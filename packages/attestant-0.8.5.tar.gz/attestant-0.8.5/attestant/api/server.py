"""
Attestant API Server: REST backend for customer provenance data.

This is the server-side counterpart to HostedStorage. Customer packages
call these endpoints to persist provenance DAGs, pipeline metadata,
and per-row audit trails to your Aurora PostgreSQL.

Run:
    ATTESTANT_DSN=postgresql://user:pass@host/db python -m attestant.api.server
"""

import hashlib
import hmac
import json
import logging
import os
import secrets
import time
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, jsonify, request, g

logger = logging.getLogger(__name__)

app = Flask(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DSN = os.environ.get("ATTESTANT_DSN", os.environ.get("PROVEIT_DSN", os.environ.get("DASH_WRITER_DSN", "")))
API_PORT = int(os.environ.get("ATTESTANT_API_PORT", "5005"))
API_SECRET = os.environ.get("ATTESTANT_API_SECRET", "")

if not API_SECRET:
    API_SECRET = secrets.token_urlsafe(32)
    logger.warning("ATTESTANT_API_SECRET not set; generated ephemeral secret")

# ---------------------------------------------------------------------------
# Database connection pool (PostgreSQL via psycopg2)
# ---------------------------------------------------------------------------

_pool = None


def _get_pool():
    global _pool
    if _pool is None:
        import psycopg2.pool as pg_pool
        _pool = pg_pool.ThreadedConnectionPool(2, 20, DSN)
    return _pool


def _get_conn():
    return _get_pool().getconn()


def _put_conn(conn):
    _get_pool().putconn(conn)


def _db():
    """Get a connection for the current request."""
    if "db" not in g:
        g.db = _get_conn()
    return g.db


@app.teardown_appcontext
def _return_conn(exc):
    conn = g.pop("db", None)
    if conn is not None:
        if exc:
            conn.rollback()
        _put_conn(conn)


# ---------------------------------------------------------------------------
# Schema bootstrap (ensures tables exist on first request)
# ---------------------------------------------------------------------------

_schema_ready = False


def _ensure_schema():
    global _schema_ready
    if _schema_ready:
        return
    from attestant.persistence.schema import get_schema_ddl
    conn = _get_conn()
    try:
        with conn.cursor() as cur:
            # Run each statement individually; skip DuplicateObject errors
            # (triggers, indexes that already exist)
            for stmt in get_schema_ddl().split(";"):
                stmt = stmt.strip()
                if not stmt or stmt.startswith("--"):
                    continue
                try:
                    cur.execute(stmt)
                    conn.commit()
                except Exception:
                    conn.rollback()
            # API keys table
            for stmt in _API_KEYS_DDL.split(";"):
                stmt = stmt.strip()
                if not stmt:
                    continue
                try:
                    cur.execute(stmt)
                    conn.commit()
                except Exception:
                    conn.rollback()
        _schema_ready = True
    finally:
        _put_conn(conn)


_API_KEYS_DDL = """
CREATE TABLE IF NOT EXISTS api_keys (
    key_id SERIAL PRIMARY KEY,
    key_hash VARCHAR(64) NOT NULL UNIQUE,
    key_prefix VARCHAR(16) NOT NULL,
    tenant_id VARCHAR(64) NOT NULL,
    tenant_name VARCHAR(255),
    tier VARCHAR(32) DEFAULT 'professional',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    last_used_at TIMESTAMP,
    rate_limit INTEGER DEFAULT 1000,
    metadata JSONB
);
CREATE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys(key_hash) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_api_keys_tenant ON api_keys(tenant_id);
"""


# ---------------------------------------------------------------------------
# API key management (admin-only)
# ---------------------------------------------------------------------------

def _hash_key(api_key: str) -> str:
    return hashlib.sha256(api_key.encode()).hexdigest()


def create_api_key(tenant_id: str, tenant_name: str = "", tier: str = "professional") -> str:
    """Generate a new API key for a tenant. Returns the raw key (show once)."""
    _ensure_schema()
    raw_key = f"pvt_live_{secrets.token_urlsafe(32)}"
    key_hash = _hash_key(raw_key)
    key_prefix = raw_key[:16]

    conn = _get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO api_keys (key_hash, key_prefix, tenant_id, tenant_name, tier)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (key_hash, key_prefix, tenant_id, tenant_name, tier),
            )
            conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        _put_conn(conn)

    return raw_key


def _validate_api_key(api_key: str):
    """Validate an API key. Returns (tenant_id, tier) or None."""
    key_hash = _hash_key(api_key)
    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT tenant_id, tier, key_id FROM api_keys
            WHERE key_hash = %s AND is_active = TRUE
            """,
            (key_hash,),
        )
        row = cur.fetchone()
        if row:
            cur.execute(
                "UPDATE api_keys SET last_used_at = NOW() WHERE key_id = %s",
                (row[2],),
            )
            conn.commit()
            return {"tenant_id": row[0], "tier": row[1]}
    return None


# ---------------------------------------------------------------------------
# Authentication middleware
# ---------------------------------------------------------------------------

def require_api_key(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Missing Authorization header"}), 401

        api_key = auth[7:]
        result = _validate_api_key(api_key)
        if result is None:
            return jsonify({"error": "Invalid API key"}), 401

        g.tenant_id = result["tenant_id"]
        g.tier = result["tier"]
        return f(*args, **kwargs)
    return decorated


def require_admin(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("X-Admin-Token", "")
        if not hmac.compare_digest(token, API_SECRET):
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.route("/v1/health", methods=["GET"])
def health():
    try:
        conn = _get_conn()
        with conn.cursor() as cur:
            cur.execute("SELECT 1")
        _put_conn(conn)
        return jsonify({"status": "healthy", "version": "1.0.0"})
    except Exception as exc:
        return jsonify({"status": "unhealthy", "error": str(exc)}), 503


# ---------------------------------------------------------------------------
# Auth validation (called by attestant.configure())
# ---------------------------------------------------------------------------

@app.route("/api/v1/auth/validate", methods=["POST"])
def auth_validate():
    _ensure_schema()
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return jsonify({"error": "Missing Authorization header"}), 401

    api_key = auth[7:]
    result = _validate_api_key(api_key)
    if result is None:
        return jsonify({"error": "Invalid API key"}), 401

    return jsonify({"tenant_id": result["tenant_id"], "tier": result["tier"]})


# ---------------------------------------------------------------------------
# Pipeline lifecycle
# ---------------------------------------------------------------------------

@app.route("/v1/pipelines", methods=["POST"])
@require_api_key
def create_pipeline():
    _ensure_schema()
    data = request.get_json(force=True)
    tenant_id = g.tenant_id

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO pipeline_metadata (pipeline_name, config, git_commit, status, tenant_id)
            VALUES (%s, %s, %s, 'running', %s)
            RETURNING pipeline_id
            """,
            (
                data.get("pipeline_name", "unnamed"),
                json.dumps(data.get("config")) if data.get("config") else None,
                data.get("git_commit"),
                tenant_id,
            ),
        )
        pipeline_id = cur.fetchone()[0]
        conn.commit()

    return jsonify({"pipeline_id": pipeline_id}), 201


@app.route("/v1/pipelines/<int:pipeline_id>", methods=["PATCH"])
@require_api_key
def complete_pipeline(pipeline_id):
    data = request.get_json(force=True)
    status = data.get("status", "completed")

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            UPDATE pipeline_metadata SET status = %s
            WHERE pipeline_id = %s AND tenant_id = %s
            """,
            (status, pipeline_id, g.tenant_id),
        )
        conn.commit()

    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# DAG nodes
# ---------------------------------------------------------------------------

@app.route("/v1/nodes", methods=["POST"])
@require_api_key
def store_nodes():
    _ensure_schema()
    from psycopg2.extras import execute_batch

    nodes = request.get_json(force=True)
    if not isinstance(nodes, list):
        return jsonify({"error": "Expected JSON array of nodes"}), 400

    tenant_id = g.tenant_id
    conn = _db()
    with conn.cursor() as cur:
        execute_batch(
            cur,
            """
            INSERT INTO dag_nodes (
                fingerprint, node_type, operation,
                table_name, column_name, pair_id, is_protected,
                entity_hash, chain_hash, metadata, pipeline_id, tenant_id
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (fingerprint, pipeline_id, tenant_id) DO NOTHING
            """,
            [
                (
                    n["fingerprint"],
                    n.get("node_type", "computation"),
                    n.get("operation", "unknown"),
                    n.get("table_name"),
                    n.get("column_name"),
                    n.get("pair_id"),
                    n.get("is_protected", False),
                    n.get("entity_hash"),
                    n.get("chain_hash"),
                    json.dumps(n["metadata"]) if n.get("metadata") else None,
                    n.get("pipeline_id"),
                    tenant_id,
                )
                for n in nodes
            ],
            page_size=100,
        )
        conn.commit()

    return jsonify({"stored": len(nodes)}), 201


@app.route("/v1/nodes", methods=["GET"])
@require_api_key
def get_node():
    fingerprint = request.args.get("fingerprint", type=int)
    pipeline_id = request.args.get("pipeline_id", type=int)

    if fingerprint is None:
        return jsonify({"error": "fingerprint parameter required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        if pipeline_id is not None:
            cur.execute(
                """
                SELECT node_id, fingerprint, node_type, operation,
                       table_name, column_name, pair_id, is_protected,
                       entity_hash, chain_hash, metadata
                FROM dag_nodes
                WHERE fingerprint = %s AND pipeline_id = %s AND tenant_id = %s
                """,
                (fingerprint, pipeline_id, g.tenant_id),
            )
        else:
            cur.execute(
                """
                SELECT node_id, fingerprint, node_type, operation,
                       table_name, column_name, pair_id, is_protected,
                       entity_hash, chain_hash, metadata
                FROM dag_nodes
                WHERE fingerprint = %s AND tenant_id = %s
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (fingerprint, g.tenant_id),
            )
        row = cur.fetchone()

    if row is None:
        return jsonify(None)

    return jsonify({
        "node_id": row[0],
        "fingerprint": row[1],
        "node_type": row[2],
        "operation": row[3],
        "table_name": row[4],
        "column_name": row[5],
        "pair_id": row[6],
        "is_protected": row[7],
        "entity_hash": row[8],
        "chain_hash": row[9],
        "metadata": json.loads(row[10]) if row[10] else None,
    })


@app.route("/v1/nodes/fingerprint-map", methods=["GET"])
@require_api_key
def fingerprint_map():
    pipeline_id = request.args.get("pipeline_id", type=int)
    if pipeline_id is None:
        return jsonify({"error": "pipeline_id parameter required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            "SELECT fingerprint, node_id FROM dag_nodes WHERE pipeline_id = %s AND tenant_id = %s",
            (pipeline_id, g.tenant_id),
        )
        result = {str(row[0]): row[1] for row in cur.fetchall()}

    return jsonify(result)


# ---------------------------------------------------------------------------
# DAG edges
# ---------------------------------------------------------------------------

@app.route("/v1/edges", methods=["POST"])
@require_api_key
def store_edges():
    _ensure_schema()
    from psycopg2.extras import execute_batch

    edges = request.get_json(force=True)
    if not isinstance(edges, list):
        return jsonify({"error": "Expected JSON array of edges"}), 400

    conn = _db()
    with conn.cursor() as cur:
        if edges and "parent_node_id" in edges[0]:
            execute_batch(
                cur,
                """
                INSERT INTO dag_edges (parent_node_id, child_node_id, input_position)
                VALUES (%s, %s, %s)
                ON CONFLICT DO NOTHING
                """,
                [
                    (e["parent_node_id"], e["child_node_id"], e.get("input_position", 0))
                    for e in edges
                ],
                page_size=100,
            )
        else:
            execute_batch(
                cur,
                """
                INSERT INTO dag_edges (parent_node_id, child_node_id, input_position)
                SELECT p.node_id, c.node_id, %s
                FROM dag_nodes p, dag_nodes c
                WHERE p.fingerprint = %s AND c.fingerprint = %s
                  AND p.tenant_id = %s AND c.tenant_id = %s
                ON CONFLICT DO NOTHING
                """,
                [
                    (
                        e.get("input_position", 0),
                        e["parent_fingerprint"],
                        e["child_fingerprint"],
                        g.tenant_id,
                        g.tenant_id,
                    )
                    for e in edges
                ],
                page_size=100,
            )
        conn.commit()

    return jsonify({"stored": len(edges)}), 201


@app.route("/v1/edges", methods=["GET"])
@require_api_key
def get_edges():
    node_id = request.args.get("node_id", type=int)
    if node_id is None:
        return jsonify({"error": "node_id parameter required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT e.parent_node_id, e.input_position, n.fingerprint
            FROM dag_edges e
            JOIN dag_nodes n ON e.parent_node_id = n.node_id
            WHERE e.child_node_id = %s AND n.tenant_id = %s
            ORDER BY e.input_position
            """,
            (node_id, g.tenant_id),
        )
        result = [
            {
                "parent_node_id": row[0],
                "input_position": row[1],
                "parent_fingerprint": row[2],
            }
            for row in cur.fetchall()
        ]

    return jsonify(result)


# ---------------------------------------------------------------------------
# Source registry
# ---------------------------------------------------------------------------

@app.route("/v1/sources", methods=["POST"])
@require_api_key
def register_source():
    _ensure_schema()
    data = request.get_json(force=True)

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO source_registry (pair_id, table_name, column_name, is_protected)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (pair_id) DO UPDATE
            SET table_name = EXCLUDED.table_name,
                column_name = EXCLUDED.column_name,
                is_protected = EXCLUDED.is_protected
            """,
            (
                data["pair_id"],
                data["table_name"],
                data["column_name"],
                data.get("is_protected", False),
            ),
        )
        conn.commit()

    return jsonify({"ok": True}), 201


@app.route("/v1/sources", methods=["GET"])
@require_api_key
def get_source():
    pair_id = request.args.get("pair_id", type=int)
    if pair_id is None:
        return jsonify({"error": "pair_id parameter required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            "SELECT table_name, column_name, is_protected FROM source_registry WHERE pair_id = %s",
            (pair_id,),
        )
        row = cur.fetchone()

    if row is None:
        return jsonify(None)

    return jsonify({
        "table_name": row[0],
        "column_name": row[1],
        "is_protected": row[2],
    })


# ---------------------------------------------------------------------------
# Pipeline results (per-row audit trail)
# ---------------------------------------------------------------------------

@app.route("/v1/results", methods=["POST"])
@require_api_key
def store_results():
    _ensure_schema()
    from psycopg2.extras import execute_batch

    data = request.get_json(force=True)
    pipeline_id = data.get("pipeline_id")
    results = data.get("results", [])

    if not pipeline_id or not results:
        return jsonify({"error": "pipeline_id and results required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        execute_batch(
            cur,
            """
            INSERT INTO pipeline_results
                (pipeline_id, row_key, output_name, fingerprint, output_value, input_hash)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            [
                (
                    pipeline_id,
                    r["row_key"],
                    r["output_name"],
                    r["fingerprint"],
                    r.get("output_value"),
                    r.get("input_hash"),
                )
                for r in results
            ],
            page_size=100,
        )
        conn.commit()

    return jsonify({"stored": len(results)}), 201


@app.route("/v1/results", methods=["GET"])
@require_api_key
def get_results():
    row_key = request.args.get("row_key")
    pipeline_id = request.args.get("pipeline_id", type=int)

    if not row_key:
        return jsonify({"error": "row_key parameter required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        if pipeline_id is not None:
            cur.execute(
                """
                SELECT r.output_name, r.fingerprint, r.output_value,
                       r.pipeline_id, n.node_id, n.node_type, n.operation,
                       n.is_protected
                FROM pipeline_results r
                LEFT JOIN dag_nodes n
                    ON r.fingerprint = n.fingerprint AND r.pipeline_id = n.pipeline_id
                    AND n.tenant_id = %s
                JOIN pipeline_metadata pm ON r.pipeline_id = pm.pipeline_id
                WHERE r.row_key = %s AND r.pipeline_id = %s AND pm.tenant_id = %s
                ORDER BY r.output_name
                """,
                (g.tenant_id, row_key, pipeline_id, g.tenant_id),
            )
        else:
            cur.execute(
                """
                SELECT r.output_name, r.fingerprint, r.output_value,
                       r.pipeline_id, n.node_id, n.node_type, n.operation,
                       n.is_protected
                FROM pipeline_results r
                LEFT JOIN dag_nodes n
                    ON r.fingerprint = n.fingerprint AND r.pipeline_id = n.pipeline_id
                    AND n.tenant_id = %s
                JOIN pipeline_metadata pm ON r.pipeline_id = pm.pipeline_id
                WHERE r.row_key = %s AND pm.tenant_id = %s
                ORDER BY r.pipeline_id DESC, r.output_name
                """,
                (g.tenant_id, row_key, g.tenant_id),
            )
        result = [
            {
                "output_name": row[0],
                "fingerprint": row[1],
                "output_value": row[2],
                "pipeline_id": row[3],
                "node_id": row[4],
                "node_type": row[5],
                "operation": row[6],
                "is_protected": row[7],
            }
            for row in cur.fetchall()
        ]

    return jsonify(result)


# ---------------------------------------------------------------------------
# Row values (value-level lineage)
# ---------------------------------------------------------------------------

@app.route("/v1/values", methods=["POST"])
@require_api_key
def store_values():
    _ensure_schema()
    from psycopg2.extras import execute_batch

    values = request.get_json(force=True)
    if not isinstance(values, list):
        return jsonify({"error": "Expected JSON array of values"}), 400

    tenant_id = g.tenant_id
    conn = _db()
    with conn.cursor() as cur:
        execute_batch(
            cur,
            """
            INSERT INTO row_values
                (pipeline_id, row_index, fingerprint, node_operation,
                 column_name, value, tenant_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            [
                (
                    v["pipeline_id"],
                    v["row_index"],
                    v["fingerprint"],
                    v["node_operation"],
                    v.get("column_name"),
                    v.get("value"),
                    tenant_id,
                )
                for v in values
            ],
            page_size=500,
        )
        conn.commit()

    return jsonify({"stored": len(values)}), 201


@app.route("/v1/values", methods=["GET"])
@require_api_key
def get_values():
    pipeline_id = request.args.get("pipeline_id", type=int)
    row_index = request.args.get("row_index", type=int)

    if pipeline_id is None or row_index is None:
        return jsonify({"error": "pipeline_id and row_index parameters required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT fingerprint, node_operation, column_name, value
            FROM row_values
            WHERE pipeline_id = %s AND row_index = %s AND tenant_id = %s
            ORDER BY value_id
            """,
            (pipeline_id, row_index, g.tenant_id),
        )
        result = [
            {
                "fingerprint": row[0],
                "node_operation": row[1],
                "column_name": row[2],
                "value": row[3],
            }
            for row in cur.fetchall()
        ]

    return jsonify(result)


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------

@app.route("/v1/stats", methods=["GET"])
@require_api_key
def get_stats():
    conn = _db()
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM dag_nodes WHERE tenant_id = %s", (g.tenant_id,))
        nodes = cur.fetchone()[0]

        cur.execute(
            """
            SELECT COUNT(*) FROM dag_edges e
            JOIN dag_nodes n ON e.child_node_id = n.node_id
            WHERE n.tenant_id = %s
            """,
            (g.tenant_id,),
        )
        edges = cur.fetchone()[0]

        cur.execute("SELECT COUNT(*) FROM dag_nodes WHERE tenant_id = %s AND is_protected = TRUE", (g.tenant_id,))
        protected = cur.fetchone()[0]

        cur.execute("SELECT COUNT(*) FROM pipeline_metadata WHERE tenant_id = %s", (g.tenant_id,))
        pipelines = cur.fetchone()[0]

    return jsonify({
        "nodes": nodes,
        "edges": edges,
        "protected_nodes": protected,
        "pipelines": pipelines,
    })


# ---------------------------------------------------------------------------
# Admin: key management
# ---------------------------------------------------------------------------

@app.route("/admin/keys", methods=["POST"])
@require_admin
def admin_create_key():
    _ensure_schema()
    data = request.get_json(force=True)
    tenant_id = data.get("tenant_id")
    if not tenant_id:
        return jsonify({"error": "tenant_id required"}), 400

    raw_key = create_api_key(
        tenant_id=tenant_id,
        tenant_name=data.get("tenant_name", ""),
        tier=data.get("tier", "professional"),
    )
    return jsonify({"api_key": raw_key, "tenant_id": tenant_id}), 201


@app.route("/admin/keys", methods=["GET"])
@require_admin
def admin_list_keys():
    _ensure_schema()
    conn = _get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT key_id, key_prefix, tenant_id, tenant_name, tier,
                       is_active, created_at, last_used_at
                FROM api_keys ORDER BY created_at DESC
                """
            )
            keys = [
                {
                    "key_id": row[0],
                    "key_prefix": row[1],
                    "tenant_id": row[2],
                    "tenant_name": row[3],
                    "tier": row[4],
                    "is_active": row[5],
                    "created_at": row[6].isoformat() if row[6] else None,
                    "last_used_at": row[7].isoformat() if row[7] else None,
                }
                for row in cur.fetchall()
            ]
    finally:
        _put_conn(conn)

    return jsonify(keys)


@app.route("/admin/keys/<int:key_id>/revoke", methods=["POST"])
@require_admin
def admin_revoke_key(key_id):
    conn = _get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE api_keys SET is_active = FALSE WHERE key_id = %s",
                (key_id,),
            )
            conn.commit()
    finally:
        _put_conn(conn)

    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Admin: DAG integrity verification
# ---------------------------------------------------------------------------

@app.route("/admin/verify/<int:pipeline_id>", methods=["GET"])
@require_admin
def admin_verify_dag(pipeline_id):
    from attestant.persistence.storage import PostgreSQLStorage
    storage = PostgreSQLStorage(DSN)
    storage.connect()
    try:
        result = storage.verify_dag_integrity(pipeline_id)
    finally:
        storage.disconnect()
    return jsonify(result)


# ---------------------------------------------------------------------------
# Unified Orchestration Endpoints (Model Validation & Deployment)
# ---------------------------------------------------------------------------

@app.route("/v1/models/validate-and-deploy", methods=["POST"])
@require_api_key
def validate_and_deploy():
    """
    End-to-end model validation and deployment decision.

    Orchestrates: FairLens → Compliance → Deployment Gate → Documentation
    """
    _ensure_schema()
    data = request.get_json(force=True)

    model_name = data.get("model_name")
    model_version = data.get("model_version")

    if not all([model_name, model_version]):
        return jsonify({"error": "model_name and model_version required"}), 400

    # TODO: Implement full orchestration with model loading from S3
    # For now, return structure showing integration pattern
    return jsonify({
        "status": "pending",
        "message": "Full orchestration integration in progress",
        "model_name": model_name,
        "model_version": model_version,
        "tenant_id": g.tenant_id,
    }), 200


@app.route("/v1/models/<model_name>/lifecycle", methods=["GET"])
@require_api_key
def get_model_lifecycle(model_name):
    """
    Get complete lifecycle view for a model.

    Returns all versions, deployment history, fairness trends, compliance status.
    """
    # TODO: Query model registry and deployment decisions
    return jsonify({
        "model_name": model_name,
        "versions": [],
        "fairness_trend": [],
        "compliance_trend": [],
        "tenant_id": g.tenant_id,
    }), 200


@app.route("/v1/models/<model_name>/attestation/<attestation_id>", methods=["GET"])
@require_api_key
def get_attestation(model_name, attestation_id):
    """Retrieve deployment attestation and validation results."""
    # TODO: Query attestation store (S3 or PostgreSQL)
    return jsonify({
        "attestation_id": attestation_id,
        "model_name": model_name,
        "status": "not_implemented",
        "tenant_id": g.tenant_id,
    }), 200


@app.route("/v1/compliance/violations", methods=["GET"])
@require_api_key
def get_compliance_violations():
    """Get all active compliance violations across models."""
    # TODO: Query compliance violation tracking
    return jsonify({
        "violations": [],
        "total_count": 0,
        "critical_count": 0,
        "tenant_id": g.tenant_id,
    }), 200


@app.route("/v1/fairness/regression-trends", methods=["GET"])
@require_api_key
def get_fairness_regression_trends():
    """Get fairness regression trends across model versions."""
    model_name = request.args.get("model_name")

    if not model_name:
        return jsonify({"error": "model_name parameter required"}), 400

    # TODO: Query fairness regression history
    return jsonify({
        "model_name": model_name,
        "trend_data": [],
        "tenant_id": g.tenant_id,
    }), 200


# ---------------------------------------------------------------------------
# Dashboard sync: pipeline results -> dashboard tables
# ---------------------------------------------------------------------------

@app.route("/v1/dashboard/sync", methods=["POST"])
@require_api_key
def dashboard_sync():
    """Sync pipeline results to dashboard tables.

    Called automatically by flush() so pipeline data appears in dashboards.
    Accepts pipeline stats, model info, and fairness results in one call.
    """
    data = request.get_json(force=True)
    tenant_id = g.tenant_id
    conn = _get_pool().getconn()
    try:
        cur = conn.cursor()

        pipeline = data.get("pipeline")
        if pipeline:
            cur.execute(
                """INSERT INTO pipeline_stats
                   (tenant_id, pipeline_name, status, node_count, edge_count,
                    duration_ms, completed_at)
                   VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                (
                    tenant_id,
                    pipeline.get("pipeline_name"),
                    pipeline.get("status", "completed"),
                    pipeline.get("node_count", 0),
                    pipeline.get("edge_count", 0),
                    pipeline.get("duration_ms"),
                    pipeline.get("completed_at"),
                ),
            )

        model = data.get("model")
        if model:
            cur.execute(
                """INSERT INTO model_snapshots
                   (tenant_id, model_id, name, version, tier, status, domain, owner,
                    compliance_score, last_validated, last_monitored,
                    validation_overdue, monitoring_overdue, finding_count)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (
                    tenant_id,
                    model.get("model_id"),
                    model.get("name"),
                    model.get("version"),
                    model.get("tier", 3),
                    model.get("status", "production"),
                    model.get("domain"),
                    model.get("owner"),
                    model.get("compliance_score"),
                    model.get("last_validated"),
                    model.get("last_monitored"),
                    model.get("validation_overdue", False),
                    model.get("monitoring_overdue", False),
                    model.get("finding_count", 0),
                ),
            )

        fairness = data.get("fairness")
        if fairness:
            cur.execute(
                """INSERT INTO fairness_snapshots
                   (tenant_id, model_id, has_disparate_impact, worst_ratio,
                    worst_group, p_value, statistically_significant,
                    protected_attributes, sample_size_warnings, details)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (
                    tenant_id,
                    fairness.get("model_id"),
                    fairness.get("has_disparate_impact", False),
                    fairness.get("worst_ratio"),
                    fairness.get("worst_group"),
                    fairness.get("p_value"),
                    fairness.get("statistically_significant", False),
                    json.dumps(fairness.get("protected_attributes", [])),
                    json.dumps(fairness.get("sample_size_warnings", [])),
                    json.dumps(fairness.get("details", {})),
                ),
            )

        compliance = data.get("compliance")
        if compliance:
            cur.execute(
                """INSERT INTO compliance_snapshots
                   (tenant_id, score, grade, engines_evaluated, critical_findings,
                    warning_findings, total_findings, top_risks, breakdowns, bonuses, trend)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (
                    tenant_id,
                    compliance.get("score", 0),
                    compliance.get("grade", "--"),
                    compliance.get("engines_evaluated", 0),
                    compliance.get("critical_findings", 0),
                    compliance.get("warning_findings", 0),
                    compliance.get("total_findings", 0),
                    json.dumps(compliance.get("top_risks", [])),
                    json.dumps(compliance.get("breakdowns", [])),
                    json.dumps(compliance.get("bonuses_applied", {})),
                    compliance.get("trend"),
                ),
            )

        alerts = data.get("alerts") or []
        for alert in alerts:
            cur.execute(
                """INSERT INTO alert_log
                   (tenant_id, severity, source, title, description, model_id, regulation)
                   VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                (
                    tenant_id,
                    alert.get("severity"),
                    alert.get("source"),
                    alert.get("title"),
                    alert.get("description"),
                    alert.get("model_id"),
                    alert.get("regulation"),
                ),
            )

        conn.commit()
        return jsonify({"ok": True}), 200
    except Exception:
        conn.rollback()
        logger.exception("Dashboard sync failed")
        return jsonify({"error": "sync failed"}), 500
    finally:
        _get_pool().putconn(conn)


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )

    if not DSN:
        print("ERROR: Set ATTESTANT_DSN or DASH_WRITER_DSN to your PostgreSQL connection string")
        print("  Example: ATTESTANT_DSN=postgresql://user:pass@localhost/proveit python -m attestant.api.server")
        raise SystemExit(1)

    _ensure_schema()
    logger.info("Attestant API server starting on port %d", API_PORT)

    app.run(host="0.0.0.0", port=API_PORT, debug=False)


if __name__ == "__main__":
    main()
