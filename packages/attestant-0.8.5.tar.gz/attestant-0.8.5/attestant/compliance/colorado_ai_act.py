"""
Colorado AI Act (SB 24-205) Compliance Engine for HYDRA-24.

Implements checks against the Colorado Artificial Intelligence Act
(C.R.S. § 6-1-1701 et seq.), effective February 1, 2026.

Key provisions:
    § 6-1-1702   Definitions (consequential decision, high-risk AI system)
    § 6-1-1703   Developer duties (documentation, risk management)
    § 6-1-1704   Deployer duties (risk management, impact assessment)
    § 6-1-1705   Notice requirements
    § 6-1-1706   Enforcement and penalties

The Act applies to AI systems that make or substantially factor into
"consequential decisions" in education, employment, financial services,
government services, healthcare, housing, insurance, and legal services.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Set

from ..hydra24_dag import ComputationDAG
from .base import (
    BaseComplianceEngine,
    ComplianceFinding,
    ComplianceResult,
    Severity,
)

_CONSEQUENTIAL_DOMAINS: Set[str] = {
    "education", "education_assessment",
    "employment", "hiring", "recruitment",
    "financial_services", "credit_scoring", "loan_approval", "insurance_pricing",
    "government_services",
    "healthcare", "healthcare_triage",
    "housing",
    "insurance",
    "legal_services", "judicial",
}


def _is_consequential(metadata: Dict[str, Any]) -> bool:
    """Determine if the AI system makes consequential decisions."""
    domain = (
        metadata.get("domain") or metadata.get("use_case") or ""
    ).lower().strip()
    return domain in _CONSEQUENTIAL_DOMAINS


class ColoradoAIActEngine(BaseComplianceEngine):
    """Compliance engine for the Colorado AI Act (SB 24-205).

    Checks:
    1. **Consequential decision classification** -- determines if the Act
       applies based on the system's domain.
    2. **Risk management programme** -- verifies NIST/ISO 42001-aligned
       risk management policy.
    3. **Impact assessment** -- validates that a required impact assessment
       has been conducted and is current (annual renewal).
    4. **Deployer duties** -- checks disclosure, governance, and notice.
    5. **Developer duties** -- checks documentation provided to deployers.
    """

    @property
    def regulation_name(self) -> str:
        return "Colorado AI Act (SB 24-205)"

    def check(
        self,
        dag: ComputationDAG,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ComplianceResult:
        meta = metadata or {}
        findings: List[ComplianceFinding] = []
        citations: List[str] = []

        is_consequential = _is_consequential(meta)

        findings.extend(self._check_classification(is_consequential, meta))

        if is_consequential:
            findings.extend(self._check_risk_management(meta))
            findings.extend(self._check_impact_assessment(meta))
            findings.extend(self._check_deployer_duties(meta))
            findings.extend(self._check_developer_duties(meta))
            findings.extend(self._check_notice_requirements(meta))

        for f in findings:
            if f.regulation_citation and f.regulation_citation not in citations:
                citations.append(f.regulation_citation)

        passed = all(f.severity != Severity.CRITICAL for f in findings)

        from .base import ComplianceReport
        remediation_recs = ComplianceReport._dedup_flat(
            [[f.remediation] for f in findings if f.remediation]
        )

        return ComplianceResult(
            passed=passed,
            regulation_name=self.regulation_name,
            findings=findings,
            citations=citations,
            remediation_recommendations=remediation_recs,
            metadata={
                "is_consequential_decision": is_consequential,
                "domain": meta.get("domain", ""),
            },
        )

    # -- individual checks ---------------------------------------------------

    def _check_classification(
        self, is_consequential: bool, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        findings: List[ComplianceFinding] = []

        if is_consequential:
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    f"System classified as HIGH-RISK under the Colorado "
                    f"AI Act (domain: {meta.get('domain', 'unknown')}). "
                    f"All § 6-1-1703 and § 6-1-1704 obligations apply. "
                    f"Effective February 1, 2026."
                ),
                regulation_citation="C.R.S. § 6-1-1702",
            ))
        else:
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "System does not appear to make consequential "
                    "decisions under the Colorado AI Act."
                ),
                regulation_citation="C.R.S. § 6-1-1702",
            ))

        return findings

    def _check_risk_management(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """§ 6-1-1704(2): Risk management programme."""
        findings: List[ComplianceFinding] = []

        if not meta.get("risk_management_policy"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No risk management policy documented. § 6-1-1704(2) "
                    "requires deployers of high-risk AI systems to "
                    "implement a risk management policy and programme "
                    "aligned with NIST AI RMF or ISO 42001."
                ),
                regulation_citation="C.R.S. § 6-1-1704(2)",
                remediation=(
                    "Implement a risk management policy aligned with "
                    "NIST AI RMF 1.0 or ISO/IEC 42001. Document under "
                    "'risk_management_policy'."
                ),
            ))

        if not meta.get("risk_management_framework"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No risk management framework reference. The Colorado "
                    "AI Act allows conformance with recognized frameworks "
                    "(NIST AI RMF, ISO 42001) as a rebuttable presumption "
                    "of compliance."
                ),
                regulation_citation="C.R.S. § 6-1-1704(2)",
                remediation=(
                    "Specify which framework the risk management programme "
                    "follows under 'risk_management_framework' (e.g. "
                    "'NIST AI RMF 1.0', 'ISO 42001')."
                ),
            ))

        return findings

    def _check_impact_assessment(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """§ 6-1-1704(3): Impact assessment requirement."""
        findings: List[ComplianceFinding] = []

        if not meta.get("impact_assessment_date"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No impact assessment conducted. § 6-1-1704(3) "
                    "requires deployers to complete an impact assessment "
                    "before deploying a high-risk AI system and annually "
                    "thereafter."
                ),
                regulation_citation="C.R.S. § 6-1-1704(3)",
                remediation=(
                    "Conduct an impact assessment covering: purpose, "
                    "intended benefits, potential risks of algorithmic "
                    "discrimination, data used, mitigation steps. "
                    "Record date under 'impact_assessment_date'."
                ),
            ))
        else:
            # Check annual renewal
            try:
                from datetime import datetime, timezone
                ia_dt = datetime.fromisoformat(str(meta["impact_assessment_date"]))
                if ia_dt.tzinfo is None:
                    ia_dt = ia_dt.replace(tzinfo=timezone.utc)
                days_old = (datetime.now(timezone.utc) - ia_dt).days
                if days_old > 365:
                    findings.append(ComplianceFinding(
                        severity=Severity.WARNING,
                        description=(
                            f"Impact assessment is {days_old} days old. "
                            f"§ 6-1-1704(3) requires annual renewal."
                        ),
                        regulation_citation="C.R.S. § 6-1-1704(3)",
                        remediation="Renew impact assessment annually.",
                    ))
            except (ValueError, TypeError):
                pass

        if not meta.get("impact_assessment_summary"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No impact assessment summary documented. The "
                    "assessment must describe the purpose, intended "
                    "benefits, potential risks of algorithmic "
                    "discrimination, and mitigation steps."
                ),
                regulation_citation="C.R.S. § 6-1-1704(3)",
                remediation=(
                    "Document assessment summary under "
                    "'impact_assessment_summary'."
                ),
            ))

        return findings

    def _check_deployer_duties(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """§ 6-1-1704: Deployer governance duties."""
        findings: List[ComplianceFinding] = []

        if not meta.get("deployer_contact_info"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No deployer contact information for consumers. "
                    "§ 6-1-1704(4) requires deployers to make available "
                    "a description of the AI system and contact info "
                    "for questions or complaints."
                ),
                regulation_citation="C.R.S. § 6-1-1704(4)",
                remediation=(
                    "Provide deployer contact information under "
                    "'deployer_contact_info'."
                ),
            ))

        if not meta.get("human_appeal_process"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No human appeal process documented. § 6-1-1704(5) "
                    "requires that consumers have the opportunity to "
                    "appeal an adverse consequential decision with a "
                    "human reviewer."
                ),
                regulation_citation="C.R.S. § 6-1-1704(5)",
                remediation=(
                    "Implement and document a human appeal process "
                    "under 'human_appeal_process'."
                ),
            ))

        return findings

    def _check_developer_duties(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """§ 6-1-1703: Developer documentation duties."""
        findings: List[ComplianceFinding] = []

        if not meta.get("developer_documentation_provided"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No developer documentation provided. § 6-1-1703(2) "
                    "requires developers to provide deployers with: "
                    "high-level summary of the AI system, known "
                    "limitations, intended use documentation, and "
                    "results of evaluations for algorithmic discrimination."
                ),
                regulation_citation="C.R.S. § 6-1-1703(2)",
                remediation=(
                    "Obtain and record developer-provided documentation "
                    "under 'developer_documentation_provided'."
                ),
            ))

        return findings

    def _check_notice_requirements(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """§ 6-1-1705: Notice to consumers."""
        findings: List[ComplianceFinding] = []

        if not meta.get("consumer_ai_disclosure"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No consumer AI disclosure documented. § 6-1-1705 "
                    "requires deployers to notify consumers that an AI "
                    "system is being used to make or substantially factor "
                    "into a consequential decision about them."
                ),
                regulation_citation="C.R.S. § 6-1-1705",
                remediation=(
                    "Disclose AI use to consumers before or at the time "
                    "of the consequential decision. Record under "
                    "'consumer_ai_disclosure'."
                ),
            ))

        if not meta.get("adverse_decision_explanation"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No adverse decision explanation mechanism documented. "
                    "§ 6-1-1705(2) requires that if an adverse "
                    "consequential decision is made, the consumer is "
                    "provided with a statement of reasons and an "
                    "explanation of how AI contributed."
                ),
                regulation_citation="C.R.S. § 6-1-1705(2)",
                remediation=(
                    "Implement adverse decision explanation and record "
                    "under 'adverse_decision_explanation'."
                ),
            ))

        return findings
