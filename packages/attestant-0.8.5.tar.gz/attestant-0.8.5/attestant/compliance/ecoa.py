"""
ECOA / Regulation B (Fair Lending) Compliance Engine for HYDRA-24.

Implements checks against the Equal Credit Opportunity Act (15 U.S.C.
1691 et seq.) and its implementing regulation, Regulation B (12 CFR Part
1002), as enforced by the Consumer Financial Protection Bureau (CFPB).

Key provisions checked:
    15 U.S.C. 1691(a)       - Prohibition on discrimination
    12 CFR 1002.4(a)        - Discrimination prohibition in any aspect of
                              a credit transaction
    12 CFR 1002.5(a)        - General rules on requests for information
    12 CFR 1002.5(b)-(d)    - Limitations on inquiring about protected
                              characteristics
    12 CFR 1002.6(a)        - Rules on evaluating applications
    12 CFR 1002.6(b)        - Specific rules concerning use of
                              information
    12 CFR 1002.9(a)(2)     - Statement of specific reasons for adverse
                              action
    12 CFR 1002.9(b)(2)     - Statement of the action taken
    12 CFR 1002.12          - Record retention
    12 CFR 1002.13          - Information for monitoring purposes (HMDA)

The engine inspects a HYDRA-24 ``ComputationDAG`` to detect whether
protected-class attributes flow into credit decisions and whether the
requisite adverse-action and record-retention requirements are met.
"""

from __future__ import annotations

from collections import deque
from typing import Any, Dict, List, Optional, Set, Tuple

from ..hydra24_dag import ComputationDAG, DAGNode, NodeType
from .base import (
    BaseComplianceEngine,
    ComplianceFinding,
    ComplianceResult,
    Severity,
)


# ---------------------------------------------------------------------------
# Protected attributes under ECOA / Reg B
# ---------------------------------------------------------------------------

_PROTECTED_ATTRIBUTES: Dict[str, str] = {
    "race": "15 U.S.C. 1691(a)(1)",
    "color": "15 U.S.C. 1691(a)(1)",
    "religion": "15 U.S.C. 1691(a)(1)",
    "national_origin": "15 U.S.C. 1691(a)(1)",
    "nationality": "15 U.S.C. 1691(a)(1)",
    "sex": "15 U.S.C. 1691(a)(1)",
    "gender": "15 U.S.C. 1691(a)(1)",
    "marital_status": "15 U.S.C. 1691(a)(1)",
    "age": "15 U.S.C. 1691(a)(1)",
    "ethnicity": "15 U.S.C. 1691(a)(1)",
    "public_assistance": "15 U.S.C. 1691(a)(2)",
    "welfare": "15 U.S.C. 1691(a)(2)",
    "disability": "15 U.S.C. 1691(a)(1)",
    "familial_status": "15 U.S.C. 1691(a)(1)",
    "pregnancy": "15 U.S.C. 1691(a)(1)",
    "sexual_orientation": "12 CFR 1002.4(a)",
    "gender_identity": "12 CFR 1002.4(a)",
}

_PROTECTED_COLUMN_PATTERNS: List[str] = [
    "race",
    "ethnicity",
    "ethnic",
    "sex",
    "gender",
    "marital",
    "married",
    "age",
    "dob",
    "date_of_birth",
    "birth_date",
    "national_origin",
    "nationality",
    "religion",
    "religious",
    "color",
    "skin_color",
    "public_assistance",
    "welfare",
    "snap",
    "tanf",
    "disability",
    "disabled",
    "pregnant",
    "pregnancy",
    "familial_status",
    "num_children",
    "dependents",
    "sexual_orientation",
    "gender_identity",
    "lgbtq",
]


def _column_is_protected(column_name: str) -> Tuple[bool, str]:
    """Test whether a column name matches a protected attribute pattern.

    Uses word-boundary-aware matching: splits on underscores and checks
    for exact token matches to avoid false positives like "age" matching
    "mileage" or "race" matching "workplace_race_condition".

    Returns (is_protected, matched_attribute).
    """
    lower = column_name.lower().strip().replace(" ", "_")
    tokens = set(lower.split("_"))
    # Also check full name for multi-token patterns (e.g. "date_of_birth")
    for pattern in _PROTECTED_COLUMN_PATTERNS:
        pattern_tokens = set(pattern.split("_"))
        if pattern_tokens.issubset(tokens) or pattern == lower:
            for attr, citation in _PROTECTED_ATTRIBUTES.items():
                attr_tokens = set(attr.split("_"))
                if attr_tokens.issubset(tokens) or pattern == attr or pattern in attr:
                    return True, attr
            return True, pattern
    return False, ""


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class ECOAEngine(BaseComplianceEngine):
    """Compliance engine for ECOA (Equal Credit Opportunity Act) / Reg B.

    Checks:
    1. **Protected-class detection** -- scans the DAG for source columns
       that match protected attributes.
    2. **Protected-data influence** -- measures how much of the
       computation graph is influenced by protected data.
    3. **Disparate impact analysis readiness** -- verifies that metadata
       contains the information needed for a disparate-impact assessment.
    4. **Adverse action requirements** -- checks that adverse-action codes
       and reasons are documented.
    5. **Record retention** -- verifies the stated retention period meets
       regulatory minimums.
    """

    @property
    def regulation_name(self) -> str:
        return "ECOA / Reg B"

    def check(
        self,
        dag: ComputationDAG,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ComplianceResult:
        meta = metadata or {}
        findings: List[ComplianceFinding] = []
        citations: List[str] = []

        findings.extend(self._check_protected_attributes(dag, meta))
        findings.extend(self._check_protected_influence(dag, meta))
        findings.extend(self._check_disparate_impact(meta))
        findings.extend(self._check_intersectional_impact(meta))
        findings.extend(self._check_adverse_action(meta))
        findings.extend(self._check_adverse_action_completeness(meta))
        findings.extend(self._check_model_explainability(meta))
        findings.extend(self._check_record_retention(meta))
        findings.extend(self._check_information_requests(meta))
        findings.extend(self._check_hmda_monitoring(meta))
        findings.extend(self._check_sogi_protection(dag))
        findings.extend(self._check_model_governance(meta))

        for f in findings:
            if f.regulation_citation and f.regulation_citation not in citations:
                citations.append(f.regulation_citation)

        passed = all(f.severity != Severity.CRITICAL for f in findings)

        from .base import ComplianceReport
        remediation_recs = ComplianceReport._dedup_flat(
            [[f.remediation] for f in findings if f.remediation]
        )

        influence_pct = self._calculate_protected_influence(dag)
        return ComplianceResult(
            passed=passed,
            regulation_name=self.regulation_name,
            findings=findings,
            citations=citations,
            remediation_recommendations=remediation_recs,
            metadata={
                "protected_influence_pct": influence_pct,
                "protected_sources_detected": [
                    (n.table, n.column)
                    for n in dag.source_nodes
                    if n.is_protected
                ],
            },
        )

    # -- individual checks ---------------------------------------------------

    def _check_protected_attributes(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """Scan the DAG for protected-class attributes used in the computation."""
        findings: List[ComplianceFinding] = []

        detected_protected: List[Tuple[DAGNode, str]] = []

        for node in dag.source_nodes:
            if node.is_protected and node.column:
                is_match, attr = _column_is_protected(node.column)
                if is_match:
                    detected_protected.append((node, attr))
                else:
                    detected_protected.append((node, "unknown_protected"))

            elif node.column:
                is_match, attr = _column_is_protected(node.column)
                if is_match:
                    detected_protected.append((node, attr))

        if detected_protected:
            attr_summary = ", ".join(
                sorted(set(f"{attr} ({n.table}.{n.column})" for n, attr in detected_protected))
            )
            node_ids = [n.node_id for n, _ in detected_protected]

            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    f"Protected-class attribute(s) detected in the computation "
                    f"DAG: {attr_summary}. Under 12 CFR 1002.6(b), a creditor "
                    f"shall not take a prohibited basis into account in any "
                    f"system of evaluating creditworthiness."
                ),
                regulation_citation="12 CFR 1002.6(b)",
                affected_nodes=node_ids,
                remediation=(
                    "Remove protected attributes from the model features. If "
                    "retained for monitoring purposes only, ensure they are "
                    "excluded from the decision path and document the "
                    "separation."
                ),
            ))

            for node, attr in detected_protected:
                if attr == "age":
                    findings.append(ComplianceFinding(
                        severity=Severity.WARNING,
                        description=(
                            f"Age data detected ({node.table}.{node.column}). "
                            f"Under 12 CFR 1002.6(b)(2)(ii), a creditor may "
                            f"use age in an empirically derived, demonstrably "
                            f"and statistically sound credit scoring system "
                            f"that does not assign a negative factor or value "
                            f"to applicants aged 62 or older."
                        ),
                        regulation_citation="12 CFR 1002.6(b)(2)(ii)",
                        affected_nodes=[node.node_id],
                        remediation=(
                            "If age is used in a credit scoring model, "
                            "document the empirical derivation and ensure no "
                            "negative factor is assigned to applicants 62+."
                        ),
                    ))

                elif attr in ("public_assistance", "welfare"):
                    findings.append(ComplianceFinding(
                        severity=Severity.CRITICAL,
                        description=(
                            f"Public assistance status detected "
                            f"({node.table}.{node.column}). 15 U.S.C. "
                            f"1691(a)(2) prohibits discrimination against any "
                            f"applicant because all or part of the applicant's "
                            f"income derives from any public assistance "
                            f"program."
                        ),
                        regulation_citation="15 U.S.C. 1691(a)(2)",
                        affected_nodes=[node.node_id],
                        remediation=(
                            "Remove public assistance indicators from the "
                            "credit decision model entirely."
                        ),
                    ))

                elif attr in ("marital_status",):
                    findings.append(ComplianceFinding(
                        severity=Severity.WARNING,
                        description=(
                            f"Marital status detected "
                            f"({node.table}.{node.column}). Under "
                            f"12 CFR 1002.5(d)(1), a creditor may inquire "
                            f"about marital status only if the applicant "
                            f"resides in a community property state or is "
                            f"relying on property located in such a state as "
                            f"a basis for repayment."
                        ),
                        regulation_citation="12 CFR 1002.5(d)(1)",
                        affected_nodes=[node.node_id],
                        remediation=(
                            "Verify that marital status inquiry is permitted "
                            "under the community-property exception, or "
                            "remove it from the model."
                        ),
                    ))

        else:
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "No protected-class attributes detected in the "
                    "computation DAG source nodes."
                ),
                regulation_citation="12 CFR 1002.6(b)",
            ))

        return findings

    def _check_protected_influence(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """Measure how much of the DAG is downstream of protected sources."""
        findings: List[ComplianceFinding] = []

        influence_pct = self._calculate_protected_influence(dag)

        if influence_pct > 0:
            severity = (
                Severity.CRITICAL if influence_pct > 25
                else Severity.WARNING if influence_pct > 5
                else Severity.INFO
            )
            findings.append(ComplianceFinding(
                severity=severity,
                description=(
                    f"Protected data influences {influence_pct:.1f}% of the "
                    f"computation graph. Under 12 CFR 1002.4(a), a creditor "
                    f"shall not discriminate on a prohibited basis in any "
                    f"aspect of a credit transaction."
                ),
                regulation_citation="12 CFR 1002.4(a)",
                remediation=(
                    "Reduce or eliminate the influence of protected attributes "
                    "on the credit decision. Consider adversarial debiasing or "
                    "feature ablation."
                ),
            ))

        return findings

    def _check_disparate_impact(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """Verify that metadata supports disparate-impact testing."""
        findings: List[ComplianceFinding] = []

        if not meta.get("disparate_impact_analysis"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No disparate impact analysis results found. While ECOA "
                    "does not mandate a specific test, the CFPB and federal "
                    "bank regulators expect creditors to conduct periodic "
                    "fair-lending analyses. The four-fifths rule (80% rule) "
                    "is a common threshold."
                ),
                regulation_citation="12 CFR 1002.4(a)",
                remediation=(
                    "Conduct a disparate impact analysis comparing approval "
                    "rates across protected groups. Add results under "
                    "'disparate_impact_analysis' in metadata."
                ),
            ))
        else:
            dia = meta["disparate_impact_analysis"]
            if isinstance(dia, dict):
                for group, ratio in dia.items():
                    if isinstance(ratio, (int, float)) and ratio < 0.80:
                        findings.append(ComplianceFinding(
                            severity=Severity.CRITICAL,
                            description=(
                                f"Disparate impact detected for group "
                                f"'{group}': selection rate ratio is "
                                f"{ratio:.2%}, which is below the 80% "
                                f"threshold. This may constitute prima facie "
                                f"evidence of discrimination under ECOA."
                            ),
                            regulation_citation="12 CFR 1002.4(a)",
                            remediation=(
                                f"Investigate and mitigate the disparate "
                                f"impact on '{group}'. Consider model "
                                f"adjustments, alternative data sources, or "
                                f"compensating factors."
                            ),
                        ))

        return findings

    def _check_adverse_action(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """Check adverse-action notice requirements."""
        findings: List[ComplianceFinding] = []

        is_adverse = meta.get("is_adverse_action", False)

        if is_adverse:
            if not meta.get("adverse_action_reasons"):
                findings.append(ComplianceFinding(
                    severity=Severity.CRITICAL,
                    description=(
                        "Adverse action taken but no specific reasons "
                        "provided. 12 CFR 1002.9(a)(2) requires that a "
                        "creditor provide a statement of specific reasons for "
                        "the action taken. A creditor must provide the "
                        "applicant with a statement of reasons within 30 days "
                        "after taking adverse action."
                    ),
                    regulation_citation="12 CFR 1002.9(a)(2)",
                    remediation=(
                        "Generate specific adverse action reason codes. Use "
                        "HYDRA-24 DAG to trace which features most influenced "
                        "the adverse decision and map them to standardised "
                        "FFIEC adverse action codes."
                    ),
                ))
            else:
                reasons = meta["adverse_action_reasons"]
                if isinstance(reasons, list) and len(reasons) > 4:
                    findings.append(ComplianceFinding(
                        severity=Severity.WARNING,
                        description=(
                            f"{len(reasons)} adverse action reasons provided. "
                            f"While Regulation B does not cap the number, the "
                            f"OCC Model Form C-1 and industry practice limit "
                            f"reasons to the principal factors (typically up "
                            f"to 4) to avoid obscuring the real reasons."
                        ),
                        regulation_citation="12 CFR 1002.9(b)(2)",
                        remediation=(
                            "Limit adverse action reasons to the top 4 "
                            "principal factors that most influenced the "
                            "decision."
                        ),
                    ))
                # CFPB Circular 2023-03: validate reason specificity
                if isinstance(reasons, list):
                    findings.extend(self._check_reason_specificity(reasons))

            # 12 CFR 1002.9(a)(1): 30-day timeline enforcement
            notice_date = meta.get("adverse_action_notice_date")
            decision_date = meta.get("adverse_action_decision_date")

            if not notice_date:
                findings.append(ComplianceFinding(
                    severity=Severity.WARNING,
                    description=(
                        "No adverse action notice date recorded. Under "
                        "12 CFR 1002.9(a)(1), notification must be provided "
                        "within 30 days after taking adverse action."
                    ),
                    regulation_citation="12 CFR 1002.9(a)(1)",
                    remediation=(
                        "Record the date the adverse action notice is sent "
                        "under 'adverse_action_notice_date'."
                    ),
                ))
            elif decision_date:
                # Validate 30-day window when both dates are available
                try:
                    from datetime import datetime
                    notice_dt = datetime.fromisoformat(str(notice_date))
                    decision_dt = datetime.fromisoformat(str(decision_date))
                    delta_days = (notice_dt - decision_dt).days
                    if delta_days > 30:
                        findings.append(ComplianceFinding(
                            severity=Severity.CRITICAL,
                            description=(
                                f"Adverse action notice sent {delta_days} days "
                                f"after the decision, exceeding the 30-day "
                                f"limit. 12 CFR 1002.9(a)(1) requires "
                                f"notification within 30 days."
                            ),
                            regulation_citation="12 CFR 1002.9(a)(1)",
                            remediation=(
                                "Ensure adverse action notices are sent within "
                                "30 days of the adverse decision."
                            ),
                        ))
                    elif delta_days < 0:
                        findings.append(ComplianceFinding(
                            severity=Severity.WARNING,
                            description=(
                                "Adverse action notice date is before the "
                                "decision date; verify date accuracy."
                            ),
                            regulation_citation="12 CFR 1002.9(a)(1)",
                        ))
                except (ValueError, TypeError):
                    findings.append(ComplianceFinding(
                        severity=Severity.WARNING,
                        description=(
                            "Unable to parse adverse action dates for "
                            "30-day validation. Use ISO 8601 format "
                            "(YYYY-MM-DD)."
                        ),
                        regulation_citation="12 CFR 1002.9(a)(1)",
                    ))

        if not meta.get("adverse_action_code_mapping"):
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "No adverse-action-code-to-feature mapping found. "
                    "Maintaining a mapping between model features and FFIEC "
                    "adverse action reason codes supports 12 CFR 1002.9 "
                    "compliance and audit readiness."
                ),
                regulation_citation="12 CFR 1002.9(a)(2)",
                remediation=(
                    "Create a mapping from model features to FFIEC adverse "
                    "action reason codes and include it in metadata under "
                    "'adverse_action_code_mapping'."
                ),
            ))

        return findings

    @staticmethod
    def _check_reason_specificity(
        reasons: List,
    ) -> List[ComplianceFinding]:
        """Validate that adverse action reasons meet CFPB specificity requirements.

        CFPB Circular 2023-03 requires that reasons be specific enough for
        the applicant to understand and potentially correct.  Generic
        phrases like "model score" or "credit risk" are insufficient.
        """
        _GENERIC_TERMS = (
            "model score", "ai decision", "algorithm", "score too low",
            "risk score", "internal score", "system decision",
            "insufficient score", "credit risk",
        )
        findings: List[ComplianceFinding] = []
        generic_found: List[str] = []

        for reason in reasons:
            text = str(reason).lower().strip()
            if any(term in text for term in _GENERIC_TERMS):
                generic_found.append(str(reason))

        if generic_found:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    f"Adverse action reason(s) may lack required "
                    f"specificity: {', '.join(generic_found[:3])}. "
                    f"CFPB Circular 2023-03 requires reasons specific "
                    f"enough for the applicant to understand and "
                    f"potentially correct the deficiency."
                ),
                regulation_citation="12 CFR 1002.9(b)(2)",
                remediation=(
                    "Replace generic reasons with specific FFIEC codes "
                    "that describe the actual credit factors (e.g., "
                    "'Amount owed on accounts is too high' instead of "
                    "'credit risk')."
                ),
            ))

        return findings

    def _check_record_retention(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """12 CFR 1002.12(a): Record retention with date-based calculation.

        Creditors must retain records for 25 months after notifying the
        applicant of action taken, or 25 months after receipt of an
        application not acted upon.  Extended during investigations.
        """
        findings: List[ComplianceFinding] = []

        retention_months = meta.get("record_retention_months")

        if retention_months is None:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No record retention period specified. 12 CFR 1002.12(a) "
                    "requires that a creditor retain records for 25 months "
                    "after notifying the applicant of action taken, or 25 "
                    "months after the date of an application that was not "
                    "acted upon."
                ),
                regulation_citation="12 CFR 1002.12(a)",
                remediation=(
                    "Set record retention to at least 25 months. Include "
                    "'record_retention_months' in metadata."
                ),
            ))
        elif retention_months < 25:
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    f"Record retention period is {retention_months} months, "
                    f"which is below the 25-month minimum required by "
                    f"12 CFR 1002.12(a)."
                ),
                regulation_citation="12 CFR 1002.12(a)",
                remediation=(
                    "Increase record retention period to at least 25 months."
                ),
            ))

        # Investigation hold
        if meta.get("under_investigation", False):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "Records are subject to investigation or enforcement "
                    "action. Per 12 CFR 1002.12(a), retention is extended "
                    "until final disposition. Do not destroy records."
                ),
                regulation_citation="12 CFR 1002.12(a)",
                remediation=(
                    "Maintain all records until investigation closes and "
                    "final order is issued."
                ),
            ))

        return findings

    def _check_information_requests(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """Check compliance with rules on information requests."""
        findings: List[ComplianceFinding] = []

        collected_demographics = meta.get("collected_demographics", [])
        if isinstance(collected_demographics, list):
            for field_name in collected_demographics:
                is_match, attr = _column_is_protected(str(field_name))
                if is_match and attr not in ("age",):
                    is_hmda = meta.get("hmda_reportable", False)
                    if not is_hmda:
                        findings.append(ComplianceFinding(
                            severity=Severity.WARNING,
                            description=(
                                f"Demographic field '{field_name}' is being "
                                f"collected. 12 CFR 1002.5(b) generally "
                                f"prohibits inquiring about an applicant's "
                                f"race, color, religion, national origin, or "
                                f"sex. Exception: 12 CFR 1002.13 requires "
                                f"collection of monitoring information for "
                                f"HMDA-reportable applications."
                            ),
                            regulation_citation="12 CFR 1002.5(b)",
                            remediation=(
                                f"If this is a HMDA-reportable application, "
                                f"set 'hmda_reportable' to True in metadata. "
                                f"Otherwise, cease collecting '{field_name}'."
                            ),
                        ))

        return findings

    def _check_model_governance(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """Check SR 11-7 model governance requirements.

        OCC Bulletin 2011-12 / Fed SR 11-7 requires that models used in
        credit decisions have documented validation, ongoing monitoring,
        and change management.  OCC examiners check these during fair
        lending reviews of AI/ML credit models.
        """
        findings: List[ComplianceFinding] = []

        if not meta.get("model_validation_date"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No model validation date recorded. SR 11-7 requires "
                    "independent validation of models used in credit "
                    "decisions. Examiners will request evidence of "
                    "validation during fair lending examinations."
                ),
                regulation_citation="SR 11-7 / OCC 2011-12",
                remediation=(
                    "Conduct independent model validation and record the "
                    "date under 'model_validation_date' in metadata."
                ),
            ))

        if not meta.get("monitoring_plan"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No ongoing monitoring plan documented. SR 11-7 "
                    "requires continuous monitoring of model performance, "
                    "including fairness metrics, for models in production."
                ),
                regulation_citation="SR 11-7 / OCC 2011-12",
                remediation=(
                    "Document an ongoing monitoring plan that includes "
                    "performance metrics, fairness thresholds, and "
                    "escalation procedures. Include under 'monitoring_plan'."
                ),
            ))

        if not meta.get("model_owner"):
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "No model owner recorded. SR 11-7 requires clear "
                    "accountability for each model, including a designated "
                    "model owner responsible for performance and compliance."
                ),
                regulation_citation="SR 11-7 / OCC 2011-12",
                remediation=(
                    "Designate a model owner and record under 'model_owner'."
                ),
            ))

        return findings

    # -- new compliance checks (2025-2026 regulatory landscape) --------------

    def _check_intersectional_impact(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """12 CFR 1002.4(a): Intersectional disparate impact analysis.

        CFPB Supervisory Highlights (January 2025) require creditors to
        analyse combinations of protected characteristics (e.g. race x
        gender) to detect compound discrimination invisible to univariate
        analysis.
        """
        findings: List[ComplianceFinding] = []

        if not meta.get("intersectional_impact_analysis"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No intersectional disparate impact analysis found. "
                    "CFPB Supervisory Highlights (January 2025) and "
                    "12 CFR 1002.4(a) require analysis across combinations "
                    "of protected attributes (e.g. race x gender, age x "
                    "national origin) to detect compound discrimination "
                    "invisible to univariate analysis."
                ),
                regulation_citation="12 CFR 1002.4(a)",
                remediation=(
                    "Conduct intersectional disparate impact analysis on all "
                    "pairwise combinations of protected attributes. Add "
                    "results under 'intersectional_impact_analysis'."
                ),
            ))
        else:
            inter = meta["intersectional_impact_analysis"]
            if isinstance(inter, list):
                for result in inter:
                    if isinstance(result, dict):
                        pair = result.get("attribute_pair", [])
                        worst_ratio = result.get("worst_ratio", 1.0)
                        if isinstance(worst_ratio, (int, float)) and worst_ratio < 0.80:
                            findings.append(ComplianceFinding(
                                severity=Severity.CRITICAL,
                                description=(
                                    f"Intersectional disparate impact detected for "
                                    f"combination {pair}: selection rate ratio is "
                                    f"{worst_ratio:.2%}. This indicates compound "
                                    f"discrimination across multiple protected "
                                    f"characteristics under 12 CFR 1002.4(a)."
                                ),
                                regulation_citation="12 CFR 1002.4(a)",
                                remediation=(
                                    f"Investigate and mitigate the disparate impact "
                                    f"on combination {pair}. Document business "
                                    f"justification or model modifications."
                                ),
                            ))

        return findings

    def _check_adverse_action_completeness(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """12 CFR 1002.9(a)(2) / Appendix C: Validate adverse action notice fields.

        Per Appendix C (Sample Forms C-1 through C-4), adverse action
        notices must contain specific mandatory fields including creditor
        identity, ECOA rights statement, supervising agency, and specific
        reasons.
        """
        findings: List[ComplianceFinding] = []

        is_adverse = meta.get("is_adverse_action", False)
        if not is_adverse:
            return findings

        notice_data = meta.get("adverse_action_notice_data", {})
        if not notice_data:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "Adverse action taken but no notice template data found. "
                    "12 CFR 1002.9(a)(2) and Appendix C require notices "
                    "to contain creditor name/address, ECOA rights statement, "
                    "supervising agency name/address, and specific reasons."
                ),
                regulation_citation="12 CFR 1002.9(a)(2)",
                remediation=(
                    "Include 'adverse_action_notice_data' in metadata with "
                    "required fields: creditor_name, creditor_address, "
                    "ecoa_statement, agency_name, agency_address, "
                    "specific_reasons."
                ),
            ))
            return findings

        required_fields = {
            "creditor_name": "Name of creditor",
            "creditor_address": "Address of creditor",
            "ecoa_statement": "ECOA rights statement (15 U.S.C. 1691)",
            "agency_name": "Name of supervising Federal agency",
            "specific_reasons": "Statement of specific reasons",
        }

        missing = [
            label for key, label in required_fields.items()
            if not notice_data.get(key)
        ]
        if missing:
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    f"Adverse action notice missing required fields: "
                    f"{', '.join(missing)}. Per 12 CFR 1002.9(a)(2) and "
                    f"Appendix C, all fields are mandatory."
                ),
                regulation_citation="12 CFR 1002.9(a)(2)",
                remediation=(
                    "Ensure notice includes all required fields before "
                    "sending to applicant."
                ),
            ))

        return findings

    def _check_model_explainability(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """CFPB Circular 2023-03: No 'black-box' models for credit decisions.

        'ECOA and Regulation B do not permit creditors to use a black-box
        underwriting technology when doing so means that the creditor
        cannot provide specific and accurate reasons for an adverse action.'
        """
        findings: List[ComplianceFinding] = []

        explanation_method = meta.get("explanation_method", "")
        if not explanation_method:
            return findings

        if explanation_method in ("zeros", "none", "unknown"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    f"Model explanation method is '{explanation_method}' "
                    f"(no explainability). CFPB Circular 2023-03 prohibits "
                    f"use of black-box models for credit decisions when "
                    f"specific and accurate adverse action reasons cannot "
                    f"be provided."
                ),
                regulation_citation="CFPB Circular 2023-03",
                remediation=(
                    "Implement an explanation method (SHAP, LIME, feature "
                    "importance) before deploying this model for credit "
                    "decisions."
                ),
            ))

        explanation_confidence = meta.get("explanation_confidence", 1.0)
        if isinstance(explanation_confidence, (int, float)):
            if explanation_confidence < 0.85:
                findings.append(ComplianceFinding(
                    severity=Severity.WARNING,
                    description=(
                        f"Explanation fidelity is {explanation_confidence:.1%}, "
                        f"below recommended 85% threshold. CFPB guidance "
                        f"requires 'specific and accurate' reasons; "
                        f"low-fidelity explanations may not meet this "
                        f"standard."
                    ),
                    regulation_citation="CFPB Circular 2023-03",
                    remediation=(
                        "Improve explanation accuracy by retraining the "
                        "explanation method with a larger sample or "
                        "simplifying the model."
                    ),
                ))

        return findings

    def _check_hmda_monitoring(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """12 CFR 1002.13: HMDA monitoring information collection.

        HMDA-reportable applications must collect race, ethnicity, sex,
        marital status, and age.  Applicant must be informed of the
        Federal monitoring purpose.
        """
        findings: List[ComplianceFinding] = []

        if not meta.get("hmda_reportable", False):
            return findings

        collected = meta.get("collected_demographics", [])
        required_hmda = {"race", "ethnicity", "sex"}
        collected_lower = {str(c).lower() for c in collected} if collected else set()
        missing_hmda = required_hmda - collected_lower

        if missing_hmda:
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    f"HMDA-reportable application missing required "
                    f"demographic fields: {', '.join(sorted(missing_hmda))}. "
                    f"12 CFR 1002.13(a)(1) requires creditors to request "
                    f"race, ethnicity, and sex as part of the application."
                ),
                regulation_citation="12 CFR 1002.13(a)(1)",
                remediation=(
                    "Include all required HMDA demographic fields in the "
                    "application form."
                ),
            ))

        if not meta.get("monitoring_purpose_disclosed", False):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "Monitoring purpose not disclosed. 12 CFR 1002.13(a)(4) "
                    "requires informing applicants that demographic data "
                    "is requested by the Federal Government for monitoring "
                    "compliance with fair lending laws."
                ),
                regulation_citation="12 CFR 1002.13(a)(4)",
                remediation=(
                    "Include Federal monitoring disclosure on application."
                ),
            ))

        return findings

    def _check_sogi_protection(
        self, dag: ComputationDAG
    ) -> List[ComplianceFinding]:
        """CFPB 2021 Interpretive Rule: Sexual orientation / gender identity.

        ECOA prohibits discrimination based on sexual orientation and
        gender identity as part of sex discrimination.
        """
        findings: List[ComplianceFinding] = []

        sogi_keywords = {"sexual_orientation", "gender_identity", "lgbtq"}
        for node in dag.source_nodes:
            if not node.column:
                continue
            col_lower = node.column.lower()
            col_tokens = set(col_lower.replace(" ", "_").split("_"))
            for kw in sogi_keywords:
                kw_tokens = set(kw.split("_"))
                if kw_tokens.issubset(col_tokens) or kw in col_lower:
                    findings.append(ComplianceFinding(
                        severity=Severity.CRITICAL,
                        description=(
                            f"Sexual orientation or gender identity data "
                            f"detected ({node.table}.{node.column}). Per "
                            f"CFPB March 2021 Interpretive Rule, ECOA "
                            f"prohibits discrimination based on sexual "
                            f"orientation or gender identity. This data "
                            f"must not influence credit decisions."
                        ),
                        regulation_citation="12 CFR 1002.4(a) / CFPB 2021",
                        affected_nodes=[node.node_id],
                        remediation=(
                            "Remove SOGI data from the decision model. If "
                            "retained for monitoring, ensure complete "
                            "separation from the decision path."
                        ),
                    ))
                    break

        return findings

    # -- helpers -------------------------------------------------------------

    def _calculate_protected_influence(self, dag: ComputationDAG) -> float:
        """Calculate the percentage of DAG nodes influenced by protected sources.

        Walks forward from protected source nodes and counts how many
        downstream nodes are reachable.
        """
        if not dag.nodes:
            return 0.0

        protected_node_ids = {n.node_id for n in dag.protected_sources}

        if not protected_node_ids:
            for node in dag.source_nodes:
                if node.column:
                    is_match, _ = _column_is_protected(node.column)
                    if is_match:
                        protected_node_ids.add(node.node_id)

        if not protected_node_ids:
            return 0.0

        children_map: Dict[int, List[int]] = {}
        for edge in dag.edges:
            children_map.setdefault(edge.source_id, []).append(edge.target_id)

        influenced: Set[int] = set(protected_node_ids)
        bfs_queue = deque(protected_node_ids)
        while bfs_queue:
            nid = bfs_queue.popleft()
            for child in children_map.get(nid, []):
                if child not in influenced:
                    influenced.add(child)
                    bfs_queue.append(child)

        total_non_source = sum(
            1 for n in dag.nodes.values() if not n.is_source
        )
        if total_non_source == 0:
            return 0.0

        influenced_non_source = sum(
            1 for nid in influenced
            if nid in dag.nodes and not dag.nodes[nid].is_source
        )

        return (influenced_non_source / total_non_source) * 100.0
