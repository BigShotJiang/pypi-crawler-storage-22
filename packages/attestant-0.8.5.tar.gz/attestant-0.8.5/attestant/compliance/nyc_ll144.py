"""
NYC Local Law 144 (AEDT) Compliance Engine for HYDRA-24.

Implements checks against New York City Local Law 144 of 2021
(NYC Admin. Code § 20-870 et seq.), effective since July 5, 2023.

Key provisions:
    § 20-870   Definitions (automated employment decision tool)
    § 20-871   Requirements for use of AEDTs
    § 20-872   Bias audit requirements (independent, annual)
    § 20-873   Notice requirements (10 business days)
    § 20-874   Penalties ($500-$1,500 per violation per day)

The law applies to automated employment decision tools (AEDTs)
used in hiring or promotion decisions within New York City.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ..hydra24_dag import ComputationDAG
from .base import (
    BaseComplianceEngine,
    ComplianceFinding,
    ComplianceResult,
    Severity,
)


def _is_aedt(metadata: Dict[str, Any]) -> bool:
    """Determine if the system is an AEDT under NYC LL 144."""
    domain = (
        metadata.get("domain") or metadata.get("use_case") or ""
    ).lower().strip()
    return domain in (
        "hiring", "recruitment", "employment", "promotion",
        "employment_screening", "resume_screening",
    )


class NYCLL144Engine(BaseComplianceEngine):
    """Compliance engine for NYC Local Law 144 (AEDT).

    Checks:
    1. **AEDT classification** -- determines if the tool is an AEDT.
    2. **Bias audit** -- verifies independent audit within 12 months.
    3. **Audit summary publication** -- verifies public posting.
    4. **Candidate notice** -- verifies 10-business-day advance notice.
    5. **Selection rate disclosure** -- verifies impact ratio reporting.
    """

    @property
    def regulation_name(self) -> str:
        return "NYC Local Law 144 (AEDT)"

    def check(
        self,
        dag: ComputationDAG,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ComplianceResult:
        meta = metadata or {}
        findings: List[ComplianceFinding] = []
        citations: List[str] = []

        is_aedt = _is_aedt(meta)

        findings.extend(self._check_classification(is_aedt, meta))

        if is_aedt:
            findings.extend(self._check_bias_audit(meta))
            findings.extend(self._check_audit_summary_publication(meta))
            findings.extend(self._check_candidate_notice(meta))
            findings.extend(self._check_selection_rate_disclosure(meta))
            findings.extend(self._check_alternative_process(meta))

        for f in findings:
            if f.regulation_citation and f.regulation_citation not in citations:
                citations.append(f.regulation_citation)

        passed = all(f.severity != Severity.CRITICAL for f in findings)

        from .base import ComplianceReport
        remediation_recs = ComplianceReport._dedup_flat(
            [[f.remediation] for f in findings if f.remediation]
        )

        return ComplianceResult(
            passed=passed,
            regulation_name=self.regulation_name,
            findings=findings,
            citations=citations,
            remediation_recommendations=remediation_recs,
            metadata={
                "is_aedt": is_aedt,
                "domain": meta.get("domain", ""),
            },
        )

    # -- individual checks ---------------------------------------------------

    def _check_classification(
        self, is_aedt: bool, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        findings: List[ComplianceFinding] = []

        if is_aedt:
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    f"System classified as an Automated Employment "
                    f"Decision Tool (AEDT) under NYC Local Law 144 "
                    f"(domain: {meta.get('domain', 'unknown')}). All "
                    f"§ 20-871 through § 20-873 obligations apply."
                ),
                regulation_citation="NYC Admin. Code § 20-870",
            ))
        else:
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "System does not appear to be an AEDT under NYC "
                    "Local Law 144."
                ),
                regulation_citation="NYC Admin. Code § 20-870",
            ))

        return findings

    def _check_bias_audit(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """§ 20-871(a): Independent bias audit within 12 months."""
        findings: List[ComplianceFinding] = []

        if not meta.get("bias_audit_date"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No bias audit conducted. § 20-871(a) requires an "
                    "independent bias audit of the AEDT within one year "
                    "prior to use. The audit must be conducted by an "
                    "independent auditor."
                ),
                regulation_citation="NYC Admin. Code § 20-871(a)",
                remediation=(
                    "Engage an independent auditor to conduct a bias "
                    "audit. Record date under 'bias_audit_date'."
                ),
            ))
        else:
            try:
                from datetime import datetime, timezone
                audit_dt = datetime.fromisoformat(str(meta["bias_audit_date"]))
                if audit_dt.tzinfo is None:
                    audit_dt = audit_dt.replace(tzinfo=timezone.utc)
                days_old = (datetime.now(timezone.utc) - audit_dt).days
                if days_old > 365:
                    findings.append(ComplianceFinding(
                        severity=Severity.CRITICAL,
                        description=(
                            f"Bias audit is {days_old} days old, exceeding "
                            f"the 12-month maximum. § 20-871(a) requires a "
                            f"new audit within one year of use."
                        ),
                        regulation_citation="NYC Admin. Code § 20-871(a)",
                        remediation="Conduct a new independent bias audit.",
                    ))
            except (ValueError, TypeError):
                pass

        if not meta.get("bias_audit_independent_auditor"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No independent auditor identified. § 20-871(a) "
                    "requires the bias audit be conducted by an "
                    "independent auditor."
                ),
                regulation_citation="NYC Admin. Code § 20-871(a)",
                remediation=(
                    "Record auditor name/firm under "
                    "'bias_audit_independent_auditor'."
                ),
            ))

        return findings

    def _check_audit_summary_publication(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """§ 20-871(b): Public posting of audit summary."""
        findings: List[ComplianceFinding] = []

        if not meta.get("bias_audit_summary_published"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "Bias audit summary not published. § 20-871(b) "
                    "requires employers to make the summary of the "
                    "most recent bias audit publicly available on "
                    "their website before use of the AEDT."
                ),
                regulation_citation="NYC Admin. Code § 20-871(b)",
                remediation=(
                    "Publish bias audit summary on employer's website. "
                    "Summary must include: date, source/explanation of "
                    "data, selection/scoring rates by sex, race/ethnicity, "
                    "and intersectional categories, and impact ratios."
                ),
            ))

        if not meta.get("bias_audit_summary_url"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No URL for published bias audit summary. The summary "
                    "must be publicly accessible."
                ),
                regulation_citation="NYC Admin. Code § 20-871(b)",
                remediation=(
                    "Record the public URL under 'bias_audit_summary_url'."
                ),
            ))

        return findings

    def _check_candidate_notice(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """§ 20-871(c): 10-business-day advance notice to candidates."""
        findings: List[ComplianceFinding] = []

        if not meta.get("candidate_notice_provided"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No candidate notice documented. § 20-871(c) "
                    "requires employers to notify candidates at least "
                    "10 business days before use of an AEDT that: "
                    "(1) an AEDT will be used, (2) what job qualifications "
                    "and characteristics the AEDT will assess, and "
                    "(3) the candidate may request an alternative process."
                ),
                regulation_citation="NYC Admin. Code § 20-871(c)",
                remediation=(
                    "Provide candidates with notice at least 10 business "
                    "days before AEDT use. Record under "
                    "'candidate_notice_provided'."
                ),
            ))

        if not meta.get("candidate_data_retention_notice"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No data retention notice provided to candidates. "
                    "§ 20-871(c)(3) requires employers to inform "
                    "candidates about the data collected, its retention "
                    "period, and how to request deletion."
                ),
                regulation_citation="NYC Admin. Code § 20-871(c)(3)",
                remediation=(
                    "Include data retention and deletion information "
                    "in candidate notice."
                ),
            ))

        return findings

    def _check_selection_rate_disclosure(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """DCWP Rules § 5-301: Selection rate and impact ratio reporting."""
        findings: List[ComplianceFinding] = []

        audit_results = meta.get("bias_audit_results", {})
        if not audit_results:
            return findings

        required_categories = {"sex", "race_ethnicity"}
        reported = set()
        if isinstance(audit_results, dict):
            reported = set(audit_results.keys())

        missing = required_categories - reported
        if missing:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    f"Bias audit missing required categories: "
                    f"{', '.join(sorted(missing))}. DCWP Rules require "
                    f"impact ratios for sex and race/ethnicity at minimum."
                ),
                regulation_citation="DCWP Rules § 5-301",
                remediation=(
                    "Include selection rates and impact ratios for all "
                    "required categories in bias audit results."
                ),
            ))

        # Check for intersectional reporting
        if not meta.get("bias_audit_intersectional"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No intersectional bias audit results. DCWP Rules "
                    "require intersectional analysis (e.g. race x sex) "
                    "in addition to individual categories."
                ),
                regulation_citation="DCWP Rules § 5-301",
                remediation=(
                    "Include intersectional impact ratios in bias audit."
                ),
            ))

        return findings

    def _check_alternative_process(
        self, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """§ 20-871(c)(2): Alternative selection process."""
        findings: List[ComplianceFinding] = []

        if not meta.get("alternative_process_available"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No alternative selection process documented. "
                    "§ 20-871(c)(2) requires informing candidates that "
                    "they may request an alternative selection process "
                    "or accommodation."
                ),
                regulation_citation="NYC Admin. Code § 20-871(c)(2)",
                remediation=(
                    "Document the alternative selection process and "
                    "ensure candidates are informed of their right to "
                    "request it."
                ),
            ))

        return findings
