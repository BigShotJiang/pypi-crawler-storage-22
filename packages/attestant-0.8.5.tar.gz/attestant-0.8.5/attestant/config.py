"""
Global configuration system for Attestant.

Provides a simple API for users to configure provenance tracking
without needing to understand the different tracker classes.

Usage:
    import attestant

    # Just set your API key — everything else is automatic
    attestant.configure(api_key="pvt_live_...")

    # Or set ATTESTANT_API_KEY env var and just call:
    attestant.configure()

    # Wrap your data
    df = attestant.wrap(raw_df, "source.csv")
    result = df['a'] + df['b']

    # Get DAG — all provenance is persisted automatically
    dag = attestant.get_dag_simple(result)
"""

from typing import Optional, Dict, Any
from dataclasses import dataclass, field
import pandas as pd


@dataclass
class Config:
    """Global configuration for Attestant."""

    # Core settings
    dag: bool = True  # Enable DAG tracking (default: True)
    pipeline_name: Optional[str] = None  # Pipeline name for auditing

    # Customer identification (REQUIRED for hosted service)
    api_key: Optional[str] = None  # Customer API key (get from dashboard)
    tenant_id: Optional[str] = None  # Tenant ID (auto-derived from API key)

    # Service configuration
    service_url: str = ""  # Hosted service URL (set via ATTESTANT_SERVICE_URL env var)

    # Performance settings
    async_writes: bool = True  # Use async writer (default: True)
    batch_size: int = 100  # Nodes per batch write
    flush_interval: float = 1.0  # Seconds between auto-flush

    # Advanced settings
    cache_dags: bool = True  # Cache reconstructed DAGs
    auto_flush_on_exit: bool = True  # Flush when Python exits

    # Internal state
    _tracker: Any = None  # Active tracker instance
    _initialized: bool = False


# Global configuration instance
_config = Config()


def configure(
    api_key: Optional[str] = None,
    dag: bool = True,
    pipeline_name: Optional[str] = None,
    async_writes: bool = True,
    batch_size: int = 100,
    flush_interval: float = 1.0,
) -> None:
    """
    Configure Attestant provenance tracking.

    Call this at the top of your script to set up tracking.

    Args:
        api_key: Your Attestant API key. If omitted, reads from the
            ``ATTESTANT_API_KEY`` environment variable (recommended for
            notebooks, Databricks, SageMaker, and CI environments).
        dag: Enable full DAG tracking (default: True)
        pipeline_name: Name for this pipeline execution
        async_writes: Use background writer thread (default: True)
        batch_size: Nodes per batch write (default: 100)
        flush_interval: Seconds between auto-flush (default: 1.0)

    Example:
        import attestant

        # Option 1: pass key directly
        attestant.configure(api_key="hyd_live_1234567890abcdef")

        # Option 2: set ATTESTANT_API_KEY env var, then just:
        attestant.configure()

        # Use simple API - everything persists automatically
        df = attestant.wrap(data, "source.csv")
        result = df['a'] + df['b']
        dag = attestant.get_dag_simple(result)
        attestant.flush()  # Ensure persisted before exit
    """
    import os
    global _config

    if not api_key:
        api_key = os.environ.get("ATTESTANT_API_KEY")

    if not api_key:
        raise ValueError(
            "API key required. Pass it directly or set ATTESTANT_API_KEY.\n\n"
            "  attestant.configure(api_key='pvt_live_...')\n\n"
            "Get yours at https://attestant.ai/signup"
        )

    _config.dag = dag
    _config.pipeline_name = pipeline_name
    _config.api_key = api_key
    _config.async_writes = async_writes
    _config.batch_size = batch_size
    _config.flush_interval = flush_interval
    _config.service_url = os.environ.get("ATTESTANT_SERVICE_URL", "https://api.attestant.ai")
    _config._initialized = True

    # Validate API key and get tenant ID
    _config.tenant_id = _validate_api_key(api_key, _config.service_url)

    # Create tracker with configuration
    _initialize_tracker()

    # Register atexit handler so data is auto-flushed on program exit
    import atexit
    atexit.register(_atexit_flush)


def _validate_api_key(api_key: str, service_url: str) -> str:
    """
    Validate API key with hosted service.

    Args:
        api_key: Customer API key
        service_url: Hosted service URL

    Returns:
        Tenant ID for this customer

    Raises:
        ValueError: If API key is invalid
    """
    import json as _json
    import os
    from urllib.request import Request, urlopen
    from urllib.error import URLError, HTTPError

    # Allow override for testing only - not for production use.
    # Prefer new ATTESTANT_* env vars; fall back to legacy HYDRA24_* names.
    skip_auth = os.environ.get('ATTESTANT_SKIP_AUTH') or os.environ.get('HYDRA24_SKIP_AUTH')
    testing = os.environ.get('ATTESTANT_TESTING') or os.environ.get('HYDRA24_TESTING')
    if skip_auth and testing:
        import warnings
        warnings.warn("ATTESTANT_SKIP_AUTH is enabled - do not use in production", stacklevel=2)
        return api_key[:8]  # Use first 8 chars as tenant ID

    url = f"{service_url}/api/v1/auth/validate"
    req = Request(
        url,
        method="POST",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
    )

    try:
        with urlopen(req, timeout=5.0) as resp:
            data = _json.loads(resp.read().decode("utf-8"))
            tenant_id = data.get('tenant_id')
            if not tenant_id:
                raise ValueError("Invalid API key response")
            return tenant_id
    except HTTPError as exc:
        if exc.code == 401:
            raise ValueError(
                "Invalid API key. Get your key at https://attestant.ai/dashboard"
            )
        raise ValueError(f"API key validation failed: HTTP {exc.code}")
    except URLError as exc:
        if "timed out" in str(exc.reason).lower():
            raise ValueError("API key validation timeout - check your connection")
        raise ValueError(f"API key validation failed: {exc.reason}")


def _initialize_tracker() -> None:
    """Initialize the global tracker based on configuration."""
    global _config

    if _config.dag:
        # Use DAGTracker with hosted persistence
        from .hydra24_dag import DAGTracker

        _config._tracker = DAGTracker(
            api_key=_config.api_key,
            tenant_id=_config.tenant_id,
            service_url=_config.service_url,
            pipeline_name=_config.pipeline_name
        )
    else:
        # Use lightweight ProvenanceTracker (still persists to hosted service)
        from .hydra24_simple import ProvenanceTracker

        _config._tracker = ProvenanceTracker()

        # Note: Non-DAG mode still gets persistence via the hosted API
        # But without full DAG reconstruction capability


def _atexit_flush():
    """Auto-flush pending writes when the program exits."""
    global _config
    if _config._initialized and _config._tracker is not None:
        try:
            if hasattr(_config._tracker, 'flush'):
                _config._tracker.flush(timeout=10.0)
        except Exception:
            pass


def _auto_configure():
    """Auto-configure from ATTESTANT_API_KEY env var if not yet initialized."""
    import os
    api_key = os.environ.get("ATTESTANT_API_KEY")
    if api_key:
        configure(api_key=api_key)
        return True
    return False


def get_tracker():
    """
    Get the active tracker instance.

    Auto-configures from ATTESTANT_API_KEY env var if not yet initialized.
    """
    global _config

    if not _config._initialized:
        if not _auto_configure():
            raise RuntimeError(
                "Attestant not configured. Call attestant.configure(api_key='...') first,\n"
                "or set the ATTESTANT_API_KEY environment variable.\n"
                "Get your API key at https://attestant.ai/signup"
            )

    return _config._tracker


def wrap(dataframe: pd.DataFrame, source_name: str, protected: bool = False):
    """
    Wrap a DataFrame with provenance tracking.

    Simplified API that uses the global configuration.

    Args:
        dataframe: Pandas DataFrame to wrap
        source_name: Name of data source (e.g., "users.csv")
        protected: Whether this contains protected/sensitive data

    Returns:
        Tracked DataFrame

    Example:
        import attestant
        attestant.configure(dag=True)

        df = attestant.wrap(raw_df, "users.csv", protected=False)
        result = df['age'] + 10
        dag = attestant.get_dag(result)
    """
    tracker = get_tracker()

    if _config.dag:
        from .hydra24_dag import wrap_dataframe_dag
        return wrap_dataframe_dag(dataframe, tracker, source_name, protected=protected)
    else:
        from .hydra24_simple import wrap_dataframe
        return wrap_dataframe(dataframe, tracker, source_name, protected=protected)


def get_dag(series_or_value):
    """
    Get the computation DAG for a result.

    Args:
        series_or_value: Series or value with provenance

    Returns:
        ComputationDAG if dag=True, otherwise None

    Example:
        import attestant
        attestant.configure(dag=True)

        df = attestant.wrap(data, "source.csv")
        result = df['a'] + df['b']

        dag = attestant.get_dag(result)
        print(dag.depth)
        print(dag.has_protected)
    """
    if not _config.dag:
        import warnings
        warnings.warn("DAG tracking not enabled. Call configure(dag=True)", UserWarning)
        return None

    tracker = get_tracker()

    # Import here to avoid circular dependency
    from .hydra24_dag import get_dag_for_series

    return get_dag_for_series(series_or_value)


def audit(series_or_value) -> Dict[str, Any]:
    """
    Get provenance audit information.

    Works with both DAG and non-DAG modes.

    Args:
        series_or_value: Series or value with provenance

    Returns:
        Dictionary with provenance info

    Example:
        import attestant

        df = attestant.wrap(data, "source.csv")
        result = df['a'] + df['b']

        info = attestant.audit(result)
        print(info['pairs'])  # Source columns
        print(info['has_protected'])  # Protected data used?
    """
    if _config.dag:
        from .hydra24_dag import dag_audit
        return dag_audit(series_or_value, get_tracker())
    else:
        from .hydra24_simple import audit
        return audit(series_or_value)


def flush(timeout: float = 30.0) -> bool:
    """
    Flush all pending writes to database.

    Only needed if persistence is enabled.

    Args:
        timeout: Max seconds to wait

    Returns:
        True if successful, False if timeout

    Example:
        import attestant
        attestant.configure(persist_to="postgresql://...")

        # ... run pipeline ...

        # Ensure everything is written
        attestant.flush()
    """
    tracker = get_tracker()

    if hasattr(tracker, 'flush'):
        return tracker.flush(timeout=timeout)

    return True


def reset() -> None:
    """
    Reset global configuration and tracker.

    Useful for testing or starting a new pipeline.
    """
    global _config

    # Flush and cleanup existing tracker
    if _config._tracker is not None:
        if hasattr(_config._tracker, 'disable_persistence'):
            _config._tracker.disable_persistence()

    # Reset to defaults
    _config = Config()


def get_stats() -> Optional[Dict[str, Any]]:
    """
    Get persistence statistics.

    Returns:
        Dictionary with stats, or None if persistence not enabled

    Example:
        stats = attestant.get_stats()
        if stats:
            print(f"Nodes written: {stats['nodes_written']}")
            print(f"Edges written: {stats['edges_written']}")
    """
    tracker = get_tracker()

    if hasattr(tracker, 'get_persistence_stats'):
        return tracker.get_persistence_stats()

    return None


# Context manager for automatic cleanup
class ProvenanceContext:
    """
    Context manager for provenance tracking with automatic cleanup.

    Example:
        import attestant

        with attestant.tracking(persist_to="postgresql://..."):
            df = attestant.wrap(data, "source.csv")
            result = df['a'] + df['b']
            dag = attestant.get_dag(result)

        # Automatically flushes and cleans up
    """

    def __init__(self, **config_kwargs):
        self.config_kwargs = config_kwargs
        self.previous_config = None

    def __enter__(self):
        global _config
        self.previous_config = Config(**_config.__dict__)
        configure(**self.config_kwargs)
        return get_tracker()

    def __exit__(self, exc_type, exc_val, exc_tb):
        global _config

        # Flush before cleanup
        flush()

        # Restore previous config
        if self.previous_config:
            _config = self.previous_config
            _initialize_tracker()

        return False


def tracking(**config_kwargs):
    """
    Context manager for provenance tracking.

    Example:
        import attestant

        with attestant.tracking(dag=True, persist_to="postgresql://..."):
            df = attestant.wrap(data, "source.csv")
            result = df['a'] + df['b']

        # Auto-flushes on exit
    """
    return ProvenanceContext(**config_kwargs)
