"""
HYDRA-24 Demo Suite - Investor Demonstration Environment

A polished, interactive showcase of HYDRA-24's capabilities designed for
investor presentations and customer demonstrations.

Components:
- Use Case Scenarios: Credit scoring (ECOA fairness detection)
- Performance Dashboard: Real benchmarks proving production-readiness
- Business Impact Metrics: Dollar cost savings and ROI calculations
"""

__version__ = "1.0.0"
