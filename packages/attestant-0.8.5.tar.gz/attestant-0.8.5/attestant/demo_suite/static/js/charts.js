/**
 * HYDRA-24 Demo Suite - Chart Rendering
 *
 * Performance dashboard chart rendering using Chart.js
 */

// Chart.js configuration and utilities will go here
// Used by performance.html template
