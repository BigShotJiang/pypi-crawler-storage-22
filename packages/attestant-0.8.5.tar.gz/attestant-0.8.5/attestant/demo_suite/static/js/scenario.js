/**
 * HYDRA-24 Demo Suite - Scenario Interaction Logic
 *
 * Handles running demos, displaying results, and rendering DAGs.
 */

document.addEventListener('DOMContentLoaded', function() {
    // Only run on scenario pages
    if (typeof window.SCENARIO === 'undefined') {
        return;
    }

    const scenario = window.SCENARIO;

    // Get DOM elements
    const btnWithoutHydra = document.getElementById('run-without-hydra');
    const btnWithHydra = document.getElementById('run-with-hydra');
    const loadingState = document.getElementById('loading-state');
    const loadingMessage = document.getElementById('loading-message');
    const resultsView = document.getElementById('results-view');

    // Attach event listeners
    if (btnWithoutHydra) {
        btnWithoutHydra.addEventListener('click', () => runDemo(false));
    }

    if (btnWithHydra) {
        btnWithHydra.addEventListener('click', () => runDemo(true));
    }

    /**
     * Run demo scenario
     */
    async function runDemo(useHydra) {
        // Show loading state
        loadingState.style.display = 'flex';
        resultsView.style.display = 'none';
        loadingMessage.textContent = useHydra ? 'Running with HYDRA-24...' : 'Running without HYDRA-24...';

        try {
            // Convert underscores to hyphens for API URL
            const apiScenario = scenario.replace(/_/g, '-');
            const response = await fetch(`/api/demo/${apiScenario}/run?hydra=${useHydra}`);
            const data = await response.json();

            if (data.status === 'error') {
                showError(data.message || 'Demo execution failed');
                return;
            }

            // Hide loading, show results
            loadingState.style.display = 'none';
            resultsView.style.display = 'block';

            // Render results
            renderResults(data);

        } catch (error) {
            console.error('Demo error:', error);
            showError('Failed to run demo. Please try again.');
        }
    }

    /**
     * Render demo results
     */
    function renderResults(data) {
        // Update header
        document.getElementById('results-title').textContent =
            data.mode === 'with_hydra' ? 'Results: With HYDRA-24' : 'Results: Without HYDRA-24';

        const modeBadge = document.getElementById('mode-badge');
        modeBadge.textContent = data.mode === 'with_hydra' ? 'HYDRA-24 Enabled' : 'Traditional Pipeline';
        modeBadge.className = 'badge ' + (data.mode === 'with_hydra' ? 'info' : 'warning');

        const statusBadge = document.getElementById('status-badge');
        statusBadge.textContent = data.production_ready ? 'Production Ready' : 'Blocked';
        statusBadge.className = 'badge ' + (data.production_ready ? 'success' : 'error');

        // Render metrics
        renderMetrics(data);

        // Render compliance findings (if present)
        if (data.compliance_findings && data.compliance_findings.length > 0) {
            renderComplianceFindings(data.compliance_findings);
        } else {
            document.getElementById('compliance-findings').style.display = 'none';
        }

        // Render DAG (if present)
        if (data.dag) {
            renderDAG(data.dag);
        } else {
            document.getElementById('dag-visualization').style.display = 'none';
        }

        // Render business impact (if present)
        if (data.business_impact) {
            renderBusinessImpact(data.business_impact);
        } else {
            document.getElementById('business-impact').style.display = 'none';
        }

        // Update quick stats
        renderQuickStats(data);

        // Show export section
        document.getElementById('export-section').style.display = 'block';

        // Setup export button
        document.getElementById('export-json').onclick = () => {
            downloadJSON(data, `${scenario}-results.json`);
        };
    }

    /**
     * Render key metrics - SAFE: Uses DOM methods, not innerHTML
     */
    function renderMetrics(data) {
        const metricsDisplay = document.getElementById('metrics-display');
        metricsDisplay.innerHTML = ''; // Clear previous

        const grid = document.createElement('div');
        grid.className = 'metrics-grid';

        // Add scenario-specific metrics
        if (data.accuracy !== undefined) {
            grid.appendChild(createMetricRow('Model Accuracy', (data.accuracy * 100).toFixed(1) + '%'));
        }
        if (data.auc_score !== undefined) {
            grid.appendChild(createMetricRow('AUC Score', data.auc_score.toFixed(3)));
        }
        if (data.execution_time !== undefined) {
            grid.appendChild(createMetricRow('Execution Time', data.execution_time.toFixed(2) + 's'));
        }
        if (data.model_deployed !== undefined) {
            grid.appendChild(createMetricRow('Deployment Status', data.model_deployed ? '✓ Deployed' : '✗ Blocked'));
        }
        if (data.compliance_check_performed !== undefined) {
            grid.appendChild(createMetricRow('Compliance Check', data.compliance_check_performed ? '✓ Performed' : '✗ Not performed'));
        }

        metricsDisplay.appendChild(grid);
    }

    function createMetricRow(label, value) {
        const row = document.createElement('div');
        row.className = 'metric-row';

        const labelSpan = document.createElement('span');
        labelSpan.className = 'metric-label';
        labelSpan.textContent = label;

        const valueSpan = document.createElement('span');
        valueSpan.className = 'metric-value';
        valueSpan.textContent = value;

        row.appendChild(labelSpan);
        row.appendChild(valueSpan);

        return row;
    }

    /**
     * Render compliance findings - SAFE: Uses DOM methods
     */
    function renderComplianceFindings(findings) {
        const findingsSection = document.getElementById('compliance-findings');
        const findingsList = document.getElementById('findings-list');
        findingsList.innerHTML = ''; // Clear previous

        findings.forEach(finding => {
            const severity = (finding.severity || 'INFO').toLowerCase();

            const card = document.createElement('div');
            card.className = `finding-card severity-${severity}`;

            const title = document.createElement('div');
            title.className = 'finding-title';
            title.textContent = `[${finding.severity}] ${finding.title}`;
            card.appendChild(title);

            const desc = document.createElement('div');
            desc.className = 'finding-description';
            desc.textContent = finding.description;
            card.appendChild(desc);

            if (finding.recommendation) {
                const rec = document.createElement('div');
                rec.className = 'finding-description';
                const strong = document.createElement('strong');
                strong.textContent = 'Recommendation: ';
                rec.appendChild(strong);
                rec.appendChild(document.createTextNode(finding.recommendation));
                card.appendChild(rec);
            }

            if (finding.citation) {
                const cite = document.createElement('div');
                cite.className = 'finding-citation';
                cite.textContent = finding.citation;
                card.appendChild(cite);
            }

            findingsList.appendChild(card);
        });

        findingsSection.style.display = 'block';
    }

    /**
     * Render DAG visualization using D3.js
     */
    function renderDAG(dag) {
        const dagSection = document.getElementById('dag-visualization');
        const svg = d3.select('#dag-svg');
        svg.selectAll('*').remove(); // Clear previous

        const width = svg.node().getBoundingClientRect().width || 800;
        const height = 500;

        // Set SVG dimensions
        svg.attr('height', height);

        const nodes = JSON.parse(JSON.stringify(dag.nodes)); // Deep copy

        // Transform edges from {from, to} to {source, target} for D3
        const edges = dag.edges.map(e => ({
            source: e.from,
            target: e.to,
            type: e.type
        }));

        // Create force simulation with better parameters
        const simulation = d3.forceSimulation(nodes)
            .force('link', d3.forceLink(edges).id(d => d.id).distance(150))
            .force('charge', d3.forceManyBody().strength(-500))
            .force('center', d3.forceCenter(width / 2, height / 2))
            .force('collision', d3.forceCollide().radius(50));

        // Add arrow markers for edges
        svg.append('defs').selectAll('marker')
            .data(['arrow', 'arrow-contamination', 'arrow-correlation'])
            .enter().append('marker')
            .attr('id', d => d)
            .attr('viewBox', '0 -5 10 10')
            .attr('refX', 30)
            .attr('refY', 0)
            .attr('markerWidth', 6)
            .attr('markerHeight', 6)
            .attr('orient', 'auto')
            .append('path')
            .attr('d', 'M0,-5L10,0L0,5')
            .attr('fill', d => {
                if (d === 'arrow-contamination') return '#ef4444';
                if (d === 'arrow-correlation') return '#fbbf24';
                return '#6b7280';
            });

        // Draw edges with arrows
        const link = svg.append('g')
            .selectAll('line')
            .data(edges)
            .enter().append('line')
            .attr('stroke', d => {
                if (d.type === 'contamination') return '#ef4444';
                if (d.type === 'correlation') return '#fbbf24';
                if (d.type === 'indirect') return '#9ca3af';
                return '#6b7280';
            })
            .attr('stroke-width', d => d.type === 'contamination' ? 3 : 2)
            .attr('stroke-dasharray', d => d.type === 'indirect' ? '5,5' : 'none')
            .attr('opacity', 0.7)
            .attr('marker-end', d => {
                if (d.type === 'contamination') return 'url(#arrow-contamination)';
                if (d.type === 'correlation') return 'url(#arrow-correlation)';
                return 'url(#arrow)';
            });

        // Draw node groups
        const node = svg.append('g')
            .selectAll('g')
            .data(nodes)
            .enter().append('g')
            .attr('class', 'node')
            .style('cursor', 'pointer')
            .call(d3.drag()
                .on('start', dragstarted)
                .on('drag', dragged)
                .on('end', dragended));

        // Node circles with glow effect for special nodes
        node.append('circle')
            .attr('r', d => {
                if (d.type === 'prediction') return 25;
                if (d.protected || d.phi || d.contaminated) return 22;
                return 20;
            })
            .attr('fill', d => {
                if (d.protected || d.phi) return '#fbbf24';
                if (d.contaminated) return '#ef4444';
                if (d.correlated_with_protected) return '#f59e0b';
                if (d.type === 'source') return '#3b82f6';
                if (d.type === 'prediction') return '#10b981';
                if (d.type === 'anchor') return '#8b5cf6';
                return '#6b7280';
            })
            .attr('stroke', d => {
                if (d.protected || d.phi || d.contaminated) return '#fbbf24';
                return '#fff';
            })
            .attr('stroke-width', d => {
                if (d.protected || d.phi || d.contaminated) return 3;
                return 2;
            })
            .style('filter', d => {
                if (d.protected || d.phi || d.contaminated) return 'drop-shadow(0 0 8px rgba(251, 191, 36, 0.6))';
                return 'none';
            });

        // Node labels
        node.append('text')
            .text(d => d.label)
            .attr('x', 30)
            .attr('y', 5)
            .attr('font-size', '13px')
            .attr('font-weight', d => (d.protected || d.phi || d.contaminated) ? 'bold' : 'normal')
            .attr('fill', '#e2e8f0');

        // Add badges for special nodes
        node.filter(d => d.protected || d.phi)
            .append('text')
            .text('⚠️')
            .attr('x', -8)
            .attr('y', -18)
            .attr('font-size', '16px');

        // Tooltips on hover
        node.append('title')
            .text(d => {
                let text = d.label;
                if (d.type) text += `\nType: ${d.type}`;
                if (d.protected) text += '\n⚠️ Protected Data';
                if (d.phi) text += '\n⚠️ PHI';
                if (d.contaminated) text += '\n⚠️ Contaminated';
                if (d.correlated_with_protected) text += '\n⚠️ Correlated with Protected';
                if (d.hash) text += `\nHash: ${d.hash.substring(0, 8)}...`;
                return text;
            });

        // Update positions on simulation tick
        simulation.on('tick', () => {
            link
                .attr('x1', d => d.source.x)
                .attr('y1', d => d.source.y)
                .attr('x2', d => d.target.x)
                .attr('y2', d => d.target.y);

            node.attr('transform', d => `translate(${d.x},${d.y})`);
        });

        // Drag functions
        function dragstarted(event, d) {
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }

        function dragged(event, d) {
            d.fx = event.x;
            d.fy = event.y;
        }

        function dragended(event, d) {
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }

        // Add legend
        const legend = svg.append('g')
            .attr('transform', `translate(20, ${height - 120})`);

        const legendItems = [
            { label: 'Source Data', color: '#3b82f6' },
            { label: 'Protected/PHI', color: '#fbbf24' },
            { label: 'Contaminated', color: '#ef4444' },
            { label: 'Prediction', color: '#10b981' }
        ];

        legendItems.forEach((item, i) => {
            const g = legend.append('g')
                .attr('transform', `translate(0, ${i * 25})`);

            g.append('circle')
                .attr('r', 8)
                .attr('fill', item.color);

            g.append('text')
                .attr('x', 15)
                .attr('y', 5)
                .attr('font-size', '12px')
                .attr('fill', '#e2e8f0')
                .text(item.label);
        });

        dagSection.style.display = 'block';
    }

    /**
     * Render business impact metrics - SAFE: Uses DOM methods
     */
    function renderBusinessImpact(impact) {
        const impactSection = document.getElementById('business-impact');
        const impactMetrics = document.getElementById('impact-metrics');
        impactMetrics.innerHTML = ''; // Clear previous

        if (impact.estimated_fine_avoided) {
            const card = createImpactCard(
                '$' + formatNumber(impact.estimated_fine_avoided),
                'Regulatory Fine Avoided'
            );
            impactMetrics.appendChild(card);
        }

        if (impact.cost_savings) {
            const card = createImpactCard(
                '$' + formatNumber(impact.cost_savings),
                'Audit Cost Savings'
            );
            impactMetrics.appendChild(card);
        }

        if (impact.time_savings_percent) {
            const card = createImpactCard(
                impact.time_savings_percent + '%',
                'Time Savings'
            );
            impactMetrics.appendChild(card);
        }

        impactSection.style.display = 'block';
    }

    function createImpactCard(amount, label) {
        const card = document.createElement('div');
        card.className = 'impact-card';

        const amountDiv = document.createElement('div');
        amountDiv.className = 'impact-amount';
        amountDiv.textContent = amount;

        const labelDiv = document.createElement('div');
        labelDiv.className = 'impact-label';
        labelDiv.textContent = label;

        card.appendChild(amountDiv);
        card.appendChild(labelDiv);

        return card;
    }

    /**
     * Render quick stats in sidebar - SAFE: Uses DOM methods
     */
    function renderQuickStats(data) {
        const quickStats = document.getElementById('quick-stats');
        quickStats.innerHTML = ''; // Clear previous

        if (data.total_applicants) {
            quickStats.appendChild(createMetricRow('Applicants', formatNumber(data.total_applicants)));
        }
        if (data.total_patients) {
            quickStats.appendChild(createMetricRow('Patients', formatNumber(data.total_patients)));
        }
        if (data.total_transactions) {
            quickStats.appendChild(createMetricRow('Transactions', formatNumber(data.total_transactions)));
        }
    }

    /**
     * Show error message
     */
    function showError(message) {
        loadingState.style.display = 'none';
        resultsView.style.display = 'block';
        document.getElementById('results-title').textContent = 'Error';
        document.getElementById('mode-badge').textContent = 'Failed';
        document.getElementById('mode-badge').className = 'badge error';

        const metricsDisplay = document.getElementById('metrics-display');
        metricsDisplay.innerHTML = '';

        const errorDiv = document.createElement('div');
        errorDiv.style.padding = '20px';
        errorDiv.style.textAlign = 'center';
        errorDiv.style.color = '#ef4444';
        errorDiv.textContent = message;

        metricsDisplay.appendChild(errorDiv);
    }

    /**
     * Download data as JSON
     */
    function downloadJSON(data, filename) {
        const json = JSON.stringify(data, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
    }

    /**
     * Format numbers with commas
     */
    function formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }
});
