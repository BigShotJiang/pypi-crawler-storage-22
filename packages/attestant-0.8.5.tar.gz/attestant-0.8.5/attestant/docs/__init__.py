"""
AutoDoc: Automated Model & Pipeline Documentation.

Generates compliance documentation from DAGs and model metadata.
Supports SR 11-7, EU AI Act Article 11, Model Cards, ECOA Fair
Lending Methodology, GDPR, and NIST AI RMF templates.

Usage:
    from attestant.docs import AutoDocEngine, TemplateType

    engine = AutoDocEngine()
    report = engine.generate(
        dag=my_dag,
        template=TemplateType.SR_11_7,
        model_metadata=metadata,
    )
    report.save("model_validation_report.md")
"""

from .engine import (
    AutoDocEngine,
    DocumentReport,
    DocumentSection,
    ModelMetadata,
    PipelineMetadata,
    TemplateType,
)
from .templates import (
    BaseTemplate,
    SR117Template,
    EUAIActTemplate,
    ModelCardTemplate,
    ECOATemplate,
    DbtDocTemplate,
    GDPRTemplate,
    NISTAIRMFTemplate,
)
from .gap_analysis import GapAnalyzer, GapReport, Gap

__version__ = "0.1.0"

__all__ = [
    "AutoDocEngine",
    "DocumentReport",
    "DocumentSection",
    "ModelMetadata",
    "PipelineMetadata",
    "TemplateType",
    "BaseTemplate",
    "SR117Template",
    "EUAIActTemplate",
    "ModelCardTemplate",
    "ECOATemplate",
    "DbtDocTemplate",
    "GDPRTemplate",
    "NISTAIRMFTemplate",
    "GapAnalyzer",
    "GapReport",
    "Gap",
]
