"""Allow running as ``python -m attestant.docs``."""

from attestant.docs.cli import main

main()
