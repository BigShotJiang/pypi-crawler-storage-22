"""
Attestant Docs CLI: generate documentation from the command line.

Usage:
    proveit docs generate --template sr11-7 --model metadata.json --output report.md
    proveit docs templates
"""

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Optional

BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
CYAN = "\033[36m"
RESET = "\033[0m"


def _supports_color() -> bool:
    import os
    if not hasattr(sys.stdout, "isatty") or not sys.stdout.isatty():
        return False
    return os.environ.get("NO_COLOR") is None


def _c(text: str, color: str) -> str:
    return f"{color}{text}{RESET}" if _supports_color() else text


def _read_json_file(filepath: str, label: str) -> dict:
    """Read and parse a JSON file with user-friendly error handling."""
    p = Path(filepath)
    if not p.exists():
        print(f"Error: {label} file not found: {filepath}", file=sys.stderr)
        sys.exit(1)
    text = p.read_text()
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        print(
            f"Error: {label} file contains invalid JSON: {filepath}\n"
            f"  {exc}",
            file=sys.stderr,
        )
        sys.exit(1)


def cmd_generate(args):
    """Generate documentation."""
    from .engine import AutoDocEngine, ModelMetadata, PipelineMetadata, TemplateType

    if getattr(args, "verbose", False):
        logging.basicConfig(level=logging.DEBUG)

    template_map = {t.value: t for t in TemplateType}
    template = template_map.get(args.template)
    if not template:
        print(f"Unknown template: {args.template}")
        print(f"Available: {', '.join(template_map.keys())}")
        sys.exit(1)

    model_meta = None
    if args.model:
        data = _read_json_file(args.model, "model metadata")
        if "name" not in data:
            print(
                f"Error: model metadata JSON is missing required 'name' key: {args.model}",
                file=sys.stderr,
            )
            sys.exit(1)
        model_meta = ModelMetadata(**{
            k: v for k, v in data.items()
            if k in ModelMetadata.__dataclass_fields__
        })

    pipeline_meta = None
    if args.pipeline:
        data = _read_json_file(args.pipeline, "pipeline metadata")
        pipeline_meta = PipelineMetadata(**{
            k: v for k, v in data.items()
            if k in PipelineMetadata.__dataclass_fields__
        })

    dag_nodes = []
    dag_edges = []
    if args.dag:
        dag_data = _read_json_file(args.dag, "DAG")
        dag_nodes = dag_data.get("nodes", [])
        dag_edges = dag_data.get("edges", [])

    fairlens_report = None
    if args.fairlens:
        fairlens_report = _read_json_file(args.fairlens, "FairLens report")

    engine = AutoDocEngine()
    report = engine.generate(
        template=template,
        model_metadata=model_meta,
        pipeline_metadata=pipeline_meta,
        dag_nodes=dag_nodes,
        dag_edges=dag_edges,
        fairlens_report=fairlens_report,
    )

    if getattr(args, "json", False):
        print(report.to_json())
    elif args.output:
        report.save(args.output)
        print()
        print(_c(f"  Generated: {args.output}", GREEN))
        print(_c(f"  Template: {args.template}", DIM))
        print(_c(f"  Sections: {report.section_count}", DIM))
        print(_c(f"  Words: {report.word_count:,}", DIM))
        print()
    else:
        print(report.to_markdown())


def cmd_templates(args):
    """List available templates."""
    from .engine import AutoDocEngine

    engine = AutoDocEngine()
    templates = engine.list_templates()

    print()
    print(_c("  Available Templates", BOLD))
    print()
    for t in templates:
        print(f"  {_c(t['type'], CYAN)}")
        print(f"    {t['description']}")
        print()


def register_subcommands(subparsers):
    """Register docs subcommands on a parent subparser (for unified CLI)."""
    gen_parser = subparsers.add_parser("generate", help="Generate documentation")
    gen_parser.add_argument("--template", required=True, help="Template type")
    gen_parser.add_argument("--model", help="Path to model metadata JSON")
    gen_parser.add_argument("--pipeline", help="Path to pipeline metadata JSON")
    gen_parser.add_argument("--dag", help="Path to DAG JSON (nodes/edges)")
    gen_parser.add_argument("--fairlens", help="Path to FairLens report JSON")
    gen_parser.add_argument("--output", help="Output file path")
    gen_parser.add_argument("--json", action="store_true", help="Output JSON report to stdout")
    gen_parser.add_argument("--verbose", "-v", action="store_true", help="Enable debug logging")

    subparsers.add_parser("templates", help="List available templates")


def main():
    parser = argparse.ArgumentParser(
        prog="proveit docs",
        description="Attestant Docs: Automated Model & Pipeline Documentation",
    )
    parser.add_argument("--version", action="version", version="proveit 0.1.0")

    subparsers = parser.add_subparsers(dest="command")
    register_subcommands(subparsers)

    args = parser.parse_args()

    if args.command == "generate":
        cmd_generate(args)
    elif args.command == "templates":
        cmd_templates(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
