"""
AutoDoc core engine: generates compliance documentation from DAG metadata,
model information, and pipeline specifications using pluggable templates.
"""

import json
import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class _MarkdownParser:
    """Lightweight parser for converting markdown text to structured tokens.

    Handles bold, italic, code spans, bullet lists, headings, tables,
    and paragraph breaks. Used by the PDF and DOCX export backends.
    """

    _BOLD_RE = re.compile(r'\*\*(.+?)\*\*|__(.+?)__')
    _ITALIC_RE = re.compile(r'(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)|(?<!_)_(?!_)(.+?)(?<!_)_(?!_)')
    _CODE_RE = re.compile(r'`([^`]+?)`')
    _HEADING_RE = re.compile(r'^(#{1,6})\s+(.+)$')
    _BULLET_RE = re.compile(r'^(\s*)[-*]\s+(.+)$')
    _NUMBERED_RE = re.compile(r'^(\s*)\d+\.\s+(.+)$')
    _TABLE_ROW_RE = re.compile(r'^\|(.+)\|$')
    _TABLE_SEP_RE = re.compile(r'^\|[\s:]*[-]+[\s:]*')
    _CHECKBOX_RE = re.compile(r'\[[ x]\]\s*')

    @classmethod
    def parse_inline(cls, text: str) -> List[Tuple[str, str]]:
        """Parse inline markdown into (style, text) tuples.

        Styles: 'normal', 'bold', 'italic', 'code'.
        """
        tokens: List[Tuple[str, str]] = []
        pos = 0
        combined = re.compile(
            r'(\*\*(.+?)\*\*|__(.+?)__)|(`([^`]+?)`)'
        )
        for m in combined.finditer(text):
            if m.start() > pos:
                tokens.append(('normal', text[pos:m.start()]))
            if m.group(1):
                tokens.append(('bold', m.group(2) or m.group(3)))
            elif m.group(4):
                tokens.append(('code', m.group(5)))
            pos = m.end()
        if pos < len(text):
            tokens.append(('normal', text[pos:]))
        return tokens if tokens else [('normal', text)]

    @classmethod
    def parse_lines(cls, content: str):
        """Yield structured line tokens from markdown content.

        Each yielded item is a dict with 'type' and type-specific keys:
        - heading: level, text
        - bullet: indent, text
        - numbered: indent, text
        - table_row: cells (list of str)
        - table_sep: (no extra keys)
        - blank: (no extra keys)
        - paragraph: text
        """
        for line in content.split('\n'):
            stripped = line.strip()

            if not stripped:
                yield {'type': 'blank'}
                continue

            m = cls._HEADING_RE.match(stripped)
            if m:
                yield {'type': 'heading', 'level': len(m.group(1)), 'text': m.group(2)}
                continue

            if cls._TABLE_SEP_RE.match(stripped):
                yield {'type': 'table_sep'}
                continue

            m = cls._TABLE_ROW_RE.match(stripped)
            if m:
                cells = [c.strip() for c in m.group(1).split('|')]
                yield {'type': 'table_row', 'cells': cells}
                continue

            m = cls._BULLET_RE.match(line)
            if m:
                yield {'type': 'bullet', 'indent': len(m.group(1)), 'text': m.group(2)}
                continue

            m = cls._NUMBERED_RE.match(line)
            if m:
                yield {'type': 'numbered', 'indent': len(m.group(1)), 'text': m.group(2)}
                continue

            yield {'type': 'paragraph', 'text': stripped}


class TemplateType(Enum):
    SR_11_7 = "sr11-7"
    EU_AI_ACT = "eu-ai-act"
    MODEL_CARD = "model-card"
    ECOA = "ecoa"
    DBT = "dbt"
    GDPR = "gdpr"
    NIST_AI_RMF = "nist-ai-rmf"


@dataclass
class ModelMetadata:
    """Metadata about a model for documentation purposes."""
    name: str
    version: str = "1.0"
    model_type: str = "unknown"
    framework: str = "unknown"
    description: str = ""
    intended_use: str = ""
    limitations: str = ""
    training_date: Optional[str] = None
    feature_count: int = 0
    training_rows: int = 0
    hyperparameters: Dict[str, Any] = field(default_factory=dict)
    performance_metrics: Dict[str, float] = field(default_factory=dict)
    fairness_metrics: Dict[str, Any] = field(default_factory=dict)
    feature_names: List[str] = field(default_factory=list)
    feature_importances: Dict[str, float] = field(default_factory=dict)
    owner: str = ""
    contact: str = ""
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "model_type": self.model_type,
            "framework": self.framework,
            "description": self.description,
            "intended_use": self.intended_use,
            "limitations": self.limitations,
            "training_date": self.training_date,
            "feature_count": self.feature_count,
            "training_rows": self.training_rows,
            "hyperparameters": self.hyperparameters,
            "performance_metrics": self.performance_metrics,
            "fairness_metrics": self.fairness_metrics,
            "owner": self.owner,
        }


@dataclass
class PipelineMetadata:
    """Metadata about a data pipeline for documentation."""
    name: str
    description: str = ""
    source_tables: List[str] = field(default_factory=list)
    output_tables: List[str] = field(default_factory=list)
    transformation_steps: List[Dict[str, Any]] = field(default_factory=list)
    schedule: str = ""
    owner: str = ""
    data_quality_checks: List[Dict[str, Any]] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    sla: str = ""
    total_columns: int = 0
    total_rows: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "source_tables": self.source_tables,
            "output_tables": self.output_tables,
            "transformation_steps": self.transformation_steps,
            "schedule": self.schedule,
            "owner": self.owner,
            "data_quality_checks": self.data_quality_checks,
            "total_columns": self.total_columns,
            "total_rows": self.total_rows,
        }


@dataclass
class DocumentSection:
    """A section in the generated document."""
    title: str
    content: str
    level: int = 1
    subsections: List["DocumentSection"] = field(default_factory=list)

    def to_markdown(self, base_level: int = 1) -> str:
        actual_level = base_level + self.level - 1
        prefix = "#" * min(actual_level, 6)
        lines = [f"{prefix} {self.title}", "", self.content, ""]

        for sub in self.subsections:
            lines.append(sub.to_markdown(base_level=actual_level + 1))

        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "content": self.content,
            "level": self.level,
            "subsections": [s.to_dict() for s in self.subsections],
        }


@dataclass
class DocumentReport:
    """A complete generated document."""
    title: str
    template_type: TemplateType
    sections: List[DocumentSection]
    generated_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_markdown(self) -> str:
        lines = [f"# {self.title}", ""]

        if self.metadata:
            lines.append("---")
            for key, value in self.metadata.items():
                lines.append(f"**{key}:** {value}")
            lines.append("---")
            lines.append("")

        for section in self.sections:
            lines.append(section.to_markdown(base_level=2))

        return "\n".join(lines)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps({
            "title": self.title,
            "template_type": self.template_type.value,
            "generated_at": self.generated_at,
            "metadata": self.metadata,
            "sections": [s.to_dict() for s in self.sections],
        }, indent=indent, default=str)

    def save(self, path: str):
        from pathlib import Path
        p = Path(path)
        parent = p.parent
        if not parent.exists():
            raise FileNotFoundError(
                f"Directory does not exist: {parent}. "
                f"Create the directory before saving the report."
            )
        suffix = p.suffix.lower()
        if suffix == ".json":
            p.write_text(self.to_json())
        elif suffix == ".pdf":
            self._save_pdf(p)
        elif suffix == ".docx":
            self._save_docx(p)
        elif suffix in (".html", ".htm"):
            self._save_html(p)
        else:
            p.write_text(self.to_markdown())

    def _save_pdf(self, path):
        """Export report as a professional PDF using fpdf2."""
        try:
            from fpdf import FPDF
        except ImportError:
            raise ImportError(
                "PDF export requires the fpdf2 library. "
                "Install it with: pip install fpdf2"
            )

        class _CompliancePDF(FPDF):
            """Subclass that adds headers, footers, and watermark support."""

            def __init__(self, doc_title):
                super().__init__(format='letter')
                self._doc_title = doc_title
                self.set_auto_page_break(auto=True, margin=25.4)

            def header(self):
                if self.page_no() > 1:
                    self.set_font('Helvetica', 'I', 8)
                    self.set_text_color(128, 128, 128)
                    self.cell(0, 5, self._doc_title, align='L')
                    self.cell(0, 5, 'CONFIDENTIAL', align='R')
                    self.ln(8)
                    self.set_draw_color(200, 200, 200)
                    self.line(25.4, self.get_y(), self.w - 25.4, self.get_y())
                    self.ln(4)

            def footer(self):
                self.set_y(-20)
                self.set_font('Helvetica', 'I', 8)
                self.set_text_color(128, 128, 128)
                self.cell(0, 10, f'Page {self.page_no()}/{{nb}}', align='C')

        pdf = _CompliancePDF(self.title)
        pdf.alias_nb_pages()
        pdf.set_margins(25.4, 25.4, 25.4)

        pdf.add_page()
        pdf.ln(50)
        pdf.set_font('Helvetica', 'B', 24)
        pdf.set_text_color(0, 0, 0)
        pdf.multi_cell(0, 12, self.title, align='C')
        pdf.ln(10)

        if self.metadata:
            pdf.set_font('Helvetica', '', 11)
            for key, value in self.metadata.items():
                pdf.set_font('Helvetica', 'B', 11)
                pdf.cell(40, 7, f'{key}:', align='R')
                pdf.set_font('Helvetica', '', 11)
                pdf.cell(0, 7, f'  {value}')
                pdf.ln(7)

        pdf.ln(20)
        pdf.set_font('Helvetica', 'I', 14)
        pdf.set_text_color(180, 0, 0)
        pdf.cell(0, 10, 'CONFIDENTIAL', align='C')
        pdf.set_text_color(0, 0, 0)

        pdf.add_page()
        pdf.set_font('Helvetica', 'B', 16)
        pdf.cell(0, 10, 'Table of Contents')
        pdf.ln(12)
        pdf.set_font('Helvetica', '', 10)
        for i, section in enumerate(self.sections, 1):
            pdf.cell(0, 6, f'{i}. {section.title}')
            pdf.ln(6)
            for j, sub in enumerate(section.subsections, 1):
                pdf.cell(10)
                pdf.cell(0, 6, f'{i}.{j} {sub.title}')
                pdf.ln(6)
        pdf.ln(8)

        def _write_inline(pdf_obj, text, base_style=''):
            tokens = _MarkdownParser.parse_inline(text)
            for style, content in tokens:
                if style == 'bold' or base_style == 'B':
                    pdf_obj.set_font('Helvetica', 'B', 10)
                elif style == 'code':
                    pdf_obj.set_font('Courier', '', 9)
                elif style == 'italic':
                    pdf_obj.set_font('Helvetica', 'I', 10)
                else:
                    pdf_obj.set_font('Helvetica', '', 10)
                pdf_obj.write(5, content)
            pdf_obj.set_font('Helvetica', '', 10)

        def _render_section_content(pdf_obj, content):
            table_rows = []
            for token in _MarkdownParser.parse_lines(content):
                ttype = token['type']

                if ttype == 'table_row':
                    table_rows.append(token['cells'])
                    continue
                elif ttype == 'table_sep':
                    continue
                else:
                    if table_rows:
                        _flush_table(pdf_obj, table_rows)
                        table_rows = []

                if ttype == 'blank':
                    pdf_obj.ln(4)
                elif ttype == 'heading':
                    level = token['level']
                    size = max(14 - level, 10)
                    pdf_obj.ln(4)
                    pdf_obj.set_font('Helvetica', 'B', size)
                    pdf_obj.multi_cell(0, 6, token['text'])
                    pdf_obj.ln(2)
                    pdf_obj.set_font('Helvetica', '', 10)
                elif ttype == 'bullet':
                    indent = min(token['indent'] // 2, 3) * 5 + 5
                    pdf_obj.cell(indent)
                    pdf_obj.write(5, '  ')
                    _write_inline(pdf_obj, token['text'])
                    pdf_obj.ln(5)
                elif ttype == 'numbered':
                    indent = min(token['indent'] // 2, 3) * 5 + 5
                    pdf_obj.cell(indent)
                    _write_inline(pdf_obj, token['text'])
                    pdf_obj.ln(5)
                elif ttype == 'paragraph':
                    _write_inline(pdf_obj, token['text'])
                    pdf_obj.ln(5)

            if table_rows:
                _flush_table(pdf_obj, table_rows)

        def _flush_table(pdf_obj, rows):
            if not rows:
                return
            num_cols = max(len(r) for r in rows)
            usable_w = pdf_obj.w - pdf_obj.l_margin - pdf_obj.r_margin
            col_w = usable_w / max(num_cols, 1)

            pdf_obj.ln(3)
            for row_idx, row in enumerate(rows):
                while len(row) < num_cols:
                    row.append('')
                if row_idx == 0:
                    pdf_obj.set_font('Helvetica', 'B', 9)
                else:
                    pdf_obj.set_font('Helvetica', '', 9)
                for cell_text in row:
                    clean = cell_text.replace('**', '').strip()
                    pdf_obj.cell(col_w, 6, clean[:50], border=1)
                pdf_obj.ln(6)
            pdf_obj.set_font('Helvetica', '', 10)
            pdf_obj.ln(3)

        for section in self.sections:
            pdf.add_page()
            pdf.set_font('Helvetica', 'B', 14)
            pdf.cell(0, 10, section.title)
            pdf.ln(10)
            pdf.set_font('Helvetica', '', 10)
            _render_section_content(pdf, section.content)

            for sub in section.subsections:
                pdf.ln(6)
                pdf.set_font('Helvetica', 'B', 12)
                pdf.cell(0, 8, sub.title)
                pdf.ln(8)
                pdf.set_font('Helvetica', '', 10)
                _render_section_content(pdf, sub.content)

        pdf.output(str(path))

    def _save_docx(self, path):
        """Export report as a professional Word document using python-docx."""
        try:
            from docx import Document
            from docx.shared import Pt, Inches, RGBColor
            from docx.enum.text import WD_ALIGN_PARAGRAPH
            from docx.enum.style import WD_STYLE_TYPE
        except ImportError:
            raise ImportError(
                "DOCX export requires the python-docx library. "
                "Install it with: pip install python-docx"
            )

        doc = Document()

        style = doc.styles['Normal']
        font = style.font
        font.name = 'Calibri'
        font.size = Pt(11)

        title_para = doc.add_paragraph()
        title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title_run = title_para.add_run(self.title)
        title_run.bold = True
        title_run.font.size = Pt(24)
        title_run.font.color.rgb = RGBColor(0, 0, 0)

        if self.metadata:
            doc.add_paragraph()
            for key, value in self.metadata.items():
                p = doc.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                run_k = p.add_run(f'{key}: ')
                run_k.bold = True
                run_k.font.size = Pt(11)
                run_v = p.add_run(str(value))
                run_v.font.size = Pt(11)

        conf_para = doc.add_paragraph()
        conf_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        conf_run = conf_para.add_run('CONFIDENTIAL')
        conf_run.bold = True
        conf_run.font.size = Pt(14)
        conf_run.font.color.rgb = RGBColor(180, 0, 0)

        doc.add_page_break()

        toc_heading = doc.add_heading('Table of Contents', level=1)
        p = doc.add_paragraph(
            'Update this field in Word to generate page numbers: '
            'References > Table of Contents > Update Table'
        )
        p.italic = True

        for i, section in enumerate(self.sections, 1):
            doc.add_paragraph(f'{i}. {section.title}', style='List Number')
            for j, sub in enumerate(section.subsections, 1):
                doc.add_paragraph(f'{i}.{j} {sub.title}', style='List Number 2')

        doc.add_page_break()

        def _add_inline_runs(paragraph, text):
            tokens = _MarkdownParser.parse_inline(text)
            for style_name, content in tokens:
                run = paragraph.add_run(content)
                if style_name == 'bold':
                    run.bold = True
                elif style_name == 'code':
                    run.font.name = 'Courier New'
                    run.font.size = Pt(9)
                elif style_name == 'italic':
                    run.italic = True

        def _render_content(content, level_offset=0):
            table_rows = []
            for token in _MarkdownParser.parse_lines(content):
                ttype = token['type']

                if ttype == 'table_row':
                    table_rows.append(token['cells'])
                    continue
                elif ttype == 'table_sep':
                    continue
                else:
                    if table_rows:
                        _flush_docx_table(table_rows)
                        table_rows = []

                if ttype == 'blank':
                    continue
                elif ttype == 'heading':
                    hl = min(token['level'] + level_offset, 4)
                    doc.add_heading(token['text'], level=max(hl, 1))
                elif ttype == 'bullet':
                    p = doc.add_paragraph(style='List Bullet')
                    _add_inline_runs(p, token['text'])
                elif ttype == 'numbered':
                    p = doc.add_paragraph(style='List Number')
                    _add_inline_runs(p, token['text'])
                elif ttype == 'paragraph':
                    p = doc.add_paragraph()
                    _add_inline_runs(p, token['text'])

            if table_rows:
                _flush_docx_table(table_rows)

        def _flush_docx_table(rows):
            if not rows:
                return
            num_cols = max(len(r) for r in rows)
            table = doc.add_table(rows=len(rows), cols=num_cols)
            table.style = 'Table Grid'
            for r_idx, row in enumerate(rows):
                for c_idx in range(num_cols):
                    cell_text = row[c_idx] if c_idx < len(row) else ''
                    clean = cell_text.replace('**', '').strip()
                    cell = table.rows[r_idx].cells[c_idx]
                    cell.text = clean
                    if r_idx == 0:
                        for run in cell.paragraphs[0].runs:
                            run.bold = True

        for section in self.sections:
            doc.add_heading(section.title, level=1)
            _render_content(section.content, level_offset=1)

            for sub in section.subsections:
                doc.add_heading(sub.title, level=2)
                _render_content(sub.content, level_offset=2)

        doc.save(str(path))

    def _save_html(self, path):
        """Export report as a standalone HTML file with inline CSS."""
        import html as html_module

        css = """
        <style>
            :root {
                --bg: #ffffff; --fg: #1a1a2e; --accent: #0f3460;
                --border: #e0e0e0; --code-bg: #f5f5f5;
                --table-header: #0f3460; --table-header-fg: #ffffff;
            }
            @media (prefers-color-scheme: dark) {
                :root {
                    --bg: #1a1a2e; --fg: #e6e6e6; --accent: #64b5f6;
                    --border: #333355; --code-bg: #16213e;
                    --table-header: #16213e; --table-header-fg: #e6e6e6;
                }
            }
            * { box-sizing: border-box; }
            body {
                font-family: 'Segoe UI', Helvetica, Arial, sans-serif;
                max-width: 900px; margin: 0 auto; padding: 40px 20px;
                background: var(--bg); color: var(--fg);
                line-height: 1.6;
            }
            h1, h2, h3, h4 { color: var(--accent); margin-top: 1.5em; }
            h1 { font-size: 1.8em; border-bottom: 2px solid var(--accent); padding-bottom: 0.3em; }
            h2 { font-size: 1.4em; border-bottom: 1px solid var(--border); padding-bottom: 0.2em; }
            h3 { font-size: 1.2em; }
            code { background: var(--code-bg); padding: 2px 6px; border-radius: 3px;
                   font-family: 'Courier New', monospace; font-size: 0.9em; }
            table { border-collapse: collapse; width: 100%; margin: 1em 0; }
            th { background: var(--table-header); color: var(--table-header-fg);
                 padding: 8px 12px; text-align: left; }
            td { padding: 8px 12px; border: 1px solid var(--border); }
            tr:nth-child(even) { background: var(--code-bg); }
            .meta { background: var(--code-bg); padding: 15px; border-radius: 5px;
                    margin-bottom: 2em; }
            .meta strong { display: inline-block; min-width: 100px; }
            .confidential { color: #b00020; font-weight: bold; text-align: center;
                           font-size: 1.1em; margin: 1em 0; }
            ul, ol { padding-left: 1.5em; }
            @media print {
                body { max-width: 100%; padding: 20px; }
                h1, h2 { page-break-after: avoid; }
                table { page-break-inside: avoid; }
            }
        </style>
        """

        def _md_inline_to_html(text):
            escaped = html_module.escape(text)
            escaped = re.sub(
                r'\*\*(.+?)\*\*|__(.+?)__',
                lambda m: f'<strong>{m.group(1) or m.group(2)}</strong>',
                escaped,
            )
            escaped = re.sub(
                r'`([^`]+?)`',
                lambda m: f'<code>{m.group(1)}</code>',
                escaped,
            )
            return escaped

        def _content_to_html(content):
            parts = []
            table_rows = []
            for token in _MarkdownParser.parse_lines(content):
                ttype = token['type']
                if ttype == 'table_row':
                    table_rows.append(token['cells'])
                    continue
                elif ttype == 'table_sep':
                    continue
                else:
                    if table_rows:
                        parts.append(_table_html(table_rows))
                        table_rows = []

                if ttype == 'blank':
                    continue
                elif ttype == 'heading':
                    lvl = min(token['level'] + 1, 6)
                    parts.append(f'<h{lvl}>{_md_inline_to_html(token["text"])}</h{lvl}>')
                elif ttype == 'bullet':
                    parts.append(f'<li>{_md_inline_to_html(token["text"])}</li>')
                elif ttype == 'numbered':
                    parts.append(f'<li>{_md_inline_to_html(token["text"])}</li>')
                elif ttype == 'paragraph':
                    parts.append(f'<p>{_md_inline_to_html(token["text"])}</p>')

            if table_rows:
                parts.append(_table_html(table_rows))

            result = []
            in_list = False
            for part in parts:
                if part.startswith('<li>'):
                    if not in_list:
                        result.append('<ul>')
                        in_list = True
                    result.append(part)
                else:
                    if in_list:
                        result.append('</ul>')
                        in_list = False
                    result.append(part)
            if in_list:
                result.append('</ul>')
            return '\n'.join(result)

        def _table_html(rows):
            if not rows:
                return ''
            lines = ['<table>']
            for i, row in enumerate(rows):
                lines.append('<tr>')
                tag = 'th' if i == 0 else 'td'
                for cell in row:
                    clean = cell.replace('**', '').strip()
                    lines.append(f'<{tag}>{html_module.escape(clean)}</{tag}>')
                lines.append('</tr>')
            lines.append('</table>')
            return '\n'.join(lines)

        body_parts = [f'<h1>{html_module.escape(self.title)}</h1>']

        if self.metadata:
            body_parts.append('<div class="meta">')
            for key, value in self.metadata.items():
                body_parts.append(
                    f'<div><strong>{html_module.escape(str(key))}:</strong> '
                    f'{html_module.escape(str(value))}</div>'
                )
            body_parts.append('</div>')
            body_parts.append('<p class="confidential">CONFIDENTIAL</p>')

        for section in self.sections:
            body_parts.append(
                f'<h2>{html_module.escape(section.title)}</h2>'
            )
            body_parts.append(_content_to_html(section.content))
            for sub in section.subsections:
                body_parts.append(
                    f'<h3>{html_module.escape(sub.title)}</h3>'
                )
                body_parts.append(_content_to_html(sub.content))

        html_doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{html_module.escape(self.title)}</title>
{css}
</head>
<body>
{chr(10).join(body_parts)}
</body>
</html>"""

        path.write_text(html_doc, encoding='utf-8')

    @property
    def section_count(self) -> int:
        count = len(self.sections)
        for s in self.sections:
            count += len(s.subsections)
        return count

    @property
    def word_count(self) -> int:
        text = self.to_markdown()
        return len(text.split())


class AutoDocEngine:
    """
    Main engine that generates documentation from DAG and model metadata.

    Supports multiple template types and can integrate with existing
    DAG stores, model registries, and compliance engines.
    """

    def __init__(self):
        from .templates import TEMPLATE_REGISTRY
        self._templates = TEMPLATE_REGISTRY

    def generate(
        self,
        template: TemplateType,
        model_metadata: Optional[ModelMetadata] = None,
        pipeline_metadata: Optional[PipelineMetadata] = None,
        dag_nodes: Optional[List[Dict[str, Any]]] = None,
        dag_edges: Optional[List[Dict[str, Any]]] = None,
        fairlens_report: Optional[Dict[str, Any]] = None,
        additional_context: Optional[Dict[str, Any]] = None,
    ) -> DocumentReport:
        """
        Generate a documentation report.

        Args:
            template: Type of document to generate
            model_metadata: Model information (for model-focused templates)
            pipeline_metadata: Pipeline information (for pipeline-focused templates)
            dag_nodes: DAG node definitions
            dag_edges: DAG edge definitions
            fairlens_report: FairLens analysis results (for ECOA template)
            additional_context: Extra context for template rendering

        Returns:
            DocumentReport with all sections populated
        """
        if dag_nodes is not None and not isinstance(dag_nodes, list):
            raise TypeError(
                f"dag_nodes must be a list or None, got {type(dag_nodes).__name__}"
            )
        if dag_edges is not None and not isinstance(dag_edges, list):
            raise TypeError(
                f"dag_edges must be a list or None, got {type(dag_edges).__name__}"
            )

        template_class = self._templates.get(template)
        if not template_class:
            raise ValueError(f"Unknown template type: {template}")

        template_instance = template_class()

        context = {
            "model": model_metadata,
            "pipeline": pipeline_metadata,
            "dag_nodes": dag_nodes or [],
            "dag_edges": dag_edges or [],
            "fairlens_report": fairlens_report,
            **(additional_context or {}),
        }

        sections = template_instance.render(context)

        report_metadata = {
            "Template": template.value,
            "Generated": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
        }
        if model_metadata:
            report_metadata["Model"] = model_metadata.name
            report_metadata["Version"] = model_metadata.version
        if pipeline_metadata:
            report_metadata["Pipeline"] = pipeline_metadata.name

        return DocumentReport(
            title=template_instance.get_title(context),
            template_type=template,
            sections=sections,
            metadata=report_metadata,
        )

    def list_templates(self) -> List[Dict[str, str]]:
        """List available templates."""
        result = []
        for ttype, tcls in self._templates.items():
            t = tcls()
            result.append({
                "type": ttype.value,
                "name": t.name,
                "description": t.description,
            })
        return result

    def gap_analysis(self, report: "DocumentReport") -> "GapReport":
        """Analyze a generated report for completeness against regulatory requirements.

        Args:
            report: A previously generated DocumentReport.

        Returns:
            GapReport with findings about missing or incomplete content.
        """
        from .gap_analysis import GapAnalyzer
        analyzer = GapAnalyzer()
        return analyzer.analyze(report, report.template_type.value)
