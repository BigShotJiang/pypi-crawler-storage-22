"""
Gap Analysis engine: identifies missing or incomplete documentation in
generated compliance reports by checking against regulatory requirements
checklists for each template type.
"""

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Gap:
    """A single identified gap in a compliance document."""
    requirement: str
    severity: str
    description: str
    remediation: str


@dataclass
class GapReport:
    """Results of a gap analysis against a regulatory requirements checklist."""
    template_type: str
    total_requirements: int
    met_requirements: int
    gaps: List[Gap]
    score: float
    status: str

    def to_section_content(self) -> str:
        """Render the gap report as markdown content for appending to a document."""
        lines = [
            f"**Gap Analysis Score:** {self.score:.1%} ({self.met_requirements}/{self.total_requirements} requirements met)",
            f"**Status:** {self.status}",
            "",
        ]
        if not self.gaps:
            lines.append("All regulatory requirements have been addressed in this document.")
            return "\n".join(lines)

        lines.append("| # | Requirement | Severity | Description | Remediation |")
        lines.append("|---|-------------|----------|-------------|-------------|")
        for i, gap in enumerate(self.gaps, 1):
            desc_short = gap.description[:120].replace("|", "/")
            rem_short = gap.remediation[:120].replace("|", "/")
            lines.append(
                f"| {i} | {gap.requirement} | **{gap.severity}** | {desc_short} | {rem_short} |"
            )

        severity_counts = {}
        for g in self.gaps:
            severity_counts[g.severity] = severity_counts.get(g.severity, 0) + 1
        lines.append("")
        lines.append("**Gap Summary:**")
        for sev in ["critical", "major", "minor"]:
            count = severity_counts.get(sev, 0)
            if count > 0:
                lines.append(f"- {sev.title()}: {count}")

        return "\n".join(lines)


class GapAnalyzer:
    """Analyzes DocumentReport instances for completeness against regulatory requirements."""

    _REQUIREMENTS: Dict[str, List[Dict[str, Any]]] = {
        "sr11-7": [
            {
                "name": "Executive Summary",
                "section_pattern": r"executive\s+summary",
                "severity": "critical",
                "description": "SR 11-7 requires an executive summary with model purpose, risk tier, validation scope, and key findings.",
                "remediation": "Add an Executive Summary section covering model purpose, risk tier, validation scope, key findings, and recommended actions.",
            },
            {
                "name": "Model Description",
                "section_pattern": r"model\s+description",
                "severity": "critical",
                "description": "SR 11-7 Section IV requires complete model description including architecture, inputs, and outputs.",
                "remediation": "Add a Model Description section documenting the model architecture, input features, output specification, and intended use.",
            },
            {
                "name": "Conceptual Soundness",
                "section_pattern": r"conceptual\s+soundness",
                "severity": "critical",
                "description": "SR 11-7 Section V.A requires conceptual soundness review of theoretical basis and methodology.",
                "remediation": "Add a Conceptual Soundness Review section evaluating theoretical basis, methodology, and key assumptions.",
            },
            {
                "name": "Data Assessment",
                "section_pattern": r"data\s+assessment",
                "severity": "critical",
                "description": "SR 11-7 Section V.B requires data quality assessment including completeness, accuracy, and representativeness.",
                "remediation": "Add a Data Assessment section covering data quality dimensions, source data inventory, and quality checks.",
            },
            {
                "name": "Performance Analysis",
                "section_pattern": r"performance\s+analysis",
                "severity": "critical",
                "description": "SR 11-7 Section V.C requires quantitative performance analysis with discrimination metrics.",
                "remediation": "Add a Performance Analysis section with AUC, KS, Gini, and benchmark comparisons.",
            },
            {
                "name": "Outcomes Analysis",
                "section_pattern": r"outcomes\s+analysis",
                "severity": "major",
                "description": "SR 11-7 Section V.C requires backtesting and sensitivity analysis of model outcomes.",
                "remediation": "Add an Outcomes Analysis section with backtesting framework, vintage analysis, and sensitivity tests.",
            },
            {
                "name": "Limitations",
                "section_pattern": r"limitation|caveat",
                "severity": "major",
                "description": "SR 11-7 requires documentation of all known model limitations.",
                "remediation": "Add a Limitations section documenting known constraints, population drift risks, and adversarial robustness.",
            },
            {
                "name": "Monitoring Plan",
                "section_pattern": r"monitor",
                "severity": "critical",
                "description": "SR 11-7 Section VI requires an ongoing monitoring plan with metrics, thresholds, and escalation.",
                "remediation": "Add a Monitoring Plan section with metric thresholds, escalation procedures, and reporting cadence.",
            },
            {
                "name": "Governance",
                "section_pattern": r"governance",
                "severity": "major",
                "description": "SR 11-7 Section VII requires governance framework documentation.",
                "remediation": "Add a Governance section covering three lines of defense, model inventory, and change management.",
            },
            {
                "name": "Risk Rating",
                "content_pattern": r"risk\s+rat(ing|ed)|overall.*rating",
                "severity": "major",
                "description": "SR 11-7 requires an overall model risk rating (Satisfactory, Needs Improvement, Unsatisfactory).",
                "remediation": "Include an explicit overall model risk rating in the Executive Summary.",
            },
            {
                "name": "Validation Findings",
                "content_pattern": r"finding|F-\d{3}",
                "severity": "major",
                "description": "SR 11-7 requires documentation of all validation findings with severity classification.",
                "remediation": "Add a findings section with finding IDs, severity levels, descriptions, and recommendations.",
            },
            {
                "name": "Regulatory Citations",
                "content_pattern": r"SR\s*(letter\s*)?11-7|OCC\s*(bulletin\s*)?2011-12",
                "severity": "minor",
                "description": "Report should reference the specific regulatory guidance (SR 11-7, OCC 2011-12).",
                "remediation": "Add regulatory cross-references citing SR 11-7 and OCC 2011-12 sections.",
            },
            {
                "name": "Performance Metric (AUC, KS, or Gini)",
                "content_pattern": r"AUC|KS|Gini|auc_roc|ks_statistic|gini_coefficient",
                "severity": "critical",
                "description": "Performance section must include at least one quantitative metric (AUC, KS, or Gini).",
                "remediation": "Include AUC-ROC, KS statistic, or Gini coefficient in the Performance Analysis section.",
            },
            {
                "name": "Monitoring Thresholds",
                "content_pattern": r"threshold|PSI|CSI|escalat",
                "severity": "major",
                "description": "Monitoring section must include specific metric thresholds and escalation procedures.",
                "remediation": "Define quantitative thresholds for key monitoring metrics and document escalation procedures.",
            },
        ],
        "ecoa": [
            {
                "name": "Protected Attribute Inventory",
                "section_pattern": r"protected\s+attribute|protected.*inventory",
                "severity": "critical",
                "description": "ECOA requires a complete inventory of protected attributes tracked in the pipeline.",
                "remediation": "Add a Protected Attribute Inventory section listing all ECOA protected classes and their status in the model.",
            },
            {
                "name": "Disparate Impact Analysis",
                "section_pattern": r"disparate\s+impact",
                "severity": "critical",
                "description": "ECOA requires disparate impact analysis across all protected attributes.",
                "remediation": "Add a Disparate Impact Analysis section with impact ratios for each protected attribute.",
            },
            {
                "name": "Proxy Detection",
                "section_pattern": r"proxy",
                "severity": "critical",
                "description": "ECOA requires proxy variable detection to identify indirect discrimination.",
                "remediation": "Add a Proxy Detection section identifying features correlated with protected attributes.",
            },
            {
                "name": "Adverse Action Methodology",
                "section_pattern": r"adverse\s+action",
                "severity": "critical",
                "description": "ECOA/CFPB requires documentation of adverse action reason code methodology.",
                "remediation": "Add an Adverse Action Methodology section documenting reason code generation per CFPB Circular 2023-03.",
            },
            {
                "name": "Four-Fifths Rule",
                "content_pattern": r"four.?fifth|4/5|0\.80|80\s*%\s*rule",
                "severity": "major",
                "description": "Report must reference the four-fifths rule (80% threshold) for disparate impact testing.",
                "remediation": "Include four-fifths rule analysis showing impact ratios compared to the 0.80 threshold.",
            },
            {
                "name": "Reg B Citation",
                "content_pattern": r"12\s*CFR\s*1002|Regulation\s*B|Reg\.?\s*B",
                "severity": "major",
                "description": "Report must cite Regulation B (12 CFR 1002) as the governing regulation.",
                "remediation": "Add regulatory citations referencing Regulation B (12 CFR 1002) sections.",
            },
            {
                "name": "DI Ratios for Protected Attribute",
                "content_pattern": r"impact\s*ratio|DI\s*ratio|\d\.\d{2,3}.*(?:PASS|FAIL)|worst_ratio",
                "severity": "critical",
                "description": "Report must include disparate impact ratios for at least one protected attribute.",
                "remediation": "Include quantitative disparate impact ratios with pass/fail status for each protected attribute.",
            },
            {
                "name": "Adverse Action Reason Codes",
                "content_pattern": r"reason\s*code|adverse\s*action\s*(?:reason|notice|notification)",
                "severity": "major",
                "description": "Report must address adverse action reason code methodology per CFPB guidance.",
                "remediation": "Document how adverse action reason codes are generated and validated for specificity requirements.",
            },
        ],
        "eu-ai-act": [
            {
                "name": "Risk Classification",
                "section_pattern": r"risk\s+(?:classification|management|assessment)",
                "severity": "critical",
                "description": "EU AI Act requires explicit risk level classification of the AI system.",
                "remediation": "Add a Risk Classification section classifying the system as prohibited, high-risk, limited, or minimal risk.",
            },
            {
                "name": "Human Oversight",
                "section_pattern": r"human\s+oversight",
                "severity": "critical",
                "description": "Article 14 requires documentation of human oversight measures.",
                "remediation": "Add a Human Oversight section documenting human-in-the-loop mechanisms per Article 14.",
            },
            {
                "name": "Data Governance",
                "section_pattern": r"data\s+governance",
                "severity": "critical",
                "description": "Article 10 requires data governance documentation for training, validation, and testing datasets.",
                "remediation": "Add a Data Governance section documenting data quality criteria, bias examination, and protection measures.",
            },
            {
                "name": "Transparency",
                "section_pattern": r"transparency|design\s+specification",
                "severity": "critical",
                "description": "Article 13 requires transparency documentation including system operation and output interpretation.",
                "remediation": "Add transparency documentation per Article 13 covering system operation and output interpretation.",
            },
            {
                "name": "Article 9 Reference",
                "content_pattern": r"Article\s*9",
                "severity": "major",
                "description": "Report must reference Article 9 (Risk Management System).",
                "remediation": "Add reference to Article 9 requirements for risk management systems.",
            },
            {
                "name": "Article 10 Reference",
                "content_pattern": r"Article\s*10",
                "severity": "major",
                "description": "Report must reference Article 10 (Data and Data Governance).",
                "remediation": "Add reference to Article 10 requirements for data governance.",
            },
            {
                "name": "Article 12 Reference",
                "content_pattern": r"Article\s*12",
                "severity": "minor",
                "description": "Report must reference Article 12 (Record-keeping).",
                "remediation": "Add reference to Article 12 logging and record-keeping requirements.",
            },
            {
                "name": "Article 13 Reference",
                "content_pattern": r"Article\s*13",
                "severity": "major",
                "description": "Report must reference Article 13 (Transparency).",
                "remediation": "Add reference to Article 13 transparency requirements.",
            },
            {
                "name": "Article 14 Reference",
                "content_pattern": r"Article\s*14",
                "severity": "major",
                "description": "Report must reference Article 14 (Human Oversight).",
                "remediation": "Add reference to Article 14 human oversight requirements.",
            },
            {
                "name": "Article 15 Reference",
                "content_pattern": r"Article\s*15",
                "severity": "minor",
                "description": "Report must reference Article 15 (Accuracy, Robustness, Cybersecurity).",
                "remediation": "Add reference to Article 15 accuracy and robustness requirements.",
            },
            {
                "name": "System Risk Level Classification",
                "content_pattern": r"(?:prohibited|high.?risk|limited.?risk|minimal.?risk)|(?:Annex\s*III)|(?:Article\s*6)",
                "severity": "critical",
                "description": "Report must explicitly classify the system risk level (prohibited, high-risk, limited, or minimal).",
                "remediation": "Add explicit risk level classification with justification citing Annex III and Article 6.",
            },
        ],
    }

    def analyze(self, report, template_type: str) -> GapReport:
        """Analyze a document report for completeness.

        Args:
            report: A DocumentReport instance.
            template_type: The template type string (e.g. 'sr11-7', 'ecoa', 'eu-ai-act').

        Returns:
            GapReport with gap findings and compliance score.
        """
        requirements = self._REQUIREMENTS.get(template_type, [])
        if not requirements:
            return GapReport(
                template_type=template_type,
                total_requirements=0,
                met_requirements=0,
                gaps=[],
                score=1.0,
                status="complete",
            )

        section_titles = []
        full_text_parts = []
        for section in report.sections:
            section_titles.append(section.title.lower())
            full_text_parts.append(section.title)
            full_text_parts.append(section.content)
            for sub in section.subsections:
                section_titles.append(sub.title.lower())
                full_text_parts.append(sub.title)
                full_text_parts.append(sub.content)

        full_text = "\n".join(full_text_parts)

        gaps = []
        met = 0

        for req in requirements:
            found = False

            if "section_pattern" in req:
                pattern = req["section_pattern"]
                for title in section_titles:
                    if re.search(pattern, title, re.IGNORECASE):
                        found = True
                        break

            if "content_pattern" in req:
                if re.search(req["content_pattern"], full_text, re.IGNORECASE):
                    if "section_pattern" not in req:
                        found = True
                    elif found:
                        pass
                else:
                    found = False

            if found:
                met += 1
            else:
                gaps.append(Gap(
                    requirement=req["name"],
                    severity=req["severity"],
                    description=req["description"],
                    remediation=req["remediation"],
                ))

        total = len(requirements)
        score = met / total if total > 0 else 1.0

        critical_gaps = sum(1 for g in gaps if g.severity == "critical")
        major_gaps = sum(1 for g in gaps if g.severity == "major")

        if score >= 0.95 and critical_gaps == 0:
            status = "complete"
        elif critical_gaps == 0 and major_gaps <= 2:
            status = "minor_gaps"
        elif critical_gaps <= 2:
            status = "major_gaps"
        else:
            status = "incomplete"

        return GapReport(
            template_type=template_type,
            total_requirements=total,
            met_requirements=met,
            gaps=gaps,
            score=score,
            status=status,
        )
