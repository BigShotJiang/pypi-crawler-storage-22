"""Allow running as ``python -m attestant.fairness``."""

from attestant.fairness.cli import main

main()
