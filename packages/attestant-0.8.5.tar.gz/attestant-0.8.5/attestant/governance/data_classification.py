"""
Data Classification & PII Detection.

Scans column names and sample values to detect Personally Identifiable
Information (PII) and classify data sensitivity levels per financial
services data governance standards.

Classification levels (aligned with FFIEC IT Examination Handbook):
    - PUBLIC: Non-sensitive, can be freely shared
    - INTERNAL: For internal use only
    - CONFIDENTIAL: Contains business-sensitive information
    - RESTRICTED: Contains PII, protected attributes, or regulated data

PII categories detected:
    - DIRECT_IDENTIFIER: SSN, driver's license, passport, account numbers
    - QUASI_IDENTIFIER: Name, address, date of birth, phone, email
    - PROTECTED_ATTRIBUTE: Race, sex, age, religion, national origin, etc.
    - FINANCIAL: Income, credit score, loan amount, account balance
    - HEALTH: Medical conditions, diagnoses, prescriptions
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set


class DataClassification(Enum):
    """Data sensitivity classification per FFIEC standards.

    Values are integers to allow comparison (higher = more sensitive).
    """
    PUBLIC = 0
    INTERNAL = 1
    CONFIDENTIAL = 2
    RESTRICTED = 3


class PIICategory(Enum):
    """Category of PII detected."""
    DIRECT_IDENTIFIER = "direct_identifier"
    QUASI_IDENTIFIER = "quasi_identifier"
    PROTECTED_ATTRIBUTE = "protected_attribute"
    FINANCIAL = "financial"
    HEALTH = "health"


@dataclass
class ColumnClassification:
    """Classification result for a single column.

    Attributes:
        column_name: Name of the column.
        classification: Sensitivity level.
        pii_categories: Which PII categories were detected.
        matched_patterns: Which patterns triggered the classification.
        confidence: Confidence in the classification (0.0-1.0).
    """
    column_name: str
    classification: DataClassification
    pii_categories: List[PIICategory] = field(default_factory=list)
    matched_patterns: List[str] = field(default_factory=list)
    confidence: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "column_name": self.column_name,
            "classification": self.classification.name.lower(),
            "pii_categories": [c.value for c in self.pii_categories],
            "matched_patterns": self.matched_patterns,
            "confidence": round(self.confidence, 2),
        }


class PIIDetector:
    """Detects PII in column names and classifies data sensitivity.

    Uses pattern matching on column names to identify PII and assign
    data classification levels. Designed for pre-processing data
    governance checks before model training or deployment.

    Usage::

        detector = PIIDetector()
        results = detector.classify_columns([
            "ssn", "applicant_name", "credit_score",
            "race", "income", "loan_amount", "zip_code",
        ])
        for r in results:
            print(f"{r.column_name}: {r.classification.value} ({r.pii_categories})")

        restricted = detector.restricted_columns(["ssn", "name", "score"])
        pii_report = detector.generate_report(["ssn", "name", "age", "score"])
    """

    # Pattern → (PIICategory, DataClassification, confidence)
    _PATTERNS: List[tuple] = [
        # Direct identifiers → RESTRICTED
        (r"(?i)\bssn\b|social.?security", PIICategory.DIRECT_IDENTIFIER, DataClassification.RESTRICTED, 1.0),
        (r"(?i)driver.?licen[cs]e|dl.?num", PIICategory.DIRECT_IDENTIFIER, DataClassification.RESTRICTED, 1.0),
        (r"(?i)passport", PIICategory.DIRECT_IDENTIFIER, DataClassification.RESTRICTED, 1.0),
        (r"(?i)account.?num|acct.?no", PIICategory.DIRECT_IDENTIFIER, DataClassification.RESTRICTED, 0.9),
        (r"(?i)tax.?id|ein\b|tin\b", PIICategory.DIRECT_IDENTIFIER, DataClassification.RESTRICTED, 0.95),
        (r"(?i)national.?id|citizen.?id", PIICategory.DIRECT_IDENTIFIER, DataClassification.RESTRICTED, 0.95),

        # Quasi-identifiers → CONFIDENTIAL
        (r"(?i)\bname\b|first.?name|last.?name|full.?name|applicant.?name", PIICategory.QUASI_IDENTIFIER, DataClassification.CONFIDENTIAL, 0.9),
        (r"(?i)\baddress\b|street|city(?!_)|zip.?code|postal", PIICategory.QUASI_IDENTIFIER, DataClassification.CONFIDENTIAL, 0.85),
        (r"(?i)date.?of.?birth|dob\b|birth.?date", PIICategory.QUASI_IDENTIFIER, DataClassification.CONFIDENTIAL, 0.95),
        (r"(?i)\bphone\b|telephone|mobile|cell.?num", PIICategory.QUASI_IDENTIFIER, DataClassification.CONFIDENTIAL, 0.9),
        (r"(?i)\bemail\b|e.?mail", PIICategory.QUASI_IDENTIFIER, DataClassification.CONFIDENTIAL, 0.9),
        (r"(?i)ip.?addr", PIICategory.QUASI_IDENTIFIER, DataClassification.CONFIDENTIAL, 0.8),

        # Protected attributes → RESTRICTED (ECOA / Fair Housing / Title VII)
        (r"(?i)\brace\b|ethnicity|racial", PIICategory.PROTECTED_ATTRIBUTE, DataClassification.RESTRICTED, 1.0),
        (r"(?i)\bsex\b|\bgender\b|male|female", PIICategory.PROTECTED_ATTRIBUTE, DataClassification.RESTRICTED, 0.95),
        (r"(?i)\bage\b|age.?group|birth.?year", PIICategory.PROTECTED_ATTRIBUTE, DataClassification.RESTRICTED, 0.85),
        (r"(?i)national.?origin|country.?of.?origin|citizenship", PIICategory.PROTECTED_ATTRIBUTE, DataClassification.RESTRICTED, 0.95),
        (r"(?i)religion|religious", PIICategory.PROTECTED_ATTRIBUTE, DataClassification.RESTRICTED, 0.95),
        (r"(?i)marital|married|divorced|single", PIICategory.PROTECTED_ATTRIBUTE, DataClassification.RESTRICTED, 0.85),
        (r"(?i)disabilit|handicap", PIICategory.PROTECTED_ATTRIBUTE, DataClassification.RESTRICTED, 0.95),
        (r"(?i)sexual.?orient|lgbtq|sogi\b", PIICategory.PROTECTED_ATTRIBUTE, DataClassification.RESTRICTED, 1.0),
        (r"(?i)military|veteran|armed.?forces", PIICategory.PROTECTED_ATTRIBUTE, DataClassification.RESTRICTED, 0.9),
        (r"(?i)pregnan", PIICategory.PROTECTED_ATTRIBUTE, DataClassification.RESTRICTED, 0.95),
        (r"(?i)familial.?status|number.?of.?children|dependents", PIICategory.PROTECTED_ATTRIBUTE, DataClassification.RESTRICTED, 0.85),

        # Financial → CONFIDENTIAL
        (r"(?i)\bincome\b|salary|wage|compensation|annual.?income", PIICategory.FINANCIAL, DataClassification.CONFIDENTIAL, 0.9),
        (r"(?i)credit.?score|fico\b|vantage.?score", PIICategory.FINANCIAL, DataClassification.CONFIDENTIAL, 0.9),
        (r"(?i)loan.?amount|principal|mortgage", PIICategory.FINANCIAL, DataClassification.CONFIDENTIAL, 0.85),
        (r"(?i)balance|account.?bal", PIICategory.FINANCIAL, DataClassification.CONFIDENTIAL, 0.8),
        (r"(?i)debt|liabilit|obligation", PIICategory.FINANCIAL, DataClassification.CONFIDENTIAL, 0.75),

        # Health → RESTRICTED (HIPAA)
        (r"(?i)diagnos|medical|health.?condition", PIICategory.HEALTH, DataClassification.RESTRICTED, 0.95),
        (r"(?i)prescription|medication|drug", PIICategory.HEALTH, DataClassification.RESTRICTED, 0.9),
        (r"(?i)icd.?\d|cpt.?code", PIICategory.HEALTH, DataClassification.RESTRICTED, 0.95),
    ]

    def classify_column(self, column_name: str) -> ColumnClassification:
        """Classify a single column by name."""
        pii_categories: List[PIICategory] = []
        matched_patterns: List[str] = []
        max_classification = DataClassification.PUBLIC
        max_confidence = 0.0

        for pattern, category, classification, confidence in self._PATTERNS:
            if re.search(pattern, column_name):
                if category not in pii_categories:
                    pii_categories.append(category)
                matched_patterns.append(pattern)
                if classification.value > max_classification.value:
                    max_classification = classification
                max_confidence = max(max_confidence, confidence)

        # Default internal if no matches but looks like a data column
        if not pii_categories:
            max_classification = DataClassification.INTERNAL
            max_confidence = 0.5

        return ColumnClassification(
            column_name=column_name,
            classification=max_classification,
            pii_categories=pii_categories,
            matched_patterns=matched_patterns,
            confidence=max_confidence if pii_categories else 0.5,
        )

    def classify_columns(
        self, column_names: List[str]
    ) -> List[ColumnClassification]:
        """Classify multiple columns."""
        return [self.classify_column(name) for name in column_names]

    def restricted_columns(self, column_names: List[str]) -> List[str]:
        """Return column names classified as RESTRICTED."""
        return [
            r.column_name
            for r in self.classify_columns(column_names)
            if r.classification == DataClassification.RESTRICTED
        ]

    def has_pii(self, column_names: List[str]) -> bool:
        """Check if any column contains PII."""
        return any(
            r.pii_categories
            for r in self.classify_columns(column_names)
        )

    def generate_report(
        self, column_names: List[str]
    ) -> Dict[str, Any]:
        """Generate a data classification report."""
        results = self.classify_columns(column_names)

        by_classification: Dict[str, List[str]] = {}
        for r in results:
            by_classification.setdefault(r.classification.name.lower(), []).append(
                r.column_name
            )

        by_pii: Dict[str, List[str]] = {}
        for r in results:
            for cat in r.pii_categories:
                by_pii.setdefault(cat.value, []).append(r.column_name)

        return {
            "total_columns": len(column_names),
            "columns_with_pii": sum(1 for r in results if r.pii_categories),
            "by_classification": by_classification,
            "by_pii_category": by_pii,
            "classifications": [r.to_dict() for r in results],
        }
