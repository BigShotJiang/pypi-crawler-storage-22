"""
Retention Policy Enforcement Engine.

Enforces regulation-specific data retention policies and detects
violations where data is retained too long or purged too soon.

Key retention requirements:
    - 12 CFR 1002.12(a): ECOA records retained 25 months (longer if
      investigation pending)
    - SR 11-7 §4: Model validation records retained for model lifecycle
    - EU AI Act Article 12(2): High-risk system logs retained for the
      duration of the system's use (minimum period set by Member States)
    - Colorado AI Act § 6-1-1704(3): Impact assessments retained for
      3 years after last deployment
    - NYC LL144: Bias audit results retained for at least 4 years
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional


@dataclass
class RetentionPolicy:
    """A data retention policy for a specific regulation or data category.

    Attributes:
        name: Policy name.
        regulation: Which regulation requires this retention.
        citation: Specific regulatory citation.
        min_retention_days: Minimum days data must be retained.
        max_retention_days: Maximum days data may be retained (0 = no max).
        data_categories: Which data categories this policy applies to.
        investigation_hold: Whether retention extends during investigations.
        notes: Additional policy notes.
    """
    name: str
    regulation: str
    citation: str
    min_retention_days: int
    max_retention_days: int = 0
    data_categories: List[str] = field(default_factory=list)
    investigation_hold: bool = False
    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "regulation": self.regulation,
            "citation": self.citation,
            "min_retention_days": self.min_retention_days,
            "max_retention_days": self.max_retention_days,
            "data_categories": self.data_categories,
            "investigation_hold": self.investigation_hold,
            "notes": self.notes,
        }


@dataclass
class RetentionViolation:
    """A retention policy violation.

    Attributes:
        policy_name: Which policy was violated.
        violation_type: "under_retention" or "over_retention".
        data_category: Which data category is affected.
        required_days: How many days are required.
        actual_days: How many days data has been retained.
        severity: "critical" or "warning".
        remediation: Suggested corrective action.
    """
    policy_name: str
    violation_type: str
    data_category: str
    required_days: int
    actual_days: int
    severity: str
    remediation: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "policy_name": self.policy_name,
            "violation_type": self.violation_type,
            "data_category": self.data_category,
            "required_days": self.required_days,
            "actual_days": self.actual_days,
            "severity": self.severity,
            "remediation": self.remediation,
        }


class RetentionPolicyEngine:
    """Enforces data retention policies across regulations.

    Pre-loaded with financial services retention requirements from ECOA,
    SR 11-7, EU AI Act, Colorado AI Act, and NYC LL144.

    Usage::

        engine = RetentionPolicyEngine()
        violations = engine.check_retention(
            data_category="credit_decisions",
            created_date=date(2024, 1, 15),
            deleted_date=date(2024, 6, 1),  # too soon!
        )
        for v in violations:
            print(f"{v.severity}: {v.policy_name} - {v.remediation}")

        all_policies = engine.get_policies_for_category("credit_decisions")
    """

    # Pre-loaded regulatory retention policies
    _DEFAULT_POLICIES: List[RetentionPolicy] = [
        RetentionPolicy(
            name="ECOA Record Retention",
            regulation="ECOA / Reg B",
            citation="12 CFR 1002.12(a)",
            min_retention_days=760,  # 25 months
            data_categories=[
                "credit_decisions", "credit_applications",
                "adverse_action_notices", "decision_logs",
            ],
            investigation_hold=True,
            notes="25 months from date of notification or date of action taken.",
        ),
        RetentionPolicy(
            name="ECOA Monitoring Data",
            regulation="ECOA / Reg B",
            citation="12 CFR 1002.12(b)(1)",
            min_retention_days=760,
            data_categories=["hmda_data", "monitoring_information"],
            investigation_hold=True,
        ),
        RetentionPolicy(
            name="SR 11-7 Model Validation Records",
            regulation="SR 11-7",
            citation="SR 11-7 §4",
            min_retention_days=1825,  # 5 years
            data_categories=[
                "model_validation", "model_documentation",
                "validation_reports", "challenger_models",
            ],
            notes="Retained for model lifecycle plus post-retirement review period.",
        ),
        RetentionPolicy(
            name="EU AI Act System Logs",
            regulation="EU AI Act",
            citation="Article 12(2)",
            min_retention_days=1825,  # 5 years minimum
            data_categories=[
                "system_logs", "ai_model_logs", "risk_assessments",
                "conformity_assessments",
            ],
            notes="Retained for duration of system use, minimum set by Member States.",
        ),
        RetentionPolicy(
            name="EU AI Act Technical Documentation",
            regulation="EU AI Act",
            citation="Article 18(1), Annex IV",
            min_retention_days=3650,  # 10 years
            data_categories=[
                "technical_documentation", "design_specifications",
                "quality_management_records",
            ],
            notes="10 years after high-risk AI system is placed on market.",
        ),
        RetentionPolicy(
            name="Colorado AI Act Impact Assessments",
            regulation="Colorado AI Act",
            citation="C.R.S. § 6-1-1704(3)",
            min_retention_days=1095,  # 3 years
            data_categories=[
                "impact_assessments", "risk_management_records",
            ],
            notes="3 years after last deployment of the AI system.",
        ),
        RetentionPolicy(
            name="NYC LL144 Bias Audit Records",
            regulation="NYC Local Law 144",
            citation="NYC Admin. Code § 20-871(a)",
            min_retention_days=1460,  # 4 years
            data_categories=[
                "bias_audits", "audit_summaries",
                "selection_rate_disclosures",
            ],
            notes="At least 4 years per DCWP enforcement guidance.",
        ),
        RetentionPolicy(
            name="BSA/AML Records",
            regulation="Bank Secrecy Act",
            citation="31 CFR 1010.430",
            min_retention_days=1825,  # 5 years
            data_categories=[
                "suspicious_activity_reports", "currency_transaction_reports",
                "customer_identification",
            ],
        ),
    ]

    def __init__(self) -> None:
        self._policies: List[RetentionPolicy] = list(self._DEFAULT_POLICIES)

    def add_policy(self, policy: RetentionPolicy) -> None:
        """Add a custom retention policy."""
        self._policies.append(policy)

    @property
    def policies(self) -> List[RetentionPolicy]:
        """All registered retention policies."""
        return list(self._policies)

    def get_policies_for_category(
        self, data_category: str
    ) -> List[RetentionPolicy]:
        """Get all policies applicable to a data category."""
        return [
            p for p in self._policies
            if data_category in p.data_categories
        ]

    def check_retention(
        self,
        data_category: str,
        created_date: date,
        deleted_date: Optional[date] = None,
        investigation_pending: bool = False,
    ) -> List[RetentionViolation]:
        """Check retention compliance for a specific data record.

        Args:
            data_category: Category of the data.
            created_date: When the data was created.
            deleted_date: When the data was/will be deleted (None = still retained).
            investigation_pending: Whether there's an ongoing investigation.

        Returns:
            List of retention violations found.
        """
        violations: List[RetentionViolation] = []
        today = date.today()
        applicable = self.get_policies_for_category(data_category)

        for policy in applicable:
            if deleted_date:
                retention_days = (deleted_date - created_date).days
            else:
                retention_days = (today - created_date).days

            # Check under-retention (deleted too soon)
            if deleted_date:
                min_days = policy.min_retention_days
                if investigation_pending and policy.investigation_hold:
                    # Investigation extends retention indefinitely
                    violations.append(RetentionViolation(
                        policy_name=policy.name,
                        violation_type="under_retention",
                        data_category=data_category,
                        required_days=min_days,
                        actual_days=retention_days,
                        severity="critical",
                        remediation=(
                            f"Data deleted during pending investigation. "
                            f"{policy.citation} requires retention during "
                            f"investigation. Restore from backup if possible."
                        ),
                    ))
                elif retention_days < min_days:
                    violations.append(RetentionViolation(
                        policy_name=policy.name,
                        violation_type="under_retention",
                        data_category=data_category,
                        required_days=min_days,
                        actual_days=retention_days,
                        severity="critical",
                        remediation=(
                            f"Data retained only {retention_days} days, "
                            f"but {policy.citation} requires {min_days} days "
                            f"minimum. Extend retention period."
                        ),
                    ))

            # Check over-retention (retained beyond maximum)
            if policy.max_retention_days > 0 and not deleted_date:
                if retention_days > policy.max_retention_days:
                    violations.append(RetentionViolation(
                        policy_name=policy.name,
                        violation_type="over_retention",
                        data_category=data_category,
                        required_days=policy.max_retention_days,
                        actual_days=retention_days,
                        severity="warning",
                        remediation=(
                            f"Data retained {retention_days} days, "
                            f"exceeding maximum of {policy.max_retention_days} "
                            f"days. Consider secure disposal."
                        ),
                    ))

        return violations

    def generate_report(self) -> Dict[str, Any]:
        """Generate a report of all retention policies."""
        by_regulation: Dict[str, List[Dict[str, Any]]] = {}
        for p in self._policies:
            by_regulation.setdefault(p.regulation, []).append(p.to_dict())

        return {
            "total_policies": len(self._policies),
            "by_regulation": by_regulation,
            "policies": [p.to_dict() for p in self._policies],
        }
