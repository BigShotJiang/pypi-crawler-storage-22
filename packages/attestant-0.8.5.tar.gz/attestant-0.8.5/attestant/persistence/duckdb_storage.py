"""
DuckDB storage backend for Attestant provenance.

DuckDB is an embedded columnar analytical database -- like SQLite but
optimised for OLAP workloads.  It is increasingly popular in ML / data
engineering pipelines and provides excellent query performance on
provenance audit trails.

The ``duckdb`` package is imported lazily at connect time so that this
module never introduces a hard dependency for users who only need SQLite
or PostgreSQL.

Usage:
    from attestant.persistence.duckdb_storage import DuckDBStorage

    storage = DuckDBStorage("./provenance.duckdb")
    storage.connect()

    # Or use as a context manager:
    with DuckDBStorage(":memory:") as storage:
        pid = storage.create_pipeline("demo")
        ...
"""

import json
import logging
from typing import Any, Dict, List, Optional, Tuple

from .storage import StorageBackend, StoredEdge, StoredNode, StoredRowValue

logger = logging.getLogger(__name__)


class DuckDBStorage(StorageBackend):
    """
    DuckDB storage backend for provenance persistence.

    Implements the same ``StorageBackend`` interface as ``SQLiteStorage``
    and ``PostgreSQLStorage`` but backed by DuckDB.

    Features:
    - Columnar storage -- fast analytical queries over large audit trails
    - Zero-config embedded engine (no server process)
    - File-based or in-memory operation
    - Same schema as the SQLite / PostgreSQL backends
    """

    def __init__(self, db_path: str = ":memory:"):
        """
        Initialise DuckDB storage.

        Args:
            db_path: Path to the DuckDB database file.
                     ``":memory:"`` for an in-memory database (default).
                     ``"./provenance.duckdb"`` for a persistent file.
        """
        self.db_path = db_path
        self._duckdb = None  # lazily imported module reference
        self.conn = None

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Import duckdb lazily, open the connection, and create tables."""
        if self._duckdb is None:
            try:
                import duckdb
            except ImportError:
                raise ImportError(
                    "DuckDBStorage requires the duckdb package. "
                    "Install with: pip install duckdb"
                )
            self._duckdb = duckdb

        self.conn = self._duckdb.connect(self.db_path)
        self._init_schema()

    def disconnect(self) -> None:
        """Close the DuckDB connection."""
        if self.conn is not None:
            try:
                self.conn.close()
            except Exception:
                pass
            self.conn = None

    def __enter__(self):
        """Context manager entry -- connects if not already connected."""
        if self.conn is None:
            self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit -- disconnects."""
        self.disconnect()
        return False

    def __del__(self):
        """Ensure connection is closed on garbage collection."""
        try:
            self.disconnect()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Schema initialisation
    # ------------------------------------------------------------------

    def _ensure_connected(self) -> None:
        """Raise if not connected."""
        if self.conn is None:
            raise RuntimeError("Not connected to database")

    def _init_schema(self) -> None:
        """Create tables and indexes matching the SQLite / PG schema."""
        self._ensure_connected()

        self.conn.execute("""
            CREATE SEQUENCE IF NOT EXISTS seq_dag_nodes START 1
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS dag_nodes (
                node_id INTEGER PRIMARY KEY DEFAULT nextval('seq_dag_nodes'),
                fingerprint BIGINT NOT NULL,
                node_type VARCHAR NOT NULL,
                operation VARCHAR NOT NULL,
                table_name VARCHAR,
                column_name VARCHAR,
                pair_id BIGINT,
                is_protected INTEGER DEFAULT 0,
                entity_hash BIGINT,
                chain_hash BIGINT,
                metadata VARCHAR,
                created_at TIMESTAMP DEFAULT current_timestamp,
                pipeline_id INTEGER,
                tenant_id VARCHAR,
                UNIQUE(fingerprint, pipeline_id, tenant_id)
            )
        """)

        self.conn.execute("""
            CREATE SEQUENCE IF NOT EXISTS seq_dag_edges START 1
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS dag_edges (
                edge_id INTEGER PRIMARY KEY DEFAULT nextval('seq_dag_edges'),
                parent_node_id INTEGER NOT NULL,
                child_node_id INTEGER NOT NULL,
                input_position INTEGER DEFAULT 0,
                UNIQUE(parent_node_id, child_node_id, input_position),
                FOREIGN KEY (parent_node_id) REFERENCES dag_nodes(node_id),
                FOREIGN KEY (child_node_id) REFERENCES dag_nodes(node_id)
            )
        """)

        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS source_registry (
                pair_id INTEGER PRIMARY KEY,
                table_name VARCHAR NOT NULL,
                column_name VARCHAR NOT NULL,
                is_protected INTEGER DEFAULT 0,
                registered_at TIMESTAMP DEFAULT current_timestamp,
                UNIQUE(table_name, column_name)
            )
        """)

        self.conn.execute("""
            CREATE SEQUENCE IF NOT EXISTS seq_pipeline_metadata START 1
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS pipeline_metadata (
                pipeline_id INTEGER PRIMARY KEY DEFAULT nextval('seq_pipeline_metadata'),
                pipeline_name VARCHAR,
                tenant_id VARCHAR,
                started_at TIMESTAMP DEFAULT current_timestamp,
                completed_at TIMESTAMP,
                status VARCHAR,
                config VARCHAR,
                git_commit VARCHAR,
                environment VARCHAR
            )
        """)

        self.conn.execute("""
            CREATE SEQUENCE IF NOT EXISTS seq_pipeline_results START 1
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS pipeline_results (
                result_id INTEGER PRIMARY KEY DEFAULT nextval('seq_pipeline_results'),
                pipeline_id INTEGER NOT NULL,
                row_key VARCHAR NOT NULL,
                output_name VARCHAR NOT NULL,
                fingerprint BIGINT NOT NULL,
                output_value DOUBLE,
                input_hash VARCHAR,
                created_at TIMESTAMP DEFAULT current_timestamp,
                FOREIGN KEY (pipeline_id) REFERENCES pipeline_metadata(pipeline_id)
            )
        """)

        self.conn.execute("""
            CREATE SEQUENCE IF NOT EXISTS seq_row_values START 1
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS row_values (
                value_id INTEGER PRIMARY KEY DEFAULT nextval('seq_row_values'),
                pipeline_id INTEGER NOT NULL,
                row_index INTEGER NOT NULL,
                fingerprint BIGINT NOT NULL,
                node_operation VARCHAR NOT NULL,
                column_name VARCHAR,
                value DOUBLE,
                tenant_id VARCHAR,
                created_at TIMESTAMP DEFAULT current_timestamp,
                FOREIGN KEY (pipeline_id) REFERENCES pipeline_metadata(pipeline_id)
            )
        """)

        # -- Indexes (DuckDB does not support partial indexes, so we
        #    create regular ones instead) --------------------------------

        self._create_index_if_missing(
            "idx_dn_tenant", "dag_nodes", "tenant_id")
        self._create_index_if_missing(
            "idx_dn_tenant_fp", "dag_nodes", "tenant_id, fingerprint")
        self._create_index_if_missing(
            "idx_dn_tenant_prot", "dag_nodes", "tenant_id, is_protected")
        self._create_index_if_missing(
            "idx_dn_tenant_src", "dag_nodes",
            "tenant_id, table_name, column_name")
        self._create_index_if_missing(
            "idx_dn_tenant_created", "dag_nodes", "tenant_id, created_at")
        self._create_index_if_missing(
            "idx_dn_fingerprint", "dag_nodes", "fingerprint")
        self._create_index_if_missing(
            "idx_de_parent", "dag_edges", "parent_node_id")
        self._create_index_if_missing(
            "idx_de_child", "dag_edges", "child_node_id")
        self._create_index_if_missing(
            "idx_pr_row", "pipeline_results", "pipeline_id, row_key")
        self._create_index_if_missing(
            "idx_pr_fp", "pipeline_results", "pipeline_id, fingerprint")
        self._create_index_if_missing(
            "idx_rv_pipeline_row", "row_values", "pipeline_id, row_index")
        self._create_index_if_missing(
            "idx_rv_tenant_pipeline", "row_values", "tenant_id, pipeline_id")

    def _create_index_if_missing(self, name: str, table: str,
                                 columns: str) -> None:
        """Create an index only if it does not already exist.

        DuckDB supports ``CREATE INDEX IF NOT EXISTS`` for regular
        (non-partial) indexes, so we use that directly.
        """
        self.conn.execute(
            f"CREATE INDEX IF NOT EXISTS {name} ON {table} ({columns})"
        )

    # ------------------------------------------------------------------
    # Pipeline lifecycle
    # ------------------------------------------------------------------

    def create_pipeline(self, pipeline_name: str,
                        config: Optional[Dict[str, Any]] = None,
                        git_commit: Optional[str] = None,
                        tenant_id: Optional[str] = None) -> int:
        """Create a pipeline execution record and return its id."""
        self._ensure_connected()

        result = self.conn.execute("""
            INSERT INTO pipeline_metadata
                (pipeline_name, config, git_commit, status, tenant_id)
            VALUES (?, ?, ?, 'running', ?)
            RETURNING pipeline_id
        """, [
            pipeline_name,
            json.dumps(config) if config else None,
            git_commit,
            tenant_id,
        ])
        row = result.fetchone()
        return row[0]

    def complete_pipeline(self, pipeline_id: int,
                          status: str = 'completed') -> None:
        """Mark a pipeline as completed or failed."""
        self._ensure_connected()

        self.conn.execute("""
            UPDATE pipeline_metadata
            SET status = ?, completed_at = current_timestamp
            WHERE pipeline_id = ?
        """, [status, pipeline_id])

    # ------------------------------------------------------------------
    # DAG storage
    # ------------------------------------------------------------------

    def store_nodes(self, nodes: List[StoredNode]) -> None:
        """Store DAG nodes in batch using executemany."""
        if not nodes:
            return
        self._ensure_connected()

        node_tuples = [
            (
                node.fingerprint,
                node.node_type,
                node.operation,
                node.table_name,
                node.column_name,
                node.pair_id,
                1 if node.is_protected else 0,
                node.entity_hash,
                node.chain_hash,
                json.dumps(node.metadata) if node.metadata else None,
                node.pipeline_id,
                getattr(node, 'tenant_id', None),
            )
            for node in nodes
        ]
        self.conn.executemany("""
            INSERT INTO dag_nodes (
                fingerprint, node_type, operation,
                table_name, column_name, pair_id, is_protected,
                entity_hash, chain_hash, metadata, pipeline_id, tenant_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT DO NOTHING
        """, node_tuples)

    def store_edges(self, edges: List[StoredEdge]) -> None:
        """Store DAG edges in batch.

        Resolves fingerprints to node_ids using a single lookup query,
        then inserts all edges in one executemany call.
        """
        if not edges:
            return
        self._ensure_connected()

        fingerprints = set()
        for edge in edges:
            fingerprints.add(edge.parent_fingerprint)
            fingerprints.add(edge.child_fingerprint)

        placeholders = ', '.join('?' * len(fingerprints))
        result = self.conn.execute(
            f"SELECT fingerprint, node_id FROM dag_nodes "
            f"WHERE fingerprint IN ({placeholders})",
            list(fingerprints),
        )
        fp_to_id: Dict[int, int] = {}
        for row in result.fetchall():
            fp_to_id[row[0]] = row[1]

        edge_tuples = []
        for edge in edges:
            parent_id = fp_to_id.get(edge.parent_fingerprint)
            child_id = fp_to_id.get(edge.child_fingerprint)
            if parent_id is not None and child_id is not None:
                edge_tuples.append((parent_id, child_id, edge.input_position))

        if edge_tuples:
            self.conn.executemany("""
                INSERT INTO dag_edges
                    (parent_node_id, child_node_id, input_position)
                VALUES (?, ?, ?)
                ON CONFLICT DO NOTHING
            """, edge_tuples)

    def store_edges_resolved(self,
                             edges: List[Tuple[int, int, int]]) -> None:
        """Store edges with already-resolved node IDs."""
        if not edges:
            return
        self._ensure_connected()

        self.conn.executemany("""
            INSERT INTO dag_edges
                (parent_node_id, child_node_id, input_position)
            VALUES (?, ?, ?)
            ON CONFLICT DO NOTHING
        """, edges)

    # ------------------------------------------------------------------
    # Source registry
    # ------------------------------------------------------------------

    def register_source(self, pair_id: int, table: str, column: str,
                        is_protected: bool = False) -> None:
        """Register a source (table, column) pair.

        Uses ``ON CONFLICT ... DO UPDATE`` to upsert, matching SQLite's
        ``INSERT OR REPLACE`` behaviour.
        """
        self._ensure_connected()

        self.conn.execute("""
            INSERT INTO source_registry
                (pair_id, table_name, column_name, is_protected)
            VALUES (?, ?, ?, ?)
            ON CONFLICT (pair_id) DO UPDATE SET
                table_name = EXCLUDED.table_name,
                column_name = EXCLUDED.column_name,
                is_protected = EXCLUDED.is_protected
        """, [pair_id, table, column, 1 if is_protected else 0])

    # ------------------------------------------------------------------
    # Query methods
    # ------------------------------------------------------------------

    def get_node_by_fingerprint(self, fingerprint: int,
                                pipeline_id: Optional[int] = None
                                ) -> Optional[Dict[str, Any]]:
        """Retrieve a node by its fingerprint."""
        self._ensure_connected()

        if pipeline_id is not None:
            result = self.conn.execute("""
                SELECT node_id, fingerprint, node_type, operation,
                       table_name, column_name, pair_id, is_protected,
                       entity_hash, chain_hash, metadata
                FROM dag_nodes
                WHERE fingerprint = ? AND pipeline_id = ?
            """, [fingerprint, pipeline_id])
        else:
            result = self.conn.execute("""
                SELECT node_id, fingerprint, node_type, operation,
                       table_name, column_name, pair_id, is_protected,
                       entity_hash, chain_hash, metadata
                FROM dag_nodes
                WHERE fingerprint = ?
                ORDER BY created_at DESC
                LIMIT 1
            """, [fingerprint])

        row = result.fetchone()
        if row is None:
            return None

        return {
            'node_id': row[0],
            'fingerprint': row[1],
            'node_type': row[2],
            'operation': row[3],
            'table_name': row[4],
            'column_name': row[5],
            'pair_id': row[6],
            'is_protected': bool(row[7]),
            'entity_hash': row[8],
            'chain_hash': row[9],
            'metadata': json.loads(row[10]) if row[10] else None,
        }

    def get_edges_for_node(self, node_id: int) -> List[Dict[str, Any]]:
        """Get all parent edges for a node (inputs to this computation)."""
        self._ensure_connected()

        result = self.conn.execute("""
            SELECT e.parent_node_id, e.input_position, n.fingerprint
            FROM dag_edges e
            JOIN dag_nodes n ON e.parent_node_id = n.node_id
            WHERE e.child_node_id = ?
            ORDER BY e.input_position
        """, [node_id])

        return [
            {
                'parent_node_id': row[0],
                'input_position': row[1],
                'parent_fingerprint': row[2],
            }
            for row in result.fetchall()
        ]

    def get_fingerprint_node_map(self, pipeline_id: int) -> Dict[int, int]:
        """Return {fingerprint: node_id} for all nodes in a pipeline."""
        self._ensure_connected()

        result = self.conn.execute(
            "SELECT fingerprint, node_id FROM dag_nodes WHERE pipeline_id = ?",
            [pipeline_id],
        )
        return {row[0]: row[1] for row in result.fetchall()}

    def get_source_info(self, pair_id: int
                        ) -> Optional[Tuple[str, str, bool]]:
        """Get (table, column, is_protected) for a pair_id."""
        self._ensure_connected()

        result = self.conn.execute("""
            SELECT table_name, column_name, is_protected
            FROM source_registry
            WHERE pair_id = ?
        """, [pair_id])

        row = result.fetchone()
        if row:
            return (row[0], row[1], bool(row[2]))
        return None

    # ------------------------------------------------------------------
    # Per-row values (value-level lineage)
    # ------------------------------------------------------------------

    def store_row_values(self, values: List[StoredRowValue]) -> None:
        """Store per-row values at DAG nodes."""
        if not values:
            return
        self._ensure_connected()

        self.conn.executemany("""
            INSERT INTO row_values
                (pipeline_id, row_index, fingerprint, node_operation,
                 column_name, value, tenant_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, [
            (v.pipeline_id, v.row_index, v.fingerprint,
             v.node_operation, v.column_name, v.value, v.tenant_id)
            for v in values
        ])

    def get_row_values(self, pipeline_id: int,
                       row_index: int) -> List[Dict[str, Any]]:
        """Retrieve all values for a specific row in a pipeline."""
        self._ensure_connected()

        result = self.conn.execute("""
            SELECT fingerprint, node_operation, column_name, value
            FROM row_values
            WHERE pipeline_id = ? AND row_index = ?
            ORDER BY value_id
        """, [pipeline_id, row_index])

        return [
            {
                'fingerprint': row[0],
                'node_operation': row[1],
                'column_name': row[2],
                'value': row[3],
            }
            for row in result.fetchall()
        ]

    # ------------------------------------------------------------------
    # Per-row results (audit trail)
    # ------------------------------------------------------------------

    def store_results(self, pipeline_id: int,
                      results: List[tuple]) -> None:
        """Store per-row output fingerprints for audit.

        Args:
            pipeline_id: Pipeline execution ID.
            results: List of (row_key, output_name, fingerprint,
                     output_value, input_hash) tuples.
        """
        if not results:
            return
        self._ensure_connected()

        rows = [(pipeline_id, *row) for row in results]
        self.conn.executemany("""
            INSERT INTO pipeline_results
                (pipeline_id, row_key, output_name, fingerprint,
                 output_value, input_hash)
            VALUES (?, ?, ?, ?, ?, ?)
        """, rows)

    def get_results_for_row(self, row_key: str,
                            pipeline_id: Optional[int] = None
                            ) -> List[Dict[str, Any]]:
        """Look up provenance results for a specific row."""
        self._ensure_connected()

        if pipeline_id is not None:
            result = self.conn.execute("""
                SELECT r.output_name, r.fingerprint, r.output_value,
                       r.pipeline_id, n.node_id, n.node_type, n.operation,
                       n.is_protected
                FROM pipeline_results r
                LEFT JOIN dag_nodes n
                    ON r.fingerprint = n.fingerprint
                   AND r.pipeline_id = n.pipeline_id
                WHERE r.row_key = ? AND r.pipeline_id = ?
                ORDER BY r.output_name
            """, [row_key, pipeline_id])
        else:
            result = self.conn.execute("""
                SELECT r.output_name, r.fingerprint, r.output_value,
                       r.pipeline_id, n.node_id, n.node_type, n.operation,
                       n.is_protected
                FROM pipeline_results r
                LEFT JOIN dag_nodes n
                    ON r.fingerprint = n.fingerprint
                   AND r.pipeline_id = n.pipeline_id
                WHERE r.row_key = ?
                ORDER BY r.pipeline_id DESC, r.output_name
            """, [row_key])

        return [
            {
                'output_name': row[0],
                'fingerprint': row[1],
                'output_value': row[2],
                'pipeline_id': row[3],
                'node_id': row[4],
                'node_type': row[5],
                'operation': row[6],
                'is_protected': bool(row[7]) if row[7] is not None else None,
            }
            for row in result.fetchall()
        ]

    # ------------------------------------------------------------------
    # Dashboard / stats
    # ------------------------------------------------------------------

    def get_stats(self) -> Dict[str, Any]:
        """Return counts of nodes, edges, sources, results, etc."""
        self._ensure_connected()

        def _count(table: str) -> int:
            return self.conn.execute(
                f"SELECT COUNT(*) FROM {table}"
            ).fetchone()[0]

        return {
            'nodes': _count('dag_nodes'),
            'edges': _count('dag_edges'),
            'sources': _count('source_registry'),
            'protected_nodes': self.conn.execute(
                "SELECT COUNT(*) FROM dag_nodes WHERE is_protected = 1"
            ).fetchone()[0],
            'pipelines': _count('pipeline_metadata'),
            'results': _count('pipeline_results'),
            'row_values': _count('row_values'),
        }

    # ------------------------------------------------------------------
    # Extra convenience methods (matching SQLiteStorage)
    # ------------------------------------------------------------------

    def get_all_pipelines(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get all pipelines (for dashboard)."""
        self._ensure_connected()

        result = self.conn.execute("""
            SELECT pipeline_id, pipeline_name, tenant_id, started_at,
                   completed_at, status
            FROM pipeline_metadata
            ORDER BY started_at DESC
            LIMIT ?
        """, [limit])

        return [
            {
                'pipeline_id': row[0],
                'pipeline_name': str(row[1]) if row[1] else None,
                'tenant_id': str(row[2]) if row[2] else None,
                'started_at': str(row[3]) if row[3] else None,
                'completed_at': str(row[4]) if row[4] else None,
                'status': str(row[5]) if row[5] else None,
            }
            for row in result.fetchall()
        ]

    def get_recent_nodes(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent nodes (for dashboard)."""
        self._ensure_connected()

        result = self.conn.execute("""
            SELECT node_id, fingerprint, node_type, operation,
                   table_name, column_name, is_protected, created_at
            FROM dag_nodes
            ORDER BY created_at DESC
            LIMIT ?
        """, [limit])

        return [
            {
                'node_id': row[0],
                'fingerprint': row[1],
                'node_type': str(row[2]) if row[2] else None,
                'operation': str(row[3]) if row[3] else None,
                'table_name': str(row[4]) if row[4] else None,
                'column_name': str(row[5]) if row[5] else None,
                'is_protected': bool(row[6]),
                'created_at': str(row[7]) if row[7] else None,
            }
            for row in result.fetchall()
        ]
