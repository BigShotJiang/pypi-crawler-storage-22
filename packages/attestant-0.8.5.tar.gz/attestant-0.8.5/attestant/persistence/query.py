"""
Query and reconstruction API for stored provenance.

Enables "3 years later" litigation queries: reconstruct the full DAG
from a fingerprint stored in the database.
"""

from typing import Optional, List, Dict, Any, Set
from dataclasses import dataclass
import logging

from .storage import StorageBackend, PostgreSQLStorage
from ..hydra24_dag import ComputationDAG, DAGNode, DAGEdge, NodeType


logger = logging.getLogger(__name__)


def reconstruct_dag(
    fingerprint: int,
    connection: str,
    pipeline_id: Optional[int] = None,
    cache: bool = True
) -> Optional[ComputationDAG]:
    """
    Reconstruct a complete DAG from a stored fingerprint.

    This is the key function for litigation: given a fingerprint from
    a 3-year-old prediction, rebuild the entire computation graph.

    Args:
        fingerprint: 24-bit provenance fingerprint
        connection: Database connection string
        pipeline_id: Optional pipeline ID (uses most recent if None)
        cache: Cache nodes during reconstruction (faster for deep DAGs)

    Returns:
        ComputationDAG object, or None if fingerprint not found

    Example:
        # 3 years later, lawsuit filed
        dag = reconstruct_dag(
            fingerprint=0x401B01,
            connection="postgresql://localhost/hydra24"
        )

        if dag:
            print(f"Protected data used: {dag.has_protected}")
            print(f"Sources: {dag.source_nodes}")
            print(f"Depth: {dag.depth}")

            # Export for court evidence
            with open('evidence.json', 'w') as f:
                f.write(dag.to_json())
    """
    storage = PostgreSQLStorage(connection)
    storage.connect()

    try:
        # Get root node
        root_data = storage.get_node_by_fingerprint(fingerprint, pipeline_id)
        if root_data is None:
            logger.warning(f"Fingerprint {hex(fingerprint)} not found in database")
            return None

        # Build DAG by traversing edges
        reconstructor = DAGReconstructor(storage, cache=cache)
        dag = reconstructor.reconstruct(root_data)

        return dag

    finally:
        storage.disconnect()


def query_by_fingerprint(
    fingerprint: int,
    connection: str,
    pipeline_id: Optional[int] = None
) -> Optional[Dict[str, Any]]:
    """
    Query basic info about a fingerprint without full DAG reconstruction.

    Faster than reconstruct_dag if you only need immediate parent info.

    Returns:
        Dictionary with node info, or None if not found
    """
    storage = PostgreSQLStorage(connection)
    storage.connect()

    try:
        return storage.get_node_by_fingerprint(fingerprint, pipeline_id)
    finally:
        storage.disconnect()


def query_by_source(
    table: str,
    column: str,
    connection: str,
    limit: int = 100
) -> List[Dict[str, Any]]:
    """
    Find all computations that used a specific source column.

    Useful for impact analysis: "What predictions were influenced by this data?"

    Args:
        table: Source table name
        column: Source column name
        connection: Database connection string
        limit: Max results to return

    Returns:
        List of node dictionaries

    Example:
        # Find all predictions that used 'age' column
        nodes = query_by_source(
            table='demographics.csv',
            column='age',
            connection="postgresql://..."
        )
        print(f"Found {len(nodes)} nodes using age data")
    """
    storage = PostgreSQLStorage(connection)
    storage.connect()

    try:
        conn = storage._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT DISTINCT fingerprint, node_type, operation,
                           is_protected, created_at
                    FROM dag_nodes
                    WHERE table_name = %s AND column_name = %s
                    ORDER BY created_at DESC
                    LIMIT %s
                    """,
                    (table, column, limit)
                )

                return [
                    {
                        'fingerprint': row[0],
                        'node_type': row[1],
                        'operation': row[2],
                        'is_protected': row[3],
                        'created_at': row[4],
                    }
                    for row in cur.fetchall()
                ]
        finally:
            storage._put_conn(conn)
    finally:
        storage.disconnect()


def query_protected_data_usage(
    connection: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    limit: int = 1000
) -> List[Dict[str, Any]]:
    """
    Find all computations that used protected data.

    Critical for compliance auditing: "Show me every prediction influenced
    by protected attributes in Q4 2025."

    Args:
        connection: Database connection string
        start_date: Start timestamp (ISO format)
        end_date: End timestamp (ISO format)
        limit: Max results

    Returns:
        List of nodes that have protected data in their lineage

    Example:
        # Compliance audit
        protected_usage = query_protected_data_usage(
            connection="postgresql://...",
            start_date="2025-10-01",
            end_date="2025-12-31"
        )
        print(f"⚠ {len(protected_usage)} predictions used protected data")
    """
    storage = PostgreSQLStorage(connection)
    storage.connect()

    try:
        conn = storage._get_conn()
        try:
            with conn.cursor() as cur:
                query = """
                    SELECT fingerprint, table_name, column_name, created_at
                    FROM dag_nodes
                    WHERE is_protected = TRUE
                """
                params = []

                if start_date:
                    query += " AND created_at >= %s"
                    params.append(start_date)

                if end_date:
                    query += " AND created_at <= %s"
                    params.append(end_date)

                query += " ORDER BY created_at DESC LIMIT %s"
                params.append(limit)

                cur.execute(query, params)

                return [
                    {
                        'fingerprint': row[0],
                        'table': row[1],
                        'column': row[2],
                        'timestamp': row[3],
                    }
                    for row in cur.fetchall()
                ]
        finally:
            storage._put_conn(conn)
    finally:
        storage.disconnect()


class DAGReconstructor:
    """
    Reconstructs computation DAGs from stored nodes and edges.

    Uses depth-first traversal with caching to efficiently rebuild
    large computation graphs.
    """

    def __init__(self, storage: StorageBackend, cache: bool = True):
        self.storage = storage
        self.cache_enabled = cache
        self._node_cache: Dict[int, DAGNode] = {}  # node_id -> DAGNode
        self._visited: Set[int] = set()

    def reconstruct(self, root_data: Dict[str, Any]) -> ComputationDAG:
        """
        Reconstruct DAG starting from root node.

        Args:
            root_data: Root node data from database

        Returns:
            Complete ComputationDAG
        """
        # Convert stored node to DAGNode
        root_node = self._build_dag_node(root_data)

        # Recursively build parent nodes
        self._reconstruct_parents(root_node, root_data['node_id'])

        # Build ComputationDAG
        dag = ComputationDAG(
            root_fingerprint=root_node.provenance,
            nodes={root_node.node_id: root_node},
            edges=[]
        )

        # Add all cached nodes
        for node_id, node in self._node_cache.items():
            if node_id != root_node.node_id:
                dag.nodes[node_id] = node

        # Collect edges
        dag.edges = self._collect_edges()

        # Compute derived properties
        dag._compute_properties()

        return dag

    def _build_dag_node(self, node_data: Dict[str, Any]) -> DAGNode:
        """Convert database node data to DAGNode object."""
        node_type_str = node_data['node_type']
        node_type = NodeType[node_type_str] if hasattr(NodeType, node_type_str) else NodeType.CUSTOM

        return DAGNode(
            node_id=node_data['node_id'],
            node_type=node_type,
            operation=node_data['operation'],
            inputs=[],  # Will be filled during reconstruction
            provenance=node_data['fingerprint'],
            metadata=node_data.get('metadata', {}),
            table=node_data.get('table_name'),
            column=node_data.get('column_name'),
            pair_id=node_data.get('pair_id'),
            is_protected=node_data.get('is_protected', False),
        )

    def _reconstruct_parents(self, node: DAGNode, node_id: int) -> None:
        """
        Recursively reconstruct parent nodes (inputs).

        Uses depth-first traversal.
        """
        if node_id in self._visited:
            return

        self._visited.add(node_id)

        # Get parent edges
        edges = self.storage.get_edges_for_node(node_id)

        for edge_data in edges:
            parent_id = edge_data['parent_node_id']

            # Check cache
            if self.cache_enabled and parent_id in self._node_cache:
                parent_node = self._node_cache[parent_id]
            else:
                # Load from database
                parent_data = self.storage.get_node_by_fingerprint(
                    edge_data['parent_fingerprint']
                )
                if parent_data is None:
                    logger.warning(f"Parent node {parent_id} not found")
                    continue

                parent_node = self._build_dag_node(parent_data)

                # Recursively reconstruct its parents
                self._reconstruct_parents(parent_node, parent_id)

                # Cache
                if self.cache_enabled:
                    self._node_cache[parent_id] = parent_node

            # Add to inputs
            node.inputs.append(parent_id)

        # Cache this node
        if self.cache_enabled:
            self._node_cache[node_id] = node

    def _collect_edges(self) -> List[DAGEdge]:
        """Collect all edges from cached nodes."""
        edges = []
        for node_id, node in self._node_cache.items():
            for input_id in node.inputs:
                edges.append(DAGEdge(
                    source=input_id,
                    target=node_id
                ))
        return edges


def export_dag_to_json_file(
    fingerprint: int,
    connection: str,
    output_path: str,
    pipeline_id: Optional[int] = None
) -> bool:
    """
    Export a reconstructed DAG to JSON file.

    Convenient for generating evidence files.

    Args:
        fingerprint: Provenance fingerprint
        connection: Database connection
        output_path: Output file path
        pipeline_id: Optional pipeline ID

    Returns:
        True if successful, False if fingerprint not found

    Example:
        export_dag_to_json_file(
            fingerprint=0x401B01,
            connection="postgresql://...",
            output_path="evidence-case-12345.json"
        )
    """
    dag = reconstruct_dag(fingerprint, connection, pipeline_id)
    if dag is None:
        return False

    with open(output_path, 'w') as f:
        f.write(dag.to_json())

    return True
