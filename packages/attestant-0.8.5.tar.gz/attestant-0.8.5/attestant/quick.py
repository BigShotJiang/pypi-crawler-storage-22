"""
One-call fairness analysis for bank ML workflows.

Provides ``analyze()`` — the simplest possible path from a model file
and a data file to a complete regulatory compliance report.

Usage:
    import attestant

    report = attestant.analyze(
        model="credit_model.pkl",
        data="applications.csv",
        protected=["race", "sex", "age"],
    )
    report.save("fairness_report.pdf")
    report.save("fairness_report.docx")
    report.save("fairness_report.json")
"""

import logging
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def analyze(
    model: Union[str, Any],
    data: Union[str, pd.DataFrame],
    protected: Union[List[str], str],
    target: Optional[str] = None,
    industry: Optional[str] = None,
    test_size: float = 0.3,
    model_name: Optional[str] = None,
    model_version: str = "",
    run_lda: bool = True,
    run_adverse_action: bool = True,
    random_state: int = 42,
) -> "AnalysisResult":
    """Run complete fairness analysis on a model and dataset.

    This is the primary entry point for bank data scientists. It
    handles model loading, data splitting, and orchestrates the
    full FairLens analysis pipeline.

    Args:
        model: Path to a saved model file (pickle, joblib, ONNX,
            PyTorch, TensorFlow) or a live model object.
        data: Path to a data file (CSV, Parquet, SAS, Excel, etc.)
            or an existing pandas DataFrame.
        protected: List of protected attribute column names, or a
            comma-separated string (e.g., ``"race,sex,age"``).
        target: Name of the target/label column. Auto-detected if
            not specified (looks for 'target', 'label', 'approved',
            'default', 'y', 'outcome', 'decision').
        industry: Industry preset for regulatory framework. One of:
            'lending', 'hiring', 'insurance', 'housing',
            'healthcare', 'education', 'general'.
        test_size: Fraction of data to use for testing (default 0.3).
        model_name: Human-readable model name for reports.
        model_version: Semantic version for SR 11-7 audit trail.
        run_lda: Whether to search for less discriminatory
            alternatives (default True).
        run_adverse_action: Whether to generate adverse action reason
            codes (default True).
        random_state: Random seed for reproducible train/test split.

    Returns:
        An ``AnalysisResult`` with the full report. Call
        ``.save("report.pdf")`` or ``.save("report.docx")`` to
        export.

    Examples:
        >>> report = attestant.analyze(
        ...     model="credit_model.pkl",
        ...     data="applications.csv",
        ...     protected=["race", "sex"],
        ...     industry="lending",
        ... )
        >>> print(report)
        >>> report.save("fairness_report.pdf")
    """
    from .loader import load_model, load_data
    from .fairness.engine import FairLensEngine, FairLensConfig

    # ── Load model ──────────────────────────────────────────────────────
    if isinstance(model, str):
        loaded_model = load_model(model)
        if model_name is None:
            model_name = Path(model).stem
    else:
        loaded_model = model
        if model_name is None:
            model_name = type(model).__name__

    # ── Load data ───────────────────────────────────────────────────────
    if isinstance(data, str):
        df = load_data(data)
    elif isinstance(data, pd.DataFrame):
        df = data
    else:
        raise ValueError(
            "data must be a file path (str) or a pandas DataFrame"
        )

    # ── Parse protected columns ─────────────────────────────────────────
    if isinstance(protected, str):
        protected_cols = [c.strip() for c in protected.split(",")]
    else:
        protected_cols = list(protected)

    # ── Detect target column ────────────────────────────────────────────
    if target is None:
        target = _guess_target(df)
    if target not in df.columns:
        raise ValueError(
            f"Target column '{target}' not found in data. "
            f"Available columns: {list(df.columns)[:20]}"
        )

    # ── Build config ────────────────────────────────────────────────────
    config = FairLensConfig(
        protected_columns=protected_cols,
        run_lda_search=run_lda,
        run_adverse_action=run_adverse_action,
        industry=industry,
    )
    engine = FairLensEngine(config=config)

    # The engine may have expanded protected_columns via industry preset.
    # Only analyze columns actually present in the data.
    available_protected = [
        c for c in config.protected_columns if c in df.columns
    ]
    missing = [c for c in config.protected_columns if c not in df.columns]
    if missing:
        logger.warning(
            "Protected columns not in data (skipped): %s", ", ".join(missing)
        )
    config.protected_columns = available_protected

    if not available_protected:
        raise ValueError(
            f"None of the protected columns {protected_cols} were found "
            f"in the data. Available columns: {list(df.columns)[:20]}"
        )

    # ── Determine feature columns ───────────────────────────────────────
    if hasattr(loaded_model, "feature_names_in_"):
        feature_cols = list(loaded_model.feature_names_in_)
        missing_feats = [c for c in feature_cols if c not in df.columns]
        if missing_feats:
            raise ValueError(
                f"Model expects features not found in data: {missing_feats}. "
                f"Available columns: {list(df.columns)[:20]}"
            )
    else:
        feature_cols = [
            c for c in df.columns
            if c != target and c not in available_protected
        ]

    # ── Validate target ─────────────────────────────────────────────────
    y = df[target].values
    if pd.isna(y).any():
        n_missing = int(pd.isna(y).sum())
        raise ValueError(
            f"Target column '{target}' has {n_missing} missing values. "
            f"Remove or impute NaN rows before analysis."
        )

    # ── Handle non-numeric features ─────────────────────────────────────
    X = df[feature_cols].copy()
    object_cols = X.select_dtypes(include=["object", "category"]).columns.tolist()
    if object_cols:
        logger.info(
            "Auto-encoding %d categorical columns: %s",
            len(object_cols),
            ", ".join(object_cols[:10]),
        )
        for col in object_cols:
            X[col] = X[col].astype("category").cat.codes

    # ── Handle NaN in features ──────────────────────────────────────────
    nan_counts = X.isna().sum()
    nan_cols = nan_counts[nan_counts > 0]
    if len(nan_cols) > 0:
        logger.warning(
            "Filling %d NaN values across %d columns with column medians: %s",
            int(nan_cols.sum()),
            len(nan_cols),
            ", ".join(nan_cols.index[:10].tolist()),
        )
        X = X.fillna(X.median(numeric_only=True))
        # Fill any remaining NaN (non-numeric) with 0
        X = X.fillna(0)

    protected_df = df[available_protected]

    # ── Validate dataset size ───────────────────────────────────────────
    min_test = max(30, int(len(X) * test_size))
    if len(X) < 50:
        raise ValueError(
            f"Dataset has only {len(X)} rows — need at least 50 for "
            f"reliable fairness analysis."
        )

    # ── Train/test split ────────────────────────────────────────────────
    try:
        from sklearn.model_selection import train_test_split
        try:
            X_train, X_test, y_train, y_test, _, prot_test = (
                train_test_split(
                    X, y, protected_df,
                    test_size=test_size,
                    random_state=random_state,
                    stratify=y,
                )
            )
        except ValueError:
            X_train, X_test, y_train, y_test, _, prot_test = (
                train_test_split(
                    X, y, protected_df,
                    test_size=test_size,
                    random_state=random_state,
                )
            )
    except ImportError:
        # Shuffle before splitting to avoid order bias
        idx = np.random.RandomState(random_state).permutation(len(X))
        split = int(len(X) * (1 - test_size))
        train_idx, test_idx = idx[:split], idx[split:]
        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        prot_test = protected_df.iloc[test_idx]

    # ── Model factory for LDA search ────────────────────────────────────
    # LDA search requires sklearn-compatible models with .fit()
    from .fairness.model_adapter import detect_framework
    fw = detect_framework(loaded_model)
    model_factory = None
    if run_lda and fw not in ("xgboost_booster", "lightgbm_booster",
                               "pytorch", "tensorflow"):
        if isinstance(model, str):
            _model_path = model

            def model_factory():
                return load_model(_model_path)
        elif hasattr(loaded_model, "fit"):
            model_factory = lambda: type(loaded_model)(
                **loaded_model.get_params()
            ) if hasattr(loaded_model, "get_params") else None

    # ── Run analysis ────────────────────────────────────────────────────
    report = engine.analyze(
        model=loaded_model,
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        protected_data=prot_test,
        model_name=model_name,
        model_factory=model_factory,
        model_version=model_version,
    )

    return AnalysisResult(report=report, model_name=model_name)


def _guess_target(data: pd.DataFrame) -> str:
    """Guess the target column name from common conventions."""
    for name in [
        "target", "label", "approved", "default", "y",
        "outcome", "decision", "is_default", "is_approved",
        "charged_off", "delinquent", "fraud", "is_fraud",
    ]:
        if name in data.columns:
            return name
    return data.columns[-1]


class AnalysisResult:
    """Wraps a FairLensReport with export capabilities.

    Attributes:
        report: The underlying ``FairLensReport`` with all findings.
    """

    def __init__(self, report, model_name: str = "model"):
        self.report = report
        self._model_name = model_name

    @property
    def findings(self):
        return self.report.findings

    @property
    def summary(self):
        return self.report.summary

    @property
    def passed(self) -> bool:
        """True if no critical findings."""
        return self.report.summary.get("critical", 0) == 0

    def to_dict(self) -> Dict[str, Any]:
        return self.report.to_dict()

    def to_json(self, indent: int = 2) -> str:
        return self.report.to_json(indent=indent)

    def save(self, path: str) -> str:
        """Export the analysis report to a file.

        Supported formats (detected from extension):
            - ``.json`` — Full structured report
            - ``.pdf`` — Examiner-ready PDF report
            - ``.docx`` — Word document for model validation teams
            - ``.html`` — Self-contained HTML report

        Args:
            path: Output file path.

        Returns:
            The absolute path of the saved file.
        """
        p = Path(path)
        ext = p.suffix.lower()

        if ext == ".json":
            p.write_text(self.to_json())
        elif ext == ".pdf":
            self._save_pdf(p)
        elif ext == ".docx":
            self._save_docx(p)
        elif ext == ".html":
            self._save_html(p)
        else:
            raise ValueError(
                f"Unsupported export format '{ext}'. "
                f"Use .json, .pdf, .docx, or .html"
            )

        logger.info("Report saved to %s", p)
        return str(p.resolve())

    def _save_pdf(self, path: Path):
        """Generate a PDF compliance report."""
        try:
            from fpdf import FPDF
        except ImportError:
            raise ImportError(
                "fpdf2 is required for PDF export.\n"
                "    pip install provenanced[pdf]"
            )

        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=20)
        pdf.add_page()

        # Title
        pdf.set_font("Helvetica", "B", 18)
        pdf.cell(0, 12, "Algorithmic Fairness Analysis Report", ln=True, align="C")
        pdf.ln(4)

        # Model info
        pdf.set_font("Helvetica", "", 10)
        pdf.set_text_color(100, 100, 100)
        pdf.cell(0, 6, f"Model: {self._model_name}", ln=True)

        import datetime
        ts = datetime.datetime.fromtimestamp(
            self.report.timestamp, tz=datetime.timezone.utc
        )
        pdf.cell(0, 6, f"Generated: {ts.strftime('%Y-%m-%d %H:%M:%S UTC')}", ln=True)
        pdf.cell(0, 6, f"Analysis time: {self.report.analysis_time_seconds:.1f}s", ln=True)

        if self.report.model_identity:
            pdf.cell(
                0, 6,
                f"Model hash: {self.report.model_identity.model_hash[:16]}...",
                ln=True,
            )
        pdf.ln(6)

        # Summary box
        pdf.set_text_color(0, 0, 0)
        pdf.set_font("Helvetica", "B", 14)
        pdf.cell(0, 10, "Executive Summary", ln=True)
        pdf.set_font("Helvetica", "", 11)

        s = self.report.summary
        critical = s.get("critical", 0)
        warnings = s.get("warnings", 0)
        proxies = s.get("proxy_features_detected", 0)

        if critical == 0:
            pdf.set_text_color(0, 128, 0)
            pdf.cell(0, 8, "PASS - No critical fairness issues detected", ln=True)
        else:
            pdf.set_text_color(200, 0, 0)
            pdf.cell(0, 8, f"FAIL - {critical} critical finding(s) require remediation", ln=True)

        pdf.set_text_color(0, 0, 0)
        pdf.cell(0, 7, f"  Warnings: {warnings}", ln=True)
        pdf.cell(0, 7, f"  Proxy features detected: {proxies}", ln=True)
        pdf.ln(6)

        # Findings
        pdf.set_font("Helvetica", "B", 14)
        pdf.cell(0, 10, "Findings", ln=True)

        for f in self.report.findings:
            if f.severity.value == "critical":
                pdf.set_text_color(200, 0, 0)
                tag = "[CRITICAL]"
            elif f.severity.value == "warning":
                pdf.set_text_color(180, 130, 0)
                tag = "[WARNING]"
            else:
                pdf.set_text_color(0, 100, 180)
                tag = "[INFO]"

            pdf.set_font("Helvetica", "B", 10)
            pdf.cell(0, 7, f"{tag} {f.category}", ln=True)
            pdf.set_text_color(0, 0, 0)
            pdf.set_font("Helvetica", "", 9)
            pdf.multi_cell(0, 5, f"  {f.description}")
            if f.regulation:
                pdf.set_text_color(100, 100, 100)
                pdf.cell(0, 5, f"  Regulation: {f.regulation}", ln=True)
            pdf.set_text_color(0, 0, 0)
            pdf.ln(3)

        # Disparate Impact Results
        if self.report.disparate_impact_results:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 14)
            pdf.cell(0, 10, "Disparate Impact Analysis", ln=True)

            for di in self.report.disparate_impact_results:
                pdf.set_font("Helvetica", "B", 11)
                status = "FAIL" if di.has_disparate_impact else "PASS"
                pdf.cell(
                    0, 8,
                    f"{di.protected_attribute}: {status} "
                    f"(ratio: {di.worst_ratio:.3f})",
                    ln=True,
                )
                pdf.set_font("Helvetica", "", 9)
                for metrics in di.group_metrics:
                    rate = metrics.selection_rate
                    n = metrics.total_count
                    label = f"{metrics.group_name}={metrics.group_value}"
                    pdf.cell(
                        0, 5,
                        f"    {label}: rate={rate:.3f}, n={n}",
                        ln=True,
                    )
                pdf.ln(3)

        # LDA Candidates
        if self.report.lda_candidates:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 14)
            pdf.cell(0, 10, "Less Discriminatory Alternatives", ln=True)

            for i, lda in enumerate(self.report.lda_candidates[:10]):
                pdf.set_font("Helvetica", "B", 10)
                pdf.cell(
                    0, 7,
                    f"Candidate {i+1}: Remove {', '.join(lda.removed_features)}",
                    ln=True,
                )
                pdf.set_font("Helvetica", "", 9)
                pdf.cell(
                    0, 5,
                    f"    AUC loss: {lda.auc_loss_pct:.1f}% | "
                    f"Disparity: {lda.original_disparity:.3f} -> {lda.candidate_disparity:.3f} | "
                    f"4/5 test: {'PASS' if lda.passes_four_fifths else 'FAIL'}",
                    ln=True,
                )
                pdf.set_font("Helvetica", "", 8)
                pdf.multi_cell(0, 4, f"    {lda.recommendation}")
                pdf.ln(2)

            if self.report.lda_search_summary:
                ss = self.report.lda_search_summary
                pdf.ln(3)
                pdf.set_font("Helvetica", "B", 10)
                pdf.cell(0, 7, "LDA Search Summary", ln=True)
                pdf.set_font("Helvetica", "", 9)
                pdf.cell(0, 5, f"    Candidates evaluated: {ss.total_candidates_evaluated}", ln=True)
                pdf.cell(0, 5, f"    Passing candidates: {ss.passing_candidates}", ln=True)
                pdf.cell(0, 5, f"    Search time: {ss.search_time_seconds:.1f}s", ln=True)

        # Adverse Action Samples
        if self.report.adverse_action_samples:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 14)
            pdf.cell(0, 10, "Adverse Action Reason Code Samples", ln=True)

            for sample in self.report.adverse_action_samples[:5]:
                pdf.set_font("Helvetica", "B", 10)
                pdf.cell(
                    0, 7,
                    f"Applicant #{sample.applicant_index} "
                    f"(prediction: {'approved' if sample.prediction == 1 else 'denied'}, "
                    f"probability: {sample.probability:.3f})",
                    ln=True,
                )
                pdf.set_font("Helvetica", "", 9)
                for reason in sample.reasons:
                    pdf.cell(
                        0, 5,
                        f"    {reason.rank}. [{reason.reason_code}] {reason.reason_text}",
                        ln=True,
                    )
                pdf.ln(3)

        pdf.output(str(path))

    def _save_docx(self, path: Path):
        """Generate a Word document compliance report."""
        try:
            from docx import Document
            from docx.shared import Inches, Pt, RGBColor
            from docx.enum.text import WD_ALIGN_PARAGRAPH
        except ImportError:
            raise ImportError(
                "python-docx is required for Word export.\n"
                "    pip install provenanced[docx]"
            )

        doc = Document()

        # Title
        title = doc.add_heading("Algorithmic Fairness Analysis Report", level=0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER

        # Model info
        import datetime
        ts = datetime.datetime.fromtimestamp(
            self.report.timestamp, tz=datetime.timezone.utc
        )
        info = doc.add_paragraph()
        info.add_run(f"Model: ").bold = True
        info.add_run(f"{self._model_name}\n")
        info.add_run(f"Generated: ").bold = True
        info.add_run(f"{ts.strftime('%Y-%m-%d %H:%M:%S UTC')}\n")
        info.add_run(f"Analysis time: ").bold = True
        info.add_run(f"{self.report.analysis_time_seconds:.1f}s\n")
        if self.report.model_identity:
            info.add_run(f"Model hash: ").bold = True
            info.add_run(f"{self.report.model_identity.model_hash[:16]}...")

        # Executive Summary
        doc.add_heading("Executive Summary", level=1)
        s = self.report.summary
        critical = s.get("critical", 0)
        warnings = s.get("warnings", 0)
        proxies = s.get("proxy_features_detected", 0)

        verdict = doc.add_paragraph()
        run = verdict.add_run(
            "PASS" if critical == 0 else "FAIL"
        )
        run.bold = True
        run.font.color.rgb = (
            RGBColor(0, 128, 0) if critical == 0
            else RGBColor(200, 0, 0)
        )
        if critical == 0:
            verdict.add_run(" - No critical fairness issues detected")
        else:
            verdict.add_run(f" - {critical} critical finding(s) require remediation")

        table = doc.add_table(rows=3, cols=2)
        table.style = "Light List"
        table.rows[0].cells[0].text = "Critical Findings"
        table.rows[0].cells[1].text = str(critical)
        table.rows[1].cells[0].text = "Warnings"
        table.rows[1].cells[1].text = str(warnings)
        table.rows[2].cells[0].text = "Proxy Features Detected"
        table.rows[2].cells[1].text = str(proxies)

        # Findings
        doc.add_heading("Findings", level=1)
        for f in self.report.findings:
            tag = f"[{f.severity.value.upper()}]"
            p = doc.add_paragraph()
            run = p.add_run(f"{tag} ")
            run.bold = True
            if f.severity.value == "critical":
                run.font.color.rgb = RGBColor(200, 0, 0)
            elif f.severity.value == "warning":
                run.font.color.rgb = RGBColor(180, 130, 0)
            p.add_run(f"{f.description}")
            if f.regulation:
                reg_p = doc.add_paragraph()
                reg_run = reg_p.add_run(f"Regulation: {f.regulation}")
                reg_run.font.color.rgb = RGBColor(100, 100, 100)
                reg_run.font.size = Pt(9)

        # Disparate Impact
        if self.report.disparate_impact_results:
            doc.add_heading("Disparate Impact Analysis", level=1)
            for di in self.report.disparate_impact_results:
                status = "FAIL" if di.has_disparate_impact else "PASS"
                doc.add_heading(
                    f"{di.protected_attribute}: {status} (ratio: {di.worst_ratio:.3f})",
                    level=2,
                )
                if di.group_metrics:
                    t = doc.add_table(
                        rows=1 + len(di.group_metrics), cols=3
                    )
                    t.style = "Light List"
                    t.rows[0].cells[0].text = "Group"
                    t.rows[0].cells[1].text = "Selection Rate"
                    t.rows[0].cells[2].text = "Count"
                    for i, metrics in enumerate(di.group_metrics):
                        t.rows[i + 1].cells[0].text = f"{metrics.group_name}={metrics.group_value}"
                        t.rows[i + 1].cells[1].text = f"{metrics.selection_rate:.3f}"
                        t.rows[i + 1].cells[2].text = str(metrics.total_count)

        # LDA
        if self.report.lda_candidates:
            doc.add_heading("Less Discriminatory Alternatives", level=1)
            t = doc.add_table(
                rows=1 + min(len(self.report.lda_candidates), 10), cols=5
            )
            t.style = "Light List"
            headers = ["Removed Features", "AUC Loss %", "Disparity Before",
                        "Disparity After", "4/5 Test"]
            for i, h in enumerate(headers):
                t.rows[0].cells[i].text = h

            for i, lda in enumerate(self.report.lda_candidates[:10]):
                t.rows[i + 1].cells[0].text = ", ".join(lda.removed_features)
                t.rows[i + 1].cells[1].text = f"{lda.auc_loss_pct:.1f}%"
                t.rows[i + 1].cells[2].text = f"{lda.original_disparity:.3f}"
                t.rows[i + 1].cells[3].text = f"{lda.candidate_disparity:.3f}"
                t.rows[i + 1].cells[4].text = "PASS" if lda.passes_four_fifths else "FAIL"

        # Adverse Action
        if self.report.adverse_action_samples:
            doc.add_heading("Adverse Action Reason Code Samples", level=1)
            for sample in self.report.adverse_action_samples[:5]:
                doc.add_heading(
                    f"Applicant #{sample.applicant_index} "
                    f"(P={sample.probability:.3f})",
                    level=2,
                )
                if sample.reasons:
                    t = doc.add_table(rows=1 + len(sample.reasons), cols=4)
                    t.style = "Light List"
                    t.rows[0].cells[0].text = "Rank"
                    t.rows[0].cells[1].text = "Code"
                    t.rows[0].cells[2].text = "Reason"
                    t.rows[0].cells[3].text = "Feature"
                    for j, r in enumerate(sample.reasons):
                        t.rows[j + 1].cells[0].text = str(r.rank)
                        t.rows[j + 1].cells[1].text = r.reason_code
                        t.rows[j + 1].cells[2].text = r.reason_text
                        t.rows[j + 1].cells[3].text = r.feature_name

        doc.save(str(path))

    def _save_html(self, path: Path):
        """Generate a self-contained HTML report."""
        import datetime
        ts = datetime.datetime.fromtimestamp(
            self.report.timestamp, tz=datetime.timezone.utc
        )
        s = self.report.summary
        critical = s.get("critical", 0)
        warnings = s.get("warnings", 0)
        proxies = s.get("proxy_features_detected", 0)
        verdict_class = "pass" if critical == 0 else "fail"
        verdict_text = (
            "PASS - No critical fairness issues detected"
            if critical == 0
            else f"FAIL - {critical} critical finding(s) require remediation"
        )

        findings_html = ""
        for f in self.report.findings:
            sev = f.severity.value
            findings_html += (
                f'<div class="finding {sev}">'
                f'<span class="tag">[{sev.upper()}]</span> '
                f'{_html_escape(f.description)}'
            )
            if f.regulation:
                findings_html += (
                    f'<div class="regulation">{_html_escape(f.regulation)}</div>'
                )
            findings_html += "</div>\n"

        di_html = ""
        for di in self.report.disparate_impact_results:
            status = "FAIL" if di.has_disparate_impact else "PASS"
            di_html += (
                f'<h3>{_html_escape(di.protected_attribute)}: '
                f'<span class="{"fail" if di.has_disparate_impact else "pass"}">'
                f'{status}</span> (ratio: {di.worst_ratio:.3f})</h3>'
            )
            di_html += '<table><tr><th>Group</th><th>Selection Rate</th><th>Count</th></tr>'
            for metrics in di.group_metrics:
                label = f"{metrics.group_name}={metrics.group_value}"
                di_html += (
                    f'<tr><td>{_html_escape(label)}</td>'
                    f'<td>{metrics.selection_rate:.3f}</td>'
                    f'<td>{metrics.total_count}</td></tr>'
                )
            di_html += "</table>"

        model_hash_line = ""
        if self.report.model_identity:
            model_hash_line = (
                f'<p><strong>Model Hash:</strong> '
                f'{self.report.model_identity.model_hash[:16]}...</p>'
            )

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Fairness Analysis: {_html_escape(self._model_name)}</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 900px; margin: 40px auto; padding: 0 20px; color: #333; line-height: 1.6; }}
h1 {{ text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; }}
h2 {{ color: #1a1a1a; border-bottom: 1px solid #ddd; padding-bottom: 5px; margin-top: 30px; }}
.meta {{ color: #666; font-size: 0.9em; }}
.verdict {{ font-size: 1.3em; font-weight: bold; padding: 15px; border-radius: 6px; margin: 20px 0; }}
.verdict.pass {{ background: #e8f5e9; color: #2e7d32; }}
.verdict.fail {{ background: #fbe9e7; color: #c62828; }}
.finding {{ padding: 10px; margin: 8px 0; border-left: 4px solid #ccc; background: #fafafa; }}
.finding.critical {{ border-left-color: #c62828; background: #fbe9e7; }}
.finding.warning {{ border-left-color: #f57c00; background: #fff3e0; }}
.finding.info {{ border-left-color: #1565c0; background: #e3f2fd; }}
.tag {{ font-weight: bold; }}
.regulation {{ color: #666; font-size: 0.85em; margin-top: 4px; }}
table {{ border-collapse: collapse; width: 100%; margin: 10px 0; }}
th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
th {{ background: #f5f5f5; font-weight: 600; }}
tr:nth-child(even) {{ background: #fafafa; }}
.pass {{ color: #2e7d32; }}
.fail {{ color: #c62828; }}
@media print {{ body {{ max-width: 100%; }} .finding {{ page-break-inside: avoid; }} }}
</style>
</head>
<body>
<h1>Algorithmic Fairness Analysis Report</h1>
<div class="meta">
<p><strong>Model:</strong> {_html_escape(self._model_name)}</p>
<p><strong>Generated:</strong> {ts.strftime('%Y-%m-%d %H:%M:%S UTC')}</p>
<p><strong>Analysis time:</strong> {self.report.analysis_time_seconds:.1f}s</p>
{model_hash_line}
</div>

<h2>Executive Summary</h2>
<div class="verdict {verdict_class}">{verdict_text}</div>
<table>
<tr><th>Metric</th><th>Value</th></tr>
<tr><td>Critical Findings</td><td>{critical}</td></tr>
<tr><td>Warnings</td><td>{warnings}</td></tr>
<tr><td>Proxy Features Detected</td><td>{proxies}</td></tr>
</table>

<h2>Findings</h2>
{findings_html}

<h2>Disparate Impact Analysis</h2>
{di_html}

</body>
</html>"""

        path.write_text(html)

    def __repr__(self) -> str:
        s = self.report.summary
        critical = s.get("critical", 0)
        warnings = s.get("warnings", 0)
        verdict = "PASS" if critical == 0 else "FAIL"
        lines = [
            f"AnalysisResult({verdict})",
            f"  Model: {self._model_name}",
            f"  Critical: {critical}, Warnings: {warnings}",
            f"  Analysis time: {self.report.analysis_time_seconds:.1f}s",
        ]
        if self.report.findings:
            lines.append("  Findings:")
            for f in self.report.findings[:5]:
                lines.append(
                    f"    [{f.severity.value.upper()}] {f.description[:80]}"
                )
            if len(self.report.findings) > 5:
                lines.append(
                    f"    ... and {len(self.report.findings) - 5} more"
                )
        return "\n".join(lines)


def _html_escape(text: str) -> str:
    """Escape HTML special characters."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
