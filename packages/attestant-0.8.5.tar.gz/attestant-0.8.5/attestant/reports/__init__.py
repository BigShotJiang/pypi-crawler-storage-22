"""
HYDRA-24 Report Generation

Produces litigation-ready compliance reports in HTML format.
"""

from .compliance import ComplianceReportGenerator, generate_report

__all__ = ['ComplianceReportGenerator', 'generate_report']
