"""
Attestant Compliance Report Generator

Produces litigation-ready HTML reports for any prediction, including:
- Executive summary with pass/fail verdict
- Full computation DAG visualization
- Protected data analysis
- Regulatory compliance checks
- Source data lineage
- Content-covering verification hash

Usage:
    from attestant.reports.compliance import generate_report

    report_html = generate_report(
        dag=computation_dag,
        tracker=tracker,
        title="Loan Approval #12345",
        regulations=['eu_ai_act', 'ecoa'],
    )
    with open('report.html', 'w') as f:
        f.write(report_html)
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from html import escape as html_escape
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field


@dataclass
class ReportSection:
    """A section in the compliance report."""
    title: str
    content: str
    severity: str = "info"


@dataclass
class ReportConfig:
    """Configuration for report generation."""
    title: str = "Attestant Provenance Report"
    organization: str = "Organization"
    analyst: str = "Attestant Automated Analysis"
    include_dag_visualization: bool = True
    include_source_lineage: bool = True
    include_compliance_checks: bool = True
    include_protected_analysis: bool = True
    regulations: List[str] = field(default_factory=list)


def _esc(value: Any) -> str:
    """HTML-escape any value for safe insertion into markup."""
    if value is None:
        return ""
    return html_escape(str(value), quote=True)


# ---------------------------------------------------------------------------
# CSS
# ---------------------------------------------------------------------------

_REPORT_CSS = """
* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    background: #ffffff;
    color: #1a1a2e;
    line-height: 1.65;
    max-width: 960px;
    margin: 0 auto;
    padding: 2.5rem 2rem;
    font-size: 14px;
}

/* ----- Print ----- */
@media print {
    body {
        padding: 0.4in 0.5in;
        font-size: 9.5pt;
        max-width: none;
        color: #000;
    }
    .no-print { display: none !important; }
    .report-section { page-break-inside: avoid; }
    .page-break { page-break-before: always; }
    .summary-card { border: 1px solid #999 !important; }
    a { color: #000; text-decoration: underline; }
    .dag-container { max-height: 300px; overflow: hidden; }
}

@page {
    size: A4;
    margin: 0.6in 0.5in;
    @bottom-center {
        content: "HYDRA-24 Compliance Report -- Page " counter(page) " of " counter(pages);
        font-size: 8pt;
        color: #999;
    }
}

/* ----- Header ----- */
.report-header {
    border-bottom: 3px solid #1a1a2e;
    padding-bottom: 1.25rem;
    margin-bottom: 2rem;
}
.report-header h1 {
    font-size: 1.75rem;
    font-weight: 800;
    letter-spacing: -0.02em;
    color: #1a1a2e;
    margin-bottom: 0.25rem;
}
.report-header .subtitle {
    color: #6b7280;
    font-size: 0.9rem;
}

/* ----- Sections ----- */
.report-section {
    margin-bottom: 2.25rem;
    page-break-inside: avoid;
}
.report-section h2 {
    font-size: 1.15rem;
    font-weight: 700;
    color: #1a1a2e;
    border-bottom: 2px solid #e5e7eb;
    padding-bottom: 0.4rem;
    margin-bottom: 1rem;
    letter-spacing: -0.01em;
}
.report-section h3 {
    font-size: 1rem;
    font-weight: 600;
    color: #374151;
    margin: 1rem 0 0.5rem;
}
.report-section h4 {
    font-size: 0.9rem;
    font-weight: 600;
    color: #4b5563;
    margin: 0.75rem 0 0.4rem;
}

/* ----- Summary grid ----- */
.summary-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
    gap: 0.75rem;
    margin-bottom: 1.25rem;
}
.summary-card {
    background: #f9fafb;
    padding: 0.85rem 0.75rem;
    border-radius: 6px;
    border: 1px solid #e5e7eb;
    text-align: center;
}
.summary-label {
    font-size: 0.7rem;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 0.2rem;
    font-weight: 500;
}
.summary-value {
    font-size: 1.35rem;
    font-weight: 700;
    color: #1a1a2e;
}
.verdict-pass {
    border: 2px solid #22c55e;
    background: #f0fdf4;
}
.verdict-pass .summary-value { color: #15803d; }
.verdict-fail {
    border: 2px solid #ef4444;
    background: #fef2f2;
}
.verdict-fail .summary-value { color: #dc2626; }
.text-danger { color: #dc2626; }
.text-safe { color: #15803d; }

/* ----- Alerts ----- */
.alert {
    padding: 0.85rem 1rem;
    border-radius: 6px;
    margin-bottom: 0.75rem;
    font-size: 0.9rem;
    line-height: 1.5;
}
.alert-danger {
    background: #fef2f2;
    border-left: 4px solid #ef4444;
    color: #991b1b;
}
.alert-warning {
    background: #fffbeb;
    border-left: 4px solid #f59e0b;
    color: #92400e;
}
.alert-info {
    background: #eff6ff;
    border-left: 4px solid #3b82f6;
    color: #1e40af;
}
.alert-safe {
    background: #f0fdf4;
    border-left: 4px solid #22c55e;
    color: #166534;
}
.alert strong { font-weight: 600; }
.alert em { font-style: normal; color: inherit; opacity: 0.85; font-size: 0.85rem; }

/* ----- Badges ----- */
.badge {
    display: inline-block;
    padding: 0.15rem 0.5rem;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 600;
    margin: 0.1rem;
    vertical-align: middle;
}
.badge-critical { background: #fecaca; color: #991b1b; }
.badge-warning  { background: #fef3c7; color: #92400e; }
.badge-info     { background: #dbeafe; color: #1e40af; }
.badge-pass     { background: #d1fae5; color: #065f46; }
.badge-fail     { background: #fecaca; color: #991b1b; }
.badge-protected { background: #fef3c7; color: #92400e; }
.badge-safe      { background: #d1fae5; color: #065f46; }

/* ----- Tables ----- */
.data-table {
    width: 100%;
    border-collapse: collapse;
    margin: 0.75rem 0;
    font-size: 0.85rem;
}
.data-table th {
    background: #f3f4f6;
    text-align: left;
    padding: 0.6rem 0.75rem;
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    color: #6b7280;
    border-bottom: 2px solid #e5e7eb;
    font-weight: 600;
}
.data-table td {
    padding: 0.55rem 0.75rem;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: top;
}
.data-table tr:hover td { background: #f9fafb; }
.data-table code {
    background: #f1f5f9;
    padding: 0.1rem 0.35rem;
    border-radius: 3px;
    font-size: 0.8rem;
    font-family: 'SF Mono', 'Cascadia Code', 'Fira Code', monospace;
}

/* ----- DAG ----- */
.dag-container {
    background: #fafafa;
    border: 1px solid #e5e7eb;
    border-radius: 6px;
    padding: 1rem;
    margin: 0.75rem 0;
}

/* ----- Protected source card ----- */
.protected-source {
    background: #fffbeb;
    border: 1px solid #fde68a;
    border-radius: 6px;
    padding: 0.85rem 1rem;
    margin: 0.6rem 0;
}
.protected-source h4 { margin-top: 0; }

/* ----- Verification ----- */
.verification-info {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    padding: 1rem 1.25rem;
    margin: 0.75rem 0;
    font-size: 0.85rem;
}
.verification-info p { margin: 0.2rem 0; }
.verification-info code {
    background: #e2e8f0;
    padding: 0.1rem 0.4rem;
    border-radius: 3px;
    font-size: 0.8rem;
    word-break: break-all;
    font-family: 'SF Mono', 'Cascadia Code', 'Fira Code', monospace;
}

/* ----- Footer ----- */
.report-footer {
    border-top: 1px solid #e5e7eb;
    padding-top: 1rem;
    margin-top: 2.5rem;
    color: #9ca3af;
    font-size: 0.75rem;
}
.report-footer p { margin: 0.15rem 0; }

/* ----- Findings ----- */
.findings { margin-top: 0.75rem; }
.finding-citation {
    display: block;
    margin-top: 0.3rem;
    font-size: 0.8rem;
    opacity: 0.9;
}
.finding-remediation {
    display: block;
    margin-top: 0.25rem;
    font-size: 0.8rem;
    opacity: 0.85;
    padding-left: 0.5rem;
    border-left: 2px solid currentColor;
}

/* ----- Compliance stat bar ----- */
.stat-bar {
    display: flex;
    gap: 1rem;
    margin: 0.5rem 0 1rem;
    font-size: 0.85rem;
}
.stat-bar .stat {
    display: flex;
    align-items: center;
    gap: 0.3rem;
}
.stat-dot {
    display: inline-block;
    width: 10px;
    height: 10px;
    border-radius: 50%;
}
.stat-dot-critical { background: #ef4444; }
.stat-dot-warning  { background: #f59e0b; }
.stat-dot-info     { background: #3b82f6; }
.stat-dot-pass     { background: #22c55e; }
"""


# ---------------------------------------------------------------------------
# Generator
# ---------------------------------------------------------------------------

class ComplianceReportGenerator:
    """
    Generates litigation-ready HTML compliance reports.

    Takes a ComputationDAG and optional compliance results to produce
    a professional, printable document suitable for regulatory submission.
    """

    def __init__(self, config: Optional[ReportConfig] = None):
        self.config = config or ReportConfig()

    def generate(
        self,
        dag: Any = None,
        tracker: Any = None,
        compliance_results: Optional[List[Dict[str, Any]]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Generate complete HTML compliance report.

        Args:
            dag: A ComputationDAG instance (or None).
            tracker: A DAGTracker instance (or None).
            compliance_results: List of compliance result dicts (from
                ``ComplianceResult.to_dict()``).
            metadata: Additional metadata for the report.

        Returns:
            A complete, self-contained HTML document string.
        """
        metadata = metadata or {}
        compliance_results = compliance_results or []

        sections: List[ReportSection] = []

        sections.append(self._build_executive_summary(dag, compliance_results))

        if dag is not None and self.config.include_dag_visualization:
            sections.append(self._build_dag_section(dag))

        if dag is not None and self.config.include_source_lineage:
            sections.append(self._build_source_lineage(dag))

        if dag is not None and self.config.include_protected_analysis:
            sections.append(self._build_protected_analysis(dag))

        if compliance_results and self.config.include_compliance_checks:
            for result in compliance_results:
                sections.append(self._build_compliance_section(result))

        report_body = self._render_html(sections, metadata)

        content_hash = hashlib.sha256(report_body.encode("utf-8")).hexdigest()

        verification_section = self._build_verification_section(dag, content_hash)
        sections.append(verification_section)

        return self._render_html(sections, metadata)

    # -----------------------------------------------------------------
    # Executive Summary
    # -----------------------------------------------------------------

    def _build_executive_summary(
        self, dag: Any, compliance_results: List[Dict[str, Any]]
    ) -> ReportSection:
        has_protected = getattr(dag, "has_protected", False) if dag else False
        all_passed = (
            all(r.get("passed", True) for r in compliance_results)
            if compliance_results
            else True
        )
        verdict = "PASS" if (not has_protected and all_passed) else "FAIL"

        source_count = len(dag.source_nodes) if dag else 0
        protected_count = len(dag.protected_sources) if dag else 0
        depth = dag.depth if dag else 0
        node_count = len(dag.nodes) if dag else 0
        edge_count = len(dag.edges) if dag else 0

        total_critical = 0
        total_warning = 0
        total_info = 0
        for r in compliance_results:
            summary = r.get("summary", {})
            if isinstance(summary, dict):
                total_critical += summary.get("critical", 0)
                total_warning += summary.get("warning", 0)
                total_info += summary.get("info", 0)

        verdict_class = "verdict-pass" if verdict == "PASS" else "verdict-fail"
        prot_class = "text-danger" if has_protected else "text-safe"
        prot_cnt_class = "text-danger" if protected_count > 0 else "text-safe"

        content = f"""
        <div class="summary-grid">
            <div class="summary-card {verdict_class}">
                <div class="summary-label">Verdict</div>
                <div class="summary-value">{_esc(verdict)}</div>
            </div>
            <div class="summary-card">
                <div class="summary-label">Protected Data</div>
                <div class="summary-value {prot_class}">{'DETECTED' if has_protected else 'NONE'}</div>
            </div>
            <div class="summary-card">
                <div class="summary-label">Computation Depth</div>
                <div class="summary-value">{_esc(depth)}</div>
            </div>
            <div class="summary-card">
                <div class="summary-label">Source Columns</div>
                <div class="summary-value">{_esc(source_count)}</div>
            </div>
            <div class="summary-card">
                <div class="summary-label">DAG Nodes</div>
                <div class="summary-value">{_esc(node_count)}</div>
            </div>
            <div class="summary-card">
                <div class="summary-label">DAG Edges</div>
                <div class="summary-value">{_esc(edge_count)}</div>
            </div>
            <div class="summary-card">
                <div class="summary-label">Protected Sources</div>
                <div class="summary-value {prot_cnt_class}">{_esc(protected_count)}</div>
            </div>
        </div>
        """

        if total_critical > 0 or total_warning > 0:
            content += '<div class="stat-bar">'
            if total_critical:
                content += (
                    f'<div class="stat"><span class="stat-dot stat-dot-critical"></span>'
                    f'{_esc(total_critical)} Critical</div>'
                )
            if total_warning:
                content += (
                    f'<div class="stat"><span class="stat-dot stat-dot-warning"></span>'
                    f'{_esc(total_warning)} Warnings</div>'
                )
            if total_info:
                content += (
                    f'<div class="stat"><span class="stat-dot stat-dot-info"></span>'
                    f'{_esc(total_info)} Info</div>'
                )
            content += "</div>"

        if has_protected and dag is not None:
            content += (
                '<div class="alert alert-danger">'
                "<strong>Protected Data Contamination Detected</strong><br>"
            )
            for src in dag.protected_sources:
                label = f"{_esc(src.table)}.{_esc(src.column)}"
                content += f'<span class="badge badge-protected">{label}</span> '
            content += "</div>"

        if compliance_results:
            failed = [r for r in compliance_results if not r.get("passed", True)]
            if failed:
                content += (
                    '<div class="alert alert-danger">'
                    "<strong>Compliance Failures</strong><ul>"
                )
                for r in failed:
                    reg = _esc(
                        r.get("regulation_name")
                        or r.get("regulation")
                        or "Unknown"
                    )
                    summary = r.get("summary", {})
                    crit = summary.get("critical", 0) if isinstance(summary, dict) else 0
                    content += (
                        f"<li><strong>{reg}</strong>: "
                        f"{_esc(crit)} critical finding(s)</li>"
                    )
                content += "</ul></div>"

        return ReportSection(
            title="Executive Summary",
            content=content,
            severity="critical" if verdict == "FAIL" else "info",
        )

    # -----------------------------------------------------------------
    # DAG Visualization
    # -----------------------------------------------------------------

    def _build_dag_section(self, dag: Any) -> ReportSection:
        nodes_data = [n.to_dict() for n in dag.nodes.values()]
        edges_data = [e.to_dict() for e in dag.edges]

        # Use JSON.parse() on an escaped string to prevent XSS injection.
        # json.dumps produces valid JSON, but injecting it directly into a
        # <script> block lets specially-crafted node names break out of the
        # JS expression context.  Wrapping in JSON.parse(atob(...)) ensures
        # the data is treated as a string literal, never as code.
        import base64
        nodes_b64 = base64.b64encode(json.dumps(nodes_data).encode()).decode()
        edges_b64 = base64.b64encode(json.dumps(edges_data).encode()).decode()

        content = f"""
        <div class="dag-container">
            <svg id="report-dag-svg" width="100%" height="400"></svg>
        </div>
        <script>
        (function() {{
            var nodes = JSON.parse(atob("{nodes_b64}"));
            var edges = JSON.parse(atob("{edges_b64}"));
            var svg = document.getElementById('report-dag-svg');
            if (!svg) return;
            var w = svg.clientWidth || 800;
            var h = 400;

            var parentsOf = {{}};
            nodes.forEach(function(n) {{ parentsOf[n.id] = []; }});
            edges.forEach(function(e) {{ if (parentsOf[e.target]) parentsOf[e.target].push(e.source); }});

            var depths = {{}};
            nodes.filter(function(n) {{ return parentsOf[n.id].length === 0; }}).forEach(function(n) {{ depths[n.id] = 0; }});
            var changed = true;
            while (changed) {{
                changed = false;
                nodes.forEach(function(n) {{
                    if (depths[n.id] !== undefined) return;
                    var pds = parentsOf[n.id].map(function(p) {{ return depths[p]; }}).filter(function(d) {{ return d !== undefined; }});
                    if (pds.length === parentsOf[n.id].length && pds.length > 0) {{
                        depths[n.id] = Math.max.apply(null, pds) + 1; changed = true;
                    }}
                }});
                if (!changed) {{ nodes.forEach(function(n) {{ if (depths[n.id] === undefined) {{ depths[n.id] = 0; changed = true; }} }}); }}
            }}

            var maxD = Math.max.apply(null, Object.keys(depths).map(function(k) {{ return depths[k]; }}).concat([0]));
            var layers = {{}};
            nodes.forEach(function(n) {{ var d = depths[n.id] || 0; if (!layers[d]) layers[d] = []; layers[d].push(n); }});
            var pos = {{}};
            for (var d = 0; d <= maxD; d++) {{
                var layer = layers[d] || [];
                var lw = w / (layer.length + 1);
                layer.forEach(function(n, i) {{ pos[n.id] = {{ x: lw * (i + 1), y: h - (h / (maxD + 2)) * (d + 1) }}; }});
            }}

            edges.forEach(function(e) {{
                var f = pos[e.source], t = pos[e.target];
                if (!f || !t) return;
                var line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
                line.setAttribute('x1', f.x); line.setAttribute('y1', f.y);
                line.setAttribute('x2', t.x); line.setAttribute('y2', t.y);
                line.setAttribute('stroke', '#d1d5db'); line.setAttribute('stroke-width', '1.5');
                svg.appendChild(line);
            }});

            nodes.forEach(function(n) {{
                var p = pos[n.id]; if (!p) return;
                var c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                c.setAttribute('cx', p.x); c.setAttribute('cy', p.y); c.setAttribute('r', '8');
                var color = '#8b5cf6';
                if (n.type === 'SOURCE') color = n.is_protected ? '#f59e0b' : '#3b82f6';
                c.setAttribute('fill', color); c.setAttribute('stroke', '#374151'); c.setAttribute('stroke-width', '1');
                svg.appendChild(c);

                var t = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                t.setAttribute('x', p.x); t.setAttribute('y', p.y - 12); t.setAttribute('text-anchor', 'middle');
                t.setAttribute('fill', '#374151'); t.setAttribute('font-size', '9'); t.setAttribute('font-family', 'sans-serif');
                t.textContent = n.type === 'SOURCE' ? (n.column || '').substring(0, 10) : (n.operation || '').substring(0, 8);
                svg.appendChild(t);
            }});
        }})();
        </script>
        """
        return ReportSection(title="Computation Graph", content=content)

    # -----------------------------------------------------------------
    # Source Lineage
    # -----------------------------------------------------------------

    def _build_source_lineage(self, dag: Any) -> ReportSection:
        rows = ""
        sources = dag.source_nodes if dag else []
        if not sources:
            return ReportSection(
                title="Source Data Lineage",
                content='<div class="alert alert-info">No source nodes recorded in the DAG.</div>',
            )

        for node in sources:
            fp = f"0x{node.provenance:06X}"
            if node.is_protected:
                status_badge = '<span class="badge badge-protected">PROTECTED</span>'
            else:
                status_badge = '<span class="badge badge-safe">Safe</span>'
            rows += f"""
            <tr>
                <td><code>{_esc(fp)}</code></td>
                <td>{_esc(node.table) or '-'}</td>
                <td>{_esc(node.column) or '-'}</td>
                <td>{_esc(node.pair_id) if node.pair_id is not None else '-'}</td>
                <td>{status_badge}</td>
            </tr>
            """

        content = f"""
        <table class="data-table">
            <thead>
                <tr>
                    <th>Fingerprint</th>
                    <th>Table</th>
                    <th>Column</th>
                    <th>Pair ID</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>{rows}</tbody>
        </table>
        """
        return ReportSection(title="Source Data Lineage", content=content)

    # -----------------------------------------------------------------
    # Protected Data Analysis
    # -----------------------------------------------------------------

    def _build_protected_analysis(self, dag: Any) -> ReportSection:
        has_protected = getattr(dag, "has_protected", False) if dag else False

        if not has_protected:
            content = (
                '<div class="alert alert-safe">'
                "<strong>No Protected Data Detected</strong><br>"
                "This computation does not use any protected or sensitive data sources."
                "</div>"
            )
            return ReportSection(
                title="Protected Data Analysis",
                content=content,
                severity="info",
            )

        content = (
            '<div class="alert alert-danger">'
            "<strong>Protected Data Detected in Computation Graph</strong>"
            "</div>"
        )

        for src in dag.protected_sources:
            table = _esc(src.table)
            column = _esc(src.column)
            pair_id = _esc(src.pair_id)
            fp = f"0x{src.provenance:06X}"
            content += f"""
            <div class="protected-source">
                <h4>{table}.{column}</h4>
                <p>Pair ID: {pair_id} | Fingerprint: <code>{_esc(fp)}</code></p>
            </div>
            """

        op_counts = dag.operation_counts if dag else {}
        if op_counts:
            content += "<h4>Operations Applied to Protected Data</h4><ul>"
            for op, count in op_counts.items():
                content += f"<li><strong>{_esc(op)}</strong>: {_esc(count)} operations</li>"
            content += "</ul>"

        depth = dag.depth if dag else 0
        content += (
            f"<p><strong>Computation Depth:</strong> {_esc(depth)} "
            f"(protected data passes through {_esc(depth)} transformation layers)</p>"
        )

        return ReportSection(
            title="Protected Data Analysis",
            content=content,
            severity="critical",
        )

    # -----------------------------------------------------------------
    # Compliance Section (per regulation)
    # -----------------------------------------------------------------

    def _build_compliance_section(self, result: Dict[str, Any]) -> ReportSection:
        regulation = _esc(
            result.get("regulation_name")
            or result.get("regulation")
            or "Unknown Regulation"
        )
        passed = result.get("passed", True)
        findings = result.get("findings", [])
        timestamp = result.get("timestamp", "")
        engine_version = result.get("engine_version", "")
        citations = result.get("citations", [])

        if passed:
            status = '<span class="badge badge-pass">PASSED</span>'
        else:
            status = '<span class="badge badge-fail">FAILED</span>'

        content = f"<p><strong>Status:</strong> {status}</p>"

        if timestamp:
            content += f"<p><strong>Checked:</strong> {_esc(timestamp)}</p>"
        if engine_version:
            content += f"<p><strong>Engine Version:</strong> {_esc(engine_version)}</p>"

        summary = result.get("summary", {})
        if isinstance(summary, dict) and summary:
            crit = summary.get("critical", 0)
            warn = summary.get("warning", 0)
            info = summary.get("info", 0)
            content += '<div class="stat-bar">'
            content += (
                f'<div class="stat"><span class="stat-dot stat-dot-critical"></span>'
                f'{_esc(crit)} Critical</div>'
            )
            content += (
                f'<div class="stat"><span class="stat-dot stat-dot-warning"></span>'
                f'{_esc(warn)} Warnings</div>'
            )
            content += (
                f'<div class="stat"><span class="stat-dot stat-dot-info"></span>'
                f'{_esc(info)} Info</div>'
            )
            content += "</div>"

        if findings:
            content += '<div class="findings">'
            for finding in findings:
                if not isinstance(finding, dict):
                    continue
                severity = str(finding.get("severity", "INFO")).upper()
                sev_class = {
                    "CRITICAL": "alert-danger",
                    "WARNING": "alert-warning",
                }.get(severity, "alert-info")

                desc = _esc(finding.get("description", ""))
                citation = _esc(
                    finding.get("regulation_citation")
                    or finding.get("citation")
                    or ""
                )
                remediation = _esc(finding.get("remediation", ""))
                affected = finding.get("affected_nodes", [])

                content += f'<div class="alert {sev_class}">'
                content += f"<strong>[{_esc(severity)}]</strong> {desc}"
                if citation:
                    content += f'<span class="finding-citation">Citation: {citation}</span>'
                if remediation:
                    content += f'<span class="finding-remediation">Remediation: {remediation}</span>'
                if affected:
                    node_list = ", ".join(str(n) for n in affected[:20])
                    if len(affected) > 20:
                        node_list += f" ... and {len(affected) - 20} more"
                    content += (
                        f'<span class="finding-citation">'
                        f"Affected nodes: {_esc(node_list)}</span>"
                    )
                content += "</div>"
            content += "</div>"

        if citations:
            content += "<h4>Regulatory Citations Referenced</h4><ul>"
            for c in citations:
                content += f"<li>{_esc(c)}</li>"
            content += "</ul>"

        recs = result.get("remediation_recommendations", [])
        if recs:
            content += "<h4>Remediation Recommendations</h4><ol>"
            for rec in recs:
                content += f"<li>{_esc(rec)}</li>"
            content += "</ol>"

        return ReportSection(
            title=f"Compliance: {regulation}",
            content=content,
            severity="critical" if not passed else "info",
        )

    # -----------------------------------------------------------------
    # Verification
    # -----------------------------------------------------------------

    def _build_verification_section(
        self, dag: Any, content_hash: str
    ) -> ReportSection:
        now_utc = datetime.now(timezone.utc)

        dag_hash = ""
        if dag is not None:
            try:
                dag_hash = hashlib.sha256(
                    json.dumps(dag.to_dict(), sort_keys=True).encode("utf-8")
                ).hexdigest()
            except Exception:
                dag_hash = "unavailable"

        content = f"""
        <div class="verification-info">
            <p><strong>Report Generated (UTC):</strong> {_esc(now_utc.isoformat())}</p>
            <p><strong>DAG Hash (SHA-256):</strong> <code>{_esc(dag_hash or 'N/A')}</code></p>
            <p><strong>Report Content Hash (SHA-256):</strong> <code>{_esc(content_hash)}</code></p>
            <p><strong>HYDRA-24 Version:</strong> 0.4.0</p>
            <p><strong>Generator:</strong> {_esc(self.config.analyst)}</p>
            <p><strong>Organization:</strong> {_esc(self.config.organization)}</p>
        </div>
        <div class="alert alert-info">
            <strong>Verification</strong><br>
            This report was generated by HYDRA-24 automated provenance analysis.
            The computation DAG and all provenance fingerprints are cryptographically
            verifiable against the stored provenance data. The report content hash
            covers the body of this document and can be used to verify that no
            modifications have been made after generation.
        </div>
        """
        return ReportSection(title="Report Verification", content=content)

    # -----------------------------------------------------------------
    # HTML Rendering
    # -----------------------------------------------------------------

    def _render_html(
        self, sections: List[ReportSection], metadata: Dict[str, Any]
    ) -> str:
        now = datetime.now(timezone.utc)
        sections_html = ""
        for section in sections:
            sections_html += f"""
            <div class="report-section">
                <h2>{_esc(section.title)}</h2>
                {section.content}
            </div>
            """

        title = _esc(self.config.title)
        org = _esc(self.config.organization)
        formatted_date = now.strftime("%B %d, %Y at %H:%M:%S UTC")

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>{_REPORT_CSS}</style>
</head>
<body>
    <div class="report-header">
        <h1>{title}</h1>
        <p class="subtitle">Generated: {_esc(formatted_date)} | Organization: {org}</p>
    </div>
    {sections_html}
    <div class="report-footer">
        <p>This report was generated by Attestant Automated Provenance Analysis v0.5.0</p>
        <p>For verification, contact: compliance@provenance.ai</p>
    </div>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Convenience function
# ---------------------------------------------------------------------------

def generate_report(
    dag: Any = None,
    tracker: Any = None,
    title: str = "HYDRA-24 Provenance Report",
    organization: str = "Organization",
    regulations: Optional[List[str]] = None,
    compliance_results: Optional[List[Dict[str, Any]]] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Convenience function to generate a compliance report.

    Args:
        dag: ComputationDAG instance
        tracker: DAGTracker instance
        title: Report title
        organization: Organization name
        regulations: List of regulation names to check
        compliance_results: Pre-computed compliance results
        metadata: Additional metadata to include

    Returns:
        Complete HTML report as string
    """
    config = ReportConfig(
        title=title,
        organization=organization,
        regulations=regulations or [],
    )

    if regulations and compliance_results is None:
        compliance_results = []
        meta = metadata or {}
        for reg in regulations:
            try:
                if reg == "eu_ai_act":
                    from attestant.compliance.eu_ai_act import EUAIActEngine
                    engine = EUAIActEngine()
                    result = engine.check(dag, meta)
                    compliance_results.append(result.to_dict())
                elif reg == "ecoa":
                    from attestant.compliance.ecoa import ECOAEngine
                    engine = ECOAEngine()
                    result = engine.check(dag, meta)
                    compliance_results.append(result.to_dict())
                elif reg == "sr117" or reg == "sr_11_7":
                    from attestant.compliance.sr117 import SR117Engine
                    engine = SR117Engine()
                    result = engine.check(dag, meta)
                    compliance_results.append(result.to_dict())
                elif reg == "colorado_ai_act" or reg == "colorado":
                    from attestant.compliance.colorado_ai_act import ColoradoAIActEngine
                    engine = ColoradoAIActEngine()
                    result = engine.check(dag, meta)
                    compliance_results.append(result.to_dict())
                elif reg == "nyc_ll144" or reg == "nyc_aedt":
                    from attestant.compliance.nyc_ll144 import NYCLL144Engine
                    engine = NYCLL144Engine()
                    result = engine.check(dag, meta)
                    compliance_results.append(result.to_dict())
            except Exception as exc:
                compliance_results.append({
                    "regulation": reg,
                    "regulation_name": reg,
                    "passed": False,
                    "summary": {
                        "critical": 1,
                        "warning": 0,
                        "info": 0,
                        "total": 1,
                    },
                    "findings": [
                        {
                            "severity": "CRITICAL",
                            "description": (
                                f"Compliance engine for '{_esc(reg)}' could not "
                                f"be executed: {_esc(type(exc).__name__)}"
                            ),
                            "regulation_citation": "",
                            "remediation": "Ensure the compliance engine module is installed and the DAG is valid.",
                        }
                    ],
                    "citations": [],
                    "remediation_recommendations": [],
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "engine_version": "",
                    "metadata": {},
                })

    generator = ComplianceReportGenerator(config)
    return generator.generate(
        dag=dag,
        tracker=tracker,
        compliance_results=compliance_results,
        metadata=metadata,
    )
