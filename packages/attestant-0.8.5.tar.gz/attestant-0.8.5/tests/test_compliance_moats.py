"""
Comprehensive tests for HYDRA-24 compliance engines and report generation.

Covers:
    - EU AI Act Engine (EUAIActEngine)
    - ECOA / Reg B Engine (ECOAEngine)
    - Compliance Report Generator (ComplianceReportGenerator)

Each test builds its own DAG fixtures using the proveit API so that the
suite is fully self-contained.
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from attestant.hydra24_dag import (
    ComputationDAG,
    DAGEdge,
    DAGNode,
    DAGTracker,
    DAGTrackedDataFrame,
    DAGTrackedSeries,
    NodeType,
    wrap_dataframe_dag,
    get_dag_for_series,
)
from attestant.compliance.base import (
    BaseComplianceEngine,
    ComplianceFinding,
    ComplianceReport,
    ComplianceResult,
    Severity,
)
from attestant.compliance.eu_ai_act import EUAIActEngine, _classify_risk
from attestant.compliance.ecoa import ECOAEngine, _column_is_protected
from attestant.reports.compliance import (
    ComplianceReportGenerator,
    ReportConfig,
    ReportSection,
    generate_report,
)


# ============================================================================
# Helpers -- DAG construction utilities
# ============================================================================

def _build_clean_dag() -> tuple:
    """Build a DAG with no protected data (credit-only pipeline)."""
    tracker = DAGTracker()

    credit_df = pd.DataFrame({
        "applicant_id": [1, 2, 3],
        "credit_score": [720, 680, 750],
        "annual_income": [85000, 65000, 120000],
    })

    credit = wrap_dataframe_dag(credit_df, tracker, "credit_bureau")

    dti = credit["annual_income"] / credit["credit_score"]
    score = dti * credit["credit_score"]

    dag = get_dag_for_series(score, row_index=0)
    return tracker, dag


def _build_contaminated_dag() -> tuple:
    """Build a DAG with protected demographics flowing into the decision."""
    tracker = DAGTracker()

    credit_df = pd.DataFrame({
        "applicant_id": [1, 2, 3],
        "credit_score": [720, 680, 750],
        "annual_income": [85000, 65000, 120000],
    })

    demo_df = pd.DataFrame({
        "applicant_id": [1, 2, 3],
        "age": [35, 28, 45],
        "gender": ["male", "female", "male"],
        "race": ["white", "black", "asian"],
    })

    credit = wrap_dataframe_dag(credit_df, tracker, "credit_bureau")
    demographics = wrap_dataframe_dag(demo_df, tracker, "demographics", protected=True)

    contaminated = credit["credit_score"] + demographics["age"]
    score = contaminated * credit["annual_income"]

    dag = get_dag_for_series(score, row_index=0)
    return tracker, dag


def _build_medical_dag() -> tuple:
    """Build a DAG containing PHI (patient health information)."""
    tracker = DAGTracker()

    patients_df = pd.DataFrame({
        "patient_id": [101, 102, 103],
        "ssn": ["123-45-6789", "987-65-4321", "555-55-5555"],
        "date_of_birth": ["1990-01-15", "1985-06-22", "1978-11-03"],
        "medical_record_number": ["MRN001", "MRN002", "MRN003"],
        "diagnosis_code": ["E11.9", "I10", "J45.20"],
    })

    patients = wrap_dataframe_dag(patients_df, tracker, "patient_records")

    result = patients["patient_id"] + patients["patient_id"]

    dag = get_dag_for_series(result, row_index=0)
    return tracker, dag


def _build_financial_dag() -> tuple:
    """Build a DAG for a financial reporting pipeline."""
    tracker = DAGTracker()

    revenue_df = pd.DataFrame({
        "quarter": [1, 2, 3, 4],
        "gross_revenue": [1000000, 1200000, 1100000, 1300000],
        "cost_of_goods": [400000, 480000, 440000, 520000],
    })

    expenses_df = pd.DataFrame({
        "quarter": [1, 2, 3, 4],
        "operating_expenses": [300000, 350000, 320000, 380000],
        "depreciation": [50000, 50000, 50000, 50000],
    })

    revenue = wrap_dataframe_dag(revenue_df, tracker, "revenue_data")
    expenses = wrap_dataframe_dag(expenses_df, tracker, "expense_data")

    gross_profit = revenue["gross_revenue"] - revenue["cost_of_goods"]
    net_income = gross_profit - expenses["operating_expenses"]

    dag = get_dag_for_series(net_income, row_index=0)
    return tracker, dag


def _build_empty_dag() -> ComputationDAG:
    """Build an empty DAG with no nodes.

    Uses a sentinel root node so that dag.depth does not raise KeyError,
    but the nodes dict is otherwise empty from a compliance perspective.
    The single sentinel node has provenance 0 and no inputs, which the
    engines treat as an effectively empty / degenerate DAG.
    """
    sentinel = DAGNode(
        node_id=0,
        node_type=NodeType.CUSTOM,
        operation="empty",
        inputs=[],
        provenance=0,
    )
    return ComputationDAG(root_id=0, nodes={0: sentinel}, edges=[])


def _build_source_only_dag() -> tuple:
    """Build a DAG with only source nodes (no computation)."""
    tracker = DAGTracker()
    df = pd.DataFrame({"value": [1, 2, 3]})
    wrapped = wrap_dataframe_dag(df, tracker, "simple_table")
    series = wrapped["value"]
    dag = get_dag_for_series(series, row_index=0)
    return tracker, dag


# ============================================================================
# EU AI Act Engine Tests
# ============================================================================

class TestEUAIActEngine:
    """Tests for the EU AI Act compliance engine."""

    def test_instantiation_and_regulation_name(self):
        """Verify the engine instantiates and exposes the correct regulation name."""
        engine = EUAIActEngine()
        assert isinstance(engine, BaseComplianceEngine)
        assert engine.regulation_name == "EU AI Act"

    def test_check_methods_exist(self):
        """Verify all expected check methods are present on the engine."""
        engine = EUAIActEngine()
        expected_methods = [
            "_check_risk_classification",
            "_check_logging",
            "_check_traceability",
            "_check_human_oversight",
            "_check_data_governance",
            "_check_transparency",
            "_check_accuracy_robustness",
            "_check_quality_management",
        ]
        for method_name in expected_methods:
            assert hasattr(engine, method_name), (
                f"EUAIActEngine is missing method: {method_name}"
            )

    def test_clean_dag_passes(self):
        """A clean DAG with adequate metadata should pass (no CRITICAL findings)."""
        engine = EUAIActEngine()
        _, dag = _build_clean_dag()

        metadata = {
            "domain": "credit_scoring",
            "model_type": "gradient_boosting",
            "human_oversight_mode": "human_in_the_loop",
            "override_capability": True,
            "intended_purpose": "Credit decisioning",
            "known_limitations": "Does not account for non-traditional credit",
            "accuracy_metrics": {"auc": 0.85},
            "robustness_testing": True,
            "quality_management_system": True,
            "training_data_description": "Historical loan data 2018-2023",
            "start_time": "2024-01-01T00:00:00",
            "end_time": "2024-01-01T00:05:00",
            "model_version": "v2.3.1",
            "conformity_assessment": True,
            "eu_database_registration": "EU-DB-12345",
            "risk_management_plan": "Formal risk management plan v1.2",
            "risk_assessment_completed": True,
            "risk_mitigation_measures": "Bias monitoring, human-in-the-loop",
            "technical_documentation": "DOC-2024-CS-001",
            "algorithm_description": "Gradient boosting with 500 trees",
            "fundamental_rights_impact_assessment": "FRIA v1.0 completed Q1 2025",
            "affected_persons_description": "Consumer loan applicants age 18+",
            "bias_examination_documented": True,
            "data_representativeness_assessment": "Representative of EU population",
            "cybersecurity_measures": "Access controls, adversarial testing",
        }

        result = engine.check(dag, metadata)

        assert isinstance(result, ComplianceResult)
        assert result.regulation_name == "EU AI Act"
        assert result.passed is True, (
            f"Expected PASS but got FAIL. Critical findings: "
            f"{[f.description for f in result.findings if f.severity == Severity.CRITICAL]}"
        )

    def test_contaminated_dag_flags_protected_data(self):
        """A contaminated DAG should produce data governance warnings."""
        engine = EUAIActEngine()
        _, dag = _build_contaminated_dag()

        result = engine.check(dag)

        assert result.passed is False or any(
            "protected" in f.description.lower() or "Article 10" in f.regulation_citation
            for f in result.findings
        ), "Expected a finding about protected data under Article 10"

    def test_empty_dag_critical_logging(self):
        """A degenerate DAG should produce CRITICAL findings for missing provenance/edges/sources."""
        engine = EUAIActEngine()
        dag = _build_empty_dag()

        result = engine.check(dag)

        assert result.passed is False
        critical_findings = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL
        ]
        assert len(critical_findings) > 0, (
            "Expected at least one CRITICAL finding for a degenerate DAG"
        )

    def test_risk_classification_prohibited(self):
        """Social scoring should be classified as 'prohibited'."""
        assert _classify_risk({"domain": "social_scoring"}) == "prohibited"

    def test_risk_classification_high(self):
        """Credit scoring should be classified as 'high'."""
        assert _classify_risk({"domain": "credit_scoring"}) == "high"

    def test_risk_classification_limited(self):
        """Generative models should be classified as 'limited'."""
        assert _classify_risk({"model_type": "generative"}) == "limited"

    def test_risk_classification_minimal(self):
        """Unrecognized domains default to 'minimal'."""
        assert _classify_risk({"domain": "weather_forecast"}) == "minimal"
        assert _classify_risk({}) == "minimal"

    def test_report_contains_regulatory_citations(self):
        """Result should contain article citations from the EU AI Act."""
        engine = EUAIActEngine()
        _, dag = _build_clean_dag()

        result = engine.check(dag, {"domain": "loan_approval"})

        assert len(result.citations) > 0
        assert any("Article" in c for c in result.citations), (
            f"Expected 'Article' references in citations, got: {result.citations}"
        )

    def test_high_risk_without_conformity_assessment(self):
        """High-risk domain without conformity assessment triggers warning."""
        engine = EUAIActEngine()
        _, dag = _build_clean_dag()

        result = engine.check(dag, {"domain": "credit_scoring"})

        conformity_findings = [
            f for f in result.findings
            if "conformity" in f.description.lower()
        ]
        assert len(conformity_findings) > 0

    def test_tamper_evidence_disabled_critical(self):
        """Explicitly disabling tamper evidence should produce CRITICAL."""
        engine = EUAIActEngine()
        _, dag = _build_clean_dag()

        result = engine.check(dag, {"tamper_evidence_enabled": False})

        tamper_criticals = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL and "tamper" in f.description.lower()
        ]
        assert len(tamper_criticals) > 0

    def test_metadata_risk_level_in_result(self):
        """The result metadata should contain the computed risk_level."""
        engine = EUAIActEngine()
        _, dag = _build_clean_dag()

        result = engine.check(dag, {"domain": "credit_scoring"})
        assert "risk_level" in result.metadata
        assert result.metadata["risk_level"] == "high"


# ============================================================================
# ECOA Engine Tests
# ============================================================================

class TestECOAEngine:
    """Tests for the ECOA / Regulation B compliance engine."""

    def test_instantiation_and_regulation_name(self):
        """Verify engine instantiates with correct regulation name."""
        engine = ECOAEngine()
        assert isinstance(engine, BaseComplianceEngine)
        assert engine.regulation_name == "ECOA / Reg B"

    def test_protected_attribute_detection_race(self):
        """Column named 'race' should be detected as protected."""
        is_protected, attr = _column_is_protected("race")
        assert is_protected is True
        assert attr == "race"

    def test_protected_attribute_detection_gender(self):
        """Column named 'gender' should be detected as protected."""
        is_protected, attr = _column_is_protected("gender")
        assert is_protected is True
        assert attr == "gender"

    def test_protected_attribute_detection_ethnicity(self):
        """Column named 'applicant_ethnicity' should be detected."""
        is_protected, attr = _column_is_protected("applicant_ethnicity")
        assert is_protected is True

    def test_protected_attribute_detection_age(self):
        """Column named 'age' should be detected as protected."""
        is_protected, attr = _column_is_protected("age")
        assert is_protected is True
        assert attr == "age"

    def test_non_protected_column(self):
        """Column named 'credit_score' should not be flagged."""
        is_protected, attr = _column_is_protected("credit_score")
        assert is_protected is False
        assert attr == ""

    def test_clean_pipeline_passes(self):
        """A pipeline with no protected data should pass ECOA checks."""
        engine = ECOAEngine()
        _, dag = _build_clean_dag()

        result = engine.check(dag)

        assert isinstance(result, ComplianceResult)
        assert result.passed is True
        info_findings = [
            f for f in result.findings
            if f.severity == Severity.INFO and "No protected" in f.description
        ]
        assert len(info_findings) > 0, (
            "Expected an INFO finding confirming no protected attributes"
        )

    def test_contaminated_pipeline_fails_with_protected(self):
        """A pipeline that uses demographics should produce CRITICAL findings."""
        engine = ECOAEngine()
        _, dag = _build_contaminated_dag()

        result = engine.check(dag)

        critical_findings = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL
        ]
        assert len(critical_findings) > 0, (
            "Expected CRITICAL findings for protected data in credit pipeline"
        )
        assert any(
            "12 CFR 1002.6(b)" in f.regulation_citation
            for f in critical_findings
        )

    def test_adverse_action_without_reasons_critical(self):
        """Adverse action without reasons should be CRITICAL."""
        engine = ECOAEngine()
        _, dag = _build_clean_dag()

        metadata = {
            "is_adverse_action": True,
        }

        result = engine.check(dag, metadata)

        adverse_criticals = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL
            and "adverse action" in f.description.lower()
        ]
        assert len(adverse_criticals) > 0

    def test_adverse_action_with_valid_reasons(self):
        """Adverse action with proper reasons should not produce CRITICAL for reasons."""
        engine = ECOAEngine()
        _, dag = _build_clean_dag()

        metadata = {
            "is_adverse_action": True,
            "adverse_action_reasons": [
                "Insufficient credit history",
                "High debt-to-income ratio",
            ],
            "adverse_action_notice_date": "2024-01-15",
            "adverse_action_code_mapping": {"income": "AA01"},
        }

        result = engine.check(dag, metadata)

        reason_criticals = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL
            and "specific reasons" in f.description.lower()
        ]
        assert len(reason_criticals) == 0

    def test_adverse_action_too_many_reasons_warning(self):
        """More than 4 adverse action reasons should produce a WARNING."""
        engine = ECOAEngine()
        _, dag = _build_clean_dag()

        metadata = {
            "is_adverse_action": True,
            "adverse_action_reasons": [
                "Reason 1", "Reason 2", "Reason 3",
                "Reason 4", "Reason 5",
            ],
            "adverse_action_notice_date": "2024-01-15",
        }

        result = engine.check(dag, metadata)

        reason_warnings = [
            f for f in result.findings
            if f.severity == Severity.WARNING
            and "adverse action reasons" in f.description.lower()
        ]
        assert len(reason_warnings) > 0

    def test_disparate_impact_below_threshold_critical(self):
        """Disparate impact ratio below 80% should flag CRITICAL."""
        engine = ECOAEngine()
        _, dag = _build_clean_dag()

        metadata = {
            "disparate_impact_analysis": {
                "black_applicants": 0.65,
                "hispanic_applicants": 0.72,
            },
        }

        result = engine.check(dag, metadata)

        impact_criticals = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL
            and "disparate impact" in f.description.lower()
        ]
        assert len(impact_criticals) >= 2, (
            "Expected CRITICAL findings for both groups below 80% threshold"
        )

    def test_record_retention_below_minimum(self):
        """Record retention below 25 months should be CRITICAL."""
        engine = ECOAEngine()
        _, dag = _build_clean_dag()

        result = engine.check(dag, {"record_retention_months": 12})

        retention_criticals = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL
            and "retention" in f.description.lower()
        ]
        assert len(retention_criticals) > 0

    def test_protected_influence_percentage_in_metadata(self):
        """Result metadata should include protected_influence_pct."""
        engine = ECOAEngine()
        _, dag = _build_contaminated_dag()

        result = engine.check(dag)

        assert "protected_influence_pct" in result.metadata
        assert result.metadata["protected_influence_pct"] >= 0

    def test_age_specific_ecoa_finding(self):
        """Age data in credit pipeline should trigger age-specific ECOA warning."""
        engine = ECOAEngine()
        _, dag = _build_contaminated_dag()

        result = engine.check(dag)

        age_findings = [
            f for f in result.findings
            if "age" in f.description.lower()
            and "12 CFR 1002.6(b)(2)" in f.regulation_citation
        ]
        assert len(age_findings) > 0, (
            "Expected an age-specific finding referencing 12 CFR 1002.6(b)(2)"
        )


# ============================================================================
# Compliance Reports Tests
# ============================================================================

class TestComplianceReports:
    """Tests for the HTML compliance report generator."""

    def test_generate_report_clean_dag(self):
        """Report generation with a clean DAG should produce valid HTML."""
        _, dag = _build_clean_dag()

        html = generate_report(dag=dag, title="Clean Pipeline Report")

        assert isinstance(html, str)
        assert "<!DOCTYPE html>" in html
        assert "Clean Pipeline Report" in html

    def test_generate_report_contaminated_dag(self):
        """Report generation with a contaminated DAG should flag protected data."""
        _, dag = _build_contaminated_dag()

        html = generate_report(dag=dag, title="Contaminated Pipeline Report")

        assert isinstance(html, str)
        assert "FAIL" in html or "Protected Data" in html or "DETECTED" in html

    def test_report_contains_expected_sections(self):
        """The generated report should contain all standard sections."""
        _, dag = _build_financial_dag()

        html = generate_report(dag=dag, title="Financial Model Report")

        assert "Executive Summary" in html
        assert "Computation Graph" in html
        assert "Source Data Lineage" in html
        assert "Protected Data Analysis" in html
        assert "Report Verification" in html

    def test_report_with_compliance_results(self):
        """Report should render compliance findings passed as dicts."""
        _, dag = _build_clean_dag()

        compliance_results = [
            {
                "regulation": "EU AI Act",
                "passed": True,
                "summary": "All checks passed",
                "findings": [
                    {
                        "severity": "INFO",
                        "description": "System classified as HIGH-RISK",
                        "citation": "Article 6, Annex III",
                    }
                ],
            },
            {
                "regulation": "ECOA / Reg B",
                "passed": True,
                "summary": "No protected attributes detected",
                "findings": [],
            },
        ]

        html = generate_report(
            dag=dag,
            compliance_results=compliance_results,
            title="Multi-Reg Report",
        )

        assert "EU AI Act" in html
        assert "ECOA / Reg B" in html
        assert "Article 6, Annex III" in html

    def test_report_includes_regulatory_citations_via_engines(self):
        """Report generated with regulation names should invoke engines and include citations."""
        _, dag = _build_clean_dag()

        html = generate_report(
            dag=dag,
            title="Engine-Driven Report",
            regulations=["eu_ai_act", "ecoa"],
        )

        assert isinstance(html, str)
        assert "<!DOCTYPE html>" in html
        assert len(html) > 500

    def test_multi_regulation_report(self):
        """A report with both regulations should contain all engine outputs."""
        _, dag = _build_financial_dag()

        html = generate_report(
            dag=dag,
            title="Full Compliance Report",
            regulations=["eu_ai_act", "ecoa"],
        )

        assert isinstance(html, str)
        assert len(html) > 1000

    def test_report_config_customization(self):
        """ReportConfig should allow customization of title and organization."""
        config = ReportConfig(
            title="Custom Title",
            organization="Acme Corp",
            analyst="Jane Doe",
        )

        assert config.title == "Custom Title"
        assert config.organization == "Acme Corp"
        assert config.analyst == "Jane Doe"

    def test_report_generator_direct_use(self):
        """ComplianceReportGenerator can be used directly."""
        _, dag = _build_clean_dag()

        config = ReportConfig(title="Direct Test", organization="TestCo")
        generator = ComplianceReportGenerator(config)

        html = generator.generate(dag=dag)

        assert isinstance(html, str)
        assert "Direct Test" in html
        assert "TestCo" in html

    def test_report_verification_section_has_hash(self):
        """The verification section should include a SHA-256 hash."""
        _, dag = _build_clean_dag()

        html = generate_report(dag=dag, title="Hash Test")

        assert "SHA-256" in html

    def test_report_with_failed_compliance(self):
        """A failed compliance result should render with FAILED badge."""
        _, dag = _build_contaminated_dag()

        compliance_results = [
            {
                "regulation": "ECOA / Reg B",
                "passed": False,
                "summary": "Protected attributes detected in credit model",
                "findings": [
                    {
                        "severity": "CRITICAL",
                        "description": "Race data flows into credit decision",
                        "citation": "12 CFR 1002.6(b)",
                        "remediation": "Remove protected attributes from features",
                    },
                ],
            },
        ]

        html = generate_report(
            dag=dag,
            compliance_results=compliance_results,
            title="Failed Compliance Report",
        )

        assert "FAILED" in html or "FAIL" in html
        assert "CRITICAL" in html
        assert "12 CFR 1002.6(b)" in html


# ============================================================================
# Cross-Engine Integration Tests
# ============================================================================

class TestCrossEngineIntegration:
    """Integration tests that run multiple engines on the same DAG."""

    def test_compliance_report_aggregation(self):
        """ComplianceReport should aggregate results from multiple engines."""
        _, dag = _build_contaminated_dag()

        report = ComplianceReport()
        report.run_engines(
            engines=[EUAIActEngine(), ECOAEngine()],
            dag=dag,
        )

        assert len(report.results) == 2
        assert report.total_findings > 0
        assert len(report.all_citations) > 0

    def test_cross_engine_overall_passed(self):
        """If any engine fails, overall_passed should be False."""
        _, dag = _build_contaminated_dag()

        report = ComplianceReport()
        report.run_engines(
            engines=[EUAIActEngine(), ECOAEngine()],
            dag=dag,
        )

        assert report.overall_passed is False

    def test_clean_dag_all_engines_metadata_present(self):
        """All engines should produce metadata even for clean DAGs."""
        _, dag = _build_clean_dag()

        metadata = {
            "domain": "credit_scoring",
            "human_oversight_mode": "human_in_the_loop",
            "override_capability": True,
            "intended_purpose": "Credit decisioning",
            "known_limitations": "None known",
            "accuracy_metrics": {"auc": 0.9},
            "robustness_testing": True,
            "quality_management_system": True,
            "training_data_description": "Historical data",
            "start_time": "2024-01-01T00:00:00",
            "end_time": "2024-01-01T00:05:00",
            "model_version": "v1.0",
            "conformity_assessment": True,
            "eu_database_registration": "EU-DB-999",
        }

        engines = [EUAIActEngine(), ECOAEngine()]
        for engine in engines:
            result = engine.check(dag, metadata)
            assert isinstance(result.metadata, dict), (
                f"{engine.regulation_name} did not return metadata dict"
            )

    def test_to_dict_serialization_all_engines(self):
        """All engines should produce JSON-serializable to_dict() output."""
        import json

        _, dag = _build_financial_dag()

        engines = [EUAIActEngine(), ECOAEngine()]
        for engine in engines:
            result = engine.check(dag)
            d = result.to_dict()
            serialized = json.dumps(d)
            assert isinstance(serialized, str), (
                f"{engine.regulation_name} to_dict() is not JSON-serializable"
            )

    def test_summary_counts(self):
        """ComplianceResult should correctly tally critical/warning/info counts."""
        _, dag = _build_contaminated_dag()

        engine = ECOAEngine()
        result = engine.check(dag)

        total = result.critical_count + result.warning_count + result.info_count
        assert total == len(result.findings)
        assert result.critical_count > 0
