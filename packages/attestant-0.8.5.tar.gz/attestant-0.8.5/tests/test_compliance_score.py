"""Tests for the ComplianceScorer board-reportable risk metric."""

import pytest
from datetime import datetime, timezone

from attestant.compliance.base import (
    ComplianceFinding,
    ComplianceReport,
    ComplianceResult,
    Severity,
)
from attestant.compliance.score import (
    ComplianceScorer,
    ComplianceScoreResult,
    ScoreBreakdown,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_result(
    regulation: str,
    criticals: int = 0,
    warnings: int = 0,
    infos: int = 0,
    passed: bool = True,
) -> ComplianceResult:
    """Build a ComplianceResult with the given finding counts."""
    findings = []
    for _ in range(criticals):
        findings.append(ComplianceFinding(
            severity=Severity.CRITICAL,
            description=f"Critical finding for {regulation}",
            regulation_citation=f"{regulation} § test",
            remediation="Fix this immediately.",
        ))
    for _ in range(warnings):
        findings.append(ComplianceFinding(
            severity=Severity.WARNING,
            description=f"Warning for {regulation}",
            regulation_citation=f"{regulation} § test",
            remediation="Address in next cycle.",
        ))
    for _ in range(infos):
        findings.append(ComplianceFinding(
            severity=Severity.INFO,
            description=f"Info for {regulation}",
            regulation_citation=f"{regulation} § test",
        ))
    if criticals > 0:
        passed = False
    return ComplianceResult(
        passed=passed,
        regulation_name=regulation,
        findings=findings,
        citations=[f"{regulation} § test"],
    )


def _make_report(*results: ComplianceResult) -> ComplianceReport:
    """Build a ComplianceReport from results."""
    report = ComplianceReport()
    for r in results:
        report.add(r)
    return report


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestComplianceScorerPerfectScore:
    """Test scoring with no findings (perfect compliance)."""

    def test_perfect_score_single_engine(self):
        report = _make_report(_make_result("ECOA / Reg B"))
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert result.score == 100.0
        assert result.grade == "A"

    def test_perfect_score_all_engines(self):
        report = _make_report(
            _make_result("ECOA / Reg B"),
            _make_result("SR 11-7 / OCC 2011-12"),
            _make_result("EU AI Act"),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert result.score == 100.0
        assert result.grade == "A"
        assert result.engines_evaluated == 3

    def test_empty_report(self):
        report = ComplianceReport()
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert result.score == 100.0
        assert result.grade == "A"
        assert result.engines_evaluated == 0


class TestComplianceScorerDeductions:
    """Test deduction logic for findings."""

    def test_single_critical_ecoa(self):
        """ECOA critical = 8 * 1.5 weight = 12 point deduction."""
        report = _make_report(_make_result("ECOA / Reg B", criticals=1))
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert result.score == 88.0
        assert result.grade == "B"
        assert result.critical_findings == 1

    def test_single_warning_sr117(self):
        """SR 11-7 warning = 3 * 1.3 weight = 3.9 point deduction."""
        report = _make_report(
            _make_result("SR 11-7 / OCC 2011-12", warnings=1)
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert abs(result.score - 96.1) < 0.1
        assert result.grade == "A"

    def test_multiple_findings_weighted(self):
        """Multiple findings across weighted regulations."""
        report = _make_report(
            _make_result("ECOA / Reg B", criticals=2, warnings=1),
            _make_result("EU AI Act", warnings=3),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        # ECOA: (2*8 + 1*3) * 1.5 = 28.5
        # EU AI: (3*3) * 1.2 = 10.8
        # Total deduction: 39.3
        expected = 100.0 - 39.3
        assert abs(result.score - expected) < 0.1
        assert result.grade == "C"

    def test_score_floor_at_zero(self):
        """Score cannot go below 0."""
        report = _make_report(
            _make_result("ECOA / Reg B", criticals=10, warnings=10),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert result.score == 0.0
        assert result.grade == "F"

    def test_info_findings_no_deduction(self):
        """INFO findings should not cause deductions."""
        report = _make_report(
            _make_result("ECOA / Reg B", infos=5),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert result.score == 100.0

    def test_unknown_regulation_default_weight(self):
        """Unknown regulation uses default weight of 1.0."""
        report = _make_report(
            _make_result("Unknown Regulation", criticals=1),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        # 1 critical * 8 * 1.0 = 8 point deduction
        assert result.score == 92.0
        assert result.grade == "A"


class TestComplianceScorerBonuses:
    """Test proactive control bonuses."""

    def test_all_bonuses(self):
        report = _make_report(
            _make_result("ECOA / Reg B", warnings=2),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report, proactive_controls={
            "has_certifications": True,
            "has_monitoring": True,
            "has_fairness_analysis": True,
            "has_decision_logging": True,
            "has_data_governance": True,
            "has_model_inventory": True,
        })
        # Deduction: 2*3*1.5 = 9.0
        # Bonuses: 3+3+3+2+2+2 = 15.0
        # Score: 100 - 9 + 15 = 106 -> capped at 100
        assert result.score == 100.0
        assert len(result.bonuses_applied) == 6

    def test_partial_bonuses(self):
        report = _make_report(
            _make_result("ECOA / Reg B", criticals=1),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report, proactive_controls={
            "has_certifications": True,
            "has_monitoring": True,
        })
        # Deduction: 1*8*1.5 = 12.0
        # Bonuses: 3+3 = 6.0
        # Score: 100 - 12 + 6 = 94.0
        assert result.score == 94.0
        assert result.grade == "A"
        assert len(result.bonuses_applied) == 2

    def test_no_bonus_for_false_controls(self):
        report = _make_report(_make_result("ECOA / Reg B"))
        scorer = ComplianceScorer()
        result = scorer.score(report, proactive_controls={
            "has_certifications": False,
            "has_monitoring": False,
        })
        assert result.score == 100.0
        assert len(result.bonuses_applied) == 0


class TestComplianceScorerGrades:
    """Test grade boundaries."""

    def test_grade_a(self):
        scorer = ComplianceScorer()
        assert scorer._grade(100.0) == "A"
        assert scorer._grade(90.0) == "A"
        assert scorer._grade(95.5) == "A"

    def test_grade_b(self):
        scorer = ComplianceScorer()
        assert scorer._grade(89.9) == "B"
        assert scorer._grade(75.0) == "B"

    def test_grade_c(self):
        scorer = ComplianceScorer()
        assert scorer._grade(74.9) == "C"
        assert scorer._grade(60.0) == "C"

    def test_grade_d(self):
        scorer = ComplianceScorer()
        assert scorer._grade(59.9) == "D"
        assert scorer._grade(40.0) == "D"

    def test_grade_f(self):
        scorer = ComplianceScorer()
        assert scorer._grade(39.9) == "F"
        assert scorer._grade(0.0) == "F"


class TestComplianceScorerTrend:
    """Test trend calculation."""

    def test_no_history_no_trend(self):
        report = _make_report(_make_result("ECOA / Reg B"))
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert result.trend is None

    def test_improving_trend(self):
        report_bad = _make_report(
            _make_result("ECOA / Reg B", criticals=3)
        )
        report_good = _make_report(
            _make_result("ECOA / Reg B", warnings=1)
        )
        scorer = ComplianceScorer()
        scorer.score(report_bad)  # first score, no trend
        result = scorer.score(report_good)  # second score
        assert result.trend == "improving"

    def test_declining_trend(self):
        report_good = _make_report(_make_result("ECOA / Reg B"))
        report_bad = _make_report(
            _make_result("ECOA / Reg B", criticals=3)
        )
        scorer = ComplianceScorer()
        scorer.score(report_good)
        result = scorer.score(report_bad)
        assert result.trend == "declining"

    def test_stable_trend(self):
        report = _make_report(
            _make_result("ECOA / Reg B", warnings=1)
        )
        scorer = ComplianceScorer()
        scorer.score(report)
        result = scorer.score(report)
        assert result.trend == "stable"


class TestComplianceScorerBreakdowns:
    """Test per-regulation breakdown details."""

    def test_breakdown_fields(self):
        report = _make_report(
            _make_result("ECOA / Reg B", criticals=1, warnings=2, infos=3),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert len(result.breakdowns) == 1
        bd = result.breakdowns[0]
        assert bd.regulation == "ECOA / Reg B"
        assert bd.weight == 1.5
        assert bd.critical_count == 1
        assert bd.warning_count == 2
        assert bd.info_count == 3
        assert bd.raw_deduction == (1 * 8.0 + 2 * 3.0)  # 14.0
        assert bd.weighted_deduction == 14.0 * 1.5  # 21.0
        assert bd.passed is False

    def test_breakdown_serialization(self):
        report = _make_report(
            _make_result("EU AI Act", warnings=1),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        bd_dict = result.breakdowns[0].to_dict()
        assert "regulation" in bd_dict
        assert "weight" in bd_dict
        assert "weighted_deduction" in bd_dict


class TestComplianceScorerSerialization:
    """Test serialization and board summary."""

    def test_to_dict(self):
        report = _make_report(
            _make_result("ECOA / Reg B", criticals=1),
            _make_result("SR 11-7 / OCC 2011-12", warnings=2),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report, proactive_controls={
            "has_certifications": True,
        })
        d = result.to_dict()
        assert "score" in d
        assert "grade" in d
        assert "timestamp" in d
        assert "breakdowns" in d
        assert len(d["breakdowns"]) == 2
        assert "bonuses_applied" in d
        assert "top_risks" in d

    def test_board_summary_string(self):
        report = _make_report(
            _make_result("ECOA / Reg B", criticals=1, warnings=1),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        summary = result.board_summary()
        assert "COMPLIANCE SCORE:" in summary
        assert "Grade:" in summary
        assert "TOP RISKS:" in summary
        assert "PER-REGULATION STATUS:" in summary
        assert "ECOA / Reg B" in summary

    def test_board_summary_no_risks(self):
        report = _make_report(_make_result("ECOA / Reg B"))
        scorer = ComplianceScorer()
        result = scorer.score(report)
        summary = result.board_summary()
        assert "COMPLIANCE SCORE: 100/100" in summary
        assert "Grade: A" in summary


class TestComplianceScorerCustomWeights:
    """Test custom regulation weights."""

    def test_custom_weights(self):
        custom = {"Custom Reg": 2.0}
        report = _make_report(
            _make_result("Custom Reg", criticals=1),
        )
        scorer = ComplianceScorer(regulation_weights=custom)
        result = scorer.score(report)
        # 1 critical * 8 * 2.0 = 16 point deduction
        assert result.score == 84.0
        assert result.grade == "B"


class TestComplianceScorerTopRisks:
    """Test top risk extraction."""

    def test_top_risks_from_criticals(self):
        report = _make_report(
            _make_result("ECOA / Reg B", criticals=3),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert len(result.top_risks) == 3
        for risk in result.top_risks:
            assert "[ECOA / Reg B]" in risk

    def test_top_risks_capped_at_five(self):
        report = _make_report(
            _make_result("ECOA / Reg B", criticals=4),
            _make_result("EU AI Act", criticals=4),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert len(result.top_risks) <= 5

    def test_no_risks_for_warnings_only(self):
        report = _make_report(
            _make_result("ECOA / Reg B", warnings=3),
        )
        scorer = ComplianceScorer()
        result = scorer.score(report)
        assert len(result.top_risks) == 0


class TestComplianceScorerImport:
    """Test that ComplianceScorer is accessible from expected paths."""

    def test_import_from_compliance(self):
        from attestant.compliance import ComplianceScorer
        assert ComplianceScorer is not None

    def test_import_from_top_level(self):
        from proveit import ComplianceScorer
        assert ComplianceScorer is not None

    def test_import_score_result(self):
        from attestant.compliance import ComplianceScoreResult, ScoreBreakdown
        assert ComplianceScoreResult is not None
        assert ScoreBreakdown is not None
