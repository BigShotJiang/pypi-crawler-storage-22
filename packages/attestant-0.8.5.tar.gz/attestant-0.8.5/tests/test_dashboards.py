"""Tests for dashboard applications (client + admin) and DashboardStore.

Covers:
- DashboardStore schema and methods (mocked psycopg2)
- Client Flask app routes and demo data
- Admin Flask app routes, demo data, and auth
"""

import json
import pytest
from unittest.mock import MagicMock, patch, PropertyMock


# ============================================================================
# DashboardStore Tests
# ============================================================================

class TestDashboardStoreSchema:
    """Verify DashboardStore schema DDL and structure."""

    def test_schema_sql_creates_all_tables(self):
        from attestant.dashboard.dashdb import _SCHEMA_SQL
        expected_tables = [
            "tenants", "compliance_snapshots", "model_snapshots",
            "fairness_snapshots", "certification_snapshots",
            "alert_log", "pipeline_stats", "system_metrics",
        ]
        for table in expected_tables:
            assert f"CREATE TABLE IF NOT EXISTS {table}" in _SCHEMA_SQL

    def test_schema_sql_creates_indexes(self):
        from attestant.dashboard.dashdb import _SCHEMA_SQL
        assert _SCHEMA_SQL.count("CREATE INDEX IF NOT EXISTS") >= 8

    def test_schema_has_tenant_fk(self):
        from attestant.dashboard.dashdb import _SCHEMA_SQL
        assert "REFERENCES tenants(tenant_id)" in _SCHEMA_SQL

    def test_schema_has_jsonb_columns(self):
        from attestant.dashboard.dashdb import _SCHEMA_SQL
        assert "JSONB" in _SCHEMA_SQL


class TestDashboardStoreInit:
    """Test DashboardStore initialization."""

    def test_default_reader_dsn(self):
        from attestant.dashboard.dashdb import DashboardStore
        store = DashboardStore(writer_dsn="postgresql://writer/db")
        assert store.reader_dsn == "postgresql://writer/db"

    def test_separate_reader_dsn(self):
        from attestant.dashboard.dashdb import DashboardStore
        store = DashboardStore(
            writer_dsn="postgresql://writer/db",
            reader_dsn="postgresql://reader/db",
        )
        assert store.writer_dsn == "postgresql://writer/db"
        assert store.reader_dsn == "postgresql://reader/db"

    def test_pool_defaults(self):
        from attestant.dashboard.dashdb import DashboardStore
        store = DashboardStore(writer_dsn="x")
        assert store.min_conn == 2
        assert store.max_conn == 10

    def test_custom_pool_size(self):
        from attestant.dashboard.dashdb import DashboardStore
        store = DashboardStore(writer_dsn="x", min_conn=5, max_conn=20)
        assert store.min_conn == 5
        assert store.max_conn == 20


class TestDashboardStoreDisconnect:
    """Test DashboardStore disconnect."""

    def test_disconnect_closes_pools(self):
        from attestant.dashboard.dashdb import DashboardStore
        store = DashboardStore(writer_dsn="x")
        mock_pool = MagicMock()
        store._writer_pool = mock_pool
        store._reader_pool = mock_pool
        store.disconnect()
        mock_pool.closeall.assert_called_once()
        assert store._writer_pool is None
        assert store._reader_pool is None

    def test_disconnect_closes_separate_pools(self):
        from attestant.dashboard.dashdb import DashboardStore
        store = DashboardStore(writer_dsn="x")
        writer_pool = MagicMock()
        reader_pool = MagicMock()
        store._writer_pool = writer_pool
        store._reader_pool = reader_pool
        store.disconnect()
        writer_pool.closeall.assert_called_once()
        reader_pool.closeall.assert_called_once()

    def test_disconnect_noop_if_not_connected(self):
        from attestant.dashboard.dashdb import DashboardStore
        store = DashboardStore(writer_dsn="x")
        store.disconnect()  # Should not raise


# ============================================================================
# Client Dashboard Tests
# ============================================================================

class TestClientDashboardApp:
    """Test the client dashboard Flask app in demo mode."""

    @pytest.fixture
    def client(self):
        import attestant.dashboard.client_app as capp
        capp.DASH_MODE = "demo"
        capp.TENANT_ID = "test_tenant"
        capp.app.config["TESTING"] = True
        with capp.app.test_client() as c:
            yield c

    def test_index_returns_html(self, client):
        resp = client.get("/")
        assert resp.status_code == 200
        assert b"Compliance Dashboard" in resp.data

    def test_health_endpoint(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert data["status"] == "healthy"
        assert data["tenant"] == "test_tenant"

    def test_compliance_endpoint(self, client):
        resp = client.get("/api/compliance")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert "score" in data
        assert "grade" in data
        assert data["grade"] in ("A", "B", "C", "D", "F")
        assert 0 <= data["score"] <= 100

    def test_compliance_history_endpoint(self, client):
        resp = client.get("/api/compliance/history")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert isinstance(data, list)
        assert len(data) > 0
        assert "score" in data[0]

    def test_models_endpoint(self, client):
        resp = client.get("/api/models")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert isinstance(data, list)
        assert len(data) > 0
        assert "model_id" in data[0]
        assert "tier" in data[0]

    def test_fairness_endpoint(self, client):
        resp = client.get("/api/fairness")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert isinstance(data, list)
        for f in data:
            assert "worst_ratio" in f
            assert "p_value" in f

    def test_calendar_endpoint(self, client):
        resp = client.get("/api/calendar")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert "all_deadlines" in data
        assert "overdue_count" in data

    def test_certifications_endpoint(self, client):
        resp = client.get("/api/certifications")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert isinstance(data, list)

    def test_alerts_endpoint(self, client):
        resp = client.get("/api/alerts")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert isinstance(data, list)
        # Should have at least one critical alert in demo
        critical = [a for a in data if a["severity"] == "critical"]
        assert len(critical) > 0


class TestClientDemoData:
    """Validate the structure of demo data functions."""

    def test_demo_compliance_has_breakdowns(self):
        from attestant.dashboard.client_app import _demo_compliance
        data = _demo_compliance()
        assert len(data["breakdowns"]) == 5
        for b in data["breakdowns"]:
            assert "regulation" in b
            assert "passed" in b
            assert "weighted_deduction" in b

    def test_demo_models_have_required_fields(self):
        from attestant.dashboard.client_app import _demo_models
        for m in _demo_models():
            assert "model_id" in m
            assert "name" in m
            assert "tier" in m
            assert m["tier"] in (1, 2, 3)

    def test_demo_fairness_has_stats(self):
        from attestant.dashboard.client_app import _demo_fairness
        for f in _demo_fairness():
            assert "has_disparate_impact" in f
            assert "worst_ratio" in f
            assert "p_value" in f
            assert "statistically_significant" in f

    def test_demo_alerts_have_severity(self):
        from attestant.dashboard.client_app import _demo_alerts
        for a in _demo_alerts():
            assert a["severity"] in ("critical", "warning", "info")


# ============================================================================
# Admin Dashboard Tests
# ============================================================================

class TestAdminDashboardApp:
    """Test the admin dashboard Flask app in demo mode."""

    @pytest.fixture
    def client(self):
        import attestant.dashboard.admin_app as aapp
        aapp.DASH_MODE = "demo"
        aapp.ADMIN_TOKEN = "test-token"
        aapp.app.config["TESTING"] = True
        with aapp.app.test_client() as c:
            yield c

    def test_index_returns_html(self, client):
        resp = client.get("/")
        assert resp.status_code == 200
        assert b"Admin Console" in resp.data

    def test_health_endpoint(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert data["role"] == "admin"

    def test_tenants_endpoint(self, client):
        resp = client.get("/api/tenants")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert isinstance(data, list)
        assert len(data) >= 3
        for t in data:
            assert "tenant_id" in t
            assert "name" in t

    def test_system_health_endpoint(self, client):
        resp = client.get("/api/system-health")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert "tenant_count" in data
        assert "total_models" in data
        assert "avg_compliance_score" in data

    def test_pipelines_endpoint(self, client):
        resp = client.get("/api/pipelines")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert isinstance(data, list)
        for p in data:
            assert "status" in p
            assert "tenant_id" in p

    def test_metrics_endpoint(self, client):
        resp = client.get("/api/metrics")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert isinstance(data, list)
        metric_names = [m["metric_name"] for m in data]
        assert "api_requests_1h" in metric_names
        assert "error_rate_1h" in metric_names

    def test_alerts_endpoint(self, client):
        resp = client.get("/api/alerts")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert isinstance(data, list)

    def test_calendar_endpoint(self, client):
        resp = client.get("/api/calendar")
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert "all_deadlines" in data


class TestAdminAuth:
    """Test admin dashboard authentication."""

    @pytest.fixture
    def secured_client(self):
        import attestant.dashboard.admin_app as aapp
        aapp.DASH_MODE = "production"
        aapp.ADMIN_TOKEN = "secret-123"
        # Mock _get_store so we don't need a real DSN
        aapp._store = None
        aapp.app.config["TESTING"] = True
        with patch.object(aapp, "_get_store", return_value=None):
            with aapp.app.test_client() as c:
                yield c
        aapp.DASH_MODE = "demo"

    def test_unauthenticated_returns_401(self, secured_client):
        resp = secured_client.get("/api/tenants")
        assert resp.status_code == 401

    def test_bearer_token_auth(self, secured_client):
        resp = secured_client.get("/api/tenants",
                                  headers={"Authorization": "Bearer secret-123"})
        assert resp.status_code == 200

    def test_query_param_auth_rejected(self, secured_client):
        """Query string tokens are no longer accepted (leak via logs/referrer)."""
        resp = secured_client.get("/api/system-health?token=secret-123")
        assert resp.status_code == 401

    def test_wrong_token_returns_401(self, secured_client):
        resp = secured_client.get("/api/tenants",
                                  headers={"Authorization": "Bearer wrong"})
        assert resp.status_code == 401


class TestAdminDemoData:
    """Validate admin demo data structure."""

    def test_demo_tenants_structure(self):
        from attestant.dashboard.admin_app import _demo_tenants
        tenants = _demo_tenants()
        assert len(tenants) >= 3
        for t in tenants:
            assert "tenant_id" in t
            assert "name" in t
            assert "tier" in t
            assert "model_count" in t
            assert "open_alerts" in t

    def test_demo_system_health_structure(self):
        from attestant.dashboard.admin_app import _demo_system_health
        h = _demo_system_health()
        assert h["tenant_count"] > 0
        assert h["total_models"] > 0
        assert h["avg_compliance_score"] > 0

    def test_demo_pipeline_stats_structure(self):
        from attestant.dashboard.admin_app import _demo_pipeline_stats
        stats = _demo_pipeline_stats()
        assert len(stats) > 0
        for s in stats:
            assert s["status"] in ("completed", "failed", "running")
            assert "duration_ms" in s

    def test_demo_metrics_have_names(self):
        from attestant.dashboard.admin_app import _demo_metrics
        metrics = _demo_metrics()
        names = {m["metric_name"] for m in metrics}
        assert "api_requests_1h" in names
        assert "error_rate_1h" in names
        assert "storage_gb" in names


# ============================================================================
# Examiner Readiness + Action Items Tests
# ============================================================================

class TestExaminerReadiness:
    """Test the examiner-readiness API endpoint."""

    @pytest.fixture
    def client(self):
        import attestant.dashboard.client_app as capp
        capp.DASH_MODE = "demo"
        capp.TENANT_ID = "test_tenant"
        capp.app.config["TESTING"] = True
        with capp.app.test_client() as c:
            yield c

    def test_readiness_returns_200(self, client):
        resp = client.get("/api/examiner-readiness")
        assert resp.status_code == 200

    def test_readiness_has_overall_status(self, client):
        data = json.loads(client.get("/api/examiner-readiness").data)
        assert data["overall"] in ("ready", "warning", "not_ready")

    def test_readiness_has_checklist(self, client):
        data = json.loads(client.get("/api/examiner-readiness").data)
        assert "checklist" in data
        assert len(data["checklist"]) == 6

    def test_readiness_checklist_structure(self, client):
        data = json.loads(client.get("/api/examiner-readiness").data)
        for item in data["checklist"]:
            assert "category" in item
            assert "item" in item
            assert item["status"] in ("ready", "warning", "not_ready")

    def test_readiness_has_counts(self, client):
        data = json.loads(client.get("/api/examiner-readiness").data)
        assert data["ready_count"] >= 0
        assert data["total_count"] == 6
        assert data["ready_count"] <= data["total_count"]

    def test_readiness_categories_cover_all(self, client):
        data = json.loads(client.get("/api/examiner-readiness").data)
        categories = {c["category"] for c in data["checklist"]}
        assert "Compliance Score" in categories
        assert "Critical Findings" in categories
        assert "Model Inventory" in categories
        assert "Fair Lending (ECOA)" in categories
        assert "Certifications" in categories
        assert "Open Alerts" in categories


class TestActionItems:
    """Test the action-items API endpoint."""

    @pytest.fixture
    def client(self):
        import attestant.dashboard.client_app as capp
        capp.DASH_MODE = "demo"
        capp.TENANT_ID = "test_tenant"
        capp.app.config["TESTING"] = True
        with capp.app.test_client() as c:
            yield c

    def test_action_items_returns_200(self, client):
        resp = client.get("/api/action-items")
        assert resp.status_code == 200

    def test_action_items_is_list(self, client):
        data = json.loads(client.get("/api/action-items").data)
        assert isinstance(data, list)
        assert len(data) > 0

    def test_action_items_structure(self, client):
        data = json.loads(client.get("/api/action-items").data)
        for item in data:
            assert "priority" in item
            assert "type" in item
            assert item["type"] in ("alert", "validation", "fairness")
            assert "title" in item
            assert "severity" in item
            assert item["severity"] in ("critical", "warning", "info")

    def test_action_items_sorted_by_priority(self, client):
        data = json.loads(client.get("/api/action-items").data)
        priorities = [item["priority"] for item in data]
        assert priorities == sorted(priorities)

    def test_action_items_has_fairness_items(self, client):
        data = json.loads(client.get("/api/action-items").data)
        fairness_items = [i for i in data if i["type"] == "fairness"]
        assert len(fairness_items) > 0

    def test_action_items_has_validation_items(self, client):
        data = json.loads(client.get("/api/action-items").data)
        val_items = [i for i in data if i["type"] == "validation"]
        assert len(val_items) > 0


# ============================================================================
# DashboardSync Tests
# ============================================================================

class TestDashboardSync:
    """Test the DashboardSync integration helper."""

    def test_init(self):
        from attestant.dashboard.sync import DashboardSync
        store = MagicMock()
        sync = DashboardSync(store, "test_tenant")
        assert sync.tenant_id == "test_tenant"
        assert sync.store is store

    def test_push_compliance(self):
        from attestant.dashboard.sync import DashboardSync
        store = MagicMock()
        sync = DashboardSync(store, "t1")
        result = MagicMock()
        result.to_dict.return_value = {"score": 85, "grade": "B"}
        sync.push_compliance(result)
        store.insert_compliance_snapshot.assert_called_once_with(
            "t1", {"score": 85, "grade": "B"})

    def test_push_compliance_dict(self):
        from attestant.dashboard.sync import DashboardSync
        store = MagicMock()
        sync = DashboardSync(store, "t1")
        sync.push_compliance({"score": 90, "grade": "A"})
        store.insert_compliance_snapshot.assert_called_once_with(
            "t1", {"score": 90, "grade": "A"})

    def test_push_models(self):
        from attestant.dashboard.sync import DashboardSync
        store = MagicMock()
        sync = DashboardSync(store, "t1")
        registry = MagicMock()
        record = MagicMock()
        record.model_id = "m1"
        record.name = "Model 1"
        record.version = "1.0"
        record.tier = 1
        record.status = MagicMock(value="production")
        record.domain = "lending"
        record.owner = "MRM"
        registry._models = {"m1": record}
        n = sync.push_models(registry)
        assert n == 1
        store.upsert_model_snapshot.assert_called_once()

    def test_push_fairness(self):
        from attestant.dashboard.sync import DashboardSync
        store = MagicMock()
        sync = DashboardSync(store, "t1")
        result = {"has_disparate_impact": True, "worst_ratio": 0.78,
                  "worst_group": "race:Black", "p_values": {"race": 0.003},
                  "statistically_significant": True}
        sync.push_fairness("m1", result)
        store.insert_fairness_snapshot.assert_called_once()
        call_data = store.insert_fairness_snapshot.call_args[0][1]
        assert call_data["model_id"] == "m1"
        assert call_data["p_value"] == 0.003

    def test_push_certifications(self):
        from attestant.dashboard.sync import DashboardSync
        from datetime import date
        store = MagicMock()
        sync = DashboardSync(store, "t1")
        tracker = MagicMock()
        cert = MagicMock()
        cert.name = "SOC 2"
        cert.status.value = "active"
        cert.issue_date = date(2025, 1, 1)
        cert.expiration_date = date(2026, 1, 1)
        cert.days_until_expiration = 320
        tracker._certifications = [cert]
        n = sync.push_certifications(tracker)
        assert n == 1
        store.upsert_certification.assert_called_once()

    def test_push_alert(self):
        from attestant.dashboard.sync import DashboardSync
        store = MagicMock()
        store.insert_alert.return_value = 42
        sync = DashboardSync(store, "t1")
        aid = sync.push_alert("critical", "FairLens", "DI detected")
        assert aid == 42
        store.insert_alert.assert_called_once()

    def test_push_all(self):
        from attestant.dashboard.sync import DashboardSync
        store = MagicMock()
        sync = DashboardSync(store, "t1")
        comp = MagicMock()
        comp.to_dict.return_value = {"score": 85, "grade": "B"}
        counts = sync.push(compliance_result=comp)
        assert counts["compliance"] == 1
        store.insert_compliance_snapshot.assert_called_once()

    def test_pipeline_tracking(self):
        from attestant.dashboard.sync import DashboardSync
        store = MagicMock()
        sync = DashboardSync(store, "t1")
        sync.start_pipeline("credit_pipeline")
        sync.record_dag_stats(100, 200)
        sync.end_pipeline("completed")
        store.insert_pipeline_stat.assert_called_once()
        call_data = store.insert_pipeline_stat.call_args[0][1]
        assert call_data["pipeline_name"] == "credit_pipeline"
        assert call_data["status"] == "completed"
        assert call_data["node_count"] == 100
        assert call_data["duration_ms"] is not None

    def test_auto_context_manager(self):
        from attestant.dashboard.sync import DashboardSync
        store = MagicMock()
        with DashboardSync.auto(store, "t1", "test_pipeline") as sync:
            assert sync.tenant_id == "t1"
        store.insert_pipeline_stat.assert_called_once()
        call_data = store.insert_pipeline_stat.call_args[0][1]
        assert call_data["status"] == "completed"

    def test_auto_context_manager_on_error(self):
        from attestant.dashboard.sync import DashboardSync
        store = MagicMock()
        try:
            with DashboardSync.auto(store, "t1", "fail_pipeline") as sync:
                raise ValueError("test error")
        except ValueError:
            pass
        store.insert_pipeline_stat.assert_called_once()
        call_data = store.insert_pipeline_stat.call_args[0][1]
        assert call_data["status"] == "failed"


# ============================================================================
# Integration: Client + Calendar
# ============================================================================

class TestCalendarIntegration:
    """Test that the calendar endpoint returns real regulatory data."""

    @pytest.fixture
    def client(self):
        import attestant.dashboard.client_app as capp
        capp.DASH_MODE = "demo"
        capp.app.config["TESTING"] = True
        with capp.app.test_client() as c:
            yield c

    def test_calendar_has_eu_ai_act(self, client):
        resp = client.get("/api/calendar")
        data = json.loads(resp.data)
        regulations = {d["regulation"] for d in data["all_deadlines"]}
        assert "EU AI Act" in regulations

    def test_calendar_has_sr_11_7(self, client):
        resp = client.get("/api/calendar")
        data = json.loads(resp.data)
        regulations = {d["regulation"] for d in data["all_deadlines"]}
        assert "SR 11-7 / OCC 2011-12" in regulations

    def test_calendar_has_colorado(self, client):
        resp = client.get("/api/calendar")
        data = json.loads(resp.data)
        regulations = {d["regulation"] for d in data["all_deadlines"]}
        assert "Colorado AI Act" in regulations

    def test_calendar_deadlines_have_urgency(self, client):
        resp = client.get("/api/calendar")
        data = json.loads(resp.data)
        for d in data["all_deadlines"]:
            assert d["urgency"] in ("overdue", "immediate", "upcoming", "planned", "future")
