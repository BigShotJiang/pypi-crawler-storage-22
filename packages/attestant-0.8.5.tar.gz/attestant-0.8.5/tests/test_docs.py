"""
Comprehensive tests for AutoDoc: Automated Model & Pipeline Documentation.

Covers: engine, all seven templates, document report serialization,
metadata handling, and end-to-end generation.
"""

import json
import pytest

from attestant.docs.engine import (
    AutoDocEngine,
    DocumentReport,
    DocumentSection,
    ModelMetadata,
    PipelineMetadata,
    TemplateType,
)
from attestant.docs.templates import (
    SR117Template,
    EUAIActTemplate,
    ModelCardTemplate,
    ECOATemplate,
    DbtDocTemplate,
    GDPRTemplate,
    NISTAIRMFTemplate,
    TEMPLATE_REGISTRY,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def model_metadata():
    return ModelMetadata(
        name="credit_risk_v2",
        version="2.1.0",
        model_type="XGBoost Classifier",
        framework="xgboost 1.7.6",
        description="Credit risk scoring model for consumer lending",
        intended_use="Predicting probability of default for loan applications",
        limitations="Not validated for commercial loans or amounts over $500K",
        training_date="2026-01-15",
        feature_count=47,
        training_rows=250000,
        hyperparameters={
            "max_depth": 6,
            "learning_rate": 0.1,
            "n_estimators": 500,
            "subsample": 0.8,
        },
        performance_metrics={
            "AUC": 0.847,
            "Accuracy": 0.812,
            "Precision": 0.795,
            "Recall": 0.723,
            "F1": 0.757,
        },
        fairness_metrics={
            "disparate_impact_race": 0.74,
            "disparate_impact_sex": 0.91,
        },
        feature_names=["credit_score", "dti", "income", "loan_amount", "employment_length"],
        feature_importances={"credit_score": 0.25, "dti": 0.18, "income": 0.15},
        owner="Model Risk Team",
        contact="modelrisk@company.com",
        tags=["credit", "lending", "consumer"],
    )


@pytest.fixture
def pipeline_metadata():
    return PipelineMetadata(
        name="daily_revenue_pipeline",
        description="Aggregates daily revenue from multiple sources",
        source_tables=["raw_orders", "raw_payments", "raw_refunds"],
        output_tables=["fct_daily_revenue", "fct_monthly_summary"],
        transformation_steps=[
            {"name": "stg_orders", "description": "Clean and standardize orders"},
            {"name": "stg_payments", "description": "Normalize payment records"},
            {"name": "int_orders_enriched", "description": "Join orders with payments"},
            {"name": "fct_daily_revenue", "description": "Aggregate to daily level"},
        ],
        schedule="Daily at 06:00 UTC",
        owner="Data Engineering",
        data_quality_checks=[
            {"name": "row_count_check", "status": "pass"},
            {"name": "null_check_order_id", "status": "pass"},
            {"name": "revenue_range_check", "status": "warning"},
        ],
        dependencies=["dbt-core>=1.7", "dbt-postgres"],
        sla="Complete by 07:00 UTC",
        total_columns=89,
        total_rows=3200000,
    )


@pytest.fixture
def dag_data():
    return {
        "nodes": [
            {"id": "n1", "name": "raw_orders", "type": "source", "columns": ["id", "amount", "date"], "row_count": 1000000},
            {"id": "n2", "name": "raw_payments", "type": "source", "columns": ["id", "order_id", "method"], "row_count": 800000},
            {"id": "n3", "name": "stg_orders", "type": "transform", "description": "Cleaned orders"},
            {"id": "n4", "name": "int_enriched", "type": "transform", "description": "Enriched with payments"},
            {"id": "n5", "name": "fct_revenue", "type": "model", "columns": ["date", "revenue", "orders"]},
        ],
        "edges": [
            {"source": "n1", "target": "n3"},
            {"source": "n2", "target": "n4"},
            {"source": "n3", "target": "n4"},
            {"source": "n4", "target": "n5"},
        ],
    }


@pytest.fixture
def fairlens_report():
    return {
        "summary": {
            "critical": 2,
            "warnings": 1,
            "proxy_features_detected": 3,
            "lda_candidates_found": 2,
        },
        "findings": [
            {"severity": "critical", "description": "Disparate impact for race: ratio = 0.74"},
            {"severity": "critical", "description": "Proxy: zip_code correlates 0.83 with race"},
            {"severity": "warning", "description": "Adverse action insufficient for 23% of denials"},
        ],
        "disparate_impact": [
            {"protected_attribute": "race", "worst_ratio": 0.74, "has_disparate_impact": True},
            {"protected_attribute": "sex", "worst_ratio": 0.91, "has_disparate_impact": False},
        ],
        "proxy_detection": [
            {"feature_name": "zip_code", "protected_attribute": "race", "correlation": 0.83},
            {"feature_name": "census_tract", "protected_attribute": "race", "correlation": 0.77},
        ],
        "lda_candidates": [
            {"removed_features": ["zip_code"], "candidate_disparity": 0.81,
             "auc_loss_pct": 0.3, "passes_four_fifths": True},
            {"removed_features": ["zip_code", "census_tract"], "candidate_disparity": 0.85,
             "auc_loss_pct": 1.2, "passes_four_fifths": True},
        ],
        "adverse_action_samples": [
            {
                "prediction": 0,
                "reasons": [
                    {"code": "F02", "text": "Excessive obligations in relation to income"},
                    {"code": "B01", "text": "Proportion of balances to credit limits is too high"},
                ],
            },
        ],
    }


# ---------------------------------------------------------------------------
# DocumentSection tests
# ---------------------------------------------------------------------------

class TestDocumentSection:
    def test_to_markdown(self):
        section = DocumentSection(title="Test", content="Hello world", level=1)
        md = section.to_markdown()
        assert "# Test" in md
        assert "Hello world" in md

    def test_subsections(self):
        section = DocumentSection(
            title="Parent", content="Intro",
            subsections=[
                DocumentSection(title="Child", content="Detail", level=1),
            ],
        )
        md = section.to_markdown(base_level=2)
        assert "## Parent" in md
        assert "### Child" in md

    def test_to_dict(self):
        section = DocumentSection(title="T", content="C", level=2)
        d = section.to_dict()
        assert d["title"] == "T"
        assert d["level"] == 2


# ---------------------------------------------------------------------------
# DocumentReport tests
# ---------------------------------------------------------------------------

class TestDocumentReport:
    def test_to_markdown(self):
        report = DocumentReport(
            title="Test Report",
            template_type=TemplateType.MODEL_CARD,
            sections=[DocumentSection(title="Section 1", content="Content 1")],
            metadata={"Author": "Test"},
        )
        md = report.to_markdown()
        assert "# Test Report" in md
        assert "**Author:** Test" in md
        assert "Section 1" in md

    def test_to_json(self):
        report = DocumentReport(
            title="Test",
            template_type=TemplateType.SR_11_7,
            sections=[DocumentSection(title="S1", content="C1")],
        )
        data = json.loads(report.to_json())
        assert data["title"] == "Test"
        assert data["template_type"] == "sr11-7"
        assert len(data["sections"]) == 1

    def test_section_count(self):
        report = DocumentReport(
            title="T",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(title="S1", content="", subsections=[
                    DocumentSection(title="S1a", content=""),
                ]),
                DocumentSection(title="S2", content=""),
            ],
        )
        assert report.section_count == 3

    def test_word_count(self):
        report = DocumentReport(
            title="T",
            template_type=TemplateType.MODEL_CARD,
            sections=[DocumentSection(title="S", content="one two three four five")],
        )
        assert report.word_count >= 5

    def test_save_markdown(self, tmp_path):
        report = DocumentReport(
            title="T", template_type=TemplateType.MODEL_CARD,
            sections=[DocumentSection(title="S", content="C")],
        )
        path = tmp_path / "report.md"
        report.save(str(path))
        assert path.exists()
        assert "# T" in path.read_text()

    def test_save_json(self, tmp_path):
        report = DocumentReport(
            title="T", template_type=TemplateType.MODEL_CARD,
            sections=[DocumentSection(title="S", content="C")],
        )
        path = tmp_path / "report.json"
        report.save(str(path))
        data = json.loads(path.read_text())
        assert data["title"] == "T"


# ---------------------------------------------------------------------------
# ModelMetadata tests
# ---------------------------------------------------------------------------

class TestModelMetadata:
    def test_create(self, model_metadata):
        assert model_metadata.name == "credit_risk_v2"
        assert model_metadata.feature_count == 47
        assert model_metadata.training_rows == 250000

    def test_to_dict(self, model_metadata):
        d = model_metadata.to_dict()
        assert d["name"] == "credit_risk_v2"
        assert d["performance_metrics"]["AUC"] == 0.847


class TestPipelineMetadata:
    def test_create(self, pipeline_metadata):
        assert pipeline_metadata.name == "daily_revenue_pipeline"
        assert len(pipeline_metadata.source_tables) == 3

    def test_to_dict(self, pipeline_metadata):
        d = pipeline_metadata.to_dict()
        assert "raw_orders" in d["source_tables"]


# ---------------------------------------------------------------------------
# Template tests
# ---------------------------------------------------------------------------

class TestSR117Template:
    def test_render_with_model(self, model_metadata, dag_data, fairlens_report):
        template = SR117Template()
        sections = template.render({
            "model": model_metadata,
            "pipeline": None,
            "dag_nodes": dag_data["nodes"],
            "dag_edges": dag_data["edges"],
            "fairlens_report": fairlens_report,
        })
        assert len(sections) == 16
        titles = [s.title for s in sections]
        assert "Executive Summary" in titles
        assert "Model Description" in titles
        assert "Fair Lending Review" in titles
        assert "Appendix A: Complete DAG Specification" in titles
        assert "Governance and Controls" in titles

    def test_executive_summary_content(self, model_metadata):
        template = SR117Template()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        summary = next(s for s in sections if s.title == "Executive Summary")
        assert "credit_risk_v2" in summary.content
        assert "250,000" in summary.content

    def test_feature_analysis_with_names(self, model_metadata):
        template = SR117Template()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        fa_section = next(s for s in sections if s.title == "Feature Analysis")
        assert "credit_score" in fa_section.content

    def test_title(self, model_metadata):
        template = SR117Template()
        title = template.get_title({"model": model_metadata, "pipeline": None})
        assert "credit_risk_v2" in title


class TestEUAIActTemplate:
    def test_render(self, model_metadata):
        template = EUAIActTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        assert len(sections) == 8
        titles = [s.title for s in sections]
        assert "General Description of the AI System" in titles
        assert "Human Oversight Measures" in titles
        assert "Logging and Traceability" in titles

    def test_risk_management_with_fairlens(self, model_metadata, fairlens_report):
        template = EUAIActTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": fairlens_report,
        })
        risk = next(s for s in sections if s.title == "Risk Management")
        assert "2 critical" in risk.content


class TestModelCardTemplate:
    def test_render(self, model_metadata):
        template = ModelCardTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        assert len(sections) == 14
        titles = [s.title for s in sections]
        assert "1. Model Details" in titles
        assert "9. Ethical Considerations & Fairness" in titles

    def test_ethical_with_fairlens(self, model_metadata, fairlens_report):
        template = ModelCardTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": fairlens_report,
        })
        ethical = next(s for s in sections if "Ethical" in s.title)
        assert "Disparate Impact" in ethical.content

    def test_metrics_table(self, model_metadata):
        template = ModelCardTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        metrics = next(s for s in sections if "Metrics" in s.title or "Performance" in s.title)
        assert "AUC" in metrics.content
        assert "0.847" in metrics.content


class TestECOATemplate:
    def test_render_with_fairlens(self, model_metadata, fairlens_report):
        template = ECOATemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": fairlens_report,
        })
        assert len(sections) == 15
        titles = [s.title for s in sections]
        assert "4. Protected Attribute Inventory" in titles
        assert "5. Disparate Impact Analysis" in titles
        assert "8. Less Discriminatory Alternatives (LDA)" in titles
        assert "Appendix B: Regulatory Cross-Reference" in titles

    def test_disparate_impact_content(self, model_metadata, fairlens_report):
        template = ECOATemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": fairlens_report,
        })
        di = next(s for s in sections if "Disparate Impact" in s.title)
        assert "race" in di.content
        assert "0.74" in di.content
        assert "FAIL" in di.content

    def test_lda_content(self, model_metadata, fairlens_report):
        template = ECOATemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": fairlens_report,
        })
        lda = next(s for s in sections if "Less Discriminatory" in s.title)
        assert "zip_code" in lda.content
        assert "PASS" in lda.content

    def test_adverse_action_content(self, model_metadata, fairlens_report):
        template = ECOATemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": fairlens_report,
        })
        aa = next(s for s in sections if "Adverse Action" in s.title)
        assert "F02" in aa.content

    def test_without_fairlens(self, model_metadata):
        template = ECOATemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        di = next(s for s in sections if "Disparate Impact" in s.title)
        assert "not available" in di.content.lower()


class TestDbtDocTemplate:
    def test_render(self, pipeline_metadata, dag_data):
        template = DbtDocTemplate()
        sections = template.render({
            "model": None, "pipeline": pipeline_metadata,
            "dag_nodes": dag_data["nodes"], "dag_edges": dag_data["edges"],
            "fairlens_report": None,
        })
        assert len(sections) == 6
        titles = [s.title for s in sections]
        assert "Sources" in titles
        assert "Models" in titles
        assert "Lineage" in titles

    def test_lineage_edges(self, pipeline_metadata, dag_data):
        template = DbtDocTemplate()
        sections = template.render({
            "model": None, "pipeline": pipeline_metadata,
            "dag_nodes": dag_data["nodes"], "dag_edges": dag_data["edges"],
            "fairlens_report": None,
        })
        lineage = next(s for s in sections if s.title == "Lineage")
        assert "n1" in lineage.content
        assert "→" in lineage.content


class TestGDPRTemplate:
    def test_render_produces_7_sections(self, model_metadata):
        template = GDPRTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        assert len(sections) == 7

    def test_section_titles(self, model_metadata):
        template = GDPRTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        titles = [s.title for s in sections]
        assert "Processing Activity Overview" in titles
        assert "Lawful Basis for Processing" in titles
        assert "Data Subject Rights" in titles
        assert "Data Protection Impact Assessment" in titles
        assert "Technical and Organizational Measures" in titles
        assert "International Data Transfers" in titles
        assert "Data Protection Officer" in titles

    def test_gdpr_article_references(self, model_metadata):
        template = GDPRTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        md = "\n".join(s.content for s in sections)
        assert "Article 6" in md
        assert "Article 13" in md or "Art 13" in md
        assert "Article 15" in md
        assert "Article 35" in md
        assert "Article 32" in md
        assert "Article 44" in md or "Articles 44-49" in md
        assert "Article 37" in md or "Articles 37-39" in md

    def test_with_model(self, model_metadata):
        template = GDPRTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        overview = sections[0]
        assert "credit_risk_v2" in overview.content

    def test_without_model(self):
        template = GDPRTemplate()
        sections = template.render({
            "model": None, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        assert len(sections) == 7
        overview = sections[0]
        assert "No model or pipeline metadata provided" in overview.content

    def test_with_fairlens(self, model_metadata, fairlens_report):
        template = GDPRTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": fairlens_report,
        })
        dpia = next(s for s in sections if s.title == "Data Protection Impact Assessment")
        assert "Critical findings: 2" in dpia.content

    def test_without_fairlens(self, model_metadata):
        template = GDPRTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        dpia = next(s for s in sections if s.title == "Data Protection Impact Assessment")
        assert "Fairness Analysis Results" not in dpia.content


class TestNISTAIRMFTemplate:
    def test_render_produces_7_sections(self, model_metadata):
        template = NISTAIRMFTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        assert len(sections) == 7

    def test_section_titles(self, model_metadata):
        template = NISTAIRMFTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        titles = [s.title for s in sections]
        assert "AI System Profile" in titles
        assert "Risk Identification (GOVERN)" in titles
        assert "Risk Assessment (MAP)" in titles
        assert "Risk Mitigation (MEASURE)" in titles
        assert "Risk Monitoring (MANAGE)" in titles
        assert "Stakeholder Engagement" in titles
        assert "Documentation and Reporting" in titles

    def test_nist_function_references(self, model_metadata):
        template = NISTAIRMFTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        md = "\n".join(s.content for s in sections)
        assert "NIST AI 100-1" in md
        assert "GOVERN 1" in md
        assert "GOVERN 6" in md
        assert "MAP 1" in md
        assert "MAP 5" in md
        assert "MEASURE 1" in md
        assert "MEASURE 4" in md
        assert "MANAGE 1" in md
        assert "MANAGE 4" in md

    def test_with_fairlens(self, model_metadata, fairlens_report):
        template = NISTAIRMFTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": fairlens_report,
        })
        measure = next(s for s in sections if s.title == "Risk Mitigation (MEASURE)")
        assert "Critical findings: 2" in measure.content

    def test_without_fairlens(self, model_metadata):
        template = NISTAIRMFTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        measure = next(s for s in sections if s.title == "Risk Mitigation (MEASURE)")
        assert "FairLens" not in measure.content

    def test_with_pipeline(self, pipeline_metadata):
        template = NISTAIRMFTemplate()
        sections = template.render({
            "model": None, "pipeline": pipeline_metadata,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        profile = sections[0]
        assert "daily_revenue_pipeline" in profile.content

    def test_performance_metrics_in_measure(self, model_metadata):
        template = NISTAIRMFTemplate()
        sections = template.render({
            "model": model_metadata, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        measure = next(s for s in sections if s.title == "Risk Mitigation (MEASURE)")
        assert "AUC" in measure.content
        assert "0.847" in measure.content


# ---------------------------------------------------------------------------
# Engine tests
# ---------------------------------------------------------------------------

class TestAutoDocEngine:
    def test_generate_sr117(self, model_metadata):
        engine = AutoDocEngine()
        report = engine.generate(
            template=TemplateType.SR_11_7,
            model_metadata=model_metadata,
        )
        assert report.title is not None
        assert "credit_risk_v2" in report.title
        assert len(report.sections) == 16
        md = report.to_markdown()
        assert "Executive Summary" in md

    def test_generate_all_templates(self, model_metadata, pipeline_metadata):
        engine = AutoDocEngine()
        for ttype in TemplateType:
            report = engine.generate(
                template=ttype,
                model_metadata=model_metadata,
                pipeline_metadata=pipeline_metadata,
            )
            assert report is not None
            assert len(report.sections) > 0
            assert report.to_markdown()
            assert report.to_json()

    def test_list_templates(self):
        engine = AutoDocEngine()
        templates = engine.list_templates()
        assert len(templates) == 7
        types = [t["type"] for t in templates]
        assert "sr11-7" in types
        assert "eu-ai-act" in types
        assert "gdpr" in types
        assert "nist-ai-rmf" in types

    def test_unknown_template(self):
        engine = AutoDocEngine()
        with pytest.raises(ValueError):
            engine.generate(template="nonexistent")

    def test_generate_with_dag(self, model_metadata, dag_data):
        engine = AutoDocEngine()
        report = engine.generate(
            template=TemplateType.SR_11_7,
            model_metadata=model_metadata,
            dag_nodes=dag_data["nodes"],
            dag_edges=dag_data["edges"],
        )
        md = report.to_markdown()
        assert "raw_orders" in md

    def test_generate_with_fairlens(self, model_metadata, fairlens_report):
        engine = AutoDocEngine()
        report = engine.generate(
            template=TemplateType.ECOA,
            model_metadata=model_metadata,
            fairlens_report=fairlens_report,
        )
        md = report.to_markdown()
        assert "zip_code" in md
        assert "0.74" in md

    def test_report_metadata(self, model_metadata):
        engine = AutoDocEngine()
        report = engine.generate(
            template=TemplateType.MODEL_CARD,
            model_metadata=model_metadata,
        )
        assert "Template" in report.metadata
        assert report.metadata["Model"] == "credit_risk_v2"


# ---------------------------------------------------------------------------
# End-to-end tests
# ---------------------------------------------------------------------------

class TestEndToEnd:
    def test_full_sr117_report(self, model_metadata, pipeline_metadata, dag_data, fairlens_report):
        engine = AutoDocEngine()
        report = engine.generate(
            template=TemplateType.SR_11_7,
            model_metadata=model_metadata,
            pipeline_metadata=pipeline_metadata,
            dag_nodes=dag_data["nodes"],
            dag_edges=dag_data["edges"],
            fairlens_report=fairlens_report,
        )

        md = report.to_markdown()
        assert "credit_risk_v2" in md
        assert "Executive Summary" in md
        assert "Data Assessment" in md
        assert "Model Description" in md
        assert "Performance Analysis" in md
        assert "Fair Lending Review" in md
        assert "Data Lineage" in md
        assert "Governance" in md

        assert "raw_orders" in md
        assert "XGBoost" in md
        assert "AUC" in md

    def test_ecoa_report_with_fairlens(self, model_metadata, fairlens_report):
        engine = AutoDocEngine()
        report = engine.generate(
            template=TemplateType.ECOA,
            model_metadata=model_metadata,
            fairlens_report=fairlens_report,
        )

        md = report.to_markdown()
        assert "race" in md
        assert "0.74" in md
        assert "FAIL" in md
        assert "zip_code" in md
        assert "PASS" in md
        assert "12 CFR 1002" in md
        assert "F02" in md

    def test_save_and_reload(self, model_metadata, tmp_path):
        engine = AutoDocEngine()
        report = engine.generate(
            template=TemplateType.MODEL_CARD,
            model_metadata=model_metadata,
        )

        json_path = tmp_path / "report.json"
        report.save(str(json_path))
        data = json.loads(json_path.read_text())
        assert data["title"] is not None
        assert len(data["sections"]) == 14

        md_path = tmp_path / "report.md"
        report.save(str(md_path))
        md_text = md_path.read_text()
        assert "# " in md_text
        assert "credit_risk_v2" in md_text


class TestAutoDocValidation:
    """Tests for input validation and error handling."""

    def test_invalid_template_type(self):
        """Passing invalid template type should raise ValueError."""
        engine = AutoDocEngine()
        with pytest.raises(ValueError, match="Unknown template"):
            engine.generate(template="definitely_not_a_template")

    def test_render_with_none_model(self):
        """Templates should handle None model gracefully."""
        template = SR117Template()
        sections = template.render({
            "model": None, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        assert len(sections) > 0

    def test_render_with_empty_context(self):
        """Templates should handle empty/minimal context."""
        template = ModelCardTemplate()
        sections = template.render({
            "model": None, "pipeline": None,
            "dag_nodes": [], "dag_edges": [],
            "fairlens_report": None,
        })
        assert len(sections) == 14

    def test_save_to_nonexistent_directory(self, tmp_path):
        """Saving to a nonexistent directory should raise FileNotFoundError."""
        report = DocumentReport(
            title="T", template_type=TemplateType.MODEL_CARD,
            sections=[DocumentSection(title="S", content="C")],
        )
        with pytest.raises(FileNotFoundError):
            report.save(str(tmp_path / "nonexistent_dir" / "report.md"))

    def test_all_templates_in_registry(self):
        """TEMPLATE_REGISTRY should have exactly 7 templates."""
        assert len(TEMPLATE_REGISTRY) == 7

    @pytest.mark.parametrize("template_type", list(TemplateType))
    def test_every_template_renders_without_crash(self, template_type, model_metadata):
        """Every template should render without error."""
        engine = AutoDocEngine()
        report = engine.generate(
            template=template_type,
            model_metadata=model_metadata,
        )
        assert report is not None
        assert len(report.sections) > 0
        assert report.to_markdown()

    def test_dag_nodes_must_be_list(self, model_metadata):
        """Passing non-list dag_nodes should raise TypeError."""
        engine = AutoDocEngine()
        with pytest.raises(TypeError, match="dag_nodes"):
            engine.generate(
                template=TemplateType.SR_11_7,
                model_metadata=model_metadata,
                dag_nodes="not_a_list",
            )
