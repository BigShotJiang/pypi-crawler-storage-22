"""
Comprehensive tests for docs module gap-filling work in Attestant.

Covers: PDF export, DOCX export, HTML export, save() dispatch,
GapAnalyzer/GapReport/Gap, and import accessibility.
"""

import json
import os
import re
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from attestant.docs import (
    AutoDocEngine,
    DocumentReport,
    DocumentSection,
    TemplateType,
    ModelMetadata,
    PipelineMetadata,
    GapAnalyzer,
    GapReport,
    Gap,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def model_metadata():
    return ModelMetadata(
        name="credit_risk_v2",
        version="2.1.0",
        model_type="XGBoost Classifier",
        framework="xgboost 1.7.6",
        description="Credit risk scoring model for consumer lending",
        intended_use="Predicting probability of default for loan applications",
        limitations="Not validated for commercial loans or amounts over $500K",
        training_date="2026-01-15",
        feature_count=47,
        training_rows=250000,
        hyperparameters={
            "max_depth": 6,
            "learning_rate": 0.1,
            "n_estimators": 500,
            "subsample": 0.8,
        },
        performance_metrics={
            "AUC": 0.847,
            "Accuracy": 0.812,
            "Precision": 0.795,
            "Recall": 0.723,
            "F1": 0.757,
        },
        fairness_metrics={
            "disparate_impact_race": 0.74,
            "disparate_impact_sex": 0.91,
        },
        feature_names=["credit_score", "dti", "income", "loan_amount", "employment_length"],
        feature_importances={"credit_score": 0.25, "dti": 0.18, "income": 0.15},
        owner="Model Risk Team",
        contact="modelrisk@company.com",
        tags=["credit", "lending", "consumer"],
    )


@pytest.fixture
def fairlens_report():
    return {
        "summary": {
            "critical": 2,
            "warnings": 1,
            "proxy_features_detected": 3,
            "lda_candidates_found": 2,
        },
        "findings": [
            {"severity": "critical", "description": "Disparate impact for race: ratio = 0.74"},
            {"severity": "critical", "description": "Proxy: zip_code correlates 0.83 with race"},
            {"severity": "warning", "description": "Adverse action insufficient for 23% of denials"},
        ],
        "disparate_impact": [
            {"protected_attribute": "race", "worst_ratio": 0.74, "has_disparate_impact": True},
            {"protected_attribute": "sex", "worst_ratio": 0.91, "has_disparate_impact": False},
        ],
        "proxy_detection": [
            {"feature_name": "zip_code", "protected_attribute": "race", "correlation": 0.83},
            {"feature_name": "census_tract", "protected_attribute": "race", "correlation": 0.77},
        ],
        "lda_candidates": [
            {"removed_features": ["zip_code"], "candidate_disparity": 0.81,
             "auc_loss_pct": 0.3, "passes_four_fifths": True},
        ],
        "adverse_action_samples": [
            {
                "prediction": 0,
                "reasons": [
                    {"code": "F02", "text": "Excessive obligations in relation to income"},
                    {"code": "B01", "text": "Proportion of balances to credit limits is too high"},
                ],
            },
        ],
    }


@pytest.fixture
def simple_report():
    """A minimal report for basic export testing."""
    return DocumentReport(
        title="Simple Test Report",
        template_type=TemplateType.MODEL_CARD,
        sections=[
            DocumentSection(title="Introduction", content="This is a simple test report."),
        ],
    )


@pytest.fixture
def rich_report():
    """A report with metadata, multiple sections, subsections, tables, and markdown."""
    return DocumentReport(
        title="Comprehensive Compliance Report",
        template_type=TemplateType.SR_11_7,
        sections=[
            DocumentSection(
                title="Executive Summary",
                content=(
                    "This report validates the **credit_risk_v2** model.\n\n"
                    "Key findings:\n"
                    "- AUC of 0.847 exceeds the benchmark\n"
                    "- Disparate impact ratio for race is *below* the 80% threshold\n"
                    "- `feature_importances` are well-distributed\n\n"
                    "| Metric | Value | Status |\n"
                    "|--------|-------|--------|\n"
                    "| AUC | 0.847 | PASS |\n"
                    "| DI Ratio | 0.74 | FAIL |\n"
                ),
                subsections=[
                    DocumentSection(
                        title="Risk Rating",
                        content="Overall rating: **Needs Improvement** due to fair lending concerns.",
                    ),
                ],
            ),
            DocumentSection(
                title="Model Description",
                content=(
                    "The model uses XGBoost with the following configuration:\n\n"
                    "1. Max depth: 6\n"
                    "2. Learning rate: 0.1\n"
                    "3. N estimators: 500\n"
                ),
            ),
            DocumentSection(
                title="Empty Section",
                content="",
            ),
        ],
        metadata={
            "Template": "sr11-7",
            "Model": "credit_risk_v2",
            "Version": "2.1.0",
            "Generated": "2026-02-09 12:00:00 UTC",
        },
    )


@pytest.fixture
def full_sr117_report(model_metadata, fairlens_report):
    """Generate a full SR 11-7 report via the engine for gap analysis testing."""
    engine = AutoDocEngine()
    return engine.generate(
        template=TemplateType.SR_11_7,
        model_metadata=model_metadata,
        fairlens_report=fairlens_report,
    )


@pytest.fixture
def full_ecoa_report(model_metadata, fairlens_report):
    """Generate a full ECOA report via the engine for gap analysis testing."""
    engine = AutoDocEngine()
    return engine.generate(
        template=TemplateType.ECOA,
        model_metadata=model_metadata,
        fairlens_report=fairlens_report,
    )


@pytest.fixture
def full_eu_ai_act_report(model_metadata, fairlens_report):
    """Generate a full EU AI Act report via the engine for gap analysis testing."""
    engine = AutoDocEngine()
    return engine.generate(
        template=TemplateType.EU_AI_ACT,
        model_metadata=model_metadata,
        fairlens_report=fairlens_report,
    )


@pytest.fixture
def empty_report():
    """A report with no sections for gap analysis (should score low)."""
    return DocumentReport(
        title="Empty Report",
        template_type=TemplateType.SR_11_7,
        sections=[],
    )


# ---------------------------------------------------------------------------
# 1. PDF Export Tests
# ---------------------------------------------------------------------------

class TestPDFExport:

    def test_basic_pdf_generation(self, simple_report, tmp_path):
        """Basic PDF generation: file exists and is non-empty."""
        try:
            from fpdf import FPDF  # noqa: F401
        except ImportError:
            pytest.skip("fpdf2 not installed")

        path = tmp_path / "basic.pdf"
        simple_report.save(str(path))
        assert path.exists()
        assert path.stat().st_size > 0

    def test_pdf_with_metadata(self, rich_report, simple_report, tmp_path):
        """PDF with metadata should be larger than one without."""
        try:
            from fpdf import FPDF  # noqa: F401
        except ImportError:
            pytest.skip("fpdf2 not installed")

        path_no_meta = tmp_path / "no_meta.pdf"
        simple_report.save(str(path_no_meta))

        path_with_meta = tmp_path / "with_meta.pdf"
        rich_report.save(str(path_with_meta))

        assert path_with_meta.stat().st_size > path_no_meta.stat().st_size

    def test_pdf_with_bold_italic_code(self, tmp_path):
        """PDF with bold, italic, and code markdown tokens."""
        try:
            from fpdf import FPDF  # noqa: F401
        except ImportError:
            pytest.skip("fpdf2 not installed")

        report = DocumentReport(
            title="Markdown Test",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(
                    title="Styles",
                    content="This has **bold**, *italic*, and `code` text.",
                ),
            ],
        )
        path = tmp_path / "styles.pdf"
        report.save(str(path))
        assert path.exists()
        assert path.stat().st_size > 0

    def test_pdf_with_bullet_and_numbered_lists(self, tmp_path):
        """PDF with bullet and numbered list markdown."""
        try:
            from fpdf import FPDF  # noqa: F401
        except ImportError:
            pytest.skip("fpdf2 not installed")

        report = DocumentReport(
            title="List Test",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(
                    title="Lists",
                    content=(
                        "Bullets:\n"
                        "- First bullet\n"
                        "- Second bullet\n"
                        "  - Nested bullet\n\n"
                        "Numbered:\n"
                        "1. First item\n"
                        "2. Second item\n"
                        "3. Third item\n"
                    ),
                ),
            ],
        )
        path = tmp_path / "lists.pdf"
        report.save(str(path))
        assert path.exists()
        assert path.stat().st_size > 0

    def test_pdf_with_tables(self, tmp_path):
        """PDF with a markdown table in section content."""
        try:
            from fpdf import FPDF  # noqa: F401
        except ImportError:
            pytest.skip("fpdf2 not installed")

        report = DocumentReport(
            title="Table Test",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(
                    title="Metrics",
                    content=(
                        "| Metric | Value |\n"
                        "|--------|-------|\n"
                        "| AUC | 0.847 |\n"
                        "| Precision | 0.795 |\n"
                    ),
                ),
            ],
        )
        path = tmp_path / "table.pdf"
        report.save(str(path))
        assert path.exists()
        assert path.stat().st_size > 0

    def test_pdf_with_subsections(self, tmp_path):
        """PDF with subsections renders without error."""
        try:
            from fpdf import FPDF  # noqa: F401
        except ImportError:
            pytest.skip("fpdf2 not installed")

        report = DocumentReport(
            title="Subsection Test",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(
                    title="Parent",
                    content="Parent content",
                    subsections=[
                        DocumentSection(title="Child A", content="Child A content"),
                        DocumentSection(title="Child B", content="Child B content"),
                    ],
                ),
            ],
        )
        path = tmp_path / "subsections.pdf"
        report.save(str(path))
        assert path.exists()
        assert path.stat().st_size > 0

    def test_pdf_with_empty_sections(self, tmp_path):
        """PDF with empty section content does not crash."""
        try:
            from fpdf import FPDF  # noqa: F401
        except ImportError:
            pytest.skip("fpdf2 not installed")

        report = DocumentReport(
            title="Empty Content",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(title="Empty", content=""),
            ],
        )
        path = tmp_path / "empty.pdf"
        report.save(str(path))
        assert path.exists()

    def test_pdf_import_error_when_fpdf2_missing(self, simple_report, tmp_path):
        """_save_pdf raises ImportError when fpdf2 is not installed."""
        path = tmp_path / "fail.pdf"
        with patch.dict("sys.modules", {"fpdf": None}):
            with pytest.raises(ImportError, match="fpdf2"):
                simple_report._save_pdf(Path(path))

    def test_pdf_save_to_nonexistent_directory(self, simple_report, tmp_path):
        """Saving PDF to a nonexistent directory raises FileNotFoundError."""
        bad_path = tmp_path / "nonexistent_dir" / "report.pdf"
        with pytest.raises(FileNotFoundError):
            simple_report.save(str(bad_path))

    def test_pdf_full_report(self, full_sr117_report, tmp_path):
        """A full engine-generated SR 11-7 report exports to PDF without error."""
        try:
            from fpdf import FPDF  # noqa: F401
        except ImportError:
            pytest.skip("fpdf2 not installed")

        path = tmp_path / "full_sr117.pdf"
        full_sr117_report.save(str(path))
        assert path.exists()
        assert path.stat().st_size > 1000


# ---------------------------------------------------------------------------
# 2. DOCX Export Tests
# ---------------------------------------------------------------------------

class TestDOCXExport:

    def test_basic_docx_generation(self, simple_report, tmp_path):
        """Basic DOCX generation: file exists and is non-empty."""
        try:
            from docx import Document  # noqa: F401
        except ImportError:
            pytest.skip("python-docx not installed")

        path = tmp_path / "basic.docx"
        simple_report.save(str(path))
        assert path.exists()
        assert path.stat().st_size > 0

    def test_docx_with_metadata(self, rich_report, tmp_path):
        """DOCX with metadata renders without error and is non-trivial."""
        try:
            from docx import Document
        except ImportError:
            pytest.skip("python-docx not installed")

        path = tmp_path / "with_meta.docx"
        rich_report.save(str(path))
        assert path.exists()
        assert path.stat().st_size > 1000

        doc = Document(str(path))
        full_text = "\n".join(p.text for p in doc.paragraphs)
        assert "credit_risk_v2" in full_text

    def test_docx_with_markdown_content(self, tmp_path):
        """DOCX with bold/italic/code markdown in content."""
        try:
            from docx import Document
        except ImportError:
            pytest.skip("python-docx not installed")

        report = DocumentReport(
            title="Markdown DOCX",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(
                    title="Styles",
                    content="Text with **bold**, *italic*, and `code` spans.",
                ),
            ],
        )
        path = tmp_path / "markdown.docx"
        report.save(str(path))
        assert path.exists()

        doc = Document(str(path))
        found_bold = False
        found_code = False
        for p in doc.paragraphs:
            for run in p.runs:
                if run.bold:
                    found_bold = True
                if run.font.name == "Courier New":
                    found_code = True
        assert found_bold, "Expected at least one bold run in DOCX"
        assert found_code, "Expected at least one code run in DOCX"

    def test_docx_with_tables(self, tmp_path):
        """DOCX with a markdown table in section content creates a Word table."""
        try:
            from docx import Document
        except ImportError:
            pytest.skip("python-docx not installed")

        report = DocumentReport(
            title="Table DOCX",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(
                    title="Metrics",
                    content=(
                        "| Metric | Value |\n"
                        "|--------|-------|\n"
                        "| AUC | 0.847 |\n"
                    ),
                ),
            ],
        )
        path = tmp_path / "table.docx"
        report.save(str(path))

        doc = Document(str(path))
        assert len(doc.tables) >= 1
        header_cells = [c.text for c in doc.tables[0].rows[0].cells]
        assert "Metric" in header_cells
        assert "Value" in header_cells

    def test_docx_with_subsections(self, tmp_path):
        """DOCX with subsections renders without error."""
        try:
            from docx import Document  # noqa: F401
        except ImportError:
            pytest.skip("python-docx not installed")

        report = DocumentReport(
            title="Subsection DOCX",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(
                    title="Parent",
                    content="Parent content.",
                    subsections=[
                        DocumentSection(title="Child A", content="Child A detail."),
                    ],
                ),
            ],
        )
        path = tmp_path / "subsections.docx"
        report.save(str(path))
        assert path.exists()
        assert path.stat().st_size > 0

    def test_docx_with_bullet_and_numbered_lists(self, tmp_path):
        """DOCX with bullet and numbered list content."""
        try:
            from docx import Document
        except ImportError:
            pytest.skip("python-docx not installed")

        report = DocumentReport(
            title="Lists DOCX",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(
                    title="Lists",
                    content=(
                        "- First bullet\n"
                        "- Second bullet\n\n"
                        "1. First numbered\n"
                        "2. Second numbered\n"
                    ),
                ),
            ],
        )
        path = tmp_path / "lists.docx"
        report.save(str(path))
        assert path.exists()

        doc = Document(str(path))
        styles_used = {p.style.name for p in doc.paragraphs if p.text.strip()}
        assert "List Bullet" in styles_used or any("bullet" in s.lower() for s in styles_used)

    def test_docx_import_error_when_python_docx_missing(self, simple_report, tmp_path):
        """_save_docx raises ImportError when python-docx is not installed."""
        path = tmp_path / "fail.docx"
        with patch.dict("sys.modules", {"docx": None, "docx.shared": None,
                                         "docx.enum": None, "docx.enum.text": None,
                                         "docx.enum.style": None}):
            with pytest.raises(ImportError, match="python-docx"):
                simple_report._save_docx(Path(path))

    def test_docx_save_to_nonexistent_directory(self, simple_report, tmp_path):
        """Saving DOCX to a nonexistent directory raises FileNotFoundError."""
        bad_path = tmp_path / "nonexistent_dir" / "report.docx"
        with pytest.raises(FileNotFoundError):
            simple_report.save(str(bad_path))

    def test_docx_confidential_watermark(self, rich_report, tmp_path):
        """DOCX includes CONFIDENTIAL text."""
        try:
            from docx import Document
        except ImportError:
            pytest.skip("python-docx not installed")

        path = tmp_path / "confidential.docx"
        rich_report.save(str(path))
        doc = Document(str(path))
        full_text = "\n".join(p.text for p in doc.paragraphs)
        assert "CONFIDENTIAL" in full_text

    def test_docx_full_report(self, full_sr117_report, tmp_path):
        """A full engine-generated SR 11-7 report exports to DOCX without error."""
        try:
            from docx import Document  # noqa: F401
        except ImportError:
            pytest.skip("python-docx not installed")

        path = tmp_path / "full_sr117.docx"
        full_sr117_report.save(str(path))
        assert path.exists()
        assert path.stat().st_size > 1000


# ---------------------------------------------------------------------------
# 3. HTML Export Tests
# ---------------------------------------------------------------------------

class TestHTMLExport:

    def test_basic_html_generation(self, simple_report, tmp_path):
        """Basic HTML generation contains DOCTYPE and title."""
        path = tmp_path / "basic.html"
        simple_report.save(str(path))
        html = path.read_text(encoding="utf-8")
        assert "<!DOCTYPE html>" in html
        assert "<title>" in html
        assert "Simple Test Report" in html

    def test_html_with_metadata(self, rich_report, tmp_path):
        """HTML with metadata includes the meta div."""
        path = tmp_path / "with_meta.html"
        rich_report.save(str(path))
        html = path.read_text(encoding="utf-8")
        assert 'class="meta"' in html
        assert "credit_risk_v2" in html
        assert "2.1.0" in html

    def test_html_with_sections(self, rich_report, tmp_path):
        """HTML with sections includes h2 tags."""
        path = tmp_path / "sections.html"
        rich_report.save(str(path))
        html = path.read_text(encoding="utf-8")
        assert "<h2>" in html
        assert "Executive Summary" in html
        assert "Model Description" in html

    def test_html_with_tables(self, tmp_path):
        """HTML with table content includes table/th/td tags."""
        report = DocumentReport(
            title="Table HTML",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(
                    title="Metrics",
                    content=(
                        "| Metric | Value |\n"
                        "|--------|-------|\n"
                        "| AUC | 0.847 |\n"
                    ),
                ),
            ],
        )
        path = tmp_path / "table.html"
        report.save(str(path))
        html = path.read_text(encoding="utf-8")
        assert "<table>" in html
        assert "<th>" in html
        assert "<td>" in html

    def test_html_with_bullets(self, tmp_path):
        """HTML with bullet content includes ul/li tags."""
        report = DocumentReport(
            title="Bullet HTML",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(
                    title="Items",
                    content="- First item\n- Second item\n- Third item\n",
                ),
            ],
        )
        path = tmp_path / "bullets.html"
        report.save(str(path))
        html = path.read_text(encoding="utf-8")
        assert "<ul>" in html
        assert "<li>" in html

    def test_html_escapes_special_characters(self, tmp_path):
        """HTML escapes special characters to prevent XSS."""
        report = DocumentReport(
            title="XSS Test <script>alert('hack')</script>",
            template_type=TemplateType.MODEL_CARD,
            sections=[
                DocumentSection(
                    title="Injection <img onerror=alert(1)>",
                    content="Content with <b>raw HTML</b> & special \"chars\"",
                ),
            ],
        )
        path = tmp_path / "escape.html"
        report.save(str(path))
        html = path.read_text(encoding="utf-8")
        assert "<script>" not in html
        assert "&lt;script&gt;" in html
        assert "<img onerror" not in html
        assert "&amp;" in html

    def test_html_has_dark_mode_css(self, simple_report, tmp_path):
        """HTML includes prefers-color-scheme dark mode CSS media query."""
        path = tmp_path / "dark.html"
        simple_report.save(str(path))
        html = path.read_text(encoding="utf-8")
        assert "prefers-color-scheme: dark" in html

    def test_html_has_print_styles(self, simple_report, tmp_path):
        """HTML includes print media query for clean printing."""
        path = tmp_path / "print.html"
        simple_report.save(str(path))
        html = path.read_text(encoding="utf-8")
        assert "@media print" in html


# ---------------------------------------------------------------------------
# 4. save() Dispatch Tests
# ---------------------------------------------------------------------------

class TestSaveDispatch:

    def test_pdf_extension_calls_save_pdf(self, simple_report, tmp_path):
        """The .pdf extension dispatches to _save_pdf."""
        path = tmp_path / "dispatch.pdf"
        with patch.object(DocumentReport, "_save_pdf") as mock_pdf:
            simple_report.save(str(path))
            mock_pdf.assert_called_once()

    def test_docx_extension_calls_save_docx(self, simple_report, tmp_path):
        """The .docx extension dispatches to _save_docx."""
        path = tmp_path / "dispatch.docx"
        with patch.object(DocumentReport, "_save_docx") as mock_docx:
            simple_report.save(str(path))
            mock_docx.assert_called_once()

    def test_html_extension_calls_save_html(self, simple_report, tmp_path):
        """The .html extension dispatches to _save_html."""
        path = tmp_path / "dispatch.html"
        with patch.object(DocumentReport, "_save_html") as mock_html:
            simple_report.save(str(path))
            mock_html.assert_called_once()

    def test_json_extension_writes_json(self, simple_report, tmp_path):
        """The .json extension writes valid JSON."""
        path = tmp_path / "dispatch.json"
        simple_report.save(str(path))
        data = json.loads(path.read_text())
        assert data["title"] == "Simple Test Report"
        assert "sections" in data

    def test_md_extension_writes_markdown(self, simple_report, tmp_path):
        """The .md extension writes markdown output."""
        path = tmp_path / "dispatch.md"
        simple_report.save(str(path))
        md = path.read_text()
        assert "# Simple Test Report" in md

    def test_unknown_extension_defaults_to_markdown(self, simple_report, tmp_path):
        """An unknown extension defaults to markdown output."""
        path = tmp_path / "dispatch.txt"
        simple_report.save(str(path))
        txt = path.read_text()
        assert "# Simple Test Report" in txt


# ---------------------------------------------------------------------------
# 5. Gap Analysis Tests
# ---------------------------------------------------------------------------

class TestGapAnalyzer:

    def test_sr117_complete_report_high_score(self, full_sr117_report):
        """A full SR 11-7 report should have a high gap analysis score."""
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(full_sr117_report, "sr11-7")
        assert gap_report.score >= 0.7
        assert gap_report.total_requirements == 14
        assert gap_report.met_requirements >= 10

    def test_sr117_empty_report_low_score(self, empty_report):
        """An empty report should score 0.0 with many gaps."""
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(empty_report, "sr11-7")
        assert gap_report.score == 0.0
        assert gap_report.met_requirements == 0
        assert len(gap_report.gaps) == 14
        assert gap_report.status == "incomplete"

    def test_sr117_missing_sections_identified(self, empty_report):
        """An empty report finds specific missing sections like Executive Summary."""
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(empty_report, "sr11-7")
        gap_names = [g.requirement for g in gap_report.gaps]
        assert "Executive Summary" in gap_names
        assert "Model Description" in gap_names
        assert "Performance Analysis" in gap_names
        assert "Monitoring Plan" in gap_names
        assert "Governance" in gap_names

    def test_ecoa_complete_report(self, full_ecoa_report):
        """A full ECOA report should have a high gap analysis score."""
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(full_ecoa_report, "ecoa")
        assert gap_report.score >= 0.7
        assert gap_report.total_requirements == 8
        assert gap_report.met_requirements >= 6

    def test_ecoa_missing_di_ratios(self):
        """An ECOA report without DI ratio data should flag the gap."""
        report = DocumentReport(
            title="ECOA Without DI",
            template_type=TemplateType.ECOA,
            sections=[
                DocumentSection(title="Protected Attribute Inventory", content="Race, sex, age tracked."),
                DocumentSection(title="Disparate Impact Analysis", content="No analysis data available."),
                DocumentSection(title="Proxy Detection Results", content="No proxies found."),
                DocumentSection(title="Adverse Action Methodology", content="CFPB compliant reason codes."),
            ],
        )
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(report, "ecoa")
        gap_names = [g.requirement for g in gap_report.gaps]
        assert "DI Ratios for Protected Attribute" in gap_names

    def test_eu_ai_act_complete_report(self, full_eu_ai_act_report):
        """A full EU AI Act report should have a reasonable gap analysis score."""
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(full_eu_ai_act_report, "eu-ai-act")
        assert gap_report.total_requirements == 11
        assert gap_report.score >= 0.5

    def test_unknown_template_returns_perfect_score(self):
        """An unknown template type returns score 1.0 with no gaps."""
        report = DocumentReport(
            title="Custom",
            template_type=TemplateType.MODEL_CARD,
            sections=[DocumentSection(title="S", content="C")],
        )
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(report, "nonexistent-template")
        assert gap_report.score == 1.0
        assert len(gap_report.gaps) == 0
        assert gap_report.status == "complete"

    def test_gap_severity_classification(self, empty_report):
        """Gaps from an empty SR 11-7 report have critical, major, and minor severities."""
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(empty_report, "sr11-7")
        severities = {g.severity for g in gap_report.gaps}
        assert "critical" in severities
        assert "major" in severities
        assert "minor" in severities

    def test_gap_report_to_section_content_renders_table(self, empty_report):
        """GapReport.to_section_content() renders a markdown table."""
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(empty_report, "sr11-7")
        content = gap_report.to_section_content()
        assert "| # | Requirement | Severity | Description | Remediation |" in content
        assert "|---|" in content
        assert "Gap Analysis Score:" in content
        assert "Gap Summary:" in content

    def test_gap_report_to_section_content_no_gaps(self):
        """GapReport with no gaps renders a clean message."""
        gap_report = GapReport(
            template_type="test",
            total_requirements=5,
            met_requirements=5,
            gaps=[],
            score=1.0,
            status="complete",
        )
        content = gap_report.to_section_content()
        assert "All regulatory requirements have been addressed" in content
        assert "|" not in content

    def test_gap_report_status_complete(self, full_sr117_report):
        """A high-scoring report with no critical gaps should have status 'complete' or 'minor_gaps'."""
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(full_sr117_report, "sr11-7")
        assert gap_report.status in ("complete", "minor_gaps")

    def test_gap_report_status_incomplete(self, empty_report):
        """An empty report should have status 'incomplete'."""
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(empty_report, "sr11-7")
        assert gap_report.status == "incomplete"

    def test_gap_report_status_major_gaps(self):
        """A report with 1-2 critical gaps and some met requirements gets 'major_gaps'."""
        report = DocumentReport(
            title="Partial",
            template_type=TemplateType.SR_11_7,
            sections=[
                DocumentSection(title="Executive Summary", content="Overview with AUC 0.85 and risk rating Satisfactory."),
                DocumentSection(title="Model Description", content="XGBoost classifier."),
                DocumentSection(title="Conceptual Soundness", content="Methodology is sound."),
                DocumentSection(title="Data Assessment", content="Data quality is good."),
                DocumentSection(title="Performance Analysis", content="AUC = 0.85, KS = 0.6, Gini = 0.7. SR 11-7 OCC 2011-12."),
                DocumentSection(title="Outcomes Analysis", content="Backtesting shows stability. Limitations include population drift."),
                DocumentSection(title="Governance and Controls", content="Three lines of defense. Monitoring thresholds defined. Finding F-001."),
            ],
        )
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(report, "sr11-7")
        assert gap_report.status in ("minor_gaps", "major_gaps", "complete")
        assert gap_report.met_requirements >= 7

    def test_gap_analysis_via_engine_convenience(self, full_sr117_report):
        """AutoDocEngine.gap_analysis() convenience method returns a GapReport."""
        engine = AutoDocEngine()
        gap_report = engine.gap_analysis(full_sr117_report)
        assert isinstance(gap_report, GapReport)
        assert gap_report.template_type == "sr11-7"
        assert gap_report.total_requirements == 14

    def test_gap_dataclass_has_all_fields(self):
        """Gap dataclass has requirement, severity, description, and remediation fields."""
        gap = Gap(
            requirement="Test Requirement",
            severity="critical",
            description="This is a test gap.",
            remediation="Fix the gap by doing something.",
        )
        assert gap.requirement == "Test Requirement"
        assert gap.severity == "critical"
        assert gap.description == "This is a test gap."
        assert gap.remediation == "Fix the gap by doing something."

    def test_gap_report_section_content_severity_counts(self, empty_report):
        """GapReport.to_section_content() includes severity breakdown counts."""
        analyzer = GapAnalyzer()
        gap_report = analyzer.analyze(empty_report, "sr11-7")
        content = gap_report.to_section_content()
        assert "Critical:" in content
        assert "Major:" in content
        assert "Minor:" in content


# ---------------------------------------------------------------------------
# 6. Import Tests
# ---------------------------------------------------------------------------

class TestImports:

    def test_import_from_proveit_docs(self):
        """GapAnalyzer, GapReport, Gap importable from attestant.docs."""
        from attestant.docs import GapAnalyzer as GA, GapReport as GR, Gap as G
        assert GA is not None
        assert GR is not None
        assert G is not None

    def test_import_from_proveit_docs_gap_analysis_module(self):
        """GapAnalyzer importable from attestant.docs.gap_analysis."""
        from attestant.docs.gap_analysis import GapAnalyzer
        assert GapAnalyzer is not None

    def test_gap_analyzer_accessible_via_engine(self):
        """AutoDocEngine.gap_analysis() is a method that calls GapAnalyzer."""
        engine = AutoDocEngine()
        assert hasattr(engine, "gap_analysis")
        assert callable(engine.gap_analysis)
