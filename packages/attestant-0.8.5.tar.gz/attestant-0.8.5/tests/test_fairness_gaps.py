"""
Tests for the two fairness module gaps:

1. Real proxy causal chain detection (data-driven, not hardcoded)
2. Fairness drift monitoring (DI ratio tracking over time)

Uses synthetic data with known causal structures to validate
statistical analysis, multi-hop path discovery, drift detection,
and alert generation.
"""

import time
import numpy as np
import pandas as pd
import pytest

from attestant.fairness.proxy_detection import (
    ProxyDetector,
    ProxyResult,
    CausalChainLink,
    KNOWN_PROXY_PATTERNS,
)
from attestant.fairness.engine import FairLensEngine, FairLensConfig


# =========================================================================
# Synthetic Data Helpers
# =========================================================================

def _make_zip_race_data(n=1000, seed=42):
    """Create dataset where zip_code strongly correlates with race (>0.7).

    Five zip codes, each dominated by a particular race with 80%
    probability.
    """
    rng = np.random.RandomState(seed)

    race = rng.choice(["white", "black", "hispanic", "asian", "other"], n, p=[0.4, 0.25, 0.2, 0.1, 0.05])
    zip_code = np.empty(n, dtype=object)

    zip_race_map = {
        "white": "10001",
        "black": "10002",
        "hispanic": "10003",
        "asian": "10004",
        "other": "10005",
    }
    for i in range(n):
        if rng.random() < 0.80:
            zip_code[i] = zip_race_map[race[i]]
        else:
            zip_code[i] = rng.choice(["10001", "10002", "10003", "10004", "10005"])

    income = rng.normal(60000, 15000, n)
    income[race == "black"] -= 8000
    income[race == "hispanic"] -= 5000
    income = np.clip(income, 15000, 200000)

    credit_score = rng.normal(700, 80, n)
    dti = rng.uniform(0.1, 0.6, n)

    features = pd.DataFrame({
        "zip_code": zip_code,
        "income": income,
        "credit_score": credit_score,
        "dti": dti,
    })
    protected = pd.DataFrame({"race": race})
    return features, protected


def _make_age_gradyear_data(n=1000, seed=42):
    """Create dataset where graduation_year correlates strongly with age.

    grad_year = (current_year - age + 22) + noise
    """
    rng = np.random.RandomState(seed)

    age = rng.randint(22, 65, n).astype(float)
    grad_year = (2026 - age + 22 + rng.normal(0, 1, n)).astype(int)
    grad_year = np.clip(grad_year, 1980, 2026)

    experience = rng.randint(0, 30, n).astype(float)
    salary = rng.normal(70000, 20000, n)

    features = pd.DataFrame({
        "graduation_year": grad_year.astype(float),
        "experience": experience,
        "salary": salary,
    })
    protected = pd.DataFrame({"age": age})
    return features, protected


def _make_multihop_data(n=2000, seed=42):
    """Create dataset where A -> B -> C (multi-hop causal chain).

    - feature_a: correlated with feature_b (0.7+)
    - feature_b: correlated with protected_attr (0.6+)
    - feature_a and protected_attr have indirect correlation via feature_b
    """
    rng = np.random.RandomState(seed)

    protected_numeric = rng.choice([0, 1], n, p=[0.5, 0.5]).astype(float)

    feature_b = protected_numeric * 2.0 + rng.normal(0, 1, n)

    feature_a = feature_b * 1.5 + rng.normal(0, 0.8, n)

    noise_c = rng.normal(0, 5, n)

    features = pd.DataFrame({
        "feature_a": feature_a,
        "feature_b": feature_b,
        "noise_c": noise_c,
    })
    protected = pd.DataFrame({"group": protected_numeric})
    return features, protected


# =========================================================================
# Tests: Proxy Causal Chain Detection (Gap 1)
# =========================================================================

class TestCausalChainDataDriven:
    """Tests that _build_causal_chain now uses real data-driven analysis."""

    def test_chain_has_measured_correlation(self):
        """Causal chain should report an actual measured correlation, not just
        repeat the input value without analysis."""
        features, protected = _make_zip_race_data()
        detector = ProxyDetector(correlation_threshold=0.3)
        results = detector.detect(features, protected, ["race"])

        zip_results = [r for r in results if r.feature_name == "zip_code"]
        assert len(zip_results) >= 1

        chain = zip_results[0].causal_chain
        assert len(chain) >= 1
        assert chain[0].correlation > 0

    def test_chain_includes_partial_correlation_info(self):
        """When multiple features exist, the chain mechanism should mention
        partial correlation analysis."""
        features, protected = _make_zip_race_data()
        detector = ProxyDetector(correlation_threshold=0.3)
        results = detector.detect(features, protected, ["race"])

        zip_results = [r for r in results if r.feature_name == "zip_code"]
        assert len(zip_results) >= 1

        mechanism = zip_results[0].causal_chain[0].mechanism.lower()
        assert "partial correlation" in mechanism or "correlation" in mechanism

    def test_zip_code_detected_as_known_geographic_proxy(self):
        """zip_code should be flagged as a known geographic proxy with
        measured statistical evidence."""
        features, protected = _make_zip_race_data()
        detector = ProxyDetector(correlation_threshold=0.3)
        results = detector.detect(features, protected, ["race"])

        zip_results = [r for r in results if r.feature_name == "zip_code"]
        assert len(zip_results) >= 1

        result = zip_results[0]
        assert result.known_proxy is True
        assert result.correlation > 0.3

        mechanism = result.causal_chain[0].mechanism.lower()
        assert "geographic" in mechanism or "segregation" in mechanism

    def test_graduation_year_correlates_with_age(self):
        """graduation_year should be detected as correlating with age."""
        features, protected = _make_age_gradyear_data()
        detector = ProxyDetector(correlation_threshold=0.3)
        results = detector.detect(features, protected, ["age"])

        grad_results = [r for r in results if r.feature_name == "graduation_year"]
        assert len(grad_results) >= 1

        result = grad_results[0]
        assert result.correlation > 0.5
        assert result.known_proxy is True

        mechanism = result.causal_chain[0].mechanism.lower()
        assert "correlation" in mechanism

    def test_multihop_path_discovery(self):
        """Multi-hop detection should find paths A -> B -> C."""
        features, protected = _make_multihop_data()
        detector = ProxyDetector(correlation_threshold=0.2)
        results = detector.detect(features, protected, ["group"])

        feature_a_results = [r for r in results if r.feature_name == "feature_a"]
        assert len(feature_a_results) >= 1

        chain = feature_a_results[0].causal_chain
        assert len(chain) >= 1

        all_mechanisms = " ".join(c.mechanism.lower() for c in chain)
        has_path_info = (
            "multi-hop" in all_mechanisms
            or "feature_b" in all_mechanisms
            or len(chain) > 1
        )

        assert feature_a_results[0].correlation > 0.2
        if len(chain) > 1:
            assert has_path_info

    def test_noise_feature_not_detected(self):
        """Random noise feature should not appear in results."""
        features, protected = _make_multihop_data()
        detector = ProxyDetector(correlation_threshold=0.3)
        results = detector.detect(features, protected, ["group"])

        noise_results = [r for r in results if r.feature_name == "noise_c"]
        assert len(noise_results) == 0

    def test_chain_without_data_still_works(self):
        """Calling _build_causal_chain without data kwargs should still
        return a valid chain (backward compatibility)."""
        detector = ProxyDetector()
        chain = detector._build_causal_chain("zip_code", "race", 0.85, True)
        assert len(chain) >= 1
        assert chain[0].correlation == 0.85
        assert "geographic" in chain[0].mechanism.lower() or "segregation" in chain[0].mechanism.lower()

    def test_chain_without_data_unknown_proxy(self):
        """Calling _build_causal_chain for unknown proxy without data should
        produce a simple statistical correlation message."""
        detector = ProxyDetector()
        chain = detector._build_causal_chain("random_feature", "group", 0.55, False)
        assert len(chain) == 1
        assert chain[0].correlation == 0.55
        assert "0.55" in chain[0].mechanism

    def test_chi_squared_for_categorical_pairs(self):
        """Chi-squared test should run for categorical feature pairs."""
        features, protected = _make_zip_race_data()
        detector = ProxyDetector(correlation_threshold=0.3)
        results = detector.detect(features, protected, ["race"])

        zip_results = [r for r in results if r.feature_name == "zip_code"]
        assert len(zip_results) >= 1
        mechanism = zip_results[0].causal_chain[0].mechanism.lower()
        assert "chi-squared" in mechanism or "correlation" in mechanism

    def test_partial_correlation_method(self):
        """Test _compute_partial_correlation directly."""
        rng = np.random.RandomState(42)
        n = 500
        x = rng.normal(0, 1, n)
        confound = rng.normal(0, 1, n)
        y = x * 0.5 + confound * 0.8 + rng.normal(0, 0.5, n)

        df = pd.DataFrame({"x": x, "y": y, "confound": confound})
        corr_matrix = df.corr()

        partial, method = ProxyDetector._compute_partial_correlation(
            "x", "y", ["confound"], corr_matrix,
        )
        assert method == "partial_correlation"
        assert 0.0 < partial < 1.0

        raw_corr = abs(corr_matrix.loc["x", "y"])
        assert abs(partial - raw_corr) < raw_corr

    def test_encode_for_correlation_mixed_types(self):
        """Encoding should handle numeric and categorical columns."""
        df = pd.DataFrame({
            "num": [1.0, 2.0, 3.0, 4.0],
            "cat": ["a", "b", "a", "b"],
        })
        encoded = ProxyDetector._encode_for_correlation(df, ["num", "cat"])
        assert "num" in encoded.columns
        assert "cat" in encoded.columns
        assert pd.api.types.is_numeric_dtype(encoded["num"])
        assert pd.api.types.is_numeric_dtype(encoded["cat"])

    def test_multihop_bfs_finds_path(self):
        """Test _find_multihop_paths directly on a known correlation matrix."""
        corr_data = pd.DataFrame(
            [[1.0, 0.8, 0.1],
             [0.8, 1.0, 0.7],
             [0.1, 0.7, 1.0]],
            index=["A", "B", "C"],
            columns=["A", "B", "C"],
        )
        detector = ProxyDetector()
        paths = detector._find_multihop_paths("A", "C", corr_data, max_hops=3, edge_threshold=0.3)
        assert len(paths) >= 1
        best = paths[0]
        nodes_in_path = [best[0][0]] + [edge[1] for edge in best]
        assert "A" in nodes_in_path
        assert "C" in nodes_in_path
        assert "B" in nodes_in_path

    def test_result_to_dict_includes_chain(self):
        """ProxyResult.to_dict() should include the causal chain."""
        features, protected = _make_zip_race_data()
        detector = ProxyDetector(correlation_threshold=0.3)
        results = detector.detect(features, protected, ["race"])

        if results:
            d = results[0].to_dict()
            assert "causal_chain" in d
            assert len(d["causal_chain"]) >= 1
            first_link = d["causal_chain"][0]
            assert "correlation" in first_link
            assert "mechanism" in first_link
