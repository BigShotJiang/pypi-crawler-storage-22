"""
Unit tests for HYDRA-24 Enhanced provenance system with entity and chain tracking.
"""

import pytest
import numpy as np
import pandas as pd

from attestant.hydra24_simple import (
    ProvenanceTracker, TrackedSeries, TrackedDataFrame,
    wrap_dataframe, audit, audit_series_diversity,
    OpCode, ProvenanceInfo, DenseEntry,
    MAX_PAIRS, MODE_01, MODE_2, MODE_DENSE,
    MODE_01_ENTITY_BITS, MODE_01_CHAIN_BITS,
    MODE_2_ENTITY_BITS, MODE_2_CHAIN_BITS,
    _binomial, _encode_pair_01, _decode_pair_01,
    _encode_pair_2, _decode_pair_2,
    _combine_chains, _update_chain, _hash_entity,
)


class TestBinomial:
    """Tests for binomial coefficient."""

    def test_basic(self):
        assert _binomial(5, 0) == 1
        assert _binomial(5, 1) == 5
        assert _binomial(5, 2) == 10
        assert _binomial(5, 3) == 10
        assert _binomial(5, 5) == 1

    def test_large(self):
        assert _binomial(512, 2) == 130816
        assert _binomial(512, 3) == 22238720


class TestMode00Encoding:
    """Tests for Mode 00 (0-1 pairs) encoding."""

    def test_empty_pairs(self):
        tracker = ProvenanceTracker()
        prov = tracker.encode(set(), entity=42, chain=7)

        pairs, entity, chain = tracker.decode_full(prov)
        assert pairs == set()
        assert entity == 42
        assert chain == 7

    def test_single_pair(self):
        tracker = ProvenanceTracker()
        tracker.register("test", "col1")

        prov = tracker.encode({0}, entity=10, chain=20)

        pairs, entity, chain = tracker.decode_full(prov)
        assert pairs == {0}
        assert entity == 10
        assert chain == 20

    def test_entity_chain_truncation(self):
        tracker = ProvenanceTracker()
        tracker.register("test", "col1")

        # Entity and chain should be truncated to 6 bits (0-63)
        prov = tracker.encode({0}, entity=100, chain=200)

        pairs, entity, chain = tracker.decode_full(prov)
        assert pairs == {0}
        assert entity == 100 % 64  # 36
        assert chain == 200 % 64   # 8

    def test_mode_detection(self):
        tracker = ProvenanceTracker()
        tracker.register("test", "col1")

        prov_empty = tracker.encode(set())
        prov_single = tracker.encode({0})

        assert tracker.get_mode(prov_empty) == "EXACT-0"
        assert tracker.get_mode(prov_single) == "EXACT-1"

    def test_all_pair_ids(self):
        tracker = ProvenanceTracker()
        for i in range(100):  # Test first 100 pair IDs
            tracker.register(f"table{i}", "col")

        for pid in range(100):
            prov = tracker.encode({pid}, entity=pid % 64, chain=0)
            pairs, entity, _ = tracker.decode_full(prov)
            assert pairs == {pid}
            assert entity == pid % 64


class TestMode01Encoding:
    """Tests for Mode 01 (2 pairs) encoding."""

    def test_two_pairs(self):
        tracker = ProvenanceTracker()
        tracker.register("test", "col1")
        tracker.register("test", "col2")

        prov = tracker.encode({0, 1}, entity=5, chain=3)

        pairs, entity, chain = tracker.decode_full(prov)
        assert pairs == {0, 1}
        assert entity == 5
        assert chain == 3

    def test_entity_chain_truncation_mode01(self):
        tracker = ProvenanceTracker()
        tracker.register("test", "col1")
        tracker.register("test", "col2")

        # Entity truncated to 3 bits (0-7), chain to 2 bits (0-3)
        prov = tracker.encode({0, 1}, entity=100, chain=200)

        pairs, entity, chain = tracker.decode_full(prov)
        assert pairs == {0, 1}
        assert entity == 100 % 8   # 4
        assert chain == 200 % 4    # 0

    def test_mode_detection_mode01(self):
        tracker = ProvenanceTracker()
        tracker.register("test", "col1")
        tracker.register("test", "col2")

        prov = tracker.encode({0, 1})
        assert tracker.get_mode(prov) == "EXACT-2"

    def test_various_pair_combinations(self):
        tracker = ProvenanceTracker()
        for i in range(50):
            tracker.register(f"t{i}", "c")

        # Test various 2-pair combinations
        test_cases = [(0, 1), (0, 49), (25, 30), (10, 40)]
        for p0, p1 in test_cases:
            prov = tracker.encode({p0, p1}, entity=3, chain=1)
            pairs, entity, chain = tracker.decode_full(prov)
            assert pairs == {p0, p1}, f"Failed for {p0}, {p1}"
            assert entity == 3
            assert chain == 1


class TestDenseMode:
    """Tests for Mode 11 (3+ pairs) dense encoding."""

    def test_three_pairs(self):
        tracker = ProvenanceTracker()
        tracker.register("t1", "c1")
        tracker.register("t2", "c2")
        tracker.register("t3", "c3")

        prov = tracker.encode({0, 1, 2}, entity=1000, chain=2000)

        pairs, entity, chain = tracker.decode_full(prov)
        assert pairs == {0, 1, 2}
        assert entity == 1000  # Full precision in registry
        assert chain == 2000

    def test_mode_detection_dense(self):
        tracker = ProvenanceTracker()
        for i in range(5):
            tracker.register(f"t{i}", "c")

        prov = tracker.encode({0, 1, 2, 3, 4})
        assert tracker.get_mode(prov) == "DENSE"

    def test_many_pairs(self):
        tracker = ProvenanceTracker()
        for i in range(20):
            tracker.register(f"t{i}", "c")

        all_pairs = set(range(20))
        prov = tracker.encode(all_pairs, entity=12345, chain=54321)

        pairs, entity, chain = tracker.decode_full(prov)
        assert pairs == all_pairs
        assert entity == 12345
        assert chain == 54321


class TestProvenanceCombine:
    """Tests for combining provenances."""

    def test_combine_single_pairs(self):
        tracker = ProvenanceTracker()
        tracker.register("t1", "c1")
        tracker.register("t2", "c2")

        prov1 = tracker.encode({0}, entity=10, chain=0)
        prov2 = tracker.encode({1}, entity=20, chain=0)

        combined = tracker.combine(prov1, prov2, OpCode.ADD)

        pairs, entity, chain = tracker.decode_full(combined)
        assert pairs == {0, 1}
        # XOR of entities (10 ^ 20 = 30), then truncated to 3 bits for mode 01 (30 % 8 = 6)
        assert entity == (10 ^ 20) % 8
        assert chain != 0  # Chain should be updated

    def test_combine_with_zero(self):
        tracker = ProvenanceTracker()
        tracker.register("t1", "c1")

        prov = tracker.encode({0}, entity=5, chain=3)

        assert tracker.combine(prov, 0) == prov
        assert tracker.combine(0, prov) == prov

    def test_combine_upgrades_mode(self):
        tracker = ProvenanceTracker()
        tracker.register("t1", "c1")
        tracker.register("t2", "c2")
        tracker.register("t3", "c3")

        prov1 = tracker.encode({0}, entity=1, chain=0)
        prov2 = tracker.encode({1, 2}, entity=2, chain=0)

        # 1 pair + 2 pairs = 3 pairs → DENSE mode
        combined = tracker.combine(prov1, prov2)

        assert tracker.get_mode(combined) == "DENSE"
        pairs, _, _ = tracker.decode_full(combined)
        assert pairs == {0, 1, 2}


class TestChainUpdates:
    """Tests for chain hash updates."""

    def test_unary_operation_updates_chain(self):
        tracker = ProvenanceTracker()
        tracker.register("t", "c")

        prov = tracker.encode({0}, entity=5, chain=0)
        updated = tracker.update_chain(prov, OpCode.NEG)

        _, _, chain = tracker.decode_full(updated)
        assert chain != 0  # Chain should be different

    def test_different_ops_different_chains(self):
        tracker = ProvenanceTracker()
        tracker.register("t", "c")

        prov = tracker.encode({0}, entity=5, chain=10)

        chain_add = tracker.update_chain(prov, OpCode.ADD)
        chain_mul = tracker.update_chain(prov, OpCode.MUL)

        _, _, c_add = tracker.decode_full(chain_add)
        _, _, c_mul = tracker.decode_full(chain_mul)

        assert c_add != c_mul


class TestTrackedSeries:
    """Tests for TrackedSeries with entity and chain."""

    def test_binary_operation_combines_prov(self):
        tracker = ProvenanceTracker()
        tracker.register("t1", "a")
        tracker.register("t2", "b")

        prov1 = tracker.encode({0}, entity=1, chain=0)
        prov2 = tracker.encode({1}, entity=2, chain=0)

        s1 = TrackedSeries([1, 2, 3], _prov=np.array([prov1]*3, dtype=np.uint32), _tracker=tracker)
        s2 = TrackedSeries([4, 5, 6], _prov=np.array([prov2]*3, dtype=np.uint32), _tracker=tracker)

        result = s1 + s2

        assert list(result) == [5, 7, 9]

        # Check provenance combined
        result_prov = int(result._prov[0])
        pairs, entity, chain = tracker.decode_full(result_prov)
        assert pairs == {0, 1}
        assert entity == 1 ^ 2  # XOR

    def test_unary_operation_updates_chain(self):
        tracker = ProvenanceTracker()
        tracker.register("t", "c")

        prov = tracker.encode({0}, entity=5, chain=0)
        s = TrackedSeries([1, -2, 3], _prov=np.array([prov]*3, dtype=np.uint32), _tracker=tracker)

        result = -s

        # Chain should be updated
        result_prov = int(result._prov[0])
        _, _, chain = tracker.decode_full(result_prov)
        assert chain != 0


class TestTrackedDataFrame:
    """Tests for TrackedDataFrame."""

    def test_wrap_dataframe_includes_entity(self):
        tracker = ProvenanceTracker()
        df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})

        wrapped = wrap_dataframe(df, tracker, "test", include_entity=True)

        # Different rows should have different entities
        col_a = wrapped['a']
        provs = [int(p) for p in col_a._prov]

        entities = [tracker.decode_full(p)[1] for p in provs]
        assert len(set(entities)) >= 1  # At least some variation expected

    def test_wrap_dataframe_no_entity(self):
        tracker = ProvenanceTracker()
        df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})

        wrapped = wrap_dataframe(df, tracker, "test", include_entity=False)

        col_a = wrapped['a']
        provs = [int(p) for p in col_a._prov]

        entities = [tracker.decode_full(p)[1] for p in provs]
        assert all(e == 0 for e in entities)


class TestAudit:
    """Tests for audit functions."""

    def test_audit_basic(self):
        tracker = ProvenanceTracker()
        tracker.register("users", "email")

        prov = tracker.encode({0}, entity=42, chain=7)
        s = TrackedSeries([1, 2], _prov=np.array([prov]*2, dtype=np.uint32), _tracker=tracker)

        result = audit(s)

        assert result['mode'] == "EXACT-1"
        assert result['pair_count'] == 1
        assert result['entity'] == 42
        assert result['chain'] == 7
        assert result['columns'] == [('users', 'email')]

    def test_audit_diversity(self):
        tracker = ProvenanceTracker()
        tracker.register("t", "c")

        # Create series with varying entities
        provs = [tracker.encode({0}, entity=i % 10, chain=0) for i in range(100)]
        s = TrackedSeries(range(100), _prov=np.array(provs, dtype=np.uint32), _tracker=tracker)

        result = audit_series_diversity(s)

        assert result['total_rows'] == 100
        assert result['unique_entities'] == 10  # 0-9


class TestExplainFull:
    """Tests for explain_full method."""

    def test_explain_full_all_info(self):
        tracker = ProvenanceTracker()
        tracker.register("users", "name")
        tracker.register("orders", "total")

        prov = tracker.encode({0, 1}, entity=5, chain=3)

        info = tracker.explain_full(prov)

        assert info['pairs'] == [('users', 'name'), ('orders', 'total')]
        assert info['pair_ids'] == [0, 1]
        assert info['entity'] == 5
        assert info['chain'] == 3
        assert info['mode'] == "EXACT-2"
        assert 'provenance_hex' in info


class TestBitLayoutVerification:
    """Verify the bit layout is correct for all modes."""

    def test_mode00_bit_layout(self):
        tracker = ProvenanceTracker()
        tracker.register("t", "c")

        # Max values for mode 00
        prov = tracker.encode({0}, entity=63, chain=63)

        # Decode and verify
        mode = (prov >> 22) & 0b11
        pair_data = (prov >> 12) & 0x3FF
        entity = (prov >> 6) & 0x3F
        chain = prov & 0x3F

        assert mode == MODE_01
        assert pair_data == 1  # 0 + 1 = single pair encoding
        assert entity == 63
        assert chain == 63

    def test_mode01_bit_layout(self):
        tracker = ProvenanceTracker()
        tracker.register("t1", "c1")
        tracker.register("t2", "c2")

        prov = tracker.encode({0, 1}, entity=7, chain=3)

        mode = (prov >> 22) & 0b11
        pair_data = (prov >> 5) & 0x1FFFF
        entity = (prov >> 2) & 0x7
        chain = prov & 0x3

        assert mode == MODE_2
        assert entity == 7
        assert chain == 3

    def test_24_bit_constraint(self):
        tracker = ProvenanceTracker()
        for i in range(10):
            tracker.register(f"t{i}", "c")

        # Test all modes stay within 24 bits
        prov_00 = tracker.encode({0}, entity=63, chain=63)
        prov_01 = tracker.encode({0, 1}, entity=7, chain=3)
        prov_11 = tracker.encode({0, 1, 2}, entity=999, chain=999)

        assert prov_00 < (1 << 24)
        assert prov_01 < (1 << 24)
        assert prov_11 < (1 << 24)


class TestLegacyCompatibility:
    """Tests for backward compatibility with legacy API."""

    def test_decode_returns_pairs_only(self):
        tracker = ProvenanceTracker()
        tracker.register("t", "c")

        prov = tracker.encode({0}, entity=42, chain=7)

        # Legacy decode should return just pairs
        pairs = tracker.decode(prov)
        assert pairs == {0}
        assert isinstance(pairs, set)

    def test_explain_works(self):
        tracker = ProvenanceTracker()
        tracker.register("users", "email")

        prov = tracker.encode({0})

        names = tracker.explain(prov)
        assert names == [('users', 'email')]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
