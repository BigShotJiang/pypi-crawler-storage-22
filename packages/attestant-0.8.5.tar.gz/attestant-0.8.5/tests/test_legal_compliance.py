"""
Tests for 2025-2026 legal compliance enhancements.

Covers:
    - ECOA engine: intersectional DI, adverse action completeness,
      model explainability, HMDA monitoring, SOGI protection, record retention
    - SR 11-7 engine: model tiering, independent validation, challenger models,
      vendor models, governance framework, concentration risk, use limitations,
      monitoring frequency alignment, model documentation
    - EU AI Act engine: FRIA (Article 27), cybersecurity (Article 15(5)),
      data bias/representativeness (Article 10)
    - Colorado AI Act engine (SB 24-205)
    - NYC Local Law 144 engine (AEDT)
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from attestant.hydra24_dag import (
    ComputationDAG,
    DAGTracker,
    wrap_dataframe_dag,
    get_dag_for_series,
)
from attestant.compliance.base import ComplianceFinding, ComplianceResult, Severity
from attestant.compliance.ecoa import ECOAEngine
from attestant.compliance.sr117 import SR117Engine
from attestant.compliance.eu_ai_act import EUAIActEngine
from attestant.compliance.colorado_ai_act import ColoradoAIActEngine
from attestant.compliance.nyc_ll144 import NYCLL144Engine


# ============================================================================
# Helpers
# ============================================================================

def _build_clean_dag():
    """Build a DAG with no protected data."""
    tracker = DAGTracker()
    df = pd.DataFrame({
        "applicant_id": [1, 2, 3],
        "credit_score": [720, 680, 750],
        "annual_income": [85000, 65000, 120000],
    })
    wrapped = wrap_dataframe_dag(df, tracker, "credit_bureau")
    score = wrapped["annual_income"] / wrapped["credit_score"]
    dag = get_dag_for_series(score, row_index=0)
    return tracker, dag


def _build_sogi_dag():
    """Build a DAG with SOGI-related columns used in computation."""
    tracker = DAGTracker()
    df = pd.DataFrame({
        "applicant_id": [1, 2, 3],
        "credit_score": [720, 680, 750],
        "sexual_orientation": [1, 0, 1],  # numeric so it can be used in calc
    })
    wrapped = wrap_dataframe_dag(df, tracker, "applicant_data")
    # Use the SOGI column in a computation so it appears in the DAG
    score = wrapped["credit_score"] + wrapped["sexual_orientation"]
    dag = get_dag_for_series(score, row_index=0)
    return tracker, dag


# ============================================================================
# ECOA Engine - Intersectional Impact
# ============================================================================

class TestECOAIntersectionalImpact:
    """12 CFR 1002.4(a) / CFPB Supervisory Highlights (Jan 2025)."""

    def test_missing_intersectional_analysis_warning(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={})
        descs = [f.description for f in result.findings]
        assert any("intersectional" in d.lower() for d in descs)

    def test_intersectional_analysis_present_no_di(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "intersectional_impact_analysis": [
                {"attribute_pair": ["race", "sex"], "worst_ratio": 0.95}
            ],
        })
        descs = [f.description for f in result.findings if f.severity == Severity.CRITICAL]
        assert not any("intersectional disparate impact" in d.lower() for d in descs)

    def test_intersectional_analysis_with_di(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "intersectional_impact_analysis": [
                {"attribute_pair": ["race", "sex"], "worst_ratio": 0.55}
            ],
        })
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("intersectional disparate impact" in f.description.lower() for f in crit)


# ============================================================================
# ECOA Engine - Adverse Action Completeness
# ============================================================================

class TestECOAAdverseActionCompleteness:
    """12 CFR 1002.9(a)(2) / Appendix C."""

    def test_no_notice_data_when_adverse(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "is_adverse_action": True,
            "adverse_action_reasons": ["Too much debt"],
        })
        descs = [f.description for f in result.findings]
        assert any("notice" in d.lower() and "template" in d.lower() or
                    "notice" in d.lower() and "data" in d.lower() for d in descs)

    def test_complete_notice_no_finding(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "is_adverse_action": True,
            "adverse_action_reasons": ["Debt to income ratio too high"],
            "adverse_action_notice_date": "2025-01-15",
            "adverse_action_decision_date": "2025-01-10",
            "adverse_action_notice_data": {
                "creditor_name": "TestBank",
                "creditor_address": "123 Main St",
                "ecoa_statement": "The Federal ECOA prohibits discrimination...",
                "agency_name": "CFPB",
                "specific_reasons": ["Debt to income ratio too high"],
            },
        })
        completeness_criticals = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL and "missing required fields" in f.description
        ]
        assert len(completeness_criticals) == 0

    def test_missing_fields_critical(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "is_adverse_action": True,
            "adverse_action_reasons": ["Debt to income ratio too high"],
            "adverse_action_notice_data": {
                "creditor_name": "TestBank",
                # Missing other fields
            },
        })
        crit = [f for f in result.findings if "missing required fields" in f.description]
        assert len(crit) > 0


# ============================================================================
# ECOA Engine - Model Explainability
# ============================================================================

class TestECOAModelExplainability:
    """CFPB Circular 2023-03: No black-box models."""

    def test_black_box_model_critical(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "explanation_method": "zeros",
        })
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("black-box" in f.description.lower() or "zeros" in f.description for f in crit)

    def test_low_fidelity_warning(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "explanation_method": "shap",
            "explanation_confidence": 0.60,
        })
        warns = [f for f in result.findings if f.severity == Severity.WARNING]
        assert any("fidelity" in f.description.lower() or "confidence" in f.description.lower() for f in warns)

    def test_good_explanation_no_critical(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "explanation_method": "shap",
            "explanation_confidence": 0.95,
        })
        crit = [f for f in result.findings if "Circular 2023-03" in f.regulation_citation and f.severity == Severity.CRITICAL]
        assert len(crit) == 0


# ============================================================================
# ECOA Engine - HMDA Monitoring
# ============================================================================

class TestECOAHMDAMonitoring:
    """12 CFR 1002.13: HMDA monitoring information collection."""

    def test_hmda_missing_demographics_critical(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "hmda_reportable": True,
            "collected_demographics": ["age"],
        })
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("hmda" in f.description.lower() or "1002.13" in f.regulation_citation for f in crit)

    def test_hmda_complete_demographics(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "hmda_reportable": True,
            "collected_demographics": ["race", "ethnicity", "sex", "age"],
            "monitoring_purpose_disclosed": True,
        })
        hmda_crit = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL and "1002.13" in f.regulation_citation
        ]
        assert len(hmda_crit) == 0


# ============================================================================
# ECOA Engine - SOGI Protection
# ============================================================================

class TestECOASOGIProtection:
    """CFPB 2021 Interpretive Rule: SOGI protection."""

    def test_sogi_column_detected(self):
        _, dag = _build_sogi_dag()
        engine = ECOAEngine()
        result = engine.check(dag)
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("sexual orientation" in f.description.lower() or "gender identity" in f.description.lower() for f in crit)


# ============================================================================
# ECOA Engine - Record Retention
# ============================================================================

class TestECOARecordRetention:
    """12 CFR 1002.12(a): Record retention with investigation hold."""

    def test_investigation_hold(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "record_retention_months": 25,
            "under_investigation": True,
        })
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("investigation" in f.description.lower() for f in crit)

    def test_adequate_retention_no_critical(self):
        _, dag = _build_clean_dag()
        engine = ECOAEngine()
        result = engine.check(dag, metadata={
            "record_retention_months": 36,
        })
        retention_crit = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL and "1002.12" in f.regulation_citation
        ]
        assert len(retention_crit) == 0


# ============================================================================
# SR 11-7 Engine - Model Tiering
# ============================================================================

class TestSR117ModelTiering:
    """SR 11-7 § 5: Model risk tiering."""

    def test_missing_tier_warning(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={"model_id": "TEST_1"})
        descs = [f.description for f in result.findings]
        assert any("risk tier" in d.lower() for d in descs)

    def test_valid_tier_accepted(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "TEST_1",
            "model_risk_tier": "high",
        })
        tier_warns = [
            f for f in result.findings
            if "invalid risk tier" in f.description.lower()
        ]
        assert len(tier_warns) == 0

    def test_invalid_tier_warning(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "TEST_1",
            "model_risk_tier": "extreme",
        })
        warns = [f for f in result.findings if "invalid risk tier" in f.description.lower()]
        assert len(warns) > 0


# ============================================================================
# SR 11-7 Engine - Independent Validation
# ============================================================================

class TestSR117IndependentValidation:
    """SR 11-7 § 4: Validator independence."""

    def test_validator_same_as_developer_critical(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "TEST_1",
            "model_validator": "John Smith",
            "model_developer": "John Smith",
            "model_validation_date": "2025-01-01",
        })
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("developer" in f.description.lower() and "independence" in f.description.lower() for f in crit)

    def test_independent_validator_no_conflict(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "TEST_1",
            "model_validator": "Jane Doe",
            "model_developer": "John Smith",
            "model_validation_date": "2025-01-01",
        })
        conflict_crit = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL and "developer" in f.description.lower()
            and "independence" in f.description.lower()
        ]
        assert len(conflict_crit) == 0


# ============================================================================
# SR 11-7 Engine - Vendor Models
# ============================================================================

class TestSR117VendorModels:
    """Interagency Third-Party Guidance (2023): Vendor model risk."""

    def test_vendor_model_missing_name_critical(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "VENDOR_1",
            "is_vendor_model": True,
        })
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("vendor" in f.description.lower() for f in crit)

    def test_vendor_model_complete(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "VENDOR_1",
            "is_vendor_model": True,
            "vendor_name": "ModelCo Inc.",
            "vendor_model_validation_evidence": "Validated Q3 2025",
            "vendor_contract_terms": "SLA includes monitoring data",
        })
        vendor_crit = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL and "vendor" in f.description.lower()
        ]
        assert len(vendor_crit) == 0

    def test_non_vendor_skips_vendor_checks(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={"model_id": "TEST_1"})
        vendor_findings = [
            f for f in result.findings if "vendor" in f.description.lower()
        ]
        assert len(vendor_findings) == 0


# ============================================================================
# SR 11-7 Engine - Governance Framework
# ============================================================================

class TestSR117GovernanceFramework:
    """SR 11-7 § 5: MRM committee, board reporting, policies."""

    def test_missing_governance_findings(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={"model_id": "TEST_1"})
        descs = [f.description for f in result.findings]
        assert any("mrm" in d.lower() or "committee" in d.lower() for d in descs)
        assert any("board" in d.lower() and "reporting" in d.lower() for d in descs)

    def test_critical_tier_needs_board_approval(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "TEST_1",
            "model_risk_tier": "critical",
        })
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("board approval" in f.description.lower() for f in crit)

    def test_board_approval_present(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "TEST_1",
            "model_risk_tier": "critical",
            "board_approval_date": "2025-06-01",
        })
        board_crit = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL and "board approval" in f.description.lower()
        ]
        assert len(board_crit) == 0


# ============================================================================
# SR 11-7 Engine - Monitoring Frequency Alignment
# ============================================================================

class TestSR117MonitoringFrequency:
    """SR 11-7 § 4.2: Monitoring frequency must match risk tier."""

    def test_annual_too_slow_for_critical(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "TEST_1",
            "model_risk_tier": "critical",
            "monitoring_frequency": "annual",
        })
        warns = [f for f in result.findings if "less frequent" in f.description.lower()]
        assert len(warns) > 0

    def test_monthly_ok_for_critical(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "TEST_1",
            "model_risk_tier": "critical",
            "monitoring_frequency": "monthly",
        })
        freq_warns = [
            f for f in result.findings if "less frequent" in f.description.lower()
        ]
        assert len(freq_warns) == 0


# ============================================================================
# SR 11-7 Engine - Concentration Risk
# ============================================================================

class TestSR117ConcentrationRisk:
    """OCC Handbook § 2.2: Feature concentration risk."""

    def test_high_feature_concentration_warning(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "TEST_1",
            "feature_importance": {
                "credit_score": 0.60,
                "income": 0.25,
                "dti": 0.10,
                "age": 0.03,
                "other": 0.02,
            },
        })
        warns = [f for f in result.findings if "concentration" in f.description.lower()]
        assert len(warns) > 0

    def test_diversified_features_no_warning(self):
        _, dag = _build_clean_dag()
        engine = SR117Engine()
        result = engine.check(dag, metadata={
            "model_id": "TEST_1",
            "feature_importance": {
                "f1": 0.20, "f2": 0.18, "f3": 0.17,
                "f4": 0.15, "f5": 0.15, "f6": 0.15,
            },
        })
        concentration_warns = [
            f for f in result.findings
            if "concentration risk" in f.description.lower()
            and f.severity == Severity.WARNING
        ]
        assert len(concentration_warns) == 0


# ============================================================================
# EU AI Act - Fundamental Rights Impact Assessment
# ============================================================================

class TestEUAIActFRIA:
    """Article 27: Fundamental rights impact assessment."""

    def test_high_risk_missing_fria_critical(self):
        _, dag = _build_clean_dag()
        engine = EUAIActEngine()
        result = engine.check(dag, metadata={
            "domain": "credit_scoring",
            "risk_management_plan": "Plan v1",
            "risk_assessment_completed": True,
            "risk_mitigation_measures": "Bias monitoring",
            "human_oversight_mode": "human_on_the_loop",
            "training_data_description": "Historical data",
        })
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("fundamental rights" in f.description.lower() for f in crit)

    def test_fria_present_no_critical(self):
        _, dag = _build_clean_dag()
        engine = EUAIActEngine()
        result = engine.check(dag, metadata={
            "domain": "credit_scoring",
            "risk_management_plan": "Plan v1",
            "risk_assessment_completed": True,
            "risk_mitigation_measures": "Bias monitoring",
            "human_oversight_mode": "human_on_the_loop",
            "training_data_description": "Historical data",
            "fundamental_rights_impact_assessment": "Assessed 2025-Q1",
            "affected_persons_description": "Loan applicants age 18+",
            "technical_documentation": "DOC-001",
            "algorithm_description": "GBM with 500 trees",
        })
        fria_crit = [
            f for f in result.findings
            if f.severity == Severity.CRITICAL and "fundamental rights" in f.description.lower()
        ]
        assert len(fria_crit) == 0

    def test_minimal_risk_skips_fria(self):
        _, dag = _build_clean_dag()
        engine = EUAIActEngine()
        result = engine.check(dag, metadata={
            "domain": "weather_forecasting",
        })
        fria_findings = [
            f for f in result.findings if "fundamental rights" in f.description.lower()
        ]
        assert len(fria_findings) == 0


# ============================================================================
# EU AI Act - Cybersecurity
# ============================================================================

class TestEUAIActCybersecurity:
    """Article 15(5): Cybersecurity measures."""

    def test_missing_cybersecurity_warning(self):
        _, dag = _build_clean_dag()
        engine = EUAIActEngine()
        result = engine.check(dag, metadata={
            "domain": "credit_scoring",
        })
        descs = [f.description for f in result.findings]
        assert any("cybersecurity" in d.lower() for d in descs)


# ============================================================================
# EU AI Act - Data Bias
# ============================================================================

class TestEUAIActDataBias:
    """Article 10(2)(f-g): Data bias and representativeness."""

    def test_high_risk_missing_bias_exam(self):
        _, dag = _build_clean_dag()
        engine = EUAIActEngine()
        result = engine.check(dag, metadata={
            "domain": "credit_scoring",
        })
        descs = [f.description for f in result.findings]
        assert any("bias examination" in d.lower() for d in descs)

    def test_bias_documented_no_warning(self):
        _, dag = _build_clean_dag()
        engine = EUAIActEngine()
        result = engine.check(dag, metadata={
            "domain": "credit_scoring",
            "bias_examination_documented": True,
            "data_representativeness_assessment": "Representative",
        })
        bias_warns = [
            f for f in result.findings
            if f.severity == Severity.WARNING and "bias examination" in f.description.lower()
        ]
        assert len(bias_warns) == 0


# ============================================================================
# Colorado AI Act Engine
# ============================================================================

class TestColoradoAIAct:
    """C.R.S. § 6-1-1701 et seq.: Colorado AI Act (SB 24-205)."""

    def test_consequential_domain_classified(self):
        _, dag = _build_clean_dag()
        engine = ColoradoAIActEngine()
        result = engine.check(dag, metadata={"domain": "credit_scoring"})
        assert result.regulation_name == "Colorado AI Act (SB 24-205)"
        assert result.metadata["is_consequential_decision"] is True

    def test_non_consequential_domain(self):
        _, dag = _build_clean_dag()
        engine = ColoradoAIActEngine()
        result = engine.check(dag, metadata={"domain": "weather_forecasting"})
        assert result.metadata["is_consequential_decision"] is False
        # Should pass with no critical findings
        assert result.passed is True

    def test_missing_risk_management_critical(self):
        _, dag = _build_clean_dag()
        engine = ColoradoAIActEngine()
        result = engine.check(dag, metadata={"domain": "loan_approval"})
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("risk management" in f.description.lower() for f in crit)

    def test_missing_impact_assessment_critical(self):
        _, dag = _build_clean_dag()
        engine = ColoradoAIActEngine()
        result = engine.check(dag, metadata={"domain": "hiring"})
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("impact assessment" in f.description.lower() for f in crit)

    def test_missing_consumer_notice_critical(self):
        _, dag = _build_clean_dag()
        engine = ColoradoAIActEngine()
        result = engine.check(dag, metadata={"domain": "insurance_pricing"})
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("consumer" in f.description.lower() and "disclosure" in f.description.lower() for f in crit)

    def test_compliant_system_passes(self):
        _, dag = _build_clean_dag()
        engine = ColoradoAIActEngine()
        result = engine.check(dag, metadata={
            "domain": "credit_scoring",
            "risk_management_policy": "MRM Policy v3.0",
            "risk_management_framework": "NIST AI RMF 1.0",
            "impact_assessment_date": "2025-12-01",
            "impact_assessment_summary": "Low risk of discrimination",
            "deployer_contact_info": "compliance@bank.com",
            "human_appeal_process": "Applicants may appeal via phone",
            "developer_documentation_provided": True,
            "consumer_ai_disclosure": "AI is used in credit decisions",
            "adverse_decision_explanation": "Feature-level reasons provided",
        })
        assert result.passed is True

    def test_stale_impact_assessment_warning(self):
        _, dag = _build_clean_dag()
        engine = ColoradoAIActEngine()
        result = engine.check(dag, metadata={
            "domain": "credit_scoring",
            "risk_management_policy": "Policy v1",
            "impact_assessment_date": "2024-01-01",
            "consumer_ai_disclosure": "Disclosed",
        })
        warns = [f for f in result.findings if "days old" in f.description.lower()]
        assert len(warns) > 0


# ============================================================================
# NYC Local Law 144 Engine
# ============================================================================

class TestNYCLL144:
    """NYC Admin. Code § 20-870 et seq.: Local Law 144 (AEDT)."""

    def test_aedt_domain_classified(self):
        _, dag = _build_clean_dag()
        engine = NYCLL144Engine()
        result = engine.check(dag, metadata={"domain": "hiring"})
        assert result.regulation_name == "NYC Local Law 144 (AEDT)"
        assert result.metadata["is_aedt"] is True

    def test_non_aedt_domain(self):
        _, dag = _build_clean_dag()
        engine = NYCLL144Engine()
        result = engine.check(dag, metadata={"domain": "credit_scoring"})
        assert result.metadata["is_aedt"] is False
        assert result.passed is True

    def test_missing_bias_audit_critical(self):
        _, dag = _build_clean_dag()
        engine = NYCLL144Engine()
        result = engine.check(dag, metadata={"domain": "hiring"})
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("bias audit" in f.description.lower() for f in crit)

    def test_missing_candidate_notice_critical(self):
        _, dag = _build_clean_dag()
        engine = NYCLL144Engine()
        result = engine.check(dag, metadata={"domain": "recruitment"})
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("candidate notice" in f.description.lower() or "notice" in f.description.lower() for f in crit)

    def test_missing_audit_publication_critical(self):
        _, dag = _build_clean_dag()
        engine = NYCLL144Engine()
        result = engine.check(dag, metadata={"domain": "hiring"})
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("summary" in f.description.lower() and "published" in f.description.lower() for f in crit)

    def test_stale_audit_critical(self):
        _, dag = _build_clean_dag()
        engine = NYCLL144Engine()
        result = engine.check(dag, metadata={
            "domain": "hiring",
            "bias_audit_date": "2024-01-01",
            "bias_audit_independent_auditor": "AuditCo",
            "bias_audit_summary_published": True,
            "bias_audit_summary_url": "https://example.com/audit",
            "candidate_notice_provided": True,
        })
        crit = [f for f in result.findings if f.severity == Severity.CRITICAL]
        assert any("days old" in f.description.lower() or "12-month" in f.description.lower() for f in crit)

    def test_compliant_aedt_passes(self):
        _, dag = _build_clean_dag()
        engine = NYCLL144Engine()
        result = engine.check(dag, metadata={
            "domain": "hiring",
            "bias_audit_date": "2025-12-01",
            "bias_audit_independent_auditor": "FairAudit LLC",
            "bias_audit_summary_published": True,
            "bias_audit_summary_url": "https://example.com/audit",
            "candidate_notice_provided": True,
            "candidate_data_retention_notice": True,
            "bias_audit_results": {
                "sex": {"impact_ratio": 0.92},
                "race_ethnicity": {"impact_ratio": 0.88},
            },
            "bias_audit_intersectional": True,
            "alternative_process_available": True,
        })
        assert result.passed is True


# ============================================================================
# Integration: ComplianceReport with all engines
# ============================================================================

class TestMultiEngineReport:
    """Test that all 5 engines can run together in a ComplianceReport."""

    def test_all_engines_run(self):
        from attestant.compliance.base import ComplianceReport
        _, dag = _build_clean_dag()

        report = ComplianceReport()
        engines = [
            ECOAEngine(),
            EUAIActEngine(),
            SR117Engine(),
            ColoradoAIActEngine(),
            NYCLL144Engine(),
        ]
        report.run_engines(engines, dag, metadata={
            "domain": "credit_scoring",
            "model_id": "TEST_MULTI",
        })

        assert report.total_findings > 0
        assert len(report.results) == 5

        summary = report.summary()
        assert summary["engines_run"] == 5
        assert "ECOA / Reg B" in summary["per_regulation"]
        assert "EU AI Act" in summary["per_regulation"]
        assert "SR 11-7 / OCC 2011-12" in summary["per_regulation"]
        assert "Colorado AI Act (SB 24-205)" in summary["per_regulation"]
        assert "NYC Local Law 144 (AEDT)" in summary["per_regulation"]

    def test_examiner_summary_routes_findings(self):
        from attestant.compliance.base import ComplianceReport
        _, dag = _build_clean_dag()

        report = ComplianceReport()
        engines = [ECOAEngine(), SR117Engine()]
        report.run_engines(engines, dag, metadata={
            "model_id": "TEST_EXAM",
        })

        exam_summary = report.examiner_summary()
        assert "model_risk" in exam_summary
        assert "fair_lending" in exam_summary
        assert "action_items" in exam_summary
