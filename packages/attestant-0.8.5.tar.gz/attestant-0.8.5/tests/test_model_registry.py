"""Tests for the ModelRegistry lifecycle management system."""

import pytest
from datetime import datetime, timezone, timedelta

from attestant.governance.model_registry import (
    ModelRecord,
    ModelRegistry,
    ModelStatus,
    ModelTier,
    MonitoringResult,
    ValidationRecord,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now() -> datetime:
    return datetime.now(timezone.utc)


def _days_ago(n: int) -> datetime:
    return _now() - timedelta(days=n)


def _days_from_now(n: int) -> datetime:
    return _now() + timedelta(days=n)


def _make_model(
    model_id: str = "test_model",
    tier: int = 1,
    status: str = "production",
    domain: str = "lending",
    **kwargs,
) -> ModelRecord:
    return ModelRecord(
        model_id=model_id,
        name=f"Test Model {model_id}",
        version="1.0.0",
        tier=tier,
        owner="MRM Team",
        domain=domain,
        status=status,
        **kwargs,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestModelRecord:
    """Test ModelRecord dataclass."""

    def test_basic_creation(self):
        m = _make_model()
        assert m.model_id == "test_model"
        assert m.tier == 1
        assert m.status == "production"
        assert m.is_production
        assert m.is_active

    def test_tier_enum(self):
        m = _make_model(tier=2)
        assert m.tier_enum == ModelTier.TIER_2

    def test_status_enum(self):
        m = _make_model(status="validation")
        assert m.status_enum == ModelStatus.VALIDATION

    def test_is_production(self):
        assert _make_model(status="production").is_production
        assert _make_model(status="monitoring").is_production
        assert not _make_model(status="development").is_production
        assert not _make_model(status="retired").is_production

    def test_is_active(self):
        assert _make_model(status="production").is_active
        assert _make_model(status="development").is_active
        assert not _make_model(status="deprecated").is_active
        assert not _make_model(status="retired").is_active

    def test_validation_overdue_no_date(self):
        m = _make_model()
        assert m.validation_overdue  # No validation date = overdue

    def test_validation_overdue_future(self):
        m = _make_model()
        m.next_validation_date = _days_from_now(30)
        assert not m.validation_overdue

    def test_validation_overdue_past(self):
        m = _make_model()
        m.next_validation_date = _days_ago(10)
        assert m.validation_overdue

    def test_monitoring_frequency_by_tier(self):
        assert _make_model(tier=1).monitoring_frequency_days == 90
        assert _make_model(tier=2).monitoring_frequency_days == 180
        assert _make_model(tier=3).monitoring_frequency_days == 365

    def test_monitoring_overdue_no_results(self):
        m = _make_model(status="production")
        assert m.monitoring_overdue

    def test_monitoring_overdue_recent(self):
        m = _make_model(tier=1)
        m.monitoring_results.append(MonitoringResult(
            date=_days_ago(30),
            monitor_type="fairness",
            passed=True,
        ))
        assert not m.monitoring_overdue  # Tier 1 = 90 days, 30 < 90

    def test_monitoring_overdue_stale(self):
        m = _make_model(tier=1)
        m.monitoring_results.append(MonitoringResult(
            date=_days_ago(100),
            monitor_type="fairness",
            passed=True,
        ))
        assert m.monitoring_overdue  # Tier 1 = 90 days, 100 > 90

    def test_to_dict(self):
        m = _make_model()
        d = m.to_dict()
        assert d["model_id"] == "test_model"
        assert d["tier"] == 1
        assert d["status"] == "production"
        assert "is_production" in d
        assert "validation_overdue" in d
        assert "monitoring_overdue" in d

    def test_latest_monitoring(self):
        m = _make_model()
        m.monitoring_results.append(MonitoringResult(
            date=_days_ago(30), monitor_type="fairness", passed=True,
        ))
        m.monitoring_results.append(MonitoringResult(
            date=_days_ago(5), monitor_type="drift", passed=False,
        ))
        assert m.latest_monitoring.monitor_type == "drift"


class TestModelRegistry:
    """Test ModelRegistry operations."""

    def test_register_and_get(self):
        reg = ModelRegistry()
        model = _make_model("m1")
        reg.register(model)
        assert reg.get("m1") is model
        assert reg.get("nonexistent") is None

    def test_register_adds_change_history(self):
        reg = ModelRegistry()
        model = _make_model("m1")
        reg.register(model)
        assert len(model.change_history) == 1
        assert model.change_history[0]["action"] == "registered"

    def test_update_status(self):
        reg = ModelRegistry()
        reg.register(_make_model("m1", status="development"))
        reg.update_status("m1", "production")
        assert reg.get("m1").status == "production"
        assert len(reg.get("m1").change_history) == 2
        assert reg.get("m1").change_history[-1]["action"] == "status_change"

    def test_update_status_nonexistent(self):
        reg = ModelRegistry()
        with pytest.raises(KeyError):
            reg.update_status("nonexistent", "production")

    def test_record_validation(self):
        reg = ModelRegistry()
        reg.register(_make_model("m1"))
        validation = ValidationRecord(
            validation_id="v1",
            date=_now(),
            validator="Internal Validation Group",
            independent=True,
            result="approved",
            findings_count=3,
            next_validation_date=_days_from_now(365),
        )
        reg.record_validation("m1", validation)
        m = reg.get("m1")
        assert len(m.validations) == 1
        assert m.last_validation_date == validation.date
        assert m.next_validation_date == validation.next_validation_date

    def test_record_monitoring(self):
        reg = ModelRegistry()
        reg.register(_make_model("m1"))
        result = MonitoringResult(
            date=_now(),
            monitor_type="fairness",
            passed=True,
            metrics={"di_ratio_race": 0.85},
        )
        reg.record_monitoring("m1", result)
        assert len(reg.get("m1").monitoring_results) == 1

    def test_record_monitoring_failure_logs_change(self):
        reg = ModelRegistry()
        reg.register(_make_model("m1"))
        result = MonitoringResult(
            date=_now(),
            monitor_type="drift",
            passed=False,
            alerts=["DI ratio below threshold"],
        )
        reg.record_monitoring("m1", result)
        m = reg.get("m1")
        assert any(
            h["action"] == "monitoring_alert"
            for h in m.change_history
        )

    def test_update_compliance_score(self):
        reg = ModelRegistry()
        reg.register(_make_model("m1"))
        reg.update_compliance_score("m1", 85.5)
        assert reg.get("m1").compliance_score == 85.5


class TestModelRegistryQueries:
    """Test registry query methods."""

    def _setup_registry(self) -> ModelRegistry:
        reg = ModelRegistry()
        reg.register(_make_model("m1", tier=1, status="production", domain="lending"))
        reg.register(_make_model("m2", tier=2, status="production", domain="fraud"))
        reg.register(_make_model("m3", tier=3, status="development", domain="lending"))
        reg.register(_make_model("m4", tier=1, status="retired", domain="lending"))
        return reg

    def test_all_models(self):
        reg = self._setup_registry()
        assert len(reg.all_models) == 4

    def test_active_models(self):
        reg = self._setup_registry()
        assert len(reg.active_models) == 3  # excludes retired m4

    def test_production_models(self):
        reg = self._setup_registry()
        assert len(reg.production_models) == 2  # m1 and m2

    def test_models_by_tier(self):
        reg = self._setup_registry()
        assert len(reg.models_by_tier(1)) == 2  # m1 and m4
        assert len(reg.models_by_tier(2)) == 1  # m2
        assert len(reg.models_by_tier(3)) == 1  # m3

    def test_models_by_domain(self):
        reg = self._setup_registry()
        assert len(reg.models_by_domain("lending")) == 3
        assert len(reg.models_by_domain("fraud")) == 1
        assert len(reg.models_by_domain("unknown")) == 0

    def test_validation_overdue(self):
        reg = self._setup_registry()
        # All active models have no validation date = overdue
        overdue = reg.validation_overdue
        assert len(overdue) == 3  # m1, m2, m3 (not m4 = retired)

    def test_monitoring_overdue(self):
        reg = self._setup_registry()
        # Production models with no monitoring = overdue
        overdue = reg.monitoring_overdue
        assert len(overdue) == 2  # m1 and m2


class TestModelRegistryReports:
    """Test registry reporting."""

    def test_inventory_report(self):
        reg = ModelRegistry()
        reg.register(_make_model("m1", tier=1, status="production"))
        reg.register(_make_model("m2", tier=2, status="development"))
        reg.update_compliance_score("m1", 90.0)

        report = reg.inventory_report()
        assert report["total_models"] == 2
        assert report["active_models"] == 2
        assert report["production_models"] == 1
        assert report["by_tier"][1] == 1
        assert report["by_tier"][2] == 1
        assert report["average_compliance_score"] == 90.0
        assert len(report["models"]) == 2

    def test_risk_summary(self):
        reg = ModelRegistry()
        reg.register(_make_model("m1", tier=1, status="production"))
        reg.update_compliance_score("m1", 45.0)  # Low score

        summary = reg.risk_summary()
        assert summary["total_production_models"] == 1
        assert summary["tier_1_models"] == 1
        assert summary["low_compliance_score_count"] == 1
        assert summary["monitoring_overdue_count"] == 1
        assert len(summary["risk_items"]) > 0

    def test_risk_summary_empty(self):
        reg = ModelRegistry()
        summary = reg.risk_summary()
        assert summary["total_production_models"] == 0
        assert summary["risk_items"] == []


class TestValidationRecord:
    """Test ValidationRecord."""

    def test_to_dict(self):
        v = ValidationRecord(
            validation_id="v1",
            date=_now(),
            validator="Test Validator",
            independent=True,
            result="approved",
            findings_count=2,
            conditions=["Address finding #1"],
            next_validation_date=_days_from_now(365),
        )
        d = v.to_dict()
        assert d["validation_id"] == "v1"
        assert d["independent"] is True
        assert d["result"] == "approved"
        assert d["findings_count"] == 2
        assert len(d["conditions"]) == 1


class TestMonitoringResult:
    """Test MonitoringResult."""

    def test_to_dict(self):
        r = MonitoringResult(
            date=_now(),
            monitor_type="fairness",
            passed=True,
            metrics={"di_ratio": 0.85},
            alerts=[],
        )
        d = r.to_dict()
        assert d["monitor_type"] == "fairness"
        assert d["passed"] is True
        assert d["metrics"]["di_ratio"] == 0.85


class TestModelRegistryImports:
    """Test imports from expected paths."""

    def test_import_from_governance(self):
        from attestant.governance import ModelRegistry, ModelRecord
        assert ModelRegistry is not None
        assert ModelRecord is not None

    def test_import_from_top_level(self):
        from proveit import ModelRegistry, ModelRecord
        assert ModelRegistry is not None
        assert ModelRecord is not None
