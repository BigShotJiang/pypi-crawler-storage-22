"""
Tests for HYDRA-24 persistence layer.

Tests database storage, async writing, and DAG reconstruction from stored data.

Note: Requires PostgreSQL running. Set TEST_DATABASE_URL environment variable.
Skip these tests if PostgreSQL not available.
"""

import os
import pytest
import pandas as pd
import numpy as np

# Check if persistence is available
try:
    from attestant.persistence import (
        init_database,
        drop_all_tables,
        PostgreSQLStorage,
        AsyncWriter,
        WriterConfig,
        SyncWriter,
        StoredNode,
        StoredEdge,
        reconstruct_dag,
        query_by_fingerprint,
        query_by_source,
    )
    from proveit import DAGTracker, wrap_dataframe, get_dag
    HAS_PERSISTENCE = True
except ImportError:
    HAS_PERSISTENCE = False


# Skip marker for tests that require PostgreSQL
requires_postgres = pytest.mark.skipif(
    not HAS_PERSISTENCE or not os.environ.get('TEST_DATABASE_URL'),
    reason="Persistence tests require psycopg2 and TEST_DATABASE_URL"
)


@pytest.fixture
def test_db():
    """Test database fixture - creates/drops tables for each test."""
    db_url = os.environ.get('TEST_DATABASE_URL')
    if not db_url:
        pytest.skip("TEST_DATABASE_URL not set")

    # Initialize fresh database
    init_database(db_url)

    yield db_url

    # Cleanup
    try:
        drop_all_tables(db_url, confirm=True)
    except:
        pass


@pytest.fixture
def storage(test_db):
    """PostgreSQL storage backend fixture."""
    store = PostgreSQLStorage(test_db)
    store.connect()
    yield store
    store.disconnect()


@requires_postgres
class TestDatabaseSchema:
    """Test database schema creation and initialization."""

    def test_init_database_creates_tables(self, test_db):
        """Verify all tables are created."""
        storage = PostgreSQLStorage(test_db)
        storage.connect()

        try:
            conn = storage._get_conn()
            with conn.cursor() as cur:
                # Check tables exist
                cur.execute("""
                    SELECT table_name FROM information_schema.tables
                    WHERE table_schema = 'public'
                    ORDER BY table_name
                """)
                tables = [row[0] for row in cur.fetchall()]

                assert 'dag_nodes' in tables
                assert 'dag_edges' in tables
                assert 'source_registry' in tables
                assert 'pipeline_metadata' in tables
        finally:
            storage._put_conn(conn)
            storage.disconnect()

    def test_init_database_creates_indexes(self, test_db):
        """Verify indexes are created for performance."""
        storage = PostgreSQLStorage(test_db)
        storage.connect()

        try:
            conn = storage._get_conn()
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT indexname FROM pg_indexes
                    WHERE schemaname = 'public' AND tablename = 'dag_nodes'
                """)
                indexes = [row[0] for row in cur.fetchall()]

                # Check key indexes exist
                assert any('fingerprint' in idx for idx in indexes)
                assert any('protected' in idx for idx in indexes)
        finally:
            storage._put_conn(conn)
            storage.disconnect()


@requires_postgres
class TestStorageBackend:
    """Test PostgreSQL storage backend operations."""

    def test_store_single_node(self, storage):
        """Store and retrieve a single node."""
        node = StoredNode(
            fingerprint=0x123456,
            node_type='SOURCE',
            operation='test.column',
            table_name='test',
            column_name='column',
            pair_id=0,
            is_protected=False,
            pipeline_id=None
        )

        storage.store_nodes([node])

        # Retrieve
        retrieved = storage.get_node_by_fingerprint(0x123456)
        assert retrieved is not None
        assert retrieved['fingerprint'] == 0x123456
        assert retrieved['node_type'] == 'SOURCE'
        assert retrieved['operation'] == 'test.column'

    def test_store_batch_nodes(self, storage):
        """Store multiple nodes in batch."""
        nodes = [
            StoredNode(
                fingerprint=i,
                node_type='SOURCE',
                operation=f'test.col{i}',
                pipeline_id=None
            )
            for i in range(100)
        ]

        storage.store_nodes(nodes)

        # Verify all stored
        for i in range(100):
            node = storage.get_node_by_fingerprint(i)
            assert node is not None
            assert node['fingerprint'] == i

    def test_store_edges(self, storage):
        """Store and retrieve edges."""
        # Create nodes first
        nodes = [
            StoredNode(fingerprint=0x001, node_type='SOURCE', operation='a', pipeline_id=None),
            StoredNode(fingerprint=0x002, node_type='SOURCE', operation='b', pipeline_id=None),
            StoredNode(fingerprint=0x003, node_type='BINARY', operation='add', pipeline_id=None),
        ]
        storage.store_nodes(nodes)

        # Create edges
        edges = [
            StoredEdge(parent_fingerprint=0x001, child_fingerprint=0x003, input_position=0),
            StoredEdge(parent_fingerprint=0x002, child_fingerprint=0x003, input_position=1),
        ]
        storage.store_edges(edges)

        # Retrieve child node and its edges
        child = storage.get_node_by_fingerprint(0x003)
        assert child is not None

        child_edges = storage.get_edges_for_node(child['node_id'])
        assert len(child_edges) == 2

    def test_register_source(self, storage):
        """Register and query sources."""
        storage.register_source(pair_id=42, table='users', column='age', is_protected=True)

        info = storage.get_source_info(42)
        assert info is not None
        assert info[0] == 'users'
        assert info[1] == 'age'
        assert info[2] is True  # is_protected

    def test_create_pipeline(self, storage):
        """Create pipeline execution record."""
        pipeline_id = storage.create_pipeline(
            pipeline_name='test_pipeline',
            config={'param': 'value'},
            git_commit='abc123'
        )

        assert pipeline_id is not None
        assert pipeline_id > 0

        # Complete pipeline
        storage.complete_pipeline(pipeline_id, status='completed')


@requires_postgres
class TestAsyncWriter:
    """Test async writer for non-blocking persistence."""

    def test_async_write_nodes(self, storage):
        """Write nodes asynchronously."""
        writer = AsyncWriter(storage, WriterConfig(batch_size=10, flush_interval=0.1))
        writer.start()

        try:
            # Queue writes (non-blocking)
            for i in range(50):
                node = StoredNode(
                    fingerprint=i,
                    node_type='SOURCE',
                    operation=f'col{i}',
                    pipeline_id=None
                )
                writer.write_node(node)

            # Flush to ensure all written
            assert writer.flush(timeout=5.0)

            # Verify all nodes stored
            for i in range(50):
                node = storage.get_node_by_fingerprint(i)
                assert node is not None

            # Check stats
            stats = writer.get_stats()
            assert stats['nodes_written'] >= 50
            assert stats['batches_written'] > 0

        finally:
            writer.stop()

    def test_async_write_batch(self, storage):
        """Write batch of nodes at once."""
        writer = AsyncWriter(storage)
        writer.start()

        try:
            nodes = [
                StoredNode(fingerprint=i, node_type='SOURCE', operation=f'c{i}', pipeline_id=None)
                for i in range(100)
            ]

            writer.write_nodes(nodes)
            assert writer.flush(timeout=5.0)

            stats = writer.get_stats()
            assert stats['nodes_written'] == 100

        finally:
            writer.stop()


@requires_postgres
class TestSyncWriter:
    """Test synchronous writer (for comparison)."""

    def test_sync_write_nodes(self, storage):
        """Write nodes synchronously."""
        writer = SyncWriter(storage)

        for i in range(10):
            node = StoredNode(
                fingerprint=i,
                node_type='SOURCE',
                operation=f'col{i}',
                pipeline_id=None
            )
            writer.write_node(node)

        # Verify immediately available
        for i in range(10):
            node = storage.get_node_by_fingerprint(i)
            assert node is not None


@requires_postgres
class TestDAGTrackerPersistence:
    """Test DAGTracker with persistence enabled."""

    def test_tracker_with_persistence(self, test_db):
        """DAGTracker persists nodes automatically."""
        tracker = DAGTracker(persist_to=test_db, pipeline_name='test_pipeline')

        try:
            # Create simple computation
            data = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})
            df = wrap_dataframe(data, tracker, 'test.csv')

            result = df['a'] + df['b']

            # Flush writes
            tracker.flush()

            # Verify nodes persisted
            storage = PostgreSQLStorage(test_db)
            storage.connect()

            try:
                # Should have source nodes and binary op node
                node_a = storage.get_node_by_fingerprint(result.iloc[0]._provenance)
                assert node_a is not None

            finally:
                storage.disconnect()

        finally:
            tracker.disable_persistence()

    def test_tracker_context_manager(self, test_db):
        """DAGTracker context manager flushes automatically."""
        with DAGTracker(persist_to=test_db, pipeline_name='test_context') as tracker:
            data = pd.DataFrame({'x': [1, 2, 3]})
            df = wrap_dataframe(data, tracker, 'data.csv')
            result = df['x'] * 2

        # After context exit, should be flushed
        # Verify persistence worked (would need to check database)


@requires_postgres
class TestDAGReconstruction:
    """Test reconstructing DAGs from stored data."""

    def test_reconstruct_simple_dag(self, test_db):
        """Reconstruct a simple computation DAG."""
        # First, create and persist a computation
        tracker = DAGTracker(persist_to=test_db, pipeline_name='recon_test')

        try:
            data = pd.DataFrame({'a': [10], 'b': [20]})
            df = wrap_dataframe(data, tracker, 'test.csv')

            result = df['a'] + df['b']
            fingerprint = result.iloc[0]._provenance

            tracker.flush()

        finally:
            tracker.disable_persistence()

        # Now reconstruct from database
        dag = reconstruct_dag(fingerprint, test_db)

        assert dag is not None
        assert len(dag.source_nodes) >= 2  # a and b
        assert dag.depth >= 1  # At least one operation

    def test_query_by_fingerprint(self, test_db):
        """Query node info by fingerprint."""
        tracker = DAGTracker(persist_to=test_db, pipeline_name='query_test')

        try:
            data = pd.DataFrame({'x': [5]})
            df = wrap_dataframe(data, tracker, 'data.csv')
            result = df['x'] * 3

            fingerprint = result.iloc[0]._provenance
            tracker.flush()

        finally:
            tracker.disable_persistence()

        # Query
        node = query_by_fingerprint(fingerprint, test_db)
        assert node is not None
        assert node['fingerprint'] == fingerprint

    def test_query_by_source(self, test_db):
        """Find all nodes using a specific source."""
        tracker = DAGTracker(persist_to=test_db, pipeline_name='source_query_test')

        try:
            data = pd.DataFrame({'age': [25, 30, 35]})
            df = wrap_dataframe(data, tracker, 'users.csv')

            result1 = df['age'] + 10
            result2 = df['age'] * 2

            tracker.flush()

        finally:
            tracker.disable_persistence()

        # Query all nodes using 'age' column
        nodes = query_by_source('users.csv', 'age', test_db)
        assert len(nodes) > 0


@requires_postgres
class TestPerformance:
    """Performance benchmarks for persistence."""

    def test_write_throughput(self, storage, benchmark):
        """Benchmark write throughput."""
        def write_batch():
            nodes = [
                StoredNode(fingerprint=i, node_type='SOURCE', operation=f'c{i}', pipeline_id=None)
                for i in range(1000)
            ]
            storage.store_nodes(nodes)

        if hasattr(benchmark, '__call__'):
            benchmark(write_batch)
        else:
            # If pytest-benchmark not available, just run once
            write_batch()

    def test_async_vs_sync_performance(self, storage):
        """Compare async vs sync write performance."""
        import time

        # Sync writer
        sync_writer = SyncWriter(storage)
        start = time.time()
        for i in range(100):
            node = StoredNode(fingerprint=i, node_type='SOURCE', operation=f'c{i}', pipeline_id=None)
            sync_writer.write_node(node)
        sync_time = time.time() - start

        # Async writer
        async_writer = AsyncWriter(storage, WriterConfig(batch_size=50))
        async_writer.start()
        try:
            start = time.time()
            for i in range(100, 200):
                node = StoredNode(fingerprint=i, node_type='SOURCE', operation=f'c{i}', pipeline_id=None)
                async_writer.write_node(node)
            async_writer.flush()
            async_time = time.time() - start
        finally:
            async_writer.stop()

        # Async should be faster or comparable
        print(f"Sync: {sync_time:.3f}s, Async: {async_time:.3f}s")
        # Note: May not always be faster for small batches due to overhead



class TestHostedStorage:
    """Tests for HostedStorage REST API backend (no server required)."""

    def test_instantiation(self):
        """HostedStorage can be created with required params."""
        from attestant.persistence import HostedStorage

        storage = HostedStorage(
            api_url="https://api.attestant.ai",
            api_key="test-key-123",
            tenant_id="org-456",
        )

        assert storage.api_url == "https://api.attestant.ai"
        assert storage.api_key == "test-key-123"
        assert storage.tenant_id == "org-456"
        assert storage.timeout == 30
        assert storage.batch_size == 100
        assert not storage._connected

    def test_instantiation_defaults(self):
        """HostedStorage uses sensible defaults."""
        from attestant.persistence import HostedStorage

        storage = HostedStorage(
            api_url="https://api.attestant.ai/",
            api_key="key",
        )

        assert storage.api_url == "https://api.attestant.ai"
        assert storage.tenant_id == "default"

    def test_request_builds_correct_headers(self):
        """_request includes Authorization and X-Tenant-ID headers."""
        from attestant.persistence import HostedStorage
        from unittest.mock import patch, MagicMock
        import io

        storage = HostedStorage(
            api_url="https://api.attestant.ai",
            api_key="my-secret-key",
            tenant_id="tenant-42",
        )

        mock_response = MagicMock()
        mock_response.read.return_value = b'{"ok": true}'
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("attestant.persistence.hosted_storage.urlopen", return_value=mock_response) as mock_urlopen:
            storage._request("GET", "/v1/health")

            call_args = mock_urlopen.call_args
            req = call_args[0][0]

            assert req.get_header("Authorization") == "Bearer my-secret-key"
            assert req.get_header("X-tenant-id") == "tenant-42"
            assert req.get_header("Content-type") == "application/json"
            assert req.full_url == "https://api.attestant.ai/v1/health"
            assert req.method == "GET"

    def test_store_nodes_serializes_correctly(self):
        """store_nodes sends correct JSON payload to /v1/nodes."""
        from attestant.persistence import HostedStorage
        from attestant.persistence.storage import StoredNode
        from unittest.mock import patch, MagicMock
        import json as json_mod

        storage = HostedStorage(
            api_url="https://api.attestant.ai",
            api_key="key",
            tenant_id="t1",
        )

        mock_response = MagicMock()
        mock_response.read.return_value = b'null'
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        nodes = [
            StoredNode(
                fingerprint=0xABC,
                node_type="SOURCE",
                operation="users.age",
                table_name="users",
                column_name="age",
                pair_id=1,
                is_protected=True,
                pipeline_id=7,
            ),
            StoredNode(
                fingerprint=0xDEF,
                node_type="BINARY",
                operation="add",
                pipeline_id=7,
            ),
        ]

        with patch("attestant.persistence.hosted_storage.urlopen", return_value=mock_response) as mock_urlopen:
            storage.store_nodes(nodes)

            call_args = mock_urlopen.call_args
            req = call_args[0][0]
            body = json_mod.loads(req.data.decode("utf-8"))

            assert len(body) == 2
            assert body[0]["fingerprint"] == 0xABC
            assert body[0]["node_type"] == "SOURCE"
            assert body[0]["table_name"] == "users"
            assert body[0]["is_protected"] is True
            assert body[1]["fingerprint"] == 0xDEF
            assert body[1]["operation"] == "add"

    def test_connect_disconnect_lifecycle(self):
        """connect/disconnect set _connected flag correctly."""
        from attestant.persistence import HostedStorage
        from unittest.mock import patch, MagicMock

        storage = HostedStorage(
            api_url="https://api.attestant.ai",
            api_key="key",
        )

        assert not storage._connected

        mock_response = MagicMock()
        mock_response.read.return_value = b'{"status": "ok"}'
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("attestant.persistence.hosted_storage.urlopen", return_value=mock_response):
            storage.connect()

        assert storage._connected

        storage.disconnect()
        assert not storage._connected

    def test_connect_sets_connected_on_failure(self):
        """connect sets _connected = True even if server is unreachable."""
        from attestant.persistence import HostedStorage
        from unittest.mock import patch
        from urllib.error import URLError

        storage = HostedStorage(
            api_url="https://api.attestant.ai",
            api_key="key",
        )

        with patch("attestant.persistence.hosted_storage.urlopen", side_effect=URLError("unreachable")):
            storage.connect()

        assert storage._connected

    def test_store_nodes_empty(self):
        """store_nodes with empty list is a no-op."""
        from attestant.persistence import HostedStorage
        from unittest.mock import patch

        storage = HostedStorage(api_url="https://x.dev", api_key="k")

        with patch("attestant.persistence.hosted_storage.urlopen") as mock_urlopen:
            storage.store_nodes([])
            mock_urlopen.assert_not_called()

    def test_create_pipeline_returns_id(self):
        """create_pipeline returns pipeline_id from server response."""
        from attestant.persistence import HostedStorage
        from unittest.mock import patch, MagicMock

        storage = HostedStorage(api_url="https://x.dev", api_key="k")

        mock_response = MagicMock()
        mock_response.read.return_value = b'{"pipeline_id": 42}'
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("attestant.persistence.hosted_storage.urlopen", return_value=mock_response):
            pid = storage.create_pipeline("test_pipe")

        assert pid == 42

    def test_get_stats_returns_dict(self):
        """get_stats returns parsed dict from server."""
        from attestant.persistence import HostedStorage
        from unittest.mock import patch, MagicMock

        storage = HostedStorage(api_url="https://x.dev", api_key="k")

        mock_response = MagicMock()
        mock_response.read.return_value = b'{"nodes": 100, "edges": 50}'
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("attestant.persistence.hosted_storage.urlopen", return_value=mock_response):
            stats = storage.get_stats()

        assert stats == {"nodes": 100, "edges": 50}

    def test_get_stats_returns_empty_on_error(self):
        """get_stats returns empty dict on connection error."""
        from attestant.persistence import HostedStorage
        from unittest.mock import patch
        from urllib.error import URLError

        storage = HostedStorage(api_url="https://x.dev", api_key="k")

        with patch("attestant.persistence.hosted_storage.urlopen", side_effect=URLError("fail")):
            stats = storage.get_stats()

        assert stats == {}


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
