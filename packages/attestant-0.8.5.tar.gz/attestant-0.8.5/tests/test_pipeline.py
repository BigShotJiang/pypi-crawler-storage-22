"""Tests for the loan approval pipeline."""

import pytest
import pandas as pd
import numpy as np
import sys
from pathlib import Path

# Add the python directory to the path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from examples.loan_approval.data_generator import (
    generate_applications, generate_credit_bureau,
    generate_income_verification, generate_demographics,
    generate_applicant_ids, set_seed, generate_all_data
)
from examples.loan_approval.features import (
    compute_credit_features, compute_income_features,
    compute_loan_features, compute_combined_features, get_model_features,
    prepare_training_data
)


class TestDataGeneration:
    """Tests for the mock data generator."""

    def test_generate_applicant_ids(self):
        """Should generate sequential IDs starting from 1."""
        ids = generate_applicant_ids(100)
        assert len(ids) == 100
        assert ids[0] == 1
        assert ids[-1] == 100
        assert list(ids) == list(range(1, 101))

    def test_generate_applicant_ids_small(self):
        """Works with small number of IDs."""
        ids = generate_applicant_ids(5)
        assert len(ids) == 5
        assert list(ids) == [1, 2, 3, 4, 5]

    def test_generate_applications(self):
        """Should generate valid applications."""
        set_seed(42)
        ids = generate_applicant_ids(100)
        df = generate_applications(100, ids)

        assert len(df) == 100
        assert 'applicant_id' in df.columns
        assert 'requested_amount' in df.columns
        assert 'loan_purpose' in df.columns
        assert 'property_type' in df.columns
        assert 'property_value' in df.columns

        # Amount constraints
        assert all(df['requested_amount'] >= 10000)
        assert all(df['requested_amount'] <= 500000)

        # Loan purposes should be valid
        valid_purposes = {'home', 'auto', 'education', 'business', 'personal'}
        assert set(df['loan_purpose'].unique()).issubset(valid_purposes)

    def test_generate_applications_property_values(self):
        """Home loans should have property values, others should not."""
        set_seed(42)
        ids = generate_applicant_ids(200)
        df = generate_applications(200, ids)

        home_loans = df[df['loan_purpose'] == 'home']
        other_loans = df[df['loan_purpose'] != 'home']

        # Home loans should have property values > 0
        if len(home_loans) > 0:
            assert all(home_loans['property_value'] > 0)
            assert all(home_loans['property_type'] != 'n/a')

        # Other loans should have property value = 0
        if len(other_loans) > 0:
            assert all(other_loans['property_value'] == 0)
            assert all(other_loans['property_type'] == 'n/a')

    def test_generate_credit_bureau(self):
        """Should generate valid credit data."""
        set_seed(42)
        ids = generate_applicant_ids(100)
        df = generate_credit_bureau(100, ids)

        assert len(df) == 100
        assert 'applicant_id' in df.columns
        assert 'credit_score' in df.columns
        assert 'num_accounts' in df.columns
        assert 'total_balance' in df.columns
        assert 'credit_limit' in df.columns
        assert 'delinquencies' in df.columns
        assert 'bankruptcies' in df.columns
        assert 'credit_age_months' in df.columns

        # Credit score constraints (FICO range)
        assert all(df['credit_score'] >= 300)
        assert all(df['credit_score'] <= 850)

        # Credit age constraints
        assert all(df['credit_age_months'] >= 12)
        assert all(df['credit_age_months'] <= 360)

        # Delinquencies and bankruptcies should be non-negative
        assert all(df['delinquencies'] >= 0)
        assert all(df['bankruptcies'] >= 0)

    def test_generate_credit_bureau_balance_limit_relationship(self):
        """Balance should not exceed credit limit."""
        set_seed(42)
        ids = generate_applicant_ids(100)
        df = generate_credit_bureau(100, ids)

        # Balance should be <= limit
        assert all(df['total_balance'] <= df['credit_limit'])

    def test_generate_income_verification(self):
        """Should generate valid income data."""
        set_seed(42)
        ids = generate_applicant_ids(100)
        df = generate_income_verification(100, ids)

        assert len(df) == 100
        assert 'applicant_id' in df.columns
        assert 'annual_income' in df.columns
        assert 'employment_length' in df.columns
        assert 'employer_type' in df.columns
        assert 'employment_status' in df.columns
        assert 'other_income' in df.columns
        assert 'monthly_debt_payments' in df.columns

        # Income constraints
        assert all(df['annual_income'] >= 20000)
        assert all(df['annual_income'] <= 500000)

        # Employment length constraints
        assert all(df['employment_length'] >= 0.5)
        assert all(df['employment_length'] <= 30)

        # Other income should be non-negative
        assert all(df['other_income'] >= 0)

        # Debt payments should be non-negative
        assert all(df['monthly_debt_payments'] >= 0)

    def test_generate_income_employer_types(self):
        """Employer types should be valid."""
        set_seed(42)
        ids = generate_applicant_ids(500)
        df = generate_income_verification(500, ids)

        valid_types = {'corporate', 'government', 'self_employed', 'nonprofit'}
        assert set(df['employer_type'].unique()).issubset(valid_types)

    def test_generate_income_employment_status(self):
        """Employment status should be valid."""
        set_seed(42)
        ids = generate_applicant_ids(500)
        df = generate_income_verification(500, ids)

        valid_statuses = {'full_time', 'part_time', 'contract'}
        assert set(df['employment_status'].unique()).issubset(valid_statuses)

    def test_generate_demographics(self):
        """Should generate demographic data."""
        set_seed(42)
        ids = generate_applicant_ids(100)
        df = generate_demographics(100, ids)

        assert len(df) == 100
        assert 'applicant_id' in df.columns
        assert 'age' in df.columns
        assert 'gender' in df.columns
        assert 'race' in df.columns
        assert 'zip_code' in df.columns

        # Age constraints
        assert all(df['age'] >= 21)
        assert all(df['age'] <= 80)

        # Zip code format (5 digits)
        assert all(df['zip_code'] >= 10000)
        assert all(df['zip_code'] <= 99999)

    def test_generate_demographics_gender(self):
        """Gender should be valid values."""
        set_seed(42)
        ids = generate_applicant_ids(500)
        df = generate_demographics(500, ids)

        valid_genders = {'male', 'female', 'non_binary'}
        assert set(df['gender'].unique()).issubset(valid_genders)

    def test_generate_demographics_race(self):
        """Race should be valid values."""
        set_seed(42)
        ids = generate_applicant_ids(500)
        df = generate_demographics(500, ids)

        valid_races = {'white', 'black', 'hispanic', 'asian', 'other'}
        assert set(df['race'].unique()).issubset(valid_races)

    def test_set_seed_reproducibility(self):
        """Setting seed should produce reproducible results."""
        set_seed(42)
        ids1 = generate_applicant_ids(10)
        df1 = generate_applications(10, ids1)

        set_seed(42)
        ids2 = generate_applicant_ids(10)
        df2 = generate_applications(10, ids2)

        assert list(df1['requested_amount']) == list(df2['requested_amount'])
        assert list(df1['loan_purpose']) == list(df2['loan_purpose'])

    def test_generate_all_data(self):
        """generate_all_data returns all four DataFrames."""
        apps, credit, income, demo = generate_all_data(n=50, seed=42)

        assert len(apps) == 50
        assert len(credit) == 50
        assert len(income) == 50
        assert len(demo) == 50

        # Check they share applicant_ids
        assert set(apps['applicant_id']) == set(credit['applicant_id'])
        assert set(apps['applicant_id']) == set(income['applicant_id'])
        assert set(apps['applicant_id']) == set(demo['applicant_id'])


class TestFeatureEngineering:
    """Tests for feature engineering functions."""

    @pytest.fixture
    def sample_data(self):
        """Generate sample data for testing."""
        np.random.seed(42)
        ids = generate_applicant_ids(100)
        return {
            'applications': generate_applications(100, ids),
            'credit': generate_credit_bureau(100, ids),
            'income': generate_income_verification(100, ids),
            'demographics': generate_demographics(100, ids),
        }

    def test_credit_features_columns(self, sample_data):
        """Credit features should have expected columns."""
        df = compute_credit_features(sample_data['credit'])

        expected_cols = [
            'credit_utilization', 'delinquency_rate', 'credit_age_years',
            'has_bankruptcy', 'credit_tier', 'credit_score_normalized'
        ]
        for col in expected_cols:
            assert col in df.columns, f"Missing column: {col}"

    def test_credit_features_utilization_range(self, sample_data):
        """Credit utilization should be in [0, 1] range."""
        df = compute_credit_features(sample_data['credit'])

        assert all(df['credit_utilization'] >= 0)
        assert all(df['credit_utilization'] <= 1)

    def test_credit_features_normalized_score_range(self, sample_data):
        """Normalized credit score should be in [0, 1] range."""
        df = compute_credit_features(sample_data['credit'])

        assert all(df['credit_score_normalized'] >= 0)
        assert all(df['credit_score_normalized'] <= 1)

    def test_credit_features_delinquency_rate(self, sample_data):
        """Delinquency rate should be computed correctly."""
        df = compute_credit_features(sample_data['credit'])

        assert all(df['delinquency_rate'] >= 0)

    def test_credit_features_bankruptcy_flag(self, sample_data):
        """Has bankruptcy should be 0 or 1."""
        df = compute_credit_features(sample_data['credit'])

        assert set(df['has_bankruptcy'].unique()).issubset({0, 1})

    def test_credit_features_credit_tier(self, sample_data):
        """Credit tier should be valid categories."""
        df = compute_credit_features(sample_data['credit'])

        valid_tiers = {'poor', 'fair', 'good', 'very_good', 'excellent'}
        actual_tiers = set(df['credit_tier'].dropna().unique())
        assert actual_tiers.issubset(valid_tiers)

    def test_income_features_columns(self, sample_data):
        """Income features should have expected columns."""
        df = compute_income_features(sample_data['income'])

        expected_cols = [
            'total_income', 'monthly_income', 'employment_stability',
            'income_per_year_employed', 'existing_dti',
            'is_self_employed', 'is_government', 'is_full_time'
        ]
        for col in expected_cols:
            assert col in df.columns, f"Missing column: {col}"

    def test_income_features_monthly_income_positive(self, sample_data):
        """Monthly income should be positive."""
        df = compute_income_features(sample_data['income'])

        assert all(df['monthly_income'] > 0)

    def test_income_features_employment_stability_range(self, sample_data):
        """Employment stability should be in [0, 1] range."""
        df = compute_income_features(sample_data['income'])

        assert all(df['employment_stability'] >= 0)
        assert all(df['employment_stability'] <= 1)

    def test_income_features_binary_flags(self, sample_data):
        """Binary employment flags should be 0 or 1."""
        df = compute_income_features(sample_data['income'])

        for col in ['is_self_employed', 'is_government', 'is_full_time']:
            assert set(df[col].unique()).issubset({0, 1}), f"{col} has invalid values"

    def test_income_features_total_income(self, sample_data):
        """Total income should be sum of annual and other income."""
        df = compute_income_features(sample_data['income'])

        expected_total = sample_data['income']['annual_income'] + sample_data['income']['other_income']
        assert all(df['total_income'] == expected_total)

    def test_loan_features(self, sample_data):
        """Loan features should be computed correctly."""
        income_features = compute_income_features(sample_data['income'])
        df = compute_loan_features(sample_data['applications'], income_features)

        expected_cols = [
            'loan_to_income', 'monthly_payment_estimate',
            'payment_to_income', 'ltv', 'loan_purpose_risk'
        ]
        for col in expected_cols:
            assert col in df.columns, f"Missing column: {col}"

    def test_loan_features_ltv(self, sample_data):
        """LTV should be 0 for non-home loans, positive for home loans."""
        income_features = compute_income_features(sample_data['income'])
        df = compute_loan_features(sample_data['applications'], income_features)

        # Non-home loans should have LTV = 0
        non_home = df[df['loan_purpose'] != 'home']
        if len(non_home) > 0:
            assert all(non_home['ltv'] == 0)

        # Home loans should have LTV > 0
        home_loans = df[df['loan_purpose'] == 'home']
        if len(home_loans) > 0:
            assert all(home_loans['ltv'] > 0)

    def test_loan_features_purpose_risk(self, sample_data):
        """Loan purpose risk should be mapped correctly."""
        income_features = compute_income_features(sample_data['income'])
        df = compute_loan_features(sample_data['applications'], income_features)

        # Check known mappings
        home_loans = df[df['loan_purpose'] == 'home']
        if len(home_loans) > 0:
            assert all(home_loans['loan_purpose_risk'] == 0.2)

        personal_loans = df[df['loan_purpose'] == 'personal']
        if len(personal_loans) > 0:
            assert all(personal_loans['loan_purpose_risk'] == 0.6)

    def test_combined_features(self, sample_data):
        """Combined features should include all expected columns."""
        df = compute_combined_features(
            sample_data['applications'],
            sample_data['credit'],
            sample_data['income']
        )

        expected_features = get_model_features()
        for feature in expected_features:
            assert feature in df.columns, f"Missing feature: {feature}"

    def test_combined_features_no_nulls_in_model_features(self, sample_data):
        """Model features should not have null values."""
        df = compute_combined_features(
            sample_data['applications'],
            sample_data['credit'],
            sample_data['income']
        )

        model_features = get_model_features()
        for feature in model_features:
            null_count = df[feature].isnull().sum()
            assert null_count == 0, f"Feature {feature} has {null_count} null values"

    def test_composite_risk_range(self, sample_data):
        """Composite risk should be in reasonable range."""
        df = compute_combined_features(
            sample_data['applications'],
            sample_data['credit'],
            sample_data['income']
        )

        # Composite risk is a weighted sum of factors in [0, 1]
        # So it should be roughly in [0, 1] range
        assert all(df['composite_risk'] >= 0)
        assert all(df['composite_risk'] <= 2)  # Allow some tolerance

    def test_no_demographics_in_features(self, sample_data):
        """Demographics should NOT appear in features."""
        df = compute_combined_features(
            sample_data['applications'],
            sample_data['credit'],
            sample_data['income']
        )

        protected_columns = ['race', 'gender', 'age', 'zip_code']
        for col in protected_columns:
            assert col not in df.columns, f"Protected column leaked: {col}"

    def test_no_demographics_in_model_features_list(self):
        """Model features list should not include protected attributes."""
        model_features = get_model_features()

        protected = ['race', 'gender', 'age', 'zip_code']
        for col in protected:
            assert col not in model_features, f"Protected column in model features: {col}"

    def test_get_model_features_not_empty(self):
        """Model features list should not be empty."""
        features = get_model_features()
        assert len(features) > 0

    def test_prepare_training_data(self, sample_data):
        """prepare_training_data should return X and y."""
        features = compute_combined_features(
            sample_data['applications'],
            sample_data['credit'],
            sample_data['income']
        )

        X, y = prepare_training_data(features, include_target=True)

        assert X is not None
        assert y is not None
        assert len(X) == len(y)
        assert len(X) == len(features)

        # X should only have model features
        model_features = get_model_features()
        assert list(X.columns) == model_features

    def test_prepare_training_data_no_target(self, sample_data):
        """prepare_training_data without target should return None for y."""
        features = compute_combined_features(
            sample_data['applications'],
            sample_data['credit'],
            sample_data['income']
        )

        X, y = prepare_training_data(features, include_target=False)

        assert X is not None
        assert y is None

    def test_prepare_training_data_target_binary(self, sample_data):
        """Target variable should be binary (0 or 1)."""
        features = compute_combined_features(
            sample_data['applications'],
            sample_data['credit'],
            sample_data['income']
        )

        X, y = prepare_training_data(features, include_target=True)

        assert set(y.unique()).issubset({0, 1})


class TestDataIntegrity:
    """Tests for data integrity across the pipeline."""

    def test_applicant_ids_consistent(self):
        """All generated datasets should have consistent applicant IDs."""
        apps, credit, income, demo = generate_all_data(n=100, seed=42)

        app_ids = set(apps['applicant_id'])
        credit_ids = set(credit['applicant_id'])
        income_ids = set(income['applicant_id'])
        demo_ids = set(demo['applicant_id'])

        assert app_ids == credit_ids
        assert app_ids == income_ids
        assert app_ids == demo_ids

    def test_no_duplicate_applicant_ids(self):
        """There should be no duplicate applicant IDs."""
        apps, credit, income, demo = generate_all_data(n=100, seed=42)

        for df, name in [(apps, 'applications'), (credit, 'credit'),
                         (income, 'income'), (demo, 'demographics')]:
            assert df['applicant_id'].nunique() == len(df), f"Duplicate IDs in {name}"

    def test_merge_preserves_rows(self):
        """Merging datasets should preserve row count."""
        apps, credit, income, demo = generate_all_data(n=100, seed=42)

        features = compute_combined_features(apps, credit, income)

        # Since all datasets have same applicant_ids, merge should preserve count
        assert len(features) == 100


class TestEdgeCases:
    """Tests for edge cases in data generation and feature engineering."""

    def test_single_applicant(self):
        """Pipeline should work with single applicant."""
        ids = generate_applicant_ids(1)
        apps = generate_applications(1, ids)
        credit = generate_credit_bureau(1, ids)
        income = generate_income_verification(1, ids)

        features = compute_combined_features(apps, credit, income)
        assert len(features) == 1

    def test_large_dataset(self):
        """Pipeline should handle larger datasets."""
        n = 1000
        ids = generate_applicant_ids(n)
        apps = generate_applications(n, ids)
        credit = generate_credit_bureau(n, ids)
        income = generate_income_verification(n, ids)

        features = compute_combined_features(apps, credit, income)
        assert len(features) == n

    def test_zero_credit_limit_handling(self):
        """Should handle edge case of very low credit limit."""
        # Create credit data with edge case
        credit = pd.DataFrame({
            'applicant_id': [1],
            'credit_score': [700],
            'num_accounts': [1],
            'total_balance': [0],
            'credit_limit': [1],  # Very low limit
            'delinquencies': [0],
            'bankruptcies': [0],
            'credit_age_months': [24],
        })

        features = compute_credit_features(credit)

        # Should not have NaN or inf values
        assert not features['credit_utilization'].isnull().any()
        assert not np.isinf(features['credit_utilization']).any()

    def test_zero_income_handling(self):
        """Should handle edge case of minimum income."""
        income = pd.DataFrame({
            'applicant_id': [1],
            'annual_income': [20000],  # Minimum
            'employment_length': [0.5],
            'employer_type': ['corporate'],
            'employment_status': ['full_time'],
            'other_income': [0],
            'monthly_debt_payments': [0],
        })

        features = compute_income_features(income)

        # Should not have NaN or inf values
        assert not features['monthly_income'].isnull().any()
        assert not np.isinf(features['monthly_income']).any()
        assert features['monthly_income'].iloc[0] > 0
