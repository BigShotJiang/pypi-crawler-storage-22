"""
Tests for vendor readiness, certifications, health check, data governance,
regulatory calendar, examiner package, and model card generation.

Validates the CEO/CCO compliance posture modules that make Attestant
a compelling vendor for bank CROs.
"""

import pytest
from datetime import date, datetime, timedelta, timezone


# ============================================================================
# Vendor Due Diligence
# ============================================================================


class TestVendorDueDiligencePackage:
    """Tests for VendorDueDiligencePackage."""

    def test_empty_package(self):
        from attestant.vendor import VendorDueDiligencePackage
        pkg = VendorDueDiligencePackage(
            vendor_name="Attestant AI",
            vendor_contact="compliance@attestant.ai",
        )
        d = pkg.to_dict()
        assert d["vendor_name"] == "Attestant AI"
        assert d["compliance_score"] == 0.0
        assert d["summary"]["total_controls"] == 0

    def test_add_controls(self):
        from attestant.vendor import (
            VendorDueDiligencePackage, SecurityControl, SecurityDomain,
        )
        pkg = VendorDueDiligencePackage()
        pkg.add_control(SecurityControl(
            domain=SecurityDomain.INFORMATION_SECURITY,
            control_id="IS-001",
            title="Encryption at Rest",
            description="AES-256 encryption.",
            implemented=True,
            evidence="SOC 2 §4.2",
            frameworks=["SOC 2", "ISO 27001"],
        ))
        pkg.add_control(SecurityControl(
            domain=SecurityDomain.ACCESS_CONTROL,
            control_id="AC-001",
            title="MFA",
            description="Multi-factor authentication.",
            implemented=False,
        ))
        assert pkg.compliance_score == 0.5
        assert len(pkg.gaps) == 1
        assert pkg.gaps[0]["id"] == "AC-001"

    def test_generate_tprm_questionnaire(self):
        from attestant.vendor import VendorDueDiligencePackage
        pkg = VendorDueDiligencePackage()
        responses = pkg.generate_tprm_questionnaire()
        assert len(responses) >= 20  # At least 20 standard questions
        # All should be non-compliant initially
        assert all(not r.compliant for r in responses)

    def test_domain_scores(self):
        from attestant.vendor import (
            VendorDueDiligencePackage, SecurityControl, SecurityDomain,
        )
        pkg = VendorDueDiligencePackage()
        pkg.add_control(SecurityControl(
            domain=SecurityDomain.INFORMATION_SECURITY,
            control_id="IS-001",
            title="Encryption",
            description="AES-256.",
            implemented=True,
        ))
        pkg.add_control(SecurityControl(
            domain=SecurityDomain.INFORMATION_SECURITY,
            control_id="IS-002",
            title="TLS",
            description="TLS 1.2+.",
            implemented=True,
        ))
        pkg.add_control(SecurityControl(
            domain=SecurityDomain.ACCESS_CONTROL,
            control_id="AC-001",
            title="MFA",
            description="MFA.",
            implemented=False,
        ))
        scores = pkg.domain_scores
        assert scores["information_security"] == 1.0
        assert scores["access_control"] == 0.0

    def test_tprm_response_compliant(self):
        from attestant.vendor import (
            VendorDueDiligencePackage, TPRMResponse, SecurityDomain,
        )
        pkg = VendorDueDiligencePackage()
        pkg.add_response(TPRMResponse(
            question_id="GOV-001",
            question="Info sec policy?",
            domain=SecurityDomain.GOVERNANCE,
            response="Yes, approved annually.",
            compliant=True,
        ))
        pkg.add_response(TPRMResponse(
            question_id="GOV-002",
            question="CISO?",
            domain=SecurityDomain.GOVERNANCE,
            response="No CISO.",
            compliant=False,
        ))
        assert pkg.compliance_score == 0.5

    def test_serialization(self):
        from attestant.vendor import VendorDueDiligencePackage
        pkg = VendorDueDiligencePackage(vendor_name="Test")
        pkg.generate_tprm_questionnaire()
        d = pkg.to_dict()
        assert "vendor_name" in d
        assert "controls" in d
        assert "questionnaire_responses" in d
        assert "gaps" in d
        assert "summary" in d
        assert "domain_scores" in d


# ============================================================================
# Certification Tracker
# ============================================================================


class TestCertificationTracker:
    """Tests for CertificationTracker."""

    def test_empty_tracker(self):
        from attestant.vendor import CertificationTracker
        tracker = CertificationTracker()
        assert len(tracker.certifications) == 0
        assert tracker.to_dict()["summary"]["total"] == 0

    def test_active_certification(self):
        from attestant.vendor import Certification, CertificationTracker, CertificationStatus
        tracker = CertificationTracker()
        tracker.add(Certification(
            name="SOC 2 Type II",
            issuing_body="Deloitte",
            issue_date=date.today() - timedelta(days=30),
            expiration_date=date.today() + timedelta(days=335),
        ))
        assert len(tracker.active) == 1
        assert tracker.certifications[0].status == CertificationStatus.ACTIVE

    def test_expiring_soon(self):
        from attestant.vendor import Certification, CertificationTracker, CertificationStatus
        tracker = CertificationTracker()
        tracker.add(Certification(
            name="ISO 27001",
            issuing_body="BSI",
            issue_date=date.today() - timedelta(days=300),
            expiration_date=date.today() + timedelta(days=30),
            renewal_lead_days=90,
        ))
        assert len(tracker.expiring_soon) == 1
        assert tracker.certifications[0].status == CertificationStatus.EXPIRING_SOON

    def test_expired(self):
        from attestant.vendor import Certification, CertificationTracker, CertificationStatus
        tracker = CertificationTracker()
        tracker.add(Certification(
            name="PCI DSS",
            issue_date=date.today() - timedelta(days=400),
            expiration_date=date.today() - timedelta(days=30),
        ))
        assert len(tracker.expired) == 1
        alerts = tracker.expiration_alerts()
        assert len(alerts) == 1
        assert alerts[0]["severity"] == "critical"

    def test_planned_certification(self):
        from attestant.vendor import Certification, CertificationStatus
        cert = Certification(name="ISO 42001")
        assert cert.status == CertificationStatus.PLANNED

    def test_remove_certification(self):
        from attestant.vendor import Certification, CertificationTracker
        tracker = CertificationTracker()
        tracker.add(Certification(name="Test Cert", issue_date=date.today()))
        assert tracker.remove("Test Cert") is True
        assert tracker.remove("Nonexistent") is False
        assert len(tracker.certifications) == 0

    def test_get_by_name(self):
        from attestant.vendor import Certification, CertificationTracker
        tracker = CertificationTracker()
        tracker.add(Certification(name="SOC 2", issue_date=date.today()))
        assert tracker.get("SOC 2") is not None
        assert tracker.get("Missing") is None

    def test_compliance_posture(self):
        from attestant.vendor import Certification, CertificationTracker
        tracker = CertificationTracker()
        tracker.add(Certification(
            name="SOC 2",
            issue_date=date.today() - timedelta(days=30),
            expiration_date=date.today() + timedelta(days=300),
        ))
        tracker.add(Certification(
            name="ISO 27001",
            issue_date=date.today() - timedelta(days=400),
            expiration_date=date.today() - timedelta(days=10),
        ))
        posture = tracker.compliance_posture
        assert posture["active"] == 1
        assert posture["expired"] == 1


# ============================================================================
# Platform Health Check
# ============================================================================


class TestPlatformHealthCheck:
    """Tests for PlatformHealthCheck."""

    def test_empty_health_check(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        assert hc.overall_score == 0.0
        assert hc.overall_status == "fail"

    def test_compliance_engines_full_coverage(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_compliance_engines(
            engines_configured=["ecoa", "sr117", "eu_ai_act", "colorado_ai_act", "nyc_ll144"],
        )
        assert result.score == 1.0
        assert result.status == "pass"

    def test_compliance_engines_partial(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_compliance_engines(
            engines_configured=["ecoa", "sr117"],
        )
        assert result.score < 1.0
        assert len(result.findings) > 0

    def test_fairness_monitoring_full(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_fairness_monitoring(
            enabled=True,
            protected_attributes=["race", "sex", "age"],
            monitoring_frequency="monthly",
            has_intersectional=True,
        )
        assert result.score == 1.0

    def test_fairness_monitoring_disabled(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_fairness_monitoring(enabled=False)
        assert result.score == 0.0
        assert result.status == "fail"

    def test_decision_logging(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_decision_logging(
            enabled=True, format="jsonl", retention_days=760,
        )
        assert result.score == 1.0

    def test_decision_logging_short_retention(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_decision_logging(
            enabled=True, format="jsonl", retention_days=365,
        )
        assert result.score < 1.0
        assert any("1002.12" in f for f in result.findings)

    def test_certifications_check(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_certifications(
            active=["SOC 2 Type II", "ISO 27001"],
            expiring_soon=[],
            expired=[],
        )
        assert result.status == "pass"

    def test_data_governance(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_data_governance(
            classification_policy=True,
            pii_detection_enabled=True,
            retention_policy=True,
            lineage_tracking=True,
        )
        assert result.score == 1.0

    def test_drift_monitoring(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_drift_monitoring(
            enabled=True, frequency="monthly",
            alert_thresholds_set=True, revalidation_triggers=True,
        )
        assert result.score >= 0.9

    def test_model_inventory(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_model_inventory(
            models_registered=10, models_with_hash=10,
            models_with_tier=10, models_with_owner=10,
        )
        assert result.score == 1.0

    def test_model_inventory_empty(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_model_inventory(models_registered=0)
        assert result.score == 0.0

    def test_generate_report(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        hc.check_compliance_engines(
            engines_configured=["ecoa", "sr117", "eu_ai_act", "colorado_ai_act", "nyc_ll144"],
        )
        hc.check_certifications(active=["SOC 2 Type II", "ISO 27001"])
        report = hc.generate_report()
        assert report["overall_score"] > 0
        assert report["summary"]["dimensions_checked"] == 2

    def test_documentation_check(self):
        from attestant.vendor import PlatformHealthCheck
        hc = PlatformHealthCheck()
        result = hc.check_documentation(
            model_cards_generated=True,
            validation_reports=True,
            fairness_reports=True,
            compliance_reports=True,
        )
        assert result.score == 1.0


# ============================================================================
# PII Detection & Data Classification
# ============================================================================


class TestPIIDetector:
    """Tests for PIIDetector."""

    def test_detect_ssn(self):
        from attestant.governance import PIIDetector, DataClassification
        detector = PIIDetector()
        result = detector.classify_column("ssn")
        assert result.classification == DataClassification.RESTRICTED
        assert result.confidence == 1.0

    def test_detect_name(self):
        from attestant.governance import PIIDetector, DataClassification
        detector = PIIDetector()
        result = detector.classify_column("applicant_name")
        assert result.classification == DataClassification.CONFIDENTIAL

    def test_detect_race(self):
        from attestant.governance import PIIDetector, PIICategory
        detector = PIIDetector()
        result = detector.classify_column("race")
        assert PIICategory.PROTECTED_ATTRIBUTE in result.pii_categories

    def test_detect_credit_score(self):
        from attestant.governance import PIIDetector, PIICategory
        detector = PIIDetector()
        result = detector.classify_column("credit_score")
        assert PIICategory.FINANCIAL in result.pii_categories

    def test_detect_medical(self):
        from attestant.governance import PIIDetector, PIICategory
        detector = PIIDetector()
        result = detector.classify_column("diagnosis_code")
        assert PIICategory.HEALTH in result.pii_categories

    def test_non_pii_column(self):
        from attestant.governance import PIIDetector, DataClassification
        detector = PIIDetector()
        result = detector.classify_column("feature_42")
        assert result.classification == DataClassification.INTERNAL
        assert len(result.pii_categories) == 0

    def test_classify_multiple_columns(self):
        from attestant.governance import PIIDetector
        detector = PIIDetector()
        results = detector.classify_columns(["ssn", "name", "score", "race"])
        assert len(results) == 4

    def test_restricted_columns(self):
        from attestant.governance import PIIDetector
        detector = PIIDetector()
        restricted = detector.restricted_columns(
            ["ssn", "name", "credit_score", "race", "feature_1"]
        )
        assert "ssn" in restricted
        assert "race" in restricted
        assert "feature_1" not in restricted

    def test_has_pii(self):
        from attestant.governance import PIIDetector
        detector = PIIDetector()
        assert detector.has_pii(["ssn", "name"])
        assert not detector.has_pii(["feature_1", "feature_2"])

    def test_generate_report(self):
        from attestant.governance import PIIDetector
        detector = PIIDetector()
        report = detector.generate_report(["ssn", "name", "age", "loan_amount"])
        assert report["total_columns"] == 4
        assert report["columns_with_pii"] > 0
        assert "by_classification" in report
        assert "by_pii_category" in report

    def test_sogi_detection(self):
        from attestant.governance import PIIDetector, PIICategory
        detector = PIIDetector()
        result = detector.classify_column("sexual_orientation")
        assert PIICategory.PROTECTED_ATTRIBUTE in result.pii_categories

    def test_email_detection(self):
        from attestant.governance import PIIDetector, PIICategory
        detector = PIIDetector()
        result = detector.classify_column("email_address")
        assert PIICategory.QUASI_IDENTIFIER in result.pii_categories

    def test_pregnancy_detection(self):
        from attestant.governance import PIIDetector, PIICategory
        detector = PIIDetector()
        result = detector.classify_column("pregnancy_status")
        assert PIICategory.PROTECTED_ATTRIBUTE in result.pii_categories


# ============================================================================
# Retention Policy Engine
# ============================================================================


class TestRetentionPolicyEngine:
    """Tests for RetentionPolicyEngine."""

    def test_default_policies(self):
        from attestant.governance import RetentionPolicyEngine
        engine = RetentionPolicyEngine()
        assert len(engine.policies) >= 7

    def test_ecoa_under_retention(self):
        from attestant.governance import RetentionPolicyEngine
        engine = RetentionPolicyEngine()
        violations = engine.check_retention(
            data_category="credit_decisions",
            created_date=date.today() - timedelta(days=100),
            deleted_date=date.today(),  # only 100 days
        )
        assert len(violations) > 0
        assert any(v.violation_type == "under_retention" for v in violations)
        assert any(v.severity == "critical" for v in violations)

    def test_ecoa_proper_retention(self):
        from attestant.governance import RetentionPolicyEngine
        engine = RetentionPolicyEngine()
        violations = engine.check_retention(
            data_category="credit_decisions",
            created_date=date.today() - timedelta(days=800),
            deleted_date=date.today(),  # 800 days > 760
        )
        under = [v for v in violations if v.violation_type == "under_retention"]
        assert len(under) == 0

    def test_investigation_hold(self):
        from attestant.governance import RetentionPolicyEngine
        engine = RetentionPolicyEngine()
        violations = engine.check_retention(
            data_category="credit_decisions",
            created_date=date.today() - timedelta(days=800),
            deleted_date=date.today(),
            investigation_pending=True,
        )
        assert len(violations) > 0
        assert any("investigation" in v.remediation.lower() for v in violations)

    def test_custom_policy(self):
        from attestant.governance import RetentionPolicyEngine, RetentionPolicy
        engine = RetentionPolicyEngine()
        engine.add_policy(RetentionPolicy(
            name="Custom Policy",
            regulation="Internal",
            citation="Internal §1",
            min_retention_days=365,
            data_categories=["custom_data"],
        ))
        violations = engine.check_retention(
            data_category="custom_data",
            created_date=date.today() - timedelta(days=100),
            deleted_date=date.today(),
        )
        assert len(violations) > 0

    def test_no_applicable_policy(self):
        from attestant.governance import RetentionPolicyEngine
        engine = RetentionPolicyEngine()
        violations = engine.check_retention(
            data_category="unknown_category",
            created_date=date.today() - timedelta(days=10),
            deleted_date=date.today(),
        )
        assert len(violations) == 0

    def test_generate_report(self):
        from attestant.governance import RetentionPolicyEngine
        engine = RetentionPolicyEngine()
        report = engine.generate_report()
        assert report["total_policies"] >= 7
        assert "by_regulation" in report

    def test_get_policies_for_category(self):
        from attestant.governance import RetentionPolicyEngine
        engine = RetentionPolicyEngine()
        policies = engine.get_policies_for_category("credit_decisions")
        assert len(policies) >= 1
        assert any("ECOA" in p.regulation for p in policies)


# ============================================================================
# Regulatory Calendar
# ============================================================================


class TestRegulatoryCalendar:
    """Tests for RegulatoryCalendar."""

    def test_default_deadlines(self):
        from attestant.governance import RegulatoryCalendar
        cal = RegulatoryCalendar()
        assert len(cal.deadlines) >= 5

    def test_by_regulation(self):
        from attestant.governance import RegulatoryCalendar
        cal = RegulatoryCalendar()
        eu = cal.by_regulation("EU AI Act")
        assert len(eu) >= 2

    def test_add_custom_deadline(self):
        from attestant.governance import RegulatoryCalendar, RegulatoryDeadline
        cal = RegulatoryCalendar()
        cal.add(RegulatoryDeadline(
            name="Custom Filing",
            regulation="Internal",
            deadline_date=date.today() + timedelta(days=30),
            description="File quarterly report.",
        ))
        assert any(d.name == "Custom Filing" for d in cal.deadlines)

    def test_urgency_levels(self):
        from attestant.governance import RegulatoryCalendar, RegulatoryDeadline, DeadlineUrgency
        cal = RegulatoryCalendar()
        # Add an overdue deadline
        cal.add(RegulatoryDeadline(
            name="Overdue Item",
            regulation="Test",
            deadline_date=date.today() - timedelta(days=10),
            description="Already passed.",
        ))
        overdue = cal.overdue()
        assert len(overdue) >= 1
        assert overdue[0].urgency == DeadlineUrgency.OVERDUE

    def test_upcoming(self):
        from attestant.governance import RegulatoryCalendar, RegulatoryDeadline
        cal = RegulatoryCalendar()
        cal.add(RegulatoryDeadline(
            name="Soon",
            regulation="Test",
            deadline_date=date.today() + timedelta(days=15),
            description="Coming soon.",
        ))
        upcoming = cal.upcoming(days=30)
        assert any(d.name == "Soon" for d in upcoming)

    def test_generate_report(self):
        from attestant.governance import RegulatoryCalendar
        cal = RegulatoryCalendar()
        report = cal.generate_report()
        assert "total_deadlines" in report
        assert "by_urgency" in report
        assert "by_regulation" in report
        assert "all_deadlines" in report


# ============================================================================
# Model Card Generator
# ============================================================================


class TestModelCardGenerator:
    """Tests for ModelCardGenerator."""

    def test_generate_empty_card(self):
        from attestant.examiner import ModelCardGenerator
        gen = ModelCardGenerator()
        card = gen.generate()
        d = card.to_dict()
        assert "model_details" in d
        assert "intended_use" in d
        assert "metrics" in d

    def test_generate_with_metadata(self):
        from attestant.examiner import ModelCardGenerator
        gen = ModelCardGenerator()
        card = gen.generate(
            model_metadata={
                "name": "Credit Model v3",
                "version": "3.0",
                "type": "XGBoost",
                "owner": "MRM Team",
                "risk_tier": "critical",
            },
        )
        assert card.model_name == "Credit Model v3"
        assert card.risk_tier == "critical"
        assert len(card.ethical_considerations) > 0  # auto-generated for critical

    def test_generate_with_fairness(self):
        from attestant.examiner import ModelCardGenerator
        gen = ModelCardGenerator()
        card = gen.generate(
            fairness_results={
                "disparate_impact": {"race": 0.85, "sex": 0.92},
                "proxy_detected": ["zip_code"],
            },
        )
        assert "race" in card.disparate_impact_results
        assert "zip_code" in card.proxy_detection_results

    def test_generate_with_compliance(self):
        from attestant.examiner import ModelCardGenerator
        gen = ModelCardGenerator()
        card = gen.generate(
            compliance_results={
                "ECOA / Reg B": "PASS",
                "SR 11-7": "PASS",
            },
        )
        assert card.compliance_status["ECOA / Reg B"] == "PASS"

    def test_to_markdown(self):
        from attestant.examiner import ModelCardGenerator
        gen = ModelCardGenerator()
        card = gen.generate(
            model_metadata={
                "name": "Test Model",
                "version": "1.0",
                "type": "LogisticRegression",
                "risk_tier": "high",
                "metrics": {"AUC": 0.82, "KS": 0.35},
            },
            fairness_results={
                "disparate_impact": {"race": 0.85},
            },
        )
        md = card.to_markdown()
        assert "# Model Card: Test Model" in md
        assert "AUC" in md
        assert "0.85" in md

    def test_generate_with_dag_metadata(self):
        from attestant.examiner import ModelCardGenerator
        gen = ModelCardGenerator()
        card = gen.generate(
            dag_metadata={
                "source_tables": ["applications", "bureau"],
                "feature_count": 42,
                "depth": 5,
            },
        )
        assert len(card.relevant_factors) == 3
        assert any("applications" in f for f in card.relevant_factors)

    def test_generate_with_training_metadata(self):
        from attestant.examiner import ModelCardGenerator
        gen = ModelCardGenerator()
        card = gen.generate(
            training_metadata={
                "description": "Historical loan applications 2020-2024",
                "size": 500000,
                "sources": ["internal_db", "bureau_api"],
            },
        )
        assert card.training_data_size == 500000
        assert len(card.training_data_sources) == 2


# ============================================================================
# Examiner Package
# ============================================================================


class TestExaminerPackage:
    """Tests for ExaminerPackage."""

    def test_empty_package(self):
        from attestant.examiner import ExaminerPackage
        pkg = ExaminerPackage(
            institution_name="Acme Bank",
            examination_type="fair_lending",
            prepared_by="Jane Smith",
        )
        bundle = pkg.generate()
        assert bundle["package_metadata"]["institution_name"] == "Acme Bank"
        assert bundle["summary"]["total_sections"] == 0

    def test_add_compliance_results(self):
        from attestant.examiner import ExaminerPackage
        pkg = ExaminerPackage()
        pkg.add_compliance_results({
            "results": [{
                "regulation_name": "ECOA / Reg B",
                "passed": True,
                "findings": [{"severity": "INFO", "description": "All good"}],
                "citations": ["12 CFR 1002"],
            }],
        })
        bundle = pkg.generate()
        assert bundle["summary"]["total_sections"] == 1
        assert bundle["summary"]["complete"] == 1

    def test_add_model_card(self):
        from attestant.examiner import ExaminerPackage, ModelCardGenerator
        gen = ModelCardGenerator()
        card = gen.generate(model_metadata={"name": "Test Model"})
        pkg = ExaminerPackage()
        pkg.add_model_card(card.to_dict())
        bundle = pkg.generate()
        assert any("Model Card" in s["title"] for s in bundle["all_sections"])

    def test_completeness_score(self):
        from attestant.examiner import ExaminerPackage, ExaminerSection
        pkg = ExaminerPackage()
        pkg.add_section(ExaminerSection(
            title="Complete", category="test", status="complete",
        ))
        pkg.add_section(ExaminerSection(
            title="Missing", category="test", status="missing",
        ))
        assert pkg.completeness_score == 0.5

    def test_coverage_by_category(self):
        from attestant.examiner import ExaminerPackage
        pkg = ExaminerPackage()
        pkg.add_compliance_results({
            "results": [
                {"regulation_name": "ECOA / Reg B", "passed": True, "findings": [], "citations": []},
                {"regulation_name": "SR 11-7", "passed": True, "findings": [], "citations": []},
            ],
        })
        coverage = pkg.coverage_by_category
        assert "fair_lending" in coverage
        assert "model_risk" in coverage

    def test_add_certifications(self):
        from attestant.examiner import ExaminerPackage
        pkg = ExaminerPackage()
        pkg.add_certifications({"certifications": [{"name": "SOC 2"}]})
        bundle = pkg.generate()
        assert any("Certification" in s["title"] for s in bundle["all_sections"])

    def test_add_data_governance(self):
        from attestant.examiner import ExaminerPackage
        pkg = ExaminerPackage()
        pkg.add_data_governance({"classification_policy": True})
        bundle = pkg.generate()
        assert any("Data Governance" in s["title"] for s in bundle["all_sections"])

    def test_add_retention_report(self):
        from attestant.examiner import ExaminerPackage
        pkg = ExaminerPackage()
        pkg.add_retention_report({"policies": []})
        bundle = pkg.generate()
        assert any("Retention" in s["title"] for s in bundle["all_sections"])

    def test_full_package(self):
        """Integration test: assemble a realistic examiner package."""
        from attestant.examiner import ExaminerPackage, ModelCardGenerator

        pkg = ExaminerPackage(
            institution_name="Test Bank",
            examination_type="comprehensive",
            prepared_by="CCO",
        )

        # Compliance
        pkg.add_compliance_results({
            "results": [
                {"regulation_name": "ECOA / Reg B", "passed": True, "findings": [{"severity": "INFO"}], "citations": ["12 CFR 1002"]},
                {"regulation_name": "SR 11-7", "passed": True, "findings": [], "citations": ["SR 11-7 §3"]},
                {"regulation_name": "EU AI Act", "passed": False, "findings": [{"severity": "CRITICAL"}], "citations": ["Article 9"]},
            ],
        })

        # Model card
        gen = ModelCardGenerator()
        card = gen.generate(
            model_metadata={"name": "Credit Model", "risk_tier": "critical"},
            fairness_results={"disparate_impact": {"race": 0.85}},
        )
        pkg.add_model_card(card.to_dict())

        # Model inventory
        pkg.add_model_inventory([
            {"name": "Credit Model", "risk_tier": "critical", "hash": "abc123"},
        ])

        # Certifications
        pkg.add_certifications({"certifications": [{"name": "SOC 2 Type II"}]})

        # Data governance
        pkg.add_data_governance({"columns_classified": 42})

        bundle = pkg.generate()
        assert bundle["summary"]["total_sections"] >= 6
        assert len(bundle["regulatory_references"]) > 0
        assert bundle["package_metadata"]["completeness_score"] > 0


# ============================================================================
# Integration: Top-level imports
# ============================================================================


class TestTopLevelImports:
    """Verify all new modules are importable from top-level attestant."""

    def test_vendor_imports(self):
        from proveit import (
            VendorDueDiligencePackage,
            CertificationTracker,
            PlatformHealthCheck,
        )
        assert VendorDueDiligencePackage is not None
        assert CertificationTracker is not None
        assert PlatformHealthCheck is not None

    def test_governance_imports(self):
        from proveit import (
            PIIDetector,
            RetentionPolicyEngine,
            RegulatoryCalendar,
        )
        assert PIIDetector is not None
        assert RetentionPolicyEngine is not None
        assert RegulatoryCalendar is not None

    def test_examiner_imports(self):
        from proveit import ExaminerPackage, ModelCardGenerator
        assert ExaminerPackage is not None
        assert ModelCardGenerator is not None


# ============================================================================
# Integration: End-to-end CCO workflow
# ============================================================================


class TestCCOWorkflow:
    """End-to-end test: CCO preparing for regulatory examination."""

    def test_full_cco_workflow(self):
        """Simulate a CCO preparing an institution for examination."""
        from attestant.vendor import (
            VendorDueDiligencePackage, SecurityControl, SecurityDomain,
            CertificationTracker, Certification,
            PlatformHealthCheck,
        )
        from attestant.governance import (
            PIIDetector, RetentionPolicyEngine, RegulatoryCalendar,
        )
        from attestant.examiner import ExaminerPackage, ModelCardGenerator

        # Step 1: Vendor due diligence
        vendor_pkg = VendorDueDiligencePackage(
            vendor_name="Attestant AI",
            vendor_contact="compliance@attestant.ai",
        )
        vendor_pkg.add_control(SecurityControl(
            domain=SecurityDomain.INFORMATION_SECURITY,
            control_id="IS-001",
            title="Encryption at Rest",
            description="AES-256.",
            implemented=True,
        ))
        vendor_pkg.generate_tprm_questionnaire()

        # Step 2: Certification tracking
        cert_tracker = CertificationTracker()
        cert_tracker.add(Certification(
            name="SOC 2 Type II",
            issue_date=date.today() - timedelta(days=30),
            expiration_date=date.today() + timedelta(days=335),
        ))

        # Step 3: Health check
        health = PlatformHealthCheck()
        health.check_compliance_engines(
            engines_configured=["ecoa", "sr117", "eu_ai_act", "colorado_ai_act", "nyc_ll144"],
        )
        health.check_certifications(active=["SOC 2 Type II"])
        health.check_fairness_monitoring(
            enabled=True, protected_attributes=["race", "sex", "age"],
            monitoring_frequency="monthly", has_intersectional=True,
        )
        health.check_decision_logging(enabled=True, format="jsonl", retention_days=760)
        health.check_data_governance(
            classification_policy=True, pii_detection_enabled=True,
            retention_policy=True, lineage_tracking=True,
        )

        health_report = health.generate_report()
        assert health_report["overall_score"] >= 0.7

        # Step 4: PII detection
        pii = PIIDetector()
        pii_report = pii.generate_report(["ssn", "name", "credit_score", "race"])
        assert pii_report["columns_with_pii"] > 0

        # Step 5: Retention check
        retention = RetentionPolicyEngine()
        violations = retention.check_retention(
            data_category="credit_decisions",
            created_date=date.today() - timedelta(days=800),
        )

        # Step 6: Regulatory calendar
        cal = RegulatoryCalendar()
        cal_report = cal.generate_report()

        # Step 7: Model card
        gen = ModelCardGenerator()
        card = gen.generate(
            model_metadata={"name": "Credit Model", "risk_tier": "critical"},
            fairness_results={"disparate_impact": {"race": 0.85}},
            compliance_results={"ECOA / Reg B": "PASS"},
        )

        # Step 8: Assemble examiner package
        exam_pkg = ExaminerPackage(
            institution_name="Test Bank",
            examination_type="comprehensive",
            prepared_by="CCO",
        )
        exam_pkg.add_model_card(card.to_dict())
        exam_pkg.add_certifications(cert_tracker.to_dict())
        exam_pkg.add_data_governance(pii_report)
        exam_pkg.add_retention_report(retention.generate_report())
        exam_pkg.add_regulatory_calendar(cal_report)

        bundle = exam_pkg.generate()
        assert bundle["summary"]["total_sections"] >= 5
        assert bundle["package_metadata"]["completeness_score"] > 0
