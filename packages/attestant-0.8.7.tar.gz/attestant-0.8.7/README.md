# Attestant

Cryptographically provable AI compliance for banks. Tamper-proof data provenance tracking, algorithmic fairness analysis, automated compliance documentation, and deployment gating for regulated ML pipelines.

```
pip install attestant
```

## Quick Start

### One-Line Fairness Analysis (no API key needed)

```python
import attestant

report = attestant.analyze(
    model="credit_model.pkl",
    data="applications.csv",
    protected=["race", "sex", "age"],
    industry="lending",
)
report.save("fairness_report.pdf")
```

### Provenance Tracking

```python
import attestant

attestant.configure(api_key="pvt_live_...")

apps = attestant.wrap(apps_df, "applications.csv", protected=["zip_code"])
credit = attestant.wrap(credit_df, "credit_bureau.csv")

df = apps.merge(credit, on="applicant_id")
risk_score = df["balance"] / df["limit"]

dag = attestant.get_dag_simple(risk_score)
print(dag.source_nodes)
# Data is persisted automatically
```

### Fairness Analysis

```python
from attestant.fairness import FairLensEngine, FairLensConfig

config = FairLensConfig(
    protected_columns=["race", "gender", "age"],
    industry="lending",
)
engine = FairLensEngine(config=config)
results = engine.analyze(
    model=model, X_train=X_train, y_train=y_train,
    X_test=X_test, y_test=y_test, protected_data=prot_test,
)
print(results.disparate_impact_results)
```

### Deployment Gate

```python
from attestant.deployment import DeploymentGate

gate = DeploymentGate()
result = gate.validate_deployment(
    model=model,
    model_name="credit_scoring_v2",
    X_train=X_train,
    y_train=y_train,
    X_test=X_test,
    y_test=y_test,
    protected_data=protected_df,
    protected_columns=["race", "sex", "age"],
)
if not result.deployment_approved:
    print(result.blocking_findings)
```

### Compliance Documentation

```python
from attestant.docs import AutoDocEngine, TemplateType, ModelMetadata

engine = AutoDocEngine()
report = engine.generate(
    template=TemplateType.SR_11_7,
    model_metadata=ModelMetadata(
        name="Risk Model v2",
        version="2.1.0",
        model_type="XGBoost",
    ),
)
report.save("sr117_report.md")
```

## CLI

```bash
attestant fairness analyze --model m.pkl --data d.csv --protected race,sex --industry lending
attestant docs generate --template sr11-7 --model metadata.json
attestant docs templates
attestant dashboard
```

## Architecture

```
              attestant.configure(api_key="...")
                         |
    +--------------------+--------------------+
    |                    |                    |
  wrap(df)         FairLensEngine      ComplianceScorer
    |                    |                    |
 DAGTracker        DI / Proxy / LDA    SR 11-7 / ECOA / EU AI Act
    |                    |                    |
 fingerprints       fairness_results    compliance_report
    |                    |                    |
    +--------+-----------+--------------------+
             |
      DeploymentGate  ------>  Approved / Blocked
             |
      AsyncWriter  ---------> PostgreSQL / S3
             |
      Dashboard Sync  ------> Admin + Client Dashboards
```

## Modules

| Module | Description |
|--------|-------------|
| `attestant` | Core provenance DAG engine with 24-bit tamper-proof fingerprints and Merkle tree anchoring |
| `attestant.fairness` | Disparate impact analysis, proxy detection, LDA search, adverse action reason codes |
| `attestant.compliance` | SR 11-7, ECOA / Reg B, EU AI Act, Colorado AI Act, NYC Local Law 144 engines |
| `attestant.deployment` | Hard deployment gate that blocks non-compliant models, fairness regression testing |
| `attestant.docs` | Auto-generated SR 11-7, EU AI Act, Model Card, ECOA, GDPR, NIST AI RMF documents |
| `attestant.persistence` | PostgreSQL, S3, DuckDB, hosted HTTP storage backends with async writer |
| `attestant.dashboard` | Admin dashboard (platform-wide) and client dashboard (per-tenant compliance portal) |
| `attestant.api` | REST API server with pipeline sync, provenance storage, and orchestration |
| `attestant.governance` | Model registry, PII detection, retention policies, regulatory calendar |
| `attestant.vendor` | Third-party risk management, SOC 2 / ISO 27001 certification tracking |
| `attestant.examiner` | Exam preparation packages and model card generation |

## Compliance Engines

Each engine returns a `ComplianceReport` with regulation-specific findings, severity levels, regulatory citations, and remediation guidance.

| Engine | Regulation | Key Checks |
|--------|-----------|------------|
| SR 11-7 | OCC 2011-12 | Model validation, ongoing monitoring, documentation |
| ECOA | Reg B (12 CFR 1002) | Disparate impact, adverse action notices, four-fifths rule |
| EU AI Act | Regulation (EU) 2024/1689 | Risk classification, transparency, human oversight |
| Colorado | SB 24-205 | Algorithmic discrimination, impact assessments |
| NYC LL144 | Local Law 144 | Automated employment decision tools, bias audits |

## Dashboards

Two Flask-based dashboards connect to Aurora PostgreSQL in production.

**Admin Dashboard** (port 5004) — Platform-wide view for Attestant operators:
- System health, client directory, alert management
- Cross-tenant compliance scoring, fairness analysis, pipeline monitoring
- Revenue tracking and model inventory

**Client Dashboard** (port 5003) — Per-tenant view for bank CROs/CCOs:
- Compliance score with 7-point provenance quality assessment
- Disparate impact analysis with auto-computed DI ratios
- Risk heatmap, examiner readiness checklist, peer benchmarking
- Action center, remediation queue, regulatory change tracking
- Report generation (SR 11-7, ECOA, Model Card) with PDF/DOCX export
- Value-level lineage explorer with per-applicant decision tracing

```bash
DASH_WRITER_DSN=postgresql://... ADMIN_TOKEN=... attestant-admin-dashboard
DASH_WRITER_DSN=postgresql://... DASH_TENANT=... attestant-client-dashboard
```

## API Server

REST API for cloud-hosted provenance persistence and dashboard data sync.

```bash
ATTESTANT_DSN=postgresql://... ATTESTANT_API_SECRET=... attestant-api
```

Key endpoints:

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/auth/validate` | Validate API key |
| POST | `/v1/pipelines` | Register pipeline run |
| POST | `/v1/nodes` | Store DAG nodes (batch) |
| POST | `/v1/edges` | Store DAG edges (batch) |
| POST | `/v1/values` | Store row-level values (batch) |
| GET | `/v1/values` | Retrieve value-level lineage for a row |
| POST | `/v1/dashboard/sync` | Sync pipeline results to dashboard tables |
| GET | `/v1/health` | Health check |

## Deployment

### AWS (Production)

The `deploy/` directory contains everything needed for EC2 + Aurora PostgreSQL deployment:

- `deploy.sh` — Main deployment script (rsync, pip install, service restart, health checks)
- `setup-ec2.sh` — EC2 instance provisioning
- `nginx.conf` — Reverse proxy for admin (/admin/), client (/client/), API (/v1/)
- Systemd service files for API, admin, and client dashboards
- CloudFormation templates for Aurora, ALB, Cognito, S3 lifecycle, deployment gate Lambda

```bash
./deploy/deploy.sh
```

### AWS Lambda (Deployment Gate)

The deployment gate runs as a Lambda function for CI/CD integration:

```bash
./deploy/deploy-gate-lambda.sh
```

## Storage Backends

```python
from attestant.persistence import create_storage, PostgreSQLStorage

# PostgreSQL (production — used directly)
storage = PostgreSQLStorage(dsn="postgresql://user:pass@host/db")

# S3 (archival)
storage = create_storage("s3://bucket/prefix")

# DuckDB (analytics)
storage = create_storage("duckdb:///analytics.duckdb")

# Hosted API (client SDK → Attestant cloud)
from attestant.persistence import HostedStorage
storage = HostedStorage(api_url="https://api.attestant.ai", api_key="pvt_live_...")
```

## Install

```bash
pip install attestant                          # core (numpy, pandas)
pip install "attestant[fairness]"              # + scikit-learn
pip install "attestant[dashboard]"             # + flask
pip install "attestant[server]"               # + flask, psycopg2, gunicorn
pip install "attestant[dashboard,server]"      # dashboards + API server
pip install "attestant[export]"               # + PDF and DOCX generation
pip install "attestant[all]"                  # everything
```

## Test

```bash
pytest tests/ -v
```

## Requirements

- Python >= 3.9
- numpy >= 1.24
- pandas >= 2.0

## License

Business Source License 1.1 (BUSL-1.1). Copyright (c) 2024-2026 Attestant, Inc.
