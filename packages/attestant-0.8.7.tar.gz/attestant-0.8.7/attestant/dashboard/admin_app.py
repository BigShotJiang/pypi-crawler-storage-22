"""
Admin / Founder Dashboard: Platform-Wide Monitoring.

Shows all tenants, system health, pipeline stats, error rates,
global compliance posture, and alert overview.

Protected by a simple bearer token (ADMIN_TOKEN env var).

Usage:
    ADMIN_TOKEN=secret DASH_WRITER_DSN=postgresql://... python -m attestant.dashboard.admin_app
    # Then open: http://localhost:5004

Requires Aurora PostgreSQL (DASH_WRITER_DSN).
"""

import hashlib
import hmac
import logging
import os
import re
import secrets
import time
from collections import defaultdict
from functools import wraps

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from flask import Flask, jsonify, render_template, render_template_string, request, redirect, make_response

logger = logging.getLogger(__name__)

app = Flask(__name__)


class _ReverseProxied:
    """WSGI middleware that adjusts SCRIPT_NAME from X-Script-Name header."""
    def __init__(self, wsgi_app):
        self.app = wsgi_app

    def __call__(self, environ, start_response):
        script_name = environ.get("HTTP_X_SCRIPT_NAME", "")
        if script_name:
            environ["SCRIPT_NAME"] = script_name
            path_info = environ.get("PATH_INFO", "")
            if path_info.startswith(script_name):
                environ["PATH_INFO"] = path_info[len(script_name):]
        return self.app(environ, start_response)


app.wsgi_app = _ReverseProxied(app.wsgi_app)


@app.after_request
def _fix_redirect_location(response):
    """Prepend SCRIPT_NAME to redirect Location headers."""
    if response.status_code in (301, 302, 303, 307, 308):
        location = response.headers.get("Location", "")
        if location.startswith("/") and not location.startswith(request.script_root + "/"):
            response.headers["Location"] = request.script_root + location
    return response


ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN")
TIER_PRICING = {
    "enterprise": int(os.environ.get("ATTESTANT_PRICE_ENTERPRISE", "5000")),
    "professional": int(os.environ.get("ATTESTANT_PRICE_PROFESSIONAL", "2000")),
    "starter": int(os.environ.get("ATTESTANT_PRICE_STARTER", "500")),
}

if not ADMIN_TOKEN:
    raise RuntimeError(
        "ADMIN_TOKEN environment variable is required. "
        "Set ADMIN_TOKEN to a secure random value (e.g. python -c "
        "\"import secrets; print(secrets.token_urlsafe(32))\")."
    )

_store = None

_SESSION_SECRET = secrets.token_hex(32)


@app.after_request
def add_security_headers(response):
    """Add security headers to all responses."""
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data:; "
        "connect-src 'self'"
    )
    return response


def _get_store():
    global _store
    if _store is not None:
        return _store
    from .dashdb import DashboardStore
    store = DashboardStore(
        writer_dsn=os.environ["DASH_WRITER_DSN"],
        reader_dsn=os.environ.get("DASH_READER_DSN"),
    )
    store.connect()
    store.ensure_schema()
    _store = store
    return _store


_AUTH_FAILURES: defaultdict = defaultdict(list)
_MAX_FAILURES = 5
_FAILURE_WINDOW = 300
_LOCKOUT_DURATION = 600


def _is_rate_limited(ip: str) -> bool:
    """Check if an IP is currently locked out due to repeated auth failures."""
    now = time.monotonic()
    _AUTH_FAILURES[ip] = [t for t in _AUTH_FAILURES[ip] if now - t < _FAILURE_WINDOW]
    if len(_AUTH_FAILURES[ip]) >= _MAX_FAILURES:
        if now - _AUTH_FAILURES[ip][-1] < _LOCKOUT_DURATION:
            return True
        _AUTH_FAILURES[ip].clear()
    return False


def _record_auth_failure(ip: str) -> None:
    """Record a failed authentication attempt for rate limiting."""
    _AUTH_FAILURES[ip].append(time.monotonic())
    logger.warning("Failed admin auth attempt from %s (attempt %d)", ip, len(_AUTH_FAILURES[ip]))


def _make_session_token() -> str:
    """Create an HMAC session token proving the user authenticated."""
    return hmac.new(
        _SESSION_SECRET.encode(), ADMIN_TOKEN.encode(), hashlib.sha256
    ).hexdigest()


def _valid_session_cookie() -> bool:
    """Check if the request has a valid admin session cookie."""
    cookie = request.cookies.get("proveit_admin_session")
    if not cookie:
        return False
    expected = _make_session_token()
    return hmac.compare_digest(cookie, expected)


def require_auth(f):
    """Bearer-token auth for admin endpoints (timing-safe, rate-limited).

    Accepts auth via:
    1. Authorization: Bearer <token> header (API clients)
    2. proveit_admin_session cookie (browser sessions via /login)
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        if _valid_session_cookie():
            return f(*args, **kwargs)

        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            provided = auth[7:]
            if hmac.compare_digest(provided, ADMIN_TOKEN):
                return f(*args, **kwargs)

        client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")
        if "," in client_ip:
            client_ip = client_ip.split(",")[0].strip()

        if auth.startswith("Bearer "):
            if _is_rate_limited(client_ip):
                logger.warning("Rate-limited admin auth from %s", client_ip)
                return jsonify({"error": "Too many failed attempts. Try again later."}), 429
            _record_auth_failure(client_ip)

        accept = request.headers.get("Accept", "")
        is_ajax = request.headers.get("X-Requested-With") == "XMLHttpRequest"
        is_fetch = "application/json" in accept and "text/html" not in accept
        if not is_ajax and not is_fetch and "text/html" in accept:
            return redirect("/login")

        return jsonify({"error": "Unauthorized"}), 401
    return decorated


# ---------------------------------------------------------------------------
# Login page
# ---------------------------------------------------------------------------

_LOGIN_HTML = """<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Attestant -- Admin Login</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#f1f5f9;--surface:#ffffff;--border:#e2e8f0;--text-1:#0f172a;--text-2:#64748b;--text-3:#94a3b8;--blue:#3b82f6;--red:#ef4444;--radius:8px}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--text-1);display:flex;align-items:center;justify-content:center;min-height:100vh;-webkit-font-smoothing:antialiased}
.login-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:40px;width:360px;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,0.06)}
.logo{font-size:20px;font-weight:700;letter-spacing:-0.5px;margin-bottom:4px}
.logo-sub{font-size:12px;color:var(--text-3);margin-bottom:32px}
label{display:block;text-align:left;font-size:12px;font-weight:500;color:var(--text-2);margin-bottom:6px}
input{width:100%;height:40px;padding:0 12px;font-size:13px;font-family:inherit;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);color:var(--text-1);outline:none;transition:border-color 0.15s}
input:focus{border-color:var(--blue)}
button{width:100%;height:40px;margin-top:16px;font-size:13px;font-weight:600;font-family:inherit;background:var(--blue);color:#fff;border:none;border-radius:var(--radius);cursor:pointer;transition:opacity 0.15s}
button:hover{opacity:0.9}
.error{color:var(--red);font-size:12px;margin-top:12px;display:none}
</style>
</head><body>
<div class="login-card">
<div class="logo">Attestant</div>
<div class="logo-sub">Admin Console</div>
<form method="POST" action="{{ request.script_root }}/login">
<label for="token">Admin Token</label>
<input type="password" id="token" name="token" placeholder="Enter admin token" autofocus>
<button type="submit">Sign In</button>
</form>
<div class="error" id="err">Invalid token. Please try again.</div>
</div>
<script>
if (location.search.includes('error=1')) document.getElementById('err').style.display='block';
</script>
</body></html>"""


@app.route("/login", methods=["GET", "POST"])
def login():
    """Login page for browser-based admin access."""
    if request.method == "GET":
        if _valid_session_cookie():
            return redirect("/")
        return render_template_string(_LOGIN_HTML)

    token = request.form.get("token", "")
    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")
    if "," in client_ip:
        client_ip = client_ip.split(",")[0].strip()

    if _is_rate_limited(client_ip):
        return redirect("/login?error=1")

    if hmac.compare_digest(token, ADMIN_TOKEN):
        resp = make_response(redirect("/"))
        resp.set_cookie(
            "proveit_admin_session",
            _make_session_token(),
            httponly=True,
            samesite="Lax",
            secure=request.scheme == "https",
            max_age=86400,
        )
        return resp

    _record_auth_failure(client_ip)
    return redirect("/login?error=1")


@app.route("/logout")
def logout():
    """Clear the admin session cookie."""
    resp = make_response(redirect("/login"))
    resp.delete_cookie("proveit_admin_session")
    return resp


# ---------------------------------------------------------------------------
# Error Handlers
# ---------------------------------------------------------------------------

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404


@app.errorhandler(500)
def server_error(e):
    logger.exception("Internal server error")
    return jsonify({"error": "Internal server error"}), 500


@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"error": "Method not allowed"}), 405


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
@require_auth
def index():
    return render_template("admin_dashboard.html")


@app.route("/health")
def health():
    return jsonify({"status": "healthy", "role": "admin"})


@app.route("/api/tenants")
@require_auth
def api_tenants():
    store = _get_store()
    try:
        return jsonify(store.admin_tenant_summary())
    except Exception as exc:
        logger.error("api_tenants failed: %s", exc)
        return jsonify([])


@app.route("/api/system-health")
@require_auth
def api_system_health():
    store = _get_store()
    try:
        return jsonify(store.admin_system_health())
    except Exception as exc:
        logger.error("api_system_health failed: %s", exc)
        return jsonify({
            "tenant_count": 0, "total_models": 0, "open_alerts": 0,
            "pipelines_24h": 0, "avg_compliance_score": None,
        })


@app.route("/api/pipelines")
@require_auth
def api_pipelines():
    store = _get_store()
    limit = min(request.args.get("limit", 50, type=int), 200)
    try:
        return jsonify(store.get_pipeline_stats(limit=limit))
    except Exception as exc:
        logger.error("api_pipelines failed: %s", exc)
        return jsonify([])


@app.route("/api/metrics")
@require_auth
def api_metrics():
    store = _get_store()
    try:
        return jsonify(store.get_latest_metrics())
    except Exception as exc:
        logger.error("api_metrics failed: %s", exc)
        return jsonify([])


@app.route("/api/alerts")
@require_auth
def api_alerts():
    store = _get_store()
    try:
        return jsonify(store.get_all_alerts_platform(limit=50))
    except Exception as exc:
        logger.error("api_alerts failed: %s", exc)
        return jsonify([])


@app.route("/api/alerts/<int:alert_id>/resolve", methods=["POST"])
@require_auth
def api_resolve_alert(alert_id):
    store = _get_store()
    try:
        store.resolve_alert(alert_id)
    except Exception as exc:
        logger.error("resolve_alert failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)}), 500
    return jsonify({"ok": True})


_TENANT_ID_RE = re.compile(r'^[a-zA-Z0-9_-]{1,128}$')


@app.route("/api/tenants/<tenant_id>")
@require_auth
def api_tenant_detail(tenant_id):
    if not _TENANT_ID_RE.match(tenant_id):
        return jsonify({"error": "Invalid tenant ID"}), 400
    store = _get_store()
    try:
        t = store.get_tenant(tenant_id)
    except Exception as exc:
        logger.error("get_tenant failed: %s", exc)
        return jsonify({"error": "Database error"}), 500
    if not t:
        return jsonify({"error": "Tenant not found"}), 404
    try:
        comp = store.get_latest_compliance(tenant_id)
        comp_history = store.get_compliance_history(tenant_id, limit=12)
        models = store.get_models(tenant_id)
        alerts = store.get_alerts(tenant_id, unresolved_only=True)
        pipelines = store.get_pipeline_stats(tenant_id=tenant_id, limit=20)
        fairness = store.get_all_fairness(tenant_id)
        certs = store.get_certifications(tenant_id)
    except Exception as exc:
        logger.error("tenant detail queries failed: %s", exc)
        comp = None
        comp_history = []
        models = []
        alerts = []
        pipelines = []
        fairness = []
        certs = []
    return jsonify({
        "tenant_id": t["tenant_id"],
        "name": t["name"],
        "tier": t["tier"],
        "created_at": t.get("created_at"),
        "compliance": comp,
        "compliance_history": comp_history,
        "models": models,
        "alerts": alerts,
        "pipelines": pipelines,
        "fairness": fairness,
        "certifications": certs,
    })


@app.route("/api/models/all")
@require_auth
def api_models_all():
    store = _get_store()
    try:
        return jsonify(store.get_all_models_platform())
    except Exception as exc:
        logger.error("api_models_all failed: %s", exc)
        return jsonify([])


@app.route("/api/fairness/all")
@require_auth
def api_fairness_all():
    store = _get_store()
    try:
        return jsonify(store.get_all_fairness_platform())
    except Exception as exc:
        logger.error("api_fairness_all failed: %s", exc)
        return jsonify([])


@app.route("/api/compliance/platform")
@require_auth
def api_compliance_platform():
    store = _get_store()
    try:
        return jsonify(store.get_compliance_platform())
    except Exception as exc:
        logger.error("api_compliance_platform failed: %s", exc)
        return jsonify({"tenants": [], "avg_score": None})


@app.route("/api/pipelines/summary")
@require_auth
def api_pipeline_summary():
    store = _get_store()
    try:
        return jsonify(store.get_pipeline_summary())
    except Exception as exc:
        logger.error("api_pipeline_summary failed: %s", exc)
        return jsonify({"total_runs": 0, "completed": 0, "failed": 0})


@app.route("/api/revenue")
@require_auth
def api_revenue():
    store = _get_store()
    try:
        tenants = store.get_all_tenants()
        tier_counts = {}
        for t in tenants:
            tier = t.get("tier", "starter")
            tier_counts[tier] = tier_counts.get(tier, 0) + 1
        mrr = sum(TIER_PRICING.get(tier, 0) * count for tier, count in tier_counts.items())
        arr = mrr * 12
        models = store.get_all_models_platform()
        health = store.admin_system_health()
        pipelines_24h = health.get("pipelines_24h", 0)
        return jsonify({
            "mrr": mrr,
            "arr": arr,
            "tier_breakdown": [
                {"tier": tier, "count": count, "mrr": TIER_PRICING.get(tier, 0) * count,
                 "price_per_unit": TIER_PRICING.get(tier, 0)}
                for tier, count in sorted(tier_counts.items(), key=lambda x: -TIER_PRICING.get(x[0], 0))
            ],
            "total_clients": len(tenants),
            "total_models": len(models),
            "models_per_client": round(len(models) / max(len(tenants), 1), 1),
            "pipelines_24h": pipelines_24h,
            "avg_revenue_per_client": round(mrr / max(len(tenants), 1)),
        })
    except Exception as exc:
        logger.error("api_revenue failed: %s", exc)
        return jsonify({})


@app.route("/api/calendar")
@require_auth
def api_calendar():
    try:
        from attestant.governance.regulatory_calendar import RegulatoryCalendar
        cal = RegulatoryCalendar()
        return jsonify(cal.generate_report())
    except Exception as exc:
        logger.error("api_calendar failed: %s", exc)
        return jsonify({})


@app.route("/api/deployment/gate-status")
@require_auth
def api_deployment_gate_status():
    """Get deployment gate status across all tenants/models."""
    store = _get_store()
    try:
        status = store.get_deployment_gate_status()
        return jsonify(status)
    except Exception as exc:
        logger.error("Failed to get deployment gate status: %s", exc)
        return jsonify({
            "total_deployments": 0,
            "approved": 0,
            "blocked": 0,
            "recent_decisions": [],
        })


@app.route("/api/compliance/violations")
@require_auth
def api_compliance_violations():
    """Get active compliance violations across all models."""
    store = _get_store()
    try:
        violations = store.get_compliance_violations()
        return jsonify(violations)
    except Exception as exc:
        logger.error("Failed to get compliance violations: %s", exc)
        return jsonify({
            "violations": [],
            "total_count": 0,
            "critical_count": 0,
            "by_regulation": {},
        })


@app.route("/api/fairness/regression-trends")
@require_auth
def api_fairness_regression_trends():
    """Get fairness regression trends across model versions."""
    store = _get_store()
    try:
        trends = store.get_fairness_regression_trends()
        return jsonify(trends)
    except Exception as exc:
        logger.error("Failed to get fairness regression trends: %s", exc)
        return jsonify({"models": [], "degrading_count": 0})


@app.route("/api/models/<model_name>/lifecycle")
@require_auth
def api_model_lifecycle(model_name):
    """Get complete lifecycle view for a specific model."""
    store = _get_store()
    try:
        lifecycle = store.get_model_lifecycle(model_name)
        return jsonify(lifecycle)
    except Exception as exc:
        logger.error("Failed to get model lifecycle: %s", exc)
        return jsonify({
            "model_name": model_name,
            "versions": [],
            "fairness_trend": [],
        })


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Attestant Admin Dashboard")
    parser.add_argument("--port", default=5004, type=int)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    from proveit import __version__

    mode_label = "Aurora PostgreSQL"

    url = f"http://{args.host}:{args.port}"

    print()
    print("  Attestant Admin Dashboard v" + __version__)
    print("  " + "=" * 44)
    print(f"  Mode:       {mode_label}")
    print(f"  Auth:       bearer token required")
    print(f"  Dashboard:  {url}")
    print()

    app.run(debug=args.debug, port=args.port, host=args.host)


if __name__ == "__main__":
    main()
