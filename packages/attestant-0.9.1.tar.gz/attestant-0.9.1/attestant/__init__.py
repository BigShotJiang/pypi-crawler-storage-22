"""
Attestant: Unified Compliance Platform for Regulated ML

SIMPLE API: Wrap your model, use it normally

    import attestant
    from sklearn.linear_model import LogisticRegression

    # Configure once
    attestant.configure(api_key="pvt_live_...")

    # Wrap your model
    model = attestant.wrap(
        LogisticRegression(),
        model_name="loan_approval",
        protected_columns=["age", "race", "gender"]
    )

    # Use normally - training automatically tracked
    model.fit(X_train, y_train)

    # Use normally - predictions automatically tracked
    predictions = model.predict(X_test)

    # Check dashboard for results
    # http://54.205.86.45/client/

How it works:
- Wrap your model at the start (2 lines of code)
- Use your model normally (.fit, .predict)
- Attestant automatically captures data in background
- All data uploaded to your AWS (non-blocking)
- Server runs all analysis (fairness, compliance, proxy detection)
- View results in dashboard
- Zero local storage - everything on your AWS

Works with ALL models: scikit-learn, XGBoost, LightGBM, PyTorch, TensorFlow, Keras, custom
Works with ALL data: NumPy, Pandas, lists, sparse matrices, GPU tensors, Polars

For most users: log into the dashboard at http://54.205.86.45/client/

Full documentation: https://attestant.ai/docs
"""

from typing import List

__version__ = "0.9.1"

# =============================================================================
# Public API
# =============================================================================
__all__ = [
    "__version__",
    "wrap",
    "configure",
    "setup_logging",
]


# =============================================================================
# Configuration
# =============================================================================

_API_KEY = None
_SERVICE_URL = None


def configure(api_key: str, service_url: str = "http://54.205.86.45"):
    """Configure Attestant with your API key.

    Args:
        api_key: Your Attestant API key (get from dashboard)
        service_url: Attestant service URL (default: http://54.205.86.45)
    """
    global _API_KEY, _SERVICE_URL
    import os
    _API_KEY = api_key
    _SERVICE_URL = service_url
    os.environ.setdefault("ATTESTANT_API_KEY", api_key)
    os.environ.setdefault("ATTESTANT_SERVICE_URL", service_url)


def wrap(
    model,
    model_name: str,
    protected_columns: List[str],
    model_version: str = "1.0.0",
    **metadata
):
    """
    Wrap a model to automatically track training and inference with Attestant.

    This is the primary API - just wrap your model at the start, then use it normally.
    Attestant automatically captures .fit() and .predict() calls, uploads data to
    your backend, where all analysis happens server-side.

    Args:
        model: ML model (scikit-learn, XGBoost, PyTorch, TensorFlow, etc.)
        model_name: Name for dashboard (e.g., "loan_approval")
        protected_columns: Protected attributes for fairness analysis (e.g., ["race", "gender", "age"])
        model_version: Version string (e.g., "1.0.0")
        **metadata: Additional metadata for documentation

    Returns:
        Wrapped model that works exactly like the original but automatically tracks data

    Example:
        import attestant
        from sklearn.linear_model import LogisticRegression

        # Configure once
        attestant.configure(api_key="pvt_live_...")

        # Wrap your model
        model = attestant.wrap(
            LogisticRegression(),
            model_name="loan_approval",
            protected_columns=["race", "gender", "age"]
        )

        # Use normally - training data automatically captured and uploaded
        model.fit(X_train, y_train)

        # Use normally - predictions automatically captured and uploaded
        predictions = model.predict(X_test)

        # Check dashboard for compliance results
        # http://54.205.86.45/client/

    For production inference:
        # Wrap deployed model
        model = attestant.wrap(
            loaded_model,
            model_name="loan_approval",
            protected_columns=["race", "gender", "age"]
        )

        # Each prediction automatically monitored
        for application in new_loan_applications:
            prediction = model.predict(application)
            process(prediction)
    """
    global _API_KEY, _SERVICE_URL

    if not _API_KEY:
        raise ValueError("Call attestant.configure(api_key='...') before wrap()")

    from .wrapper import ModelWrapper

    return ModelWrapper(
        model=model,
        model_name=model_name,
        protected_columns=protected_columns,
        api_key=_API_KEY,
        service_url=_SERVICE_URL,
        model_version=model_version,
        **metadata
    )


# =============================================================================
# Production Logging Setup
# =============================================================================

def setup_logging(
    level: str = "INFO",
    fmt: str = "json",
    include_timestamp: bool = True,
) -> None:
    """Configure logging for production bank deployments.

    Sets up structured logging across all ``attestant.*`` loggers so that
    output is compatible with log aggregation tools (Splunk, ELK,
    Datadog, CloudWatch Logs).

    Args:
        level: Log level (``"DEBUG"``, ``"INFO"``, ``"WARNING"``, ``"ERROR"``).
        fmt: ``"json"`` for structured JSON lines (default, recommended
             for production), or ``"text"`` for human-readable output.
        include_timestamp: Include ISO-8601 timestamps (default ``True``).

    Example::

        import attestant
        attestant.setup_logging(level="INFO", fmt="json")
    """
    import logging
    import json as _json
    import sys
    from datetime import datetime, timezone

    numeric_level = getattr(logging, level.upper(), logging.INFO)

    class _JSONFormatter(logging.Formatter):
        def format(self, record: logging.LogRecord) -> str:
            entry = {
                "logger": record.name,
                "level": record.levelname,
                "message": record.getMessage(),
            }
            if include_timestamp:
                entry["timestamp"] = (
                    datetime.fromtimestamp(record.created, tz=timezone.utc)
                    .isoformat()
                )
            if record.exc_info and record.exc_info[0] is not None:
                entry["exception"] = self.formatException(record.exc_info)
            return _json.dumps(entry, default=str)

    class _TextFormatter(logging.Formatter):
        _fmt_ts = "%(asctime)s %(name)s %(levelname)s %(message)s"
        _fmt_no_ts = "%(name)s %(levelname)s %(message)s"

        def __init__(self, with_ts: bool = True) -> None:
            super().__init__(
                fmt=self._fmt_ts if with_ts else self._fmt_no_ts,
                datefmt="%Y-%m-%dT%H:%M:%S%z",
            )

    root_logger = logging.getLogger("attestant")
    root_logger.setLevel(numeric_level)

    root_logger.handlers.clear()

    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(numeric_level)

    if fmt == "json":
        handler.setFormatter(_JSONFormatter())
    else:
        handler.setFormatter(_TextFormatter(with_ts=include_timestamp))

    root_logger.addHandler(handler)

