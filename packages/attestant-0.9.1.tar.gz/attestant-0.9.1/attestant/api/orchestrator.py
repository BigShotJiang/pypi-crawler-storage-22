"""
Unified Orchestration API for Attestant: End-to-end ML compliance workflows.

This orchestrates the complete model lifecycle:
  Model → FairLens → Compliance → Deployment Gate → Documentation → Monitoring

Provides a single unified API that:
1. Runs fairness analysis with full provenance tracking
2. Validates SR 11-7, ECOA, EU AI Act compliance
3. Checks deployment gate (blocks if non-compliant)
4. Auto-generates documentation (SR 11-7, Model Cards, EU AI Act)
5. Persists attestations and compliance status to dashboard
6. Sends alerts on violations

This is the "control tower" that unifies all Attestant capabilities.
"""

import hashlib
import json
import logging
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import pandas as pd

from ..fairness.engine import FairLensEngine, FairLensConfig
from ..deployment.gate import DeploymentGate, GateStatus
from ..deployment.regression import FairnessRegressionTester
from ..documentation.sr117_generator import SR117Generator
from ..compliance.sr117 import SR117Engine
from ..compliance.ecoa import ECOAEngine
from ..compliance.eu_ai_act import EUAIActEngine
from ..hydra24_dag import ComputationDAG, DAGTracker
from ..persistence.storage import StorageBackend
from ..governance.model_registry import ModelRegistry, ModelRecord

logger = logging.getLogger(__name__)


@dataclass
class ModelValidationRequest:
    """Request for end-to-end model validation."""
    model_name: str
    model_version: str
    model: Any
    X_train: pd.DataFrame
    y_train: np.ndarray
    X_test: pd.DataFrame
    y_test: np.ndarray
    protected_data: pd.DataFrame
    protected_columns: List[str]

    # Optional parameters
    model_factory: Optional[Callable] = None
    previous_version: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    industry: str = "lending"

    # Pipeline configuration
    run_fairness: bool = True
    run_compliance: bool = True
    run_deployment_gate: bool = True
    run_documentation: bool = True
    persist_to_dashboard: bool = True


@dataclass
class ValidationResult:
    """Complete model validation result with all analyses."""
    deployment_approved: bool
    model_name: str
    model_version: str
    model_hash: str
    timestamp: str

    # Analysis results
    fairness_report: Optional[Dict[str, Any]] = None
    sr117_result: Optional[Dict[str, Any]] = None
    ecoa_result: Optional[Dict[str, Any]] = None
    eu_ai_act_result: Optional[Dict[str, Any]] = None
    deployment_gate_result: Optional[Dict[str, Any]] = None
    regression_result: Optional[Dict[str, Any]] = None

    # Generated documentation
    sr117_report_path: Optional[str] = None
    model_card_path: Optional[str] = None
    eu_ai_act_doc_path: Optional[str] = None

    # Attestation
    attestation_id: Optional[str] = None

    # Findings summary
    blocking_findings: List[Dict[str, Any]] = field(default_factory=list)
    warning_findings: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)


class ModelOrchestrator:
    """
    Unified orchestrator for end-to-end ML compliance workflows.

    This is the "control tower" that:
    1. Runs FairLens fairness analysis
    2. Validates compliance (SR 11-7, ECOA, EU AI Act)
    3. Executes deployment gate (blocks non-compliant models)
    4. Auto-generates documentation
    5. Persists to model registry and dashboard
    6. Sends compliance alerts

    Example:
        orchestrator = ModelOrchestrator(storage=s3_storage)

        result = orchestrator.validate_and_deploy(
            model_name="credit_scoring_v2",
            model_version="2.1.0",
            model=xgb_model,
            X_train=X_train,
            y_train=y_train,
            X_test=X_test,
            y_test=y_test,
            protected_data=protected_df,
            protected_columns=["race", "sex", "age"],
        )

        if result.deployment_approved:
            print(f"✓ Deployment approved: {result.attestation_id}")
        else:
            print(f"✗ Deployment blocked:")
            for finding in result.blocking_findings:
                print(f"  - {finding['description']}")
    """

    def __init__(
        self,
        storage: Optional[StorageBackend] = None,
        dashboard_db_path: Optional[str] = None,
        strict_mode: bool = True,
        four_fifths_threshold: float = 0.80,
    ):
        """
        Initialize the orchestrator.

        Args:
            storage: Storage backend for persisting provenance data
            dashboard_db_path: Path to dashboard SQLite database
            strict_mode: Block on all CRITICAL findings (not just fairness)
            four_fifths_threshold: Disparate impact threshold
        """
        self.storage = storage
        self.dashboard_db_path = dashboard_db_path
        self.strict_mode = strict_mode
        self.four_fifths_threshold = four_fifths_threshold

        # Initialize components
        self.fairlens = FairLensEngine()
        self.sr117_engine = SR117Engine()
        self.ecoa_engine = ECOAEngine()
        self.eu_ai_act_engine = EUAIActEngine()
        self.deployment_gate = DeploymentGate(
            storage=storage,
            strict_mode=strict_mode,
            four_fifths_threshold=four_fifths_threshold,
        )
        self.regression_tester = FairnessRegressionTester(storage=storage)
        self.sr117_generator = SR117Generator()

        # Model registry
        self.registry = None
        if storage:
            self.registry = ModelRegistry(storage=storage)

    def validate_and_deploy(
        self,
        model_name: str,
        model_version: str,
        model: Any,
        X_train: pd.DataFrame,
        y_train: np.ndarray,
        X_test: pd.DataFrame,
        y_test: np.ndarray,
        protected_data: pd.DataFrame,
        protected_columns: List[str],
        model_factory: Optional[Callable] = None,
        previous_version: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        industry: str = "lending",
    ) -> ValidationResult:
        """
        Complete end-to-end validation workflow.

        This orchestrates:
        1. Fairness analysis (FairLens)
        2. Compliance validation (SR 11-7, ECOA, EU AI Act)
        3. Deployment gate decision
        4. Fairness regression testing
        5. Documentation generation
        6. Model registry update
        7. Dashboard persistence
        8. Alerting

        Args:
            model_name: Model identifier
            model_version: Semantic version
            model: Trained model
            X_train: Training features
            y_train: Training labels
            X_test: Test features
            y_test: Test labels
            protected_data: DataFrame with protected attributes
            protected_columns: List of protected attribute column names
            model_factory: Factory function to recreate model for LDA search
            previous_version: Previous model version for regression testing
            metadata: Additional metadata for documentation
            industry: Industry context (lending, hiring, etc.)

        Returns:
            ValidationResult with all analyses, documentation, and deployment decision
        """
        start_time = time.time()
        timestamp = datetime.now(timezone.utc).isoformat()

        logger.info("Starting validation for %s v%s", model_name, model_version)

        # Compute model hash for identity
        import pickle
        model_hash = hashlib.sha256(pickle.dumps(model)).hexdigest()[:16]

        result = ValidationResult(
            deployment_approved=False,
            model_name=model_name,
            model_version=model_version,
            model_hash=model_hash,
            timestamp=timestamp,
        )

        # Step 1: Run FairLens fairness analysis
        logger.info("Running FairLens fairness analysis...")
        fairness_config = FairLensConfig(
            protected_columns=protected_columns,
            four_fifths_threshold=self.four_fifths_threshold,
            industry=industry,
        )

        fairness_report = self.fairlens.analyze(
            model=model,
            X_train=X_train,
            y_train=y_train,
            X_test=X_test,
            y_test=y_test,
            protected_data=protected_data,
            config=fairness_config,
            model_version=model_version,
            model_factory=model_factory,
        )

        result.fairness_report = fairness_report.to_dict()

        # Step 2: Run compliance validations
        logger.info("Running compliance validations...")

        sr117_result = self.sr117_engine.validate(fairness_report, metadata or {})
        result.sr117_result = sr117_result.to_dict()

        ecoa_result = self.ecoa_engine.validate(fairness_report, metadata or {})
        result.ecoa_result = ecoa_result.to_dict()

        eu_ai_act_result = self.eu_ai_act_engine.validate(fairness_report, metadata or {})
        result.eu_ai_act_result = eu_ai_act_result.to_dict()

        # Step 3: Run deployment gate
        logger.info("Running deployment gate...")
        gate_result = self.deployment_gate.validate_deployment(
            model=model,
            model_name=model_name,
            X_train=X_train,
            y_train=y_train,
            X_test=X_test,
            y_test=y_test,
            protected_data=protected_data,
            protected_columns=protected_columns,
            model_factory=model_factory,
            model_version=model_version,
            previous_version=previous_version,
            metadata=metadata,
        )

        result.deployment_gate_result = gate_result.to_dict()
        result.deployment_approved = gate_result.deployment_approved
        result.attestation_id = gate_result.attestation_id
        result.blocking_findings = [f.__dict__ for f in gate_result.blocking_findings]
        result.warning_findings = [f.__dict__ for f in gate_result.warning_findings]

        # Step 4: Run fairness regression testing if previous version provided
        if previous_version and self.storage:
            logger.info("Running fairness regression testing...")
            regression_result = self.regression_tester.compare_versions(
                current_report=fairness_report,
                current_version=model_version,
                previous_version=previous_version,
            )
            result.regression_result = regression_result.to_dict()

        # Step 5: Auto-generate documentation (only if deployment approved)
        if result.deployment_approved:
            logger.info("Generating documentation...")

            # SR 11-7 Model Validation Report
            sr117_report = self.sr117_generator.generate(
                model_name=model_name,
                model_version=model_version,
                fairness_report=fairness_report,
                metadata=metadata or {},
            )

            if self.storage:
                sr117_path = f"documentation/{model_name}/v{model_version}/sr117_validation_report.md"
                self.storage.store_document(sr117_path, sr117_report.encode('utf-8'))
                result.sr117_report_path = sr117_path
                logger.info("Stored SR 11-7 report at %s", sr117_path)

        # Step 6: Update model registry
        if self.registry:
            logger.info("Updating model registry...")
            model_record = ModelRecord(
                model_name=model_name,
                model_version=model_version,
                model_hash=model_hash,
                deployment_status="approved" if result.deployment_approved else "blocked",
                fairness_status="compliant" if not result.blocking_findings else "non-compliant",
                attestation_id=result.attestation_id,
                metadata=metadata or {},
            )
            self.registry.register_model(model_record)

        # Step 7: Persist to dashboard database
        if self.dashboard_db_path and result.deployment_approved:
            logger.info("Persisting to dashboard...")
            self._persist_to_dashboard(result)

        # Step 8: Send alerts for blocking findings
        if result.blocking_findings:
            logger.warning("Deployment blocked with %d findings", len(result.blocking_findings))
            self._send_alerts(result)

        elapsed = time.time() - start_time
        logger.info(
            "Validation complete in %.2fs: %s",
            elapsed,
            "APPROVED" if result.deployment_approved else "BLOCKED",
        )

        return result

    def _persist_to_dashboard(self, result: ValidationResult) -> None:
        """Persist validation results to dashboard database."""
        if not self.dashboard_db_path:
            return

        import sqlite3

        try:
            conn = sqlite3.connect(self.dashboard_db_path)
            cursor = conn.cursor()

            # Insert deployment decision record
            cursor.execute(
                """
                INSERT OR REPLACE INTO deployment_decisions (
                    model_name, model_version, model_hash, timestamp,
                    deployment_approved, attestation_id, blocking_findings_count,
                    fairness_report_json, gate_result_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    result.model_name,
                    result.model_version,
                    result.model_hash,
                    result.timestamp,
                    result.deployment_approved,
                    result.attestation_id,
                    len(result.blocking_findings),
                    json.dumps(result.fairness_report) if result.fairness_report else None,
                    json.dumps(result.deployment_gate_result) if result.deployment_gate_result else None,
                ),
            )

            conn.commit()
            conn.close()
            logger.info("Persisted validation to dashboard database")

        except Exception as exc:
            logger.error("Failed to persist to dashboard: %s", exc)

    def validate_inference(
        self,
        model: Any,
        X_production: pd.DataFrame,
        protected_data: pd.DataFrame,
        protected_columns: List[str],
        model_name: str,
        model_version: str,
        batch_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Validate production inference for fairness monitoring.

        This analyzes predictions on production data for disparate impact
        without requiring training data. Use for ongoing production monitoring.

        Args:
            model: Trained model with predict() or predict_proba()
            X_production: Production features to score
            protected_data: DataFrame with protected attributes
            protected_columns: List of protected column names
            model_name: Model identifier
            model_version: Model version
            batch_id: Optional batch identifier
            metadata: Additional metadata

        Returns:
            Dictionary with:
            - predictions: List of predictions
            - fairness_metrics: Disparate impact analysis
            - flagged_cases: Cases failing fairness checks
            - summary_stats: Approval rate, flagged count
        """
        import uuid
        from datetime import datetime

        logger.info("Validating inference for %s v%s", model_name, model_version)

        # Generate batch_id if not provided
        if batch_id is None:
            batch_id = f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"

        # Run predictions
        if hasattr(model, 'predict_proba'):
            predictions_proba = model.predict_proba(X_production)
            if predictions_proba.shape[1] == 2:
                predictions = predictions_proba[:, 1].tolist()
                predictions_binary = (predictions_proba[:, 1] >= 0.5).astype(int).tolist()
            else:
                predictions = predictions_proba.argmax(axis=1).tolist()
                predictions_binary = predictions
        else:
            predictions = model.predict(X_production).tolist()
            predictions_binary = predictions

        # Analyze fairness
        fairness_metrics = {}
        flagged_cases = []

        if len(protected_data) > 0 and len(protected_columns) > 0:
            for col in protected_columns:
                if col not in protected_data.columns:
                    continue

                groups = protected_data[col].unique()
                if len(groups) < 2:
                    continue

                # Calculate approval rate by group
                approval_rates = {}
                for group in groups:
                    mask = protected_data[col] == group
                    if mask.sum() == 0:
                        continue
                    group_preds = [predictions_binary[i] for i in range(len(predictions_binary)) if mask.iloc[i]]
                    approval_rate = sum(group_preds) / len(group_preds) if len(group_preds) > 0 else 0
                    approval_rates[str(group)] = approval_rate

                if len(approval_rates) >= 2:
                    max_rate = max(approval_rates.values())
                    min_rate = min(approval_rates.values())
                    di_ratio = min_rate / max_rate if max_rate > 0 else 0

                    fairness_metrics[col] = {
                        "approval_rates": approval_rates,
                        "disparate_impact_ratio": di_ratio,
                        "has_disparate_impact": di_ratio < self.four_fifths_threshold,
                        "worst_group": min(approval_rates, key=approval_rates.get),
                        "best_group": max(approval_rates, key=approval_rates.get)
                    }

                    # Flag cases from disadvantaged groups
                    if di_ratio < self.four_fifths_threshold:
                        worst_group = min(approval_rates, key=approval_rates.get)
                        for i in range(len(predictions_binary)):
                            if protected_data[col].iloc[i] == worst_group:
                                flagged_cases.append({
                                    "row_index": i,
                                    "prediction": predictions_binary[i],
                                    "protected_attribute": col,
                                    "protected_value": str(worst_group),
                                    "di_ratio": di_ratio
                                })

        # Calculate summary stats
        total_predictions = len(predictions_binary)
        approval_count = sum(predictions_binary)
        approval_rate = approval_count / total_predictions if total_predictions > 0 else 0.0
        flagged_count = len(flagged_cases)

        logger.info(
            "Inference validation complete: %d predictions, %.1f%% approval rate, %d flagged",
            total_predictions, approval_rate * 100, flagged_count
        )

        return {
            "predictions": predictions,
            "fairness_metrics": fairness_metrics,
            "flagged_cases": flagged_cases,
            "batch_id": batch_id,
            "total_predictions": total_predictions,
            "approval_rate": approval_rate,
            "flagged_count": flagged_count,
            "model_name": model_name,
            "model_version": model_version,
        }

    def _send_alerts(self, result: ValidationResult) -> None:
        """Send alerts for compliance violations."""
        for finding in result.blocking_findings:
            logger.critical(
                "COMPLIANCE VIOLATION: %s - %s [%s]",
                finding['category'],
                finding['description'],
                finding['regulation_citation'],
            )

        # TODO: Integrate with alerting system (PagerDuty, Slack, etc.)

    def get_model_lifecycle(self, model_name: str) -> Dict[str, Any]:
        """
        Get complete lifecycle view for a model (all versions).

        Returns deployment history, fairness trends, compliance status.
        """
        if not self.registry:
            return {"error": "Model registry not initialized"}

        versions = self.registry.get_model_versions(model_name)

        lifecycle = {
            "model_name": model_name,
            "versions": [],
            "fairness_trend": [],
            "compliance_trend": [],
        }

        for version in versions:
            lifecycle["versions"].append({
                "version": version.model_version,
                "deployment_status": version.deployment_status,
                "fairness_status": version.fairness_status,
                "attestation_id": version.attestation_id,
                "created_at": version.created_at,
            })

        return lifecycle
