"""
Attestant API Server: REST backend for customer provenance data.

This is the server-side counterpart to HostedStorage. Customer packages
call these endpoints to persist provenance DAGs, pipeline metadata,
and per-row audit trails to your Aurora PostgreSQL.

Run:
    ATTESTANT_DSN=postgresql://user:pass@host/db python -m attestant.api.server
"""

import base64
import hashlib
import hmac
import json
import logging
import os
import pickle
import secrets
import time
import traceback
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, jsonify, request, g

logger = logging.getLogger(__name__)

app = Flask(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DSN = os.environ.get("ATTESTANT_DSN", os.environ.get("PROVEIT_DSN", os.environ.get("DASH_WRITER_DSN", "")))
API_PORT = int(os.environ.get("ATTESTANT_API_PORT", "5005"))
API_SECRET = os.environ.get("ATTESTANT_API_SECRET", "")

if not API_SECRET:
    API_SECRET = secrets.token_urlsafe(32)
    logger.warning("ATTESTANT_API_SECRET not set; generated ephemeral secret")

# ---------------------------------------------------------------------------
# Database connection pool (PostgreSQL via psycopg2)
# ---------------------------------------------------------------------------

_pool = None


def _get_pool():
    global _pool
    if _pool is None:
        import psycopg2.pool as pg_pool
        _pool = pg_pool.ThreadedConnectionPool(2, 20, DSN)
    return _pool


def _get_conn():
    return _get_pool().getconn()


def _put_conn(conn):
    _get_pool().putconn(conn)


def _db():
    """Get a connection for the current request."""
    if "db" not in g:
        g.db = _get_conn()
    return g.db


@app.teardown_appcontext
def _return_conn(exc):
    conn = g.pop("db", None)
    if conn is not None:
        if exc:
            conn.rollback()
        _put_conn(conn)


# ---------------------------------------------------------------------------
# Schema bootstrap (ensures tables exist on first request)
# ---------------------------------------------------------------------------

_schema_ready = False


def _ensure_schema():
    global _schema_ready
    if _schema_ready:
        return
    from attestant.persistence.schema import get_schema_ddl
    conn = _get_conn()
    try:
        with conn.cursor() as cur:
            # Run each statement individually; skip DuplicateObject errors
            # (triggers, indexes that already exist)
            for stmt in get_schema_ddl().split(";"):
                stmt = stmt.strip()
                if not stmt or stmt.startswith("--"):
                    continue
                try:
                    cur.execute(stmt)
                    conn.commit()
                except Exception:
                    conn.rollback()
            # API keys table
            for stmt in _API_KEYS_DDL.split(";"):
                stmt = stmt.strip()
                if not stmt:
                    continue
                try:
                    cur.execute(stmt)
                    conn.commit()
                except Exception:
                    conn.rollback()
        _schema_ready = True
    finally:
        _put_conn(conn)


_API_KEYS_DDL = """
CREATE TABLE IF NOT EXISTS api_keys (
    key_id SERIAL PRIMARY KEY,
    key_hash VARCHAR(64) NOT NULL UNIQUE,
    key_prefix VARCHAR(16) NOT NULL,
    tenant_id VARCHAR(64) NOT NULL,
    tenant_name VARCHAR(255),
    tier VARCHAR(32) DEFAULT 'professional',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    last_used_at TIMESTAMP,
    rate_limit INTEGER DEFAULT 1000,
    metadata JSONB
);
CREATE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys(key_hash) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_api_keys_tenant ON api_keys(tenant_id);
"""


# ---------------------------------------------------------------------------
# API key management (admin-only)
# ---------------------------------------------------------------------------

def _hash_key(api_key: str) -> str:
    return hashlib.sha256(api_key.encode()).hexdigest()


def create_api_key(tenant_id: str, tenant_name: str = "", tier: str = "professional") -> str:
    """Generate a new API key for a tenant. Returns the raw key (show once)."""
    _ensure_schema()
    raw_key = f"pvt_live_{secrets.token_urlsafe(32)}"
    key_hash = _hash_key(raw_key)
    key_prefix = raw_key[:16]

    conn = _get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO api_keys (key_hash, key_prefix, tenant_id, tenant_name, tier)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (key_hash, key_prefix, tenant_id, tenant_name, tier),
            )
            conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        _put_conn(conn)

    return raw_key


def _validate_api_key(api_key: str):
    """Validate an API key. Returns (tenant_id, tier) or None."""
    key_hash = _hash_key(api_key)
    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT tenant_id, tier, key_id FROM api_keys
            WHERE key_hash = %s AND is_active = TRUE
            """,
            (key_hash,),
        )
        row = cur.fetchone()
        if row:
            cur.execute(
                "UPDATE api_keys SET last_used_at = NOW() WHERE key_id = %s",
                (row[2],),
            )
            conn.commit()
            return {"tenant_id": row[0], "tier": row[1]}
    return None


# ---------------------------------------------------------------------------
# Authentication middleware
# ---------------------------------------------------------------------------

def require_api_key(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Missing Authorization header"}), 401

        api_key = auth[7:]
        result = _validate_api_key(api_key)
        if result is None:
            return jsonify({"error": "Invalid API key"}), 401

        g.tenant_id = result["tenant_id"]
        g.tier = result["tier"]
        return f(*args, **kwargs)
    return decorated


def require_admin(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("X-Admin-Token", "")
        if not hmac.compare_digest(token, API_SECRET):
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.route("/v1/health", methods=["GET"])
def health():
    try:
        conn = _get_conn()
        with conn.cursor() as cur:
            cur.execute("SELECT 1")
        _put_conn(conn)
        return jsonify({"status": "healthy", "version": "1.0.0"})
    except Exception as exc:
        return jsonify({"status": "unhealthy", "error": str(exc)}), 503


# ---------------------------------------------------------------------------
# Auth validation (called by attestant.configure())
# ---------------------------------------------------------------------------

@app.route("/api/v1/auth/validate", methods=["POST"])
def auth_validate():
    _ensure_schema()
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return jsonify({"error": "Missing Authorization header"}), 401

    api_key = auth[7:]
    result = _validate_api_key(api_key)
    if result is None:
        return jsonify({"error": "Invalid API key"}), 401

    return jsonify({"tenant_id": result["tenant_id"], "tier": result["tier"]})


# ---------------------------------------------------------------------------
# Pipeline lifecycle
# ---------------------------------------------------------------------------

@app.route("/v1/pipelines", methods=["POST"])
@require_api_key
def create_pipeline():
    _ensure_schema()
    data = request.get_json(force=True)
    tenant_id = g.tenant_id

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO pipeline_metadata (pipeline_name, config, git_commit, status, tenant_id)
            VALUES (%s, %s, %s, 'running', %s)
            RETURNING pipeline_id
            """,
            (
                data.get("pipeline_name", "unnamed"),
                json.dumps(data.get("config")) if data.get("config") else None,
                data.get("git_commit"),
                tenant_id,
            ),
        )
        pipeline_id = cur.fetchone()[0]
        conn.commit()

    return jsonify({"pipeline_id": pipeline_id}), 201


@app.route("/v1/pipelines/<int:pipeline_id>", methods=["PATCH"])
@require_api_key
def complete_pipeline(pipeline_id):
    data = request.get_json(force=True)
    status = data.get("status", "completed")

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            UPDATE pipeline_metadata SET status = %s
            WHERE pipeline_id = %s AND tenant_id = %s
            """,
            (status, pipeline_id, g.tenant_id),
        )
        conn.commit()

    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# DAG nodes
# ---------------------------------------------------------------------------

@app.route("/v1/nodes", methods=["POST"])
@require_api_key
def store_nodes():
    _ensure_schema()
    from psycopg2.extras import execute_batch

    nodes = request.get_json(force=True)
    if not isinstance(nodes, list):
        return jsonify({"error": "Expected JSON array of nodes"}), 400

    tenant_id = g.tenant_id
    conn = _db()
    with conn.cursor() as cur:
        execute_batch(
            cur,
            """
            INSERT INTO dag_nodes (
                fingerprint, node_type, operation,
                table_name, column_name, pair_id, is_protected,
                entity_hash, chain_hash, metadata, pipeline_id, tenant_id
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (fingerprint, pipeline_id, tenant_id) DO NOTHING
            """,
            [
                (
                    n["fingerprint"],
                    n.get("node_type", "computation"),
                    n.get("operation", "unknown"),
                    n.get("table_name"),
                    n.get("column_name"),
                    n.get("pair_id"),
                    n.get("is_protected", False),
                    n.get("entity_hash"),
                    n.get("chain_hash"),
                    json.dumps(n["metadata"]) if n.get("metadata") else None,
                    n.get("pipeline_id"),
                    tenant_id,
                )
                for n in nodes
            ],
            page_size=100,
        )
        conn.commit()

    return jsonify({"stored": len(nodes)}), 201


@app.route("/v1/nodes", methods=["GET"])
@require_api_key
def get_node():
    fingerprint = request.args.get("fingerprint", type=int)
    pipeline_id = request.args.get("pipeline_id", type=int)

    if fingerprint is None:
        return jsonify({"error": "fingerprint parameter required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        if pipeline_id is not None:
            cur.execute(
                """
                SELECT node_id, fingerprint, node_type, operation,
                       table_name, column_name, pair_id, is_protected,
                       entity_hash, chain_hash, metadata
                FROM dag_nodes
                WHERE fingerprint = %s AND pipeline_id = %s AND tenant_id = %s
                """,
                (fingerprint, pipeline_id, g.tenant_id),
            )
        else:
            cur.execute(
                """
                SELECT node_id, fingerprint, node_type, operation,
                       table_name, column_name, pair_id, is_protected,
                       entity_hash, chain_hash, metadata
                FROM dag_nodes
                WHERE fingerprint = %s AND tenant_id = %s
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (fingerprint, g.tenant_id),
            )
        row = cur.fetchone()

    if row is None:
        return jsonify(None)

    return jsonify({
        "node_id": row[0],
        "fingerprint": row[1],
        "node_type": row[2],
        "operation": row[3],
        "table_name": row[4],
        "column_name": row[5],
        "pair_id": row[6],
        "is_protected": row[7],
        "entity_hash": row[8],
        "chain_hash": row[9],
        "metadata": json.loads(row[10]) if row[10] else None,
    })


@app.route("/v1/nodes/fingerprint-map", methods=["GET"])
@require_api_key
def fingerprint_map():
    pipeline_id = request.args.get("pipeline_id", type=int)
    if pipeline_id is None:
        return jsonify({"error": "pipeline_id parameter required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            "SELECT fingerprint, node_id FROM dag_nodes WHERE pipeline_id = %s AND tenant_id = %s",
            (pipeline_id, g.tenant_id),
        )
        result = {str(row[0]): row[1] for row in cur.fetchall()}

    return jsonify(result)


# ---------------------------------------------------------------------------
# DAG edges
# ---------------------------------------------------------------------------

@app.route("/v1/edges", methods=["POST"])
@require_api_key
def store_edges():
    _ensure_schema()
    from psycopg2.extras import execute_batch

    edges = request.get_json(force=True)
    if not isinstance(edges, list):
        return jsonify({"error": "Expected JSON array of edges"}), 400

    conn = _db()
    with conn.cursor() as cur:
        if edges and "parent_node_id" in edges[0]:
            execute_batch(
                cur,
                """
                INSERT INTO dag_edges (parent_node_id, child_node_id, input_position)
                VALUES (%s, %s, %s)
                ON CONFLICT DO NOTHING
                """,
                [
                    (e["parent_node_id"], e["child_node_id"], e.get("input_position", 0))
                    for e in edges
                ],
                page_size=100,
            )
        else:
            execute_batch(
                cur,
                """
                INSERT INTO dag_edges (parent_node_id, child_node_id, input_position)
                SELECT p.node_id, c.node_id, %s
                FROM dag_nodes p, dag_nodes c
                WHERE p.fingerprint = %s AND c.fingerprint = %s
                  AND p.tenant_id = %s AND c.tenant_id = %s
                ON CONFLICT DO NOTHING
                """,
                [
                    (
                        e.get("input_position", 0),
                        e["parent_fingerprint"],
                        e["child_fingerprint"],
                        g.tenant_id,
                        g.tenant_id,
                    )
                    for e in edges
                ],
                page_size=100,
            )
        conn.commit()

    return jsonify({"stored": len(edges)}), 201


@app.route("/v1/edges", methods=["GET"])
@require_api_key
def get_edges():
    node_id = request.args.get("node_id", type=int)
    if node_id is None:
        return jsonify({"error": "node_id parameter required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT e.parent_node_id, e.input_position, n.fingerprint
            FROM dag_edges e
            JOIN dag_nodes n ON e.parent_node_id = n.node_id
            WHERE e.child_node_id = %s AND n.tenant_id = %s
            ORDER BY e.input_position
            """,
            (node_id, g.tenant_id),
        )
        result = [
            {
                "parent_node_id": row[0],
                "input_position": row[1],
                "parent_fingerprint": row[2],
            }
            for row in cur.fetchall()
        ]

    return jsonify(result)


# ---------------------------------------------------------------------------
# Source registry
# ---------------------------------------------------------------------------

@app.route("/v1/sources", methods=["POST"])
@require_api_key
def register_source():
    _ensure_schema()
    data = request.get_json(force=True)

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO source_registry (pair_id, table_name, column_name, is_protected)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (pair_id) DO UPDATE
            SET table_name = EXCLUDED.table_name,
                column_name = EXCLUDED.column_name,
                is_protected = EXCLUDED.is_protected
            """,
            (
                data["pair_id"],
                data["table_name"],
                data["column_name"],
                data.get("is_protected", False),
            ),
        )
        conn.commit()

    return jsonify({"ok": True}), 201


@app.route("/v1/sources", methods=["GET"])
@require_api_key
def get_source():
    pair_id = request.args.get("pair_id", type=int)
    if pair_id is None:
        return jsonify({"error": "pair_id parameter required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            "SELECT table_name, column_name, is_protected FROM source_registry WHERE pair_id = %s",
            (pair_id,),
        )
        row = cur.fetchone()

    if row is None:
        return jsonify(None)

    return jsonify({
        "table_name": row[0],
        "column_name": row[1],
        "is_protected": row[2],
    })


# ---------------------------------------------------------------------------
# Pipeline results (per-row audit trail)
# ---------------------------------------------------------------------------

@app.route("/v1/results", methods=["POST"])
@require_api_key
def store_results():
    _ensure_schema()
    from psycopg2.extras import execute_batch

    data = request.get_json(force=True)
    pipeline_id = data.get("pipeline_id")
    results = data.get("results", [])

    if not pipeline_id or not results:
        return jsonify({"error": "pipeline_id and results required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        execute_batch(
            cur,
            """
            INSERT INTO pipeline_results
                (pipeline_id, row_key, output_name, fingerprint, output_value, input_hash)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            [
                (
                    pipeline_id,
                    r["row_key"],
                    r["output_name"],
                    r["fingerprint"],
                    r.get("output_value"),
                    r.get("input_hash"),
                )
                for r in results
            ],
            page_size=100,
        )
        conn.commit()

    return jsonify({"stored": len(results)}), 201


@app.route("/v1/results", methods=["GET"])
@require_api_key
def get_results():
    row_key = request.args.get("row_key")
    pipeline_id = request.args.get("pipeline_id", type=int)

    if not row_key:
        return jsonify({"error": "row_key parameter required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        if pipeline_id is not None:
            cur.execute(
                """
                SELECT r.output_name, r.fingerprint, r.output_value,
                       r.pipeline_id, n.node_id, n.node_type, n.operation,
                       n.is_protected
                FROM pipeline_results r
                LEFT JOIN dag_nodes n
                    ON r.fingerprint = n.fingerprint AND r.pipeline_id = n.pipeline_id
                    AND n.tenant_id = %s
                JOIN pipeline_metadata pm ON r.pipeline_id = pm.pipeline_id
                WHERE r.row_key = %s AND r.pipeline_id = %s AND pm.tenant_id = %s
                ORDER BY r.output_name
                """,
                (g.tenant_id, row_key, pipeline_id, g.tenant_id),
            )
        else:
            cur.execute(
                """
                SELECT r.output_name, r.fingerprint, r.output_value,
                       r.pipeline_id, n.node_id, n.node_type, n.operation,
                       n.is_protected
                FROM pipeline_results r
                LEFT JOIN dag_nodes n
                    ON r.fingerprint = n.fingerprint AND r.pipeline_id = n.pipeline_id
                    AND n.tenant_id = %s
                JOIN pipeline_metadata pm ON r.pipeline_id = pm.pipeline_id
                WHERE r.row_key = %s AND pm.tenant_id = %s
                ORDER BY r.pipeline_id DESC, r.output_name
                """,
                (g.tenant_id, row_key, g.tenant_id),
            )
        result = [
            {
                "output_name": row[0],
                "fingerprint": row[1],
                "output_value": row[2],
                "pipeline_id": row[3],
                "node_id": row[4],
                "node_type": row[5],
                "operation": row[6],
                "is_protected": row[7],
            }
            for row in cur.fetchall()
        ]

    return jsonify(result)


# ---------------------------------------------------------------------------
# Row values (value-level lineage)
# ---------------------------------------------------------------------------

@app.route("/v1/values", methods=["POST"])
@require_api_key
def store_values():
    _ensure_schema()
    from psycopg2.extras import execute_batch

    values = request.get_json(force=True)
    if not isinstance(values, list):
        return jsonify({"error": "Expected JSON array of values"}), 400

    tenant_id = g.tenant_id
    conn = _db()
    with conn.cursor() as cur:
        execute_batch(
            cur,
            """
            INSERT INTO row_values
                (pipeline_id, row_index, fingerprint, node_operation,
                 column_name, value, text_value, tenant_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            [
                (
                    v["pipeline_id"],
                    v["row_index"],
                    v["fingerprint"],
                    v["node_operation"],
                    v.get("column_name"),
                    v.get("value"),
                    v.get("text_value"),
                    tenant_id,
                )
                for v in values
            ],
            page_size=500,
        )
        conn.commit()

    return jsonify({"stored": len(values)}), 201


@app.route("/v1/values", methods=["GET"])
@require_api_key
def get_values():
    pipeline_id = request.args.get("pipeline_id", type=int)
    row_index = request.args.get("row_index", type=int)

    if pipeline_id is None or row_index is None:
        return jsonify({"error": "pipeline_id and row_index parameters required"}), 400

    conn = _db()
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT fingerprint, node_operation, column_name, value, text_value
            FROM row_values
            WHERE pipeline_id = %s AND row_index = %s AND tenant_id = %s
            ORDER BY value_id
            """,
            (pipeline_id, row_index, g.tenant_id),
        )
        result = [
            {
                "fingerprint": row[0],
                "node_operation": row[1],
                "column_name": row[2],
                "value": row[3] if row[3] is not None else row[4],
            }
            for row in cur.fetchall()
        ]

    return jsonify(result)


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------

@app.route("/v1/stats", methods=["GET"])
@require_api_key
def get_stats():
    conn = _db()
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM dag_nodes WHERE tenant_id = %s", (g.tenant_id,))
        nodes = cur.fetchone()[0]

        cur.execute(
            """
            SELECT COUNT(*) FROM dag_edges e
            JOIN dag_nodes n ON e.child_node_id = n.node_id
            WHERE n.tenant_id = %s
            """,
            (g.tenant_id,),
        )
        edges = cur.fetchone()[0]

        cur.execute("SELECT COUNT(*) FROM dag_nodes WHERE tenant_id = %s AND is_protected = TRUE", (g.tenant_id,))
        protected = cur.fetchone()[0]

        cur.execute("SELECT COUNT(*) FROM pipeline_metadata WHERE tenant_id = %s", (g.tenant_id,))
        pipelines = cur.fetchone()[0]

    return jsonify({
        "nodes": nodes,
        "edges": edges,
        "protected_nodes": protected,
        "pipelines": pipelines,
    })


# ---------------------------------------------------------------------------
# Admin: key management
# ---------------------------------------------------------------------------

@app.route("/admin/keys", methods=["POST"])
@require_admin
def admin_create_key():
    _ensure_schema()
    data = request.get_json(force=True)
    tenant_id = data.get("tenant_id")
    if not tenant_id:
        return jsonify({"error": "tenant_id required"}), 400

    raw_key = create_api_key(
        tenant_id=tenant_id,
        tenant_name=data.get("tenant_name", ""),
        tier=data.get("tier", "professional"),
    )
    return jsonify({"api_key": raw_key, "tenant_id": tenant_id}), 201


@app.route("/admin/keys", methods=["GET"])
@require_admin
def admin_list_keys():
    _ensure_schema()
    conn = _get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT key_id, key_prefix, tenant_id, tenant_name, tier,
                       is_active, created_at, last_used_at
                FROM api_keys ORDER BY created_at DESC
                """
            )
            keys = [
                {
                    "key_id": row[0],
                    "key_prefix": row[1],
                    "tenant_id": row[2],
                    "tenant_name": row[3],
                    "tier": row[4],
                    "is_active": row[5],
                    "created_at": row[6].isoformat() if row[6] else None,
                    "last_used_at": row[7].isoformat() if row[7] else None,
                }
                for row in cur.fetchall()
            ]
    finally:
        _put_conn(conn)

    return jsonify(keys)


@app.route("/admin/keys/<int:key_id>/revoke", methods=["POST"])
@require_admin
def admin_revoke_key(key_id):
    conn = _get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE api_keys SET is_active = FALSE WHERE key_id = %s",
                (key_id,),
            )
            conn.commit()
    finally:
        _put_conn(conn)

    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Admin: DAG integrity verification
# ---------------------------------------------------------------------------

@app.route("/admin/verify/<int:pipeline_id>", methods=["GET"])
@require_admin
def admin_verify_dag(pipeline_id):
    from attestant.persistence.storage import PostgreSQLStorage
    storage = PostgreSQLStorage(DSN)
    storage.connect()
    try:
        result = storage.verify_dag_integrity(pipeline_id)
    finally:
        storage.disconnect()
    return jsonify(result)


# ---------------------------------------------------------------------------
# Unified Orchestration Endpoints (Model Validation & Deployment)
# ---------------------------------------------------------------------------

@app.route("/v1/models/validate-and-deploy", methods=["POST"])
@require_api_key
def validate_and_deploy():
    """
    End-to-end model validation and deployment decision.

    Orchestrates: FairLens → Compliance → Deployment Gate → Documentation
    """
    _ensure_schema()
    data = request.get_json(force=True)

    model_name = data.get("model_name")
    model_version = data.get("model_version")

    if not all([model_name, model_version]):
        return jsonify({"error": "model_name and model_version required"}), 400

    # TODO: Implement full orchestration with model loading from S3
    # For now, return structure showing integration pattern
    return jsonify({
        "status": "pending",
        "message": "Full orchestration integration in progress",
        "model_name": model_name,
        "model_version": model_version,
        "tenant_id": g.tenant_id,
    }), 200


@app.route("/v1/models/<model_name>/lifecycle", methods=["GET"])
@require_api_key
def get_model_lifecycle(model_name):
    """
    Get complete lifecycle view for a model.

    Returns all versions, deployment history, fairness trends, compliance status.
    """
    # TODO: Query model registry and deployment decisions
    return jsonify({
        "model_name": model_name,
        "versions": [],
        "fairness_trend": [],
        "compliance_trend": [],
        "tenant_id": g.tenant_id,
    }), 200


@app.route("/v1/models/<model_name>/attestation/<attestation_id>", methods=["GET"])
@require_api_key
def get_attestation(model_name, attestation_id):
    """Retrieve deployment attestation and validation results."""
    # TODO: Query attestation store (S3 or PostgreSQL)
    return jsonify({
        "attestation_id": attestation_id,
        "model_name": model_name,
        "status": "not_implemented",
        "tenant_id": g.tenant_id,
    }), 200


@app.route("/v1/compliance/violations", methods=["GET"])
@require_api_key
def get_compliance_violations():
    """Get all active compliance violations across models."""
    # TODO: Query compliance violation tracking
    return jsonify({
        "violations": [],
        "total_count": 0,
        "critical_count": 0,
        "tenant_id": g.tenant_id,
    }), 200


@app.route("/v1/fairness/regression-trends", methods=["GET"])
@require_api_key
def get_fairness_regression_trends():
    """Get fairness regression trends across model versions."""
    model_name = request.args.get("model_name")

    if not model_name:
        return jsonify({"error": "model_name parameter required"}), 400

    # TODO: Query fairness regression history
    return jsonify({
        "model_name": model_name,
        "trend_data": [],
        "tenant_id": g.tenant_id,
    }), 200


# ---------------------------------------------------------------------------
# Dashboard sync: pipeline results -> dashboard tables
# ---------------------------------------------------------------------------

@app.route("/v1/dashboard/sync", methods=["POST"])
@require_api_key
def dashboard_sync():
    """Sync pipeline results to dashboard tables.

    Called automatically by flush() so pipeline data appears in dashboards.
    Accepts pipeline stats, model info, and fairness results in one call.
    """
    data = request.get_json(force=True)
    tenant_id = g.tenant_id
    conn = _get_pool().getconn()
    try:
        cur = conn.cursor()

        pipeline = data.get("pipeline")
        if pipeline:
            prov_id = pipeline.get("provenance_pipeline_id")
            if prov_id:
                cur.execute(
                    """INSERT INTO pipeline_stats
                       (tenant_id, pipeline_name, status, node_count, edge_count,
                        duration_ms, provenance_pipeline_id, completed_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
                       ON CONFLICT (tenant_id, provenance_pipeline_id)
                       DO UPDATE SET
                         status = EXCLUDED.status,
                         node_count = EXCLUDED.node_count,
                         edge_count = EXCLUDED.edge_count,
                         duration_ms = EXCLUDED.duration_ms,
                         completed_at = EXCLUDED.completed_at""",
                    (
                        tenant_id,
                        pipeline.get("pipeline_name"),
                        pipeline.get("status", "completed"),
                        pipeline.get("node_count", 0),
                        pipeline.get("edge_count", 0),
                        pipeline.get("duration_ms"),
                        prov_id,
                        pipeline.get("completed_at"),
                    ),
                )
            else:
                cur.execute(
                    """INSERT INTO pipeline_stats
                       (tenant_id, pipeline_name, status, node_count, edge_count,
                        duration_ms, provenance_pipeline_id, completed_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
                    (
                        tenant_id,
                        pipeline.get("pipeline_name"),
                        pipeline.get("status", "completed"),
                        pipeline.get("node_count", 0),
                        pipeline.get("edge_count", 0),
                        pipeline.get("duration_ms"),
                        None,
                        pipeline.get("completed_at"),
                    ),
                )

        model = data.get("model")
        if model:
            cur.execute(
                """INSERT INTO model_snapshots
                   (tenant_id, model_id, name, version, tier, status, domain, owner,
                    compliance_score, last_validated, last_monitored,
                    validation_overdue, monitoring_overdue, finding_count)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (
                    tenant_id,
                    model.get("model_id"),
                    model.get("name"),
                    model.get("version"),
                    model.get("tier", 3),
                    model.get("status", "production"),
                    model.get("domain"),
                    model.get("owner"),
                    model.get("compliance_score"),
                    model.get("last_validated"),
                    model.get("last_monitored"),
                    model.get("validation_overdue", False),
                    model.get("monitoring_overdue", False),
                    model.get("finding_count", 0),
                ),
            )

        fairness = data.get("fairness")
        if fairness:
            cur.execute(
                """INSERT INTO fairness_snapshots
                   (tenant_id, model_id, has_disparate_impact, worst_ratio,
                    worst_group, p_value, statistically_significant,
                    protected_attributes, sample_size_warnings, details)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (
                    tenant_id,
                    fairness.get("model_id"),
                    fairness.get("has_disparate_impact", False),
                    fairness.get("worst_ratio"),
                    fairness.get("worst_group"),
                    fairness.get("p_value"),
                    fairness.get("statistically_significant", False),
                    json.dumps(fairness.get("protected_attributes", [])),
                    json.dumps(fairness.get("sample_size_warnings", [])),
                    json.dumps(fairness.get("details", {})),
                ),
            )

        # ---------------------------------------------------------------
        # Compute compliance score from provenance data
        # ---------------------------------------------------------------
        provenance_pipeline_id = (
            pipeline.get("provenance_pipeline_id") if pipeline else None
        )
        model_id = model.get("model_id") if model else None

        # Fall back to existing database records when sync payload is sparse
        if not provenance_pipeline_id:
            cur.execute(
                """SELECT pipeline_id FROM pipeline_metadata
                   WHERE tenant_id = %s
                   ORDER BY pipeline_id DESC LIMIT 1""",
                (tenant_id,),
            )
            row = cur.fetchone()
            if row:
                provenance_pipeline_id = row[0]

        if not model_id:
            cur.execute(
                """SELECT DISTINCT ON (model_id) model_id
                   FROM model_snapshots
                   WHERE tenant_id = %s
                   ORDER BY model_id, snapshot_at DESC LIMIT 1""",
                (tenant_id,),
            )
            row = cur.fetchone()
            if row:
                model_id = row[0]
                if model is None:
                    model = {"model_id": model_id}

        if not fairness:
            cur.execute(
                """SELECT has_disparate_impact, worst_ratio, worst_group,
                          p_value, statistically_significant,
                          protected_attributes, sample_size_warnings, details
                   FROM fairness_snapshots
                   WHERE tenant_id = %s
                   ORDER BY snapshot_at DESC LIMIT 1""",
                (tenant_id,),
            )
            frow = cur.fetchone()
            if frow:
                pa = frow[5]
                if isinstance(pa, str):
                    pa = json.loads(pa)
                fairness = {
                    "has_disparate_impact": frow[0],
                    "worst_ratio": frow[1],
                    "worst_group": frow[2],
                    "p_value": frow[3],
                    "statistically_significant": frow[4],
                    "protected_attributes": pa if isinstance(pa, list) else [],
                }

        score = 0
        breakdowns = []
        top_risks = []
        critical_count = 0
        warning_count = 0

        # 1. Pipeline Registration (15 pts)
        has_pipeline = False
        if provenance_pipeline_id:
            cur.execute(
                "SELECT COUNT(*) FROM pipeline_metadata WHERE pipeline_id = %s AND tenant_id = %s",
                (provenance_pipeline_id, tenant_id),
            )
            has_pipeline = cur.fetchone()[0] > 0
        if not has_pipeline:
            cur.execute(
                "SELECT COUNT(*) FROM pipeline_metadata WHERE tenant_id = %s",
                (tenant_id,),
            )
            has_pipeline = cur.fetchone()[0] > 0

        if has_pipeline:
            score += 15
            breakdowns.append({"check": "Pipeline Registration", "points": 15, "max": 15})
        else:
            breakdowns.append({"check": "Pipeline Registration", "points": 0, "max": 15})
            top_risks.append("No completed pipeline registered")
            warning_count += 1

        # 2. DAG Completeness (20 pts)
        node_count = 0
        edge_count = 0
        if provenance_pipeline_id:
            cur.execute(
                "SELECT COUNT(*) FROM dag_nodes WHERE pipeline_id = %s AND tenant_id = %s",
                (provenance_pipeline_id, tenant_id),
            )
            node_count = cur.fetchone()[0]
            cur.execute(
                """SELECT COUNT(*) FROM dag_edges e
                   JOIN dag_nodes n ON e.child_node_id = n.node_id
                   WHERE n.pipeline_id = %s AND n.tenant_id = %s""",
                (provenance_pipeline_id, tenant_id),
            )
            edge_count = cur.fetchone()[0]

        if node_count > 0 and edge_count > 0:
            score += 20
            breakdowns.append({"check": "DAG Completeness", "points": 20, "max": 20})
        elif node_count > 0:
            score += 10
            breakdowns.append({"check": "DAG Completeness", "points": 10, "max": 20})
            top_risks.append("DAG has nodes but no edges recorded")
            warning_count += 1
        else:
            breakdowns.append({"check": "DAG Completeness", "points": 0, "max": 20})
            top_risks.append("No DAG nodes or edges for this pipeline")
            critical_count += 1

        # 3. Value-Level Audit Trail (20 pts)
        row_value_count = 0
        if provenance_pipeline_id:
            cur.execute(
                "SELECT COUNT(*) FROM row_values WHERE pipeline_id = %s AND tenant_id = %s",
                (provenance_pipeline_id, tenant_id),
            )
            row_value_count = cur.fetchone()[0]

        if row_value_count > 0:
            score += 20
            breakdowns.append({"check": "Value-Level Audit Trail", "points": 20, "max": 20})
        else:
            breakdowns.append({"check": "Value-Level Audit Trail", "points": 0, "max": 20})
            top_risks.append("No value-level audit trail")
            critical_count += 1

        # 4. Protected Attribute Detection (15 pts)
        protected_assessed = False
        has_disparate_impact_ratio = False
        if fairness:
            protected_attrs = fairness.get("protected_attributes", [])
            if protected_attrs:
                protected_assessed = True
            if fairness.get("worst_ratio") is not None:
                has_disparate_impact_ratio = True

        if protected_assessed:
            score += 15
            breakdowns.append({"check": "Protected Attribute Detection", "points": 15, "max": 15})
        else:
            breakdowns.append({"check": "Protected Attribute Detection", "points": 0, "max": 15})
            top_risks.append("No protected attribute assessment")
            critical_count += 1

        # 5. Model Registration (10 pts)
        has_model = model is not None and model.get("model_id")
        if has_model:
            score += 10
            breakdowns.append({"check": "Model Registration", "points": 10, "max": 10})
        else:
            breakdowns.append({"check": "Model Registration", "points": 0, "max": 10})
            top_risks.append("Model not registered")
            warning_count += 1

        # 6. Data Lineage Depth (10 pts)
        depth_points = 0
        if node_count > 10:
            depth_points = 10
        elif node_count > 5:
            depth_points = 5

        score += depth_points
        breakdowns.append({"check": "Data Lineage Depth", "points": depth_points, "max": 10})
        if depth_points == 0:
            top_risks.append("Low DAG depth (5 or fewer nodes)")
            warning_count += 1
        elif depth_points == 5:
            top_risks.append("Moderate DAG depth (6-10 nodes)")
            warning_count += 1

        # 7. Multi-Source Traceability (10 pts)
        distinct_sources = 0
        if provenance_pipeline_id:
            cur.execute(
                """SELECT COUNT(DISTINCT table_name) FROM dag_nodes
                   WHERE pipeline_id = %s AND tenant_id = %s AND table_name IS NOT NULL""",
                (provenance_pipeline_id, tenant_id),
            )
            distinct_sources = cur.fetchone()[0]

        if distinct_sources >= 2:
            score += 10
            breakdowns.append({"check": "Multi-Source Traceability", "points": 10, "max": 10})
        elif distinct_sources == 1:
            score += 5
            breakdowns.append({"check": "Multi-Source Traceability", "points": 5, "max": 10})
            top_risks.append("Single source table only")
            warning_count += 1
        else:
            breakdowns.append({"check": "Multi-Source Traceability", "points": 0, "max": 10})
            top_risks.append("No source tables tracked")
            warning_count += 1

        # 8. Protected Data Isolation (-25 penalty)
        protected_in_decision = []
        if provenance_pipeline_id:
            try:
                cur.execute(
                    """WITH RECURSIVE decision_ancestors AS (
                        SELECT dn.node_id
                        FROM dag_nodes dn
                        WHERE dn.pipeline_id = %s AND dn.tenant_id = %s
                          AND dn.node_id NOT IN (
                              SELECT DISTINCT parent_node_id FROM dag_edges
                          )
                          AND dn.node_type <> 'SOURCE'
                        UNION
                        SELECT de.parent_node_id
                        FROM dag_edges de
                        JOIN decision_ancestors da ON de.child_node_id = da.node_id
                    )
                    SELECT DISTINCT dn.table_name, dn.column_name
                    FROM decision_ancestors da
                    JOIN dag_nodes dn ON da.node_id = dn.node_id
                    WHERE dn.is_protected = TRUE
                      AND dn.pipeline_id = %s AND dn.tenant_id = %s""",
                    (provenance_pipeline_id, tenant_id,
                     provenance_pipeline_id, tenant_id),
                )
                protected_in_decision = cur.fetchall()
            except Exception:
                pass

        if protected_in_decision:
            score -= 25
            cols = ", ".join(
                "%s.%s" % (r[0] or "unknown", r[1] or "unknown")
                for r in protected_in_decision
            )
            breakdowns.append({
                "check": "Protected Data Isolation",
                "points": -25,
                "max": 0,
                "detail": cols,
            })
            top_risks.insert(0,
                "ECOA: Protected data (%s) flows into model decision" % cols
            )
            critical_count += 1
        else:
            breakdowns.append({
                "check": "Protected Data Isolation",
                "points": 0,
                "max": 0,
            })

        score = max(0, score)

        # Determine grade
        if score >= 90:
            grade = "A"
        elif score >= 75:
            grade = "B"
        elif score >= 60:
            grade = "C"
        else:
            grade = "D"

        total_findings = critical_count + warning_count
        engines_count = 8

        # Determine trend from previous snapshot
        trend = None
        cur.execute(
            """SELECT score FROM compliance_snapshots
               WHERE tenant_id = %s ORDER BY snapshot_at DESC LIMIT 1""",
            (tenant_id,),
        )
        prev = cur.fetchone()
        if prev is not None:
            prev_score = prev[0]
            if score > prev_score:
                trend = "improving"
            elif score < prev_score:
                trend = "declining"
            else:
                trend = "stable"

        cur.execute(
            """INSERT INTO compliance_snapshots
               (tenant_id, score, grade, engines_evaluated, critical_findings,
                warning_findings, total_findings, top_risks, breakdowns, bonuses, trend)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, score, grade, engines_count, critical_count,
                warning_count, total_findings, json.dumps(top_risks),
                json.dumps(breakdowns), json.dumps({}), trend,
            ),
        )

        # ---------------------------------------------------------------
        # Auto-compute disparate impact ratio from row_values
        # ---------------------------------------------------------------
        di_computed = False
        worst_ratio = None
        worst_group = None
        di_p_value = None
        di_significant = False
        group_rates = []

        if (provenance_pipeline_id and row_value_count > 0
                and protected_assessed):
            try:
                # Find leaf/output nodes (nodes never appearing as parent)
                cur.execute(
                    """SELECT dn.fingerprint, dn.operation
                       FROM dag_nodes dn
                       WHERE dn.pipeline_id = %s AND dn.tenant_id = %s
                         AND dn.node_type <> 'SOURCE'
                         AND dn.node_id NOT IN (
                             SELECT parent_node_id FROM dag_edges
                         )
                         AND dn.operation <> 'merge'
                       ORDER BY dn.fingerprint""",
                    (provenance_pipeline_id, tenant_id),
                )
                leaf_nodes = cur.fetchall()

                # Find numeric protected attributes available in row_values
                cur.execute(
                    """SELECT DISTINCT rv.node_operation, rv.column_name
                       FROM row_values rv
                       JOIN dag_nodes dn ON rv.fingerprint = dn.fingerprint
                         AND rv.pipeline_id = dn.pipeline_id
                         AND rv.tenant_id = dn.tenant_id
                       WHERE rv.pipeline_id = %s AND rv.tenant_id = %s
                         AND dn.is_protected = TRUE
                         AND rv.value IS NOT NULL""",
                    (provenance_pipeline_id, tenant_id),
                )
                protected_cols = cur.fetchall()

                if leaf_nodes and protected_cols:
                    # Use first leaf node as the decision score
                    score_fp = leaf_nodes[0][0]
                    # Use age if available, otherwise first numeric protected
                    prot_op = protected_cols[0][0]
                    prot_col = protected_cols[0][1]
                    for pc in protected_cols:
                        if pc[1] == 'age':
                            prot_op = pc[0]
                            prot_col = pc[1]
                            break

                    # Compute approval rates per group
                    if prot_col == 'age':
                        cur.execute(
                            """SELECT
                                 CASE WHEN prot.value < 25 THEN 'Under 25'
                                      WHEN prot.value < 40 THEN '25-39'
                                      WHEN prot.value < 55 THEN '40-54'
                                      ELSE '55+' END AS grp,
                                 COUNT(*) AS total,
                                 SUM(CASE WHEN sc.value > 0.55 THEN 1 ELSE 0 END) AS approved
                               FROM row_values sc
                               JOIN row_values prot
                                 ON sc.pipeline_id = prot.pipeline_id
                                 AND sc.row_index = prot.row_index
                                 AND sc.tenant_id = prot.tenant_id
                                 AND prot.node_operation = %s
                               WHERE sc.pipeline_id = %s
                                 AND sc.tenant_id = %s
                                 AND sc.fingerprint = %s
                               GROUP BY 1
                               HAVING COUNT(*) >= 5""",
                            (prot_op, provenance_pipeline_id,
                             tenant_id, score_fp),
                        )
                    else:
                        # For non-age numeric protected (e.g. zip_code),
                        # bin into quartiles
                        cur.execute(
                            """SELECT
                                 NTILE(4) OVER (ORDER BY prot.value) AS grp,
                                 sc.value AS score_val
                               FROM row_values sc
                               JOIN row_values prot
                                 ON sc.pipeline_id = prot.pipeline_id
                                 AND sc.row_index = prot.row_index
                                 AND sc.tenant_id = prot.tenant_id
                                 AND prot.node_operation = %s
                               WHERE sc.pipeline_id = %s
                                 AND sc.tenant_id = %s
                                 AND sc.fingerprint = %s""",
                            (prot_op, provenance_pipeline_id,
                             tenant_id, score_fp),
                        )
                        # Aggregate in Python for NTILE-based grouping
                        ntile_rows = cur.fetchall()
                        from collections import defaultdict
                        buckets = defaultdict(lambda: [0, 0])
                        for ntile_grp, sv in ntile_rows:
                            label = "Q%d" % ntile_grp
                            buckets[label][0] += 1
                            if sv is not None and sv > 0.55:
                                buckets[label][1] += 1
                        # Convert to same format as age query
                        cur.description = None  # reset
                        group_rates = [
                            (label, ct[0], ct[1])
                            for label, ct in buckets.items()
                            if ct[0] >= 5
                        ]

                    if cur.description is not None:
                        group_rates = cur.fetchall()

                    if len(group_rates) >= 2:
                        rates = []
                        for grp, total, approved in group_rates:
                            rate = approved / max(total, 1)
                            rates.append((grp, rate, total, approved))

                        max_rate = max(r[1] for r in rates)
                        min_rate_row = min(rates, key=lambda r: r[1])

                        if max_rate > 0:
                            worst_ratio = round(
                                min_rate_row[1] / max_rate, 4
                            )
                            worst_group = "%s (by %s)" % (
                                min_rate_row[0], prot_col,
                            )
                            has_disparate_impact_ratio = True
                            di_computed = True
                            di_significant = worst_ratio < 0.80

                            # Chi-squared approximation
                            total_n = sum(r[2] for r in rates)
                            total_approved = sum(r[3] for r in rates)
                            if total_n > 0 and total_approved > 0:
                                overall_rate = total_approved / total_n
                                chi2 = 0.0
                                for _, _, n, a in rates:
                                    expected = n * overall_rate
                                    exp_denied = n * (1 - overall_rate)
                                    if expected > 0 and exp_denied > 0:
                                        chi2 += ((a - expected) ** 2
                                                 / expected)
                                        chi2 += (((n - a) - exp_denied) ** 2
                                                 / exp_denied)
                                df = len(rates) - 1
                                # Approximate p-value from chi2 with df
                                # using Wilson-Hilferty approximation
                                if df > 0 and chi2 > 0:
                                    import math
                                    z = (((chi2 / df) ** (1.0 / 3))
                                         - (1 - 2.0 / (9 * df)))
                                    z /= math.sqrt(2.0 / (9 * df))
                                    # Normal CDF approximation
                                    di_p_value = round(
                                        0.5 * math.erfc(z / math.sqrt(2)),
                                        6,
                                    )
                                    di_significant = (
                                        worst_ratio < 0.80
                                        and (di_p_value or 1.0) < 0.05
                                    )

                            # Update fairness snapshot
                            cur.execute(
                                """UPDATE fairness_snapshots
                                   SET worst_ratio = %s,
                                       worst_group = %s,
                                       p_value = %s,
                                       statistically_significant = %s
                                   WHERE tenant_id = %s
                                     AND model_id = %s
                                     AND snapshot_at = (
                                         SELECT MAX(snapshot_at)
                                         FROM fairness_snapshots
                                         WHERE tenant_id = %s
                                           AND model_id = %s
                                     )""",
                                (worst_ratio, worst_group, di_p_value,
                                 di_significant, tenant_id, model_id,
                                 tenant_id, model_id),
                            )

            except Exception as e:
                logger.warning(
                    "Auto DI computation failed (non-fatal): %s", e
                )

        # ---------------------------------------------------------------
        # Generate alerts
        # ---------------------------------------------------------------
        generated_alerts = []

        if protected_in_decision:
            cols = ", ".join(
                "%s.%s" % (r[0] or "unknown", r[1] or "unknown")
                for r in protected_in_decision
            )
            generated_alerts.append({
                "severity": "critical",
                "source": "provenance_engine",
                "title": "Protected data used in model decision",
                "description": (
                    "ECOA violation: Protected attributes (%s) flow directly "
                    "into the model's decision DAG. The model must not use "
                    "race, gender, age, or other protected characteristics "
                    "as inputs to credit decisions. Compliance score reduced "
                    "by 25 points." % cols
                ),
                "model_id": model_id,
                "regulation": "ECOA",
            })

        if protected_assessed and not di_computed:
            generated_alerts.append({
                "severity": "warning",
                "source": "compliance_engine",
                "title": "Disparate impact ratio not computed",
                "description": (
                    "Protected attributes were detected but no disparate impact "
                    "ratio was computed. Run a full fairness analysis with outcome "
                    "data to assess compliance."
                ),
                "model_id": model_id,
                "regulation": "ECOA",
            })

        if di_computed and di_significant:
            generated_alerts.append({
                "severity": "critical",
                "source": "fairness_engine",
                "title": "Disparate impact confirmed (ratio %.3f)" % (
                    worst_ratio or 0,
                ),
                "description": (
                    "Four-fifths rule violation detected. Worst group: %s "
                    "with DI ratio %.4f (p=%.4f). Review model for ECOA "
                    "compliance before deployment."
                ) % (
                    worst_group or "unknown",
                    worst_ratio or 0,
                    di_p_value or 0,
                ),
                "model_id": model_id,
                "regulation": "ECOA",
            })

        if provenance_pipeline_id and row_value_count == 0:
            generated_alerts.append({
                "severity": "warning",
                "source": "compliance_engine",
                "title": "Value-level audit trail missing",
                "description": (
                    "Pipeline %s has no row-level value records. Enable value "
                    "tracking to maintain a complete audit trail for regulatory "
                    "examinations." % provenance_pipeline_id
                ),
                "model_id": model_id,
                "regulation": "SR 11-7",
            })

        # Also include any alerts explicitly provided in the request
        explicit_alerts = data.get("alerts") or []
        generated_alerts.extend(explicit_alerts)

        for alert in generated_alerts:
            cur.execute(
                """INSERT INTO alert_log
                   (tenant_id, severity, source, title, description, model_id, regulation)
                   VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                (
                    tenant_id,
                    alert.get("severity"),
                    alert.get("source"),
                    alert.get("title"),
                    alert.get("description"),
                    alert.get("model_id"),
                    alert.get("regulation"),
                ),
            )

        conn.commit()
        return jsonify({"ok": True}), 200
    except Exception:
        conn.rollback()
        logger.exception("Dashboard sync failed")
        return jsonify({"error": "sync failed"}), 500
    finally:
        _get_pool().putconn(conn)


# ---------------------------------------------------------------------------
# Server-Side Model Validation (/v1/validate)
# ---------------------------------------------------------------------------

def _deserialize_array(obj):
    """Reconstruct numpy/pandas objects from the client's serialization format.

    Handles: pandas DataFrames/Series, numpy arrays, sparse matrices, tensors, lists.
    """
    import numpy as np
    import pandas as pd

    if obj is None:
        return None

    arr_type = obj.get("type", "list")
    data = obj.get("data")

    if arr_type == "dataframe":
        return pd.DataFrame(**data)
    elif arr_type == "series":
        return pd.Series(data)
    elif arr_type == "ndarray":
        return np.array(data)
    elif arr_type == "sparse":
        # Sparse matrix converted to dense
        return np.array(data)
    elif arr_type == "tensor":
        # GPU tensor converted to numpy array
        return np.array(data)
    else:
        # Default: convert to numpy array
        return np.array(data)


@app.route("/v1/training", methods=["POST"])
@require_api_key
def training_upload():
    """
    Receive training data from wrapped model.fit() calls.

    Runs full compliance analysis on training data:
    - Fairness analysis (disparate impact)
    - SR 11-7 compliance
    - ECOA compliance
    - Stores results in database
    """
    try:
        tenant_id = g.tenant_id
        data = request.get_json()

        model_name = data.get("model_name", "unknown")
        model_version = data.get("model_version", "1.0.0")
        protected_columns = data.get("protected_columns", [])

        logger.info("Processing training data for %s v%s", model_name, model_version)

        # Deserialize model and data
        model_b64 = data.get("model_b64", "")
        if not model_b64:
            return jsonify({"error": "model_b64 required"}), 400

        model_bytes = base64.b64decode(model_b64)
        model = pickle.loads(model_bytes)

        # Deserialize training data
        import pandas as pd
        import numpy as np

        X = _deserialize_array(data.get("X"))
        y = _deserialize_array(data.get("y"))
        protected_data = _deserialize_array(data.get("protected_data"))

        if X is None or y is None:
            return jsonify({"error": "X and y required"}), 400

        # Convert to proper formats
        if not isinstance(X, pd.DataFrame):
            X = pd.DataFrame(X)
        if not isinstance(y, np.ndarray):
            y = np.array(y)

        # Split into train/test (80/20)
        from sklearn.model_selection import train_test_split
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Build protected_data
        if protected_data is not None:
            if isinstance(protected_data, pd.DataFrame):
                pass
            else:
                protected_data = pd.DataFrame(protected_data)
        elif isinstance(X_test, pd.DataFrame):
            available = [c for c in protected_columns if c in X_test.columns]
            protected_data = X_test[available] if available else pd.DataFrame()
        else:
            protected_data = pd.DataFrame()

        # Run full orchestration (reuse existing ModelOrchestrator)
        from ..api.orchestrator import ModelOrchestrator

        orchestrator = ModelOrchestrator(strict_mode=True)
        orch_result = orchestrator.validate_and_deploy(
            model_name=model_name,
            model_version=model_version,
            model=model,
            X_train=X_train,
            y_train=y_train,
            X_test=X_test,
            y_test=y_test,
            protected_data=protected_data,
            protected_columns=protected_columns,
            industry=data.get("metadata", {}).get("domain", "lending"),
            metadata=data.get("metadata", {}),
        )

        # Store results in database (reuse existing logic from /v1/validate)
        model_hash = hashlib.sha256(model_bytes).hexdigest()[:16]
        model_id = "%s_%s_%s" % (model_name, model_version, model_hash)
        now_iso = datetime.now(timezone.utc).isoformat()

        # Compute compliance score
        compliance_score = 100.0
        blocking_count = len(orch_result.blocking_findings)
        warning_count = len(orch_result.warning_findings)
        compliance_score -= blocking_count * 15
        compliance_score -= warning_count * 5
        compliance_score = max(0.0, min(100.0, compliance_score))

        findings = []
        for bf in orch_result.blocking_findings:
            desc = bf.get("description", "") if isinstance(bf, dict) else str(bf)
            if desc and desc not in findings:
                findings.append(desc)

        conn = _get_pool().getconn()
        try:
            cur = conn.cursor()

            # Store in model_snapshots
            cur.execute(
                """INSERT INTO model_snapshots
                   (tenant_id, model_id, name, version, tier, status, domain, owner,
                    compliance_score, last_validated, last_monitored,
                    validation_overdue, monitoring_overdue, finding_count)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                   ON CONFLICT (tenant_id, model_id) DO UPDATE SET
                   compliance_score = EXCLUDED.compliance_score,
                   last_validated = EXCLUDED.last_validated,
                   finding_count = EXCLUDED.finding_count""",
                (tenant_id, model_id, model_name, model_version, 1,
                 "approved" if orch_result.deployment_approved else "blocked",
                 data.get("metadata", {}).get("domain", "lending"),
                 data.get("metadata", {}).get("owner"),
                 compliance_score, now_iso, now_iso, False, False, len(findings))
            )

            # Store fairness results
            if orch_result.fairness_report:
                fr = orch_result.fairness_report
                cur.execute(
                    """INSERT INTO fairness_snapshots
                       (tenant_id, model_id, has_disparate_impact, worst_ratio,
                        worst_group, p_value, statistically_significant,
                        protected_attributes, sample_size_warnings, details)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    (tenant_id, model_id, fr.get("has_disparate_impact", False),
                     fr.get("worst_di_ratio"), fr.get("worst_di_group"),
                     fr.get("p_value"), fr.get("statistically_significant", False),
                     json.dumps(protected_columns), json.dumps(fr.get("sample_size_warnings", [])),
                     json.dumps(fr))
                )

            conn.commit()
        finally:
            _get_pool().putconn(conn)

        logger.info("✅ Training analysis complete for %s", model_name)

        service_url = os.environ.get("ATTESTANT_SERVICE_URL", "http://54.205.86.45")

        return jsonify({
            "success": True,
            "deployment_approved": orch_result.deployment_approved,
            "compliance_score": compliance_score,
            "findings": findings,
            "dashboard_url": f"{service_url}/client/models/{model_name}",
            "model_id": model_id
        }), 200

    except Exception as exc:
        logger.exception("Training upload failed for %s", model_name)
        return jsonify({
            "success": False,
            "error": str(exc)
        }), 500


@app.route("/v1/inference", methods=["POST"])
@require_api_key
def inference_upload():
    """
    Receive inference data from wrapped model.predict() calls.

    Analyzes predictions for fairness and stores individual predictions.
    """
    try:
        tenant_id = g.tenant_id
        data = request.get_json()

        model_name = data.get("model_name", "unknown")
        model_version = data.get("model_version", "1.0.0")
        batch_id = data.get("batch_id", f"batch_{int(time.time())}")
        protected_columns = data.get("protected_columns", [])

        logger.info("Processing inference data for %s v%s (batch: %s)", model_name, model_version, batch_id)

        # Deserialize data
        import pandas as pd
        import numpy as np

        X_production = _deserialize_array(data.get("X_production"))
        predictions = _deserialize_array(data.get("predictions"))
        protected_data = _deserialize_array(data.get("protected_data"))

        if X_production is None or predictions is None:
            return jsonify({"error": "X_production and predictions required"}), 400

        # Convert predictions to binary if needed
        if isinstance(predictions, np.ndarray) and len(predictions.shape) == 2:
            # Probabilities - convert to binary
            predictions_binary = (predictions[:, 1] >= 0.5).astype(int).tolist() if predictions.shape[1] == 2 else predictions.argmax(axis=1).tolist()
        else:
            predictions_binary = list(predictions)

        # Analyze fairness
        fairness_metrics = {}
        if protected_data is not None and len(protected_columns) > 0:
            if not isinstance(protected_data, pd.DataFrame):
                protected_data = pd.DataFrame(protected_data)

            for col in protected_columns:
                if col not in protected_data.columns:
                    continue

                groups = protected_data[col].unique()
                if len(groups) < 2:
                    continue

                # Calculate approval rates by group
                approval_rates = {}
                for group in groups:
                    mask = protected_data[col] == group
                    group_preds = [predictions_binary[i] for i in range(len(predictions_binary)) if mask.iloc[i]]
                    if len(group_preds) > 0:
                        approval_rates[str(group)] = sum(group_preds) / len(group_preds)

                if len(approval_rates) >= 2:
                    max_rate = max(approval_rates.values())
                    min_rate = min(approval_rates.values())
                    di_ratio = min_rate / max_rate if max_rate > 0 else 0

                    fairness_metrics[col] = {
                        "approval_rates": approval_rates,
                        "disparate_impact_ratio": di_ratio,
                        "has_disparate_impact": di_ratio < 0.80
                    }

        # Store in database
        model_bytes = base64.b64decode(data.get("model_b64", ""))
        model_hash = hashlib.sha256(model_bytes).hexdigest()[:16] if model_bytes else "unknown"

        conn = _db()
        with conn.cursor() as cur:
            # Find or create pipeline record
            cur.execute("""
                SELECT id FROM pipeline_stats
                WHERE tenant_id = %s AND pipeline_name = %s AND model_hash = %s
            """, (tenant_id, model_name, model_hash))
            row = cur.fetchone()

            if row:
                pipeline_id = row[0]
                cur.execute("""
                    UPDATE pipeline_stats
                    SET last_used_at = NOW(), case_count = case_count + %s
                    WHERE id = %s
                """, (len(predictions_binary), pipeline_id))
            else:
                cur.execute("""
                    INSERT INTO pipeline_stats
                    (tenant_id, pipeline_name, model_hash, case_count, last_used_at, created_at, metadata)
                    VALUES (%s, %s, %s, %s, NOW(), NOW(), %s)
                    RETURNING id
                """, (tenant_id, model_name, model_hash, len(predictions_binary),
                      json.dumps({"type": "INFERENCE", "model_version": model_version, "batch_id": batch_id})))
                pipeline_id = cur.fetchone()[0]

            # Store individual predictions
            for i, pred in enumerate(predictions_binary):
                decision = "approved" if pred == 1 else "denied"
                score = float(predictions[i]) if isinstance(predictions[i], (int, float)) else float(pred)

                cur.execute("""
                    INSERT INTO pipeline_row_results
                    (tenant_id, pipeline_id, row_index, decision, score, timestamp)
                    VALUES (%s, %s, %s, %s, %s, NOW())
                """, (tenant_id, pipeline_id, i, decision, score))

            conn.commit()

        logger.info("✅ Stored %d predictions for %s", len(predictions_binary), model_name)

        service_url = os.environ.get("ATTESTANT_SERVICE_URL", "http://54.205.86.45")

        return jsonify({
            "success": True,
            "total_predictions": len(predictions_binary),
            "approval_rate": sum(predictions_binary) / len(predictions_binary) if len(predictions_binary) > 0 else 0.0,
            "fairness_metrics": fairness_metrics,
            "dashboard_url": f"{service_url}/client/pipelines/{pipeline_id}",
            "batch_id": batch_id
        }), 200

    except Exception as exc:
        logger.exception("Inference upload failed for %s", model_name)
        return jsonify({
            "success": False,
            "error": str(exc)
        }), 500


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )

    if not DSN:
        print("ERROR: Set ATTESTANT_DSN or DASH_WRITER_DSN to your PostgreSQL connection string")
        print("  Example: ATTESTANT_DSN=postgresql://user:pass@localhost/attestant python -m attestant.api.server")
        raise SystemExit(1)

    _ensure_schema()
    logger.info("Attestant API server starting on port %d", API_PORT)

    app.run(host="0.0.0.0", port=API_PORT, debug=False)


if __name__ == "__main__":
    main()
