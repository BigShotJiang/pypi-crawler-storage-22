"""
Rate Limiting for Attestant API

Implements tiered rate limiting with excellent UX:
- Standard: 100 requests/minute
- Premium: 500 requests/minute
- Enterprise: Unlimited

Features:
- Helpful error messages with upgrade information
- Automatic cleanup of old records
- Redis-compatible (falls back to PostgreSQL)
"""

import time
from typing import Optional, Tuple
from functools import wraps
from flask import request, jsonify
import psycopg2

# Rate limit tiers (requests per minute)
RATE_LIMITS = {
    "standard": 100,
    "premium": 500,
    "enterprise": float("inf"),
}


class RateLimiter:
    """PostgreSQL-backed rate limiter with tiered limits"""

    def __init__(self, db_conn):
        self.db_conn = db_conn

    def check_limit(
        self, api_key_id: str, endpoint: str, tier: str = "standard"
    ) -> Tuple[bool, Optional[str]]:
        """
        Check if request is within rate limit.

        Returns:
            (allowed: bool, error_message: Optional[str])
        """
        limit = RATE_LIMITS.get(tier, 100)

        if limit == float("inf"):
            return True, None

        window_start = time.time() - 60  # 1 minute window

        with self.db_conn.cursor() as cur:
            # Get current request count in this window
            cur.execute(
                """
                SELECT request_count
                FROM api_rate_limits
                WHERE api_key_id = %s
                  AND endpoint = %s
                  AND window_start > to_timestamp(%s)
                """,
                (api_key_id, endpoint, window_start),
            )
            row = cur.fetchone()
            current_count = row[0] if row else 0

            if current_count >= limit:
                # Rate limit exceeded
                wait_seconds = int(60 - (time.time() - window_start))
                error_msg = self._format_error_message(tier, limit, wait_seconds)
                return False, error_msg

            # Increment counter
            cur.execute(
                """
                INSERT INTO api_rate_limits (api_key_id, endpoint, window_start, request_count, last_request_at)
                VALUES (%s, %s, to_timestamp(%s), 1, NOW())
                ON CONFLICT (api_key_id, endpoint, window_start)
                DO UPDATE SET
                    request_count = api_rate_limits.request_count + 1,
                    last_request_at = NOW()
                """,
                (api_key_id, endpoint, time.time()),
            )
            self.db_conn.commit()

        return True, None

    def _format_error_message(
        self, tier: str, limit: int, wait_seconds: int
    ) -> str:
        """Format helpful error message with upgrade information"""
        msg = f"Rate limit exceeded: {limit} requests/minute ({tier} tier). "
        msg += f"Please wait {wait_seconds} seconds or upgrade your plan:\n\n"

        if tier == "standard":
            msg += "• Premium tier: 500 requests/minute - $99/month\n"
            msg += "• Enterprise tier: Unlimited requests - Custom pricing\n"
        elif tier == "premium":
            msg += "• Enterprise tier: Unlimited requests - Custom pricing\n"

        msg += "\nContact sales@attestant.ai to upgrade."
        return msg

    def cleanup_old_records(self):
        """Remove rate limit records older than 24 hours"""
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                DELETE FROM api_rate_limits
                WHERE window_start < NOW() - INTERVAL '24 hours'
                """
            )
            self.db_conn.commit()


def check_rate_limit(api_key_id: str, endpoint: str, tier: str, db_conn) -> Tuple[bool, Optional[str]]:
    """
    Standalone rate limit check function.

    Returns:
        (allowed: bool, error_message: Optional[str])
    """
    limiter = RateLimiter(db_conn)
    return limiter.check_limit(api_key_id, endpoint, tier)


def rate_limit(db_conn_getter):
    """
    Flask decorator for rate limiting endpoints.

    Usage:
        @app.route("/api/endpoint")
        @rate_limit(lambda: get_db_connection())
        def my_endpoint():
            ...
    """

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Extract API key from request
            api_key = request.headers.get("X-API-Key")
            if not api_key:
                return jsonify({"error": "Missing API key"}), 401

            # Get tier from database
            db_conn = db_conn_getter()
            with db_conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT key_id, rate_limit_tier
                    FROM api_keys
                    WHERE key_prefix = %s
                      AND revoked_at IS NULL
                      AND (expires_at IS NULL OR expires_at > NOW())
                    """,
                    (api_key[:10],),
                )
                row = cur.fetchone()

            if not row:
                return jsonify({"error": "Invalid or expired API key"}), 401

            api_key_id, tier = row

            # Check rate limit
            allowed, error_msg = check_rate_limit(
                api_key_id, request.endpoint, tier, db_conn
            )

            if not allowed:
                return jsonify({"error": error_msg}), 429

            return f(*args, **kwargs)

        return decorated_function

    return decorator
