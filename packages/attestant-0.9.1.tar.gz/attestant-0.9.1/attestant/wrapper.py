"""
Model wrapper for automatic attestant tracking.

Wraps ML models to automatically capture training and inference data,
upload to backend for analysis, with minimal client code changes.
"""

import logging
import threading
import queue
import time
from typing import Any, List, Optional, Dict
import json
import base64
import pickle
import urllib.request
import urllib.error

logger = logging.getLogger(__name__)


class ModelWrapper:
    """
    Wraps a model to automatically capture fit() and predict() calls.

    Usage:
        model = ModelWrapper(
            original_model,
            model_name="loan_approval",
            protected_columns=["race", "gender"],
            api_key="pvt_live_...",
            service_url="http://54.205.86.45"
        )

        # Use normally
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
    """

    def __init__(
        self,
        model: Any,
        model_name: str,
        protected_columns: List[str],
        api_key: str,
        service_url: str = "http://54.205.86.45",
        model_version: str = "1.0.0",
        **metadata
    ):
        self._model = model
        self._model_name = model_name
        self._protected_columns = protected_columns
        self._api_key = api_key
        self._service_url = service_url
        self._model_version = model_version
        self._metadata = metadata

        # Upload queue for async uploads
        self._upload_queue = queue.Queue()
        self._upload_thread = threading.Thread(target=self._upload_worker, daemon=True)
        self._upload_thread.start()

        # Track if training data has been captured
        self._training_captured = False

    def fit(self, X, y=None, **kwargs):
        """Intercept fit() call, capture data, upload to backend."""
        # Call original fit
        result = self._model.fit(X, y, **kwargs)

        # Capture training data (first time only)
        if not self._training_captured:
            self._training_captured = True
            self._queue_training_upload(X, y)

        return self

    def predict(self, X, **kwargs):
        """Intercept predict() call, capture data, upload to backend."""
        # Call original predict
        predictions = self._model.predict(X, **kwargs)

        # Capture inference data
        self._queue_inference_upload(X, predictions)

        return predictions

    def predict_proba(self, X, **kwargs):
        """Intercept predict_proba() call."""
        probas = self._model.predict_proba(X, **kwargs)

        # Capture inference data (use probabilities)
        self._queue_inference_upload(X, probas)

        return probas

    def score(self, X, y, **kwargs):
        """Pass through to original model."""
        return self._model.score(X, y, **kwargs)

    def __getattr__(self, name):
        """Pass through any other methods to original model."""
        return getattr(self._model, name)

    def _queue_training_upload(self, X, y):
        """Queue training data for async upload."""
        try:
            import pandas as pd
            import numpy as np

            # Extract protected data if available
            protected_data = None
            if isinstance(X, pd.DataFrame):
                available_cols = [c for c in self._protected_columns if c in X.columns]
                if available_cols:
                    protected_data = X[available_cols]

            payload = {
                "type": "training",
                "model_name": self._model_name,
                "model_version": self._model_version,
                "X": X,
                "y": y,
                "protected_data": protected_data,
                "protected_columns": self._protected_columns,
                "metadata": self._metadata,
                "model": self._model
            }

            self._upload_queue.put(payload)
            logger.info(f"Queued training data for {self._model_name}")

        except Exception as e:
            logger.error(f"Error queuing training upload: {e}")

    def _queue_inference_upload(self, X, predictions):
        """Queue inference data for async upload."""
        try:
            import pandas as pd

            # Extract protected data if available
            protected_data = None
            if isinstance(X, pd.DataFrame):
                available_cols = [c for c in self._protected_columns if c in X.columns]
                if available_cols:
                    protected_data = X[available_cols]

            payload = {
                "type": "inference",
                "model_name": self._model_name,
                "model_version": self._model_version,
                "X": X,
                "predictions": predictions,
                "protected_data": protected_data,
                "protected_columns": self._protected_columns,
                "metadata": self._metadata,
                "model": self._model
            }

            self._upload_queue.put(payload)
            logger.debug(f"Queued {len(X)} predictions for {self._model_name}")

        except Exception as e:
            logger.error(f"Error queuing inference upload: {e}")

    def _upload_worker(self):
        """Background worker that processes upload queue."""
        while True:
            try:
                # Get item from queue (blocking)
                payload = self._upload_queue.get(timeout=1)

                if payload["type"] == "training":
                    self._upload_training(payload)
                elif payload["type"] == "inference":
                    self._upload_inference(payload)

                self._upload_queue.task_done()

            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Upload worker error: {e}")
                time.sleep(1)  # Backoff on error

    def _upload_training(self, payload):
        """Upload training data to backend."""
        try:
            import pandas as pd
            import numpy as np

            # Serialize model
            model_bytes = pickle.dumps(payload["model"])
            model_b64 = base64.b64encode(model_bytes).decode('utf-8')

            # Serialize data
            def serialize_array(arr):
                if arr is None:
                    return None
                if isinstance(arr, pd.DataFrame):
                    return {"type": "dataframe", "data": arr.to_dict(orient='split')}
                elif isinstance(arr, pd.Series):
                    return {"type": "series", "data": arr.tolist()}
                elif isinstance(arr, np.ndarray):
                    return {"type": "ndarray", "data": arr.tolist()}
                else:
                    return {"type": "list", "data": list(arr)}

            request_payload = {
                "model_name": payload["model_name"],
                "model_version": payload["model_version"],
                "model_b64": model_b64,
                "model_serialization_method": "pickle",
                "X": serialize_array(payload["X"]),
                "y": serialize_array(payload["y"]),
                "protected_data": serialize_array(payload["protected_data"]),
                "protected_columns": payload["protected_columns"],
                "metadata": payload["metadata"]
            }

            body = json.dumps(request_payload).encode('utf-8')
            req = urllib.request.Request(
                f"{self._service_url}/v1/training",
                data=body,
                method="POST",
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
            )

            with urllib.request.urlopen(req, timeout=300) as resp:
                result = json.loads(resp.read().decode('utf-8'))
                logger.info(f"✅ Training data uploaded for {payload['model_name']}")

        except Exception as e:
            logger.error(f"Failed to upload training data: {e}")

    def _upload_inference(self, payload):
        """Upload inference data to backend."""
        try:
            import pandas as pd
            import numpy as np
            from datetime import datetime

            # Serialize model
            model_bytes = pickle.dumps(payload["model"])
            model_b64 = base64.b64encode(model_bytes).decode('utf-8')

            # Serialize data
            def serialize_array(arr):
                if arr is None:
                    return None
                if isinstance(arr, pd.DataFrame):
                    return {"type": "dataframe", "data": arr.to_dict(orient='split')}
                elif isinstance(arr, pd.Series):
                    return {"type": "series", "data": arr.tolist()}
                elif isinstance(arr, np.ndarray):
                    return {"type": "ndarray", "data": arr.tolist()}
                else:
                    return {"type": "list", "data": list(arr)}

            # Generate batch_id
            batch_id = f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

            request_payload = {
                "model_name": payload["model_name"],
                "model_version": payload["model_version"],
                "model_b64": model_b64,
                "model_serialization_method": "pickle",
                "X_production": serialize_array(payload["X"]),
                "predictions": serialize_array(payload["predictions"]),
                "protected_data": serialize_array(payload["protected_data"]),
                "protected_columns": payload["protected_columns"],
                "batch_id": batch_id,
                "metadata": payload["metadata"]
            }

            body = json.dumps(request_payload).encode('utf-8')
            req = urllib.request.Request(
                f"{self._service_url}/v1/inference",
                data=body,
                method="POST",
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
            )

            with urllib.request.urlopen(req, timeout=300) as resp:
                result = json.loads(resp.read().decode('utf-8'))
                logger.debug(f"✅ Inference data uploaded for {payload['model_name']}")

        except Exception as e:
            logger.error(f"Failed to upload inference data: {e}")
