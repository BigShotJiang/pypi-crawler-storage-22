"""Parser definitions for setup commands.

Copyright 2025 Smart-AI-Memory
Licensed under the Apache License, Version 2.0
"""

from ..commands import setup


def register_parsers(subparsers):
    """Register setup command parsers.

    Args:
        subparsers: ArgumentParser subparsers object from main parser
    """
    # Init command
    parser_init = subparsers.add_parser(
        "init",
        help="Initialize a new Attune AI project",
    )
    parser_init.add_argument(
        "--format",
        choices=["yaml", "json"],
        default="yaml",
        help="Configuration format (default: yaml)",
    )
    parser_init.add_argument(
        "--output",
        help="Output file path (default: attune.config.{format})",
    )
    parser_init.set_defaults(func=setup.cmd_init)

    # Validate command
    parser_validate = subparsers.add_parser(
        "validate",
        help="Validate a configuration file",
    )
    parser_validate.add_argument(
        "config",
        help="Path to configuration file to validate",
    )
    parser_validate.set_defaults(func=setup.cmd_validate)

    # Setup wizard command
    parser_setup = subparsers.add_parser(
        "setup",
        help="Interactive setup workflow for first-time configuration",
    )
    parser_setup.set_defaults(func=setup.cmd_setup)
