# ATX Guardrails

**Enterprise-Grade AI Guardrails & Evaluation Platform**

`atx-guardrails` is a unified library designed to secure, manage, and evaluate your Large Language Model (LLM) applications. It provides three core pillars of functionality:

1.  **AI Evaluation**: State-of-the-art metrics to validate agent performance (Response Relevance, Task Success, Param Correctness, etc.).
2.  **Prompt Firewall**: Real-time protection against jailbreaks, harmful content, and PII leakage.
3.  **RBAC (Role-Based Access Control)**: Secure Retrieval Augmented Generation (RAG) with granular document-level permissioning.

---

## Installation

```bash
pip install atx-guardrails
```

---

## Getting Started

ATX Guardrails is a managed service. To get started:

1. **Install** the library using `pip install atx-guardrails`
2. **Contact ATX Labs** at **hello@atxlabs.ai** to receive your authentication credentials and endpoint configuration
3. **Configure** your environment with the provided `.env` file
4. **Start building** with the clients provided below

---

## Platform Capabilities

### 1. AI Evaluation

A comprehensive suite of metrics to validate, benchmark, and monitor the performance of your LLM agents and pipelines.

| Metric | What It Measures |
|---|---|
| **Response Relevance** | How directly and accurately the output addresses the input query |
| **Task Success** | Whether the agent successfully completed the requested task |
| **Tool Correctness** | Whether the agent invoked the right tools in the right sequence |
| **Param Correctness** | Whether the arguments passed to tools are valid and match user intent |
| **G-Eval** | Custom criteria evaluation — define your own rubric and scoring logic |
| **CEP (Conditional Evaluation Pipeline)** | Multi-step, branching evaluation flows for complex agent workflows |

**Key Features:**
- Agent-level tracking with `agent_name` tagging
- Automatic server-side logging of all evaluation results
- Configurable thresholds for pass/fail determination
- Support for custom evaluation steps and criteria

---

### 2. Prompt Firewall

Real-time protection layer that sits between your users and your LLM, filtering out harmful, malicious, or policy-violating prompts before they reach your model.

**Protects Against:**
- Prompt injection and jailbreak attempts
- Requests for harmful or dangerous content
- Social engineering and manipulation tactics
- PII leakage and data exfiltration

---

### 3. RBAC (Role-Based Access Control)

Secure your Retrieval Augmented Generation (RAG) pipelines with granular, document-level access control. Ensure users only receive answers based on information they are authorized to access.

**Key Features:**
- Role-based document permissioning via simple YAML configuration
- Automatic document syncing and indexing
- Per-user query filtering based on assigned roles
- Built-in telemetry and access monitoring

---

## Why ATX Guardrails?

- **All-in-One Platform** — Evaluation, Security, and Access Control in a single library
- **Simple Integration** — Drop-in Python client, no infrastructure to manage
- **Enterprise Ready** — Token-based auth, audit logging, role-based access

---

## Contact

For access credentials, or a demo:

**Technical Whitepaper** available upon request for detailed documentation.

📧 **hello@atxlabs.ai**

---

## License

Proprietary — ATX Labs. All rights reserved.
