import os
from typing import Any, Dict, List, Optional
from .BaseAPIClient import BaseAPIClient

class AIEvalClient(BaseAPIClient):
    def __init__(self, base_url: Optional[str] = None, token: Optional[str] = None, timeout: int = 60):
        # AI Eval might take longer, so default timeout is increased
        default_url = base_url or os.getenv("ATX_AI_EVAL_ENDPOINT")
        super().__init__(
            default_url, 
            token, 
            base_url_env="ATX_AI_EVAL_ENDPOINT", 
            token_env="ATX_GDRL_TOKEN", 
            timeout=timeout
        )

    def task_success(self, input_text: str, actual_output: str, threshold: float = 0.5, token: Optional[str] = None, agent_name: Optional[str] = None, tools_called: Optional[List[Dict[str, Any]]] = None, expected_tools: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        payload = {
            "input": input_text, 
            "actual_output": actual_output, 
            "threshold": threshold,
            "token": token or self.token,
            "agent_name": agent_name,
            "tools_called": tools_called,
            "expected_tools": expected_tools
        }
        return self._post("/evaluate/task-success", json_data=payload)

    def param_correctness(self, input_text: str, actual_output: str, threshold: float = 0.5, token: Optional[str] = None, agent_name: Optional[str] = None, tools_called: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        payload = {
            "input": input_text, 
            "actual_output": actual_output, 
            "threshold": threshold,
            "token": token or self.token,
            "agent_name": agent_name,
            "tools_called": tools_called
        }
        return self._post("/evaluate/param-correctness", json_data=payload)

    def tool_correctness(self, input_text: str, actual_output: str, threshold: float = 0.5, token: Optional[str] = None, agent_name: Optional[str] = None, tools_called: Optional[List[Dict[str, Any]]] = None, expected_tools: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        payload = {
            "input": input_text, 
            "actual_output": actual_output, 
            "threshold": threshold,
            "token": token or self.token,
            "agent_name": agent_name,
            "tools_called": tools_called,
            "expected_tools": expected_tools
        }
        return self._post("/evaluate/tool-correctness", json_data=payload)

    def response_relevance(self, input_text: str, actual_output: str, threshold: float = 0.5, token: Optional[str] = None, agent_name: Optional[str] = None) -> Dict[str, Any]:
        payload = {
            "input": input_text, 
            "actual_output": actual_output, 
            "threshold": threshold,
            "token": token or self.token,
            "agent_name": agent_name
        }
        return self._post("/evaluate/response-relevance", json_data=payload)

    def geval(self, input_text: str, actual_output: str, name: str, criteria: str, threshold: float = 0.5, token: Optional[str] = None, agent_name: Optional[str] = None, evaluation_steps: Optional[List[str]] = None) -> Dict[str, Any]:
        payload = {
            "input": input_text,
            "actual_output": actual_output,
            "name": name,
            "criteria": criteria,
            "threshold": threshold,
            "token": token or self.token,
            "agent_name": agent_name,
            "evaluation_steps": evaluation_steps
        }
        return self._post("/evaluate/geval", json_data=payload)

    def cep(self, input_text: str, actual_output: str, threshold: float = 0.5, token: Optional[str] = None, agent_name: Optional[str] = None, cep_config: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        payload = {
            "input": input_text, 
            "actual_output": actual_output, 
            "threshold": threshold,
            "token": token or self.token,
            "agent_name": agent_name,
            "cep_config": cep_config
        }
        return self._post("/evaluate/cep", json_data=payload)
