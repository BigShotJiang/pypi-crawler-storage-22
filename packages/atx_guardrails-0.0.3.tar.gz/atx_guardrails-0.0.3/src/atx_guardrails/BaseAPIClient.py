import os
import requests
from typing import Any, Dict, Optional
import platform
import json
import subprocess
from pathlib import Path

class BaseAPIClient:
    """
    Base class for API clients that need base_url + token management.
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        base_url_env: str = "ATX_GDRL_ENDPOINT",
        token_env: str = "ATX_GDRL_TOKEN",
        timeout: int = 30,
        persist: bool = True, 
        config_path = ".config.json"
    ) -> None:
        """
        Initialize the API client.

        Args:
            base_url (Optional[str]): Base URL for API. Defaults to env var.
            token (Optional[str]): Authentication token. Defaults to env var.
            base_url_env (str): Env variable name for base URL.
            token_env (str): Env variable name for token.
            timeout (int): Request timeout in seconds.
        """
        self.base_url_env = base_url_env
        self.token_env = token_env

        self.base_url = (base_url or os.getenv(self.base_url_env, "")).rstrip("/")
        self.token = token or os.getenv(self.token_env)
        self.timeout = timeout

        if not self.base_url:
            raise ValueError(f"Base URL not provided and {self.base_url_env} not set.")
        if not self.token:
            raise ValueError(f"Token not provided and {self.token_env} not set.")

        # Persist values to environment for consistency
        os.environ[self.base_url_env] = self.base_url
        os.environ[self.token_env] = self.token

        
        if persist:
            self._persist_env(self.base_url_env, self.base_url)
            self._persist_env(self.token_env, self.token)

        if not os.path.exists(config_path):
            self.config = {}
        else:
            self.config = self._load_config(config_path)

        if 'rbac' not in self.config:
            self.config['rbac'] = {}
        if 'firewall' not in self.config:
            self.config['firewall'] = {}
        if 'pii' not in self.config:
            self.config['pii'] = {}
        if 'create_collection' not in self.config['rbac']:
            self.config['rbac']['create_collection'] = True

        self._save_config(config_path)

    # -----------------
    # HTTP helpers
    # -----------------       

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from a JSON file."""
        config_file = Path(config_path)
        if config_file.exists():
            with open(config_file, "r") as f:
                return json.load(f)
        return {}
    
    def _save_config(self, config_path: str) -> None:
        """Save configuration to a JSON file."""
        config_file = Path(config_path)
        with open(config_file, "w") as f:
            json.dump(self.config, f, indent=4)

    def _persist_env(self, key: str, value: str):
        system = platform.system()
        if system == "Windows":
            # permanently set for current user
            subprocess.run(["setx", key, value], check=True)
        else:
            # append to ~/.bashrc
            bashrc = Path.home() / ".bashrc"
            export_line = f'export {key}="{value}"\n'
            with open(bashrc, "a") as f:
                f.write(export_line)
            # also update current process
            os.environ[key] = value

    def _post(self, path: str, data: Optional[Dict[str, Any]] = None,
              json_data: Optional[Dict[str, Any]] = None,
              files: Optional[Dict[str, Any]] = None,
              params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Helper for POST requests."""
        url = f"{self.base_url}{path}"
        try:
            resp = requests.post(
                url,
                data=data,
                json=json_data,
                files=files,
                params=params,
                timeout=self.timeout,
            )
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"POST {url} failed: {e}") from e

    def _put(self, path: str, data: Optional[Dict[str, Any]] = None,
             files: Optional[Dict[str, Any]] = None,
             params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Helper for PUT requests."""
        url = f"{self.base_url}{path}"
        try:
            resp = requests.put(url, data=data, files=files, params=params, timeout=self.timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"PUT {url} failed: {e}") from e

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Helper for GET requests."""
        url = f"{self.base_url}{path}"
        try:
            resp = requests.get(url, params=params, timeout=self.timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"GET {url} failed: {e}") from e
