from typing import Any, Dict, Optional
from .BaseAPIClient import BaseAPIClient

class FirewallClient(BaseAPIClient):
    def __init__(self, base_url: Optional[str] = None, token: Optional[str] = None, timeout: int = 30):
        super().__init__(base_url, token, base_url_env="ATX_GDRL_ENDPOINT", token_env="ATX_GDRL_TOKEN", timeout=timeout)

    def validate_token(self, token: Optional[str] = None) -> Dict[str, Any]:
        payload = {"token": token or self.token}
        return self._post("/firewall/validate-token", json_data=payload)

    def chat(self, prompt: str, token: Optional[str] = None) -> Dict[str, Any]:
        payload = {"prompt": prompt, "token": token or self.token}
        return self._post("/firewall/chat", json_data=payload)
