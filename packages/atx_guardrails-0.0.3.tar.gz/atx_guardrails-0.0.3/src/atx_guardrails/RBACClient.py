import os
import zipfile
import tempfile
from pathlib import Path
from typing import List, Dict, Any, Optional
from .BaseAPIClient import BaseAPIClient

class RBACClient(BaseAPIClient):
    """
    Client for interacting with the RBAC FastAPI backend.
    Requires:
      - folder containing:
          ├── documents/ (with one or more subfolders)
          ├── roles_config.yaml
          └── users_config.yaml
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        folder: Optional[str] = None,
        timeout: int = 30,
    ) -> None:
        super().__init__(
            base_url,
            token,
            base_url_env="ATX_GDRL_ENDPOINT",
            token_env="ATX_GDRL_TOKEN",
            timeout=timeout,
        )

        self.folder = folder or os.getenv("ATX_RBAC_FOLDER", "")
        if not self.folder:
            raise ValueError("Folder not provided and ATX_RBAC_FOLDER not set.")

        os.environ["ATX_RBAC_FOLDER"] = self.folder
        self._persist_env("ATX_RBAC_FOLDER", self.folder)

        self.validate_structure(self.folder)

        if self.config['rbac'].get('create_collection', False):
            self.create_collection()
            self.config['rbac']['create_collection'] = False
            self._save_config(".config.json")
    # -----------------
    # Validation
    # -----------------

    @staticmethod
    def validate_structure(folder: str) -> None:
        """Ensure folder follows the expected RBAC structure."""
        folder_path = Path(folder)
        if not folder_path.is_dir():
            raise ValueError(f"{folder} is not a valid directory")

        documents_path = folder_path / "documents"
        if not documents_path.exists() or not documents_path.is_dir():
            raise ValueError("Missing 'documents' folder")

        if not any(documents_path.iterdir()):
            raise ValueError("'documents' folder must contain at least one subfolder")

        if not (folder_path / "roles_config.yaml").exists():
            raise ValueError("roles_config.yaml file is missing")
        if not (folder_path / "users_config.yaml").exists():
            raise ValueError("users_config.yaml file is missing")

    # -----------------
    # Helpers
    # -----------------

    @staticmethod
    def _make_zip_from_subfolders(folder: str) -> str:
        folder_path = Path(folder)
        tmp_fd, tmp_zip = tempfile.mkstemp(suffix=".zip")
        os.close(tmp_fd)

        with zipfile.ZipFile(tmp_zip, "w", zipfile.ZIP_DEFLATED) as zipf:
            documents_path = folder_path / "documents"
            if not documents_path.exists() or not documents_path.is_dir():
                raise ValueError("Expected a 'documents' subfolder inside the folder")

            for subfolder in documents_path.iterdir():
                if subfolder.is_dir():
                    for root, _, files in os.walk(subfolder):
                        for file in files:
                            file_path = Path(root) / file
                            # Archive relative to 'documents' (NOT parent)
                            arcname = file_path.relative_to(documents_path)
                            zipf.write(file_path, arcname)
        return tmp_zip



    def _prepare_files(self, folder: str) -> Dict[str, Any]:
        """Package documents + configs into request-ready files."""
        self.validate_structure(folder)
        zip_file = self._make_zip_from_subfolders(folder)
        folder_path = Path(folder)

        files = {
            "zip_file": open(zip_file, "rb"),
            "roles_config": open(folder_path / "roles_config.yaml", "rb"),
            "users_config": open(folder_path / "users_config.yaml", "rb"),
        }
        return files

    def _finalize_request(self, files: Dict[str, Any], resp: Dict[str, Any], zip_file: str) -> Dict[str, Any]:
        """Close and cleanup temp files after request."""
        for f in files.values():
            try:
                f.close()
            except Exception:
                pass
        if os.path.exists(zip_file):
            os.remove(zip_file)
        return resp

    # -----------------
    # Collection Methods
    # -----------------

    def create_collection(self) -> Dict[str, Any]:
        files = self._prepare_files(self.folder)
        zip_file = files["zip_file"].name
        resp = self._post("/rbac/collections/create", data={"token": self.token}, files=files)
        return self._finalize_request(files, resp, zip_file)

    def recreate_collection(self) -> Dict[str, Any]:
        # files = self._prepare_files(self.folder)s
        zip_file = files["zip_file"].name
        resp = self._post("/rbac/collections/recreate", data={"token": self.token})
        return self._finalize_request(files, resp, zip_file)

    def update_collection(self) -> Dict[str, Any]:
        files = self._prepare_files(self.folder)
        zip_file = files["zip_file"].name
        resp = self._put("/collections/update", params={"token": self.token}, files=files)
        return self._finalize_request(files, resp, zip_file)

    # -----------------
    # Query & Telemetry
    # -----------------

    def query(self, user: str, query: str) -> Dict[str, Any]:
        return self._post("/rbac/query", data={"user": user, "query": query, "token": self.token})

    def get_telemetry(self, mode: str = "all", n: Optional[int] = None) -> Dict[str, Any]:
        params = {"token": self.token, "mode": mode}
        if n is not None:
            params["n"] = n
        return self._get("/rbac/telemetry", params=params)
