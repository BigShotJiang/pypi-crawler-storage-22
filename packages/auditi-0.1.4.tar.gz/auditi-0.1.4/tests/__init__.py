"""Tests for Auditi SDK"""
