# 🧬 Aura Hive Google Shim for Betterproto
from betterproto.lib.google import protobuf
