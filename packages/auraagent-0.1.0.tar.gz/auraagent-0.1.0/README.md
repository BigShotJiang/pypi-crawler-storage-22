# Aura

Carbon tracking and monitoring toolkit for AI engineers.

## Composants

| Composant | Description |
|-----------|-------------|
| `aura.carbon` | Mesure d'émissions CO2 (wrapper CodeCarbon) |
| `aura.web` | Interface web locale (FastAPI) |
| `aura.core` | Utilitaires partagés (config, auth, models) |

## Installation

```bash
# Depuis GitHub Packages
pip install aura --index-url https://pip.pkg.github.com/cevia

# Avec le composant web
pip install "aura[web]" --index-url https://pip.pkg.github.com/cevia
```

## Usage rapide

```python
from aura.carbon import AuraCarbon

# Context manager
with AuraCarbon() as tracker:
    train_model()

# Decorator
from aura.carbon import track_emissions

@track_emissions()
def train_model():
    pass
```

## Interface web locale

```bash
aura-web
# Ouvre http://localhost:8765 dans le navigateur
```

## Structure

```
aura/
├── carbon/          # Mesure CO2
│   ├── tracker.py   # AuraCarbon (wrapper CodeCarbon)
│   ├── output.py    # AuraOutput (envoi vers serveur)
│   └── decorators.py
├── web/             # Interface locale
│   ├── main.py      # Point d'entrée (FastAPI + navigateur)
│   ├── app.py       # Application FastAPI
│   ├── routers/     # Endpoints
│   ├── services/    # Logique métier
│   └── templates/   # HTML
└── core/            # Partagé
    ├── config.py    # ~/.aura.config
    ├── auth.py      # Auth serveur
    ├── models.py    # Modèles Pydantic
    └── exceptions.py
```

## Licence

MIT — CEVIA
