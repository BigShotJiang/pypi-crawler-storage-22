"""
Aura — Carbon tracking and monitoring toolkit.

Composants disponibles :
    - aura.carbon  : Mesure d'émissions CO2 (wrapper CodeCarbon)
    - aura.web     : Interface web locale (FastAPI)
    - aura.core    : Utilitaires partagés (config, auth, logging)

Usage rapide :
    from aura.carbon import AuraCarbon

    tracker = AuraCarbon()
    tracker.start()
    # ... ton code ...
    tracker.stop()
"""

__version__ = "0.1.0"
__author__ = "CEVIA"
__email__ = "contact@cevia.io"

# Exports publics principaux
from aura.carbon import AuraCarbon
from aura.carbon.decorators import track_emissions

__all__ = [
    "AuraCarbon",
    "track_emissions",
    "__version__",
]
