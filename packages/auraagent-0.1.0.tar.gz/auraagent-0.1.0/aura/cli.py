"""
CLI Aura — commande `aura`

Commandes disponibles :
    aura web          → Lance l'interface web locale
    aura status       → Affiche la configuration courante
    aura logout       → Supprime la configuration locale
    aura version      → Affiche la version
"""

import click
from rich.console import Console
from rich.table import Table

console = Console()


@click.group()
@click.version_option(package_name="aura", prog_name="aura")
def main():
    """Aura — Carbon tracking and monitoring toolkit."""
    pass


@main.command()
@click.option("--port", default=8765, show_default=True, help="Port d'écoute.")
@click.option("--no-browser", is_flag=True, help="Ne pas ouvrir le navigateur.")
def web(port: int, no_browser: bool):
    """Lance l'interface web locale Aura."""
    from aura.web.main import start
    start(open_browser=not no_browser, port=port)


@main.command()
def status():
    """Affiche la configuration locale courante."""
    from aura.core.config import AuraConfig
    from aura.core.exceptions import AuraConfigError

    cfg = AuraConfig()
    if not cfg.exists():
        console.print("[yellow]Aucune configuration trouvée.[/yellow]")
        console.print("Lancez [bold]aura web[/bold] pour vous connecter.")
        return

    cfg.load()
    data = cfg.to_dict()

    table = Table(title="Configuration Aura", show_header=False, border_style="dim")
    table.add_column("Clé", style="cyan")
    table.add_column("Valeur")
    for key, val in data.items():
        table.add_row(key, str(val))
    console.print(table)


@main.command()
def logout():
    """Supprime la configuration locale (déconnexion)."""
    from aura.core.config import AuraConfig

    cfg = AuraConfig()
    if not cfg.exists():
        console.print("[yellow]Aucune configuration à supprimer.[/yellow]")
        return

    if click.confirm("Supprimer la configuration locale (~/.aura.config) ?"):
        cfg.delete()
        console.print("[green]Déconnecté.[/green]")


if __name__ == "__main__":
    main()
