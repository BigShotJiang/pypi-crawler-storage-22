"""
Constantes globales du package Aura.

AURA_SERVER_URL est l'unique point d'entrée hardcodé.
Toutes les autres URLs sont retournées par le serveur après authentification.
"""

# URL du serveur Aura — fixée à la distribution du package
AURA_SERVER_URL = "https://cevia.io"

# Endpoints relatifs (construits sur AURA_SERVER_URL)
AUTH_VERIFY_ENDPOINT    = "/api/auth/verify/"
MACHINE_REGISTER_ENDPOINT = "/api/machines/register/"

# Nom du fichier de configuration local
CONFIG_FILENAME = ".aura.config"
CONFIG_SECTION  = "aura"

ACCESS_TOKEN_KEY = "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"