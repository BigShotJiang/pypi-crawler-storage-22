"""
aura.web — Composant interface web locale.

Lance une interface FastAPI accessible depuis le navigateur sur localhost.
Permet de :
    - Se connecter au serveur Aura (première utilisation)
    - Démarrer / arrêter le tracking CO2
    - Visualiser les données en temps réel
    - Gérer la configuration locale

Usage :
    # Depuis la CLI
    aura-web

    # Depuis Python
    from aura.web.main import start
    start()
"""

from aura.web.main import start

__all__ = ["start"]
