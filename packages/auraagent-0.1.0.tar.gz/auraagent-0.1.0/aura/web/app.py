"""
Application FastAPI principale — composant web Aura.
"""

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse
from pathlib import Path

from aura.core.config import AuraConfig
from aura.web.routers import auth, tracker, config as config_router

# ─── App ─────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Aura Web",
    description="Interface locale Aura — gestion du tracking CO2",
    version="0.1.0",
    docs_url=None,    # Désactiver Swagger en mode desktop
    redoc_url=None,
)

# ─── Fichiers statiques & templates ──────────────────────────────────────────

BASE_DIR = Path(__file__).parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

# ─── Routers ─────────────────────────────────────────────────────────────────

app.include_router(auth.router,    prefix="/auth",    tags=["auth"])
app.include_router(tracker.router, prefix="/tracker", tags=["tracker"])
app.include_router(config_router.router, prefix="/config", tags=["config"])

# ─── Pages HTML ──────────────────────────────────────────────────────────────

@app.get("/")
async def root():
    """Redirige vers le dashboard ou le login selon la config."""
    cfg = AuraConfig()
    if cfg.exists():
        return RedirectResponse(url="/dashboard")
    return RedirectResponse(url="/login")


@app.get("/login")
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.get("/dashboard")
async def dashboard_page(request: Request):
    cfg = AuraConfig()
    if not cfg.exists():
        return RedirectResponse(url="/login")
    cfg.load()
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "config": cfg.to_dict(),
    })


@app.get("/settings")
async def settings_page(request: Request):
    cfg = AuraConfig()
    if not cfg.exists():
        return RedirectResponse(url="/login")
    cfg.load()
    return templates.TemplateResponse("settings.html", {
        "request": request,
        "config": cfg.to_dict(),
    })
