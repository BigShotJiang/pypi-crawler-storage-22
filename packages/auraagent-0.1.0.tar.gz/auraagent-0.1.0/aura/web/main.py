"""
Point d'entrée du composant web.

Lance le serveur FastAPI en local et ouvre le navigateur automatiquement.
Utilisé par :
    - La commande CLI : aura-web
    - L'icône bureau (via PyInstaller)
    - Import direct : from aura.web import start; start()
"""

import threading
import time
import webbrowser
import uvicorn

HOST = "127.0.0.1"
PORT = 8765
URL = f"http://{HOST}:{PORT}"


def _open_browser():
    """Ouvre le navigateur après un court délai (le temps que FastAPI démarre)."""
    time.sleep(1.5)
    webbrowser.open(URL)


def start(open_browser: bool = True, port: int = PORT) -> None:
    """
    Démarre le serveur Aura Web en local.

    Args:
        open_browser: Ouvre automatiquement le navigateur (défaut: True).
        port: Port d'écoute (défaut: 8765).
    """
    if open_browser:
        threading.Thread(target=_open_browser, daemon=True).start()

    print(f"[Aura Web] Démarrage sur {URL}")
    uvicorn.run(
        "aura.web.app:app",
        host=HOST,
        port=port,
        log_level="warning",   # Silencieux en production desktop
        reload=False,
    )


if __name__ == "__main__":
    start()
