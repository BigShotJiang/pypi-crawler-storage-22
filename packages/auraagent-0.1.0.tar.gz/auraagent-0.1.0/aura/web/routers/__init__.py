# Routers FastAPI — auto-découverte dans app.py
