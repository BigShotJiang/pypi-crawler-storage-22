"""
Router d'authentification — /auth/*

Endpoints :
    POST /auth/login     → Vérifie email + api_key, enregistre la machine, écrit ~/.aura.config
    POST /auth/logout    → Supprime ~/.aura.config
    GET  /auth/status    → Vérifie si configuré
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from aura.core.auth import AuraAuth
from aura.core.config import AuraConfig
from aura.core.exceptions import AuraAuthError, AuraAPIError

router = APIRouter()


class LoginBody(BaseModel):
    email: str
    api_key: str


@router.post("/login")
async def login(body: LoginBody):
    """
    Flux complet de connexion :
        1. Vérifie email + api_key auprès du serveur Aura
        2. Enregistre la machine (hostname, OS, CPU, GPU, RAM)
        3. Écrit ~/.aura.config avec tout ce que le serveur a retourné
    """
    try:
        auth = AuraAuth()   # Utilise AURA_SERVER_URL hardcodé
        config = auth.login_and_save(email=body.email, api_key=body.api_key)

        return JSONResponse({
            "success": True,
            "message": "Connexion réussie. Configuration sauvegardée.",
            "config": config.to_dict(),
        })

    except AuraAuthError as e:
        raise HTTPException(status_code=401, detail=str(e))
    except AuraAPIError as e:
        raise HTTPException(status_code=502, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur inattendue : {e}")


@router.post("/logout")
async def logout():
    """Supprime la configuration locale (déconnexion)."""
    config = AuraConfig()
    config.delete()
    return JSONResponse({"success": True, "message": "Déconnecté."})


@router.get("/status")
async def status():
    """Retourne l'état de configuration actuel."""
    config = AuraConfig()
    if not config.exists():
        return JSONResponse({"configured": False})

    config.load()
    return JSONResponse({
        "configured": True,
        "config": config.to_dict(),
    })
