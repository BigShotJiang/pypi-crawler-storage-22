"""
Router config — /config/*

Endpoints :
    GET  /config          → Lit la configuration courante
    PATCH /config         → Met à jour des valeurs de config
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional

from aura.core.config import AuraConfig
from aura.core.exceptions import AuraConfigError

router = APIRouter()


class ConfigUpdateBody(BaseModel):
    default_project: Optional[str] = None
    organization: Optional[str] = None


@router.get("/")
async def get_config():
    """Retourne la configuration courante (sans api_key en clair)."""
    cfg = AuraConfig()
    if not cfg.exists():
        raise HTTPException(status_code=404, detail="Aucune configuration trouvée.")
    cfg.load()
    return JSONResponse(cfg.to_dict())


@router.patch("/")
async def update_config(body: ConfigUpdateBody):
    """Met à jour des champs de configuration."""
    cfg = AuraConfig()
    if not cfg.exists():
        raise HTTPException(status_code=404, detail="Aucune configuration trouvée.")
    cfg.load()

    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="Aucune valeur à mettre à jour.")

    cfg.write(updates)
    return JSONResponse({"success": True, "updated": list(updates.keys())})
