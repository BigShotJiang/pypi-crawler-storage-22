"""
Router tracker — /tracker/*

Endpoints :
    POST /tracker/start   → Démarre le tracking
    POST /tracker/stop    → Arrête le tracking
    POST /tracker/flush   → Flush sans arrêter
    GET  /tracker/status  → Statut courant
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional

from aura.web.services.tracker_service import TrackerService

router = APIRouter()
_service = TrackerService()


class StartBody(BaseModel):
    project_name: Optional[str] = None
    measure_power_secs: float = 15
    save_to_file: bool = False


@router.post("/start")
async def start(body: StartBody):
    """Démarre le tracker AuraCarbon."""
    if _service.is_running():
        raise HTTPException(status_code=409, detail="Un tracking est déjà en cours.")
    try:
        _service.start(
            project_name=body.project_name,
            measure_power_secs=body.measure_power_secs,
            save_to_file=body.save_to_file,
        )
        return JSONResponse({"success": True, "message": "Tracking démarré."})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stop")
async def stop():
    """Arrête le tracker et retourne les émissions totales."""
    if not _service.is_running():
        raise HTTPException(status_code=409, detail="Aucun tracking en cours.")
    try:
        result = _service.stop()
        return JSONResponse({"success": True, "emissions": result})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/flush")
async def flush():
    """Envoie les données courantes sans arrêter le tracking."""
    if not _service.is_running():
        raise HTTPException(status_code=409, detail="Aucun tracking en cours.")
    try:
        result = _service.flush()
        return JSONResponse({"success": True, "emissions": result})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status")
async def status():
    """Retourne le statut courant du tracker."""
    return JSONResponse(_service.get_status())
