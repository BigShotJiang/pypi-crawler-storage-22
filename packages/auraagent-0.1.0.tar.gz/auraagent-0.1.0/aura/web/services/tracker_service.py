"""
TrackerService — Gère le cycle de vie du AuraCarbon dans le contexte web.

Le tracker tourne dans un thread séparé pour ne pas bloquer FastAPI.
"""

import threading
import time
from datetime import datetime
from typing import Optional

from aura.carbon.tracker import AuraCarbon
from aura.core.exceptions import AuraConfigError


class TrackerService:
    """Singleton gérant le tracker AuraCarbon pour l'interface web."""

    def __init__(self):
        self._tracker: Optional[AuraCarbon] = None
        self._lock = threading.Lock()
        self._started_at: Optional[datetime] = None
        self._project_name: Optional[str] = None
        self._last_emissions: Optional[float] = None

    def is_running(self) -> bool:
        """Retourne True si un tracking est en cours."""
        with self._lock:
            return self._tracker is not None

    def start(
        self,
        project_name: Optional[str] = None,
        measure_power_secs: float = 15,
        save_to_file: bool = False,
    ) -> None:
        """Démarre le tracker."""
        with self._lock:
            self._tracker = AuraCarbon(
                project_name=project_name,
                measure_power_secs=measure_power_secs,
                save_to_file=save_to_file,
            )
            self._tracker.start()
            self._started_at = datetime.now()
            self._project_name = project_name
            self._last_emissions = None

    def stop(self) -> Optional[float]:
        """Arrête le tracker et retourne les émissions totales (kg CO2eq)."""
        with self._lock:
            if self._tracker is None:
                return None
            emissions = self._tracker.stop()
            self._last_emissions = emissions
            self._tracker = None
            self._started_at = None
            return emissions

    def flush(self) -> Optional[float]:
        """Flush les données courantes sans arrêter."""
        with self._lock:
            if self._tracker is None:
                return None
            return self._tracker.flush()

    def get_status(self) -> dict:
        """Retourne le statut courant sous forme de dict JSON."""
        with self._lock:
            if self._tracker is None:
                return {
                    "running": False,
                    "project_name": None,
                    "started_at": None,
                    "duration_seconds": None,
                    "emissions": self._last_emissions,
                }
            duration = (
                (datetime.now() - self._started_at).total_seconds()
                if self._started_at else None
            )
            return {
                "running": True,
                "project_name": self._project_name,
                "started_at": self._started_at.isoformat() if self._started_at else None,
                "duration_seconds": round(duration, 1) if duration else None,
                "emissions": None,  # Disponible seulement après stop()
            }
