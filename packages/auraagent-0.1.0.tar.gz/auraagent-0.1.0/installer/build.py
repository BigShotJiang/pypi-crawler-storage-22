"""
Script de build PyInstaller — génère l'exécutable installateur.

Usage :
    python installer/build.py

Génère :
    installer/dist/aura-install.exe     (Windows)
    installer/dist/aura-install         (Linux)
    installer/dist/aura-install.app     (macOS)
"""

import subprocess
import sys
import platform
from pathlib import Path

HERE = Path(__file__).parent
ICON_WIN = HERE / "assets" / "aura.ico"
ICON_MAC = HERE / "assets" / "aura.icns"
ICON_LIN = HERE / "assets" / "aura.png"


def get_icon():
    system = platform.system()
    if system == "Windows" and ICON_WIN.exists():
        return str(ICON_WIN)
    if system == "Darwin" and ICON_MAC.exists():
        return str(ICON_MAC)
    if ICON_LIN.exists():
        return str(ICON_LIN)
    return None


def build():
    icon = get_icon()
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--windowed",           # Pas de fenêtre terminal
        "--name", "aura-install",
        "--distpath", str(HERE / "dist"),
        "--workpath", str(HERE / "build"),
        "--specpath", str(HERE),
    ]

    if icon:
        cmd += ["--icon", icon]

    cmd.append(str(HERE / "install.py"))

    print(f"Build PyInstaller en cours...")
    subprocess.run(cmd, check=True)
    print(f"\nExécutable généré dans : installer/dist/")


if __name__ == "__main__":
    build()
