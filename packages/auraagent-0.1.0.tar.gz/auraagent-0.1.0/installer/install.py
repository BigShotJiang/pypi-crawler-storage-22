"""
Installateur Aura — script exécuté par l'utilisateur.

Ce script est compilé en exécutable via PyInstaller (voir build.py).
Il est générique : pas de token embarqué.

Étapes :
    1. Vérifie Python installé
    2. Installe aura depuis GitHub Packages
    3. Crée un raccourci bureau (Win/Mac/Linux)
    4. Lance aura-web pour la première configuration
"""

import sys
import subprocess
import platform
import os
from pathlib import Path

PACKAGE_INDEX = "https://pypi.pkg.github.com/tombouVincentA/simple/"
PACKAGE_NAME = "auraagent[web]"
APP_NAME = "Aura"


def print_step(msg: str):
    print(f"\n  ➜  {msg}")


def print_ok(msg: str):
    print(f"  ✓  {msg}")


def print_error(msg: str):
    print(f"  ✗  {msg}", file=sys.stderr)


def check_python():
    """Vérifie que Python 3.9+ est disponible."""
    print_step("Vérification de Python...")
    v = sys.version_info
    if v < (3, 9):
        print_error(f"Python 3.9+ requis. Version détectée : {v.major}.{v.minor}")
        sys.exit(1)
    print_ok(f"Python {v.major}.{v.minor}.{v.micro}")


def install_package():
    """Installe aura depuis GitHub Packages."""
    print_step(f"Installation de {PACKAGE_NAME}...")
    try:
        subprocess.run(
            [
                sys.executable, "-m", "pip", "install",
                "--upgrade",
                "--index-url", PACKAGE_INDEX,
                "--extra-index-url", "https://pypi.org/simple/",
                PACKAGE_NAME,
            ],
            check=True,
        )
        print_ok("Package installé.")
    except subprocess.CalledProcessError:
        print_error("L'installation a échoué. Vérifiez votre connexion internet.")
        sys.exit(1)


def create_shortcut():
    """Crée un raccourci bureau selon l'OS."""
    print_step("Création du raccourci bureau...")
    system = platform.system()

    try:
        if system == "Windows":
            _create_shortcut_windows()
        elif system == "Darwin":
            _create_shortcut_macos()
        else:
            _create_shortcut_linux()
        print_ok("Raccourci créé sur le bureau.")
    except Exception as e:
        print(f"  ⚠  Impossible de créer le raccourci : {e}")
        print("     Vous pouvez lancer Aura manuellement avec : aura web")


def _create_shortcut_windows():
    import winreg
    desktop = Path(os.path.expanduser("~/Desktop"))
    shortcut_path = desktop / f"{APP_NAME}.bat"
    with open(shortcut_path, "w") as f:
        f.write(f'@echo off\nstart /B {sys.executable} -m aura.web.main\n')


def _create_shortcut_macos():
    desktop = Path.home() / "Desktop"
    app_dir = desktop / f"{APP_NAME}.app" / "Contents" / "MacOS"
    app_dir.mkdir(parents=True, exist_ok=True)

    script = app_dir / APP_NAME
    with open(script, "w") as f:
        f.write(f'#!/bin/bash\n{sys.executable} -m aura.web.main\n')
    script.chmod(0o755)

    # Info.plist basique
    plist = app_dir.parent.parent / "Info.plist"
    with open(plist, "w") as f:
        f.write(f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
    <key>CFBundleName</key><string>{APP_NAME}</string>
    <key>CFBundleExecutable</key><string>{APP_NAME}</string>
</dict></plist>""")


def _create_shortcut_linux():
    desktop = Path.home() / "Desktop"
    desktop.mkdir(exist_ok=True)
    shortcut = desktop / f"{APP_NAME}.desktop"
    with open(shortcut, "w") as f:
        f.write(f"""[Desktop Entry]
Name={APP_NAME}
Exec={sys.executable} -m aura.web.main
Type=Application
Terminal=false
Comment=Aura Carbon Tracker
""")
    shortcut.chmod(0o755)


def launch_app():
    """Lance aura-web après installation."""
    print_step("Lancement d'Aura Web...")
    subprocess.Popen([sys.executable, "-m", "aura.web.main"])


def main():
    print("\n" + "=" * 50)
    print("       Installation d'Aura")
    print("=" * 50)

    check_python()
    install_package()
    create_shortcut()
    launch_app()

    print("\n" + "=" * 50)
    print("  Installation terminée !")
    print("  Aura s'ouvre dans votre navigateur...")
    print("=" * 50 + "\n")


if __name__ == "__main__":
    main()
