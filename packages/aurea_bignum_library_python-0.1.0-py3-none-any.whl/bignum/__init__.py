"""bignum

A lightweight 'bignum' implementation.

This package uses a src/ layout so it can be built and published to PyPI.
"""

from __future__ import annotations

__version__ = "0.1.0"

# Re-export the public API from the original single-file implementation.
from .core import (  # noqa: F401
    SafeMode,
    SF,
    absBignum,
    addBignum,
    bignumdict,
    compareBignum,
    cubrtBignum,
    divBignum,
    eulersnumber,
    expBignum,
    exphelper,
    factBignum,
    floorBignum,
    fromInteger,
    fromScientific,
    isZero,
    lnBignum,
    lnhelper,
    Log10,
    Logx,
    multBignum,
    nthrtBignum,
    pi,
    recipBignum,
    roundBignum,
    roundSFBignum,
    sqrtBignum,
    subBignum,
    toInteger,
    toScientific,
)

__all__ = [
    "__version__",
    "SF",
    "SafeMode",
    "eulersnumber",
    "pi",
    "bignumdict",
    "compareBignum",
    "roundSFBignum",
    "roundBignum",
    "toScientific",
    "toInteger",
    "fromScientific",
    "fromInteger",
    "isZero",
    "floorBignum",
    "absBignum",
    "recipBignum",
    "addBignum",
    "subBignum",
    "multBignum",
    "divBignum",
    "lnBignum",
    "lnhelper",
    "expBignum",
    "exphelper",
    "Log10",
    "Logx",
    "sqrtBignum",
    "cubrtBignum",
    "nthrtBignum",
    "factBignum",
]
