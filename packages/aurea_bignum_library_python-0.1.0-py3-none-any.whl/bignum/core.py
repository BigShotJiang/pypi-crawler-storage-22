# HOURS_WASTED 2.0: 4 :/
# current status: why. words cannot come to tell you how much i HATE this thing. this code is a scourge. why. this is self torture.
from typing import TypedDict
import math

class bignumdict(TypedDict):
    '''Gives the type of bignum dict to help to allow type checking.'''
    sign: str
    mantissa: float
    exponent: int
    exponentsign: str
    magnitude: int
    imaginary: bool

'''
Bignum:
{'sign': string [+/-], 'mantissa': float, 'exponent': int, 'exponentsign': string [+/-], 'magnitude': int, 'imaginary': false}
1e10 = {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '+', 'magnitude': 0, 'imaginary': false}
1e-10 = {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '-', 'magnitude': 0, 'imaginary': false}
1ee10 = {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '+', 'magnitude': 1, 'imaginary': false}
1e10i = {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '+', 'magnitude': 0, 'imaginary': true}
'''

'''
Completed functions:
- compareBignum 
- roundBignum
- toScientific
- toInteger
- fromScientific
- fromInteger
- isZero
- floorBignum
- absBignum
- recipBignum
- addBignum
- subBignum
- multBignum
- divBignum
- lnBignum
- [ lnhelper 
- expBignum
- exphelper ] -> These make up expBignum. lnBignum is included but referenced as seperate as it can be used seperatly.
- Log10
- Logx
- sqrtBignum
- cubrtBignum
- nthrtBignum
-
'''

# Key variables:
SF = 5 # Amount of significant figures. Reminder that past 10, some python modules cannot support numbers of that length.
SafeMode = True # SafeMode stops certain laggy features from occuring.

#KEY THINGS (DO NOT CHANGE)
eulersnumber = 2.718281828459045235360287471352
pi: bignumdict = {'sign': '+', 'mantissa': 3.141592653589793, 'exponent': 0, 'exponentsign': '+', 'magnitude': 0, 'imaginary': False}
#- Conversions + Helper functions


def compareBignum(b1: bignumdict, b2: bignumdict) -> int:
    '''
    Compares the two bignums.\n
    Returns 1 if first bignum is bigger.\n
    Returns 0 if they are the same.\n
    Returns -1 if second bignum is bigger.
    '''
    b1mantissa = b1.get('mantissa', 0); b2mantissa = b2.get('mantissa', 0)
    b1exponent = b1.get('exponent', 0); b2exponent = b2.get('exponent', 0)
    b1expsign = b1.get('exponentsign', '+'); b2expsign = b2.get('exponentsign', '+')
    b1layer = b1.get('magnitude', 0); b2layer = b2.get('magnitude', 0)
    b1sign = b1.get('sign', '+'); b2sign = b2.get('sign', '+')
    #- Sign checks
    if b1 == b2: return 0
    if b1sign == '-' and b2sign == '+': return -1
    elif b1sign == '+' and b2sign == '-': return 1
    #- Magnitude checks
    if b1layer < b2layer: return -1
    elif b1layer > b2layer: return 1
    #- Exponent sign checks (for same magnitude)
    if b1expsign == '-' and b2expsign == '+': return -1
    elif b1expsign == '+' and b2expsign == '-': return 1
    #- Exponent checks (consider sign)
    if b1expsign == '-':
        if b1exponent > b2exponent: return -1
        elif b1exponent < b2exponent: return 1
    else:
        if b1exponent < b2exponent: return -1
        elif b1exponent > b2exponent: return 1
    #- Mantissa checks
    if b1mantissa < b2mantissa: return -1
    elif b1mantissa > b2mantissa: return 1
    #- ELSE:
    return 0


def roundSFBignum(num: bignumdict) -> bignumdict:
    '''
    Rounds a bignum to SF significant figures.
    Returns a bignum.
    '''
    mantissa = num.get('mantissa', 0.0)
    if mantissa == 0.0: return num
    sign = num.get('sign', '+')
    exponent = num.get('exponent', 0)
    exponentsign = num.get('exponentsign', '+')
    magnitude = num.get('magnitude', 0)
    imaginary = num.get('imaginary', False)
    mantissa = round(mantissa, SF)
    return {'sign': sign, 'mantissa': mantissa, 'exponent': exponent, 'exponentsign': exponentsign, 'magnitude': magnitude, 'imaginary': imaginary}

def roundBignum(num: bignumdict, sigfigs: int) -> bignumdict:
    '''
    Rounds a bignum to sigfigs significant figures.
    Returns a bignum.
    '''
    mantissa: float = num.get('mantissa', 0.0)
    if mantissa == 0.0: return num
    sign = num.get('sign', '+')
    exponent = num.get('exponent', 0)
    exponentsign = num.get('exponentsign', '+')
    magnitude = num.get('magnitude', 0)
    imaginary = num.get('imaginary', False)
    scale = 10 ** sigfigs
    mantissa = math.floor(mantissa * scale + 0.5) / scale
    if mantissa >= 10:
        mantissa /= 10
        exponent += 1
    return {'sign': sign, 'mantissa': mantissa, 'exponent': exponent, 'exponentsign': exponentsign, 'magnitude': magnitude, 'imaginary': imaginary}
#- Conversions :3


def toScientific(bignum: bignumdict) -> str:
    '''
    Converts a bignum into a scientific number.
    Bignum contains: sign, mantissa, exponent, exponentsign, magnitude, imaginary.\n
    Examples:
    {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '+', 'magnitude': 0, 'imaginary': False} = +1.0e10
    {'sign': '-', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '-', 'magnitude': 0, 'imaginary': False} = -1.0e-10
    {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '+', 'magnitude': 1, 'imaginary': False} = +1.0ee10
    {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '+', 'magnitude': 0, 'imaginary': True} = +1.0e10i
    '''
    magnitude = bignum.get('magnitude', 0)
    mantissa = bignum.get('mantissa', 0.0)
    exponent = bignum.get('exponent', 0)
    exponentsign = bignum.get('exponentsign', '+')
    sign = bignum.get('sign', '+')
    imaginary = bignum.get('imaginary', False)
    if mantissa == 0.0: return '0e0'
    es = 'e' * (magnitude + 1)
    expstr = f'{exponentsign}{exponent}' if exponentsign == '-' else str(exponent)
    imagstr = 'i' if imaginary else ''
    return f'{sign}{mantissa}{es}{expstr}{imagstr}'


def toInteger(bignum: bignumdict) -> float:
    '''
    Converts a bignum into a number.
    Only works between 1e-10 and 1e10\n
    Examples:
    {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '+', 'magnitude': 0} = 1e10
    {'sign': '+', 'mantissa': 1.0, 'exponent': 5, 'exponentsign': '-', 'magnitude': 0} = 1e-5
    '''
    if compareBignum(bignum, fromScientific('1e10')) == 1:
        return 0.0
    elif compareBignum(bignum, fromScientific('1e-10')) == -1:
        return 0.0
    bmnt = float(bignum.get('mantissa', 0.0))
    bexp = int(bignum.get('exponent', 0))
    bexpsign = bignum.get('exponentsign', '+')
    bsign = bignum.get('sign', '+')
    if bexp == 0:
        result = bmnt
    else:
        if bexpsign == '-':
            result = bmnt * (10 ** -bexp)
        else:
            result = bmnt * (10 ** bexp)
    return -result if bsign == '-' else result


def fromScientific(num: str) -> bignumdict:
    '''
    Converts a number from scientific into bignum.
    Bignum contains: sign, mantissa, exponent, exponentsign, magnitude, imaginary.\n
    Examples:
    1e10 = {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '+', 'magnitude': 0, 'imaginary': False}
    -1e-10 = {'sign': '-', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '-', 'magnitude': 0, 'imaginary': False}
    1ee10 = {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '+', 'magnitude': 1, 'imaginary': False}
    '''
    count = 0
    imaginary = False
    for char in num:
        if char == 'e': count += 1
        if char == 'i': imaginary = True
    magnitude = count - 1 if count > 0 else 0
    separator = 'e' * count
    numtuple = num.partition(separator)
    #- Parse mantissa and sign
    mantissastr = numtuple[0].replace('i', '')
    if mantissastr.startswith('-'):
        sign = '-'
        mantissastr = mantissastr[1:]
    elif mantissastr.startswith('+'):
        sign = '+'
        mantissastr = mantissastr[1:]
    else:
        sign = '+'
    mantissa = float(mantissastr) if mantissastr else 0.0
    exponentstr = numtuple[2].replace('i', '')
    if exponentstr.startswith('-'):
        exponentsign = '-'
        exponentstr = exponentstr[1:]
    elif exponentstr.startswith('+'):
        exponentsign = '+'
        exponentstr = exponentstr[1:]
    else:
        exponentsign = '+'
    exponent = int(exponentstr) if exponentstr else 0
    return {'sign': sign, 'mantissa': mantissa, 'exponent': exponent, 'exponentsign': exponentsign, 'magnitude': magnitude, 'imaginary': imaginary}


def fromInteger(num: float) -> bignumdict:
    '''
    Converts a float into a bignum which is then returned.
    Bignum contains: sign, mantissa, exponent, exponentsign, magnitude, imaginary.\n
    Examples:
    10000000000.0 = {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '+', 'magnitude': 0, 'imaginary': False}
    0.0000000001 = {'sign': '+', 'mantissa': 1.0, 'exponent': 10, 'exponentsign': '-', 'magnitude': 0, 'imaginary': False}
    '''
    if num == 0: return {'sign': '+', 'mantissa': 0.0, 'exponent': 0, 'exponentsign': '+', 'magnitude': 0, 'imaginary': False}
    sign = '-' if num < 0 else '+'
    num = abs(num)
    exponent = 0
    exponentsign = '+'
    if num >= 1:
        while num >= 10:
            num = num / 10
            exponent += 1
    else:
        exponentsign = '-'
        while num < 1:
            num = num * 10
            exponent += 1
    return {'sign': sign, 'mantissa': num, 'exponent': exponent, 'exponentsign': exponentsign, 'magnitude': 0, 'imaginary': False}


#- Other helper functions:


def isZero(b1: bignumdict) -> bool:
    '''
    Takes an input of a bignum, and returns a boolean whether or not it is 0.
    '''
    if b1 == fromInteger(0):
        return True
    else:
        return False


def floorBignum(bignum: bignumdict) -> bignumdict:
    '''
    Floors a bignum.
    Returns a bignum.
    '''
    roundedbignum = roundBignum(bignum, 5)
    if compareBignum(roundedbignum, bignum) == 1:
        roundedbignum = subBignum(roundedbignum, fromInteger(1))
        return roundedbignum
    else:
        return roundedbignum


def absBignum(bignum: bignumdict) -> bignumdict:
    '''
    Returns the absolute value of a bignum.
    The return is a bignum.
    '''
    magnitude = bignum.get('magnitude', 0)
    mantissa = bignum.get('mantissa', 0.0)
    exponent = bignum.get('exponent', 0)
    exponentsign = bignum.get('exponentsign', '+')
    imaginary = bignum.get('imaginary', False)
    sign = '+'
    return {'sign': sign, 'mantissa': mantissa, 'exponent': exponent, 'exponentsign': exponentsign, 'magnitude': magnitude, 'imaginary': imaginary}


def recipBignum(bignum: bignumdict) -> bignumdict:
    '''
    Reciprocates a bignum (1/bignum) and returns the result.
    '''
    reciprocal = divBignum(fromInteger(1),bignum)
    return reciprocal


#- THE ACTUAL MATHS
# THIS IS THE BEGINNING AND THE END


def addBignum(b1: bignumdict, b2: bignumdict) -> bignumdict:
    '''
    Takes two bignums as an argument.
    Adds them together as well as possible.
    Note that safemode will stop some additions.\n
    Example usage: print(subBignum(fromInteger(4000),fromInteger(200))) = 4200
    '''
    b1mantissa = b1.get('mantissa', 0); b2mantissa = b2.get('mantissa', 0)
    b1exponent = b1.get('exponent', 0); b2exponent = b2.get('exponent', 0)
    b1expsign = b1.get('exponentsign', '+'); b2expsign = b2.get('exponentsign', '+')
    b1layer = b1.get('magnitude', 0); b2layer = b2.get('magnitude', 0)
    b1sign = b1.get('sign', '+'); b2sign = b2.get('sign', '+')
    b1exp = b1exponent if b1expsign == '+' else -b1exponent
    b2exp = b2exponent if b2expsign == '+' else -b2exponent
    m1 = b1mantissa if b1sign == '+' else -b1mantissa
    m2 = b2mantissa if b2sign == '+' else -b2mantissa
    if SafeMode:
        if abs(b1exp-b2exp) >= 101: print("WARN: addBignum has over than 1e1000 difference. No addition will happen to reduce lag. Disable safe mode to continue."); return b1 if abs(b1exp) > abs(b2exp) else b2
        if abs(b1layer - b2layer) > 0: print("WARN: addBignum has noticed that the gain in the second argument is over 1 layer/magnitude in difference, and so for lag reasons has stopped it. Disable safe mode to continue."); return b1 if b1layer > b2layer else b2
    if b1exp > b2exp:
        m2 = m2 * (10 **(b2exp - b1exp))
        result = b1exp
        layer = b1layer
    elif b2exp > b1exp:
        m1 = m1 * (10 ** (b1exp - b2exp))
        result = b2exp
        layer = b2layer
    else:
        result = b1exp
        layer = b1layer
    mantissa = m1 + m2
    sign = '+' if mantissa >= 0 else '-'
    mantissa = abs(mantissa)
    while mantissa >= 10:
        mantissa /= 10
        result += 1
    while mantissa < 1 and mantissa != 0:
        mantissa *= 10
        result -= 1
    expsign = '+' if result >= 0 else '-'
    result = abs(result)
    b1imaginary = b1.get('imaginary', False); b2imaginary = b2.get('imaginary', False)
    imaginary = b1imaginary or b2imaginary
    return {'sign': sign, 'mantissa': round(mantissa, SF), 'exponent': result, 'exponentsign': expsign, 'magnitude': layer, 'imaginary': imaginary}


def subBignum(b1: bignumdict, b2: bignumdict) -> bignumdict:
    '''
    Takes two bignums as an argument.
    Attempts to subtract them as well as possible.
    Note that safemode will stop some subtractions.\n
    Example usage: print(subBignum(fromInteger(4000),fromInteger(200))) = 3800
    '''
    b1mantissa = b1.get('mantissa', 0); b2mantissa = b2.get('mantissa', 0)
    b1exponent = b1.get('exponent', 0); b2exponent = b2.get('exponent', 0)
    b1expsign = b1.get('exponentsign', '+'); b2expsign = b2.get('exponentsign', '+')
    b1layer = b1.get('magnitude', 0); b2layer = b2.get('magnitude', 0)
    b1sign = b1.get('sign', '+'); b2sign = b2.get('sign', '+')
    b1exp = b1exponent if b1expsign == '+' else -b1exponent
    b2exp = b2exponent if b2expsign == '+' else -b2exponent
    m1 = b1mantissa if b1sign == '+' else -b1mantissa
    m2 = b2mantissa if b2sign == '+' else -b2mantissa
    if SafeMode:
        if abs(b1exp-b2exp) >= 101: print("WARN: subBignum has over than 1e1000 difference. No subtraction will happen to reduce lag. Disable safe mode to continue."); return b1 if abs(b1exp) > abs(b2exp) else b2
        if abs(b1layer - b2layer) > 0: print("WARN: subBignum has noticed that the gain in the second argument is over 1 layer/magnitude in difference, and so for lag reasons has stopped it. Disable safe mode to continue."); return b1 if b1layer > b2layer else b2
    if b1exp > b2exp:
        m2 = m2 * (10 **(b2exp - b1exp))
        result = b1exp
        layer = b1layer
    elif b2exp > b1exp:
        m1 = m1 * (10 ** (b1exp - b2exp))
        result = b2exp
        layer = b2layer
    else:
        result = b1exp
        layer = b1layer
    mantissa = m1 - m2
    sign = '+' if mantissa >= 0 else '-'
    mantissa = abs(mantissa)
    while mantissa >= 10:
        mantissa /= 10
        result += 1
    while mantissa < 1 and mantissa != 0:
        mantissa *= 10
        result -= 1
    expsign = '+' if result >= 0 else '-'
    result = abs(result)
    b1imaginary = b1.get('imaginary', False); b2imaginary = b2.get('imaginary', False)
    imaginary = b1imaginary or b2imaginary
    return {'sign': sign, 'mantissa': round(mantissa, SF), 'exponent': result, 'exponentsign': expsign, 'magnitude': layer, 'imaginary': imaginary}


def multBignum(b1: bignumdict, b2: bignumdict) -> bignumdict:
    '''
    Takes two bignums as an argument.
    Attempts to multiply them by each other.
    Note that safemode will stop some multiplications.\n
    Example: print(multBignum(fromInteger(4),fromInteger(300))) = 1200
    '''
    b1mantissa = b1.get('mantissa', 0); b2mantissa = b2.get('mantissa', 0)
    b1exponent = b1.get('exponent', 0); b2exponent = b2.get('exponent', 0)
    b1expsign = b1.get('exponentsign', '+'); b2expsign = b2.get('exponentsign', '+')
    b1layer = b1.get('magnitude', 0); b2layer = b2.get('magnitude', 0)
    b1sign = b1.get('sign', '+'); b2sign = b2.get('sign', '+')
    b1exp = b1exponent if b1expsign == '+' else -b1exponent
    b2exp = b2exponent if b2expsign == '+' else -b2exponent
    m1 = b1mantissa if b1sign == '+' else -b1mantissa
    m2 = b2mantissa if b2sign == '+' else -b2mantissa
    if SafeMode:
        if abs(b1layer - b2layer) > 0: print("WARN: multBignum has noticed that the gain in the second argument is over 1 layer/magnitude in difference, and so for lag reasons has stopped it. Disable safe mode to continue."); return b1 if b1layer > b2layer else b2
    mantissa = m1 * m2
    result = b1exp + b2exp
    sign = '+' if mantissa >= 0 else '-'
    mantissa = abs(mantissa)
    while mantissa >= 10:
        mantissa /= 10
        result += 1
    while mantissa < 1 and mantissa != 0:
        mantissa *= 10
        result -= 1
    expsign = '+' if result >= 0 else '-'
    result = abs(result)
    b1imaginary = b1.get('imaginary', False); b2imaginary = b2.get('imaginary', False)
    imaginary = b1imaginary != b2imaginary
    return {'sign': sign, 'mantissa': round(mantissa, SF), 'exponent': result, 'exponentsign': expsign, 'magnitude': b1layer, 'imaginary': imaginary}


def divBignum(b1: bignumdict, b2: bignumdict) -> bignumdict:
    '''
    Takes two bignums as an argument.
    Attempts to divide them by each other.
    Note that safemode will stop some dividations.\n
    Example: print(divBignum(fromInteger(4),fromInteger(300))) = 1.33e-2
    '''
    b1mantissa = b1.get('mantissa', 0); b2mantissa = b2.get('mantissa', 0)
    b1exponent = b1.get('exponent', 0); b2exponent = b2.get('exponent', 0)
    b1expsign = b1.get('exponentsign', '+'); b2expsign = b2.get('exponentsign', '+')
    b1layer = b1.get('magnitude', 0); b2layer = b2.get('magnitude', 0)
    b1sign = b1.get('sign', '+'); b2sign = b2.get('sign', '+')
    b1exp = b1exponent if b1expsign == '+' else -b1exponent
    b2exp = b2exponent if b2expsign == '+' else -b2exponent
    m1 = b1mantissa if b1sign == '+' else -b1mantissa
    m2 = b2mantissa if b2sign == '+' else -b2mantissa
    if m2 == fromInteger(0): return fromInteger(0)
    if SafeMode:
        if abs(b1layer - b2layer) > 0: print("WARN: divBignum has noticed that the gain in the second argument is over 1 layer/magnitude in difference, and so for lag reasons has stopped it. Disable safe mode to continue."); return b1 if b1layer > b2layer else b2
    mantissa = m1 / m2
    result = b1exp - b2exp
    sign = '+' if mantissa >= 0 else '-'
    mantissa = abs(mantissa)
    while mantissa >= 10:
        mantissa /= 10
        result += 1
    while mantissa < 1 and mantissa != 0:
        mantissa *= 10
        result -= 1
    expsign = '+' if result >= 0 else '-'
    result = abs(result)
    b1imaginary = b1.get('imaginary', False); b2imaginary = b2.get('imaginary', False)
    imaginary = b1imaginary != b2imaginary
    return {'sign': sign, 'mantissa': round(mantissa, SF), 'exponent': result, 'exponentsign': expsign, 'magnitude': b1layer, 'imaginary': imaginary}


def lnBignum(bignum: bignumdict) -> bignumdict:
    '''
    Calculates the natural logarithm of a bignum.
    Uses the formula: ln(m * 10^e) = ln(m) + e * ln(10)
    Returns a bignum.
    '''
    mantissa = bignum.get('mantissa', 0.0)
    exponent = bignum.get('exponent', 0)
    exponentsign = bignum.get('exponentsign', '+')
    sign = bignum.get('sign', '+')
    if sign == '-':
        print("ERROR: Cannot take natural log of negative number")
        return fromInteger(0)
    if mantissa == 0:
        print("ERROR: Cannot take natural log of zero")
        return fromInteger(0)
    #- Calculate ln(mantissa) using Taylor series
    if mantissa < 0.5 or mantissa > 2:
        normfactor = 0
        tempmantissa = mantissa
        while tempmantissa > 2:
            tempmantissa /= eulersnumber
            normfactor += 1
        while tempmantissa < 0.5:
            tempmantissa *= eulersnumber
            normfactor -= 1
        lnmantissa = lnhelper(tempmantissa) + normfactor
    else:
        lnmantissa = lnhelper(mantissa)
    #- Add e * ln(10)
    ln10 = 2.302585092994045684017991454684
    signedexp = exponent if exponentsign == '+' else -exponent
    lnvalue = lnmantissa + signedexp * ln10
    return fromInteger(lnvalue)


def lnhelper(x: float) -> float:
    '''
    Helper function to calculate ln(x) for x near 1 using Taylor series.\n
    Uses ln(x) = 2 * sum((1/(2n+1)) * ((x-1)/(x+1))^(2n+1))\n
    More accurate for 0.5 < x < 2
    '''
    if x <= 0:
        return 0.0
    y = (x - 1) / (x + 1)
    ysquared = y * y
    result = 0.0
    term = y
    n = 0
    while abs(term) > 1e-15 and n < 100:
        result += term / (2 * n + 1)
        term *= ysquared
        n += 1
    return 2 * result


def expBignum(base: bignumdict, exponent: bignumdict) -> bignumdict:
    '''
    Calculates base^exponent for bignums.
    Uses the formula: base^exponent = e^(exponent * ln(base))
    Returns a bignum.
    '''
    basemantissa = base.get('mantissa', 0.0)
    baseexponent = base.get('exponent', 0)
    baseexpsign = base.get('exponentsign', '+')
    basesign = base.get('sign', '+')
    basemagnitude = base.get('magnitude', 0)
    expmagnitude = exponent.get('magnitude', 0)
    #- Handle special cases
    if isZero(base):
        if compareBignum(exponent, fromInteger(0)) == 1:
            return fromInteger(0)
        else:
            print("ERROR: 0^0 or 0^negative is undefined")
            return fromInteger(1)
    if isZero(exponent):
        return fromInteger(1)
    if compareBignum(base, fromInteger(1)) == 0:
        return fromInteger(1)
    if compareBignum(exponent, fromInteger(1)) == 0:
        return base
    if basesign == '-':
        print("WARN: Negative base in expBignum, taking absolute value")
        base = absBignum(base)
    if basemagnitude > 0 or expmagnitude > 1:
        if basemagnitude > 0:
            #- base is already huge, raising to any power > 1 increases magnitude
            baseimaginary = base.get('imaginary', False)
            if compareBignum(exponent, fromInteger(1)) == 1:
                return {'sign': '+', 'mantissa': round(basemantissa,SF), 'exponent': baseexponent, 'exponentsign': baseexpsign, 'magnitude': basemagnitude + 1, 'imaginary': baseimaginary}
            else:
                return base
        if expmagnitude > 1:
            baseimaginary = base.get('imaginary', False)
            return {'sign': '+', 'mantissa': round(basemantissa,SF), 'exponent': baseexponent, 'exponentsign': '+', 'magnitude': expmagnitude, 'imaginary': baseimaginary}
    #- Standard case: use logarithms
    #- result = e^(exponent * ln(base))
    lnbase = lnBignum(base)
    expln = multBignum(exponent, lnbase)
    #- Now calculate e^expln
    return exphelper(expln)


def exphelper(bignum: bignumdict) -> bignumdict:
    '''
    Helper function to calculate e^bignum.
    Handles the conversion from natural exponential to bignum format.
    '''
    mantissa = bignum.get('mantissa', 0.0)
    exponent = bignum.get('exponent', 0)
    exponentsign = bignum.get('exponentsign', '+')
    sign = bignum.get('sign', '+')
    magnitude = bignum.get('magnitude', 0)
    signedexp = exponent if exponentsign == '+' else -exponent
    value = mantissa * (10 ** signedexp)
    if sign == '-': value = -value
    if value > 100:
        #- e^value is huge, approximate
        #- e^x ≈ 10^(x/ln(10)) = 10^(x/2.303)
        ln10 = 2.302585092994045684017991454684
        newexponent = value / ln10
        bigumimaginary = bignum.get('imaginary', False)
        return fromInteger(10 ** newexponent) if newexponent < 300 else {'sign': '+', 'mantissa': 1.0, 'exponent': int(newexponent), 'exponentsign': '+', 'magnitude': magnitude + 1, 'imaginary': bigumimaginary}
        return fromInteger(0)
    #- For moderate values, use Taylor series
    #- e^x = sum(x^n / n!)
    result = 1.0
    term = 1.0
    n = 1
    while abs(term) > 1e-15 and n < 100:
        term *= value / n
        result += term
        n += 1
    return fromInteger(result)


def Log10(bignum: bignumdict) -> bignumdict:
    '''
    Finds the log 10 of a bignum using the natural logarithm.
    Quite precise.
    '''
    ln10 = lnBignum(fromInteger(10))
    lnbignum = lnBignum(bignum)
    log10val = divBignum(lnbignum, ln10)
    return log10val


def Logx(bignum: bignumdict, logarithm: bignumdict) -> bignumdict:
    '''
    Given a bignum and a logarithm, calculates the logarithm of it using a naturallog.
    Quite precise.
    '''
    ln10 = lnBignum(logarithm)
    lnbignum = lnBignum(bignum)
    log10val = divBignum(lnbignum, ln10)
    return log10val


def sqrtBignum(bignum: bignumdict) -> bignumdict:
    '''
    Takes a bignum, and squareroots it.
    Relies on expBignum.
    Supports imaginary numbers.
    '''
    sign = bignum.get('sign','+')
    negative = True if sign == '-' else False
    bignum = expBignum(absBignum(bignum), fromInteger(0.5))
    sign = bignum.get('sign','+')
    mantissa = bignum.get('mantissa',0.0)
    exponent = bignum.get('exponent',0)
    exponentsign = bignum.get('exponentsign','+')
    magnitude = bignum.get('magnitude',0)
    return {
        'sign': sign,
        'mantissa': round(mantissa, SF),
        'exponent': exponent,
        'exponentsign': exponentsign,
        'magnitude': magnitude,
        'imaginary': negative
    }


def cubrtBignum(bignum: bignumdict) -> bignumdict:
    '''
    Takes a bignum, and cuberoots it.
    Relies on expBignum.
    '''
    bignum = expBignum(absBignum(bignum), divBignum(fromInteger(1), fromInteger(3)))
    sign = bignum.get('sign','+')
    mantissa = bignum.get('mantissa',0.0)
    exponent = bignum.get('exponent',0)
    exponentsign = bignum.get('exponentsign','+')
    magnitude = bignum.get('magnitude',0)
    return {
        'sign': sign,
        'mantissa': round(mantissa, SF),
        'exponent': exponent,
        'exponentsign': exponentsign,
        'magnitude': magnitude,
        'imaginary': False
    } 


def nthrtBignum(bignum: bignumdict, nth: bignumdict) -> bignumdict:
    '''
    Takes a bignum, and nth-roots it.
    Relies on expBignum.
    Supports imaginary numbers.
    '''
    itest1 = subBignum(nth, fromInteger(2))
    itest2 = divBignum(itest1, fromInteger(4))
    if compareBignum(itest2, roundBignum(itest2, 5)) == 0:
        sign = bignum.get('sign','+')
        negative = True if sign == '-' else False
    else:
        negative = False

    bignum = expBignum(absBignum(bignum), divBignum(fromInteger(1), nth))
    sign = bignum.get('sign','+')
    mantissa = bignum.get('mantissa',0.0)
    exponent = bignum.get('exponent',0)
    exponentsign = bignum.get('exponentsign','+')
    magnitude = bignum.get('magnitude',0)
    return {
        'sign': sign,
        'mantissa': round(mantissa, SF),
        'exponent': exponent,
        'exponentsign': exponentsign,
        'magnitude': magnitude,
        'imaginary': negative
    }


def factBignum(bignum: bignumdict) -> bignumdict:
    currentnum = bignum.copy()
    while compareBignum(currentnum, fromInteger(0)) == 1:
        bignum = multBignum(bignum,currentnum)
        currentnum = subBignum(currentnum,fromInteger(1))
    return bignum
