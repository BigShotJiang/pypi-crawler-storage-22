"""Tool configuration generators.

This module handles configuration for AI tools:
- registry.py: Configuration registry and management
"""

__all__ = []
