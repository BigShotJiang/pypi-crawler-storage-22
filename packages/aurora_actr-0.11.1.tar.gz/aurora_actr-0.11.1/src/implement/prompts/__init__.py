"""Prompt templates for implement package."""
