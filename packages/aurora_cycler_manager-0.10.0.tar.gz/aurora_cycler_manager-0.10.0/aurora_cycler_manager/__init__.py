"""Aurora cycler manager."""
