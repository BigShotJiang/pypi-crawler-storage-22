"""Copyright © 2025-2026, Empa.

Harvest EC-lab .mpr files and convert to aurora-compatible parquet files.

Define the machines to grab files from in the config.json file.

Run the script to harvest and convert all mpr files.
"""

import json
import logging
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import polars as pl
import yadg
from dgbowl_schemas.yadg.dataschema import ExtractorFactory

from aurora_cycler_manager.config import get_config
from aurora_cycler_manager.data_parse import get_sample_folder
from aurora_cycler_manager.database_funcs import add_data_to_db, get_sample_data, update_harvester
from aurora_cycler_manager.setup_logging import setup_logging
from aurora_cycler_manager.ssh import SSHConnection
from aurora_cycler_manager.stdlib_utils import run_from_sample
from aurora_cycler_manager.utils import parse_datetime
from aurora_cycler_manager.version import __url__, __version__

CONFIG = get_config()
logger = logging.getLogger(__name__)
# These warnings from yadg is handled
logging.getLogger("yadg.extractors.eclab.mpr").addFilter(lambda record: "No 'log' module" not in record.getMessage())
logging.getLogger("yadg.extractors.eclab.mpr").addFilter(
    lambda record: "I Range could not be understood" not in record.getMessage()
)


def get_eclab_snapshot_folder() -> Path:
    """Get the path to the snapshot folder for eclab files."""
    snapshot_parent = CONFIG.get("Snapshots folder path")
    if not snapshot_parent:
        msg = (
            "No 'Snapshots folder path' in config file. "
            f"Please fill in the config file at {CONFIG.get('User config path')}.",
        )
        raise ValueError(msg)
    snapshot_path = Path(snapshot_parent) / "eclab_snapshots"
    snapshot_path.mkdir(parents=True, exist_ok=True)
    return snapshot_path


def get_mprs(
    server: dict,
    server_copy_folder: str,
    local_folder: Path | str,
    *,
    force_copy: bool = False,
) -> list[Path]:
    """Get .mpr files from subfolders of specified folder.

    Args:
        server (dict): Server dictionary, as defined in config
        server_copy_folder (str): Folder to search and copy .mpr and .mpl files
        local_folder (Path | str): Folder to copy files to
        force_copy (bool, optional): Copy all files regardless of modification date

    """
    # Set default cutoff date, use local timezone
    cutoff_uts = 0.0
    if not force_copy:  # Set cutoff date to last snapshot from database
        with sqlite3.connect(CONFIG["Database path"]) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT `Last snapshot` FROM harvester WHERE `Server label`=? AND `Server hostname`=? AND `Folder`=?",
                (server["label"], server["hostname"], server_copy_folder),
            )
            result = cursor.fetchone()
            cursor.close()
        if result:
            cutoff_uts = parse_datetime(result[0]).timestamp()

    # Connect to the server and copy the files
    with SSHConnection(server) as ssh:
        remote_files = ssh.check_new_files(server_copy_folder, [".mpr", ".mpl"], cutoff_uts)
        local_files = [Path(local_folder) / os.path.relpath(file, server_copy_folder) for file in remote_files]
        copy_datetime = datetime.now(timezone.utc)  # Keep time of copying for database
        ssh.get_files(local_files, remote_files)

    update_harvester(server, server_copy_folder, copy_datetime)
    return local_files


def get_all_mprs(*, force_copy: bool = False) -> list[Path]:
    """Get all MPR files from the folders specified in the config.

    Searches in the active "data_path" folder as well as a list of passive
    "harvester_folders".
    """
    all_new_files = []
    snapshot_folder = get_eclab_snapshot_folder()

    # Find all biologic servers
    for server in CONFIG["Servers"].values():
        if server.get("server_type") in {"biologic", "biologic_harvester"}:
            # Check active data path folder
            if server.get("data_path"):
                new_files = get_mprs(
                    server,
                    server["data_path"],
                    snapshot_folder,
                    force_copy=force_copy,
                )
                all_new_files.extend(new_files)

            # Check passive harvesters
            for folder in server.get("harvester_folders", []):
                new_files = get_mprs(
                    server,
                    folder,
                    snapshot_folder,
                    force_copy=force_copy,
                )
                all_new_files.extend(new_files)

    return all_new_files


def get_mpr_data(
    mpr_file: str | Path | bytes,
    mpl_file: str | Path | bytes | None = None,
) -> tuple[pl.DataFrame, dict, dict]:
    """Convert mpr file to dataframe."""
    if isinstance(mpr_file, (str, Path)):
        mpr_file = Path(mpr_file)
        data = yadg.extractors.extract("eclab.mpr", mpr_file)
    elif isinstance(mpr_file, bytes):
        extractor = ExtractorFactory(extractor={"filetype": "eclab.mpr"}).extractor
        data = yadg.extractors.extract_from_bytes(
            source=mpr_file,
            extractor=extractor,
        )
    else:
        msg = "mpr_file must be str, Path, or raw bytes of mpr file."
        raise TypeError(msg)

    # Build dict of arrays
    cols: dict[str, np.ndarray | int] = {}

    # Unix time - get start time from mpl if missing in mpr
    uts = data.coords["uts"].to_numpy()
    finished = bool(uts[0] != 0)  # If the start time is 0, job is ongoing, start time still only in mpl
    cols["uts"] = check_mpr_uts(uts, mpr_file, mpl_file)

    # Voltage
    voltage_col = next(col for col in ("Ewe", "<Ewe>") if col in data.data_vars)
    cols["V (V)"] = data[voltage_col].to_numpy()

    # Current
    I_units = {"A": 1, "mA": 1e-3, "uA": 1e-6}
    dq_units = {"mA·h": 3600 / 1000, "A·h": 3600}
    if "I" in data:
        multiplier = I_units.get(data["I"].attrs.get("units"), 1)
        cols["I (A)"] = data["I"].to_numpy() * multiplier
    elif "dq" in data:
        multiplier = dq_units.get(data["dq"].attrs.get("units"), 1)
        dt = np.diff(cols["uts"], prepend=np.inf)
        cols["I (A)"] = multiplier * data["dq"].to_numpy() / dt
    else:
        cols["I (A)"] = np.zeros_like(cols["uts"])

    # Cycle number
    cols["cycle_number"] = data["half cycle"].to_numpy() // 2 if "half cycle" in data else 0

    # Technique code
    cols["technique"] = data["mode"].to_numpy() if "mode" in data else 0

    # impedance block
    if all(k in data for k in ["freq", "Re(Z)", "-Im(Z)"]) and np.any(data["freq"]):
        cols["f (Hz)"] = data["freq"].to_numpy().astype("float32")
        cols["Re(Z) (ohm)"] = data["Re(Z)"].to_numpy().astype("float32")
        cols["Im(Z) (ohm)"] = (-data["-Im(Z)"]).to_numpy().astype("float32")

    df = pl.DataFrame(cols).with_columns(
        pl.col("V (V)").cast(pl.Float32),
        pl.col("I (A)").cast(pl.Float32),
        pl.col("technique").cast(pl.Int16),
        pl.col("cycle_number").cast(pl.Int32),
    )

    # Get metadata
    mpr_metadata = json.loads(data.attrs["original_metadata"])
    mpr_metadata["Finished"] = finished
    mpr_metadata["job_type"] = "eclab_mpr"
    yadg_metadata = {k: v for k, v in data.attrs.items() if k.startswith("yadg")}
    return pl.DataFrame(df), mpr_metadata, yadg_metadata


def check_mpr_uts(
    uts: np.ndarray, mpr_file: str | Path | bytes, mpl_file: str | Path | bytes | None = None
) -> np.ndarray:
    """Check if the unix timestamp is correct, attempts to find it from .mpl if not."""
    if uts[0] < 1000000000:  # The measurement started before 2001, assume wrong
        if not isinstance(mpr_file, (str, Path)) and not mpl_file:
            msg = "Incorrect start time in mpr file, reading from bytes, cannot auto-find mpl and no mpl provided."
            raise ValueError(msg)
        # Try to find the start datetime from the mpl
        if isinstance(mpr_file, (str, Path)) and not mpl_file:
            mpl_file = Path(mpr_file).with_suffix(".mpl")
            if not mpl_file.exists():
                msg = "Could not get acquisition start time from mpr, cannot find associated mpl file."
                raise ValueError(msg)
        if isinstance(mpl_file, (str, Path)):
            with Path(mpl_file).open(encoding="cp1252") as f:
                lines = f.readlines()
        elif isinstance(mpl_file, bytes):  # file-like object
            text = mpl_file.decode("cp1252", errors="replace")
            lines = text.splitlines()
        else:
            msg = "Cannot get start time from mpr or mpl file."
            raise ValueError(msg)
        try:
            for line in lines:
                if line.startswith("Acquisition started on : "):
                    datetime_str = line.split(":", 1)[1].strip()
                    # EC-lab mpl has no timezone info - assume it is in the same timezone
                    datetime_object = datetime.strptime(datetime_str, "%m/%d/%Y %H:%M:%S.%f")  # noqa: DTZ007
                    uts_start = datetime_object.replace(tzinfo=CONFIG["tz"]).timestamp()
                    uts = uts + uts_start
                    break
            else:
                msg = f"Incorrect start time in {mpr_file!s} and no start time in found {mpl_file!s}"
                raise ValueError(msg)
        except FileNotFoundError as e:
            msg = "Incorrect start time in mpr file, cannot find associated mpl file"
            raise ValueError(msg) from e
    return uts


def convert_mpr(
    mpr_file: str | Path | bytes,
    mpl_file: str | Path | bytes | None = None,
    sample_id: str | None = None,
    job_id: str | None = None,
    modified_date: datetime | None = None,
    file_name: str | None = None,
    *,
    update_database: bool = True,
) -> tuple[pl.DataFrame, dict]:
    """Convert a ec-lab mpr to dataframe, optionally update database.

    Args:
        mpr_file (str, Path, bytes): path to the mpr file, or raw bytes
        mpl_file (str, Path, bytes, optional): path to the associated mpl file, or raw bytes
        update_database (bool, optional): whether to save data and update tables in database
        sample_id (str, optional): Sample ID as in database, REQUIRED if reading from bytes
        job_id (str, optional): Job ID as in the database, will check dataframe hash if not used
        modified_date (datetime, optional): Used for last snapshot time, inferred from mpr_file if str/path
        file_name (str, optional): Filename uploaded to the database, inferred from mpr_file if str/path

    Returns:
        pd.DataFrame: DataFrame containing the time-series cycling data
        dict: metadata

    Columns in output DataFrame:
    - uts: unix timestamp in seconds
    - V (V): Cell voltage in volts
    - I (A): Current in amps
    - cycle_number: number of cycles within one technique
    - technique: code of technique using Biologic convention

    """
    # Ensure there is a Sample ID, Run ID, and optionally creation date
    if isinstance(mpr_file, (str, Path)):
        mpr_file = Path(mpr_file).resolve()
        if not sample_id:
            sample_id = get_sampleid_from_mpr(mpr_file)
        if not modified_date:
            modified_date = datetime.fromtimestamp(mpr_file.stat().st_mtime, tz=timezone.utc)
    elif isinstance(mpr_file, bytes):  # file-like object
        if not sample_id:
            msg = "Sample ID is required if reading from bytes"
            raise ValueError(msg)
        if not file_name:
            msg = "File name is required if reading from bytes"
            raise ValueError(msg)
    else:
        msg = "mpr_file must be str, Path, or file-like object"
        raise TypeError(msg)

    # Get data and metadata from mpr (and mpl) files
    df, mpr_metadata, yadg_metadata = get_mpr_data(mpr_file, mpl_file)

    # get sample data from database
    try:
        sample_data = get_sample_data(sample_id)
    except ValueError:
        sample_data = {}

    # Metadata to add to file
    technique_codes = {1: "Constant current", 2: "Constant voltage", 3: "Open circuit voltage"}
    metadata = {
        "provenance": {
            "snapshot_file": str(mpr_file) if isinstance(mpr_file, (str, Path)) else None,
            "yadg_metadata": yadg_metadata,
            "aurora_metadata": {
                "mpr_conversion": {
                    "repo_url": __url__,
                    "repo_version": __version__,
                    "method": "eclab_harvester.convert_mpr",
                    "datetime": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                },
            },
        },
        "job_data": mpr_metadata,
        "sample_data": sample_data,
        "glossary": {
            "uts": "Unix time stamp in seconds",
            "V (V)": "Cell voltage in volts",
            "I (A)": "Current across cell in amps",
            "cycle_number": "Number of cycles based on EC-lab half cycles",
            "technique": "code of technique using mpr conventions, see technique codes",
            "technique codes": technique_codes,
        },
    }

    # Save and update database
    if update_database:
        if not sample_id:
            logger.warning("Not saving %s, no valid Sample ID found", mpr_file)
            return df, metadata
        folder = get_sample_folder(sample_id) / "snapshots"
        if not folder.exists():
            folder.mkdir(parents=True)

        # Get the file stem and path
        if file_name:
            file_stem = Path(file_name).stem
        else:
            assert isinstance(mpr_file, (str, Path))  # noqa: S101
            file_stem = Path(mpr_file).stem

        parquet_filepath = folder / f"snapshot.{file_stem}.parquet"

        # Add the file/job information to the database
        add_data_to_db(sample_id, file_stem, df["uts"][0], df["uts"][-1], job_id)

        # Write to parquet file
        df.write_parquet(parquet_filepath, metadata={"AURORA:metadata": json.dumps(metadata)})

        # Update the database
        with sqlite3.connect(CONFIG["Database path"]) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT OR IGNORE INTO results (`Sample ID`) VALUES (?)",
                (sample_id,),
            )
            cursor.execute(
                "UPDATE results SET `Last snapshot` = ? WHERE `Sample ID` = ?",
                (modified_date.isoformat(timespec="seconds") if modified_date else None, sample_id),
            )
            cursor.close()
    return df, metadata


def get_sampleid_from_mpr(mpr_rel_path: str | Path) -> str:
    """Try to get the sample ID based on the remote file path."""
    # split the relative path into parts
    parts = Path(mpr_rel_path).parts
    run_id: str | None = None
    sample_number: int | None = None
    sample_id: str | None = None

    # From aurora-biologic API, files are stored base_folder/run_id/sample_id/job_id/files.mpr
    try:
        if parts[-4] == run_from_sample(parts[-3]):  # if this works, it was stored correctly
            return parts[-3]
    except IndexError:
        pass

    # If that did not work, this may be 'out of bounds' data

    # A run ID lookup table is defined in case run IDs are wrong on the server
    run_id_lookup = CONFIG.get("Run ID lookup", {})

    # Get valid run IDs from the database
    with sqlite3.connect(CONFIG["Database path"]) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT `Run ID` FROM samples")
        valid_run_ids = {row[0] for row in cursor.fetchall()}

    # This is usually stored as
    # base_folder/run_id/sample_number/files.mpr (run id index -3)
    # base_folder/run_id/sample_number/another_folder/files.mpr (run id index -4)
    for i in [-3, -4]:
        try:
            run_folder = parts[i]
            sample_folder = parts[i + 1]
        except IndexError as e:
            if i == -2:
                msg = f"Could not get run and sample number components for {mpr_rel_path}"
                raise ValueError(msg) from e
            continue
        # Check if the run_id is in the database or in the lookup table
        run_id = run_folder if run_folder in valid_run_ids else run_id_lookup.get(run_folder, None)

        if run_id:  # A run ID folder was found, now try to get the sample number
            try:
                sample_number = int(sample_folder)
                sample_id = f"{run_id}_{sample_number:02d}"
                break
            except ValueError:
                pass

    if not run_id or not sample_id:
        msg = f"Could not get Sample ID and Run ID for {mpr_rel_path}"
        raise ValueError(msg)
    return sample_id


def convert_all_mprs() -> None:
    """Convert all raw .mpr files to parquet.

    Looks in configuration for "Servers" with "server_type": "biologic" or
    "biologic_harvester".
    Gets data from "data_path" and "harvester_folders" list.
    """
    # walk through raw_folder and get the sample ID
    snapshot_folder = get_eclab_snapshot_folder()
    for dirpath, _dirnames, filenames in os.walk(snapshot_folder):
        for filename in filenames:
            if filename.endswith(".mpr"):
                full_path = Path(dirpath) / filename
                try:
                    convert_mpr(
                        full_path,
                        update_database=True,
                    )
                    logger.info("Converted %s", full_path)
                except (ValueError, IndexError, KeyError, RuntimeError):
                    logger.exception("Error converting %s", full_path)
                    continue


def main() -> None:
    """Harverst and convert all new mpr files."""
    new_files = get_all_mprs()
    for mpr_path in new_files:
        try:
            convert_mpr(
                mpr_path,
                update_database=True,
            )
        except (ValueError, IndexError, KeyError, RuntimeError):
            logger.exception("Error converting %s", mpr_path)
            continue


if __name__ == "__main__":
    setup_logging()
    main()
