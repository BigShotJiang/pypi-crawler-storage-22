"""Copyright © 2025-2026, Empa.

Harvest Neware data files and convert to aurora-compatible parquet files.

Define the machines to grab files from in the config.json file.

Run the script to harvest and convert all neware files.
"""

import json
import logging
import re
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import fastnda
import pandas as pd
import polars as pl
import xmltodict

from aurora_cycler_manager.analysis import analyse_sample
from aurora_cycler_manager.config import get_config
from aurora_cycler_manager.data_parse import get_sample_folder
from aurora_cycler_manager.database_funcs import (
    check_job_running,
    get_all_sampleids,
    get_job_data,
    get_or_create_job_id_from_server,
    get_sample_data,
    update_harvester,
)
from aurora_cycler_manager.setup_logging import setup_logging
from aurora_cycler_manager.ssh import SSHConnection
from aurora_cycler_manager.utils import parse_datetime
from aurora_cycler_manager.version import __url__, __version__

# Load configuration
CONFIG = get_config()
logger = logging.getLogger(__name__)
# This warning from yadg is handled
logging.getLogger("fastnda.ndax").addFilter(
    lambda record: "negative jumps in the 'timestamp' column" not in record.getMessage()
)
logging.getLogger("fastnda.ndax").addFilter(lambda record: "Reading ndc" not in record.getMessage())


def get_neware_snapshot_folder() -> Path:
    """Get the path to the snapshot folder for neware files."""
    snapshot_parent = CONFIG.get("Snapshots folder path")
    if not snapshot_parent:
        msg = (
            "No 'Snapshots folder path' in config file. "
            f"Please fill in the config file at {CONFIG.get('User config path')}.",
        )
        raise ValueError(msg)
    snapshot_path = Path(snapshot_parent) / "neware_snapshots"
    snapshot_path.mkdir(parents=True, exist_ok=True)
    return snapshot_path


def harvest_neware_files(
    server: dict,
    server_copy_folder: str,
    local_folder: str | Path,
    *,
    force_copy: bool = False,
) -> list[Path]:
    """Get Neware files from subfolders of specified folder.

    Args:
        server (dict): Server dictionary, as defined in config
        server_copy_folder (str): Folder to search and copy files
        local_folder (str): Folder to copy files to
        force_copy (bool): Copy all files regardless of modification date

    Returns:
        list of new files copied

    """
    # Set default cutoff date, use local timezone
    cutoff_uts = 0.0
    if not force_copy:  # Set cutoff date to last snapshot from database
        with sqlite3.connect(CONFIG["Database path"]) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT `Last snapshot` FROM harvester WHERE `Server label`=? AND `Server hostname`=? AND `Folder`=?",
                (server["label"], server["hostname"], server_copy_folder),
            )
            result = cursor.fetchone()
            cursor.close()
        if result:
            cutoff_uts = parse_datetime(result[0]).timestamp()

    # Connect to the server and copy the files
    with SSHConnection(server) as ssh:
        remote_files = ssh.check_new_files(server_copy_folder, [".ndax"], cutoff_uts)
        job_ids = [
            get_or_create_job_id_from_server(server["label"], Path(file).stem.replace("_", "-"))
            for file in remote_files
        ]
        local_files = [Path(local_folder) / (job_id + ".ndax") for job_id in job_ids]
        copy_datetime = datetime.now(timezone.utc)
        ssh.get_files(local_files, remote_files)

    update_harvester(server, server_copy_folder, copy_datetime)
    return local_files


def snapshot_raw_data(job_id: str) -> Path | None:
    """Copy latest data from server into local .ndax file.

    Connects to server, searches for the raw .ndc files, copies into local .ndax file.

    Args:
        job_id (str): full job ID from database with server label e.g. nw4-22-6-4-26

    Returns:
        Path to the .ndax file created or modified, or None if no files updated.

    """
    # File to create or update
    ndax_path = get_neware_snapshot_folder() / f"{job_id}.ndax"

    # Get the job info from database
    job_data = get_job_data(job_id)

    # Get device information from job ID on server
    dev_id, subdev_id, channel_id, test_id = re.split(r"[-_]", job_data["Job ID on server"])
    # Neware has a different format for raw data. Folder is raw_data_folder/YYYYMMDD/,
    # file is YYYYMMDD_HHMMSS_27{len(4) 0 padded device_id}_0_{(subdevid-1)*8 + channel_id}_{test_id} + file type .ndc

    # Need the start/submission time to locate the raw data on Neware server
    if job_data["Submitted"]:
        submitted = datetime.fromisoformat(job_data["Submitted"]).strftime("%Y%m%d")  # Get YYYYMMDD format
    elif ndax_path.exists():
        metadata = get_neware_metadata(ndax_path)
        if metadata.get("Start time"):
            submitted = datetime.fromisoformat(metadata["Start time"]).strftime("%Y%m%d")
        else:
            msg = "No submit time in database, no start time in file, cannot find raw data on server."
            raise ValueError(msg)
    else:
        msg = "No submit time in database, no local file to check, cannot find raw data on server."
        raise ValueError(msg)

    # Get the server from the config
    server = CONFIG["Servers"].get(job_data["Server label"])
    if not server:
        msg = f"No server found with label '{job_data['Server label']}' in config."
        raise ValueError(msg)
    raw_data_folder = server.get("neware_raw_data_path", "C:/Program Files (x86)/NEWARE/BTSServer80/NdcFile/")

    # Build the paths to check - assumes device type 27
    full_folder = raw_data_folder + submitted
    full_folder_alt = full_folder + "_NoTestInfoData"
    file_middle = (
        "27" + str(dev_id).zfill(4) + "_0_" + str((int(subdev_id) - 1) * 8 + int(channel_id)) + "_" + str(test_id)
    )

    # Powershell command to return paths of files matching the pattern
    ps_command = f"""
        $ProgressPreference = 'SilentlyContinue'

        $searchFolders = @("{full_folder}", "{full_folder_alt}")
        $file_middle = "{file_middle}"
        $file_endings = @(".ndc", "_step.ndc", "_runInfo.ndc", "_log.ndc", "_es.ndc")

        $foundFiles = [ordered]@{{}}
        foreach ($ending in $file_endings) {{
            $matchedFile = $null
            foreach ($folder in $searchFolders) {{
                if (Test-Path $folder) {{
                    $pattern = "*$file_middle$ending"
                    $match = Get-ChildItem -Path $folder -Recurse -File -ErrorAction SilentlyContinue |
                        Where-Object {{ $_.Name -like $pattern }} | Select-Object -First 1

                    if ($match) {{
                        $matchedFile = $match.FullName
                        break
                    }}
                }}
            }}
            $foundFiles[$ending] = $matchedFile
        }}
        $foundFiles | ConvertTo-Json -Compress
    """

    # Connect to the server
    with SSHConnection(server) as ssh:
        # Run pattern matching command
        _stdin, stdout, stderr = ssh.exec_command(ps_command)

        # Parse the output
        output = stdout.read().decode("utf-8").strip()
        error = stderr.read().decode("utf-8").strip()
        if error:
            msg = f"Error finding raw files: {error}"
            raise RuntimeError(msg)
        found_files = json.loads(output)

        # If nothing found, give up
        if all(file is None for file in found_files.values()):
            return None

        # Otherwise create or update the ndax file with new raw data
        logger.info("Updating ndax file at '%s'", ndax_path)

        # Create a temporary directory to store the files
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)

            # If ndax already exists, extract it to the temporary directory
            if ndax_path.exists():
                with zipfile.ZipFile(ndax_path, "r") as zf:
                    zf.extractall(tmp_path)

            # Copy the new files over, replacing any existing ones
            local_files = [tmp_path / ("data" + ending) for ending in found_files]
            remote_files = list(found_files.values())

            ssh.get_files(local_files, remote_files)

            # Write a new zip
            with zipfile.ZipFile(ndax_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for file in tmp_path.rglob("*"):
                    if file.is_file():
                        zf.write(file, arcname=file.relative_to(tmp_path))
    return ndax_path


def harvest_all_neware_files(*, force_copy: bool = False) -> list[Path]:
    """Get neware files from all servers specified in the config.

    Looks in configuration for "Servers" with "server_type": "neware" or
    "neware_harvester".
    Gets data from "data_path" and "harvester_folders" list.
    "harvester_folders".
    """
    all_new_files = []
    snapshots_folder = get_neware_snapshot_folder()

    # Find all neware servers
    for server in CONFIG["Servers"].values():
        if server.get("server_type") in {"neware", "neware_harvester"}:
            # Check activate data path folder
            if server.get("data_path"):
                new_files = harvest_neware_files(
                    server,
                    server["data_path"],
                    snapshots_folder,
                    force_copy=force_copy,
                )
                all_new_files.extend(new_files)

            # Check passive harvesters
            for folder in server.get("harvester_folders", []):
                new_files = harvest_neware_files(
                    server,
                    folder,
                    snapshots_folder,
                    force_copy=force_copy,
                )
                all_new_files.extend(new_files)

    return all_new_files


def get_neware_data(filepath: Path) -> pl.DataFrame:
    """Get dataframe from a Neware ndax or xlsx file."""
    if filepath.suffix == ".xlsx":
        df = get_neware_xlsx_data(filepath)
    elif filepath.suffix == ".ndax":
        df = get_neware_ndax_data(filepath)
    else:
        msg = f"File type {filepath.suffix} not supported"
        raise ValueError(msg)
    return df


def get_neware_metadata(filepath: Path) -> dict:
    """Get metadata dict from a Neware ndax or xlsx file."""
    if filepath.suffix == ".xlsx":
        metadata = get_neware_xlsx_metadata(filepath)
        metadata["job_type"] = "neware_xlsx"
    elif filepath.suffix == ".ndax":
        metadata = get_neware_ndax_metadata(filepath)
        metadata["job_type"] = "neware_ndax"
    else:
        msg = f"File type {filepath.suffix} not supported"
        raise ValueError(msg)
    return metadata


def get_neware_xlsx_metadata(file_path: Path) -> dict:
    """Get metadata from a neware xlsx file.

    Args:
        file_path (Path): Path to the neware xlsx file

    Returns:
        dict: Metadata from the file

    """
    # Get the test info, including barcode / remarks
    df = pd.read_excel(file_path, sheet_name="test", header=None, engine="calamine")

    # In first column, find index where value is "Test information" and "Step plan"
    test_idx = df[df.iloc[:, 0] == "Test information"].index[0]
    step_idx = df[df.iloc[:, 0] == "Step plan"].index[0]

    # Get test info, remove empty columns and rows
    test_settings = df.iloc[test_idx + 1 : step_idx, :]
    test_settings = test_settings.dropna(axis=1, how="all")
    test_settings = test_settings.dropna(axis=0, how="all")

    # Flatten and convert to dict
    flattened = test_settings.to_numpy().flatten().tolist()
    flattened = [str(x) for x in flattened if str(x) != "nan"]
    test_info = {
        flattened[i]: flattened[i + 1] for i in range(0, len(flattened), 2) if flattened[i] and flattened[i] != "-"
    }
    test_info = {k: v for k, v in test_info.items() if (k and k not in ("-", "nan")) or (v and v not in ("-", "nan"))}

    # Payload
    payload = df.iloc[step_idx + 2 :, :]
    payload.columns = df.iloc[step_idx + 1]
    payload_dict = payload.to_dict(orient="records")

    payload_dict = [{k: v for k, v in record.items() if str(v) != "nan"} for record in payload_dict]

    # In Neware step information, 'Cycle' steps have different columns defined within the row
    # E.g. the "Voltage (V)" column has a value like "Cycle count:2"
    # We find these entires, and rename the key e.g. "Voltage (V)": "Cycle count:2" becomes "Cycle count": 2
    rename = {
        "Voltage(V)": "Voltage (V)",
        "Current(A)": "Current (A)",
        "Time(s)": "Time (s)",
        "Cut-off curr.(A)": "Cut-off current (A)",
    }
    for record in payload_dict:
        # change Voltage(V) to Voltage (V) if it exists
        for k, v in rename.items():
            if k in record:
                record[v] = record.pop(k)
        if record.get("Step Name") == "Cycle":
            # find values with ":" in them, and split them into key value pairs, delete the original key
            bad_key_vals = {k: v for k, v in record.items() if ":" in str(v)}
            for k, v in bad_key_vals.items():
                del record[k]
                new_k, new_v = v.split(":")
                record[new_k] = new_v

    # Add to test_info
    test_info["Payload"] = payload_dict

    # Check if test is finished
    df = pd.read_excel(file_path, sheet_name="log", header=None, engine="calamine")
    if df["Event"].iloc[-1] == "Finished test":
        test_info["End time"] = df["Time"].iloc[-1]
        test_info["Finished"] = True
    else:
        test_info["Finished"] = False

    return test_info


# change every dict with {'Value': 'some value'} to 'some value'
def _scrub_dict(d: dict) -> dict:
    """Scrub 'Value' and 'Main' keys from dict."""
    for k, v in d.items():
        if isinstance(v, dict):
            if "Value" in v:
                d[k] = v["Value"]
            elif "Main" in v:
                d[k] = v["Main"]
            _scrub_dict(v)
    return d


def _convert_dict_values(d: dict) -> dict:
    """Convert values in step.xml dict to floats and scale to SI units."""
    for key, value in d.items():
        if isinstance(value, dict):
            if key == "Volt":
                for sub_key in value:
                    value[sub_key] = float(value[sub_key]) / 10000
            elif key in ("Curr", "Time"):
                for sub_key in value:
                    value[sub_key] = float(value[sub_key]) / 1000
            else:
                _convert_dict_values(value)
        elif isinstance(value, str):
            if key in ("Volt", "Stop_Volt"):
                d[key] = float(value) / 10000
            elif key in ("Curr", "Stop_Curr", "Time"):
                d[key] = float(value) / 1000
    return d


state_dict = {
    "1": "CC Chg",
    "2": "CC DChg",
    "3": "CV Chg",
    "4": "Rest",
    "5": "Cycle",
    "6": "End",
    "7": "CCCV Chg",
    "8": "CP DChg",
    "9": "CP Chg",
    "10": "CR DChg",
    "13": "Pause",
    "16": "Pulse",
    "17": "SIM",
    "19": "CV DChg",
    "20": "CCCV DChg",
    "21": "Control",
    "26": "CPCV DChg",
    "27": "CPCV Chg",
}
# For switching back to ints from NewareNDA
state_dict_rev = {v: int(k) for k, v in state_dict.items()}
state_dict_rev_underscored = {v.replace(" ", "_"): int(k) for k, v in state_dict.items()}


def _clean_ndax_step(d: dict) -> dict:
    """Extract useful info from dict from step.xml inside .ndax file."""
    # get rid of 'root' 'config' keys
    d = d["root"]["config"]
    # scrub 'Value' and 'Main' keys
    d = _scrub_dict(d)
    # put 'Head_Info' dict into the main dict
    d.update(d.pop("Head_Info"))

    # convert all values to floats
    _convert_dict_values(d)

    # convert 'Step_Info' to a more readable 'Payload' list
    step_list = []
    step_info = d.pop("Step_Info")
    for k, v in step_info.items():
        if k == "Num":
            continue
        new_step: dict[str, int | float | str] = {}
        new_step["Step Index"] = int(v.get("Step_ID"))
        new_step["Step Name"] = state_dict.get(v.get("Step_Type"), "Unknown")
        record = v.get("Record")
        if record:
            new_step["Record settings"] = (
                str(record.get("Time"))
                + "s/"
                + str(record.get("Curr", "0"))
                + "A/"
                + str(record.get("Volt", "0"))
                + "V"
            )
        limit = v.get("Limit")
        if limit:
            new_step["Current (A)"] = limit.get("Curr", 0)
            new_step["Voltage (V)"] = limit.get("Volt", 0)
            new_step["Time (s)"] = limit.get("Time", 0)
            new_step["Cut-off voltage (V)"] = limit.get("Stop_Volt", 0)
            new_step["Cut-off current (A)"] = limit.get("Stop_Curr", 0)
            other = limit.get("Other", {})
            if other:
                new_step["Cycle count"] = int(other.get("Cycle_Count", 0))
                new_step["Start step ID"] = int(other.get("Start_Step_ID", 0))
        # remove keys where value is 0 and add to list
        new_step = {k: v for k, v in new_step.items() if v != 0}
        step_list.append(new_step)
    d["Payload"] = step_list
    # Change some keys for consistency with xlsx
    d["Remarks"] = d.pop("Remark", "")
    d["Start step ID"] = int(d.pop("Start_Step", 1))
    # Get rid of keys that are not useful
    unwanted_keys = ["SMBUS", "Whole_Prt", "Guid", "Operate", "type", "version", "SCQ", "SCQ_F", "RateType", "Scale"]
    for k in unwanted_keys:
        d.pop(k, None)
    return d


def get_neware_ndax_metadata(file_path: Path) -> dict:
    """Extract metadata from Neware .ndax file.

    Args:
        file_path (Path): Path to the .ndax file

    Returns:
        dict: Metadata from the file

    """
    # Get step.xml and testinfo.xml from the .ndax file, if not present check database for metadata

    zf = zipfile.PyZipFile(str(file_path))

    if "Step.xml" in zf.namelist() and "TestInfo.xml" in zf.namelist():
        # Get the step info from step.xml
        step = zf.read("Step.xml")
        step_parsed = xmltodict.parse(step.decode(errors="replace"), attr_prefix="")
        metadata = _clean_ndax_step(step_parsed)

        # Add test info
        testinfo = xmltodict.parse(zf.read("TestInfo.xml").decode(errors="replace"), attr_prefix="")
        testinfo = testinfo.get("root", {}).get("config", {}).get("TestInfo", {})
        metadata["Barcode"] = testinfo.get("Barcode")
        metadata["Start time"] = testinfo.get("StartTime")
        endtime = testinfo.get("EndTime")
        metadata["End time"] = endtime or None
        metadata["Finished"] = bool(endtime)
        metadata["Step name"] = testinfo.get("StepName")
        metadata["Device type"] = testinfo.get("DevType")
        metadata["Device ID"] = testinfo.get("DevID")
        metadata["Subdevice ID"] = testinfo.get("UnitID")  # Seems like this doesn't work from Neware's side
        metadata["Channel ID"] = testinfo.get("ChlID")
        metadata["Test ID"] = testinfo.get("TestID")
        metadata["Voltage range (V)"] = float(testinfo.get("VoltRange", 0))
        metadata["Current range (mA)"] = float(testinfo.get("CurrRange", 0))

    else:
        metadata = get_neware_metadata_from_db(file_path.stem)

    return metadata


def get_neware_metadata_from_db(job_id: str) -> dict:
    """Get relevant metadata from the database for a Neware file.

    Args:
        job_id (str): Name of Job ID, (should be filename without extension)

    Returns:
        dict: Metadata from the database

    """
    job_data = get_job_data(job_id)
    finished = not check_job_running(job_id)
    # Check if payload needs parsing
    metadata = {}
    if isinstance(job_data, dict | list):  # It is already parsed
        metadata = {"Payload": job_data["Payload"]}
    elif isinstance(job_data, str):
        if job_data["Payload"].startswith("<"):  # It is an xml string
            xml_payload = xmltodict.parse(job_data["Payload"], attr_prefix="")
            metadata = _clean_ndax_step(xml_payload)
        elif job_data["Payload"].startswith("["):  # It is JSON list of steps
            metadata = {"Payload": json.loads(job_data["Payload"])}
    device_id, subdevice_id, channel_id, test_id = re.split(r"[-_]", job_data["Job ID on server"])
    metadata["Start time"] = job_data["Submitted"]
    metadata["Device ID"] = device_id
    metadata["Subdevice ID"] = subdevice_id
    metadata["Channel ID"] = channel_id
    metadata["Test ID"] = test_id
    metadata["Barcode"] = job_data["Sample ID"]
    metadata["Finished"] = finished
    return metadata


def get_sampleid_from_metadata(metadata: dict, known_samples: list[str] | None = None) -> str | None:
    """Get sample ID from Remarks or Barcode in the Neware metadata."""
    # Get sampleid from test_info
    barcode_sampleid = metadata.get("Barcode", "")
    remark_sampleid = metadata.get("Remarks", "")
    sampleid = None

    if not known_samples:
        known_samples = get_all_sampleids()
    for possible_sampleid in [barcode_sampleid, remark_sampleid]:
        if possible_sampleid in known_samples:
            sampleid = possible_sampleid
            break
    if sampleid is None:  # May be user error, try some common fixes
        logger.info(
            "Could not find Sample ID '%s' or '%s' in database, trying to infer it",
            barcode_sampleid,
            remark_sampleid,
        )
        for possible_sampleid in [remark_sampleid, barcode_sampleid]:
            # Should be YYMMDD-otherstuff-XX, where XX is a number
            sampleid_parts = re.split("_|-", possible_sampleid)
            if len(sampleid_parts) > 1:
                if len(sampleid_parts[0]) == 8:  # YYYYMMDD -> YYMMDD
                    sampleid_parts[0] = sampleid_parts[0][2:]
                sampleid_parts[-1] = sampleid_parts[-1].zfill(2)  # pad with zeros
                # Check if this is consistent with any known samples
                possible_samples = [s for s in known_samples if all(parts in s for parts in sampleid_parts)]
                if len(possible_samples) > 1:
                    possible_samples = [s for s in possible_samples if "_".join(sampleid_parts) in s]
                if len(possible_samples) == 1:
                    sampleid = possible_samples[0]
                    logger.info("Barcode '%s' inferred as Sample ID '%s'", possible_sampleid, sampleid)
                    break
    if not sampleid:
        logger.warning(
            "Barcode: '%s', or Remark: '%s' not recognised as a Sample ID",
            barcode_sampleid,
            remark_sampleid,
        )
    return sampleid


def get_neware_xlsx_data(file_path: Path) -> pl.DataFrame:
    """Convert Neware xlsx file to dictionary. DEPRACATED: use ndax not xlsx."""
    df = pd.read_excel(file_path, sheet_name="record", header=0, engine="calamine")
    required_columns = ["Voltage(V)", "Current(A)", "Step Type", "Date", "Time"]
    if not all(col in df.columns for col in required_columns):
        msg = f"Missing required columns in {file_path}: {required_columns}"
        raise ValueError(msg)
    output_df = pd.DataFrame()
    output_df["V (V)"] = df["Voltage(V)"]
    output_df["I (A)"] = df["Current(A)"]
    output_df["technique"] = df["Step Type"].apply(lambda x: state_dict_rev.get(x, -1)).astype(int)
    # Every time the Step Type changes from a string containing "DChg" or "Rest" increment the cycle number
    output_df["cycle_number"] = (
        df["Step Type"].str.contains(r" DChg| DCHg|Rest", regex=True).shift(1)
        & df["Step Type"].str.contains(r" Chg", regex=True)
    ).cumsum()
    # convert date string from df["Date"] in format YYYY-MM-DD HH:MM:SS to uts timestamp in seconds
    output_df["uts"] = df["Date"].apply(lambda x: datetime.strptime(x, "%Y-%m-%d %H:%M:%S").timestamp())  # noqa: DTZ007
    # add 1e-6 to Timestamp where Time is 0 - negligible and avoids errors when sorting
    output_df["uts"] = output_df["uts"] + (df["Time"] == 0) * 1e-6
    return pl.DataFrame(output_df)


def get_neware_ndax_data(file_path: Path) -> pl.DataFrame:
    """Convert Neware ndax file to dictionary."""
    df = fastnda.read(file_path)
    if len(df) == 0:
        msg = f"No data in file {file_path.name}"
        raise ValueError(msg)
    df = df.with_columns(
        [
            pl.col("voltage_V").alias("V (V)"),
            (pl.col("current_mA") / 1000).alias("I (A)"),
            pl.col("step_type")
            .cast(pl.String)
            .replace_strict(state_dict_rev_underscored, return_dtype=pl.UInt32)
            .alias("technique"),
            pl.col("cycle_count").alias("cycle_number"),
            (pl.col(["total_time_s"]) + df["unix_time_s"][0] + (df["step_time_s"] == 0) * 1e-6).alias("uts"),
        ]
    )
    return df.select(["V (V)", "I (A)", "technique", "cycle_number", "uts"])


def update_database_job(
    filepath: Path,
    sampleid: str | None = None,
    known_samples: list[str] | None = None,
) -> None:
    """Update the database with job information.

    Args:
        filepath (Path): Path to the file
        sampleid (str, optional): Sample ID to use, otherwise find from metadata
        known_samples (list[str], optional): List of known Sample IDs to check against

    """
    metadata = get_neware_metadata(filepath)
    if sampleid is None:
        sampleid = get_sampleid_from_metadata(metadata, known_samples)
    if not sampleid:
        msg = f"Sample ID not found in metadata for file {filepath}"
        raise ValueError(msg)
    job_id = filepath.stem
    job_data = get_job_data(job_id)
    job_id_on_server = job_data["Job ID on server"]
    server_label = job_data["Server label"]
    pipeline = job_data["Pipeline"]
    submitted = metadata.get("Start time")
    payload = json.dumps(metadata.get("Payload"))
    last_snapshot_uts = filepath.stat().st_birthtime
    last_snapshot = datetime.fromtimestamp(last_snapshot_uts, tz=timezone.utc).isoformat(timespec="seconds")

    server_config = CONFIG["Servers"].get(job_data["Server label"], {})
    server_hostname = server_config.get("hostname")
    if not server_hostname:
        msg = f"Server hostname not found for server label {server_label}"
        raise ValueError(msg)

    with sqlite3.connect(CONFIG["Database path"]) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT OR IGNORE INTO jobs (`Job ID`) VALUES (?)",
            (job_id,),
        )
        cursor.execute(
            "UPDATE jobs SET "
            "`Job ID on server` = ?, `Pipeline` = ?, `Sample ID` = ?, "
            "`Server Label` = ?, `Server Hostname` = ?, `Submitted` = ?, "
            "`Payload` = ?, `Last Snapshot` = ?, `Job ID on server` = ? "
            "WHERE `Job ID` = ?",
            (
                job_id_on_server,
                pipeline,
                sampleid,
                server_label,
                server_hostname,
                submitted,
                payload,
                last_snapshot,
                job_id_on_server,
                job_id,
            ),
        )


def convert_neware_data(
    file_path: Path | str,
    sampleid: str | None = None,
    known_samples: list[str] | None = None,
    *,
    save_file: bool = True,
) -> tuple[pl.DataFrame, dict]:
    """Convert a neware file to a dataframe and save as parquet.

    Args:
        file_path (Path): Path to the neware file
        sampleid (str, optional): Sample ID to use, otherwise find from metadata
        known_samples (list[str], optional): List of known Sample IDs to check against
        save_file (bool): Whether to save the file to the data lake

    Returns:
        tuple[pd.DataFrame, dict]: DataFrame containing the cycling data and metadata

    """
    # Get test information and Sample ID
    file_path = Path(file_path)
    df = get_neware_data(file_path)
    job_data = get_neware_metadata(file_path)
    if sampleid is None:
        sampleid = get_sampleid_from_metadata(job_data, known_samples)

    # If there is a valid Sample ID, get sample metadata from database
    sample_data = None
    if sampleid:
        sample_data = get_sample_data(sampleid)

    # Metadata to add
    job_data["Technique codes"] = state_dict
    current_datetime = datetime.now(timezone.utc).isoformat(timespec="seconds")
    metadata = {
        "provenance": {
            "snapshot_file": str(file_path),
            "aurora_metadata": {
                "mpr_conversion": {
                    "repo_url": __url__,
                    "repo_version": __version__,
                    "method": "neware_harvester.convert_neware_data",
                    "datetime": current_datetime,
                },
            },
        },
        "job_data": job_data,
        "sample_data": sample_data,
        "glossary": {
            "uts": "Unix time stamp in seconds",
            "V (V)": "Cell voltage in volts",
            "I (A)": "Current across cell in amps",
            "cycle_number": "Number of cycles, increments when changing from discharge or rest to charge",
            "technique": "Code of technique using Neware convention, see technique codes",
            "technique codes": state_dict,
        },
    }

    if save_file:
        if not sampleid:
            logger.warning("Not saving %s, no valid Sample ID found", file_path)
            return df, metadata
        folder = get_sample_folder(sampleid) / "snapshots"
        if not folder.exists():
            folder.mkdir(parents=True)
        parquet_filepath = folder / f"snapshot.{file_path.stem}.parquet"

        # Ensure smallest data types are used
        df = df.cast({"V (V)": pl.Float32, "I (A)": pl.Float32, "technique": pl.Int16, "cycle_number": pl.Int32})

        # Write to parquet file
        df.write_parquet(parquet_filepath, metadata={"AURORA:metadata": json.dumps(metadata)})

        # Update the database
        creation_date = datetime.fromtimestamp(file_path.stat().st_mtime, tz=timezone.utc).isoformat(timespec="seconds")
        with sqlite3.connect(CONFIG["Database path"]) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT OR IGNORE INTO results (`Sample ID`) VALUES (?)",
                (sampleid,),
            )
            cursor.execute(
                "UPDATE results SET `Last snapshot` = ? WHERE `Sample ID` = ?",
                (creation_date, sampleid),
            )
            cursor.close()

    return df, metadata


def convert_all_neware_data() -> None:
    """Convert all neware files to parquet files."""
    # Get all xlsx and ndax files in the raw folder recursively
    snapshots_folder = get_neware_snapshot_folder()
    neware_files = [file for file in snapshots_folder.rglob("*") if file.suffix in [".xlsx", ".ndax"]]
    new_samples = set()
    known_samples = get_all_sampleids()
    for file in neware_files:
        logger.info("Converting %s", file)
        try:
            _data, metadata = convert_neware_data(file, save_file=True, known_samples=known_samples)
            if metadata is not None:
                sampleid = metadata.get("sample_data", {}).get("Sample ID") if metadata.get("sample_data") else None
                if sampleid:
                    update_database_job(file, sampleid=sampleid, known_samples=known_samples)
                    new_samples.add(sampleid)
                    logger.info("Converted %s", sampleid)
        except (ValueError, AttributeError):
            logger.exception("Error converting %s", file)
    logger.info("Analysing %d samples", len(new_samples))
    for sample in new_samples:
        try:
            analyse_sample(sample)
            logger.info("Analysed %s", sample)
        except (ValueError, PermissionError, RuntimeError, FileNotFoundError, KeyError):
            logger.exception("Error analysing %s", sample)


def main() -> None:
    """Harvest and convert files that have changed."""
    new_files = harvest_all_neware_files()
    new_samples = set()
    known_samples = get_all_sampleids()
    logger.info("Processing %d files", len(new_files))
    for file in new_files:
        logger.info("Processing %s", file)
        try:
            _data, metadata = convert_neware_data(file, save_file=True, known_samples=known_samples)
            update_database_job(file, known_samples=known_samples)
            if metadata is not None:
                sampleid = metadata.get("sample_data", {}).get("Sample ID")
                if sampleid:
                    new_samples.add(sampleid)
                    logger.info("Converted %s", sampleid)
        except Exception:
            logger.exception("Error converting %s", file)
    logger.info("Analysing %d samples", len(new_samples))
    for sample in new_samples:
        try:
            analyse_sample(sample)
            logger.info("Analysed %s", sample)
        except Exception:
            logger.exception("Error analysing %s", sample)


if __name__ == "__main__":
    setup_logging()
    main()
