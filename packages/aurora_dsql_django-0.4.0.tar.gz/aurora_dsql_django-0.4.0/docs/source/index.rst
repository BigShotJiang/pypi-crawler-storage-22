.. AuroraDSQL documentation master file, created by
   sphinx-quickstart on Wed Oct 30 21:16:44 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

AuroraDSQL documentation
========================
This is the adapter for enabling development of Django applications using Aurora DSQL.

Installation
------------

.. toctree::
   :maxdepth: 2

   guide/installation


Getting Started
---------------

.. toctree::
   :maxdepth: 2

   guide/getting_started

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
