# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

TEST_HOST = "test.dsql.us-east-1.on.aws"
TEST_USER = "admin"
