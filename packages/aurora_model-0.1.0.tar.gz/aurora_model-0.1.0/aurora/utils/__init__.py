# aurora/utils/__init__.py
from aurora.utils.path_utils import get_package_file_path