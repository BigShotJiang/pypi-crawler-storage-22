# aurora/utils/path_utils.py
import importlib.resources
from pathlib import Path


def get_package_file_path(relative_path: str) -> str:
    """
    Get the absolute path of a static file inside the installed package.
    Optimized for Python ≥3.10: uses stable importlib.resources.files() API.
    No extra dependencies required (built-in standard library).

    Args:
        relative_path: Relative path to the file within the package (e.g., "bert_config/config.json")

    Returns:
        Absolute system path to the file (as string, compatible with old code logic)
    """
    # 1. Get package root (stable API for Python ≥3.10, no deprecation warnings)
    package_root = importlib.resources.files("aurora")

    # 2. Join package root with target file's relative path (returns Path object directly)
    #    Path object operations are optimized in Python 3.10+
    file_path: Path = package_root.joinpath(relative_path)

    # 3. Resolve to absolute path and convert to string (to keep compatibility with existing code)
    #    For Python ≥3.10, Path.resolve() is more robust against symbolic links
    return str(file_path.resolve(strict=True))