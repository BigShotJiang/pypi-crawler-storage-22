# setup.py
from setuptools import setup, find_packages

def get_version():
    """
    Get the package version from aurora/__init__.py
    If version is not found, return default "0.1.0"
    """
    try:
        with open("aurora/__init__.py", "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("__version__"):
                    return line.strip().split("=")[1].strip().strip('"')
    except FileNotFoundError:
        pass
    return "0.1.0"

# Core packaging configuration
setup(
    name="aurora-model",
    version=get_version(),
    packages=find_packages(),
    install_requires=[
        "torch>=2.4.0",
        "torchvision>=0.19.0",
        "transformers>=4.50.0",
        "huggingface_hub>=0.16.0",
        "numpy>=1.21.0",
        "scipy>=1.7.0",
        "einops>=0.8.1"
        # ✅ No extra dependencies needed for Python ≥3.10 (importlib is built-in)
    ],
    include_package_data=True,
    package_data={
        "aurora": [
            "bert_config/*.json",
            "vit_config/*.json",
            "*.json",
            "utils/*.py"
        ],
    },
    author="Your Name",
    author_email="your_email@example.com",
    description="Aurora: A multimodal time series prediction model based on Transformers",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        # ✅ Explicitly mark support for Python 3.10+ (remove lower versions if needed)
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    # ✅ Explicitly require Python ≥3.10 (no lower versions)
    python_requires=">=3.10",
)