"""可选扩展（Contrib）。

该目录用于放置与核心框架解耦的可选集成能力（例如管理后台、监控面板等）。
"""

from __future__ import annotations

__all__ = []


