"""通道后端实现。"""

from .broadcaster import BroadcasterChannel

__all__ = ["BroadcasterChannel"]
