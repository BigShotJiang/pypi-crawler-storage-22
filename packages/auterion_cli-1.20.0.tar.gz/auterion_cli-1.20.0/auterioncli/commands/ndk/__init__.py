from .riveter_tool.riveter_command import RiveterCommand

def available_ndk_tools(config):
    return {
        'riveter': RiveterCommand(config)
    }
