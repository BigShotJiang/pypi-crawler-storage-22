from ..command_base import CliCommand
from . import available_ndk_tools

class NDKCommand(CliCommand):
    @staticmethod
    def help():
        return 'NDK tools set that allows deep modifications of software components'

    def needs_device(self, args):
        return False

    def __init__(self, config):
        self._config = config

    def setup_parser(self, parser):
        self.tools = available_ndk_tools(self._config)
        self.parser_help = parser.print_help

        ndk_subparser = parser.add_subparsers(title="NDK arguments", metavar='<tool>', dest="ndk_tool")

        for name, tool in self.tools.items():
            tool_parser = ndk_subparser.add_parser(name, help=tool.help())
            tool.setup_parser(tool_parser)

    def run(self, args):
        if args.ndk_tool is None:
            self.parser_help()
            exit(1)

        try:
            # Run tool
            self.tools[args.ndk_tool].run(args)
        except Exception as e:
            # Give the tool a chance to handle its exceptions
            self.tools[args.ndk_tool].handle_exception(e)
        except KeyboardInterrupt:
            print("Aborting..")
            exit(1) 

    def handle_exception(self, exception):
        raise exception
