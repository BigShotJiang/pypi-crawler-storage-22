import os
import yaml
import subprocess

from ...command_base import CliCommand
from auterioncli.meta_util import eprint

def arg_file_path_type(parser, arg):
    if os.path.isfile(arg):
        return arg
    parser.error('File %s does not exist' % arg)

def arg_dir_path_type(parser, arg):
    if os.path.isdir(arg):
        return arg
    parser.error('Directory %s does not exist' % arg)

def run_command(commands, cwd='.', shell=False):
    process = subprocess.Popen(commands, cwd=cwd, shell=shell, text=True)

    # Wait for the process to complete
    process.wait()

    # Check if the process exited with a non-zero code (indicating an error)
    if process.returncode != 0:
        raise subprocess.CalledProcessError(process.returncode, commands)

    return process.returncode

def riveter_init(args):
    dest_path = os.path.abspath(args.out_dir)

    # Ensure the directory is empty
    if os.path.exists(dest_path) and os.path.isdir(dest_path):
        if os.listdir(dest_path):
            eprint(f"{dest_path} is not empty, aborting to avoid overwriting it.")
            exit(1)
    else: 
        eprint(f"{dest_path} is not a valid path.")
        exit(1)

    # Check if the docker image is in the registry
    try:
        subprocess.run(["docker", "image", "inspect", args.docker_image],
                       stdout=subprocess.DEVNULL, 
                       stderr=subprocess.DEVNULL,
                       check=True)
    except subprocess.CalledProcessError:
        eprint(f"Docker image {args.docker_image} is not present in the lcal registry, please add it")

    # Pull module example and init.d from docker image
    uid = os.getuid()
    gid = os.getgid()
    run_command(["docker",
                 "run",
                 "--mount", f"type=bind,source={dest_path},target=/host",
                 "-u", f"{uid}:{gid}",
                 "--rm",
                 "-it",
                 args.docker_image,
                 "cp", "-r", "/init/.", "/host"],
            cwd=dest_path)

def riveter_run(args):
    # Run riveter.py inside the docker container with the provided yaml (mount folder containing the yaml file)
    yaml_path = os.path.abspath(args.yaml)
    yaml_dir = os.path.dirname(yaml_path)
    
    docker_image = yaml.safe_load(open(yaml_path))["base"]
    
    run_command(["docker",
                 "run",
                 "--mount", f"type=bind,source={yaml_dir},target=/riveter",
                 "-w", "/riveter",
                 "--rm",
                 "-it",
                 docker_image,
                 "python3", "/px4/riveter.py", os.path.basename(args.yaml)],
            cwd=yaml_dir)
    

class RiveterCommand(CliCommand):
    @staticmethod
    def help():
        return 'Riveter is the tool to assemble and build customized PX4 distributions'

    def __init__(self, config):
        self._config = config

    def setup_parser(self, parser):
        riveter_parser = parser.add_subparsers(title="Riveter commands", metavar='<command>', dest="riveter_command")
        self.parser_help = parser.print_help

        # Init command
        init_parser = riveter_parser.add_parser('init', help="initialize a Riveter template project in the current direcotry")
        init_parser.add_argument("docker_image", type=str, help="Docker image contating base PX4")
        init_parser.add_argument('--out-dir', '-o', default='.', help='target output directory (default is \'.\')',
            type=lambda x: arg_dir_path_type(parser, x))

        # Run command
        run_parser = riveter_parser.add_parser('run', help="run Riveter given a yaml config file")
        run_parser.add_argument("yaml", help="Path to the yaml file containing Riveter settings",
            type=lambda x: arg_file_path_type(parser, x))

    def run(self, args):
        if args.riveter_command is None:
            self.parser_help()
            exit(1)
        elif args.riveter_command == 'init':
            riveter_init(args)
        elif args.riveter_command == 'run':
            assert(os.path.isfile(args.yaml))
            riveter_run(args)

    def handle_exception(self, exception):
        raise exception