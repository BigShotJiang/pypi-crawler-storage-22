# Auth_capture_proxy

[![Version status](https://img.shields.io/pypi/status/authcaptureproxy)](https://pypi.org/project/authcaptureproxy)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Python version compatibility](https://img.shields.io/pypi/pyversions/authcaptureproxy)](https://pypi.org/project/authcaptureproxy)
[![Version on Github](https://img.shields.io/github/v/release/alandtse/auth_capture_proxy?include_prereleases&label=GitHub)](https://github.com/alandtse/auth_capture_proxy/releases)
[![Version on PyPi](https://img.shields.io/pypi/v/authcaptureproxy)](https://pypi.org/project/authcaptureproxy)
![PyPI - Downloads](https://img.shields.io/pypi/dd/authcaptureproxy)
![PyPI - Downloads](https://img.shields.io/pypi/dw/authcaptureproxy)
![PyPI - Downloads](https://img.shields.io/pypi/dm/authcaptureproxy)
[![Documentation Status](https://readthedocs.org/projects/auth-capture-proxy/badge/?version=latest)](https://auth-capture-proxy.readthedocs.io/en/latest/?badge=latest)
[![Build (Github Actions)](https://img.shields.io/github/workflow/status/alandtse/auth_capture_proxy/Build%20&%20test?label=Build%20&%20test)](https://github.com/alandtse/auth_capture_proxy/actions)
[![Test coverage (coveralls)](https://coveralls.io/repos/github/alandtse/auth_capture_proxy/badge.svg?branch=main&service=github)](https://coveralls.io/github/alandtse/auth_capture_proxy?branch=main)

A Python project to create a proxy to capture authentication information from a webpage. This is useful to capture oauth login details without access to a third-party oauth.

## Install

```bash
pip install authcaptureproxy
```

## Using

To see basic usage look at the [proxy-example](authcaptureproxy/cli.py) that logs into Amazon.com and will print out the detected email and password.

```bash
python authcaptureproxy/cli.py proxy-example
```

[See the docs 📚](https://auth-capture-proxy.readthedocs.io/en/latest/) for more info.

## License

Licensed under the terms of the [Apache License 2.0](https://spdx.org/licenses/Apache-2.0.html).

## Contributing

[New issues](https://github.com/alandtse/auth_capture_proxy/issues) and pull requests are welcome.
Please refer to the [contributing guide](https://github.com/alandtse/auth_capture_proxy/blob/main/CONTRIBUTING.md)
and [security policy](https://github.com/alandtse/auth_capture_proxy/blob/main/SECURITY.md).

Generated with [Tyrannosaurus](https://github.com/dmyersturnbull/tyrannosaurus).
