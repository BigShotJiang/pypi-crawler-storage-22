# Auto Code Fixer

Auto Code Fixer is a CLI tool that **detects runtime failures** and automatically fixes Python code using OpenAI.

It is designed for real projects where an entry script imports multiple local modules. The tool runs your code in an **isolated sandbox + venv**, installs missing external dependencies, and applies fixes only after the code executes successfully.

---

## Installation

```bash
pip install auto-code-fixer
```

---

## Quick start

```bash
auto-code-fixer path/to/main.py --project-root . --ask
```

If you want it to overwrite without asking:

```bash
auto-code-fixer path/to/main.py --project-root . --no-ask
```

---

## What it fixes (core behavior)

### ✅ Local/internal imports are treated as project code
If your entry file imports something like:

```py
from mylib import add
```

…and `mylib.py` exists inside the project, Auto Code Fixer will:
- copy `main.py` + `mylib.py` into a sandbox
- execute inside the sandbox
- if the traceback points to `mylib.py`, it will fix `mylib.py`
- then apply the fix back to your repo (with backups)

### ✅ External imports are auto-installed
If execution fails with:

```
ModuleNotFoundError: No module named 'requests'
```

…it will run:

```bash
pip install requests
```

…but only inside the sandbox venv (so your system env isn’t polluted).

---

## Safety

### Backups
Before overwriting any file, it creates a backup:
- `file.py.bak` (or `.bak1`, `.bak2`, ...)

### Dry run
```bash
auto-code-fixer path/to/main.py --project-root . --dry-run
```

---

## Advanced options

### Run a custom command (pytest, etc.)
Instead of `python main.py`, run tests:

```bash
auto-code-fixer . --project-root . --run "pytest -q" --no-ask
```

### Model selection
```bash
export AUTO_CODE_FIXER_MODEL=gpt-4.1-mini
# or
auto-code-fixer main.py --model gpt-4.1-mini
```

### Max retries / timeout
```bash
auto-code-fixer main.py --max-retries 8 --timeout 30
```

### Optional AI planning (which file to edit)
```bash
auto-code-fixer main.py --ai-plan
```
This enables a helper that can suggest which local file to edit. It is best-effort.

---

## Environment variables

- `OPENAI_API_KEY` (required unless you always pass `--api-key`)
- `AUTO_CODE_FIXER_MODEL` (default model)
- `AUTO_CODE_FIXER_ASK=true|false`
- `AUTO_CODE_FIXER_VERBOSE=true|false`

---

## Notes

- This tool edits code. Use it on a git repo so you can review diffs.
- For maximum safety, run with `--ask` and/or `--dry-run`.
