import argparse
import os
import shutil
import tempfile
import time
from decouple import config

from auto_code_fixer.runner import run_code
from auto_code_fixer.fixer import fix_code_with_gpt
from auto_code_fixer.installer import check_and_install_missing_lib
from auto_code_fixer.utils import (
    discover_all_files,
    is_in_project,
    log,
    set_verbose,
)
from auto_code_fixer import __version__

DEFAULT_MAX_RETRIES = 8  # can be overridden via CLI


def fix_file(file_path, project_root, api_key, ask, verbose, *, dry_run: bool, model: str | None, timeout_s: int, max_retries: int, run_cmd: str | None) -> bool:
    log(f"Processing entry file: {file_path}")

    project_root = os.path.abspath(project_root)
    file_path = os.path.abspath(file_path)

    # Build sandbox with entry + imported local files
    from auto_code_fixer.sandbox import make_sandbox
    sandbox_root, sandbox_entry = make_sandbox(entry_file=file_path, project_root=project_root)

    # Always delete temp sandbox (best-effort). Also register atexit cleanup in case of crashes.
    import atexit

    def cleanup_sandbox() -> None:
        try:
            shutil.rmtree(sandbox_root)
        except FileNotFoundError:
            return
        except Exception as e:
            log(f"WARN: failed to delete sandbox dir {sandbox_root}: {e}")

    atexit.register(cleanup_sandbox)

    # Create isolated venv in sandbox
    from auto_code_fixer.venv_manager import create_venv
    from auto_code_fixer.patcher import backup_file

    venv_python = create_venv(sandbox_root)

    changed_sandbox_files: set[str] = set()

    for attempt in range(max_retries):
        log(f"Run attempt #{attempt + 1}")

        # Ensure local modules resolve inside sandbox
        if run_cmd:
            from auto_code_fixer.command_runner import run_command

            retcode, stdout, stderr = run_command(
                run_cmd,
                timeout_s=timeout_s,
                python_exe=venv_python,
                cwd=sandbox_root,
                extra_env={"PYTHONPATH": sandbox_root},
            )
        else:
            retcode, stdout, stderr = run_code(
                sandbox_entry,
                timeout_s=timeout_s,
                python_exe=venv_python,
                cwd=sandbox_root,
                extra_env={"PYTHONPATH": sandbox_root},
            )

        if verbose:
            if stdout:
                log(f"STDOUT:\n{stdout}", "DEBUG")
            if stderr:
                log(f"STDERR:\n{stderr}", "DEBUG")

        if retcode == 0:
            log("Script executed successfully ✅")

            # Apply sandbox changes back to project (only if we actually changed something)
            if attempt > 0 and is_in_project(file_path, project_root) and changed_sandbox_files:
                rel_changes = [os.path.relpath(p, sandbox_root) for p in sorted(changed_sandbox_files)]

                if ask:
                    confirm = input(
                        "Overwrite original files with fixed versions?\n"
                        + "\n".join(f"- {c}" for c in rel_changes)
                        + "\n(y/n): "
                    ).strip().lower()

                    if confirm != "y":
                        log("User declined overwrite", "WARN")
                        cleanup_sandbox()
                        return False

                if dry_run:
                    log("DRY RUN: would apply fixes:\n" + "\n".join(rel_changes), "WARN")
                else:
                    sr = os.path.realpath(os.path.abspath(sandbox_root))
                    pr = os.path.realpath(os.path.abspath(project_root))

                    for p in sorted(changed_sandbox_files):
                        p_real = os.path.realpath(os.path.abspath(p))

                        # compute rel using real paths to avoid macOS /private path weirdness
                        rel = os.path.relpath(p_real, sr)

                        # Safety: never allow paths escaping the sandbox
                        if rel.startswith(".." + os.sep) or rel == "..":
                            log(f"Skipping suspicious path outside sandbox: {p}", "WARN")
                            continue

                        dst = os.path.join(pr, rel)
                        dst_real = os.path.realpath(os.path.abspath(dst))

                        # Safety: never write outside the project root
                        if not (dst_real.startswith(pr + os.sep) or dst_real == pr):
                            log(f"Skipping suspicious destination outside project: {dst}", "WARN")
                            continue

                        # Avoid shutil.SameFileError
                        try:
                            if os.path.exists(dst_real) and os.path.samefile(p_real, dst_real):
                                log(f"Skip copy (same file): {dst_real}", "DEBUG")
                                continue
                        except Exception:
                            pass

                        if os.path.exists(dst_real):
                            bak = backup_file(dst_real)
                            log(f"Backup created: {bak}", "DEBUG")

                        os.makedirs(os.path.dirname(dst_real), exist_ok=True)
                        shutil.copy(p_real, dst_real)
                        log(f"File updated: {dst_real}")

            cleanup_sandbox()
            log(f"Fix completed in {attempt + 1} attempt(s) 🎉")
            return True

        log("Error detected ❌", "ERROR")
        print(stderr)

        if check_and_install_missing_lib(stderr, python_exe=venv_python, project_root=sandbox_root):
            log("Missing dependency installed (venv), retrying…")
            time.sleep(1)
            continue

        # Pick the most relevant local file from the traceback (entry or imported file)
        from auto_code_fixer.traceback_utils import pick_relevant_file

        target_file = pick_relevant_file(stderr, sandbox_root=sandbox_root) or sandbox_entry

        # Safety: ensure target_file is within sandbox
        try:
            sr = os.path.realpath(os.path.abspath(sandbox_root))
            tf = os.path.realpath(os.path.abspath(target_file))
            if not (tf.startswith(sr + os.sep) or tf == sr):
                target_file = sandbox_entry
        except Exception:
            target_file = sandbox_entry

        # Optional AI fix plan can override file selection
        try:
            from auto_code_fixer.plan import ask_ai_for_fix_plan

            plan = ask_ai_for_fix_plan(
                sandbox_root=sandbox_root,
                stderr=stderr,
                api_key=api_key,
                model=model,
            )
            if plan and plan.target_files:
                # Use the first suggested file that exists
                for rel in plan.target_files:
                    cand = os.path.abspath(os.path.join(sandbox_root, rel))
                    if cand.startswith(os.path.abspath(sandbox_root)) and os.path.exists(cand):
                        target_file = cand
                        break
        except Exception:
            pass

        log(f"Sending {os.path.relpath(target_file, sandbox_root)} + error to GPT 🧠", "DEBUG")

        fixed_code = fix_code_with_gpt(
            original_code=open(target_file, encoding="utf-8").read(),
            error_log=stderr,
            api_key=api_key,
            model=model,
        )

        if fixed_code.strip() == open(target_file, encoding="utf-8").read().strip():
            log("GPT returned no changes. Stopping.", "WARN")
            break

        with open(target_file, "w", encoding="utf-8") as f:
            f.write(fixed_code)

        changed_sandbox_files.add(os.path.abspath(target_file))

        log("Code updated by GPT ✏️")
        time.sleep(1)

    log("Failed to auto-fix file after max retries ❌", "ERROR")
    cleanup_sandbox()
    return False


def main():
    parser = argparse.ArgumentParser(
        description="Auto-fix Python code using OpenAI (advanced sandbox + retry loop)"
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    parser.add_argument(
        "entry_file",
        nargs="?",
        help="Path to the main Python file",
    )

    parser.add_argument("--project-root", default=".")
    parser.add_argument("--api-key")
    parser.add_argument("--model", default=None, help="OpenAI model (default: AUTO_CODE_FIXER_MODEL or gpt-4.1-mini)")
    parser.add_argument("--timeout", type=int, default=30, help="Execution timeout seconds (default: 30)")
    parser.add_argument("--dry-run", action="store_true", help="Do not overwrite files; just report what would change")
    parser.add_argument("--max-retries", type=int, default=DEFAULT_MAX_RETRIES, help="Max fix attempts (default: 8)")
    parser.add_argument(
        "--run",
        default=None,
        help=(
            "Optional command to run instead of `python entry.py`. Examples: 'pytest -q', 'python -m module'. "
            "If set, it runs inside the sandbox venv."
        ),
    )
    parser.add_argument(
        "--ai-plan",
        action="store_true",
        help="Optional: use AI to suggest which file to edit (AUTO_CODE_FIXER_AI_PLAN=1)",
    )

    # ✅ Proper boolean flags
    ask_group = parser.add_mutually_exclusive_group()
    ask_group.add_argument(
        "--ask",
        action="store_true",
        help="Ask before overwriting files",
    )
    ask_group.add_argument(
        "--no-ask",
        action="store_true",
        help="Do not ask before overwriting files",
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose/debug output",
    )

    args = parser.parse_args()

    if not args.entry_file:
        parser.error("the following arguments are required: entry_file")

    # ENV defaults
    env_ask = config("AUTO_CODE_FIXER_ASK", default=False, cast=bool)
    env_verbose = config("AUTO_CODE_FIXER_VERBOSE", default=False, cast=bool)

    # Final ask resolution (CLI overrides ENV)
    if args.ask:
        ask = True
    elif args.no_ask:
        ask = False
    else:
        ask = env_ask

    verbose = args.verbose or env_verbose
    set_verbose(verbose)

    # Optional: enable AI planning helper
    if args.ai_plan:
        os.environ["AUTO_CODE_FIXER_AI_PLAN"] = "1"

    ok = fix_file(
        args.entry_file,
        args.project_root,
        args.api_key,
        ask,
        verbose,
        dry_run=args.dry_run,
        model=args.model,
        timeout_s=args.timeout,
        max_retries=args.max_retries,
        run_cmd=args.run,
    )

    raise SystemExit(0 if ok else 2)


if __name__ == "__main__":
    main()
