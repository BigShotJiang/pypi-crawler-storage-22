import json
import os
from decouple import config
from openai import OpenAI


def get_openai_client(api_key: str | None = None) -> OpenAI:
    key = api_key or os.getenv("OPENAI_API_KEY") or config("OPENAI_API_KEY", default=None)
    if not key:
        raise RuntimeError(
            "OpenAI API key not found. Set OPENAI_API_KEY env var or .env file or pass --api-key"
        )
    return OpenAI(api_key=key)


def _strip_code_fences(text: str) -> str:
    text = (text or "").strip()
    if text.startswith("```"):
        text = "\n".join(text.split("\n")[1:])
    if text.endswith("```"):
        text = "\n".join(text.split("\n")[:-1])
    return text.strip()


def fix_code_with_gpt(
    *,
    original_code: str,
    error_log: str,
    api_key: str | None = None,
    model: str | None = None,
) -> str:
    """Fix code using OpenAI. Returns full corrected code.

    Model can be set via:
      - --model
      - AUTO_CODE_FIXER_MODEL env
      - default fallback
    """

    client = get_openai_client(api_key)
    model = model or os.getenv("AUTO_CODE_FIXER_MODEL") or "gpt-4.1-mini"

    instructions = {
        "task": "Fix Python code to run without errors.",
        "requirements": [
            "Preserve existing behavior unless required to fix the crash.",
            "Do not remove functionality.",
            "Return ONLY the full corrected Python source code (no markdown).",
        ],
    }

    prompt = (
        "You are a senior Python engineer. Fix the following Python code so it runs without errors.\n\n"
        "INSTRUCTIONS (JSON):\n"
        + json.dumps(instructions)
        + "\n\nCODE:\n"
        + original_code
        + "\n\nERROR LOG:\n"
        + error_log
    )

    # Use Responses API (openai>=1) for forward compatibility
    resp = client.responses.create(
        model=model,
        input=[
            {"role": "system", "content": "You fix broken Python code."},
            {"role": "user", "content": prompt},
        ],
        temperature=0.2,
        max_output_tokens=2000,
    )

    text = ""
    for item in resp.output or []:
        for c in item.content or []:
            if getattr(c, "type", None) in ("output_text", "text"):
                text += getattr(c, "text", "") or ""

    return _strip_code_fences(text)
