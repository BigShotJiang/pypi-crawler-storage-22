import os
from dataclasses import dataclass


@dataclass
class FileEdit:
    path: str
    new_content: str


def safe_write(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def safe_read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def backup_file(path: str) -> str:
    bak = path + ".bak"
    # Avoid overwriting an existing bak
    i = 1
    while os.path.exists(bak):
        bak = f"{path}.bak{i}"
        i += 1
    with open(path, "rb") as src, open(bak, "wb") as dst:
        dst.write(src.read())
    return bak
