import difflib
from dataclasses import dataclass


@dataclass(frozen=True)
class PlannedChange:
    abs_path: str
    rel_path: str
    old_content: str
    new_content: str


class UserAbort(Exception):
    pass


def unified_diff_text(rel_path: str, old: str, new: str) -> str:
    return "".join(
        difflib.unified_diff(
            (old or "").splitlines(keepends=True),
            (new or "").splitlines(keepends=True),
            fromfile=rel_path + " (before)",
            tofile=rel_path + " (after)",
        )
    )


def guard_planned_changes(
    planned: list[PlannedChange],
    *,
    max_file_bytes: int,
    max_total_bytes: int,
    max_diff_lines: int,
) -> None:
    """Safety guards against huge edits.

    Raises ValueError when limits are exceeded.
    """

    if max_file_bytes <= 0 or max_total_bytes <= 0 or max_diff_lines <= 0:
        raise ValueError("Guard limits must be positive")

    total = 0

    for ch in planned:
        b = len((ch.new_content or "").encode("utf-8"))
        total += b
        if b > max_file_bytes:
            raise ValueError(
                f"Proposed content for {ch.rel_path} is {b} bytes, exceeding --max-file-bytes={max_file_bytes}"
            )

        diff = unified_diff_text(ch.rel_path, ch.old_content, ch.new_content)
        diff_lines = len(diff.splitlines())
        if diff_lines > max_diff_lines:
            raise ValueError(
                f"Diff for {ch.rel_path} is {diff_lines} lines, exceeding --max-diff-lines={max_diff_lines}"
            )

    if total > max_total_bytes:
        raise ValueError(
            f"Total proposed content is {total} bytes, exceeding --max-total-bytes={max_total_bytes}"
        )


def prompt_approve_file_by_file(
    planned: list[PlannedChange],
    *,
    input_fn=input,
    print_fn=print,
) -> list[PlannedChange]:
    """Interactive approval per file.

    Commands:
      y = apply this change
      n = skip this change
      a = apply this and all remaining
      q = abort
    """

    if not planned:
        return []

    out: list[PlannedChange] = []
    apply_all = False

    for ch in planned:
        diff = unified_diff_text(ch.rel_path, ch.old_content, ch.new_content)
        print_fn("\nPROPOSED CHANGE:")
        print_fn(diff)

        if apply_all:
            out.append(ch)
            continue

        ans = (
            input_fn(f"Apply change for {ch.rel_path}? (y/n/a/q): ")
            .strip()
            .lower()
        )
        if ans == "y":
            out.append(ch)
        elif ans == "n":
            continue
        elif ans == "a":
            out.append(ch)
            apply_all = True
        elif ans == "q":
            raise UserAbort("User aborted approvals")
        else:
            # default: be safe
            continue

    return out
