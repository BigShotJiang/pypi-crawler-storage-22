import argparse
import os
import shutil
import tempfile
import time
from decouple import config

from auto_code_fixer.runner import run_code
from auto_code_fixer.fixer import fix_code_with_gpt
from auto_code_fixer.installer import check_and_install_missing_lib
from auto_code_fixer.utils import (
    discover_all_files,
    is_in_project,
    log,
    set_verbose,
)
from auto_code_fixer import __version__

DEFAULT_MAX_RETRIES = 8  # can be overridden via CLI


def fix_file(
    file_path,
    project_root,
    api_key,
    ask,
    verbose,
    *,
    dry_run: bool,
    model: str | None,
    timeout_s: int,
    max_retries: int,
    run_cmd: str | None,
    patch_protocol: bool,
    max_files_changed: int,
    context_files: int,
    approve: bool,
    max_diff_lines: int,
    max_file_bytes: int,
    max_total_bytes: int,
    post_apply_check: bool,
    fmt: str | None,
    lint: str | None,
    lint_fix: bool,
) -> bool:
    log(f"Processing entry file: {file_path}")

    project_root = os.path.abspath(project_root)
    file_path = os.path.abspath(file_path)

    # Build sandbox with entry + imported local files
    from auto_code_fixer.sandbox import make_sandbox
    sandbox_root, sandbox_entry = make_sandbox(entry_file=file_path, project_root=project_root)

    # Always delete temp sandbox (best-effort). Also register atexit cleanup in case of crashes.
    import atexit

    def cleanup_sandbox() -> None:
        try:
            shutil.rmtree(sandbox_root)
        except FileNotFoundError:
            return
        except Exception as e:
            log(f"WARN: failed to delete sandbox dir {sandbox_root}: {e}")

    atexit.register(cleanup_sandbox)

    # Create isolated venv in sandbox
    from auto_code_fixer.venv_manager import create_venv
    from auto_code_fixer.patcher import backup_file

    venv_python = create_venv(sandbox_root)

    def _run_optional_formatters_and_linters() -> None:
        # Best-effort formatting/linting (only if tools are installed in the sandbox venv).
        from auto_code_fixer.command_runner import run_command

        if fmt == "black":
            rc, out, err = run_command(
                "python -m black .",
                timeout_s=max(timeout_s, 60),
                python_exe=venv_python,
                cwd=sandbox_root,
                extra_env={"PYTHONPATH": sandbox_root},
            )
            if rc == 0:
                log("Formatted with black", "DEBUG")
            else:
                # If black isn't installed, ignore.
                if "No module named" in (err or "") and "black" in (err or ""):
                    log("black not installed in sandbox venv; skipping format", "DEBUG")
                else:
                    log(f"black failed (rc={rc}): {err}", "DEBUG")

        if lint == "ruff":
            cmd = "python -m ruff check ."
            if lint_fix:
                cmd += " --fix"
            rc, out, err = run_command(
                cmd,
                timeout_s=max(timeout_s, 60),
                python_exe=venv_python,
                cwd=sandbox_root,
                extra_env={"PYTHONPATH": sandbox_root},
            )
            if rc == 0:
                log("ruff check passed", "DEBUG")
            else:
                if "No module named" in (err or "") and "ruff" in (err or ""):
                    log("ruff not installed in sandbox venv; skipping lint", "DEBUG")
                else:
                    log(f"ruff reported issues (rc={rc}): {err}", "DEBUG")

    changed_sandbox_files: set[str] = set()

    for attempt in range(max_retries):
        log(f"Run attempt #{attempt + 1}")

        # Ensure local modules resolve inside sandbox
        if run_cmd:
            from auto_code_fixer.command_runner import run_command

            retcode, stdout, stderr = run_command(
                run_cmd,
                timeout_s=timeout_s,
                python_exe=venv_python,
                cwd=sandbox_root,
                extra_env={"PYTHONPATH": sandbox_root},
            )
        else:
            retcode, stdout, stderr = run_code(
                sandbox_entry,
                timeout_s=timeout_s,
                python_exe=venv_python,
                cwd=sandbox_root,
                extra_env={"PYTHONPATH": sandbox_root},
            )

        if verbose:
            if stdout:
                log(f"STDOUT:\n{stdout}", "DEBUG")
            if stderr:
                log(f"STDERR:\n{stderr}", "DEBUG")

        if retcode == 0:
            log("Script executed successfully ✅")

            # Apply sandbox changes back to project (only if we actually changed something)
            if attempt > 0 and is_in_project(file_path, project_root) and changed_sandbox_files:
                rel_changes = [os.path.relpath(p, sandbox_root) for p in sorted(changed_sandbox_files)]

                if ask:
                    confirm = input(
                        "Overwrite original files with fixed versions?\n"
                        + "\n".join(f"- {c}" for c in rel_changes)
                        + "\n(y/n): "
                    ).strip().lower()

                    if confirm != "y":
                        log("User declined overwrite", "WARN")
                        cleanup_sandbox()
                        return False

                if dry_run:
                    log("DRY RUN: would apply fixes:\n" + "\n".join(rel_changes), "WARN")
                else:
                    sr = os.path.realpath(os.path.abspath(sandbox_root))
                    pr = os.path.realpath(os.path.abspath(project_root))

                    backups: dict[str, str] = {}

                    for p in sorted(changed_sandbox_files):
                        p_real = os.path.realpath(os.path.abspath(p))

                        # compute rel using real paths to avoid macOS /private path weirdness
                        rel = os.path.relpath(p_real, sr)

                        # Safety: never allow paths escaping the sandbox
                        if rel.startswith(".." + os.sep) or rel == "..":
                            log(f"Skipping suspicious path outside sandbox: {p}", "WARN")
                            continue

                        dst = os.path.join(pr, rel)
                        dst_real = os.path.realpath(os.path.abspath(dst))

                        # Safety: never write outside the project root
                        if not (dst_real.startswith(pr + os.sep) or dst_real == pr):
                            log(f"Skipping suspicious destination outside project: {dst}", "WARN")
                            continue

                        # Avoid shutil.SameFileError
                        try:
                            if os.path.exists(dst_real) and os.path.samefile(p_real, dst_real):
                                log(f"Skip copy (same file): {dst_real}", "DEBUG")
                                continue
                        except Exception:
                            pass

                        if os.path.exists(dst_real):
                            bak = backup_file(dst_real)
                            backups[dst_real] = bak
                            log(f"Backup created: {bak}", "DEBUG")

                        os.makedirs(os.path.dirname(dst_real), exist_ok=True)
                        shutil.copy(p_real, dst_real)
                        log(f"File updated: {dst_real}")

                    # Optional post-apply verification: run the same command against the real project files,
                    # using the sandbox venv for dependencies.
                    if post_apply_check and run_cmd and changed_sandbox_files:
                        from auto_code_fixer.command_runner import run_command

                        rc2, out2, err2 = run_command(
                            run_cmd,
                            timeout_s=timeout_s,
                            python_exe=venv_python,
                            cwd=project_root,
                            extra_env={"PYTHONPATH": project_root},
                        )
                        if verbose:
                            if out2:
                                log(f"POST-APPLY STDOUT:\n{out2}", "DEBUG")
                            if err2:
                                log(f"POST-APPLY STDERR:\n{err2}", "DEBUG")

                        if rc2 != 0:
                            log(
                                "Post-apply command failed; restoring backups (best-effort).",
                                "ERROR",
                            )
                            for dst_real, bak in backups.items():
                                try:
                                    shutil.copy(bak, dst_real)
                                except Exception as e:
                                    log(f"WARN: failed to restore {dst_real} from {bak}: {e}")
                            cleanup_sandbox()
                            return False

            cleanup_sandbox()
            log(f"Fix completed in {attempt + 1} attempt(s) 🎉")
            return True

        log("Error detected ❌", "ERROR")
        print(stderr)

        if check_and_install_missing_lib(stderr, python_exe=venv_python, project_root=sandbox_root):
            log("Missing dependency installed (venv), retrying…")
            time.sleep(1)
            continue

        # Pick the most relevant local file from the traceback (entry or imported file)
        from auto_code_fixer.traceback_utils import pick_relevant_file

        target_file = pick_relevant_file(stderr, sandbox_root=sandbox_root) or sandbox_entry

        # Safety: ensure target_file is within sandbox
        try:
            sr = os.path.realpath(os.path.abspath(sandbox_root))
            tf = os.path.realpath(os.path.abspath(target_file))
            if not (tf.startswith(sr + os.sep) or tf == sr):
                target_file = sandbox_entry
        except Exception:
            target_file = sandbox_entry

        # Optional AI fix plan can override file selection
        try:
            from auto_code_fixer.plan import ask_ai_for_fix_plan

            plan = ask_ai_for_fix_plan(
                sandbox_root=sandbox_root,
                stderr=stderr,
                api_key=api_key,
                model=model,
            )
            if plan and plan.target_files:
                # Use the first suggested file that exists
                for rel in plan.target_files:
                    cand = os.path.abspath(os.path.join(sandbox_root, rel))
                    if cand.startswith(os.path.abspath(sandbox_root)) and os.path.exists(cand):
                        target_file = cand
                        break
        except Exception:
            pass

        log(f"Sending {os.path.relpath(target_file, sandbox_root)} + error to GPT 🧠", "DEBUG")

        applied_any = False

        if patch_protocol:
            try:
                import difflib

                from auto_code_fixer.fixer import fix_code_with_gpt_patch_protocol
                from auto_code_fixer.patch_protocol import (
                    parse_patch_protocol_response,
                    validate_and_resolve_patch_files,
                )
                from auto_code_fixer.patcher import safe_read, atomic_write_verified_sha256
                from auto_code_fixer.utils import find_imports

                hint_paths = [os.path.relpath(target_file, sandbox_root)]

                # Add a few related local files as read-only context to reduce back-and-forth.
                ctx_pairs: list[tuple[str, str]] = []
                if context_files and context_files > 0:
                    rels: list[str] = []
                    for abs_p in find_imports(target_file, sandbox_root):
                        try:
                            rels.append(os.path.relpath(abs_p, sandbox_root))
                        except Exception:
                            continue
                    # drop duplicates and the target itself
                    rels = [r for r in rels if r not in hint_paths]
                    for rel in rels[:context_files]:
                        abs_p = os.path.join(sandbox_root, rel)
                        if os.path.exists(abs_p):
                            try:
                                ctx_pairs.append((rel, safe_read(abs_p)))
                            except Exception:
                                pass

                raw = fix_code_with_gpt_patch_protocol(
                    sandbox_root=sandbox_root,
                    error_log=stderr,
                    api_key=api_key,
                    model=model,
                    hint_paths=hint_paths,
                    context_files=ctx_pairs,
                )

                patch_files = parse_patch_protocol_response(raw)

                if len(patch_files) > max_files_changed:
                    raise ValueError(
                        f"Patch wants to change {len(patch_files)} files, exceeding --max-files-changed={max_files_changed}"
                    )

                resolved = validate_and_resolve_patch_files(patch_files, sandbox_root=sandbox_root)

                # Prepare diffs / approvals and apply atomically.
                sha_by_rel = {pf.path: pf.sha256 for pf in patch_files}

                from auto_code_fixer.approval import (
                    PlannedChange,
                    UserAbort,
                    guard_planned_changes,
                    prompt_approve_file_by_file,
                )

                planned: list[PlannedChange] = []
                for abs_path, new_content in resolved:
                    old = ""
                    if os.path.exists(abs_path):
                        old = safe_read(abs_path)
                    if new_content.strip() == (old or "").strip():
                        continue
                    rel = os.path.relpath(abs_path, sandbox_root)
                    planned.append(
                        PlannedChange(
                            abs_path=abs_path,
                            rel_path=rel,
                            old_content=old,
                            new_content=new_content,
                        )
                    )

                if planned:
                    if len(planned) > max_files_changed:
                        raise ValueError(
                            f"Patch would change {len(planned)} files, exceeding --max-files-changed={max_files_changed}"
                        )

                    guard_planned_changes(
                        planned,
                        max_file_bytes=max_file_bytes,
                        max_total_bytes=max_total_bytes,
                        max_diff_lines=max_diff_lines,
                    )

                    if approve:
                        try:
                            planned = prompt_approve_file_by_file(planned)
                        except UserAbort:
                            log("User aborted patch application", "WARN")
                            planned = []

                for ch in planned:
                    expected_sha = sha_by_rel.get(ch.rel_path)
                    if not expected_sha:
                        # Shouldn't happen; keep safe.
                        raise ValueError(f"Missing sha256 for {ch.rel_path} in patch protocol payload")

                    atomic_write_verified_sha256(ch.abs_path, ch.new_content, expected_sha)
                    changed_sandbox_files.add(os.path.abspath(ch.abs_path))
                    applied_any = True

            except Exception as e:
                log(f"Patch protocol failed ({e}); falling back to full-text mode", "WARN")

        if not applied_any:
            fixed_code = fix_code_with_gpt(
                original_code=open(target_file, encoding="utf-8").read(),
                error_log=stderr,
                api_key=api_key,
                model=model,
            )

            if fixed_code.strip() == open(target_file, encoding="utf-8").read().strip():
                log("GPT returned no changes. Stopping.", "WARN")
                break

            from auto_code_fixer.approval import (
                PlannedChange,
                UserAbort,
                guard_planned_changes,
                prompt_approve_file_by_file,
            )

            old = open(target_file, encoding="utf-8").read()
            rel = os.path.relpath(target_file, sandbox_root)

            planned = [
                PlannedChange(
                    abs_path=target_file,
                    rel_path=rel,
                    old_content=old,
                    new_content=fixed_code,
                )
            ]

            guard_planned_changes(
                planned,
                max_file_bytes=max_file_bytes,
                max_total_bytes=max_total_bytes,
                max_diff_lines=max_diff_lines,
            )

            if approve:
                try:
                    planned = prompt_approve_file_by_file(planned)
                except UserAbort:
                    log("User declined patch application", "WARN")
                    cleanup_sandbox()
                    return False

            if not planned:
                log("No legacy changes approved", "WARN")
                cleanup_sandbox()
                return False

            from auto_code_fixer.patcher import safe_write

            safe_write(target_file, planned[0].new_content)
            changed_sandbox_files.add(os.path.abspath(target_file))
            applied_any = True

        if applied_any:
            _run_optional_formatters_and_linters()
            log("Code updated by GPT ✏️")
            time.sleep(1)

    log("Failed to auto-fix file after max retries ❌", "ERROR")
    cleanup_sandbox()
    return False


def main():
    parser = argparse.ArgumentParser(
        description="Auto-fix Python code using OpenAI (advanced sandbox + retry loop)"
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    parser.add_argument(
        "entry_file",
        nargs="?",
        help="Path to the main Python file",
    )

    parser.add_argument("--project-root", default=".")
    parser.add_argument("--api-key")
    parser.add_argument("--model", default=None, help="OpenAI model (default: AUTO_CODE_FIXER_MODEL or gpt-4.1-mini)")
    parser.add_argument("--timeout", type=int, default=30, help="Execution timeout seconds (default: 30)")
    parser.add_argument("--dry-run", action="store_true", help="Do not overwrite files; just report what would change")
    parser.add_argument("--max-retries", type=int, default=DEFAULT_MAX_RETRIES, help="Max fix attempts (default: 8)")
    parser.add_argument(
        "--run",
        default=None,
        help=(
            "Optional command to run instead of `python entry.py`. Examples: 'pytest -q', 'python -m module'. "
            "If set, it runs inside the sandbox venv."
        ),
    )
    parser.add_argument(
        "--ai-plan",
        action="store_true",
        help="Optional: use AI to suggest which file to edit (AUTO_CODE_FIXER_AI_PLAN=1)",
    )

    parser.add_argument(
        "--legacy-mode",
        action="store_true",
        help=(
            "Disable the default JSON patch protocol and use legacy full-text edit mode only. "
            "(Not recommended; patch protocol is safer and supports multi-file fixes.)"
        ),
    )

    parser.add_argument(
        "--max-files-changed",
        type=int,
        default=20,
        help="Safety guard: maximum number of files the model may change per attempt (default: 20)",
    )

    parser.add_argument(
        "--context-files",
        type=int,
        default=3,
        help=(
            "Include up to N related local files (imports) as read-only context in the LLM prompt "
            "when using patch protocol (default: 3)"
        ),
    )

    parser.add_argument(
        "--approve",
        action="store_true",
        help=(
            "Show diffs for proposed changes and ask for approval before applying them in the sandbox. "
            "In patch-protocol mode, approvals are file-by-file."
        ),
    )

    parser.add_argument(
        "--max-diff-lines",
        type=int,
        default=4000,
        help="Safety guard: maximum unified-diff lines to display/apply per file (default: 4000)",
    )
    parser.add_argument(
        "--max-file-bytes",
        type=int,
        default=200_000,
        help="Safety guard: maximum size (bytes) of proposed new content per file (default: 200000)",
    )
    parser.add_argument(
        "--max-total-bytes",
        type=int,
        default=1_000_000,
        help="Safety guard: maximum total bytes of proposed new content across all files (default: 1000000)",
    )

    post_apply_group = parser.add_mutually_exclusive_group()
    post_apply_group.add_argument(
        "--post-apply-check",
        action="store_true",
        help=(
            "If using --run, re-run the command against the real project files after applying fixes "
            "(uses sandbox venv for deps)."
        ),
    )
    post_apply_group.add_argument(
        "--no-post-apply-check",
        action="store_true",
        help="Disable the post-apply re-run check (even if --run is set).",
    )

    parser.add_argument(
        "--format",
        default=None,
        choices=["black"],
        help="Optional: run formatter in sandbox (best-effort). Currently supported: black",
    )
    parser.add_argument(
        "--lint",
        default=None,
        choices=["ruff"],
        help="Optional: run linter in sandbox (best-effort). Currently supported: ruff",
    )
    parser.add_argument(
        "--fix",
        action="store_true",
        help="If used with --lint ruff, apply fixes (ruff --fix) (best-effort)",
    )

    # ✅ Proper boolean flags
    ask_group = parser.add_mutually_exclusive_group()
    ask_group.add_argument(
        "--ask",
        action="store_true",
        help="Ask before overwriting files",
    )
    ask_group.add_argument(
        "--no-ask",
        action="store_true",
        help="Do not ask before overwriting files",
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose/debug output",
    )

    args = parser.parse_args()

    if not args.entry_file:
        parser.error("the following arguments are required: entry_file")

    # ENV defaults
    env_ask = config("AUTO_CODE_FIXER_ASK", default=False, cast=bool)
    env_verbose = config("AUTO_CODE_FIXER_VERBOSE", default=False, cast=bool)

    # Final ask resolution (CLI overrides ENV)
    if args.ask:
        ask = True
    elif args.no_ask:
        ask = False
    else:
        ask = env_ask

    verbose = args.verbose or env_verbose
    set_verbose(verbose)

    # Optional: enable AI planning helper
    if args.ai_plan:
        os.environ["AUTO_CODE_FIXER_AI_PLAN"] = "1"

    if args.no_post_apply_check:
        post_apply_check = False
    elif args.post_apply_check:
        post_apply_check = True
    else:
        post_apply_check = bool(args.run)

    ok = fix_file(
        args.entry_file,
        args.project_root,
        args.api_key,
        ask,
        verbose,
        dry_run=args.dry_run,
        model=args.model,
        timeout_s=args.timeout,
        max_retries=args.max_retries,
        run_cmd=args.run,
        patch_protocol=not args.legacy_mode,
        max_files_changed=args.max_files_changed,
        context_files=args.context_files,
        approve=args.approve,
        max_diff_lines=args.max_diff_lines,
        max_file_bytes=args.max_file_bytes,
        max_total_bytes=args.max_total_bytes,
        post_apply_check=post_apply_check,
        fmt=args.format,
        lint=args.lint,
        lint_fix=args.fix,
    )

    raise SystemExit(0 if ok else 2)


if __name__ == "__main__":
    main()
