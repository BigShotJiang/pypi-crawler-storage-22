import os
import shlex
import subprocess


def run_command(
    cmd: str,
    *,
    timeout_s: int,
    python_exe: str,
    cwd: str,
    extra_env: dict | None = None,
):
    """Run an arbitrary command inside the sandbox.

    If cmd starts with 'python', replace with the sandbox venv python.
    If cmd starts with 'pytest', run as `python -m pytest ...`.
    """

    parts = shlex.split(cmd)
    if not parts:
        return -1, "", "Empty command"

    if parts[0] == "python" or parts[0] == "python3":
        parts[0] = python_exe

    if parts[0] == "pytest":
        parts = [python_exe, "-m", "pytest", *parts[1:]]

    env = {**os.environ}
    if extra_env:
        env.update({k: str(v) for k, v in extra_env.items()})

    try:
        r = subprocess.run(
            parts,
            capture_output=True,
            text=True,
            timeout=timeout_s,
            cwd=cwd,
            env=env,
        )
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return -1, "", f"TimeoutExpired: Command took too long to run ({timeout_s}s)."
