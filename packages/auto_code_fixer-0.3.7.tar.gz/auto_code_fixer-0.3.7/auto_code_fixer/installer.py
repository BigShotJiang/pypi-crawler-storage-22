import re
import subprocess


_MISSING_RE = re.compile(r"No module named '([^']+)'")

# common import-name -> pip-package mappings
IMPORT_TO_PIP = {
    "PIL": "Pillow",
    "cv2": "opencv-python",
    "sklearn": "scikit-learn",
    "yaml": "PyYAML",
    "Crypto": "pycryptodome",
}


def parse_missing_module(stderr: str) -> str | None:
    m = _MISSING_RE.search(stderr or "")
    if not m:
        return None
    return m.group(1)


def install_package(package: str, *, python_exe: str) -> bool:
    try:
        subprocess.check_call([python_exe, "-m", "pip", "install", package])
        return True
    except subprocess.CalledProcessError:
        return False


def is_local_module(module: str, *, project_root: str) -> bool:
    """Return True if `module` can be resolved to a local file/package under project_root."""
    import os
    from pathlib import Path

    base = Path(project_root)
    parts = module.split(".")
    candidates = [
        base.joinpath(*parts).with_suffix(".py"),
        base.joinpath(*parts, "__init__.py"),
    ]
    return any(os.path.isfile(str(p)) for p in candidates)


def check_and_install_missing_lib(stderr: str, *, python_exe: str, project_root: str) -> bool:
    lib = parse_missing_module(stderr)
    if not lib:
        return False

    # ✅ Important: do NOT pip install if it's a local module.
    if is_local_module(lib, project_root=project_root):
        return False

    pkg = IMPORT_TO_PIP.get(lib, lib)
    return install_package(pkg, python_exe=python_exe)
