from __future__ import annotations

from dataclasses import dataclass


@dataclass
class RunResult:
    returncode: int
    stdout: str
    stderr: str


@dataclass
class FixResult:
    success: bool
    attempts: int
    changed_files: list[str]
    last_error: str | None = None
    sandbox_root: str | None = None
