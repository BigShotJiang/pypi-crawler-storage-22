import hashlib
import json
import os
from dataclasses import dataclass


@dataclass(frozen=True)
class PatchFile:
    """A single file edit from the structured patch protocol."""

    path: str
    new_content: str
    sha256: str


def strip_code_fences(text: str) -> str:
    text = (text or "").strip()
    if text.startswith("```"):
        text = "\n".join(text.split("\n")[1:])
    if text.endswith("```"):
        text = "\n".join(text.split("\n")[:-1])
    return text.strip()


def compute_sha256_utf8(content: str) -> str:
    return hashlib.sha256((content or "").encode("utf-8")).hexdigest()


def parse_patch_protocol_response(text: str) -> list[PatchFile]:
    """Parse model output for the patch protocol.

    Expected JSON schema:
      {"files": [{"path": "...", "new_content": "...", "sha256": "..."}, ...]}

    Raises ValueError on invalid input.
    """

    cleaned = strip_code_fences(text)

    try:
        payload = json.loads(cleaned)
    except Exception as e:  # pragma: no cover
        raise ValueError(f"Invalid JSON: {e}")

    if not isinstance(payload, dict):
        raise ValueError("Patch protocol JSON must be an object")

    files = payload.get("files")
    if not isinstance(files, list) or not files:
        raise ValueError("Patch protocol JSON must contain non-empty 'files' list")

    out: list[PatchFile] = []
    for i, f in enumerate(files):
        if not isinstance(f, dict):
            raise ValueError(f"files[{i}] must be an object")

        path = f.get("path")
        new_content = f.get("new_content")
        sha256 = f.get("sha256")

        if not isinstance(path, str) or not path.strip():
            raise ValueError(f"files[{i}].path must be a non-empty string")
        if not isinstance(new_content, str):
            raise ValueError(f"files[{i}].new_content must be a string")
        if not isinstance(sha256, str) or len(sha256.strip()) != 64:
            raise ValueError(f"files[{i}].sha256 must be a 64-char hex string")

        out.append(PatchFile(path=path, new_content=new_content, sha256=sha256.strip().lower()))

    return out


def validate_and_resolve_patch_files(
    patch_files: list[PatchFile], *, sandbox_root: str
) -> list[tuple[str, str]]:
    """Validate patch files and return a list of (abs_path, new_content).

    Safety:
    - paths must be relative and remain within sandbox_root
    - sha256 must match new_content (utf-8)
    """

    sr = os.path.realpath(os.path.abspath(sandbox_root))
    resolved: list[tuple[str, str]] = []

    for pf in patch_files:
        if os.path.isabs(pf.path):
            raise ValueError(f"Absolute path not allowed in patch protocol: {pf.path}")

        # Normalize and resolve against sandbox_root
        abs_path = os.path.realpath(os.path.abspath(os.path.join(sr, pf.path)))

        if not (abs_path.startswith(sr + os.sep) or abs_path == sr):
            raise ValueError(f"Patch path escapes sandbox root: {pf.path}")

        got = compute_sha256_utf8(pf.new_content)
        if got != pf.sha256:
            raise ValueError(f"sha256 mismatch for {pf.path}: expected {pf.sha256}, got {got}")

        resolved.append((abs_path, pf.new_content))

    return resolved
