import os
import tempfile
from dataclasses import dataclass

from auto_code_fixer.patch_protocol import compute_sha256_utf8


@dataclass
class FileEdit:
    path: str
    new_content: str


def _atomic_write(path: str, content: str) -> None:
    """Atomically write text content to path.

    Writes to a temp file in the same directory then os.replace() to avoid partial writes.
    """

    dir_name = os.path.dirname(path) or "."
    os.makedirs(dir_name, exist_ok=True)

    fd, tmp_path = tempfile.mkstemp(prefix=".acf_", suffix=".tmp", dir=dir_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    finally:
        try:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
        except Exception:
            pass


def atomic_write_verified_sha256(path: str, content: str, expected_sha256: str) -> None:
    """Atomically write text content, verifying sha256(content) before commit."""

    got = compute_sha256_utf8(content)
    if got != (expected_sha256 or "").strip().lower():
        raise ValueError(f"sha256 mismatch for {path}: expected {expected_sha256}, got {got}")

    _atomic_write(path, content)


def safe_write(path: str, content: str) -> None:
    # Backwards-compatible name; now atomic.
    _atomic_write(path, content)


def safe_read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def backup_file(path: str) -> str:
    bak = path + ".bak"
    # Avoid overwriting an existing bak
    i = 1
    while os.path.exists(bak):
        bak = f"{path}.bak{i}"
        i += 1
    with open(path, "rb") as src, open(bak, "wb") as dst:
        dst.write(src.read())
    return bak
