import json
import os
from dataclasses import dataclass

from auto_code_fixer.fixer import get_openai_client


@dataclass
class FixPlan:
    target_files: list[str]
    reason: str


def ask_ai_for_fix_plan(*, sandbox_root: str, stderr: str, api_key: str | None, model: str | None) -> FixPlan | None:
    """Optional: let AI propose which file to edit.

    This is a best-effort helper; errors should be ignored by caller.
    """

    if os.getenv("AUTO_CODE_FIXER_AI_PLAN", "0").lower() not in {"1", "true", "yes"}:
        return None

    client = get_openai_client(api_key)
    model = model or os.getenv("AUTO_CODE_FIXER_MODEL") or "gpt-4.1-mini"

    prompt = (
        "Given this Python traceback, decide which local file(s) should be edited to fix it.\n"
        "Return ONLY JSON with keys: target_files (list of relative paths), reason (string).\n"
        f"Sandbox root: {sandbox_root}\n\n"
        "Traceback:\n" + (stderr or "")
    )

    resp = client.responses.create(
        model=model,
        input=[{"role": "user", "content": prompt}],
        temperature=0.0,
        max_output_tokens=600,
    )

    text = ""
    for item in resp.output or []:
        for c in item.content or []:
            if getattr(c, "type", None) in ("output_text", "text"):
                text += getattr(c, "text", "") or ""

    text = (text or "").strip()
    if not text:
        return None

    data = json.loads(text)
    if not isinstance(data, dict):
        return None

    target_files = data.get("target_files") or []
    if not isinstance(target_files, list):
        return None

    target_files = [str(x) for x in target_files if x]
    reason = str(data.get("reason") or "")

    return FixPlan(target_files=target_files, reason=reason)
