import os
import subprocess
import sys


def run_code(
    path_to_code: str,
    *,
    timeout_s: int = 30,
    python_exe: str | None = None,
    cwd: str | None = None,
    extra_env: dict | None = None,
):
    """Run a python file and capture output.

    python_exe: allow running inside a venv interpreter.
    cwd: working directory (important for relative imports/files)
    extra_env: extra environment variables (merged)
    """

    exe = python_exe or sys.executable
    env = {**os.environ}
    if extra_env:
        env.update({k: str(v) for k, v in extra_env.items()})

    try:
        result = subprocess.run(
            [exe, path_to_code],
            capture_output=True,
            text=True,
            timeout=timeout_s,
            env=env,
            cwd=cwd,
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "TimeoutExpired: Code took too long to run."

