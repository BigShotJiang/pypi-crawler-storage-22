import os
import shutil
import tempfile
from pathlib import Path


def make_sandbox(*, entry_file: str, project_root: str) -> tuple[str, str]:
    """Create a sandbox directory containing entry_file and discovered local imports.

    Returns (sandbox_root, sandbox_entry_path).

    Files are copied preserving relative paths from project_root.
    """

    from auto_code_fixer.utils import discover_all_files

    project_root = os.path.abspath(project_root)
    entry_file = os.path.abspath(entry_file)

    sandbox_root = tempfile.mkdtemp(prefix="codefix_sandbox_")

    files = discover_all_files(entry_file)

    for src in files:
        src = os.path.abspath(src)
        if not src.startswith(project_root):
            # Skip anything outside the project
            continue
        rel = os.path.relpath(src, project_root)
        dst = os.path.join(sandbox_root, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy(src, dst)

    sandbox_entry = os.path.join(sandbox_root, os.path.relpath(entry_file, project_root))
    return sandbox_root, sandbox_entry


def apply_sandbox_back(*, sandbox_root: str, project_root: str, changed_paths: list[str]) -> None:
    """Copy changed sandbox files back into project_root."""

    project_root = os.path.abspath(project_root)
    for p in changed_paths:
        p = os.path.abspath(p)
        if not p.startswith(os.path.abspath(sandbox_root)):
            continue
        rel = os.path.relpath(p, sandbox_root)
        dst = os.path.join(project_root, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy(p, dst)
