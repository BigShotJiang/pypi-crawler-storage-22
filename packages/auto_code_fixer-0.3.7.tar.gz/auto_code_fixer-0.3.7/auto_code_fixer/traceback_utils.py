import os
import re

_FILE_RE = re.compile(r"File \"([^\"]+)\", line (\d+)")


def _norm(p: str) -> str:
    """Normalize paths for comparison.

    On macOS tracebacks often include /private prefix; realpath handles that.
    """
    return os.path.realpath(os.path.abspath(p))


def pick_relevant_file(stderr: str, *, sandbox_root: str) -> str | None:
    """Pick the most relevant python file from a traceback.

    Strategy: return the last file path that lives inside sandbox_root.

    Uses realpath() to handle macOS '/private/var/...' vs '/var/...' differences.
    """

    if not stderr:
        return None

    sandbox_root_n = _norm(sandbox_root)
    matches = _FILE_RE.findall(stderr)
    if not matches:
        return None

    chosen = None
    for path, _lineno in matches:
        ap = _norm(path)
        if ap.startswith(sandbox_root_n + os.sep) or ap == sandbox_root_n:
            chosen = ap

    return chosen
