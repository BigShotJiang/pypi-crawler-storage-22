import ast
import os
import re
from datetime import datetime
from pathlib import Path


VERBOSE = False


def set_verbose(value: bool):
    global VERBOSE
    VERBOSE = value


def log(message, level="INFO"):
    if level == "DEBUG" and not VERBOSE:
        return

    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"[{timestamp}] {level}: {message}")


def _module_to_candidate_paths(project_root: str, module: str) -> list[str]:
    """Resolve a module name to potential local file paths."""
    base = Path(project_root)
    parts = module.split(".")

    # module.py
    p1 = base.joinpath(*parts).with_suffix(".py")
    # module/__init__.py
    p2 = base.joinpath(*parts, "__init__.py")
    return [str(p1), str(p2)]


def find_imports(file_path: str, project_root: str) -> list[str]:
    """AST-based import discovery for local files.

    This is more accurate than regex scanning and supports:
    - import x
    - import x.y
    - from x import y
    - from x.y import z

    Only resolves modules that map to a file under project_root.
    """

    found: set[str] = set()

    try:
        src = Path(file_path).read_text(encoding="utf-8")
        tree = ast.parse(src)
    except Exception:
        # Fallback to regex if parsing fails
        import_pattern = re.compile(r"^\s*(?:from|import)\s+([a-zA-Z0-9_\.]+)")
        for line in src.splitlines() if 'src' in locals() else Path(file_path).read_text(encoding='utf-8').splitlines():
            m = import_pattern.match(line)
            if not m:
                continue
            mod = m.group(1)
            for c in _module_to_candidate_paths(project_root, mod):
                if os.path.isfile(c):
                    found.add(os.path.abspath(c))
        return sorted(found)

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                mod = alias.name
                for c in _module_to_candidate_paths(project_root, mod):
                    if os.path.isfile(c):
                        found.add(os.path.abspath(c))

        if isinstance(node, ast.ImportFrom):
            if not node.module:
                continue
            mod = node.module
            for c in _module_to_candidate_paths(project_root, mod):
                if os.path.isfile(c):
                    found.add(os.path.abspath(c))

    return sorted(found)


def discover_all_files(entry_file: str) -> list[str]:
    """Discover all local python files imported from entry_file."""

    project_root = os.path.dirname(os.path.abspath(entry_file))
    stack = [os.path.abspath(entry_file)]
    discovered: set[str] = set()

    while stack:
        current = stack.pop()
        if current in discovered:
            continue

        discovered.add(current)
        for f in find_imports(current, project_root):
            if f not in discovered:
                stack.append(f)

    return sorted(discovered)


def is_in_project(file_path: str, project_root: str) -> bool:
    return os.path.abspath(file_path).startswith(os.path.abspath(project_root))
