import os
import subprocess
import sys
from pathlib import Path


def create_venv(dir_path: str) -> str:
    """Create a venv and return path to its python executable."""
    venv_dir = Path(dir_path) / ".venv"
    if not venv_dir.exists():
        subprocess.check_call([sys.executable, "-m", "venv", str(venv_dir)])

    # Linux/mac
    py = venv_dir / "bin" / "python"
    if py.exists():
        # ensure pip exists
        subprocess.check_call([str(py), "-m", "pip", "install", "-U", "pip"], stdout=subprocess.DEVNULL)
        return str(py)

    # Windows fallback
    py = venv_dir / "Scripts" / "python.exe"
    if py.exists():
        subprocess.check_call([str(py), "-m", "pip", "install", "-U", "pip"], stdout=subprocess.DEVNULL)
        return str(py)

    raise RuntimeError(f"Could not locate venv python in {venv_dir}")


def install_editable(project_root: str, *, python_exe: str) -> None:
    """Install project (editable) into venv for proper imports."""
    # Avoid user site-packages contamination
    env = {**os.environ, "PIP_DISABLE_PIP_VERSION_CHECK": "1"}
    subprocess.check_call([python_exe, "-m", "pip", "install", "-e", project_root], env=env, stdout=subprocess.DEVNULL)
