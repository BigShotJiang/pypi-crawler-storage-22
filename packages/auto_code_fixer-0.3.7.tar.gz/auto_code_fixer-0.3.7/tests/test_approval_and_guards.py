import pytest

from auto_code_fixer.approval import (
    PlannedChange,
    UserAbort,
    guard_planned_changes,
    prompt_approve_file_by_file,
)


def test_guard_planned_changes_rejects_big_file():
    planned = [
        PlannedChange(
            abs_path="/tmp/a.py",
            rel_path="a.py",
            old_content="",
            new_content="x" * 11,
        )
    ]
    with pytest.raises(ValueError, match="max-file-bytes"):
        guard_planned_changes(planned, max_file_bytes=10, max_total_bytes=100, max_diff_lines=100)


def test_guard_planned_changes_rejects_total_bytes():
    planned = [
        PlannedChange("/tmp/a.py", "a.py", "", "x" * 6),
        PlannedChange("/tmp/b.py", "b.py", "", "x" * 6),
    ]
    with pytest.raises(ValueError, match="max-total-bytes"):
        guard_planned_changes(planned, max_file_bytes=100, max_total_bytes=10, max_diff_lines=100)


def test_prompt_approve_file_by_file_apply_skip():
    planned = [
        PlannedChange("/tmp/a.py", "a.py", "print(1)\n", "print(2)\n"),
        PlannedChange("/tmp/b.py", "b.py", "print(1)\n", "print(3)\n"),
    ]

    answers = iter(["y", "n"])

    def _input(_prompt: str) -> str:
        return next(answers)

    chosen = prompt_approve_file_by_file(planned, input_fn=_input, print_fn=lambda *_: None)
    assert [c.rel_path for c in chosen] == ["a.py"]


def test_prompt_approve_file_by_file_abort():
    planned = [PlannedChange("/tmp/a.py", "a.py", "", "x")]

    def _input(_prompt: str) -> str:
        return "q"

    with pytest.raises(UserAbort):
        prompt_approve_file_by_file(planned, input_fn=_input, print_fn=lambda *_: None)
