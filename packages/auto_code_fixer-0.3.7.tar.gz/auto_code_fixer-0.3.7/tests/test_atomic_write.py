import os
from pathlib import Path

import pytest

from auto_code_fixer.patcher import atomic_write_verified_sha256, safe_read, safe_write
from auto_code_fixer.patch_protocol import compute_sha256_utf8


def test_safe_write_is_atomic_and_writes_content(tmp_path: Path):
    p = tmp_path / "a.txt"
    safe_write(str(p), "hello")
    assert safe_read(str(p)) == "hello"


def test_atomic_write_verified_sha256_rejects_mismatch_and_does_not_modify(tmp_path: Path):
    p = tmp_path / "a.txt"
    p.write_text("old", encoding="utf-8")

    with pytest.raises(ValueError, match="sha256 mismatch"):
        atomic_write_verified_sha256(str(p), "new", expected_sha256="0" * 64)

    assert p.read_text(encoding="utf-8") == "old"


def test_atomic_write_verified_sha256_accepts_and_modifies(tmp_path: Path):
    p = tmp_path / "a.txt"
    p.write_text("old", encoding="utf-8")

    content = "new content\n"
    sha = compute_sha256_utf8(content)
    atomic_write_verified_sha256(str(p), content, expected_sha256=sha)

    assert p.read_text(encoding="utf-8") == content
