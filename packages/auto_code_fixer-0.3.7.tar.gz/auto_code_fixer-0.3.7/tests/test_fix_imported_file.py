import subprocess
import sys
from pathlib import Path


def test_fix_applies_to_imported_file_with_backup(tmp_path: Path):
    proj = tmp_path / "proj"
    proj.mkdir()

    # This module has a bug
    (proj / "mylib.py").write_text(
        "def add(a, b):\n    return a + c\n",
        encoding="utf-8",
    )

    # Entry imports it
    (proj / "main.py").write_text(
        "from mylib import add\n\nprint(add(1, 2))\n",
        encoding="utf-8",
    )

    # Run fixer with OPENAI_API_KEY inherited from env if present.
    cmd = [
        sys.executable,
        "-m",
        "auto_code_fixer.cli",
        str(proj / "main.py"),
        "--project-root",
        str(proj),
        "--no-ask",
        "--timeout",
        "30",
        "--max-retries",
        "2",
    ]

    r = subprocess.run(cmd, capture_output=True, text=True, timeout=180)

    # If OPENAI_API_KEY isn't set, the tool will fail when trying to fix.
    # In CI without key, we just assert it ran and produced an error.
    if "OpenAI API key not found" in (r.stdout + r.stderr):
        return

    assert r.returncode == 0

    # At least one backup should exist if files were overwritten.
    # Depending on the model's fix strategy, it may edit main.py or mylib.py.
    assert any(p.name.endswith(".bak") or ".bak" in p.name for p in proj.iterdir())
