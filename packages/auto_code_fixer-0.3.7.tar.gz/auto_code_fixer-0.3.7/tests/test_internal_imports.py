import os
import subprocess
import sys
from pathlib import Path


def test_internal_import_not_pip_installed(tmp_path: Path):
    """Regression: internal imports should not trigger pip install attempts."""

    proj = tmp_path / "proj"
    proj.mkdir()

    # internal module
    (proj / "mylib.py").write_text(
        "def add(a, b):\n    return a + b\n",
        encoding="utf-8",
    )

    # entry file imports local module
    (proj / "main.py").write_text(
        "from mylib import add\n\nprint(add(1, 2))\n",
        encoding="utf-8",
    )

    # run the tool in dry-run mode (should just execute successfully)
    cmd = [sys.executable, "-m", "auto_code_fixer.cli", str(proj / "main.py"), "--project-root", str(proj), "--dry-run"]

    r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    assert r.returncode == 0
    assert "No module named" not in (r.stderr + r.stdout)
