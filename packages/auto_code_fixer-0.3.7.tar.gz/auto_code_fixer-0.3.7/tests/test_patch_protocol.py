import pytest

from auto_code_fixer.patch_protocol import (
    compute_sha256_utf8,
    parse_patch_protocol_response,
    validate_and_resolve_patch_files,
)


def test_parse_patch_protocol_happy_path_with_code_fences(tmp_path):
    import json

    content = "print('hi')\n"
    sha = compute_sha256_utf8(content)
    payload = {"files": [{"path": "a.py", "new_content": content, "sha256": sha}]}
    text = "```json\n" + json.dumps(payload) + "\n```"

    files = parse_patch_protocol_response(text)
    assert len(files) == 1
    assert files[0].path == "a.py"
    assert files[0].sha256 == sha

    resolved = validate_and_resolve_patch_files(files, sandbox_root=str(tmp_path))
    assert resolved[0][0].endswith("a.py")
    assert resolved[0][1] == content


def test_validate_rejects_sha_mismatch(tmp_path):
    text = '{"files": [{"path": "a.py", "new_content": "x", "sha256": "' + ("0" * 64) + '"}]}'
    files = parse_patch_protocol_response(text)
    with pytest.raises(ValueError, match="sha256 mismatch"):
        validate_and_resolve_patch_files(files, sandbox_root=str(tmp_path))


def test_validate_rejects_path_traversal(tmp_path):
    content = "x"
    sha = compute_sha256_utf8(content)
    text = '{"files": [{"path": "../evil.py", "new_content": "x", "sha256": "' + sha + '"}]}'
    files = parse_patch_protocol_response(text)
    with pytest.raises(ValueError, match="escapes sandbox"):
        validate_and_resolve_patch_files(files, sandbox_root=str(tmp_path))


def test_parse_rejects_missing_files_list():
    with pytest.raises(ValueError, match="files"):
        parse_patch_protocol_response("{}")
