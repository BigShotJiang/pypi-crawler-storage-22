import dataclasses
import datetime as _dt
import difflib
import json
import os
from typing import Any


def utc_now_iso() -> str:
    return _dt.datetime.now(tz=_dt.timezone.utc).isoformat()


def unified_diff(*, old: str, new: str, fromfile: str, tofile: str) -> str:
    return "".join(
        difflib.unified_diff(
            (old or "").splitlines(keepends=True),
            (new or "").splitlines(keepends=True),
            fromfile=fromfile,
            tofile=tofile,
        )
    )


@dataclasses.dataclass
class ReportAttempt:
    index: int
    run_cmd: str
    return_code: int = 0
    stdout: str | None = None
    stderr: str | None = None
    selected_file: str | None = None
    ruff_first_applied: bool = False
    changed_files: list[str] = dataclasses.field(default_factory=list)


@dataclasses.dataclass
class FixReport:
    tool: str = "auto-code-fixer"
    version: str | None = None
    mode: str = "file"  # file|fixpack
    project_root: str | None = None
    sandbox_root: str | None = None
    target: str | None = None
    run_cmd: str | None = None
    started_at: str = dataclasses.field(default_factory=utc_now_iso)
    finished_at: str | None = None
    ok: bool | None = None
    attempts: list[ReportAttempt] = dataclasses.field(default_factory=list)
    files_touched: list[str] = dataclasses.field(default_factory=list)
    diffs: dict[str, str] = dataclasses.field(default_factory=dict)  # relpath -> unified diff

    def to_dict(self) -> dict[str, Any]:
        d = dataclasses.asdict(self)
        # dataclasses.asdict converts nested dataclasses, OK
        return d

    def write_json(self, path: str) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2, sort_keys=False)
            f.write("\n")
