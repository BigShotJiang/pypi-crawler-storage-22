import os
import shutil
import tempfile
from pathlib import Path


def make_sandbox(*, entry_file: str, project_root: str) -> tuple[str, str]:
    """Create a sandbox directory containing entry_file and discovered local imports.

    Returns (sandbox_root, sandbox_entry_path).

    Files are copied preserving relative paths from project_root.
    """

    from auto_code_fixer.utils import discover_all_files

    project_root = os.path.abspath(project_root)
    entry_file = os.path.abspath(entry_file)

    sandbox_root = tempfile.mkdtemp(prefix="codefix_sandbox_")

    files = discover_all_files(entry_file)

    for src in files:
        src = os.path.abspath(src)
        if not src.startswith(project_root):
            # Skip anything outside the project
            continue
        rel = os.path.relpath(src, project_root)
        dst = os.path.join(sandbox_root, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy(src, dst)

    sandbox_entry = os.path.join(sandbox_root, os.path.relpath(entry_file, project_root))
    return sandbox_root, sandbox_entry


def make_sandbox_project(*, project_root: str) -> str:
    """Create a sandbox directory with a full copy of project_root.

    This is used for "Fixpack" runs where we execute a command (e.g., pytest) across
    a package/folder and iteratively fix failures.
    """

    project_root = os.path.abspath(project_root)
    sandbox_root = tempfile.mkdtemp(prefix="codefix_sandbox_")

    def _ignore(_dir: str, names: list[str]):
        skip = {".git",
            ".venv",
            "__pycache__",
            "build",
            "dist",
            ".mypy_cache",
            ".ruff_cache",
            ".pytest_cache",
        }
        return {n for n in names if n in skip}

    # Copy everything into sandbox_root.
    # Note: copytree requires dest not to exist; copy contents manually.
    for item in os.listdir(project_root):
        src = os.path.join(project_root, item)
        dst = os.path.join(sandbox_root, item)
        if os.path.isdir(src):
            shutil.copytree(src, dst, ignore=_ignore)
        else:
            shutil.copy2(src, dst)

    return sandbox_root


def apply_sandbox_back(*, sandbox_root: str, project_root: str, changed_paths: list[str]) -> None:
    """Copy changed sandbox files back into project_root."""

    project_root = os.path.abspath(project_root)
    for p in changed_paths:
        p = os.path.abspath(p)
        if not p.startswith(os.path.abspath(sandbox_root)):
            continue
        rel = os.path.relpath(p, sandbox_root)
        dst = os.path.join(project_root, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy(p, dst)
