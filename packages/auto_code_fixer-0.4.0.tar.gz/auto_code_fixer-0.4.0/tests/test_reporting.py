import json
from pathlib import Path

from auto_code_fixer.reporting import FixReport, ReportAttempt, unified_diff


def test_unified_diff_contains_markers():
    d = unified_diff(old="a\n", new="b\n", fromfile="a/x.py", tofile="b/x.py")
    assert "--- a/x.py" in d
    assert "+++ b/x.py" in d
    assert "-a" in d
    assert "+b" in d


def test_fix_report_serializes(tmp_path: Path):
    r = FixReport(version="0.0.0", mode="file", project_root="/p", target="/p/x.py")
    r.attempts.append(ReportAttempt(index=1, run_cmd="python x.py", return_code=1))
    out = tmp_path / "report.json"
    r.write_json(str(out))
    data = json.loads(out.read_text(encoding="utf-8"))
    assert data["tool"] == "auto-code-fixer"
    assert data["mode"] == "file"
    assert data["attempts"][0]["index"] == 1
