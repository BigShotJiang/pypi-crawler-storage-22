# action.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



from abc import ABCMeta, abstractmethod

from AutoArchive._application._action.action_result import ActionResult



class Action(metaclass = ABCMeta):
    def __init__(self, actionResult: ActionResult):
        self.__actionResult = actionResult



    def execute(self) -> bool:
        self.__actionResult.set(ActionResult.ActionResults.Successful)
        self.__actionResult.startObservingUiMessages()

        result = self.executeAction_()

        self.__actionResult.stopObservingUiMessages()

        self.handleResult_(self.__actionResult)

        return self.__actionResult.computeReturnValue(result)



    @abstractmethod
    def executeAction_(self) -> bool:
        pass



    def handleResult_(self, actionResult: ActionResult) -> None:
        pass
