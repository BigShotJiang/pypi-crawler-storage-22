# _action_result.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



from AutoArchive._infrastructure.ui import UiMessageKinds
from AutoArchive._infrastructure.py_additions import Enum



class ActionResult:

    #: Enumerates statuses how a backup operation can finish.
    ActionResults = Enum(

        #: Backup operation finished successfully.
        "Successful",

        #: Backup operation finished successfully with some issues (warnings).
        "Issues",

        #: Backup operation failed.
        "Failed")



    def __init__(self, componentUi):
        self.__componentUi = componentUi

        self.__result: ActionResult = self.ActionResults.Successful



    @property
    def result(self) -> ActionResults:
        return self.__result



    def set(self, result: ActionResults):
        self.__result = result



    def startObservingUiMessages(self):
        self.__componentUi.messageShown += self.__onMessageShown



    def stopObservingUiMessages(self):
        self.__componentUi.messageShown -= self.__onMessageShown



    def computeReturnValue(self, executeResult: bool) -> bool:
        return self.__result == self.ActionResults.Successful and executeResult == True



    def __onMessageShown(self, messageKind: UiMessageKinds):
        "Sets the backup status."

        # SMELL: Split status evaluation and message presentation.
        if messageKind == UiMessageKinds.Warning and self.__result != self.ActionResults.Failed:
            self.__result = self.ActionResults.Issues
        elif messageKind == UiMessageKinds.Error:
            self.__result = self.ActionResults.Failed
