# _archiving_constants.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



from abc import ABCMeta, abstractmethod



class _RestartStorageVariables(metaclass = ABCMeta):
    """Names of storage variables for backup level restarting."""

    LAST_RESTART = "archiving-last-restart"
    LAST_FULL_RESTART = "archiving-last-full-restart"
    BACKUP_SIZE = "archiving-size-level"
    RESTART_COUNT = "archiving-restart-count"



    @abstractmethod
    def __init__(self):
        pass
