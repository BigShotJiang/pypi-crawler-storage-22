# _utils.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



from AutoArchive._infrastructure.configuration import Options, ConfigurationBase, ArchiverTypes
from AutoArchive._infrastructure.service._service_accessor import ServiceAccessor
from AutoArchive._services.archiver import ArchiverServiceIdentification, ArchiverServiceProviderIDs
from AutoArchive._services.archiver.tar_archiver_provider_base import TarArchiverProviderBase



class _Utils:

    # SMELL: This is duplication with service provider ID and TarArchiverProviderBase.supportedBackupTypes;
    # map should be made between ArchiverTypes and BackupTypes then get query services for supportedBackupTypes
    __ARCHIVER_TYPE_TO_PROVIDER_ID_MAP = {ArchiverTypes.Tar: ArchiverServiceProviderIDs.TarExternal,
                                          ArchiverTypes.TarGz: ArchiverServiceProviderIDs.TarExternal,
                                          ArchiverTypes.TarBz2: ArchiverServiceProviderIDs.TarExternal,
                                          ArchiverTypes.TarXz: ArchiverServiceProviderIDs.TarExternal,
                                          ArchiverTypes.TarZst: ArchiverServiceProviderIDs.TarExternal,
                                          ArchiverTypes.TarInternal: ArchiverServiceProviderIDs.TarInternal,
                                          ArchiverTypes.TarGzInternal: ArchiverServiceProviderIDs.TarInternal,
                                          ArchiverTypes.TarBz2Internal: ArchiverServiceProviderIDs.TarInternal}



    @classmethod
    def getOrCreateArchiverService(cls,
            serviceAccessor: ServiceAccessor, archiveSpec: ConfigurationBase) -> TarArchiverProviderBase:
        providerIdentification = cls.__ARCHIVER_TYPE_TO_PROVIDER_ID_MAP[archiveSpec[Options.ARCHIVER]]
        return serviceAccessor.getOrCreateService(ArchiverServiceIdentification, providerIdentification)
