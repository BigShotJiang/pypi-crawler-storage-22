# action_utils.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



from AutoArchive._infrastructure.configuration import Options
from AutoArchive._infrastructure.service._service_accessor import ServiceAccessor
from AutoArchive._infrastructure.utils import Utils
from AutoArchive._services.external_command_executor import ExternalCommandExecutorServiceIdentification
from .._archiving import _Archiving
from .._command_executor import _CommandExecutor
from ..._action.action_result import ActionResult



class ActionUtils:

    def __init__(self, componentUi, applicationContext, serviceAccessor: ServiceAccessor):
        self.__componentUi = componentUi

        self.__configuration = applicationContext.configuration
        self.__commandExecutor = _CommandExecutor(self.__configuration, serviceAccessor.getOrCreateService(
            ExternalCommandExecutorServiceIdentification, None), self.__componentUi)
        self.__archiving = _Archiving(componentUi, applicationContext, serviceAccessor, self.__commandExecutor)
        self.__actionResult = ActionResult(self.__componentUi)



    @property
    def actionResult(self) -> ActionResult:
        return self.__actionResult



    @property
    def configuration(self):
        return self.__configuration



    @property
    def archiving(self) -> _Archiving:
        return self.__archiving



    @property
    def commandExecutor(self) -> _CommandExecutor:
        return self.__commandExecutor



    @property
    def componentUi(self):
        return self.__componentUi



    def getArchiveSpecsForProcessing(self, selectedArchiveSpecs):

        @Utils.uniq
        def getAllUniqueArchiveSpecs():
            for archiveSpecInfo in selectedArchiveSpecs:
                yield archiveSpecInfo

            empty = True
            for archiveSpecInfo in self.__archiving.getArchiveSpecs():
                empty = False
                yield archiveSpecInfo
            if empty:
                self.__componentUi.showWarning("No configured archive specification files were found.")



        if len(selectedArchiveSpecs) == 0 or self.__configuration[Options.ALL]:
            try:
                allUniqueArchiveSpecs = tuple(getAllUniqueArchiveSpecs())
            except (RuntimeError, OSError) as ex:
                self.__componentUi.showError(str.format(
                    "An error occurred while obtaining the list of all archive specification files: {}", ex))
                return None
            return allUniqueArchiveSpecs
        else:
            return selectedArchiveSpecs



    def getOrphanedArchives(self, archiveSpecs):
        return (name
                for name in self.__archiving.getStoredArchiveNames()
                if name not in frozenset(self.getValidArchiveNames(archiveSpecs)))



    @Utils.uniq
    def getValidArchiveNames(self, archiveSpecs):
        return self.__archiving.filterValidSpecFiles((archSpecInf.path for archSpecInf in archiveSpecs))
