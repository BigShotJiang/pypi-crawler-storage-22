# _purge_action.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



from AutoArchive._infrastructure.configuration import Options
from AutoArchive._infrastructure.ui import VerbosityLevels
from .action_utils import ActionUtils
from ..._action.action import Action



class PurgeAction(Action):

    def __init__(self, actionUtils: ActionUtils, selectedArchiveSpecs):
        super().__init__(actionUtils.actionResult)

        self.__actionUtils = actionUtils
        self.__selectedArchiveSpecs = selectedArchiveSpecs

        self.__archiving = actionUtils.archiving
        self.__componentUi = actionUtils.componentUi



    def executeAction_(self) -> bool:
        result = True

        archiveSpecsForProcessing = self.__actionUtils.getArchiveSpecsForProcessing(self.__selectedArchiveSpecs)
        if archiveSpecsForProcessing is None:
            return False

        orphanedArchives = frozenset(self.__actionUtils.getOrphanedArchives(archiveSpecsForProcessing))
        knownValidArchiveNames = frozenset(self.__actionUtils.getValidArchiveNames(archiveSpecsForProcessing))
        try:
            # names of archive specs which were selected by a name, not by path to .aa file
            archiveSpecNamesSelectedByName = [asi.name for asi in self.__selectedArchiveSpecs if asi.name is not None]
            for archiveSpecName in archiveSpecNamesSelectedByName:
                self.__componentUi.setProcessingArchSpec(archiveSpecName)
                if archiveSpecName in orphanedArchives:
                    self.__reportPurgedArchive(archiveSpecName)
                    self.__archiving.purgeStoredArchiveData(archiveSpecName)
                elif archiveSpecName in knownValidArchiveNames:
                    self.__componentUi.showWarning("Archive is not orphaned. Not purging.")
                    result = False
                else:
                    self.__componentUi.showInfo("Nothing to purge.")
            self.__componentUi.setProcessingArchSpec(None)

            if self.__actionUtils.configuration[Options.ALL]:
                for orphanedArchive in orphanedArchives:
                    self.__componentUi.setProcessingArchSpec(orphanedArchive)

                    # archives specified via name arguments were purged in the loop above so exclude them here
                    if orphanedArchive not in archiveSpecNamesSelectedByName:

                        self.__reportPurgedArchive(orphanedArchive)
                        self.__archiving.purgeStoredArchiveData(orphanedArchive)

                self.__componentUi.setProcessingArchSpec(None)
        except OSError as ex:
            self.__componentUi.showError(str.format("Purge failed: {}", ex.strerror))
            result = False

        return result



    def __reportPurgedArchive(self, processingArchSpec):
        if self.__componentUi.verbosity == VerbosityLevels.Verbose:
            self.__componentUi.showVerbose(str.format("Purging {}.", processingArchSpec))



