# __init__.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2014 Róbert Čerňanský



"""Component tests for getting info about configured archives."""



from .test_configured_archive_info import *



__all__ = test_configured_archive_info.__all__
