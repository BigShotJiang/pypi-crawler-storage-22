# __init__.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2014 Róbert Čerňanský



"""Component tests for getting info about stored archives."""



from .test_stored_archive_info import *



__all__ = test_stored_archive_info.__all__
