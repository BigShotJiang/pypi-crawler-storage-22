# archiving_application.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



from .archiving.actions.action_utils import ActionUtils
from .archiving.actions.create_action import CreateAction
from .archiving.actions.list_action import ListAction
from .archiving.actions.purge_action import PurgeAction



class ArchivingApplication:
    """Takes care of executing user actions - application main use cases.

    :param componentUi: Access to user interface.
    :type componentUi: :class:`.CmdlineUi`
    :param applicationContext: Application context.
    :type applicationContext: :class:`.ApplicationContext`
    :param serviceAccessor: Access to services.
    :type serviceAccessor: :class:`.IServiceAccessor`"""



    def __init__(self, componentUi, applicationContext, serviceAccessor):
        self.__actionUtils = ActionUtils(componentUi, applicationContext, serviceAccessor)



    def executeCreateAction(self, selectedArchiveSpecs) -> bool:
        """Executes create backup(s) action.

        Takes ``selectedArchiveSpecs`` and for each it creates a backup.  If ``selectedArchiveSpecs`` is empty or
        :attr:`.Options.ALL` is set to ``True`` then backups for all knows archives (typically all archive
        specification files in :attr:`.Options.ARCHIVE_SPECS_DIR` directory) plus those in ``selectedArchiveSpecs``
        are created.

        :param selectedArchiveSpecs: :term:`archive specification files <archive specification file>` for which backups
           shall be created.
        :type selectedArchiveSpecs: ``Sequence<ArchiveSpecInfo>``"""

        return CreateAction(self.__actionUtils, selectedArchiveSpecs).execute()



    def executeListAction(self, selectedArchiveSpecs) -> bool:
        """Lists information about :term:`selected <selected archive>` and :term:`orphaned <orphaned archive>` archives
        to standard output.

        Similarly to :meth:`executeCreateAction` archives in ``selectedArchiveSpecs`` are listed.  If it is empty or
        :attr:`.Options.ALL` is ``True`` then all archives plus selected are listed.  Orphaned archives are always
        listed.

        List of orphaned archives is obtained by following operation: from the list of
        :term:`stored archives <stored archive>` is subtracted the unique list of valid selected archives and
        valid :term:`configured archives <configured archive>`.

        Output has two possible formats depending on the :attr:`.Options.VERBOSE` option.

        :param selectedArchiveSpecs: :term:`archive specification files <archive specification file>` which shall be
           listed.
        :type selectedArchiveSpecs: ``Sequence<ArchiveSpecInfo>``"""

        return ListAction(self.__actionUtils, selectedArchiveSpecs).execute()



    def executePurgeAction(self, selectedArchiveSpecs) -> bool:
        """Removes all stored information about specified orphaned archives.

        If ``selectedArchiveSpecs`` is empty or :attr:`.Options.ALL` is ``True`` then all orphaned archives are
        processed.

        :param selectedArchiveSpecs: :term:`archive specification files <archive specification file>` which shall be
           purged.
        :type selectedArchiveSpecs: ``Sequence<ArchiveSpecInfo>``"""

        return PurgeAction(self.__actionUtils, selectedArchiveSpecs).execute()
