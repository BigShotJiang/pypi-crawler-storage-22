# __init__.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



"""Component tests for :term:`Application`."""



from .test_archiving_application import *



__all__ = test_archiving_application.__all__[:]
