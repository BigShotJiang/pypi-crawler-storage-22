# constants.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2022 Róbert Čerňanský



""":class:`Constants`."""



__all__ = ["Constants"]



# {{{ INCLUDES

from abc import ABCMeta, abstractmethod



# }}} INCLUDES



# {{{ CLASSES

class Constants(metaclass = ABCMeta):

    CONFIG_FILE_NAME = "aa.conf"



    @abstractmethod
    def __init__(self):
        pass

# }}} CLASSES
