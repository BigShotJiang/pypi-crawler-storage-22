# iservice.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



__all__ = ["IService"]



from abc import *



class IService(metaclass = ABCMeta):
    """Interface for component's services.

    See also: :class:`.ServiceAccessor`.

    :param workDir: Path to a writable directory which shall be used as a persistent storage."""

    @abstractmethod
    def __init__(self, wokDir: str = None):
        pass
