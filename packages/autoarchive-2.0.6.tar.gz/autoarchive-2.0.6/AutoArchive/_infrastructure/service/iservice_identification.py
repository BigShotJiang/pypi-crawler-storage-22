# iservice_identification.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



""":class:`IServiceIdentification` interface."""



__all__ = ["IServiceIdentification"]



from abc import *



class IServiceIdentification(metaclass = ABCMeta):
    """Identifies a service.

    .. Note:: Implementations should be static classes."""



    @property
    @abstractmethod
    def interface(self) -> type:
        """Gets interface type of the service.

        :rtype: ``type{``object``\ ``}``"""
