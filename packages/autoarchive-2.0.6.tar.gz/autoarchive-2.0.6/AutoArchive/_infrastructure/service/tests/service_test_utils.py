# service_test_utils.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



__all__ = ["ServiceTestUtils"]



from abc import ABCMeta, abstractmethod
from mock import Mock
from .._service_accessor import ServiceAccessor



class ServiceTestUtils(metaclass = ABCMeta):
    """Utility methods for service framework tests."""

    @abstractmethod
    def __init__(self):
        pass



    @staticmethod
    def createServiceAccessorMock(serviceStorage):
        """Creates mock of the :class:`.ServiceAccessor`.

        The mock is set up so that registering and getting services is functional.

        :param serviceStorage: Object to store registered services.
        :type serviceStorage: ``Dictionary``"""

        def getOrCreateServiceSideEffect(serviceIdentification, providerIdentification):
            providers = serviceStorage[serviceIdentification]
            return [p[0]() for p in providers if p[1] == providerIdentification][0]



        def getOrCreateServicesSideEffect(serviceIdentification):
            return [p[0]() for p in serviceStorage[serviceIdentification]]



        def registerServiceSideEffect(serviceIdentification, providerClass, providerIdentification = None):
            if serviceIdentification not in serviceStorage:
                serviceStorage[serviceIdentification] = []
            serviceStorage[serviceIdentification].append((providerClass, providerIdentification))



        serviceAccessorMock = Mock(spec_set = ServiceAccessor)
        serviceAccessorMock.getOrCreateService.side_effect = getOrCreateServiceSideEffect
        serviceAccessorMock.getOrCreateServices.side_effect = getOrCreateServicesSideEffect
        serviceAccessorMock.registerService.side_effect = registerServiceSideEffect

        return serviceAccessorMock
