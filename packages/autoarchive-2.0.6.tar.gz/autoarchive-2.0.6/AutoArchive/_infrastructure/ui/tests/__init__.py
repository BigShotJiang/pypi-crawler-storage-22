# __init__.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2014 Róbert Čerňanský



"""Component tests for :term:`UI framework`."""



from .test_multi_field_line import *



__all__ = test_multi_field_line.__all__[:]
