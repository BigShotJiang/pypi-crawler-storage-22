# constants.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2022 Róbert Čerňanský



__all__ = ["Constants"]



import os
from abc import ABCMeta, abstractmethod



class Constants(metaclass = ABCMeta):
    "Defines various “global” constants."

    #: Debugging support.
    DEBUG = os.environ.get("AADEBUG")



    @abstractmethod
    def __init__(self):
        pass
