# error_handling.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2022 Róbert Čerňanský



__all__ = ["ErrorHandling"]



import sys
from abc import ABCMeta, abstractmethod



class ErrorHandling(metaclass = ABCMeta):

    @abstractmethod
    def __init__(self):
        pass



    @classmethod
    def printWarning(cls, msg, appName = None):
        "Prints ``msg`` as a warning to standard error."

        cls.__printToStdErr("Warning", msg, appName)



    @classmethod
    def printError(cls, msg, appName = None):
        "Prints ``msg`` as an error to standard error."

        cls.__printToStdErr("Error", msg, appName)



    @classmethod
    def fatalExit(cls, msg, appName = None):
        "Prints ``msg`` to standard error and exits with exit code 2."

        cls.__printToStdErr("Fatal Error", msg, appName)
        sys.exit(2)



    @staticmethod
    def __printToStdErr(attentionString, msg, appName = None):
        if appName is None:
            appName = sys.argv[0]
        sys.stderr.write(str.format("{}: {}! {}\n", appName, attentionString, msg))
