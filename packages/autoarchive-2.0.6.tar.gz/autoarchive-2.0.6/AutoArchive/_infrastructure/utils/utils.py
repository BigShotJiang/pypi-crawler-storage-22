# utils.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



__all__ = ["Utils"]



# {{{ INCLUDES

import os
import platform
from abc import *
from functools import wraps

# }}} INCLUDES



# {{{ CLASSES

class Utils(metaclass = ABCMeta):
    "Various utility methods."

    @abstractmethod
    def __init__(self):
        pass



    @staticmethod
    def uniq(decorated):
        "Decorator that filters out duplicate elements from an iterable returned by decorated function."

        @wraps(decorated)
        def wrapper(*args, **kwargs):
            seen = set()
            for item in decorated(*args, **kwargs):
                if item not in seen:
                    seen.add(item)
                    yield item

        return wrapper



    @staticmethod
    def effectiveAccess(path, mode):
        return os.access(path, mode, effective_ids = os.access in os.supports_effective_ids)

# }}} CLASSES
