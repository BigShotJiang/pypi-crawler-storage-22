# archiver_service_component.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



from AutoArchive._infrastructure.service import IServiceComponent
from AutoArchive._infrastructure.service._service_accessor import ServiceAccessor
from . import ArchiverServiceProviderIDs, ArchiverServiceIdentification
from ._external_tar_archiver_provider import _ExternalTarArchiverProvider
from ._internal_tar_archiver_provider import _InternalTarArchiverProvider



class ArchiverServiceComponent(IServiceComponent):
    """Service component for archiver services.

    Registers service identified by :class:`.ArchiverServiceIdentification` with two providers identified
    via ArchiverServiceProviderIDs."""

    def __init__(self, applicationContext, serviceAccessor: ServiceAccessor):
        self.__serviceAccessor = serviceAccessor

        serviceAccessor.registerService(ArchiverServiceIdentification, _InternalTarArchiverProvider,
                                        ArchiverServiceProviderIDs.TarInternal)
        serviceAccessor.registerService(ArchiverServiceIdentification, _ExternalTarArchiverProvider,
                                        ArchiverServiceProviderIDs.TarExternal)



    def destroyServices(self):
        "See: :meth:`IServiceComponent.destroyServices()`"

        self.__serviceAccessor.unregisterService(ArchiverServiceIdentification)
