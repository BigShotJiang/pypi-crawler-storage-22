# archiver_service_identification.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2023 Róbert Čerňanský



""":class:`ArchiverServiceIdentification` interface."""



__all__ = ["ArchiverServiceIdentification"]



from AutoArchive._infrastructure.py_additions import staticproperty
from AutoArchive._infrastructure.service import IServiceIdentification
from .tar_archiver_provider_base import TarArchiverProviderBase



class ArchiverServiceIdentification(IServiceIdentification):
    """Identifies the Archiver service.

    Parameters required by the service upon creation:

       ``workDir``: Path to a writable directory.  The service will use it as persistent storage (type ``str``)."""

    @staticproperty
    def interface() -> type[TarArchiverProviderBase]:
        """Gets interface type of the Archiver service.

        :rtype: ``type{``TarArchiverProviderBase``\ ``}``"""

        return TarArchiverProviderBase
