# __init__.py
#
# Project: AutoArchive
# License: GNU GPLv3
#
# Copyright (C) 2003 - 2014 Róbert Čerňanský



"""Service for executing external commands."""



from .external_command_executor_service_identification import *



__all__ = external_command_executor_service_identification.__all__[:]
