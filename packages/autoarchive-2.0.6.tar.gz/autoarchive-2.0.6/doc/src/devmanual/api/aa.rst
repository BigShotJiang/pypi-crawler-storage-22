.. aa.rst
.. 
.. Project: AutoArchive
.. License: GNU GPLv3
.. 
.. Copyright (C) 2003 - 2012 Róbert Čerňanský



.. A section for the aa script.



aa
==

.. module:: aa

Startup script for AutoArchive.

.. note:: Symbolic link ``autoarchive`` pointing to this startup script is also available.
