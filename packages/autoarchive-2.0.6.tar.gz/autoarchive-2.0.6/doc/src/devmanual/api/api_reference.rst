.. api_reference.rst
.. 
.. Project: AutoArchive
.. License: GNU GPLv3
.. 
.. Copyright (C) 2003 - 2012 Róbert Čerňanský



.. API Reference section



*************
API Reference
*************



Packages
========

.. toctree::
   :maxdepth: 1

   autoarchive



Scripts
=======

.. toctree::
   :maxdepth: 1

   aa
