.. application.action.rst
..
.. Project: AutoArchive
.. License: GNU GPLv3
..
.. Copyright (C) 2003 - 2025 Róbert Čerňanský



.. A section for the AutoArchive._application._action package.



AutoArchive._application._action
================================

.. automodule:: AutoArchive._application._action
   :no-members:



Modules
-------

action_result
^^^^^^^^^^^^^

.. automodule:: AutoArchive._application._action.action_result



action
^^^^^^

.. automodule:: AutoArchive._application._action.action
