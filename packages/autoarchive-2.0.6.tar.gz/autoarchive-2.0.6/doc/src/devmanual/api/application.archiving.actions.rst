.. application.archiving.actions.rst
..
.. Project: AutoArchive
.. License: GNU GPLv3
..
.. Copyright (C) 2003 - 2025 Róbert Čerňanský



.. A section for the AutoArchive._application.archiving.actions package.



AutoArchive._application.archiving.actions
==========================================

.. automodule:: AutoArchive._application.archiving.actions
   :no-members:



Modules
-------

action_utils
^^^^^^^^^^^^

.. automodule:: AutoArchive._application.archiving.actions.action_utils



create_action
^^^^^^^^^^^^^

.. automodule:: AutoArchive._application.archiving.actions.create_action



list_action
^^^^^^^^^^^

.. automodule:: AutoArchive._application.archiving.actions.list_action



purge_action
^^^^^^^^^^^^

.. automodule:: AutoArchive._application.archiving.actions.purge_action
