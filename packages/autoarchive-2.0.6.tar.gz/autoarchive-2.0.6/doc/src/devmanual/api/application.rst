.. application.rst
..
.. Project: AutoArchive
.. License: GNU GPLv3
..
.. Copyright (C) 2003 - 2025 Róbert Čerňanský



.. A section for the AutoArchive._application package.



AutoArchive._application
========================

.. automodule:: AutoArchive._application
   :no-members:



Sub-Packages
------------

.. toctree::
   :maxdepth: 1

   application.archiving
   application.action



Modules
-------

archiving_application
^^^^^^^^^^^^^^^^^^^^^

.. automodule:: AutoArchive._application.archiving_application
