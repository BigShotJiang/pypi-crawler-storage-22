.. infrastructure.utils.interval.rst
..
.. Project: AutoArchive
.. License: GNU GPLv3
..
.. Copyright (C) 2003 - 2021 Róbert Čerňanský



.. A section for the AutoArchive._infrastructure.utils.interval package.



AutoArchive._infrastructure.utils.interval
==========================================

.. automodule:: AutoArchive._infrastructure.utils.interval
   :no-members:



Modules
-------

interval
^^^^^^^^

.. automodule:: AutoArchive._infrastructure.utils.interval.interval



interval_element
^^^^^^^^^^^^^^^^

.. automodule:: AutoArchive._infrastructure.utils.interval.interval_element
