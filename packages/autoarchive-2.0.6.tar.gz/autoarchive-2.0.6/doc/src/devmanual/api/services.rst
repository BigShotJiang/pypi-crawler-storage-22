.. services.rst
..
.. Project: AutoArchive
.. License: GNU GPLv3
..
.. Copyright (C) 2003 - 2015 Róbert Čerňanský



.. A section for the AutoArchive._services package.



AutoArchive._services
=====================

.. automodule:: AutoArchive._services
   :no-members:



Sub-Packages
------------

.. toctree::
   :maxdepth: 1

   services.archiver
   services.external_command_executor
