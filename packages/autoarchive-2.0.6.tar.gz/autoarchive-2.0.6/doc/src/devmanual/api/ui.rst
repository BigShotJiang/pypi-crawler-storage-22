.. ui.rst
.. 
.. Project: AutoArchive
.. License: GNU GPLv3
.. 
.. Copyright (C) 2003 - 2015 Róbert Čerňanský



.. A section for the AutoArchive._ui package.



AutoArchive._ui
===============

.. automodule:: AutoArchive._ui
   :no-members:



Sub-Packages
------------

.. toctree::
   :maxdepth: 1

   ui.cmdline
