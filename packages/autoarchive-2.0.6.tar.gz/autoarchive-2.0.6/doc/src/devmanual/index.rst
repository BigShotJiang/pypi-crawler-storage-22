.. index.rst
.. 
.. Project: AutoArchive
.. License: GNU GPLv3
.. 
.. Copyright (C) 2003 - 2012 Róbert Čerňanský



.. AutoArchive developer manual master file.



############################
AutoArchive Developer Manual
############################

Contents:

.. toctree::
   :maxdepth: 3

   api/api_reference

   glossary



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
* :ref:`glossary`
