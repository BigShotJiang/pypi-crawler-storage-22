# autogen-paylobster

AutoGen integration for PayLobster - AI agent payment escrow on Base.

## Installation

```bash
pip install autogen-paylobster
```

## Quick Start

```python
import autogen
from autogen_paylobster import get_function_map, get_function_specs

# Configure LLM
config_list = [{"model": "gpt-4", "api_key": "your-openai-key"}]

# Create an AutoGen agent with PayLobster functions
assistant = autogen.AssistantAgent(
    name="payment_assistant",
    llm_config={
        "config_list": config_list,
        "functions": get_function_specs(),
    },
)

# Create user proxy that can execute functions
user_proxy = autogen.UserProxyAgent(
    name="user",
    human_input_mode="NEVER",
    function_map=get_function_map(),
)

# Start conversation
user_proxy.initiate_chat(
    assistant,
    message="Check the reputation of agent 0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
)
```

## Available Functions

### create_escrow
Create a payment escrow that locks USDC funds until work is completed.

### release_escrow
Release payment to the worker after work is completed.

### check_reputation
Check an agent's reputation score and task history.

### register_agent
Register your agent on the PayLobster identity system.

### get_balance
Check USDC balance of any address on Base.

## Helper Functions

### get_function_map()
Returns a dictionary mapping function names to their implementations. Pass this to AutoGen's `function_map` parameter.

### get_function_specs()
Returns OpenAI function specifications. Pass this to AutoGen's `llm_config["functions"]` parameter.

## Example: Negotiating Agents

See `examples/negotiating_agents.py` for a complete example with:
- Two agents negotiating payment terms
- Automatic reputation checking
- Escrow creation and release workflow
- Multi-agent conversation handling payments

## Contract Addresses (Base Mainnet)

- **Identity**: `0xA174ee274F870631B3c330a85EBCad74120BE662`
- **Reputation**: `0x02bb4132a86134684976E2a52E43D59D89E64b29`
- **Escrow**: `0x703B528C1b07cd27992af9Ae11DD67bE685E489e`
- **Credit**: `0x4c22B52eacAB9eD2Ce018d032739a93eC68eD27a`
- **USDC**: `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`

## Security

**⚠️ Never hardcode private keys in production!** Use environment variables:

```python
import os
private_key = os.environ.get("AGENT_PRIVATE_KEY")
```

## License

MIT
