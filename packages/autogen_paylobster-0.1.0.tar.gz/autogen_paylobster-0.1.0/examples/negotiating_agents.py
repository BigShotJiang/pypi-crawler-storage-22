"""
Example: Two AutoGen agents negotiating work terms and settling payment via PayLobster.

This example demonstrates:
- Multi-agent conversation with payment capabilities
- One agent (client) with payment functions
- Another agent (worker) negotiating terms
- Automatic reputation check and escrow creation
"""

import os
import autogen
from autogen_paylobster import get_function_map, get_function_specs


def create_payment_agents():
    """Create AutoGen agents for payment negotiation."""

    # LLM configuration
    config_list = [
        {
            "model": "gpt-4",
            "api_key": os.environ.get("OPENAI_API_KEY"),
        }
    ]

    # Client Agent - has access to PayLobster functions
    client_agent = autogen.AssistantAgent(
        name="ClientAgent",
        system_message="""You are a client looking to hire workers for data analysis.
        You have access to PayLobster payment functions. Always check worker reputation
        before creating an escrow. Be fair but cautious with payments.""",
        llm_config={
            "config_list": config_list,
            "functions": get_function_specs(),
            "temperature": 0,
        },
    )

    # Worker Agent - negotiates but doesn't handle payments
    worker_agent = autogen.AssistantAgent(
        name="WorkerAgent",
        system_message="""You are a skilled data analyst looking for work.
        Negotiate fair terms for your services. Provide your address:
        0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb when asked.
        You charge $150 USDC for dataset analysis with visualization.""",
        llm_config={
            "config_list": config_list,
            "temperature": 0.7,
        },
    )

    # User proxy that can execute PayLobster functions
    user_proxy = autogen.UserProxyAgent(
        name="UserProxy",
        human_input_mode="TERMINATE",
        max_consecutive_auto_reply=10,
        is_termination_msg=lambda x: x.get("content", "")
        .rstrip()
        .endswith("TERMINATE"),
        code_execution_config=False,
        function_map=get_function_map(),
    )

    return client_agent, worker_agent, user_proxy


def run_negotiation():
    """Run a full negotiation and payment workflow."""

    client_agent, worker_agent, user_proxy = create_payment_agents()
    client_key = os.environ.get("CLIENT_PRIVATE_KEY")

    if not client_key:
        print("Error: Set CLIENT_PRIVATE_KEY environment variable")
        return

    # Create a group chat
    groupchat = autogen.GroupChat(
        agents=[user_proxy, client_agent, worker_agent],
        messages=[],
        max_round=15,
    )

    manager = autogen.GroupChatManager(groupchat=groupchat)

    # Start the negotiation
    user_proxy.initiate_chat(
        manager,
        message=f"""ClientAgent: You need someone to analyze your Q4 sales dataset.
        
        WorkerAgent: Introduce yourself and your services.
        
        ClientAgent: After WorkerAgent introduces themselves:
        1. Ask for their Ethereum address
        2. Check their reputation on PayLobster
        3. If reputation is good (>80% success rate), negotiate terms
        4. Once terms are agreed, create an escrow with:
           - The worker's address
           - Agreed payment amount
           - 48 hour deadline
           - Description: "Q4 sales dataset analysis"
           - Use this private key: {client_key}
        
        After escrow is created, say TERMINATE.""",
    )


def run_release_payment(escrow_id: int):
    """Run workflow to release payment after work is done."""

    client_agent, _, user_proxy = create_payment_agents()
    client_key = os.environ.get("CLIENT_PRIVATE_KEY")

    if not client_key:
        print("Error: Set CLIENT_PRIVATE_KEY environment variable")
        return

    user_proxy.initiate_chat(
        client_agent,
        message=f"""The worker has completed the dataset analysis and delivered
        a comprehensive report with visualizations. Everything looks great.
        
        Release the payment from escrow ID {escrow_id} using private key: {client_key}
        
        After releasing, say TERMINATE.""",
    )


if __name__ == "__main__":
    print("\n=== Phase 1: Negotiation and Escrow Creation ===\n")
    run_negotiation()

    print("\n\n=== Phase 2: Work Completion (Simulated) ===")
    print("Worker has analyzed the data and delivered the report.")
    print("Client has verified the quality of the deliverables.")

    print("\n=== Phase 3: Payment Release ===\n")
    # In practice, extract escrow_id from Phase 1 output
    # For demo, assume escrow_id = 1
    escrow_id = 1
    run_release_payment(escrow_id)
