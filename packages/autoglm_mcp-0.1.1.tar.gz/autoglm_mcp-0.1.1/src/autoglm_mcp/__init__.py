"""AutoGLM MCP Server - Android screen analysis via MCP protocol"""

from .server import main

__version__ = "0.1.1"
__all__ = ["main"]
