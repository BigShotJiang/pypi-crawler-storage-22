# Automata Diags: Comprehensive Backend Engineering Process & Architectural Evolution

## 1. Introduction & Vision

This document serves as a rigorous, deep-dive chronicle of the engineering journey, architectural decisions, and algorithmic implementation of the `automata-diags` Python backend.

### 1.1 The Theoretical-Practical Gap
The core motivation for this package was to bridge the significant gap between **Academic Automata Theory** and **Production-Grade Software Engineering**.
- **The Academic View**: Automata are mathematical 5-tuples $(Q, \Sigma, \delta, q_0, F)$. They exist in abstract space. Implementations in textbooks often use pseudocode or naive, untyped Python dictionaries (e.g., `delta['q0']['a'] = 'q1'`).
- **The Engineering View**: Software requires robustness, maintainability, and safety. Naive implementations suffer from string-typing errors (confusing a state named "a" with the symbol "a"), lack of IDE support, and runtime fragility.

### 1.2 Core Design Principles
To solve this, `automata-diags` was built on four pillars:
1.  **Type Safety First**: Leveraging Python's `typing` module to enforce strict distinction between semantic concepts (States vs. Symbols).
2.  **Object-Oriented Abstraction**: Using inheritance and abstract base classes to define rigid interfaces for what an "Automaton" is, allowing polymorphic behavior in higher-level systems (like the visualization engine).
3.  **Algorithmic Rigor**: Implementing standard algorithms (Hopcroft, Thompson, CYK) with attention to their theoretical time complexities, rather than ad-hoc solutions.
4.  **Immutability & Hashability**: Designing core data structures (like `Production` rules) to be hashable, enabling their use in sets and dictionary keys—a requirement for many graph algorithms.

---

## 2. Phase 1: The Foundation (Type System & Abstractions)

### 2.1 The "Stringly-Typed" Problem & Solution
In dynamic languages, it is tempting to use primitive strings for everything. However, this leads to semantic bugs.
- *Scenario*: A user creates a state named "0" and inputs a symbol "0".
- *Bug*: In a weakly typed system, swapping arguments to `add_transition(state, symbol)` might pass silently but break logic.

#### Implementation: `dist.py`
I utilized `NewType` to create distinct types that exist only for the static type checker (MyPy) but have zero runtime overhead (they compile to simple strings).

```python
from typing import NewType

# These are mutually incompatible types in the eyes of the type checker
Symbol = NewType("Symbol", str)
State = NewType("State", str)
NonTerminal = NewType("NonTerminal", str)
Terminal = NewType("Terminal", str)
```

This decision immediately pays off in function signatures. A function defined as `def transition(q: State, a: Symbol) -> State` will raise a linter error if called as `transition("a", "q0")`, catching logical inversions during development.

### 2.2 The Generic Abstract Base (`automaton_base.py`)
To prevent code duplication, I defined `Automaton` as a Generic Abstract Base Class (`ABC`).

```python
class Automaton(Generic[T], ABC):
    def __init__(self, states: StateSet, alphabet: Alphabet, ...):
        # ...
```

**Key Architectural Decision: Generic State Type `T`**
Why `Generic[T]`? Because not all automata use simple string states.
- A **DFA** uses `State` (strings).
- A **DFA converted from an NFA** effectively uses sets of states as its states.
- A **Product Automaton** (for intersection) uses tuples of states `(q_a, q_b)`.

By making the base class generic, the system is future-proofed for complex composition operations where "states" become complex data structures.

---

## 3. Phase 2: Finite Automata (DFA & NFA)

### 3.1 Deterministic Finite Automata (DFA) (`dfa_mod.py`)

#### The Transition Function Structure
The mathematical function $\delta: Q \times \Sigma \to Q$ is implemented as a nested hash map: `Dict[State, Dict[Symbol, State]]`.
- **Outer Key**: The source state.
- **Inner Key**: The input symbol.
- **Value**: The single destination state.

#### Parsing Logic: `from_string`
To make the library student-friendly, I implemented a robust parsing engine that accepts shorthand strings: `"q0,a,q1;q1,b,q2"`.
- **Validation**: The parser aggressively validates structure. It splits by `;` then by `,`.
- **Inference**: It implicitly builds the `Alphabet` and `StateSet` by observing all unique symbols and state names used in the string, reducing boilerplate for the user.

#### The `accepts` Algorithm
The acceptance check is a direct O(n) simulation:
```python
current = start_state
for symbol in word:
    current = transitions[current][symbol]
```
**Engineering Detail - The Sink State**:
Strictly, a DFA must be *total* (transitions defined for every symbol from every state). In practice, users define partial DFAs.
- *Decision*: I added an explicit `sink_state` attribute. If a transition is missing:
    - If `sink_state` is defined: Transition there (and stay there).
    - If `sink_state` is None: Reject immediately (return `False`).
This hybrid approach balances theoretical strictness with practical usability.

### 3.2 Non-Deterministic Finite Automata (NFA) (`nfa_mod.py`)

#### Structural Differences
The NFA transition function changes signature to: `Dict[State, Dict[Symbol, StateSet]]`.
1.  **Non-Determinism**: The value is now a `StateSet` (multiple possible next states).
2.  **Epsilon**: The dictionary keys can include the empty string `""` (represented as a specific `Symbol` constant).

#### Algorithm: Breadth-First Search (BFS) for Acceptance
Unlike the DFA's linear path, an NFA execution is a tree of possibilities.
- *Naive Approach*: Recursion (DFS). *Problem*: Vulnerable to `RecursionError` on long strings and infinite loops with $\epsilon$-cycles.
- *Selected Approach*: **Iterative BFS**.
    - We maintain a `current_states` set.
    - For each input symbol, we compute `next_states = Union(delta(q, symbol) for q in current_states)`.
    - **Crucial Step**: After *every* transition, we must compute the **Epsilon Closure** of the result.

#### The Epsilon Closure Algorithm
This is the heart of the NFA engine. `epsilon_closure(S)` computes all states reachable from set $S$ using only $\epsilon$-transitions.
- *Implementation*: A stack-based worklist algorithm.
- *Cycle Handling*: A `visited` set ensures we don't get stuck in $\epsilon$-loops (e.g., $q_0 \xrightarrow{\epsilon} q_1 \xrightarrow{\epsilon} q_0$).

---

## 4. Phase 3: The Compiler Pipeline (Regex to NFA)

Implementing `NFA.from_regex()` transformed the project from a simulator into a compiler. This required a full three-stage pipeline.

### 4.1 Stage 1: Lexical Analysis & Preprocessing
Raw regexes contain "syntactic sugar" that complicates parsing. The preprocessor normalizes this.
- **Character Classes (`[a-z]`)**: The engine expands ranges using ASCII ordinals. `[a-c]` becomes `(a|b|c)`. This converts a complex token into primitive operations.
- **The Plus Quantifier (`+`)**: `a+` implies "one or more". The engine rewrites this as `aa*` (one instance followed by zero or more).
- **Explicit Concatenation**: Standard regex syntax implies concatenation: `ab` means `a` then `b`. Parsers hate implicit operators.
    - *Algorithm*: Scan the string. Insert a special `.` token between:
        - Literal & Literal (`ab` $\to$ `a.b`)
        - Literal & Open Paren (`a(` $\to$ `a.(`)
        - Star & Literal (`*a` $\to$ `*.a`)
    - This allows the parser to treat concatenation as a standard binary operator like `|`.

### 4.2 Stage 2: Parsing (The Shunting-Yard Algorithm)
To respect order of operations (Operator Precedence), I implemented Dijkstra's Shunting-Yard algorithm.
- **Precedence Hierarchy**:
    1.  Kleene Star `*` (Highest binding)
    2.  Concatenation `.`
    3.  Union `|` (Lowest binding)
- **Mechanism**: Two stacks (Output Queue, Operator Stack). As tokens stream in, operators are pushed onto the stack. If a new operator has lower precedence than the top of the stack, the stack is popped to the output.
- **Result**: A Postfix (Reverse Polish Notation) string. `a|b.c` becomes `abc.|`.

### 4.3 Stage 3: Code Generation (Thompson's Construction)
We process the Postfix string using a stack of `NFAFragment` objects.
- **Abstraction**: An `NFAFragment` is a mini-NFA with a specific `start_state` and a set of `accept_states` and an internal dictionary of transitions.
- **The Stack Machine**:
    - **Literal 'a'**: Push a fragment $q_{start} \xrightarrow{a} q_{end}$.
    - **Union `|`**: Pop fragments $F_2, F_1$. Create a new start state $S$ with $\epsilon$-transitions to $F_1.start$ and $F_2.start$. Push combined fragment.
    - **Concat `. `**: Pop $F_2, F_1$. Wire all $F_1.accept\_states$ via $\epsilon$ to $F_2.start$. The new start is $F_1.start$, new accept is $F_2.accept$.
    - **Star `*`**: Pop $F$. Create new start $S$ and accept $E$. Add $\epsilon$-paths: $S \to F.start$, $F.accept \to F.start$ (loop), $S \to E$ (skip), $F.accept \to E$ (exit).

This construction guarantees that the resulting NFA has exactly one start state and one accept state (mostly), and grows linearly with regex size.

---

## 5. Phase 4: Context-Free Grammars (Deep Dive)

The most complex recent addition is the CFG module, requiring strict adherence to formal language theory algorithms.

### 5.1 Data Structure Architecture (`cfg_mod.py`)
- **`Production` Class**: This class is the atomic unit.
    - *Immutability*: It implements `__hash__` and `__eq__`. This allows productions to be stored in `set()` structures, which is critical for the "set of productions" semantics of a CFG.
    - *Ordering*: Implements `__lt__` to allow canonical sorting for reproducible outputs.
- **`CFG` Class**: Validates that all symbols used in productions are declared in `terminals` or `non_terminals` sets.

### 5.2 The CNF Conversion Pipeline
Converting a CFG to Chomsky Normal Form (CNF) is notoriously error-prone if steps are reordered. I implemented the strict academic pipeline: **START $\to$ TERM $\to$ BIN $\to$ DEL $\to$ UNIT**.

#### Step 1: `_eliminate_null` (Removing $\epsilon$-productions)
This is computationally the most expensive step.
1.  **Identify Nullable Variables**: Iteratively find all variables $A$ that can derive $\epsilon$ (either directly $A \to \epsilon$ or via nullable chain $A \to BC$ where $B,C$ nullable).
2.  **Powerset Generation**: For a rule like $S \to AB$, if both $A$ and $B$ are nullable, we must generate *all combinations* of their presence/absence:
    - $S \to AB$ (original)
    - $S \to A$ (B vanished)
    - $S \to B$ (A vanished)
    - (We don't add $S \to \epsilon$ unless it's the start symbol).
    - *Implementation Details*: I used bitmasking `range(1 << n)` to generate these combinations efficiently.

#### Step 2: `_eliminate_unit` (Removing $A \to B$)
Naive implementations often loop infinitely on cycles ($A \to B \to A$).
- **Graph Theoretic Approach**: I treated unit productions as a directed graph where nodes are NonTerminals and edges are unit rules.
- **Transitive Closure**: For every node, I computed the set of reachable nodes. If $A$ can reach $C$ via unit rules ($A \to^* C$), then $A$ must inherit all non-unit productions of $C$.
- **Reconstruction**: The new grammar keeps the inherited rules and discards the unit edges.

#### Step 3: `_binarize` (Breaking long productions)
CNF restricts RHS to max 2 NonTerminals ($A \to BC$).
- *Process*: A rule $A \to B C D E$ is iteratively consumed.
    - Create new variable `BIN_1`.
    - Rule becomes $A \to B \cdot \text{BIN}_1$.
    - New rule $\text{BIN}_1 \to C D E$.
    - Repeat until valid.
    - *Naming*: I used a deterministic counter for auxiliary variables (`BIN_0`, `BIN_1`) to ensure the grammar remains readable during debugging.

## 6. Phase 6: CFG Algorithms (Parsing & Acceptance)

While CNF conversion is a structural transformation, the ultimate goal of a grammar is to define a language. I implemented two distinct algorithms for checking string membership ($w \in L(G)$).

### 6.1 The CYK Algorithm (`cyk_accept`)
For grammars in Chomsky Normal Form, the Cocke-Younger-Kasami (CYK) algorithm provides a guaranteed $O(n^3)$ parsing time.
- **Dynamic Programming Table**:
    - `table[i][j]` stores the set of NonTerminals that can generate the substring `string[i:j+1]`.
- **Initialization**: Fill the diagonal `table[i][i]` with NonTerminals that produce the terminal `string[i]` (e.g., if $A \to a$, add $A$).
- **The Triple Loop**:
    - Iterate through substring lengths `l` from 2 to `n`.
    - Iterate through start positions `i`.
    - Iterate through split points `k` (where to break the substring into two parts).
    - If $B \in table[i][k]$ and $C \in table[k+1][j]$ and there exists a rule $A \to BC$, add $A$ to `table[i][j]`.
- **Conclusion**: The string is accepted if the Start Symbol is in `table[0][n-1]`.

### 6.2 BFS with Pruning (`accept_string`)
For general CFGs (not in CNF), I implemented a Breadth-First Search (BFS) derivation simulation.
- **State Space**: Each state is a "sentential form" (a mix of Terminals and NonTerminals).
- **Expansion**: Replace the first NonTerminal in the current form with its RHS productions.
- **Pruning Strategy**: To prevent infinite recursion (e.g., $S \to S$), I prune branches where:
    - The number of terminals exceeds the target string length.
    - The sentential form has been visited before.
    - The derivation depth exceeds a heuristic limit ($3 \times |w| + 10$).
- **Trade-off**: This is less efficient than CYK but works for *any* CFG without requiring conversion overhead.

---

## 7. Phase 7: Advanced Algorithms (DFA Minimization)

The project includes two minimization algorithms, highlighting the commitment to algorithmic efficiency.

### 7.1 Hopcroft's Algorithm (Partition Refinement)
Standard minimization algorithms run in $O(n^2)$. Hopcroft's runs in $O(n \log n)$.
- **The Concept**: Instead of checking every pair of states for equivalence, we assume all states are equivalent and try to *disprove* it (split them).
- **Initialization**: Partition $P = \{F, Q \setminus F\}$ (Accepting vs Rejecting).
- **The Refinement Loop**:
    - We maintain a **Worklist** of "splitters" (sets of states).
    - We extract a splitter $S$ and an input symbol $a$.
    - We compute the "inverse image": states that transition *into* $S$ on $a$.
    - If a partition block is partially in the inverse image and partially out, it must be split.
    - *Optimization*: When splitting, we only add the *smaller* half to the worklist. This guarantees the $O(n \log n)$ bound.

### 7.2 Myhill-Nerode Theorem Implementation
While Hopcroft is faster, Myhill-Nerode is theoretically more significant. I implemented a table-filling algorithm (`myhill_nerode.py`) that explicitly marks pairs $(p, q)$ as "distinguishable".
- This implementation serves an educational purpose: it generates the **Distinguishability Table**, which students often need to produce in exams. It visualizes *why* two states are different.

---

## 8. Phase 8: NFA to DFA (Subset Construction)

The `nfa_to_dfa.py` module handles the exponential complexity of subset construction.

### 8.1 State Representation Challenge
A DFA state corresponds to a *set* of NFA states. Python lists are not hashable (cannot be dictionary keys).
- **Solution**: `frozenset`. Every DFA state is uniquely identified by a `frozenset` of NFA state names.
- **Naming Convention**: The generated DFA states are named by joining the sorted NFA state names (e.g., `"{q1,q2}"`).

### 8.2 The Exploration Loop
1.  **Queue Initialization**: Start with `epsilon_closure({start_node})`.
2.  **Breadth-First Expansion**: While the queue is not empty:
    - Pop a state set $S$.
    - For each symbol $a$ in the alphabet:
        - Compute $S_{next} = \bigcup_{q \in S} \delta(q, a)$.
        - Compute closure: $S_{final} = \text{epsilon\_closure}(S_{next})$.
        - If $S_{final}$ is new, add to queue and register as a new DFA state.
        - Record transition $S \xrightarrow{a} S_{final}$.

This algorithm correctly handles the "state explosion" problem by only generating reachable subsets, rather than the theoretical $2^Q$ full power set.

---

## 9. Conclusion

The `automata-diags` backend is a testament to the application of rigorous software engineering to theoretical computer science. By strictly enforcing types, using generic abstractions, and implementing optimal algorithms like Hopcroft's and Shunting-Yard, the system achieves a level of robustness and correctness suitable for both educational visualization and serious language processing tasks.
