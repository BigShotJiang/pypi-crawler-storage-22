# Automata Diags: Frontend Engineering Process & Architectural Evolution

## 1. Introduction & Vision

This document details the engineering journey and architectural decisions behind the **Automata Diags Frontend**, a React-based interactive learning environment for automata theory.

### 1.1 The Challenge
The goal was to create a web application that visualizes complex theoretical concepts (DFAs, NFAs, CFGs, PDAs, TMs) while maintaining:
-   **Interactivity**: Real-time simulation and editing.
-   **Performance**: Smooth handling of graph rendering and state updates.
-   **Educational Value**: Seamless integration of tutorials and hands-on challenges.
-   **Usability**: A clean, modern UI that abstracts away the complexity of the underlying math.

### 1.2 Tech Stack
-   **React 19**: Leveraging functional components, hooks (`useState`, `useEffect`, `useCallback`), and the latest React patterns.
-   **ReactFlow**: For the heavy lifting of graph visualization (nodes, edges, layout).
-   **Framer Motion**: For smooth animations and transitions.
-   **Lucide React**: For consistent and modern iconography.
-   **CSS Modules**: Modular styling for component isolation.

---

## 2. Phase 1: Core Architecture & Navigation

### 2.1 The Unified Layout (`Layout.jsx`)
Instead of a multi-page app, I chose a **Single Page Application (SPA)** model with a persistent layout wrapper.
-   **Sidebar Navigation**: A unified sidebar allows switching between automaton types (DFA, NFA, PDA, etc.) and the Tutorial Hub.
-   **State Lifting**: The `currentAutomaton` state is lifted to `App.js` to coordinate the main view and the sidebar.

### 2.2 Component Modularization
To manage the complexity of supporting 5 different machine types, I adopted a directory-based module structure:
```
components/
├── DFA_components/    # Dedicated logic for Deterministic Finite Automata
├── NFA_components/    # Non-deterministic specific logic
├── PDA_components/    # Stack-based automata logic
├── TM_components/     # Turing Machine logic (Tape visualization)
└── shared/            # Reusable UI components
```
This separation of concerns ensures that specific logic (like stack handling for PDA) doesn't pollute the generic graph components.

---

## 3. Phase 2: State Management & Simulation Logic

### 3.1 Custom Hooks for Logic (`useDFA.js`, `useTM.js`, etc.)
Instead of embedding logic directly into UI components, I extracted the state machine logic into custom React hooks. This is a crucial architectural decision for **testability** and **reusability**.

**Example: `useDFA.js`**
-   **State**: Manages `states`, `alphabet`, `transitions`, `startState`, `acceptStates`.
-   **Operations**: Provides methods like `addState`, `updateTransition`, `deleteState`.
-   **History Management**: Implements `undo`/`redo` functionality directly within the hook by maintaining a history stack of the entire machine state.

```javascript
// Architecture Pattern: Logic/View Separation
const { dfa, addState, undo } = useDFA(initialConfig); // Logic Layer
return <DFAGraph data={dfa} />;                        // View Layer
```

### 3.2 Simulation Engine
The simulation is handled client-side for immediate feedback.
-   **Step-by-Step Execution**: The simulator components (`DFASimulator.jsx`, etc.) maintain a `simulationSteps` array.
-   **Pre-computation**: When "Test" is clicked, the entire execution path is pre-calculated.
-   **Playback**: The UI simply iterates through these steps, updating the highlighted state and active transition edge. This avoids complex asynchronous state management during playback.

---

## 4. Phase 3: Visualization (ReactFlow Integration)

### 4.1 The Graph Engine (`DFAGraph.jsx`, etc.)
Visualizing automata requires a robust graph library. `ReactFlow` was chosen for its interactivity (drag-and-drop nodes).
-   **Node Customization**: States are rendered as nodes. Accept states use double borders (CSS styling).
-   **Edge Routing**: Transitions are edges. Self-loops and multi-edge handling (e.g., transitions on '0' and '1') required custom edge rendering logic to prevent visual clutter.

### 4.2 Specialized Visualizers
Not all automata are just graphs.
-   **Turing Machines**: Required a custom `TapeVisualizer` component. This renders an infinite tape array, centers the "head" dynamically, and animates the read/write operations.
-   **PDAs**: Added a **Stack Visualizer** to show push/pop operations in real-time alongside the graph transition.
-   **CFGs**: Implemented a **Parse Tree** renderer to visualize the derivation of strings from grammar rules.

---

## 5. Phase 4: The Tutorial System

### 5.1 Interactive Learning (`TutorialHub.jsx`)
I built a comprehensive Learning Management System (LMS) within the app.
-   **Data-Driven**: Content is stored in structured JS objects (`tutorialData.js`), making it easy to add new lessons without changing code.
-   **Progress Tracking**: Uses `useState` and simple set logic to track completed lessons and exercises.

### 5.2 Hands-On Challenges
This is the "killer feature" of the frontend.
-   **Challenge Mode**: The simulator can accept a `challenge` prop.
-   **Validation Engine (`ChallengeValidator.js`)**: A dedicated utility that runs a user's constructed automaton against a suite of test cases (hidden from the user).
-   **Cross-Window Communication**: When a student opens a challenge from the tutorial, it launches the simulator in a new mode. Passing the test sends a message back to the Tutorial Hub to unlock the next step.

---

## 6. Phase 5: User Experience (UX) Polish

### 6.1 Responsive Design
-   **Collapsible Panels**: Complex controls (Transition Tables, State Editors) are wrapped in `CollapsibleSection` components to maximize screen real estate for the graph.
-   **Toast Notifications**: Replaced native browser alerts with custom UI feedback for errors (e.g., "Duplicate State Name").

### 6.2 History & Persistence
-   **Undo/Redo**: Implemented robust time-travel debugging for graph editing.
-   **Session Storage**: Used `sessionStorage` to persist tutorial progress and simulator state across reloads, ensuring students don't lose their context.

---

## 7. Conclusion

The `Automata Diags` frontend is not just a UI for the backend; it is a full-featured, standalone educational platform. By decoupling the simulation logic into hooks and leveraging modern React ecosystem tools, the architecture achieves high performance and maintainability while delivering a rich, interactive learning experience.


