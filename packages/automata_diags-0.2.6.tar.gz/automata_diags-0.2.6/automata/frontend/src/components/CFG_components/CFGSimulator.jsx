import React, { useState, useEffect, useCallback, useMemo } from 'react';
import './stylings/CFGSimulator.css';
import { CFGControlPanel } from './CFGControlPanel';
import { CFGTestCases } from './CFGTestCases';
import { ParseTree } from './ParseTree';
import { VariablesEditor } from './VariablesEditor';
import { TerminalsEditor } from './TerminalsEditor';
import { ProductionRulesEditor } from './ProductionRulesEditor';
import { CollapsibleSection } from '../shared/CollapsibleSection';
import { useExamples } from './examples';
import { useCFG } from './useCFG';
import { validateCFGChallenge } from '../Tutorial_components/ChallengeValidator';
import { CheckCircle, XCircle, Target } from 'lucide-react';

const CFGSimulator = ({ challenge }) => {
    const { examples } = useExamples();
    const [currentExampleName, setCurrentExampleName] = useState(challenge ? null : 'balanced_parentheses');
    const [currentExampleDescription, setCurrentExampleDescription] = useState(null);
    const [validationResults, setValidationResults] = useState(null);

    // Memoize initialConfig to prevent re-renders
    const initialConfig = useMemo(() => challenge ? {
        variables: challenge.challenge?.variables || ['S'],
        terminals: challenge.challenge?.terminals || ['0', '1'],
        rules: [],
        startVariable: challenge.challenge?.variables?.[0] || 'S',
    } : {
        variables: examples['balanced_parentheses'].variables,
        terminals: examples['balanced_parentheses'].terminals,
        rules: examples['balanced_parentheses'].rules,
        startVariable: examples['balanced_parentheses'].startVariable,
    }, [challenge, examples]);

    const cfg = useCFG(initialConfig);

    const [inputString, setInputString] = useState('');
    const [derivationSteps, setDerivationSteps] = useState([]);
    const [currentStep, setCurrentStep] = useState(-1);
    const [isPlaying, setIsPlaying] = useState(false);
    const [playbackSpeed, setPlaybackSpeed] = useState(1000);
    const [isAccepted, setIsAccepted] = useState(null);

    const resetDerivation = useCallback(() => {
        setDerivationSteps([]);
        setCurrentStep(-1);
        setIsPlaying(false);
        setIsAccepted(null);
    }, []);

    // Event listeners for toolbox actions
    useEffect(() => {
        const handleImport = () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        try {
                            const cfgDefinition = JSON.parse(e.target.result);
                            cfg.loadCFG({
                                variables: cfgDefinition.variables || [],
                                terminals: cfgDefinition.terminals || [],
                                rules: cfgDefinition.rules || [],
                                startVariable: cfgDefinition.startVariable || 'S'
                            });
                            setCurrentExampleName(cfgDefinition.name || 'Imported CFG');
                            resetDerivation();
                        } catch (error) {
                            alert('Invalid JSON file or CFG definition format');
                        }
                    };
                    reader.readAsText(file);
                }
            };
            input.click();
        };

        const handleExport = () => {
            const cfgDefinition = {
                name: currentExampleName || 'Custom CFG',
                description: 'Exported CFG definition',
                variables: cfg.variables,
                terminals: cfg.terminals,
                rules: cfg.rules,
                startVariable: cfg.startVariable
            };
            const dataStr = JSON.stringify(cfgDefinition, null, 2);
            const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
            const linkElement = document.createElement('a');
            linkElement.setAttribute('href', dataUri);
            linkElement.setAttribute('download', 'cfg_definition.json');
            linkElement.click();
        };

        const handleClearAll = () => {
            if (window.confirm('Are you sure you want to clear all and start fresh?')) {
                cfg.loadCFG({ variables: ['S'], terminals: ['a', 'b'], rules: [], startVariable: 'S' });
                setCurrentExampleName(null);
                setCurrentExampleDescription(null);
                resetDerivation();
                setValidationResults(null);
            }
        };

        window.addEventListener('import', handleImport);
        window.addEventListener('export', handleExport);
        window.addEventListener('clearAll', handleClearAll);
        return () => {
            window.removeEventListener('import', handleImport);
            window.removeEventListener('export', handleExport);
            window.removeEventListener('clearAll', handleClearAll);
        };
        // Use individual cfg properties to avoid re-running when cfg object changes
    }, [cfg.loadCFG, cfg.variables, cfg.terminals, cfg.rules, cfg.startVariable, currentExampleName, resetDerivation]);

    // Reset to blank when challenge mode is activated
    useEffect(() => {
        if (challenge) {
            cfg.loadCFG({
                variables: challenge.challenge?.variables || ['S'],
                terminals: challenge.challenge?.terminals || ['0', '1'],
                rules: [],
                startVariable: challenge.challenge?.variables?.[0] || 'S'
            });
            setInputString('');
            resetDerivation();
            setValidationResults(null);
        }
        // Only run when challenge changes
    }, [challenge]);

    // Auto-play derivation steps
    useEffect(() => {
        let timer;
        if (isPlaying && currentStep < derivationSteps.length - 1) {
            timer = setTimeout(() => { setCurrentStep(currentStep + 1); }, playbackSpeed);
        } else if (currentStep >= derivationSteps.length - 1) {
            setIsPlaying(false);
        }
        return () => clearTimeout(timer);
    }, [isPlaying, currentStep, derivationSteps.length, playbackSpeed]);

    // Helper functions for CNF conversion and CYK parsing
    const normalizeCFG = (cfg) => {
        const newCfg = JSON.parse(JSON.stringify(cfg));
        if (!Array.isArray(newCfg.rules)) newCfg.rules = [];
        newCfg.rules = newCfg.rules.map(r => ({
            left: r.left,
            right: (r.right === 'ε' || r.right === 'epsilon' || r.right === '') ? [] : r.right.split('')
        }));
        return newCfg;
    };

    const toCNF = (cfg) => {
        let cnf = normalizeCFG(cfg);
        cnf = eliminateStart(cnf);
        cnf = eliminateNull(cnf);
        cnf = eliminateUnit(cnf);
        cnf = separateTerminals(cnf);
        cnf = binarize(cnf);
        cnf = removeDuplicates(cnf);
        cnf.rules.sort((a, b) => {
            const leftComparison = a.left.localeCompare(b.left);
            if (leftComparison !== 0) return leftComparison;
            return a.right.join(' ').localeCompare(b.right.join(' '));
        });
        return cnf;
    };

    const eliminateStart = (cfg) => {
        const newCfg = JSON.parse(JSON.stringify(cfg));
        if (!Array.isArray(newCfg.rules)) newCfg.rules = [];
        if (!Array.isArray(newCfg.variables)) newCfg.variables = [];
        newCfg.rules = newCfg.rules.map(r => ({ 
            left: r.left, 
            right: Array.isArray(r.right) ? r.right : ((r.right === 'ε' || r.right === 'epsilon' || r.right === '') ? [] : (typeof r.right === 'string' ? r.right.split('') : [])) 
        }));
        if (newCfg.rules.some(r => r.right.includes(newCfg.startVariable))) {
            const newStart = newCfg.startVariable + '0';
            if (!newCfg.variables.includes(newStart)) newCfg.variables.push(newStart);
            newCfg.rules.push({ left: newStart, right: [newCfg.startVariable] });
            newCfg.startVariable = newStart;
        }
        return newCfg;
    };

    const eliminateNull = (cfg) => {
        const newCfg = JSON.parse(JSON.stringify(cfg));
        if (!Array.isArray(newCfg.rules)) newCfg.rules = [];
        const nullable = new Set();
        newCfg.rules.forEach(r => {
            const rhs = Array.isArray(r.right) ? r.right : ((r.right === 'ε' || r.right === 'epsilon' || r.right === '') ? [] : (typeof r.right === 'string' ? r.right.split('') : []));
            if (rhs.length === 0) nullable.add(r.left);
            r.right = rhs;
        });
        let changed = true;
        let safetyCount = 0;
        while (changed && safetyCount < 100) {
            safetyCount++;
            changed = false;
            for (let r of newCfg.rules) {
                if (r.right.every(sym => nullable.has(sym))) {
                    if (!nullable.has(r.left)) { nullable.add(r.left); changed = true; }
                }
            }
        }
        const newRules = [];
        newCfg.rules.forEach(r => {
            if (r.right.length === 0) return;
            const nullableIndices = [];
            r.right.forEach((sym, i) => { if (nullable.has(sym)) nullableIndices.push(i); });
            
            // Limit to prevent exponential blowup
            const maxCombos = Math.min(1 << nullableIndices.length, 1024);
            for (let i = 0; i < maxCombos; i++) {
                const newRhs = [...r.right];
                for (let j = 0; j < nullableIndices.length; j++) { if ((i >> j) & 1) newRhs[nullableIndices[j]] = null; }
                const finalRhs = newRhs.filter(sym => sym !== null);
                if (finalRhs.length > 0) newRules.push({ left: r.left, right: finalRhs });
            }
        });
        newCfg.rules = newRules;
        return newCfg;
    };

    const eliminateUnit = (cfg) => {
        const newCfg = JSON.parse(JSON.stringify(cfg));
        if (!Array.isArray(newCfg.rules)) newCfg.rules = [];
        if (!Array.isArray(newCfg.variables)) newCfg.variables = [];
        const unitPairs = new Set();
        newCfg.rules.forEach(r => {
            if (!Array.isArray(r.right)) r.right = ((r.right === 'ε' || r.right === 'epsilon' || r.right === '') ? [] : (typeof r.right === 'string' ? r.right.split('') : []));
            if (r.right.length === 1 && newCfg.variables.includes(r.right[0])) unitPairs.add(`${r.left}-${r.right[0]}`);
        });
        const closures = {};
        newCfg.variables.forEach(v => closures[v] = new Set([v]));
        unitPairs.forEach(pair => { const [a, b] = pair.split('-'); if (closures[a]) closures[a].add(b); });
        let changed = true;
        let safetyCount = 0;
        while (changed && safetyCount < 100) {
            safetyCount++;
            changed = false;
            for (let a of newCfg.variables) {
                for (let b of newCfg.variables) {
                    if (closures[a].has(b)) {
                        for (let c of (closures[b] || [])) { if (!closures[a].has(c)) { closures[a].add(c); changed = true; } }
                    }
                }
            }
        }
        const newRules = [];
        for (let A of newCfg.variables) {
            const closureA = closures[A] || new Set([A]);
            for (let B of closureA) {
                newCfg.rules.forEach(p => {
                    if (p.left === B && !(p.right.length === 1 && newCfg.variables.includes(p.right[0]))) newRules.push({ left: A, right: p.right });
                });
            }
        }
        newCfg.rules = newRules;
        return newCfg;
    };

    const separateTerminals = (cfg) => {
        const newCfg = JSON.parse(JSON.stringify(cfg));
        const terminalMap = {};
        newCfg.terminals.forEach(t => {
            const nt = 'X' + t.toUpperCase();
            if (!newCfg.variables.includes(nt)) newCfg.variables.push(nt);
            terminalMap[t] = nt;
            newCfg.rules.push({ left: nt, right: [t] });
        });
        newCfg.rules = newCfg.rules.map(r => {
            if (r.right.length > 1) return { left: r.left, right: r.right.map(sym => terminalMap[sym] || sym) };
            return r;
        });
        return newCfg;
    };

    const binarize = (cfg) => {
        const newCfg = JSON.parse(JSON.stringify(cfg));
        const newRules = [];
        const productionsToProcess = [...newCfg.rules];
        const binarizationVars = ['P', 'Q', 'R', 'T', 'U', 'V', 'W', 'Y', 'Z'];
        let varCounter = 0;
        while (productionsToProcess.length > 0) {
            const p = productionsToProcess.shift();
            if (p.right.length > 2) {
                let newVar = varCounter < binarizationVars.length ? binarizationVars[varCounter] : 'B' + varCounter;
                varCounter++;
                if (!newCfg.variables.includes(newVar)) newCfg.variables.push(newVar);
                newRules.push({ left: p.left, right: [p.right[0], newVar] });
                productionsToProcess.push({ left: newVar, right: p.right.slice(1) });
            } else newRules.push(p);
        }
        const uniqueRules = [];
        const seen = new Set();
        newRules.forEach(r => {
            const key = `${r.left}-${r.right.join(',')}`;
            if (!seen.has(key)) { seen.add(key); uniqueRules.push(r); }
        });
        newCfg.rules = uniqueRules;
        return newCfg;
    };

    const removeDuplicates = (cfg) => {
        const seen = new Set();
        cfg.rules = cfg.rules.filter(r => {
            const key = `${r.left}->${r.right.join(' ')}`;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
        return cfg;
    };

    const cykParse = (cnf, input) => {
        const n = input.length;
        if (n === 0) return false;
        const table = Array.from({ length: n }, () => Array.from({ length: n }, () => new Set()));
        for (let i = 0; i < n; i++) {
            cnf.rules.forEach(r => { if (r.right.length === 1 && r.right[0] === input[i]) table[i][i].add(r.left); });
        }
        for (let len = 2; len <= n; len++) {
            for (let i = 0; i <= n - len; i++) {
                const j = i + len - 1;
                for (let k = i; k < j; k++) {
                    cnf.rules.forEach(r => {
                        if (r.right.length === 2) {
                            const [b, c] = r.right;
                            if (table[i][k].has(b) && table[k + 1][j].has(c)) table[i][j].add(r.left);
                        }
                    });
                }
            }
        }
        return table[0][n - 1].has(cnf.startVariable);
    };

    const generateLeftmostDerivation = (cfg, target) => {
        // Use BFS instead of recursion to prevent deep call stacks and provide better progress
        const queue = [{
            current: cfg.startVariable,
            steps: [{ step: 0, string: cfg.startVariable, production: null, description: `Start with ${cfg.startVariable}` }],
            depth: 1
        }];
        const visited = new Set([cfg.startVariable]);
        const maxDepth = 1000; // Limit iterations
        let count = 0;

        while (queue.length > 0 && count < maxDepth) {
            count++;
            const { current, steps, depth } = queue.shift();

            if (current === target) return steps;
            if (current.length > target.length * 2 + 2) continue;

            let variableIndex = -1;
            let variable = null;
            for (let i = 0; i < current.length; i++) { 
                if (cfg.variables.includes(current[i])) { 
                    variableIndex = i; 
                    variable = current[i]; 
                    break; 
                } 
            }

            if (variable === null) continue;

            const applicableRules = cfg.rules.filter(r => r.left === variable);
            for (const rule of applicableRules) {
                const replacement = (rule.right === 'ε' || rule.right === 'epsilon' || rule.right === '') ? '' : rule.right;
                const newString = current.substring(0, variableIndex) + replacement + current.substring(variableIndex + 1);
                
                // Heuristic: terminal prefix must match target
                const terminalPrefix = newString.split('').filter((_, idx) => idx < variableIndex || !cfg.variables.includes(newString[idx])).join('').substring(0, variableIndex);
                if (terminalPrefix && !target.startsWith(terminalPrefix)) continue;

                if (!visited.has(newString)) {
                    visited.add(newString);
                    const newSteps = [...steps, { 
                        step: depth, 
                        string: newString, 
                        production: rule, 
                        highlightIndices: Array.from({ length: replacement.length }, (_, i) => variableIndex + i), 
                        description: `Apply ${rule.left} → ${rule.right}` 
                    }];
                    queue.push({ current: newString, steps: newSteps, depth: depth + 1 });
                }
            }
        }
        return null;
    };

    const parseString = () => {
        setDerivationSteps([]);
        setCurrentStep(-1);
        setIsAccepted(null);

        // Run CYK first - it's O(n^3) and safer for rejection
        const cnfGrammar = toCNF(cfg);
        const accepted = cykParse(cnfGrammar, inputString);
        
        if (!accepted) {
            setIsAccepted(false);
            setDerivationSteps([{ step: 0, string: inputString, production: null, description: `REJECTED: No derivation possible.` }]);
            setCurrentStep(0);
            return;
        }

        // If accepted, try to find a derivation for visualization
        const steps = generateLeftmostDerivation(cfg, inputString);
        if (steps) {
            setDerivationSteps(steps);
            setIsAccepted(true);
            setCurrentStep(0);
        } else {
            // Should not happen if CYK accepted, but as fallback
            setIsAccepted(true);
            setDerivationSteps([{ step: 0, string: inputString, production: null, description: `ACCEPTED (CYK Result)` }]);
            setCurrentStep(0);
        }
    };

    const loadExample = useCallback((exampleName) => {
        const example = examples[exampleName];
        if (example) {
            setCurrentExampleName(exampleName);
            setCurrentExampleDescription(example?.description || null);
            cfg.loadCFG(example);
            setInputString('');
            resetDerivation();
        }
    }, [examples, cfg.loadCFG, resetDerivation]);

    const handleValidateChallenge = () => {
        if (!challenge || !challenge.challenge || !challenge.challenge.testCases) {
            alert('No challenge data available');
            return;
        }
        const userCFG = { variables: cfg.variables, terminals: cfg.terminals, rules: cfg.rules, startVariable: cfg.startVariable };
        const results = validateCFGChallenge(userCFG, challenge.challenge.testCases);
        setValidationResults(results);
        if (window.opener && challenge.returnTo === 'tutorial') {
            window.opener.postMessage({ type: 'CHALLENGE_RESULT', results: results }, window.location.origin);
        }
    };

    return (
        <div className="cfg-simulator-new">
            <div className="cfg-container">
                {challenge && challenge.challenge && (
                    <div className="compact-challenge-header">
                        <div className="challenge-info">
                            <Target size={20} />
                            <span><strong>Challenge:</strong> {challenge.challenge.description}</span>
                        </div>
                        <button className="validate-btn-compact" onClick={handleValidateChallenge}>
                            <CheckCircle size={16} /> Validate
                        </button>
                        {validationResults && (
                            <div className={`mini-results ${validationResults.passed === validationResults.total ? 'pass' : 'fail'}`}>
                                {validationResults.passed}/{validationResults.total} Passed
                            </div>
                        )}
                    </div>
                )}

                {!challenge && (
                    <div className="cfg-header">
                        <h1 className="cfg-title">CFG Simulator</h1>
                        <p className="cfg-subtitle">Context-Free Grammar - Derivation and parsing visualization</p>
                    </div>
                )}

                {!challenge && (
                    <div className="cfg-example-selector">
                        <label className="cfg-selector-label">Load Example:</label>
                        <div className="cfg-selector-buttons">
                            {Object.entries(examples).map(([key, example]) => (
                                <button key={key} className={`cfg-selector-btn ${currentExampleName === key ? 'active' : ''}`} onClick={() => loadExample(key)}>
                                    {example.name}
                                </button>
                            ))}
                        </div>
                        {currentExampleDescription && (
                            <div className="cfg-example-description"><strong>Description:</strong> {currentExampleDescription}</div>
                        )}
                    </div>
                )}

                <div className="cfg-grid">
                    <div className="cfg-left-col">
                        <div className="cfg-input-card">
                            <h3 className="cfg-card-title">Test Input String</h3>
                            <div className="cfg-input-group">
                                <input type="text" value={inputString} onChange={(e) => setInputString(e.target.value)} placeholder="Enter string to parse (e.g., aa)" className="cfg-input" />
                                <button onClick={parseString} className="cfg-btn cfg-btn-primary">Parse</button>
                            </div>
                            <p className="cfg-input-help">Terminals: {cfg.terminals.join(', ')}</p>
                            {isAccepted !== null && (
                                <div className={`cfg-result ${isAccepted ? 'accepted' : 'rejected'}`}>
                                    String is {isAccepted ? 'ACCEPTED' : 'REJECTED'}
                                </div>
                            )}
                        </div>

                        <CFGControlPanel
                            currentStep={currentStep}
                            totalSteps={derivationSteps.length}
                            isPlaying={isPlaying}
                            isComplete={currentStep >= 0 && currentStep === derivationSteps.length - 1}
                            isAccepted={isAccepted}
                            speed={playbackSpeed}
                            onRun={() => setIsPlaying(true)}
                            onPause={() => setIsPlaying(false)}
                            onStep={() => { if (currentStep < derivationSteps.length - 1) setCurrentStep(currentStep + 1); }}
                            onReset={resetDerivation}
                            onSpeedChange={setPlaybackSpeed}
                        />

                        <CollapsibleSection title="Grammar Rules" defaultOpen={true}>
                            <div className="cfg-grammar-card">
                                <div className="cfg-rules-list">
                                    {cfg.rules.map((rule, index) => (
                                        <div key={index} className="cfg-rule">
                                            <span className="cfg-rule-left">{rule.left}</span>
                                            <span className="cfg-rule-arrow">→</span>
                                            <span className="cfg-rule-right">{rule.right}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </CollapsibleSection>
                    </div>

                    <div className="cfg-right-col">
                        <CollapsibleSection title="Variables Editor" defaultOpen={challenge ? true : false}>
                            <VariablesEditor cfg={cfg} onUpdate={resetDerivation} />
                        </CollapsibleSection>
                        <CollapsibleSection title="Terminals Editor" defaultOpen={challenge ? true : false}>
                            <TerminalsEditor cfg={cfg} onUpdate={resetDerivation} />
                        </CollapsibleSection>
                        <CollapsibleSection title="Production Rules Editor" defaultOpen={challenge ? true : false}>
                            <ProductionRulesEditor cfg={cfg} onUpdate={resetDerivation} />
                        </CollapsibleSection>
                        {!challenge && (
                            <CollapsibleSection title="Example Test Cases" defaultOpen={false}>
                                <CFGTestCases onLoadTest={(ti) => { setInputString(ti); resetDerivation(); }} currentExample={currentExampleName} />
                            </CollapsibleSection>
                        )}
                        <CollapsibleSection title="Parse Tree" defaultOpen={true}>
                            <div className="cfg-tree-card">
                                <ParseTree derivationSteps={derivationSteps} currentStep={currentStep} />
                            </div>
                        </CollapsibleSection>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CFGSimulator;
