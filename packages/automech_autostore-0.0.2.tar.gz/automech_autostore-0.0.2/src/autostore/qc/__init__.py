"""QCIO interface."""

from . import structure

__all__ = ["structure"]
