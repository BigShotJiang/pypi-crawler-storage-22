"""RDKit interface."""

from . import mol
from .mol import Mol

__all__ = ["mol", "Mol"]
