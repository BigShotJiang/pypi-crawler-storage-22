#!/usr/bin/env python
"""
Setup script for backward compatibility.
Use pyproject.toml for modern builds.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
