"""Analyzers package initialization."""

from .call_tree_builder import CallTreeBuilder

__all__ = ["CallTreeBuilder"]
