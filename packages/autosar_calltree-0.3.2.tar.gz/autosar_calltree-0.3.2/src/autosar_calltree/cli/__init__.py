"""CLI package initialization."""

from .main import cli

__all__ = ["cli"]
