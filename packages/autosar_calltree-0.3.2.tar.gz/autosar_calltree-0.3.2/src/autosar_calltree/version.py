"""Version information for autosar-calltree package."""

__version__ = "0.3.1"
__author__ = "melodypapa"
__email__ = "melodypapa@outlook.com"
