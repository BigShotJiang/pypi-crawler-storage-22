"""CLI module for autosar-pdf2txt."""

from autosar_pdf2txt.cli.autosar_cli import main

__all__ = ["main"]
