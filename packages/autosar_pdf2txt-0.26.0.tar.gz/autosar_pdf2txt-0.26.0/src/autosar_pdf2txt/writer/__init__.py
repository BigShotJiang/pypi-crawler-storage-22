"""Markdown writer for AUTOSAR packages and classes."""

from autosar_pdf2txt.writer.markdown_writer import MarkdownWriter

__all__ = ["MarkdownWriter"]
