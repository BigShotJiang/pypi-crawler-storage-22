
# AutoScore - Automated Scorecard Modeling Library

from .pipeline import AutoScore
from .eda import FeatureAnalyzer
from .binning import BinningProcess
from .selection import FeatureSelector
from .modeling import ModelTrainer
from .evaluation import ModelEvaluator
from .scorecard import ScorecardTransformer
from .reporting import ReportGenerator
from .lightweight_scorer import LightweightScorer

__version__ = '0.1.0'
