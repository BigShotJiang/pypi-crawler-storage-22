import numpy as np

class Config:
    # Random Seed
    RANDOM_STATE = 42
    
    # Missing Values
    MISSING_VALUES = [float('nan'), None, np.nan]
    
    # Special Values that should be treated as separate bins (e.g., -999, -1)
    SPECIAL_VALUES = []
    
    # Binning Defaults
    MAX_BINS = 10
    MIN_BIN_PCT = 0.05
    
    # Selection Defaults
    IV_THRESHOLD = 0.02
    PSI_THRESHOLD = 0.1
    CORR_THRESHOLD = 0.7
    
    # Modeling Defaults
    TEST_SIZE = 0.3
    
    # SGD Classifier Defaults (for incremental learning)
    SGD_ALPHA = 0.0001
    SGD_LEARNING_RATE = 'adaptive'
    SGD_ETA0 = 0.01
    SGD_MAX_ITER = 1000
    SGD_PENALTY = 'l2'
    SGD_LOSS = 'log_loss'
