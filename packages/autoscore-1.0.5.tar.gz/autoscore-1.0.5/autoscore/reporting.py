
import pandas as pd

class ReportGenerator:
    def generate(self, filename, data_dict):
        """
        Generate Excel report.
        data_dict: dictionary of {sheet_name: dataframe}
        """
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            for sheet_name, df in data_dict.items():
                if df is not None:
                    # Truncate sheet name if too long (max 31 chars)
                    safe_name = sheet_name[:31]
                    df.to_excel(writer, sheet_name=safe_name, index=False)
                    
        return filename
