
import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="autoscore",
    version="1.0.5",
    author="AutoScore Team",
    author_email="example@example.com",
    description="A comprehensive automated credit risk scorecard modeling library",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/autoscore",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Office/Business :: Financial",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires='>=3.6',
    install_requires=[
        "pandas>=1.0.0",
        "numpy>=1.18.0",
        "scikit-learn>=0.22.0",
        "matplotlib>=3.0.0",
        "openpyxl>=3.0.0",
        "joblib>=0.14.0"
    ],
    include_package_data=True,
)
