"""
Tests package for autoscore.
"""
