"""
Basic tests for autoscore package.
"""

import pandas as pd
import numpy as np
from autoscore import AutoScore
from autoscore.binning import BinningProcess
from autoscore.selection import FeatureSelector
from autoscore.eda import FeatureAnalyzer

def test_feature_analyzer():
    """Test FeatureAnalyzer functionality."""
    print("Testing FeatureAnalyzer...")
    
    # Create sample data
    df = pd.DataFrame({
        'age': [25, 30, 35, 40, 45],
        'income': [50000, 60000, 70000, 80000, 90000],
        'target': [0, 0, 1, 0, 1]
    })
    
    # Test analyze
    analyzer = FeatureAnalyzer()
    summary = analyzer.analyze(df, target='target')
    
    assert summary is not None
    assert len(summary) == 3  # age, income, target
    assert 'single_value_rate' in summary.columns
    assert 'mode' in summary.columns
    assert 'median' in summary.columns
    assert 'corr_with_target' in summary.columns
    
    print("FeatureAnalyzer test passed!")

def test_binning_process():
    """Test BinningProcess functionality."""
    print("Testing BinningProcess...")
    
    # Create sample data
    df = pd.DataFrame({
        'feature1': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        'target': [0, 0, 0, 1, 1, 0, 0, 1, 1, 0]
    })
    
    # Test fit
    binning = BinningProcess(max_bins=3)
    binning.fit(df[['feature1']], df['target'])
    
    assert binning.rules is not None
    assert 'feature1' in binning.rules
    assert 'cutoffs' in binning.rules['feature1']
    
    # Test transform
    X_woe = binning.transform(df[['feature1']])
    assert X_woe is not None
    assert 'feature1' in X_woe.columns
    
    print("BinningProcess test passed!")

def test_feature_selector():
    """Test FeatureSelector functionality."""
    print("Testing FeatureSelector...")
    
    # Create sample data
    X = pd.DataFrame({
        'feature1': [1, 2, 3, 4, 5],
        'feature2': [10, 20, 30, 40, 50],
        'feature3': [100, 200, 300, 400, 500]
    })
    y = pd.Series([0, 0, 1, 0, 1])
    
    # Test stepwise selection
    selector = FeatureSelector()
    selected = selector.stepwise_selection(X, y, selection_method='stepwise')
    
    assert selected is not None
    assert len(selected) >= 1
    assert len(selector.selection_process) > 0
    
    print("FeatureSelector test passed!")

def test_autoscore_basic():
    """Test AutoScore basic functionality."""
    print("Testing AutoScore basic functionality...")
    
    # Create sample data
    df = pd.DataFrame({
        'age': [25, 30, 35, 40, 45, 50, 55, 60, 65, 70],
        'income': [50000, 60000, 70000, 80000, 90000, 100000, 110000, 120000, 130000, 140000],
        'target': [0, 0, 1, 0, 1, 0, 1, 0, 1, 0]
    })
    
    # Test fit
    score = AutoScore(random_state=42)
    results = score.fit(
        X=df.drop(columns=['target']),
        y=df['target'],
        test_size=0.3,
        max_bins=3,
        selection_method='stepwise'
    )
    
    assert results is not None
    assert 'selected_features' in results
    assert 'performance' in results
    assert len(score.selected_features) >= 1
    
    # Test predict
    X_new = df.drop(columns=['target']).head(3)
    scores = score.predict_score(X_new)
    probas = score.predict_proba(X_new)
    
    assert scores is not None
    assert len(scores) == 3
    assert probas is not None
    assert len(probas) == 3
    
    print("AutoScore basic test passed!")

if __name__ == '__main__':
    test_feature_analyzer()
    test_binning_process()
    test_feature_selector()
    test_autoscore_basic()
    print("\nAll basic tests passed!")
