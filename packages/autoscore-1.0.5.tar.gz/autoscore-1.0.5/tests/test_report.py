"""
Tests for report generation.
"""

import pandas as pd
import os
from autoscore import AutoScore

def test_report_generation():
    """Test report generation functionality."""
    print("Testing report generation...")
    
    # Create sample data
    df = pd.DataFrame({
        'age': [25, 30, 35, 40, 45, 50, 55, 60, 65, 70],
        'income': [50000, 60000, 70000, 80000, 90000, 100000, 110000, 120000, 130000, 140000],
        'target': [0, 0, 1, 0, 1, 0, 1, 0, 1, 0]
    })
    
    # Train model
    score = AutoScore(random_state=42)
    results = score.fit(
        X=df.drop(columns=['target']),
        y=df['target'],
        test_size=0.3,
        max_bins=3,
        selection_method='stepwise'
    )
    
    # Generate report
    report_path = 'test_report.xlsx'
    score.create_report(report_path)
    
    # Check if report was created
    assert os.path.exists(report_path), f"Report file {report_path} was not created"
    
    # Check if report contains expected sheets
    import openpyxl
    wb = openpyxl.load_workbook(report_path)
    expected_sheets = ['数据情况', 'Summary', '原始特征清单', '特征选择过程', 
                       'Selected Features', 'Model Coefficients', 'Model Performance', 
                       'Scorecard', 'Score Bin']
    
    for sheet_name in expected_sheets:
        assert sheet_name in wb.sheetnames, f"Sheet '{sheet_name}' not found in report"
    
    print("Report generation test passed!")
    
    # Clean up
    os.remove(report_path)

if __name__ == '__main__':
    test_report_generation()
    print("\nReport generation tests passed!")
