from autotimm.tasks.classification import ImageClassifier

__all__ = ["ImageClassifier"]
