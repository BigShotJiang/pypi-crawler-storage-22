from autotimm.tasks.classification import ImageClassifier
from autotimm.tasks.object_detection import ObjectDetector

__all__ = ["ImageClassifier", "ObjectDetector"]
