"""Basic utilities."""

from .cpu_count import cpu_count
from .seasonal import seasonal_int
