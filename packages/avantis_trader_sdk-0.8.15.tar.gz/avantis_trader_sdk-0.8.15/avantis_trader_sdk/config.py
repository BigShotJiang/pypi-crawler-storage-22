MAINNET_ADDRESSES = {
    "TradingStorage": "0x8a311D7048c35985aa31C131B9A13e03a5f7422d",
    "PairStorage": "0x5db3772136e5557EFE028Db05EE95C84D76faEC4",
    "PairInfos": "0x81F22d0Cc22977c91bEfE648C9fddf1f2bd977e5",
    "PriceAggregator": "0x64e2625621970F8cfA17B294670d61CB883dA511",
    "USDC": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
    "Trading": "0x44914408af82bC9983bbb330e3578E1105e11d4e",
    "Multicall": "0xA7cFc43872F4D7B0E6141ee8c36f1F7FEe5d099e",
    "Referral": "0x1A110bBA13A1f16cCa4b79758BD39290f29De82D",
}

AVANTIS_SOCKET_API = "https://socket-api-pub.avantisfi.com/socket-api/v1/data"
AVANTIS_CORE_API_BASE_URL = "https://core.avantisfi.com"
AVANTIS_FEED_V3_URL = "https://feed-v3.avantisfi.com"
PYTH_LAZER_SSE_URL = "https://pyth-lazer-proxy-3.dourolabs.app/v1/stream"

CONTRACT_ADDRESSES = MAINNET_ADDRESSES
