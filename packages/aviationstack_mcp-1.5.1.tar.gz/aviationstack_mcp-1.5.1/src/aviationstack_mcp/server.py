"""Aviationstack MCP server tools."""

import json
import os
import random
from datetime import datetime
from typing import Any
from collections.abc import Callable

import requests
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Aviationstack MCP")

API_BASE_URL = "https://api.aviationstack.com/v1"


def _safe_get(obj: dict[str, Any] | None, *keys: str) -> Any:
    """Safely read nested keys from dictionaries."""
    current: Any = obj
    for key in keys:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current


def _validate_positive_int(value: int, param_name: str) -> None:
    if value <= 0:
        raise ValueError(f"'{param_name}' must be greater than 0.")


def _validate_non_negative_int(value: int, param_name: str) -> None:
    if value < 0:
        raise ValueError(f"'{param_name}' must be 0 or greater.")


def _validate_iso_date(date_value: str, param_name: str) -> None:
    """Validate strict YYYY-MM-DD date format."""
    try:
        parsed = datetime.strptime(date_value, "%Y-%m-%d")
    except ValueError as exc:
        raise ValueError(f"'{param_name}' must be in YYYY-MM-DD format.") from exc
    if parsed.strftime("%Y-%m-%d") != date_value:
        raise ValueError(f"'{param_name}' must be in YYYY-MM-DD format.")


def _error_response(context: str, exc: Exception) -> str:
    return json.dumps({"ok": False, "context": context, "error": str(exc)})


def _sample_data(items: list[dict[str, Any]], count: int) -> list[dict[str, Any]]:
    _validate_positive_int(count, "count")
    number_to_fetch = min(count, len(items))
    return random.sample(items, number_to_fetch)


def fetch_flight_data(endpoint: str, params: dict[str, Any]) -> dict[str, Any]:
    """Fetch data from the Aviationstack API."""
    api_key = os.getenv("AVIATION_STACK_API_KEY")
    if not api_key:
        raise ValueError("AVIATION_STACK_API_KEY not set in environment.")
    request_params = {"access_key": api_key, **params}
    response = requests.get(f"{API_BASE_URL}/{endpoint}", params=request_params, timeout=15)
    try:
        payload = response.json()
    except ValueError:
        payload = {}

    if payload.get("error"):
        error = payload["error"]
        code = error.get("code", "api_error")
        error_type = error.get("type", "api_error")
        message = error.get("message", "Unknown API error")
        raise ValueError(f"{error_type} ({code}): {message}")

    response.raise_for_status()
    return payload


def _list_reference_data(
    endpoint: str,
    params: dict[str, Any],
    mapper: Callable[[dict[str, Any]], dict[str, Any]],
) -> str:
    data = fetch_flight_data(endpoint, params)
    return json.dumps([mapper(item) for item in data.get("data", [])])


@mcp.tool()
def flights_with_airline(airline_name: str, number_of_flights: int) -> str:
    """Get a random sample of real-time flights for an airline."""
    try:
        _validate_positive_int(number_of_flights, "number_of_flights")
        data = fetch_flight_data(
            "flights", {"airline_name": airline_name, "limit": number_of_flights}
        )
        sampled_flights = _sample_data(data.get("data", []), number_of_flights)

        filtered_flights = []
        for flight in sampled_flights:
            filtered_flights.append(
                {
                    "flight_number": _safe_get(flight, "flight", "iata"),
                    "airline": _safe_get(flight, "airline", "name"),
                    "departure_airport": _safe_get(flight, "departure", "airport"),
                    "departure_timezone": _safe_get(flight, "departure", "timezone"),
                    "departure_time": _safe_get(flight, "departure", "scheduled"),
                    "arrival_airport": _safe_get(flight, "arrival", "airport"),
                    "arrival_timezone": _safe_get(flight, "arrival", "timezone"),
                    "flight_status": flight.get("flight_status"),
                    "departure_delay": _safe_get(flight, "departure", "delay"),
                    "departure_terminal": _safe_get(flight, "departure", "terminal"),
                    "departure_gate": _safe_get(flight, "departure", "gate"),
                }
            )
        if not filtered_flights:
            return f"No flights found for airline '{airline_name}'."
        return json.dumps(filtered_flights)
    except requests.RequestException as exc:
        return _error_response("fetching flights", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching flights", exc)


@mcp.tool()
def historical_flights_by_date(
    flight_date: str,
    number_of_flights: int,
    airline_iata: str = "",
    dep_iata: str = "",
    arr_iata: str = "",
) -> str:
    """Get a random sample of historical flights for a specific date (Basic plan+)."""
    try:
        _validate_positive_int(number_of_flights, "number_of_flights")
        _validate_iso_date(flight_date, "flight_date")
        params: dict[str, Any] = {"flight_date": flight_date, "limit": number_of_flights}
        if airline_iata:
            params["airline_iata"] = airline_iata
        if dep_iata:
            params["dep_iata"] = dep_iata
        if arr_iata:
            params["arr_iata"] = arr_iata

        data = fetch_flight_data("flights", params)
        sampled_flights = _sample_data(data.get("data", []), number_of_flights)

        historical_flights = []
        for flight in sampled_flights:
            historical_flights.append(
                {
                    "flight_date": flight.get("flight_date"),
                    "flight_status": flight.get("flight_status"),
                    "flight_number": _safe_get(flight, "flight", "iata"),
                    "airline": _safe_get(flight, "airline", "name"),
                    "departure_airport": _safe_get(flight, "departure", "airport"),
                    "departure_time": _safe_get(flight, "departure", "scheduled"),
                    "arrival_airport": _safe_get(flight, "arrival", "airport"),
                    "arrival_time": _safe_get(flight, "arrival", "scheduled"),
                }
            )
        if not historical_flights:
            return f"No historical flights found for date '{flight_date}'."
        return json.dumps(historical_flights)
    except requests.RequestException as exc:
        return _error_response("fetching historical flights", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching historical flights", exc)


@mcp.tool()
def flight_arrival_departure_schedule(
    airport_iata_code: str,
    schedule_type: str,
    airline_name: str,
    number_of_flights: int,
) -> str:
    """Get a random sample of current-day arrival/departure schedules for an airport."""
    try:
        _validate_positive_int(number_of_flights, "number_of_flights")
        normalized_schedule_type = schedule_type.lower()
        if normalized_schedule_type not in {"arrival", "departure"}:
            raise ValueError("'schedule_type' must be either 'arrival' or 'departure'.")

        params: dict[str, Any] = {"iataCode": airport_iata_code, "type": normalized_schedule_type}
        if airline_name:
            params["airline_name"] = airline_name

        data = fetch_flight_data("timetable", params)
        sampled_flights = _sample_data(data.get("data", []), number_of_flights)

        filtered_flights = []
        for flight in sampled_flights:
            filtered_flights.append(
                {
                    "airline": _safe_get(flight, "airline", "name"),
                    "flight_number": _safe_get(flight, "flight", "iataNumber"),
                    "departure_estimated_time": _safe_get(
                        flight, "departure", "estimatedTime"
                    ),
                    "departure_scheduled_time": _safe_get(
                        flight, "departure", "scheduledTime"
                    ),
                    "departure_actual_time": _safe_get(flight, "departure", "actualTime"),
                    "departure_terminal": _safe_get(flight, "departure", "terminal"),
                    "departure_gate": _safe_get(flight, "departure", "gate"),
                    "arrival_estimated_time": _safe_get(flight, "arrival", "estimatedTime"),
                    "arrival_scheduled_time": _safe_get(flight, "arrival", "scheduledTime"),
                    "arrival_airport_code": _safe_get(flight, "arrival", "iataCode"),
                    "arrival_terminal": _safe_get(flight, "arrival", "terminal"),
                    "arrival_gate": _safe_get(flight, "arrival", "gate"),
                    "departure_delay": _safe_get(flight, "departure", "delay"),
                }
            )
        if not filtered_flights:
            return f"No flights found for iata code '{airport_iata_code}'."
        return json.dumps(filtered_flights)
    except requests.RequestException as exc:
        return _error_response("fetching flight schedule", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching flight schedule", exc)


@mcp.tool()
def future_flights_arrival_departure_schedule(
    airport_iata_code: str,
    schedule_type: str,
    airline_iata: str,
    date: str,
    number_of_flights: int,
) -> str:
    """Get a random sample of future flights for an airport and date."""
    try:
        _validate_positive_int(number_of_flights, "number_of_flights")
        _validate_iso_date(date, "date")
        normalized_schedule_type = schedule_type.lower()
        if normalized_schedule_type not in {"arrival", "departure"}:
            raise ValueError("'schedule_type' must be either 'arrival' or 'departure'.")

        params: dict[str, Any] = {
            "iataCode": airport_iata_code,
            "type": normalized_schedule_type,
            "date": date,
        }
        if airline_iata:
            params["airline_iata"] = airline_iata

        data = fetch_flight_data("flightsFuture", params)
        sampled_flights = _sample_data(data.get("data", []), number_of_flights)

        filtered_flights = []
        for flight in sampled_flights:
            filtered_flights.append(
                {
                    "airline": _safe_get(flight, "airline", "name"),
                    "flight_number": _safe_get(flight, "flight", "iataNumber"),
                    "departure_scheduled_time": _safe_get(
                        flight, "departure", "scheduledTime"
                    ),
                    "arrival_scheduled_time": _safe_get(flight, "arrival", "scheduledTime"),
                    "arrival_airport_code": _safe_get(flight, "arrival", "iataCode"),
                    "arrival_terminal": _safe_get(flight, "arrival", "terminal"),
                    "arrival_gate": _safe_get(flight, "arrival", "gate"),
                    "aircraft": _safe_get(flight, "aircraft", "modelText"),
                }
            )
        if not filtered_flights:
            return f"No flights found for iata code '{airport_iata_code}'."
        return json.dumps(filtered_flights)
    except requests.RequestException as exc:
        return _error_response("fetching flight future schedule", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching flight future schedule", exc)


@mcp.tool()
def random_aircraft_type(number_of_aircraft: int) -> str:
    """Get random aircraft types."""
    try:
        _validate_positive_int(number_of_aircraft, "number_of_aircraft")
        data = fetch_flight_data("aircraft_types", {"limit": number_of_aircraft})
        sampled_aircraft_types = _sample_data(data.get("data", []), number_of_aircraft)

        aircraft_types = []
        for aircraft_type in sampled_aircraft_types:
            aircraft_types.append(
                {
                    "aircraft_name": aircraft_type.get("aircraft_name"),
                    "iata_code": aircraft_type.get("iata_code"),
                }
            )
        return json.dumps(aircraft_types)
    except requests.RequestException as exc:
        return _error_response("fetching aircraft type", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching aircraft type", exc)


@mcp.tool()
def random_airplanes_detailed_info(number_of_airplanes: int) -> str:
    """Get detailed info for random airplanes."""
    try:
        _validate_positive_int(number_of_airplanes, "number_of_airplanes")
        data = fetch_flight_data("airplanes", {"limit": number_of_airplanes})
        sampled_airplanes = _sample_data(data.get("data", []), number_of_airplanes)

        airplanes = []
        for airplane in sampled_airplanes:
            airplanes.append(
                {
                    "production_line": airplane.get("production_line"),
                    "plane_owner": airplane.get("plane_owner"),
                    "plane_age": airplane.get("plane_age"),
                    "model_name": airplane.get("model_name"),
                    "model_code": airplane.get("model_code"),
                    "plane_series": airplane.get("plane_series"),
                    "registration_number": airplane.get("registration_number"),
                    "engines_type": airplane.get("engines_type"),
                    "engines_count": airplane.get("engines_count"),
                    "delivery_date": airplane.get("delivery_date"),
                    "first_flight_date": airplane.get("first_flight_date"),
                }
            )
        return json.dumps(airplanes)
    except requests.RequestException as exc:
        return _error_response("fetching airplanes", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching airplanes", exc)


@mcp.tool()
def random_countries_detailed_info(number_of_countries: int) -> str:
    """Get detailed info for random countries."""
    try:
        _validate_positive_int(number_of_countries, "number_of_countries")
        data = fetch_flight_data("countries", {"limit": number_of_countries})
        sampled_countries = _sample_data(data.get("data", []), number_of_countries)

        countries = []
        for country in sampled_countries:
            countries.append(
                {
                    "country_name": country.get("name"),
                    "capital": country.get("capital"),
                    "currency_code": country.get("currency_code"),
                    "fips_code": country.get("fips_code"),
                    "country_iso2": country.get("country_iso2"),
                    "country_iso3": country.get("country_iso3"),
                    "continent": country.get("continent"),
                    "country_id": country.get("country_id"),
                    "currency_name": country.get("currency_name"),
                    "country_iso_numeric": country.get("country_iso_numeric"),
                    "phone_prefix": country.get("phone_prefix"),
                    "population": country.get("population"),
                }
            )
        return json.dumps(countries)
    except requests.RequestException as exc:
        return _error_response("fetching countries", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching countries", exc)


@mcp.tool()
def random_cities_detailed_info(number_of_cities: int) -> str:
    """Get detailed info for random cities."""
    try:
        _validate_positive_int(number_of_cities, "number_of_cities")
        data = fetch_flight_data("cities", {"limit": number_of_cities})
        sampled_cities = _sample_data(data.get("data", []), number_of_cities)

        cities = []
        for city in sampled_cities:
            cities.append(
                {
                    "gmt": city.get("gmt"),
                    "city_id": city.get("city_id"),
                    "iata_code": city.get("iata_code"),
                    "country_iso2": city.get("country_iso2"),
                    "geoname_id": city.get("geoname_id"),
                    "latitude": city.get("latitude"),
                    "longitude": city.get("longitude"),
                    "timezone": city.get("timezone"),
                    "city_name": city.get("city_name"),
                }
            )
        return json.dumps(cities)
    except requests.RequestException as exc:
        return _error_response("fetching cities", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching cities", exc)


@mcp.tool()
def list_airports(limit: int = 10, offset: int = 0, search: str = "") -> str:
    """List airports (supports basic-plan autocomplete through `search`)."""
    try:
        _validate_positive_int(limit, "limit")
        _validate_non_negative_int(offset, "offset")
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if search:
            params["search"] = search

        return _list_reference_data(
            "airports",
            params,
            lambda airport: {
                "airport_name": airport.get("airport_name"),
                "iata_code": airport.get("iata_code"),
                "icao_code": airport.get("icao_code"),
                "city_iata_code": airport.get("city_iata_code"),
                "country_name": airport.get("country_name"),
                "country_iso2": airport.get("country_iso2"),
                "timezone": airport.get("timezone"),
                "gmt": airport.get("gmt"),
            },
        )
    except requests.RequestException as exc:
        return _error_response("fetching airports", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching airports", exc)


@mcp.tool()
def list_airlines(limit: int = 10, offset: int = 0, search: str = "") -> str:
    """List airlines (supports basic-plan autocomplete through `search`)."""
    try:
        _validate_positive_int(limit, "limit")
        _validate_non_negative_int(offset, "offset")
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if search:
            params["search"] = search

        return _list_reference_data(
            "airlines",
            params,
            lambda airline: {
                "airline_name": airline.get("airline_name"),
                "iata_code": airline.get("iata_code"),
                "icao_code": airline.get("icao_code"),
                "callsign": airline.get("callsign"),
                "status": airline.get("status"),
                "country_name": airline.get("country_name"),
                "country_iso2": airline.get("country_iso2"),
            },
        )
    except requests.RequestException as exc:
        return _error_response("fetching airlines", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching airlines", exc)


@mcp.tool()
def list_routes(
    limit: int = 10,
    offset: int = 0,
    airline_iata: str = "",
    dep_iata: str = "",
    arr_iata: str = "",
) -> str:
    """List routes (available on Basic plan and higher)."""
    try:
        _validate_positive_int(limit, "limit")
        _validate_non_negative_int(offset, "offset")
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if airline_iata:
            params["airline_iata"] = airline_iata
        if dep_iata:
            params["dep_iata"] = dep_iata
        if arr_iata:
            params["arr_iata"] = arr_iata

        return _list_reference_data(
            "routes",
            params,
            lambda route: {
                "airline_iata": route.get("airline_iata"),
                "airline_icao": route.get("airline_icao"),
                "flight_number": route.get("flight_number"),
                "dep_iata": route.get("dep_iata"),
                "dep_icao": route.get("dep_icao"),
                "arr_iata": route.get("arr_iata"),
                "arr_icao": route.get("arr_icao"),
            },
        )
    except requests.RequestException as exc:
        return _error_response("fetching routes", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching routes", exc)


@mcp.tool()
def list_taxes(limit: int = 10, offset: int = 0, search: str = "") -> str:
    """List aviation taxes (available on all plans)."""
    try:
        _validate_positive_int(limit, "limit")
        _validate_non_negative_int(offset, "offset")
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if search:
            params["search"] = search

        return _list_reference_data(
            "taxes",
            params,
            lambda tax: {
                "tax_id": tax.get("tax_id"),
                "tax_name": tax.get("tax_name"),
                "iata_code": tax.get("iata_code"),
            },
        )
    except requests.RequestException as exc:
        return _error_response("fetching taxes", exc)
    except (KeyError, ValueError, TypeError) as exc:
        return _error_response("fetching taxes", exc)
