from ._coverage import COVERPACKAGES, CoverPackage
from ._elf import EXTENSIONS, INSTRUCTIONS, parse_elf
from ._instr import Instruction
from ._isa import ISA, Encoding, extract_isa
from ._spike import parse_spike_log
from ._trace import TRACE, Trace

# Add version
__version__ : str = "0.0.1"

__all__ = [
    "COVERPACKAGES",
    "CoverPackage",
    "EXTENSIONS",
    "INSTRUCTIONS",
    "parse_elf",
    "Instruction",
    "ISA",
    "extract_isa",
    "Encoding",
    "parse_spike_log",
    "TRACE",
    "Trace",
]
