from ._trace import Trace

COVERPACKAGES = []
"""
List of all registered CoverPackage classes
"""

class CoverPackage:

    def __init__(self, name : str) -> None:
        """
        Constructor

        :param name: Coverage Package name
        :type name: str
        """
        self.name = name

    def sample(self, trace : Trace) -> None:
        """
        Sample a given trace element

        :param trace: Trace element
        :type trace: Trace
        """
        raise ValueError(f"Unimplemented sample function: {self.name}")


__all__ = [
    "COVERPACKAGES",
    "CoverPackage",
]
