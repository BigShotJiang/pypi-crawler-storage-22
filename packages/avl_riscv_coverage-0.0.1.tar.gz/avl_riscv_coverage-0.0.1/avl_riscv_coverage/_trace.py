from ._instr import Instruction

TRACE = {}
"""
Dict of double-linked-lists of Trace elements. Indexed by CPUID
"""

class Trace:
    def __init__(self, instr : Instruction) -> None:
        """
        Constructor

        :param instr: Executed Instruction
        :type instr: Instruction
        """

        self.instr = instr
        self.prev = None
        self.next = None

    def __str__(self) -> str:
        """
        Return a string representation of the Instruction.

        :return: String representation of the Instruction.
        :rtype: str
        """

        s  = f"{self.prev.instr}" if self.prev is not None else "None"
        s += " -> "
        s += f"\033[31m{self.instr}\033[0m" if self.instr is not None else "None"
        s += " -> "
        s += f"{self.next.instr}" if self.next is not None else "None"

        return s

    def link(self, next : Instruction | None) -> None:
        """
        Create 2 way link to next instruction (if you can)

        Next / Prev refers to location in trace (i.e. executed instruction +/- one instruction)
        not location in program

        :param next: Next executed instruction
        :type next: Instruction
        """
        if next is not None:
            self.next = next
            self.next.prev = self

__all__ = [
    "TRACE",
    "Trace",
]
