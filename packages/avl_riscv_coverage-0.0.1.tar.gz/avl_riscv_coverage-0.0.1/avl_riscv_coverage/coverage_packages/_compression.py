import avl
from avl_riscv_coverage._coverage import COVERPACKAGES, CoverPackage
from avl_riscv_coverage._elf import EXTENSIONS
from avl_riscv_coverage._trace import Trace


class Compression(CoverPackage):

    def __init__(self) -> None:
        super().__init__("Compression")

        self.compressed = False
        self.cg = avl.Covergroup("compression", None)
        cp = self.cg.add_coverpoint("compression", lambda: self.compressed)
        cp.add_bin("compressed", True)
        cp.add_bin("not compressed", False)

    def sample(self, trace : Trace) -> None:
        self.compressed = trace.instr.encoding.size == 2
        self.cg.sample()

if "C" in EXTENSIONS:
    COVERPACKAGES.append(Compression())
