import avl
from avl_riscv_coverage._coverage import COVERPACKAGES, CoverPackage
from avl_riscv_coverage._isa import ISA
from avl_riscv_coverage._trace import Trace


class Opcodes(CoverPackage):

    def __init__(self) -> None:
        super().__init__("Opcodes")

        self.mnemonic = None
        self.cg = avl.Covergroup("opcodes", None)
        cp = self.cg.add_coverpoint("opcode", lambda: self.mnemonic)

        for k in ISA.keys():
            if k is not None:
                cp.add_bin(k, lambda x,k=k: x == k)

    def sample(self, trace : Trace) -> None:
        self.mnemonic = trace.instr.encoding.mnemonic
        if self.mnemonic is not None:
            self.cg.sample()

COVERPACKAGES.append(Opcodes())
