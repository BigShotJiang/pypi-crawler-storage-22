"""AWS GPU Capacity Management Agent."""

__version__ = "0.1.0"
