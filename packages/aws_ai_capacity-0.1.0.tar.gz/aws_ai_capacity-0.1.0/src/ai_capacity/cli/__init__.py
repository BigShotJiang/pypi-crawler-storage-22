"""CLI for the capacity agent."""
