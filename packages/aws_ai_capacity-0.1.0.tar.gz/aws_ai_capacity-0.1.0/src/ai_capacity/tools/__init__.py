"""AWS tools for capacity management."""
