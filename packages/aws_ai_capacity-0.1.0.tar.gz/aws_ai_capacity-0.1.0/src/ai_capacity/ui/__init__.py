"""Chainlit UI for the capacity agent."""
