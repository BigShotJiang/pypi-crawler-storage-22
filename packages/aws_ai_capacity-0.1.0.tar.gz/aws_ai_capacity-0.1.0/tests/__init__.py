"""Tests for ai-capacity."""
