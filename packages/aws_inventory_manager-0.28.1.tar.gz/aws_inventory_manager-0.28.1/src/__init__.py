"""AWS Baseline Snapshot & Delta Tracking tool."""

__version__ = "0.28.1"
