"""Resource collectors for AWS services."""

from typing import List

__all__: List[str] = []
