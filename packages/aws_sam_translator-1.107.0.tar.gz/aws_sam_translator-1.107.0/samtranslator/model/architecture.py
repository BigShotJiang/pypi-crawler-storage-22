"""
Enum for determining type of architectures for Lambda Function.
"""

ARM64 = "arm64"
X86_64 = "x86_64"
