__all__ = ["SamTemplate"]

from samtranslator.sdk.template import SamTemplate
