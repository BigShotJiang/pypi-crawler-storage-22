**To list your private certificate authorities**

The following ``list-certificate-authorities`` command lists information about all of the private CAs in your account. ::

  aws acm-pca list-certificate-authorities --max-results 10