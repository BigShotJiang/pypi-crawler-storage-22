from __future__ import annotations

import sys

from axe_cli.cli import cli

if __name__ == "__main__":
    sys.exit(cli())
