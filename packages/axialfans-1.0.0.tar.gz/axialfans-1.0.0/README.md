# AxialFans

Analytical solver for multistage ducted axial fans.

## Installation

```bash
pip install axialfans
