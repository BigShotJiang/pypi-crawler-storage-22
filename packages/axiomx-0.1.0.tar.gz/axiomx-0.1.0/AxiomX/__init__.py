import time

print("AxiomX loading...")
time.sleep(3)
print("AxiomX is ready to use!")

import constants
import calculus
import functions
import exp
import trig
import hyperbolic

version = '0.1.0'