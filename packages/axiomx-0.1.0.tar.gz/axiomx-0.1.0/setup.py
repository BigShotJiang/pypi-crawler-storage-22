from setuptools import setup, find_packages

setup(
    name="AxiomX",  # rename to your project name
    version="0.1.0",
    description="A custom Python math library with special functions.",
    author="Eric Joseph",  # change if needed
    packages=find_packages(),
    install_requires=[],
    python_requires=">=2.7",
)