# Axiron

Axiron is a powerful OSINT-focused Python library that provides high-speed asynchronous username search and email leak detection across hundreds of platforms.

## Features

 Username Search (OsiAxi)
Perform high-speed asynchronous searches across 700+ websites.

 Email Leak Checker (EmailAxi)
Check whether an email address has appeared in known data breaches.

## Installation

Install via pip:

pip install axiron

## Usage

## Username Scanner

The OsiAxi function performs a high-speed asynchronous search across 700+ sites.

import axiron

results = axiron.OsiAxi("johndoe")

print(f"Total accounts found: {len(results)}")

for account in results:
    print(f"[+] {account['platform']}: {account['link']}")

## Email Leak Checker

The EmailAxi function checks if an email has been leaked in known data breaches.

import axiron

leak = axiron.EmailAxi("test@example.com")

if leak["status"] == "leaked":
    print(f"Warning! Found in {leak['count']} breaches.")
    print(f"Sources: {', '.join(leak['sources'])}")
else:
    print("This email appears to be safe.")
	
## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.