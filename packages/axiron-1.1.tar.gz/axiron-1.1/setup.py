from setuptools import setup, find_packages
import os

if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
else:
    long_description = "BestAxiron"

setup(
    name="axiron",
    version="1.1",
    packages=find_packages(),
    include_package_data=True,
    package_data={'axiron': ['*.json']},
    install_requires=[
        "requests>=2.31.0",
        "aiohttp>=3.9.0",
    ],
    # BURASI ÖNEMLİ:
    long_description=long_description,
    long_description_content_type="text/markdown", 
    author="Axiron",
    description="Tg: BestAxiron",
    url="https://pypi.org/project/axiron/",
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)