"""Example notebooks utility package."""
