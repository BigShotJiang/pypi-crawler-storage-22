"""Endpoint service for Azure Cortex SDK."""

from typing import Any, Dict, Optional

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import Endpoint, EndpointIdentity, InferenceResponse, PaginatedResponse


class EndpointService:
    """Service for managing endpoints."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(
        self,
        page: int = 1,
        per_page: int = 25,
    ) -> PaginatedResponse:
        """List endpoints.

        Args:
            page: Page number (1-based)
            per_page: Number of items per page

        Returns:
            PaginatedResponse: Paginated list of endpoints

        """
        params = {"page": page, "perPage": per_page}
        response = self.http_client.get("/endpoints", params=params)

        # Transform response data
        documents = []
        if "documents" in response:
            documents = [
                self._transform_endpoint_data(endpoint)
                for endpoint in response["documents"]
            ]

        # Transform to PaginatedResponse format
        total_documents = response.get("totalDocuments", 0)
        current_page = response.get("page", page)
        items_per_page = response.get("perPage", per_page)

        return PaginatedResponse(
            items=documents,
            page=current_page,
            per_page=items_per_page,
            total=total_documents,
            has_next=(current_page * items_per_page) < total_documents,
            has_prev=current_page > 1,
        )

    def get(self, name: str) -> Optional[Endpoint]:
        """Get a specific endpoint by name.

        Args:
            name: Endpoint name

        Returns:
            Endpoint: The endpoint if found, None otherwise

        Raises:
            NotFoundError: If endpoint is not found

        """
        try:
            response = self.http_client.get(f"/endpoints/{name}")
            return Endpoint(**self._transform_endpoint_data(response))
        except NotFoundError:
            return None

    def create(self, name: str) -> Dict[str, str]:
        """Create a new endpoint.

        Args:
            name: Endpoint name

        Returns:
            Dict[str, str]: Creation response message

        """
        endpoint_data = EndpointIdentity(name=name)
        response = self.http_client.post(
            "/endpoints", data=endpoint_data.model_dump(by_alias=True)
        )
        return response

    def delete(self, name: str) -> Dict[str, str]:
        """Delete an endpoint.

        Args:
            name: Endpoint name

        Returns:
            Dict[str, str]: Deletion response message

        """
        endpoint_data = EndpointIdentity(name=name)
        response = self.http_client.delete(
            "/endpoints", data=endpoint_data.model_dump(by_alias=True)
        )
        return response

    def infer(self, name: str, inputs: Dict[str, Any]) -> InferenceResponse:
        """Perform inference on an endpoint.

        Args:
            name: Endpoint name
            inputs: Input data for inference

        Returns:
            InferenceResponse: The inference result

        Raises:
            NotFoundError: If endpoint is not found
            APIError: If inference fails

        """
        request_data = {"inputs": inputs}
        response = self.http_client.post(f"/endpoints/{name}/infer", data=request_data)
        return InferenceResponse(**response)

    def _transform_endpoint_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform endpoint data from API response format to model format.

        Args:
            data: Raw endpoint data from API

        Returns:
            Dict[str, Any]: Transformed endpoint data

        """
        transformed = data.copy()

        # Handle nested properties transformation if needed
        if "properties" in transformed and isinstance(transformed["properties"], dict):
            properties = transformed["properties"]

            # Transform camelCase to snake_case for specific fields
            if "provisioningState" in properties:
                properties["provisioning_state"] = properties.pop("provisioningState")
            if "publicNetworkAccess" in properties:
                properties["public_network_access"] = properties.pop(
                    "publicNetworkAccess"
                )
            if "authMode" in properties:
                properties["auth_mode"] = properties.pop("authMode")
            if "scoringUri" in properties:
                properties["scoring_uri"] = properties.pop("scoringUri")
            if "swaggerUri" in properties:
                properties["swagger_uri"] = properties.pop("swaggerUri")

        # Handle systemData transformation
        if "systemData" in transformed:
            transformed["system_data"] = transformed.pop("systemData")

        return transformed
