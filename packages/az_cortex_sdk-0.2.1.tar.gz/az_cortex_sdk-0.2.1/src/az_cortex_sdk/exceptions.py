"""Exception classes for Azure Cortex SDK."""

from typing import Any, Dict, Optional


class CortexSDKError(Exception):
    """Base exception for all Cortex SDK errors."""

    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}


class AuthenticationError(CortexSDKError):
    """Raised when authentication fails."""

    pass


class APIError(CortexSDKError):
    """Raised when API returns an error response."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_data: Optional[Dict[str, Any]] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, details)
        self.status_code = status_code
        self.response_data = response_data or {}


class ValidationError(CortexSDKError):
    """Raised when request validation fails."""

    pass


class NotFoundError(APIError):
    """Raised when a resource is not found (404)."""

    pass


class RateLimitError(APIError):
    """Raised when rate limit is exceeded (429)."""

    def __init__(self, message: str, retry_after: Optional[int] = None, **kwargs):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class TimeoutError(CortexSDKError):
    """Raised when a request times out."""

    pass


class ConnectionError(CortexSDKError):
    """Raised when connection to API fails."""

    pass


class ServerError(APIError):
    """Raised when server returns 5xx error."""

    pass
