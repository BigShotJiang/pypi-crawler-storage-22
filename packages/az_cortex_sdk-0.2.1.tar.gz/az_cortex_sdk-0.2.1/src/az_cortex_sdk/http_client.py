"""HTTP client for Azure Cortex SDK."""

import json
from typing import Any, Dict, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .auth import AuthManager
from .config import CortexConfig
from .exceptions import (
    APIError,
    ConnectionError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)


class HTTPClient:
    """HTTP client with authentication and retry logic."""

    def __init__(self, config: CortexConfig):
        self.config = config
        self.auth_manager = AuthManager(config)
        self._session = self._create_session()

    def _create_session(self) -> requests.Session:
        """Create configured requests session."""
        session = requests.Session()

        # Configure retry strategy
        # Note: 500 errors removed from retry list because they often indicate
        # API bugs (like "Not Found" returned as 500) that shouldn't be retried
        retry_strategy = Retry(
            total=self.config.max_retries,
            backoff_factor=self.config.retry_delay,
            status_forcelist=[429, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS", "POST", "PUT", "DELETE"],
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)
        # Only mount HTTPS adapter for security - Azure Cortex API only supports HTTPS
        session.mount("https://", adapter)

        return session

    def _get_headers(
        self, additional_headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, str]:
        """Get request headers with authentication."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "az-cortex-sdk/0.1.0",
        }

        # Add auth headers
        headers.update(self.auth_manager.get_auth_headers())

        # Add any additional headers
        if additional_headers:
            headers.update(additional_headers)

        return headers

    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """Handle API response and raise appropriate exceptions."""
        try:
            if response.status_code == 200:
                return response.json() if response.content else {}
            elif response.status_code == 201:
                return response.json() if response.content else {}
            elif response.status_code == 204:
                return {}
            elif response.status_code == 400:
                error_data = response.json() if response.content else {}
                raise ValidationError(
                    error_data.get("message", "Bad request"), details=error_data
                )
            elif response.status_code == 401:
                raise APIError("Authentication failed", status_code=401)
            elif response.status_code == 404:
                try:
                    error_data = response.json() if response.content else {}
                    message = error_data.get("message", "Resource not found")
                except (ValueError, TypeError):
                    # Handle HTML or non-JSON error responses
                    error_data = {}
                    message = "Resource not found"
                raise NotFoundError(
                    message,
                    status_code=404,
                    response_data=error_data,
                )
            elif response.status_code == 429:
                retry_after = response.headers.get("Retry-After")
                retry_after_int = int(retry_after) if retry_after else None
                raise RateLimitError(
                    "Rate limit exceeded", status_code=429, retry_after=retry_after_int
                )
            elif 500 <= response.status_code < 600:
                try:
                    error_data = response.json() if response.content else {}
                    message = error_data.get(
                        "message", f"Server error: {response.status_code}"
                    )

                    # Debug: print full error response
                    if (
                        not message
                        or message == f"Server error: {response.status_code}"
                    ):
                        import sys

                        print(
                            f"DEBUG: Full error response: {error_data}", file=sys.stderr
                        )
                        print(f"DEBUG: Response text: {response.text}", file=sys.stderr)

                    # Handle API bug: 500 errors with "Not Found" message should be NotFoundError
                    if "not found" in message.lower():
                        raise NotFoundError(
                            message,
                            status_code=response.status_code,
                            response_data=error_data,
                        )

                    raise ServerError(
                        message,
                        status_code=response.status_code,
                        response_data=error_data,
                    )
                except (ValueError, KeyError):
                    # Handle non-JSON error responses
                    raise ServerError(
                        f"Server error: {response.status_code}",
                        status_code=response.status_code,
                        response_data={},
                    )
            else:
                error_data = response.json() if response.content else {}
                raise APIError(
                    f"Unexpected status code: {response.status_code}",
                    status_code=response.status_code,
                    response_data=error_data,
                )

        except json.JSONDecodeError:
            raise APIError(
                f"Invalid JSON response (status: {response.status_code})",
                status_code=response.status_code,
                response_data={"raw_content": response.text},
            )

    def get(
        self, path: str, params: Optional[Dict[str, Any]] = None, stream: bool = False
    ) -> Dict[str, Any]:
        """Make GET request."""
        return self._make_request("GET", path, params=params, stream=stream)

    def _make_request(
        self,
        method: str,
        path: str,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        retry_auth: bool = True,
        stream: bool = False,
    ):
        """Make HTTP request with automatic token refresh on 401.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            path: API endpoint path
            data: Request body data (for POST/PUT)
            files: Files to upload
            headers: Additional HTTP headers
            params: Query parameters
            retry_auth: Whether to retry with new token on 401
            stream: If True, return raw response for streaming. If False, parse JSON.

        """
        url = f"{self.config.base_url}{path}"
        request_headers = self._get_headers(headers)

        # Handle multipart uploads
        if files:
            # Remove Content-Type for multipart uploads
            request_headers.pop("Content-Type", None)
            json_data = None
        else:
            json_data = data

        try:
            if method == "GET":
                response = self._session.get(
                    url,
                    headers=request_headers,
                    params=params,
                    timeout=self.config.timeout,
                )
            elif method == "POST":
                response = self._session.post(
                    url,
                    headers=request_headers,
                    json=json_data,
                    files=files,
                    timeout=self.config.timeout,
                    params=params,
                    stream=stream,
                )
            elif method == "PUT":
                response = self._session.put(
                    url,
                    headers=request_headers,
                    json=json_data,
                    timeout=self.config.timeout,
                    params=params,
                )
            elif method == "DELETE":
                response = self._session.delete(
                    url,
                    headers=request_headers,
                    json=json_data,
                    timeout=self.config.timeout,
                    params=params,
                )
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            # Handle 401 with token refresh and retry
            if response.status_code == 401 and retry_auth:
                # Try refreshing token and retry once
                self.auth_manager.get_token(force_refresh=True)
                return self._make_request(
                    method,
                    path,
                    data,
                    files,
                    headers,
                    params,
                    retry_auth=False,
                    stream=stream,
                )

            # For streaming responses, return raw response
            if stream:
                return response

            return self._handle_response(response)

        except requests.exceptions.Timeout:
            raise TimeoutError(f"Request timed out: {url}")
        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(f"Connection failed: {e}")

    def post(
        self,
        path: str,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make POST request."""
        return self._make_request(
            "POST", path, data=data, files=files, headers=headers, params=params
        )

    def put(
        self,
        path: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make PUT request."""
        return self._make_request("PUT", path, data=data, params=params)

    def delete(
        self,
        path: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make DELETE request."""
        return self._make_request("DELETE", path, data=data, params=params)

    def close(self) -> None:
        """Close the HTTP client."""
        self.auth_manager.close()
        self._session.close()
