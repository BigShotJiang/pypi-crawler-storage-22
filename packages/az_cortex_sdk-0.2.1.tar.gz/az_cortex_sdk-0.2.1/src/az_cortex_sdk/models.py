"""Data models for Azure Cortex SDK."""

from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, ConfigDict, Field


class SystemData(BaseModel):
    """System metadata for Azure ML resources."""

    created_by: Optional[str] = Field(default=None, description="Created by user")
    created_by_type: Optional[str] = Field(default=None, description="Created by type")
    created_at: Optional[datetime] = Field(
        default=None, description="Creation timestamp"
    )
    last_modified_by: Optional[str] = Field(
        default=None, description="Last modified by user"
    )
    last_modified_by_type: Optional[str] = Field(
        default=None, description="Last modified by type"
    )
    last_modified_at: Optional[datetime] = Field(
        default=None, description="Last modification timestamp"
    )


class Environment(BaseModel):
    """Environment container model."""

    name: str = Field(description="Environment name")
    id: Optional[str] = Field(default=None, description="Environment ID")
    type: Optional[str] = Field(default=None, description="Environment type")
    latest_version: Optional[str] = Field(default=None, description="Latest version")
    next_version: Optional[str] = Field(default=None, description="Next version")
    is_archived: Optional[bool] = Field(
        default=None, description="Whether environment is archived"
    )
    properties: Optional[Dict[str, Any]] = Field(
        default=None, description="Environment properties"
    )
    tags: Optional[Dict[str, str]] = Field(default=None, description="Environment tags")
    system_data: Optional[SystemData] = Field(
        default=None, description="System metadata"
    )
    versions: Optional[List[str]] = Field(
        default=None, description="Available versions"
    )
    total_versions: Optional[int] = Field(
        default=None, description="Total number of versions"
    )


class EnvironmentVersion(BaseModel):
    """Environment version model."""

    name: str = Field(description="Environment name")
    version: str = Field(description="Environment version")
    id: Optional[str] = Field(default=None, description="Environment version ID")
    type: Optional[str] = Field(default=None, description="Environment version type")
    description: Optional[str] = Field(
        default=None, description="Environment description"
    )
    image: Optional[str] = Field(default=None, description="Docker image")
    conda_file: Optional[str] = Field(
        default=None, description="Conda YAML configuration"
    )
    docker_context: Optional[str] = Field(default=None, description="Docker context")
    is_archived: Optional[bool] = Field(
        default=None, description="Whether version is archived"
    )
    tags: Optional[Dict[str, str]] = Field(default=None, description="Environment tags")
    properties: Optional[Dict[str, str]] = Field(
        default=None, description="Environment properties"
    )
    system_data: Optional[SystemData] = Field(
        default=None, description="System metadata"
    )


class Model(BaseModel):
    """Model container model."""

    name: str = Field(description="Model name")
    id: Optional[str] = Field(default=None, description="Model ID")
    type: Optional[str] = Field(default=None, description="Model type")
    latest_version: Optional[str] = Field(default=None, description="Latest version")
    is_archived: Optional[bool] = Field(
        default=None, description="Whether model is archived"
    )
    properties: Optional[Dict[str, Any]] = Field(
        default=None, description="Model properties"
    )
    tags: Optional[Dict[str, str]] = Field(default=None, description="Model tags")
    system_data: Optional[SystemData] = Field(
        default=None, description="System metadata"
    )
    versions: Optional[List[str]] = Field(
        default=None, description="Available versions"
    )
    total_versions: Optional[int] = Field(
        default=None, description="Total number of versions"
    )


class ModelVersion(BaseModel):
    """Model version model."""

    model_config = ConfigDict(protected_namespaces=())

    name: str = Field(description="Model name")
    version: str = Field(description="Model version")
    id: Optional[str] = Field(default=None, description="Model version ID")
    type: Optional[str] = Field(default=None, description="Model version type")
    description: Optional[str] = Field(default=None, description="Model description")
    model_uri: Optional[str] = Field(default=None, description="Model URI")
    model_type: Optional[str] = Field(default=None, description="Model type")
    job_name: Optional[str] = Field(default=None, description="Job name")
    is_anonymous: Optional[bool] = Field(
        default=None, description="Whether model is anonymous"
    )
    is_archived: Optional[bool] = Field(
        default=None, description="Whether model version is archived"
    )
    tags: Optional[Dict[str, str]] = Field(default=None, description="Model tags")
    properties: Optional[Dict[str, str]] = Field(
        default=None, description="Model properties"
    )
    flavors: Optional[Dict[str, Any]] = Field(default=None, description="Model flavors")
    system_data: Optional[SystemData] = Field(
        default=None, description="System metadata"
    )


class Document(BaseModel):
    """Document container model."""

    name: str = Field(description="Document name")
    id: Optional[str] = Field(default=None, description="Document ID")
    folder: Optional[str] = Field(default=None, description="Document folder")
    latest_version: Optional[str] = Field(default=None, description="Latest version")
    next_version: Optional[str] = Field(default=None, description="Next version")
    is_archived: Optional[bool] = Field(
        default=None, description="Whether document is archived"
    )
    properties: Optional[Dict[str, Any]] = Field(
        default=None, description="Document properties"
    )
    tags: Optional[Dict[str, str]] = Field(default=None, description="Document tags")
    system_data: Optional[SystemData] = Field(
        default=None, description="System metadata"
    )
    versions: Optional[List[str]] = Field(
        default=None, description="Available versions"
    )
    total_versions: Optional[int] = Field(
        default=None, description="Total number of versions"
    )


class DocumentVersion(BaseModel):
    """Document version model."""

    model_config = ConfigDict(protected_namespaces=())

    name: str = Field(description="Document name")
    version: str = Field(description="Document version")
    id: Optional[str] = Field(default=None, description="Document version ID")
    type: Optional[str] = Field(default=None, description="Document version type")
    description: Optional[str] = Field(default=None, description="Document description")
    model_uri: Optional[str] = Field(default=None, description="Document URI")
    is_archived: Optional[bool] = Field(
        default=None, description="Whether document version is archived"
    )
    tags: Optional[Dict[str, str]] = Field(default=None, description="Document tags")
    properties: Optional[Dict[str, str]] = Field(
        default=None, description="Document properties"
    )
    flavors: Optional[Dict[str, Any]] = Field(
        default=None, description="Document flavors"
    )
    system_data: Optional[SystemData] = Field(
        default=None, description="System metadata"
    )


class DocumentCollection(BaseModel):
    """Document collection model."""

    id: str = Field(default=None, description="Document collection ID", alias="_id")
    name: str = Field(description="Document collection name")
    tenant_name: str = Field(default=None, description="Tenant name", alias="tenantKey")
    app_name: str = Field(default=None, description="App name", alias="appName")


class DocumentCollectionVersion(BaseModel):
    """Document collection version model."""

    id: str = Field(
        default=None, description="Document collection version ID", alias="_id"
    )
    document_collection_name: str = Field(
        description="Document collection name", alias="collectionName"
    )
    version: int = Field(description="Document collection version")
    tenant_name: str = Field(default=None, description="Tenant name", alias="tenantKey")
    app_name: str = Field(default=None, description="App name", alias="appName")
    documents: Dict[str, str] = Field(
        description="Dictionary of document names to document versions"
    )


class UploadResult(BaseModel):
    """File upload result model."""

    success: bool = Field(description="Whether upload was successful")
    file_name: str = Field(description="Name of uploaded file")
    azure_ml_uri: Optional[str] = Field(default=None, description="Azure ML URI")
    blob_url: Optional[str] = Field(default=None, description="Blob storage URL")
    size_bytes: Optional[int] = Field(default=None, description="File size in bytes")
    error: Optional[str] = Field(default=None, description="Error message if failed")


class RegistrationResult(BaseModel):
    """Registration result model."""

    success: bool = Field(description="Whether registration was successful")
    name: str = Field(description="Resource name")
    version: str = Field(description="Resource version")
    id: Optional[str] = Field(default=None, description="Resource ID")
    error: Optional[str] = Field(default=None, description="Error message if failed")


class EscalationRoute(BaseModel):
    """Escalation route model."""

    escalation_route_id: str = Field(description="Escalation route ID")
    escalation_target_name: str = Field(description="Escalation target name")
    escalation_link: str = Field(description="Escalation link")
    escalation_tooltip: str = Field(description="Escalation tooltip")


class File(BaseModel):
    """File model."""

    id: str = Field(description="File ID", alias="_id")
    tenant_key: str = Field(description="Tenant key", alias="tenantKey")
    file_name: str = Field(description="File name", alias="fileName")
    owner_email: str = Field(description="Owner email", alias="ownerEmail")


class Inference(BaseModel):
    """Inference model."""

    id: Optional[str] = Field(default=None, description="Inference ID", alias="_id")
    tenant_key: Optional[str] = Field(default=None, description="Tenant key")
    endpoint_name: Optional[str] = Field(default=None, description="Endpoint name")
    conversation_id: Optional[str] = Field(default=None, description="Conversation ID")
    message_id: Optional[str] = Field(default=None, description="Message ID")
    email: Optional[str] = Field(default=None, description="User email")
    inferrer_name: Optional[str] = Field(default=None, description="Inferrer name")
    inputs: Optional[Dict[str, Any]] = Field(
        default=None, description="Inference inputs"
    )
    outputs: Optional[Union[Dict[str, Any], str]] = Field(
        default=None, description="Inference outputs"
    )
    annotation: Optional[str] = Field(default=None, description="Inference annotation")
    tags: Optional[List[str]] = Field(default=None, description="Inference tags")
    escalation_routes: Optional[List[EscalationRoute]] = Field(default=None, description="Escalation routes")
    duration: Optional[int] = Field(default=None, description="Inference duration in milliseconds")
    is_test_generated: Optional[bool] = Field(default=None, description="Whether this inference was generated for testing purposes", alias="isTestGenerated")
    file_ids: Optional[List[str]] = Field(default=[], description="List of file IDs associated with this inference", alias="fileIds")
    created_date: Optional[datetime] = Field(default=None, description="Creation timestamp")
    updated_date: Optional[datetime] = Field(default=None, description="Last update timestamp")

    model_config = ConfigDict(populate_by_name=True)


class Conversation(BaseModel):
    """Conversation model."""

    id: Optional[str] = Field(default=None, description="Conversation ID", alias="_id")
    tenant_key: Optional[str] = Field(default=None, description="Tenant key")
    endpoint_name: Optional[str] = Field(default=None, description="Endpoint name")
    llm_config_name: Optional[str] = Field(
        default=None, description="LLM config name", alias="llmConfigName"
    )
    name: Optional[str] = Field(default=None, description="User name")
    email: Optional[str] = Field(default=None, description="User email")
    escalation_routes: Optional[List[EscalationRoute]] = Field(
        default=None, description="Available escalation routes"
    )
    selected_escalation_route: Optional[str] = Field(
        default=None, description="Selected escalation route"
    )
    escalating_inference_id: Optional[str] = Field(
        default=None, description="Escalating inference ID"
    )
    is_escalated: Optional[bool] = Field(
        default=None, description="Whether conversation is escalated"
    )
    is_resolved: Optional[bool] = Field(
        default=None, description="Whether conversation is resolved"
    )
    is_archived: Optional[bool] = Field(
        default=None, description="Whether conversation is archived"
    )
    is_test_generated: Optional[bool] = Field(
        default=None,
        description="Whether this conversation was generated for testing purposes",
        alias="isTestGenerated",
    )
    created_date: Optional[datetime] = Field(
        default=None, description="Creation timestamp"
    )
    updated_date: Optional[datetime] = Field(
        default=None, description="Last update timestamp"
    )
    escalation_date: Optional[datetime] = Field(
        default=None, description="Escalation timestamp"
    )
    resolution_date: Optional[datetime] = Field(
        default=None, description="Resolution timestamp"
    )

    model_config = ConfigDict(populate_by_name=True)


class PaginatedResponse(BaseModel):
    """Paginated response model."""

    items: List[Any] = Field(description="List of items")
    page: int = Field(description="Current page number")
    per_page: int = Field(description="Items per page")
    total: int = Field(description="Total number of items")
    has_next: bool = Field(description="Whether there are more pages")
    has_prev: bool = Field(description="Whether there are previous pages")


class AuthToken(BaseModel):
    """OAuth token model."""

    access_token: str = Field(description="Access token")
    token_type: str = Field(default="Bearer", description="Token type")
    expires_in: int = Field(description="Token expiration in seconds")
    expires_at: Optional[datetime] = Field(
        default=None, description="Token expiration timestamp"
    )
    scope: Optional[str] = Field(default=None, description="Token scope")

    def is_expired(self) -> bool:
        """Check if token is expired."""
        if self.expires_at is None:
            return False
        return datetime.utcnow() >= self.expires_at


class ScoringScript(BaseModel):
    """Scoring script model."""

    model_config = ConfigDict(populate_by_name=True)

    name: str = Field(description="Scoring script name")
    uri: str = Field(description="Scoring script URI")
    file_name: str = Field(description="Scoring script file name", alias="fileName")


class ScoringScriptCreate(BaseModel):
    """Scoring script creation model."""

    name: str = Field(description="Scoring script name")
    content: str = Field(description="Scoring script content")


class ScoringScriptList(BaseModel):
    """Scoring script list response model."""

    model_config = ConfigDict(populate_by_name=True)

    documents: List[ScoringScript] = Field(description="List of scoring scripts")
    total_documents: int = Field(
        description="Total number of scoring scripts", alias="totalDocuments"
    )
    page: Optional[int] = Field(default=None, description="Current page number")
    per_page: Optional[int] = Field(
        default=None, description="Items per page", alias="perPage"
    )


class InferenceRequest(BaseModel):
    """Inference request model."""

    inputs: Dict[str, Any] = Field(description="Input data for inference")


class InferenceResponse(BaseModel):
    """Inference response model.

    This model is designed to handle dynamic outputs from various model types:
    - Chat/Conversational models: may have 'messages', 'content', 'role'
    - Text completion models: may have 'text', 'choices', 'completion'
    - Custom models: may have any arbitrary output structure

    The model uses flexible typing to accommodate different response formats.
    """

    model_config = ConfigDict(
        extra="allow"
    )  # Allow additional fields not explicitly defined

    # Common fields that may be present across different model types
    messages: Optional[Union[List[Dict[str, Any]], Dict[str, Any]]] = Field(
        default=None, description="Response messages (chat models)"
    )
    content: Optional[str] = Field(default=None, description="Response content")
    role: Optional[str] = Field(default=None, description="Response role")
    text: Optional[str] = Field(
        default=None, description="Generated text (completion models)"
    )
    choices: Optional[List[Dict[str, Any]]] = Field(
        default=None, description="Response choices"
    )
    completion: Optional[str] = Field(default=None, description="Text completion")
    predictions: Optional[Union[List[Any], Dict[str, Any]]] = Field(
        default=None, description="Model predictions"
    )

    # Document/RAG-related fields
    documents: Optional[List[str]] = Field(
        default=None, description="Response documents"
    )
    metadatas: Optional[List[Dict[str, Any]]] = Field(
        default=None, description="Response metadata"
    )

    # System/debug fields
    input_preview: Optional[str] = Field(default=None, description="Input preview")
    output_preview: Optional[str] = Field(default=None, description="Output preview")
    asked_followup: Optional[bool] = Field(
        default=None, description="Whether followup was asked"
    )
    retrieved_chunk_count: Optional[int] = Field(
        default=None, description="Number of retrieved chunks"
    )
    score_filtered_chunk_count: Optional[int] = Field(
        default=None, description="Number of score filtered chunks"
    )
    sections_identified_for_reconstruction: Optional[int] = Field(
        default=None, description="Sections identified for reconstruction"
    )


class Message(BaseModel):
    """Message model."""

    model_config = ConfigDict(populate_by_name=True)

    id: Optional[str] = Field(default=None, description="Message ID", alias="_id")
    tenant_key: Optional[str] = Field(
        default=None, description="Tenant key", alias="tenantKey"
    )
    endpoint_name: Optional[str] = Field(
        default=None, description="Endpoint name", alias="endpointName"
    )
    llm_config_name: Optional[str] = Field(
        default=None, description="LLM config name", alias="llmConfigName"
    )
    conversation_id: Optional[str] = Field(
        default=None, description="Conversation ID", alias="conversationId"
    )
    text: Optional[str] = Field(default=None, description="Message text")
    email: Optional[str] = Field(default=None, description="User email")
    ip_address: Optional[str] = Field(default=None, description="IP address", alias="ipAddress")
    inference_id: Optional[str] = Field(default=None, description="Inference ID", alias="inferenceId")
    auto_infer: Optional[bool] = Field(default=None, description="Whether to automatically trigger inference", alias="autoInfer")
    is_test_generated: Optional[bool] = Field(default=None, description="Whether this message was generated for testing purposes", alias="isTestGenerated")
    file_ids: Optional[List[str]] = Field(default=[], description="List of file IDs associated with this message", alias="fileIds")
    created_date: Optional[datetime] = Field(default=None, description="Creation date", alias="createdDate")
    updated_date: Optional[datetime] = Field(default=None, description="Update date", alias="updatedDate")


class MessageCreate(BaseModel):
    """Message creation model."""

    model_config = ConfigDict(populate_by_name=True)

    tenant_key: Optional[str] = Field(
        default=None, description="Tenant key", alias="tenantKey"
    )
    endpoint_name: Optional[str] = Field(
        default=None, description="Endpoint name", alias="endpointName"
    )
    llm_config_name: Optional[str] = Field(
        default=None, description="LLM config name", alias="llmConfigName"
    )
    conversation_id: Optional[str] = Field(
        default=None, description="Conversation ID", alias="conversationId"
    )
    text: Optional[str] = Field(default=None, description="Message text")
    email: Optional[str] = Field(default=None, description="User email")
    ip_address: Optional[str] = Field(
        default=None, description="IP address", alias="ipAddress"
    )
    inference_id: Optional[str] = Field(
        default=None, description="Inference ID", alias="inferenceId"
    )
    auto_infer: Optional[bool] = Field(
        default=None,
        description="Whether to automatically trigger inference (default: true)",
        alias="autoInfer",
    )
    is_test_generated: Optional[bool] = Field(
        default=None,
        description="Whether this message was generated for testing purposes",
        alias="isTestGenerated",
    )


class EndpointIdentity(BaseModel):
    """Endpoint identity model."""

    name: str = Field(description="Endpoint name")


class EndpointProperties(BaseModel):
    """Endpoint properties model."""

    model_config = ConfigDict(populate_by_name=True)

    compute: Optional[str] = Field(default=None, description="Compute target")
    provisioning_state: Optional[str] = Field(
        default=None, description="Provisioning state", alias="provisioningState"
    )
    public_network_access: Optional[str] = Field(
        default=None, description="Public network access", alias="publicNetworkAccess"
    )
    traffic: Optional[Dict[str, Any]] = Field(
        default=None, description="Traffic configuration"
    )
    auth_mode: str = Field(description="Authentication mode", alias="authMode")
    description: Optional[str] = Field(default=None, description="Endpoint description")
    keys: Optional[Dict[str, str]] = Field(
        default=None, description="Authentication keys"
    )
    properties: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional properties"
    )
    scoring_uri: Optional[str] = Field(
        default=None, description="Scoring URI", alias="scoringUri"
    )
    swagger_uri: Optional[str] = Field(
        default=None, description="Swagger URI", alias="swaggerUri"
    )


class Endpoint(BaseModel):
    """Endpoint model."""

    model_config = ConfigDict(populate_by_name=True)

    id: Optional[str] = Field(default=None, description="Endpoint ID")
    name: Optional[str] = Field(default=None, description="Endpoint name")
    type: Optional[str] = Field(default=None, description="Endpoint type")
    location: str = Field(description="Endpoint location")
    identity: Optional[Dict[str, Any]] = Field(
        default=None, description="Endpoint identity"
    )
    kind: Optional[str] = Field(default=None, description="Endpoint kind")
    properties: EndpointProperties = Field(description="Endpoint properties")
    sku: Optional[Dict[str, Any]] = Field(default=None, description="SKU information")
    tags: Optional[Dict[str, str]] = Field(default=None, description="Endpoint tags")
    system_data: Optional[SystemData] = Field(
        default=None, description="System metadata", alias="systemData"
    )


class DeploymentIdentity(BaseModel):
    """Deployment identity model."""

    name: str = Field(description="Deployment name")


class CreateDeployment(BaseModel):
    """Deployment creation model.

    Supported Azure ML instance types:
    - Standard_DS1_v2: 1 vCPU, 3.5 GB RAM (general purpose)
    - Standard_D2a_v4: 2 vCPUs, 8 GB RAM (general purpose, AMD)
    - Standard_D2as_v4: 2 vCPUs, 8 GB RAM, premium storage (general purpose, AMD)
    - Standard_E2s_v3: 2 vCPUs, 16 GB RAM, premium storage (memory optimized)
    - Standard_E4s_v3: 4 vCPUs, 32 GB RAM, premium storage (memory optimized)
    - Standard_F2s_v2: 2 vCPUs, 4 GB RAM, premium storage (compute optimized)
    - Standard_F4s_v2: 4 vCPUs, 8 GB RAM, premium storage (compute optimized)
    """

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    endpoint_name: str = Field(description="Endpoint name", alias="endpointName")
    name: str = Field(description="Deployment name")
    instance_type: str = Field(
        description="Azure ML instance type (e.g., Standard_DS1_v2, Standard_E2s_v3, Standard_F2s_v2)",
        alias="instanceType"
    )
    model_name: str = Field(description="Model name", alias="modelName")
    model_version: str = Field(description="Model version", alias="modelVersion")
    environment_name: str = Field(
        description="Environment name", alias="environmentName"
    )
    environment_version: str = Field(
        description="Environment version", alias="environmentVersion"
    )
    scoring_script_name: str = Field(
        description="Scoring script name", alias="scoringScriptName"
    )
    traffic: Dict[str, int] = Field(description="Traffic allocation")
    secrets: Optional[List[str]] = Field(default=None, description="Secret names")
    request_timeout_seconds: Optional[int] = Field(
        default=None,
        description="Request timeout in seconds (ISO 8601 duration format will be used)",
        alias="requestTimeoutSeconds"
    )
    tags: Optional[Dict[str, str]] = Field(
        default=None,
        description="Tags for the deployment (e.g., {'supportsStreaming': 'true'})"
    )


class Deployment(BaseModel):
    """Deployment model."""

    model_config = ConfigDict(populate_by_name=True)

    id: Optional[str] = Field(default=None, description="Deployment ID")
    name: Optional[str] = Field(default=None, description="Deployment name")
    type: Optional[str] = Field(default=None, description="Deployment type")
    location: str = Field(description="Deployment location")
    identity: Optional[Dict[str, Any]] = Field(
        default=None, description="Deployment identity"
    )
    kind: Optional[str] = Field(default=None, description="Deployment kind")
    properties: Dict[str, Any] = Field(description="Deployment properties")
    sku: Optional[Dict[str, Any]] = Field(default=None, description="SKU information")
    tags: Optional[Dict[str, str]] = Field(default=None, description="Deployment tags")
    system_data: Optional[SystemData] = Field(
        default=None, description="System metadata", alias="systemData"
    )


class SecretListItem(BaseModel):
    """Secret list item model."""

    name: str = Field(description="Secret name")
    enabled: Optional[bool] = Field(
        default=None, description="Whether secret is enabled"
    )
    created: Optional[str] = Field(default=None, description="Creation timestamp")
    updated: Optional[str] = Field(default=None, description="Last update timestamp")


class SecretsList(BaseModel):
    """Secrets list response model."""

    documents: List[SecretListItem] = Field(description="List of secrets")
    total_documents: int = Field(
        description="Total number of secrets", alias="totalDocuments"
    )
    page: Optional[int] = Field(default=None, description="Current page number")
    per_page: Optional[int] = Field(
        default=None, description="Items per page", alias="perPage"
    )

    model_config = ConfigDict(populate_by_name=True)


class SecretCreate(BaseModel):
    """Secret creation model."""

    name: str = Field(description="Secret name")
    value: str = Field(description="Secret value")


class SecretUpdate(BaseModel):
    """Secret update model."""

    value: str = Field(description="Secret value")


class SecretResponse(BaseModel):
    """Secret operation response model."""

    name: str = Field(description="Secret name")
    message: str = Field(description="Operation result message")


class SecretDelete(BaseModel):
    """Secret deletion model."""

    name: str = Field(description="Secret name")


class SecretValueResponse(BaseModel):
    """Secret value response model."""

    value: str = Field(description="Secret value")


class LLMDefaultParameters(BaseModel):
    """Default parameters for LLM configuration."""

    temperature: Optional[float] = Field(
        default=None, description="Controls randomness (0.0 to 2.0)"
    )
    max_tokens: Optional[int] = Field(
        default=None, description="Maximum tokens to generate"
    )
    top_p: Optional[float] = Field(
        default=None, description="Nucleus sampling parameter"
    )
    frequency_penalty: Optional[float] = Field(
        default=None, description="Penalize frequent tokens"
    )
    presence_penalty: Optional[float] = Field(
        default=None, description="Penalize tokens based on presence"
    )


class LLMConfig(BaseModel):
    """LLM configuration model."""

    id: Optional[str] = Field(default=None, description="Configuration ID", alias="_id")
    tenant_key: Optional[str] = Field(default=None, description="Tenant key")
    config_name: Optional[str] = Field(default=None, description="Configuration name")
    provider: Optional[str] = Field(
        default=None, description="LLM provider (e.g., 'openai', 'azure-openai')"
    )
    api_key: Optional[str] = Field(
        default=None,
        description="API key (auto-stored as secret, mutually exclusive with secret_name)",
    )
    secret_name: Optional[str] = Field(
        default=None,
        description="Key Vault secret name (mutually exclusive with api_key)",
    )
    endpoint: Optional[str] = Field(
        default=None, description="Endpoint URL (for Azure OpenAI)"
    )
    model: Optional[str] = Field(
        default=None, description="Model name (e.g., 'gpt-4', 'gpt-3.5-turbo')"
    )
    deployment: Optional[str] = Field(
        default=None, description="Deployment name (for Azure OpenAI)"
    )
    default_parameters: Optional[LLMDefaultParameters] = Field(
        default=None, description="Default parameters"
    )
    is_archived: Optional[bool] = Field(
        default=None, description="Whether configuration is archived"
    )
    created_date: Optional[datetime] = Field(
        default=None, description="Creation timestamp"
    )
    updated_date: Optional[datetime] = Field(
        default=None, description="Last update timestamp"
    )

    model_config = ConfigDict(populate_by_name=True)


# ============================================================================
# Embedding Configuration Models
# ============================================================================


class EmbeddingConfig(BaseModel):
    """Embedding configuration model."""

    id: Optional[str] = Field(default=None, description="Configuration ID", alias="_id")
    tenant_key: Optional[str] = Field(default=None, description="Tenant key")
    config_name: Optional[str] = Field(default=None, description="Configuration name")
    provider: Optional[str] = Field(
        default=None,
        description="Embedding provider: 'openai', 'azure-openai', 'cohere', 'mistral'",
    )
    api_key: Optional[str] = Field(
        default=None,
        description="API key (auto-stored as secret, mutually exclusive with secret_name)",
    )
    secret_name: Optional[str] = Field(
        default=None,
        description="Key Vault secret name (mutually exclusive with api_key)",
    )
    model: Optional[str] = Field(
        default=None,
        description="Model name (e.g., 'text-embedding-3-small', 'text-embedding-ada-002')",
    )
    endpoint: Optional[str] = Field(
        default=None, description="Endpoint URL (for Azure OpenAI)"
    )
    deployment: Optional[str] = Field(
        default=None, description="Deployment name (for Azure OpenAI)"
    )
    dimensions: Optional[int] = Field(
        default=None, description="Embedding dimensions (for dimension reduction)"
    )
    is_archived: Optional[bool] = Field(
        default=None, description="Whether configuration is archived"
    )
    created_date: Optional[datetime] = Field(
        default=None, description="Creation timestamp"
    )
    updated_date: Optional[datetime] = Field(
        default=None, description="Last update timestamp"
    )

    model_config = ConfigDict(populate_by_name=True)


class EmbeddingConfigListResponse(BaseModel):
    """Response model for listing embedding configurations."""

    documents: List[EmbeddingConfig] = Field(
        description="List of embedding configurations"
    )
    count: int = Field(description="Number of configurations returned")
    total: int = Field(description="Total number of configurations")
    page: int = Field(description="Current page number")
    per_page: int = Field(description="Results per page", alias="perPage")

    model_config = ConfigDict(populate_by_name=True)


class EmbeddingGenerateRequest(BaseModel):
    """Request model for generating a single embedding."""

    text: str = Field(description="Text to generate embedding for")
    dimensions: Optional[int] = Field(
        default=None, description="Override config dimensions"
    )

    model_config = ConfigDict(populate_by_name=True)


class EmbeddingUsage(BaseModel):
    """Usage information for embedding generation."""

    tokens: int = Field(description="Number of tokens used")

    model_config = ConfigDict(populate_by_name=True)


class EmbeddingGenerateResponse(BaseModel):
    """Response model for single embedding generation."""

    embedding: List[float] = Field(description="Generated embedding vector")
    usage: EmbeddingUsage = Field(description="Token usage information")

    model_config = ConfigDict(populate_by_name=True)


class EmbeddingGenerateManyRequest(BaseModel):
    """Request model for generating multiple embeddings."""

    texts: List[str] = Field(description="List of texts to generate embeddings for")
    dimensions: Optional[int] = Field(
        default=None, description="Override config dimensions"
    )
    max_parallel_calls: Optional[int] = Field(
        default=None, description="Limit parallel requests", alias="maxParallelCalls"
    )

    model_config = ConfigDict(populate_by_name=True)


class EmbeddingGenerateManyResponse(BaseModel):
    """Response model for batch embedding generation."""

    embeddings: List[List[float]] = Field(
        description="List of generated embedding vectors"
    )
    usage: EmbeddingUsage = Field(description="Token usage information")

    model_config = ConfigDict(populate_by_name=True)


class EmbeddingDeleteResponse(BaseModel):
    """Response model for embedding config deletion."""

    message: str = Field(description="Deletion confirmation message")

    model_config = ConfigDict(populate_by_name=True)


class LLMMessage(BaseModel):
    """Message format for LLM inference."""

    role: str = Field(description="Message role ('system', 'user', or 'assistant')")
    content: str = Field(description="Message content")


class LLMInferenceRequest(BaseModel):
    """LLM inference request model."""

    config_name: str = Field(description="LLM configuration name")
    inputs: Dict[str, Any] = Field(description="Input data containing messages")
    parameters: Optional[LLMDefaultParameters] = Field(
        default=None, description="Override parameters for this inference"
    )
    is_test_generated: Optional[bool] = Field(
        default=None, description="Whether this inference is test-generated"
    )


class LLMInferenceResponse(BaseModel):
    """LLM inference response model."""

    id: Optional[str] = Field(default=None, description="Inference ID", alias="_id")
    tenant_key: Optional[str] = Field(default=None, description="Tenant key")
    inference_type: Optional[str] = Field(
        default=None, description="Inference type ('endpoint' or 'llm')"
    )
    llm_config_name: Optional[str] = Field(
        default=None, description="LLM configuration name"
    )
    config_name: Optional[str] = Field(
        default=None, description="Configuration name (kept for backward compatibility)"
    )
    inputs: Optional[Dict[str, Any]] = Field(default=None, description="Input data")
    outputs: Optional[Dict[str, Any]] = Field(default=None, description="Output data")
    is_test_generated: Optional[bool] = Field(
        default=None, description="Whether this inference is test-generated"
    )
    duration: Optional[int] = Field(
        default=None, description="Inference duration in milliseconds"
    )
    created_date: Optional[datetime] = Field(
        default=None, description="Creation timestamp"
    )
    updated_date: Optional[datetime] = Field(
        default=None, description="Last update timestamp"
    )

    model_config = ConfigDict(populate_by_name=True)


class LLMDeleteResponse(BaseModel):
    """LLM configuration delete response model."""

    message: str = Field(description="Deletion confirmation message")


# Vector Database Models


class VectorConnectionOptions(BaseModel):
    """Connection options for vector database providers."""

    # pgvector options
    host: Optional[str] = Field(default=None, description="Database host")
    port: Optional[int] = Field(default=None, description="Database port")
    database: Optional[str] = Field(default=None, description="Database name")
    schema: Optional[str] = Field(default=None, description="Database schema")
    table_name: Optional[str] = Field(
        default=None, description="Table name for pgvector"
    )
    distance_strategy: Optional[str] = Field(
        default=None,
        description="Distance strategy: 'cosine', 'innerProduct', or 'euclidean'",
    )
    ssl: Optional[bool] = Field(default=None, description="Enable SSL/TLS connection")
    ssl_mode: Optional[str] = Field(
        default=None,
        alias="sslMode",
        description="SSL mode: 'disable', 'allow', 'prefer', 'require', 'verify-ca', or 'verify-full'",
    )

    # Pinecone options
    environment: Optional[str] = Field(default=None, description="Pinecone environment")
    index_name: Optional[str] = Field(default=None, description="Pinecone index name")

    # Qdrant options
    url: Optional[str] = Field(default=None, description="Qdrant URL")

    # Chroma options
    collection_name: Optional[str] = Field(default=None, description="Collection name")

    model_config = ConfigDict(populate_by_name=True, extra="allow")


class VectorConfig(BaseModel):
    """Vector database configuration model."""

    id: Optional[str] = Field(default=None, description="Configuration ID", alias="_id")
    tenant_key: Optional[str] = Field(default=None, description="Tenant key")
    config_name: Optional[str] = Field(default=None, description="Configuration name")
    provider: Optional[str] = Field(
        default=None,
        description="Vector DB provider: 'pgvector', 'pinecone', 'qdrant', 'chroma', 'weaviate'",
    )
    api_key: Optional[str] = Field(
        default=None, description="API key (auto-stored as secret)"
    )
    secret_name: Optional[str] = Field(
        default=None, description="Key Vault secret name"
    )
    connection_options: Optional[VectorConnectionOptions] = Field(
        default=None, description="Provider-specific connection options"
    )
    embedding_provider: Optional[str] = Field(
        default=None,
        description="Embedding provider: 'openai', 'azure-openai', 'cohere', 'mistral'",
    )
    embedding_model: Optional[str] = Field(
        default=None, description="Embedding model name"
    )
    embedding_secret_name: Optional[str] = Field(
        default=None, description="Secret for embedding API key"
    )
    embedding_api_key: Optional[str] = Field(
        default=None, description="Embedding API key (auto-stored as secret)"
    )
    embedding_endpoint: Optional[str] = Field(
        default=None, description="Embedding endpoint (for Azure OpenAI)"
    )
    embedding_deployment: Optional[str] = Field(
        default=None, description="Embedding deployment name (for Azure OpenAI)"
    )
    is_archived: Optional[bool] = Field(
        default=None, description="Whether configuration is archived"
    )
    created_date: Optional[datetime] = Field(
        default=None, description="Creation timestamp"
    )
    updated_date: Optional[datetime] = Field(
        default=None, description="Last update timestamp"
    )

    model_config = ConfigDict(populate_by_name=True)


class VectorDeleteResponse(BaseModel):
    """Vector configuration delete response model."""

    message: str = Field(description="Deletion confirmation message")


class CollectionData(BaseModel):
    """Vector database collection model."""

    collection_name: str = Field(description="Collection name")
    document_count: Optional[int] = Field(
        default=None, description="Number of documents in collection"
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Collection metadata"
    )
    created_date: Optional[datetime] = Field(
        default=None, description="Creation timestamp"
    )

    model_config = ConfigDict(populate_by_name=True)


class CollectionListResponse(BaseModel):
    """Response for listing collections."""

    collections: List[CollectionData] = Field(description="List of collections")
    count: int = Field(description="Total number of collections")


class DocumentData(BaseModel):
    """Document data for adding to vector database."""

    id: Optional[str] = Field(
        default=None, description="Document ID (auto-generated if not provided)"
    )
    content: str = Field(description="Document content")
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Document metadata"
    )
    vector: Optional[List[float]] = Field(
        default=None, description="Pre-computed embedding vector"
    )


class DocumentAddRequest(BaseModel):
    """Request for adding documents to a collection."""

    documents: List[DocumentData] = Field(description="List of documents to add")


class DocumentAddResponse(BaseModel):
    """Response for adding documents."""

    added_count: int = Field(description="Number of documents added")
    document_ids: List[str] = Field(description="List of document IDs")

    model_config = ConfigDict(populate_by_name=True)


class SearchResult(BaseModel):
    """Search result from vector database."""

    id: str = Field(description="Document ID")
    content: str = Field(description="Document content")
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Document metadata"
    )
    score: Optional[float] = Field(default=None, description="Similarity score")


class SearchRequest(BaseModel):
    """Request for similarity search."""

    query: str = Field(description="Text query (will be embedded)")
    k: Optional[int] = Field(default=5, description="Number of results to return")
    filter: Optional[Dict[str, Any]] = Field(
        default=None, description="Metadata filter"
    )


class SearchByVectorRequest(BaseModel):
    """Request for search by pre-computed vector."""

    vector: List[float] = Field(description="Pre-computed embedding vector")
    k: Optional[int] = Field(default=5, description="Number of results to return")
    filter: Optional[Dict[str, Any]] = Field(
        default=None, description="Metadata filter"
    )


class SearchResponse(BaseModel):
    """Response for search operations."""

    results: List[SearchResult] = Field(description="Search results")
    count: int = Field(description="Number of results returned")


class MMRSearchRequest(BaseModel):
    """Request for Maximum Marginal Relevance search (diverse results)."""

    query: str = Field(description="Text query")
    k: Optional[int] = Field(default=5, description="Number of results to return")
    fetch_k: Optional[int] = Field(
        default=20, description="Number of candidates to fetch before diversification"
    )
    lambda_param: Optional[float] = Field(
        default=0.5,
        description="Diversity parameter (0=max diversity, 1=max relevance)",
        alias="lambda",
    )
    filter: Optional[Dict[str, Any]] = Field(
        default=None, description="Metadata filter"
    )

    model_config = ConfigDict(populate_by_name=True)


class BatchSearchRequest(BaseModel):
    """Request for batch search of multiple queries."""

    queries: List[str] = Field(description="List of text queries")
    k: Optional[int] = Field(default=5, description="Number of results per query")
    filter: Optional[Dict[str, Any]] = Field(
        default=None, description="Metadata filter"
    )


class BatchSearchResult(BaseModel):
    """Result for a single query in batch search."""

    query: str = Field(description="The query text")
    results: List[SearchResult] = Field(description="Search results for this query")


class BatchSearchResponse(BaseModel):
    """Response for batch search operations."""

    results: List[BatchSearchResult] = Field(description="Results for each query")
