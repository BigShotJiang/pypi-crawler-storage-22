"""Embedding configuration service for the Cortex SDK."""

from typing import Any, Dict, List, Optional

from ..http_client import HTTPClient
from ..models import (
    EmbeddingConfig,
    EmbeddingConfigListResponse,
    EmbeddingDeleteResponse,
    EmbeddingGenerateManyResponse,
    EmbeddingGenerateResponse,
)


class EmbeddingService:
    """Service for managing embedding configurations and generating embeddings."""

    def __init__(self, http_client: HTTPClient):
        """Initialize the embedding service.

        Args:
            http_client: HTTP client for making API requests

        """
        self.http_client = http_client

    # Configuration CRUD operations

    def list(
        self,
        provider: Optional[str] = None,
        is_archived: Optional[bool] = None,
        page: int = 1,
        per_page: int = 10,
    ) -> EmbeddingConfigListResponse:
        """List embedding configurations.

        Args:
            provider: Filter by provider ('openai', 'azure-openai', 'cohere', 'mistral')
            is_archived: Filter by archived status
            page: Page number (default: 1)
            per_page: Results per page (default: 10)

        Returns:
            EmbeddingConfigListResponse: List of embedding configurations

        """
        params: Dict[str, Any] = {
            "page": page,
            "perPage": per_page,
        }

        if provider is not None:
            params["provider"] = provider
        if is_archived is not None:
            params["isArchived"] = is_archived

        response = self.http_client.get("/embedding-configs", params=params)
        transformed_response = self._transform_list_response(response)
        return EmbeddingConfigListResponse(**transformed_response)

    def get(self, config_name: str) -> EmbeddingConfig:
        """Get a specific embedding configuration.

        Args:
            config_name: Name of the configuration to retrieve

        Returns:
            EmbeddingConfig: The embedding configuration

        """
        response = self.http_client.get(f"/embedding-configs/{config_name}")
        transformed_response = self._transform_embedding_config(response)
        return EmbeddingConfig(**transformed_response)

    def create(
        self,
        config_name: str,
        provider: str,
        model: str,
        api_key: Optional[str] = None,
        secret_name: Optional[str] = None,
        endpoint: Optional[str] = None,
        deployment: Optional[str] = None,
        dimensions: Optional[int] = None,
    ) -> EmbeddingConfig:
        """Create a new embedding configuration.

        Args:
            config_name: Configuration name
            provider: Embedding provider ('openai', 'azure-openai', 'cohere', 'mistral')
            model: Model name (e.g., 'text-embedding-3-small', 'text-embedding-ada-002')
            api_key: API key (auto-stored as secret, mutually exclusive with secret_name)
            secret_name: Key Vault secret name (mutually exclusive with api_key)
            endpoint: Endpoint URL (for Azure OpenAI)
            deployment: Deployment name (for Azure OpenAI)
            dimensions: Embedding dimensions (for dimension reduction)

        Returns:
            EmbeddingConfig: The created embedding configuration

        """
        data: Dict[str, Any] = {
            "configName": config_name,
            "provider": provider,
            "model": model,
        }

        if api_key is not None:
            data["apiKey"] = api_key
        if secret_name is not None:
            data["secretName"] = secret_name
        if endpoint is not None:
            data["endpoint"] = endpoint
        if deployment is not None:
            data["deployment"] = deployment
        if dimensions is not None:
            data["dimensions"] = dimensions

        response = self.http_client.post("/embedding-configs", data=data)
        transformed_response = self._transform_embedding_config(response)
        return EmbeddingConfig(**transformed_response)

    def update(
        self,
        config_name: str,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        secret_name: Optional[str] = None,
        endpoint: Optional[str] = None,
        deployment: Optional[str] = None,
        dimensions: Optional[int] = None,
    ) -> EmbeddingConfig:
        """Update an existing embedding configuration.

        Args:
            config_name: Name of the configuration to update
            provider: Embedding provider
            model: Model name
            api_key: API key
            secret_name: Key Vault secret name
            endpoint: Endpoint URL (for Azure OpenAI)
            deployment: Deployment name (for Azure OpenAI)
            dimensions: Embedding dimensions

        Returns:
            EmbeddingConfig: The updated embedding configuration

        """
        data: Dict[str, Any] = {}

        if provider is not None:
            data["provider"] = provider
        if model is not None:
            data["model"] = model
        if api_key is not None:
            data["apiKey"] = api_key
        if secret_name is not None:
            data["secretName"] = secret_name
        if endpoint is not None:
            data["endpoint"] = endpoint
        if deployment is not None:
            data["deployment"] = deployment
        if dimensions is not None:
            data["dimensions"] = dimensions

        response = self.http_client.put(f"/embedding-configs/{config_name}", data=data)
        transformed_response = self._transform_embedding_config(response)
        return EmbeddingConfig(**transformed_response)

    def archive(self, config_name: str) -> EmbeddingConfig:
        """Archive an embedding configuration.

        Args:
            config_name: Name of the configuration to archive

        Returns:
            EmbeddingConfig: The archived embedding configuration

        """
        response = self.http_client.put(f"/embedding-configs/{config_name}/archive")
        transformed_response = self._transform_embedding_config(response)
        return EmbeddingConfig(**transformed_response)

    def delete(self, config_name: str) -> EmbeddingDeleteResponse:
        """Delete an embedding configuration.

        Args:
            config_name: Name of the configuration to delete

        Returns:
            EmbeddingDeleteResponse: Deletion confirmation

        """
        response = self.http_client.delete(f"/embedding-configs/{config_name}")
        return EmbeddingDeleteResponse(**response)

    # Embedding generation operations

    def generate_embedding(
        self,
        config_name: str,
        text: str,
        dimensions: Optional[int] = None,
    ) -> EmbeddingGenerateResponse:
        """Generate a single embedding using the specified configuration.

        Args:
            config_name: Name of the embedding configuration to use
            text: Text to generate embedding for
            dimensions: Override config dimensions

        Returns:
            EmbeddingGenerateResponse: Generated embedding and usage info

        """
        data: Dict[str, Any] = {"text": text}

        if dimensions is not None:
            data["dimensions"] = dimensions

        response = self.http_client.post(
            f"/embedding-configs/{config_name}/embed", data=data
        )
        return EmbeddingGenerateResponse(**response)

    def generate_embeddings(
        self,
        config_name: str,
        texts: List[str],
        dimensions: Optional[int] = None,
        max_parallel_calls: Optional[int] = None,
    ) -> EmbeddingGenerateManyResponse:
        """Generate multiple embeddings (batch) using the specified configuration.

        Args:
            config_name: Name of the embedding configuration to use
            texts: List of texts to generate embeddings for
            dimensions: Override config dimensions
            max_parallel_calls: Limit parallel requests

        Returns:
            EmbeddingGenerateManyResponse: Generated embeddings and usage info

        """
        data: Dict[str, Any] = {"texts": texts}

        if dimensions is not None:
            data["dimensions"] = dimensions
        if max_parallel_calls is not None:
            data["maxParallelCalls"] = max_parallel_calls

        response = self.http_client.post(
            f"/embedding-configs/{config_name}/embed-many", data=data
        )
        return EmbeddingGenerateManyResponse(**response)

    # Transformation helpers

    def _transform_embedding_config(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform API response to SDK model format."""
        transformed = {}

        field_mapping = {
            "_id": "id",
            "tenantKey": "tenant_key",
            "configName": "config_name",
            "provider": "provider",
            "apiKey": "api_key",
            "secretName": "secret_name",
            "model": "model",
            "endpoint": "endpoint",
            "deployment": "deployment",
            "dimensions": "dimensions",
            "isArchived": "is_archived",
            "createdDate": "created_date",
            "updatedDate": "updated_date",
        }

        for api_field, sdk_field in field_mapping.items():
            if api_field in data:
                transformed[sdk_field] = data[api_field]

        return transformed

    def _transform_list_response(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform list response from API format to SDK format."""
        return {
            "documents": [
                self._transform_embedding_config(config)
                for config in data.get("documents", [])
            ],
            "count": data.get("count", 0),
            "total": data.get("total", 0),
            "page": data.get("page", 1),
            "per_page": data.get("perPage", 10),
        }
