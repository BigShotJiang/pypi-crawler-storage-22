"""Environment version service for Azure Cortex SDK."""

from typing import Any, Dict, Optional

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import EnvironmentVersion, PaginatedResponse, RegistrationResult


class EnvironmentVersionService:
    """Service for managing Azure ML environment versions."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def _convert_version_to_integer(self, version: str) -> str:
        """Convert semantic version to integer for Azure ML API."""
        # Azure ML API expects integer versions, not semantic versions
        # Convert "1.0.0" -> "1", "2.1.0" -> "2", etc.
        try:
            # Try to extract the major version number
            major_version = version.split(".")[0]
            if major_version.isdigit():
                return major_version
            else:
                # If it's already an integer string, return as-is
                return version
        except (ValueError, AttributeError, IndexError):
            # Fallback: return as-is
            return version

    def list(
        self,
        environment_name: str,
        page: int = 1,
        per_page: int = 25,
        latest: bool = False,
        is_archived: bool = False,
    ) -> PaginatedResponse:
        """List environment versions with pagination and filtering."""
        params = {
            "environmentName": environment_name,
            "page": page,
            "perPage": per_page,
            "isArchived": str(is_archived).lower(),
        }

        if latest:
            params["latest"] = "true"

        try:
            response = self.http_client.get("/environment-versions", params=params)

            # Handle response format from API
            versions_data = response.get("versions", [])
            versions = [EnvironmentVersion(**item) for item in versions_data]

            return PaginatedResponse(
                items=versions,
                page=response.get("page", page),
                per_page=response.get("perPage", per_page),
                total=response.get("totalDocuments", len(versions)),
                has_next=response.get("page", page) * response.get("perPage", per_page)
                < response.get("totalDocuments", 0),
                has_prev=response.get("page", page) > 1,
            )
        except Exception as e:
            raise Exception(
                f"Failed to list environment versions for '{environment_name}': {e}"
            ) from e

    def get(self, environment_name: str, version: str) -> Optional[EnvironmentVersion]:
        """Get specific environment version."""
        try:
            # Convert version to integer format for Azure ML API
            api_version = self._convert_version_to_integer(version)
            response = self.http_client.get(
                f"/environment-versions/{api_version}",
                params={"environmentName": environment_name},
            )

            # Transform API response to match SDK model structure
            transformed_response = {
                **response,
                "name": environment_name,  # Use the environment name from the request
                "version": response.get(
                    "name", api_version
                ),  # API returns version in "name" field
            }

            # Handle isArchived field - move from properties to top level if present
            if "properties" in transformed_response and isinstance(
                transformed_response["properties"], dict
            ):
                if "isArchived" in transformed_response["properties"]:
                    transformed_response["is_archived"] = transformed_response[
                        "properties"
                    ]["isArchived"]
                    # Remove from properties to avoid validation issues
                    transformed_response["properties"] = {
                        k: v
                        for k, v in transformed_response["properties"].items()
                        if k != "isArchived"
                    }

            return EnvironmentVersion(**transformed_response)
        except NotFoundError:
            raise NotFoundError(
                f"Environment version '{environment_name}:{version}' not found"
            )
        except Exception as e:
            if "not found" in str(e).lower() or "404" in str(e):
                raise NotFoundError(
                    f"Environment version '{environment_name}:{version}' not found"
                )
            raise

    def register(
        self,
        environment_name: str,
        version: str,
        description: Optional[str] = None,
        image: Optional[str] = None,
        conda_file: Optional[str] = None,
        docker_context: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
    ) -> RegistrationResult:
        """Register (create) a new environment version."""
        data: Dict[str, Any] = {}

        if description:
            data["description"] = description
        if image:
            data["image"] = image
        if conda_file:
            data["condaFile"] = conda_file
        if docker_context:
            data["dockerContext"] = docker_context
        if tags:
            data["tags"] = tags
        if properties:
            data["properties"] = properties

        # Convert version to integer format for Azure ML API
        api_version = self._convert_version_to_integer(version)

        try:
            response = self.http_client.post(
                f"/environment-versions/{api_version}",
                params={"environmentName": environment_name},
                data=data,
            )

            return RegistrationResult(
                success=True,  # If we got here, it was successful
                name=environment_name,  # Use the original name we sent
                version=response.get(
                    "name", api_version
                ),  # API returns version in "name" field
                id=response.get("id"),
                error=None,
            )
        except Exception as e:
            return RegistrationResult(
                success=False,
                name=environment_name,
                version=version,
                id=None,
                error=str(e),
            )

    def update(
        self,
        environment_name: str,
        version: str,
        description: Optional[str] = None,
        image: Optional[str] = None,
        conda_file: Optional[str] = None,
        docker_context: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
        is_archived: Optional[bool] = None,
    ) -> EnvironmentVersion:
        """Update an existing environment version."""
        data: Dict[str, Any] = {}

        if description is not None:
            data["description"] = description
        if image is not None:
            data["image"] = image
        if conda_file is not None:
            data["condaFile"] = conda_file
        if docker_context is not None:
            data["dockerContext"] = docker_context
        if tags is not None:
            data["tags"] = tags
        if properties is not None:
            data["properties"] = properties
        if is_archived is not None:
            data["isArchived"] = is_archived

        # Convert version to integer format for Azure ML API
        api_version = self._convert_version_to_integer(version)

        try:
            response = self.http_client.put(
                f"/environment-versions/{api_version}",
                params={"environmentName": environment_name},
                data=data,
            )

            # Transform API response to match SDK model structure
            transformed_response = {
                **response,
                "name": environment_name,  # Use the environment name from the request
                "version": response.get(
                    "name", api_version
                ),  # API returns version in "name" field
            }

            # Handle isArchived field - move from properties to top level if present
            if "properties" in transformed_response and isinstance(
                transformed_response["properties"], dict
            ):
                if "isArchived" in transformed_response["properties"]:
                    transformed_response["is_archived"] = transformed_response[
                        "properties"
                    ]["isArchived"]
                    # Remove from properties to avoid validation issues
                    transformed_response["properties"] = {
                        k: v
                        for k, v in transformed_response["properties"].items()
                        if k != "isArchived"
                    }

            return EnvironmentVersion(**transformed_response)
        except Exception as e:
            raise Exception(
                f"Failed to update environment version '{environment_name}:{version}': {e}"
            ) from e

    def archive(self, environment_name: str, version: str) -> EnvironmentVersion:
        """Archive an environment version."""
        return self.update(environment_name, version, is_archived=True)

    def unarchive(self, environment_name: str, version: str) -> EnvironmentVersion:
        """Unarchive an environment version."""
        return self.update(environment_name, version, is_archived=False)
