"""Environment service for Azure Cortex SDK."""

from typing import Any, Dict, Optional

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import (
    Environment,
    EnvironmentVersion,
    PaginatedResponse,
    RegistrationResult,
)


class EnvironmentService:
    """Service for managing Azure ML environments."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def _convert_version_to_integer(self, version: str) -> str:
        """Convert semantic version to integer for Azure ML API."""
        # Azure ML API expects integer versions, not semantic versions
        # Convert "1.0.0" -> "1", "2.1.0" -> "2", etc.
        try:
            # Try to extract the major version number
            major_version = version.split(".")[0]
            if major_version.isdigit():
                return major_version
            else:
                # If it's already an integer string, return as-is
                return version
        except (ValueError, AttributeError, IndexError):
            # Fallback: return as-is
            return version

    def list(
        self, page: int = 1, per_page: int = 25, include_latest: bool = True
    ) -> PaginatedResponse:
        """List all environments with pagination."""
        params = {
            "page": page,
            "perPage": per_page,
            "includeLatest": include_latest,
        }

        response = self.http_client.get("/environments", params=params)

        # Handle both response formats: {items: []} and {documents: []}
        items_data = response.get("items", response.get("documents", []))
        total_count = response.get(
            "total", response.get("totalDocuments", len(items_data))
        )

        # Transform API response to match SDK model structure
        transformed_items = []
        for item in items_data:
            # Transform each environment item
            # API: {"properties": {"description": "...", "latestVersion": "..."}}
            # SDK: {"description": "...", "latest_version": "..."}
            transformed_item = {**item}

            if "properties" in item and isinstance(item["properties"], dict):
                props = item["properties"]
                if "description" in props:
                    transformed_item["description"] = props["description"]
                if "latestVersion" in props:
                    transformed_item["latest_version"] = props["latestVersion"]
                if "nextVersion" in props:
                    transformed_item["next_version"] = props["nextVersion"]
                if "isArchived" in props:
                    transformed_item["is_archived"] = props["isArchived"]
                if "tags" in props:
                    transformed_item["tags"] = props["tags"]
                if "properties" in props:
                    transformed_item["properties"] = props["properties"]

            transformed_items.append(transformed_item)

        environments = [Environment(**item) for item in transformed_items]

        return PaginatedResponse(
            items=environments,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=total_count,
            has_next=response.get("page", page) * response.get("perPage", per_page)
            < total_count,
            has_prev=response.get("page", page) > 1,
        )

    def get_container(self, name: str) -> Optional[Environment]:
        """Get environment container (base environment info without version details)."""
        try:
            response = self.http_client.get(f"/environments/{name}")

            # Transform API response to match SDK model structure
            transformed_response = {**response}

            if "properties" in response and isinstance(response["properties"], dict):
                props = response["properties"]
                if "description" in props:
                    transformed_response["description"] = props["description"]
                if "latestVersion" in props:
                    transformed_response["latest_version"] = props["latestVersion"]
                if "nextVersion" in props:
                    transformed_response["next_version"] = props["nextVersion"]
                if "isArchived" in props:
                    transformed_response["is_archived"] = props["isArchived"]
                if "tags" in props:
                    transformed_response["tags"] = props["tags"]
                if "properties" in props:
                    transformed_response["properties"] = props["properties"]

            return Environment(**transformed_response)
        except NotFoundError:
            raise
        except Exception:
            return None

    def update_container(
        self,
        name: str,
        description: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        is_archived: Optional[bool] = None,
    ) -> Environment:
        """Update environment container (archive/unarchive, update description, etc.)."""
        data = {}
        if description is not None:
            data["description"] = description
        if tags is not None:
            data["tags"] = tags
        if is_archived is not None:
            data["isArchived"] = is_archived

        response = self.http_client.put(f"/environments/{name}", data=data)

        # Transform API response to match SDK model structure
        transformed_response = {**response}

        if "properties" in response and isinstance(response["properties"], dict):
            props = response["properties"]
            if "description" in props:
                transformed_response["description"] = props["description"]
            if "latestVersion" in props:
                transformed_response["latest_version"] = props["latestVersion"]
            if "nextVersion" in props:
                transformed_response["next_version"] = props["nextVersion"]
            if "isArchived" in props:
                transformed_response["is_archived"] = props["isArchived"]
            if "tags" in props:
                transformed_response["tags"] = props["tags"]
            if "properties" in props:
                transformed_response["properties"] = props["properties"]

        return Environment(**transformed_response)

    def get(self, name: str, version: str) -> Optional[EnvironmentVersion]:
        """Get specific environment version."""
        try:
            # Convert version to integer format for Azure ML API
            api_version = self._convert_version_to_integer(version)
            # Use the correct API endpoint: GET /environment-versions/{version}?environmentName={name}
            response = self.http_client.get(
                f"/environment-versions/{api_version}?environmentName={name}"
            )

            # Transform API response to match SDK model structure
            # API returns: {"name": "1", "properties": {...}, ...}
            # SDK expects: {"name": "env-name", "version": "1", ...}
            transformed_response = {
                **response,
                "name": name,  # Use the environment name from the request
                "version": version,  # Use the original version from the request
            }

            # Extract nested properties if they exist
            if "properties" in response and isinstance(response["properties"], dict):
                props = response["properties"]
                # Map common properties from nested structure
                if "description" in props:
                    transformed_response["description"] = props["description"]
                if "image" in props:
                    transformed_response["image"] = props["image"]
                if "condaFile" in props:
                    transformed_response["conda_file"] = props["condaFile"]
                if "dockerFile" in props:
                    transformed_response["docker_file"] = props["dockerFile"]
                if "isAnonymous" in props:
                    transformed_response["is_anonymous"] = props["isAnonymous"]
                if "isArchived" in props:
                    transformed_response["is_archived"] = props["isArchived"]
                if "tags" in props:
                    transformed_response["tags"] = props["tags"]
                if "properties" in props:
                    transformed_response["properties"] = props["properties"]

            return EnvironmentVersion(**transformed_response)
        except NotFoundError:
            # Re-raise NotFoundError so error handling tests work correctly
            raise
        except Exception:
            return None

    def list_versions(
        self, name: str, page: int = 1, per_page: int = 25
    ) -> PaginatedResponse:
        """List all versions of an environment."""
        params = {
            "page": page,
            "perPage": per_page,
        }

        response = self.http_client.get(f"/environments/{name}/versions", params=params)

        versions = [EnvironmentVersion(**item) for item in response.get("items", [])]

        return PaginatedResponse(
            items=versions,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=response.get("total", len(versions)),
            has_next=response.get("page", page) * response.get("perPage", per_page)
            < response.get("total", 0),
            has_prev=response.get("page", page) > 1,
        )

    def create(
        self,
        name: str,
        version: str,
        description: Optional[str] = None,
        image: Optional[str] = None,
        conda_file: Optional[str] = None,
        docker_context: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
    ) -> RegistrationResult:
        """Create a new environment version."""
        data: Dict[str, Any] = {
            "name": name,
            "version": version,
        }

        if description:
            data["description"] = description
        if image:
            data["image"] = image
        if conda_file:
            data["condaFile"] = conda_file
        if docker_context:
            data["dockerContext"] = docker_context
        if tags:
            data["tags"] = tags
        if properties:
            data["properties"] = properties

        # Convert version to integer format for Azure ML API
        api_version = self._convert_version_to_integer(version)

        # Use the correct API endpoint: POST /environment-versions/{version}?environmentName={name}
        response = self.http_client.post(
            f"/environment-versions/{api_version}?environmentName={name}", data=data
        )

        return RegistrationResult(
            success=response.get(
                "success", True
            ),  # Use API response or default to True
            name=name,  # Use the original name we sent
            version=version,  # Use the original version we sent
            id=response.get("id"),
            error=response.get("error"),
        )

    def update(
        self,
        name: str,
        version: str,
        description: Optional[str] = None,
        image: Optional[str] = None,
        conda_file: Optional[str] = None,
        docker_context: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
    ) -> RegistrationResult:
        """Update an existing environment version."""
        data: Dict[str, Any] = {}

        if description is not None:
            data["description"] = description
        if image is not None:
            data["image"] = image
        if conda_file is not None:
            data["condaFile"] = conda_file
        if docker_context is not None:
            data["dockerContext"] = docker_context
        if tags is not None:
            data["tags"] = tags
        if properties is not None:
            data["properties"] = properties

        response = self.http_client.put(
            f"/environments/{name}/versions/{version}", data=data
        )

        return RegistrationResult(
            success=response.get("success", True),
            name=response.get("name", name),
            version=response.get("version", version),
            id=response.get("id"),
            error=response.get("error"),
        )

    def delete(self, name: str, version: str) -> Dict[str, Any]:
        """Delete an environment version."""
        # Note: API does not currently support DELETE operations for environments
        raise NotImplementedError(
            "Delete operations are not supported by the API. "
            "Environment versions cannot be deleted via the API."
        )

    def delete_all_versions(self, name: str) -> Dict[str, Any]:
        """Delete all versions of an environment."""
        # Note: API does not currently support DELETE operations for environments
        raise NotImplementedError(
            "Delete operations are not supported by the API. "
            "Environments cannot be deleted via the API."
        )
