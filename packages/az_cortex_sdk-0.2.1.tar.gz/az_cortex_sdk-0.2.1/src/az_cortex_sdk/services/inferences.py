"""Inference service for Azure Cortex SDK."""

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Union

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import (
    Inference,
    InferenceResponse,
    PaginatedResponse,
)


class InferenceService:
    """Service for managing inferences."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def infer(
        self,
        endpoint_name: str,
        inputs: Dict[str, Any],
        is_test_generated: Optional[bool] = None,
    ) -> InferenceResponse:
        """Perform inference on an endpoint.

        Args:
            endpoint_name: Endpoint name
            inputs: Input data for inference
            is_test_generated: Whether this inference is test-generated (optional)

        Returns:
            InferenceResponse: The inference result

        Raises:
            NotFoundError: If endpoint is not found
            APIError: If inference fails

        """
        request_data = {"inputs": inputs}
        if is_test_generated is not None:
            request_data["isTestGenerated"] = is_test_generated
        response = self.http_client.post(
            f"/endpoints/{endpoint_name}/infer", data=request_data
        )
        return InferenceResponse(**response)

    def list(
        self,
        endpoint_name: Optional[str] = None,
        conversation_id: Optional[str] = None,
        message_id: Optional[str] = None,
        email: Optional[str] = None,
        has_annotation: Optional[bool] = None,
        with_tags: Optional[Union[bool, str]] = None,
        is_test_generated: Optional[Literal["true", "false", "all"]] = None,
        created_date_start: Optional[datetime] = None,
        created_date_end: Optional[datetime] = None,
        updated_date_start: Optional[datetime] = None,
        updated_date_end: Optional[datetime] = None,
        page: int = 1,
        per_page: int = 25,
    ) -> PaginatedResponse:
        """List inferences with optional filtering.

        Args:
            endpoint_name: Filter by endpoint name
            conversation_id: Filter by conversation ID
            message_id: Filter by message ID
            email: Filter by user email
            has_annotation: Filter by presence of annotation (True/False)
            with_tags: Filter by tags. Can be:
                - bool: True = has any tags, False = has no tags
                - str: specific tag name (e.g., 'Bad', 'Good', 'Drift Detection')
            is_test_generated: Filter by test generation status:
                - None (default): Hide test-generated inferences (same as 'false')
                - 'false': Hide test-generated inferences
                - 'true': Show only test-generated inferences
                - 'all': Show all inferences regardless of test generation status
            created_date_start: Filter by creation date (start)
            created_date_end: Filter by creation date (end)
            updated_date_start: Filter by update date (start)
            updated_date_end: Filter by update date (end)
            page: Page number (1-based)
            per_page: Items per page

        Returns:
            PaginatedResponse containing Inference objects

        Note:
            By default, test-generated inferences are hidden. To see test data,
            explicitly set is_test_generated='true' or is_test_generated='all'.

        """
        params = {
            "page": page,
            "perPage": per_page,
        }

        if endpoint_name is not None:
            params["endpointName"] = endpoint_name
        if conversation_id is not None:
            params["conversationId"] = conversation_id
        if message_id is not None:
            params["messageId"] = message_id
        if email is not None:
            params["email"] = email
        if has_annotation is not None:
            params["hasAnnotation"] = "true" if has_annotation else "false"
        if with_tags is not None:
            if isinstance(with_tags, bool):
                # Boolean: True = has any tags, False = has no tags
                params["withTags"] = "true" if with_tags else "false"
            else:
                # String: specific tag name to filter by
                params["withTags"] = str(with_tags)

        # Handle isTestGenerated filtering with default behavior
        if is_test_generated is None:
            # Default: hide test-generated inferences
            params["isTestGenerated"] = "false"
        elif is_test_generated != "all":
            # Explicit 'true' or 'false' value
            params["isTestGenerated"] = is_test_generated
        # If is_test_generated == "all", don't add the parameter to show all

        if created_date_start is not None:
            params["createdDateStart"] = self._format_datetime_param(created_date_start)
        if created_date_end is not None:
            params["createdDateEnd"] = self._format_datetime_param(created_date_end)
        if updated_date_start is not None:
            params["updatedDateStart"] = self._format_datetime_param(updated_date_start)
        if updated_date_end is not None:
            params["updatedDateEnd"] = self._format_datetime_param(updated_date_end)

        response = self.http_client.get("/inferences", params=params)

        # Handle response format: {documents: [], totalDocuments: N, page: N, perPage: N}
        items_data = response.get("documents", [])
        total_count = response.get("totalDocuments", len(items_data))

        # Transform API response to match SDK model structure
        transformed_items = []
        for item in items_data:
            transformed_item = self._transform_inference_data(item)
            transformed_items.append(transformed_item)

        inferences = [Inference(**item) for item in transformed_items]

        return PaginatedResponse(
            items=inferences,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=total_count,
            has_next=response.get("page", page) * response.get("perPage", per_page)
            < total_count,
            has_prev=response.get("page", page) > 1,
        )

    def get(self, inference_id: str) -> Optional[Inference]:
        """Get specific inference by ID."""
        try:
            response = self.http_client.get(f"/inferences/{inference_id}")
            transformed_response = self._transform_inference_data(response)
            return Inference(**transformed_response)
        except NotFoundError:
            raise
        except Exception:
            return None

    def update(
        self,
        inference_id: str,
        annotation: Optional[str] = None,
        tags: Optional[List[str]] = None,
        is_test_generated: Optional[bool] = None,
        **kwargs: Any,
    ) -> Inference:
        """Update inference (admin only)."""
        data = {}

        if annotation is not None:
            data["annotation"] = annotation
        if tags is not None:
            data["tags"] = tags
        if is_test_generated is not None:
            data["isTestGenerated"] = is_test_generated

        # Allow additional fields to be updated
        for key, value in kwargs.items():
            if value is not None:
                data[key] = value

        response = self.http_client.put(f"/inferences/{inference_id}", data=data)
        transformed_response = self._transform_inference_data(response)
        return Inference(**transformed_response)

    def list_test_inferences(
        self,
        endpoint_name: Optional[str] = None,
        conversation_id: Optional[str] = None,
        message_id: Optional[str] = None,
        email: Optional[str] = None,
        has_annotation: Optional[bool] = None,
        with_tags: Optional[Union[bool, str]] = None,
        created_date_start: Optional[datetime] = None,
        created_date_end: Optional[datetime] = None,
        updated_date_start: Optional[datetime] = None,
        updated_date_end: Optional[datetime] = None,
        page: int = 1,
        per_page: int = 25,
    ) -> PaginatedResponse:
        """List test-generated inferences only.

        This is a convenience method that automatically filters for test-generated
        inferences by setting is_test_generated='true'.

        Args:
            endpoint_name: Filter by endpoint name
            conversation_id: Filter by conversation ID
            message_id: Filter by message ID
            email: Filter by user email
            has_annotation: Filter by presence of annotation (True/False)
            with_tags: Filter by tags. Can be:
                - bool: True = has any tags, False = has no tags
                - str: specific tag name (e.g., 'Bad', 'Good', 'Drift Detection')
            created_date_start: Filter by creation date (start)
            created_date_end: Filter by creation date (end)
            updated_date_start: Filter by update date (start)
            updated_date_end: Filter by update date (end)
            page: Page number (1-based)
            per_page: Items per page

        Returns:
            PaginatedResponse containing test-generated Inference objects

        """
        return self.list(
            endpoint_name=endpoint_name,
            conversation_id=conversation_id,
            message_id=message_id,
            email=email,
            has_annotation=has_annotation,
            with_tags=with_tags,
            is_test_generated="true",
            created_date_start=created_date_start,
            created_date_end=created_date_end,
            updated_date_start=updated_date_start,
            updated_date_end=updated_date_end,
            page=page,
            per_page=per_page,
        )

    def _format_datetime_param(self, date_param) -> str:
        """Format datetime parameter for API request."""
        if hasattr(date_param, "isoformat"):
            # It's a datetime object
            return date_param.replace(tzinfo=None).isoformat() + 'Z'
        else:
            # It's a string - ensure it's in proper ISO format
            date_str = str(date_param)
            # If it's just a date (YYYY-MM-DD), add time component
            if len(date_str) == 10 and date_str.count("-") == 2:
                return f"{date_str}T00:00:00Z"
            # If it doesn't end with Z or timezone, add Z
            elif "T" in date_str and not (
                date_str.endswith("Z")
                or "+" in date_str[-6:]
                or date_str.endswith("+00:00")
            ):
                return f"{date_str}Z"
            else:
                return date_str

    def _transform_inference_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform API response data to match SDK model structure."""
        transformed = {**data}

        # Transform field names from API format to SDK format
        field_mappings = {
            "_id": "id",
            "tenantKey": "tenant_key",
            "endpointName": "endpoint_name",
            "conversationId": "conversation_id",
            "messageId": "message_id",
            "inferrerName": "inferrer_name",
            "escalationRoutes": "escalation_routes",
            "isTestGenerated": "is_test_generated",
            "createdDate": "created_date",
            "updatedDate": "updated_date",
        }

        for api_field, sdk_field in field_mappings.items():
            if api_field in data:
                transformed[sdk_field] = data[api_field]
                if api_field != sdk_field:  # Don't delete if same name
                    transformed.pop(api_field, None)

        # Transform escalation routes if present
        if "escalation_routes" in transformed and transformed["escalation_routes"]:
            escalation_routes = []
            for route in transformed["escalation_routes"]:
                escalation_route = {
                    "escalation_route_id": route.get("escalationRouteId"),
                    "escalation_target_name": route.get("escalationTargetName"),
                    "escalation_link": route.get("escalationLink"),
                    "escalation_tooltip": route.get("escalationTooltip"),
                }
                escalation_routes.append(escalation_route)
            transformed["escalation_routes"] = escalation_routes

        # Parse datetime strings if present
        for date_field in ["created_date", "updated_date"]:
            if date_field in transformed and transformed[date_field]:
                try:
                    transformed[date_field] = datetime.fromisoformat(
                        transformed[date_field].replace("Z", "+00:00")
                    )
                except (ValueError, AttributeError):
                    pass  # Keep original value if parsing fails

        return transformed
