"""LLM service for Azure Cortex SDK."""

from typing import Any, Dict, List, Optional

from ..http_client import HTTPClient
from ..models import (
    LLMConfig,
    LLMDeleteResponse,
    LLMInferenceResponse,
    PaginatedResponse,
)


class LLMService:
    """Service for managing LLM configurations and performing inference."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(
        self,
        provider: Optional[str] = None,
        is_archived: Optional[bool] = None,
        page: int = 1,
        per_page: int = 25,
    ) -> PaginatedResponse:
        """List all LLM configurations with pagination.

        Args:
            provider: Filter by provider (e.g., 'openai', 'azure-openai')
            is_archived: Include archived configs
            page: Page number
            per_page: Items per page

        Returns:
            PaginatedResponse: Paginated list of LLM configurations

        """
        params: Dict[str, Any] = {
            "page": page,
            "perPage": per_page,
        }

        if provider is not None:
            params["provider"] = provider
        if is_archived is not None:
            # Convert boolean to lowercase string for API compatibility
            params["isArchived"] = str(is_archived).lower()

        response = self.http_client.get("/llm-configs", params=params)

        # Handle response format: {documents: [], totalDocuments: N}
        items_data = response.get("documents", [])
        total_count = response.get("totalDocuments", len(items_data))

        # Transform API response to match SDK model structure
        transformed_items = []
        for item in items_data:
            transformed_item = self._transform_llm_config(item)
            transformed_items.append(transformed_item)

        return PaginatedResponse(
            items=[LLMConfig(**item) for item in transformed_items],
            total=total_count,
            page=page,
            per_page=per_page,
            has_next=page * per_page < total_count,
            has_prev=page > 1,
        )

    def get(self, config_name: str) -> Optional[LLMConfig]:
        """Get a specific LLM configuration by name.

        Args:
            config_name: Configuration name

        Returns:
            LLMConfig: The LLM configuration

        """
        response = self.http_client.get(f"/llm-configs/{config_name}")
        transformed_response = self._transform_llm_config(response)
        return LLMConfig(**transformed_response)

    def create(
        self,
        config_name: str,
        provider: str,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        secret_name: Optional[str] = None,
        endpoint: Optional[str] = None,
        deployment: Optional[str] = None,
        default_parameters: Optional[Dict[str, Any]] = None,
    ) -> LLMConfig:
        """Create a new LLM configuration.

        Args:
            config_name: Configuration name
            provider: LLM provider ('openai', 'azure-openai', etc.)
            model: Model name (e.g., 'gpt-4', 'gpt-3.5-turbo')
            api_key: API key (auto-stored as secret, mutually exclusive with secret_name)
            secret_name: Key Vault secret name (mutually exclusive with api_key)
            endpoint: Endpoint URL (for Azure OpenAI)
            deployment: Deployment name (for Azure OpenAI)
            default_parameters: Default parameters for inference

        Returns:
            LLMConfig: The created LLM configuration

        Note:
            Either api_key or secret_name must be provided, but not both.
            If api_key is provided, it will be automatically stored as a secret
            with the name "llm-{config_name}".

        """
        data: Dict[str, Any] = {
            "configName": config_name,
            "provider": provider,
        }

        if model is not None:
            data["model"] = model
        if api_key is not None:
            data["apiKey"] = api_key
        if secret_name is not None:
            data["secretName"] = secret_name
        if endpoint is not None:
            data["endpoint"] = endpoint
        if deployment is not None:
            data["deployment"] = deployment
        if default_parameters is not None:
            data["defaultParameters"] = self._transform_parameters_to_api(
                default_parameters
            )

        response = self.http_client.post("/llm-configs", data=data)
        transformed_response = self._transform_llm_config(response)
        return LLMConfig(**transformed_response)

    def update(
        self,
        config_name: str,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        secret_name: Optional[str] = None,
        endpoint: Optional[str] = None,
        deployment: Optional[str] = None,
        default_parameters: Optional[Dict[str, Any]] = None,
    ) -> LLMConfig:
        """Update an existing LLM configuration.

        Args:
            config_name: Configuration name
            provider: LLM provider
            model: Model name
            api_key: API key (auto-stored as secret, mutually exclusive with secret_name)
            secret_name: Key Vault secret name (mutually exclusive with api_key)
            endpoint: Endpoint URL
            deployment: Deployment name
            default_parameters: Default parameters for inference

        Returns:
            LLMConfig: The updated LLM configuration

        Note:
            Cannot provide both api_key and secret_name.
            If api_key is provided, it will update or create the secret.

        """
        data: Dict[str, Any] = {}

        if provider is not None:
            data["provider"] = provider
        if model is not None:
            data["model"] = model
        if api_key is not None:
            data["apiKey"] = api_key
        if secret_name is not None:
            data["secretName"] = secret_name
        if endpoint is not None:
            data["endpoint"] = endpoint
        if deployment is not None:
            data["deployment"] = deployment
        if default_parameters is not None:
            data["defaultParameters"] = self._transform_parameters_to_api(
                default_parameters
            )

        response = self.http_client.put(f"/llm-configs/{config_name}", data=data)
        transformed_response = self._transform_llm_config(response)
        return LLMConfig(**transformed_response)

    def archive(self, config_name: str) -> LLMConfig:
        """Archive an LLM configuration (soft delete).

        Args:
            config_name: Configuration name

        Returns:
            LLMConfig: The archived LLM configuration

        """
        response = self.http_client.put(f"/llm-configs/{config_name}/archive", data={})
        transformed_response = self._transform_llm_config(response)
        return LLMConfig(**transformed_response)

    def delete(self, config_name: str) -> LLMDeleteResponse:
        """Hard delete an LLM configuration and associated secret if not in use.

        Args:
            config_name: Configuration name

        Returns:
            LLMDeleteResponse: Deletion confirmation message

        Note:
            This permanently deletes the configuration. If the associated secret
            is not used by other configurations, it will also be deleted.

        """
        response = self.http_client.delete(f"/llm-configs/{config_name}")
        return LLMDeleteResponse(**response)

    def infer(
        self,
        config_name: str,
        messages: List[Dict[str, str]],
        parameters: Optional[Dict[str, Any]] = None,
        is_test_generated: Optional[bool] = None,
    ) -> LLMInferenceResponse:
        """Perform LLM inference using a configured LLM.

        Args:
            config_name: LLM configuration name
            messages: List of messages with 'role' and 'content' keys
            parameters: Optional parameters to override defaults
            is_test_generated: Whether this inference is test-generated

        Returns:
            LLMInferenceResponse: The inference result

        """
        data: Dict[str, Any] = {
            "inputs": {
                "messages": messages,
            },
        }

        if parameters is not None:
            data["parameters"] = self._transform_parameters_to_api(parameters)
        if is_test_generated is not None:
            data["isTestGenerated"] = is_test_generated

        response = self.http_client.post(f"/llm-configs/{config_name}/infer", data=data)
        transformed_response = self._transform_llm_inference(response)
        return LLMInferenceResponse(**transformed_response)

    def infer_stream(
        self,
        config_name: str,
        messages: List[Dict[str, str]],
        parameters: Optional[Dict[str, Any]] = None,
        is_test_generated: Optional[bool] = None,
    ):
        r"""Perform streaming LLM inference using a configured LLM.

        Args:
            config_name: LLM configuration name
            messages: List of messages with 'role' and 'content' keys
            parameters: Optional parameters to override defaults
            is_test_generated: Whether this inference is test-generated

        Yields:
            Dict: Streaming events with 'type' and data fields
                - type='chunk': {'type': 'chunk', 'content': str}
                - type='done': {'type': 'done', 'usage': dict}
                - type='error': {'type': 'error', 'message': str}

        Example:
            >>> for event in client.llm.infer_stream("my-config", messages):
            ...     if event['type'] == 'chunk':
            ...         print(event['content'], end='', flush=True)
            ...     elif event['type'] == 'done':
            ...         print(f"\nUsage: {event['usage']}")

        """
        import json

        data: Dict[str, Any] = {
            "inputs": {
                "messages": messages,
            },
        }

        if parameters is not None:
            data["parameters"] = self._transform_parameters_to_api(parameters)
        if is_test_generated is not None:
            data["isTestGenerated"] = is_test_generated

        # Make streaming request
        response = self.http_client._make_request(
            "POST", f"/llm-configs/{config_name}/stream", data=data, stream=True
        )

        # Parse Server-Sent Events
        for line in response.iter_lines():
            if line:
                line_str = line.decode("utf-8")
                if line_str.startswith("data: "):
                    event_data = line_str[6:]  # Remove 'data: ' prefix
                    try:
                        event = json.loads(event_data)
                        yield event
                    except json.JSONDecodeError:
                        # Skip malformed events
                        continue

    def _transform_llm_config(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform API response to SDK model format."""
        transformed = {}

        # Map API fields to SDK fields
        field_mapping = {
            "_id": "id",
            "tenantKey": "tenant_key",
            "configName": "config_name",
            "provider": "provider",
            "apiKey": "api_key",
            "secretName": "secret_name",
            "endpoint": "endpoint",
            "model": "model",
            "deployment": "deployment",
            "isArchived": "is_archived",
            "createdDate": "created_date",
            "updatedDate": "updated_date",
        }

        for api_field, sdk_field in field_mapping.items():
            if api_field in data:
                transformed[sdk_field] = data[api_field]

        # Transform defaultParameters
        if "defaultParameters" in data and data["defaultParameters"]:
            params = data["defaultParameters"]
            transformed["default_parameters"] = {
                "temperature": params.get("temperature"),
                "max_tokens": params.get("maxTokens"),
                "top_p": params.get("topP"),
                "frequency_penalty": params.get("frequencyPenalty"),
                "presence_penalty": params.get("presencePenalty"),
            }

        return transformed

    def _transform_llm_inference(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform API inference response to SDK model format."""
        transformed = {}

        field_mapping = {
            "_id": "id",
            "tenantKey": "tenant_key",
            "inferenceType": "inference_type",
            "llmConfigName": "llm_config_name",
            "configName": "config_name",
            "inputs": "inputs",
            "outputs": "outputs",
            "isTestGenerated": "is_test_generated",
            "duration": "duration",
            "createdDate": "created_date",
            "updatedDate": "updated_date",
        }

        for api_field, sdk_field in field_mapping.items():
            if api_field in data:
                transformed[sdk_field] = data[api_field]

        return transformed

    def _transform_parameters_to_api(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Transform SDK parameters to API format."""
        api_params = {}

        param_mapping = {
            "temperature": "temperature",
            "max_tokens": "maxTokens",
            "top_p": "topP",
            "frequency_penalty": "frequencyPenalty",
            "presence_penalty": "presencePenalty",
        }

        for sdk_field, api_field in param_mapping.items():
            if sdk_field in params and params[sdk_field] is not None:
                api_params[api_field] = params[sdk_field]

        return api_params
