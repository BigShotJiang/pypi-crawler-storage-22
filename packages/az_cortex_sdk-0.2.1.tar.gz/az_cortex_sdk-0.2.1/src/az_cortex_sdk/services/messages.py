"""Message service for Azure Cortex SDK."""

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import Message, MessageCreate, PaginatedResponse


class MessageService:
    """Service for managing messages."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(
        self,
        tenant_key: Optional[str] = None,
        endpoint_name: Optional[str] = None,
        conversation_id: Optional[str] = None,
        email: Optional[str] = None,
        text: Optional[str] = None,
        inference_id: Optional[str] = None,
        is_test_generated: Optional[Literal["true", "false", "all"]] = None,
        created_date_start: Optional[datetime] = None,
        created_date_end: Optional[datetime] = None,
        page: int = 1,
        per_page: int = 25,
    ) -> PaginatedResponse:
        """List messages with optional filtering.

        Args:
            tenant_key: Filter by tenant key
            endpoint_name: Filter by endpoint name
            conversation_id: Filter by conversation ID
            email: Filter by user email
            text: Filter by message text
            inference_id: Filter by inference ID
            is_test_generated: Filter by test generation status:
                - None (default): Hide test-generated messages (same as 'false')
                - 'false': Hide test-generated messages
                - 'true': Show only test-generated messages
                - 'all': Show all messages regardless of test generation status
            created_date_start: Filter by creation date (start)
            created_date_end: Filter by creation date (end)
            page: Page number (1-based)
            per_page: Number of items per page

        Returns:
            PaginatedResponse: Paginated list of messages

        Note:
            By default, test-generated messages are hidden. To see test data,
            explicitly set is_test_generated='true' or is_test_generated='all'.

        """
        params = {"page": page, "perPage": per_page}

        # Add optional filters
        if tenant_key is not None:
            params["tenantKey"] = tenant_key
        if endpoint_name is not None:
            params["endpointName"] = endpoint_name
        if conversation_id is not None:
            params["conversationId"] = conversation_id
        if email is not None:
            params["email"] = email
        if text is not None:
            params["text"] = text
        if inference_id is not None:
            params["inferenceId"] = inference_id

        # Handle isTestGenerated filtering with default behavior
        if is_test_generated is None:
            # Default: hide test-generated messages
            params["isTestGenerated"] = "false"
        elif is_test_generated != "all":
            # Explicit 'true' or 'false' value
            params["isTestGenerated"] = is_test_generated
        # If is_test_generated == "all", don't add the parameter to show all

        if created_date_start is not None:
            params["createdDateStart"] = created_date_start.isoformat()
        if created_date_end is not None:
            params["createdDateEnd"] = created_date_end.isoformat()

        response = self.http_client.get("/messages", params=params)

        # Transform response data
        documents = []
        if "documents" in response:
            documents = [
                self._transform_message_data(msg) for msg in response["documents"]
            ]

        # Transform to PaginatedResponse format
        total_documents = response.get("totalDocuments", 0)
        current_page = response.get("page", page)
        items_per_page = response.get("perPage", per_page)

        return PaginatedResponse(
            items=documents,
            page=current_page,
            per_page=items_per_page,
            total=total_documents,
            has_next=(current_page * items_per_page) < total_documents,
            has_prev=current_page > 1,
        )

    def get(self, message_id: str) -> Optional[Message]:
        """Get a specific message by ID.

        Args:
            message_id: Message ID

        Returns:
            Message: The message if found, None otherwise

        Raises:
            NotFoundError: If message is not found

        """
        try:
            response = self.http_client.get(f"/messages/{message_id}")
            return Message(**self._transform_message_data(response))
        except NotFoundError:
            return None

    def create(
        self,
        tenant_key: Optional[str] = None,
        endpoint_name: Optional[str] = None,
        llm_config_name: Optional[str] = None,
        conversation_id: Optional[str] = None,
        text: Optional[str] = None,
        email: Optional[str] = None,
        ip_address: Optional[str] = None,
        inference_id: Optional[str] = None,
        auto_infer: Optional[bool] = None,
        is_test_generated: Optional[bool] = None,
        file_ids: Optional[List[str]] = None,
    ) -> Message:
        """Create a new message.

        Args:
            tenant_key: Tenant key
            endpoint_name: Endpoint name (mutually exclusive with llm_config_name)
            llm_config_name: LLM config name (mutually exclusive with endpoint_name)
            conversation_id: Conversation ID (optional - if not provided,
                           a new conversation will be automatically created by the API)
            text: Message text
            email: User email
            ip_address: IP address
            inference_id: Inference ID
            auto_infer: Whether to automatically trigger inference (default: True)
            is_test_generated: Whether this message is generated for testing purposes
            file_ids: List of file IDs to associate with this message

        Returns:
            Message: The created message

        Note:
            If conversation_id is not provided, the Azure ML API will automatically
            create a new conversation and assign it to the message. If you do provide
            a conversation_id, it must be an existing conversation ID in ObjectId format.

            When is_test_generated=True, the created message (and any auto-created
            conversation) will be marked as test-generated and hidden by default
            from list operations.

            Auto-inference is triggered by default (auto_infer=True) when either
            endpoint_name or llm_config_name is provided. Set auto_infer=False to
            disable automatic inference (useful for importing historical messages).

        """
        message_data = MessageCreate(
            tenant_key=tenant_key,
            endpoint_name=endpoint_name,
            llm_config_name=llm_config_name,
            conversation_id=conversation_id,
            text=text,
            email=email,
            ip_address=ip_address,
            inference_id=inference_id,
            auto_infer=auto_infer,
            is_test_generated=is_test_generated,
            file_ids=file_ids,
        )

        response = self.http_client.post(
            "/messages", data=message_data.model_dump(by_alias=True, exclude_none=True)
        )
        return Message(**self._transform_message_data(response))

    def update(
        self,
        message_id: str,
        tenant_key: Optional[str] = None,
        endpoint_name: Optional[str] = None,
        conversation_id: Optional[str] = None,
        text: Optional[str] = None,
        email: Optional[str] = None,
        ip_address: Optional[str] = None,
        inference_id: Optional[str] = None,
        is_test_generated: Optional[bool] = None,
        file_ids: Optional[List[str]] = None,
    ) -> Message:
        """Update an existing message.

        Args:
            message_id: Message ID
            tenant_key: Tenant key
            endpoint_name: Endpoint name
            conversation_id: Conversation ID
            text: Message text
            email: User email
            ip_address: IP address
            inference_id: Inference ID
            is_test_generated: Whether this message is generated for testing purposes
            file_ids: List of file IDs to associate with this message

        Returns:
            Message: The updated message

        """
        update_data = {}
        if tenant_key is not None:
            update_data["tenantKey"] = tenant_key
        if endpoint_name is not None:
            update_data["endpointName"] = endpoint_name
        if conversation_id is not None:
            update_data["conversationId"] = conversation_id
        if text is not None:
            update_data["text"] = text
        if email is not None:
            update_data["email"] = email
        if ip_address is not None:
            update_data["ipAddress"] = ip_address
        if inference_id is not None:
            update_data["inferenceId"] = inference_id
        if is_test_generated is not None:
            update_data["isTestGenerated"] = is_test_generated
        if file_ids is not None:
            update_data["fileIds"] = file_ids

        response = self.http_client.put(f"/messages/{message_id}", data=update_data)
        return Message(**self._transform_message_data(response))

    def list_test_messages(
        self,
        tenant_key: Optional[str] = None,
        endpoint_name: Optional[str] = None,
        conversation_id: Optional[str] = None,
        email: Optional[str] = None,
        text: Optional[str] = None,
        inference_id: Optional[str] = None,
        created_date_start: Optional[datetime] = None,
        created_date_end: Optional[datetime] = None,
        page: int = 1,
        per_page: int = 25,
    ) -> PaginatedResponse:
        """List test-generated messages only.

        This is a convenience method that automatically filters for test-generated
        messages by setting is_test_generated='true'.

        Args:
            tenant_key: Filter by tenant key
            endpoint_name: Filter by endpoint name
            conversation_id: Filter by conversation ID
            email: Filter by user email
            text: Filter by message text
            inference_id: Filter by inference ID
            created_date_start: Filter by creation date (start)
            created_date_end: Filter by creation date (end)
            page: Page number (1-based)
            per_page: Number of items per page

        Returns:
            PaginatedResponse: Paginated list of test-generated messages

        """
        return self.list(
            tenant_key=tenant_key,
            endpoint_name=endpoint_name,
            conversation_id=conversation_id,
            email=email,
            text=text,
            inference_id=inference_id,
            is_test_generated="true",
            created_date_start=created_date_start,
            created_date_end=created_date_end,
            page=page,
            per_page=per_page,
        )

    def _transform_message_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform message data from API response format to model format.

        Args:
            data: Raw message data from API

        Returns:
            Dict[str, Any]: Transformed message data

        """
        transformed = data.copy()

        # Parse datetime strings if present
        for date_field in ["createdDate", "updatedDate"]:
            if date_field in transformed and transformed[date_field]:
                try:
                    transformed[date_field] = datetime.fromisoformat(
                        transformed[date_field].replace("Z", "+00:00")
                    )
                except (ValueError, AttributeError):
                    pass  # Keep original value if parsing fails

        return transformed
