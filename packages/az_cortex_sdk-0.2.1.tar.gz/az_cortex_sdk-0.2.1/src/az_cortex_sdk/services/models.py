"""Model service for Azure Cortex SDK."""

import json
from pathlib import Path
from typing import Any, Dict, Optional, Union

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import (
    Model,
    ModelVersion,
    PaginatedResponse,
    RegistrationResult,
    UploadResult,
)


class ModelService:
    """Service for managing Azure ML models."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(
        self, page: int = 1, per_page: int = 25, include_latest: bool = True
    ) -> PaginatedResponse:
        """List all models with pagination."""
        params = {
            "page": page,
            "perPage": per_page,
            "includeLatest": include_latest,
        }

        response = self.http_client.get("/models", params=params)

        # Handle both response formats: {items: []} and {documents: []}
        items_data = response.get("items", response.get("documents", []))
        total_count = response.get(
            "total", response.get("totalDocuments", len(items_data))
        )

        models = [Model(**item) for item in items_data]

        return PaginatedResponse(
            items=models,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=total_count,
            has_next=response.get("page", page) * response.get("perPage", per_page)
            < total_count,
            has_prev=response.get("page", page) > 1,
        )

    def get_container(self, name: str) -> Optional[Model]:
        """Get model container (base model info without version details)."""
        try:
            response = self.http_client.get(f"/models/{name}")

            # Transform API response to match SDK model structure
            transformed_response = {**response}

            if "properties" in response and isinstance(response["properties"], dict):
                props = response["properties"]
                if "description" in props:
                    transformed_response["description"] = props["description"]
                if "latestVersion" in props:
                    transformed_response["latest_version"] = props["latestVersion"]
                if "nextVersion" in props:
                    transformed_response["next_version"] = props["nextVersion"]
                if "isArchived" in props:
                    transformed_response["is_archived"] = props["isArchived"]
                if "tags" in props:
                    transformed_response["tags"] = props["tags"]
                if "properties" in props:
                    transformed_response["properties"] = props["properties"]

            return Model(**transformed_response)
        except NotFoundError:
            raise
        except Exception:
            return None

    def update_container(
        self,
        name: str,
        description: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        is_archived: Optional[bool] = None,
    ) -> Model:
        """Update model container (archive/unarchive, update description, etc.)."""
        data = {}
        if description is not None:
            data["description"] = description
        if tags is not None:
            data["tags"] = tags
        if is_archived is not None:
            data["isArchived"] = is_archived

        response = self.http_client.put(f"/models/{name}", data=data)

        # Transform API response to match SDK model structure
        transformed_response = {**response}

        if "properties" in response and isinstance(response["properties"], dict):
            props = response["properties"]
            if "description" in props:
                transformed_response["description"] = props["description"]
            if "latestVersion" in props:
                transformed_response["latest_version"] = props["latestVersion"]
            if "nextVersion" in props:
                transformed_response["next_version"] = props["nextVersion"]
            if "isArchived" in props:
                transformed_response["is_archived"] = props["isArchived"]
            if "tags" in props:
                transformed_response["tags"] = props["tags"]
            if "properties" in props:
                transformed_response["properties"] = props["properties"]

        return Model(**transformed_response)

    def get(self, name: str, version: str) -> Optional[ModelVersion]:
        """Get specific model version."""
        try:
            # Convert version to integer format for Azure ML API
            api_version = self._convert_version_to_integer(version)
            # Use the correct API endpoint: GET /model-versions/{version}?modelName={name}
            response = self.http_client.get(
                f"/model-versions/{api_version}?modelName={name}"
            )

            # Transform API response to match SDK model structure
            # API returns: {"name": "1", "properties": {...}, ...}
            # SDK expects: {"name": "model-name", "version": "1", ...}
            transformed_response = {
                **response,
                "name": name,  # Use the model name from the request
                "version": version,  # Use the original version from the request
            }

            # Extract nested properties if they exist
            if "properties" in response and isinstance(response["properties"], dict):
                props = response["properties"]
                # Map common properties from nested structure
                if "description" in props:
                    transformed_response["description"] = props["description"]
                if "modelUri" in props:
                    transformed_response["model_uri"] = props["modelUri"]
                if "modelType" in props:
                    transformed_response["model_type"] = props["modelType"]
                if "jobName" in props:
                    transformed_response["job_name"] = props["jobName"]
                if "isAnonymous" in props:
                    transformed_response["is_anonymous"] = props["isAnonymous"]
                if "isArchived" in props:
                    transformed_response["is_archived"] = props["isArchived"]
                if "tags" in props:
                    transformed_response["tags"] = props["tags"]
                if "properties" in props:
                    transformed_response["properties"] = props["properties"]
                if "flavors" in props:
                    transformed_response["flavors"] = props["flavors"]

            return ModelVersion(**transformed_response)
        except NotFoundError:
            # Re-raise NotFoundError so error handling tests work correctly
            raise
        except Exception:
            return None

    def list_versions(
        self, name: str, page: int = 1, per_page: int = 25
    ) -> PaginatedResponse:
        """List all versions of a model."""
        params = {
            "page": page,
            "perPage": per_page,
        }

        response = self.http_client.get(f"/models/{name}/versions", params=params)

        versions = [ModelVersion(**item) for item in response.get("items", [])]

        return PaginatedResponse(
            items=versions,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=response.get("total", len(versions)),
            has_next=response.get("page", page) * response.get("perPage", per_page)
            < response.get("total", 0),
            has_prev=response.get("page", page) > 1,
        )

    def create(
        self,
        name: str,
        version: str,
        description: Optional[str] = None,
        model_uri: Optional[str] = None,
        model_type: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
        flavors: Optional[Dict[str, Any]] = None,
    ) -> RegistrationResult:
        """Create a new model version."""
        data: Dict[str, Any] = {
            "name": name,
            "version": version,
        }

        if description:
            data["description"] = description
        if model_uri:
            data["modelUri"] = model_uri
        if model_type:
            data["modelType"] = model_type
        if tags:
            data["tags"] = tags
        if properties:
            data["properties"] = properties
        if flavors:
            data["flavors"] = flavors

        response = self.http_client.post("/models", data=data)

        return RegistrationResult(
            success=response.get("success", True),
            name=response.get("name", name),
            version=response.get("version", version),
            id=response.get("id"),
            error=response.get("error"),
        )

    def _convert_version_to_integer(self, version: str) -> str:
        """Convert semantic version to integer for Azure ML API."""
        # Azure ML API expects integer versions, not semantic versions
        # Convert "1.0.0" -> "1", "2.1.0" -> "2", etc.
        try:
            # Try to extract the major version number
            major_version = version.split(".")[0]
            if major_version.isdigit():
                return major_version
            else:
                # If it's already an integer string, return as-is
                return version
        except (ValueError, AttributeError, IndexError):
            # Fallback: return as-is
            return version

    def upload_and_create(
        self,
        file_path: Union[str, Path],
        name: str,
        version: str,
        description: Optional[str] = None,
        model_type: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
        flavors: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Upload a file and create model version."""
        file_path = Path(file_path)

        if not file_path.exists():
            return {
                "upload_result": UploadResult(
                    success=False,
                    file_name=file_path.name,
                    error=f"File not found: {file_path}",
                )
            }

        # Prepare multipart form data
        files = {
            "file": (file_path.name, open(file_path, "rb"), "application/octet-stream")
        }

        # Prepare form fields (name and version come from URL, not form data)
        form_data = {
            "assetType": "file"  # Required for single file uploads
        }

        if description:
            form_data["description"] = description
        if model_type:
            form_data["modelType"] = model_type
        if tags:
            form_data["tags"] = json.dumps(tags)
        if properties:
            form_data["properties"] = json.dumps(properties)
        if flavors:
            form_data["flavors"] = json.dumps(flavors)

        try:
            # Convert version to integer format for Azure ML API
            api_version = self._convert_version_to_integer(version)

            # Use the correct API endpoint: POST /model-versions/{version}?modelName={name}
            response = self.http_client.post(
                f"/model-versions/{api_version}?modelName={name}",
                files=files,
                data=form_data,
            )

            return {
                "upload_result": UploadResult(
                    success=True,
                    file_name=file_path.name,
                    azure_ml_uri=response.get("modelUri"),
                    size_bytes=file_path.stat().st_size,
                ),
                "registration_result": RegistrationResult(
                    success=True,  # If we got here, it was successful
                    name=name,  # Use the original name we sent
                    version=response.get(
                        "name", api_version
                    ),  # API returns version in "name" field
                    id=response.get("id"),
                    error=None,
                ),
            }

        except Exception as e:
            return {
                "upload_result": UploadResult(
                    success=False, file_name=file_path.name, error=str(e)
                )
            }
        finally:
            # Close file handle
            if "file" in files:
                files["file"][1].close()

    def upload_buffer_and_create(
        self,
        buffer: bytes,
        file_name: str,
        name: str,
        version: str,
        description: Optional[str] = None,
        model_type: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
        flavors: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Upload a buffer and create model version."""
        # Prepare multipart form data
        files = {"file": (file_name, buffer, "application/octet-stream")}

        # Prepare form fields (name and version come from URL, not form data)
        form_data = {
            "assetType": "file"  # Required for single file uploads
        }

        if description:
            form_data["description"] = description
        if model_type:
            form_data["modelType"] = model_type
        if tags:
            form_data["tags"] = json.dumps(tags)
        if properties:
            form_data["properties"] = json.dumps(properties)
        if flavors:
            form_data["flavors"] = json.dumps(flavors)

        try:
            # Convert version to integer format for Azure ML API
            api_version = self._convert_version_to_integer(version)

            # Use the correct API endpoint: POST /model-versions/{version}?modelName={name}
            response = self.http_client.post(
                f"/model-versions/{api_version}?modelName={name}",
                files=files,
                data=form_data,
            )

            return {
                "upload_result": UploadResult(
                    success=True,
                    file_name=file_name,
                    azure_ml_uri=response.get("modelUri"),
                    size_bytes=len(buffer),
                ),
                "registration_result": RegistrationResult(
                    success=True,  # If we got here, it was successful
                    name=name,  # Use the original name we sent
                    version=response.get(
                        "name", api_version
                    ),  # API returns version in "name" field
                    id=response.get("id"),
                    error=None,
                ),
            }

        except Exception as e:
            return {
                "upload_result": UploadResult(
                    success=False, file_name=file_name, error=str(e)
                )
            }

    def update_version(
        self,
        name: str,
        version: str,
        description: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
        is_archived: Optional[bool] = None,
    ) -> ModelVersion:
        """Update a model version."""
        # Convert version to integer format for Azure ML API
        api_version = self._convert_version_to_integer(version)

        data = {}
        if description is not None:
            data["description"] = description
        if tags is not None:
            data["tags"] = tags
        if properties is not None:
            data["properties"] = properties
        if is_archived is not None:
            data["isArchived"] = is_archived

        response = self.http_client.put(
            f"/model-versions/{api_version}?modelName={name}", data=data
        )

        # Transform API response to match SDK model structure
        transformed_response = {
            **response,
            "name": name,  # Use the model name from the request
            "version": response.get(
                "name", api_version
            ),  # API returns version in "name" field
        }

        # Extract nested properties if they exist
        if "properties" in response and isinstance(response["properties"], dict):
            props = response["properties"]
            # Map common properties from nested structure
            if "description" in props:
                transformed_response["description"] = props["description"]
            if "modelUri" in props:
                transformed_response["model_uri"] = props["modelUri"]
            if "modelType" in props:
                transformed_response["model_type"] = props["modelType"]
            if "jobName" in props:
                transformed_response["job_name"] = props["jobName"]
            if "isAnonymous" in props:
                transformed_response["is_anonymous"] = props["isAnonymous"]
            if "isArchived" in props:
                transformed_response["is_archived"] = props["isArchived"]
            if "tags" in props:
                transformed_response["tags"] = props["tags"]
            if "properties" in props:
                transformed_response["properties"] = props["properties"]
            if "flavors" in props:
                transformed_response["flavors"] = props["flavors"]

        return ModelVersion(**transformed_response)


    def upload_directory_and_create(
        self,
        directory_path: Union[str, Path],
        name: str,
        version: str,
        description: Optional[str] = None,
        model_type: Optional[str] = "mlflow_model",
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Upload a directory and create model version using Azure ML SDK.

        This method uploads the entire directory structure to Azure ML blob storage
        without zipping, preserving the folder structure. This is required for
        MLflow models and other models that need their directory structure intact.

        Args:
            directory_path: Path to the model directory
            name: Model name
            version: Model version (must be integer string like "1", "2", etc.)
            description: Model description
            model_type: Model type (default: "mlflow_model")
            tags: Optional tags dictionary
            properties: Optional properties dictionary

        Returns:
            Dictionary with upload_result and registration_result

        """
        try:
            from azure.ai.ml import MLClient
            from azure.ai.ml.entities import Model
            from azure.identity import DefaultAzureCredential
        except ImportError:
            return {
                "upload_result": UploadResult(
                    success=False,
                    file_name=str(directory_path),
                    error="azure-ai-ml package not installed. Install with: pip install azure-ai-ml azure-identity",
                )
            }

        directory_path = Path(directory_path)

        if not directory_path.exists():
            return {
                "upload_result": UploadResult(
                    success=False,
                    file_name=directory_path.name,
                    error=f"Directory not found: {directory_path}",
                )
            }

        if not directory_path.is_dir():
            return {
                "upload_result": UploadResult(
                    success=False,
                    file_name=directory_path.name,
                    error=f"Path is not a directory: {directory_path}",
                )
            }

        # Get Azure ML workspace configuration from Cortex config
        tenant = self.http_client.config.tenant
        subscription_id = "eb4b4479-cd6b-49f5-b157-3d6e187e9a4b"
        resource_group = "rg-cortex-tenant-services-dev"
        workspace_name = f"{tenant}-ws"

        # Convert version to integer format
        api_version = self._convert_version_to_integer(version)

        try:
            # Create Azure ML client using DefaultAzureCredential
            credential = DefaultAzureCredential()
            ml_client = MLClient(
                credential=credential,
                subscription_id=subscription_id,
                resource_group_name=resource_group,
                workspace_name=workspace_name
            )

            # Calculate total size
            total_size = sum(f.stat().st_size for f in directory_path.rglob('*') if f.is_file())

            # Create Model entity
            model = Model(
                path=str(directory_path),
                name=name,
                version=api_version,
                description=description or f"Model uploaded from {directory_path.name}",
                type=model_type,
                tags=tags,
                properties=properties,
            )

            # Upload and register the model
            registered_model = ml_client.models.create_or_update(model)

            return {
                "upload_result": UploadResult(
                    success=True,
                    file_name=directory_path.name,
                    azure_ml_uri=registered_model.path,
                    size_bytes=total_size,
                ),
                "registration_result": RegistrationResult(
                    success=True,
                    name=name,
                    version=api_version,
                    id=registered_model.id,
                    error=None,
                ),
            }

        except Exception as e:
            return {
                "upload_result": UploadResult(
                    success=False,
                    file_name=directory_path.name,
                    error=f"Failed to upload directory: {str(e)}",
                )
            }
    def delete(self, name: str, version: str) -> Dict[str, Any]:
        """Delete a model version."""
        # Note: API does not currently support DELETE operations for models
        raise NotImplementedError(
            "Delete operations are not supported by the API. "
            "Model versions cannot be deleted via the API."
        )

    def delete_all_versions(self, name: str) -> Dict[str, Any]:
        """Delete all versions of a model."""
        # Note: API does not currently support DELETE operations for models
        raise NotImplementedError(
            "Delete operations are not supported by the API. "
            "Models cannot be deleted via the API."
        )
