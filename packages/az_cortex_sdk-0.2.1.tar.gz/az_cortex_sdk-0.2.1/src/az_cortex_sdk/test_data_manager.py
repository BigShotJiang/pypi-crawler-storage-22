"""Test data management utilities for Azure Cortex SDK."""

from datetime import datetime
from typing import Dict, List, Optional

from .client import CortexClient
from .models import Message, PaginatedResponse


class TestDataManager:
    """Utility class for creating and managing test data in Azure Cortex.

    This class provides convenient methods for creating test conversations, messages,
    and inferences, as well as utilities for cleaning up test data after testing.

    All data created through this manager is automatically marked with
    is_test_generated=True, making it easy to identify and clean up later.
    """

    def __init__(self, client: CortexClient):
        """Initialize TestDataManager with a CortexClient instance.

        Args:
            client: Configured CortexClient instance

        """
        self.client = client

    def create_test_message(
        self,
        endpoint_name: str,
        text: str,
        email: str,
        tenant_key: Optional[str] = None,
        conversation_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        inference_id: Optional[str] = None,
    ) -> Message:
        """Create a test message.

        Args:
            endpoint_name: Endpoint name
            text: Message text
            email: User email
            tenant_key: Tenant key (optional)
            conversation_id: Conversation ID (optional - if not provided,
                           a new conversation will be automatically created)
            ip_address: IP address (optional)
            inference_id: Inference ID (optional)

        Returns:
            Message: The created test message

        """
        return self.client.messages.create(
            tenant_key=tenant_key,
            endpoint_name=endpoint_name,
            conversation_id=conversation_id,
            text=text,
            email=email,
            ip_address=ip_address,
            inference_id=inference_id,
            is_test_generated=True,
        )

    def create_test_conversation_with_messages(
        self,
        endpoint_name: str,
        email: str,
        messages: List[str],
        tenant_key: Optional[str] = None,
        ip_address: Optional[str] = None,
    ) -> List[Message]:
        """Create a test conversation with multiple messages.

        Args:
            endpoint_name: Endpoint name
            email: User email
            messages: List of message texts to create
            tenant_key: Tenant key (optional)
            ip_address: IP address (optional)

        Returns:
            List[Message]: List of created test messages

        """
        created_messages = []
        conversation_id = None

        for message_text in messages:
            message = self.create_test_message(
                endpoint_name=endpoint_name,
                text=message_text,
                email=email,
                tenant_key=tenant_key,
                conversation_id=conversation_id,
                ip_address=ip_address,
            )
            created_messages.append(message)

            # Use the conversation_id from the first message for subsequent messages
            if conversation_id is None:
                conversation_id = message.conversation_id

        return created_messages

    def get_all_test_data(self) -> Dict[str, PaginatedResponse]:
        """Retrieve all test data across conversations, messages, and inferences.

        Returns:
            Dict containing test data for each entity type:
            - 'conversations': Test conversations
            - 'messages': Test messages
            - 'inferences': Test inferences

        """
        return {
            "conversations": self.client.conversations.list_test_conversations(
                per_page=100
            ),
            "messages": self.client.messages.list_test_messages(per_page=100),
            "inferences": self.client.inferences.list_test_inferences(per_page=100),
        }

    def cleanup_test_conversations(
        self,
        endpoint_name: Optional[str] = None,
        email: Optional[str] = None,
        created_after: Optional[datetime] = None,
        dry_run: bool = False,
    ) -> Dict[str, int]:
        """Clean up test conversations.

        Args:
            endpoint_name: Only clean up conversations from this endpoint (optional)
            email: Only clean up conversations from this email (optional)
            created_after: Only clean up conversations created after this date (optional)
            dry_run: If True, return count of items that would be deleted without actually deleting

        Returns:
            Dict with cleanup statistics: {'deleted': count, 'errors': count}

        """
        conversations = self.client.conversations.list_test_conversations(
            endpoint_name=endpoint_name,
            email=email,
            created_date_start=created_after,
            per_page=100,
        )

        deleted_count = 0
        error_count = 0

        for conversation in conversations.items:
            if not dry_run:
                try:
                    # Note: Actual deletion would depend on API support
                    # For now, we'll mark as archived which is typically how cleanup works
                    self.client.conversations.update(conversation.id, is_archived=True)
                    deleted_count += 1
                except Exception:
                    error_count += 1
            else:
                deleted_count += 1

        return {"deleted": deleted_count, "errors": error_count}

    def cleanup_test_messages(
        self,
        endpoint_name: Optional[str] = None,
        email: Optional[str] = None,
        created_after: Optional[datetime] = None,
        dry_run: bool = False,
    ) -> Dict[str, int]:
        """Clean up test messages.

        Args:
            endpoint_name: Only clean up messages from this endpoint (optional)
            email: Only clean up messages from this email (optional)
            created_after: Only clean up messages created after this date (optional)
            dry_run: If True, return count of items that would be deleted without actually deleting

        Returns:
            Dict with cleanup statistics: {'deleted': count, 'errors': count}

        """
        messages = self.client.messages.list_test_messages(
            endpoint_name=endpoint_name,
            email=email,
            created_date_start=created_after,
            per_page=100,
        )

        deleted_count = 0
        error_count = 0

        for _message in messages.items:
            if not dry_run:
                try:
                    # Note: Actual deletion would depend on API support
                    # This is a placeholder for the actual deletion logic
                    # In practice, this might involve calling a delete endpoint
                    # or marking the message as deleted/archived
                    deleted_count += 1
                except Exception:
                    error_count += 1
            else:
                deleted_count += 1

        return {"deleted": deleted_count, "errors": error_count}

    def cleanup_all_test_data(
        self,
        endpoint_name: Optional[str] = None,
        email: Optional[str] = None,
        created_after: Optional[datetime] = None,
        dry_run: bool = False,
    ) -> Dict[str, Dict[str, int]]:
        """Clean up all test data (conversations, messages, inferences).

        Args:
            endpoint_name: Only clean up data from this endpoint (optional)
            email: Only clean up data from this email (optional)
            created_after: Only clean up data created after this date (optional)
            dry_run: If True, return count of items that would be deleted without actually deleting

        Returns:
            Dict with cleanup statistics for each entity type

        """
        return {
            "conversations": self.cleanup_test_conversations(
                endpoint_name=endpoint_name,
                email=email,
                created_after=created_after,
                dry_run=dry_run,
            ),
            "messages": self.cleanup_test_messages(
                endpoint_name=endpoint_name,
                email=email,
                created_after=created_after,
                dry_run=dry_run,
            ),
        }

    def count_test_data(self) -> Dict[str, int]:
        """Count all test data items.

        Returns:
            Dict with counts for each entity type

        """
        test_data = self.get_all_test_data()
        return {
            "conversations": test_data["conversations"].total,
            "messages": test_data["messages"].total,
            "inferences": test_data["inferences"].total,
        }
