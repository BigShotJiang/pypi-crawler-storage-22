"""Tests for isTestGenerated functionality."""

from unittest.mock import Mock

from az_cortex_sdk.models import Conversation, Inference, Message, PaginatedResponse
from az_cortex_sdk.services.conversations import ConversationService
from az_cortex_sdk.services.inferences import InferenceService
from az_cortex_sdk.services.messages import MessageService


class TestIsTestGeneratedFiltering:
    """Test cases for isTestGenerated filtering functionality."""

    def setup_method(self):
        """Set up test fixtures."""
        self.mock_http_client = Mock()

    def test_conversation_list_default_filtering(self):
        """Test that conversations list hides test data by default."""
        service = ConversationService(self.mock_http_client)

        # Mock response
        mock_response = {
            "documents": [],
            "totalDocuments": 0,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Call list without is_test_generated parameter
        service.list()

        # Verify that isTestGenerated=false was added to params
        self.mock_http_client.get.assert_called_once()
        call_args = self.mock_http_client.get.call_args
        params = call_args[1]['params']
        assert params['isTestGenerated'] == 'false'

    def test_conversation_list_explicit_test_filtering(self):
        """Test explicit test data filtering options."""
        service = ConversationService(self.mock_http_client)

        mock_response = {
            "documents": [],
            "totalDocuments": 0,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Test is_test_generated='true'
        service.list(is_test_generated='true')
        call_args = self.mock_http_client.get.call_args
        params = call_args[1]['params']
        assert params['isTestGenerated'] == 'true'

        # Reset mock
        self.mock_http_client.reset_mock()

        # Test is_test_generated='false'
        service.list(is_test_generated='false')
        call_args = self.mock_http_client.get.call_args
        params = call_args[1]['params']
        assert params['isTestGenerated'] == 'false'

        # Reset mock
        self.mock_http_client.reset_mock()

        # Test is_test_generated='all' (should not add parameter)
        service.list(is_test_generated='all')
        call_args = self.mock_http_client.get.call_args
        params = call_args[1]['params']
        assert 'isTestGenerated' not in params

    def test_message_list_default_filtering(self):
        """Test that messages list hides test data by default."""
        service = MessageService(self.mock_http_client)

        mock_response = {
            "documents": [],
            "totalDocuments": 0,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Call list without is_test_generated parameter
        service.list()

        # Verify that isTestGenerated=false was added to params
        self.mock_http_client.get.assert_called_once()
        call_args = self.mock_http_client.get.call_args
        params = call_args[1]['params']
        assert params['isTestGenerated'] == 'false'

    def test_inference_list_default_filtering(self):
        """Test that inferences list hides test data by default."""
        service = InferenceService(self.mock_http_client)

        mock_response = {
            "documents": [],
            "totalDocuments": 0,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Call list without is_test_generated parameter
        service.list()

        # Verify that isTestGenerated=false was added to params
        self.mock_http_client.get.assert_called_once()
        call_args = self.mock_http_client.get.call_args
        params = call_args[1]['params']
        assert params['isTestGenerated'] == 'false'

    def test_message_create_with_is_test_generated(self):
        """Test creating a message with is_test_generated flag."""
        service = MessageService(self.mock_http_client)

        mock_response = {
            "_id": "msg1",
            "tenantKey": "demo",
            "endpointName": "test-endpoint",
            "text": "Test message",
            "email": "test@example.com",
            "isTestGenerated": True,
            "createdDate": "2024-01-01T12:00:00Z"
        }
        self.mock_http_client.post.return_value = mock_response

        # Create message with is_test_generated=True
        result = service.create(
            endpoint_name="test-endpoint",
            text="Test message",
            email="test@example.com",
            is_test_generated=True
        )

        # Verify the request was made with correct data
        self.mock_http_client.post.assert_called_once()
        call_args = self.mock_http_client.post.call_args
        data = call_args[1]['data']
        assert data['isTestGenerated'] is True

        # Verify the response
        assert isinstance(result, Message)

    def test_conversation_list_test_convenience_method(self):
        """Test the list_test_conversations convenience method."""
        service = ConversationService(self.mock_http_client)

        mock_response = {
            "documents": [{
                "_id": "conv1",
                "tenantKey": "demo",
                "endpointName": "test-endpoint",
                "email": "test@example.com",
                "isTestGenerated": True,
                "createdDate": "2024-01-01T12:00:00Z"
            }],
            "totalDocuments": 1,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Call list_test_conversations
        result = service.list_test_conversations(email="test@example.com")

        # Verify that isTestGenerated=true was set
        call_args = self.mock_http_client.get.call_args
        params = call_args[1]['params']
        assert params['isTestGenerated'] == 'true'
        assert params['email'] == 'test@example.com'

        # Verify the response
        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 1
        assert isinstance(result.items[0], Conversation)

    def test_message_list_test_convenience_method(self):
        """Test the list_test_messages convenience method."""
        service = MessageService(self.mock_http_client)

        mock_response = {
            "documents": [{
                "_id": "msg1",
                "tenantKey": "demo",
                "endpointName": "test-endpoint",
                "text": "Test message",
                "email": "test@example.com",
                "isTestGenerated": True,
                "createdDate": "2024-01-01T12:00:00Z"
            }],
            "totalDocuments": 1,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Call list_test_messages
        result = service.list_test_messages(email="test@example.com")

        # Verify that isTestGenerated=true was set
        call_args = self.mock_http_client.get.call_args
        params = call_args[1]['params']
        assert params['isTestGenerated'] == 'true'
        assert params['email'] == 'test@example.com'

        # Verify the response
        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 1

    def test_inference_list_test_convenience_method(self):
        """Test the list_test_inferences convenience method."""
        service = InferenceService(self.mock_http_client)

        mock_response = {
            "documents": [{
                "_id": "inf1",
                "tenantKey": "demo",
                "endpointName": "test-endpoint",
                "email": "test@example.com",
                "isTestGenerated": True,
                "createdDate": "2024-01-01T12:00:00Z"
            }],
            "totalDocuments": 1,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Call list_test_inferences
        result = service.list_test_inferences(email="test@example.com")

        # Verify that isTestGenerated=true was set
        call_args = self.mock_http_client.get.call_args
        params = call_args[1]['params']
        assert params['isTestGenerated'] == 'true'
        assert params['email'] == 'test@example.com'

        # Verify the response
        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 1
        assert isinstance(result.items[0], Inference)

    def test_update_methods_support_is_test_generated(self):
        """Test that update methods support is_test_generated parameter."""
        # Test message update
        message_service = MessageService(self.mock_http_client)
        mock_response = {
            "_id": "msg1",
            "text": "Updated message",
            "isTestGenerated": True
        }
        self.mock_http_client.put.return_value = mock_response

        message_service.update("msg1", text="Updated message", is_test_generated=True)

        call_args = self.mock_http_client.put.call_args
        data = call_args[1]['data']
        assert data['isTestGenerated'] is True

        # Reset mock
        self.mock_http_client.reset_mock()

        # Test conversation update
        conversation_service = ConversationService(self.mock_http_client)
        mock_response = {
            "_id": "conv1",
            "email": "updated@example.com",
            "isTestGenerated": True
        }
        self.mock_http_client.put.return_value = mock_response

        conversation_service.update("conv1", email="updated@example.com", is_test_generated=True)

        call_args = self.mock_http_client.put.call_args
        data = call_args[1]['data']
        assert data['isTestGenerated'] is True

        # Reset mock
        self.mock_http_client.reset_mock()

        # Test inference update
        inference_service = InferenceService(self.mock_http_client)
        mock_response = {
            "_id": "inf1",
            "annotation": "Updated annotation",
            "isTestGenerated": True
        }
        self.mock_http_client.put.return_value = mock_response

        inference_service.update("inf1", annotation="Updated annotation", is_test_generated=True)

        call_args = self.mock_http_client.put.call_args
        data = call_args[1]['data']
        assert data['isTestGenerated'] is True
#!/usr/bin/env python3
"""
Test to verify that archived LLM configs are filtered correctly.

This test verifies:
1. Archived configs don't appear in default list
2. Archived configs appear when is_archived=True
3. Archived configs don't appear when is_archived=False
"""

import os
import sys
from datetime import datetime

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from az_cortex_sdk import CortexClient

# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
BLUE = '\033[94m'
YELLOW = '\033[93m'
RESET = '\033[0m'
BOLD = '\033[1m'

def print_header(text: str):
    print(f"\n{BOLD}{BLUE}{'='*80}{RESET}")
    print(f"{BOLD}{BLUE}  {text}{RESET}")
    print(f"{BOLD}{BLUE}{'='*80}{RESET}\n")

def print_success(text: str):
    print(f"{GREEN}✓{RESET} {text}")

def print_error(text: str):
    print(f"{RED}✗{RESET} {text}")

def print_info(text: str):
    print(f"  {text}")

def main():
    # Load environment variables
    if load_dotenv:
        env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
        load_dotenv(env_path)
        print(f"Loaded environment from: {env_path}\n")

    print_header("Archive Filtering Verification Test")

    # Initialize client
    client = CortexClient.from_env()
    print_success("Initialized CortexClient")

    # Generate unique config name
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    config_name = f"test-archive-filter-{timestamp}"

    try:
        # Step 1: Create a test config
        print_info(f"\n1. Creating test LLM config: {config_name}")
        client.llm.create(
            config_name=config_name,
            provider="openai",
            model="gpt-4",
            api_key="sk-test-placeholder-key",
            default_parameters={
                "temperature": 0.7,
                "max_tokens": 1000,
            }
        )
        print_success(f"Created config: {config_name}")

        # Step 2: List configs without filter (should appear)
        print_info("\n2. Listing configs (default - should include new config)")
        configs_default = client.llm.list(per_page=100)
        config_names_default = [c.config_name for c in configs_default.items]

        if config_name in config_names_default:
            print_success(f"Config appears in default list (found {configs_default.total} total)")
            print_info(f"   Config is at position {config_names_default.index(config_name) + 1}")
        else:
            print_error("Config NOT found in default list (UNEXPECTED)")
            return False

        # Step 3: Archive the config
        print_info(f"\n3. Archiving config: {config_name}")
        archived = client.llm.archive(config_name)
        print_success(f"Archived config (is_archived={archived.is_archived})")

        # Step 4: List configs without filter (should NOT appear)
        print_info("\n4. Listing configs (default - should NOT include archived config)")
        configs_after_archive = client.llm.list(per_page=100)
        config_names_after = [c.config_name for c in configs_after_archive.items]

        if config_name not in config_names_after:
            print_success("Archived config correctly excluded from default list")
            print_info(f"   Found {configs_after_archive.total} configs (was {configs_default.total} before archive)")
        else:
            print_error("Archived config still appears in default list (UNEXPECTED)")
            return False

        # Step 5: List with is_archived=False (should NOT appear)
        print_info("\n5. Listing configs with is_archived=False (should NOT include archived)")
        configs_not_archived = client.llm.list(is_archived=False, per_page=100)
        config_names_not_archived = [c.config_name for c in configs_not_archived.items]

        if config_name not in config_names_not_archived:
            print_success("Archived config correctly excluded when is_archived=False")
            print_info(f"   Found {configs_not_archived.total} non-archived configs")
        else:
            print_error("Archived config appears when is_archived=False (UNEXPECTED)")
            return False

        # Step 6: List with is_archived=True (should appear)
        print_info("\n6. Listing configs with is_archived=True (should include archived)")
        configs_archived = client.llm.list(is_archived=True, per_page=100)
        config_names_archived = [c.config_name for c in configs_archived.items]

        if config_name in config_names_archived:
            print_success("Archived config correctly included when is_archived=True")
            print_info(f"   Found {configs_archived.total} archived configs")
            print_info(f"   Config is at position {config_names_archived.index(config_name) + 1}")
        else:
            print_error("Archived config NOT found when is_archived=True (UNEXPECTED)")
            return False

        # Summary
        print_header("Test Results Summary")
        print_success("All archive filtering tests passed!")
        print_info("")
        print_info("Verified behaviors:")
        print_info("  ✓ New configs appear in default list")
        print_info("  ✓ Archived configs are excluded from default list")
        print_info("  ✓ Archived configs are excluded when is_archived=False")
        print_info("  ✓ Archived configs are included when is_archived=True")
        print_info("")
        print_info(f"Test config '{config_name}' left in archived state for inspection")

        return True

    except Exception as e:
        print_error(f"Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

"""Tests for TestDataManager class."""


from az_cortex_sdk.test_data_manager import TestDataManager


class TestTestDataManager:
    """Test cases for TestDataManager functionality."""

    def setup_method(self):
        """Set up test fixtures."""
        self.mock_client = Mock()
        self.mock_client.messages = Mock()
        self.mock_client.conversations = Mock()
        self.mock_client.inferences = Mock()
        self.test_manager = TestDataManager(self.mock_client)

    def test_create_test_message(self):
        """Test creating a test message."""
        # Mock the client's messages.create method
        mock_message = Mock(spec=Message)
        mock_message.id = "msg1"
        mock_message.text = "Test message"
        mock_message.is_test_generated = True
        self.mock_client.messages.create.return_value = mock_message

        # Create test message
        result = self.test_manager.create_test_message(
            endpoint_name="test-endpoint",
            text="Test message",
            email="test@example.com"
        )

        # Verify the client method was called with correct parameters
        self.mock_client.messages.create.assert_called_once_with(
            tenant_key=None,
            endpoint_name="test-endpoint",
            conversation_id=None,
            text="Test message",
            email="test@example.com",
            ip_address=None,
            inference_id=None,
            is_test_generated=True,
        )

        # Verify the result
        assert result == mock_message

    def test_create_test_conversation_with_messages(self):
        """Test creating a test conversation with multiple messages."""
        # Mock messages
        mock_messages = []
        for i in range(3):
            mock_message = Mock(spec=Message)
            mock_message.id = f"msg{i+1}"
            mock_message.conversation_id = "conv1" if i > 0 else "conv1"
            mock_message.text = f"Message {i+1}"
            mock_message.is_test_generated = True
            mock_messages.append(mock_message)

        # Set up the mock to return different messages for each call
        self.mock_client.messages.create.side_effect = mock_messages

        # Create test conversation with messages
        messages = ["Message 1", "Message 2", "Message 3"]
        result = self.test_manager.create_test_conversation_with_messages(
            endpoint_name="test-endpoint",
            email="test@example.com",
            messages=messages
        )

        # Verify the client method was called 3 times
        assert self.mock_client.messages.create.call_count == 3

        # Verify the first call (no conversation_id)
        first_call = self.mock_client.messages.create.call_args_list[0]
        assert first_call[1]['conversation_id'] is None
        assert first_call[1]['text'] == "Message 1"
        assert first_call[1]['is_test_generated'] is True

        # Verify subsequent calls (with conversation_id)
        second_call = self.mock_client.messages.create.call_args_list[1]
        assert second_call[1]['conversation_id'] == "conv1"
        assert second_call[1]['text'] == "Message 2"

        # Verify the result
        assert len(result) == 3
        assert result == mock_messages

    def test_get_all_test_data(self):
        """Test getting all test data."""
        # Mock paginated responses
        mock_conversations = Mock(spec=PaginatedResponse)
        mock_messages = Mock(spec=PaginatedResponse)
        mock_inferences = Mock(spec=PaginatedResponse)

        self.mock_client.conversations.list_test_conversations.return_value = mock_conversations
        self.mock_client.messages.list_test_messages.return_value = mock_messages
        self.mock_client.inferences.list_test_inferences.return_value = mock_inferences

        # Get all test data
        result = self.test_manager.get_all_test_data()

        # Verify the client methods were called
        self.mock_client.conversations.list_test_conversations.assert_called_once_with(per_page=100)
        self.mock_client.messages.list_test_messages.assert_called_once_with(per_page=100)
        self.mock_client.inferences.list_test_inferences.assert_called_once_with(per_page=100)

        # Verify the result structure
        assert 'conversations' in result
        assert 'messages' in result
        assert 'inferences' in result
        assert result['conversations'] == mock_conversations
        assert result['messages'] == mock_messages
        assert result['inferences'] == mock_inferences

    def test_cleanup_test_conversations_dry_run(self):
        """Test cleaning up test conversations in dry run mode."""
        # Mock test conversations
        mock_conversations = Mock(spec=PaginatedResponse)
        mock_conversations.items = [
            Mock(id="conv1"),
            Mock(id="conv2"),
            Mock(id="conv3")
        ]
        self.mock_client.conversations.list_test_conversations.return_value = mock_conversations

        # Run cleanup in dry run mode
        result = self.test_manager.cleanup_test_conversations(
            endpoint_name="test-endpoint",
            dry_run=True
        )

        # Verify the list method was called with correct parameters
        self.mock_client.conversations.list_test_conversations.assert_called_once_with(
            endpoint_name="test-endpoint",
            email=None,
            created_date_start=None,
            per_page=100,
        )

        # Verify no update calls were made (dry run)
        self.mock_client.conversations.update.assert_not_called()

        # Verify the result
        assert result['deleted'] == 3
        assert result['errors'] == 0

    def test_cleanup_test_conversations_actual(self):
        """Test actually cleaning up test conversations."""
        # Mock test conversations
        mock_conversations = Mock(spec=PaginatedResponse)
        mock_conversations.items = [
            Mock(id="conv1"),
            Mock(id="conv2")
        ]
        self.mock_client.conversations.list_test_conversations.return_value = mock_conversations

        # Mock successful updates
        self.mock_client.conversations.update.return_value = Mock()

        # Run actual cleanup
        result = self.test_manager.cleanup_test_conversations(
            email="test@example.com",
            dry_run=False
        )

        # Verify the update method was called for each conversation
        assert self.mock_client.conversations.update.call_count == 2
        self.mock_client.conversations.update.assert_any_call("conv1", is_archived=True)
        self.mock_client.conversations.update.assert_any_call("conv2", is_archived=True)

        # Verify the result
        assert result['deleted'] == 2
        assert result['errors'] == 0

    def test_cleanup_test_conversations_with_errors(self):
        """Test cleanup with some errors."""
        # Mock test conversations
        mock_conversations = Mock(spec=PaginatedResponse)
        mock_conversations.items = [
            Mock(id="conv1"),
            Mock(id="conv2"),
            Mock(id="conv3")
        ]
        self.mock_client.conversations.list_test_conversations.return_value = mock_conversations

        # Mock update method to raise exception for second conversation
        def mock_update(conv_id, **kwargs):
            if conv_id == "conv2":
                raise Exception("Update failed")
            return Mock()

        self.mock_client.conversations.update.side_effect = mock_update

        # Run cleanup
        result = self.test_manager.cleanup_test_conversations(dry_run=False)

        # Verify the result
        assert result['deleted'] == 2  # conv1 and conv3 succeeded
        assert result['errors'] == 1   # conv2 failed

    def test_cleanup_all_test_data(self):
        """Test cleaning up all test data."""
        # Mock cleanup methods
        self.test_manager.cleanup_test_conversations = Mock(return_value={'deleted': 2, 'errors': 0})
        self.test_manager.cleanup_test_messages = Mock(return_value={'deleted': 5, 'errors': 1})

        # Run cleanup all
        result = self.test_manager.cleanup_all_test_data(
            endpoint_name="test-endpoint",
            email="test@example.com",
            dry_run=True
        )

        # Verify the cleanup methods were called
        self.test_manager.cleanup_test_conversations.assert_called_once_with(
            endpoint_name="test-endpoint",
            email="test@example.com",
            created_after=None,
            dry_run=True,
        )
        self.test_manager.cleanup_test_messages.assert_called_once_with(
            endpoint_name="test-endpoint",
            email="test@example.com",
            created_after=None,
            dry_run=True,
        )

        # Verify the result structure
        assert 'conversations' in result
        assert 'messages' in result
        assert result['conversations'] == {'deleted': 2, 'errors': 0}
        assert result['messages'] == {'deleted': 5, 'errors': 1}

    def test_count_test_data(self):
        """Test counting test data."""
        # Mock get_all_test_data
        mock_test_data = {
            'conversations': Mock(total=10),
            'messages': Mock(total=25),
            'inferences': Mock(total=15)
        }
        self.test_manager.get_all_test_data = Mock(return_value=mock_test_data)

        # Count test data
        result = self.test_manager.count_test_data()

        # Verify the result
        assert result['conversations'] == 10
        assert result['messages'] == 25
        assert result['inferences'] == 15

    def test_cleanup_test_messages(self):
        """Test cleaning up test messages."""
        # Mock test messages
        mock_messages = Mock(spec=PaginatedResponse)
        mock_messages.items = [Mock(id="msg1"), Mock(id="msg2")]
        self.mock_client.messages.list_test_messages.return_value = mock_messages

        # Run cleanup (dry run)
        result = self.test_manager.cleanup_test_messages(dry_run=True)

        # Verify the list method was called
        self.mock_client.messages.list_test_messages.assert_called_once_with(
            endpoint_name=None,
            email=None,
            created_date_start=None,
            per_page=100,
        )

        # Verify the result
        assert result['deleted'] == 2
        assert result['errors'] == 0
