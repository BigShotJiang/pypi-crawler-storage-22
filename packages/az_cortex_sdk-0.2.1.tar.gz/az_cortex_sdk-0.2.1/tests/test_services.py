"""Integration tests for EnvironmentService."""

from unittest.mock import Mock, patch

import pytest

from az_cortex_sdk import CortexClient, CortexConfig
from az_cortex_sdk.models import (
    Environment,
    EnvironmentVersion,
    PaginatedResponse,
    RegistrationResult,
)


class TestEnvironmentService:
    """Test cases for EnvironmentService integration."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock client for testing."""
        config = CortexConfig(
            base_url="https://test.example.com",
            client_id="test-id",
            client_secret="test-secret",
            tenant="test-tenant",
        )
        with patch("az_cortex_sdk.client.HTTPClient") as mock_http_class:
            mock_http_instance = Mock()
            mock_http_class.return_value = mock_http_instance
            client = CortexClient(config=config)
            client._mock_http_client = mock_http_instance  # Store reference for tests
            return client

    @pytest.fixture
    def mock_http_client(self):
        """Create a mock HTTP client."""
        return Mock()

    def test_list_environments_empty(self, mock_client):
        """Test listing environments when none exist."""
        mock_client._mock_http_client.get.return_value = {
            "items": [],
            "page": 1,
            "perPage": 25,
            "total": 0,
        }

        result = mock_client.environments.list()

        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 0
        assert result.page == 1
        assert result.total == 0
        assert not result.has_next
        assert not result.has_prev
        mock_client._mock_http_client.get.assert_called_once_with(
            "/environments", params={"page": 1, "perPage": 25, "includeLatest": True}
        )

    def test_list_environments_with_data(self, mock_client):
        """Test listing environments with data."""
        mock_environments = [
            {
                "name": "test-env-1",
                "id": "env-1",
                "latest_version": "1.0.0",
                "properties": {"type": "test"},
            },
            {
                "name": "test-env-2",
                "id": "env-2",
                "latest_version": "2.0.0",
                "properties": {"type": "production"},
            },
        ]

        mock_client._mock_http_client.get.return_value = {
            "items": mock_environments,
            "page": 1,
            "perPage": 25,
            "total": 2,
        }

        result = mock_client.environments.list()

        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 2
        assert all(isinstance(env, Environment) for env in result.items)
        assert result.items[0].name == "test-env-1"
        assert result.items[1].name == "test-env-2"

    def test_create_environment_success(self, mock_client):
        """Test successful environment creation."""
        mock_client._mock_http_client.post.return_value = {
            "success": True,
            "name": "test-env",
            "version": "1.0.0",
            "id": "env-123",
        }

        result = mock_client.environments.create(
            name="test-env",
            version="1.0.0",
            description="Test environment",
            image="test-image:latest",
            tags={"purpose": "testing"},
        )

        assert isinstance(result, RegistrationResult)
        assert result.success is True
        assert result.name == "test-env"
        assert result.version == "1.0.0"
        assert result.id == "env-123"
        assert result.error is None

        mock_client._mock_http_client.post.assert_called_once_with(
            "/environment-versions/1?environmentName=test-env",
            data={
                "name": "test-env",
                "version": "1.0.0",
                "description": "Test environment",
                "image": "test-image:latest",
                "tags": {"purpose": "testing"},
            },
        )

    def test_create_environment_failure(self, mock_client):
        """Test environment creation failure."""
        mock_client._mock_http_client.post.return_value = {
            "success": False,
            "name": "test-env",
            "version": "1.0.0",
            "error": "Environment already exists",
        }

        result = mock_client.environments.create(name="test-env", version="1.0.0")

        assert isinstance(result, RegistrationResult)
        assert result.success is False
        assert result.error == "Environment already exists"

    def test_get_environment_success(self, mock_client):
        """Test successful environment retrieval."""
        mock_env_data = {
            "name": "test-env",
            "version": "1.0.0",
            "description": "Test environment",
            "image": "test-image:latest",
            "tags": {"purpose": "testing"},
        }

        mock_client._mock_http_client.get.return_value = mock_env_data

        result = mock_client.environments.get("test-env", "1.0.0")

        assert isinstance(result, EnvironmentVersion)
        assert result.name == "test-env"
        assert result.version == "1.0.0"
        assert result.description == "Test environment"

        mock_client._mock_http_client.get.assert_called_once_with(
            "/environment-versions/1?environmentName=test-env"
        )

    def test_get_environment_not_found(self, mock_client):
        """Test environment retrieval when not found."""
        mock_client._mock_http_client.get.side_effect = Exception("Not found")

        result = mock_client.environments.get("nonexistent", "1.0.0")

        assert result is None

    def test_update_environment_success(self, mock_client):
        """Test successful environment update."""
        mock_client._mock_http_client.put.return_value = {
            "success": True,
            "name": "test-env",
            "version": "1.0.0",
            "id": "env-123",
        }

        result = mock_client.environments.update(
            name="test-env",
            version="1.0.0",
            description="Updated description",
            tags={"status": "updated"},
        )

        assert isinstance(result, RegistrationResult)
        assert result.success is True
        assert result.name == "test-env"

        mock_client._mock_http_client.put.assert_called_once_with(
            "/environments/test-env/versions/1.0.0",
            data={"description": "Updated description", "tags": {"status": "updated"}},
        )

    @pytest.mark.xfail(reason="Delete operations are not supported by the API")
    def test_delete_environment_success(self, mock_client):
        """Test successful environment deletion."""
        mock_client._mock_http_client.delete.return_value = {"success": True}

        result = mock_client.environments.delete("test-env", "1.0.0")

        assert result == {"success": True}
        mock_client._mock_http_client.delete.assert_called_once_with(
            "/environments/test-env/versions/1.0.0"
        )

    def test_list_environment_versions(self, mock_client):
        """Test listing environment versions."""
        mock_versions = [
            {"name": "test-env", "version": "1.0.0", "description": "First version"},
            {"name": "test-env", "version": "2.0.0", "description": "Second version"},
        ]

        mock_client._mock_http_client.get.return_value = {
            "items": mock_versions,
            "page": 1,
            "perPage": 25,
            "total": 2,
        }

        result = mock_client.environments.list_versions("test-env")

        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 2
        assert all(isinstance(version, EnvironmentVersion) for version in result.items)
        assert result.items[0].version == "1.0.0"
        assert result.items[1].version == "2.0.0"

        mock_client._mock_http_client.get.assert_called_once_with(
            "/environments/test-env/versions", params={"page": 1, "perPage": 25}
        )


class TestEnvironmentWorkflow:
    """Test complete environment workflow scenarios."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock client for workflow testing."""
        config = CortexConfig(
            base_url="https://test.example.com",
            client_id="test-id",
            client_secret="test-secret",
            tenant="test-tenant",
        )
        with patch("az_cortex_sdk.client.HTTPClient") as mock_http_class:
            mock_http_instance = Mock()
            mock_http_class.return_value = mock_http_instance
            client = CortexClient(config=config)
            client._mock_http_client = mock_http_instance
            return client

    @pytest.mark.xfail(reason="Delete operations are not supported by the API")
    def test_complete_environment_workflow(self, mock_client):
        """Test complete workflow: list → create → update → list → delete."""

        # Step 1: Initial list (empty)
        mock_client._mock_http_client.get.return_value = {
            "items": [],
            "page": 1,
            "perPage": 25,
            "total": 0,
        }

        initial_envs = mock_client.environments.list()
        assert len(initial_envs.items) == 0

        # Step 2: Create environment
        mock_client._mock_http_client.post.return_value = {
            "success": True,
            "name": "workflow-env",
            "version": "1.0.0",
            "id": "env-workflow-123",
        }

        create_result = mock_client.environments.create(
            name="workflow-env",
            version="1.0.0",
            description="Workflow test environment",
            image="test-image:latest",
        )
        assert create_result.success is True
        assert create_result.name == "workflow-env"

        # Step 3: Update environment
        mock_client._mock_http_client.put.return_value = {
            "success": True,
            "name": "workflow-env",
            "version": "1.0.0",
            "id": "env-workflow-123",
        }

        update_result = mock_client.environments.update(
            name="workflow-env",
            version="1.0.0",
            description="Updated workflow test environment",
            tags={"status": "updated"},
        )
        assert update_result.success is True

        # Step 4: List again (should show created environment)
        mock_client._mock_http_client.get.return_value = {
            "items": [
                {
                    "name": "workflow-env",
                    "id": "env-workflow-123",
                    "latest_version": "1.0.0",
                }
            ],
            "page": 1,
            "perPage": 25,
            "total": 1,
        }

        updated_envs = mock_client.environments.list()
        assert len(updated_envs.items) == 1
        assert updated_envs.items[0].name == "workflow-env"

        # Step 5: Delete environment
        mock_client._mock_http_client.delete.return_value = {"success": True}

        delete_result = mock_client.environments.delete("workflow-env", "1.0.0")
        assert delete_result == {"success": True}

        # Verify all calls were made
        assert mock_client._mock_http_client.get.call_count == 2  # Two list calls
        assert mock_client._mock_http_client.post.call_count == 1  # One create call
        assert mock_client._mock_http_client.put.call_count == 1  # One update call
        assert mock_client._mock_http_client.delete.call_count == 1  # One delete call
"""Integration tests for ModelService."""

import os
import tempfile
from pathlib import Path

import pytest

from az_cortex_sdk.models import (
    Model,
    ModelVersion,
    UploadResult,
)


class TestModelService:
    """Test cases for ModelService integration."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock client for testing."""
        config = CortexConfig(
            base_url="https://test.example.com",
            client_id="test-id",
            client_secret="test-secret",
            tenant="test-tenant",
        )
        with patch("az_cortex_sdk.client.HTTPClient") as mock_http_class:
            mock_http_instance = Mock()
            mock_http_class.return_value = mock_http_instance
            client = CortexClient(config=config)
            client._mock_http_client = mock_http_instance
            return client

    @pytest.fixture
    def mock_http_client(self):
        """Create a mock HTTP client."""
        return Mock()

    @pytest.fixture
    def temp_model_file(self):
        """Create a temporary model file for testing."""
        with tempfile.NamedTemporaryFile(mode="wb", suffix=".pkl", delete=False) as f:
            f.write(b"fake model data")
            temp_path = f.name

        yield temp_path

        # Cleanup
        if os.path.exists(temp_path):
            os.unlink(temp_path)

    def test_list_models_empty(self, mock_client):
        """Test listing models when none exist."""
        mock_client._mock_http_client.get.return_value = {
            "items": [],
            "page": 1,
            "perPage": 25,
            "total": 0,
        }

        result = mock_client.models.list()

        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 0
        assert result.page == 1
        assert result.total == 0
        assert not result.has_next
        assert not result.has_prev
        mock_client._mock_http_client.get.assert_called_once_with(
            "/models", params={"page": 1, "perPage": 25, "includeLatest": True}
        )

    def test_list_models_with_data(self, mock_client):
        """Test listing models with data."""
        mock_models = [
            {
                "name": "test-model-1",
                "id": "model-1",
                "latest_version": "1.0.0",
                "properties": {"type": "sklearn"},
            },
            {
                "name": "test-model-2",
                "id": "model-2",
                "latest_version": "2.0.0",
                "properties": {"type": "pytorch"},
            },
        ]

        mock_client._mock_http_client.get.return_value = {
            "items": mock_models,
            "page": 1,
            "perPage": 25,
            "total": 2,
        }

        result = mock_client.models.list()

        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 2
        assert all(isinstance(model, Model) for model in result.items)
        assert result.items[0].name == "test-model-1"
        assert result.items[1].name == "test-model-2"

    def test_get_model_success(self, mock_client):
        """Test successful model retrieval."""
        mock_model_data = {
            "name": "test-model",
            "version": "1.0.0",
            "description": "Test model",
            "model_uri": "azureml://models/test-model/1.0.0",
            "model_type": "sklearn",
            "tags": {"framework": "scikit-learn"},
        }

        mock_client._mock_http_client.get.return_value = mock_model_data

        result = mock_client.models.get("test-model", "1.0.0")

        assert isinstance(result, ModelVersion)
        assert result.name == "test-model"
        assert result.version == "1.0.0"
        assert result.description == "Test model"
        assert result.model_type == "sklearn"

        mock_client._mock_http_client.get.assert_called_once_with(
            "/model-versions/1?modelName=test-model"
        )

    def test_get_model_not_found(self, mock_client):
        """Test model retrieval when not found."""
        mock_client._mock_http_client.get.side_effect = Exception("Not found")

        result = mock_client.models.get("nonexistent", "1.0.0")

        assert result is None

    def test_create_model_success(self, mock_client):
        """Test successful model creation."""
        mock_client._mock_http_client.post.return_value = {
            "success": True,
            "name": "test-model",
            "version": "1.0.0",
            "id": "model-123",
        }

        result = mock_client.models.create(
            name="test-model",
            version="1.0.0",
            description="Test model",
            model_type="sklearn",
            tags={"framework": "scikit-learn"},
        )

        assert isinstance(result, RegistrationResult)
        assert result.success is True
        assert result.name == "test-model"
        assert result.version == "1.0.0"
        assert result.id == "model-123"
        assert result.error is None

        mock_client._mock_http_client.post.assert_called_once_with(
            "/models",
            data={
                "name": "test-model",
                "version": "1.0.0",
                "description": "Test model",
                "modelType": "sklearn",
                "tags": {"framework": "scikit-learn"},
            },
        )

    def test_upload_and_create_success(self, mock_client, temp_model_file):
        """Test successful model upload and creation."""
        mock_client._mock_http_client.post.return_value = {
            "success": True,
            "name": "test-model",
            "version": "1.0.0",
            "id": "model-123",
            "modelUri": "azureml://models/test-model/1.0.0",
        }

        result = mock_client.models.upload_and_create(
            file_path=temp_model_file,
            name="test-model",
            version="1.0.0",
            description="Uploaded test model",
            model_type="sklearn",
        )

        assert "upload_result" in result
        assert "registration_result" in result

        upload_result = result["upload_result"]
        assert isinstance(upload_result, UploadResult)
        assert upload_result.success is True
        assert upload_result.file_name == Path(temp_model_file).name
        assert upload_result.azure_ml_uri == "azureml://models/test-model/1.0.0"

        reg_result = result["registration_result"]
        assert isinstance(reg_result, RegistrationResult)
        assert reg_result.success is True
        assert reg_result.name == "test-model"

    def test_upload_and_create_file_not_found(self, mock_client):
        """Test upload with non-existent file."""
        result = mock_client.models.upload_and_create(
            file_path="/nonexistent/file.pkl", name="test-model", version="1.0.0"
        )

        assert "upload_result" in result
        upload_result = result["upload_result"]
        assert isinstance(upload_result, UploadResult)
        assert upload_result.success is False
        assert "File not found" in upload_result.error

    def test_upload_buffer_and_create_success(self, mock_client):
        """Test successful buffer upload and model creation."""
        mock_client._mock_http_client.post.return_value = {
            "success": True,
            "name": "test-model",
            "version": "1.0.0",
            "id": "model-123",
            "modelUri": "azureml://models/test-model/1.0.0",
        }

        buffer_data = b"fake model data"

        result = mock_client.models.upload_buffer_and_create(
            buffer=buffer_data,
            file_name="model.pkl",
            name="test-model",
            version="1.0.0",
            description="Buffer uploaded model",
        )

        assert "upload_result" in result
        assert "registration_result" in result

        upload_result = result["upload_result"]
        assert isinstance(upload_result, UploadResult)
        assert upload_result.success is True
        assert upload_result.file_name == "model.pkl"
        assert upload_result.size_bytes == len(buffer_data)

    @pytest.mark.xfail(reason="Delete operations are not supported by the API")
    def test_delete_model_success(self, mock_client):
        """Test successful model deletion."""
        mock_client._mock_http_client.delete.return_value = {"success": True}

        result = mock_client.models.delete("test-model", "1.0.0")

        assert result == {"success": True}
        mock_client._mock_http_client.delete.assert_called_once_with(
            "/models/test-model/versions/1.0.0"
        )

    def test_list_model_versions(self, mock_client):
        """Test listing model versions."""
        mock_versions = [
            {
                "name": "test-model",
                "version": "1.0.0",
                "description": "First version",
                "model_type": "sklearn",
            },
            {
                "name": "test-model",
                "version": "2.0.0",
                "description": "Second version",
                "model_type": "sklearn",
            },
        ]

        mock_client._mock_http_client.get.return_value = {
            "items": mock_versions,
            "page": 1,
            "perPage": 25,
            "total": 2,
        }

        result = mock_client.models.list_versions("test-model")

        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 2
        assert all(isinstance(version, ModelVersion) for version in result.items)
        assert result.items[0].version == "1.0.0"
        assert result.items[1].version == "2.0.0"

        mock_client._mock_http_client.get.assert_called_once_with(
            "/models/test-model/versions", params={"page": 1, "perPage": 25}
        )


class TestModelWorkflow:
    """Test complete model workflow scenarios."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock client for workflow testing."""
        config = CortexConfig(
            base_url="https://test.example.com",
            client_id="test-id",
            client_secret="test-secret",
            tenant="test-tenant",
        )
        with patch("az_cortex_sdk.client.HTTPClient") as mock_http_class:
            mock_http_instance = Mock()
            mock_http_class.return_value = mock_http_instance
            client = CortexClient(config=config)
            client._mock_http_client = mock_http_instance
            return client

    @pytest.fixture
    def temp_model_file(self):
        """Create a temporary model file for testing."""
        with tempfile.NamedTemporaryFile(mode="wb", suffix=".pkl", delete=False) as f:
            f.write(b"fake model data for workflow test")
            temp_path = f.name

        yield temp_path

        # Cleanup
        if os.path.exists(temp_path):
            os.unlink(temp_path)

    @pytest.mark.xfail(reason="Delete operations are not supported by the API")
    def test_complete_model_workflow(self, mock_client, temp_model_file):
        """Test complete workflow: list → upload_and_create → list → delete."""
        # Step 1: Initial list (empty)
        mock_client._mock_http_client.get.return_value = {
            "items": [],
            "page": 1,
            "perPage": 25,
            "total": 0,
        }

        initial_models = mock_client.models.list()
        assert len(initial_models.items) == 0

        # Step 2: Upload and create model
        mock_client._mock_http_client.post.return_value = {
            "success": True,
            "name": "workflow-model",
            "version": "1.0.0",
            "id": "model-workflow-123",
            "modelUri": "azureml://models/workflow-model/1.0.0",
        }

        upload_result = mock_client.models.upload_and_create(
            file_path=temp_model_file,
            name="workflow-model",
            version="1.0.0",
            description="Workflow test model",
            model_type="sklearn",
            tags={"purpose": "testing"},
        )

        assert upload_result["upload_result"].success is True
        assert upload_result["registration_result"].success is True
        assert upload_result["registration_result"].name == "workflow-model"

        # Step 3: List again (should show created model)
        mock_client._mock_http_client.get.return_value = {
            "items": [
                {
                    "name": "workflow-model",
                    "id": "model-workflow-123",
                    "latest_version": "1.0.0",
                    "properties": {"type": "sklearn"},
                }
            ],
            "page": 1,
            "perPage": 25,
            "total": 1,
        }

        updated_models = mock_client.models.list()
        assert len(updated_models.items) == 1
        assert updated_models.items[0].name == "workflow-model"

        # Step 4: Delete model
        mock_client._mock_http_client.delete.return_value = {"success": True}

        delete_result = mock_client.models.delete("workflow-model", "1.0.0")
        assert delete_result == {"success": True}

        # Verify all calls were made
        assert mock_client._mock_http_client.get.call_count == 2  # Two list calls
        assert (
            mock_client._mock_http_client.post.call_count == 1
        )  # One upload_and_create call
        assert mock_client._mock_http_client.delete.call_count == 1  # One delete call
"""Tests for endpoint and deployment services."""


import pytest

from az_cortex_sdk.exceptions import NotFoundError
from az_cortex_sdk.models import (
    Deployment,
    Endpoint,
    InferenceResponse,
)
from az_cortex_sdk.services.deployments import DeploymentService
from az_cortex_sdk.services.endpoints import EndpointService


class TestEndpointService:
    """Test cases for EndpointService."""

    def setup_method(self):
        """Set up test fixtures."""
        self.mock_http_client = Mock()
        self.service = EndpointService(self.mock_http_client)

    def test_list_endpoints(self):
        """Test listing endpoints."""
        # Mock response
        mock_response = {
            "documents": [
                {
                    "id": "endpoint-1",
                    "name": "test-endpoint",
                    "type": "Microsoft.MachineLearningServices/workspaces/onlineEndpoints",
                    "location": "eastus",
                    "properties": {
                        "authMode": "Key",
                        "provisioningState": "Succeeded",
                        "scoringUri": "https://test-endpoint.eastus.inference.ml.azure.com/score"
                    }
                }
            ],
            "totalDocuments": 1,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Test list
        result = self.service.list()

        # Assertions
        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 1
        assert result.items[0]["name"] == "test-endpoint"
        assert result.items[0]["location"] == "eastus"
        assert result.total == 1
        assert result.page == 1
        assert result.per_page == 25
        self.mock_http_client.get.assert_called_once_with(
            "/endpoints",
            params={"page": 1, "perPage": 25}
        )

    def test_get_endpoint(self):
        """Test getting a specific endpoint."""
        # Mock response
        mock_response = {
            "id": "endpoint-1",
            "name": "test-endpoint",
            "type": "Microsoft.MachineLearningServices/workspaces/onlineEndpoints",
            "location": "eastus",
            "properties": {
                "authMode": "Key",
                "provisioningState": "Succeeded",
                "scoringUri": "https://test-endpoint.eastus.inference.ml.azure.com/score"
            }
        }
        self.mock_http_client.get.return_value = mock_response

        # Test get
        result = self.service.get("test-endpoint")

        # Assertions
        assert isinstance(result, Endpoint)
        assert result.name == "test-endpoint"
        assert result.location == "eastus"
        assert result.properties.auth_mode == "Key"
        assert result.properties.provisioning_state == "Succeeded"
        self.mock_http_client.get.assert_called_once_with("/endpoints/test-endpoint")

    def test_get_endpoint_not_found(self):
        """Test getting a non-existent endpoint."""
        self.mock_http_client.get.side_effect = NotFoundError("Endpoint not found")

        result = self.service.get("non-existent")

        assert result is None

    def test_create_endpoint(self):
        """Test creating an endpoint."""
        # Mock response
        mock_response = {"message": "Endpoint created successfully"}
        self.mock_http_client.post.return_value = mock_response

        # Test create
        result = self.service.create("new-endpoint")

        # Assertions
        assert result == mock_response
        expected_data = {"name": "new-endpoint"}
        self.mock_http_client.post.assert_called_once_with("/endpoints", data=expected_data)

    def test_delete_endpoint(self):
        """Test deleting an endpoint."""
        # Mock response
        mock_response = {"message": "Endpoint deleted successfully"}
        self.mock_http_client.delete.return_value = mock_response

        # Test delete
        result = self.service.delete("test-endpoint")

        # Assertions
        assert result == mock_response
        expected_data = {"name": "test-endpoint"}
        self.mock_http_client.delete.assert_called_once_with("/endpoints", data=expected_data)

    def test_infer_success(self):
        """Test successful inference."""
        # Mock response
        mock_response = {
            "messages": {
                "documents": ["doc1", "doc2"],
                "content": "This is a test response",
                "role": "assistant",
                "metadatas": [{"key": "value"}]
            }
        }
        self.mock_http_client.post.return_value = mock_response

        # Test inference
        result = self.service.infer("test-endpoint", {"prompt": "test"})

        # Assertions
        assert isinstance(result, InferenceResponse)
        assert result.messages is not None
        assert result.messages["content"] == "This is a test response"
        self.mock_http_client.post.assert_called_once_with(
            "/endpoints/test-endpoint/infer",
            data={"inputs": {"prompt": "test"}}
        )

    def test_infer_endpoint_not_found(self):
        """Test inference with non-existent endpoint."""
        self.mock_http_client.post.side_effect = NotFoundError("Endpoint not found")

        with pytest.raises(NotFoundError):
            self.service.infer("non-existent-endpoint", {"prompt": "test"})

    def test_transform_endpoint_data(self):
        """Test endpoint data transformation."""
        # Test data with camelCase fields
        data = {
            "id": "endpoint-1",
            "name": "test-endpoint",
            "properties": {
                "authMode": "Key",
                "provisioningState": "Succeeded",
                "publicNetworkAccess": "Enabled",
                "scoringUri": "https://example.com/score",
                "swaggerUri": "https://example.com/swagger"
            },
            "systemData": {
                "createdBy": "user@example.com",
                "createdAt": "2024-01-01T00:00:00Z"
            }
        }

        result = self.service._transform_endpoint_data(data)

        # Assertions
        assert result["id"] == "endpoint-1"
        assert result["name"] == "test-endpoint"
        assert "system_data" in result
        assert "systemData" not in result

        props = result["properties"]
        assert props["auth_mode"] == "Key"
        assert props["provisioning_state"] == "Succeeded"
        assert props["public_network_access"] == "Enabled"
        assert props["scoring_uri"] == "https://example.com/score"
        assert props["swagger_uri"] == "https://example.com/swagger"


class TestDeploymentService:
    """Test cases for DeploymentService."""

    def setup_method(self):
        """Set up test fixtures."""
        self.mock_http_client = Mock()
        self.service = DeploymentService(self.mock_http_client)

    def test_list_deployments(self):
        """Test listing deployments."""
        # Mock response
        mock_response = {
            "documents": [
                {
                    "id": "deployment-1",
                    "name": "test-deployment",
                    "type": "Microsoft.MachineLearningServices/workspaces/onlineEndpoints/deployments",
                    "location": "eastus",
                    "properties": {
                        "provisioningState": "Succeeded",
                        "instanceType": "Standard_DS1_v2"
                    }
                }
            ],
            "totalDocuments": 1,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Test list
        result = self.service.list("test-endpoint")

        # Assertions
        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 1
        assert result.items[0]["name"] == "test-deployment"
        assert result.items[0]["location"] == "eastus"
        assert result.total == 1
        self.mock_http_client.get.assert_called_once_with(
            "/deployments",
            params={"endpointName": "test-endpoint", "page": 1, "perPage": 25}
        )

    def test_get_deployment(self):
        """Test getting a specific deployment."""
        # Mock response
        mock_response = {
            "id": "deployment-1",
            "name": "test-deployment",
            "type": "Microsoft.MachineLearningServices/workspaces/onlineEndpoints/deployments",
            "location": "eastus",
            "properties": {
                "provisioningState": "Succeeded",
                "instanceType": "Standard_DS1_v2"
            }
        }
        self.mock_http_client.get.return_value = mock_response

        # Test get
        result = self.service.get("test-deployment", "test-endpoint")

        # Assertions
        assert isinstance(result, Deployment)
        assert result.name == "test-deployment"
        assert result.location == "eastus"
        self.mock_http_client.get.assert_called_once_with(
            "/deployments/test-deployment",
            params={"endpointName": "test-endpoint"}
        )

    def test_get_deployment_not_found(self):
        """Test getting a non-existent deployment."""
        self.mock_http_client.get.side_effect = NotFoundError("Deployment not found")

        result = self.service.get("non-existent", "test-endpoint")

        assert result is None

    def test_create_deployment(self):
        """Test creating a deployment."""
        # Mock response
        mock_response = {"message": "Deployment created successfully"}
        self.mock_http_client.post.return_value = mock_response

        # Test create
        result = self.service.create(
            endpoint_name="test-endpoint",
            name="new-deployment",
            instance_type="Standard_DS1_v2",
            model_name="test-model",
            model_version="1",
            environment_name="test-env",
            environment_version="1",
            scoring_script_name="score.py",
            traffic={"default": 100},
            secrets=["secret1"]
        )

        # Assertions
        assert result == mock_response
        expected_data = {
            "endpointName": "test-endpoint",
            "name": "new-deployment",
            "instanceType": "Standard_DS1_v2",
            "modelName": "test-model",
            "modelVersion": "1",
            "environmentName": "test-env",
            "environmentVersion": "1",
            "scoringScriptName": "score.py",
            "traffic": {"default": 100},
            "secrets": ["secret1"]
        }
        self.mock_http_client.post.assert_called_once_with("/deployments", data=expected_data)

    def test_create_deployment_without_secrets(self):
        """Test creating a deployment without secrets."""
        # Mock response
        mock_response = {"message": "Deployment created successfully"}
        self.mock_http_client.post.return_value = mock_response

        # Test create without secrets
        result = self.service.create(
            endpoint_name="test-endpoint",
            name="new-deployment",
            instance_type="Standard_D2a_v4",
            model_name="test-model",
            model_version="1",
            environment_name="test-env",
            environment_version="1",
            scoring_script_name="score.py",
            traffic={"blue": 50, "green": 50}
        )

        # Assertions
        assert result == mock_response
        expected_data = {
            "endpointName": "test-endpoint",
            "name": "new-deployment",
            "instanceType": "Standard_D2a_v4",
            "modelName": "test-model",
            "modelVersion": "1",
            "environmentName": "test-env",
            "environmentVersion": "1",
            "scoringScriptName": "score.py",
            "traffic": {"blue": 50, "green": 50}
        }
        self.mock_http_client.post.assert_called_once_with("/deployments", data=expected_data)

    def test_delete_deployment(self):
        """Test deleting a deployment."""
        # Mock response
        mock_response = {"message": "Deployment deleted successfully"}
        self.mock_http_client.delete.return_value = mock_response

        # Test delete
        result = self.service.delete("test-deployment", "test-endpoint")

        # Assertions
        assert result == mock_response
        self.mock_http_client.delete.assert_called_once_with(
            "/deployments/test-deployment",
            params={"endpointName": "test-endpoint"}
        )

    def test_transform_deployment_data(self):
        """Test deployment data transformation."""
        # Test data with systemData
        data = {
            "id": "deployment-1",
            "name": "test-deployment",
            "properties": {"instanceType": "Standard_DS1_v2"},
            "systemData": {
                "createdBy": "user@example.com",
                "createdAt": "2024-01-01T00:00:00Z"
            }
        }

        result = self.service._transform_deployment_data(data)

        # Assertions
        assert result["id"] == "deployment-1"
        assert result["name"] == "test-deployment"
        assert "system_data" in result
        assert "systemData" not in result
"""Tests for scoring service."""

from unittest.mock import mock_open

import pytest

from az_cortex_sdk.models import ScoringScript, ScoringScriptList
from az_cortex_sdk.services.scorings import ScoringService


class TestScoringService:
    """Test cases for ScoringService."""

    def setup_method(self):
        """Set up test fixtures."""
        self.mock_http_client = Mock()
        self.service = ScoringService(self.mock_http_client)

    def test_list_scoring_scripts(self):
        """Test listing scoring scripts."""
        # Mock response
        mock_response = {
            "documents": [
                {
                    "name": "test-script",
                    "uri": "https://example.com/script.py",
                    "fileName": "script.py"
                }
            ],
            "totalDocuments": 1
        }
        self.mock_http_client.get.return_value = mock_response

        # Call service
        result = self.service.list()

        # Assertions
        assert isinstance(result, ScoringScriptList)
        assert len(result.documents) == 1
        assert result.total_documents == 1
        assert result.documents[0].name == "test-script"

        # Verify HTTP call
        self.mock_http_client.get.assert_called_once_with(
            "/scorings",
            params={"page": 1, "perPage": 25}
        )

    def test_list_scoring_scripts_with_pagination(self):
        """Test listing scoring scripts with custom pagination."""
        mock_response = {
            "documents": [],
            "totalDocuments": 0
        }
        self.mock_http_client.get.return_value = mock_response

        # Call service with custom pagination
        self.service.list(page=2, per_page=10)

        # Verify HTTP call with custom params
        self.mock_http_client.get.assert_called_once_with(
            "/scorings",
            params={"page": 2, "perPage": 10}
        )

    def test_get_scoring_script(self):
        """Test getting a specific scoring script."""
        # Mock response
        mock_response = {
            "name": "test-script",
            "uri": "https://example.com/script.py",
            "fileName": "script.py"
        }
        self.mock_http_client.get.return_value = mock_response

        # Call service
        result = self.service.get("test-script")

        # Assertions
        assert isinstance(result, ScoringScript)
        assert result.name == "test-script"
        assert result.uri == "https://example.com/script.py"
        assert result.file_name == "script.py"

        # Verify HTTP call
        self.mock_http_client.get.assert_called_once_with("/scorings/test-script")

    def test_get_scoring_script_not_found(self):
        """Test getting a non-existent scoring script."""
        # Mock HTTP client to raise exception
        self.mock_http_client.get.side_effect = Exception("Script not found")

        # Call service and expect NotFoundError
        with pytest.raises(NotFoundError, match="Scoring script 'nonexistent' not found"):
            self.service.get("nonexistent")

    def test_create_scoring_script(self):
        """Test creating a new scoring script."""
        # Mock response
        mock_response = {"message": "Scoring script created successfully"}
        self.mock_http_client.post.return_value = mock_response

        script_content = "def init():\n    pass\n\ndef run(data):\n    return data"

        # Call service
        result = self.service.create("new-script", script_content)

        # Assertions
        assert result == mock_response

        # Verify HTTP call
        expected_data = {
            "name": "new-script",
            "content": script_content
        }
        self.mock_http_client.post.assert_called_once_with("/scorings", data=expected_data)

    def test_create_from_file(self):
        """Test creating a scoring script from a file."""
        # Mock response
        mock_response = {"message": "Scoring script created successfully"}
        self.mock_http_client.post.return_value = mock_response

        script_content = "def init():\n    pass\n\ndef run(data):\n    return data"

        # Mock file reading
        with patch("builtins.open", mock_open(read_data=script_content)):
            result = self.service.create_from_file("file-script", "/path/to/script.py")

        # Assertions
        assert result == mock_response

        # Verify HTTP call
        expected_data = {
            "name": "file-script",
            "content": script_content
        }
        self.mock_http_client.post.assert_called_once_with("/scorings", data=expected_data)

    def test_create_from_file_handles_encoding(self):
        """Test creating a scoring script from a file with proper encoding."""
        mock_response = {"message": "Scoring script created successfully"}
        self.mock_http_client.post.return_value = mock_response

        script_content = "# -*- coding: utf-8 -*-\ndef init():\n    pass"

        # Mock file reading and verify encoding parameter
        with patch("builtins.open", mock_open(read_data=script_content)) as mock_file:
            self.service.create_from_file("encoded-script", "/path/to/script.py")

            # Verify file was opened with correct encoding
            mock_file.assert_called_once_with("/path/to/script.py", encoding='utf-8')
"""Tests for secrets service."""


import pytest

from az_cortex_sdk.models import SecretResponse, SecretsList
from az_cortex_sdk.services.secrets import SecretsService


class TestSecretsService:
    """Test cases for SecretsService."""

    def setup_method(self):
        """Set up test fixtures."""
        self.mock_http_client = Mock()
        self.service = SecretsService(self.mock_http_client)

    def test_list_secrets(self):
        """Test listing secrets."""
        # Mock response
        mock_response = {
            "documents": [
                {
                    "name": "api-key",
                    "enabled": True,
                    "created": "2023-01-01T00:00:00Z",
                    "updated": "2023-01-02T00:00:00Z"
                },
                {
                    "name": "db-password",
                    "enabled": True,
                    "created": "2023-01-03T00:00:00Z"
                }
            ],
            "totalDocuments": 2,
            "page": 1,
            "perPage": 25
        }

        self.mock_http_client.get.return_value = mock_response

        # Call the method
        result = self.service.list()

        # Assertions
        assert isinstance(result, SecretsList)
        assert len(result.documents) == 2
        assert result.total_documents == 2
        assert result.documents[0].name == "api-key"
        assert result.documents[0].enabled is True
        assert result.documents[1].name == "db-password"

        # Verify HTTP client was called correctly
        self.mock_http_client.get.assert_called_once_with(
            "/secrets",
            params={"page": 1, "perPage": 25}
        )

    def test_list_secrets_with_pagination(self):
        """Test listing secrets with custom pagination."""
        mock_response = {
            "documents": [],
            "totalDocuments": 0,
            "page": 2,
            "perPage": 10
        }

        self.mock_http_client.get.return_value = mock_response

        # Call with custom pagination
        self.service.list(page=2, per_page=10)

        # Verify HTTP client was called with correct params
        self.mock_http_client.get.assert_called_once_with(
            "/secrets",
            params={"page": 2, "perPage": 10}
        )

    def test_create_secret(self):
        """Test creating a new secret."""
        mock_response = {
            "name": "new-secret",
            "message": "Secret created successfully"
        }

        self.mock_http_client.post.return_value = mock_response

        # Call the method
        result = self.service.create("new-secret", "secret-value")

        # Assertions
        assert isinstance(result, SecretResponse)
        assert result.name == "new-secret"
        assert result.message == "Secret created successfully"

        # Verify HTTP client was called correctly
        self.mock_http_client.post.assert_called_once_with(
            "/secrets",
            data={"name": "new-secret", "value": "secret-value"}
        )

    def test_update_secret(self):
        """Test updating an existing secret."""
        mock_response = {
            "name": "existing-secret",
            "message": "Secret updated successfully"
        }

        self.mock_http_client.put.return_value = mock_response

        # Call the method
        result = self.service.update("existing-secret", "new-value")

        # Assertions
        assert isinstance(result, SecretResponse)
        assert result.name == "existing-secret"
        assert result.message == "Secret updated successfully"

        # Verify HTTP client was called correctly
        self.mock_http_client.put.assert_called_once_with(
            "/secrets/existing-secret",
            data={"value": "new-value"}
        )

    def test_update_secret_not_found(self):
        """Test updating a non-existent secret."""
        self.mock_http_client.put.side_effect = NotFoundError("Secret not found")

        # Call the method and expect NotFoundError
        with pytest.raises(NotFoundError, match="Secret 'nonexistent' not found"):
            self.service.update("nonexistent", "value")

    def test_delete_secret(self):
        """Test deleting a secret."""
        mock_response = {
            "name": "secret-to-delete",
            "message": "Secret deleted successfully"
        }

        self.mock_http_client.delete.return_value = mock_response

        # Call the method
        result = self.service.delete("secret-to-delete")

        # Assertions
        assert isinstance(result, SecretResponse)
        assert result.name == "secret-to-delete"
        assert result.message == "Secret deleted successfully"

        # Verify HTTP client was called correctly
        self.mock_http_client.delete.assert_called_once_with(
            "/secrets",
            data={"name": "secret-to-delete"}
        )

    def test_delete_secret_not_found(self):
        """Test deleting a non-existent secret."""
        self.mock_http_client.delete.side_effect = NotFoundError("Secret not found")

        # Call the method and expect NotFoundError
        with pytest.raises(NotFoundError, match="Secret 'nonexistent' not found"):
            self.service.delete("nonexistent")

    def test_set_secret_create_success(self):
        """Test set method when secret doesn't exist (create)."""
        mock_response = {
            "name": "new-secret",
            "message": "Secret created successfully"
        }

        self.mock_http_client.post.return_value = mock_response

        # Call the method
        result = self.service.set("new-secret", "value")

        # Assertions
        assert isinstance(result, SecretResponse)
        assert result.name == "new-secret"
        assert result.message == "Secret created successfully"

        # Verify only create was called
        self.mock_http_client.post.assert_called_once()
        self.mock_http_client.put.assert_not_called()

    def test_set_secret_update_fallback(self):
        """Test set method when secret exists (update fallback)."""
        # Mock create to fail with conflict, update to succeed
        create_response = Exception("Secret already exists")
        update_response = {
            "name": "existing-secret",
            "message": "Secret updated successfully"
        }

        self.mock_http_client.post.side_effect = create_response
        self.mock_http_client.put.return_value = update_response

        # Call the method
        result = self.service.set("existing-secret", "new-value")

        # Assertions
        assert isinstance(result, SecretResponse)
        assert result.name == "existing-secret"
        assert result.message == "Secret updated successfully"

        # Verify both create and update were called
        self.mock_http_client.post.assert_called_once()
        self.mock_http_client.put.assert_called_once()

    def test_list_secrets_error_handling(self):
        """Test error handling in list method."""
        self.mock_http_client.get.side_effect = Exception("API Error")

        with pytest.raises(Exception, match="Failed to list secrets: API Error"):
            self.service.list()

    def test_create_secret_error_handling(self):
        """Test error handling in create method."""
        self.mock_http_client.post.side_effect = Exception("API Error")

        with pytest.raises(Exception, match="Failed to create secret 'test': API Error"):
            self.service.create("test", "value")

    def test_get_secret_value(self):
        """Test getting a secret's value."""
        from az_cortex_sdk.models import SecretValueResponse

        mock_response = {
            "value": "my-secret-value-123"
        }

        self.mock_http_client.get.return_value = mock_response

        # Call the method
        result = self.service.get("my-secret")

        # Assertions
        assert isinstance(result, SecretValueResponse)
        assert result.value == "my-secret-value-123"

        # Verify HTTP client was called correctly
        self.mock_http_client.get.assert_called_once_with("/secrets/my-secret/value")

    def test_get_secret_not_found(self):
        """Test getting a non-existent secret."""
        self.mock_http_client.get.side_effect = NotFoundError("Secret not found")

        # Call the method and expect NotFoundError
        with pytest.raises(NotFoundError, match="Secret 'nonexistent' not found"):
            self.service.get("nonexistent")

    def test_get_secret_error_handling(self):
        """Test error handling in get method."""
        self.mock_http_client.get.side_effect = Exception("API Error")

        with pytest.raises(Exception, match="Failed to get secret 'test': API Error"):
            self.service.get("test")
"""Tests for environment and model version services."""


from az_cortex_sdk.services.environment_versions import EnvironmentVersionService
from az_cortex_sdk.services.model_versions import ModelVersionService


class TestEnvironmentVersionService:
    """Test cases for EnvironmentVersionService."""

    def setup_method(self):
        """Set up test fixtures."""
        self.mock_http_client = Mock()
        self.service = EnvironmentVersionService(self.mock_http_client)

    def test_list_environment_versions(self):
        """Test listing environment versions."""
        # Mock API response
        mock_response = {
            "versions": [
                {
                    "name": "test-env",
                    "version": "1.0.0",
                    "description": "Test environment version",
                    "image": "test-image:latest",
                    "is_archived": False
                }
            ],
            "totalDocuments": 1,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Call service method
        result = self.service.list("test-env")

        # Verify request
        self.mock_http_client.get.assert_called_once_with(
            "/environment-versions",
            params={
                "environmentName": "test-env",
                "page": 1,
                "perPage": 25,
                "isArchived": "false"
            }
        )

        # Verify response
        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 1
        assert isinstance(result.items[0], EnvironmentVersion)
        assert result.items[0].name == "test-env"
        assert result.items[0].version == "1.0.0"

    def test_get_environment_version(self):
        """Test getting a specific environment version."""
        # Mock API response
        mock_response = {
            "name": "1",  # API returns version as name
            "id": "test-id",
            "properties": {
                "description": "Test environment version",
                "image": "test-image:latest"
            }
        }
        self.mock_http_client.get.return_value = mock_response

        # Call service method
        result = self.service.get("test-env", "1.0.0")

        # Verify request
        self.mock_http_client.get.assert_called_once_with(
            "/environment-versions/1",
            params={"environmentName": "test-env"}
        )

        # Verify response
        assert isinstance(result, EnvironmentVersion)
        assert result.name == "test-env"
        assert result.version == "1"

    def test_register_environment_version(self):
        """Test registering a new environment version."""
        # Mock API response
        mock_response = {
            "name": "1",  # API returns version as name
            "id": "test-id"
        }
        self.mock_http_client.post.return_value = mock_response

        # Call service method
        result = self.service.register(
            environment_name="test-env",
            version="1.0.0",
            description="Test environment",
            image="test-image:latest"
        )

        # Verify request
        self.mock_http_client.post.assert_called_once_with(
            "/environment-versions/1",
            params={"environmentName": "test-env"},
            data={
                "description": "Test environment",
                "image": "test-image:latest"
            }
        )

        # Verify response
        assert isinstance(result, RegistrationResult)
        assert result.success is True
        assert result.name == "test-env"
        assert result.version == "1"

    def test_archive_environment_version(self):
        """Test archiving an environment version."""
        # Mock API response
        mock_response = {
            "name": "1",
            "id": "test-id",
            "properties": {
                "isArchived": True
            }
        }
        self.mock_http_client.put.return_value = mock_response

        # Call service method
        result = self.service.archive("test-env", "1.0.0")

        # Verify request
        self.mock_http_client.put.assert_called_once_with(
            "/environment-versions/1",
            params={"environmentName": "test-env"},
            data={"isArchived": True}
        )

        # Verify response
        assert isinstance(result, EnvironmentVersion)
        assert result.name == "test-env"


class TestModelVersionService:
    """Test cases for ModelVersionService."""

    def setup_method(self):
        """Set up test fixtures."""
        self.mock_http_client = Mock()
        self.service = ModelVersionService(self.mock_http_client)

    def test_list_model_versions(self):
        """Test listing model versions."""
        # Mock API response
        mock_response = {
            "versions": [
                {
                    "name": "test-model",
                    "version": "1.0.0",
                    "description": "Test model version",
                    "model_uri": "azureml://models/test-model/versions/1",
                    "is_archived": False
                }
            ],
            "totalDocuments": 1,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Call service method
        result = self.service.list("test-model")

        # Verify request
        self.mock_http_client.get.assert_called_once_with(
            "/model-versions",
            params={
                "modelName": "test-model",
                "page": 1,
                "perPage": 25,
                "isArchived": "false"
            }
        )

        # Verify response
        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 1
        assert isinstance(result.items[0], ModelVersion)
        assert result.items[0].name == "test-model"
        assert result.items[0].version == "1.0.0"

    def test_get_model_version(self):
        """Test getting a specific model version."""
        # Mock API response
        mock_response = {
            "name": "1",  # API returns version as name
            "id": "test-id",
            "properties": {
                "description": "Test model version",
                "modelUri": "azureml://models/test-model/versions/1"
            }
        }
        self.mock_http_client.get.return_value = mock_response

        # Call service method
        result = self.service.get("test-model", "1.0.0")

        # Verify request
        self.mock_http_client.get.assert_called_once_with(
            "/model-versions/1",
            params={"modelName": "test-model"}
        )

        # Verify response
        assert isinstance(result, ModelVersion)
        assert result.name == "test-model"
        assert result.version == "1"

    def test_register_model_version(self):
        """Test registering a new model version."""
        # Mock API response
        mock_response = {
            "name": "1",  # API returns version as name
            "id": "test-id"
        }
        self.mock_http_client.post.return_value = mock_response

        # Call service method
        result = self.service.register(
            model_name="test-model",
            version="1.0.0",
            description="Test model",
            model_uri="azureml://models/test-model/versions/1",
            model_type="sklearn"
        )

        # Verify request
        self.mock_http_client.post.assert_called_once_with(
            "/model-versions/1",
            params={"modelName": "test-model"},
            data={
                "description": "Test model",
                "modelUri": "azureml://models/test-model/versions/1",
                "modelType": "sklearn"
            }
        )

        # Verify response
        assert isinstance(result, RegistrationResult)
        assert result.success is True
        assert result.name == "test-model"
        assert result.version == "1"

    def test_archive_model_version(self):
        """Test archiving a model version."""
        # Mock API response
        mock_response = {
            "name": "1",
            "id": "test-id",
            "properties": {
                "isArchived": True
            }
        }
        self.mock_http_client.put.return_value = mock_response

        # Call service method
        result = self.service.archive("test-model", "1.0.0")

        # Verify request
        self.mock_http_client.put.assert_called_once_with(
            "/model-versions/1",
            params={"modelName": "test-model"},
            data={"isArchived": True}
        )

        # Verify response
        assert isinstance(result, ModelVersion)
        assert result.name == "test-model"

    @patch("builtins.open")
    @patch("pathlib.Path.exists")
    @patch("pathlib.Path.stat")
    def test_register_from_file(self, mock_stat, mock_exists, mock_open):
        """Test registering a model version from file."""
        # Mock file operations
        mock_exists.return_value = True
        mock_stat.return_value.st_size = 1024
        mock_file = Mock()
        mock_open.return_value = mock_file

        # Mock API response
        mock_response = {
            "name": "1",
            "id": "test-id",
            "modelUri": "azureml://models/test-model/versions/1"
        }
        self.mock_http_client.post.return_value = mock_response

        # Call service method
        result = self.service.register_from_file(
            file_path="test_model.pkl",
            model_name="test-model",
            version="1.0.0",
            description="Test model from file"
        )

        # Verify response structure
        assert "upload_result" in result
        assert "registration_result" in result
        assert result["upload_result"].success is True
        assert result["registration_result"].success is True
