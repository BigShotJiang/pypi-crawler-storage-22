from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from collections.abc import Iterable
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from threading import Lock
from typing import Literal

from azure.storage.blob import ContainerClient
from platformdirs import user_cache_path

from .config import (
    APP_AUTHOR,
    APP_NAME,
    get_sas_token,
    load_settings,
    normalize_prefix,
    normalize_sas_token,
)

ReadBackend = Literal["auto", "sdk", "azcopy"]

READ_BACKEND_ENV = "AZURE_BLOB_TUI_READ_BACKEND"
CACHE_ENABLED_ENV = "AZURE_BLOB_TUI_CACHE_ENABLED"
CACHE_DIR_ENV = "AZURE_BLOB_TUI_CACHE_DIR"
CACHE_MAX_BYTES_ENV = "AZURE_BLOB_TUI_CACHE_MAX_BYTES"
AZCOPY_PATH_ENV = "AZURE_BLOB_TUI_AZCOPY_PATH"
READ_WORKERS_ENV = "AZURE_BLOB_TUI_READ_WORKERS"
MAX_CONCURRENCY_ENV = "AZURE_BLOB_TUI_MAX_CONCURRENCY"

_DEFAULT_AZCOPY_CUTOFF_BYTES = 32 * 1024 * 1024
_DEFAULT_CACHE_MAX_BYTES = 10 * 1024 * 1024 * 1024
_CACHE_TRIM_LOCK = Lock()


def _resolve_settings(
    account_name: str | None,
    container_name: str | None,
    sas_token: str | None,
) -> tuple[str, str, str | None]:
    settings = load_settings()
    account = (account_name or settings.get("account_name", "")).strip()
    container = (container_name or settings.get("container_name", "")).strip()
    sas = (sas_token or get_sas_token()).strip()
    sas, account_from_url = normalize_sas_token(sas)
    if account_from_url:
        account = account_from_url
    sas = sas or None
    if not account:
        raise ValueError(
            "Missing Azure Storage account. Set it in config or AZURE_STORAGE_ACCOUNT."
        )
    if not container:
        raise ValueError("Missing container name. Set it in config or AZURE_BLOB_TUI_CONTAINER.")
    return account, container, sas


def get_container_client(
    *,
    account_name: str | None = None,
    container_name: str | None = None,
    sas_token: str | None = None,
) -> ContainerClient:
    account, container, sas = _resolve_settings(account_name, container_name, sas_token)
    account_url = f"https://{account}.blob.core.windows.net"
    return ContainerClient(account_url, container, credential=sas)


def _env_flag(name: str, default: bool) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    if not raw:
        return default
    return raw in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        parsed = int(raw)
    except ValueError:
        return default
    return parsed if parsed > 0 else default


def _normalize_backend(backend: str | None) -> ReadBackend:
    choice = (backend or os.environ.get(READ_BACKEND_ENV, "auto")).strip().lower()
    if choice in {"sdk", "azcopy"}:
        return choice
    return "auto"


def _resolve_use_cache(use_cache: bool | None) -> bool:
    if use_cache is not None:
        return use_cache
    return _env_flag(CACHE_ENABLED_ENV, default=False)


def _resolve_workers(workers: int | None) -> int:
    if workers is not None and workers > 0:
        return workers
    return _env_int(READ_WORKERS_ENV, default=16)


def _resolve_max_concurrency(max_concurrency: int | None) -> int:
    if max_concurrency is not None and max_concurrency > 0:
        return max_concurrency
    return _env_int(MAX_CONCURRENCY_ENV, default=8)


def _cache_root() -> Path:
    env_dir = os.environ.get(CACHE_DIR_ENV, "").strip()
    if env_dir:
        return Path(env_dir).expanduser()
    return user_cache_path(APP_NAME, APP_AUTHOR) / "blob-cache"


def _parse_size_bytes(raw: str) -> int | None:
    text = raw.strip().lower()
    if not text:
        return None
    factors = {
        "k": 1024,
        "kb": 1024,
        "m": 1024**2,
        "mb": 1024**2,
        "g": 1024**3,
        "gb": 1024**3,
    }
    for suffix, factor in factors.items():
        if text.endswith(suffix):
            base = text[: -len(suffix)].strip()
            try:
                value = float(base)
            except ValueError:
                return None
            return max(int(value * factor), 0)
    try:
        return max(int(text), 0)
    except ValueError:
        return None


def _resolve_cache_max_bytes() -> int:
    raw = os.environ.get(CACHE_MAX_BYTES_ENV, "").strip()
    parsed = _parse_size_bytes(raw) if raw else None
    if parsed is None:
        return _DEFAULT_CACHE_MAX_BYTES
    return parsed


def _blob_parts(blob_name: str) -> list[str]:
    safe: list[str] = []
    for part in blob_name.strip("/").split("/"):
        if not part or part in {".", ".."}:
            continue
        safe.append(part)
    return safe


def _cache_path_for_blob(
    cache_root: Path,
    account_name: str,
    container_name: str,
    blob_name: str,
) -> Path:
    parts = _blob_parts(blob_name)
    if not parts:
        parts = ["__root__"]
    return cache_root / account_name / container_name / Path(*parts)


def _cache_base_for_prefix(
    cache_root: Path,
    account_name: str,
    container_name: str,
    prefix: str,
) -> Path:
    base = cache_root / account_name / container_name
    prefix_clean = prefix.strip("/")
    if not prefix_clean:
        return base
    return base / Path(*_blob_parts(prefix_clean))


def _copy_file(src: Path, dst: Path) -> None:
    if src == dst:
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def _touch_file(path: Path) -> None:
    try:
        os.utime(path, None)
    except OSError:
        return


def _trim_cache(cache_root: Path) -> None:
    limit = _resolve_cache_max_bytes()
    if limit <= 0:
        return
    if not cache_root.exists():
        return

    files: list[tuple[Path, int, float]] = []
    total = 0
    for file_path in cache_root.rglob("*"):
        if not file_path.is_file():
            continue
        try:
            stat = file_path.stat()
        except OSError:
            continue
        size = int(stat.st_size)
        total += size
        files.append((file_path, size, stat.st_atime))

    if total <= limit:
        return

    files.sort(key=lambda x: x[2])
    for file_path, size, _ in files:
        if total <= limit:
            break
        try:
            file_path.unlink()
            total -= size
        except OSError:
            continue

    for directory in sorted(
        (p for p in cache_root.rglob("*") if p.is_dir()),
        key=lambda p: len(p.parts),
        reverse=True,
    ):
        try:
            directory.rmdir()
        except OSError:
            continue


def _trim_cache_safe(cache_root: Path) -> None:
    with _CACHE_TRIM_LOCK:
        _trim_cache(cache_root)


def _azcopy_path() -> str | None:
    configured = os.environ.get(AZCOPY_PATH_ENV, "").strip() or "azcopy"
    candidate = Path(configured).expanduser()
    if candidate.exists() and candidate.is_file():
        return str(candidate)
    resolved = shutil.which(configured)
    if resolved:
        return resolved
    return None


def _build_blob_url(
    account_name: str,
    container_name: str,
    blob_name: str,
    sas_token: str | None,
) -> str:
    name = blob_name.lstrip("/")
    base = f"https://{account_name}.blob.core.windows.net/{container_name}/{name}"
    if not sas_token:
        return base
    token = sas_token.lstrip("?")
    return f"{base}?{token}"


def _build_container_url_with_prefix(
    account_name: str,
    container_name: str,
    prefix: str,
    sas_token: str | None,
) -> str:
    prefix_clean = prefix.strip("/")
    base = f"https://{account_name}.blob.core.windows.net/{container_name}"
    if prefix_clean:
        base = f"{base}/{prefix_clean}"
    if not sas_token:
        return base
    token = sas_token.lstrip("?")
    return f"{base}?{token}"


def _run_azcopy(command: list[str]) -> None:
    proc = subprocess.run(command, check=False, capture_output=True, text=True)
    if proc.returncode != 0:
        stderr = proc.stderr.strip()
        stdout = proc.stdout.strip()
        detail = stderr or stdout or "unknown error"
        raise RuntimeError(f"AzCopy failed: {detail}")


def _download_blob_sdk(
    client: ContainerClient,
    blob_name: str,
    target_path: Path,
    *,
    max_concurrency: int,
) -> None:
    blob = client.get_blob_client(blob_name)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    with target_path.open("wb") as handle:
        stream = blob.download_blob(max_concurrency=max_concurrency)
        stream.readinto(handle)


def _download_blob_azcopy(
    *,
    azcopy_path: str,
    blob_url: str,
    target_path: Path,
    overwrite: bool,
) -> None:
    target_path.parent.mkdir(parents=True, exist_ok=True)
    command = [
        azcopy_path,
        "cp",
        blob_url,
        str(target_path),
        "--overwrite=true" if overwrite else "--overwrite=false",
    ]
    _run_azcopy(command)


def _download_batch_azcopy(
    *,
    azcopy_path: str,
    source_url: str,
    destination_dir: Path,
    relative_files: list[str],
    overwrite: bool,
) -> None:
    if not relative_files:
        return
    destination_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", delete=False, encoding="utf-8") as temp:
        temp.write("\n".join(relative_files))
        file_list = temp.name
    try:
        command = [
            azcopy_path,
            "cp",
            source_url,
            str(destination_dir),
            "--recursive",
            "--list-of-files",
            file_list,
            "--overwrite=true" if overwrite else "--overwrite=false",
        ]
        _run_azcopy(command)
    finally:
        Path(file_list).unlink(missing_ok=True)


def _select_backend_for_file(
    backend: ReadBackend,
    *,
    azcopy_available: bool,
    blob_size: int | None,
) -> ReadBackend:
    if backend == "sdk":
        return "sdk"
    if backend == "azcopy":
        if not azcopy_available:
            raise RuntimeError("AzCopy backend requested, but azcopy executable was not found.")
        return "azcopy"
    if azcopy_available and blob_size is not None and blob_size >= _DEFAULT_AZCOPY_CUTOFF_BYTES:
        return "azcopy"
    return "sdk"


def _select_backend_for_batch(
    backend: ReadBackend,
    *,
    azcopy_available: bool,
    file_count: int,
    total_size: int,
) -> ReadBackend:
    if backend == "sdk":
        return "sdk"
    if backend == "azcopy":
        if not azcopy_available:
            raise RuntimeError("AzCopy backend requested, but azcopy executable was not found.")
        return "azcopy"
    if azcopy_available and (file_count >= 16 or total_size >= _DEFAULT_AZCOPY_CUTOFF_BYTES):
        return "azcopy"
    return "sdk"


def _download_blob_to_cache_or_target(
    *,
    client: ContainerClient,
    account_name: str,
    container_name: str,
    sas_token: str | None,
    blob_name: str,
    target_path: Path,
    cache_path: Path | None,
    backend: ReadBackend,
    force_refresh: bool,
    overwrite_target: bool,
    max_concurrency: int,
) -> None:
    if target_path.exists() and not overwrite_target:
        raise FileExistsError(f"{target_path} already exists")

    if cache_path and cache_path.exists() and not force_refresh:
        _touch_file(cache_path)
        _copy_file(cache_path, target_path)
        return

    azcopy = _azcopy_path()
    blob_size: int | None = None
    if backend == "auto":
        try:
            props = client.get_blob_client(blob_name).get_blob_properties()
            blob_size = getattr(props, "size", None)
        except Exception:
            blob_size = None
    selected = _select_backend_for_file(
        backend,
        azcopy_available=azcopy is not None and bool(sas_token),
        blob_size=blob_size,
    )

    destination = cache_path or target_path
    if selected == "azcopy":
        assert azcopy is not None
        blob_url = _build_blob_url(account_name, container_name, blob_name, sas_token)
        _download_blob_azcopy(
            azcopy_path=azcopy,
            blob_url=blob_url,
            target_path=destination,
            overwrite=True,
        )
    else:
        _download_blob_sdk(
            client,
            blob_name,
            destination,
            max_concurrency=max_concurrency,
        )

    if cache_path:
        _touch_file(cache_path)
        _copy_file(cache_path, target_path)
        _trim_cache_safe(_cache_root())


def upload_file(
    local_path: str | Path,
    blob_name: str,
    *,
    account_name: str | None = None,
    container_name: str | None = None,
    sas_token: str | None = None,
    overwrite: bool = True,
) -> None:
    client = get_container_client(
        account_name=account_name, container_name=container_name, sas_token=sas_token
    )
    blob = client.get_blob_client(blob_name)
    with open(Path(local_path), "rb") as handle:
        blob.upload_blob(handle, overwrite=overwrite)


def download_file(
    blob_name: str,
    local_path: str | Path,
    *,
    account_name: str | None = None,
    container_name: str | None = None,
    sas_token: str | None = None,
    overwrite: bool = True,
    backend: ReadBackend | None = None,
    use_cache: bool | None = None,
    force_refresh: bool = False,
    max_concurrency: int | None = None,
) -> None:
    account, container, resolved_sas = _resolve_settings(account_name, container_name, sas_token)
    client = get_container_client(
        account_name=account_name, container_name=container_name, sas_token=sas_token
    )
    selected_backend = _normalize_backend(backend)
    cache_enabled = _resolve_use_cache(use_cache)
    max_conn = _resolve_max_concurrency(max_concurrency)
    target = Path(local_path)
    if target.exists() and not overwrite:
        raise FileExistsError(f"{target} already exists")
    blob_name = blob_name.lstrip("/")
    cache_path = None
    if cache_enabled:
        cache_path = _cache_path_for_blob(_cache_root(), account, container, blob_name)
    _download_blob_to_cache_or_target(
        client=client,
        account_name=account,
        container_name=container,
        sas_token=resolved_sas,
        blob_name=blob_name,
        target_path=target,
        cache_path=cache_path,
        backend=selected_backend,
        force_refresh=force_refresh,
        overwrite_target=overwrite,
        max_concurrency=max_conn,
    )


def upload_dir(
    local_dir: str | Path,
    *,
    prefix: str = "",
    account_name: str | None = None,
    container_name: str | None = None,
    sas_token: str | None = None,
    overwrite: bool = True,
) -> int:
    client = get_container_client(
        account_name=account_name, container_name=container_name, sas_token=sas_token
    )
    root = Path(local_dir)
    prefix = normalize_prefix(prefix)
    uploaded = 0
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        blob_name = f"{prefix}{rel}" if prefix else rel
        with open(path, "rb") as handle:
            client.upload_blob(name=blob_name, data=handle.read(), overwrite=overwrite)
        uploaded += 1
    return uploaded


def download_dir(
    local_dir: str | Path,
    *,
    prefix: str = "",
    account_name: str | None = None,
    container_name: str | None = None,
    sas_token: str | None = None,
    overwrite: bool = True,
    backend: ReadBackend | None = None,
    use_cache: bool | None = None,
    force_refresh: bool = False,
    workers: int | None = None,
    max_concurrency: int | None = None,
) -> int:
    account, container, resolved_sas = _resolve_settings(account_name, container_name, sas_token)
    client = get_container_client(
        account_name=account_name, container_name=container_name, sas_token=sas_token
    )
    selected_backend = _normalize_backend(backend)
    cache_enabled = _resolve_use_cache(use_cache)
    pool_workers = _resolve_workers(workers)
    max_conn = _resolve_max_concurrency(max_concurrency)
    root = Path(local_dir)
    prefix = normalize_prefix(prefix)
    jobs: list[tuple[str, str, Path, int]] = []
    for blob in client.list_blobs(name_starts_with=prefix):
        name = blob.name
        if prefix:
            if not name.startswith(prefix):
                continue
            rel = name[len(prefix) :]
        else:
            rel = name
        if not rel or rel.endswith("/"):
            continue
        target = root / rel
        if target.exists() and not overwrite:
            continue
        size = int(getattr(blob, "size", 0) or 0)
        jobs.append((name, rel, target, size))

    if not jobs:
        return 0

    cache_root = _cache_root() if cache_enabled else None
    downloaded = 0
    pending: list[tuple[str, str, Path, int]] = []
    for name, rel, target, size in jobs:
        cache_path = None
        if cache_root is not None:
            cache_path = _cache_path_for_blob(cache_root, account, container, name)
        if cache_path and cache_path.exists() and not force_refresh:
            _touch_file(cache_path)
            _copy_file(cache_path, target)
            downloaded += 1
        else:
            pending.append((name, rel, target, size))

    if not pending:
        return downloaded

    azcopy = _azcopy_path()
    total_size = sum(size for _, _, _, size in pending)
    active_backend = _select_backend_for_batch(
        selected_backend,
        azcopy_available=azcopy is not None and bool(resolved_sas),
        file_count=len(pending),
        total_size=total_size,
    )

    if active_backend == "azcopy":
        assert azcopy is not None
        source_url = _build_container_url_with_prefix(account, container, prefix, resolved_sas)
        relative_files = [rel for _, rel, _, _ in pending]
        if cache_root is not None:
            cache_dest = _cache_base_for_prefix(cache_root, account, container, prefix)
            _download_batch_azcopy(
                azcopy_path=azcopy,
                source_url=source_url,
                destination_dir=cache_dest,
                relative_files=relative_files,
                overwrite=True,
            )
            for _, rel, target, _ in pending:
                _copy_file(cache_dest / Path(*_blob_parts(rel)), target)
                downloaded += 1
            _trim_cache_safe(cache_root)
        else:
            _download_batch_azcopy(
                azcopy_path=azcopy,
                source_url=source_url,
                destination_dir=root,
                relative_files=relative_files,
                overwrite=overwrite,
            )
            downloaded += len(pending)
        return downloaded

    with ThreadPoolExecutor(max_workers=pool_workers) as executor:
        futures = []
        for name, _, target, _ in pending:
            cache_path = None
            if cache_root is not None:
                cache_path = _cache_path_for_blob(cache_root, account, container, name)
            futures.append(
                executor.submit(
                    _download_blob_to_cache_or_target,
                    client=client,
                    account_name=account,
                    container_name=container,
                    sas_token=resolved_sas,
                    blob_name=name,
                    target_path=target,
                    cache_path=cache_path,
                    backend="sdk",
                    force_refresh=force_refresh,
                    overwrite_target=overwrite,
                    max_concurrency=max_conn,
                )
            )
        for future in as_completed(futures):
            future.result()
            downloaded += 1
    return downloaded


def read_blob_bytes(
    blob_name: str,
    *,
    account_name: str | None = None,
    container_name: str | None = None,
    sas_token: str | None = None,
    backend: ReadBackend | None = None,
    use_cache: bool | None = None,
    force_refresh: bool = False,
    max_concurrency: int | None = None,
) -> bytes:
    account, container, resolved_sas = _resolve_settings(account_name, container_name, sas_token)
    client = get_container_client(
        account_name=account_name,
        container_name=container_name,
        sas_token=sas_token,
    )
    selected_backend = _normalize_backend(backend)
    cache_enabled = _resolve_use_cache(use_cache)
    max_conn = _resolve_max_concurrency(max_concurrency)
    normalized_name = blob_name.lstrip("/")

    cache_path = None
    if cache_enabled:
        cache_path = _cache_path_for_blob(_cache_root(), account, container, normalized_name)
    if cache_path and cache_path.exists() and not force_refresh:
        _touch_file(cache_path)
        return cache_path.read_bytes()

    azcopy = _azcopy_path()
    blob_size: int | None = None
    if selected_backend == "auto":
        try:
            props = client.get_blob_client(normalized_name).get_blob_properties()
            blob_size = getattr(props, "size", None)
        except Exception:
            blob_size = None
    active_backend = _select_backend_for_file(
        selected_backend,
        azcopy_available=azcopy is not None and bool(resolved_sas),
        blob_size=blob_size,
    )

    if active_backend == "azcopy":
        assert azcopy is not None
        blob_url = _build_blob_url(account, container, normalized_name, resolved_sas)
        destination = cache_path
        temp_path: Path | None = None
        if destination is None:
            with tempfile.NamedTemporaryFile(delete=False) as temp:
                temp_path = Path(temp.name)
            destination = temp_path
        try:
            _download_blob_azcopy(
                azcopy_path=azcopy,
                blob_url=blob_url,
                target_path=destination,
                overwrite=True,
            )
            return destination.read_bytes()
        finally:
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)

    payload = (
        client.get_blob_client(normalized_name).download_blob(max_concurrency=max_conn).readall()
    )
    if isinstance(payload, str):
        data = payload.encode()
    else:
        data = payload
    if cache_path:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.write_bytes(data)
        _touch_file(cache_path)
        _trim_cache_safe(_cache_root())
    return data


def prefetch_blobs(
    blob_names: Iterable[str],
    *,
    account_name: str | None = None,
    container_name: str | None = None,
    sas_token: str | None = None,
    backend: ReadBackend | None = None,
    force_refresh: bool = False,
    workers: int | None = None,
    max_concurrency: int | None = None,
) -> int:
    account, container, resolved_sas = _resolve_settings(account_name, container_name, sas_token)
    client = get_container_client(
        account_name=account_name,
        container_name=container_name,
        sas_token=sas_token,
    )
    selected_backend = _normalize_backend(backend)
    pool_workers = _resolve_workers(workers)
    max_conn = _resolve_max_concurrency(max_concurrency)
    cache_root = _cache_root()
    cache_container_root = cache_root / account / container

    normalized = sorted({name.lstrip("/") for name in blob_names if name.strip("/")})
    pending: list[str] = []
    for name in normalized:
        cache_path = _cache_path_for_blob(cache_root, account, container, name)
        if cache_path.exists() and not force_refresh:
            continue
        pending.append(name)
    if not pending:
        return 0

    azcopy = _azcopy_path()
    sizes = {name: 0 for name in pending}
    if selected_backend == "auto":
        for blob in client.list_blobs(name_starts_with=""):
            if blob.name in sizes:
                sizes[blob.name] = int(getattr(blob, "size", 0) or 0)
        total_size = sum(sizes.values())
    else:
        total_size = 0
    active_backend = _select_backend_for_batch(
        selected_backend,
        azcopy_available=azcopy is not None and bool(resolved_sas),
        file_count=len(pending),
        total_size=total_size,
    )

    if active_backend == "azcopy":
        assert azcopy is not None
        source_url = _build_container_url_with_prefix(account, container, "", resolved_sas)
        _download_batch_azcopy(
            azcopy_path=azcopy,
            source_url=source_url,
            destination_dir=cache_container_root,
            relative_files=pending,
            overwrite=True,
        )
        _trim_cache_safe(cache_root)
        return len(pending)

    with ThreadPoolExecutor(max_workers=pool_workers) as executor:
        futures = [
            executor.submit(
                _download_blob_sdk,
                client,
                name,
                _cache_path_for_blob(cache_root, account, container, name),
                max_concurrency=max_conn,
            )
            for name in pending
        ]
        for future in as_completed(futures):
            future.result()
    _trim_cache_safe(cache_root)
    return len(pending)


def clear_cache(
    *,
    blob_name: str | None = None,
    prefix: str = "",
    account_name: str | None = None,
    container_name: str | None = None,
) -> int:
    account, container, _ = _resolve_settings(account_name, container_name, sas_token=None)
    base = _cache_root() / account / container
    removed = 0

    if blob_name:
        target = _cache_path_for_blob(_cache_root(), account, container, blob_name)
        if target.exists():
            target.unlink()
            return 1
        return 0

    prefix = normalize_prefix(prefix)
    if prefix:
        target_dir = base / Path(*_blob_parts(prefix.rstrip("/")))
        if target_dir.exists():
            if target_dir.is_file():
                target_dir.unlink()
                return 1
            for item in target_dir.rglob("*"):
                if item.is_file():
                    removed += 1
            shutil.rmtree(target_dir, ignore_errors=True)
        return removed

    if not base.exists():
        return 0
    for item in base.rglob("*"):
        if item.is_file():
            removed += 1
    shutil.rmtree(base, ignore_errors=True)
    return removed


def list_blobs(
    *,
    prefix: str = "",
    account_name: str | None = None,
    container_name: str | None = None,
    sas_token: str | None = None,
) -> Iterable[str]:
    client = get_container_client(
        account_name=account_name, container_name=container_name, sas_token=sas_token
    )
    prefix = normalize_prefix(prefix)
    return (item.name for item in client.list_blobs(name_starts_with=prefix))
