"""Azure Discovery: Azure tenant discovery and visualization via Resource Graph.

This package can be installed from PyPI as ``azure-discovery`` and used as:

  pip install azure-discovery
  azure-discovery discover --tenant-id <id> --subscription <sub-id>

Programmatic usage:

  from azure_discovery import run_discovery
  from azure_discovery.adt_types import AzureDiscoveryRequest, AzureDiscoveryResponse
"""

from .orchestrator import run_discovery
from .adt_types import (
    AzureDiscoveryRequest,
    AzureDiscoveryResponse,
    AzureEnvironment,
    DiscoveryFilter,
    ResourceNode,
    ResourceRelationship,
)

__all__ = [
    "run_discovery",
    "AzureDiscoveryRequest",
    "AzureDiscoveryResponse",
    "AzureEnvironment",
    "DiscoveryFilter",
    "ResourceNode",
    "ResourceRelationship",
]
__version__ = "0.1.0"
