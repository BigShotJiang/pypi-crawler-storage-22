"""FastAPI surface for Azure discovery."""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse

from .orchestrator import run_discovery
from .adt_types import AzureDiscoveryRequest, AzureDiscoveryResponse
from .utils.logging import get_logger

LOGGER = get_logger()
app = FastAPI(title="Azure Discovery", version="1.0.0")


@app.get("/healthz", tags=["system"])
async def health_check() -> dict:
    return {"status": "ok"}


@app.post(
    "/discover",
    response_model=AzureDiscoveryResponse,
    tags=["discovery"],
)
async def discover_endpoint(
    request: AzureDiscoveryRequest,
) -> AzureDiscoveryResponse:
    LOGGER.info(
        "API discovery invoked",
        extra={"context": {"tenant_id": request.tenant_id}},
    )
    return await run_discovery(request)


@app.get("/visuals/{file_name}", tags=["visualization"])
async def visualization_endpoint(file_name: str) -> FileResponse:
    if not file_name:
        raise HTTPException(status_code=400, detail="file_name missing")
    html_path = Path("artifacts/graphs") / file_name
    if not html_path.is_file():
        raise HTTPException(status_code=404, detail="Visualization not found")
    return FileResponse(html_path)
