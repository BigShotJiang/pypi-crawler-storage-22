"""Discovery orchestrator."""

from __future__ import annotations

from .adt_types import AzureDiscoveryRequest, AzureDiscoveryResponse
from .enumerators import enumerate_azure_resources
from .reporting import emit_console_summary, render_visualization


async def run_discovery(request: AzureDiscoveryRequest) -> AzureDiscoveryResponse:
    """Coordinate enumeration and visualization."""

    if not request:
        raise ValueError("request cannot be None")

    discovery_response = await enumerate_azure_resources(request)
    visualization = render_visualization(
        response=discovery_response, options=request.visualization
    )
    enriched_response = discovery_response.model_copy(
        update={"html_report_path": visualization.html_path}
    )
    emit_console_summary(enriched_response)
    return enriched_response
