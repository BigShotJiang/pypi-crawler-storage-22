"""Azure SDK client helpers."""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional

from azure.identity import (
    AzureCliCredential,
    ChainedTokenCredential,
    DefaultAzureCredential,
)
from azure.identity._constants import KnownAuthorities
from azure.mgmt.resourcegraph import ResourceGraphClient
from azure.mgmt.resourcegraph.models import QueryRequest
from azure.mgmt.subscription import SubscriptionClient

from ..adt_types import (
    AzureDiscoveryRequest,
    AzureEnvironment,
    AzureEnvironmentConfig,
    AzureClientError,
)
from .logging import get_logger

LOGGER = get_logger()

_ENVIRONMENT_MAP: Dict[AzureEnvironment, AzureEnvironmentConfig] = {
    AzureEnvironment.AZURE_PUBLIC: AzureEnvironmentConfig(
        name=AzureEnvironment.AZURE_PUBLIC,
        authority_host=KnownAuthorities.AZURE_PUBLIC_CLOUD,
        resource_manager="https://management.azure.com/",
        storage_suffix="core.windows.net",
    ),
    AzureEnvironment.AZURE_GOV: AzureEnvironmentConfig(
        name=AzureEnvironment.AZURE_GOV,
        authority_host=KnownAuthorities.AZURE_GOVERNMENT,
        resource_manager="https://management.usgovcloudapi.net/",
        storage_suffix="core.usgovcloudapi.net",
    ),
    AzureEnvironment.AZURE_CHINA: AzureEnvironmentConfig(
        name=AzureEnvironment.AZURE_CHINA,
        authority_host=KnownAuthorities.AZURE_CHINA,
        resource_manager="https://management.chinacloudapi.cn/",
        storage_suffix="core.chinacloudapi.cn",
    ),
    AzureEnvironment.AZURE_GERMANY: AzureEnvironmentConfig(
        name=AzureEnvironment.AZURE_GERMANY,
        authority_host=KnownAuthorities.AZURE_GERMANY,
        resource_manager="https://management.microsoftazure.de/",
        storage_suffix="core.cloudapi.de",
    ),
    AzureEnvironment.AZURE_STACK: AzureEnvironmentConfig(
        name=AzureEnvironment.AZURE_STACK,
        authority_host=KnownAuthorities.AZURE_PUBLIC_CLOUD,
        resource_manager="https://management.local.azurestack.external/",
        storage_suffix="local.azurestack.external",
    ),
}


def build_environment_config(
    environment: AzureEnvironment,
) -> AzureEnvironmentConfig:
    """Return endpoints for the requested cloud."""

    if environment not in _ENVIRONMENT_MAP:
        raise AzureClientError(f"Unsupported environment: {environment}")
    return _ENVIRONMENT_MAP[environment]


def get_credential(
    request: AzureDiscoveryRequest,
    config: AzureEnvironmentConfig,
) -> ChainedTokenCredential:
    """Return credential chain honoring CLI preference."""

    credential_chain = []
    if request.prefer_cli_credentials:
        credential_chain.append(
            AzureCliCredential(
                authority=config.authority_host,
                tenant_id=request.tenant_id,
            )
        )
    credential_chain.append(
        DefaultAzureCredential(
            authority=config.authority_host,
            exclude_interactive_browser_credential=False,
        )
    )
    return ChainedTokenCredential(*credential_chain)


async def ensure_subscription_ids(
    request: AzureDiscoveryRequest,
    credential: ChainedTokenCredential,
    base_url: Optional[str] = None,
) -> List[str]:
    """Resolve the subscription list, querying Azure if needed."""

    if request.subscriptions:
        return sorted({sub.strip() for sub in request.subscriptions if sub})

    loop = asyncio.get_running_loop()

    # Add explicit credential scopes for sovereign cloud support
    credential_scopes = [base_url + ".default"] if base_url else None
    client = SubscriptionClient(
        credential=credential,
        base_url=base_url,
        credential_scopes=credential_scopes,
    )

    def _list_subscriptions() -> List[str]:
        return [sub.subscription_id for sub in client.subscriptions.list()]

    try:
        results: List[str] = await loop.run_in_executor(
            None, _list_subscriptions
        )
    except Exception as exc:  # noqa: BLE001
        LOGGER.error(
            "Failed to enumerate subscriptions",
            extra={"context": {"error": str(exc)}},
        )
        raise AzureClientError("Unable to enumerate subscriptions") from exc
    if not results:
        raise AzureClientError("No subscriptions available for discovery")
    return sorted(results)


async def query_resource_graph(
    credential: ChainedTokenCredential,
    query: str,
    subscriptions: List[str],
    batch_size: int,
    base_url: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Execute a Resource Graph query with pagination."""

    if not query or not query.strip():
        raise AzureClientError("Resource Graph query cannot be empty")

    # Add explicit credential scopes for sovereign cloud support
    credential_scopes = [base_url + ".default"] if base_url else None
    client = ResourceGraphClient(
        credential=credential,
        base_url=base_url,
        credential_scopes=credential_scopes,
    )
    payload = QueryRequest(
        subscriptions=subscriptions,
        query=query,
        options={"resultFormat": "objectArray", "top": batch_size},
    )
    loop = asyncio.get_running_loop()
    results: List[Dict[str, Any]] = []
    skip_token: Optional[str] = None

    while True:
        if skip_token:
            payload.options["skipToken"] = skip_token

        def _run_query() -> Any:
            return client.resources(payload)

        try:
            response = await loop.run_in_executor(None, _run_query)
        except Exception as exc:  # noqa: BLE001
            LOGGER.error(
                "Resource Graph query failed",
                extra={"context": {"error": str(exc)}},
            )
            raise AzureClientError("Resource Graph query failure") from exc

        results.extend(response.data or [])
        skip_token = getattr(response, "skip_token", None)
        if not skip_token:
            break

    return results
