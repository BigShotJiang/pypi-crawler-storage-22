"""Integration-style tests for the discovery orchestrator."""

from __future__ import annotations

import pytest

from azure_discovery.adt_types import (
    AzureDiscoveryRequest,
    AzureDiscoveryResponse,
    ResourceNode,
    VisualizationOptions,
    VisualizationResponse,
)
from azure_discovery.orchestrator import run_discovery


@pytest.mark.asyncio
async def test_run_discovery_enriches_response(monkeypatch: pytest.MonkeyPatch) -> None:
    request = AzureDiscoveryRequest(tenant_id="tenant-1")
    base_response = AzureDiscoveryResponse(
        tenant_id="tenant-1",
        discovered_subscriptions=["sub-a"],
        nodes=[
            ResourceNode(
                id="vm-a",
                name="vm-a",
                type="Microsoft.Compute/virtualMachines",
                subscription_id="sub-a",
            )
        ],
        relationships=[],
        total_resources=1,
    )

    async def fake_enumerate(req: AzureDiscoveryRequest) -> AzureDiscoveryResponse:
        assert req is request
        return base_response

    def fake_render_visualization(
        response: AzureDiscoveryResponse,
        options: VisualizationOptions,
    ) -> VisualizationResponse:
        assert response is base_response
        assert options == request.visualization
        return VisualizationResponse(
            html_path="artifacts/graphs/test.html",
            nodes=len(response.nodes),
            relationships=len(response.relationships),
        )

    emitted: dict[str, AzureDiscoveryResponse] = {}

    def fake_emit_console_summary(response: AzureDiscoveryResponse) -> None:
        emitted["response"] = response

    monkeypatch.setattr(
        "azure_discovery.orchestrator.enumerate_azure_resources", fake_enumerate
    )
    monkeypatch.setattr(
        "azure_discovery.orchestrator.render_visualization", fake_render_visualization
    )
    monkeypatch.setattr(
        "azure_discovery.orchestrator.emit_console_summary", fake_emit_console_summary
    )

    enriched_response = await run_discovery(request)

    assert enriched_response.html_report_path == "artifacts/graphs/test.html"
    assert enriched_response is not base_response
    assert emitted["response"] is enriched_response
