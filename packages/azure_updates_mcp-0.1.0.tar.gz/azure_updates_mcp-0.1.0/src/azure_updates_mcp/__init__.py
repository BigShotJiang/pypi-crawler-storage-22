"""Azure Updates MCP Server - Query Azure Updates RSS feed via MCP."""

__version__ = "0.1.0"
