"""RSS feed handling for Azure Updates."""
