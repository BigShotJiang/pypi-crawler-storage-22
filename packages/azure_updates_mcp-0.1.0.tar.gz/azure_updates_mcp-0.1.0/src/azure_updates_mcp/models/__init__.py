"""Data models for Azure Updates."""

from .update import AzureUpdate

__all__ = ["AzureUpdate"]
