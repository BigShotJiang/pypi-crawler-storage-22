"""Tests for Azure Updates MCP Server."""
