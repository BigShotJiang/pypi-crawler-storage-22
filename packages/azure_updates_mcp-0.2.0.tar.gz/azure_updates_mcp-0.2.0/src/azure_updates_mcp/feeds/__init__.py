"""Azure Updates JSON API client."""
