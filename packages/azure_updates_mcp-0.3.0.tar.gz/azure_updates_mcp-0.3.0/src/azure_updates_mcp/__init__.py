"""Azure Updates MCP Server - Query Azure Updates JSON API via MCP."""

__version__ = "0.3.0"
