"""MCP tools for Azure Updates."""
