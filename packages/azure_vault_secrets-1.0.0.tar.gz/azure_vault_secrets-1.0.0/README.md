# Azure Vault Secrets

A Python client library for securely accessing and managing secrets stored in Azure Key Vault.

## Features

- 🔐 Secure secret retrieval from Azure Key Vault
- ⚡ Built-in caching to reduce API calls
- 🔄 Support for secret CRUD operations
- 🛡️ Automatic authentication using Azure credentials
- 🧪 Comprehensive test coverage
- 📝 Type hints for better IDE support

## Installation

### Prerequisites

- Python 3.9+
- Azure subscription
- Azure Key Vault instance

### From PyPI

```bash
pip install azure-vault-secrets
```

### From Source

```bash
git clone https://github.com/PioManojDatt/azure-vault-secrets.git
cd azure-vault-secrets
pip install -e .
```

## Quick Start

### Basic Usage

```python
from azure_vault_secrets import SecretClient

# Initialize the client
client = SecretClient(vault_url="https://<vault-name>.vault.azure.net/")

# Retrieve a secret
secret = client.get_secret("my-secret-name")
print(secret)

# Store a secret
client.set_secret("new-secret", "secret-value")

# List all secrets
secrets = client.list_secrets()
print(secrets)

# Delete a secret
client.delete_secret("secret-to-delete")
```

### With Custom Cache TTL

```python
from azure_vault_secrets import SecretClient

# Initialize with 10-minute cache TTL
client = SecretClient(
    vault_url="https://<vault-name>.vault.azure.net/",
    cache_ttl_seconds=600,
    enable_cache=True
)

# Use the client...
secret = client.get_secret("my-secret")
```

### Disable Caching

```python
client = SecretClient(
    vault_url="https://<vault-name>.vault.azure.net/",
    enable_cache=False
)
```

## Authentication

The client uses Azure's `DefaultAzureCredential` for authentication, which supports multiple authentication methods:

1. **Environment Variables** - `AZURE_TENANT_ID`, `AZURE_CLIENT_ID`, `AZURE_CLIENT_SECRET`
2. **Azure CLI** - Automatically uses credentials from `az login`
3. **Managed Identity** - In Azure services (App Service, Functions, etc.)
4. **Visual Studio Code** - Uses VS Code Azure extension authentication

### Setting Up Authentication

#### Using Azure CLI

```bash
az login
```

#### Using Environment Variables

```bash
export AZURE_TENANT_ID="<your-tenant-id>"
export AZURE_CLIENT_ID="<your-client-id>"
export AZURE_CLIENT_SECRET="<your-client-secret>"
```

## Error Handling

```python
from azure_vault_secrets import SecretClient, SecretNotFoundError, AuthenticationError

client = SecretClient(vault_url="https://<vault-name>.vault.azure.net/")

try:
    secret = client.get_secret("my-secret")
except SecretNotFoundError:
    print("Secret not found in vault")
except AuthenticationError:
    print("Failed to authenticate with Azure")
except Exception as e:
    print(f"An error occurred: {e}")
```

## API Reference

### SecretClient

#### Methods

- `get_secret(secret_name: str) -> str` - Retrieve a secret
- `set_secret(secret_name: str, secret_value: str) -> None` - Store a secret
- `delete_secret(secret_name: str) -> None` - Delete a secret
- `list_secrets() -> list` - List all secrets
- `clear_cache() -> None` - Clear the secret cache
- `close() -> None` - Close the client connection

### SecretCache

#### Methods

- `get(key: str) -> Optional[str]` - Get a cached value
- `set(key: str, value: str) -> None` - Cache a value
- `clear() -> None` - Clear all cached values
- `remove(key: str) -> None` - Remove a specific cached value
- `is_expired(key: str) -> bool` - Check if a cached value has expired

## Testing

Run the test suite:

```bash
pytest tests/
```

With coverage:

```bash
pytest --cov=azure_vault_secrets tests/
```

## Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For issues, questions, or suggestions, please open an issue on the [GitHub repository](https://github.com/PioManojDatt/azure-vault-secrets/issues).

## Changelog

### 0.1.0 (Initial Release)

- Initial release
- Basic secret CRUD operations
- Caching support
- Azure Key Vault integration

## Security Considerations

- Never hardcode secrets in your code
- Always use Azure Key Vault for secret storage
- Regularly rotate your secrets
- Use Managed Identity when running in Azure services
- Keep the Azure SDK up to date

## Performance Tips

- Use caching for frequently accessed secrets
- Adjust cache TTL based on your security requirements
- List secrets sparingly (this operation can be expensive)
- Consider using Managed Identity for better performance in Azure

## Resources

- [Azure Key Vault Documentation](https://docs.microsoft.com/azure/key-vault/)
- [Azure Identity Library](https://github.com/Azure/azure-sdk-for-python/tree/main/sdk/identity/azure-identity)
- [Azure Key Vault Secrets Library](https://github.com/Azure/azure-sdk-for-python/tree/main/sdk/keyvault/azure-keyvault-secrets)
