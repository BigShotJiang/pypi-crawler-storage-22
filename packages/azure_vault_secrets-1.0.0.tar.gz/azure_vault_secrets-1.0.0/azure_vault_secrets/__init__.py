"""Azure Vault Secrets - A client library for accessing Azure Key Vault secrets."""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .client import SecretClient
from .cache import SecretCache
from .exceptions import SecretNotFoundError, AuthenticationError, AzureVaultException

__all__ = [
    "SecretClient",
    "SecretCache",
    "SecretNotFoundError",
    "AuthenticationError",
    "AzureVaultException",
]
