"""Custom exceptions for Azure Vault Secrets."""


class AzureVaultException(Exception):
    """Base exception for Azure Vault Secrets."""

    pass


class SecretNotFoundError(AzureVaultException):
    """Raised when a requested secret is not found in Azure Key Vault."""

    pass


class AuthenticationError(AzureVaultException):
    """Raised when authentication with Azure Key Vault fails."""

    pass


class CacheError(AzureVaultException):
    """Raised when an error occurs in the secret cache."""

    pass
