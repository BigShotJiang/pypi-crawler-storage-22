import base64
import traceback

import jwt
import msgpack

# 更简洁的版本，直接返回原始数据
def jwtsign_read_extract(download_sign):
    try:
        # 解码JWT而不验证签名
        payload = jwt.decode(
            download_sign.strip(),
            options={"verify_signature": False}  # 不验证签名
        )
        download_data = payload["download_path"]
        download_pack = base64.b64decode(download_data)
        download_info = msgpack.loads(download_pack, raw=False)

        return {
            "proto": download_info["proto"],
            "prefix": download_info["prefix"],
            "path": download_info["path"],
            "check_point_hash": "127.0.0.1"
        }

    except Exception as e:
        traceback.print_exc()
        print(f"Decode error: {e}")
        return None