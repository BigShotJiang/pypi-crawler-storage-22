# babappaomega/cli.py
# ============================================================
# BABAPPAΩ — COMMAND-LINE INTERFACE
# ============================================================

import argparse
from pathlib import Path

from babappaomega.inference import run_inference
from babappaomega.interpret import interpret_results


def main():
    parser = argparse.ArgumentParser(
        prog="babappaomega",
        description=(
            "BABAPPAΩ: likelihood-free inference of episodic "
            "selection burden in phylogenetic data"
        )
    )

    parser.add_argument(
        "--alignment",
        required=True,
        help="Input codon alignment (FASTA)"
    )
    parser.add_argument(
        "--tree",
        required=True,
        help="Phylogenetic tree (Newick)"
    )
    parser.add_argument(
        "--out",
        default=None,
        help=(
            "Output JSON file (default: <alignment>.babappaomega.json)"
        )
    )
    parser.add_argument(
        "--device",
        default="auto",
        choices=["auto", "cpu", "cuda"],
        help="Inference device"
    )
    parser.add_argument(
        "--model",
        default="frozen",
        help="Model tag (default: frozen)"
    )

    parser.add_argument(
        "--no-interpretation",
        action="store_true",
        help="Disable generation of human-readable interpretation"
    )

    args = parser.parse_args()

    # ------------------------------------------------
    # RESOLVE OUTPUT PATH
    # ------------------------------------------------
    if args.out is None:
        aln_path = Path(args.alignment)
        out_path = aln_path.with_suffix(".babappaomega.json")
    else:
        out_path = Path(args.out)

    # ------------------------------------------------
    # RUN INFERENCE (WRITES JSON TO DISK)
    # ------------------------------------------------
    run_inference(
        alignment_path=args.alignment,
        tree_path=args.tree,
        out_path=str(out_path),
        device=args.device,
        model_tag=args.model,
    )

    print(f"[OK] Results written to {out_path}")

    # ------------------------------------------------
    # RUN INTERPRETATION (READS JSON FROM DISK)
    # ------------------------------------------------
    if not args.no_interpretation:
        interpret_results(str(out_path))
        txt_out = out_path.with_suffix(".interpretation.txt")
        print(f"[OK] Interpretation written to {txt_out}")


if __name__ == "__main__":
    main()
