# babappaomega/interpret.py
# ============================================================
# BABAPPAΩ — HUMAN-READABLE INTERPRETATION LAYER
# ============================================================

import json
import numpy as np
from collections import defaultdict
from pathlib import Path

# ------------------------------------------------------------
# BRANCH TYPE GUARDS (CRITICAL)
# ------------------------------------------------------------

def _is_internal_branch(name: str) -> bool:
    """
    Internal branches are deterministically named by tree.py
    as 'internal_<id>'.
    """
    return name.startswith("internal_")


def _is_terminal_branch(name: str) -> bool:
    """
    Terminal branches correspond to extant taxa (leaf nodes).
    These are the ONLY branches allowed in reporting.
    """
    return not _is_internal_branch(name)


# ------------------------------------------------------------
# CORE INTERPRETATION
# ------------------------------------------------------------

def interpret_results(
    result_json,
    out_path=None,
    top_branches=10,
    top_sites=20,
):
    """
    Generate a conservative, biologically meaningful interpretation
    of BABAPPAΩ inference results.

    Internal branches are ALWAYS excluded from reporting.
    """

    # --------------------------------------------------------
    # LOAD RESULTS
    # --------------------------------------------------------
    with open(result_json) as f:
        results = json.load(f)

    site_scores = np.asarray(results["site_scores"])
    branch_scores = results["branch_background"]

    # --------------------------------------------------------
    # FILTER TERMINAL BRANCHES (STRICT)
    # --------------------------------------------------------
    terminal_branch_scores = {
        b: s for b, s in branch_scores.items()
        if _is_terminal_branch(b)
    }

    # DEFENSIVE ASSERTION — BUG MUST NEVER REAPPEAR
    assert len(terminal_branch_scores) > 0, (
        "No terminal branches detected. "
        "Check tree labels or filtering logic."
    )

    assert all(
        not b.startswith("internal_")
        for b in terminal_branch_scores
    ), "INTERNAL BRANCH LEAK DETECTED — REPORTING ABORTED"

    # --------------------------------------------------------
    # BRANCH Z-SCORES (TERMINAL ONLY)
    # --------------------------------------------------------
    branch_vals = np.array(list(terminal_branch_scores.values()))
    mu = branch_vals.mean()
    sd = branch_vals.std() + 1e-8

    branch_z = {
        b: (s - mu) / sd
        for b, s in terminal_branch_scores.items()
    }

    ranked_branches = sorted(
        terminal_branch_scores.keys(),
        key=lambda b: branch_z[b],
        reverse=True
    )

    # --------------------------------------------------------
    # SITE Z-SCORES
    # --------------------------------------------------------
    site_mu = site_scores.mean()
    site_sd = site_scores.std() + 1e-8
    site_z = (site_scores - site_mu) / site_sd

    ranked_sites = np.argsort(site_z)[::-1]

    # --------------------------------------------------------
    # PER-BRANCH DRIVER SITES (TERMINAL ONLY)
    # --------------------------------------------------------
    branch_site_drivers = defaultdict(list)

    for b in ranked_branches[:top_branches]:
        for i in ranked_sites[:top_sites]:
            branch_site_drivers[b].append(
                (i + 1, site_scores[i], site_z[i])
            )

    # --------------------------------------------------------
    # WRITE REPORT
    # --------------------------------------------------------
    if out_path is None:
        out_path = Path(result_json).with_suffix(".interpretation.txt")

    with open(out_path, "w") as out:
        out.write("BABAPPAΩ — INTERPRETED RESULTS\n")
        out.write("=" * 60 + "\n\n")

        # SUMMARY
        out.write("1. SUMMARY\n")
        out.write("-" * 60 + "\n")
        out.write(
            f"This analysis evaluated {len(site_scores)} codon sites "
            f"across {len(terminal_branch_scores)} terminal evolutionary branches.\n\n"
        )
        out.write(
            "Scores represent relative episodic selection burden:\n"
            "- Higher values indicate lineage-specific evolutionary stress\n"
            "- Interpretation is relative, not absolute\n\n"
        )

        # TOP BRANCHES
        out.write("2. TERMINAL BRANCHES WITH STRONGEST GLOBAL DEVIATION\n")
        out.write("-" * 60 + "\n")

        for i, b in enumerate(ranked_branches[:top_branches], 1):
            out.write(
                f"{i:2d}. {b:<40} "
                f"background={terminal_branch_scores[b]:.4f}  "
                f"z={branch_z[b]:+.2f}\n"
            )

        out.write(
            "\nInterpretation:\n"
            "Branches listed above show unusually high overall evolutionary\n"
            "stress compared to other terminal lineages.\n\n"
        )

        # TOP SITES
        out.write("3. SITES WITH STRONGEST EPISODIC SELECTION BURDEN\n")
        out.write("-" * 60 + "\n")

        for i in ranked_sites[:top_sites]:
            out.write(
                f"Site {i+1:4d}  "
                f"score={site_scores[i]:.4f}  "
                f"z={site_z[i]:+.2f}\n"
            )

        out.write(
            "\nInterpretation:\n"
            "These codon positions show unusually high episodic deviation,\n"
            "likely driven by a subset of branches rather than uniform\n"
            "divergence across the tree.\n\n"
        )

        # NOTES
        out.write("5. INTERPRETATION NOTES\n")
        out.write("-" * 60 + "\n")
        out.write(
            "- Internal tree nodes are strictly excluded from reporting.\n"
            "- Scores are not dN/dS or ω estimates.\n"
            "- Values reflect relative evolutionary stress.\n"
            "- Per-branch site lists indicate putative drivers, not\n"
            "  definitive causal substitutions.\n"
            "- High-ranking sites should be mapped to protein domains\n"
            "  or structural models for validation.\n"
        )

    return out_path
