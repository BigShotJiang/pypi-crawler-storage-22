﻿babilonia.accounting
====================

.. automodule:: babilonia.accounting

   
   .. rubric:: Classes

   .. autosummary::
   
      BBCDB
      Budget
      CashFlow
      CashFlowBBCC
      CashFlowBBCCPJ
      CashFlowBBPP
      NFSe
      NFSeColl
   