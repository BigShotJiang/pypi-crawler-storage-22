﻿babilonia.tools.parse
=====================

.. automodule:: babilonia.tools.parse

   
   .. rubric:: Functions

   .. autosummary::
   
      main
   