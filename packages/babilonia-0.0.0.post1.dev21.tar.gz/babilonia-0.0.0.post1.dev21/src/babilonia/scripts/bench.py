import pprint
import re
import pandas as pd

def split_accounts(lines):

    dc_accounts = {
        "BB CDB DI": "BB CDB PROGRESSIVO",
        "BB CDB PROGRESSIVO": None
    }

    ls_accounts = list(dc_accounts.keys())
    b_collect = False
    dc_data = {}
    for account in ls_accounts:
        ls_data = []
        for i, line in enumerate(lines[:]):
            if account in line:
                b_collect = True

            if dc_accounts[account] is None:
                pass
            elif dc_accounts[account] in line:
                b_collect = False

            if b_collect:
                ls_data.append(line)

        dc_data[account] = ls_data[:]

    return dc_data

def split_sections(dc_data):
    sections = {}

    section_titles = {
        "CAIXA": {
            "START": None,
            "END":"SALDO NOS ULTIMOS 6 MESES"
        },
        "SALDOS": {
            "START": "SALDO NOS ULTIMOS 6 MESES",
            "END":"RESUMO DOS DEPOSITOS EM SER"
        },
        "DEPOSITOS": {
            "START": "RESUMO DOS DEPOSITOS EM SER",
            "END":"RENDIMENTO BRUTO NO PERIODO POR DEPOSITO"
        },
        "RENDIMENTOS": {
            "START": "RENDIMENTO BRUTO NO PERIODO POR DEPOSITO",
            "END": None,
        }
    }

    dc_data_out = {}

    for account in dc_data:
        print(account)
        dc_account_data = {}

        for title in section_titles:
            ls_data = []
            if title == "CAIXA":
                for line in dc_data[account]:
                    b_collect = True

                    if section_titles[title]["END"] in line:
                        b_collect = False
                        break

                    if b_collect:

                        if "Saldo anterior" in line:
                            pass
                        elif "capital" in line:
                            pass

                        elif "Saldo final" in line:
                            pass

                        else:
                            ls_data.append(line[:])

                ls_data[1] = "Data;Historico;Deposito;Valor"
                if len(ls_data) > 3:
                    ls_data_new = ls_data[:2]
                    for i in range(0, len(ls_data[2:]), 2):
                        line_new = ls_data[2:][i] + ls_data[2:][i + 1]
                        line_new = line_new.replace("-", "")
                        line_new = line_new.replace("valor juros", "")
                        line_new = line_new.replace("Rendimento  mensal", "Juros")
                        ls_data_new.append(line_new[:])

                    ls_data = ls_data_new[1:]


            elif title == "SALDOS":
                for line in dc_data[account]:

                    if section_titles[title]["START"] in line:
                        b_collect = True

                    if section_titles[title]["END"] in line:
                        b_collect = False
                        break

                    if b_collect:
                        ls_data.append(line[:])

                ls_data[1] = "Data;Capital_Inicial;Juros;IR_Projetado;Capital_Projetado"
                ls_data = ls_data[1:]

            elif title == "DEPOSITOS":
                for line in dc_data[account]:
                    if section_titles[title]["START"] in line:
                        b_collect = True

                    if section_titles[title]["END"] in line:
                        b_collect = False
                        break

                    if b_collect:
                        ls_data.append(line[:])
                ls_data[1] = "Deposito;Data_Aplicacao;Capital;Saldo;Taxa;Data_Vencimento"
                ls_data = ls_data[1:]

            elif title == "RENDIMENTOS":
                for line in dc_data[account]:
                    if section_titles[title]["START"] in line:
                        b_collect = True

                    if b_collect:
                        ls_data.append(line[:])

                ls_data[1] = "Data;Deposito;Rendimento_Bruto"
                ls_data = ls_data[1:]


            ls_processed = []
            for line in ls_data:
                collapsed = re.sub(r"\s+", ";", line.strip())
                ls_processed.append(collapsed[:])

            dc_account_data[title] = ls_processed[:]

        dc_data_out[account] = dc_account_data.copy()

    return dc_data_out

def read_txt_as_lines(path, encoding="cp1252"):
    with open(path, encoding=encoding) as f:
        lines = f.readlines()

    ls = []
    for line in lines:
        ls.append(line[:])

    return ls

def drop_blank_lines(lines):
    return [line for line in lines if line.strip()]

def drop_lines(lines, contains="-"):
    return [line for line in lines if contains not in line]

def replacer(lines, contains="\xa0", relacer=" "):
    return [line.replace(contains, relacer) for line in lines]


if __name__ == "__main__":

    print('hello world!')

    file_txt = "C:/Users/Ipo/My Drive/athens/babilonia/money/bb/cdb/2026/EXTRATO_BB_CDB_2026-01_T0.txt"

    ls_data = read_txt_as_lines(file_txt)

    ls_data = drop_lines(ls_data, contains="--")

    ls_data = drop_lines(ls_data, contains="==")

    ls_data = drop_blank_lines(ls_data)
    ls_data = replacer(ls_data)
    ls_data = replacer(ls_data, "\n", "")

    #pprint.pprint(ls_data[:40])

    dc_data = split_accounts(ls_data)

    #pprint.pprint(dc_data)

    dc_data2 = split_sections(dc_data=dc_data)

    print("\n\n")
    print()
    for c in dc_data2:
        for k in dc_data2[c]:
            print("-----")
            print(f"{c} {k}")
            print()
            for line in dc_data2[c][k]:
                print(line)

    #data["BB CDB DI"]["depositos"].head()