import pprint
from pathlib import Path
from babilonia.accounting import BBCDB

if __name__ == "__main__":
    print("Hello World!")

    dc_accounts = {
        "BB CDB DI": "CDBDI",
        "BB CDB PROGRESSIVO": "CDBPROG",
    }

    file_txt = "C:/Users/Ipo/My Drive/athens/babilonia/money/bb/cdb/2025/EXTRATO_BB_CDB_2025-01_T0.txt"
    folder = Path(file_txt).parent
    cdb = BBCDB()
    cdb.load_data(file_txt)

    for a in cdb.data:
        for s in cdb.data[a]:
            print(f"\n{a} -- {s}")
            df = cdb.data[a][s]
            print(df)

            #file_path = folder / f"{s}_BB_{dc_accounts[a]}_2025-01_T1.csv"
            #df.to_csv(file_path, sep=";", index=False)


