from pathlib import Path

WORKPLACE = Path("C:/Users/Ipo/My Drive/athens")
CARTAGO_DIR = WORKPLACE / "cartago"
BABYLON_DIR = WORKPLACE / "babylon"

MONEY_DIR = BABYLON_DIR / "money"
NU_DIR = MONEY_DIR / "nubank"
BB_DIR = MONEY_DIR / "bb"
SLU_DIR = BABYLON_DIR / "business/slu"


