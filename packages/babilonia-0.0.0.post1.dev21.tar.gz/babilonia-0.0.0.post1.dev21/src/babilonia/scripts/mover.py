from scripts.entry import BB_DIR, SLU_DIR, NU_DIR
import glob, shutil, os, re
from pathlib import Path

people = {
    "IPORA-BRITO-POSSANTTI": "83433732000",
    "LUIS-GUSTAVO-MELLO-NUNES": "03284440062",
    "JULIANO-SANTOS-FINCK": "03101609011",
    "RAFAEL-BARBEDO-FONTANA": "85362760025",
    "GUILHERME-FERNANDES-MARQUES": "76947661668",
}


if __name__ == "__main__":

    # LIST FILE
    print(BB_DIR)
    pattern = BB_DIR / "ccpj/_arquivo/*/*/prolabore_*.pdf"
    print(pattern)
    print(str(pattern))
    ls = glob.glob(str(pattern))

    # LOOP
    for f in ls:
        print(f)
        name = Path(f).name
        year = name.split("_")[2][:4]
        month = name.split("_")[2][5:7]
        person = name.split("_")[1].upper()
        last = name.split("_")[-1]
        print(last)
        if last == "comprovante.pdf":
            new_name = f"PAGAMENTO_27643216000121_PROLABORE-{people[person]}_{year}-{month}_COMPROVANTE.pdf"
        else:
            new_name = f"PAGAMENTO_27643216000121_PROLABORE-{people[person]}_{year}-{month}_RECIBO.pdf"
        # CHANGE NAMES
        print(new_name)

        # infer month
        dst_folder = SLU_DIR / f"series/{year}/prolabore/{people[person]}_{person}"
        #print(dst_folder)
        dst_file =  dst_folder / new_name
        #shutil.copy(f, dst_file)
