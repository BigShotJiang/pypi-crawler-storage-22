from scripts.entry import BB_DIR, SLU_DIR
import glob, shutil, os

if __name__ == "__main__":

    # LIST FILE
    print(BB_DIR)
    pattern = SLU_DIR / "series/*/contador/*.pdf"
    print(pattern)
    print(str(pattern))
    ls = glob.glob(str(pattern))

    # LOOP
    for f in ls:
        print(f)
        # CHANGE NAMES
        f1 = f.replace("PAGAMENTO_", "PAGAMENTO_27643216000121_")
        print(f1)
        # RENAME
        os.rename(f, f1)



