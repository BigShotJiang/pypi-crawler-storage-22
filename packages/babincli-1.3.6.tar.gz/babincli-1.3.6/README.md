<div align="center">

# 🤖 BabinCLI

[![PyPI version](https://badge.fury.io/py/babincli.svg)](https://pypi.org/project/babincli/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9%2B-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**My AI-powered terminal assistant built with Gemini 2.5 Flash, Groq, NVIDIA, and GitHub**

[📦 Install 📦](#installation) · [⚡ Quick Start ⚡](#quick-start) · [📖 Full Guide 📖](https://github.com/KGFCH2/BabinCLI/blob/main/INSTRUCTIONS.md) · [🧠 Logic 🧠](https://github.com/KGFCH2/BabinCLI/blob/main/LOGIC.md) · [🌐 Portal 🌐](https://KGFCH2.github.io/BabinCLI/)

</div>

---

## ✨ Features

This CLI tool is my personal assistant, and I've packed it with features I use every day:

| Feature | Description |
|---|---|
| **Multi-Provider** | Gemini, Groq, NVIDIA, & GitHub |
| **Streaming Output** | Typewriter response generation (v1.3.6) |
| **Web Search** | Automatic DuckDuckGo search for live info (v1.3.6) |
| **File Context** | Inject file content into AI prompt with `-f` (v1.3.6) |
| **Persistent History**| Conversations saved automatically (v1.3.6) |
| **Animation** | Premium live typewriter generation (v1.3.6) |
| **Multi-Key Rotation** | Comma-separated Gemini keys for multiplied quota |
| **Live Weather** | Real-time weather data injected into responses |
| **Mid-Chat Switch** | Change models on-the-fly without restarting |
| **Shortcuts** | Quick commands like `babin a`, `babin c`, `babin h` |
| **Global Options** | Use `-p`, `-m`, `-f` anywhere in the command |

---

## <a id="installation"></a>📦 Installation

```bash
pip install babincli
```

> Or install from GitHub: `pip install git+https://github.com/KGFCH2/BabinCLI.git`

> **Windows**: BabinCLI auto-fixes PATH on first run. If `babin` isn't recognized, run `python -m babin_cli setup-path` and open a new terminal.

---

## ⚙️ Quick Setup

Copy `.env.example` to `.env` and add your API keys:

```env
GEMINI_API_KEY=your_key_here
GROQ_API_KEY=your_key_here
OPENWEATHERMAP_API_KEY=your_key_here    # optional
WEATHERAPI_KEY=your_key_here            # optional
```

> 🔑 **Multi-key**: Use `GEMINI_API_KEY=key1,key2,key3` to multiply your daily quota!

Get free keys: [Google AI Studio](https://aistudio.google.com/) · [Groq Console](https://console.groq.com/) · [NVIDIA](https://build.nvidia.com/) · [GitHub](https://github.com/marketplace/models)

---

## <a id="quick-start"></a>⚡ Quick Start

```bash
babin c                           # Start chat (Groq - llama-3.3-70b)
babin -p github c                 # Chat with GPT-5 Nano
babin -p gemini c                 # Chat with Gemini (Global flag)
babin a "What is Python?"         # Quick question
babin -f main.py a "Explain"      # Analyze file (Global flag)
babin h                           # View history (After session ends)
babin -p gemini c                 # Chat with Gemini (Global flag)
babin lm                          # List available models
```

### 🕒 Chat History Note
All sessions are saved in `~/.babincli_history/`. To see your latest session in history, you must **exit the current chat** (type `exit` or `quit`). History is written to disk only after the session is terminated.

### Switch Models Mid-Chat

Type `switch` during any chat session to see a numbered menu of available models and switch instantly — no restart needed!

---

## 📖 Full Documentation

See **[INSTRUCTIONS.md](INSTRUCTIONS.md)** for the complete guide including:
- Detailed configuration for all platforms
- All commands with examples
- Multi-key rotation explained
- Auto-fallback behavior
- Local development & testing
- Troubleshooting

---

## 🌐 Portal

Visit **[KGFCH2.github.io/BabinCLI](https://KGFCH2.github.io/BabinCLI/)** for the interactive documentation portal with code examples and AI helper.

---

## 📤 Publishing to PyPI

### 🤖 Automated Publishing (GitHub Actions)

This project uses **GitHub Actions** for automatic PyPI publishing:

1. 🏷️ **Bump version** in `pyproject.toml` and `babin_cli/__init__.py`
2. 💾 **Commit changes**: `git commit -m "Update message"` (Updates GitHub only)
3. 🚀 **Push Tag**: `git tag v1.3.6 && git push origin v1.3.6` (Updates PyPI automatically)

> ⚠️ **Note**: A regular `git push` will **not** update PyPI. You must push a version tag to trigger the automation.

### 📦 Manual Publishing

For manual publishing or testing:

```bash
# 1. Install build tools
pip install build twine

# 2. Build the package
python -m build

# 3. Upload to PyPI
python -m twine upload dist/*
```

### ⚙️ First-Time Setup

**For GitHub Actions:**
1. Go to [pypi.org](https://pypi.org) → Project Settings → **Publishing**
2. Add **Trusted Publisher** with:
   - **Owner**: `KGFCH2`
   - **Repository**: `BabinCLI`
   - **Workflow**: `publish.yml`
   - **Environment**: `pypi`
3. **Save** → GitHub Actions can now publish without tokens.

> 🔑 **Manual Publishing Account**: Create account at [pypi.org](https://pypi.org/account/register/) & generate API token.

> 📖 **Detailed Guide**: See [INSTRUCTIONS.md](INSTRUCTIONS.md) for comprehensive publishing instructions.

---

## 📄 License

MIT License © 2026 Babin Bid

*Personal project hand-crafted with 💖 by [Babin Bid](https://github.com/KGFCH2).*

---

### ⭐ Support

If you find this useful, please **give it a star on GitHub**! It helps me keep building.
