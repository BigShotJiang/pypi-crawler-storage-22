"""BabinCLI: A powerful assistant powered by Gemini 2.5 Flash & Groq with weather, web search, and file context."""

__version__ = "1.3.6"
