"""Allow running BabinCLI as: python -m babin_cli"""

from babin_cli.main import cli

if __name__ == "__main__":
    cli()
