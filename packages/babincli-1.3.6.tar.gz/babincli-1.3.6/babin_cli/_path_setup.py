"""
Auto-fix PATH on Windows so `babin` command works immediately after `pip install babincli`.

When pip installs with --user on Windows, scripts go to:
  %APPDATA%\\Python\\PythonXYZ\\Scripts\\
This directory is often NOT in PATH, causing 'babin' is not recognized errors.

This module detects the situation and permanently adds the Scripts directory
to the user's PATH via the Windows registry, then broadcasts the change
so new Command Prompt / PowerShell windows pick it up immediately.
"""

import os
import sys
import site
import glob


def _get_user_scripts_dirs():
    """Find all potential Python user Scripts directories on Windows."""
    dirs = set()

    # Method 1: site.getusersitepackages() -> go up to Scripts
    try:
        user_site = site.getusersitepackages()
        if user_site:
            # user_site is like C:\Users\X\AppData\Roaming\Python\Python313\site-packages
            scripts_dir = os.path.join(os.path.dirname(user_site), "Scripts")
            if os.path.isdir(scripts_dir):
                dirs.add(os.path.normpath(scripts_dir))
    except Exception:
        pass

    # Method 2: Check APPDATA-based paths
    appdata = os.environ.get("APPDATA", "")
    if appdata:
        pattern = os.path.join(appdata, "Python", "Python*", "Scripts")
        for d in glob.glob(pattern):
            if os.path.isdir(d):
                dirs.add(os.path.normpath(d))

    # Method 3: Check where babin.exe actually lives (if already installed)
    for d in dirs.copy():
        babin_exe = os.path.join(d, "babin.exe")
        if os.path.isfile(babin_exe):
            dirs.add(os.path.normpath(d))

    # Method 4: The standard Python Scripts directory
    scripts_in_prefix = os.path.join(sys.prefix, "Scripts")
    if os.path.isdir(scripts_in_prefix):
        dirs.add(os.path.normpath(scripts_in_prefix))

    return dirs


def _get_current_user_path():
    """Read the current user PATH from the Windows registry."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Environment", 0,
                            winreg.KEY_READ) as key:
            value, _ = winreg.QueryValueEx(key, "Path")
            return value
    except FileNotFoundError:
        return ""
    except Exception:
        return ""


def _set_user_path(new_path):
    """Write the user PATH to the Windows registry and broadcast the change."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Environment", 0,
                            winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "Path", 0, winreg.REG_EXPAND_SZ, new_path)

        # Broadcast WM_SETTINGCHANGE so new shells pick up the change
        try:
            import ctypes
            HWND_BROADCAST = 0xFFFF
            WM_SETTINGCHANGE = 0x001A
            SMTO_ABORTIFHUNG = 0x0002
            ctypes.windll.user32.SendMessageTimeoutW(
                HWND_BROADCAST, WM_SETTINGCHANGE, 0, "Environment",
                SMTO_ABORTIFHUNG, 5000, ctypes.byref(ctypes.c_ulong(0))
            )
        except Exception:
            pass  # Broadcasting is best-effort

        return True
    except Exception:
        return False


def _is_in_path(directory, path_string):
    """Check if a directory is already in a PATH string (case-insensitive on Windows)."""
    norm_dir = os.path.normpath(directory).lower()
    for entry in path_string.split(os.pathsep):
        if os.path.normpath(entry).lower() == norm_dir:
            return True
    return False


def ensure_windows_path():
    """
    Ensure Python user Scripts directory is in PATH on Windows.
    Returns a message string if PATH was modified, or None if no action needed.
    """
    if sys.platform != "win32":
        return None

    scripts_dirs = _get_user_scripts_dirs()
    if not scripts_dirs:
        return None

    # Get current user PATH from registry (persistent PATH)
    user_path = _get_current_user_path()

    # Also check the current process PATH
    process_path = os.environ.get("PATH", "")

    dirs_added = []
    for scripts_dir in scripts_dirs:
        # Check if babin.exe exists in this directory
        babin_exe = os.path.join(scripts_dir, "babin.exe")
        if not os.path.isfile(babin_exe):
            continue

        # Check if already in persistent user PATH
        if _is_in_path(scripts_dir, user_path):
            # Already in PATH permanently, ensure it's in current process too
            if not _is_in_path(scripts_dir, process_path):
                os.environ["PATH"] = scripts_dir + os.pathsep + os.environ.get("PATH", "")
            continue

        # Need to add to PATH
        if user_path:
            new_path = user_path + os.pathsep + scripts_dir
        else:
            new_path = scripts_dir

        if _set_user_path(new_path):
            user_path = new_path  # Update for subsequent checks
            dirs_added.append(scripts_dir)
            # Also add to current process PATH
            os.environ["PATH"] = scripts_dir + os.pathsep + os.environ.get("PATH", "")

    if dirs_added:
        return dirs_added[0]  # Return the first directory that was added
    return None
