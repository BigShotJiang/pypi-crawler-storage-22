import os
import sys
import json
import re
import time
import requests
import warnings
from datetime import datetime
from typing import Optional, List
import click
from google import genai
from google.genai import types
from groq import Groq
from dotenv import load_dotenv
from openai import OpenAI
import logging
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.rule import Rule
from rich.prompt import Prompt, Confirm
from rich.live import Live
from ddgs import DDGS

# Suppress noisy internal logs from libraries
logging.getLogger("duckduckgo_search").setLevel(logging.ERROR)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("curl_cffi").setLevel(logging.ERROR)
logging.getLogger("urllib3").setLevel(logging.ERROR)

# Auto-fix PATH on Windows
from babin_cli._path_setup import ensure_windows_path
from babin_cli._key_setup import run_interactive_setup, _get_env_path, _env_has_keys
_path_result = ensure_windows_path()

__version__ = "1.3.5"
HISTORY_DIR = os.path.join(os.path.expanduser("~"), ".babincli_history")
os.makedirs(HISTORY_DIR, exist_ok=True)

# Load environment variables — check home directory .env first, then CWD .env
_home_env = os.path.join(os.path.expanduser("~"), ".babincli.env")
if os.path.isfile(_home_env):
    load_dotenv(_home_env)
load_dotenv()  # Also load CWD .env (won't overwrite already-set keys)

# Ensure UTF-8 output for Windows terminals (supports Bengali, Hindi, etc.)
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except (AttributeError, Exception):
        pass

console = Console(force_terminal=True if os.getenv("TERM") else None)

# Show PATH fix message once (if PATH was just modified)
if _path_result:
    console.print(f"[bold green]✅ Auto-added Python Scripts to PATH:[/] {_path_result}")
    console.print("[dim]Open a new terminal window for the change to take effect everywhere.[/]\n")

# Default models per provider
DEFAULT_MODELS = {
    "gemini": "gemini-2.5-flash",
    "groq": "llama-3.3-70b-versatile",
    "nvidia": "meta/llama-3.1-8b-instruct",
    "github": "gpt-5-nano",
}

# Gemini models to try in order when quota is hit (free tier stability)
GEMINI_FALLBACK_CHAIN = [
    "gemini-2.5-flash",
]

# Max retries for temporary per-minute rate limits
MAX_RETRIES = 2

# Weather-related keywords for auto-detection
WEATHER_KEYWORDS = [
    "weather", "temperature", "forecast", "rain", "snow", "sunny",
    "cloudy", "humid", "wind", "storm", "celsius", "fahrenheit",
    "climate", "hot today", "cold today", "warm today",
]

# Models available for mid-chat switching
SWITCHABLE_MODELS = [
    ("gemini", "gemini-2.5-flash"),
    ("groq", "llama-3.3-70b-versatile"),
    ("groq", "llama-3.1-8b-instant"),
    ("nvidia", "meta/llama-3.1-8b-instruct"),
    ("github", "gpt-5-nano"),
    ("github", "gpt-4o-mini"),
]

# Commands that trigger model switching in chat
SWITCH_COMMANDS = {"switch", "switch model", "/switch", "/model", "sm", "change model"}


class ModelSwitchRequest(Exception):
    """Raised when user requests a model switch mid-chat."""
    def __init__(self, provider, model):
        self.provider = provider
        self.model = model


# ---------------------------------------------------------------------------
#  Multi-key support for Gemini
# ---------------------------------------------------------------------------

def _get_gemini_keys():
    """Return a list of Gemini API keys (supports comma-separated keys)."""
    raw = os.getenv("GEMINI_API_KEY", "")
    keys = [k.strip() for k in raw.split(",") if k.strip()]
    return keys


def _get_groq_keys():
    """Return a list of Groq API keys (supports comma-separated keys)."""
    raw = os.getenv("GROQ_API_KEY", "")
    keys = [k.strip() for k in raw.split(",") if k.strip()]
    return keys


def _get_nvidia_keys():
    """Return a list of NVIDIA API keys."""
    raw = os.getenv("NVIDIA_API_KEY", "")
    return [k.strip() for k in raw.split(",") if k.strip()]


def _get_github_keys():
    """Return a list of GitHub tokens."""
    raw = os.getenv("GITHUB_TOKEN", "")
    return [k.strip() for k in raw.split(",") if k.strip()]


def _get_openrouter_keys():
    """Return a list of OpenRouter API keys."""
    raw = os.getenv("OPENROUTER_API_KEY", "")
    return [k.strip() for k in raw.split(",") if k.strip()]


# ---------------------------------------------------------------------------
#  Weather integration
# ---------------------------------------------------------------------------

def _fetch_weather_openweathermap(city):
    """Fetch current weather from OpenWeatherMap API."""
    api_key = os.getenv("OPENWEATHERMAP_API_KEY")
    if not api_key:
        return None
    try:
        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {"q": city, "appid": api_key, "units": "metric"}
        resp = requests.get(url, params=params, timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            return {
                "source": "OpenWeatherMap",
                "city": data.get("name", city),
                "country": data.get("sys", {}).get("country", ""),
                "temp_c": data["main"]["temp"],
                "feels_like_c": data["main"]["feels_like"],
                "humidity": data["main"]["humidity"],
                "description": data["weather"][0]["description"],
                "wind_speed_mps": data["wind"]["speed"],
            }
    except Exception:
        pass
    return None


def _fetch_weather_weatherapi(city):
    """Fetch current weather from WeatherAPI.com."""
    api_key = os.getenv("WEATHERAPI_KEY")
    if not api_key:
        return None
    try:
        url = "https://api.weatherapi.com/v1/current.json"
        params = {"key": api_key, "q": city, "aqi": "no"}
        resp = requests.get(url, params=params, timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            current = data["current"]
            location = data["location"]
            return {
                "source": "WeatherAPI",
                "city": location.get("name", city),
                "country": location.get("country", ""),
                "temp_c": current["temp_c"],
                "feels_like_c": current["feelslike_c"],
                "humidity": current["humidity"],
                "description": current["condition"]["text"],
                "wind_speed_kph": current["wind_kph"],
            }
    except Exception:
        pass
    return None


def _fetch_weather_wttr(city):
    """Fetch current weather from wttr.in (free, no API key required)."""
    try:
        # wttr.in expects spaces as '+' and handles commas well
        safe_city = city.replace(" ", "+")
        url = f"https://wttr.in/{safe_city}?format=j1"
        resp = requests.get(url, timeout=5, headers={"User-Agent": "BabinCLI"})
        if resp.status_code == 200:
            data = resp.json()
            current = data["current_condition"][0]
            area = data.get("nearest_area", [{}])[0]
            return {
                "source": "wttr.in",
                "city": area.get("areaName", [{}])[0].get("value", city),
                "country": area.get("country", [{}])[0].get("value", ""),
                "temp_c": current["temp_C"],
                "feels_like_c": current["FeelsLikeC"],
                "humidity": current["humidity"],
                "description": current["weatherDesc"][0]["value"],
                "wind_speed_kph": current["windspeedKmph"],
            }
    except Exception:
        pass
    return None


def _extract_city_from_prompt(prompt):
    """Try to extract a city name from a weather-related prompt."""
    prompt_lower = prompt.lower()
    # Common patterns: "weather in Tokyo", "temperature of London", "how hot is it in Paris"
    patterns = [
        r'(?:weather|temperature|forecast|climate)\s+(?:in|of|at|for)\s+([a-zA-Z\s,]+)',
        r'(?:how\s+(?:hot|cold|warm|rainy|sunny))\s+(?:is\s+it\s+)?(?:in|at)\s+([a-zA-Z\s,]+)',
        r'(?:rain|snow|storm)(?:ing)?\s+(?:in|at)\s+([a-zA-Z\s,]+)',
        r'(?:in|at)\s+([a-zA-Z\s,]+?)\s*(?:weather|temperature|forecast)',
    ]
    for pattern in patterns:
        match = re.search(pattern, prompt_lower)
        if match:
            city = match.group(1).strip().rstrip('?.!')
            if city:
                return city.title()
    return None


def _fetch_web_search(query):
    """Perform a web search using DuckDuckGo (free, no key required)."""
    try:
        # Clean query: remove generic phrases for better search results
        junk_words = [
            "what is", "who is", "who are", "who's", "what's", "tell me about",
            "current", "status of", "latest", "news on", "information about", 
            "details on", "updates for", "any news on", "this", "that", "it", "?"
        ]
        clean_query = query.lower()
        for word in junk_words:
            # use regex to replace whole word only to avoid partial matches
            clean_query = re.sub(rf'\b{re.escape(word)}\b', '', clean_query)
        
        clean_query = clean_query.strip()
        if not clean_query or len(clean_query) < 3:
            return ""

        # console.print(f"[dim]🔍 Searching the web for: [italic]{clean_query}[/]...[/]")
        
        with DDGS() as ddgs:
            # use clean_query for search, but return original as context if needed
            results = list(ddgs.text(clean_query, max_results=8))
            if results:
                context = "\n\n--- !!! IMPORTANT: LIVE INTERNET DATA !!! ---\n"
                context += f"The following information was just fetched from the web regarding '{query}'.\n"
                context += "USE THIS DATA TO ANSWER. IT IS MORE RECENT THAN YOUR TRAINING DATA.\n\n"
                for i, r in enumerate(results, 1):
                    context += f"SOURCE {i}: {r['title']}\nCONTENT: {r['body']}\nURL: {r['href']}\n\n"
                context += "--- END OF LIVE DATA ---\n"
                return context
    except Exception as e:
        # console.print(f"[dim]Search failed: {e}[/]") # for internal debugging
        pass
    return ""


def _read_file_content(filepath):
    """Read content from a file to use as context (handles text files only)."""
    if not filepath:
        return ""
    try:
        if not os.path.isfile(filepath):
            return f"\n\n[Error: File '{filepath}' not found.]"
        
        # Check if file is likely binary by reading first 1024 bytes
        with open(filepath, 'rb') as f:
            chunk = f.read(1024)
            if b'\x00' in chunk:
                return f"\n\n[Warning: '{os.path.basename(filepath)}' appears to be a binary file. BabinCLI only supports text context.]"
        
        # Read text content
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read(50000) # Limit to 50k chars for safety
            if len(content) >= 50000:
                content += "\n\n[... content truncated due to size ...]"
            return f"\n\n--- ATTACHED FILE CONTEXT ({os.path.basename(filepath)}) ---\n{content}\n---"
    except Exception as e:
        return f"\n\n[Error reading file '{filepath}': {e}]"


def _save_chat_history(history, provider, model):
    """Save the chat session to a persistent history file."""
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"chat_{timestamp}_{provider}_{model}.md"
        path = os.path.join(HISTORY_DIR, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"# BabinCLI Chat Session\n")
            f.write(f"- Provider: {provider}\n")
            f.write(f"- Model: {model}\n")
            f.write(f"- Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write("---\n\n")
            for msg in history:
                role = msg.get("role", "user").capitalize()
                content = msg.get("content", "")
                f.write(f"### {role}\n{content}\n\n")
        return path
    except Exception:
        return None


def _is_web_search_query(prompt):
    """Check if the prompt likely needs a web search for live or factual information."""
    prompt_lower = prompt.lower().strip().rstrip('?.!')
    
    # 1. Do NOT search for conversational or generic phrases
    conversational_phrases = [
        "how are you", "how are you doing", "how are things", "how is it going",
        "hows it going", "how's it going", "what's up", "whats up", "what is up",
        "who are you", "what are you", "what is your name", "what's your name",
        "what can you do", "what is your purpose", "who built you", "who made you",
        "hello", "hi", "hey", "good morning", "good afternoon", "good evening",
        "thank you", "thanks", "bye", "goodbye"
    ]
    if any(p == prompt_lower for p in conversational_phrases):
        return False

    # 2. Do NOT search for generic "What is this" or "Tell me more" 
    generic_prompts = ["what is this", "what is it", "who is this", "tell me about this", "explain this"]
    if any(p == prompt_lower for p in generic_prompts):
        return False
        
    # 3. Avoid searching for extremely short queries
    if len(prompt_lower) < 5:
        return False

    search_keywords = [
        "search", "latest", "news", "who is", "what happened", "who's", "what's",
        "current", "price of", "update", "status", "who won", "score", "today",
        "yesterday", "recent", "stock", "crypto", "bitcoin", "movie", "film",
        "song", "album", "artist", "celebrity", "actor", "actress", "game",
        "release", "upcoming", "born", "died", "when", "launch", "event",
        "live", "results", "league", "match", "tournament", "president", 
        "governor", "ceo", "company", "weather", "temperature", "biography",
        "wiki", "player", "team", "club", "stats", "population", "capital",
        "founder", "owner", "price", "market", "trend"
    ]
    
    # Check if any strong search keywords are present
    has_keyword = any(kw in prompt_lower for kw in search_keywords)
    
    # 4. Trigger if it's a substantive question that isn't a conversational one
    if prompt_lower.startswith(("who ", "what ", "where ", "when ", "how ")):
        # For "how/what" questions, require a keyword OR more length to avoid false positives
        if has_keyword:
            return True
        if len(prompt_lower) > 25: # Longer questions are more likely to be search-worthy
            return True
        return False
        
    return has_keyword


def _is_weather_query(prompt):
    """Check if the user's prompt is weather-related."""
    prompt_lower = prompt.lower()
    return any(kw in prompt_lower for kw in WEATHER_KEYWORDS)


def _get_enrichment_context(prompt):
    """Fetch weather or web search data if the prompt needs live info."""
    context = ""
    
    # 1. Weather
    if _is_weather_query(prompt):
        city = _extract_city_from_prompt(prompt)
        if city:
            # First Priority: Official Weather APIs
            weather = _fetch_weather_openweathermap(city) or _fetch_weather_weatherapi(city)
            if weather:
                wind = weather.get('wind_speed_kph', weather.get('wind_speed_mps', 'N/A'))
                wind_unit = 'km/h' if 'wind_speed_kph' in weather else 'm/s'
                context += (
                    f"\n\n--- LIVE WEATHER DATA ({weather['source']}) ---\n"
                    f"City: {weather['city']}, {weather['country']}\n"
                    f"Condition: {weather['description']}\n"
                    f"Temp: {weather['temp_c']}°C (Feels like: {weather['feels_like_c']}°C)\n"
                    f"Humidity: {weather['humidity']}%, Wind: {wind} {wind_unit}\n"
                    f"---\n"
                )
            else:
                # If APIs fail, web search will trigger in the next block
                console.print(f"[yellow]⚡ Dedicated weather APIs failed for {city}. Falling back to Web Search...[/]")

    # 2. General Web Search
    if _is_web_search_query(prompt) and not context:
        search_results = _fetch_web_search(prompt)
        if search_results:
            context += search_results
            
    return context


def _get_system_prompt():
    """Build a system prompt with metadata."""
    now = datetime.now()
    return (
        f"You are a helpful AI assistant called BabinCLI. "
        f"Today is {now.strftime('%A, %B %d, %Y')}. The local time is {now.strftime('%I:%M %p')}. "
        f"Provide accurate, concise, and helpful responses in stylized Markdown. "
        f"CRITICAL: Always prioritize using the provided LIVE DATA (Weather or Web Search) over your internal training data. "
        f"If the user asks about current events and you have INJECTED LIVE DATA, use it to ensure your response is up-to-date."
    )


def _enrich_prompt(user_prompt, file_path=None):
    """Enrich the user prompt with live context and file content. Returns (prompt, is_live)."""
    context = _get_enrichment_context(user_prompt)
    is_live = bool(context)
    if file_path:
        context += _read_file_content(file_path)
    return user_prompt + context, is_live


def _is_switch_command(text):
    """Check if user input is a model switch command."""
    return text.lower().strip() in SWITCH_COMMANDS


def _show_model_menu(current_provider, current_model):
    """Display model selection menu. Returns (provider, model) or None if cancelled."""
    console.print("\n[bold cyan]🔄 Available Models:[/]")
    console.print(f"[dim]Current: {current_model} ({current_provider})[/]\n")

    for i, (provider, model) in enumerate(SWITCHABLE_MODELS, 1):
        marker = "  ◀ current" if provider == current_provider and model == current_model else ""
        tag = "[sky_blue1]Gemini[/]" if provider == "gemini" else "[green]Groq[/]"
        console.print(f"  [bold]{i}.[/] {model}  {tag}[dim]{marker}[/]")

    console.print(f"\n  [dim]0. Cancel[/]\n")

    choice = Prompt.ask("[bold yellow]Select model number[/]")
    try:
        idx = int(choice)
        if idx == 0:
            console.print("[dim]Cancelled.[/]")
            return None
        if 1 <= idx <= len(SWITCHABLE_MODELS):
            return SWITCHABLE_MODELS[idx - 1]
    except ValueError:
        pass
    console.print("[yellow]Invalid selection. Continuing with current model.[/]")
    return None


class AliasedGroup(click.Group):
    """Custom Click group that supports short command aliases."""
    ALIASES = {
        'a': 'ask',
        'c': 'chat',
        'h': 'history',
        'history': 'history',
        'lm': 'list-models',
        'models': 'list-models',
        's': 'setup',
    }

    def get_command(self, ctx, cmd_name):
        cmd_name = self.ALIASES.get(cmd_name, cmd_name)
        return super().get_command(ctx, cmd_name)

    def resolve_command(self, ctx, args):
        if args and args[0] in self.ALIASES:
            args[0] = self.ALIASES[args[0]]
        return super().resolve_command(ctx, args)

    def format_usage(self, ctx, formatter):
        super().format_usage(ctx, formatter)

    def format_epilog(self, ctx, formatter):
        formatter.write_paragraph()
        formatter.write_text('Shortcuts:')
        with formatter.indentation():
            formatter.write_text('a      → ask')
            formatter.write_text('c      → chat')
            formatter.write_text('lm     → list-models')
            formatter.write_text('models → list-models')
            formatter.write_text('s      → setup')
            formatter.write_text('-p     → --provider')
            formatter.write_text('-m     → --model')
            formatter.write_text('-f     → --file')
        super().format_epilog(ctx, formatter)


def _get_api_key(provider, silent=False):
    """Retrieve the first API key for the given provider."""
    if provider == "groq":
        keys = _get_groq_keys()
        if not keys and not silent:
            console.print("\n[bold red]Error:[/] GROQ_API_KEY not found.")
            console.print("[dim]You need a Groq API key to use this provider or for automatic fallback.[/]")
            if Confirm.ask("[bold yellow]Would you like to run the setup wizard now?[/]"):
                run_interactive_setup(force=True)
                # Reload env after setup
                load_dotenv(_get_env_path(), override=True)
                keys = _get_groq_keys()
        return keys[0] if keys else None
    elif provider == "nvidia":
        keys = _get_nvidia_keys()
        if not keys and not silent:
            console.print("\n[bold red]Error:[/] NVIDIA_API_KEY not found.")
            if Confirm.ask("[bold yellow]Run setup wizard?[/]"):
                run_interactive_setup(force=True)
                load_dotenv(_get_env_path(), override=True)
                keys = _get_nvidia_keys()
        return keys[0] if keys else None
    elif provider == "github":
        keys = _get_github_keys()
        if not keys and not silent:
            console.print("\n[bold red]Error:[/] GITHUB_TOKEN not found.")
            if Confirm.ask("[bold yellow]Run setup wizard?[/]"):
                run_interactive_setup(force=True)
                load_dotenv(_get_env_path(), override=True)
                keys = _get_github_keys()
        return keys[0] if keys else None
    elif provider == "openrouter":
        keys = _get_openrouter_keys()
        if not keys and not silent:
            console.print("\n[bold red]Error:[/] OPENROUTER_API_KEY not found.")
            if Confirm.ask("[bold yellow]Run setup wizard?[/]"):
                run_interactive_setup(force=True)
                load_dotenv(_get_env_path(), override=True)
                keys = _get_openrouter_keys()
        return keys[0] if keys else None
    else:
        keys = _get_gemini_keys()
        if not keys and not silent:
            console.print("\n[bold red]Error:[/] GEMINI_API_KEY not found.")
            console.print("[dim]You need at least one Gemini API key for the primary AI features.[/]")
            if Confirm.ask("[bold yellow]Would you like to run the setup wizard now?[/]"):
                run_interactive_setup(force=True)
                # Reload env after setup
                load_dotenv(_get_env_path(), override=True)
                keys = _get_gemini_keys()
        return keys[0] if keys else None


def _is_quota_error(error):
    """Check if an error is a rate-limit / quota-exhausted error."""
    msg = str(error)
    return any(kw in msg for kw in ["RESOURCE_EXHAUSTED", "429", "quota", "rate limit", "Rate limit"])


def _is_temporary_rate_limit(error):
    """Check if the error is a per-minute rate limit (retryable) vs daily quota (not retryable)."""
    msg = str(error)
    # If the error says "retryDelay" or "PerMinute", it's a temporary per-minute limit
    if "retryDelay" in msg or "PerMinute" in msg:
        return True
    # If limit is 0, the daily quota is fully exhausted — not retryable
    if "limit: 0" in msg:
        return False
    return False


def _extract_retry_delay(error):
    """Extract the retry delay in seconds from a quota error message."""
    msg = str(error)
    # Look for patterns like "retry in 9.111s" or "retryDelay": "9s"
    match = re.search(r'retry\s*(?:in|Delay["\s:]*)\s*["\']?(\d+(?:\.\d+)?)\s*s', msg, re.IGNORECASE)
    if match:
        return min(float(match.group(1)) + 1, 30)  # add 1s buffer, cap at 30s
    return 10  # default 10s


def _get_fallback_provider(current_provider):
    """Return the other provider as fallback."""
    return "groq" if current_provider == "gemini" else "gemini"


@click.group(cls=AliasedGroup)
@click.option('-p', '--provider', type=click.Choice(['gemini', 'groq', 'nvidia', 'github'], case_sensitive=False), default='groq', help='AI provider to use.')
@click.option('-m', '--model', default=None, help='AI model to use. Defaults depend on the provider.')
@click.option('-f', '--file', type=click.Path(exists=True), help='Path to a local file to use as context.')
@click.pass_context
def cli(ctx, provider, model, file):
    """BabinCLI: Your Advanced AI-Powered Terminal Assistant (Multi-Provider)."""
    ctx.ensure_object(dict)
    provider = provider.lower()
    ctx.obj['PROVIDER'] = provider
    ctx.obj['MODEL'] = model or DEFAULT_MODELS[provider]
    ctx.obj['FILE'] = file

    # Auto-trigger setup on first run if no API keys are configured
    # Skip if user is running 'setup', 'setup-path', or '--help'
    invoked = ctx.invoked_subcommand
    if invoked not in ('setup', 'setup-path', None) and not _env_has_keys():
        console.print("[bold yellow]No API keys found. Starting first-time setup...[/]\n")
        run_interactive_setup(force=False)
        # Reload env after setup
        load_dotenv(_get_env_path(), override=True)


@cli.command()
def history():
    """List or view past chat sessions saved in history."""
    if not os.path.exists(HISTORY_DIR) or not os.listdir(HISTORY_DIR):
        console.print("[yellow]No chat history found.[/]")
        return
    
    files = sorted(os.listdir(HISTORY_DIR), reverse=True)
    recent_files: List[str] = files[:10]
    console.print("[bold cyan]Recent Chat History:[/]")
    for i, f in enumerate(recent_files, 1):
        console.print(f" {i}. [sky_blue1]{f}[/]")
    
    choice = Prompt.ask("\nEnter number to view (or 0 to cancel)", default="0")
    if choice.isdigit():
        idx = int(choice)
        if 0 < idx <= len(files):
            path = os.path.join(HISTORY_DIR, files[idx-1])
            with open(path, "r", encoding="utf-8") as file:
                console.print(Panel(Markdown(file.read()), title=f"[bold]{files[idx-1]}", border_style="blue"))


@cli.command(name='setup-path')
def setup_path():
    """(Windows) Add Python Scripts directory to PATH so 'babin' works everywhere."""
    if sys.platform != "win32":
        console.print("[yellow]This command is only needed on Windows.[/]")
        return
    result = ensure_windows_path()
    if result:
        console.print(f"[bold green]✅ Added to PATH:[/] {result}")
        console.print("[dim]Open a new terminal window for the change to take effect.[/]")
    else:
        console.print("[bold green]✅ PATH already configured.[/]")


@cli.command(name='setup')
def setup_keys():
    """Configure API keys interactively (Gemini, Groq, Weather)."""
    run_interactive_setup(force=True)


@cli.command()
@click.pass_context
def list_models(ctx):
    """List available AI models (verified & recommended first)."""
    provider = ctx.obj['PROVIDER']

    # Curated sets of recommended highly-performant models
    RECOMMENDED = {
        "groq": ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768"],
        "gemini": ["gemini-2.5-flash", "gemini-1.5-flash"],
        "nvidia": ["meta/llama-3.1-8b-instruct", "meta/llama-3.1-70b-instruct", "nvidia/nemotron-70b-instruct"],
        "github": ["gpt-5-nano", "gpt-4o-mini", "phi-3.5-mini-instruct"],
    }

    if provider == "groq":
        api_key = _get_api_key("groq")
        if not api_key: return
        try:
            client = Groq(api_key=api_key)
            models = client.models.list()
            console.print("[bold cyan]🔥 Recommended Groq Models:[/]")
            for m in RECOMMENDED["groq"]:
                console.print(f" • [bold green]{m}[/]")
            
            console.print("\n[dim]All Available Models:[/]")
            for m in models.data:
                if m.id not in RECOMMENDED["groq"]:
                    console.print(f" - {m.id}")
        except Exception as e:
            console.print(f"[bold red]Error listing Groq models:[/] {e}")
    elif provider in ("nvidia", "github", "openrouter"):
        api_key = _get_api_key(provider)
        if not api_key: return
        try:
            base_url = {
                "nvidia": "https://integrate.api.nvidia.com/v1",
                "github": "https://models.inference.ai.azure.com",
                "openrouter": "https://openrouter.ai/api/v1",
            }[provider]
            client = OpenAI(api_key=api_key, base_url=base_url)
            models = client.models.list()
            
            console.print(f"[bold cyan]🔥 Recommended {provider.title()} Models:[/]")
            for m in RECOMMENDED.get(provider, []):
                console.print(f" • [bold green]{m}[/]")
            
            console.print("\n[dim]Other Available Models:[/]")
            for m in models.data:
                if m.id not in RECOMMENDED.get(provider, []):
                    console.print(f" - {m.id}")
        except Exception as e:
            console.print(f"[bold red]Error listing {provider} models:[/] {e}")
    else:
        api_key = _get_api_key("gemini")
        if not api_key: return
        try:
            client = genai.Client(api_key=api_key)
            # Fetch all and filter client-side to be safe
            all_models = [m.name.replace("models/", "") for m in client.models.list()]
            
            console.print("[bold cyan]🔥 Recommended Gemini Models:[/]")
            for rec in RECOMMENDED["gemini"]:
                # Check fuzzy match or exact match to verify access
                if any(rec in m for m in all_models):
                     console.print(f" • [bold green]{rec}[/]")
            
            console.print("\n[dim]Other Available Models:[/]")
            for m in all_models:
                if not any(rec in m for rec in RECOMMENDED["gemini"]):
                    console.print(f" - {m}")
        except Exception as e:
            console.print(f"[bold red]Error listing Gemini models:[/] {e}")


# ---------------------------------------------------------------------------
#  Gemini smart retry & model fallback
# ---------------------------------------------------------------------------

def _gemini_chat_send_with_retry(chat_session, model_name, user_input, file_path=None):
    """Send a chat message with auto-retry and streaming output."""
    enriched_input, is_live = _enrich_prompt(user_input, file_path)
    for attempt in range(MAX_RETRIES + 1):
        try:
            status_msg = f"[bold blue]🧠 Thinking (attempt {attempt+1})..."
            console.print(status_msg)
            
            full_text = ""
            title = _get_response_title(model_name, is_live)
            with Live(Panel("", title=title, border_style="bright_magenta"), console=console, refresh_per_second=10) as live:
                responses = chat_session.send_message_stream(enriched_input)
                for chunk in responses:
                    chunk_text = (chunk.text or "")
                    for char in chunk_text:
                        full_text += char
                        live.update(Panel(Markdown(full_text), title=title, border_style="bright_magenta"))
                        time.sleep(0.005) # Typewriter effect
            
            return full_text
        except Exception as e:
            if not _is_quota_error(e): raise
            if _is_temporary_rate_limit(e) and attempt < MAX_RETRIES:
                delay = _extract_retry_delay(e)
                console.print(f"[yellow]⏳ Rate limited. Retrying in {delay:.0f}s...[/]")
                time.sleep(delay)
                continue
            raise


def _get_response_title(model_name, is_live=False):
    """Determine the panel title based on context."""
    if is_live:
        return "[bold sky_blue1]Babin Assistant"
    return f"[bold cyan]Response ({model_name})"


# ---------------------------------------------------------------------------
#  Ask command
# ---------------------------------------------------------------------------

@cli.command()
@click.argument('prompt')
@click.pass_context
def ask(ctx, prompt):
    """Ask a single question and get a formatted response."""
    provider = ctx.obj['PROVIDER']
    model_name = ctx.obj['MODEL']
    file = ctx.obj.get('FILE')
    api_key = _get_api_key(provider)
    if not api_key:
        return

    enriched_prompt, is_live = _enrich_prompt(prompt, file)
    
    try:
        if provider == "groq":
            _ask_groq(api_key, model_name, prompt, file)
        elif provider in ("nvidia", "github", "openrouter"):
            base_url = {
                "nvidia": "https://integrate.api.nvidia.com/v1",
                "github": "https://models.inference.ai.azure.com",
                "openrouter": "https://openrouter.ai/api/v1",
            }[provider]
            _ask_openai_compatible(api_key, base_url, model_name, prompt, file)
        else:
            # Smart Gemini: retry + model fallback chain
            text, used_model = _gemini_generate_with_retry(api_key, model_name, prompt, file)
    except Exception as e:
        if _is_quota_error(e):
            _handle_fallback_ask(provider, model_name, prompt, e, file)
        else:
            console.print(f"[bold red]Error:[/] {e}")


def _gemini_generate_with_retry(api_key, model_name, prompt, file_path=None):
    """Try generating content with auto-retry, multi-key rotation, and streaming."""
    enriched_prompt, is_live = _enrich_prompt(prompt, file_path)
    all_keys = _get_gemini_keys() or [api_key]

    if api_key in all_keys:
        ordered_keys = [api_key] + [k for k in all_keys if k != api_key]
    else:
        ordered_keys = [api_key] + all_keys

    models_to_try = [model_name] + [m for m in GEMINI_FALLBACK_CHAIN if m != model_name]

    last_error: Optional[Exception] = None
    for key_idx, key in enumerate(ordered_keys):
        client = genai.Client(api_key=key)
        if key_idx > 0:
            console.print(f"[yellow]🔑 Switching to Gemini API key #{key_idx + 1}...[/]")

        for model in models_to_try:
            for attempt in range(MAX_RETRIES + 1):
                try:
                    console.print(f"[bold blue]🔍 Querying {model}..." + (f" (retry {attempt})" if attempt else "") + "[/]")
                    
                    title = _get_response_title(model, is_live)
                    full_text = ""
                    with Live(Panel("", title=title, border_style="green"), console=console, refresh_per_second=10) as live:
                        responses = client.models.generate_content_stream(
                            model=model,
                            contents=enriched_prompt,
                            config=types.GenerateContentConfig(
                                system_instruction=_get_system_prompt(),
                            )
                        )
                        for chunk in responses:
                            chunk_text = (chunk.text or "")
                            for char in chunk_text:
                                full_text += char
                                live.update(Panel(Markdown(full_text), title=title, border_style="green"))
                                time.sleep(0.005)
                    
                    return full_text, model
                except Exception as e:
                    last_error = e
                    if not _is_quota_error(e): raise
                    if _is_temporary_rate_limit(e) and attempt < MAX_RETRIES:
                        delay = _extract_retry_delay(e)
                        console.print(f"[yellow]⏳ Rate limited on {model}. Retrying in {delay:.0f}s...[/]")
                        time.sleep(delay)
                        continue
                    console.print(f"[yellow]⚡ {model} quota exhausted, trying next...[/]")
                    break
    if last_error is not None:
        raise last_error
    raise Exception("All models exhausted without error captured.")


def _ask_groq(api_key, model_name, prompt, file_path=None):
    """Handle a single question using Groq with streaming (raises on error)."""
    enriched_prompt, is_live = _enrich_prompt(prompt, file_path)
    client = Groq(api_key=api_key)
    
    console.print(f"[bold blue]⚡ Querying {model_name}...[/]")
    
    stream = client.chat.completions.create(
        model=model_name,
        messages=[
            {"role": "system", "content": _get_system_prompt()},
            {"role": "user", "content": enriched_prompt},
        ],
        stream=True
    )
    
    title = _get_response_title(model_name, is_live)
    full_reply = ""
    with Live(Panel("", title=title, border_style="green"), console=console, refresh_per_second=10) as live:
        for chunk in stream:
            if chunk.choices[0].delta.content:
                chunk_text = chunk.choices[0].delta.content
                for char in chunk_text:
                    full_reply += char
                    live.update(Panel(Markdown(full_reply), title=title, border_style="green"))
                    time.sleep(0.005)
    return full_reply


def _ask_openai_compatible(api_key, base_url, model_name, prompt, file_path=None):
    """Handle a single question using an OpenAI-compatible provider."""
    enriched_prompt, is_live = _enrich_prompt(prompt, file_path)
    client = OpenAI(api_key=api_key, base_url=base_url)
    
    console.print(f"[bold blue]🌐 Querying {model_name}...")
    
    stream = client.chat.completions.create(
        model=model_name,
        messages=[
            {"role": "system", "content": _get_system_prompt()},
            {"role": "user", "content": enriched_prompt},
        ],
        stream=True
    )
    
    title = _get_response_title(model_name, is_live)
    full_reply = ""
    with Live(Panel("", title=title, border_style="green"), console=console, refresh_per_second=10) as live:
        for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content:
                chunk_text = chunk.choices[0].delta.content
                for char in chunk_text:
                    full_reply += char
                    live.update(Panel(Markdown(full_reply), title=title, border_style="green"))
                    time.sleep(0.005)
    return full_reply


def _handle_fallback_ask(failed_provider, failed_model, prompt, original_error, file_path=None):
    """Attempt to fall back to the other provider for a single ask."""
    fallback = _get_fallback_provider(failed_provider)
    fallback_key = _get_api_key(fallback, silent=True)

    if not fallback_key:
        console.print(Panel(
            f"[bold red]Error:[/] All {failed_provider.title()} models quota exhausted.\n\n"
            f"[yellow]{fallback.upper()}_API_KEY is not set. Set it to enable automatic fallback:[/]\n"
            f"  [cyan]$env:{fallback.upper()}_API_KEY=\"your_key\"[/]",
            title="All Providers Exhausted — No Fallback Available"
        ))
        return

    fallback_model = DEFAULT_MODELS[fallback]
    console.print(f"\n[bold yellow]⚡ {failed_provider.title()} service unavailable or quota exhausted. Falling back to {fallback.title()} ({fallback_model})...[/]\n")

    try:
        if fallback == "groq":
            _ask_groq(fallback_key, fallback_model, prompt, file_path)
        else:
            _gemini_generate_with_retry(fallback_key, fallback_model, prompt, file_path)
    except Exception as fallback_err:
        console.print(f"[bold red]Fallback also failed:[/] {fallback_err}")


# ---------------------------------------------------------------------------
#  Chat command
# ---------------------------------------------------------------------------

@cli.command()
@click.pass_context
def chat(ctx):
    """Start an interactive chat session with history."""
    provider = ctx.obj['PROVIDER']
    model_name = ctx.obj['MODEL']
    file = ctx.obj.get('FILE')

    console.print(Panel(
        "[bold sky_blue1]BabinCLI Interactive Assistant[/]\n"
        "Your terminal, now powered by advanced AI.\n\n"
        "• Type [bold yellow]'exit'[/] or [bold yellow]'quit'[/] to end\n"
        "• Type [bold yellow]'switch'[/] to change models mid-chat\n"
        "• [bold red]NOTE:[/] Session history is saved [italic]after[/] termination\n\n"
        "[dim]To view history, you must terminate the current session first.[/]",
        border_style="bright_blue",
        title="[bold]Chat Active",
        subtitle="[dim]Powered by Gemini & Groq",
        padding=(1, 2)
    ))

    while True:
        api_key = _get_api_key(provider)
        if not api_key:
            return

        # Modern status bar instead of just text
        console.print(Rule(f"[bold white]{provider.upper()}[/] | [cyan]{model_name}[/]", style="blue"))
        console.print()

        try:
            if provider == "groq":
                _chat_groq(api_key, model_name, ctx.obj.get('FILE'))
            elif provider in ("nvidia", "github", "openrouter"):
                base_url = {
                    "nvidia": "https://integrate.api.nvidia.com/v1",
                    "github": "https://models.inference.ai.azure.com",
                    "openrouter": "https://openrouter.ai/api/v1",
                }[provider]
                _chat_openai_compatible(api_key, base_url, provider, model_name, ctx.obj.get('FILE'))
            else:
                _chat_gemini(api_key, model_name, ctx.obj.get('FILE'))
            break  # Normal exit (user typed quit/exit)
        except ModelSwitchRequest as switch:
            provider = switch.provider
            model_name = switch.model
            switch_key = _get_api_key(provider, silent=True)
            if not switch_key:
                console.print(f"[bold red]Error:[/] {provider.upper()}_API_KEY not set. Cannot switch.")
                provider = ctx.obj['PROVIDER']
                model_name = ctx.obj['MODEL']
                continue
            console.print(f"\n[bold green]✅ Switched to {model_name} ({provider})[/]\n")


def _chat_gemini(api_key, model_name, file_path=None):
    """Run an interactive chat loop using Google Gemini with retry + model fallback."""
    try:
        client = genai.Client(api_key=api_key)
        chat_session = client.chats.create(
            model=model_name,
            config=types.GenerateContentConfig(
                system_instruction=_get_system_prompt(),
            ),
        )
    except Exception as e:
        if _is_quota_error(e):
            if not _try_alt_gemini_chat(api_key, model_name, file_path):
                _handle_fallback_chat("gemini", model_name, e)
        else:
            console.print(Panel(f"[bold red]Error:[/] {e}", title="Model Access Error"))
        return

    _run_gemini_chat_loop(chat_session, model_name, api_key, file_path)


def _try_alt_gemini_chat(api_key, current_model, file_path=None):
    """Try starting a chat with an alternative Gemini model."""
    alt_models = [m for m in GEMINI_FALLBACK_CHAIN if m != current_model]
    client = genai.Client(api_key=api_key)

    for alt_model in alt_models:
        try:
            console.print(f"[yellow]⚡ {current_model} quota exhausted. Trying {alt_model}...[/]")
            chat_session = client.chats.create(
                model=alt_model,
                config=types.GenerateContentConfig(
                    system_instruction=_get_system_prompt(),
                ),
            )
            console.print(f"[green]✓ Switched to {alt_model}[/]\n")
            _run_gemini_chat_loop(chat_session, alt_model, api_key, file_path)
            return True
        except ModelSwitchRequest:
            raise
        except Exception as e:
            if _is_quota_error(e): continue
            console.print(f"[bold red]Error with {alt_model}:[/] {e}")
            break
    return False


def _run_gemini_chat_loop(chat_session, model_name, api_key, file_path=None):
    """Core Gemini chat loop with streaming and history."""
    history_for_saving = []
    try:
        while True:
            user_input = Prompt.ask("[bold sky_blue1]❯ You[/]")
            if user_input.lower() in ["exit", "quit", ""]:
                if user_input.lower() != "":
                    console.print("[bold bright_magenta]👋 Goodbye! Saving history...[/]")
                    _save_chat_history(history_for_saving, "gemini", model_name)
                    break
                continue

            if _is_switch_command(user_input):
                result = _show_model_menu("gemini", model_name)
                if result:
                    _save_chat_history(history_for_saving, "gemini", model_name)
                    raise ModelSwitchRequest(*result)
                continue

            try:
                # File context only on the first message
                current_file = file_path if not history_for_saving else None
                text = _gemini_chat_send_with_retry(chat_session, model_name, user_input, current_file)
                
                history_for_saving.append({"role": "user", "content": user_input})
                history_for_saving.append({"role": "assistant", "content": text})
            except Exception as e:
                if _is_quota_error(e):
                    if _try_alt_gemini_chat(api_key, model_name, file_path):
                        return
                    _save_chat_history(history_for_saving, "gemini", model_name)
                    _handle_fallback_chat("gemini", model_name, e)
                    return
                else:
                    console.print(f"[bold red]Error:[/] {e}")
    except KeyboardInterrupt:
        _save_chat_history(history_for_saving, "gemini", model_name)
        console.print("\n[bold bright_magenta]👋 Session saved. Goodbye![/]")


def _chat_groq(api_key, model_name, file_path=None):
    """Run an interactive chat loop using Groq with auto-fallback and streaming."""
    try:
        client = Groq(api_key=api_key)
        history = [{"role": "system", "content": _get_system_prompt()}]
    except Exception as e:
        if _is_quota_error(e):
            _handle_fallback_chat("groq", model_name, e)
        else:
            console.print(Panel(f"[bold red]Error:[/] {e}", title="Model Access Error"))
        return

    try:
        while True:
            user_input = Prompt.ask("[bold sky_blue1]❯ You[/]")
            if user_input.lower() in ["exit", "quit", ""]:
                if user_input.lower() != "":
                    console.print("[bold bright_magenta]👋 Goodbye! Saving history and ending session...[/]")
                    _save_chat_history(history, "groq", model_name)
                    break
                continue

            if _is_switch_command(user_input):
                result = _show_model_menu("groq", model_name)
                if result:
                    _save_chat_history(history, "groq", model_name)
                    raise ModelSwitchRequest(*result)
                continue

            # Enrich the first message with file context if provided
            enriched_input, is_live = _enrich_prompt(user_input, file_path if len(history) == 1 else None)
            history.append({"role": "user", "content": enriched_input})

            try:
                console.print("[bold blue]🤖 Thinking...[/]")
                stream = client.chat.completions.create(
                    model=model_name,
                    messages=history,
                    stream=True
                )
                
                full_reply: str = ""
                title = _get_response_title(model_name, is_live)
                with Live(Panel("", title=title, border_style="bright_magenta"), console=console, refresh_per_second=10) as live:
                    for chunk in stream:
                        delta = chunk.choices[0].delta
                        if delta and delta.content:
                            chunk_text = str(delta.content)
                            for char in chunk_text:
                                full_reply += char
                                live.update(Panel(Markdown(full_reply), title=title, border_style="bright_magenta"))
                                time.sleep(0.005)
                
                history.append({"role": "assistant", "content": full_reply})
            except Exception as e:
                if _is_quota_error(e):
                    console.print(f"\n[bold yellow]⚡ Groq quota hit. Switching...[/]\n")
                    _save_chat_history(history, "groq", model_name)
                    _handle_fallback_chat("groq", model_name, e)
                    return
                else:
                    console.print(f"[bold red]Error:[/] {e}")
    except KeyboardInterrupt:
        _save_chat_history(history, "groq", model_name)
        console.print("\n[bold bright_magenta]👋 Session saved. Goodbye![/]")


def _handle_fallback_chat(failed_provider, failed_model, original_error):
    """Attempt to start a chat session on the other provider (last resort)."""
    fallback = _get_fallback_provider(failed_provider)
    fallback_key = _get_api_key(fallback, silent=True)

    if not fallback_key:
        console.print(Panel(
            f"[bold red]Error:[/] All models exhausted.\n\n"
            f"[yellow]{fallback.upper()}_API_KEY is not set. Set it to enable automatic fallback:[/]\n"
            f"  [cyan]$env:{fallback.upper()}_API_KEY=\"your_key\"[/]",
            title="All Quotas Exceeded — No Fallback Available"
        ))
        return

    fallback_model = DEFAULT_MODELS[fallback]
    console.print(f"[bold yellow]⚡ Last resort: switching to {fallback.title()} ({fallback_model})...[/]\n")

    if fallback == "groq":
        _chat_groq(fallback_key, fallback_model)
    elif fallback in ("nvidia", "github", "openrouter"):
        base_url = {
            "nvidia": "https://integrate.api.nvidia.com/v1",
            "github": "https://models.inference.ai.azure.com",
            "openrouter": "https://openrouter.ai/api/v1",
        }[fallback]
        _chat_openai_compatible(fallback_key, base_url, fallback, fallback_model)
    else:
        _chat_gemini(fallback_key, fallback_model)


def _chat_openai_compatible(api_key, base_url, provider, model_name, file_path=None):
    """Run an interactive chat loop using an OpenAI-compatible provider."""
    try:
        client = OpenAI(api_key=api_key, base_url=base_url)
        history = [{"role": "system", "content": _get_system_prompt()}]
    except Exception as e:
        console.print(Panel(f"[bold red]Error:[/] {e}", title="Model Access Error"))
        return

    try:
        while True:
            user_input = Prompt.ask("[bold sky_blue1]❯ You[/]")
            if user_input.lower() in ["exit", "quit", ""]:
                if user_input.lower() != "":
                    console.print("[bold bright_magenta]👋 Goodbye! Saving history and ending session...[/]")
                    _save_chat_history(history, provider, model_name)
                    break
                continue

            if _is_switch_command(user_input):
                result = _show_model_menu(provider, model_name)
                if result:
                    _save_chat_history(history, provider, model_name)
                    raise ModelSwitchRequest(*result)
                continue

            enriched_input, is_live = _enrich_prompt(user_input, file_path if len(history) == 1 else None)
            history.append({"role": "user", "content": enriched_input})

            try:
                console.print("[bold blue]✨ Thinking...[/]")
                stream = client.chat.completions.create(
                    model=model_name,
                    messages=history,
                    stream=True
                )
                
                full_reply: str = ""
                title = _get_response_title(model_name, is_live)
                with Live(Panel("", title=title, border_style="bright_magenta"), console=console, refresh_per_second=10) as live:
                    for chunk in stream:
                        if chunk.choices and chunk.choices[0].delta.content:
                            chunk_text = str(chunk.choices[0].delta.content)
                            for char in chunk_text:
                                full_reply += char
                                live.update(Panel(Markdown(full_reply), title=title, border_style="bright_magenta"))
                                time.sleep(0.005)
                
                history.append({"role": "assistant", "content": full_reply})
            except Exception as e:
                console.print(f"[bold red]Error:[/] {e}")
                # Optional: Handle rate limits or other Provider-specific errors here
    except KeyboardInterrupt:
        _save_chat_history(history, provider, model_name)
        console.print(f"\n[bold bright_magenta]👋 Session saved ({provider}). Goodbye![/]")


if __name__ == '__main__':
    cli()
