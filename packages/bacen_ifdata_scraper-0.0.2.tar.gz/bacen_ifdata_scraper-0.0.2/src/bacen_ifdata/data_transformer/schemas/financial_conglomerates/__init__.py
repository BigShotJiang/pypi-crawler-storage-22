#!/usr/bin/env python
# encoding: utf-8
#
#  ------------------------------------------------------------------------------
#  Name: __init__.py
#  Version: 0.0.1
#  Summary: Bacen IF.data AutoScraper & Data Manager
#           Este sistema foi projetado para automatizar o download dos
#           relatórios da ferramenta IF.data do Banco Central do Brasil.
#           Criado para facilitar a integração com ferramentas automatizadas de
#           análise e visualização de dados, garantido acesso fácil e oportuno
#           aos dados.
#
#  Author: Alexsander Lopes Camargos
#  Author-email: alcamargos@vivaldi.net
#
#  License: MIT
#  ------------------------------------------------------------------------------

"""
Bacen IF.data AutoScraper & Data Manager

This script is designed to automate the download of reports from the Banco Central do Brasil's
IF.data tool. It facilitates the integration with automated data analysis and visualization tools,
ensuring easy and timely access to data.

Author: Alexsander Lopes Camargos
License: MIT
"""

from bacen_ifdata.data_transformer.schemas.financial_conglomerates.assets import FinancialConglomeratesAssetsSchema
from bacen_ifdata.data_transformer.schemas.financial_conglomerates.income_statement import (
    FinancialConglomerateIncomeStatementSchema,
)
from bacen_ifdata.data_transformer.schemas.financial_conglomerates.liabilities import (
    FinancialConglomerateLiabilitiesSchema,
)
from bacen_ifdata.data_transformer.schemas.financial_conglomerates.summary import FinancialConglomerateSummarySchema

# Instance a schema for report summary of financial conglomerates.
FINANCIAL_CONGLOMERATE_SUMMARY_SCHEMA = FinancialConglomerateSummarySchema()

# Instance a schema for report assets of financial conglomerates.
FINANCIAL_CONGLOMERATE_ASSETS_SCHEMA = FinancialConglomeratesAssetsSchema()

# Instance a schema for report liabilities of financial conglomerates.
FINANCIAL_CONGLOMERATE_LIABILITIES_SCHEMA = FinancialConglomerateLiabilitiesSchema()

# Instance a schema for report income statement of financial conglomerates.
FINANCIAL_CONGLOMERATE_INCOME_STATEMENT_SCHEMA = FinancialConglomerateIncomeStatementSchema()


__all__ = [
    'FINANCIAL_CONGLOMERATE_SUMMARY_SCHEMA',
    'FINANCIAL_CONGLOMERATE_ASSETS_SCHEMA',
    'FINANCIAL_CONGLOMERATE_LIABILITIES_SCHEMA',
    'FINANCIAL_CONGLOMERATE_INCOME_STATEMENT_SCHEMA',
]
