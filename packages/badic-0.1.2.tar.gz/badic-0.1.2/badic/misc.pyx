# coding=utf8
"""
Miscellanious


AUTHORS:

- Paul Mercat (2013)- I2M AMU Aix-Marseille Universite - initial version

REFERENCES:

"""

# *****************************************************************************
#	   Copyright (C) 2014 Paul Mercat <paul.mercat@univ-amu.fr>
#
#  Distributed under the terms of the GNU General Public License (GPL)
#
#	This code is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#	General Public License for more details.
#
#  The full text of the GPL is available at:
#
#				  http://www.gnu.org/licenses/
# *****************************************************************************
from __future__ import division, print_function, absolute_import

from libc.stdlib cimport malloc, free
from libc.stdint cimport int8_t

from cpython cimport bool as c_bool
from cysignals.signals cimport sig_on, sig_off, sig_check

from .cautomata cimport DetAutomaton, CAutomaton

from sage.structure.element import Matrix

cdef extern from "Automaton.h":
	cdef struct State:
		int* f
		int final

	cdef struct Automaton:
		State* e  # states
		int n   # number of states
		int na  # number of letters
		int i  # initial state

	cdef struct Transition:
		int l  # label
		int e  # arrival state

	cdef struct NState:
		Transition* a
		int n
		int final
		int initial

	cdef struct NAutomaton:
		NState* e  # states
		int n   # number of states
		int na  # number of letters

cdef extern from "automataC.h":
	NAutomaton CopyN(Automaton a, int verb)

def set_dark_mode(v = 1):
	"""
	Set the dark mode.
	
		- 0 : normal mode
		- 1 : dark mode
		- 2 : transparent mode
	
	INPUT:
		- ``v`` - int -- the value to set
	"""
	with open("dark_mode", "w") as f:
		f.write(str(v))
	import matplotlib.pyplot as plt
	if v == 1:
		plt.style.use('dark_background')
	elif v == 0:
		plt.style.use('default')

def is_dark_mode():
	"""
	Get the dark mode.
	
		- 0 : normal mode
		- 1 : dark mode
	"""
	try:
		with open("dark_mode", "r") as f:
			return int(f.read())
	except:
		return 0

def is_Matrix(m):
	"""
	Test if m is a matrix.
	"""
	return isinstance(m, Matrix)

