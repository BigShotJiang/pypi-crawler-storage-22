"""
Minimal setup.py for handling Cython extensions with custom build configuration.
The project metadata is now defined in pyproject.toml.
"""

from setuptools import setup
from setuptools.extension import Extension
from distutils.command.build_ext import build_ext as _build_ext
import sys
import os
import numpy as np


class build_ext(_build_ext):
    def finalize_options(self):
        import subprocess
        from Cython.Build import cythonize
        import json

        # Run the configure script
        subprocess.check_call(["make", "configure"])
        try:
            subprocess.check_call(["sh", "./configure"])
        except subprocess.CalledProcessError:
            subprocess.check_call(["cat", "config.log"])

        # Read config.json created by configure
        config = json.load(open("./config.json"))
        HAVE_SDL2 = config['HAVE_SDL2']

        for mod in self.distribution.ext_modules:
            mod.define_macros.append(('SDL_PRESENT', int(HAVE_SDL2)))
            mod.define_macros.append(('SDL_IMAGE_PRESENT', int(HAVE_SDL2)))
            if HAVE_SDL2:
                mod.libraries.append('SDL2')

        self.distribution.ext_modules[:] = cythonize(
            self.distribution.ext_modules, include_path=sys.path)
        _build_ext.finalize_options(self)


extensions = [
    Extension(
        "badic.density",
        sources=['badic/density.pyx']
    ),
    Extension(
        "badic.cautomata",
        sources=['badic/cautomata.pyx', 'badic/automataC.c']
    ),
    Extension(
        "badic.misc",
        sources=['badic/misc.pyx', 'badic/miscellanious.c', 'badic/automataC.c']
    ),
    Extension(
        "badic.beta_adic",
        sources=[
            'badic/beta_adic.pyx',
            'badic/complexe.c',
            'badic/draw.c',
            'badic/relations.c',
            'badic/automataC.c'
        ],
        include_dirs=[np.get_include()]
    ),
    Extension(
        "badic.turing",
        sources=['badic/turing.pyx', 'badic/miscellanious.c', 'badic/automataC.c'],
        include_dirs=[np.get_include()]
    ),
]

setup(
    ext_modules=extensions,
    cmdclass={'build_ext': build_ext}
)
