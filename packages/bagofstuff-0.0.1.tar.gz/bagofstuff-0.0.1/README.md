# bagofstuff

## Introduction

Just a library of things to tinker with.

[//]: # (README.md ends here)
