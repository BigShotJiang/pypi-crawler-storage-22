﻿"""MemGPT/LeTTA adapter stub."""

class MemGPTAdapter:
    def __init__(self) -> None:
        raise NotImplementedError("MemGPT adapter is not implemented yet.")
