﻿"""memU adapter stub."""

class MemUAdapter:
    def __init__(self) -> None:
        raise NotImplementedError("memU adapter is not implemented yet.")
