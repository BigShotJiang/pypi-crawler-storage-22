﻿"""ReMe adapter stub."""

class ReMeAdapter:
    def __init__(self) -> None:
        raise NotImplementedError("ReMe adapter is not implemented yet.")
