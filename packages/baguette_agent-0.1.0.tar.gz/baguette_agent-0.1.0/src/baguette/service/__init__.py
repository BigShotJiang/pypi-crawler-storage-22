"""Storage service for Baguette."""
