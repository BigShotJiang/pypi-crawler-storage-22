﻿"""Storage backends for Baguette."""
