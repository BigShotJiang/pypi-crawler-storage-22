"""Tests for BalaganAgent."""
