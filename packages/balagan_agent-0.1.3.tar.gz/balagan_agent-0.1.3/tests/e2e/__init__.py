"""End-to-end integration tests for agent wrappers."""
