"""
Core functionality for balancing chemical equations.
"""

from __future__ import annotations

from itertools import combinations
from fractions import Fraction
from math import gcd
from functools import reduce

import numpy as np
from pymatgen.core import Composition

def _gcd_list(nums):
    nums = [abs(int(x)) for x in nums if int(x) != 0]
    return reduce(gcd, nums) if nums else 1

def _lcm(a: int, b: int) -> int:
    return abs(a * b) // gcd(a, b) if a and b else 0

def _lcm_list(nums):
    nums = [abs(int(n)) for n in nums if int(n) != 0]
    return reduce(_lcm, nums, 1) if nums else 1

def _comp_to_frac_map(formula: str) -> dict[str, Fraction]:
    d = Composition(formula).get_el_amt_dict()
    return {el: Fraction(str(amt)) for el, amt in d.items()}

def _rref_fraction(A: list[list[Fraction]]):
    R = [row[:] for row in A]
    m = len(R)
    n = len(R[0]) if m else 0
    pivots = []
    r = 0
    for c in range(n):
        pivot_row = None
        for i in range(r, m):
            if R[i][c] != 0:
                pivot_row = i
                break
        if pivot_row is None:
            continue
        if pivot_row != r:
            R[r], R[pivot_row] = R[pivot_row], R[r]

        pv = R[r][c]
        if pv != 1:
            inv = Fraction(1, 1) / pv
            R[r] = [x * inv for x in R[r]]

        for i in range(m):
            if i != r and R[i][c] != 0:
                f = R[i][c]
                R[i] = [R[i][j] - f * R[r][j] for j in range(n)]

        pivots.append(c)
        r += 1
        if r == m:
            break
    return R, pivots

def _nullspace_one_vector_fraction(A: list[list[Fraction]]):
    R, pivots = _rref_fraction(A)
    m = len(R)
    n = len(R[0]) if m else 0
    pivot_set = set(pivots)
    free_cols = [j for j in range(n) if j not in pivot_set]
    if not free_cols:
        return None

    free_choice = free_cols[0]
    x = [Fraction(0, 1) for _ in range(n)]
    x[free_choice] = Fraction(1, 1)

    for i, pc in enumerate(pivots):
        s = Fraction(0, 1)
        for j in free_cols:
            if R[i][j] != 0 and x[j] != 0:
                s += R[i][j] * x[j]
        x[pc] = -s

    if all(v == 0 for v in x):
        return None
    return x

def _frac_vec_to_min_int(vec: list[Fraction]) -> list[int]:
    denoms = [v.denominator for v in vec if v != 0]
    L = _lcm_list(denoms) if denoms else 1
    ints = [int(v * L) for v in vec]
    g = _gcd_list(ints)
    return [x // g for x in ints]

def balance_rxns(
    reactants,
    product_pool,
    *,
    max_products: int | None = None,
    require_all_reactants: bool = True,
    rank_tol: float = 1e-12,   # numpy rank阈值（仅用于预筛）
):
    """
    NumPy做快速预筛（秩判定） + Fraction做精确解。
    返回：
      [ equation_str, {reactant:coef...}, {product:coef...} ]
    """
    reactants = list(reactants)
    product_pool = list(product_pool)

    # 解析
    r_maps = [_comp_to_frac_map(f) for f in reactants]
    p_maps = [_comp_to_frac_map(f) for f in product_pool]

    r_elems = set().union(*(m.keys() for m in r_maps))
    p_ok = [set(m.keys()).issubset(r_elems) for m in p_maps]

    elements = sorted(r_elems)
    eidx = {e: i for i, e in enumerate(elements)}
    m = len(elements)

    # 预先列向量：一份 Fraction（用于精确），一份 float（用于numpy预筛）
    def make_cols(elmap, sign):
        col_f = [Fraction(0, 1) for _ in range(m)]
        col_x = np.zeros(m, dtype=float)
        for el, amt in elmap.items():
            i = eidx[el]
            col_f[i] = sign * amt
            col_x[i] = float(sign * amt)
        return col_f, col_x

    r_cols_f, r_cols_x = [], []
    for em in r_maps:
        cf, cx = make_cols(em, -1)
        r_cols_f.append(cf); r_cols_x.append(cx)

    p_cols_f, p_cols_x = [], []
    for em in p_maps:
        cf, cx = make_cols(em, +1)
        p_cols_f.append(cf); p_cols_x.append(cx)

    results = []
    dedup = set()

    nP = len(product_pool)
    max_k = nP if max_products is None else min(max_products, nP)

    for k in range(1, max_k + 1):
        for idxs in combinations(range(nP), k):
            if any(not p_ok[i] for i in idxs):
                continue

            chosen_products = [product_pool[i] for i in idxs]

            # --- NumPy 预筛：构建 float 矩阵，判定是否存在零空间（rank < ncols）---
            cols_x = r_cols_x + [p_cols_x[i] for i in idxs]
            Mx = np.column_stack(cols_x)  # shape (m, n)
            n = Mx.shape[1]
            # 满列秩 => 没有非零解，直接跳过
            if np.linalg.matrix_rank(Mx, tol=rank_tol) == n:
                continue

            # --- 精确求解：Fraction RREF ---
            cols_f = r_cols_f + [p_cols_f[i] for i in idxs]
            A = [[cols_f[j][i] for j in range(n)] for i in range(m)]  # rows
            v = _nullspace_one_vector_fraction(A)
            if v is None:
                continue

            ints = _frac_vec_to_min_int(v)
            r_part = ints[:len(reactants)]
            p_part = ints[len(reactants):]

            def all_pos(xs): return all(x > 0 for x in xs)

            if not (all_pos(r_part) and all_pos(p_part)):
                ints = [-x for x in ints]
                r_part = ints[:len(reactants)]
                p_part = ints[len(reactants):]

            if not (all_pos(r_part) and all_pos(p_part)):
                continue
            if require_all_reactants and any(x == 0 for x in r_part):
                continue
            if any(x == 0 for x in p_part):
                continue

            rmap = {name: coef for name, coef in zip(reactants, r_part)}
            pmap = {name: coef for name, coef in zip(chosen_products, p_part)}

            key = (tuple(sorted(rmap.items())), tuple(sorted(pmap.items())))
            if key in dedup:
                continue
            dedup.add(key)

            def fmt_side(m):
                return " + ".join((f"{c}{s}" if c != 1 else s) for s, c in m.items())

            eq = f"{fmt_side(rmap)} -> {fmt_side(pmap)}"
            results.append([eq, rmap, pmap])

    return results