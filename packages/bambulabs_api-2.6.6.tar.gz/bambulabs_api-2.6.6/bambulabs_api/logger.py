__all__ = ["logger"]

import logging

logger = logging.getLogger("bambulabs_api")
