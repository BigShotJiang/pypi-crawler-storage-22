AMSFilamentSettings
===================
.. automodule:: bambulabs_api.AMSFilamentSettings
  :members:
  :imported-members: