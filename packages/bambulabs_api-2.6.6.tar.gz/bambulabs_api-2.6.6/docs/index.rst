BambuLabs API
=====================================================

Description
===========
This is the Unofficial Bambulabs API:
API for accessing information for a printer,
including the status of the printer and the status of the print job.

.. toctree::
  :maxdepth: 2

  self
  Examples <examples>
  API <api>
  Release Notes <release>
