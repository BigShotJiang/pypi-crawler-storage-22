import os
import sys
#from .web_server import app, bank
# Change this line to ensure it matches your package structure
from bank_pkg.web_server import app, bank, main 

# ... keep the rest of your logic that checks for i7.exe and credit.dat ...
def main():
    """
    Bootstrap function to prepare the environment and start the Flask server.
    """
    print("=== AB'S Bank Account Manager (V6) ===")
    
    # 1. Verify C Backend exists
    if not os.path.exists(bank.c_program_path):
        print(f"Error: C executable not found at {bank.c_program_path}")
        sys.exit(1)

    # 2. Check for data file 
    if not os.path.exists(bank.data_file):
        print(f"Note: {bank.data_file} not found. A new one will be created.")

    # 3. Start the Flask App 
    # We use host='0.0.0.0' to make it accessible locally
    app.run(host='0.0.0.0', port=5000, debug=False)

if __name__ == "__main__":
    main()