from setuptools import setup, find_packages

setup(
    name="bank-manager-v6-sathish-abs",
    version="6.1.11",
    packages=find_packages(),
    include_package_data=True, # Critical for .dat and .exe files
    install_requires=[
        "Flask",
    ],
    
    entry_points={
        "console_scripts": [
            "run-bank-manager=bank_pkg.web_server:main",
        ],
    },
    author="SATHISH RAMANUJAM",
    description="V6 Bank Account Manager with C Backend",
    
)