"""
barcode-pao-wasm: Cross-platform barcode generation library for Python (WASM version)

This package provides Python bindings for a barcode library using WebAssembly.
It requires Node.js to be installed on the system.

Example:
    >>> from barcode_pao_wasm import QR, Code39
    >>>
    >>> # Generate QR code
    >>> qr = QR()
    >>> qr.set_error_correction_level("H")
    >>> base64_image = qr.draw("Hello, World!", 200)
    >>>
    >>> # Generate Code39 barcode
    >>> code39 = Code39()
    >>> code39.set_show_text(True)
    >>> base64_image = code39.draw("12345", 200, 100)
"""

from .wrapper import (
    # Error
    WasmBarcodeError,

    # 1D Barcodes
    Code39,
    Code93,
    Code128,
    GS1_128,
    NW7,
    Matrix2of5,
    NEC2of5,
    Jan8,
    Jan13,
    UPC_A,
    UPC_E,

    # GS1 DataBar
    GS1DataBar14,
    GS1DataBarLimited,
    GS1DataBarExpanded,

    # 2D Barcodes
    QR,
    DataMatrix,
    PDF417,

    # Special
    YubinCustomer,

    # Product Info
    ProductInfo,
)

__version__ = "1.0.0"
__author__ = "Pao"

__all__ = [
    # Error
    "WasmBarcodeError",

    # 1D Barcodes
    "Code39",
    "Code93",
    "Code128",
    "GS1_128",
    "NW7",
    "Matrix2of5",
    "NEC2of5",
    "Jan8",
    "Jan13",
    "UPC_A",
    "UPC_E",

    # GS1 DataBar
    "GS1DataBar14",
    "GS1DataBarLimited",
    "GS1DataBarExpanded",

    # 2D Barcodes
    "QR",
    "DataMatrix",
    "PDF417",

    # Special
    "YubinCustomer",

    # Product Info
    "ProductInfo",
]
