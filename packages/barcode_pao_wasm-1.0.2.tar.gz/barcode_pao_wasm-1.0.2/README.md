# barcode-pao-wasm

クロスプラットフォーム バーコード生成ライブラリ for Python（WebAssembly版）

## 概要

`barcode-pao-wasm` は、WebAssembly（WASM）を使用してバーコードを生成するPythonパッケージです。Node.jsを介してWASMモジュールを実行するため、ネイティブコンパイルが不要でクロスプラットフォームで動作します。

## 必要条件

- Python 3.8以上
- **Node.js** (v14以上推奨)

Node.jsがシステムにインストールされている必要があります。

```bash
# Node.jsのインストール確認
node --version
```

## 対応バーコード（18種）

### 1次元バーコード（11種）
- **Code39** - 英数字対応の汎用バーコード
- **Code93** - Code39の拡張版
- **Code128** - 全ASCII文字対応の高密度バーコード
- **GS1-128** - 物流・流通向けバーコード（コンビニ収納代行対応）
- **NW-7 (Codabar)** - 血液銀行・宅配便向けバーコード
- **Matrix 2 of 5** - 工業用バーコード
- **NEC 2 of 5** - NECが開発した2 of 5系バーコード
- **JAN-8** - 日本の商品コード（8桁）
- **JAN-13** - 日本の商品コード（13桁）
- **UPC-A** - 北米の商品コード（12桁）
- **UPC-E** - UPC-Aの短縮版（8桁）

### GS1 DataBar（3種）
- **GS1 DataBar 14** - 標準型（オムニ/スタック対応）
- **GS1 DataBar Limited** - 限定型
- **GS1 DataBar Expanded** - 拡張型（スタック対応）

### 2次元バーコード（3種）
- **QRコード** - 日本発の2次元コード
- **DataMatrix** - 工業用途の2次元コード
- **PDF417** - 運転免許証等で使用される2次元コード

### 特殊バーコード（1種）
- **郵便カスタマバーコード** - 日本郵便の住所表示バーコード

## インストール

```bash
pip install barcode-pao-wasm
```

## 使用例

### QRコード生成

```python
from barcode_pao_wasm import QR

# QRコードインスタンスを作成
qr = QR()

# エラー訂正レベルを設定（L/M/Q/H）
qr.set_error_correction_level("H")

# Base64エンコードされた画像を取得
base64_image = qr.draw("https://example.com", 200)

# ファイルに保存
qr.draw_to_file("Hello, World!", 200, "qrcode.png")
```

### Code128バーコード生成

```python
from barcode_pao_wasm import Code128

# Code128インスタンスを作成
code128 = Code128()

# テキスト表示を有効化
code128.set_show_text(True)

# 出力フォーマットをSVGに設定
code128.set_output_format("svg")

# バーコード生成
svg_data = code128.draw("ABC-12345", 300, 100)
```

### 色のカスタマイズ

```python
from barcode_pao_wasm import Code39

code39 = Code39()

# 前景色（バーの色）をRGBAで設定
code39.set_foreground_color(0, 0, 128, 255)  # 紺色

# 背景色をRGBAで設定
code39.set_background_color(255, 255, 200, 255)  # 薄黄色

base64_image = code39.draw("12345", 200, 80)
```

### GS1-128 コンビニ収納代行バーコード

```python
from barcode_pao_wasm import GS1_128

gs1 = GS1_128()
gs1.set_show_text(True)

# 標準料金代理収納用バーコード
convenience_code = "9101234567890123456789012345678901234567890123"
base64_image = gs1.draw_convenience(convenience_code, 400, 100)
```

### 郵便カスタマバーコード

```python
from barcode_pao_wasm import YubinCustomer

yubin = YubinCustomer()

# 郵便番号 + 住所表示番号
code = "1000001-1-2-3"
base64_image = yubin.draw(code, 50)  # 高さのみ指定
```

## API リファレンス

### 共通メソッド（全バーコードクラス）

| メソッド | 説明 |
|---------|------|
| `set_output_format(format)` | 出力フォーマットを設定（"png", "jpg", "gif", "svg"）|
| `set_foreground_color(r, g, b, a=255)` | 前景色（バーの色）を設定 |
| `set_background_color(r, g, b, a=255)` | 背景色を設定 |
| `draw(code, width, height)` | Base64エンコードされた画像を返す |
| `draw_to_file(code, width, height, filepath)` | ファイルに保存 |

### 1次元バーコード固有メソッド

| メソッド | 説明 |
|---------|------|
| `set_show_text(show)` | バーコード下のテキスト表示 |
| `set_text_font_scale(scale)` | テキストのフォントサイズスケール |
| `set_text_gap(scale)` | バーとテキストの間隔 |
| `set_fit_width(fit)` | 幅に合わせてバーを調整 |
| `set_px_adjust_black(adjust)` | 黒バーのピクセル調整 |
| `set_px_adjust_white(adjust)` | 白バーのピクセル調整 |

### 2次元バーコード固有メソッド

| クラス | メソッド | 説明 |
|--------|---------|------|
| QR | `set_error_correction_level(level)` | エラー訂正レベル（L/M/Q/H）|
| QR | `set_version(version)` | バージョン（0=自動, 1-40）|
| QR | `set_encode_mode(mode)` | エンコードモード（NUMERIC/ALPHANUMERIC/BYTE/KANJI）|
| DataMatrix | `set_code_size(size)` | シンボルサイズ（"AUTO", "10x10"など）|
| DataMatrix | `set_encode_scheme(scheme)` | エンコードスキーム（AUTO/ASCII/C40/TEXT/X12/EDIFACT/BASE256）|
| PDF417 | `set_error_level(level)` | エラー訂正レベル（-1=自動, 0-8）|
| PDF417 | `set_columns(columns)` | 列数 |
| PDF417 | `set_rows(rows)` | 行数 |

## 出力フォーマット

| フォーマット | 説明 |
|-------------|------|
| `png` | PNG画像（デフォルト）|
| `jpg` / `jpeg` | JPEG画像 |
| `gif` | GIF画像 |
| `svg` | SVGベクター画像 |

## Native版との違い

| 項目 | barcode-pao-wasm | barcode-pao-native |
|------|------------------|---------------------|
| 実行速度 | 遅い（Node.jsプロセス起動あり）| 高速 |
| インストール | 簡単（コンパイル不要）| コンパイラ必要 |
| 依存関係 | Node.js必須 | なし |
| クロスプラットフォーム | 優秀 | プラットフォーム依存 |
| 用途 | 開発・テスト、少量生成 | 本番環境、大量生成 |

## トラブルシューティング

### Node.jsが見つからないエラー

```
WasmBarcodeError: Node.js is required for WASM barcode generation.
```

Node.jsをインストールしてください：
- Windows: https://nodejs.org/ からインストーラをダウンロード
- macOS: `brew install node`
- Linux: `apt install nodejs` または `yum install nodejs`

### タイムアウトエラー

```
WasmBarcodeError: Barcode generation timed out
```

複雑なバーコード生成や大量データの場合に発生する可能性があります。
本番環境では `barcode-pao-native` の使用を推奨します。

## ライセンス

MIT License

## 関連パッケージ

- [barcode-pao-native](https://pypi.org/project/barcode-pao-native/) - C++ネイティブ版（高速）
