"""
WASM Barcode Wrapper

This module provides Python wrappers for the barcode WASM module.
It uses Node.js as a bridge to execute the Emscripten-compiled WASM.
"""

import json
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Optional


class WasmBarcodeError(Exception):
    """Exception raised when WASM barcode generation fails."""
    pass


def _get_wasm_dir() -> Path:
    """Get the directory containing WASM files."""
    return Path(__file__).parent / "wasm"


def _get_node_script() -> str:
    """Get the Node.js script for barcode generation (ES module format)."""
    return """
import Module from './barcode.mjs';

const args = JSON.parse(process.argv[2]);
const {className, method, methodArgs, settings} = args;

try {
    const m = await Module();
    const BarcodeClass = m[className];
    if (!BarcodeClass) {
        console.log(JSON.stringify({error: `Unknown class: ${className}`}));
        process.exit(1);
    }

    const instance = new BarcodeClass();

    // Apply settings
    if (settings.outputFormat) instance.setOutputFormat(settings.outputFormat);
    if (settings.foregroundColor) {
        const [r, g, b, a] = settings.foregroundColor;
        instance.setForegroundColor(r, g, b, a);
    }
    if (settings.backgroundColor) {
        const [r, g, b, a] = settings.backgroundColor;
        instance.setBackgroundColor(r, g, b, a);
    }
    if (settings.showText !== undefined && instance.setShowText) instance.setShowText(settings.showText);
    if (settings.fitWidth !== undefined && instance.setFitWidth) instance.setFitWidth(settings.fitWidth);
    if (settings.pxAdjustBlack !== undefined && instance.setPxAdjustBlack) instance.setPxAdjustBlack(settings.pxAdjustBlack);
    if (settings.pxAdjustWhite !== undefined && instance.setPxAdjustWhite) instance.setPxAdjustWhite(settings.pxAdjustWhite);
    if (settings.textGap !== undefined && instance.setTextGap) instance.setTextGap(settings.textGap);
    if (settings.textFontScale !== undefined && instance.setTextFontScale) instance.setTextFontScale(settings.textFontScale);
    if (settings.textEvenSpacing !== undefined && instance.setTextEvenSpacing) instance.setTextEvenSpacing(settings.textEvenSpacing);
    if (settings.showStartStop !== undefined && instance.setShowStartStop) instance.setShowStartStop(settings.showStartStop);
    if (settings.codeMode !== undefined && instance.setCodeMode) instance.setCodeMode(settings.codeMode);
    if (settings.extendedGuard !== undefined && instance.setExtendedGuard) instance.setExtendedGuard(settings.extendedGuard);
    if (settings.symbolType !== undefined && instance.setSymbolType) instance.setSymbolType(settings.symbolType);
    if (settings.noOfColumns !== undefined && instance.setNoOfColumns) instance.setNoOfColumns(settings.noOfColumns);
    if (settings.stringEncoding !== undefined && instance.setStringEncoding) instance.setStringEncoding(settings.stringEncoding);
    if (settings.errorCorrectionLevel !== undefined && instance.setErrorCorrectionLevel) instance.setErrorCorrectionLevel(settings.errorCorrectionLevel);
    if (settings.version !== undefined && instance.setVersion) instance.setVersion(settings.version);
    if (settings.encodeMode !== undefined && instance.setEncodeMode) instance.setEncodeMode(settings.encodeMode);
    if (settings.codeSize !== undefined && instance.setCodeSize) instance.setCodeSize(settings.codeSize);
    if (settings.encodeScheme !== undefined && instance.setEncodeScheme) instance.setEncodeScheme(settings.encodeScheme);
    if (settings.errorLevel !== undefined && instance.setErrorLevel) instance.setErrorLevel(settings.errorLevel);
    if (settings.columns !== undefined && instance.setColumns) instance.setColumns(settings.columns);
    if (settings.rows !== undefined && instance.setRows) instance.setRows(settings.rows);
    if (settings.aspectRatio !== undefined && instance.setAspectRatio) instance.setAspectRatio(settings.aspectRatio);
    if (settings.yHeight !== undefined && instance.setYHeight) instance.setYHeight(settings.yHeight);

    // Call the method
    const func = instance[method];
    if (!func) {
        console.log(JSON.stringify({error: `Unknown method: ${method}`}));
        process.exit(1);
    }

    const result = func.apply(instance, methodArgs);
    console.log(JSON.stringify({result: result}));
} catch (err) {
    console.log(JSON.stringify({error: err.message || String(err)}));
    process.exit(1);
}
"""


class BarcodeWasmBase:
    """Base class for WASM-based barcode wrappers."""

    _class_name: str = ""
    _node_path: Optional[str] = None

    def __init__(self):
        self._settings = {
            "outputFormat": "png",
            "foregroundColor": None,
            "backgroundColor": None,
        }
        self._wasm_dir = _get_wasm_dir()
        self._ensure_node_available()

    def _ensure_node_available(self):
        """Check if Node.js is available."""
        if BarcodeWasmBase._node_path is not None:
            return

        # Try to find Node.js
        for cmd in ["node", "nodejs"]:
            try:
                result = subprocess.run([cmd, "--version"], capture_output=True, text=True)
                if result.returncode == 0:
                    BarcodeWasmBase._node_path = cmd
                    return
            except FileNotFoundError:
                continue

        raise WasmBarcodeError(
            "Node.js is required for WASM barcode generation. "
            "Please install Node.js from https://nodejs.org/"
        )

    def _call_wasm(self, method: str, *args) -> str:
        """Call a WASM method through Node.js."""
        # Create temporary script file (ES module format)
        script_path = self._wasm_dir / "_barcode_runner.mjs"
        if not script_path.exists():
            script_path.write_text(_get_node_script())

        # Prepare arguments
        call_args = {
            "className": self._class_name,
            "method": method,
            "methodArgs": list(args),
            "settings": self._settings,
        }

        # Run Node.js
        try:
            result = subprocess.run(
                [BarcodeWasmBase._node_path, str(script_path), json.dumps(call_args)],
                capture_output=True,
                cwd=str(self._wasm_dir),
                timeout=30,
            )
        except subprocess.TimeoutExpired:
            raise WasmBarcodeError("Barcode generation timed out")

        # Decode output (handle Windows encoding)
        try:
            stdout = result.stdout.decode('utf-8') if result.stdout else ""
            stderr = result.stderr.decode('utf-8') if result.stderr else ""
        except UnicodeDecodeError:
            stdout = result.stdout.decode('latin-1') if result.stdout else ""
            stderr = result.stderr.decode('latin-1') if result.stderr else ""

        if result.returncode != 0:
            error_msg = stderr.strip() if stderr else "Unknown error"
            # Try to parse JSON error from stdout (our script outputs to stdout)
            if stdout.strip():
                try:
                    error_data = json.loads(stdout.strip())
                    if "error" in error_data:
                        error_msg = error_data.get("error", error_msg)
                except json.JSONDecodeError:
                    pass
            raise WasmBarcodeError(f"WASM execution failed: {error_msg}")

        # Parse result - find JSON line (may have debug output before it)
        json_line = None
        for line in stdout.strip().split('\n'):
            line = line.strip()
            if line.startswith('{') and line.endswith('}'):
                json_line = line

        if not json_line:
            raise WasmBarcodeError(f"No JSON response found in WASM output: {stdout[-500:]}")

        try:
            output = json.loads(json_line)
            if "error" in output:
                raise WasmBarcodeError(f"WASM error: {output['error']}")
            return output.get("result", "")
        except json.JSONDecodeError:
            raise WasmBarcodeError(f"Invalid JSON response from WASM: {json_line}")

    def set_output_format(self, format: str):
        """Set output format (png, jpg, gif, svg)."""
        self._settings["outputFormat"] = format

    def set_foreground_color(self, r: int, g: int, b: int, a: int = 255):
        """Set foreground color (RGBA)."""
        self._settings["foregroundColor"] = [r, g, b, a]

    def set_background_color(self, r: int, g: int, b: int, a: int = 255):
        """Set background color (RGBA)."""
        self._settings["backgroundColor"] = [r, g, b, a]


class Barcode1DBase(BarcodeWasmBase):
    """Base class for 1D barcode wrappers."""

    def set_show_text(self, show: bool):
        """Set whether to show text below barcode."""
        self._settings["showText"] = show

    def set_text_gap(self, scale: float):
        """Set gap between barcode and text."""
        self._settings["textGap"] = scale

    def set_text_font_scale(self, scale: float):
        """Set text font scale."""
        self._settings["textFontScale"] = scale

    def set_text_even_spacing(self, even: bool):
        """Set text even spacing mode."""
        self._settings["textEvenSpacing"] = even

    def set_fit_width(self, fit: bool):
        """Set whether to fit barcode to width."""
        self._settings["fitWidth"] = fit

    def set_px_adjust_black(self, adjust: int):
        """Set pixel adjustment for black bars."""
        self._settings["pxAdjustBlack"] = adjust

    def set_px_adjust_white(self, adjust: int):
        """Set pixel adjustment for white bars."""
        self._settings["pxAdjustWhite"] = adjust

    def draw(self, code: str, width: int, height: int) -> str:
        """Generate barcode and return Base64 or SVG string."""
        return self._call_wasm("draw", code, width, height)

    def draw_to_file(self, code: str, width: int, height: int, filepath: str):
        """Generate barcode and save to file."""
        import base64
        result = self.draw(code, width, height)
        if result.startswith("<svg") or result.startswith("<?xml"):
            # SVG output
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(result)
        else:
            # Base64 encoded binary - strip data URI prefix if present
            if result.startswith("data:"):
                result = result.split(",", 1)[1]
            data = base64.b64decode(result)
            with open(filepath, "wb") as f:
                f.write(data)


class Barcode2DBase(BarcodeWasmBase):
    """Base class for 2D barcode wrappers."""

    def set_string_encoding(self, encoding: str):
        """Set string encoding (utf-8, shift-jis)."""
        self._settings["stringEncoding"] = encoding

    def set_fit_width(self, fit: bool):
        """Set whether to fit barcode to width."""
        self._settings["fitWidth"] = fit

    def draw(self, code: str, size: int) -> str:
        """Generate barcode and return Base64 or SVG string."""
        return self._call_wasm("draw", code, size)

    def draw_to_file(self, code: str, size: int, filepath: str):
        """Generate barcode and save to file."""
        import base64
        result = self.draw(code, size)
        if result.startswith("<svg") or result.startswith("<?xml"):
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(result)
        else:
            # Strip data URI prefix if present
            if result.startswith("data:"):
                result = result.split(",", 1)[1]
            data = base64.b64decode(result)
            with open(filepath, "wb") as f:
                f.write(data)


# =============================================================================
# 1D Barcodes
# =============================================================================

class Code39(Barcode1DBase):
    """Code39 barcode generator."""
    _class_name = "Code39"

    def set_show_start_stop(self, show: bool):
        """Set whether to show start/stop characters."""
        self._settings["showStartStop"] = show


class Code93(Barcode1DBase):
    """Code93 barcode generator."""
    _class_name = "Code93"


class Code128(Barcode1DBase):
    """Code128 barcode generator."""
    _class_name = "Code128"

    def set_code_mode(self, mode: str):
        """Set code mode (AUTO, A, B, C)."""
        self._settings["codeMode"] = mode


class GS1_128(Barcode1DBase):
    """GS1-128 barcode generator."""
    _class_name = "GS1_128"

    def draw_convenience(self, code: str, width: int, height: int) -> str:
        """Generate convenience store payment barcode."""
        return self._call_wasm("drawConvenience", code, width, height)


class NW7(Barcode1DBase):
    """NW-7 (Codabar) barcode generator."""
    _class_name = "NW7"

    def set_show_start_stop(self, show: bool):
        """Set whether to show start/stop characters."""
        self._settings["showStartStop"] = show


class ITF(Barcode1DBase):
    """ITF (Interleaved 2 of 5) barcode generator."""
    _class_name = "ITF"


class Matrix2of5(Barcode1DBase):
    """Matrix 2 of 5 barcode generator."""
    _class_name = "Matrix2of5"


class NEC2of5(Barcode1DBase):
    """NEC 2 of 5 barcode generator."""
    _class_name = "NEC2of5"


class Jan8(Barcode1DBase):
    """JAN-8 barcode generator."""
    _class_name = "Jan8"

    def set_extended_guard(self, extended: bool):
        """Set whether to use extended guard bars."""
        self._settings["extendedGuard"] = extended


class Jan13(Barcode1DBase):
    """JAN-13 barcode generator."""
    _class_name = "Jan13"

    def set_extended_guard(self, extended: bool):
        """Set whether to use extended guard bars."""
        self._settings["extendedGuard"] = extended


class UPC_A(Barcode1DBase):
    """UPC-A barcode generator."""
    _class_name = "UPC_A"

    def set_extended_guard(self, extended: bool):
        """Set whether to use extended guard bars."""
        self._settings["extendedGuard"] = extended


class UPC_E(Barcode1DBase):
    """UPC-E barcode generator."""
    _class_name = "UPC_E"

    def set_extended_guard(self, extended: bool):
        """Set whether to use extended guard bars."""
        self._settings["extendedGuard"] = extended


# =============================================================================
# GS1 DataBar
# =============================================================================

class GS1DataBar14(Barcode1DBase):
    """GS1 DataBar 14 barcode generator."""
    _class_name = "GS1DataBar14"

    def set_symbol_type(self, type: str):
        """Set symbol type (OMNIDIRECTIONAL, STACKED, STACKED_OMNIDIRECTIONAL)."""
        self._settings["symbolType"] = type

    def encode(self, content: str) -> bool:
        """Encode GTIN-14 content."""
        return self._call_wasm("encode", content)

    @staticmethod
    def calculate_check_digit(src: str) -> str:
        """Calculate GS1 check digit."""
        # Note: This would need to be implemented in Python or via WASM
        raise NotImplementedError("Use native version for static methods")


class GS1DataBarLimited(Barcode1DBase):
    """GS1 DataBar Limited barcode generator."""
    _class_name = "GS1DataBarLimited"


class GS1DataBarExpanded(Barcode1DBase):
    """GS1 DataBar Expanded barcode generator."""
    _class_name = "GS1DataBarExpanded"

    def set_symbol_type(self, type: str):
        """Set symbol type (UNSTACKED, STACKED)."""
        self._settings["symbolType"] = type

    def set_no_of_columns(self, columns: int):
        """Set number of columns for stacked version."""
        self._settings["noOfColumns"] = columns

    def draw_stacked(self, code: str, width: int, height: int) -> str:
        """Generate stacked barcode."""
        return self._call_wasm("drawStacked", code, width, height)


# =============================================================================
# Special Barcodes
# =============================================================================

class YubinCustomer(BarcodeWasmBase):
    """Japanese postal customer barcode generator."""
    _class_name = "YubinCustomer"

    def set_px_adjust_black(self, adjust: int):
        """Set pixel adjustment for black bars."""
        self._settings["pxAdjustBlack"] = adjust

    def set_px_adjust_white(self, adjust: int):
        """Set pixel adjustment for white bars."""
        self._settings["pxAdjustWhite"] = adjust

    def draw(self, code: str, height: int) -> str:
        """Generate barcode (width is auto-calculated)."""
        return self._call_wasm("draw", code, height)

    def draw_with_width(self, code: str, width: int, height: int) -> str:
        """Generate barcode with explicit width."""
        return self._call_wasm("drawWithWidth", code, width, height)

    def draw_to_file(self, code: str, height: int, filepath: str):
        """Generate barcode and save to file."""
        import base64
        result = self.draw(code, height)
        if result.startswith("<svg") or result.startswith("<?xml"):
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(result)
        else:
            # Strip data URI prefix if present
            if result.startswith("data:"):
                result = result.split(",", 1)[1]
            data = base64.b64decode(result)
            with open(filepath, "wb") as f:
                f.write(data)


# =============================================================================
# 2D Barcodes
# =============================================================================

class QR(Barcode2DBase):
    """QR code generator."""
    _class_name = "QR"

    def set_error_correction_level(self, level: str):
        """Set error correction level (L, M, Q, H)."""
        self._settings["errorCorrectionLevel"] = level

    def set_version(self, version: int):
        """Set QR version (0=auto, 1-40)."""
        self._settings["version"] = version

    def set_encode_mode(self, mode: str):
        """Set encode mode (NUMERIC, ALPHANUMERIC, BYTE, KANJI)."""
        self._settings["encodeMode"] = mode


class DataMatrix(Barcode2DBase):
    """DataMatrix barcode generator."""
    _class_name = "DataMatrix"

    def set_code_size(self, size: str):
        """Set code size (AUTO, 10x10, 12x12, etc.)."""
        self._settings["codeSize"] = size

    def set_encode_scheme(self, scheme: str):
        """Set encode scheme (AUTO, ASCII, C40, TEXT, X12, EDIFACT, BASE256)."""
        self._settings["encodeScheme"] = scheme


class PDF417(Barcode2DBase):
    """PDF417 barcode generator."""
    _class_name = "PDF417"

    def set_error_level(self, level: int):
        """Set error correction level (-1=auto, 0-8)."""
        self._settings["errorLevel"] = level

    def set_columns(self, columns: int):
        """Set number of columns."""
        self._settings["columns"] = columns

    def set_rows(self, rows: int):
        """Set number of rows."""
        self._settings["rows"] = rows

    def set_aspect_ratio(self, ratio: float):
        """Set aspect ratio."""
        self._settings["aspectRatio"] = ratio

    def set_y_height(self, y_height: int):
        """Set Y height."""
        self._settings["yHeight"] = y_height


# =============================================================================
# Product Info
# =============================================================================

class ProductInfo:
    """Product information (license info)."""

    @staticmethod
    def get_license_email_addr() -> str:
        """Get license email address."""
        raise NotImplementedError("Use native version for ProductInfo")

    @staticmethod
    def is_licensed() -> bool:
        """Check if licensed."""
        raise NotImplementedError("Use native version for ProductInfo")

    @staticmethod
    def get_product_name() -> str:
        """Get product name."""
        return "barcode-pao-wasm"

    @staticmethod
    def get_version() -> str:
        """Get version."""
        return "1.0.0"

    @staticmethod
    def get_manufacturer() -> str:
        """Get manufacturer."""
        return "Pao"
