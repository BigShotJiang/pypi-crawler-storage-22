"""
setup.py for barcode-pao-wasm

Build and install:
    pip install -e .

Build wheel:
    pip install build
    python -m build
"""

import os
from setuptools import setup, find_packages

# Read README
readme_path = os.path.join(os.path.dirname(__file__), "README.md")
long_description = ""
if os.path.exists(readme_path):
    with open(readme_path, encoding="utf-8") as f:
        long_description = f.read()

setup(
    name="barcode-pao-wasm",
    version="1.0.0",
    author="Pao",
    author_email="info@pao.ac",
    description="Cross-platform barcode generation library for Python (WASM version)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pao-ac/barcode-pao-wasm",
    packages=find_packages(),
    package_data={
        "barcode_pao_wasm": ["wasm/*"],
    },
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Multimedia :: Graphics",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="barcode qr code128 code39 datamatrix pdf417 ean jan upc gs1 wasm",
)
