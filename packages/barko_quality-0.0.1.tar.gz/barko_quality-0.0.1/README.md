# barko-quality


### Authentication
```bash
export BARKO_ACCESS_TOKEN="your_token_here"
```

### Usage
```bash
barko-quality \
  --files ./media.png \
  --project-id <your-project-id>
```