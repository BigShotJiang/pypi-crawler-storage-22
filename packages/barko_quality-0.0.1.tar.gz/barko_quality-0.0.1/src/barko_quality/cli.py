import json
import os
import requests
from typing import Optional, List
from pydantic import BaseModel
import argparse

class ChatCallInput(BaseModel):
    project_idx: str
    user_input: str
    messageidx: str
    entry_id: str
    temp_file_ids: Optional[List[str]] = None

def upload_files(file_paths: List[str], site: str, access_token: str):
    uploaded_temp_ids = []

    for file_path in file_paths:
        filename = os.path.basename(file_path)

        with open(file_path, "rb") as f:
            files = {"file": (filename, f)}

            url = f"{site}/api/chats/upload_files"
            headers = {"Authorization": f"Bearer {access_token}"}

            response = requests.post(url, files=files, headers=headers)

            if response.status_code != 200:
                raise Exception(f"Upload failed: {response.status_code} - {response.text}")

            uploaded_temp_ids.append(response.text.strip())

    return uploaded_temp_ids

def create_chat(message: str, project_id: str, site: str, access_token: str):
    url = f"{site}/api/chats/create-chat"
    body = {
        "project_idx": project_id,
        "user_input": message
    }
    response = requests.post(
        url,
        headers={
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        },
        json=body,
    )
    response.raise_for_status()
    return response.json()

def create_chat_entry(message: str, site: str, access_token: str):
    url = f"{site}/api/chat-entry/create"
    body = {
        "messageBody": {
            "ai": "loading",
            "user_input": message
        }
    }
    response = requests.post(
        url,
        headers={
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        },
        json=body,
    )
    response.raise_for_status()
    return response.json().get("created")

def fetch_chat_data_stream(entry_id, message_id, user_input, project_id, site, access_token, temp_file_ids=None):
    payload = ChatCallInput(
        project_idx=project_id,
        user_input=user_input,
        messageidx=message_id,
        entry_id=entry_id,
        temp_file_ids=temp_file_ids or [],
    )

    url = f"{site}/api/chats/call"

    response = requests.post(
        url,
        headers={
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        },
        json=payload.dict(),
        stream=True,
    )

    if not response.ok:
        raise Exception(f"HTTP error! Status: {response.status_code}")

    return read_stream_response(response)

def read_stream_response(response):
    accumulated_text = ""
    for chunk in response.iter_content(chunk_size=None):
        if chunk:
            decoded = chunk.decode("utf-8").replace("]+】", "")
            accumulated_text += decoded
            #print(decoded, end="", flush=True)
    return accumulated_text

def execute_full_chat(
    message: str,
    project_id: str,
    access_token: str,
    site: str,
    file_paths: Optional[List[str]] = None,
):
    temp_file_ids = []

    if file_paths:
        temp_file_ids = upload_files(file_paths, site, access_token)

    chat_response = create_chat(message, project_id, site, access_token)
    entry_id = create_chat_entry(message, site, access_token)
    message_id = chat_response["message_id"]

    stream_response = fetch_chat_data_stream(
        entry_id,
        message_id,
        message,
        project_id,
        site,
        access_token,
        temp_file_ids=temp_file_ids,
    )

    return {
        "chat": chat_response,
        "entry_id": entry_id,
        "temp_file_ids": temp_file_ids,
        "stream_response": stream_response,
    }

def main():
    parser = argparse.ArgumentParser(
        description="barko-quality: CLI client for BarkoAgent"
    )

    parser.add_argument("--message", help="Message to send to the AI", default="What is the quality?")
    parser.add_argument("--files", nargs="*", help="Files to upload")
    parser.add_argument("--project-id", required=True, help="BarkoAgent project ID")
    parser.add_argument(
        "--site",
        default="https://chat.barkoagent.com",
        help="Base BarkoAgent URL",
    )
    parser.add_argument(
        "--access-token",
        default=os.getenv("BARKO_ACCESS_TOKEN"),
        help="Access token (or set BARKO_ACCESS_TOKEN env var)",
    )

    args = parser.parse_args()

    if not args.access_token:
        raise ValueError(
            "You must provide --access-token or set BARKO_ACCESS_TOKEN"
        )

    result = execute_full_chat(
        message=args.message,
        project_id=args.project_id,
        access_token=args.access_token,
        site=args.site,
        file_paths=args.files,
    )

    print("\n\n")
    #print(json.dumps(result, indent=2))
    print(result.get("stream_response"))

if __name__ == "__main__":
    main()
