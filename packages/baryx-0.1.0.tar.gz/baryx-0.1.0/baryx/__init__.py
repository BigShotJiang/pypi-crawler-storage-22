# Copyright 2025 The Baryx Authors.
#
# Based on original work by Crown Copyright GCHQ (Coreax)
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from ._custom_types import Nodes, Weights
from ._recombine import recombine
from ._solution import Error, Solution, barycenter, recombination_error
from ._solver import (
    AbstractRecombinationSolver,
    Caratheodory,
    TreeReduce,
)

__all__ = [
    "AbstractRecombinationSolver",
    "Caratheodory",
    "Error",
    "Nodes",
    "Solution",
    "TreeReduce",
    "Weights",
    "barycenter",
    "recombination_error",
    "recombine",
]
__version__ = "0.1.0"
