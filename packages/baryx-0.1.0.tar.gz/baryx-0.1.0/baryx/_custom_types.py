# Copyright 2025 The Baryx Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from jaxtyping import Array, ArrayLike, Float, Integer, PyTree

Nodes = Float[Array, "*batch n m"]
Weights = Float[Array, "*batch n"]
Indices = Integer[Array, "*batch n"]

UnbatchedNodes = Float[Array, "n m"]
UnbatchedWeights = Float[Array, " n"]
UnbatchedIndices = Integer[Array, " n"]

ProcessedNodes = Float[Array, "n_processed m"]
ProcessedWeights = Float[Array, " n_processed"]
ProcessedIndices = Integer[Array, " n_processed"]

RecombinedNodes = Float[Array, "*batch n_recombined m"]
RecombinedWeights = Float[Array, "*batch n_recombined"]
RecombinedIndices = Integer[Array, "*batch n_recombined"]

del Array, ArrayLike, Float, Integer, PyTree
