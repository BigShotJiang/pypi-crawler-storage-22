# Copyright 2025 The Baryx Authors.
#
# Based on original work by Crown Copyright GCHQ (Coreax)
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Literal, TypeVar

import equinox as eqx
import jax
import jax.numpy as jnp

from baryx._custom_types import (
    Nodes,
    ProcessedIndices,
    ProcessedWeights,
    RecombinedIndices,
    RecombinedWeights,
    UnbatchedNodes,
    UnbatchedWeights,
    Weights,
)
from baryx._solution import Solution
from baryx._solver import AbstractRecombinationSolver, TreeReduce

_SolverState = TypeVar("_SolverState")


def recombine(
    nodes: Nodes,
    weights: Weights | None = None,
    solver: AbstractRecombinationSolver[_SolverState] = TreeReduce(),
    mode: Literal["implicit-explicit", "implicit", "explicit"] = "implicit-explicit",
) -> Solution[_SolverState]:
    """Recombine the weighted nodes to reduce measure support.

    Given a discrete measure with ``n`` support points, finds a reduced measure
    with at most ``m + 1`` support points that preserves the barycenter, where
    ``m`` is the node dimensionality.

    Args:
        nodes: The nodes of the discrete measure with shape ``(*batch, n, m)``.
        weights: The weights associated with each node with shape
            ``(*batch, n)``. If ``None``, uniform weights are used.
        solver: The recombination solver to use.
        mode: Output format for the recombined measure.

            - ``'implicit-explicit'``: Returns ``min(n, m + 1)`` points. Of
              these, ``r + 1`` have positive weight and the remainder have zero
              weight (implicitly removed).
            - ``'implicit'``: Returns all ``n`` points. Of these, ``r + 1``
              have positive weight and the remainder have zero weight
              (implicitly removed).
            - ``'explicit'``: Returns only the ``r + 1`` points with positive
              weight. Not JIT-compatible as the output size depends on the
              rank, which is unknown at compile time.

            In all modes, ``r`` denotes the rank of the node matrix (i.e., the
            number of linearly independent columns), satisfying ``r <= m``.

    Returns:
        A :class:`~baryx.Solution` containing the recombined ``indices`` and
        ``weights``, a ``nodes`` property for accessing the indexed subset,
        and an ``error`` method for assessing the solution quality.

    Raises:
        ValueError: If an invalid ``mode`` is provided.
    """
    if mode not in {"implicit-explicit", "implicit", "explicit"}:
        msg = "Invalid mode, expected 'implicit-explicit', 'implicit' or 'explicit'."
        raise ValueError(msg)
    processed_nodes, processed_weights = _process_inputs(nodes, weights)
    unbatched_ndim = 2
    if nodes.ndim == unbatched_ndim:
        return _recombine(processed_nodes, processed_weights, solver, mode)
    return eqx.filter_vmap(_recombine)(processed_nodes, processed_weights, solver, mode)


def _recombine(
    nodes: UnbatchedNodes,
    weights: UnbatchedWeights,
    solver: AbstractRecombinationSolver[_SolverState],
    mode: Literal["implicit-explicit", "implicit", "explicit"],
) -> Solution[_SolverState]:
    """Recombine the unbatched weighted nodes."""
    # Explicit pre-normalization and post-denormalization improves numerical stability.
    weights_ = weights / weights.sum()
    implicit_weights, implicit_indices, solver_state = solver.solve(nodes, weights_)
    recombined_indices, recombined_weights = _trim_result(
        nodes, implicit_indices, implicit_weights, mode=mode
    )
    recombined_weights *= weights.sum() / recombined_weights.sum()
    return Solution(
        recombined_indices,
        recombined_weights,
        solver_state,
        original_nodes=nodes,
        original_weights=weights,
    )


def _process_inputs(nodes: Nodes, weights: Weights | None) -> tuple[Nodes, Weights]:
    """Convert nodes and weights to JAX arrays."""
    nodes = jnp.asarray(nodes)
    *batch, n, _ = nodes.shape
    if weights is None:
        weights = jnp.full((*tuple(batch), n), fill_value=1 / n, dtype=nodes.dtype)
    weights = jnp.asarray(weights)
    return nodes, weights


def _trim_result(
    nodes: UnbatchedNodes,
    indices: ProcessedIndices,
    weights: ProcessedWeights,
    mode: Literal["implicit-explicit", "implicit", "explicit"],
) -> tuple[RecombinedIndices, RecombinedWeights]:
    """Trim the weights and indices according to the specified mode.

    Args:
        nodes: The original nodes used to determine the output size bounds.
        indices: The processed indices from the solver.
        weights: The processed weights from the solver.
        mode: Output format for the recombined measure. See :func:`recombine`
            for details on each mode.

    Returns:
        A tuple of trimmed indices and weights according to the specified mode.
    """
    n, m = nodes.shape
    match mode:
        # Inside the JIT context we cannot explicitly remove all zero-weight points,
        # because we don't know how many non-zero weights there will be a priori (the
        # node matrix rank `r` is unknown until after null space resolution, and the
        # number of non-zero weights is `r + 1`). However, we have an upper bound:
        # `r + 1 <= min(n, m + 1)`. Thus, we return `min(n, m + 1)` points, of which
        # `min(n, m + 1) - (r + 1)` may be zero-weighted (implicitly removed). The
        # fill value is set to `argmin(weights)` to ensure we always index a
        # zero-weight point whenever padding is needed.
        case "implicit-explicit":
            idx = jnp.flatnonzero(
                weights, size=min(n, m + 1), fill_value=jnp.argmin(weights)
            )
        case "implicit":
            idx = jnp.flatnonzero(weights, size=n, fill_value=jnp.argmin(weights))
        case "explicit":
            try:
                idx = jnp.flatnonzero(weights)
            except jax.errors.ConcretizationTypeError as err:
                msg = (
                    "'explicit' mode is incompatible with JAX transformations such as "
                    "'jax.jit'"
                )
                raise ValueError(msg) from err
    return indices[idx], weights[idx]
