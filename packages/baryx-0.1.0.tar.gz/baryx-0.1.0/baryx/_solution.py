# Copyright 2025 The Baryx Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import functools as ft
from typing import Generic, NamedTuple, TypeVar

import equinox as eqx
import jax.numpy as jnp
from jaxtyping import Array, ArrayLike, Float, Real

from baryx._custom_types import (
    Nodes,
    RecombinedIndices,
    RecombinedNodes,
    RecombinedWeights,
    UnbatchedNodes,
    UnbatchedWeights,
    Weights,
)

UNBATCHED_NDIM = 2


class Error(NamedTuple):
    """The reconstruction error of a recombination solution.

    Measures the discrepancy between the barycenter of the recombined measure
    and the barycenter of the original measure.

    Attributes:
        absolute: The absolute error between the recombined and original
            barycenters.
        relative: The relative error between the recombined and original
            barycenters, computed as ``absolute / norm(original_barycenter)``.
        norm: The norm order used for computing the error.
    """

    absolute: Float[Array, ""]
    relative: Float[Array, ""]
    norm: Real[ArrayLike, ""] | str | None


def barycenter(nodes: Nodes, weights: Weights) -> Float[Array, "*batch m"]:
    """Compute the barycenter (center of mass) of the nodes and weights.

    Args:
        nodes: The nodes with shape ``(*batch, n, m)``.
        weights: The weights associated with each node with shape ``(*batch, n)``.

    Returns:
        The barycenter with shape ``(*batch, m)``.
    """

    def _barycenter(
        _nodes: UnbatchedNodes, _weights: UnbatchedWeights
    ) -> Float[Array, " m"]:
        normalized_weights = _weights / jnp.sum(_weights)
        return _nodes.T @ normalized_weights

    if nodes.ndim == UNBATCHED_NDIM:
        return _barycenter(nodes, weights)
    return eqx.filter_vmap(_barycenter)(nodes, weights)


def recombination_error(
    nodes: RecombinedNodes,
    weights: RecombinedWeights,
    original_nodes: Nodes,
    original_weights: Weights,
    norm: Real[ArrayLike, ""] | str | None = jnp.inf,
) -> Error:
    """Compute the error between the recombined and original barycenters.

    Args:
        nodes: The recombined nodes with shape ``(*batch, n_recombined, m)``.
        weights: The recombined weights with shape ``(*batch, n_recombined)``.
        original_nodes: The original nodes with shape ``(*batch, n, m)``.
        original_weights: The original weights with shape ``(*batch, n)``.
        norm: The norm order for computing the error. Defaults to infinity norm.
            Accepts any value valid for ``jax.numpy.linalg.norm``.

    Returns:
        An ``Error`` named tuple containing:
            - The absolute error.
            - The relative error.
            - The norm order used for the computation.
    """
    recombined_barycenter = barycenter(nodes, weights)
    original_barycenter = barycenter(original_nodes, original_weights)
    norm_ = ft.partial(jnp.linalg.norm, ord=norm)
    if nodes.ndim != UNBATCHED_NDIM:
        norm_ = eqx.filter_vmap(norm_)
    absolute = norm_(original_barycenter - recombined_barycenter)
    relative = absolute / norm_(original_barycenter)
    return Error(absolute, relative, norm)


_SolverState = TypeVar("_SolverState")


class Solution(eqx.Module, Generic[_SolverState]):
    """The solution to a recombination problem.

    Attributes:
        indices: Indices into the original nodes array identifying which nodes
            are retained in the recombined measure with shape
            ``(*batch, n_recombined)``.
        weights: The recombined weights with shape ``(*batch, n_recombined)``.
        solver_state: The final state of the solver, useful for debugging or
            analysis. Type depends on the solver used.
        original_nodes: The original input nodes with shape ``(*batch, n, m)``.
        original_weights: The original input weights with shape ``(*batch, n)``.
    """

    indices: RecombinedIndices
    weights: RecombinedWeights
    solver_state: _SolverState
    original_nodes: Nodes
    original_weights: Weights

    @property
    def nodes(self) -> RecombinedNodes:
        """The recombined solution nodes.

        Returns:
            The recombined nodes extracted from ``original_nodes`` at the
            positions specified by the ``indices`` with shape
            ``(*batch, n_recombined, m)``.
        """
        return jnp.take_along_axis(
            self.original_nodes, self.indices[..., None], axis=-2, mode="clip"
        )

    def error(self, norm: Real[ArrayLike, ""] | str | None = jnp.inf) -> Error:
        """Compute the reconstruction error of this solution.

        Args:
            norm: The norm order for computing the error. Defaults to infinity norm.
                Accepts any value valid for ``jax.numpy.linalg.norm``.

        Returns:
            An ``Error`` named tuple containing:
                - The absolute error.
                - The relative error.
                - The norm order used for the computation.
        """
        return recombination_error(
            self.nodes,
            self.weights,
            self.original_nodes,
            self.original_weights,
            norm=norm,
        )
