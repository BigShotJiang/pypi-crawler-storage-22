# Copyright 2025 The Baryx Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import abc
from typing import Generic, TypeAlias, TypeVar

import equinox as eqx
import jax
import jax.numpy as jnp
from jaxtyping import Array, Bool

from baryx._custom_types import (
    ProcessedIndices,
    ProcessedNodes,
    ProcessedWeights,
    UnbatchedNodes,
    UnbatchedWeights,
)

_SolverState = TypeVar("_SolverState")
_LoopState: TypeAlias = tuple[ProcessedWeights, ProcessedIndices, _SolverState]


class AbstractRecombinationSolver(eqx.Module, Generic[_SolverState]):
    """Abstract base class for all recombination solvers."""

    debug: eqx.AbstractVar[bool]

    @abc.abstractmethod
    def init(
        self,
        nodes: UnbatchedNodes,
        weights: UnbatchedWeights,
    ) -> tuple[ProcessedNodes, ProcessedWeights, ProcessedIndices, _SolverState]:
        """Initialize the solver state and preprocess the nodes and weights."""

    @abc.abstractmethod
    def step(
        self,
        nodes: ProcessedNodes,
        loop_state: _LoopState[_SolverState],
    ) -> _LoopState[_SolverState]:
        """Solution step called by the ``iterate`` method."""

    @classmethod
    @abc.abstractmethod
    def converged(
        cls,
        loop_state: _LoopState[_SolverState],
    ) -> Bool[Array, ""]:
        """Check if ``step`` has converged."""

    @classmethod
    def iterate_debug_callback(
        cls,
        nodes: ProcessedNodes,
        weights: ProcessedWeights,
        indices: ProcessedIndices,
        loop_state: _LoopState[_SolverState],
    ) -> None:
        """Called during each iteration step when debug is enabled."""

    def iterate(
        self,
        nodes: ProcessedNodes,
        weights: ProcessedWeights,
        indices: ProcessedIndices,
        solver_state: _SolverState,
    ) -> tuple[ProcessedWeights, ProcessedIndices, _SolverState]:
        """Iteratively apply ``step`` until ``converged``.

        Args:
            nodes: The preprocessed nodes from ``init``.
            weights: The preprocessed weights from ``init``.
            indices: The initial indices from ``init``.
            solver_state: The initial solver state from ``init``.

        Returns:
            A tuple of the final weights, indices, and solver state.
        """
        # Only array (dynamic) parts of the solver state can be passed through JAX's
        # while_loop. The static state is closed over in _cond and _step so that
        # self.step and self.converged can still access the full solver state.
        dynamic_state, static_state = eqx.partition(solver_state, eqx.is_array)

        def _rebuild_state(
            loop_state: _LoopState[_SolverState],
        ) -> _LoopState[_SolverState]:
            weights_, indices_, dynamic_state_ = loop_state
            solver_state_ = eqx.combine(dynamic_state_, static_state)
            return weights_, indices_, solver_state_

        def _cond(loop_state: _LoopState[_SolverState]) -> Bool[Array, ""]:
            loop_state_ = _rebuild_state(loop_state)
            if self.debug:
                self.iterate_debug_callback(nodes, weights, indices, loop_state_)
            return jnp.logical_not(self.converged(loop_state_))

        def _step(loop_state: _LoopState[_SolverState]) -> _LoopState[_SolverState]:
            loop_state_ = _rebuild_state(loop_state)
            out_weights, out_indices, out_solver_state = self.step(nodes, loop_state_)
            out_dynamic_state = eqx.filter(out_solver_state, eqx.is_array)
            return out_weights, out_indices, out_dynamic_state

        loop_state = weights, indices, dynamic_state
        out_dynamic_state = jax.lax.while_loop(_cond, _step, loop_state)
        return _rebuild_state(out_dynamic_state)

    def solve(
        self,
        nodes: UnbatchedNodes,
        weights: UnbatchedWeights,
    ) -> tuple[ProcessedWeights, ProcessedIndices, _SolverState]:
        """Solve the recombination problem.

        Initializes the solver state via ``init`` and iterates via ``iterate``
        until convergence.

        Args:
            nodes: The input nodes with shape ``(n, m)``.
            weights: The input weights with shape ``(n,)``.

        Returns:
            A tuple of the final weights, indices, and solver state.
        """
        nodes_, weights_, indices, state = self.init(nodes, weights)
        return self.iterate(nodes_, weights_, indices, state)
