# Copyright 2025 The Baryx Authors.
#
# Based on original work by Crown Copyright GCHQ (Coreax)
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Literal, NamedTuple

import equinox as eqx
import jax
import jax.numpy as jnp
from jaxtyping import Array, Bool, DTypeLike, Float, Int

from baryx._custom_types import (
    Indices,
    ProcessedIndices,
    ProcessedNodes,
    ProcessedWeights,
    UnbatchedIndices,
    UnbatchedNodes,
    UnbatchedWeights,
)
from baryx._solution import recombination_error
from baryx._solver import AbstractRecombinationSolver


class _CaratheodoryState(NamedTuple):
    resolved_rcond: Float[Array, ""]
    largest_null_space_basis: Float[Array, "n n"]
    nullity: Int[Array, ""]
    basis_index: Int[Array, ""]


class Caratheodory(AbstractRecombinationSolver[_CaratheodoryState]):
    r"""Recombination via Caratheodory measure reduction (Gaussian elimination).

    Proposed in Tchernychova (2016), Chapter 1.3.3.3, as an alternative to the
    Simplex algorithm for solving the recombination problem.

    Unlike the Simplex method, with time complexity ``O(m^3 n + m n^2)``,
    Caratheodory recombination has time complexity of only ``O(m n^2)``.

    Attributes:
        rcond: Relative condition number. Singular values below
            ``rcond * max(singular_values)`` are treated as zero. Defaults to
            ``eps * max(n, m)`` where ``eps`` is the floating-point machine
            epsilon.
        zero_threshold: Threshold below which values are treated as zero.
            Defaults to ``eps * max(abs(values))`` if ``None``.
        null_space_resolver: Method for computing the left null space basis.
            ``'svd'`` uses singular value decomposition, ``'rrqr'`` uses
            rank-revealing QR decomposition, and ``'qr'`` uses standard QR
            decomposition. Listed in order of decreasing numerical stability
            and increasing speed (i.e., ``'svd'`` is the most stable but
            slowest, while ``'qr'`` is the fastest but least stable).
        svd_algorithm: The SVD algorithm to use when ``null_space_resolver``
            is ``'svd'``. See ``jax.lax.linalg.svd`` for details.
        debug: If ``True``, prints detailed debug information during iteration.

    References:
        Tchernychova, M. (2016). Caratheodory cubature measures. PhD thesis,
        University of Oxford.
        https://ora.ox.ac.uk/objects/uuid:a3a10980-d35d-467b-b3c0-d10d2e491f2d
    """

    rcond: float | None = None
    zero_threshold: float | None = None
    null_space_resolver: Literal["svd", "rrqr", "qr"] = "svd"
    svd_algorithm: jax.lax.linalg.SvdAlgorithm | None = None
    debug: bool = eqx.field(default=False, kw_only=True)

    def init(
        self, nodes: UnbatchedNodes, weights: UnbatchedWeights
    ) -> tuple[ProcessedNodes, ProcessedWeights, ProcessedIndices, _CaratheodoryState]:
        # Precision loss is too large if we don't use jnp.float64.
        nodes_, weights_ = nodes.astype(jnp.float64), weights.astype(jnp.float64)
        safe_nodes, safe_weights, safe_indices = _collinearize(
            nodes_, weights_, self.zero_threshold
        )
        safe_augmented_nodes = _augment_nodes(safe_nodes, safe_weights)
        largest_null_space_basis, nullity, resolved_rcond = _resolve_null_basis(
            safe_augmented_nodes,
            self.rcond,
            self.null_space_resolver,
            self.svd_algorithm,
        )
        solver_state = _CaratheodoryState(
            resolved_rcond=resolved_rcond,
            largest_null_space_basis=largest_null_space_basis,
            nullity=nullity,
            basis_index=jnp.asarray(0, dtype=jnp.int64),
        )
        if self.debug:
            n, m = safe_nodes.shape
            jax.debug.print(
                "[{name}] nodes[n={n},m={m}], nullity={nullity}",
                name=self.__class__.__name__,
                n=n,
                m=m,
                nullity=nullity,
            )
        return safe_nodes, safe_weights, safe_indices, solver_state

    def step(
        self,
        nodes: ProcessedNodes,
        loop_state: tuple[ProcessedWeights, ProcessedIndices, _CaratheodoryState],
    ) -> tuple[ProcessedWeights, ProcessedIndices, _CaratheodoryState]:
        # Algorithm 6 - Chapter 3.3 of Tchernychova (2016)
        # Our Notation -> Their Notation
        # - `basis_index` (loop iteration) -> i
        # - `elimination_index` -> k^{(i)}
        # - `elimination_rescaling_factor` -> \alpha_{(i)}
        # - `updated_weights` -> \underline{\Beta}^{(i)}
        # - `null_space_basis_update` -> d_{l+1}^{(i)}\phi_1^{(i-1)}
        # - `updated_null_space_basis` -> \Psi^{(i)}
        del nodes
        weights, indices, solver_state = loop_state
        resolved_rcond, null_space_basis, nullity, basis_index = solver_state
        basis_vector = null_space_basis[basis_index]
        # Equation 3: Select the weight to eliminate.
        elimination_condition = jnp.where(
            basis_vector > _resolve_zero_threshold(basis_vector, self.zero_threshold),
            weights / basis_vector,
            jnp.inf,
        )
        elimination_index = jnp.argmin(elimination_condition)
        elimination_rescaling_factor = elimination_condition[elimination_index]
        # Equation 4: Eliminate the selected weight and redistribute its mass.
        # NOTE: Equation 5 is implicit from Equation 4 and is performed outside
        # of `_eliminate` and `implicit_recombine`.
        updated_weights = weights - elimination_rescaling_factor * basis_vector
        updated_weights = jnp.where(
            updated_weights
            > _resolve_zero_threshold(updated_weights, self.zero_threshold),
            updated_weights,
            0,
        )
        # Equations 6, 7 and 8: Update the Null space basis.
        null_space_basis_update = jnp.outer(
            null_space_basis[:, elimination_index],
            basis_vector / basis_vector[elimination_index],
        )
        updated_null_space_basis = null_space_basis - null_space_basis_update
        updated_solver_state = _CaratheodoryState(
            resolved_rcond=resolved_rcond,
            largest_null_space_basis=updated_null_space_basis,
            nullity=nullity,
            basis_index=basis_index + 1,
        )
        return updated_weights, indices, updated_solver_state

    @classmethod
    def converged(
        cls, loop_state: tuple[ProcessedWeights, ProcessedIndices, _CaratheodoryState]
    ) -> Bool[Array, ""]:
        *_, solver_state = loop_state
        return jnp.bool(solver_state.basis_index >= solver_state.nullity)

    @classmethod
    def iterate_debug_callback(
        cls,
        nodes: UnbatchedNodes,
        weights: UnbatchedWeights,
        indices: Indices,
        loop_state: tuple[ProcessedWeights, ProcessedIndices, _CaratheodoryState],
    ) -> None:
        del indices
        current_weights, current_indices, current_solver_state = loop_state
        n, mp1 = nodes.shape
        nullity_bound = max(n, mp1)
        current_nodes = nodes[current_indices]
        abs_sup, rel_sup, _ = recombination_error(
            current_nodes, current_weights, nodes, weights, norm=jnp.inf
        )
        abs_l2, rel_l2, _ = recombination_error(
            current_nodes, current_weights, nodes, weights, norm=2
        )

        jax.debug.print(
            "[{name}] iter: {iteration:{iteration_width}}/{max_iterations}, "
            "weights(nz={non_zero_weights}/{weight_count},sum={weight_sum:.2e}), "
            "error[sup/L2](abs={abs_sup:.2e}/{abs_l2:.2e},rel={rel_sup:.2e}/{rel_l2:.2e})",
            name=cls.__name__,
            iteration=current_solver_state.basis_index,
            iteration_width=len(str(nullity_bound)),
            max_iterations=current_solver_state.nullity,
            non_zero_weights=jnp.count_nonzero(current_weights),
            weight_count=n,
            weight_sum=jnp.sum(weights),
            abs_sup=abs_sup,
            rel_sup=rel_sup,
            abs_l2=abs_l2,
            rel_l2=rel_l2,
        )


def _augment_nodes(
    nodes: UnbatchedNodes, weights: UnbatchedWeights
) -> Float[Array, "n m+1"]:
    affine_augmentation = jnp.full(weights.shape, jnp.sum(weights), weights.dtype)
    augmented_nodes = jnp.c_[affine_augmentation, nodes]
    return augmented_nodes


def _collinearize(
    nodes: UnbatchedNodes, weights: UnbatchedWeights, zero_threshold: float | None
) -> tuple[UnbatchedNodes, UnbatchedWeights, UnbatchedIndices]:
    """Make zero-weighted nodes collinear with the maximum weighted node.

    Due to the static shape requirements imposed by JAX, we implicitly remove nodes
    by setting their corresponding weights to zero. This is sufficient in the
    recombination algorithm for all but one scenario, the computation of the null
    space basis. Because the zero-weighted nodes still exist in the node matrix,
    they influence the null space resolution and yield an erroneous null space basis.

    We handle this problem by setting the zero-weighted nodes equal (collinear)
    to the largest weighted node (an arbitrary but consistent choice). Because the
    nodes are now collinear to each other and the largest weighted node, we know
    that at least all but one of them can be safely eliminated by the recombination
    procedure. Thus, the nodes become effectively "invisible" to the elimination
    procedure.

    The only caveat is that we don't know which of the equal nodes will be retained
    post-elimination. To handle this, we keep an index (reference) from the
    zero-weighted nodes to the largest weighted node, and we redistribute the largest
    weight equally over all the collinear nodes (preserving the barycenter and
    allowing any node to be eliminated).

    Args:
        nodes: The nodes to make collinear.
        weights: The weights to apply the collinearization correction to.
        zero_threshold: Threshold below which weights are treated as zero.

    Returns:
        The collinear nodes, corrected weights, and collinear-to-original
        reference indices.
    """
    max_index = jnp.argmax(weights)
    index_dtype = max_index.dtype
    resolved_zero_threshold = _resolve_zero_threshold(weights, zero_threshold)

    def _cond(state):
        zero_weights_mask, *_ = state
        return jnp.any(zero_weights_mask > 0)

    def _body(state):
        zero_weights_mask, normalizer, indices = state
        update_index = jnp.argmax(weights / normalizer)
        zero_index = jnp.argmax(zero_weights_mask)
        updated_weights_mask = zero_weights_mask.at[zero_index].set(0)
        updated_indices = indices.at[zero_index].set(update_index)
        updated_normalizer = normalizer.at[update_index].add(1.0)
        return updated_weights_mask, updated_normalizer, updated_indices

    normalizer = jnp.ones(weights.shape[0], dtype=weights.dtype)
    zero_weights_mask = (weights <= resolved_zero_threshold).astype(index_dtype)
    init_state = (zero_weights_mask, normalizer, jnp.arange(weights.shape[0]))
    _, normalizer, indices = jax.lax.while_loop(_cond, _body, init_state)
    normalized_weights = weights / normalizer
    return nodes[indices], normalized_weights[indices], indices


# Credit: https://github.com/patrick-kidger/lineax/blob/9b923c8df6556551fedc7adeea7979b5c7b3ffb0/lineax/_solver/svd.py#L67  # noqa: E501
# for the rank determination code.
def _resolve_null_basis(
    nodes: UnbatchedNodes,
    rcond: float | None,
    null_space_resolver: Literal["svd", "rrqr", "qr"],
    svd_algorithm: jax.lax.linalg.SvdAlgorithm | None,
) -> tuple[Float[Array, "n n"], Int[Array, ""], Float[Array, ""]]:
    r"""Compute an orthonormal basis containing the left null space.

    Computes a full ``n x n`` orthonormal matrix ``Q`` from which the left null
    space basis can be extracted. The first ``nullity`` rows of ``Q`` span the
    left null space. The remaining rows are orthogonal complements and should
    be ignored in upstream computations.

    For a matrix A with shape ``(n, m)`` and rank ``r``, the left null space has
    dimension ``n - r``. This function returns the full orthonormal basis to
    maintain static array shapes required by JAX.

    Args:
        nodes: Matrix of nodes with shape ``(n, m)`` whose left null space is to
            be determined.
        rcond: Relative condition number. Singular values below
            ``rcond * max(singular_values)`` are treated as zero. Defaults to
            ``eps * max(n, m)`` if ``None``.
        null_space_resolver: Method for computing the left null space basis.
            ``'svd'`` uses singular value decomposition, ``'rrqr'`` uses
            rank-revealing QR decomposition, and ``'qr'`` uses standard QR
            decomposition. Listed in order of decreasing numerical stability
            and increasing speed (i.e., ``'svd'`` is the most stable but
            slowest, while ``'qr'`` is the fastest but least stable).
        svd_algorithm: The SVD algorithm to use when ``null_space_resolver``
            is ``'svd'``. See ``jax.lax.linalg.svd`` for details.

    Returns:
        A tuple containing:
            - The ``n x n`` orthonormal basis matrix (first ``nullity`` rows
              span the left null space).
            - The nullity (dimension of the left null space).
            - The resolved relative condition number.
    """
    node_norm: Array = jnp.linalg.norm(nodes, axis=0, keepdims=True)
    nodes = jnp.where(node_norm > 0, nodes / node_norm, nodes)
    match null_space_resolver:
        case "svd":
            q, s, _ = jax.lax.linalg.svd(nodes, algorithm=svd_algorithm)
        case "rrqr" | "qr":
            pivoting = True if null_space_resolver == "rrqr" else False
            q, r, *_ = jax.lax.linalg.qr(nodes, pivoting=pivoting)
            s = jnp.abs(jnp.diag(r))
        case _:
            msg = "Invalid null_space_resolver, expected 'svd', 'rrqr' or 'qr'."
            raise ValueError(msg)
    resolved_rcond = _resolve_rcond(nodes.shape, s.dtype, rcond)
    if s.size > 0:
        resolved_rcond *= jnp.max(s[0])
    mask = (s > resolved_rcond).astype(jax.dtypes.canonicalize_dtype(jnp.int64))
    matrix_rank = sum(mask)
    nullity = jnp.maximum(0, nodes.shape[0] - matrix_rank)
    largest_null_space_basis = q.T[::-1]
    return largest_null_space_basis, nullity, resolved_rcond


# Credit: https://github.com/patrick-kidger/lineax/blob/9b923c8df6556551fedc7adeea7979b5c7b3ffb0/lineax/_misc.py#L34  # noqa: E501
def _resolve_rcond(
    shape: tuple[int, ...], dtype: DTypeLike, rcond: float | None = None
) -> Float[Array, ""]:
    """Resolve the relative condition number (rcond).

    Args:
        shape: The shape of the matrix for which rcond is being resolved.
        dtype: The data type of the matrix elements.
        rcond: The relative condition number. If ``None``, defaults to
            ``eps * max(shape)`` where ``eps`` is the floating-point machine
            epsilon. If negative, defaults to ``eps``.

    Returns:
        The resolved relative condition number.
    """
    epsilon = jnp.asarray(jnp.finfo(dtype).eps, dtype)
    if rcond is None:
        return epsilon * max(shape)
    return jnp.where(rcond < jnp.asarray(0), epsilon, rcond)


def _resolve_zero_threshold(
    x: Float[Array, "..."], zero_threshold: float | None = None
) -> Float[Array, ""]:
    """Resolve the zero cutoff threshold.

    Args:
        x: Array used to determine a scale-appropriate threshold when
            ``zero_threshold`` is ``None``.
        zero_threshold: Explicit threshold value. If ``None``, defaults to
            ``eps * max(abs(x))``. If negative, defaults to ``eps``.

    Returns:
        The resolved zero cutoff threshold.
    """
    epsilon = jnp.asarray(jnp.finfo(x.dtype).eps, x.dtype)
    if zero_threshold is None:
        scale_factor = jnp.max(jnp.abs(x))
        safe_scale_factor = jnp.maximum(scale_factor, jnp.asarray(1.0, dtype=x.dtype))
        return safe_scale_factor * epsilon
    return jnp.where(zero_threshold < jnp.asarray(0), epsilon, zero_threshold)
