# Copyright 2025 The Baryx Authors.
#
# Based on original work by Crown Copyright GCHQ (Coreax)
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math
from typing import Generic, NamedTuple

import equinox as eqx
import jax
import jax.numpy as jnp
from jaxtyping import Array, Bool, Float, Int, Shaped
from typing_extensions import TypeVar  # Backports default parameter from 3.13

from baryx._custom_types import (
    Indices,
    ProcessedIndices,
    ProcessedNodes,
    ProcessedWeights,
    UnbatchedNodes,
    UnbatchedWeights,
)
from baryx._solution import recombination_error
from baryx._solver import (
    AbstractRecombinationSolver,
    Caratheodory,
)

_Solver = TypeVar("_Solver", bound=AbstractRecombinationSolver, default=Caratheodory)


class _TreeState(NamedTuple):
    padding: int
    tree_count: int
    max_tree_depth: int
    depth: Int[Array, ""]
    initial_nonzero_weight_count: Int[Array, ""]


class TreeReduce(AbstractRecombinationSolver[_TreeState], Generic[_Solver]):
    r"""Tree-based recombination solver.

    Based on Algorithm 7, Chapter 3.3 of Tchernychova (2016), which is an order
    of magnitude more efficient than Algorithm 5 in Chapter 3.2, originally
    introduced in Litterer & Lyons (2012).

    The tree traversal requires ``O(log(n / (c * m)))`` levels, where ``c`` is
    the ``tree_reduction_factor``. At each level, recombination is performed on
    ``c * m`` cluster centroids using ``base_solver``. The overall time
    complexity is ``O(n * m + log(n / (c * m)) * c * m^3)``.

    Note:
        As the ratio ``n / m`` grows, the time complexity of ``TreeReduce``
        grows logarithmically, whereas ``Caratheodory`` grows quadratically.
        Hence, ``TreeReduce`` is generally more efficient for all but the
        smallest values of ``n / m``.

    Attributes:
        base_solver: The solver used to perform recombination on the cluster
            barycenters.
        tree_reduction_factor: The factor by which each tree reduction step
            reduces the number of positive-weight nodes. After recombination,
            the remaining number of positive-weight nodes is at most
            ``n / tree_reduction_factor``.
        debug: If ``True``, prints detailed debug information during iteration.

    References:
        Tchernychova, M. (2016). Caratheodory cubature measures. PhD thesis,
        University of Oxford.
        https://ora.ox.ac.uk/objects/uuid:a3a10980-d35d-467b-b3c0-d10d2e491f2d

        Litterer, C. & Lyons, T. (2012). High order recombination and an
        application to cubature on Wiener space. The Annals of Applied
        Probability, 22(4). doi:10.1214/11-aap786
    """

    base_solver: _Solver = Caratheodory()  # pyright: ignore
    tree_reduction_factor: float = 2.0
    debug: bool = eqx.field(default=False, kw_only=True)

    def init(
        self, nodes: UnbatchedNodes, weights: UnbatchedWeights
    ) -> tuple[ProcessedNodes, ProcessedWeights, ProcessedIndices, _TreeState]:
        n, m = nodes.shape
        padding, tree_count, max_depth = _prepare_tree(n, m, self.tree_reduction_factor)
        padded_weights = jnp.pad(weights, pad_width=(0, padding))
        padded_indices = jnp.arange(n + padding)
        # JAX clamps out-of-bounds indices to the last valid entry, so any
        # padded indices >= len(nodes) will use the final row of nodes.
        padded_nodes = nodes[padded_indices]
        solver_state = _TreeState(
            padding,
            tree_count,
            max_depth,
            depth=jnp.asarray(0),
            initial_nonzero_weight_count=jnp.count_nonzero(weights),
        )
        if self.debug:
            jax.debug.print(
                "[{name}] nodes[{n}x{m}], padding={padding}, tree_count={tree_count}",
                name=self.__class__.__name__,
                n=n,
                m=m,
                padding=padding,
                tree_count=tree_count,
            )
        return padded_nodes, padded_weights, padded_indices, solver_state

    def step(
        self,
        nodes: ProcessedNodes,
        loop_state: tuple[ProcessedWeights, ProcessedIndices, _TreeState],
    ) -> tuple[ProcessedWeights, ProcessedIndices, _TreeState]:
        """Apply one tree-based recombination step.

        Partitions the dataset into clusters of approximately equal size and
        computes the cluster barycenters. Recombination is then performed on
        these barycenters using ``base_solver``, with every node in eliminated
        clusters being implicitly removed (assigned zero weight).

        Each step reduces the number of positive-weight nodes by a factor of
        approximately ``tree_reduction_factor``. The process repeats until each
        cluster contains at most one positive-weight node.

        Args:
            nodes: The preprocessed input nodes.
            loop_state: Tuple of weights, indices, and solver state.

        Returns:
            Updated tuple of weights, indices, and solver state.
        """
        weights, indices, solver_state = loop_state
        tree_count = solver_state.tree_count
        # Index weights to a centroid; argsort ensures that centroids are balanced.
        centroid_indices = jnp.argsort(weights).reshape(tree_count, -1, order="F")
        centroid_nodes, centroid_weights = _centroid(
            nodes[indices[centroid_indices]],
            weights[centroid_indices],
        )
        # Solve the measure reduction problem on the centroid dataset.
        centroid_result = self.base_solver.solve(centroid_nodes, centroid_weights)
        recombined_weights, recombined_indices, _ = centroid_result
        # Propagate centroid coresubset weights to the underlying weights for each
        # centroid, as defined by `centroid_indices`.
        weight_update_indices = centroid_indices[recombined_indices]
        weight_update = recombined_weights / centroid_weights[recombined_indices]
        updated_weights = weights[weight_update_indices] * weight_update[..., None]
        # Maintain a correspondence between the original data indices and the sorted
        # indices, used to construct the balanced centroids.
        updated_indices = indices[weight_update_indices.reshape(-1, order="F")]
        out_weights = updated_weights.reshape(-1, order="F")
        out_state = _TreeState(
            solver_state.padding,
            solver_state.tree_count,
            solver_state.max_tree_depth,
            depth=solver_state.depth + 1,
            initial_nonzero_weight_count=jnp.count_nonzero(weights),
        )
        return out_weights, updated_indices, out_state

    @classmethod
    def converged(
        cls, loop_state: tuple[ProcessedWeights, ProcessedIndices, _TreeState]
    ) -> Bool[Array, ""]:
        weights, _, solver_state = loop_state
        return jnp.logical_or(
            jnp.logical_and(
                solver_state.depth > 0,
                jnp.count_nonzero(weights) == solver_state.initial_nonzero_weight_count,
            ),
            solver_state.depth >= solver_state.max_tree_depth,
        )

    @classmethod
    def iterate_debug_callback(
        cls,
        nodes: UnbatchedNodes,
        weights: UnbatchedWeights,
        indices: Indices,
        loop_state: tuple[ProcessedWeights, ProcessedIndices, _TreeState],
    ) -> None:
        del indices
        current_weights, current_indices, current_solver_state = loop_state
        n, _ = nodes.shape
        current_nodes = nodes[current_indices]
        abs_sup, rel_sup, _ = recombination_error(
            current_nodes, current_weights, nodes, weights, norm=jnp.inf
        )
        abs_l2, rel_l2, _ = recombination_error(
            current_nodes, current_weights, nodes, weights, norm=2
        )
        jax.debug.print(
            "[{name}] depth: {depth:{depth_width}}/{max_depth}, converged={converged}, "
            "weights(nz={non_zero_weights}/{weight_count},sum={weight_sum:.2e}), "
            "error[sup/L2](abs={abs_sup:.2e}/{abs_l2:.2e},rel={rel_sup:.2e}/{rel_l2:.2e})",
            name=cls.__name__,
            depth=current_solver_state.depth,
            depth_width=len(str(current_solver_state.max_tree_depth)),
            max_depth=current_solver_state.max_tree_depth,
            converged=cls.converged(loop_state),
            non_zero_weights=jnp.count_nonzero(current_weights),
            weight_count=n,
            weight_sum=jnp.sum(weights),
            abs_sup=abs_sup,
            rel_sup=rel_sup,
            abs_l2=abs_l2,
            rel_l2=rel_l2,
        )


def _prepare_tree(n: int, m: int, tree_reduction_factor: float) -> tuple[int, int, int]:
    """Compute tree parameters: padding, tree count, and maximum depth.

    Args:
        n: Number of nodes.
        m: Node dimensionality (number of test functions).
        tree_reduction_factor: The factor by which each tree reduction step
            reduces the number of positive-weight nodes. The remaining number
            of positive-weight nodes after recombination is at most
            ``n / tree_reduction_factor``.

    Returns:
        A tuple containing:
            - The padding required to reshape nodes into approximately
              equal-sized clusters.
            - The tree count (number of clusters).
            - The maximum tree depth (number of reduction steps).
    """
    max_retained_trees = m + 1
    # alpha \in [1, ..., n - m]
    alpha = max(1, math.ceil((tree_reduction_factor - 1) * max_retained_trees))
    tree_count = min(n, max_retained_trees + alpha)
    max_tree_size = math.ceil(n / tree_count)
    padding = tree_count * max_tree_size - n

    max_depth = 0
    n_remaining = n
    while True:
        max_depth += 1
        large_tree_count = n_remaining % tree_count
        small_tree_count = tree_count - large_tree_count
        assert large_tree_count + small_tree_count == tree_count

        small_tree_size = n_remaining // tree_count
        n_small = small_tree_count * small_tree_size
        n_large = n_remaining - n_small
        if large_tree_count > 0:
            large_tree_size = n_large / large_tree_count
        else:
            large_tree_size = 0
        if small_tree_size + large_tree_size <= 1:
            # At this point, each tree indexes at most a single point and we
            # have traversed to the bottom of the tree (hit the maximum depth).
            break
        max_large_trees_retained = min(large_tree_count, max_retained_trees)
        min_small_trees_retained = max_retained_trees - max_large_trees_retained
        max_large_retained = max_large_trees_retained * large_tree_size
        min_small_retained = min_small_trees_retained * small_tree_size
        n_remaining = max_large_retained + min_small_retained

    # max_depth is calculated under the assumption of full rank at all times and that
    # only the smallest sized trees are eliminated at each depth. By computing max_depth
    # we can save one final round of null space resolution in the iterate method.
    return padding, tree_count, max_depth


def _centroid(
    nodes: Shaped[Array, "tree_count tree_size m"],
    weights: Shaped[Array, "tree_count tree_size"],
) -> tuple[Float[Array, "tree_count m"], Float[Array, " tree_count"]]:
    """Compute the cluster barycenters and total masses.

    Args:
        nodes: Clustered nodes with shape ``(tree_count, tree_size, m)``. The
            leading axis indexes each cluster and the middle axis indexes nodes
            within a cluster.
        weights: Clustered weights with shape ``(tree_count, tree_size)``,
            matching the node layout.

    Returns:
        A tuple containing:
            - The cluster barycenters with shape ``(tree_count, m)``.
            - The cluster masses (sum of weights) with shape ``(tree_count,)``.
    """

    @jax.vmap
    def _per_tree_centroid(
        _nodes: Shaped[Array, "tree_size m"], _weights: Shaped[Array, " tree_size"]
    ) -> tuple[Float[Array, " m"], Float[Array, ""]]:
        tree_centroid_nodes = jnp.nan_to_num(jnp.average(_nodes, 0, _weights))
        tree_centroid_weights = jnp.sum(_weights)
        return tree_centroid_nodes, tree_centroid_weights

    return _per_tree_centroid(nodes, weights)
