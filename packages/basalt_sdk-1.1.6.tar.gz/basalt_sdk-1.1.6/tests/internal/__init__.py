"""Tests for internal utilities."""
