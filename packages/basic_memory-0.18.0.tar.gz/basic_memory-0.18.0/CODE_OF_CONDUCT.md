# Code of Conduct

## Purpose

Maintain a respectful and professional environment where contributions can be made without harassment or
negativity.

## Standards

Respectful communication and collaboration are expected. Offensive behavior, harassment, or personal attacks will not be
tolerated.

## Reporting Issues

To report inappropriate behavior, contact [paul@basicmachines.co].

## Consequences

Violations of this code may lead to consequences, including being banned from contributing to the project.
