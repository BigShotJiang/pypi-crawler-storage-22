"""basic-memory - Local-first knowledge management combining Zettelkasten with knowledge graphs"""

# Package version - updated by release automation
__version__ = "0.18.0"

# API version for FastAPI - independent of package version
__api_version__ = "v0"
