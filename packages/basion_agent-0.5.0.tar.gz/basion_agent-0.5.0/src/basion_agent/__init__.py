"""Basion AI Agent SDK - Synchronous Python framework for building AI agents."""

__version__ = "0.4.0"

from .app import BasionAgentApp
from .agent import Agent
from .message import Message
from .conversation import Conversation
from .conversation_client import ConversationClient
from .conversation_message import ConversationMessage
from .checkpoint_client import CheckpointClient
from .memory import Memory
from .memory_client import (
    MemoryClient,
    MemoryMessage,
    MemorySearchResult,
    UserSummary,
)
from .memory_v2 import MemoryV2
from .memory_v2_client import MemoryV2Client
from .attachment_client import AttachmentClient, AttachmentInfo
from .streamer import Streamer
from .structural import Artifact, Surface, TextBlock, Stepper
from .loki_handler import LokiLogHandler
from .tools import Tools, KnowledgeGraphTool
from .exceptions import (
    BasionAgentError,
    RegistrationError,
    KafkaError,
    ConfigurationError,
    APIException,
    HeartbeatError,
)

__all__ = [
    "BasionAgentApp",
    "Agent",
    "Message",
    "Conversation",
    "ConversationClient",
    "ConversationMessage",
    "CheckpointClient",
    "Memory",
    "MemoryClient",
    "MemoryMessage",
    "MemorySearchResult",
    "UserSummary",
    "MemoryV2",
    "MemoryV2Client",
    "AttachmentClient",
    "AttachmentInfo",
    "Streamer",
    "Artifact",
    "Surface",
    "TextBlock",
    "Stepper",
    "LokiLogHandler",
    "Tools",
    "KnowledgeGraphTool",
    "BasionAgentError",
    "RegistrationError",
    "KafkaError",
    "ConfigurationError",
    "APIException",
    "HeartbeatError",
]
