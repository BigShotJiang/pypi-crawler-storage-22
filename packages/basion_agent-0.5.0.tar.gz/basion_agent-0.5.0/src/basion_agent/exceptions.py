"""Custom exceptions for Basion AI Agent framework."""


class BasionAgentError(Exception):
    """Base exception for all Basion Agent errors."""
    pass


class RegistrationError(BasionAgentError):
    """Raised when agent registration fails."""
    pass


class KafkaError(BasionAgentError):
    """Raised when Kafka operations fail."""
    pass


class HeartbeatError(BasionAgentError):
    """Raised when heartbeat operations fail."""
    pass


class MessageHandlerError(BasionAgentError):
    """Raised when message handler execution fails."""
    pass


class ConfigurationError(BasionAgentError):
    """Raised when configuration is invalid."""
    pass


class APIException(BasionAgentError):
    """Raised when conversation-store API requests fail."""
    pass
