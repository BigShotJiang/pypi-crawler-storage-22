"""Memory V2 context for accessing mem0-backed memory from message handler."""

from typing import List, Any

from .memory_v2_client import MemoryV2Client


class MemoryV2:
    """User-facing mem0 memory context, attached to Message.

    Provides easy access to mem0 memory functions scoped to the current
    user/conversation.
    """

    def __init__(self, user_id: str, conversation_id: str, client: MemoryV2Client):
        self.user_id = user_id
        self.conversation_id = conversation_id
        self._client = client

    async def search(self, query: str) -> List[Any]:
        """Search mem0 memories for the current user.

        Args:
            query: Semantic search query

        Returns:
            List of mem0 search results
        """
        return await self._client.search(query=query, user_id=self.user_id)

    async def ingest(self, role: str, content: str) -> Any:
        """Ingest a message into mem0 memory for the current user/conversation.

        Args:
            role: Message role ('user', 'assistant', or 'system')
            content: Message content to ingest

        Returns:
            mem0 ingestion result
        """
        return await self._client.ingest(
            user_id=self.user_id,
            content=content,
            role=role,
            conversation_id=self.conversation_id,
        )
