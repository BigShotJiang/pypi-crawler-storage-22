"""Tools container - accessed via agent.tools property."""

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .knowledge_graph import KnowledgeGraphTool


class Tools:
    """
    Container for all available tools.

    Accessed via agent.tools property (similar to agent.streamer(message)):
        kg = agent.tools.knowledge_graph
        diseases = await kg.search_diseases(name="Huntington")

    Tools are lazy-initialized - no overhead if not used.
    """

    def __init__(self, gateway_client):
        self._gateway_client = gateway_client
        self._knowledge_graph: Optional["KnowledgeGraphTool"] = None

    @property
    def knowledge_graph(self) -> "KnowledgeGraphTool":
        """
        Knowledge Graph tool for querying biomedical entities and relationships.

        Example:
            kg = agent.tools.knowledge_graph
            diseases = await kg.search_diseases(name="Huntington")
            similar = await kg.find_similar_diseases("Huntington Disease")
            path = await kg.find_shortest_path("BRCA1", "protein", "Breast Cancer", "disease")
        """
        if self._knowledge_graph is None:
            from .knowledge_graph import KnowledgeGraphTool

            self._knowledge_graph = KnowledgeGraphTool(
                self._gateway_client.knowledge_graph_url
            )
        return self._knowledge_graph

    async def close(self):
        """Close all tool sessions."""
        if self._knowledge_graph:
            await self._knowledge_graph.close()
