# Bastion AI

Supply-chain security, capability intelligence, and trust system for AI agents.

Bastion AI protects bot-first ecosystems by detecting malicious or risky skills/plugins/tools, tracking capability drift over time, and producing machine-readable security artifacts (Dynamic AIBOM).

## Installation

```bash
pip install bastion-ai-security
```

For JavaScript/TypeScript analysis support:

```bash
pip install bastion-ai-security[js]
```

PyPI: https://pypi.org/project/bastion-ai-security/

## Quick Start

### Initialize a project

```bash
cd your-agent-project
bastion init
```

This creates a `.bastion/` directory with project configuration and prepares for scanning.

### Scan for risks

```bash
bastion scan
```

Bastion auto-discovers plugins, skills, and tools in your project and analyzes them for:

- **System execution** — subprocess, os.system, child_process, etc.
- **Network access** — requests, fetch, urllib, etc.
- **Secret/environment access** — os.environ, process.env, dotenv, etc.
- **Dynamic code execution** — eval, exec, Function constructor, etc.
- **Obfuscation patterns** — base64+exec, encoded strings, etc.

### Check project status

```bash
bastion status
```

### Connect to Bastion Cloud

```bash
bastion connect
```

Links your project to Bastion Cloud for continuous monitoring, trust scores, and a security dashboard.

After connecting, the CLI prints a **claim URL** — click it to link the project to your account on the dashboard. If you're not signed in yet, you'll be prompted to sign in first, and the project will be linked automatically.

Dashboard: https://bastion-ai-hub.replit.app

## How It Works

### Plugin Discovery

Bastion automatically finds plugins by scanning:
- Known framework directories (`skills/`, `tools/`, `plugins/`, `extensions/`)
- Framework-specific patterns (OpenClaw, LangChain, AutoGPT, CrewAI)
- File naming conventions (`*_skill.py`, `*_tool.js`, etc.)

### Capability Analysis

Each discovered plugin is analyzed using:
- **Python**: AST-based static analysis
- **JavaScript/TypeScript**: esprima parsing with regex fallback

### Risk Levels

| Level | Description |
|-------|-------------|
| Critical | System execution, dynamic code, obfuscation detected |
| High | Network access, secret/env access detected |
| Medium | New plugin without dangerous capabilities |
| Low | No risky capabilities detected |

### Drift Detection

On subsequent scans, Bastion compares against the baseline to detect:
- **New plugins** added since last scan
- **Modified plugins** with changed capabilities
- **Removed plugins** no longer present

### Generated Artifacts

All artifacts are written to `.bastion/`:

| File | Description |
|------|-------------|
| `security_state.json` | Overall security posture |
| `capability_surface.json` | All plugin capabilities |
| `drift_summary.json` | Changes since last scan |
| `aibom.json` | Dynamic AI Bill of Materials |
| `events.log.jsonl` | Rolling event log |
| `baseline.json` | Baseline for drift comparison |

## CI/CD Usage

```bash
bastion init
bastion scan --ci
```

Exit codes:
- `0` — No high-risk findings
- `1` — High or Critical findings detected

## Language Support

- Python (`.py`)
- JavaScript (`.js`, `.jsx`)
- TypeScript (`.ts`, `.tsx`)

## License

MIT
