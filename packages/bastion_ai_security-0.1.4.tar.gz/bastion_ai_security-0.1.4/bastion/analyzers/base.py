from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

from bastion.models import Capability, Evidence


class BaseAnalyzer(ABC):

    @abstractmethod
    def analyze(self, file_path: str) -> List[Capability]:
        ...
