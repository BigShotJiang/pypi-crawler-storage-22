"""
Package: batabyal

Modules:
- cleaning_module - for cleaning .csv files
- trainer_kit - provides ML utilities for classification problems
"""

__version__ = "1.0.3"
__all__ = ["cleaning_module", "trainer_kit"]