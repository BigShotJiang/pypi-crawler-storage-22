from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from util_common.pydantic_util import show_settings_as_env


class BatchStoreSettings(BaseSettings):
    """Workflow settings class that combines all settings."""

    model_config = SettingsConfigDict(
        case_sensitive=False,
        extra="allow",
    )

    data_root: Path = Field(
        default=Path("/mnt/ssd0/hgj_customs_declaration_training_data/data")
    )  # DATA_ROOT 环境变量
    unify_pages_base_url: str = "http://192.168.8.83:28002"


batch_store_settings = BatchStoreSettings()
show_settings_as_env(batch_store_settings)
