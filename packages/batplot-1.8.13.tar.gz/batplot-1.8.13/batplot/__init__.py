"""batplot: Interactive plotting for battery data visualization."""

__version__ = "1.8.13"

__all__ = ["__version__"]
