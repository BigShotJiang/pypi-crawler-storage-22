"""batplot: Interactive plotting for battery data visualization."""

__version__ = "1.8.6"

__all__ = ["__version__"]
