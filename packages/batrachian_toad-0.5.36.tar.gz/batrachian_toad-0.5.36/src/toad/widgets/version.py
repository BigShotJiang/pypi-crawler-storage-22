from textual.widgets import Static


class Version(Static):
    pass
