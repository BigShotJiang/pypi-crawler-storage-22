"""Alias data model."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from ._base import _parse_datetime


@dataclass(frozen=True)
class Alias:
    """An email alias on a verified domain."""

    id: str
    domain_id: str
    alias: str
    full_email: str
    domain_name: str
    user_id: str
    created_at: datetime | None = None
    updated_at: datetime | None = None
    signature_html: str | None = None
    signature_text: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Alias:
        return cls(
            id=str(data["id"]),
            domain_id=str(data["domain_id"]),
            alias=data["alias"],
            full_email=data["full_email"],
            domain_name=data["domain_name"],
            user_id=str(data["user_id"]),
            created_at=_parse_datetime(data.get("created_at")),
            updated_at=_parse_datetime(data.get("updated_at")),
            signature_html=data.get("signature_html"),
            signature_text=data.get("signature_text"),
        )


@dataclass(frozen=True)
class WarmupTokenResponse:
    """Warmup token governance and stats for one alias token."""

    token: str
    seen_count: int
    unique_sender_count: int
    first_seen_at: datetime | None = None
    last_seen_at: datetime | None = None
    is_allowlisted: bool = False
    is_denylisted: bool = False
    last_backfill_at: datetime | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WarmupTokenResponse:
        return cls(
            token=data["token"],
            seen_count=data.get("seen_count", 0),
            unique_sender_count=data.get("unique_sender_count", 0),
            first_seen_at=_parse_datetime(data.get("first_seen_at")),
            last_seen_at=_parse_datetime(data.get("last_seen_at")),
            is_allowlisted=bool(data.get("is_allowlisted", False)),
            is_denylisted=bool(data.get("is_denylisted", False)),
            last_backfill_at=_parse_datetime(data.get("last_backfill_at")),
        )
