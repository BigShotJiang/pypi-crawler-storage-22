# Baymax - Legal Research Synthesis Tool

**Zero hallucination. Pure extraction.**

Baymax is a powerful MCP server for Claude Desktop that provides extraction-based legal research tools. Unlike AI that generates or summarizes, Baymax extracts actual text from cases - holdings, rules, facts, and procedural posture - with full citations.

## Quick Start (5 minutes)

### Step 1: Install Python Dependencies

```bash
cd "path/to/baymax"
pip install -r requirements.txt
```

### Step 2: Configure Claude Desktop

Add Baymax to your Claude Desktop config file:

**Windows:** `%APPDATA%\Claude\claude_desktop_config.json`
**Mac:** `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "baymax": {
      "command": "python",
      "args": ["C:/path/to/baymax/citation_mcp_text_based.py"]
    }
  }
}
```

Replace the path with your actual installation location.

### Step 3: Restart Claude Desktop

Close and reopen Claude Desktop. You should see "baymax" in your MCP servers.

### Step 4: Start Using

Just ask Claude:
- "Brief this case for me" (paste case text)
- "Extract the holding from Brady v. Maryland"
- "Synthesize the rules across these three cases"
- "Generate a parenthetical for this case"

---

## Features

### Core Extraction Tools

| Tool | Description |
|------|-------------|
| `extract_citation` | Parse case names and citations from text |
| `extract_rules` | Extract holdings, standards, elements, and factors |
| `extract_case_facts` | Extract procedural posture, key facts, and outcome |
| `generate_parenthetical` | Create properly formatted case parentheticals |
| `build_citation_string` | Format citations with signals and pin cites |

### Workflow Tools (One-Click Analysis)

| Tool | Description |
|------|-------------|
| `brief_this_case` | Complete case briefing - facts, rules, holding, parenthetical |
| `synthesize_rules` | Multi-case rule synthesis with hierarchy |
| `validate_brief` | Check brief for citation errors and unsupported assertions |

### Research Tools

| Tool | Description |
|------|-------------|
| `find_similar_holdings` | Match arguments to case holdings |
| `suggest_signals` | Recommend citation signals based on context |
| `analyze_argument_strength` | Evaluate supporting authority strength |

### Deposition Tools

| Tool | Description |
|------|-------------|
| `ingest_deposition` | Parse transcript into searchable Q&A entries |
| `search_deposition` | Find testimony by keyword, topic, or citation |
| `validate_facts_against_record` | Check statement of facts against depositions |

---

## Installation Options

### Basic (MCP Server Only)

```bash
pip install mcp
```

### Recommended (With PDF Support)

```bash
pip install mcp PyPDF2 pdfplumber python-docx
```

### Full Install (All Features)

```bash
pip install -r requirements.txt
```

### Optional: Web UI

Baymax includes a web interface for drag-and-drop case analysis:

```bash
pip install flask
python web_app.py
# Open http://127.0.0.1:5000
```

---

## Usage Examples

### Brief a Case

```
User: Brief this case for me:
[paste case text]

Claude: Uses brief_this_case tool...

CASE BRIEF: Brady v. Maryland
=============================
CITATION: 373 U.S. 83 (1963)

PROCEDURAL POSTURE:
Certiorari to the Court of Appeals of Maryland

KEY FACTS:
- Petitioner and companion were convicted of murder
- Companion admitted the actual killing
- Prosecution withheld companion's confession

HOLDING:
The suppression by the prosecution of evidence favorable
to an accused upon request violates due process where the
evidence is material either to guilt or to punishment.

PARENTHETICAL:
(holding that prosecution's suppression of evidence
favorable to accused violates due process when material
to guilt or punishment)
```

### Synthesize Rules Across Cases

```
User: Synthesize the qualified immunity rules from these cases:
[paste 3 case texts]

Claude: Uses synthesize_rules tool...

RULE SYNTHESIS: Qualified Immunity
==================================
MASTER RULE:
Government officials are entitled to qualified immunity
unless their conduct violated clearly established law.

ELEMENTS:
1. Whether the facts show a constitutional violation
2. Whether the right was clearly established at the time
3. Whether a reasonable official would have known

SOURCES: Harlow v. Fitzgerald, Saucier v. Katz, Pearson v. Callahan
```

### Validate a Brief

```
User: Check this brief section for problems:
[paste brief section]

Claude: Uses validate_brief tool...

VALIDATION REPORT
=================
CITATIONS: 5 found, 4 valid

ISSUES:
[!] "Smith v. Jones, 123 F.3d 456" - citation format error
[!] Assertion on page 3 lacks supporting authority
[!] Signal "see" may be incorrect - consider "see also"

SUGGESTIONS:
- Add pin cite for block quote from Johnson v. State
- Consider distinguishing adverse authority on element 2
```

---

## Requirements

- **Python 3.9+**
- **Claude Desktop** with MCP support
- **Optional:** Tesseract OCR (for scanned PDFs)
- **Optional:** Poppler (for PDF-to-image conversion)

## File Structure

```
baymax/
├── citation_mcp_text_based.py   # MCP server (main entry point)
├── brief_synthesis.py           # Parentheticals, synthesis
├── enhanced_rules.py            # Rule/holding extraction
├── extraction_validation.py     # Validation tools
├── workflows.py                 # Workflow orchestration
├── deposition_tools.py          # Deposition processing
├── web_app.py                   # Optional web UI
├── templates/
│   └── index.html               # Web UI template
├── requirements.txt             # Python dependencies
├── pyproject.toml               # Package configuration
└── README.md                    # This file
```

## Troubleshooting

### "MCP server not connecting"

1. Check the path in `claude_desktop_config.json` is correct
2. Ensure Python is in your PATH
3. Try running `python citation_mcp_text_based.py` directly to see errors

### "Module not found"

```bash
pip install mcp
```

### "PDF extraction not working"

```bash
pip install PyPDF2 pdfplumber
```

### "DOCX export not working"

```bash
pip install python-docx
```

---

## How It Works

Baymax uses **pattern-based extraction** - not AI generation. Every piece of text returned is extracted directly from the source document using legal-specific regex patterns:

1. **Holdings**: Patterns like "We hold that...", "The court held..."
2. **Rules**: "Under [standard], a party must..."
3. **Facts**: Procedural posture, party actions, key events
4. **Elements**: Numbered lists, "requires that" constructions

This means:
- **No hallucination** - only text from your documents
- **Verifiable** - check every extraction against the source
- **Citation-ready** - formatted for immediate use

---

## License

MIT License - Free for personal and professional use.

## Contributing

Issues and PRs welcome at the project repository.

---

**Baymax** - Extraction-based legal research synthesis for Claude Desktop.
