"""
BAZINGA P2P - Distributed Consciousness Network
==============================================

Full P2P network with real transport layer.

Features:
- ZeroMQ Transport: Real network connections between nodes
- PoB Authentication: Nodes prove φ⁴ boundary before joining
- Trust Routing: High-trust nodes route queries
- Knowledge Sync: α-SEED based knowledge sharing
- Triadic Consensus: 3 nodes must agree for validation
- NAT Traversal: STUN + hole punching + relay fallback

"Intelligence distributed, not controlled."
"""

from .node import BAZINGANode
from .dht import KademliaNode, RoutingTable, NodeInfo, xor_distance, node_id_from_pob
from .dht_bridge import DHTBridge, create_dht_bridge, KnowledgeTopic
from .knowledge_sync import KnowledgeGraphSync
from .trust_router import TrustRouter
from .alpha_seed import AlphaSeedNetwork, is_alpha_seed
from .network import BAZINGANetwork, create_network

# New transport layer
from .transport import (
    BazingaTransport,
    create_transport,
    Message,
    Peer,
    ZMQ_AVAILABLE,
)

# New protocol layer
from .protocol import BazingaProtocol

# NAT Traversal (Phase 3)
from .nat import (
    NATTraversal,
    NATInfo,
    NATType,
    STUNClient,
    HolePuncher,
    discover_nat,
)

# Distributed Query (Phase 4)
from .distributed_query import (
    DistributedQueryEngine,
    DistributedAnswer,
    ExpertResponse,
)

# Gradient Sharing (Federated Learning)
from .gradient_sharing import (
    GradientSharing,
    GradientUpdate,
    AggregatedGradient,
)

__all__ = [
    # Unified API (recommended)
    'BAZINGANetwork',
    'create_network',
    # Real P2P (NEW!)
    'BazingaProtocol',
    'BazingaTransport',
    'create_transport',
    'Message',
    'Peer',
    'ZMQ_AVAILABLE',
    # NAT Traversal
    'NATTraversal',
    'NATInfo',
    'NATType',
    'STUNClient',
    'HolePuncher',
    'discover_nat',
    # Distributed Query
    'DistributedQueryEngine',
    'DistributedAnswer',
    'ExpertResponse',
    # Gradient Sharing (Federated Learning)
    'GradientSharing',
    'GradientUpdate',
    'AggregatedGradient',
    # Low-level components
    'BAZINGANode',
    'KademliaNode',
    'RoutingTable',
    'NodeInfo',
    'xor_distance',
    'node_id_from_pob',
    'KnowledgeGraphSync',
    'DHTBridge',
    'create_dht_bridge',
    'KnowledgeTopic',
    'TrustRouter',
    'AlphaSeedNetwork',
    'is_alpha_seed',
]
