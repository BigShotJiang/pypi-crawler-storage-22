# Copyright 2026 EcoFuture Technology Services LLC and contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from django.apps import apps

from bazis.core.apps import BaseConfig
from bazis.core.utils.imp import import_module, pkg_load


class BgConfig(BaseConfig):
    name = 'bazis.contrib.bg'
    verbose_name = 'Background tasks'

    def ready(self):
        super().ready()

        # perform loading of bg packages of connected applications
        for app in apps.get_app_configs():
            try:
                bg_pkg = import_module(f'{app.module.__name__}.bg')
            except ModuleNotFoundError:
                pass
            else:
                pkg_load(bg_pkg)

