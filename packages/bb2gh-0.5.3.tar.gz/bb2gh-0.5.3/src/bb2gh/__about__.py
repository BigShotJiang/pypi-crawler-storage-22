"""Version information for bb2gh."""

__version__ = "0.5.3"
