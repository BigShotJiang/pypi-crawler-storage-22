"""GitHub base adapter for bb2gh.

Provides shared logic for all GitHub adapter variants:
- GitHub Cloud
- GitHub Cloud with Data Residency
- GitHub Enterprise Server

Supports multiple authentication methods:
- Personal Access Token (PAT)
- Fine-grained Personal Access Token
- GitHub App installation token
"""

from __future__ import annotations

import time
from abc import abstractmethod
from typing import TYPE_CHECKING, Any, Literal

import httpx
import structlog

from bb2gh.adapters.base import TargetAdapter
from bb2gh.exceptions import APIError, AuthenticationError, ConfigurationError

if TYPE_CHECKING:
    from bb2gh.models.branch_protection import GitHubRulesetConfig
    from bb2gh.models.repository import Repository
    from bb2gh.models.user import User

logger = structlog.get_logger(__name__)


class GitHubBaseAdapter(TargetAdapter):
    """Base class for GitHub API adapters.

    Provides shared functionality for all GitHub variants including:
    - Authentication (PAT, fine-grained PAT, GitHub App)
    - HTTP client management
    - Request/response handling
    - Rate limit handling

    Subclasses must implement:
    - api_url property: Return the base API URL
    - api_version property: Return the API version (optional)

    Example usage:
        # PAT auth
        adapter = GitHubCloudAdapter(token="ghp_xxx")

        # GitHub App auth
        adapter = GitHubCloudAdapter(
            app_id=12345,
            private_key="-----BEGIN RSA PRIVATE KEY-----...",
            installation_id=67890,
        )

        async with adapter:
            repos = await adapter.list_repositories(organization="myorg")
    """

    def __init__(
        self,
        *,
        token: str | None = None,
        app_id: int | None = None,
        private_key: str | None = None,
        installation_id: int | None = None,
        ssl_verify: str | bool = True,
    ) -> None:
        """Initialize GitHub adapter.

        Args:
            token: Personal Access Token (classic or fine-grained).
            app_id: GitHub App ID.
            private_key: GitHub App private key (PEM format).
            installation_id: GitHub App installation ID.
            ssl_verify: SSL verification setting — ``True`` for default
                certifi verification, or a string path to a custom CA
                bundle (PEM).  Passed to ``httpx.AsyncClient(verify=...)``.

        Raises:
            ConfigurationError: If authentication is not properly configured.
        """
        self._token = token
        self._app_id = app_id
        self._private_key = private_key
        self._installation_id = installation_id
        self._ssl_verify = ssl_verify

        # Installation token state (for GitHub App auth)
        self._installation_token: str | None = None
        self._installation_token_expires_at: float = 0

        # HTTP client (created lazily)
        self._client: httpx.AsyncClient | None = None

        # Validate configuration
        self._validate_auth_config()

        # Log initialization (without credentials)
        logger.debug(
            "github_adapter_initialized",
            auth_type=self.auth_type,
            api_url=self.api_url,
        )

    def _validate_auth_config(self) -> None:
        """Validate authentication configuration.

        Raises:
            ConfigurationError: If auth config is invalid or incomplete.
        """
        has_token = self._token is not None
        has_app = any([self._app_id, self._private_key, self._installation_id])

        if not has_token and not has_app:
            raise ConfigurationError(
                "GitHub authentication required. Provide either:\n"
                "  - token for Personal Access Token auth, or\n"
                "  - app_id, private_key, and installation_id for GitHub App auth"
            )

        # Check for incomplete GitHub App config
        if has_app:
            missing = []
            if self._app_id is None:
                missing.append("app_id")
            if self._private_key is None:
                missing.append("private_key")
            if self._installation_id is None:
                missing.append("installation_id")

            if missing:
                raise ConfigurationError(
                    f"Incomplete GitHub App configuration: {', '.join(missing)} required"
                )

    @property
    def auth_type(self) -> Literal["token", "app"]:
        """Get the authentication type being used."""
        if self._token is not None:
            return "token"
        return "app"

    @property
    @abstractmethod
    def api_url(self) -> str:
        """Get the API base URL.

        Subclasses must implement this to return the appropriate URL.
        """
        ...

    @property
    def api_version(self) -> str:
        """Get the API version header value.

        Returns the API version to use in the X-GitHub-Api-Version header.
        Default is "2022-11-28" (latest stable version).
        """
        return "2022-11-28"

    def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(30.0),
                follow_redirects=True,
                verify=self._ssl_verify,
            )
        return self._client

    async def _get_auth_headers(self) -> dict[str, str]:
        """Get authentication headers for API requests.

        Returns:
            Dict with Authorization header.
        """
        if self.auth_type == "token":
            return {"Authorization": f"Bearer {self._token}"}
        else:
            # GitHub App - ensure we have a valid installation token
            await self._ensure_valid_installation_token()
            return {"Authorization": f"Bearer {self._installation_token}"}

    async def _ensure_valid_installation_token(self) -> None:
        """Ensure we have a valid GitHub App installation token.

        Fetches a new token if expired.
        """
        # Check if we need a new token (with 60s buffer)
        if self._installation_token is None or time.time() >= (
            self._installation_token_expires_at - 60
        ):
            await self._fetch_installation_token()

    async def _fetch_installation_token(self) -> None:
        """Fetch GitHub App installation access token.

        Uses JWT authentication to get an installation token.

        Raises:
            AuthenticationError: If token request fails.
        """
        # Generate JWT for App authentication
        jwt_token = self._generate_jwt()

        client = self._get_client()
        url = f"{self.api_url}/app/installations/{self._installation_id}/access_tokens"

        logger.debug("fetching_installation_token", installation_id=self._installation_id)

        try:
            response = await client.post(
                url,
                headers={
                    "Authorization": f"Bearer {jwt_token}",
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": self.api_version,
                },
            )

            if response.status_code == 401:
                raise AuthenticationError(
                    "GitHub App authentication failed: Invalid app credentials"
                )

            if response.status_code == 404:
                raise AuthenticationError(
                    f"GitHub App installation not found: {self._installation_id}"
                )

            response.raise_for_status()
            token_data = response.json()

            self._installation_token = token_data["token"]
            # Parse ISO format expiration
            expires_at = token_data.get("expires_at", "")
            if expires_at:
                from datetime import datetime

                dt = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
                self._installation_token_expires_at = dt.timestamp()
            else:
                # Default to 1 hour
                self._installation_token_expires_at = time.time() + 3600

            logger.debug(
                "installation_token_obtained",
                expires_in=int(self._installation_token_expires_at - time.time()),
            )

        except httpx.HTTPStatusError as e:
            raise AuthenticationError(
                f"Failed to obtain installation token: {e.response.status_code}"
            ) from e

    def _generate_jwt(self) -> str:
        """Generate a JWT for GitHub App authentication.

        Returns:
            JWT token string.

        Raises:
            ConfigurationError: If JWT generation fails.
        """
        try:
            import jwt  # type: ignore[import-not-found]  # optional dependency
        except ImportError as err:
            raise ConfigurationError(
                "PyJWT is required for GitHub App authentication. "
                "Install it with: pip install PyJWT"
            ) from err

        now = int(time.time())
        payload = {
            "iat": now - 60,  # Issued 60 seconds ago to account for clock drift
            "exp": now + 600,  # Expires in 10 minutes
            "iss": self._app_id,
        }

        try:
            result: str = jwt.encode(payload, self._private_key, algorithm="RS256")
            return result
        except Exception as e:
            raise ConfigurationError(f"Failed to generate JWT: {e}") from e

    async def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Make an authenticated API request.

        Args:
            method: HTTP method.
            path: API path (relative to base URL).
            **kwargs: Additional arguments for httpx request.

        Returns:
            HTTP response.
        """
        client = self._get_client()
        headers = await self._get_auth_headers()

        # Add standard GitHub headers
        headers["Accept"] = "application/vnd.github+json"
        headers["X-GitHub-Api-Version"] = self.api_version

        # Merge with any provided headers
        if "headers" in kwargs:
            headers.update(kwargs.pop("headers"))

        url = f"{self.api_url}/{path.lstrip('/')}"
        return await client.request(method, url, headers=headers, **kwargs)

    async def _graphql(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make a GraphQL API request.

        Args:
            query: GraphQL query or mutation.
            variables: Optional variables for the query.

        Returns:
            GraphQL response data.

        Raises:
            APIError: If the request fails.
        """
        client = self._get_client()
        headers = await self._get_auth_headers()
        headers["Accept"] = "application/vnd.github+json"

        # GraphQL endpoint
        graphql_url = self.api_url.replace("/api/v3", "").rstrip("/") + "/graphql"
        if "api.github.com" in self.api_url:
            graphql_url = "https://api.github.com/graphql"

        payload: dict[str, Any] = {"query": query}
        if variables:
            payload["variables"] = variables

        response = await client.post(graphql_url, headers=headers, json=payload)
        response.raise_for_status()

        result: dict[str, Any] = response.json()

        if "errors" in result:
            errors = result["errors"]
            error_msg = "; ".join(e.get("message", str(e)) for e in errors)
            raise APIError(f"GraphQL error: {error_msg}")

        data: dict[str, Any] = result.get("data", {})
        return data

    # =========================================================================
    # Enterprise Importer API Methods
    # =========================================================================

    async def get_organization_id(self, org: str) -> str | None:
        """Get the GraphQL node ID for an organization.

        Args:
            org: Organization name.

        Returns:
            Organization node ID, or None if not found.
        """
        query = """
        query($login: String!) {
            organization(login: $login) {
                id
                login
            }
        }
        """
        try:
            result = await self._graphql(query, {"login": org})
            org_data = result.get("organization")
            return org_data.get("id") if org_data else None
        except Exception as e:
            logger.warning("failed_to_get_org_id", org=org, error=str(e))
            return None

    async def check_enterprise_importer_access(self) -> bool:
        """Check if the current token has access to Enterprise Importer.

        Returns:
            True if Enterprise Importer mutations are available.
        """
        # Try to introspect the createMigrationSource mutation
        query = """
        query {
            __type(name: "Mutation") {
                fields {
                    name
                }
            }
        }
        """
        try:
            result = await self._graphql(query)
            fields = result.get("__type", {}).get("fields", [])
            mutation_names = [f.get("name") for f in fields]
            return "createMigrationSource" in mutation_names
        except Exception as e:
            logger.debug("enterprise_importer_check_failed", error=str(e))
            return False

    async def create_migration_source(
        self,
        org_id: str,
        source_name: str,
        source_url: str,
        source_type: str = "BITBUCKET_SERVER",
    ) -> str | None:
        """Create a migration source for Enterprise Importer.

        Args:
            org_id: Organization node ID.
            source_name: Name for the migration source.
            source_url: URL of the source system.
            source_type: Type of source (AZURE_DEVOPS, BITBUCKET_SERVER, GITHUB_ARCHIVE).

        Returns:
            Migration source ID, or None if failed.
        """
        mutation = """
        mutation createMigrationSource(
            $name: String!,
            $url: String!,
            $ownerId: ID!,
            $type: MigrationSourceType!
        ) {
            createMigrationSource(input: {
                name: $name,
                url: $url,
                ownerId: $ownerId,
                type: $type
            }) {
                migrationSource {
                    id
                    name
                    url
                    type
                }
            }
        }
        """
        try:
            result = await self._graphql(
                mutation,
                {
                    "name": source_name,
                    "url": source_url,
                    "ownerId": org_id,
                    "type": source_type,
                },
            )
            source: dict[str, Any] | None = result.get("createMigrationSource", {}).get(
                "migrationSource"
            )
            if source:
                logger.info(
                    "migration_source_created",
                    source_id=source.get("id"),
                    name=source.get("name"),
                )
                source_id: str | None = source.get("id")
                return source_id
            return None
        except Exception as e:
            logger.error("create_migration_source_failed", error=str(e))
            return None

    async def start_repository_migration(
        self,
        migration_source_id: str,
        org_id: str,
        source_repo_url: str,
        target_repo_name: str,
        *,
        git_archive_url: str | None = None,
        metadata_archive_url: str | None = None,
        source_token: str | None = None,
        target_token: str | None = None,
        skip_releases: bool = False,
        target_visibility: str = "private",
        continue_on_error: bool = True,
    ) -> dict[str, Any] | None:
        """Start a repository migration using Enterprise Importer.

        Args:
            migration_source_id: Migration source ID from createMigrationSource.
            org_id: Target organization node ID.
            source_repo_url: URL of the source repository.
            target_repo_name: Name for the target repository.
            git_archive_url: URL to git archive (for archive-based migrations).
            metadata_archive_url: URL to metadata archive (PRs, issues, etc.).
            source_token: Token for accessing source system.
            target_token: Token for target GitHub.
            skip_releases: Skip migrating releases.
            target_visibility: Target repo visibility (private, public, internal).
            continue_on_error: Continue migration even if some items fail.

        Returns:
            Migration info dict with 'id', 'state', etc., or None if failed.
        """
        mutation = """
        mutation startRepositoryMigration(
            $sourceId: ID!,
            $ownerId: ID!,
            $sourceRepositoryUrl: URI!,
            $repositoryName: String!,
            $continueOnError: Boolean!,
            $gitArchiveUrl: String,
            $metadataArchiveUrl: String,
            $accessToken: String,
            $githubPat: String,
            $skipReleases: Boolean,
            $targetRepoVisibility: String
        ) {
            startRepositoryMigration(input: {
                sourceId: $sourceId,
                ownerId: $ownerId,
                sourceRepositoryUrl: $sourceRepositoryUrl,
                repositoryName: $repositoryName,
                continueOnError: $continueOnError,
                gitArchiveUrl: $gitArchiveUrl,
                metadataArchiveUrl: $metadataArchiveUrl,
                accessToken: $accessToken,
                githubPat: $githubPat,
                skipReleases: $skipReleases,
                targetRepoVisibility: $targetRepoVisibility
            }) {
                repositoryMigration {
                    id
                    databaseId
                    sourceUrl
                    state
                    failureReason
                    migrationSource {
                        id
                        name
                        type
                    }
                }
            }
        }
        """
        variables = {
            "sourceId": migration_source_id,
            "ownerId": org_id,
            "sourceRepositoryUrl": source_repo_url,
            "repositoryName": target_repo_name,
            "continueOnError": continue_on_error,
            "skipReleases": skip_releases,
            "targetRepoVisibility": target_visibility,
        }

        if git_archive_url:
            variables["gitArchiveUrl"] = git_archive_url
        if metadata_archive_url:
            variables["metadataArchiveUrl"] = metadata_archive_url
        if source_token:
            variables["accessToken"] = source_token
        if target_token:
            variables["githubPat"] = target_token

        try:
            result = await self._graphql(mutation, variables)
            migration: dict[str, Any] | None = result.get("startRepositoryMigration", {}).get(
                "repositoryMigration"
            )
            if migration:
                logger.info(
                    "repository_migration_started",
                    migration_id=migration.get("id"),
                    state=migration.get("state"),
                )
                return migration
            return None
        except Exception as e:
            logger.error("start_repository_migration_failed", error=str(e))
            return None

    async def get_migration_status(self, migration_id: str) -> dict[str, Any] | None:
        """Get the status of a repository migration.

        Args:
            migration_id: Migration node ID.

        Returns:
            Migration status dict, or None if failed.
        """
        query = """
        query($id: ID!) {
            node(id: $id) {
                ... on Migration {
                    id
                    sourceUrl
                    migrationLogUrl
                    migrationSource {
                        name
                    }
                    state
                    warningsCount
                    failureReason
                    repositoryName
                }
            }
        }
        """
        try:
            result = await self._graphql(query, {"id": migration_id})
            node: dict[str, Any] | None = result.get("node")
            return node
        except Exception as e:
            logger.error("get_migration_status_failed", error=str(e))
            return None

    async def wait_for_migration(
        self,
        migration_id: str,
        *,
        poll_interval: int = 10,
        timeout: int = 3600,
    ) -> dict[str, Any] | None:
        """Wait for a migration to complete.

        Args:
            migration_id: Migration node ID.
            poll_interval: Seconds between status checks.
            timeout: Maximum seconds to wait.

        Returns:
            Final migration status, or None if timeout/failed.
        """
        import asyncio

        elapsed = 0
        while elapsed < timeout:
            status = await self.get_migration_status(migration_id)
            if not status:
                return None

            state = status.get("state")
            logger.debug(
                "migration_status",
                migration_id=migration_id,
                state=state,
            )

            if state in ("SUCCEEDED", "FAILED", "FAILED_VALIDATION"):
                return status

            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

        logger.warning("migration_timeout", migration_id=migration_id)
        return None

    async def verify_credentials(self) -> bool:
        """Verify that credentials are valid.

        Returns:
            True if credentials are valid.

        Raises:
            AuthenticationError: If credentials are invalid.
        """
        logger.debug("verifying_credentials", auth_type=self.auth_type)

        try:
            if self.auth_type == "token":
                # For PAT, verify by getting the authenticated user
                response = await self._request("GET", "/user")
            else:
                # For App, verify the installation has access
                response = await self._request("GET", "/installation/repositories")

            if response.status_code == 401:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get("message", "Invalid credentials")
                raise AuthenticationError(
                    f"GitHub authentication failed: {error_msg}. "
                    "Please verify your credentials are correct."
                )

            response.raise_for_status()

            if self.auth_type == "token":
                user_data = response.json()
                logger.info(
                    "credentials_verified",
                    username=user_data.get("login"),
                    auth_type=self.auth_type,
                )
            else:
                logger.info(
                    "credentials_verified",
                    installation_id=self._installation_id,
                    auth_type=self.auth_type,
                )
            return True

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthenticationError(
                    "GitHub authentication failed: Invalid or expired credentials"
                ) from e
            raise

    # TargetAdapter interface implementation

    async def create_repository(
        self,
        *,
        name: str,
        organization: str,
        description: str | None = None,
        private: bool = True,
        default_branch: str = "main",
    ) -> Repository:
        """Create a new repository in GitHub.

        Args:
            name: Repository name.
            organization: Target organization.
            description: Optional repository description.
            private: Whether the repository should be private.
            default_branch: Default branch name.

        Returns:
            Created Repository model.

        Raises:
            APIError: If creation fails.
        """
        from bb2gh.models.repository import Repository

        logger.debug(
            "creating_repository",
            name=name,
            organization=organization,
            private=private,
        )

        payload: dict[str, Any] = {
            "name": name,
            "private": private,
            "auto_init": False,  # Don't create initial commit
        }

        if description:
            payload["description"] = description

        try:
            response = await self._request(
                "POST",
                f"/orgs/{organization}/repos",
                json=payload,
            )

            if response.status_code == 422:
                error_data = response.json()
                errors = error_data.get("errors", [])
                for error in errors:
                    if error.get("field") == "name":
                        raise APIError(
                            f"Repository name '{name}' already exists or is invalid",
                            status_code=422,
                            response_body=error_data,
                        )
                raise APIError(
                    f"Failed to create repository: {error_data.get('message', 'Unknown error')}",
                    status_code=422,
                    response_body=error_data,
                )

            response.raise_for_status()
            repo_data = response.json()

            logger.info(
                "repository_created",
                name=name,
                full_name=repo_data.get("full_name"),
            )

            return Repository(
                id=str(repo_data["id"]),
                name=repo_data["name"],
                full_name=repo_data["full_name"],
                description=repo_data.get("description"),
                private=repo_data.get("private", True),
                default_branch=repo_data.get("default_branch", default_branch),
                clone_url_https=repo_data.get("clone_url"),
                clone_url_ssh=repo_data.get("ssh_url"),
                size_bytes=(repo_data.get("size", 0) * 1024) if repo_data.get("size") else None,
                owner=repo_data["owner"]["login"],
                created_at=repo_data.get("created_at"),
                updated_at=repo_data.get("updated_at"),
                archived=repo_data.get("archived", False),
                fork=repo_data.get("fork", False),
                source="github",
            )

        except httpx.HTTPStatusError as e:
            raise APIError(
                f"Failed to create repository '{name}': {e.response.status_code}",
                status_code=e.response.status_code,
            ) from e

    async def update_repository(
        self,
        repo_id: str,
        *,
        description: str | None = None,
        private: bool | None = None,
        default_branch: str | None = None,
        archived: bool | None = None,
    ) -> Repository:
        """Update an existing repository.

        Args:
            repo_id: Repository identifier (full name like "org/repo").
            description: New description (if provided).
            private: New visibility (if provided).
            default_branch: New default branch (if provided).
            archived: Whether to archive the repo (if provided).

        Returns:
            Updated Repository model.

        Raises:
            APIError: If update fails.
        """
        from bb2gh.models.repository import Repository

        logger.debug("updating_repository", repo_id=repo_id)

        payload: dict[str, Any] = {}
        if description is not None:
            payload["description"] = description
        if private is not None:
            payload["private"] = private
        if default_branch is not None:
            payload["default_branch"] = default_branch
        if archived is not None:
            payload["archived"] = archived

        if not payload:
            # Nothing to update, just fetch current state
            repo = await self.get_repository(repo_id)
            if repo is None:
                raise APIError(f"Repository not found: {repo_id}", status_code=404)
            return repo

        try:
            response = await self._request(
                "PATCH",
                f"/repos/{repo_id}",
                json=payload,
            )

            if response.status_code == 404:
                raise APIError(f"Repository not found: {repo_id}", status_code=404)

            response.raise_for_status()
            repo_data = response.json()

            logger.info("repository_updated", repo_id=repo_id)

            return Repository(
                id=str(repo_data["id"]),
                name=repo_data["name"],
                full_name=repo_data["full_name"],
                description=repo_data.get("description"),
                private=repo_data.get("private", True),
                default_branch=repo_data.get("default_branch", "main"),
                clone_url_https=repo_data.get("clone_url"),
                clone_url_ssh=repo_data.get("ssh_url"),
                size_bytes=(repo_data.get("size", 0) * 1024) if repo_data.get("size") else None,
                owner=repo_data["owner"]["login"],
                created_at=repo_data.get("created_at"),
                updated_at=repo_data.get("updated_at"),
                archived=repo_data.get("archived", False),
                fork=repo_data.get("fork", False),
                source="github",
            )

        except httpx.HTTPStatusError as e:
            raise APIError(
                f"Failed to update repository '{repo_id}': {e.response.status_code}",
                status_code=e.response.status_code,
            ) from e

    async def get_repository(self, repo_id: str) -> Repository | None:
        """Get a single repository by full name.

        Args:
            repo_id: Repository identifier (full name like "org/repo").

        Returns:
            Repository model if found, None otherwise.
        """
        from bb2gh.models.repository import Repository

        logger.debug("getting_repository", repo_id=repo_id)

        try:
            response = await self._request("GET", f"/repos/{repo_id}")

            if response.status_code == 404:
                return None

            response.raise_for_status()
            repo_data = response.json()

            return Repository(
                id=str(repo_data["id"]),
                name=repo_data["name"],
                full_name=repo_data["full_name"],
                description=repo_data.get("description"),
                private=repo_data.get("private", True),
                default_branch=repo_data.get("default_branch", "main"),
                clone_url_https=repo_data.get("clone_url"),
                clone_url_ssh=repo_data.get("ssh_url"),
                size_bytes=(repo_data.get("size", 0) * 1024) if repo_data.get("size") else None,
                owner=repo_data["owner"]["login"],
                created_at=repo_data.get("created_at"),
                updated_at=repo_data.get("updated_at"),
                archived=repo_data.get("archived", False),
                fork=repo_data.get("fork", False),
                source="github",
            )

        except httpx.HTTPStatusError:
            return None

    async def list_users(
        self,
        *,
        organization: str | None = None,
        page: int = 1,
        page_size: int = 100,
    ) -> list[User]:
        """List users from the organization.

        Args:
            organization: Organization to list users from.
            page: Page number (1-indexed).
            page_size: Items per page.

        Returns:
            List of User models.
        """
        from bb2gh.models.user import User

        if organization is None:
            return []

        logger.debug(
            "listing_users",
            organization=organization,
            page=page,
            page_size=page_size,
        )

        try:
            response = await self._request(
                "GET",
                f"/orgs/{organization}/members",
                params={"page": page, "per_page": page_size},
            )

            if response.status_code == 404:
                return []

            response.raise_for_status()
            members_data = response.json()

            # Enrich with per-user profile data (name, email)
            users: list[User] = []
            for member in members_data:
                login = member["login"]
                name: str | None = None
                email: str | None = None

                try:
                    detail_resp = await self._request("GET", f"/users/{login}")
                    if detail_resp.status_code == 200:
                        detail = detail_resp.json()
                        name = detail.get("name")
                        email = detail.get("email")
                except httpx.HTTPError:
                    logger.debug("user_detail_fetch_failed", login=login)

                users.append(
                    User(
                        id=str(member["id"]),
                        username=login,
                        display_name=name,
                        email=email,
                        avatar_url=member.get("avatar_url"),
                        source="github",
                    )
                )

            return users

        except httpx.HTTPStatusError:
            return []

    # PR-related methods for migration

    async def create_pull_request(
        self,
        repo: str,
        *,
        title: str,
        body: str,
        head: str,
        base: str,
        draft: bool = False,
    ) -> dict[str, Any]:
        """Create a pull request.

        Args:
            repo: Repository name (org/repo).
            title: PR title.
            body: PR body/description.
            head: Source branch.
            base: Target branch.
            draft: Whether to create as draft.

        Returns:
            Dict with PR data including 'number' and 'html_url'.
        """
        logger.debug(
            "creating_pull_request",
            repo=repo,
            head=head,
            base=base,
        )

        data = {
            "title": title,
            "body": body,
            "head": head,
            "base": base,
            "draft": draft,
        }

        response = await self._request(
            "POST",
            f"/repos/{repo}/pulls",
            json=data,
        )
        response.raise_for_status()
        pr_data: dict[str, Any] = response.json()

        logger.info(
            "pull_request_created",
            repo=repo,
            pr_number=pr_data.get("number"),
        )

        return pr_data

    async def update_pull_request(
        self,
        repo: str,
        pr_number: int,
        *,
        state: str | None = None,
        title: str | None = None,
        body: str | None = None,
    ) -> dict[str, Any]:
        """Update a pull request.

        Args:
            repo: Repository name (org/repo).
            pr_number: PR number.
            state: New state ('open' or 'closed').
            title: New title.
            body: New body.

        Returns:
            Dict with updated PR data.
        """
        logger.debug(
            "updating_pull_request",
            repo=repo,
            pr_number=pr_number,
            state=state,
        )

        data: dict[str, str] = {}
        if state is not None:
            data["state"] = state
        if title is not None:
            data["title"] = title
        if body is not None:
            data["body"] = body

        response = await self._request(
            "PATCH",
            f"/repos/{repo}/pulls/{pr_number}",
            json=data,
        )
        response.raise_for_status()
        pr_data: dict[str, Any] = response.json()

        logger.info(
            "pull_request_updated",
            repo=repo,
            pr_number=pr_number,
        )

        return pr_data

    async def request_reviewers(
        self,
        repo: str,
        pr_number: int,
        reviewers: list[str],
    ) -> None:
        """Request reviewers on a PR.

        Args:
            repo: Repository name (org/repo).
            pr_number: PR number.
            reviewers: List of GitHub usernames.
        """
        if not reviewers:
            return

        logger.debug(
            "requesting_reviewers",
            repo=repo,
            pr_number=pr_number,
            reviewers=reviewers,
        )

        await self._request(
            "POST",
            f"/repos/{repo}/pulls/{pr_number}/requested_reviewers",
            json={"reviewers": reviewers},
        )

        logger.info(
            "reviewers_requested",
            repo=repo,
            pr_number=pr_number,
            count=len(reviewers),
        )

    async def ensure_label(
        self,
        repo: str,
        label: str,
        *,
        color: str = "ededed",
    ) -> None:
        """Ensure a label exists in the repository.

        Args:
            repo: Repository name (org/repo).
            label: Label name.
            color: Label color (hex without #).
        """
        try:
            await self._request(
                "GET",
                f"/repos/{repo}/labels/{label}",
            )
        except APIError:
            # Label doesn't exist, create it
            logger.debug("creating_label", repo=repo, label=label)
            await self._request(
                "POST",
                f"/repos/{repo}/labels",
                json={"name": label, "color": color},
            )

    async def add_labels(
        self,
        repo: str,
        issue_number: int,
        labels: list[str],
    ) -> None:
        """Add labels to an issue or PR.

        Args:
            repo: Repository name (org/repo).
            issue_number: Issue/PR number.
            labels: List of label names.
        """
        if not labels:
            return

        logger.debug(
            "adding_labels",
            repo=repo,
            issue_number=issue_number,
            labels=labels,
        )

        await self._request(
            "POST",
            f"/repos/{repo}/issues/{issue_number}/labels",
            json={"labels": labels},
        )

    async def create_issue(
        self,
        repo: str,
        title: str,
        body: str,
        *,
        labels: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create an issue in a repository.

        Args:
            repo: Repository name (org/repo).
            title: Issue title.
            body: Issue body.
            labels: Optional list of label names.

        Returns:
            Dict with issue data including 'number' and 'html_url'.
        """
        logger.debug(
            "creating_issue",
            repo=repo,
            title=title,
        )

        payload: dict[str, Any] = {
            "title": title,
            "body": body,
        }
        if labels:
            payload["labels"] = labels

        response = await self._request(
            "POST",
            f"/repos/{repo}/issues",
            json=payload,
        )
        response.raise_for_status()

        issue: dict[str, Any] = response.json()
        logger.info(
            "issue_created",
            repo=repo,
            issue_number=issue.get("number"),
        )
        return issue

    async def close_issue(
        self,
        repo: str,
        issue_number: int,
    ) -> dict[str, Any]:
        """Close an issue.

        Args:
            repo: Repository name (org/repo).
            issue_number: Issue number.

        Returns:
            Dict with updated issue data.
        """
        logger.debug(
            "closing_issue",
            repo=repo,
            issue_number=issue_number,
        )

        response = await self._request(
            "PATCH",
            f"/repos/{repo}/issues/{issue_number}",
            json={"state": "closed"},
        )
        response.raise_for_status()
        result: dict[str, Any] = response.json()
        return result

    async def create_issue_comment(
        self,
        repo: str,
        issue_number: int,
        body: str,
    ) -> dict[str, Any]:
        """Create a comment on an issue or PR.

        Args:
            repo: Repository name (org/repo).
            issue_number: Issue/PR number.
            body: Comment body.

        Returns:
            Dict with comment data.
        """
        logger.debug(
            "creating_issue_comment",
            repo=repo,
            issue_number=issue_number,
        )

        response = await self._request(
            "POST",
            f"/repos/{repo}/issues/{issue_number}/comments",
            json={"body": body},
        )
        response.raise_for_status()
        result: dict[str, Any] = response.json()
        return result

    # =========================================================================
    # Branch Protection / Rulesets
    # =========================================================================

    def _serialize_ruleset(self, config: GitHubRulesetConfig) -> dict[str, Any]:
        """Serialize a GitHubRulesetConfig to the GitHub API JSON format.

        Args:
            config: Ruleset configuration.

        Returns:
            Dict matching GitHub rulesets API schema.
        """
        rules_payload: list[dict[str, Any]] = []
        for rule in config.rules:
            rule_dict: dict[str, Any] = {"type": rule.type}
            if rule.parameters is not None:
                rule_dict["parameters"] = rule.parameters.model_dump(
                    exclude_defaults=True,
                )
            rules_payload.append(rule_dict)

        payload: dict[str, Any] = {
            "name": config.name,
            "target": config.target.value,
            "enforcement": config.enforcement.value,
            "conditions": {
                "ref_name": {
                    "include": config.conditions.ref_name.include,
                    "exclude": config.conditions.ref_name.exclude,
                },
            },
            "rules": rules_payload,
        }

        if config.bypass_actors:
            payload["bypass_actors"] = [
                {
                    "actor_id": actor.actor_id,
                    "actor_type": actor.actor_type.value,
                    "bypass_mode": actor.bypass_mode.value,
                }
                for actor in config.bypass_actors
            ]

        if config.conditions.repository_name is not None:
            payload["conditions"]["repository_name"] = {
                "include": config.conditions.repository_name.include,
                "exclude": config.conditions.repository_name.exclude,
                "protected": config.conditions.repository_name.protected,
            }

        return payload

    async def create_repository_ruleset(
        self,
        repo: str,
        config: GitHubRulesetConfig,
    ) -> dict[str, Any]:
        """Create a repository-level ruleset.

        Args:
            repo: Repository name (org/repo).
            config: Ruleset configuration.

        Returns:
            Created ruleset data including 'id'.

        Raises:
            APIError: If creation fails (422 duplicate, etc.).
        """
        payload = self._serialize_ruleset(config)

        logger.debug("creating_repository_ruleset", repo=repo, name=config.name)

        response = await self._request(
            "POST",
            f"/repos/{repo}/rulesets",
            json=payload,
        )

        if response.status_code == 422:
            error_data = response.json()
            raise APIError(
                f"Failed to create ruleset '{config.name}': "
                f"{error_data.get('message', 'Validation failed')}",
                status_code=422,
                response_body=error_data,
            )

        response.raise_for_status()
        result: dict[str, Any] = response.json()

        logger.info(
            "repository_ruleset_created",
            repo=repo,
            ruleset_id=result.get("id"),
            name=config.name,
        )
        return result

    async def list_repository_rulesets(
        self,
        repo: str,
    ) -> list[dict[str, Any]]:
        """List repository-level rulesets.

        Args:
            repo: Repository name (org/repo).

        Returns:
            List of ruleset dicts.
        """
        logger.debug("listing_repository_rulesets", repo=repo)

        response = await self._request("GET", f"/repos/{repo}/rulesets")

        if response.status_code == 404:
            return []

        response.raise_for_status()
        result: list[dict[str, Any]] = response.json()
        return result

    async def delete_repository_ruleset(
        self,
        repo: str,
        ruleset_id: int,
    ) -> None:
        """Delete a repository-level ruleset.

        Args:
            repo: Repository name (org/repo).
            ruleset_id: ID of the ruleset to delete.

        Raises:
            APIError: If deletion fails.
        """
        logger.debug(
            "deleting_repository_ruleset",
            repo=repo,
            ruleset_id=ruleset_id,
        )

        response = await self._request(
            "DELETE",
            f"/repos/{repo}/rulesets/{ruleset_id}",
        )

        if response.status_code == 404:
            raise APIError(
                f"Ruleset {ruleset_id} not found in {repo}",
                status_code=404,
            )

        response.raise_for_status()

        logger.info(
            "repository_ruleset_deleted",
            repo=repo,
            ruleset_id=ruleset_id,
        )

    async def create_organization_ruleset(
        self,
        org: str,
        config: GitHubRulesetConfig,
    ) -> dict[str, Any]:
        """Create an organization-level ruleset.

        Args:
            org: Organization name.
            config: Ruleset configuration.

        Returns:
            Created ruleset data including 'id'.

        Raises:
            APIError: If creation fails (403 permissions, 422 validation).
        """
        payload = self._serialize_ruleset(config)

        logger.debug("creating_organization_ruleset", org=org, name=config.name)

        response = await self._request(
            "POST",
            f"/orgs/{org}/rulesets",
            json=payload,
        )

        if response.status_code == 403:
            error_data = response.json() if response.content else {}
            raise APIError(
                f"Insufficient permissions to create org ruleset in '{org}': "
                f"{error_data.get('message', 'Forbidden')}",
                status_code=403,
                response_body=error_data,
            )

        if response.status_code == 422:
            error_data = response.json()
            raise APIError(
                f"Failed to create org ruleset '{config.name}': "
                f"{error_data.get('message', 'Validation failed')}",
                status_code=422,
                response_body=error_data,
            )

        response.raise_for_status()
        result: dict[str, Any] = response.json()

        logger.info(
            "organization_ruleset_created",
            org=org,
            ruleset_id=result.get("id"),
            name=config.name,
        )
        return result

    async def list_organization_rulesets(
        self,
        org: str,
    ) -> list[dict[str, Any]]:
        """List organization-level rulesets.

        Args:
            org: Organization name.

        Returns:
            List of ruleset dicts.
        """
        logger.debug("listing_organization_rulesets", org=org)

        response = await self._request("GET", f"/orgs/{org}/rulesets")

        if response.status_code == 404:
            return []

        response.raise_for_status()
        result: list[dict[str, Any]] = response.json()
        return result

    async def delete_organization_ruleset(
        self,
        org: str,
        ruleset_id: int,
    ) -> None:
        """Delete an organization-level ruleset.

        Args:
            org: Organization name.
            ruleset_id: ID of the ruleset to delete.

        Raises:
            APIError: If deletion fails.
        """
        logger.debug(
            "deleting_organization_ruleset",
            org=org,
            ruleset_id=ruleset_id,
        )

        response = await self._request(
            "DELETE",
            f"/orgs/{org}/rulesets/{ruleset_id}",
        )

        if response.status_code == 404:
            raise APIError(
                f"Org ruleset {ruleset_id} not found in {org}",
                status_code=404,
            )

        response.raise_for_status()

        logger.info(
            "organization_ruleset_deleted",
            org=org,
            ruleset_id=ruleset_id,
        )

    async def enable_auto_merge(self, repo: str) -> None:
        """Enable auto-merge on a repository.

        Args:
            repo: Repository name (org/repo).

        Raises:
            APIError: If enabling fails.
        """
        logger.debug("enabling_auto_merge", repo=repo)

        response = await self._request(
            "PATCH",
            f"/repos/{repo}",
            json={"allow_auto_merge": True},
        )

        if response.status_code == 403:
            error_data = response.json() if response.content else {}
            raise APIError(
                f"Cannot enable auto-merge on '{repo}': {error_data.get('message', 'Forbidden')}",
                status_code=403,
                response_body=error_data,
            )

        response.raise_for_status()

        logger.info("auto_merge_enabled", repo=repo)

    async def close(self) -> None:
        """Close HTTP client and release resources."""
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
            logger.debug("github_client_closed")

    def __repr__(self) -> str:
        """Return string representation without exposing credentials."""
        return f"{self.__class__.__name__}(auth_type={self.auth_type!r}, api_url={self.api_url!r})"

    def __str__(self) -> str:
        """Return string representation."""
        return f"{self.__class__.__name__}({self.auth_type})"
