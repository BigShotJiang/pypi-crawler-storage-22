"""GitHub Enterprise Server adapter for bb2gh.

Implements the TargetAdapter interface for GitHub Enterprise Server (on-premises).
Supports configurable base URLs and API version checks.
"""

from __future__ import annotations

from typing import Any

import httpx
import structlog

from bb2gh.adapters.github_base import GitHubBaseAdapter
from bb2gh.exceptions import APIError, ConfigurationError

logger = structlog.get_logger(__name__)

# Minimum supported GHES version
MIN_SUPPORTED_VERSION = "3.8"


class GitHubServerAdapter(GitHubBaseAdapter):
    """GitHub Enterprise Server API adapter.

    Connects to on-premises GitHub Enterprise Server installations.
    Supports API version validation and custom endpoints.

    Example usage:
        adapter = GitHubServerAdapter(
            token="ghp_xxx",
            base_url="https://github.mycompany.com",
        )

        # Check server version
        version = await adapter.get_server_version()

        async with adapter:
            repo = await adapter.create_repository(
                name="my-repo",
                organization="my-org",
            )
    """

    def __init__(
        self,
        *,
        base_url: str,
        token: str | None = None,
        app_id: int | None = None,
        private_key: str | None = None,
        installation_id: int | None = None,
        skip_version_check: bool = False,
    ) -> None:
        """Initialize GitHub Enterprise Server adapter.

        Args:
            base_url: GitHub Enterprise Server base URL (e.g., https://github.mycompany.com).
            token: Personal Access Token (classic or fine-grained).
            app_id: GitHub App ID.
            private_key: GitHub App private key (PEM format).
            installation_id: GitHub App installation ID.
            skip_version_check: Skip server version validation.

        Raises:
            ConfigurationError: If configuration is invalid.
        """
        # Validate base URL
        if not base_url:
            raise ConfigurationError(
                "GitHub Enterprise Server requires a base_url. "
                "Example: https://github.mycompany.com"
            )

        if not base_url.startswith("https://"):
            raise ConfigurationError("base_url must be a valid HTTPS URL")

        # Construct API URL (GHES uses /api/v3 path)
        self._base_url = base_url.rstrip("/")
        self._api_url = f"{self._base_url}/api/v3"
        self._skip_version_check = skip_version_check

        # Server version (fetched lazily)
        self._server_version: str | None = None

        # Initialize base class
        super().__init__(
            token=token,
            app_id=app_id,
            private_key=private_key,
            installation_id=installation_id,
        )

        logger.debug(
            "github_server_adapter_initialized",
            base_url=self._base_url,
            api_url=self._api_url,
        )

    @property
    def api_url(self) -> str:
        """Get the API URL for GHES."""
        return self._api_url

    @property
    def base_url(self) -> str:
        """Get the base URL for the GitHub Enterprise Server."""
        return self._base_url

    @property
    def server_version(self) -> str | None:
        """Get the cached server version (None if not yet fetched)."""
        return self._server_version

    async def get_server_version(self) -> str:
        """Fetch and cache the GitHub Enterprise Server version.

        Returns:
            Server version string (e.g., "3.12.0").

        Raises:
            APIError: If version cannot be determined.
        """
        if self._server_version is not None:
            return self._server_version

        logger.debug("fetching_server_version", base_url=self._base_url)

        try:
            # GHES exposes version via meta endpoint
            response = await self._request("GET", "/meta")
            response.raise_for_status()

            meta_data = response.json()
            version = meta_data.get("installed_version")

            if not version:
                # Try alternate method: check response headers
                version = response.headers.get("X-GitHub-Enterprise-Version")

            if not version:
                raise APIError(
                    "Unable to determine GitHub Enterprise Server version",
                    status_code=response.status_code,
                )

            self._server_version = str(version)
            logger.info("server_version_detected", version=version)

            return self._server_version

        except httpx.HTTPStatusError as e:
            raise APIError(
                f"Failed to get server version: {e.response.status_code}",
                status_code=e.response.status_code,
            ) from e

    async def check_version_compatibility(self) -> bool:
        """Check if the server version is compatible.

        Returns:
            True if version is compatible.

        Raises:
            APIError: If version is incompatible or cannot be determined.
        """
        if self._skip_version_check:
            logger.debug("version_check_skipped")
            return True

        version = await self.get_server_version()

        # Parse version (handle formats like "3.12.0" or "3.12")
        try:
            parts = version.split(".")
            major = int(parts[0])
            minor = int(parts[1]) if len(parts) > 1 else 0
        except (ValueError, IndexError):
            logger.warning("version_parse_failed", version=version)
            return True  # Assume compatible if can't parse

        min_parts = MIN_SUPPORTED_VERSION.split(".")
        min_major = int(min_parts[0])
        min_minor = int(min_parts[1]) if len(min_parts) > 1 else 0

        if major < min_major or (major == min_major and minor < min_minor):
            raise APIError(
                f"GitHub Enterprise Server version {version} is not supported. "
                f"Minimum required version is {MIN_SUPPORTED_VERSION}."
            )

        logger.debug(
            "version_compatible",
            version=version,
            min_version=MIN_SUPPORTED_VERSION,
        )
        return True

    async def verify_credentials(self) -> bool:
        """Verify credentials and optionally check server version.

        Returns:
            True if credentials and version are valid.

        Raises:
            AuthenticationError: If credentials are invalid.
            APIError: If version is incompatible.
        """
        # Verify credentials first
        await super().verify_credentials()

        # Then check version compatibility
        await self.check_version_compatibility()

        return True

    async def get_server_info(self) -> dict[str, Any]:
        """Get detailed server information.

        Returns:
            Dict with server metadata.
        """
        logger.debug("fetching_server_info", base_url=self._base_url)

        try:
            response = await self._request("GET", "/meta")
            response.raise_for_status()
            result: dict[str, Any] = response.json()
            return result
        except httpx.HTTPStatusError:
            return {}

    def __repr__(self) -> str:
        """Return string representation without exposing credentials."""
        return f"GitHubServerAdapter(auth_type={self.auth_type!r}, base_url={self._base_url!r})"
