"""CLI package for bb2gh.

This package provides the command-line interface for the bb2gh migration tool.
"""

from bb2gh.cli.app import app

__all__ = ["app"]
