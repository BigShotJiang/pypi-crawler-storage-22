"""Console utilities for bb2gh CLI.

Provides a configured Rich console with TTY detection and color support.
"""

from __future__ import annotations

import os
import sys
from typing import IO

from rich.console import Console

# Module-level cached console instance
_console: Console | None = None


def is_tty(stream: IO[str] | None) -> bool:
    """Check if a stream is a TTY.

    Args:
        stream: The stream to check, or None.

    Returns:
        True if the stream is a TTY, False otherwise.
    """
    if stream is None:
        return False
    try:
        return stream.isatty()
    except AttributeError:
        return False


def get_console(
    *,
    force_terminal: bool | None = None,
    no_color: bool | None = None,
) -> Console:
    """Get a configured Rich console instance.

    The console respects:
    - NO_COLOR environment variable (disables colors)
    - TTY detection (auto-disables rich output when not a terminal)
    - Force terminal mode for testing

    Args:
        force_terminal: Force terminal mode (useful for testing).
        no_color: Force no-color mode. If None, respects NO_COLOR env var.

    Returns:
        A configured Rich Console instance.
    """
    # Check NO_COLOR environment variable
    if no_color is None:
        no_color = os.environ.get("NO_COLOR") is not None

    # Determine terminal status
    is_terminal = force_terminal if force_terminal is not None else is_tty(sys.stdout)

    return Console(
        force_terminal=force_terminal,
        no_color=no_color,
        highlight=is_terminal,
        markup=True,
    )


def get_shared_console() -> Console:
    """Get the shared console instance (singleton).

    Creates the console on first call, returns cached instance after.

    Returns:
        The shared Rich Console instance.
    """
    global _console
    if _console is None:
        _console = get_console()
    return _console


def reset_shared_console() -> None:
    """Reset the shared console instance.

    Useful for testing to ensure a fresh console.
    """
    global _console
    _console = None
