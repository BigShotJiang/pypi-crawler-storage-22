"""Discovery command implementation for bb2gh.

Discovers repositories in a Bitbucket workspace and generates an inventory
with metadata, complexity scoring, and migration recommendations.
"""

from __future__ import annotations

import asyncio
import time
from typing import TYPE_CHECKING

import structlog
import typer

from bb2gh.cli.console import get_shared_console
from bb2gh.cli.output import print_error, print_info, print_success, progress_context
from bb2gh.exceptions import AuthenticationError, ConfigurationError
from bb2gh.licensing.decorators import LicenseRequiredError
from bb2gh.licensing.features import require_license

if TYPE_CHECKING:
    from rich.console import Console

    from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter
    from bb2gh.models.inventory import Inventory, RepositoryInventoryItem
    from bb2gh.models.repository import Repository

logger = structlog.get_logger(__name__)


def _get_ssl_verify() -> str | bool:
    """Resolve SSL verification from BB2GH settings."""
    from bb2gh.models.config import BB2GHSettings
    from bb2gh.services.ssl import resolve_ssl_verify

    settings = BB2GHSettings()
    return resolve_ssl_verify(settings.ssl_ca_bundle)


def _get_bitbucket_adapter(
    *,
    profile: str = "default",
) -> BitbucketCloudAdapter:
    """Create a Bitbucket Cloud adapter from resolved credentials.

    Uses credential resolver: env vars > keyring > profile config.

    Args:
        profile: Name of the migration profile to use for credential lookup.

    Returns:
        Configured BitbucketCloudAdapter.

    Raises:
        ConfigurationError: If required credentials are missing.
    """
    from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter
    from bb2gh.cli.credential_resolver import resolve_bitbucket_credentials

    creds = resolve_bitbucket_credentials(profile_name=profile)
    ssl_verify = _get_ssl_verify()

    if creds.get("auth_method") == "api-token":
        return BitbucketCloudAdapter(
            username=creds["username"], api_token=creds["api_token"], ssl_verify=ssl_verify
        )
    elif creds.get("auth_method") == "oauth2":
        return BitbucketCloudAdapter(
            client_id=creds["client_id"],
            client_secret=creds["client_secret"],
            ssl_verify=ssl_verify,
        )
    else:
        raise ConfigurationError(
            "Bitbucket credentials not found."
            " Run 'bb2gh auth login' or set:\n"
            "  - BB_USERNAME and BB_API_TOKEN for API token auth, or\n"
            "  - BB_CLIENT_ID and BB_CLIENT_SECRET for OAuth 2.0"
        )


async def _discover_repositories(
    workspace: str,
    *,
    project: str | None = None,
    analyze: bool = False,
) -> tuple[list[Repository], list[RepositoryInventoryItem] | None]:
    """Discover all repositories in a Bitbucket workspace.

    Args:
        workspace: Bitbucket workspace slug.
        project: Optional project key filter.
        analyze: Whether to perform deep analysis with complexity scoring.

    Returns:
        Tuple of (list of repositories, analyzed inventory items or None).
    """
    from bb2gh.services.discovery import analyze_repository

    console = get_shared_console()
    adapter = _get_bitbucket_adapter()

    all_repos: list[Repository] = []
    analyzed_items: list[RepositoryInventoryItem] | None = None
    page = 1
    page_size = 100

    async with adapter:
        # Verify credentials first
        print_info("Verifying Bitbucket credentials...")
        await adapter.verify_credentials()
        print_success("Credentials verified")

        # Fetch repositories with progress
        with progress_context(console=console) as progress:
            task = progress.add_task(
                f"[cyan]Discovering repositories in {workspace}...",
                total=None,  # Unknown total initially
            )

            while True:
                repos = await adapter.list_repositories(
                    workspace=workspace,
                    project=project,
                    page=page,
                    page_size=page_size,
                )

                if not repos:
                    break

                all_repos.extend(repos)
                progress.update(
                    task,
                    description=f"[cyan]Discovered {len(all_repos)} repositories...",
                    completed=len(all_repos),
                )

                # If we got less than page_size, we're done
                if len(repos) < page_size:
                    break

                page += 1

            # Mark as complete
            progress.update(
                task,
                description=f"[green]Discovered {len(all_repos)} repositories",
                total=len(all_repos),
                completed=len(all_repos),
            )

        # Perform deep analysis if requested
        if analyze and all_repos:
            analyzed_items = []
            with progress_context(console=console) as progress:
                task = progress.add_task(
                    "[cyan]Analyzing repositories...",
                    total=len(all_repos),
                )

                for i, repo in enumerate(all_repos):
                    progress.update(
                        task,
                        description=f"[cyan]Analyzing {repo.name}...",
                        completed=i,
                    )

                    item = await analyze_repository(
                        adapter,
                        repo,
                        workspace=workspace,
                    )
                    analyzed_items.append(item)

                progress.update(
                    task,
                    description=f"[green]Analyzed {len(all_repos)} repositories",
                    completed=len(all_repos),
                )

    return all_repos, analyzed_items


def _repository_to_inventory_item(
    repo: Repository,
    workspace: str,
) -> RepositoryInventoryItem:
    """Convert a Repository model to a RepositoryInventoryItem.

    Args:
        repo: Repository model from adapter.
        workspace: Workspace name.

    Returns:
        RepositoryInventoryItem for the inventory.
    """
    from bb2gh.models.inventory import RepositoryInventoryItem

    return RepositoryInventoryItem(
        id=repo.id,
        name=repo.name,
        full_name=repo.full_name,
        description=repo.description,
        source=repo.source,
        workspace=workspace,
        project=repo.project,
        private=repo.private,
        archived=repo.archived,
        fork=repo.fork,
        default_branch=repo.default_branch,
        size_bytes=repo.size_bytes,
        clone_url_https=repo.clone_url_https,
        clone_url_ssh=repo.clone_url_ssh,
        created_at=repo.created_at,
        updated_at=repo.updated_at,
    )


def _format_size(size_bytes: int) -> str:
    """Format size in bytes to human-readable string."""
    if size_bytes >= 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"
    elif size_bytes >= 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.2f} MB"
    elif size_bytes >= 1024:
        return f"{size_bytes / 1024:.2f} KB"
    return f"{size_bytes} B"


def _print_summary_table(
    console: Console,
    inventory: Inventory,
    *,
    analyze: bool = False,
) -> None:
    """Print a summary table of the discovery results.

    Args:
        console: Rich console instance.
        inventory: Inventory with discovery results.
        analyze: Whether deep analysis was performed.
    """
    from rich.panel import Panel
    from rich.table import Table

    # Overview stats
    console.print()
    overview = Table(show_header=False, box=None, padding=(0, 2))
    overview.add_column("Label", style="dim")
    overview.add_column("Value", style="cyan")

    overview.add_row("Total repositories", str(inventory.summary.total_repositories))
    overview.add_row("Total size", _format_size(inventory.summary.total_size_bytes))
    overview.add_row("Private", str(inventory.summary.private_count))
    overview.add_row("Public", str(inventory.summary.public_count))

    if inventory.summary.archived_count > 0:
        overview.add_row("Archived", str(inventory.summary.archived_count))
    if inventory.summary.fork_count > 0:
        overview.add_row("Forks", str(inventory.summary.fork_count))

    console.print(Panel(overview, title="[bold]Overview[/bold]", border_style="blue"))

    # Complexity breakdown (only shown if analysis was performed)
    if analyze:
        complexity_table = Table(show_header=True, box=None, padding=(0, 2))
        complexity_table.add_column("Complexity", style="bold")
        complexity_table.add_column("Count", justify="right")
        complexity_table.add_column("Percentage", justify="right")

        total = inventory.summary.total_repositories
        if total > 0:
            simple_pct = (inventory.summary.complexity_simple / total) * 100
            moderate_pct = (inventory.summary.complexity_moderate / total) * 100
            complex_pct = (inventory.summary.complexity_complex / total) * 100

            complexity_table.add_row(
                "[green]Simple[/green]",
                str(inventory.summary.complexity_simple),
                f"{simple_pct:.1f}%",
            )
            complexity_table.add_row(
                "[yellow]Moderate[/yellow]",
                str(inventory.summary.complexity_moderate),
                f"{moderate_pct:.1f}%",
            )
            complexity_table.add_row(
                "[red]Complex[/red]",
                str(inventory.summary.complexity_complex),
                f"{complex_pct:.1f}%",
            )

        console.print(
            Panel(
                complexity_table, title="[bold]Complexity Distribution[/bold]", border_style="blue"
            )
        )

        # Warnings summary
        if (
            inventory.summary.repos_with_large_files > 0
            or inventory.summary.repos_with_lfs > 0
            or inventory.summary.total_warnings > 0
        ):
            warnings_table = Table(show_header=False, box=None, padding=(0, 2))
            warnings_table.add_column("Issue", style="dim")
            warnings_table.add_column("Count", style="yellow", justify="right")

            if inventory.summary.repos_with_large_files > 0:
                warnings_table.add_row(
                    "Repos with large files (>100MB)",
                    str(inventory.summary.repos_with_large_files),
                )
            if inventory.summary.repos_with_lfs > 0:
                warnings_table.add_row(
                    "Repos using Git LFS",
                    str(inventory.summary.repos_with_lfs),
                )
            if inventory.summary.total_warnings > 0:
                warnings_table.add_row(
                    "Total warnings",
                    str(inventory.summary.total_warnings),
                )

            console.print(
                Panel(warnings_table, title="[bold]Potential Issues[/bold]", border_style="yellow")
            )


def run_discover(
    workspace: str,
    output: str,
    *,
    source: str = "bitbucket-cloud",
    project: str | None = None,
    analyze: bool = False,
) -> Inventory:
    """Run the discovery process.

    Args:
        workspace: Bitbucket workspace slug.
        output: Output file path for inventory.
        source: Source type (bitbucket-cloud or bitbucket-dc).
        project: Optional project key filter.
        analyze: Whether to perform deep analysis with complexity scoring.

    Returns:
        Inventory with discovered repositories.

    Raises:
        typer.Exit: On error.
    """
    from bb2gh.models.inventory import Inventory

    console = get_shared_console()

    # Currently only bitbucket-cloud is supported
    if source != "bitbucket-cloud":
        print_error(f"Source type '{source}' is not yet supported. Use 'bitbucket-cloud'.")
        raise typer.Exit(1)

    # Check license before proceeding
    try:
        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    console.print("\n[bold]Discovering repositories[/bold]")
    console.print(f"  Workspace: [cyan]{workspace}[/cyan]")
    if project:
        console.print(f"  Project: [cyan]{project}[/cyan]")
    console.print(f"  Output: [cyan]{output}[/cyan]")
    if analyze:
        console.print("  Analysis: [cyan]enabled (complexity scoring, large files, LFS)[/cyan]")
    console.print()

    start_time = time.monotonic()

    try:
        repositories, analyzed_items = asyncio.run(
            _discover_repositories(workspace, project=project, analyze=analyze)
        )

        # Use analyzed items if available, otherwise convert basic info
        if analyzed_items is not None:
            inventory_items = analyzed_items
        else:
            inventory_items = [
                _repository_to_inventory_item(repo, workspace) for repo in repositories
            ]

        # Create inventory
        inventory = Inventory.from_repositories(
            inventory_items,
            workspace=workspace,
            source_type=source,
            project_filter=project,
        )

        # Save to file
        inventory.to_json_file(output)

        # Print summary
        console.print()
        console.print("[bold green]Discovery complete![/bold green]")

        # Display summary table
        _print_summary_table(console, inventory, analyze=analyze)

        # Show output file
        console.print(f"\n  Inventory saved to: [green]{output}[/green]")

        logger.info(
            "discovery_complete",
            workspace=workspace,
            repository_count=inventory.summary.total_repositories,
            total_size_bytes=inventory.summary.total_size_bytes,
            output_file=output,
        )

        # Emit telemetry
        from bb2gh.cli import telemetry_helpers

        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        telemetry_helpers.emit_discovery_completed(
            repo_count=inventory.summary.total_repositories,
            total_size_mb=inventory.summary.total_size_bytes // (1024 * 1024),
            repos_with_lfs=inventory.summary.repos_with_lfs,
            complexity_simple=inventory.summary.complexity_simple,
            complexity_moderate=inventory.summary.complexity_moderate,
            complexity_complex=inventory.summary.complexity_complex,
        )
        telemetry_helpers.emit_command_success("discover", duration_ms=elapsed_ms)

        return inventory

    except ConfigurationError as e:
        from bb2gh.cli import telemetry_helpers

        telemetry_helpers.emit_command_failure("discover", error_type="ConfigurationError")
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1) from None
    except AuthenticationError as e:
        from bb2gh.cli import telemetry_helpers

        telemetry_helpers.emit_command_failure("discover", error_type="AuthenticationError")
        print_error(f"Authentication failed: {e}")
        raise typer.Exit(1) from None
    except Exception as e:
        from bb2gh.cli import telemetry_helpers

        telemetry_helpers.emit_command_failure("discover", error_type=type(e).__name__)
        logger.exception("discovery_failed", workspace=workspace)
        print_error(f"Discovery failed: {e}")
        raise typer.Exit(2) from None
