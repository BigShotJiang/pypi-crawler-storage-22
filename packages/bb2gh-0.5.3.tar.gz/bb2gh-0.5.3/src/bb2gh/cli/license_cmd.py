"""License commands for bb2gh CLI.

Provides `bb2gh license register`, `bb2gh license activate`,
`bb2gh license status`, and `bb2gh license deactivate` subcommands
for managing software licenses.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import TYPE_CHECKING

import typer

if TYPE_CHECKING:
    from bb2gh.models.license import License, LicenseInfo, LicenseStatus

license_app = typer.Typer(
    name="license",
    help="Manage bb2gh license registration and activation.",
    no_args_is_help=True,
)

# Registration API endpoint (not yet available)
_REGISTRATION_API_URL = "https://api.n8-group.com/v1/licenses/register"

# Simple email format validation (RFC 5322 simplified)
_EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _get_license_dir() -> Path:
    """Get the license directory path (~/.bb2gh/).

    Returns:
        Path to the license directory.
    """
    return Path.home() / ".bb2gh"


def _get_license_file() -> Path:
    """Get the license file path (~/.bb2gh/license).

    Returns:
        Path to the license file.
    """
    return _get_license_dir() / "license"


def _status_to_user_message(status: LicenseStatus) -> str:
    """Map LicenseStatus to a user-actionable error message.

    Args:
        status: License validation status.

    Returns:
        User-friendly error message with action hint.
    """
    from bb2gh.models.license import LicenseStatus

    messages: dict[LicenseStatus, str] = {
        LicenseStatus.NOT_FOUND: (
            "No license found. Register for a free license: bb2gh license register"
        ),
        LicenseStatus.INVALID_SIGNATURE: (
            "License signature is invalid. "
            "Your license may be corrupted or tampered with. "
            "Re-download or contact support."
        ),
        LicenseStatus.PARSE_ERROR: (
            "License format is invalid. "
            "Check that you copied the full license key. "
            "Re-download or contact support."
        ),
        LicenseStatus.EXPIRED: (
            "License has expired. Register for a new license or contact sales@n8-group.com"
        ),
    }
    return messages.get(status, f"License error: {status.value}")


@license_app.command("register")
def register(
    email: str | None = typer.Option(
        None,
        "--email",
        "-e",
        help="Email address for registration.",
    ),
    tier: str = typer.Option(
        "free",
        "--tier",
        "-t",
        help="License tier: free, pro, or ultimate.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Override email validation and submit anyway.",
    ),
) -> None:
    """Register for a bb2gh license.

    For free tier: submits registration and sends a license key via email.
    For pro/ultimate: directs to sales for enterprise licensing.
    """
    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.output import print_error, print_info, print_success

    console = get_shared_console()

    # Prompt for email if not provided
    if email is None:
        email = typer.prompt("Email")

    # Validate email format
    if not _EMAIL_PATTERN.match(email):
        if not force:
            print_error(f"Invalid email format: {email}\n  Use --force to override this check.")
            raise typer.Exit(1)
        console.print(
            f"[yellow]Warning:[/yellow] '{email}' doesn't look like a valid email address."
        )

    # Validate tier
    tier_lower = tier.lower()
    if tier_lower not in ("free", "pro", "ultimate"):
        print_error(f"Invalid tier: {tier}. Must be 'free', 'pro', or 'ultimate'.")
        raise typer.Exit(1)

    # Pro/Ultimate: direct to sales
    if tier_lower in ("pro", "ultimate"):
        console.print()
        print_info(
            f"[bold]{tier_lower.capitalize()}[/bold] licenses are available through our sales team."
        )
        console.print()
        console.print("  Contact: [bold cyan]sales@n8-group.com[/bold cyan]")
        console.print(f"  Mention: {email}")
        console.print()
        print_info("Our team will send you a license key within 1 business day.")
        return

    # Free tier: attempt API registration
    console.print()
    print_info(f"Registering [bold]{email}[/bold] for a free license...")

    try:
        import httpx

        with httpx.Client(timeout=10.0) as client:
            response = client.post(
                _REGISTRATION_API_URL,
                json={"email": email, "tier": "free"},
            )
            response.raise_for_status()
    except ImportError:
        print_error("httpx is required for registration. Install with: pip install httpx")
        raise typer.Exit(1) from None
    except Exception as e:
        import httpx

        if isinstance(e, httpx.HTTPError):
            # API may not exist yet - that's expected during pre-release
            pass
        else:
            raise

    console.print()
    print_success("Registration submitted! Check your email for the license key.")
    console.print()
    console.print(
        "[dim]Once you receive your key, activate it with:[/dim]\n  bb2gh license activate <key>"
    )


@license_app.command("activate")
def activate(
    key: str | None = typer.Argument(
        None,
        help="License key string (BB2GH-1-...).",
    ),
    key_file: Path | None = typer.Option(
        None,
        "--key-file",
        "-f",
        help="Path to a file containing the license key.",
    ),
) -> None:
    """Activate a bb2gh license key.

    Validates the license signature offline, checks expiry,
    and stores it in ~/.bb2gh/license.

    The key can be provided as a positional argument, via --key-file,
    or via the BB2GH_LICENSE environment variable (for CI/CD).
    """
    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.output import print_error
    from bb2gh.licensing.features import (
        _MAX_LICENSE_LENGTH,
        clear_license_cache,
        set_license,
    )
    from bb2gh.models.license import (
        LicenseStatus,
    )

    console = get_shared_console()
    from_env = False

    # Resolve the license key string
    license_str: str | None = None

    if key is not None:
        license_str = key.strip()
    elif key_file is not None:
        if not key_file.exists():
            print_error(f"Key file not found: {key_file}")
            raise typer.Exit(1)
        if key_file.is_symlink():
            print_error(
                f"Key file is a symlink: {key_file}\n"
                "  Symlinks are not allowed for security. Use the actual file."
            )
            raise typer.Exit(1)
        try:
            license_str = key_file.read_text().strip()
        except UnicodeDecodeError:
            print_error(f"Key file contains invalid characters (not UTF-8): {key_file}")
            raise typer.Exit(1) from None
    else:
        # Check environment variable
        env_key = os.environ.get("BB2GH_LICENSE")
        if env_key:
            license_str = env_key.strip()
            from_env = True
        else:
            print_error(
                "No license key provided. "
                "Pass a key as argument, use --key-file, "
                "or set BB2GH_LICENSE environment variable."
            )
            raise typer.Exit(1)

    # Size cap check
    if len(license_str) > _MAX_LICENSE_LENGTH:
        print_error(
            f"License key is too large ({len(license_str)} bytes, max {_MAX_LICENSE_LENGTH})."
        )
        raise typer.Exit(1)

    # Validate the license
    clear_license_cache()
    license_info = set_license(license_str)

    if license_info.status == LicenseStatus.EXPIRED:
        print_error(_status_to_user_message(LicenseStatus.EXPIRED))
        if license_info.license:
            console.print(f"  Expired: {license_info.license.exp.strftime('%Y-%m-%d')}")
        raise typer.Exit(1)

    if not license_info.is_valid or license_info.license is None:
        print_error(_status_to_user_message(license_info.status))
        raise typer.Exit(1)

    lic = license_info.license

    # Store the license file (unless from env var)
    stored_location = "BB2GH_LICENSE environment variable"
    if not from_env:
        license_dir = _get_license_dir()
        license_dir.mkdir(parents=True, exist_ok=True)
        license_file = license_dir / "license"

        # Reject symlink at write path
        if license_file.is_symlink():
            print_error(
                f"License file path is a symlink: {license_file}\n"
                "  Remove the symlink and try again."
            )
            raise typer.Exit(1)

        license_file.write_text(license_str)
        license_file.chmod(0o600)
        stored_location = str(license_file)

    # Display activation result
    _display_activation_result(console, lic, stored_location)


def _display_activation_result(
    console: object,
    lic: License,
    stored_location: str,
) -> None:
    """Display license activation result using Rich.

    Args:
        console: Rich console instance.
        lic: Validated License object.
        stored_location: Where the license was stored.
    """
    from rich.console import Console
    from rich.table import Table

    from bb2gh.cli.output import print_success
    from bb2gh.models.license import TIER_FEATURES, TIER_LIMITS, Tier

    if not isinstance(console, Console):
        from bb2gh.cli.console import get_shared_console

        console = get_shared_console()

    print_success("License activated!")

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Field", style="bold")
    table.add_column("Value")

    table.add_row("Tier", lic.tier.value.capitalize())
    table.add_row("Organization", lic.org)

    # Features summary
    tier_features = TIER_FEATURES.get(lic.tier, frozenset())
    extra = [f for f in tier_features if f not in TIER_FEATURES[Tier.FREE]]

    if extra:
        features_str = f"Core + {', '.join(f.value.replace('_', ' ').title() for f in extra)}"
    else:
        features_str = "Core"

    # Add worker info for Pro+
    limits = TIER_LIMITS.get(lic.tier, TIER_LIMITS[Tier.FREE])
    max_workers = limits.get("workers", 1)
    if max_workers > 1:
        features_str += f" ({max_workers} workers)"
    elif max_workers == 0:
        features_str += " (Unlimited workers)"

    table.add_row("Features", features_str)
    table.add_row("Expires", lic.exp.strftime("%Y-%m-%d"))
    table.add_row("Stored in", stored_location)

    console.print()
    console.print(table)
    console.print()


@license_app.command("status")
def status() -> None:
    """Show current license status.

    Displays license details, feature checklist, and limits
    in a formatted table.
    """
    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.output import print_error, print_info
    from bb2gh.licensing.features import clear_license_cache, get_license
    from bb2gh.models.license import (
        LicenseStatus,
    )

    console = get_shared_console()
    clear_license_cache()

    # Use get_license() instead of duplicate _load_license_for_status()
    license_info = get_license()

    if license_info.status == LicenseStatus.NOT_FOUND:
        console.print()
        print_info(_status_to_user_message(LicenseStatus.NOT_FOUND))
        console.print()
        return

    if license_info.status in (
        LicenseStatus.INVALID_SIGNATURE,
        LicenseStatus.PARSE_ERROR,
    ):
        console.print()
        print_error(_status_to_user_message(license_info.status))
        console.print()
        return

    lic = license_info.license
    if lic is None:
        print_info("No license found.")
        return

    _display_license_status(console, lic, license_info)


def _display_license_status(
    console: object,
    lic: License,
    license_info: LicenseInfo,
) -> None:
    """Display license status using Rich tables.

    Args:
        console: Rich console instance.
        lic: License object.
        license_info: License validation info.
    """
    from datetime import UTC, datetime

    from rich.console import Console
    from rich.table import Table

    from bb2gh.models.license import (
        TIER_LIMITS,
        LicenseStatus,
        Tier,
    )

    if not isinstance(console, Console):
        from bb2gh.cli.console import get_shared_console

        console = get_shared_console()

    # Main status table
    table = Table(title="License Status", show_header=False, padding=(0, 2))
    table.add_column("Field", style="bold", min_width=14)
    table.add_column("Value")

    table.add_row("Tier", lic.tier.value.capitalize())
    table.add_row("Organization", lic.org)
    table.add_row("Email", lic.sub)
    table.add_row("License ID", lic.payload.lid)

    # Dates
    if lic.payload.iat:
        table.add_row("Issued", lic.payload.iat.strftime("%Y-%m-%d"))

    # Expiry with days remaining
    now = datetime.now(UTC)
    days_remaining = (lic.exp - now).days
    if days_remaining > 0:
        expiry_str = f"{lic.exp.strftime('%Y-%m-%d')} ({days_remaining} days)"
    else:
        expiry_str = f"{lic.exp.strftime('%Y-%m-%d')} (expired)"
    table.add_row("Expires", expiry_str)

    # Status
    if license_info.status == LicenseStatus.VALID:
        status_str = "[green]Valid[/green]"
    elif license_info.status == LicenseStatus.EXPIRED:
        status_str = "[red]Expired[/red]"
    else:
        status_str = f"[yellow]{license_info.status.value}[/yellow]"
    table.add_row("Status", status_str)

    # Limits
    limits = TIER_LIMITS.get(lic.tier, TIER_LIMITS[Tier.FREE])
    # Override with license-specific limits
    effective_limits = limits.copy()
    if lic.payload.limits:
        effective_limits.update(lic.payload.limits)

    max_repos = effective_limits.get("repos", 0)
    max_workers = effective_limits.get("workers", 1)
    table.add_row("Repo limit", "Unlimited" if max_repos == 0 else str(max_repos))
    table.add_row(
        "Workers",
        "Unlimited" if max_workers == 0 else f"Up to {max_workers}",
    )

    console.print()
    console.print(table)

    # Feature checklist
    console.print()
    _display_feature_checklist(lic)
    console.print()


def _display_feature_checklist(lic: License) -> None:
    """Display a feature checklist showing enabled/disabled features.

    Args:
        lic: License object.
    """
    from rich.table import Table

    from bb2gh.cli.console import get_shared_console
    from bb2gh.models.license import TIER_FEATURES, Feature, Tier

    console = get_shared_console()

    tier_features = TIER_FEATURES.get(lic.tier, frozenset())
    # Include explicit feature overrides
    all_enabled = tier_features | set(lic.features)

    table = Table(title="Features", show_header=False, box=None, padding=(0, 1))
    table.add_column("Status", min_width=4)
    table.add_column("Feature")
    table.add_column("Requirement", style="dim")

    for feature in Feature:
        enabled = feature in all_enabled
        check = "[green][x][/green]" if enabled else "[ ]"

        # Determine minimum tier required
        req = ""
        if not enabled:
            for t in (Tier.FREE, Tier.PRO, Tier.ULTIMATE):
                if feature in TIER_FEATURES.get(t, frozenset()):
                    req = f"({t.value.capitalize()})"
                    break

        name = feature.value.replace("_", " ").title()
        table.add_row(check, name, req)

    console.print(table)


@license_app.command("deactivate")
def deactivate() -> None:
    """Remove the stored license from ~/.bb2gh/license.

    Clears the license file and cache so subsequent commands
    will run without a license.
    """
    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.output import print_info, print_success
    from bb2gh.licensing.features import clear_license_cache

    console = get_shared_console()
    license_dir = _get_license_dir()
    license_file = license_dir / "license"

    if not license_file.exists():
        console.print()
        print_info("No license file found.")
        console.print(f"  Expected location: {license_file}")
        console.print()
        return

    # Warn about env var
    if os.environ.get("BB2GH_LICENSE"):
        console.print()
        console.print(
            "[yellow]Warning:[/yellow] BB2GH_LICENSE environment variable is set. "
            "Removing the file will not affect the env var."
        )

    license_file.unlink()
    clear_license_cache()

    console.print()
    print_success(f"License removed from {license_file}")
    console.print()
