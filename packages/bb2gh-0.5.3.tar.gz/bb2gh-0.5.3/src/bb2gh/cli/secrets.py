"""Secrets command implementation for bb2gh.

CLI commands for secret inventory, scaffolding, and validation.
"""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog
import typer

if TYPE_CHECKING:
    from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter
    from bb2gh.adapters.github_cloud import GitHubCloudAdapter

from bb2gh.cli.console import get_shared_console
from bb2gh.cli.output import print_error, print_info, print_success, progress_context

logger = structlog.get_logger(__name__)


def _get_bitbucket_adapter() -> BitbucketCloudAdapter:
    """Create Bitbucket adapter from environment."""
    from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter

    token = (
        os.environ.get("BB_API_TOKEN")
        or os.environ.get("BB_APP_PASSWORD")
        or os.environ.get("BITBUCKET_API_TOKEN")
        or os.environ.get("BITBUCKET_APP_PASSWORD")
    )
    username = os.environ.get("BB_USERNAME") or os.environ.get("BITBUCKET_USERNAME")

    if not token:
        raise ValueError("Bitbucket credentials not found. Set BB_API_TOKEN or BB_APP_PASSWORD.")

    return BitbucketCloudAdapter(
        username=username or "",
        app_password=token,
    )


def _get_github_adapter() -> GitHubCloudAdapter:
    """Create GitHub adapter from environment."""
    from bb2gh.adapters.github_cloud import GitHubCloudAdapter

    token = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")

    if not token:
        raise ValueError("GitHub credentials not found. Set GH_TOKEN or GITHUB_TOKEN.")

    return GitHubCloudAdapter(token=token)


async def _export_secrets(workspace: str, output: Path) -> dict[str, Any]:
    """Export secrets inventory to JSON.

    Args:
        workspace: Bitbucket workspace.
        output: Output file path.

    Returns:
        Inventory summary dict.
    """
    from bb2gh.secrets.inventory import SecretsInventoryService

    adapter = _get_bitbucket_adapter()

    async with adapter:
        service = SecretsInventoryService(source_adapter=adapter)
        inventory = await service.discover_secrets(workspace)

        # Export to JSON
        with output.open("w", encoding="utf-8") as f:
            json.dump(inventory.to_dict(), f, indent=2)

        return {
            "total": inventory.total_count,
            "secured": inventory.secured_count,
            "by_scope": inventory.by_scope,
        }


async def _scaffold_secrets(
    inventory_file: Path,
    target_org: str,
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Scaffold secrets in GitHub.

    Args:
        inventory_file: Path to inventory JSON file.
        target_org: Target GitHub organization.
        dry_run: If True, only preview.

    Returns:
        Scaffold result summary.
    """
    from bb2gh.models.secret import SecretInventory
    from bb2gh.secrets.scaffold import SecretsScaffoldService

    # Load inventory
    with inventory_file.open(encoding="utf-8") as f:
        data = json.load(f)

    # Reconstruct inventory from dict
    from bb2gh.models.secret import Secret, SecretScope, SecretType, SecretVisibility

    secrets = []
    for s in data.get("secrets", []):
        secrets.append(
            Secret(
                name=s["name"],
                secret_type=SecretType(s["type"]),
                scope=SecretScope(s["scope"]),
                visibility=SecretVisibility(s.get("visibility", "secured")),
                repository=s.get("repository"),
                environment=s.get("environment"),
            )
        )

    inventory = SecretInventory(
        source_workspace=data["source_workspace"],
        secrets=secrets,
    )

    adapter = _get_github_adapter()

    async with adapter:
        service = SecretsScaffoldService(target_adapter=adapter)
        result = await service.scaffold_secrets(
            inventory,
            target_org=target_org,
            dry_run=dry_run,
        )

        return {
            "created": result.created,
            "skipped": result.skipped,
            "failed": result.failed,
            "errors": result.errors,
        }


async def _validate_secrets(
    inventory_file: Path,
    target_org: str,
) -> dict[str, Any]:
    """Validate secrets exist in GitHub.

    Args:
        inventory_file: Path to inventory JSON file.
        target_org: Target GitHub organization.

    Returns:
        Validation result summary.
    """
    from bb2gh.models.secret import SecretInventory
    from bb2gh.secrets.validation import SecretsValidationService

    # Load inventory
    with inventory_file.open(encoding="utf-8") as f:
        data = json.load(f)

    from bb2gh.models.secret import Secret, SecretScope, SecretType, SecretVisibility

    secrets = []
    for s in data.get("secrets", []):
        secrets.append(
            Secret(
                name=s["name"],
                secret_type=SecretType(s["type"]),
                scope=SecretScope(s["scope"]),
                visibility=SecretVisibility(s.get("visibility", "secured")),
                repository=s.get("repository"),
                environment=s.get("environment"),
            )
        )

    inventory = SecretInventory(
        source_workspace=data["source_workspace"],
        secrets=secrets,
    )

    adapter = _get_github_adapter()

    async with adapter:
        service = SecretsValidationService(target_adapter=adapter)
        result = await service.validate_secrets(
            inventory,
            target_org=target_org,
        )

        return {
            "source_count": result.source_count,
            "target_count": result.target_count,
            "missing": result.missing_secrets,
            "extra": result.extra_secrets,
            "is_valid": result.is_valid,
        }


def run_export(
    source: str,
    workspace: str,
    output: str | None = None,
) -> None:
    """Export secrets inventory from source platform.

    Args:
        source: Source platform (bitbucket).
        workspace: Workspace name.
        output: Output file path.

    Raises:
        typer.Exit: On error.
    """
    # Check license and feature gate before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import is_feature_enabled, require_license
        from bb2gh.models.license import Feature

        require_license()
        if not is_feature_enabled(Feature.SECRETS_MANAGEMENT):
            print_error("Secrets management requires an Ultimate license.")
            raise typer.Exit(code=1)
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(code=1) from None

    console = get_shared_console()

    if source != "bitbucket":
        print_error(f"Unsupported source: {source}. Only 'bitbucket' is supported.")
        raise typer.Exit(1)

    output_path = Path(output) if output else Path(f"secrets-{workspace}.json")

    console.print("\n[bold]Exporting secrets inventory[/bold]")
    console.print(f"  Workspace: [cyan]{workspace}[/cyan]")
    console.print(f"  Output: [cyan]{output_path}[/cyan]")
    console.print()

    try:
        with progress_context(console=console) as progress:
            task = progress.add_task("[cyan]Discovering secrets...", total=None)

            result = asyncio.run(_export_secrets(workspace, output_path))

            progress.update(task, description=f"[green]Found {result['total']} secrets")

        # Summary
        console.print(f"\n  Total secrets: [cyan]{result['total']}[/cyan]")
        console.print(f"  Secured: [green]{result['secured']}[/green]")

        for scope, count in result["by_scope"].items():
            console.print(f"  {scope}: {count}")

        print_success(f"Exported to {output_path}")

    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1) from None
    except Exception as e:
        logger.exception("export_secrets_failed")
        print_error(f"Export failed: {e}")
        raise typer.Exit(2) from None


def run_checklist(
    inventory_file: str,
    output: str | None = None,
    output_format: str = "csv",
) -> None:
    """Generate a migration checklist from inventory.

    Args:
        inventory_file: Path to inventory JSON file.
        output: Output file path.
        output_format: Output format (csv or json).

    Raises:
        typer.Exit: On error.
    """
    # Check license and feature gate before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import is_feature_enabled, require_license
        from bb2gh.models.license import Feature

        require_license()
        if not is_feature_enabled(Feature.SECRETS_MANAGEMENT):
            print_error("Secrets management requires an Ultimate license.")
            raise typer.Exit(code=1)
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(code=1) from None

    from bb2gh.secrets.checklist import SecretsChecklistService

    console = get_shared_console()

    inventory_path = Path(inventory_file)
    if not inventory_path.exists():
        print_error(f"Inventory file not found: {inventory_file}")
        raise typer.Exit(1)

    # Load inventory
    with inventory_path.open(encoding="utf-8") as f:
        data = json.load(f)

    from bb2gh.models.secret import (
        Secret,
        SecretInventory,
        SecretScope,
        SecretType,
        SecretVisibility,
    )

    secrets = []
    for s in data.get("secrets", []):
        secrets.append(
            Secret(
                name=s["name"],
                secret_type=SecretType(s["type"]),
                scope=SecretScope(s["scope"]),
                visibility=SecretVisibility(s.get("visibility", "secured")),
                repository=s.get("repository"),
                environment=s.get("environment"),
            )
        )

    inventory = SecretInventory(
        source_workspace=data["source_workspace"],
        secrets=secrets,
    )

    # Generate checklist
    service = SecretsChecklistService()
    items = service.generate_checklist(
        inventory,
        target_org="",  # Will be filled in manually
    )

    # Determine output path
    ext = "csv" if output_format == "csv" else "json"
    output_path = Path(output) if output else Path(f"secrets-checklist.{ext}")

    if output_format == "csv":
        service.export_csv(items, output_path)
    else:
        # Export as JSON
        with output_path.open("w", encoding="utf-8") as f:
            json.dump([item.to_csv_row() for item in items], f, indent=2)

    # Print summary
    stats = service.get_summary_stats(items)

    console.print("\n[bold]Checklist Summary[/bold]")
    console.print(f"  Total secrets: [cyan]{stats['total']}[/cyan]")

    for scope, count in stats["by_scope"].items():
        console.print(f"  {scope}: {count}")

    print_success(f"Checklist exported to {output_path}")


def run_scaffold(
    inventory_file: str,
    target_org: str,
    *,
    dry_run: bool = False,
) -> None:
    """Scaffold placeholder secrets in GitHub.

    Args:
        inventory_file: Path to inventory JSON file.
        target_org: Target GitHub organization.
        dry_run: Preview without creating.

    Raises:
        typer.Exit: On error.
    """
    # Check license and feature gate before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import is_feature_enabled, require_license
        from bb2gh.models.license import Feature

        require_license()
        if not is_feature_enabled(Feature.SECRETS_MANAGEMENT):
            print_error("Secrets management requires an Ultimate license.")
            raise typer.Exit(code=1)
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(code=1) from None

    console = get_shared_console()

    inventory_path = Path(inventory_file)
    if not inventory_path.exists():
        print_error(f"Inventory file not found: {inventory_file}")
        raise typer.Exit(1)

    console.print("\n[bold]Scaffolding secrets[/bold]")
    console.print(f"  Inventory: [cyan]{inventory_file}[/cyan]")
    console.print(f"  Target org: [cyan]{target_org}[/cyan]")
    if dry_run:
        console.print("  [yellow]DRY RUN - no changes will be made[/yellow]")
    console.print()

    try:
        with progress_context(console=console) as progress:
            task = progress.add_task("[cyan]Scaffolding secrets...", total=None)

            result = asyncio.run(
                _scaffold_secrets(
                    inventory_path,
                    target_org,
                    dry_run=dry_run,
                )
            )

            progress.update(task, description=f"[green]Created {result['created']} secrets")

        # Summary
        console.print(f"\n  Created: [green]{result['created']}[/green]")
        if result["failed"] > 0:
            console.print(f"  Failed: [red]{result['failed']}[/red]")
            for error in result["errors"]:
                console.print(f"    - {error}")

        if dry_run:
            print_info(f"Would create {result['created']} secrets")
        else:
            print_success(f"Created {result['created']} placeholder secrets")

    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1) from None
    except Exception as e:
        logger.exception("scaffold_secrets_failed")
        print_error(f"Scaffold failed: {e}")
        raise typer.Exit(2) from None


def run_validate(
    inventory_file: str,
    target_org: str,
) -> None:
    """Validate secrets exist in target.

    Args:
        inventory_file: Path to inventory JSON file.
        target_org: Target GitHub organization.

    Raises:
        typer.Exit: On error (including validation failure).
    """
    # Check license and feature gate before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import is_feature_enabled, require_license
        from bb2gh.models.license import Feature

        require_license()
        if not is_feature_enabled(Feature.SECRETS_MANAGEMENT):
            print_error("Secrets management requires an Ultimate license.")
            raise typer.Exit(code=1)
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(code=1) from None

    console = get_shared_console()

    inventory_path = Path(inventory_file)
    if not inventory_path.exists():
        print_error(f"Inventory file not found: {inventory_file}")
        raise typer.Exit(1)

    console.print("\n[bold]Validating secrets[/bold]")
    console.print(f"  Inventory: [cyan]{inventory_file}[/cyan]")
    console.print(f"  Target org: [cyan]{target_org}[/cyan]")
    console.print()

    try:
        with progress_context(console=console) as progress:
            task = progress.add_task("[cyan]Validating secrets...", total=None)

            result = asyncio.run(_validate_secrets(inventory_path, target_org))

            status = "[green]Valid[/green]" if result["is_valid"] else "[red]Invalid[/red]"
            progress.update(task, description=f"Validation: {status}")

        # Summary
        console.print(f"\n  Source count: [cyan]{result['source_count']}[/cyan]")
        console.print(f"  Target count: [cyan]{result['target_count']}[/cyan]")

        if result["missing"]:
            console.print(f"\n  [red]Missing secrets ({len(result['missing'])}):[/red]")
            for name in result["missing"][:10]:  # Limit output
                console.print(f"    - {name}")
            if len(result["missing"]) > 10:
                console.print(f"    ... and {len(result['missing']) - 10} more")

        if result["extra"]:
            console.print(f"\n  [yellow]Extra secrets ({len(result['extra'])}):[/yellow]")
            for name in result["extra"][:10]:
                console.print(f"    - {name}")

        if result["is_valid"]:
            print_success("Validation passed!")
        else:
            print_error("Validation failed")
            raise typer.Exit(1)

    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1) from None
    except typer.Exit:
        raise
    except Exception as e:
        logger.exception("validate_secrets_failed")
        print_error(f"Validation failed: {e}")
        raise typer.Exit(2) from None
