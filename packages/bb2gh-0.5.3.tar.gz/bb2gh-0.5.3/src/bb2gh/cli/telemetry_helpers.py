"""Telemetry helper functions for CLI commands.

Module-level helpers that CLI commands use to emit and flush telemetry events.
All functions are safe to call even when telemetry is disabled — they silently
no-op when the collector or sender has not been initialised.
"""

from __future__ import annotations

import contextlib
import time
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from collections.abc import Generator

    from bb2gh.telemetry.collector import TelemetryCollector
    from bb2gh.telemetry.sender import PostHogSender

logger = structlog.get_logger(__name__)

# Module-level references, set by init()
_collector: TelemetryCollector | None = None
_sender: PostHogSender | None = None


def init(collector: TelemetryCollector, sender: PostHogSender) -> None:
    """Store module-level references to the collector and sender.

    Called once from ``_init_telemetry`` in ``app.py``.

    Args:
        collector: The telemetry collector instance.
        sender: The PostHog sender instance.
    """
    global _collector, _sender
    _collector = collector
    _sender = sender


def _flush() -> None:
    """Drain the collector queue through the sender."""
    if _collector is None or _sender is None:
        return
    for event in _collector.flush():
        _sender.capture(event)
    _sender.flush()


# ── Discovery ───────────────────────────────────────────────────────────────


def emit_discovery_completed(
    *,
    repo_count: int = 0,
    total_size_mb: int = 0,
    repos_with_lfs: int = 0,
    complexity_simple: int = 0,
    complexity_moderate: int = 0,
    complexity_complex: int = 0,
    total_prs: int = 0,
) -> None:
    """Emit a discovery_completed event and flush.

    Args:
        repo_count: Number of repos discovered.
        total_size_mb: Aggregate size in megabytes.
        repos_with_lfs: Repos using LFS.
        complexity_simple: Repos with simple complexity.
        complexity_moderate: Repos with moderate complexity.
        complexity_complex: Repos with complex complexity.
        total_prs: Total PRs found.
    """
    if _collector is None:
        return
    _collector.discovery_completed(
        repo_count=repo_count,
        total_size_mb=total_size_mb,
        repos_with_lfs=repos_with_lfs,
        complexity_simple=complexity_simple,
        complexity_moderate=complexity_moderate,
        complexity_complex=complexity_complex,
        total_prs=total_prs,
    )
    _flush()


# ── Plan ────────────────────────────────────────────────────────────────────


def emit_plan_created(
    *,
    repo_count: int = 0,
    total_size_mb: int = 0,
    repos_with_lfs: int = 0,
    renamed_count: int = 0,
    repos_with_warnings: int = 0,
) -> None:
    """Emit a plan_created event and flush.

    Args:
        repo_count: Number of repos in the plan.
        total_size_mb: Aggregate size in megabytes.
        repos_with_lfs: Repos using LFS.
        renamed_count: Number of renamed repos.
        repos_with_warnings: Repos with warnings.
    """
    if _collector is None:
        return
    _collector.plan_created(
        repo_count=repo_count,
        total_size_mb=total_size_mb,
        repos_with_lfs=repos_with_lfs,
        renamed_count=renamed_count,
        repos_with_warnings=repos_with_warnings,
    )
    _flush()


# ── Migration ───────────────────────────────────────────────────────────────


def emit_migration_start(
    *,
    repo_count: int = 0,
    total_size_mb: int = 0,
    repos_with_lfs: int = 0,
    total_prs: int = 0,
) -> None:
    """Emit a migration_start event and flush.

    Args:
        repo_count: Number of repositories.
        total_size_mb: Aggregate size in megabytes.
        repos_with_lfs: Repos using LFS.
        total_prs: Total PRs to migrate.
    """
    if _collector is None:
        return
    _collector.migration_start(
        repo_count,
        total_size_mb=total_size_mb,
        repos_with_lfs=repos_with_lfs,
        total_prs=total_prs,
    )
    _flush()


def emit_migration_success(
    *,
    repo_count: int = 0,
    duration_ms: int = 0,
    repos_completed: int = 0,
    repos_failed: int = 0,
) -> None:
    """Emit a migration_success event and flush.

    Args:
        repo_count: Number of repositories.
        duration_ms: Duration in milliseconds.
        repos_completed: Repos completed successfully.
        repos_failed: Repos that failed.
    """
    if _collector is None:
        return
    _collector.migration_success(
        repo_count,
        duration_ms,
        repos_completed=repos_completed,
        repos_failed=repos_failed,
    )
    _flush()


def emit_migration_failure(
    *,
    repo_count: int = 0,
    repos_completed: int = 0,
    repos_failed: int = 0,
    error_type: str = "",
    duration_ms: int = 0,
) -> None:
    """Emit a migration_failure event and flush.

    Args:
        repo_count: Number of repositories.
        repos_completed: Repos completed before failure.
        repos_failed: Repos that failed.
        error_type: Type of error (not message).
        duration_ms: Duration in milliseconds.
    """
    if _collector is None:
        return
    _collector.migration_failure(
        repo_count,
        repos_completed=repos_completed,
        repos_failed=repos_failed,
        error_type=error_type,
        duration_ms=duration_ms,
    )
    _flush()


# ── Validation ──────────────────────────────────────────────────────────────


def emit_validation_completed(
    *,
    repos_validated: int = 0,
    repos_passed: int = 0,
    repos_failed: int = 0,
    repos_warnings: int = 0,
) -> None:
    """Emit a validation_completed event and flush.

    Args:
        repos_validated: Repos validated.
        repos_passed: Repos that passed.
        repos_failed: Repos that failed.
        repos_warnings: Repos with warnings.
    """
    if _collector is None:
        return
    _collector.validation_completed(
        repos_validated=repos_validated,
        repos_passed=repos_passed,
        repos_failed=repos_failed,
        repos_warnings=repos_warnings,
    )
    _flush()


# ── Generic command outcome helpers ─────────────────────────────────────────


def emit_command_success(command: str, duration_ms: int = 0) -> None:
    """Emit a command_success event and flush.

    Args:
        command: Command name.
        duration_ms: Duration in milliseconds.
    """
    if _collector is None:
        return
    _collector.command_success(command, duration_ms=duration_ms)
    _flush()


def emit_command_failure(command: str, error_type: str = "") -> None:
    """Emit a command_failure event and flush.

    Args:
        command: Command name.
        error_type: Type of error (not message).
    """
    if _collector is None:
        return
    _collector.command_failure(command, error_type=error_type)
    _flush()


@contextlib.contextmanager
def track_command(command: str) -> Generator[None, None, None]:
    """Context manager that times a command and emits success/failure events.

    Args:
        command: Command name.

    Yields:
        Nothing — the caller runs the command inside the ``with`` block.
    """
    start = time.monotonic()
    try:
        yield
        elapsed_ms = int((time.monotonic() - start) * 1000)
        emit_command_success(command, duration_ms=elapsed_ms)
    except BaseException:
        emit_command_failure(command, error_type="exception")
        raise
