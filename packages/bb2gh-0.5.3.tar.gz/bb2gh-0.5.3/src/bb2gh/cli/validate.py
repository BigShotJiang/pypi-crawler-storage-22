"""Validate command implementation for bb2gh.

Validates migration completeness by comparing source and target repositories.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path
from typing import TYPE_CHECKING

import structlog
import typer

from bb2gh.cli.console import get_shared_console
from bb2gh.cli.output import print_error, print_info, print_success, progress_context
from bb2gh.exceptions import ConfigurationError
from bb2gh.models.plan import MigrationPlan

if TYPE_CHECKING:
    from rich.console import Console

    from bb2gh.services.validation import (
        AttributionValidationReport,
        CommentValidationReport,
        PRValidationReport,
        ValidationReport,
    )

logger = structlog.get_logger(__name__)


async def _run_validation(
    plan: MigrationPlan,
    *,
    migration_id: str | None = None,
    quick: bool = False,
) -> ValidationReport:
    """Execute validation for all repositories in the plan.

    Args:
        plan: Migration plan to validate.
        migration_id: Optional migration ID.
        quick: If True, only check counts.

    Returns:
        ValidationReport with results.
    """
    import subprocess

    from bb2gh.services.validation import ValidationService

    console = get_shared_console()

    # Get auth tokens
    source_token = (
        os.environ.get("BB_API_TOKEN")
        or os.environ.get("BB_APP_PASSWORD")
        or os.environ.get("BITBUCKET_API_TOKEN")
        or os.environ.get("BITBUCKET_APP_PASSWORD")
    )
    target_token = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")

    # Fallback: get GitHub token from gh CLI if not in environment
    if not target_token:
        try:
            result = subprocess.run(
                ["gh", "auth", "token"],
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode == 0:
                target_token = result.stdout.strip()
        except FileNotFoundError:
            pass  # gh CLI not installed

    service = ValidationService(
        source_auth_token=source_token,
        target_auth_token=target_token,
    )

    total = len(plan.repositories)

    with progress_context(console=console) as progress:
        task = progress.add_task(
            f"[cyan]Validating {total} repositories...",
            total=total,
        )

        report = await service.validate_plan(
            plan,
            migration_id=migration_id,
            quick=quick,
        )

        progress.update(
            task,
            description=f"[green]Validation complete: {report.passed}/{total} passed",
            completed=total,
        )

    return report


async def _run_pr_validation(
    plan: MigrationPlan,
    *,
    state_db: str | None = None,
    migration_id: str | None = None,
) -> PRValidationReport:
    """Execute PR validation for all repositories in the plan.

    Args:
        plan: Migration plan to validate.
        state_db: Path to state database.
        migration_id: Optional migration ID.

    Returns:
        PRValidationReport with results.
    """
    import subprocess

    from bb2gh.services.validation import PRValidationReport, ValidationService
    from bb2gh.state.store import StateStore

    console = get_shared_console()

    # Get auth tokens
    source_token = (
        os.environ.get("BB_API_TOKEN")
        or os.environ.get("BB_APP_PASSWORD")
        or os.environ.get("BITBUCKET_API_TOKEN")
        or os.environ.get("BITBUCKET_APP_PASSWORD")
    )
    target_token = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")

    # Fallback: get GitHub token from gh CLI if not in environment
    if not target_token:
        try:
            result = subprocess.run(
                ["gh", "auth", "token"],
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode == 0:
                target_token = result.stdout.strip()
        except FileNotFoundError:
            pass  # gh CLI not installed

    service = ValidationService(
        source_auth_token=source_token,
        target_auth_token=target_token,
    )

    db_path = Path(state_db) if state_db else Path(".bb2gh") / "state.db"

    combined_report = PRValidationReport(migration_id=migration_id)

    async with StateStore(db_path) as state_store:
        total = len(plan.repositories)

        # Find migration ID if not provided
        effective_migration_id = migration_id
        if not effective_migration_id:
            # Try to get the latest migration for this plan
            migrations = await state_store.list_migrations(limit=1)
            if migrations:
                # Use the most recent migration
                effective_migration_id = migrations[0].migration_id

        if not effective_migration_id:
            logger.warning("no_migration_id_for_pr_validation")
            return combined_report

        with progress_context(console=console) as progress:
            task = progress.add_task(
                f"[cyan]Validating PRs for {total} repositories...",
                total=total,
            )

            for i, mapping in enumerate(plan.repositories):
                source_repo = mapping.source_full_name
                target_repo = mapping.target_full_name

                # Get PR migration state from database
                pr_states = await state_store.list_pr_migrations(
                    migration_id=effective_migration_id,
                    source_repo=source_repo,
                )

                if pr_states:
                    repo_report = await service.validate_pr_migrations(
                        source_repo,
                        target_repo,
                        pr_states,
                        migration_id=effective_migration_id,
                    )

                    # Aggregate results
                    combined_report.total += repo_report.total
                    combined_report.passed += repo_report.passed
                    combined_report.failed += repo_report.failed
                    combined_report.warnings += repo_report.warnings
                    combined_report.pr_validations.extend(repo_report.pr_validations)

                progress.update(task, completed=i + 1)

            progress.update(
                task,
                description=f"[green]PR validation complete: {combined_report.passed}/{combined_report.total} passed",
                completed=total,
            )

    return combined_report


def _print_validation_summary(
    console: Console,
    report: ValidationReport,
) -> None:
    """Print validation summary table.

    Args:
        console: Rich console instance.
        report: Validation report.
    """
    from rich.panel import Panel
    from rich.table import Table

    from bb2gh.services.validation import ValidationStatus

    # Overview
    console.print()
    overview = Table(show_header=False, box=None, padding=(0, 2))
    overview.add_column("Label", style="dim")
    overview.add_column("Value", style="cyan")

    if report.migration_id:
        overview.add_row("Migration ID", report.migration_id)
    overview.add_row("Total repositories", str(report.total))
    overview.add_row("Passed", f"[green]{report.passed}[/green]")
    overview.add_row("Failed", f"[red]{report.failed}[/red]" if report.failed > 0 else "0")
    overview.add_row(
        "Warnings", f"[yellow]{report.warnings}[/yellow]" if report.warnings > 0 else "0"
    )
    if report.skipped > 0:
        overview.add_row("Skipped", str(report.skipped))

    # Overall status
    status_color = {
        ValidationStatus.PASSED: "green",
        ValidationStatus.FAILED: "red",
        ValidationStatus.WARNING: "yellow",
        ValidationStatus.SKIPPED: "dim",
    }.get(report.status, "white")
    overview.add_row("Status", f"[{status_color}]{report.status.value}[/{status_color}]")

    console.print(Panel(overview, title="[bold]Validation Summary[/bold]", border_style="blue"))

    # Repository details
    if report.repositories:
        repo_table = Table(show_header=True, box=None, padding=(0, 1))
        repo_table.add_column("Repository", style="cyan")
        repo_table.add_column("Status")
        repo_table.add_column("Branches")
        repo_table.add_column("Tags")
        repo_table.add_column("Commits")
        repo_table.add_column("LFS")
        repo_table.add_column("Issues")

        for repo in report.repositories:
            status_color = {
                ValidationStatus.PASSED: "green",
                ValidationStatus.FAILED: "red",
                ValidationStatus.WARNING: "yellow",
                ValidationStatus.SKIPPED: "dim",
            }.get(repo.status, "white")

            branches_str = f"{repo.target_branches}/{repo.source_branches}"
            if repo.missing_branches:
                branches_str = f"[red]{branches_str}[/red]"

            tags_str = f"{repo.target_tags}/{repo.source_tags}"
            if repo.missing_tags:
                tags_str = f"[red]{tags_str}[/red]"

            commits_str = f"{repo.target_commits}/{repo.source_commits}"
            if repo.target_commits != repo.source_commits:
                commits_str = f"[red]{commits_str}[/red]"

            # LFS status
            if repo.source_has_lfs:
                if repo.lfs_issues:
                    lfs_str = f"[yellow]{repo.target_lfs_files}/{repo.source_lfs_files}[/yellow]"
                else:
                    lfs_str = f"[green]{repo.target_lfs_files}/{repo.source_lfs_files}[/green]"
            else:
                lfs_str = "[dim]-[/dim]"

            repo_table.add_row(
                repo.source_full_name,
                f"[{status_color}]{repo.status.value}[/{status_color}]",
                branches_str,
                tags_str,
                commits_str,
                lfs_str,
                repo.message or "-",
            )

        console.print(
            Panel(repo_table, title="[bold]Repository Details[/bold]", border_style="blue")
        )

    # PR validation results
    if report.pr_report and report.pr_report.total > 0:
        pr_overview = Table(show_header=False, box=None, padding=(0, 2))
        pr_overview.add_column("Label", style="dim")
        pr_overview.add_column("Value", style="cyan")

        pr_overview.add_row("Total PRs", str(report.pr_report.total))
        pr_overview.add_row("Passed", f"[green]{report.pr_report.passed}[/green]")
        pr_overview.add_row(
            "Failed",
            f"[red]{report.pr_report.failed}[/red]" if report.pr_report.failed > 0 else "0",
        )
        if report.pr_report.warnings > 0:
            pr_overview.add_row("Warnings", f"[yellow]{report.pr_report.warnings}[/yellow]")

        pr_status_color = {
            ValidationStatus.PASSED: "green",
            ValidationStatus.FAILED: "red",
            ValidationStatus.WARNING: "yellow",
            ValidationStatus.SKIPPED: "dim",
        }.get(report.pr_report.status, "white")
        pr_overview.add_row(
            "Status",
            f"[{pr_status_color}]{report.pr_report.status.value}[/{pr_status_color}]",
        )

        console.print(
            Panel(pr_overview, title="[bold]PR Validation Summary[/bold]", border_style="blue")
        )

        # Show failed/warning PRs if any
        problem_prs = [
            pr
            for pr in report.pr_report.pr_validations
            if pr.status in (ValidationStatus.FAILED, ValidationStatus.WARNING)
        ]

        if problem_prs:
            pr_table = Table(show_header=True, box=None, padding=(0, 1))
            pr_table.add_column("Source PR", style="cyan")
            pr_table.add_column("Target PR")
            pr_table.add_column("Status")
            pr_table.add_column("Issue")

            for pr in problem_prs[:10]:  # Limit to first 10
                status_color = "red" if pr.status == ValidationStatus.FAILED else "yellow"
                target_str = f"#{pr.target_pr_number}" if pr.target_pr_number else "-"

                pr_table.add_row(
                    f"{pr.source_repo}#{pr.source_pr_id}",
                    target_str,
                    f"[{status_color}]{pr.status.value}[/{status_color}]",
                    pr.message or "-",
                )

            if len(problem_prs) > 10:
                pr_table.add_row(
                    f"... and {len(problem_prs) - 10} more",
                    "",
                    "",
                    "",
                )

            console.print(Panel(pr_table, title="[bold]PR Issues[/bold]", border_style="yellow"))

        # Comment validation summary
        if report.pr_report.comment_report:
            _print_comment_validation(console, report.pr_report.comment_report)

        # Attribution validation summary
        if report.pr_report.attribution_report:
            _print_attribution_validation(console, report.pr_report.attribution_report)


def _print_comment_validation(
    console: Console,
    comment_report: CommentValidationReport,
) -> None:
    """Print comment validation summary.

    Args:
        console: Rich console instance.
        comment_report: Comment validation report.
    """
    from rich.panel import Panel
    from rich.table import Table

    from bb2gh.services.validation import ValidationStatus

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Label", style="dim")
    table.add_column("Value", style="cyan")

    table.add_row("PRs validated", str(comment_report.total_prs))
    table.add_row(
        "Comments expected",
        str(comment_report.total_comments_expected),
    )
    table.add_row(
        "Comments migrated",
        f"[green]{comment_report.total_comments_migrated}[/green]",
    )
    if comment_report.total_comments_failed > 0:
        table.add_row(
            "Comments failed",
            f"[red]{comment_report.total_comments_failed}[/red]",
        )
        table.add_row(
            "PRs with missing comments",
            f"[yellow]{comment_report.prs_with_missing_comments}[/yellow]",
        )
    table.add_row(
        "Success rate",
        f"{comment_report.success_rate:.1f}%",
    )

    status_color = {
        ValidationStatus.PASSED: "green",
        ValidationStatus.WARNING: "yellow",
        ValidationStatus.SKIPPED: "dim",
    }.get(comment_report.status, "white")
    table.add_row(
        "Status",
        f"[{status_color}]{comment_report.status.value}[/{status_color}]",
    )

    console.print(Panel(table, title="[bold]Comment Validation[/bold]", border_style="blue"))


def _print_attribution_validation(
    console: Console,
    attribution_report: AttributionValidationReport,
) -> None:
    """Print attribution validation summary.

    Args:
        console: Rich console instance.
        attribution_report: Attribution validation report.
    """
    from rich.panel import Panel
    from rich.table import Table

    from bb2gh.services.validation import ValidationStatus

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Label", style="dim")
    table.add_column("Value", style="cyan")

    table.add_row("PRs validated", str(attribution_report.total_prs))
    table.add_row(
        "Authors mapped",
        f"[green]{attribution_report.prs_with_mapped_author}[/green]",
    )
    if attribution_report.prs_with_ghost_author > 0:
        table.add_row(
            "Ghost user (unmapped)",
            f"[yellow]{attribution_report.prs_with_ghost_author}[/yellow]",
        )
    table.add_row(
        "Mapping rate",
        f"{attribution_report.mapping_rate:.1f}%",
    )

    status_color = {
        ValidationStatus.PASSED: "green",
        ValidationStatus.WARNING: "yellow",
        ValidationStatus.SKIPPED: "dim",
    }.get(attribution_report.status, "white")
    table.add_row(
        "Status",
        f"[{status_color}]{attribution_report.status.value}[/{status_color}]",
    )

    console.print(Panel(table, title="[bold]Attribution Validation[/bold]", border_style="blue"))

    # Show ghost usernames if any
    if attribution_report.ghost_usernames:
        ghost_table = Table(show_header=True, box=None, padding=(0, 1))
        ghost_table.add_column("Unmapped Username", style="yellow")

        for username in attribution_report.ghost_usernames[:20]:
            ghost_table.add_row(username)

        if len(attribution_report.ghost_usernames) > 20:
            ghost_table.add_row(f"... and {len(attribution_report.ghost_usernames) - 20} more")

        console.print(
            Panel(
                ghost_table,
                title="[bold]Unmapped Users[/bold]",
                border_style="yellow",
            )
        )


def run_validate(
    plan_file: str,
    *,
    migration_id: str | None = None,
    output: str | None = None,
    quick: bool = False,
    include_prs: bool = False,
    state_db: str | None = None,
) -> None:
    """Run the validation process.

    Args:
        plan_file: Path to migration plan file.
        migration_id: Optional migration ID.
        output: Output path for JSON report.
        quick: Quick validation (counts only).
        include_prs: If True, also validate PR migrations.
        state_db: Path to state database file (required if include_prs is True).

    Raises:
        typer.Exit: On error.
    """
    console = get_shared_console()

    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    # Validate plan file exists
    plan_path = Path(plan_file)
    if not plan_path.exists():
        print_error(f"Plan file not found: {plan_file}")
        raise typer.Exit(1)

    # Load plan
    try:
        plan = MigrationPlan.from_json_file(plan_path)
    except Exception as e:
        print_error(f"Failed to load plan: {e}")
        raise typer.Exit(1) from None

    # Check PR validation requirements
    if include_prs and not state_db:
        # Use default state DB
        state_db = str(Path(".bb2gh") / "state.db")
        if not Path(state_db).exists():
            print_error("State database not found. Use --state-db to specify location.")
            raise typer.Exit(1)

    # Summary info
    console.print("\n[bold]Starting validation[/bold]")
    console.print(f"  Plan: [cyan]{plan_file}[/cyan]")
    console.print(f"  Source: [cyan]{plan.metadata.source_workspace}[/cyan]")
    console.print(f"  Target: [cyan]{plan.metadata.target_org}[/cyan]")
    console.print(f"  Repositories: [cyan]{len(plan.repositories)}[/cyan]")
    if migration_id:
        console.print(f"  Migration ID: [cyan]{migration_id}[/cyan]")
    if include_prs:
        console.print("  [cyan]Including PR validation[/cyan]")
    console.print()

    # Execute validation
    start_time = time.monotonic()

    try:
        from bb2gh.services.validation import ValidationStatus

        report = asyncio.run(
            _run_validation(
                plan,
                migration_id=migration_id,
                quick=quick,
            )
        )

        # Add PR validation if requested
        if include_prs:
            pr_report = asyncio.run(
                _run_pr_validation(
                    plan,
                    state_db=state_db,
                    migration_id=migration_id,
                )
            )
            report.pr_report = pr_report

        # Print summary
        _print_validation_summary(console, report)

        # Export to JSON if requested
        if output:
            output_path = Path(output)
            output_path.parent.mkdir(parents=True, exist_ok=True)

            with output_path.open("w") as f:
                json.dump(report.to_dict(), f, indent=2)

            console.print(f"\n[dim]Report saved to: {output}[/dim]")

        # Emit telemetry
        from bb2gh.cli import telemetry_helpers

        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        telemetry_helpers.emit_validation_completed(
            repos_validated=report.total,
            repos_passed=report.passed,
            repos_failed=report.failed,
            repos_warnings=report.warnings,
        )

        if report.status == ValidationStatus.PASSED:
            telemetry_helpers.emit_command_success("validate", duration_ms=elapsed_ms)
            print_success("Validation passed!")
        elif report.status == ValidationStatus.FAILED:
            telemetry_helpers.emit_command_failure("validate", error_type="validation_failed")
            print_error(f"{report.failed} repositories failed validation")
            sys.exit(1)
        elif report.status == ValidationStatus.WARNING:
            telemetry_helpers.emit_command_success("validate", duration_ms=elapsed_ms)
            print_info(f"{report.warnings} repositories have warnings")

    except ConfigurationError as e:
        from bb2gh.cli import telemetry_helpers

        telemetry_helpers.emit_command_failure("validate", error_type="ConfigurationError")
        print_error(f"Configuration error: {e}")
        sys.exit(1)
    except Exception as e:
        from bb2gh.cli import telemetry_helpers

        telemetry_helpers.emit_command_failure("validate", error_type=type(e).__name__)
        logger.exception("validation_failed", plan=plan_file)
        print_error(f"Validation failed: {e}")
        sys.exit(2)
