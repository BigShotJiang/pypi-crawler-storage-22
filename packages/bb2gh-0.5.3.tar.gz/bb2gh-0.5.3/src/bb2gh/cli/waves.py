"""Wave CLI commands.

Commands for managing wave-based migrations.

AUDIT [N8-279]: Wave commands have require_license() but are missing
is_feature_enabled(Feature.BATCH_WAVES) dual-gate checks. BATCH_WAVES is
an Ultimate-only feature, so a Free/Pro user with a valid license can
currently access wave commands. Follow-up: add dual-gate to each command.
"""

from __future__ import annotations

import asyncio
import json
from typing import TYPE_CHECKING, Any

import structlog
import typer

from bb2gh.cli.console import get_shared_console
from bb2gh.waves.config import WaveConfigParser, parse_wave_config
from bb2gh.waves.executor import WaveExecutor
from bb2gh.waves.status import WaveStatusTracker

if TYPE_CHECKING:
    from pathlib import Path

logger = structlog.get_logger(__name__)


def run_list_waves(
    config_file: Path,
    output_format: str = "table",
) -> None:
    """List all defined waves.

    Args:
        config_file: Path to wave config file.
        output_format: Output format (table or json).
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        console = get_shared_console()
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from None

    console = get_shared_console()
    try:
        config = parse_wave_config(config_file)
        tracker = WaveStatusTracker(config)

        if output_format == "json":
            waves = tracker.list_waves()
            console.print(json.dumps(waves, indent=2))
        else:
            console.print(tracker.format_table())

    except FileNotFoundError:
        console.print(f"[red]Wave config not found: {config_file}[/red]")
        raise typer.Exit(1) from None
    except Exception as e:
        console.print(f"[red]Error listing waves: {e}[/red]")
        raise typer.Exit(1) from e


def run_wave_status(
    config_file: Path,
    wave_name: str | None = None,
    output_format: str = "table",
) -> None:
    """Show wave status.

    Args:
        config_file: Path to wave config file.
        wave_name: Optional specific wave name.
        output_format: Output format (table or json).
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        console = get_shared_console()
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from None

    console = get_shared_console()
    try:
        config = parse_wave_config(config_file)
        tracker = WaveStatusTracker(config)

        if wave_name:
            status = tracker.get_wave_status(wave_name)
            if not status:
                console.print(f"[red]Wave not found: {wave_name}[/red]")
                raise typer.Exit(1)

            if output_format == "json":
                console.print(json.dumps(status, indent=2))
            else:
                console.print(f"Wave: {status['name']}")
                console.print(f"Status: {status['status']}")
                console.print(f"Progress: {status['progress_percent']:.1f}%")
                console.print(f"Completed: {status['repos_completed']}/{status['total_repos']}")
                console.print(f"Failed: {status['repos_failed']}")
        else:
            report = tracker.get_status()
            if output_format == "json":
                console.print(json.dumps(report.to_json(), indent=2))
            else:
                console.print(tracker.format_table())

    except FileNotFoundError:
        console.print(f"[red]Wave config not found: {config_file}[/red]")
        raise typer.Exit(1) from None
    except Exception as e:
        console.print(f"[red]Error getting status: {e}[/red]")
        raise typer.Exit(1) from e


def run_execute_wave(
    config_file: Path,
    wave_name: str,
    dry_run: bool = False,
) -> None:
    """Execute a specific wave.

    Args:
        config_file: Path to wave config file.
        wave_name: Wave to execute.
        dry_run: If True, show what would be migrated.
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        console = get_shared_console()
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from None

    console = get_shared_console()
    try:
        config = parse_wave_config(config_file)

        async def run() -> dict[str, Any]:
            executor = WaveExecutor(config)
            return await executor.execute_wave(wave_name, dry_run=dry_run)

        result = asyncio.run(run())

        if dry_run:
            console.print(f"[yellow]Dry run for wave: {wave_name}[/yellow]")
            console.print(f"Repositories to migrate: {result['total_repos']}")
            for repo in result["repos_to_migrate"]:
                console.print(f"  - {repo}")
        else:
            console.print(f"[green]Wave {wave_name} completed[/green]")
            console.print(f"Completed: {result['repos_completed']}")
            console.print(f"Failed: {result['repos_failed']}")

    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from e
    except Exception as e:
        console.print(f"[red]Error executing wave: {e}[/red]")
        raise typer.Exit(1) from e


def run_generate_config(
    output_file: Path,
    strategy: str = "complexity",
    num_waves: int = 3,
) -> None:
    """Generate a wave configuration file.

    Args:
        output_file: Output file path.
        strategy: Generation strategy.
        num_waves: Number of waves to generate.
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        console = get_shared_console()
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from None

    console = get_shared_console()
    try:
        parser = WaveConfigParser()

        # For now, generate empty config as template
        from bb2gh.models.wave import Wave, WaveConfig

        template_waves = [
            Wave(
                name="pilot",
                description="Pilot wave - test with low-risk repositories",
                order=0,
                repositories=["repo-a", "repo-b"],
                max_workers=2,
            ),
            Wave(
                name="main",
                description="Main wave - standard repositories",
                order=1,
                repositories=["repo-c", "repo-d", "repo-e"],
                max_workers=4,
            ),
            Wave(
                name="complex",
                description="Complex repositories requiring attention",
                order=2,
                repositories=["repo-f"],
                max_workers=2,
                continue_on_error=False,
            ),
        ]

        config = WaveConfig(
            waves=template_waves[:num_waves],
            generated_by=f"bb2gh generate:{strategy}",
        )

        parser.save_config(config, output_file)
        console.print(f"[green]Wave config generated: {output_file}[/green]")
        console.print("Edit the file to customize repository assignments.")

    except Exception as e:
        console.print(f"[red]Error generating config: {e}[/red]")
        raise typer.Exit(1) from e


def run_validate_config(config_file: Path) -> None:
    """Validate a wave configuration file.

    Args:
        config_file: Path to wave config file.
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        console = get_shared_console()
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from None

    console = get_shared_console()
    try:
        config = parse_wave_config(config_file)
        errors = config.validate_config()

        if errors:
            console.print("[red]Validation failed:[/red]")
            for error in errors:
                console.print(f"  - {error}")
            raise typer.Exit(1)
        else:
            console.print("[green]Wave config is valid[/green]")
            console.print(f"Waves: {len(config.waves)}")
            total_repos = sum(w.total_repos for w in config.waves)
            console.print(f"Total repositories: {total_repos}")

    except FileNotFoundError:
        console.print(f"[red]Wave config not found: {config_file}[/red]")
        raise typer.Exit(1) from None
    except Exception as e:
        console.print(f"[red]Error validating config: {e}[/red]")
        raise typer.Exit(1) from e
