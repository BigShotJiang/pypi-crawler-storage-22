"""Custom exceptions for bb2gh.

Provides a hierarchy of exceptions with:
- User-friendly messages
- Exit codes for CLI
- Structured error data for programmatic handling
"""

from __future__ import annotations

from enum import IntEnum
from typing import Any


class ExitCode(IntEnum):
    """CLI exit codes."""

    SUCCESS = 0
    USER_ERROR = 1  # User error (bad input, config issues)
    SYSTEM_ERROR = 2  # System error (API failures, network issues)


class BB2GHError(Exception):
    """Base exception for all bb2gh errors.

    All custom exceptions inherit from this class, allowing:
    - Consistent error handling
    - Exit code mapping
    - User-friendly message display
    """

    def __init__(
        self,
        message: str,
        *,
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        """Initialize the exception.

        Args:
            message: Human-readable error message.
            exit_code: CLI exit code for this error type.
        """
        super().__init__(message)
        self.message = message
        self.exit_code = exit_code

    def __str__(self) -> str:
        return self.message


class ConfigError(BB2GHError):
    """Configuration-related errors.

    Raised when:
    - Required configuration is missing
    - Configuration values are invalid
    - Config file cannot be read/parsed
    """

    def __init__(
        self,
        message: str,
        *,
        field: str | None = None,
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        """Initialize configuration error.

        Args:
            message: Human-readable error message.
            field: Optional field name that caused the error.
            exit_code: CLI exit code.
        """
        super().__init__(message, exit_code=exit_code)
        self.field = field


class ValidationError(BB2GHError):
    """Validation errors for user input or data.

    Raised when:
    - Input data fails validation
    - Migration plan has conflicts
    - Repository names are invalid
    """

    def __init__(
        self,
        message: str,
        *,
        errors: list[dict[str, Any]] | None = None,
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        """Initialize validation error.

        Args:
            message: Human-readable error message.
            errors: Optional list of detailed validation errors.
            exit_code: CLI exit code.
        """
        super().__init__(message, exit_code=exit_code)
        self.errors = errors or []


class APIError(BB2GHError):
    """API communication errors.

    Raised when:
    - HTTP requests fail
    - API returns error responses
    - Rate limits are exceeded
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: dict[str, Any] | None = None,
        exit_code: ExitCode = ExitCode.SYSTEM_ERROR,
    ) -> None:
        """Initialize API error.

        Args:
            message: Human-readable error message.
            status_code: HTTP status code if available.
            response_body: Response body if available.
            exit_code: CLI exit code.
        """
        # Build message with status code
        full_message = f"{message} (HTTP {status_code})" if status_code else message

        super().__init__(full_message, exit_code=exit_code)
        self.status_code = status_code
        self.response_body = response_body


class AuthenticationError(APIError):
    """Authentication-specific API errors.

    Raised when:
    - Credentials are invalid
    - Tokens are expired
    - Permission is denied
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: dict[str, Any] | None = None,
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        """Initialize authentication error.

        Args:
            message: Human-readable error message.
            status_code: HTTP status code if available.
            response_body: Response body if available.
            exit_code: CLI exit code (default USER_ERROR since credentials are user-provided).
        """
        super().__init__(
            message,
            status_code=status_code,
            response_body=response_body,
            exit_code=exit_code,
        )


class GitError(BB2GHError):
    """Git operation errors.

    Raised when:
    - Clone operations fail
    - Push operations fail
    - Git commands return errors
    """

    def __init__(
        self,
        message: str,
        *,
        command: str | None = None,
        exit_code: ExitCode = ExitCode.SYSTEM_ERROR,
    ) -> None:
        """Initialize git error.

        Args:
            message: Human-readable error message.
            command: Git command that failed.
            exit_code: CLI exit code.
        """
        super().__init__(message, exit_code=exit_code)
        self.command = command


class StateError(BB2GHError):
    """State management errors.

    Raised when:
    - State database is corrupted
    - Migration state is inconsistent
    - Resume data is invalid
    """

    def __init__(
        self,
        message: str,
        *,
        migration_id: str | None = None,
        exit_code: ExitCode = ExitCode.SYSTEM_ERROR,
    ) -> None:
        """Initialize state error.

        Args:
            message: Human-readable error message.
            migration_id: Migration ID if applicable.
            exit_code: CLI exit code.
        """
        super().__init__(message, exit_code=exit_code)
        self.migration_id = migration_id


class LimitExceededError(BB2GHError):
    """Raised when a quantitative license limit is exceeded.

    Raised when:
    - Repository count exceeds the tier's repo limit
    - Worker count exceeds the tier's worker limit
    """

    def __init__(
        self,
        limit_name: str,
        current: int,
        max_limit: int,
        *,
        message: str | None = None,
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        """Initialize limit exceeded error.

        Args:
            limit_name: Name of the limit that was exceeded (e.g., "repos", "workers").
            current: Current count that exceeded the limit.
            max_limit: Maximum allowed by the license tier.
            message: Optional custom message override.
            exit_code: CLI exit code.
        """
        if message is None:
            message = (
                f"License limit exceeded for '{limit_name}': "
                f"{current} requested but limit is {max_limit}. "
                "Contact sales@n8-group.com to upgrade."
            )
        super().__init__(message, exit_code=exit_code)
        self.limit_name = limit_name
        self.current = current
        self.max_limit = max_limit


# Aliases for convenience
ConfigurationError = ConfigError
