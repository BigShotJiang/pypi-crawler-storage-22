"""Identity resolution module for bb2gh.

Provides IdP-aware user matching for enterprise migration scenarios.
Supports Atlassian SCIM, Atlassian Org API, GitHub SAML, GitHub SCIM (EMU),
and git commit email extraction.

Enterprise feature gating: IdP integrations are behind the
``@enterprise_feature`` decorator. Currently a noop (free tier),
designed for easy migration to enterprise tier gating.
"""

from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Any, TypeVar

F = TypeVar("F", bound=Callable[..., Any])


def enterprise_feature(_feature_name: str) -> Callable[[F], F]:
    """Feature gate decorator for enterprise-tier identity features.

    Currently a noop — all features are available. Designed for easy
    migration to enterprise tier gating by replacing the inner logic
    with a license check.

    Args:
        feature_name: Name of the enterprise feature (e.g. "identity_resolution").

    Returns:
        Decorator that passes through unchanged (noop).
    """

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return func(*args, **kwargs)

        return wrapper  # type: ignore[return-value]

    return decorator
