"""Atlassian SCIM API client for identity resolution.

Queries the Atlassian SCIM provisioning API to retrieve user identities
with their IdP-assigned externalId (e.g. Okta uid, Entra objectId).

Auth: Bearer token (Directory API key — separate from Org API key).
Endpoint: https://api.atlassian.com/scim/directory/{directoryId}/Users
"""

from __future__ import annotations

from typing import Any

import httpx
import structlog

from bb2gh.identity import enterprise_feature
from bb2gh.identity.base import IdentityProvider

logger = structlog.get_logger(__name__)


@enterprise_feature("identity_resolution")
class AtlassianSCIMClient(IdentityProvider):
    """Client for Atlassian SCIM provisioning API.

    Retrieves SCIM-provisioned user identities. The key field is
    ``externalId`` which holds the IdP user ID (Okta uid, Entra objectId).
    The SCIM ``id`` field equals the Atlassian ``account_id``.
    """

    BASE_URL = "https://api.atlassian.com/scim/directory"

    def __init__(self, directory_id: str, api_key: str, *, ssl_verify: str | bool = True) -> None:
        self._directory_id = directory_id
        self._api_key = api_key
        self._ssl_verify = ssl_verify
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> AtlassianSCIMClient:
        self._client = httpx.AsyncClient(
            base_url=f"{self.BASE_URL}/{self._directory_id}",
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Accept": "application/scim+json",
            },
            timeout=30.0,
            verify=self._ssl_verify,
        )
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("Client not initialized — use 'async with'")
        return self._client

    async def list_users(self) -> list[dict[str, Any]]:
        """List all SCIM-provisioned users in the directory.

        Handles pagination via startIndex/count.

        Returns:
            List of user records with id, externalId, userName, emails, etc.
        """
        client = self._get_client()
        users: list[dict[str, Any]] = []
        start_index = 1
        count = 100

        while True:
            response = await client.get(
                "/Users",
                params={"startIndex": start_index, "count": count},
            )
            response.raise_for_status()
            data = response.json()

            resources = data.get("Resources", [])
            for resource in resources:
                users.append(self._parse_user(resource))

            total = data.get("totalResults", 0)
            fetched = len(resources)
            if fetched == 0 or len(users) >= total:
                break
            start_index += fetched

        logger.debug("atlassian_scim_users_listed", count=len(users))
        return users

    async def get_user_by_external_id(self, external_id: str) -> dict[str, Any] | None:
        """Find a user by their IdP external ID.

        Args:
            external_id: IdP-assigned user ID (e.g. Okta uid).

        Returns:
            User record if found, None otherwise.
        """
        client = self._get_client()
        response = await client.get(
            "/Users",
            params={"filter": f'externalId eq "{external_id}"'},
        )
        response.raise_for_status()
        data = response.json()

        resources = data.get("Resources", [])
        if not resources:
            return None

        return self._parse_user(resources[0])

    @staticmethod
    def _parse_user(resource: dict[str, Any]) -> dict[str, Any]:
        """Parse a SCIM user resource into a normalized dict."""
        emails = resource.get("emails", [])
        primary_email = next(
            (e["value"] for e in emails if e.get("primary")),
            emails[0]["value"] if emails else None,
        )

        name = resource.get("name", {})
        display_name = resource.get("displayName", "")
        if not display_name and name:
            display_name = f"{name.get('givenName', '')} {name.get('familyName', '')}".strip()

        return {
            "id": resource.get("id", ""),  # = Atlassian account_id
            "external_id": resource.get("externalId"),
            "username": resource.get("userName", ""),
            "email": primary_email,
            "display_name": display_name,
            "active": resource.get("active", True),
        }
