"""Base protocol for identity providers.

Defines the interface that all identity source adapters must implement.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class IdentityProvider(Protocol):
    """Protocol for identity data sources.

    Each identity provider (Atlassian SCIM, GitHub SAML, etc.) implements
    this protocol to provide user identity data for matching.
    """

    async def list_users(self) -> list[dict[str, Any]]:
        """List all users from this identity source.

        Returns:
            List of user identity records. Each record should include
            at minimum an ``id`` and ``email`` field. Additional fields
            vary by provider (e.g. ``external_id``, ``display_name``).
        """
        ...

    async def get_user_by_external_id(self, external_id: str) -> dict[str, Any] | None:
        """Look up a user by their IdP external ID.

        Args:
            external_id: The IdP-assigned user identifier
                (e.g. Okta uid, Entra objectId).

        Returns:
            User identity record if found, None otherwise.
        """
        ...
