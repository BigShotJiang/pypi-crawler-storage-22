"""Identity resolution configuration models.

Pydantic v2 models for IdP configuration, migration scenarios,
and identity matching settings.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field


class IdPMode(StrEnum):
    """Identity Provider mode for a source or target system.

    Determines which matching stages are available:
    - NONE: No IdP — only platform email, git email, and fuzzy matching
    - SAML_SSO: SAML SSO configured — SAML identity mapping available
    - SCIM: SCIM provisioning — externalId matching available (best)
    - EMU: GitHub Enterprise Managed Users — SCIM + managed usernames
    """

    NONE = "none"
    SAML_SSO = "saml_sso"
    SCIM = "scim"
    EMU = "emu"


class MigrationScenario(BaseModel):
    """Detected or configured identity migration scenario.

    Captures the IdP configuration on both source (Bitbucket/Atlassian)
    and target (GitHub) sides, plus which matching stages are active.
    """

    source_idp: IdPMode = Field(description="Source system IdP mode")
    target_idp: IdPMode = Field(description="Target system IdP mode")
    same_idp_instance: bool = Field(
        default=False,
        description="Whether source and target use the same IdP instance "
        "(e.g. both use the same Okta tenant). Enables externalId matching.",
    )
    active_stages: list[int] = Field(
        default_factory=list,
        description="Active matching waterfall stages (1-5). Determined by detected scenario.",
    )
    source_idp_type: str | None = Field(
        default=None,
        description="Source IdP type name (e.g. 'okta', 'entra_id', 'onelogin')",
    )
    target_idp_type: str | None = Field(
        default=None,
        description="Target IdP type name (e.g. 'okta', 'entra_id')",
    )


class IdentityConfig(BaseModel):
    """Configuration for identity resolution APIs.

    Holds credentials and connection details for the various identity
    APIs used during user matching. All fields are optional — only
    configure what's available for your IdP scenario.
    """

    # Atlassian Organization API
    atlassian_org_id: str | None = Field(
        default=None,
        description="Atlassian Organization ID (UUID)",
    )
    atlassian_org_api_key: str | None = Field(
        default=None,
        description="Atlassian Organization API key (admin.atlassian.com)",
    )

    # Atlassian SCIM (separate auth from Org API)
    atlassian_scim_directory_id: str | None = Field(
        default=None,
        description="Atlassian SCIM directory ID",
    )
    atlassian_scim_api_key: str | None = Field(
        default=None,
        description="Atlassian SCIM directory API key (separate from Org API key)",
    )

    # GitHub identity
    github_org: str | None = Field(
        default=None,
        description="GitHub organization name (for SAML/SCIM queries)",
    )
    github_enterprise: str | None = Field(
        default=None,
        description="GitHub enterprise slug (for EMU SCIM queries)",
    )
