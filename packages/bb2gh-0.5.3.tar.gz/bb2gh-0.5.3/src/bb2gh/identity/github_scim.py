"""GitHub SCIM API client for identity resolution.

Queries the GitHub SCIM API to retrieve provisioned user identities
for Enterprise Managed Users (EMU) or organizations with SCIM.

Auth: PAT with `scim:enterprise` scope (EMU) or `admin:org` scope (non-EMU).
Endpoint: /scim/v2/enterprises/{enterprise}/Users (EMU)
          /scim/v2/organizations/{org}/Users (non-EMU)
"""

from __future__ import annotations

from typing import Any

import httpx
import structlog

from bb2gh.identity import enterprise_feature

logger = structlog.get_logger(__name__)


@enterprise_feature("identity_resolution")
class GitHubSCIMClient:
    """Client for GitHub SCIM provisioned users.

    Supports both EMU (enterprise-level) and non-EMU (org-level) SCIM.
    The key field is ``externalId`` which maps to the IdP user ID.
    """

    def __init__(
        self,
        token: str,
        *,
        api_url: str = "https://api.github.com",
        enterprise: str | None = None,
        org: str | None = None,
        ssl_verify: str | bool = True,
    ) -> None:
        self._token = token
        self._api_url = api_url.rstrip("/")
        self._enterprise = enterprise
        self._org = org
        self._ssl_verify = ssl_verify
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> GitHubSCIMClient:
        self._client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {self._token}",
                "Accept": "application/scim+json",
            },
            timeout=30.0,
            verify=self._ssl_verify,
        )
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("Client not initialized — use 'async with'")
        return self._client

    @property
    def _scim_base(self) -> str:
        """Get the SCIM endpoint base URL."""
        if self._enterprise:
            return f"{self._api_url}/scim/v2/enterprises/{self._enterprise}"
        if self._org:
            return f"{self._api_url}/scim/v2/organizations/{self._org}"
        raise ValueError("Either enterprise or org must be configured")

    async def list_users(self) -> list[dict[str, Any]]:
        """List all SCIM-provisioned users.

        Handles pagination via startIndex/count.

        Returns:
            List of user records with externalId, userName, etc.
        """
        client = self._get_client()
        users: list[dict[str, Any]] = []
        start_index = 1
        count = 100

        while True:
            response = await client.get(
                f"{self._scim_base}/Users",
                params={"startIndex": start_index, "count": count},
            )
            response.raise_for_status()
            data = response.json()

            resources = data.get("Resources", [])
            for resource in resources:
                users.append(self._parse_user(resource))

            total = data.get("totalResults", 0)
            fetched = len(resources)
            if fetched == 0 or len(users) >= total:
                break
            start_index += fetched

        logger.debug("github_scim_users_listed", count=len(users))
        return users

    async def get_user_by_external_id(self, external_id: str) -> dict[str, Any] | None:
        """Find a user by their IdP external ID.

        Args:
            external_id: IdP-assigned user ID.

        Returns:
            User record if found, None otherwise.
        """
        client = self._get_client()
        response = await client.get(
            f"{self._scim_base}/Users",
            params={"filter": f'externalId eq "{external_id}"'},
        )
        response.raise_for_status()
        data = response.json()

        resources = data.get("Resources", [])
        if not resources:
            return None

        return self._parse_user(resources[0])

    @staticmethod
    def _parse_user(resource: dict[str, Any]) -> dict[str, Any]:
        """Parse a SCIM user resource."""
        emails = resource.get("emails", [])
        primary_email = next(
            (e["value"] for e in emails if e.get("primary")),
            emails[0]["value"] if emails else None,
        )

        name = resource.get("name", {})
        display_name = resource.get("displayName", "")
        if not display_name and name:
            display_name = f"{name.get('givenName', '')} {name.get('familyName', '')}".strip()

        return {
            "id": resource.get("id", ""),
            "external_id": resource.get("externalId"),
            "username": resource.get("userName", ""),
            "email": primary_email,
            "display_name": display_name,
            "active": resource.get("active", True),
        }
