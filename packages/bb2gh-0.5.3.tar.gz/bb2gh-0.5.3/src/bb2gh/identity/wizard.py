"""Interactive identity setup wizard.

Guides users through configuring identity providers for
high-fidelity user matching during migration.
"""

from __future__ import annotations

from dataclasses import dataclass

import structlog

from bb2gh.identity import enterprise_feature
from bb2gh.identity.config import IdentityConfig
from bb2gh.identity.detector import ScenarioDetector

logger = structlog.get_logger(__name__)

# Human-readable stage descriptions
STAGE_DESCRIPTIONS: list[dict[str, str | int]] = [
    {
        "stage": 1,
        "label": "SCIM externalId (same IdP instance)",
        "confidence": "DEFINITIVE",
    },
    {
        "stage": 2,
        "label": "IdP email (from SCIM/SAML)",
        "confidence": "HIGH",
    },
    {
        "stage": 3,
        "label": "Platform email (from BB/GH profiles)",
        "confidence": "HIGH",
    },
    {
        "stage": 4,
        "label": "Git commit email (from repositories)",
        "confidence": "MEDIUM",
    },
    {
        "stage": 5,
        "label": "Fuzzy (username + name similarity)",
        "confidence": "LOW-MEDIUM",
    },
]


@dataclass
class WizardStep:
    """A single step/question in the setup wizard."""

    key: str
    prompt: str
    choices: list[tuple[str, str]] | None = None
    is_secret: bool = False
    is_text: bool = False
    help_text: str | None = None


@enterprise_feature("identity_resolution")
class IdentitySetupWizard:
    """Interactive wizard for configuring identity resolution.

    Provides a step-by-step flow for collecting identity provider
    configuration. The CLI layer handles the actual prompting;
    this class manages question flow, validation, and config building.
    """

    def get_steps(self) -> list[WizardStep]:
        """Get the initial wizard steps.

        Returns:
            List of WizardStep objects for the initial questions.
        """
        return [
            WizardStep(
                key="source_idp",
                prompt="What identity provider does your Bitbucket/Atlassian organization use?",
                choices=[
                    ("none", "No IdP / Unknown"),
                    ("scim", "SCIM provisioning (Okta, Entra ID, etc.)"),
                    ("saml_sso", "SAML SSO (without SCIM)"),
                ],
                help_text=(
                    "SCIM provides the highest-fidelity matching via externalId. "
                    "SAML SSO provides email-based matching via the Organization API."
                ),
            ),
            WizardStep(
                key="target_idp",
                prompt="What identity setup does your GitHub organization use?",
                choices=[
                    ("none", "No IdP / Unknown"),
                    ("saml_sso", "SAML SSO (GitHub org with SSO)"),
                    ("emu", "Enterprise Managed Users (EMU)"),
                ],
                help_text=(
                    "EMU provides the best matching (SCIM externalId + managed accounts). "
                    "SAML SSO provides email-based matching via the GraphQL API."
                ),
            ),
        ]

    def get_follow_up_steps(
        self,
        answers: dict[str, str],
    ) -> list[WizardStep]:
        """Get follow-up steps based on answers so far.

        Args:
            answers: Dict of key → answer value from previous steps.

        Returns:
            List of follow-up WizardStep objects.
        """
        steps: list[WizardStep] = []

        source_idp = answers.get("source_idp", "none")
        target_idp = answers.get("target_idp", "none")

        # Source IdP follow-ups
        if source_idp == "scim":
            steps.extend(
                [
                    WizardStep(
                        key="atlassian_scim_directory_id",
                        prompt="Atlassian SCIM Directory ID:",
                        is_text=True,
                        help_text=(
                            "Found in Atlassian Admin → Directory → SCIM configuration. "
                            "Format: UUID."
                        ),
                    ),
                    WizardStep(
                        key="atlassian_scim_api_key",
                        prompt="Atlassian SCIM API Key:",
                        is_secret=True,
                        help_text="The API key generated for the SCIM directory.",
                    ),
                ]
            )
        elif source_idp == "saml_sso":
            steps.extend(
                [
                    WizardStep(
                        key="atlassian_org_id",
                        prompt="Atlassian Organization ID:",
                        is_text=True,
                        help_text=(
                            "Found in admin.atlassian.com → Settings → Organization details. "
                            "Format: UUID."
                        ),
                    ),
                    WizardStep(
                        key="atlassian_org_api_key",
                        prompt="Atlassian Organization API Key:",
                        is_secret=True,
                        help_text="Generated at admin.atlassian.com → Settings → API keys.",
                    ),
                ]
            )

        # Target IdP follow-ups
        if target_idp in ("saml_sso", "emu"):
            steps.append(
                WizardStep(
                    key="github_org",
                    prompt="GitHub organization name:",
                    is_text=True,
                    help_text="The GitHub organization slug (e.g., 'my-company').",
                ),
            )

        if target_idp == "emu":
            steps.append(
                WizardStep(
                    key="github_enterprise",
                    prompt="GitHub enterprise slug:",
                    is_text=True,
                    help_text=(
                        "The enterprise slug from github.com/enterprises/<slug>. "
                        "Required for EMU SCIM API access."
                    ),
                ),
            )

        return steps

    def build_config(
        self,
        answers: dict[str, str],
    ) -> IdentityConfig:
        """Build an IdentityConfig from wizard answers.

        Args:
            answers: Dict of key → answer value from all steps.

        Returns:
            Populated IdentityConfig.
        """
        return IdentityConfig(
            atlassian_scim_directory_id=answers.get("atlassian_scim_directory_id"),
            atlassian_scim_api_key=answers.get("atlassian_scim_api_key"),
            atlassian_org_id=answers.get("atlassian_org_id"),
            atlassian_org_api_key=answers.get("atlassian_org_api_key"),
            github_org=answers.get("github_org"),
            github_enterprise=answers.get("github_enterprise"),
        )

    async def preview_scenario(
        self,
        config: IdentityConfig,
    ) -> dict[str, object]:
        """Preview the matching scenario for a given config.

        Runs the scenario detector and returns a human-readable summary.

        Args:
            config: Identity configuration to preview.

        Returns:
            Dict with scenario details and stage descriptions.
        """
        detector = ScenarioDetector()
        scenario = await detector.detect(config)

        active_descriptions = [
            desc for desc in STAGE_DESCRIPTIONS if desc["stage"] in scenario.active_stages
        ]

        return {
            "source_idp": scenario.source_idp.value,
            "target_idp": scenario.target_idp.value,
            "same_idp_instance": scenario.same_idp_instance,
            "active_stages": scenario.active_stages,
            "stage_descriptions": active_descriptions,
        }
