"""Feature gating for bb2gh enterprise features.

Provides functions to check if features are enabled based on current license.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

import structlog

from bb2gh.exceptions import LimitExceededError
from bb2gh.models.license import (
    TIER_FEATURES,
    TIER_LIMITS,
    Feature,
    LicenseInfo,
    LicenseStatus,
    Tier,
)

logger = structlog.get_logger(__name__)

# Environment variable for license key
LICENSE_ENV_VAR = "BB2GH_LICENSE"

# Config file locations
CONFIG_LOCATIONS = [
    Path.home() / ".bb2gh" / "license",
    Path.cwd() / ".bb2gh" / "license",
]


# Embedded public keys for license validation, keyed by kid (key ID).
# Supports key rotation: when a new key is introduced, add a new entry
# with a new kid. Old entries remain to validate older licenses.
# Non-versioned formats and unknown kids are rejected (no fallback).
PUBLIC_KEYS: dict[str, bytes] = {
    "2026-01": b"""-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAu3neqvFj7FuOzK8MthviWnutfMED6I3yrZ9NsKgZyCg=
-----END PUBLIC KEY-----
""",
}

# Features available without any license (free tier)
_FREE_FEATURES: frozenset[Feature] = TIER_FEATURES[Tier.FREE]

_MAX_LICENSE_LENGTH = 65_536  # 64 KB — real licenses are ~500 bytes


@lru_cache(maxsize=1)
def get_license() -> LicenseInfo:
    """Get and validate the current license.

    License is loaded from:
    1. BB2GH_LICENSE environment variable
    2. ~/.bb2gh/license file
    3. .bb2gh/license file in current directory

    The license string is expected in the BB2GH-1- versioned format.
    The kid field in the payload is used to look up the correct public key
    from PUBLIC_KEYS for signature verification.

    Returns:
        LicenseInfo with validation status.
    """
    license_str = _load_license_string()

    if not license_str:
        logger.debug("no_license_found")
        return LicenseInfo(status=LicenseStatus.NOT_FOUND)

    # Extract kid from the license to look up the right public key
    public_key = _resolve_public_key(license_str)
    if public_key is None:
        return LicenseInfo(
            status=LicenseStatus.PARSE_ERROR,
            error="Unknown key ID (kid) in license",
        )

    from bb2gh.licensing.keys import validate_license

    return validate_license(license_str, public_key)


def _resolve_public_key(license_str: str) -> bytes | None:
    """Extract kid from license and look up public key.

    Returns None on: non-versioned format, malformed, unknown kid,
    missing kid, missing v, wrong v, any parse error. No fallbacks.
    """
    import json

    from bb2gh.licensing.keys import _b64url_decode

    prefix = "BB2GH-1-"
    if not license_str.startswith(prefix):
        return None

    rest = license_str[len(prefix) :]
    parts = rest.split(".")
    if len(parts) != 2 or not parts[0]:
        return None

    try:
        payload_bytes = _b64url_decode(parts[0])
        payload_data = json.loads(payload_bytes.decode("utf-8"))

        v = payload_data.get("v")
        if not isinstance(v, int) or v != 1:
            return None

        kid = payload_data.get("kid")
        if kid and kid in PUBLIC_KEYS:
            return PUBLIC_KEYS[kid]
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return None

    return None


def _load_license_string() -> str | None:
    """Load license string from environment or config file.

    Returns:
        License string or None if not found.
    """
    # Check environment variable first
    if license_str := os.environ.get(LICENSE_ENV_VAR):
        logger.debug("license_from_env")
        license_str = license_str.strip()
        if len(license_str) > _MAX_LICENSE_LENGTH:
            logger.warning("license_too_large", length=len(license_str))
            import sys

            print(
                f"Warning: License string is too large ({len(license_str)} bytes). "
                "This does not look like a valid license key.",
                file=sys.stderr,
            )
            return None
        return license_str

    # Check config file locations
    for config_path in CONFIG_LOCATIONS:
        # Reject symlinks (both valid and broken) for security
        if config_path.is_symlink():
            import sys

            logger.warning("license_symlink_rejected", path=str(config_path))
            print(
                f"Warning: License file is a symlink: {config_path}. "
                "Symlinks are not allowed for security.",
                file=sys.stderr,
            )
            continue

        if config_path.exists():
            try:
                license_str = config_path.read_text().strip()
                if license_str:
                    if len(license_str) > _MAX_LICENSE_LENGTH:
                        logger.warning("license_too_large", length=len(license_str))
                        import sys

                        print(
                            f"Warning: License string is too large "
                            f"({len(license_str)} bytes). "
                            "This does not look like a valid license key.",
                            file=sys.stderr,
                        )
                        return None
                    logger.debug("license_from_file", path=str(config_path))
                    return license_str
            except UnicodeDecodeError:
                import sys

                logger.warning("license_file_not_utf8", path=str(config_path))
                print(
                    f"Warning: License file contains invalid characters (not UTF-8): {config_path}",
                    file=sys.stderr,
                )
                continue
            except OSError as e:
                logger.warning("license_file_read_error", path=str(config_path), error=str(e))

    return None


def _get_effective_tier(license_info: LicenseInfo) -> Tier | None:
    """Resolve the effective tier for the given license state.

    For valid licenses: returns the license's tier.
    For expired licenses: returns Free (grace period).
    For no license / invalid: returns None.

    Args:
        license_info: Current license info.

    Returns:
        Effective Tier, or None if no usable license.
    """
    if license_info.status == LicenseStatus.VALID and license_info.license is not None:
        return license_info.license.tier

    if license_info.status == LicenseStatus.EXPIRED and license_info.license is not None:
        # Grace period: expired license falls back to Free tier
        return Tier.FREE

    return None


def is_feature_enabled(feature: Feature) -> bool:
    """Check if a feature is enabled.

    All features require a valid license. When no license exists, all features
    are disabled (including core ones). When a license is expired, the user
    falls back to Free tier features.

    Args:
        feature: Feature to check.

    Returns:
        True if feature is enabled.
    """
    license_info = get_license()

    # No license at all: nothing is enabled
    if license_info.status == LicenseStatus.NOT_FOUND:
        return False

    # Invalid or parse error: nothing is enabled
    if license_info.status in (
        LicenseStatus.INVALID_SIGNATURE,
        LicenseStatus.PARSE_ERROR,
    ):
        return False

    # Expired license: grace period — fall back to Free tier
    if license_info.status == LicenseStatus.EXPIRED:
        logger.warning(
            "license_expired_fallback",
            msg="License expired. Falling back to Free tier limits.",
        )
        return feature in _FREE_FEATURES

    # Valid license: check tier features
    if license_info.license is not None:
        tier_features = TIER_FEATURES.get(license_info.license.tier, frozenset())
        if feature in tier_features:
            return True

        # Also check explicit feature overrides on the license
        return license_info.license.has_feature(feature)

    return False


def get_enabled_features() -> list[Feature]:
    """Get list of all currently enabled features.

    Returns:
        List of enabled Feature values.
    """
    license_info = get_license()

    # No license: nothing is enabled
    if license_info.status == LicenseStatus.NOT_FOUND:
        return []

    # Invalid or parse error: nothing is enabled
    if license_info.status in (
        LicenseStatus.INVALID_SIGNATURE,
        LicenseStatus.PARSE_ERROR,
    ):
        return []

    # Expired license: grace period — Free tier only
    if license_info.status == LicenseStatus.EXPIRED:
        return sorted(_FREE_FEATURES, key=lambda f: f.value)

    # Valid license: tier features + explicit overrides
    if license_info.is_valid and license_info.license:
        tier_features = TIER_FEATURES.get(license_info.license.tier, frozenset())
        # Combine tier features with any explicit feature overrides
        all_features = tier_features | set(license_info.license.features)
        return sorted(all_features, key=lambda f: f.value)

    return []


def _get_effective_limits(license_info: LicenseInfo) -> dict[str, int]:
    """Get the effective quantitative limits for the given license state.

    For valid licenses: uses the license's limits or tier defaults.
    For expired licenses: uses Free tier limits.

    Args:
        license_info: Current license info.

    Returns:
        Dict of limit name to limit value (0 = unlimited).
    """
    effective_tier = _get_effective_tier(license_info)
    if effective_tier is None:
        # No usable license
        return TIER_LIMITS[Tier.FREE].copy()

    # Start with tier defaults
    effective = TIER_LIMITS.get(effective_tier, TIER_LIMITS[Tier.FREE]).copy()

    # For valid (non-expired) licenses, override with license-specific limits
    if (
        license_info.status == LicenseStatus.VALID
        and license_info.license is not None
        and license_info.license.payload.limits
    ):
        effective.update(license_info.license.payload.limits)

    return effective


def require_license() -> None:
    """Verify that a valid or expired license is present.

    SECURITY: This function alone is NOT sufficient for paid features.
    Always pair with is_feature_enabled() for non-FREE commands.

    Raises:
        LicenseRequiredError: If no usable license is found.
    """
    from bb2gh.licensing.decorators import LicenseRequiredError

    license_info = get_license()

    if license_info.status in (LicenseStatus.VALID, LicenseStatus.EXPIRED):
        return

    logger.warning(
        "license_denied",
        status=license_info.status.value,
        action="require_license",
    )

    if license_info.status == LicenseStatus.NOT_FOUND:
        raise LicenseRequiredError(
            message="No license found. Register for a free license: bb2gh license register"
        )
    raise LicenseRequiredError(
        message="Invalid license. Register a valid license: bb2gh license register"
    )


def check_repo_limit(count: int) -> None:
    """Check if repository count is within the license limit.

    SECURITY: Uses default-deny allowlist — only VALID and EXPIRED pass.
    Raises LimitExceededError if count exceeds the effective repo limit.
    A limit of 0 means unlimited.

    Args:
        count: Number of repositories to check.

    Raises:
        LicenseRequiredError: If no usable license exists.
        LimitExceededError: If count exceeds the repo limit.
    """
    from bb2gh.licensing.decorators import LicenseRequiredError

    license_info = get_license()

    if license_info.status not in (LicenseStatus.VALID, LicenseStatus.EXPIRED):
        logger.warning(
            "license_denied",
            status=license_info.status.value,
            action="check_repo_limit",
        )
        raise LicenseRequiredError(
            message=("No valid license found. Register for a free license: bb2gh license register")
        )

    limits = _get_effective_limits(license_info)
    max_repos = limits.get("repos", 0)

    if max_repos > 0 and count > max_repos:
        raise LimitExceededError(
            "repos",
            count,
            max_repos,
            message=(
                f"Repository limit exceeded: {count} repositories requested "
                f"but your plan allows {max_repos}. "
                "Contact sales@n8-group.com to upgrade."
            ),
        )


def check_worker_limit(count: int) -> int:
    """Check worker count against the license limit and cap if needed.

    SECURITY: Uses default-deny allowlist — only VALID and EXPIRED pass.
    Unlike check_repo_limit, this does NOT error when the limit is exceeded.
    Instead, it caps the worker count to the limit and logs a warning.
    A limit of 0 means unlimited.

    Args:
        count: Requested number of workers.

    Returns:
        The effective worker count (capped to limit if needed).

    Raises:
        LicenseRequiredError: If no usable license exists.
    """
    from bb2gh.licensing.decorators import LicenseRequiredError

    license_info = get_license()

    if license_info.status not in (LicenseStatus.VALID, LicenseStatus.EXPIRED):
        logger.warning(
            "license_denied",
            status=license_info.status.value,
            action="check_worker_limit",
        )
        raise LicenseRequiredError(
            message=("No valid license found. Register for a free license: bb2gh license register")
        )

    limits = _get_effective_limits(license_info)
    max_workers = limits.get("workers", 0)

    if max_workers > 0 and count > max_workers:
        logger.warning(
            "worker_limit_capped",
            requested=count,
            capped_to=max_workers,
            msg=(
                f"License supports up to {max_workers} workers. "
                f"Using {max_workers}. For unlimited workers, upgrade to Ultimate: "
                "sales@n8-group.com"
            ),
        )
        return max_workers

    return count


def clear_license_cache() -> None:
    """Clear the cached license (useful for testing)."""
    get_license.cache_clear()


def set_license(license_str: str) -> LicenseInfo:
    """Set and validate a license.

    Args:
        license_str: License string in BB2GH-1- format.

    Returns:
        LicenseInfo with validation status.
    """
    clear_license_cache()

    # Resolve the public key based on kid in the license
    public_key = _resolve_public_key(license_str)
    if public_key is None:
        return LicenseInfo(
            status=LicenseStatus.PARSE_ERROR,
            error="Unknown key ID (kid) in license",
        )

    from bb2gh.licensing.keys import validate_license

    license_info = validate_license(license_str, public_key)

    if license_info.is_valid:
        logger.info(
            "license_set",
            org=license_info.license.org if license_info.license else None,
            tier=license_info.license.tier.value if license_info.license else None,
            features=[f.value for f in license_info.get_enabled_features()],
        )
    else:
        logger.warning("license_set_failed", status=license_info.status.value)

    return license_info
