"""bb2gh data models package - Pydantic models for data structures."""
