"""Analysis models for bb2gh.

Models for repository analysis results including large files and LFS detection.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class LargeFile(BaseModel):
    """A file that exceeds the size threshold."""

    path: str = Field(description="File path relative to repository root")
    size_bytes: int = Field(description="File size in bytes")

    @property
    def size_mb(self) -> float:
        """File size in megabytes."""
        return self.size_bytes / (1024 * 1024)


class LargeFilesResult(BaseModel):
    """Result of large files analysis."""

    has_large_files: bool = Field(
        default=False, description="Whether any files exceed the threshold"
    )
    large_files: list[LargeFile] = Field(
        default_factory=list, description="List of files exceeding threshold"
    )
    threshold_bytes: int = Field(
        default=100_000_000, description="Size threshold used (default 100MB)"
    )
    files_scanned: int = Field(default=0, description="Total files scanned")

    @property
    def total_large_size_bytes(self) -> int:
        """Total size of all large files."""
        return sum(f.size_bytes for f in self.large_files)


class LFSResult(BaseModel):
    """Result of LFS detection."""

    has_lfs: bool = Field(default=False, description="Whether LFS is configured")
    patterns: list[str] = Field(default_factory=list, description="LFS-tracked file patterns")
    gitattributes_found: bool = Field(default=False, description="Whether .gitattributes was found")
