"""Configuration models for bb2gh.

Pydantic v2 settings for application configuration with support for:
- YAML config file (~/.bb2gh/config.yaml)
- Environment variables (BB2GH_* prefix)
- CLI flag overrides
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class BitbucketConfig(BaseModel):
    """Bitbucket API configuration."""

    base_url: str = Field(
        default="https://api.bitbucket.org/2.0",
        description="Bitbucket API base URL",
    )
    username: str | None = Field(
        default=None,
        description="Bitbucket username for app password auth",
    )
    api_token: SecretStr | None = Field(
        default=None,
        description="Bitbucket API token (replaces app_password)",
    )
    app_password: SecretStr | None = Field(
        default=None,
        description="Bitbucket app password (deprecated, use api_token instead)",
    )
    client_id: str | None = Field(
        default=None,
        description="Bitbucket OAuth client ID",
    )
    client_secret: SecretStr | None = Field(
        default=None,
        description="Bitbucket OAuth client secret",
    )

    @property
    def effective_api_token(self) -> SecretStr | None:
        """Get the effective API token, preferring api_token over app_password.

        Returns:
            The api_token if set, otherwise app_password, otherwise None.
        """
        return self.api_token or self.app_password


class GitHubConfig(BaseModel):
    """GitHub API configuration."""

    base_url: str = Field(
        default="https://api.github.com",
        description="GitHub API base URL (use custom for GitHub Server)",
    )
    token: SecretStr | None = Field(
        default=None,
        description="GitHub personal access token or fine-grained PAT",
    )
    app_id: int | None = Field(
        default=None,
        description="GitHub App ID for app authentication",
    )
    app_private_key: SecretStr | None = Field(
        default=None,
        description="GitHub App private key (PEM format)",
    )
    app_private_key_file: Path | None = Field(
        default=None,
        description="Path to GitHub App private key file (alternative to inline key)",
    )
    installation_id: int | None = Field(
        default=None,
        description="GitHub App installation ID",
    )


class LoggingConfig(BaseModel):
    """Logging configuration."""

    level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = Field(
        default="INFO",
        description="Log level",
    )
    format: Literal["console", "json"] = Field(
        default="console",
        description="Log format: console (human-readable) or json (structured)",
    )
    file: Path | None = Field(
        default=None,
        description="Optional log file path",
    )


class WebhookConfig(BaseModel):
    """Webhook configuration for notifications."""

    url: str = Field(description="Webhook endpoint URL")
    events: list[str] = Field(
        default_factory=lambda: ["migration.completed", "migration.failed"],
        description="Events to notify on",
    )
    headers: dict[str, str] = Field(
        default_factory=dict,
        description="Custom headers",
    )


class MigrationEvent(BaseModel):
    """Event payload for webhook notifications."""

    event: str
    timestamp: str
    migration_id: str
    details: dict[str, Any] = Field(default_factory=dict)


class SourceProfile(BaseModel):
    """Source system profile configuration (non-secrets only)."""

    type: Literal["bitbucket-cloud"] = Field(
        default="bitbucket-cloud",
        description="Source system type",
    )
    username: str | None = Field(default=None, description="Username for API auth")
    workspace: str | None = Field(default=None, description="Default workspace")
    auth_method: Literal["api-token", "oauth2"] = Field(
        default="api-token",
        description="Authentication method",
    )
    base_url: str = Field(
        default="https://api.bitbucket.org/2.0",
        description="API base URL",
    )
    client_id: str | None = Field(default=None, description="OAuth 2.0 client ID")


class TargetProfile(BaseModel):
    """Target system profile configuration (non-secrets only)."""

    type: Literal["github-cloud", "github-server", "github-cloud-dr"] = Field(
        default="github-cloud",
        description="Target system type",
    )
    organization: str | None = Field(default=None, description="Default target organization")
    auth_method: Literal["pat", "app"] = Field(
        default="pat",
        description="Authentication method",
    )
    base_url: str = Field(
        default="https://api.github.com",
        description="API base URL",
    )
    app_id: int | None = Field(default=None, description="GitHub App ID")
    installation_id: int | None = Field(default=None, description="GitHub App installation ID")
    app_private_key_file: Path | None = Field(
        default=None,
        description="Path to GitHub App private key PEM file",
    )


class MigrationProfile(BaseModel):
    """A named migration profile pairing source and target."""

    source: SourceProfile = Field(default_factory=SourceProfile)
    target: TargetProfile = Field(default_factory=TargetProfile)


class BB2GHSettings(BaseSettings):
    """Main bb2gh settings with environment variable support.

    Configuration precedence (highest to lowest):
    1. CLI flags
    2. Environment variables (BB2GH_*)
    3. Config file (~/.bb2gh/config.yaml)
    4. Defaults

    Environment variable examples:
        BB2GH_BITBUCKET__USERNAME=myuser
        BB2GH_GITHUB__TOKEN=ghp_xxx
        BB2GH_LOGGING__LEVEL=DEBUG
    """

    model_config = SettingsConfigDict(
        env_prefix="BB2GH_",
        env_nested_delimiter="__",
        case_sensitive=False,
    )

    bitbucket: BitbucketConfig = Field(default_factory=BitbucketConfig)
    github: GitHubConfig = Field(default_factory=GitHubConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    ssl_ca_bundle: Path | None = Field(
        default=None,
        description="Path to custom CA certificate bundle (PEM). "
        "For corporate proxies (Zscaler, Netskope) that intercept HTTPS.",
    )

    config_dir: Path = Field(
        default_factory=lambda: Path.home() / ".bb2gh",
        description="Configuration directory path",
    )
    state_dir: Path = Field(
        default=Path(".bb2gh"),
        description="State directory (relative to working directory)",
    )

    default_profile: str = Field(
        default="default",
        description="Name of the default profile to use",
    )
    profiles: dict[str, MigrationProfile] = Field(
        default_factory=dict,
        description="Named migration profiles",
    )

    @property
    def config_file(self) -> Path:
        """Path to the main config file."""
        return self.config_dir / "config.yaml"

    @property
    def state_db(self) -> Path:
        """Path to the state database."""
        return self.state_dir / "state.db"

    def get_github_private_key(self) -> str | None:
        """Get GitHub App private key from inline value or file.

        Returns:
            Private key string, or None if not configured.
        """
        if self.github.app_private_key:
            return self.github.app_private_key.get_secret_value()

        if self.github.app_private_key_file:
            key_path = Path(self.github.app_private_key_file).expanduser()
            if key_path.exists():
                return key_path.read_text()

        return None
