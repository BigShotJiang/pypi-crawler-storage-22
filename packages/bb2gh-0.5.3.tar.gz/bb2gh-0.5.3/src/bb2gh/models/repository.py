"""Repository model for bb2gh.

Represents a git repository with metadata from source or target systems.
"""

from __future__ import annotations

from datetime import datetime  # noqa: TC003
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class Repository(BaseModel):
    """Repository data model.

    Represents a git repository with its metadata.
    Used for both source (Bitbucket) and target (GitHub) repositories.
    """

    model_config = ConfigDict(frozen=True)

    id: str = Field(description="Unique identifier in the source/target system")
    name: str = Field(description="Repository name (slug)")
    full_name: str = Field(description="Full name including owner (e.g., 'org/repo')")

    description: str | None = Field(default=None, description="Repository description")
    private: bool = Field(default=True, description="Whether the repository is private")

    default_branch: str = Field(default="main", description="Default branch name")
    clone_url_https: str | None = Field(default=None, description="HTTPS clone URL")
    clone_url_ssh: str | None = Field(default=None, description="SSH clone URL")

    size_bytes: int | None = Field(default=None, description="Repository size in bytes")

    owner: str = Field(description="Owner (organization or user)")
    project: str | None = Field(default=None, description="Project key (Bitbucket)")

    created_at: datetime | None = Field(default=None, description="Creation timestamp")
    updated_at: datetime | None = Field(default=None, description="Last update timestamp")

    archived: bool = Field(default=False, description="Whether the repository is archived")
    fork: bool = Field(default=False, description="Whether this is a fork")

    source: Literal["bitbucket", "github"] = Field(description="Source system")

    # Migration-specific fields
    has_lfs: bool = Field(default=False, description="Whether repo uses Git LFS")
    has_large_files: bool = Field(default=False, description="Whether repo has files > 100MB")
    branch_count: int | None = Field(default=None, description="Number of branches")
    tag_count: int | None = Field(default=None, description="Number of tags")
