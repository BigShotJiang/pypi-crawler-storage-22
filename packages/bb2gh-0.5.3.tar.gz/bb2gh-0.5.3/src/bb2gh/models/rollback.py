"""Rollback models for bb2gh.

Pydantic v2 models for rollback planning and result tracking.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field


class RollbackScope(StrEnum):
    """What to rollback."""

    REPOS_ONLY = "repos-only"
    PRS_ONLY = "prs-only"
    EVERYTHING = "everything"


class RollbackMode(StrEnum):
    """How to rollback."""

    SOFT = "soft"  # Archive repos, close PRs with note
    STAGED = "staged"  # Select specific repos/PRs
    FULL = "full"  # Delete everything (requires confirmation)


class RollbackPlan(BaseModel):
    """Plan for a rollback operation."""

    migration_id: str
    mode: RollbackMode
    scope: RollbackScope = RollbackScope.EVERYTHING
    repos: list[str] = Field(default_factory=list)  # specific repos to rollback
    dry_run: bool = False
    confirm: bool = False  # required for FULL mode


class RollbackResult(BaseModel):
    """Result of a rollback operation."""

    migration_id: str
    mode: RollbackMode
    repos_processed: int = 0
    repos_archived: int = 0
    repos_deleted: int = 0
    repos_failed: int = 0
    prs_closed: int = 0
    prs_failed: int = 0
    errors: list[str] = Field(default_factory=list)

    @property
    def success(self) -> bool:
        """Check if rollback was fully successful."""
        return self.repos_failed == 0 and self.prs_failed == 0
