"""User mapping models for bb2gh.

Models for mapping Bitbucket users to GitHub users for PR attribution.
"""

from __future__ import annotations

from enum import StrEnum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field


class MatchConfidence(StrEnum):
    """Confidence level for user match."""

    DEFINITIVE = "definitive"  # SCIM externalId match (same IdP instance)
    HIGH = "high"  # Email exact match (IdP or platform)
    MEDIUM = "medium"  # Name fuzzy match (>80% similarity) or git email
    LOW = "low"  # No match found
    MANUAL = "manual"  # Manually specified


class MatchType(StrEnum):
    """How the match was determined."""

    SCIM_EXTERNAL_ID = "scim_external_id"  # Stage 1: SCIM externalId (same IdP)
    IDP_EMAIL = "idp_email"  # Stage 2: Email from SCIM/SAML identity
    PLATFORM_EMAIL = "platform_email"  # Stage 3: Email from BB/GH profiles
    GIT_EMAIL = "git_email"  # Stage 4: Email from git commit history
    EMAIL = "email"  # Legacy: generic email match
    NAME = "name"  # Stage 5: Matched by name (fuzzy)
    USERNAME = "username"  # Stage 5: Matched by username
    MANUAL = "manual"  # Manually specified
    UNMAPPED = "unmapped"  # No match found


class SourceUser(BaseModel):
    """A user from a source platform (Bitbucket)."""

    username: str
    email: str | None = None
    display_name: str | None = None
    account_id: str | None = None
    avatar_url: str | None = None
    external_id: str | None = None  # SCIM externalId (e.g. Okta uid, Entra objectId)
    idp_email: str | None = None  # Email from SCIM/Org API (more reliable than profile)

    def to_csv_row(self) -> dict[str, str]:
        """Convert to CSV row dict."""
        return {
            "username": self.username,
            "email": self.email or "",
            "display_name": self.display_name or "",
            "account_id": self.account_id or "",
            "external_id": self.external_id or "",
            "idp_email": self.idp_email or "",
        }


class TargetUser(BaseModel):
    """A user from a target platform (GitHub)."""

    username: str
    email: str | None = None
    name: str | None = None
    id: int | None = None
    avatar_url: str | None = None
    external_id: str | None = None  # SCIM externalId from GitHub side
    idp_email: str | None = None  # Email from SAML/SCIM identity

    def to_csv_row(self) -> dict[str, str]:
        """Convert to CSV row dict."""
        return {
            "username": self.username,
            "email": self.email or "",
            "name": self.name or "",
            "id": str(self.id) if self.id else "",
            "external_id": self.external_id or "",
            "idp_email": self.idp_email or "",
        }


class UserMapping(BaseModel):
    """Mapping from a source user to a target user."""

    source_username: str
    source_email: str | None = None
    target_username: str | None = None
    target_email: str | None = None
    match_type: MatchType = MatchType.UNMAPPED
    confidence: MatchConfidence = MatchConfidence.LOW
    match_stage: int | None = None  # Which waterfall stage matched (1-5)
    match_rule: str | None = None  # Human-readable rule description
    notes: str | None = None

    @property
    def is_mapped(self) -> bool:
        """Check if this mapping has a target user."""
        return self.target_username is not None

    def to_csv_row(self) -> dict[str, str]:
        """Convert to CSV row dict."""
        return {
            "bb_username": self.source_username,
            "bb_email": self.source_email or "",
            "gh_username": self.target_username or "",
            "gh_email": self.target_email or "",
            "match_type": self.match_type.value,
            "confidence": self.confidence.value,
            "match_stage": str(self.match_stage) if self.match_stage is not None else "",
            "match_rule": self.match_rule or "",
            "notes": self.notes or "",
        }

    @classmethod
    def from_csv_row(cls, row: dict[str, str]) -> UserMapping:
        """Create from CSV row dict.

        Backward-compatible: new fields (match_stage, match_rule) are
        optional and default to None when missing from old CSV files.
        """
        stage_str = row.get("match_stage", "")
        return cls(
            source_username=row["bb_username"],
            source_email=row.get("bb_email") or None,
            target_username=row.get("gh_username") or None,
            target_email=row.get("gh_email") or None,
            match_type=MatchType(row.get("match_type", "unmapped")),
            confidence=MatchConfidence(row.get("confidence", "low")),
            match_stage=int(stage_str) if stage_str else None,
            match_rule=row.get("match_rule") or None,
            notes=row.get("notes") or None,
        )


class MatchResult(BaseModel):
    """Result of attempting to match a source user to target users."""

    source_user: SourceUser
    target_user: TargetUser | None = None
    match_type: MatchType = MatchType.UNMAPPED
    confidence: MatchConfidence = MatchConfidence.LOW
    similarity_score: float | None = None
    alternatives: list[TargetUser] = Field(default_factory=list)

    def to_mapping(self) -> UserMapping:
        """Convert to UserMapping."""
        return UserMapping(
            source_username=self.source_user.username,
            source_email=self.source_user.email,
            target_username=self.target_user.username if self.target_user else None,
            target_email=self.target_user.email if self.target_user else None,
            match_type=self.match_type,
            confidence=self.confidence,
        )


class GhostUserConfig(BaseModel):
    """Configuration for ghost user handling."""

    username: str = Field(
        default="ghost",
        description="GitHub username to use for unmapped users",
    )
    use_authenticated_user: bool = Field(
        default=True,
        description="Use the authenticated user instead of a specific ghost user",
    )
    attribution_template: str = Field(
        default="[Migrated from Bitbucket: @{bb_username}]",
        description="Template for attribution note in PR/comment body",
    )

    def format_attribution(self, bb_username: str) -> str:
        """Format the attribution note for a Bitbucket user."""
        return self.attribution_template.format(bb_username=bb_username)


class UserMappingStore(BaseModel):
    """Complete user mapping state."""

    source_workspace: str
    target_org: str
    mappings: list[UserMapping] = Field(default_factory=list)
    ghost_config: GhostUserConfig = Field(default_factory=GhostUserConfig)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def mapped_count(self) -> int:
        """Count of mapped users."""
        return sum(1 for m in self.mappings if m.is_mapped)

    @property
    def unmapped_count(self) -> int:
        """Count of unmapped users."""
        return sum(1 for m in self.mappings if not m.is_mapped)

    def get_mapping(self, source_username: str) -> UserMapping | None:
        """Get mapping for a source username."""
        for mapping in self.mappings:
            if mapping.source_username == source_username:
                return mapping
        return None

    def resolve_user(self, source_username: str) -> tuple[str | None, str | None]:
        """Resolve a source user to target username and attribution note.

        Returns:
            Tuple of (target_username, attribution_note).
            If unmapped, returns (None, attribution_note).
        """
        mapping = self.get_mapping(source_username)
        if mapping and mapping.is_mapped:
            return mapping.target_username, None

        # Unmapped - return ghost user info
        attribution = self.ghost_config.format_attribution(source_username)
        if self.ghost_config.use_authenticated_user:
            return None, attribution
        return self.ghost_config.username, attribution

    @classmethod
    def from_csv(cls, path: str | Path) -> UserMappingStore:
        """Load a UserMappingStore from a CSV file.

        Args:
            path: Path to CSV file.

        Returns:
            UserMappingStore instance.
        """
        import csv

        path = Path(path)
        mappings = []

        with path.open(encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                mappings.append(UserMapping.from_csv_row(row))

        # Extract workspace and org from filename if possible
        # Default to empty strings
        source_workspace = ""
        target_org = ""

        return cls(
            source_workspace=source_workspace,
            target_org=target_org,
            mappings=mappings,
        )
