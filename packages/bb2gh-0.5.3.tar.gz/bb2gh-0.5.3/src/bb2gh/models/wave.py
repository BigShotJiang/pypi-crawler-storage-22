"""Wave models for batch/wave migrations."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class WaveStatus(StrEnum):
    """Wave execution status values."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    PAUSED = "paused"


class WaveFilterType(StrEnum):
    """Wave filter types."""

    EXPLICIT = "explicit"  # Explicit list of repositories
    COMPLEXITY = "complexity"  # Filter by complexity level
    ACTIVE = "active"  # Filter by active status
    SIZE = "size"  # Filter by repository size
    PATTERN = "pattern"  # Filter by name pattern


class WaveFilter(BaseModel):
    """Filter for selecting repositories in a wave."""

    filter_type: WaveFilterType
    value: Any = None

    # Complexity filter options
    complexity_level: str | None = None  # low, medium, high

    # Active filter options
    include_inactive: bool = False

    # Size filter options
    min_size_bytes: int | None = None
    max_size_bytes: int | None = None

    # Pattern filter options
    name_pattern: str | None = None  # Regex pattern

    def matches(self, repo_name: str, repo_metadata: dict[str, Any]) -> bool:
        """Check if a repository matches this filter.

        Args:
            repo_name: Repository name.
            repo_metadata: Repository metadata.

        Returns:
            True if repository matches filter.
        """
        if self.filter_type == WaveFilterType.EXPLICIT:
            repos = self.value if isinstance(self.value, list) else [self.value]
            return repo_name in repos

        if self.filter_type == WaveFilterType.COMPLEXITY:
            repo_complexity: str = repo_metadata.get("complexity", "medium")
            return repo_complexity == self.complexity_level

        if self.filter_type == WaveFilterType.ACTIVE:
            is_active: bool = repo_metadata.get("is_active", True)
            if self.include_inactive:
                return True
            return is_active

        if self.filter_type == WaveFilterType.SIZE:
            size = repo_metadata.get("size_bytes", 0)
            if self.min_size_bytes and size < self.min_size_bytes:
                return False
            return not (self.max_size_bytes and size > self.max_size_bytes)

        if self.filter_type == WaveFilterType.PATTERN:
            import re

            if self.name_pattern:
                return bool(re.match(self.name_pattern, repo_name))
            return True

        return False


class Wave(BaseModel):
    """A migration wave containing a group of repositories."""

    name: str
    description: str | None = None
    repositories: list[str] = Field(default_factory=list)
    filters: list[WaveFilter] = Field(default_factory=list)
    status: WaveStatus = WaveStatus.PENDING
    order: int = 0  # Execution order

    # Execution settings
    parallel: bool = True  # Execute repos in parallel within wave
    max_workers: int = 4
    continue_on_error: bool = True

    # Progress tracking
    repos_completed: int = 0
    repos_failed: int = 0
    started_at: datetime | None = None
    completed_at: datetime | None = None

    # Metadata
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def total_repos(self) -> int:
        """Get total repository count."""
        return len(self.repositories)

    @property
    def progress_percent(self) -> float:
        """Get progress percentage."""
        if self.total_repos == 0:
            return 0.0
        return ((self.repos_completed + self.repos_failed) / self.total_repos) * 100

    @property
    def is_complete(self) -> bool:
        """Check if wave is complete."""
        return self.status in (WaveStatus.COMPLETED, WaveStatus.FAILED)

    def add_repository(self, repo_name: str) -> None:
        """Add a repository to this wave."""
        if repo_name not in self.repositories:
            self.repositories.append(repo_name)

    def remove_repository(self, repo_name: str) -> None:
        """Remove a repository from this wave."""
        if repo_name in self.repositories:
            self.repositories.remove(repo_name)


class WaveConfig(BaseModel):
    """Configuration for wave-based migrations."""

    version: str = "1.0"
    waves: list[Wave] = Field(default_factory=list)

    # Global settings
    auto_advance: bool = False  # Auto-advance to next wave on completion
    validation_between_waves: bool = True  # Run validation between waves
    pause_on_failure: bool = True  # Pause if any wave fails

    # Generated settings
    generated_at: datetime | None = None
    generated_by: str | None = None

    def get_wave(self, name: str) -> Wave | None:
        """Get a wave by name.

        Args:
            name: Wave name.

        Returns:
            Wave if found, None otherwise.
        """
        for wave in self.waves:
            if wave.name == name:
                return wave
        return None

    def get_waves_by_status(self, status: WaveStatus) -> list[Wave]:
        """Get waves by status.

        Args:
            status: Status to filter by.

        Returns:
            List of matching waves.
        """
        return [w for w in self.waves if w.status == status]

    @property
    def pending_waves(self) -> list[Wave]:
        """Get pending waves."""
        return self.get_waves_by_status(WaveStatus.PENDING)

    @property
    def next_wave(self) -> Wave | None:
        """Get the next wave to execute."""
        pending = self.pending_waves
        if not pending:
            return None
        # Sort by order and return first
        pending.sort(key=lambda w: w.order)
        return pending[0]

    def validate_config(self) -> list[str]:
        """Validate the wave configuration.

        Returns:
            List of validation errors (empty if valid).
        """
        errors = []

        # Check for duplicate wave names
        names = [w.name for w in self.waves]
        if len(names) != len(set(names)):
            errors.append("Duplicate wave names found")

        # Check for overlapping repositories
        all_repos: set[str] = set()
        for wave in self.waves:
            for repo in wave.repositories:
                if repo in all_repos:
                    errors.append(f"Repository '{repo}' appears in multiple waves")
                all_repos.add(repo)

        # Validate wave order
        orders = [w.order for w in self.waves]
        if len(orders) != len(set(orders)):
            errors.append("Duplicate wave orders found")

        return errors


class WaveStatusReport(BaseModel):
    """Status report for wave migrations."""

    config_version: str = "1.0"
    total_waves: int = 0
    waves_completed: int = 0
    waves_in_progress: int = 0
    waves_pending: int = 0
    waves_failed: int = 0

    total_repos: int = 0
    repos_completed: int = 0
    repos_failed: int = 0
    repos_pending: int = 0

    wave_details: list[dict[str, Any]] = Field(default_factory=list)

    generated_at: datetime = Field(default_factory=lambda: datetime.now())

    @property
    def overall_progress(self) -> float:
        """Get overall progress percentage."""
        if self.total_repos == 0:
            return 0.0
        return (self.repos_completed / self.total_repos) * 100

    def to_json(self) -> dict[str, Any]:
        """Convert to JSON-serializable dict."""
        return {
            "config_version": self.config_version,
            "total_waves": self.total_waves,
            "waves_completed": self.waves_completed,
            "waves_in_progress": self.waves_in_progress,
            "waves_pending": self.waves_pending,
            "waves_failed": self.waves_failed,
            "total_repos": self.total_repos,
            "repos_completed": self.repos_completed,
            "repos_failed": self.repos_failed,
            "repos_pending": self.repos_pending,
            "overall_progress": self.overall_progress,
            "wave_details": self.wave_details,
            "generated_at": self.generated_at.isoformat(),
        }
