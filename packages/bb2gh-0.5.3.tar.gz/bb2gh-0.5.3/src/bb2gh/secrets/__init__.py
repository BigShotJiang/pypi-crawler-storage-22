"""Secrets management module for bb2gh.

Handles discovery, inventory, and scaffolding of secrets during migration.

AUDIT [N8-279]: Service-layer entry points do NOT have
@requires_feature(Feature.SECRETS_MANAGEMENT) decorators. Feature gating is
currently enforced at the CLI layer (dual-gate: require_license +
is_feature_enabled in secrets.py). Follow-up: add decorators to service
entry points for defense-in-depth.
"""

from bb2gh.secrets.checklist import SecretsChecklistService
from bb2gh.secrets.inventory import SecretsInventoryService
from bb2gh.secrets.scaffold import SecretsScaffoldService
from bb2gh.secrets.validation import SecretsValidationService

__all__ = [
    "SecretsChecklistService",
    "SecretsInventoryService",
    "SecretsScaffoldService",
    "SecretsValidationService",
]
