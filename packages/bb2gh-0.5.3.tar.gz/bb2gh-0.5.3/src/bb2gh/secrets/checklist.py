"""Secrets checklist service for bb2gh.

Generates checklists for manual secret population.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

import structlog

from bb2gh.models.secret import (
    SecretInventory,
    SecretMigrationItem,
    SecretMigrationStatus,
    SecretScope,
)

logger = structlog.get_logger(__name__)


class SecretsChecklistService:
    """Service for generating secret migration checklists."""

    def generate_checklist(
        self,
        inventory: SecretInventory,
        *,
        target_org: str,  # noqa: ARG002
        repo_mapping: dict[str, str] | None = None,  # noqa: ARG002
    ) -> list[SecretMigrationItem]:
        """Generate a migration checklist from inventory.

        Args:
            inventory: Source secret inventory.
            target_org: Target GitHub organization.
            repo_mapping: Optional source to target repo mapping.

        Returns:
            List of SecretMigrationItem for checklist.
        """
        items: list[SecretMigrationItem] = []

        for secret in inventory.secrets:
            # Determine target scope
            target_scope = self._map_scope(secret.scope)

            item = SecretMigrationItem(
                source_name=secret.name,
                source_type=secret.secret_type,
                source_scope=secret.scope,
                target_scope=target_scope,
                repository=secret.repository,
                environment=secret.environment,
            )
            items.append(item)

        # Sort by repository, then by name
        items.sort(key=lambda x: (x.repository or "", x.source_name))

        return items

    def _map_scope(self, source_scope: SecretScope) -> SecretScope:
        """Map source scope to target scope.

        Args:
            source_scope: Source platform scope.

        Returns:
            Target platform scope.
        """
        scope_mapping = {
            SecretScope.REPOSITORY: SecretScope.REPOSITORY,
            SecretScope.ENVIRONMENT: SecretScope.ENVIRONMENT,
            SecretScope.WORKSPACE: SecretScope.ORGANIZATION,
            SecretScope.ORGANIZATION: SecretScope.ORGANIZATION,
        }
        return scope_mapping.get(source_scope, SecretScope.REPOSITORY)

    def export_csv(
        self,
        items: list[SecretMigrationItem],
        output_path: Path | str,
    ) -> None:
        """Export checklist to CSV file.

        Args:
            items: Checklist items.
            output_path: Output file path.
        """
        output_path = Path(output_path)

        with output_path.open("w", newline="", encoding="utf-8") as f:
            fieldnames = [
                "repo",
                "secret_name",
                "secret_type",
                "source_scope",
                "target_scope",
                "status",
                "notes",
            ]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()

            for item in items:
                writer.writerow(item.to_csv_row())

        logger.info("checklist_exported", path=str(output_path), count=len(items))

    def import_csv(
        self,
        input_path: Path | str,
    ) -> list[SecretMigrationItem]:
        """Import checklist from CSV file.

        Args:
            input_path: Input file path.

        Returns:
            List of SecretMigrationItem.
        """
        input_path = Path(input_path)
        items: list[SecretMigrationItem] = []

        from bb2gh.models.secret import SecretType

        with input_path.open(encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                item = SecretMigrationItem(
                    source_name=row["secret_name"],
                    source_type=SecretType(row["secret_type"]),
                    source_scope=SecretScope(row["source_scope"]),
                    target_scope=SecretScope(row["target_scope"]),
                    repository=row.get("repo") or None,
                    status=SecretMigrationStatus(row.get("status", "pending")),
                    notes=row.get("notes") or None,
                )
                items.append(item)

        return items

    def get_summary_stats(
        self,
        items: list[SecretMigrationItem],
    ) -> dict[str, Any]:
        """Get summary statistics for checklist.

        Args:
            items: Checklist items.

        Returns:
            Dictionary with summary statistics.
        """
        # Count by status
        by_status: dict[str, int] = {}
        for item in items:
            status = item.status.value
            by_status[status] = by_status.get(status, 0) + 1

        # Count by scope
        by_scope: dict[str, int] = {}
        for item in items:
            scope = item.source_scope.value
            by_scope[scope] = by_scope.get(scope, 0) + 1

        # Count by repository
        by_repo: dict[str, int] = {}
        for item in items:
            repo = item.repository or "(workspace)"
            by_repo[repo] = by_repo.get(repo, 0) + 1

        return {
            "total": len(items),
            "by_status": by_status,
            "by_scope": by_scope,
            "by_repository": by_repo,
            "pending": by_status.get("pending", 0),
            "completed": by_status.get("populated", 0) + by_status.get("verified", 0),
        }
