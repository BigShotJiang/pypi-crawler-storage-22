"""Branch protection mapping and migration service.

Translates Bitbucket Cloud branch restrictions to GitHub Enterprise Cloud
rulesets. Implements the full 16-kind translation table with consolidation.
"""

from __future__ import annotations

from typing import Any

import structlog

from bb2gh.models.branch_protection import (
    BranchMatchKind,
    BranchProtectionPlan,
    BranchRestriction,
    BranchRestrictionKind,
    DefaultReviewer,
    GitHubRulesetConfig,
    MappingStatus,
    PullRequestRuleParams,
    RefNameCondition,
    RepoBranchProtection,
    RepositoryNameCondition,
    RestrictionMapping,
    RulesetConditions,
    RulesetEnforcement,
    RulesetRule,
    RulesetScope,
    RulesetTarget,
    StatusChecksRuleParams,
)

logger = structlog.get_logger(__name__)

# Kinds that have no GitHub equivalent
_UNMAPPABLE_KINDS: dict[BranchRestrictionKind, str] = {
    BranchRestrictionKind.REQUIRE_ALL_DEPENDENCIES_MERGED: ("GitHub has no PR dependency concept"),
    BranchRestrictionKind.SMART_RESET_PULLREQUEST_APPROVALS: (
        "GitHub has no diff-aware approval reset"
    ),
    BranchRestrictionKind.RESET_PULLREQUEST_CHANGES_REQUESTED_ON_CHANGE: (
        "GitHub doesn't auto-reset change requests on source change"
    ),
}

# Default branch type fallback patterns when branching model is unavailable
_BRANCH_TYPE_FALLBACKS: dict[str, str] = {
    "production": "main",
    "development": "develop",
    "feature": "feature/*",
    "bugfix": "bugfix/*",
    "release": "release/*",
    "hotfix": "hotfix/*",
}


class BranchProtectionMapper:
    """Maps Bitbucket branch restrictions to GitHub rulesets."""

    def map_restrictions(
        self,
        protection: RepoBranchProtection,
        target_repo: str,
        *,
        user_mapping: dict[str, str] | None = None,
    ) -> BranchProtectionPlan:
        """Map all restrictions to a branch protection plan.

        Groups restrictions by branch pattern, maps each restriction,
        consolidates into minimal rulesets, and generates warnings.

        Args:
            protection: Source branch protection data.
            target_repo: Target repository name (org/repo).
            user_mapping: Optional BB UUID -> GH username mapping.

        Returns:
            Complete migration plan.
        """
        if not protection.restrictions:
            return BranchProtectionPlan(
                source_repo=protection.repo_full_name,
                target_repo=target_repo,
            )

        # Step 1: Map each restriction individually
        mappings: list[RestrictionMapping] = []
        for restriction in protection.restrictions:
            mapping = self._map_single_restriction(restriction)
            mappings.append(mapping)

        # Step 2: Group by resolved branch pattern
        grouped = self._consolidate_by_pattern(
            protection.restrictions,
            mappings,
            protection.branching_model,
        )

        # Step 3: Build rulesets from groups
        rulesets: list[GitHubRulesetConfig] = []
        for pattern, group_mappings in grouped.items():
            ruleset = self._build_ruleset(pattern, group_mappings)
            if ruleset is not None:
                rulesets.append(ruleset)

        # Step 4: Check if manual review needed
        requires_review = any(
            m.status in (MappingStatus.UNMAPPED, MappingStatus.APPROXIMATE) for m in mappings
        )

        # Step 5: Generate warnings
        warnings: list[str] = []
        for m in mappings:
            warnings.extend(m.warnings)

        # Step 6: Generate CODEOWNERS if needed
        codeowners = self._generate_codeowners(
            protection.default_reviewers,
            user_mapping or {},
        )

        # Step 7: Check for auto-merge
        enable_auto_merge = any(
            m.source.kind == BranchRestrictionKind.ALLOW_AUTO_MERGE_WHEN_BUILDS_PASS
            for m in mappings
        )

        return BranchProtectionPlan(
            source_repo=protection.repo_full_name,
            target_repo=target_repo,
            mappings=mappings,
            rulesets=rulesets,
            warnings=warnings,
            requires_manual_review=requires_review,
            codeowners_content=codeowners,
            enable_auto_merge=enable_auto_merge,
        )

    def _map_single_restriction(self, restriction: BranchRestriction) -> RestrictionMapping:
        """Map a single BB restriction to a GH ruleset rule.

        Implements the full 16-kind translation table from the spec.

        Args:
            restriction: Source BB restriction.

        Returns:
            RestrictionMapping with status and optional target rule.
        """
        kind = restriction.kind

        # --- Direct mappings ---

        if kind == BranchRestrictionKind.FORCE:
            return RestrictionMapping(
                source=restriction,
                target_rule=RulesetRule(type="non_fast_forward"),
                status=MappingStatus.MAPPED,
            )

        if kind == BranchRestrictionKind.DELETE:
            return RestrictionMapping(
                source=restriction,
                target_rule=RulesetRule(type="deletion"),
                status=MappingStatus.MAPPED,
            )

        if kind == BranchRestrictionKind.REQUIRE_APPROVALS_TO_MERGE:
            return RestrictionMapping(
                source=restriction,
                target_rule=RulesetRule(
                    type="pull_request",
                    parameters=PullRequestRuleParams(
                        required_approving_review_count=restriction.value or 1,
                    ),
                ),
                status=MappingStatus.MAPPED,
            )

        if kind == BranchRestrictionKind.REQUIRE_DEFAULT_REVIEWER_APPROVALS_TO_MERGE:
            return RestrictionMapping(
                source=restriction,
                target_rule=RulesetRule(
                    type="pull_request",
                    parameters=PullRequestRuleParams(
                        require_code_owner_review=True,
                    ),
                ),
                status=MappingStatus.MAPPED,
                notes="Requires CODEOWNERS file generated from BB default reviewers",
            )

        if kind == BranchRestrictionKind.REQUIRE_PASSING_BUILDS_TO_MERGE:
            return RestrictionMapping(
                source=restriction,
                target_rule=RulesetRule(
                    type="required_status_checks",
                    parameters=StatusChecksRuleParams(
                        do_not_enforce_on_create=True,
                    ),
                ),
                status=MappingStatus.MAPPED,
                notes="Status check contexts must be configured manually",
            )

        if kind == BranchRestrictionKind.RESET_PULLREQUEST_APPROVALS_ON_CHANGE:
            return RestrictionMapping(
                source=restriction,
                target_rule=RulesetRule(
                    type="pull_request",
                    parameters=PullRequestRuleParams(
                        dismiss_stale_reviews_on_push=True,
                    ),
                ),
                status=MappingStatus.MAPPED,
            )

        if kind == BranchRestrictionKind.PUSH:
            return RestrictionMapping(
                source=restriction,
                target_rule=RulesetRule(type="non_fast_forward"),
                status=MappingStatus.MAPPED,
                notes="BB push restriction mapped to bypass_actors on ruleset",
            )

        if kind == BranchRestrictionKind.RESTRICT_MERGES:
            return RestrictionMapping(
                source=restriction,
                target_rule=RulesetRule(
                    type="pull_request",
                    parameters=PullRequestRuleParams(),
                ),
                status=MappingStatus.MAPPED,
                notes="BB restrict_merges mapped to pull_request rule with bypass_actors",
            )

        if kind == BranchRestrictionKind.ALLOW_AUTO_MERGE_WHEN_BUILDS_PASS:
            return RestrictionMapping(
                source=restriction,
                target_rule=None,
                status=MappingStatus.MAPPED,
                notes="Enable auto_merge repo setting via separate API call",
            )

        # --- Implicit (no action needed) ---

        if kind == BranchRestrictionKind.ENFORCE_MERGE_CHECKS:
            return RestrictionMapping(
                source=restriction,
                target_rule=None,
                status=MappingStatus.IMPLICIT,
                notes="GitHub rulesets always enforce merge checks",
            )

        # --- Approximate mappings ---

        if kind == BranchRestrictionKind.REQUIRE_TASKS_TO_BE_COMPLETED:
            return RestrictionMapping(
                source=restriction,
                target_rule=RulesetRule(
                    type="pull_request",
                    parameters=PullRequestRuleParams(
                        required_review_thread_resolution=True,
                    ),
                ),
                status=MappingStatus.APPROXIMATE,
                notes="BB tasks mapped to GH review thread resolution",
                warnings=[
                    "Behavioral difference: BB PR tasks are not the same as "
                    "GH review thread resolution"
                ],
            )

        if kind == BranchRestrictionKind.REQUIRE_NO_CHANGES_REQUESTED:
            return RestrictionMapping(
                source=restriction,
                target_rule=RulesetRule(
                    type="pull_request",
                    parameters=PullRequestRuleParams(
                        required_review_thread_resolution=True,
                    ),
                ),
                status=MappingStatus.APPROXIMATE,
                notes="BB no-changes-requested mapped to GH review thread resolution",
                warnings=[
                    "Behavioral difference: BB 'no changes requested' != "
                    "GH review thread resolution"
                ],
            )

        if kind == BranchRestrictionKind.REQUIRE_COMMITS_BEHIND:
            return RestrictionMapping(
                source=restriction,
                target_rule=RulesetRule(
                    type="required_status_checks",
                    parameters=StatusChecksRuleParams(
                        strict_required_status_checks_policy=True,
                    ),
                ),
                status=MappingStatus.APPROXIMATE,
                notes=(
                    f"BB require_commits_behind (max {restriction.value} commits) "
                    "mapped to GH strict up-to-date policy (boolean)"
                ),
                warnings=[
                    "BB uses numeric commit count, GH only has boolean 'require up-to-date' policy"
                ],
            )

        # --- Unmappable ---

        if kind in _UNMAPPABLE_KINDS:
            return RestrictionMapping(
                source=restriction,
                target_rule=None,
                status=MappingStatus.UNMAPPED,
                notes=_UNMAPPABLE_KINDS[kind],
                warnings=[f"No GitHub equivalent for BB '{kind.value}': {_UNMAPPABLE_KINDS[kind]}"],
            )

        # Fallback for unknown kinds
        return RestrictionMapping(
            source=restriction,
            target_rule=None,
            status=MappingStatus.UNMAPPED,
            notes=f"Unknown BB restriction kind: {kind.value}",
            warnings=[f"Unknown BB restriction kind: {kind.value}"],
        )

    def _consolidate_by_pattern(
        self,
        restrictions: list[BranchRestriction],
        mappings: list[RestrictionMapping],
        branching_model: dict[str, Any] | None,
    ) -> dict[str, list[RestrictionMapping]]:
        """Group mappings by resolved branch pattern.

        Args:
            restrictions: Source restrictions.
            mappings: Corresponding mappings.
            branching_model: BB branching model for resolution.

        Returns:
            Dict of pattern -> list of mappings.
        """
        grouped: dict[str, list[RestrictionMapping]] = {}
        for restriction, mapping in zip(restrictions, mappings, strict=True):
            pattern = self._resolve_branch_pattern(
                restriction,
                branching_model,
            )
            if pattern not in grouped:
                grouped[pattern] = []
            grouped[pattern].append(mapping)
        return grouped

    def _build_ruleset(
        self,
        pattern: str,
        mappings: list[RestrictionMapping],
    ) -> GitHubRulesetConfig | None:
        """Build a single GitHub ruleset from mappings for a pattern.

        Combines multiple mapped rules into one ruleset.

        Args:
            pattern: Branch pattern this ruleset targets.
            mappings: Mappings for this pattern.

        Returns:
            GitHubRulesetConfig, or None if no rules to create.
        """
        rules: list[RulesetRule] = []
        seen_types: set[str] = set()
        pr_params = PullRequestRuleParams()
        has_pr_params = False

        for mapping in mappings:
            if mapping.target_rule is None:
                continue

            rule_type = mapping.target_rule.type

            # Consolidate pull_request parameters into a single rule
            if rule_type == "pull_request" and mapping.target_rule.parameters:
                params = mapping.target_rule.parameters
                if isinstance(params, PullRequestRuleParams):
                    has_pr_params = True
                    if params.required_approving_review_count > 0:
                        pr_params.required_approving_review_count = max(
                            pr_params.required_approving_review_count,
                            params.required_approving_review_count,
                        )
                    if params.dismiss_stale_reviews_on_push:
                        pr_params.dismiss_stale_reviews_on_push = True
                    if params.require_code_owner_review:
                        pr_params.require_code_owner_review = True
                    if params.required_review_thread_resolution:
                        pr_params.required_review_thread_resolution = True
                    if params.require_last_push_approval:
                        pr_params.require_last_push_approval = True
                continue

            # Non-PR rules: add once per type
            if rule_type not in seen_types:
                seen_types.add(rule_type)
                rules.append(mapping.target_rule)

        # Add consolidated PR rule if any PR params were set
        if has_pr_params:
            rules.append(RulesetRule(type="pull_request", parameters=pr_params))

        if not rules:
            return None

        # Build ref_name condition
        ref_pattern = f"refs/heads/{pattern}" if not pattern.startswith("refs/") else pattern
        conditions = RulesetConditions(
            ref_name=RefNameCondition(
                include=[ref_pattern],
                exclude=[],
            ),
        )

        # Generate a descriptive name
        name = f"bb2gh-{pattern.replace('/', '-').replace('*', 'all')}"

        return GitHubRulesetConfig(
            name=name,
            target=RulesetTarget.BRANCH,
            enforcement=RulesetEnforcement.EVALUATE,
            conditions=conditions,
            rules=rules,
        )

    def _generate_codeowners(
        self,
        default_reviewers: list[DefaultReviewer],
        user_mapping: dict[str, str],
    ) -> str | None:
        """Generate CODEOWNERS content from BB default reviewers.

        Args:
            default_reviewers: BB default reviewers.
            user_mapping: BB UUID -> GH username mapping.

        Returns:
            CODEOWNERS file content, or None if no reviewers.
        """
        if not default_reviewers:
            return None

        lines = [
            "# CODEOWNERS - Generated by bb2gh from Bitbucket default reviewers",
            "# Review and adjust paths as needed",
            "",
        ]

        owners: list[str] = []
        for reviewer in default_reviewers:
            gh_username = user_mapping.get(reviewer.uuid)
            if gh_username:
                owners.append(f"@{gh_username}")
            else:
                # Include as comment for manual resolution
                display = reviewer.display_name or reviewer.uuid
                owners.append(f"# UNMAPPED: {display} ({reviewer.uuid})")

        # Global ownership
        mapped_owners = [o for o in owners if not o.startswith("#")]
        unmapped_owners = [o for o in owners if o.startswith("#")]

        if mapped_owners:
            lines.append(f"* {' '.join(mapped_owners)}")
        if unmapped_owners:
            lines.append("")
            lines.append("# The following reviewers could not be mapped:")
            lines.extend(unmapped_owners)

        lines.append("")
        return "\n".join(lines)

    def _resolve_branch_pattern(
        self,
        restriction: BranchRestriction,
        branching_model: dict[str, Any] | None,
    ) -> str:
        """Resolve a branch restriction to a concrete branch pattern.

        For glob match kind, returns the pattern directly.
        For branching_model match kind, resolves the branch type using
        the repository's branching model configuration.

        Args:
            restriction: The restriction to resolve.
            branching_model: BB branching model data (may be None).

        Returns:
            Resolved branch pattern string.
        """
        if restriction.branch_match_kind == BranchMatchKind.GLOB:
            return restriction.pattern or "*"

        # Branching model resolution
        branch_type = restriction.branch_type
        if branch_type is None:
            return "*"

        bt_value = branch_type.value

        if branching_model is not None:
            # Production and development are top-level keys
            if bt_value in ("production", "development"):
                config = branching_model.get(bt_value, {})
                if isinstance(config, dict):
                    name = config.get("name")
                    if name:
                        return str(name)
                    # development with use_mainbranch
                    if bt_value == "development" and config.get("use_mainbranch"):
                        return "main"

            # Branch types (feature, bugfix, release, hotfix) are in branch_types array
            branch_types = branching_model.get("branch_types", [])
            if isinstance(branch_types, list):
                for bt in branch_types:
                    if isinstance(bt, dict) and bt.get("kind") == bt_value:
                        prefix = bt.get("prefix", "")
                        if prefix:
                            return f"{prefix}*"

        # Fallback to defaults
        return _BRANCH_TYPE_FALLBACKS.get(bt_value, bt_value)

    def _ruleset_fingerprint(self, ruleset: GitHubRulesetConfig) -> str:
        """Generate a fingerprint for a ruleset based on its rules and conditions.

        Two rulesets with the same fingerprint have identical rules and
        branch patterns, making them candidates for org-level consolidation.

        Args:
            ruleset: The ruleset to fingerprint.

        Returns:
            A string fingerprint.
        """
        rule_types = sorted(r.type for r in ruleset.rules)
        ref_includes = sorted(ruleset.conditions.ref_name.include)
        return f"{','.join(rule_types)}|{','.join(ref_includes)}"

    def analyze_org_patterns(
        self,
        all_plans: list[BranchProtectionPlan],
        *,
        threshold: float = 0.7,
    ) -> list[GitHubRulesetConfig]:
        """Analyze plans across repos and propose org-level rulesets.

        When a ruleset fingerprint (same rules + branch conditions) appears
        in >= threshold fraction of repos, it is proposed as an org-level
        ruleset to reduce per-repo duplication.

        Args:
            all_plans: Plans for all repos.
            threshold: Fraction of repos that must share a pattern (0.0-1.0).

        Returns:
            List of proposed org-level rulesets.
        """
        if not all_plans:
            return []

        total_repos = len(all_plans)
        if total_repos == 0:
            return []

        min_count = max(1, int(total_repos * threshold))

        # Collect fingerprints and track which repos have each one
        fingerprint_repos: dict[str, list[str]] = {}
        fingerprint_ruleset: dict[str, GitHubRulesetConfig] = {}

        for plan in all_plans:
            for ruleset in plan.rulesets:
                fp = self._ruleset_fingerprint(ruleset)
                if fp not in fingerprint_repos:
                    fingerprint_repos[fp] = []
                    fingerprint_ruleset[fp] = ruleset
                fingerprint_repos[fp].append(plan.target_repo)

        # Build org-level rulesets for patterns meeting threshold
        org_rulesets: list[GitHubRulesetConfig] = []
        for fp, repos in fingerprint_repos.items():
            if len(repos) >= min_count:
                source_ruleset = fingerprint_ruleset[fp]
                # Deduplicate repo names
                unique_repos = sorted(set(repos))

                org_ruleset = GitHubRulesetConfig(
                    name=f"bb2gh-org-{source_ruleset.name}",
                    target=source_ruleset.target,
                    enforcement=RulesetEnforcement.EVALUATE,
                    scope=RulesetScope.ORGANIZATION,
                    conditions=RulesetConditions(
                        ref_name=source_ruleset.conditions.ref_name,
                        repository_name=RepositoryNameCondition(
                            include=unique_repos,
                        ),
                    ),
                    rules=source_ruleset.rules,
                )
                org_rulesets.append(org_ruleset)

        return org_rulesets


class BranchProtectionService:
    """Orchestrates branch protection discovery, planning, application, and rollback.

    Coordinates between source/target adapters and the mapper to provide
    the full branch protection migration lifecycle.
    """

    #: Prefix used for all bb2gh-created rulesets (used for rollback filtering).
    RULESET_PREFIX = "bb2gh-"

    def __init__(
        self,
        *,
        source_adapter: Any,
        target_adapter: Any,
        user_mapping: dict[str, str] | None = None,
    ) -> None:
        """Initialize the service.

        Args:
            source_adapter: SourceAdapter for reading BB protection data.
            target_adapter: TargetAdapter for creating GH rulesets.
            user_mapping: Optional BB UUID -> GH username mapping.
        """
        self._source = source_adapter
        self._target = target_adapter
        self._user_mapping = user_mapping or {}
        self._mapper = BranchProtectionMapper()

    async def plan(
        self,
        source_repo: str,
        target_repo: str,
    ) -> BranchProtectionPlan:
        """Discover BB protection and generate a migration plan.

        Args:
            source_repo: Source BB repo (workspace/repo).
            target_repo: Target GH repo (org/repo).

        Returns:
            Complete migration plan.
        """
        protection = await self._source.get_branch_protection(source_repo)

        if protection is None:
            return BranchProtectionPlan(
                source_repo=source_repo,
                target_repo=target_repo,
            )

        return self._mapper.map_restrictions(
            protection,
            target_repo,
            user_mapping=self._user_mapping,
        )

    async def apply(
        self,
        plan: BranchProtectionPlan,
    ) -> list[dict[str, Any]]:
        """Apply a branch protection plan by creating rulesets.

        Creates rulesets in the target repository. Continues on error
        (one failing ruleset doesn't block others).

        Args:
            plan: The plan to apply.

        Returns:
            List of created ruleset responses.
        """
        results: list[dict[str, Any]] = []

        for ruleset_config in plan.rulesets:
            try:
                result = await self._target.create_repository_ruleset(
                    plan.target_repo,
                    ruleset_config,
                )
                results.append(result)
                logger.info(
                    "ruleset_applied",
                    repo=plan.target_repo,
                    ruleset_name=ruleset_config.name,
                    ruleset_id=result.get("id"),
                )
            except Exception:
                logger.exception(
                    "ruleset_apply_failed",
                    repo=plan.target_repo,
                    ruleset_name=ruleset_config.name,
                )

        # Enable auto-merge if flagged in the plan
        if plan.enable_auto_merge:
            try:
                await self._target.enable_auto_merge(plan.target_repo)
                logger.info("auto_merge_enabled", repo=plan.target_repo)
            except Exception:
                logger.exception(
                    "auto_merge_enable_failed",
                    repo=plan.target_repo,
                )

        return results

    async def validate(
        self,
        plan: BranchProtectionPlan,
    ) -> list[str]:
        """Validate that applied rulesets match the plan.

        Args:
            plan: The plan to validate against.

        Returns:
            List of validation issue strings (empty = all good).
        """
        issues: list[str] = []

        existing = await self._target.list_repository_rulesets(plan.target_repo)
        existing_names = {r.get("name") for r in existing}

        for ruleset_config in plan.rulesets:
            if ruleset_config.name not in existing_names:
                issues.append(f"Missing ruleset '{ruleset_config.name}' in {plan.target_repo}")

        return issues

    async def rollback(self, target_repo: str) -> None:
        """Delete all bb2gh-created rulesets from a repository.

        Only deletes rulesets with the bb2gh- prefix to avoid
        removing pre-existing rulesets.

        Args:
            target_repo: Repository to rollback (org/repo).
        """
        existing = await self._target.list_repository_rulesets(target_repo)

        for ruleset in existing:
            name = ruleset.get("name", "")
            if name.startswith(self.RULESET_PREFIX):
                ruleset_id = ruleset["id"]
                try:
                    await self._target.delete_repository_ruleset(
                        target_repo,
                        ruleset_id,
                    )
                    logger.info(
                        "ruleset_rolled_back",
                        repo=target_repo,
                        ruleset_id=ruleset_id,
                        name=name,
                    )
                except Exception:
                    logger.exception(
                        "ruleset_rollback_failed",
                        repo=target_repo,
                        ruleset_id=ruleset_id,
                    )

    async def promote(self, target_repo: str) -> None:
        """Promote bb2gh rulesets from evaluate to active enforcement.

        Args:
            target_repo: Repository to promote (org/repo).
        """
        existing = await self._target.list_repository_rulesets(target_repo)

        for ruleset in existing:
            name = ruleset.get("name", "")
            enforcement = ruleset.get("enforcement", "")
            if name.startswith(self.RULESET_PREFIX) and enforcement == "evaluate":
                ruleset_id = ruleset["id"]
                try:
                    await self._target._request(
                        "PUT",
                        f"/repos/{target_repo}/rulesets/{ruleset_id}",
                        json={"enforcement": "active"},
                    )
                    logger.info(
                        "ruleset_promoted",
                        repo=target_repo,
                        ruleset_id=ruleset_id,
                        name=name,
                    )
                except Exception:
                    logger.exception(
                        "ruleset_promote_failed",
                        repo=target_repo,
                        ruleset_id=ruleset_id,
                    )
