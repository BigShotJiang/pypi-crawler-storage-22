"""Mannequin mapping service for GitHub Enterprise Importer.

Generates CSV files for mapping GEI mannequins to real GitHub users.
"""

from __future__ import annotations

import csv
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from pathlib import Path

logger = structlog.get_logger(__name__)


class MannequinService:
    """Service for managing GEI mannequin mappings."""

    def export_mannequin_csv(
        self,
        users: list[dict[str, Any]],
        output_path: Path,
    ) -> None:
        """Export mannequin mapping CSV for GEI reclaim process.

        The CSV format matches the GEI mannequin specification:
        - mannequin-user: Original username from source system
        - mannequin-id: Source system user ID
        - target-user: GitHub username to map to (to be filled)

        Args:
            users: List of user dicts with source_username, source_id, display_name.
            output_path: Path to write CSV file.
        """
        logger.info(
            "exporting_mannequin_csv",
            user_count=len(users),
            output_path=str(output_path),
        )

        with output_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)

            # GEI expected headers
            writer.writerow(
                [
                    "mannequin-user",
                    "mannequin-id",
                    "target-user",
                ]
            )

            for user in users:
                writer.writerow(
                    [
                        user.get("source_username", ""),
                        user.get("source_id", ""),
                        "",  # target-user to be filled by admin
                    ]
                )

        logger.info(
            "mannequin_csv_exported",
            output_path=str(output_path),
        )

    def load_mannequin_csv(self, csv_path: Path) -> list[dict[str, str]]:
        """Load mannequin mapping CSV.

        Args:
            csv_path: Path to CSV file.

        Returns:
            List of mapping dicts with mannequin-user, mannequin-id, target-user.
        """
        mappings: list[dict[str, str]] = []

        with csv_path.open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row.get("target-user"):  # Only include rows with target mapping
                    mappings.append(dict(row))

        return mappings
