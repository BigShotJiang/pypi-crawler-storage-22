"""Planning service for bb2gh.

Provides repository filtering, renaming, and plan generation logic.
"""

from __future__ import annotations

import csv
import fnmatch
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog

from bb2gh.exceptions import ConfigurationError, ValidationError

if TYPE_CHECKING:
    from bb2gh.models.inventory import RepositoryInventoryItem

logger = structlog.get_logger(__name__)


def matches_pattern(name: str, pattern: str) -> bool:
    """Check if a name matches a glob pattern.

    Args:
        name: The name to check.
        pattern: The glob pattern to match against.

    Returns:
        True if the name matches the pattern.
    """
    return fnmatch.fnmatch(name, pattern)


def filter_repositories(
    repositories: list[RepositoryInventoryItem],
    *,
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
    project_filter: str | None = None,
) -> list[RepositoryInventoryItem]:
    """Filter repositories based on patterns and project.

    Filtering logic:
    1. If include_patterns specified, repository must match at least one
    2. If exclude_patterns specified, repository must not match any
    3. If project_filter specified, repository must have that project key

    Patterns are matched against the repository name using glob matching.

    Args:
        repositories: List of repository inventory items.
        include_patterns: Glob patterns to include (None means include all).
        exclude_patterns: Glob patterns to exclude (None means exclude none).
        project_filter: Project key filter (None means no project filter).

    Returns:
        Filtered list of repositories.
    """
    filtered = list(repositories)

    # Apply project filter first
    if project_filter is not None:
        filtered = [r for r in filtered if r.project == project_filter]
        logger.debug(
            "project_filter_applied",
            project=project_filter,
            remaining=len(filtered),
        )

    # Apply include patterns (must match at least one)
    if include_patterns:
        filtered = [
            r for r in filtered if any(matches_pattern(r.name, p) for p in include_patterns)
        ]
        logger.debug(
            "include_patterns_applied",
            patterns=include_patterns,
            remaining=len(filtered),
        )

    # Apply exclude patterns (must not match any)
    if exclude_patterns:
        filtered = [
            r for r in filtered if not any(matches_pattern(r.name, p) for p in exclude_patterns)
        ]
        logger.debug(
            "exclude_patterns_applied",
            patterns=exclude_patterns,
            remaining=len(filtered),
        )

    logger.info(
        "repositories_filtered",
        original_count=len(repositories),
        filtered_count=len(filtered),
        include_patterns=include_patterns,
        exclude_patterns=exclude_patterns,
        project_filter=project_filter,
    )

    return filtered


def parse_rename_arg(rename_arg: str) -> tuple[str, str]:
    """Parse a single rename argument in 'old:new' format.

    Args:
        rename_arg: Rename specification in 'old:new' format.

    Returns:
        Tuple of (old_name, new_name).

    Raises:
        ConfigurationError: If format is invalid.
    """
    if ":" not in rename_arg:
        raise ConfigurationError(
            f"Invalid rename format: '{rename_arg}'. Expected 'old_name:new_name'."
        )

    parts = rename_arg.split(":", 1)
    old_name = parts[0].strip()
    new_name = parts[1].strip()

    if not old_name or not new_name:
        raise ConfigurationError(
            f"Invalid rename format: '{rename_arg}'. Both old and new names must be non-empty."
        )

    return old_name, new_name


def load_rename_mappings_from_csv(csv_path: str) -> dict[str, str]:
    """Load rename mappings from a CSV file.

    CSV format: old_name,new_name (with optional header row)

    Args:
        csv_path: Path to the CSV file.

    Returns:
        Dictionary mapping old names to new names.

    Raises:
        ConfigurationError: If file doesn't exist or is invalid.
    """
    path = Path(csv_path)
    if not path.exists():
        raise ConfigurationError(f"Rename mappings file not found: {csv_path}")

    mappings: dict[str, str] = {}

    try:
        with path.open(newline="", encoding="utf-8") as f:
            # Try to detect if there's a header
            sample = f.read(1024)
            f.seek(0)

            # Check if first row looks like a header
            has_header = sample.lower().startswith(("old", "source", "from", "original"))
            reader = csv.reader(f)

            if has_header:
                next(reader)  # Skip header row

            for row_num, row in enumerate(reader, start=2 if has_header else 1):
                if not row or (len(row) == 1 and not row[0].strip()):
                    continue  # Skip empty rows

                if len(row) < 2:
                    raise ConfigurationError(
                        f"Invalid row {row_num} in {csv_path}: expected 2 columns, got {len(row)}"
                    )

                old_name = row[0].strip()
                new_name = row[1].strip()

                if not old_name or not new_name:
                    raise ConfigurationError(
                        f"Invalid row {row_num} in {csv_path}: names cannot be empty"
                    )

                if old_name in mappings:
                    raise ConfigurationError(
                        f"Duplicate old name '{old_name}' in {csv_path} at row {row_num}"
                    )

                mappings[old_name] = new_name

    except csv.Error as e:
        raise ConfigurationError(f"Error parsing CSV file {csv_path}: {e}") from e

    logger.info(
        "rename_mappings_loaded",
        file=csv_path,
        count=len(mappings),
    )

    return mappings


def build_rename_mappings(
    rename_args: list[str] | None = None,
    rename_file: str | None = None,
) -> dict[str, str]:
    """Build rename mappings from CLI arguments and/or CSV file.

    Args:
        rename_args: List of 'old:new' rename arguments.
        rename_file: Path to CSV file with rename mappings.

    Returns:
        Dictionary mapping old names to new names.

    Raises:
        ConfigurationError: If arguments are invalid or files don't exist.
    """
    mappings: dict[str, str] = {}

    # Load from CSV file first
    if rename_file:
        mappings.update(load_rename_mappings_from_csv(rename_file))

    # Add CLI arguments (override CSV if same old name)
    if rename_args:
        for arg in rename_args:
            old_name, new_name = parse_rename_arg(arg)
            if old_name in mappings:
                logger.debug(
                    "rename_override",
                    old_name=old_name,
                    previous_new_name=mappings[old_name],
                    new_name=new_name,
                )
            mappings[old_name] = new_name

    return mappings


def validate_rename_mappings(
    mappings: dict[str, str],
    repository_names: set[str],
) -> list[str]:
    """Validate rename mappings against repository names.

    Checks for:
    - Old names that don't exist in repositories
    - Duplicate new names (conflicts)
    - New names that conflict with existing unremapped repositories

    Args:
        mappings: Dictionary mapping old names to new names.
        repository_names: Set of actual repository names.

    Returns:
        List of warning messages (empty if all valid).

    Raises:
        ValidationError: If there are naming conflicts.
    """
    warnings: list[str] = []
    errors: list[str] = []

    # Check for old names that don't exist
    missing_repos = set(mappings.keys()) - repository_names
    for name in missing_repos:
        warnings.append(f"Repository '{name}' in rename mappings not found in inventory")

    # Build the final name set to detect conflicts
    final_names: dict[str, str] = {}  # new_name -> source (old_name or "existing")

    # Add all repositories that aren't being renamed
    for name in repository_names:
        if name not in mappings:
            final_names[name] = "existing"

    # Add renamed repositories
    for old_name, new_name in mappings.items():
        if old_name not in repository_names:
            continue  # Skip non-existent repos

        if new_name in final_names:
            existing_source = final_names[new_name]
            if existing_source == "existing":
                errors.append(
                    f"Rename conflict: '{old_name}' -> '{new_name}' conflicts with "
                    f"existing repository '{new_name}'"
                )
            else:
                errors.append(
                    f"Rename conflict: Both '{existing_source}' and '{old_name}' "
                    f"would be renamed to '{new_name}'"
                )
        else:
            final_names[new_name] = old_name

    if errors:
        raise ValidationError("Rename validation failed:\n  " + "\n  ".join(errors))

    return warnings


def parse_org_mapping_arg(mapping_arg: str) -> tuple[str, str]:
    """Parse a single org mapping argument in 'project:org' format.

    Args:
        mapping_arg: Org mapping specification in 'project:org' format.

    Returns:
        Tuple of (project_key, target_org).

    Raises:
        ConfigurationError: If format is invalid.
    """
    if ":" not in mapping_arg:
        raise ConfigurationError(
            f"Invalid org mapping format: '{mapping_arg}'. Expected 'PROJECT:target-org'."
        )

    parts = mapping_arg.split(":", 1)
    project_key = parts[0].strip()
    target_org = parts[1].strip()

    if not project_key or not target_org:
        raise ConfigurationError(
            f"Invalid org mapping format: '{mapping_arg}'. Both project and org must be non-empty."
        )

    return project_key, target_org


def build_org_mappings(
    org_mapping_args: list[str] | None = None,
) -> dict[str, str]:
    """Build org mappings from CLI arguments.

    Args:
        org_mapping_args: List of 'PROJECT:target-org' mapping arguments.

    Returns:
        Dictionary mapping project keys to target organizations.

    Raises:
        ConfigurationError: If arguments are invalid.
    """
    mappings: dict[str, str] = {}

    if org_mapping_args:
        for arg in org_mapping_args:
            project_key, target_org = parse_org_mapping_arg(arg)
            if project_key in mappings:
                logger.debug(
                    "org_mapping_override",
                    project=project_key,
                    previous_org=mappings[project_key],
                    new_org=target_org,
                )
            mappings[project_key] = target_org

    return mappings


def get_target_org_for_repo(
    project: str | None,
    default_org: str,
    org_mappings: dict[str, str] | None = None,
) -> str:
    """Get the target organization for a repository based on its project.

    Args:
        project: Repository's Bitbucket project key (may be None).
        default_org: Default target organization.
        org_mappings: Dictionary mapping project keys to target organizations.

    Returns:
        Target organization name.
    """
    if org_mappings and project and project in org_mappings:
        return org_mappings[project]
    return default_org


def validate_org_mappings(
    org_mappings: dict[str, str],
    project_keys: set[str | None],
) -> list[str]:
    """Validate org mappings against actual project keys.

    Args:
        org_mappings: Dictionary mapping project keys to target organizations.
        project_keys: Set of actual project keys from repositories.

    Returns:
        List of warning messages (empty if all valid).
    """
    warnings: list[str] = []

    # Remove None from project_keys for comparison
    actual_projects = {p for p in project_keys if p is not None}

    # Check for mapped projects that don't exist
    missing_projects = set(org_mappings.keys()) - actual_projects
    for project in missing_projects:
        warnings.append(f"Project '{project}' in org mappings not found in inventory")

    return warnings


# GitHub org/repo naming constraints
GITHUB_ORG_PATTERN = re.compile(r"^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$")
GITHUB_REPO_PATTERN = re.compile(r"^[a-zA-Z0-9._-]+$")
GITHUB_ORG_MAX_LENGTH = 39
GITHUB_REPO_MAX_LENGTH = 100

# Size thresholds for warnings
LARGE_REPO_THRESHOLD_BYTES = 1024 * 1024 * 1024  # 1GB
VERY_LARGE_REPO_THRESHOLD_BYTES = 5 * 1024 * 1024 * 1024  # 5GB


def validate_github_org_name(org_name: str) -> list[str]:
    """Validate a GitHub organization name.

    GitHub org names:
    - Must be 1-39 characters
    - Can contain alphanumeric characters and hyphens
    - Cannot start or end with a hyphen
    - Cannot have consecutive hyphens

    Args:
        org_name: Organization name to validate.

    Returns:
        List of error messages (empty if valid).
    """
    errors: list[str] = []

    if not org_name:
        errors.append("Organization name cannot be empty")
        return errors

    if len(org_name) > GITHUB_ORG_MAX_LENGTH:
        errors.append(f"Organization name '{org_name}' exceeds {GITHUB_ORG_MAX_LENGTH} characters")

    if not GITHUB_ORG_PATTERN.match(org_name):
        errors.append(
            f"Organization name '{org_name}' contains invalid characters. "
            "Use only alphanumeric characters and hyphens, "
            "cannot start/end with hyphen."
        )

    if "--" in org_name:
        errors.append(f"Organization name '{org_name}' cannot contain consecutive hyphens")

    return errors


def validate_github_repo_name(repo_name: str) -> list[str]:
    """Validate a GitHub repository name.

    GitHub repo names:
    - Must be 1-100 characters
    - Can contain alphanumeric characters, hyphens, underscores, periods
    - Cannot be just "." or ".."

    Args:
        repo_name: Repository name to validate.

    Returns:
        List of error messages (empty if valid).
    """
    errors: list[str] = []

    if not repo_name:
        errors.append("Repository name cannot be empty")
        return errors

    if len(repo_name) > GITHUB_REPO_MAX_LENGTH:
        errors.append(f"Repository name '{repo_name}' exceeds {GITHUB_REPO_MAX_LENGTH} characters")

    if repo_name in (".", ".."):
        errors.append(f"Repository name cannot be '{repo_name}'")

    if not GITHUB_REPO_PATTERN.match(repo_name):
        errors.append(
            f"Repository name '{repo_name}' contains invalid characters. "
            "Use only alphanumeric characters, hyphens, underscores, and periods."
        )

    return errors


def validate_plan(
    plan_items: list[Any],  # list[RepositoryPlanItem] - avoiding circular import
    *,
    inventory_items: list[Any] | None = None,  # list[RepositoryInventoryItem]
) -> tuple[list[str], list[str]]:
    """Validate a migration plan for issues.

    Checks:
    - Duplicate target repository names (within same org)
    - Invalid GitHub organization names
    - Invalid GitHub repository names
    - Large repository warnings
    - LFS usage warnings

    Args:
        plan_items: List of repository plan items.
        inventory_items: Optional list of inventory items for additional checks.

    Returns:
        Tuple of (errors, warnings).
        Errors are blocking issues that must be fixed.
        Warnings are non-blocking but should be reviewed.
    """
    errors: list[str] = []
    warnings: list[str] = []

    # Build mapping of inventory items by source_id for quick lookup
    inventory_by_id: dict[str, Any] = {}
    if inventory_items:
        inventory_by_id = {item.id: item for item in inventory_items}

    # Check for duplicate target full names
    target_full_names: dict[str, str] = {}  # target_full_name -> source_name
    for item in plan_items:
        if item.target_full_name in target_full_names:
            errors.append(
                f"Naming conflict: Both '{target_full_names[item.target_full_name]}' "
                f"and '{item.source_name}' would create '{item.target_full_name}'"
            )
        else:
            target_full_names[item.target_full_name] = item.source_name

    # Collect unique orgs for validation
    unique_orgs: set[str] = {item.target_org for item in plan_items}

    # Validate organization names
    for org in unique_orgs:
        org_errors = validate_github_org_name(org)
        errors.extend(org_errors)

    # Validate repository names and check for issues
    large_repos: list[str] = []
    very_large_repos: list[str] = []
    lfs_repos: list[str] = []
    conflicting_repos: list[str] = []

    for item in plan_items:
        # Validate repo name
        repo_errors = validate_github_repo_name(item.target_name)
        for err in repo_errors:
            errors.append(f"Repository '{item.source_name}': {err}")

        # Check for target existence conflicts (when action is None = fail)
        if (
            hasattr(item, "target_exists")
            and item.target_exists
            and (not hasattr(item, "target_exists_action") or item.target_exists_action is None)
        ):
            conflicting_repos.append(item.target_full_name)

        # Check for size issues
        if item.size_bytes:
            if item.size_bytes >= VERY_LARGE_REPO_THRESHOLD_BYTES:
                very_large_repos.append(item.source_name)
            elif item.size_bytes >= LARGE_REPO_THRESHOLD_BYTES:
                large_repos.append(item.source_name)

        # Check inventory for LFS
        if item.source_id in inventory_by_id:
            inv_item = inventory_by_id[item.source_id]
            if hasattr(inv_item, "lfs") and inv_item.lfs and inv_item.lfs.has_lfs:
                lfs_repos.append(item.source_name)

    # Add errors for conflicting repos
    if conflicting_repos:
        errors.append(
            f"{len(conflicting_repos)} target repo(s) already exist in GitHub: "
            f"{', '.join(conflicting_repos[:5])}"
            + (f" and {len(conflicting_repos) - 5} more" if len(conflicting_repos) > 5 else "")
            + ". Use --on-conflict=skip to skip, --on-conflict=update to push, "
            "or --rename 'repo:new-name' to use a different target name."
        )

    # Generate warnings for size issues
    if very_large_repos:
        warnings.append(
            f"{len(very_large_repos)} repositories exceed 5GB and may fail migration: "
            f"{', '.join(very_large_repos[:3])}"
            + (f" and {len(very_large_repos) - 3} more" if len(very_large_repos) > 3 else "")
        )

    if large_repos:
        warnings.append(
            f"{len(large_repos)} repositories exceed 1GB and may require chunked transfer: "
            f"{', '.join(large_repos[:3])}"
            + (f" and {len(large_repos) - 3} more" if len(large_repos) > 3 else "")
        )

    if lfs_repos:
        warnings.append(
            f"{len(lfs_repos)} repositories use Git LFS and require LFS migration: "
            f"{', '.join(lfs_repos[:3])}"
            + (f" and {len(lfs_repos) - 3} more" if len(lfs_repos) > 3 else "")
        )

    logger.info(
        "plan_validated",
        error_count=len(errors),
        warning_count=len(warnings),
        repository_count=len(plan_items),
    )

    return errors, warnings


async def check_target_repos_exist(
    plan_items: list[Any],  # list[RepositoryPlanItem]
    github_token: str | None = None,
    *,
    ssl_verify: str | bool = True,
) -> dict[str, bool]:
    """Check which target repositories already exist in GitHub.

    Args:
        plan_items: List of repository plan items to check.
        github_token: GitHub token for API access.
        ssl_verify: SSL verification setting for httpx clients.

    Returns:
        Dictionary mapping target_full_name to exists (True/False).
    """
    import httpx

    results: dict[str, bool] = {}

    if not github_token:
        logger.warning("no_github_token", message="Cannot check target repos without GitHub token")
        return results

    headers = {
        "Authorization": f"token {github_token}",
        "Accept": "application/vnd.github.v3+json",
    }

    async with httpx.AsyncClient(timeout=30.0, verify=ssl_verify) as client:
        for item in plan_items:
            target = item.target_full_name
            try:
                response = await client.get(
                    f"https://api.github.com/repos/{target}",
                    headers=headers,
                )
                exists = response.status_code == 200
                results[target] = exists
                if exists:
                    logger.info(
                        "target_repo_exists",
                        target=target,
                        source=item.source_full_name,
                    )
            except Exception as e:
                logger.warning(
                    "target_check_failed",
                    target=target,
                    error=str(e),
                )
                results[target] = False  # Assume doesn't exist on error

    return results
