"""SSL certificate verification helpers for bb2gh.

Resolves the ``verify`` parameter for httpx clients based on
configuration (ssl_ca_bundle) and environment variables.
"""

from __future__ import annotations

from pathlib import Path

from bb2gh.exceptions import ConfigError

# Well-known system CA bundle paths (checked in order).
# These include Zscaler/corporate proxy root CAs when IT installs them.
_SYSTEM_CA_PATHS = (
    Path("/etc/ssl/certs/ca-certificates.crt"),  # Debian / Ubuntu / WSL2
    Path("/etc/pki/tls/certs/ca-bundle.crt"),  # RHEL / CentOS / Fedora
    Path("/etc/ssl/ca-bundle.pem"),  # openSUSE
    Path("/etc/ssl/cert.pem"),  # macOS / Alpine
)


def detect_system_ca_bundle() -> str | None:
    """Return the first existing system CA bundle path, or ``None``.

    Checks well-known locations where Linux distributions and macOS store
    their consolidated CA certificate bundles.  These bundles typically
    include corporate proxy root CAs (Zscaler, Netskope) when IT has
    installed them system-wide.
    """
    for path in _SYSTEM_CA_PATHS:
        if path.is_file():
            return str(path)
    return None


def resolve_ssl_verify(ca_bundle: Path | None = None) -> str | bool:
    """Resolve the SSL verify parameter for httpx clients.

    Args:
        ca_bundle: Optional path to a custom CA certificate bundle (PEM).

    Returns:
        A string path to the bundle (if provided) or ``True`` for default
        verification. httpx also respects ``SSL_CERT_FILE`` when
        ``trust_env=True`` (the default), so that env var acts as a
        further fallback.

    Raises:
        ConfigError: If the specified CA bundle file does not exist.
    """
    if ca_bundle is not None:
        resolved = ca_bundle.expanduser().resolve()
        if not resolved.exists():
            raise ConfigError(
                f"SSL CA bundle file not found: {resolved}",
                field="ssl_ca_bundle",
            )
        return str(resolved)
    return True
