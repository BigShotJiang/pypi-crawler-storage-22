"""User mapping service for bb2gh.

Handles user export, matching, and mapping for PR attribution.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

from bb2gh.models.user_mapping import (
    GhostUserConfig,
    MatchConfidence,
    MatchResult,
    MatchType,
    SourceUser,
    TargetUser,
    UserMapping,
    UserMappingStore,
)

if TYPE_CHECKING:
    from bb2gh.adapters.base import SourceAdapter, TargetAdapter
    from bb2gh.identity.config import IdentityConfig, MigrationScenario
    from bb2gh.identity.resolver import ResolutionResult

logger = structlog.get_logger(__name__)


class UserMappingService:
    """Service for managing user mappings between Bitbucket and GitHub."""

    def __init__(
        self,
        *,
        source_adapter: SourceAdapter | None = None,
        target_adapter: TargetAdapter | None = None,
        similarity_threshold: float = 0.8,
    ) -> None:
        """Initialize UserMappingService.

        Args:
            source_adapter: Adapter for source platform (Bitbucket).
            target_adapter: Adapter for target platform (GitHub).
            similarity_threshold: Minimum similarity for name matching (0-1).
        """
        self._source_adapter = source_adapter
        self._target_adapter = target_adapter
        self._similarity_threshold = similarity_threshold

    async def export_bitbucket_users(
        self,
        workspace: str,
    ) -> list[SourceUser]:
        """Export users from a Bitbucket workspace.

        Args:
            workspace: Bitbucket workspace slug.

        Returns:
            List of SourceUser objects.
        """
        if not self._source_adapter:
            raise ValueError("Source adapter not configured")

        logger.info("exporting_bitbucket_users", workspace=workspace)

        users = []
        async for member in self._source_adapter.list_workspace_members(workspace):
            user = SourceUser(
                username=member.get("username", member.get("account_id", "")),
                email=member.get("email"),
                display_name=member.get("display_name"),
                account_id=member.get("account_id"),
                avatar_url=member.get("avatar_url"),
            )
            users.append(user)

        logger.info("exported_bitbucket_users", count=len(users))
        return users

    async def export_github_users(
        self,
        org: str,
    ) -> list[TargetUser]:
        """Export users from a GitHub organization.

        Args:
            org: GitHub organization name.

        Returns:
            List of TargetUser objects.
        """
        if not self._target_adapter:
            raise ValueError("Target adapter not configured")

        logger.info("exporting_github_users", org=org)

        users = []
        async for member in self._target_adapter.list_org_members(org):
            user = TargetUser(
                username=member.get("login", ""),
                email=member.get("email"),
                name=member.get("name"),
                id=member.get("id"),
                avatar_url=member.get("avatar_url"),
            )
            users.append(user)

        logger.info("exported_github_users", count=len(users))
        return users

    def auto_match_users(
        self,
        source_users: list[SourceUser],
        target_users: list[TargetUser],
    ) -> list[MatchResult]:
        """Auto-match source users to target users.

        Matching strategy:
        1. Exact email match → HIGH confidence
        2. Fuzzy name match (>threshold) → MEDIUM confidence
        3. Username match → MEDIUM confidence
        4. No match → LOW confidence (unmapped)

        Args:
            source_users: List of source (Bitbucket) users.
            target_users: List of target (GitHub) users.

        Returns:
            List of MatchResult objects.
        """
        logger.info(
            "auto_matching_users",
            source_count=len(source_users),
            target_count=len(target_users),
        )

        # Build lookup indexes
        target_by_email: dict[str, TargetUser] = {}
        target_by_username: dict[str, TargetUser] = {}
        for user in target_users:
            if user.email:
                target_by_email[user.email.lower()] = user
            target_by_username[user.username.lower()] = user

        results = []
        matched_emails = 0
        matched_names = 0
        unmatched = 0

        for source in source_users:
            result = MatchResult(source_user=source)

            # Strategy 1: Exact email match
            if source.email:
                target = target_by_email.get(source.email.lower())
                if target:
                    result.target_user = target
                    result.match_type = MatchType.EMAIL
                    result.confidence = MatchConfidence.HIGH
                    result.similarity_score = 1.0
                    results.append(result)
                    matched_emails += 1
                    continue

            # Strategy 2: Username match
            if source.username:
                target = target_by_username.get(source.username.lower())
                if target:
                    result.target_user = target
                    result.match_type = MatchType.USERNAME
                    result.confidence = MatchConfidence.MEDIUM
                    result.similarity_score = 1.0
                    results.append(result)
                    matched_names += 1
                    continue

            # Strategy 3: Fuzzy name match
            if source.display_name:
                best_match, best_score = self._find_best_name_match(
                    source.display_name, target_users
                )
                if best_match and best_score >= self._similarity_threshold:
                    result.target_user = best_match
                    result.match_type = MatchType.NAME
                    result.confidence = MatchConfidence.MEDIUM
                    result.similarity_score = best_score
                    results.append(result)
                    matched_names += 1
                    continue

            # No match found
            result.match_type = MatchType.UNMAPPED
            result.confidence = MatchConfidence.LOW
            results.append(result)
            unmatched += 1

        logger.info(
            "auto_match_complete",
            matched_email=matched_emails,
            matched_name=matched_names,
            unmatched=unmatched,
        )

        return results

    def _find_best_name_match(
        self,
        source_name: str,
        target_users: list[TargetUser],
    ) -> tuple[TargetUser | None, float]:
        """Find the best name match using fuzzy matching.

        Args:
            source_name: Source user's display name.
            target_users: List of target users to match against.

        Returns:
            Tuple of (best matching user, similarity score).
        """
        best_match = None
        best_score = 0.0

        source_lower = source_name.lower()

        for target in target_users:
            if not target.name:
                continue

            # Simple similarity: Jaccard similarity of words
            score = self._calculate_name_similarity(source_lower, target.name.lower())
            if score > best_score:
                best_score = score
                best_match = target

        return best_match, best_score

    def _calculate_name_similarity(self, name1: str, name2: str) -> float:
        """Calculate similarity between two names.

        Uses Jaccard similarity of word sets.

        Args:
            name1: First name (lowercase).
            name2: Second name (lowercase).

        Returns:
            Similarity score 0-1.
        """
        words1 = set(name1.split())
        words2 = set(name2.split())

        if not words1 or not words2:
            return 0.0

        intersection = len(words1 & words2)
        union = len(words1 | words2)

        return intersection / union if union > 0 else 0.0

    def results_to_mappings(
        self,
        results: list[MatchResult],
    ) -> list[UserMapping]:
        """Convert match results to user mappings.

        Args:
            results: List of MatchResult objects.

        Returns:
            List of UserMapping objects.
        """
        return [r.to_mapping() for r in results]

    def export_to_csv(
        self,
        mappings: list[UserMapping],
        output_path: Path | str,
    ) -> None:
        """Export mappings to CSV file.

        Args:
            mappings: List of UserMapping objects.
            output_path: Path to output CSV file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        fieldnames = [
            "bb_username",
            "bb_email",
            "gh_username",
            "gh_email",
            "match_type",
            "confidence",
            "match_stage",
            "match_rule",
            "notes",
        ]

        with output_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for mapping in mappings:
                writer.writerow(mapping.to_csv_row())

        logger.info("exported_mappings_to_csv", path=str(output_path), count=len(mappings))

    def import_from_csv(
        self,
        input_path: Path | str,
    ) -> list[UserMapping]:
        """Import mappings from CSV file.

        Args:
            input_path: Path to input CSV file.

        Returns:
            List of UserMapping objects.
        """
        input_path = Path(input_path)

        mappings = []
        with input_path.open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                mapping = UserMapping.from_csv_row(row)
                mappings.append(mapping)

        logger.info("imported_mappings_from_csv", path=str(input_path), count=len(mappings))
        return mappings

    def export_users_to_csv(
        self,
        users: list[SourceUser] | list[TargetUser],
        output_path: Path | str,
        *,
        source: str = "bitbucket",
    ) -> None:
        """Export users to CSV file.

        Args:
            users: List of users to export.
            output_path: Path to output CSV file.
            source: Source platform ('bitbucket' or 'github').
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if source == "bitbucket":
            fieldnames = [
                "username",
                "email",
                "display_name",
                "account_id",
                "external_id",
                "idp_email",
            ]
        else:
            fieldnames = [
                "username",
                "email",
                "name",
                "id",
                "external_id",
                "idp_email",
            ]

        with output_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for user in users:
                writer.writerow(user.to_csv_row())

        logger.info("exported_users_to_csv", path=str(output_path), count=len(users))

    def create_mapping_store(
        self,
        source_workspace: str,
        target_org: str,
        mappings: list[UserMapping],
        *,
        ghost_config: GhostUserConfig | None = None,
    ) -> UserMappingStore:
        """Create a UserMappingStore from mappings.

        Args:
            source_workspace: Bitbucket workspace.
            target_org: GitHub organization.
            mappings: List of user mappings.
            ghost_config: Optional ghost user configuration.

        Returns:
            UserMappingStore object.
        """
        return UserMappingStore(
            source_workspace=source_workspace,
            target_org=target_org,
            mappings=mappings,
            ghost_config=ghost_config or GhostUserConfig(),
        )

    def validate_mappings(
        self,
        mappings: list[UserMapping],
    ) -> list[str]:
        """Validate mappings for issues.

        Args:
            mappings: List of user mappings.

        Returns:
            List of validation error messages (empty if valid).
        """
        errors = []

        seen_sources = set()
        for mapping in mappings:
            # Check for duplicate source usernames
            if mapping.source_username in seen_sources:
                errors.append(f"Duplicate source username: {mapping.source_username}")
            seen_sources.add(mapping.source_username)

            # Check for incomplete mappings
            if mapping.match_type != MatchType.UNMAPPED and not mapping.target_username:
                errors.append(
                    f"Mapping for {mapping.source_username} marked as "
                    f"{mapping.match_type.value} but has no target username"
                )

        return errors

    async def resolve_with_identity(
        self,
        source_users: list[SourceUser],
        target_users: list[TargetUser],
        *,
        identity_config: IdentityConfig | None = None,
        scenario: MigrationScenario | None = None,
        git_emails_source: dict[str, set[str]] | None = None,
        git_emails_target: dict[str, set[str]] | None = None,
    ) -> ResolutionResult:
        """Resolve users using the 5-stage identity waterfall.

        Uses the IdentityResolver for high-fidelity matching when
        identity configuration is available.

        Either identity_config or scenario must be provided. If
        identity_config is given, the ScenarioDetector runs first.

        Args:
            source_users: Users from source system (Bitbucket).
            target_users: Users from target system (GitHub).
            identity_config: Identity configuration for auto-detection.
            scenario: Pre-computed migration scenario (skips detection).
            git_emails_source: Git email → source identifier mapping.
            git_emails_target: Git email → target username mapping.

        Returns:
            ResolutionResult with mappings for all source users.
        """
        from bb2gh.identity.detector import ScenarioDetector
        from bb2gh.identity.resolver import IdentityResolver

        if scenario is None:
            if identity_config is None:
                from bb2gh.identity.config import IdentityConfig as IC

                identity_config = IC()
            detector = ScenarioDetector()
            scenario = await detector.detect(identity_config)

        resolver = IdentityResolver(
            similarity_threshold=self._similarity_threshold,
        )
        return resolver.resolve(
            source_users,
            target_users,
            scenario,
            git_emails_source=git_emails_source,
            git_emails_target=git_emails_target,
        )
