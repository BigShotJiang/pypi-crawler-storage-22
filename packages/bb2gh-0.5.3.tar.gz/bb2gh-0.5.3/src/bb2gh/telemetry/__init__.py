"""Telemetry module for anonymous usage tracking.

Provides opt-out telemetry for product development insights.
"""

from bb2gh.telemetry.collector import TelemetryCollector, collect_event
from bb2gh.telemetry.privacy import is_telemetry_enabled, opt_out, show_telemetry_notice
from bb2gh.telemetry.sender import PostHogSender

__all__ = [
    "PostHogSender",
    "TelemetryCollector",
    "collect_event",
    "is_telemetry_enabled",
    "opt_out",
    "show_telemetry_notice",
]
