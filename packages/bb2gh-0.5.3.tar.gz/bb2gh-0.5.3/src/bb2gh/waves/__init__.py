"""Waves module for batch/wave migrations.

Provides phased migration execution with validation gates.

AUDIT [N8-279]: Service-layer entry points do NOT have
@requires_feature(Feature.BATCH_WAVES) decorators. Feature gating is only
at the CLI layer (require_license in waves.py, missing is_feature_enabled).
Follow-up: add dual-gate to CLI commands and decorators to service layer.
"""

from bb2gh.waves.config import WaveConfigParser, parse_wave_config
from bb2gh.waves.executor import WaveExecutor, execute_wave
from bb2gh.waves.status import WaveStatusTracker, get_wave_status

__all__ = [
    "WaveConfigParser",
    "WaveExecutor",
    "WaveStatusTracker",
    "execute_wave",
    "get_wave_status",
    "parse_wave_config",
]
