"""Wave configuration parsing.

Parses YAML wave configuration files for phased migrations.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog
import yaml  # type: ignore[import-untyped]

from bb2gh.models.wave import (
    Wave,
    WaveConfig,
    WaveFilter,
    WaveFilterType,
)

if TYPE_CHECKING:
    from bb2gh.models.repository import Repository as RepositoryInfo

logger = structlog.get_logger(__name__)


class WaveConfigParser:
    """Parser for wave configuration files."""

    def parse(self, config_path: Path | str) -> WaveConfig:
        """Parse a wave configuration file.

        Args:
            config_path: Path to YAML config file.

        Returns:
            Parsed WaveConfig.

        Raises:
            FileNotFoundError: If config file doesn't exist.
            ValueError: If config format is invalid.
        """
        config_path = Path(config_path)

        if not config_path.exists():
            raise FileNotFoundError(f"Wave config not found: {config_path}")

        with config_path.open() as f:
            data = yaml.safe_load(f)

        return self.parse_dict(data)

    def parse_dict(self, data: dict[str, Any]) -> WaveConfig:
        """Parse wave configuration from a dictionary.

        Args:
            data: Configuration dictionary.

        Returns:
            Parsed WaveConfig.
        """
        waves = []

        for i, wave_data in enumerate(data.get("waves", [])):
            wave = self._parse_wave(wave_data, order=i)
            waves.append(wave)

        config = WaveConfig(
            version=data.get("version", "1.0"),
            waves=waves,
            auto_advance=data.get("auto_advance", False),
            validation_between_waves=data.get("validation_between_waves", True),
            pause_on_failure=data.get("pause_on_failure", True),
            generated_at=datetime.now(),
        )

        logger.info(
            "wave_config_parsed",
            num_waves=len(waves),
            version=config.version,
        )

        return config

    def _parse_wave(self, data: dict[str, Any], order: int = 0) -> Wave:
        """Parse a single wave from config data.

        Args:
            data: Wave configuration data.
            order: Wave execution order.

        Returns:
            Parsed Wave.
        """
        filters = []
        for filter_data in data.get("filters", []):
            filter_obj = self._parse_filter(filter_data)
            if filter_obj:
                filters.append(filter_obj)

        return Wave(
            name=data["name"],
            description=data.get("description"),
            repositories=data.get("repositories", []),
            filters=filters,
            order=data.get("order", order),
            parallel=data.get("parallel", True),
            max_workers=data.get("max_workers", 4),
            continue_on_error=data.get("continue_on_error", True),
            metadata=data.get("metadata", {}),
        )

    def _parse_filter(self, data: dict[str, Any]) -> WaveFilter | None:
        """Parse a wave filter from config data.

        Args:
            data: Filter configuration data.

        Returns:
            Parsed WaveFilter or None.
        """
        filter_type_str = data.get("type", "").lower()

        try:
            filter_type = WaveFilterType(filter_type_str)
        except ValueError:
            logger.warning("unknown_filter_type", filter_type=filter_type_str)
            return None

        return WaveFilter(
            filter_type=filter_type,
            value=data.get("value"),
            complexity_level=data.get("complexity_level"),
            include_inactive=data.get("include_inactive", False),
            min_size_bytes=data.get("min_size_bytes"),
            max_size_bytes=data.get("max_size_bytes"),
            name_pattern=data.get("name_pattern"),
        )

    def generate_config(
        self,
        repositories: list[RepositoryInfo],
        strategy: str = "complexity",
        num_waves: int = 3,
    ) -> WaveConfig:
        """Auto-generate wave configuration from repositories.

        Args:
            repositories: List of repositories.
            strategy: Generation strategy (complexity, size, alphabetical).
            num_waves: Number of waves to generate.

        Returns:
            Generated WaveConfig.
        """
        if strategy == "complexity":
            return self._generate_by_complexity(repositories, num_waves)
        elif strategy == "size":
            return self._generate_by_size(repositories, num_waves)
        else:
            return self._generate_alphabetical(repositories, num_waves)

    def _generate_by_complexity(
        self,
        repositories: list[RepositoryInfo],
        num_waves: int,
    ) -> WaveConfig:
        """Generate waves by repository complexity."""
        waves = [
            Wave(
                name="pilot",
                description="Pilot wave with simple, low-risk repositories",
                order=0,
                filters=[
                    WaveFilter(
                        filter_type=WaveFilterType.COMPLEXITY,
                        complexity_level="low",
                    )
                ],
            ),
            Wave(
                name="main",
                description="Main wave with standard repositories",
                order=1,
                filters=[
                    WaveFilter(
                        filter_type=WaveFilterType.COMPLEXITY,
                        complexity_level="medium",
                    )
                ],
            ),
            Wave(
                name="complex",
                description="Complex repositories requiring extra attention",
                order=2,
                filters=[
                    WaveFilter(
                        filter_type=WaveFilterType.COMPLEXITY,
                        complexity_level="high",
                    )
                ],
            ),
        ]

        # Distribute repos to waves based on complexity
        for repo in repositories:
            complexity = getattr(repo, "complexity", "medium")
            if complexity == "low":
                waves[0].repositories.append(repo.name)
            elif complexity == "high":
                waves[2].repositories.append(repo.name)
            else:
                waves[1].repositories.append(repo.name)

        return WaveConfig(
            waves=waves[:num_waves],
            generated_at=datetime.now(),
            generated_by="auto-generate:complexity",
        )

    def _generate_by_size(
        self,
        repositories: list[RepositoryInfo],
        num_waves: int,
    ) -> WaveConfig:
        """Generate waves by repository size."""
        # Sort by size
        sorted_repos = sorted(
            repositories,
            key=lambda r: getattr(r, "size_bytes", 0),
        )

        # Split into waves
        chunk_size = len(sorted_repos) // num_waves or 1
        waves = []

        for i in range(num_waves):
            start = i * chunk_size
            end = start + chunk_size if i < num_waves - 1 else len(sorted_repos)
            chunk = sorted_repos[start:end]

            wave = Wave(
                name=f"wave-{i + 1}",
                description=f"Wave {i + 1} - by size",
                order=i,
                repositories=[r.name for r in chunk],
            )
            waves.append(wave)

        return WaveConfig(
            waves=waves,
            generated_at=datetime.now(),
            generated_by="auto-generate:size",
        )

    def _generate_alphabetical(
        self,
        repositories: list[RepositoryInfo],
        num_waves: int,
    ) -> WaveConfig:
        """Generate waves alphabetically."""
        sorted_repos = sorted(repositories, key=lambda r: r.name)
        chunk_size = len(sorted_repos) // num_waves or 1
        waves = []

        for i in range(num_waves):
            start = i * chunk_size
            end = start + chunk_size if i < num_waves - 1 else len(sorted_repos)
            chunk = sorted_repos[start:end]

            wave = Wave(
                name=f"wave-{i + 1}",
                description=f"Wave {i + 1} - alphabetical",
                order=i,
                repositories=[r.name for r in chunk],
            )
            waves.append(wave)

        return WaveConfig(
            waves=waves,
            generated_at=datetime.now(),
            generated_by="auto-generate:alphabetical",
        )

    def save_config(self, config: WaveConfig, output_path: Path | str) -> None:
        """Save wave configuration to file.

        Args:
            config: Configuration to save.
            output_path: Output file path.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        data: dict[str, Any] = {
            "version": config.version,
            "auto_advance": config.auto_advance,
            "validation_between_waves": config.validation_between_waves,
            "pause_on_failure": config.pause_on_failure,
            "waves": [],
        }

        for wave in config.waves:
            wave_data: dict[str, Any] = {
                "name": wave.name,
                "description": wave.description,
                "order": wave.order,
                "repositories": wave.repositories,
                "parallel": wave.parallel,
                "max_workers": wave.max_workers,
                "continue_on_error": wave.continue_on_error,
            }
            if wave.filters:
                wave_data["filters"] = [
                    {
                        "type": f.filter_type.value,
                        "value": f.value,
                        "complexity_level": f.complexity_level,
                    }
                    for f in wave.filters
                ]
            data["waves"].append(wave_data)

        with output_path.open("w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

        logger.info("wave_config_saved", path=str(output_path))


def parse_wave_config(config_path: Path | str) -> WaveConfig:
    """Parse a wave configuration file.

    Args:
        config_path: Path to YAML config file.

    Returns:
        Parsed WaveConfig.
    """
    parser = WaveConfigParser()
    return parser.parse(config_path)
