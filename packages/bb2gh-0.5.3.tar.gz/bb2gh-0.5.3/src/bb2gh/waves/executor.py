"""Wave execution for phased migrations.

Executes waves of repositories with validation gates.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

import structlog

from bb2gh.models.wave import Wave, WaveConfig, WaveStatus

logger = structlog.get_logger(__name__)


class WaveExecutor:
    """Executes waves of repository migrations.

    Supports phased rollouts with validation gates between waves.
    """

    def __init__(
        self,
        config: WaveConfig,
        migration_callback: Callable[[str], Awaitable[Any]] | None = None,
        validation_callback: Callable[[str], Awaitable[bool]] | None = None,
    ):
        """Initialize wave executor.

        Args:
            config: Wave configuration.
            migration_callback: Callback for migrating a repository.
            validation_callback: Callback for validating a migration.
        """
        self.config = config
        self._migration_callback = migration_callback
        self._validation_callback = validation_callback
        self._stop_requested = False

    async def execute_wave(
        self,
        wave_name: str,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Execute a specific wave.

        Args:
            wave_name: Name of wave to execute.
            dry_run: If True, show what would be migrated.

        Returns:
            Execution result dictionary.

        Raises:
            ValueError: If wave not found.
        """
        wave = self.config.get_wave(wave_name)
        if not wave:
            raise ValueError(f"Wave not found: {wave_name}")

        if dry_run:
            return self._dry_run_wave(wave)

        return await self._execute_wave(wave)

    async def execute_waves(
        self,
        wave_names: list[str],
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Execute multiple waves.

        Args:
            wave_names: Names of waves to execute.
            dry_run: If True, show what would be migrated.

        Returns:
            Combined execution results.
        """
        results: dict[str, Any] = {
            "waves_executed": [],
            "total_repos": 0,
            "repos_completed": 0,
            "repos_failed": 0,
            "dry_run": dry_run,
        }

        for wave_name in wave_names:
            if self._stop_requested:
                logger.info("wave_execution_stopped")
                break

            result = await self.execute_wave(wave_name, dry_run=dry_run)
            results["waves_executed"].append(result)
            results["total_repos"] += result.get("total_repos", 0)
            results["repos_completed"] += result.get("repos_completed", 0)
            results["repos_failed"] += result.get("repos_failed", 0)

            # Run validation between waves if configured
            if self.config.validation_between_waves and not dry_run:
                validation_passed = await self._run_validation(wave_name)
                if not validation_passed and self.config.pause_on_failure:
                    logger.warning("validation_failed_pausing", wave=wave_name)
                    break

        return results

    async def execute_all(self, dry_run: bool = False) -> dict[str, Any]:
        """Execute all pending waves in order.

        Args:
            dry_run: If True, show what would be migrated.

        Returns:
            Combined execution results.
        """
        pending_waves = sorted(
            self.config.pending_waves,
            key=lambda w: w.order,
        )
        wave_names = [w.name for w in pending_waves]
        return await self.execute_waves(wave_names, dry_run=dry_run)

    def stop(self) -> None:
        """Request stop of wave execution."""
        self._stop_requested = True
        logger.info("wave_execution_stop_requested")

    def _dry_run_wave(self, wave: Wave) -> dict[str, Any]:
        """Perform dry run for a wave.

        Args:
            wave: Wave to dry run.

        Returns:
            Dry run results.
        """
        logger.info(
            "wave_dry_run",
            wave=wave.name,
            repos=wave.repositories,
        )

        return {
            "wave": wave.name,
            "dry_run": True,
            "total_repos": len(wave.repositories),
            "repos_to_migrate": wave.repositories,
            "parallel": wave.parallel,
            "max_workers": wave.max_workers,
        }

    async def _execute_wave(self, wave: Wave) -> dict[str, Any]:
        """Execute a single wave.

        Args:
            wave: Wave to execute.

        Returns:
            Execution results.
        """
        logger.info(
            "wave_execution_started",
            wave=wave.name,
            num_repos=len(wave.repositories),
        )

        wave.status = WaveStatus.IN_PROGRESS
        wave.started_at = datetime.now()

        results: dict[str, Any] = {
            "wave": wave.name,
            "total_repos": len(wave.repositories),
            "repos_completed": 0,
            "repos_failed": 0,
            "repo_results": [],
        }

        for repo in wave.repositories:
            if self._stop_requested:
                break

            try:
                if self._migration_callback:
                    await self._migration_callback(repo)

                wave.repos_completed += 1
                results["repos_completed"] += 1
                results["repo_results"].append(
                    {
                        "repo": repo,
                        "success": True,
                    }
                )

            except Exception as e:
                logger.error(
                    "repo_migration_failed",
                    wave=wave.name,
                    repo=repo,
                    error=str(e),
                )
                wave.repos_failed += 1
                results["repos_failed"] += 1
                results["repo_results"].append(
                    {
                        "repo": repo,
                        "success": False,
                        "error": str(e),
                    }
                )

                if not wave.continue_on_error:
                    break

        # Update wave status
        if wave.repos_failed > 0 and not wave.continue_on_error:
            wave.status = WaveStatus.FAILED
        elif wave.repos_completed == wave.total_repos:
            wave.status = WaveStatus.COMPLETED
        else:
            wave.status = WaveStatus.FAILED

        wave.completed_at = datetime.now()

        logger.info(
            "wave_execution_completed",
            wave=wave.name,
            status=wave.status.value,
            completed=wave.repos_completed,
            failed=wave.repos_failed,
        )

        return results

    async def _run_validation(self, wave_name: str) -> bool:
        """Run validation after a wave.

        Args:
            wave_name: Wave that was executed.

        Returns:
            True if validation passed.
        """
        wave = self.config.get_wave(wave_name)
        if not wave:
            return True

        if not self._validation_callback:
            return True

        all_passed = True
        for repo in wave.repositories:
            try:
                passed = await self._validation_callback(repo)
                if not passed:
                    all_passed = False
                    logger.warning(
                        "repo_validation_failed",
                        wave=wave_name,
                        repo=repo,
                    )
            except Exception as e:
                logger.error(
                    "repo_validation_error",
                    wave=wave_name,
                    repo=repo,
                    error=str(e),
                )
                all_passed = False

        return all_passed

    def get_skipped_repos(self, _wave_name: str) -> list[str]:
        """Get list of already-completed repositories in a wave.

        Args:
            _wave_name: Wave name (unused, reserved for state store integration).

        Returns:
            List of skipped repository names.
        """
        # This would check state store for completed repos
        # For now, return empty list
        return []


async def execute_wave(
    config: WaveConfig,
    wave_name: str,
    migration_callback: Callable[[str], Awaitable[Any]] | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Execute a single wave.

    Args:
        config: Wave configuration.
        wave_name: Wave to execute.
        migration_callback: Migration callback function.
        dry_run: If True, show what would be migrated.

    Returns:
        Execution results.
    """
    executor = WaveExecutor(config, migration_callback=migration_callback)
    return await executor.execute_wave(wave_name, dry_run=dry_run)
