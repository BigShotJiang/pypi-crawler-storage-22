"""Wave status tracking.

Tracks wave execution progress and generates status reports.
"""

from __future__ import annotations

from typing import Any

import structlog

from bb2gh.models.wave import WaveConfig, WaveStatus, WaveStatusReport

logger = structlog.get_logger(__name__)


class WaveStatusTracker:
    """Tracks and reports wave execution status.

    Persists wave status to state store for resume capability.
    """

    def __init__(self, config: WaveConfig, state_store: Any | None = None):
        """Initialize status tracker.

        Args:
            config: Wave configuration.
            state_store: Optional state store for persistence.
        """
        self.config = config
        self.state_store = state_store

    def get_status(self) -> WaveStatusReport:
        """Get current wave status report.

        Returns:
            Wave status report.
        """
        report = WaveStatusReport()
        report.config_version = self.config.version
        report.total_waves = len(self.config.waves)

        for wave in self.config.waves:
            if wave.status == WaveStatus.COMPLETED:
                report.waves_completed += 1
            elif wave.status == WaveStatus.IN_PROGRESS:
                report.waves_in_progress += 1
            elif wave.status == WaveStatus.FAILED:
                report.waves_failed += 1
            else:
                report.waves_pending += 1

            report.total_repos += wave.total_repos
            report.repos_completed += wave.repos_completed
            report.repos_failed += wave.repos_failed

            report.wave_details.append(
                {
                    "name": wave.name,
                    "status": wave.status.value,
                    "total_repos": wave.total_repos,
                    "repos_completed": wave.repos_completed,
                    "repos_failed": wave.repos_failed,
                    "progress_percent": wave.progress_percent,
                    "started_at": wave.started_at.isoformat() if wave.started_at else None,
                    "completed_at": wave.completed_at.isoformat() if wave.completed_at else None,
                }
            )

        report.repos_pending = report.total_repos - report.repos_completed - report.repos_failed

        return report

    def get_wave_status(self, wave_name: str) -> dict[str, Any] | None:
        """Get status for a specific wave.

        Args:
            wave_name: Wave name.

        Returns:
            Wave status dict or None if not found.
        """
        wave = self.config.get_wave(wave_name)
        if not wave:
            return None

        return {
            "name": wave.name,
            "description": wave.description,
            "status": wave.status.value,
            "total_repos": wave.total_repos,
            "repos_completed": wave.repos_completed,
            "repos_failed": wave.repos_failed,
            "progress_percent": wave.progress_percent,
            "started_at": wave.started_at.isoformat() if wave.started_at else None,
            "completed_at": wave.completed_at.isoformat() if wave.completed_at else None,
            "repositories": wave.repositories,
        }

    def list_waves(self) -> list[dict[str, Any]]:
        """List all defined waves.

        Returns:
            List of wave summary dicts.
        """
        return [
            {
                "name": wave.name,
                "order": wave.order,
                "status": wave.status.value,
                "total_repos": wave.total_repos,
                "progress_percent": wave.progress_percent,
            }
            for wave in sorted(self.config.waves, key=lambda w: w.order)
        ]

    async def save_status(self) -> None:
        """Save current status to state store."""
        if not self.state_store:
            return

        # Save wave status to state store
        # This would use the state store's wave tracking table
        logger.debug("wave_status_saved")

    async def load_status(self) -> None:
        """Load status from state store."""
        if not self.state_store:
            return

        # Load wave status from state store
        logger.debug("wave_status_loaded")

    def format_table(self) -> str:
        """Format wave status as ASCII table.

        Returns:
            Formatted table string.
        """
        lines = []
        lines.append("Wave Status")
        lines.append("=" * 70)
        lines.append(
            f"{'Wave':<15} {'Status':<12} {'Progress':<10} {'Completed':<10} {'Failed':<8}"
        )
        lines.append("-" * 70)

        for wave in sorted(self.config.waves, key=lambda w: w.order):
            progress = f"{wave.progress_percent:.1f}%"
            lines.append(
                f"{wave.name:<15} {wave.status.value:<12} {progress:<10} "
                f"{wave.repos_completed:<10} {wave.repos_failed:<8}"
            )

        lines.append("-" * 70)

        report = self.get_status()
        lines.append(
            f"{'TOTAL':<15} {'':<12} {report.overall_progress:.1f}%    "
            f"{report.repos_completed:<10} {report.repos_failed:<8}"
        )

        return "\n".join(lines)


def get_wave_status(config: WaveConfig) -> WaveStatusReport:
    """Get wave status report.

    Args:
        config: Wave configuration.

    Returns:
        Status report.
    """
    tracker = WaveStatusTracker(config)
    return tracker.get_status()
