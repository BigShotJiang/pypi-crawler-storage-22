"""Workers module for parallel migration execution.

Provides local multi-process parallel workers and work distribution.

AUDIT [N8-279]: Service-layer entry points do NOT have
@requires_feature(Feature.DISTRIBUTED_WORKERS) decorators. Feature gating
is currently enforced at the CLI layer (check_worker_limit in migrate.py).
Follow-up: add decorators to service entry points for defense-in-depth.
"""

from bb2gh.workers.distributor import WorkQueue, distribute_work
from bb2gh.workers.local import LocalWorkerPool
from bb2gh.workers.pool import WorkerPool
from bb2gh.workers.rate_limiter import SharedRateLimiter, TokenBucket

__all__ = [
    "LocalWorkerPool",
    "SharedRateLimiter",
    "TokenBucket",
    "WorkQueue",
    "WorkerPool",
    "distribute_work",
]
