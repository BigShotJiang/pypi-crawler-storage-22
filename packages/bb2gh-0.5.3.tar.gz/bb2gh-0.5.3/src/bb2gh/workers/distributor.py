"""Work distribution for parallel workers.

Provides work queue and distribution strategies.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING

import structlog

from bb2gh.models.worker import TaskPriority, TaskStatus, WorkerTask

if TYPE_CHECKING:
    from typing import Any

    from bb2gh.models.repository import Repository as RepositoryInfo

logger = structlog.get_logger(__name__)


class DistributionStrategy(StrEnum):
    """Work distribution strategies."""

    FIFO = "fifo"  # First in, first out
    LARGEST_FIRST = "largest_first"  # Largest repos first (longest job first)
    SMALLEST_FIRST = "smallest_first"  # Smallest repos first
    PRIORITY = "priority"  # By priority, then FIFO


@dataclass
class WorkQueue:
    """Thread-safe work queue for distributing tasks to workers.

    Supports multiple distribution strategies and priority-based ordering.
    """

    strategy: DistributionStrategy = DistributionStrategy.FIFO
    enable_work_stealing: bool = False
    _tasks: list[WorkerTask] = field(default_factory=list)
    _completed: list[WorkerTask] = field(default_factory=list)
    _failed: list[WorkerTask] = field(default_factory=list)
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def enqueue(self, task: WorkerTask) -> None:
        """Add a task to the queue.

        Args:
            task: Task to add.
        """
        async with self._lock:
            self._tasks.append(task)
            self._sort_tasks()
            logger.debug("task_enqueued", task_id=task.id, repository=task.repository)

    async def enqueue_many(self, tasks: list[WorkerTask]) -> None:
        """Add multiple tasks to the queue.

        Args:
            tasks: Tasks to add.
        """
        async with self._lock:
            self._tasks.extend(tasks)
            self._sort_tasks()
            logger.info("tasks_enqueued", count=len(tasks))

    async def dequeue(self, worker_id: str) -> WorkerTask | None:
        """Get the next task for a worker.

        Args:
            worker_id: ID of the worker requesting work.

        Returns:
            Next task to execute, or None if queue is empty.
        """
        async with self._lock:
            # Find first pending task
            for task in self._tasks:
                if task.status == TaskStatus.PENDING:
                    task.mark_started(worker_id)
                    logger.debug(
                        "task_dequeued",
                        task_id=task.id,
                        worker_id=worker_id,
                        repository=task.repository,
                    )
                    return task

                # Also check for retry tasks
                if task.status == TaskStatus.RETRY and task.can_retry():
                    task.mark_started(worker_id)
                    logger.debug(
                        "task_retrying",
                        task_id=task.id,
                        worker_id=worker_id,
                        attempt=task.attempt,
                    )
                    return task

            return None

    async def complete_task(
        self,
        task_id: str,
        success: bool,
        result: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        """Mark a task as completed.

        Args:
            task_id: Task ID.
            success: Whether task succeeded.
            result: Task result (if success).
            error: Error message (if failure).
        """
        async with self._lock:
            for task in self._tasks:
                if task.id == task_id:
                    if success:
                        task.mark_completed(result)
                        self._completed.append(task)
                    else:
                        task.mark_failed(error or "Unknown error")
                        if not task.can_retry():
                            self._failed.append(task)

                    logger.debug(
                        "task_completed",
                        task_id=task_id,
                        success=success,
                        status=task.status.value,
                    )
                    return

    async def steal_work(self, _from_worker_id: str, to_worker_id: str) -> WorkerTask | None:
        """Steal work from another worker (for work stealing strategy).

        Args:
            _from_worker_id: Worker to steal from (unused in current implementation).
            to_worker_id: Worker receiving the work.

        Returns:
            Stolen task, or None if no work available.
        """
        if not self.enable_work_stealing:
            return None

        # Work stealing implementation - find pending tasks assigned to from_worker
        # This is a placeholder for more sophisticated work stealing
        return await self.dequeue(to_worker_id)

    def _sort_tasks(self) -> None:
        """Sort tasks based on distribution strategy."""
        if self.strategy == DistributionStrategy.FIFO:
            # Already in order
            pass
        elif self.strategy == DistributionStrategy.LARGEST_FIRST:
            self._tasks.sort(
                key=lambda t: t.metadata.get("size", 0),
                reverse=True,
            )
        elif self.strategy == DistributionStrategy.SMALLEST_FIRST:
            self._tasks.sort(
                key=lambda t: t.metadata.get("size", 0),
            )
        elif self.strategy == DistributionStrategy.PRIORITY:
            priority_order = {
                TaskPriority.URGENT: 0,
                TaskPriority.HIGH: 1,
                TaskPriority.NORMAL: 2,
                TaskPriority.LOW: 3,
            }
            self._tasks.sort(key=lambda t: priority_order.get(t.priority, 2))

    @property
    def pending_count(self) -> int:
        """Get count of pending tasks."""
        return sum(1 for t in self._tasks if t.status in (TaskStatus.PENDING, TaskStatus.RETRY))

    @property
    def in_progress_count(self) -> int:
        """Get count of in-progress tasks."""
        return sum(1 for t in self._tasks if t.status == TaskStatus.IN_PROGRESS)

    @property
    def completed_count(self) -> int:
        """Get count of completed tasks."""
        return len(self._completed)

    @property
    def failed_count(self) -> int:
        """Get count of failed tasks."""
        return len(self._failed)

    @property
    def total_count(self) -> int:
        """Get total task count."""
        return len(self._tasks)

    def is_empty(self) -> bool:
        """Check if queue has no pending work."""
        return self.pending_count == 0 and self.in_progress_count == 0

    def get_stats(self) -> dict[str, int]:
        """Get queue statistics."""
        return {
            "total": self.total_count,
            "pending": self.pending_count,
            "in_progress": self.in_progress_count,
            "completed": self.completed_count,
            "failed": self.failed_count,
        }


def distribute_work(
    repositories: list[RepositoryInfo],
    strategy: DistributionStrategy = DistributionStrategy.LARGEST_FIRST,
    filter_repos: list[str] | None = None,
    max_attempts: int = 3,
) -> list[WorkerTask]:
    """Create tasks for a list of repositories.

    Args:
        repositories: List of repositories to migrate.
        strategy: Distribution strategy.
        filter_repos: Optional list of repo names to include.
        max_attempts: Max retry attempts per task.

    Returns:
        List of WorkerTask objects.
    """
    tasks = []

    for i, repo in enumerate(repositories):
        # Apply filter if specified
        if filter_repos and repo.name not in filter_repos:
            continue

        task = WorkerTask(
            id=f"task-{i:04d}",
            repository=repo.name,
            task_type="migrate",
            max_attempts=max_attempts,
            metadata={
                "size": repo.size_bytes if hasattr(repo, "size_bytes") else 0,
                "source_url": repo.clone_url_https if hasattr(repo, "clone_url_https") else "",
            },
        )
        tasks.append(task)

    # Sort based on strategy
    if strategy == DistributionStrategy.LARGEST_FIRST:
        tasks.sort(key=lambda t: t.metadata.get("size", 0), reverse=True)
    elif strategy == DistributionStrategy.SMALLEST_FIRST:
        tasks.sort(key=lambda t: t.metadata.get("size", 0))

    logger.info(
        "work_distributed",
        total_tasks=len(tasks),
        strategy=strategy.value,
        filtered=len(filter_repos) if filter_repos else None,
    )

    return tasks
