"""Progress display for parallel workers.

Provides multi-worker progress visualization.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from bb2gh.models.worker import Worker, WorkerPoolStats
    from bb2gh.workers.rate_limiter import SharedRateLimiter

logger = structlog.get_logger(__name__)


@dataclass
class WorkerProgressState:
    """Progress state for a single worker."""

    worker_id: str
    worker_name: str
    current_repo: str | None = None
    progress_percent: float = 0.0
    tasks_completed: int = 0
    tasks_failed: int = 0
    is_active: bool = False


@dataclass
class MultiWorkerProgress:
    """Multi-worker progress display manager.

    Tracks and displays progress for multiple workers executing
    migration tasks in parallel.
    """

    workers: dict[str, WorkerProgressState] = field(default_factory=dict)
    total_tasks: int = 0
    completed_tasks: int = 0
    failed_tasks: int = 0
    started_at: datetime | None = None
    rate_limit_status: dict[str, float] = field(default_factory=dict)

    def update_worker(
        self,
        worker: Worker,
    ) -> None:
        """Update progress state for a worker.

        Args:
            worker: Worker to update.
        """
        if worker.id not in self.workers:
            self.workers[worker.id] = WorkerProgressState(
                worker_id=worker.id,
                worker_name=worker.name,
            )

        state = self.workers[worker.id]
        state.is_active = worker.is_busy
        state.tasks_completed = worker.tasks_completed
        state.tasks_failed = worker.tasks_failed

        if worker.current_task:
            state.current_repo = worker.current_task.repository
        else:
            state.current_repo = None

    def update_from_stats(self, stats: WorkerPoolStats) -> None:
        """Update progress from pool stats.

        Args:
            stats: Worker pool statistics.
        """
        self.total_tasks = stats.total_tasks
        self.completed_tasks = stats.tasks_completed
        self.failed_tasks = stats.tasks_failed
        self.started_at = stats.started_at

        if stats.current_rate_limit is not None:
            self.rate_limit_status["github"] = stats.current_rate_limit

    def update_rate_limits(self, rate_limiter: SharedRateLimiter) -> None:
        """Update rate limit status.

        Args:
            rate_limiter: Rate limiter to get status from.
        """
        all_status = rate_limiter.get_all_status()
        for api, status in all_status.items():
            self.rate_limit_status[api] = status.get("percent_available", 100.0)

    @property
    def overall_progress(self) -> float:
        """Get overall progress percentage."""
        if self.total_tasks == 0:
            return 0.0
        return (self.completed_tasks / self.total_tasks) * 100

    @property
    def eta_seconds(self) -> float | None:
        """Estimate time remaining in seconds."""
        if not self.started_at or self.completed_tasks == 0:
            return None

        elapsed = (datetime.now() - self.started_at).total_seconds()
        rate = self.completed_tasks / elapsed  # tasks per second

        remaining = self.total_tasks - self.completed_tasks
        if rate > 0:
            return remaining / rate
        return None

    def format_eta(self) -> str:
        """Format ETA as human-readable string."""
        eta = self.eta_seconds
        if eta is None:
            return "calculating..."

        if eta < 60:
            return f"{int(eta)}s"
        elif eta < 3600:
            minutes = int(eta / 60)
            seconds = int(eta % 60)
            return f"{minutes}m {seconds}s"
        else:
            hours = int(eta / 3600)
            minutes = int((eta % 3600) / 60)
            return f"{hours}h {minutes}m"

    def render(self) -> str:
        """Render progress display as string.

        Returns:
            Multi-line progress display.
        """
        lines = []

        # Overall progress header
        lines.append(f"Migration Progress: {self.overall_progress:.1f}%")
        lines.append(
            f"Tasks: {self.completed_tasks}/{self.total_tasks} completed, {self.failed_tasks} failed"
        )
        lines.append(f"ETA: {self.format_eta()}")
        lines.append("")

        # Worker status
        lines.append("Workers:")
        for _worker_id, state in sorted(self.workers.items()):
            status = "●" if state.is_active else "○"
            repo = state.current_repo or "idle"
            line = f"  {status} {state.worker_name}: {repo} ({state.tasks_completed} done)"
            lines.append(line)

        # Rate limit status
        if self.rate_limit_status:
            lines.append("")
            lines.append("Rate Limits:")
            for api, percent in self.rate_limit_status.items():
                bar = self._render_bar(percent, width=20)
                lines.append(f"  {api}: {bar} {percent:.0f}%")

        return "\n".join(lines)

    def _render_bar(self, percent: float, width: int = 20) -> str:
        """Render a progress bar.

        Args:
            percent: Progress percentage (0-100).
            width: Bar width in characters.

        Returns:
            Progress bar string.
        """
        filled = int(width * percent / 100)
        empty = width - filled
        return f"[{'█' * filled}{'░' * empty}]"


class WorkerProgressBar:
    """Individual worker progress bar.

    Displays progress for a single worker.
    """

    def __init__(
        self,
        worker_id: str,
        worker_name: str,
        total_tasks: int = 0,
    ):
        """Initialize progress bar.

        Args:
            worker_id: Worker ID.
            worker_name: Display name.
            total_tasks: Total tasks assigned.
        """
        self.worker_id = worker_id
        self.worker_name = worker_name
        self.total_tasks = total_tasks
        self.completed_tasks = 0
        self.current_repo: str | None = None
        self.is_active = False

    def update(
        self,
        completed: int | None = None,
        current_repo: str | None = None,
        is_active: bool | None = None,
    ) -> None:
        """Update progress bar state.

        Args:
            completed: Number of completed tasks.
            current_repo: Currently processing repository.
            is_active: Whether worker is active.
        """
        if completed is not None:
            self.completed_tasks = completed
        if current_repo is not None:
            self.current_repo = current_repo
        if is_active is not None:
            self.is_active = is_active

    @property
    def progress_percent(self) -> float:
        """Get progress percentage."""
        if self.total_tasks == 0:
            return 0.0
        return (self.completed_tasks / self.total_tasks) * 100

    def render(self, width: int = 30) -> str:
        """Render progress bar as string.

        Args:
            width: Bar width.

        Returns:
            Progress bar string.
        """
        status = "●" if self.is_active else "○"
        bar = self._render_bar(self.progress_percent, width)
        repo = (
            self.current_repo[:20] + "..."
            if self.current_repo and len(self.current_repo) > 20
            else (self.current_repo or "idle")
        )

        return f"{status} {self.worker_name}: {bar} {self.progress_percent:.0f}% ({repo})"

    def _render_bar(self, percent: float, width: int) -> str:
        """Render progress bar portion."""
        filled = int(width * percent / 100)
        empty = width - filled
        return f"[{'█' * filled}{'░' * empty}]"
