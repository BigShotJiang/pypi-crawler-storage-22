"""Rate limiting for parallel workers.

Provides shared rate limiting across multiple worker processes.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from multiprocessing import Manager
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from multiprocessing.managers import SyncManager

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class RateLimitConfig:
    """Rate limit configuration."""

    max_tokens: float
    refill_rate: float  # tokens per second
    name: str = "default"


# Default rate limits for common APIs
DEFAULT_RATE_LIMITS = {
    "bitbucket": RateLimitConfig(
        name="bitbucket",
        max_tokens=1000,  # Bitbucket has generous limits
        refill_rate=100,  # tokens per second
    ),
    "github": RateLimitConfig(
        name="github",
        max_tokens=5000,  # GitHub's default for authenticated requests
        refill_rate=1.4,  # ~5000 per hour = ~1.4/second
    ),
}


class TokenBucket:
    """Token bucket rate limiter.

    Thread-safe token bucket implementation for rate limiting.
    """

    def __init__(
        self,
        max_tokens: float,
        refill_rate: float,
        name: str = "default",
    ):
        """Initialize token bucket.

        Args:
            max_tokens: Maximum tokens in bucket.
            refill_rate: Tokens added per second.
            name: Bucket name for logging.
        """
        self.max_tokens = max_tokens
        self.refill_rate = refill_rate
        self.name = name
        self._tokens = max_tokens
        self._last_refill = time.monotonic()
        self._lock = asyncio.Lock()

    def _refill(self) -> None:
        """Refill tokens based on elapsed time."""
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(
            self.max_tokens,
            self._tokens + elapsed * self.refill_rate,
        )
        self._last_refill = now

    async def acquire(self, tokens: float = 1.0) -> float:
        """Acquire tokens, waiting if necessary.

        Args:
            tokens: Number of tokens to acquire.

        Returns:
            Wait time in seconds (0 if no wait).
        """
        async with self._lock:
            self._refill()

            if self._tokens >= tokens:
                self._tokens -= tokens
                return 0.0

            # Calculate wait time
            needed = tokens - self._tokens
            wait_time = needed / self.refill_rate

            logger.debug(
                "rate_limit_waiting",
                bucket=self.name,
                tokens_needed=tokens,
                tokens_available=self._tokens,
                wait_seconds=wait_time,
            )

            # Release lock while waiting
            await asyncio.sleep(wait_time)

            # Refill and consume
            self._refill()
            self._tokens -= tokens
            return wait_time

    def try_acquire(self, tokens: float = 1.0) -> bool:
        """Try to acquire tokens without waiting.

        Args:
            tokens: Number of tokens to acquire.

        Returns:
            True if tokens were acquired, False otherwise.
        """
        self._refill()
        if self._tokens >= tokens:
            self._tokens -= tokens
            return True
        return False

    @property
    def available_tokens(self) -> float:
        """Get currently available tokens."""
        self._refill()
        return self._tokens

    @property
    def wait_time(self) -> float:
        """Get wait time until 1 token is available."""
        self._refill()
        if self._tokens >= 1:
            return 0.0
        return (1 - self._tokens) / self.refill_rate


class SharedRateLimiter:
    """Shared rate limiter for multi-process workers.

    Uses multiprocessing.Manager for shared state across processes.
    """

    def __init__(
        self,
        configs: dict[str, RateLimitConfig] | None = None,
        manager: SyncManager | None = None,
    ):
        """Initialize shared rate limiter.

        Args:
            configs: Rate limit configurations per API.
            manager: Multiprocessing manager for shared state.
        """
        self._manager = manager or Manager()
        self._configs = configs or DEFAULT_RATE_LIMITS

        # Create shared state for each API
        self._state: dict[str, Any] = {}
        self._locks: dict[str, Any] = {}

        for name, config in self._configs.items():
            self._state[name] = self._manager.dict(
                {
                    "tokens": config.max_tokens,
                    "last_refill": time.monotonic(),
                    "max_tokens": config.max_tokens,
                    "refill_rate": config.refill_rate,
                }
            )
            self._locks[name] = self._manager.Lock()

    def _refill(self, name: str) -> float:
        """Refill tokens for an API.

        Args:
            name: API name.

        Returns:
            Available tokens after refill.
        """
        state = self._state[name]
        now = time.monotonic()
        elapsed = now - state["last_refill"]
        new_tokens = min(
            state["max_tokens"],
            state["tokens"] + elapsed * state["refill_rate"],
        )
        state["tokens"] = new_tokens
        state["last_refill"] = now
        return float(new_tokens)

    async def acquire(self, api: str, tokens: float = 1.0) -> float:
        """Acquire tokens for an API, waiting if necessary.

        Args:
            api: API name (e.g., "github", "bitbucket").
            tokens: Number of tokens to acquire.

        Returns:
            Wait time in seconds.
        """
        if api not in self._state:
            logger.warning("unknown_api_rate_limit", api=api)
            return 0.0

        with self._locks[api]:
            self._refill(api)
            state = self._state[api]

            if state["tokens"] >= tokens:
                state["tokens"] -= tokens
                return 0.0

            # Calculate wait time
            needed = tokens - state["tokens"]
            wait_time = needed / state["refill_rate"]

        logger.debug(
            "shared_rate_limit_waiting",
            api=api,
            tokens_needed=tokens,
            wait_seconds=wait_time,
        )

        await asyncio.sleep(wait_time)

        with self._locks[api]:
            self._refill(api)
            self._state[api]["tokens"] -= tokens

        return float(wait_time)

    def get_status(self, api: str) -> dict[str, float]:
        """Get rate limit status for an API.

        Args:
            api: API name.

        Returns:
            Dict with tokens, max_tokens, refill_rate.
        """
        if api not in self._state:
            return {}

        with self._locks[api]:
            self._refill(api)
            state = self._state[api]
            return {
                "tokens": state["tokens"],
                "max_tokens": state["max_tokens"],
                "refill_rate": state["refill_rate"],
                "percent_available": (state["tokens"] / state["max_tokens"]) * 100,
            }

    def get_all_status(self) -> dict[str, dict[str, float]]:
        """Get rate limit status for all APIs.

        Returns:
            Dict of API name to status.
        """
        return {api: self.get_status(api) for api in self._state}
