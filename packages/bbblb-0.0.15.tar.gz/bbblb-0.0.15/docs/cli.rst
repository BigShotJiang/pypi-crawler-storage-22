.. _cli:

=========
Admin CLI
=========

.. note::

    If you followed the :doc:`docker compose based deployment <install>`, you can use the ``bbblb.sh`` wrapper ro tun ``bbblb`` inside the container.

BBBLB Commands
==================

.. include:: _click.rst
