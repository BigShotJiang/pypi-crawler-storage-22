from .core import BBOTCore

CORE = BBOTCore()
