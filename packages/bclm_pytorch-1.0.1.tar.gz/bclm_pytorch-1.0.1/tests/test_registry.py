# tests/test_registry.py
import pytest
from bclm.registry import (
    register_architecture,
    get_architecture,
    list_architectures,
    ArchitectureEntry,
)


class TestRegistry:
    def test_builtin_bclm1_registered(self):
        entry = get_architecture("BCLM1Model")
        assert entry is not None
        assert entry.model_class is not None
        assert entry.config_class is not None
        assert entry.inference_class is not None

    def test_list_includes_bclm1(self):
        names = list_architectures()
        assert "BCLM1Model" in names

    def test_unknown_architecture_raises(self):
        with pytest.raises(ValueError, match="Unknown architecture"):
            get_architecture("NonExistentModel_v99")

    def test_custom_registration(self):
        class DummyModel:
            pass

        class DummyConfig:
            @classmethod
            def from_dict(cls, d):
                return cls()

        class DummyInference:
            pass

        register_architecture(
            "TestDummyArch",
            model_class=DummyModel,
            config_class=DummyConfig,
            inference_class=DummyInference,
        )

        entry = get_architecture("TestDummyArch")
        assert entry.model_class is DummyModel
        assert entry.config_class is DummyConfig
        assert entry.inference_class is DummyInference
        assert "TestDummyArch" in list_architectures()