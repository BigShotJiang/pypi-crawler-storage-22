"""BC Calc Practice - Generate AP BC Calculus practice problems using AI."""

__version__ = "0.1.1"
