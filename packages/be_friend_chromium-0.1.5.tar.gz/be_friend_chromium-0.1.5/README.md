# be-friend-chromium

A Python client library for Chromium DevTools Protocol.

## Installation

```bash
pip install be-friend-chromium
```

## Features

- Connect to Chromium-based browsers via DevTools Protocol
- Browser automation and control
- Network interception and monitoring
- Element interaction

## Quick Start

```python
from be_friend_chromium import Browser

# Your code here
```

## Requirements

- Python >= 3.12
- Chromium-based browser (Chrome, Edge, etc.)

## License

MIT
