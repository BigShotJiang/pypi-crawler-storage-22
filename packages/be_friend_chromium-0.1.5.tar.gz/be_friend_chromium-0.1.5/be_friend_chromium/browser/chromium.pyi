from be_friend_chromium.browser.base import Browser as Browser
from typing import Any, Callable

class Chromium(Browser):
    def __init__(self, connection_port: int, on_target_session_creating: Callable[[dict], Any] | None = None, on_target_session_created: Callable[[dict], Any] | None = None, on_target_created: Callable[[dict], Any] | None = None, on_target_destroyed: Callable[[dict], Any] | None = None, on_target_info_changed: Callable[[dict], Any] | None = None) -> None: ...
