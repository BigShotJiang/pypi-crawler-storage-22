from be_friend_chromium.protocol.base import Command as Command
from be_friend_chromium.protocol.inspector.methods import DisableCommand as DisableCommand, EnableCommand as EnableCommand, InspectorMethod as InspectorMethod

class InspectorCommands:
    @staticmethod
    def enable() -> EnableCommand: ...
    @staticmethod
    def disable() -> DisableCommand: ...
