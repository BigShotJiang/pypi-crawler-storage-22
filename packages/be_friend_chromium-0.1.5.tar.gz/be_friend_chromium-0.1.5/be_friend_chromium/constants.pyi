from _typeshed import Incomplete
from enum import Enum

class DefaultTimeout:
    PAGE_LOAD: int
    COMMAND_EXECUTION: int
    WS_RECEIVE_POLL: float

class DefaultLimit:
    NETWORK_LOG_PER_SESSION: int

class _MatchType(Enum):
    CONTAINS = 'contains'
    STARTS_WITH = 'starts_with'
    ENDS_WITH = 'ends_with'
    NOT_EQUAL = 'not_equal'
    EQUAL = 'equal'

class MatchExpression:
    def __or__(self, other: MatchExpression) -> CombinedMatcher: ...
    def __and__(self, other: MatchExpression) -> CombinedMatcher: ...

class Matcher(MatchExpression):
    value: Incomplete
    match_type: Incomplete
    def __init__(self, value: str, match_type: _MatchType) -> None: ...

class CombinedMatcher(MatchExpression):
    matchers: Incomplete
    logic: Incomplete
    def __init__(self, matchers: list[MatchExpression], logic: str) -> None: ...

class Match:
    @staticmethod
    def contains(value: str) -> Matcher: ...
    @staticmethod
    def starts_with(value: str) -> Matcher: ...
    @staticmethod
    def ends_with(value: str) -> Matcher: ...
    @staticmethod
    def not_equal(value: str) -> Matcher: ...
    @staticmethod
    def equal(value: str) -> Matcher: ...

class By(str, Enum):
    CSS_SELECTOR = 'css'
    XPATH = 'xpath'
    CLASS_NAME = 'class_name'
    ID = 'id'
    TAG_NAME = 'tag_name'
    NAME = 'name'

class PageLoadState(str, Enum):
    COMPLETE = 'complete'
    INTERACTIVE = 'interactive'

class ScrollPosition(str, Enum):
    UP = 'up'
    DOWN = 'down'
    LEFT = 'left'
    RIGHT = 'right'

class Scripts:
    ELEMENT_VISIBLE: str
    ELEMENT_ON_TOP: str
    ELEMENT_INTERACTIVE: str
    CLICK: str
    CLICK_OPTION_TAG: str
    BOUNDS: str
    FIND_RELATIVE_XPATH_ELEMENT: str
    FIND_XPATH_ELEMENT: str
    FIND_RELATIVE_XPATH_ELEMENTS: str
    FIND_XPATH_ELEMENTS: str
    QUERY_SELECTOR: str
    RELATIVE_QUERY_SELECTOR: str
    QUERY_SELECTOR_ALL: str
    RELATIVE_QUERY_SELECTOR_ALL: str
    GET_TEXT_BY_XPATH: str
    GET_TEXT_BY_CSS: str
    GET_PARENT_NODE: str
    GET_CHILDREN_NODE: str
    GET_SIBLINGS_NODE: str
    MAKE_REQUEST: str
    SCROLL_BY: str
    SCROLL_TO_TOP: str
    SCROLL_TO_BOTTOM: str
    GET_SCROLL_Y: str
    GET_REMAINING_SCROLL_TO_BOTTOM: str
    GET_VIEWPORT_CENTER: str
    INSERT_TEXT: str
    IS_EDITABLE: str
    IS_OPTION_TAG: str

class Key(tuple[str, int], Enum):
    BACKSPACE = ('Backspace', 8)
    TAB = ('Tab', 9)
    ENTER = ('Enter', 13)
    SHIFT = ('Shift', 16)
    CONTROL = ('Control', 17)
    ALT = ('Alt', 18)
    PAUSE = ('Pause', 19)
    CAPSLOCK = ('CapsLock', 20)
    ESCAPE = ('Escape', 27)
    SPACE = ('Space', 32)
    PAGEUP = ('PageUp', 33)
    PAGEDOWN = ('PageDown', 34)
    END = ('End', 35)
    HOME = ('Home', 36)
    ARROWLEFT = ('ArrowLeft', 37)
    ARROWUP = ('ArrowUp', 38)
    ARROWRIGHT = ('ArrowRight', 39)
    ARROWDOWN = ('ArrowDown', 40)
    PRINTSCREEN = ('PrintScreen', 44)
    INSERT = ('Insert', 45)
    DELETE = ('Delete', 46)
    DIGIT0 = ('0', 48)
    DIGIT1 = ('1', 49)
    DIGIT2 = ('2', 50)
    DIGIT3 = ('3', 51)
    DIGIT4 = ('4', 52)
    DIGIT5 = ('5', 53)
    DIGIT6 = ('6', 54)
    DIGIT7 = ('7', 55)
    DIGIT8 = ('8', 56)
    DIGIT9 = ('9', 57)
    A = ('A', 65)
    B = ('B', 66)
    C = ('C', 67)
    D = ('D', 68)
    E = ('E', 69)
    F = ('F', 70)
    G = ('G', 71)
    H = ('H', 72)
    I = ('I', 73)
    J = ('J', 74)
    K = ('K', 75)
    L = ('L', 76)
    M = ('M', 77)
    N = ('N', 78)
    O = ('O', 79)
    P = ('P', 80)
    Q = ('Q', 81)
    R = ('R', 82)
    S = ('S', 83)
    T = ('T', 84)
    U = ('U', 85)
    V = ('V', 86)
    W = ('W', 87)
    X = ('X', 88)
    Y = ('Y', 89)
    Z = ('Z', 90)
    META = ('Meta', 91)
    METARIGHT = ('MetaRight', 92)
    CONTEXTMENU = ('ContextMenu', 93)
    NUMPAD0 = ('Numpad0', 96)
    NUMPAD1 = ('Numpad1', 97)
    NUMPAD2 = ('Numpad2', 98)
    NUMPAD3 = ('Numpad3', 99)
    NUMPAD4 = ('Numpad4', 100)
    NUMPAD5 = ('Numpad5', 101)
    NUMPAD6 = ('Numpad6', 102)
    NUMPAD7 = ('Numpad7', 103)
    NUMPAD8 = ('Numpad8', 104)
    NUMPAD9 = ('Numpad9', 105)
    NUMPADMULTIPLY = ('NumpadMultiply', 106)
    NUMPADADD = ('NumpadAdd', 107)
    NUMPADSUBTRACT = ('NumpadSubtract', 109)
    NUMPADDECIMAL = ('NumpadDecimal', 110)
    NUMPADDIVIDE = ('NumpadDivide', 111)
    F1 = ('F1', 112)
    F2 = ('F2', 113)
    F3 = ('F3', 114)
    F4 = ('F4', 115)
    F5 = ('F5', 116)
    F6 = ('F6', 117)
    F7 = ('F7', 118)
    F8 = ('F8', 119)
    F9 = ('F9', 120)
    F10 = ('F10', 121)
    F11 = ('F11', 122)
    F12 = ('F12', 123)
    NUMLOCK = ('NumLock', 144)
    SCROLLLOCK = ('ScrollLock', 145)
    SEMICOLON = ('Semicolon', 186)
    EQUALSIGN = ('EqualSign', 187)
    COMMA = ('Comma', 188)
    MINUS = ('Minus', 189)
    PERIOD = ('Period', 190)
    SLASH = ('Slash', 191)
    GRAVEACCENT = ('GraveAccent', 192)
    BRACKETLEFT = ('BracketLeft', 219)
    BACKSLASH = ('Backslash', 220)
    BRACKETRIGHT = ('BracketRight', 221)
    QUOTE = ('Quote', 222)

class BrowserType(Enum):
    CHROME = ...
    EDGE = ...

class TypoType(str, Enum):
    ADJACENT = 'adjacent'
    TRANSPOSE = 'transpose'
    DOUBLE = 'double'
    SKIP = 'skip'
    MISSED_SPACE = 'missed_space'

DEFAULT_TYPO_PROBABILITY: float
QWERTY_NEIGHBORS: dict[str, list[str]]
