from _typeshed import Incomplete

class BeFriendChromiumException(Exception):
    message: str
    def __init__(self, message: str = '') -> None: ...

class ConnectionException(BeFriendChromiumException):
    message: str

class ConnectionFailed(ConnectionException):
    message: str

class ReconnectionFailed(ConnectionException):
    message: str

class ConnectionRetryExhausted(ConnectionException):
    message: str
    attempts: Incomplete
    last_error: Incomplete
    def __init__(self, attempts: int = 0, last_error: str = '') -> None: ...

class WebSocketConnectionClosed(ConnectionException):
    message: str

class NetworkError(ConnectionException):
    message: str

class BrowserException(BeFriendChromiumException):
    message: str

class BrowserNotRunning(BrowserException):
    message: str

class FailedToStartBrowser(BrowserException):
    message: str

class UnsupportedOS(BrowserException):
    message: str

class NoValidTabFound(BrowserException):
    message: str

class InvalidConnectionPort(BrowserException):
    message: str

class InvalidWebSocketAddress(BrowserException):
    message: str

class MissingTargetOrWebSocket(BrowserException):
    message: str

class ProtocolException(BeFriendChromiumException):
    message: str

class TopLevelTargetRequired(ProtocolException):
    message: str

class InvalidCommand(ProtocolException):
    message: str

class InvalidResponse(ProtocolException):
    message: str

class ResendCommandFailed(ProtocolException):
    message: str

class CommandExecutionTimeout(ProtocolException):
    message: str
    method: Incomplete
    timeout: Incomplete
    def __init__(self, method: str = '', timeout: int = 0) -> None: ...

class CDPError(ProtocolException):
    message: str
    PARSE_ERROR: int
    INVALID_REQUEST: int
    METHOD_NOT_FOUND: int
    INVALID_PARAMS: int
    INTERNAL_ERROR: int
    SERVER_ERROR: int
    SESSION_NOT_FOUND: int
    TARGET_CLOSED: int
    code: Incomplete
    error_message: Incomplete
    data: Incomplete
    method: Incomplete
    def __init__(self, code: int = 0, message: str = '', data: str = '', method: str = '') -> None: ...
    @property
    def is_session_error(self) -> bool: ...
    @property
    def is_target_closed(self) -> bool: ...
    @property
    def is_retryable(self) -> bool: ...

class CDPSessionError(CDPError):
    message: str

class CDPTargetClosedError(CDPError):
    message: str

class InvalidCallback(ProtocolException):
    message: str

class EventNotSupported(ProtocolException):
    message: str

class ElementException(BeFriendChromiumException):
    message: str

class ElementNotFound(ElementException):
    message: str

class ElementNotVisible(ElementException):
    message: str

class ElementNotInteractable(ElementException):
    message: str

class ClickIntercepted(ElementException):
    message: str

class ElementNotAFileInput(ElementException):
    message: str

class TimeoutException(BeFriendChromiumException):
    message: str

class PageLoadTimeout(TimeoutException):
    message: str

class WaitElementTimeout(TimeoutException):
    message: str

class DownloadTimeout(TimeoutException):
    message: str

class ConfigurationException(BeFriendChromiumException):
    message: str

class InvalidOptionsObject(ConfigurationException):
    message: str

class InvalidBrowserPath(ConfigurationException):
    message: str

class ArgumentAlreadyExistsInOptions(ConfigurationException):
    message: str

class ArgumentNotFoundInOptions(ConfigurationException):
    message: str

class InvalidFileExtension(ConfigurationException):
    message: str

class InvalidTabInitialization(ConfigurationException):
    message: str

class MissingScreenshotPath(ConfigurationException):
    message: str

class DialogException(BeFriendChromiumException):
    message: str

class NoDialogPresent(DialogException):
    message: str

class NotAnIFrame(BeFriendChromiumException):
    message: str

class InvalidIFrame(BeFriendChromiumException):
    message: str

class IFrameNotFound(BeFriendChromiumException):
    message: str

class NetworkEventsNotEnabled(BeFriendChromiumException):
    message: str

class RequestException(BeFriendChromiumException):
    message: str

class HTTPError(RequestException):
    message: str

class ScriptException(BeFriendChromiumException):
    message: str

class InvalidScriptWithElement(ScriptException):
    message: str

class WrongPrefsDict(BeFriendChromiumException):
    message: str

class StaleElementError(ElementException):
    message: str

class ElementPreconditionError(ElementException):
    message: str
