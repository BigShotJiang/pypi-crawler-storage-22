from be_friend_chromium.protocol.accessibility.types import AXNode as AXNode
from be_friend_chromium.protocol.base import CDPEvent as CDPEvent
from enum import Enum
from typing_extensions import TypedDict

class AccessibilityEvent(str, Enum):
    LOAD_COMPLETE = 'Accessibility.loadComplete'
    NODES_UPDATED = 'Accessibility.nodesUpdated'

class LoadCompleteEventParams(TypedDict):
    root: AXNode

class NodesUpdatedEventParams(TypedDict):
    nodes: list[AXNode]
LoadComplete = CDPEvent[LoadCompleteEventParams]
NodesUpdated = CDPEvent[NodesUpdatedEventParams]
