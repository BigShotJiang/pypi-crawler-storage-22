from be_friend_chromium.protocol.accessibility.types import AXNode as AXNode, AXNodeId as AXNodeId
from be_friend_chromium.protocol.base import Command as Command, EmptyParams as EmptyParams, EmptyResponse as EmptyResponse
from be_friend_chromium.protocol.dom.types import BackendNodeId as BackendNodeId, NodeId as NodeId
from enum import Enum
from typing_extensions import TypedDict

class AccessibilityMethod(str, Enum):
    DISABLE = 'Accessibility.disable'
    ENABLE = 'Accessibility.enable'
    GET_FULL_AX_TREE = 'Accessibility.getFullAXTree'
    GET_PARTIAL_AX_TREE = 'Accessibility.getPartialAXTree'
    GET_ROOT_AX_NODE = 'Accessibility.getRootAXNode'
    GET_AX_NODE_AND_ANCESTORS = 'Accessibility.getAXNodeAndAncestors'
    GET_CHILD_AX_NODES = 'Accessibility.getChildAXNodes'
    QUERY_AX_TREE = 'Accessibility.queryAXTree'

class GetPartialAXTreeParams(TypedDict, total=False):
    nodeId: NodeId
    backendNodeId: BackendNodeId
    objectId: str
    fetchRelatives: bool

class GetPartialAXTreeResult(TypedDict):
    nodes: list[AXNode]

class GetFullAXTreeParams(TypedDict, total=False):
    depth: int
    frameId: str

class GetFullAXTreeResult(TypedDict):
    nodes: list[AXNode]

class GetRootAXNodeParams(TypedDict, total=False):
    frameId: str

class GetRootAXNodeResult(TypedDict):
    node: AXNode

class GetAXNodeAndAncestorsParams(TypedDict, total=False):
    nodeId: NodeId
    backendNodeId: BackendNodeId
    objectId: str

class GetAXNodeAndAncestorsResult(TypedDict):
    nodes: list[AXNode]

class GetChildAXNodesParams(TypedDict, total=False):
    id: AXNodeId
    frameId: str

class GetChildAXNodesResult(TypedDict):
    nodes: list[AXNode]

class QueryAXTreeParams(TypedDict, total=False):
    nodeId: NodeId
    backendNodeId: BackendNodeId
    objectId: str
    accessibleName: str
    role: str

class QueryAXTreeResult(TypedDict):
    nodes: list[AXNode]
GetPartialAXTreeResponse = GetPartialAXTreeResult
GetFullAXTreeResponse = GetFullAXTreeResult
GetRootAXNodeResponse = GetRootAXNodeResult
GetAXNodeAndAncestorsResponse = GetAXNodeAndAncestorsResult
GetChildAXNodesResponse = GetChildAXNodesResult
QueryAXTreeResponse = QueryAXTreeResult
DisableCommand = Command[EmptyParams, EmptyResponse]
EnableCommand = Command[EmptyParams, EmptyResponse]
GetPartialAXTreeCommand = Command[GetPartialAXTreeParams, GetPartialAXTreeResponse]
GetFullAXTreeCommand = Command[GetFullAXTreeParams, GetFullAXTreeResponse]
GetRootAXNodeCommand = Command[GetRootAXNodeParams, GetRootAXNodeResponse]
GetAXNodeAndAncestorsCommand = Command[GetAXNodeAndAncestorsParams, GetAXNodeAndAncestorsResponse]
GetChildAXNodesCommand = Command[GetChildAXNodesParams, GetChildAXNodesResponse]
QueryAXTreeCommand = Command[QueryAXTreeParams, QueryAXTreeResponse]
