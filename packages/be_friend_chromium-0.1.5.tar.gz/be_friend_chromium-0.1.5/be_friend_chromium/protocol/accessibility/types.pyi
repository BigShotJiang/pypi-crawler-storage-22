from be_friend_chromium.protocol.dom.types import BackendNodeId as BackendNodeId
from enum import Enum
from typing import Any
from typing_extensions import NotRequired, TypedDict

AXNodeId = str

class AXValueType(str, Enum):
    BOOLEAN = 'boolean'
    TRISTATE = 'tristate'
    BOOLEAN_OR_UNDEFINED = 'booleanOrUndefined'
    IDREF = 'idref'
    IDREF_LIST = 'idrefList'
    INTEGER = 'integer'
    NODE = 'node'
    NODE_LIST = 'nodeList'
    NUMBER = 'number'
    STRING = 'string'
    COMPUTED_STRING = 'computedString'
    TOKEN = 'token'
    TOKEN_LIST = 'tokenList'
    DOM_RELATION = 'domRelation'
    ROLE = 'role'
    INTERNAL_ROLE = 'internalRole'
    VALUE_UNDEFINED = 'valueUndefined'

class AXValueSourceType(str, Enum):
    ATTRIBUTE = 'attribute'
    IMPLICIT = 'implicit'
    STYLE = 'style'
    CONTENTS = 'contents'
    PLACEHOLDER = 'placeholder'
    RELATED_ELEMENT = 'relatedElement'

class AXValueNativeSourceType(str, Enum):
    DESCRIPTION = 'description'
    FIGCAPTION = 'figcaption'
    LABEL = 'label'
    LABELFOR = 'labelfor'
    LABELWRAPPED = 'labelwrapped'
    LEGEND = 'legend'
    RUBYANNOTATION = 'rubyannotation'
    TABLECAPTION = 'tablecaption'
    TITLE = 'title'
    OTHER = 'other'

class AXValueSource(TypedDict, total=False):
    type: AXValueSourceType
    value: AXValue
    attribute: str
    attributeValue: AXValue
    superseded: bool
    nativeSource: AXValueNativeSourceType
    nativeSourceValue: AXValue
    invalid: bool
    invalidReason: str

class AXRelatedNode(TypedDict):
    backendDOMNodeId: BackendNodeId
    idref: NotRequired[str]
    text: NotRequired[str]

class AXProperty(TypedDict):
    name: AXPropertyName
    value: AXValue

class AXValue(TypedDict, total=False):
    type: AXValueType
    value: Any
    relatedNodes: list[AXRelatedNode]
    sources: list[AXValueSource]

class AXPropertyName(str, Enum):
    BUSY = 'busy'
    DISABLED = 'disabled'
    EDITABLE = 'editable'
    FOCUSABLE = 'focusable'
    FOCUSED = 'focused'
    HIDDEN = 'hidden'
    HIDDEN_ROOT = 'hiddenRoot'
    INVALID = 'invalid'
    KEYSHORTCUTS = 'keyshortcuts'
    SETTABLE = 'settable'
    ROLEDESCRIPTION = 'roledescription'
    LIVE = 'live'
    ATOMIC = 'atomic'
    RELEVANT = 'relevant'
    ROOT = 'root'
    AUTOCOMPLETE = 'autocomplete'
    HAS_POPUP = 'hasPopup'
    LEVEL = 'level'
    MULTISELECTABLE = 'multiselectable'
    ORIENTATION = 'orientation'
    MULTILINE = 'multiline'
    READONLY = 'readonly'
    REQUIRED = 'required'
    VALUE_MIN = 'valuemin'
    VALUE_MAX = 'valuemax'
    VALUE_TEXT = 'valuetext'
    CHECKED = 'checked'
    EXPANDED = 'expanded'
    MODAL = 'modal'
    PRESSED = 'pressed'
    SELECTED = 'selected'
    ACTIVEDESCENDANT = 'activedescendant'
    CONTROLS = 'controls'
    DESCRIBEDBY = 'describedby'
    DETAILS = 'details'
    ERRORMESSAGE = 'errormessage'
    FLOWTO = 'flowto'
    LABELLEDBY = 'labelledby'
    OWNS = 'owns'
    POSІНSET = 'posinset'
    SETSIZE = 'setsize'

class AXNode(TypedDict, total=False):
    nodeId: AXNodeId
    ignored: bool
    ignoredReasons: list[dict[str, Any]]
    role: AXValue
    chromeRole: AXValue
    name: AXValue
    description: AXValue
    value: AXValue
    properties: list[AXProperty]
    parentId: AXNodeId
    childIds: list[AXNodeId]
    backendDOMNodeId: BackendNodeId
    frameId: str
