from typing import Generic, TypeVar
from typing_extensions import NotRequired, TypedDict

T_CommandParams = TypeVar('T_CommandParams')
T_CommandResponse = TypeVar('T_CommandResponse')
T_EventParams = TypeVar('T_EventParams')

class EmptyParams(TypedDict): ...
class EmptyResponse(TypedDict): ...

class Command(TypedDict, Generic[T_CommandParams, T_CommandResponse]):
    id: NotRequired[int]
    method: str
    params: NotRequired[T_CommandParams]
    sessionId: NotRequired[str]

class Response(TypedDict, Generic[T_CommandResponse]):
    id: int
    result: T_CommandResponse
    sessionId: NotRequired[str]

class CDPEvent(TypedDict, Generic[T_EventParams]):
    method: str
    params: NotRequired[T_EventParams]
    sessionId: NotRequired[str]
