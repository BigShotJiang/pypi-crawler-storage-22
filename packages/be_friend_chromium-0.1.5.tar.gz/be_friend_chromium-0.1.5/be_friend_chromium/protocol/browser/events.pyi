from be_friend_chromium.protocol.base import CDPEvent as CDPEvent
from be_friend_chromium.protocol.browser.types import DownloadProgressState as DownloadProgressState
from enum import Enum
from typing_extensions import NotRequired, TypedDict

class BrowserEvent(str, Enum):
    DOWNLOAD_PROGRESS = 'Browser.downloadProgress'
    DOWNLOAD_WILL_BEGIN = 'Browser.downloadWillBegin'

class DownloadProgressEventParams(TypedDict):
    guid: str
    totalBytes: float
    receivedBytes: float
    state: DownloadProgressState
    filePath: NotRequired[str]

class DownloadWillBeginEventParams(TypedDict):
    frameId: str
    guid: str
    url: str
    suggestedFilename: str
DownloadProgressEvent = CDPEvent[DownloadProgressEventParams]
DownloadWillBeginEvent = CDPEvent[DownloadWillBeginEventParams]
