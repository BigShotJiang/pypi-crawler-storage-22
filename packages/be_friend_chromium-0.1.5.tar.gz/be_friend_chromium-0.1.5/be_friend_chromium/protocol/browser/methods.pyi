from be_friend_chromium.protocol.base import Command as Command, EmptyParams as EmptyParams, EmptyResponse as EmptyResponse
from be_friend_chromium.protocol.browser.types import Bounds as Bounds, BrowserCommandId as BrowserCommandId, BrowserContextID as BrowserContextID, DownloadBehavior as DownloadBehavior, Histogram as Histogram, PermissionDescriptor as PermissionDescriptor, PermissionSetting as PermissionSetting, PermissionType as PermissionType, PrivacySandboxAPI as PrivacySandboxAPI, WindowID as WindowID
from enum import Enum
from typing_extensions import NotRequired, TypedDict

class BrowserMethod(str, Enum):
    ADD_PRIVACY_SANDBOX_COORDINATOR_KEY_CONFIG = 'Browser.addPrivacySandboxCoordinatorKeyConfig'
    ADD_PRIVACY_SANDBOX_ENROLLMENT_OVERRIDE = 'Browser.addPrivacySandboxEnrollmentOverride'
    CANCEL_DOWNLOAD = 'Browser.cancelDownload'
    CLOSE = 'Browser.close'
    CRASH = 'Browser.crash'
    CRASH_GPU_PROCESS = 'Browser.crashGpuProcess'
    EXECUTE_BROWSER_COMMAND = 'Browser.executeBrowserCommand'
    GET_BROWSER_COMMAND_LINE = 'Browser.getBrowserCommandLine'
    GET_HISTOGRAM = 'Browser.getHistogram'
    GET_HISTOGRAMS = 'Browser.getHistograms'
    GET_VERSION = 'Browser.getVersion'
    GET_WINDOW_BOUNDS = 'Browser.getWindowBounds'
    GET_WINDOW_FOR_TARGET = 'Browser.getWindowForTarget'
    GRANT_PERMISSIONS = 'Browser.grantPermissions'
    RESET_PERMISSIONS = 'Browser.resetPermissions'
    SET_CONTENTS_SIZE = 'Browser.setContentsSize'
    SET_DOCK_TILE = 'Browser.setDockTile'
    SET_DOWNLOAD_BEHAVIOR = 'Browser.setDownloadBehavior'
    SET_PERMISSION = 'Browser.setPermission'
    SET_WINDOW_BOUNDS = 'Browser.setWindowBounds'

class SetPermissionParams(TypedDict):
    permission: PermissionDescriptor
    setting: PermissionSetting
    origin: NotRequired[str]
    browserContextId: NotRequired[BrowserContextID]

class GrantPermissionsParams(TypedDict):
    permissions: list[PermissionType]
    origin: NotRequired[str]
    browserContextId: NotRequired[BrowserContextID]

class ResetPermissionsParams(TypedDict):
    browserContextId: NotRequired[BrowserContextID]

class SetDownloadBehaviorParams(TypedDict):
    behavior: DownloadBehavior
    browserContextId: NotRequired[BrowserContextID]
    downloadPath: NotRequired[str]
    eventsEnabled: NotRequired[bool]

class CancelDownloadParams(TypedDict):
    guid: str
    browserContextId: NotRequired[BrowserContextID]

class GetHistogramsParams(TypedDict):
    query: NotRequired[str]
    delta: NotRequired[bool]

class GetHistogramParams(TypedDict):
    name: str
    delta: NotRequired[bool]

class GetWindowBoundsParams(TypedDict):
    windowId: WindowID

class GetWindowForTargetParams(TypedDict):
    targetId: NotRequired[str]

class SetWindowBoundsParams(TypedDict):
    windowId: WindowID
    bounds: Bounds

class SetContentsSizeParams(TypedDict):
    windowId: WindowID
    width: NotRequired[int]
    height: NotRequired[int]

class SetDockTileParams(TypedDict):
    badgeLabel: NotRequired[str]
    image: NotRequired[str]

class ExecuteBrowserCommandParams(TypedDict):
    commandId: BrowserCommandId

class AddPrivacySandboxEnrollmentOverrideParams(TypedDict):
    url: str

class AddPrivacySandboxCoordinatorKeyConfigParams(TypedDict):
    api: PrivacySandboxAPI
    coordinatorOrigin: str
    keyConfig: str
    browserContextId: NotRequired[BrowserContextID]

class GetVersionResult(TypedDict):
    protocolVersion: str
    product: str
    revision: str
    userAgent: str
    jsVersion: str

class GetBrowserCommandLineResult(TypedDict):
    arguments: list[str]

class GetHistogramsResult(TypedDict):
    histograms: list[Histogram]

class GetHistogramResult(TypedDict):
    histogram: Histogram

class GetWindowBoundsResult(TypedDict):
    bounds: Bounds

class GetWindowForTargetResult(TypedDict):
    windowId: WindowID
    bounds: Bounds
GetVersionResponse = GetVersionResult
GetBrowserCommandLineResponse = GetBrowserCommandLineResult
GetHistogramsResponse = GetHistogramsResult
GetHistogramResponse = GetHistogramResult
GetWindowBoundsResponse = GetWindowBoundsResult
GetWindowForTargetResponse = GetWindowForTargetResult
AddPrivacySandboxCoordinatorKeyConfigCommand = Command[AddPrivacySandboxCoordinatorKeyConfigParams, EmptyResponse]
AddPrivacySandboxEnrollmentOverrideCommand = Command[AddPrivacySandboxEnrollmentOverrideParams, EmptyResponse]
CancelDownloadCommand = Command[CancelDownloadParams, EmptyResponse]
CloseCommand = Command[EmptyParams, EmptyResponse]
CrashCommand = Command[EmptyParams, EmptyResponse]
CrashGpuProcessCommand = Command[EmptyParams, EmptyResponse]
ExecuteBrowserCommandCommand = Command[ExecuteBrowserCommandParams, EmptyResponse]
GetBrowserCommandLineCommand = Command[EmptyParams, GetBrowserCommandLineResponse]
GetHistogramCommand = Command[GetHistogramParams, GetHistogramResponse]
GetHistogramsCommand = Command[GetHistogramsParams, GetHistogramsResponse]
GetVersionCommand = Command[EmptyParams, GetVersionResponse]
GetWindowBoundsCommand = Command[GetWindowBoundsParams, GetWindowBoundsResponse]
GetWindowForTargetCommand = Command[GetWindowForTargetParams, GetWindowForTargetResponse]
GrantPermissionsCommand = Command[GrantPermissionsParams, EmptyResponse]
ResetPermissionsCommand = Command[ResetPermissionsParams, EmptyResponse]
SetContentsSizeCommand = Command[SetContentsSizeParams, EmptyResponse]
SetDockTileCommand = Command[SetDockTileParams, EmptyResponse]
SetDownloadBehaviorCommand = Command[SetDownloadBehaviorParams, EmptyResponse]
SetPermissionCommand = Command[SetPermissionParams, EmptyResponse]
SetWindowBoundsCommand = Command[SetWindowBoundsParams, EmptyResponse]
