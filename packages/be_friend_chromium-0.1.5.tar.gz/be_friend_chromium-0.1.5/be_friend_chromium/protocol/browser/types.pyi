from enum import Enum
from typing_extensions import TypedDict

BrowserContextID = str
WindowID = int

class WindowState(str, Enum):
    NORMAL = 'normal'
    MINIMIZED = 'minimized'
    MAXIMIZED = 'maximized'
    FULLSCREEN = 'fullscreen'

class DownloadBehavior(str, Enum):
    DENY = 'deny'
    ALLOW = 'allow'
    ALLOW_AND_NAME = 'allowAndName'
    DEFAULT = 'default'

class DownloadProgressState(str, Enum):
    IN_PROGRESS = 'inProgress'
    COMPLETED = 'completed'
    CANCELED = 'canceled'

class Bounds(TypedDict, total=False):
    left: int
    top: int
    width: int
    height: int
    windowState: WindowState

class PermissionType(str, Enum):
    AR = 'ar'
    AUDIO_CAPTURE = 'audioCapture'
    AUTOMATIC_FULLSCREEN = 'automaticFullscreen'
    BACKGROUND_FETCH = 'backgroundFetch'
    BACKGROUND_SYNC = 'backgroundSync'
    CAMERA_PAN_TILT_ZOOM = 'cameraPanTiltZoom'
    CAPTURED_SURFACE_CONTROL = 'capturedSurfaceControl'
    CLIPBOARD_READ_WRITE = 'clipboardReadWrite'
    CLIPBOARD_SANITIZED_WRITE = 'clipboardSanitizedWrite'
    DISPLAY_CAPTURE = 'displayCapture'
    DURABLE_STORAGE = 'durableStorage'
    GEOLOCATION = 'geolocation'
    HAND_TRACKING = 'handTracking'
    IDLE_DETECTION = 'idleDetection'
    KEYBOARD_LOCK = 'keyboardLock'
    LOCAL_FONTS = 'localFonts'
    LOCAL_NETWORK_ACCESS = 'localNetworkAccess'
    MIDI = 'midi'
    MIDI_SYSEX = 'midiSysex'
    NFC = 'nfc'
    NOTIFICATIONS = 'notifications'
    PAYMENT_HANDLER = 'paymentHandler'
    PERIODIC_BACKGROUND_SYNC = 'periodicBackgroundSync'
    POINTER_LOCK = 'pointerLock'
    PROTECTED_MEDIA_IDENTIFIER = 'protectedMediaIdentifier'
    SENSORS = 'sensors'
    SMART_CARD = 'smartCard'
    SPEAKER_SELECTION = 'speakerSelection'
    STORAGE_ACCESS = 'storageAccess'
    TOP_LEVEL_STORAGE_ACCESS = 'topLevelStorageAccess'
    VIDEO_CAPTURE = 'videoCapture'
    VR = 'vr'
    WAKE_LOCK_SCREEN = 'wakeLockScreen'
    WAKE_LOCK_SYSTEM = 'wakeLockSystem'
    WEB_APP_INSTALLATION = 'webAppInstallation'
    WEB_PRINTING = 'webPrinting'
    WINDOW_MANAGEMENT = 'windowManagement'

class PermissionSetting(str, Enum):
    GRANTED = 'granted'
    DENIED = 'denied'
    PROMPT = 'prompt'

class PermissionDescriptor(TypedDict, total=False):
    name: str
    sysex: bool
    userVisibleOnly: bool
    allowWithoutSanitization: bool
    allowWithoutGesture: bool
    panTiltZoom: bool

class BrowserCommandId(str, Enum):
    OPEN_TAB_SEARCH = 'openTabSearch'
    CLOSE_TAB_SEARCH = 'closeTabSearch'
    OPEN_GLIC = 'openGlic'

class Bucket(TypedDict):
    low: int
    high: int
    count: int

class Histogram(TypedDict):
    name: str
    sum: int
    count: int
    buckets: list['Bucket']

class PrivacySandboxAPI(str, Enum):
    BIDDING_AND_AUCTION_SERVICES = 'BiddingAndAuctionServices'
    TRUSTED_KEY_VALUE = 'TrustedKeyValue'
