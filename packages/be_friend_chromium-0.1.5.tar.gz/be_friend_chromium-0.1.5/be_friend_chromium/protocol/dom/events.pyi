from be_friend_chromium.protocol.base import CDPEvent as CDPEvent
from be_friend_chromium.protocol.dom.types import BackendNode as BackendNode, Node as Node, NodeId as NodeId
from enum import Enum
from typing_extensions import TypedDict

class DomEvent(str, Enum):
    ATTRIBUTE_MODIFIED = 'DOM.attributeModified'
    ATTRIBUTE_REMOVED = 'DOM.attributeRemoved'
    CHARACTER_DATA_MODIFIED = 'DOM.characterDataModified'
    CHILD_NODE_COUNT_UPDATED = 'DOM.childNodeCountUpdated'
    CHILD_NODE_INSERTED = 'DOM.childNodeInserted'
    CHILD_NODE_REMOVED = 'DOM.childNodeRemoved'
    DISTRIBUTED_NODES_UPDATED = 'DOM.distributedNodesUpdated'
    DOCUMENT_UPDATED = 'DOM.documentUpdated'
    INLINE_STYLE_INVALIDATED = 'DOM.inlineStyleInvalidated'
    PSEUDO_ELEMENT_ADDED = 'DOM.pseudoElementAdded'
    PSEUDO_ELEMENT_REMOVED = 'DOM.pseudoElementRemoved'
    SCROLLABLE_FLAG_UPDATED = 'DOM.scrollableFlagUpdated'
    SHADOW_ROOT_POPPED = 'DOM.shadowRootPopped'
    SHADOW_ROOT_PUSHED = 'DOM.shadowRootPushed'
    SET_CHILD_NODES = 'DOM.setChildNodes'
    TOP_LAYER_ELEMENTS_UPDATED = 'DOM.topLayerElementsUpdated'

class AttributeModifiedEventParams(TypedDict):
    nodeId: NodeId
    name: str
    value: str

class AttributeRemovedEventParams(TypedDict):
    nodeId: NodeId
    name: str

class CharacterDataModifiedEventParams(TypedDict):
    nodeId: NodeId
    characterData: str

class ChildNodeCountUpdatedEventParams(TypedDict):
    nodeId: NodeId
    childNodeCount: int

class ChildNodeInsertedEventParams(TypedDict):
    parentNodeId: NodeId
    previousNodeId: NodeId
    node: Node

class ChildNodeRemovedEventParams(TypedDict):
    parentNodeId: NodeId
    nodeId: NodeId

class DistributedNodesUpdatedEventParams(TypedDict):
    insertionPointId: NodeId
    distributedNodes: list[BackendNode]

class DocumentUpdatedEventParams(TypedDict): ...

class InlineStyleInvalidatedEventParams(TypedDict):
    nodeIds: list[NodeId]

class PseudoElementAddedEventParams(TypedDict):
    parentId: NodeId
    pseudoElement: Node

class PseudoElementRemovedEventParams(TypedDict):
    parentId: NodeId
    pseudoElementId: NodeId

class ScrollableFlagUpdatedEventParams(TypedDict):
    nodeId: NodeId
    isScrollable: bool

class ShadowRootPoppedEventParams(TypedDict):
    hostId: NodeId
    rootId: NodeId

class ShadowRootPushedEventParams(TypedDict):
    hostId: NodeId
    root: Node

class SetChildNodesEventParams(TypedDict):
    parentId: NodeId
    nodes: list[Node]

class TopLayerElementsUpdatedEventParams(TypedDict): ...
AttributeModifiedEvent = CDPEvent[AttributeModifiedEventParams]
AttributeRemovedEvent = CDPEvent[AttributeRemovedEventParams]
CharacterDataModifiedEvent = CDPEvent[CharacterDataModifiedEventParams]
ChildNodeCountUpdatedEvent = CDPEvent[ChildNodeCountUpdatedEventParams]
ChildNodeInsertedEvent = CDPEvent[ChildNodeInsertedEventParams]
ChildNodeRemovedEvent = CDPEvent[ChildNodeRemovedEventParams]
DistributedNodesUpdatedEvent = CDPEvent[DistributedNodesUpdatedEventParams]
DocumentUpdatedEvent = CDPEvent[DocumentUpdatedEventParams]
InlineStyleInvalidatedEvent = CDPEvent[InlineStyleInvalidatedEventParams]
PseudoElementAddedEvent = CDPEvent[PseudoElementAddedEventParams]
PseudoElementRemovedEvent = CDPEvent[PseudoElementRemovedEventParams]
ScrollableFlagUpdatedEvent = CDPEvent[ScrollableFlagUpdatedEventParams]
ShadowRootPoppedEvent = CDPEvent[ShadowRootPoppedEventParams]
ShadowRootPushedEvent = CDPEvent[ShadowRootPushedEventParams]
SetChildNodesEvent = CDPEvent[SetChildNodesEventParams]
TopLayerElementsUpdatedEvent = CDPEvent[TopLayerElementsUpdatedEventParams]
