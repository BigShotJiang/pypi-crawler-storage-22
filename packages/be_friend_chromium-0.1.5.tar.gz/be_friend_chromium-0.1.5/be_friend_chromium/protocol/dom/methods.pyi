from be_friend_chromium.protocol.base import Command as Command, EmptyParams as EmptyParams, EmptyResponse as EmptyResponse
from be_friend_chromium.protocol.dom.types import BackendNodeId as BackendNodeId, BoxModel as BoxModel, CSSComputedStyleProperty as CSSComputedStyleProperty, DetachedElementInfo as DetachedElementInfo, IncludeWhitespace as IncludeWhitespace, LogicalAxes as LogicalAxes, Node as Node, NodeId as NodeId, PhysicalAxes as PhysicalAxes, Quad as Quad, Rect as Rect, RelationType as RelationType
from be_friend_chromium.protocol.page.types import FrameId as FrameId
from be_friend_chromium.protocol.runtime.types import ExecutionContextId as ExecutionContextId, RemoteObject as RemoteObject, RemoteObjectId as RemoteObjectId, StackTrace as StackTrace
from enum import Enum
from typing_extensions import TypedDict

class DomMethod(str, Enum):
    COLLECT_CLASS_NAMES_FROM_SUBTREE = 'DOM.collectClassNamesFromSubtree'
    COPY_TO = 'DOM.copyTo'
    DESCRIBE_NODE = 'DOM.describeNode'
    DISABLE = 'DOM.disable'
    DISCARD_SEARCH_RESULTS = 'DOM.discardSearchResults'
    ENABLE = 'DOM.enable'
    FOCUS = 'DOM.focus'
    FORCE_SHOW_POPOVER = 'DOM.forceShowPopover'
    GET_ANCHOR_ELEMENT = 'DOM.getAnchorElement'
    GET_ATTRIBUTES = 'DOM.getAttributes'
    GET_BOX_MODEL = 'DOM.getBoxModel'
    GET_CONTAINER_FOR_NODE = 'DOM.getContainerForNode'
    GET_CONTENT_QUADS = 'DOM.getContentQuads'
    GET_DETACHED_DOM_NODES = 'DOM.getDetachedDomNodes'
    GET_DOCUMENT = 'DOM.getDocument'
    GET_ELEMENT_BY_RELATION = 'DOM.getElementByRelation'
    GET_FILE_INFO = 'DOM.getFileInfo'
    GET_FLATTENED_DOCUMENT = 'DOM.getFlattenedDocument'
    GET_FRAME_OWNER = 'DOM.getFrameOwner'
    GET_NODE_FOR_LOCATION = 'DOM.getNodeForLocation'
    GET_NODE_STACK_TRACES = 'DOM.getNodeStackTraces'
    GET_NODES_FOR_SUBTREE_BY_STYLE = 'DOM.getNodesForSubtreeByStyle'
    GET_OUTER_HTML = 'DOM.getOuterHTML'
    GET_QUERYING_DESCENDANTS_FOR_CONTAINER = 'DOM.getQueryingDescendantsForContainer'
    GET_RELAYOUT_BOUNDARY = 'DOM.getRelayoutBoundary'
    GET_SEARCH_RESULTS = 'DOM.getSearchResults'
    GET_TOP_LAYER_ELEMENTS = 'DOM.getTopLayerElements'
    HIDE_HIGHLIGHT = 'DOM.hideHighlight'
    HIGHLIGHT_NODE = 'DOM.highlightNode'
    HIGHLIGHT_RECT = 'DOM.highlightRect'
    MARK_UNDOABLE_STATE = 'DOM.markUndoableState'
    MOVE_TO = 'DOM.moveTo'
    PERFORM_SEARCH = 'DOM.performSearch'
    PUSH_NODE_BY_PATH_TO_FRONTEND = 'DOM.pushNodeByPathToFrontend'
    PUSH_NODES_BY_BACKEND_IDS_TO_FRONTEND = 'DOM.pushNodesByBackendIdsToFrontend'
    QUERY_SELECTOR = 'DOM.querySelector'
    QUERY_SELECTOR_ALL = 'DOM.querySelectorAll'
    REDO = 'DOM.redo'
    REMOVE_ATTRIBUTE = 'DOM.removeAttribute'
    REMOVE_NODE = 'DOM.removeNode'
    REQUEST_CHILD_NODES = 'DOM.requestChildNodes'
    REQUEST_NODE = 'DOM.requestNode'
    RESOLVE_NODE = 'DOM.resolveNode'
    SCROLL_INTO_VIEW_IF_NEEDED = 'DOM.scrollIntoViewIfNeeded'
    SET_ATTRIBUTE_VALUE = 'DOM.setAttributeValue'
    SET_ATTRIBUTES_AS_TEXT = 'DOM.setAttributesAsText'
    SET_FILE_INPUT_FILES = 'DOM.setFileInputFiles'
    SET_INSPECTED_NODE = 'DOM.setInspectedNode'
    SET_NODE_NAME = 'DOM.setNodeName'
    SET_NODE_STACK_TRACES_ENABLED = 'DOM.setNodeStackTracesEnabled'
    SET_NODE_VALUE = 'DOM.setNodeValue'
    SET_OUTER_HTML = 'DOM.setOuterHTML'
    UNDO = 'DOM.undo'

class CollectClassNamesFromSubtreeParams(TypedDict):
    nodeId: NodeId

class CopyToParams(TypedDict, total=False):
    nodeId: NodeId
    targetNodeId: NodeId
    insertBeforeNodeId: NodeId

class DescribeNodeParams(TypedDict, total=False):
    nodeId: NodeId
    backendNodeId: BackendNodeId
    objectId: RemoteObjectId
    depth: int
    pierce: bool

class ScrollIntoViewIfNeededParams(TypedDict, total=False):
    nodeId: NodeId
    backendNodeId: BackendNodeId
    objectId: RemoteObjectId
    rect: Rect

class DiscardSearchResultsParams(TypedDict):
    searchId: str

class EnableParams(TypedDict, total=False):
    includeWhitespace: IncludeWhitespace

class FocusParams(TypedDict, total=False):
    nodeId: NodeId
    backendNodeId: BackendNodeId
    objectId: RemoteObjectId

class GetAttributesParams(TypedDict):
    nodeId: NodeId

class GetBoxModelParams(TypedDict, total=False):
    nodeId: NodeId
    backendNodeId: BackendNodeId
    objectId: RemoteObjectId

class GetContentQuadsParams(TypedDict, total=False):
    nodeId: NodeId
    backendNodeId: BackendNodeId
    objectId: RemoteObjectId

class GetDocumentParams(TypedDict, total=False):
    depth: int
    pierce: bool

class GetFlattenedDocumentParams(TypedDict, total=False):
    depth: int
    pierce: bool

class GetNodesForSubtreeByStyleParams(TypedDict, total=False):
    nodeId: NodeId
    computedStyles: list[CSSComputedStyleProperty]
    pierce: bool

class GetNodeForLocationParams(TypedDict, total=False):
    x: int
    y: int
    includeUserAgentShadowDOM: bool
    ignorePointerEventsNone: bool

class GetOuterHTMLParams(TypedDict, total=False):
    nodeId: NodeId
    backendNodeId: BackendNodeId
    objectId: RemoteObjectId
    includeShadowDOM: bool

class GetRelayoutBoundaryParams(TypedDict):
    nodeId: NodeId

class GetSearchResultsParams(TypedDict):
    searchId: str
    fromIndex: int
    toIndex: int

class MoveToParams(TypedDict, total=False):
    nodeId: NodeId
    targetNodeId: NodeId
    insertBeforeNodeId: NodeId

class PerformSearchParams(TypedDict, total=False):
    query: str
    includeUserAgentShadowDOM: bool

class PushNodeByPathToFrontendParams(TypedDict):
    path: str

class PushNodesByBackendIdsToFrontendParams(TypedDict):
    backendNodeIds: list[BackendNodeId]

class QuerySelectorParams(TypedDict):
    nodeId: NodeId
    selector: str

class QuerySelectorAllParams(TypedDict):
    nodeId: NodeId
    selector: str

class GetElementByRelationParams(TypedDict):
    nodeId: NodeId
    relation: RelationType

class RemoveAttributeParams(TypedDict):
    nodeId: NodeId
    name: str

class RemoveNodeParams(TypedDict):
    nodeId: NodeId

class RequestChildNodesParams(TypedDict, total=False):
    nodeId: NodeId
    depth: int
    pierce: bool

class RequestNodeParams(TypedDict):
    objectId: RemoteObjectId

class ResolveNodeParams(TypedDict, total=False):
    nodeId: NodeId
    backendNodeId: BackendNodeId
    objectGroup: str
    executionContextId: ExecutionContextId

class SetAttributeValueParams(TypedDict):
    nodeId: NodeId
    name: str
    value: str

class SetAttributesAsTextParams(TypedDict, total=False):
    nodeId: NodeId
    text: str
    name: str

class SetFileInputFilesParams(TypedDict, total=False):
    files: list[str]
    nodeId: NodeId
    backendNodeId: BackendNodeId
    objectId: RemoteObjectId

class SetNodeStackTracesEnabledParams(TypedDict):
    enable: bool

class GetNodeStackTracesParams(TypedDict):
    nodeId: NodeId

class GetFileInfoParams(TypedDict):
    objectId: RemoteObjectId

class SetInspectedNodeParams(TypedDict):
    nodeId: NodeId

class SetNodeNameParams(TypedDict):
    nodeId: NodeId
    name: str

class SetNodeValueParams(TypedDict):
    nodeId: NodeId
    value: str

class SetOuterHTMLParams(TypedDict):
    nodeId: NodeId
    outerHTML: str

class GetFrameOwnerParams(TypedDict):
    frameId: FrameId

class GetContainerForNodeParams(TypedDict, total=False):
    nodeId: NodeId
    containerName: str
    physicalAxes: PhysicalAxes
    logicalAxes: LogicalAxes
    queriesScrollState: bool
    queriesAnchored: bool

class GetQueryingDescendantsForContainerParams(TypedDict):
    nodeId: NodeId

class GetAnchorElementParams(TypedDict, total=False):
    nodeId: NodeId
    anchorSpecifier: str

class ForceShowPopoverParams(TypedDict):
    nodeId: NodeId
    enable: bool

class CollectClassNamesFromSubtreeResult(TypedDict):
    classNames: list[str]

class CopyToResult(TypedDict):
    nodeId: NodeId

class DescribeNodeResult(TypedDict):
    node: Node

class GetAttributesResult(TypedDict):
    attributes: list[str]

class GetBoxModelResult(TypedDict):
    model: BoxModel

class GetContentQuadsResult(TypedDict):
    quads: list[Quad]

class GetDocumentResult(TypedDict):
    root: Node

class GetFlattenedDocumentResult(TypedDict):
    nodes: list[Node]

class GetNodesForSubtreeByStyleResult(TypedDict):
    nodeIds: list[NodeId]

class GetNodeForLocationResult(TypedDict, total=False):
    backendNodeId: BackendNodeId
    frameId: FrameId
    nodeId: NodeId

class GetOuterHTMLResult(TypedDict):
    outerHTML: str

class GetRelayoutBoundaryResult(TypedDict):
    nodeId: NodeId

class GetSearchResultsResult(TypedDict):
    nodeIds: list[NodeId]

class GetTopLayerElementsResult(TypedDict):
    nodeIds: list[NodeId]

class GetElementByRelationResult(TypedDict):
    nodeId: NodeId

class MoveToResult(TypedDict):
    nodeId: NodeId

class PerformSearchResult(TypedDict):
    searchId: str
    resultCount: int

class PushNodeByPathToFrontendResult(TypedDict):
    nodeId: NodeId

class PushNodesByBackendIdsToFrontendResult(TypedDict):
    nodeIds: list[NodeId]

class QuerySelectorResult(TypedDict):
    nodeId: NodeId

class QuerySelectorAllResult(TypedDict):
    nodeIds: list[NodeId]

class RequestNodeResult(TypedDict):
    nodeId: NodeId

class ResolveNodeResult(TypedDict):
    object: RemoteObject

class SetNodeNameResult(TypedDict):
    nodeId: NodeId

class GetNodeStackTracesResult(TypedDict, total=False):
    creation: StackTrace

class GetFileInfoResult(TypedDict):
    path: str

class GetDetachedDomNodesResult(TypedDict):
    detachedNodes: list[DetachedElementInfo]

class GetFrameOwnerResult(TypedDict, total=False):
    backendNodeId: BackendNodeId
    nodeId: NodeId

class GetContainerForNodeResult(TypedDict, total=False):
    nodeId: NodeId

class GetQueryingDescendantsForContainerResult(TypedDict):
    nodeIds: list[NodeId]

class GetAnchorElementResult(TypedDict):
    nodeId: NodeId

class ForceShowPopoverResult(TypedDict):
    nodeIds: list[NodeId]
CollectClassNamesFromSubtreeResponse = CollectClassNamesFromSubtreeResult
CopyToResponse = CopyToResult
DescribeNodeResponse = DescribeNodeResult
GetAttributesResponse = GetAttributesResult
GetBoxModelResponse = GetBoxModelResult
GetContentQuadsResponse = GetContentQuadsResult
GetDocumentResponse = GetDocumentResult
GetFlattenedDocumentResponse = GetFlattenedDocumentResult
GetNodesForSubtreeByStyleResponse = GetNodesForSubtreeByStyleResult
GetNodeForLocationResponse = GetNodeForLocationResult
GetOuterHTMLResponse = GetOuterHTMLResult
GetRelayoutBoundaryResponse = GetRelayoutBoundaryResult
GetSearchResultsResponse = GetSearchResultsResult
GetTopLayerElementsResponse = GetTopLayerElementsResult
GetElementByRelationResponse = GetElementByRelationResult
MoveToResponse = MoveToResult
PerformSearchResponse = PerformSearchResult
PushNodeByPathToFrontendResponse = PushNodeByPathToFrontendResult
PushNodesByBackendIdsToFrontendResponse = PushNodesByBackendIdsToFrontendResult
QuerySelectorResponse = QuerySelectorResult
QuerySelectorAllResponse = QuerySelectorAllResult
RequestNodeResponse = RequestNodeResult
ResolveNodeResponse = ResolveNodeResult
SetNodeNameResponse = SetNodeNameResult
GetNodeStackTracesResponse = GetNodeStackTracesResult
GetFileInfoResponse = GetFileInfoResult
GetDetachedDomNodesResponse = GetDetachedDomNodesResult
GetFrameOwnerResponse = GetFrameOwnerResult
GetContainerForNodeResponse = GetContainerForNodeResult
GetQueryingDescendantsForContainerResponse = GetQueryingDescendantsForContainerResult
GetAnchorElementResponse = GetAnchorElementResult
ForceShowPopoverResponse = ForceShowPopoverResult
CollectClassNamesFromSubtreeCommand = Command[CollectClassNamesFromSubtreeParams, CollectClassNamesFromSubtreeResponse]
CopyToCommand = Command[CopyToParams, CopyToResponse]
DescribeNodeCommand = Command[DescribeNodeParams, DescribeNodeResponse]
DisableCommand = Command[EmptyParams, EmptyResponse]
DiscardSearchResultsCommand = Command[DiscardSearchResultsParams, EmptyResponse]
EnableCommand = Command[EnableParams, EmptyResponse]
FocusCommand = Command[FocusParams, EmptyResponse]
ForceShowPopoverCommand = Command[ForceShowPopoverParams, ForceShowPopoverResponse]
GetAnchorElementCommand = Command[GetAnchorElementParams, GetAnchorElementResponse]
GetAttributesCommand = Command[GetAttributesParams, GetAttributesResponse]
GetBoxModelCommand = Command[GetBoxModelParams, GetBoxModelResponse]
GetContainerForNodeCommand = Command[GetContainerForNodeParams, GetContainerForNodeResponse]
GetContentQuadsCommand = Command[GetContentQuadsParams, GetContentQuadsResponse]
GetDetachedDomNodesCommand = Command[EmptyParams, GetDetachedDomNodesResponse]
GetDocumentCommand = Command[GetDocumentParams, GetDocumentResponse]
GetElementByRelationCommand = Command[GetElementByRelationParams, GetElementByRelationResponse]
GetFileInfoCommand = Command[GetFileInfoParams, GetFileInfoResponse]
GetFlattenedDocumentCommand = Command[GetFlattenedDocumentParams, GetFlattenedDocumentResponse]
GetFrameOwnerCommand = Command[GetFrameOwnerParams, GetFrameOwnerResponse]
GetNodeForLocationCommand = Command[GetNodeForLocationParams, GetNodeForLocationResponse]
GetNodeStackTracesCommand = Command[GetNodeStackTracesParams, GetNodeStackTracesResponse]
GetNodesForSubtreeByStyleCommand = Command[GetNodesForSubtreeByStyleParams, GetNodesForSubtreeByStyleResponse]
GetOuterHTMLCommand = Command[GetOuterHTMLParams, GetOuterHTMLResponse]
GetQueryingDescendantsForContainerCommand = Command[GetQueryingDescendantsForContainerParams, GetQueryingDescendantsForContainerResponse]
GetRelayoutBoundaryCommand = Command[GetRelayoutBoundaryParams, GetRelayoutBoundaryResponse]
GetSearchResultsCommand = Command[GetSearchResultsParams, GetSearchResultsResponse]
GetTopLayerElementsCommand = Command[EmptyParams, GetTopLayerElementsResponse]
HideHighlightCommand = Command[EmptyParams, EmptyResponse]
HighlightNodeCommand = Command[EmptyParams, EmptyResponse]
HighlightRectCommand = Command[EmptyParams, EmptyResponse]
MarkUndoableStateCommand = Command[EmptyParams, EmptyResponse]
MoveToCommand = Command[MoveToParams, MoveToResponse]
PerformSearchCommand = Command[PerformSearchParams, PerformSearchResponse]
PushNodeByPathToFrontendCommand = Command[PushNodeByPathToFrontendParams, PushNodeByPathToFrontendResponse]
PushNodesByBackendIdsToFrontendCommand = Command[PushNodesByBackendIdsToFrontendParams, PushNodesByBackendIdsToFrontendResponse]
QuerySelectorCommand = Command[QuerySelectorParams, QuerySelectorResponse]
QuerySelectorAllCommand = Command[QuerySelectorAllParams, QuerySelectorAllResponse]
RedoCommand = Command[EmptyParams, EmptyResponse]
RemoveAttributeCommand = Command[RemoveAttributeParams, EmptyResponse]
RemoveNodeCommand = Command[RemoveNodeParams, EmptyResponse]
RequestChildNodesCommand = Command[RequestChildNodesParams, EmptyResponse]
RequestNodeCommand = Command[RequestNodeParams, RequestNodeResponse]
ResolveNodeCommand = Command[ResolveNodeParams, ResolveNodeResponse]
ScrollIntoViewIfNeededCommand = Command[ScrollIntoViewIfNeededParams, EmptyResponse]
SetAttributeValueCommand = Command[SetAttributeValueParams, EmptyResponse]
SetAttributesAsTextCommand = Command[SetAttributesAsTextParams, EmptyResponse]
SetFileInputFilesCommand = Command[SetFileInputFilesParams, EmptyResponse]
SetInspectedNodeCommand = Command[SetInspectedNodeParams, EmptyResponse]
SetNodeNameCommand = Command[SetNodeNameParams, SetNodeNameResponse]
SetNodeStackTracesEnabledCommand = Command[SetNodeStackTracesEnabledParams, EmptyResponse]
SetNodeValueCommand = Command[SetNodeValueParams, EmptyResponse]
SetOuterHTMLCommand = Command[SetOuterHTMLParams, EmptyResponse]
UndoCommand = Command[EmptyParams, EmptyResponse]
