from _typeshed import Incomplete
from enum import Enum
from typing import Any
from typing_extensions import TypedDict

NodeId = int
BackendNodeId = int
Quad: Incomplete

class PseudoType(str, Enum):
    FIRST_LINE = 'first-line'
    FIRST_LETTER = 'first-letter'
    CHECKMARK = 'checkmark'
    BEFORE = 'before'
    AFTER = 'after'
    PICKER_ICON = 'picker-icon'
    MARKER = 'marker'
    BACKDROP = 'backdrop'
    COLUMN = 'column'
    SELECTION = 'selection'
    SEARCH_TEXT = 'search-text'
    TARGET_TEXT = 'target-text'
    SPELLING_ERROR = 'spelling-error'
    GRAMMAR_ERROR = 'grammar-error'
    HIGHLIGHT = 'highlight'
    FIRST_LINE_INHERITED = 'first-line-inherited'
    SCROLL_MARKER = 'scroll-marker'
    SCROLL_MARKER_GROUP = 'scroll-marker-group'
    SCROLL_BUTTON = 'scroll-button'
    SCROLLBAR = 'scrollbar'
    SCROLLBAR_THUMB = 'scrollbar-thumb'
    SCROLLBAR_BUTTON = 'scrollbar-button'
    SCROLLBAR_TRACK = 'scrollbar-track'
    SCROLLBAR_TRACK_PIECE = 'scrollbar-track-piece'
    SCROLLBAR_CORNER = 'scrollbar-corner'
    RESIZER = 'resizer'
    INPUT_LIST_BUTTON = 'input-list-button'
    VIEW_TRANSITION = 'view-transition'
    VIEW_TRANSITION_GROUP = 'view-transition-group'
    VIEW_TRANSITION_IMAGE_PAIR = 'view-transition-image-pair'
    VIEW_TRANSITION_GROUP_CHILDREN = 'view-transition-group-children'
    VIEW_TRANSITION_OLD = 'view-transition-old'
    VIEW_TRANSITION_NEW = 'view-transition-new'
    PLACEHOLDER = 'placeholder'
    FILE_SELECTOR_BUTTON = 'file-selector-button'
    DETAILS_CONTENT = 'details-content'
    PICKER = 'picker'
    PERMISSION_ICON = 'permission-icon'

class ShadowRootType(str, Enum):
    USER_AGENT = 'user-agent'
    OPEN = 'open'
    CLOSED = 'closed'

class CompatibilityMode(str, Enum):
    QUIRKS_MODE = 'QuirksMode'
    LIMITED_QUIRKS_MODE = 'LimitedQuirksMode'
    NO_QUIRKS_MODE = 'NoQuirksMode'

class PhysicalAxes(str, Enum):
    HORIZONTAL = 'Horizontal'
    VERTICAL = 'Vertical'
    BOTH = 'Both'

class LogicalAxes(str, Enum):
    INLINE = 'Inline'
    BLOCK = 'Block'
    BOTH = 'Both'

class ScrollOrientation(str, Enum):
    HORIZONTAL = 'horizontal'
    VERTICAL = 'vertical'

class IncludeWhitespace(str, Enum):
    NONE = 'none'
    ALL = 'all'

class RelationType(str, Enum):
    POPOVER_TARGET = 'PopoverTarget'
    INTEREST_TARGET = 'InterestTarget'
    COMMAND_FOR = 'CommandFor'

class BackendNode(TypedDict):
    nodeType: int
    nodeName: str
    backendNodeId: BackendNodeId

class Node(TypedDict, total=False):
    nodeId: NodeId
    parentId: NodeId
    backendNodeId: BackendNodeId
    nodeType: int
    nodeName: str
    localName: str
    nodeValue: str
    childNodeCount: int
    children: list['Node']
    attributes: list[str]
    documentURL: str
    baseURL: str
    publicId: str
    systemId: str
    internalSubset: str
    xmlVersion: str
    name: str
    value: str
    pseudoType: PseudoType
    pseudoIdentifier: str
    shadowRootType: ShadowRootType
    frameId: str
    contentDocument: Node
    shadowRoots: list['Node']
    templateContent: Node
    pseudoElements: list['Node']
    importedDocument: Node
    distributedNodes: list[BackendNode]
    isSVG: bool
    compatibilityMode: CompatibilityMode
    assignedSlot: BackendNode
    isScrollable: bool

class DetachedElementInfo(TypedDict):
    treeNode: Node
    retainedNodeIds: list[NodeId]

class RGBA(TypedDict, total=False):
    r: int
    g: int
    b: int
    a: float

class BoxModel(TypedDict, total=False):
    content: Quad
    padding: Quad
    border: Quad
    margin: Quad
    width: int
    height: int
    shapeOutside: ShapeOutsideInfo

class ShapeOutsideInfo(TypedDict):
    bounds: Quad
    shape: list[Any]
    marginShape: list[Any]

class Rect(TypedDict):
    x: float
    y: float
    width: float
    height: float

class CSSComputedStyleProperty(TypedDict):
    name: str
    value: str
