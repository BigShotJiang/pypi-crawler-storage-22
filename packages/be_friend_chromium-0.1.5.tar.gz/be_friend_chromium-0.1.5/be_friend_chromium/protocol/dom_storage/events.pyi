from be_friend_chromium.protocol.base import CDPEvent as CDPEvent
from be_friend_chromium.protocol.dom_storage.types import StorageId as StorageId
from enum import Enum
from typing_extensions import TypedDict

class DomStorageEvent(str, Enum):
    DOM_STORAGE_ITEM_ADDED = 'DOMStorage.domStorageItemAdded'
    DOM_STORAGE_ITEM_REMOVED = 'DOMStorage.domStorageItemRemoved'
    DOM_STORAGE_ITEM_UPDATED = 'DOMStorage.domStorageItemUpdated'
    DOM_STORAGE_ITEMS_CLEARED = 'DOMStorage.domStorageItemsCleared'

class DomStorageItemAddedEventParams(TypedDict):
    storageId: StorageId
    key: str
    newValue: str

class DomStorageItemRemovedEventParams(TypedDict):
    storageId: StorageId
    key: str

class DomStorageItemUpdatedEventParams(TypedDict):
    storageId: StorageId
    key: str
    oldValue: str
    newValue: str

class DomStorageItemsClearedEventParams(TypedDict):
    storageId: StorageId
DomStorageItemAddedEvent = CDPEvent[DomStorageItemAddedEventParams]
DomStorageItemRemovedEvent = CDPEvent[DomStorageItemRemovedEventParams]
DomStorageItemUpdatedEvent = CDPEvent[DomStorageItemUpdatedEventParams]
DomStorageItemsClearedEvent = CDPEvent[DomStorageItemsClearedEventParams]
