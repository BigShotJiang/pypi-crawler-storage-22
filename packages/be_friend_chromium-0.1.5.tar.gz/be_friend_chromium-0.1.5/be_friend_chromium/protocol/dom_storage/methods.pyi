from be_friend_chromium.protocol.base import Command as Command, EmptyParams as EmptyParams, EmptyResponse as EmptyResponse
from be_friend_chromium.protocol.dom_storage.types import Item as Item, StorageId as StorageId
from enum import Enum
from typing_extensions import TypedDict

class DomStorageMethod(str, Enum):
    CLEAR = 'DOMStorage.clear'
    DISABLE = 'DOMStorage.disable'
    ENABLE = 'DOMStorage.enable'
    GET_DOM_STORAGE_ITEMS = 'DOMStorage.getDOMStorageItems'
    REMOVE_DOM_STORAGE_ITEM = 'DOMStorage.removeDOMStorageItem'
    SET_DOM_STORAGE_ITEM = 'DOMStorage.setDOMStorageItem'

class ClearParams(TypedDict):
    storageId: StorageId

class GetDOMStorageItemsParams(TypedDict):
    storageId: StorageId

class RemoveDOMStorageItemParams(TypedDict):
    storageId: StorageId
    key: str

class SetDOMStorageItemParams(TypedDict):
    storageId: StorageId
    key: str
    value: str

class GetDOMStorageItemsResult(TypedDict):
    entries: list[Item]
GetDOMStorageItemsResponse = GetDOMStorageItemsResult
ClearCommand = Command[ClearParams, EmptyResponse]
DisableCommand = Command[EmptyParams, EmptyResponse]
EnableCommand = Command[EmptyParams, EmptyResponse]
GetDOMStorageItemsCommand = Command[GetDOMStorageItemsParams, GetDOMStorageItemsResponse]
RemoveDOMStorageItemCommand = Command[RemoveDOMStorageItemParams, EmptyResponse]
SetDOMStorageItemCommand = Command[SetDOMStorageItemParams, EmptyResponse]
