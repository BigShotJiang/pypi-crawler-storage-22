from _typeshed import Incomplete
from typing_extensions import TypedDict

Item: Incomplete

class StorageId(TypedDict, total=False):
    securityOrigin: str
    isLocalStorage: bool
    storageKey: str
