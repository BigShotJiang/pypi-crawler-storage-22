from be_friend_chromium.protocol.base import CDPEvent as CDPEvent
from be_friend_chromium.protocol.fetch.types import AuthChallenge as AuthChallenge
from be_friend_chromium.protocol.network.types import ErrorReason as ErrorReason, Request as Request, ResourceType as ResourceType
from enum import Enum
from typing_extensions import TypedDict

class FetchEvent(str, Enum):
    AUTH_REQUIRED = 'Fetch.authRequired'
    REQUEST_PAUSED = 'Fetch.requestPaused'

class AuthRequiredEventParams(TypedDict):
    requestId: str
    request: Request
    frameId: str
    resourceType: ResourceType
    authChallenge: AuthChallenge

class RequestPausedEventParams(TypedDict):
    requestId: str
    request: Request
    frameId: str
    resourceType: ResourceType
    responseErrorReason: ErrorReason
    responseStatusCode: int
    responseStatusText: str
RequestPausedEvent = CDPEvent[RequestPausedEventParams]
AuthRequiredEvent = CDPEvent[AuthRequiredEventParams]
