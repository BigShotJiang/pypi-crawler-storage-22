from be_friend_chromium.protocol.base import Command as Command, EmptyParams as EmptyParams, EmptyResponse as EmptyResponse
from be_friend_chromium.protocol.fetch.types import AuthChallengeResponse as AuthChallengeResponse, HeaderEntry as HeaderEntry, RequestPattern as RequestPattern
from be_friend_chromium.protocol.io.types import StreamHandle as StreamHandle
from be_friend_chromium.protocol.network.types import ErrorReason as ErrorReason
from enum import Enum
from typing_extensions import TypedDict

class FetchMethod(str, Enum):
    CONTINUE_REQUEST = 'Fetch.continueRequest'
    CONTINUE_RESPONSE = 'Fetch.continueResponse'
    CONTINUE_WITH_AUTH = 'Fetch.continueWithAuth'
    DISABLE = 'Fetch.disable'
    ENABLE = 'Fetch.enable'
    FAIL_REQUEST = 'Fetch.failRequest'
    FULFILL_REQUEST = 'Fetch.fulfillRequest'
    GET_RESPONSE_BODY = 'Fetch.getResponseBody'
    TAKE_RESPONSE_BODY_AS_STREAM = 'Fetch.takeResponseBodyAsStream'
RequestId = str

class EnableParams(TypedDict, total=False):
    patterns: list[RequestPattern]
    handleAuthRequests: bool

class FailRequestParams(TypedDict):
    requestId: RequestId
    errorReason: ErrorReason

class FulfillRequestParams(TypedDict, total=False):
    requestId: RequestId
    responseCode: int
    responseHeaders: list[HeaderEntry]
    binaryResponseHeaders: str
    body: str
    responsePhrase: str

class ContinueRequestParams(TypedDict, total=False):
    requestId: RequestId
    url: str
    method: str
    postData: str
    headers: list[HeaderEntry]
    interceptResponse: bool

class ContinueWithAuthParams(TypedDict):
    requestId: RequestId
    authChallengeResponse: AuthChallengeResponse

class ContinueResponseParams(TypedDict, total=False):
    requestId: RequestId
    responseCode: int
    responsePhrase: str
    responseHeaders: list[HeaderEntry]
    binaryResponseHeaders: str

class GetResponseBodyParams(TypedDict):
    requestId: RequestId

class TakeResponseBodyAsStreamParams(TypedDict):
    requestId: RequestId

class GetResponseBodyResult(TypedDict):
    body: str
    base64Encoded: bool

class TakeResponseBodyAsStreamResult(TypedDict):
    stream: StreamHandle
GetResponseBodyResponse = GetResponseBodyResult
TakeResponseBodyAsStreamResponse = TakeResponseBodyAsStreamResult
ContinueRequestCommand = Command[ContinueRequestParams, EmptyResponse]
ContinueResponseCommand = Command[ContinueResponseParams, EmptyResponse]
ContinueWithAuthCommand = Command[ContinueWithAuthParams, EmptyResponse]
DisableCommand = Command[EmptyParams, EmptyResponse]
EnableCommand = Command[EnableParams, EmptyResponse]
FailRequestCommand = Command[FailRequestParams, EmptyResponse]
FulfillRequestCommand = Command[FulfillRequestParams, EmptyResponse]
GetResponseBodyCommand = Command[GetResponseBodyParams, GetResponseBodyResponse]
TakeResponseBodyAsStreamCommand = Command[TakeResponseBodyAsStreamParams, TakeResponseBodyAsStreamResponse]
