from be_friend_chromium.protocol.network.types import ResourceType as ResourceType
from enum import Enum
from typing_extensions import NotRequired, TypedDict

class RequestStage(str, Enum):
    REQUEST = 'Request'
    RESPONSE = 'Response'

class AuthChallengeSource(str, Enum):
    SERVER = 'Server'
    PROXY = 'Proxy'

class AuthChallengeResponseType(str, Enum):
    DEFAULT = 'Default'
    CANCEL_AUTH = 'CancelAuth'
    PROVIDE_CREDENTIALS = 'ProvideCredentials'

class RequestPattern(TypedDict, total=False):
    urlPattern: str
    resourceType: ResourceType
    requestStage: RequestStage

class HeaderEntry(TypedDict):
    name: str
    value: str

class AuthChallenge(TypedDict):
    source: NotRequired[AuthChallengeSource]
    origin: str
    scheme: str
    realm: str

class AuthChallengeResponse(TypedDict):
    response: AuthChallengeResponseType
    username: NotRequired[str]
    password: NotRequired[str]
