from be_friend_chromium.protocol.base import CDPEvent as CDPEvent
from be_friend_chromium.protocol.input.types import DragData as DragData
from enum import Enum
from typing_extensions import TypedDict

class InputEvent(str, Enum):
    DRAG_INTERCEPTED = 'Input.dragIntercepted'

class DragInterceptedEventParams(TypedDict):
    data: DragData
DragInterceptedEvent = CDPEvent[DragInterceptedEventParams]
