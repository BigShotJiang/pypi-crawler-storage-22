from be_friend_chromium.protocol.base import CDPEvent as CDPEvent
from enum import Enum
from typing_extensions import TypedDict

class InspectorEvent(str, Enum):
    DETACHED = 'Inspector.detached'
    TARGET_CRASHED = 'Inspector.targetCrashed'
    TARGET_RELOADED_AFTER_CRASH = 'Inspector.targetReloadedAfterCrash'
    WORK_SCRIPT_LOADED = 'Inspector.workScriptLoaded'

class DetachedEventParams(TypedDict):
    reason: str

class TargetCrashedEventParams(TypedDict): ...
class TargetReloadedAfterCrashedEventParams(TypedDict): ...
class WorkScriptLoadedEventParams(TypedDict): ...
DetachedEvent = CDPEvent[DetachedEventParams]
TargetCrashedEvent = CDPEvent[TargetCrashedEventParams]
TargetReloadedAfterCrashedEvent = CDPEvent[TargetReloadedAfterCrashedEventParams]
WorkScriptLoadedEvent = CDPEvent[WorkScriptLoadedEventParams]
