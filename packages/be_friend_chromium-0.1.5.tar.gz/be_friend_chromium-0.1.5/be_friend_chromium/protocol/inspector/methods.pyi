from be_friend_chromium.protocol.base import Command as Command, EmptyParams as EmptyParams, EmptyResponse as EmptyResponse
from enum import Enum

class InspectorMethod(str, Enum):
    DISABLE = 'Inspector.disable'
    ENABLE = 'Inspector.enable'
EnableCommand = Command[EmptyParams, EmptyResponse]
DisableCommand = Command[EmptyParams, EmptyResponse]
