from be_friend_chromium.protocol.base import Command as Command, EmptyParams as EmptyParams, EmptyResponse as EmptyResponse
from be_friend_chromium.protocol.debugger.types import SearchMatch as SearchMatch
from be_friend_chromium.protocol.emulation.types import UserAgentMetadata as UserAgentMetadata
from be_friend_chromium.protocol.fetch.types import HeaderEntry as HeaderEntry, RequestPattern as RequestPattern
from be_friend_chromium.protocol.network.types import ConnectionType as ConnectionType, ContentEncoding as ContentEncoding, Cookie as Cookie, CookiePartitionKey as CookiePartitionKey, CookiePriority as CookiePriority, CookieSameSite as CookieSameSite, CookieSourceScheme as CookieSourceScheme, LoadNetworkResourceOptions as LoadNetworkResourceOptions, SecurityIsolationStatus as SecurityIsolationStatus
from enum import Enum
from typing_extensions import NotRequired, TypedDict

class NetworkMethod(str, Enum):
    CLEAR_BROWSER_CACHE = 'Network.clearBrowserCache'
    CLEAR_BROWSER_COOKIES = 'Network.clearBrowserCookies'
    DELETE_COOKIES = 'Network.deleteCookies'
    GET_COOKIES = 'Network.getCookies'
    SET_COOKIE = 'Network.setCookie'
    SET_COOKIES = 'Network.setCookies'
    SET_COOKIE_CONTROLS = 'Network.setCookieControls'
    ENABLE = 'Network.enable'
    DISABLE = 'Network.disable'
    EMULATE_NETWORK_CONDITIONS = 'Network.emulateNetworkConditions'
    SET_CACHE_DISABLED = 'Network.setCacheDisabled'
    SET_BYPASS_SERVICE_WORKER = 'Network.setBypassServiceWorker'
    GET_REQUEST_POST_DATA = 'Network.getRequestPostData'
    GET_RESPONSE_BODY = 'Network.getResponseBody'
    GET_RESPONSE_BODY_FOR_INTERCEPTION = 'Network.getResponseBodyForInterception'
    SEARCH_IN_RESPONSE_BODY = 'Network.searchInResponseBody'
    STREAM_RESOURCE_CONTENT = 'Network.streamResourceContent'
    TAKE_RESPONSE_BODY_FOR_INTERCEPTION_AS_STREAM = 'Network.takeResponseBodyForInterceptionAsStream'
    SET_EXTRA_HTTP_HEADERS = 'Network.setExtraHTTPHeaders'
    SET_USER_AGENT_OVERRIDE = 'Network.setUserAgentOverride'
    SET_ACCEPTED_ENCODINGS = 'Network.setAcceptedEncodings'
    CLEAR_ACCEPTED_ENCODINGS_OVERRIDE = 'Network.clearAcceptedEncodingsOverride'
    SET_BLOCKED_URLS = 'Network.setBlockedURLs'
    ENABLE_REPORTING_API = 'Network.enableReportingApi'
    GET_CERTIFICATE = 'Network.getCertificate'
    GET_SECURITY_ISOLATION_STATUS = 'Network.getSecurityIsolationStatus'
    LOAD_NETWORK_RESOURCE = 'Network.loadNetworkResource'
    REPLAY_XHR = 'Network.replayXHR'
    SET_ATTACH_DEBUG_STACK = 'Network.setAttachDebugStack'

class DeleteCookiesParams(TypedDict):
    name: str
    url: NotRequired[str]
    domain: NotRequired[str]
    path: NotRequired[str]
    partitionKey: NotRequired[CookiePartitionKey]

class EmulateNetworkConditionsParams(TypedDict):
    offline: bool
    latency: float
    downloadThroughput: float
    uploadThroughput: float
    connectionType: NotRequired[ConnectionType]
    packetLoss: NotRequired[float]
    packetQueueLength: NotRequired[int]
    packetReordering: NotRequired[bool]

class NetworkEnableParams(TypedDict):
    maxTotalBufferSize: NotRequired[int]
    maxResourceBufferSize: NotRequired[int]
    maxPostDataSize: NotRequired[int]

class GetCookiesParams(TypedDict):
    urls: NotRequired[list[str]]

class GetRequestPostDataParams(TypedDict):
    requestId: str

class GetResponseBodyParams(TypedDict):
    requestId: str

class GetCertificateParams(TypedDict):
    origin: str

class GetResponseBodyForInterceptionParams(TypedDict):
    interceptionId: str

class SearchInResponseBodyParams(TypedDict):
    requestId: str
    query: str
    caseSensitive: NotRequired[bool]
    isRegex: NotRequired[bool]

class SetBypassServiceWorkerParams(TypedDict):
    bypass: bool

class SetCacheDisabledParams(TypedDict):
    cacheDisabled: bool

class SetCookieParams(TypedDict):
    name: str
    value: str
    url: NotRequired[str]
    domain: NotRequired[str]
    path: NotRequired[str]
    secure: NotRequired[bool]
    httpOnly: NotRequired[bool]
    sameSite: NotRequired[CookieSameSite]
    expires: NotRequired[float]
    priority: NotRequired[CookiePriority]
    sameParty: NotRequired[bool]
    sourceScheme: NotRequired[CookieSourceScheme]
    sourcePort: NotRequired[int]
    partitionKey: NotRequired[CookiePartitionKey]

class SetCookiesParams(TypedDict):
    cookies: list[SetCookieParams]

class SetExtraHTTPHeadersParams(TypedDict):
    headers: list[HeaderEntry]

class SetUserAgentOverrideParams(TypedDict):
    userAgent: str
    acceptLanguage: NotRequired[str]
    platform: NotRequired[str]
    userAgentMetadata: NotRequired[UserAgentMetadata]

class SetBlockedURLsParams(TypedDict):
    urls: list[str]

class SetAcceptedEncodingsParams(TypedDict):
    encodings: list[ContentEncoding]

class SetAttachDebugStackParams(TypedDict):
    enabled: bool

class SetCookieControlsParams(TypedDict):
    enableThirdPartyCookieRestriction: bool
    disableThirdPartyCookieMetadata: NotRequired[bool]
    disableThirdPartyCookieHeuristics: NotRequired[bool]

class StreamResourceContentParams(TypedDict):
    requestId: str

class TakeResponseBodyForInterceptionAsStreamParams(TypedDict):
    interceptionId: str

class SetRequestInterceptionParams(TypedDict):
    patterns: list[RequestPattern]

class AuthChallengeResponseParams(TypedDict):
    response: str
    username: NotRequired[str]
    password: NotRequired[str]

class EnableReportingApiParams(TypedDict):
    enabled: bool

class GetSecurityIsolationStatusParams(TypedDict):
    frameId: NotRequired[str]

class LoadNetworkResourceParams(TypedDict):
    url: str
    options: LoadNetworkResourceOptions
    frameId: NotRequired[str]

class ReplayXHRParams(TypedDict):
    requestId: str

class GetCookiesResult(TypedDict):
    cookies: list[Cookie]

class GetRequestPostDataResult(TypedDict):
    postData: str

class GetResponseBodyResult(TypedDict):
    body: str
    base64Encoded: bool

class GetResponseBodyForInterceptionResult(TypedDict):
    body: str
    base64Encoded: bool

class GetCertificateResult(TypedDict):
    tableNames: list[str]

class SearchInResponseBodyResult(TypedDict):
    result: list[SearchMatch]

class SetCookieResult(TypedDict):
    success: bool

class StreamResourceContentResult(TypedDict):
    bufferedData: str

class TakeResponseBodyForInterceptionAsStreamResult(TypedDict):
    stream: str

class CanClearBrowserCacheResult(TypedDict):
    result: bool

class CanClearBrowserCookiesResult(TypedDict):
    result: bool

class CanEmulateNetworkConditionsResult(TypedDict):
    result: bool

class GetSecurityIsolationStatusResult(TypedDict):
    status: SecurityIsolationStatus

class LoadNetworkResourceResult(TypedDict):
    success: bool
    netError: NotRequired[float]
    netErrorName: NotRequired[str]
    httpStatusCode: NotRequired[float]
    stream: NotRequired[str]
    headers: NotRequired[list[HeaderEntry]]
GetCookiesResponse = GetCookiesResult
SetCookieResponse = SetCookieResult
GetRequestPostDataResponse = GetRequestPostDataResult
GetResponseBodyResponse = GetResponseBodyResult
GetResponseBodyForInterceptionResponse = GetResponseBodyForInterceptionResult
SearchInResponseBodyResponse = SearchInResponseBodyResult
StreamResourceContentResponse = StreamResourceContentResult
TakeResponseBodyForInterceptionAsStreamResponse = TakeResponseBodyForInterceptionAsStreamResult
GetCertificateResponse = GetCertificateResult
CanClearBrowserCacheResponse = CanClearBrowserCacheResult
CanClearBrowserCookiesResponse = CanClearBrowserCookiesResult
CanEmulateNetworkConditionsResponse = CanEmulateNetworkConditionsResult
GetSecurityIsolationStatusResponse = GetSecurityIsolationStatusResult
LoadNetworkResourceResponse = LoadNetworkResourceResult
ClearBrowserCacheCommand = Command[EmptyParams, EmptyResponse]
ClearBrowserCookiesCommand = Command[EmptyParams, EmptyResponse]
ClearCookiesCommand = Command[DeleteCookiesParams, EmptyResponse]
GetCookiesCommand = Command[GetCookiesParams, GetCookiesResponse]
SetCookieCommand = Command[SetCookieParams, SetCookieResponse]
SetCookiesCommand = Command[SetCookiesParams, EmptyResponse]
EnableCommand = Command[NetworkEnableParams, EmptyResponse]
DisableCommand = Command[EmptyParams, EmptyResponse]
EmulateNetworkConditionsCommand = Command[EmulateNetworkConditionsParams, EmptyResponse]
SetCacheDisabledCommand = Command[SetCacheDisabledParams, EmptyResponse]
SetBypassServiceWorkerCommand = Command[SetBypassServiceWorkerParams, EmptyResponse]
GetRequestPostDataCommand = Command[GetRequestPostDataParams, GetRequestPostDataResponse]
GetResponseBodyCommand = Command[GetResponseBodyParams, GetResponseBodyResponse]
GetResponseBodyForInterceptionCommand = Command[GetResponseBodyForInterceptionParams, GetResponseBodyForInterceptionResponse]
SearchInResponseBodyCommand = Command[SearchInResponseBodyParams, SearchInResponseBodyResponse]
StreamResourceContentCommand = Command[StreamResourceContentParams, StreamResourceContentResponse]
TakeResponseBodyForInterceptionAsStreamCommand = Command[TakeResponseBodyForInterceptionAsStreamParams, TakeResponseBodyForInterceptionAsStreamResponse]
SetExtraHTTPHeadersCommand = Command[SetExtraHTTPHeadersParams, EmptyResponse]
SetUserAgentOverrideCommand = Command[SetUserAgentOverrideParams, EmptyResponse]
SetAcceptedEncodingsCommand = Command[SetAcceptedEncodingsParams, EmptyResponse]
ClearAcceptedEncodingsOverrideCommand = Command[EmptyParams, EmptyResponse]
SetBlockedURLsCommand = Command[SetBlockedURLsParams, EmptyResponse]
EnableReportingApiCommand = Command[EnableReportingApiParams, EmptyResponse]
GetCertificateCommand = Command[GetCertificateParams, GetCertificateResponse]
SetAttachDebugStackCommand = Command[SetAttachDebugStackParams, EmptyResponse]
SetCookieControlsCommand = Command[SetCookieControlsParams, EmptyResponse]
GetSecurityIsolationStatusCommand = Command[GetSecurityIsolationStatusParams, GetSecurityIsolationStatusResponse]
LoadNetworkResourceCommand = Command[LoadNetworkResourceParams, LoadNetworkResourceResponse]
ReplayXHRCommand = Command[ReplayXHRParams, EmptyResponse]
