from be_friend_chromium.protocol.base import CDPEvent as CDPEvent
from be_friend_chromium.protocol.dom.types import BackendNodeId as BackendNodeId
from be_friend_chromium.protocol.network.types import LoaderId as LoaderId, MonotonicTime as MonotonicTime
from be_friend_chromium.protocol.page.types import BackForwardCacheNotRestoredExplanation as BackForwardCacheNotRestoredExplanation, BackForwardCacheNotRestoredExplanationTree as BackForwardCacheNotRestoredExplanationTree, ClientNavigationDisposition as ClientNavigationDisposition, ClientNavigationReason as ClientNavigationReason, DialogType as DialogType, Frame as Frame, FrameId as FrameId, NavigationType as NavigationType, ScreencastFrameMetadata as ScreencastFrameMetadata
from be_friend_chromium.protocol.runtime.types import StackTrace as StackTrace
from enum import Enum
from typing_extensions import NotRequired, TypedDict

class PageEvent(str, Enum):
    DOM_CONTENT_EVENT_FIRED = 'Page.domContentEventFired'
    FILE_CHOOSER_OPENED = 'Page.fileChooserOpened'
    FRAME_ATTACHED = 'Page.frameAttached'
    FRAME_DETACHED = 'Page.frameDetached'
    FRAME_NAVIGATED = 'Page.frameNavigated'
    INTERSTITIAL_HIDDEN = 'Page.interstitialHidden'
    INTERSTITIAL_SHOWN = 'Page.interstitialShown'
    JAVASCRIPT_DIALOG_CLOSED = 'Page.javascriptDialogClosed'
    JAVASCRIPT_DIALOG_OPENING = 'Page.javascriptDialogOpening'
    LIFECYCLE_EVENT = 'Page.lifecycleEvent'
    LOAD_EVENT_FIRED = 'Page.loadEventFired'
    WINDOW_OPEN = 'Page.windowOpen'
    BACK_FORWARD_CACHE_NOT_USED = 'Page.backForwardCacheNotUsed'
    COMPILATION_CACHE_PRODUCED = 'Page.compilationCacheProduced'
    DOCUMENT_OPENED = 'Page.documentOpened'
    FRAME_REQUESTED_NAVIGATION = 'Page.frameRequestedNavigation'
    FRAME_RESIZED = 'Page.frameResized'
    FRAME_STARTED_LOADING = 'Page.frameStartedLoading'
    FRAME_STARTED_NAVIGATING = 'Page.frameStartedNavigating'
    FRAME_STOPPED_LOADING = 'Page.frameStoppedLoading'
    FRAME_SUBTREE_WILL_BE_DETACHED = 'Page.frameSubtreeWillBeDetached'
    NAVIGATED_WITHIN_DOCUMENT = 'Page.navigatedWithinDocument'
    SCREENCAST_FRAME = 'Page.screencastFrame'
    SCREENCAST_VISIBILITY_CHANGED = 'Page.screencastVisibilityChanged'
    DOWNLOAD_WILL_BEGIN = 'Page.downloadWillBegin'
    DOWNLOAD_PROGRESS = 'Page.downloadProgress'

class DomContentEventFiredEventParams(TypedDict):
    timestamp: MonotonicTime

class FileChooserOpenedEventParams(TypedDict):
    frameId: FrameId
    mode: str
    backendNodeId: NotRequired[BackendNodeId]

class FrameAttachedEventParams(TypedDict):
    frameId: FrameId
    parentFrameId: FrameId
    stack: NotRequired[StackTrace]

class FrameClearedScheduledNavigationEventParams(TypedDict):
    frameId: FrameId

class FrameDetachedEventParams(TypedDict):
    frameId: FrameId
    reason: str

class FrameSubtreeWillBeDetachedEventParams(TypedDict):
    frameId: FrameId

class FrameNavigatedEventParams(TypedDict):
    frame: Frame
    type: NavigationType

class DocumentOpenedEventParams(TypedDict):
    frame: Frame

class FrameResizedEventParams(TypedDict): ...

class FrameStartedNavigatingEventParams(TypedDict):
    frameId: FrameId
    url: str
    loaderId: LoaderId
    navigationType: str

class FrameRequestedNavigationEventParams(TypedDict):
    frameId: FrameId
    reason: ClientNavigationReason
    url: str
    disposition: ClientNavigationDisposition

class FrameScheduledNavigationEventParams(TypedDict):
    frameId: FrameId
    delay: float
    reason: ClientNavigationReason
    url: str

class FrameStartedLoadingEventParams(TypedDict):
    frameId: FrameId

class FrameStoppedLoadingEventParams(TypedDict):
    frameId: FrameId

class DownloadWillBeginEventParams(TypedDict):
    frameId: FrameId
    guid: str
    url: str
    suggestedFilename: str

class DownloadProgressEventParams(TypedDict):
    guid: str
    totalBytes: float
    receivedBytes: float
    state: str

class InterstitialHiddenEventParams(TypedDict): ...
class InterstitialShownEventParams(TypedDict): ...

class JavascriptDialogClosedEventParams(TypedDict):
    frameId: FrameId
    result: bool
    userInput: str

class JavascriptDialogOpeningEventParams(TypedDict):
    url: str
    frameId: FrameId
    message: str
    type: DialogType
    hasBrowserHandler: bool
    defaultPrompt: NotRequired[str]

class LifecycleEventEventParams(TypedDict):
    frameId: FrameId
    loaderId: LoaderId
    name: str
    timestamp: MonotonicTime

class BackForwardCacheNotUsedEventParams(TypedDict):
    loaderId: LoaderId
    frameId: FrameId
    notRestoredExplanations: list[BackForwardCacheNotRestoredExplanation]
    notRestoredExplanationsTree: NotRequired[BackForwardCacheNotRestoredExplanationTree]

class LoadEventFiredEventParams(TypedDict):
    timestamp: MonotonicTime

class NavigatedWithinDocumentEventParams(TypedDict):
    frameId: FrameId
    url: str
    navigationType: str

class ScreencastFrameEventParams(TypedDict):
    data: str
    metadata: ScreencastFrameMetadata
    sessionId: int

class ScreencastVisibilityChangedEventParams(TypedDict):
    visible: bool

class WindowOpenEventParams(TypedDict):
    url: str
    windowName: str
    windowFeatures: list[str]
    userGesture: bool

class CompilationCacheProducedEventParams(TypedDict):
    url: str
    data: str
DomContentEventFiredEvent = CDPEvent[DomContentEventFiredEventParams]
FileChooserOpenedEvent = CDPEvent[FileChooserOpenedEventParams]
FrameAttachedEvent = CDPEvent[FrameAttachedEventParams]
FrameClearedScheduledNavigationEvent = CDPEvent[FrameClearedScheduledNavigationEventParams]
FrameDetachedEvent = CDPEvent[FrameDetachedEventParams]
FrameSubtreeWillBeDetachedEvent = CDPEvent[FrameSubtreeWillBeDetachedEventParams]
FrameNavigatedEvent = CDPEvent[FrameNavigatedEventParams]
DocumentOpenedEvent = CDPEvent[DocumentOpenedEventParams]
FrameResizedEvent = CDPEvent[FrameResizedEventParams]
FrameStartedNavigatingEvent = CDPEvent[FrameStartedNavigatingEventParams]
FrameRequestedNavigationEvent = CDPEvent[FrameRequestedNavigationEventParams]
FrameScheduledNavigationEvent = CDPEvent[FrameScheduledNavigationEventParams]
FrameStartedLoadingEvent = CDPEvent[FrameStartedLoadingEventParams]
FrameStoppedLoadingEvent = CDPEvent[FrameStoppedLoadingEventParams]
DownloadWillBeginEvent = CDPEvent[DownloadWillBeginEventParams]
DownloadProgressEvent = CDPEvent[DownloadProgressEventParams]
InterstitialHiddenEvent = CDPEvent[InterstitialHiddenEventParams]
InterstitialShownEvent = CDPEvent[InterstitialShownEventParams]
JavascriptDialogClosedEvent = CDPEvent[JavascriptDialogClosedEventParams]
JavascriptDialogOpeningEvent = CDPEvent[JavascriptDialogOpeningEventParams]
LifecycleEventEvent = CDPEvent[LifecycleEventEventParams]
BackForwardCacheNotUsedEvent = CDPEvent[BackForwardCacheNotUsedEventParams]
LoadEventFiredEvent = CDPEvent[LoadEventFiredEventParams]
NavigatedWithinDocumentEvent = CDPEvent[NavigatedWithinDocumentEventParams]
ScreencastFrameEvent = CDPEvent[ScreencastFrameEventParams]
ScreencastVisibilityChangedEvent = CDPEvent[ScreencastVisibilityChangedEventParams]
WindowOpenEvent = CDPEvent[WindowOpenEventParams]
CompilationCacheProducedEvent = CDPEvent[CompilationCacheProducedEventParams]
