from be_friend_chromium.protocol.base import Command as Command, EmptyParams as EmptyParams, EmptyResponse as EmptyResponse
from be_friend_chromium.protocol.debugger.types import SearchMatch as SearchMatch
from be_friend_chromium.protocol.dom.types import Rect as Rect
from be_friend_chromium.protocol.io.types import StreamHandle as StreamHandle
from be_friend_chromium.protocol.network.types import LoaderId as LoaderId
from be_friend_chromium.protocol.page.types import AdScriptAncestry as AdScriptAncestry, AppManifestError as AppManifestError, AppManifestParsedProperties as AppManifestParsedProperties, AutoResponseMode as AutoResponseMode, CompilationCacheParams as CompilationCacheParams, FontFamilies as FontFamilies, FontSizes as FontSizes, FrameId as FrameId, FrameResourceTree as FrameResourceTree, FrameTree as FrameTree, InstallabilityError as InstallabilityError, LayoutViewport as LayoutViewport, NavigationEntry as NavigationEntry, OriginTrial as OriginTrial, PermissionsPolicyFeatureState as PermissionsPolicyFeatureState, ReferrerPolicy as ReferrerPolicy, ScreencastFormat as ScreencastFormat, ScreenshotFormat as ScreenshotFormat, ScriptFontFamilies as ScriptFontFamilies, ScriptIdentifier as ScriptIdentifier, TransferMode as TransferMode, TransitionType as TransitionType, Viewport as Viewport, VisualViewport as VisualViewport, WebAppManifest as WebAppManifest, WebLifecycleState as WebLifecycleState
from be_friend_chromium.protocol.runtime.types import ExecutionContextId as ExecutionContextId
from enum import Enum
from typing_extensions import NotRequired, TypedDict

class PageMethod(str, Enum):
    ADD_SCRIPT_TO_EVALUATE_ON_LOAD = 'Page.addScriptToEvaluateOnLoad'
    ADD_SCRIPT_TO_EVALUATE_ON_NEW_DOCUMENT = 'Page.addScriptToEvaluateOnNewDocument'
    REMOVE_SCRIPT_TO_EVALUATE_ON_LOAD = 'Page.removeScriptToEvaluateOnLoad'
    REMOVE_SCRIPT_TO_EVALUATE_ON_NEW_DOCUMENT = 'Page.removeScriptToEvaluateOnNewDocument'
    NAVIGATE = 'Page.navigate'
    NAVIGATE_TO_HISTORY_ENTRY = 'Page.navigateToHistoryEntry'
    RELOAD = 'Page.reload'
    STOP_LOADING = 'Page.stopLoading'
    GET_NAVIGATION_HISTORY = 'Page.getNavigationHistory'
    RESET_NAVIGATION_HISTORY = 'Page.resetNavigationHistory'
    CAPTURE_SCREENSHOT = 'Page.captureScreenshot'
    CAPTURE_SNAPSHOT = 'Page.captureSnapshot'
    PRINT_TO_PDF = 'Page.printToPDF'
    BRING_TO_FRONT = 'Page.bringToFront'
    CLOSE = 'Page.close'
    CRASH = 'Page.crash'
    ENABLE = 'Page.enable'
    DISABLE = 'Page.disable'
    HANDLE_JAVASCRIPT_DIALOG = 'Page.handleJavaScriptDialog'
    SET_INTERCEPT_FILE_CHOOSER_DIALOG = 'Page.setInterceptFileChooserDialog'
    GET_FRAME_TREE = 'Page.getFrameTree'
    GET_RESOURCE_TREE = 'Page.getResourceTree'
    GET_RESOURCE_CONTENT = 'Page.getResourceContent'
    CREATE_ISOLATED_WORLD = 'Page.createIsolatedWorld'
    GET_LAYOUT_METRICS = 'Page.getLayoutMetrics'
    SET_BYPASS_CSP = 'Page.setBypassCSP'
    SET_AD_BLOCKING_ENABLED = 'Page.setAdBlockingEnabled'
    GET_PERMISSIONS_POLICY_STATE = 'Page.getPermissionsPolicyState'
    SET_DOCUMENT_CONTENT = 'Page.setDocumentContent'
    SEARCH_IN_RESOURCE = 'Page.searchInResource'
    GET_APP_MANIFEST = 'Page.getAppManifest'
    GET_APP_ID = 'Page.getAppId'
    GET_INSTALLABILITY_ERRORS = 'Page.getInstallabilityErrors'
    GET_MANIFEST_ICONS = 'Page.getManifestIcons'
    SET_LIFECYCLE_EVENTS_ENABLED = 'Page.setLifecycleEventsEnabled'
    SET_WEB_LIFECYCLE_STATE = 'Page.setWebLifecycleState'
    START_SCREENCAST = 'Page.startScreencast'
    STOP_SCREENCAST = 'Page.stopScreencast'
    SCREENCAST_FRAME_ACK = 'Page.screencastFrameAck'
    CLEAR_COMPILATION_CACHE = 'Page.clearCompilationCache'
    ADD_COMPILATION_CACHE = 'Page.addCompilationCache'
    PRODUCE_COMPILATION_CACHE = 'Page.produceCompilationCache'
    GENERATE_TEST_REPORT = 'Page.generateTestReport'
    GET_AD_SCRIPT_ANCESTRY_IDS = 'Page.getAdScriptAncestryIds'
    GET_ORIGIN_TRIALS = 'Page.getOriginTrials'
    SET_FONT_FAMILIES = 'Page.setFontFamilies'
    SET_FONT_SIZES = 'Page.setFontSizes'
    SET_PRERENDERING_ALLOWED = 'Page.setPrerenderingAllowed'
    SET_RPH_REGISTRATION_MODE = 'Page.setRPHRegistrationMode'
    SET_SPC_TRANSACTION_MODE = 'Page.setSPCTransactionMode'
    WAIT_FOR_DEBUGGER = 'Page.waitForDebugger'

class AddScriptToEvaluateOnNewDocumentParams(TypedDict):
    source: str
    worldName: NotRequired[str]
    includeCommandLineAPI: NotRequired[bool]
    runImmediately: NotRequired[bool]

class CaptureScreenshotParams(TypedDict, total=False):
    format: ScreenshotFormat
    quality: int
    clip: Viewport
    fromSurface: bool
    captureBeyondViewport: bool
    optimizeForSpeed: bool

class CaptureSnapshotParams(TypedDict, total=False):
    format: str

class CreateIsolatedWorldParams(TypedDict):
    frameId: FrameId
    worldName: NotRequired[str]
    grantUniveralAccess: NotRequired[bool]

class GetAppManifestParams(TypedDict, total=False):
    manifestId: str

class GetAdScriptAncestryParams(TypedDict):
    frameId: FrameId

class GetPermissionsPolicyStateParams(TypedDict):
    frameId: FrameId

class GetOriginTrialsParams(TypedDict):
    frameId: FrameId

class GetResourceContentParams(TypedDict):
    frameId: FrameId
    url: str

class HandleJavaScriptDialogParams(TypedDict):
    accept: bool
    promptText: NotRequired[str]

class NavigateParams(TypedDict):
    url: str
    referrer: NotRequired[str]
    transitionType: NotRequired[TransitionType]
    frameId: NotRequired[FrameId]
    referrerPolicy: NotRequired[ReferrerPolicy]

class NavigateToHistoryEntryParams(TypedDict):
    entryId: int

class EnableParams(TypedDict):
    enableFileChooserOpenedEvent: NotRequired[bool]

class PrintToPDFParams(TypedDict, total=False):
    landscape: bool
    displayHeaderFooter: bool
    printBackground: bool
    scale: float
    paperWidth: float
    paperHeight: float
    marginTop: float
    marginBottom: float
    marginLeft: float
    marginRight: float
    pageRanges: str
    headerTemplate: str
    footerTemplate: str
    preferCSSPageSize: bool
    transferMode: TransferMode
    generateTaggedPDF: bool
    generateDocumentOutline: bool

class ReloadParams(TypedDict, total=False):
    ignoreCache: bool
    scriptToEvaluateOnLoad: str
    loaderId: LoaderId

class RemoveScriptToEvaluateOnNewDocumentParams(TypedDict):
    identifier: ScriptIdentifier

class ScreencastFrameAckParams(TypedDict):
    sessionId: int

class SearchInResourceParams(TypedDict):
    frameId: FrameId
    url: str
    query: str
    caseSensitive: NotRequired[bool]
    isRegex: NotRequired[bool]

class SetAdBlockingEnabledParams(TypedDict):
    enabled: bool

class SetBypassCSPParams(TypedDict):
    enabled: bool

class AddScriptToEvaluateOnLoadParams(TypedDict):
    scriptSource: str

class SetDocumentContentParams(TypedDict):
    frameId: FrameId
    html: str

class SetInterceptFileChooserDialogParams(TypedDict):
    enabled: bool
    cancel: NotRequired[bool]

class SetLifecycleEventsEnabledParams(TypedDict):
    enabled: bool

class AddCompilationCacheParams(TypedDict):
    url: str
    data: str

class GenerateTestReportParams(TypedDict):
    message: str
    group: NotRequired[str]

class GetAdScriptAncestryIdsParams(TypedDict):
    frameId: FrameId

class GetAppIdParams(TypedDict, total=False):
    appId: str
    recommendedId: str

class GetManifestIconsParams(TypedDict): ...

class RemoveScriptToEvaluateOnLoadParams(TypedDict):
    identifier: ScriptIdentifier

class SetFontFamiliesParams(TypedDict):
    fontFamilies: FontFamilies
    forScripts: NotRequired[list[ScriptFontFamilies]]

class SetFontSizesParams(TypedDict):
    fontSizes: FontSizes

class SetPrerenderingAllowedParams(TypedDict):
    isAllowed: bool

class SetRPHRegistrationModeParams(TypedDict):
    mode: AutoResponseMode

class SetSPCTransactionModeParams(TypedDict):
    mode: AutoResponseMode

class SetWebLifecycleStateParams(TypedDict):
    state: WebLifecycleState

class StartScreencastParams(TypedDict, total=False):
    format: ScreencastFormat
    quality: int
    maxWidth: int
    maxHeight: int
    everyNthFrame: int

class ProduceCompilationCacheParams(TypedDict):
    scripts: list[CompilationCacheParams]

class AddScriptToEvaluateOnNewDocumentResult(TypedDict):
    identifier: ScriptIdentifier

class CaptureScreenshotResult(TypedDict):
    data: str

class CaptureSnapshotResult(TypedDict):
    data: str

class CreateIsolatedWorldResult(TypedDict):
    executionContextId: ExecutionContextId

class GetAppManifestResult(TypedDict):
    url: str
    errors: list[AppManifestError]
    data: NotRequired[str]
    parsed: NotRequired[AppManifestParsedProperties]
    manifest: NotRequired[WebAppManifest]

class GetInstallabilityErrorsResult(TypedDict):
    installabilityErrors: list[InstallabilityError]

class GetAppIdResult(TypedDict, total=False):
    appId: str
    recommendedId: str

class GetAdScriptAncestryResult(TypedDict, total=False):
    adScriptAncestry: AdScriptAncestry

class GetFrameTreeResult(TypedDict):
    frameTree: FrameTree

class GetLayoutMetricsResult(TypedDict):
    layoutViewport: LayoutViewport
    visualViewport: VisualViewport
    contentSize: Rect
    cssLayoutViewport: LayoutViewport
    cssVisualViewport: VisualViewport
    cssContentSize: Rect

class GetNavigationHistoryResult(TypedDict):
    currentIndex: int
    entries: list[NavigationEntry]

class GetPermissionsPolicyStateResult(TypedDict):
    states: list[PermissionsPolicyFeatureState]

class GetOriginTrialsResult(TypedDict):
    originTrials: list[OriginTrial]

class GetResourceContentResult(TypedDict):
    content: str
    base64Encoded: bool

class GetResourceTreeResult(TypedDict):
    frameTree: FrameResourceTree

class PrintToPDFResult(TypedDict):
    data: str
    stream: NotRequired[StreamHandle]

class SearchInResourceResult(TypedDict):
    result: list[SearchMatch]

class NavigateResult(TypedDict):
    frameId: FrameId
    loaderId: NotRequired[LoaderId]
    errorText: NotRequired[str]
    isDownload: NotRequired[bool]

class AddScriptToEvaluateOnLoadResult(TypedDict):
    identifier: ScriptIdentifier

class GetManifestIconsResult(TypedDict):
    primaryIcon: NotRequired[str]

class GetAdScriptAncestryIdsResult(TypedDict):
    adScriptAncestry: NotRequired[AdScriptAncestry]
AddScriptToEvaluateOnLoadResponse = AddScriptToEvaluateOnLoadResult
AddScriptToEvaluateOnNewDocumentResponse = AddScriptToEvaluateOnNewDocumentResult
CaptureScreenshotResponse = CaptureScreenshotResult
CaptureSnapshotResponse = CaptureSnapshotResult
CreateIsolatedWorldResponse = CreateIsolatedWorldResult
GetAdScriptAncestryIdsResponse = GetAdScriptAncestryIdsResult
GetAdScriptAncestryResponse = GetAdScriptAncestryResult
GetAppIdResponse = GetAppIdResult
GetAppManifestResponse = GetAppManifestResult
GetFrameTreeResponse = GetFrameTreeResult
GetInstallabilityErrorsResponse = GetInstallabilityErrorsResult
GetLayoutMetricsResponse = GetLayoutMetricsResult
GetManifestIconsResponse = GetManifestIconsResult
GetNavigationHistoryResponse = GetNavigationHistoryResult
GetOriginTrialsResponse = GetOriginTrialsResult
GetPermissionsPolicyStateResponse = GetPermissionsPolicyStateResult
GetResourceContentResponse = GetResourceContentResult
GetResourceTreeResponse = GetResourceTreeResult
NavigateResponse = NavigateResult
PrintToPDFResponse = PrintToPDFResult
SearchInResourceResponse = SearchInResourceResult
AddScriptToEvaluateOnLoadCommand = Command[AddScriptToEvaluateOnLoadParams, AddScriptToEvaluateOnLoadResponse]
AddScriptToEvaluateOnNewDocumentCommand = Command[AddScriptToEvaluateOnNewDocumentParams, AddScriptToEvaluateOnNewDocumentResponse]
RemoveScriptToEvaluateOnLoadCommand = Command[RemoveScriptToEvaluateOnLoadParams, EmptyResponse]
RemoveScriptToEvaluateOnNewDocumentCommand = Command[RemoveScriptToEvaluateOnNewDocumentParams, EmptyResponse]
NavigateCommand = Command[NavigateParams, NavigateResponse]
NavigateToHistoryEntryCommand = Command[NavigateToHistoryEntryParams, EmptyResponse]
ReloadCommand = Command[ReloadParams, EmptyResponse]
StopLoadingCommand = Command[EmptyParams, EmptyResponse]
GetNavigationHistoryCommand = Command[EmptyParams, GetNavigationHistoryResponse]
ResetNavigationHistoryCommand = Command[EmptyParams, EmptyResponse]
CaptureScreenshotCommand = Command[CaptureScreenshotParams, CaptureScreenshotResponse]
CaptureSnapshotCommand = Command[CaptureSnapshotParams, CaptureSnapshotResponse]
PrintToPDFCommand = Command[PrintToPDFParams, PrintToPDFResponse]
BringToFrontCommand = Command[EmptyParams, EmptyResponse]
CloseCommand = Command[EmptyParams, EmptyResponse]
CrashCommand = Command[EmptyParams, EmptyResponse]
EnableCommand = Command[EnableParams, EmptyResponse]
DisableCommand = Command[EmptyParams, EmptyResponse]
HandleJavaScriptDialogCommand = Command[HandleJavaScriptDialogParams, EmptyResponse]
SetInterceptFileChooserDialogCommand = Command[SetInterceptFileChooserDialogParams, EmptyResponse]
GetFrameTreeCommand = Command[EmptyParams, GetFrameTreeResponse]
GetResourceTreeCommand = Command[EmptyParams, GetResourceTreeResponse]
GetResourceContentCommand = Command[GetResourceContentParams, GetResourceContentResponse]
CreateIsolatedWorldCommand = Command[CreateIsolatedWorldParams, CreateIsolatedWorldResponse]
GetLayoutMetricsCommand = Command[EmptyParams, GetLayoutMetricsResponse]
SetBypassCSPCommand = Command[SetBypassCSPParams, EmptyResponse]
SetAdBlockingEnabledCommand = Command[SetAdBlockingEnabledParams, EmptyResponse]
GetPermissionsPolicyStateCommand = Command[GetPermissionsPolicyStateParams, GetPermissionsPolicyStateResponse]
SetDocumentContentCommand = Command[SetDocumentContentParams, EmptyResponse]
SearchInResourceCommand = Command[SearchInResourceParams, SearchInResourceResponse]
GetAppManifestCommand = Command[GetAppManifestParams, GetAppManifestResponse]
GetAppIdCommand = Command[GetAppIdParams, GetAppIdResponse]
GetInstallabilityErrorsCommand = Command[EmptyParams, GetInstallabilityErrorsResponse]
GetManifestIconsCommand = Command[EmptyParams, GetManifestIconsResponse]
SetLifecycleEventsEnabledCommand = Command[SetLifecycleEventsEnabledParams, EmptyResponse]
SetWebLifecycleStateCommand = Command[SetWebLifecycleStateParams, EmptyResponse]
StartScreencastCommand = Command[StartScreencastParams, EmptyResponse]
StopScreencastCommand = Command[EmptyParams, EmptyResponse]
ScreencastFrameAckCommand = Command[ScreencastFrameAckParams, EmptyResponse]
ClearCompilationCacheCommand = Command[EmptyParams, EmptyResponse]
AddCompilationCacheCommand = Command[AddCompilationCacheParams, EmptyResponse]
ProduceCompilationCacheCommand = Command[ProduceCompilationCacheParams, EmptyResponse]
GenerateTestReportCommand = Command[GenerateTestReportParams, EmptyResponse]
GetAdScriptAncestryCommand = Command[GetAdScriptAncestryParams, GetAdScriptAncestryResponse]
GetAdScriptAncestryIdsCommand = Command[GetAdScriptAncestryIdsParams, GetAdScriptAncestryIdsResponse]
GetOriginTrialsCommand = Command[GetOriginTrialsParams, GetOriginTrialsResponse]
SetFontFamiliesCommand = Command[SetFontFamiliesParams, EmptyResponse]
SetFontSizesCommand = Command[SetFontSizesParams, EmptyResponse]
SetPrerenderingAllowedCommand = Command[SetPrerenderingAllowedParams, EmptyResponse]
SetRPHRegistrationModeCommand = Command[SetRPHRegistrationModeParams, EmptyResponse]
SetSPCTransactionModeCommand = Command[SetSPCTransactionModeParams, EmptyResponse]
WaitForDebuggerCommand = Command[EmptyParams, EmptyResponse]
