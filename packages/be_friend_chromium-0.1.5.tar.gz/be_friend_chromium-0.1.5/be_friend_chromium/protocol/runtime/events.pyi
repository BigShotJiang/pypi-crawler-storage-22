from be_friend_chromium.protocol.base import CDPEvent as CDPEvent
from be_friend_chromium.protocol.runtime.types import ExceptionDetails as ExceptionDetails, ExecutionContextDescription as ExecutionContextDescription, ExecutionContextId as ExecutionContextId, RemoteObject as RemoteObject, StackTrace as StackTrace, Timestamp as Timestamp
from enum import Enum
from typing import Any
from typing_extensions import NotRequired, TypedDict

class RuntimeEvent(str, Enum):
    CONSOLE_API_CALLED = 'Runtime.consoleAPICalled'
    EXCEPTION_REVOKED = 'Runtime.exceptionRevoked'
    EXCEPTION_THROWN = 'Runtime.exceptionThrown'
    EXECUTION_CONTEXT_CREATED = 'Runtime.executionContextCreated'
    EXECUTION_CONTEXT_DESTROYED = 'Runtime.executionContextDestroyed'
    EXECUTION_CONTEXTS_CLEARED = 'Runtime.executionContextsCleared'
    INSPECT_REQUESTED = 'Runtime.inspectRequested'
    BINDING_CALLED = 'Runtime.bindingCalled'

class ConsoleAPICallType(str, Enum):
    LOG = 'log'
    DEBUG = 'debug'
    INFO = 'info'
    ERROR = 'error'
    WARNING = 'warning'
    DIR = 'dir'
    DIRXML = 'dirxml'
    TABLE = 'table'
    TRACE = 'trace'
    CLEAR = 'clear'
    START_GROUP = 'startGroup'
    START_GROUP_COLLAPSED = 'startGroupCollapsed'
    END_GROUP = 'endGroup'
    ASSERT = 'assert'
    PROFILE = 'profile'
    PROFILE_END = 'profileEnd'
    COUNT = 'count'
    TIME_END = 'timeEnd'

class BindingCalledEventParams(TypedDict):
    name: str
    payload: str
    executionContextId: ExecutionContextId

class ConsoleAPICalledEventParams(TypedDict):
    type: ConsoleAPICallType
    args: list[RemoteObject]
    executionContextId: ExecutionContextId
    timestamp: Timestamp
    stackTrace: NotRequired[StackTrace]
    context: NotRequired[str]

class ExceptionRevokedEventParams(TypedDict):
    reason: str
    exceptionId: int

class ExceptionThrownEventParams(TypedDict):
    timestamp: Timestamp
    exceptionDetails: ExceptionDetails

class ExecutionContextCreatedEventParams(TypedDict):
    context: ExecutionContextDescription

class ExecutionContextDestroyedEventParams(TypedDict):
    executionContextId: ExecutionContextId
    executionContextUniqueId: str

class ExecutionContextsClearedEventParams(TypedDict): ...

class InspectRequestedEventParams(TypedDict):
    object: RemoteObject
    hints: dict[str, Any]
    executionContextId: NotRequired[ExecutionContextId]
BindingCalledEvent = CDPEvent[BindingCalledEventParams]
ConsoleAPICalledEvent = CDPEvent[ConsoleAPICalledEventParams]
ExceptionRevokedEvent = CDPEvent[ExceptionRevokedEventParams]
ExceptionThrownEvent = CDPEvent[ExceptionThrownEventParams]
ExecutionContextCreatedEvent = CDPEvent[ExecutionContextCreatedEventParams]
ExecutionContextDestroyedEvent = CDPEvent[ExecutionContextDestroyedEventParams]
ExecutionContextsClearedEvent = CDPEvent[ExecutionContextsClearedEventParams]
InspectRequestedEvent = CDPEvent[InspectRequestedEventParams]
