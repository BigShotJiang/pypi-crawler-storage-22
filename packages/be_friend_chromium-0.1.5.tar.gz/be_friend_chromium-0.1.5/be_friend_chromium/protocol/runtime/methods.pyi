from be_friend_chromium.protocol.base import Command as Command, EmptyParams as EmptyParams, EmptyResponse as EmptyResponse
from be_friend_chromium.protocol.runtime.types import CallArgument as CallArgument, ExceptionDetails as ExceptionDetails, ExecutionContextId as ExecutionContextId, InternalPropertyDescriptor as InternalPropertyDescriptor, PrivatePropertyDescriptor as PrivatePropertyDescriptor, PropertyDescriptor as PropertyDescriptor, RemoteObject as RemoteObject, RemoteObjectId as RemoteObjectId, ScriptId as ScriptId, SerializationOptions as SerializationOptions, TimeDelta as TimeDelta
from enum import Enum
from typing_extensions import NotRequired, TypedDict

S: str

class RuntimeMethod(str, Enum):
    ADD_BINDING = 'Runtime.addBinding'
    AWAIT_PROMISE = 'Runtime.awaitPromise'
    CALL_FUNCTION_ON = ...
    COMPILE_SCRIPT = 'Runtime.compileScript'
    DISABLE = 'Runtime.disable'
    DISCARD_CONSOLE_ENTRIES = 'Runtime.discardConsoleEntries'
    ENABLE = 'Runtime.enable'
    EVALUATE = 'Runtime.evaluate'
    GET_EXCEPTION_DETAILS = 'Runtime.getExceptionDetails'
    GET_HEAP_USAGE = 'Runtime.getHeapUsage'
    GET_ISOLATE_ID = 'Runtime.getIsolateId'
    GET_PROPERTIES = 'Runtime.getProperties'
    GLOBAL_LEXICAL_SCOPE_NAMES = 'Runtime.globalLexicalScopeNames'
    QUERY_OBJECTS = 'Runtime.queryObjects'
    RELEASE_OBJECT = 'Runtime.releaseObject'
    RELEASE_OBJECT_GROUP = 'Runtime.releaseObjectGroup'
    REMOVE_BINDING = 'Runtime.removeBinding'
    RUN_IF_WAITING_FOR_DEBUGGER = 'Runtime.runIfWaitingForDebugger'
    RUN_SCRIPT = 'Runtime.runScript'
    SET_ASYNC_CALL_STACK_DEPTH = 'Runtime.setAsyncCallStackDepth'
    SET_CUSTOM_OBJECT_FORMATTER_ENABLED = 'Runtime.setCustomObjectFormatterEnabled'
    SET_MAX_CALL_STACK_SIZE_TO_CAPTURE = 'Runtime.setMaxCallStackSizeToCapture'
    TERMINATE_EXECUTION = 'Runtime.terminateExecution'

class AddBindingParams(TypedDict):
    name: str
    executionContextId: NotRequired[ExecutionContextId]
    executionContextName: NotRequired[str]

class AwaitPromiseParams(TypedDict):
    promiseObjectId: RemoteObjectId
    returnByValue: NotRequired[bool]
    generatePreview: NotRequired[bool]

class CallFunctionOnParams(TypedDict):
    functionDeclaration: str
    objectId: NotRequired[RemoteObjectId]
    arguments: NotRequired[list[CallArgument]]
    silent: NotRequired[bool]
    returnByValue: NotRequired[bool]
    generatePreview: NotRequired[bool]
    userGesture: NotRequired[bool]
    awaitPromise: NotRequired[bool]
    executionContextId: NotRequired[ExecutionContextId]
    objectGroup: NotRequired[str]
    throwOnSideEffect: NotRequired[bool]
    uniqueContextId: NotRequired[str]
    serializationOptions: NotRequired[SerializationOptions]

class CompileScriptParams(TypedDict):
    expression: str
    sourceURL: str
    persistScript: bool
    executionContextId: NotRequired[ExecutionContextId]

class EvaluateParams(TypedDict):
    expression: str
    objectGroup: NotRequired[str]
    includeCommandLineAPI: NotRequired[bool]
    silent: NotRequired[bool]
    contextId: NotRequired[ExecutionContextId]
    returnByValue: NotRequired[bool]
    generatePreview: NotRequired[bool]
    userGesture: NotRequired[bool]
    awaitPromise: NotRequired[bool]
    throwOnSideEffect: NotRequired[bool]
    timeout: NotRequired[TimeDelta]
    disableBreaks: NotRequired[bool]
    replMode: NotRequired[bool]
    allowUnsafeEvalBlockedByCSP: NotRequired[bool]
    uniqueContextId: NotRequired[str]
    serializationOptions: NotRequired[SerializationOptions]

class GetExceptionDetailsParams(TypedDict):
    errorObjectId: RemoteObjectId

class GetPropertiesParams(TypedDict):
    objectId: RemoteObjectId
    ownProperties: NotRequired[bool]
    accessorPropertiesOnly: NotRequired[bool]
    generatePreview: NotRequired[bool]
    nonIndexedPropertiesOnly: NotRequired[bool]

class GlobalLexicalScopeNamesParams(TypedDict, total=False):
    executionContextId: ExecutionContextId

class QueryObjectsParams(TypedDict):
    prototypeObjectId: RemoteObjectId
    objectGroup: NotRequired[str]

class ReleaseObjectParams(TypedDict):
    objectId: RemoteObjectId

class ReleaseObjectGroupParams(TypedDict):
    objectGroup: str

class RemoveBindingParams(TypedDict):
    name: str

class RunScriptParams(TypedDict):
    scriptId: ScriptId
    executionContextId: NotRequired[ExecutionContextId]
    objectGroup: NotRequired[str]
    silent: NotRequired[bool]
    includeCommandLineAPI: NotRequired[bool]
    returnByValue: NotRequired[bool]
    generatePreview: NotRequired[bool]
    awaitPromise: NotRequired[bool]

class SetAsyncCallStackDepthParams(TypedDict):
    maxDepth: int

class SetCustomObjectFormatterEnabledParams(TypedDict):
    enabled: bool

class SetMaxCallStackSizeToCaptureParams(TypedDict):
    size: int

class AwaitPromiseResult(TypedDict):
    result: RemoteObject
    exceptionDetails: NotRequired[ExceptionDetails]

class CallFunctionOnResult(TypedDict):
    result: RemoteObject
    exceptionDetails: NotRequired[ExceptionDetails]

class CompileScriptResult(TypedDict, total=False):
    scriptId: ScriptId
    exceptionDetails: ExceptionDetails

class EvaluateResult(TypedDict):
    result: RemoteObject
    exceptionDetails: NotRequired[ExceptionDetails]

class GetExceptionDetailsResult(TypedDict, total=False):
    exceptionDetails: ExceptionDetails

class GetHeapUsageResult(TypedDict):
    usedSize: float
    totalSize: float
    embedderHeapUsedSize: float
    backingStorageSize: float

class GetIsolateIdResult(TypedDict):
    id: str

class GetPropertiesResult(TypedDict):
    result: list[PropertyDescriptor]
    internalProperties: NotRequired[list[InternalPropertyDescriptor]]
    privateProperties: NotRequired[list[PrivatePropertyDescriptor]]
    exceptionDetails: NotRequired[ExceptionDetails]

class GlobalLexicalScopeNamesResult(TypedDict):
    names: list[str]

class QueryObjectsResult(TypedDict):
    objects: RemoteObject

class RunScriptResult(TypedDict):
    result: RemoteObject
    exceptionDetails: NotRequired[ExceptionDetails]
AwaitPromiseResponse = AwaitPromiseResult
CallFunctionOnResponse = CallFunctionOnResult
CompileScriptResponse = CompileScriptResult
EvaluateResponse = EvaluateResult
GetExceptionDetailsResponse = GetExceptionDetailsResult
GetHeapUsageResponse = GetHeapUsageResult
GetIsolateIdResponse = GetIsolateIdResult
GetPropertiesResponse = GetPropertiesResult
GlobalLexicalScopeNamesResponse = GlobalLexicalScopeNamesResult
QueryObjectsResponse = QueryObjectsResult
RunScriptResponse = RunScriptResult
AddBindingCommand = Command[AddBindingParams, EmptyResponse]
RemoveBindingCommand = Command[RemoveBindingParams, EmptyResponse]
EvaluateCommand = Command[EvaluateParams, EvaluateResponse]
CallFunctionOnCommand = Command[CallFunctionOnParams, CallFunctionOnResponse]
CompileScriptCommand = Command[CompileScriptParams, CompileScriptResponse]
RunScriptCommand = Command[RunScriptParams, RunScriptResponse]
AwaitPromiseCommand = Command[AwaitPromiseParams, AwaitPromiseResponse]
EnableCommand = Command[EmptyParams, EmptyResponse]
DisableCommand = Command[EmptyParams, EmptyResponse]
GetPropertiesCommand = Command[GetPropertiesParams, GetPropertiesResponse]
ReleaseObjectCommand = Command[ReleaseObjectParams, EmptyResponse]
ReleaseObjectGroupCommand = Command[ReleaseObjectGroupParams, EmptyResponse]
QueryObjectsCommand = Command[QueryObjectsParams, QueryObjectsResponse]
GetExceptionDetailsCommand = Command[GetExceptionDetailsParams, GetExceptionDetailsResponse]
GetHeapUsageCommand = Command[EmptyParams, GetHeapUsageResponse]
GetIsolateIdCommand = Command[EmptyParams, GetIsolateIdResponse]
GlobalLexicalScopeNamesCommand = Command[GlobalLexicalScopeNamesParams, GlobalLexicalScopeNamesResponse]
DiscardConsoleEntriesCommand = Command[EmptyParams, EmptyResponse]
RunIfWaitingForDebuggerCommand = Command[EmptyParams, EmptyResponse]
SetAsyncCallStackDepthCommand = Command[SetAsyncCallStackDepthParams, EmptyResponse]
SetCustomObjectFormatterEnabledCommand = Command[SetCustomObjectFormatterEnabledParams, EmptyResponse]
SetMaxCallStackSizeToCaptureCommand = Command[SetMaxCallStackSizeToCaptureParams, EmptyResponse]
TerminateExecutionCommand = Command[EmptyParams, EmptyResponse]
