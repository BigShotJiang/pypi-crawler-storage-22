from enum import Enum
from typing import Any
from typing_extensions import NotRequired, TypedDict

ScriptId = str
RemoteObjectId = str
UnserializableValue = str
ExecutionContextId = int
Timestamp = float
TimeDelta = float
UniqueDebuggerId = str

class SerializationType(str, Enum):
    DEEP = 'deep'
    JSON = 'json'
    ID_ONLY = 'idOnly'

class DeepSerializedValueType(str, Enum):
    UNDEFINED = 'undefined'
    NULL = 'null'
    STRING = 'string'
    NUMBER = 'number'
    BOOLEAN = 'boolean'
    BIGINT = 'bigint'
    REGEXP = 'regexp'
    DATE = 'date'
    SYMBOL = 'symbol'
    ARRAY = 'array'
    OBJECT = 'object'
    FUNCTION = 'function'
    MAP = 'map'
    SET = 'set'
    WEAKMAP = 'weakmap'
    WEAKSET = 'weakset'
    ERROR = 'error'
    PROXY = 'proxy'
    PROMISE = 'promise'
    TYPEDARRAY = 'typedarray'
    ARRAYBUFFER = 'arraybuffer'
    NODE = 'node'
    WINDOW = 'window'
    GENERATOR = 'generator'

class RemoteObjectType(str, Enum):
    OBJECT = 'object'
    FUNCTION = 'function'
    UNDEFINED = 'undefined'
    STRING = 'string'
    NUMBER = 'number'
    BOOLEAN = 'boolean'
    SYMBOL = 'symbol'
    BIGINT = 'bigint'

class RemoteObjectSubtype(str, Enum):
    ARRAY = 'array'
    NULL = 'null'
    NODE = 'node'
    REGEXP = 'regexp'
    DATE = 'date'
    MAP = 'map'
    SET = 'set'
    WEAKMAP = 'weakmap'
    WEAKSET = 'weakset'
    ITERATOR = 'iterator'
    GENERATOR = 'generator'
    ERROR = 'error'
    PROXY = 'proxy'
    PROMISE = 'promise'
    TYPEDARRAY = 'typedarray'
    ARRAYBUFFER = 'arraybuffer'
    DATAVIEW = 'dataview'
    WEBASSEMBLYMEMORY = 'webassemblymemory'
    WASMVALUE = 'wasmvalue'

class ObjectPreviewType(str, Enum):
    OBJECT = 'object'
    FUNCTION = 'function'
    UNDEFINED = 'undefined'
    STRING = 'string'
    NUMBER = 'number'
    BOOLEAN = 'boolean'
    SYMBOL = 'symbol'
    BIGINT = 'bigint'

class ObjectPreviewSubtype(str, Enum):
    ARRAY = 'array'
    NULL = 'null'
    NODE = 'node'
    REGEXP = 'regexp'
    DATE = 'date'
    MAP = 'map'
    SET = 'set'
    WEAKMAP = 'weakmap'
    WEAKSET = 'weakset'
    ITERATOR = 'iterator'
    GENERATOR = 'generator'
    ERROR = 'error'
    PROXY = 'proxy'
    PROMISE = 'promise'
    TYPEDARRAY = 'typedarray'
    ARRAYBUFFER = 'arraybuffer'
    DATAVIEW = 'dataview'
    WEBASSEMBLYMEMORY = 'webassemblymemory'
    WASMVALUE = 'wasmvalue'

class PropertyPreviewType(str, Enum):
    OBJECT = 'object'
    FUNCTION = 'function'
    UNDEFINED = 'undefined'
    STRING = 'string'
    NUMBER = 'number'
    BOOLEAN = 'boolean'
    SYMBOL = 'symbol'
    ACCESSOR = 'accessor'
    BIGINT = 'bigint'

class PropertyPreviewSubtype(str, Enum):
    ARRAY = 'array'
    NULL = 'null'
    NODE = 'node'
    REGEXP = 'regexp'
    DATE = 'date'
    MAP = 'map'
    SET = 'set'
    WEAKMAP = 'weakmap'
    WEAKSET = 'weakset'
    ITERATOR = 'iterator'
    GENERATOR = 'generator'
    ERROR = 'error'
    PROXY = 'proxy'
    PROMISE = 'promise'
    TYPEDARRAY = 'typedarray'
    ARRAYBUFFER = 'arraybuffer'
    DATAVIEW = 'dataview'
    WEBASSEMBLYMEMORY = 'webassemblymemory'
    WASMVALUE = 'wasmvalue'

class SerializationOptions(TypedDict):
    serialization: SerializationType
    maxDepth: NotRequired[int]
    additionalParameters: NotRequired[dict[str, Any]]

class DeepSerializedValue(TypedDict):
    type: DeepSerializedValueType
    value: NotRequired[Any]
    objectId: NotRequired[str]
    weakLocalObjectReference: NotRequired[int]

class CustomPreview(TypedDict):
    header: str
    bodyGetterId: NotRequired[RemoteObjectId]

class PropertyPreview(TypedDict):
    name: str
    type: PropertyPreviewType
    value: NotRequired[str]
    valuePreview: NotRequired['ObjectPreview']
    subtype: NotRequired[PropertyPreviewSubtype]

class EntryPreview(TypedDict):
    value: ObjectPreview
    key: NotRequired['ObjectPreview']

class ObjectPreview(TypedDict):
    type: ObjectPreviewType
    overflow: bool
    properties: list[PropertyPreview]
    subtype: NotRequired[ObjectPreviewSubtype]
    description: NotRequired[str]
    entries: NotRequired[list[EntryPreview]]

class RemoteObject(TypedDict):
    type: RemoteObjectType
    subtype: NotRequired[RemoteObjectSubtype]
    className: NotRequired[str]
    value: NotRequired[Any]
    unserializableValue: NotRequired[UnserializableValue]
    description: NotRequired[str]
    deepSerializedValue: NotRequired[DeepSerializedValue]
    objectId: NotRequired[RemoteObjectId]
    preview: NotRequired[ObjectPreview]
    customPreview: NotRequired[CustomPreview]

class PropertyDescriptor(TypedDict):
    name: str
    configurable: bool
    enumerable: bool
    value: NotRequired[RemoteObject]
    writable: NotRequired[bool]
    get: NotRequired[RemoteObject]
    set: NotRequired[RemoteObject]
    wasThrown: NotRequired[bool]
    isOwn: NotRequired[bool]
    symbol: NotRequired[RemoteObject]

class InternalPropertyDescriptor(TypedDict):
    name: str
    value: NotRequired[RemoteObject]

class PrivatePropertyDescriptor(TypedDict):
    name: str
    value: NotRequired[RemoteObject]
    get: NotRequired[RemoteObject]
    set: NotRequired[RemoteObject]

class CallArgument(TypedDict, total=False):
    value: Any
    unserializableValue: UnserializableValue
    objectId: RemoteObjectId

class ExecutionContextDescription(TypedDict):
    id: ExecutionContextId
    origin: str
    name: str
    uniqueId: str
    auxData: NotRequired[dict[str, Any]]

class ExceptionDetails(TypedDict):
    exceptionId: int
    text: str
    lineNumber: int
    columnNumber: int
    scriptId: NotRequired[ScriptId]
    url: NotRequired[str]
    stackTrace: NotRequired['StackTrace']
    exception: NotRequired[RemoteObject]
    executionContextId: NotRequired[ExecutionContextId]
    exceptionMetaData: NotRequired[dict[str, Any]]

class CallFrame(TypedDict):
    functionName: str
    scriptId: ScriptId
    url: str
    lineNumber: int
    columnNumber: int

class StackTraceId(TypedDict):
    id: str
    debuggerId: NotRequired[UniqueDebuggerId]

class StackTrace(TypedDict):
    callFrames: list[CallFrame]
    description: NotRequired[str]
    parent: NotRequired['StackTrace']
    parentId: NotRequired[StackTraceId]
