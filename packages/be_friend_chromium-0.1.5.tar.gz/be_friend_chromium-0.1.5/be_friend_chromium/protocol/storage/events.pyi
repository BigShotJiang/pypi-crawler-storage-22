from be_friend_chromium.protocol.base import CDPEvent as CDPEvent
from be_friend_chromium.protocol.network.types import RequestId as RequestId, TimeSinceEpoch as TimeSinceEpoch
from be_friend_chromium.protocol.page.types import FrameId as FrameId
from be_friend_chromium.protocol.storage.types import AttributionReportingAggregatableResult as AttributionReportingAggregatableResult, AttributionReportingEventLevelResult as AttributionReportingEventLevelResult, AttributionReportingReportResult as AttributionReportingReportResult, AttributionReportingSourceRegistration as AttributionReportingSourceRegistration, AttributionReportingSourceRegistrationResult as AttributionReportingSourceRegistrationResult, AttributionReportingTriggerRegistration as AttributionReportingTriggerRegistration, InterestGroupAccessType as InterestGroupAccessType, InterestGroupAuctionEventType as InterestGroupAuctionEventType, InterestGroupAuctionFetchType as InterestGroupAuctionFetchType, InterestGroupAuctionId as InterestGroupAuctionId, SharedStorageAccessMethod as SharedStorageAccessMethod, SharedStorageAccessParams as SharedStorageAccessParams, SharedStorageAccessScope as SharedStorageAccessScope, StorageBucketInfo as StorageBucketInfo
from be_friend_chromium.protocol.target.types import TargetID as TargetID
from enum import Enum
from typing import Any
from typing_extensions import NotRequired, TypedDict

class StorageEvent(str, Enum):
    CACHE_STORAGE_CONTENT_UPDATED = 'Storage.cacheStorageContentUpdated'
    CACHE_STORAGE_LIST_UPDATED = 'Storage.cacheStorageListUpdated'
    INDEXED_DB_CONTENT_UPDATED = 'Storage.indexedDBContentUpdated'
    INDEXED_DB_LIST_UPDATED = 'Storage.indexedDBListUpdated'
    INTEREST_GROUP_ACCESSED = 'Storage.interestGroupAccessed'
    INTEREST_GROUP_AUCTION_EVENT_OCCURRED = 'Storage.interestGroupAuctionEventOccurred'
    INTEREST_GROUP_AUCTION_NETWORK_REQUEST_CREATED = 'Storage.interestGroupAuctionNetworkRequestCreated'
    SHARED_STORAGE_ACCESSED = 'Storage.sharedStorageAccessed'
    SHARED_STORAGE_WORKLET_OPERATION_EXECUTION_FINISHED = 'Storage.sharedStorageWorkletOperationExecutionFinished'
    STORAGE_BUCKET_CREATED_OR_UPDATED = 'Storage.storageBucketCreatedOrUpdated'
    STORAGE_BUCKET_DELETED = 'Storage.storageBucketDeleted'
    ATTRIBUTION_REPORTING_SOURCE_REGISTERED = 'Storage.attributionReportingSourceRegistered'
    ATTRIBUTION_REPORTING_TRIGGER_REGISTERED = 'Storage.attributionReportingTriggerRegistered'
    ATTRIBUTION_REPORTING_REPORT_SENT = 'Storage.attributionReportingReportSent'
    ATTRIBUTION_REPORTING_VERBOSE_DEBUG_REPORT_SENT = 'Storage.attributionReportingVerboseDebugReportSent'

class CacheStorageContentUpdatedEventParams(TypedDict):
    origin: str
    storageKey: str
    bucketId: str
    cacheName: str

class CacheStorageListUpdatedEventParams(TypedDict):
    origin: str
    storageKey: str
    bucketId: str

class IndexedDBContentUpdatedEventParams(TypedDict):
    origin: str
    storageKey: str
    bucketId: str
    databaseName: str
    objectStoreName: str

class IndexedDBListUpdatedEventParams(TypedDict):
    origin: str
    storageKey: str
    bucketId: str

class InterestGroupAccessedEventParams(TypedDict):
    accessTime: TimeSinceEpoch
    type: InterestGroupAccessType
    ownerOrigin: str
    name: str
    componentSellerOrigin: NotRequired[str]
    bid: NotRequired[float]
    bidCurrency: NotRequired[str]
    uniqueAuctionId: NotRequired[InterestGroupAuctionId]

class InterestGroupAuctionEventOccurredEventParams(TypedDict):
    eventTime: TimeSinceEpoch
    type: InterestGroupAuctionEventType
    uniqueAuctionId: InterestGroupAuctionId
    parentAuctionId: NotRequired[InterestGroupAuctionId]
    auctionConfig: NotRequired[dict[str, Any]]

class InterestGroupAuctionNetworkRequestCreatedEventParams(TypedDict):
    type: InterestGroupAuctionFetchType
    requestId: RequestId
    auctions: list[InterestGroupAuctionId]

class SharedStorageAccessedEventParams(TypedDict):
    accessTime: TimeSinceEpoch
    scope: SharedStorageAccessScope
    method: SharedStorageAccessMethod
    mainFrameId: FrameId
    ownerOrigin: str
    ownerSite: str
    params: SharedStorageAccessParams

class SharedStorageWorkletOperationExecutionFinishedEventParams(TypedDict):
    finishedTime: TimeSinceEpoch
    executionTime: int
    method: SharedStorageAccessMethod
    operationId: str
    workletTargetId: TargetID
    mainFrameId: FrameId
    ownerOrigin: str

class StorageBucketCreatedOrUpdatedEventParams(TypedDict):
    bucketInfo: StorageBucketInfo

class StorageBucketDeletedEventParams(TypedDict):
    bucketId: str

class AttributionReportingSourceRegisteredEventParams(TypedDict):
    registration: AttributionReportingSourceRegistration
    result: AttributionReportingSourceRegistrationResult

class AttributionReportingTriggerRegisteredEventParams(TypedDict):
    registration: AttributionReportingTriggerRegistration
    eventLevel: AttributionReportingEventLevelResult
    aggregatable: AttributionReportingAggregatableResult

class AttributionReportingReportSentEventParams(TypedDict):
    url: str
    body: dict[str, Any]
    result: AttributionReportingReportResult
    netError: NotRequired[int]
    netErrorName: NotRequired[str]
    httpStatusCode: NotRequired[int]

class AttributionReportingVerboseDebugReportSentEventParams(TypedDict):
    url: str
    body: NotRequired[list[dict[str, Any]]]
    netError: NotRequired[int]
    netErrorName: NotRequired[str]
    httpStatusCode: NotRequired[int]
CacheStorageContentUpdated = CDPEvent[CacheStorageContentUpdatedEventParams]
CacheStorageListUpdated = CDPEvent[CacheStorageListUpdatedEventParams]
IndexedDBContentUpdated = CDPEvent[IndexedDBContentUpdatedEventParams]
IndexedDBListUpdated = CDPEvent[IndexedDBListUpdatedEventParams]
InterestGroupAccessed = CDPEvent[InterestGroupAccessedEventParams]
InterestGroupAuctionEventOccurred = CDPEvent[InterestGroupAuctionEventOccurredEventParams]
InterestGroupAuctionNetworkRequestCreated = CDPEvent[InterestGroupAuctionNetworkRequestCreatedEventParams]
SharedStorageAccessed = CDPEvent[SharedStorageAccessedEventParams]
SharedStorageWorkletOperationExecutionFinished = CDPEvent[SharedStorageWorkletOperationExecutionFinishedEventParams]
StorageBucketCreatedOrUpdated = CDPEvent[StorageBucketCreatedOrUpdatedEventParams]
StorageBucketDeleted = CDPEvent[StorageBucketDeletedEventParams]
AttributionReportingSourceRegistered = CDPEvent[AttributionReportingSourceRegisteredEventParams]
AttributionReportingTriggerRegistered = CDPEvent[AttributionReportingTriggerRegisteredEventParams]
AttributionReportingReportSent = CDPEvent[AttributionReportingReportSentEventParams]
AttributionReportingVerboseDebugReportSent = CDPEvent[AttributionReportingVerboseDebugReportSentEventParams]
