"""Tests for categorical model."""
