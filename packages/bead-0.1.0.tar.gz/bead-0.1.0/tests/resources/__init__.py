"""Tests for resources module."""
