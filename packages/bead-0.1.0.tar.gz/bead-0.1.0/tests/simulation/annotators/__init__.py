"""Tests for simulation annotators."""
