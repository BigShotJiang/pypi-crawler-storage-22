"""Tests for noise models."""
