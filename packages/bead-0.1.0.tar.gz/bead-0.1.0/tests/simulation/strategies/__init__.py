"""Tests for simulation strategies."""
