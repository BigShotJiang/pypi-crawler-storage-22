"""Tests for templates module."""
