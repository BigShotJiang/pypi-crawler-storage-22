"""Beadloom TUI widgets."""
