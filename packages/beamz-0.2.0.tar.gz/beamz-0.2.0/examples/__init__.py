"""BEAMZ runnable examples package."""
