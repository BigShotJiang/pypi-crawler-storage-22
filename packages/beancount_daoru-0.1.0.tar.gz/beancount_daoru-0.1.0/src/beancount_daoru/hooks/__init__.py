"""Hooks package for post-processing imported Beancount entries.

This package contains hook implementations for post-processing imported
Beancount entries. Hooks allow customization of imported entries before
final output.
"""
