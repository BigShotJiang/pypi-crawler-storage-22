#[allow(clippy::module_inception)]
mod configuration;
mod new_line_kind;

pub use configuration::*;
pub use new_line_kind::*;
