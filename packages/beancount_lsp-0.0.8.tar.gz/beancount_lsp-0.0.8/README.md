Beancount LSP
