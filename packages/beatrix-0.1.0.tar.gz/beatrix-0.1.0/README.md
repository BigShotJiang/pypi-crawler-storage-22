# beatrix
Python library providing structural beam calculation models.
