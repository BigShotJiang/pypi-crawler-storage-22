from dataclasses import dataclass
from .materials import Material
from .cross_sections import CrossSection


@dataclass
class Beam:

    cross_section: CrossSection
    length: float
    material: Material
