from dataclasses import dataclass
from functools import cached_property



class CrossSection:

    @property
    def A (self):
        return 0

    @property
    def Ix (self):
        return 0

    @property
    def Iy (self):
        return 0

    @property
    def Ixy (self):
        return 0



@dataclass
class CHS (CrossSection):

    D: float        # Outer diameter
    t: float        # Wall thickness

    @cached_property
    def d (self):
        return self.D - 2*self.t

    @cached_property
    def A (self):
        from math import pi
        return pi * (self.D**2 - self.d**2) / 4

    @cached_property
    def I (self):
        from math import pi
        return pi * (self.D**4 - self.d**4) / 64

    @cached_property
    def Ix (self):
        return self.I

    @cached_property
    def Iy (self):
        return self.I



