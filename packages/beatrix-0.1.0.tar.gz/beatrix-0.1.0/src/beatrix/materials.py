from dataclasses import dataclass
from functools import cached_property
from metrum.units import GPa



class Material:
    pass


@dataclass
class IsotropicElasticMaterial (Material):

    E: float
    nu: float

    @cached_property
    def G (self):
        return 0.5 * self.E / (1 + self.nu)


STEEL = IsotropicElasticMaterial(E=210*GPa, nu=0.3)

