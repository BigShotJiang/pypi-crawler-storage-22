def to_excel_column(n: int) -> str:
    """Преобразует индекс в буквенную колонку (0 -> a, 26 -> aa)."""
    if n < 0:
        raise ValueError("n должно быть ≥ 0")
    result = ""
    while n >= 0:
        result = chr(ord('a') + (n % 26)) + result
        n = n // 26 - 1
    return result


def beautify_list(data, format_type: str = "space") -> str:
    """
    Форматирует списки, кортежи и словари в красивые строки.
    Типы: 'space', 'enter', 'number', 'alphabetical'.
    """
    if not data:
        return ""

    items = [str(x) for x in data]

    if format_type == "enter":
        return "\n".join(items)

    elif format_type == "number":
        return "\n".join(f"{i + 1}) {x}" for i, x in enumerate(items))

    elif format_type == "alphabetical":
        return "\n".join(f"{to_excel_column(i)}) {x}" for i, x in enumerate(items))

    # По умолчанию 'space' или любой другой некорректный тип
    return " ".join(items)


def enter(a):
    for x in range(0, a):
        print("")