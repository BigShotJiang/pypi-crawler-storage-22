from setuptools import setup, find_packages

setup(
    name="beautifyall",
    version="0.1.0",
    packages=find_packages(),
    author="MineMish",
    description="Библиотека для красивого вывода списков в консоль",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.6",
)