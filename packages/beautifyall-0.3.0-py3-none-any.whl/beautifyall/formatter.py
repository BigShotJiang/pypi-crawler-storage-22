import json
import sqlite3
import os

def to_excel_column(n: int) -> str:
    """Преобразует индекс в буквенную колонку (0 -> a, 26 -> aa)."""
    if n < 0:
        raise ValueError("n должно быть ≥ 0")
    result = ""
    while n >= 0:
        result = chr(ord('a') + (n % 26)) + result
        n = n // 26 - 1
    return result


def beautify_list(data, format_type: str = "space") -> str:
    """
    Форматирует списки, кортежи и словари в красивые строки.
    Типы: 'space', 'enter', 'number', 'alphabetical'.
    """
    if not data:
        return ""

    items = [str(x) for x in data]

    if format_type == "enter":
        return "\n".join(items)

    elif format_type == "number":
        return "\n".join(f"{i + 1}) {x}" for i, x in enumerate(items))

    elif format_type == "alphabetical":
        return "\n".join(f"{to_excel_column(i)}) {x}" for i, x in enumerate(items))

    # По умолчанию 'space' или любой другой некорректный тип
    return " ".join(items)


def enter(a):
    for x in range(0, a):
        print("")


def save_in_data(vars_dict: dict, file_type: str = "txt", filename: str = "exported_data"):
    """
    Сохраняет выбранные переменные в форматы JSON, SQL или TXT.

    :param vars_dict: Словарь с переменными (например, {'x': 10})
    :param file_type: 'json', 'sql' или 'txt'
    :param filename: Имя файла без расширения
    """
    if file_type == "json" or file_type == ".json":
        with open(f"{filename}.json", "w", encoding="utf-8") as f:
            json.dump(vars_dict, f, ensure_ascii=False, indent=4)

    elif file_type == "txt" or file_type == ".txt":
        with open(f"{filename}.txt", "w", encoding="utf-8") as f:
            for key, value in vars_dict.items():
                f.write(f"{key}: {value}\n")

    elif file_type == "sql" or file_type == ".sql":
        conn = sqlite3.connect(f"{filename}.db")
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS data (var_name TEXT, var_value TEXT)")
        for key, value in vars_dict.items():
            cursor.execute("INSERT INTO data VALUES (?, ?)", (str(key), str(value)))
        conn.commit()
        conn.close()

    print(f"Данные успешно сохранены в {filename}.{file_type}")


def get_vars(scope, names="all"):
    """
    Вспомогательная функция для фильтрации переменных.
    """
    # Исключаем системные переменные Python
    excluded = ['__name__', '__doc__', '__package__', '__loader__', '__spec__', '__annotations__', '__builtins__']

    if names == "all":
        return {k: v for k, v in scope.items() if k not in excluded and not callable(v)}

    return {k: scope[k] for k in names if k in scope}