# Types

::: beautyspot.types
