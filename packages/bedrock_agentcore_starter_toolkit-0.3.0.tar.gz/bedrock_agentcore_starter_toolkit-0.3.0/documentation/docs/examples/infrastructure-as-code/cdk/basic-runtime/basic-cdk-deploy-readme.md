{% include-markdown "https://raw.githubusercontent.com/awslabs/amazon-bedrock-agentcore-samples/refs/heads/main/04-infrastructure-as-code/cdk/basic-runtime/README.md" start="#" %}
