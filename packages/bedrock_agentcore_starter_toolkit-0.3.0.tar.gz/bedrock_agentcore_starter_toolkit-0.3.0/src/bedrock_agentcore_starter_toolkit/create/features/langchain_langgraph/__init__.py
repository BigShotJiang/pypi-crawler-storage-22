"""Langgraph Templates."""
