Future modules
==============

The documentation will expand as new modules are added. Planned additions include:

- Module A (planned)
- Module B (planned)

These sections will be populated with usage guides and API references when the
modules are released.
