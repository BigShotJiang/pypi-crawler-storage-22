BEEhaviourLab
=============

Welcome to the BEEhaviourLab documentation.

BEEhaviourLab provides tools for detecting, tracking, and analysing bee behaviour
from video data. The library is structured into modules, with Tracking available
today and additional modules planned.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   quickstart
   api

.. toctree::
   :maxdepth: 2
   :caption: Modules:

   tracking
   future-modules
