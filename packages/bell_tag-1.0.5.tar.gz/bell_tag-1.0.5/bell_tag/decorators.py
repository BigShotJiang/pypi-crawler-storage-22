import requests
from flask import request
from .exceptions import VerificationFailed
from .utils import load_env_config, verify_server_once

def bell_tag(f):
    """
    Decorator to track a Flask route.
    Automatically verifies the server on first usage using API_KEY from .env.

    Usage:
        @app.route("/my-route")
        @bell_tag
        def my_route():
            return "Hello"
    """
    from functools import wraps

    # Load API_KEY from .env
    config = load_env_config()
    api_key = config.get("API_KEY")
    if not api_key:
        raise VerificationFailed("Bell Tag: API_KEY missing in .env")

    # Perform verification once
    verify_server_once(api_key)

    @wraps(f)
    def wrapper(*args, **kwargs):
        # Track the request silently
        try:
            ip_address = request.headers.get('X-Forwarded-For', request.remote_addr)
            user_agent = request.headers.get('User-Agent')
            path = request.path
            method = request.method

            requests.post(
                "https://belltagmanager.com/api/v1/track",
                json={
                    "api_key": api_key,
                    "path": path,
                    "method": method,
                    "ip": ip_address,
                    "user_agent": user_agent
                },
                timeout=3
            )
        except Exception:
            pass  # fail silently

        return f(*args, **kwargs)

    return wrapper
