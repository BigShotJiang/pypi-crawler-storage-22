class VerificationFailed(Exception):
    """Raised when server verification fails"""
    pass
