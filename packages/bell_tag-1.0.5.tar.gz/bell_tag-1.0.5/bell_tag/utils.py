import os
from dotenv import load_dotenv
import requests
from .exceptions import VerificationFailed

_verified = False  # internal flag for verification

def load_env_config():
    """Load BELL_KEY from .env"""
    load_dotenv()  # loads .env from current working directory
    return {"BELL_KEY": os.getenv("BELL_KEY")}

def verify_server_once(api_key):
    """Verify server with API once per process"""
    global _verified
    if _verified:
        return True

    try:
        resp = requests.post(
            "https://belltagmanager.com/api/v1/verify",
            json={"api_key": api_key},
            timeout=5
        )
        if resp.status_code != 200:
            raise VerificationFailed("Server verification failed.")

        _verified = True
        return True
    except Exception as e:
        raise VerificationFailed(f"Verification error: {e}")
