# bell_tag/utils.py

_verified = False  # internal flag for verification

def load_env_config():
    from dotenv import load_dotenv
    import os
    """Load BELL_KEY from .env"""
    load_dotenv()  # loads .env from current working directory
    return {"BELL_KEY": os.getenv("BELL_KEY")}
def verify_server_once(api_key):
    """Verify server with API once per process, fail silently if server is down"""
    global _verified
    if _verified:
        return True

    try:
        import requests
        resp = requests.post(
            "https://belltagmanager.com/api/v1/verify",
            json={"api_key": api_key},
            timeout=5
        )
        if resp.status_code == 200:
            _verified = True
            return True
        else:
            # server responded but failed verification — log silently
            print("Bell Tag: Verification failed, continuing anyway.")
            return False
    except Exception as e:
        # server unreachable — fail silently
        print(f"Bell Tag: Verification could not be completed ({e}), continuing anyway.")
        return False
