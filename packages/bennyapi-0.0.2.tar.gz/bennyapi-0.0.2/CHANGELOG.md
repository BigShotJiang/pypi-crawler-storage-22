# Changelog

## 0.0.2 (2026-02-15)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/Benny-API/benny-python/compare/v0.0.1...v0.0.2)

### Chores

* configure new SDK language ([2eeaa20](https://github.com/Benny-API/benny-python/commit/2eeaa208aa728bb9c0712ece9067a188debb53d3))
* update SDK settings ([548f3e4](https://github.com/Benny-API/benny-python/commit/548f3e434e266fa51f838353dc5c34bb5e874251))
* update SDK settings ([4a26383](https://github.com/Benny-API/benny-python/commit/4a26383d1d85d3af5085cbbdfbab2e82fdfb16d9))
* update SDK settings ([862a7e0](https://github.com/Benny-API/benny-python/commit/862a7e0eb2b483368855d246f5dd138403ee4359))
