# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from benny_ebt import Benny, AsyncBenny
from tests.utils import assert_matches_type
from benny_ebt.types import OrderCreateSessionResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestOrders:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_session(self, client: Benny) -> None:
        order = client.orders.create_session(
            items=[
                {
                    "id": "id",
                    "description": "description",
                    "name": "name",
                    "price": 0,
                    "quantity": 0,
                    "snap_eligible": True,
                    "tax_rate": 0,
                    "tenders": [
                        {
                            "amount": 0,
                            "tender": "EBT_CASH",
                        }
                    ],
                    "unit": "COUNT",
                }
            ],
            on_exit_redirect_url="onExitRedirectUrl",
            on_success_redirect_url="onSuccessRedirectUrl",
        )
        assert_matches_type(OrderCreateSessionResponse, order, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_session_with_all_params(self, client: Benny) -> None:
        order = client.orders.create_session(
            items=[
                {
                    "id": "id",
                    "description": "description",
                    "name": "name",
                    "price": 0,
                    "quantity": 0,
                    "snap_eligible": True,
                    "tax_rate": 0,
                    "tenders": [
                        {
                            "amount": 0,
                            "tender": "EBT_CASH",
                        }
                    ],
                    "unit": "COUNT",
                    "padded_price": 0,
                    "photo_url": "photoUrl",
                }
            ],
            on_exit_redirect_url="onExitRedirectUrl",
            on_success_redirect_url="onSuccessRedirectUrl",
            external_customer_id="externalCustomerId",
            external_order_id="externalOrderId",
        )
        assert_matches_type(OrderCreateSessionResponse, order, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create_session(self, client: Benny) -> None:
        response = client.orders.with_raw_response.create_session(
            items=[
                {
                    "id": "id",
                    "description": "description",
                    "name": "name",
                    "price": 0,
                    "quantity": 0,
                    "snap_eligible": True,
                    "tax_rate": 0,
                    "tenders": [
                        {
                            "amount": 0,
                            "tender": "EBT_CASH",
                        }
                    ],
                    "unit": "COUNT",
                }
            ],
            on_exit_redirect_url="onExitRedirectUrl",
            on_success_redirect_url="onSuccessRedirectUrl",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        order = response.parse()
        assert_matches_type(OrderCreateSessionResponse, order, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create_session(self, client: Benny) -> None:
        with client.orders.with_streaming_response.create_session(
            items=[
                {
                    "id": "id",
                    "description": "description",
                    "name": "name",
                    "price": 0,
                    "quantity": 0,
                    "snap_eligible": True,
                    "tax_rate": 0,
                    "tenders": [
                        {
                            "amount": 0,
                            "tender": "EBT_CASH",
                        }
                    ],
                    "unit": "COUNT",
                }
            ],
            on_exit_redirect_url="onExitRedirectUrl",
            on_success_redirect_url="onSuccessRedirectUrl",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            order = response.parse()
            assert_matches_type(OrderCreateSessionResponse, order, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncOrders:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_session(self, async_client: AsyncBenny) -> None:
        order = await async_client.orders.create_session(
            items=[
                {
                    "id": "id",
                    "description": "description",
                    "name": "name",
                    "price": 0,
                    "quantity": 0,
                    "snap_eligible": True,
                    "tax_rate": 0,
                    "tenders": [
                        {
                            "amount": 0,
                            "tender": "EBT_CASH",
                        }
                    ],
                    "unit": "COUNT",
                }
            ],
            on_exit_redirect_url="onExitRedirectUrl",
            on_success_redirect_url="onSuccessRedirectUrl",
        )
        assert_matches_type(OrderCreateSessionResponse, order, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_session_with_all_params(self, async_client: AsyncBenny) -> None:
        order = await async_client.orders.create_session(
            items=[
                {
                    "id": "id",
                    "description": "description",
                    "name": "name",
                    "price": 0,
                    "quantity": 0,
                    "snap_eligible": True,
                    "tax_rate": 0,
                    "tenders": [
                        {
                            "amount": 0,
                            "tender": "EBT_CASH",
                        }
                    ],
                    "unit": "COUNT",
                    "padded_price": 0,
                    "photo_url": "photoUrl",
                }
            ],
            on_exit_redirect_url="onExitRedirectUrl",
            on_success_redirect_url="onSuccessRedirectUrl",
            external_customer_id="externalCustomerId",
            external_order_id="externalOrderId",
        )
        assert_matches_type(OrderCreateSessionResponse, order, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create_session(self, async_client: AsyncBenny) -> None:
        response = await async_client.orders.with_raw_response.create_session(
            items=[
                {
                    "id": "id",
                    "description": "description",
                    "name": "name",
                    "price": 0,
                    "quantity": 0,
                    "snap_eligible": True,
                    "tax_rate": 0,
                    "tenders": [
                        {
                            "amount": 0,
                            "tender": "EBT_CASH",
                        }
                    ],
                    "unit": "COUNT",
                }
            ],
            on_exit_redirect_url="onExitRedirectUrl",
            on_success_redirect_url="onSuccessRedirectUrl",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        order = await response.parse()
        assert_matches_type(OrderCreateSessionResponse, order, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create_session(self, async_client: AsyncBenny) -> None:
        async with async_client.orders.with_streaming_response.create_session(
            items=[
                {
                    "id": "id",
                    "description": "description",
                    "name": "name",
                    "price": 0,
                    "quantity": 0,
                    "snap_eligible": True,
                    "tax_rate": 0,
                    "tenders": [
                        {
                            "amount": 0,
                            "tender": "EBT_CASH",
                        }
                    ],
                    "unit": "COUNT",
                }
            ],
            on_exit_redirect_url="onExitRedirectUrl",
            on_success_redirect_url="onSuccessRedirectUrl",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            order = await response.parse()
            assert_matches_type(OrderCreateSessionResponse, order, path=["response"])

        assert cast(Any, response.is_closed) is True
