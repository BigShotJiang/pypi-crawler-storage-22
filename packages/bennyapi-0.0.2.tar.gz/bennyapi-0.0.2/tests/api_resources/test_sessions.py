# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from benny_ebt import Benny, AsyncBenny
from tests.utils import assert_matches_type
from benny_ebt.types import SessionCreateTokenResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSessions:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_token(self, client: Benny) -> None:
        session = client.sessions.create_token(
            external_user_id="externalUserId",
        )
        assert_matches_type(SessionCreateTokenResponse, session, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_token_with_all_params(self, client: Benny) -> None:
        session = client.sessions.create_token(
            external_user_id="externalUserId",
            order_id="orderId",
        )
        assert_matches_type(SessionCreateTokenResponse, session, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create_token(self, client: Benny) -> None:
        response = client.sessions.with_raw_response.create_token(
            external_user_id="externalUserId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        session = response.parse()
        assert_matches_type(SessionCreateTokenResponse, session, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create_token(self, client: Benny) -> None:
        with client.sessions.with_streaming_response.create_token(
            external_user_id="externalUserId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            session = response.parse()
            assert_matches_type(SessionCreateTokenResponse, session, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncSessions:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_token(self, async_client: AsyncBenny) -> None:
        session = await async_client.sessions.create_token(
            external_user_id="externalUserId",
        )
        assert_matches_type(SessionCreateTokenResponse, session, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_token_with_all_params(self, async_client: AsyncBenny) -> None:
        session = await async_client.sessions.create_token(
            external_user_id="externalUserId",
            order_id="orderId",
        )
        assert_matches_type(SessionCreateTokenResponse, session, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create_token(self, async_client: AsyncBenny) -> None:
        response = await async_client.sessions.with_raw_response.create_token(
            external_user_id="externalUserId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        session = await response.parse()
        assert_matches_type(SessionCreateTokenResponse, session, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create_token(self, async_client: AsyncBenny) -> None:
        async with async_client.sessions.with_streaming_response.create_token(
            external_user_id="externalUserId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            session = await response.parse()
            assert_matches_type(SessionCreateTokenResponse, session, path=["response"])

        assert cast(Any, response.is_closed) is True
