# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["PaymentCreateIntentResponse"]


class PaymentCreateIntentResponse(BaseModel):
    payment_intent_id: str = FieldInfo(alias="paymentIntentId")
    """The payment intent ID. Payment intents expire after 1 hour."""
