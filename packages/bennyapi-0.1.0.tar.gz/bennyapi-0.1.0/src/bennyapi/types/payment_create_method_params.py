# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentCreateMethodParams"]


class PaymentCreateMethodParams(TypedDict, total=False):
    external_user_id: Required[Annotated[str, PropertyInfo(alias="externalUserId")]]
    """The representation of your customer ID."""

    token_id: Required[Annotated[str, PropertyInfo(alias="tokenId")]]
    """The token ID returned from the mobile or web SDK representing the EBT card."""
