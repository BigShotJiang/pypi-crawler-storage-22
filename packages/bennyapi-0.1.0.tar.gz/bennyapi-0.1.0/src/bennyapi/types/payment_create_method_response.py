# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["PaymentCreateMethodResponse"]


class PaymentCreateMethodResponse(BaseModel):
    payment_method_id: str = FieldInfo(alias="paymentMethodId")
    """The payment method ID that represents the tokenized EBT card."""
