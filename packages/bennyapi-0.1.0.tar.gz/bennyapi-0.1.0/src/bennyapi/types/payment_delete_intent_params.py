# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentDeleteIntentParams"]


class PaymentDeleteIntentParams(TypedDict, total=False):
    payment_intent_id: Required[Annotated[str, PropertyInfo(alias="paymentIntentId")]]
    """The payment intent ID."""
