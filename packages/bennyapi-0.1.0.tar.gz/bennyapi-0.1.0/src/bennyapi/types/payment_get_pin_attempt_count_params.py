# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentGetPinAttemptCountParams"]


class PaymentGetPinAttemptCountParams(TypedDict, total=False):
    retrieval_reference_number: Required[Annotated[str, PropertyInfo(alias="retrievalReferenceNumber")]]
