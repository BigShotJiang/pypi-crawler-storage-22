# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["PaymentRefundResponse"]


class PaymentRefundResponse(BaseModel):
    refund_intent_id: str = FieldInfo(alias="refundIntentId")
    """The refund intent ID."""
