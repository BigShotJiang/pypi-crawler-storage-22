# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentReverseParams"]


class PaymentReverseParams(TypedDict, total=False):
    payment_intent_id: Annotated[str, PropertyInfo(alias="paymentIntentId")]
    """The payment intent ID."""

    refund_intent_id: Annotated[str, PropertyInfo(alias="refundIntentId")]
    """The refund intent ID."""
