# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["TenderType"]

TenderType: TypeAlias = Literal["EBT_CASH", "SNAP", "BANK_CARD"]
