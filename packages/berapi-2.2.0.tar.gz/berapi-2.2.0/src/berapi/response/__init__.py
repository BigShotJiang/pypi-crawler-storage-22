"""Response handling for BerAPI."""

from berapi.response.response import Response

__all__ = [
    "Response",
]
