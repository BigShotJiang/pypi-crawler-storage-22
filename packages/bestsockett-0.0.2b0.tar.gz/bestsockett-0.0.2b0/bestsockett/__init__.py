import maincodes
print("-" * 30)
print("Using Bestsockett v0.0.2b   ")
print("-" * 30)
# Kütüphane versiyonunu burada da belirtebilirsin (isteğe bağlı)
__version__ = "0.0.2b"