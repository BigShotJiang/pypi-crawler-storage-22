---
paths:
  - "**/*.py"
---

# Python Rules

## Naming

- Never use type suffixes in variable names (`_list`, `_dict`, `_map`, `_str`, `_int`, etc.)
- Bad: `users_list`, `config_dict`, `name_str`, `handler_map`, `count_int`
- Good: `users`, `config`, `name`, `handlers`, `count`
