# Changelog

## 0.4.0

### Added

- New `arnmatch` module for ARN pattern matching using regex patterns from AWS documentation
- `arnmatch(arn)` function returns `ARNMatch` with parsed ARN components
- `ARNMatch.resource_id` and `ARNMatch.resource_name` heuristics for extracting resource identifiers
- Support for Resource Explorer type aliases (handles naming differences between AWS docs and Resource Explorer)
- 2080 ARN patterns covering 355 AWS services

## 0.3.1

- Initial release with `get_tags` and `set_tags` functions
