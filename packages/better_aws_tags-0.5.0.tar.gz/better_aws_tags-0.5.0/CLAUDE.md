# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## EXTREMELY IMPORTANT

- NEVER use bare `try...except` or `except Exception`. ALWAYS catch specific exceptions.
- NEVER do defensive programming. Let code FAIL if there is an unhandled exception.
- ALWAYS validate results of API calls (boto3, HTTP, etc.). Check the response to confirm the operation succeeded.

## Build and Development Commands

```bash
make dev       # Run in development mode (uv run python -m better_aws_tags)
make run       # Run debug script (uv run python -i debug_bats.py)
make test      # Run tests on Python 3.10-3.13
make lint      # Run ruff linter
make fmt       # Format code with ruff
make check     # Run lint and tests
make build     # Build package
make publish   # Build and publish to PyPI
```

Run a single test:
```bash
uv run pytest tests/test_dispatch.py::test_dispatch_supported_resource -v
```

## Architecture

This library provides a unified API for AWS resource tagging that abstracts away the differences between AWS's various tagging APIs.

### Core Flow

1. **Entry points** (`src/better_aws_tags/tags.py`): `get_tags()` and `set_tags()` accept ARNs and optional boto3 session
2. **Dispatch** (`tags.py:dispatch()`): Routes ARNs to appropriate handlers based on resource type
3. **Handlers** (`src/better_aws_tags/handlers.py`): Execute AWS API calls

### Handlers

- `TaggingAPIHandler`: Uses Resource Groups Tagging API for resources in `SUPPORTED_RESOURCES`
- `IAMRoleHandler`: IAM roles (`arn:aws:iam::*:role/*`)
- `IAMUserHandler`: IAM users (`arn:aws:iam::*:user/*`)
- `IAMPolicyHandler`: IAM policies (`arn:aws:iam::*:policy/*`)

The `HANDLERS` dict maps `(service, resource_type)` tuples to handler classes for resources not covered by the Tagging API.

### Handler Routing Logic

The `dispatch()` function determines which handler to use:
1. If CloudFormation resource type is in `SUPPORTED_RESOURCES` → `TaggingAPIHandler`
2. If `(service, resource_type)` is in `HANDLERS` → specific handler
3. Otherwise → raises `NotImplementedError`

### Dependencies

- `arnmatch`: Parses ARNs and extracts service, resource type, and CloudFormation resource type
- `boto3`: AWS SDK for Python

## Adding Support for New Resources

1. **Run integration tests** to identify unsupported resources:
   ```bash
   uv run python tests/integration/check_coverage.py
   ```

2. **Get sample ARN** and parse with arnmatch:
   ```python
   from arnmatch import arnmatch
   data = arnmatch(arn)
   print('aws_service:', data.aws_service)
   print('resource_type:', data.resource_type)
   print('tagging_resource:', data.tagging_resource)
   ```
   If `tagging_resource` is not `None` and is in `SUPPORTED_RESOURCES` → TaggingAPIHandler works.
   If `tagging_resource` is `None` → need custom handler or mark unsupported.

3. **Check if boto client exists**:
   ```python
   client = data.client()
   ```
   If no client exists → resource is not taggable.

4. **Check if tagging methods exist**:
   ```python
   tag_methods = [m for m in dir(client) if 'tag' in m.lower()]
   ```
   If no tag methods → add to `unsupported_resources.py`.

5. **Test if tagging works for this resource type**:
   ```python
   client.list_tags_for_resource(resourceArn=arn)  # or similar
   ```
   If fails with "invalid resource" → add to `unsupported_resources.py`.

6. **If taggable, write a handler**:
   - Create `src/better_aws_tags/handlers/{service}.py`
   - Implement `get_tags` and `set_tags` methods
   - Register in `handlers/__init__.py` with `(service, resource_type)` key

7. **Re-run integration tests** to verify coverage.
