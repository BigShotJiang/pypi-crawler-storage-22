# better-aws-tags

A unified Python interface for managing AWS resource tags.

AWS provides multiple tagging APIs across services, including the Resource Groups Tagging API and service-specific implementations such as EC2, S3, and IAM. This library abstracts these differences behind a single API that accepts any valid ARN and handles service routing automatically.

## Getting Started

```python
import better_aws_tags as bats

# Get tags for resources
tags = bats.get_tags(["arn:aws:s3:::my-bucket", "arn:aws:iam::123456789012:role/my-role"])

# Set tags on resources
bats.set_tags(["arn:aws:s3:::my-bucket"], {"Environment": "prod", "Team": "platform"})
```

## How It Works

The library routes ARNs to the appropriate handler:

1. Most resources use the **Resource Groups Tagging API** (1000+ supported resource types)
2. Some IAM resources (roles, users, policies) require **IAM-specific APIs**

This routing is transparent - just pass ARNs and the library handles the rest.

## Reference

- https://docs.aws.amazon.com/resourcegroupstagging/latest/APIReference/overview.html
- https://docs.aws.amazon.com/resourcegroupstagging/latest/APIReference/API_TagResources.html
- https://docs.aws.amazon.com/resourcegroupstagging/latest/APIReference/supported-services.html
- https://docs.aws.amazon.com/ARG/latest/userguide/supported-resources.html

AWS Resources and Resource Types:
- https://docs.aws.amazon.com/IAM/latest/UserGuide/reference-arns.html
- https://docs.aws.amazon.com/service-authorization/latest/reference/reference_policies_actions-resources-contextkeys.html
