__version__ = "0.5.0"

from .tags import get_tags as get_tags
from .tags import set_tags as set_tags
