from .asg import ASGHandler
from .base import Handler
from .cloudfront import CloudFrontFunctionHandler
from .glue import GlueTableHandler
from .iam import IAMPolicyHandler, IAMRoleHandler, IAMUserHandler
from .inspector import InspectorHandler
from .rds import RDSAutoBackupHandler
from .resource_explorer import ResourceExplorer2Handler
from .ses import SESIdentityHandler
from .tagging_api import TaggingAPIHandler
from .wafv2 import WAFv2Handler

HANDLERS = {
    ("autoscaling", "autoscaling-group"): ASGHandler,
    ("cloudfront", "function"): CloudFrontFunctionHandler,
    ("glue", "table"): GlueTableHandler,
    ("iam", "iam-role"): IAMRoleHandler,
    ("iam", "user"): IAMUserHandler,
    ("iam", "policy"): IAMPolicyHandler,
    ("inspector", "target-template"): InspectorHandler,
    ("rds", "auto-backup"): RDSAutoBackupHandler,
    ("resource-explorer-2", "index"): ResourceExplorer2Handler,
    ("resource-explorer-2", "view"): ResourceExplorer2Handler,
    ("ses", "identity"): SESIdentityHandler,
    ("wafv2", "ipset"): WAFv2Handler,
    ("wafv2", "rulegroup"): WAFv2Handler,
    ("wafv2", "webacl"): WAFv2Handler,
}

__all__ = [
    "ASGHandler",
    "CloudFrontFunctionHandler",
    "GlueTableHandler",
    "Handler",
    "HANDLERS",
    "IAMPolicyHandler",
    "IAMRoleHandler",
    "IAMUserHandler",
    "InspectorHandler",
    "RDSAutoBackupHandler",
    "ResourceExplorer2Handler",
    "SESIdentityHandler",
    "TaggingAPIHandler",
    "WAFv2Handler",
]
