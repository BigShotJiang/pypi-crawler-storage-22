from botocore.exceptions import ClientError
from arnmatch import arnmatch

from .base import Handler


class ASGHandler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        client = session.client("autoscaling")
        result = {}

        names = {arnmatch(arn).resource_name: arn for arn in arns}

        response = client.describe_tags(
            Filters=[{"Name": "auto-scaling-group", "Values": list(names.keys())}]
        )

        for arn in arns:
            result[arn] = {}

        for tag in response["Tags"]:
            arn = names[tag["ResourceId"]]
            result[arn][tag["Key"]] = tag["Value"]

        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        client = session.client("autoscaling")
        result = {}

        for arn in arns:
            name = arnmatch(arn).resource_name
            payload = [
                {
                    "ResourceId": name,
                    "ResourceType": "auto-scaling-group",
                    "Key": k,
                    "Value": v,
                    "PropagateAtLaunch": False,
                }
                for k, v in tags.items()
            ]
            try:
                client.create_or_update_tags(Tags=payload)
                result[arn] = True
            except ClientError as e:
                if e.response["Error"]["Code"] == "ValidationError":
                    result[arn] = None
                else:
                    raise

        return result
