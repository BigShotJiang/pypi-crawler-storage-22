from abc import ABC, abstractmethod


class Handler(ABC):
    @classmethod
    @abstractmethod
    def get_tags(cls, session, arns):
        pass

    @classmethod
    @abstractmethod
    def set_tags(cls, session, arns, tags):
        pass
