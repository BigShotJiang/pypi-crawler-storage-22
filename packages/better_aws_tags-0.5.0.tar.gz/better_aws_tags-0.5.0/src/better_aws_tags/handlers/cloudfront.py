from .base import Handler


class CloudFrontFunctionHandler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        client = session.client("cloudfront")
        result = {}

        for arn in arns:
            response = client.list_tags_for_resource(Resource=arn)
            tags = response["Tags"].get("Items", [])
            result[arn] = {t["Key"]: t["Value"] for t in tags}

        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        client = session.client("cloudfront")
        result = {}

        payload = {"Items": [{"Key": k, "Value": v} for k, v in tags.items()]}
        for arn in arns:
            client.tag_resource(Resource=arn, Tags=payload)
            result[arn] = True

        return result
