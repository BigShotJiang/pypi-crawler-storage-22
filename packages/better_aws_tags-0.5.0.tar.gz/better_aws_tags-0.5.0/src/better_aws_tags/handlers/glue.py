from .base import Handler


class GlueTableHandler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        client = session.client("glue")
        result = {}

        for arn in arns:
            response = client.get_tags(ResourceArn=arn)
            result[arn] = response["Tags"]

        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        client = session.client("glue")
        result = {}

        for arn in arns:
            client.tag_resource(ResourceArn=arn, TagsToAdd=tags)
            result[arn] = True

        return result
