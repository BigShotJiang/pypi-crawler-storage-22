from arnmatch import arnmatch

from .base import Handler


class IAMRoleHandler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        client = session.client("iam")
        result = {}
        for arn in arns:
            name = arnmatch(arn).resource_name
            response = client.list_role_tags(RoleName=name)
            result[arn] = {t["Key"]: t["Value"] for t in response["Tags"]}
        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        client = session.client("iam")
        payload = [{"Key": k, "Value": v} for k, v in tags.items()]
        result = {}
        for arn in arns:
            name = arnmatch(arn).resource_name
            try:
                client.tag_role(RoleName=name, Tags=payload)
                result[arn] = True
            except client.exceptions.NoSuchEntityException:
                result[arn] = None
        return result


class IAMUserHandler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        client = session.client("iam")
        result = {}
        for arn in arns:
            name = arnmatch(arn).resource_name
            response = client.list_user_tags(UserName=name)
            result[arn] = {t["Key"]: t["Value"] for t in response["Tags"]}
        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        client = session.client("iam")
        payload = [{"Key": k, "Value": v} for k, v in tags.items()]
        result = {}
        for arn in arns:
            name = arnmatch(arn).resource_name
            try:
                client.tag_user(UserName=name, Tags=payload)
                result[arn] = True
            except client.exceptions.NoSuchEntityException:
                result[arn] = None
        return result


class IAMPolicyHandler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        client = session.client("iam")
        result = {}
        for arn in arns:
            response = client.list_policy_tags(PolicyArn=arn)
            result[arn] = {t["Key"]: t["Value"] for t in response["Tags"]}
        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        client = session.client("iam")
        payload = [{"Key": k, "Value": v} for k, v in tags.items()]
        result = {}
        for arn in arns:
            try:
                client.tag_policy(PolicyArn=arn, Tags=payload)
                result[arn] = True
            except client.exceptions.NoSuchEntityException:
                result[arn] = None
        return result
