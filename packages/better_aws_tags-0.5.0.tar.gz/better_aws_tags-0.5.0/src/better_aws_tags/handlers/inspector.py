from .base import Handler


class InspectorHandler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        client = session.client("inspector")
        result = {}

        for arn in arns:
            response = client.list_tags_for_resource(resourceArn=arn)
            result[arn] = {t["key"]: t["value"] for t in response["tags"]}

        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        client = session.client("inspector")
        result = {}

        payload = [{"key": k, "value": v} for k, v in tags.items()]
        for arn in arns:
            client.set_tags_for_resource(resourceArn=arn, tags=payload)
            result[arn] = True

        return result
