from .base import Handler


class RDSAutoBackupHandler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        client = session.client("rds")
        result = {}

        for arn in arns:
            response = client.list_tags_for_resource(ResourceName=arn)
            result[arn] = {t["Key"]: t["Value"] for t in response["TagList"]}

        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        client = session.client("rds")
        result = {}

        payload = [{"Key": k, "Value": v} for k, v in tags.items()]
        for arn in arns:
            client.add_tags_to_resource(ResourceName=arn, Tags=payload)
            result[arn] = True

        return result
