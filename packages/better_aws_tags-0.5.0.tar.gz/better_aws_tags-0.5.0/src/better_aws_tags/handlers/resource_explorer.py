from .base import Handler


class ResourceExplorer2Handler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        client = session.client("resource-explorer-2")
        result = {}

        for arn in arns:
            response = client.list_tags_for_resource(resourceArn=arn)
            result[arn] = response.get("Tags", {})

        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        client = session.client("resource-explorer-2")
        result = {}

        for arn in arns:
            client.tag_resource(resourceArn=arn, Tags=tags)
            result[arn] = True

        return result
