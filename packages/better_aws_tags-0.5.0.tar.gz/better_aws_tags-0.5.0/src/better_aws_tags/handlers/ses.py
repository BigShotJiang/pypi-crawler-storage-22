from .base import Handler


class SESIdentityHandler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        client = session.client("sesv2")
        result = {}

        for arn in arns:
            response = client.list_tags_for_resource(ResourceArn=arn)
            result[arn] = {t["Key"]: t["Value"] for t in response["Tags"]}

        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        client = session.client("sesv2")
        result = {}

        payload = [{"Key": k, "Value": v} for k, v in tags.items()]
        for arn in arns:
            client.tag_resource(ResourceArn=arn, Tags=payload)
            result[arn] = True

        return result
