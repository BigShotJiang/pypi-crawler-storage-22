from .base import Handler


class TaggingAPIHandler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        if not arns:
            raise ValueError("At least one ARN must be provided to get_tags.")

        client = session.client("resourcegroupstaggingapi")
        result = {}

        # https://docs.aws.amazon.com/resourcegroupstagging/latest/APIReference/API_GetResources.html
        batch_size = 100
        for i in range(0, len(arns), batch_size):
            batch = arns[i : i + batch_size]
            response = client.get_resources(ResourceARNList=batch)
            response = response["ResourceTagMappingList"]
            for arn in batch:
                if arn in response:
                    result[arn] = {
                        t["Key"]: t["Value"] for t in response[arn].get("Tags", [])
                    }
                else:
                    result[arn] = None
        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        if not arns:
            raise ValueError("At least one ARN must be provided to set_tags.")

        if len(tags) == 0:
            raise ValueError("At least one tag must be provided to set_tags.")

        if len(tags) > 50:
            raise ValueError("A maximum of 50 tags can be set at once.")

        client = session.client("resourcegroupstaggingapi")
        result = {}

        # https://docs.aws.amazon.com/resourcegroupstagging/latest/APIReference/API_TagResources.html
        batch_size = 20
        for i in range(0, len(arns), batch_size):
            batch = arns[i : i + batch_size]
            response = client.tag_resources(ResourceARNList=batch, Tags=tags)
            for arn in batch:
                result[arn] = arn not in response["FailedResourcesMap"]

        return result
