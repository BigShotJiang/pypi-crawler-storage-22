from .base import Handler


class WAFv2Handler(Handler):
    @classmethod
    def get_tags(cls, session, arns):
        client = session.client("wafv2")
        result = {}

        for arn in arns:
            response = client.list_tags_for_resource(ResourceARN=arn)
            tags = response["TagInfoForResource"]["TagList"]
            result[arn] = {t["Key"]: t["Value"] for t in tags}

        return result

    @classmethod
    def set_tags(cls, session, arns, tags):
        client = session.client("wafv2")
        result = {}

        payload = [{"Key": k, "Value": v} for k, v in tags.items()]
        for arn in arns:
            client.tag_resource(ResourceARN=arn, Tags=payload)
            result[arn] = True

        return result
