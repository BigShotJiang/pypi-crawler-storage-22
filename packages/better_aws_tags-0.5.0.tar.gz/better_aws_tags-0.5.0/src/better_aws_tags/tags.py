"""AWS resource tag operations."""

import boto3

from arnmatch import arnmatch
from .handlers import HANDLERS, TaggingAPIHandler
from .supported_resources import SUPPORTED_RESOURCES
from .unsupported_resources import UNSUPPORTED_RESOURCES


def get_tags(arns, session=None):
    """Get tags for AWS resources."""
    session = session or boto3.Session()
    handlers = dispatch(arns)
    results = {}
    for handler, handler_arns in handlers.items():
        r = handler.get_tags(session, handler_arns)
        results.update(r)
    return results


def set_tags(arns, tags, session=None):
    """Set tags on AWS resources."""
    session = session or boto3.Session()
    handlers = dispatch(arns)
    results = {}
    for handler, handler_arns in handlers.items():
        r = handler.set_tags(session, handler_arns, tags)
        results.update(r)
    return results


def dispatch(arns):
    """Group ARNs by handler."""
    handler_to_arns = {}
    for arn in arns:
        data = arnmatch(arn)
        key = (data.aws_service, data.resource_type)

        if key in UNSUPPORTED_RESOURCES:
            continue

        tagging_resource = data.tagging_resource or data.cloudformation_resource
        if tagging_resource in SUPPORTED_RESOURCES:
            handler = TaggingAPIHandler
        elif key in HANDLERS:
            handler = HANDLERS[key]
        else:
            raise NotImplementedError(
                f"Unsupported resource: {data.aws_service}:{data.resource_type}"
            )

        handler_to_arns.setdefault(handler, []).append(arn)
    return handler_to_arns
