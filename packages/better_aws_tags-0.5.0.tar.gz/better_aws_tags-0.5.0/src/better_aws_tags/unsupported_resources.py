"""Resources that cannot be tagged via AWS APIs."""

# (service, resource_type) tuples for resources that are not taggable
UNSUPPORTED_RESOURCES = {
    # EKS Kubernetes resources - indexed by Resource Explorer but not taggable via AWS APIs
    ("eks", "daemonset"),
    ("eks", "deployment"),
    ("eks", "endpoint-slice"),
    ("eks", "ingress"),
    ("eks", "namespace"),
    ("eks", "persistent-volume"),
    ("eks", "replicaset"),
    ("eks", "service"),
    ("eks", "statefulset"),
    # IAM groups - no tagging API exists
    ("iam", "group"),
    # CloudWatch dashboards - TagResource only supports alarms and insight-rules
    ("cloudwatch", "dashboard"),
    # CloudFront origin-access-identity - not supported by TagResource
    ("cloudfront", "origin-access-identity"),
    # CloudFront origin-access-control - not supported by TagResource
    ("cloudfront", "origin-access-control"),
    # CloudFront cache-policy - not supported by TagResource
    ("cloudfront", "cache-policy"),
    # IAM service-linked roles - AWS-managed
    ("iam", "opensearchservice-role"),
    # SSM resource-data-sync - not supported by ListTagsForResource
    ("ssm", "resource-datasync"),
}
