"""Check handler coverage against real AWS resources via Resource Explorer."""

from collections import defaultdict

import boto3
from arnmatch import arnmatch

from better_aws_tags.handlers import HANDLERS
from better_aws_tags.supported_resources import SUPPORTED_RESOURCES
from better_aws_tags.unsupported_resources import UNSUPPORTED_RESOURCES


def fetch_resources():
    """Fetch all resources from AWS Resource Explorer 2."""
    client = boto3.client("resource-explorer-2")
    paginator = client.get_paginator("list_resources")

    resources = []
    for page in paginator.paginate():
        for resource in page.get("Resources", []):
            arn = resource.get("Arn")
            if arn:
                resources.append(arn)
        print(f"Fetched {len(resources)} resources...")

    return resources


def check_coverage(arns):
    """Check which ARNs are supported and which are not."""
    supported = defaultdict(list)
    skipped = defaultdict(list)
    unsupported = defaultdict(list)

    for arn in arns:
        data = arnmatch(arn)
        tagging_resource = data.tagging_resource or data.cloudformation_resource
        key = (data.aws_service, data.resource_type)

        if tagging_resource in SUPPORTED_RESOURCES:
            supported[tagging_resource].append(arn)
        elif key in HANDLERS:
            handler = HANDLERS[key]
            supported[handler.__name__].append(arn)
        elif key in UNSUPPORTED_RESOURCES:
            skipped[f"{data.aws_service}:{data.resource_type}"].append(arn)
        else:
            unsupported[f"{data.aws_service}:{data.resource_type}"].append(arn)

    return supported, skipped, unsupported


def main():
    arns = fetch_resources()
    supported, skipped, unsupported = check_coverage(arns)

    print("\n" + "=" * 60)
    print("SUPPORTED RESOURCES")
    print("=" * 60)
    for resource_type in sorted(supported.keys()):
        print(f"  {resource_type}: {len(supported[resource_type])}")
    print(f"\nTotal: {len(supported)} types, {sum(len(v) for v in supported.values())} resources")

    print("\n" + "=" * 60)
    print("SKIPPED RESOURCES (not taggable via AWS APIs)")
    print("=" * 60)
    for resource_type in sorted(skipped.keys()):
        print(f"  {resource_type}: {len(skipped[resource_type])}")
    print(f"\nTotal: {len(skipped)} types, {sum(len(v) for v in skipped.values())} resources")

    print("\n" + "=" * 60)
    print("UNSUPPORTED RESOURCES")
    print("=" * 60)
    for resource_type in sorted(unsupported.keys()):
        print(f"  {resource_type}: {len(unsupported[resource_type])}")
    print(f"\nTotal: {len(unsupported)} types, {sum(len(v) for v in unsupported.values())} resources")


if __name__ == "__main__":
    main()
