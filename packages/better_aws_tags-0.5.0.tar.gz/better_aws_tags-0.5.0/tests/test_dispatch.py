import pytest

from better_aws_tags.tags import dispatch
from better_aws_tags.handlers import (
    IAMRoleHandler,
    IAMUserHandler,
    TaggingAPIHandler,
)


def test_dispatch_supported_resource():
    """Supported resource routes to TaggingAPIHandler."""
    arns = ["arn:aws:s3:::my-bucket"]
    result = dispatch(arns)
    assert TaggingAPIHandler in result
    assert result[TaggingAPIHandler] == arns


def test_dispatch_iam_role():
    """IAM role routes to IAMRoleHandler."""
    arns = ["arn:aws:iam::123456789012:role/my-role"]
    result = dispatch(arns)
    assert IAMRoleHandler in result
    assert result[IAMRoleHandler] == arns


def test_dispatch_iam_user():
    """IAM user routes to IAMUserHandler."""
    arns = ["arn:aws:iam::123456789012:user/my-user"]
    result = dispatch(arns)
    assert IAMUserHandler in result
    assert result[IAMUserHandler] == arns


def test_dispatch_iam_policy():
    """IAM policy routes to TaggingAPIHandler (via tagging_resource)."""
    arns = ["arn:aws:iam::123456789012:policy/my-policy"]
    result = dispatch(arns)
    assert TaggingAPIHandler in result
    assert result[TaggingAPIHandler] == arns


def test_dispatch_iam_instance_profile():
    """IAM instance profile is in SUPPORTED_RESOURCES, routes to TaggingAPIHandler."""
    arns = ["arn:aws:iam::123456789012:instance-profile/my-profile"]
    result = dispatch(arns)
    assert TaggingAPIHandler in result
    assert result[TaggingAPIHandler] == arns


def test_dispatch_mixed_resources():
    """Mixed resources are grouped by handler."""
    s3_arn = "arn:aws:s3:::my-bucket"
    iam_arn = "arn:aws:iam::123456789012:role/my-role"
    ec2_arn = "arn:aws:ec2:us-east-1:123456789012:instance/i-1234"

    result = dispatch([s3_arn, iam_arn, ec2_arn])

    assert TaggingAPIHandler in result
    assert IAMRoleHandler in result
    assert s3_arn in result[TaggingAPIHandler]
    assert ec2_arn in result[TaggingAPIHandler]
    assert iam_arn in result[IAMRoleHandler]
