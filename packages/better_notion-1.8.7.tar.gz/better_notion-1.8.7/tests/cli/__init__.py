"""Tests for Better Notion CLI."""
