"""Tests for the plugin system."""
