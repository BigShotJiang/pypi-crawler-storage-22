#!/usr/bin/env python3

from betterhtmlchunking.main import DomRepresentation
