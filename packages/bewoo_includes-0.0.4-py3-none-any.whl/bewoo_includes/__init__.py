"""Bewoo Includes package.

General Header Only Utilities
"""

from pathlib import Path

from bewoo_includes._internal.cli import main
from bewoo_includes._internal.info import METADATA

__version__: str = METADATA.version

_PACKAGE_DIR = Path(__file__).parent


def get_include() -> str:
    """Return path to the C++ header files directory.

    Usage in build systems:
        include_dirs = [bewoo_includes.get_include()]

    Or with compiler flags:
        -I$(python -c "import bewoo_includes; print(bewoo_includes.get_include())")
    """
    return str(_PACKAGE_DIR)


def get_info() -> str:
    """Return path to the info/ headers (project_info.hpp, version_helpers.hpp)."""
    return str(_PACKAGE_DIR / "info")


def get_logger() -> str:
    """Return path to the logger/ headers."""
    return str(_PACKAGE_DIR / "logger")


def get_py_constants() -> str:
    """Return path to the py_constants/ headers."""
    return str(_PACKAGE_DIR / "py_constants")


__all__: list[str] = [
    "METADATA",
    "__version__",
    "get_include",
    "get_info",
    "get_logger",
    "get_py_constants",
    "main",
]
