from argparse import ArgumentParser, Namespace, _SubParsersAction
from typing import TYPE_CHECKING, NamedTuple

if TYPE_CHECKING:
    from .info import ExitCode, _BumpType


class _ReturnedArgs(NamedTuple):
    cmd: str
    version_name: bool
    bump_type: _BumpType
    no_color: bool


def get_args(args: list[str]) -> _ReturnedArgs:
    """Parse command-line arguments."""
    from .info import _VALID_BUMP_TYPES as VALIDS

    parser = ArgumentParser(description="Pack Int CLI")
    subparsers: _SubParsersAction[ArgumentParser] = parser.add_subparsers(dest="command", required=True)
    version: ArgumentParser = subparsers.add_parser("version", help="Get the version of the package.")
    version.add_argument("--name", "-n", action="store_true", help="Print only the version name.")
    bump: ArgumentParser = subparsers.add_parser("bump", help="Bump the version of the package.")
    bump.add_argument("bump_type", type=str, choices=VALIDS, help="Type of version bump (major, minor, patch).")
    debug: ArgumentParser = subparsers.add_parser("debug", help="Print debug information.")
    debug.add_argument("--no-color", "-nc", action="store_true", help="Disable colored output.")
    parsed: Namespace = parser.parse_args(args)
    return _ReturnedArgs(
        cmd=parsed.command,
        version_name=getattr(parsed, "name", False),
        bump_type=getattr(parsed, "bump_type", "patch"),
        no_color=getattr(parsed, "no_color", False),
    )


def get_version(version_name: bool) -> ExitCode:
    """CLI command to get the version of the package."""
    from .info import METADATA, ExitCode

    if version_name:
        print(METADATA.full_version)
    else:
        print(METADATA.version)
    return ExitCode.SUCCESS


def bump_version(b: _BumpType) -> ExitCode:
    """Bump the version of the current package.

    Args:
        b: The type of bump ("major", "minor", or "patch").
        v: A Version instance representing the current version.

    Returns:
        An ExitCode indicating success or failure.
    """
    from .info import _VALID_BUMP_TYPES as VALIDS, METADATA, ExitCode, _Version

    v: _Version = METADATA.version_tuple
    if b not in VALIDS:
        print(f"Invalid argument '{b}'. Use one of: {', '.join(VALIDS)}.")
        return ExitCode.FAILURE

    if v == (0, 0, 0):
        print("Current version is 0.0.0, cannot bump version.")
        return ExitCode.FAILURE
    try:
        new_version: _Version = v.new_version(b)
        print(str(new_version))
        return ExitCode.SUCCESS
    except ValueError:
        print(f"Invalid version tuple: {v}")
        return ExitCode.FAILURE


def debug_info(no_color: bool = False) -> ExitCode:
    """CLI command to print debug information."""
    from .debug import _print_debug_info
    from .info import ExitCode

    _print_debug_info(no_color=no_color)
    return ExitCode.SUCCESS


# ruff: noqa: PLC0415
