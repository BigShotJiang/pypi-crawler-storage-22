#pragma once

#include <chrono>
#include <string>

namespace TimeCub {


#define DATE_FORMAT "%m-%d-%Y"
#define TIME_FORMAT "%I:%M:%S %p"
#define DT_FORMAT_WITH_SECONDS DATE_FORMAT " " TIME_FORMAT
#define DEFAULT_TZ "UTC"

#define MILLISECONDS_IN_SECOND 1000
#define MICROSECONDS_IN_SECOND 1000000

static inline const char* get_ord_suffix(uint8_t day) {
    if (day >= 11 && day <= 13) {
        return "th";
    }
    switch (day % 10) {
        case 1: return "st";
        case 2: return "nd";
        case 3: return "rd";
        default: return "th";
    }
}

enum TimestampPrecision {
    TS_SECONDS,
    TS_MILLISECONDS,
    TS_MICROSECONDS
};

struct EpochTimestamp {
    
    uint64_t timestamp;

    const char* tz;
    char str[32];

    uint16_t millisecond;
    uint16_t microsecond;

    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;

    TimestampPrecision precision;

    static EpochTimestamp now(TimestampPrecision precision = TS_MILLISECONDS) {
        EpochTimestamp ts = {};
        auto now = std::chrono::system_clock::now();
        auto epoch = now.time_since_epoch();
        ts.precision = precision;
        switch (precision) {
            case TS_SECONDS:
                ts.timestamp = std::chrono::duration_cast<std::chrono::seconds>(epoch).count();
                ts.precision = TS_SECONDS;
                break;
            case TS_MILLISECONDS:
                ts.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(epoch).count();
                ts.precision = TS_MILLISECONDS;
                break;
            case TS_MICROSECONDS:
                ts.timestamp = std::chrono::duration_cast<std::chrono::microseconds>(epoch).count();
                ts.precision = TS_MICROSECONDS;
                break;
        }
        auto time_t_now = std::chrono::system_clock::to_time_t(now);
        struct tm* time_info = std::localtime(&time_t_now);

        ts.year = time_info->tm_year + 1900;
        ts.month = time_info->tm_mon + 1;
        ts.day = time_info->tm_mday;
        ts.hour = time_info->tm_hour;
        ts.minute = time_info->tm_min;
        ts.second = time_info->tm_sec;
        ts.millisecond = std::chrono::duration_cast<std::chrono::milliseconds>(epoch).count() % MILLISECONDS_IN_SECOND;
        ts.microsecond = std::chrono::duration_cast<std::chrono::microseconds>(epoch).count() % MICROSECONDS_IN_SECOND;

        ts.tz = time_info->tm_zone ? time_info->tm_zone : DEFAULT_TZ;

        if (precision == TS_SECONDS) {
            strftime(ts.str, sizeof(ts.str), "%Y-%m-%d %H:%M:%S", time_info);
        } else if (precision == TS_MILLISECONDS) {
            snprintf(ts.str, sizeof(ts.str), "%04d-%02d-%02d %02d:%02d:%02d.%03d",
                     ts.year, ts.month, ts.day, ts.hour, ts.minute, ts.second, ts.millisecond);
        } else if (precision == TS_MICROSECONDS) {
            snprintf(ts.str, sizeof(ts.str), "%04d-%02d-%02d %02d:%02d:%02d.%06d",
                     ts.year, ts.month, ts.day, ts.hour, ts.minute, ts.second, ts.microsecond);
        }
        return ts;
    }

    std::string to_string() const { return std::string(str); }
    int to_int() const { return static_cast<int>(timestamp); }

    bool same_precision(const EpochTimestamp& other) const { return precision == other.precision; }

    bool operator==(const EpochTimestamp& other) const {return same_precision(other) &&timestamp == other.timestamp; }
    bool operator!=(const EpochTimestamp& other) const { return !(*this == other); }
    bool operator<(const EpochTimestamp& other) const { return same_precision(other) && timestamp < other.timestamp; }
    bool operator<=(const EpochTimestamp& other) const { return same_precision(other) && timestamp <= other.timestamp; }
    bool operator>(const EpochTimestamp& other) const { return same_precision(other) && timestamp > other.timestamp; }
    bool operator>=(const EpochTimestamp& other) const { return same_precision(other) && timestamp >= other.timestamp; }

    int since(const EpochTimestamp& other) const {
        if (precision != other.precision) { throw std::invalid_argument("Cannot compare timestamps with different precision"); }
        return timestamp - other.timestamp;
    }
};

EpochTimestamp now(TimestampPrecision default_precision = TS_MILLISECONDS) { return EpochTimestamp::now(default_precision); }
uint64_t time_since(const EpochTimestamp& start, const EpochTimestamp& end) { return end.since(start); }


} // namespace TimeCub
