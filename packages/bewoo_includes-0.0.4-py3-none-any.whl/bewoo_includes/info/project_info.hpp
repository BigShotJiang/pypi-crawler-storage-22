#pragma once

#include <pybind11/pybind11.h>

#include <stdexcept>
#include <string>
#include <sstream>

namespace py = pybind11;

// Expects these to be defined via compiler flags (-D):
//   PROJECT_PACKAGE_NAME   e.g. "ecs_cub"
//   PROJECT_NAME           e.g. "ecs_cub"
//   PROJECT_NAME_UPPER     e.g. "ECS_CUB"
//   PROJECT_ENV_VARIABLE   e.g. "ECS_CUB_ENV"
//
// Example in bear_build.toml:
//   extra_compile_args = [
//       "-DPROJECT_PACKAGE_NAME=\"my_project\"",
//       "-DPROJECT_NAME=\"my_project\"",
//       "-DPROJECT_NAME_UPPER=\"MY_PROJECT\"",
//       "-DPROJECT_ENV_VARIABLE=\"MY_PROJECT_ENV\"",
//   ]

#ifndef PROJECT_PACKAGE_NAME
#define PROJECT_PACKAGE_NAME ""
#endif
#ifndef PROJECT_NAME
#define PROJECT_NAME ""
#endif
#ifndef PROJECT_NAME_UPPER
#define PROJECT_NAME_UPPER ""
#endif
#ifndef PROJECT_ENV_VARIABLE
#define PROJECT_ENV_VARIABLE "_ENV"
#endif

namespace ProjectInfo {

enum class ExitCode : int {
    Success = 0,
    Failure = 1,
    MisuseOfShellCommand = 2,
    CommandCannotExecute = 126,
    CommandNotFound = 127,
    InvalidArgumentToExit = 128,
    ScriptTerminatedByControlC = 130,
    ProcessKilledBySigkill = 137,
    SegmentationFault = 139,
    ProcessTerminatedBySigterm = 143,
    ExitStatusOutOfRange = 255
};

enum class VersionParts : int {
    Major = 0,
    Minor = 1,
    Patch = 2
};

struct Version {
    int major = 0;
    int minor = 0;
    int patch = 0;

    Version() = default;
    Version(int maj, int min, int pat) : major(maj), minor(min), patch(pat) {}

    Version bump(VersionParts part) const {
        switch (part) {
            case VersionParts::Major:
                return Version(major + 1, 0, 0);
            case VersionParts::Minor:
                return Version(major, minor + 1, 0);
            case VersionParts::Patch:
                return Version(major, minor, patch + 1);
            default:
                throw std::invalid_argument("Invalid version part");
        }
    }

    Version bump(const std::string& part_name) const {
        if (part_name == "major") return bump(VersionParts::Major);
        if (part_name == "minor") return bump(VersionParts::Minor);
        if (part_name == "patch") return bump(VersionParts::Patch);
        throw std::invalid_argument("Invalid bump type: " + part_name);
    }

    static Version from_string(const std::string& version_str) {
        Version v;
        std::istringstream ss(version_str);
        char dot;
        ss >> v.major;
        if (ss.peek() == '.') { ss >> dot >> v.minor; }
        if (ss.peek() == '.') { ss >> dot >> v.patch; }
        return v;
    }

    std::string to_string() const {
        return std::to_string(major) + "." + std::to_string(minor) + "." + std::to_string(patch);
    }

    bool operator==(const Version& other) const {
        return major == other.major && minor == other.minor && patch == other.patch;
    }

    bool operator<(const Version& other) const {
        if (major != other.major) return major < other.major;
        if (minor != other.minor) return minor < other.minor;
        return patch < other.patch;
    }
};

// Bind project info to a pybind11 module
//
// Usage:
//   PYBIND11_MODULE(my_module, m) {
//       ProjectInfo::bind_project_info(m);
//   }
template <typename Module>
inline void bind_project_info(Module& m) {
    py::enum_<ExitCode>(m, "ExitCode")
        .value("Success", ExitCode::Success)
        .value("Failure", ExitCode::Failure)
        .value("MisuseOfShellCommand", ExitCode::MisuseOfShellCommand)
        .value("CommandCannotExecute", ExitCode::CommandCannotExecute)
        .value("CommandNotFound", ExitCode::CommandNotFound)
        .value("InvalidArgumentToExit", ExitCode::InvalidArgumentToExit)
        .value("ScriptTerminatedByControlC", ExitCode::ScriptTerminatedByControlC)
        .value("ProcessKilledBySigkill", ExitCode::ProcessKilledBySigkill)
        .value("SegmentationFault", ExitCode::SegmentationFault)
        .value("ProcessTerminatedBySigterm", ExitCode::ProcessTerminatedBySigterm)
        .value("ExitStatusOutOfRange", ExitCode::ExitStatusOutOfRange);

    py::enum_<VersionParts>(m, "VersionParts")
        .value("Major", VersionParts::Major)
        .value("Minor", VersionParts::Minor)
        .value("Patch", VersionParts::Patch);

    py::class_<Version>(m, "Version")
        .def(py::init<>())
        .def(py::init<int, int, int>(), py::arg("major"), py::arg("minor") = 0, py::arg("patch") = 0)
        .def_readwrite("major", &Version::major)
        .def_readwrite("minor", &Version::minor)
        .def_readwrite("patch", &Version::patch)
        .def("bump", py::overload_cast<VersionParts>(&Version::bump, py::const_), py::arg("part"))
        .def("bump", py::overload_cast<const std::string&>(&Version::bump, py::const_), py::arg("part_name"))
        .def_static("from_string", &Version::from_string, py::arg("version_str"))
        .def("__str__", &Version::to_string)
        .def("__repr__", [](const Version& v) {
            return "Version(" + std::to_string(v.major) + ", " + std::to_string(v.minor) + ", " + std::to_string(v.patch) + ")";
        })
        .def("__eq__", &Version::operator==)
        .def("__lt__", &Version::operator<);

    // Expose project constants (from -D compiler flags)
    m.attr("PACKAGE_NAME") = PROJECT_PACKAGE_NAME;
    m.attr("PROJECT_NAME") = PROJECT_NAME;
    m.attr("PROJECT_NAME_UPPER") = PROJECT_NAME_UPPER;
    m.attr("ENV_VARIABLE") = PROJECT_ENV_VARIABLE;
}

}  // namespace ProjectInfo
