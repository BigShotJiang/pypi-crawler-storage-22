#pragma once

#include <iostream>
#include <string>
#include <cassert>
#ifdef LOGGER_BUFFER
#include <vector>
#endif
#ifdef LOGGER_FILE
#include <filesystem>
#include <fstream>
#endif

#include "colors.hpp"
#include "logger_common.hpp"
#include "../epoch_timestamp.h"

using namespace TimeCub;

namespace LogCub {
class Logger {
   private:
    using LogFunc = void (Logger::*)(const std::string&, const std::string&);

    LogLevel level;
    LoggingMode mode;

    LogFunc info_fn;
    LogFunc warning_fn;
    LogFunc error_fn;
    LogFunc debug_fn;
    LogFunc verbose_fn;
    
    #ifdef LOGGER_FILE
    int current_file_size = 0;
    int max_rotations = LOGGER_FILE_ROTATIONS;
    int max_file_size = LOGGER_FILE_MAX_SIZE;
    std::filesystem::path log_file_path;
    std::ofstream log_file;

    void close_file() { if (log_file.is_open()) { log_file.close(); } }

    void writeToFile(const std::string &msg) {
        if (ShouldRotate()) { RotateFiles(); }
        log_file << msg << std::endl;
        log_file.flush();
    }

    void RotateFiles() {
        close_file();
        for (int i = max_rotations - 1; i > 0; --i) {
            std::filesystem::path old_path = log_file_path.string() + "." + std::to_string(i);
            std::filesystem::path new_path = log_file_path.string() + "." + std::to_string(i + 1);
            if (std::filesystem::exists(old_path)) {
                std::filesystem::rename(old_path, new_path);
            }
        }
        std::filesystem::path first_backup = log_file_path.string() + ".1";
        if (std::filesystem::exists(log_file_path)) {
            std::filesystem::rename(log_file_path, first_backup);
        }
        log_file.open(log_file_path, std::ios_base::trunc);
    }

    bool ShouldRotate() {
        if (!log_file.is_open()) return false;
        log_file.seekp(0, std::ios::end);
        return log_file.tellp() >= LOGGER_FILE_MAX_SIZE;
    }

    #else
    void close_file() {}
    void writeToFile(const std::string &msg) {}
    void RotateFiles() {}
    bool ShouldRotate() { return false; }
    #endif

    const char* get_level_color(LogLevel level) {
        switch (level) {
            case LogLevel::INFO: return GREEN;
            case LogLevel::WARNING: return YELLOW;
            case LogLevel::ERROR: return RED;
            case LogLevel::DEBUG: return BLUE;
            case LogLevel::VERBOSE: return CYAN;
            default: return RESET;
        }
    }

    void Log(LogLevel level, const std::string &message, const std::string &prefix) {
        EpochTimestamp ts = now();
        LogEntry entry = {level, message, ts};
        const std::string level_str = get_prefix(level);
        #ifdef LOGGER_COLOR
        std::string style = std::string(get_level_color(level));
        std::string msg = std::format("{} [{}] {}{}{}", level_str, ts.str, style, prefix + message, RESET);
        #else
        std::string msg = std::format("{} [{}] {} {}", level_str, ts.str, prefix, message);
        #endif
        #ifdef LOGGER_FILE
        if (mode & FILE) { writeToFile(msg); }
        #endif
        #ifdef LOGGER_STDOUT
        if (mode & STDOUT) { std::cout << msg << std::endl; }
        #endif
        #ifdef LOGGER_STDERR
        if (mode & STDERR) { std::cerr << msg << std::endl; }
        #endif
        #ifdef LOGGER_BUFFER
        if (mode & BUFFER) { logs.push_back(entry); }
        #endif
    }



    void _Noop(const std::string& message, const std::string& prefix = "") {}
    void _Info(const std::string &message, const std::string &prefix) { Log(LogLevel::INFO, message, prefix); }
    void _Warning(const std::string &message, const std::string &prefix) { Log(LogLevel::WARNING, message, prefix); }
    void _Error(const std::string &message, const std::string &prefix) { Log(LogLevel::ERROR, message, prefix); }
    void _Debug(const std::string &message, const std::string &prefix) { Log(LogLevel::DEBUG, message, prefix); }
    void _Verbose(const std::string &message, const std::string &prefix) { Log(LogLevel::VERBOSE, message, prefix); }

   public:
    #ifdef LOGGER_BUFFER
    static std::vector<LogEntry> logs;
    #endif

    void set_level(LogLevel new_level, bool override = false) {
        level = new_level;
        if (level == NOTSET) {
            info_fn = &Logger::_Noop;
            warning_fn = &Logger::_Noop;
            error_fn = &Logger::_Noop;
            debug_fn = &Logger::_Noop;
            verbose_fn = &Logger::_Noop;
            return;
        }
        info_fn = (level >= INFO) ? &Logger::_Info : &Logger::_Noop;
        warning_fn = (level >= WARNING) ? &Logger::_Warning : &Logger::_Noop;
        error_fn = (level >= ERROR) ? &Logger::_Error : &Logger::_Noop;
        debug_fn = (level >= DEBUG) ? &Logger::_Debug : &Logger::_Noop;
        #ifdef LOG_VERBOSE_TRUE
        verbose_fn = &Logger::_Verbose;
        #else
        if (override) {
            verbose_fn = &Logger::_Verbose;
        } else {
            verbose_fn = &Logger::_Noop;
        }
        #endif
    }

    #ifdef LOGGER_FILE 
    Logger(
        LogLevel level = NOTSET, 
        LoggingMode mode = NONE,
        std::filesystem::path path = LOGGER_FILE_PATH, 
        int rotations = LOGGER_FILE_ROTATIONS, 
        int max_file_size = LOGGER_FILE_MAX_SIZE
    ) : 
        level(level), 
        mode(mode), 
        log_file_path(path), 
        max_rotations(rotations), 
        max_file_size(max_file_size)
    { set_level(level);log_file.open(path, std::ios_base::app); }
    ~Logger() { if (log_file.is_open()) { log_file.close(); } }
    #else
    Logger(LogLevel level = NOTSET, LoggingMode mode = NONE) : level(level), mode(mode) { set_level(level); }
    ~Logger() {}
    #endif
    
    void Info(const std::string& message, const std::string& prefix = "") { (this->*info_fn)(message, prefix); }
    void Warning(const std::string& message, const std::string& prefix = "") { (this->*warning_fn)(message, prefix); }
    void Error(const std::string& message, const std::string& prefix = "") { (this->*error_fn)(message, prefix); }
    void Debug(const std::string& message, const std::string& prefix = "") { (this->*debug_fn)(message, prefix); }
    void Verbose(const std::string& message, const std::string& prefix = "") { (this->*verbose_fn)(message, prefix); }

    void Print(const std::string& message, const std::string& prefix = "", const std::string style = "") {
        std::string styled_message = style + message + RESET;
        std::cout << prefix << styled_message << std::endl;
    }

    void KeyValue(const std::string& key, const std::string& value, const std::string& prefix = "", const std::string style1 = "", const std::string style2 = "") {
        std::string styled_key = style1 + key + RESET;
        std::string styled_value = style2 + value + RESET;
        std::cout << prefix << styled_key << ": " << styled_value << std::endl;
    }

};

#ifdef LOGGER_FILE
inline Logger g_logger(_build_log_level(), _build_logging_mode(), LOGGER_FILE_PATH, LOGGER_FILE_ROTATIONS, LOGGER_FILE_MAX_SIZE);
#else
inline Logger g_logger(_build_log_level(), _build_logging_mode());
#endif

#ifdef LOGGER_BUFFER
inline std::vector<LogEntry> Logger::logs; 
#endif

#ifdef LOG_VERBOSE_TRUE
#ifdef __FILE_NAME__
#define SHORT_FILE __FILE_NAME__
#else
#define SHORT_FILE __FILE__
#endif
#define LOG_V(msg) g_logger.Verbose(msg, std::string("[") + SHORT_FILE + "::" + __func__ + "[" + std::to_string(__LINE__) + "]")
#define LOG_ERR(msg) g_logger.Error(msg, std::string("[") + SHORT_FILE + "::" + __func__ + "[" + std::to_string(__LINE__) + "]")
define LOG_ASSERT(expr, msg) do { \
    if (!(expr)) { \
        g_logger.Error(std::string("Assertion failed: ") + (msg), std::string("[") + SHORT_FILE + "::" + __func__ + "[" + std::to_string(__LINE__) + "]"); \
        assert(expr); \
    } \
} while(0)
#else
#define LOG_V(msg)
#define LOG_ERR(msg)
#define LOG_ASSERT(expr, msg)
#endif

}  // namespace LoggerCub
