#pragma once

#include <string>
#include "../epoch_timestamp.h"

using namespace TimeCub;

namespace LogCub {
    #ifdef LOGGER_FILE
    #define MEGABYTE (1024 * 1024)
    #ifndef LOGGER_FILE_PATH
    #define LOGGER_FILE_PATH "general.log"
    #endif
    
    #ifndef LOGGER_FILE_ROTATIONS
    #define LOGGER_FILE_ROTATIONS 5
    #endif
    
    #ifndef LOGGER_FILE_MAX_SIZE
    #define LOGGER_FILE_MAX_SIZE 5 * MEGABYTE
    #endif
    #endif
    
    #ifdef LOGGER_VERBOSE
    #define LOG_VERBOSE_TRUE
    #endif
    
    constexpr const char *INFO_PREFIX = "[INFO]";
    constexpr const char *ERROR_PREFIX = "[ERROR]";
    constexpr const char *WARNING_PREFIX = "[WARNING]";
    constexpr const char *DEBUG_PREFIX = "[DEBUG]";
    constexpr const char *VERBOSE_PREFIX = "[VERBOSE]";
    
    static inline const std::string get_prefix(LogLevel level){
        switch (level) {
            case LogLevel::INFO: return INFO_PREFIX;
            case LogLevel::ERROR: return ERROR_PREFIX;
            case LogLevel::WARNING: return WARNING_PREFIX;
            case LogLevel::DEBUG: return DEBUG_PREFIX;
            case LogLevel::VERBOSE: return VERBOSE_PREFIX;
            default: return "";
        }
    } 
    
    enum LoggingMode {
        NONE = 0,
        FILE = 1 << 0,    // 0b0001
        STDOUT = 1 << 1,  // 0b0010
        STDERR = 1 << 2,  // 0b0100
        BUFFER = 1 << 3   // 0b1000
    };
    
    enum LogLevel {
        NOTSET = 0,
        INFO,
        WARNING,
        ERROR,
        DEBUG,
        VERBOSE
    };
    
    struct LogEntry {
        LogLevel level;
        std::string message;
        EpochTimestamp timestamp;
    };

    constexpr LoggingMode _build_logging_mode() {
        int mode = NONE;
        #ifdef LOGGER_STDOUT
            mode |= STDOUT;
        #endif
        #ifdef LOGGER_STDERR
            mode |= STDERR;
        #endif
        #ifdef LOGGER_FILE
            mode |= FILE;
        #endif
        #ifdef LOGGER_BUFFER
            mode |= BUFFER;
        #endif
        return static_cast<LoggingMode>(mode);
    }
    
    constexpr LogLevel _build_log_level() {
        #ifdef LOGGER_LEVEL_INFO
            return INFO;
        #elif defined(LOGGER_LEVEL_WARNING)
            return WARNING;
        #elif defined(LOGGER_LEVEL_ERROR)
            return ERROR;
        #elif defined(LOGGER_LEVEL_DEBUG)
            return DEBUG;
        #else
            return NOTSET;
        #endif
    }
}
