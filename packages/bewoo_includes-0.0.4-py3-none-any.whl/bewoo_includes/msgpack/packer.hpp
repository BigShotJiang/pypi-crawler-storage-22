#pragma once

#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <type_traits>

#include "constants.hpp"

namespace MsgPackCub {

constexpr size_t MAX_BUFFER_SIZE = 1024 * 1024;  // 1 MB

class Packer {
   private:
    std::vector<uint8_t> buffer_;

    /**
     * @brief Write a single byte to the buffer.
     * @param byte The byte to write
     */
    inline void write_byte(uint8_t byte) {
        buffer_.push_back(byte);
    }

    /**
     * @brief Write multiple bytes to the buffer.
     * @param data Pointer to the byte data
     * @param len Number of bytes to write
     */
    inline void write_bytes(const uint8_t* data, size_t len) {
        buffer_.insert(buffer_.end(), data, data + len);
    }

    /**
     * @brief Write big-endian uint16
     * @param value The uint16 value to write
     */
    inline void write_uint16(uint16_t value) {
        uint8_t bytes[2] = {
            static_cast<uint8_t>(value >> 8),
            static_cast<uint8_t>(value & 0xFF)};
        write_bytes(bytes, 2);
    }

    /**
     * @brief Write big-endian uint32
     * @param value The uint32 value to write
     */
    inline void write_uint32(uint32_t value) {
        uint8_t bytes[4] = {
            static_cast<uint8_t>((value >> 24) & 0xFF),
            static_cast<uint8_t>((value >> 16) & 0xFF),
            static_cast<uint8_t>((value >> 8) & 0xFF),
            static_cast<uint8_t>(value & 0xFF)};
        write_bytes(bytes, 4);
    }

    /**
     * @brief Write big-endian uint64
     * @param value The uint64 value to write
     */
    inline void write_uint64(uint64_t value) {
        uint8_t bytes[8] = {
            static_cast<uint8_t>((value >> 56) & 0xFF),
            static_cast<uint8_t>((value >> 48) & 0xFF),
            static_cast<uint8_t>((value >> 40) & 0xFF),
            static_cast<uint8_t>((value >> 32) & 0xFF),
            static_cast<uint8_t>((value >> 24) & 0xFF),
            static_cast<uint8_t>((value >> 16) & 0xFF),
            static_cast<uint8_t>((value >> 8) & 0xFF),
            static_cast<uint8_t>(value & 0xFF)};
        write_bytes(bytes, 8);
    }

    /**
     * @brief Write a float64 value
     * @param value The float64 value to write
     */
    inline void write_float64(double value) {
        uint64_t bits;
        std::memcpy(&bits, &value, sizeof(double));
        write_uint64(bits);
    }

    /**
     * @brief Pack an integer value
     * @param value The integer value to pack
     */
    void _pack_int(int64_t value) {
        // Positive fixint: 0..127
        if (value >= 0 && value <= 127) {
            write_byte(static_cast<uint8_t>(value));
            return;
        }

        // Negative fixint: -32..-1
        if (value >= -32 && value < 0) {
            write_byte(static_cast<uint8_t>(value & 0xFF));
            return;
        }

        // Choose smallest representation
        if (value >= 0) {
            // Unsigned
            if (value <= UINT8_MAX) {
                write_byte(tag::UINT8);
                write_byte(static_cast<uint8_t>(value));
            } else if (value <= UINT16_MAX) {
                write_byte(tag::UINT16);
                write_uint16(static_cast<uint16_t>(value));
            } else if (value <= UINT32_MAX) {
                write_byte(tag::UINT32);
                write_uint32(static_cast<uint32_t>(value));
            } else {
                write_byte(tag::UINT64);
                write_uint64(static_cast<uint64_t>(value));
            }
        } else {
            // Signed
            if (value >= INT8_MIN) {
                write_byte(tag::INT8);
                write_byte(static_cast<uint8_t>(value & 0xFF));
            } else if (value >= INT16_MIN) {
                write_byte(tag::INT16);
                write_uint16(static_cast<uint16_t>(value & 0xFFFF));
            } else if (value >= INT32_MIN) {
                write_byte(tag::INT32);
                write_uint32(static_cast<uint32_t>(value & 0xFFFFFFFF));
            } else {
                write_byte(tag::INT64);
                write_uint64(static_cast<uint64_t>(value));
            }
        }
    }

    /**
     * @brief Pack a string value
     * @param data Pointer to the string data
     * @param len Length of the string
     */
    void pack_string(const char* data, size_t len) {
        // fixstr: 0-31 bytes
        if (len <= 31) {
            write_byte(tag::FIXSTR_BASE | static_cast<uint8_t>(len));
        } else if (len <= UINT8_MAX) {
            write_byte(tag::STR8);
            write_byte(static_cast<uint8_t>(len));
        } else if (len <= UINT16_MAX) {
            write_byte(tag::STR16);
            write_uint16(static_cast<uint16_t>(len));
        } else if (len <= UINT32_MAX) {
            write_byte(tag::STR32);
            write_uint32(static_cast<uint32_t>(len));
        } else {
            throw std::runtime_error("String too long for MessagePack");
        }
        write_bytes(reinterpret_cast<const uint8_t*>(data), len);
    }

    /**
     * @brief Pack binary data
     * @param data Pointer to the binary data
     * @param len Length of the binary data
     */
    void pack_binary(const uint8_t* data, size_t len) {
        if (len <= UINT8_MAX) {
            write_byte(tag::BIN8);
            write_byte(static_cast<uint8_t>(len));
        } else if (len <= UINT16_MAX) {
            write_byte(tag::BIN16);
            write_uint16(static_cast<uint16_t>(len));
        } else if (len <= UINT32_MAX) {
            write_byte(tag::BIN32);
            write_uint32(static_cast<uint32_t>(len));
        } else {
            throw std::runtime_error("Binary data too long for MessagePack");
        }
        write_bytes(data, len);
    }

    /**
     * @brief Pack array header
     * @param len Length of the array
     */
    void pack_array_header(size_t len) {
        if (len <= 15) {
            write_byte(tag::FIXARRAY_BASE | static_cast<uint8_t>(len));
        } else if (len <= UINT16_MAX) {
            write_byte(tag::ARRAY16);
            write_uint16(static_cast<uint16_t>(len));
        } else if (len <= UINT32_MAX) {
            write_byte(tag::ARRAY32);
            write_uint32(static_cast<uint32_t>(len));
        } else {
            throw std::runtime_error("Array too long for MessagePack");
        }
    }

    /**
     * @brief Pack map header
     * @param len Length of the map
     */
    void pack_map_header(size_t len) {
        if (len <= 15) {
            write_byte(tag::FIXMAP_BASE | static_cast<uint8_t>(len));
        } else if (len <= UINT16_MAX) {
            write_byte(tag::MAP16);
            write_uint16(static_cast<uint16_t>(len));
        } else if (len <= UINT32_MAX) {
            write_byte(tag::MAP32);
            write_uint32(static_cast<uint32_t>(len));
        } else {
            throw std::runtime_error("Map too long for MessagePack");
        }
    }

   public:
    Packer() {
        buffer_.reserve(MAX_BUFFER_SIZE);
    }

    void clear() {
        buffer_.clear();
    }

    std::vector<uint8_t> get_buffer() const {
        return buffer_;
    }

    const uint8_t* data() const {
        return buffer_.data();
    }

    size_t size() const {
        return buffer_.size();
    }

    void pack_nil() {
        write_byte(tag::NIL);
    }

    void pack_bool(bool value) {
        write_byte(value ? tag::TRUE : tag::FALSE);
    }

    void pack_int(int64_t value) {
        _pack_int(value);
    }

    void pack_uint(uint64_t value) {
        if (value <= 127) {
            write_byte(static_cast<uint8_t>(value));
        } else if (value <= UINT8_MAX) {
            write_byte(tag::UINT8);
            write_byte(static_cast<uint8_t>(value));
        } else if (value <= UINT16_MAX) {
            write_byte(tag::UINT16);
            write_uint16(static_cast<uint16_t>(value));
        } else if (value <= UINT32_MAX) {
            write_byte(tag::UINT32);
            write_uint32(static_cast<uint32_t>(value));
        } else {
            write_byte(tag::UINT64);
            write_uint64(value);
        }
    }

    void pack_double(double value) {
        write_byte(tag::FLOAT64);
        write_float64(value);
    }

    void pack_string(const std::string& str) {
        pack_string(str.c_str(), str.size());
    }

    void pack_binary(const std::vector<uint8_t>& data) {
        pack_binary(data.data(), data.size());
    }

    void pack_vector(const std::vector<int>& vec) {
        pack_array_header(vec.size());
        for (int val : vec) {
            _pack_int(val);
        }
    }

    void pack_map(const std::unordered_map<std::string, int>& map) {
        pack_map_header(map.size());
        for (const auto& [key, value] : map) {
            pack_string(key);
            _pack_int(value);
        }
    }

    // Pack a MsgPackValue (recursive)
    void pack(const MsgPackValue& value);
};

inline void Packer::pack(const MsgPackValue& value) {
    std::visit([this](auto&& arg) {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, std::nullptr_t>) {
            pack_nil();
        } else if constexpr (std::is_same_v<T, bool>) {
            pack_bool(arg);
        } else if constexpr (std::is_same_v<T, int64_t>) {
            pack_int(arg);
        } else if constexpr (std::is_same_v<T, uint64_t>) {
            pack_uint(arg);
        } else if constexpr (std::is_same_v<T, double>) {
            pack_double(arg);
        } else if constexpr (std::is_same_v<T, std::string>) {
            pack_string(arg);
        } else if constexpr (std::is_same_v<T, std::vector<uint8_t>>) {
            pack_binary(arg);
        } else if constexpr (std::is_same_v<T, MsgPackArray>) {
            pack_array_header(arg.size());
            for (const auto& item : arg) {
                pack(item);
            }
        } else if constexpr (std::is_same_v<T, MsgPackMap>) {
            pack_map_header(arg.size());
            for (const auto& [key, val] : arg) {
                pack_string(key);
                pack(val);
            }
        }
    },
               value.data);
}

}  // namespace MsgPackCub
