#ifndef MSGPACK_PACK_HPP
#define MSGPACK_PACK_HPP

#include <Python.h>
#include <cstdint>
#include <cstring>
#include <vector>
#include <stdexcept>
#include <unordered_map>
#include "constants.hpp"

namespace msgpack {

    constexpr size_t MAX_BUFFER_SIZE = 1024 * 1024; // 1 MB

class Packer {
private:
    std::vector<uint8_t> buffer_;

    /**
     * @brief Write a single byte to the buffer.
     * @param byte The byte to write
    */
    inline void write_byte(uint8_t byte) {
        buffer_.push_back(byte);
    }

    /**
     * @brief Write multiple bytes to the buffer.
     * @param data Pointer to the byte data
     * @param len Number of bytes to write
    */
    inline void write_bytes(const uint8_t* data, size_t len) {
        buffer_.insert(buffer_.end(), data, data + len);
    }

    /**
     * @brief Write big-endian uint16
     * @param value The uint16 value to write
    */
    inline void write_uint16(uint16_t value) {
        uint8_t bytes[2] = {
            static_cast<uint8_t>(value >> 8),
            static_cast<uint8_t>(value & 0xFF)
        };
        write_bytes(bytes, 2);
    }

    /**
     * @brief Write big-endian uint32
     * @param value The uint32 value to write
    */
    inline void write_uint32(uint32_t value) {
        uint8_t bytes[4] = {
            static_cast<uint8_t>((value >> 24) & 0xFF),
            static_cast<uint8_t>((value >> 16) & 0xFF),
            static_cast<uint8_t>((value >> 8) & 0xFF),
            static_cast<uint8_t>(value & 0xFF)
        };
        write_bytes(bytes, 4);
    }

    /**
     * @brief Write big-endian uint64
     * @param value The uint64 value to write
    */
    inline void write_uint64(uint64_t value) {
        uint8_t bytes[8] = {
            static_cast<uint8_t>((value >> 56) & 0xFF),
            static_cast<uint8_t>((value >> 48) & 0xFF),
            static_cast<uint8_t>((value >> 40) & 0xFF),
            static_cast<uint8_t>((value >> 32) & 0xFF),
            static_cast<uint8_t>((value >> 24) & 0xFF),
            static_cast<uint8_t>((value >> 16) & 0xFF),
            static_cast<uint8_t>((value >> 8) & 0xFF),
            static_cast<uint8_t>(value & 0xFF)
        };
        write_bytes(bytes, 8);
    }

    /**
     * @brief Write a float64 value
     * @param value The float64 value to write
    */
    inline void write_float64(double value) {
        uint64_t bits;
        std::memcpy(&bits, &value, sizeof(double));
        write_uint64(bits);
    }

    /**
     * @brief Pack an integer value
     * @param value The integer value to pack
    */
    void _pack_int(int64_t value) {
        // Positive fixint: 0..127
        if (value >= 0 && value <= 127) {
            write_byte(static_cast<uint8_t>(value));
            return;
        }

        // Negative fixint: -32..-1
        if (value >= -32 && value < 0) {
            write_byte(static_cast<uint8_t>(value & 0xFF));
            return;
        }

        // Choose smallest representation
        if (value >= 0) {
            // Unsigned
            if (value <= UINT8_MAX) {
                write_byte(tag::UINT8);
                write_byte(static_cast<uint8_t>(value));
            } else if (value <= UINT16_MAX) {
                write_byte(tag::UINT16);
                write_uint16(static_cast<uint16_t>(value));
            } else if (value <= UINT32_MAX) {
                write_byte(tag::UINT32);
                write_uint32(static_cast<uint32_t>(value));
            } else {
                write_byte(tag::UINT64);
                write_uint64(static_cast<uint64_t>(value));
            }
        } else {
            // Signed
            if (value >= INT8_MIN) {
                write_byte(tag::INT8);
                write_byte(static_cast<uint8_t>(value & 0xFF));
            } else if (value >= INT16_MIN) {
                write_byte(tag::INT16);
                write_uint16(static_cast<uint16_t>(value & 0xFFFF));
            } else if (value >= INT32_MIN) {
                write_byte(tag::INT32);
                write_uint32(static_cast<uint32_t>(value & 0xFFFFFFFF));
            } else {
                write_byte(tag::INT64);
                write_uint64(static_cast<uint64_t>(value));
            }
        }
    }

    /**
     * @brief Pack a string value
     * @param data Pointer to the string data
     * @param len Length of the string
    */
    void pack_string(const char* data, size_t len) {
        // fixstr: 0-31 bytes
        if (len <= 31) {
            write_byte(tag::FIXSTR_BASE | static_cast<uint8_t>(len));
        } else if (len <= UINT8_MAX) {
            write_byte(tag::STR8);
            write_byte(static_cast<uint8_t>(len));
        } else if (len <= UINT16_MAX) {
            write_byte(tag::STR16);
            write_uint16(static_cast<uint16_t>(len));
        } else if (len <= UINT32_MAX) {
            write_byte(tag::STR32);
            write_uint32(static_cast<uint32_t>(len));
        } else {
            throw std::runtime_error("String too long for MessagePack");
        }
        write_bytes(reinterpret_cast<const uint8_t*>(data), len);
    }

    /**
     * @brief Pack binary data
     * @param data Pointer to the binary data
     * @param len Length of the binary data
    */
    void pack_binary(const uint8_t* data, size_t len) {
        if (len <= UINT8_MAX) {
            write_byte(tag::BIN8);
            write_byte(static_cast<uint8_t>(len));
        } else if (len <= UINT16_MAX) {
            write_byte(tag::BIN16);
            write_uint16(static_cast<uint16_t>(len));
        } else if (len <= UINT32_MAX) {
            write_byte(tag::BIN32);
            write_uint32(static_cast<uint32_t>(len));
        } else {
            throw std::runtime_error("Binary data too long for MessagePack");
        }
        write_bytes(data, len);
    }

    /**
     * @brief Pack array header
     * @param len Length of the array
    */
    void pack_array_header(size_t len) {
        if (len <= 15) {
            write_byte(tag::FIXARRAY_BASE | static_cast<uint8_t>(len));
        } else if (len <= UINT16_MAX) {
            write_byte(tag::ARRAY16);
            write_uint16(static_cast<uint16_t>(len));
        } else if (len <= UINT32_MAX) {
            write_byte(tag::ARRAY32);
            write_uint32(static_cast<uint32_t>(len));
        } else {
            throw std::runtime_error("Array too long for MessagePack");
        }
    }

    /**
     * @brief Pack map header
     * @param len Length of the map
    */
    void pack_map_header(size_t len) {
        if (len <= 15) {
            write_byte(tag::FIXMAP_BASE | static_cast<uint8_t>(len));
        } else if (len <= UINT16_MAX) {
            write_byte(tag::MAP16);
            write_uint16(static_cast<uint16_t>(len));
        } else if (len <= UINT32_MAX) {
            write_byte(tag::MAP32);
            write_uint32(static_cast<uint32_t>(len));
        } else {
            throw std::runtime_error("Map too long for MessagePack");
        }
    }

    void pack_object(PyObject* obj);

public:
    Packer() {
        buffer_.reserve(MAX_BUFFER_SIZE);
    }

    void pack(PyObject* obj) {
        pack_object(obj);
    }

    PyObject* get_bytes() {
        return PyBytes_FromStringAndSize(
            reinterpret_cast<const char*>(buffer_.data()),
            buffer_.size()
        );
    }

    void clear() {
        buffer_.clear();
    }

    std::vector<uint8_t> get_buffer() const {
        return buffer_;
    }

    const uint8_t* data() const {
        return buffer_.data();
    }

    size_t size() const {
        return buffer_.size();
    }

    void pack_int(int64_t value) {
        _pack_int(value);
    }

    void pack_string(const std::string& str) {
        pack_string(str.c_str(), str.size());
    }

    void pack_vector(const std::vector<int>& vec) {
        pack_array_header(vec.size());
        for (int val : vec) {
            _pack_int(val);
        }
    }

    void pack_map(const std::unordered_map<std::string, int>& map) {
        pack_map_header(map.size());
        for (const auto& [key, value] : map) {
            pack_string(key);
            _pack_int(value);
        }
    }

    template<typename T>
    void pack_value(const T& value);
};

inline void Packer::pack_object(PyObject* obj) {
    /**
     * @brief Pack a Python object into MessagePack format
     * @param obj The Python object to pack
    */
    if (obj == Py_None) {
        write_byte(tag::NIL);
        return;
    }

    /**
     * @brief Pack a boolean value
     * @param obj The Python boolean object
    */
    if (PyBool_Check(obj)) {
        write_byte(obj == Py_True ? tag::TRUE : tag::FALSE);
        return;
    }

    /**
     * @brief Pack an integer value
     * @param obj The Python integer object
    */
    if (PyLong_Check(obj)) {
        int64_t value = PyLong_AsLongLong(obj);
        if (value == -1 && PyErr_Occurred()) {
            // Handle overflow - could be unsigned 64-bit
            PyErr_Clear();
            uint64_t uvalue = PyLong_AsUnsignedLongLong(obj);
            if (uvalue == static_cast<uint64_t>(-1) && PyErr_Occurred()) {
                throw std::runtime_error("Integer too large for MessagePack");
            }
            write_byte(tag::UINT64);
            write_uint64(uvalue);
            return;
        }
        _pack_int(value);
        return;
    }

    /**
     * @brief Pack a float value
     * @param obj The Python float object
    */
    if (PyFloat_Check(obj)) {
        write_byte(tag::FLOAT64);
        write_float64(PyFloat_AS_DOUBLE(obj));
        return;
    }

    /**
     * @brief Pack a string value
     * @param obj The Python string object
    */
    if (PyUnicode_Check(obj)) {
        Py_ssize_t size;
        const char* data = PyUnicode_AsUTF8AndSize(obj, &size);
        if (!data) {
            throw std::runtime_error("Failed to encode string as UTF-8");
        }
        pack_string(data, size);
        return;
    }

    /**
     * @brief Pack binary data
     * @param obj The Python bytes object
    */
    if (PyBytes_Check(obj)) {
        char* data;
        Py_ssize_t size;
        if (PyBytes_AsStringAndSize(obj, &data, &size) < 0) {
            throw std::runtime_error("Failed to get bytes data");
        }
        pack_binary(reinterpret_cast<const uint8_t*>(data), size);
        return;
    }

    /**
     * @brief Pack a list or tuple
     * @param obj The Python list or tuple object
    */
    if (PyList_Check(obj) || PyTuple_Check(obj)) {
        Py_ssize_t len = PySequence_Size(obj);
        pack_array_header(len);

        for (Py_ssize_t i = 0; i < len; ++i) {
            PyObject* item = PySequence_GetItem(obj, i);
            if (!item) {
                throw std::runtime_error("Failed to get sequence item");
            }
            pack_object(item);
            Py_DECREF(item);
        }
        return;
    }

    /**
     * @brief Pack a dictionary
     * @param obj The Python dictionary object
    */
    if (PyDict_Check(obj)) {
        Py_ssize_t len = PyDict_Size(obj);
        pack_map_header(len);

        PyObject *key, *value;
        Py_ssize_t pos = 0;

        while (PyDict_Next(obj, &pos, &key, &value)) {
            pack_object(key);
            pack_object(value);
        }
        return;
    }

    /**
     * @brief Unsupported type error
     * @param obj The unsupported Python object
    */
    PyObject* type_name = PyObject_GetAttrString(reinterpret_cast<PyObject*>(Py_TYPE(obj)), "__name__");
    const char* name = type_name ? PyUnicode_AsUTF8(type_name) : "unknown";
    Py_XDECREF(type_name);
    throw std::runtime_error(std::string("Unsupported type for packing: ") + name);
}

} // namespace msgpack

#endif // MSGPACK_PACK_HPP
