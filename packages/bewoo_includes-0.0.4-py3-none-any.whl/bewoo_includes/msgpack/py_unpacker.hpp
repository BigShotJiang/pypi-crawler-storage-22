#ifndef MSGPACK_UNPACK_HPP
#define MSGPACK_UNPACK_HPP

#include <Python.h>
#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>
#include "constants.hpp"

namespace msgpack {

class Unpacker {
private:
    const uint8_t* buf_;
    size_t pos_;
    size_t buf_len_;

    // Read big-endian integers
    inline uint16_t read_uint16() {
        uint16_t result = (static_cast<uint16_t>(buf_[pos_]) << 8) | buf_[pos_ + 1];
        pos_ += 2;
        return result;
    }

    inline uint32_t read_uint32() {
        uint32_t result = (static_cast<uint32_t>(buf_[pos_]) << 24) |
                         (static_cast<uint32_t>(buf_[pos_ + 1]) << 16) |
                         (static_cast<uint32_t>(buf_[pos_ + 2]) << 8) |
                         static_cast<uint32_t>(buf_[pos_ + 3]);
        pos_ += 4;
        return result;
    }

    inline uint64_t read_uint64() {
        uint64_t result = (static_cast<uint64_t>(buf_[pos_]) << 56) |
                         (static_cast<uint64_t>(buf_[pos_ + 1]) << 48) |
                         (static_cast<uint64_t>(buf_[pos_ + 2]) << 40) |
                         (static_cast<uint64_t>(buf_[pos_ + 3]) << 32) |
                         (static_cast<uint64_t>(buf_[pos_ + 4]) << 24) |
                         (static_cast<uint64_t>(buf_[pos_ + 5]) << 16) |
                         (static_cast<uint64_t>(buf_[pos_ + 6]) << 8) |
                         static_cast<uint64_t>(buf_[pos_ + 7]);
        pos_ += 8;
        return result;
    }

    inline double read_float64() {
        uint64_t bits = read_uint64();
        double result;
        std::memcpy(&result, &bits, sizeof(double));
        return result;
    }

    // Read string from buffer
    inline PyObject* read_string(size_t length) {
        if (pos_ + length > buf_len_) {
            throw std::runtime_error("Buffer overflow reading string");
        }
        PyObject* bytes_obj = PyBytes_FromStringAndSize(
            reinterpret_cast<const char*>(&buf_[pos_]), length
        );
        if (!bytes_obj) return nullptr;

        pos_ += length;

        PyObject* str_obj = PyUnicode_FromEncodedObject(bytes_obj, "utf-8", "strict");
        Py_DECREF(bytes_obj);
        return str_obj;
    }

    // Read raw bytes from buffer
    inline PyObject* read_bytes(size_t length) {
        if (pos_ + length > buf_len_) {
            throw std::runtime_error("Buffer overflow reading bytes");
        }
        PyObject* result = PyBytes_FromStringAndSize(
            reinterpret_cast<const char*>(&buf_[pos_]), length
        );
        pos_ += length;
        return result;
    }

    // Forward declaration for recursive unpacking
    PyObject* unpack_one();

    // Unpack array of given length
    PyObject* unpack_array(size_t length) {
        PyObject* list = PyList_New(length);
        if (!list) return nullptr;

        for (size_t i = 0; i < length; ++i) {
            PyObject* item = unpack_one();
            if (!item) {
                Py_DECREF(list);
                return nullptr;
            }
            PyList_SET_ITEM(list, i, item);  // Steals reference
        }
        return list;
    }

    // Unpack map of given length
    PyObject* unpack_map(size_t length) {
        PyObject* dict = PyDict_New();
        if (!dict) return nullptr;

        for (size_t i = 0; i < length; ++i) {
            PyObject* key = unpack_one();
            if (!key) {
                Py_DECREF(dict);
                return nullptr;
            }

            PyObject* value = unpack_one();
            if (!value) {
                Py_DECREF(key);
                Py_DECREF(dict);
                return nullptr;
            }

            if (PyDict_SetItem(dict, key, value) < 0) {
                Py_DECREF(key);
                Py_DECREF(value);
                Py_DECREF(dict);
                return nullptr;
            }

            Py_DECREF(key);
            Py_DECREF(value);
        }
        return dict;
    }

public:
    Unpacker(const uint8_t* buf, size_t buf_len)
        : buf_(buf), pos_(0), buf_len_(buf_len) {}

    PyObject* unpack() {
        return unpack_one();
    }
};

// Implementation of unpack_one (must be after class definition for member access)
inline PyObject* Unpacker::unpack_one() {
    if (pos_ >= buf_len_) {
        PyErr_SetString(PyExc_ValueError, "Unexpected end of buffer");
        return nullptr;
    }

    uint8_t tag_byte = buf_[pos_++];

    // Positive fixint: 0x00 - 0x7F
    if ((tag_byte & tag::POS_FIXINT_MASK) == 0) {
        return PyLong_FromLong(tag_byte);
    }

    // Negative fixint: 0xE0 - 0xFF
    if ((tag_byte & tag::NEG_FIXINT_MASK) == tag::NEG_FIXINT_BASE) {
        return PyLong_FromLong(static_cast<int8_t>(tag_byte));
    }

    // Fixstr: 0xA0 - 0xBF
    if ((tag_byte & tag::FIXSTR_MASK) == tag::FIXSTR_BASE) {
        size_t length = tag_byte & 0x1F;
        return read_string(length);
    }

    // Fixarray: 0x90 - 0x9F
    if ((tag_byte & tag::FIXARRAY_MASK) == tag::FIXARRAY_BASE) {
        size_t length = tag_byte & 0x0F;
        return unpack_array(length);
    }

    // Fixmap: 0x80 - 0x8F
    if ((tag_byte & tag::FIXMAP_MASK) == tag::FIXMAP_BASE) {
        size_t length = tag_byte & 0x0F;
        return unpack_map(length);
    }

    // Literals
    switch (tag_byte) {
        case tag::NIL:
            Py_RETURN_NONE;
        case tag::FALSE:
            Py_RETURN_FALSE;
        case tag::TRUE:
            Py_RETURN_TRUE;

        // Unsigned integers
        case tag::UINT8:
            return PyLong_FromUnsignedLong(buf_[pos_++]);
        case tag::UINT16:
            return PyLong_FromUnsignedLong(read_uint16());
        case tag::UINT32:
            return PyLong_FromUnsignedLong(read_uint32());
        case tag::UINT64:
            return PyLong_FromUnsignedLongLong(read_uint64());

        // Signed integers
        case tag::INT8:
            return PyLong_FromLong(static_cast<int8_t>(buf_[pos_++]));
        case tag::INT16:
            return PyLong_FromLong(static_cast<int16_t>(read_uint16()));
        case tag::INT32:
            return PyLong_FromLong(static_cast<int32_t>(read_uint32()));
        case tag::INT64:
            return PyLong_FromLongLong(static_cast<int64_t>(read_uint64()));

        // Float
        case tag::FLOAT64:
            return PyFloat_FromDouble(read_float64());

        // Strings
        case tag::STR8:
            return read_string(buf_[pos_++]);
        case tag::STR16:
            return read_string(read_uint16());
        case tag::STR32:
            return read_string(read_uint32());

        // Binary
        case tag::BIN8:
            return read_bytes(buf_[pos_++]);
        case tag::BIN16:
            return read_bytes(read_uint16());
        case tag::BIN32:
            return read_bytes(read_uint32());

        // Arrays
        case tag::ARRAY16:
            return unpack_array(read_uint16());
        case tag::ARRAY32:
            return unpack_array(read_uint32());

        // Maps
        case tag::MAP16:
            return unpack_map(read_uint16());
        case tag::MAP32:
            return unpack_map(read_uint32());

        default: {
            char error_msg[64];
            snprintf(error_msg, sizeof(error_msg), "Unknown tag: 0x%02X", tag_byte);
            PyErr_SetString(PyExc_ValueError, error_msg);
            return nullptr;
        }
    }
}

} // namespace msgpack

#endif // MSGPACK_UNPACK_HPP
