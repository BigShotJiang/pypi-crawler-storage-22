#pragma once

#include <cstdint>
#include <cstring>
#include <stdexcept>

#include "constants.hpp"

namespace MsgPackCub {

class Unpacker {
   private:
    const uint8_t* buf_;
    size_t pos_;
    size_t buf_len_;

    // Read big-endian integers
    inline uint16_t read_uint16() {
        uint16_t result = (static_cast<uint16_t>(buf_[pos_]) << 8) | buf_[pos_ + 1];
        pos_ += 2;
        return result;
    }

    inline uint32_t read_uint32() {
        uint32_t result = (static_cast<uint32_t>(buf_[pos_]) << 24) |
                          (static_cast<uint32_t>(buf_[pos_ + 1]) << 16) |
                          (static_cast<uint32_t>(buf_[pos_ + 2]) << 8) |
                          static_cast<uint32_t>(buf_[pos_ + 3]);
        pos_ += 4;
        return result;
    }

    inline uint64_t read_uint64() {
        uint64_t result = (static_cast<uint64_t>(buf_[pos_]) << 56) |
                          (static_cast<uint64_t>(buf_[pos_ + 1]) << 48) |
                          (static_cast<uint64_t>(buf_[pos_ + 2]) << 40) |
                          (static_cast<uint64_t>(buf_[pos_ + 3]) << 32) |
                          (static_cast<uint64_t>(buf_[pos_ + 4]) << 24) |
                          (static_cast<uint64_t>(buf_[pos_ + 5]) << 16) |
                          (static_cast<uint64_t>(buf_[pos_ + 6]) << 8) |
                          static_cast<uint64_t>(buf_[pos_ + 7]);
        pos_ += 8;
        return result;
    }

    inline double read_float64() {
        uint64_t bits = read_uint64();
        double result;
        std::memcpy(&result, &bits, sizeof(double));
        return result;
    }

    // Read string from buffer
    inline std::string read_string(size_t length) {
        if (pos_ + length > buf_len_) {
            throw std::runtime_error("Buffer overflow reading string");
        }
        std::string result(reinterpret_cast<const char*>(&buf_[pos_]), length);
        pos_ += length;
        return result;
    }

    // Read raw bytes from buffer
    inline std::vector<uint8_t> read_bytes(size_t length) {
        if (pos_ + length > buf_len_) {
            throw std::runtime_error("Buffer overflow reading bytes");
        }
        std::vector<uint8_t> result(&buf_[pos_], &buf_[pos_ + length]);
        pos_ += length;
        return result;
    }

    // Forward declarations for recursive unpacking
    MsgPackValue unpack_one(); // C++ is dumb
    MsgPackArray unpack_array(size_t length);
    MsgPackMap unpack_map(size_t length);

   public:
    Unpacker(const uint8_t* buf, size_t buf_len)
        : buf_(buf), pos_(0), buf_len_(buf_len) {}

    MsgPackValue unpack() {
        return unpack_one();
    }
};

// Implementation of unpack_one
inline MsgPackValue Unpacker::unpack_one() {
    if (pos_ >= buf_len_) {
        throw std::runtime_error("Unexpected end of buffer");
    }

    uint8_t tag_byte = buf_[pos_++];

    // Positive fixint: 0x00 - 0x7F
    if ((tag_byte & tag::POS_FIXINT_MASK) == 0) {
        return MsgPackValue{static_cast<int64_t>(tag_byte)};
    }

    // Negative fixint: 0xE0 - 0xFF
    if ((tag_byte & tag::NEG_FIXINT_MASK) == tag::NEG_FIXINT_BASE) {
        return MsgPackValue{static_cast<int64_t>(static_cast<int8_t>(tag_byte))};
    }

    // Fixstr: 0xA0 - 0xBF
    if ((tag_byte & tag::FIXSTR_MASK) == tag::FIXSTR_BASE) {
        size_t length = tag_byte & 0x1F;
        return MsgPackValue{read_string(length)};
    }

    // Fixarray: 0x90 - 0x9F
    if ((tag_byte & tag::FIXARRAY_MASK) == tag::FIXARRAY_BASE) {
        size_t length = tag_byte & 0x0F;
        return MsgPackValue{unpack_array(length)};
    }

    // Fixmap: 0x80 - 0x8F
    if ((tag_byte & tag::FIXMAP_MASK) == tag::FIXMAP_BASE) {
        size_t length = tag_byte & 0x0F;
        return MsgPackValue{unpack_map(length)};
    }

    // Literals and sized types
    switch (tag_byte) {
        case tag::NIL:
            return MsgPackValue{nullptr};
        case tag::FALSE:
            return MsgPackValue{false};
        case tag::TRUE:
            return MsgPackValue{true};

        // Unsigned integers
        case tag::UINT8:
            return MsgPackValue{static_cast<uint64_t>(buf_[pos_++])};
        case tag::UINT16:
            return MsgPackValue{static_cast<uint64_t>(read_uint16())};
        case tag::UINT32:
            return MsgPackValue{static_cast<uint64_t>(read_uint32())};
        case tag::UINT64:
            return MsgPackValue{read_uint64()};

        // Signed integers
        case tag::INT8:
            return MsgPackValue{static_cast<int64_t>(static_cast<int8_t>(buf_[pos_++]))};
        case tag::INT16:
            return MsgPackValue{static_cast<int64_t>(static_cast<int16_t>(read_uint16()))};
        case tag::INT32:
            return MsgPackValue{static_cast<int64_t>(static_cast<int32_t>(read_uint32()))};
        case tag::INT64:
            return MsgPackValue{static_cast<int64_t>(read_uint64())};

        // Float
        case tag::FLOAT64:
            return MsgPackValue{read_float64()};

        // Strings
        case tag::STR8:
            return MsgPackValue{read_string(buf_[pos_++])};
        case tag::STR16:
            return MsgPackValue{read_string(read_uint16())};
        case tag::STR32:
            return MsgPackValue{read_string(read_uint32())};

        // Binary
        case tag::BIN8:
            return MsgPackValue{read_bytes(buf_[pos_++])};
        case tag::BIN16:
            return MsgPackValue{read_bytes(read_uint16())};
        case tag::BIN32:
            return MsgPackValue{read_bytes(read_uint32())};

        // Arrays
        case tag::ARRAY16:
            return MsgPackValue{unpack_array(read_uint16())};
        case tag::ARRAY32:
            return MsgPackValue{unpack_array(read_uint32())};

        // Maps
        case tag::MAP16:
            return MsgPackValue{unpack_map(read_uint16())};
        case tag::MAP32:
            return MsgPackValue{unpack_map(read_uint32())};

        default: {
            char error_msg[64];
            snprintf(error_msg, sizeof(error_msg), "Unknown tag: 0x%02X", tag_byte);
            throw std::runtime_error(error_msg);
        }
    }
}

inline MsgPackArray Unpacker::unpack_array(size_t length) {
    MsgPackArray arr;
    arr.reserve(length);
    for (size_t i = 0; i < length; ++i) {
        arr.push_back(unpack_one());
    }
    return arr;
}

inline MsgPackMap Unpacker::unpack_map(size_t length) {
    MsgPackMap map;
    for (size_t i = 0; i < length; ++i) {
        MsgPackValue key_val = unpack_one();
        std::string key = std::get<std::string>(key_val.data);
        map[key] = unpack_one();
    }
    return map;
}

}  // namespace MsgPackCub
