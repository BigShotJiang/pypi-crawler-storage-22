#pragma once

#include <Python.h>
#include <pybind11/pybind11.h>

#include <stdexcept>
#include <string>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>

namespace py = pybind11;

namespace PyConstantsHelper {

using ConstantKeys = std::unordered_set<std::string>;

template <typename T>
struct PythonConstant {
    T value;

    PythonConstant(PyObject* obj) {
        if constexpr (std::is_same_v<T, int>) {
            value = PyLong_AsLong(obj);
        } else if constexpr (std::is_same_v<T, double>) {
            value = PyFloat_AsDouble(obj);
        } else if constexpr (std::is_same_v<T, bool>) {
            value = PyObject_IsTrue(obj);
        } else if constexpr (std::is_same_v<T, std::string>) {
            value = PyUnicode_AsUTF8(obj);
        } else {
            throw std::invalid_argument("Unsupported type");
        }
    }
    ~PythonConstant() = default;
};

struct PyConstants {
    std::unordered_map<std::string, PythonConstant<int>> int_constants;
    std::unordered_map<std::string, PythonConstant<double>> double_constants;
    std::unordered_map<std::string, PythonConstant<bool>> bool_constants;
    std::unordered_map<std::string, PythonConstant<std::string>> string_constants;

    ConstantKeys int_keys;
    ConstantKeys double_keys;
    ConstantKeys bool_keys;
    ConstantKeys string_keys;

    PyConstants() = default;
    ~PyConstants() = default;

    bool has_int_key(const std::string& name) const { return int_keys.count(name) > 0; }
    bool has_double_key(const std::string& name) const { return double_keys.count(name) > 0; }
    bool has_bool_key(const std::string& name) const { return bool_keys.count(name) > 0; }
    bool has_string_key(const std::string& name) const { return string_keys.count(name) > 0; }
    bool has_key(const std::string& name) const { return has_int_key(name) || has_double_key(name) || has_bool_key(name) || has_string_key(name); }
    
    size_t size() const { return int_constants.size() + double_constants.size() + bool_constants.size() + string_constants.size(); }
    bool empty() const { return size() == 0; }

    void add_constant(const std::string& name, PyObject* obj) {
        if (PyBool_Check(obj)) {
            bool_constants.emplace(name, PythonConstant<bool>(obj));
            bool_keys.insert(name);
        } else if (PyLong_Check(obj)) {
            int_constants.emplace(name, PythonConstant<int>(obj));
            int_keys.insert(name);
        } else if (PyFloat_Check(obj)) {
            double_constants.emplace(name, PythonConstant<double>(obj));
            double_keys.insert(name);
        } else if (PyUnicode_Check(obj)) {
            string_constants.emplace(name, PythonConstant<std::string>(obj));
            string_keys.insert(name);
        } else {
            throw std::invalid_argument("Unsupported constant type");
        }
    }

    template <typename T>
    T get_constant(const std::string& name) const {
        if constexpr (std::is_same_v<T, int>) {
            if (has_int_key(name)) {
                return int_constants.at(name).value;
            }
        } else if constexpr (std::is_same_v<T, double>) {
            if (has_double_key(name)) {
                return double_constants.at(name).value;
            }
        } else if constexpr (std::is_same_v<T, bool>) {
            if (has_bool_key(name)) {
                return bool_constants.at(name).value;
            }
        } else if constexpr (std::is_same_v<T, std::string>) {
            if (has_string_key(name)) {
                return string_constants.at(name).value;
            }
        }
        throw std::out_of_range("Constant not found: " + name);
    }
};

// Bind PyConstants class to a pybind11 module (creator side)
//
// Usage:
//   PYBIND11_MODULE(my_module, m) {
//       PyConstantsHelper::bind_py_constants(m);
//   }
//
// Then in Python:
//   constants = my_module.PyConstants()
//   constants.add("WIDTH", 800).add("HEIGHT", 600)
//   other_module.set_constants(constants.ptr())
template <typename Module>
inline void bind_py_constants(Module& m) {
    py::class_<PyConstants>(m, "PyConstants")
        .def(py::init<>())
        .def("add", [](PyConstants& self, const std::string& name, py::object obj) -> PyConstants& {
            self.add_constant(name, obj.ptr());
            return self;
        }, py::return_value_policy::reference, py::arg("name"), py::arg("obj"))
        .def("has_key", &PyConstants::has_key, py::arg("name"))
        .def("has_int_key", &PyConstants::has_int_key, py::arg("name"))
        .def("has_double_key", &PyConstants::has_double_key, py::arg("name"))
        .def("has_bool_key", &PyConstants::has_bool_key, py::arg("name"))
        .def("has_string_key", &PyConstants::has_string_key, py::arg("name"))
        .def("size", &PyConstants::size)
        .def("empty", &PyConstants::empty)
        .def("ptr", [](PyConstants& self) {
            return py::capsule(&self, "PyConstantsHelper::PyConstants");
        }, "Get a capsule containing a pointer to this PyConstants instance");
}

// Bind set_constants to a pybind11 module (consumer side)
//
// Usage:
//   PyConstantsHelper::PyConstants* g_constants = nullptr;
//
//   PYBIND11_MODULE(my_module, m) {
//       PyConstantsHelper::bind_set_constants(m, g_constants);
//   }
template <typename Module>
inline void bind_set_constants(Module& m, PyConstants*& target) {
    m.def("set_constants", [&target](py::capsule cap) {
        void* ptr = PyCapsule_GetPointer(cap.ptr(), "PyConstantsHelper::PyConstants");
        if (!ptr) throw std::runtime_error("Invalid capsule!");
        target = reinterpret_cast<PyConstants*>(ptr);
    }, py::arg("constants"), "Set the constants from a capsule");
}

}  // namespace PyConstantsHelper
