#pragma once
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include "common.h"

namespace StackCub {

    constexpr size_t INITIAL_FREELIST_CAPACITY = 64; // Initial capacity for free entity ID stack
    constexpr size_t NOT_SET_ENTRY = ((size_t)(-1)); // Sentinel value for empty stack position
    constexpr size_t MAX_STACK_SIZE = 1048576;       // Arbitrary upper limit to prevent runaway allocations

    typedef size_t (*CallbackFunc)(void* ctx);

    typedef struct SimpleStack {
        size_t* items;
        size_t count;
        size_t capacity;
    } SimpleStack;

    static inline bool init_simple_stack(SimpleStack* stack) {
        stack->items = (size_t*)malloc(INITIAL_FREELIST_CAPACITY * sizeof(size_t));
        if (stack->items == NULL) {
            return false;
        }
        stack->count = 0;
        stack->capacity = INITIAL_FREELIST_CAPACITY;
        return true;
    }

    static inline bool reset_simple_stack(SimpleStack* stack) {
        stack->items = (size_t*)realloc(stack->items, INITIAL_FREELIST_CAPACITY * sizeof(size_t));
        if (stack->items == NULL) {
            return false;
        }
        stack->capacity = INITIAL_FREELIST_CAPACITY;
        stack->count = 0;
        return true;
    }

    static inline bool stack_grow(SimpleStack* stack) {
        if (stack->capacity >= MAX_STACK_SIZE) {
            return false;
        }

        size_t new_capacity = stack->capacity * 2;

        if (new_capacity > MAX_STACK_SIZE) {
            new_capacity = MAX_STACK_SIZE;
        }

        size_t* new_items = (size_t*)realloc(stack->items, new_capacity * sizeof(size_t));
        if (new_items == NULL) {
            return false;
        }
        stack->items = new_items;
        stack->capacity = new_capacity;
        return true;
    }

    static inline bool stack_push(SimpleStack* stack, size_t value) {
        if (stack->count >= stack->capacity) {
            if (!stack_grow(stack)) {
                return false;
            }
        }
        stack->items[stack->count] = value;
        stack->count++;
        return true;
    }

    static inline size_t stack_pop(SimpleStack* stack) {
        if (stack->count == 0) {
            return NOT_SET_ENTRY;
        }
        stack->count--;
        return stack->items[stack->count];
    }

    static inline size_t pop_or_callback(SimpleStack* stack, CallbackFunc callback, void* ctx) {
        size_t value = stack_pop(stack);
        if (value == NOT_SET_ENTRY) {
            return callback(ctx);
        }
        return value;
    }




    


} // namespace StackCub
