#pragma once

#include <chrono>
#include <iostream>

#include "logger/logger.hpp"

namespace TimerCub {

    struct ScopedTimer {
        const char* name;

        std::chrono::high_resolution_clock::time_point start;
        ScopedTimer(const char* n) : name(n), start(std::chrono::high_resolution_clock::now()) {}
        ~ScopedTimer() {
            auto end = std::chrono::high_resolution_clock::now();
            auto duration_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count();
            double duration_us = duration_ns / 1000.0;
            char buf[64];
            snprintf(buf, sizeof(buf), "%.2f", duration_us);
            LogCub::g_logger.Info(std::string("Timer [") + name + "] took " + buf + " us");
        }
    };

} // TimerCub

#define PROFILE_SCOPE(name) TimerCub::ScopedTimer timer##__LINE__(name)
