from setuptools import setup

setup(name='BezdarSQL',
      version='1.1.1',
      description='My little SQL ORM for the ones who called bezdars',
      packages=['bezdarsql'],
      author_email='boliklevik@gmail.com',
      zip_safe=False)
