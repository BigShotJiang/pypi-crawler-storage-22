from .b_fast import *

__doc__ = b_fast.__doc__
if hasattr(b_fast, "__all__"):
    __all__ = b_fast.__all__