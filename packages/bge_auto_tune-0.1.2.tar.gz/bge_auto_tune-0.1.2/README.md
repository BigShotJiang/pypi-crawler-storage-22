# 🎯 BGE Auto-Tune

**Fine-tune [BAAI/bge-m3](https://huggingface.co/BAAI/bge-m3) on your domain, from scratch.**

BGE Auto-Tune automates the entire pipeline: generates a training dataset from your chunks in Qdrant, runs unified fine-tuning (dense + sparse + ColBERT), and tests retrieval quality by comparing the base model against the fine-tuned one.

```
bge-auto-tune generate   →   create dataset from Qdrant + local LLM
bge-auto-tune finetune   →   train the model
bge-auto-tune test       →   compare base vs fine-tuned
bge-auto-tune run        →   all steps in sequence (for advanced users)
```

---

## Prerequisites

BGE Auto-Tune is not a standalone tool — it relies on three services that must be running.

### 1. Qdrant

A Qdrant instance with a collection populated with text chunks. Chunks must have a `text` field in their payload (configurable with `--text-field`).

```
http://localhost:6333  (default)
```

### 2. Local LLM (OpenAI-compatible API)

A language model accessible via an OpenAI-compatible API. Used for two things: filtering low-quality chunks and generating realistic synthetic queries.

Any model served by **vLLM**, **Ollama** (with OpenAI endpoint), **llama.cpp**, **TGI**, etc. will work.

```
http://localhost:8001/v1  (default)
```

Tested with `Qwen/Qwen3-4B-Instruct-2507` — 4-8B models work great for this task.

### 3. BGE-M3 embedding server

A server exposing the BGE-M3 model for generating embeddings. Used to search for hard negatives in Qdrant during dataset generation.

```
http://localhost:8004  (default)
```

The server must respond on `POST /v1/embeddings` with the standard format.

### Services overview

| Service | Default endpoint | Env var | Purpose |
|---------|-----------------|---------|---------|
| Qdrant | `http://localhost:6333` | `QDRANT_URL` | Source of text chunks |
| LLM | `http://localhost:8001/v1` | `LLM_URL` | Quality filter + query generation |
| Embedding | `http://localhost:8004` | `EMBED_URL` | Hard negatives search |

All endpoints can be configured via env vars or CLI flags.

### Hardware

Fine-tuning requires a **GPU with at least 16 GB VRAM** (24 GB recommended). Dataset generation and testing can run on CPU but are much faster on GPU.

---

## Installation

```bash
pip install bge-auto-tune
```

---

## Recommended workflow (manual pipeline)

**If this is your first time, use the individual commands.** This lets you inspect and validate each step before moving on.

### Step 1 — Generate the dataset

```bash
bge-auto-tune generate \
  --collection my_docs \
  --min-pairs 3000 \
  --queries-per-chunk 3 \
  --hard-negatives 7
```

This produces a `bge_m3_training.jsonl` file. **Open it and review it** before proceeding:

```bash
# How many pairs?
wc -l bge_m3_training.jsonl

# Look at some examples
head -5 bge_m3_training.jsonl | python -m json.tool
```

Check that:
- Queries are realistic and diverse
- Positives are actually relevant to the query
- Negatives are "hard" (similar but incorrect)

If something looks off, adjust parameters and regenerate. It's much better to spend time here than to fine-tune on dirty data.

#### How many pairs do you need?

| Pairs | Expected quality |
|-------|-----------------|
| < 500 | Nearly useless — too little signal |
| 500 – 1,000 | Works only with a very specific domain and clean data |
| 1,000 – 3,000 | Safe zone for most use cases |
| 3,000 – 10,000 | Ideal — robust results |
| > 10,000 | Diminishing returns |

The absolute number matters less than **coverage**: if your corpus has 5,000 chunks but the dataset only covers 200 of them, you'll have huge blind spots. Aim to cover at least 30-50% of your chunks.

### Step 2 — Fine-tune

```bash
bge-auto-tune finetune \
  --dataset bge_m3_training.jsonl \
  --epochs 2 \
  --lr 1e-5 \
  --batch-size 4
```

The model is saved to `./bge-m3-finetuned/`.

> **Note:** fine-tuning always starts from the base model `BAAI/bge-m3`. If you rerun the command, the previous output is **overwritten**. To keep different versions, change `--output`:
>
> ```bash
> bge-auto-tune finetune --output ./bge-m3-finetuned-v2
> ```

### Step 3 — Test

```bash
bge-auto-tune test \
  --model ./bge-m3-finetuned \
  --test-queries 100 \
  --top-k 10
```

The test automatically compares the base model against the fine-tuned one and shows:
- **Recall@K** — is the positive in the top K results?
- **MRR** — at what average position does the positive end up?
- **Rerank accuracy** — does the model assign the highest score to the positive?
- **Qualitative examples** — queries where fine-tuning improved (or worsened) the ranking

If results aren't good, go back to Step 1: more data, better data, or different parameters.

---

## `run` command (automatic pipeline)

For users who have already calibrated their parameters and want to run everything in one shot:

```bash
bge-auto-tune run \
  --collection my_docs \
  --min-pairs 3000 \
  --epochs 2 \
  --lr 1e-5 \
  --verbose
```

Runs `generate → finetune → test` in sequence. If any step fails, it stops.

⚠️ **Use this only when you know your services are working and your parameters are dialed in.** For the first time, use the manual pipeline.

All parameters from individual commands are available in `run`:

```bash
bge-auto-tune run \
  --qdrant-url http://10.0.0.1:6333 \
  --collection docs_v2 \
  --llm-model Qwen/Qwen3-8B \
  --min-pairs 5000 \
  --queries-per-chunk 5 \
  --hard-negatives 10 \
  --epochs 3 \
  --lr 2e-5 \
  --batch-size 8 \
  --test-queries 200 \
  --verbose
```

---

## All parameters

### `bge-auto-tune generate`

| Parameter | Default | Description |
|-----------|---------|-------------|
| `--qdrant-url` | `http://localhost:6333` | Qdrant instance URL |
| `--collection` | `docs` | Collection name |
| `--text-field` | `text` | Payload field containing text |
| `--llm-url` | `http://localhost:8001/v1` | Local LLM endpoint |
| `--llm-model` | `Qwen/Qwen3-4B-Instruct-2507` | LLM model name |
| `--embed-url` | `http://localhost:8004` | BGE-M3 embedding server |
| `--output` | `bge_m3_training.jsonl` | Output dataset file |
| `--queries-per-chunk` | `3` | Queries generated per chunk |
| `--hard-negatives` | `7` | Hard negatives per query |
| `--min-pairs` | `2000` | Minimum target pairs |
| `--max-chunks` | (all) | Limit chunks processed (for testing) |
| `--min-chunk-length` | `100` | Minimum chunk length (chars) |
| `--min-words` | `20` | Minimum words per chunk |
| `--min-alpha-ratio` | `0.4` | Minimum alphabetic character ratio |
| `--skip-llm-filter` | `false` | Skip LLM quality filter |
| `--seed` | `42` | Random seed |
| `--resume` | `false` | Resume from partial output |

### `bge-auto-tune finetune`

| Parameter | Default | Description |
|-----------|---------|-------------|
| `--dataset` | `bge_m3_training.jsonl` | Input dataset |
| `--model` | `BAAI/bge-m3` | Base model |
| `--output` | `./bge-m3-finetuned` | Output directory |
| `--epochs` | `2` | Training epochs |
| `--lr` | `1e-5` | Learning rate |
| `--batch-size` | `4` | Batch size per GPU |
| `--temperature` | `0.02` | InfoNCE temperature |
| `--warmup-ratio` | `0.05` | Warmup ratio |
| `--max-passage-len` | `1024` | Max passage length |
| `--max-query-len` | `256` | Max query length |
| `--train-group-size` | `8` | Passages per query in batch |
| `--save-steps` | `500` | Save checkpoint every N steps |
| `--gradient-checkpointing` | `true` | Save VRAM |

### `bge-auto-tune test`

| Parameter | Default | Description |
|-----------|---------|-------------|
| `--base-model` | `BAAI/bge-m3` | Base model for comparison |
| `--model` | `./bge-m3-finetuned` | Fine-tuned model |
| `--dataset` | `bge_m3_training.jsonl` | Dataset with query/positive pairs |
| `--test-queries` | `100` | Number of test queries |
| `--top-k` | `10` | Recall@K |
| `--batch-size` | `16` | Encoding batch size |
| `--output` | `test_results.json` | Detailed JSON report |
| `--verbose` | `false` | Show all examples |
| `--device` | `auto` | Device: auto, cuda, cpu, mps |

---

## Environment variables

All endpoints can be set via env vars so you don't have to repeat them:

```bash
export QDRANT_URL=http://10.0.0.1:6333
export QDRANT_COLLECTION=my_docs
export LLM_URL=http://10.0.0.1:8001/v1
export LLM_MODEL=Qwen/Qwen3-8B
export LLM_API_KEY=none
export EMBED_URL=http://10.0.0.1:8004

# Now just:
bge-auto-tune generate
```

---

## After fine-tuning

Once the test shows improvements, you need to **re-index** your documents in Qdrant using the new model. The fine-tuned model produces different embeddings — searching with the new model on an index built with the old one won't work.

```bash
# Point your embedding server to the fine-tuned model
M3_MODEL_ID=./bge-m3-finetuned python bge_server.py

# Re-index all documents
```

---

## License

MIT