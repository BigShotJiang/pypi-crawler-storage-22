"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  finetune_bge_m3.py                                                        ║
║  Fine-tune BAAI/bge-m3 per retrieval + reranking su dominio specifico      ║
║                                                                            ║
║  Allena contemporaneamente dense, sparse e colbert (unified M3 training)   ║
║                                                                            ║
║  Requisiti:                                                                ║
║    pip install FlagEmbedding[finetune] --break-system-packages             ║
║    # oppure                                                                ║
║    pip install FlagEmbedding accelerate datasets --break-system-packages   ║
║                                                                            ║
║  Uso:                                                                      ║
║    python finetune_bge_m3.py                                               ║
║    python finetune_bge_m3.py --dataset bge_m3_training.jsonl               ║
║    python finetune_bge_m3.py --epochs 3 --lr 1e-5 --batch-size 4          ║
║                                                                            ║
║  ⚠️ DOPO il training, devi ri-indicizzare Qdrant col nuovo modello!        ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import time
import argparse
import subprocess
from pathlib import Path


# ════════════════════════════════════════════════════════════════
# ⚙️ ARGS
# ════════════════════════════════════════════════════════════════

def parse_args():
    p = argparse.ArgumentParser(description="Fine-tune BGE-M3 (unified)")

    p.add_argument("--dataset", default="bge_m3_training.jsonl",
                   help="Path al dataset JSONL (formato FlagEmbedding)")
    p.add_argument("--model", default="BAAI/bge-m3",
                   help="Modello base da fine-tunare")
    p.add_argument("--output", default="./bge-m3-finetuned",
                   help="Directory output del modello fine-tunato")

    # Training
    p.add_argument("--epochs", type=int, default=2,
                   help="Numero epoche (2-3 per embedding)")
    p.add_argument("--lr", type=float, default=1e-5,
                   help="Learning rate (1e-5 safe, 2e-5 aggressivo)")
    p.add_argument("--batch-size", type=int, default=4,
                   help="Batch size per GPU")
    p.add_argument("--temperature", type=float, default=0.02,
                   help="InfoNCE temperature")
    p.add_argument("--warmup-ratio", type=float, default=0.05)

    # Lengths
    p.add_argument("--max-passage-len", type=int, default=1024,
                   help="Max passage length (allinea col tuo server)")
    p.add_argument("--max-query-len", type=int, default=256,
                   help="Max query length (allinea col tuo server)")

    # Grouping
    p.add_argument("--train-group-size", type=int, default=8,
                   help="Numero di passaggi (1 pos + N neg) per query nel batch")

    # Misc
    p.add_argument("--save-steps", type=int, default=500)
    p.add_argument("--logging-steps", type=int, default=10)
    p.add_argument("--gradient-checkpointing", action="store_true", default=True,
                   help="Risparmia VRAM (default: attivo)")
    p.add_argument("--no-gradient-checkpointing", dest="gradient_checkpointing",
                   action="store_false")

    return p.parse_args()


# ════════════════════════════════════════════════════════════════
# 📊 VALIDAZIONE DATASET
# ════════════════════════════════════════════════════════════════

def validate_dataset(path):
    """Controlla che il dataset sia valido per FlagEmbedding."""
    print(f"\n  📊 Validazione: {path}")

    if not os.path.exists(path):
        print(f"  ✗ File non trovato: {path}")
        return 0

    total = 0
    with_neg = 0
    errors = 0
    pos_lengths = []
    neg_counts = []

    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)

                # Campi obbligatori
                if "query" not in item:
                    errors += 1
                    continue
                if "pos" not in item or not item["pos"]:
                    errors += 1
                    continue

                total += 1
                pos_lengths.append(len(item["pos"][0]))

                if item.get("neg"):
                    with_neg += 1
                    neg_counts.append(len(item["neg"]))

            except json.JSONDecodeError:
                errors += 1

    if total == 0:
        print(f"  ✗ Nessun esempio valido!")
        return 0

    avg_pos_len = sum(pos_lengths) / len(pos_lengths)
    avg_neg = sum(neg_counts) / len(neg_counts) if neg_counts else 0

    print(f"  ✓ Esempi validi:       {total}")
    print(f"    Con hard negatives:  {with_neg} ({100 * with_neg / total:.0f}%)")
    print(f"    Media neg per query: {avg_neg:.1f}")
    print(f"    Lunghezza pos media: {avg_pos_len:.0f} chars")
    if errors:
        print(f"    ⚠️ Errori/skip:     {errors}")

    if total < 100:
        print(f"\n  ⚠️ Dataset molto piccolo. Il fine-tuning potrebbe non essere efficace.")
        print(f"     Consiglio almeno 500-1000 coppie.")

    if with_neg / total < 0.5:
        print(f"\n  ⚠️ Solo {100 * with_neg / total:.0f}% ha hard negatives.")
        print(f"     I hard negatives sono cruciali per buoni risultati.")

    return total


# ════════════════════════════════════════════════════════════════
# 🔧 TRAINING
# ════════════════════════════════════════════════════════════════

def run_training(args):
    """Lancia il training M3 unificato."""

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Il training script che verrà eseguito come subprocess
    # (FlagEmbedding ha bisogno di essere il processo principale)
    training_code = f'''
import os
import sys

# Setta env prima di importare torch
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "0")

try:
    from FlagEmbedding.abc.finetune.embedder import AbsEmbedderTrainingArguments as TrainingArgs
    from FlagEmbedding.finetune.embedder.encoder_only.m3 import EncoderOnlyEmbedderM3Runner as M3Runner
except ImportError:
    print()
    print("✗ FlagEmbedding non installato o versione non compatibile.")
    print("  Installa con:")
    print("    pip install FlagEmbedding[finetune] --break-system-packages")
    print()
    sys.exit(1)

# ── Model args ──
model_args = {{
    "model_name_or_path": "{args.model}",
    "cache_dir": None,
}}

# ── Data args ──
data_args = {{
    "train_data": "{os.path.abspath(args.dataset)}",
    "cache_path": None,
    "train_group_size": {args.train_group_size},
    "query_max_len": {args.max_query_len},
    "passage_max_len": {args.max_passage_len},
    "pad_to_multiple_of": None,
    "knowledge_distillation": False,
    "same_dataset_within_batch": False,
    "small_threshold": 0,
    "drop_threshold": 0,
    "query_instruction_for_retrieval": None,
    "query_instruction_format": "{{}}{{}}",
    "passage_instruction_for_retrieval": None,
    "passage_instruction_format": "{{}}{{}}",
}}

# ── Training args ──
training_args = TrainingArgs(
    output_dir="{os.path.abspath(args.output)}",

    # Schedule
    num_train_epochs={args.epochs},
    learning_rate={args.lr},
    warmup_ratio={args.warmup_ratio},

    # Batch
    per_device_train_batch_size={args.batch_size},

    # Precision
    fp16=True,
    bf16=False,

    # Memory
    gradient_checkpointing={args.gradient_checkpointing},
    dataloader_drop_last=True,

    # Saving / Logging
    logging_steps={args.logging_steps},
    save_steps={args.save_steps},
    save_total_limit=2,

    # Contrastive learning
    temperature={args.temperature},
    negatives_cross_device=False,

    # Pooling
    sentence_pooling_method="cls",
    normalize_embeddings=True,

    # M3 unified
    unified_finetuning=True,
    use_self_distill=True,
    fix_encoder=False,
    self_distill_start_step=0,

    # Sub-batch (None = auto)
    sub_batch_size=None,

    # Loss
    kd_loss_type="kl_div",

    # Reporting
    report_to="none",

    # Seed
    seed=42,
    deepspeed=None,
)

print()
print("🚀 Avvio M3 unified training...")
print()

runner = M3Runner(
    model_args=model_args,
    data_args=data_args,
    training_args=training_args,
)

runner.run()

print()
print("✓ Training completato!")
'''

    # Salva lo script temporaneo
    tmp_script = output_dir / "_run_m3_training.py"
    with open(tmp_script, "w") as f:
        f.write(training_code)

    # Esegui
    print(f"\n  🚀 Esecuzione training...")
    print(f"     (log dettagliato sotto)\n")
    print("─" * 60)

    result = subprocess.run(
        [sys.executable, str(tmp_script)],
        cwd=str(output_dir.parent),
    )

    print("─" * 60)

    # Cleanup
    tmp_script.unlink(missing_ok=True)

    if result.returncode != 0:
        print(f"\n  ✗ Training fallito (exit code {result.returncode})")
        return False

    return True


# ════════════════════════════════════════════════════════════════
# 🚀 MAIN
# ════════════════════════════════════════════════════════════════

def run_finetune(args):
    """Entry point chiamato da cli.py"""

    print("""
╔══════════════════════════════════════════════════════════════╗
║        🔧  BGE-M3 Fine-Tuning Pipeline                      ║
║        Unified: Dense + Sparse + ColBERT                     ║
╚══════════════════════════════════════════════════════════════╝
    """)

    # ── Config summary ──
    print(f"  📋 Configurazione:")
    print(f"     Modello base:      {args.model}")
    print(f"     Dataset:           {args.dataset}")
    print(f"     Output:            {args.output}")
    print(f"     Epochs:            {args.epochs}")
    print(f"     Learning rate:     {args.lr}")
    print(f"     Batch size:        {args.batch_size}")
    print(f"     Train group size:  {args.train_group_size}")
    print(f"     Temperature:       {args.temperature}")
    print(f"     Max query len:     {args.max_query_len}")
    print(f"     Max passage len:   {args.max_passage_len}")
    print(f"     Grad checkpoint:   {args.gradient_checkpointing}")

    # ── Validazione ──
    num_examples = validate_dataset(args.dataset)
    if num_examples == 0:
        print(f"\n  ✗ Dataset vuoto o non trovato. Genera prima il dataset con:")
        print(f"    python generate_dataset.py --collection tua_collection")
        sys.exit(1)

    # ── Stima tempo ──
    # Rough estimate: ~2-5 sec per step su GPU consumer
    effective_batch = args.batch_size * args.train_group_size
    steps_per_epoch = num_examples // effective_batch
    total_steps = steps_per_epoch * args.epochs
    est_minutes = total_steps * 3 / 60  # ~3 sec/step stima media

    print(f"\n  ⏱️  Stima:")
    print(f"     Steps per epoca:   ~{steps_per_epoch}")
    print(f"     Steps totali:      ~{total_steps}")
    print(f"     Tempo stimato:     ~{est_minutes:.0f} minuti")

    # ── Conferma ──
    print(f"\n  Procedo con il training?")
    print(f"  (Ctrl+C per annullare, Invio per procedere)")

    try:
        input()
    except KeyboardInterrupt:
        print("\n  Annullato.")
        sys.exit(0)

    # ── Training ──
    start_time = time.time()
    success = run_training(args)
    elapsed = time.time() - start_time

    if success:
        print(f"\n{'═' * 60}")
        print(f"  ✅  Fine-tuning completato!")
        print(f"{'═' * 60}")
        print(f"  ⏱️  Durata: {elapsed / 60:.1f} minuti")
        print(f"  💾 Modello: {args.output}")
        print(f"\n  📋 Prossimi passi:")
        print(f"     1. Testa il modello:")
        print(f"        python test_retrieval.py --model {args.output}")
        print(f"     2. Se soddisfatto, ri-indicizza Qdrant:")
        print(f"        M3_MODEL_ID={args.output} python bge_server.py")
        print(f"     3. Ri-indicizza tutti i documenti con il nuovo modello")
    else:
        print(f"\n  ✗ Training fallito dopo {elapsed / 60:.1f} minuti")
        sys.exit(1)


def main():
    args = parse_args()
    run_finetune(args)


if __name__ == "__main__":
    main()
