"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  test_retrieval.py                                                         ║
║  Testa e confronta la qualità del retrieval: base vs fine-tunato           ║
║                                                                            ║
║  Cosa fa:                                                                  ║
║    1. Prende un campione di query dal dataset di training                  ║
║    2. Per ogni query, cerca con modello BASE e modello FINETUNED           ║
║    3. Calcola metriche: Recall@K, MRR, e confronto hit/miss               ║
║    4. Mostra esempi qualitativi di miglioramenti                           ║
║                                                                            ║
║  Uso:                                                                      ║
║    python test_retrieval.py                                                ║
║    python test_retrieval.py --model ./bge-m3-finetuned                     ║
║    python test_retrieval.py --test-queries 100 --top-k 10                  ║
║                                                                            ║
║  Nota: richiede che il dataset JSONL esista (con le coppie query/pos)      ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import time
import random
import argparse
import numpy as np

# ════════════════════════════════════════════════════════════════
# ⚙️ ARGS
# ════════════════════════════════════════════════════════════════

def parse_args():
    p = argparse.ArgumentParser(description="Testa retrieval BGE-M3 base vs fine-tunato")

    p.add_argument("--base-model", default="BAAI/bge-m3",
                   help="Modello base (originale)")
    p.add_argument("--model", default="./bge-m3-finetuned",
                   help="Modello fine-tunato")
    p.add_argument("--dataset", default="bge_m3_training.jsonl",
                   help="Dataset JSONL con query e positivi")

    # Test config
    p.add_argument("--test-queries", type=int, default=100,
                   help="Numero di query da testare")
    p.add_argument("--top-k", type=int, default=10,
                   help="Recall@K da calcolare")
    p.add_argument("--max-len", type=int, default=1024)
    p.add_argument("--batch-size", type=int, default=16)

    # Output
    p.add_argument("--output", default="test_results.json",
                   help="Salva risultati dettagliati in JSON")
    p.add_argument("--verbose", action="store_true",
                   help="Mostra esempi qualitativi per ogni query")

    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default="auto",
                   help="Device: auto, cuda, cpu, mps")

    return p.parse_args()


# ════════════════════════════════════════════════════════════════
# 🧠 MODEL LOADING
# ════════════════════════════════════════════════════════════════

def get_device(requested):
    import torch
    if requested == "auto":
        if torch.cuda.is_available():
            return "cuda"
        elif torch.backends.mps.is_available():
            return "mps"
        return "cpu"
    return requested


def load_model(model_name, device):
    """Carica BGE-M3 (base o fine-tunato)."""
    from FlagEmbedding import BGEM3FlagModel
    import torch

    use_fp16 = device == "cuda"
    model = BGEM3FlagModel(model_name, device=device, use_fp16=use_fp16)
    return model


# ════════════════════════════════════════════════════════════════
# 📊 DATASET LOADING
# ════════════════════════════════════════════════════════════════

def load_test_data(dataset_path, n_queries, seed=42):
    """
    Carica query e positivi dal dataset.
    Ritorna lista di {query, positive_text}.
    """
    all_items = []

    with open(dataset_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)
                if item.get("query") and item.get("pos"):
                    all_items.append({
                        "query": item["query"],
                        "positive": item["pos"][0],
                    })
            except json.JSONDecodeError:
                continue

    if not all_items:
        return [], []

    # Campiona
    random.seed(seed)
    if len(all_items) > n_queries:
        test_items = random.sample(all_items, n_queries)
    else:
        test_items = all_items

    # Corpus = tutti i positivi unici (per simulare il retrieval)
    all_positives = list(set(item["positive"] for item in all_items))

    return test_items, all_positives


# ════════════════════════════════════════════════════════════════
# 🔍 RETRIEVAL TEST
# ════════════════════════════════════════════════════════════════

def encode_texts(model, texts, batch_size=16, max_len=1024):
    """Codifica testi con il modello. Ritorna array numpy di embeddings."""
    out = model.encode(
        texts,
        batch_size=batch_size,
        max_length=max_len,
        return_dense=True,
        return_sparse=False,
        return_colbert_vecs=False,
    )
    return np.array(out["dense_vecs"])


def compute_similarities(query_embs, corpus_embs):
    """Cosine similarity tra query e corpus."""
    # Normalizza
    q_norm = query_embs / (np.linalg.norm(query_embs, axis=1, keepdims=True) + 1e-8)
    c_norm = corpus_embs / (np.linalg.norm(corpus_embs, axis=1, keepdims=True) + 1e-8)
    # Dot product (= cosine sim dato che sono normalizzati)
    return q_norm @ c_norm.T


def evaluate_retrieval(model, test_items, corpus, batch_size, max_len, top_k=10):
    """
    Per ogni query, cerca nel corpus e calcola se il positive è nei top-K.
    Ritorna metriche e dettagli per query.
    """
    # Crea mapping positive → indice nel corpus
    positive_to_idx = {}
    for idx, text in enumerate(corpus):
        if text not in positive_to_idx:
            positive_to_idx[text] = idx

    queries = [item["query"] for item in test_items]
    positives = [item["positive"] for item in test_items]

    # Encode
    print(f"    Encoding {len(queries)} query...", end=" ", flush=True)
    query_embs = encode_texts(model, queries, batch_size, max_len=256)
    print("done")

    print(f"    Encoding {len(corpus)} documenti corpus...", end=" ", flush=True)
    corpus_embs = encode_texts(model, corpus, batch_size, max_len)
    print("done")

    # Similarity
    sims = compute_similarities(query_embs, corpus_embs)

    # Metriche
    results = []
    hits_at_k = {k: 0 for k in [1, 3, 5, 10] if k <= top_k}
    reciprocal_ranks = []

    for i, (query, positive) in enumerate(zip(queries, positives)):
        target_idx = positive_to_idx.get(positive)
        if target_idx is None:
            continue

        # Rank degli indici per score decrescente
        ranked_indices = np.argsort(sims[i])[::-1]

        # Posizione del positive nel ranking
        rank = np.where(ranked_indices == target_idx)[0]
        if len(rank) > 0:
            rank = int(rank[0]) + 1  # 1-based
        else:
            rank = len(corpus) + 1

        # Reciprocal rank
        reciprocal_ranks.append(1.0 / rank)

        # Hits@K
        for k in hits_at_k:
            if rank <= k:
                hits_at_k[k] += 1

        # Top-K retrieved per analisi qualitativa
        top_retrieved = []
        for j in ranked_indices[:top_k]:
            top_retrieved.append({
                "rank": int(np.where(ranked_indices == j)[0][0]) + 1,
                "score": float(sims[i][j]),
                "text_preview": corpus[j][:150],
                "is_positive": j == target_idx,
            })

        results.append({
            "query": query,
            "positive_rank": rank,
            "positive_preview": positive[:150],
            "top_retrieved": top_retrieved,
        })

    n = len(results)
    if n == 0:
        return {}, []

    metrics = {
        "mrr": sum(reciprocal_ranks) / n,
        "num_queries": n,
    }
    for k, count in hits_at_k.items():
        metrics[f"recall@{k}"] = count / n

    return metrics, results


# ════════════════════════════════════════════════════════════════
# 🔬 RERANK TEST
# ════════════════════════════════════════════════════════════════

def evaluate_reranking(model, test_items, top_k=10):
    """
    Testa il reranking: per ogni query, crea coppie con il positive
    e alcuni negativi, e verifica se il modello dà il punteggio più alto
    al positive.
    """
    correct = 0
    total = 0

    for item in test_items:
        query = item["query"]
        positive = item["positive"]

        # Prendi 5 random negativi dal test set
        negatives = [
            t["positive"] for t in random.sample(test_items, min(5, len(test_items)))
            if t["positive"] != positive
        ][:4]

        if not negatives:
            continue

        # Coppie: query + positive, query + negatives
        all_docs = [positive] + negatives
        pairs = [(query, doc) for doc in all_docs]

        scores = model.compute_score(
            pairs,
            batch_size=16,
            max_query_length=256,
            max_passage_length=1024,
            weights_for_different_modes=[0.30, 0.65, 0.05],
        )

        combined = scores["colbert+sparse+dense"]
        best_idx = int(np.argmax(combined))

        if best_idx == 0:  # positive era il primo
            correct += 1
        total += 1

    accuracy = correct / total if total > 0 else 0
    return {"rerank_accuracy": accuracy, "total": total, "correct": correct}


# ════════════════════════════════════════════════════════════════
# 📊 REPORT
# ════════════════════════════════════════════════════════════════

def print_comparison(base_metrics, ft_metrics, base_rerank, ft_rerank):
    """Stampa confronto side-by-side."""

    print(f"\n{'═' * 65}")
    print(f"  📊  CONFRONTO RETRIEVAL: Base vs Fine-tunato")
    print(f"{'═' * 65}\n")

    header = f"  {'Metrica':<25} {'Base':>10} {'Finetuned':>10} {'Delta':>10}"
    print(header)
    print(f"  {'─' * 55}")

    # Retrieval metrics
    for key in ["recall@1", "recall@3", "recall@5", "recall@10", "mrr"]:
        base_val = base_metrics.get(key, 0)
        ft_val = ft_metrics.get(key, 0)
        delta = ft_val - base_val
        arrow = "↑" if delta > 0 else "↓" if delta < 0 else "="
        color = "\033[32m" if delta > 0 else "\033[31m" if delta < 0 else ""
        reset = "\033[0m" if delta != 0 else ""

        print(f"  {key:<25} {base_val:>9.1%} {ft_val:>9.1%} {color}{arrow} {abs(delta):>7.1%}{reset}")

    # Reranking
    print(f"  {'─' * 55}")
    base_acc = base_rerank.get("rerank_accuracy", 0)
    ft_acc = ft_rerank.get("rerank_accuracy", 0)
    delta = ft_acc - base_acc
    arrow = "↑" if delta > 0 else "↓" if delta < 0 else "="
    color = "\033[32m" if delta > 0 else "\033[31m" if delta < 0 else ""
    reset = "\033[0m" if delta != 0 else ""

    print(f"  {'rerank_accuracy':<25} {base_acc:>9.1%} {ft_acc:>9.1%} {color}{arrow} {abs(delta):>7.1%}{reset}")

    print()

    # Verdetto
    retrieval_improved = ft_metrics.get("recall@5", 0) > base_metrics.get("recall@5", 0)
    rerank_improved = ft_acc > base_acc

    if retrieval_improved and rerank_improved:
        print("  ✅ Il modello fine-tunato è MIGLIORE su retrieval e reranking!")
    elif retrieval_improved:
        print("  ✅ Retrieval migliorato, reranking stabile.")
    elif rerank_improved:
        print("  ✅ Reranking migliorato, retrieval stabile.")
    else:
        print("  ⚠️ Nessun miglioramento chiaro. Considera:")
        print("     - Più dati di training")
        print("     - Più hard negatives")
        print("     - Learning rate diverso")


def print_qualitative_examples(base_results, ft_results, n_examples=5):
    """Mostra esempi dove il fine-tuning ha fatto la differenza."""

    print(f"\n{'═' * 65}")
    print(f"  🔍  ESEMPI QUALITATIVI (miglioramenti)")
    print(f"{'═' * 65}")

    improvements = []
    for base_r, ft_r in zip(base_results, ft_results):
        base_rank = base_r["positive_rank"]
        ft_rank = ft_r["positive_rank"]
        if ft_rank < base_rank:  # più basso = meglio
            improvements.append({
                "query": base_r["query"],
                "base_rank": base_rank,
                "ft_rank": ft_rank,
                "improvement": base_rank - ft_rank,
            })

    # Ordina per miglioramento maggiore
    improvements.sort(key=lambda x: -x["improvement"])

    if not improvements:
        print("\n  Nessun miglioramento evidente nei singoli esempi.")
        return

    print(f"\n  Trovati {len(improvements)} query migliorate. Top {n_examples}:\n")

    for i, imp in enumerate(improvements[:n_examples]):
        print(f"  [{i + 1}] Query: \"{imp['query'][:80]}\"")
        print(f"      Base: rank #{imp['base_rank']} → Finetuned: rank #{imp['ft_rank']}"
              f"  (↑ {imp['improvement']} posizioni)")
        print()

    # Mostra anche degradamenti
    degradations = []
    for base_r, ft_r in zip(base_results, ft_results):
        base_rank = base_r["positive_rank"]
        ft_rank = ft_r["positive_rank"]
        if ft_rank > base_rank:
            degradations.append({
                "query": base_r["query"],
                "base_rank": base_rank,
                "ft_rank": ft_rank,
                "degradation": ft_rank - base_rank,
            })

    if degradations:
        degradations.sort(key=lambda x: -x["degradation"])
        print(f"\n  ⚠️ {len(degradations)} query peggiorate. Top 3:\n")
        for i, deg in enumerate(degradations[:3]):
            print(f"  [{i + 1}] Query: \"{deg['query'][:80]}\"")
            print(f"      Base: rank #{deg['base_rank']} → Finetuned: rank #{deg['ft_rank']}"
                  f"  (↓ {deg['degradation']} posizioni)")
            print()


# ════════════════════════════════════════════════════════════════
# 🚀 MAIN
# ════════════════════════════════════════════════════════════════

def run_test(args):
    """Entry point chiamato da cli.py"""
    random.seed(args.seed)

    print("""
╔══════════════════════════════════════════════════════════════╗
║        🔬  BGE-M3 Retrieval Quality Test                     ║
║        Base vs Fine-tunato                                   ║
╚══════════════════════════════════════════════════════════════╝
    """)

    # ── Verifica file ──
    if not os.path.exists(args.dataset):
        print(f"  ✗ Dataset non trovato: {args.dataset}")
        print(f"    Genera prima il dataset con: python generate_dataset.py")
        sys.exit(1)

    if not os.path.exists(args.model) and args.model != args.base_model:
        print(f"  ✗ Modello fine-tunato non trovato: {args.model}")
        print(f"    Esegui prima il training: python finetune_bge_m3.py")
        sys.exit(1)

    # ── Carica test data ──
    print(f"  📊 Caricamento test data da: {args.dataset}")
    test_items, corpus = load_test_data(args.dataset, args.test_queries, args.seed)

    if not test_items:
        print(f"  ✗ Nessun dato di test trovato nel dataset")
        sys.exit(1)

    print(f"     Query di test: {len(test_items)}")
    print(f"     Corpus size:   {len(corpus)} documenti")

    # ── Device ──
    device = get_device(args.device)
    print(f"  🖥️  Device: {device}")

    # ══════════════════════════════════════════════════════════
    # TEST MODELLO BASE
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  📦 Test modello BASE: {args.base_model}")
    print(f"{'═' * 60}")

    print(f"  Caricamento modello base...")
    base_model = load_model(args.base_model, device)

    print(f"  🔍 Retrieval test...")
    start = time.time()
    base_metrics, base_results = evaluate_retrieval(
        base_model, test_items, corpus, args.batch_size, args.max_len, args.top_k
    )
    print(f"    ⏱️ {time.time() - start:.1f}s")

    print(f"  🎚️ Rerank test...")
    start = time.time()
    base_rerank = evaluate_reranking(base_model, test_items, args.top_k)
    print(f"    ⏱️ {time.time() - start:.1f}s")

    print(f"\n  Risultati base:")
    for k, v in base_metrics.items():
        if k != "num_queries":
            print(f"    {k}: {v:.1%}")
    print(f"    rerank_accuracy: {base_rerank['rerank_accuracy']:.1%}")

    # Libera memoria
    del base_model
    import torch
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    import gc
    gc.collect()

    # ══════════════════════════════════════════════════════════
    # TEST MODELLO FINE-TUNATO
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  🔧 Test modello FINETUNED: {args.model}")
    print(f"{'═' * 60}")

    print(f"  Caricamento modello fine-tunato...")
    ft_model = load_model(args.model, device)

    print(f"  🔍 Retrieval test...")
    start = time.time()
    ft_metrics, ft_results = evaluate_retrieval(
        ft_model, test_items, corpus, args.batch_size, args.max_len, args.top_k
    )
    print(f"    ⏱️ {time.time() - start:.1f}s")

    print(f"  🎚️ Rerank test...")
    start = time.time()
    ft_rerank = evaluate_reranking(ft_model, test_items, args.top_k)
    print(f"    ⏱️ {time.time() - start:.1f}s")

    print(f"\n  Risultati fine-tunato:")
    for k, v in ft_metrics.items():
        if k != "num_queries":
            print(f"    {k}: {v:.1%}")
    print(f"    rerank_accuracy: {ft_rerank['rerank_accuracy']:.1%}")

    del ft_model
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    gc.collect()

    # ══════════════════════════════════════════════════════════
    # CONFRONTO
    # ══════════════════════════════════════════════════════════

    print_comparison(base_metrics, ft_metrics, base_rerank, ft_rerank)
    print_qualitative_examples(base_results, ft_results)

    # ── Salva risultati dettagliati ──
    output_data = {
        "config": {
            "base_model": args.base_model,
            "finetuned_model": args.model,
            "test_queries": len(test_items),
            "corpus_size": len(corpus),
            "top_k": args.top_k,
        },
        "base": {
            "retrieval": base_metrics,
            "reranking": base_rerank,
        },
        "finetuned": {
            "retrieval": ft_metrics,
            "reranking": ft_rerank,
        },
        "per_query_base": base_results[:20] if not args.verbose else base_results,
        "per_query_finetuned": ft_results[:20] if not args.verbose else ft_results,
    }

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    print(f"\n  💾 Risultati dettagliati salvati in: {args.output}")

    print(f"\n{'═' * 60}")
    print(f"  Fatto!")
    print(f"{'═' * 60}\n")


def main():
    args = parse_args()
    run_test(args)


if __name__ == "__main__":
    main()
