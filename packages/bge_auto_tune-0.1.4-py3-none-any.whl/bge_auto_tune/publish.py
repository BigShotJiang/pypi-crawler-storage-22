"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  publish.py                                                                ║
║  Pubblica il modello fine-tunato su HuggingFace Hub                        ║
║                                                                            ║
║  Uso:                                                                      ║
║    bge-auto-tune publish --repo user/bge-m3-bank-it                        ║
║    bge-auto-tune publish --repo user/bge-m3-bank-it --private              ║
║    bge-auto-tune publish --model ./bge-m3-finetuned --repo org/model-name  ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import shutil


def run_publish(args):
    """Entry point chiamato da cli.py"""

    model_path = args.model
    repo_id = args.repo

    print(f"""
╔══════════════════════════════════════════════════════════════╗
║        📦  Pubblica modello su HuggingFace Hub               ║
╚══════════════════════════════════════════════════════════════╝
    """)

    # ── Verifica modello ──
    if not os.path.exists(model_path):
        print(f"  ✗ Modello non trovato: {model_path}")
        sys.exit(1)

    config_path = os.path.join(model_path, "config.json")
    if not os.path.exists(config_path):
        print(f"  ✗ config.json non trovato in {model_path}")
        print(f"    Sei sicuro che sia una cartella modello valida?")
        sys.exit(1)

    # ── Verifica repo id ──
    if not repo_id or "/" not in repo_id:
        print(f"  ✗ --repo deve essere nel formato user/nome-modello")
        print(f"    Esempio: --repo Sophia-AI/bge-m3-bank-it")
        sys.exit(1)

    # ── Controlla huggingface_hub ──
    try:
        from huggingface_hub import HfApi, create_repo
    except ImportError:
        print(f"  ✗ huggingface_hub non installato.")
        print(f"    Installa con: pip install huggingface_hub")
        sys.exit(1)

    # ── Genera model card se non esiste ──
    readme_path = os.path.join(model_path, "README.md")
    if not os.path.exists(readme_path):
        print(f"  📝 Generazione model card...")
        _generate_model_card(model_path, repo_id, args)
        print(f"  ✓ README.md creato")
    else:
        print(f"  ✓ README.md già presente")

    # ── Info ──
    total_size = 0
    file_count = 0
    for root, dirs, files in os.walk(model_path):
        # Salta i checkpoint intermedi
        basename = os.path.basename(root)
        if basename.startswith("checkpoint-") and root != model_path:
            continue
        for f in files:
            fpath = os.path.join(root, f)
            total_size += os.path.getsize(fpath)
            file_count += 1

    print(f"\n  📊 Dettagli:")
    print(f"     Modello:     {model_path}")
    print(f"     Repo:        {repo_id}")
    print(f"     Privato:     {'sì' if args.private else 'no'}")
    print(f"     File:        {file_count}")
    print(f"     Dimensione:  {total_size / 1e9:.2f} GB")

    # ── Conferma ──
    if not args.yes:
        print()
        risposta = input("  Procedere con l'upload? [y/N] ").strip().lower()
        if risposta not in ("y", "yes", "s", "si", "sì"):
            print("  Annullato.")
            return

    # ── Crea repo ──
    api = HfApi()

    print(f"\n  Creazione/verifica repo...")
    try:
        create_repo(
            repo_id=repo_id,
            repo_type="model",
            private=args.private,
            exist_ok=True,
        )
        print(f"  ✓ Repo pronto")
    except Exception as e:
        print(f"  ✗ Errore creazione repo: {e}")
        print(f"\n  Hai fatto login? Prova: huggingface-cli login")
        sys.exit(1)

    # ── Upload ──
    print(f"\n  📤 Upload in corso...")

    ignore_patterns = [
        "checkpoint-*/",
        "*.pt",
        "__pycache__/",
        "*.pyc",
        ".git/",
    ]

    try:
        api.upload_folder(
            folder_path=model_path,
            repo_id=repo_id,
            repo_type="model",
            revision=args.branch,
            ignore_patterns=ignore_patterns,
            commit_message=args.message or "Upload fine-tuned BGE-M3 model via bge-auto-tune",
        )
    except Exception as e:
        print(f"\n  ✗ Errore upload: {e}")
        sys.exit(1)

    url = f"https://huggingface.co/{repo_id}"
    print(f"\n{'═' * 60}")
    print(f"  ✅ Modello pubblicato!")
    print(f"{'═' * 60}")
    print(f"  🔗 {url}")
    print(f"\n  Per usarlo:")
    print(f"     from FlagEmbedding import BGEM3FlagModel")
    print(f"     model = BGEM3FlagModel('{repo_id}')")
    print()


def _generate_model_card(model_path, repo_id, args):
    """Genera una model card base se non esiste."""

    # Prova a leggere i test results se disponibili
    test_results = None
    test_path = os.path.join(os.path.dirname(model_path), "test_results.json")
    if os.path.exists(test_path):
        try:
            with open(test_path, "r") as f:
                test_results = json.load(f)
        except Exception:
            pass

    # Sezione benchmark
    benchmark_section = ""
    if test_results:
        base = test_results.get("base", {})
        ft = test_results.get("finetuned", {})
        base_dense = base.get("dense_retrieval", {})
        ft_dense = ft.get("dense_retrieval", {})
        base_rerank = base.get("reranking", {})
        ft_rerank = ft.get("reranking", {})

        benchmark_section = f"""
## Benchmark Results

Evaluation on held-out test set (20% split, queries never seen during training):

### Dense Retrieval

| Metric | Base (bge-m3) | Fine-tuned | Delta |
|---|---|---|---|
| Recall@1 | {base_dense.get('recall@1', 0):.1%} | **{ft_dense.get('recall@1', 0):.1%}** | ↑ {ft_dense.get('recall@1', 0) - base_dense.get('recall@1', 0):.1%} |
| Recall@5 | {base_dense.get('recall@5', 0):.1%} | **{ft_dense.get('recall@5', 0):.1%}** | ↑ {ft_dense.get('recall@5', 0) - base_dense.get('recall@5', 0):.1%} |
| Recall@10 | {base_dense.get('recall@10', 0):.1%} | **{ft_dense.get('recall@10', 0):.1%}** | ↑ {ft_dense.get('recall@10', 0) - base_dense.get('recall@10', 0):.1%} |
| MRR | {base_dense.get('mrr', 0):.1%} | **{ft_dense.get('mrr', 0):.1%}** | ↑ {ft_dense.get('mrr', 0) - base_dense.get('mrr', 0):.1%} |
| NDCG@10 | {base_dense.get('ndcg@10', 0):.1%} | **{ft_dense.get('ndcg@10', 0):.1%}** | ↑ {ft_dense.get('ndcg@10', 0) - base_dense.get('ndcg@10', 0):.1%} |

### Multi-Mode Reranking

| Metric | Base (bge-m3) | Fine-tuned | Delta |
|---|---|---|---|
| Accuracy | {base_rerank.get('rerank_accuracy', 0):.1%} | **{ft_rerank.get('rerank_accuracy', 0):.1%}** | ↑ {ft_rerank.get('rerank_accuracy', 0) - base_rerank.get('rerank_accuracy', 0):.1%} |
| MRR | {base_rerank.get('rerank_mrr', 0):.1%} | **{ft_rerank.get('rerank_mrr', 0):.1%}** | ↑ {ft_rerank.get('rerank_mrr', 0) - base_rerank.get('rerank_mrr', 0):.1%} |
"""

    card = f"""---
language:
  - it
  - en
license: mit
library_name: FlagEmbedding
base_model: BAAI/bge-m3
tags:
  - embeddings
  - retrieval
  - reranking
  - bge
  - bge-m3
  - fine-tuned
pipeline_tag: sentence-similarity
---

# {repo_id.split('/')[-1]}

A fine-tuned version of [BAAI/bge-m3](https://huggingface.co/BAAI/bge-m3) for domain-specific retrieval and reranking.

Produces **dense, sparse (lexical), and ColBERT** embeddings simultaneously.
{benchmark_section}
## Usage

```python
from FlagEmbedding import BGEM3FlagModel

model = BGEM3FlagModel("{repo_id}", device="cuda", use_fp16=True)

# Embeddings
output = model.encode(["Your query here"], return_dense=True, return_sparse=True)

# Reranking
scores = model.compute_score(
    [["query", "document"]],
    weights_for_different_modes=[0.30, 0.65, 0.05],
)
```

## Fine-Tune Your Own

This model was fine-tuned using [bge-auto-tune](https://pypi.org/project/bge-auto-tune/):

```bash
pip install bge-auto-tune

bge-auto-tune generate --collection your_collection --min-pairs 2000
bge-auto-tune finetune --dataset bge_m3_training.jsonl --epochs 4
bge-auto-tune test --model ./bge-m3-finetuned
bge-auto-tune publish --repo your-user/your-model-name
```
"""

    readme_path = os.path.join(model_path, "README.md")
    with open(readme_path, "w", encoding="utf-8") as f:
        f.write(card.strip() + "\n")