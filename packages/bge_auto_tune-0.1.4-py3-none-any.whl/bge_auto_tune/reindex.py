"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  reindex.py                                                                ║
║  Re-indicizza una o più collection Qdrant col modello fine-tunato          ║
║                                                                            ║
║  Cosa fa:                                                                  ║
║    1. Itera i punti di ogni collection                                     ║
║    2. Prende il testo dal campo configurato                                ║
║    3. Chiama il servizio embeddings per generare nuovi vettori             ║
║    4. Aggiorna i vettori in Qdrant (in-place o su collection di test)      ║
║                                                                            ║
║  Uso:                                                                      ║
║    bge-auto-tune reindex --collections my_docs                             ║
║    bge-auto-tune reindex --collections docs1,docs2 --test                  ║
║    bge-auto-tune reindex --collections docs --vectors dense,sparse         ║
║    bge-auto-tune reindex --collections docs --text-field content           ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import time
import json
import requests
from typing import List, Dict, Any, Optional


# ════════════════════════════════════════════════════════════════
# 🔌 SERVICE CHECKS
# ════════════════════════════════════════════════════════════════

def check_qdrant(url: str) -> bool:
    """Verifica che Qdrant sia raggiungibile."""
    try:
        r = requests.get(f"{url}/healthz", timeout=5)
        return r.status_code == 200
    except Exception:
        # Alcune versioni di Qdrant usano endpoint diversi
        try:
            r = requests.get(f"{url}/collections", timeout=5)
            return r.status_code == 200
        except Exception:
            return False


def check_embed_service(url: str) -> bool:
    """Verifica che il servizio embeddings sia raggiungibile."""
    try:
        r = requests.get(f"{url}/health", timeout=5)
        return r.status_code == 200
    except Exception:
        return False


# ════════════════════════════════════════════════════════════════
# 📦 QDRANT HELPERS
# ════════════════════════════════════════════════════════════════

def get_collection_info(qdrant_url: str, collection: str) -> Optional[Dict]:
    """Ottieni info sulla collection (vettori, punti, etc.)."""
    try:
        r = requests.get(f"{qdrant_url}/collections/{collection}", timeout=10)
        if r.status_code == 200:
            return r.json().get("result", {})
        return None
    except Exception:
        return None


def get_points_count(qdrant_url: str, collection: str) -> int:
    """Numero totale di punti nella collection."""
    info = get_collection_info(qdrant_url, collection)
    if info:
        return info.get("points_count", 0)
    return 0


def scroll_points(qdrant_url: str, collection: str, batch_size: int = 100,
                  text_field: str = "text", offset=None):
    """
    Scrolla i punti della collection.
    Ritorna (points, next_offset).
    """
    payload = {
        "limit": batch_size,
        "with_payload": True,
        "with_vector": False,
    }
    if offset is not None:
        payload["offset"] = offset

    r = requests.post(
        f"{qdrant_url}/collections/{collection}/points/scroll",
        json=payload,
        timeout=30,
    )

    if r.status_code != 200:
        raise Exception(f"Qdrant scroll error: {r.status_code} {r.text}")

    data = r.json().get("result", {})
    points = data.get("points", [])
    next_offset = data.get("next_page_offset", None)

    return points, next_offset


def create_test_collection(qdrant_url: str, source_collection: str, test_collection: str):
    """
    Crea una collection di test copiando la configurazione da quella sorgente.
    """
    # Prendi config dalla sorgente
    info = get_collection_info(qdrant_url, source_collection)
    if not info:
        raise Exception(f"Collection sorgente '{source_collection}' non trovata")

    config = info.get("config", {})
    params = config.get("params", {})

    # Elimina la collection test se esiste già
    requests.delete(f"{qdrant_url}/collections/{test_collection}", timeout=10)

    # Crea nuova collection con stessa configurazione vettori
    vectors_config = params.get("vectors", {})

    create_payload = {
        "vectors": vectors_config,
    }

    # Sparse vectors se presenti
    sparse_config = params.get("sparse_vectors", None)
    if sparse_config:
        create_payload["sparse_vectors"] = sparse_config

    r = requests.put(
        f"{qdrant_url}/collections/{test_collection}",
        json=create_payload,
        timeout=30,
    )

    if r.status_code not in (200, 201):
        raise Exception(f"Errore creazione collection test: {r.status_code} {r.text}")


def upsert_points_batch(qdrant_url: str, collection: str, points: List[Dict]):
    """Inserisci/aggiorna batch di punti."""
    if not points:
        return

    r = requests.put(
        f"{qdrant_url}/collections/{collection}/points",
        json={"points": points},
        timeout=60,
    )

    if r.status_code != 200:
        raise Exception(f"Qdrant upsert error: {r.status_code} {r.text}")


def update_vectors_batch(qdrant_url: str, collection: str, points: List[Dict]):
    """Aggiorna solo i vettori di punti esistenti (senza toccare payload)."""
    if not points:
        return

    r = requests.put(
        f"{qdrant_url}/collections/{collection}/points/vectors",
        json={"points": points},
        timeout=60,
    )

    if r.status_code != 200:
        raise Exception(f"Qdrant update vectors error: {r.status_code} {r.text}")


# ════════════════════════════════════════════════════════════════
# 🧠 EMBEDDING SERVICE
# ════════════════════════════════════════════════════════════════

def get_embeddings(embed_url: str, texts: List[str],
                   return_dense: bool = True,
                   return_sparse: bool = True,
                   return_colbert: bool = False,
                   timeout: int = 120) -> List[Dict]:
    """
    Chiama il servizio embeddings BGE-M3.
    Ritorna lista di dict con 'dense', 'sparse', 'colbert' a seconda dei flag.
    """
    payload = {
        "input": texts,
        "return_dense": return_dense,
        "return_sparse": return_sparse,
        "return_colbert": return_colbert,
    }

    r = requests.post(
        f"{embed_url}/v1/embeddings",
        json=payload,
        timeout=timeout,
    )

    if r.status_code != 200:
        raise Exception(f"Embed service error: {r.status_code} {r.text}")

    data = r.json()
    results = data.get("results", [])

    # Ordina per index
    results.sort(key=lambda x: x["index"])

    return [item["embeddings"] for item in results]


# ════════════════════════════════════════════════════════════════
# 🔄 REINDEX LOGIC
# ════════════════════════════════════════════════════════════════

def reindex_collection(
    qdrant_url: str,
    embed_url: str,
    source_collection: str,
    target_collection: str,
    text_field: str,
    vectors_config: Dict[str, str],
    embed_batch_size: int,
    scroll_batch_size: int,
    is_test_mode: bool,
    return_dense: bool,
    return_sparse: bool,
    return_colbert: bool,
):
    """
    Re-indicizza una singola collection.

    vectors_config: mapping tipo_vettore → nome_vettore_in_qdrant
        Es: {"dense": "dense", "sparse": "sparse"}
        Es: {"dense": None}  (vettore unnamed)
    """

    total_points = get_points_count(qdrant_url, source_collection)
    if total_points == 0:
        print(f"    ⚠️  Collection '{source_collection}' vuota, skip")
        return 0

    print(f"    📊 Punti da re-indicizzare: {total_points}")

    # Se test mode, crea la collection target
    if is_test_mode:
        print(f"    🧪 Creazione collection test: {target_collection}")
        create_test_collection(qdrant_url, source_collection, target_collection)

    processed = 0
    skipped = 0
    errors = 0
    offset = None
    start_time = time.time()

    while True:
        # Scrolla punti
        points, next_offset = scroll_points(
            qdrant_url, source_collection, scroll_batch_size, text_field, offset
        )

        if not points:
            break

        # Estrai testi
        batch_ids = []
        batch_texts = []
        batch_payloads = []

        for point in points:
            point_id = point["id"]
            payload = point.get("payload", {})
            text = payload.get(text_field, "")

            if not text or not text.strip():
                skipped += 1
                continue

            batch_ids.append(point_id)
            batch_texts.append(text.strip())
            batch_payloads.append(payload)

        # Embedding in sotto-batch
        if batch_texts:
            for i in range(0, len(batch_texts), embed_batch_size):
                sub_texts = batch_texts[i:i + embed_batch_size]
                sub_ids = batch_ids[i:i + embed_batch_size]
                sub_payloads = batch_payloads[i:i + embed_batch_size]

                try:
                    embeddings = get_embeddings(
                        embed_url, sub_texts,
                        return_dense=return_dense,
                        return_sparse=return_sparse,
                        return_colbert=return_colbert,
                    )
                except Exception as e:
                    print(f"\n    ✗ Errore embedding batch: {e}")
                    errors += len(sub_texts)
                    continue

                # Costruisci punti per Qdrant
                if is_test_mode:
                    # Upsert completo (vettori + payload) nella collection test
                    qdrant_points = []
                    for j, (pid, emb, pay) in enumerate(zip(sub_ids, embeddings, sub_payloads)):
                        point_data = {
                            "id": pid,
                            "payload": pay,
                            "vector": _build_vector_payload(emb, vectors_config),
                        }
                        qdrant_points.append(point_data)

                    upsert_points_batch(qdrant_url, target_collection, qdrant_points)

                else:
                    # Update solo vettori nella collection originale
                    vector_points = []
                    for j, (pid, emb) in enumerate(zip(sub_ids, embeddings)):
                        point_data = {
                            "id": pid,
                            "vector": _build_vector_payload(emb, vectors_config),
                        }
                        vector_points.append(point_data)

                    update_vectors_batch(qdrant_url, target_collection, vector_points)

                processed += len(sub_texts)

                # Progress
                elapsed = time.time() - start_time
                rate = processed / elapsed if elapsed > 0 else 0
                eta = (total_points - processed) / rate if rate > 0 else 0
                print(f"\r    ⏳ {processed}/{total_points} "
                      f"({processed / total_points * 100:.1f}%) "
                      f"| {rate:.1f} doc/s "
                      f"| ETA {eta:.0f}s "
                      f"| skip {skipped} | err {errors}",
                      end="", flush=True)

        # Prossima pagina
        if next_offset is None:
            break
        offset = next_offset

    print()  # newline dopo progress

    elapsed = time.time() - start_time
    print(f"    ✓ Completato: {processed} punti in {elapsed:.1f}s")
    if skipped:
        print(f"    ⚠️  {skipped} punti senza testo (skippati)")
    if errors:
        print(f"    ✗ {errors} errori embedding")

    return processed


def _build_vector_payload(embeddings: Dict, vectors_config: Dict[str, str]) -> Dict:
    """
    Costruisce il payload vettori per Qdrant basandosi sulla config.

    vectors_config: {"dense": "nome_vettore", "sparse": "nome_vettore_sparse"}
    embeddings: {"dense": [...], "sparse": {"indices": [...], "values": [...]}}
    """
    vectors = {}

    for vec_type, vec_name in vectors_config.items():
        if vec_type == "dense" and "dense" in embeddings:
            if vec_name:
                vectors[vec_name] = embeddings["dense"]
            else:
                # Vettore unnamed — ritorna direttamente la lista
                return embeddings["dense"]

        elif vec_type == "sparse" and "sparse" in embeddings:
            if vec_name:
                vectors[vec_name] = embeddings["sparse"]

        elif vec_type == "colbert" and "colbert" in embeddings:
            if vec_name:
                vectors[vec_name] = embeddings["colbert"]

    return vectors


# ════════════════════════════════════════════════════════════════
# 🚀 MAIN
# ════════════════════════════════════════════════════════════════

def run_reindex(args):
    """Entry point chiamato da cli.py"""

    print(f"""
╔══════════════════════════════════════════════════════════════╗
║        🔄  Re-indicizzazione Qdrant                          ║
╚══════════════════════════════════════════════════════════════╝
    """)

    qdrant_url = args.qdrant_url.rstrip("/")
    embed_url = args.embed_url.rstrip("/")
    collections = [c.strip() for c in args.collections.split(",") if c.strip()]
    text_field = args.text_field
    is_test = args.test

    # Parse vector types
    vec_types = [v.strip() for v in args.vectors.split(",") if v.strip()]
    return_dense = "dense" in vec_types
    return_sparse = "sparse" in vec_types
    return_colbert = "colbert" in vec_types

    if not (return_dense or return_sparse or return_colbert):
        print("  ✗ Devi specificare almeno un tipo di vettore (dense, sparse, colbert)")
        sys.exit(1)

    # Parse vector names mapping
    # --vector-names "dense:dense,sparse:sparse"
    vectors_config = {}
    if args.vector_names:
        for pair in args.vector_names.split(","):
            pair = pair.strip()
            if ":" in pair:
                vtype, vname = pair.split(":", 1)
                vectors_config[vtype.strip()] = vname.strip()
            else:
                # Se non c'è ":", assume che sia il nome per dense
                vectors_config["dense"] = pair.strip()
    else:
        # Default: named vectors con stesso nome del tipo
        if return_dense:
            vectors_config["dense"] = "dense"
        if return_sparse:
            vectors_config["sparse"] = "sparse"
        if return_colbert:
            vectors_config["colbert"] = "colbert"

    # Unnamed vectors
    if args.unnamed_vectors:
        vectors_config = {"dense": None}
        return_sparse = False
        return_colbert = False

    # ── Info ──
    print(f"  📋 Configurazione:")
    print(f"     Qdrant:          {qdrant_url}")
    print(f"     Embed service:   {embed_url}")
    print(f"     Collections:     {', '.join(collections)}")
    print(f"     Campo testo:     {text_field}")
    print(f"     Vettori:         {', '.join(vec_types)}")
    print(f"     Vector names:    {vectors_config}")
    print(f"     Modalità:        {'🧪 TEST (nuova collection)' if is_test else '⚡ UPDATE (in-place)'}")
    print(f"     Embed batch:     {args.embed_batch}")
    print()

    # ── Verifica servizi ──
    print("  🔌 Verifica servizi...")

    if not check_qdrant(qdrant_url):
        print(f"  ✗ Qdrant non raggiungibile: {qdrant_url}")
        sys.exit(1)
    print(f"  ✓ Qdrant OK")

    if not check_embed_service(embed_url):
        print(f"  ✗ Servizio embeddings non raggiungibile: {embed_url}")
        print(f"    Assicurati che il server BGE-M3 sia in esecuzione col modello corretto.")
        sys.exit(1)
    print(f"  ✓ Embed service OK")

    # ── Verifica collections ──
    for coll in collections:
        info = get_collection_info(qdrant_url, coll)
        if not info:
            print(f"\n  ✗ Collection '{coll}' non trovata in Qdrant")
            sys.exit(1)

    # ── Conferma se non test e non --yes ──
    if not is_test and not args.yes:
        print(f"\n  ⚠️  Stai per SOVRASCRIVERE i vettori nelle collection originali!")
        print(f"     Collections: {', '.join(collections)}")
        print(f"     Usa --test per creare collection di test separate.")
        risposta = input("\n  Procedere? [y/N] ").strip().lower()
        if risposta not in ("y", "yes", "s", "si", "sì"):
            print("  Annullato.")
            return

    # ── Reindex ──
    total_start = time.time()
    total_processed = 0

    for i, coll in enumerate(collections, 1):
        print(f"\n{'═' * 60}")
        print(f"  [{i}/{len(collections)}] Collection: {coll}")
        print(f"{'═' * 60}")

        if is_test:
            target = f"{coll}_test_finetuned"
        else:
            target = coll

        processed = reindex_collection(
            qdrant_url=qdrant_url,
            embed_url=embed_url,
            source_collection=coll,
            target_collection=target,
            text_field=text_field,
            vectors_config=vectors_config,
            embed_batch_size=args.embed_batch,
            scroll_batch_size=args.scroll_batch,
            is_test_mode=is_test,
            return_dense=return_dense,
            return_sparse=return_sparse,
            return_colbert=return_colbert,
        )

        total_processed += processed

    # ── Riepilogo ──
    total_elapsed = time.time() - total_start

    print(f"\n{'═' * 60}")
    print(f"  ✅ Re-indicizzazione completata!")
    print(f"{'═' * 60}")
    print(f"  ⏱️  Tempo totale: {total_elapsed:.1f}s ({total_elapsed / 60:.1f} min)")
    print(f"  📊 Punti totali:  {total_processed}")
    if total_processed > 0 and total_elapsed > 0:
        print(f"  🚀 Velocità:      {total_processed / total_elapsed:.1f} doc/s")

    if is_test:
        test_names = [f"{c}_test_finetuned" for c in collections]
        print(f"\n  🧪 Collection di test create:")
        for name in test_names:
            count = get_points_count(qdrant_url, name)
            print(f"     {name}: {count} punti")
        print(f"\n  Per confrontare, cerca nella collection di test e compara i risultati.")
        print(f"  Quando sei soddisfatto, rilancia senza --test per aggiornare la produzione.")
    else:
        print(f"\n  ⚡ Vettori aggiornati in-place nelle collection originali.")
        print(f"  Le query ora useranno i nuovi embeddings del modello fine-tunato.")

    print()