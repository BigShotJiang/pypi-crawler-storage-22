"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  test_retrieval.py                                                         ║
║  Testa e confronta la qualità del retrieval: base vs fine-tunato           ║
║                                                                            ║
║  Miglioramenti rispetto alla v1:                                           ║
║    - Train/test split: testa su dati MAI visti durante il training         ║
║    - Multi-mode scoring: dense + sparse + colbert (come in produzione)     ║
║    - NDCG@K oltre a Recall@K e MRR                                        ║
║    - Corpus realistico: positivi + hard negatives dal dataset              ║
║    - Rerank test con gli stessi hard negatives, non random                 ║
║                                                                            ║
║  Uso:                                                                      ║
║    python test_retrieval.py                                                ║
║    python test_retrieval.py --model ./bge-m3-finetuned                     ║
║    python test_retrieval.py --test-queries 200 --top-k 10                  ║
║    python test_retrieval.py --test-split 0.2                               ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import time
import math
import random
import argparse
import numpy as np
from collections import defaultdict


# ════════════════════════════════════════════════════════════════
# ⚙️ ARGS
# ════════════════════════════════════════════════════════════════

def parse_args():
    p = argparse.ArgumentParser(description="Testa retrieval BGE-M3 base vs fine-tunato")

    p.add_argument("--base-model", default="BAAI/bge-m3",
                   help="Modello base (originale)")
    p.add_argument("--model", default="./bge-m3-finetuned",
                   help="Modello fine-tunato")
    p.add_argument("--dataset", default="bge_m3_training.jsonl",
                   help="Dataset JSONL con query, positivi e negativi")

    # Test config
    p.add_argument("--test-queries", type=int, default=200,
                   help="Numero massimo di query da testare")
    p.add_argument("--test-split", type=float, default=0.2,
                   help="Percentuale di dati riservati al test (0.2 = 20%%)")
    p.add_argument("--top-k", type=int, default=10,
                   help="Recall@K / NDCG@K da calcolare")
    p.add_argument("--max-len", type=int, default=1024)
    p.add_argument("--batch-size", type=int, default=16)

    # Rerank weights (stessi del server di produzione)
    p.add_argument("--dense-weight", type=float, default=0.30)
    p.add_argument("--sparse-weight", type=float, default=0.65)
    p.add_argument("--colbert-weight", type=float, default=0.05)

    # Output
    p.add_argument("--output", default="test_results.json",
                   help="Salva risultati dettagliati in JSON")
    p.add_argument("--verbose", action="store_true",
                   help="Mostra tutti gli esempi qualitativi")

    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default="auto",
                   help="Device: auto, cuda, cpu, mps")

    return p.parse_args()


# ════════════════════════════════════════════════════════════════
# 🧠 MODEL LOADING
# ════════════════════════════════════════════════════════════════

def get_device(requested):
    import torch
    if requested == "auto":
        if torch.cuda.is_available():
            return "cuda"
        elif torch.backends.mps.is_available():
            return "mps"
        return "cpu"
    return requested


def load_model(model_name, device):
    """Carica BGE-M3 (base o fine-tunato)."""
    from FlagEmbedding import BGEM3FlagModel
    use_fp16 = device == "cuda"
    model = BGEM3FlagModel(model_name, device=device, use_fp16=use_fp16)
    return model


# ════════════════════════════════════════════════════════════════
# 📊 DATASET LOADING + TRAIN/TEST SPLIT
# ════════════════════════════════════════════════════════════════

def load_and_split_data(dataset_path, test_split=0.2, max_test=200, seed=42):
    """
    Carica il dataset e lo splitta in train/test.
    Il test set contiene query MAI usate per il training.

    Ritorna:
        test_items: lista di {query, positive, negatives}
        corpus: lista di testi unici (positivi + negativi)
    """
    all_items = []

    with open(dataset_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)
                if item.get("query") and item.get("pos"):
                    all_items.append({
                        "query": item["query"],
                        "positive": item["pos"][0],
                        "negatives": item.get("neg", []),
                    })
            except json.JSONDecodeError:
                continue

    if not all_items:
        return [], [], []

    # ── Raggruppa per positive (più query possono avere lo stesso positive) ──
    # Per evitare data leakage, splittiamo per POSITIVE, non per query.
    # Se un positive è nel test, TUTTE le sue query vanno nel test.
    positive_to_items = defaultdict(list)
    for item in all_items:
        positive_to_items[item["positive"]].append(item)

    all_positives = list(positive_to_items.keys())
    random.seed(seed)
    random.shuffle(all_positives)

    # Split
    n_test_positives = max(1, int(len(all_positives) * test_split))
    test_positives = set(all_positives[:n_test_positives])
    train_positives = set(all_positives[n_test_positives:])

    # Raccogli test items
    test_items = []
    for pos in test_positives:
        test_items.extend(positive_to_items[pos])

    # Limita
    if len(test_items) > max_test:
        random.shuffle(test_items)
        test_items = test_items[:max_test]

    # ── Costruisci corpus realistico ──
    # Include TUTTI i positivi + TUTTI i negativi unici
    corpus_set = set()
    for item in all_items:
        corpus_set.add(item["positive"])
        for neg in item.get("negatives", []):
            corpus_set.add(neg)

    corpus = list(corpus_set)

    n_train = sum(len(positive_to_items[p]) for p in train_positives)
    n_test = len(test_items)

    return test_items, corpus, {
        "total_items": len(all_items),
        "train_items": n_train,
        "test_items": n_test,
        "corpus_size": len(corpus),
        "test_positives": len(test_positives),
        "train_positives": len(train_positives),
    }


# ════════════════════════════════════════════════════════════════
# 🔍 DENSE RETRIEVAL TEST
# ════════════════════════════════════════════════════════════════

def encode_texts(model, texts, batch_size=16, max_len=1024):
    """Codifica testi con il modello. Ritorna embeddings densi."""
    out = model.encode(
        texts,
        batch_size=batch_size,
        max_length=max_len,
        return_dense=True,
        return_sparse=False,
        return_colbert_vecs=False,
    )
    return np.array(out["dense_vecs"])


def compute_similarities(query_embs, corpus_embs):
    """Cosine similarity normalizzata."""
    q_norm = query_embs / (np.linalg.norm(query_embs, axis=1, keepdims=True) + 1e-8)
    c_norm = corpus_embs / (np.linalg.norm(corpus_embs, axis=1, keepdims=True) + 1e-8)
    return q_norm @ c_norm.T


def dcg_at_k(relevances, k):
    """Discounted Cumulative Gain."""
    relevances = np.array(relevances[:k])
    if len(relevances) == 0:
        return 0.0
    discounts = np.log2(np.arange(2, len(relevances) + 2))
    return np.sum(relevances / discounts)


def ndcg_at_k(relevances, k):
    """Normalized DCG@K."""
    actual = dcg_at_k(relevances, k)
    ideal = dcg_at_k(sorted(relevances, reverse=True), k)
    if ideal == 0:
        return 0.0
    return actual / ideal


def evaluate_dense_retrieval(model, test_items, corpus, batch_size, max_len, top_k=10):
    """
    Retrieval solo dense (cosine similarity).
    Calcola Recall@K, MRR, NDCG@K.
    """
    positive_to_idx = {}
    for idx, text in enumerate(corpus):
        if text not in positive_to_idx:
            positive_to_idx[text] = idx

    queries = [item["query"] for item in test_items]

    print(f"    Encoding {len(queries)} query...", end=" ", flush=True)
    query_embs = encode_texts(model, queries, batch_size, max_len=256)
    print("done")

    print(f"    Encoding {len(corpus)} documenti corpus...", end=" ", flush=True)
    corpus_embs = encode_texts(model, corpus, batch_size, max_len)
    print("done")

    sims = compute_similarities(query_embs, corpus_embs)

    results = []
    hits_at_k = {k: 0 for k in [1, 3, 5, 10] if k <= top_k}
    reciprocal_ranks = []
    ndcg_scores = []

    for i, item in enumerate(test_items):
        target_idx = positive_to_idx.get(item["positive"])
        if target_idx is None:
            continue

        ranked_indices = np.argsort(sims[i])[::-1]
        rank = int(np.where(ranked_indices == target_idx)[0][0]) + 1

        reciprocal_ranks.append(1.0 / rank)

        for k in hits_at_k:
            if rank <= k:
                hits_at_k[k] += 1

        # NDCG: relevance 1 per il positive, 0 per tutti gli altri
        relevances = [1.0 if ranked_indices[j] == target_idx else 0.0 for j in range(top_k)]
        ndcg_scores.append(ndcg_at_k(relevances, top_k))

        top_retrieved = []
        for j in ranked_indices[:min(top_k, 5)]:
            top_retrieved.append({
                "rank": int(np.where(ranked_indices == j)[0][0]) + 1,
                "score": float(sims[i][j]),
                "text_preview": corpus[j][:150],
                "is_positive": bool(j == target_idx),
            })

        results.append({
            "query": item["query"],
            "positive_rank": rank,
            "positive_preview": item["positive"][:150],
            "top_retrieved": top_retrieved,
        })

    n = len(results)
    if n == 0:
        return {}, []

    metrics = {
        "mrr": sum(reciprocal_ranks) / n,
        f"ndcg@{top_k}": sum(ndcg_scores) / n,
        "num_queries": n,
    }
    for k, count in hits_at_k.items():
        metrics[f"recall@{k}"] = count / n

    return metrics, results


# ════════════════════════════════════════════════════════════════
# 🎚️ MULTI-MODE RERANK TEST (dense + sparse + colbert)
# ════════════════════════════════════════════════════════════════

def evaluate_reranking(model, test_items, weights, batch_size=16):
    """
    Testa il reranking multi-mode (come in produzione).
    Per ogni query usa il positive + i suoi hard negatives dal dataset.
    Molto più realistico che usare negativi random.
    """
    correct = 0
    total = 0
    mrr_scores = []

    for item in test_items:
        query = item["query"]
        positive = item["positive"]
        negatives = item.get("negatives", [])

        if not negatives:
            continue

        # Max 7 hard negatives per non esplodere di tempo
        negs = negatives[:7]
        all_docs = [positive] + negs
        pairs = [(query, doc) for doc in all_docs]

        try:
            scores = model.compute_score(
                pairs,
                batch_size=batch_size,
                max_query_length=256,
                max_passage_length=1024,
                weights_for_different_modes=weights,
            )

            combined = scores["colbert+sparse+dense"]
            if not isinstance(combined, list):
                combined = [combined]

            # Rank del positive (index 0)
            ranked = np.argsort(combined)[::-1]
            pos_rank = int(np.where(ranked == 0)[0][0]) + 1

            if pos_rank == 1:
                correct += 1
            total += 1
            mrr_scores.append(1.0 / pos_rank)

        except Exception as e:
            print(f"    ⚠️ Errore rerank: {e}")
            continue

    accuracy = correct / total if total > 0 else 0
    mrr = sum(mrr_scores) / len(mrr_scores) if mrr_scores else 0

    return {
        "rerank_accuracy": accuracy,
        "rerank_mrr": mrr,
        "total": total,
        "correct": correct,
    }


# ════════════════════════════════════════════════════════════════
# 📊 REPORT
# ════════════════════════════════════════════════════════════════

def print_comparison(base_dense, ft_dense, base_rerank, ft_rerank, top_k):
    """Stampa confronto side-by-side."""

    print(f"\n{'═' * 70}")
    print(f"  📊  CONFRONTO: Base vs Fine-tunato")
    print(f"{'═' * 70}")

    # ── Dense Retrieval ──
    print(f"\n  ── Dense Retrieval (cosine similarity) ──\n")
    header = f"  {'Metrica':<25} {'Base':>10} {'Finetuned':>10} {'Delta':>10}"
    print(header)
    print(f"  {'─' * 55}")

    dense_keys = [f"recall@{k}" for k in [1, 3, 5, 10] if k <= top_k]
    dense_keys += ["mrr", f"ndcg@{top_k}"]

    for key in dense_keys:
        base_val = base_dense.get(key, 0)
        ft_val = ft_dense.get(key, 0)
        delta = ft_val - base_val
        arrow = "↑" if delta > 0.001 else "↓" if delta < -0.001 else "="
        color = "\033[32m" if delta > 0.001 else "\033[31m" if delta < -0.001 else ""
        reset = "\033[0m" if color else ""
        print(f"  {key:<25} {base_val:>9.1%} {ft_val:>9.1%} {color}{arrow} {abs(delta):>7.1%}{reset}")

    # ── Reranking Multi-Mode ──
    print(f"\n  ── Reranking Multi-Mode (dense+sparse+colbert) ──\n")
    print(f"  {'Metrica':<25} {'Base':>10} {'Finetuned':>10} {'Delta':>10}")
    print(f"  {'─' * 55}")

    for key in ["rerank_accuracy", "rerank_mrr"]:
        base_val = base_rerank.get(key, 0)
        ft_val = ft_rerank.get(key, 0)
        delta = ft_val - base_val
        arrow = "↑" if delta > 0.001 else "↓" if delta < -0.001 else "="
        color = "\033[32m" if delta > 0.001 else "\033[31m" if delta < -0.001 else ""
        reset = "\033[0m" if color else ""
        label = "accuracy" if "accuracy" in key else "mrr"
        print(f"  {label:<25} {base_val:>9.1%} {ft_val:>9.1%} {color}{arrow} {abs(delta):>7.1%}{reset}")

    print()

    # ── Verdetto ──
    ft_recall5 = ft_dense.get("recall@5", ft_dense.get("recall@10", 0))
    base_recall5 = base_dense.get("recall@5", base_dense.get("recall@10", 0))
    retrieval_improved = ft_recall5 > base_recall5 + 0.01
    rerank_improved = ft_rerank.get("rerank_accuracy", 0) > base_rerank.get("rerank_accuracy", 0) + 0.01

    if retrieval_improved and rerank_improved:
        print("  ✅ Il modello fine-tunato è MIGLIORE su retrieval e reranking!")
    elif retrieval_improved:
        print("  ✅ Retrieval migliorato. Reranking stabile.")
    elif rerank_improved:
        print("  ✅ Reranking migliorato. Retrieval stabile.")
    else:
        ft_mrr = ft_dense.get("mrr", 0)
        base_mrr = base_dense.get("mrr", 0)
        if ft_mrr > base_mrr + 0.01:
            print("  ✅ MRR migliorato (documenti rilevanti più in alto nel ranking).")
        else:
            print("  ⚠️ Nessun miglioramento chiaro. Considera:")
            print("     - Più dati di training (target 3000+ coppie)")
            print("     - Più hard negatives")
            print("     - Verificare qualità del dataset")


def print_qualitative_examples(base_results, ft_results, n_examples=5):
    """Mostra esempi dove il fine-tuning ha fatto la differenza."""

    print(f"\n{'═' * 70}")
    print(f"  🔍  ESEMPI QUALITATIVI")
    print(f"{'═' * 70}")

    # Miglioramenti
    improvements = []
    degradations = []

    for base_r, ft_r in zip(base_results, ft_results):
        base_rank = base_r["positive_rank"]
        ft_rank = ft_r["positive_rank"]
        if ft_rank < base_rank:
            improvements.append({
                "query": base_r["query"],
                "base_rank": base_rank,
                "ft_rank": ft_rank,
                "improvement": base_rank - ft_rank,
            })
        elif ft_rank > base_rank:
            degradations.append({
                "query": base_r["query"],
                "base_rank": base_rank,
                "ft_rank": ft_rank,
                "degradation": ft_rank - base_rank,
            })

    # Summary
    same = len(base_results) - len(improvements) - len(degradations)
    print(f"\n  Risultati su {len(base_results)} query:")
    print(f"    ✅ Migliorate:   {len(improvements)}")
    print(f"    ⚠️  Peggiorate:  {len(degradations)}")
    print(f"    ➡️  Invariate:   {same}")

    # Top miglioramenti
    improvements.sort(key=lambda x: -x["improvement"])
    if improvements:
        print(f"\n  Top {min(n_examples, len(improvements))} miglioramenti:\n")
        for i, imp in enumerate(improvements[:n_examples]):
            print(f"  [{i + 1}] \"{imp['query'][:80]}\"")
            print(f"      rank #{imp['base_rank']} → #{imp['ft_rank']}"
                  f"  (\033[32m↑ {imp['improvement']} posizioni\033[0m)")
            print()

    # Top degradamenti
    degradations.sort(key=lambda x: -x["degradation"])
    if degradations:
        n_show = min(3, len(degradations))
        print(f"  Top {n_show} peggioramenti:\n")
        for i, deg in enumerate(degradations[:n_show]):
            print(f"  [{i + 1}] \"{deg['query'][:80]}\"")
            print(f"      rank #{deg['base_rank']} → #{deg['ft_rank']}"
                  f"  (\033[31m↓ {deg['degradation']} posizioni\033[0m)")
            print()


# ════════════════════════════════════════════════════════════════
# 🚀 MAIN
# ════════════════════════════════════════════════════════════════

def run_test(args):
    """Entry point chiamato da cli.py"""
    random.seed(args.seed)

    print("""
╔══════════════════════════════════════════════════════════════╗
║        🔬  BGE-M3 Retrieval Quality Test                     ║
║        Base vs Fine-tunato                                   ║
║        (con train/test split + multi-mode reranking)         ║
╚══════════════════════════════════════════════════════════════╝
    """)

    # ── Verifica file ──
    if not os.path.exists(args.dataset):
        print(f"  ✗ Dataset non trovato: {args.dataset}")
        sys.exit(1)

    if not os.path.exists(args.model) and args.model != args.base_model:
        print(f"  ✗ Modello fine-tunato non trovato: {args.model}")
        sys.exit(1)

    # ── Carica e splitta dati ──
    print(f"  📊 Caricamento e split dataset: {args.dataset}")
    print(f"     Test split: {args.test_split:.0%}")

    test_items, corpus, split_info = load_and_split_data(
        args.dataset, args.test_split, args.test_queries, args.seed
    )

    if not test_items:
        print(f"  ✗ Nessun dato di test trovato")
        sys.exit(1)

    print(f"     Totale coppie:      {split_info['total_items']}")
    print(f"     Training:           {split_info['train_items']} coppie ({split_info['train_positives']} positivi)")
    print(f"     Test (held-out):    {split_info['test_items']} coppie ({split_info['test_positives']} positivi)")
    print(f"     Corpus:             {split_info['corpus_size']} documenti")

    print(f"\n  ⚠️  Le query di test NON sono state usate per il training.")
    print(f"     I risultati misurano la capacità di generalizzazione.\n")

    # ── Device ──
    device = get_device(args.device)
    print(f"  🖥️  Device: {device}")

    weights = [args.dense_weight, args.sparse_weight, args.colbert_weight]
    print(f"  🎚️  Rerank weights: dense={weights[0]}, sparse={weights[1]}, colbert={weights[2]}")

    # ══════════════════════════════════════════════════════════
    # TEST MODELLO BASE
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  📦 Test modello BASE: {args.base_model}")
    print(f"{'═' * 60}")

    print(f"\n  Caricamento modello base...")
    base_model = load_model(args.base_model, device)

    # Dense retrieval
    print(f"\n  🔍 Dense retrieval test...")
    start = time.time()
    base_dense, base_dense_results = evaluate_dense_retrieval(
        base_model, test_items, corpus, args.batch_size, args.max_len, args.top_k
    )
    print(f"    ⏱️ {time.time() - start:.1f}s")

    # Multi-mode rerank
    print(f"\n  🎚️ Multi-mode rerank test (dense+sparse+colbert)...")
    start = time.time()
    base_rerank = evaluate_reranking(base_model, test_items, weights, args.batch_size)
    print(f"    ⏱️ {time.time() - start:.1f}s")

    print(f"\n  Risultati base (dense retrieval):")
    for k, v in base_dense.items():
        if k != "num_queries":
            print(f"    {k}: {v:.1%}")
    print(f"  Risultati base (reranking):")
    print(f"    accuracy: {base_rerank['rerank_accuracy']:.1%}")
    print(f"    mrr: {base_rerank['rerank_mrr']:.1%}")

    # Libera memoria
    del base_model
    import torch
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    import gc
    gc.collect()

    # ══════════════════════════════════════════════════════════
    # TEST MODELLO FINE-TUNATO
    # ══════════════════════════════════════════════════════════

    print(f"\n{'═' * 60}")
    print(f"  🔧 Test modello FINETUNED: {args.model}")
    print(f"{'═' * 60}")

    print(f"\n  Caricamento modello fine-tunato...")
    ft_model = load_model(args.model, device)

    print(f"\n  🔍 Dense retrieval test...")
    start = time.time()
    ft_dense, ft_dense_results = evaluate_dense_retrieval(
        ft_model, test_items, corpus, args.batch_size, args.max_len, args.top_k
    )
    print(f"    ⏱️ {time.time() - start:.1f}s")

    print(f"\n  🎚️ Multi-mode rerank test (dense+sparse+colbert)...")
    start = time.time()
    ft_rerank = evaluate_reranking(ft_model, test_items, weights, args.batch_size)
    print(f"    ⏱️ {time.time() - start:.1f}s")

    print(f"\n  Risultati fine-tunato (dense retrieval):")
    for k, v in ft_dense.items():
        if k != "num_queries":
            print(f"    {k}: {v:.1%}")
    print(f"  Risultati fine-tunato (reranking):")
    print(f"    accuracy: {ft_rerank['rerank_accuracy']:.1%}")
    print(f"    mrr: {ft_rerank['rerank_mrr']:.1%}")

    del ft_model
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    gc.collect()

    # ══════════════════════════════════════════════════════════
    # CONFRONTO
    # ══════════════════════════════════════════════════════════

    print_comparison(base_dense, ft_dense, base_rerank, ft_rerank, args.top_k)
    print_qualitative_examples(base_dense_results, ft_dense_results)

    # ── Salva risultati dettagliati ──
    output_data = {
        "config": {
            "base_model": args.base_model,
            "finetuned_model": args.model,
            "test_split": args.test_split,
            "test_queries": split_info["test_items"],
            "train_queries": split_info["train_items"],
            "corpus_size": split_info["corpus_size"],
            "top_k": args.top_k,
            "rerank_weights": {
                "dense": args.dense_weight,
                "sparse": args.sparse_weight,
                "colbert": args.colbert_weight,
            },
        },
        "base": {
            "dense_retrieval": base_dense,
            "reranking": base_rerank,
        },
        "finetuned": {
            "dense_retrieval": ft_dense,
            "reranking": ft_rerank,
        },
        "per_query_base": base_dense_results[:20] if not args.verbose else base_dense_results,
        "per_query_finetuned": ft_dense_results[:20] if not args.verbose else ft_dense_results,
    }

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    print(f"\n  💾 Risultati salvati in: {args.output}")
    print(f"\n{'═' * 60}")
    print(f"  Fatto!")
    print(f"{'═' * 60}\n")


def main():
    args = parse_args()
    run_test(args)


if __name__ == "__main__":
    main()