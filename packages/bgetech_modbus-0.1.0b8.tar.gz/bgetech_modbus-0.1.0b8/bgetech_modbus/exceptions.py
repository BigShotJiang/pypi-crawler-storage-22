class CannotConnect(Exception):
    pass
