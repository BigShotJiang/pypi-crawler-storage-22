"""
Funções utilitárias para execução de comandos Docker e shell, com captura de saída e timeout.
Inclui:
 - Execução robusta de comandos externos
 - Checagem rápida de disponibilidade do Docker
"""
from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class CmdResult:
    """
    Resultado de uma execução de comando externo.
    - cmd: comando executado
    - returncode: código de retorno do processo
    - stdout: saída padrão
    - stderr: saída de erro
    - timed_out: True se houve timeout
    """
    cmd: List[str]
    returncode: int
    stdout: str
    stderr: str
    timed_out: bool


def run_cmd(
    cmd: List[str],
    *,
    cwd: Optional[Path] = None,
    timeout_sec: Optional[int] = None,
) -> CmdResult:
    """
    Executa um comando externo e captura stdout/stderr.
    - Usa modo texto (UTF-8)
    - Suporta timeout
    - Retorna CmdResult com todas as informações relevantes
    """
    try:
        proc = subprocess.Popen(
            cmd,
            cwd=str(cwd) if cwd else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        try:
            # Espera o comando terminar, respeitando o timeout
            out, err = proc.communicate(timeout=timeout_sec)
            return CmdResult(cmd=cmd, returncode=proc.returncode, stdout=out or "", stderr=err or "", timed_out=False)
        except subprocess.TimeoutExpired:
            # Timeout: mata o processo e coleta o que foi produzido
            proc.kill()
            out, err = proc.communicate()
            return CmdResult(cmd=cmd, returncode=proc.returncode or 124, stdout=out or "", stderr=err or "", timed_out=True)
    except FileNotFoundError as e:
        # Comando não encontrado (ex: docker não instalado)
        return CmdResult(cmd=cmd, returncode=127, stdout="", stderr=str(e), timed_out=False)


def docker_available() -> CmdResult:
    """
    Checagem rápida se o comando docker está disponível e funcional.
    """
    return run_cmd(["docker", "version"], timeout_sec=20)
