"""
Módulo de validação do Dockerfile do bundle AgentCore.
Inclui funções para inferir o entrypoint e checar instruções mínimas obrigatórias.
"""
from __future__ import annotations
from pathlib import Path
from typing import Optional, Tuple, List
import re
from .models import ValidationIssue

Entrypoint = Tuple[str, str]  # ("file","app.py") | ("module","module.name")

def infer_entrypoint_from_dockerfile_text(dockerfile_text: str) -> Optional[Entrypoint]:
    """
    Infere o entrypoint (arquivo ou módulo) a partir do texto do Dockerfile.
    Retorna uma tupla ("file", nome) ou ("module", nome) se encontrar CMD válido.
    """
    m = re.search(r'(?im)^\s*CMD\s*\[(.+?)\]\s*$', dockerfile_text)
    if not m:
        return None
    raw = m.group(1)
    tokens = re.findall(r'"([^"]+)"', raw)
    if not tokens or "python" not in tokens:
        return None

    i = tokens.index("python")
    if i + 2 < len(tokens) and tokens[i + 1] == "-m":
        return ("module", tokens[i + 2])
    if i + 1 < len(tokens) and tokens[i + 1].endswith(".py"):
        return ("file", tokens[i + 1])
    return None

def infer_entrypoint_from_dockerfile_path(dockerfile_path: Path) -> Optional[Entrypoint]:
    """
    Lê o Dockerfile e infere o entrypoint usando infer_entrypoint_from_dockerfile_text.
    """
    if not dockerfile_path.exists():
        return None
    text = dockerfile_path.read_text(encoding="utf-8", errors="ignore")
    return infer_entrypoint_from_dockerfile_text(text)

def check_dockerfile_minimum(dockerfile: Path) -> List[ValidationIssue]:
    """
    Checa se o Dockerfile contém instruções mínimas: FROM, COPY e CMD.
    Retorna uma lista de ValidationIssue para cada problema encontrado.
    """
    issues: List[ValidationIssue] = []
    if not dockerfile.exists():
        return issues

    text = dockerfile.read_text(encoding="utf-8", errors="ignore")

    if not re.search(r"(?im)^\s*FROM\s+\S+", text):
        issues.append(ValidationIssue(
            severity="ERROR",
            code="DOCKERFILE_MISSING_FROM",
            message="Dockerfile não contém FROM.",
            file=str(dockerfile),
            hint="Inclua uma imagem base: FROM public.ecr.aws/docker/library/python:3.11-slim (exemplo).",
        ))

    if not re.search(r"(?im)^\s*COPY\s+.+", text):
        issues.append(ValidationIssue(
            severity="WARN",
            code="DOCKERFILE_MISSING_COPY",
            message="Dockerfile não contém COPY (heurística).",
            file=str(dockerfile),
            hint="Normalmente você precisa copiar o código e requirements para dentro da imagem.",
        ))

    if not re.search(r"(?im)^\s*CMD\s+\[", text):
        issues.append(ValidationIssue(
            severity="WARN",
            code="DOCKERFILE_MISSING_CMD",
            message="Dockerfile não contém CMD em formato JSON array (heurística).",
            file=str(dockerfile),
            hint='Ex.: CMD ["opentelemetry-instrument","python","main.py"]',
        ))

    return issues
