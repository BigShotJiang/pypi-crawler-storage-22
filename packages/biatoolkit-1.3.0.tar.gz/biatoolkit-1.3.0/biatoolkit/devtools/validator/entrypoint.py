"""
Funções utilitárias para resolução e validação do entrypoint do bundle AgentCore.
Inclui validação de nomes de módulos, existência de arquivos e coerência com o Dockerfile.
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Optional, Tuple
import re

from .models import ValidationIssue
from .dockerfile_val import infer_entrypoint_from_dockerfile_path, Entrypoint
from .requirements import looks_like_external_dependency
from .python_checks import check_python_compiles, check_mcp_scaffold

_PY_MODULE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$")

def is_valid_python_module_name(name: str) -> bool:
    """
    Verifica se o nome informado é um nome de módulo Python válido (regex).
    Exemplo válido: my_module.submodule
    """
    return bool(_PY_MODULE_RE.match(name))

def module_exists_in_bundle(root: Path, module_name: str) -> bool:
    """
    Verifica se o módulo existe no bundle (como arquivo .py, __init__.py ou __main__.py).
    """
    parts = module_name.split(".")
    rel = Path(*parts)
    cand_file = root / rel.with_suffix(".py")  # mymod.py
    cand_pkg_init = root / rel / "__init__.py"  # mymod/__init__.py
    cand_pkg_main = root / rel / "__main__.py"  # mymod/__main__.py
    return cand_file.exists() or cand_pkg_init.exists() or cand_pkg_main.exists()

def resolve_entrypoint(
    root: Path,
    dockerfile_path: Path,
    entry_file: Optional[str],
    entry_module: Optional[str],
    issues: List[ValidationIssue],
) -> Optional[Entrypoint]:
    """
    Resolve o entrypoint do bundle, considerando argumentos explícitos e o Dockerfile.
    - Se ambos entry_file e entry_module são passados, gera erro de ambiguidade
    - Se entry_file é passado, valida existência e consistência com Dockerfile
    - Se entry_module é passado, valida consistência com Dockerfile
    - Se nenhum é passado, tenta inferir pelo Dockerfile
    """
    if entry_file and entry_module:
        # Não pode passar ambos
        issues.append(ValidationIssue(
            severity="ERROR",
            code="ENTRY_AMBIGUOUS",
            message="Passe apenas um: --entry-file OU --entry-module (não ambos).",
            hint="Ex.: --entry-module sales_agent_murilo",
        ))
        return None

    inferred = infer_entrypoint_from_dockerfile_path(dockerfile_path)

    if entry_file:
        p = root / entry_file
        if not p.exists():
            # Arquivo informado não existe
            issues.append(ValidationIssue(
                severity="ERROR",
                code="ENTRY_FILE_NOT_FOUND",
                message=f"Entry file informado não existe: {entry_file}",
                file=str(p),
                hint="Aponte para um arquivo .py existente dentro do bundle.",
            ))
            return None
        if inferred and inferred != ("file", entry_file):
            # Divergência entre argumento e Dockerfile
            issues.append(ValidationIssue(
                severity="ERROR",
                code="ENTRY_MISMATCH",
                message=f"Entry file ({entry_file}) não bate com o Dockerfile (inferred={inferred}).",
                file=str(dockerfile_path),
                hint="Ajuste o Dockerfile CMD ou use --entry-module/--entry-file correto.",
            ))
            return None
        return ("file", entry_file)

    if entry_module:
        if inferred and inferred != ("module", entry_module):
            # Divergência entre argumento e Dockerfile
            issues.append(ValidationIssue(
                severity="ERROR",
                code="ENTRY_MISMATCH",
                message=f"Entry module ({entry_module}) não bate com o Dockerfile (inferred={inferred}).",
                file=str(dockerfile_path),
                hint="Ajuste o Dockerfile CMD ou use --entry-module correto.",
            ))
            return None
        return ("module", entry_module)

    if not inferred:
        # Não foi possível inferir pelo Dockerfile
        issues.append(ValidationIssue(
            severity="ERROR",
            code="ENTRY_NOT_INFERRED",
            message="Não foi possível inferir entrypoint pelo Dockerfile.",
            file=str(dockerfile_path),
            hint="Passe --entry-file app.py ou --entry-module meu_modulo.",
        ))
        return None

    return inferred

def check_module_entrypoint(root: Path, module_name: str, *, allow_hyphen_module: bool) -> List[ValidationIssue]:
    """
    Valida se o módulo informado existe, é válido e compila.
    - Gera erro se o nome não é válido para python -m
    - Permite hífen se allow_hyphen_module=True (gera warning)
    - Se existir no bundle, checa compilação e scaffold MCP
    - Se não existir, verifica se parece dependência externa
    """
    issues: List[ValidationIssue] = []

    if not is_valid_python_module_name(module_name):
        # Nome inválido para python -m
        sev = "WARN" if allow_hyphen_module else "ERROR"
        issues.append(ValidationIssue(
            severity=sev,
            code="ENTRY_MODULE_INVALID_PYNAME",
            message=f"O entry_module '{module_name}' não é um nome de módulo Python válido para `python -m`.",
            hint=(
                "Você habilitou allow_hyphen_module=True (escape hatch). Confirme na Fase 2 (docker build/run)."
                if allow_hyphen_module else
                "Python não resolve hífen em nomes de módulo. Use módulo importável (underscore) no CMD."
            ),
        ))
        return issues

    if module_exists_in_bundle(root, module_name):
        # Módulo existe no bundle: checa compilação e scaffold MCP
        parts = module_name.split(".")
        package_main = root.joinpath(*parts) / "__main__.py"
        module_py = root.joinpath(*parts).with_suffix(".py")
        target = package_main if package_main.exists() else module_py
        issues.extend(check_python_compiles(target))
        issues.extend(check_mcp_scaffold(target))
        return issues

    if looks_like_external_dependency(root, module_name):
        # Não está no bundle, mas parece dependência externa
        issues.append(ValidationIssue(
            severity="WARN",
            code="ENTRY_MODULE_EXTERNAL",
            message=f"Não encontrei '{module_name}' no bundle, mas parece ser dependência externa (requirements.txt).",
            hint="Pode estar OK se o Dockerfile instala requirements.txt. Valide na Fase 2 (smoke test).",
        ))
        return issues

    # Não encontrado nem como local nem como dependência
    issues.append(ValidationIssue(
        severity="ERROR",
        code="MODULE_NOT_FOUND_IN_BUNDLE",
        message=f"Não encontrei '{module_name}' no bundle e não detectei dependência correspondente em requirements.txt.",
        hint="Se for código local, adicione ao bundle. Se for pip, inclua no requirements.txt.",
    ))
    return issues

def check_file_entrypoint(root: Path, file_name: str) -> List[ValidationIssue]:
    """
    Valida se o arquivo informado existe, compila e contém scaffold MCP.
    """
    entry_path = root / file_name
    issues: List[ValidationIssue] = []
    issues.extend(check_python_compiles(entry_path))
    issues.extend(check_mcp_scaffold(entry_path))
    return issues
