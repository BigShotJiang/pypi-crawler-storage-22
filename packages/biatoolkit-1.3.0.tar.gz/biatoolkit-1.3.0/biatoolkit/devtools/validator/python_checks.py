"""
Funções para checagens específicas em código Python do bundle AgentCore.
Inclui validação de compilação e presença de decorators MCP.
"""
from __future__ import annotations
from pathlib import Path
from typing import List
import py_compile
from .models import ValidationIssue

def check_python_compiles(py_path: Path) -> List[ValidationIssue]:
    """
    Tenta compilar o arquivo Python informado.
    - Retorna erro se o arquivo não existir
    - Retorna erro se houver problema de sintaxe/compilação
    """
    issues: List[ValidationIssue] = []
    if not py_path.exists():
        # Arquivo não encontrado
        issues.append(ValidationIssue(
            severity="ERROR",
            code="ENTRY_FILE_NOT_FOUND",
            message=f"Arquivo de entrypoint não encontrado: {py_path.name}",
            file=str(py_path),
        ))
        return issues

    try:
        # Compila o arquivo Python (levanta exceção se houver erro)
        py_compile.compile(str(py_path), doraise=True)
    except Exception as e:
        # Erro de sintaxe ou compilação
        issues.append(ValidationIssue(
            severity="ERROR",
            code="PYTHON_SYNTAX_ERROR",
            message=f"Arquivo {py_path.name} não compila (erro de sintaxe/compilação): {e}",
            file=str(py_path),
            hint="Abra o arquivo e corrija o erro indicado. Rode novamente o validate.",
        ))
    return issues

def check_mcp_scaffold(py_path: Path) -> List[ValidationIssue]:
    """
    Verifica se o arquivo contém referências a FastMCP/mcp e decorators @mcp.tool.
    - Gera warnings heurísticos caso não encontre
    - Não retorna erro se o arquivo não existir
    """
    issues: List[ValidationIssue] = []
    if not py_path.exists():
        return issues  # Arquivo não existe, não há o que checar

    text = py_path.read_text(encoding="utf-8", errors="ignore")

    # Heurística: verifica se há referência a FastMCP ou mcp
    if "FastMCP" not in text and "mcp" not in text:
        issues.append(ValidationIssue(
            severity="WARN",
            code="MCP_FASTMCP_NOT_FOUND",
            message=f"Não encontrei referência a FastMCP/mcp em {py_path.name} (heurística).",
            file=str(py_path),
            hint="Certifique-se de que o MCP server utiliza FastMCP (ou biblioteca MCP equivalente).",
        ))

    # Heurística: verifica se há pelo menos um decorator @mcp.tool
    if "@mcp.tool" not in text:
        issues.append(ValidationIssue(
            severity="WARN",
            code="MCP_TOOL_DECORATOR_NOT_FOUND",
            message=f"Não encontrei '@mcp.tool' em {py_path.name} (heurística).",
            file=str(py_path),
            hint="Certifique-se de que ao menos uma tool está registrada com @mcp.tool.",
        ))

    return issues
