# Validação dinâmica (em tempo de execução) do bundle AgentCore
"""
Módulo de validação dinâmica (smoke test) do bundle AgentCore.
Executa validações em tempo de execução usando Docker:
 1. (Opcional) Validação estática prévia
 2. docker build
 3. docker run (container detached)
 4. (Opcional) Health check HTTP
 5. Limpeza de container/imagem

O objetivo é garantir que o container inicia corretamente com o CMD do Dockerfile.
"""
from __future__ import annotations

import hashlib
import json
import time
import urllib.request
import asyncio
from biatoolkit.basic_client import BiaClient
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from biatoolkit.devtools.validator.models import ValidationIssue, ValidationResult
from .docker_runner import run_cmd, docker_available


def _default_tag(project_path: Path) -> str:
    h = hashlib.sha1(str(project_path).encode("utf-8")).hexdigest()[:10]
    ts = int(time.time())
    return f"biatoolkit-smoke:{h}-{ts}"


def _default_container_name(project_path: Path) -> str:
    h = hashlib.sha1((str(project_path) + str(time.time())).encode("utf-8")).hexdigest()[:12]
    return f"biatoolkit_smoke_{h}"


def _http_get(url: str, timeout_sec: int = 3) -> Tuple[bool, str]:
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            body = resp.read(1024).decode("utf-8", errors="ignore")
            return True, f"HTTP {resp.status}: {body[:200]}"
    except Exception as e:
        return False, str(e)


def _vprint(verbose: bool, msg: str) -> None:
    if verbose:
        print(msg, flush=True)


def smoke_validate_bundle(
    project_path: str | Path,
    *,
    tag: Optional[str] = None,
    run_seconds: int = 8,
    build_timeout_sec: int = 600,
    start_timeout_sec: int = 60,
    keep_image: bool = False,
    keep_container: bool = False,
    skip_static: bool = False,
    env: Optional[Dict[str, str]] = None,
    port: Optional[int] = None,
    health_path: Optional[str] = None,
    verbose: bool = False,
    show_logs: bool = False,
    mcp_url: Optional[str] = None,
    skip_mcp_list_tools: bool = False,
    logs_tail_lines: int = 80,          
) -> ValidationResult:
    """
    Smoke test:
      1) (optional) static validate
      2) docker build
      3) docker run (detached), ensure it stays alive for `run_seconds`
      4) (optional) HTTP health check
      5) cleanup
    """
    root = Path(project_path).resolve()
    issues: List[ValidationIssue] = []

    _vprint(verbose, "")
    _vprint(verbose, "=== BIATOOLKIT SMOKE (Runtime) - verbose ===")
    _vprint(verbose, f"Path: {root}")

    # 0) docker available?
    _vprint(verbose, "[0/4] Checking Docker availability...")
    dv = docker_available()
    if dv.returncode != 0:
        issues.append(
            ValidationIssue(
                severity="ERROR",
                code="DOCKER_NOT_AVAILABLE",
                message="Docker CLI não está disponível (ou não está rodando).",
                hint="Instale o Docker Desktop e garanta que o daemon está rodando. "
                     f"Detalhes: {dv.stderr.strip() or dv.stdout.strip()}",
            )
        )
        return ValidationResult(ok=False, issues=issues)
    _vprint(verbose, "✔ Docker available")

    # 1) static validate
    if not skip_static:
        _vprint(verbose, "[1/4] Running static validation...")
        t0 = time.time()
        static_res = _run_static_validate(root)
        dt = time.time() - t0

        _vprint(verbose, f"{'✔' if static_res.ok else '✖'} Static validation "
                         f"{'passed' if static_res.ok else 'failed'} ({dt:.2f}s)")

        issues.extend(static_res.issues)
        if not static_res.ok:
            issues.append(
                ValidationIssue(
                    severity="INFO",
                    code="SMOKE_ABORTED_BY_STATIC",
                    message="Smoke test não executado porque a validação estática falhou.",
                    hint="Corrija os erros da fase estática ou use --skip-static para forçar.",
                )
            )
            return ValidationResult(ok=False, issues=issues)
    else:
        _vprint(verbose, "[1/4] Skipping static validation (--skip-static).")

    # 2) docker build
    img_tag = tag or _default_tag(root)
    _vprint(verbose, f"[2/4] Building Docker image: {img_tag}")
    t0 = time.time()
    build = run_cmd(["docker", "build", "-t", img_tag, "."], cwd=root, timeout_sec=build_timeout_sec)
    dt = time.time() - t0

    if build.timed_out:
        issues.append(
            ValidationIssue(
                severity="ERROR",
                code="DOCKER_BUILD_TIMEOUT",
                message=f"docker build excedeu timeout ({build_timeout_sec}s).",
                hint="Verifique downloads/pip install. Tente aumentar --build-timeout-sec.",
            )
        )
        return ValidationResult(ok=False, issues=issues)

    if build.returncode != 0:
        issues.append(
            ValidationIssue(
                severity="ERROR",
                code="DOCKER_BUILD_FAILED",
                message=f"docker build falhou ({dt:.2f}s).",
                hint=_format_cmd_failure(build),
            )
        )
        return ValidationResult(ok=False, issues=issues)

    _vprint(verbose, f"✔ Docker image built ({dt:.2f}s)")

    # 3) docker run (detached)
    name = _default_container_name(root)
    _vprint(verbose, f"[3/4] Starting container: {name}")

    run_cmd_list = ["docker", "run", "-d", "--name", name]
    if env:
        for k, v in env.items():
            run_cmd_list += ["-e", f"{k}={v}"]
    if port:
        run_cmd_list += ["-p", f"{port}:{port}"]
        _vprint(verbose, f"  - Port mapping: {port}:{port}")
    run_cmd_list.append(img_tag)

    t0 = time.time()
    runr = run_cmd(run_cmd_list, timeout_sec=start_timeout_sec)
    dt = time.time() - t0

    if runr.timed_out or runr.returncode != 0:
        issues.append(
            ValidationIssue(
                severity="ERROR",
                code="DOCKER_RUN_FAILED",
                message=f"docker run falhou ao iniciar container ({dt:.2f}s).",
                hint=_format_cmd_failure(runr),
            )
        )
        _cleanup_container(name, keep_container=True)  # safe
        _cleanup_image(img_tag, keep_image=keep_image)
        return ValidationResult(ok=False, issues=issues)

    container_id = (runr.stdout or "").strip()
    if not container_id:
        issues.append(
            ValidationIssue(
                severity="ERROR",
                code="DOCKER_RUN_NO_CONTAINER_ID",
                message="docker run não retornou container id.",
            )
        )
        _cleanup_container(name, keep_container=keep_container)
        _cleanup_image(img_tag, keep_image=keep_image)
        return ValidationResult(ok=False, issues=issues)

    _vprint(verbose, f"✔ Container started ({dt:.2f}s) id={container_id[:12]}")

    # 4) wait and check if still running
    wait_total = max(1, int(run_seconds))
    _vprint(verbose, f"[4/4] Waiting {wait_total}s to ensure container stays alive...")

    for i in range(wait_total):
        time.sleep(1)
        if verbose:
            _vprint(verbose, f"  ... {i+1}/{wait_total}s")

    still_running, exit_code = _inspect_container(name)
    if not still_running:
        detail = _inspect_container_detailed(name)
        logs = _container_logs(name, tail_lines=200)

        hint_parts = [
            _format_container_detail(detail, fallback_exit_code=exit_code),
            "\n--- docker logs (tail 200) ---\n" + _tail(logs, 4000),
        ]
        issues.append(
            ValidationIssue(
                severity="ERROR",
                code="CONTAINER_EXITED_EARLY",
                message=f"Container terminou antes de {wait_total}s.",
                hint="\n".join([p for p in hint_parts if p]),
            )
        )
        _cleanup_container(name, keep_container=keep_container)
        _cleanup_image(img_tag, keep_image=keep_image)
        return ValidationResult(ok=False, issues=issues)

    _vprint(verbose, "✔ Container is still running")

    # 5) optional MCP ListTools
    if mcp_url:
        _vprint(verbose, f"[+] MCP ListTools (via BiaClient): {mcp_url}")

        ok_tools, info = _mcp_list_tools_via_biatoolkit(mcp_url, timeout_sec=60)
        if not ok_tools:
            logs = _container_logs(name)
            issues.append(
                ValidationIssue(
                    severity="ERROR",
                    code="MCP_LISTTOOLS_FAILED",
                    message=f"Falha ao executar MCP ListTools em {mcp_url}.",
                    hint=f"{info}\n\n--- container logs (tail) ---\n{_tail(logs, n=3000)}",
                )
            )
            _cleanup_container(name, keep_container=keep_container)
            _cleanup_image(img_tag, keep_image=keep_image)
            return ValidationResult(ok=False, issues=issues)


        issues.append(
            ValidationIssue(
                severity="INFO",
                code="MCP_LISTTOOLS_OK",
                message="MCP ListTools executado com sucesso (via BiaClient).",
                hint=info,
            )
        )
        _vprint(verbose, f"✔ MCP ListTools OK: {info}")

        # Se info contiver 'names=[...]', extrai e imprime cada tool
        if "names=[" in info:
            try:
                import ast
                names_str = info.split("names=")[-1]
                if names_str.startswith("["):
                    names = ast.literal_eval(names_str.split(";")[0])
                    if isinstance(names, list):
                        _vprint(verbose, f"Lista de tools disponíveis:")
                        for tool in names:
                            _vprint(verbose, f"  - {tool}")
            except Exception as e:
                _vprint(verbose, f"[!] Erro ao extrair nomes das tools: {e}")


    # 5) optional health check
    if port and health_path:
        url = f"http://127.0.0.1:{port}{health_path}"
        _vprint(verbose, f"[+] Optional health check: {url}")
        ok_h, info = _http_get(url, timeout_sec=3)
        if not ok_h:
            issues.append(
                ValidationIssue(
                    severity="WARN",
                    code="HEALTHCHECK_FAILED",
                    message=f"Health check falhou em {url}.",
                    hint=info,
                )
            )
            _vprint(verbose, f"⚠ Health check failed: {info}")
        else:
            issues.append(
                ValidationIssue(
                    severity="INFO",
                    code="HEALTHCHECK_OK",
                    message=f"Health check OK em {url}.",
                    hint=info,
                )
            )
            _vprint(verbose, f"✔ Health check OK: {info}")

    if show_logs:
        _vprint(verbose, "[*] Showing container logs (tail 80)...")
        print(_container_logs(name).splitlines()[-80:])

    # ✅ show logs even on success
    if show_logs:
        _vprint(verbose, f"[*] Showing container logs (tail {logs_tail_lines})...")
        print(_container_logs(name, tail_lines=logs_tail_lines), flush=True)

    # 6) cleanup
    _vprint(verbose, "[*] Cleaning up...")
    _cleanup_container(name, keep_container=keep_container)
    _cleanup_image(img_tag, keep_image=keep_image)


    ok = not any(i.severity == "ERROR" for i in issues)
    # Print status final colorido
    if verbose:
        if ok:
            print("\033[92m[OK] Smoke test finalizado com sucesso\033[0m", flush=True)
        else:
            print("\033[91m[ERRO] Smoke test encontrou falhas\033[0m", flush=True)
    else:
        _vprint(verbose, "✔ Smoke finished")
    return ValidationResult(ok=ok, issues=issues)


def _run_static_validate(root: Path) -> ValidationResult:
    # Preferred new path:
    try:
        from biatoolkit.devtools.validator.static.validator import validate_agentcore_bundle  # type: ignore
        return validate_agentcore_bundle(root)
    except Exception:
        pass

    # Fallback: old facade
    try:
        from biatoolkit.devtools.agentcore_validator import validate_agentcore_bundle  # type: ignore
        return validate_agentcore_bundle(root)
    except Exception as e:
        return ValidationResult(
            ok=True,
            issues=[
                ValidationIssue(
                    severity="WARN",
                    code="STATIC_VALIDATE_NOT_AVAILABLE",
                    message="Não consegui importar a validação estática; continuando apenas com smoke.",
                    hint=str(e),
                )
            ],
        )


def _inspect_container(name: str) -> Tuple[bool, Optional[int]]:
    running = run_cmd(["docker", "inspect", "-f", "{{.State.Running}}", name], timeout_sec=10)
    if running.returncode != 0:
        return False, None
    is_running = (running.stdout or "").strip().lower() == "true"

    exit_code = None
    ec = run_cmd(["docker", "inspect", "-f", "{{.State.ExitCode}}", name], timeout_sec=10)
    if ec.returncode == 0:
        try:
            exit_code = int((ec.stdout or "").strip())
        except Exception:
            exit_code = None
    return is_running, exit_code


def _inspect_container_detailed(name: str) -> Dict[str, object]:
    """
    Retorna um dict com detalhes úteis do docker inspect.
    (Não explode em caso de erro; retorna {}.)
    """
    res = run_cmd(["docker", "inspect", name], timeout_sec=10)
    if res.returncode != 0:
        return {"_inspect_error": _format_cmd_failure(res)}
    try:
        arr = json.loads(res.stdout or "[]")
        if not arr:
            return {}
        obj = arr[0]
        state = obj.get("State", {}) if isinstance(obj, dict) else {}
        return {
            "Running": state.get("Running"),
            "ExitCode": state.get("ExitCode"),
            "OOMKilled": state.get("OOMKilled"),
            "Error": state.get("Error"),
            "StartedAt": state.get("StartedAt"),
            "FinishedAt": state.get("FinishedAt"),
            "Status": state.get("Status"),
        }
    except Exception as e:
        return {"_inspect_parse_error": str(e)}


def _format_container_detail(detail: Dict[str, object], fallback_exit_code: Optional[int]) -> str:
    if not detail:
        return ""

    if "_inspect_error" in detail:
        return f"--- docker inspect error ---\n{detail['_inspect_error']}"

    parts = ["--- docker inspect (State) ---"]
    exit_code = detail.get("ExitCode", fallback_exit_code)
    parts.append(f"ExitCode: {exit_code}")
    if "OOMKilled" in detail:
        parts.append(f"OOMKilled: {detail.get('OOMKilled')}")
    if detail.get("Error"):
        parts.append(f"Error: {detail.get('Error')}")
    if detail.get("Status"):
        parts.append(f"Status: {detail.get('Status')}")
    if detail.get("StartedAt"):
        parts.append(f"StartedAt: {detail.get('StartedAt')}")
    if detail.get("FinishedAt"):
        parts.append(f"FinishedAt: {detail.get('FinishedAt')}")
    return "\n".join(parts)


def _container_logs(name: str, *, tail_lines: int = 200) -> str:
    res = run_cmd(["docker", "logs", "--tail", str(tail_lines), name], timeout_sec=10)
    out = (res.stdout or "")
    err = ("\n" + res.stderr) if res.stderr else ""
    return out + err


def _cleanup_container(name: str, *, keep_container: bool) -> None:
    if keep_container:
        return
    run_cmd(["docker", "rm", "-f", name], timeout_sec=20)


def _cleanup_image(tag: str, *, keep_image: bool) -> None:
    if keep_image:
        return
    run_cmd(["docker", "rmi", "-f", tag], timeout_sec=30)


def _format_cmd_failure(res) -> str:
    """
    Formata um erro de comando de forma útil, sem floodar.
    """
    cmd_str = " ".join(res.cmd) if getattr(res, "cmd", None) else "<cmd>"
    timed = " (timed out)" if getattr(res, "timed_out", False) else ""
    body = (res.stderr or "") + ("\n" + res.stdout if res.stdout else "")
    body = body.strip()
    body_tail = _tail(body, 3000)
    return f"cmd: {cmd_str}\nreturncode: {res.returncode}{timed}\n--- tail ---\n{body_tail}"


def _tail(s: str, n: int = 1500) -> str:
    if not s:
        return ""
    s = s.strip()
    return s if len(s) <= n else ("..." + s[-n:])

def _mcp_list_tools_via_biatoolkit(mcp_url: str, timeout_sec: int = 8) -> Tuple[bool, str]:
    """
    Usa o BiaClient (cliente oficial MCP via streamablehttp_client) para list_tools.
    Isso evita 406 e valida o handshake MCP real.
    """

    async def _run() -> Tuple[bool, str]:
        try:
            # BiaClient já garante o sufixo /mcp (se não tiver)
            client = BiaClient(mcp_url)

            # opcional: ajustar timeout do client se quiser (depende do settings)
            # client.settings.client_timeout_seconds = timeout_sec

            tools = await client.list_tools()

            # tools é do tipo retornado pelo mcp ClientSession; aqui só resumimos
            items = getattr(tools, "tools", None) or []
            names = [getattr(t, "name", None) for t in items]
            names = [n for n in names if n]
            return True, f"tools={len(items)}; names={names[:30]}"

        except Exception as e:
            return False, str(e)

    # smoke_validate_bundle é síncrono; fazemos bridge sync->async
    return asyncio.run(_run())
