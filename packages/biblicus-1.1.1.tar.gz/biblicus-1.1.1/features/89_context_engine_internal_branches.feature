Feature: Context engine internal branches
  The Context engine internal helpers should be exercised for coverage.

  Scenario: Context assembler reports missing context
    When I assemble a missing Context
    Then the context error should mention "Context 'missing' not defined"

  Scenario: Context assembler uses fallback user message when none exists
    When I extract a user message from messages without a user entry
    Then the extracted user message equals "fallback"

  Scenario: Context assembler resolves templates and joins messages
    When I resolve a template with dotted fields
    Then the resolved template equals "Hello world"

  Scenario: Context assembler applies budget trimming and compaction
    When I apply context budget trimming with compact overflow
    Then the compacted system prompt equals "one two"

  Scenario: Context assembler renders retriever packs from config
    Given a retriever registry with a corpus-backed retriever
    When I render that retriever pack with a template query
    Then the rendered retriever pack equals "pack text"

  Scenario: Context assembler skips empty pack content
    Given a retriever registry with a corpus-backed retriever
    When I assemble messages with an empty context pack
    Then the assembled messages should be empty

  Scenario: Context assembler inserts non-empty pack content
    Given a retriever registry with a corpus-backed retriever
    When I assemble messages with a non-empty context pack
    Then the assembled messages should include the pack content

  Scenario: Context assembler applies pipeline query settings
    Given a retriever registry with pipeline query and index config
    When I render that retriever pack with pipeline config
    Then the retriever request should include pipeline query values
    And the retriever request should include pipeline index configuration

  Scenario: Context assembler uses index config when pipeline is missing
    Given a retriever registry with index-only config
    When I render that retriever pack with index config
    Then the retriever request should include index configuration

  Scenario: Context assembler falls back to empty pipeline index config
    Given a retriever registry with pipeline query only
    When I render that retriever pack with pipeline-only config
    Then the retriever request should include empty configuration

  Scenario: Context assembler handles query config without limit
    Given a retriever registry with pipeline query config missing limit
    When I render that retriever pack with missing-limit query config
    Then the retriever request should include query settings without limit

  Scenario: Context assembler raises when no retriever is available
    Given a retriever registry with a corpus-backed retriever
    When I render that retriever pack without a retriever function
    Then the context error should mention "No retriever override or default retriever configured"

  Scenario: Nested context packs forbid history directives
    When I render a nested Context pack that includes history
    Then the context error should mention "Nested context packs cannot include history()"

  Scenario: Context assembler exercises default and explicit assembly paths
    When I assemble default and explicit Context paths
    Then the explicit user message equals "explicit user"
    And the default system prompt includes "base system"
