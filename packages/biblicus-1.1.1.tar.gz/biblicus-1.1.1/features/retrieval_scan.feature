Feature: Retrieval with scan retriever
  The scan retriever performs deterministic full-text scans across markdown and text
  items without materializing external indexes.

  Scenario: Build a scan snapshot and query for evidence
    Given I initialized a corpus at "corpus"
    And a text file "alpha.md" exists with contents "alpha bravo charlie"
    When I ingest the file "alpha.md" into corpus "corpus"
    And I build a "scan" retrieval snapshot in corpus "corpus"
    And I query with the latest snapshot for "bravo" and budget:
      | key                  | value |
      | max_total_items      | 5     |
      | maximum_total_characters | 2000  |
      | max_items_per_source | 5     |
    Then the query returns evidence with stage "scan"
    And the query evidence includes the last ingested item identifier

  Scenario: Scan query respects the max_total_items budget
    Given I initialized a corpus at "corpus"
    And a text file "one.md" exists with contents "topic one"
    And a text file "two.md" exists with contents "topic two"
    When I ingest the file "one.md" into corpus "corpus"
    And I ingest the file "two.md" into corpus "corpus"
    And I build a "scan" retrieval snapshot in corpus "corpus"
    And I query with the latest snapshot for "topic" and budget:
      | key                  | value |
      | max_total_items      | 1     |
      | maximum_total_characters | 2000  |
      | max_items_per_source | 5     |
    Then the query evidence count is 1

  Scenario: Scan query respects the maximum_total_characters budget
    Given I initialized a corpus at "corpus"
    When I ingest the text "longtext longtext longtext longtext" with title "Long" and tags "a" into corpus "corpus"
    And I build a "scan" retrieval snapshot in corpus "corpus"
    And I query with the latest snapshot for "longtext" and budget:
      | key                  | value |
      | max_total_items      | 5     |
      | maximum_total_characters | 1     |
      | max_items_per_source | 5     |
    Then the query evidence count is 0

  Scenario: Scan retriever ignores non-text items
    Given I initialized a corpus at "corpus"
    And a binary file "blob.bin" exists
    When I ingest the file "blob.bin" into corpus "corpus"
    And I build a "scan" retrieval snapshot in corpus "corpus"
    And I query with the latest snapshot for "blob" and budget:
      | key                  | value |
      | max_total_items      | 5     |
      | maximum_total_characters | 2000  |
      | max_items_per_source | 5     |
    Then the query evidence count is 0

  Scenario: Scan handles plain text files
    Given I initialized a corpus at "corpus"
    And a text file "plain.txt" exists with contents "plain content"
    When I ingest the file "plain.txt" into corpus "corpus"
    And I build a "scan" retrieval snapshot in corpus "corpus"
    And I query with the latest snapshot for "plain" and budget:
      | key                  | value |
      | max_total_items      | 5     |
      | maximum_total_characters | 2000  |
      | max_items_per_source | 5     |
    Then the query evidence count is 1
