# Copyright (C) 2025 APH10 Limited
# SPDX-License-Identifier: Apache-2.0

VERSION: str = "0.3.1"
