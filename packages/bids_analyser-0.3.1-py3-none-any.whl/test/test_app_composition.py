from textual.app import App
from textual.widgets import Button, Header, Footer, Input, Static
from textual.containers import Container, VerticalScroll
from textual.pilot import Pilot
import pytest
import asyncio


from bids.gui import BidsUI, MainScreen

@pytest.mark.asyncio
async def test_MainScreen():
    # Check that the initial screeen composes its expected widgets.
    app = BidsUI()
    async with app.run_test() as pilot:

        # Assert that the correct screen is active after on_mount runs
        await pilot.wait_for_animation()
        assert isinstance(pilot.app.screen, MainScreen)

        # Check if Header and Footer are present
        #header = pilot.app.query_one(Header)
        #assert header is not None
        #assert header.name == "BIDS - Binary Analysis"
        #footer = pilot.app.query_one(Footer)
        #assert footer is not None

        # Check for buttons
        analyse_button = pilot.app.query_one("#analyse", Button)
        assert analyse_button is not None
        assert analyse_button.disabled == True

        # # Check for the log display and search input within the main content
        # log_scroll = pilot.app.query_one("#log_display_container", VerticalScroll)
        # search_input = pilot.app.query_one("#search_input", Input)

        # assert log_scroll is not None
        # assert search_input is not None

        # # Check their parentage (optional, but good for complex layouts)
        # assert log_scroll.parent == main_content
        # assert search_input.parent == main_content

        # # Assert initial visibility of the search input
        # assert search_input.styles.display == "none" # Assuming it starts hidden