import pytest
from textual.app import App
from textual.widgets import Input, Static
from textual.containers import VerticalScroll
from textual.screen import Screen # If you're using Screens
from textual.reactive import reactive # If your class uses reactive

# Assume your MyApp and LogContainer are imported
# from your_app_module import MyApp, LogContainer, SearchCleared

# --- Simplified versions of your app components for test context ---
class SearchCleared(Event): # Define this for the test
    pass

class LogContainer(Container):
    search_term: reactive[str] = reactive("")
    current_match_line: reactive[int | None] = reactive(None)
    def render_log_lines(self, msgs):
        self.remove_children()
        for i, msg in enumerate(msgs):
            highlighted_text = Text(msg) # Simplified for test
            if i == self.current_match_line:
                highlighted_text.stylize("b red") # Highlight for test
            self.mount(Static(highlighted_text))

class SearchInput(Input):
    def on_key(self, event: Key) -> None:
        if event.key == "escape":
            self.app.post_message(SearchCleared())
            self.value = ""
            event.prevent_default()
            event.stop()
            return

class MyApp(App):
    BINDINGS = [
        Binding("slash", "toggle_search", "Search", show=True, key_display="/"),
        Binding("n", "next_match", "Next Match", show=False),
        Binding("p", "previous_match", "Previous Match", show=False),
    ]
    _all_log_messages = ["line one error", "line two warning", "line three"]
    show_search_input: reactive[bool] = reactive(False)
    _match_indices = []
    current_match_index: reactive[int | None] = reactive(None)

    def compose(self):
        yield Header()
        with Container():
            yield VerticalScroll(id="log_display_container"):
                yield LogContainer(id="log_display")
            yield SearchInput(id="search_input")
        yield Footer()

    CSS = """
    Container { layout: vertical; height: 1fr; }
    #log_display_container { height: 1fr; }
    #search_input { height: auto; display: none; }
    """ # Simplified CSS for test

    def watch_show_search_input(self, show: bool):
        self.query_one("#search_input").styles.display = "block" if show else "none"
        if show: self.query_one("#search_input").focus()
        else: self.query_one("#search_input").blur()

    def on_mount(self):
        self._redraw_log_content("")
        self.show_search_input = False # Ensure initial state is hidden

    @on(Input.Submitted, "#search_input")
    def on_input_submitted(self, event: Input.Submitted):
        search_term = event.value
        log_container = self.query_one("#log_display", LogContainer)
        log_container.search_term = search_term
        self._match_indices = [i for i, msg in enumerate(self._all_log_messages) if search_term in msg]
        self.current_match_index = 0 if self._match_indices else None
        self.show_search_input = False

    @on(SearchCleared)
    def on_search_cleared(self):
        self.query_one("#log_display", LogContainer).search_term = ""
        self._match_indices = []
        self.current_match_index = None
        self.show_search_input = False
        self._redraw_log_content("")

    def action_toggle_search(self):
        self.show_search_input = not self.show_search_input

    def action_next_match(self):
        if self._match_indices:
            self.current_match_index = (self.current_match_index + 1) % len(self._match_indices)
    
    def action_previous_match(self):
        if self._match_indices:
            self.current_match_index = (self.current_match_index - 1 + len(self._match_indices)) % len(self._match_indices)

    def _redraw_log_content(self, term):
        log_container = self.query_one("#log_display", LogContainer)
        log_container.current_match_line = (
            self._match_indices[self.current_match_index]
            if self.current_match_index is not None and self._match_indices
            else None
        )
        log_container.render_log_lines(self._all_log_messages)
        # Simplified scroll for test
        if self.current_match_index is not None and self._match_indices:
            self.query_one("#log_display_container").scroll_y = 100 # Simulate scroll
        else:
             self.query_one("#log_display_container").scroll_y = 0


# --- Test file: test_app_interactions.py ---

@pytest.mark.asyncio
async def test_toggle_search_input():
    async with MyApp().run_test() as app:
        search_input = app.query_one("#search_input", Input)

        # Initially hidden
        assert search_input.styles.display == "none"
        assert search_input.has_focus is False

        # Toggle search (/)
        await app.press("/")
        assert search_input.styles.display == "block"
        assert search_input.has_focus is True

        # Toggle search again (/)
        await app.press("/")
        assert search_input.styles.display == "none"
        assert search_input.has_focus is False


@pytest.mark.asyncio
async def test_search_and_highlight():
    async with MyApp().run_test() as app:
        search_input = app.query_one("#search_input", Input)
        log_display = app.query_one("#log_display", LogContainer)

        await app.press("/") # Open search
        await app.workers.wait_until_ready() # Wait for DOM updates

        search_input.value = "error"
        await app.press("enter") # Submit search
        await app.workers.wait_until_ready() # Wait for DOM updates

        # Assert search input is hidden after submission
        assert search_input.styles.display == "none"
        
        # Assert log container has the correct search term and current match
        assert log_display.search_term == "error"
        assert log_display.current_match_line == 0 # First match is 'line one error'

        # Verify content of the first line (requires inspecting Static widget)
        # This is a bit more involved as Static widgets store Rich.Text
        first_log_line_static = log_display.query(Static).first()
        assert "error" in first_log_line_static.renderable.plain.lower() # Check plain text
        # To check rich styling, you'd inspect first_log_line_static.renderable.spans

        # Test 'n' for next match
        await app.press("n")
        await app.workers.wait_until_ready()
        assert log_display.current_match_line == 1 # Second match is 'line two warning' (assuming 'error' not in 'warning')
        assert app.current_match_index == 1 # Check app's internal state

        # Test 'p' for previous match
        await app.press("p")
        await app.workers.wait_until_ready()
        assert log_display.current_match_line == 0
        assert app.current_match_index == 0


@pytest.mark.asyncio
async def test_escape_key_hides_search_input():
    async with MyApp().run_test() as app:
        search_input = app.query_one("#search_input", Input)
        log_display = app.query_one("#log_display", LogContainer)

        await app.press("/") # Open search
        await app.workers.wait_until_ready()

        assert search_input.styles.display == "block"
        assert search_input.has_focus is True

        await app.press("escape") # Press escape
        await app.workers.wait_until_ready()

        assert search_input.styles.display == "none"
        assert search_input.has_focus is False
        assert log_display.search_term == "" # Search should be cleared
        assert app.current_match_index is None # Match index should be reset