import pytest
from textual.app import App
from textual.widgets import Static, Input
from textual.message import Message
from rich.text import Text

# Assume your custom widgets are imported
# from your_app_module import LogContainer, SearchInput, SearchCleared, SearchHighlighter

# Re-include simplified versions for test context if needed
class SearchCleared(Message):
    pass

class SearchHighlighter:
    def __init__(self, search_term: str = "", current_match_line: int | None = None) -> None:
        self.search_term = search_term
        self.current_match_line = current_match_line
    def __call__(self, text: Text, line_number: int) -> Text:
        if self.search_term in text.plain:
            if line_number == self.current_match_line:
                text.stylize("b green on red")
            else:
                text.stylize("b black on yellow")
        return text

class LogContainer(Container):
    search_term: reactive[str] = reactive("")
    current_match_line: reactive[int | None] = reactive(None)
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._current_highlighter = SearchHighlighter("", None)
    def watch_search_term(self, new_term):
        self._current_highlighter = SearchHighlighter(new_term, self.current_match_line)
    def watch_current_match_line(self, new_line):
        self._current_highlighter = SearchHighlighter(self.search_term, new_line)
    def render_log_lines(self, msgs):
        self.remove_children()
        for i, msg in enumerate(msgs):
            self.mount(Static(self._current_highlighter(Text(msg), i)))

class SearchInput(Input):
    def on_key(self, event: Key) -> None:
        if event.key == "escape":
            self.app.post_message(SearchCleared())
            self.value = ""
            event.prevent_default()
            event.stop()
            return

@pytest.mark.asyncio
async def test_log_container_rendering_and_highlighting():
    class TestApp(App):
        def compose(self):
            yield LogContainer(id="test_log")

    async with TestApp().run_test() as app:
        log_container = app.query_one("#test_log", LogContainer)
        test_messages = ["apple banana", "orange apple", "grape"]

        # Test initial rendering
        log_container.render_log_lines(test_messages)
        assert len(log_container.children) == 3
        assert isinstance(log_container.children[0], Static)
        assert log_container.children[0].renderable.plain == "apple banana"

        # Test search term highlighting
        log_container.search_term = "apple"
        log_container.render_log_lines(test_messages) # Re-render after search term change

        # Check highlighting (this requires inspecting Rich.Text spans)
        # This is a bit advanced, but shows the concept
        static_0_renderable = log_container.children[0].renderable
        static_1_renderable = log_container.children[1].renderable
        static_2_renderable = log_container.children[2].renderable

        # Assert styling for 'apple' in first line (should have regular highlight)
        assert "on yellow" in static_0_renderable.spans[0].style.string # Simplified check for 'on yellow'

        # Assert styling for 'apple' in second line
        assert "on yellow" in static_1_renderable.spans[0].style.string

        # Test current match highlighting
        log_container.current_match_line = 1 # Highlight second line
        log_container.render_log_lines(test_messages) # Re-render

        static_0_renderable = log_container.children[0].renderable
        static_1_renderable = log_container.children[1].renderable

        # First line should still have regular highlight
        assert "on yellow" in static_0_renderable.spans[0].style.string
        # Second line should have active highlight
        assert "on red" in static_1_renderable.spans[0].style.string


@pytest.mark.asyncio
async def test_search_input_escape_key():
    # An app that has our SearchInput and can receive messages
    class TestApp(App):
        MESSAGES_RECEIVED = []
        def compose(self):
            yield SearchInput(id="test_input")
        @on(SearchCleared)
        def handle_clear(self, message: SearchCleared):
            self.MESSAGES_RECEIVED.append(message)

    async with TestApp().run_test() as app:
        test_input = app.query_one("#test_input", SearchInput)
        test_input.value = "some text"
        
        # Simulate pressing escape
        await test_input.app.press("escape") # Use app.press from the input's app context

        # Assert the input value is cleared
        assert test_input.value == ""
        # Assert a SearchCleared message was posted
        assert len(TestApp.MESSAGES_RECEIVED) == 1
        assert isinstance(TestApp.MESSAGES_RECEIVED[0], SearchCleared)

        # Assert focus is lost (optional, but good for UX)
        assert test_input.has_focus is False