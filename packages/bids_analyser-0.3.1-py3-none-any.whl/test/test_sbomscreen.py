import pytest
from pathlib import Path
from textual.widgets import RadioSet, RadioButton, Input, Button, Label
from textual.containers import Container
from bids.ui.sbom import SbomScreen, SPDX_FORMATS, CYCLONEDX_FORMATS
from bids.ui.display import DisplayScreen
from bids.gui import BidsUI
from unittest.mock import patch, MagicMock


@pytest.mark.asyncio
async def test_sbom_screen_renders_correctly(tmp_path):
    target_file = tmp_path / "dummy"
    target_file.write_text("dummy")

    async with BidsUI().run_test() as pilot:
        # Show the modal screen directly
        await pilot.app.push_screen(SbomScreen(target_path=target_file))
        screen = pilot.app.screen

        # Check title
        label = screen.query_one(Label)
        assert f"Generate SBOM for: {target_file}" in label.renderable

        # Check SBOM Type radios
        type_set = screen.query_one("#sbom_type", RadioSet)
        type_buttons = type_set.query(RadioButton)
        assert len(type_buttons) == 2
        assert type_buttons[0].label == "SPDX"
        assert type_buttons[0].value is True  # Default selected
        assert type_buttons[1].label == "CycloneDX"

        # Check Format radios
        format_set = screen.query_one("#sbom_format", RadioSet)
        format_buttons = format_set.query(RadioButton)
        assert len(format_buttons) >= 1
        assert any(btn.label == "JSON" and btn.value for btn in format_buttons)

        # Check input box
        input_box = screen.query_one("#sbom_filename", Input)
        assert input_box.placeholder == "e.g., my-sbom.json"

        # Check buttons
        generate_btn = screen.query_one("#generate", Button)
        cancel_btn = screen.query_one("#cancel", Button)
        assert generate_btn.label == "Generate SBOM"
        assert cancel_btn.label == "Cancel"

        # Simulate pressing cancel
        # Focus and press the cancel button (simulates user input properly)
        cancel_btn.focus()
        await pilot.press("enter")
        # Verify that screen has changed
        active_screen = pilot.app.screen_stack[-1].screen
        assert not isinstance(active_screen, SbomScreen)

@pytest.mark.asyncio
async def test_generate_sbom_with_filename_triggers_sbom_creation(app):
    target = Path("/fake/binary")

    # Patch both sbom.process_file and sbom.create_sbom
    with patch("bids.ui.sbom.bids.sbom.process_file", return_value=(["pkg1"], ["rel1"])) as mock_process, \
         patch("bids.ui.sbom.bids.sbom.create_sbom") as mock_create, \
         patch.object(BidsUI, "notify") as mock_notify:

        app = BidsUI()

        async with app.run_test() as pilot:
            screen = SbomScreen(target_path=target)
            await app.push_screen(screen)
            # Wait for screen to be ready
            await pilot.pause()

            # Enter a filename in the input by setting filename directly
            filename_input = screen.query_one("#sbom_filename", Input)
            filename_input.value = "output.spdx.json"
            # Click the generate button
            generate_btn = screen.query_one("#generate", Button)
            assert generate_btn.label == "Generate SBOM"

            # Focus and press the generate button (simulates user input properly)
            generate_btn.focus()
            await pilot.press("enter")

        # Check process_file was called with the path
        mock_process.assert_called_once_with(str(target))

        # Check create_sbom was called with expected args
        mock_create.assert_called_once()

        _, kwargs = mock_create.call_args
        assert kwargs["output_file"].endswith("output.spdx.json")

        # Check notify was called
        mock_notify.assert_called_once()
        assert "SBOM saved to" in mock_notify.call_args[0][0]

@pytest.mark.asyncio
async def test_cancel_button_pops_screen():
    app = BidsUI()
    async with app.run_test() as pilot:
        screen = SbomScreen(target_path=Path("/fake/binary"))
        await app.push_screen(screen)

        # Click cancel button
        #await pilot.click("#cancel")

        cancel_btn = screen.query_one("#cancel", Button)
        assert cancel_btn.label == "Cancel"

        # Simulate pressing cancel
        # Focus and press the cancel button (simulates user input properly)
        cancel_btn.focus()
        await pilot.press("enter")

        # Screen should be popped (i.e. current screen no longer SbomScreen)
        active_screen = app.screen_stack[-1]
        assert active_screen is not screen

@pytest.mark.asyncio
async def test_sbom_type_switch_updates_formats():
    app = BidsUI()
    async with app.run_test() as pilot:
        screen = SbomScreen(target_path=Path("/fake/binary"))
        await app.push_screen(screen)

        # Initially SPDX type should be selected by default
        sbom_type_rs = screen.query_one("#sbom_type")
        assert sbom_type_rs.pressed_button.label.plain == "SPDX"

        sbom_format_rs = screen.query_one("#sbom_format")
        # Check initial formats correspond to SPDX_FORMATS
        spdx_labels = [btn.label.plain for btn in sbom_format_rs.query("RadioButton")]
        # These should match SPDX_FORMATS labels
        expected_labels = [name for name, _ in SPDX_FORMATS]
        assert spdx_labels == expected_labels                      

        # Switch SBOM type to CycloneDX by pressing its RadioButton
        cyclone_radio = None
        for btn in sbom_type_rs.query("RadioButton"):
            if btn.label.plain == "CycloneDX":
                cyclone_radio = btn
                break
        assert cyclone_radio is not None
        # Simulate changing selection to CycloneDX
        await pilot.click("#sbom_cyclonedx")
        #await pilot.press(cyclone_radio)  # press triggers on_radio_set_changed event

        # After event processing, format radio buttons should update
        new_format_labels = [btn.label.plain for btn in sbom_format_rs.query("RadioButton")]
        # These should match CYCLONEDX_FORMATS labels
        expected_labels = [name for name, _ in CYCLONEDX_FORMATS]
        assert new_format_labels == expected_labels

@pytest.mark.asyncio
async def test_generate_sbom_no_filename_pushes_displayscreen():
    target = Path("/fake/binary")

    with patch("bids.ui.sbom.bids.sbom.process_file", return_value=(["pkg1"], ["rel1"])) as mock_process, \
         patch("bids.ui.sbom.bids.sbom.create_sbom") as mock_create, \
         patch("bids.ui.sbom.tempfile.NamedTemporaryFile") as mock_tmpfile, \
         patch.object(BidsUI, "notify") as mock_notify:

        # Setup tempfile mock
        mock_tempfile_instance = MagicMock()
        mock_tempfile_instance.name = "/tmp/bids_tempfile"
        mock_tmpfile.return_value = mock_tempfile_instance

        app = BidsUI()
        async with app.run_test() as pilot:
            screen = SbomScreen(target_path=target)
            await app.push_screen(screen)

            # Leave filename empty (default "")
            filename_input = screen.query_one("#sbom_filename")
            filename_input.value = ""

            # Click generate button
            #await pilot.click("#generate")
            generate_btn = screen.query_one("#generate", Button)
            assert generate_btn.label == "Generate SBOM"
            generate_btn.focus()
            await pilot.press("enter")            

        mock_process.assert_called_once()
        mock_create.assert_called_once()

        # Since no filename, should NOT call notify (no pop_screen + notify)
        mock_notify.assert_not_called()

        # Instead, app should have pushed DisplayScreen with SBOM content
        # Confirm last screen is DisplayScreen instance
        active_screen = app.screen_stack[-1]
        assert isinstance(active_screen, DisplayScreen)

        # Also tempfile.close should be called
        mock_tempfile_instance.close.assert_called_once()
