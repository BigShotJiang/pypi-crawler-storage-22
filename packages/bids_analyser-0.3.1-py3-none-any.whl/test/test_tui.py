import asyncio
import pytest
from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, Input, Static
from textual.containers import Container, VerticalScroll
from textual.pilot import Pilot # You MUST explicitly import Pilot for this to work
from textual.binding import Binding # Also needed if using BINDINGS
from textual.reactive import reactive
from textual.message import Message
from textual.events import Key
from textual.widget import Widget
from textual import on
from rich.text import Text # Needed for LogContainer
from textual.layouts.vertical import VerticalLayout
from textual.css.scalar import Unit


# --- Re-including simplified components for a full, self-contained example ---
class SearchCleared(Message):
    """Posted when the search is cleared."""
    pass

class SearchHighlighter:
    def __init__(self, search_term: str = "", current_match_line: int | None = None) -> None:
        self.search_term = search_term.lower()
        self.current_match_line = current_match_line

    def __call__(self, text: Text, line_number: int) -> Text:
        if not self.search_term:
            return text
        plain_text = text.plain.lower()
        start = 0
        while True:
            idx = plain_text.find(self.search_term, start)
            if idx == -1:
                break
            end = idx + len(self.search_term)
            if line_number == self.current_match_line:
                text.stylize("b green on red", idx, end)
            else:
                text.stylize("b black on yellow", idx, end)
            start = end
        return text

class LogContainer(Container):
    search_term: reactive[str] = reactive("", always_update=True)
    current_match_line: reactive[int | None] = reactive(None)

    def __init__(self, *children: Widget, name: str | None = None, id: str | None = None, classes: str | None = None, disabled: bool = False) -> None:
        super().__init__(*children, name=name, id=id, classes=classes, disabled=disabled)
        self._current_highlighter = SearchHighlighter("", None)

    def watch_search_term(self, new_search_term: str) -> None:
        self._current_highlighter = SearchHighlighter(new_search_term, self.current_match_line)

    def watch_current_match_line(self, new_line: int | None) -> None:
        self._current_highlighter = SearchHighlighter(self.search_term, new_line)

    def render_log_lines(self, all_messages: list[str]) -> None:
        self.remove_children()
        for i, msg in enumerate(all_messages):
            rich_text = Text(msg)
            highlighted_text = self._current_highlighter(rich_text, i)
            self.mount(Static(highlighted_text))

class SearchInput(Input):
    def on_key(self, event: Key) -> None:
        if event.key == "escape":
            self.app.post_message(SearchCleared())
            self.value = ""
            event.prevent_default()
            event.stop()
            return

class MyApp(App):
    BINDINGS = [
        Binding("slash", "toggle_search", "Search", show=True, key_display="/"),
        Binding("n", "next_match", "Next Match", show=False),
        Binding("p", "previous_match", "Previous Match", show=False),
    ]

    _all_log_messages: list[str] = ["line one error", "line two warning", "line three"]
    _match_indices: list[int] = []
    current_match_index: reactive[int | None] = reactive(None)
    show_search_input: reactive[bool] = reactive(False)

    CSS = """
    Container { layout: vertical; height: 1fr; }
    #log_display_container { height: 1fr; }
    #search_input { height: auto; display: none; }
    """

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="main_content"):
            with VerticalScroll(id="log_display_container"):
                yield LogContainer(id="log_display")
            yield SearchInput(id="search_input")
        yield Footer()

    def watch_show_search_input(self, show_input: bool) -> None:
        search_input = self.query_one("#search_input", Input)
        if show_input:
            search_input.styles.display = "block"
            search_input.focus()
        else:
            search_input.styles.display = "none"
            search_input.blur()

    def on_mount(self) -> None:
        self._redraw_log_content("")
        self.show_search_input = False

    @on(Input.Submitted, "#search_input")
    def apply_search_and_highlight(self, event: Input.Submitted) -> None:
        search_term = event.value.strip()
        log_container = self.query_one("#log_display", LogContainer)
        log_container.search_term = search_term
        self._match_indices = []
        if search_term:
            for i, msg in enumerate(self._all_log_messages):
                if search_term.lower() in msg.lower():
                    self._match_indices.append(i)
        self.current_match_index = 0 if self._match_indices else None
        self.show_search_input = False
        self._redraw_log_content(search_term) # Call it after current_match_index is set
        

    @on(SearchCleared)
    def handle_search_cleared(self) -> None:
        log_container = self.query_one("#log_display", LogContainer)
        log_container.search_term = ""
        self.current_match_index = None
        self._match_indices = []
        self.show_search_input = False
        self._redraw_log_content("")

    def action_toggle_search(self) -> None:
        self.show_search_input = not self.show_search_input

    def action_next_match(self) -> None:
        if self._match_indices:
            if self.current_match_index is None:
                self.current_match_index = 0
            else:
                self.current_match_index = (self.current_match_index + 1) % len(self._match_indices)

    def action_previous_match(self) -> None:
        if self._match_indices:
            if self.current_match_index is None:
                self.current_match_index = len(self._match_indices) - 1
            else:
                self.current_match_index = (self.current_match_index - 1 + len(self._match_indices)) % len(self._match_indices)

    def action_escape(self) -> None:
        search_input = self.query_one("#search_input", Input)
        if not search_input.styles.display == "none":
            self.post_message(SearchCleared())
        else:
            self.app.exit() # Changed to exit for simple testing, could be app.pop_screen()

    def _redraw_log_content(self, current_search_term: str) -> None:
        log_container = self.query_one("#log_display", LogContainer)
        log_container.current_match_line = (
            self._match_indices[self.current_match_index]
            if self.current_match_index is not None and self._match_indices
            else None
        )
        log_container.render_log_lines(self._all_log_messages)
        # Simplified scroll for testing
        if self.current_match_index is not None and self._match_indices:
            self.query_one("#log_display_container", VerticalScroll).scroll_y = self._match_indices[self.current_match_index] * 2 # Rough scroll
        else:
            self.query_one("#log_display_container", VerticalScroll).scroll_y = 0


# --- The test code, NOW EXPLICITLY using 'pilot.app.query_one' for older Pilot versions ---
@pytest.mark.asyncio
async def test_app_initial_composition():
    async with MyApp().run_test() as pilot: # Yields the pilot
        print(f"Type of 'pilot' in test: {type(pilot)}") # Still seeing textual.pilot.Pilot?

        # Access query_one via pilot.app
        header = pilot.app.query_one(Header)
        footer = pilot.app.query_one(Footer)
        
        assert header is not None
        assert footer is not None

        main_content = pilot.app.query_one("#main_content", Container)
        assert main_content is not None

        # --- ADD THESE DEBUG PRINTS ---
        print(f"Type of main_content.styles.layout: {type(main_content.styles.layout)}")
        print(f"Value of main_content.styles.layout: {main_content.styles.layout!r}") # Use !r for raw representation
        print(f"Type of main_content.styles.height: {type(main_content.styles.height)}")
        print(f"Value of main_content.styles.height: {main_content.styles.height!r}") # Use !r for raw representation        
        # --- END DEBUG PRINTS ---

        assert isinstance(main_content.styles.layout, VerticalLayout) 
        #assert main_content.styles.height == "1fr"
        assert main_content.styles.height.value == 1.0
        assert main_content.styles.height.unit == Unit.FRACTION

        log_scroll = pilot.app.query_one("#log_display_container", VerticalScroll)
        search_input = pilot.app.query_one("#search_input", Input)

        assert log_scroll is not None
        assert search_input is not None

        # Check their parentage (still works as widgets are tied to the actual app's DOM)
        assert log_scroll.parent == main_content
        assert search_input.parent == main_content

        # Assert initial visibility of the search input via the app's state
        assert pilot.app.show_search_input is False
        assert search_input.styles.display == "none"

@pytest.mark.asyncio
async def test_toggle_search_input():
    async with MyApp().run_test() as pilot:
        search_input = pilot.app.query_one("#search_input", Input)

        # Initially hidden
        assert search_input.styles.display == "none"
        assert search_input.has_focus is False

        # Toggle search (/)
        await pilot.press("/") # Use pilot.press for simulating key presses
        #await pilot.app.workers.wait_until_ready() # Wait for DOM updates
        await asyncio.sleep(0.1)

        print(f"search_input.styles.display:  {search_input.styles.display!r}")
        assert search_input.styles.display == "block"
        assert search_input.has_focus is True

        # Toggle search again (/)
        await pilot.press("/")
        #await pilot.app.workers.wait_until_ready()
        await asyncio.sleep(0.1)

        print(f"search_input.styles.display:  {search_input.styles.display!r}")
        assert search_input.styles.display == "none"
        assert search_input.has_focus is False

@pytest.mark.asyncio
async def test_search_and_highlight():
    async with MyApp().run_test() as pilot:
        search_input = pilot.app.query_one("#search_input", Input)
        log_display = pilot.app.query_one("#log_display", LogContainer)

        await pilot.press("/") # Open search
        #await pilot.wait_until_ready()
        await asyncio.sleep(0.1)

        search_input.value = "error"
        await pilot.press("enter") # Submit search
        #await pilot.app.workers.wait_until_ready()
        await asyncio.sleep(0.1)

        print (f"search_input.styles.display:  {search_input.styles.display!r}")
        assert search_input.styles.display == "none"
        assert log_display.search_term == "error"
        assert log_display.current_match_line == 0 

        first_log_line_static = log_display.query(Static).first()
        assert "error" in first_log_line_static.renderable.plain.lower()

        # Test 'n' for next match
        await pilot.press("n")
        #await pilot.app.workers.wait_until_ready()
        await asyncio.sleep(0.1)
        assert log_display.current_match_line == 1
        assert pilot.app.current_match_index == 1

        # Test 'p' for previous match
        await pilot.press("p")
        #await pilot.app.workers.wait_until_ready()
        await asyncio.sleep(0.1)
        assert log_display.current_match_line == 0
        assert pilot.app.current_match_index == 0

@pytest.mark.asyncio
async def test_search_functionality_and_navigation():
    async with MyApp().run_test() as pilot:
        search_input = pilot.app.query_one("#search_input", Input)
        log_container = pilot.app.query_one("#log_display", LogContainer)

        # 1. Open search and enter a term
        await pilot.press("/")
        await asyncio.sleep(0.1) # Wait for search input to appear and focus

        search_input.value = "error" # Set the input value
        await pilot.press("enter") # Simulate pressing Enter (triggers Input.Submitted)

        # *** Crucial Wait Here for the logic in apply_search_and_highlight to execute ***
        await asyncio.sleep(0.2) # A slightly longer sleep might be beneficial if complex updates happen

        # Now assert:
        assert log_container.search_term == "error"
        assert log_container.current_match_line == 0 # This should now pass!

        # 2. Navigate to next match
        await pilot.press("n")
        await asyncio.sleep(0.1) # Wait for action_next_match to update and redraw
        assert log_container.current_match_line == 1
        assert pilot.app.current_match_index == 1

        # 3. Navigate to previous match
        await pilot.press("p")
        await asyncio.sleep(0.1) # Wait for action_previous_match to update and redraw
        assert log_container.current_match_line == 0
        assert pilot.app.current_match_index == 0

        # 4. Clear search using escape key
        await pilot.press("escape")
        await asyncio.sleep(0.1) # Wait for handle_search_cleared to update and redraw
        assert log_container.search_term == ""
        assert log_container.current_match_line is None
        assert pilot.app.current_match_index is None


@pytest.mark.asyncio
async def test_escape_key_hides_search_input():
    async with MyApp().run_test() as pilot:
        search_input = pilot.app.query_one("#search_input", Input)
        log_display = pilot.app.query_one("#log_display", LogContainer)

        await pilot.press("/") # Open search
        #await pilot.app.workers.wait_until_ready()

        assert search_input.styles.display == "block"
        assert search_input.has_focus is True

        await pilot.press("escape") # Press escape
        #await pilot.app.workers.wait_until_ready()

        assert search_input.styles.display == "none"
        assert search_input.has_focus is False
        assert log_display.search_term == ""
        assert pilot.app.current_match_index is None