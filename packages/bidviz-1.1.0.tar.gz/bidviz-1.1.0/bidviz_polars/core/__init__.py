"""Core base classes for Polars transformers."""

from bidviz_polars.core.base import BaseChartTransformer

__all__ = ["BaseChartTransformer"]
