"""Core base classes for Polars transformers."""

from bidviz.polars.core.base import BaseChartTransformer

__all__ = ["BaseChartTransformer"]
