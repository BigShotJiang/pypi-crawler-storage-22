from byfrost.shared.errors.interface import BifrostError
