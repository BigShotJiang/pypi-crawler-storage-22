import os
import unittest
import byfrost

GOOGLE_BUCKET_NAME = os.environ.get("GOOGLE_BUCKET_NAME")

PATH = os.path.join(os.path.dirname(__file__), "../")

CREDENTIALS_FILE_PATH = os.path.join(PATH, "byfrost.json")


class TestGCS(unittest.TestCase):
    def setUp(self):
        self.bridge, error = byfrost.new_rainbow_bridge(
            byfrost.BridgeConfig(
                provider=byfrost.GoogleCloudStorage,
                credentials_file=CREDENTIALS_FILE_PATH,
                default_bucket=GOOGLE_BUCKET_NAME,
                default_timeout=20,
                public_read=True,
            )
        )
        self.assertIsNone(error)

    def test_is_connected(self):
        self.assertTrue(self.bridge.is_connected())

    def test_upload_file(self):
        upload, error = self.bridge.upload_file(
            file_face=byfrost.File(
                path=os.path.join(PATH, "cat.jpeg"),
                filename="cat",
            )
        )
        self.assertIsNone(error)
        self.assertIsNotNone(upload)
        self.assertIsNotNone(upload.name)
        self.assertIsNotNone(upload.url)
        self.assertIsNotNone(upload.size)

    def test_upload_file_with_no_filename(self):
        upload, error = self.bridge.upload_file(
            file_face=byfrost.File(
                path=os.path.join(PATH, "cat.jpeg"),
            )
        )
        self.assertIsNone(error)
        self.assertIsNotNone(upload)
        self.assertEqual(upload.name, "cat.jpeg")
        self.assertIsNotNone(upload.url)
        self.assertIsNotNone(upload.size)

    def test_upload_multi_file(self):
        upload, erroror = self.bridge.upload_multi_file(
            multi_face=byfrost.MultiFile(
                files=[
                    byfrost.File(
                        path="/Users/ifihan/Projects/byfrost/flower.jpeg",
                        filename="",
                    ),
                    byfrost.File(
                        path="/Users/ifihan/Projects/byfrost/dog.jpeg",
                        filename="",
                    ),
                ],
            )
        )
        self.assertIsNone(erroror)
        self.assertIsNotNone(upload)
        self.assertIsNotNone(upload[0].name)
        self.assertIsNotNone(upload[0].url)
        self.assertIsNotNone(upload[1].name)
        self.assertIsNotNone(upload[1].url)


if __name__ == "__main__":
    unittest.main()
