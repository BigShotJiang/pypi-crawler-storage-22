# Bifrost SDK

Rainbow Bridge for shipping your files to any cloud storage service with the same function calls.

<img src="https://user-images.githubusercontent.com/59074379/226159115-1cfcb221-127f-4574-87ed-b74b4b2c4591.png" width="1000" />

# Table of contents

- [Bifrost SDK](#bifrost-sdk)
- [Problem Statement](#problem-statement)
  - [Google Cloud Storage using GCS SDK](#google-cloud-storage-using-gcs-sdk)
  - [Pinata Cloud using Pinata API](#pinata-cloud-using-pinata-api)
  - [Using Bifrost SDK](#using-bifrost-sdk)
- [Installation](#installation)
- [Usage](#usage)
- [Contributing](#contributing)
- [License](#license)
- [Changelog](#changelog)
- [Contributors](#contributors)

# Problem Statement

Many projects need to store files in the cloud and different projects might use different cloud storage providers or, sometimes, multiple cloud providers all at once. Using different SDKs with different implementations for each provider can be tedious and time-consuming. Bifrost SDK aims to simplify the process of working with multiple cloud storage providers by providing a consistent API for all of them.

To gain a better understanding of how Bifrost SDK addresses this issue, let's take you on a ride with Thor by comparing two different code samples for working with Google Cloud Storage and Pinata Cloud in a single project: one using a conventional approach and the other using Bifrost SDK.

## Google Cloud Storage using GCS SDK

Without Bifrost SDK, the process of uploading a file to GCS using the Google Cloud Storage client library for Python would typically involve the following steps:

```py
# to be added
```

## Pinata Cloud using Pinata API

...and for Pinata Cloud, the usual way of uploading a file in Python would be something along the following steps:

```py
# to be added
```

We can already see the challenges of the conventional methods since they require you to learn to use multiple packages with separate implementation patterns. Now this is why `Bifrost SDK` comes in! With Bifrost SDK, you can mount rainbow bridges to the providers you want and use the same set of functions to upload files through any of these mounted bridges. This makes it much easier to work with multiple providers and streamlines the development process to just one learning curve.

Now, let's see how we can revamp the two samples above into something much more exciting with Bifrost SDK.

## Using Bifrost SDK

```py
# to be added
```

The above example clearly demonstrates the speed, simplicity, and ease of use that Bifrost SDK offers. Now you know what it feels like to ride with Thor!

# Installation

```bash
pip install bifrostsdk
```

# Usage

If you want to learn more about how Bifrost SDK is creating different methods to make it easier to use different cloud providers, you can follow these links:

- [Google Cloud Storage (GCS)](bifrostsdk/gcs/doc.md)
- [Amazon S3](bifrostsdk/s3/doc.md)
- [Pinata Cloud](bifrostsdk/pinata/doc.md)

# Variants

Bifrost also exists in other forms and languages and you are free to start a new variant of bifrost in any other form or language of your choice. For now, below are the know variants of bifrost.

- [x] [Bifrost in Golang](https://github.com/opensaucerer/bifrost)
- [x] [Bifrost CLI](https://github.com/showbaba/bifrost-cli)

# Contributing

Bifrost SDK is an open source project and we welcome contributions of all kinds. Please read our [contributing guide](./CONTRIBUTING.md) to learn about our development process, how to propose bug fixes and improvements, and how to build and test your changes to Bifrost SDK.

# License

Bifrost SDK is [MIT licensed](./LICENSE).

# Changelog

See [CHANGELOG.md](./CHANGELOG.md) for more details.

# Contributors

<a href="https://github.com/ifihan/byfrost/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=ifihan/byfrost" />
</a>

Made with [contrib.rocks](https://contrib.rocks).
