#!usr/bin/env python3

from .shared.types.dataclass.bridge import BridgeConfig, RainbowBridge
from .shared.types.dataclass.file import File, MultiFile, Options

from .shared.types.typeddict.bridge import BridgeConfigDict
from .shared.types.typeddict.file import (
    OptionsDict,
    FileDict,
    MultiFileDict,
    ParamFileDict,
    ParamDataDict,
    ParamDict,
    UploadedFileDict,
)

from .shared.errors.constant import (
    ErrBadRequest,
    ErrClientError,
    ErrIncompleteMultiFileUpload,
    ErrInvalidBucket,
    ErrInvalidConfig,
    ErrInvalidCredentials,
    ErrInvalidProvider,
    ErrUnauthorized,
    ErrFileOperationFailed,
)
from .shared.errors.interface import BifrostError
from .shared.config.provider import (
    GoogleCloudStorage,
    PinataCloud,
    SimpleStorageService,
)

from .shared.config.option import (
    OptACL,
    ACLPublicRead,
    ACLPrivate,
    OptContentType,
    OptMetadata,
    OptPinata,
)

from .bifrost import new_rainbow_bridge

__name__ = "byfrost"
__all__ = [
    "BridgeConfig",
    "RainbowBridge",
    "File",
    "Options",
    "MultiFile",
    "BridgeConfigDict",
    "OptionsDict",
    "FileDict",
    "MultiFileDict",
    "ParamFileDict",
    "ParamDataDict",
    "ParamDict",
    "UploadedFileDict",
    "ErrBadRequest",
    "ErrClientError",
    "ErrIncompleteMultiFileUpload",
    "ErrInvalidBucket",
    "ErrInvalidConfig",
    "ErrInvalidCredentials",
    "ErrInvalidProvider",
    "ErrUnauthorized",
    "ErrFileOperationFailed",
    "BifrostError",
    "GoogleCloudStorage",
    "PinataCloud",
    "SimpleStorageService",
    "new_rainbow_bridge",
    "OptACL",
    "ACLPublicRead",
    "ACLPrivate",
    "OptContentType",
    "OptMetadata",
    "OptPinata",
]
