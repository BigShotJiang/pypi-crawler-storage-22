#!/usr/bin/env python3

"""
Byfrost provides a rainbow bridge for shipping files to any cloud storage service.

It's like bifrost from marvel comics, but for files.
"""

from .shared.types.dataclass import bridge
from typing import Tuple
from .shared.errors.interface import BifrostError

def new_rainbow_bridge(
    bc: bridge.BridgeConfig,
) -> Tuple[bridge.RainbowBridge, BifrostError]:
    """
    new_rainbow_bridge returns a new Rainbow Bridge for shipping files to your specified cloud storage service and an error if one occurs.
    """
    ...

def new_google_cloud_storage(
    bc: bridge.BridgeConfig,
) -> Tuple[bridge.RainbowBridge, BifrostError]:
    """new_google_cloud_storage returns a new client for Google Cloud Storage."""
    ...

def new_pinata_cloud_storage(
    bc: bridge.BridgeConfig,
) -> Tuple[bridge.RainbowBridge, BifrostError]:
    """new_pinata_cloud_storage returns a new client for Pinata Cloud Storage."""

def new_simple_storage_service(
    bc: bridge.BridgeConfig,
) -> Tuple[bridge.RainbowBridge, BifrostError]:
    """new_simple_storage_service returns a new client for Simple Storage Service."""
    ...
