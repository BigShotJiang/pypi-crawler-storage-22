#!/usr/bin/env python3
"""
    The RainbowBridge interface for Pinata Cloud

    All providers must implement this interface completely
"""

"""Bifrost interface for Pinata Cloud."""

from byfrost.shared import errors
from byfrost.shared.config import provider
from ..shared.types.dataclass import file as bfile
from ..shared.types.dataclass import bridge
from typing import List, Tuple
from ..shared.errors.interface import BifrostError
from ..shared.config import option, request, url
from ..shared.errors import loga
from ..shared.request.builder import Client

class PinataCloud:
    """PinataCloud is the Google Cloud Storage class"""

    def __init__(self, bc: bridge.BridgeConfig, client: Client):
        """__init__ initializes the GoogleCloudStorage class."""
        ...
    def upload_file(
        self, file_face: bfile.File
    ) -> Tuple[bfile.UploadedFile, BifrostError]:
        """upload_file uploads a file to Pinata Storage and returns an error if one occurs."""
        ...
    def upload_multi_file(
        self,
        multi_face: bfile.MultiFile,
    ) -> Tuple[List[bfile.UploadedFile], BifrostError]:
        """upload multi file uploads multiple files to Pinata Storage and returns an error if one occurs."""
        ...
    def preflight(self) -> BifrostError:
        """preflight attempts to authenticate with Pinata and returns an error if one occurs."""
        ...
    def disconnect(self) -> BifrostError:
        """disconnect closes the Pinata Storage client connection and returns an error if one occurs."""
        ...
    def config(self) -> bridge.BridgeConfig:
        """config returns the provider configuration."""
        ...
    def is_connected(self) -> bool:
        """is_connected returns true if there is an active connection to the provider."""
        ...
    def upload_folder(
        self,
        fold_face: bfile.MultiFile,
    ) -> Tuple[List[bfile.UploadedFile], BifrostError]:
        """upload_folder uploads a folder to Pinata Storage and returns an error if one occurs."""
        ...
