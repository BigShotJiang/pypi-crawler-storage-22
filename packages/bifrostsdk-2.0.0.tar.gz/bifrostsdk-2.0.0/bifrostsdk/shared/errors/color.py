#!/usr/bin/env python3

"""Error color codes"""

WARN = "\033[0;33m"
"""Yellow color code"""

ERROR = "\033[0;31m"
"""Red color code"""

INFO = "\033[0;32m"
"""Green color code"""

DEBUG = "\033[0;34m"
"""Blue color code"""

RESET = "\033[0m"
"""Reset color code"""
