#!/usr/bin/env python3

from typing import Any


class BifrostError(Exception):
    """Bifrost Error Class is the class for all Bifrost errors."""

    def __init__(self, error: str = "", code: str = ""):
        super().__init__(error)
        self.error = error
        self.code = code

    def __str__(self) -> str:
        return f"{self.code} :: {self.error}"

    def nil(self) -> bool:
        return self.error == "" and self.code == ""

    def code(self) -> str:
        return self.code
