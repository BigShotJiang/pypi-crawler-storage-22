#!/usr/bin/env python3

from typing import Any

class BifrostError(Exception):
    """BifrostError is the class for all bifrost errors."""

    error: str
    """error is the error message."""
    code: str
    """code is the error code."""

    def __init__(self, error: str = "", code: str = ""): ...
    def __str__(self) -> str: ...
    """__str__ returns the error message."""

    def nil(self) -> bool: ...
    """nil returns true if the error is nil."""

    def code(self) -> str: ...
    """code returns the error code."""
