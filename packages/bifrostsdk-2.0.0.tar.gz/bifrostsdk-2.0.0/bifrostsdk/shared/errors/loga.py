#!/usr/bin/env python3

from datetime import datetime
from .color import WARN, DEBUG, INFO, ERROR, RESET


def _get_formatted_date_time() -> str:
    return datetime.now().isoformat(sep=" ", timespec="seconds")


def _get_logger(level: str) -> str:
    return _get_formatted_date_time() + " " + level + "{}" + RESET


def warn(message: str) -> None:
    print(_get_logger(WARN).format(message))


def error(message: str) -> None:
    print(_get_logger(ERROR).format(message))


def info(message: str) -> None:
    print(_get_logger(INFO).format(message))


def debug(message: str) -> None:
    print(_get_logger(DEBUG).format(message))
