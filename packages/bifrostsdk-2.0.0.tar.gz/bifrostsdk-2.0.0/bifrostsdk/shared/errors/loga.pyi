#!/usr/bin/env python3

def _get_logger(level: str) -> str:
    """_get_logger returns a logger with the given level"""
    ...

def warn(message: str) -> None:
    """warn logs a warning message with color yellow"""
    ...

def error(message: str) -> None:
    """error logs an error message with color red"""
    ...

def info(message: str) -> None:
    """info logs an info message with color green"""
    ...

def debug(message: str) -> None:
    """debug logs a debug message with color blue"""
    ...
