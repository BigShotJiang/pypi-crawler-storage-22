from bifrostsdk.shared.errors.interface import BifrostError
