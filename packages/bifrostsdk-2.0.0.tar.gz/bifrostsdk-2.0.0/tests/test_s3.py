import os
import unittest
import bifrostsdk

AWS_S3_BUCKET_NAME = os.environ.get("AWS_S3_BUCKET_NAME")

PATH = os.path.join(os.path.dirname(__file__), "../")

CREDENTIALS_FILE_PATH = os.path.join(PATH, "bifrostsdk.json")


class TestS3(unittest.TestCase):
    def setUp(self):
        self.bridge, error = bifrostsdk.new_rainbow_bridge(
            bifrostsdk.BridgeConfig(
                provider=bifrostsdk.SimpleStorageService,
                access_key=os.environ.get("ACCESS_KEY"),
                secret_key=os.environ.get("SECRET_KEY"),
                default_bucket=AWS_S3_BUCKET_NAME,
                region="us-east-1",
                default_timeout=20,
                public_read=True,
            )
        )
        self.assertIsNone(error)

    def test_is_connected(self):
        self.assertTrue(self.bridge.is_connected())

    def test_upload_file(self):
        upload, error = self.bridge.upload_file(
            file_face=bifrostsdk.File(
                path=os.path.join(PATH, "cat.jpeg"),
                filename="cat",
            )
        )
        self.assertIsNone(error)
        self.assertIsNotNone(upload)
        self.assertIsNotNone(upload.name)
        self.assertIsNotNone(upload.url)
        self.assertIsNotNone(upload.size)

    def test_upload_file_with_no_filename(self):
        upload, error = self.bridge.upload_file(
            file_face=bifrostsdk.File(
                path=os.path.join(PATH, "cat.jpeg"),
            )
        )
        self.assertIsNone(error)
        self.assertIsNotNone(upload)
        self.assertEqual(upload.name, "cat.jpeg")
        self.assertIsNotNone(upload.url)
        self.assertIsNotNone(upload.size)

    def test_upload_multi_file(self):
        upload, erroror = self.bridge.upload_multi_file(
            multi_face=bifrostsdk.MultiFile(
                files=[
                    bifrostsdk.File(
                        path="/Users/ifihan/Projects/byfrost/flower.jpeg",
                        filename="",
                    ),
                    bifrostsdk.File(
                        path="/Users/ifihan/Projects/byfrost/dog.jpeg",
                        filename="",
                    ),
                ],
            )
        )
        self.assertIsNone(erroror)
        self.assertIsNotNone(upload)
        self.assertIsNotNone(upload[0].name)
        self.assertIsNotNone(upload[0].url)
        self.assertIsNotNone(upload[1].name)
        self.assertIsNotNone(upload[1].url)


if __name__ == "__main__":
    unittest.main()
