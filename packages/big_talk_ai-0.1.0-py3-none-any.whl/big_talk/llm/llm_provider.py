from abc import ABC, abstractmethod
from typing import Sequence, AsyncGenerator

from ..message import Message, AssistantMessage


class LLMProvider(ABC):
    @abstractmethod
    async def count_tokens(self, model: str, messages: Sequence[Message], **kwargs) -> int:
        pass

    @abstractmethod
    def stream(self, model: str, messages: Sequence[Message], **kwargs) -> AsyncGenerator[AssistantMessage, None]:
        pass

    async def close(self):
        pass
