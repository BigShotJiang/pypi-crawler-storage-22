import inspect
import logging
from dataclasses import dataclass
from typing import Any, Callable, get_type_hints, get_origin, Literal, get_args, TypedDict, Sequence, Union, TypeAlias, \
    Optional, is_typeddict, Annotated, overload, Iterable

import docstring_parser

logger = logging.getLogger(__name__)


class Property(TypedDict):
    type: Literal['string', 'integer', 'boolean', 'number', 'array', 'object']
    description: Optional[str]


class EnumProperty(Property):
    type: Literal['string']
    enum: Sequence[str]


class ArrayProperty(Property):
    type: Literal['array']
    items: dict[str, Any]


class ObjectProperty(Property):
    type: Literal['object']
    properties: dict[str, Any]
    required: Sequence[str]


class DictionaryProperty(Property):
    type: Literal['object']
    additionalProperties: bool


ToolParametersProperty: TypeAlias = Union[
    Property, EnumProperty, ArrayProperty, ObjectProperty, DictionaryProperty, dict[str, Any]]


class ToolParameters(TypedDict):
    type: Literal['object']
    properties: dict[str, ToolParametersProperty]
    required: Sequence[str]


@dataclass
class Tool:
    name: str
    description: str
    parameters: ToolParameters
    func: Callable
    metadata: dict[str, Any]

    @classmethod
    def from_func(cls,
                  func: Callable,
                  *docstring_args,
                  metadata: dict[str, Any] = None,
                  hidden_default_types: Sequence[type] = None,
                  hidden_default_values: Sequence[Any] = None,
                  **docstring_kwargs) -> 'Tool':
        if not metadata:
            metadata = {}

        if hidden_default_types:
            hidden_default_types = tuple(hidden_default_types)

        doc = docstring_parser.parse(inspect.getdoc(func) or '')

        description = doc.short_description or ''
        if doc.long_description:
            description += f'\n\n{doc.long_description}'

        if docstring_args or docstring_kwargs:
            try:
                description = description.format(*docstring_args, **docstring_kwargs)
            except (ValueError, KeyError, IndexError):
                logger.warning(
                    f'Failed to format docstring for tool {func.__name__} with args {docstring_args} and '
                    f'kwargs {docstring_kwargs}. Using unformatted description.',
                    exc_info=True)

        param_docs = {p.arg_name: p.description for p in doc.params}

        sig = inspect.signature(func)
        type_hints = get_type_hints(func, include_extras=True)

        required: list[str] = []
        properties: dict[str, ToolParametersProperty] = {}

        for param_name, param in sig.parameters.items():
            if param_name in ('self', 'cls'):
                continue

            is_required = param.default == inspect.Parameter.empty
            if not is_required:
                if hidden_default_values and param.default in hidden_default_values:
                    continue
                if hidden_default_types and isinstance(param.default, hidden_default_types):
                    continue

            python_type = type_hints.get(param_name, Any)
            json_schema = cls._schema_from_type(python_type)

            if param_name in param_docs and param_docs[param_name]:
                param_description = param_docs[param_name]
                if json_schema.get('description'):
                    json_schema['description'] += f'\n\n{param_description}'
                else:
                    json_schema['description'] = param_description

            properties[param_name] = json_schema

            if is_required:
                required.append(param_name)

        parameters = ToolParameters(
            type='object',
            properties=properties,
            required=required
        )

        return cls(name=func.__name__, description=description, parameters=parameters, func=func, metadata=metadata)

    @staticmethod
    def _schema_from_type(t: type) -> ToolParametersProperty:
        origin = get_origin(t)

        # Handle Annotated
        description = None
        if origin is Annotated:
            args = get_args(t)
            t = args[0]
            for arg in args[1:]:
                if isinstance(arg, str):
                    description = arg
                    break

        # Handle Optional (e.g. Optional[str] or Union[str, None])
        if origin is Union:
            args = get_args(t)
            non_none_args = [a for a in args if a is not type(None)]
            if len(non_none_args) == 1:
                return Tool._schema_from_type(non_none_args[0])
            else:
                return Tool._schema_from_type(non_none_args[0])

        # Pydantic support
        if hasattr(t, 'model_json_schema') and callable(t.model_json_schema):
            # noinspection PyTypeChecker
            schema: dict[str, Any] = t.model_json_schema()
            schema.pop('title', None)
            if description:
                schema['description'] = description
            return schema

        # Handle basic types
        if t == str:
            return Property(type='string', description=description)
        elif t == int:
            return Property(type='integer', description=description)
        elif t == float:
            return Property(type='number', description=description)
        elif t == bool:
            return Property(type='boolean', description=description)

        # Handle Literals
        if get_origin(t) is Literal:
            return EnumProperty(type='string', enum=list(get_args(t)), description=description)

        # Handle Lists (e.g. list[str])
        if t == list or get_origin(t) == list:
            args = get_args(t)
            item_schema = Tool._schema_from_type(args[0]) if args else {}
            return ArrayProperty(type='array', items=item_schema, description=description)

        # Handle TypedDict
        if is_typeddict(t):
            properties = {}
            required = []

            # get_type_hints handles inheritance and forward refs better than __annotations__
            hints = get_type_hints(t, include_extras=True)

            for key, value in hints.items():
                properties[key] = Tool._schema_from_type(value)

                # TypedDicts usually mark all keys required unless using total=False
                # We assume required for tool use safety, unless Optional is detected
                if get_origin(value) is not Union or type(None) not in get_args(value):
                    required.append(key)

            return ObjectProperty(
                type='object',
                properties=properties,
                required=required,
                description=description
            )

        # Fallback for dicts or complex types (treat as generic object)
        if t == dict or get_origin(t) == dict:
            return DictionaryProperty(type='object', additionalProperties=True, description=description)

        raise NotImplementedError(f'Type {t} is not supported in Tool parameter type mapping.')


@overload
def tool(func: Callable) -> Tool: ...


@overload
def tool(*docstring_args,
         metadata: dict[str, Any] = None,
         hidden_default_types: Sequence[type] = None,
         hidden_default_values: Sequence[Any] = None,
         **docstring_kwargs) -> Callable[[Callable], Tool]: ...


def tool(func: Callable | Any = None,
         *args,
         metadata: dict[str, Any] = None,
         hidden_default_types: Sequence[type] = None,
         hidden_default_values: Sequence[Any] = None,
         **kwargs) -> Tool | Callable[[Callable], Tool]:
    """
    Decorator to convert a function into a BigTalk Tool.

    Supports both:
      @tool
      def my_func(): ...

      @tool(metadata={'scope': 'read'})
      def my_func(): ...
    """
    is_factory = func is None or not callable(func)

    if is_factory:
        format_args = list(args)
        if func is not None:
            format_args.insert(0, func)

        def wrapper(f: Callable) -> Tool:
            return Tool.from_func(f, metadata=metadata, hidden_default_values=hidden_default_values,
                                  hidden_default_types=hidden_default_types, *format_args, **kwargs)

        return wrapper

    return Tool.from_func(func, metadata=metadata, hidden_default_values=hidden_default_values,
                          hidden_default_types=hidden_default_types, *args, **kwargs)
