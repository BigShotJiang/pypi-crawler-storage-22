# This file is placed in the Public Domain.


"kern van de zaak"
