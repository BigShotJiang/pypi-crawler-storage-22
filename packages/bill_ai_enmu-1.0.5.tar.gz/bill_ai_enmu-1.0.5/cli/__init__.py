from pathlib import Path
import sys
p = Path(Path.home() / ".config/bflowai")
f = p / "config.json"

if f.exists():
    pass
else:
    p.mkdir()
    p.touch("config.json")
    config_temp = """
    {
        "model": "gemini/gemini-3-flash-preview",
        "api_key": "",
        "rpm": 10
    }
    """
    f.write_text(config_temp)


    print("配置文件已经生成，请重新执行指令")
    sys.exit(1)