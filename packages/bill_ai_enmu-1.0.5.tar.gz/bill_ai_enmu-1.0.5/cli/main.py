

import cli.review
from cli.root import app


def main():
    app()


if __name__ == "__main__":
    main()