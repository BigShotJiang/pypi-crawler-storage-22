import typer
from typing import List
from cli.root import app
from typing_extensions import Annotated
from llm.ai import llm
import asyncio
from datetime import date, timedelta
from pathlib import Path
import json


@app.command()
def review(
    files: Annotated[List[typer.FileText], typer.Argument()] = ["-"],
    analyze_path: Annotated[
        str, typer.Option("-p", "--path", help="路径")
    ] = f"{Path.home()}/.flow/analyze/{date.today().year}/{(date.today().replace(day=1) - timedelta(days=1)).month:02d}.md",
):
    
    config_path = Path(Path.home() / ".config/bflowai") / "config.json"
    with open(str(config_path), "r", encoding="utf-8") as f:
        config_data  = f.read()

    allcontent = ""
    for f in files:
        allcontent += f.read()
    config = json.loads(config_data)
    if not config["api_key"]:
        raise ValueError("请填写正确的api_key")
    ai = llm([config])
    analyze_content = asyncio.run(ai.explain(allcontent))

    if not analyze_content:
        raise ValueError("分析出现错误，请检查模型与网络")

    if not Path(analyze_path).exists():
        Path(analyze_path).parent.mkdir(parents=True, exist_ok=True)
        Path(analyze_path).touch(exist_ok=True)

    with open(analyze_path, "w", encoding="utf-8") as f:
        f.write(analyze_content)
