import typer


app = typer.Typer(help="ai分析")
