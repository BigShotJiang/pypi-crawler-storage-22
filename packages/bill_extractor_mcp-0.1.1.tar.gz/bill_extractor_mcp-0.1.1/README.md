# Bill Extractor MCP Server

一个用于提取用户账单流水的MCP服务器，支持从Excel文件加载模拟数据。

## 功能

1. **单日期查询** - 根据明确日期或可推算的单日期表述查询交易记录
2. **时间区间查询** - 查询指定时间区间内的所有交易记录（支持绝对/相对时间区间）
3. **时间区间+特定分类查询** - 查询指定时间区间内特定分类的交易记录

## 安装

使用uvx安装和运行：

```bash
uvx bill-extractor-mcp
```

或者安装到环境中：

```bash
pip install bill-extractor-mcp
```

## 使用方法

### 作为MCP服务器运行

```bash
bill-mcp
```

### 查询示例

1. **单日期查询**:
   - "查询2026年1月1日的交易记录"
   - "查看昨天的账单"

2. **时间区间查询**:
   - "查询2026年1月1日到1月15日的交易记录"
   - "查看最近一周的所有交易"

3. **时间区间+特定分类查询**:
   - "查询2026年1月1日到1月15日的餐饮类交易"
   - "查看上个月的交通费用"

## 数据格式

项目使用Excel文件作为数据源，需要包含以下列：
- `date`: 交易日期 (YYYY-MM-DD格式)
- `description`: 交易描述
- `category`: 交易分类 (如: 餐饮, 交通, 购物等)
- `amount`: 交易金额
- `type`: 交易类型 (收入/支出)

## 开发

安装开发依赖：

```bash
pip install -e .
```

运行服务器：

```bash
python -m bill_extractor_mcp.server
```

## 发布到PyPI

要将此包发布到PyPI，请按照以下步骤操作：

1. 在PyPI上注册账户并创建API令牌：
   - 访问 https://pypi.org/account/register/ 注册账户
   - 登录后访问 https://pypi.org/manage/account/token/ 创建API令牌

2. 配置认证信息：
   - 创建 `~/.pypirc` 文件，内容如下：
     ```
     [distutils]
     index-servers = pypi

     [pypi]
     username = __token__
     password = YOUR_API_TOKEN
     ```
   - 将 `YOUR_API_TOKEN` 替换为您在PyPI上创建的实际API令牌

3. 构建包：
   ```bash
   python -m build
   ```

4. 上传包到PyPI：
   ```bash
   twine upload dist/*
   ```

注意：
- 请确保在上传之前更新 `pyproject.toml` 中的版本号
- 如果您遇到上传错误，请检查您的网络连接和认证信息
- 上传成功后，您的包将可以在PyPI上公开访问，其他用户可以使用 `pip install bill-extractor-mcp` 安装它

## 故障排除

如果在上传过程中遇到问题，请尝试以下解决方案：

1. 检查您的API令牌是否正确复制且没有过期
2. 确保您的网络连接正常
3. 使用 `--verbose` 选项获取更多错误信息：
   ```bash
   twine upload --verbose dist/*
   ```
4. 如果您配置了自定义的PyPI镜像，请确保使用正确的上传URL
