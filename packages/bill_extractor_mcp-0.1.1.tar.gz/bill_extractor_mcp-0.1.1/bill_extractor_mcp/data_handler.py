import pandas as pd
import logging
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)

def load_transaction_data(file_path: str) -> pd.DataFrame:
    """
    从Excel文件加载交易数据
    
    Excel文件应包含以下列:
    - date: 交易日期 (YYYY-MM-DD格式)
    - description: 交易描述
    - category: 交易分类
    - amount: 交易金额
    - type: 交易类型 (收入/支出)
    """
    try:
        # 读取Excel文件
        df = pd.read_excel(file_path)
        
        # 确保日期列是datetime类型
        df['date'] = pd.to_datetime(df['date'])
        
        # 按日期排序
        df = df.sort_values('date')
        
        logger.info(f"成功加载 {len(df)} 条交易记录")
        return df
    except FileNotFoundError:
        logger.warning(f"未找到数据文件 {file_path}，将创建示例数据")
        return create_sample_data()
    except Exception as e:
        logger.error(f"加载数据时出错: {e}")
        return create_sample_data()

def create_sample_data() -> pd.DataFrame:
    """创建示例交易数据"""
    sample_data = {
        'date': pd.date_range('2026-01-01', periods=30, freq='D'),
        'description': [
            '超市购物', '餐厅用餐', '公交卡充值', '工资收入', '网购', 
            '电影票', '水电费', '加油', '咖啡', '书籍购买',
            '健身房会员', '手机充值', '外卖', '理发', '礼品购买',
            '医院缴费', '保险缴费', '旅游支出', '房租', '投资收益',
            '奖金收入', '退款', '维修费', '停车费', '洗衣',
            '网络费', '订阅费', '捐赠', '宠物用品', '交通罚款'
        ],
        'category': [
            '购物', '餐饮', '交通', '收入', '购物',
            '娱乐', '生活', '交通', '餐饮', '教育',
            '健康', '通讯', '餐饮', '个人', '购物',
            '医疗', '保险', '旅游', '住房', '投资',
            '收入', '其他', '维修', '交通', '生活',
            '通讯', '娱乐', '慈善', '宠物', '交通'
        ],
        'amount': [
            -156.8, -89.5, -50.0, 8000.0, -234.6,
            -45.0, -120.0, -300.0, -28.5, -67.8,
            -180.0, -50.0, -35.2, -60.0, -98.5,
            -150.0, -500.0, -1200.0, -2500.0, 500.0,
            2000.0, 45.6, -80.0, -15.0, -25.0,
            -80.0, -15.99, -50.0, -67.3, -100.0
        ],
        'type': [
            '支出', '支出', '支出', '收入', '支出',
            '支出', '支出', '支出', '支出', '支出',
            '支出', '支出', '支出', '支出', '支出',
            '支出', '支出', '支出', '支出', '收入',
            '收入', '收入', '支出', '支出', '支出',
            '支出', '支出', '支出', '支出', '支出'
        ]
    }
    
    df = pd.DataFrame(sample_data)
    # 保存示例数据到Excel文件
    df.to_excel('sample_data.xlsx', index=False)
    logger.info("已创建示例数据文件 sample_data.xlsx")
    return df
