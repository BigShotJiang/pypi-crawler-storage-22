import json
import logging
import asyncio
import sys
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from mcp.server.session import ServerSession
from mcp.server.stdio import stdio_server
from mcp.server.models import InitializationOptions
from mcp.types import Tool, InitializeResult, ServerCapabilities, ToolsCapability
from mcp import Notification, JSONRPCResponse
from dateutil.parser import parse
import pandas as pd

from .data_handler import load_transaction_data
from .utils import parse_date, parse_date_range

logger = logging.getLogger(__name__)

class BillExtractorServer:
    def __init__(self, data_file: str = "sample_data.xlsx"):
        self.data_file = data_file
        self.transactions_df = load_transaction_data(data_file)
        
    async def query_transactions_by_date(self, date_str: str) -> List[Dict[str, Any]]:
        """根据日期查询交易记录"""
        try:
            target_date = parse_date(date_str)
            filtered_df = self.transactions_df[
                self.transactions_df['date'].dt.date == target_date.date()
            ]
            return filtered_df.to_dict('records')
        except Exception as e:
            logger.error(f"Error querying transactions by date: {e}")
            return []
    
    async def query_transactions_by_range(self, start_date_str: str, end_date_str: str) -> List[Dict[str, Any]]:
        """根据时间区间查询交易记录"""
        try:
            start_date = parse_date(start_date_str)
            end_date = parse_date(end_date_str)
            
            # 确保开始日期不大于结束日期
            if start_date > end_date:
                start_date, end_date = end_date, start_date
            
            filtered_df = self.transactions_df[
                (self.transactions_df['date'] >= start_date) & 
                (self.transactions_df['date'] <= end_date)
            ]
            return filtered_df.to_dict('records')
        except Exception as e:
            logger.error(f"Error querying transactions by range: {e}")
            return []
    
    async def query_transactions_by_category_in_range(
        self, start_date_str: str, end_date_str: str, category: str
    ) -> List[Dict[str, Any]]:
        """根据时间区间和分类查询交易记录"""
        try:
            start_date = parse_date(start_date_str)
            end_date = parse_date(end_date_str)
            
            # 确保开始日期不大于结束日期
            if start_date > end_date:
                start_date, end_date = end_date, start_date
            
            filtered_df = self.transactions_df[
                (self.transactions_df['date'] >= start_date) & 
                (self.transactions_df['date'] <= end_date) &
                (self.transactions_df['category'].str.contains(category, case=False, na=False))
            ]
            return filtered_df.to_dict('records')
        except Exception as e:
            logger.error(f"Error querying transactions by category in range: {e}")
            return []

async def get_tool_result(server: BillExtractorServer, name: str, arguments: Dict[str, Any]) -> List[Dict[str, Any]]:
    """处理工具调用"""
    if name == "query_transactions_by_date":
        date_str = arguments.get("date", "")
        return await server.query_transactions_by_date(date_str)
    elif name == "query_transactions_by_range":
        start_date = arguments.get("start_date", "")
        end_date = arguments.get("end_date", "")
        return await server.query_transactions_by_range(start_date, end_date)
    elif name == "query_transactions_by_category_in_range":
        start_date = arguments.get("start_date", "")
        end_date = arguments.get("end_date", "")
        category = arguments.get("category", "")
        return await server.query_transactions_by_category_in_range(start_date, end_date, category)
    else:
        raise ValueError(f"Unknown tool: {name}")

async def run_server(data_file: str = "sample_data.xlsx"):
    """运行MCP服务器"""
    server = BillExtractorServer(data_file)
    
    # 创建工具列表
    tools = [
        Tool(
            name="query_transactions_by_date",
            description="根据日期查询交易记录（支持明确日期或可推算的单日期表述）",
            inputSchema={
                "type": "object",
                "properties": {
                    "date": {"type": "string", "description": "日期字符串，可以是明确日期或相对日期（如'昨天'、'上周一'等）"}
                },
                "required": ["date"]
            }
        ),
        Tool(
            name="query_transactions_by_range",
            description="根据时间区间查询交易记录（支持绝对/相对时间区间）",
            inputSchema={
                "type": "object",
                "properties": {
                    "start_date": {"type": "string", "description": "开始日期字符串"},
                    "end_date": {"type": "string", "description": "结束日期字符串"}
                },
                "required": ["start_date", "end_date"]
            }
        ),
        Tool(
            name="query_transactions_by_category_in_range",
            description="根据时间区间和分类查询交易记录（支持绝对/相对时间区间+分类要求）",
            inputSchema={
                "type": "object",
                "properties": {
                    "start_date": {"type": "string", "description": "开始日期字符串"},
                    "end_date": {"type": "string", "description": "结束日期字符串"},
                    "category": {"type": "string", "description": "交易分类"}
                },
                "required": ["start_date", "end_date", "category"]
            }
        )
    ]
    
    # 创建初始化选项
    capabilities = ServerCapabilities(
        tools=ToolsCapability(listChanged=True)
    )
    
    init_options = InitializationOptions(
        server_name="bill-extractor-mcp",
        server_version="0.1.0",
        capabilities=capabilities
    )
    
    async with stdio_server() as (read_stream, write_stream):
        async with ServerSession(read_stream, write_stream, init_options) as session:
            # 处理请求
            async for request in session.incoming_requests:
                if request.method == "initialize":
                    # 发送初始化响应
                    result = InitializeResult(capabilities=capabilities)
                    await session.send_response(JSONRPCResponse(id=request.id, result=result.dict()))
                elif request.method == "tools/call":
                    # 处理工具调用
                    try:
                        tool_name = request.params["name"]
                        tool_args = request.params["arguments"]
                        result = await get_tool_result(server, tool_name, tool_args)
                        await session.send_response(JSONRPCResponse(id=request.id, result=result))
                    except Exception as e:
                        await session.send_error_response(request.id, str(e))
                else:
                    # 发送错误响应
                    await session.send_error_response(request.id, f"Unknown method: {request.method}")

def main():
    # 设置日志
    logging.basicConfig(level=logging.INFO)
    
    # 获取数据文件路径参数
    data_file = "sample_data.xlsx"
    if len(sys.argv) > 1:
        data_file = sys.argv[1]
    
    # 运行服务器
    asyncio.run(run_server(data_file))

if __name__ == "__main__":
    main()
