import re
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil.parser import parse
import logging

logger = logging.getLogger(__name__)

def parse_date(date_str: str) -> datetime:
    """
    解析日期字符串，支持相对日期和绝对日期
    
    Args:
        date_str: 日期字符串，可以是：
            - 绝对日期：'2026-01-01', '2026/1/1', '2026年1月1日'
            - 相对日期：'昨天', '前天', '上周一', '上个月1号'
    
    Returns:
        datetime: 解析后的日期对象
    """
    # 去除首尾空格
    date_str = date_str.strip()
    
    # 处理相对日期
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    
    # 昨天
    if date_str in ['昨天', '昨日']:
        return today - timedelta(days=1)
    
    # 前天
    if date_str in ['前天', '前日']:
        return today - timedelta(days=2)
    
    # 今天
    if date_str in ['今天', '今日']:
        return today
    
    # 明天
    if date_str in ['明天', '明日']:
        return today + timedelta(days=1)
    
    # 处理"上周X"格式
    week_match = re.match(r'上周([一二三四五六日天])', date_str)
    if week_match:
        weekday_map = {
            '一': 0, '二': 1, '三': 2, '四': 3, 
            '五': 4, '六': 5, '日': 6, '天': 6
        }
        weekday = weekday_map[week_match.group(1)]
        # 计算上周指定星期几的日期
        days_since_last_weekday = (today.weekday() - weekday) % 7
        if days_since_last_weekday == 0:
            days_since_last_weekday = 7
        return today - timedelta(days=days_since_last_weekday + (6 - weekday))
    
    # 处理"上个月X号"格式
    month_day_match = re.match(r'上个月(\d+)号?', date_str)
    if month_day_match:
        day = int(month_day_match.group(1))
        # 获取上个月的年份和月份
        last_month = today.replace(day=1) - timedelta(days=1)
        # 尝试设置指定的日期
        try:
            return last_month.replace(day=day)
        except ValueError:
            # 如果指定的日期不存在（如上个月没有31号），则使用最后一天
            return last_month
    
    # 处理绝对日期
    try:
        # 使用dateutil.parser处理各种日期格式
        parsed_date = parse(date_str, fuzzy=True)
        # 如果没有指定时间，设置为当天的开始
        if parsed_date.hour == 0 and parsed_date.minute == 0 and parsed_date.second == 0:
            return parsed_date.replace(hour=0, minute=0, second=0, microsecond=0)
        return parsed_date
    except Exception as e:
        logger.error(f"无法解析日期字符串: {date_str}, 错误: {e}")
        # 如果解析失败，返回今天
        return today

def parse_date_range(start_str: str, end_str: str) -> tuple[datetime, datetime]:
    """
    解析日期范围字符串
    
    Args:
        start_str: 开始日期字符串
        end_str: 结束日期字符串
    
    Returns:
        tuple[datetime, datetime]: (开始日期, 结束日期)
    """
    start_date = parse_date(start_str)
    end_date = parse_date(end_str)
    
    # 确保开始日期不大于结束日期
    if start_date > end_date:
        start_date, end_date = end_date, start_date
    
    return start_date, end_date

def format_transaction(transaction: dict) -> str:
    """
    格式化交易记录为字符串
    
    Args:
        transaction: 交易记录字典
        
    Returns:
        str: 格式化后的交易记录字符串
    """
    return f"{transaction['date'].strftime('%Y-%m-%d')} | {transaction['description']} | {transaction['category']} | {transaction['amount']} | {transaction['type']}"

def format_transactions(transactions: list) -> str:
    """
    格式化交易记录列表为字符串
    
    Args:
        transactions: 交易记录列表
        
    Returns:
        str: 格式化后的交易记录字符串
    """
    if not transactions:
        return "未找到符合条件的交易记录"
    
    # 表头
    result = "日期 | 描述 | 分类 | 金额 | 类型\n"
    result += "---|---|---|---|---\n"
    
    # 交易记录
    for transaction in transactions:
        result += format_transaction(transaction) + "\n"
    
    return result
