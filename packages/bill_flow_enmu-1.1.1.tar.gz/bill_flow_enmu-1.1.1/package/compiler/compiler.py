import logging

from package.config import Config
from ir import IR, Order
from package.parser.ali import alipay
from package.strategy.template.strategy import TemplateStrategy
import re
import json
import sys

# from datetime import date
# from pathlib import Path


class Compiler:
    def __init__(
        self,
        privider: str,
        config: Config,
        ir: IR,
        template_strategy: TemplateStrategy,
    ):
        self.privider = privider
        self.config = config
        self.ir = ir
        self.template_strategy = template_strategy

    def compile(self):
        logging.debug("start compile")
        orders: list[Order] = []
        for o in self.ir.orders:
            ignore, res_minus, res_plus, extra_account, tags = (
                alipay.get_account_and_tags(o, self.config, self.privider)
            )
            o.minus_account = res_minus
            o.plus_account = res_plus
            o.extra_account = extra_account
            o.tags = tags
            orders.append(o)

        for io in orders:
            self.template_strategy.template_parser(io)

        expends_data = self.distribution(self.template_strategy.expense_list)
        expends_data["income"] = self.template_strategy.income_list

        reverse_data = {k: (lambda x: x[::-1])(v) for k, v in expends_data.items()}
        json_str = json.dumps(reverse_data, ensure_ascii=False)
        print(json_str)

    def distribution(self, bean_bill_list: list):
        r = r"^\d{4}-(\d{2})-\d{2}"
        monthly_data = {}

        for item in bean_bill_list:
            match_obj = re.match(r, item)
            if match_obj:
                month = match_obj.group(1)
                if month not in monthly_data:
                    monthly_data[month] = []

                monthly_data[month].append(item)

        return monthly_data

        # self.write_bills(
        #     file_path="/Users/enmu/code/mandt/account/data/2026/income.bean",
        #     data=self.template_strategy.income_list,
        # )
        # self.write_bills(
        #     file_path=self.output, data=self.template_strategy.expense_list
        # )

    # def get_income_path(self) -> str:
    #     today = date.today()
    #     # month = f"{today.month:02d}"
    #     year = f"{today.year}"
    #     home = Path().home()
    #     return str(home / ".flow" / "account" / "data" / year / "income.bean")

    # def write_bills(self, file_path: str, data: list[str]):
    #     with open(file=file_path, mode="a", encoding="utf-8") as f:
    #         f.writelines(data)
