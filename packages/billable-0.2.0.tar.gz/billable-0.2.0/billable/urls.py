"""URL configuration for the billable module.

This module provides a "boxed" installation approach, allowing users to include
the billable app with a single line in their main urls.py. All NinjaAPI initialization
logic is encapsulated within this package.
"""

from django.urls import path
from ninja import NinjaAPI
from .api import router as billing_router
from .conf import billable_settings

# 1. Read settings from billable_settings wrapper
SHOW_DOCS = billable_settings.SHOW_DOCS
API_TITLE = billable_settings.API_TITLE

# 2. Create API instance
# If SHOW_DOCS=False, pass None, which disables documentation path generation
api = NinjaAPI(
    title=API_TITLE,
    docs_url="/docs" if SHOW_DOCS else None,
    urls_namespace="billable_default_api",  # To avoid conflicts with other APIs
)

# 3. Connect router
# Empty string "" means the router will be connected to the root of this API
api.add_router("", billing_router)

# 4. Export api object and api.urls for flexible usage
# The api object can be imported to add additional routers or exception handlers if needed
# api.urls returns a tuple (urlpatterns, app_name, namespace)
# When used directly in path(), Django automatically handles namespace registration correctly
# This matches the working pattern: path("api/v1/", api.urls)

# Export api object for advanced usage (adding routers, exception handlers, etc.)
__all__ = ['api', 'urlpatterns']

# Export api.urls as urlpatterns for direct use in path()
# Usage: path("api/v1/billing/", billable.urls.urlpatterns)
# or: from billable.urls import urlpatterns; path("api/v1/billing/", urlpatterns)
urlpatterns = api.urls
