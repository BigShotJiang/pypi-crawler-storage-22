from datetime import datetime, timedelta
from typing import Union
import pytz
import asyncio
import pandas as pd

async def get_trades_from_backup(self, symbol: str,
    since: int,
    until: int, 
    api_sleep_ms=1000,
    validate = False,
) -> pd.DataFrame:
    """
    Retrieves all trades for a symbol between since and until timestamps. 
    since and until are in epoch milliseconds
    Callback can be used to process the trades as they are downloaded or cancel the download midway
    """

    all_trades_df = None
    start_date = convert_date_to_datetime(since)
    end_date = convert_date_to_datetime(until)

    start_date_string = start_date.strftime('%Y-%m-%d')
    end_date_string = end_date.strftime('%Y-%m-%d')
    backup_symbol = symbol.split(':')[0].replace('/', '')

    symbol = self.symbol_normalizer(symbol)

    def backup_filename(backup_symbol, date_string):
        return f"{backup_symbol}-aggTrades-{date_string}.zip"

    backup_filenames = [backup_filename(backup_symbol, date_string) for date_string in pd.date_range(start_date_string, end_date_string).strftime('%Y-%m-%d')]

    backup_urls = [f"https://data.binance.vision/data/futures/um/daily/aggTrades/{backup_symbol}/{backup_filename}" for backup_filename in backup_filenames]

    def _convert_backup_trades_to_df(raw_trades_df):

        # NOTE: This is because for some reason binance sometimes have trades with 0 amount and/or price
        raw_trades_df = raw_trades_df[(raw_trades_df['quantity'] > 0) & (raw_trades_df['price'] > 0)]

        raw_trades_df['symbol'] = symbol

        raw_trades_df['market'] = self.market
        raw_trades_df['exchange'] = self.name
        raw_trades_df['provider'] = 'binance-backup'


        raw_trades_df.index = raw_trades_df['transact_time'].apply(lambda x: pd.Timestamp(x, unit='ms', tz=pytz.utc))

        raw_trades_df.index.rename('time', inplace=True)

        raw_trades_df['id'] = raw_trades_df['agg_trade_id'].astype(int)
        raw_trades_df['amount'] = raw_trades_df['quantity'].astype(float)
        raw_trades_df['price'] = raw_trades_df['price'].astype(float)
        raw_trades_df['buy'] = ~raw_trades_df['is_buyer_maker']

        raw_trades_df = raw_trades_df.drop(columns=[
            'agg_trade_id', 'first_trade_id', 'last_trade_id', 
            'quantity', 'transact_time', 'is_buyer_maker'
        ])

        return raw_trades_df

    try:
        for url in backup_urls:
            # df = pd.read_csv(url)
            df = pd.read_csv(url, header=None, names=[
                'agg_trade_id', 'price', 'quantity', 
                'first_trade_id', 'last_trade_id', 'transact_time', 'is_buyer_maker'
            ], low_memory=False)
            if df['quantity'].dtype == 'object':
                df = pd.read_csv(url, header=0, names=[
                    'agg_trade_id', 'price', 'quantity', 
                    'first_trade_id', 'last_trade_id', 'transact_time', 'is_buyer_maker'
                ])
            trades_df = _convert_backup_trades_to_df(df)
            if trades_df is None or trades_df.empty:
                break
            trades_df = date_slice_df(trades_df, since, until)

            if all_trades_df is None:
                all_trades_df = trades_df
            else:
                all_trades_df = pd.concat([all_trades_df, trades_df])

            await asyncio.sleep(api_sleep_ms / 1000)

        if all_trades_df is None:
            return pd.DataFrame()
    except:
        print(f"some Error fetching trades from backup: {since} to {until} for {symbol}")
        print("Retuning dataframes that have gotten")


    if all_trades_df is None or all_trades_df.empty:
        return pd.DataFrame()
    return date_slice_df(all_trades_df, since, until)


DateType = Union[datetime, str, int]

def convert_date_to_datetime(date: DateType):

    if isinstance(date, int):
        res = datetime.fromtimestamp((date / 1000), tz=pytz.UTC)
    elif isinstance(date, str):
        if 'T' in date:
            # ISO 8601 format
            res = datetime.fromisoformat(date.replace('Z', '+00:00'))
            if res.tzinfo is None:
                res = pytz.utc.localize(res)
        else:
            date_format = '%Y-%m-%d %H:%M:%S'
            res = datetime.strptime(date, date_format)
            res = pytz.utc.localize(res)
    elif isinstance(date, datetime):
        res = date
        if res.tzinfo is None:
            res = pytz.utc.localize(res)
    else:
        pass
    
    return res

def date_slice_df(df: pd.DataFrame, start: DateType, end: DateType) -> pd.DataFrame:
    start = convert_date_to_datetime(start)
    end = convert_date_to_datetime(end)

    return df[(df.index >= start) & (df.index <= end)]

