# binance_trades

Fetch raw trades from Binance futures (UM) and return them as pandas DataFrames. Uses [binance.vision](https://data.binance.vision) daily archives as primary source for fast bulk download, falls back to CCXT for recent dates not yet archived.

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

Requires a `.env` file in the `price/` directory:

```
BINANCE_API_KEY=your_key
BINANCE_API_SECRET=your_secret
```

API credentials are only needed for the CCXT fallback (recent dates not yet on binance.vision).

## Usage

```python
import asyncio
from binance_trades import fetch_trades, fetch_trades_multi

# Single symbol
df = asyncio.run(fetch_trades("BTC/USDT", "2025-01-01", "2025-01-05"))

# Bare token name (treated as TOKEN/USDT)
df = asyncio.run(fetch_trades("ETH", "2025-01-01", "2025-01-05"))

# Multiple symbols (returns one combined DataFrame with a `token` column)
df = asyncio.run(fetch_trades_multi(["BTC", "ETH", "AAVE"], "2025-01-01", "2025-01-03"))
print(f"Total trades: {len(df)}")
print(df.groupby("token").size())
```

### Date inputs

`start` and `end` accept:
- `str`: `"2025-01-01"`, `"2025-01-01 12:30:00"`, ISO 8601
- `int`: epoch milliseconds
- `datetime`: timezone-aware or naive (assumed UTC)

### Symbol inputs

All of these are equivalent:
- `"ETH"` (bare token, assumed USDT pair)
- `"ETH/USDT"` (canonical)
- `"ETH/USDT:USDT"` (CCXT futures format)

## Output DataFrame

| Column | Type | Description |
|--------|------|-------------|
| `time` | DatetimeIndex (UTC) | Trade timestamp (index) |
| `token` | str | Base token (e.g. `"ETH"`) |
| `amount` | float | Trade quantity |
| `price` | float | Trade price |
| `buy` | bool | True if buyer initiated |
| `id` | int64 | Unique trade ID |

Deduped on `id`, sorted by `time`.

## Architecture

1. **Vision** — downloads daily aggTrades ZIP archives from `data.binance.vision`. On 404 or error for a day, records that date as the cutoff and stops.
2. **CCXT** — if vision didn't cover the full range, fetches remaining trades via `ccxt.async_support.binance` with pagination and retry.
3. **Merge** — concatenates both sources, deduplicates on trade `id`, sorts by time, enforces column types.

## Using from other monorepo projects

Each subproject has its own virtual environment. To import `binance_trades` from another project (e.g. `core/`):

```bash
cd ../core
source venv/bin/activate
pip install -e ../price
```

Then use it normally:

```python
from binance_trades import fetch_trades
```

## Running tests

```bash
source .venv/bin/activate
pip install pytest pytest-asyncio
pytest tests/
```
