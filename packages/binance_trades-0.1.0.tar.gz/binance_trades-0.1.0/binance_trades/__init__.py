import logging
from typing import Optional

import pandas as pd

from .ccxt_client import fetch_ccxt_trades
from .config import extract_token, normalize_symbol
from .merge import empty_trades_df, merge_trade_dfs
from .utils import DateType
from .vision import fetch_vision_trades

logger = logging.getLogger(__name__)


async def fetch_trades(symbol: str, start: DateType, end: DateType) -> pd.DataFrame:
    symbol = normalize_symbol(symbol)
    token = extract_token(symbol)

    # 1. Try vision archives
    vision_df, cutoff_date = await fetch_vision_trades(symbol, start, end)
    logger.info(
        "Vision returned %d trades for %s, cutoff=%s",
        len(vision_df), symbol, cutoff_date,
    )

    # 2. Fall back to CCXT if vision didn't cover full range
    ccxt_df = pd.DataFrame()
    if cutoff_date is not None:
        logger.info("Falling back to CCXT from %s to %s for %s", cutoff_date, end, symbol)
        try:
            ccxt_df = await fetch_ccxt_trades(symbol, cutoff_date, end)
            logger.info("CCXT returned %d trades for %s", len(ccxt_df), symbol)
        except Exception as e:
            logger.warning("CCXT fallback failed for %s: %s", symbol, e)

    # 3. Merge
    df = merge_trade_dfs(vision_df, ccxt_df)

    if df.empty:
        df = empty_trades_df()

    # 4. Add token column
    df['token'] = token

    return df


async def fetch_trades_multi(
    symbols: list[str],
    start: DateType,
    end: DateType,
) -> pd.DataFrame:
    dfs: list[pd.DataFrame] = []
    for symbol in symbols:
        df = await fetch_trades(symbol, start, end)
        dfs.append(df)
    if not dfs:
        return empty_trades_df()
    combined = pd.concat(dfs)
    combined = combined.sort_index()
    return combined
