import asyncio
import logging

import pandas as pd
import pytz
import ccxt.async_support as ccxt_async

from .config import load_config, symbol_for_ccxt
from .utils import DateType, convert_date_to_datetime

logger = logging.getLogger(__name__)

MAX_RETRIES = 3
RETRY_BACKOFF = 2


async def fetch_ccxt_trades(
    symbol: str,
    start: DateType,
    end: DateType,
) -> pd.DataFrame:
    config = load_config()
    if not config['api_key'] or not config['api_secret']:
        raise RuntimeError(
            "BINANCE_API_KEY and BINANCE_API_SECRET must be set in .env"
        )

    start_dt = convert_date_to_datetime(start)
    end_dt = convert_date_to_datetime(end)
    ccxt_sym = symbol_for_ccxt(symbol)

    since_ms = int(start_dt.timestamp() * 1000)
    end_ms = int(end_dt.timestamp() * 1000)

    logger.info("CCXT: fetching %s from %s to %s", ccxt_sym, start_dt, end_dt)

    exchange = ccxt_async.binance({
        'apiKey': config['api_key'],
        'secret': config['api_secret'],
        'enableRateLimit': True,
        'options': {'defaultType': 'future'},
    })

    all_trades: list[dict] = []
    page = 0

    try:
        while since_ms < end_ms:
            page += 1
            retries = 0
            trades = None
            while retries < MAX_RETRIES:
                try:
                    logger.debug("CCXT: page %d, since_ms=%d (%.1f%% through range)",
                                 page, since_ms,
                                 (since_ms - int(start_dt.timestamp() * 1000))
                                 / max(1, end_ms - int(start_dt.timestamp() * 1000)) * 100)
                    trades = await exchange.fetch_trades(
                        ccxt_sym, since=since_ms, limit=1000
                    )
                    break
                except ccxt_async.NetworkError as e:
                    retries += 1
                    if retries >= MAX_RETRIES:
                        logger.error("CCXT: network error after %d retries: %s", MAX_RETRIES, e)
                        raise
                    wait = RETRY_BACKOFF ** retries
                    logger.warning("CCXT: network error (retry %d/%d), waiting %ds: %s", retries, MAX_RETRIES, wait, e)
                    await asyncio.sleep(wait)
                except ccxt_async.AuthenticationError as e:
                    raise RuntimeError(
                        f"CCXT authentication failed. Check .env credentials: {e}"
                    ) from e

            if not trades:
                logger.info("CCXT: no trades returned on page %d, stopping", page)
                break

            # Filter trades within our end boundary
            for t in trades:
                if t['timestamp'] > end_ms:
                    break
                all_trades.append(t)

            # Advance past the last trade
            last_ts = trades[-1]['timestamp']
            if last_ts <= since_ms:
                # No progress — avoid infinite loop
                logger.warning("CCXT: no timestamp progress on page %d (stuck at %d), nudging +1ms", page, since_ms)
                since_ms += 1
            else:
                since_ms = last_ts + 1

            if page % 50 == 0:
                logger.info("CCXT: page %d, %d trades so far, last_ts=%d", page, len(all_trades), last_ts)

            # If we got fewer than limit, we've exhausted available data
            if len(trades) < 1000:
                logger.info("CCXT: got %d trades (< 1000) on page %d, done", len(trades), page)
                break
    finally:
        logger.info("CCXT: closing exchange, %d total trades fetched in %d pages", len(all_trades), page)
        await exchange.close()

    if not all_trades:
        return pd.DataFrame()

    rows = []
    for t in all_trades:
        rows.append({
            'time': pd.Timestamp(t['timestamp'], unit='ms', tz=pytz.utc),
            'id': int(t['id']),
            'amount': float(t['amount']),
            'price': float(t['price']),
            'buy': t['side'] == 'buy',
        })

    df = pd.DataFrame(rows)
    df = df.set_index('time')
    df.index.name = 'time'
    return df
