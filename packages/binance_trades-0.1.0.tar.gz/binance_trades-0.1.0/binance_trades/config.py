import os
from pathlib import Path

from dotenv import load_dotenv


def load_config() -> dict:
    env_path = Path(__file__).resolve().parent.parent / '.env'
    load_dotenv(env_path)
    return {
        'api_key': os.getenv('BINANCE_API_KEY', ''),
        'api_secret': os.getenv('BINANCE_API_SECRET', ''),
    }


def normalize_symbol(symbol: str) -> str:
    symbol = symbol.strip().upper()
    # Remove futures suffix if present
    if symbol.endswith(':USDT'):
        symbol = symbol[:-5]
    # If bare token (no slash), assume /USDT pair
    if '/' not in symbol:
        symbol = f"{symbol}/USDT"
    return symbol


def symbol_for_vision(symbol: str) -> str:
    s = normalize_symbol(symbol)
    return s.replace('/', '')


def symbol_for_ccxt(symbol: str) -> str:
    s = normalize_symbol(symbol)
    return f"{s}:USDT"


def extract_token(symbol: str) -> str:
    s = normalize_symbol(symbol)
    return s.split('/')[0]
