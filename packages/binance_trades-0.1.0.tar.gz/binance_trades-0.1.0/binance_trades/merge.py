import numpy as np
import pandas as pd
import pytz


def empty_trades_df() -> pd.DataFrame:
    df = pd.DataFrame(columns=['token', 'amount', 'price', 'buy', 'id'])
    df.index.name = 'time'
    df['amount'] = df['amount'].astype(float)
    df['price'] = df['price'].astype(float)
    df['buy'] = df['buy'].astype(bool)
    df['id'] = df['id'].astype('int64')
    return df


def merge_trade_dfs(*dfs: pd.DataFrame) -> pd.DataFrame:
    non_empty = [df for df in dfs if df is not None and not df.empty]
    if not non_empty:
        return empty_trades_df()

    merged = pd.concat(non_empty)

    # Dedup on trade id, keep first occurrence
    merged = merged[~merged['id'].duplicated(keep='first')]

    # Sort by time index
    merged = merged.sort_index()

    # Enforce types
    merged['amount'] = merged['amount'].astype(float)
    merged['price'] = merged['price'].astype(float)
    merged['buy'] = merged['buy'].astype(bool)
    merged['id'] = merged['id'].astype('int64')

    return merged
