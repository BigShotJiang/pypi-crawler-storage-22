from datetime import datetime
from typing import Union

import pandas as pd
import pytz

DateType = Union[datetime, str, int]


def convert_date_to_datetime(date: DateType) -> datetime:
    if isinstance(date, int):
        res = datetime.fromtimestamp(date / 1000, tz=pytz.UTC)
    elif isinstance(date, str):
        if 'T' in date:
            res = datetime.fromisoformat(date.replace('Z', '+00:00'))
            if res.tzinfo is None:
                res = pytz.utc.localize(res)
        elif ' ' in date:
            res = datetime.strptime(date, '%Y-%m-%d %H:%M:%S')
            res = pytz.utc.localize(res)
        else:
            res = datetime.strptime(date, '%Y-%m-%d')
            res = pytz.utc.localize(res)
    elif isinstance(date, datetime):
        res = date
        if res.tzinfo is None:
            res = pytz.utc.localize(res)
    else:
        raise ValueError(f"Unsupported date type: {type(date)}")

    return res


def date_slice_df(df: pd.DataFrame, start: DateType, end: DateType) -> pd.DataFrame:
    start = convert_date_to_datetime(start)
    end = convert_date_to_datetime(end)
    return df[(df.index >= start) & (df.index <= end)]
