import asyncio
import io
import logging
import zipfile
from datetime import datetime, timedelta
from typing import Optional

import aiohttp
import pandas as pd
import pytz

from .config import symbol_for_vision
from .utils import DateType, convert_date_to_datetime, date_slice_df

logger = logging.getLogger(__name__)

AGG_TRADE_COLUMNS = [
    'agg_trade_id', 'price', 'quantity',
    'first_trade_id', 'last_trade_id', 'transact_time', 'is_buyer_maker',
]

BASE_URL = "https://data.binance.vision/data/futures/um/daily/aggTrades"


def _extract_zip(data: bytes) -> bytes:
    """Extract the first file from a ZIP archive."""
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        name = zf.namelist()[0]
        return zf.read(name)


def _parse_vision_csv(data: bytes) -> pd.DataFrame:
    csv_bytes = _extract_zip(data)
    # Peek at first line to decide whether a header row exists
    first_line = csv_bytes.split(b'\n', 1)[0].decode('utf-8', errors='replace')
    has_header = not first_line.split(',')[0].strip().lstrip('-').isdigit()
    logger.debug("Vision CSV first line: %s (has_header=%s)", first_line[:120], has_header)

    df = pd.read_csv(
        io.BytesIO(csv_bytes),
        header=0 if has_header else None,
        names=AGG_TRADE_COLUMNS,
        low_memory=False,
    )
    return df


def _convert_to_trades_df(raw: pd.DataFrame) -> pd.DataFrame:
    # Filter out zero-amount / zero-price rows
    raw = raw[(raw['quantity'] > 0) & (raw['price'] > 0)]
    if raw.empty:
        return raw

    raw.index = raw['transact_time'].apply(
        lambda x: pd.Timestamp(x, unit='ms', tz=pytz.utc)
    )
    raw.index.rename('time', inplace=True)

    raw['id'] = raw['agg_trade_id'].astype('int64')
    raw['amount'] = raw['quantity'].astype(float)
    raw['price'] = raw['price'].astype(float)
    raw['buy'] = ~raw['is_buyer_maker'].astype(bool)

    raw = raw.drop(columns=[
        'agg_trade_id', 'first_trade_id', 'last_trade_id',
        'quantity', 'transact_time', 'is_buyer_maker',
    ])
    return raw


async def fetch_vision_trades(
    symbol: str,
    start: DateType,
    end: DateType,
) -> tuple[pd.DataFrame, Optional[datetime]]:
    start_dt = convert_date_to_datetime(start)
    end_dt = convert_date_to_datetime(end)
    vision_sym = symbol_for_vision(symbol)

    dates = pd.date_range(
        start_dt.strftime('%Y-%m-%d'),
        end_dt.strftime('%Y-%m-%d'),
    )

    all_dfs: list[pd.DataFrame] = []
    cutoff_date: Optional[datetime] = None
    loop = asyncio.get_running_loop()
    total_days = len(dates)

    logger.info("Vision: fetching %s from %s to %s (%d days)", vision_sym, start_dt, end_dt, total_days)

    async with aiohttp.ClientSession() as session:
        for day_idx, day in enumerate(dates, 1):
            date_str = day.strftime('%Y-%m-%d')
            filename = f"{vision_sym}-aggTrades-{date_str}.zip"
            url = f"{BASE_URL}/{vision_sym}/{filename}"

            logger.info("Vision: [%d/%d] downloading %s", day_idx, total_days, filename)

            try:
                async with session.get(url) as resp:
                    if resp.status == 404:
                        logger.info("Vision: 404 for %s on %s, marking cutoff", vision_sym, date_str)
                        cutoff_date = pytz.utc.localize(day.to_pydatetime())
                        break
                    resp.raise_for_status()
                    data = await resp.read()
                    logger.debug("Vision: downloaded %s (%.1f KB)", filename, len(data) / 1024)
            except aiohttp.ClientResponseError:
                logger.warning("Vision: HTTP error for %s on %s, marking cutoff", vision_sym, date_str)
                cutoff_date = pytz.utc.localize(day.to_pydatetime())
                break
            except Exception as e:
                logger.warning("Vision: error for %s on %s: %s, marking cutoff", vision_sym, date_str, e)
                cutoff_date = pytz.utc.localize(day.to_pydatetime())
                break

            try:
                raw = await loop.run_in_executor(None, _parse_vision_csv, data)
                trades = _convert_to_trades_df(raw)
                logger.info("Vision: [%d/%d] parsed %s -> %d trades", day_idx, total_days, date_str, len(trades))
            except Exception as e:
                logger.warning("Vision: parse error for %s on %s: %s, marking cutoff", vision_sym, date_str, e)
                cutoff_date = pytz.utc.localize(day.to_pydatetime())
                break

            if trades.empty:
                continue

            trades = date_slice_df(trades, start, end)
            all_dfs.append(trades)

    if not all_dfs:
        logger.info("Vision: no trades collected for %s", vision_sym)
        return pd.DataFrame(), cutoff_date

    df = pd.concat(all_dfs)
    logger.info("Vision: total %d trades for %s, cutoff=%s", len(df), vision_sym, cutoff_date)
    return df, cutoff_date
