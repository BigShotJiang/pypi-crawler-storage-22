"""
Integration test: fetch AAVE/USDT trades for the last 2 weeks and validate
the resulting DataFrame schema, deduplication, sort order, and date range.

Requires network access and a valid .env with Binance credentials (for CCXT
fallback on recent dates).

Run with:
    pytest tests/test_integration.py -v -s
"""

from datetime import datetime, timedelta

import pandas as pd
import pytz
import pytest
import pytest_asyncio

from binance_trades import fetch_trades

SYMBOL = "AAVE"
WINDOW_DAYS = 4


@pytest.fixture
def date_range():
    end = datetime.now(tz=pytz.UTC).replace(hour=0, minute=0, second=0, microsecond=0)
    start = end - timedelta(days=WINDOW_DAYS)
    return start, end


@pytest.mark.asyncio
async def test_aave_trades_schema_and_range(date_range):
    start, end = date_range
    df = await fetch_trades(SYMBOL, start, end)

    # --- non-empty ---
    assert len(df) > 0, "Expected trades but got empty DataFrame"

    # --- index ---
    assert df.index.name == "time", f"Index name should be 'time', got '{df.index.name}'"
    assert df.index.dtype.kind == "M", "Index should be datetime"
    assert df.index.tz is not None, "Index should be tz-aware"

    # --- required columns ---
    expected_cols = {"token", "amount", "price", "buy", "id"}
    assert expected_cols.issubset(set(df.columns)), (
        f"Missing columns: {expected_cols - set(df.columns)}"
    )

    # --- dtypes ---
    assert df["amount"].dtype == float, f"amount dtype: {df['amount'].dtype}"
    assert df["price"].dtype == float, f"price dtype: {df['price'].dtype}"
    assert df["buy"].dtype == bool, f"buy dtype: {df['buy'].dtype}"
    assert df["id"].dtype == "int64", f"id dtype: {df['id'].dtype}"

    # --- token value ---
    assert (df["token"] == "AAVE").all(), "All rows should have token='AAVE'"

    # --- dedup ---
    assert df["id"].is_unique, "Trade IDs should be unique (deduped)"

    # --- sort order ---
    assert df.index.is_monotonic_increasing, "Index should be sorted ascending"

    # --- date range ---
    # Allow 1 day tolerance: vision archives are daily granularity, so the
    # first available trade may be slightly after `start`, and the last trade
    # may be before `end` if the most recent archive isn't posted yet.
    tolerance = timedelta(days=1)

    first_trade = df.index.min()
    last_trade = df.index.max()

    assert first_trade >= start - tolerance, (
        f"First trade {first_trade} is before start {start} (minus tolerance)"
    )
    assert first_trade <= start + tolerance, (
        f"First trade {first_trade} is too far after start {start}"
    )
    assert last_trade <= end + tolerance, (
        f"Last trade {last_trade} is after end {end} (plus tolerance)"
    )
    assert last_trade >= end - tolerance * 2, (
        f"Last trade {last_trade} is too far before end {end}"
    )

    # --- summary ---
    print(f"\n{'='*60}")
    print(f"AAVE trades: {len(df):,}")
    print(f"Range: {first_trade} -> {last_trade}")
    print(f"Requested: {start} -> {end}")
    print(f"Columns: {list(df.columns)}")
    print(f"Dtypes:\n{df.dtypes}")
    print(f"Head:\n{df.head()}")
    print(f"{'='*60}")
