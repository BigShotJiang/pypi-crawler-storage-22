"""
Integration test: fetch AAVE/USDT and LINK/USDT trades for the last 8 days
using fetch_trades_multi, and validate the combined DataFrame.

Requires network access and a valid .env with Binance credentials (for CCXT
fallback on recent dates).

Run with:
    pytest tests/test_integration_multi.py -v -s
"""

from datetime import datetime, timedelta

import pandas as pd
import pytz
import pytest

from binance_trades import fetch_trades_multi

SYMBOLS = ["AAVE", "LINK"]
WINDOW_DAYS = 4


@pytest.fixture
def date_range():
    end = datetime.now(tz=pytz.UTC).replace(hour=0, minute=0, second=0, microsecond=0)
    start = end - timedelta(days=WINDOW_DAYS)
    return start, end


@pytest.mark.asyncio
async def test_multi_token_trades(date_range):
    start, end = date_range
    df = await fetch_trades_multi(SYMBOLS, start, end)

    tolerance = timedelta(days=1)

    # --- non-empty ---
    assert len(df) > 0, "Expected trades but got empty DataFrame"

    # --- index ---
    assert df.index.name == "time", f"Index name should be 'time', got '{df.index.name}'"
    assert df.index.dtype.kind == "M", "Index should be datetime"
    assert df.index.tz is not None, "Index should be tz-aware"

    # --- required columns ---
    expected_cols = {"token", "amount", "price", "buy", "id"}
    assert expected_cols.issubset(set(df.columns)), (
        f"Missing columns: {expected_cols - set(df.columns)}"
    )

    # --- dtypes ---
    assert df["amount"].dtype == float, f"amount dtype: {df['amount'].dtype}"
    assert df["price"].dtype == float, f"price dtype: {df['price'].dtype}"
    assert df["buy"].dtype == bool, f"buy dtype: {df['buy'].dtype}"
    assert df["id"].dtype == "int64", f"id dtype: {df['id'].dtype}"

    # --- both tokens present ---
    tokens_found = set(df["token"].unique())
    assert tokens_found == set(SYMBOLS), (
        f"Expected tokens {set(SYMBOLS)}, got {tokens_found}"
    )

    # --- sort order (combined df is sorted by time across both tokens) ---
    assert df.index.is_monotonic_increasing, "Index should be sorted ascending"

    # --- per-token validation ---
    for symbol in SYMBOLS:
        token_df = df[df["token"] == symbol]

        assert len(token_df) > 0, f"{symbol}: expected trades but got none"

        first_trade = token_df.index.min()
        last_trade = token_df.index.max()

        assert first_trade >= start - tolerance, (
            f"{symbol}: first trade {first_trade} is before start {start} (minus tolerance)"
        )
        assert first_trade <= start + tolerance, (
            f"{symbol}: first trade {first_trade} is too far after start {start}"
        )
        assert last_trade <= end + tolerance, (
            f"{symbol}: last trade {last_trade} is after end {end} (plus tolerance)"
        )
        assert last_trade >= end - tolerance * 2, (
            f"{symbol}: last trade {last_trade} is too far before end {end}"
        )

        print(f"\n{'='*60}")
        print(f"{symbol} trades: {len(token_df):,}")
        print(f"Range: {first_trade} -> {last_trade}")
        print(f"{'='*60}")

    # --- combined summary ---
    print(f"\nCombined DataFrame: {len(df):,} trades")
    print(f"Tokens: {list(tokens_found)}")
    print(f"Requested: {start} -> {end}")
    print(f"Head:\n{df.head()}")
