"""Implementation of the PAGE Algorithm
"""

from .io import (
    GeneSets,
    ExpressionProfile)
from .utils import (
    empirical_pvalue,
    hypergeometric_test,
    benjamini_hochberg)
from .information import (
    mutual_information,
    conditional_mutual_information,
    calculate_mi_permutations,
    calculate_cmi_permutations,
    measure_redundancy,
    batch_mutual_information,
    batch_conditional_mutual_information)
from .heatmap import Heatmap

import numpy as np
import numba as nb
import pandas as pd
import sys
from typing import Optional, Tuple


class PAGE:
    """
    Pathway Analysis of Gene Expression [1]_


    Methods
    -------
    run:
        Perform the PAGE algorithm on the provided data

    Attributes
    ----------
    expression: ExpressionProfile
        the provided expression profile
    ontology: GeneSets
        the provided ontology
    shared_genes: np.ndarray
        the shared genes between the `ExpressionProfile` and `GeneOntology`
    exp_bins: np.ndarray
        the expression bins for the intersection of `shared_genes`.
        of shape (`shared_genes`.size, )
    ont_bool: np.ndarray
        the ontology bins for the intersection of `shared_genes`.
        of shape (`num_pathways`, `shared_genes`.size)
    x_bins: int
        the number of expression bins in `exp_bins`
    y_bins: int
        the number of expression bins in `ont_bool`
    num_pathways: int
        the number of pathways in `ontology`
    information: np.ndarray
        the calculated mutual information for each pathway.
        of shape (`num_pathways`, )
    informative: np.ndarray
        a `bool` array representing whether that pathway was considered informative.
        of shape (`num_pathways`, )
    n_shuffle: int
        the number of performed permutation tests
        (`default = 1e4`)
    alpha: float
        the maximum p-value threshold to consider a pathway informative
        with respect to the permuted mutual information distribution
        (`default = 5e-3`)
    k: int
        the number of contiguous uninformative pathways to consider before
        stopping the informative pathway search
        (`default = 20`)
    r: float
        the ratio of the conditional mutual information of a new accepted
        pathway against the mutual information of that pathway against
        all other accepted pathways. Only active when filter_redundant == True.
        (`default = 5.0`)
    base: int
        the base of the logarithm used when calculating entropy
        (`default = 2`)
    filter_redundant: bool
        whether to perform the pathway redundancy search
        (`default = True`)
    n_jobs: int
        The number of parallel jobs to use in the analysis
        (`default = all available cores`)


    Notes
    =====
    .. [1] H. Goodarzi, O. Elemento, S. Tavazoie, "Revealing Global Regulatory Perturbations across Human Cancers." https://doi.org/10.1016/j.molcel.2009.11.016
    """

    def __init__(
            self,
            expression: ExpressionProfile,
            genesets: GeneSets,
            n_shuffle: int = 10000,
            alpha: float = 5e-3,
            k: int = 20,
            filter_redundant: bool = True,
            n_jobs: Optional[int] = 1,
            function: Optional[str] = 'cmi',
            redundancy_ratio: Optional[float] = 5.0):
        """
        Initialize object

        Parameters
        ----------
        expression: ExpressionProfile
            The provided `ExpressionProfile`

        genesets: GeneSets
            the provided `GeneOntology`

        n_shuffle: int
            the number of performed permutation tests
            (`default = 1e4`)

        alpha: float
            the maximum p-value threshold to consider a pathway informative
            with respect to the permuted mutual information distribution
            (`default = 5e-3`)

        k: int
            the number of contiguous uninformative pathways to consider before
            stopping the informative pathway search
            (`default = 20`)

        base: int
            the base of the logarithm used when calculating entropy
            (`default = 2`)

        filter_redundant: bool
            whether to perform the pathway redundancy search
            (`default = True`)

        redundancy_ratio: float
            the ratio of CMI/MI above which a pathway is considered
            non-redundant with respect to already accepted pathways
            (`default = 5.0`)

        function: str
            the information function to use: 'mi' or 'cmi'
            (`default = 'cmi'`)

        n_jobs: int
            The number of parallel jobs to use in the analysis
            (`default = all available cores`)
        """

        self.expression = expression
        self.ontology = genesets

        self.n_shuffle = int(n_shuffle)
        self.alpha = float(alpha)
        self.k = int(k)
        self.base = 2
        self.filter_redundant = filter_redundant
        self.n_jobs = n_jobs
        self._set_jobs()
        self.function = function
        self.redundancy_ratio = redundancy_ratio
        self._killed_log = []

        # Validate parameters
        if not (0 < self.alpha < 1):
            raise ValueError(f"alpha must be in (0, 1), got {self.alpha}")
        if self.k <= 0:
            raise ValueError(f"k must be > 0, got {self.k}")
        if self.n_shuffle <= 0:
            raise ValueError(f"n_shuffle must be > 0, got {self.n_shuffle}")
        if self.function not in ('mi', 'cmi'):
            raise ValueError(f"function must be 'mi' or 'cmi', got {self.function!r}")
        if self.redundancy_ratio is not None and self.redundancy_ratio <= 0:
            raise ValueError(f"redundancy_ratio must be > 0, got {self.redundancy_ratio}")

        # Always refresh derived arrays for this PAGE instance.
        # Input objects may have been used in previous PAGE runs.
        self._intersect_genes()
        self._subset_matrices()
        self._set_sizes()

    def _set_jobs(self):
        """Sets the number of available jobs for numba parallel
        """
        if self.n_jobs:
            self.n_jobs = int(self.n_jobs)
            nb.set_num_threads(self.n_jobs)
        else:
            # default to using all available threads
            nb.set_num_threads(nb.config.NUMBA_NUM_THREADS)

    def _intersect_genes(self):
        """Intersects to genes found in both sets
        """
        self.shared_genes = np.sort(np.intersect1d(
                                    self.expression.genes,
                                    self.ontology.genes))

    def _subset_matrices(self):
        """Subsets the bool arrays to the gene intersection
        """
        self.exp_bins = self.expression.get_gene_subset(self.shared_genes)
        self.ont_bool = self.ontology.get_gene_subset(self.shared_genes)
        self.membership_bins = self.ontology.get_membership_subset(self.shared_genes)

    def _set_sizes(self):
        """Sets the number of bins for the expression and ontology
        as well as the number of pathways found
        """
        self.x_bins = self.exp_bins.max() + 1
        self.y_bins = self.ont_bool.max() + 1
        self.z_bins = self.membership_bins.max() + 1
        self.num_pathways = self.ont_bool.shape[0]

    def _calculate_information(self) -> np.ndarray:
        """Calculates mutual or conditional mutual information for each pathway
        """
        if self.function == 'mi':
            return batch_mutual_information(
                self.exp_bins,
                self.ont_bool,
                self.x_bins,
                self.y_bins,
                base=self.base)
        else:
            return batch_conditional_mutual_information(
                self.exp_bins,
                self.ont_bool,
                self.membership_bins,
                self.x_bins,
                self.y_bins,
                self.z_bins,
                base=self.base)

    def _calculate_information_2D(self) -> np.ndarray:
        """Calculates mutual or conditional mutual information for each pathway
        """
        information = np.zeros((self.exp_bins.shape[0], self.num_pathways))
        for exp_idx in range(self.exp_bins.shape[0]):
            for idx in range(self.num_pathways):
                if self.function == 'mi':
                    information[exp_idx, idx] = mutual_information(
                        self.exp_bins[exp_idx],
                        self.ont_bool[idx],
                        self.x_bins,
                        self.y_bins,
                        base=self.base)
                else:
                    information[exp_idx, idx] = conditional_mutual_information(
                        self.exp_bins[exp_idx],
                        self.ont_bool[idx],
                        self.membership_bins,
                        self.x_bins,
                        self.y_bins,
                        self.z_bins,
                        base=self.base)
        information = pd.DataFrame(information, columns=self.ontology.pathways)

        return information

    def _calculate_enrichment(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Iterates through informative pathways to calculate hypergeometric pvalues
        """
        overrep_pvals = np.zeros((self.pathway_indices.size, self.x_bins))
        underrep_pvals = np.zeros_like(overrep_pvals)

        for idx, info_idx in enumerate(self.pathway_indices):
            pvals = hypergeometric_test(
                self.exp_bins,
                self.ont_bool[info_idx])
            overrep_pvals[idx, :] = pvals[0]
            underrep_pvals[idx, :] = pvals[1]

        return overrep_pvals, underrep_pvals

    def _calculate_informative(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Calculates the informative categories
        """
        n_break = 0
        informative = np.zeros_like(self.information)
        pvalues = np.ones_like(self.information)
        zscores = np.full_like(self.information, np.nan)
        accepted_nonredundant = []

        # iterate through most informative pathways
        sorted_idx = np.argsort(self.information)[::-1]
        for rank, idx in enumerate(sorted_idx, start=1):
            pathway_name = self.ontology.pathways[idx]
            if self.filter_redundant and len(accepted_nonredundant) > 0:
                all_ri = np.zeros(len(accepted_nonredundant))
                for i, e in enumerate(accepted_nonredundant):
                    all_ri[i] = measure_redundancy(
                        self.exp_bins,
                        self.ont_bool[idx],
                        self.ont_bool[e],
                        self.x_bins,
                        self.y_bins,
                        self.y_bins,
                    )
                if not np.all(all_ri > self.redundancy_ratio):
                    min_idx = int(np.argmin(all_ri))
                    killer_idx = accepted_nonredundant[min_idx]
                    print(
                        (
                            f"[filtered:redundancy] pathway={pathway_name} "
                            f"killed_by={self.ontology.pathways[killer_idx]} "
                            f"ratio={all_ri[min_idx]:.6g} "
                            f"threshold={self.redundancy_ratio:.6g}"
                        ),
                        file=sys.stdout,
                        flush=True,
                    )
                    self._killed_log.append((
                        pathway_name,
                        self.ontology.pathways[killer_idx],
                        all_ri[min_idx],
                    ))
                    continue

            # calculate mutual information of random permutations
            if self.function == 'mi':
                permutations = calculate_mi_permutations(
                    self.exp_bins,
                    self.ont_bool[idx],
                    self.x_bins,
                    self.y_bins,
                    n=self.n_shuffle)
            else:
                permutations = calculate_cmi_permutations(
                    self.exp_bins,
                    self.ont_bool[idx],
                    self.membership_bins,
                    self.x_bins,
                    self.y_bins,
                    self.z_bins,
                    n=self.n_shuffle)

            # calculate empirical pvalue against randomization
            pvalues[idx] = empirical_pvalue(
                permutations,
                self.information[idx])

            # calculate z-score
            perm_std = permutations.std()
            if perm_std > 0:
                zscores[idx] = (self.information[idx] - permutations.mean()) / perm_std
            else:
                zscores[idx] = np.inf if self.information[idx] > permutations.mean() else 0.0

            passed = bool(pvalues[idx] <= self.alpha)
            print(
                (
                    f"[permutation] rank={rank}/{self.num_pathways} "
                    f"pathway={pathway_name} "
                    f"CMI={self.information[idx]:.6g} "
                    f"z={zscores[idx]:.6g} "
                    f"p={pvalues[idx]:.4e} "
                    f"pass={passed}"
                ),
                file=sys.stdout,
                flush=True,
            )

            if pvalues[idx] > self.alpha:
                print(
                    (
                        f"[filtered:alpha] pathway={pathway_name} "
                        f"p={pvalues[idx]:.4e} > alpha={self.alpha:.4e}"
                    ),
                    file=sys.stdout,
                    flush=True,
                )
                n_break += 1
                if n_break == self.k:
                    print(
                        f"[permutation] early_stopping after={rank} pathways k={self.k}",
                        file=sys.stdout,
                        flush=True,
                    )
                    break
            else:
                informative[idx] = 1
                if self.filter_redundant:
                    accepted_nonredundant.append(idx)
                n_break = 0

        self.pathway_indices = np.array(accepted_nonredundant, dtype=int)
        return (informative, pvalues, zscores)

    def _consolidate_pathways(self) -> np.ndarray:
        """Consolidate redundant pathways, tracking which pathway killed each rejection.
        """
        existing = []
        self._killed_log = []
        informative_mask = self.informative.astype(bool)

        # iterate through cmi in descending order
        for idx in np.argsort(self.information)[::-1]:

            # skip indices that are not informative
            if not informative_mask[idx]:
                continue

            # if there are no existing pathways yet start the chain
            if len(existing) == 0:
                existing.append(idx)
                continue

            # initialize redundancy information array
            all_ri = np.zeros(len(existing))

            # calculate redundancy
            for i, e in enumerate(existing):
                all_ri[i] = measure_redundancy(
                    self.exp_bins,
                    self.ont_bool[idx],
                    self.ont_bool[e],
                    self.x_bins,
                    self.y_bins,
                    self.y_bins)

            if np.all(all_ri > self.redundancy_ratio):
                existing.append(idx)
            else:
                # Track which accepted pathway caused the rejection
                min_idx = int(np.argmin(all_ri))
                killer_idx = existing[min_idx]
                print(
                    (
                        f"[filtered:redundancy] pathway={self.ontology.pathways[idx]} "
                        f"killed_by={self.ontology.pathways[killer_idx]} "
                        f"ratio={all_ri[min_idx]:.6g} "
                        f"threshold={self.redundancy_ratio:.6g}"
                    ),
                    file=sys.stdout,
                    flush=True,
                )
                self._killed_log.append((
                    self.ontology.pathways[idx],
                    self.ontology.pathways[killer_idx],
                    all_ri[min_idx]))

        return np.array(existing)

    def get_redundancy_log(self) -> pd.DataFrame:
        """Return a DataFrame of pathways rejected during redundancy filtering.

        Returns
        -------
        pd.DataFrame
            Columns: rejected_pathway, killed_by, min_ratio
        """
        if not hasattr(self, '_killed_log'):
            return pd.DataFrame(columns=['rejected_pathway', 'killed_by', 'min_ratio'])
        return pd.DataFrame(
            self._killed_log,
            columns=['rejected_pathway', 'killed_by', 'min_ratio'])

    def _gather_results(self) -> pd.DataFrame:
        """Gathers the results from the experiment into a single dataframe
        """
        # estimate sign
        self.log_overrep_pvals = np.log10(self.overrep_pvals + 1e-8)
        self.log_underrep_pvals = np.log10(self.underrep_pvals + 1e-8)
        self.graphical_ar = np.minimum(self.log_overrep_pvals, self.log_underrep_pvals)
        self.graphical_ar[self.log_overrep_pvals < self.log_underrep_pvals] *= -1  # make overrepresented positive
        n_bins = self.graphical_ar.shape[1]
        s1 = self.graphical_ar[:, :n_bins // 3].copy()
        s2 = self.graphical_ar[:, -n_bins // 3:].copy()
        s1[s1 < 0] = 0
        s2[s2 < 0] = 0
        sign = s1.sum(1) <= s2.sum(1)
        sign = sign.astype(int)
        sign[sign == 0] = -1
        results = pd.DataFrame({"pathway": self.ontology.pathways[self.pathway_indices],
                                "CMI": self.information[self.pathway_indices],
                                "z-score": self.zscores[self.pathway_indices],
                                "p-value": self.pvalues[self.pathway_indices],
                                "Regulation pattern": sign}
                               )
        return results

    def _make_heatmap(self):
        """

        Returns
        -------

        """

        hm = Heatmap(np.array(self.results['pathway']),
                     self.graphical_ar,
                     bin_edges=getattr(self.expression, 'bin_edges', None),
                     bin_labels=getattr(self.expression, 'bin_labels', None))

        hm.add_gene_expression(self.expression.genes, self.expression.raw_expression)
        return hm

    def run(self) -> Tuple[pd.DataFrame, Optional[Heatmap]]:
        """
        Perform the PAGE algorithm

        Returns
        =======
        pd.DataFrame
            A dataframe representing the results of the analysis

        Examples
        ========
        >>> p = PAGE(exp, ont)
        >>> p.run()
        """

        # calculate mutual information
        if len(self.exp_bins.shape) == 2:
            self.information = self._calculate_information_2D()
            return self.information, None

        self.information = self._calculate_information()

        # select informative pathways
        self.informative, self.pvalues, self.zscores = self._calculate_informative()

        # filter redundant pathways (online during informative scan)
        all_informative_indices = np.flatnonzero(self.informative)
        if not self.filter_redundant:
            self.pathway_indices = all_informative_indices

        # Build full_results containing all informative pathways with redundancy flag
        non_redundant_set = set(self.pathway_indices.tolist()) if len(self.pathway_indices) > 0 else set()
        self.full_results = pd.DataFrame({
            "pathway": self.ontology.pathways[all_informative_indices],
            "CMI": self.information[all_informative_indices],
            "z-score": self.zscores[all_informative_indices],
            "p-value": self.pvalues[all_informative_indices],
            "redundant": [idx not in non_redundant_set for idx in all_informative_indices]
        })

        if len(self.pathway_indices) != 0:
            # hypergeometric testing over selected pathways
            self.overrep_pvals, self.underrep_pvals = self._calculate_enrichment()

            self.results = self._gather_results()
            self.hm = self._make_heatmap()

            return self.results, self.hm
        else:
            return pd.DataFrame(columns=["pathway", "CMI", "z-score", "p-value", "Regulation pattern"]), None

    def run_manual(self, pathway_names: list) -> Tuple[pd.DataFrame, Optional[Heatmap]]:
        """Compute enrichment statistics and heatmap for a user-specified
        list of pathways, bypassing significance and redundancy tests.

        Parameters
        ----------
        pathway_names: list
            List of pathway names to include in the analysis.
            All names must exist in the gene set annotations.

        Returns
        -------
        Tuple[pd.DataFrame, Optional[Heatmap]]
            Results DataFrame and Heatmap object for the selected pathways.
        """
        if len(self.exp_bins.shape) == 2:
            raise ValueError("run_manual is not supported for 2D expression profiles")

        # Validate pathway names
        unknown = [n for n in pathway_names if n not in self.ontology.pathways]
        if unknown:
            raise ValueError(f"Unknown pathway(s): {unknown}")

        # Resolve pathway names to indices
        pathway_indices = np.array([
            int(np.flatnonzero(self.ontology.pathways == name)[0])
            for name in pathway_names
        ])

        # Compute MI/CMI for these pathways
        self.information = self._calculate_information()

        # Set pathway_indices for enrichment calculation
        self.pathway_indices = pathway_indices

        # p-values and z-scores are NaN (no permutation testing)
        self.pvalues = np.full(self.num_pathways, np.nan)
        self.zscores = np.full(self.num_pathways, np.nan)

        # Hypergeometric enrichment
        self.overrep_pvals, self.underrep_pvals = self._calculate_enrichment()

        self.results = self._gather_results()
        self.hm = self._make_heatmap()

        return self.results, self.hm

    def get_enriched_genes(self, name) -> list:
        matches = np.flatnonzero(self.ontology.pathways == name)
        if matches.size == 0:
            raise ValueError(f"pathway not present: {name!r}")
        pathway_idx = matches[0]
        pathway_binary = self.ont_bool[pathway_idx]
        res = []
        for bin in set(self.exp_bins):
            genes_in_bin = self.shared_genes[np.where(pathway_binary & (self.exp_bins == bin))[0]]
            res.append(genes_in_bin)
        return res

    def get_es_matrix(self):
        """
        Returns the enrichment score matrix for each pathway and bin

        enrichment score is defined as the log10 of the hypergeometric p-value
        (overrepresented scores per bin are positive and underrepresented scores are negative)

        Returns
        =======
        pd.DataFrame
            A dataframe representing the results of the analysis as a matrix (rows are pathways and columns are bins)
        """
        hm = self._make_heatmap()
        return pd.DataFrame(
            hm._subset_and_sort_pathways()[1],
            index=hm._subset_and_sort_pathways()[0]
        )
