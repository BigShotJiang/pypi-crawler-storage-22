from subprocess import Popen, PIPE, run
import os.path
import tempfile
from bioleach.env import (
    BIOLEACH_READS_DIR,
    BIOLEACH_PHIX,
    BIOLEACH_PHIX_PREFIX
)
from bioleach.download import download_phix

# https://www.cell.com/cell-reports-methods/fulltext/S2667-2375(25)00254-1
# https://academic.oup.com/gigascience/article/doi/10.1093/gigascience/giaf004/8045180?login=false#506556268
# https://github.com/YunyunGao374/HostPurge/blob/main/0HostDecontaminationImpactiononDownstreamAnalysis.sh
# https://github.com/YunyunGao374/HostPurge/blob/main/1HostDecontaminationSoftwareComparison.sh
# https://github.com/YunyunGao374/HostPurge
# https://link.springer.com/article/10.1186/s12859-023-05492-w
# https://academic.oup.com/nargab/article/7/3/lqaf105/8211928?login=false
# https://github.com/rki-mf1/clean

def remove_contaminants_bbtools(in1, in2, out1, out2, threads: int = 1):
    """Use BBtools to remove phix contamination

    Parameters
    ----------
    in1, in2
        paired-end fastq input files
    out1, out2
        paried-end fastq output files
    threads: int
        number of threads to use
    """

    run((
        'bbduk.sh',
        f'in1={in1}',
        f'in2={in2}',
        f'out1={out1}',
        f'out2={out2}',
        f'threads={threads}',
        'ref=phix.fa',
        'k=31',
        'hdist=1',
        'stats=stats.txt'
    ))


def remove_contaminants_alignment(args, fastq_out_1, fastq_out_2):
    """Remove contaminants with an alignment-based method

    Parameters
    ----------
    args
        iterable of arguments defining the command line for the sequence aligner
    fastq_out_1, fastq_out_2
        destination for paired-end fastq output
    """

    with tempfile.TemporaryDirectory(dir=BIOLEACH_READS_DIR) as temp_dir:
        with Popen(args, stdout=PIPE) as aligner:
            run(('samtools', 'sort', '-O', 'bam', '-o', os.path.join(temp_dir, 'sort.bam')), stdin=aligner.stdout)
        run(('samtools', 'index', os.path.join(temp_dir, 'sort.bam')))
        with Popen(('samtools', 'view', '-b', '-f', '4', os.path.join(temp_dir, 'sort.bam')), stdout=PIPE) as view_unmapped:
            with Popen(('samtools', 'collate', '-u', '-O', '-'), stdin=view_unmapped.stdout, stdout=PIPE) as collate:
                run(('samtools', 'fastq', '-0', '/dev/null', '-s', '/dev/null', '-n', '-1', fastq_out_1, '-2', fastq_out_2), stdin=collate.stdout)


def remove_contaminants_bowtie2(
    fastq_in_1,
    fastq_in_2,
    fastq_out_1,
    fastq_out_2,
    local: bool = False,
    preset: str = 'very-fast',
    threads: int = 1
):
    if not os.path.exists(BIOLEACH_PHIX):
        download_phix()
    if not os.path.exists(f'{BIOLEACH_PHIX[:-2]}1.bt2'):
        run(('bowtie2-build', BIOLEACH_PHIX, BIOLEACH_PHIX_PREFIX))
    args = ('bowtie2', f'--{preset}', '--threads', str(threads), '-x', BIOLEACH_PHIX_PREFIX, '-1', fastq_in_1, '-2', fastq_in_2) + local * ('--local',)
    remove_contaminants_alignment(args, fastq_out_1, fastq_out_2)


def remove_contaminants_bwa(
    fastq_in_1, fastq_in_2,
    fastq_out_1, fastq_out_2,
    threads: int = 1
):
    if not os.path.exists(BIOLEACH_PHIX):
        download_phix()
    if not all(os.path.exists(f'{BIOLEACH_PHIX}.{ext}') for ext in ('amb', 'ann', 'bwt', 'pac', 'sa')):
        run(('bwa index', BIOLEACH_PHIX))
    args = ('bwa', 'mem', '-t', str(threads), BIOLEACH_PHIX, fastq_in_1, fastq_in_2)
    remove_contaminants_alignment(args, fastq_out_1, fastq_out_2)


def remove_contaminants_minimap2(
    fastq_in_1, fastq_in_2,
    fastq_out_1, fastq_out_2,
    threads: int = 1
):
    if not os.path.exists(BIOLEACH_PHIX):
        download_phix()
    args = ('minimap2', '-t', str(threads), '-ax', 'sr', BIOLEACH_PHIX, fastq_in_1, fastq_in_2)
    remove_contaminants_alignment(args, fastq_out_1, fastq_out_2)


def remove_contaminants(
        fastq_in_1, fastq_in_2,
        output_dir=BIOLEACH_READS_DIR,
        algorithm: str = 'bbtools',
        threads: int = 1
):
    """Remove contaminants
    """

    if algorithm == 'bbtools':
        remove_contaminants_bbtools(
            fastq_in_1,
            fastq_in_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_in_1)[:-11]}_clean_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_in_2)[:-11]}_clean_2.fq'),
            threads=threads
        )
    elif algorithm == 'bowtie2':
        remove_contaminants_bowtie2(
            fastq_in_1,
            fastq_in_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_in_1)[:-11]}_clean_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_in_2)[:-11]}_clean_2.fq'),
            threads=threads
        )
    elif algorithm == 'bwa':
        remove_contaminants_bwa(
            fastq_in_1,
            fastq_in_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_in_1)[:-11]}_clean_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_in_2)[:-11]}_clean_2.fq'),
            threads=threads
        )

