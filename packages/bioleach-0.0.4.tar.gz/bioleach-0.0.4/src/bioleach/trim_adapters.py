import os.path
from subprocess import run
from bioleach.env import BIOLEACH_READS_DIR

def trim_adapters_bbtools(in1, in2, out1, out2, threads: int = 1):
    """Use BBtools to trim adapters

    Parameters
    ----------
    in1, in2
        paired-end fastq input files
    out1, out2
        paried-end fastq output files
    """

    run((
        'bbduk.sh',
        f'in1={in1}',
        f'in2={in2}',
        f'out1={out1}',
        f'out2={out2}',
        f'threads={threads}',
        'ref=adapters',
        'ktrim=r',
        'k=23',
        'mink=11',
        'hdist=1',
        'tpe',
        'tbo'
    ))


def trim_adapters_trim_galore(fastq_1, fastq_2, output_dir, cores: int = 1):
    """Use trim-galore to trim adapters

    Parameters
    ----------
    fastq_1, fastq_2
        paired-end fastq input files
    output_dir
        output directory
    cores : int
        number of cores to use for adapter trimming
    """

    run((
        'trim_galore',
        '--paired',
        '--fastqc',
        '--output_dir', output_dir,
        '--cores', str(cores),
        fastq_1,
        fastq_2
    ))

def trim_adapters_trimmomatic(
        fastq_in_1,
        fastq_in_2,
        fastq_out_1_paired,
        fastq_out_1_unpaired,
        fastq_out_2_paired,
        fastq_out_2_unpaired,
        threads: int = 1
    ):
    """Use trimmomatic to trim adapters

    Parameters
    ----------
    fastq_in_1, fastq_in_2
        paired-end fastq input files
    fastq_out_1_paired,
        path to output fastq file (paired reads)
    fastq_out_1_unpaired,
        path to output fastq file (unpaired reads)
    fastq_out_2_paired,
        path to output fastq file (paired reads)
    fastq_out_2_unpaired,
        path to output fastq file (unpaired reads)
    threads : int
        number of threads for parallel processing
    """

    run((
        'trimmomatic', 'PE', '-threads', str(threads),
        fastq_in_1, fastq_in_2,
        fastq_out_1_paired,
        fastq_out_1_unpaired,
        fastq_out_2_paired,
        fastq_out_2_unpaired,
        'ILLUMINACLIP:TruSeq3-PE.fa:2:30:10:2:True',
        'LEADING:3',
        'TRAILING:3',
        'MINLEN:36'
    ))

def trim_adapters_fastp(
        fastq_in_1, fastq_in_2,
        fastq_out_1, fastq_out_2,
        threads: int = 1
    ):
    """Use fastp to trim adapters

    Parameters
    ----------
    fastq_in_1, fastq_in_2
        paired-end fastq output files
    fastq_out_1, fastq_out_2
        paired-end fastq output files
    threads : int
        number of threads for parallel processing
    """

    run((
        'fastp', '--thread', str(threads),
        '-i', fastq_in_1,
        '-I', fastq_in_2,
        '-o', fastq_out_1,
        '-O', fastq_out_2
    ))


def trim_adapters(
        fastq_1,
        fastq_2,
        output_dir=BIOLEACH_READS_DIR,
        algorithm: str = 'fastp',
        threads: int = 1
):
    """Use one of the available algorithms to trim adapters

    Parameters
    ----------
    fastq_1, fastq_2
        paired-end fastq input files
    output_dir
        output directory
    algorithm : str
        algorithm for adapter trimming, 'fastp', 'bbtools', 'trim-galore', or 'trimmomatic'
    threads : int
        number of cores to use for adapter trimming
    """

    if algorithm == 'fastp':
        trim_adapters_fastp(
            fastq_1,
            fastq_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_1)[:-6]}_val_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_2)[:-6]}_val_2.fq'),
            threads=threads
        )
    elif algorithm == 'bbtools':
        trim_adapters_bbtools(
            fastq_1,
            fastq_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_1)[:-6]}_val_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_2)[:-6]}_val_2.fq'),
            threads=threads
        )
    elif algorithm == 'trim-galore':
        trim_adapters_trim_galore(
                fastq_1,
                fastq_2,
                output_dir=output_dir,
                cores=threads
            )
    elif algorithm == 'trimmomatic':
        trim_adapters_trimmomatic(
            fastq_1,
            fastq_2,
            os.path.join(output_dir, f'{os.path.basename(fastq_1)[:-6]}_val_1.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_1)[:-6]}_val_1U.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_2)[:-6]}_val_2.fq'),
            os.path.join(output_dir, f'{os.path.basename(fastq_2)[:-6]}_val_2U.fq'),
            threads=threads
        )
    else:
        raise ValueError(f'Algorithm {algorithm} not available.')

