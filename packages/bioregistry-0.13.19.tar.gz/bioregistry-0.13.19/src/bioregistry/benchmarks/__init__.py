"""Benchmarks for the Bioregistry."""
