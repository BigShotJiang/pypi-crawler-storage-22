"""
Report modules for BioSynth.
"""
