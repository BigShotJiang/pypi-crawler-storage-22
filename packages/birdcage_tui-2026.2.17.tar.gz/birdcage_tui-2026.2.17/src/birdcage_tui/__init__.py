"""Birdcage TUI — Textual interface for Winegard satellite dish control."""
