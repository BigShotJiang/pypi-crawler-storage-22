"""Camera backend abstraction — capture images from USB/CSI cameras.

Wraps fswebcam/ffmpeg/libcamera-still via subprocess for zero-dependency
operation. DemoCamera generates placeholder frames without hardware.

No TUI dependency. All methods are blocking — designed for
@work(thread=True) workers in the TUI.
"""

import glob
import logging
import shutil
import struct
import subprocess
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger(__name__)


@dataclass
class CameraConfig:
    """Camera hardware and capture settings."""

    device: str = "/dev/video0"
    resolution: tuple[int, int] = (1280, 720)
    backend_cmd: str = "fswebcam"  # fswebcam | ffmpeg | libcamera-still
    extra_args: list[str] = field(default_factory=list)


@dataclass
class CaptureResult:
    """Outcome of a single capture attempt."""

    path: Path
    timestamp: str  # ISO-8601 UTC
    duration_ms: float
    success: bool
    error: str = ""


class CameraBackend(ABC):
    """Abstract camera backend. Subclasses wrap specific capture tools."""

    @abstractmethod
    def capture(self, output_path: Path) -> CaptureResult:
        """Capture a single frame to output_path. Blocking."""

    @abstractmethod
    def is_available(self) -> bool:
        """Check if the backend tool and device are accessible."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable backend identifier."""


class SubprocessCamera(CameraBackend):
    """Camera backend wrapping fswebcam/ffmpeg/libcamera-still.

    Each tool is invoked via subprocess.run() with a 10-second timeout.
    The caller provides the output path; the backend builds the command.
    """

    _COMMANDS: dict[str, list[str]] = {
        "fswebcam": [
            "fswebcam",
            "-r",
            "{width}x{height}",
            "--no-banner",
            "-d",
            "{device}",
            "{output}",
        ],
        "ffmpeg": [
            "ffmpeg",
            "-y",
            "-f",
            "v4l2",
            "-video_size",
            "{width}x{height}",
            "-i",
            "{device}",
            "-frames:v",
            "1",
            "{output}",
        ],
        "libcamera-still": [
            "libcamera-still",
            "--width",
            "{width}",
            "--height",
            "{height}",
            "-t",
            "1",
            "-o",
            "{output}",
        ],
    }

    def __init__(self, config: CameraConfig) -> None:
        self._config = config

    def capture(self, output_path: Path) -> CaptureResult:
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        t0 = time.monotonic()

        template = self._COMMANDS.get(self._config.backend_cmd)
        if template is None:
            return CaptureResult(
                path=output_path,
                timestamp=ts,
                duration_ms=0.0,
                success=False,
                error=f"Unknown backend: {self._config.backend_cmd}",
            )

        w, h = self._config.resolution
        cmd = [
            part.format(
                width=w,
                height=h,
                device=self._config.device,
                output=str(output_path),
            )
            for part in template
        ]
        cmd.extend(self._config.extra_args)

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=10,
                check=False,
            )
            elapsed = (time.monotonic() - t0) * 1000
            if result.returncode != 0:
                stderr = result.stderr.decode(errors="replace")[:200]
                return CaptureResult(
                    path=output_path,
                    timestamp=ts,
                    duration_ms=elapsed,
                    success=False,
                    error=f"Exit {result.returncode}: {stderr}",
                )
            return CaptureResult(
                path=output_path,
                timestamp=ts,
                duration_ms=elapsed,
                success=True,
            )
        except subprocess.TimeoutExpired:
            elapsed = (time.monotonic() - t0) * 1000
            return CaptureResult(
                path=output_path,
                timestamp=ts,
                duration_ms=elapsed,
                success=False,
                error="Capture timed out (10s)",
            )
        except FileNotFoundError:
            return CaptureResult(
                path=output_path,
                timestamp=ts,
                duration_ms=0.0,
                success=False,
                error=f"{self._config.backend_cmd} not found",
            )

    def is_available(self) -> bool:
        return shutil.which(self._config.backend_cmd) is not None

    @property
    def name(self) -> str:
        return f"{self._config.backend_cmd} ({self._config.device})"


class DemoCamera(CameraBackend):
    """Generates a minimal valid JPEG without external dependencies.

    When Pillow is available, renders a placeholder frame with a timestamp
    overlay. Otherwise creates a tiny valid JPEG (gray 1x1 pixel). Always
    available — used in --demo mode.
    """

    def __init__(self, resolution: tuple[int, int] = (1280, 720)) -> None:
        self._resolution = resolution

    def capture(self, output_path: Path) -> CaptureResult:
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        t0 = time.monotonic()

        try:
            self._write_frame(output_path, ts)
            elapsed = (time.monotonic() - t0) * 1000
            return CaptureResult(
                path=output_path,
                timestamp=ts,
                duration_ms=elapsed,
                success=True,
            )
        except Exception as exc:
            elapsed = (time.monotonic() - t0) * 1000
            return CaptureResult(
                path=output_path,
                timestamp=ts,
                duration_ms=elapsed,
                success=False,
                error=str(exc),
            )

    def _write_frame(self, output_path: Path, timestamp: str) -> None:
        """Try Pillow first, fall back to minimal JPEG."""
        try:
            from PIL import Image, ImageDraw

            w, h = self._resolution
            img = Image.new("RGB", (w, h), color=(14, 20, 32))
            draw = ImageDraw.Draw(img)
            draw.text((20, 20), "DEMO CAPTURE", fill=(0, 212, 170))
            draw.text((20, 50), timestamp, fill=(200, 208, 216))
            draw.text((20, 80), f"{w}x{h}", fill=(80, 104, 120))
            img.save(output_path, "JPEG", quality=85)
        except ImportError:
            self._write_minimal_jpeg(output_path)

    def _write_minimal_jpeg(self, output_path: Path) -> None:
        """Write a valid 1x1 gray JPEG (smallest possible valid file)."""
        # Minimal JFIF: SOI + APP0 + DQT + SOF0 + DHT + SOS + data + EOI
        # This is a pre-computed 1x1 gray pixel JPEG.
        data = bytes(
            [
                0xFF,
                0xD8,  # SOI
                0xFF,
                0xE0,  # APP0 (JFIF)
            ]
        )
        app0_payload = b"JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00"
        data += struct.pack(">H", len(app0_payload) + 2) + app0_payload

        # Quantization table (all 1s for simplicity)
        dqt = bytes([0xFF, 0xDB, 0x00, 0x43, 0x00]) + bytes([1] * 64)
        data += dqt

        # SOF0 (baseline, 1x1, 1 component, Y only)
        sof0 = bytes(
            [
                0xFF,
                0xC0,
                0x00,
                0x0B,
                0x08,
                0x00,
                0x01,
                0x00,
                0x01,  # height=1, width=1
                0x01,
                0x01,
                0x11,
                0x00,  # 1 component, sampling 1x1, quant table 0
            ]
        )
        data += sof0

        # DHT (minimal Huffman table for DC)
        dht = bytes(
            [
                0xFF,
                0xC4,
                0x00,
                0x1F,
                0x00,
                0x00,
                0x01,
                0x05,
                0x01,
                0x01,
                0x01,
                0x01,
                0x01,
                0x01,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x01,
                0x02,
                0x03,
                0x04,
                0x05,
                0x06,
                0x07,
                0x08,
                0x09,
                0x0A,
                0x0B,
            ]
        )
        data += dht

        # SOS + encoded data (gray pixel value 128)
        sos = bytes(
            [
                0xFF,
                0xDA,
                0x00,
                0x08,
                0x01,
                0x01,
                0x00,
                0x00,
                0x3F,
                0x00,
                0x7F,
                0x49,  # encoded pixel data
            ]
        )
        data += sos

        # EOI
        data += bytes([0xFF, 0xD9])

        output_path.write_bytes(data)

    def is_available(self) -> bool:
        return True

    @property
    def name(self) -> str:
        return "demo"


def detect_cameras() -> list[str]:
    """Discover available video capture devices."""
    devices = sorted(glob.glob("/dev/video*"))
    return devices


def auto_select_backend(config: CameraConfig) -> CameraBackend:
    """Pick the best available backend for the given config.

    Tries the configured backend first, then falls through alternatives.
    Falls back to DemoCamera if nothing is available.
    """
    # Try configured backend first
    candidate = SubprocessCamera(config)
    if candidate.is_available():
        log.info("Using %s backend", config.backend_cmd)
        return candidate

    # Try alternatives in preference order
    for alt_cmd in ("fswebcam", "ffmpeg", "libcamera-still"):
        if alt_cmd == config.backend_cmd:
            continue
        alt_config = CameraConfig(
            device=config.device,
            resolution=config.resolution,
            backend_cmd=alt_cmd,
        )
        alt = SubprocessCamera(alt_config)
        if alt.is_available():
            log.info("Falling back to %s backend", alt_cmd)
            return alt

    log.info("No camera backend available, using demo")
    return DemoCamera(config.resolution)
