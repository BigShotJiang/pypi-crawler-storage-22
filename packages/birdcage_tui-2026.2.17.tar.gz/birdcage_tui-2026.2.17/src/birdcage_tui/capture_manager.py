"""Capture orchestrator — coordinates camera backend + metadata + output files.

Thread-safe (internal lock). All methods blocking — designed for
@work(thread=True) workers. Writes JPEG + JSON sidecar always;
optionally adds EXIF (Pillow) and FITS (astropy) when available.
"""

import json
import logging
import re
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path

from birdcage_tui.camera import CameraBackend, CaptureResult

log = logging.getLogger(__name__)

# Optional dependencies — graceful degradation
try:
    from PIL import Image

    HAS_PILLOW = True
except ImportError:
    HAS_PILLOW = False

try:
    from astropy.io import fits as astropy_fits

    HAS_ASTROPY = True
except ImportError:
    HAS_ASTROPY = False

# Filename-safe character filter
_SAFE_RE = re.compile(r"[^a-zA-Z0-9_\-]")


@dataclass
class CaptureMetadata:
    """Everything we know about a capture at the moment the shutter fires."""

    # Timing
    timestamp: str = ""  # ISO-8601 UTC
    capture_duration_ms: float = 0.0

    # Mount position (actual dish position at capture time)
    mount_az: float = 0.0
    mount_el: float = 0.0

    # Target info (from active tracking, if any)
    target_name: str = ""
    target_type: str = ""  # satellite, planet, star, comet, ""
    target_id: str = ""
    target_az: float | None = None
    target_el: float | None = None
    target_distance_km: float | None = None
    target_range_rate: float | None = None

    # Context
    tracking_mode: str = "manual"  # manual, craft, rotctld
    tracking_status: str = ""  # TRACKING, WAITING, IDLE
    trigger: str = "manual"  # manual, interval, aos, tca, los

    # Sequence
    sequence_number: int = 0
    session_id: str = ""

    # Camera
    camera_backend: str = ""
    camera_device: str = ""
    resolution: tuple[int, int] = (0, 0)

    # Device
    firmware_version: str = ""


@dataclass
class CaptureSession:
    """Tracks a capture session with sequential numbering."""

    session_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    start_time: str = field(
        default_factory=lambda: time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    )
    capture_count: int = 0
    output_dir: Path = Path("captures")

    def next_sequence(self) -> int:
        self.capture_count += 1
        return self.capture_count


def _sanitize_name(name: str) -> str:
    """Make a target name filesystem-safe."""
    if not name:
        return "manual"
    cleaned = name.replace(" ", "-")
    cleaned = _SAFE_RE.sub("", cleaned)
    return cleaned[:40] or "capture"


def _build_filename(metadata: CaptureMetadata, ext: str) -> str:
    """Generate filename: {target}_{az:06.2f}_{el:05.2f}_{timestamp}.{ext}"""
    name = _sanitize_name(metadata.target_name)
    az = f"{metadata.mount_az:06.2f}"
    el = f"{metadata.mount_el:05.2f}"
    # Compact timestamp: 20260216T082500Z
    ts = metadata.timestamp.replace("-", "").replace(":", "").replace(" ", "")
    return f"{name}_{az}_{el}_{ts}.{ext}"


class CaptureManager:
    """Orchestrates capture → metadata → output pipeline.

    Usage:
        manager = CaptureManager(backend, output_dir=Path("captures"))
        result = manager.capture(metadata)  # blocking

    Output files per capture:
        - JPEG (always) — from camera backend
        - JSON sidecar (always) — full metadata
        - FITS (when astropy available) — with WCS headers
    """

    def __init__(
        self, backend: CameraBackend, output_dir: Path = Path("captures")
    ) -> None:
        self._backend = backend
        self._output_dir = output_dir
        self._session = CaptureSession(output_dir=output_dir)
        self._lock = threading.Lock()

    def capture(self, metadata: CaptureMetadata) -> CaptureResult:
        """Execute a full capture cycle. Blocking, thread-safe."""
        with self._lock:
            seq = self._session.next_sequence()

        metadata.sequence_number = seq
        metadata.session_id = self._session.session_id
        metadata.camera_backend = self._backend.name

        # Date-based subdirectory
        date_str = time.strftime("%Y-%m-%d", time.gmtime())
        capture_dir = self._output_dir / date_str
        capture_dir.mkdir(parents=True, exist_ok=True)

        # Capture the frame
        jpeg_name = _build_filename(metadata, "jpg")
        jpeg_path = capture_dir / jpeg_name

        result = self._backend.capture(jpeg_path)

        # Populate timing metadata from result
        metadata.timestamp = result.timestamp
        metadata.capture_duration_ms = result.duration_ms

        # Always write JSON sidecar
        self._write_json_sidecar(capture_dir, metadata)

        if result.success:
            # EXIF embedding (optional)
            if HAS_PILLOW:
                self._add_jpeg_exif(jpeg_path, metadata)

            # FITS output (optional)
            if HAS_ASTROPY:
                fits_name = _build_filename(metadata, "fits")
                fits_path = capture_dir / fits_name
                self._write_fits(jpeg_path, fits_path, metadata)

            log.info(
                "Capture #%d: %s (%.1fms)",
                seq,
                jpeg_name,
                result.duration_ms,
            )
        else:
            log.warning("Capture #%d failed: %s", seq, result.error)

        return result

    @property
    def session(self) -> CaptureSession:
        return self._session

    @property
    def has_pillow(self) -> bool:
        return HAS_PILLOW

    @property
    def has_astropy(self) -> bool:
        return HAS_ASTROPY

    def _write_json_sidecar(self, capture_dir: Path, metadata: CaptureMetadata) -> None:
        """Write metadata as a JSON sidecar file. Always succeeds or logs."""
        try:
            json_name = _build_filename(metadata, "json")
            json_path = capture_dir / json_name
            data = asdict(metadata)
            # Convert tuple to list for JSON serialization
            data["resolution"] = list(data["resolution"])
            json_path.write_text(json.dumps(data, indent=2, default=str))
        except Exception:
            log.exception("Failed to write JSON sidecar")

    def _add_jpeg_exif(self, jpeg_path: Path, metadata: CaptureMetadata) -> None:
        """Embed metadata into JPEG EXIF. Requires Pillow."""
        try:
            import piexif

            exif_dict = piexif.load(str(jpeg_path))
            # UserComment field for metadata
            comment = json.dumps(
                {
                    "mount_az": metadata.mount_az,
                    "mount_el": metadata.mount_el,
                    "target": metadata.target_name,
                    "trigger": metadata.trigger,
                    "session": metadata.session_id,
                }
            )
            exif_dict["Exif"][piexif.ExifIFD.UserComment] = (
                piexif.helper.UserComment.dump(comment, encoding="unicode")
            )
            exif_bytes = piexif.dump(exif_dict)
            piexif.insert(exif_bytes, str(jpeg_path))
        except Exception:
            # piexif not available or EXIF write failed — non-fatal
            log.debug("EXIF embedding skipped", exc_info=True)

    def _write_fits(
        self, jpeg_path: Path, fits_path: Path, metadata: CaptureMetadata
    ) -> None:
        """Write FITS file with WCS headers. Requires astropy."""
        try:
            if HAS_PILLOW:
                img = Image.open(jpeg_path)
                import numpy as np

                data = np.array(img)
            else:
                # Without Pillow, create a minimal FITS with no image data
                data = None

            hdu = astropy_fits.PrimaryHDU(data=data)
            hdr = hdu.header

            # Standard FITS keywords
            hdr["DATE-OBS"] = metadata.timestamp
            hdr["OBJECT"] = metadata.target_name or "MANUAL"
            hdr["TELESCOP"] = "Birdcage/Winegard"
            hdr["INSTRUME"] = metadata.camera_backend

            # WCS — AZ/EL tangent plane projection
            hdr["CTYPE1"] = "AZ---TAN"
            hdr["CTYPE2"] = "EL---TAN"
            hdr["CRVAL1"] = metadata.mount_az
            hdr["CRVAL2"] = metadata.mount_el
            hdr["CRPIX1"] = metadata.resolution[0] / 2 if metadata.resolution[0] else 1
            hdr["CRPIX2"] = metadata.resolution[1] / 2 if metadata.resolution[1] else 1

            # Custom headers
            hdr["MOUNT-AZ"] = (metadata.mount_az, "Mount azimuth (deg)")
            hdr["MOUNT-EL"] = (metadata.mount_el, "Mount elevation (deg)")
            hdr["TRIGGER"] = (metadata.trigger, "Capture trigger type")
            hdr["SEQNUM"] = (metadata.sequence_number, "Capture sequence number")
            hdr["SESSID"] = (metadata.session_id, "Capture session ID")

            if metadata.target_name:
                hdr["TGT-NAME"] = (metadata.target_name, "Target name")
                hdr["TGT-TYPE"] = (metadata.target_type, "Target type")
                hdr["TGT-ID"] = (metadata.target_id, "Target ID")
            if metadata.target_distance_km is not None:
                hdr["TGT-DIST"] = (metadata.target_distance_km, "Target distance (km)")
            if metadata.target_range_rate is not None:
                hdr["TGT-RATE"] = (
                    metadata.target_range_rate,
                    "Target range rate (km/s)",
                )

            hdu.writeto(str(fits_path), overwrite=True)
            log.debug("FITS written: %s", fits_path.name)
        except Exception:
            log.exception("Failed to write FITS file")
