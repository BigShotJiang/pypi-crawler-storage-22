"""Capture trigger system — manual, interval, and pass-event triggers.

Decoupled from TUI — operates on callbacks. The PassEventDetector is a
stateful edge detector: call update() from the tracking loop each iteration,
and it fires callbacks on AOS/TCA/LOS transitions.

IntervalTimer runs a daemon thread that fires at configurable intervals.
"""

import logging
import threading
import time
from enum import Enum, auto

log = logging.getLogger(__name__)


class TriggerType(Enum):
    """Types of capture triggers."""

    MANUAL = auto()
    INTERVAL = auto()
    AOS = auto()  # Acquisition of Signal: WAITING/IDLE -> TRACKING
    TCA = auto()  # Time of Closest Approach: elevation peak during TRACKING
    LOS = auto()  # Loss of Signal: TRACKING -> WAITING/IDLE


class TriggerEvent:
    """A trigger event with type, timestamp, and optional detail."""

    __slots__ = ("trigger_type", "timestamp", "detail")

    def __init__(
        self,
        trigger_type: TriggerType,
        timestamp: str = "",
        detail: str = "",
    ) -> None:
        self.trigger_type = trigger_type
        self.timestamp = timestamp or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.detail = detail


class IntervalTimer:
    """Background thread that fires a callback every N seconds.

    Thread-safe start/stop/pause. Daemon thread — doesn't block shutdown.
    """

    def __init__(
        self,
        callback: "callable",
        interval_seconds: float = 10.0,
    ) -> None:
        self._callback = callback
        self._interval = interval_seconds
        self._running = False
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()

    def start(self) -> None:
        """Start firing at the configured interval."""
        if self._running:
            return
        self._running = True
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop,
            name="capture-interval",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        """Stop the timer. Safe to call multiple times."""
        self._running = False
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None

    def set_interval(self, seconds: float) -> None:
        """Update the interval. Takes effect on the next cycle."""
        self._interval = max(1.0, seconds)

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def interval(self) -> float:
        return self._interval

    def _loop(self) -> None:
        while self._running and not self._stop_event.is_set():
            self._stop_event.wait(self._interval)
            if not self._running:
                break
            try:
                event = TriggerEvent(
                    trigger_type=TriggerType.INTERVAL,
                    detail=f"interval={self._interval:.0f}s",
                )
                self._callback(event)
            except Exception:
                log.exception("Interval trigger callback failed")


class PassEventDetector:
    """Stateful edge detector for satellite pass events.

    Call update() each tracking iteration with the current status, target
    name, and elevation. The detector fires callbacks on state transitions:

    - AOS: status transitions from WAITING/IDLE to TRACKING
    - LOS: status transitions from TRACKING to WAITING/IDLE
    - TCA: during TRACKING, elevation stops ascending and drops by >0.5 deg
            from the observed peak (hysteresis prevents jitter false triggers)

    The detector tracks per-target state and resets on target change.
    """

    # Minimum elevation drop from peak before we fire TCA (hysteresis)
    TCA_HYSTERESIS_DEG = 0.5

    def __init__(self, on_event: "callable") -> None:
        self._on_event = on_event
        self._enabled: set[TriggerType] = set()
        self._prev_status: str = ""
        self._prev_target: str = ""
        self._peak_el: float = -90.0
        self._tca_fired: bool = False

    def enable(self, *trigger_types: TriggerType) -> None:
        """Enable one or more trigger types."""
        for tt in trigger_types:
            self._enabled.add(tt)

    def disable(self, *trigger_types: TriggerType) -> None:
        """Disable one or more trigger types."""
        for tt in trigger_types:
            self._enabled.discard(tt)

    def is_enabled(self, trigger_type: TriggerType) -> bool:
        return trigger_type in self._enabled

    def update(self, status: str, target_name: str, elevation: float) -> None:
        """Feed current tracking state. Call each iteration (~1 Hz)."""
        # Reset on target change
        if target_name != self._prev_target:
            self._peak_el = -90.0
            self._tca_fired = False
            self._prev_status = ""
            self._prev_target = target_name

        # AOS detection: non-tracking -> TRACKING
        if (
            TriggerType.AOS in self._enabled
            and status == "TRACKING"
            and self._prev_status in ("WAITING", "IDLE", "")
        ):
            self._fire(
                TriggerType.AOS,
                f"AOS: {target_name} at EL {elevation:.1f}\u00b0",
            )
            self._peak_el = elevation
            self._tca_fired = False

        # LOS detection: TRACKING -> non-tracking
        if (
            TriggerType.LOS in self._enabled
            and self._prev_status == "TRACKING"
            and status in ("WAITING", "IDLE")
        ):
            self._fire(
                TriggerType.LOS,
                f"LOS: {target_name} at EL {elevation:.1f}\u00b0",
            )

        # TCA detection: elevation peak with hysteresis
        if status == "TRACKING":
            if elevation > self._peak_el:
                self._peak_el = elevation
                self._tca_fired = False
            elif (
                TriggerType.TCA in self._enabled
                and not self._tca_fired
                and (self._peak_el - elevation) > self.TCA_HYSTERESIS_DEG
            ):
                self._fire(
                    TriggerType.TCA,
                    f"TCA: {target_name} peak EL {self._peak_el:.1f}\u00b0",
                )
                self._tca_fired = True

        self._prev_status = status

    def reset(self) -> None:
        """Reset all state. Call when tracking stops."""
        self._prev_status = ""
        self._prev_target = ""
        self._peak_el = -90.0
        self._tca_fired = False

    def _fire(self, trigger_type: TriggerType, detail: str) -> None:
        """Dispatch a trigger event."""
        try:
            event = TriggerEvent(trigger_type=trigger_type, detail=detail)
            self._on_event(event)
            log.info("Pass event: %s — %s", trigger_type.name, detail)
        except Exception:
            log.exception("Pass event callback failed for %s", trigger_type.name)
