"""TUI screen modules — one per F-key mode."""
