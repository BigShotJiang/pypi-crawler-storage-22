"""Camera capture overlay — F6 slide-up modal for image acquisition.

Follows the ConsoleOverlay pattern: ModalScreen pushed via F6, dismissed
via Escape or F6 again. Pre-installed via install_screen() for persistence.

Provides manual capture, interval timer, and AOS/TCA/LOS pass-event
triggers. Each capture writes JPEG + JSON sidecar (+ optional FITS).
"""

import logging
import time

from textual import work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Button, Input, RichLog, Static

from birdcage_tui.camera import CaptureResult
from birdcage_tui.capture_manager import CaptureManager, CaptureMetadata
from birdcage_tui.capture_triggers import (
    IntervalTimer,
    PassEventDetector,
    TriggerEvent,
    TriggerType,
)

log = logging.getLogger(__name__)

# Map trigger types to display colors (Rich markup)
_TRIGGER_COLORS: dict[TriggerType, str] = {
    TriggerType.MANUAL: "#00d4aa",
    TriggerType.INTERVAL: "#00b8c8",
    TriggerType.AOS: "#00e060",
    TriggerType.TCA: "#e8c020",
    TriggerType.LOS: "#e04040",
}


class CaptureStatusPanel(Static):
    """Top status bar showing camera state, capture count, and formats."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._camera_name = "none"
        self._capture_count = 0
        self._last_capture = ""
        self._formats = "JPEG + JSON"
        self._triggers_text = "none"
        self._auto_interval = 0.0

    def update_status(
        self,
        camera_name: str = "",
        capture_count: int = 0,
        last_capture: str = "",
        formats: str = "",
        triggers_text: str = "",
        auto_interval: float = 0.0,
    ) -> None:
        if camera_name:
            self._camera_name = camera_name
        self._capture_count = capture_count
        if last_capture:
            self._last_capture = last_capture
        if formats:
            self._formats = formats
        if triggers_text:
            self._triggers_text = triggers_text
        self._auto_interval = auto_interval
        self._refresh_display()

    def _refresh_display(self) -> None:
        last = self._last_capture or "---"
        auto = f"  Auto: {self._auto_interval:.0f}s" if self._auto_interval > 0 else ""
        self.update(
            f"  Camera: {self._camera_name}  |  "
            f"Captures: {self._capture_count}  |  "
            f"Last: {last}\n"
            f"  Formats: {self._formats}  |  "
            f"Triggers: {self._triggers_text}{auto}"
        )


class CameraOverlay(ModalScreen):
    """F6: Camera capture overlay as a slide-up panel.

    Slides up from the bottom of the terminal, taking ~45% of the viewport.
    Provides manual capture, interval timer, and pass-event trigger controls.
    """

    BINDINGS = [
        Binding("escape", "dismiss_overlay", "Close", priority=True),
        Binding("f6", "dismiss_overlay", "Close", priority=True),
        Binding("c", "manual_capture", "Capture", priority=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._capture_manager: CaptureManager | None = None
        self._interval_timer: IntervalTimer | None = None
        self._pass_detector: PassEventDetector | None = None
        self._auto_running = False

    def compose(self) -> ComposeResult:
        with Container(id="camera-overlay"):
            yield CaptureStatusPanel(id="capture-status")
            yield RichLog(id="capture-log", markup=True, wrap=True)
            with Horizontal(classes="camera-controls"):
                yield Button("Capture", id="btn-capture", variant="primary")
                yield Static("Interval:", classes="label")
                yield Input(
                    value="10",
                    id="camera-interval-input",
                    type="integer",
                )
                yield Static("s", classes="label")
                yield Button("Start", id="btn-auto-start")
                yield Button("Stop", id="btn-auto-stop")
            with Horizontal(classes="camera-trigger-bar"):
                yield Static("Triggers:", classes="label")
                yield Button("AOS", id="btn-trigger-aos", classes="trigger-btn")
                yield Button("TCA", id="btn-trigger-tca", classes="trigger-btn")
                yield Button("LOS", id="btn-trigger-los", classes="trigger-btn")
                yield Static("  Cam:", classes="label")
                yield Static("---", id="camera-backend-label")

    def on_mount(self) -> None:
        """Initialize camera system on first mount."""
        self._setup_camera()

    def on_screen_resume(self) -> None:
        """Refresh status when the overlay is re-opened."""
        self._refresh_status()

    def action_dismiss_overlay(self) -> None:
        self.dismiss()

    # ------------------------------------------------------------------
    # Camera setup
    # ------------------------------------------------------------------

    def _setup_camera(self) -> None:
        """Initialize camera backend and capture manager."""
        from pathlib import Path

        from birdcage_tui.camera import CameraConfig, auto_select_backend

        capture_dir = getattr(self.app, "capture_dir", "captures")
        camera_device = getattr(self.app, "camera_device", "auto")

        config = CameraConfig()
        if camera_device != "auto":
            config.device = camera_device

        # In demo mode, always use the demo camera
        is_demo = getattr(self.app, "demo_mode", False)
        if is_demo:
            from birdcage_tui.camera import DemoCamera

            backend = DemoCamera(config.resolution)
        else:
            backend = auto_select_backend(config)

        output_dir = Path(capture_dir)
        self._capture_manager = CaptureManager(backend, output_dir)

        # Set up interval timer
        self._interval_timer = IntervalTimer(
            callback=self._on_interval_trigger,
            interval_seconds=10.0,
        )

        # Set up pass event detector (shared at app level)
        self._pass_detector = getattr(self.app, "_pass_detector", None)
        if self._pass_detector is None:
            self._pass_detector = PassEventDetector(
                on_event=self._on_pass_trigger,
            )
            # Store at app level so control.py can feed it
            self.app._pass_detector = self._pass_detector

        self._refresh_status()

        # Update backend label
        try:
            label = self.query_one("#camera-backend-label", Static)
            label.update(backend.name)
        except Exception:
            pass

        # Log welcome
        capture_log = self.query_one("#capture-log", RichLog)
        capture_log.write(f"[#506878]Camera ready: {backend.name}[/]")
        formats = self._format_list()
        capture_log.write(f"[#506878]Output: {formats}[/]")

    # ------------------------------------------------------------------
    # Manual capture
    # ------------------------------------------------------------------

    def action_manual_capture(self) -> None:
        """Trigger a manual capture via keyboard shortcut."""
        self._do_capture(TriggerType.MANUAL)

    # ------------------------------------------------------------------
    # Capture execution
    # ------------------------------------------------------------------

    @work(thread=True)
    def _do_capture(self, trigger_type: TriggerType) -> None:
        """Execute a capture in a worker thread."""
        if self._capture_manager is None:
            return

        metadata = self._collect_metadata(trigger_type)
        result = self._capture_manager.capture(metadata)
        self.app.call_from_thread(self._on_capture_complete, result, metadata)

    def _collect_metadata(self, trigger_type: TriggerType) -> CaptureMetadata:
        """Snapshot current app state into capture metadata."""
        meta = CaptureMetadata(
            mount_az=getattr(self.app, "_current_az", 0.0),
            mount_el=getattr(self.app, "_current_el", 0.0),
            trigger=trigger_type.name.lower(),
        )

        # Try to get tracking info from the Craft tracking state
        try:
            control = self.app.query_one("#control")
            if hasattr(control, "_craft_state") and control._craft_tracking:
                state = control._craft_state
                meta.target_name = state.target_name
                meta.target_az = state.azimuth
                meta.target_el = state.elevation
                meta.target_distance_km = state.distance_km
                meta.target_range_rate = state.range_rate
                meta.tracking_mode = "craft"
                meta.tracking_status = state.status
                meta.target_type = getattr(control, "_craft_target_type", "")
                meta.target_id = getattr(control, "_craft_target_id", "")
        except Exception:
            pass

        # Camera info
        if self._capture_manager:
            meta.camera_backend = self._capture_manager._backend.name
            mgr = self._capture_manager
            meta.resolution = (
                getattr(mgr._backend, "_resolution", (0, 0))
                if hasattr(mgr._backend, "_resolution")
                else (0, 0)
            )

        return meta

    def _on_capture_complete(
        self, result: CaptureResult, metadata: CaptureMetadata
    ) -> None:
        """Update UI after capture completes (main thread)."""
        capture_log = self.query_one("#capture-log", RichLog)
        ts = time.strftime("%H:%M:%S", time.gmtime())
        trigger_name = metadata.trigger.upper()
        color = (
            _TRIGGER_COLORS.get(TriggerType[trigger_name], "#506878")
            if trigger_name in TriggerType.__members__
            else "#506878"
        )

        if result.success:
            name = result.path.name
            if len(name) > 45:
                name = name[:42] + "..."
            capture_log.write(
                f"[{color}][{ts}] {trigger_name:<8}[/] "
                f"[#c8d0d8]{name}[/]  "
                f"[#506878]{result.duration_ms:.0f}ms[/]"
            )
        else:
            capture_log.write(
                f"[{color}][{ts}] {trigger_name:<8}[/] "
                f"[#e04040]FAILED: {result.error}[/]"
            )

        self._refresh_status()

    # ------------------------------------------------------------------
    # Interval timer
    # ------------------------------------------------------------------

    def _on_interval_trigger(self, event: TriggerEvent) -> None:
        """Called from the interval timer thread."""
        self.app.call_from_thread(self._do_capture, TriggerType.INTERVAL)

    def _start_auto(self) -> None:
        """Start the interval timer."""
        if self._interval_timer is None or self._auto_running:
            return

        try:
            interval_input = self.query_one("#camera-interval-input", Input)
            seconds = float(interval_input.value)
            if seconds < 1:
                seconds = 1
            self._interval_timer.set_interval(seconds)
        except (ValueError, Exception):
            self._interval_timer.set_interval(10.0)

        self._interval_timer.start()
        self._auto_running = True
        self._refresh_status()

        capture_log = self.query_one("#capture-log", RichLog)
        interval = self._interval_timer.interval
        capture_log.write(f"[#00b8c8]Auto-capture started ({interval:.0f}s)[/]")

    def _stop_auto(self) -> None:
        """Stop the interval timer."""
        if self._interval_timer is None or not self._auto_running:
            return

        self._interval_timer.stop()
        self._auto_running = False
        self._refresh_status()

        capture_log = self.query_one("#capture-log", RichLog)
        capture_log.write("[#506878]Auto-capture stopped[/]")

    # ------------------------------------------------------------------
    # Pass event triggers
    # ------------------------------------------------------------------

    def _on_pass_trigger(self, event: TriggerEvent) -> None:
        """Called from the tracking loop thread via PassEventDetector."""
        self.app.call_from_thread(self._do_capture, event.trigger_type)

    def _toggle_trigger(self, trigger_type: TriggerType, button: Button) -> None:
        """Toggle a pass event trigger on/off."""
        if self._pass_detector is None:
            return

        if self._pass_detector.is_enabled(trigger_type):
            self._pass_detector.disable(trigger_type)
            button.remove_class("active")
        else:
            self._pass_detector.enable(trigger_type)
            button.add_class("active")

        self._refresh_status()

    # ------------------------------------------------------------------
    # Button handlers
    # ------------------------------------------------------------------

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""

        if button_id == "btn-capture":
            self._do_capture(TriggerType.MANUAL)
        elif button_id == "btn-auto-start":
            self._start_auto()
        elif button_id == "btn-auto-stop":
            self._stop_auto()
        elif button_id == "btn-trigger-aos":
            self._toggle_trigger(TriggerType.AOS, event.button)
        elif button_id == "btn-trigger-tca":
            self._toggle_trigger(TriggerType.TCA, event.button)
        elif button_id == "btn-trigger-los":
            self._toggle_trigger(TriggerType.LOS, event.button)

    # ------------------------------------------------------------------
    # Status helpers
    # ------------------------------------------------------------------

    def _refresh_status(self) -> None:
        """Update the status panel with current state."""
        try:
            panel = self.query_one("#capture-status", CaptureStatusPanel)
        except Exception:
            return

        if self._capture_manager is None:
            return

        session = self._capture_manager.session
        formats = self._format_list()

        triggers = []
        if self._pass_detector:
            for tt in (TriggerType.AOS, TriggerType.TCA, TriggerType.LOS):
                if self._pass_detector.is_enabled(tt):
                    triggers.append(tt.name)
        triggers_text = " ".join(triggers) if triggers else "none"

        auto_interval = self._interval_timer.interval if self._auto_running else 0.0

        panel.update_status(
            camera_name=(
                self._capture_manager._backend.name if self._capture_manager else "none"
            ),
            capture_count=session.capture_count,
            last_capture="",
            formats=formats,
            triggers_text=triggers_text,
            auto_interval=auto_interval,
        )

    def _format_list(self) -> str:
        """Build a string describing available output formats."""
        parts = ["JPEG", "JSON"]
        if self._capture_manager:
            if self._capture_manager.has_pillow:
                parts.append("EXIF")
            if self._capture_manager.has_astropy:
                parts.append("FITS")
        return " + ".join(parts)

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def on_unmount(self) -> None:
        """Stop timers on teardown."""
        if self._interval_timer:
            self._interval_timer.stop()
