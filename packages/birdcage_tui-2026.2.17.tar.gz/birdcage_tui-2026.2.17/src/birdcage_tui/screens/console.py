"""Console overlay -- raw serial terminal as a slide-up ModalScreen.

Pushed via F5, dismissed via Escape or F5 again. Preserves command
history across open/close cycles when installed via install_screen().
"""

import re

from textual import work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.events import Key
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Static

from birdcage_tui.widgets.serial_log import SerialLog

_KNOWN_PROMPTS = [
    "TRK>",
    "MOT>",
    "DVB>",
    "NVS>",
    "A3981>",
    "ADC>",
    "OS>",
    "STEP>",
    "PEAK>",
    "EE>",
    "GPIO>",
    "LATLON>",
    "DIPSWITCH>",
]

# Pattern to detect NVS write commands.
_NVS_WRITE_RE = re.compile(r"e\s+\d+\s+\S+")


def _detect_prompt(text: str) -> str | None:
    """Find the last known prompt in the response text."""
    last_prompt = None
    last_pos = -1
    for prompt in _KNOWN_PROMPTS:
        pos = text.rfind(prompt)
        if pos > last_pos:
            last_pos = pos
            last_prompt = prompt
    return last_prompt


class ConsoleOverlay(ModalScreen):
    """F5: Raw serial console as a slide-up overlay.

    Slides up from the bottom of the terminal, taking ~50% of the viewport.
    The active screen remains visible (dimmed) above. Dismissed by Escape or F5.
    """

    BINDINGS = [
        Binding("escape", "dismiss_overlay", "Close", priority=True),
        Binding("f5", "dismiss_overlay", "Close", priority=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._command_history: list[str] = []
        self._history_idx: int = 0
        self._cmd_count: int = 0
        self._prompt_ctx: str = "TRK>"
        self._last_dangerous_cmd: str | None = None
        self._welcomed = False

    def compose(self) -> ComposeResult:
        with Container(id="console-overlay"):
            yield SerialLog(id="serial-log")
            with Horizontal(classes="console-context"):
                yield Static("Context: TRK>", id="console-context")
                yield Static("  Commands: 0", id="console-cmd-count")
            with Horizontal(classes="console-input-area"):
                yield Static("> ", classes="label")
                yield Input(placeholder="Enter command...", id="console-input")
                yield Button("Send", id="btn-send", variant="primary")

    def on_mount(self) -> None:
        """Show welcome message on first mount."""
        if not self._welcomed:
            self._show_welcome()
            self._welcomed = True
        self.query_one("#console-input", Input).focus()

    def on_screen_resume(self) -> None:
        """Re-focus input when the overlay is re-opened."""
        self.query_one("#console-input", Input).focus()

    def _show_welcome(self) -> None:
        """Display connection info in the serial log."""
        serial_log = self.query_one("#serial-log", SerialLog)
        device = self.app.device if hasattr(self.app, "device") else None

        if device is not None:
            is_demo = type(device).__name__ == "DemoDevice"
            mode_label = "DEMO" if is_demo else "Live"
        else:
            mode_label = "No device"

        port = getattr(self.app, "serial_port", "---")

        serial_log.append_output("Birdcage Console -- type ? for help")
        serial_log.append_output(f"Connected to: {mode_label} / {port}")

    def action_dismiss_overlay(self) -> None:
        """Close the console overlay."""
        self.dismiss()

    # ------------------------------------------------------------------
    # Safety checks
    # ------------------------------------------------------------------

    def _check_dangerous(self, cmd: str) -> str | None:
        """Return a warning if the command is dangerous, or None if safe."""
        stripped = cmd.strip()
        lower = stripped.lower()

        # Same dangerous command repeated -- user is insisting.
        is_repeat = (
            self._last_dangerous_cmd is not None
            and stripped == self._last_dangerous_cmd
        )
        if is_repeat:
            self._last_dangerous_cmd = None
            return None

        warning = None

        if lower == "q" and self._prompt_ctx == "TRK>":
            warning = (
                "Warning: 'q' at root kills the shell! "
                "Use submenu-level 'q' to exit submenus."
            )
        elif lower == "reboot":
            warning = "Warning: 'reboot' will restart the dish firmware."
        elif _NVS_WRITE_RE.search(lower):
            warning = "Warning: NVS write detected. Are you sure?"

        if warning is not None:
            self._last_dangerous_cmd = stripped
        else:
            self._last_dangerous_cmd = None

        return warning

    # ------------------------------------------------------------------
    # Command dispatch
    # ------------------------------------------------------------------

    def _do_send(self, cmd_text: str) -> None:
        """Validate and dispatch a command."""
        cmd_text = cmd_text.strip()
        if not cmd_text:
            return

        # Safety gate.
        warning = self._check_dangerous(cmd_text)
        if warning is not None:
            self.notify(warning, severity="warning", timeout=5)
            return

        # Record in history.
        self._command_history.append(cmd_text)
        self._history_idx = len(self._command_history)

        # Show the command in the log immediately.
        serial_log = self.query_one("#serial-log", SerialLog)
        serial_log.append_command(cmd_text)

        # Clear input.
        self.query_one("#console-input", Input).value = ""

        # Dispatch to worker thread.
        self._send_command(cmd_text)

    @work(thread=True)
    def _send_command(self, cmd: str) -> None:
        """Send the command over serial and update the UI with the response."""
        device = self.app.device if hasattr(self.app, "device") else None
        if device is None:
            self.app.call_from_thread(
                self.notify, "No device connected", severity="error"
            )
            return

        try:
            response = device.send_raw(cmd)
        except Exception as exc:
            self.app.call_from_thread(self._on_response, f"ERROR: {exc}", cmd)
            return

        self.app.call_from_thread(self._on_response, response, cmd)

    def _on_response(self, response: str, cmd: str) -> None:
        """Process the firmware response on the main thread."""
        serial_log = self.query_one("#serial-log", SerialLog)
        serial_log.append_output(response)

        # Detect prompt context from the response.
        detected = _detect_prompt(response)
        if detected is not None:
            self._prompt_ctx = detected
            ctx_label = self.query_one("#console-context", Static)
            ctx_label.update(f"Context: {self._prompt_ctx}")

            # Update the app-level StatusStrip menu indicator
            from birdcage_tui.widgets.status_strip import StatusStrip

            try:
                strip = self.app.query_one("#status-strip", StatusStrip)
                strip.fw_menu = self._prompt_ctx
            except Exception:
                pass

        # Update command count.
        self._cmd_count += 1
        count_label = self.query_one("#console-cmd-count", Static)
        count_label.update(f"  Commands: {self._cmd_count}")

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle Enter key in the command input."""
        if event.input.id == "console-input":
            self._do_send(event.value)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle the Send button click."""
        if event.button.id == "btn-send":
            cmd_input = self.query_one("#console-input", Input)
            self._do_send(cmd_input.value)

    def on_key(self, event: Key) -> None:
        """Handle up/down arrow keys for command history navigation."""
        cmd_input = self.query_one("#console-input", Input)

        if not cmd_input.has_focus:
            return

        if event.key == "up":
            event.prevent_default()
            event.stop()
            if not self._command_history:
                return
            self._history_idx = max(0, self._history_idx - 1)
            cmd_input.value = self._command_history[self._history_idx]
            cmd_input.cursor_position = len(cmd_input.value)

        elif event.key == "down":
            event.prevent_default()
            event.stop()
            if not self._command_history:
                return
            self._history_idx = min(len(self._command_history), self._history_idx + 1)
            if self._history_idx >= len(self._command_history):
                cmd_input.value = ""
            else:
                cmd_input.value = self._command_history[self._history_idx]
                cmd_input.cursor_position = len(cmd_input.value)

        elif event.key == "ctrl+l":
            event.prevent_default()
            event.stop()
            serial_log = self.query_one("#serial-log", SerialLog)
            serial_log.clear()
