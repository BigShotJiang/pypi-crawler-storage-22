"""F2 Control screen -- Point My Dish with Manual, Presets, and Track sub-modes.

Three-mode layout driven by a ModeBar and ContentSwitcher. Manual mode provides
compass rose, motor status, sparklines, and move/home/engage controls. Presets
mode manages saved AZ/EL targets. Track mode wraps the rotctld server lifecycle.
"""

import contextlib
import logging
import threading

from birdcage.craft_client import CraftClient, CraftTrackingState
from textual import work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import Button, ContentSwitcher, Input, Static
from textual.worker import Worker

from birdcage_tui.rotctld_server import TrackingState, TuiRotctldServer
from birdcage_tui.widgets.compass_rose import CompassRose
from birdcage_tui.widgets.craft_panel import CraftPanel
from birdcage_tui.widgets.mode_bar import ModeBar
from birdcage_tui.widgets.motor_status import MotorStatus
from birdcage_tui.widgets.preset_list import PresetList
from birdcage_tui.widgets.sparkline_widget import SparklineWidget
from birdcage_tui.widgets.tracking_panel import TrackingPanel

log = logging.getLogger(__name__)


class ControlScreen(Container):
    """F2: Point My Dish -- Manual / Presets / Track sub-modes."""

    can_focus = True

    BINDINGS = [
        Binding("left", "nudge_az(-1)", "AZ -1", show=False),
        Binding("right", "nudge_az(1)", "AZ +1", show=False),
        Binding("up", "nudge_el(1)", "EL +1", show=False),
        Binding("down", "nudge_el(-1)", "EL -1", show=False),
        Binding("h", "home_both", "Home Both", show=False),
        Binding("e", "engage_motors", "Engage", show=False),
        Binding("r", "release_motors", "Release", show=False),
    ]

    # Available step sizes for the nudge selector (degrees).
    STEP_SIZES: list[float] = [0.1, 0.5, 1.0, 5.0, 10.0]

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._device: object = None
        self._polling = False
        self._engaged = False
        self._poll_worker: Worker | None = None
        self._last_az = 180.0
        self._last_el = 45.0
        self._step_size: float = 1.0
        self._rotctld_server: TuiRotctldServer | None = None
        self._rotctld_thread: threading.Thread | None = None
        # Craft tracking state
        self._craft_client: CraftClient | None = None
        self._craft_tracking: bool = False
        self._craft_state: CraftTrackingState = CraftTrackingState()
        self._craft_target_type: str = ""
        self._craft_target_id: str = ""

    # ------------------------------------------------------------------
    # Compose
    # ------------------------------------------------------------------

    def compose(self) -> ComposeResult:
        with Container(classes="screen-container"):
            yield ModeBar(
                modes={
                    "manual": "Manual",
                    "presets": "Presets",
                    "track": "Track",
                    "craft": "Craft",
                },
                initial="manual",
                classes="mode-bar",
            )
            with ContentSwitcher(id="control-modes", initial="manual"):
                # -- Manual mode --
                with Container(id="manual"):
                    with Horizontal(classes="top-row"):
                        yield CompassRose(id="ctrl-compass")
                        with Vertical(classes="panel"):
                            yield Static("Motor Status", classes="panel-title")
                            yield MotorStatus(id="ctrl-motor-status")
                    with Vertical():
                        yield SparklineWidget(
                            max_points=80,
                            label="AZ",
                            color="#00d4aa",
                            id="ctrl-az-spark",
                        )
                        yield SparklineWidget(
                            max_points=80,
                            label="EL",
                            color="#00b8c8",
                            id="ctrl-el-spark",
                        )
                    with Horizontal(classes="bottom-controls"):
                        yield Static("AZ ", classes="label")
                        yield Input(
                            placeholder="180.0",
                            id="ctrl-az-input",
                            type="number",
                        )
                        yield Static(" EL ", classes="label")
                        yield Input(
                            placeholder="45.0",
                            id="ctrl-el-input",
                            type="number",
                        )
                        yield Button("Move", id="btn-ctrl-move", variant="primary")
                    with Horizontal(classes="velocity-controls"):
                        yield Static("AZ Vel ", classes="label")
                        yield Input(
                            placeholder="65.0",
                            id="ctrl-az-vel",
                            type="number",
                        )
                        yield Static(" EL Vel ", classes="label")
                        yield Input(
                            placeholder="45.0",
                            id="ctrl-el-vel",
                            type="number",
                        )
                        yield Button("Apply", id="btn-ctrl-apply-vel")
                    with Horizontal(classes="step-size-bar"):
                        yield Static("Step ", classes="label")
                        for size in self.STEP_SIZES:
                            label = f"{size}°" if size >= 1 else f"{size:.1f}°"
                            btn_id = f"btn-step-{str(size).replace('.', '_')}"
                            classes = "step-btn selected" if size == 1.0 else "step-btn"
                            yield Button(label, id=btn_id, classes=classes)
                    with Horizontal(classes="bottom-controls"):
                        yield Button("Home AZ", id="btn-ctrl-home-az")
                        yield Button("Home EL", id="btn-ctrl-home-el")
                        yield Button("E/R", id="btn-ctrl-engage")

                # -- Presets mode --
                with Container(id="presets"), Horizontal(classes="top-row"):
                    yield PresetList(id="ctrl-preset-list")
                    with Vertical(classes="panel"):
                        yield Static("Current Position", classes="panel-title")
                        yield CompassRose(id="ctrl-preset-compass")

                # -- Track mode --
                with Container(id="track"), Vertical(classes="panel"):
                    yield Static("Satellite Tracking", classes="panel-title")
                    yield TrackingPanel(id="ctrl-tracking-panel")

                # -- Craft mode --
                with Container(id="craft"), Vertical(classes="panel"):
                    yield Static("Craft Tracking", classes="panel-title")
                    yield CraftPanel(id="ctrl-craft-panel")

    # ------------------------------------------------------------------
    # Device lifecycle
    # ------------------------------------------------------------------

    def set_device(self, device: object) -> None:
        """Store the device reference and start the data poll."""
        self._device = device
        self._start_data_poll()
        self._load_motor_dynamics()

    def on_show(self) -> None:
        """Resume polling when this screen becomes visible."""
        if self._device is not None and not self._polling:
            self._start_data_poll()

    def on_unmount(self) -> None:
        """Stop polling thread, rotctld server, and craft tracking on teardown."""
        self._polling = False
        self._stop_rotctld()
        self._stop_craft_tracking()

    # ------------------------------------------------------------------
    # Mode switching
    # ------------------------------------------------------------------

    def on_mode_bar_mode_changed(self, event: ModeBar.ModeChanged) -> None:
        """Switch the ContentSwitcher when the ModeBar selection changes."""
        switcher = self.query_one("#control-modes", ContentSwitcher)
        switcher.current = event.mode

    def switch_mode(self, mode_key: str) -> None:
        """Programmatically switch to a sub-mode (called by app.py)."""
        switcher = self.query_one("#control-modes", ContentSwitcher)
        switcher.current = mode_key
        # Update ModeBar button highlight
        mode_bar = self.query_one(ModeBar)
        for btn in mode_bar.query(".mode-btn"):
            btn.remove_class("active")
        with contextlib.suppress(Exception):
            mode_bar.query_one(f"#mode-{mode_key}").add_class("active")

    # ------------------------------------------------------------------
    # Position updates (called by app-level poll)
    # ------------------------------------------------------------------

    def on_position_update(self, az: float, el: float) -> None:
        """Push position to compass roses, sparklines, and internal cache."""
        self._last_az = az
        self._last_el = el

        # Manual mode compass
        try:
            compass = self.query_one("#ctrl-compass", CompassRose)
            compass.azimuth = az
            compass.elevation = el
        except Exception:
            pass

        # Presets mode compass
        try:
            preset_compass = self.query_one("#ctrl-preset-compass", CompassRose)
            preset_compass.azimuth = az
            preset_compass.elevation = el
        except Exception:
            pass

        # Sparklines
        try:
            self.query_one("#ctrl-az-spark", SparklineWidget).push(az)
            self.query_one("#ctrl-el-spark", SparklineWidget).push(el)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Data poll worker (step positions + torque)
    # ------------------------------------------------------------------

    def _start_data_poll(self) -> None:
        """Kick off the background data poll for motor status."""
        self._polling = True
        self._poll_worker = self._do_data_poll()

    @work(thread=True, exclusive=True, group="load-dynamics")
    def _load_motor_dynamics(self) -> None:
        """Fetch current velocity values and populate the input fields."""
        if self._device is None:
            return
        try:
            dynamics = self._device.get_motor_dynamics()
            self.app.call_from_thread(
                self._populate_velocity_inputs,
                dynamics["az_max_vel"],
                dynamics["el_max_vel"],
            )
        except Exception:
            log.debug("Failed to load motor dynamics", exc_info=True)

    def _populate_velocity_inputs(self, az_vel: float, el_vel: float) -> None:
        try:
            self.query_one("#ctrl-az-vel", Input).value = f"{az_vel:.1f}"
            self.query_one("#ctrl-el-vel", Input).value = f"{el_vel:.1f}"
        except Exception:
            pass

    @work(thread=True, exclusive=True, group="control-data-poll")
    def _do_data_poll(self) -> None:
        """Poll step positions and torque at ~2 Hz while active."""
        shutdown = self.app.shutdown_event
        while self._polling and not shutdown.is_set():
            if self._device is None:
                shutdown.wait(0.5)
                continue

            # Step positions
            try:
                steps = self._device.get_step_positions()
                self.app.call_from_thread(
                    self._update_motor_steps,
                    steps["az_steps"],
                    steps["el_steps"],
                )
            except Exception:
                log.debug("Step position poll failed", exc_info=True)

            # Torque state from A3981
            try:
                torque_resp = self._device.get_a3981_torque()
                az_torque = "HIGH" if "AZ Torq:HIGH" in torque_resp else "LOW"
                el_torque = "HIGH" if "EL Torq:HIGH" in torque_resp else "LOW"
                self.app.call_from_thread(self._update_torque, az_torque, el_torque)
            except Exception:
                log.debug("Torque poll failed", exc_info=True)

            shutdown.wait(0.5)

    # ------------------------------------------------------------------
    # Thread-safe widget update callbacks
    # ------------------------------------------------------------------

    def _update_motor_steps(self, az_steps: int, el_steps: int) -> None:
        try:
            motor = self.query_one("#ctrl-motor-status", MotorStatus)
            motor.az_steps = az_steps
            motor.el_steps = el_steps
        except Exception:
            pass

    def _update_torque(self, az_torque: str, el_torque: str) -> None:
        try:
            motor = self.query_one("#ctrl-motor-status", MotorStatus)
            motor.az_torque = az_torque
            motor.el_torque = el_torque
        except Exception:
            pass

    def _update_engaged(self, engaged: bool) -> None:
        try:
            motor = self.query_one("#ctrl-motor-status", MotorStatus)
            motor.engaged = engaged
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Button handlers
    # ------------------------------------------------------------------

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""

        if button_id == "btn-ctrl-move":
            self._handle_move()
        elif button_id == "btn-ctrl-home-az":
            self._handle_home(0)
        elif button_id == "btn-ctrl-home-el":
            self._handle_home(1)
        elif button_id == "btn-ctrl-engage":
            self._handle_engage_toggle()
        elif button_id.startswith("btn-step-"):
            self._handle_step_size(event.button)
        elif button_id == "btn-ctrl-apply-vel":
            self._handle_apply_velocity()

    def _handle_move(self) -> None:
        """Read AZ/EL inputs and issue a move command."""
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return

        az_input = self.query_one("#ctrl-az-input", Input)
        el_input = self.query_one("#ctrl-el-input", Input)

        try:
            az = float(az_input.value) if az_input.value.strip() else self._last_az
        except ValueError:
            self.app.notify("Invalid AZ value", severity="warning")
            return

        try:
            el = float(el_input.value) if el_input.value.strip() else self._last_el
        except ValueError:
            self.app.notify("Invalid EL value", severity="warning")
            return

        self.app.notify(f"Moving to AZ={az:.1f} EL={el:.1f}", severity="information")
        self._run_motor_command(self._device.move_to, az, el)

    def _handle_home(self, motor_id: int) -> None:
        """Home a specific motor axis."""
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return
        axis = "AZ" if motor_id == 0 else "EL"
        self.app.notify(f"Homing {axis}...", severity="information")
        self._run_motor_command(self._device.home_motor, motor_id)

    def _handle_engage_toggle(self) -> None:
        """Toggle motor engage/release state."""
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return

        if self._engaged:
            self._run_motor_command(self._device.release)
            self._engaged = False
            self._update_engaged(False)
            self.app.notify("Motors released")
        else:
            self._run_motor_command(self._device.engage)
            self._engaged = True
            self._update_engaged(True)
            self.app.notify("Motors engaged")

    def _handle_step_size(self, pressed_btn: Button) -> None:
        """Update step size and highlight the selected button."""
        # Parse the step size from the button ID: "btn-step-1_0" → 1.0
        raw = (pressed_btn.id or "").replace("btn-step-", "").replace("_", ".")
        try:
            self._step_size = float(raw)
        except ValueError:
            return

        # Update visual selection on all step buttons.
        for btn in self.query(".step-btn"):
            btn.remove_class("selected")
        pressed_btn.add_class("selected")

    def _handle_apply_velocity(self) -> None:
        """Apply velocity settings from the input fields."""
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return

        az_vel_input = self.query_one("#ctrl-az-vel", Input)
        el_vel_input = self.query_one("#ctrl-el-vel", Input)

        az_val = az_vel_input.value.strip()
        el_val = el_vel_input.value.strip()

        if not az_val and not el_val:
            self.app.notify("Enter a velocity value", severity="warning")
            return

        if az_val:
            try:
                az_vel = float(az_val)
                self._run_motor_command(self._device.set_max_velocity, 0, az_vel)
            except ValueError:
                self.app.notify("Invalid AZ velocity", severity="warning")
                return

        if el_val:
            try:
                el_vel = float(el_val)
                self._run_motor_command(self._device.set_max_velocity, 1, el_vel)
            except ValueError:
                self.app.notify("Invalid EL velocity", severity="warning")
                return

        self.app.notify("Velocity updated", severity="information")

    # ------------------------------------------------------------------
    # Preset handlers
    # ------------------------------------------------------------------

    def on_preset_list_go_to_preset(self, event: PresetList.GoToPreset) -> None:
        """Move dish to the selected preset's AZ/EL."""
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return

        az = event.az if event.az is not None else self._last_az
        el = event.el
        self.app.notify(
            f"Moving to preset AZ={az:.1f} EL={el:.1f}",
            severity="information",
        )
        self._run_motor_command(self._device.move_to, az, el)

    def on_preset_list_save_requested(self, _event: PresetList.SaveRequested) -> None:
        """Save the current position as a new preset."""
        preset_list = self.query_one("#ctrl-preset-list", PresetList)
        name_input = preset_list.query_one("#preset-name-input", Input)
        name = name_input.value.strip()

        if not name:
            self.app.notify("Enter a preset name first", severity="warning")
            return

        preset_list.save_preset(name, self._last_az, self._last_el)
        name_input.value = ""
        self.app.notify(
            f"Saved preset '{name}' at AZ={self._last_az:.1f} EL={self._last_el:.1f}"
        )

    # ------------------------------------------------------------------
    # Tracking handlers
    # ------------------------------------------------------------------

    def on_tracking_panel_start_requested(
        self, event: TrackingPanel.StartRequested
    ) -> None:
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return

        if self._rotctld_server is not None:
            self.app.notify("Server already running", severity="warning")
            return

        log.info(
            "Tracking start requested: %s:%d min_el=%.1f",
            event.host,
            event.port,
            event.min_el,
        )

        def status_callback(state: TrackingState) -> None:
            self.app.call_from_thread(self._apply_tracking_state, state)

        self._rotctld_server = TuiRotctldServer(
            device=self._device,
            host=event.host,
            port=event.port,
            on_status=status_callback,
        )
        self._rotctld_thread = threading.Thread(
            target=self._rotctld_server.serve_forever,
            name="rotctld",
            daemon=True,
        )
        self._rotctld_thread.start()

    def on_tracking_panel_stop_requested(
        self, _event: TrackingPanel.StopRequested
    ) -> None:
        self._stop_rotctld()

    def _stop_rotctld(self) -> None:
        if self._rotctld_server is None:
            return

        log.info("Stopping rotctld server")
        self._rotctld_server.stop()

        if self._rotctld_thread is not None:
            self._rotctld_thread.join(timeout=3.0)
            self._rotctld_thread = None

        self._rotctld_server = None

        panel = self.query_one("#ctrl-tracking-panel", TrackingPanel)
        panel.set_status(state="STOPPED")
        self.app.notify("Tracking server stopped")

    def _apply_tracking_state(self, state: TrackingState) -> None:
        try:
            panel = self.query_one("#ctrl-tracking-panel", TrackingPanel)
            panel.set_status(
                state=state.status,
                client=state.client,
                moves=state.moves,
                rate=state.rate,
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Craft API integration
    # ------------------------------------------------------------------

    def set_craft_client(self, client: CraftClient) -> None:
        """Store the Craft API client reference."""
        self._craft_client = client

    def on_craft_panel_search_requested(
        self, event: CraftPanel.SearchRequested
    ) -> None:
        if self._craft_client is None:
            self.app.notify("Craft API not configured", severity="warning")
            return
        self._do_craft_search(event.query)

    def on_craft_panel_passes_requested(
        self, event: CraftPanel.PassesRequested
    ) -> None:
        if self._craft_client is None:
            self.app.notify("Craft API not configured", severity="warning")
            return
        self._do_craft_passes(event.norad_id)

    def on_craft_panel_track_requested(self, event: CraftPanel.TrackRequested) -> None:
        if self._craft_client is None:
            self.app.notify("Craft API not configured", severity="warning")
            return
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return
        if self._craft_tracking:
            self.app.notify("Already tracking", severity="warning")
            return

        self._craft_target_type = event.target_type
        self._craft_target_id = event.target_id
        self._craft_state = CraftTrackingState(
            status="TRACKING", target_name=event.name
        )
        self._craft_tracking = True
        self._run_craft_tracking(
            event.name, event.target_type, event.target_id, event.min_el
        )

    def on_craft_panel_stop_tracking_requested(
        self, _event: CraftPanel.StopTrackingRequested
    ) -> None:
        self._stop_craft_tracking()

    def _stop_craft_tracking(self) -> None:
        if not self._craft_tracking:
            return
        self._craft_tracking = False
        self._craft_state.status = "IDLE"
        try:
            panel = self.query_one("#ctrl-craft-panel", CraftPanel)
            panel.set_tracking_status(state="IDLE")
        except Exception:
            pass

    @work(thread=True, exclusive=True, group="craft-search")
    def _do_craft_search(self, query: str) -> None:
        """Search the Craft catalog in a worker thread."""
        try:
            results = self._craft_client.search(query)
            rows = [
                {
                    "name": r.name,
                    "target_type": r.target_type,
                    "target_id": r.target_id,
                    "groups": r.groups,
                }
                for r in results
            ]
            self.app.call_from_thread(self._apply_craft_search, rows)
        except Exception:
            log.exception("Craft search failed")
            self.app.call_from_thread(
                self.app.notify, "Search failed", severity="error"
            )

    def _apply_craft_search(self, rows: list[dict]) -> None:
        try:
            panel = self.query_one("#ctrl-craft-panel", CraftPanel)
            panel.set_search_results(rows)
            self.app.notify(f"Found {len(rows)} results")
        except Exception:
            pass

    @work(thread=True, exclusive=True, group="craft-passes")
    def _do_craft_passes(self, norad_id: int) -> None:
        """Fetch pass predictions in a worker thread."""
        try:
            passes = self._craft_client.get_passes(norad_id)
            if not passes:
                self.app.call_from_thread(
                    self._apply_craft_passes, "No upcoming passes"
                )
                return

            lines = []
            for p in passes[:8]:
                # Format: AOS time  MaxEL  Duration
                aos = p.aos_time[:16] if len(p.aos_time) > 16 else p.aos_time
                mins = p.duration_seconds // 60
                secs = p.duration_seconds % 60
                vis = " *" if p.is_visible else ""
                lines.append(
                    f"  {aos}  MaxEL {p.max_elevation:5.1f}\u00b0"
                    f"  {mins}m{secs:02d}s{vis}"
                )
            text = "\n".join(lines)
            self.app.call_from_thread(self._apply_craft_passes, text)
        except Exception:
            log.exception("Craft passes failed")
            self.app.call_from_thread(
                self.app.notify, "Pass lookup failed", severity="error"
            )

    def _apply_craft_passes(self, text: str) -> None:
        try:
            panel = self.query_one("#ctrl-craft-panel", CraftPanel)
            panel.set_passes(text)
        except Exception:
            pass

    @work(thread=True, exclusive=True, group="craft-track")
    def _run_craft_tracking(
        self,
        name: str,
        target_type: str,
        target_id: str,
        min_el: float,
    ) -> None:
        """Poll Craft API at ~1 Hz and drive the dish to track a target."""
        shutdown = self.app.shutdown_event
        state = self._craft_state
        state.status = "TRACKING"
        state.target_name = name
        state.error = ""

        # Hook into pass event detector for camera triggers (if installed)
        pass_detector = getattr(self.app, "_pass_detector", None)

        self.app.call_from_thread(self._apply_craft_state, state)

        while self._craft_tracking and not shutdown.is_set():
            try:
                targets = self._craft_client.get_visible_targets(min_alt=0.0)
            except Exception:
                state.status = "ERROR"
                state.error = "API request failed"
                self.app.call_from_thread(self._apply_craft_state, state)
                shutdown.wait(5.0)
                continue

            # Find our target
            match = None
            for t in targets:
                if t.target_type == target_type and t.target_id == target_id:
                    match = t
                    break

            if match is None:
                state.status = "WAITING"
                state.error = "Target below horizon"
                state.azimuth = 0.0
                state.elevation = 0.0
                self.app.call_from_thread(self._apply_craft_state, state)
                shutdown.wait(1.0)
                continue

            state.azimuth = match.azimuth
            state.elevation = match.altitude
            state.distance_km = match.distance_km
            state.range_rate = match.range_rate

            if match.altitude < min_el:
                state.status = "WAITING"
                state.error = f"EL {match.altitude:.1f}\u00b0 < min {min_el:.1f}\u00b0"
                self.app.call_from_thread(self._apply_craft_state, state)
                shutdown.wait(1.0)
                continue

            # Drive the dish
            state.status = "TRACKING"
            state.error = ""
            try:
                self._device.move_motor(0, match.azimuth)
                self._device.move_motor(1, match.altitude)
                state.record_move()
            except Exception:
                log.exception("Craft motor command failed")
                state.error = "Motor command failed"

            self.app.call_from_thread(self._apply_craft_state, state)

            # Feed pass event detector for camera triggers
            if pass_detector is not None:
                pass_detector.update(state.status, name, state.elevation)

            shutdown.wait(1.0)

        # Clean exit
        state.status = "IDLE"
        state.error = ""
        self.app.call_from_thread(self._apply_craft_state, state)

        # Signal LOS on tracking stop
        if pass_detector is not None:
            pass_detector.update("IDLE", name, 0.0)
            pass_detector.reset()

    def _apply_craft_state(self, state: CraftTrackingState) -> None:
        try:
            panel = self.query_one("#ctrl-craft-panel", CraftPanel)
            panel.set_tracking_status(
                state=state.status,
                target_name=state.target_name,
                azimuth=state.azimuth,
                elevation=state.elevation,
                distance_km=state.distance_km,
                range_rate=state.range_rate,
                moves=state.moves,
                rate=state.rate,
                error=state.error,
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Key binding actions
    # ------------------------------------------------------------------

    def _is_manual_active(self) -> bool:
        """Check if Manual mode is the currently visible sub-mode."""
        try:
            switcher = self.query_one("#control-modes", ContentSwitcher)
            return switcher.current == "manual"
        except Exception:
            return False

    def action_nudge_az(self, delta: int) -> None:
        """Nudge azimuth by delta * step_size degrees."""
        if not self._is_manual_active() or self._device is None:
            return
        new_az = self._last_az + delta * self._step_size
        self._run_motor_command(self._device.move_motor, 0, new_az)

    def action_nudge_el(self, delta: int) -> None:
        """Nudge elevation by delta * step_size degrees."""
        if not self._is_manual_active() or self._device is None:
            return
        new_el = self._last_el + delta * self._step_size
        self._run_motor_command(self._device.move_motor, 1, new_el)

    def action_home_both(self) -> None:
        """Home both AZ and EL motors."""
        if not self._is_manual_active() or self._device is None:
            return
        self.app.notify("Homing AZ + EL...", severity="information")
        self._run_motor_command(self._device.home_motor, 0)
        self._run_motor_command(self._device.home_motor, 1)

    def action_engage_motors(self) -> None:
        """Engage (energize) stepper motors."""
        if not self._is_manual_active() or self._device is None:
            return
        self._run_motor_command(self._device.engage)
        self._engaged = True
        self._update_engaged(True)
        self.app.notify("Motors engaged")

    def action_release_motors(self) -> None:
        """Release (de-energize) stepper motors."""
        if not self._is_manual_active() or self._device is None:
            return
        self._run_motor_command(self._device.release)
        self._engaged = False
        self._update_engaged(False)
        self.app.notify("Motors released")

    # ------------------------------------------------------------------
    # Motor command worker
    # ------------------------------------------------------------------

    @work(thread=True, exclusive=False, group="motor-cmd")
    def _run_motor_command(self, fn, *args) -> None:
        """Execute a motor command in a worker thread."""
        try:
            fn(*args)
        except Exception:
            log.exception("Motor command failed")
            self.app.call_from_thread(
                self.app.notify, "Motor command failed", severity="error"
            )
