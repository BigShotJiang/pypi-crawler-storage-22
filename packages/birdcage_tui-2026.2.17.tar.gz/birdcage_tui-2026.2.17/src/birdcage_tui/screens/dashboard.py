"""F1 Dashboard screen -- at-a-glance status and quick actions.

Home base for the Birdcage TUI. Shows a compass rose with live AZ/EL
position, a signal gauge with RSSI sparkline, quick-action buttons for
common tasks, and a system health summary pulled from firmware on mount.
"""

import logging

from textual import work
from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import Static

from birdcage_tui.widgets.compass_rose import CompassRose
from birdcage_tui.widgets.quick_actions import QuickActions
from birdcage_tui.widgets.signal_gauge import SignalGauge
from birdcage_tui.widgets.sparkline_widget import SparklineWidget
from birdcage_tui.widgets.system_health import SystemHealthPanel

log = logging.getLogger(__name__)

DeviceLike = object


class DashboardScreen(Container):
    """F1: At-a-glance status overview with quick actions."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._device: DeviceLike | None = None
        self._health_loaded = False

    def compose(self) -> ComposeResult:
        with Container(classes="screen-container"):
            with Horizontal(classes="top-row"):
                with Vertical(classes="panel"):
                    yield Static("Position", classes="panel-title")
                    yield CompassRose(id="dash-compass")
                with Vertical(classes="panel"):
                    yield Static("Signal", classes="panel-title")
                    yield SignalGauge(id="dash-signal")
                    yield SparklineWidget(
                        max_points=80,
                        label="DVB RSSI",
                        color="#00d4aa",
                        id="dash-rssi-spark",
                    )
            yield QuickActions(classes="quick-actions")
            with Vertical(classes="system-health"):
                yield Static("System Health", classes="panel-title")
                yield SystemHealthPanel(id="dash-health")

    # ------------------------------------------------------------------
    # Device lifecycle
    # ------------------------------------------------------------------

    def set_device(self, device: object) -> None:
        """Store the device reference and kick off health data load."""
        self._device = device
        self._load_health_data()

    def on_show(self) -> None:
        """Load health data on first activation if not yet fetched."""
        if not self._health_loaded and self._device is not None:
            self._load_health_data()

    # ------------------------------------------------------------------
    # Position updates (called by app-level 2 Hz poll)
    # ------------------------------------------------------------------

    def on_position_update(self, az: float, el: float) -> None:
        """Push live AZ/EL into the compass rose."""
        compass = self.query_one("#dash-compass", CompassRose)
        compass.azimuth = az
        compass.elevation = el

    # ------------------------------------------------------------------
    # System health loader
    # ------------------------------------------------------------------

    @work(thread=True, exclusive=True, group="dash-health")
    def _load_health_data(self) -> None:
        """Fetch hardware diagnostics from firmware and populate the panel."""
        if self._device is None:
            return

        shutdown = getattr(self.app, "shutdown_event", None)
        if shutdown is not None and shutdown.is_set():
            return

        diag = ""
        torque = ""
        fw_id = ""
        motor_life = ""
        el_limits: dict[str, float] = {"min": 0.0, "max": 0.0, "home": 0.0}

        try:
            diag = self._device.get_a3981_diag()
        except Exception:
            log.debug("Dashboard: failed to fetch A3981 diag", exc_info=True)

        try:
            torque = self._device.get_a3981_torque()
        except Exception:
            log.debug("Dashboard: failed to fetch A3981 torque", exc_info=True)

        try:
            fw_id = self._device.get_firmware_id()
        except Exception:
            log.debug("Dashboard: failed to fetch firmware ID", exc_info=True)

        try:
            motor_life = self._device.get_motor_life()
        except Exception:
            log.debug("Dashboard: failed to fetch motor life", exc_info=True)

        try:
            el_limits = self._device.get_el_limits()
        except Exception:
            log.debug("Dashboard: failed to fetch EL limits", exc_info=True)

        self._health_loaded = True

        try:
            self.app.call_from_thread(
                self._apply_health_data,
                diag,
                torque,
                fw_id,
                motor_life,
                el_limits,
            )
        except Exception:
            log.debug("Dashboard: failed to push health data to UI", exc_info=True)

    def _apply_health_data(
        self,
        diag: str,
        torque: str,
        fw_id: str,
        motor_life: str,
        el_limits: dict[str, float],
    ) -> None:
        """Update the SystemHealthPanel on the main thread."""
        panel = self.query_one("#dash-health", SystemHealthPanel)
        panel.load_data(
            diag=diag,
            torque=torque,
            fw_id=fw_id,
            motor_life=motor_life,
            el_limits=el_limits,
        )
