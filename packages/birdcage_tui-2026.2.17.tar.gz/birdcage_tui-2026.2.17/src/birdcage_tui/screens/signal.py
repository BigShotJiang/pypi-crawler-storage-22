"""F3 Signal screen -- Find and Measure.

Three sub-modes via ModeBar + ContentSwitcher:

  Monitor  -- RSSI monitoring with dual sparklines, signal gauge, receiver info
  Sweep    -- 1D azimuth-vs-RSSI bar chart across an AZ range at fixed EL
  Sky Map  -- 2D AZ x EL grid scan with heatmap visualization and CSV export

Merges the old Signal + Scan screens into a single tab.
"""

import contextlib
import csv
import logging
import re
from pathlib import Path

from textual import work
from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import (
    Button,
    Checkbox,
    ContentSwitcher,
    Input,
    ProgressBar,
    Static,
)
from textual.worker import Worker, get_current_worker

from birdcage_tui.widgets.mode_bar import ModeBar
from birdcage_tui.widgets.receiver_info import ReceiverInfo
from birdcage_tui.widgets.signal_gauge import SignalGauge
from birdcage_tui.widgets.sky_heatmap import SkyHeatmap
from birdcage_tui.widgets.sparkline_widget import SparklineWidget
from birdcage_tui.widgets.status_strip import StatusStrip
from birdcage_tui.widgets.sweep_plot import SweepPlot

log = logging.getLogger(__name__)

# Type alias -- SerialBridge and DemoDevice share the same duck-typed interface.
DeviceLike = object


class SignalScreen(Container):
    """F3: Find and Measure -- signal monitoring, sweep, and sky mapping."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._device: DeviceLike | None = None

        # Monitor state
        self._monitoring = False
        self._lna_enabled = False
        self._peak_rssi = 0
        self._total_samples = 0
        self._signal_worker: Worker | None = None
        self._receiver_loaded = False

        # Sweep state
        self._sweeping = False
        self._sweep_data: list[tuple[float, float]] = []

        # Sky Map state
        self._scanning = False
        self._scan_data: list[tuple[float, float, float]] = []

    # ------------------------------------------------------------------
    # Compose
    # ------------------------------------------------------------------

    def compose(self) -> ComposeResult:
        with Container(classes="screen-container"):
            yield ModeBar(
                modes={
                    "monitor": "Monitor",
                    "sweep": "Sweep",
                    "skymap": "Sky Map",
                },
                initial="monitor",
                classes="mode-bar",
            )
            with ContentSwitcher(id="signal-modes", initial="monitor"):
                # -- Monitor mode -----------------------------------------
                with Container(id="monitor"):
                    with Horizontal(classes="top-row"):
                        with Vertical(classes="panel"):
                            yield Static("Signal Strength", classes="panel-title")
                            yield SignalGauge(id="signal-gauge")
                            yield SparklineWidget(
                                max_points=80,
                                label="DVB RSSI",
                                color="#00d4aa",
                                id="dvb-spark",
                            )
                            yield SparklineWidget(
                                max_points=80,
                                label="ADC RSSI",
                                color="#2080d0",
                                id="adc-spark",
                            )
                        with Vertical(classes="panel"):
                            yield Static("Receiver", classes="panel-title")
                            yield ReceiverInfo(id="receiver-info")
                    with Horizontal(classes="panel"):
                        yield Static("Samples: 0", id="sample-count", classes="label")
                        yield Static("  Peak: 0", id="peak-value", classes="label")
                        yield Static("  LNA: OFF", id="lna-status", classes="label")
                        yield Static("  Lock: NO", id="lock-status", classes="label")
                    with Horizontal(classes="bottom-controls"):
                        yield Static("Iters ", classes="label")
                        yield Input(value="10", id="iter-input", type="integer")
                        yield Static(" Rate ", classes="label")
                        yield Input(value="2", id="rate-input", type="integer")
                        yield Static(" Hz", classes="label")
                        yield Button("Start", id="btn-start", variant="primary")
                        yield Button("Stop", id="btn-stop")
                        yield Button("V-pol 13V", id="btn-lna")
                        yield Button("Reset Peak", id="btn-reset-peak")

                # -- Sweep mode -------------------------------------------
                with Container(id="sweep"):
                    with Vertical(classes="panel"):
                        yield Static("AZ Sweep", classes="panel-title")
                        yield SweepPlot(id="sweep-plot")
                    with Horizontal(classes="scan-status"):
                        yield Static("Idle", id="sweep-status-text")
                        yield ProgressBar(
                            id="sweep-progress", total=100, show_eta=False
                        )
                    with Horizontal(classes="bottom-controls"):
                        yield Static("AZ Start ", classes="label")
                        yield Input(value="160", id="sweep-az-start", type="number")
                        yield Static(" AZ End ", classes="label")
                        yield Input(value="220", id="sweep-az-end", type="number")
                        yield Static(" Step ", classes="label")
                        yield Input(value="1.5", id="sweep-az-step", type="number")
                        yield Static(" EL (fixed) ", classes="label")
                        yield Input(value="38.0", id="sweep-el-fixed", type="number")
                        yield Static(" Iters ", classes="label")
                        yield Input(value="10", id="sweep-iters", type="integer")
                    with Horizontal(classes="bottom-controls"):
                        yield Button(
                            "Start Sweep", id="btn-start-sweep", variant="primary"
                        )
                        yield Button("Stop", id="btn-stop-sweep")
                        yield Button("Export CSV", id="btn-export-sweep")
                        yield Checkbox(
                            "Software mode",
                            id="sweep-software-mode",
                            value=False,
                        )

                # -- Sky Map mode -----------------------------------------
                with Container(id="skymap"):
                    with Vertical(classes="panel"):
                        yield Static("Sky Scan", classes="panel-title")
                        yield SkyHeatmap(az_bins=40, el_bins=10, id="heatmap")
                    yield SparklineWidget(
                        max_points=80,
                        label="Sweep RSSI",
                        color="#00d4aa",
                        id="scan-spark",
                    )
                    with Horizontal(classes="scan-status"):
                        yield Static("Idle", id="scan-status-text")
                        yield ProgressBar(id="scan-progress", total=100, show_eta=False)
                    with Horizontal(classes="bottom-controls"):
                        yield Static("AZ ", classes="label")
                        yield Input(value="160", id="scan-az-start", type="number")
                        yield Static("-", classes="label")
                        yield Input(value="220", id="scan-az-end", type="number")
                        yield Static(" Step ", classes="label")
                        yield Input(value="1.5", id="scan-az-step", type="number")
                        yield Static(" EL ", classes="label")
                        yield Input(value="18", id="scan-el-start", type="number")
                        yield Static("-", classes="label")
                        yield Input(value="65", id="scan-el-end", type="number")
                        yield Static(" Step ", classes="label")
                        yield Input(value="5.0", id="scan-el-step", type="number")
                    with Horizontal(classes="bottom-controls"):
                        yield Static("Transponders ", classes="label")
                        yield Input(value="3", id="xponder-input", type="integer")
                        yield Button(
                            "Start Scan", id="btn-start-scan", variant="primary"
                        )
                        yield Button("Stop", id="btn-stop-scan")
                        yield Button("Export CSV", id="btn-export-scan")
                        yield Checkbox(
                            "Software mode",
                            id="scan-software-mode",
                            value=False,
                        )

    # ------------------------------------------------------------------
    # Device lifecycle
    # ------------------------------------------------------------------

    def set_device(self, device: DeviceLike) -> None:
        """Store the device reference."""
        self._device = device

    def on_show(self) -> None:
        """Load receiver info on first show (requires device)."""
        if not self._receiver_loaded and self._device is not None:
            self._load_receiver_info()

    def on_position_update(self, az: float, el: float) -> None:
        """Called by app-level position poll. Signal screen doesn't use this."""

    def on_unmount(self) -> None:
        """Stop all workers on teardown."""
        self._monitoring = False
        self._sweeping = False
        self._scanning = False

    # ------------------------------------------------------------------
    # ModeBar switching
    # ------------------------------------------------------------------

    def on_mode_bar_mode_changed(self, event: ModeBar.ModeChanged) -> None:
        """Switch ContentSwitcher when ModeBar selection changes."""
        switcher = self.query_one("#signal-modes", ContentSwitcher)
        switcher.current = event.mode

    def switch_mode(self, mode_key: str) -> None:
        """Programmatic mode switch (called by app.py for QuickActions)."""
        switcher = self.query_one("#signal-modes", ContentSwitcher)
        switcher.current = mode_key
        # Update the ModeBar visual state to match.
        mode_bar = self.query_one(ModeBar)
        for btn in mode_bar.query(".mode-btn"):
            btn.remove_class("active")
        with contextlib.suppress(Exception):
            mode_bar.query_one(f"#mode-{mode_key}").add_class("active")

    # ------------------------------------------------------------------
    # Input helpers
    # ------------------------------------------------------------------

    def _read_float(self, widget_id: str, fallback: float) -> float:
        """Read a float from an Input widget, returning *fallback* on error."""
        try:
            return float(self.query_one(f"#{widget_id}", Input).value)
        except (ValueError, TypeError):
            return fallback

    def _read_int(self, widget_id: str, fallback: int) -> int:
        """Read an int from an Input widget, returning *fallback* on error."""
        try:
            return int(self.query_one(f"#{widget_id}", Input).value)
        except (ValueError, TypeError):
            return fallback

    # ==================================================================
    # MONITOR MODE
    # ==================================================================

    @work(thread=True, exclusive=True, group="signal-poll")
    def _do_signal_poll(self) -> None:
        """Poll RSSI at the configured rate while monitoring is active."""
        shutdown = self.app.shutdown_event
        while self._monitoring and not shutdown.is_set():
            if self._device is None:
                shutdown.wait(0.5)
                continue

            # Read config from inputs (safe defaults on parse failure).
            try:
                iterations = int(
                    self.app.call_from_thread(self._read_input, "iter-input") or "10"
                )
                iterations = max(1, iterations)
            except (ValueError, TypeError):
                iterations = 10

            try:
                rate = int(
                    self.app.call_from_thread(self._read_input, "rate-input") or "2"
                )
                rate = max(1, rate)
            except (ValueError, TypeError):
                rate = 2

            # DVB RSSI (bounded, averaged)
            try:
                rssi = self._device.get_rssi(iterations)
                rssi_avg = rssi["average"]
                rssi_cur = rssi["current"]
                reads = rssi["reads"]

                self._total_samples += reads
                if rssi_cur > self._peak_rssi:
                    self._peak_rssi = rssi_cur

                self.app.call_from_thread(self._update_gauge, rssi_avg, rssi_cur, reads)
                self.app.call_from_thread(self._push_dvb_spark, float(rssi_avg))
                self.app.call_from_thread(self._update_monitor_stats)
                self.app.call_from_thread(self._update_status_strip_rssi, rssi_avg)
            except Exception:
                log.debug("DVB RSSI poll failed", exc_info=True)

            # ADC RSSI (raw single-shot)
            try:
                adc_resp = self._device.get_adc_rssi()
                adc_match = re.search(r"(\d+)", adc_resp)
                if adc_match:
                    adc_val = float(adc_match.group(1))
                    self.app.call_from_thread(self._push_adc_spark, adc_val)
            except Exception:
                log.debug("ADC RSSI poll failed", exc_info=True)

            # Lock status
            try:
                lock_resp = self._device.get_lock_status()
                lock_match = re.search(r"Lock:(\d)", lock_resp)
                if lock_match:
                    locked = lock_match.group(1) == "1"
                    self.app.call_from_thread(self._update_lock, locked)
            except Exception:
                log.debug("Lock status poll failed", exc_info=True)

            shutdown.wait(1.0 / rate)

    # -- Monitor thread-safe callbacks --

    def _read_input(self, input_id: str) -> str:
        """Read an Input widget's value (must run on main thread)."""
        return self.query_one(f"#{input_id}", Input).value

    def _update_gauge(self, rssi_avg: int, rssi_cur: int, reads: int) -> None:
        gauge = self.query_one("#signal-gauge", SignalGauge)
        gauge.rssi_avg = rssi_avg
        gauge.rssi_cur = rssi_cur
        gauge.reads = reads

    def _push_dvb_spark(self, value: float) -> None:
        self.query_one("#dvb-spark", SparklineWidget).push(value)

    def _push_adc_spark(self, value: float) -> None:
        self.query_one("#adc-spark", SparklineWidget).push(value)

    def _update_monitor_stats(self) -> None:
        self.query_one("#sample-count", Static).update(
            f"Samples: {self._total_samples}"
        )
        self.query_one("#peak-value", Static).update(f"  Peak: {self._peak_rssi}")

    def _update_lock(self, locked: bool) -> None:
        label = "YES" if locked else "NO"
        self.query_one("#lock-status", Static).update(f"  Lock: {label}")

    def _update_lna_ui(self) -> None:
        if self._lna_enabled:
            self.query_one("#lna-status", Static).update("  LNA: ON (V-pol)")
            self.query_one("#btn-lna", Button).label = "H-pol 18V"
        else:
            self.query_one("#lna-status", Static).update("  LNA: OFF (H-pol)")
            self.query_one("#btn-lna", Button).label = "V-pol 13V"

    def _update_status_strip_rssi(self, rssi_avg: int) -> None:
        """Push RSSI to the app-level StatusStrip."""
        with contextlib.suppress(Exception):
            self.app.query_one("#status-strip", StatusStrip).rssi = rssi_avg

    # -- Monitor button handlers --

    def _handle_monitor_start(self) -> None:
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return
        if self._monitoring:
            return

        self._monitoring = True
        self._signal_worker = self._do_signal_poll()
        self.app.notify("Signal monitoring started")

        self.query_one("#btn-start", Button).variant = "default"
        self.query_one("#btn-stop", Button).variant = "warning"

    def _handle_monitor_stop(self) -> None:
        self._monitoring = False
        self.app.notify("Signal monitoring stopped")

        self.query_one("#btn-start", Button).variant = "primary"
        self.query_one("#btn-stop", Button).variant = "default"

    def _handle_lna(self) -> None:
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return
        self._do_toggle_lnb()

    @work(thread=True, exclusive=False, group="signal-cmd")
    def _do_toggle_lnb(self) -> None:
        try:
            if self._lna_enabled:
                self._device.set_lnb_voltage("stb")
                self._lna_enabled = False
                self.app.call_from_thread(self._update_lna_ui)
                self.app.call_from_thread(
                    self.app.notify, "LNB set to 18V (H-pol)"
                )
            else:
                self._device.set_lnb_voltage("odu")
                self._lna_enabled = True
                self.app.call_from_thread(self._update_lna_ui)
                self.app.call_from_thread(
                    self.app.notify, "LNB set to 13V (V-pol, LNA on)"
                )
        except Exception:
            log.exception("LNB voltage switch failed")
            self.app.call_from_thread(
                self.app.notify, "LNB voltage switch failed", severity="error"
            )

    def _handle_reset_peak(self) -> None:
        self._peak_rssi = 0
        self._total_samples = 0
        self._update_monitor_stats()
        self.app.notify("Peak and sample counters reset")

    @work(thread=True, exclusive=False, group="signal-cmd")
    def _load_receiver_info(self) -> None:
        """Fetch channel params and DVB config in a worker thread."""
        if self._device is None:
            return
        try:
            channel = self._device.get_channel_params()
            config = self._device.get_dvb_config()
            self._receiver_loaded = True
            self.app.call_from_thread(self._apply_receiver_info, channel, config)
        except Exception:
            log.debug("Receiver info load failed", exc_info=True)

    def _apply_receiver_info(self, channel: str, config: str) -> None:
        self.query_one("#receiver-info", ReceiverInfo).load_data(channel, config)

    # ==================================================================
    # SWEEP MODE (1D AZ scan)
    # ==================================================================

    @work(thread=True)
    def _do_sweep(self) -> None:
        """Execute a 1D AZ sweep -- firmware-accelerated or software fallback."""
        device = self._device
        if device is None:
            return

        try:
            # Check if user forced software mode.
            force_software = self.query_one("#sweep-software-mode", Checkbox).value

            if not force_software and hasattr(device, "az_sweep_firmware"):
                try:
                    self._do_sweep_firmware(device)
                    return
                except InterruptedError:
                    # User cancelled via Stop or app shutdown — don't retry.
                    log.info("Firmware sweep cancelled")
                    return
                except Exception:
                    log.warning(
                        "Firmware sweep failed, falling back to software",
                        exc_info=True,
                    )
                    # Only fall through to software if still active.
                    if not self._sweeping:
                        return
                    with contextlib.suppress(Exception):
                        self.app.call_from_thread(
                            self._set_sweep_status,
                            "Firmware sweep failed -- falling back...",
                        )

            self._do_sweep_software(device)
        finally:
            self._sweeping = False
            # Clear cancel so the next sweep doesn't immediately abort.
            if self._device and hasattr(self._device, "clear_cancel"):
                self._device.clear_cancel()
            with contextlib.suppress(Exception):
                self.app.call_from_thread(self._reset_sweep_buttons)

    def _do_sweep_firmware(self, device: DeviceLike) -> None:
        """Firmware-accelerated sweep via azscanwxp (runs in worker thread)."""
        shutdown = self.app.shutdown_event

        az_start = self._read_float("sweep-az-start", 160.0)
        az_end = self._read_float("sweep-az-end", 220.0)
        az_step = self._read_float("sweep-az-step", 1.5)
        el_fixed = self._read_float("sweep-el-fixed", 38.0)
        iterations = self._read_int("sweep-iters", 10)

        span = az_end - az_start
        if span <= 0 or az_step <= 0:
            self.app.call_from_thread(
                self._set_sweep_status, "Invalid sweep range -- check parameters"
            )
            return

        step_cdeg = max(1, int(az_step * 100))

        # Set EL once.
        self.app.call_from_thread(self._set_sweep_status, "Setting elevation...")
        device.move_motor(1, el_fixed)

        # Let EL settle briefly.
        shutdown.wait(0.5)
        if not self._sweeping or shutdown.is_set():
            return

        self.app.call_from_thread(
            self._set_sweep_status, "Firmware scan in progress..."
        )
        self.app.call_from_thread(
            self._set_sweep_progress, 10, "Firmware scan in progress..."
        )

        results = device.az_sweep_firmware(
            start_az=az_start,
            span=span,
            step_cdeg=step_cdeg,
            num_xponders=iterations,
        )

        # Check if Stop was pressed while firmware was executing.
        if not self._sweeping or shutdown.is_set():
            self.app.call_from_thread(self._set_sweep_status, "Sweep stopped")
            return

        if not results:
            self.app.call_from_thread(
                self._set_sweep_status, "Firmware sweep returned no data"
            )
            return

        # Populate the plot with all points at once.
        sweep_plot = self.query_one("#sweep-plot", SweepPlot)
        for pt in results:
            az_val = pt["az"]
            rssi = pt["rssi"]
            self._sweep_data.append((az_val, rssi))
            self.app.call_from_thread(sweep_plot.add_point, az_val, rssi)

        total = len(results)
        msg = f"Sweep complete -- {total} points (firmware)"
        self.app.call_from_thread(self._set_sweep_progress, 100, msg)
        self.app.call_from_thread(
            self._set_sweep_status, f"Sweep complete -- {total} points (firmware)"
        )

    def _do_sweep_software(self, device: DeviceLike) -> None:
        """Software step-dwell-measure sweep (runs in worker thread)."""
        worker = get_current_worker()
        shutdown = self.app.shutdown_event

        az_start = self._read_float("sweep-az-start", 160.0)
        az_end = self._read_float("sweep-az-end", 220.0)
        az_step = self._read_float("sweep-az-step", 1.5)
        el_fixed = self._read_float("sweep-el-fixed", 38.0)
        iterations = self._read_int("sweep-iters", 10)

        if az_step <= 0:
            az_step = 1.0

        # Build AZ point list.
        az_values: list[float] = []
        az = az_start
        while az <= az_end + 1e-9:
            az_values.append(round(az, 2))
            az += az_step

        total = len(az_values)
        if total == 0:
            self.app.call_from_thread(
                self._set_sweep_status, "No sweep points -- check parameters"
            )
            return

        sweep_plot = self.query_one("#sweep-plot", SweepPlot)

        # Set EL once at start, then only move AZ per point.
        try:
            device.move_motor(1, el_fixed)
        except Exception:
            log.exception("EL move failed")

        for idx, az_val in enumerate(az_values):
            if not self._sweeping or worker.is_cancelled or shutdown.is_set():
                self.app.call_from_thread(self._set_sweep_status, "Sweep stopped")
                return

            # Move AZ only (EL already set).
            try:
                device.move_motor(0, az_val)
            except Exception:
                log.exception("AZ move failed at %.2f", az_val)
                msg = f"Move error at AZ={az_val:.1f}"
                self.app.call_from_thread(self._set_sweep_status, msg)
                continue

            # Settle time.
            shutdown.wait(0.3)

            # Read signal.
            try:
                rssi_data = device.get_rssi(iterations)
                rssi = float(rssi_data.get("average", 0))
            except Exception:
                log.exception("get_rssi failed at AZ=%.2f", az_val)
                rssi = 0.0

            self._sweep_data.append((az_val, rssi))

            # Update widgets.
            self.app.call_from_thread(sweep_plot.add_point, az_val, rssi)
            self.app.call_from_thread(sweep_plot.set_active, az_val)

            done = idx + 1
            pct = int(done * 100 / total)
            status = f"AZ={az_val:.1f}  RSSI={rssi:.0f}  [{done}/{total}]"
            self.app.call_from_thread(self._set_sweep_progress, pct, status)

        self.app.call_from_thread(
            self._set_sweep_status, f"Sweep complete -- {total} points"
        )

    # -- Sweep thread-safe callbacks --

    def _set_sweep_status(self, text: str) -> None:
        self.query_one("#sweep-status-text", Static).update(text)

    def _set_sweep_progress(self, pct: int, status_text: str) -> None:
        self.query_one("#sweep-progress", ProgressBar).update(progress=pct)
        self.query_one("#sweep-status-text", Static).update(status_text)

    def _reset_sweep_buttons(self) -> None:
        """Restore sweep button styles to idle state (main thread)."""
        self.query_one("#btn-start-sweep", Button).variant = "primary"
        self.query_one("#btn-stop-sweep", Button).variant = "default"

    # -- Sweep button handlers --

    def _handle_sweep_start(self) -> None:
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return
        if self._sweeping:
            self.app.notify("Sweep already in progress", severity="warning")
            return

        sweep_plot = self.query_one("#sweep-plot", SweepPlot)
        sweep_plot.clear()
        self._sweep_data.clear()
        self.query_one("#sweep-progress", ProgressBar).update(progress=0)
        self._set_sweep_status("Starting sweep...")

        self.query_one("#btn-start-sweep", Button).variant = "default"
        self.query_one("#btn-stop-sweep", Button).variant = "warning"

        self._sweeping = True
        self._do_sweep()

    def _handle_sweep_stop(self) -> None:
        self._sweeping = False
        # Cancel any blocked serial operation (firmware sweep).
        if self._device and hasattr(self._device, "cancel_operation"):
            self._device.cancel_operation()
        self._set_sweep_status("Stopping...")
        self._reset_sweep_buttons()

    def _export_sweep_csv(self) -> None:
        if not self._sweep_data:
            self.app.notify("No sweep data to export", severity="warning")
            return

        output = Path("/tmp/birdcage_sweep.csv")
        try:
            with output.open("w", newline="") as fh:
                writer = csv.writer(fh)
                writer.writerow(["az", "rssi"])
                for az, rssi in self._sweep_data:
                    writer.writerow([f"{az:.2f}", f"{rssi:.1f}"])
            self.app.notify(f"Exported {len(self._sweep_data)} points to {output}")
        except OSError as exc:
            log.exception("Sweep CSV export failed")
            self.app.notify(f"Export failed: {exc}", severity="error")

    # ==================================================================
    # SKY MAP MODE (2D AZ x EL scan)
    # ==================================================================

    @work(thread=True)
    def _do_scan(self) -> None:
        """Execute the AZ/EL grid scan in a background thread."""
        device = self._device
        if device is None:
            return

        try:
            self._do_scan_inner(device)
        finally:
            self._scanning = False
            if self._device and hasattr(self._device, "clear_cancel"):
                self._device.clear_cancel()
            with contextlib.suppress(Exception):
                self.app.call_from_thread(self._reset_scan_buttons)

    def _do_scan_inner(self, device: DeviceLike) -> None:
        """Inner scan logic (called from _do_scan worker thread)."""
        worker = get_current_worker()
        shutdown = self.app.shutdown_event

        az_start = self._read_float("scan-az-start", 160.0)
        az_end = self._read_float("scan-az-end", 220.0)
        az_step = self._read_float("scan-az-step", 1.5)
        el_start = self._read_float("scan-el-start", 18.0)
        el_end = self._read_float("scan-el-end", 65.0)
        el_step = self._read_float("scan-el-step", 5.0)
        iterations = self._read_int("xponder-input", 3)

        if az_step <= 0:
            az_step = 1.0
        if el_step <= 0:
            el_step = 1.0

        # Build the grid point lists.
        el_values: list[float] = []
        el = el_start
        while el <= el_end + 1e-9:
            el_values.append(round(el, 2))
            el += el_step

        az_values: list[float] = []
        az = az_start
        while az <= az_end + 1e-9:
            az_values.append(round(az, 2))
            az += az_step

        total_points = len(el_values) * len(az_values)
        if total_points == 0:
            self.app.call_from_thread(
                self._set_scan_status, "No grid points -- check parameters"
            )
            return

        heatmap = self.query_one("#heatmap", SkyHeatmap)
        spark = self.query_one("#scan-spark", SparklineWidget)

        force_software = self.query_one("#scan-software-mode", Checkbox).value
        use_firmware = not force_software and hasattr(device, "az_sweep_firmware")

        done = 0
        az_span_grid = az_end - az_start + 1e-9
        el_span_grid = el_end - el_start + 1e-9
        span_deg = az_end - az_start
        step_cdeg = max(1, int(az_step * 100))

        for _el_idx, el_val in enumerate(el_values):
            if not self._scanning or worker.is_cancelled or shutdown.is_set():
                self.app.call_from_thread(self._set_scan_status, "Scan stopped")
                return

            # Try firmware sweep for this EL row.
            if use_firmware:
                try:
                    device.move_motor(1, el_val)
                    shutdown.wait(0.3)

                    status = f"EL={el_val:.1f}  Firmware sweep..."
                    self.app.call_from_thread(self._set_scan_status, status)

                    results = device.az_sweep_firmware(
                        start_az=az_start,
                        span=span_deg,
                        step_cdeg=step_cdeg,
                        num_xponders=iterations,
                    )

                    for pt in results:
                        az_val = pt["az"]
                        rssi = pt["rssi"]
                        self._scan_data.append((az_val, el_val, rssi))

                        grid_az = min(
                            int((az_val - az_start) / az_span_grid * heatmap.az_bins),
                            heatmap.az_bins - 1,
                        )
                        grid_el = min(
                            int((el_val - el_start) / el_span_grid * heatmap.el_bins),
                            heatmap.el_bins - 1,
                        )
                        self.app.call_from_thread(
                            heatmap.set_point, grid_az, grid_el, rssi
                        )
                        self.app.call_from_thread(spark.push, rssi)

                    done += len(az_values)
                    pct = min(int(done * 100 / total_points), 100)
                    status = (
                        f"EL={el_val:.1f}  {len(results)} pts (firmware)  "
                        f"[{done}/{total_points}]"
                    )
                    self.app.call_from_thread(self._set_scan_progress, pct, status)
                    continue

                except Exception:
                    log.warning(
                        "Firmware sweep failed at EL=%.1f, falling back",
                        el_val,
                        exc_info=True,
                    )
                    use_firmware = False  # Don't retry firmware for remaining rows.

            # Software fallback: point-by-point for this EL row.
            try:
                device.move_motor(1, el_val)
            except Exception:
                log.exception("EL move failed at EL=%.2f", el_val)

            for _az_idx, az_val in enumerate(az_values):
                if not self._scanning or worker.is_cancelled or shutdown.is_set():
                    self.app.call_from_thread(self._set_scan_status, "Scan stopped")
                    return

                try:
                    device.move_motor(0, az_val)
                except Exception:
                    log.exception("AZ move failed at AZ=%.2f EL=%.2f", az_val, el_val)
                    continue

                shutdown.wait(0.3)

                try:
                    rssi_data = device.get_rssi(iterations)
                    rssi = float(rssi_data.get("average", 0))
                except Exception:
                    log.exception("get_rssi failed at AZ=%.2f EL=%.2f", az_val, el_val)
                    rssi = 0.0

                self._scan_data.append((az_val, el_val, rssi))

                grid_az = min(
                    int((az_val - az_start) / az_span_grid * heatmap.az_bins),
                    heatmap.az_bins - 1,
                )
                grid_el = min(
                    int((el_val - el_start) / el_span_grid * heatmap.el_bins),
                    heatmap.el_bins - 1,
                )

                self.app.call_from_thread(heatmap.set_point, grid_az, grid_el, rssi)
                self.app.call_from_thread(heatmap.set_active, grid_az, grid_el)
                self.app.call_from_thread(spark.push, rssi)

                done += 1
                pct = int(done * 100 / total_points)
                status_text = (
                    f"AZ={az_val:.1f} EL={el_val:.1f}  "
                    f"RSSI={rssi:.0f}  [{done}/{total_points}]"
                )
                self.app.call_from_thread(self._set_scan_progress, pct, status_text)

        msg = f"Scan complete -- {total_points} points"
        self.app.call_from_thread(self._set_scan_status, msg)

    # -- Scan thread-safe callbacks --

    def _set_scan_status(self, text: str) -> None:
        self.query_one("#scan-status-text", Static).update(text)

    def _set_scan_progress(self, pct: int, status_text: str) -> None:
        self.query_one("#scan-progress", ProgressBar).update(progress=pct)
        self.query_one("#scan-status-text", Static).update(status_text)

    def _reset_scan_buttons(self) -> None:
        """Restore scan button styles to idle state (main thread)."""
        self.query_one("#btn-start-scan", Button).variant = "primary"
        self.query_one("#btn-stop-scan", Button).variant = "default"

    # -- Scan button handlers --

    def _handle_scan_start(self) -> None:
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return
        if self._scanning:
            self.app.notify("Scan already in progress", severity="warning")
            return

        heatmap = self.query_one("#heatmap", SkyHeatmap)
        heatmap.clear()
        self._scan_data.clear()
        self.query_one("#scan-progress", ProgressBar).update(progress=0)
        self._set_scan_status("Starting scan...")

        self.query_one("#btn-start-scan", Button).variant = "default"
        self.query_one("#btn-stop-scan", Button).variant = "warning"

        self._scanning = True
        self._do_scan()

    def _handle_scan_stop(self) -> None:
        self._scanning = False
        if self._device and hasattr(self._device, "cancel_operation"):
            self._device.cancel_operation()
        self._set_scan_status("Stopping...")
        self._reset_scan_buttons()

    def _export_scan_csv(self) -> None:
        if not self._scan_data:
            self.app.notify("No scan data to export", severity="warning")
            return

        output = Path("/tmp/birdcage_scan.csv")
        try:
            with output.open("w", newline="") as fh:
                writer = csv.writer(fh)
                writer.writerow(["az", "el", "rssi"])
                for az, el, rssi in self._scan_data:
                    writer.writerow([f"{az:.2f}", f"{el:.2f}", f"{rssi:.1f}"])
            self.app.notify(f"Exported {len(self._scan_data)} points to {output}")
        except OSError as exc:
            log.exception("Scan CSV export failed")
            self.app.notify(f"Export failed: {exc}", severity="error")

    # ==================================================================
    # Unified button dispatcher
    # ==================================================================

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""

        # Monitor buttons
        if button_id == "btn-start":
            self._handle_monitor_start()
        elif button_id == "btn-stop":
            self._handle_monitor_stop()
        elif button_id == "btn-lna":
            self._handle_lna()
        elif button_id == "btn-reset-peak":
            self._handle_reset_peak()

        # Sweep buttons
        elif button_id == "btn-start-sweep":
            self._handle_sweep_start()
        elif button_id == "btn-stop-sweep":
            self._handle_sweep_stop()
        elif button_id == "btn-export-sweep":
            self._export_sweep_csv()

        # Sky Map buttons
        elif button_id == "btn-start-scan":
            self._handle_scan_start()
        elif button_id == "btn-stop-scan":
            self._handle_scan_stop()
        elif button_id == "btn-export-scan":
            self._export_scan_csv()
