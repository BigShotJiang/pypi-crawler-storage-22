"""F4 System Screen -- hardware info, motor tuning, NVS configuration.

Three sub-modes via ModeBar: Hardware, Motors, NVS Config. All data is
fetched from the device in background worker threads and pushed to widgets
via call_from_thread.
"""

import json
import logging
import re
from pathlib import Path

from rich.text import Text
from textual import work
from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import Button, ContentSwitcher, Static
from textual.worker import get_current_worker

from birdcage_tui.widgets.mode_bar import ModeBar
from birdcage_tui.widgets.motor_tuning import MotorTuning
from birdcage_tui.widgets.nvs_filter import NvsFilter
from birdcage_tui.widgets.nvs_table import NvsTable

log = logging.getLogger(__name__)

# Type alias -- SerialBridge and DemoDevice share the same duck-typed interface.
DeviceLike = object


def _parse_firmware_info(raw: str) -> Text:
    """Extract version, clock speed, and antenna ID from ``os > id`` output.

    Returns a styled Rich Text suitable for a Static widget.
    """
    version = "?"
    clock = "?"
    ant_id = "?"

    m = re.search(r"Software version:\s*(\S+)", raw)
    if m:
        version = m.group(1)

    m = re.search(r"CCLK:\s*(\d+)", raw)
    if m:
        mhz = int(m.group(1)) // 1_000_000
        clock = f"{mhz}MHz"

    m = re.search(r"Ant ID:\s*(.+?)$", raw, re.MULTILINE)
    if m:
        ant_id = m.group(1).strip()

    result = Text()
    result.append("FW: ", style="#506878")
    result.append(version, style="bold #00d4aa")
    result.append("  |  ", style="#1a2a38")
    result.append("MCU: ", style="#506878")
    result.append(f"K60 {clock}", style="#c8d0d8")
    result.append("  |  ", style="#1a2a38")
    result.append("Ant: ", style="#506878")
    result.append(ant_id, style="#c8d0d8")
    return result


def _format_a3981(diag: str, modes: dict[str, str], torque: str) -> Text:
    """Combine A3981 diagnostic, mode, and torque data into styled text."""
    result = Text()

    # Diagnostics -- highlight OK in green, FAULT in red.
    for line in diag.splitlines():
        line = line.strip()
        if not line:
            continue
        if "FAULT" in line.upper():
            result.append(line, style="bold #e04040")
        elif "OK" in line.upper():
            result.append(line, style="#00e060")
        else:
            result.append(line, style="#c8d0d8")
        result.append("\n")

    # Step mode.
    sm = modes.get("step_mode", "")
    for line in sm.splitlines():
        line = line.strip()
        if line:
            result.append(line, style="#506878")
            result.append("\n")

    # Current mode.
    cm = modes.get("current_mode", "")
    for line in cm.splitlines():
        line = line.strip()
        if line:
            result.append(line, style="#506878")
            result.append("\n")

    # Torque -- HIGH in warm color, LOW in dim.
    for line in torque.splitlines():
        line = line.strip()
        if not line:
            continue
        if "HIGH" in line.upper():
            result.append(line, style="#e8c020")
        else:
            result.append(line, style="#384858")
        result.append("\n")

    # Trim trailing newline.
    text_str = result.plain
    if text_str.endswith("\n"):
        result.right_crop(1)

    return result


def _format_motor_dynamics(
    dynamics: dict[str, float],
    el_limits: dict[str, float],
) -> Text:
    """Format motor velocity, acceleration, and EL limits into styled text."""
    result = Text()

    az_vel = dynamics.get("az_max_vel", 0.0)
    el_vel = dynamics.get("el_max_vel", 0.0)
    az_acc = dynamics.get("az_accel", 0.0)
    el_acc = dynamics.get("el_accel", 0.0)

    result.append("AZ Max Vel: ", style="#506878")
    result.append(f"{az_vel:.1f}", style="bold #c8d0d8")
    result.append("\u00b0/s", style="#506878")
    result.append("    ", style="#0e1420")
    result.append("EL Max Vel: ", style="#506878")
    result.append(f"{el_vel:.1f}", style="bold #c8d0d8")
    result.append("\u00b0/s", style="#506878")
    result.append("\n")

    result.append("AZ Accel:   ", style="#506878")
    result.append(f"{az_acc:.1f}", style="bold #c8d0d8")
    result.append("\u00b0/s\u00b2", style="#506878")
    result.append("  ", style="#0e1420")
    result.append("EL Accel:   ", style="#506878")
    result.append(f"{el_acc:.1f}", style="bold #c8d0d8")
    result.append("\u00b0/s\u00b2", style="#506878")
    result.append("\n")

    result.append("Steps/Rev:  ", style="#506878")
    result.append("40000 / 24960", style="#c8d0d8")

    el_min = el_limits.get("min", 0.0)
    el_max = el_limits.get("max", 0.0)
    el_home = el_limits.get("home", 0.0)

    result.append("\n")
    result.append("EL Range:   ", style="#506878")
    result.append(f"{el_min:.1f}", style="#c8d0d8")
    result.append("\u00b0 - ", style="#506878")
    result.append(f"{el_max:.1f}", style="#c8d0d8")
    result.append("\u00b0", style="#506878")
    result.append("  Home: ", style="#506878")
    result.append(f"{el_home:.1f}", style="bold #00d4aa")
    result.append("\u00b0", style="#506878")

    return result


class SystemScreen(Container):
    """F4: System hardware, motor tuning, and NVS configuration."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._device: DeviceLike | None = None
        self._refreshed = False
        self._nvs_raw: str = ""
        self._nvs_parsed: list[dict[str, str]] = []

    def compose(self) -> ComposeResult:
        with Container(classes="screen-container"):
            yield ModeBar(
                modes={
                    "hardware": "Hardware",
                    "motors": "Motors",
                    "nvs": "NVS Config",
                },
                initial="hardware",
                classes="mode-bar",
            )
            with ContentSwitcher(id="system-modes", initial="hardware"):
                # -- Hardware sub-mode --
                with Container(id="hardware"):
                    with Vertical(classes="panel"):
                        yield Static("Firmware", classes="panel-title")
                        yield Static("", id="firmware-info")
                    with Vertical(classes="panel"):
                        yield Static("A3981 Stepper Drivers", classes="panel-title")
                        yield Static("", id="a3981-diag")
                    with Horizontal(classes="bottom-controls"):
                        yield Button(
                            "Refresh All",
                            id="btn-refresh-all",
                            variant="primary",
                        )
                        yield Button("Reset A3981 Faults", id="btn-reset-a3981")

                # -- Motors sub-mode --
                with Container(id="motors"):
                    with Vertical(classes="panel"):
                        yield Static("Motor Dynamics", classes="panel-title")
                        yield Static("", id="motor-dynamics")
                    yield MotorTuning(id="motor-tuning", classes="motor-tuning")

                # -- NVS Config sub-mode --
                with Container(id="nvs"):
                    yield NvsFilter(id="nvs-filter", classes="nvs-filter")
                    with Vertical(classes="panel"):
                        yield NvsTable(id="nvs-table")
                    with Horizontal(classes="bottom-controls"):
                        yield Button(
                            "Refresh NVS",
                            id="btn-refresh-nvs",
                            variant="primary",
                        )
                        yield Button("Export NVS JSON", id="btn-export-nvs")

    # ------------------------------------------------------------------
    # Mode switching
    # ------------------------------------------------------------------

    def on_mode_bar_mode_changed(self, event: ModeBar.ModeChanged) -> None:
        """Switch the system sub-mode ContentSwitcher."""
        self.query_one("#system-modes", ContentSwitcher).current = event.mode

    # ------------------------------------------------------------------
    # Device wiring
    # ------------------------------------------------------------------

    def set_device(self, device: DeviceLike) -> None:
        """Store the device reference and trigger an initial refresh."""
        self._device = device
        # Only auto-refresh if we're already mounted (widget tree exists).
        try:
            self.query_one("#firmware-info")
            self._do_system_refresh()
        except Exception:
            # Not mounted yet -- on_show will handle it.
            pass

    def on_show(self) -> None:
        """Called when this screen becomes visible via ContentSwitcher."""
        if self._device is not None and not self._refreshed:
            self._do_system_refresh()

    def on_position_update(self, az: float, el: float) -> None:
        """System screen does not need position updates."""

    # ------------------------------------------------------------------
    # System refresh worker (all panels)
    # ------------------------------------------------------------------

    @work(thread=True)
    def _do_system_refresh(self) -> None:
        """Fetch all system data from the device in a background thread."""
        worker = get_current_worker()
        device = self._device
        if device is None:
            return

        # 1. Firmware identification.
        try:
            fw_raw = device.get_firmware_id()
            fw_text = _parse_firmware_info(fw_raw)
            self.app.call_from_thread(
                self.query_one("#firmware-info", Static).update, fw_text
            )
        except Exception:
            log.exception("Failed to read firmware ID")
            self.app.call_from_thread(
                self.query_one("#firmware-info", Static).update,
                Text("FW: error reading firmware ID", style="#e04040"),
            )

        if worker.is_cancelled:
            return

        # 2. A3981 diagnostics.
        try:
            diag = device.get_a3981_diag()
            modes = device.get_a3981_modes()
            torque = device.get_a3981_torque()
            a3981_text = _format_a3981(diag, modes, torque)
            self.app.call_from_thread(
                self.query_one("#a3981-diag", Static).update, a3981_text
            )
        except Exception:
            log.exception("Failed to read A3981 data")
            self.app.call_from_thread(
                self.query_one("#a3981-diag", Static).update,
                Text("Error reading A3981 diagnostics", style="#e04040"),
            )

        if worker.is_cancelled:
            return

        # 3. Motor dynamics.
        try:
            dynamics = device.get_motor_dynamics()
            el_limits = device.get_el_limits()
            motor_text = _format_motor_dynamics(dynamics, el_limits)
            self.app.call_from_thread(
                self.query_one("#motor-dynamics", Static).update, motor_text
            )
        except Exception:
            log.exception("Failed to read motor dynamics")
            self.app.call_from_thread(
                self.query_one("#motor-dynamics", Static).update,
                Text("Error reading motor dynamics", style="#e04040"),
            )

        # 3b. PID gains (populate the tuning widget).
        try:
            gains = device.get_pid_gains()
            az_g = gains.get("az", {})
            el_g = gains.get("el", {})
            self.app.call_from_thread(
                self._apply_pid_gains,
                az_g.get("kp", 600),
                az_g.get("kv", 60),
                az_g.get("ki", 1),
                el_g.get("kp", 250),
                el_g.get("kv", 50),
                el_g.get("ki", 1),
            )
        except Exception:
            log.debug("PID gain read failed", exc_info=True)

        if worker.is_cancelled:
            return

        # 4. NVS dump.
        try:
            nvs_text = device.nvs_dump()
            self._nvs_raw = nvs_text
            nvs_table = self.query_one("#nvs-table", NvsTable)
            self.app.call_from_thread(nvs_table.load_nvs, nvs_text)
            # Cache parsed rows for filtering.
            self.app.call_from_thread(self._cache_nvs_rows)
        except Exception:
            log.exception("Failed to dump NVS")
            self.app.call_from_thread(
                self.app.notify, "NVS dump failed", severity="error"
            )

        self._refreshed = True

    def _apply_pid_gains(
        self,
        az_kp: float,
        az_kv: float,
        az_ki: float,
        el_kp: float,
        el_kv: float,
        el_ki: float,
    ) -> None:
        """Push device-reported PID gains into the MotorTuning widget inputs."""
        tuning = self.query_one("#motor-tuning", MotorTuning)
        tuning.load_gains(az_kp, az_kv, az_ki, el_kp, el_kv, el_ki)

    def _cache_nvs_rows(self) -> None:
        """Snapshot parsed NVS rows from the table for filter operations."""
        nvs_table = self.query_one("#nvs-table", NvsTable)
        self._nvs_parsed = nvs_table.parsed_rows

    # ------------------------------------------------------------------
    # NVS-only refresh worker
    # ------------------------------------------------------------------

    @work(thread=True)
    def _do_nvs_refresh(self) -> None:
        """Refresh just the NVS table without touching other panels."""
        device = self._device
        if device is None:
            return

        try:
            nvs_text = device.nvs_dump()
            self._nvs_raw = nvs_text
            nvs_table = self.query_one("#nvs-table", NvsTable)
            self.app.call_from_thread(nvs_table.load_nvs, nvs_text)
            self.app.call_from_thread(self._cache_nvs_rows)
            self.app.call_from_thread(self.app.notify, "NVS table refreshed")
        except Exception:
            log.exception("Failed to refresh NVS")
            self.app.call_from_thread(
                self.app.notify, "NVS refresh failed", severity="error"
            )

    # ------------------------------------------------------------------
    # A3981 fault reset worker
    # ------------------------------------------------------------------

    @work(thread=True)
    def _do_a3981_reset(self) -> None:
        """Reset A3981 fault flags via the A3981 submenu."""
        device = self._device
        if device is None:
            return

        try:
            device.send_raw("a3981")
            device.send_raw("reset")
            device.send_raw("q")
            self.app.call_from_thread(self.app.notify, "A3981 faults reset")
            # Re-read diagnostics after reset.
            try:
                diag = device.get_a3981_diag()
                modes = device.get_a3981_modes()
                torque = device.get_a3981_torque()
                a3981_text = _format_a3981(diag, modes, torque)
                self.app.call_from_thread(
                    self.query_one("#a3981-diag", Static).update, a3981_text
                )
            except Exception:
                log.debug("A3981 re-read after reset failed", exc_info=True)
        except Exception:
            log.exception("A3981 fault reset failed")
            self.app.call_from_thread(
                self.app.notify, "A3981 reset failed", severity="error"
            )

    # ------------------------------------------------------------------
    # NVS filter handler
    # ------------------------------------------------------------------

    def on_nvs_filter_filter_changed(self, event: NvsFilter.FilterChanged) -> None:
        """Re-filter the NVS table based on search text and modified toggle."""
        self._apply_nvs_filter(event.text, event.modified_only)

    def _apply_nvs_filter(self, text: str, modified_only: bool) -> None:
        """Clear the NVS DataTable and re-add only matching rows."""
        nvs_table = self.query_one("#nvs-table", NvsTable)
        nvs_table.clear()

        needle = text.strip().lower()

        for row in self._nvs_parsed:
            # Modified-only filter: skip rows where current == default.
            if modified_only and row["current"] == row["default"]:
                continue

            # Text filter: match against index or name (case-insensitive).
            if needle:
                idx_match = needle in row["idx"].lower()
                name_match = needle in row["name"].lower()
                if not (idx_match or name_match):
                    continue

            # Row passes all filters -- add it to the table.
            modified = row["current"] != row["default"]
            label = f"*{row['idx']}" if modified else row["idx"]
            nvs_table.add_row(
                label,
                row["name"],
                row["current"],
                row["saved"],
                row["default"],
                key=f"nvs-{row['idx']}",
            )

    # ------------------------------------------------------------------
    # Button handlers
    # ------------------------------------------------------------------

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""

        if button_id == "btn-refresh-all":
            self._handle_refresh_all()
        elif button_id == "btn-refresh-nvs":
            self._handle_refresh_nvs()
        elif button_id == "btn-export-nvs":
            self._export_nvs_json()
        elif button_id == "btn-reset-a3981":
            self._handle_reset_a3981()

    def _handle_refresh_all(self) -> None:
        """Kick off a full system refresh."""
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return
        self._refreshed = False
        self._do_system_refresh()

    def _handle_refresh_nvs(self) -> None:
        """Kick off an NVS-only refresh."""
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return
        self._do_nvs_refresh()

    def _handle_reset_a3981(self) -> None:
        """Reset A3981 stepper driver fault flags."""
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return
        self._do_a3981_reset()

    def _export_nvs_json(self) -> None:
        """Export parsed NVS rows to /tmp/birdcage_nvs.json."""
        rows = self._nvs_parsed

        if not rows:
            self.app.notify(
                "No NVS data to export -- refresh first", severity="warning"
            )
            return

        output = Path("/tmp/birdcage_nvs.json")
        try:
            with output.open("w") as fh:
                json.dump(rows, fh, indent=2)
            self.app.notify(f"Exported {len(rows)} NVS entries to {output}")
        except OSError as exc:
            log.exception("NVS JSON export failed")
            self.app.notify(f"Export failed: {exc}", severity="error")

    # ------------------------------------------------------------------
    # Motor tuning handler
    # ------------------------------------------------------------------

    def on_motor_tuning_apply_requested(
        self, event: MotorTuning.ApplyRequested
    ) -> None:
        """Handle PID gain apply request from the MotorTuning widget."""
        if self._device is None:
            self.app.notify("No device connected", severity="warning")
            return
        log.info(
            "PID apply requested: AZ(%.0f/%.0f/%.0f) EL(%.0f/%.0f/%.0f)",
            event.az_kp,
            event.az_kv,
            event.az_ki,
            event.el_kp,
            event.el_kv,
            event.el_ki,
        )
        self._do_pid_write(
            event.az_kp,
            event.az_kv,
            event.az_ki,
            event.el_kp,
            event.el_kv,
            event.el_ki,
        )

    @work(thread=True)
    def _do_pid_write(
        self,
        az_kp: float,
        az_kv: float,
        az_ki: float,
        el_kp: float,
        el_kv: float,
        el_ki: float,
    ) -> None:
        """Write PID gains to both motor axes in a worker thread."""
        device = self._device
        if device is None:
            return
        try:
            device.set_pid_gains(0, az_kp, az_kv, az_ki)
            device.set_pid_gains(1, el_kp, el_kv, el_ki)
            self.app.call_from_thread(self.app.notify, "PID gains applied to AZ + EL")
        except Exception:
            log.exception("PID write failed")
            self.app.call_from_thread(
                self.app.notify, "PID write failed", severity="error"
            )
