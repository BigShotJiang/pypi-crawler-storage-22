"""Compass rose widget — visual AZ/EL position display with Unicode compass dial."""

from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static

# Compass grid layout: 11 columns x 7 rows.
# Positions indexed [row][col] where (0,0) is top-left.
# Cardinal/intercardinal markers are placed at fixed positions.
# The pointer occupies one of 16 perimeter slots based on azimuth.

# 16-slot perimeter positions (clockwise from N=0):
# Each entry is (row, col) on the 11x7 grid.
_POINTER_SLOTS: list[tuple[int, int]] = [
    (0, 5),  #  0: N
    (0, 7),  #  1: NNE
    (1, 9),  #  2: NE
    (2, 10),  #  3: ENE
    (3, 10),  #  4: E
    (4, 10),  #  5: ESE
    (5, 9),  #  6: SE
    (6, 7),  #  7: SSE
    (6, 5),  #  8: S
    (6, 3),  #  9: SSW
    (5, 1),  # 10: SW
    (4, 0),  # 11: WSW
    (3, 0),  # 12: W
    (2, 0),  # 13: WNW
    (1, 1),  # 14: NW
    (0, 3),  # 15: NNW
]

# Fixed cardinal/intercardinal label positions: (row, col, label)
_LABELS: list[tuple[int, int, str]] = [
    (0, 5, "N"),
    (3, 10, "E"),
    (6, 5, "S"),
    (3, 0, "W"),
]

# Ring structure characters for the compass dial.
_RING_CHARS: dict[tuple[int, int], str] = {
    # Top arc
    (0, 3): ".",
    (0, 4): "\u2500",
    (0, 6): "\u2500",
    (0, 7): ".",
    # Upper sides
    (1, 1): "/",
    (1, 9): "\\",
    # Mid-upper sides
    (2, 0): "\u2502",
    (2, 10): "\u2502",
    # Center sides (cardinals placed separately)
    # (3, 0) and (3, 10) reserved for W/E labels
    # Lower-mid sides
    (4, 0): "\u2502",
    (4, 10): "\u2502",
    # Lower sides
    (5, 1): "\\",
    (5, 9): "/",
    # Bottom arc
    (6, 3): "'",
    (6, 4): "\u2500",
    (6, 6): "\u2500",
    (6, 7): "'",
}


def _azimuth_to_slot(az: float) -> int:
    """Map azimuth (0-360, 0=N clockwise) to one of 16 perimeter slots."""
    normalized = az % 360.0
    slot = round(normalized / 22.5) % 16
    return slot


class CompassRose(Static):
    """Visual compass display showing azimuth/elevation position."""

    azimuth: reactive[float] = reactive(180.0)
    elevation: reactive[float] = reactive(45.0)

    def render(self) -> Text:
        result = Text()

        # Large numeric readout
        az_label = Text("AZ ", style="#506878 bold")
        az_value = Text(f"{self.azimuth:7.2f}\u00b0", style="#00d4aa bold")
        el_label = Text("  EL ", style="#506878 bold")
        el_value = Text(f"{self.elevation:6.2f}\u00b0", style="#00d4aa bold")

        result.append(az_label)
        result.append(az_value)
        result.append(el_label)
        result.append(el_value)
        result.append("\n\n")

        # Build the 7x11 compass grid
        grid: list[list[tuple[str, str]]] = [
            [(" ", "#0e1420") for _ in range(11)] for _ in range(7)
        ]

        # Place ring structure
        for (r, c), ch in _RING_CHARS.items():
            grid[r][c] = (ch, "#c8d0d8")

        # Place cardinal labels
        for r, c, label in _LABELS:
            grid[r][c] = (label, "#506878 bold")

        # Center crosshair
        grid[3][5] = ("\u253c", "#1a2a38")
        grid[3][4] = ("\u2500", "#1a2a38")
        grid[3][6] = ("\u2500", "#1a2a38")
        grid[2][5] = ("\u2502", "#1a2a38")
        grid[4][5] = ("\u2502", "#1a2a38")

        # Place pointer at azimuth position
        slot = _azimuth_to_slot(self.azimuth)
        pr, pc = _POINTER_SLOTS[slot]
        # Use a filled diamond for the pointer
        grid[pr][pc] = ("\u25c6", "#00d4aa bold")

        # Compute a line from center toward the pointer direction for visual clarity
        # Place a dot at an intermediate position between center (3,5) and pointer
        cr, cc = 3, 5
        dr = pr - cr
        dc = pc - cc
        if abs(dr) > 1 or abs(dc) > 1:
            mr = cr + (1 if dr > 0 else (-1 if dr < 0 else 0))
            mc = cc + (1 if dc > 0 else (-1 if dc < 0 else 0))
            # Only place intermediate dot if it doesn't overwrite a label
            existing_ch = grid[mr][mc][0]
            if existing_ch in (" ", "\u2500", "\u2502", "\u253c"):
                grid[mr][mc] = ("\u2022", "#00d4aa")

        # Render grid to text
        for row_idx, row in enumerate(grid):
            for _col_idx, (ch, style) in enumerate(row):
                result.append(ch, style=style)
            if row_idx < 6:
                result.append("\n")

        # Bearing line below compass
        bearing = self.azimuth % 360.0
        if bearing < 0:
            bearing += 360.0
        cardinal = _bearing_to_cardinal(bearing)
        result.append("\n")
        result.append(f"  {cardinal:>5s}", style="#506878")
        result.append(f"  {bearing:05.1f}\u00b0", style="#c8d0d8")

        return result

    def watch_azimuth(self, _value: float) -> None:
        self.refresh()

    def watch_elevation(self, _value: float) -> None:
        self.refresh()


def _bearing_to_cardinal(bearing: float) -> str:
    """Convert bearing in degrees to 16-point cardinal abbreviation."""
    directions = [
        "N",
        "NNE",
        "NE",
        "ENE",
        "E",
        "ESE",
        "SE",
        "SSE",
        "S",
        "SSW",
        "SW",
        "WSW",
        "W",
        "WNW",
        "NW",
        "NNW",
    ]
    idx = round(bearing / 22.5) % 16
    return directions[idx]
