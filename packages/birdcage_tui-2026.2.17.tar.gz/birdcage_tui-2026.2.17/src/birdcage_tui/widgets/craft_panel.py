"""Craft tracking panel — search, pass predictions, and live satellite tracking.

Provides the UI surface for the Craft API integration. Posts messages
upward to ControlScreen which handles the actual HTTP calls and motor
commands in worker threads.
"""

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.message import Message
from textual.reactive import reactive
from textual.widgets import Button, DataTable, Input, Static


class CraftPanel(Container):
    """Panel for Craft satellite tracking — search, passes, and live track.

    All heavy lifting (HTTP calls, motor commands) is handled by the parent
    ControlScreen. This widget is the control surface only.
    """

    class SearchRequested(Message):
        def __init__(self, query: str) -> None:
            super().__init__()
            self.query = query

    class TrackRequested(Message):
        def __init__(
            self,
            target_type: str,
            target_id: str,
            name: str,
            min_el: float,
        ) -> None:
            super().__init__()
            self.target_type = target_type
            self.target_id = target_id
            self.name = name
            self.min_el = min_el

    class StopTrackingRequested(Message):
        pass

    class PassesRequested(Message):
        def __init__(self, norad_id: int) -> None:
            super().__init__()
            self.norad_id = norad_id

    def compose(self) -> ComposeResult:
        with Horizontal(classes="craft-search-bar"):
            yield Input(
                placeholder="Search satellites, planets...",
                id="craft-search-input",
            )
            yield Button("Search", id="btn-craft-search", variant="primary")
        yield DataTable(id="craft-results-table")
        yield CraftPassInfo(id="craft-pass-info")
        yield CraftTrackingStatus(id="craft-tracking-status")
        with Horizontal(classes="craft-controls"):
            yield Button("Track", id="btn-craft-track", variant="primary")
            yield Button("Stop", id="btn-craft-stop")
            yield Button("Passes", id="btn-craft-passes")
            yield Static(" Min EL: ", classes="label")
            yield Input(value="18.0", id="craft-minel-input", type="number")

    def on_mount(self) -> None:
        table = self.query_one("#craft-results-table", DataTable)
        table.add_columns("Name", "Type", "ID", "Groups")
        table.cursor_type = "row"
        table.zebra_stripes = True

    # ------------------------------------------------------------------
    # Public API (called by ControlScreen)
    # ------------------------------------------------------------------

    def set_search_results(self, results: list[dict]) -> None:
        """Populate the results table from search data."""
        table = self.query_one("#craft-results-table", DataTable)
        table.clear()
        for r in results:
            groups = ", ".join(r.get("groups", []))
            table.add_row(
                r.get("name", ""),
                r.get("target_type", ""),
                str(r.get("target_id", "")),
                groups,
                key=f"{r.get('target_type', '')}:{r.get('target_id', '')}",
            )

    def set_passes(self, passes_text: str) -> None:
        """Update the pass prediction display."""
        info = self.query_one("#craft-pass-info", CraftPassInfo)
        info.passes_text = passes_text

    def set_tracking_status(
        self,
        state: str = "IDLE",
        target_name: str = "",
        azimuth: float = 0.0,
        elevation: float = 0.0,
        distance_km: float = 0.0,
        range_rate: float = 0.0,
        moves: int = 0,
        rate: float = 0.0,
        error: str = "",
    ) -> None:
        """Update the tracking status display."""
        status = self.query_one("#craft-tracking-status", CraftTrackingStatus)
        status.state = state
        status.target_name = target_name
        status.azimuth = azimuth
        status.elevation = elevation
        status.distance_km = distance_km
        status.range_rate = range_rate
        status.moves = moves
        status.rate = rate
        status.error = error

    # ------------------------------------------------------------------
    # Selected row helpers
    # ------------------------------------------------------------------

    def _get_selected_row(self) -> dict | None:
        """Return the selected row's data as a dict, or None."""
        table = self.query_one("#craft-results-table", DataTable)
        if table.row_count == 0:
            return None
        try:
            row_key, _ = table.coordinate_to_cell_key(table.cursor_coordinate)
        except Exception:
            return None
        row = table.get_row(row_key)
        if not row:
            return None
        return {
            "name": row[0],
            "target_type": row[1],
            "target_id": row[2],
        }

    # ------------------------------------------------------------------
    # Button handlers
    # ------------------------------------------------------------------

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""

        if button_id == "btn-craft-search":
            self._handle_search()
        elif button_id == "btn-craft-track":
            self._handle_track()
        elif button_id == "btn-craft-stop":
            self._handle_stop()
        elif button_id == "btn-craft-passes":
            self._handle_passes()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "craft-search-input":
            self._handle_search()

    def _handle_search(self) -> None:
        query = self.query_one("#craft-search-input", Input).value.strip()
        if not query:
            self.app.notify("Enter a search term", severity="warning")
            return
        self.post_message(self.SearchRequested(query))

    def _handle_track(self) -> None:
        row = self._get_selected_row()
        if row is None:
            self.app.notify("Select a target first", severity="warning")
            return

        try:
            min_el = float(self.query_one("#craft-minel-input", Input).value)
        except ValueError:
            min_el = 18.0

        self.post_message(
            self.TrackRequested(
                target_type=row["target_type"],
                target_id=row["target_id"],
                name=row["name"],
                min_el=min_el,
            )
        )

    def _handle_stop(self) -> None:
        self.post_message(self.StopTrackingRequested())

    def _handle_passes(self) -> None:
        row = self._get_selected_row()
        if row is None:
            self.app.notify("Select a satellite first", severity="warning")
            return
        if row["target_type"] != "satellite":
            self.app.notify("Pass predictions require a satellite", severity="warning")
            return
        self.post_message(self.PassesRequested(norad_id=int(row["target_id"])))


class CraftTrackingStatus(Static):
    """Rich text display of Craft tracking state."""

    state: reactive[str] = reactive("IDLE")
    target_name: reactive[str] = reactive("")
    azimuth: reactive[float] = reactive(0.0)
    elevation: reactive[float] = reactive(0.0)
    distance_km: reactive[float] = reactive(0.0)
    range_rate: reactive[float] = reactive(0.0)
    moves: reactive[int] = reactive(0)
    rate: reactive[float] = reactive(0.0)
    error: reactive[str] = reactive("")

    def render(self) -> Text:
        result = Text()
        w = 10

        # Status
        result.append("Status".ljust(w), style="#506878")
        if self.state == "TRACKING":
            result.append("TRACKING", style="#00e060 bold")
        elif self.state == "WAITING":
            result.append("WAITING", style="#e8a020 bold")
        elif self.state == "ERROR":
            result.append("ERROR", style="#e04040 bold")
        else:
            result.append("IDLE", style="#506878")
        result.append("\n")

        # Target
        result.append("Target".ljust(w), style="#506878")
        if self.target_name:
            result.append(self.target_name, style="#c8d0d8")
        else:
            result.append("(none)", style="#384858")
        result.append("\n")

        # Position
        result.append("Sat AZ".ljust(w), style="#506878")
        result.append(f"{self.azimuth:.2f}", style="#00d4aa")
        result.append("   Sat EL  ", style="#506878")
        result.append(f"{self.elevation:.2f}", style="#00d4aa")
        result.append("\n")

        # Distance + range rate
        result.append("Dist".ljust(w), style="#506878")
        result.append(f"{self.distance_km:.0f} km", style="#c8d0d8")
        result.append("   Rate: ", style="#506878")
        rate_style = "#e04040" if self.range_rate > 0 else "#00e060"
        result.append(f"{self.range_rate:+.1f} km/s", style=rate_style)
        result.append("\n")

        # Move stats
        result.append("Moves".ljust(w), style="#506878")
        result.append(f"{self.moves}", style="#c8d0d8")
        result.append("   Rate: ", style="#506878")
        result.append(f"{self.rate:.1f}/s", style="#c8d0d8")

        # Error
        if self.error:
            result.append("\n")
            result.append("Error".ljust(w), style="#506878")
            result.append(self.error, style="#e04040")

        return result

    def watch_state(self, _v: str) -> None:
        self.refresh()

    def watch_target_name(self, _v: str) -> None:
        self.refresh()

    def watch_azimuth(self, _v: float) -> None:
        self.refresh()

    def watch_elevation(self, _v: float) -> None:
        self.refresh()

    def watch_distance_km(self, _v: float) -> None:
        self.refresh()

    def watch_range_rate(self, _v: float) -> None:
        self.refresh()

    def watch_moves(self, _v: int) -> None:
        self.refresh()

    def watch_rate(self, _v: float) -> None:
        self.refresh()

    def watch_error(self, _v: str) -> None:
        self.refresh()


class CraftPassInfo(Static):
    """Display upcoming pass predictions as formatted text."""

    passes_text: reactive[str] = reactive("")

    def render(self) -> Text:
        result = Text()
        result.append("Upcoming Passes\n", style="#00d4aa bold")
        if self.passes_text:
            result.append(self.passes_text, style="#c8d0d8")
        else:
            result.append("(search and select a satellite)", style="#384858")
        return result

    def watch_passes_text(self, _v: str) -> None:
        self.refresh()
