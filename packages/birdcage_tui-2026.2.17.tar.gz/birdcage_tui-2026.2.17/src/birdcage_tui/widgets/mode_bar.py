"""Mode bar widget -- button bar for ContentSwitcher sub-modes."""

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.message import Message
from textual.widgets import Button


class ModeBar(Horizontal):
    """Horizontal bar of toggle buttons that switch a ContentSwitcher.

    Used inside screens to switch between sub-modes (e.g., Manual/Presets/Track
    within the Control screen, or Monitor/Sweep/SkyMap within Signal).

    Posts a ``ModeBar.ModeChanged`` message when the active mode changes.
    The parent screen should watch for this and update its ContentSwitcher.
    """

    class ModeChanged(Message):
        """Posted when the user selects a different mode."""

        def __init__(self, mode: str) -> None:
            super().__init__()
            self.mode = mode

    def __init__(
        self,
        modes: dict[str, str],
        initial: str | None = None,
        **kwargs,
    ) -> None:
        """Create a mode bar.

        Args:
            modes: Mapping of mode_key -> display label.
            initial: Which mode to highlight initially. Defaults to the first key.
        """
        super().__init__(**kwargs)
        self._modes = modes
        self._initial = initial or next(iter(modes))

    def compose(self) -> ComposeResult:
        for key, label in self._modes.items():
            btn = Button(label, id=f"mode-{key}", classes="mode-btn")
            if key == self._initial:
                btn.add_class("active")
            yield btn

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""
        if not button_id.startswith("mode-"):
            return

        mode = button_id.removeprefix("mode-")
        if mode not in self._modes:
            return

        # Update button highlight
        for btn in self.query(".mode-btn"):
            btn.remove_class("active")
        event.button.add_class("active")

        self.post_message(self.ModeChanged(mode))
        event.stop()

    @property
    def active_mode(self) -> str:
        """Return the currently active mode key."""
        for btn in self.query(".mode-btn.active"):
            btn_id = btn.id or ""
            return btn_id.removeprefix("mode-")
        return self._initial
