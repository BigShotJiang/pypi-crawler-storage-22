"""Motor status widget — engagement state, torque, step counts, and EL range."""

from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static


class MotorStatus(Static):
    """Panel showing motor engagement state, torque, and step counts."""

    engaged: reactive[bool] = reactive(False)
    az_torque: reactive[str] = reactive("LOW")
    el_torque: reactive[str] = reactive("LOW")
    az_steps: reactive[int] = reactive(0)
    el_steps: reactive[int] = reactive(0)
    el_min: reactive[float] = reactive(18.0)
    el_max: reactive[float] = reactive(65.0)

    def render(self) -> Text:
        result = Text()
        label_w = 10

        # Engaged row
        result.append("Engaged".ljust(label_w), style="#506878")
        if self.engaged:
            result.append("YES", style="#00e060 bold")
        else:
            result.append("NO", style="#e04040")
        result.append("\n")

        # Torque row
        result.append("Torque".ljust(label_w), style="#506878")
        result.append("AZ: ", style="#506878")
        az_style = "#e8c020 bold" if self.az_torque == "HIGH" else "#c8d0d8"
        result.append(f"{self.az_torque}", style=az_style)
        result.append("  EL: ", style="#506878")
        el_style = "#e8c020 bold" if self.el_torque == "HIGH" else "#c8d0d8"
        result.append(f"{self.el_torque}", style=el_style)
        result.append("\n")

        # Steps row
        result.append("Steps".ljust(label_w), style="#506878")
        result.append("AZ: ", style="#506878")
        result.append(f"{self.az_steps}", style="#c8d0d8")
        result.append("  EL: ", style="#506878")
        result.append(f"{self.el_steps}", style="#c8d0d8")
        result.append("\n")

        # EL Range row
        result.append("EL Range".ljust(label_w), style="#506878")
        result.append(f"{self.el_min:.1f}\u00b0", style="#c8d0d8")
        result.append(" \u2013 ", style="#506878")
        result.append(f"{self.el_max:.1f}\u00b0", style="#c8d0d8")

        return result

    def watch_engaged(self, _value: bool) -> None:
        self.refresh()

    def watch_az_torque(self, _value: str) -> None:
        self.refresh()

    def watch_el_torque(self, _value: str) -> None:
        self.refresh()

    def watch_az_steps(self, _value: int) -> None:
        self.refresh()

    def watch_el_steps(self, _value: int) -> None:
        self.refresh()

    def watch_el_min(self, _value: float) -> None:
        self.refresh()

    def watch_el_max(self, _value: float) -> None:
        self.refresh()
