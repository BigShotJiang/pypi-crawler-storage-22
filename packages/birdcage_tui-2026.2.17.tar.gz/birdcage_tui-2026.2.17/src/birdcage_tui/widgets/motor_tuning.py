"""Motor tuning widget -- PID gain editor for AZ and EL motor control loops."""

from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.message import Message
from textual.widgets import Button, Input, Static


class MotorTuning(Container):
    """PID gain editor for AZ and EL motor control loops.

    Displays two rows of labeled inputs (Kp, Kv, Ki for each axis) and an
    Apply button. The button uses ``variant="warning"`` because writing PID
    gains takes effect immediately on the live motor control loop.

    The parent screen should confirm the action before sending the values
    to the firmware via ``mot pid <motor> <Kp> <Kv> <Ki>``.
    """

    class ApplyRequested(Message):
        """Posted when the user clicks Apply PID.

        The parent screen should validate and confirm before writing to
        the firmware, since PID changes affect motor behavior immediately.
        """

        def __init__(
            self,
            az_kp: float,
            az_kv: float,
            az_ki: float,
            el_kp: float,
            el_kv: float,
            el_ki: float,
        ) -> None:
            super().__init__()
            self.az_kp = az_kp
            self.az_kv = az_kv
            self.az_ki = az_ki
            self.el_kp = el_kp
            self.el_kv = el_kv
            self.el_ki = el_ki

    def compose(self) -> ComposeResult:
        yield Static("PID Tuning", classes="panel-title")

        with Vertical():
            # AZ row
            with Horizontal(classes="pid-row"):
                yield Static("AZ", classes="pid-axis-label")
                yield Static("Kp:", classes="pid-gain-label")
                yield Input(value="600", id="pid-az-kp", type="number")
                yield Static("Kv:", classes="pid-gain-label")
                yield Input(value="60", id="pid-az-kv", type="number")
                yield Static("Ki:", classes="pid-gain-label")
                yield Input(value="1", id="pid-az-ki", type="number")

            # EL row
            with Horizontal(classes="pid-row"):
                yield Static("EL", classes="pid-axis-label")
                yield Static("Kp:", classes="pid-gain-label")
                yield Input(value="250", id="pid-el-kp", type="number")
                yield Static("Kv:", classes="pid-gain-label")
                yield Input(value="50", id="pid-el-kv", type="number")
                yield Static("Ki:", classes="pid-gain-label")
                yield Input(value="1", id="pid-el-ki", type="number")

            # Button row
            with Horizontal(classes="pid-button-row"):
                yield Button(
                    "Apply PID",
                    id="pid-apply",
                    variant="warning",
                )

    def load_gains(
        self,
        az_kp: float,
        az_kv: float,
        az_ki: float,
        el_kp: float,
        el_kv: float,
        el_ki: float,
    ) -> None:
        """Populate all input fields from device-reported PID gains.

        Args:
            az_kp: Azimuth proportional gain.
            az_kv: Azimuth velocity gain.
            az_ki: Azimuth integral gain.
            el_kp: Elevation proportional gain.
            el_kv: Elevation velocity gain.
            el_ki: Elevation integral gain.
        """
        self.query_one("#pid-az-kp", Input).value = str(int(az_kp))
        self.query_one("#pid-az-kv", Input).value = str(int(az_kv))
        self.query_one("#pid-az-ki", Input).value = str(int(az_ki))
        self.query_one("#pid-el-kp", Input).value = str(int(el_kp))
        self.query_one("#pid-el-kv", Input).value = str(int(el_kv))
        self.query_one("#pid-el-ki", Input).value = str(int(el_ki))

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle the Apply PID button press."""
        if event.button.id != "pid-apply":
            return

        try:
            az_kp = float(self.query_one("#pid-az-kp", Input).value)
            az_kv = float(self.query_one("#pid-az-kv", Input).value)
            az_ki = float(self.query_one("#pid-az-ki", Input).value)
            el_kp = float(self.query_one("#pid-el-kp", Input).value)
            el_kv = float(self.query_one("#pid-el-kv", Input).value)
            el_ki = float(self.query_one("#pid-el-ki", Input).value)
        except ValueError:
            # Non-numeric input -- do not post the message.
            # The Input widget's type="number" constraint should prevent this
            # in normal usage, but guard against edge cases.
            return

        self.post_message(
            self.ApplyRequested(
                az_kp=az_kp,
                az_kv=az_kv,
                az_ki=az_ki,
                el_kp=el_kp,
                el_kv=el_kv,
                el_ki=el_ki,
            )
        )
        event.stop()
