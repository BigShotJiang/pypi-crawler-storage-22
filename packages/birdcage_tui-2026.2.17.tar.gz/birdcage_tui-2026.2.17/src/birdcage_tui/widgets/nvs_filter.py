"""NVS filter widget -- text search and modified-only toggle for NVS table filtering."""

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.message import Message
from textual.widgets import Checkbox, Input, Static


class NvsFilter(Horizontal):
    """Filter bar for the NVS table: text search + show-modified-only toggle.

    Composes a label, text input for searching NVS entries by name or index,
    and a checkbox to restrict display to entries where current != default.

    Posts ``NvsFilter.FilterChanged`` when either control changes, so the
    parent screen can re-filter the NVS DataTable rows.
    """

    class FilterChanged(Message):
        """Posted when the filter text or modified-only toggle changes."""

        def __init__(self, text: str, modified_only: bool) -> None:
            super().__init__()
            self.text = text
            self.modified_only = modified_only

    def compose(self) -> ComposeResult:
        yield Static("Filter: ", classes="label")
        yield Input(
            placeholder="search by name or index...",
            id="nvs-filter-input",
        )
        yield Checkbox(
            "Modified only",
            id="nvs-filter-modified",
            value=False,
        )

    def on_input_changed(self, event: Input.Changed) -> None:
        """Re-post filter state when search text changes."""
        if event.input.id != "nvs-filter-input":
            return
        self._post_filter()
        event.stop()

    def on_checkbox_changed(self, event: Checkbox.Changed) -> None:
        """Re-post filter state when the modified-only toggle changes."""
        if event.checkbox.id != "nvs-filter-modified":
            return
        self._post_filter()
        event.stop()

    def _post_filter(self) -> None:
        """Read current control values and post a FilterChanged message."""
        text_input = self.query_one("#nvs-filter-input", Input)
        checkbox = self.query_one("#nvs-filter-modified", Checkbox)
        self.post_message(
            self.FilterChanged(
                text=text_input.value,
                modified_only=checkbox.value,
            )
        )

    @property
    def filter_text(self) -> str:
        """Current text in the search input."""
        return self.query_one("#nvs-filter-input", Input).value

    @property
    def modified_only(self) -> bool:
        """Whether the modified-only checkbox is checked."""
        return self.query_one("#nvs-filter-modified", Checkbox).value
