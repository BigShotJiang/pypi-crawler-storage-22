"""NVS table widget — DataTable wrapper for non-volatile storage dump display."""

import re

from textual.widgets import DataTable

# Regex to parse NVS dump lines.
# Examples:
#   0) Log ID's                    0x00000007  0x00000007  0x00000007
#  20) Disable Tracker Proc?       TRUE        TRUE        FALSE
# 101) Minimum Elevation Angle     18.00       18.00       18.00
_NVS_LINE_RE = re.compile(
    r"^\s*(\d+)\)\s+"  # index with closing paren
    r"(.+?)\s{2,}"  # name (greedy until 2+ spaces)
    r"(\S+)\s+"  # current value
    r"(\S+)\s+"  # saved value
    r"(\S+)\s*$"  # default value
)


class NvsTable(DataTable):
    """DataTable displaying NVS (non-volatile storage) dump data."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._parsed_rows: list[dict[str, str]] = []
        self._columns_added = False

    def on_mount(self) -> None:
        """Add columns when the widget is mounted."""
        if not self._columns_added:
            self.add_columns("Idx", "Name", "Current", "Saved", "Default")
            self._columns_added = True

    def load_nvs(self, text: str) -> list[dict[str, str]]:
        """Parse NVS dump text and populate the table.

        Returns a list of dicts with keys: idx, name, current, saved, default.
        Rows where current != default are marked for the screen to highlight.
        """
        self.clear_table()
        self._parsed_rows = []

        for line in text.splitlines():
            line = line.rstrip()
            if not line:
                continue

            match = _NVS_LINE_RE.match(line)
            if not match:
                continue

            idx = match.group(1)
            name = match.group(2).strip()
            current = match.group(3)
            saved = match.group(4)
            default = match.group(5)

            row_data = {
                "idx": idx,
                "name": name,
                "current": current,
                "saved": saved,
                "default": default,
            }
            self._parsed_rows.append(row_data)

            # Add row to the DataTable
            modified = current != default
            # Prefix the index cell to signal modification to the screen.
            # The screen's CSS rule .nvs-modified handles styling.
            label = f"*{idx}" if modified else idx

            self.add_row(label, name, current, saved, default, key=f"nvs-{idx}")

        return self._parsed_rows

    def clear_table(self) -> None:
        """Remove all rows from the table."""
        self.clear()
        self._parsed_rows = []

    @property
    def parsed_rows(self) -> list[dict[str, str]]:
        """Access the most recently parsed NVS data."""
        return list(self._parsed_rows)

    @property
    def modified_indices(self) -> list[str]:
        """Return indices where current value differs from default."""
        return [
            row["idx"] for row in self._parsed_rows if row["current"] != row["default"]
        ]
