"""Preset list widget -- saved AZ/EL target presets backed by JSON file."""

import json
import logging
from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.message import Message
from textual.widgets import Button, DataTable, Input

log = logging.getLogger(__name__)

PRESETS_PATH = Path.home() / ".config" / "birdcage" / "presets.json"


class PresetList(Container):
    """DataTable of saved AZ/EL presets with save/go/delete actions.

    File format::

        {
            "targets": [
                {"name": "Zenith", "az": null, "el": 65.0, "notes": "EL-only"},
                {"name": "South", "az": 180.0, "el": 45.0, "notes": ""}
            ]
        }

    An ``az`` value of ``null`` means "don't move AZ" (EL-only targets).
    """

    class GoToPreset(Message):
        """Posted when the user presses Go on a selected preset."""

        def __init__(self, az: float | None, el: float) -> None:
            super().__init__()
            self.az = az
            self.el = el

    class SaveRequested(Message):
        """Posted when the user presses Save Current.

        The parent screen should read the current position and call
        ``save_preset()`` with a name and the current AZ/EL.
        """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._presets: list[dict] = []
        self._table_ready = False

    def compose(self) -> ComposeResult:
        yield DataTable(id="preset-table")
        with Horizontal(classes="preset-controls"):
            yield Input(placeholder="Preset name", id="preset-name-input")
            yield Button("Save Current", id="btn-preset-save")
            yield Button("Go", id="btn-preset-go")
            yield Button("Delete", id="btn-preset-delete")

    def on_mount(self) -> None:
        """Add columns and load presets when mounted."""
        table = self.query_one("#preset-table", DataTable)
        table.add_columns("Name", "AZ", "EL", "Notes")
        table.cursor_type = "row"
        self._table_ready = True
        self.load_presets()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def load_presets(self) -> None:
        """Read presets from the JSON file and populate the table."""
        self._presets = []

        if PRESETS_PATH.exists():
            try:
                data = json.loads(PRESETS_PATH.read_text(encoding="utf-8"))
                self._presets = data.get("targets", [])
            except (json.JSONDecodeError, KeyError):
                log.warning("Failed to parse presets file: %s", PRESETS_PATH)

        self._rebuild_table()

    def _write_presets(self) -> None:
        """Write the current presets list to the JSON file."""
        PRESETS_PATH.parent.mkdir(parents=True, exist_ok=True)
        data = {"targets": self._presets}
        PRESETS_PATH.write_text(
            json.dumps(data, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def _rebuild_table(self) -> None:
        """Clear and repopulate the DataTable from the in-memory presets list."""
        if not self._table_ready:
            return

        table = self.query_one("#preset-table", DataTable)
        table.clear()

        for idx, preset in enumerate(self._presets):
            name = preset.get("name", f"preset-{idx}")
            az = preset.get("az")
            el = preset.get("el", 0.0)
            notes = preset.get("notes", "")

            az_str = f"{az:.1f}" if az is not None else "---"
            el_str = f"{el:.1f}"

            table.add_row(name, az_str, el_str, notes, key=f"preset-{idx}")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def save_preset(
        self,
        name: str,
        az: float | None,
        el: float,
        notes: str = "",
    ) -> None:
        """Append a new preset and persist to disk.

        Args:
            name: Human-readable label for this target.
            az: Azimuth in degrees, or None for EL-only targets.
            el: Elevation in degrees.
            notes: Optional description.
        """
        entry: dict = {
            "name": name,
            "az": az,
            "el": el,
            "notes": notes,
        }
        self._presets.append(entry)
        self._write_presets()
        self._rebuild_table()

    def delete_selected(self) -> None:
        """Remove the currently highlighted preset row."""
        table = self.query_one("#preset-table", DataTable)
        if table.row_count == 0:
            return

        row_key = table.cursor_row
        if row_key < 0 or row_key >= len(self._presets):
            return

        self._presets.pop(row_key)
        self._write_presets()
        self._rebuild_table()

    def _get_selected_preset(self) -> dict | None:
        """Return the preset dict for the currently highlighted row."""
        table = self.query_one("#preset-table", DataTable)
        if table.row_count == 0:
            return None

        row_key = table.cursor_row
        if row_key < 0 or row_key >= len(self._presets):
            return None

        return self._presets[row_key]

    @property
    def presets(self) -> list[dict]:
        """Access the current in-memory presets list."""
        return list(self._presets)

    # ------------------------------------------------------------------
    # Button handlers
    # ------------------------------------------------------------------

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""

        if button_id == "btn-preset-save":
            self._handle_save()
        elif button_id == "btn-preset-go":
            self._handle_go()
        elif button_id == "btn-preset-delete":
            self._handle_delete()

    def _handle_save(self) -> None:
        """Read the name input and post a SaveRequested message."""
        name_input = self.query_one("#preset-name-input", Input)
        name = name_input.value.strip()
        if not name:
            self.app.notify("Enter a preset name first", severity="warning")
            return
        self.post_message(self.SaveRequested())

    def _handle_go(self) -> None:
        """Post a GoToPreset message for the selected row."""
        preset = self._get_selected_preset()
        if preset is None:
            self.app.notify("No preset selected", severity="warning")
            return

        az = preset.get("az")
        el = preset.get("el", 0.0)
        self.post_message(self.GoToPreset(az=az, el=float(el)))

    def _handle_delete(self) -> None:
        """Delete the selected preset."""
        preset = self._get_selected_preset()
        if preset is None:
            self.app.notify("No preset selected", severity="warning")
            return

        name = preset.get("name", "?")
        self.delete_selected()
        self.app.notify(f"Deleted preset: {name}")
