"""Quick actions widget -- grid of task-oriented action buttons for the Dashboard."""

from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.message import Message
from textual.widgets import Button


class QuickActions(Container):
    """Grid of buttons navigating to relevant screens/modes.

    Posts an ``ActionSelected`` message when a button is pressed.
    The parent screen or app handles the actual navigation or confirmation
    (e.g., stow requires user confirmation before moving).
    """

    class ActionSelected(Message):
        """Posted when the user selects a quick action."""

        def __init__(self, action: str) -> None:
            super().__init__()
            self.action = action

    # Action definitions: (id_suffix, label, description)
    _ACTIONS: list[tuple[str, str]] = [
        ("point", "Point Dish"),
        ("monitor", "Monitor Signal"),
        ("scan", "Scan Sky"),
        ("stow", "Stow"),
    ]

    def compose(self) -> ComposeResult:
        with Horizontal(classes="quick-action-row"):
            for action_id, label in self._ACTIONS:
                yield Button(
                    label,
                    id=f"qa-{action_id}",
                    classes="quick-action-btn",
                )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""
        if not button_id.startswith("qa-"):
            return

        action = button_id.removeprefix("qa-")
        self.post_message(self.ActionSelected(action))
        event.stop()
