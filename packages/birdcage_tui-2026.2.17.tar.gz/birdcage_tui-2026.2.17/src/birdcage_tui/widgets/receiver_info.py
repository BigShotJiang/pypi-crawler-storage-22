"""Receiver info widget -- parsed DVB/RF receiver parameters display."""

import re

from rich.text import Text
from textual.widgets import Static


class ReceiverInfo(Static):
    """Displays parsed DVB receiver parameters from bridge channel/config queries.

    Call ``load_data(channel_params_text, dvb_config_text)`` to update.
    Parses the firmware's ``dis`` and ``config`` command output into a
    compact, color-coded summary of receiver state.
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._freq: str = "---"
        self._symrate: str = "---"
        self._lnb: str = "---"
        self._lock: str = "NO"
        self._bcm_id: str = "---"
        self._bcm_rev: str = ""
        self._bcm_fw: str = ""

    def load_data(
        self,
        channel_params: str = "",
        dvb_config: str = "",
    ) -> None:
        """Parse raw firmware responses and refresh the display.

        Args:
            channel_params: Raw output from DVB ``dis`` command (channel
                parameter table with Parameter/Current columns).
            dvb_config: Raw output from DVB ``config`` command (BCM
                hardware/firmware identification).
        """
        self._parse_channel_params(channel_params)
        self._parse_dvb_config(dvb_config)
        self.refresh()

    def _parse_channel_params(self, text: str) -> None:
        """Extract frequency, symbol rate, LNB state, and lock from dis output.

        The ``dis`` command returns a table-formatted output with
        "Parameter" and "Current" columns. We extract key-value pairs
        by matching known parameter names.
        """
        if not text:
            return

        # Frequency (kHz)
        freq_match = re.search(
            r"(?:freq|frequency)\s*[:\|]?\s*(\d+)", text, re.IGNORECASE
        )
        if freq_match:
            self._freq = f"{freq_match.group(1)} kHz"

        # Symbol rate
        sym_match = re.search(
            r"(?:sym(?:bol)?[\s_]*rate|ksps)\s*[:\|]?\s*(\S+)", text, re.IGNORECASE
        )
        if sym_match:
            val = sym_match.group(1)
            # May be "blind" for blind scan mode, or a numeric value
            if val.lower() in ("blind", "blind_scan", "auto"):
                self._symrate = "blind scan"
            else:
                self._symrate = f"{val} ksps"

        # LNB voltage / polarity
        lnb_match = re.search(
            r"(?:lnb|polarity|lnbdc)\s*[:\|]?\s*(.+?)(?:\r?\n|$)", text, re.IGNORECASE
        )
        if lnb_match:
            raw = lnb_match.group(1).strip()
            # Interpret voltage as polarity
            if "13" in raw:
                self._lnb = "ODU 13V (V-pol)"
            elif "18" in raw:
                self._lnb = "ODU 18V (H-pol)"
            elif raw:
                self._lnb = raw

        # Lock status
        lock_match = re.search(r"lock\s*[:\|]?\s*(\S+)", text, re.IGNORECASE)
        if lock_match:
            val = lock_match.group(1).upper()
            if val in ("1", "YES", "TRUE", "LOCKED"):
                self._lock = "YES"
            else:
                self._lock = "NO"

    def _parse_dvb_config(self, text: str) -> None:
        """Extract BCM chip ID, revision, and firmware version from config output.

        The ``config`` command returns lines like:
            BCM4515 ID 0x4515 Rev B0
            FW v113.37
        """
        if not text:
            return

        # BCM chip ID (e.g., "0x4515")
        id_match = re.search(r"(?:ID|BCM)\s*(0x[0-9a-fA-F]+)", text)
        if id_match:
            self._bcm_id = id_match.group(1)

        # Revision (e.g., "Rev B0")
        rev_match = re.search(r"Rev\s+(\S+)", text, re.IGNORECASE)
        if rev_match:
            self._bcm_rev = rev_match.group(1)

        # Firmware version (e.g., "FW v113.37" or "v113.37")
        fw_match = re.search(r"(?:FW\s+)?v(\d+\.\d+)", text)
        if fw_match:
            self._bcm_fw = f"v{fw_match.group(1)}"

    def render(self) -> Text:
        result = Text()
        label_w = 10

        # Frequency
        result.append("Freq".ljust(label_w), style="#506878")
        result.append(self._freq, style="#c8d0d8")
        result.append("\n")

        # Symbol rate
        result.append("SymRate".ljust(label_w), style="#506878")
        result.append(self._symrate, style="#c8d0d8")
        result.append("\n")

        # LNB state
        result.append("LNB".ljust(label_w), style="#506878")
        result.append(self._lnb, style="#c8d0d8")
        result.append("\n")

        # Lock status
        result.append("Lock".ljust(label_w), style="#506878")
        if self._lock == "YES":
            result.append("YES", style="#00e060 bold")
        else:
            result.append("NO", style="#e04040")
        result.append("\n")

        # BCM identification
        result.append("BCM".ljust(label_w), style="#506878")
        result.append(self._bcm_id, style="#00d4aa")
        if self._bcm_rev:
            result.append(f" Rev {self._bcm_rev}", style="#c8d0d8")
        if self._bcm_fw:
            result.append(f" FW {self._bcm_fw}", style="#c8d0d8")

        return result
