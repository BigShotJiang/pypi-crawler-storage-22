"""Serial log widget — RichLog with color-coded firmware console prompts."""

import re

from rich.text import Text
from textual.widgets import RichLog

# Prompt patterns and their colors, ordered by specificity (longest match first).
_PROMPT_STYLES: list[tuple[str, str]] = [
    ("A3981>", "#00b8c8"),
    ("STEP>", "#40c0a0"),
    ("TRK>", "#00d4aa"),
    ("MOT>", "#00e060"),
    ("DVB>", "#2080d0"),
    ("NVS>", "#e8a020"),
    ("EE>", "#e8a020"),
    ("OS>", "#8090a0"),
    ("ADC>", "#00b8c8"),
    ("GPIO>", "#40c0a0"),
    ("PEAK>", "#e8c020"),
    ("LATLON>", "#506878"),
    ("DIPSWITCH>", "#506878"),
]

# Build a regex that matches any known prompt at any position in the text.
_PROMPT_PATTERN = re.compile(
    r"(" + "|".join(re.escape(p) for p, _ in _PROMPT_STYLES) + r")"
)

# Lookup dict for color by prompt string
_PROMPT_COLOR: dict[str, str] = {p: c for p, c in _PROMPT_STYLES}


class SerialLog(RichLog):
    """RichLog that color-codes Winegard firmware console prompts."""

    def __init__(self, **kwargs) -> None:
        super().__init__(markup=False, wrap=True, **kwargs)

    def append_output(self, text: str) -> None:
        """Append firmware output with color-coded prompts.

        Each line is scanned for known prompt strings (TRK>, MOT>, etc.)
        which are rendered in their assigned color. All other text uses
        the default terminal color.
        """
        for line in text.splitlines():
            if not line:
                continue

            styled = _colorize_line(line)
            self.write(styled)

    def append_command(self, cmd: str) -> None:
        """Append a user-issued command, formatted with a prompt indicator."""
        styled = Text()
        styled.append("> ", style="#00d4aa bold")
        styled.append(cmd, style="#00d4aa")
        self.write(styled)


def _colorize_line(line: str) -> Text:
    """Parse a single line and return a Rich Text with colored prompt spans."""
    result = Text()
    last_end = 0

    for match in _PROMPT_PATTERN.finditer(line):
        start, end = match.span()
        prompt_str = match.group(1)
        color = _PROMPT_COLOR[prompt_str]

        # Text before the prompt
        if start > last_end:
            result.append(line[last_end:start], style="#c8d0d8")

        # The prompt itself
        result.append(prompt_str, style=f"{color} bold")
        last_end = end

    # Remaining text after last prompt
    if last_end < len(line):
        result.append(line[last_end:], style="#c8d0d8")

    return result
