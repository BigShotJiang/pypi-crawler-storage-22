"""Signal gauge widget — horizontal RSSI bar with color-coded thresholds."""

from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static

# RSSI color thresholds (upper bound, color)
_THRESHOLDS: list[tuple[int, str]] = [
    (500, "#2080d0"),  # cold — noise floor
    (1000, "#00b8c8"),  # cool — weak signal
    (2000, "#00e060"),  # mid — usable
    (3000, "#e8c020"),  # warm — strong
    (4096, "#e04040"),  # hot — saturating
]

BAR_WIDTH = 40
MAX_RSSI = 4096

# Sub-character bar fragments for smooth rendering (8 levels per cell)
_BAR_CHARS = " ▏▎▍▌▋▊▉"
_FULL = "\u2588"  # █


def _rssi_color(rssi: int) -> str:
    """Return the color string for a given RSSI value."""
    for threshold, color in _THRESHOLDS:
        if rssi <= threshold:
            return color
    return _THRESHOLDS[-1][1]


class SignalGauge(Static):
    """Horizontal RSSI signal strength bar gauge."""

    rssi_avg: reactive[int] = reactive(0)
    rssi_cur: reactive[int] = reactive(0)
    reads: reactive[int] = reactive(0)

    def render(self) -> Text:
        result = Text()

        # Title
        result.append("RSSI", style="#506878 bold")
        result.append("\n")

        # Compute fill with sub-character precision (8 levels per cell = 320 positions)
        clamped = max(0, min(self.rssi_cur, MAX_RSSI))
        fill_frac = clamped / MAX_RSSI * BAR_WIDTH
        full_cells = int(fill_frac)
        partial = fill_frac - full_cells
        partial_idx = int(partial * 8)

        # Build the bar with per-character color based on position thresholds
        for i in range(full_cells):
            pos_rssi = round((i + 0.5) / BAR_WIDTH * MAX_RSSI)
            color = _rssi_color(pos_rssi)
            result.append(_FULL, style=color)

        # Partial sub-character cell
        remaining = BAR_WIDTH - full_cells
        if remaining > 0 and partial_idx > 0:
            pos_rssi = round((full_cells + 0.5) / BAR_WIDTH * MAX_RSSI)
            color = _rssi_color(pos_rssi)
            result.append(_BAR_CHARS[partial_idx], style=color)
            remaining -= 1

        result.append("\u2591" * remaining, style="#1a2a38")

        # Numeric value at end of bar
        result.append(f" {self.rssi_cur}", style=_rssi_color(self.rssi_cur))
        result.append("\n")

        # Label line
        result.append("avg: ", style="#506878")
        result.append(f"{self.rssi_avg}", style="#c8d0d8")
        result.append("  cur: ", style="#506878")
        result.append(f"{self.rssi_cur}", style="#c8d0d8")
        result.append("  reads: ", style="#506878")
        result.append(f"{self.reads}", style="#c8d0d8")

        return result

    def watch_rssi_avg(self, _value: int) -> None:
        self.refresh()

    def watch_rssi_cur(self, _value: int) -> None:
        self.refresh()

    def watch_reads(self, _value: int) -> None:
        self.refresh()
