"""Sky heatmap widget — 2D AZ x EL grid colored by RSSI for sky scan visualization."""

from rich.text import Text
from textual.widgets import Static

# RSSI color thresholds matching signal_gauge.py
_THRESHOLDS: list[tuple[float, str]] = [
    (500.0, "#2080d0"),
    (1000.0, "#00b8c8"),
    (2000.0, "#00e060"),
    (3000.0, "#e8c020"),
    (4096.0, "#e04040"),
]

_ZERO_COLOR = "#0e1420"


def _rssi_color(rssi: float) -> str:
    """Return the color string for a given RSSI value."""
    if rssi <= 0:
        return _ZERO_COLOR
    for threshold, color in _THRESHOLDS:
        if rssi <= threshold:
            return color
    return _THRESHOLDS[-1][1]


class SkyHeatmap(Static):
    """2D azimuth x elevation grid colored by RSSI for sky scan visualization."""

    def __init__(
        self,
        az_bins: int = 40,
        el_bins: int = 10,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self._az_bins = az_bins
        self._el_bins = el_bins
        self._grid: list[list[float]] = [[0.0] * az_bins for _ in range(el_bins)]
        self._active_az: int | None = None
        self._active_el: int | None = None

    def set_point(self, az_idx: int, el_idx: int, rssi: float) -> None:
        """Set RSSI value at a grid cell. Does not refresh — call refresh() explicitly
        or batch updates and refresh once."""
        if 0 <= el_idx < self._el_bins and 0 <= az_idx < self._az_bins:
            self._grid[el_idx][az_idx] = rssi

    def set_active(self, az_idx: int, el_idx: int) -> None:
        """Highlight the current scan position and refresh."""
        self._active_az = az_idx
        self._active_el = el_idx
        self.refresh()

    def clear(self) -> None:
        """Reset all RSSI values to zero and clear active position."""
        for row in self._grid:
            for i in range(len(row)):
                row[i] = 0.0
        self._active_az = None
        self._active_el = None
        self.refresh()

    def render(self) -> Text:
        result = Text()

        # Column header: AZ labels (every 5 bins)
        # Left gutter for EL labels
        gutter = 5
        result.append(" " * gutter, style="#0e1420")
        for az in range(self._az_bins):
            if az % 5 == 0:
                label = str(az)
                result.append(label, style="#506878")
                # Pad to maintain 1-char-per-bin spacing
                pad = 1 - len(label)
                if pad > 0:
                    result.append(" " * pad)
            else:
                result.append(" ")
        result.append("\n")

        # Grid rows: highest EL at top
        for el_idx in range(self._el_bins - 1, -1, -1):
            # EL label
            el_label = f"{el_idx:>3d} "
            result.append(el_label, style="#506878")
            result.append("\u2502", style="#1a2a38")

            for az_idx in range(self._az_bins):
                rssi = self._grid[el_idx][az_idx]
                is_active = az_idx == self._active_az and el_idx == self._active_el

                if is_active:
                    # Active scan position: bright white on dark background
                    result.append("\u2588", style="bold #ffffff on #1a2a38")
                elif rssi <= 0:
                    # Empty cell
                    result.append("\u2591", style="#0e1420")
                else:
                    color = _rssi_color(rssi)
                    # Use denser block for higher RSSI
                    ch = "\u2593" if rssi < 500 else "\u2588"
                    result.append(ch, style=color)

            if el_idx > 0:
                result.append("\n")

        # Bottom border
        result.append("\n")
        result.append(" " * gutter, style="#0e1420")
        result.append("\u2500" * self._az_bins, style="#1a2a38")

        return result

    @property
    def az_bins(self) -> int:
        return self._az_bins

    @property
    def el_bins(self) -> int:
        return self._el_bins
