"""Sparkline widget — rolling time series using Unicode block characters."""

from collections import deque

from rich.text import Text
from textual.widgets import Static

# 8-level vertical block characters for sparkline rendering.
# Index 0 = lowest bar, index 7 = tallest bar.
_BLOCKS = "\u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588"


class SparklineWidget(Static):
    """Rolling sparkline time series display."""

    def __init__(
        self,
        max_points: int = 60,
        label: str = "",
        color: str = "#00d4aa",
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self._max_points = max_points
        self._label = label
        self._color = color
        self._buffer: deque[float] = deque(maxlen=max_points)

    def push(self, value: float) -> None:
        """Add a data point to the sparkline buffer and refresh."""
        self._buffer.append(value)
        self.refresh()

    def render(self) -> Text:
        result = Text()

        # Label prefix
        if self._label:
            result.append(f"{self._label} ", style="#506878")

        if not self._buffer:
            result.append("\u2581" * self._max_points, style="#1a2a38")
            return result

        values = list(self._buffer)
        lo = min(values)
        hi = max(values)
        span = hi - lo

        for v in values:
            if span <= 0:
                # All values identical — render as mid-level
                idx = 3
            else:
                normalized = (v - lo) / span
                idx = min(int(normalized * 7.999), 7)
            result.append(_BLOCKS[idx], style=self._color)

        # Pad remaining width with low blocks if buffer not full
        remaining = self._max_points - len(values)
        if remaining > 0:
            result.append(_BLOCKS[0] * remaining, style="#1a2a38")

        # Min/max annotation
        result.append("\n")
        if self._label:
            result.append(" " * (len(self._label) + 1))
        result.append(f"{lo:.0f}", style="#506878")
        gap = self._max_points - len(f"{lo:.0f}") - len(f"{hi:.0f}")
        if gap > 0:
            result.append(" " * gap)
        result.append(f"{hi:.0f}", style="#506878")

        return result
