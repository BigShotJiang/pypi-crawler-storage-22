"""Sweep plot widget -- 1D azimuth-vs-RSSI bar chart for signal sweep visualization."""

from collections import deque

from rich.text import Text
from textual.widgets import Static

# 8-level vertical block characters for bar rendering.
# Index 0 = lowest bar, index 7 = tallest bar.
_BLOCKS = "\u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588"

# RSSI color thresholds matching signal_gauge.py / sky_heatmap.py
_THRESHOLDS: list[tuple[float, str]] = [
    (500.0, "#2080d0"),  # cold -- noise floor
    (1000.0, "#00b8c8"),  # cool -- weak signal
    (2000.0, "#00e060"),  # mid -- usable
    (3000.0, "#e8c020"),  # warm -- strong
    (4096.0, "#e04040"),  # hot -- saturating
]

# Maximum display width in columns. AZ range is mapped to fit within this.
MAX_DISPLAY_WIDTH = 60


def _rssi_color(rssi: float) -> str:
    """Return the color string for a given RSSI value."""
    if rssi <= 0:
        return "#1a2a38"
    for threshold, color in _THRESHOLDS:
        if rssi <= threshold:
            return color
    return _THRESHOLDS[-1][1]


class SweepPlot(Static):
    """1D vertical bar chart showing RSSI at each AZ position.

    X-axis = azimuth positions, Y-axis = RSSI intensity (8-level Unicode blocks).
    Similar to a spectrum analyzer display but in angular domain.

    Each column represents one azimuth measurement point, rendered as a stacked
    block character whose height encodes RSSI strength and whose color encodes
    the signal gradient (blue < cyan < green < yellow < red).

    Methods:
        clear: Reset all measurement data.
        add_point: Add an AZ/RSSI measurement point.
        set_active: Highlight the current sweep position.
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        # Ordered measurement data: (az, rssi) pairs
        self._points: deque[tuple[float, float]] = deque(maxlen=MAX_DISPLAY_WIDTH)
        self._active_az: float | None = None

    def clear(self) -> None:
        """Reset all data and clear the active position."""
        self._points.clear()
        self._active_az = None
        self.refresh()

    def add_point(self, az: float, rssi: float) -> None:
        """Add a measurement point and refresh the display.

        Args:
            az: Azimuth angle in degrees.
            rssi: Raw RSSI ADC count (0-4096).
        """
        self._points.append((az, rssi))
        self.refresh()

    def set_active(self, az: float) -> None:
        """Highlight the current sweep position and refresh.

        Args:
            az: Azimuth angle in degrees of the active scan position.
        """
        self._active_az = az
        self.refresh()

    def render(self) -> Text:
        result = Text()

        # Title line
        result.append("AZ Sweep", style="#506878 bold")

        if not self._points:
            result.append("\n")
            result.append(_BLOCKS[0] * MAX_DISPLAY_WIDTH, style="#1a2a38")
            result.append("\n")
            result.append("no data", style="#384858")
            return result

        points = list(self._points)
        rssi_values = [rssi for _, rssi in points]
        az_values = [az for az, _ in points]

        # Find peak
        peak_rssi = max(rssi_values)
        peak_idx = rssi_values.index(peak_rssi)
        peak_az = az_values[peak_idx]

        # Normalize RSSI to 0-7 block index range
        lo = min(rssi_values)
        hi = max(rssi_values)
        span = hi - lo

        # Render the bar chart row
        result.append("\n")
        for az, rssi in points:
            is_active = self._active_az is not None and abs(az - self._active_az) < 0.05

            if is_active:
                # Active position: bright white marker
                result.append(_BLOCKS[7], style="#ffffff bold")
            else:
                # Compute block level from RSSI
                if span <= 0:
                    idx = 3
                else:
                    normalized = (rssi - lo) / span
                    idx = min(int(normalized * 7.999), 7)
                color = _rssi_color(rssi)
                result.append(_BLOCKS[idx], style=color)

        # Pad remaining width with low blocks if fewer points than max width
        remaining = MAX_DISPLAY_WIDTH - len(points)
        if remaining > 0:
            result.append(_BLOCKS[0] * remaining, style="#1a2a38")

        # AZ axis labels
        result.append("\n")
        if len(az_values) >= 2:
            az_lo = az_values[0]
            az_hi = az_values[-1]
            lo_label = f"{az_lo:.1f}\u00b0"
            hi_label = f"{az_hi:.1f}\u00b0"
            gap = MAX_DISPLAY_WIDTH - len(lo_label) - len(hi_label)
            result.append(lo_label, style="#506878")
            if gap > 0:
                result.append(" " * gap)
            result.append(hi_label, style="#506878")
        elif len(az_values) == 1:
            result.append(f"{az_values[0]:.1f}\u00b0", style="#506878")

        # Peak indicator line
        result.append("\n")
        result.append("Peak at ", style="#506878")
        result.append(f"AZ={peak_az:.1f}", style="#00d4aa bold")
        result.append("  RSSI=", style="#506878")
        result.append(f"{peak_rssi:.0f}", style=_rssi_color(peak_rssi))

        # Point count
        result.append(f"  ({len(points)} pts)", style="#384858")

        return result
