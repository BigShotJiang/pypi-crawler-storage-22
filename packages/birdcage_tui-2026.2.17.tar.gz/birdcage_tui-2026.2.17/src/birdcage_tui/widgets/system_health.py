"""System health panel widget -- compact multi-line diagnostics for the Dashboard."""

import re

from rich.text import Text
from textual.widgets import Static


class SystemHealthPanel(Static):
    """Multi-line styled text showing A3981 diag, firmware ID, motor life.

    Populated by calling ``load_data()`` with raw firmware response strings.
    Parses and formats hardware diagnostics into a compact, color-coded
    summary suitable for the Dashboard overview.
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._diag: str = ""
        self._torque: str = ""
        self._fw_id: str = ""
        self._motor_life: str = ""
        self._el_limits: dict[str, float] = {"min": 0.0, "max": 0.0}

    def load_data(
        self,
        diag: str = "",
        torque: str = "",
        fw_id: str = "",
        motor_life: str = "",
        el_limits: dict[str, float] | None = None,
    ) -> None:
        """Update all health fields from raw firmware responses and refresh.

        Args:
            diag: Raw A3981 ``diag`` response (e.g., "AZ DIAG: OK  EL DIAG: OK").
            torque: Raw A3981 ``st`` response (e.g., "AZ Torq:LOW  EL Torq:LOW").
            fw_id: Raw OS ``id`` response with NVS version, system ID, chip info.
            motor_life: Raw MOT ``life`` response with usage statistics.
            el_limits: Parsed EL limits dict with "min" and "max" keys (degrees).
        """
        self._diag = diag
        self._torque = torque
        self._fw_id = fw_id
        self._motor_life = motor_life
        if el_limits is not None:
            self._el_limits = el_limits
        self.refresh()

    def render(self) -> Text:
        result = Text()
        label_w = 10

        # A3981 diagnostic row
        result.append("A3981".ljust(label_w), style="#506878")
        az_diag, el_diag = _parse_diag(self._diag)
        result.append("AZ ", style="#506878")
        result.append(az_diag, style=_diag_style(az_diag))
        result.append("  EL ", style="#506878")
        result.append(el_diag, style=_diag_style(el_diag))
        result.append("\n")

        # Torque row
        result.append("Torque".ljust(label_w), style="#506878")
        az_torque, el_torque = _parse_torque(self._torque)
        result.append("AZ ", style="#506878")
        result.append(az_torque, style=_torque_style(az_torque))
        result.append("  EL ", style="#506878")
        result.append(el_torque, style=_torque_style(el_torque))
        result.append("\n")

        # Firmware identification row
        fw_ver, mcu, ant_id = _parse_fw_id(self._fw_id)
        result.append("FW".ljust(label_w), style="#506878")
        result.append(fw_ver, style="#c8d0d8")
        if mcu:
            result.append("  MCU: ", style="#506878")
            result.append(mcu, style="#c8d0d8")
        if ant_id:
            result.append("  Ant: ", style="#506878")
            result.append(ant_id, style="#c8d0d8")
        result.append("\n")

        # EL range + motor life row
        result.append("EL Range".ljust(label_w), style="#506878")
        el_min = self._el_limits.get("min", 0.0)
        el_max = self._el_limits.get("max", 0.0)
        result.append(f"{el_min:.1f}\u00b0", style="#c8d0d8")
        result.append(" \u2013 ", style="#506878")
        result.append(f"{el_max:.1f}\u00b0", style="#c8d0d8")

        az_life, el_life = _parse_motor_life(self._motor_life)
        if az_life or el_life:
            result.append("   Life: ", style="#506878")
            result.append(f"AZ {az_life}", style="#c8d0d8")
            result.append(f"  EL {el_life}", style="#c8d0d8")

        return result


def _parse_diag(text: str) -> tuple[str, str]:
    """Extract AZ and EL diagnostic status from A3981 diag response."""
    az = "---"
    el = "---"
    if not text:
        return az, el

    az_match = re.search(r"AZ\s+DIAG:\s*(\w+)", text, re.IGNORECASE)
    el_match = re.search(r"EL\s+DIAG:\s*(\w+)", text, re.IGNORECASE)
    if az_match:
        az = az_match.group(1).upper()
    if el_match:
        el = el_match.group(1).upper()
    return az, el


def _parse_torque(text: str) -> tuple[str, str]:
    """Extract AZ and EL torque levels from A3981 st response."""
    az = "---"
    el = "---"
    if not text:
        return az, el

    az_match = re.search(r"AZ\s+Torq:(\w+)", text, re.IGNORECASE)
    el_match = re.search(r"EL\s+Torq:(\w+)", text, re.IGNORECASE)
    if az_match:
        az = az_match.group(1).upper()
    if el_match:
        el = el_match.group(1).upper()
    return az, el


def _parse_fw_id(text: str) -> tuple[str, str, str]:
    """Extract firmware version, MCU type, and antenna ID from OS id response.

    The ``id`` command returns multi-line output including NVS version,
    System ID, and chip details. We extract the most relevant fields.
    """
    fw_ver = "---"
    mcu = ""
    ant_id = ""
    if not text:
        return fw_ver, mcu, ant_id

    # Firmware / NVS version (e.g., "02.02.48" or "NVS Ver: 02.02.48")
    ver_match = re.search(r"(\d{2}\.\d{2}\.\d{2,3})", text)
    if ver_match:
        fw_ver = ver_match.group(1)

    # MCU identification (e.g., "K60" or "Kinetis")
    if "K60" in text or "Kinetis" in text:
        mcu = "K60 96MHz"

    # Antenna ID (e.g., "12-IN G2" or "Ant ID")
    ant_match = re.search(r"Ant\s+ID\s*[-:]\s*(.+?)(?:\r?\n|$)", text, re.IGNORECASE)
    if ant_match:
        ant_id = ant_match.group(1).strip()

    return fw_ver, mcu, ant_id


def _parse_motor_life(text: str) -> tuple[str, str]:
    """Extract AZ and EL motor life counters from MOT life response."""
    az = ""
    el = ""
    if not text:
        return az, el

    # Motor life output varies by firmware. Look for numeric counters
    # associated with motor 0 (AZ) and motor 1 (EL).
    az_match = re.search(r"(?:Motor\s*\[?0\]?|AZ)\D+(\d+)", text, re.IGNORECASE)
    el_match = re.search(r"(?:Motor\s*\[?1\]?|EL)\D+(\d+)", text, re.IGNORECASE)
    if az_match:
        az = az_match.group(1)
    if el_match:
        el = el_match.group(1)
    return az, el


def _diag_style(value: str) -> str:
    """Return Rich style string for a diagnostic status value."""
    if value == "OK":
        return "#00e060 bold"
    if value == "FAULT":
        return "#e04040 bold"
    return "#506878"


def _torque_style(value: str) -> str:
    """Return Rich style string for a torque level value."""
    if value == "HIGH":
        return "#e8c020 bold"
    if value == "LOW":
        return "#c8d0d8"
    return "#506878"
