"""Tracking panel widget -- rotctld server lifecycle control for satellite tracking."""

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.message import Message
from textual.reactive import reactive
from textual.widgets import Button, Input, Static


class TrackingPanel(Container):
    """Panel wrapping the RotctldServer lifecycle UI for satellite tracking.

    Displays server status, bind address, client info, move statistics,
    and leapfrog state. The actual rotctld server is started and managed
    by the parent screen -- this widget is purely the control surface.
    """

    class StartRequested(Message):
        """Posted when the user presses Start Server."""

        def __init__(self, host: str, port: int, min_el: float) -> None:
            super().__init__()
            self.host = host
            self.port = port
            self.min_el = min_el

    class StopRequested(Message):
        """Posted when the user presses Stop."""

    def compose(self) -> ComposeResult:
        yield TrackingStatus(id="tracking-status")
        with Horizontal(classes="tracking-controls"):
            yield Button("Start Server", id="btn-track-start", variant="primary")
            yield Button("Stop", id="btn-track-stop")
            yield Static(" Bind: ", classes="label")
            yield Input(value="127.0.0.1", id="track-host-input")
            yield Static(":", classes="label")
            yield Input(value="4533", id="track-port-input", type="integer")
            yield Static(" Min EL: ", classes="label")
            yield Input(value="18.0", id="track-minel-input", type="number")

    # ------------------------------------------------------------------
    # Status updates (called by parent screen)
    # ------------------------------------------------------------------

    def set_status(
        self,
        state: str = "STOPPED",
        client: str = "",
        moves: int = 0,
        rate: float = 0.0,
        leapfrog: bool = True,
    ) -> None:
        """Update the tracking status display.

        Args:
            state: One of "STOPPED", "LISTENING", "CONNECTED".
            client: Client identification string (e.g., "Gpredict").
            moves: Total move commands received.
            rate: Move command rate in commands per second.
            leapfrog: Whether leapfrog predictive compensation is active.
        """
        status = self.query_one("#tracking-status", TrackingStatus)
        status.state = state
        status.client = client
        status.moves = moves
        status.rate = rate
        status.leapfrog = leapfrog

    # ------------------------------------------------------------------
    # Button handlers
    # ------------------------------------------------------------------

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""

        if button_id == "btn-track-start":
            self._handle_start()
        elif button_id == "btn-track-stop":
            self._handle_stop()

    def _handle_start(self) -> None:
        """Read bind parameters and post a StartRequested message."""
        host = self.query_one("#track-host-input", Input).value.strip()
        if not host:
            host = "127.0.0.1"

        try:
            port = int(self.query_one("#track-port-input", Input).value)
        except ValueError:
            self.app.notify("Invalid port number", severity="warning")
            return

        try:
            min_el = float(self.query_one("#track-minel-input", Input).value)
        except ValueError:
            min_el = 18.0

        self.post_message(self.StartRequested(host, port, min_el))

    def _handle_stop(self) -> None:
        """Post a StopRequested message."""
        self.post_message(self.StopRequested())


class TrackingStatus(Static):
    """Rich text display of rotctld server state and tracking statistics."""

    state: reactive[str] = reactive("STOPPED")
    client: reactive[str] = reactive("")
    moves: reactive[int] = reactive(0)
    rate: reactive[float] = reactive(0.0)
    leapfrog: reactive[bool] = reactive(True)

    def render(self) -> Text:
        result = Text()
        label_w = 10

        # Status row
        result.append("Status".ljust(label_w), style="#506878")
        if self.state == "CONNECTED":
            result.append("CONNECTED", style="#00e060 bold")
        elif self.state == "LISTENING":
            result.append("LISTENING", style="#e8a020 bold")
        else:
            result.append("STOPPED", style="#e04040")
        result.append("\n")

        # Bind address row (shown as part of status context)
        result.append("Client".ljust(label_w), style="#506878")
        if self.client:
            result.append(self.client, style="#c8d0d8")
        else:
            result.append("(none)", style="#384858")
        result.append("\n")

        # Move statistics row
        result.append("Moves".ljust(label_w), style="#506878")
        result.append(f"{self.moves}", style="#c8d0d8")
        result.append("   Rate: ", style="#506878")
        result.append(f"{self.rate:.1f}/s", style="#c8d0d8")
        result.append("   Leapfrog: ", style="#506878")
        if self.leapfrog:
            result.append("ON", style="#00e060 bold")
        else:
            result.append("OFF", style="#506878")

        return result

    def watch_state(self, _value: str) -> None:
        self.refresh()

    def watch_client(self, _value: str) -> None:
        self.refresh()

    def watch_moves(self, _value: int) -> None:
        self.refresh()

    def watch_rate(self, _value: float) -> None:
        self.refresh()

    def watch_leapfrog(self, _value: bool) -> None:
        self.refresh()
