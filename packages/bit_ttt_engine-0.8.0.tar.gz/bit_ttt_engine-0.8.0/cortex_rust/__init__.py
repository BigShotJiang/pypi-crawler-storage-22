# Auto-add CUDA DLL path on Windows
import os
import sys

if sys.platform == "win32":
    cuda_paths = [
        os.environ.get("CUDA_PATH", ""),
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.4",
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.3",
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.0",
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.8",
    ]
    for cuda_path in cuda_paths:
        bin_path = os.path.join(cuda_path, "bin")
        if os.path.isdir(bin_path):
            os.add_dll_directory(bin_path)
            break

from .cortex_rust import *
from .chat import format_chat, format_simple, detect_template, list_templates
from .engine import load, Model

__doc__ = cortex_rust.__doc__
if hasattr(cortex_rust, "__all__"):
    __all__ = cortex_rust.__all__
