"""Enable `python -m cortex_rust` as CLI entry point."""
from cortex_rust.cli import main

main()
