"""Chat template support for various LLM architectures.

Provides format_chat() to convert messages into model-specific prompt strings.
Supports Llama-3, Llama-2, Gemma-2, Qwen/ChatML, and generic formats.

Usage:
    from cortex_rust.chat import format_chat, detect_template

    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello!"},
    ]
    prompt = format_chat(messages, template="llama3")
    # Or auto-detect from model path:
    template = detect_template("Meta-Llama-3-8B-Instruct.Q4_K_M.gguf")
    prompt = format_chat(messages, template=template)
"""

from typing import List, Dict, Optional

# ============================================================================
# Template Definitions
# ============================================================================

TEMPLATES = {
    "llama3": {
        "bos": "<|begin_of_text|>",
        "system_start": "<|start_header_id|>system<|end_header_id|>\n\n",
        "system_end": "<|eot_id|>",
        "user_start": "<|start_header_id|>user<|end_header_id|>\n\n",
        "user_end": "<|eot_id|>",
        "assistant_start": "<|start_header_id|>assistant<|end_header_id|>\n\n",
        "assistant_end": "<|eot_id|>",
        "default_system": "You are a helpful assistant.",
    },
    "llama2": {
        "bos": "<s>",
        "system_start": "<<SYS>>\n",
        "system_end": "\n<</SYS>>\n\n",
        "user_start": "[INST] ",
        "user_end": " [/INST]",
        "assistant_start": " ",
        "assistant_end": " </s>",
        "default_system": "You are a helpful, respectful and honest assistant.",
        # Llama-2 embeds system inside first [INST]
        "system_inside_user": True,
    },
    "gemma2": {
        "bos": "<bos>",
        "system_start": "",  # Gemma-2 has no system role
        "system_end": "",
        "user_start": "<start_of_turn>user\n",
        "user_end": "<end_of_turn>\n",
        "assistant_start": "<start_of_turn>model\n",
        "assistant_end": "<end_of_turn>\n",
        "default_system": None,  # No system support
    },
    "chatml": {
        # Used by Qwen, Mistral-Instruct, etc.
        "bos": "",
        "system_start": "<|im_start|>system\n",
        "system_end": "<|im_end|>\n",
        "user_start": "<|im_start|>user\n",
        "user_end": "<|im_end|>\n",
        "assistant_start": "<|im_start|>assistant\n",
        "assistant_end": "<|im_end|>\n",
        "default_system": "You are a helpful assistant.",
    },
}

# Model name patterns → template mapping
_DETECTION_PATTERNS = [
    ("llama-3", "llama3"),
    ("llama3", "llama3"),
    ("meta-llama-3", "llama3"),
    ("llama-2", "llama2"),
    ("llama2", "llama2"),
    ("gemma-3", "gemma2"),
    ("gemma3", "gemma2"),
    ("gemma-2", "gemma2"),
    ("gemma2", "gemma2"),
    ("qwen", "chatml"),
    ("mistral", "chatml"),
    ("yi-", "chatml"),
]


def detect_template(model_path: str) -> str:
    """Auto-detect chat template from model filename.
    
    Args:
        model_path: Path to model file (e.g., "Meta-Llama-3-8B-Instruct.Q4_K_M.gguf")
    
    Returns:
        Template name (e.g., "llama3", "chatml"). Falls back to "chatml" if unknown.
    """
    name = model_path.lower().replace("\\", "/").split("/")[-1]
    for pattern, template in _DETECTION_PATTERNS:
        if pattern in name:
            return template
    return "chatml"  # Safe default


def list_templates() -> List[str]:
    """List all available template names."""
    return list(TEMPLATES.keys())


def format_chat(
    messages: List[Dict[str, str]],
    template: str = "chatml",
    add_generation_prompt: bool = True,
) -> str:
    """Format chat messages into a model-specific prompt string.
    
    Args:
        messages: List of {"role": "system"|"user"|"assistant", "content": "..."}
        template: Template name ("llama3", "llama2", "gemma2", "chatml")
        add_generation_prompt: If True, append assistant start token at the end
    
    Returns:
        Formatted prompt string ready for model.generate()
    
    Example:
        >>> messages = [{"role": "user", "content": "Hello!"}]
        >>> format_chat(messages, template="llama3")
        '<|begin_of_text|><|start_header_id|>user<|end_header_id|>\\n\\nHello!<|eot_id|><|start_header_id|>assistant<|end_header_id|>\\n\\n'
    """
    if template not in TEMPLATES:
        raise ValueError(f"Unknown template '{template}'. Available: {list_templates()}")
    
    tmpl = TEMPLATES[template]
    parts = [tmpl["bos"]]
    
    system_inside_user = tmpl.get("system_inside_user", False)
    system_content = None
    
    for msg in messages:
        role = msg["role"]
        content = msg["content"]
        
        if role == "system":
            if system_inside_user:
                # Llama-2 style: save system for embedding in first user message
                system_content = content
            elif tmpl["system_start"]:  # Skip if no system support (Gemma-2)
                parts.append(tmpl["system_start"])
                parts.append(content)
                parts.append(tmpl["system_end"])
        
        elif role == "user":
            parts.append(tmpl["user_start"])
            if system_inside_user and system_content is not None:
                # Llama-2: embed system before user content
                parts.append(tmpl["system_start"])
                parts.append(system_content)
                parts.append(tmpl["system_end"])
                system_content = None  # Only first user message
            parts.append(content)
            parts.append(tmpl["user_end"])
        
        elif role == "assistant":
            parts.append(tmpl["assistant_start"])
            parts.append(content)
            parts.append(tmpl["assistant_end"])
    
    if add_generation_prompt:
        parts.append(tmpl["assistant_start"])
    
    return "".join(parts)


def format_simple(
    user_message: str,
    system_message: Optional[str] = None,
    template: str = "chatml",
) -> str:
    """Convenience: format a single user message (with optional system prompt).
    
    Args:
        user_message: The user's message
        system_message: Optional system prompt (uses template default if None)
        template: Template name
    
    Returns:
        Formatted prompt string
    """
    messages = []
    
    tmpl = TEMPLATES.get(template, TEMPLATES["chatml"])
    if system_message is not None:
        messages.append({"role": "system", "content": system_message})
    elif tmpl.get("default_system"):
        messages.append({"role": "system", "content": tmpl["default_system"]})
    
    messages.append({"role": "user", "content": user_message})
    
    return format_chat(messages, template=template)
