"""High-level Python SDK for Bit-TTT-Engine.

Simple, Pythonic interface for LLM inference.

Quick start:
    from cortex_rust.engine import load

    model = load("model.gguf")                        # local file
    model = load("bartowski/Llama-3-8B-Instruct-GGUF") # HuggingFace auto-download

    # Generate text
    text = model.generate("Once upon a time")

    # Chat (auto-applies chat template)
    response = model.chat([
        {"role": "user", "content": "What is 2+2?"}
    ])

    # Stream tokens
    for token in model.stream("Tell me a story"):
        print(token, end="", flush=True)

    # Chat stream
    for token in model.chat_stream([
        {"role": "system", "content": "You are a pirate."},
        {"role": "user", "content": "Hello!"},
    ]):
        print(token, end="", flush=True)
"""

import os
from typing import Dict, Iterator, List, Optional, Union

Messages = List[Dict[str, str]]


class Model:
    """High-level model wrapper with chat, generate, and stream support."""

    def __init__(self, inner, template: str, model_path: str,
                 tokenizer=None):
        self._inner = inner
        self._template = template
        self._model_path = model_path
        self._tokenizer = tokenizer  # tokenizers.Tokenizer instance

    @property
    def config(self):
        """Access model configuration."""
        return self._inner.config

    @property
    def template(self) -> str:
        """Chat template name (llama3, llama2, gemma2, chatml)."""
        return self._template

    # ---- Generation ----

    def generate(self, prompt: str, max_tokens: int = 256,
                 temperature: float = 0.7, top_p: float = 0.9,
                 repetition_penalty: float = 1.1, **kwargs) -> str:
        """Generate text from a prompt (no chat template applied).

        Args:
            prompt: Raw text prompt.
            max_tokens: Maximum tokens to generate.
            temperature: Sampling temperature (0 = greedy).
            top_p: Nucleus sampling threshold.
            repetition_penalty: Repetition penalty.

        Returns:
            Generated text string.
        """
        self._inner.reset_cache()
        return self._inner.generate(
            prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            repetition_penalty=repetition_penalty,
        )

    def chat(self, messages: Messages, max_tokens: int = 256,
             temperature: float = 0.7, top_p: float = 0.9,
             repetition_penalty: float = 1.1, **kwargs) -> str:
        """Chat completion with automatic template formatting.

        Args:
            messages: List of {"role": ..., "content": ...} dicts.
            max_tokens: Maximum tokens to generate.

        Returns:
            Assistant response text.
        """
        from cortex_rust.chat import format_chat
        prompt = format_chat(messages, template=self._template)
        return self.generate(prompt, max_tokens=max_tokens,
                             temperature=temperature, top_p=top_p,
                             repetition_penalty=repetition_penalty)

    # ---- Streaming ----

    def stream(self, prompt: str, max_tokens: int = 256,
               temperature: float = 0.7, top_p: float = 0.9,
               repetition_penalty: float = 1.1) -> Iterator[str]:
        """Stream tokens from a prompt.

        Uses generate_from_tokens internally and decodes token-by-token.
        If tokenizer is not available, falls back to yielding the full output.

        Yields:
            Individual token strings as they are generated.
        """
        self._inner.reset_cache()

        # Try token-by-token via generate_from_tokens
        if self._tokenizer is not None:
            encoding = self._tokenizer.encode(prompt, add_special_tokens=True)
            prompt_ids = [int(t) for t in encoding.ids]
            if not prompt_ids:
                prompt_ids = [1]

            gen_ids = self._inner.generate_from_tokens(
                prompt_ids,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                repetition_penalty=repetition_penalty,
            )
            # Decode incrementally to preserve whitespace
            all_ids = []
            prev_text = ""
            for tid in gen_ids:
                all_ids.append(int(tid))
                full_text = self._tokenizer.decode(all_ids, skip_special_tokens=True)
                delta = full_text[len(prev_text):]
                prev_text = full_text
                if delta:
                    yield delta
        else:
            # Fallback: yield full output at once
            text = self._inner.generate(
                prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                repetition_penalty=repetition_penalty,
            )
            yield text

    def chat_stream(self, messages: Messages, max_tokens: int = 256,
                    temperature: float = 0.7, top_p: float = 0.9,
                    repetition_penalty: float = 1.1) -> Iterator[str]:
        """Stream chat completion tokens.

        Yields:
            Individual token strings.

        Example:
            for token in model.chat_stream([{"role": "user", "content": "Hi!"}]):
                print(token, end="", flush=True)
        """
        from cortex_rust.chat import format_chat
        prompt = format_chat(messages, template=self._template)
        yield from self.stream(prompt, max_tokens=max_tokens,
                               temperature=temperature, top_p=top_p,
                               repetition_penalty=repetition_penalty)

    # ---- Configuration ----

    def enable_q8_cache(self, enabled: bool = True):
        """Enable/disable Q8 KV cache (saves ~82% VRAM)."""
        self._inner.enable_q8_kv_cache(enabled)
        return self

    def enable_ttt(self, enabled: bool = True, lr: float = 0.01):
        """Enable/disable Test-Time Training."""
        self._inner.enable_ttt(enabled)
        return self

    def create_lora(self, rank: int = 8, alpha: float = 16.0,
                    target_modules: Optional[List[str]] = None):
        """Create LoRA adapters for fine-tuning.

        Args:
            rank: LoRA rank (lower = faster, less capacity).
            alpha: LoRA alpha scaling factor.
            target_modules: List of modules to apply LoRA to.
                Default: ["q_proj", "v_proj"]
        """
        modules = target_modules or ["q_proj", "v_proj"]
        self._inner.create_lora(rank=rank, alpha=alpha, target_modules=modules)
        return self

    def reset(self):
        """Reset KV cache and TTT state."""
        self._inner.reset_cache()
        return self

    def __repr__(self):
        name = os.path.basename(self._model_path)
        return f"Model({name}, template={self._template})"


def load(model_path: str, device: str = "cuda",
         tokenizer: Optional[str] = None) -> Model:
    """Load a model from a local file or HuggingFace repo.

    Args:
        model_path: Local GGUF file path or HuggingFace repo ID.
            Examples:
                "model.gguf"
                "bartowski/Llama-3-8B-Instruct-GGUF"
                "TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF:Q4_K_M"
        device: "cuda" or "cpu".
        tokenizer: Optional path to tokenizer.json.

    Returns:
        Model instance ready for generation.
    """
    from cortex_rust import QGgufModel
    from cortex_rust.chat import detect_template
    from cortex_rust.cli import _resolve_model_path

    # Resolve HF repo → local path
    resolved = _resolve_model_path(model_path)

    # Auto-detect tokenizer
    tok = tokenizer
    if tok is None:
        model_dir = os.path.dirname(os.path.abspath(resolved))
        candidate = os.path.join(model_dir, "tokenizer.json")
        if os.path.exists(candidate):
            tok = candidate

    kwargs = {"device": device}
    if tok:
        kwargs["tokenizer"] = tok

    inner = QGgufModel(resolved, **kwargs)
    template = detect_template(resolved)

    # Load tokenizer instance for streaming
    tok_instance = None
    if tok:
        try:
            from tokenizers import Tokenizer
            tok_instance = Tokenizer.from_file(tok)
        except Exception:
            pass  # streaming will fall back to non-token mode

    return Model(inner, template=template, model_path=resolved,
                 tokenizer=tok_instance)
