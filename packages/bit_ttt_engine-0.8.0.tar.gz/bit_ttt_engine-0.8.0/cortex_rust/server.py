"""OpenAI-compatible API server for Bit-TTT-Engine.

Provides /v1/chat/completions and /v1/completions endpoints
with SSE streaming support.

Usage:
    bit-ttt serve model.gguf [--port 8000] [--host 0.0.0.0]
    python -m cortex_rust serve model.gguf

Requires: pip install fastapi uvicorn sse-starlette
"""

import asyncio
import json
import os
import signal
import sys
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from typing import AsyncGenerator, Dict, List, Optional

try:
    from fastapi import FastAPI, HTTPException, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    from pydantic import BaseModel, Field
except ImportError:
    raise ImportError(
        "OpenAI-compatible server requires fastapi and uvicorn.\n"
        "Install with: pip install fastapi uvicorn sse-starlette"
    )

try:
    from sse_starlette.sse import EventSourceResponse
except ImportError:
    EventSourceResponse = None

from cortex_rust.chat import format_chat, detect_template

# ============================================================================
# Pydantic Models (OpenAI-compatible)
# ============================================================================

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatCompletionRequest(BaseModel):
    model: str = "default"
    messages: List[ChatMessage]
    temperature: float = 0.7
    top_p: float = 0.9
    max_tokens: Optional[int] = 256
    stream: bool = False
    stop: Optional[List[str]] = None
    repetition_penalty: float = Field(default=1.1, alias="frequency_penalty")

    class Config:
        populate_by_name = True

class CompletionRequest(BaseModel):
    model: str = "default"
    prompt: str
    temperature: float = 0.7
    top_p: float = 0.9
    max_tokens: Optional[int] = 256
    stream: bool = False
    stop: Optional[List[str]] = None
    repetition_penalty: float = Field(default=1.1, alias="frequency_penalty")

    class Config:
        populate_by_name = True

# ============================================================================
# Server
# ============================================================================

class BitTTTServer:
    """OpenAI-compatible inference server."""

    def __init__(self, model_path: str, device: str = "cuda",
                 tokenizer: Optional[str] = None,
                 lora: Optional[str] = None, q8_cache: bool = False,
                 ttt: bool = False):
        from cortex_rust import QGgufModel

        # Resolve HF repo ID → local path
        from cortex_rust.cli import _resolve_model_path
        resolved_path = _resolve_model_path(model_path)

        self.model_path = resolved_path
        self.model_name = os.path.basename(resolved_path)
        self.template = detect_template(resolved_path)
        self.created = int(time.time())

        # Find tokenizer
        tok = tokenizer
        if tok is None:
            model_dir = os.path.dirname(os.path.abspath(resolved_path))
            candidate = os.path.join(model_dir, "tokenizer.json")
            if os.path.exists(candidate):
                tok = candidate

        kwargs = {"device": device}
        if tok:
            kwargs["tokenizer"] = tok

        print(f"📦 Loading model: {self.model_name}")
        self.model = QGgufModel(resolved_path, **kwargs)

        # Load tokenizer for streaming
        self._tokenizer = None
        if tok:
            try:
                from tokenizers import Tokenizer
                self._tokenizer = Tokenizer.from_file(tok)
            except Exception:
                pass

        # Apply feature flags
        if q8_cache:
            self.model.enable_q8_kv_cache(True)
            print("   🔧 Q8 KV cache enabled")
        if ttt:
            self.model.enable_ttt(True)
            print("   🔧 TTT enabled")
        if lora:
            self.model.load_lora(lora)
            self.model.enable_lora(True)
            print(f"   🔧 LoRA loaded: {lora}")

        print(f"✅ Model loaded (template: {self.template})")

        # Thread pool for generation (GIL release)
        self._executor = ThreadPoolExecutor(max_workers=1)
        self._lock = asyncio.Lock()

        # Request counter
        self._request_count = 0

    def _generate_sync(self, prompt: str, max_tokens: int,
                       temperature: float, top_p: float,
                       repetition_penalty: float) -> str:
        """Synchronous generation (runs in thread pool)."""
        self.model.reset_cache()
        return self.model.generate(
            prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            repetition_penalty=repetition_penalty,
        )

    def _generate_tokens_sync(self, prompt: str, max_tokens: int,
                              temperature: float, top_p: float,
                              repetition_penalty: float) -> List[str]:
        """Synchronous token-by-token generation with incremental decode."""
        self.model.reset_cache()

        # Use tokenizer for proper token-by-token output
        if self._tokenizer is not None:
            encoding = self._tokenizer.encode(prompt, add_special_tokens=True)
            prompt_ids = [int(t) for t in encoding.ids]
            if not prompt_ids:
                prompt_ids = [1]

            gen_ids = self.model.generate_from_tokens(
                prompt_ids,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                repetition_penalty=repetition_penalty,
            )

            # Incremental decode to preserve whitespace
            tokens = []
            all_ids = []
            prev_text = ""
            for tid in gen_ids:
                all_ids.append(int(tid))
                full_text = self._tokenizer.decode(all_ids, skip_special_tokens=True)
                delta = full_text[len(prev_text):]
                prev_text = full_text
                if delta:
                    tokens.append(delta)
            return tokens
        else:
            # Fallback: return full output as single token
            text = self.model.generate(
                prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                repetition_penalty=repetition_penalty,
            )
            return [text]

    async def generate(self, prompt: str, max_tokens: int = 256,
                       temperature: float = 0.7, top_p: float = 0.9,
                       repetition_penalty: float = 1.1) -> str:
        """Async generation."""
        async with self._lock:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(
                self._executor,
                self._generate_sync,
                prompt, max_tokens, temperature, top_p, repetition_penalty,
            )

    async def generate_stream(self, prompt: str, max_tokens: int = 256,
                              temperature: float = 0.7, top_p: float = 0.9,
                              repetition_penalty: float = 1.1
                              ) -> AsyncGenerator[str, None]:
        """Async streaming generation."""
        async with self._lock:
            loop = asyncio.get_event_loop()
            tokens = await loop.run_in_executor(
                self._executor,
                self._generate_tokens_sync,
                prompt, max_tokens, temperature, top_p, repetition_penalty,
            )
            for token in tokens:
                yield token

    def shutdown(self):
        """Clean shutdown."""
        self._executor.shutdown(wait=False)
        print("\n👋 Server shutting down...")


def create_app(server: BitTTTServer) -> FastAPI:
    """Create FastAPI app with OpenAI-compatible endpoints."""

    app = FastAPI(title="Bit-TTT-Engine", version="0.6.2",
                  description="OpenAI-compatible API for Bit-TTT-Engine")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Global error handler
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "message": str(exc),
                    "type": type(exc).__name__,
                    "code": "internal_error",
                }
            },
        )

    @app.on_event("shutdown")
    async def on_shutdown():
        server.shutdown()

    def _make_id() -> str:
        return f"chatcmpl-{uuid.uuid4().hex[:12]}"

    # ---- /v1/models ----
    @app.get("/v1/models")
    async def list_models():
        return {
            "object": "list",
            "data": [{
                "id": server.model_name,
                "object": "model",
                "created": server.created,
                "owned_by": "bit-ttt-engine",
            }],
        }

    # ---- /v1/chat/completions ----
    @app.post("/v1/chat/completions")
    async def chat_completions(req: ChatCompletionRequest):
        messages = [{"role": m.role, "content": m.content} for m in req.messages]
        prompt = format_chat(messages, template=server.template)
        max_tokens = req.max_tokens or 256

        if req.stream:
            if EventSourceResponse is None:
                raise HTTPException(
                    status_code=400,
                    detail="Streaming requires sse-starlette. Install: pip install sse-starlette",
                )
            return EventSourceResponse(
                _stream_chat(server, prompt, max_tokens, req),
                media_type="text/event-stream",
            )

        # Non-streaming
        start = time.perf_counter()
        text = await server.generate(
            prompt, max_tokens, req.temperature, req.top_p, req.repetition_penalty,
        )
        elapsed = time.perf_counter() - start
        server._request_count += 1

        return _chat_response(server, _make_id(), text, elapsed)

    # ---- /v1/completions ----
    @app.post("/v1/completions")
    async def completions(req: CompletionRequest):
        max_tokens = req.max_tokens or 256

        if req.stream:
            if EventSourceResponse is None:
                raise HTTPException(
                    status_code=400,
                    detail="Streaming requires sse-starlette. Install: pip install sse-starlette",
                )
            return EventSourceResponse(
                _stream_completion(server, req.prompt, max_tokens, req),
                media_type="text/event-stream",
            )

        start = time.perf_counter()
        text = await server.generate(
            req.prompt, max_tokens, req.temperature, req.top_p, req.repetition_penalty,
        )
        elapsed = time.perf_counter() - start
        server._request_count += 1
        cmpl_id = f"cmpl-{uuid.uuid4().hex[:12]}"
        return {
            "id": cmpl_id,
            "object": "text_completion",
            "created": int(time.time()),
            "model": server.model_name,
            "choices": [{
                "text": text,
                "index": 0,
                "logprobs": None,
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        }

    # ---- Health / Status ----
    @app.get("/health")
    async def health():
        return {
            "status": "ok",
            "model": server.model_name,
            "template": server.template,
            "requests_served": server._request_count,
        }

    return app


# ============================================================================
# Response Helpers
# ============================================================================

def _chat_response(server: BitTTTServer, cmpl_id: str, text: str,
                   elapsed: float = 0.0) -> dict:
    return {
        "id": cmpl_id,
        "object": "chat.completion",
        "created": int(time.time()),
        "model": server.model_name,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": text},
            "finish_reason": "stop",
        }],
        "usage": {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        },
    }


async def _stream_chat(server: BitTTTServer, prompt: str, max_tokens: int,
                       req: ChatCompletionRequest) -> AsyncGenerator[str, None]:
    cmpl_id = f"chatcmpl-{uuid.uuid4().hex[:12]}"

    # First chunk: role
    yield json.dumps({
        "id": cmpl_id,
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": server.model_name,
        "choices": [{
            "index": 0,
            "delta": {"role": "assistant"},
            "finish_reason": None,
        }],
    })

    # Token chunks
    async for token in server.generate_stream(
        prompt, max_tokens, req.temperature, req.top_p, req.repetition_penalty,
    ):
        yield json.dumps({
            "id": cmpl_id,
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": server.model_name,
            "choices": [{
                "index": 0,
                "delta": {"content": token},
                "finish_reason": None,
            }],
        })

    # Final chunk
    yield json.dumps({
        "id": cmpl_id,
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": server.model_name,
        "choices": [{
            "index": 0,
            "delta": {},
            "finish_reason": "stop",
        }],
    })
    yield "[DONE]"


async def _stream_completion(server: BitTTTServer, prompt: str, max_tokens: int,
                             req: CompletionRequest) -> AsyncGenerator[str, None]:
    cmpl_id = f"cmpl-{uuid.uuid4().hex[:12]}"

    async for token in server.generate_stream(
        prompt, max_tokens, req.temperature, req.top_p, req.repetition_penalty,
    ):
        yield json.dumps({
            "id": cmpl_id,
            "object": "text_completion",
            "created": int(time.time()),
            "model": server.model_name,
            "choices": [{
                "index": 0,
                "text": token,
                "logprobs": None,
                "finish_reason": None,
            }],
        })

    yield json.dumps({
        "id": cmpl_id,
        "object": "text_completion",
        "created": int(time.time()),
        "model": server.model_name,
        "choices": [{
            "index": 0,
            "text": "",
            "logprobs": None,
            "finish_reason": "stop",
        }],
    })
    yield "[DONE]"


# ============================================================================
# CLI Entry Point
# ============================================================================

def serve(model_path: str, host: str = "0.0.0.0", port: int = 8000,
          device: str = "cuda", tokenizer: Optional[str] = None,
          lora: Optional[str] = None, q8_cache: bool = False,
          ttt: bool = False):
    """Start the OpenAI-compatible server."""
    import uvicorn

    server = BitTTTServer(model_path, device=device, tokenizer=tokenizer,
                          lora=lora, q8_cache=q8_cache, ttt=ttt)
    app = create_app(server)

    print(f"\n🚀 Bit-TTT-Engine API server")
    print(f"   Endpoint: http://{host}:{port}")
    print(f"   Docs:     http://{host}:{port}/docs")
    print(f"   Model:    {server.model_name}")
    print(f"   Template: {server.template}")
    print(f"\n   OpenAI SDK usage:")
    print(f'   client = OpenAI(base_url="http://localhost:{port}/v1", api_key="none")')
    print()

    try:
        uvicorn.run(app, host=host, port=port, log_level="info")
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
