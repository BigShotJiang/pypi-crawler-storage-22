//! cuBLAS GEMV wrapper for optimized decode-phase attention
//!
//! Note: cudarc 0.13.x changed API structure, making direct FFI calls complex.
//! This module provides a fallback implementation using standard matmul.
//! Future: Implement proper cuBLAS integration when API stabilizes.

use candle_core::{DType, Device, Result, Tensor};

#[cfg(feature = "cuda")]
use crate::kernels::fused_ops::softmax_cuda;

/// Optimized decode attention (currently uses standard matmul with CUDA softmax)
///
/// For decode phase (seq_q = 1).
/// TODO: Implement cuBLAS GEMV when cudarc API allows direct FFI calls.
pub fn decode_attention_gemv(
    q: &Tensor, // [batch, n_heads, 1, head_dim]
    k: &Tensor, // [batch, n_heads, seq_kv, head_dim]
    v: &Tensor, // [batch, n_heads, seq_kv, head_dim]
    scale: f32,
    softcap: Option<f32>,
) -> Result<Tensor> {
    use candle_core::D;

    // QK^T
    let attn_weights = q.matmul(&k.transpose(D::Minus2, D::Minus1)?)?;
    let attn_weights = (attn_weights * scale as f64)?;

    // Softcapping (Gemma-2)
    let attn_weights = if let Some(cap) = softcap {
        if cap > 0.0 {
            ((attn_weights / cap as f64)?.tanh()? * cap as f64)?
        } else {
            attn_weights
        }
    } else {
        attn_weights
    };

    // Softmax with CUDA support
    let attn_weights = softmax_safe(&attn_weights)?;

    // Output
    attn_weights.matmul(v)
}

/// Softmax with CUDA/CPU fallback
fn softmax_safe(x: &Tensor) -> Result<Tensor> {
    #[cfg(feature = "cuda")]
    {
        if matches!(x.device(), Device::Cuda(_)) {
            // Use CUDA softmax
            return softmax_cuda(x);
        }
    }
    // CPU fallback
    candle_nn::ops::softmax_last_dim(x)
}
