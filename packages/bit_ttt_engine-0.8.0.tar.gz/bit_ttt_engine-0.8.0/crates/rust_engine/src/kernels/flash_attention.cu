/**
 * Flash Attention CUDA Kernel
 * 
 * Implements memory-efficient attention computation.
 * Reference: https://arxiv.org/abs/2205.14135
 * 
 * This is a simplified version optimized for inference.
 */

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <float.h>

// Block sizes - tuned for common head dimensions
#define BLOCK_M 64  // Query block size
#define BLOCK_N 64  // Key/Value block size
#define WARP_SIZE 32

/**
 * Flash Attention Forward Kernel
 * 
 * Computes: softmax(Q @ K^T / sqrt(d)) @ V
 * 
 * @param Q         Query tensor [batch, heads, seq_q, head_dim]
 * @param K         Key tensor [batch, heads, seq_kv, head_dim]
 * @param V         Value tensor [batch, heads, seq_kv, head_dim]
 * @param O         Output tensor [batch, heads, seq_q, head_dim]
 * @param batch     Batch size
 * @param heads     Number of attention heads
 * @param seq_q     Query sequence length
 * @param seq_kv    Key/Value sequence length
 * @param head_dim  Head dimension
 * @param scale     Scale factor (1/sqrt(head_dim))
 * @param causal    Whether to apply causal masking
 */
extern "C" __global__ void flash_attention_fwd_f32(
    const float* __restrict__ Q,
    const float* __restrict__ K,
    const float* __restrict__ V,
    float* __restrict__ O,
    int batch,
    int heads,
    int seq_q,
    int seq_kv,
    int head_dim,
    float scale,
    int causal
) {
    // Each block handles one query position for one batch/head
    int batch_idx = blockIdx.z;
    int head_idx = blockIdx.y;
    int q_idx = blockIdx.x * blockDim.x + threadIdx.x;
    
    if (q_idx >= seq_q) return;
    
    // Calculate offsets
    int qkv_offset = (batch_idx * heads + head_idx) * seq_q * head_dim;
    int kv_offset = (batch_idx * heads + head_idx) * seq_kv * head_dim;
    
    // Local accumulators
    float m = -FLT_MAX;  // Running max
    float l = 0.0f;       // Running sum of exp
    
    // Output accumulator (per head_dim)
    extern __shared__ float shared_mem[];
    float* output_acc = &shared_mem[threadIdx.x * head_dim];
    
    // Initialize output accumulator to 0
    for (int d = 0; d < head_dim; d++) {
        output_acc[d] = 0.0f;
    }
    
    // Load query vector for this position
    float q_vec[128];  // Max head_dim = 128
    for (int d = 0; d < head_dim; d++) {
        q_vec[d] = Q[qkv_offset + q_idx * head_dim + d];
    }
    
    // Iterate over key/value positions
    int kv_end = causal ? min(q_idx + 1, seq_kv) : seq_kv;
    
    for (int kv_idx = 0; kv_idx < kv_end; kv_idx++) {
        // Compute attention score: q @ k / sqrt(d)
        float score = 0.0f;
        for (int d = 0; d < head_dim; d++) {
            float k_val = K[kv_offset + kv_idx * head_dim + d];
            score += q_vec[d] * k_val;
        }
        score *= scale;
        
        // Online softmax update
        float m_new = fmaxf(m, score);
        float exp_diff = expf(m - m_new);
        float exp_score = expf(score - m_new);
        
        // Update output: o = exp(m-m_new)*o + exp(score-m_new)*v
        for (int d = 0; d < head_dim; d++) {
            float v_val = V[kv_offset + kv_idx * head_dim + d];
            output_acc[d] = exp_diff * output_acc[d] + exp_score * v_val;
        }
        
        // Update running statistics
        l = exp_diff * l + exp_score;
        m = m_new;
    }
    
    // Final normalization: o = o / l
    for (int d = 0; d < head_dim; d++) {
        O[qkv_offset + q_idx * head_dim + d] = output_acc[d] / l;
    }
}

/**
 * Simplified Flash Attention for small head dimensions (<=64)
 * Uses registers instead of shared memory for better performance
 */
extern "C" __global__ void flash_attention_fwd_f32_small(
    const float* __restrict__ Q,
    const float* __restrict__ K,
    const float* __restrict__ V,
    float* __restrict__ O,
    int batch,
    int heads,
    int seq_q,
    int seq_kv,
    int head_dim,
    float scale,
    int causal
) {
    // Each thread handles one query position
    int batch_head_idx = blockIdx.y;
    int batch_idx = batch_head_idx / heads;
    int head_idx = batch_head_idx % heads;
    int q_idx = blockIdx.x * blockDim.x + threadIdx.x;
    
    if (batch_idx >= batch || q_idx >= seq_q) return;
    
    // Calculate offsets
    int q_base = ((batch_idx * heads + head_idx) * seq_q + q_idx) * head_dim;
    int kv_base = (batch_idx * heads + head_idx) * seq_kv * head_dim;
    
    // Local accumulators (registers)
    float m = -FLT_MAX;
    float l = 0.0f;
    float output_acc[64];  // Max head_dim = 64 for this kernel
    
    // Initialize
    for (int d = 0; d < head_dim; d++) {
        output_acc[d] = 0.0f;
    }
    
    // Load query
    float q_vec[64];
    for (int d = 0; d < head_dim; d++) {
        q_vec[d] = Q[q_base + d];
    }
    
    // Process all KV positions
    int kv_end = causal ? min(q_idx + 1, seq_kv) : seq_kv;
    
    for (int kv_idx = 0; kv_idx < kv_end; kv_idx++) {
        int kv_pos = kv_base + kv_idx * head_dim;
        
        // Compute dot product
        float score = 0.0f;
        for (int d = 0; d < head_dim; d++) {
            score += q_vec[d] * K[kv_pos + d];
        }
        score *= scale;
        
        // Online softmax
        float m_new = fmaxf(m, score);
        float exp_diff = expf(m - m_new);
        float exp_score = expf(score - m_new);
        
        // Update output
        for (int d = 0; d < head_dim; d++) {
            output_acc[d] = exp_diff * output_acc[d] + exp_score * V[kv_pos + d];
        }
        
        l = exp_diff * l + exp_score;
        m = m_new;
    }
    
    // Write output
    for (int d = 0; d < head_dim; d++) {
        O[q_base + d] = output_acc[d] / l;
    }
}
