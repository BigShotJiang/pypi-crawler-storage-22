//! CUDA Flash Attention Implementation
//!
//! Provides GPU-accelerated flash attention for efficient inference.

#[cfg(feature = "cuda")]
use candle_core::cuda_backend::cudarc::driver::{DevicePtr, LaunchAsync, LaunchConfig};
#[cfg(feature = "cuda")]
use candle_core::cuda_backend::WrapErr;
#[cfg(feature = "cuda")]
use candle_core::Device;
use candle_core::{DType, Result, Tensor};
#[cfg(feature = "cuda")]
use std::sync::OnceLock;

#[cfg(feature = "cuda")]
const FLASH_ATTN_PTX: &str = include_str!(concat!(env!("OUT_DIR"), "/flash_attention.ptx"));

#[cfg(feature = "cuda")]
static FLASH_ATTN_LOADED: OnceLock<std::sync::Mutex<std::collections::HashSet<usize>>> =
    OnceLock::new();

#[cfg(feature = "cuda")]
fn ensure_flash_attn_loaded(
    cuda_dev: &std::sync::Arc<candle_core::cuda_backend::cudarc::driver::CudaDevice>,
    device_id: usize,
) -> Result<()> {
    let loaded =
        FLASH_ATTN_LOADED.get_or_init(|| std::sync::Mutex::new(std::collections::HashSet::new()));
    let mut guard = loaded.lock().unwrap();

    if !guard.contains(&device_id) {
        cuda_dev
            .load_ptx(
                FLASH_ATTN_PTX.into(),
                "flash_attention",
                &["flash_attention_fwd_f32", "flash_attention_fwd_f32_small"],
            )
            .w()?;
        guard.insert(device_id);
        tracing::info!("Loaded flash_attention PTX for device {}", device_id);
    }

    Ok(())
}

/// CUDA Flash Attention
///
/// # Arguments
/// * `q` - Query tensor [batch, heads, seq_q, head_dim]
/// * `k` - Key tensor [batch, heads, seq_kv, head_dim]
/// * `v` - Value tensor [batch, heads, seq_kv, head_dim]
/// * `scale` - Scale factor (typically 1/sqrt(head_dim))
/// * `causal` - Whether to apply causal masking
///
/// # Returns
/// * Output tensor [batch, heads, seq_q, head_dim]
#[cfg(feature = "cuda")]
pub fn flash_attention_cuda(
    q: &Tensor,
    k: &Tensor,
    v: &Tensor,
    scale: f32,
    causal: bool,
) -> Result<Tensor> {
    let dev = match q.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => {
            // CPU fallback - use standard attention
            return standard_attention_fallback(q, k, v, scale, causal);
        }
    };

    let cuda_dev = dev.cuda_device();
    ensure_flash_attn_loaded(&cuda_dev, dev.ordinal())?;

    let (batch, heads, seq_q, head_dim) = q.dims4()?;
    let (_, _, seq_kv, _) = k.dims4()?;

    // Convert to F32 and ensure contiguous
    let q_f32 = q.to_dtype(DType::F32)?.contiguous()?;
    let k_f32 = k.to_dtype(DType::F32)?.contiguous()?;
    let v_f32 = v.to_dtype(DType::F32)?.contiguous()?;

    // Get pointers
    let q_ptr = {
        let storage = q_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("Q must be CUDA tensor".to_string())),
        }
    };

    let k_ptr = {
        let storage = k_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("K must be CUDA tensor".to_string())),
        }
    };

    let v_ptr = {
        let storage = v_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("V must be CUDA tensor".to_string())),
        }
    };

    // Allocate output
    let output = Tensor::zeros(
        (batch, heads, seq_q, head_dim),
        DType::F32,
        &Device::Cuda(dev.clone()),
    )?;
    let out_ptr = {
        let storage = output.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Output allocation failed".to_string(),
                ))
            }
        }
    };

    // Choose kernel based on head_dim
    let kernel_name = if head_dim <= 64 {
        "flash_attention_fwd_f32_small"
    } else {
        "flash_attention_fwd_f32"
    };

    let func = match cuda_dev.get_func("flash_attention", kernel_name) {
        Some(f) => f,
        None => {
            tracing::warn!("Flash attention CUDA kernel not found, using fallback");
            return standard_attention_fallback(q, k, v, scale, causal);
        }
    };

    // Launch configuration
    let block_size = 256u32;
    let grid_x = (seq_q as u32 + block_size - 1) / block_size;
    let grid_y = (batch * heads) as u32;

    let shared_mem = if head_dim <= 64 {
        0 // Small kernel uses registers
    } else {
        (block_size as usize * head_dim * std::mem::size_of::<f32>()) as u32
    };

    let cfg = LaunchConfig {
        grid_dim: (grid_x, grid_y, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: shared_mem,
    };

    let params = (
        q_ptr,
        k_ptr,
        v_ptr,
        out_ptr,
        batch as i32,
        heads as i32,
        seq_q as i32,
        seq_kv as i32,
        head_dim as i32,
        scale,
        if causal { 1i32 } else { 0i32 },
    );

    unsafe { func.launch(cfg, params) }.w()?;

    output.to_dtype(q.dtype())
}

#[cfg(not(feature = "cuda"))]
pub fn flash_attention_cuda(
    q: &Tensor,
    k: &Tensor,
    v: &Tensor,
    scale: f32,
    causal: bool,
) -> Result<Tensor> {
    standard_attention_fallback(q, k, v, scale, causal)
}

/// Standard attention fallback for CPU or when CUDA kernel unavailable
fn standard_attention_fallback(
    q: &Tensor,
    k: &Tensor,
    v: &Tensor,
    scale: f32,
    causal: bool,
) -> Result<Tensor> {
    use candle_core::D;

    // QK^T
    let attn_weights = q.matmul(&k.transpose(D::Minus2, D::Minus1)?)?;
    let attn_weights = (attn_weights * scale as f64)?;

    // Causal mask
    let attn_weights = if causal {
        let (_, _, seq_q, seq_kv) = attn_weights.dims4()?;
        let mask = Tensor::tril2(seq_kv, q.dtype(), q.device())?;
        let mask = mask.narrow(0, 0, seq_q)?;
        let neg_inf = Tensor::new(f32::NEG_INFINITY, q.device())?;
        attn_weights.where_cond(&mask.broadcast_as(attn_weights.shape())?, &neg_inf)?
    } else {
        attn_weights
    };

    // Softmax (use our fused_ops which handles CUDA context resets)
    let attn_weights = crate::kernels::fused_ops::softmax_cuda(&attn_weights)?;

    // Attention output
    attn_weights.matmul(v)
}
