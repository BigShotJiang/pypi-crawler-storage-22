/**
 * Flash-Decoding CUDA Kernels
 * 
 * Optimized attention for decode phase (seq_q=1).
 * Parallelizes across KV sequence length for better GPU utilization.
 * 
 * Reference: https://crfm.stanford.edu/2023/10/12/flashdecoding.html
 */

#include <cuda_runtime.h>
#include <float.h>

#define WARP_SIZE 32

// ============================================================================
// Flash-Decoding Split Kernel
// ============================================================================

/**
 * Compute partial attention for one KV split.
 * Each CUDA block handles one split for one (batch, head) pair.
 * 
 * @param Q             Query [batch, n_heads, 1, head_dim]
 * @param K             Key cache [batch, n_kv_heads, seq_kv, head_dim]
 * @param V             Value cache [batch, n_kv_heads, seq_kv, head_dim]
 * @param partial_O     Partial outputs [batch, n_heads, num_splits, head_dim]
 * @param partial_m     Partial max [batch, n_heads, num_splits]
 * @param partial_l     Partial sum [batch, n_heads, num_splits]
 * @param batch         Batch size
 * @param n_heads       Number of query heads
 * @param n_kv_heads    Number of KV heads (for GQA)
 * @param seq_kv        KV sequence length
 * @param head_dim      Head dimension
 * @param num_splits    Number of KV splits
 * @param scale         Attention scale (1/sqrt(head_dim))
 * @param softcap       Softcapping value (0 = disabled)
 */
extern "C" __global__ void flash_decode_split_kernel_f32(
    const float* __restrict__ Q,
    const float* __restrict__ K,
    const float* __restrict__ V,
    float* __restrict__ partial_O,
    float* __restrict__ partial_m,
    float* __restrict__ partial_l,
    int batch,
    int n_heads,
    int n_kv_heads,
    int seq_kv,
    int head_dim,
    int num_splits,
    float scale,
    float softcap
) {
    // Block indices
    const int split_idx = blockIdx.x;
    const int batch_head_idx = blockIdx.y;
    const int batch_idx = batch_head_idx / n_heads;
    const int head_idx = batch_head_idx % n_heads;
    
    if (batch_idx >= batch || split_idx >= num_splits) return;
    
    // GQA: map query head to KV head
    const int kv_head_idx = head_idx * n_kv_heads / n_heads;
    
    // Calculate split range
    const int split_size = (seq_kv + num_splits - 1) / num_splits;
    const int kv_start = split_idx * split_size;
    const int kv_end = min(kv_start + split_size, seq_kv);
    
    if (kv_start >= seq_kv) {
        // This split has no tokens
        const int out_idx = (batch_idx * n_heads + head_idx) * num_splits + split_idx;
        partial_m[out_idx] = -FLT_MAX;
        partial_l[out_idx] = 0.0f;
        for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
            partial_O[(out_idx * head_dim) + d] = 0.0f;
        }
        return;
    }
    
    // Shared memory for query and scores
    extern __shared__ float shared[];
    float* q_shared = shared;                           // [head_dim]
    float* scores = shared + head_dim;                  // [split_size]
    
    // Load query into shared memory
    const int q_base = (batch_idx * n_heads + head_idx) * head_dim;
    for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
        q_shared[d] = Q[q_base + d];
    }
    __syncthreads();
    
    // Compute Q @ K^T for this split
    const int kv_base = (batch_idx * n_kv_heads + kv_head_idx) * seq_kv * head_dim;
    float local_max = -FLT_MAX;
    
    for (int kv_idx = kv_start + threadIdx.x; kv_idx < kv_end; kv_idx += blockDim.x) {
        float score = 0.0f;
        const int k_offset = kv_base + kv_idx * head_dim;
        
        // Dot product Q @ K
        for (int d = 0; d < head_dim; d++) {
            score += q_shared[d] * K[k_offset + d];
        }
        score *= scale;
        
        // Softcapping (Gemma-2)
        if (softcap > 0.0f) {
            score = tanhf(score / softcap) * softcap;
        }
        
        scores[kv_idx - kv_start] = score;
        local_max = fmaxf(local_max, score);
    }
    __syncthreads();
    
    // Warp reduction for max
    for (int offset = WARP_SIZE / 2; offset > 0; offset >>= 1) {
        local_max = fmaxf(local_max, __shfl_down_sync(0xffffffff, local_max, offset));
    }
    
    // Block reduction for max (first thread of each warp)
    __shared__ float warp_max[32];
    const int warp_id = threadIdx.x / WARP_SIZE;
    const int lane_id = threadIdx.x % WARP_SIZE;
    
    if (lane_id == 0) {
        warp_max[warp_id] = local_max;
    }
    __syncthreads();
    
    if (threadIdx.x == 0) {
        float block_max = warp_max[0];
        for (int i = 1; i < (blockDim.x + WARP_SIZE - 1) / WARP_SIZE; i++) {
            block_max = fmaxf(block_max, warp_max[i]);
        }
        warp_max[0] = block_max;
    }
    __syncthreads();
    
    float m = warp_max[0];  // Global max for this split
    
    // Compute exp(score - max) and sum
    float local_sum = 0.0f;
    const int local_len = kv_end - kv_start;
    
    for (int i = threadIdx.x; i < local_len; i += blockDim.x) {
        float exp_score = expf(scores[i] - m);
        scores[i] = exp_score;
        local_sum += exp_score;
    }
    __syncthreads();
    
    // Warp reduction for sum
    for (int offset = WARP_SIZE / 2; offset > 0; offset >>= 1) {
        local_sum += __shfl_down_sync(0xffffffff, local_sum, offset);
    }
    
    __shared__ float warp_sum[32];
    if (lane_id == 0) {
        warp_sum[warp_id] = local_sum;
    }
    __syncthreads();
    
    if (threadIdx.x == 0) {
        float block_sum = warp_sum[0];
        for (int i = 1; i < (blockDim.x + WARP_SIZE - 1) / WARP_SIZE; i++) {
            block_sum += warp_sum[i];
        }
        warp_sum[0] = block_sum;
    }
    __syncthreads();
    
    float l = warp_sum[0];  // Global sum for this split
    
    // Compute output: sum(softmax(scores) @ V)
    const int out_base = ((batch_idx * n_heads + head_idx) * num_splits + split_idx) * head_dim;
    
    for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
        float acc = 0.0f;
        for (int i = 0; i < local_len; i++) {
            const int v_offset = kv_base + (kv_start + i) * head_dim + d;
            acc += scores[i] * V[v_offset];
        }
        partial_O[out_base + d] = acc;
    }
    
    // Store partial m and l
    if (threadIdx.x == 0) {
        const int ml_idx = (batch_idx * n_heads + head_idx) * num_splits + split_idx;
        partial_m[ml_idx] = m;
        partial_l[ml_idx] = l;
    }
}

// ============================================================================
// Flash-Decoding Reduce Kernel
// ============================================================================

/**
 * Combine partial results from all splits.
 * Uses log-sum-exp rescaling for numerical stability.
 * 
 * @param partial_O     Partial outputs [batch, n_heads, num_splits, head_dim]
 * @param partial_m     Partial max [batch, n_heads, num_splits]
 * @param partial_l     Partial sum [batch, n_heads, num_splits]
 * @param O             Final output [batch, n_heads, head_dim]
 * @param batch         Batch size
 * @param n_heads       Number of heads
 * @param head_dim      Head dimension
 * @param num_splits    Number of splits
 */
extern "C" __global__ void flash_decode_reduce_kernel_f32(
    const float* __restrict__ partial_O,
    const float* __restrict__ partial_m,
    const float* __restrict__ partial_l,
    float* __restrict__ O,
    int batch,
    int n_heads,
    int head_dim,
    int num_splits
) {
    const int batch_head_idx = blockIdx.x;
    const int batch_idx = batch_head_idx / n_heads;
    const int head_idx = batch_head_idx % n_heads;
    
    if (batch_idx >= batch) return;
    
    // Find global max across all splits
    const int ml_base = (batch_idx * n_heads + head_idx) * num_splits;
    
    float m_global = -FLT_MAX;
    for (int s = 0; s < num_splits; s++) {
        m_global = fmaxf(m_global, partial_m[ml_base + s]);
    }
    
    // Compute rescaled sum: sum(exp(m_i - m_global) * l_i)
    float l_global = 0.0f;
    for (int s = 0; s < num_splits; s++) {
        float m_i = partial_m[ml_base + s];
        float l_i = partial_l[ml_base + s];
        l_global += expf(m_i - m_global) * l_i;
    }
    
    // Compute final output
    const int out_base = (batch_idx * n_heads + head_idx) * head_dim;
    const int partial_base = (batch_idx * n_heads + head_idx) * num_splits * head_dim;
    
    for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
        float acc = 0.0f;
        for (int s = 0; s < num_splits; s++) {
            float m_i = partial_m[ml_base + s];
            float o_i = partial_O[partial_base + s * head_dim + d];
            
            // Rescale: exp(m_i - m_global) * o_i
            // Note: o_i already contains sum of (softmax * v), not normalized
            acc += expf(m_i - m_global) * o_i;
        }
        O[out_base + d] = acc / l_global;
    }
}

// ============================================================================
// Single-kernel Flash-Decoding (for small seq_kv)
// ============================================================================

/**
 * Flash-Decoding in a single kernel for small KV sequences.
 * More efficient when seq_kv is small (< 1024).
 * 
 * @param Q             Query [batch, n_heads, 1, head_dim]
 * @param K             Key cache [batch, n_kv_heads, seq_kv, head_dim]
 * @param V             Value cache [batch, n_kv_heads, seq_kv, head_dim]
 * @param O             Output [batch, n_heads, head_dim]
 */
extern "C" __global__ void flash_decode_single_kernel_f32(
    const float* __restrict__ Q,
    const float* __restrict__ K,
    const float* __restrict__ V,
    float* __restrict__ O,
    int batch,
    int n_heads,
    int n_kv_heads,
    int seq_kv,
    int head_dim,
    float scale,
    float softcap
) {
    const int batch_head_idx = blockIdx.x;
    const int batch_idx = batch_head_idx / n_heads;
    const int head_idx = batch_head_idx % n_heads;
    
    if (batch_idx >= batch) return;
    
    // GQA mapping
    const int kv_head_idx = head_idx * n_kv_heads / n_heads;
    
    // Load query (all threads cooperate)
    extern __shared__ float shared[];
    float* q_shared = shared;
    
    const int q_base = (batch_idx * n_heads + head_idx) * head_dim;
    for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
        q_shared[d] = Q[q_base + d];
    }
    __syncthreads();
    
    // Each thread handles a subset of KV positions
    const int kv_base = (batch_idx * n_kv_heads + kv_head_idx) * seq_kv * head_dim;
    
    // Online softmax variables
    float m = -FLT_MAX;
    float l = 0.0f;
    float o[128];  // Max head_dim = 128 for this kernel
    
    for (int d = 0; d < head_dim; d++) {
        o[d] = 0.0f;
    }
    
    // Process KV positions assigned to this thread
    for (int kv_idx = threadIdx.x; kv_idx < seq_kv; kv_idx += blockDim.x) {
        // Compute score
        float score = 0.0f;
        const int k_offset = kv_base + kv_idx * head_dim;
        
        for (int d = 0; d < head_dim; d++) {
            score += q_shared[d] * K[k_offset + d];
        }
        score *= scale;
        
        // Softcapping
        if (softcap > 0.0f) {
            score = tanhf(score / softcap) * softcap;
        }
        
        // Online softmax update
        float m_new = fmaxf(m, score);
        float exp_diff = expf(m - m_new);
        float exp_score = expf(score - m_new);
        
        // Update output: o = exp(m-m_new)*o + exp(score-m_new)*v
        const int v_offset = kv_base + kv_idx * head_dim;
        for (int d = 0; d < head_dim; d++) {
            o[d] = exp_diff * o[d] + exp_score * V[v_offset + d];
        }
        
        l = exp_diff * l + exp_score;
        m = m_new;
    }
    
    // Warp reduction for online softmax state
    // This is more complex - need to combine (m, l, o) correctly
    // For simplicity, we'll use atomics for the final output
    
    // Final normalization
    for (int d = 0; d < head_dim; d++) {
        o[d] /= l;
    }
    
    // Write output (using atomics for thread reduction)
    const int out_base = (batch_idx * n_heads + head_idx) * head_dim;
    
    // Simple approach: only thread 0 computes full attention
    // For better parallelism, use shared memory reduction
    if (threadIdx.x == 0) {
        // Recompute for single thread (correct but slow fallback)
        m = -FLT_MAX;
        l = 0.0f;
        for (int d = 0; d < head_dim; d++) o[d] = 0.0f;
        
        for (int kv_idx = 0; kv_idx < seq_kv; kv_idx++) {
            float score = 0.0f;
            const int k_offset = kv_base + kv_idx * head_dim;
            
            for (int d = 0; d < head_dim; d++) {
                score += q_shared[d] * K[k_offset + d];
            }
            score *= scale;
            
            if (softcap > 0.0f) {
                score = tanhf(score / softcap) * softcap;
            }
            
            float m_new = fmaxf(m, score);
            float exp_diff = expf(m - m_new);
            float exp_score = expf(score - m_new);
            
            const int v_offset = kv_base + kv_idx * head_dim;
            for (int d = 0; d < head_dim; d++) {
                o[d] = exp_diff * o[d] + exp_score * V[v_offset + d];
            }
            
            l = exp_diff * l + exp_score;
            m = m_new;
        }
        
        for (int d = 0; d < head_dim; d++) {
            O[out_base + d] = o[d] / l;
        }
    }
}
