//! Flash-Decoding for optimized decode-phase attention
//!
//! Implements parallel attention over KV sequence length.
//! Reference: https://crfm.stanford.edu/2023/10/12/flashdecoding.html

#[cfg(feature = "cuda")]
use candle_core::cuda_backend::cudarc::driver::{DevicePtr, LaunchAsync, LaunchConfig};
#[cfg(feature = "cuda")]
use candle_core::cuda_backend::WrapErr;
#[cfg(feature = "cuda")]
use candle_core::Device;
use candle_core::{DType, Result, Tensor};
#[cfg(feature = "cuda")]
use std::sync::OnceLock;

/// Pre-allocated buffers for flash decode (avoids 4 GPU allocs per layer per token)
pub struct FlashDecodeBuffers {
    pub output: Tensor,    // [batch, n_heads, head_dim]
    pub partial_o: Tensor, // [batch, n_heads, max_splits, head_dim]
    pub partial_m: Tensor, // [batch, n_heads, max_splits]
    pub partial_l: Tensor, // [batch, n_heads, max_splits]
    pub max_splits: usize,
}

impl FlashDecodeBuffers {
    /// Create pre-allocated buffers for flash decode
    pub fn new(
        batch: usize,
        n_heads: usize,
        head_dim: usize,
        max_splits: usize,
        device: &candle_core::Device,
    ) -> Result<Self> {
        Ok(Self {
            output: Tensor::zeros((batch, n_heads, head_dim), DType::F32, device)?,
            partial_o: Tensor::zeros((batch, n_heads, max_splits, head_dim), DType::F32, device)?,
            partial_m: Tensor::zeros((batch, n_heads, max_splits), DType::F32, device)?,
            partial_l: Tensor::zeros((batch, n_heads, max_splits), DType::F32, device)?,
            max_splits,
        })
    }
}

#[cfg(feature = "cuda")]
const FLASH_DECODE_PTX: &str = include_str!(concat!(env!("OUT_DIR"), "/flash_decoding.ptx"));

#[cfg(feature = "cuda")]
const FLASH_DECODE_FP16_PTX: &str =
    include_str!(concat!(env!("OUT_DIR"), "/flash_decoding_fp16.ptx"));

#[cfg(feature = "cuda")]
static FLASH_DECODE_LOADED: OnceLock<std::sync::Mutex<std::collections::HashSet<usize>>> =
    OnceLock::new();

#[cfg(feature = "cuda")]
static FLASH_DECODE_FP16_LOADED: OnceLock<std::sync::Mutex<std::collections::HashSet<usize>>> =
    OnceLock::new();

#[cfg(feature = "cuda")]
fn ensure_flash_decode_loaded(
    cuda_dev: &std::sync::Arc<candle_core::cuda_backend::cudarc::driver::CudaDevice>,
    device_id: usize,
) -> Result<()> {
    let loaded =
        FLASH_DECODE_LOADED.get_or_init(|| std::sync::Mutex::new(std::collections::HashSet::new()));
    let mut guard = loaded.lock().unwrap();

    if !guard.contains(&device_id) {
        cuda_dev
            .load_ptx(
                FLASH_DECODE_PTX.into(),
                "flash_decoding",
                &[
                    "flash_decode_split_kernel_f32",
                    "flash_decode_reduce_kernel_f32",
                    "flash_decode_single_kernel_f32",
                ],
            )
            .w()?;
        guard.insert(device_id);
        tracing::info!("Loaded flash_decoding PTX for device {}", device_id);
    }

    Ok(())
}

#[cfg(feature = "cuda")]
fn ensure_flash_decode_fp16_loaded(
    cuda_dev: &std::sync::Arc<candle_core::cuda_backend::cudarc::driver::CudaDevice>,
    device_id: usize,
) -> Result<()> {
    let loaded = FLASH_DECODE_FP16_LOADED
        .get_or_init(|| std::sync::Mutex::new(std::collections::HashSet::new()));
    let mut guard = loaded.lock().unwrap();

    if !guard.contains(&device_id) {
        cuda_dev
            .load_ptx(
                FLASH_DECODE_FP16_PTX.into(),
                "flash_decoding_fp16",
                &[
                    "flash_decode_split_kernel_f16",
                    "flash_decode_reduce_kernel_f16",
                    "flash_decode_single_kernel_f16_v2",
                ],
            )
            .w()?;
        guard.insert(device_id);
        tracing::info!("Loaded flash_decoding_fp16 PTX for device {}", device_id);
    }

    Ok(())
}

/// Flash-Decoding for decode phase (seq_q = 1)
///
/// # Arguments
/// * `q` - Query tensor [batch, n_heads, 1, head_dim]
/// * `k` - Key cache [batch, n_kv_heads, seq_kv, head_dim]
/// * `v` - Value cache [batch, n_kv_heads, seq_kv, head_dim]
/// * `scale` - Attention scale (1/sqrt(head_dim) or custom)
/// * `softcap` - Softcapping value (0 = disabled, used by Gemma-2)
///
/// # Returns
/// * Output tensor [batch, n_heads, 1, head_dim]
#[cfg(feature = "cuda")]
pub fn flash_decode_cuda(
    q: &Tensor,
    k: &Tensor,
    v: &Tensor,
    scale: f32,
    softcap: f32,
) -> Result<Tensor> {
    let dev = match q.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => {
            // CPU fallback
            return flash_decode_cpu(q, k, v, scale, softcap);
        }
    };

    let cuda_dev = dev.cuda_device();
    ensure_flash_decode_loaded(&cuda_dev, dev.ordinal())?;

    // Get dimensions
    let (batch, n_heads, seq_q, head_dim) = q.dims4()?;
    let (_, n_kv_heads, seq_kv, _) = k.dims4()?;

    // Flash-Decoding is for seq_q = 1
    if seq_q != 1 {
        tracing::warn!(
            "Flash-Decoding called with seq_q={}, falling back to standard attention",
            seq_q
        );
        return flash_decode_cpu(q, k, v, scale, softcap);
    }

    // Convert to F32 and ensure contiguous
    let q_f32 = q.to_dtype(DType::F32)?.contiguous()?;
    let k_f32 = k.to_dtype(DType::F32)?.contiguous()?;
    let v_f32 = v.to_dtype(DType::F32)?.contiguous()?;

    // Squeeze query: [batch, n_heads, 1, head_dim] -> [batch, n_heads, head_dim]
    let q_squeezed = q_f32.squeeze(2)?;

    // Get device pointers
    let q_ptr = get_cuda_ptr(&q_squeezed)?;
    let k_ptr = get_cuda_ptr(&k_f32)?;
    let v_ptr = get_cuda_ptr(&v_f32)?;

    // Determine number of splits based on seq_kv
    // Ensure split_size fits in shared memory (max ~1024 floats for scores)
    // For large head_dim (256), we need more splits
    let max_split_size = if head_dim > 128 { 256 } else { 512 };
    let min_splits = (seq_kv + max_split_size - 1) / max_split_size;

    let num_splits = if seq_kv <= 64 {
        min_splits.max(2)
    } else if seq_kv <= 256 {
        min_splits.max(4)
    } else if seq_kv <= 1024 {
        min_splits.max(8)
    } else if seq_kv <= 4096 {
        min_splits.max(16)
    } else {
        min_splits.max(32)
    };

    // Allocate output
    let output = Tensor::zeros(
        (batch, n_heads, head_dim),
        DType::F32,
        &Device::Cuda(dev.clone()),
    )?;
    let out_ptr = get_cuda_ptr(&output)?;

    // Always use split + reduce kernels for better GPU utilization
    {
        // Use split + reduce kernels for larger sequences

        // Allocate partial results
        let partial_o = Tensor::zeros(
            (batch, n_heads, num_splits, head_dim),
            DType::F32,
            &Device::Cuda(dev.clone()),
        )?;
        let partial_m = Tensor::zeros(
            (batch, n_heads, num_splits),
            DType::F32,
            &Device::Cuda(dev.clone()),
        )?;
        let partial_l = Tensor::zeros(
            (batch, n_heads, num_splits),
            DType::F32,
            &Device::Cuda(dev.clone()),
        )?;

        let partial_o_ptr = get_cuda_ptr(&partial_o)?;
        let partial_m_ptr = get_cuda_ptr(&partial_m)?;
        let partial_l_ptr = get_cuda_ptr(&partial_l)?;

        // Launch split kernel
        let split_func = match cuda_dev.get_func("flash_decoding", "flash_decode_split_kernel_f32")
        {
            Some(f) => f,
            None => {
                tracing::warn!("Flash decode split kernel not found, using CPU fallback");
                return flash_decode_cpu(q, k, v, scale, softcap);
            }
        };

        let split_size = (seq_kv + num_splits - 1) / num_splits;
        let block_size = 256u32;
        let shared_mem = ((head_dim + split_size) * std::mem::size_of::<f32>()) as u32;

        let split_cfg = LaunchConfig {
            grid_dim: (num_splits as u32, (batch * n_heads) as u32, 1),
            block_dim: (block_size, 1, 1),
            shared_mem_bytes: shared_mem,
        };

        let split_params = (
            q_ptr,
            k_ptr,
            v_ptr,
            partial_o_ptr,
            partial_m_ptr,
            partial_l_ptr,
            batch as i32,
            n_heads as i32,
            n_kv_heads as i32,
            seq_kv as i32,
            head_dim as i32,
            num_splits as i32,
            scale,
            softcap,
        );

        unsafe { split_func.launch(split_cfg, split_params) }.w()?;

        // Launch reduce kernel
        let reduce_func =
            match cuda_dev.get_func("flash_decoding", "flash_decode_reduce_kernel_f32") {
                Some(f) => f,
                None => {
                    tracing::warn!("Flash decode reduce kernel not found, using CPU fallback");
                    return flash_decode_cpu(q, k, v, scale, softcap);
                }
            };

        let reduce_cfg = LaunchConfig {
            grid_dim: ((batch * n_heads) as u32, 1, 1),
            block_dim: (256u32.min(head_dim as u32), 1, 1),
            shared_mem_bytes: 0,
        };

        let reduce_params = (
            partial_o_ptr,
            partial_m_ptr,
            partial_l_ptr,
            out_ptr,
            batch as i32,
            n_heads as i32,
            head_dim as i32,
            num_splits as i32,
        );

        unsafe { reduce_func.launch(reduce_cfg, reduce_params) }.w()?;
    }

    // Reshape output: [batch, n_heads, head_dim] -> [batch, n_heads, 1, head_dim]
    let output = output.unsqueeze(2)?;
    output.to_dtype(q.dtype())
}

/// Flash-Decoding with pre-allocated buffers (zero-allocation decode)
///
/// Same as flash_decode_cuda but reuses buffers to avoid 4 GPU allocs per call.
/// Saves ~128 CUDA malloc/free per token for 32-layer models.
#[cfg(feature = "cuda")]
pub fn flash_decode_cuda_buffered(
    q: &Tensor,
    k: &Tensor,
    v: &Tensor,
    scale: f32,
    softcap: f32,
    bufs: &FlashDecodeBuffers,
) -> Result<Tensor> {
    let dev = match q.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => return flash_decode_cpu(q, k, v, scale, softcap),
    };

    let cuda_dev = dev.cuda_device();
    ensure_flash_decode_loaded(&cuda_dev, dev.ordinal())?;

    let (batch, n_heads, seq_q, head_dim) = q.dims4()?;
    let (_, n_kv_heads, seq_kv, _) = k.dims4()?;

    if seq_q != 1 {
        return flash_decode_cpu(q, k, v, scale, softcap);
    }

    let q_f32 = q.to_dtype(DType::F32)?.contiguous()?;
    let k_f32 = k.to_dtype(DType::F32)?.contiguous()?;
    let v_f32 = v.to_dtype(DType::F32)?.contiguous()?;

    let q_squeezed = q_f32.squeeze(2)?;
    let q_ptr = get_cuda_ptr(&q_squeezed)?;
    let k_ptr = get_cuda_ptr(&k_f32)?;
    let v_ptr = get_cuda_ptr(&v_f32)?;

    let max_split_size = if head_dim > 128 { 256 } else { 512 };
    let min_splits = (seq_kv + max_split_size - 1) / max_split_size;
    let num_splits = if seq_kv <= 64 {
        min_splits.max(2)
    } else if seq_kv <= 256 {
        min_splits.max(4)
    } else if seq_kv <= 1024 {
        min_splits.max(8)
    } else if seq_kv <= 4096 {
        min_splits.max(16)
    } else {
        min_splits.max(32)
    };

    // Use pre-allocated buffers (or fall back to standard if splits exceed buffer)
    if num_splits > bufs.max_splits {
        return flash_decode_cuda(q, k, v, scale, softcap);
    }

    let out_ptr = get_cuda_ptr(&bufs.output)?;
    let partial_o_ptr = get_cuda_ptr(&bufs.partial_o)?;
    let partial_m_ptr = get_cuda_ptr(&bufs.partial_m)?;
    let partial_l_ptr = get_cuda_ptr(&bufs.partial_l)?;

    // Split kernel
    let split_func = match cuda_dev.get_func("flash_decoding", "flash_decode_split_kernel_f32") {
        Some(f) => f,
        None => return flash_decode_cpu(q, k, v, scale, softcap),
    };

    let split_size = (seq_kv + num_splits - 1) / num_splits;
    let block_size = 256u32;
    let shared_mem = ((head_dim + split_size) * std::mem::size_of::<f32>()) as u32;

    let split_cfg = LaunchConfig {
        grid_dim: (num_splits as u32, (batch * n_heads) as u32, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: shared_mem,
    };

    let split_params = (
        q_ptr,
        k_ptr,
        v_ptr,
        partial_o_ptr,
        partial_m_ptr,
        partial_l_ptr,
        batch as i32,
        n_heads as i32,
        n_kv_heads as i32,
        seq_kv as i32,
        head_dim as i32,
        num_splits as i32,
        scale,
        softcap,
    );

    unsafe { split_func.launch(split_cfg, split_params) }.w()?;

    // Reduce kernel
    let reduce_func = match cuda_dev.get_func("flash_decoding", "flash_decode_reduce_kernel_f32") {
        Some(f) => f,
        None => return flash_decode_cpu(q, k, v, scale, softcap),
    };

    let reduce_cfg = LaunchConfig {
        grid_dim: ((batch * n_heads) as u32, 1, 1),
        block_dim: (256u32.min(head_dim as u32), 1, 1),
        shared_mem_bytes: 0,
    };

    let reduce_params = (
        partial_o_ptr,
        partial_m_ptr,
        partial_l_ptr,
        out_ptr,
        batch as i32,
        n_heads as i32,
        head_dim as i32,
        num_splits as i32,
    );

    unsafe { reduce_func.launch(reduce_cfg, reduce_params) }.w()?;

    let output = bufs.output.unsqueeze(2)?;
    output.to_dtype(q.dtype())
}

#[cfg(not(feature = "cuda"))]
pub fn flash_decode_cuda_buffered(
    q: &Tensor,
    k: &Tensor,
    v: &Tensor,
    scale: f32,
    softcap: f32,
    _bufs: &FlashDecodeBuffers,
) -> Result<Tensor> {
    flash_decode_cpu(q, k, v, scale, softcap)
}

#[cfg(feature = "cuda")]
fn get_cuda_ptr(tensor: &Tensor) -> Result<u64> {
    let storage = tensor.storage_and_layout().0;
    match &*storage {
        candle_core::Storage::Cuda(s) => Ok(*s.as_cuda_slice::<f32>()?.device_ptr()),
        _ => Err(candle_core::Error::Msg("Expected CUDA tensor".to_string())),
    }
}

/// Flash-Decoding FP16 for decode phase (seq_q = 1)
///
/// Uses half precision for 2x memory bandwidth improvement.
///
/// # Arguments
/// * `q` - Query tensor [batch, n_heads, 1, head_dim] (will be converted to FP16)
/// * `k` - Key cache [batch, n_kv_heads, seq_kv, head_dim] (will be converted to FP16)
/// * `v` - Value cache [batch, n_kv_heads, seq_kv, head_dim] (will be converted to FP16)
/// * `scale` - Attention scale (1/sqrt(head_dim) or custom)
/// * `softcap` - Softcapping value (0 = disabled, used by Gemma-2)
#[cfg(feature = "cuda")]
pub fn flash_decode_cuda_fp16(
    q: &Tensor,
    k: &Tensor,
    v: &Tensor,
    scale: f32,
    softcap: f32,
) -> Result<Tensor> {
    let dev = match q.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => return flash_decode_cpu(q, k, v, scale, softcap),
    };

    let cuda_dev = dev.cuda_device();
    ensure_flash_decode_fp16_loaded(&cuda_dev, dev.ordinal())?;

    // Convert to FP16 and ensure contiguous
    let q_f16 = q.to_dtype(DType::F16)?.contiguous()?;
    let k_f16 = k.to_dtype(DType::F16)?.contiguous()?;
    let v_f16 = v.to_dtype(DType::F16)?.contiguous()?;

    let (batch, n_heads, _seq_q, head_dim) = q_f16.dims4()?;
    let (_, n_kv_heads, seq_kv, _) = k_f16.dims4()?;

    // Squeeze query: [batch, n_heads, 1, head_dim] -> [batch, n_heads, head_dim]
    let q_squeezed = q_f16.squeeze(2)?;

    // Get CUDA pointers for FP16 tensors
    let q_ptr = get_cuda_ptr_f16(&q_squeezed)?;
    let k_ptr = get_cuda_ptr_f16(&k_f16)?;
    let v_ptr = get_cuda_ptr_f16(&v_f16)?;

    // Output tensor (FP16)
    let output = Tensor::zeros(
        (batch, n_heads, head_dim),
        DType::F16,
        &Device::Cuda(dev.clone()),
    )?;
    let out_ptr = get_cuda_ptr_f16(&output)?;

    // For short sequences, use the single kernel (no split needed)
    let use_single_kernel = seq_kv <= 512;

    if use_single_kernel {
        // Use single kernel for short sequences
        let single_func =
            match cuda_dev.get_func("flash_decoding_fp16", "flash_decode_single_kernel_f16_v2") {
                Some(f) => f,
                None => {
                    tracing::warn!("Flash decode FP16 single kernel not found, using F32 fallback");
                    return flash_decode_cuda(q, k, v, scale, softcap);
                }
            };

        // Calculate block size to fit in 48KB shared memory
        // Shared memory: q_shared[head_dim] + partial_o[block_size * head_dim] + partial_m[block_size] + partial_l[block_size]
        // = head_dim * (1 + block_size) + 2 * block_size bytes (as floats)
        // With head_dim=64: 64 * (1 + block_size) + 2 * block_size = 64 + 66 * block_size
        // Max shared = 48KB = 12288 floats
        // 12288 = 64 + 66 * block_size -> block_size = (12288 - 64) / 66 = 185
        let block_size = 128u32; // Safe value for 48KB shared memory
        let shared_mem = (head_dim * (1 + block_size as usize) + 2 * block_size as usize)
            * std::mem::size_of::<f32>();
        let cfg = LaunchConfig {
            grid_dim: ((batch * n_heads) as u32, 1, 1),
            block_dim: (block_size, 1, 1),
            shared_mem_bytes: shared_mem as u32,
        };

        let params = (
            q_ptr,
            k_ptr,
            v_ptr,
            out_ptr,
            batch as i32,
            n_heads as i32,
            n_kv_heads as i32,
            seq_kv as i32,
            head_dim as i32,
            scale,
            softcap,
        );

        unsafe { single_func.launch(cfg, params) }.w()?;
    } else {
        // Use split-reduce for longer sequences
        let num_splits = ((seq_kv + 255) / 256).min(32);
        let block_size = 256u32;

        // Allocate partial results (FP32 for precision)
        let partial_o = Tensor::zeros(
            (batch, n_heads, num_splits, head_dim),
            DType::F32,
            &Device::Cuda(dev.clone()),
        )?;
        let partial_m = Tensor::zeros(
            (batch, n_heads, num_splits),
            DType::F32,
            &Device::Cuda(dev.clone()),
        )?;
        let partial_l = Tensor::zeros(
            (batch, n_heads, num_splits),
            DType::F32,
            &Device::Cuda(dev.clone()),
        )?;

        let partial_o_ptr = get_cuda_ptr(&partial_o)?;
        let partial_m_ptr = get_cuda_ptr(&partial_m)?;
        let partial_l_ptr = get_cuda_ptr(&partial_l)?;

        // Split kernel
        let split_func =
            match cuda_dev.get_func("flash_decoding_fp16", "flash_decode_split_kernel_f16") {
                Some(f) => f,
                None => {
                    tracing::warn!("Flash decode FP16 split kernel not found, using F32 fallback");
                    return flash_decode_cuda(q, k, v, scale, softcap);
                }
            };

        let split_cfg = LaunchConfig {
            grid_dim: (num_splits as u32, (batch * n_heads) as u32, 1),
            block_dim: (block_size, 1, 1),
            shared_mem_bytes: 0,
        };

        let split_params = (
            q_ptr,
            k_ptr,
            v_ptr,
            partial_o_ptr,
            partial_m_ptr,
            partial_l_ptr,
            batch as i32,
            n_heads as i32,
            n_kv_heads as i32,
            seq_kv as i32,
            head_dim as i32,
            num_splits as i32,
            scale,
            softcap,
        );

        unsafe { split_func.launch(split_cfg, split_params) }.w()?;

        // Reduce kernel
        let reduce_func =
            match cuda_dev.get_func("flash_decoding_fp16", "flash_decode_reduce_kernel_f16") {
                Some(f) => f,
                None => {
                    tracing::warn!("Flash decode FP16 reduce kernel not found, using F32 fallback");
                    return flash_decode_cuda(q, k, v, scale, softcap);
                }
            };

        let reduce_cfg = LaunchConfig {
            grid_dim: ((batch * n_heads) as u32, 1, 1),
            block_dim: (256u32.min(head_dim as u32), 1, 1),
            shared_mem_bytes: 0,
        };

        let reduce_params = (
            partial_o_ptr,
            partial_m_ptr,
            partial_l_ptr,
            out_ptr,
            batch as i32,
            n_heads as i32,
            head_dim as i32,
            num_splits as i32,
        );

        unsafe { reduce_func.launch(reduce_cfg, reduce_params) }.w()?;
    }

    // Reshape output: [batch, n_heads, head_dim] -> [batch, n_heads, 1, head_dim]
    let output = output.unsqueeze(2)?;
    output.to_dtype(q.dtype())
}

#[cfg(feature = "cuda")]
fn get_cuda_ptr_f16(tensor: &Tensor) -> Result<u64> {
    let storage = tensor.storage_and_layout().0;
    match &*storage {
        candle_core::Storage::Cuda(s) => Ok(*s.as_cuda_slice::<half::f16>()?.device_ptr()),
        _ => Err(candle_core::Error::Msg(
            "Expected CUDA FP16 tensor".to_string(),
        )),
    }
}

#[cfg(not(feature = "cuda"))]
pub fn flash_decode_cuda_fp16(
    q: &Tensor,
    k: &Tensor,
    v: &Tensor,
    scale: f32,
    softcap: f32,
) -> Result<Tensor> {
    flash_decode_cpu(q, k, v, scale, softcap)
}

#[cfg(not(feature = "cuda"))]
pub fn flash_decode_cuda(
    q: &Tensor,
    k: &Tensor,
    v: &Tensor,
    scale: f32,
    softcap: f32,
) -> Result<Tensor> {
    flash_decode_cpu(q, k, v, scale, softcap)
}

/// CPU fallback for flash decoding (with GQA support)
fn flash_decode_cpu(
    q: &Tensor,
    k: &Tensor,
    v: &Tensor,
    scale: f32,
    softcap: f32,
) -> Result<Tensor> {
    use candle_core::D;

    // Handle GQA: expand K/V heads to match Q heads if needed
    let (_, n_q_heads, _, _) = q.dims4()?;
    let (b_sz, n_kv_heads, seq_kv, head_dim) = k.dims4()?;
    let n_rep = n_q_heads / n_kv_heads;

    let (k, v) = if n_rep > 1 {
        // GQA: expand K/V from [b, kv_heads, seq, dim] to [b, q_heads, seq, dim]
        let k_exp = k.unsqueeze(2)?.repeat(&[1, 1, n_rep, 1, 1])?.reshape((
            b_sz,
            n_kv_heads * n_rep,
            seq_kv,
            head_dim,
        ))?;
        let v_exp = v.unsqueeze(2)?.repeat(&[1, 1, n_rep, 1, 1])?.reshape((
            b_sz,
            n_kv_heads * n_rep,
            seq_kv,
            head_dim,
        ))?;
        (k_exp, v_exp)
    } else {
        (k.clone(), v.clone())
    };

    // Standard attention: softmax(Q @ K^T / scale) @ V
    let attn_weights = q.matmul(&k.transpose(D::Minus2, D::Minus1)?)?;
    let attn_weights = (attn_weights * scale as f64)?;

    // Softcapping (Gemma-2)
    let attn_weights = if softcap > 0.0 {
        ((attn_weights / softcap as f64)?.tanh()? * softcap as f64)?
    } else {
        attn_weights
    };

    // Softmax (use our fused_ops which handles CUDA context resets)
    let attn_weights = crate::kernels::fused_ops::softmax_cuda(&attn_weights)?;

    // Output
    attn_weights.matmul(&v)
}
