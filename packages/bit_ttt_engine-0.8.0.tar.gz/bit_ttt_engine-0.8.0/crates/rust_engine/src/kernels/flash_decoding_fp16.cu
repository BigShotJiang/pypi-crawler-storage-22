/**
 * Flash-Decoding FP16 CUDA Kernels
 * 
 * Optimized with:
 * - Half precision (FP16) for 2x memory bandwidth
 * - Vectorized memory access (half2)
 * - Better thread utilization
 * - Warp-level primitives
 */

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <float.h>

#define WARP_SIZE 32
#define BLOCK_SIZE 256

// Helper: half to float
__device__ __forceinline__ float h2f(half h) {
    return __half2float(h);
}

// Helper: float to half
__device__ __forceinline__ half f2h(float f) {
    return __float2half(f);
}

// ============================================================================
// Flash-Decoding FP16 Split Kernel
// ============================================================================

extern "C" __global__ void flash_decode_split_kernel_f16(
    const half* __restrict__ Q,
    const half* __restrict__ K,
    const half* __restrict__ V,
    float* __restrict__ partial_O,  // Keep partial results in FP32 for precision
    float* __restrict__ partial_m,
    float* __restrict__ partial_l,
    int batch,
    int n_heads,
    int n_kv_heads,
    int seq_kv,
    int head_dim,
    int num_splits,
    float scale,
    float softcap
) {
    const int split_idx = blockIdx.x;
    const int batch_head_idx = blockIdx.y;
    const int batch_idx = batch_head_idx / n_heads;
    const int head_idx = batch_head_idx % n_heads;
    
    if (batch_idx >= batch || split_idx >= num_splits) return;
    
    const int kv_head_idx = head_idx * n_kv_heads / n_heads;
    
    const int split_size = (seq_kv + num_splits - 1) / num_splits;
    const int kv_start = split_idx * split_size;
    const int kv_end = min(kv_start + split_size, seq_kv);
    
    if (kv_start >= seq_kv) {
        const int out_idx = (batch_idx * n_heads + head_idx) * num_splits + split_idx;
        partial_m[out_idx] = -FLT_MAX;
        partial_l[out_idx] = 0.0f;
        for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
            partial_O[(out_idx * head_dim) + d] = 0.0f;
        }
        return;
    }
    
    extern __shared__ float shared[];
    float* q_shared = shared;
    float* scores = shared + head_dim;
    
    // Load query (FP16 -> FP32)
    const int q_base = (batch_idx * n_heads + head_idx) * head_dim;
    for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
        q_shared[d] = h2f(Q[q_base + d]);
    }
    __syncthreads();
    
    // Compute Q @ K^T with FP16 K
    const int kv_base = (batch_idx * n_kv_heads + kv_head_idx) * seq_kv * head_dim;
    float local_max = -FLT_MAX;
    
    for (int kv_idx = kv_start + threadIdx.x; kv_idx < kv_end; kv_idx += blockDim.x) {
        float score = 0.0f;
        const int k_offset = kv_base + kv_idx * head_dim;
        
        // Vectorized dot product using half2
        for (int d = 0; d < head_dim; d += 2) {
            half2 k_vec = *reinterpret_cast<const half2*>(&K[k_offset + d]);
            score += q_shared[d] * h2f(k_vec.x);
            if (d + 1 < head_dim) {
                score += q_shared[d + 1] * h2f(k_vec.y);
            }
        }
        
        score *= scale;
        
        if (softcap > 0.0f) {
            score = tanhf(score / softcap) * softcap;
        }
        
        scores[kv_idx - kv_start] = score;
        local_max = fmaxf(local_max, score);
    }
    __syncthreads();
    
    // Warp reduction for max
    for (int offset = WARP_SIZE / 2; offset > 0; offset >>= 1) {
        local_max = fmaxf(local_max, __shfl_down_sync(0xffffffff, local_max, offset));
    }
    
    __shared__ float warp_max[32];
    const int warp_id = threadIdx.x / WARP_SIZE;
    const int lane_id = threadIdx.x % WARP_SIZE;
    
    if (lane_id == 0) {
        warp_max[warp_id] = local_max;
    }
    __syncthreads();
    
    if (threadIdx.x == 0) {
        float block_max = warp_max[0];
        for (int i = 1; i < (blockDim.x + WARP_SIZE - 1) / WARP_SIZE; i++) {
            block_max = fmaxf(block_max, warp_max[i]);
        }
        warp_max[0] = block_max;
    }
    __syncthreads();
    
    float m = warp_max[0];
    
    // Compute exp(score - max) and sum
    float local_sum = 0.0f;
    const int local_len = kv_end - kv_start;
    
    for (int i = threadIdx.x; i < local_len; i += blockDim.x) {
        float exp_score = expf(scores[i] - m);
        scores[i] = exp_score;
        local_sum += exp_score;
    }
    __syncthreads();
    
    // Warp reduction for sum
    for (int offset = WARP_SIZE / 2; offset > 0; offset >>= 1) {
        local_sum += __shfl_down_sync(0xffffffff, local_sum, offset);
    }
    
    __shared__ float warp_sum[32];
    if (lane_id == 0) {
        warp_sum[warp_id] = local_sum;
    }
    __syncthreads();
    
    if (threadIdx.x == 0) {
        float block_sum = warp_sum[0];
        for (int i = 1; i < (blockDim.x + WARP_SIZE - 1) / WARP_SIZE; i++) {
            block_sum += warp_sum[i];
        }
        warp_sum[0] = block_sum;
    }
    __syncthreads();
    
    float l = warp_sum[0];
    
    // Compute output with FP16 V
    const int out_base = ((batch_idx * n_heads + head_idx) * num_splits + split_idx) * head_dim;
    
    for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
        float acc = 0.0f;
        for (int i = 0; i < local_len; i++) {
            const int v_offset = kv_base + (kv_start + i) * head_dim + d;
            acc += scores[i] * h2f(V[v_offset]);
        }
        partial_O[out_base + d] = acc;
    }
    
    if (threadIdx.x == 0) {
        const int ml_idx = (batch_idx * n_heads + head_idx) * num_splits + split_idx;
        partial_m[ml_idx] = m;
        partial_l[ml_idx] = l;
    }
}

// ============================================================================
// Flash-Decoding FP16 Optimized Single Kernel
// ============================================================================

/**
 * Optimized single-kernel flash decoding with proper parallelization.
 * Uses online softmax with correct warp-level reduction.
 */
extern "C" __global__ void flash_decode_single_kernel_f16_v2(
    const half* __restrict__ Q,
    const half* __restrict__ K,
    const half* __restrict__ V,
    half* __restrict__ O,
    int batch,
    int n_heads,
    int n_kv_heads,
    int seq_kv,
    int head_dim,
    float scale,
    float softcap
) {
    const int batch_head_idx = blockIdx.x;
    const int batch_idx = batch_head_idx / n_heads;
    const int head_idx = batch_head_idx % n_heads;
    
    if (batch_idx >= batch) return;
    
    const int kv_head_idx = head_idx * n_kv_heads / n_heads;
    
    // Shared memory for Q and intermediate results
    extern __shared__ float shared[];
    float* q_shared = shared;                    // [head_dim]
    float* partial_o = shared + head_dim;        // [blockDim.x * head_dim]
    float* partial_m = partial_o + blockDim.x * head_dim;  // [blockDim.x]
    float* partial_l = partial_m + blockDim.x;   // [blockDim.x]
    
    // Load query
    const int q_base = (batch_idx * n_heads + head_idx) * head_dim;
    for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
        q_shared[d] = h2f(Q[q_base + d]);
    }
    __syncthreads();
    
    const int kv_base = (batch_idx * n_kv_heads + kv_head_idx) * seq_kv * head_dim;
    
    // Each thread computes online softmax for its KV positions
    float m_local = -FLT_MAX;
    float l_local = 0.0f;
    float* o_local = &partial_o[threadIdx.x * head_dim];
    
    for (int d = 0; d < head_dim; d++) {
        o_local[d] = 0.0f;
    }
    
    // Process KV positions
    for (int kv_idx = threadIdx.x; kv_idx < seq_kv; kv_idx += blockDim.x) {
        float score = 0.0f;
        const int k_offset = kv_base + kv_idx * head_dim;
        
        // Dot product Q @ K
        for (int d = 0; d < head_dim; d++) {
            score += q_shared[d] * h2f(K[k_offset + d]);
        }
        score *= scale;
        
        if (softcap > 0.0f) {
            score = tanhf(score / softcap) * softcap;
        }
        
        // Online softmax update
        float m_new = fmaxf(m_local, score);
        float exp_diff = expf(m_local - m_new);
        float exp_score = expf(score - m_new);
        
        const int v_offset = kv_base + kv_idx * head_dim;
        for (int d = 0; d < head_dim; d++) {
            o_local[d] = exp_diff * o_local[d] + exp_score * h2f(V[v_offset + d]);
        }
        
        l_local = exp_diff * l_local + exp_score;
        m_local = m_new;
    }
    
    // Store local results
    partial_m[threadIdx.x] = m_local;
    partial_l[threadIdx.x] = l_local;
    __syncthreads();
    
    // Reduction across threads (tree reduction)
    // Only first warp does the final reduction
    if (threadIdx.x < WARP_SIZE) {
        // Initialize with thread's own values
        float m_acc = partial_m[threadIdx.x];
        float l_acc = partial_l[threadIdx.x];
        float o_acc[128];
        for (int d = 0; d < head_dim; d++) {
            o_acc[d] = partial_o[threadIdx.x * head_dim + d];
        }
        
        // Reduce across first warp's worth of threads
        for (int i = threadIdx.x + WARP_SIZE; i < blockDim.x; i += WARP_SIZE) {
            float m_i = partial_m[i];
            float l_i = partial_l[i];
            
            float m_new = fmaxf(m_acc, m_i);
            float exp_acc = expf(m_acc - m_new);
            float exp_i = expf(m_i - m_new);
            
            for (int d = 0; d < head_dim; d++) {
                o_acc[d] = exp_acc * o_acc[d] + exp_i * partial_o[i * head_dim + d];
            }
            
            l_acc = exp_acc * l_acc + exp_i * l_i;
            m_acc = m_new;
        }
        
        // Warp reduction
        for (int offset = WARP_SIZE / 2; offset > 0; offset >>= 1) {
            float m_other = __shfl_down_sync(0xffffffff, m_acc, offset);
            float l_other = __shfl_down_sync(0xffffffff, l_acc, offset);
            
            float m_new = fmaxf(m_acc, m_other);
            float exp_acc = expf(m_acc - m_new);
            float exp_other = expf(m_other - m_new);
            
            for (int d = 0; d < head_dim; d++) {
                float o_other = __shfl_down_sync(0xffffffff, o_acc[d], offset);
                o_acc[d] = exp_acc * o_acc[d] + exp_other * o_other;
            }
            
            l_acc = exp_acc * l_acc + exp_other * l_other;
            m_acc = m_new;
        }
        
        // Thread 0 writes final output
        if (threadIdx.x == 0) {
            const int out_base = (batch_idx * n_heads + head_idx) * head_dim;
            for (int d = 0; d < head_dim; d++) {
                O[out_base + d] = f2h(o_acc[d] / l_acc);
            }
        }
    }
}

// ============================================================================
// Reduce Kernel (FP16 compatible)
// ============================================================================

extern "C" __global__ void flash_decode_reduce_kernel_f16(
    const float* __restrict__ partial_O,
    const float* __restrict__ partial_m,
    const float* __restrict__ partial_l,
    half* __restrict__ O,
    int batch,
    int n_heads,
    int head_dim,
    int num_splits
) {
    const int batch_head_idx = blockIdx.x;
    const int batch_idx = batch_head_idx / n_heads;
    const int head_idx = batch_head_idx % n_heads;
    
    if (batch_idx >= batch) return;
    
    const int ml_base = (batch_idx * n_heads + head_idx) * num_splits;
    
    float m_global = -FLT_MAX;
    for (int s = 0; s < num_splits; s++) {
        m_global = fmaxf(m_global, partial_m[ml_base + s]);
    }
    
    float l_global = 0.0f;
    for (int s = 0; s < num_splits; s++) {
        float m_i = partial_m[ml_base + s];
        float l_i = partial_l[ml_base + s];
        l_global += expf(m_i - m_global) * l_i;
    }
    
    const int out_base = (batch_idx * n_heads + head_idx) * head_dim;
    const int partial_base = (batch_idx * n_heads + head_idx) * num_splits * head_dim;
    
    for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
        float acc = 0.0f;
        for (int s = 0; s < num_splits; s++) {
            float m_i = partial_m[ml_base + s];
            float o_i = partial_O[partial_base + s * head_dim + d];
            acc += expf(m_i - m_global) * o_i;
        }
        O[out_base + d] = f2h(acc / l_global);
    }
}
