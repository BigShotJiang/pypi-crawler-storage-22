/**
 * Fused CUDA Kernels for LLM Inference
 * 
 * Contains optimized implementations of:
 * - RMSNorm
 * - Softmax
 * - RoPE (Rotary Position Embedding)
 */

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdint.h>
#include <float.h>

// Warp size
#define WARP_SIZE 32

// Block sizes
#define RMS_BLOCK_SIZE 256
#define SOFTMAX_BLOCK_SIZE 256
#define ROPE_BLOCK_SIZE 256

// ============================================================================
// RMSNorm Kernel
// ============================================================================

/**
 * RMSNorm: y = x * weight / sqrt(mean(x^2) + eps)
 * 
 * @param x       Input tensor [batch, seq_len, hidden_dim]
 * @param weight  Weight tensor [hidden_dim]
 * @param y       Output tensor [batch, seq_len, hidden_dim]
 * @param hidden_dim Hidden dimension
 * @param eps     Epsilon for numerical stability
 * @param n_elements Total number of rows (batch * seq_len)
 */
extern "C" __global__ void rms_norm_kernel_f32(
    const float* __restrict__ x,
    const float* __restrict__ weight,
    float* __restrict__ y,
    int hidden_dim,
    float eps,
    int n_elements
) {
    int row = blockIdx.x;
    if (row >= n_elements) return;
    
    const float* x_row = x + row * hidden_dim;
    float* y_row = y + row * hidden_dim;
    
    // Compute sum of squares using parallel reduction
    __shared__ float shared_sum[RMS_BLOCK_SIZE];
    
    float thread_sum = 0.0f;
    for (int i = threadIdx.x; i < hidden_dim; i += blockDim.x) {
        float val = x_row[i];
        thread_sum += val * val;
    }
    
    shared_sum[threadIdx.x] = thread_sum;
    __syncthreads();
    
    // Reduce within block
    for (int stride = blockDim.x / 2; stride > 0; stride >>= 1) {
        if (threadIdx.x < stride) {
            shared_sum[threadIdx.x] += shared_sum[threadIdx.x + stride];
        }
        __syncthreads();
    }
    
    // Compute RMS
    float rms = rsqrtf(shared_sum[0] / (float)hidden_dim + eps);
    
    // Apply normalization
    for (int i = threadIdx.x; i < hidden_dim; i += blockDim.x) {
        y_row[i] = x_row[i] * rms * weight[i];
    }
}

// ============================================================================
// Softmax Kernel
// ============================================================================

/**
 * Softmax on last dimension: y = exp(x - max(x)) / sum(exp(x - max(x)))
 * 
 * @param x       Input tensor [batch, seq_len, vocab_size] or [batch, heads, seq, seq]
 * @param y       Output tensor (same shape)
 * @param last_dim Size of last dimension
 * @param n_rows  Number of rows (product of all dims except last)
 */
extern "C" __global__ void softmax_kernel_f32(
    const float* __restrict__ x,
    float* __restrict__ y,
    int last_dim,
    int n_rows
) {
    int row = blockIdx.x;
    if (row >= n_rows) return;
    
    const float* x_row = x + row * last_dim;
    float* y_row = y + row * last_dim;
    
    __shared__ float shared_max[SOFTMAX_BLOCK_SIZE];
    __shared__ float shared_sum[SOFTMAX_BLOCK_SIZE];
    
    // Find max
    float thread_max = -FLT_MAX;
    for (int i = threadIdx.x; i < last_dim; i += blockDim.x) {
        thread_max = fmaxf(thread_max, x_row[i]);
    }
    shared_max[threadIdx.x] = thread_max;
    __syncthreads();
    
    // Reduce max
    for (int stride = blockDim.x / 2; stride > 0; stride >>= 1) {
        if (threadIdx.x < stride) {
            shared_max[threadIdx.x] = fmaxf(shared_max[threadIdx.x], shared_max[threadIdx.x + stride]);
        }
        __syncthreads();
    }
    float max_val = shared_max[0];
    
    // Compute exp and sum
    float thread_sum = 0.0f;
    for (int i = threadIdx.x; i < last_dim; i += blockDim.x) {
        float exp_val = expf(x_row[i] - max_val);
        y_row[i] = exp_val;  // Store intermediate
        thread_sum += exp_val;
    }
    shared_sum[threadIdx.x] = thread_sum;
    __syncthreads();
    
    // Reduce sum
    for (int stride = blockDim.x / 2; stride > 0; stride >>= 1) {
        if (threadIdx.x < stride) {
            shared_sum[threadIdx.x] += shared_sum[threadIdx.x + stride];
        }
        __syncthreads();
    }
    float sum_val = shared_sum[0];
    
    // Normalize
    float inv_sum = 1.0f / sum_val;
    for (int i = threadIdx.x; i < last_dim; i += blockDim.x) {
        y_row[i] *= inv_sum;
    }
}

// ============================================================================
// RoPE Kernel
// ============================================================================

/**
 * Apply Rotary Position Embedding in-place
 * 
 * Interleaved style (matching GGUF/llama.cpp convention):
 * For each pair (d[2i], d[2i+1]):
 *   y[2i]   = x[2i]   * cos[i] - x[2i+1] * sin[i]
 *   y[2i+1] = x[2i]   * sin[i] + x[2i+1] * cos[i]
 * 
 * @param q       Query tensor [batch, heads, seq_len, head_dim]
 * @param k       Key tensor [batch, heads, seq_len, head_dim]
 * @param cos     Cosine cache [max_seq, half_dim]
 * @param sin     Sine cache [max_seq, half_dim]
 * @param batch   Batch size
 * @param n_q_heads Number of Q heads
 * @param n_kv_heads Number of KV heads (may be < n_q_heads for GQA)
 * @param seq_len Sequence length
 * @param head_dim Head dimension (must be even)
 * @param start_pos Starting position for cache lookup
 */
extern "C" __global__ void rope_kernel_f32(
    float* __restrict__ q,
    float* __restrict__ k,
    const float* __restrict__ cos,
    const float* __restrict__ sin,
    int batch,
    int n_q_heads,
    int n_kv_heads,
    int seq_len,
    int head_dim,
    int start_pos
) {
    // Each thread handles one pair of interleaved dimensions
    int half_dim = head_dim / 2;
    int total_q = batch * n_q_heads * seq_len * half_dim;
    
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= total_q) return;
    
    // Decode: which pair (h_idx), which position (s), which head, which batch
    int h_idx = idx % half_dim;
    int remaining = idx / half_dim;
    int s = remaining % seq_len;
    remaining /= seq_len;
    int head = remaining % n_q_heads;
    int b = remaining / n_q_heads;
    
    // cos/sin table: [max_seq, half_dim]
    int pos = start_pos + s;
    float cos_val = cos[pos * half_dim + h_idx];
    float sin_val = sin[pos * half_dim + h_idx];
    
    // Interleaved: pair is (d[2*h_idx], d[2*h_idx+1])
    int pair_offset = 2 * h_idx;
    
    // Apply RoPE to Q
    {
        int q_offset = ((b * n_q_heads + head) * seq_len + s) * head_dim + pair_offset;
        float x0 = q[q_offset];
        float x1 = q[q_offset + 1];
        q[q_offset]     = x0 * cos_val - x1 * sin_val;
        q[q_offset + 1] = x0 * sin_val + x1 * cos_val;
    }
    
    // Apply RoPE to K (only for heads < n_kv_heads)
    if (head < n_kv_heads) {
        int k_offset = ((b * n_kv_heads + head) * seq_len + s) * head_dim + pair_offset;
        float x0 = k[k_offset];
        float x1 = k[k_offset + 1];
        k[k_offset]     = x0 * cos_val - x1 * sin_val;
        k[k_offset + 1] = x0 * sin_val + x1 * cos_val;
    }
}

// ============================================================================
// SiLU (Swish) Kernel
// ============================================================================

/**
 * SiLU activation: y = x * sigmoid(x)
 */
extern "C" __global__ void silu_kernel_f32(
    const float* __restrict__ x,
    float* __restrict__ y,
    int n_elements
) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= n_elements) return;
    
    float val = x[idx];
    y[idx] = val / (1.0f + expf(-val));
}

// ============================================================================
// Fused Gate-Up with SiLU
// ============================================================================

/**
 * Fused: y = silu(gate) * up
 * 
 * @param gate   Gate projection output [batch, hidden]
 * @param up     Up projection output [batch, hidden]  
 * @param y      Output [batch, hidden]
 * @param n_elements Total elements
 */
extern "C" __global__ void fused_silu_mul_kernel_f32(
    const float* __restrict__ gate,
    const float* __restrict__ up,
    float* __restrict__ y,
    int n_elements
) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= n_elements) return;
    
    float g = gate[idx];
    float silu_g = g / (1.0f + expf(-g));
    y[idx] = silu_g * up[idx];
}

// ============================================================================
// GELU Kernel
// ============================================================================

// GELU constant: sqrt(2/π) ≈ 0.7978845608
#define GELU_COEF_A 0.7978845608f
#define GELU_COEF_B 0.044715f

/**
 * GELU activation: y = 0.5 * x * (1 + tanh(sqrt(2/π) * (x + 0.044715 * x³)))
 */
extern "C" __global__ void gelu_kernel_f32(
    const float* __restrict__ x,
    float* __restrict__ y,
    int n_elements
) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= n_elements) return;
    
    float val = x[idx];
    float x3 = val * val * val;
    float inner = GELU_COEF_A * (val + GELU_COEF_B * x3);
    y[idx] = 0.5f * val * (1.0f + tanhf(inner));
}

// ============================================================================
// Fused Gate-Up with GELU
// ============================================================================

/**
 * Fused: y = gelu(gate) * up
 * 
 * @param gate   Gate projection output [batch, hidden]
 * @param up     Up projection output [batch, hidden]  
 * @param y      Output [batch, hidden]
 * @param n_elements Total elements
 */
extern "C" __global__ void fused_gelu_mul_kernel_f32(
    const float* __restrict__ gate,
    const float* __restrict__ up,
    float* __restrict__ y,
    int n_elements
) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= n_elements) return;
    
    float g = gate[idx];
    float g3 = g * g * g;
    float inner = GELU_COEF_A * (g + GELU_COEF_B * g3);
    float gelu_g = 0.5f * g * (1.0f + tanhf(inner));
    y[idx] = gelu_g * up[idx];
}

// ============================================================================
// Fused Residual Add + RMSNorm Kernel
// ============================================================================

/**
 * Fused residual add + RMSNorm in a single kernel launch.
 * Saves 1 kernel launch per layer (2→1 for add+norm).
 * 
 * sum_out[i] = residual[i] + x[i]
 * norm_out[i] = rms_norm(sum_out, weight)
 * 
 * Both outputs are written - sum_out is needed as the next residual.
 * Uses shared memory to avoid reading sum_out back from global memory.
 *
 * @param residual   Input residual [rows, hidden_dim]
 * @param x          Input to add [rows, hidden_dim]
 * @param weight     RMSNorm weight [hidden_dim]
 * @param sum_out    Output: residual + x [rows, hidden_dim]
 * @param norm_out   Output: rms_norm(sum_out) [rows, hidden_dim]
 * @param hidden_dim Hidden dimension
 * @param eps        RMSNorm epsilon
 * @param n_rows     Number of rows
 */
extern "C" __global__ void fused_residual_add_rms_norm_f32(
    const float* __restrict__ residual,
    const float* __restrict__ x,
    const float* __restrict__ weight,
    float* __restrict__ sum_out,
    float* __restrict__ norm_out,
    int hidden_dim,
    float eps,
    int n_rows
) {
    int row = blockIdx.x;
    if (row >= n_rows) return;

    const float* res_row = residual + row * hidden_dim;
    const float* x_row = x + row * hidden_dim;
    float* sum_row = sum_out + row * hidden_dim;
    float* norm_row = norm_out + row * hidden_dim;

    // Pass 1: Compute residual + x, write to sum_out, accumulate sum of squares
    __shared__ float shared_ss[RMS_BLOCK_SIZE];
    
    float thread_ss = 0.0f;
    for (int i = threadIdx.x; i < hidden_dim; i += blockDim.x) {
        float val = res_row[i] + x_row[i];
        sum_row[i] = val;
        thread_ss += val * val;
    }
    
    shared_ss[threadIdx.x] = thread_ss;
    __syncthreads();
    
    // Reduce sum of squares
    for (int stride = blockDim.x / 2; stride > 0; stride >>= 1) {
        if (threadIdx.x < stride) {
            shared_ss[threadIdx.x] += shared_ss[threadIdx.x + stride];
        }
        __syncthreads();
    }
    
    float rms = rsqrtf(shared_ss[0] / (float)hidden_dim + eps);
    
    // Pass 2: Read back from sum_out and normalize
    for (int i = threadIdx.x; i < hidden_dim; i += blockDim.x) {
        norm_row[i] = sum_row[i] * rms * weight[i];
    }
}

// ============================================================================
// Softcapping Kernel (Gemma-2)
// ============================================================================

/**
 * Softcapping: y = tanh(x / cap) * cap
 * Used in Gemma-2 for attention and final logits
 * 
 * @param x          Input tensor
 * @param y          Output tensor
 * @param cap        Softcapping value (e.g., 50.0 for attn, 30.0 for final)
 * @param n_elements Total elements
 */
extern "C" __global__ void softcap_kernel_f32(
    const float* __restrict__ x,
    float* __restrict__ y,
    float cap,
    int n_elements
) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= n_elements) return;
    
    float val = x[idx];
    y[idx] = tanhf(val / cap) * cap;
}
