//! Fused CUDA Kernels for LLM Inference
//!
//! Provides optimized CUDA implementations for:
//! - RMSNorm
//! - Softmax
//! - RoPE (Rotary Position Embedding)
//! - SiLU activation
//! - Fused SiLU * multiply

#[cfg(feature = "cuda")]
use candle_core::cuda_backend::cudarc::driver::{DevicePtr, LaunchAsync, LaunchConfig};
#[cfg(feature = "cuda")]
use candle_core::cuda_backend::WrapErr;
#[cfg(feature = "cuda")]
use candle_core::Device;
use candle_core::{DType, Result, Tensor};
#[cfg(feature = "cuda")]
use std::sync::OnceLock;

#[cfg(feature = "cuda")]
const FUSED_OPS_PTX: &str = include_str!(concat!(env!("OUT_DIR"), "/fused_ops.ptx"));

#[cfg(feature = "cuda")]
static FUSED_OPS_LOADED: OnceLock<std::sync::Mutex<std::collections::HashSet<usize>>> =
    OnceLock::new();

#[cfg(feature = "cuda")]
fn ensure_fused_ops_loaded(
    cuda_dev: &std::sync::Arc<candle_core::cuda_backend::cudarc::driver::CudaDevice>,
    device_id: usize,
) -> Result<()> {
    // Always check if kernel exists (CudaDevice instance may have changed)
    // If kernel exists, we're good. If not, reload.
    if cuda_dev
        .get_func("fused_ops", "rms_norm_kernel_f32")
        .is_none()
    {
        load_fused_ops_ptx(cuda_dev, device_id)?;
        tracing::debug!(
            "Loaded fused_ops PTX for device {} (new instance)",
            device_id
        );
    }
    Ok(())
}

/// Force reload kernels (call when CUDA context may have been reset)
#[cfg(feature = "cuda")]
fn force_reload_fused_ops(
    cuda_dev: &std::sync::Arc<candle_core::cuda_backend::cudarc::driver::CudaDevice>,
    device_id: usize,
) -> Result<()> {
    let loaded =
        FUSED_OPS_LOADED.get_or_init(|| std::sync::Mutex::new(std::collections::HashSet::new()));
    let mut guard = loaded.lock().unwrap();

    // Clear loaded state and reload
    guard.remove(&device_id);
    load_fused_ops_ptx(cuda_dev, device_id)?;
    guard.insert(device_id);
    tracing::info!("Force reloaded fused_ops PTX for device {}", device_id);

    Ok(())
}

/// Get kernel function with auto-reload on CUDA context reset
#[cfg(feature = "cuda")]
fn get_fused_ops_func(
    cuda_dev: &std::sync::Arc<candle_core::cuda_backend::cudarc::driver::CudaDevice>,
    device_id: usize,
    func_name: &str,
) -> Result<candle_core::cuda_backend::cudarc::driver::CudaFunction> {
    match cuda_dev.get_func("fused_ops", func_name) {
        Some(f) => Ok(f),
        None => {
            // Kernel not found - likely CUDA context was reset. Force reload.
            force_reload_fused_ops(cuda_dev, device_id)?;
            cuda_dev.get_func("fused_ops", func_name).ok_or_else(|| {
                candle_core::Error::Msg(format!("Failed to get {} after reload", func_name))
            })
        }
    }
}

#[cfg(feature = "cuda")]
fn load_fused_ops_ptx(
    cuda_dev: &std::sync::Arc<candle_core::cuda_backend::cudarc::driver::CudaDevice>,
    device_id: usize,
) -> Result<()> {
    cuda_dev
        .load_ptx(
            FUSED_OPS_PTX.into(),
            "fused_ops",
            &[
                "rms_norm_kernel_f32",
                "softmax_kernel_f32",
                "rope_kernel_f32",
                "silu_kernel_f32",
                "fused_silu_mul_kernel_f32",
                "gelu_kernel_f32",
                "fused_gelu_mul_kernel_f32",
                "softcap_kernel_f32",
                "fused_residual_add_rms_norm_f32",
            ],
        )
        .w()?;
    tracing::info!("Loaded fused_ops PTX for device {}", device_id);
    Ok(())
}

/// RMSNorm using CUDA kernel
///
/// y = x * weight / sqrt(mean(x^2) + eps)
#[cfg(feature = "cuda")]
pub fn rms_norm_cuda(x: &Tensor, weight: &Tensor, eps: f64) -> Result<Tensor> {
    let dev = match x.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => return rms_norm_cpu(x, weight, eps),
    };

    let cuda_dev = dev.cuda_device();
    ensure_fused_ops_loaded(&cuda_dev, dev.ordinal())?;

    let dims = x.dims();
    let hidden_dim = dims[dims.len() - 1];
    let n_elements: usize = dims[..dims.len() - 1].iter().product();

    let x_f32 = x.to_dtype(DType::F32)?.contiguous()?;
    let weight_f32 = weight.to_dtype(DType::F32)?.contiguous()?;

    let x_ptr = {
        let storage = x_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("X must be CUDA tensor".to_string())),
        }
    };

    let weight_ptr = {
        let storage = weight_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Weight must be CUDA tensor".to_string(),
                ))
            }
        }
    };

    let output = Tensor::zeros(x.dims(), DType::F32, &Device::Cuda(dev.clone()))?;
    let out_ptr = {
        let storage = output.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Output allocation failed".to_string(),
                ))
            }
        }
    };

    // Get function with auto-reload on CUDA context reset
    let func = get_fused_ops_func(&cuda_dev, dev.ordinal(), "rms_norm_kernel_f32")?;

    let block_size = 256u32;
    let cfg = LaunchConfig {
        grid_dim: (n_elements as u32, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: 0,
    };

    let params = (
        x_ptr,
        weight_ptr,
        out_ptr,
        hidden_dim as i32,
        eps as f32,
        n_elements as i32,
    );

    unsafe { func.launch(cfg, params) }.w()?;

    output.to_dtype(x.dtype())
}

#[cfg(not(feature = "cuda"))]
pub fn rms_norm_cuda(x: &Tensor, weight: &Tensor, eps: f64) -> Result<Tensor> {
    rms_norm_cpu(x, weight, eps)
}

/// CPU fallback for RMSNorm
pub fn rms_norm_cpu(x: &Tensor, weight: &Tensor, eps: f64) -> Result<Tensor> {
    let x_f32 = x.to_dtype(DType::F32)?;
    let dim = x_f32.rank() - 1;
    let hidden_size = x_f32.dim(dim)?;

    let norm_x = (x_f32.sqr()?.sum_keepdim(dim)? / (hidden_size as f64))?;
    let x_normed = x_f32.broadcast_div(&(norm_x + eps)?.sqrt()?)?;

    let weight_f32 = weight
        .to_dtype(DType::F32)?
        .broadcast_as(x_normed.shape())?;
    let result = (x_normed * weight_f32)?;

    result.to_dtype(x.dtype())
}

/// Softmax on last dimension using CUDA kernel
#[cfg(feature = "cuda")]
pub fn softmax_cuda(x: &Tensor) -> Result<Tensor> {
    let dev = match x.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => return softmax_cpu(x),
    };

    let cuda_dev = dev.cuda_device();
    ensure_fused_ops_loaded(&cuda_dev, dev.ordinal())?;

    let dims = x.dims();
    let last_dim = dims[dims.len() - 1];
    let n_rows: usize = dims[..dims.len() - 1].iter().product();

    let x_f32 = x.to_dtype(DType::F32)?.contiguous()?;

    let x_ptr = {
        let storage = x_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("X must be CUDA tensor".to_string())),
        }
    };

    let output = Tensor::zeros(x.dims(), DType::F32, &Device::Cuda(dev.clone()))?;
    let out_ptr = {
        let storage = output.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Output allocation failed".to_string(),
                ))
            }
        }
    };

    let func = get_fused_ops_func(&cuda_dev, dev.ordinal(), "softmax_kernel_f32")?;

    let block_size = 256u32;
    let cfg = LaunchConfig {
        grid_dim: (n_rows as u32, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: 0,
    };

    let params = (x_ptr, out_ptr, last_dim as i32, n_rows as i32);

    unsafe { func.launch(cfg, params) }.w()?;

    output.to_dtype(x.dtype())
}

#[cfg(not(feature = "cuda"))]
pub fn softmax_cuda(x: &Tensor) -> Result<Tensor> {
    softmax_cpu(x)
}

/// CPU fallback for softmax
pub fn softmax_cpu(x: &Tensor) -> Result<Tensor> {
    use candle_core::D;
    let max = x.max_keepdim(D::Minus1)?;
    let exp = (x.broadcast_sub(&max))?.exp()?;
    let sum = exp.sum_keepdim(D::Minus1)?;
    exp.broadcast_div(&sum)
}

/// SiLU activation using CUDA kernel
#[cfg(feature = "cuda")]
pub fn silu_cuda(x: &Tensor) -> Result<Tensor> {
    let dev = match x.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => return candle_nn::ops::silu(x),
    };

    let cuda_dev = dev.cuda_device();
    ensure_fused_ops_loaded(&cuda_dev, dev.ordinal())?;

    let n_elements = x.elem_count();
    let x_f32 = x.to_dtype(DType::F32)?.contiguous()?;

    let x_ptr = {
        let storage = x_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("X must be CUDA tensor".to_string())),
        }
    };

    let output = Tensor::zeros(x.dims(), DType::F32, &Device::Cuda(dev.clone()))?;
    let out_ptr = {
        let storage = output.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Output allocation failed".to_string(),
                ))
            }
        }
    };

    let func = get_fused_ops_func(&cuda_dev, dev.ordinal(), "silu_kernel_f32")?;

    let block_size = 256u32;
    let grid_size = (n_elements as u32 + block_size - 1) / block_size;
    let cfg = LaunchConfig {
        grid_dim: (grid_size, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: 0,
    };

    let params = (x_ptr, out_ptr, n_elements as i32);

    unsafe { func.launch(cfg, params) }.w()?;

    output.to_dtype(x.dtype())
}

#[cfg(not(feature = "cuda"))]
pub fn silu_cuda(x: &Tensor) -> Result<Tensor> {
    candle_nn::ops::silu(x)
}

/// Fused SiLU(gate) * up using CUDA kernel
#[cfg(feature = "cuda")]
pub fn fused_silu_mul_cuda(gate: &Tensor, up: &Tensor) -> Result<Tensor> {
    let dev = match gate.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => {
            let silu_gate = candle_nn::ops::silu(gate)?;
            return silu_gate.mul(up);
        }
    };

    let cuda_dev = dev.cuda_device();
    ensure_fused_ops_loaded(&cuda_dev, dev.ordinal())?;

    let n_elements = gate.elem_count();
    let gate_f32 = gate.to_dtype(DType::F32)?.contiguous()?;
    let up_f32 = up.to_dtype(DType::F32)?.contiguous()?;

    let gate_ptr = {
        let storage = gate_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Gate must be CUDA tensor".to_string(),
                ))
            }
        }
    };

    let up_ptr = {
        let storage = up_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Up must be CUDA tensor".to_string(),
                ))
            }
        }
    };

    let output = Tensor::zeros(gate.dims(), DType::F32, &Device::Cuda(dev.clone()))?;
    let out_ptr = {
        let storage = output.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Output allocation failed".to_string(),
                ))
            }
        }
    };

    let func = get_fused_ops_func(&cuda_dev, dev.ordinal(), "fused_silu_mul_kernel_f32")?;

    let block_size = 256u32;
    let grid_size = (n_elements as u32 + block_size - 1) / block_size;
    let cfg = LaunchConfig {
        grid_dim: (grid_size, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: 0,
    };

    let params = (gate_ptr, up_ptr, out_ptr, n_elements as i32);

    unsafe { func.launch(cfg, params) }.w()?;

    output.to_dtype(gate.dtype())
}

#[cfg(not(feature = "cuda"))]
pub fn fused_silu_mul_cuda(gate: &Tensor, up: &Tensor) -> Result<Tensor> {
    let silu_gate = candle_nn::ops::silu(gate)?;
    silu_gate.mul(up)
}

/// GELU activation using CUDA kernel
#[cfg(feature = "cuda")]
pub fn gelu_cuda(x: &Tensor) -> Result<Tensor> {
    let dev = match x.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => return x.gelu(), // CPU fallback
    };

    let cuda_dev = dev.cuda_device();
    ensure_fused_ops_loaded(&cuda_dev, dev.ordinal())?;

    let n_elements = x.elem_count();
    let x_f32 = x.to_dtype(DType::F32)?.contiguous()?;

    let x_ptr = {
        let storage = x_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("X must be CUDA tensor".to_string())),
        }
    };

    let output = Tensor::zeros(x.dims(), DType::F32, &Device::Cuda(dev.clone()))?;
    let out_ptr = {
        let storage = output.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Output allocation failed".to_string(),
                ))
            }
        }
    };

    let func = match cuda_dev.get_func("fused_ops", "gelu_kernel_f32") {
        Some(f) => f,
        None => {
            // Kernel not found (bundled PTX may be outdated), fallback to CPU
            tracing::warn!("GELU CUDA kernel not found, using CPU fallback");
            return x.gelu();
        }
    };

    let block_size = 256u32;
    let grid_size = (n_elements as u32 + block_size - 1) / block_size;
    let cfg = LaunchConfig {
        grid_dim: (grid_size, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: 0,
    };

    let params = (x_ptr, out_ptr, n_elements as i32);

    unsafe { func.launch(cfg, params) }.w()?;

    output.to_dtype(x.dtype())
}

#[cfg(not(feature = "cuda"))]
pub fn gelu_cuda(x: &Tensor) -> Result<Tensor> {
    x.gelu()
}

/// Fused GELU * multiply using CUDA kernel (for GeGLU MLP)
#[cfg(feature = "cuda")]
pub fn fused_gelu_mul_cuda(gate: &Tensor, up: &Tensor) -> Result<Tensor> {
    let dev = match gate.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => return gate.gelu()?.mul(up), // CPU fallback
    };

    let cuda_dev = dev.cuda_device();
    ensure_fused_ops_loaded(&cuda_dev, dev.ordinal())?;

    let n_elements = gate.elem_count();
    let gate_f32 = gate.to_dtype(DType::F32)?.contiguous()?;
    let up_f32 = up.to_dtype(DType::F32)?.contiguous()?;

    let gate_ptr = {
        let storage = gate_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Gate must be CUDA tensor".to_string(),
                ))
            }
        }
    };

    let up_ptr = {
        let storage = up_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Up must be CUDA tensor".to_string(),
                ))
            }
        }
    };

    let output = Tensor::zeros(gate.dims(), DType::F32, &Device::Cuda(dev.clone()))?;
    let out_ptr = {
        let storage = output.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Output allocation failed".to_string(),
                ))
            }
        }
    };

    let func = match cuda_dev.get_func("fused_ops", "fused_gelu_mul_kernel_f32") {
        Some(f) => f,
        None => {
            // Kernel not found (bundled PTX may be outdated), fallback to CPU
            tracing::warn!("Fused GELU*MUL CUDA kernel not found, using CPU fallback");
            return gate.gelu()?.mul(up);
        }
    };

    let block_size = 256u32;
    let grid_size = (n_elements as u32 + block_size - 1) / block_size;
    let cfg = LaunchConfig {
        grid_dim: (grid_size, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: 0,
    };

    let params = (gate_ptr, up_ptr, out_ptr, n_elements as i32);

    unsafe { func.launch(cfg, params) }.w()?;

    output.to_dtype(gate.dtype())
}

#[cfg(not(feature = "cuda"))]
pub fn fused_gelu_mul_cuda(gate: &Tensor, up: &Tensor) -> Result<Tensor> {
    gate.gelu()?.mul(up)
}

/// Softcapping using CUDA kernel (Gemma-2)
/// Applies: tanh(x / cap) * cap
#[cfg(feature = "cuda")]
pub fn softcap_cuda(x: &Tensor, cap: f64) -> Result<Tensor> {
    let dev = match x.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => {
            // CPU fallback
            let scaled = (x / cap)?;
            return (scaled.tanh()? * cap);
        }
    };

    let cuda_dev = dev.cuda_device();
    ensure_fused_ops_loaded(&cuda_dev, dev.ordinal())?;

    let n_elements = x.elem_count();
    let x_f32 = x.to_dtype(DType::F32)?.contiguous()?;

    let x_ptr = {
        let storage = x_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("X must be CUDA tensor".to_string())),
        }
    };

    let output = Tensor::zeros(x.dims(), DType::F32, &Device::Cuda(dev.clone()))?;
    let out_ptr = {
        let storage = output.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Output allocation failed".to_string(),
                ))
            }
        }
    };

    let func = match cuda_dev.get_func("fused_ops", "softcap_kernel_f32") {
        Some(f) => f,
        None => {
            // Kernel not found, fallback to CPU
            tracing::warn!("Softcap CUDA kernel not found, using CPU fallback");
            let scaled = (x / cap)?;
            return (scaled.tanh()? * cap);
        }
    };

    let block_size = 256u32;
    let grid_size = (n_elements as u32 + block_size - 1) / block_size;
    let cfg = LaunchConfig {
        grid_dim: (grid_size, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: 0,
    };

    let params = (x_ptr, out_ptr, cap as f32, n_elements as i32);

    unsafe { func.launch(cfg, params) }.w()?;

    output.to_dtype(x.dtype())
}

#[cfg(not(feature = "cuda"))]
pub fn softcap_cuda(x: &Tensor, cap: f64) -> Result<Tensor> {
    let scaled = (x / cap)?;
    scaled.tanh()? * cap
}

/// Fused Residual Add + RMSNorm
///
/// Computes: sum = residual + x, norm = rms_norm(sum, weight)
/// Returns (sum, norm) - sum is needed as the next residual.
/// Saves 1 kernel launch per call (2→1 for add+norm).
#[cfg(feature = "cuda")]
pub fn fused_residual_add_rms_norm(
    residual: &Tensor,
    x: &Tensor,
    weight: &Tensor,
    eps: f64,
) -> Result<(Tensor, Tensor)> {
    let dev = match residual.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => {
            // CPU fallback: do it the normal way
            let sum = (residual + x)?;
            let norm = rms_norm_cpu(&sum, weight, eps)?;
            return Ok((sum, norm));
        }
    };

    let cuda_dev = dev.cuda_device();
    ensure_fused_ops_loaded(&cuda_dev, dev.ordinal())?;

    let dims = residual.dims();
    let hidden_dim = dims[dims.len() - 1];
    let n_rows: usize = dims[..dims.len() - 1].iter().product();

    let residual_f32 = residual.to_dtype(DType::F32)?.contiguous()?;
    let x_f32 = x.to_dtype(DType::F32)?.contiguous()?;
    let weight_f32 = weight.to_dtype(DType::F32)?.contiguous()?;

    let res_ptr = {
        let storage = residual_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("residual must be CUDA".into())),
        }
    };
    let x_ptr = {
        let storage = x_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("x must be CUDA".into())),
        }
    };
    let w_ptr = {
        let storage = weight_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("weight must be CUDA".into())),
        }
    };

    let sum_out = Tensor::zeros(dims, DType::F32, &Device::Cuda(dev.clone()))?;
    let norm_out = Tensor::zeros(dims, DType::F32, &Device::Cuda(dev.clone()))?;

    let sum_ptr = {
        let storage = sum_out.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("alloc failed".into())),
        }
    };
    let norm_ptr = {
        let storage = norm_out.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("alloc failed".into())),
        }
    };

    let func = get_fused_ops_func(&cuda_dev, dev.ordinal(), "fused_residual_add_rms_norm_f32")?;

    let cfg = LaunchConfig {
        grid_dim: (n_rows as u32, 1, 1),
        block_dim: (256, 1, 1),
        shared_mem_bytes: 0,
    };

    let params = (
        res_ptr,
        x_ptr,
        w_ptr,
        sum_ptr,
        norm_ptr,
        hidden_dim as i32,
        eps as f32,
        n_rows as i32,
    );

    unsafe { func.launch(cfg, params) }.w()?;

    let sum_out = sum_out.to_dtype(residual.dtype())?;
    let norm_out = norm_out.to_dtype(residual.dtype())?;
    Ok((sum_out, norm_out))
}

#[cfg(not(feature = "cuda"))]
pub fn fused_residual_add_rms_norm(
    residual: &Tensor,
    x: &Tensor,
    weight: &Tensor,
    eps: f64,
) -> Result<(Tensor, Tensor)> {
    let sum = (residual + x)?;
    let norm = rms_norm_cpu(&sum, weight, eps)?;
    Ok((sum, norm))
}

/// Fused RoPE (Rotary Position Embedding) applied in-place to Q and K
///
/// Replaces 10 kernel launches (neg, cat, mul, add × 2 for Q&K) with 1 kernel.
///
/// # Arguments
/// * `q` - Query tensor [batch, n_heads, seq_len, head_dim] (modified in-place via output)
/// * `k` - Key tensor [batch, n_kv_heads, seq_len, head_dim] (modified in-place via output)
/// * `cos` - Precomputed cosine [max_seq, head_dim] (full cache, sliced by start_pos)
/// * `sin` - Precomputed sine [max_seq, head_dim] (full cache, sliced by start_pos)
/// * `start_pos` - Starting position in the sequence
///
/// # Returns
/// (q_rotated, k_rotated) with RoPE applied
#[cfg(feature = "cuda")]
pub fn fused_rope_cuda(
    q: &Tensor,
    k: &Tensor,
    cos: &Tensor,
    sin: &Tensor,
    start_pos: usize,
) -> Result<(Tensor, Tensor)> {
    let dev = match q.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => return fused_rope_cpu(q, k, cos, sin, start_pos),
    };

    let cuda_dev = dev.cuda_device();
    ensure_fused_ops_loaded(&cuda_dev, dev.ordinal())?;

    let (batch, n_heads, seq_len, head_dim) = q.dims4()?;
    let (_, n_kv_heads, _, _) = k.dims4()?;

    // Prepare contiguous F32 tensors
    let q_f32 = q.to_dtype(DType::F32)?.contiguous()?;
    let k_f32 = k.to_dtype(DType::F32)?.contiguous()?;
    let cos_f32 = cos.to_dtype(DType::F32)?.contiguous()?;
    let sin_f32 = sin.to_dtype(DType::F32)?.contiguous()?;

    // Create output tensors (copy of input, will be modified by kernel)
    let q_out = q_f32.clone();
    let k_out = k_f32.clone();

    let q_ptr = {
        let storage = q_out.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("Q must be CUDA".to_string())),
        }
    };
    let k_ptr = {
        let storage = k_out.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("K must be CUDA".to_string())),
        }
    };
    let cos_ptr = {
        let storage = cos_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("cos must be CUDA".to_string())),
        }
    };
    let sin_ptr = {
        let storage = sin_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("sin must be CUDA".to_string())),
        }
    };

    let func = get_fused_ops_func(&cuda_dev, dev.ordinal(), "rope_kernel_f32")?;

    // Kernel handles Q with n_heads
    let total_q = batch * n_heads * seq_len * (head_dim / 2);
    let block_size = 256u32;
    let grid_size = (total_q as u32 + block_size - 1) / block_size;

    let cfg = LaunchConfig {
        grid_dim: (grid_size, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: 0,
    };

    // BUG FIX (2026-02-04): The CUDA kernel now accepts separate n_q_heads and n_kv_heads.
    // Previously, a single n_heads was used for both Q and K offset calculations,
    // causing out-of-bounds writes on K when n_kv_heads < n_heads (GQA models like Llama-3).
    // This produced garbage output (token 128255) for any GQA model with ratio > 1.
    //
    // The new kernel handles GQA natively in a single launch: Q threads use n_q_heads
    // for offsets, K threads use n_kv_heads. Threads where head >= n_kv_heads skip K writes.
    let params = (
        q_ptr,
        k_ptr,
        cos_ptr,
        sin_ptr,
        batch as i32,
        n_heads as i32,    // n_q_heads
        n_kv_heads as i32, // n_kv_heads (may be < n_q_heads for GQA)
        seq_len as i32,
        head_dim as i32,
        start_pos as i32,
    );
    unsafe { func.launch(cfg, params) }.w()?;

    Ok((q_out.to_dtype(q.dtype())?, k_out.to_dtype(k.dtype())?))
}

#[cfg(not(feature = "cuda"))]
pub fn fused_rope_cuda(
    q: &Tensor,
    k: &Tensor,
    cos: &Tensor,
    sin: &Tensor,
    start_pos: usize,
) -> Result<(Tensor, Tensor)> {
    fused_rope_cpu(q, k, cos, sin, start_pos)
}

/// CPU fallback for fused RoPE
pub fn fused_rope_cpu(
    q: &Tensor,
    k: &Tensor,
    cos_full: &Tensor,
    sin_full: &Tensor,
    start_pos: usize,
) -> Result<(Tensor, Tensor)> {
    let (b_sz, n_q_heads, seq_len, head_dim) = q.dims4()?;
    let (_, n_kv_heads, _, _) = k.dims4()?;
    let half_dim = head_dim / 2;

    // cos/sin: [max_seq, half_dim] → narrow to [seq_len, half_dim]
    let cos = cos_full.narrow(0, start_pos, seq_len)?;
    let sin = sin_full.narrow(0, start_pos, seq_len)?;

    // Interleaved RoPE: pair (d[2i], d[2i+1]) with freq[i]
    // Reshape x from [b, h, s, dim] → [b, h, s, half_dim, 2]
    // Apply rotation, reshape back
    fn apply_interleaved_rope(
        x: &Tensor,
        cos: &Tensor,
        sin: &Tensor,
        b: usize,
        n_heads: usize,
        seq: usize,
        h_dim: usize,
    ) -> Result<Tensor> {
        let half = h_dim / 2;
        // [b, h, s, dim] → [b, h, s, half, 2]
        let x_pairs = x.reshape((b, n_heads, seq, half, 2))?;
        let x0 = x_pairs.narrow(4, 0, 1)?.squeeze(4)?; // [b, h, s, half]
        let x1 = x_pairs.narrow(4, 1, 1)?.squeeze(4)?; // [b, h, s, half]

        // cos/sin: [s, half] → [1, 1, s, half] for broadcast
        let cos_b = cos.unsqueeze(0)?.unsqueeze(0)?;
        let sin_b = sin.unsqueeze(0)?.unsqueeze(0)?;

        // y0 = x0 * cos - x1 * sin
        // y1 = x0 * sin + x1 * cos
        let y0 = (x0.broadcast_mul(&cos_b)? - x1.broadcast_mul(&sin_b)?)?;
        let y1 = (x0.broadcast_mul(&sin_b)? + x1.broadcast_mul(&cos_b)?)?;

        // Stack back: [b, h, s, half, 2] → [b, h, s, dim]
        let y0 = y0.unsqueeze(4)?;
        let y1 = y1.unsqueeze(4)?;
        let y_pairs = Tensor::cat(&[&y0, &y1], 4)?; // [b, h, s, half, 2]
        y_pairs.reshape((b, n_heads, seq, h_dim))
    }

    let q_embed = apply_interleaved_rope(q, &cos, &sin, b_sz, n_q_heads, seq_len, head_dim)?;
    let k_embed = apply_interleaved_rope(k, &cos, &sin, b_sz, n_kv_heads, seq_len, head_dim)?;
    Ok((q_embed, k_embed))
}
