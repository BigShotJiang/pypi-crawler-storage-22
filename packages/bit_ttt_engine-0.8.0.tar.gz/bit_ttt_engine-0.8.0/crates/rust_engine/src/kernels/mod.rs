pub mod cpu;
pub mod cublas_gemv; // cuBLAS GEMV for optimized decode attention
pub mod cuda;
pub mod flash_attention_cuda; // CUDA Flash Attention (prefill)
pub mod flash_decoding; // CUDA Flash-Decoding (decode)
pub mod fused_ops; // Fused CUDA kernels (RMSNorm, softmax, RoPE, SiLU)
pub mod matmul_4bit;
pub mod packing;
pub mod packing_4bit; // 4-bit quantization packing/unpacking
pub mod paged_attention; // PagedAttention CUDA kernels
pub mod quantize_q8; // Q8_0 quantization for KV cache
pub mod wmma_matmul; // WMMA (Tensor Core) accelerated MatMul
