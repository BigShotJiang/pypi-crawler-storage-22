/**
 * Q8_0 Quantization Kernels for KV Cache
 * 
 * Based on llama.cpp's Q8_0 format:
 * - Block size: 32 values
 * - Per-block scale (FP16)
 * - INT8 quantized values
 */

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdint.h>
#include <float.h>

// Block size for Q8_0 quantization
#define QK8_0 32

// Q8_0 block structure (34 bytes for 32 values)
struct block_q8_0 {
    __half d;           // delta (scale)
    int8_t qs[QK8_0];   // quantized values
};

// Warp size
#define WARP_SIZE 32

// Helper for unaligned int32 load from int8 array
// block_q8_0.qs is at offset 2 (after __half d), so it's NOT 4-byte aligned
__device__ __forceinline__ int load_int32_unaligned(const int8_t* ptr) {
    int result;
    // Use memcpy which compiler optimizes to appropriate load instruction
    memcpy(&result, ptr, sizeof(int));
    return result;
}

// ============================================================================
// Quantization: FP16 -> Q8_0
// ============================================================================

/**
 * Quantize FP16 tensor to Q8_0 format
 * 
 * Each block of 32 values gets:
 * - scale = max(|x|) / 127
 * - q[i] = round(x[i] / scale)
 * 
 * @param x         Input FP16 tensor [n_elements]
 * @param dst       Output Q8_0 blocks [n_elements / QK8_0]
 * @param n_blocks  Number of Q8_0 blocks
 */
extern "C" __global__ void quantize_q8_0_kernel(
    const __half* __restrict__ x,
    block_q8_0* __restrict__ dst,
    int n_blocks
) {
    int block_idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (block_idx >= n_blocks) return;
    
    const __half* x_block = x + block_idx * QK8_0;
    block_q8_0* dst_block = dst + block_idx;
    
    // Find max absolute value in block
    float amax = 0.0f;
    float vals[QK8_0];
    
    #pragma unroll
    for (int i = 0; i < QK8_0; i++) {
        float v = __half2float(x_block[i]);
        vals[i] = v;
        amax = fmaxf(amax, fabsf(v));
    }
    
    // Compute scale
    float d = amax / 127.0f;
    float id = (d != 0.0f) ? (127.0f / amax) : 0.0f;
    
    dst_block->d = __float2half(d);
    
    // Quantize values
    #pragma unroll
    for (int i = 0; i < QK8_0; i++) {
        int q = __float2int_rn(vals[i] * id);
        q = max(-127, min(127, q));
        dst_block->qs[i] = (int8_t)q;
    }
}

/**
 * Quantize FP32 tensor to Q8_0 format
 */
extern "C" __global__ void quantize_q8_0_f32_kernel(
    const float* __restrict__ x,
    block_q8_0* __restrict__ dst,
    int n_blocks
) {
    int block_idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (block_idx >= n_blocks) return;
    
    const float* x_block = x + block_idx * QK8_0;
    block_q8_0* dst_block = dst + block_idx;
    
    // Find max absolute value in block
    float amax = 0.0f;
    
    #pragma unroll
    for (int i = 0; i < QK8_0; i++) {
        amax = fmaxf(amax, fabsf(x_block[i]));
    }
    
    // Compute scale
    float d = amax / 127.0f;
    float id = (d != 0.0f) ? (127.0f / amax) : 0.0f;
    
    dst_block->d = __float2half(d);
    
    // Quantize values
    #pragma unroll
    for (int i = 0; i < QK8_0; i++) {
        int q = __float2int_rn(x_block[i] * id);
        q = max(-127, min(127, q));
        dst_block->qs[i] = (int8_t)q;
    }
}

// ============================================================================
// Dequantization: Q8_0 -> FP16 (for debugging/validation)
// ============================================================================

/**
 * Dequantize Q8_0 to FP16
 * 
 * x[i] = q[i] * scale
 */
extern "C" __global__ void dequantize_q8_0_kernel(
    const block_q8_0* __restrict__ src,
    __half* __restrict__ dst,
    int n_blocks
) {
    int block_idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (block_idx >= n_blocks) return;
    
    const block_q8_0* src_block = src + block_idx;
    __half* dst_block = dst + block_idx * QK8_0;
    
    float d = __half2float(src_block->d);
    
    #pragma unroll
    for (int i = 0; i < QK8_0; i++) {
        float v = (float)src_block->qs[i] * d;
        dst_block[i] = __float2half(v);
    }
}

// ============================================================================
// Dot Product: Q8_0 × FP16 -> FP32
// ============================================================================

/**
 * Compute dot product between Q8_0 block and FP16 vector
 * 
 * This is the core operation for attention: Q × K where K is Q8_0 quantized
 * 
 * @param k_q8      Q8_0 quantized K block
 * @param q_f16     FP16 query vector (32 elements)
 * @return          Dot product result (FP32)
 */
__device__ __forceinline__ float vec_dot_q8_0_f16(
    const block_q8_0* __restrict__ k_q8,
    const __half* __restrict__ q_f16
) {
    float d = __half2float(k_q8->d);
    float sum = 0.0f;
    
    #pragma unroll
    for (int i = 0; i < QK8_0; i++) {
        sum += (float)k_q8->qs[i] * __half2float(q_f16[i]);
    }
    
    return sum * d;
}

/**
 * Vectorized dot product using int8 SIMD (4 values at a time)
 */
__device__ __forceinline__ float vec_dot_q8_0_f16_simd(
    const block_q8_0* __restrict__ k_q8,
    const __half2* __restrict__ q_f16_2
) {
    float d = __half2float(k_q8->d);
    float sum = 0.0f;
    
    // Process 4 elements at a time using __half2
    // Use unaligned load because qs is at offset 2 in block_q8_0
    
    #pragma unroll
    for (int i = 0; i < QK8_0 / 4; i++) {
        int32_t qs4 = load_int32_unaligned(k_q8->qs + i * 4);
        
        // Extract 4 int8 values
        int8_t q0 = (int8_t)(qs4 & 0xFF);
        int8_t q1 = (int8_t)((qs4 >> 8) & 0xFF);
        int8_t q2 = (int8_t)((qs4 >> 16) & 0xFF);
        int8_t q3 = (int8_t)((qs4 >> 24) & 0xFF);
        
        // Load 4 FP16 values as 2 half2
        __half2 qf0 = q_f16_2[i * 2];
        __half2 qf1 = q_f16_2[i * 2 + 1];
        
        // Compute partial sums
        sum += (float)q0 * __low2float(qf0);
        sum += (float)q1 * __high2float(qf0);
        sum += (float)q2 * __low2float(qf1);
        sum += (float)q3 * __high2float(qf1);
    }
    
    return sum * d;
}

// ============================================================================
// Optimized Dot Product using DP4A (INT8 SIMD)
// ============================================================================

/**
 * DP4A: Dot Product of 4 signed int8 values, accumulated into int32
 * Available on SM 6.1+ (Pascal and later)
 * 
 * __dp4a(a, b, c) = a[0]*b[0] + a[1]*b[1] + a[2]*b[2] + a[3]*b[3] + c
 */
__device__ __forceinline__ int dp4a(int a, int b, int c) {
#if __CUDA_ARCH__ >= 610
    return __dp4a(a, b, c);
#else
    // Fallback for older GPUs
    const int8_t* a8 = (const int8_t*)&a;
    const int8_t* b8 = (const int8_t*)&b;
    return c + a8[0]*b8[0] + a8[1]*b8[1] + a8[2]*b8[2] + a8[3]*b8[3];
#endif
}

/**
 * Optimized Q8_0 × Q8_0 dot product using DP4A
 * 
 * Both K and Q are quantized to Q8_0 format.
 * This is the fastest method for INT8 dot products.
 * 
 * @param k_q8  Q8_0 quantized K block (32 values)
 * @param q_q8  Q8_0 quantized Q block (32 values)
 * @return      Dot product result (FP32)
 */
__device__ __forceinline__ float vec_dot_q8_0_q8_0_dp4a(
    const block_q8_0* __restrict__ k_q8,
    const block_q8_0* __restrict__ q_q8
) {
    int sumi = 0;
    
    // 32 values = 8 int32s, each containing 4 int8s
    // Use unaligned loads because qs is at offset 2 in block_q8_0
    #pragma unroll
    for (int i = 0; i < QK8_0 / 4; i++) {
        int k_packed = load_int32_unaligned(k_q8->qs + i * 4);
        int q_packed = load_int32_unaligned(q_q8->qs + i * 4);
        sumi = dp4a(k_packed, q_packed, sumi);
    }
    
    // Scale by both deltas
    float d_k = __half2float(k_q8->d);
    float d_q = __half2float(q_q8->d);
    
    return (float)sumi * d_k * d_q;
}

/**
 * Warp-level reduction for sum
 * Reduces a value across all threads in a warp using shuffle instructions
 */
__device__ __forceinline__ float warp_reduce_sum(float val) {
    #pragma unroll
    for (int mask = 16; mask > 0; mask >>= 1) {
        val += __shfl_xor_sync(0xFFFFFFFF, val, mask);
    }
    return val;
}

/**
 * Warp-level reduction for max
 */
__device__ __forceinline__ float warp_reduce_max(float val) {
    #pragma unroll
    for (int mask = 16; mask > 0; mask >>= 1) {
        val = fmaxf(val, __shfl_xor_sync(0xFFFFFFFF, val, mask));
    }
    return val;
}

/**
 * Batch dot product: Multiple Q8_0 × Q8_0 dot products
 * 
 * Computes dot products between one query and multiple keys.
 * Optimized for attention score computation.
 * 
 * @param Q_q8      Single query block (Q8_0)
 * @param K_q8      Array of key blocks (Q8_0)
 * @param scores    Output scores array
 * @param n_keys    Number of keys to process
 * @param head_dim_blocks  Number of Q8_0 blocks per head_dim (head_dim/32)
 */
extern "C" __global__ void batch_dot_q8_0_kernel(
    const block_q8_0* __restrict__ Q_q8,
    const block_q8_0* __restrict__ K_q8,
    float* __restrict__ scores,
    int n_keys,
    int head_dim_blocks
) {
    int key_idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (key_idx >= n_keys) return;
    
    float score = 0.0f;
    
    // Compute dot product across all blocks in head_dim
    for (int b = 0; b < head_dim_blocks; b++) {
        const block_q8_0* q_block = Q_q8 + b;
        const block_q8_0* k_block = K_q8 + key_idx * head_dim_blocks + b;
        
        score += vec_dot_q8_0_q8_0_dp4a(q_block, k_block);
    }
    
    scores[key_idx] = score;
}

/**
 * Quantize Q to Q8_0 and compute dot product with K (already Q8_0)
 * 
 * This is useful when Q is in FP16 but K is pre-quantized in cache.
 * Quantizes Q on-the-fly in registers.
 * 
 * @param Q_f16     Query in FP16 format [head_dim]
 * @param K_q8      Key in Q8_0 format [head_dim / 32 blocks]
 * @param head_dim  Head dimension (must be divisible by 32)
 * @return          Dot product result
 */
__device__ float dot_f16_q8_0_quantize_on_fly(
    const __half* __restrict__ Q_f16,
    const block_q8_0* __restrict__ K_q8,
    int head_dim
) {
    float total_sum = 0.0f;
    int n_blocks = head_dim / QK8_0;
    
    for (int b = 0; b < n_blocks; b++) {
        const __half* q_block = Q_f16 + b * QK8_0;
        const block_q8_0* k_block = K_q8 + b;
        
        // Find max of Q block for quantization
        float q_amax = 0.0f;
        float q_vals[QK8_0];
        
        #pragma unroll
        for (int i = 0; i < QK8_0; i++) {
            float v = __half2float(q_block[i]);
            q_vals[i] = v;
            q_amax = fmaxf(q_amax, fabsf(v));
        }
        
        // Quantize Q and compute dot product
        float q_d = q_amax / 127.0f;
        float q_id = (q_amax != 0.0f) ? (127.0f / q_amax) : 0.0f;
        float k_d = __half2float(k_block->d);
        
        int sumi = 0;
        #pragma unroll
        for (int i = 0; i < QK8_0; i += 4) {
            // Quantize 4 Q values
            int q_packed = 0;
            int8_t* q_bytes = (int8_t*)&q_packed;
            q_bytes[0] = (int8_t)__float2int_rn(q_vals[i+0] * q_id);
            q_bytes[1] = (int8_t)__float2int_rn(q_vals[i+1] * q_id);
            q_bytes[2] = (int8_t)__float2int_rn(q_vals[i+2] * q_id);
            q_bytes[3] = (int8_t)__float2int_rn(q_vals[i+3] * q_id);
            
            // Load K values (unaligned because qs is at offset 2 in block)
            int k_packed = load_int32_unaligned(k_block->qs + i);
            
            // DP4A
            sumi = dp4a(q_packed, k_packed, sumi);
        }
        
        total_sum += (float)sumi * q_d * k_d;
    }
    
    return total_sum;
}

// ============================================================================
// Flash Attention with Q8_0 KV Cache - Optimized Version
// ============================================================================

#define FA_BLOCK_SIZE 256
#define WARP_SIZE 32

/**
 * Block-level reduction for max using shared memory
 */
__device__ __forceinline__ float block_reduce_max(float val, float* shared) {
    int lane = threadIdx.x % WARP_SIZE;
    int wid = threadIdx.x / WARP_SIZE;
    
    // Warp-level reduction
    val = warp_reduce_max(val);
    
    // Write warp results to shared memory
    if (lane == 0) shared[wid] = val;
    __syncthreads();
    
    // First warp reduces across warps
    if (wid == 0) {
        val = (threadIdx.x < blockDim.x / WARP_SIZE) ? shared[lane] : -FLT_MAX;
        val = warp_reduce_max(val);
    }
    __syncthreads();
    
    return __shfl_sync(0xFFFFFFFF, val, 0);
}

/**
 * Block-level reduction for sum using shared memory
 */
__device__ __forceinline__ float block_reduce_sum(float val, float* shared) {
    int lane = threadIdx.x % WARP_SIZE;
    int wid = threadIdx.x / WARP_SIZE;
    
    // Warp-level reduction
    val = warp_reduce_sum(val);
    
    // Write warp results to shared memory
    if (lane == 0) shared[wid] = val;
    __syncthreads();
    
    // First warp reduces across warps
    if (wid == 0) {
        val = (threadIdx.x < blockDim.x / WARP_SIZE) ? shared[lane] : 0.0f;
        val = warp_reduce_sum(val);
    }
    __syncthreads();
    
    return __shfl_sync(0xFFFFFFFF, val, 0);
}

/**
 * Optimized Flash Attention with Q8_0 quantized K and V
 * Uses DP4A for Q×K computation and warp-level reductions
 * 
 * For decode phase (single query token):
 * - Q: [batch, n_heads, 1, head_dim] FP16
 * - K: [batch, n_kv_heads, seq_len, head_dim] Q8_0
 * - V: [batch, n_kv_heads, seq_len, head_dim] Q8_0
 * - Output: [batch, n_heads, 1, head_dim] FP16
 */
extern "C" __global__ void flash_attention_decode_q8(
    const __half* __restrict__ Q,
    const block_q8_0* __restrict__ K_q8,
    const block_q8_0* __restrict__ V_q8,
    __half* __restrict__ output,
    float scale,
    int n_heads,
    int n_kv_heads,
    int seq_len,
    int head_dim
) {
    // Block handles one head
    int head_idx = blockIdx.x;
    int kv_head_idx = head_idx * n_kv_heads / n_heads;  // GQA support
    
    // Number of Q8_0 blocks per head_dim
    int blocks_per_head = head_dim / QK8_0;
    // Total blocks per sequence position (all kv_heads)
    int blocks_per_pos = n_kv_heads * blocks_per_head;
    
    // Shared memory layout:
    // [0, head_dim): Q values (scaled, quantized to int8)
    // [head_dim, head_dim + seq_len): attention scores
    // [head_dim + seq_len, ...): reduction workspace
    extern __shared__ char shared_bytes[];
    int8_t* Q_q8_shared = (int8_t*)shared_bytes;           // [head_dim]
    float* Q_scales = (float*)(Q_q8_shared + head_dim);    // [blocks_per_head]
    float* scores = Q_scales + blocks_per_head;             // [seq_len]
    float* reduce_workspace = scores + seq_len;             // [8] for reductions
    
    // Load and quantize Q into shared memory
    const __half* Q_head = Q + head_idx * head_dim;
    
    // Each thread handles multiple elements
    for (int b = threadIdx.x; b < blocks_per_head; b += blockDim.x) {
        float amax = 0.0f;
        float vals[QK8_0];
        
        // Load block and find max
        #pragma unroll
        for (int i = 0; i < QK8_0; i++) {
            float v = __half2float(Q_head[b * QK8_0 + i]) * scale;
            vals[i] = v;
            amax = fmaxf(amax, fabsf(v));
        }
        
        // Quantize
        float d = amax / 127.0f;
        float id = (amax != 0.0f) ? (127.0f / amax) : 0.0f;
        
        Q_scales[b] = d;
        
        #pragma unroll
        for (int i = 0; i < QK8_0; i++) {
            Q_q8_shared[b * QK8_0 + i] = (int8_t)__float2int_rn(vals[i] * id);
        }
    }
    __syncthreads();
    
    // Compute attention scores using DP4A: Q × K^T
    // Memory layout: [seq_pos, kv_head, head_dim_blocks]
    float local_max = -FLT_MAX;
    
    for (int s = threadIdx.x; s < seq_len; s += blockDim.x) {
        // Access pattern: s * blocks_per_pos + kv_head_idx * blocks_per_head
        const block_q8_0* K_pos = K_q8 + s * blocks_per_pos + kv_head_idx * blocks_per_head;
        
        float score = 0.0f;
        
        // DP4A-optimized dot product
        for (int b = 0; b < blocks_per_head; b++) {
            float k_d = __half2float(K_pos[b].d);
            float q_d = Q_scales[b];
            
            // Q is in shared memory (aligned), K is in global memory (potentially unaligned)
            const int32_t* q_i32 = (const int32_t*)(Q_q8_shared + b * QK8_0);
            
            int sumi = 0;
            #pragma unroll
            for (int i = 0; i < QK8_0 / 4; i++) {
                // Use unaligned load for K because qs is at offset 2 in block_q8_0
                int k_packed = load_int32_unaligned(K_pos[b].qs + i * 4);
                sumi = dp4a(q_i32[i], k_packed, sumi);
            }
            
            score += (float)sumi * q_d * k_d;
        }
        
        scores[s] = score;
        local_max = fmaxf(local_max, score);
    }
    
    // Block-level max reduction
    float max_score = block_reduce_max(local_max, reduce_workspace);
    
    // Compute exp and sum
    float local_sum = 0.0f;
    for (int s = threadIdx.x; s < seq_len; s += blockDim.x) {
        float exp_val = expf(scores[s] - max_score);
        scores[s] = exp_val;
        local_sum += exp_val;
    }
    
    // Block-level sum reduction
    float sum_exp = block_reduce_sum(local_sum, reduce_workspace);
    
    // Normalize scores
    float inv_sum = 1.0f / sum_exp;
    for (int s = threadIdx.x; s < seq_len; s += blockDim.x) {
        scores[s] *= inv_sum;
    }
    __syncthreads();
    
    // Compute output: Scores × V (with V dequantization)
    __half* out_head = output + head_idx * head_dim;
    
    for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
        int block_idx = d / QK8_0;
        int block_offset = d % QK8_0;
        
        float out_val = 0.0f;
        
        for (int s = 0; s < seq_len; s++) {
            // Memory layout: [seq_pos, kv_head, head_dim_blocks]
            const block_q8_0* V_pos = V_q8 + s * blocks_per_pos + kv_head_idx * blocks_per_head + block_idx;
            float v = (float)V_pos->qs[block_offset] * __half2float(V_pos->d);
            out_val += scores[s] * v;
        }
        
        out_head[d] = __float2half(out_val);
    }
}
