//! Q8_0 Quantization for KV Cache
//!
//! Based on llama.cpp's Q8_0 format:
//! - Block size: 32 values
//! - Per-block scale (FP16)
//! - INT8 quantized values
//!
//! Memory layout:
//! ```
//! block_q8_0 {
//!     d: f16,         // scale
//!     qs: [i8; 32],   // quantized values
//! } // 34 bytes total
//! ```

#[cfg(feature = "cuda")]
use candle_core::cuda_backend::cudarc::driver::{DevicePtr, LaunchAsync};
use candle_core::{DType, Device, Result, Tensor};

/// Block size for Q8_0 quantization
pub const QK8_0: usize = 32;

/// Size of a Q8_0 block in bytes (2 bytes scale + 32 bytes data)
pub const BLOCK_Q8_0_SIZE: usize = 34;

#[cfg(feature = "cuda")]
const QUANTIZE_Q8_PTX: &str = include_str!(concat!(env!("OUT_DIR"), "/quantize_q8.ptx"));

#[cfg(feature = "cuda")]
fn ensure_quantize_q8_loaded(
    cuda_dev: &std::sync::Arc<candle_core::cuda_backend::cudarc::driver::CudaDevice>,
    _device_id: usize,
) -> Result<()> {
    use candle_core::cuda_backend::WrapErr;

    // Check if PTX is already loaded on THIS device instance
    // (not by device ordinal — each Arc<CudaDevice> has its own module map)
    if cuda_dev
        .get_func("quantize_q8", "quantize_q8_0_kernel")
        .is_some()
    {
        return Ok(());
    }

    cuda_dev
        .load_ptx(
            QUANTIZE_Q8_PTX.into(),
            "quantize_q8",
            &[
                "quantize_q8_0_kernel",
                "quantize_q8_0_f32_kernel",
                "dequantize_q8_0_kernel",
                "flash_attention_decode_q8",
                "batch_dot_q8_0_kernel",
            ],
        )
        .w()?;
    tracing::info!("Loaded quantize_q8 PTX on device instance");

    Ok(())
}

/// Q8_0 Quantized KV Cache (CPU version - legacy)
///
/// Stores K and V tensors in Q8_0 format for memory efficiency.
#[derive(Debug)]
pub struct KVCacheQ8 {
    /// Quantized K cache as raw bytes
    /// Shape: [batch, n_kv_heads, seq_len, n_blocks, BLOCK_Q8_0_SIZE]
    pub k_data: Vec<u8>,

    /// Quantized V cache as raw bytes
    pub v_data: Vec<u8>,

    /// Current sequence length
    pub seq_len: usize,

    /// Maximum sequence length
    pub max_seq_len: usize,

    /// Number of KV heads
    pub n_kv_heads: usize,

    /// Head dimension
    pub head_dim: usize,

    /// Device
    pub device: Device,
}

/// Q8_0 Quantized KV Cache (GPU-optimized version)
///
/// Keeps all data on GPU to avoid CPU-GPU transfers.
/// This is ~3x faster than the CPU version during inference.
#[cfg(feature = "cuda")]
pub struct KVCacheQ8Gpu {
    /// Quantized K cache on GPU
    k_gpu: candle_core::cuda_backend::cudarc::driver::CudaSlice<u8>,

    /// Quantized V cache on GPU
    v_gpu: candle_core::cuda_backend::cudarc::driver::CudaSlice<u8>,

    /// Current sequence length
    pub seq_len: usize,

    /// Maximum sequence length
    pub max_seq_len: usize,

    /// Number of KV heads
    pub n_kv_heads: usize,

    /// Head dimension
    pub head_dim: usize,

    /// CUDA device
    cuda_device: std::sync::Arc<candle_core::cuda_backend::cudarc::driver::CudaDevice>,

    /// Device ordinal
    device_ordinal: usize,
}

#[cfg(feature = "cuda")]
impl KVCacheQ8Gpu {
    /// Create a new GPU-resident Q8_0 KV cache
    pub fn new(
        max_seq_len: usize,
        n_kv_heads: usize,
        head_dim: usize,
        device: &Device,
    ) -> Result<Self> {
        use candle_core::cuda_backend::WrapErr;

        assert!(
            head_dim % QK8_0 == 0,
            "head_dim must be divisible by {}",
            QK8_0
        );

        let cuda_device = match device {
            Device::Cuda(dev) => dev,
            _ => candle_core::bail!("KVCacheQ8Gpu requires CUDA device"),
        };

        let cuda_dev = cuda_device.cuda_device();
        let device_ordinal = cuda_device.ordinal();

        // Ensure PTX is loaded
        ensure_quantize_q8_loaded(&cuda_dev, device_ordinal)?;

        let n_blocks = head_dim / QK8_0;
        let bytes_per_pos = n_kv_heads * n_blocks * BLOCK_Q8_0_SIZE;
        let total_bytes = max_seq_len * bytes_per_pos;

        // Allocate GPU buffers
        let k_gpu = unsafe { cuda_dev.alloc::<u8>(total_bytes).w()? };
        let v_gpu = unsafe { cuda_dev.alloc::<u8>(total_bytes).w()? };

        tracing::debug!(
            "KVCacheQ8Gpu allocated: {} MB per cache (max_seq={})",
            total_bytes / 1024 / 1024,
            max_seq_len
        );

        Ok(Self {
            k_gpu,
            v_gpu,
            seq_len: 0,
            max_seq_len,
            n_kv_heads,
            head_dim,
            cuda_device: cuda_dev.clone(),
            device_ordinal,
        })
    }

    /// Append new K and V tensors to the cache (quantizing directly on GPU)
    pub fn append(&mut self, k: &Tensor, v: &Tensor) -> Result<usize> {
        use candle_core::cuda_backend::cudarc::driver::LaunchConfig;
        use candle_core::cuda_backend::WrapErr;

        let (_b_sz, n_kv_heads, new_seq_len, head_dim) = k.dims4()?;

        assert_eq!(n_kv_heads, self.n_kv_heads, "KV heads mismatch");
        assert_eq!(head_dim, self.head_dim, "head_dim mismatch");
        assert!(
            self.seq_len + new_seq_len <= self.max_seq_len,
            "KV cache overflow"
        );

        // Convert to F16 and flatten
        let k_f16 = k.to_dtype(DType::F16)?.contiguous()?.flatten_all()?;
        let v_f16 = v.to_dtype(DType::F16)?.contiguous()?.flatten_all()?;

        let n_elements = k_f16.elem_count();
        let n_blocks = n_elements / QK8_0;

        // Calculate offset in cache
        let blocks_per_pos = (self.n_kv_heads * self.head_dim) / QK8_0;
        let bytes_per_pos = blocks_per_pos * BLOCK_Q8_0_SIZE;
        let offset = self.seq_len * bytes_per_pos;

        // Get input pointers
        let k_ptr = {
            let storage = k_f16.storage_and_layout().0;
            match &*storage {
                candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<half::f16>()?.device_ptr(),
                _ => candle_core::bail!("K tensor not on CUDA"),
            }
        };

        let v_ptr = {
            let storage = v_f16.storage_and_layout().0;
            match &*storage {
                candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<half::f16>()?.device_ptr(),
                _ => candle_core::bail!("V tensor not on CUDA"),
            }
        };

        // Get output pointers with offset
        let k_out_ptr = *self.k_gpu.device_ptr() + offset as u64;
        let v_out_ptr = *self.v_gpu.device_ptr() + offset as u64;

        let func = self
            .cuda_device
            .get_func("quantize_q8", "quantize_q8_0_kernel")
            .ok_or_else(|| candle_core::Error::Msg("quantize_q8_0_kernel not found".into()))?;

        let block_size = 256u32;
        let grid_size = (n_blocks as u32 + block_size - 1) / block_size;
        let cfg = LaunchConfig {
            grid_dim: (grid_size, 1, 1),
            block_dim: (block_size, 1, 1),
            shared_mem_bytes: 0,
        };

        // Quantize K directly into GPU cache
        let params_k = (k_ptr, k_out_ptr, n_blocks as i32);
        unsafe { func.clone().launch(cfg.clone(), params_k) }.w()?;

        // Quantize V directly into GPU cache
        let params_v = (v_ptr, v_out_ptr, n_blocks as i32);
        unsafe { func.launch(cfg, params_v) }.w()?;

        let old_seq_len = self.seq_len;
        self.seq_len += new_seq_len;

        Ok(old_seq_len)
    }

    /// Get K cache GPU pointer
    pub fn k_ptr(&self) -> u64 {
        *self.k_gpu.device_ptr()
    }

    /// Get V cache GPU pointer
    pub fn v_ptr(&self) -> u64 {
        *self.v_gpu.device_ptr()
    }

    /// Get current sequence length
    pub fn current_seq_len(&self) -> usize {
        self.seq_len
    }

    /// Reset the cache
    pub fn reset(&mut self) {
        self.seq_len = 0;
    }
}

impl KVCacheQ8 {
    /// Create a new Q8_0 KV cache
    pub fn new(max_seq_len: usize, n_kv_heads: usize, head_dim: usize, device: &Device) -> Self {
        assert!(
            head_dim % QK8_0 == 0,
            "head_dim must be divisible by {}",
            QK8_0
        );

        let n_blocks = head_dim / QK8_0;
        let bytes_per_pos = n_kv_heads * n_blocks * BLOCK_Q8_0_SIZE;
        let total_bytes = max_seq_len * bytes_per_pos;

        Self {
            k_data: vec![0u8; total_bytes],
            v_data: vec![0u8; total_bytes],
            seq_len: 0,
            max_seq_len,
            n_kv_heads,
            head_dim,
            device: device.clone(),
        }
    }

    /// Append new K and V tensors to the cache (quantizing to Q8_0)
    ///
    /// # Arguments
    /// * `k` - Key tensor [batch, n_kv_heads, new_seq_len, head_dim] FP16/FP32
    /// * `v` - Value tensor [batch, n_kv_heads, new_seq_len, head_dim] FP16/FP32
    ///
    /// # Returns
    /// New sequence position for the added tokens
    #[cfg(feature = "cuda")]
    pub fn append(&mut self, k: &Tensor, v: &Tensor) -> Result<usize> {
        let (_b_sz, n_kv_heads, new_seq_len, head_dim) = k.dims4()?;

        assert_eq!(n_kv_heads, self.n_kv_heads, "KV heads mismatch");
        assert_eq!(head_dim, self.head_dim, "head_dim mismatch");
        assert!(
            self.seq_len + new_seq_len <= self.max_seq_len,
            "KV cache overflow"
        );

        // Quantize K and V to Q8_0
        let k_flat = k.flatten_all()?;
        let v_flat = v.flatten_all()?;

        let k_q8 = quantize_q8_0(&k_flat)?;
        let v_q8 = quantize_q8_0(&v_flat)?;

        // Calculate offset in cache
        let n_blocks = head_dim / QK8_0;
        let bytes_per_pos = n_kv_heads * n_blocks * BLOCK_Q8_0_SIZE;
        let offset = self.seq_len * bytes_per_pos;

        // Copy to cache
        let copy_len = new_seq_len * bytes_per_pos;
        self.k_data[offset..offset + copy_len].copy_from_slice(&k_q8[..copy_len]);
        self.v_data[offset..offset + copy_len].copy_from_slice(&v_q8[..copy_len]);

        let old_seq_len = self.seq_len;
        self.seq_len += new_seq_len;

        Ok(old_seq_len)
    }

    #[cfg(not(feature = "cuda"))]
    pub fn append(&mut self, k: &Tensor, v: &Tensor) -> Result<usize> {
        let (_b_sz, _n_kv_heads, new_seq_len, _head_dim) = k.dims4()?;
        let old_seq_len = self.seq_len;
        self.seq_len += new_seq_len;
        Ok(old_seq_len)
    }

    /// Get K cache data as GPU tensor for flash attention
    #[cfg(feature = "cuda")]
    pub fn k_tensor(&self) -> Result<Tensor> {
        if self.seq_len == 0 {
            candle_core::bail!("KV cache is empty");
        }

        let n_blocks = self.head_dim / QK8_0;
        let bytes_per_seq = self.n_kv_heads * n_blocks * BLOCK_Q8_0_SIZE;
        let total_bytes = self.seq_len * bytes_per_seq;

        // Create tensor from raw bytes
        Tensor::from_slice(&self.k_data[..total_bytes], (total_bytes,), &self.device)
    }

    /// Get V cache data as GPU tensor for flash attention
    #[cfg(feature = "cuda")]
    pub fn v_tensor(&self) -> Result<Tensor> {
        if self.seq_len == 0 {
            candle_core::bail!("KV cache is empty");
        }

        let n_blocks = self.head_dim / QK8_0;
        let bytes_per_seq = self.n_kv_heads * n_blocks * BLOCK_Q8_0_SIZE;
        let total_bytes = self.seq_len * bytes_per_seq;

        Tensor::from_slice(&self.v_data[..total_bytes], (total_bytes,), &self.device)
    }

    /// Get current sequence length
    pub fn current_seq_len(&self) -> usize {
        self.seq_len
    }

    /// Reset the cache
    pub fn reset(&mut self) {
        self.seq_len = 0;
        // Optionally zero out data
    }
}

/// Quantize a FP16 tensor to Q8_0 format
///
/// # Arguments
/// * `x` - Input tensor, must have last dimension divisible by 32
///
/// # Returns
/// Raw Q8_0 data as bytes
#[cfg(feature = "cuda")]
pub fn quantize_q8_0(x: &Tensor) -> Result<Vec<u8>> {
    use candle_core::cuda_backend::cudarc::driver::LaunchConfig;
    use candle_core::cuda_backend::WrapErr;

    let device = match x.device() {
        Device::Cuda(dev) => dev,
        _ => candle_core::bail!("quantize_q8_0 requires CUDA tensor"),
    };

    let cuda_dev = device.cuda_device();
    let device_id = device.ordinal();
    ensure_quantize_q8_loaded(&cuda_dev, device_id)?;

    let x_f16 = x.to_dtype(DType::F16)?.contiguous()?;
    let n_elements = x_f16.elem_count();
    let n_blocks = n_elements / QK8_0;

    // Allocate output buffer
    let output_bytes = n_blocks * BLOCK_Q8_0_SIZE;
    let output = unsafe { cuda_dev.alloc::<u8>(output_bytes).w()? };

    let x_ptr = {
        let storage = x_f16.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<half::f16>()?.device_ptr(),
            _ => candle_core::bail!("not a CUDA tensor"),
        }
    };

    let func = cuda_dev
        .get_func("quantize_q8", "quantize_q8_0_kernel")
        .ok_or_else(|| candle_core::Error::Msg("quantize_q8_0_kernel not found".into()))?;

    let block_size = 256u32;
    let grid_size = (n_blocks as u32 + block_size - 1) / block_size;
    let cfg = LaunchConfig {
        grid_dim: (grid_size, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: 0,
    };

    let params = (x_ptr, &output, n_blocks as i32);
    unsafe { func.launch(cfg, params) }.w()?;

    // Copy result to CPU
    let mut result = vec![0u8; output_bytes];
    cuda_dev.dtoh_sync_copy_into(&output, &mut result).w()?;

    Ok(result)
}

#[cfg(not(feature = "cuda"))]
pub fn quantize_q8_0(x: &Tensor) -> Result<Vec<u8>> {
    // CPU fallback implementation
    let x_f32 = x.to_dtype(DType::F32)?.flatten_all()?;
    let data: Vec<f32> = x_f32.to_vec1()?;
    let n_blocks = data.len() / QK8_0;

    let mut result = vec![0u8; n_blocks * BLOCK_Q8_0_SIZE];

    for block_idx in 0..n_blocks {
        let block_data = &data[block_idx * QK8_0..(block_idx + 1) * QK8_0];

        // Find max absolute value
        let amax = block_data.iter().map(|x| x.abs()).fold(0.0f32, f32::max);

        // Compute scale
        let d = amax / 127.0;
        let id = if d != 0.0 { 127.0 / amax } else { 0.0 };

        // Write scale as f16
        let d_f16 = half::f16::from_f32(d);
        let block_offset = block_idx * BLOCK_Q8_0_SIZE;
        result[block_offset..block_offset + 2].copy_from_slice(&d_f16.to_le_bytes());

        // Quantize values
        for i in 0..QK8_0 {
            let q = (block_data[i] * id).round().clamp(-127.0, 127.0) as i8;
            result[block_offset + 2 + i] = q as u8;
        }
    }

    Ok(result)
}

/// Dequantize Q8_0 data back to FP16
#[cfg(feature = "cuda")]
pub fn dequantize_q8_0(data: &[u8], device: &Device) -> Result<Tensor> {
    use candle_core::cuda_backend::cudarc::driver::LaunchConfig;
    use candle_core::cuda_backend::WrapErr;

    let cuda_device = match device {
        Device::Cuda(dev) => dev,
        _ => candle_core::bail!("dequantize_q8_0 requires CUDA device"),
    };

    let cuda_dev = cuda_device.cuda_device();
    let device_id = cuda_device.ordinal();
    ensure_quantize_q8_loaded(&cuda_dev, device_id)?;

    let n_blocks = data.len() / BLOCK_Q8_0_SIZE;
    let n_elements = n_blocks * QK8_0;

    // Upload data to GPU
    let input = cuda_dev.htod_sync_copy(data).w()?;

    // Allocate output
    let output = unsafe { cuda_dev.alloc::<half::f16>(n_elements).w()? };

    let func = cuda_dev
        .get_func("quantize_q8", "dequantize_q8_0_kernel")
        .ok_or_else(|| candle_core::Error::Msg("dequantize_q8_0_kernel not found".into()))?;

    let block_size = 256u32;
    let grid_size = (n_blocks as u32 + block_size - 1) / block_size;
    let cfg = LaunchConfig {
        grid_dim: (grid_size, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: 0,
    };

    let params = (&input, &output, n_blocks as i32);
    unsafe { func.launch(cfg, params) }.w()?;

    // Create tensor from output
    let shape = candle_core::Shape::from_dims(&[n_elements]);

    // This is a simplified version - proper implementation would use from_raw_storage
    let mut result = vec![half::f16::ZERO; n_elements];
    cuda_dev.dtoh_sync_copy_into(&output, &mut result).w()?;

    Tensor::from_vec(result, shape, device)
}

#[cfg(not(feature = "cuda"))]
pub fn dequantize_q8_0(data: &[u8], device: &Device) -> Result<Tensor> {
    let n_blocks = data.len() / BLOCK_Q8_0_SIZE;
    let n_elements = n_blocks * QK8_0;

    let mut result = vec![0.0f32; n_elements];

    for block_idx in 0..n_blocks {
        let block_offset = block_idx * BLOCK_Q8_0_SIZE;

        // Read scale
        let d_bytes = [data[block_offset], data[block_offset + 1]];
        let d = half::f16::from_le_bytes(d_bytes).to_f32();

        // Dequantize values
        for i in 0..QK8_0 {
            let q = data[block_offset + 2 + i] as i8;
            result[block_idx * QK8_0 + i] = q as f32 * d;
        }
    }

    Tensor::from_vec(result, (n_elements,), device)
}

/// Flash Attention decode with GPU-resident Q8_0 KV cache (FAST)
///
/// This version avoids CPU-GPU transfers by using KVCacheQ8Gpu.
///
/// # Arguments
/// * `q` - Query tensor [batch, n_heads, 1, head_dim] FP16
/// * `kv_cache` - GPU-resident Q8_0 quantized KV cache
/// * `scale` - Attention scale (typically 1/sqrt(head_dim))
///
/// # Returns
/// Output tensor [batch, n_heads, 1, head_dim] F32
#[cfg(feature = "cuda")]
pub fn flash_attention_q8_gpu(q: &Tensor, kv_cache: &KVCacheQ8Gpu, scale: f32) -> Result<Tensor> {
    use candle_core::cuda_backend::cudarc::driver::LaunchConfig;
    use candle_core::cuda_backend::WrapErr;

    let device = match q.device() {
        Device::Cuda(dev) => dev,
        _ => candle_core::bail!("flash_attention_q8_gpu requires CUDA tensor"),
    };

    let cuda_dev = device.cuda_device();
    let device_id = device.ordinal();
    ensure_quantize_q8_loaded(&cuda_dev, device_id)?;

    let (b_sz, n_heads, seq_len, head_dim) = q.dims4()?;
    assert_eq!(
        seq_len, 1,
        "flash_attention_q8_gpu only supports decode (seq_len=1)"
    );
    assert_eq!(head_dim, kv_cache.head_dim, "head_dim mismatch");

    let kv_seq_len = kv_cache.seq_len;
    if kv_seq_len == 0 {
        candle_core::bail!("KV cache is empty");
    }

    // Debug: log attention parameters for troubleshooting
    tracing::debug!(
        "flash_attention_q8_gpu: n_heads={}, n_kv_heads={}, kv_seq_len={}, head_dim={}",
        n_heads,
        kv_cache.n_kv_heads,
        kv_seq_len,
        head_dim
    );

    // Flatten Q for kernel
    let q_f16 = q.to_dtype(DType::F16)?.contiguous()?;

    // Allocate output as a proper Tensor (stays on GPU, no copy!)
    let output = Tensor::zeros(
        (b_sz, n_heads, head_dim),
        DType::F16,
        &Device::Cuda(device.clone()),
    )?;
    let out_ptr = {
        let storage = output.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<half::f16>()?.device_ptr(),
            _ => candle_core::bail!("output not on CUDA"),
        }
    };

    let q_ptr = {
        let storage = q_f16.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<half::f16>()?.device_ptr(),
            _ => candle_core::bail!("not a CUDA tensor"),
        }
    };

    let func = cuda_dev
        .get_func("quantize_q8", "flash_attention_decode_q8")
        .ok_or_else(|| candle_core::Error::Msg("flash_attention_decode_q8 not found".into()))?;

    // Shared memory: Q_q8[head_dim] + Q_scales[blocks] + scores[seq_len] + workspace[8]
    let n_blocks = head_dim / QK8_0;
    let shared_mem = head_dim + n_blocks * 4 + kv_seq_len * 4 + 32;

    let block_size = 256u32;
    let cfg = LaunchConfig {
        grid_dim: (n_heads as u32, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: shared_mem as u32,
    };

    // Use GPU pointers directly (no CPU-GPU transfer!)
    let k_ptr = kv_cache.k_ptr();
    let v_ptr = kv_cache.v_ptr();

    let params = (
        q_ptr,
        k_ptr,
        v_ptr,
        out_ptr,
        scale,
        n_heads as i32,
        kv_cache.n_kv_heads as i32,
        kv_seq_len as i32,
        head_dim as i32,
    );

    unsafe { func.launch(cfg, params) }.w()?;

    // Reshape to [batch, n_heads, 1, head_dim] and convert to F32
    // No GPU->CPU transfer - everything stays on GPU!
    let output = output.unsqueeze(2)?;
    output.to_dtype(DType::F32)
}

/// Flash Attention decode with Q8_0 quantized KV cache (legacy CPU version)
///
/// # Arguments
/// * `q` - Query tensor [batch, n_heads, 1, head_dim] FP16
/// * `kv_cache` - Q8_0 quantized KV cache
/// * `scale` - Attention scale (typically 1/sqrt(head_dim))
///
/// # Returns
/// Output tensor [batch, n_heads, 1, head_dim] FP16
#[cfg(feature = "cuda")]
pub fn flash_attention_q8(q: &Tensor, kv_cache: &KVCacheQ8, scale: f32) -> Result<Tensor> {
    use candle_core::cuda_backend::cudarc::driver::LaunchConfig;
    use candle_core::cuda_backend::WrapErr;

    let device = match q.device() {
        Device::Cuda(dev) => dev,
        _ => candle_core::bail!("flash_attention_q8 requires CUDA tensor"),
    };

    let cuda_dev = device.cuda_device();
    let device_id = device.ordinal();
    ensure_quantize_q8_loaded(&cuda_dev, device_id)?;

    let (b_sz, n_heads, seq_len, head_dim) = q.dims4()?;
    assert_eq!(
        seq_len, 1,
        "flash_attention_q8 only supports decode (seq_len=1)"
    );
    assert_eq!(head_dim, kv_cache.head_dim, "head_dim mismatch");

    let kv_seq_len = kv_cache.seq_len;
    if kv_seq_len == 0 {
        candle_core::bail!("KV cache is empty");
    }

    // Flatten Q for kernel
    let q_f16 = q.to_dtype(DType::F16)?.contiguous()?;

    // Get K and V as GPU buffers
    let k_bytes =
        &kv_cache.k_data[..kv_seq_len * kv_cache.n_kv_heads * (head_dim / QK8_0) * BLOCK_Q8_0_SIZE];
    let v_bytes =
        &kv_cache.v_data[..kv_seq_len * kv_cache.n_kv_heads * (head_dim / QK8_0) * BLOCK_Q8_0_SIZE];

    let k_gpu = cuda_dev.htod_sync_copy(k_bytes).w()?;
    let v_gpu = cuda_dev.htod_sync_copy(v_bytes).w()?;

    // Allocate output
    let output_len = b_sz * n_heads * head_dim;
    let output = unsafe { cuda_dev.alloc::<half::f16>(output_len).w()? };

    let q_ptr = {
        let storage = q_f16.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<half::f16>()?.device_ptr(),
            _ => candle_core::bail!("not a CUDA tensor"),
        }
    };

    let func = cuda_dev
        .get_func("quantize_q8", "flash_attention_decode_q8")
        .ok_or_else(|| candle_core::Error::Msg("flash_attention_decode_q8 not found".into()))?;

    // Shared memory: Q_q8[head_dim] + Q_scales[blocks] + scores[seq_len] + workspace[8]
    let n_blocks = head_dim / QK8_0;
    let shared_mem = head_dim + n_blocks * 4 + kv_seq_len * 4 + 32;

    let block_size = 256u32;
    let cfg = LaunchConfig {
        grid_dim: (n_heads as u32, 1, 1),
        block_dim: (block_size, 1, 1),
        shared_mem_bytes: shared_mem as u32,
    };

    let k_ptr = *k_gpu.device_ptr();
    let v_ptr = *v_gpu.device_ptr();
    let out_ptr = *output.device_ptr();

    let params = (
        q_ptr,
        k_ptr,
        v_ptr,
        out_ptr,
        scale,
        n_heads as i32,
        kv_cache.n_kv_heads as i32,
        kv_seq_len as i32,
        head_dim as i32,
    );

    unsafe { func.launch(cfg, params) }.w()?;

    // Create output tensor
    let mut result = vec![half::f16::ZERO; output_len];
    cuda_dev.dtoh_sync_copy_into(&output, &mut result).w()?;

    let output_tensor = Tensor::from_vec(result, (b_sz, n_heads, 1, head_dim), q.device())?;
    Ok(output_tensor)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_quantize_dequantize_cpu() {
        let device = Device::Cpu;
        let data: Vec<f32> = (0..64).map(|i| (i as f32 - 32.0) / 10.0).collect();
        let tensor = Tensor::from_vec(data.clone(), (64,), &device).unwrap();

        // Quantize
        let q8_data = quantize_q8_0(&tensor).unwrap();
        assert_eq!(q8_data.len(), 2 * BLOCK_Q8_0_SIZE); // 2 blocks

        // Dequantize
        let recovered = dequantize_q8_0(&q8_data, &device).unwrap();
        let recovered_data: Vec<f32> = recovered.to_vec1().unwrap();

        // Check approximate equality (quantization introduces some error)
        for (orig, rec) in data.iter().zip(recovered_data.iter()) {
            let error = (orig - rec).abs();
            assert!(error < 0.1, "Large quantization error: {} vs {}", orig, rec);
        }
    }
}
