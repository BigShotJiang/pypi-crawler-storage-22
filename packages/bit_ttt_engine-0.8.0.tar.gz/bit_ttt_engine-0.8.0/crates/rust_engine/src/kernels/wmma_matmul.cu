/**
 * WMMA (Tensor Core) Matrix Multiplication for 4-bit Quantized Weights
 * 
 * Target: NVIDIA Ampere (SM 8.0+), tested on RTX 3070 (SM 8.6)
 * 
 * Strategy:
 * 1. Load Q4_0 weights and dequantize to FP16 in shared memory
 * 2. Load FP16 input to shared memory
 * 3. Use WMMA (Tensor Core) for fast matrix multiplication
 * 
 * Reference: llama.cpp ggml-cuda/mma.cuh, mmq.cuh
 */

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <mma.h>
#include <stdint.h>

using namespace nvcuda;

// ============================================================================
// Configuration
// ============================================================================

// WMMA tile dimensions (16x16x16 for FP16 on Ampere)
#define WMMA_M 16
#define WMMA_N 16
#define WMMA_K 16

// Block configuration - adjusted for correct coverage
#define BLOCK_SIZE 256          // Threads per block (8 warps)
#define WARPS_PER_BLOCK 8
#define WARP_SIZE 32

// Tile sizes for shared memory
// 8 warps in 2x4 arrangement: 2*16=32 (M) x 4*16=64 (N)
#define TILE_M 32               // Output tile M dimension
#define TILE_N 64               // Output tile N dimension  
#define TILE_K 32               // K dimension per iteration

// Q4_0 quantization parameters
#define QK4_0 32                // Block size for Q4_0

// ============================================================================
// Helper Functions
// ============================================================================

// Unpack 4-bit value with -8 offset (matches Python packing)
__device__ __forceinline__ half unpack_4bit_to_half(uint8_t packed, int idx) {
    int val;
    if (idx == 0) {
        val = (int)(packed & 0x0F) - 8;
    } else {
        val = (int)((packed >> 4) & 0x0F) - 8;
    }
    return __float2half((float)val);
}

// ============================================================================
// WMMA Kernels
// ============================================================================

/**
 * Basic WMMA GEMM Kernel (FP16 input, FP32 accumulator)
 * 
 * Computes: Y = X @ W^T
 * 
 * @param X       Input [batch, in_dim] FP16
 * @param W       Weights [out_dim, in_dim] FP16 (pre-dequantized for testing)
 * @param Y       Output [batch, out_dim] FP32
 */
extern "C" __global__ void wmma_gemm_fp16_basic(
    const half* __restrict__ X,     // [M, K] row-major
    const half* __restrict__ W,     // [N, K] row-major (W^T is [K, N] col-major)
    float* __restrict__ Y,          // [M, N] row-major
    int M, int N, int K
) {
    // Bs is transposed: [N][K] layout for col_major WMMA access
    __shared__ half As[TILE_M][TILE_K + 8];
    __shared__ half Bs[TILE_N][TILE_K + 8];  // Changed for col_major access
    
    const int warpId = threadIdx.x / WARP_SIZE;
    
    const int blockM = blockIdx.y * TILE_M;
    const int blockN = blockIdx.x * TILE_N;
    
    const int warpM = (warpId / 4) * WMMA_M;
    const int warpN = (warpId % 4) * WMMA_N;
    
    wmma::fragment<wmma::matrix_a, WMMA_M, WMMA_N, WMMA_K, half, wmma::row_major> a_frag;
    wmma::fragment<wmma::matrix_b, WMMA_M, WMMA_N, WMMA_K, half, wmma::col_major> b_frag;
    wmma::fragment<wmma::accumulator, WMMA_M, WMMA_N, WMMA_K, float> c_frag;
    
    wmma::fill_fragment(c_frag, 0.0f);
    
    for (int k = 0; k < K; k += TILE_K) {
        // Load A tile
        #pragma unroll
        for (int i = threadIdx.x; i < TILE_M * TILE_K; i += BLOCK_SIZE) {
            int row = i / TILE_K;
            int col = i % TILE_K;
            int globalRow = blockM + row;
            int globalCol = k + col;
            
            if (globalRow < M && globalCol < K) {
                As[row][col] = X[globalRow * K + globalCol];
            } else {
                As[row][col] = __float2half(0.0f);
            }
        }
        
        // Load B tile (transposed: Bs[nn][kk])
        #pragma unroll
        for (int i = threadIdx.x; i < TILE_K * TILE_N; i += BLOCK_SIZE) {
            int kk = i / TILE_N;
            int nn = i % TILE_N;
            int globalK = k + kk;
            int globalN = blockN + nn;
            
            if (globalK < K && globalN < N) {
                // W is [N, K], store transposed into Bs[N][K]
                Bs[nn][kk] = W[globalN * K + globalK];
            } else {
                Bs[nn][kk] = __float2half(0.0f);
            }
        }
        
        __syncthreads();
        
        #pragma unroll
        for (int kk = 0; kk < TILE_K; kk += WMMA_K) {
            wmma::load_matrix_sync(a_frag, &As[warpM][kk], TILE_K + 8);
            wmma::load_matrix_sync(b_frag, &Bs[warpN][kk], TILE_K + 8);
            wmma::mma_sync(c_frag, a_frag, b_frag, c_frag);
        }
        
        __syncthreads();
    }
    
    int outRow = blockM + warpM;
    int outCol = blockN + warpN;
    
    if (outRow < M && outCol < N) {
        wmma::store_matrix_sync(&Y[outRow * N + outCol], c_frag, N, wmma::mem_row_major);
    }
}

/**
 * WMMA GEMM with Q4_0 Dequantization Fused
 * 
 * Computes: Y = X @ dequant(W_q4)^T
 * 
 * @param X           Input [batch, in_dim] FP16
 * @param W_packed    Packed Q4_0 weights [out_dim, in_dim/2] U8
 * @param W_scales    Scales [out_dim, in_dim/QK4_0] FP16
 * @param Y           Output [batch, out_dim] FP32
 */
extern "C" __global__ void wmma_gemm_q4_0_fused(
    const half* __restrict__ X,             // [M, K] row-major FP16
    const uint8_t* __restrict__ W_packed,   // [N, K/2] row-major U8
    const half* __restrict__ W_scales,      // [N, K/QK4_0] row-major FP16
    float* __restrict__ Y,                  // [M, N] row-major FP32
    int M, int N, int K
) {
    __shared__ half As[TILE_M][TILE_K + 8];
    __shared__ half Bs[TILE_N][TILE_K + 8];  // Changed for col_major access
    
    const int warpId = threadIdx.x / WARP_SIZE;
    
    const int blockM = blockIdx.y * TILE_M;
    const int blockN = blockIdx.x * TILE_N;
    
    const int warpM = (warpId / 4) * WMMA_M;
    const int warpN = (warpId % 4) * WMMA_N;
    
    wmma::fragment<wmma::matrix_a, WMMA_M, WMMA_N, WMMA_K, half, wmma::row_major> a_frag;
    wmma::fragment<wmma::matrix_b, WMMA_M, WMMA_N, WMMA_K, half, wmma::col_major> b_frag;
    wmma::fragment<wmma::accumulator, WMMA_M, WMMA_N, WMMA_K, float> c_frag;
    
    wmma::fill_fragment(c_frag, 0.0f);
    
    const int n_groups = K / QK4_0;
    const int packed_k = K / 2;
    
    for (int k = 0; k < K; k += TILE_K) {
        // Load A tile
        #pragma unroll
        for (int i = threadIdx.x; i < TILE_M * TILE_K; i += BLOCK_SIZE) {
            int row = i / TILE_K;
            int col = i % TILE_K;
            int globalRow = blockM + row;
            int globalCol = k + col;
            
            if (globalRow < M && globalCol < K) {
                As[row][col] = X[globalRow * K + globalCol];
            } else {
                As[row][col] = __float2half(0.0f);
            }
        }
        
        // Load and dequantize B tile (transposed)
        #pragma unroll
        for (int i = threadIdx.x; i < TILE_K * TILE_N; i += BLOCK_SIZE) {
            int kk = i / TILE_N;
            int nn = i % TILE_N;
            int globalK = k + kk;
            int globalN = blockN + nn;
            
            if (globalK < K && globalN < N) {
                int packed_idx = globalK / 2;
                int is_high = globalK % 2;
                int group_idx = globalK / QK4_0;
                
                uint8_t packed = W_packed[globalN * packed_k + packed_idx];
                half scale = W_scales[globalN * n_groups + group_idx];
                
                int val = is_high ? ((packed >> 4) & 0x0F) - 8 : (packed & 0x0F) - 8;
                Bs[nn][kk] = __hmul(__float2half((float)val), scale);  // Transposed
            } else {
                Bs[nn][kk] = __float2half(0.0f);
            }
        }
        
        __syncthreads();
        
        #pragma unroll
        for (int kk = 0; kk < TILE_K; kk += WMMA_K) {
            wmma::load_matrix_sync(a_frag, &As[warpM][kk], TILE_K + 8);
            wmma::load_matrix_sync(b_frag, &Bs[warpN][kk], TILE_K + 8);
            wmma::mma_sync(c_frag, a_frag, b_frag, c_frag);
        }
        
        __syncthreads();
    }
    
    int outRow = blockM + warpM;
    int outCol = blockN + warpN;
    
    if (outRow < M && outCol < N) {
        wmma::store_matrix_sync(&Y[outRow * N + outCol], c_frag, N, wmma::mem_row_major);
    }
}

/**
 * Optimized WMMA GEMM with Double Buffering
 */
extern "C" __global__ void wmma_gemm_q4_0_double_buffer(
    const half* __restrict__ X,
    const uint8_t* __restrict__ W_packed,
    const half* __restrict__ W_scales,
    float* __restrict__ Y,
    int M, int N, int K
) {
    __shared__ half As[2][TILE_M][TILE_K + 8];
    __shared__ half Bs[2][TILE_N][TILE_K + 8];  // Changed for col_major
    
    const int warpId = threadIdx.x / WARP_SIZE;
    const int blockM = blockIdx.y * TILE_M;
    const int blockN = blockIdx.x * TILE_N;
    const int warpM = (warpId / 4) * WMMA_M;
    const int warpN = (warpId % 4) * WMMA_N;
    
    wmma::fragment<wmma::matrix_a, WMMA_M, WMMA_N, WMMA_K, half, wmma::row_major> a_frag;
    wmma::fragment<wmma::matrix_b, WMMA_M, WMMA_N, WMMA_K, half, wmma::col_major> b_frag;
    wmma::fragment<wmma::accumulator, WMMA_M, WMMA_N, WMMA_K, float> c_frag;
    
    wmma::fill_fragment(c_frag, 0.0f);
    
    const int n_groups = K / QK4_0;
    const int packed_k = K / 2;
    
    int stage = 0;
    
    // Prefetch first tile
    #pragma unroll
    for (int i = threadIdx.x; i < TILE_M * TILE_K; i += BLOCK_SIZE) {
        int row = i / TILE_K;
        int col = i % TILE_K;
        int globalRow = blockM + row;
        int globalCol = col;
        
        if (globalRow < M && globalCol < K) {
            As[0][row][col] = X[globalRow * K + globalCol];
        } else {
            As[0][row][col] = __float2half(0.0f);
        }
    }
    
    #pragma unroll
    for (int i = threadIdx.x; i < TILE_K * TILE_N; i += BLOCK_SIZE) {
        int kk = i / TILE_N;
        int nn = i % TILE_N;
        int globalK = kk;
        int globalN = blockN + nn;
        
        if (globalK < K && globalN < N) {
            int packed_idx = globalK / 2;
            int is_high = globalK % 2;
            int group_idx = globalK / QK4_0;
            
            uint8_t packed = W_packed[globalN * packed_k + packed_idx];
            half scale = W_scales[globalN * n_groups + group_idx];
            int val = is_high ? ((packed >> 4) & 0x0F) - 8 : (packed & 0x0F) - 8;
            Bs[0][nn][kk] = __hmul(__float2half((float)val), scale);  // Transposed
        } else {
            Bs[0][nn][kk] = __float2half(0.0f);
        }
    }
    
    __syncthreads();
    
    for (int k = 0; k < K; k += TILE_K) {
        int next_k = k + TILE_K;
        int next_stage = 1 - stage;
        
        // Prefetch next tile
        if (next_k < K) {
            #pragma unroll
            for (int i = threadIdx.x; i < TILE_M * TILE_K; i += BLOCK_SIZE) {
                int row = i / TILE_K;
                int col = i % TILE_K;
                int globalRow = blockM + row;
                int globalCol = next_k + col;
                
                if (globalRow < M && globalCol < K) {
                    As[next_stage][row][col] = X[globalRow * K + globalCol];
                } else {
                    As[next_stage][row][col] = __float2half(0.0f);
                }
            }
            
            #pragma unroll
            for (int i = threadIdx.x; i < TILE_K * TILE_N; i += BLOCK_SIZE) {
                int kk = i / TILE_N;
                int nn = i % TILE_N;
                int globalK = next_k + kk;
                int globalN = blockN + nn;
                
                if (globalK < K && globalN < N) {
                    int packed_idx = globalK / 2;
                    int is_high = globalK % 2;
                    int group_idx = globalK / QK4_0;
                    
                    uint8_t packed = W_packed[globalN * packed_k + packed_idx];
                    half scale = W_scales[globalN * n_groups + group_idx];
                    int val = is_high ? ((packed >> 4) & 0x0F) - 8 : (packed & 0x0F) - 8;
                    Bs[next_stage][nn][kk] = __hmul(__float2half((float)val), scale);  // Transposed
                } else {
                    Bs[next_stage][nn][kk] = __float2half(0.0f);
                }
            }
        }
        
        // Compute current tile
        #pragma unroll
        for (int kk = 0; kk < TILE_K; kk += WMMA_K) {
            wmma::load_matrix_sync(a_frag, &As[stage][warpM][kk], TILE_K + 8);
            wmma::load_matrix_sync(b_frag, &Bs[stage][warpN][kk], TILE_K + 8);
            wmma::mma_sync(c_frag, a_frag, b_frag, c_frag);
        }
        
        __syncthreads();
        stage = next_stage;
    }
    
    int outRow = blockM + warpM;
    int outCol = blockN + warpN;
    
    if (outRow < M && outCol < N) {
        wmma::store_matrix_sync(&Y[outRow * N + outCol], c_frag, N, wmma::mem_row_major);
    }
}

/**
 * WMMA GEMM with FP32 input (converts to FP16 internally)
 * 
 * Fixed: Bs is now [TILE_N][TILE_K+8] to match col_major access pattern
 */
extern "C" __global__ void wmma_gemm_q4_0_f32_input(
    const float* __restrict__ X,            // [M, K] row-major FP32
    const uint8_t* __restrict__ W_packed,   // [N, K/2] row-major U8
    const float* __restrict__ W_scales,     // [N, K/QK4_0] row-major FP32
    float* __restrict__ Y,                  // [M, N] row-major FP32
    int M, int N, int K
) {
    // Bs is transposed: [N][K] layout for col_major WMMA access
    __shared__ half As[TILE_M][TILE_K + 8];
    __shared__ half Bs[TILE_N][TILE_K + 8];  // Changed from [TILE_K][TILE_N+8]
    
    const int warpId = threadIdx.x / WARP_SIZE;
    const int blockM = blockIdx.y * TILE_M;
    const int blockN = blockIdx.x * TILE_N;
    const int warpM = (warpId / 4) * WMMA_M;
    const int warpN = (warpId % 4) * WMMA_N;
    
    wmma::fragment<wmma::matrix_a, WMMA_M, WMMA_N, WMMA_K, half, wmma::row_major> a_frag;
    wmma::fragment<wmma::matrix_b, WMMA_M, WMMA_N, WMMA_K, half, wmma::col_major> b_frag;
    wmma::fragment<wmma::accumulator, WMMA_M, WMMA_N, WMMA_K, float> c_frag;
    
    wmma::fill_fragment(c_frag, 0.0f);
    
    const int n_groups = K / QK4_0;
    const int packed_k = K / 2;
    
    for (int k = 0; k < K; k += TILE_K) {
        // Load A tile with FP32 -> FP16 conversion
        #pragma unroll
        for (int i = threadIdx.x; i < TILE_M * TILE_K; i += BLOCK_SIZE) {
            int row = i / TILE_K;
            int col = i % TILE_K;
            int globalRow = blockM + row;
            int globalCol = k + col;
            
            if (globalRow < M && globalCol < K) {
                As[row][col] = __float2half(X[globalRow * K + globalCol]);
            } else {
                As[row][col] = __float2half(0.0f);
            }
        }
        
        // Load and dequantize B tile (transposed: Bs[nn][kk])
        #pragma unroll
        for (int i = threadIdx.x; i < TILE_K * TILE_N; i += BLOCK_SIZE) {
            int kk = i / TILE_N;
            int nn = i % TILE_N;
            int globalK = k + kk;
            int globalN = blockN + nn;
            
            if (globalK < K && globalN < N) {
                int packed_idx = globalK / 2;
                int is_high = globalK % 2;
                int group_idx = globalK / QK4_0;
                
                uint8_t packed = W_packed[globalN * packed_k + packed_idx];
                float scale = W_scales[globalN * n_groups + group_idx];
                int val = is_high ? ((packed >> 4) & 0x0F) - 8 : (packed & 0x0F) - 8;
                // Store transposed: Bs[N][K] instead of Bs[K][N]
                Bs[nn][kk] = __float2half((float)val * scale);
            } else {
                Bs[nn][kk] = __float2half(0.0f);
            }
        }
        
        __syncthreads();
        
        #pragma unroll
        for (int kk = 0; kk < TILE_K; kk += WMMA_K) {
            wmma::load_matrix_sync(a_frag, &As[warpM][kk], TILE_K + 8);
            // Load from Bs[warpN][kk] with stride (TILE_K + 8)
            wmma::load_matrix_sync(b_frag, &Bs[warpN][kk], TILE_K + 8);
            wmma::mma_sync(c_frag, a_frag, b_frag, c_frag);
        }
        
        __syncthreads();
    }
    
    int outRow = blockM + warpM;
    int outCol = blockN + warpN;
    
    if (outRow < M && outCol < N) {
        wmma::store_matrix_sync(&Y[outRow * N + outCol], c_frag, N, wmma::mem_row_major);
    }
}
