//! WMMA (Tensor Core) Matrix Multiplication Kernels
//!
//! Provides GPU-accelerated matrix multiplication using Tensor Cores (WMMA).
//! Significantly faster than standard CUDA cores for supported operations.
//!
//! # Kernel Variants
//! - `wmma_gemm_fp16_basic`: Basic FP16 WMMA (for testing)
//! - `wmma_gemm_q4_0_fused`: Q4_0 dequantize + WMMA fused
//! - `wmma_gemm_q4_0_double_buffer`: Double-buffered for overlapped loads
//! - `wmma_gemm_q4_0_f32_input`: FP32 input with internal FP16 conversion
//!
//! # Requirements
//! - NVIDIA GPU with Tensor Cores (SM 7.0+, recommended SM 8.0+)
//! - CUDA feature enabled
//!
//! # Usage
//! ```ignore
//! // Automatically selected when beneficial
//! let output = gemm_4bit_wmma(&x, &w_packed, &scales, group_size)?;
//! ```

#[cfg(feature = "cuda")]
use candle_core::cuda_backend::cudarc::driver::{DevicePtr, LaunchAsync, LaunchConfig};
#[cfg(feature = "cuda")]
use candle_core::cuda_backend::WrapErr;
#[cfg(feature = "cuda")]
use candle_core::Device;
use candle_core::{Result, Tensor};

#[cfg(feature = "cuda")]
use std::sync::OnceLock;

#[cfg(feature = "cuda")]
const WMMA_MATMUL_PTX: &str = include_str!(concat!(env!("OUT_DIR"), "/wmma_matmul.ptx"));

/// Track which devices have loaded the WMMA PTX module
#[cfg(feature = "cuda")]
static WMMA_PTX_LOADED: OnceLock<std::sync::Mutex<std::collections::HashSet<usize>>> =
    OnceLock::new();

#[cfg(feature = "cuda")]
fn ensure_wmma_loaded(
    cuda_dev: &std::sync::Arc<candle_core::cuda_backend::cudarc::driver::CudaDevice>,
    device_id: usize,
) -> Result<()> {
    let loaded =
        WMMA_PTX_LOADED.get_or_init(|| std::sync::Mutex::new(std::collections::HashSet::new()));
    let mut guard = loaded.lock().unwrap();

    if !guard.contains(&device_id) {
        cuda_dev
            .load_ptx(
                WMMA_MATMUL_PTX.into(),
                "wmma_matmul",
                &[
                    "wmma_gemm_fp16_basic",
                    "wmma_gemm_q4_0_fused",
                    "wmma_gemm_q4_0_double_buffer",
                    "wmma_gemm_q4_0_f32_input",
                ],
            )
            .w()?;
        guard.insert(device_id);
        tracing::info!("Loaded WMMA matmul PTX for device {}", device_id);
    }

    Ok(())
}

/// Minimum dimensions for WMMA to be beneficial
/// Below these sizes, standard CUDA kernels may be faster
pub const WMMA_MIN_M: usize = 16;
pub const WMMA_MIN_N: usize = 16;
pub const WMMA_MIN_K: usize = 32;

/// Check if WMMA should be used for given dimensions
pub fn should_use_wmma(batch: usize, in_dim: usize, out_dim: usize) -> bool {
    batch >= WMMA_MIN_M && in_dim >= WMMA_MIN_K && out_dim >= WMMA_MIN_N
}

/// WMMA-accelerated 4-bit GEMM
///
/// # Arguments
/// - `x`: Input tensor `[batch, in_dim]` (F32)
/// - `w_packed`: Packed weights `[out_dim, in_dim/2]` (U8)
/// - `scales`: Per-group scales `[out_dim, n_groups]` (F32)
/// - `group_size`: Elements per quantization group (typically 32)
///
/// # Returns
/// Output tensor `[batch, out_dim]` (F32)
#[cfg(feature = "cuda")]
pub fn gemm_4bit_wmma(
    x: &Tensor,
    w_packed: &Tensor,
    scales: &Tensor,
    _group_size: usize,
) -> Result<Tensor> {
    let dev = match x.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => {
            return Err(candle_core::Error::Msg(
                "WMMA requires CUDA device".to_string(),
            ))
        }
    };

    // Get dimensions
    let x_dims = x.dims();
    let w_dims = w_packed.dims();

    let (batch, in_dim) = match x_dims {
        [b, k] => (*b, *k),
        [k] => (1, *k),
        _ => return Err(candle_core::Error::Msg("X must be 1D or 2D".to_string())),
    };

    let (out_dim, packed_in) = match w_dims {
        [o, pk] => (*o, *pk),
        _ => return Err(candle_core::Error::Msg("W_packed must be 2D".to_string())),
    };

    // Verify dimensions
    if packed_in * 2 != in_dim {
        return Err(candle_core::Error::Msg(format!(
            "Dimension mismatch: packed_in={} * 2 != in_dim={}",
            packed_in, in_dim
        )));
    }

    // Ensure tensors are on GPU and correct dtype
    let x_f32 = x.to_dtype(candle_core::DType::F32)?;
    let scales_f32 = scales.to_dtype(candle_core::DType::F32)?;

    // Get raw CUDA pointers
    let x_ptr = {
        let storage = x_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("X must be CUDA tensor".to_string())),
        }
    };

    let w_ptr = {
        let storage = w_packed.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<u8>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("W must be CUDA tensor".to_string())),
        }
    };

    let s_ptr = {
        let storage = scales_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Scales must be CUDA tensor".to_string(),
                ))
            }
        }
    };

    // Create output tensor on GPU
    let output = Tensor::zeros(
        (batch, out_dim),
        candle_core::DType::F32,
        &Device::Cuda(dev.clone()),
    )?;

    let out_ptr = {
        let storage = output.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Output allocation failed".to_string(),
                ))
            }
        }
    };

    // Load PTX module (cached per device)
    let cuda_dev = dev.cuda_device();
    let device_id = dev.ordinal();
    ensure_wmma_loaded(&cuda_dev, device_id)?;

    // Tile sizes (must match CUDA kernel)
    const TILE_M: usize = 32;
    const TILE_N: usize = 64;
    const BLOCK_SIZE: u32 = 256;

    // Grid dimensions
    let grid_x = ((out_dim + TILE_N - 1) / TILE_N) as u32;
    let grid_y = ((batch + TILE_M - 1) / TILE_M) as u32;

    let cfg = LaunchConfig {
        grid_dim: (grid_x, grid_y, 1),
        block_dim: (BLOCK_SIZE, 1, 1),
        shared_mem_bytes: 0, // Shared memory is statically allocated
    };

    // Get WMMA kernel function
    let func = cuda_dev
        .get_func("wmma_matmul", "wmma_gemm_q4_0_f32_input")
        .ok_or_else(|| candle_core::Error::Msg("Failed to get WMMA CUDA kernel".to_string()))?;

    let m = batch as i32;
    let n = out_dim as i32;
    let k = in_dim as i32;

    // Launch kernel
    unsafe {
        func.launch(cfg, (x_ptr, w_ptr, s_ptr, out_ptr, m, n, k))
            .w()?;
    }

    Ok(output)
}

/// WMMA-accelerated 4-bit GEMM with double buffering
///
/// Uses double buffering to overlap memory loads with computation.
/// May provide additional speedup for large matrices.
#[cfg(feature = "cuda")]
pub fn gemm_4bit_wmma_double_buffer(
    x: &Tensor,
    w_packed: &Tensor,
    scales: &Tensor,
    _group_size: usize,
) -> Result<Tensor> {
    let dev = match x.device() {
        Device::Cuda(dev) => dev.clone(),
        _ => {
            return Err(candle_core::Error::Msg(
                "WMMA requires CUDA device".to_string(),
            ))
        }
    };

    let x_dims = x.dims();
    let w_dims = w_packed.dims();

    let (batch, in_dim) = match x_dims {
        [b, k] => (*b, *k),
        [k] => (1, *k),
        _ => return Err(candle_core::Error::Msg("X must be 1D or 2D".to_string())),
    };

    let (out_dim, _packed_in) = match w_dims {
        [o, pk] => (*o, *pk),
        _ => return Err(candle_core::Error::Msg("W_packed must be 2D".to_string())),
    };

    let x_f32 = x.to_dtype(candle_core::DType::F32)?;
    let scales_f32 = scales.to_dtype(candle_core::DType::F32)?;

    let x_ptr = {
        let storage = x_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("X must be CUDA tensor".to_string())),
        }
    };

    let w_ptr = {
        let storage = w_packed.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<u8>()?.device_ptr(),
            _ => return Err(candle_core::Error::Msg("W must be CUDA tensor".to_string())),
        }
    };

    let s_ptr = {
        let storage = scales_f32.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Scales must be CUDA tensor".to_string(),
                ))
            }
        }
    };

    let output = Tensor::zeros(
        (batch, out_dim),
        candle_core::DType::F32,
        &Device::Cuda(dev.clone()),
    )?;

    let out_ptr = {
        let storage = output.storage_and_layout().0;
        match &*storage {
            candle_core::Storage::Cuda(s) => *s.as_cuda_slice::<f32>()?.device_ptr(),
            _ => {
                return Err(candle_core::Error::Msg(
                    "Output allocation failed".to_string(),
                ))
            }
        }
    };

    let cuda_dev = dev.cuda_device();
    let device_id = dev.ordinal();
    ensure_wmma_loaded(&cuda_dev, device_id)?;

    const TILE_M: usize = 32;
    const TILE_N: usize = 64;
    const BLOCK_SIZE: u32 = 256;

    let grid_x = ((out_dim + TILE_N - 1) / TILE_N) as u32;
    let grid_y = ((batch + TILE_M - 1) / TILE_M) as u32;

    let cfg = LaunchConfig {
        grid_dim: (grid_x, grid_y, 1),
        block_dim: (BLOCK_SIZE, 1, 1),
        shared_mem_bytes: 0,
    };

    let func = cuda_dev
        .get_func("wmma_matmul", "wmma_gemm_q4_0_double_buffer")
        .ok_or_else(|| candle_core::Error::Msg("Failed to get WMMA CUDA kernel".to_string()))?;

    let m = batch as i32;
    let n = out_dim as i32;
    let k = in_dim as i32;

    unsafe {
        func.launch(cfg, (x_ptr, w_ptr, s_ptr, out_ptr, m, n, k))
            .w()?;
    }

    Ok(output)
}

/// CPU fallback (not implemented - WMMA is CUDA-only)
#[cfg(not(feature = "cuda"))]
pub fn gemm_4bit_wmma(
    _x: &Tensor,
    _w_packed: &Tensor,
    _scales: &Tensor,
    _group_size: usize,
) -> Result<Tensor> {
    Err(candle_core::Error::Msg(
        "WMMA requires CUDA feature".to_string(),
    ))
}

#[cfg(not(feature = "cuda"))]
pub fn gemm_4bit_wmma_double_buffer(
    _x: &Tensor,
    _w_packed: &Tensor,
    _scales: &Tensor,
    _group_size: usize,
) -> Result<Tensor> {
    Err(candle_core::Error::Msg(
        "WMMA requires CUDA feature".to_string(),
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_should_use_wmma() {
        // Should use WMMA for large matrices
        assert!(should_use_wmma(64, 4096, 4096));
        assert!(should_use_wmma(128, 4096, 11008));

        // Should not use WMMA for small matrices
        assert!(!should_use_wmma(1, 4096, 4096)); // batch too small
        assert!(!should_use_wmma(64, 16, 4096)); // in_dim too small
        assert!(!should_use_wmma(64, 4096, 8)); // out_dim too small
    }
}
