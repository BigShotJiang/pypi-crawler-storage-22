//! LoRA (Low-Rank Adaptation) Layer
//!
//! Implements efficient fine-tuning through low-rank weight updates.
//! Instead of updating all weights W, we learn small matrices A and B:
//!
//! ```text
//! W' = W + α * B @ A
//!
//! where:
//!   W: [out_features, in_features] - frozen pretrained weights
//!   A: [rank, in_features]         - learnable down-projection
//!   B: [out_features, rank]        - learnable up-projection
//!   α: scaling factor (typically alpha / rank)
//! ```
//!
//! # Benefits
//! - Parameter efficient: only ~0.1% of original parameters
//! - No inference latency when merged
//! - Can be stacked for multiple adaptations
//!
//! # References
//! - LoRA: Low-Rank Adaptation of Large Language Models (Hu et al., 2021)
//! - https://arxiv.org/abs/2106.09685

use candle_core::{DType, Device, Result, Tensor};
use candle_nn::VarBuilder;
use std::collections::HashMap;

/// LoRA configuration
#[derive(Debug, Clone)]
pub struct LoRAConfig {
    /// Rank of the low-rank matrices (typically 4, 8, 16, or 32)
    pub rank: usize,

    /// Alpha scaling factor (typically same as rank or 2x rank)
    pub alpha: f32,

    /// Dropout probability for LoRA layers (0.0 = no dropout)
    pub dropout: f32,

    /// Which modules to apply LoRA to
    pub target_modules: Vec<String>,
}

impl Default for LoRAConfig {
    fn default() -> Self {
        Self {
            rank: 8,
            alpha: 16.0,
            dropout: 0.0,
            target_modules: vec!["q_proj".to_string(), "v_proj".to_string()],
        }
    }
}

impl LoRAConfig {
    /// Create a new LoRA config with the given rank
    pub fn new(rank: usize) -> Self {
        Self {
            rank,
            alpha: rank as f32 * 2.0,
            ..Default::default()
        }
    }

    /// Apply LoRA to all linear layers
    pub fn all_linear(rank: usize) -> Self {
        Self {
            rank,
            alpha: rank as f32 * 2.0,
            dropout: 0.0,
            target_modules: vec![
                "q_proj".to_string(),
                "k_proj".to_string(),
                "v_proj".to_string(),
                "o_proj".to_string(),
                "gate_proj".to_string(),
                "up_proj".to_string(),
                "down_proj".to_string(),
            ],
        }
    }
}

/// A single LoRA adapter layer
#[derive(Debug, Clone)]
pub struct LoRALayer {
    /// Down-projection matrix A: [rank, in_features]
    pub lora_a: Tensor,

    /// Up-projection matrix B: [out_features, rank]
    pub lora_b: Tensor,

    /// Scaling factor: alpha / rank
    pub scaling: f32,

    /// Input features dimension
    pub in_features: usize,

    /// Output features dimension  
    pub out_features: usize,

    /// Rank
    pub rank: usize,

    /// Whether this layer is enabled
    pub enabled: bool,
}

impl LoRALayer {
    /// Create a new LoRA layer with random initialization
    ///
    /// A is initialized with Kaiming uniform, B is initialized to zero.
    /// This ensures the LoRA contribution starts at zero.
    pub fn new(
        in_features: usize,
        out_features: usize,
        rank: usize,
        alpha: f32,
        device: &Device,
    ) -> Result<Self> {
        // A: Kaiming uniform initialization
        // For rank << in_features, use small random values
        let std = (2.0 / in_features as f64).sqrt() as f32;
        let lora_a = Tensor::randn(0.0f32, std, (rank, in_features), device)?;

        // B: Zero initialization (LoRA starts with no contribution)
        let lora_b = Tensor::zeros((out_features, rank), DType::F32, device)?;

        let scaling = alpha / rank as f32;

        Ok(Self {
            lora_a,
            lora_b,
            scaling,
            in_features,
            out_features,
            rank,
            enabled: true,
        })
    }

    /// Load LoRA weights from a VarBuilder
    pub fn load(
        in_features: usize,
        out_features: usize,
        rank: usize,
        alpha: f32,
        vb: VarBuilder,
    ) -> Result<Self> {
        let lora_a = vb.get((rank, in_features), "lora_A")?;
        let lora_b = vb.get((out_features, rank), "lora_B")?;

        let scaling = alpha / rank as f32;

        Ok(Self {
            lora_a,
            lora_b,
            scaling,
            in_features,
            out_features,
            rank,
            enabled: true,
        })
    }

    /// Forward pass: compute the LoRA contribution
    ///
    /// Returns: scaling * (x @ A^T @ B^T) = scaling * B @ A @ x
    pub fn forward(&self, x: &Tensor) -> Result<Tensor> {
        if !self.enabled {
            // Return zeros with correct output shape
            let mut out_shape = x.dims().to_vec();
            if let Some(last) = out_shape.last_mut() {
                *last = self.out_features;
            }
            return Tensor::zeros(out_shape, x.dtype(), x.device());
        }

        // Convert input to F32 for LoRA computation
        let x_f32 = x.to_dtype(DType::F32)?;

        // x: [..., in_features]
        // A: [rank, in_features]
        // B: [out_features, rank]

        // For 3D input [batch, seq, in], we need to handle matmul carefully
        let original_shape = x_f32.dims().to_vec();
        let in_features = *original_shape.last().unwrap();

        // Flatten to 2D: [batch * seq, in_features]
        let batch_seq: usize = original_shape
            .iter()
            .take(original_shape.len() - 1)
            .product();
        let x_2d = x_f32.reshape((batch_seq, in_features))?;

        // Step 1: x @ A^T -> [batch * seq, rank]
        let h = x_2d.matmul(&self.lora_a.t()?)?;

        // Step 2: h @ B^T -> [batch * seq, out_features]
        let out_2d = h.matmul(&self.lora_b.t()?)?;

        // Reshape back to original batch dimensions
        let mut out_shape = original_shape;
        *out_shape.last_mut().unwrap() = self.out_features;
        let out = out_2d.reshape(out_shape)?;

        // Step 3: Apply scaling and convert back to original dtype
        let scaled = out.affine(self.scaling as f64, 0.0)?;
        scaled.to_dtype(x.dtype())
    }

    /// Merge LoRA into the base weight matrix
    ///
    /// Returns: W + scaling * B @ A
    pub fn merge_into(&self, base_weight: &Tensor) -> Result<Tensor> {
        // base_weight: [out_features, in_features]
        // B @ A: [out_features, rank] @ [rank, in_features] = [out_features, in_features]
        let lora_weight = self.lora_b.matmul(&self.lora_a)?;
        let scaled = lora_weight.affine(self.scaling as f64, 0.0)?;
        base_weight.add(&scaled)
    }

    /// Get the number of trainable parameters
    pub fn num_parameters(&self) -> usize {
        self.rank * self.in_features + self.out_features * self.rank
    }

    /// Enable or disable this LoRA layer
    pub fn set_enabled(&mut self, enabled: bool) {
        self.enabled = enabled;
    }

    /// Convert weights to a specific dtype
    pub fn to_dtype(&self, dtype: DType) -> Result<Self> {
        Ok(Self {
            lora_a: self.lora_a.to_dtype(dtype)?,
            lora_b: self.lora_b.to_dtype(dtype)?,
            scaling: self.scaling,
            in_features: self.in_features,
            out_features: self.out_features,
            rank: self.rank,
            enabled: self.enabled,
        })
    }

    /// Move to a specific device
    pub fn to_device(&self, device: &Device) -> Result<Self> {
        Ok(Self {
            lora_a: self.lora_a.to_device(device)?,
            lora_b: self.lora_b.to_device(device)?,
            scaling: self.scaling,
            in_features: self.in_features,
            out_features: self.out_features,
            rank: self.rank,
            enabled: self.enabled,
        })
    }
}

/// Collection of LoRA adapters for a model
#[derive(Debug, Default)]
pub struct LoRAAdapters {
    /// Map from layer name to LoRA layer
    pub layers: HashMap<String, LoRALayer>,

    /// Configuration used to create these adapters
    pub config: Option<LoRAConfig>,
}

impl LoRAAdapters {
    /// Create a new empty adapter collection
    pub fn new() -> Self {
        Self {
            layers: HashMap::new(),
            config: None,
        }
    }

    /// Create adapters for a model based on config
    pub fn from_config(
        config: LoRAConfig,
        layer_dims: &[(String, usize, usize)], // (name, in_features, out_features)
        device: &Device,
    ) -> Result<Self> {
        let mut layers = HashMap::new();

        for (name, in_features, out_features) in layer_dims {
            // Check if this layer should have LoRA applied
            let should_apply = config
                .target_modules
                .iter()
                .any(|target| name.contains(target));

            if should_apply {
                let lora = LoRALayer::new(
                    *in_features,
                    *out_features,
                    config.rank,
                    config.alpha,
                    device,
                )?;
                layers.insert(name.clone(), lora);
                tracing::debug!(
                    "Created LoRA for {}: {}x{} rank={}",
                    name,
                    in_features,
                    out_features,
                    config.rank
                );
            }
        }

        tracing::info!("Created {} LoRA adapters", layers.len());

        Ok(Self {
            layers,
            config: Some(config),
        })
    }

    /// Add a LoRA layer
    pub fn add(&mut self, name: String, layer: LoRALayer) {
        self.layers.insert(name, layer);
    }

    /// Get a LoRA layer by name
    pub fn get(&self, name: &str) -> Option<&LoRALayer> {
        self.layers.get(name)
    }

    /// Get a mutable LoRA layer by name
    pub fn get_mut(&mut self, name: &str) -> Option<&mut LoRALayer> {
        self.layers.get_mut(name)
    }

    /// Check if a layer has LoRA
    pub fn has(&self, name: &str) -> bool {
        self.layers.contains_key(name)
    }

    /// Get total number of trainable parameters
    pub fn num_parameters(&self) -> usize {
        self.layers.values().map(|l| l.num_parameters()).sum()
    }

    /// Enable or disable all LoRA layers
    pub fn set_enabled(&mut self, enabled: bool) {
        for layer in self.layers.values_mut() {
            layer.set_enabled(enabled);
        }
    }

    /// Save LoRA weights to a file (safetensors format)
    pub fn save(&self, path: &str) -> Result<()> {
        let mut tensors = HashMap::new();

        for (name, layer) in &self.layers {
            tensors.insert(format!("{}.lora_A", name), layer.lora_a.clone());
            tensors.insert(format!("{}.lora_B", name), layer.lora_b.clone());
        }

        candle_core::safetensors::save(&tensors, path)?;
        tracing::info!("Saved LoRA weights to {}", path);

        Ok(())
    }

    /// Load LoRA weights from a file (safetensors format)
    pub fn load(path: &str, device: &Device) -> Result<Self> {
        use candle_core::safetensors::load;

        let tensors = load(path, device)?;
        let mut layers = HashMap::new();

        // Group tensors by layer name
        let mut layer_tensors: HashMap<String, (Option<Tensor>, Option<Tensor>)> = HashMap::new();

        for (name, tensor) in tensors {
            if name.ends_with(".lora_A") {
                let layer_name = name.trim_end_matches(".lora_A").to_string();
                layer_tensors.entry(layer_name).or_insert((None, None)).0 = Some(tensor);
            } else if name.ends_with(".lora_B") {
                let layer_name = name.trim_end_matches(".lora_B").to_string();
                layer_tensors.entry(layer_name).or_insert((None, None)).1 = Some(tensor);
            }
        }

        // Create LoRA layers
        for (name, (lora_a, lora_b)) in layer_tensors {
            if let (Some(lora_a), Some(lora_b)) = (lora_a, lora_b) {
                let (rank, in_features) = lora_a.dims2()?;
                let (out_features, _) = lora_b.dims2()?;

                // Default alpha = rank * 2
                let alpha = rank as f32 * 2.0;
                let scaling = alpha / rank as f32;

                let layer = LoRALayer {
                    lora_a,
                    lora_b,
                    scaling,
                    in_features,
                    out_features,
                    rank,
                    enabled: true,
                };

                layers.insert(name, layer);
            }
        }

        tracing::info!("Loaded {} LoRA layers from {}", layers.len(), path);

        Ok(Self {
            layers,
            config: None,
        })
    }
}

/// Linear layer with optional LoRA
#[derive(Debug)]
pub struct LinearWithLoRA {
    /// Base weight matrix: [out_features, in_features]
    pub weight: Tensor,

    /// Optional bias: [out_features]
    pub bias: Option<Tensor>,

    /// Optional LoRA adapter
    pub lora: Option<LoRALayer>,

    /// Layer name (for debugging)
    pub name: String,
}

impl LinearWithLoRA {
    /// Create a new linear layer with optional LoRA
    pub fn new(weight: Tensor, bias: Option<Tensor>, name: &str) -> Self {
        Self {
            weight,
            bias,
            lora: None,
            name: name.to_string(),
        }
    }

    /// Attach a LoRA adapter to this layer
    pub fn attach_lora(&mut self, lora: LoRALayer) {
        self.lora = Some(lora);
    }

    /// Detach the LoRA adapter
    pub fn detach_lora(&mut self) -> Option<LoRALayer> {
        self.lora.take()
    }

    /// Forward pass
    pub fn forward(&self, x: &Tensor) -> Result<Tensor> {
        // Base linear: y = x @ W^T + b
        let mut y = x.matmul(&self.weight.t()?)?;

        if let Some(bias) = &self.bias {
            y = y.broadcast_add(bias)?;
        }

        // Add LoRA contribution if present
        if let Some(lora) = &self.lora {
            let lora_out = lora.forward(x)?;
            y = y.add(&lora_out)?;
        }

        Ok(y)
    }

    /// Merge LoRA into base weights (for inference optimization)
    pub fn merge_lora(&mut self) -> Result<()> {
        if let Some(lora) = &self.lora {
            self.weight = lora.merge_into(&self.weight)?;
            self.lora = None;
            tracing::debug!("Merged LoRA into {}", self.name);
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_lora_layer_creation() {
        let device = Device::Cpu;
        let lora = LoRALayer::new(768, 768, 8, 16.0, &device).unwrap();

        assert_eq!(lora.in_features, 768);
        assert_eq!(lora.out_features, 768);
        assert_eq!(lora.rank, 8);
        assert_eq!(lora.scaling, 2.0); // 16 / 8
        assert_eq!(lora.num_parameters(), 8 * 768 + 768 * 8); // 12288
    }

    #[test]
    fn test_lora_forward() {
        let device = Device::Cpu;
        let lora = LoRALayer::new(64, 64, 4, 8.0, &device).unwrap();

        let x = Tensor::randn(0.0f32, 1.0f32, (2, 64), &device).unwrap();
        let out = lora.forward(&x).unwrap();

        assert_eq!(out.dims(), &[2, 64]);
    }

    #[test]
    fn test_lora_starts_at_zero() {
        let device = Device::Cpu;
        let lora = LoRALayer::new(64, 64, 4, 8.0, &device).unwrap();

        let x = Tensor::ones((1, 64), DType::F32, &device).unwrap();
        let out = lora.forward(&x).unwrap();

        // B is initialized to zero, so output should be zero
        let sum: f32 = out.abs().unwrap().sum_all().unwrap().to_scalar().unwrap();
        assert!(sum < 1e-6, "LoRA output should start at zero, got {}", sum);
    }

    #[test]
    fn test_lora_merge() {
        let device = Device::Cpu;
        let mut lora = LoRALayer::new(64, 64, 4, 8.0, &device).unwrap();

        // Manually set B to non-zero to test merging
        lora.lora_b = Tensor::ones((64, 4), DType::F32, &device).unwrap();

        let base_weight = Tensor::zeros((64, 64), DType::F32, &device).unwrap();
        let merged = lora.merge_into(&base_weight).unwrap();

        // Merged weight should be non-zero now
        let sum: f32 = merged
            .abs()
            .unwrap()
            .sum_all()
            .unwrap()
            .to_scalar()
            .unwrap();
        assert!(sum > 0.0, "Merged weight should be non-zero");
    }

    #[test]
    fn test_lora_config() {
        let config = LoRAConfig::new(16);
        assert_eq!(config.rank, 16);
        assert_eq!(config.alpha, 32.0);

        let config = LoRAConfig::all_linear(8);
        assert_eq!(config.target_modules.len(), 7);
    }
}
