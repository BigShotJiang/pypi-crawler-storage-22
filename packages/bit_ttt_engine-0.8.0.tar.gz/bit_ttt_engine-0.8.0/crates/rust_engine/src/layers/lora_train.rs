//! LoRA Training Support
//!
//! This module provides training capabilities for LoRA adapters.
//! Unlike inference-only LoRA, this uses Var for gradient tracking.
//!
//! # Example
//!
//! ```rust,ignore
//! let trainer = LoRATrainer::new(model, config)?;
//! for (input, target) in dataset {
//!     let loss = trainer.train_step(&input, &target)?;
//!     println!("Loss: {}", loss);
//! }
//! trainer.save_lora("finetuned_lora.safetensors")?;
//! ```

use candle_core::{DType, Device, Result, Tensor, Var};
use std::collections::HashMap;

use super::{LoRAConfig, LoRALayer};

/// Trainable LoRA layer with Var-backed weights
#[derive(Debug)]
pub struct TrainableLoRALayer {
    /// Down-projection variable A: [rank, in_features]
    pub lora_a: Var,

    /// Up-projection variable B: [out_features, rank]
    pub lora_b: Var,

    /// Scaling factor: alpha / rank
    pub scaling: f32,

    /// Dimensions
    pub in_features: usize,
    pub out_features: usize,
    pub rank: usize,

    /// Whether enabled
    pub enabled: bool,
}

impl TrainableLoRALayer {
    /// Create a new trainable LoRA layer
    pub fn new(
        in_features: usize,
        out_features: usize,
        rank: usize,
        alpha: f32,
        device: &Device,
    ) -> Result<Self> {
        // A: Kaiming uniform initialization
        let std = (2.0 / in_features as f64).sqrt() as f32;
        let a_init = Tensor::randn(0.0f32, std, (rank, in_features), device)?;

        // B: Small non-zero initialization to enable gradient flow to A
        // Standard LoRA uses zeros, but that blocks gradient flow until B updates
        // Using small values (1e-4) keeps initial contribution ~0 while allowing gradients
        let b_init = Tensor::randn(0.0f32, 1e-4, (out_features, rank), device)?;

        // Create Vars for gradient tracking
        let lora_a = Var::from_tensor(&a_init)?;
        let lora_b = Var::from_tensor(&b_init)?;

        let scaling = alpha / rank as f32;

        Ok(Self {
            lora_a,
            lora_b,
            scaling,
            in_features,
            out_features,
            rank,
            enabled: true,
        })
    }

    /// Create from existing LoRA layer (convert Tensor to Var)
    pub fn from_lora_layer(layer: &LoRALayer) -> Result<Self> {
        let lora_a = Var::from_tensor(&layer.lora_a.to_dtype(DType::F32)?)?;
        let lora_b = Var::from_tensor(&layer.lora_b.to_dtype(DType::F32)?)?;

        Ok(Self {
            lora_a,
            lora_b,
            scaling: layer.scaling,
            in_features: layer.in_features,
            out_features: layer.out_features,
            rank: layer.rank,
            enabled: layer.enabled,
        })
    }

    /// Forward pass with gradient tracking
    pub fn forward(&self, x: &Tensor) -> Result<Tensor> {
        if !self.enabled {
            let mut out_shape = x.dims().to_vec();
            if let Some(last) = out_shape.last_mut() {
                *last = self.out_features;
            }
            return Tensor::zeros(out_shape, x.dtype(), x.device());
        }

        // Convert to F32 for computation
        let x_f32 = x.to_dtype(DType::F32)?;

        let original_shape = x_f32.dims().to_vec();
        let in_features = *original_shape.last().unwrap();

        // Flatten to 2D
        let batch_seq: usize = original_shape
            .iter()
            .take(original_shape.len() - 1)
            .product();
        let x_2d = x_f32.reshape((batch_seq, in_features))?;

        // Use as_tensor() to get gradient-tracking tensor
        let a = self.lora_a.as_tensor();
        let b = self.lora_b.as_tensor();

        // x @ A^T -> [batch * seq, rank]
        let h = x_2d.matmul(&a.t()?)?;

        // h @ B^T -> [batch * seq, out_features]
        let out_2d = h.matmul(&b.t()?)?;

        // Reshape back
        let mut out_shape = original_shape;
        *out_shape.last_mut().unwrap() = self.out_features;
        let out = out_2d.reshape(out_shape)?;

        // Scale and convert back
        let scaled = out.affine(self.scaling as f64, 0.0)?;
        scaled.to_dtype(x.dtype())
    }

    /// Convert back to inference-only LoRALayer
    pub fn to_lora_layer(&self) -> Result<LoRALayer> {
        Ok(LoRALayer {
            lora_a: self.lora_a.as_tensor().clone(),
            lora_b: self.lora_b.as_tensor().clone(),
            scaling: self.scaling,
            in_features: self.in_features,
            out_features: self.out_features,
            rank: self.rank,
            enabled: self.enabled,
        })
    }

    /// Get trainable variables
    pub fn vars(&self) -> Vec<Var> {
        vec![self.lora_a.clone(), self.lora_b.clone()]
    }

    /// Get number of trainable parameters
    pub fn num_parameters(&self) -> usize {
        self.rank * self.in_features + self.out_features * self.rank
    }
}

/// AdamW optimizer for LoRA training
pub struct AdamW {
    /// Learning rate
    pub lr: f64,
    /// Beta1 for momentum
    pub beta1: f64,
    /// Beta2 for RMS
    pub beta2: f64,
    /// Weight decay (L2 regularization)
    pub weight_decay: f64,
    /// Epsilon for numerical stability
    pub eps: f64,

    /// First moment estimates (m)
    m: Vec<Tensor>,
    /// Second moment estimates (v)
    v: Vec<Tensor>,
    /// Step count
    step: usize,
    /// Tracked variables
    vars: Vec<Var>,
}

impl AdamW {
    pub fn new(vars: Vec<Var>, lr: f64) -> Result<Self> {
        let mut m = Vec::with_capacity(vars.len());
        let mut v = Vec::with_capacity(vars.len());

        for var in &vars {
            let t = var.as_tensor();
            m.push(Tensor::zeros(t.dims(), DType::F32, t.device())?);
            v.push(Tensor::zeros(t.dims(), DType::F32, t.device())?);
        }

        Ok(Self {
            lr,
            beta1: 0.9,
            beta2: 0.999,
            weight_decay: 0.01,
            eps: 1e-8,
            m,
            v,
            step: 0,
            vars,
        })
    }

    pub fn with_weight_decay(mut self, wd: f64) -> Self {
        self.weight_decay = wd;
        self
    }

    pub fn with_betas(mut self, beta1: f64, beta2: f64) -> Self {
        self.beta1 = beta1;
        self.beta2 = beta2;
        self
    }

    /// Perform one optimization step
    pub fn step(&mut self, grads: &candle_core::backprop::GradStore) -> Result<()> {
        self.step += 1;

        // Bias correction
        let bias_correction1 = 1.0 - self.beta1.powi(self.step as i32);
        let bias_correction2 = 1.0 - self.beta2.powi(self.step as i32);

        for (i, var) in self.vars.iter().enumerate() {
            let grad = match grads.get(var) {
                Some(g) => g,
                None => continue, // Skip if no gradient
            };

            let param = var.as_tensor();

            // Convert gradient to F32
            let grad_f32 = grad.to_dtype(DType::F32)?;

            // Update first moment: m = beta1 * m + (1 - beta1) * grad
            let new_m =
                ((self.m[i].clone() * self.beta1)? + (grad_f32.clone() * (1.0 - self.beta1))?)?;

            // Update second moment: v = beta2 * v + (1 - beta2) * grad^2
            let grad_sq = grad_f32.sqr()?;
            let new_v = ((self.v[i].clone() * self.beta2)? + (grad_sq * (1.0 - self.beta2))?)?;

            // Bias-corrected estimates
            let m_hat = (&new_m / bias_correction1)?;
            let v_hat = (&new_v / bias_correction2)?;

            // Compute update: lr * m_hat / (sqrt(v_hat) + eps)
            let v_sqrt = v_hat.sqrt()?;
            let denom = (v_sqrt + self.eps)?;
            let update = (m_hat / denom)?.affine(self.lr, 0.0)?;

            // Apply weight decay (decoupled)
            let param_f32 = param.to_dtype(DType::F32)?;
            let decayed = (param_f32.clone() * (1.0 - self.lr * self.weight_decay))?;

            // Update parameter
            let new_param = (decayed - update)?;
            var.set(&new_param.to_dtype(param.dtype())?)?;

            // Store updated moments
            self.m[i] = new_m;
            self.v[i] = new_v;
        }

        Ok(())
    }

    /// Get current learning rate
    pub fn learning_rate(&self) -> f64 {
        self.lr
    }

    /// Set learning rate
    pub fn set_learning_rate(&mut self, lr: f64) {
        self.lr = lr;
    }
}

/// Collection of trainable LoRA adapters
pub struct TrainableLoRAAdapters {
    /// Map from layer name to trainable LoRA
    pub layers: HashMap<String, TrainableLoRALayer>,
    /// Config
    pub config: LoRAConfig,
}

impl TrainableLoRAAdapters {
    /// Create new trainable adapters
    pub fn new(
        config: LoRAConfig,
        layer_dims: &[(String, usize, usize)],
        device: &Device,
    ) -> Result<Self> {
        let mut layers = HashMap::new();

        for (name, in_features, out_features) in layer_dims {
            let should_apply = config.target_modules.iter().any(|t| name.contains(t));

            if should_apply {
                let lora = TrainableLoRALayer::new(
                    *in_features,
                    *out_features,
                    config.rank,
                    config.alpha,
                    device,
                )?;
                layers.insert(name.clone(), lora);
                tracing::debug!("Created trainable LoRA for {}", name);
            }
        }

        tracing::info!("Created {} trainable LoRA adapters", layers.len());

        Ok(Self { layers, config })
    }

    /// Get all Vars for optimizer
    pub fn vars(&self) -> Vec<Var> {
        self.layers.values().flat_map(|l| l.vars()).collect()
    }

    /// Get total trainable parameters
    pub fn num_parameters(&self) -> usize {
        self.layers.values().map(|l| l.num_parameters()).sum()
    }

    /// Save to safetensors
    pub fn save(&self, path: &str) -> Result<()> {
        let mut tensors = HashMap::new();

        for (name, layer) in &self.layers {
            tensors.insert(format!("{}.lora_A", name), layer.lora_a.as_tensor().clone());
            tensors.insert(format!("{}.lora_B", name), layer.lora_b.as_tensor().clone());
        }

        candle_core::safetensors::save(&tensors, path)?;
        tracing::info!("Saved trainable LoRA to {}", path);

        Ok(())
    }

    /// Load weights from safetensors (for resuming training)
    ///
    /// This updates the existing Var tensors in-place, preserving gradient tracking.
    pub fn load(&mut self, path: &str) -> Result<()> {
        use candle_core::safetensors::load;

        // Get device from existing layer
        let device = self
            .layers
            .values()
            .next()
            .map(|l| l.lora_a.as_tensor().device().clone())
            .ok_or_else(|| candle_core::Error::Msg("No LoRA layers to load into".to_string()))?;

        let tensors = load(path, &device)?;
        let mut loaded_count = 0;

        for (name, layer) in &mut self.layers {
            let a_key = format!("{}.lora_A", name);
            let b_key = format!("{}.lora_B", name);

            if let (Some(a_tensor), Some(b_tensor)) = (tensors.get(&a_key), tensors.get(&b_key)) {
                // Update Var tensors in-place
                layer.lora_a.set(a_tensor)?;
                layer.lora_b.set(b_tensor)?;
                loaded_count += 1;
            }
        }

        if loaded_count == 0 {
            return Err(candle_core::Error::Msg(format!(
                "No matching LoRA layers found in {}. Expected keys like 'layers.0.q_proj.lora_A'",
                path
            )));
        }

        tracing::info!("Loaded {} LoRA layers from {}", loaded_count, path);
        Ok(())
    }

    /// Get a layer by layer index and projection type
    /// Returns the LoRA layer for the specified attention projection
    pub fn get_layer(&self, layer_idx: usize, proj_type: &str) -> Option<&TrainableLoRALayer> {
        // Try different naming conventions
        let patterns = [
            format!("layers.{}.{}", layer_idx, proj_type),
            format!("layers.{}.self_attn.{}", layer_idx, proj_type),
            format!("model.layers.{}.self_attn.{}", layer_idx, proj_type),
            format!("layers.{}.attention.{}", layer_idx, proj_type),
        ];

        for pattern in &patterns {
            if let Some(layer) = self.layers.get(pattern) {
                return Some(layer);
            }
        }

        // Try matching partial name
        let search_key = format!("layers.{}", layer_idx);
        for (name, layer) in &self.layers {
            if name.contains(&search_key) && name.contains(proj_type) {
                return Some(layer);
            }
        }

        None
    }

    /// Get all layer indices that have LoRA adapters
    pub fn layer_indices(&self) -> Vec<usize> {
        let mut indices: Vec<usize> = self
            .layers
            .keys()
            .filter_map(|name| {
                // Extract layer index from name like "layers.5.q_proj"
                name.split('.')
                    .find(|part| part.parse::<usize>().is_ok())
                    .and_then(|s| s.parse().ok())
            })
            .collect();
        indices.sort();
        indices.dedup();
        indices
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_trainable_lora_creation() {
        let device = Device::Cpu;

        let lora = TrainableLoRALayer::new(768, 768, 8, 16.0, &device).unwrap();

        assert_eq!(lora.in_features, 768);
        assert_eq!(lora.out_features, 768);
        assert_eq!(lora.rank, 8);
        assert_eq!(lora.num_parameters(), 8 * 768 * 2);
    }

    #[test]
    fn test_trainable_lora_forward() {
        let device = Device::Cpu;

        let lora = TrainableLoRALayer::new(64, 64, 4, 8.0, &device).unwrap();

        let x = Tensor::randn(0.0f32, 1.0f32, (2, 64), &device).unwrap();
        let out = lora.forward(&x).unwrap();

        assert_eq!(out.dims(), &[2, 64]);
    }

    #[test]
    fn test_trainable_lora_vars() {
        let device = Device::Cpu;

        let lora = TrainableLoRALayer::new(64, 64, 4, 8.0, &device).unwrap();
        let vars = lora.vars();

        assert_eq!(vars.len(), 2);
    }

    #[test]
    fn test_adamw_creation() {
        let device = Device::Cpu;
        let lora = TrainableLoRALayer::new(64, 64, 4, 8.0, &device).unwrap();
        let vars = lora.vars();

        let opt = AdamW::new(vars, 1e-4).unwrap();
        assert!((opt.lr - 1e-4).abs() < 1e-10);
    }
}
