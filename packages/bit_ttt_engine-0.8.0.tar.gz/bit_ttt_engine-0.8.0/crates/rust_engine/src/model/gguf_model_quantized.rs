//! GGUF Model (Quantized) - Memory-efficient inference using QMatMul
//!
//! This version keeps weights in quantized format and uses QMatMul for computation,
//! significantly reducing memory usage compared to the dequantized version.
//!
//! Memory comparison (7B model):
//! - Dequantized (FP32): ~28GB VRAM
//! - Quantized (Q4_K_M): ~4GB VRAM
//!
//! Based on candle-transformers' quantized_llama.rs pattern.

/// Scale factor for hybrid LoRA residual injection.
/// Must be identical in both training path (forward_with_trainable_lora)
/// and inference path (forward with use_hybrid_lora).
const HYBRID_LORA_SCALE: f64 = 0.1;

use candle_core::backend::BackendDevice;
use candle_core::quantized::{gguf_file, QMatMul, QTensor};
use candle_core::{Device, Result, Tensor};
use candle_nn::{Embedding, Module};
use std::collections::HashMap;
use std::io::{Read, Seek};
use std::path::Path;
use tracing::info;

use super::config::{ActivationType, BitLlamaConfig};
use crate::kernels::flash_decoding::{flash_decode_cuda, flash_decode_cuda_fp16};
use crate::layers::QuantizedKVCache;

/// Fast QMatMul forward using quantized matmul (apply_op1_no_bwd)
///
/// This is **40x faster** than `forward_via_f16` because:
/// - Uses CUDA quantized matmul kernel (mul_mat_vec_via_q8_1)
/// - No dequantize overhead (input is quantized on-the-fly to Q8_1)
/// - Leverages llama.cpp-style quantized computation
///
/// Benchmark results (Q4_K_M, [1, 4096] @ [4096, 4096]):
/// - forward_via_f16:              1.612ms
/// - apply_op1_no_bwd (this):      0.039ms (40x faster!)
///
/// Note: Input must be 2D [batch*seq, hidden] for apply_op1
#[inline]
fn qmatmul_forward_quantized(qmatmul: &QMatMul, xs: &Tensor) -> Result<Tensor> {
    match qmatmul {
        QMatMul::QTensor(qtensor) => {
            // Flatten to 2D for apply_op1
            let original_shape = xs.dims().to_vec();
            let hidden = *original_shape.last().unwrap();
            let batch_seq = original_shape
                .iter()
                .take(original_shape.len() - 1)
                .product::<usize>();

            let xs_2d = xs.reshape((batch_seq, hidden))?;

            // Use quantized matmul via CustomOp1
            let result_2d = xs_2d.apply_op1_no_bwd(qtensor.as_ref())?;

            // Reshape back to original batch dimensions
            let out_hidden = result_2d.dim(1)?;
            let mut out_shape = original_shape;
            *out_shape.last_mut().unwrap() = out_hidden;
            result_2d.reshape(out_shape)
        }
        QMatMul::Tensor(t) => {
            // Already dequantized to F32, use standard matmul
            let w = match *xs.dims() {
                [b1, b2, _, _] => t.broadcast_left((b1, b2))?.t()?,
                [bsize, _, _] => t.broadcast_left(bsize)?.t()?,
                _ => t.t()?,
            };
            xs.matmul(&w)
        }
        QMatMul::TensorF16(t) => {
            // Convert F16 to input dtype and matmul
            let t = t.to_dtype(xs.dtype())?;
            let w = match *xs.dims() {
                [b1, b2, _, _] => t.broadcast_left((b1, b2))?.t()?,
                [bsize, _, _] => t.broadcast_left(bsize)?.t()?,
                _ => t.t()?,
            };
            xs.matmul(&w)
        }
    }
}

/// Quantized GGUF Model for memory-efficient inference
///
/// Keeps weights in quantized format (Q4_K_M, Q8_0, etc.) and uses
/// QMatMul for matrix multiplication without dequantizing to FP32.
pub struct QGgufModel {
    /// Token embeddings (dequantized for lookup)
    tok_embeddings: Embedding,
    /// Transformer layers
    layers: Vec<QGgufLayer>,
    /// Final normalization
    norm: QRmsNorm,
    /// LM head (output projection)
    output: QMatMul,
    /// Model configuration
    config: BitLlamaConfig,
    /// Causal masks cache (full attention)
    masks: HashMap<usize, Tensor>,
    /// Sliding window masks cache (for sliding attention layers)
    sliding_masks: HashMap<usize, Tensor>,
    /// Per-layer attention type: true = full attention, false = sliding window
    layer_is_full_attn: Vec<bool>,
    /// Device
    device: Device,
    /// Is this a Gemma-2 model?
    is_gemma2: bool,
    /// LoRA adapters (optional)
    lora_adapters: Option<crate::layers::LoRAAdapters>,
    /// Whether LoRA is enabled
    lora_enabled: bool,
    /// Use hybrid LoRA mode (accumulate LoRA residual, add to final hidden)
    /// This matches the training path and produces better results with trained LoRA weights
    use_hybrid_lora: bool,
    /// Profiling mode: collect per-component timing
    profiling_enabled: bool,
    /// Last profile results: (component_name, duration_ms)
    last_profile: Vec<(String, f64)>,
}

/// Single transformer layer with quantized weights
struct QGgufLayer {
    /// Pre-attention norm
    attention_norm: QRmsNorm,
    /// Post-attention norm (FFN norm)
    ffn_norm: QRmsNorm,
    /// Gemma-2: Post-attention norm (optional)
    post_attn_norm: Option<QRmsNorm>,
    /// Gemma-2: Post-FFN norm (optional)
    post_ffn_norm: Option<QRmsNorm>,
    /// Attention Q projection
    attention_wq: QMatMul,
    /// Attention Q bias (Qwen2)
    attention_bq: Option<Tensor>,
    /// Attention K projection
    attention_wk: QMatMul,
    /// Attention K bias (Qwen2)
    attention_bk: Option<Tensor>,
    /// Attention V projection
    attention_wv: QMatMul,
    /// Attention V bias (Qwen2)
    attention_bv: Option<Tensor>,
    /// Attention output projection
    attention_wo: QMatMul,
    /// MLP gate projection
    feed_forward_w1: QMatMul,
    /// MLP down projection
    feed_forward_w2: QMatMul,
    /// MLP up projection
    feed_forward_w3: QMatMul,
    /// LoRA for Q projection (optional)
    lora_wq: Option<crate::layers::LoRALayer>,
    /// LoRA for K projection (optional)
    lora_wk: Option<crate::layers::LoRALayer>,
    /// LoRA for V projection (optional)
    lora_wv: Option<crate::layers::LoRALayer>,
    /// LoRA for output projection (optional)
    lora_wo: Option<crate::layers::LoRALayer>,
    /// Number of attention heads
    n_heads: usize,
    /// Number of KV heads
    n_kv_heads: usize,
    /// Dimension per head
    head_dim: usize,
    /// RoPE cos cache
    cos: Tensor,
    /// RoPE sin cache
    sin: Tensor,
    /// Negative infinity for masking
    neg_inf: Tensor,
    /// KV cache (FP16) - legacy cat-based (fallback)
    kv_cache: Option<(Tensor, Tensor)>,
    /// Pre-allocated KV cache buffers [batch, n_kv_heads, max_seq, head_dim]
    kv_buffer: Option<(Tensor, Tensor)>,
    /// Current sequence length in pre-allocated KV cache
    kv_seq_len: usize,
    /// KV cache (Q8_0 quantized, GPU-optimized) - for memory efficiency
    #[cfg(feature = "cuda")]
    kv_cache_q8: Option<crate::kernels::quantize_q8::KVCacheQ8Gpu>,
    #[cfg(not(feature = "cuda"))]
    kv_cache_q8: Option<crate::kernels::quantize_q8::KVCacheQ8>,
    /// Use Q8_0 quantized KV cache
    use_q8_kv_cache: bool,
    /// Gemma-3: Q projection LayerNorm (per-head)
    attn_q_norm: Option<QRmsNorm>,
    /// Gemma-3: K projection LayerNorm (per-head)
    attn_k_norm: Option<QRmsNorm>,
    /// Gemma-2: Attention logit softcapping
    attn_logit_softcapping: Option<f64>,
    /// Gemma-2: Sliding window size
    sliding_window: Option<usize>,
    /// Gemma-2: Query pre-attention scalar
    query_pre_attn_scalar: Option<f64>,
    /// Is this a Gemma-2 model?
    is_gemma2: bool,
    /// Layer index
    layer_idx: usize,
    /// TTT (Test-Time Training) state for online learning
    /// W_state: [d_small, d_small] - learnable hidden state matrix
    ttt_w_state: Option<Tensor>,
    /// TTT compressed dimension (hidden_dim / 4)
    ttt_d_small: usize,
    /// TTT inner learning rate
    ttt_inner_lr: f64,
    /// Enable TTT refinement
    use_ttt: bool,
}

/// Quantized RMS Normalization
struct QRmsNorm {
    weight: Tensor,
    eps: f64,
}

impl QRmsNorm {
    fn new(weight: QTensor, eps: f64, device: &Device) -> Result<Self> {
        let weight = weight.dequantize(device)?;
        Ok(Self { weight, eps })
    }

    fn forward(&self, x: &Tensor) -> Result<Tensor> {
        // Use CUDA RMSNorm kernel (fast, no backward)
        crate::kernels::fused_ops::rms_norm_cuda(x, &self.weight, self.eps)
    }

    /// Gradient-compatible forward using standard candle ops (slower but backward works)
    fn forward_grad(&self, x: &Tensor) -> Result<Tensor> {
        crate::kernels::fused_ops::rms_norm_cpu(x, &self.weight, self.eps)
    }
}

impl QGgufLayer {
    /// Initialize TTT state for this layer
    fn init_ttt_state(&mut self, device: &Device) -> Result<()> {
        if self.ttt_w_state.is_none() {
            // Initialize W as identity-like (small random values)
            let d = self.ttt_d_small;
            let scale = (1.0 / d as f64).sqrt();
            let w_data: Vec<f32> = (0..d * d)
                .map(|i| {
                    let row = i / d;
                    let col = i % d;
                    if row == col {
                        1.0 // Diagonal = 1
                    } else {
                        ((i as f64 * 0.1).sin() * scale) as f32 // Small off-diagonal
                    }
                })
                .collect();
            self.ttt_w_state = Some(Tensor::from_vec(w_data, (d, d), device)?);
            tracing::debug!(
                "Initialized TTT state for layer {}: d_small={}",
                self.layer_idx,
                d
            );
        }
        Ok(())
    }

    /// Reset TTT state (for new conversation)
    fn reset_ttt_state(&mut self) {
        self.ttt_w_state = None;
    }

    /// TTT refinement on attention output
    ///
    /// Uses online gradient descent to refine the output based on self-supervised loss.
    /// This can improve long-context understanding without additional training.
    ///
    /// # Arguments
    /// - `x`: Input to attention [batch, seq, hidden]
    /// - `attn_out`: Attention output [batch, seq, hidden]
    ///
    /// # Returns
    /// - Refined output [batch, seq, hidden]
    /// Project hidden features to d_small dimension via mean pooling
    /// [batch, seq, hidden] -> [batch, seq, d_small], normalized
    fn ttt_project_features(&self, x: &Tensor) -> Result<Tensor> {
        let (b_sz, seq_len, hidden) = x.dims3()?;
        let d_small = self.ttt_d_small;
        let feats = x
            .reshape((b_sz, seq_len, d_small, hidden / d_small))?
            .mean(3)?; // [batch, seq_len, d_small]
                       // L2 normalize
        let norms = (feats.sqr()?.sum_keepdim(2)?.sqrt()? + 1e-6)?;
        feats.broadcast_div(&norms)
    }

    fn ttt_refine(&mut self, x: &Tensor, attn_out: &Tensor) -> Result<Tensor> {
        if !self.use_ttt {
            return Ok(attn_out.clone());
        }

        let device = x.device();
        self.init_ttt_state(device)?;

        let (b_sz, seq_len, hidden) = x.dims3()?;
        let d_small = self.ttt_d_small;

        // Project input features to d_small
        let feats_norm = self.ttt_project_features(x)?; // [batch, seq, d_small]

        if seq_len > 1 {
            // === PREFILL: Learn from sequence via next-token prediction ===
            // For each t: predict feat[t+1] from feat[t] using W
            // Loss = ||W @ feat[t] - feat[t+1]||²
            // This teaches W the sequential patterns in the input

            let mut w = self.ttt_w_state.as_ref().unwrap().clone();

            for t in 0..(seq_len - 1) {
                let feat_t = feats_norm.narrow(1, t, 1)?.squeeze(1)?; // [batch, d_small]
                let feat_next = feats_norm.narrow(1, t + 1, 1)?.squeeze(1)?; // [batch, d_small]

                // Predict: pred = W @ feat_t
                let w_batched = w.unsqueeze(0)?.broadcast_as((b_sz, d_small, d_small))?;
                let feat_col = feat_t.unsqueeze(2)?; // [batch, d_small, 1]
                let pred = w_batched.matmul(&feat_col)?.squeeze(2)?; // [batch, d_small]

                // Gradient: (pred - target) outer feat_t
                let diff = (&pred - &feat_next)?;
                let grad = diff.unsqueeze(2)?.matmul(&feat_t.unsqueeze(1)?)?; // [batch, d, d]
                let grad_mean = grad.mean(0)?; // [d_small, d_small]

                w = (&w - &grad_mean * self.ttt_inner_lr)?.detach();
            }

            self.ttt_w_state = Some(w);

            // During prefill, don't modify output (learning only)
            Ok(attn_out.clone())
        } else {
            // === DECODE: Use learned W to refine output ===
            let feat = feats_norm.squeeze(1)?; // [batch, d_small]

            let w = self.ttt_w_state.as_ref().unwrap();
            let w_batched = w.unsqueeze(0)?.broadcast_as((b_sz, d_small, d_small))?;
            let feat_col = feat.unsqueeze(2)?; // [batch, d_small, 1]
            let pred = w_batched.matmul(&feat_col)?.squeeze(2)?; // [batch, d_small]

            // Online learning: continue updating W during decode
            let diff = (&pred - &feat)?;
            let grad = diff.unsqueeze(2)?.matmul(&feat.unsqueeze(1)?)?;
            let grad_mean = grad.mean(0)?;
            let w_new = (w - &grad_mean * self.ttt_inner_lr)?.detach();
            self.ttt_w_state = Some(w_new);

            // Project up: [batch, d_small] -> [batch, hidden]
            let refined = pred
                .unsqueeze(2)? // [batch, d_small, 1]
                .broadcast_as((b_sz, d_small, hidden / d_small))?
                .reshape((b_sz, hidden))?
                .unsqueeze(1)?; // [batch, 1, hidden]

            // Mix with attention output (increased from 0.1)
            let alpha = 0.3;
            let attn_scaled = (attn_out * (1.0 - alpha))?;
            let refined_scaled = (refined * alpha)?;
            Ok((attn_scaled + refined_scaled)?)
        }
    }

    fn apply_rotary_emb_qk(
        &self,
        q: &Tensor,
        k: &Tensor,
        index_pos: usize,
    ) -> Result<(Tensor, Tensor)> {
        // Use fused CUDA RoPE kernel (1 launch instead of 10)
        crate::kernels::fused_ops::fused_rope_cuda(q, k, &self.cos, &self.sin, index_pos)
    }

    fn forward_attn(
        &mut self,
        x: &Tensor,
        mask: Option<&Tensor>,
        index_pos: usize,
    ) -> Result<Tensor> {
        let (b_sz, seq_len, _hidden) = x.dims3()?;

        // Q, K, V projections (using quantized matmul for 40x speedup)
        let mut q = qmatmul_forward_quantized(&self.attention_wq, x)?;
        let mut k = qmatmul_forward_quantized(&self.attention_wk, x)?;
        let mut v = qmatmul_forward_quantized(&self.attention_wv, x)?;

        // Apply attention bias (Qwen2)
        if let Some(ref bq) = self.attention_bq {
            q = q.broadcast_add(bq)?;
        }
        if let Some(ref bk) = self.attention_bk {
            k = k.broadcast_add(bk)?;
        }
        if let Some(ref bv) = self.attention_bv {
            v = v.broadcast_add(bv)?;
        }

        // Apply LoRA if enabled
        if let Some(ref lora) = self.lora_wq {
            if lora.enabled {
                q = q.add(&lora.forward(x)?)?;
            }
        }
        if let Some(ref lora) = self.lora_wk {
            if lora.enabled {
                k = k.add(&lora.forward(x)?)?;
            }
        }
        if let Some(ref lora) = self.lora_wv {
            if lora.enabled {
                v = v.add(&lora.forward(x)?)?;
            }
        }

        // Reshape to [batch, seq, heads, head_dim]
        let q = q
            .reshape((b_sz, seq_len, self.n_heads, self.head_dim))?
            .transpose(1, 2)?;
        let k = k
            .reshape((b_sz, seq_len, self.n_kv_heads, self.head_dim))?
            .transpose(1, 2)?;
        let v = v
            .reshape((b_sz, seq_len, self.n_kv_heads, self.head_dim))?
            .transpose(1, 2)?
            .contiguous()?;

        // Gemma-3: Apply QK LayerNorm (per-head normalization before RoPE)
        let q = if let Some(ref norm) = self.attn_q_norm {
            // norm expects [*, dim], q is [batch, heads, seq, head_dim]
            // Apply norm to last dimension (head_dim)
            norm.forward(&q.contiguous()?)?
        } else {
            q
        };
        let k = if let Some(ref norm) = self.attn_k_norm {
            norm.forward(&k.contiguous()?)?
        } else {
            k
        };

        // Apply RoPE
        let (q, k) = self.apply_rotary_emb_qk(&q, &k, index_pos)?;

        // Scaled dot-product attention scale
        let scale = if let Some(scalar) = self.query_pre_attn_scalar {
            scalar.powf(-0.5)
        } else {
            (self.head_dim as f64).sqrt().recip()
        };

        // Q8_0 KV cache path (GPU-optimized for memory efficiency)
        #[cfg(feature = "cuda")]
        if self.use_q8_kv_cache && seq_len == 1 && q.device().is_cuda() {
            use crate::kernels::quantize_q8::{flash_attention_q8_gpu, KVCacheQ8Gpu};

            // Initialize Q8 KV cache if needed
            if self.kv_cache_q8.is_none() {
                let max_seq = 4096; // TODO: make configurable
                self.kv_cache_q8 = Some(KVCacheQ8Gpu::new(
                    max_seq,
                    self.n_kv_heads,
                    self.head_dim,
                    q.device(),
                )?);

                // Transfer existing F16 cache to Q8 cache (from prefill phase)
                // IMPORTANT: We transfer position-by-position to maintain correct memory layout
                // Q8 kernel expects [seq_pos, kv_head, head_dim_blocks] layout
                if let Some((k_cache, v_cache)) = self.kv_cache.take() {
                    let kv_cache = self.kv_cache_q8.as_mut().unwrap();
                    let prefill_seq_len = k_cache.dim(2)?;
                    tracing::info!(
                        "Transferring {} prefill tokens from F16 to Q8 cache",
                        prefill_seq_len
                    );

                    // Transfer each position separately to maintain [seq_pos, kv_head, dim_blocks] layout
                    // Use contiguous() to ensure proper memory layout (narrow() returns a view)
                    for pos in 0..prefill_seq_len {
                        let k_pos = k_cache.narrow(2, pos, 1)?.contiguous()?; // [batch, n_kv_heads, 1, head_dim]
                        let v_pos = v_cache.narrow(2, pos, 1)?.contiguous()?;
                        kv_cache.append(&k_pos, &v_pos)?;
                    }
                    tracing::info!(
                        "Transfer complete, Q8 cache seq_len = {}",
                        kv_cache.current_seq_len()
                    );
                }
            }

            // Append current K/V to Q8 cache (quantizes directly on GPU)
            let kv_cache = self.kv_cache_q8.as_mut().unwrap();
            kv_cache.append(&k, &v)?;

            // Use flash attention with GPU-resident Q8 KV (no CPU-GPU transfers!)
            let y = flash_attention_q8_gpu(&q, kv_cache, scale as f32)?;

            // Output is already F32 from flash_attention_q8_gpu
            // Reshape back and output projection
            let y = y
                .transpose(1, 2)?
                .reshape((b_sz, seq_len, self.n_heads * self.head_dim))?;
            let mut out = qmatmul_forward_quantized(&self.attention_wo, &y)?;

            // Apply LoRA to output projection if enabled
            if let Some(ref lora) = self.lora_wo {
                if lora.enabled {
                    out = out.add(&lora.forward(&y)?)?;
                }
            }

            return Ok(out);
        }

        // Simple KV cache using cat (no pre-allocation, guaranteed correct)
        let (k, v) = match &self.kv_cache {
            None => (k, v),
            Some((k_cache, v_cache)) => {
                if index_pos == 0 {
                    (k, v)
                } else {
                    let k = Tensor::cat(&[k_cache, &k], 2)?;
                    let v = Tensor::cat(&[v_cache, &v], 2)?;
                    (k, v)
                }
            }
        };
        self.kv_cache = Some((k.clone(), v.clone()));

        // Standard attention with repeat_kv for GQA
        let y = {
            let k = repeat_kv(k, self.n_heads / self.n_kv_heads)?.contiguous()?;
            let v = repeat_kv(v, self.n_heads / self.n_kv_heads)?.contiguous()?;

            let att = (q.matmul(&k.t()?)? * scale)?;

            // Gemma-2: Attention logit softcapping
            let att = if let Some(cap) = self.attn_logit_softcapping {
                ((att / cap)?.tanh()? * cap)?
            } else {
                att
            };

            // Apply causal mask
            let att = match mask {
                None => att,
                Some(mask) => att.broadcast_add(mask)?,
            };

            let att = softmax_last_dim_safe(&att)?;
            att.matmul(&v.contiguous()?)?
        };

        // Reshape back to [batch, seq, hidden]
        let y = y
            .transpose(1, 2)?
            .reshape((b_sz, seq_len, self.n_heads * self.head_dim))?;

        // Output projection (using quantized matmul for 40x speedup)
        let mut out = qmatmul_forward_quantized(&self.attention_wo, &y)?;

        // Apply LoRA to output projection if enabled
        if let Some(ref lora) = self.lora_wo {
            if lora.enabled {
                out = out.add(&lora.forward(&y)?)?;
            }
        }

        Ok(out)
    }

    fn forward(&mut self, x: &Tensor, mask: Option<&Tensor>, index_pos: usize) -> Result<Tensor> {
        let (_b_sz, _seq_len, _hidden) = x.dims3()?;

        // Pre-attention norm
        let residual = x.clone();
        let x = self.attention_norm.forward(x)?;

        // Self-attention
        let attn_out = self.forward_attn(&x, mask, index_pos)?;

        // TTT refinement (optional, for improved long-context understanding)
        let attn_out = self.ttt_refine(&x, &attn_out)?;

        // Gemma-2: Post-attention norm (before residual)
        let attn_out = if let Some(ref norm) = self.post_attn_norm {
            norm.forward(&attn_out)?
        } else {
            attn_out
        };

        // Residual connection
        let x = (residual + attn_out)?;

        // MLP
        let residual = x.clone();
        let x = self.ffn_norm.forward(&x)?;

        // Gated MLP: down(act(gate(x)) * up(x)) with CUDA fused kernel
        // Gemma family uses GELU, others use SiLU
        let w1 = qmatmul_forward_quantized(&self.feed_forward_w1, &x)?;
        let w3 = qmatmul_forward_quantized(&self.feed_forward_w3, &x)?;
        let act_mul = if self.is_gemma2 {
            crate::kernels::fused_ops::fused_gelu_mul_cuda(&w1, &w3)?
        } else {
            crate::kernels::fused_ops::fused_silu_mul_cuda(&w1, &w3)?
        };
        let mlp_out = qmatmul_forward_quantized(&self.feed_forward_w2, &act_mul)?;

        // Gemma-2: Post-FFN norm (before residual)
        let mlp_out = if let Some(ref norm) = self.post_ffn_norm {
            norm.forward(&mlp_out)?
        } else {
            mlp_out
        };

        // Residual connection
        residual + mlp_out
    }

    /// Forward pass with trainable LoRA for gradient-based training
    ///
    /// This applies TrainableLoRA adapters to attention projections,
    /// Per-layer forward pass with trainable LoRA injected into Q/K/V/O.
    ///
    /// NOTE: Currently UNUSED. The model-level forward_with_trainable_lora uses the
    /// "hybrid" approach instead (accumulate LoRA residual → add to final hidden).
    /// This per-layer version doesn't work because custom CUDA kernels (rms_norm, rope, etc.)
    /// break the backward graph even with forward_grad() workarounds.
    /// Kept for future reference if candle adds backward support for custom ops.
    #[allow(dead_code)]
    fn forward_with_trainable_lora(
        &mut self,
        x: &Tensor,
        mask: Option<&Tensor>,
        index_pos: usize,
        trainable_loras: &crate::layers::TrainableLoRAAdapters,
        layer_idx: usize,
    ) -> Result<Tensor> {
        // Pre-attention norm (grad-compatible for training)
        let residual = x.clone();
        let x_normed = self.attention_norm.forward_grad(x)?;

        // ===== Attention with Trainable LoRA =====
        let (b_sz, seq_len, _hidden) = x_normed.dims3()?;

        // Q, K, V projections (base quantized matmul)
        let mut q = qmatmul_forward_quantized(&self.attention_wq, &x_normed)?;
        let mut k = qmatmul_forward_quantized(&self.attention_wk, &x_normed)?;
        let mut v = qmatmul_forward_quantized(&self.attention_wv, &x_normed)?;

        // Apply attention bias (Qwen2)
        if let Some(ref bq) = self.attention_bq {
            q = q.broadcast_add(bq)?;
        }
        if let Some(ref bk) = self.attention_bk {
            k = k.broadcast_add(bk)?;
        }
        if let Some(ref bv) = self.attention_bv {
            v = v.broadcast_add(bv)?;
        }

        // Apply TrainableLoRA to Q, K, V (gradient flows through these!)
        // Cast LoRA output to match quantized matmul output dtype
        if let Some(lora) = trainable_loras.get_layer(layer_idx, "q_proj") {
            let lora_out = lora.forward(&x_normed)?.to_dtype(q.dtype())?;
            q = q.add(&lora_out)?;
        }
        if let Some(lora) = trainable_loras.get_layer(layer_idx, "k_proj") {
            let lora_out = lora.forward(&x_normed)?.to_dtype(k.dtype())?;
            k = k.add(&lora_out)?;
        }
        if let Some(lora) = trainable_loras.get_layer(layer_idx, "v_proj") {
            let lora_out = lora.forward(&x_normed)?.to_dtype(v.dtype())?;
            v = v.add(&lora_out)?;
        }

        // Reshape for attention
        let q = q
            .reshape((b_sz, seq_len, self.n_heads, self.head_dim))?
            .transpose(1, 2)?;
        let k = k
            .reshape((b_sz, seq_len, self.n_kv_heads, self.head_dim))?
            .transpose(1, 2)?;
        let v = v
            .reshape((b_sz, seq_len, self.n_kv_heads, self.head_dim))?
            .transpose(1, 2)?
            .contiguous()?;

        // RoPE
        let (q, k) = self.apply_rotary_emb_qk(&q, &k, index_pos)?;

        // Attention scale
        let scale = if let Some(scalar) = self.query_pre_attn_scalar {
            scalar.powf(-0.5)
        } else {
            (self.head_dim as f64).sqrt().recip()
        };

        // Standard attention (no KV cache during training)
        let (k, v) = match &self.kv_cache {
            None => (k, v),
            Some((k_cache, v_cache)) => {
                if index_pos == 0 {
                    (k, v)
                } else {
                    let k = Tensor::cat(&[k_cache, &k], 2)?;
                    let v = Tensor::cat(&[v_cache, &v], 2)?;
                    (k, v)
                }
            }
        };
        self.kv_cache = Some((k.clone(), v.clone()));

        let k = repeat_kv(k, self.n_heads / self.n_kv_heads)?;
        let v = repeat_kv(v, self.n_heads / self.n_kv_heads)?;

        let att = (q.matmul(&k.t()?)? * scale)?;
        let att = if let Some(cap) = self.attn_logit_softcapping {
            ((att / cap)?.tanh()? * cap)?
        } else {
            att
        };
        let att = match mask {
            None => att,
            Some(mask) => att.broadcast_add(mask)?,
        };
        // Manual softmax for gradient support on CUDA (custom kernel has no backward)
        // softmax(x) = exp(x - max(x)) / sum(exp(x - max(x)))
        let att_max = att.max_keepdim(candle_core::D::Minus1)?;
        let att = att.broadcast_sub(&att_max)?;
        let att = att.exp()?;
        let att_sum = att.sum_keepdim(candle_core::D::Minus1)?;
        let att = att.broadcast_div(&att_sum)?;
        let y = att.matmul(&v.contiguous()?)?;

        // Output projection
        let y = y
            .transpose(1, 2)?
            .reshape((b_sz, seq_len, self.n_heads * self.head_dim))?;
        let mut attn_out = qmatmul_forward_quantized(&self.attention_wo, &y)?;

        // Apply LoRA to output projection
        if let Some(lora) = trainable_loras.get_layer(layer_idx, "o_proj") {
            let lora_out = lora.forward(&y)?.to_dtype(attn_out.dtype())?;
            attn_out = attn_out.add(&lora_out)?;
        }
        // ===== End Attention =====

        // Gemma-2: Post-attention norm (grad-compatible)
        let attn_out = if let Some(ref norm) = self.post_attn_norm {
            norm.forward_grad(&attn_out)?
        } else {
            attn_out
        };

        // Residual connection
        let x = (residual + attn_out)?;

        // MLP (using candle native ops for gradient support)
        let residual = x.clone();
        let x = self.ffn_norm.forward_grad(&x)?;

        let w1 = qmatmul_forward_quantized(&self.feed_forward_w1, &x)?;
        let w3 = qmatmul_forward_quantized(&self.feed_forward_w3, &x)?;
        // Use candle native SiLU * mul instead of fused CUDA kernel (for backward support)
        let silu_mul = (candle_nn::ops::silu(&w1)? * w3)?;
        let mlp_out = qmatmul_forward_quantized(&self.feed_forward_w2, &silu_mul)?;

        // Gemma-2: Post-FFN norm (grad-compatible)
        let mlp_out = if let Some(ref norm) = self.post_ffn_norm {
            norm.forward_grad(&mlp_out)?
        } else {
            mlp_out
        };

        // Residual connection
        residual + mlp_out
    }
}

impl QGgufModel {
    /// Load a GGUF model with quantized weights
    pub fn load<P: AsRef<Path>>(path: P, device: &Device) -> Result<Self> {
        let path = path.as_ref();
        info!("📦 Loading quantized GGUF model: {:?}", path);

        let mut file = std::fs::File::open(path)?;
        let content = gguf_file::Content::read(&mut file)?;

        // Extract config from metadata
        let config = Self::extract_config(&content)?;
        let is_gemma2 = config.arch == super::config::ModelArch::Gemma2
            || config.arch == super::config::ModelArch::Gemma3;

        info!(
            "   ✅ Config: {}L, {}H, {}KV, vocab={}, arch={:?}",
            config.num_layers, config.n_heads, config.n_kv_heads, config.vocab_size, config.arch
        );

        // Load embeddings (need to dequantize for lookup)
        info!("   📥 Loading embeddings...");
        let tok_embeddings = content.tensor(&mut file, "token_embd.weight", device)?;
        let tok_embeddings = tok_embeddings.dequantize(device)?;
        let tok_embeddings = Embedding::new(tok_embeddings, config.hidden_dim);

        // Precompute RoPE
        // Use head_dim from config if available (important for Gemma-2 where head_dim != hidden_dim/n_heads)
        let head_dim = config
            .head_dim
            .unwrap_or(config.hidden_dim / config.n_heads);
        let (cos, sin) = precompute_freqs_cis(
            head_dim,
            config.rope_theta as f32,
            config.max_position_embeddings,
            device,
        )?;

        // Gemma-3: precompute local RoPE (different theta for sliding attention layers)
        let (cos_local, sin_local) = if let Some(local_theta) = config.rope_local_theta {
            info!("   📐 Precomputing local RoPE (theta={})", local_theta);
            let (cl, sl) = precompute_freqs_cis(
                head_dim,
                local_theta as f32,
                config.max_position_embeddings,
                device,
            )?;
            (Some(cl), Some(sl))
        } else {
            (None, None)
        };

        let neg_inf = Tensor::new(f32::NEG_INFINITY, device)?;

        // Load layers
        info!("   📥 Loading layers...");
        let mut layers = Vec::with_capacity(config.num_layers);
        let swa_pattern = config.sliding_window_pattern.unwrap_or(6);
        for i in 0..config.num_layers {
            if (i + 1) % 10 == 0 || i == config.num_layers - 1 {
                info!("      Layer {}/{}", i + 1, config.num_layers);
            }
            // Gemma-3: sliding layers use local RoPE, full layers use global RoPE
            let is_full_attention =
                config.arch == super::config::ModelArch::Gemma3 && ((i + 1) % swa_pattern == 0);
            let (layer_cos, layer_sin) =
                if config.arch == super::config::ModelArch::Gemma3 && !is_full_attention {
                    // Sliding attention layer → use local theta
                    (
                        cos_local.as_ref().unwrap_or(&cos),
                        sin_local.as_ref().unwrap_or(&sin),
                    )
                } else {
                    // Full attention layer (or non-Gemma3) → use global theta
                    (&cos, &sin)
                };
            layers.push(Self::load_layer(
                &content, &mut file, i, &config, device, layer_cos, layer_sin, &neg_inf, is_gemma2,
            )?);
        }

        // Load final norm
        info!("   📥 Loading output norm...");
        let norm = QRmsNorm::new(
            content.tensor(&mut file, "output_norm.weight", device)?,
            config.rms_norm_eps,
            device,
        )?;

        // Load output projection
        info!("   📥 Loading output projection...");
        let output = if content.tensor_infos.contains_key("output.weight") {
            QMatMul::from_qtensor(content.tensor(&mut file, "output.weight", device)?)?
        } else {
            // Tied embeddings: use transposed embeddings
            info!("      ℹ️ Using tied embeddings");
            let embed_weight = content.tensor(&mut file, "token_embd.weight", device)?;
            QMatMul::from_qtensor(embed_weight)?
        };

        // Build per-layer attention type map
        let layer_is_full_attn = if config.arch == super::config::ModelArch::Gemma3 {
            let pattern = config.sliding_window_pattern.unwrap_or(6);
            (0..config.num_layers)
                .map(|i| (i + 1) % pattern == 0) // every Nth layer is full attention
                .collect()
        } else {
            // All other architectures: all layers are the same type
            vec![true; config.num_layers]
        };

        if config.arch == super::config::ModelArch::Gemma3 {
            let full_count = layer_is_full_attn.iter().filter(|&&x| x).count();
            let sliding_count = config.num_layers - full_count;
            info!(
                "   Gemma-3 layer pattern: {} full + {} sliding (pattern={})",
                full_count,
                sliding_count,
                config.sliding_window_pattern.unwrap_or(6)
            );
        }

        info!("✅ Quantized GGUF model loaded!");

        Ok(Self {
            tok_embeddings,
            layers,
            norm,
            output,
            config,
            masks: HashMap::new(),
            sliding_masks: HashMap::new(),
            layer_is_full_attn,
            device: device.clone(),
            is_gemma2,
            lora_adapters: None,
            lora_enabled: false,
            use_hybrid_lora: false,
            profiling_enabled: false,
            last_profile: Vec::new(),
        })
    }

    fn extract_config(content: &gguf_file::Content) -> Result<BitLlamaConfig> {
        let md_get = |s: &str| {
            content
                .metadata
                .get(s)
                .ok_or_else(|| candle_core::Error::Msg(format!("Missing metadata: {}", s)))
        };

        let arch = md_get("general.architecture")?
            .to_string()
            .map_err(|_| candle_core::Error::Msg("Invalid architecture".into()))?;

        let prefix = &arch;

        // vocab_size: try arch-specific key first, then infer from tokenizer tokens array
        let vocab_size = md_get(&format!("{}.vocab_size", prefix))
            .and_then(|v| v.to_u64())
            .ok()
            .or_else(|| {
                // Fallback: get vocab size from tokenizer.ggml.tokens array length
                content.metadata.get("tokenizer.ggml.tokens").and_then(|v| {
                    if let gguf_file::Value::Array(arr) = v {
                        Some(arr.len() as u64)
                    } else {
                        None
                    }
                })
            })
            .unwrap_or(32000) as usize;

        let hidden_dim = md_get(&format!("{}.embedding_length", prefix))?
            .to_u64()
            .map_err(|_| candle_core::Error::Msg("Invalid embedding_length".into()))?
            as usize;

        let num_layers = md_get(&format!("{}.block_count", prefix))?
            .to_u64()
            .map_err(|_| candle_core::Error::Msg("Invalid block_count".into()))?
            as usize;

        let n_heads = md_get(&format!("{}.attention.head_count", prefix))?
            .to_u64()
            .map_err(|_| candle_core::Error::Msg("Invalid head_count".into()))?
            as usize;

        let n_kv_heads = md_get(&format!("{}.attention.head_count_kv", prefix))
            .and_then(|v| v.to_u64())
            .unwrap_or(n_heads as u64) as usize;

        let rope_theta = md_get(&format!("{}.rope.freq_base", prefix))
            .and_then(|v| v.to_f32())
            .unwrap_or(10000.0) as f64;
        info!("   rope_theta = {}", rope_theta);

        let max_position_embeddings = md_get(&format!("{}.context_length", prefix))
            .and_then(|v| v.to_u64())
            .unwrap_or(2048) as usize;

        let rms_norm_eps = md_get(&format!("{}.attention.layer_norm_rms_epsilon", prefix))
            .and_then(|v| v.to_f32())
            .unwrap_or(1e-5) as f64;

        let model_arch = match arch.to_lowercase().as_str() {
            "gemma2" => super::config::ModelArch::Gemma2,
            "gemma3" => super::config::ModelArch::Gemma3,
            "gemma" => super::config::ModelArch::Gemma,
            "mistral" => super::config::ModelArch::Mistral,
            "qwen2" => super::config::ModelArch::Qwen,
            _ => super::config::ModelArch::Llama,
        };
        let activation = model_arch.default_activation();

        // Gemma-2 specific
        let sliding_window = md_get(&format!("{}.attention.sliding_window", prefix))
            .and_then(|v| v.to_u64())
            .map(|v| v as usize)
            .ok();

        let attn_logit_softcapping = md_get(&format!("{}.attn_logit_softcapping", prefix))
            .and_then(|v| v.to_f32())
            .map(|v| v as f64)
            .ok();

        let final_logit_softcapping = md_get(&format!("{}.final_logit_softcapping", prefix))
            .and_then(|v| v.to_f32())
            .map(|v| v as f64)
            .ok();

        // Head dimension (important for Gemma-2 where head_dim != hidden_dim/n_heads)
        let head_dim = md_get(&format!("{}.attention.key_length", prefix))
            .and_then(|v| v.to_u64())
            .map(|v| v as usize)
            .ok();

        // Query pre-attention scalar (Gemma-2)
        let query_pre_attn_scalar = md_get(&format!("{}.attention.query_pre_attn_scalar", prefix))
            .and_then(|v| v.to_f32())
            .map(|v| v as f64)
            .ok();

        // Gemma-3 specific: local RoPE theta and sliding window pattern
        let rope_local_theta = if model_arch == super::config::ModelArch::Gemma3 {
            // Gemma-3 uses different RoPE theta for sliding vs full attention layers
            // Local (sliding) theta defaults to 10000, global (full) theta is rope_theta (1M)
            let local = md_get(&format!("{}.rope.local.freq_base", prefix))
                .and_then(|v| v.to_f32())
                .unwrap_or(10000.0) as f64;
            info!("   Gemma-3 rope_local_theta = {}", local);
            Some(local)
        } else {
            None
        };

        let sliding_window_pattern = if model_arch == super::config::ModelArch::Gemma3 {
            let pattern = md_get(&format!("{}.attention.sliding_window_pattern", prefix))
                .and_then(|v| v.to_u64())
                .unwrap_or(6) as usize;
            info!("   Gemma-3 sliding_window_pattern = {}", pattern);
            Some(pattern)
        } else {
            None
        };

        Ok(BitLlamaConfig {
            arch: model_arch,
            vocab_size,
            hidden_dim,
            num_layers,
            n_heads,
            n_kv_heads,
            intermediate_dim: None,
            inner_lr: 0.01,
            n_gpu_layers: None,
            rope_theta,
            max_position_embeddings,
            lm_head_cpu: false,
            sliding_window,
            attention_sink_size: None,
            quantization: None,
            rms_norm_eps,
            activation,
            attn_logit_softcapping,
            final_logit_softcapping,
            query_pre_attn_scalar,
            head_dim,
            rope_local_theta,
            sliding_window_pattern,
        })
    }

    fn load_layer<R: Read + Seek>(
        content: &gguf_file::Content,
        reader: &mut R,
        idx: usize,
        config: &BitLlamaConfig,
        device: &Device,
        cos: &Tensor,
        sin: &Tensor,
        neg_inf: &Tensor,
        is_gemma2: bool,
    ) -> Result<QGgufLayer> {
        let prefix = format!("blk.{}", idx);

        // Load norms
        let attention_norm = QRmsNorm::new(
            content.tensor(reader, &format!("{}.attn_norm.weight", prefix), device)?,
            config.rms_norm_eps,
            device,
        )?;

        let ffn_norm = QRmsNorm::new(
            content.tensor(reader, &format!("{}.ffn_norm.weight", prefix), device)?,
            config.rms_norm_eps,
            device,
        )?;

        // Gemma-2 specific norms
        let post_attn_norm = if is_gemma2 {
            content
                .tensor(
                    reader,
                    &format!("{}.post_attention_norm.weight", prefix),
                    device,
                )
                .ok()
                .map(|qt| QRmsNorm::new(qt, config.rms_norm_eps, device))
                .transpose()?
        } else {
            None
        };

        let post_ffn_norm = if is_gemma2 {
            content
                .tensor(reader, &format!("{}.post_ffw_norm.weight", prefix), device)
                .ok()
                .map(|qt| QRmsNorm::new(qt, config.rms_norm_eps, device))
                .transpose()?
        } else {
            None
        };

        // Load attention weights (as QMatMul)
        let attention_wq = QMatMul::from_qtensor(content.tensor(
            reader,
            &format!("{}.attn_q.weight", prefix),
            device,
        )?)?;
        let attention_wk = QMatMul::from_qtensor(content.tensor(
            reader,
            &format!("{}.attn_k.weight", prefix),
            device,
        )?)?;
        let attention_wv = QMatMul::from_qtensor(content.tensor(
            reader,
            &format!("{}.attn_v.weight", prefix),
            device,
        )?)?;
        let attention_wo = QMatMul::from_qtensor(content.tensor(
            reader,
            &format!("{}.attn_output.weight", prefix),
            device,
        )?)?;

        // Load attention biases (optional, e.g. Qwen2)
        let mut load_bias = |name: &str| -> Option<Tensor> {
            content
                .tensor(reader, name, device)
                .ok()
                .and_then(|qt| qt.dequantize(device).ok())
        };
        let attention_bq = load_bias(&format!("{}.attn_q.bias", prefix));
        let attention_bk = load_bias(&format!("{}.attn_k.bias", prefix));
        let attention_bv = load_bias(&format!("{}.attn_v.bias", prefix));
        if attention_bq.is_some() {
            info!("   🔧 Attention bias detected (Qwen2-style)");
        }

        // Load MLP weights (as QMatMul)
        let feed_forward_w1 = QMatMul::from_qtensor(content.tensor(
            reader,
            &format!("{}.ffn_gate.weight", prefix),
            device,
        )?)?;
        let feed_forward_w2 = QMatMul::from_qtensor(content.tensor(
            reader,
            &format!("{}.ffn_down.weight", prefix),
            device,
        )?)?;
        let feed_forward_w3 = QMatMul::from_qtensor(content.tensor(
            reader,
            &format!("{}.ffn_up.weight", prefix),
            device,
        )?)?;

        // Gemma-3: QK LayerNorm (per-head normalization of Q and K)
        let attn_q_norm = content
            .tensor(reader, &format!("{}.attn_q_norm.weight", prefix), device)
            .ok()
            .map(|qt| QRmsNorm::new(qt, config.rms_norm_eps, device))
            .transpose()?;
        let attn_k_norm = content
            .tensor(reader, &format!("{}.attn_k_norm.weight", prefix), device)
            .ok()
            .map(|qt| QRmsNorm::new(qt, config.rms_norm_eps, device))
            .transpose()?;
        if attn_q_norm.is_some() && idx == 0 {
            info!("   🔧 QK LayerNorm detected (Gemma-3/Phi-3 style)");
        }

        // Use head_dim from config if available (important for Gemma-2)
        let head_dim = config
            .head_dim
            .unwrap_or(config.hidden_dim / config.n_heads);

        Ok(QGgufLayer {
            attention_norm,
            ffn_norm,
            post_attn_norm,
            post_ffn_norm,
            attention_wq,
            attention_bq,
            attention_wk,
            attention_bk,
            attention_wv,
            attention_bv,
            attention_wo,
            feed_forward_w1,
            feed_forward_w2,
            feed_forward_w3,
            lora_wq: None,
            lora_wk: None,
            lora_wv: None,
            lora_wo: None,
            n_heads: config.n_heads,
            n_kv_heads: config.n_kv_heads,
            head_dim,
            cos: cos.clone(),
            sin: sin.clone(),
            neg_inf: neg_inf.clone(),
            kv_cache: None,
            kv_buffer: None,
            kv_seq_len: 0,
            kv_cache_q8: None,
            use_q8_kv_cache: false,
            attn_q_norm,
            attn_k_norm,
            attn_logit_softcapping: config.attn_logit_softcapping,
            sliding_window: config.sliding_window,
            query_pre_attn_scalar: config.query_pre_attn_scalar,
            is_gemma2,
            layer_idx: idx,
            // TTT (Test-Time Training) - disabled by default
            ttt_w_state: None,
            ttt_d_small: config.hidden_dim / 4,
            ttt_inner_lr: 0.01,
            use_ttt: false,
        })
    }

    /// Forward pass
    pub fn forward(&mut self, input_ids: &Tensor, start_pos: usize) -> Result<Tensor> {
        let (batch, seq_len) = input_ids.dims2()?;

        // Chunked prefill: candle's quantized CUDA matmul may produce NaN for batch > 8
        // when weight dimensions aren't multiples of 256 (e.g., Gemma-3 1B hidden_dim=1152).
        // Work around by splitting into chunks of 8 tokens.
        const MAX_PREFILL_CHUNK: usize = 8;
        if seq_len > MAX_PREFILL_CHUNK {
            let mut pos = start_pos;
            let mut offset = 0;
            let mut last_logits = None;
            while offset < seq_len {
                let chunk_len = (seq_len - offset).min(MAX_PREFILL_CHUNK);
                let chunk_ids = input_ids.narrow(1, offset, chunk_len)?;
                let logits = self.forward_inner(&chunk_ids, pos)?;
                pos += chunk_len;
                offset += chunk_len;
                last_logits = Some(logits);
            }
            return Ok(last_logits.unwrap());
        }

        self.forward_inner(input_ids, start_pos)
    }

    fn forward_inner(&mut self, input_ids: &Tensor, start_pos: usize) -> Result<Tensor> {
        let (_batch, seq_len) = input_ids.dims2()?;
        let profiling = self.profiling_enabled;

        // Profiling helper: sync GPU + record time
        macro_rules! prof_start {
            () => {
                if profiling {
                    // Force GPU sync to get accurate timing
                    if let Device::Cuda(dev) = &self.device {
                        dev.synchronize().ok();
                    }
                    std::time::Instant::now()
                } else {
                    std::time::Instant::now() // unused but needed for type
                }
            };
        }
        macro_rules! prof_record {
            ($profile:expr, $name:expr, $start:expr) => {
                if profiling {
                    if let Device::Cuda(dev) = &self.device {
                        dev.synchronize().ok();
                    }
                    let elapsed = $start.elapsed().as_secs_f64() * 1000.0;
                    $profile.push(($name.to_string(), elapsed));
                }
            };
        }

        let mut profile: Vec<(String, f64)> = Vec::new();
        let total_start = std::time::Instant::now();

        // Check context length limit
        let max_pos = self.config.max_position_embeddings;
        if start_pos + seq_len > max_pos {
            return Err(candle_core::Error::Msg(format!(
                "Context length exceeded: position {} + seq_len {} > max {}",
                start_pos, seq_len, max_pos
            )));
        }

        // Embed tokens
        let t = prof_start!();
        let mut hidden = self.tok_embeddings.forward(input_ids)?;

        // Gemma-2: Scale embeddings
        if self.is_gemma2 {
            let scale = (self.config.hidden_dim as f64).sqrt();
            hidden = (hidden * scale)?;
        }
        prof_record!(profile, "embedding", t);

        // Create causal masks
        let t = prof_start!();
        let is_gemma3 = self.config.arch == super::config::ModelArch::Gemma3;
        let mask = if seq_len <= 1 {
            None
        } else {
            let mask = self.get_mask(seq_len, start_pos)?;
            Some(mask)
        };
        // Gemma-3: separate full causal mask (no sliding window) for full attention layers
        let full_mask = if is_gemma3 && seq_len > 1 {
            Some(self.get_full_causal_mask_with_pos(seq_len, start_pos)?)
        } else {
            None
        };
        prof_record!(profile, "mask", t);

        // Process layers (with optional hybrid LoRA accumulation)
        let use_hybrid = self.use_hybrid_lora && self.lora_enabled;
        let mut lora_residual: Option<Tensor> = if use_hybrid {
            let (b, s) = (hidden.dim(0)?, hidden.dim(1)?);
            Some(Tensor::zeros(
                (b, s, self.config.hidden_dim),
                candle_core::DType::F32,
                &self.device,
            )?)
        } else {
            None
        };

        let n_layers = self.layers.len();
        let t_layers = prof_start!();
        for (layer_idx, layer) in self.layers.iter_mut().enumerate() {
            let t_layer = prof_start!();

            // Hybrid LoRA: accumulate LoRA perturbation from each layer
            if let Some(ref mut lr) = lora_residual {
                let x_normed = layer
                    .attention_norm
                    .forward(&hidden)?
                    .to_dtype(candle_core::DType::F32)?;
                let hidden_dim = self.config.hidden_dim;
                if let Some(ref lora) = layer.lora_wq {
                    if lora.enabled {
                        let lora_out =
                            lora.forward(&x_normed)?.to_dtype(candle_core::DType::F32)?;
                        if lora_out.dim(2)? == hidden_dim {
                            *lr = lr.add(&lora_out)?;
                        }
                    }
                }
                if let Some(ref lora) = layer.lora_wv {
                    if lora.enabled {
                        let lora_out =
                            lora.forward(&x_normed)?.to_dtype(candle_core::DType::F32)?;
                        if lora_out.dim(2)? == hidden_dim {
                            *lr = lr.add(&lora_out)?;
                        } else {
                            let out_dim = lora_out.dim(2)?;
                            let n_rep = hidden_dim / out_dim;
                            if hidden_dim % out_dim == 0 {
                                let expanded = lora_out.repeat(&[1, 1, n_rep])?;
                                *lr = lr.add(&expanded)?;
                            }
                        }
                    }
                }
            }
            // Gemma-3: per-layer mask selection (full vs sliding attention)
            let layer_mask = if is_gemma3 && self.layer_is_full_attn[layer_idx] {
                full_mask.as_ref() // Full attention layers: no sliding window
            } else {
                mask.as_ref() // Sliding layers (or non-Gemma3): use default mask
            };
            hidden = layer.forward(&hidden, layer_mask, start_pos)?;

            // Profile first, middle, and last layer
            if profiling
                && (layer_idx == 0 || layer_idx == n_layers / 2 || layer_idx == n_layers - 1)
            {
                prof_record!(profile, &format!("layer_{}", layer_idx), t_layer);
            }
        }
        prof_record!(profile, "all_layers", t_layers);

        // Final norm
        let t = prof_start!();
        hidden = self.norm.forward(&hidden)?;
        prof_record!(profile, "final_norm", t);

        // Add hybrid LoRA residual to final hidden
        if let Some(lr) = lora_residual {
            let lr_scaled = lr
                .affine(HYBRID_LORA_SCALE, 0.0)?
                .to_dtype(hidden.dtype())?;
            hidden = hidden.add(&lr_scaled)?;
        }

        // LM head (using quantized matmul for 40x speedup)
        let t = prof_start!();
        let logits = qmatmul_forward_quantized(&self.output, &hidden)?;
        prof_record!(profile, "lm_head", t);

        // Gemma-2: Final logit softcapping
        let logits = if let Some(cap) = self.config.final_logit_softcapping {
            ((logits / cap)?.tanh()? * cap)?
        } else {
            logits
        };

        if profiling {
            if let Device::Cuda(dev) = &self.device {
                dev.synchronize().ok();
            }
            let total = total_start.elapsed().as_secs_f64() * 1000.0;
            profile.push(("total".to_string(), total));
            self.last_profile = profile;
        }

        Ok(logits)
    }

    fn get_mask(&mut self, seq_len: usize, start_pos: usize) -> Result<Tensor> {
        let total_len = start_pos + seq_len;

        // For chunked prefill (start_pos > 0, seq_len > 1), mask is [seq_len, total_len]
        // For normal prefill (start_pos = 0), mask is [seq_len, seq_len]
        if start_pos > 0 && seq_len > 1 {
            // Chunked prefill: query positions are start_pos..start_pos+seq_len
            // Key positions are 0..total_len (from KV cache + current chunk)
            let sliding_window = self.config.sliding_window;
            let mask: Vec<_> = (0..seq_len)
                .flat_map(|qi| {
                    let abs_qi = start_pos + qi;
                    (0..total_len).map(move |kj| {
                        if kj > abs_qi {
                            f32::NEG_INFINITY // Causal: can't attend to future
                        } else if let Some(w) = sliding_window {
                            if abs_qi - kj >= w {
                                f32::NEG_INFINITY
                            } else {
                                0.
                            }
                        } else {
                            0.
                        }
                    })
                })
                .collect();
            return Tensor::from_vec(mask, (seq_len, total_len), &self.device);
        }

        // Standard case: [seq_len, seq_len] (cacheable)
        if let Some(mask) = self.masks.get(&seq_len) {
            return Ok(mask.clone());
        }
        let sliding_window = self.config.sliding_window;
        let mask: Vec<_> = (0..seq_len)
            .flat_map(|i| {
                (0..seq_len).map(move |j| {
                    if i < j {
                        f32::NEG_INFINITY
                    } else if let Some(w) = sliding_window {
                        if i - j >= w {
                            f32::NEG_INFINITY
                        } else {
                            0.
                        }
                    } else {
                        0.
                    }
                })
            })
            .collect();
        let mask = Tensor::from_vec(mask, (seq_len, seq_len), &self.device)?;
        self.masks.insert(seq_len, mask.clone());
        Ok(mask)
    }

    /// Get full causal mask (no sliding window) for Gemma-3 full attention layers
    fn get_full_causal_mask_with_pos(&self, seq_len: usize, start_pos: usize) -> Result<Tensor> {
        let total_len = start_pos + seq_len;
        if start_pos > 0 && seq_len > 1 {
            let mask: Vec<_> = (0..seq_len)
                .flat_map(|qi| {
                    let abs_qi = start_pos + qi;
                    (0..total_len).map(move |kj| if kj > abs_qi { f32::NEG_INFINITY } else { 0. })
                })
                .collect();
            return Tensor::from_vec(mask, (seq_len, total_len), &self.device);
        }
        self.get_full_causal_mask_cached(seq_len)
    }

    fn get_full_causal_mask_cached(&self, seq_len: usize) -> Result<Tensor> {
        // Note: can't use &mut self here easily, just compute
        let mask: Vec<_> = (0..seq_len)
            .flat_map(|i| (0..seq_len).map(move |j| if i < j { f32::NEG_INFINITY } else { 0. }))
            .collect();
        Tensor::from_vec(mask, (seq_len, seq_len), &self.device)
    }

    fn get_full_causal_mask(&mut self, seq_len: usize) -> Result<Tensor> {
        if let Some(mask) = self.sliding_masks.get(&seq_len) {
            return Ok(mask.clone());
        }
        let mask = self.get_full_causal_mask_cached(seq_len)?;
        self.sliding_masks.insert(seq_len, mask.clone());
        Ok(mask)
    }

    /// Reset KV cache
    pub fn reset_cache(&mut self) {
        for layer in &mut self.layers {
            layer.kv_cache = None;
            // Reset pre-allocated KV buffer position (keep buffer allocated)
            layer.kv_seq_len = 0;
            // Set Q8 cache to None (not just reset) to force re-initialization
            // and re-transfer of F16 cache when switching back to Q8 mode
            layer.kv_cache_q8 = None;
        }
        self.masks.clear();
        self.sliding_masks.clear();
    }

    /// Enable Q8_0 quantized KV cache for memory efficiency
    ///
    /// This reduces KV cache memory by ~50% with minimal quality loss.
    /// Only effective during decode phase (seq_len=1).
    pub fn enable_q8_kv_cache(&mut self, enable: bool) {
        for layer in &mut self.layers {
            layer.use_q8_kv_cache = enable;
        }
        if enable {
            tracing::info!("Q8_0 quantized KV cache enabled");
        }
    }

    /// Check if Q8_0 KV cache is enabled
    pub fn is_q8_kv_cache_enabled(&self) -> bool {
        self.layers
            .first()
            .map(|l| l.use_q8_kv_cache)
            .unwrap_or(false)
    }

    /// Enable TTT (Test-Time Training) refinement
    ///
    /// TTT uses online gradient descent to refine attention outputs,
    /// which can improve long-context understanding.
    ///
    /// # Arguments
    /// - `enable`: Whether to enable TTT
    /// - `inner_lr`: Optional learning rate for TTT updates (default: 0.01)
    pub fn enable_ttt(&mut self, enable: bool, inner_lr: Option<f64>) {
        let lr = inner_lr.unwrap_or(0.01);
        for layer in &mut self.layers {
            layer.use_ttt = enable;
            layer.ttt_inner_lr = lr;
        }
        if enable {
            tracing::info!("TTT refinement enabled with lr={}", lr);
        } else {
            tracing::info!("TTT refinement disabled");
        }
    }

    /// Check if TTT is enabled
    pub fn is_ttt_enabled(&self) -> bool {
        self.layers.first().map(|l| l.use_ttt).unwrap_or(false)
    }

    /// Reset TTT state (call when starting a new conversation)
    pub fn reset_ttt_state(&mut self) {
        for layer in &mut self.layers {
            layer.reset_ttt_state();
        }
        tracing::debug!("TTT state reset");
    }

    /// Get config
    pub fn config(&self) -> &BitLlamaConfig {
        &self.config
    }

    /// Load LoRA adapters from a safetensors file
    ///
    /// The file should contain tensors named like:
    /// - `layers.0.attention.wq.lora_A` / `layers.0.attention.wq.lora_B`
    /// - `layers.0.attention.wv.lora_A` / `layers.0.attention.wv.lora_B`
    ///
    /// Or HuggingFace PEFT format:
    /// - `base_model.model.model.layers.0.self_attn.q_proj.lora_A.weight`
    pub fn load_lora(&mut self, path: &str) -> Result<()> {
        use crate::layers::LoRAAdapters;

        let adapters = LoRAAdapters::load(path, &self.device)?;

        // Apply LoRA to layers based on naming convention
        for (name, lora_layer) in &adapters.layers {
            // Parse layer index and projection type from name
            // Expected formats:
            // - "layers.{idx}.attention.wq" or "layers.{idx}.self_attn.q_proj"
            if let Some((layer_idx, proj_type)) = Self::parse_lora_name(name) {
                if layer_idx < self.layers.len() {
                    let layer = &mut self.layers[layer_idx];
                    match proj_type.as_str() {
                        "wq" | "q_proj" => {
                            layer.lora_wq = Some(lora_layer.clone());
                            tracing::debug!("Applied LoRA to layer {}.wq", layer_idx);
                        }
                        "wk" | "k_proj" => {
                            layer.lora_wk = Some(lora_layer.clone());
                            tracing::debug!("Applied LoRA to layer {}.wk", layer_idx);
                        }
                        "wv" | "v_proj" => {
                            layer.lora_wv = Some(lora_layer.clone());
                            tracing::debug!("Applied LoRA to layer {}.wv", layer_idx);
                        }
                        "wo" | "o_proj" => {
                            layer.lora_wo = Some(lora_layer.clone());
                            tracing::debug!("Applied LoRA to layer {}.wo", layer_idx);
                        }
                        _ => {
                            tracing::warn!("Unknown projection type in LoRA: {}", name);
                        }
                    }
                }
            }
        }

        self.lora_adapters = Some(adapters);
        self.lora_enabled = true;

        let total_params: usize = self
            .layers
            .iter()
            .flat_map(|l| [&l.lora_wq, &l.lora_wk, &l.lora_wv, &l.lora_wo])
            .filter_map(|l| l.as_ref())
            .map(|l| l.num_parameters())
            .sum();

        tracing::info!("LoRA loaded: {} trainable parameters", total_params);
        Ok(())
    }

    /// Parse LoRA tensor name to extract layer index and projection type
    fn parse_lora_name(name: &str) -> Option<(usize, String)> {
        // Try different naming conventions
        // Format 1: "layers.{idx}.attention.{proj}"
        // Format 2: "layers.{idx}.self_attn.{proj}"
        // Format 3: "model.layers.{idx}.self_attn.{proj}"

        let parts: Vec<&str> = name.split('.').collect();

        for (i, part) in parts.iter().enumerate() {
            if *part == "layers" && i + 1 < parts.len() {
                if let Ok(idx) = parts[i + 1].parse::<usize>() {
                    // Find projection type
                    for p in &parts[i + 2..] {
                        match *p {
                            "wq" | "q_proj" => return Some((idx, "wq".to_string())),
                            "wk" | "k_proj" => return Some((idx, "wk".to_string())),
                            "wv" | "v_proj" => return Some((idx, "wv".to_string())),
                            "wo" | "o_proj" => return Some((idx, "wo".to_string())),
                            _ => continue,
                        }
                    }
                }
            }
        }
        None
    }

    /// Create LoRA adapters for this model
    ///
    /// # Arguments
    /// * `config` - LoRA configuration (rank, alpha, target modules)
    pub fn create_lora(&mut self, config: crate::layers::LoRAConfig) -> Result<()> {
        let hidden_dim = self.config.hidden_dim;
        let head_dim = self
            .config
            .head_dim
            .unwrap_or(hidden_dim / self.config.n_heads);
        let n_heads = self.config.n_heads;
        let n_kv_heads = self.config.n_kv_heads;

        let q_dim = n_heads * head_dim;
        let kv_dim = n_kv_heads * head_dim;

        for (idx, layer) in self.layers.iter_mut().enumerate() {
            // Create LoRA for enabled projections
            if config
                .target_modules
                .iter()
                .any(|t| t == "q_proj" || t == "wq")
            {
                layer.lora_wq = Some(crate::layers::LoRALayer::new(
                    hidden_dim,
                    q_dim,
                    config.rank,
                    config.alpha,
                    &self.device,
                )?);
            }
            if config
                .target_modules
                .iter()
                .any(|t| t == "k_proj" || t == "wk")
            {
                layer.lora_wk = Some(crate::layers::LoRALayer::new(
                    hidden_dim,
                    kv_dim,
                    config.rank,
                    config.alpha,
                    &self.device,
                )?);
            }
            if config
                .target_modules
                .iter()
                .any(|t| t == "v_proj" || t == "wv")
            {
                layer.lora_wv = Some(crate::layers::LoRALayer::new(
                    hidden_dim,
                    kv_dim,
                    config.rank,
                    config.alpha,
                    &self.device,
                )?);
            }
            if config
                .target_modules
                .iter()
                .any(|t| t == "o_proj" || t == "wo")
            {
                layer.lora_wo = Some(crate::layers::LoRALayer::new(
                    q_dim,
                    hidden_dim,
                    config.rank,
                    config.alpha,
                    &self.device,
                )?);
            }

            tracing::debug!("Created LoRA for layer {}", idx);
        }

        self.lora_enabled = true;

        let total_params: usize = self
            .layers
            .iter()
            .flat_map(|l| [&l.lora_wq, &l.lora_wk, &l.lora_wv, &l.lora_wo])
            .filter_map(|l| l.as_ref())
            .map(|l| l.num_parameters())
            .sum();

        tracing::info!(
            "Created LoRA with {} trainable parameters (rank={})",
            total_params,
            config.rank
        );
        Ok(())
    }

    /// Enable or disable LoRA
    pub fn enable_lora(&mut self, enable: bool) {
        self.lora_enabled = enable;
        for layer in &mut self.layers {
            if let Some(ref mut lora) = layer.lora_wq {
                lora.enabled = enable;
            }
            if let Some(ref mut lora) = layer.lora_wk {
                lora.enabled = enable;
            }
            if let Some(ref mut lora) = layer.lora_wv {
                lora.enabled = enable;
            }
            if let Some(ref mut lora) = layer.lora_wo {
                lora.enabled = enable;
            }
        }
    }

    /// Check if LoRA is enabled
    pub fn is_lora_enabled(&self) -> bool {
        self.lora_enabled
    }

    /// Enable hybrid LoRA mode (matches training path)
    ///
    /// When enabled, LoRA perturbation is accumulated across layers and added to
    /// the final hidden state, matching the training forward pass for consistent results.
    pub fn enable_hybrid_lora(&mut self, enable: bool) {
        self.use_hybrid_lora = enable;
    }

    /// Check if hybrid LoRA mode is enabled
    pub fn is_hybrid_lora_enabled(&self) -> bool {
        self.use_hybrid_lora
    }

    /// Enable profiling mode (adds CUDA sync overhead, use for debugging only)
    pub fn enable_profiling(&mut self, enable: bool) {
        self.profiling_enabled = enable;
    }

    /// Get last profile results: Vec<(component_name, duration_ms)>
    pub fn get_profile(&self) -> &[(String, f64)] {
        &self.last_profile
    }

    /// Save LoRA weights to a file
    pub fn save_lora(&self, path: &str) -> Result<()> {
        let mut tensors = std::collections::HashMap::new();

        for (idx, layer) in self.layers.iter().enumerate() {
            if let Some(ref lora) = layer.lora_wq {
                tensors.insert(
                    format!("layers.{}.attention.wq.lora_A", idx),
                    lora.lora_a.clone(),
                );
                tensors.insert(
                    format!("layers.{}.attention.wq.lora_B", idx),
                    lora.lora_b.clone(),
                );
            }
            if let Some(ref lora) = layer.lora_wk {
                tensors.insert(
                    format!("layers.{}.attention.wk.lora_A", idx),
                    lora.lora_a.clone(),
                );
                tensors.insert(
                    format!("layers.{}.attention.wk.lora_B", idx),
                    lora.lora_b.clone(),
                );
            }
            if let Some(ref lora) = layer.lora_wv {
                tensors.insert(
                    format!("layers.{}.attention.wv.lora_A", idx),
                    lora.lora_a.clone(),
                );
                tensors.insert(
                    format!("layers.{}.attention.wv.lora_B", idx),
                    lora.lora_b.clone(),
                );
            }
            if let Some(ref lora) = layer.lora_wo {
                tensors.insert(
                    format!("layers.{}.attention.wo.lora_A", idx),
                    lora.lora_a.clone(),
                );
                tensors.insert(
                    format!("layers.{}.attention.wo.lora_B", idx),
                    lora.lora_b.clone(),
                );
            }
        }

        candle_core::safetensors::save(&tensors, path)?;
        tracing::info!("Saved LoRA weights to {}", path);
        Ok(())
    }

    // =========================================================================
    // Soul API helpers (public access for PyQGgufModel)
    // =========================================================================

    /// Set LoRA on a specific layer and projection
    pub fn set_layer_lora(&mut self, layer_idx: usize, proj: &str, lora: crate::layers::LoRALayer) {
        if layer_idx < self.layers.len() {
            let layer = &mut self.layers[layer_idx];
            match proj {
                "q_proj" | "wq" => {
                    layer.lora_wq = Some(lora);
                }
                "v_proj" | "wv" => {
                    layer.lora_wv = Some(lora);
                }
                "k_proj" | "wk" => {
                    layer.lora_wk = Some(lora);
                }
                "o_proj" | "wo" => {
                    layer.lora_wo = Some(lora);
                }
                _ => {}
            }
        }
    }

    /// Clear all LoRA adapters
    pub fn clear_lora(&mut self) {
        for layer in &mut self.layers {
            layer.lora_wq = None;
            layer.lora_wk = None;
            layer.lora_wv = None;
            layer.lora_wo = None;
        }
        self.lora_enabled = false;
    }

    /// Set LoRA enabled flag
    pub fn set_lora_enabled(&mut self, enabled: bool) {
        self.lora_enabled = enabled;
    }

    /// Forward pass with trainable LoRA adapters for gradient-based training
    ///
    /// This method applies TrainableLoRAAdapters (Var-backed) to enable gradient flow
    /// through the LoRA parameters while keeping base weights frozen.
    ///
    /// # Arguments
    /// * `input_ids` - Input token IDs [batch, seq_len]
    /// * `trainable_loras` - Trainable LoRA adapters with Var-backed weights
    /// * `start_pos` - Starting position for KV cache
    ///
    /// # Returns
    /// Logits tensor with gradients flowing through LoRA paths
    pub fn forward_with_trainable_lora(
        &mut self,
        input_ids: &Tensor,
        trainable_loras: &crate::layers::TrainableLoRAAdapters,
        start_pos: usize,
    ) -> Result<Tensor> {
        let (_batch, seq_len) = input_ids.dims2()?;

        // Check context length limit
        let max_pos = self.config.max_position_embeddings;
        if start_pos + seq_len > max_pos {
            return Err(candle_core::Error::Msg(format!(
                "Context length exceeded: position {} + seq_len {} > max {}",
                start_pos, seq_len, max_pos
            )));
        }

        // Embed tokens
        let mut hidden = self.tok_embeddings.forward(input_ids)?;

        // Gemma-2: Scale embeddings
        if self.is_gemma2 {
            let scale = (self.config.hidden_dim as f64).sqrt();
            hidden = (hidden * scale)?;
        }

        // Create causal masks
        let is_gemma3 = self.config.arch == super::config::ModelArch::Gemma3;
        let mask = if seq_len <= 1 {
            None
        } else {
            let mask = self.get_mask(seq_len, start_pos)?;
            Some(mask)
        };
        let full_mask = if is_gemma3 && seq_len > 1 {
            Some(self.get_full_causal_mask(seq_len)?)
        } else {
            None
        };

        // Hybrid approach: accumulate LoRA perturbation (with grad) + run base forward (no grad)
        // LoRA Vars → lora.forward() → accumulate → add to final hidden → LM head → loss
        // This ensures gradient flows through LoRA path even though base model has no backward
        let (b_sz, _seq) = input_ids.dims2()?;
        let hidden_dim = self.config.hidden_dim;
        let mut lora_residual = Tensor::zeros(
            (b_sz, seq_len, hidden_dim),
            candle_core::DType::F32,
            &self.device,
        )?;

        for (layer_idx, layer) in self.layers.iter_mut().enumerate() {
            // Accumulate LoRA perturbation (gradient-tracked path)
            let x_normed_f32 = layer
                .attention_norm
                .forward(&hidden)?
                .to_dtype(candle_core::DType::F32)?;

            if let Some(lora) = trainable_loras.get_layer(layer_idx, "q_proj") {
                let lora_out = lora.forward(&x_normed_f32)?;
                let out_dim = lora_out.dim(2)?;
                if out_dim == hidden_dim {
                    lora_residual = lora_residual.add(&lora_out)?;
                } else if out_dim < hidden_dim && hidden_dim % out_dim == 0 {
                    let expanded = lora_out.repeat(&[1, 1, hidden_dim / out_dim])?;
                    lora_residual = lora_residual.add(&expanded)?;
                }
            }
            if let Some(lora) = trainable_loras.get_layer(layer_idx, "v_proj") {
                let lora_out = lora.forward(&x_normed_f32)?;
                let out_dim = lora_out.dim(2)?;
                if out_dim == hidden_dim {
                    lora_residual = lora_residual.add(&lora_out)?;
                } else if out_dim < hidden_dim && hidden_dim % out_dim == 0 {
                    let expanded = lora_out.repeat(&[1, 1, hidden_dim / out_dim])?;
                    lora_residual = lora_residual.add(&expanded)?;
                }
            }

            // Base forward (no gradient tracking, uses fast CUDA kernels)
            let layer_mask = if is_gemma3 && self.layer_is_full_attn[layer_idx] {
                full_mask.as_ref()
            } else {
                mask.as_ref()
            };
            hidden = layer.forward(&hidden, layer_mask, start_pos)?;
        }

        // Final norm
        hidden = self.norm.forward(&hidden)?;

        // Convert hidden to F32 for gradient-compatible LM head
        let hidden_f32 = hidden.to_dtype(candle_core::DType::F32)?;

        // Add LoRA perturbation (gradient flows through lora_residual → LoRA Vars)
        let hidden_with_lora = (hidden_f32 + lora_residual.affine(HYBRID_LORA_SCALE, 0.0)?)?;

        // LM head - use dequantized matmul for gradient support during training
        let lm_weight = match &self.output {
            QMatMul::QTensor(qt) => qt.dequantize(&self.device)?,
            QMatMul::Tensor(t) => t.to_dtype(candle_core::DType::F32)?,
            QMatMul::TensorF16(t) => t.to_dtype(candle_core::DType::F32)?,
        };
        let lm_weight_t = lm_weight.t()?;
        let logits = hidden_with_lora.broadcast_matmul(&lm_weight_t)?;

        // Gemma-2: Final logit softcapping
        let logits = if let Some(cap) = self.config.final_logit_softcapping {
            ((logits / cap)?.tanh()? * cap)?
        } else {
            logits
        };

        Ok(logits)
    }
}

/// Repeat KV heads for grouped-query attention
fn repeat_kv(x: Tensor, n_rep: usize) -> Result<Tensor> {
    if n_rep == 1 {
        return Ok(x);
    }
    // Use Tensor::repeat() for a real data copy instead of expand+reshape.
    // expand() creates a stride-0 view, which can cause issues with matmul
    // when the data layout doesn't match what CUDA kernels expect.
    let (b_sz, n_kv_heads, seq_len, head_dim) = x.dims4()?;
    // repeat along dim 1 (heads): [b, kv_heads, seq, dim] → [b, kv_heads * n_rep, seq, dim]
    // First unsqueeze to [b, kv_heads, 1, seq, dim], repeat, then reshape
    let x = x
        .unsqueeze(2)? // [b, kv_h, 1, seq, dim]
        .repeat(&[1, 1, n_rep, 1, 1])? // [b, kv_h, n_rep, seq, dim]
        .reshape((b_sz, n_kv_heads * n_rep, seq_len, head_dim))?; // [b, n_heads, seq, dim]
    Ok(x)
}

/// Precompute RoPE frequencies (duplicated for full head_dim)
fn precompute_freqs_cis(
    head_dim: usize,
    freq_base: f32,
    max_seq_len: usize,
    device: &Device,
) -> Result<(Tensor, Tensor)> {
    let half_dim = head_dim / 2;

    // Positions: [max_seq_len, 1]
    let positions: Vec<f32> = (0..max_seq_len).map(|p| p as f32).collect();
    let positions = Tensor::from_vec(positions, (max_seq_len, 1), device)?;

    // Frequencies: [1, half_dim]
    let freqs: Vec<f32> = (0..half_dim)
        .map(|i| 1.0 / (freq_base as f64).powf(2.0 * i as f64 / head_dim as f64) as f32)
        .collect();
    let freqs = Tensor::from_vec(freqs, (1, half_dim), device)?;

    // Angles: [max_seq_len, half_dim]
    let angles = positions.matmul(&freqs)?;
    let cos = angles.cos()?;
    let sin = angles.sin()?;

    // Keep as [max_seq_len, half_dim] for interleaved RoPE kernel
    // (no duplication needed - kernel indexes with half_dim stride)

    Ok((cos, sin))
}

/// Masked fill helper
fn masked_fill(on_false: &Tensor, mask: &Tensor, on_true: &Tensor) -> Result<Tensor> {
    let shape = mask.shape();
    mask.where_cond(&on_true.broadcast_as(shape.dims())?, on_false)
}

/// Rotate half for RoPE
fn rotate_half(x: &Tensor) -> Result<Tensor> {
    let last_dim = x.dims().len() - 1;
    let half = x.dim(last_dim)? / 2;
    let x1 = x.narrow(last_dim, 0, half)?;
    let x2 = x.narrow(last_dim, half, half)?;
    Tensor::cat(&[&x2.neg()?, &x1], last_dim)
}

/// Softmax using CUDA kernel (or CPU fallback)
fn softmax_last_dim_safe(x: &Tensor) -> Result<Tensor> {
    crate::kernels::fused_ops::softmax_cuda(x)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_precompute_freqs() {
        let device = Device::Cpu;
        let (cos, sin) = precompute_freqs_cis(64, 10000.0, 128, &device).unwrap();
        // RoPE returns [seq_len, head_dim/2] — no duplication for interleaved kernel
        assert_eq!(cos.dims(), &[128, 32]);
        assert_eq!(sin.dims(), &[128, 32]);
    }
}
