//! Python Bindings for BitLlama and GgufModel (PyO3)

#[cfg(feature = "python")]
use candle_core::{DType, Device, IndexOp, Tensor, Var};

#[cfg(feature = "python")]
use pyo3::prelude::*;

#[cfg(feature = "python")]
use crate::model::{BitLlama, BitLlamaConfig, GgufModel, QGgufModel};
#[cfg(feature = "python")]
use crate::optim::schedule_free::{ParamsScheduleFree, ScheduleFreeOptimizer};
#[cfg(feature = "python")]
use candle_nn::VarMap;

#[cfg(feature = "python")]
use tokenizers::Tokenizer;

// ============================================================================
// PyGgufModel - Python wrapper for GgufModel (GGUF format inference)
// ============================================================================

/// Python wrapper for GgufModel (GGUF format inference)
///
/// Example:
/// ```python
/// from cortex_rust import GgufModel
///
/// # With tokenizer (recommended)
/// model = GgufModel("model.gguf", tokenizer="tokenizer.json")
/// output = model.generate("Hello, world!", max_tokens=50)
///
/// # Without tokenizer (byte-level fallback)
/// model = GgufModel("model.gguf")
/// ```
#[cfg(feature = "python")]
#[pyclass(name = "GgufModel")]
pub struct PyGgufModel {
    inner: GgufModel,
    device: Device,
    tokenizer: Option<Tokenizer>,
    eos_token_id: i64, // End-of-sequence token ID (default: 2 for Llama)
}

#[cfg(feature = "python")]
#[pymethods]
impl PyGgufModel {
    /// Load a GGUF model
    ///
    /// Args:
    ///     path: Path to the GGUF model file
    ///     tokenizer: Path to tokenizer.json (optional but recommended)
    ///     device: Device to use ("cpu" or "cuda"). Default: "cpu"
    #[new]
    #[pyo3(signature = (path, tokenizer=None, device=None))]
    pub fn new(path: &str, tokenizer: Option<&str>, device: Option<&str>) -> PyResult<Self> {
        let device = match device {
            Some("cuda") | Some("gpu") => Device::new_cuda(0).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Failed to initialize CUDA: {}. Try device='cpu'",
                    e
                ))
            })?,
            Some("cpu") | None => Device::Cpu,
            Some(unknown) => {
                return Err(pyo3::exceptions::PyValueError::new_err(format!(
                    "Unknown device: '{}'. Use 'cpu' or 'cuda'",
                    unknown
                )))
            }
        };

        let model = GgufModel::load(path, &device).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!(
                "Failed to load model '{}': {}",
                path, e
            ))
        })?;

        // Load tokenizer if provided
        let tokenizer = if let Some(tok_path) = tokenizer {
            Some(Tokenizer::from_file(tok_path).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Failed to load tokenizer '{}': {}",
                    tok_path, e
                ))
            })?)
        } else {
            None
        };

        // Get EOS token ID from tokenizer (try common names, fallback to 2)
        // Supports: Llama-2 (</s>), Gemma (<eos>), GPT (<|endoftext|>), Phi (<|end|>),
        //           Llama-3 (<|eot_id|>, <|end_of_text|>), Qwen (<|im_end|>)
        let eos_token_id = if let Some(ref tok) = tokenizer {
            tok.token_to_id("</s>")
                .or_else(|| tok.token_to_id("<eos>"))
                .or_else(|| tok.token_to_id("<end_of_turn>")) // Gemma-2/3
                .or_else(|| tok.token_to_id("<|endoftext|>"))
                .or_else(|| tok.token_to_id("<|end|>"))
                .or_else(|| tok.token_to_id("<|eot_id|>")) // Llama-3
                .or_else(|| tok.token_to_id("<|end_of_text|>")) // Llama-3 alt
                .or_else(|| tok.token_to_id("<|im_end|>")) // Qwen/ChatML
                .map(|id| id as i64)
                .unwrap_or(2) // Default to 2 (common for Llama-2)
        } else {
            2 // Default EOS token for Llama models
        };

        Ok(Self {
            inner: model,
            device,
            tokenizer,
            eos_token_id,
        })
    }

    /// Get model configuration info
    #[getter]
    pub fn config(&self) -> PyResult<PyGgufConfig> {
        let cfg = self.inner.config();
        Ok(PyGgufConfig {
            vocab_size: cfg.vocab_size,
            hidden_dim: cfg.hidden_dim,
            num_layers: cfg.num_layers,
            n_heads: cfg.n_heads,
            n_kv_heads: cfg.n_kv_heads,
        })
    }

    /// Forward pass through the model
    ///
    /// Args:
    ///     tokens: List of token IDs
    ///     start_pos: Starting position for KV cache
    ///
    /// Returns:
    ///     Logits as a list of floats (flattened)
    #[pyo3(signature = (tokens, start_pos=0))]
    pub fn forward(&mut self, tokens: Vec<i64>, start_pos: usize) -> PyResult<Vec<f32>> {
        if tokens.is_empty() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "tokens cannot be empty",
            ));
        }
        let seq_len = tokens.len();
        let input = Tensor::from_vec(tokens, (1, seq_len), &self.device)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let logits = self
            .inner
            .forward(&input, start_pos)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // Return last token's logits
        let (_, seq_len, _vocab_size) = logits
            .dims3()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let last_logits = logits
            .narrow(1, seq_len - 1, 1)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
            .squeeze(1)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
            .squeeze(0)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let result = last_logits
            .to_vec1::<f32>()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        Ok(result)
    }

    /// Generate text from a prompt
    ///
    /// Args:
    ///     prompt: Text prompt to continue
    ///     max_tokens: Maximum number of tokens to generate
    ///     temperature: Sampling temperature (0.0 = greedy, 1.0 = full distribution)
    ///     top_k: Top-k sampling (0 = disabled)
    ///     top_p: Top-p (nucleus) sampling (1.0 = disabled)
    ///
    /// Returns:
    ///     Generated text (excluding the prompt)
    #[pyo3(signature = (prompt, max_tokens=50, temperature=0.7, top_k=40, top_p=0.9, repetition_penalty=1.1))]
    pub fn generate(
        &mut self,
        py: Python,
        prompt: &str,
        max_tokens: usize,
        temperature: f32,
        top_k: usize,
        top_p: f32,
        repetition_penalty: f32,
    ) -> PyResult<String> {
        py.allow_threads(|| {
            self.generate_inner(
                prompt,
                max_tokens,
                temperature,
                top_k,
                top_p,
                repetition_penalty,
            )
        })
    }

    /// Reset the KV cache (call between conversations)
    pub fn reset_cache(&mut self) {
        self.inner.reset_cache();
    }

    // =========================================================================
    // TTT (Test-Time Training) API
    // =========================================================================

    /// Enable TTT (Test-Time Training) mode
    ///
    /// TTT allows the model to learn and adapt during inference.
    /// The model will update internal weights based on input patterns.
    ///
    /// Args:
    ///     layers: Number of layers to enable TTT for (from the end).
    ///             None = all layers, 4 = last 4 layers (recommended)
    ///     learning_rate: TTT learning rate (default: 0.01)
    ///
    /// Example:
    ///     model.enable_ttt(layers=4, learning_rate=0.01)
    ///     output1 = model.generate("My name is Alice")
    ///     output2 = model.generate("What is my name?")  # Should remember!
    #[pyo3(signature = (layers=None, learning_rate=0.01))]
    pub fn enable_ttt(&mut self, layers: Option<usize>, learning_rate: f64) {
        let num_layers = self.inner.config().num_layers;
        let range = if let Some(n) = layers {
            let start = num_layers.saturating_sub(n);
            Some(start..num_layers)
        } else {
            None
        };
        self.inner.enable_ttt(range, learning_rate);
    }

    /// Disable TTT mode
    pub fn disable_ttt(&mut self) {
        self.inner.disable_ttt();
    }

    /// Reset TTT state (forget learned patterns)
    pub fn reset_ttt_state(&mut self) {
        self.inner.reset_ttt_state();
    }

    /// Check if TTT is enabled
    #[getter]
    pub fn ttt_enabled(&self) -> bool {
        self.inner.is_ttt_enabled()
    }

    /// Generate tokens and return as list (for streaming in Python)
    ///
    /// Use with a Python wrapper for streaming:
    /// ```python
    /// def stream(model, prompt, **kwargs):
    ///     tokens = model.generate_tokens_list(prompt, **kwargs)
    ///     for token in tokens:
    ///         yield token
    /// ```
    #[pyo3(signature = (prompt, max_tokens=50, temperature=0.7, top_k=40, top_p=0.9, repetition_penalty=1.1))]
    pub fn generate_tokens_list(
        &mut self,
        prompt: &str,
        max_tokens: usize,
        temperature: f32,
        top_k: usize,
        top_p: f32,
        repetition_penalty: f32,
    ) -> PyResult<Vec<String>> {
        // Tokenize prompt
        let prompt_tokens = if let Some(ref tokenizer) = self.tokenizer {
            let encoding = tokenizer.encode(prompt, true).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Tokenization failed: {}", e))
            })?;
            let ids: Vec<i64> = encoding.get_ids().iter().map(|&x| x as i64).collect();
            if ids.is_empty() {
                vec![1_i64]
            } else {
                ids
            }
        } else {
            let bytes: Vec<i64> = prompt.bytes().map(|b| b as i64).collect();
            if bytes.is_empty() {
                vec![1_i64]
            } else {
                bytes
            }
        };

        let mut tokens = prompt_tokens.clone();
        let mut result = Vec::new();

        // Prefill
        let input = Tensor::from_vec(
            prompt_tokens.clone(),
            (1, prompt_tokens.len()),
            &self.device,
        )
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let logits = self
            .inner
            .forward(&input, 0)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let first_token = self.sample_token(
            &logits,
            &tokens,
            temperature,
            top_k,
            top_p,
            repetition_penalty,
        )?;

        // Check if first token is EOS
        if first_token == self.eos_token_id {
            return Ok(result);
        }

        tokens.push(first_token);
        result.push(self.decode_single_token(first_token)?);

        // Decode loop
        for _ in 1..max_tokens {
            let pos = tokens.len() - 1;
            let last_token = *tokens.last().unwrap();

            let input = Tensor::from_vec(vec![last_token], (1, 1), &self.device)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let logits = self
                .inner
                .forward(&input, pos)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let next_token = self.sample_token(
                &logits,
                &tokens,
                temperature,
                top_k,
                top_p,
                repetition_penalty,
            )?;

            // Stop on EOS token (detected from tokenizer)
            if next_token == self.eos_token_id {
                break;
            }

            tokens.push(next_token);
            result.push(self.decode_single_token(next_token)?);
        }

        Ok(result)
    }

    /// Generate with callback for each token (true streaming)
    ///
    /// Args:
    ///     prompt: Text prompt
    ///     callback: Python function called with each token string
    ///     max_tokens, temperature, top_k, top_p: Generation params
    ///
    /// Example:
    ///     model.generate_with_callback("Hello", lambda t: print(t, end="", flush=True))
    #[pyo3(signature = (prompt, callback, max_tokens=50, temperature=0.7, top_k=40, top_p=0.9, repetition_penalty=1.1))]
    pub fn generate_with_callback(
        &mut self,
        py: Python,
        prompt: &str,
        callback: PyObject,
        max_tokens: usize,
        temperature: f32,
        top_k: usize,
        top_p: f32,
        repetition_penalty: f32,
    ) -> PyResult<String> {
        // Tokenize prompt
        let prompt_tokens = if let Some(ref tokenizer) = self.tokenizer {
            let encoding = tokenizer.encode(prompt, true).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Tokenization failed: {}", e))
            })?;
            let ids: Vec<i64> = encoding.get_ids().iter().map(|&x| x as i64).collect();
            if ids.is_empty() {
                vec![1_i64]
            } else {
                ids
            }
        } else {
            let bytes: Vec<i64> = prompt.bytes().map(|b| b as i64).collect();
            if bytes.is_empty() {
                vec![1_i64]
            } else {
                bytes
            }
        };

        let mut tokens = prompt_tokens.clone();
        let mut full_output = String::new();

        // Prefill
        let input = Tensor::from_vec(
            prompt_tokens.clone(),
            (1, prompt_tokens.len()),
            &self.device,
        )
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let logits = self
            .inner
            .forward(&input, 0)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let first_token = self.sample_token(
            &logits,
            &tokens,
            temperature,
            top_k,
            top_p,
            repetition_penalty,
        )?;

        // Check if first token is EOS
        if first_token == self.eos_token_id {
            return Ok(full_output);
        }

        tokens.push(first_token);
        let token_str = self.decode_single_token(first_token)?;
        full_output.push_str(&token_str);
        callback.call1(py, (token_str,))?;

        // Decode loop
        for _ in 1..max_tokens {
            let pos = tokens.len() - 1;
            let last_token = *tokens.last().unwrap();

            let input = Tensor::from_vec(vec![last_token], (1, 1), &self.device)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let logits = self
                .inner
                .forward(&input, pos)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let next_token = self.sample_token(
                &logits,
                &tokens,
                temperature,
                top_k,
                top_p,
                repetition_penalty,
            )?;

            // Stop on EOS token (detected from tokenizer)
            if next_token == self.eos_token_id {
                break;
            }

            tokens.push(next_token);
            let token_str = self.decode_single_token(next_token)?;
            full_output.push_str(&token_str);
            callback.call1(py, (token_str,))?;
        }

        Ok(full_output)
    }
}

#[cfg(feature = "python")]
impl PyGgufModel {
    fn decode_single_token(&self, token: i64) -> PyResult<String> {
        if let Some(ref tokenizer) = self.tokenizer {
            tokenizer
                .decode(&[token as u32], false)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))
        } else {
            Ok(if token >= 32 && token < 127 {
                (token as u8 as char).to_string()
            } else if token == 10 {
                "\n".to_string()
            } else {
                String::new()
            })
        }
    }
}

#[cfg(feature = "python")]
impl PyGgufModel {
    fn generate_inner(
        &mut self,
        prompt: &str,
        max_tokens: usize,
        temperature: f32,
        top_k: usize,
        top_p: f32,
        repetition_penalty: f32,
    ) -> PyResult<String> {
        // Tokenize prompt (with special tokens like BOS)
        let (prompt_tokens, use_tokenizer) = if let Some(ref tokenizer) = self.tokenizer {
            let encoding = tokenizer.encode(prompt, true).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Tokenization failed: {}", e))
            })?;
            let ids: Vec<i64> = encoding.get_ids().iter().map(|&x| x as i64).collect();
            // Handle empty prompt: use BOS token (1) as default
            if ids.is_empty() {
                (vec![1_i64], true) // BOS token
            } else {
                (ids, true)
            }
        } else {
            // Fallback to byte-level tokenization
            let bytes: Vec<i64> = prompt.bytes().map(|b| b as i64).collect();
            if bytes.is_empty() {
                (vec![1_i64], false) // BOS token
            } else {
                (bytes, false)
            }
        };

        let mut tokens = prompt_tokens.clone();
        let prompt_len = tokens.len();

        // Prefill
        let input = Tensor::from_vec(tokens.clone(), (1, tokens.len()), &self.device)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let logits = self
            .inner
            .forward(&input, 0)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let first_token = self.sample_token(
            &logits,
            &tokens,
            temperature,
            top_k,
            top_p,
            repetition_penalty,
        )?;

        // Check if first token is EOS
        if first_token == self.eos_token_id {
            // Return empty string if model immediately outputs EOS
            return Ok(String::new());
        }
        tokens.push(first_token);

        // Decode loop
        for _ in 1..max_tokens {
            // Start from 1 since we already have first_token
            let pos = tokens.len() - 1;
            let last_token = tokens[pos];

            let input = Tensor::from_vec(vec![last_token], (1, 1), &self.device)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let logits = self
                .inner
                .forward(&input, pos)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let next_token = self.sample_token(
                &logits,
                &tokens,
                temperature,
                top_k,
                top_p,
                repetition_penalty,
            )?;

            // Stop on EOS token (detected from tokenizer)
            if next_token == self.eos_token_id {
                break;
            }

            tokens.push(next_token);
        }

        // Decode output
        let generated_tokens: Vec<u32> =
            tokens.iter().skip(prompt_len).map(|&t| t as u32).collect();

        if use_tokenizer {
            let tokenizer = self.tokenizer.as_ref().unwrap();
            let output = tokenizer.decode(&generated_tokens, true).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Decoding failed: {}", e))
            })?;
            Ok(output)
        } else {
            // Fallback byte-level decoding
            let output: String = generated_tokens
                .iter()
                .filter_map(|&t| {
                    if t >= 32 && t < 127 {
                        Some(t as u8 as char)
                    } else if t == 10 {
                        Some('\n')
                    } else {
                        None
                    }
                })
                .collect();
            Ok(output)
        }
    }

    /// Optimized sampling: avoids GPU→CPU full-vocab copy when possible.
    fn sample_token(
        &self,
        logits: &Tensor,
        generated_tokens: &[i64],
        temperature: f32,
        top_k: usize,
        top_p: f32,
        repetition_penalty: f32,
    ) -> PyResult<i64> {
        let (_, seq_len, _) = logits
            .dims3()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let last_logits = logits
            .narrow(1, seq_len - 1, 1)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
            .squeeze(1)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
            .squeeze(0)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // === Fast path: Greedy sampling on GPU ===
        if temperature < 0.01 {
            if repetition_penalty == 1.0 || generated_tokens.is_empty() {
                let max_idx = last_logits
                    .argmax(0)
                    .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
                    .to_scalar::<u32>()
                    .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
                return Ok(max_idx as i64);
            }

            let mut logits_vec = last_logits
                .to_vec1::<f32>()
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
            for &token in generated_tokens {
                if token >= 0 && (token as usize) < logits_vec.len() {
                    let idx = token as usize;
                    if logits_vec[idx] > 0.0 {
                        logits_vec[idx] /= repetition_penalty;
                    } else {
                        logits_vec[idx] *= repetition_penalty;
                    }
                }
            }
            let max_idx = logits_vec
                .iter()
                .enumerate()
                .max_by(|a, b| a.1.partial_cmp(b.1).unwrap_or(std::cmp::Ordering::Equal))
                .map(|(i, _)| i)
                .unwrap_or(0);
            return Ok(max_idx as i64);
        }

        // === Slow path: Full CPU sampling ===
        use rand::Rng;

        let mut logits_vec = last_logits
            .to_vec1::<f32>()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        if repetition_penalty != 1.0 {
            for &token in generated_tokens {
                if token >= 0 && (token as usize) < logits_vec.len() {
                    let idx = token as usize;
                    if logits_vec[idx] > 0.0 {
                        logits_vec[idx] /= repetition_penalty;
                    } else {
                        logits_vec[idx] *= repetition_penalty;
                    }
                }
            }
        }

        for logit in &mut logits_vec {
            *logit /= temperature;
        }

        if top_k > 0 && top_k < logits_vec.len() {
            let mut indexed: Vec<(usize, f32)> = logits_vec.iter().cloned().enumerate().collect();
            indexed.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
            let threshold = indexed[top_k - 1].1;
            for logit in &mut logits_vec {
                if *logit < threshold {
                    *logit = f32::NEG_INFINITY;
                }
            }
        }

        let max_logit = logits_vec.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
        let exp_sum: f32 = logits_vec.iter().map(|&x| (x - max_logit).exp()).sum();
        let probs: Vec<f32> = logits_vec
            .iter()
            .map(|&x| (x - max_logit).exp() / exp_sum)
            .collect();

        let probs = if top_p < 1.0 {
            let mut indexed: Vec<(usize, f32)> = probs.iter().cloned().enumerate().collect();
            indexed.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
            let mut cumsum = 0.0;
            let mut cutoff_idx = indexed.len();
            for (i, (_, p)) in indexed.iter().enumerate() {
                cumsum += p;
                if cumsum > top_p {
                    cutoff_idx = i + 1;
                    break;
                }
            }
            let mut filtered = vec![0.0; probs.len()];
            for (idx, p) in indexed.iter().take(cutoff_idx) {
                filtered[*idx] = *p;
            }
            let sum: f32 = filtered.iter().sum();
            if sum > 0.0 {
                filtered.iter().map(|&x| x / sum).collect()
            } else {
                probs
            }
        } else {
            probs
        };

        let mut rng = rand::thread_rng();
        let r: f32 = rng.gen();
        let mut cumsum = 0.0;
        for (i, &p) in probs.iter().enumerate() {
            cumsum += p;
            if r < cumsum {
                return Ok(i as i64);
            }
        }

        Ok((probs.len() - 1) as i64)
    }
}

/// Model configuration (read-only)
#[cfg(feature = "python")]
#[pyclass(name = "GgufConfig")]
pub struct PyGgufConfig {
    #[pyo3(get)]
    pub vocab_size: usize,
    #[pyo3(get)]
    pub hidden_dim: usize,
    #[pyo3(get)]
    pub num_layers: usize,
    #[pyo3(get)]
    pub n_heads: usize,
    #[pyo3(get)]
    pub n_kv_heads: usize,
}

// ============================================================================
// PyBitLlama - Original BitLlama wrapper (safetensors format)
// ============================================================================

/// Python wrapper for BitLlama model (Inference)
#[cfg(feature = "python")]
#[pyclass(name = "BitLlama")]
pub struct PyBitLlama {
    inner: BitLlama,
    w_states: Vec<Tensor>,
    tokenizer: Option<Tokenizer>,
}

#[cfg(feature = "python")]
#[pymethods]
impl PyBitLlama {
    #[new]
    #[pyo3(signature = (config, checkpoint_path, device=None, tokenizer_path=None))]
    pub fn new(
        config: BitLlamaConfig,
        checkpoint_path: &str,
        device: Option<&str>,
        tokenizer_path: Option<&str>,
    ) -> PyResult<Self> {
        let _device = match device {
            Some("cuda") => candle_core::Device::new_cuda(0).map_err(|e| {
                pyo3::exceptions::PyValueError::new_err(format!("CUDA error: {}", e))
            })?,
            Some("cpu") | None => candle_core::Device::Cpu,
            Some(unknown) => {
                return Err(pyo3::exceptions::PyValueError::new_err(format!(
                    "Unsupported device: {}. Use 'cpu' or 'cuda'",
                    unknown
                )))
            }
        };

        // Always load to CPU first, then selectively move to GPU in llama.rs
        // This enables hybrid offloading (n_gpu_layers)
        let vb = unsafe {
            candle_nn::VarBuilder::from_mmaped_safetensors(
                &[checkpoint_path],
                DType::F32,
                &candle_core::Device::Cpu,
            )
            .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?
        };

        let mut model = BitLlama::load(config.clone(), vb)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        model
            .precompute_packed()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // w_states should match each layer's device for Hybrid Offloading
        let d_small = config.hidden_dim / 4;
        let mut w_states = Vec::new();
        for layer in &model.layers {
            let layer_device = layer.device();
            let w = Tensor::zeros((d_small, d_small), DType::F32, layer_device)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
            w_states.push(w);
        }

        // Load tokenizer if path provided
        let tokenizer = if let Some(tok_path) = tokenizer_path {
            match Tokenizer::from_file(tok_path) {
                Ok(tok) => Some(tok),
                Err(e) => {
                    return Err(pyo3::exceptions::PyValueError::new_err(format!(
                        "Failed to load tokenizer: {}",
                        e
                    )))
                }
            }
        } else {
            None
        };

        Ok(Self {
            inner: model,
            w_states,
            tokenizer,
        })
    }

    pub fn forward(&mut self, token_id: u32) -> PyResult<Vec<f32>> {
        let device = self.inner.embedding.embeddings().device();
        let input = Tensor::new(&[token_id], device)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let logits = self
            .inner
            .forward_one(&input, &mut self.w_states)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let logits_vec = logits
            .flatten_all()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
            .to_vec1::<f32>()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        Ok(logits_vec)
    }

    #[pyo3(signature = (prompt, max_tokens))]
    pub fn generate(&mut self, py: Python, prompt: &str, max_tokens: usize) -> PyResult<String> {
        // Check if tokenizer is available and encode prompt
        let prompt_tokens = {
            let tokenizer = self.tokenizer.as_ref().ok_or_else(|| {
                pyo3::exceptions::PyValueError::new_err(
                    "Tokenizer not available. Please provide tokenizer_path during initialization.",
                )
            })?;

            // 1. Encode prompt to token IDs
            let encoding = tokenizer.encode(prompt, true).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to encode prompt: {}", e))
            })?;

            let tokens: Vec<u32> = encoding.get_ids().to_vec();

            if tokens.is_empty() {
                return Err(pyo3::exceptions::PyValueError::new_err(
                    "Prompt encoded to empty token list",
                ));
            }

            tokens
        };

        // 2. Generate tokens using the parent generate_tokens implementation
        let generated_tokens = self.generate_tokens(py, prompt_tokens.clone(), max_tokens)?;

        // 3. Decode output tokens to string
        let tokenizer = self.tokenizer.as_ref().ok_or_else(|| {
            pyo3::exceptions::PyValueError::new_err(
                "Tokenizer not available. Please provide tokenizer_path during initialization.",
            )
        })?;

        // Remove the prompt tokens from the result, keeping only the newly generated ones
        let new_tokens: Vec<u32> = generated_tokens
            .iter()
            .skip(prompt_tokens.len())
            .copied()
            .collect();

        let decoded = tokenizer.decode(&new_tokens, true).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to decode tokens: {}", e))
        })?;

        Ok(decoded)
    }

    pub fn generate_tokens(
        &mut self,
        py: Python,
        start_tokens: Vec<u32>,
        max_new_tokens: usize,
    ) -> PyResult<Vec<u32>> {
        py.allow_threads(move || {
            let device = self.inner.embedding.embeddings().device().clone();
            let mut current_tokens = start_tokens.clone();

            // 1. Prefill
            let input = Tensor::new(start_tokens.as_slice(), &device)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
                .unsqueeze(0) // Batch size 1
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let logits = self
                .inner
                .forward(&input, &mut self.w_states)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            // Sample first token from last position
            let (_b, seq_len, _v) = logits
                .dims3()
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
            let last_logits = logits
                .i((0, seq_len - 1))
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let next_token = last_logits
                .argmax(0)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
                .to_scalar::<u32>()
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            current_tokens.push(next_token);

            // 2. Decode Loop
            for _ in 1..max_new_tokens {
                let last_token = *current_tokens.last().unwrap();
                let input = Tensor::new(&[last_token], &device)
                    .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

                let logits = self
                    .inner
                    .forward_one(&input, &mut self.w_states)
                    .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

                let logits_v = logits
                    .flatten_all()
                    .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

                let next_token = logits_v
                    .argmax(0)
                    .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
                    .to_scalar::<u32>()
                    .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

                current_tokens.push(next_token);
            }

            Ok(current_tokens)
        })
    }
}

/// Python wrapper for BitLlama model (Training)
#[cfg(feature = "python")]
#[pyclass(name = "PyTrainer")]
pub struct PyTrainer {
    model: BitLlama,
    varmap: VarMap,
    optimizer: ScheduleFreeOptimizer,
    sorted_vars: Vec<Var>, // For deterministic gradient ordering
}

#[cfg(feature = "python")]
#[pymethods]
impl PyTrainer {
    #[new]
    #[pyo3(signature = (config, checkpoint_path=None, device=None))]
    pub fn new(
        config: BitLlamaConfig,
        checkpoint_path: Option<&str>,
        device: Option<&str>,
    ) -> PyResult<Self> {
        let device = match device {
            Some("cuda") => candle_core::Device::new_cuda(0).map_err(|e| {
                pyo3::exceptions::PyValueError::new_err(format!("CUDA error: {}", e))
            })?,
            Some("cpu") | None => candle_core::Device::Cpu,
            Some(unknown) => {
                return Err(pyo3::exceptions::PyValueError::new_err(format!(
                    "Unsupported device: {}. Use 'cpu' or 'cuda'",
                    unknown
                )))
            }
        };

        let mut varmap = VarMap::new();
        let vb = candle_nn::VarBuilder::from_varmap(&varmap, DType::F32, &device);
        // Note: We use clone() heavily for config here.
        let model = BitLlama::load(config, vb)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // Load Weights if provided
        if let Some(path) = checkpoint_path {
            varmap.load(path).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to load params: {}", e))
            })?;
        }

        // Initialize Optimizer
        // CRITICAL: Sort variables by name to ensure stable order for optimizer mapping
        let data = varmap.data().lock().unwrap();
        let mut named_vars: Vec<_> = data.iter().map(|(n, v)| (n.clone(), v.clone())).collect();
        // Drop lock before sorting/processing to minimize hold time
        drop(data);

        named_vars.sort_by(|a, b| a.0.cmp(&b.0));

        let vars: Vec<Var> = named_vars.iter().map(|(_, v)| v.clone()).collect();
        let sorted_vars = vars.clone();

        let params = ParamsScheduleFree {
            lr: 0.002,
            ..Default::default()
        };
        let optimizer = ScheduleFreeOptimizer::new(vars, params)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        Ok(Self {
            model,
            varmap,
            optimizer,
            sorted_vars,
        })
    }

    pub fn set_learning_rate(&mut self, lr: f64) {
        self.optimizer.set_learning_rate(lr);
    }

    #[pyo3(signature = (py_input_ids, py_targets))]
    pub fn train_step(
        &mut self,
        py: Python,
        py_input_ids: Vec<u32>,
        py_targets: Vec<u32>,
    ) -> PyResult<f64> {
        py.allow_threads(move || {
            let device = self.model.embedding.embeddings().device();
            let input_tensor = Tensor::new(py_input_ids.as_slice(), device)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
                .unsqueeze(0) // Batch dim 1
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
            let target_tensor = Tensor::new(py_targets.as_slice(), device)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
                .unsqueeze(0)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            // 1. Pre-step
            self.optimizer
                .pre_step()
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            // 2. Forward
            // Create ephemeral w_states (zeroed) for this chunk
            let d_small = self.model.config.hidden_dim / 4;
            let mut w_states = Vec::new();
            for _ in 0..self.model.config.num_layers {
                let w = Tensor::zeros((d_small, d_small), DType::F32, device)
                    .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
                w_states.push(w);
            }

            let seq_len = py_input_ids.len();

            let logits = self
                .model
                .forward_chunkwise(&input_tensor, &mut w_states, seq_len)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            // 3. Loss
            let b_sz = 1;
            let logits = logits
                .reshape((b_sz * seq_len, logits.dim(2).unwrap()))
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
            let targets = target_tensor
                .reshape((b_sz * seq_len,))
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let loss = candle_nn::loss::cross_entropy(&logits, &targets)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            // 4. Backward
            let grads_store = loss
                .backward()
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            // 5. Collect Gradients in determinstic order
            let mut grad_tensors = Vec::new();
            for var in &self.sorted_vars {
                if let Some(g) = grads_store.get(var) {
                    grad_tensors.push(g.clone());
                } else {
                    return Err(pyo3::exceptions::PyRuntimeError::new_err(
                        "Missing gradient for a variable. Graph disconnected?",
                    ));
                }
            }

            // 6. Optimizer Step
            self.optimizer
                .step(&grad_tensors)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            // 7. Return Loss
            let loss_val = loss
                .to_scalar::<f32>()
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
                as f64;
            Ok(loss_val)
        })
    }

    #[pyo3(signature = (path))]
    pub fn save_checkpoint(&self, path: &str) -> PyResult<()> {
        self.varmap
            .save(path)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // Save Optimizer State (Z)
        // Use sorted_vars to ensure same order as self.optimizer.z
        let mut z_map = std::collections::HashMap::new();

        let data = self.varmap.data().lock().unwrap();
        // We need to map var -> name to key the map.
        // Wait, saving requires "name" -> "tensor".
        // self.sorted_vars is just tensors.
        // But `data` (HashMap) has names.
        // Efficient way:
        // Iterate `data` and find index in `sorted_vars`? No, slow.
        // Better:
        // Re-construct the sorted list of (name, var) pairs similarly to `new`.
        // Since `Var` is RefCell/Arc id based, if we sort by name again, we get same order.
        let mut named_vars: Vec<_> = data.iter().collect();
        named_vars.sort_by(|a, b| a.0.cmp(b.0));

        for (i, (name, _var)) in named_vars.iter().enumerate() {
            if i < self.optimizer.z.len() {
                z_map.insert(format!("{}.z", name), self.optimizer.z[i].clone());
            }
        }

        let optim_path = format!("{}.optim", path);
        candle_core::safetensors::save(&z_map, &optim_path)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        Ok(())
    }
}

// ============================================================================
// PyQGgufModel - Memory-efficient quantized GGUF model (for 8GB VRAM)
// ============================================================================

/// Memory-efficient quantized GGUF model for inference
///
/// This model keeps weights in quantized format, reducing VRAM usage significantly:
/// - 7B Q4_K_M: ~4GB VRAM (vs ~28GB for dequantized)
///
/// Example:
/// ```python
/// from cortex_rust import QGgufModel
///
/// # Load quantized model (stays in quantized format)
/// model = QGgufModel("model-7b-q4_k_m.gguf", tokenizer="tokenizer.json", device="cuda")
/// output = model.generate("Hello!", max_tokens=50)
/// ```
#[cfg(feature = "python")]
#[pyclass(name = "QGgufModel")]
pub struct PyQGgufModel {
    inner: QGgufModel,
    device: Device,
    tokenizer: Option<Tokenizer>,
    eos_token_id: i64,
    /// Trainable LoRA adapters for online learning (Soul)
    soul_lora: Option<crate::layers::TrainableLoRAAdapters>,
    /// AdamW optimizer for Soul learning
    soul_optimizer: Option<crate::layers::AdamW>,
    /// Soul learning rate
    soul_lr: f64,
    /// Soul LoRA rank
    soul_rank: usize,
}

#[cfg(feature = "python")]
#[pymethods]
impl PyQGgufModel {
    /// Load a quantized GGUF model (memory-efficient)
    ///
    /// Args:
    ///     path: Path to the GGUF model file
    ///     tokenizer: Path to tokenizer.json (optional but recommended)
    ///     device: Device to use ("cpu" or "cuda"). Default: "cpu"
    #[new]
    #[pyo3(signature = (path, tokenizer=None, device=None))]
    pub fn new(path: &str, tokenizer: Option<&str>, device: Option<&str>) -> PyResult<Self> {
        let device = match device {
            Some("cuda") | Some("gpu") => Device::new_cuda(0).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Failed to initialize CUDA: {}. Try device='cpu'",
                    e
                ))
            })?,
            Some("cpu") | None => Device::Cpu,
            Some(unknown) => {
                return Err(pyo3::exceptions::PyValueError::new_err(format!(
                    "Unknown device: '{}'. Use 'cpu' or 'cuda'",
                    unknown
                )))
            }
        };

        let model = QGgufModel::load(path, &device).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!(
                "Failed to load quantized model '{}': {}",
                path, e
            ))
        })?;

        // Load tokenizer if provided
        let tokenizer = if let Some(tok_path) = tokenizer {
            Some(Tokenizer::from_file(tok_path).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Failed to load tokenizer '{}': {}",
                    tok_path, e
                ))
            })?)
        } else {
            None
        };

        // Get EOS token ID from tokenizer
        // Supports: Llama-2 (</s>), Gemma (<eos>), GPT (<|endoftext|>), Phi (<|end|>),
        //           Llama-3 (<|eot_id|>, <|end_of_text|>), Qwen (<|im_end|>)
        let eos_token_id = if let Some(ref tok) = tokenizer {
            tok.token_to_id("</s>")
                .or_else(|| tok.token_to_id("<eos>"))
                .or_else(|| tok.token_to_id("<end_of_turn>")) // Gemma-2/3
                .or_else(|| tok.token_to_id("<|endoftext|>"))
                .or_else(|| tok.token_to_id("<|end|>"))
                .or_else(|| tok.token_to_id("<|eot_id|>")) // Llama-3
                .or_else(|| tok.token_to_id("<|end_of_text|>")) // Llama-3 alt
                .or_else(|| tok.token_to_id("<|im_end|>")) // Qwen/ChatML
                .map(|id| id as i64)
                .unwrap_or(2)
        } else {
            2
        };

        Ok(Self {
            inner: model,
            device,
            tokenizer,
            eos_token_id,
            soul_lora: None,
            soul_optimizer: None,
            soul_lr: 1e-4,
            soul_rank: 8,
        })
    }

    // =========================================================================
    // Soul API — Online learning via LoRA
    // =========================================================================

    /// Learn from text — updates the model's "Soul" (LoRA weights) via online gradient descent
    ///
    /// This is the core of Bit-TTT's "growing AI" feature. Each call teaches
    /// the model something new by fine-tuning LoRA weights on the given text.
    ///
    /// Args:
    ///     text: Text to learn from (e.g., "My name is Onoko. I love curry.")
    ///     lr: Learning rate (default: 1e-4)
    ///     epochs: Number of training passes over the text (default: 3)
    ///
    /// Returns:
    ///     Final loss value
    ///
    /// Example:
    ///     model.learn("My name is Onoko")
    ///     model.learn("My favorite food is curry")
    ///     output = model.generate("What is my name?")
    ///     model.save_soul("onoko.soul")
    #[pyo3(signature = (text, lr=1e-4, epochs=3))]
    pub fn learn(&mut self, py: Python, text: &str, lr: f64, epochs: usize) -> PyResult<f64> {
        let text = text.to_string();
        py.allow_threads(|| self.learn_inner(&text, lr, epochs))
    }

    /// Save Soul (learned LoRA weights) to a file
    ///
    /// Args:
    ///     path: Path to save (.soul or .safetensors)
    ///
    /// Example:
    ///     model.save_soul("my_ai.soul")
    pub fn save_soul(&self, path: &str) -> PyResult<()> {
        let lora = self.soul_lora.as_ref().ok_or_else(|| {
            pyo3::exceptions::PyRuntimeError::new_err(
                "No Soul to save. Call learn() first to teach the model something.",
            )
        })?;
        lora.save(path).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to save Soul: {}", e))
        })
    }

    /// Load Soul (learned LoRA weights) from a file
    ///
    /// Args:
    ///     path: Path to .soul or .safetensors file
    ///
    /// Example:
    ///     model.load_soul("my_ai.soul")
    ///     output = model.generate("What is my name?")
    pub fn load_soul(&mut self, path: &str) -> PyResult<()> {
        // Load as regular LoRA weights into the model
        self.inner.load_lora(path).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to load Soul: {}", e))
        })?;
        // Enable hybrid LoRA mode (required for Soul inference)
        self.inner.enable_hybrid_lora(true);
        Ok(())
    }

    /// Check if Soul (LoRA) is active
    #[getter]
    pub fn has_soul(&self) -> bool {
        self.soul_lora.is_some() || self.inner.is_lora_enabled()
    }

    /// Reset Soul (forget everything learned)
    pub fn reset_soul(&mut self) {
        self.soul_lora = None;
        self.soul_optimizer = None;
        self.inner.clear_lora();
    }

    /// Generate text from a prompt
    #[pyo3(signature = (prompt, max_tokens=50, temperature=0.7, top_k=40, top_p=0.9, repetition_penalty=1.1))]
    pub fn generate(
        &mut self,
        py: Python,
        prompt: &str,
        max_tokens: usize,
        temperature: f32,
        top_k: usize,
        top_p: f32,
        repetition_penalty: f32,
    ) -> PyResult<String> {
        py.allow_threads(|| {
            self.generate_inner(
                prompt,
                max_tokens,
                temperature,
                top_k,
                top_p,
                repetition_penalty,
            )
        })
    }

    /// Generate and return raw token IDs (for debugging/external tokenizer decode)
    ///
    /// Args:
    ///     prompt_tokens: Input token IDs (from external tokenizer)
    ///     max_tokens: Maximum tokens to generate
    ///     temperature: Sampling temperature
    ///
    /// Returns:
    ///     List of generated token IDs (not including prompt)
    #[pyo3(signature = (prompt_tokens, max_tokens=50, temperature=0.7, top_k=40, top_p=0.9, repetition_penalty=1.1))]
    pub fn generate_from_tokens(
        &mut self,
        py: Python,
        prompt_tokens: Vec<i64>,
        max_tokens: usize,
        temperature: f32,
        top_k: usize,
        top_p: f32,
        repetition_penalty: f32,
    ) -> PyResult<Vec<i64>> {
        py.allow_threads(|| {
            self.generate_from_tokens_inner(
                prompt_tokens,
                max_tokens,
                temperature,
                top_k,
                top_p,
                repetition_penalty,
            )
        })
    }

    /// Run forward pass and return raw logits
    ///
    /// Args:
    ///     tokens: Token IDs to process
    ///     start_pos: Starting position for RoPE/KV cache (default: 0)
    ///
    /// Returns:
    ///     List of logits (flattened: [batch * seq_len * vocab_size])
    #[pyo3(signature = (tokens, start_pos=0))]
    pub fn forward(&mut self, tokens: Vec<i64>, start_pos: usize) -> PyResult<Vec<f32>> {
        let input = Tensor::from_vec(tokens.clone(), (1, tokens.len()), &self.device)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
        let logits = self
            .inner
            .forward(&input, start_pos)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
        let logits_vec = logits
            .flatten_all()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
            .to_vec1::<f32>()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
        Ok(logits_vec)
    }

    /// Reset the KV cache (call between conversations)
    pub fn reset_cache(&mut self) {
        self.inner.reset_cache();
    }

    /// Get model configuration info
    #[getter]
    pub fn config(&self) -> PyResult<PyQGgufConfig> {
        let cfg = self.inner.config();
        Ok(PyQGgufConfig {
            vocab_size: cfg.vocab_size,
            hidden_dim: cfg.hidden_dim,
            num_layers: cfg.num_layers,
            n_heads: cfg.n_heads,
            n_kv_heads: cfg.n_kv_heads,
        })
    }

    /// Enable Q8_0 quantized KV cache for memory efficiency
    ///
    /// This reduces KV cache memory by ~50% with minimal quality loss.
    /// Only effective during decode phase (seq_len=1).
    ///
    /// Args:
    ///     enable: Whether to enable Q8 KV cache
    ///
    /// Example:
    ///     model.enable_q8_kv_cache(True)
    ///     output = model.generate("Hello!", max_tokens=100)
    #[pyo3(signature = (enable=true))]
    pub fn enable_q8_kv_cache(&mut self, enable: bool) {
        self.inner.enable_q8_kv_cache(enable);
    }

    /// Check if Q8_0 KV cache is enabled
    #[getter]
    pub fn q8_kv_cache_enabled(&self) -> bool {
        self.inner.is_q8_kv_cache_enabled()
    }

    /// Enable TTT (Test-Time Training) refinement
    ///
    /// TTT uses online gradient descent to refine attention outputs,
    /// which can improve long-context understanding without additional training.
    ///
    /// Args:
    ///     enable: Whether to enable TTT refinement
    ///     inner_lr: Learning rate for TTT updates (default: 0.01)
    ///
    /// Example:
    ///     model.enable_ttt(True, inner_lr=0.01)
    ///     output = model.generate("Hello!", max_tokens=100)
    #[pyo3(signature = (enable=true, inner_lr=None))]
    pub fn enable_ttt(&mut self, enable: bool, inner_lr: Option<f64>) {
        self.inner.enable_ttt(enable, inner_lr);
    }

    /// Check if TTT is enabled
    #[getter]
    pub fn ttt_enabled(&self) -> bool {
        self.inner.is_ttt_enabled()
    }

    /// Reset TTT state (call when starting a new conversation)
    ///
    /// This clears the learnable hidden state in each layer.
    /// Call this when you want to start fresh without conversation history.
    pub fn reset_ttt(&mut self) {
        self.inner.reset_ttt_state();
    }

    /// Load LoRA adapters from a safetensors file
    ///
    /// Args:
    ///     path: Path to the LoRA weights file (.safetensors)
    ///
    /// Example:
    ///     model.load_lora("lora_weights.safetensors")
    ///     output = model.generate("Hello!", max_tokens=50)
    pub fn load_lora(&mut self, path: &str) -> PyResult<()> {
        self.inner.load_lora(path).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to load LoRA: {}", e))
        })
    }

    /// Create new LoRA adapters for the model
    ///
    /// Args:
    ///     rank: LoRA rank (typically 4, 8, 16, or 32)
    ///     alpha: LoRA alpha scaling factor (typically rank * 2)
    ///     target_modules: List of modules to apply LoRA to (e.g., ["q_proj", "v_proj"])
    ///
    /// Example:
    ///     model.create_lora(rank=8, alpha=16, target_modules=["q_proj", "v_proj"])
    #[pyo3(signature = (rank=8, alpha=None, target_modules=None))]
    pub fn create_lora(
        &mut self,
        rank: usize,
        alpha: Option<f32>,
        target_modules: Option<Vec<String>>,
    ) -> PyResult<()> {
        let alpha = alpha.unwrap_or(rank as f32 * 2.0);
        let target_modules =
            target_modules.unwrap_or_else(|| vec!["q_proj".to_string(), "v_proj".to_string()]);

        let config = crate::layers::LoRAConfig {
            rank,
            alpha,
            dropout: 0.0,
            target_modules,
        };

        self.inner.create_lora(config).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to create LoRA: {}", e))
        })
    }

    /// Enable or disable LoRA
    ///
    /// Args:
    ///     enable: Whether to enable LoRA
    #[pyo3(signature = (enable=true))]
    pub fn enable_lora(&mut self, enable: bool) {
        self.inner.enable_lora(enable);
    }

    /// Check if LoRA is enabled
    #[getter]
    pub fn lora_enabled(&self) -> bool {
        self.inner.is_lora_enabled()
    }

    /// Enable hybrid LoRA mode (matches training path)
    ///
    /// When enabled, LoRA perturbation is accumulated across layers and added
    /// to the final hidden state. This matches the training forward pass,
    /// producing better results with trained LoRA weights.
    ///
    /// Args:
    ///     enable: Whether to enable hybrid LoRA mode
    #[pyo3(signature = (enable=true))]
    pub fn enable_hybrid_lora(&mut self, enable: bool) {
        self.inner.enable_hybrid_lora(enable);
    }

    /// Check if hybrid LoRA mode is enabled
    #[getter]
    pub fn hybrid_lora_enabled(&self) -> bool {
        self.inner.is_hybrid_lora_enabled()
    }

    /// Enable profiling mode (measures per-component timing with CUDA sync)
    ///
    /// WARNING: This adds significant overhead due to GPU synchronization.
    /// Use only for debugging/optimization, not production.
    #[pyo3(signature = (enable=true))]
    pub fn enable_profiling(&mut self, enable: bool) {
        self.inner.enable_profiling(enable);
    }

    /// Get last forward pass profile results
    ///
    /// Returns list of (component_name, duration_ms) tuples
    pub fn get_profile(&self) -> Vec<(String, f64)> {
        self.inner.get_profile().to_vec()
    }

    /// Save LoRA weights to a file
    ///
    /// Args:
    ///     path: Path to save the LoRA weights (.safetensors)
    pub fn save_lora(&self, path: &str) -> PyResult<()> {
        self.inner.save_lora(path).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to save LoRA: {}", e))
        })
    }
}

#[cfg(feature = "python")]
impl PyQGgufModel {
    fn generate_inner(
        &mut self,
        prompt: &str,
        max_tokens: usize,
        temperature: f32,
        top_k: usize,
        top_p: f32,
        repetition_penalty: f32,
    ) -> PyResult<String> {
        // Tokenize prompt (with special tokens like BOS)
        let (prompt_tokens, use_tokenizer) = if let Some(ref tokenizer) = self.tokenizer {
            let encoding = tokenizer.encode(prompt, true).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Tokenization failed: {}", e))
            })?;
            let ids: Vec<i64> = encoding.get_ids().iter().map(|&x| x as i64).collect();
            if ids.is_empty() {
                (vec![1_i64], true)
            } else {
                (ids, true)
            }
        } else {
            // No tokenizer - require explicit token IDs via generate_from_tokens()
            return Err(pyo3::exceptions::PyRuntimeError::new_err(
                "Tokenizer required for generate(). Either:\n\
                 1. Pass tokenizer path: QGgufModel(path, tokenizer='tokenizer.json')\n\
                 2. Use generate_from_tokens() with pre-tokenized input",
            ));
        };

        let mut tokens = prompt_tokens.clone();
        let prompt_len = tokens.len();

        // Prefill
        let input = Tensor::from_vec(tokens.clone(), (1, tokens.len()), &self.device)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let logits = self
            .inner
            .forward(&input, 0)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let first_token = self.sample_token(
            &logits,
            &tokens,
            temperature,
            top_k,
            top_p,
            repetition_penalty,
        )?;

        if first_token == self.eos_token_id {
            return Ok(String::new());
        }
        tokens.push(first_token);

        // Decode loop
        for _ in 1..max_tokens {
            let pos = tokens.len() - 1;
            let last_token = tokens[pos];

            let input = Tensor::from_vec(vec![last_token], (1, 1), &self.device)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let logits = self
                .inner
                .forward(&input, pos)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let next_token = self.sample_token(
                &logits,
                &tokens,
                temperature,
                top_k,
                top_p,
                repetition_penalty,
            )?;

            if next_token == self.eos_token_id {
                break;
            }

            tokens.push(next_token);
        }

        // Decode output
        let generated_tokens: Vec<u32> =
            tokens.iter().skip(prompt_len).map(|&t| t as u32).collect();

        // use_tokenizer is always true now (we error earlier if no tokenizer)
        let tokenizer = self.tokenizer.as_ref().unwrap();
        let output = tokenizer.decode(&generated_tokens, true).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Decoding failed: {}", e))
        })?;
        Ok(output)
    }

    fn generate_from_tokens_inner(
        &mut self,
        prompt_tokens: Vec<i64>,
        max_tokens: usize,
        temperature: f32,
        top_k: usize,
        top_p: f32,
        repetition_penalty: f32,
    ) -> PyResult<Vec<i64>> {
        let mut tokens = prompt_tokens.clone();
        let mut generated = Vec::new();

        // Prefill
        let input = Tensor::from_vec(tokens.clone(), (1, tokens.len()), &self.device)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let logits = self
            .inner
            .forward(&input, 0)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let first_token = self.sample_token(
            &logits,
            &tokens,
            temperature,
            top_k,
            top_p,
            repetition_penalty,
        )?;

        if first_token == self.eos_token_id {
            return Ok(generated);
        }
        tokens.push(first_token);
        generated.push(first_token);

        // Decode loop
        for _ in 1..max_tokens {
            let pos = tokens.len() - 1;
            let last_token = tokens[pos];

            let input = Tensor::from_vec(vec![last_token], (1, 1), &self.device)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let logits = self
                .inner
                .forward(&input, pos)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let next_token = self.sample_token(
                &logits,
                &tokens,
                temperature,
                top_k,
                top_p,
                repetition_penalty,
            )?;

            if next_token == self.eos_token_id {
                break;
            }

            tokens.push(next_token);
            generated.push(next_token);
        }

        Ok(generated)
    }

    /// Initialize Soul LoRA adapters (lazy init on first learn() call)
    fn init_soul_lora(&mut self, lr: f64) -> PyResult<()> {
        if self.soul_lora.is_some() {
            // Update learning rate if changed
            if let Some(ref mut opt) = self.soul_optimizer {
                opt.set_learning_rate(lr);
            }
            return Ok(());
        }

        let config = self.inner.config();
        let hidden_dim = config.hidden_dim;
        let n_heads = config.n_heads;
        let n_kv_heads = config.n_kv_heads;
        let head_dim = hidden_dim / n_heads;
        let num_layers = config.num_layers;

        // Only apply to last 1/4 of layers (most effective, least memory)
        let start_layer = num_layers * 3 / 4;

        let lora_config = crate::layers::LoRAConfig {
            rank: self.soul_rank,
            alpha: (self.soul_rank * 2) as f32,
            target_modules: vec!["q_proj".to_string(), "v_proj".to_string()],
            dropout: 0.0,
        };

        let mut layer_dims = Vec::new();
        for idx in start_layer..num_layers {
            // Q projection: hidden_dim -> hidden_dim (n_heads * head_dim)
            layer_dims.push((
                format!("layers.{}.self_attn.q_proj", idx),
                hidden_dim,
                n_heads * head_dim,
            ));
            // V projection: hidden_dim -> n_kv_heads * head_dim
            layer_dims.push((
                format!("layers.{}.self_attn.v_proj", idx),
                hidden_dim,
                n_kv_heads * head_dim,
            ));
        }

        let adapters =
            crate::layers::TrainableLoRAAdapters::new(lora_config, &layer_dims, &self.device)
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Failed to init Soul LoRA: {}",
                        e
                    ))
                })?;

        let vars = adapters.vars();
        let optimizer = crate::layers::AdamW::new(vars, lr).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to init optimizer: {}", e))
        })?;

        tracing::info!(
            "Soul initialized: {} layers ({}-{}), rank={}, params={}",
            num_layers - start_layer,
            start_layer,
            num_layers - 1,
            self.soul_rank,
            adapters.num_parameters()
        );

        self.soul_lora = Some(adapters);
        self.soul_optimizer = Some(optimizer);
        self.soul_lr = lr;
        Ok(())
    }

    /// Core learn implementation: tokenize text, compute loss, update LoRA
    fn learn_inner(&mut self, text: &str, lr: f64, epochs: usize) -> PyResult<f64> {
        use candle_nn::loss::cross_entropy;

        // Tokenize
        let tokenizer = self.tokenizer.as_ref().ok_or_else(|| {
            pyo3::exceptions::PyRuntimeError::new_err(
                "Tokenizer required for learn(). Pass tokenizer path when creating the model.",
            )
        })?;
        let encoding = tokenizer.encode(text, true).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Tokenization failed: {}", e))
        })?;
        let token_ids: Vec<i64> = encoding.get_ids().iter().map(|&x| x as i64).collect();

        if token_ids.len() < 2 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "Text too short to learn from (need at least 2 tokens)",
            ));
        }

        // Initialize Soul LoRA on first call
        self.init_soul_lora(lr)?;

        let seq_len = token_ids.len();
        // input = tokens[0..n-1], labels = tokens[1..n] (next-token prediction)
        let input_ids: Vec<i64> = token_ids[..seq_len - 1].to_vec();
        let labels: Vec<i64> = token_ids[1..].to_vec();
        let train_len = input_ids.len();

        let mut last_loss = 0.0;

        for epoch in 0..epochs {
            // Create input tensor
            let input = Tensor::from_vec(input_ids.clone(), (1, train_len), &self.device)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            // Reset cache for fresh forward
            self.inner.reset_cache();

            // Forward pass WITH trainable LoRA (gradient flows through LoRA)
            let lora = self.soul_lora.as_ref().unwrap();

            let logits = self
                .inner
                .forward_with_trainable_lora(&input, lora, 0)
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!("Forward failed: {}", e))
                })?;

            // Compute cross-entropy loss
            let vocab_size = logits
                .dim(2)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
            let logits_flat = logits
                .reshape((train_len, vocab_size))
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
            let targets = Tensor::from_vec(labels.clone(), (train_len,), &self.device)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
                .to_dtype(candle_core::DType::U32)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            let loss = cross_entropy(&logits_flat, &targets).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Loss failed: {}", e))
            })?;

            last_loss = loss
                .to_scalar::<f32>()
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
                as f64;

            // Backward + optimizer step
            let grads = loss.backward().map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Backward failed: {}", e))
            })?;
            self.soul_optimizer
                .as_mut()
                .unwrap()
                .step(&grads)
                .map_err(|e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Optimizer step failed: {}",
                        e
                    ))
                })?;

            tracing::debug!(
                "Soul learn epoch {}/{}: loss={:.4}",
                epoch + 1,
                epochs,
                last_loss
            );
        }

        // After learning, apply the trained LoRA weights to the model's inference path
        // Convert TrainableLoRA (Var-backed) → inference LoRA (Tensor-backed)
        self.apply_soul_to_inference()?;

        // Reset cache after learning
        self.inner.reset_cache();

        Ok(last_loss)
    }

    /// Copy Soul LoRA weights from trainable Vars to inference-time LoRA slots
    fn apply_soul_to_inference(&mut self) -> PyResult<()> {
        let lora = self
            .soul_lora
            .as_ref()
            .ok_or_else(|| pyo3::exceptions::PyRuntimeError::new_err("No Soul to apply"))?;

        for (name, trainable_layer) in &lora.layers {
            // Parse layer index and projection type
            // Name format: "layers.{idx}.self_attn.{q_proj|v_proj}"
            let parts: Vec<&str> = name.split('.').collect();
            if parts.len() >= 4 {
                if let Ok(layer_idx) = parts[1].parse::<usize>() {
                    let proj = parts.last().unwrap_or(&"");
                    let inference_lora = crate::layers::LoRALayer {
                        lora_a: trainable_layer.lora_a.as_tensor().clone(),
                        lora_b: trainable_layer.lora_b.as_tensor().clone(),
                        scaling: trainable_layer.scaling,
                        in_features: trainable_layer.in_features,
                        out_features: trainable_layer.out_features,
                        rank: trainable_layer.rank,
                        enabled: true,
                    };
                    self.inner.set_layer_lora(layer_idx, proj, inference_lora);
                }
            }
        }
        self.inner.set_lora_enabled(true);
        self.inner.enable_hybrid_lora(true);
        Ok(())
    }

    /// Optimized sampling: avoids GPU→CPU full-vocab copy when possible.
    ///
    /// - Greedy (temp<0.01) + no rep penalty: GPU argmax only (4B transfer vs 608KB for Qwen)
    /// - Greedy + rep penalty: GPU-side penalty → GPU argmax
    /// - Non-greedy: falls back to CPU sampling (existing path)
    fn sample_token(
        &self,
        logits: &Tensor,
        generated_tokens: &[i64],
        temperature: f32,
        top_k: usize,
        top_p: f32,
        repetition_penalty: f32,
    ) -> PyResult<i64> {
        let (_, seq_len, _) = logits
            .dims3()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let last_logits = logits
            .narrow(1, seq_len - 1, 1)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
            .squeeze(1)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
            .squeeze(0)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // === Fast path: Greedy sampling on GPU (avoids full vocab GPU→CPU copy) ===
        if temperature < 0.01 {
            if repetition_penalty == 1.0 || generated_tokens.is_empty() {
                // Pure GPU argmax: transfer only 4 bytes instead of vocab_size * 4
                let max_idx = last_logits
                    .argmax(0)
                    .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
                    .to_scalar::<u32>()
                    .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
                return Ok(max_idx as i64);
            }

            // Greedy with repetition penalty: apply penalty on GPU, then argmax
            // Build penalty factors tensor on GPU
            let vocab_size = last_logits
                .dim(0)
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
            let device = last_logits.device();

            // Get logits to apply penalty (only copy when rep penalty is active)
            let mut logits_vec = last_logits
                .to_vec1::<f32>()
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            for &token in generated_tokens {
                if token >= 0 && (token as usize) < vocab_size {
                    let idx = token as usize;
                    if logits_vec[idx] > 0.0 {
                        logits_vec[idx] /= repetition_penalty;
                    } else {
                        logits_vec[idx] *= repetition_penalty;
                    }
                }
            }

            let max_idx = logits_vec
                .iter()
                .enumerate()
                .max_by(|a, b| a.1.partial_cmp(b.1).unwrap_or(std::cmp::Ordering::Equal))
                .map(|(i, _)| i)
                .unwrap_or(0);
            return Ok(max_idx as i64);
        }

        // === Slow path: Full CPU sampling (non-greedy) ===
        use rand::Rng;

        let mut logits_vec = last_logits
            .to_vec1::<f32>()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // Apply repetition penalty
        if repetition_penalty != 1.0 {
            for &token in generated_tokens {
                if token >= 0 && (token as usize) < logits_vec.len() {
                    let idx = token as usize;
                    if logits_vec[idx] > 0.0 {
                        logits_vec[idx] /= repetition_penalty;
                    } else {
                        logits_vec[idx] *= repetition_penalty;
                    }
                }
            }
        }

        // Apply temperature
        for logit in &mut logits_vec {
            *logit /= temperature;
        }

        // Top-k filtering
        if top_k > 0 && top_k < logits_vec.len() {
            let mut indexed: Vec<(usize, f32)> = logits_vec.iter().cloned().enumerate().collect();
            indexed.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
            let threshold = indexed[top_k - 1].1;
            for logit in &mut logits_vec {
                if *logit < threshold {
                    *logit = f32::NEG_INFINITY;
                }
            }
        }

        // Softmax
        let max_logit = logits_vec.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
        let exp_sum: f32 = logits_vec.iter().map(|&x| (x - max_logit).exp()).sum();
        let probs: Vec<f32> = logits_vec
            .iter()
            .map(|&x| (x - max_logit).exp() / exp_sum)
            .collect();

        // Top-p (nucleus) filtering
        let probs = if top_p < 1.0 {
            let mut indexed: Vec<(usize, f32)> = probs.iter().cloned().enumerate().collect();
            indexed.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

            let mut cumsum = 0.0;
            let mut cutoff_idx = indexed.len();
            for (i, (_, p)) in indexed.iter().enumerate() {
                cumsum += p;
                if cumsum > top_p {
                    cutoff_idx = i + 1;
                    break;
                }
            }

            let mut filtered = vec![0.0; probs.len()];
            for (idx, prob) in indexed.iter().take(cutoff_idx) {
                filtered[*idx] = *prob;
            }

            let sum: f32 = filtered.iter().sum();
            if sum > 0.0 {
                filtered.iter().map(|&p| p / sum).collect()
            } else {
                probs
            }
        } else {
            probs
        };

        // Sample from distribution
        let mut rng = rand::thread_rng();
        let r: f32 = rng.gen();
        let mut cumsum = 0.0;
        for (i, &p) in probs.iter().enumerate() {
            cumsum += p;
            if r < cumsum {
                return Ok(i as i64);
            }
        }

        Ok((probs.len() - 1) as i64)
    }
}

/// Configuration for quantized GGUF model
#[cfg(feature = "python")]
#[pyclass(name = "QGgufConfig")]
pub struct PyQGgufConfig {
    #[pyo3(get)]
    pub vocab_size: usize,
    #[pyo3(get)]
    pub hidden_dim: usize,
    #[pyo3(get)]
    pub num_layers: usize,
    #[pyo3(get)]
    pub n_heads: usize,
    #[pyo3(get)]
    pub n_kv_heads: usize,
}

// ============================================================================
// PyLoRATrainer - LoRA fine-tuning for QGgufModel
// ============================================================================

/// LoRA trainer for fine-tuning quantized models
///
/// This allows training only the LoRA adapters while keeping the base
/// model weights frozen (quantized).
///
/// Example:
/// ```python
/// from cortex_rust import QGgufModel, LoRATrainer
///
/// model = QGgufModel("model.gguf", tokenizer="tokenizer.json", device="cuda")
/// trainer = LoRATrainer(model, rank=8, alpha=16, lr=1e-4)
///
/// for input_ids, labels in dataset:
///     loss = trainer.train_step(input_ids, labels)
///     print(f"Loss: {loss:.4f}")
///
/// trainer.save_lora("finetuned_lora.safetensors")
/// ```
#[cfg(feature = "python")]
#[pyclass(name = "LoRATrainer")]
pub struct PyLoRATrainer {
    /// The quantized model (with frozen weights)
    model: QGgufModel,
    /// Trainable LoRA adapters
    lora_adapters: crate::layers::TrainableLoRAAdapters,
    /// AdamW optimizer
    optimizer: crate::layers::AdamW,
    /// Tokenizer for encoding/decoding
    tokenizer: Option<Tokenizer>,
    /// Device
    device: Device,
    /// Training step count
    step: usize,
}

#[cfg(feature = "python")]
#[pymethods]
impl PyLoRATrainer {
    /// Create a new LoRA trainer
    ///
    /// Args:
    ///     model_path: Path to the GGUF model file
    ///     tokenizer: Path to tokenizer.json (optional but recommended)
    ///     rank: LoRA rank (default: 8)
    ///     alpha: LoRA alpha scaling (default: rank * 2)
    ///     lr: Learning rate (default: 1e-4)
    ///     weight_decay: Weight decay for AdamW (default: 0.01)
    ///     target_modules: Modules to apply LoRA (default: ["q_proj", "v_proj"])
    ///     device: Device ("cpu" or "cuda", default: "cuda")
    #[new]
    #[pyo3(signature = (model_path, tokenizer=None, rank=8, alpha=None, lr=1e-4, weight_decay=0.01, target_modules=None, device=None))]
    pub fn new(
        model_path: &str,
        tokenizer: Option<&str>,
        rank: usize,
        alpha: Option<f32>,
        lr: f64,
        weight_decay: f64,
        target_modules: Option<Vec<String>>,
        device: Option<&str>,
    ) -> PyResult<Self> {
        let device = match device {
            Some("cuda") | Some("gpu") => Device::new_cuda(0).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Failed to initialize CUDA: {}. Try device='cpu'",
                    e
                ))
            })?,
            Some("cpu") | None => Device::Cpu,
            Some(unknown) => {
                return Err(pyo3::exceptions::PyValueError::new_err(format!(
                    "Unknown device: '{}'. Use 'cpu' or 'cuda'",
                    unknown
                )))
            }
        };

        // Load quantized model
        let model = QGgufModel::load(model_path, &device).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!(
                "Failed to load model '{}': {}",
                model_path, e
            ))
        })?;

        // Load tokenizer if provided
        let tokenizer = if let Some(tok_path) = tokenizer {
            Some(Tokenizer::from_file(tok_path).map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Failed to load tokenizer '{}': {}",
                    tok_path, e
                ))
            })?)
        } else {
            None
        };

        // Get model config for layer dimensions
        let config = model.config();
        let hidden_dim = config.hidden_dim;
        let num_layers = config.num_layers;

        // Create layer dimension list for LoRA
        let alpha = alpha.unwrap_or(rank as f32 * 2.0);
        let target_modules =
            target_modules.unwrap_or_else(|| vec!["q_proj".to_string(), "v_proj".to_string()]);

        // Build layer dimensions [(name, in_features, out_features)]
        // GQA models have different dimensions for K/V vs Q/O
        let n_heads = config.n_heads;
        let n_kv_heads = config.n_kv_heads;
        let head_dim = config.head_dim.unwrap_or(hidden_dim / n_heads);
        let q_dim = n_heads * head_dim; // Q, O projections
        let kv_dim = n_kv_heads * head_dim; // K, V projections

        let mut layer_dims = Vec::new();
        for i in 0..num_layers {
            for module in &target_modules {
                let name = format!("layers.{}.{}", i, module);
                // Determine output dimension based on projection type
                let out_dim = match module.as_str() {
                    "q_proj" | "wq" | "o_proj" | "wo" => q_dim,
                    "k_proj" | "wk" | "v_proj" | "wv" => kv_dim,
                    _ => hidden_dim, // fallback
                };
                layer_dims.push((name, hidden_dim, out_dim));
            }
        }

        let lora_config = crate::layers::LoRAConfig {
            rank,
            alpha,
            dropout: 0.0,
            target_modules,
        };

        let lora_adapters =
            crate::layers::TrainableLoRAAdapters::new(lora_config, &layer_dims, &device).map_err(
                |e| {
                    pyo3::exceptions::PyRuntimeError::new_err(format!(
                        "Failed to create LoRA adapters: {}",
                        e
                    ))
                },
            )?;

        let vars = lora_adapters.vars();
        let optimizer = crate::layers::AdamW::new(vars, lr)
            .map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Failed to create optimizer: {}",
                    e
                ))
            })?
            .with_weight_decay(weight_decay);

        tracing::info!(
            "Created LoRA trainer: {} adapters, {} params, lr={}",
            lora_adapters.layers.len(),
            lora_adapters.num_parameters(),
            lr
        );

        Ok(Self {
            model,
            lora_adapters,
            optimizer,
            tokenizer,
            device,
            step: 0,
        })
    }

    /// Perform one training step
    ///
    /// Args:
    ///     input_ids: Input token IDs [seq_len]
    ///     labels: Target token IDs [seq_len] (shifted by 1 for causal LM)
    ///
    /// Returns:
    ///     Loss value (float)
    ///
    /// Example:
    ///     loss = trainer.train_step([1, 2, 3, 4], [2, 3, 4, 5])
    pub fn train_step(
        &mut self,
        py: Python,
        input_ids: Vec<i64>,
        labels: Vec<i64>,
    ) -> PyResult<f64> {
        py.allow_threads(|| self.train_step_inner(input_ids, labels))
    }

    /// Get number of trainable parameters
    #[getter]
    pub fn num_parameters(&self) -> usize {
        self.lora_adapters.num_parameters()
    }

    /// Get current training step
    #[getter]
    pub fn current_step(&self) -> usize {
        self.step
    }

    /// Get learning rate
    #[getter]
    pub fn learning_rate(&self) -> f64 {
        self.optimizer.learning_rate()
    }

    /// Set learning rate
    #[setter]
    pub fn set_learning_rate(&mut self, lr: f64) {
        self.optimizer.set_learning_rate(lr);
    }

    /// Save LoRA weights to a file
    ///
    /// Args:
    ///     path: Path to save (.safetensors)
    pub fn save_lora(&self, path: &str) -> PyResult<()> {
        self.lora_adapters.save(path).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to save LoRA: {}", e))
        })
    }

    /// Load LoRA weights from a file (for resuming training)
    ///
    /// This loads weights into the existing LoRA adapters, allowing you to
    /// resume training from a checkpoint.
    ///
    /// Args:
    ///     path: Path to load (.safetensors)
    ///
    /// Example:
    ///     trainer.load_lora("checkpoint_step_100.safetensors")
    ///     # Continue training from step 100
    ///     for i in range(100, 200):
    ///         loss = trainer.train_step(...)
    pub fn load_lora(&mut self, path: &str) -> PyResult<()> {
        self.lora_adapters.load(path).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to load LoRA: {}", e))
        })
    }

    /// Reset training step counter (use after loading checkpoint)
    ///
    /// Args:
    ///     step: Step number to set
    pub fn set_step(&mut self, step: usize) {
        self.step = step;
    }

    /// Perform one training step with multiple samples (batch training)
    ///
    /// Args:
    ///     samples: List of input token ID sequences
    ///     labels: List of target token ID sequences (same length as samples)
    ///     pad_token_id: Token ID used for padding (default: 0)
    ///
    /// Returns:
    ///     Average loss across the batch
    ///
    /// Example:
    ///     loss = trainer.train_batch(
    ///         [[1,2,3], [4,5,6,7,8]],
    ///         [[2,3,4], [5,6,7,8,9]],
    ///         pad_token_id=0
    ///     )
    #[pyo3(signature = (samples, labels, pad_token_id=0))]
    pub fn train_batch(
        &mut self,
        py: Python,
        samples: Vec<Vec<i64>>,
        labels: Vec<Vec<i64>>,
        pad_token_id: i64,
    ) -> PyResult<f64> {
        py.allow_threads(|| self.train_batch_inner(samples, labels, pad_token_id))
    }
}

#[cfg(feature = "python")]
impl PyLoRATrainer {
    fn train_step_inner(&mut self, input_ids: Vec<i64>, labels: Vec<i64>) -> PyResult<f64> {
        use candle_nn::loss::cross_entropy;

        if input_ids.len() != labels.len() {
            return Err(pyo3::exceptions::PyValueError::new_err(format!(
                "input_ids length ({}) must match labels length ({})",
                input_ids.len(),
                labels.len()
            )));
        }

        if input_ids.is_empty() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "input_ids cannot be empty",
            ));
        }

        let seq_len = input_ids.len();

        // 1. Create input tensor
        let input = Tensor::from_vec(input_ids, (1, seq_len), &self.device)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // 2. Reset cache for fresh forward pass
        self.model.reset_cache();

        // 3. Forward pass through model WITH trainable LoRA
        // This applies LoRA to attention projections (Q, K, V, O)
        // Gradients flow through LoRA paths while base weights are frozen
        let logits = self
            .model
            .forward_with_trainable_lora(&input, &self.lora_adapters, 0)
            .map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Forward pass failed: {}", e))
            })?;

        let vocab_size = logits
            .dim(2)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // 4. Compute cross-entropy loss
        let logits_flat = logits
            .reshape((seq_len, vocab_size))
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let targets = Tensor::from_vec(labels, (seq_len,), &self.device)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
            .to_dtype(candle_core::DType::U32)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let loss = cross_entropy(&logits_flat, &targets).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Loss computation failed: {}", e))
        })?;

        // 5. Get loss value before backward
        let loss_val: f32 = loss
            .to_scalar()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // 6. Backward pass
        let grads = loss.backward().map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Backward pass failed: {}", e))
        })?;

        // 7. Optimizer step (update LoRA weights)
        self.optimizer.step(&grads).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Optimizer step failed: {}", e))
        })?;

        self.step += 1;

        Ok(loss_val as f64)
    }

    fn train_batch_inner(
        &mut self,
        samples: Vec<Vec<i64>>,
        labels: Vec<Vec<i64>>,
        pad_token_id: i64,
    ) -> PyResult<f64> {
        use candle_nn::loss::cross_entropy;

        if samples.len() != labels.len() {
            return Err(pyo3::exceptions::PyValueError::new_err(format!(
                "samples length ({}) must match labels length ({})",
                samples.len(),
                labels.len()
            )));
        }

        if samples.is_empty() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "samples cannot be empty",
            ));
        }

        let batch_size = samples.len();

        // Find max sequence length
        let max_len = samples.iter().map(|s| s.len()).max().unwrap();

        // Pad samples and labels to max_len
        let mut padded_samples = Vec::with_capacity(batch_size * max_len);
        let mut padded_labels = Vec::with_capacity(batch_size * max_len);
        let mut mask = Vec::with_capacity(batch_size * max_len);

        for (sample, label) in samples.iter().zip(labels.iter()) {
            // Add actual tokens
            for &tok in sample {
                padded_samples.push(tok);
            }
            for &tok in label {
                padded_labels.push(tok);
                mask.push(1.0f32);
            }
            // Add padding
            let pad_len = max_len - sample.len();
            for _ in 0..pad_len {
                padded_samples.push(pad_token_id);
                padded_labels.push(pad_token_id);
                mask.push(0.0f32); // Don't compute loss on padding
            }
        }

        // Create tensors
        let input = Tensor::from_vec(padded_samples, (batch_size, max_len), &self.device)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // Reset cache
        self.model.reset_cache();

        // Forward pass
        let logits = self
            .model
            .forward_with_trainable_lora(&input, &self.lora_adapters, 0)
            .map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!("Forward pass failed: {}", e))
            })?;

        let vocab_size = logits
            .dim(2)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // Flatten for loss computation: [batch * seq, vocab]
        let logits_flat = logits
            .reshape((batch_size * max_len, vocab_size))
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let targets = Tensor::from_vec(padded_labels, (batch_size * max_len,), &self.device)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?
            .to_dtype(candle_core::DType::U32)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // Compute per-token loss
        let per_token_loss = cross_entropy(&logits_flat, &targets).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Loss computation failed: {}", e))
        })?;

        // Apply mask and compute mean (only non-padding tokens)
        let mask_tensor = Tensor::from_vec(mask.clone(), (batch_size * max_len,), &self.device)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let masked_loss = per_token_loss
            .broadcast_mul(&mask_tensor)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let valid_tokens: f64 = mask.iter().sum::<f32>() as f64;
        let sum_loss = masked_loss
            .sum_all()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
        let loss = (sum_loss / valid_tokens)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // Get loss value
        let loss_val: f32 = loss
            .to_scalar()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        // Backward
        let grads = loss.backward().map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Backward pass failed: {}", e))
        })?;

        // Optimizer step
        self.optimizer.step(&grads).map_err(|e| {
            pyo3::exceptions::PyRuntimeError::new_err(format!("Optimizer step failed: {}", e))
        })?;

        self.step += 1;

        Ok(loss_val as f64)
    }
}

/// Test function to verify gradient flow with candle Var
#[cfg(feature = "python")]
#[pyfunction]
pub fn test_lora_gradient() -> PyResult<String> {
    let device = Device::cuda_if_available(0)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

    // Create a simple LoRA-like setup
    let in_features = 4usize;
    let rank = 2usize;
    let out_features = 3usize;
    let batch_size = 2usize;

    // Create Vars (trainable parameters)
    let lora_a_data = Tensor::randn(0.0f32, 0.01, (in_features, rank), &device)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
    // Initialize B with small values (not zeros!) so gradient flows to A
    let lora_b_data = Tensor::randn(0.0f32, 0.01, (rank, out_features), &device)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

    let lora_a = Var::from_tensor(&lora_a_data)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
    let lora_b = Var::from_tensor(&lora_b_data)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

    // Create input (constant, no gradient needed)
    let input = Tensor::randn(0.0f32, 1.0, (batch_size, in_features), &device)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

    // Target output
    let target = Tensor::ones((batch_size, out_features), DType::F32, &device)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

    // Forward: output = input @ A @ B
    let h = input
        .matmul(&lora_a.as_tensor())
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
    let output = h
        .matmul(&lora_b.as_tensor())
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

    // Loss: MSE = mean((output - target)^2)
    let diff = output
        .sub(&target)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
    let sq = diff
        .sqr()
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
    let loss = sq
        .mean_all()
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

    let loss_val: f32 = loss
        .to_scalar()
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

    // Backward
    let grads = loss
        .backward()
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

    // Check gradients
    let grad_a = grads.get(&lora_a);
    let grad_b = grads.get(&lora_b);

    let mut result = format!("Loss: {:.6}\n", loss_val);

    if let Some(g) = grad_a {
        let sum: f32 = g
            .abs()
            .and_then(|t| t.sum_all())
            .and_then(|t| t.to_scalar::<f32>())
            .unwrap_or(0.0);
        result.push_str(&format!("Grad A: exists, sum={:.6}\n", sum));
    } else {
        result.push_str("Grad A: NOT FOUND\n");
    }

    if let Some(g) = grad_b {
        let sum: f32 = g
            .abs()
            .and_then(|t| t.sum_all())
            .and_then(|t| t.to_scalar::<f32>())
            .unwrap_or(0.0);
        result.push_str(&format!("Grad B: exists, sum={:.6}\n", sum));
    } else {
        result.push_str("Grad B: NOT FOUND\n");
    }

    Ok(result)
}
