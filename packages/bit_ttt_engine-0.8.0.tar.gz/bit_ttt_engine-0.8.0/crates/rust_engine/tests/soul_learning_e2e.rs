//! Soul Learning E2E Tests
//!
//! CI-safe tests that verify the complete LoRA training pipeline:
//!   1. LoRA init → forward → loss → backward → optimizer step → weight change
//!   2. Save/Load roundtrip via safetensors
//!   3. Multi-epoch training causes loss decrease
//!
//! Optional (GGUF model required):
//!   4. Full pipeline: model load → tokenize → train → save soul
//!   5. Soul applied → inference logits differ from baseline

mod common;

use candle_core::{Device, Tensor};
use cortex_rust::layers::{AdamW, LoRAConfig, TrainableLoRAAdapters, TrainableLoRALayer};

// ─── helpers ───────────────────────────────────────────────────────

/// Compute MSE loss between two tensors (returns scalar with grad)
fn mse_loss(pred: &Tensor, target: &Tensor) -> candle_core::Result<Tensor> {
    let diff = pred.sub(target)?;
    diff.sqr()?.mean_all()
}

/// Snapshot all Var values as flat Vec<f32>
fn snapshot_vars(vars: &[candle_core::Var]) -> Vec<Vec<f32>> {
    vars.iter()
        .map(|v| v.as_tensor().flatten_all().unwrap().to_vec1::<f32>().unwrap())
        .collect()
}

/// Check whether two snapshots differ by more than `eps`
fn snapshots_differ(a: &[Vec<f32>], b: &[Vec<f32>], eps: f32) -> bool {
    a.iter().zip(b.iter()).any(|(va, vb)| {
        va.iter()
            .zip(vb.iter())
            .any(|(x, y)| (x - y).abs() > eps)
    })
}

// ─── CI-safe tests (no model required) ─────────────────────────────

/// Basic training loop: LoRA forward → loss → backward → optimizer step → weights change
#[test]
fn test_lora_training_updates_weights() {
    let device = Device::Cpu;
    let (in_dim, out_dim, rank) = (64, 64, 4);
    let alpha = (rank * 2) as f32;

    let lora = TrainableLoRALayer::new(in_dim, out_dim, rank, alpha, &device).unwrap();
    let vars = lora.vars();
    let before = snapshot_vars(&vars);

    // Synthetic training step
    let x = Tensor::randn(0.0f32, 1.0, (1, 8, in_dim), &device).unwrap();
    let target = Tensor::randn(0.0f32, 0.1, (1, 8, out_dim), &device).unwrap();
    let pred = lora.forward(&x).unwrap();
    let loss = mse_loss(&pred, &target).unwrap();

    let loss_val: f32 = loss.to_scalar().unwrap();
    assert!(loss_val.is_finite(), "Loss should be finite");

    // Backward + optimizer
    let grads = loss.backward().unwrap();
    let mut opt = AdamW::new(vars.clone(), 1e-3).unwrap();
    opt.step(&grads).unwrap();

    let after = snapshot_vars(&vars);
    assert!(
        snapshots_differ(&before, &after, 1e-10),
        "Weights must change after one optimizer step"
    );
}

/// Multi-epoch training: loss should decrease on a simple fitting task
#[test]
fn test_lora_loss_decreases_over_epochs() {
    let device = Device::Cpu;
    let (in_dim, out_dim, rank) = (32, 32, 4);
    let alpha = (rank * 2) as f32;

    let lora = TrainableLoRALayer::new(in_dim, out_dim, rank, alpha, &device).unwrap();
    let vars = lora.vars();
    let mut opt = AdamW::new(vars, 1e-2).unwrap();

    // Fixed input/target pair (deterministic seed via fixed tensor)
    let x = Tensor::ones((1, 4, in_dim), candle_core::DType::F32, &device).unwrap();
    let target = Tensor::ones((1, 4, out_dim), candle_core::DType::F32, &device)
        .unwrap()
        .affine(0.5, 0.0)
        .unwrap();

    let mut losses = Vec::new();
    for _ in 0..20 {
        let pred = lora.forward(&x).unwrap();
        let loss = mse_loss(&pred, &target).unwrap();
        losses.push(loss.to_scalar::<f32>().unwrap());

        let grads = loss.backward().unwrap();
        opt.step(&grads).unwrap();
    }

    let first = losses[0];
    let last = *losses.last().unwrap();

    assert!(
        last < first,
        "Loss should decrease: first={:.6}, last={:.6}",
        first,
        last
    );
    assert!(
        last < first * 0.5,
        "Loss should decrease by at least 50%: first={:.6}, last={:.6}",
        first,
        last
    );
}

/// TrainableLoRAAdapters: multi-layer init + vars collection
#[test]
fn test_trainable_adapters_multi_layer() {
    let device = Device::Cpu;
    let config = LoRAConfig {
        rank: 4,
        alpha: 8.0,
        target_modules: vec!["q_proj".to_string(), "v_proj".to_string()],
        dropout: 0.0,
    };

    // Simulate 2 layers with q_proj + v_proj
    let layer_dims = vec![
        ("layers.6.self_attn.q_proj".to_string(), 64, 64),
        ("layers.6.self_attn.v_proj".to_string(), 64, 32),
        ("layers.7.self_attn.q_proj".to_string(), 64, 64),
        ("layers.7.self_attn.v_proj".to_string(), 64, 32),
    ];

    let adapters = TrainableLoRAAdapters::new(config, &layer_dims, &device).unwrap();

    // 4 layers × 2 vars each = 8 trainable vars
    assert_eq!(adapters.vars().len(), 8);
    assert!(adapters.num_parameters() > 0);

    // Can retrieve by layer index
    assert!(adapters.get_layer(6, "q_proj").is_some());
    assert!(adapters.get_layer(7, "v_proj").is_some());
    assert!(adapters.get_layer(0, "q_proj").is_none());
}

/// Save → Load roundtrip preserves LoRA weights
#[test]
fn test_lora_save_load_roundtrip() {
    let device = Device::Cpu;
    let config = LoRAConfig {
        rank: 4,
        alpha: 8.0,
        target_modules: vec!["q_proj".to_string()],
        dropout: 0.0,
    };

    let layer_dims = vec![
        ("layers.0.self_attn.q_proj".to_string(), 32, 32),
        ("layers.1.self_attn.q_proj".to_string(), 32, 32),
    ];

    let adapters = TrainableLoRAAdapters::new(config.clone(), &layer_dims, &device).unwrap();

    // Snapshot original weights
    let orig_a0: Vec<f32> = adapters
        .get_layer(0, "q_proj")
        .unwrap()
        .lora_a
        .as_tensor()
        .flatten_all()
        .unwrap()
        .to_vec1()
        .unwrap();

    // Save to temp file
    let tmp = std::env::temp_dir().join("test_soul_roundtrip.safetensors");
    let tmp_str = tmp.to_str().unwrap();
    adapters.save(tmp_str).unwrap();

    assert!(tmp.exists(), "Safetensors file should be created");
    assert!(
        tmp.metadata().unwrap().len() > 0,
        "File should be non-empty"
    );

    // Load into fresh adapters
    let mut loaded = TrainableLoRAAdapters::new(config, &layer_dims, &device).unwrap();
    loaded.load(tmp_str).unwrap();

    let loaded_a0: Vec<f32> = loaded
        .get_layer(0, "q_proj")
        .unwrap()
        .lora_a
        .as_tensor()
        .flatten_all()
        .unwrap()
        .to_vec1()
        .unwrap();

    // Values should match exactly (same file, same device)
    for (o, l) in orig_a0.iter().zip(loaded_a0.iter()) {
        assert!(
            (o - l).abs() < 1e-7,
            "Weight mismatch after roundtrip: {} vs {}",
            o,
            l
        );
    }

    // Cleanup
    let _ = std::fs::remove_file(&tmp);
}

/// Train → save → load → continue training (resume workflow)
#[test]
fn test_lora_train_save_resume() {
    let device = Device::Cpu;
    let config = LoRAConfig {
        rank: 4,
        alpha: 8.0,
        target_modules: vec!["q_proj".to_string()],
        dropout: 0.0,
    };
    let layer_dims = vec![("layers.0.self_attn.q_proj".to_string(), 32, 32)];

    // Phase 1: Train 5 steps
    let adapters1 = TrainableLoRAAdapters::new(config.clone(), &layer_dims, &device).unwrap();
    let mut opt1 = AdamW::new(adapters1.vars(), 1e-2).unwrap();
    let x = Tensor::ones((1, 4, 32), candle_core::DType::F32, &device).unwrap();
    let target = Tensor::ones((1, 4, 32), candle_core::DType::F32, &device)
        .unwrap()
        .affine(0.3, 0.0)
        .unwrap();

    for _ in 0..5 {
        let pred = adapters1.get_layer(0, "q_proj").unwrap().forward(&x).unwrap();
        let loss = mse_loss(&pred, &target).unwrap();
        let grads = loss.backward().unwrap();
        opt1.step(&grads).unwrap();
    }

    let loss_after_phase1 = {
        let pred = adapters1.get_layer(0, "q_proj").unwrap().forward(&x).unwrap();
        mse_loss(&pred, &target)
            .unwrap()
            .to_scalar::<f32>()
            .unwrap()
    };

    // Save
    let tmp = std::env::temp_dir().join("test_soul_resume.safetensors");
    let tmp_str = tmp.to_str().unwrap();
    adapters1.save(tmp_str).unwrap();

    // Phase 2: Load into fresh adapters, train 5 more steps
    let mut adapters2 = TrainableLoRAAdapters::new(config, &layer_dims, &device).unwrap();
    adapters2.load(tmp_str).unwrap();
    let mut opt2 = AdamW::new(adapters2.vars(), 1e-2).unwrap();

    for _ in 0..5 {
        let pred = adapters2.get_layer(0, "q_proj").unwrap().forward(&x).unwrap();
        let loss = mse_loss(&pred, &target).unwrap();
        let grads = loss.backward().unwrap();
        opt2.step(&grads).unwrap();
    }

    let loss_after_phase2 = {
        let pred = adapters2.get_layer(0, "q_proj").unwrap().forward(&x).unwrap();
        mse_loss(&pred, &target)
            .unwrap()
            .to_scalar::<f32>()
            .unwrap()
    };

    assert!(
        loss_after_phase2 < loss_after_phase1,
        "Resumed training should continue reducing loss: phase1={:.6}, phase2={:.6}",
        loss_after_phase1,
        loss_after_phase2
    );

    let _ = std::fs::remove_file(&tmp);
}

/// Disabled LoRA produces zero output
#[test]
fn test_lora_disabled_produces_zeros() {
    let device = Device::Cpu;
    let mut lora = TrainableLoRALayer::new(32, 32, 4, 8.0, &device).unwrap();
    lora.enabled = false;

    let x = Tensor::ones((2, 32), candle_core::DType::F32, &device).unwrap();
    let out = lora.forward(&x).unwrap();

    let sum: f32 = out.abs().unwrap().sum_all().unwrap().to_scalar().unwrap();
    assert!(
        sum < 1e-10,
        "Disabled LoRA should produce zeros, got sum={}",
        sum
    );
}

// ─── Optional tests (GGUF model required) ──────────────────────────

/// Full Soul learning pipeline: load model → init LoRA → train → loss decreases → save
#[test]
fn test_full_soul_learning_pipeline() {
    let model_path = common::get_gguf_model_path();
    if !model_path.exists() {
        eprintln!(
            "⏭️  Skipping full pipeline test: GGUF model not found at {:?}",
            model_path
        );
        return;
    }

    // Check for tokenizer.json next to model
    let tok_path = model_path.parent().unwrap().join("tokenizer.json");
    if !tok_path.exists() {
        eprintln!(
            "⏭️  Skipping full pipeline test: tokenizer.json not found at {:?}",
            tok_path
        );
        return;
    }

    let device = Device::Cpu;

    // 1. Load model
    let mut model = cortex_rust::model::gguf_model_quantized::QGgufModel::load(&model_path, &device)
        .expect("Failed to load GGUF model");
    let config = model.config().clone();

    // 2. Load tokenizer + encode
    let tokenizer = tokenizers::Tokenizer::from_file(&tok_path)
        .expect("Failed to load tokenizer");
    let text = "The capital of France is Paris.";
    let encoding = tokenizer.encode(text, true).expect("Tokenization failed");
    let token_ids: Vec<i64> = encoding.get_ids().iter().map(|&x| x as i64).collect();
    assert!(token_ids.len() >= 2, "Need at least 2 tokens");

    let seq_len = token_ids.len();
    let input_ids: Vec<i64> = token_ids[..seq_len - 1].to_vec();
    let labels: Vec<i64> = token_ids[1..].to_vec();
    let train_len = input_ids.len();

    // 3. Init Soul LoRA (last 1/4 layers)
    let hidden_dim = config.hidden_dim;
    let n_heads = config.n_heads;
    let n_kv_heads = config.n_kv_heads;
    let head_dim = hidden_dim / n_heads;
    let num_layers = config.num_layers;
    let start_layer = num_layers * 3 / 4;
    let rank = 4; // small rank for test speed

    let lora_config = LoRAConfig {
        rank,
        alpha: (rank * 2) as f32,
        target_modules: vec!["q_proj".to_string(), "v_proj".to_string()],
        dropout: 0.0,
    };

    let mut layer_dims = Vec::new();
    for idx in start_layer..num_layers {
        layer_dims.push((
            format!("layers.{}.self_attn.q_proj", idx),
            hidden_dim,
            n_heads * head_dim,
        ));
        layer_dims.push((
            format!("layers.{}.self_attn.v_proj", idx),
            hidden_dim,
            n_kv_heads * head_dim,
        ));
    }

    let lora = TrainableLoRAAdapters::new(lora_config, &layer_dims, &device)
        .expect("Failed to init LoRA");

    assert!(lora.num_parameters() > 0, "LoRA should have parameters");

    // 4. Train 3 epochs, collect losses
    let vars = lora.vars();
    let mut opt = AdamW::new(vars, 1e-4).expect("Failed to init optimizer");
    let mut losses = Vec::new();

    for epoch in 0..3 {
        let input = Tensor::from_vec(input_ids.clone(), (1, train_len), &device).unwrap();
        model.reset_cache();

        let logits = model
            .forward_with_trainable_lora(&input, &lora, 0)
            .expect("Forward pass failed");

        let vocab_size = logits.dim(2).unwrap();
        let logits_flat = logits.reshape((train_len, vocab_size)).unwrap();
        let targets = Tensor::from_vec(labels.clone(), (train_len,), &device)
            .unwrap()
            .to_dtype(candle_core::DType::U32)
            .unwrap();

        let loss = candle_nn::loss::cross_entropy(&logits_flat, &targets)
            .expect("Loss computation failed");
        let loss_val = loss.to_scalar::<f32>().unwrap();
        losses.push(loss_val);

        let grads = loss.backward().expect("Backward failed");
        opt.step(&grads).expect("Optimizer step failed");

        eprintln!("   epoch {}: loss = {:.4}", epoch + 1, loss_val);
    }

    assert!(
        losses.iter().all(|l| l.is_finite()),
        "All losses must be finite"
    );

    // Loss should generally trend down (compare first vs last)
    let first_loss = losses[0];
    let last_loss = *losses.last().unwrap();
    eprintln!(
        "   Loss trend: {:.4} → {:.4} (delta: {:.4})",
        first_loss,
        last_loss,
        first_loss - last_loss
    );

    // 5. Save soul
    let tmp = std::env::temp_dir().join("test_soul_pipeline.safetensors");
    let tmp_str = tmp.to_str().unwrap();
    lora.save(tmp_str).expect("Failed to save soul");
    assert!(tmp.exists(), "Soul file should be created");
    assert!(
        tmp.metadata().unwrap().len() > 100,
        "Soul file should contain tensor data"
    );

    let _ = std::fs::remove_file(&tmp);
    eprintln!("✅ Full Soul learning pipeline passed");
}

/// Soul modifies inference: logits with soul ≠ logits without soul
#[test]
fn test_soul_changes_inference_output() {
    let model_path = common::get_gguf_model_path();
    if !model_path.exists() {
        eprintln!("⏭️  Skipping inference diff test: GGUF model not found");
        return;
    }

    let device = Device::Cpu;

    // 1. Baseline inference (no soul)
    let mut model = cortex_rust::model::gguf_model_quantized::QGgufModel::load(&model_path, &device)
        .expect("Failed to load model");

    let input = Tensor::new(&[[1i64, 2, 3]], &device).unwrap();

    model.reset_cache();
    let logits_base = model.forward(&input, 0).expect("Baseline forward failed");
    let base_vec: Vec<f32> = logits_base
        .flatten_all()
        .unwrap()
        .to_vec1()
        .unwrap();

    // 2. Create and apply a trained LoRA
    let config = model.config().clone();
    let hidden_dim = config.hidden_dim;
    let n_heads = config.n_heads;
    let n_kv_heads = config.n_kv_heads;
    let head_dim = hidden_dim / n_heads;
    let num_layers = config.num_layers;
    let start_layer = num_layers * 3 / 4;

    let lora_config = LoRAConfig {
        rank: 4,
        alpha: 8.0,
        target_modules: vec!["q_proj".to_string(), "v_proj".to_string()],
        dropout: 0.0,
    };

    let mut layer_dims = Vec::new();
    for idx in start_layer..num_layers {
        layer_dims.push((
            format!("layers.{}.self_attn.q_proj", idx),
            hidden_dim,
            n_heads * head_dim,
        ));
        layer_dims.push((
            format!("layers.{}.self_attn.v_proj", idx),
            hidden_dim,
            n_kv_heads * head_dim,
        ));
    }

    let lora = TrainableLoRAAdapters::new(lora_config, &layer_dims, &device).unwrap();

    // Apply LoRA to model's inference path
    for (name, trainable_layer) in &lora.layers {
        let parts: Vec<&str> = name.split('.').collect();
        if parts.len() >= 4 {
            if let Ok(layer_idx) = parts[1].parse::<usize>() {
                let proj = parts.last().unwrap_or(&"");
                let inference_lora = cortex_rust::layers::LoRALayer {
                    lora_a: trainable_layer.lora_a.as_tensor().clone(),
                    lora_b: trainable_layer.lora_b.as_tensor().clone(),
                    scaling: trainable_layer.scaling,
                    in_features: trainable_layer.in_features,
                    out_features: trainable_layer.out_features,
                    rank: trainable_layer.rank,
                    enabled: true,
                };
                model.set_layer_lora(layer_idx, proj, inference_lora);
            }
        }
    }
    model.enable_lora(true);
    model.enable_hybrid_lora(true);

    // 3. Inference with soul
    model.reset_cache();
    let logits_soul = model.forward(&input, 0).expect("Soul forward failed");
    let soul_vec: Vec<f32> = logits_soul
        .flatten_all()
        .unwrap()
        .to_vec1()
        .unwrap();

    // 4. Outputs must differ
    let max_diff: f32 = base_vec
        .iter()
        .zip(soul_vec.iter())
        .map(|(a, b)| (a - b).abs())
        .fold(0.0f32, f32::max);

    assert!(
        max_diff > 1e-6,
        "Soul should change logits, but max_diff = {}",
        max_diff
    );
    eprintln!(
        "✅ Soul changes inference: max logit diff = {:.6}",
        max_diff
    );
}
