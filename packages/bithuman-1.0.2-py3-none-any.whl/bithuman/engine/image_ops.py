"""Image operations — replaces image_ops.cpp (SSE2 blend + bilinear resize).

Provides two blend implementations:
1. numba JIT (primary) — per-pixel with exact div255 formula, SIMD-comparable
2. numpy fallback — vectorized uint16 arithmetic, ~3-5ms for typical face ROI

Resize delegates to cv2.resize (IPP/SIMD-optimized internally).
"""

from __future__ import annotations

import numpy as np
import cv2

try:
    from numba import njit, prange

    _HAS_NUMBA = True
except ImportError:
    _HAS_NUMBA = False


# ---------------------------------------------------------------------------
# Blend: numba JIT (primary path)
# ---------------------------------------------------------------------------
if _HAS_NUMBA:

    @njit(cache=True, parallel=True)
    def _blend_3ch_numba(
        frame: np.ndarray,
        lip: np.ndarray,
        mask: np.ndarray,
        roi_x: int,
        roi_y: int,
        roi_h: int,
        roi_w: int,
    ) -> None:
        """In-place alpha blend with 3-channel mask using exact div255."""
        for y in prange(roi_h):
            for x in range(roi_w):
                for c in range(3):
                    m = np.uint16(mask[y, x, c])
                    im = np.uint16(255) - m
                    val = np.uint16(lip[y, x, c]) * m + np.uint16(
                        frame[roi_y + y, roi_x + x, c]
                    ) * im
                    # div255: exact integer division by 255
                    val = (val + np.uint16(1) + ((val + np.uint16(1)) >> np.uint16(8))) >> np.uint16(8)
                    frame[roi_y + y, roi_x + x, c] = np.uint8(val)

    @njit(cache=True, parallel=True)
    def _blend_1ch_numba(
        frame: np.ndarray,
        lip: np.ndarray,
        mask: np.ndarray,
        roi_x: int,
        roi_y: int,
        roi_h: int,
        roi_w: int,
    ) -> None:
        """In-place alpha blend with 1-channel mask using exact div255."""
        for y in prange(roi_h):
            for x in range(roi_w):
                m = np.uint16(mask[y, x, 0] if mask.ndim == 3 else mask[y, x])
                im = np.uint16(255) - m
                for c in range(3):
                    val = np.uint16(lip[y, x, c]) * m + np.uint16(
                        frame[roi_y + y, roi_x + x, c]
                    ) * im
                    val = (val + np.uint16(1) + ((val + np.uint16(1)) >> np.uint16(8))) >> np.uint16(8)
                    frame[roi_y + y, roi_x + x, c] = np.uint8(val)


# ---------------------------------------------------------------------------
# Blend: numpy fallback
# ---------------------------------------------------------------------------
def _blend_numpy(
    frame: np.ndarray,
    lip: np.ndarray,
    mask: np.ndarray,
    roi_x: int,
    roi_y: int,
    roi_h: int,
    roi_w: int,
) -> None:
    """Vectorized numpy blend with exact div255 formula."""
    roi = frame[roi_y : roi_y + roi_h, roi_x : roi_x + roi_w]

    # Ensure mask is 3-channel
    if mask.ndim == 2:
        m = mask[:, :, np.newaxis].astype(np.uint16)
    elif mask.ndim == 3 and mask.shape[2] == 1:
        m = mask.astype(np.uint16)
    else:
        m = mask.astype(np.uint16)

    # Broadcast to 3 channels if needed
    if m.shape[2] == 1:
        m = np.broadcast_to(m, roi.shape).copy()

    im = np.uint16(255) - m
    val = lip[:roi_h, :roi_w].astype(np.uint16) * m + roi.astype(np.uint16) * im
    # div255: (val + 1 + ((val + 1) >> 8)) >> 8
    val_p1 = val + np.uint16(1)
    result = ((val_p1 + (val_p1 >> 8)) >> 8).astype(np.uint8)
    frame[roi_y : roi_y + roi_h, roi_x : roi_x + roi_w] = result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def blend_face_region(
    frame: np.ndarray,
    roi_x: int,
    roi_y: int,
    roi_w: int,
    roi_h: int,
    lip: np.ndarray,
    mask: np.ndarray,
) -> None:
    """Alpha-blend lip overlay into face region of frame (in-place).

    Matches image_ops.cpp blend_face_region (lines 429-503):
    Formula per byte: out = div255(lip * mask + face * (255 - mask))
    where div255(x) = (x + 1 + ((x + 1) >> 8)) >> 8

    Args:
        frame: (H, W, 3) uint8 BGR — modified in-place.
        roi_x, roi_y: top-left corner of face region in frame.
        roi_w, roi_h: dimensions of face region.
        lip: (roi_h, roi_w, 3) uint8 BGR lip overlay.
        mask: (roi_h, roi_w, 1) or (roi_h, roi_w, 3) uint8 blend mask.
    """
    is_3ch = mask.ndim == 3 and mask.shape[2] == 3

    if _HAS_NUMBA:
        if is_3ch:
            _blend_3ch_numba(frame, lip, mask, roi_x, roi_y, roi_h, roi_w)
        else:
            _blend_1ch_numba(frame, lip, mask, roi_x, roi_y, roi_h, roi_w)
    else:
        _blend_numpy(frame, lip, mask, roi_x, roi_y, roi_h, roi_w)


def resize_image(image: np.ndarray, new_width: int, new_height: int) -> np.ndarray:
    """Bilinear resize using OpenCV (IPP/SIMD optimized).

    Replaces image_ops.cpp resize_image (lines 347-375).
    """
    if image.size == 0:
        return image
    h, w = image.shape[:2]
    if w == new_width and h == new_height:
        return image
    return cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_LINEAR)


def resize_image_scale(image: np.ndarray, scale: float) -> np.ndarray:
    """Resize by scale factor. Replaces resize_image_scale in C++."""
    if scale == 1.0 or image.size == 0:
        return image
    new_w = round(image.shape[1] * scale)
    new_h = round(image.shape[0] * scale)
    return resize_image(image, new_w, new_h)


# ---------------------------------------------------------------------------
# Pre-warm numba JIT in background thread (avoids ~200ms spike on first blend)
# ---------------------------------------------------------------------------
def _warmup_numba_jit() -> None:
    """Trigger JIT compilation of blend functions with tiny arrays.

    With cache=True, the compiled code persists to __pycache__ for
    subsequent process starts.
    """
    if not _HAS_NUMBA:
        return
    try:
        _tiny_frame = np.zeros((2, 2, 3), dtype=np.uint8)
        _tiny_lip = np.zeros((1, 1, 3), dtype=np.uint8)
        _tiny_mask_3ch = np.zeros((1, 1, 3), dtype=np.uint8)
        _tiny_mask_1ch = np.zeros((1, 1, 1), dtype=np.uint8)
        _blend_3ch_numba(_tiny_frame, _tiny_lip, _tiny_mask_3ch, 0, 0, 1, 1)
        _blend_1ch_numba(_tiny_frame, _tiny_lip, _tiny_mask_1ch, 0, 0, 1, 1)
    except Exception:
        pass  # Warmup failure is non-fatal


import threading as _threading

_warmup_thread = _threading.Thread(target=_warmup_numba_jit, daemon=True)
_warmup_thread.start()
