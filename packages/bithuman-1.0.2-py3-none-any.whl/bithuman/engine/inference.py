"""ONNX audio encoder inference — replaces C++ melChunkToAudioEmbedding."""

from __future__ import annotations

import os
import threading
from typing import Dict, Optional

import numpy as np
import onnxruntime as ort

# Module-level ONNX session cache keyed by absolute model path.
# ONNX Runtime internally shares model weights across sessions, but this
# avoids Python-side overhead (~8 KB per duplicate session object).
_onnx_session_cache: Dict[str, ort.InferenceSession] = {}
_onnx_session_lock = threading.Lock()


class AudioEncoder:
    """Wraps an ONNX audio encoder session for mel-to-embedding inference.

    Matches the C++ BithumanRuntime ONNX setup:
    - intra_op_num_threads=1 (avoid nested parallelism)
    - disable CPU memory arena (container compatibility)
    - fallback from EXTENDED to BASIC optimization level
    - pre-allocated input buffer reused across calls
    """

    def __init__(self, model_path: str = ""):
        self._session: Optional[ort.InferenceSession] = None
        self._input_name: Optional[str] = None
        self._output_name: Optional[str] = None
        # Pre-allocated input buffer matching C++ onnx_input_data_ (1*1*80*16)
        self._input_buf: np.ndarray = np.zeros((1, 1, 80, 16), dtype=np.float32)
        if model_path:
            self.load(model_path)

    def load(self, model_path: str) -> None:
        """Load ONNX model, reusing cached session if available.

        Mirrors generator.cpp setAudioEncoder (lines 439-502):
        - Try EXTENDED first, fall back to BASIC on failure.
        """
        abs_path = os.path.abspath(model_path)

        with _onnx_session_lock:
            if abs_path in _onnx_session_cache:
                self._session = _onnx_session_cache[abs_path]
                self._input_name = self._session.get_inputs()[0].name
                self._output_name = self._session.get_outputs()[0].name
                return

        # Create new session outside the lock (loading can be slow)
        opts = ort.SessionOptions()
        opts.intra_op_num_threads = 1
        opts.enable_cpu_mem_arena = False

        try:
            opts.graph_optimization_level = (
                ort.GraphOptimizationLevel.ORT_ENABLE_EXTENDED
            )
            session = ort.InferenceSession(model_path, opts)
        except Exception:
            opts.graph_optimization_level = (
                ort.GraphOptimizationLevel.ORT_ENABLE_BASIC
            )
            try:
                session = ort.InferenceSession(model_path, opts)
            except Exception as e:
                raise RuntimeError(
                    f"Failed to load audio encoder model '{model_path}': {e}"
                ) from e

        with _onnx_session_lock:
            # Double-check: another thread may have cached it while we were loading
            if abs_path in _onnx_session_cache:
                session = _onnx_session_cache[abs_path]
            else:
                _onnx_session_cache[abs_path] = session

        self._session = session
        self._input_name = self._session.get_inputs()[0].name
        self._output_name = self._session.get_outputs()[0].name

    def encode(self, mel_chunk: np.ndarray) -> np.ndarray:
        """Convert a mel spectrogram chunk to an audio embedding.

        Args:
            mel_chunk: float32 array of shape (80, 16).

        Returns:
            float32 array of shape (embedding_dim,).

        Mirrors generator.cpp melChunkToAudioEmbedding (lines 505-533):
        - Input shape: (1, 1, 80, 16), row-major (C-contiguous = numpy default).
        - Output: squeezed to 1-D embedding vector.
        """
        if self._session is None:
            raise RuntimeError("Audio encoder not initialized")

        # Copy into pre-allocated buffer (matches C++ zero-copy pattern)
        np.copyto(self._input_buf[0, 0], mel_chunk.astype(np.float32))

        result = self._session.run(
            [self._output_name],
            {self._input_name: self._input_buf},
        )
        return result[0].squeeze()
