"""Audio feature KNN search — replaces Eigen squaredNorm + minCoeff."""

from __future__ import annotations

import numpy as np


class AudioFeatureIndex:
    """Stores audio feature cluster centers and finds the nearest match.

    Mirrors generator.cpp processAudio (lines 337-342):
    ``(audio_features_.rowwise() - audio_embed.transpose())
        .rowwise().squaredNorm().minCoeff(&min_index)``
    """

    def __init__(self) -> None:
        self._features: np.ndarray = np.empty((0, 0), dtype=np.float32)

    def set_features(self, features: np.ndarray) -> None:
        """Set audio feature cluster centers.

        Args:
            features: float32 array shape (num_clusters, embedding_dim), row-major.
        """
        self._features = np.ascontiguousarray(features, dtype=np.float32)

    def load_from_h5(self, h5_path: str) -> None:
        """Load audio features from an HDF5 file.

        Mirrors generator.cpp setAudioFeature (lines 409-432):
        Reads dataset ``audio_feature`` as row-major float32 matrix.
        """
        import h5py

        with h5py.File(h5_path, "r") as f:
            data = f["audio_feature"][:]
        self.set_features(data)

    def find_nearest(self, embedding: np.ndarray) -> int:
        """Return index of nearest cluster center by squared Euclidean distance.

        Args:
            embedding: float32 array shape (embedding_dim,).

        Returns:
            Index of the nearest cluster center.
        """
        diff = self._features - embedding
        sq_dists = np.einsum("ij,ij->i", diff, diff)
        return int(np.argmin(sq_dists))

    @property
    def num_clusters(self) -> int:
        return self._features.shape[0]

    @property
    def embedding_dim(self) -> int:
        return self._features.shape[1] if self._features.size > 0 else 0
