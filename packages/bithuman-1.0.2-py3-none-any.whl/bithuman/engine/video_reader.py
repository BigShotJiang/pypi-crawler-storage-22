"""Video decoding with PyAV — replaces video_decode.cpp.

Handles both regular video files and XOR-encrypted .bhtensor files.
"""

from __future__ import annotations

import io
from typing import Iterator, List, Optional

import numpy as np

ENCRYPT_KEY = b"bithuman_video_data_key"  # 26 bytes — matches C++ video_data_key


def is_encrypted_file(path: str) -> bool:
    """Check if file is encrypted based on extension.

    Matches video_decode.cpp isEncryptedFile.
    """
    return path.endswith(".bhtensor")


def xor_decrypt_bytes(data: bytes, key: bytes = ENCRYPT_KEY) -> bytes:
    """XOR-decrypt data in-place style, returning a new bytes object.

    Matches video_decode.cpp decryptDataInPlace: byte-wise XOR with repeating key.
    Uses numpy for vectorized XOR (much faster than Python byte loop).
    """
    key_len = len(key)
    data_arr = np.frombuffer(data, dtype=np.uint8).copy()
    key_arr = np.frombuffer(key, dtype=np.uint8)

    # Tile key to match data length and XOR
    full_key = np.tile(key_arr, len(data_arr) // key_len + 1)[: len(data_arr)]
    data_arr ^= full_key
    return data_arr.tobytes()


def read_and_decrypt_file(path: str, key: bytes = ENCRYPT_KEY) -> bytes:
    """Read file and XOR-decrypt its contents.

    Matches video_decode.cpp readAndDecryptFile.
    """
    with open(path, "rb") as f:
        data = f.read()
    return xor_decrypt_bytes(data, key)


class VideoReader:
    """PyAV-based video reader replacing FFmpeg C wrapper.

    Decodes all frames into memory for random access. Avatar data videos
    are typically small, so this is acceptable and matches SYNC loading.

    For encrypted .bhtensor files, the file is fully decrypted into memory
    then passed to PyAV via BytesIO.
    """

    def __init__(
        self,
        video_path: str,
        key: str = "",
        thread_count: int = 0,
    ) -> None:
        import av

        self._path = video_path
        self._is_encrypted = is_encrypted_file(video_path)

        # Open container
        if self._is_encrypted:
            decrypt_key = key.encode("utf-8") if key else ENCRYPT_KEY
            decrypted = read_and_decrypt_file(video_path, decrypt_key)
            self._container = av.open(io.BytesIO(decrypted))
        else:
            self._container = av.open(video_path)

        stream = self._container.streams.video[0]
        stream.thread_type = "AUTO"

        self._width: int = stream.codec_context.width
        self._height: int = stream.codec_context.height

        # Decode all frames into memory for random access
        self._frames: List[np.ndarray] = []
        self._container.seek(0)
        for frame in self._container.decode(video=0):
            bgr = frame.to_ndarray(format="bgr24")
            self._frames.append(bgr)

        self._frame_count = len(self._frames)

    def get(self, index: int) -> np.ndarray:
        """Get a decoded frame by index (returns a copy).

        Matches VideoReader::get in video_decode.cpp.
        """
        if index < 0:
            index = self._frame_count + index
        if index < 0 or index >= self._frame_count:
            raise IndexError(
                f"Frame index {index} out of range [0, {self._frame_count})"
            )
        return self._frames[index].copy()

    def size(self) -> int:
        """Return total number of decoded frames."""
        return self._frame_count

    @property
    def width(self) -> int:
        return self._width

    @property
    def height(self) -> int:
        return self._height

    def close(self) -> None:
        if self._container:
            self._container.close()
            self._container = None


def iter_video_frames(
    video_path: str,
    key: str = "",
    thread_count: int = 0,
    max_frames: int = -1,
) -> Iterator[np.ndarray]:
    """Yield decoded BGR24 frames one at a time from a video file.

    Unlike VideoReader (which decodes all frames into memory), this function
    yields frames sequentially and discards each one after yielding. Peak
    memory is ~1 frame instead of all frames.

    Args:
        video_path: Path to video file (.mp4 or .bhtensor).
        key: Decryption key for .bhtensor files. Empty string uses default.
        thread_count: Unused (kept for API symmetry with VideoReader).
        max_frames: Maximum number of frames to yield. -1 means all frames.

    Yields:
        BGR24 numpy arrays of shape (height, width, 3).
    """
    import av

    encrypted = is_encrypted_file(video_path)

    if encrypted:
        decrypt_key = key.encode("utf-8") if key else ENCRYPT_KEY
        decrypted = read_and_decrypt_file(video_path, decrypt_key)
        container = av.open(io.BytesIO(decrypted))
    else:
        container = av.open(video_path)

    try:
        stream = container.streams.video[0]
        stream.thread_type = "AUTO"
        container.seek(0)
        count = 0
        for frame in container.decode(video=0):
            if 0 <= max_frames <= count:
                break
            yield frame.to_ndarray(format="bgr24")
            count += 1
    finally:
        container.close()
