"""bithuman CLI — model conversion and utilities.

Usage:
    python -m bithuman convert <model.imx> [--quality 85] [--output new_model.imx]
    bithuman convert <model.imx> [--quality 85] [--output new_model.imx]
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import sys
import tarfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tempfile import TemporaryDirectory


def _find_avatar_bhtensor_files(workspace_dir: str) -> list[Path]:
    """Find .bhtensor files that are avatar lip-sync data (not main videos)."""
    workspace = Path(workspace_dir)
    avatar_files = []
    for pattern in ["*.feature-first.bhtensor", "*.time-first.bhtensor"]:
        avatar_files.extend(workspace.rglob(pattern))
    return sorted(avatar_files)


def _convert_bhtensor_to_bjpeg_standalone(
    bhtensor_path: str,
    quality: int = 85,
) -> str:
    """Convert a single .bhtensor to .bjpeg without importing torch/encrypt.py.

    Uses only bithuman.engine.video_reader and bithuman.engine.compression.
    Returns the path to the created .bjpeg file.
    """
    import av
    import numpy as np

    from bithuman.engine.compression import encode_jpeg
    from bithuman.engine.video_reader import (
        ENCRYPT_KEY,
        _write_bjpeg_from_blobs,
        read_and_decrypt_file,
    )

    input_path = Path(bhtensor_path)
    name = input_path.name
    if name.endswith(".bhtensor"):
        output_file = str(input_path.parent / (name[: -len(".bhtensor")] + ".bjpeg"))
    else:
        output_file = str(input_path.with_suffix(".bjpeg"))

    # Decrypt
    print(f"  Decrypting {input_path.name}...")
    decrypted = read_and_decrypt_file(bhtensor_path, ENCRYPT_KEY)

    # Decode H.264 + parallel JPEG encode
    print(f"  Decoding H.264 + parallel JPEG encoding...")
    container = av.open(io.BytesIO(decrypted))
    stream = container.streams.video[0]
    stream.thread_type = "AUTO"
    container.seek(0)

    num_workers = min(os.cpu_count() or 4, 8)
    width, height = None, None
    futures = []
    with ThreadPoolExecutor(max_workers=num_workers) as pool:
        for frame in container.decode(video=0):
            bgr = frame.to_ndarray(format="bgr24")
            if width is None:
                height, width = bgr.shape[:2]
            futures.append(pool.submit(encode_jpeg, bgr, quality))
        jpeg_blobs = [f.result() for f in futures]

    container.close()
    del decrypted

    print(f"  {len(jpeg_blobs)} frames ({width}x{height})")
    print(f"  Writing .bjpeg...")

    _write_bjpeg_from_blobs(output_file, jpeg_blobs, width, height, quality, ENCRYPT_KEY)

    in_size = input_path.stat().st_size / 1024 / 1024
    out_size = Path(output_file).stat().st_size / 1024 / 1024
    print(f"  {input_path.name} ({in_size:.1f} MB) -> {Path(output_file).name} ({out_size:.1f} MB)")

    return output_file


def _convert_video_to_bjpeg(
    video_path: str,
    h5_path: str,
    quality: int = 85,
) -> str:
    """Convert an .mp4 video to .bjpeg, resized to HDF5 frame_wh.

    Returns the path to the created .bjpeg file.
    """
    import av
    import h5py
    import numpy as np

    from bithuman.engine.compression import encode_jpeg
    from bithuman.engine.video_reader import ENCRYPT_KEY, _write_bjpeg_from_blobs

    input_path = Path(video_path)
    output_file = str(input_path.parent / (input_path.stem + ".bjpeg"))

    # Read target resolution from HDF5
    with h5py.File(h5_path, "r") as f:
        wh = f.attrs["frame_wh"]
        target_w, target_h = int(wh[0]), int(wh[1])

    # Decode .mp4 + parallel JPEG encode at target resolution
    print(f"  Decoding {input_path.name} → resize to {target_w}x{target_h}...")
    container = av.open(str(video_path))
    stream = container.streams.video[0]
    stream.thread_type = "AUTO"
    container.seek(0)

    import cv2

    num_workers = min(os.cpu_count() or 4, 8)
    futures = []
    with ThreadPoolExecutor(max_workers=num_workers) as pool:
        for frame in container.decode(video=0):
            bgr = frame.to_ndarray(format="bgr24")
            if bgr.shape[1] != target_w or bgr.shape[0] != target_h:
                bgr = cv2.resize(bgr, (target_w, target_h))
            futures.append(pool.submit(encode_jpeg, bgr, quality))
        jpeg_blobs = [f.result() for f in futures]

    container.close()

    print(f"  {len(jpeg_blobs)} frames ({target_w}x{target_h})")
    print(f"  Writing {Path(output_file).name}...")

    _write_bjpeg_from_blobs(output_file, jpeg_blobs, target_w, target_h, quality, ENCRYPT_KEY)

    out_size = Path(output_file).stat().st_size / 1024 / 1024
    print(f"  {input_path.name} → {Path(output_file).name} ({out_size:.1f} MB)")

    return output_file


def _generate_bimx_metadata(
    workspace: Path,
    model_hash: str,
) -> dict:
    """Generate bimx_metadata.json content for the workspace.

    Scans the workspace for videos (from videos.yaml), computes per-video
    metadata, and returns the metadata dict.
    """
    import h5py
    import yaml

    videos_yaml = workspace / "videos.yaml"
    if not videos_yaml.exists():
        raise FileNotFoundError(f"videos.yaml not found in {workspace}")

    with open(videos_yaml) as f:
        config = yaml.safe_load(f)

    metadata = {
        "version": 1,
        "model_hash": model_hash,
        "videos": {},
    }

    for vc in config.get("videos", []):
        name = vc["name"]
        video_file = vc.get("video_file", "")

        # Find the .mp4 file
        mp4_path = workspace / video_file
        if not mp4_path.exists():
            # Try searching
            mp4_candidates = list(workspace.rglob(f"{name}*.mp4"))
            mp4_path = mp4_candidates[0] if mp4_candidates else None

        # Find the .h5 file
        h5_candidates = list(workspace.rglob(f"{name}*.h5"))
        h5_path = h5_candidates[0] if h5_candidates else None

        # Find avatar .bjpeg
        avatar_candidates = list(workspace.rglob(f"{name}*.bjpeg"))
        # Exclude original video bjpeg (ones in videos/ dir)
        avatar_bjpeg = None
        original_bjpeg = None
        for c in avatar_candidates:
            rel = str(c.relative_to(workspace))
            if "avatar_models" in rel or "feature-first" in rel or "time-first" in rel:
                avatar_bjpeg = c
            elif "videos" in rel or rel.endswith(f"{name}.bjpeg"):
                original_bjpeg = c

        # Compute video hash from .mp4
        video_hash = ""
        frame_count = 0
        resolution = [0, 0]

        if mp4_path and mp4_path.exists():
            with open(mp4_path, "rb") as f:
                video_hash = hashlib.md5(f.read()).hexdigest()

        if h5_path and h5_path.exists():
            with h5py.File(str(h5_path), "r") as f:
                wh = f.attrs["frame_wh"]
                resolution = [int(wh[0]), int(wh[1])]
                frame_count = len(f["face_coords"])

        vmeta = {
            "hash": video_hash,
            "frame_count": frame_count,
            "resolution": resolution,
        }
        if h5_path:
            vmeta["h5_file"] = str(h5_path.relative_to(workspace))
        if avatar_bjpeg:
            vmeta["avatar_bjpeg_file"] = str(avatar_bjpeg.relative_to(workspace))
        if original_bjpeg:
            vmeta["original_bjpeg_file"] = str(original_bjpeg.relative_to(workspace))

        metadata["videos"][name] = vmeta

    return metadata


def cmd_convert(args: argparse.Namespace) -> int:
    """Convert old .imx (tar) model to new BIMX format with near-instant loading."""
    from bithuman.engine.video_reader import BimxContainer, is_bimx_file, write_imx_container

    imx_path = Path(args.imx_path)
    if not imx_path.exists():
        print(f"ERROR: File not found: {imx_path}")
        return 1

    # Already fully converted?
    if is_bimx_file(str(imx_path)):
        container = BimxContainer(str(imx_path))
        if container.has_metadata:
            print(f"Already converted: {imx_path}")
            return 0
        print(f"ERROR: BIMX container without metadata is not supported: {imx_path}")
        print("Please re-convert from the original tar .imx file.")
        return 1

    output_path = Path(args.output) if args.output else imx_path
    quality = args.quality
    overwriting = output_path.resolve() == imx_path.resolve()

    # Compute model hash from original file BEFORE conversion
    print("Computing model hash...")
    with open(imx_path, "rb") as f:
        h = hashlib.md5()
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
        model_hash = h.hexdigest()
    print(f"  Model hash: {model_hash}")

    imx_size = imx_path.stat().st_size / 1024 / 1024
    print(f"Input:   {imx_path} ({imx_size:.1f} MB)")
    print(f"Output:  {output_path}")
    if overwriting:
        print(f"WARNING: This will overwrite the original file!")
    print(f"Quality: {quality}")
    print()

    if overwriting and sys.stdin.isatty():
        answer = input("Overwrite the original .imx file? [y/N] ").strip().lower()
        if answer not in ("y", "yes"):
            print("Aborted.")
            return 1

    # Extract tar archive to temp directory
    temp_dir = TemporaryDirectory()
    print("Extracting .imx archive...")
    mode = "r:gz" if imx_path.name.endswith("gz") else "r"
    with tarfile.open(imx_path, mode) as tar:
        tar.extractall(temp_dir.name)

    # Find the workspace root (enter single directory if present)
    workspace = Path(temp_dir.name)
    contents = list(workspace.iterdir())
    if len(contents) == 1 and contents[0].is_dir():
        workspace = contents[0]

    print(f"  Extracted to: {workspace}")

    # Convert avatar .bhtensor files to .bjpeg (if any)
    avatar_files = _find_avatar_bhtensor_files(str(workspace))
    if avatar_files:
        print(f"\nFound {len(avatar_files)} avatar .bhtensor file(s) to convert:")
        for f in avatar_files:
            sz = f.stat().st_size / 1024 / 1024
            print(f"  {f.relative_to(workspace)} ({sz:.1f} MB)")

        print()
        for bhtensor_file in avatar_files:
            print(f"Converting {bhtensor_file.name}...")
            _convert_bhtensor_to_bjpeg_standalone(str(bhtensor_file), quality=quality)
            bhtensor_file.unlink()
            print(f"  Removed {bhtensor_file.name}")

    # Convert .mp4 video files to .bjpeg (resized to HDF5 frame_wh)
    mp4_files = sorted(workspace.rglob("videos/*.mp4"))
    converted_mp4s = set()
    if mp4_files:
        print(f"\nFound {len(mp4_files)} video .mp4 file(s) to convert:")
        for f in mp4_files:
            sz = f.stat().st_size / 1024 / 1024
            print(f"  {f.relative_to(workspace)} ({sz:.1f} MB)")

            # Find matching .h5 file
            h5_candidates = list(f.parent.glob(f"{f.name}*.h5"))
            if h5_candidates:
                print(f"\nConverting {f.name} to .bjpeg...")
                _convert_video_to_bjpeg(str(f), str(h5_candidates[0]), quality=quality)
                converted_mp4s.add(str(f.relative_to(workspace)))
            else:
                print(f"  WARNING: No .h5 file found for {f.name}, skipping .bjpeg conversion")

    # Generate metadata
    print(f"\nGenerating bimx_metadata.json...")
    metadata = _generate_bimx_metadata(workspace, model_hash)
    metadata_json = json.dumps(metadata, indent=2).encode("utf-8")
    metadata_path = workspace / "bimx_metadata.json"
    with open(metadata_path, "wb") as f:
        f.write(metadata_json)
    print(f"  {json.dumps(metadata, indent=2)}")

    # Collect all files for the new BIMX container
    # Skip .mp4 files that have .bjpeg counterparts, skip .bhtensor
    print(f"\nPacking new .imx binary container...")
    files = {}
    for item in sorted(workspace.rglob("*")):
        if item.is_file():
            rel_path = str(item.relative_to(workspace))
            # Skip .mp4 files that were converted to .bjpeg
            if rel_path in converted_mp4s:
                print(f"  Skipping {rel_path} (replaced by .bjpeg)")
                continue
            # Skip .bhtensor files (shouldn't exist after conversion, but safety check)
            if rel_path.endswith(".bhtensor"):
                continue
            with open(item, "rb") as f:
                files[rel_path] = f.read()

    # Write to temp file first, then move to output
    tmp_output = str(output_path) + ".tmp"
    write_imx_container(tmp_output, files)
    os.replace(tmp_output, str(output_path))

    out_size = output_path.stat().st_size / 1024 / 1024
    print(f"\nDone: {output_path} ({out_size:.1f} MB)")
    print(f"Size: {imx_size:.1f} MB -> {out_size:.1f} MB ({out_size / imx_size:.1%})")

    temp_dir.cleanup()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="bithuman",
        description="bithuman CLI — model conversion and utilities",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # convert subcommand
    convert_parser = subparsers.add_parser(
        "convert",
        help="Convert old .imx model to new format for 10x faster loading",
    )
    convert_parser.add_argument("imx_path", help="Path to .imx model file")
    convert_parser.add_argument(
        "--output",
        "-o",
        help="Output .imx path (default: overwrite original)",
    )
    convert_parser.add_argument(
        "--quality",
        "-q",
        type=int,
        default=85,
        help="JPEG compression quality 1-100 (default: 85)",
    )

    args = parser.parse_args()

    if args.command == "convert":
        return cmd_convert(args)
    else:
        parser.print_help()
        return 1
