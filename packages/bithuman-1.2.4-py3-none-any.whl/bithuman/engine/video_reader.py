"""Video decoding with PyAV — replaces video_decode.cpp.

Handles regular video files, XOR-encrypted .bhtensor files,
and .bjpeg indexed JPEG archives for on-demand frame access.
"""

from __future__ import annotations

import fnmatch
import io
import json
import os
import struct
import threading
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Iterator, List, Optional, Tuple

import numpy as np

ENCRYPT_KEY = b"bithuman_video_data_key"  # 26 bytes — matches C++ video_data_key

# .bjpeg format constants
BJPEG_MAGIC = b"BJPG"
BJPEG_VERSION = 1
BJPEG_HEADER_SIZE = 24  # magic(4) + version(2) + count(4) + w(2) + h(2) + q(1) + reserved(1) + data_offset(8)

# BIMX (.imx v2) binary container format constants
BIMX_MAGIC = b"BIMX"
BIMX_VERSION = 1


def is_encrypted_file(path: str) -> bool:
    """Check if file is encrypted based on extension.

    Matches video_decode.cpp isEncryptedFile.
    """
    return path.endswith(".bhtensor")


def is_bjpeg_file(path: str) -> bool:
    """Check if file is a .bjpeg indexed JPEG archive."""
    return path.endswith(".bjpeg")


def xor_decrypt_bytes(data: bytes, key: bytes = ENCRYPT_KEY) -> bytes:
    """XOR-decrypt data in-place style, returning a new bytes object.

    Matches video_decode.cpp decryptDataInPlace: byte-wise XOR with repeating key.
    Uses numpy for vectorized XOR (much faster than Python byte loop).
    """
    key_len = len(key)
    data_arr = np.frombuffer(data, dtype=np.uint8).copy()
    key_arr = np.frombuffer(key, dtype=np.uint8)

    # Tile key to match data length and XOR
    full_key = np.tile(key_arr, len(data_arr) // key_len + 1)[: len(data_arr)]
    data_arr ^= full_key
    return data_arr.tobytes()


def _write_xor_encrypted(
    f, file_offset: int, data: bytes, key: bytes
) -> None:
    """XOR-encrypt data at the correct key position and write to file.

    This enables streaming writes without building the entire encrypted file
    in memory. The key cycles correctly from the given file offset.
    """
    key_len = len(key)
    key_start = file_offset % key_len
    data_arr = np.frombuffer(data, dtype=np.uint8)
    key_arr = np.frombuffer(key, dtype=np.uint8)
    indices = np.arange(key_start, key_start + len(data)) % key_len
    f.write((data_arr ^ key_arr[indices]).tobytes())


def read_and_decrypt_file(path: str, key: bytes = ENCRYPT_KEY) -> bytes:
    """Read file and XOR-decrypt its contents.

    Matches video_decode.cpp readAndDecryptFile.
    """
    with open(path, "rb") as f:
        data = f.read()
    return xor_decrypt_bytes(data, key)


class VideoReader:
    """PyAV-based video reader replacing FFmpeg C wrapper.

    Decodes all frames into memory for random access. Avatar data videos
    are typically small, so this is acceptable and matches SYNC loading.

    For encrypted .bhtensor files, the file is fully decrypted into memory
    then passed to PyAV via BytesIO.
    """

    def __init__(
        self,
        video_path: str,
        key: str = "",
        thread_count: int = 0,
    ) -> None:
        import av

        self._path = video_path
        self._is_encrypted = is_encrypted_file(video_path)

        # Open container
        if self._is_encrypted:
            decrypt_key = key.encode("utf-8") if key else ENCRYPT_KEY
            decrypted = read_and_decrypt_file(video_path, decrypt_key)
            self._container = av.open(io.BytesIO(decrypted))
        else:
            self._container = av.open(video_path)

        stream = self._container.streams.video[0]
        stream.thread_type = "AUTO"

        self._width: int = stream.codec_context.width
        self._height: int = stream.codec_context.height

        # Decode all frames into memory for random access
        self._frames: List[np.ndarray] = []
        self._container.seek(0)
        for frame in self._container.decode(video=0):
            bgr = frame.to_ndarray(format="bgr24")
            self._frames.append(bgr)

        self._frame_count = len(self._frames)

    def get(self, index: int) -> np.ndarray:
        """Get a decoded frame by index (returns a copy).

        Matches VideoReader::get in video_decode.cpp.
        """
        if index < 0:
            index = self._frame_count + index
        if index < 0 or index >= self._frame_count:
            raise IndexError(
                f"Frame index {index} out of range [0, {self._frame_count})"
            )
        return self._frames[index].copy()

    def size(self) -> int:
        """Return total number of decoded frames."""
        return self._frame_count

    @property
    def width(self) -> int:
        return self._width

    @property
    def height(self) -> int:
        return self._height

    def close(self) -> None:
        if self._container:
            self._container.close()
            self._container = None


class IndexedJpegReader:
    """On-demand JPEG frame reader for .bjpeg indexed archives.

    Reads individual JPEG frames from disk on demand instead of decoding
    all frames into memory upfront. Uses ~1 MB RAM (header + index) vs
    ~14.8 GB for VideoReader with 48K lip-sync frames.

    The .bjpeg format stores XOR-encrypted individually-indexed JPEG frames
    with a header and offset table for O(1) random access.

    Format layout:
        [24-byte header] [N * 8-byte offset index] [concatenated JPEG blobs]
        All XOR-encrypted with cycling key.

    Thread-safe: concurrent get() calls are serialized via a lock on the
    underlying file handle (seek + read must be atomic).
    """

    def __init__(
        self,
        path: str,
        key: str = "",
        thread_count: int = 0,
        *,
        base_offset: int = 0,
        file_size: int = 0,
    ) -> None:
        self._path = path
        self._key = key.encode("utf-8") if key else ENCRYPT_KEY
        self._lock = threading.Lock()
        self._base_offset = base_offset

        # Open file and determine bjpeg size
        self._file = open(path, "rb")
        if file_size > 0:
            self._file_size = file_size
        else:
            self._file.seek(0, 2)
            self._file_size = self._file.tell()

        # Seek to bjpeg start (may be embedded inside a BIMX container)
        self._file.seek(self._base_offset)

        # Read and decrypt 24-byte header
        raw_header = self._file.read(BJPEG_HEADER_SIZE)
        header = self._xor_decrypt_range(0, raw_header)

        magic = header[:4]
        if magic != BJPEG_MAGIC:
            self._file.close()
            raise RuntimeError(f"Invalid .bjpeg file: bad magic {magic!r}")

        version = struct.unpack_from("<H", header, 4)[0]
        if version != BJPEG_VERSION:
            self._file.close()
            raise RuntimeError(f"Unsupported .bjpeg version: {version}")

        self._frame_count: int = struct.unpack_from("<I", header, 6)[0]
        self._width: int = struct.unpack_from("<H", header, 10)[0]
        self._height: int = struct.unpack_from("<H", header, 12)[0]
        self._quality: int = header[14]
        # header[15] is reserved
        self._data_offset: int = struct.unpack_from("<Q", header, 16)[0]

        # Read and decrypt offset index (N * 8 bytes)
        index_size = self._frame_count * 8
        raw_index = self._file.read(index_size)
        index_data = self._xor_decrypt_range(BJPEG_HEADER_SIZE, raw_index)
        self._offsets = struct.unpack(f"<{self._frame_count}Q", index_data)

    def _xor_decrypt_range(self, file_offset: int, data: bytes) -> bytes:
        """XOR-decrypt data from a specific file offset, handling key cycling."""
        key_len = len(self._key)
        key_start = file_offset % key_len
        data_arr = np.frombuffer(data, dtype=np.uint8).copy()
        key_arr = np.frombuffer(self._key, dtype=np.uint8)
        indices = np.arange(key_start, key_start + len(data)) % key_len
        data_arr ^= key_arr[indices]
        return data_arr.tobytes()

    def get(self, index: int) -> np.ndarray:
        """Get a decoded BGR frame by index.

        Seeks to the frame's JPEG blob on disk, reads and decrypts it,
        then decodes via TurboJPEG.
        """
        if index < 0:
            index = self._frame_count + index
        if index < 0 or index >= self._frame_count:
            raise IndexError(
                f"Frame index {index} out of range [0, {self._frame_count})"
            )

        # Determine byte range for this frame's JPEG blob (bjpeg-relative offsets)
        start = self._offsets[index]
        end = self._offsets[index + 1] if index + 1 < self._frame_count else self._file_size

        blob_size = end - start

        # Thread-safe seek + read (add base_offset for embedded bjpeg)
        with self._lock:
            self._file.seek(self._base_offset + start)
            raw_blob = self._file.read(blob_size)

        # Decrypt using bjpeg-relative offset (XOR key cycling is bjpeg-relative)
        jpeg_data = self._xor_decrypt_range(start, raw_blob)

        from .compression import decode_jpeg

        return decode_jpeg(jpeg_data)

    def size(self) -> int:
        """Return total number of frames."""
        return self._frame_count

    @property
    def width(self) -> int:
        return self._width

    @property
    def height(self) -> int:
        return self._height

    def close(self) -> None:
        if self._file:
            self._file.close()
            self._file = None


def write_bjpeg(
    output_path: str,
    frames: List[np.ndarray],
    quality: int = 85,
    key: bytes = ENCRYPT_KEY,
    workers: int = 0,
) -> None:
    """Write a list of BGR frames to a .bjpeg indexed JPEG archive.

    JPEG encoding is parallelized across threads (TurboJPEG releases the GIL).
    File is written with streaming XOR encryption to avoid 3x memory overhead.

    Args:
        output_path: Destination .bjpeg file path.
        frames: List of BGR uint8 numpy arrays (all same dimensions).
        quality: JPEG compression quality (1-100).
        key: XOR encryption key.
        workers: Number of parallel JPEG encode threads (0 = auto).
    """
    from .compression import encode_jpeg

    if not frames:
        raise ValueError("No frames to write")

    height, width = frames[0].shape[:2]
    frame_count = len(frames)

    # Parallel JPEG encoding (TurboJPEG releases the GIL via ctypes)
    num_workers = workers if workers > 0 else min(os.cpu_count() or 4, 8)
    with ThreadPoolExecutor(max_workers=num_workers) as pool:
        jpeg_blobs = list(
            pool.map(lambda f: encode_jpeg(f, quality=quality), frames)
        )

    _write_bjpeg_from_blobs(output_path, jpeg_blobs, width, height, quality, key)


def _write_bjpeg_from_blobs(
    output_path: str,
    jpeg_blobs: List[bytes],
    width: int,
    height: int,
    quality: int = 85,
    key: bytes = ENCRYPT_KEY,
) -> None:
    """Write pre-encoded JPEG blobs to a .bjpeg archive with streaming XOR.

    Writes header, offset index, and JPEG data sequentially with position-aware
    XOR encryption, avoiding the need to build the entire file in memory.
    """
    frame_count = len(jpeg_blobs)

    # Compute offset index (absolute file offsets)
    data_offset = BJPEG_HEADER_SIZE + frame_count * 8
    offsets: List[int] = []
    current = data_offset
    for blob in jpeg_blobs:
        offsets.append(current)
        current += len(blob)

    # Build header
    header = struct.pack(
        "<4sHIHHBBQ",
        BJPEG_MAGIC,
        BJPEG_VERSION,
        frame_count,
        width,
        height,
        quality,
        0,  # reserved
        data_offset,
    )

    # Build index
    index_data = struct.pack(f"<{frame_count}Q", *offsets)

    # Stream-write with position-aware XOR (avoids 3x memory of full-file build)
    with open(output_path, "wb") as f:
        _write_xor_encrypted(f, 0, header, key)
        _write_xor_encrypted(f, BJPEG_HEADER_SIZE, index_data, key)
        pos = data_offset
        for blob in jpeg_blobs:
            _write_xor_encrypted(f, pos, blob, key)
            pos += len(blob)


def iter_video_frames(
    video_path: str,
    key: str = "",
    thread_count: int = 0,
    max_frames: int = -1,
) -> Iterator[np.ndarray]:
    """Yield decoded BGR24 frames one at a time from a video file.

    Unlike VideoReader (which decodes all frames into memory), this function
    yields frames sequentially and discards each one after yielding. Peak
    memory is ~1 frame instead of all frames.

    Args:
        video_path: Path to video file (.mp4 or .bhtensor).
        key: Decryption key for .bhtensor files. Empty string uses default.
        thread_count: Unused (kept for API symmetry with VideoReader).
        max_frames: Maximum number of frames to yield. -1 means all frames.

    Yields:
        BGR24 numpy arrays of shape (height, width, 3).
    """
    import av

    encrypted = is_encrypted_file(video_path)

    if encrypted:
        decrypt_key = key.encode("utf-8") if key else ENCRYPT_KEY
        decrypted = read_and_decrypt_file(video_path, decrypt_key)
        container = av.open(io.BytesIO(decrypted))
    else:
        container = av.open(video_path)

    try:
        stream = container.streams.video[0]
        stream.thread_type = "AUTO"
        container.seek(0)
        count = 0
        for frame in container.decode(video=0):
            if 0 <= max_frames <= count:
                break
            yield frame.to_ndarray(format="bgr24")
            count += 1
    finally:
        container.close()


# ---------------------------------------------------------------------------
# BIMX (.imx v2) binary container
# ---------------------------------------------------------------------------


def is_bimx_file(path: str) -> bool:
    """Check if a file is a BIMX binary container by reading magic bytes."""
    try:
        with open(path, "rb") as f:
            return f.read(4) == BIMX_MAGIC
    except (OSError, IOError):
        return False


def read_imx_file_table(path: str) -> List[tuple]:
    """Read the file table from a BIMX container (.imx v2).

    Returns:
        List of (name, data_offset, data_size) tuples.
    """
    with open(path, "rb") as f:
        header = f.read(8)
        if len(header) < 8:
            raise RuntimeError("File too small to be a BIMX container")
        magic = header[:4]
        if magic != BIMX_MAGIC:
            raise RuntimeError(f"Not a BIMX file: bad magic {magic!r}")
        version = struct.unpack_from("<H", header, 4)[0]
        if version != BIMX_VERSION:
            raise RuntimeError(f"Unsupported BIMX version: {version}")
        file_count = struct.unpack_from("<H", header, 6)[0]

        entries = []
        for _ in range(file_count):
            name_len = struct.unpack("<H", f.read(2))[0]
            name = f.read(name_len).decode("utf-8")
            data_offset, data_size = struct.unpack("<QQ", f.read(16))
            entries.append((name, data_offset, data_size))
        return entries


def write_imx_container(
    output_path: str,
    files: dict,
) -> None:
    """Write files into a BIMX binary container (.imx v2).

    Format:
        HEADER (8 bytes):
            magic(4) b"BIMX" + version(2) + file_count(2)
        FILE TABLE (variable):
            Per file: name_len(2) + name(var) + data_offset(8) + data_size(8)
        FILE DATA:
            Each file stored as-is at its declared offset.

    Args:
        output_path: Destination .imx file path.
        files: Ordered dict mapping filename (str) to file data (bytes).
    """
    file_count = len(files)

    # Build header (8 bytes)
    header = struct.pack("<4sHH", BIMX_MAGIC, BIMX_VERSION, file_count)

    # Compute file table size to determine data start offset
    file_entries = []
    for name, data in files.items():
        name_bytes = name.encode("utf-8")
        file_entries.append((name_bytes, data))

    table_size = sum(2 + len(nb) + 8 + 8 for nb, _ in file_entries)
    data_start = len(header) + table_size

    # Build file table and track data positions
    current_offset = data_start
    file_table = bytearray()
    data_items = []
    for name_bytes, data in file_entries:
        file_table.extend(struct.pack("<H", len(name_bytes)))
        file_table.extend(name_bytes)
        file_table.extend(struct.pack("<QQ", current_offset, len(data)))
        data_items.append(data)
        current_offset += len(data)

    # Write header + file table (cleartext) + file data (as-is)
    with open(output_path, "wb") as f:
        f.write(header)
        f.write(file_table)
        for data in data_items:
            f.write(data)


class BimxContainer:
    """Virtual filesystem over a BIMX binary container.

    Reads the file table on init (<1ms for typical containers) and provides
    random access to embedded files via seek+read without extraction.

    If the container includes a ``bimx_metadata.json`` file, it is eagerly
    loaded and exposed via the ``metadata`` property.
    """

    def __init__(self, path: str) -> None:
        self.path = path
        self._entries: Dict[str, Tuple[int, int]] = {}
        self._metadata: Optional[dict] = None

        with open(path, "rb") as f:
            header = f.read(8)
            if len(header) < 8:
                raise RuntimeError("File too small to be a BIMX container")
            magic = header[:4]
            if magic != BIMX_MAGIC:
                raise RuntimeError(f"Not a BIMX file: bad magic {magic!r}")
            version = struct.unpack_from("<H", header, 4)[0]
            if version != BIMX_VERSION:
                raise RuntimeError(f"Unsupported BIMX version: {version}")
            file_count = struct.unpack_from("<H", header, 6)[0]

            for _ in range(file_count):
                name_len = struct.unpack("<H", f.read(2))[0]
                name = f.read(name_len).decode("utf-8")
                data_offset, data_size = struct.unpack("<QQ", f.read(16))
                self._entries[name] = (data_offset, data_size)

        # Eagerly load metadata if present
        if "bimx_metadata.json" in self._entries:
            raw = self.read_file("bimx_metadata.json")
            self._metadata = json.loads(raw)

    def read_file(self, name: str) -> bytes:
        """Read an embedded file by name."""
        if name not in self._entries:
            raise KeyError(f"File not found in BIMX container: {name!r}")
        offset, size = self._entries[name]
        with open(self.path, "rb") as f:
            f.seek(offset)
            return f.read(size)

    def get_entry(self, name: str) -> Tuple[int, int]:
        """Return (offset, size) for an embedded file."""
        if name not in self._entries:
            raise KeyError(f"File not found in BIMX container: {name!r}")
        return self._entries[name]

    def has_file(self, name: str) -> bool:
        """Check if a file exists in the container."""
        return name in self._entries

    def list_files(self) -> List[str]:
        """Return all file names in the container."""
        return list(self._entries.keys())

    def find_files(self, pattern: str) -> List[str]:
        """Return file names matching a glob pattern."""
        return [n for n in self._entries if fnmatch.fnmatch(n, pattern)]

    @property
    def has_metadata(self) -> bool:
        """Whether the container includes bimx_metadata.json."""
        return self._metadata is not None

    @property
    def metadata(self) -> Optional[dict]:
        """Parsed bimx_metadata.json contents, or None."""
        return self._metadata
