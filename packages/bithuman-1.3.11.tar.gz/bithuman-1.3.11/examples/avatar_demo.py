"""
bitHuman Avatar Demo
====================
Converts an avatar model (.imx) + audio input into lip-synced video frames.

Usage:
    python avatar_demo.py --model avatar.imx --audio speech.wav --key YOUR_API_KEY
    python avatar_demo.py --model avatar.imx --audio speech.wav --key YOUR_API_KEY --save output.mp4
"""

import argparse
import asyncio
import sys
from pathlib import Path

# Add parent to path for local testing
sys.path.insert(0, str(Path(__file__).parent.parent))

# bitHuman imports
from bithuman import AsyncBithuman
from bithuman.audio import load_audio, float32_to_int16

# Optional: for visualization (pip install opencv-python)
try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

# Optional: for saving video (pip install opencv-python)
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False


async def main(model_path: str, audio_path: str, api_key: str, save_path: str = None):
    """
    Main function that demonstrates the bitHuman avatar pipeline:
    1. Load the avatar model
    2. Stream audio to the runtime
    3. Receive lip-synced video frames
    4. Optionally save to video file
    """

    # =========================================================================
    # STEP 1: Initialize the avatar runtime
    # =========================================================================
    # The runtime loads your .imx model file and prepares for animation.
    # You need an API key from bithuman.ai to authenticate.

    print(f"Loading model: {model_path}")
    runtime = await AsyncBithuman.create(
        model_path=model_path,
        api_secret=api_key,
        insecure=True,  # For local testing only
    )

    # Start the runtime (begins internal processing loop)
    await runtime.start()
    print(f"Model loaded! Frame size: {runtime.get_frame_size()}")

    # =========================================================================
    # STEP 2: Load and prepare audio
    # =========================================================================
    # Audio is converted to the format expected by the runtime:
    # - 16-bit signed integers (int16)
    # - Any sample rate (will be resampled internally if needed)

    print(f"Loading audio: {audio_path}")
    audio_float, sample_rate = load_audio(audio_path)  # Returns float32 array
    audio_int16 = float32_to_int16(audio_float)        # Convert to int16
    print(f"Audio loaded: {len(audio_int16)/sample_rate:.1f}s @ {sample_rate}Hz")

    # =========================================================================
    # STEP 3: Stream audio in the background
    # =========================================================================
    # Audio is pushed to the runtime in small chunks, simulating real-time
    # streaming (like from a TTS engine). The runtime processes audio and
    # generates lip-synced frames.

    async def stream_audio():
        """Push audio chunks to the runtime for lip-sync processing."""
        # Chunk size: ~40ms of audio (25 chunks per second matches video FPS)
        chunk_size = sample_rate // 25

        for i in range(0, len(audio_int16), chunk_size):
            chunk = audio_int16[i : i + chunk_size]
            # Push audio bytes to the runtime
            await runtime.push_audio(chunk.tobytes(), sample_rate)

        # Signal end of speech - avatar will return to idle state
        await runtime.flush()
        print("Audio streaming complete")

    # Start audio streaming as a background task
    audio_task = asyncio.create_task(stream_audio())

    # =========================================================================
    # STEP 4: Receive and process video frames
    # =========================================================================
    # The runtime yields VideoFrame objects containing:
    # - bgr_image: numpy array (H, W, 3) in BGR format for OpenCV
    # - audio_chunk: synchronized audio data (int16, 16kHz mono)
    #
    # You can display frames, encode them, stream via WebRTC, etc.

    # Setup video writer if saving
    video_writer = None
    if save_path and HAS_CV2:
        frame_size = runtime.get_frame_size()  # (width, height)
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        video_writer = cv2.VideoWriter(save_path, fourcc, 25, frame_size)
        print(f"Saving video to: {save_path}")

    frame_count = 0
    print("Receiving frames...")

    async for frame in runtime.run():
        # Skip frames without image data
        if frame.bgr_image is None:
            continue

        frame_count += 1

        # Option A: Save to video file
        if video_writer:
            video_writer.write(frame.bgr_image)

        # Option B: Display in window (requires display)
        elif HAS_CV2 and save_path is None:
            cv2.imshow("bitHuman Avatar", frame.bgr_image)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        # Option C: Do something else with the frame
        # - Stream via WebRTC (see livekit integration)
        # - Encode and send over websocket
        # - Process with your own pipeline
        else:
            if frame_count % 25 == 0:  # Print every second
                print(f"  Frame {frame_count}")

        # Stop after audio is done + buffer time
        if audio_task.done() and frame_count > 50:
            # Wait a bit for remaining frames
            await asyncio.sleep(0.5)
            break

    # =========================================================================
    # STEP 5: Cleanup
    # =========================================================================

    if video_writer:
        video_writer.release()
        print(f"Video saved: {save_path} ({frame_count} frames)")

    if HAS_CV2:
        cv2.destroyAllWindows()

    await runtime.stop()
    print(f"Done! Processed {frame_count} frames")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Convert avatar model + audio into lip-synced video"
    )
    parser.add_argument(
        "--model", required=True, help="Path to avatar model (.imx file)"
    )
    parser.add_argument(
        "--audio", required=True, help="Path to audio file (.wav, .mp3, etc.)"
    )
    parser.add_argument(
        "--key", required=True, help="bitHuman API key (from bithuman.ai)"
    )
    parser.add_argument(
        "--save", default=None, help="Save output to video file (e.g., output.mp4)"
    )

    args = parser.parse_args()
    asyncio.run(main(args.model, args.audio, args.key, args.save))
