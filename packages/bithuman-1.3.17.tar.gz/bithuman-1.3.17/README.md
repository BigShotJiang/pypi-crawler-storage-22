# bitHuman Avatar Runtime

![bitHuman Banner](https://docs.bithuman.ai/docs/assets/images/bithuman-banner.jpg)

**Real-time avatar engine for visual AI agents, digital humans, and creative characters.**

[![PyPI version](https://badge.fury.io/py/bithuman.svg)](https://pypi.org/project/bithuman/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)

bitHuman powers **visual AI agents** and **conversational AI** with photorealistic avatars and real-time lip-sync. Build voice agents with faces, video chatbots, AI assistants, and interactive digital humans — all running on edge devices with just 1-2 CPU cores and <200ms latency.

## Installation

```bash
pip install bithuman
```

## Quick Start

Save this as `avatar_demo.py` and run with:
```bash
python avatar_demo.py --model avatar.imx --audio speech.wav --key YOUR_API_KEY
python avatar_demo.py --model avatar.imx --audio speech.wav --key YOUR_API_KEY --save output.mp4
```

```python
"""
bitHuman Avatar Demo
====================
Converts an avatar model (.imx) + audio input into lip-synced video frames.

Usage:
    python avatar_demo.py --model avatar.imx --audio speech.wav --key YOUR_API_KEY
    python avatar_demo.py --model avatar.imx --audio speech.wav --key YOUR_API_KEY --save output.mp4
"""

import argparse
import asyncio

import numpy as np

# bitHuman imports
from bithuman import AsyncBithuman
from bithuman.audio import load_audio, float32_to_int16, write_video_with_audio

# Optional: for live display (pip install opencv-python)
try:
    import cv2

    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False


async def main(model_path: str, audio_path: str, api_key: str, save_path: str = None):
    """
    Main function that demonstrates the bitHuman avatar pipeline:
    1. Load the avatar model
    2. Stream audio to the runtime
    3. Receive lip-synced video frames
    4. Optionally save to video file with audio
    """

    # =========================================================================
    # STEP 1: Initialize the avatar runtime
    # =========================================================================
    # The runtime loads your .imx model file and prepares for animation.
    # You need an API key from bithuman.ai to authenticate.

    print(f"Loading model: {model_path}")
    runtime = await AsyncBithuman.create(
        model_path=model_path,
        api_secret=api_key,
    )

    # Start the runtime (begins internal processing loop)
    await runtime.start()
    print(f"Model loaded! Frame size: {runtime.get_frame_size()}")

    # =========================================================================
    # STEP 2: Load and prepare audio
    # =========================================================================
    # Audio is converted to the format expected by the runtime:
    # - 16-bit signed integers (int16)
    # - Any sample rate (will be resampled internally if needed)

    print(f"Loading audio: {audio_path}")
    audio_float, sample_rate = load_audio(audio_path)  # Returns float32 array
    audio_int16 = float32_to_int16(audio_float)  # Convert to int16
    print(f"Audio loaded: {len(audio_int16)/sample_rate:.1f}s @ {sample_rate}Hz")

    # =========================================================================
    # STEP 3: Stream audio in the background
    # =========================================================================
    # Audio is pushed to the runtime in small chunks, simulating real-time
    # streaming (like from a TTS engine). The runtime processes audio and
    # generates lip-synced frames.

    async def stream_audio():
        """Push audio chunks to the runtime for lip-sync processing."""
        # Chunk size: ~40ms of audio (25 chunks per second matches video FPS)
        chunk_size = sample_rate // 25

        for i in range(0, len(audio_int16), chunk_size):
            chunk = audio_int16[i : i + chunk_size]
            # Push audio bytes to the runtime
            await runtime.push_audio(chunk.tobytes(), sample_rate, last_chunk=False)

        # Signal end of speech - this causes runtime.run() to yield
        # a frame with end_of_speech=True so we know when to stop.
        await runtime.flush()
        print("Audio streaming complete")

    # Start audio streaming as a background task
    audio_task = asyncio.create_task(stream_audio())

    # =========================================================================
    # STEP 4: Receive and process video frames
    # =========================================================================
    # The runtime yields VideoFrame objects containing:
    # - bgr_image: numpy array (H, W, 3) in BGR format
    # - rgb_image: numpy array (H, W, 3) in RGB format
    # - audio_chunk: synchronized audio data (int16, 16kHz mono)
    # - end_of_speech: True when all audio has been processed
    #
    # You can display frames, encode them, stream via WebRTC, etc.

    frames = []
    audio_chunks = []
    frame_count = 0
    print("Receiving frames...")

    async for frame in runtime.run():
        # end_of_speech signals that all audio has been processed
        if frame.end_of_speech:
            break

        if frame.bgr_image is None:
            continue

        frame_count += 1

        # Collect frames and audio for saving (.copy() ensures data
        # survives if the runtime reuses internal frame buffers)
        if save_path:
            frames.append(frame.rgb_image.copy())
            if frame.audio_chunk is not None:
                audio_chunks.append(frame.audio_chunk.data.copy())

        # Live display (requires opencv-python and a display)
        elif HAS_CV2:
            cv2.imshow("bitHuman Avatar", frame.bgr_image)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        # Fallback: print progress
        else:
            if frame_count % 25 == 0:
                print(f"  Frame {frame_count} ({frame_count/25:.1f}s)")

    # =========================================================================
    # STEP 5: Save and cleanup
    # =========================================================================

    await audio_task

    if save_path and frames:
        # Combine audio chunks and convert to float32 for the writer
        audio_data = np.concatenate(audio_chunks).astype(np.float32) / 32767.0
        write_video_with_audio(save_path, frames, audio_data, 16000, fps=25)
        print(f"Video saved: {save_path} ({frame_count} frames, {frame_count/25:.1f}s)")

    if HAS_CV2 and not save_path:
        cv2.destroyAllWindows()

    await runtime.stop()
    print(f"Done! Processed {frame_count} frames ({frame_count/25:.1f}s)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Convert avatar model + audio into lip-synced video"
    )
    parser.add_argument(
        "--model", required=True, help="Path to avatar model (.imx file)"
    )
    parser.add_argument(
        "--audio", required=True, help="Path to audio file (.wav, .mp3, etc.)"
    )
    parser.add_argument(
        "--key", required=True, help="bitHuman API key (from bithuman.ai)"
    )
    parser.add_argument(
        "--save",
        default="output.mp4",
        help="Save output to video file (default: output.mp4)",
    )

    args = parser.parse_args()
    asyncio.run(main(args.model, args.audio, args.key, args.save))
```

## How It Works

1. **Load model** — `.imx` file contains the avatar's appearance and animations
2. **Push audio** — Stream audio bytes via `push_audio()`, call `flush()` when done
3. **Get frames** — Iterate `runtime.run()` to receive lip-synced video frames

## Performance

| Feature | Spec |
|---------|------|
| **CPU Usage** | 1-2 cores |
| **Memory** | 2GB RAM |
| **Latency** | <200ms end-to-end |
| **Throughput** | 100+ FPS on Intel i5-12400 / Apple M2 |

## Supported Platforms

| Platform | Architecture |
|----------|--------------|
| **Linux** | x86_64, ARM64 |
| **macOS** | Intel, Apple Silicon |
| **Windows** | x86_64 |
| **Edge Devices** | Raspberry Pi 4/5, Mac Mini, Chromebook |

## Use Cases

- **Visual AI Agents** — Give your voice agents a face with real-time lip-sync
- **Conversational AI** — Build video chatbots and AI assistants with human-like presence
- **Edge AI Deployment** — Run avatars locally on Raspberry Pi, Mac Mini, or any edge device
- **Live Streaming** — Integrate with LiveKit, WebRTC, or custom streaming pipelines
- **Digital Twins** — Create photorealistic replicas for customer service, education, or entertainment

## Integrations & Self-Hosting

Build visual AI agents with TTS, STT, and LLMs:

- **[LiveKit Integration](https://docs.bithuman.ai/#/examples/livekit-bithuman-plugin-self-hosted)** — Real-time video streaming for conversational AI
- **[Self-Hosting Guide](https://docs.bithuman.ai/#/)** — Deploy on your own edge infrastructure

## Getting a bitHuman Model

To generate your own avatar model (`.imx` file):

1. Visit [bithuman.ai](https://bithuman.ai)
2. Register and subscribe
3. Upload a photo or video to create your avatar
4. Download your `.imx` model file

## Learn More

- [Documentation](https://docs.bithuman.ai/#/)
- [bithuman.ai](https://bithuman.ai)

## License

Commercial license required. See [bithuman.ai/pricing](https://bithuman.ai/pricing).
