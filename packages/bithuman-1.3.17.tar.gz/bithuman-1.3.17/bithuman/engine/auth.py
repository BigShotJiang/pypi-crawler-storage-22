"""JWT validation, hardware fingerprinting, token refresh — replaces
jwt.cpp, fingerprint.cpp, token_request.cpp, hash.cpp.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import socket
import sys
import threading
import time
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Set

from loguru import logger

from . import RUNTIME_VERSION

# ---------------------------------------------------------------------------
# The JWT signing secret — matches getSecretKey() in generator.cpp.
# The C++ code uses compile-time XOR obfuscation, but the XOR+un-XOR
# in getSecretKey() is a round-trip that returns the original plaintext.
# ---------------------------------------------------------------------------
_SECRET_KEY = "myxVr8FBASSOyPet2Jf2VQBbe3Pbeliv"


# ---------------------------------------------------------------------------
# Hashing — replaces hash.cpp
# ---------------------------------------------------------------------------
def calculate_md5(data: str) -> str:
    """MD5 hex digest of a string. Matches hash.cpp calculateMD5."""
    return hashlib.md5(data.encode("utf-8")).hexdigest()


def calculate_sha256(data: str) -> str:
    """SHA-256 hex digest of a string. Matches hash.cpp calculateSHA256."""
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def calculate_file_md5(file_path: str) -> str:
    """MD5 hex digest of file contents. Matches hash.cpp calculateFileMD5."""
    md5 = hashlib.md5()
    try:
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                md5.update(chunk)
        return md5.hexdigest()
    except OSError:
        return ""


# ---------------------------------------------------------------------------
# Hardware fingerprint — replaces fingerprint.cpp
# ---------------------------------------------------------------------------
def generate_hardware_fingerprint() -> str:
    """Generate MD5 hash of machine-id + hostname + timestamp.

    Matches fingerprint.cpp generateHardwareFingerprint (lines 22-108):
    Linux: /etc/machine-id + "-" + hostname + "-" + YYYYMMDDHHMM → MD5
    macOS: hostname + "-" + platform UUID + "-" + YYYYMMDDHHMM → MD5
    Windows: computer name + "-" + volume serial + "-" + YYYYMMDDHHMM → MD5
    """
    parts: List[str] = []

    if sys.platform == "win32":
        parts.append(platform.node())
        # Volume serial approximation
        parts.append(str(uuid.getnode()))
    elif sys.platform == "darwin":
        parts.append(socket.gethostname())
        # macOS hardware UUID via ioreg
        try:
            import subprocess

            result = subprocess.run(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                capture_output=True,
                text=True,
            )
            for line in result.stdout.split("\n"):
                if "IOPlatformUUID" in line:
                    hw_uuid = line.split('"')[-2]
                    parts.append(hw_uuid)
                    break
        except Exception:
            pass
    else:
        # Linux
        try:
            with open("/etc/machine-id") as f:
                parts.append(f.read().strip())
        except FileNotFoundError:
            pass
        parts.append(socket.gethostname())

    # Add timestamp (YYYYMMDDHHMM) — matches C++ strftime "%Y%m%d%H%M"
    now = datetime.now()
    parts.append(now.strftime("%Y%m%d%H%M"))

    fingerprint = "-".join(parts)
    return calculate_md5(fingerprint)


# ---------------------------------------------------------------------------
# JWT Validator — replaces JWTValidator class in jwt.cpp
# ---------------------------------------------------------------------------
class JWTValidator:
    """Validates JWT tokens with HS256 signing.

    Matches jwt.cpp JWTValidator class: verifies signature, extracts claims
    (iss, sub, aud, exp, nbf, videos, models, instance_id, model_hash_type,
    ref.runtime_model_hash), manages allowed hash sets.
    """

    def __init__(self, secret_key: str = _SECRET_KEY) -> None:
        self._secret_key = secret_key
        self._is_valid = False
        self._expiration_time: Optional[float] = None  # Unix timestamp
        self._issuer = ""
        self._subject = ""
        self._audience = ""
        self._not_before: Optional[int] = None
        self._allowed_video_hashes: Set[str] = set()
        self._allowed_model_hashes: Set[str] = set()
        self._use_raw_model_hash = False
        self._instance_id = ""
        self._runtime_model_hash = ""

    def validate_token(self, token: str, verbose: bool = True) -> bool:
        """Validate JWT token. Matches jwt.cpp validateToken (lines 29-456).

        Uses PyJWT for HS256 verification with 300s leeway.
        """
        try:
            import jwt as pyjwt

            payload = pyjwt.decode(
                token,
                self._secret_key,
                algorithms=["HS256"],
                options={
                    "verify_exp": True,
                    "verify_aud": False,  # C++ jwt-cpp doesn't verify aud
                    "require": ["exp"],
                },
                leeway=300,  # 5 min clock skew — matches C++
            )

            # Extract standard claims
            self._issuer = payload.get("iss", "")
            self._subject = payload.get("sub", "")
            self._audience = payload.get("aud", "")
            self._not_before = payload.get("nbf")

            # Expiration
            exp = payload.get("exp")
            if exp is not None:
                self._expiration_time = float(exp)
                if time.time() > self._expiration_time:
                    if verbose:
                        logger.error("Token has expired!")
                    return False

            # Video hashes
            videos = payload.get("videos", [])
            if isinstance(videos, list):
                self._allowed_video_hashes = {h for h in videos if isinstance(h, str)}

            # Model hashes
            models = payload.get("models", [])
            if isinstance(models, list):
                self._allowed_model_hashes = {h for h in models if isinstance(h, str)}

            # Instance ID
            self._instance_id = payload.get("instance_id", "")

            # Model hash type
            hash_type = payload.get("model_hash_type", "")
            self._use_raw_model_hash = hash_type == "md5sum"

            # Runtime model hash from ref claim
            ref = payload.get("ref", {})
            if isinstance(ref, dict):
                self._runtime_model_hash = ref.get("runtime_model_hash", "")

            self._is_valid = True
            return True

        except Exception as e:
            if verbose:
                logger.error(f"Token validation failed: {e}")
            return False

    def is_validated(self) -> bool:
        return self._is_valid

    def has_expired(self) -> bool:
        """Check if token has expired. Matches jwt.cpp hasExpired."""
        if not self._is_valid:
            return True
        if self._expiration_time is None:
            return False
        return time.time() > self._expiration_time

    def get_expiration_time(self) -> Optional[float]:
        if not self._is_valid or self._expiration_time is None:
            return None
        return self._expiration_time

    def get_issuer(self) -> str:
        return self._issuer

    def get_audience(self) -> str:
        return self._audience

    def get_not_before(self) -> Optional[int]:
        return self._not_before

    def get_runtime_model_hash(self) -> str:
        return self._runtime_model_hash

    def is_video_hash_allowed(self, video_hash: str) -> bool:
        """Matches jwt.cpp isVideoHashAllowed (lines 458-470)."""
        if not self._is_valid:
            return False
        if not self._allowed_video_hashes:
            return True
        return video_hash in self._allowed_video_hashes

    def is_model_hash_allowed(
        self, raw_model_hash: str, encrypted_model_hash: str = ""
    ) -> bool:
        """Matches jwt.cpp isModelHashAllowed (lines 472-498)."""
        if not self._is_valid:
            return False
        if not self._allowed_model_hashes:
            return True
        if self._use_raw_model_hash:
            return raw_model_hash in self._allowed_model_hashes
        hash_to_check = (
            encrypted_model_hash if encrypted_model_hash else self.encrypt_model_hash(raw_model_hash)
        )
        return hash_to_check in self._allowed_model_hashes

    def encrypt_model_hash(self, model_hash: str) -> str:
        """Matches jwt.cpp encryptModelHash (lines 500-510):
        SHA256(model_hash + SHA256(secret_key))
        """
        secret_hash = calculate_sha256(self._secret_key)
        combined = model_hash + secret_hash
        return calculate_sha256(combined)


# ---------------------------------------------------------------------------
# Token request — replaces token_request.cpp
# ---------------------------------------------------------------------------
def request_token(
    api_url: str,
    api_secret: str,
    fingerprint: str,
    runtime_model_hash: Optional[str] = None,
    tags: Optional[str] = None,
    transaction_id: Optional[str] = None,
    insecure: bool = False,
    timeout: float = 30.0,
) -> str:
    """HTTP POST to auth API, returns JWT token string.

    Matches token_request.cpp requestToken (lines 26-134):
    POST with JSON body and api-secret header.
    """
    import requests

    body: Dict[str, str] = {
        "fingerprint": fingerprint,
        "runtime_version": RUNTIME_VERSION,
    }
    if runtime_model_hash:
        body["runtime_model_hash"] = runtime_model_hash
    if tags:
        body["tags"] = tags
    if transaction_id:
        body["transaction_id"] = transaction_id

    headers = {
        "Content-Type": "application/json",
        "api-secret": api_secret,
    }

    resp = requests.post(
        api_url,
        json=body,
        headers=headers,
        timeout=timeout,
        verify=not insecure,
    )

    if resp.status_code == 200:
        data = resp.json()
        # API wraps response in {"data": {"token": ...}, "status": ...}
        token = data.get("token", "") or data.get("data", {}).get("token", "")
        if not token:
            raise RuntimeError("Failed to parse token from response")
        return token
    elif resp.status_code == 402:
        raise RuntimeError(
            "Payment Required (402): Your quota has been exceeded or "
            "payment is required. Runtime terminated."
        )
    elif resp.status_code == 403:
        raise RuntimeError("Forbidden (403): Access denied. Runtime terminated.")
    elif resp.status_code == 400:
        try:
            error_detail = resp.json()
        except Exception:
            error_detail = resp.text
        raise RuntimeError(
            f"Bad Request (400): {error_detail}. Runtime terminated."
        )
    else:
        raise RuntimeError(
            f"Token request failed with status code: {resp.status_code}"
        )


# ---------------------------------------------------------------------------
# UUID generation — replaces jwt.cpp generateUUID
# ---------------------------------------------------------------------------
def generate_uuid() -> str:
    """Generate a UUID4 string. Matches jwt.cpp generateUUID."""
    return str(uuid.uuid4())
