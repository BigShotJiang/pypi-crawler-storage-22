# Multithreaded Video Decoding in Bithuman Runtime

This document explains how to use the `thread_count` parameter to control multithreaded video decoding performance.

## Overview

The Bithuman runtime now supports multithreaded video decoding to improve performance on multi-core systems. You can control the threading behavior when adding videos to the runtime.

## Usage

### Basic Syntax

```python
from bithuman.lib.generator import BithumanRuntime
from bithuman import CompressionType, LoadingMode

runtime = BithumanRuntime()

runtime.add_video(
    video_name="my_video",
    video_path="video.mp4",
    video_data_path="video_data.h5",
    avatar_data_path="avatar_data.bhtensor",
    compression_type=CompressionType.JPEG,
    loading_mode=LoadingMode.ASYNC,
    thread_count=0  # Threading control parameter
)
```

### Thread Count Options

| Value | Behavior | Use Case |
|-------|----------|----------|
| `0` (default) | Single-threaded | Safe default, minimal memory usage |
| `1` | Explicitly single-threaded | Same as 0, but explicit |
| `2`, `4`, `8`, etc. | Use N threads | Fine-tuned control for specific hardware |
| `-1` | Auto-detect optimal | Best performance, recommended for production |

### Examples

#### Single-threaded (Default)
```python
runtime.add_video(
    video_name="video1",
    video_path="path/to/video.mp4",
    video_data_path="path/to/data.h5",
    avatar_data_path="path/to/avatar.bhtensor"
    # thread_count=0 is the default
)
```

#### Multi-threaded with 4 cores
```python
runtime.add_video(
    video_name="video2",
    video_path="path/to/video.mp4",
    video_data_path="path/to/data.h5",
    avatar_data_path="path/to/avatar.bhtensor",
    thread_count=4  # Use 4 CPU threads
)
```

#### Auto-detect optimal thread count
```python
runtime.add_video(
    video_name="video3",
    video_path="path/to/video.mp4",
    video_data_path="path/to/data.h5",
    avatar_data_path="path/to/avatar.bhtensor",
    thread_count=-1  # Auto-detect best thread count
)
```

## Performance Considerations

### When to Use Single-threaded (thread_count=0)
- **Testing and development**: Predictable, reproducible behavior
- **Limited memory systems**: Lower memory usage
- **Simple videos**: For low-resolution or short videos
- **Compatibility**: When you need consistent behavior across systems

### When to Use Multi-threaded (thread_count>0)
- **High-resolution videos**: 1080p, 4K videos benefit significantly
- **Batch processing**: Processing multiple videos
- **Performance-critical applications**: When speed is important
- **Multi-core systems**: Systems with 4+ CPU cores

### When to Use Auto-detect (thread_count=-1)
- **Production deployments**: Best performance on any hardware
- **Unknown target hardware**: When you don't know the deployment environment
- **Maximum performance**: When you want the best possible speed

## Memory Usage

Threading affects memory usage:

- **Single-threaded**: Baseline memory usage
- **Multi-threaded**: 2-8x baseline memory usage
- **Auto-detect**: Automatically balances performance vs memory

## Performance Benchmarking

You can benchmark different thread counts:

```python
import time

def benchmark_video_loading(thread_count, description):
    start_time = time.time()

    runtime.add_video(
        video_name=f"test_{thread_count}",
        video_path="path/to/video.mp4",
        video_data_path="path/to/data.h5",
        avatar_data_path="path/to/avatar.bhtensor",
        thread_count=thread_count
    )

    end_time = time.time()
    print(f"{description}: {end_time - start_time:.2f} seconds")

# Benchmark different configurations
benchmark_video_loading(0, "Single-threaded")
benchmark_video_loading(4, "4-threaded")
benchmark_video_loading(-1, "Auto-threaded")
```

## Best Practices

1. **Start with auto-detect** (`thread_count=-1`) for best performance
2. **Use single-threaded** (`thread_count=0`) for development and testing
3. **Profile your specific use case** to find optimal settings
4. **Monitor memory usage** when using multi-threading
5. **Consider your target hardware** when choosing thread counts

## Troubleshooting

### No Performance Improvement
- Check if your videos support multi-threaded decoding (H.264/H.265 work best)
- Ensure you have multiple CPU cores available
- Try different thread counts to find the optimal value

### High Memory Usage
- Reduce thread count
- Use single-threaded mode for memory-constrained environments
- Process videos sequentially instead of in parallel

### Inconsistent Results
- Use single-threaded mode for reproducible results
- Multi-threading can introduce slight timing variations

## Example Script

See `threading_example.py` for a complete working example demonstrating all threading options.

## Technical Details

The `thread_count` parameter controls FFmpeg's multithreaded video decoder:
- Frame-level parallelism for complex video streams
- Slice-level parallelism for simpler streams
- Automatic optimization for H.264 and H.265 codecs
- Memory pooling for efficient buffer management

For more technical details, see the C++ documentation in the source code.
