from setuptools import find_packages, setup

setup(
    name="bithuman",
    python_requires=">=3.9",
    platforms=["Linux", "Mac OS X", "Windows"],
    packages=find_packages(),
    include_package_data=True,
    # Exclude large data files - controlled by MANIFEST.in
)
