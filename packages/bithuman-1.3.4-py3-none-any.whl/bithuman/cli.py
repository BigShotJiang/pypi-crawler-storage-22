"""bithuman CLI — model conversion and utilities.

Usage:
    python -m bithuman convert <model.imx> [--quality 85] [--output new_model.imx]
    python -m bithuman validate <path> [--workers 4]
    bithuman convert <model.imx> [--quality 85] [--output new_model.imx]
    bithuman validate <path> [--workers 4]
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import sys
import tarfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tempfile import TemporaryDirectory


def _find_files_case_insensitive(workspace: Path, name: str, extension: str) -> list[Path]:
    """Find files matching name prefix with given extension, case-insensitively.

    This handles the case where videos.yaml has 'name: talking' but the actual
    file is 'Talking.mp4.WAV2LIP_1280_1eec9bf5.h5'.
    """
    name_lower = name.lower()
    matches = []
    for f in workspace.rglob(f"*{extension}"):
        fname_lower = f.name.lower()
        if fname_lower.startswith(name_lower):
            matches.append(f)
    return matches


def _find_avatar_bhtensor_files(workspace_dir: str) -> list[Path]:
    """Find .bhtensor files that are avatar lip-sync data (not main videos)."""
    workspace = Path(workspace_dir)
    avatar_files = []
    for pattern in ["*.feature-first.bhtensor", "*.time-first.bhtensor"]:
        avatar_files.extend(workspace.rglob(pattern))
    return sorted(avatar_files)


def _convert_bhtensor_to_bjpeg_standalone(
    bhtensor_path: str,
    quality: int = 85,
) -> str:
    """Convert a single .bhtensor to .bjpeg without importing torch/encrypt.py.

    Uses only bithuman.engine.video_reader and bithuman.engine.compression.
    Returns the path to the created .bjpeg file.
    """
    import av
    import numpy as np

    from bithuman.engine.compression import encode_jpeg
    from bithuman.engine.video_reader import (
        ENCRYPT_KEY,
        _write_bjpeg_from_blobs,
        read_and_decrypt_file,
    )

    input_path = Path(bhtensor_path)
    name = input_path.name
    if name.endswith(".bhtensor"):
        output_file = str(input_path.parent / (name[: -len(".bhtensor")] + ".bjpeg"))
    else:
        output_file = str(input_path.with_suffix(".bjpeg"))

    # Decrypt
    print(f"  Decrypting {input_path.name}...")
    decrypted = read_and_decrypt_file(bhtensor_path, ENCRYPT_KEY)

    # Decode H.264 + parallel JPEG encode
    print(f"  Decoding H.264 + parallel JPEG encoding...")
    container = av.open(io.BytesIO(decrypted))
    stream = container.streams.video[0]
    stream.thread_type = "AUTO"
    container.seek(0)

    num_workers = min(os.cpu_count() or 4, 8)
    width, height = None, None
    futures = []
    with ThreadPoolExecutor(max_workers=num_workers) as pool:
        for frame in container.decode(video=0):
            bgr = frame.to_ndarray(format="bgr24")
            if width is None:
                height, width = bgr.shape[:2]
            futures.append(pool.submit(encode_jpeg, bgr, quality))
        jpeg_blobs = [f.result() for f in futures]

    container.close()
    del decrypted

    print(f"  {len(jpeg_blobs)} frames ({width}x{height})")
    print(f"  Writing .bjpeg...")

    _write_bjpeg_from_blobs(output_file, jpeg_blobs, width, height, quality, ENCRYPT_KEY)

    in_size = input_path.stat().st_size / 1024 / 1024
    out_size = Path(output_file).stat().st_size / 1024 / 1024
    print(f"  {input_path.name} ({in_size:.1f} MB) -> {Path(output_file).name} ({out_size:.1f} MB)")

    return output_file


def _convert_video_to_bjpeg(
    video_path: str,
    h5_path: str,
    quality: int = 85,
) -> str:
    """Convert an .mp4 video to .bjpeg, resized to HDF5 frame_wh.

    Returns the path to the created .bjpeg file.
    """
    import av
    import h5py
    import numpy as np

    from bithuman.engine.compression import encode_jpeg
    from bithuman.engine.video_reader import ENCRYPT_KEY, _write_bjpeg_from_blobs

    input_path = Path(video_path)
    output_file = str(input_path.parent / (input_path.stem + ".bjpeg"))

    # Read target resolution from HDF5
    with h5py.File(h5_path, "r") as f:
        wh = f.attrs["frame_wh"]
        target_w, target_h = int(wh[0]), int(wh[1])

    # Decode .mp4 + parallel JPEG encode at target resolution
    print(f"  Decoding {input_path.name} → resize to {target_w}x{target_h}...")
    container = av.open(str(video_path))
    stream = container.streams.video[0]
    stream.thread_type = "AUTO"
    container.seek(0)

    import cv2

    num_workers = min(os.cpu_count() or 4, 8)
    futures = []
    with ThreadPoolExecutor(max_workers=num_workers) as pool:
        for frame in container.decode(video=0):
            bgr = frame.to_ndarray(format="bgr24")
            if bgr.shape[1] != target_w or bgr.shape[0] != target_h:
                bgr = cv2.resize(bgr, (target_w, target_h))
            futures.append(pool.submit(encode_jpeg, bgr, quality))
        jpeg_blobs = [f.result() for f in futures]

    container.close()

    print(f"  {len(jpeg_blobs)} frames ({target_w}x{target_h})")
    print(f"  Writing {Path(output_file).name}...")

    _write_bjpeg_from_blobs(output_file, jpeg_blobs, target_w, target_h, quality, ENCRYPT_KEY)

    out_size = Path(output_file).stat().st_size / 1024 / 1024
    print(f"  {input_path.name} → {Path(output_file).name} ({out_size:.1f} MB)")

    return output_file


def _generate_bimx_metadata(
    workspace: Path,
    model_hash: str,
) -> dict:
    """Generate bimx_metadata.json content for the workspace.

    Scans the workspace for videos (from videos.yaml), computes per-video
    metadata, and returns the metadata dict.
    """
    import h5py
    import yaml

    videos_yaml = workspace / "videos.yaml"
    if not videos_yaml.exists():
        # Auto-generate videos.yaml from video files found in the workspace
        print(f"  videos.yaml not found, auto-generating from video files...")
        mp4_files = list(workspace.rglob("videos/*.mp4"))
        if not mp4_files:
            raise FileNotFoundError(f"videos.yaml not found and no video files in {workspace}")

        videos_config = {"videos": []}
        for mp4 in mp4_files:
            name = mp4.stem
            rel_path = str(mp4.relative_to(workspace))
            videos_config["videos"].append({
                "name": name,
                "single_direction": True,
                "video_file": rel_path,
                "video_type": "LoopingVideo",
            })

        with open(videos_yaml, "w") as f:
            yaml.dump(videos_config, f, default_flow_style=False)
        print(f"  Generated videos.yaml with {len(mp4_files)} video(s)")

    with open(videos_yaml) as f:
        config = yaml.safe_load(f)

    metadata = {
        "version": 1,
        "model_hash": model_hash,
        "videos": {},
    }

    for vc in config.get("videos", []):
        name = vc["name"]
        video_file = vc.get("video_file", "")

        # Find the .mp4 file
        mp4_path = workspace / video_file
        if not mp4_path.exists():
            # Try searching (case-insensitive to handle name casing mismatches)
            mp4_candidates = _find_files_case_insensitive(workspace, name, ".mp4")
            mp4_path = mp4_candidates[0] if mp4_candidates else None

        # Get the actual video filename stem for h5/bjpeg search
        # h5 files are named like "Talking.mp4.WAV2LIP_1280_xxx.h5" (after the video file)
        video_stem = Path(video_file).stem if video_file else name

        # Find the .h5 file (case-insensitive, using video filename not config name)
        h5_candidates = _find_files_case_insensitive(workspace, video_stem, ".h5")
        h5_path = h5_candidates[0] if h5_candidates else None

        # Find avatar .bjpeg (case-insensitive, using video filename)
        avatar_candidates = _find_files_case_insensitive(workspace, video_stem, ".bjpeg")
        # Exclude original video bjpeg (ones in videos/ dir)
        avatar_bjpeg = None
        original_bjpeg = None
        for c in avatar_candidates:
            rel = str(c.relative_to(workspace))
            if "avatar_models" in rel or "feature-first" in rel or "time-first" in rel:
                avatar_bjpeg = c
            elif "videos" in rel or c.stem.lower() == video_stem.lower():
                original_bjpeg = c

        # Compute video hash from .mp4
        video_hash = ""
        frame_count = 0
        resolution = [0, 0]

        if mp4_path and mp4_path.exists():
            with open(mp4_path, "rb") as f:
                video_hash = hashlib.md5(f.read()).hexdigest()

            # Always get frame_count and resolution from video file (OpenCV)
            import cv2
            cap = cv2.VideoCapture(str(mp4_path))
            try:
                frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                resolution = [
                    int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
                    int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
                ]
            finally:
                cap.release()

        # If h5 file exists, prefer its resolution (more accurate for lip-sync)
        if h5_path and h5_path.exists():
            with h5py.File(str(h5_path), "r") as f:
                wh = f.attrs["frame_wh"]
                resolution = [int(wh[0]), int(wh[1])]
                # Use h5 frame count if available (more accurate for lip-sync videos)
                h5_frames = len(f["face_coords"])
                if h5_frames > 0:
                    frame_count = h5_frames

        vmeta = {
            "hash": video_hash,
            "frame_count": frame_count,
            "resolution": resolution,
        }
        if h5_path:
            vmeta["h5_file"] = str(h5_path.relative_to(workspace))
        if avatar_bjpeg:
            vmeta["avatar_bjpeg_file"] = str(avatar_bjpeg.relative_to(workspace))
        if original_bjpeg:
            vmeta["original_bjpeg_file"] = str(original_bjpeg.relative_to(workspace))

        metadata["videos"][name] = vmeta

    return metadata


def cmd_convert(args: argparse.Namespace) -> int:
    """Convert old .imx (tar) model to new BIMX format with near-instant loading."""
    from bithuman.engine.video_reader import BimxContainer, is_bimx_file, write_imx_container

    imx_path = Path(args.imx_path)
    if not imx_path.exists():
        print(f"ERROR: File not found: {imx_path}")
        return 1

    # Already fully converted?
    if is_bimx_file(str(imx_path)):
        container = BimxContainer(str(imx_path))
        if container.has_metadata:
            print(f"Already converted: {imx_path}")
            return 0
        print(f"ERROR: BIMX container without metadata is not supported: {imx_path}")
        print("Please re-convert from the original tar .imx file.")
        return 1

    output_path = Path(args.output) if args.output else imx_path
    quality = args.quality
    overwriting = output_path.resolve() == imx_path.resolve()

    # Compute model hash from original file BEFORE conversion
    print("Computing model hash...")
    with open(imx_path, "rb") as f:
        h = hashlib.md5()
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
        model_hash = h.hexdigest()
    print(f"  Model hash: {model_hash}")

    imx_size = imx_path.stat().st_size / 1024 / 1024
    print(f"Input:   {imx_path} ({imx_size:.1f} MB)")
    print(f"Output:  {output_path}")
    if overwriting:
        print(f"WARNING: This will overwrite the original file!")
    print(f"Quality: {quality}")
    print()

    if overwriting and sys.stdin.isatty():
        answer = input("Overwrite the original .imx file? [y/N] ").strip().lower()
        if answer not in ("y", "yes"):
            print("Aborted.")
            return 1

    # Extract tar archive to temp directory
    temp_dir = TemporaryDirectory()
    print("Extracting .imx archive...")
    mode = "r:gz" if imx_path.name.endswith("gz") else "r"
    with tarfile.open(imx_path, mode) as tar:
        tar.extractall(temp_dir.name)

    # Find the workspace root (enter single directory if present)
    workspace = Path(temp_dir.name)
    contents = list(workspace.iterdir())
    if len(contents) == 1 and contents[0].is_dir():
        workspace = contents[0]

    print(f"  Extracted to: {workspace}")

    # Convert avatar .bhtensor files to .bjpeg (if any)
    avatar_files = _find_avatar_bhtensor_files(str(workspace))
    if avatar_files:
        print(f"\nFound {len(avatar_files)} avatar .bhtensor file(s) to convert:")
        for f in avatar_files:
            sz = f.stat().st_size / 1024 / 1024
            print(f"  {f.relative_to(workspace)} ({sz:.1f} MB)")

        print()
        for bhtensor_file in avatar_files:
            print(f"Converting {bhtensor_file.name}...")
            _convert_bhtensor_to_bjpeg_standalone(str(bhtensor_file), quality=quality)
            bhtensor_file.unlink()
            print(f"  Removed {bhtensor_file.name}")

    # Convert .mp4 video files to .bjpeg (resized to HDF5 frame_wh)
    mp4_files = sorted(workspace.rglob("videos/*.mp4"))
    converted_mp4s = set()
    if mp4_files:
        print(f"\nFound {len(mp4_files)} video .mp4 file(s) to convert:")
        for f in mp4_files:
            sz = f.stat().st_size / 1024 / 1024
            print(f"  {f.relative_to(workspace)} ({sz:.1f} MB)")

            # Find matching .h5 file
            h5_candidates = list(f.parent.glob(f"{f.name}*.h5"))
            if h5_candidates:
                print(f"\nConverting {f.name} to .bjpeg...")
                _convert_video_to_bjpeg(str(f), str(h5_candidates[0]), quality=quality)
                converted_mp4s.add(str(f.relative_to(workspace)))
            else:
                print(f"  WARNING: No .h5 file found for {f.name}, skipping .bjpeg conversion")

    # Generate metadata
    print(f"\nGenerating bimx_metadata.json...")
    metadata = _generate_bimx_metadata(workspace, model_hash)
    metadata_json = json.dumps(metadata, indent=2).encode("utf-8")
    metadata_path = workspace / "bimx_metadata.json"
    with open(metadata_path, "wb") as f:
        f.write(metadata_json)
    print(f"  {json.dumps(metadata, indent=2)}")

    # Collect all files for the new BIMX container
    # Skip .mp4 files that have .bjpeg counterparts, skip .bhtensor
    print(f"\nPacking new .imx binary container...")
    files = {}
    for item in sorted(workspace.rglob("*")):
        if item.is_file():
            rel_path = str(item.relative_to(workspace))
            # Skip .mp4 files that were converted to .bjpeg
            if rel_path in converted_mp4s:
                print(f"  Skipping {rel_path} (replaced by .bjpeg)")
                continue
            # Skip .bhtensor files (shouldn't exist after conversion, but safety check)
            if rel_path.endswith(".bhtensor"):
                continue
            with open(item, "rb") as f:
                files[rel_path] = f.read()

    # Write to temp file first, then move to output
    tmp_output = str(output_path) + ".tmp"
    write_imx_container(tmp_output, files)
    os.replace(tmp_output, str(output_path))

    out_size = output_path.stat().st_size / 1024 / 1024
    print(f"\nDone: {output_path} ({out_size:.1f} MB)")
    print(f"Size: {imx_size:.1f} MB -> {out_size:.1f} MB ({out_size / imx_size:.1%})")

    temp_dir.cleanup()
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    """Validate BIMX model(s) by testing if they load correctly."""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    from bithuman.engine.video_reader import is_bimx_file
    from bithuman.video_graph.navigator import VideoGraphNavigator

    path = Path(args.path)

    def validate_single(model_path: Path) -> tuple[str, bool, str]:
        """Validate a single model. Returns (name, success, error)."""
        try:
            if not model_path.exists():
                return model_path.name, False, "File not found"

            if not is_bimx_file(str(model_path)):
                return model_path.name, False, "Not a BIMX file"

            # Try to load the model
            VideoGraphNavigator.from_workspace(str(model_path))
            return model_path.name, True, ""
        except Exception as e:
            return model_path.name, False, str(e)[:100]

    # Collect models to validate
    models: list[Path] = []
    if path.is_file():
        models = [path]
    elif path.is_dir():
        # Check if it's a single agent dir or a parent directory
        model_file = path / "model.imx"
        if model_file.exists():
            models = [model_file]
        else:
            # Scan for all model.imx files
            for agent_dir in path.iterdir():
                if agent_dir.is_dir():
                    m = agent_dir / "model.imx"
                    if m.exists():
                        models.append(m)
            models = sorted(models)
    else:
        print(f"ERROR: Path not found: {path}")
        return 1

    if not models:
        print(f"No models found at: {path}")
        return 1

    # Validate
    workers = min(args.workers, len(models))
    print(f"Validating {len(models)} model(s) with {workers} workers...")

    valid = 0
    invalid = 0
    errors: list[tuple[str, str]] = []

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(validate_single, m): m for m in models}
        for i, future in enumerate(as_completed(futures), 1):
            name, success, error = future.result()
            if success:
                valid += 1
            else:
                invalid += 1
                errors.append((name, error))

            if len(models) > 10 and i % 100 == 0:
                print(f"  [{i:,}/{len(models):,}] valid: {valid}, invalid: {invalid}")

    # Summary
    print(f"\nValidation Results:")
    print(f"  Total:   {len(models)}")
    print(f"  Valid:   {valid}")
    print(f"  Invalid: {invalid}")

    if errors:
        print(f"\nInvalid models ({len(errors)}):")
        # Group by error type
        error_groups: dict[str, list[str]] = {}
        for name, err in errors:
            key = err[:50] if err else "Unknown error"
            error_groups.setdefault(key, []).append(name)

        for err, names in sorted(error_groups.items(), key=lambda x: -len(x[1]))[:10]:
            print(f"  [{len(names)}x] {err}")
            if len(names) <= 3:
                for n in names:
                    print(f"       - {n}")

    return 0 if invalid == 0 else 1


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="bithuman",
        description="bithuman CLI — model conversion and utilities",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # convert subcommand
    convert_parser = subparsers.add_parser(
        "convert",
        help="Convert old .imx model to new format for 10x faster loading",
    )
    convert_parser.add_argument("imx_path", help="Path to .imx model file")
    convert_parser.add_argument(
        "--output",
        "-o",
        help="Output .imx path (default: overwrite original)",
    )
    convert_parser.add_argument(
        "--quality",
        "-q",
        type=int,
        default=85,
        help="JPEG compression quality 1-100 (default: 85)",
    )

    # validate subcommand
    validate_parser = subparsers.add_parser(
        "validate",
        help="Validate BIMX model(s) by testing if they load correctly",
    )
    validate_parser.add_argument(
        "path",
        help="Path to .imx file, agent directory, or parent directory containing agents",
    )
    validate_parser.add_argument(
        "--workers",
        "-w",
        type=int,
        default=4,
        help="Number of parallel workers (default: 4)",
    )

    args = parser.parse_args()

    if args.command == "convert":
        return cmd_convert(args)
    elif args.command == "validate":
        return cmd_validate(args)
    else:
        parser.print_help()
        return 1
