from __future__ import annotations

import tarfile
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Optional, Union

from ..engine.video_reader import BimxContainer

# BIMX magic bytes for format detection
_BIMX_MAGIC = b"BIMX"


def _extract_bimx(imx_path: str, extract_dir: str) -> None:
    """Extract all files from a BIMX container to a directory."""
    container = BimxContainer(imx_path)
    for name in container.list_files():
        dest = Path(extract_dir) / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(container.read_file(name))


def unzip_tarfile(
    file_path: str, extract_to_local: bool = False
) -> tuple[Union[str, BimxContainer], Optional[TemporaryDirectory], bool]:
    """Open a model file or directory.

    Supported formats:
      - BIMX binary container with ``bimx_metadata.json`` — returns a
        ``BimxContainer`` directly (no extraction, near-instant).
      - Legacy TAR archive (``.imx`` v1) — extracts to a temp directory.
      - Plain directory — passed through as-is.

    Returns:
        Tuple of (workspace_path_or_container, temp_dir_handle, is_legacy_format).
    """
    file_path: Path = Path(file_path)
    if file_path.is_dir():
        return str(file_path), None, False

    # Detect format by reading magic bytes
    with open(file_path, "rb") as f:
        magic = f.read(4)

    if magic == _BIMX_MAGIC:
        container = BimxContainer(str(file_path))
        if container.has_metadata:
            return container, None, False
        # BIMX without metadata is not supported at runtime.
        raise RuntimeError(
            f"BIMX container missing bimx_metadata.json: {file_path}\n"
            "Re-convert the model to add metadata:\n"
            f"  python -m bithuman convert {file_path}"
        )

    # Legacy TAR archive
    if not extract_to_local:
        temp_dir_handle = TemporaryDirectory()
        dest_dir = temp_dir_handle.name
    else:
        temp_dir_handle = None
        dest_dir = str(file_path.parent / file_path.stem)
        if dest_dir.endswith(".tar"):
            dest_dir = dest_dir[:-4]

    if temp_dir_handle is not None or not Path(dest_dir).exists():
        Path(dest_dir).mkdir(parents=True, exist_ok=True)
        mode = "r:gz" if file_path.name.endswith("gz") else "r"
        with tarfile.open(file_path, mode) as tar:
            tar.extractall(dest_dir)

    # Enter the dir if there is only one directory in the archive
    files = list(Path(dest_dir).iterdir())
    if len(files) == 1 and files[0].is_dir():
        dest_dir = str(files[0])
    return dest_dir, temp_dir_handle, True
