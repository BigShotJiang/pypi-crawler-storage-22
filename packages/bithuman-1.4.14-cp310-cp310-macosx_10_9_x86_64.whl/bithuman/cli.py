"""bithuman CLI — avatar engine, video generation, and live streaming.

Usage:
    bithuman generate <model.imx> --audio <speech.wav> --key YOUR_API_KEY
    bithuman stream <model.imx> --key YOUR_API_KEY
    bithuman speak <audio.wav>
    bithuman action <name>
    bithuman info <model.imx>
    bithuman list-videos <model.imx>
    bithuman convert <model.imx> [--quality 80] [--output new_model.imx]
    bithuman validate <path> [--workers 4]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tarfile
from datetime import datetime, timezone
from pathlib import Path
from tempfile import TemporaryDirectory


def _find_files_case_insensitive(workspace: Path, name: str, extension: str) -> list[Path]:
    """Find files matching name prefix with given extension, case-insensitively.

    This handles the case where videos.yaml has 'name: talking' but the actual
    file is 'Talking.mp4.WAV2LIP_1280_1eec9bf5.h5'.
    """
    name_lower = name.lower()
    matches = []
    for f in workspace.rglob(f"*{extension}"):
        fname_lower = f.name.lower()
        if fname_lower.startswith(name_lower):
            matches.append(f)
    return matches


def _find_avatar_bhtensor_files(workspace_dir: str) -> list[Path]:
    """Find .bhtensor files that are avatar lip-sync data (not main videos)."""
    workspace = Path(workspace_dir)
    avatar_files = []
    for pattern in ["*.feature-first.bhtensor", "*.time-first.bhtensor"]:
        avatar_files.extend(workspace.rglob(pattern))
    return sorted(avatar_files)


def _downscale_video(mp4_path: str, max_dim: int = 1280) -> bool:
    """Downscale MP4 in-place if any dimension exceeds max_dim.

    Uses H.264 CRF 18 (visually lossless) to preserve quality.
    Returns True if the video was transcoded.
    """
    import av

    container = av.open(mp4_path)
    stream = container.streams.video[0]
    w, h = stream.codec_context.width, stream.codec_context.height
    fps = stream.average_rate
    container.close()

    if w <= max_dim and h <= max_dim:
        return False

    # Calculate new dimensions preserving aspect ratio, ensure even
    scale = max_dim / max(w, h)
    new_w = int(w * scale) & ~1
    new_h = int(h * scale) & ~1
    print(f"    Downscaling {w}x{h} → {new_w}x{new_h}")

    input_container = av.open(mp4_path)
    tmp_path = mp4_path + ".tmp"
    output_container = av.open(tmp_path, "w", format="mp4")

    in_stream = input_container.streams.video[0]
    in_stream.thread_type = "AUTO"
    in_stream.thread_count = int(os.environ.get("CONVERT_THREADS", 0)) or None
    out_stream = output_container.add_stream("libx264", rate=fps)
    out_stream.width = new_w
    out_stream.height = new_h
    out_stream.pix_fmt = "yuv420p"
    out_stream.options = {"crf": "18", "preset": "medium"}

    for frame in input_container.decode(video=0):
        frame = frame.reformat(width=new_w, height=new_h)
        for packet in out_stream.encode(frame):
            output_container.mux(packet)

    for packet in out_stream.encode():
        output_container.mux(packet)

    output_container.close()
    input_container.close()

    os.replace(tmp_path, mp4_path)
    return True


def _convert_bhtensor_to_patches(
    bhtensor_path: str,
    h5_path: str,
    output_dir: str,
    video_stem: str,
    num_clusters: int,
    crop_bbox: tuple[int, int, int, int],
    quality: int = 80,
) -> dict:
    """Convert .bhtensor → WebP archives (bases + mouth patches).

    Returns dict with lip_sync metadata for manifest.json.
    """
    import av
    import numpy as np
    import cv2
    from tqdm import tqdm
    from concurrent.futures import ThreadPoolExecutor

    from bithuman.engine.video_reader import (
        ENCRYPT_KEY,
        _streaming_xor_decrypt_file,
        _write_xor_encrypted,
    )
    from bithuman.engine.patch_reader import BLOB_MAGIC, BLOB_VERSION, BLOB_HEADER_SIZE

    input_path = Path(bhtensor_path)
    x1, y1, x2, y2 = crop_bbox
    crop_w, crop_h = x2 - x1, y2 - y1

    bases_path = os.path.join(output_dir, f"{video_stem}_bases.bin")
    patches_path = os.path.join(output_dir, f"{video_stem}_patches.bin")

    # Phase 1: Decrypt .bhtensor → temp MP4
    import tempfile
    tmp_video_fd, tmp_video_path = tempfile.mkstemp(suffix=".mp4")
    os.close(tmp_video_fd)

    try:
        _streaming_xor_decrypt_file(bhtensor_path, tmp_video_path, ENCRYPT_KEY)

        # Phase 2: Decode H.264 and encode WebP archives
        container = av.open(tmp_video_path)
        stream = container.streams.video[0]
        stream.thread_type = "AUTO"
        stream.thread_count = int(os.environ.get("CONVERT_THREADS", 0)) or None
        width = stream.codec_context.width
        height = stream.codec_context.height

        total_frames_expected = stream.frames or 0
        num_source_frames = total_frames_expected // num_clusters if total_frames_expected else 0

        num_workers = int(os.environ.get("CONVERT_THREADS", max(1, int((os.cpu_count() or 4) * 0.8))))

        def encode_webp(frame_bgr, q=quality):
            _, buf = cv2.imencode(".webp", frame_bgr, [cv2.IMWRITE_WEBP_QUALITY, q])
            return buf.tobytes()

        # Temp files for streaming blob writes
        tmp_bases_fd, tmp_bases = tempfile.mkstemp()
        tmp_patches_fd, tmp_patches = tempfile.mkstemp()

        try:
            base_offsets = []
            patch_offsets = []
            actual_source_frames = 0

            frames_iter = container.decode(video=0)
            desc = f"  Converting {input_path.name}"

            with os.fdopen(tmp_bases_fd, "wb") as bf, \
                 os.fdopen(tmp_patches_fd, "wb") as pf, \
                 ThreadPoolExecutor(max_workers=num_workers) as pool:

                # Use tqdm - estimate total source frames
                pbar = tqdm(
                    desc=desc,
                    total=num_source_frames if num_source_frames > 0 else None,
                    unit="group",
                    leave=True,
                )

                while True:
                    # Read one source frame group (num_clusters frames)
                    group = []
                    for _ in range(num_clusters):
                        try:
                            frame = next(frames_iter)
                            group.append(frame.to_ndarray(format="bgr24"))
                        except StopIteration:
                            break

                    if not group:
                        break

                    actual_source_frames += 1

                    # Encode base (full frame)
                    base_blob_future = pool.submit(encode_webp, group[0])

                    # Encode mouth patches (cropped regions) in parallel
                    patch_futures = []
                    for i in range(1, len(group)):
                        patch = group[i][y1:y2, x1:x2].copy()
                        patch_futures.append(pool.submit(encode_webp, patch))

                    # Write base
                    base_blob = base_blob_future.result()
                    base_offsets.append(bf.tell())
                    bf.write(base_blob)

                    # Write patches
                    for fut in patch_futures:
                        patch_blob = fut.result()
                        patch_offsets.append(pf.tell())
                        pf.write(patch_blob)

                    pbar.update(1)

                pbar.close()

            container.close()

            # Assemble bases archive
            _assemble_blob_archive(
                bases_path, base_offsets, tmp_bases,
                width, height, quality, ENCRYPT_KEY,
            )

            # Assemble patches archive
            _assemble_blob_archive(
                patches_path, patch_offsets, tmp_patches,
                crop_w, crop_h, quality, ENCRYPT_KEY,
            )

        finally:
            for p in (tmp_bases, tmp_patches):
                if os.path.exists(p):
                    os.unlink(p)
    finally:
        if os.path.exists(tmp_video_path):
            os.unlink(tmp_video_path)

    in_size = input_path.stat().st_size / 1024 / 1024
    bases_size = Path(bases_path).stat().st_size / 1024 / 1024
    patches_size = Path(patches_path).stat().st_size / 1024 / 1024
    total_size = bases_size + patches_size
    print(
        f"  {input_path.name} ({in_size:.1f} MB) → "
        f"bases ({bases_size:.1f} MB) + patches ({patches_size:.1f} MB) = {total_size:.1f} MB"
    )

    return {
        "bases_file": os.path.basename(bases_path),
        "patches_file": os.path.basename(patches_path),
        "crop_bbox": list(crop_bbox),
        "num_source_frames": actual_source_frames,
        "num_clusters": num_clusters,
    }


def _assemble_blob_archive(
    output_path: str,
    blob_offsets: list[int],
    tmp_blob_path: str,
    width: int,
    height: int,
    quality: int,
    key: bytes,
) -> None:
    """Assemble an indexed blob archive from a temp blob file + offset list."""
    import struct
    from bithuman.engine.patch_reader import BLOB_MAGIC, BLOB_VERSION, BLOB_HEADER_SIZE
    from bithuman.engine.video_reader import _write_xor_encrypted

    frame_count = len(blob_offsets)
    data_start = BLOB_HEADER_SIZE + frame_count * 8
    abs_offsets = [data_start + off for off in blob_offsets]

    header = struct.pack(
        "<4sHIHHBBQ",
        BLOB_MAGIC, BLOB_VERSION, frame_count,
        width, height, quality, 0, data_start,
    )
    index_data = struct.pack(f"<{frame_count}Q", *abs_offsets)

    with open(output_path, "wb") as out:
        _write_xor_encrypted(out, 0, header, key)
        _write_xor_encrypted(out, BLOB_HEADER_SIZE, index_data, key)
        with open(tmp_blob_path, "rb") as blob_in:
            pos = data_start
            while True:
                chunk = blob_in.read(256 * 1024)
                if not chunk:
                    break
                _write_xor_encrypted(out, pos, chunk, key)
                pos += len(chunk)


def _generate_manifest(
    workspace: Path,
    model_hash: str,
    lip_sync_data: dict[str, dict],
    num_clusters: int,
) -> dict:
    """Generate manifest.json for IMX v2 format.

    Merges video configuration from videos.yaml with computed metadata
    (frame counts, resolutions, hashes, lip_sync info) into a single manifest.

    Args:
        workspace: Extracted workspace directory.
        model_hash: MD5 hash of the original model file.
        lip_sync_data: Per-video lip sync metadata from _convert_bhtensor_to_patches().
        num_clusters: Number of audio clusters from feature_centers.npy.
    """
    import yaml
    import cv2

    videos_yaml = workspace / "videos.yaml"
    if not videos_yaml.exists():
        # Auto-generate from video files
        mp4_files = list(workspace.rglob("videos/*.mp4"))
        if not mp4_files:
            raise FileNotFoundError(f"videos.yaml not found and no video files in {workspace}")
        videos_config = {"videos": []}
        for mp4 in mp4_files:
            videos_config["videos"].append({
                "name": mp4.stem,
                "single_direction": True,
                "video_file": str(mp4.relative_to(workspace)),
                "video_type": "LoopingVideo",
            })
        with open(videos_yaml, "w") as f:
            yaml.dump(videos_config, f, default_flow_style=False)

    with open(videos_yaml) as f:
        config = yaml.safe_load(f)

    manifest = {
        "format_version": 2,
        "model_hash": model_hash,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "audio": {
            "feature_centers_file": "audio/feature_centers.npz",
            "num_clusters": num_clusters,
        },
        "videos": {},
    }

    # Extract script section if present
    if "videos_script" in config:
        script = config["videos_script"]
        manifest["script"] = {
            "fps": script.get("FPS", 25),
            "back_to_idle": script.get("BACK_TO_IDLE", 15),
            "default_video": script.get("default_video", ""),
        }
        if "action_hi_video" in script:
            manifest["script"]["action_hi_video"] = script["action_hi_video"]
        if "idle_actions" in script:
            manifest["script"]["idle_actions"] = script["idle_actions"]

    for vc in config.get("videos", []):
        name = vc["name"]
        video_file = vc.get("video_file", "")
        video_type = vc.get("video_type", "LoopingVideo")
        video_stem = Path(video_file).stem if video_file else name

        # Find the .mp4 file
        mp4_path = workspace / video_file if video_file else None
        if mp4_path and not mp4_path.exists():
            mp4_candidates = _find_files_case_insensitive(workspace, name, ".mp4")
            mp4_path = mp4_candidates[0] if mp4_candidates else None

        # Compute video metadata
        video_hash = ""
        frame_count = 0
        resolution = [0, 0]

        if mp4_path and mp4_path.exists():
            with open(mp4_path, "rb") as f:
                video_hash = hashlib.md5(f.read()).hexdigest()
            cap = cv2.VideoCapture(str(mp4_path))
            try:
                frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                resolution = [
                    int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
                    int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
                ]
            finally:
                cap.release()

        # Check HDF5 for frame count (more accurate than OpenCV for lip-sync videos)
        h5_candidates = _find_files_case_insensitive(workspace, video_stem, ".h5")
        h5_path = h5_candidates[0] if h5_candidates else None
        if h5_path and h5_path.exists():
            import h5py
            with h5py.File(str(h5_path), "r") as f:
                h5_frames = len(f["face_coords"])
                if h5_frames > 0:
                    frame_count = h5_frames
            # Note: resolution stays from the actual MP4 (not H5 frame_wh),
            # since H5 frame_wh is the face coordinate space which may differ
            # from the video resolution. The runtime resizes as needed.

        # Determine correct video_file path for the container
        video_file_in_container = f"videos/{video_stem}.mp4"
        if mp4_path and mp4_path.exists():
            video_file_in_container = str(mp4_path.relative_to(workspace))

        # Build per-video metadata
        vmeta = {
            "video_file": video_file_in_container,
            "video_hash": video_hash,
            "frame_count": frame_count,
            "resolution": resolution,
            "type": video_type,
            "single_direction": vc.get("single_direction", True),
        }

        # Video type specific fields
        if video_type == "LoopingVideo":
            if "stride" in vc:
                vmeta["stride"] = vc["stride"]
            if "loop_between" in vc:
                vmeta["loop_between"] = vc["loop_between"]
        elif video_type == "SingleActionVideo":
            vmeta["action_frame"] = vc.get("action_frame", -1)
            vmeta["transition_frames"] = vc.get("transition_frames", [0, -1])
            if "stop_on_user_speech" in vc:
                vmeta["stop_on_user_speech"] = vc["stop_on_user_speech"]
            if "stop_on_agent_speech" in vc:
                vmeta["stop_on_agent_speech"] = vc["stop_on_agent_speech"]

        # Lip sync data (if this video has it)
        lip_sync_required = vc.get("lip_sync_required", True)
        if lip_sync_required and video_stem in lip_sync_data:
            ls = lip_sync_data[video_stem]
            h5_rel = str(h5_path.relative_to(workspace)) if h5_path else ""
            vmeta["lip_sync"] = {
                "h5_file": f"lip_sync/{Path(h5_rel).name}" if h5_rel else "",
                "bases_file": f"lip_sync/{ls['bases_file']}",
                "patches_file": f"lip_sync/{ls['patches_file']}",
                "crop_bbox": ls["crop_bbox"],
                "num_source_frames": ls["num_source_frames"],
                "num_clusters": ls["num_clusters"],
            }

        # Graph metadata
        graph = {}
        adding_kwargs = vc.get("adding_kwargs", {})
        if "edge_threshold" in adding_kwargs:
            graph["edge_threshold"] = adding_kwargs["edge_threshold"]
        if "connects_to" in adding_kwargs and adding_kwargs["connects_to"]:
            graph["connects_to"] = adding_kwargs["connects_to"]
        if "num_filler_frames" in adding_kwargs:
            graph["num_filler_frames"] = adding_kwargs["num_filler_frames"]
        if graph:
            vmeta["graph"] = graph

        manifest["videos"][name] = vmeta

    return manifest


def convert_tar_to_v2(
    workspace: Path,
    output_path: Path,
    quality: int = 80,
    max_resolution: int = 1280,
    model_hash: str = "",
) -> None:
    """Convert an extracted TAR workspace to an IMX v2 container.

    This is the core conversion pipeline used by both ``cmd_convert()``
    (CLI) and the auto-conversion path in ``unzip_tarfile()``.

    Args:
        workspace: Root of the extracted TAR workspace (contains videos.yaml,
            videos/, etc.).
        output_path: Where to write the IMX v2 container.
        quality: WebP compression quality for lip-sync patches (1-100).
        max_resolution: Downscale videos exceeding this max dimension.
        model_hash: MD5 hash of the original model file (stored in manifest).
    """
    import shutil

    import numpy as np
    from loguru import logger

    from bithuman.engine.video_reader import (
        compute_mask_bbox,
        write_imx_v2_container,
    )

    # Read feature_centers.npy to get num_clusters
    fc_files = list(workspace.rglob("feature_centers.npy"))
    if not fc_files:
        raise FileNotFoundError(f"feature_centers.npy not found in {workspace}")

    feature_centers = np.load(fc_files[0])
    num_clusters = feature_centers.shape[0]
    logger.info(f"Audio clusters: {num_clusters}")

    # Convert avatar .bhtensor files to WebP (bases + patches)
    avatar_files = _find_avatar_bhtensor_files(str(workspace))
    lip_sync_data = {}

    if avatar_files:
        logger.info(f"Converting {len(avatar_files)} lip-sync file(s) to base+patch format")

        for bhtensor_file in avatar_files:
            video_stem = bhtensor_file.name.split(".")[0]
            h5_candidates = _find_files_case_insensitive(workspace, video_stem, ".h5")

            if not h5_candidates:
                logger.warning(f"No .h5 file found for {bhtensor_file.name}, skipping")
                continue

            h5_path = h5_candidates[0]

            import h5py
            with h5py.File(str(h5_path), "r") as f:
                wh = f.attrs["frame_wh"]
                frame_w, frame_h = int(wh[0]), int(wh[1])

            crop_bbox = compute_mask_bbox(str(h5_path), frame_w, frame_h)

            lip_sync_dir = workspace / "lip_sync"
            lip_sync_dir.mkdir(exist_ok=True)

            ls_meta = _convert_bhtensor_to_patches(
                str(bhtensor_file), str(h5_path),
                str(lip_sync_dir), video_stem,
                num_clusters, crop_bbox, quality,
            )
            lip_sync_data[video_stem] = ls_meta
            bhtensor_file.unlink()

    # Downscale MP4 videos
    mp4_files = sorted(f for f in workspace.rglob("videos/*.mp4") if not f.name.startswith("._"))
    pre_downscale_hashes = {}
    for mp4_file in mp4_files:
        with open(mp4_file, "rb") as f:
            pre_downscale_hashes[mp4_file.stem] = hashlib.md5(f.read()).hexdigest()

    if mp4_files:
        logger.info(f"Checking {len(mp4_files)} video(s) for downscaling (max {max_resolution}p)")
        for mp4_file in mp4_files:
            _downscale_video(str(mp4_file), max_dim=max_resolution)

    # Build similarity matrix hash rename map
    hash_rename_map = {}
    for mp4_file in mp4_files:
        old_hash = pre_downscale_hashes.get(mp4_file.stem, "")
        if mp4_file.exists() and old_hash:
            with open(mp4_file, "rb") as f:
                new_hash = hashlib.md5(f.read()).hexdigest()
            if old_hash[:8] != new_hash[:8]:
                hash_rename_map[old_hash[:8]] = new_hash[:8]

    # Compress feature_centers
    audio_dir = workspace / "audio"
    audio_dir.mkdir(exist_ok=True)
    np.savez_compressed(audio_dir / "feature_centers.npz", feature_centers)

    # Move h5 files to lip_sync/ directory
    lip_sync_dir = workspace / "lip_sync"
    lip_sync_dir.mkdir(exist_ok=True)
    for h5_file in workspace.rglob("videos/*.h5"):
        dest = lip_sync_dir / h5_file.name
        if not dest.exists():
            shutil.copy2(h5_file, dest)

    # Generate manifest
    manifest = _generate_manifest(workspace, model_hash, lip_sync_data, num_clusters)
    manifest_json = json.dumps(manifest, indent=2).encode("utf-8")

    # Collect files for IMX v2 container
    files = {}
    files["manifest.json"] = manifest_json

    npz_path = audio_dir / "feature_centers.npz"
    with open(npz_path, "rb") as f:
        files["audio/feature_centers.npz"] = f.read()

    for name, vmeta in manifest["videos"].items():
        video_file = vmeta["video_file"]
        src = workspace / video_file
        if src.exists():
            with open(src, "rb") as f:
                files[video_file] = f.read()

    for name, vmeta in manifest["videos"].items():
        lip = vmeta.get("lip_sync")
        if lip:
            for key in ("h5_file", "bases_file", "patches_file"):
                fpath = lip[key]
                src = workspace / fpath
                if src.exists():
                    with open(src, "rb") as f:
                        files[fpath] = f.read()

    for npy_file in sorted(workspace.rglob("similarities/*.npy")):
        fname = npy_file.name
        for old_id, new_id in hash_rename_map.items():
            fname = fname.replace(old_id, new_id)
        rel = f"graph/similarities/{fname}"
        with open(npy_file, "rb") as f:
            files[rel] = f.read()

    graph_dot = workspace / "video_graph.dot"
    if graph_dot.exists():
        with open(graph_dot, "rb") as f:
            files["graph/video_graph.dot"] = f.read()

    # Write IMX v2 container
    tmp_output = str(output_path) + ".tmp"
    write_imx_v2_container(tmp_output, files)
    os.replace(tmp_output, str(output_path))


def _branded_header() -> str:
    """Return branded header lines for CLI output."""
    from bithuman._version import __version__
    return (
        f"  bitHuman Avatar Engine v{__version__}\n"
        f"  {'─' * 41}"
    )


def _load_imx_container(path: str) -> "ImxContainer":
    """Load an IMX model, auto-converting legacy TAR format if needed.

    Returns an ImxContainer with manifest.json metadata.
    """
    from bithuman.utils.unzip import unzip_tarfile
    from bithuman.engine.video_reader import ImxContainer, is_imx_v2_file

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {path}")

    # Check if auto-conversion will happen (TAR format)
    if not is_imx_v2_file(path):
        print("  Upgrading model to optimized format...")

    result, temp_dir, _ = unzip_tarfile(path)

    if isinstance(result, ImxContainer):
        return result

    raise RuntimeError(f"Unexpected result from unzip_tarfile: {type(result)}")


def _detect_model_format(path: str) -> str:
    """Detect model format without loading. Returns 'imx_v2', 'imx_v1', 'tar', or 'unknown'."""
    from bithuman.engine.video_reader import IMX_MAGIC

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {path}")
    if p.is_dir():
        return "directory"

    with open(path, "rb") as f:
        magic = f.read(4)

    if magic == IMX_MAGIC:
        return "imx_v2"
    if magic == b"BIMX":
        return "imx_v1"
    # Check for TAR
    try:
        with tarfile.open(path, "r") as _:
            return "tar"
    except (tarfile.TarError, Exception):
        pass
    return "unknown"


def cmd_info(args: argparse.Namespace) -> int:
    """Show model information."""
    path = args.path
    p = Path(path)
    if not p.exists():
        print(f"  ERROR: File not found: {path}")
        return 1

    fmt = _detect_model_format(path)
    file_size = p.stat().st_size / 1024 / 1024
    filename = p.name

    # Handle legacy/unsupported formats without auto-converting
    if fmt == "tar":
        print(_branded_header())
        print(f"  Model:        {filename} ({file_size:.1f} MB)")
        print(f"  Format:       Legacy TAR archive")
        print()
        print("  This model uses the legacy TAR format and must be converted")
        print("  to IMX v2 before detailed info can be shown.")
        print()
        print("  To convert:")
        print(f"    bithuman convert {path}")
        print(f"  {'─' * 41}")
        return 0

    if fmt == "imx_v1":
        print(_branded_header())
        print(f"  Model:        {filename} ({file_size:.1f} MB)")
        print(f"  Format:       IMX v1 (outdated)")
        print()
        print("  This model uses an outdated container format (IMX v1).")
        print("  Please re-convert from the original source.")
        print(f"  {'─' * 41}")
        return 1

    if fmt == "directory":
        print(_branded_header())
        print(f"  Model:        {filename} (directory)")
        print(f"  Format:       Unpackaged workspace")
        print()
        print("  To package as IMX v2:")
        print(f"    bithuman convert {path}")
        print(f"  {'─' * 41}")
        return 0

    if fmt != "imx_v2":
        print(f"  ERROR: Unrecognized file format: {path}")
        return 1

    # IMX v2 — load metadata
    try:
        container = _load_imx_container(path)
    except (FileNotFoundError, RuntimeError) as e:
        print(f"  ERROR: {e}")
        return 1

    meta = container.metadata
    if not meta:
        print("  ERROR: Model has no metadata (manifest.json missing)")
        return 1

    # Format version
    fmt_version = meta.get("format_version", "unknown")

    # Created date
    created = meta.get("created_at", "unknown")

    # Audio info
    audio = meta.get("audio", {})
    num_clusters = audio.get("num_clusters", 0)

    # Script info
    script = meta.get("script", {})

    # Video summary
    videos = meta.get("videos", {})
    total_videos = len(videos)
    looping = sum(1 for v in videos.values() if v.get("type") == "LoopingVideo")
    action = sum(1 for v in videos.values() if v.get("type") == "SingleActionVideo")
    lip_sync_count = sum(1 for v in videos.values() if v.get("lip_sync"))

    print(_branded_header())
    print(f"  Model:        {filename} ({file_size:.1f} MB)")
    print(f"  Format:       IMX v{fmt_version}")
    print(f"  Created:      {created}")

    if num_clusters:
        print()
        print(f"  Audio")
        print(f"    Clusters:   {num_clusters}")

    if script:
        print()
        print(f"  Script")
        default_video = script.get("default_video", "")
        fps = script.get("fps", 25)
        idle_after = script.get("back_to_idle", 0)
        if default_video:
            print(f"    Default:    {default_video}")
        print(f"    FPS:        {fps}")
        if idle_after:
            print(f"    Idle After: {idle_after}s")

    if total_videos:
        type_parts = []
        if looping:
            type_parts.append(f"{looping} looping")
        if action:
            type_parts.append(f"{action} action")
        type_summary = ", ".join(type_parts)
        print()
        print(f"  Videos:       {total_videos} total ({type_summary})")
        print(f"    Lip Sync:   {lip_sync_count} of {total_videos} videos")

    print(f"  {'─' * 41}")
    return 0


def cmd_list_videos(args: argparse.Namespace) -> int:
    """List videos in a model."""
    path = args.path

    # Reject legacy formats — don't auto-convert for read-only commands
    fmt = _detect_model_format(path)
    if fmt in ("tar", "imx_v1", "directory"):
        print(f"  ERROR: Model must be in IMX v2 format. Convert first:")
        print(f"    bithuman convert {path}")
        return 1

    try:
        container = _load_imx_container(path)
    except (FileNotFoundError, RuntimeError) as e:
        print(f"  ERROR: {e}")
        return 1

    meta = container.metadata
    if not meta:
        print("  ERROR: Model has no metadata (manifest.json missing)")
        return 1

    videos = meta.get("videos", {})
    if not videos:
        print("  No videos found in model.")
        return 0

    filename = Path(path).name

    print(_branded_header())
    print()
    print(f"  Videos in {filename}:")
    print()

    # Compute name column width based on longest video name
    name_col = max(max(len(n) for n in videos) + 2, 14)
    table_width = name_col + 10 + 8 + 12 + 10 + 15

    # Table header
    header = f"  {'Name':<{name_col}}{'Type':<10}{'Frames':<8}{'Resolution':<12}{'Lip Sync':<10}{'Direction'}"
    print(header)
    print(f"  {'─' * table_width}")

    for name, vmeta in videos.items():
        vtype_raw = vmeta.get("type", "")
        if vtype_raw == "LoopingVideo":
            vtype = "Looping"
        elif vtype_raw == "SingleActionVideo":
            vtype = "Action"
        else:
            vtype = vtype_raw

        frame_count = vmeta.get("frame_count", 0)
        resolution = vmeta.get("resolution", [0, 0])
        res_str = f"{resolution[0]}\u00d7{resolution[1]}" if resolution[0] else "-"
        has_lip = "Enabled" if vmeta.get("lip_sync") else "-"
        single_dir = vmeta.get("single_direction", True)
        direction = "Forward" if single_dir else "Bidirectional"

        print(f"  {name:<{name_col}}{vtype:<10}{frame_count:<8}{res_str:<12}{has_lip:<10}{direction}")

    print(f"  {'─' * table_width}")
    print()
    print(f"  {len(videos)} videos total")
    return 0


def cmd_snapshot(args: argparse.Namespace) -> int:
    """Generate a snapshot collage of lip-sync clusters for a video frame."""
    import math

    path = args.path
    video_name = args.video
    frame_num = args.frame
    output_path = args.output

    try:
        container = _load_imx_container(path)
    except (FileNotFoundError, RuntimeError) as e:
        print(f"  ERROR: {e}")
        return 1

    meta = container.metadata
    if not meta:
        print("  ERROR: Model has no metadata (manifest.json missing)")
        return 1

    videos = meta.get("videos", {})
    available_names = list(videos.keys())

    # Check video exists
    if video_name not in videos:
        print(f"  Video '{video_name}' not found. Available: {', '.join(available_names)}")
        return 1

    vmeta = videos[video_name]

    # Check lip sync
    lip_sync = vmeta.get("lip_sync")
    if not lip_sync:
        lip_sync_videos = [n for n, v in videos.items() if v.get("lip_sync")]
        if lip_sync_videos:
            print(f"  Video '{video_name}' does not have lip-sync data. Try: {', '.join(lip_sync_videos)}")
        else:
            print(f"  Video '{video_name}' does not have lip-sync data.")
        return 1

    num_source_frames = lip_sync.get("num_source_frames", 0)
    num_clusters = lip_sync.get("num_clusters", 0)

    # Check frame range
    if frame_num < 0 or frame_num >= num_source_frames:
        print(f"  Frame {frame_num} is out of range. Valid: 0\u2013{num_source_frames - 1}")
        return 1

    # Default output filename
    if not output_path:
        output_path = f"snapshot_{video_name}_{frame_num}.webp"

    print(_branded_header())
    print(f"  Generating snapshot...")
    print(f"    Video:      {video_name}")
    print(f"    Frame:      {frame_num} of {num_source_frames}")
    print(f"    Variants:   {num_clusters} lip-sync clusters")

    # Open raw base and patch readers separately for visualization
    import cv2
    import numpy as np
    from bithuman.engine.patch_reader import BlobReader, PatchReader

    bases_file = lip_sync["bases_file"]
    patches_file = lip_sync["patches_file"]
    bases_offset, bases_size = container.get_entry(bases_file)
    patches_offset, patches_size = container.get_entry(patches_file)

    base_reader = BlobReader(
        container.path, decoder="webp",
        base_offset=bases_offset, file_size=bases_size,
    )
    patch_blob_reader = BlobReader(
        container.path, decoder="webp",
        base_offset=patches_offset, file_size=patches_size,
    )
    patch_reader = PatchReader(
        container.path,
        container.path,
        lip_sync,
        decode_fn="webp",
        bases_offset=bases_offset,
        bases_size=bases_size,
        patches_offset=patches_offset,
        patches_size=patches_size,
    )

    try:
        x1, y1, x2, y2 = lip_sync["crop_bbox"]
        cell_w = base_reader.width
        cell_h = base_reader.height
        patch_w = x2 - x1  # crop_bbox width
        patch_h = y2 - y1  # crop_bbox height

        # Grid layout: wrap clusters into rows of grid_cols, each cluster
        # has 3 sub-rows (base / diff / reconstructed)
        grid_cols = int(math.ceil(math.sqrt(num_clusters)))
        grid_rows = int(math.ceil(num_clusters / grid_cols))
        label_h = 20
        # Each cluster block: 3 equal sub-rows
        block_h = 3 * (cell_h + label_h)
        canvas_w = grid_cols * cell_w
        canvas_h = grid_rows * block_h
        canvas = np.zeros((canvas_h, canvas_w, 3), dtype=np.uint8)

        print(f"    Crop bbox:  ({x1},{y1})-({x2},{y2}) = {patch_w}\u00d7{patch_h}")
        print(f"    Grid:       {grid_cols} \u00d7 {grid_rows}")

        base_frame = base_reader.get(frame_num)

        for cluster in range(num_clusters):
            gc = cluster % grid_cols
            gr = cluster // grid_cols
            x0 = gc * cell_w
            block_y = gr * block_h

            flat_idx = frame_num * num_clusters + cluster
            reconstructed = patch_reader.get(flat_idx)

            # --- Sub-row 1: Base frame ---
            r1_label_y = block_y
            r1_img_y = block_y + label_h
            canvas[r1_img_y : r1_img_y + cell_h, x0 : x0 + cell_w] = base_frame
            cv2.putText(canvas, f"base (c={cluster})", (x0 + 2, r1_label_y + 13),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200, 200, 200), 1, cv2.LINE_AA)
            # Draw crop_bbox on base
            cv2.rectangle(canvas, (x0 + x1, r1_img_y + y1), (x0 + x2, r1_img_y + y2),
                          (0, 255, 0), 1)

            # --- Sub-row 2: Pixel diff (amplified abs(result - base)) ---
            r2_label_y = r1_img_y + cell_h
            r2_img_y = r2_label_y + label_h
            if cluster == 0:
                cv2.putText(canvas, "no diff (base)", (x0 + 2, r2_label_y + 13),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.35, (100, 100, 100), 1, cv2.LINE_AA)
            else:
                diff = cv2.absdiff(reconstructed, base_frame)
                # Amplify 4x so subtle differences are visible
                diff = np.clip(diff.astype(np.uint16) * 4, 0, 255).astype(np.uint8)
                canvas[r2_img_y : r2_img_y + cell_h, x0 : x0 + cell_w] = diff
                cv2.putText(canvas, f"diff c={cluster} (4x)", (x0 + 2, r2_label_y + 13),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200, 200, 200), 1, cv2.LINE_AA)

            # --- Sub-row 3: Reconstructed ---
            r3_label_y = r2_img_y + cell_h
            r3_img_y = r3_label_y + label_h
            canvas[r3_img_y : r3_img_y + cell_h, x0 : x0 + cell_w] = reconstructed
            cv2.putText(canvas, f"result c={cluster}", (x0 + 2, r3_label_y + 13),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200, 200, 200), 1, cv2.LINE_AA)
            cv2.rectangle(canvas, (x0 + x1, r3_img_y + y1), (x0 + x2, r3_img_y + y2),
                          (0, 255, 0), 1)

        cv2.imwrite(output_path, canvas, [cv2.IMWRITE_WEBP_QUALITY, 50])

        total_h, total_w = canvas.shape[:2]
        file_kb = Path(output_path).stat().st_size / 1024
        print()
        print(f"  Saved: {output_path} ({total_w}\u00d7{total_h}, {file_kb:.0f} KB)")
    finally:
        base_reader.close()
        patch_blob_reader.close()
        patch_reader.close()

    print(f"  {'─' * 41}")
    return 0


def cmd_convert(args: argparse.Namespace) -> int:
    """Convert old .imx (tar) model to optimized IMX v2 format."""
    import time

    from bithuman.engine.video_reader import is_imx_v2_file

    imx_path = Path(args.imx_path)
    if not imx_path.exists():
        print(f"ERROR: File not found: {imx_path}")
        return 1

    # Check if already IMX v2
    if is_imx_v2_file(str(imx_path)):
        print(f"Already in IMX v2 format: {imx_path}")
        return 0

    # Reject old IMX v1 format
    try:
        with open(imx_path, "rb") as f:
            magic = f.read(4)
        if magic == b"BIMX":
            print("ERROR: This file uses an outdated container format (IMX v1).")
            print("Please convert from the original TAR-based .imx file instead.")
            return 1
    except (OSError, IOError):
        pass

    output_path = Path(args.output) if args.output else imx_path
    quality = args.quality
    max_res = getattr(args, "max_resolution", 1280)
    overwriting = output_path.resolve() == imx_path.resolve()

    t_start = time.perf_counter()

    # Compute model hash
    print("Computing model hash...")
    with open(imx_path, "rb") as f:
        h = hashlib.md5()
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
        model_hash = h.hexdigest()

    imx_size = imx_path.stat().st_size / 1024 / 1024
    print(f"Input:   {imx_path} ({imx_size:.1f} MB)")
    print(f"Output:  {output_path}")
    print(f"Quality: WebP q{quality}")
    print()

    if overwriting and sys.stdin.isatty():
        answer = input("Overwrite the original .imx file? [y/N] ").strip().lower()
        if answer not in ("y", "yes"):
            print("Aborted.")
            return 1

    # Extract TAR archive
    temp_dir = TemporaryDirectory()
    print("Extracting .imx archive...")
    mode = "r:gz" if imx_path.name.endswith("gz") else "r"
    with tarfile.open(imx_path, mode) as tar:
        tar.extractall(temp_dir.name)

    workspace = Path(temp_dir.name)
    contents = list(workspace.iterdir())
    if len(contents) == 1 and contents[0].is_dir():
        workspace = contents[0]

    # Run the conversion pipeline
    convert_tar_to_v2(
        workspace, output_path,
        quality=quality,
        max_resolution=max_res,
        model_hash=model_hash,
    )

    t_elapsed = time.perf_counter() - t_start
    out_size = output_path.stat().st_size / 1024 / 1024
    reduction = (1 - out_size / imx_size) * 100

    print(f"\n{'='*60}")
    print(f"  Conversion complete!")
    print(f"  Input:     {imx_size:.1f} MB")
    print(f"  Output:    {out_size:.1f} MB ({reduction:.1f}% smaller)")
    print(f"  Time:      {t_elapsed:.1f}s")
    print(f"  Output:    {output_path}")
    print(f"{'='*60}")

    temp_dir.cleanup()
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    """Validate IMX model(s) by testing if they load correctly."""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    from bithuman.video_graph.graph import VideoGraph

    path = Path(args.path)

    def validate_single(model_path: Path) -> tuple[str, bool, str]:
        """Validate a single model. Returns (name, success, error)."""
        try:
            if not model_path.exists():
                return model_path.name, False, "File not found"

            # Try to load the model (handles IMX v2, legacy TAR, and directories)
            VideoGraph.from_workspace(str(model_path))
            return model_path.name, True, ""
        except Exception as e:
            return model_path.name, False, str(e)[:100]

    # Collect models to validate
    models: list[Path] = []
    if path.is_file():
        models = [path]
    elif path.is_dir():
        # Check if it's a single agent dir or a parent directory
        model_file = path / "model.imx"
        if model_file.exists():
            models = [model_file]
        else:
            # Scan for all model.imx files
            for agent_dir in path.iterdir():
                if agent_dir.is_dir():
                    m = agent_dir / "model.imx"
                    if m.exists():
                        models.append(m)
            models = sorted(models)
    else:
        print(f"ERROR: Path not found: {path}")
        return 1

    if not models:
        print(f"No models found at: {path}")
        return 1

    # Validate
    workers = min(args.workers, len(models))
    print(f"Validating {len(models)} model(s) with {workers} workers...")

    valid = 0
    invalid = 0
    errors: list[tuple[str, str]] = []

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(validate_single, m): m for m in models}
        for i, future in enumerate(as_completed(futures), 1):
            name, success, error = future.result()
            if success:
                valid += 1
            else:
                invalid += 1
                errors.append((name, error))

            if len(models) > 10 and i % 100 == 0:
                print(f"  [{i:,}/{len(models):,}] valid: {valid}, invalid: {invalid}")

    # Summary
    print(f"\nValidation Results:")
    print(f"  Total:   {len(models)}")
    print(f"  Valid:   {valid}")
    print(f"  Invalid: {invalid}")

    if errors:
        print(f"\nInvalid models ({len(errors)}):")
        # Group by error type
        error_groups: dict[str, list[str]] = {}
        for name, err in errors:
            key = err[:50] if err else "Unknown error"
            error_groups.setdefault(key, []).append(name)

        for err, names in sorted(error_groups.items(), key=lambda x: -len(x[1]))[:10]:
            print(f"  [{len(names)}x] {err}")
            if len(names) <= 3:
                for n in names:
                    print(f"       - {n}")

    return 0 if invalid == 0 else 1


def cmd_generate(args: argparse.Namespace) -> int:
    """Generate lip-synced video from avatar model + audio."""
    import asyncio
    import resource
    import time

    import numpy as np

    path = args.path
    audio_path = args.audio
    output_path = args.output or "output.mp4"
    api_key = args.key or os.environ.get("BITHUMAN_API_KEY", "")

    if not api_key:
        print("  ERROR: API key required. Use --key or set BITHUMAN_API_KEY env var.")
        return 1

    if not Path(path).exists():
        print(f"  ERROR: Model not found: {path}")
        return 1

    if not Path(audio_path).exists():
        print(f"  ERROR: Audio not found: {audio_path}")
        return 1

    max_dim = args.max_resolution
    workers = args.workers
    if workers == 0:
        workers = os.cpu_count() or 4
    elif workers < 0:
        workers = 1

    async def _render():
        import av
        import cv2
        from loguru import logger
        from bithuman import AsyncBithuman
        from bithuman.audio import load_audio, float32_to_int16

        # Suppress verbose loguru output during CLI generation
        logger.remove()
        if args.verbose:
            logger.add(sys.stderr, level="DEBUG")

        print(_branded_header())
        print(f"  Model:   {path}")
        print(f"  Audio:   {audio_path}")
        print(f"  Output:  {output_path}")
        if workers > 1:
            print(f"  Workers: {workers}")
        print()

        # Load audio
        audio_float, sample_rate = load_audio(audio_path)
        audio_int16 = float32_to_int16(audio_float)
        audio_duration = len(audio_int16) / sample_rate
        print(f"  Audio loaded: {audio_duration:.1f}s @ {sample_rate}Hz")

        # Initialize runtime
        print(f"  Loading model...")
        t_start = time.perf_counter()
        runtime = await AsyncBithuman.create(
            model_path=path,
            api_secret=api_key,
            batch_workers=workers,
        )
        await runtime.start()
        t_load = time.perf_counter() - t_start
        frame_size = runtime.get_frame_size()
        print(f"  Model loaded in {t_load:.1f}s (frame size: {frame_size})")

        # Stream audio in background
        async def stream_audio():
            chunk_size = sample_rate // 25
            for i in range(0, len(audio_int16), chunk_size):
                chunk = audio_int16[i : i + chunk_size]
                await runtime.push_audio(chunk.tobytes(), sample_rate, last_chunk=False)
            await runtime.flush()

        audio_task = asyncio.create_task(stream_audio())

        # Stream: generate → downscale → encode with PyAV (inline H.264)
        output_container = None
        video_stream = None
        audio_stream = None
        scale_factor = None
        frame_count = 0
        out_w, out_h = 0, 0
        enc_w, enc_h = 0, 0
        needs_pad = False
        expected_frames = int(audio_duration * 25)
        bar_width = 30

        # Collect audio chunks (runtime outputs 16kHz mono int16)
        audio_chunks_out = []

        def _progress(n, total, elapsed):
            pct = min(n / total, 1.0) if total > 0 else 0
            filled = int(bar_width * pct)
            bar = "\u2588" * filled + "\u2591" * (bar_width - filled)
            secs_done = n / 25.0
            fps = n / elapsed if elapsed > 0 else 0
            eta = (total - n) / fps if fps > 0 else 0
            print(f"\r  {bar} {pct*100:5.1f}%  {secs_done:.1f}/{audio_duration:.1f}s  {fps:.0f} FPS  ETA {eta:.0f}s  ", end="", flush=True)

        print(f"  Rendering {audio_duration:.1f}s of video...")
        t_render_start = time.perf_counter()

        async for frame in runtime.run():
            if frame.end_of_speech:
                break
            if frame.bgr_image is None:
                continue

            img = frame.rgb_image

            # Downscale if needed
            h, w = img.shape[:2]
            if scale_factor is None:
                long_side = max(h, w)
                if long_side > max_dim:
                    scale_factor = max_dim / long_side
                    out_w = int(w * scale_factor + 0.5)
                    out_h = int(h * scale_factor + 0.5)
                else:
                    scale_factor = 1.0
                    out_w, out_h = w, h
                # H.264 requires even dimensions
                enc_w = out_w if out_w % 2 == 0 else out_w + 1
                enc_h = out_h if out_h % 2 == 0 else out_h + 1
                needs_pad = (enc_w != out_w) or (enc_h != out_h)
            if scale_factor < 1.0:
                img = cv2.resize(img, (out_w, out_h), interpolation=cv2.INTER_AREA)

            # Lazy-init PyAV output container on first frame
            if output_container is None:
                output_container = av.open(output_path, "w")
                video_stream = output_container.add_stream("h264", rate=25)
                video_stream.width = enc_w
                video_stream.height = enc_h
                video_stream.pix_fmt = "yuv420p"
                video_stream.codec_context.thread_count = 4
                video_stream.options = {"preset": "veryfast", "crf": "18", "movflags": "+faststart"}
                audio_stream = output_container.add_stream("aac", rate=16000)
                audio_stream.layout = "mono"

            # Pad if needed
            if needs_pad:
                padded = np.zeros((enc_h, enc_w, 3), dtype=img.dtype)
                padded[:out_h, :out_w] = img
                img = padded

            # Encode video frame
            vf = av.VideoFrame.from_ndarray(img, format="rgb24")
            vf.pts = frame_count
            for pkt in video_stream.encode(vf):
                output_container.mux(pkt)

            # Collect audio
            if frame.audio_chunk is not None:
                audio_chunks_out.append(frame.audio_chunk.data)

            frame_count += 1
            _progress(frame_count, expected_frames, time.perf_counter() - t_render_start)

        t_render = time.perf_counter() - t_render_start
        await audio_task
        await runtime.stop()

        if frame_count == 0 or output_container is None:
            print("\n  ERROR: No frames generated.")
            if output_container:
                output_container.close()
            return 1

        # Flush video encoder
        for pkt in video_stream.encode():
            output_container.mux(pkt)

        # Encode audio
        if audio_chunks_out:
            audio_data = np.concatenate(audio_chunks_out)
            # PyAV expects float32 planar audio for AAC
            audio_f32 = audio_data.astype(np.float32) / 32768.0
            chunk_size = 1024  # AAC frame size
            for i in range(0, len(audio_f32), chunk_size):
                chunk = audio_f32[i:i + chunk_size]
                af = av.AudioFrame.from_ndarray(
                    chunk.reshape(1, -1), format="fltp", layout="mono"
                )
                af.sample_rate = 16000
                af.pts = i
                for pkt in audio_stream.encode(af):
                    output_container.mux(pkt)
            # Flush audio encoder
            for pkt in audio_stream.encode():
                output_container.mux(pkt)

        output_container.close()

        out_size = Path(output_path).stat().st_size / 1024 / 1024
        pipeline_fps = frame_count / t_render if t_render > 0 else 0

        # Raw generation FPS from producer thread instrumentation
        raw_gen_time = getattr(runtime, '_producer_gen_time', None)
        raw_frame_count = getattr(runtime, '_producer_frame_count', 0)
        raw_fps = raw_frame_count / raw_gen_time if raw_gen_time and raw_gen_time > 0 else 0

        raw_tag = f"  raw {raw_fps:.0f}" if raw_fps > 0 else ""
        print(f"\r  {chr(0x2588) * bar_width} 100.0%  Done! {frame_count} frames in {t_render:.1f}s ({pipeline_fps:.1f} FPS{raw_tag})  ")

        # Peak memory
        peak_rss_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        peak_rss_mb = peak_rss_kb / 1024

        # Summary
        t_total = time.perf_counter() - t_start
        video_duration = frame_count / 25.0

        print()
        print(f"  {'─' * 41}")
        print(f"  Result:")
        print(f"    Output:      {output_path} ({out_size:.1f} MB)")
        print(f"    Resolution:  {out_w}\u00d7{out_h}")
        print(f"    Duration:    {video_duration:.1f}s ({frame_count} frames @ 25 FPS)")
        if raw_fps > 0:
            print(f"    Raw FPS:     {raw_fps:.1f} (generation only)")
        print(f"    Pipeline:    {pipeline_fps:.1f} FPS (generate + encode)")
        print(f"    Peak memory: {peak_rss_mb:.0f} MB")
        print(f"    Total time:  {t_total:.1f}s (load {t_load:.1f}s + render {t_render:.1f}s)")
        print(f"  {'─' * 41}")
        return 0

    return asyncio.run(_render())


def cmd_stream(args: argparse.Namespace) -> int:
    """Start a live streaming server for an avatar model."""
    import asyncio

    from loguru import logger as _logger

    path = args.path
    port = args.port
    api_key = args.key or os.environ.get("BITHUMAN_API_KEY", "")

    if not api_key:
        print("  ERROR: API key required. Use --key or set BITHUMAN_API_KEY env var.")
        return 1

    if not Path(path).exists():
        print(f"  ERROR: Model not found: {path}")
        return 1

    _logger.remove()
    if args.verbose:
        _logger.add(sys.stderr, level="DEBUG")

    print(_branded_header())
    print(f"  Model:   {path}")
    print(f"  Port:    {port}")
    print(f"  Quality: JPEG q{args.quality}")
    print()
    print("  Loading model...")

    from .stream_server import StreamServer

    server = StreamServer(
        model_path=path,
        api_key=api_key,
        port=port,
        jpeg_quality=args.quality,
    )

    try:
        asyncio.run(server.run_async())
    except KeyboardInterrupt:
        print("\n  Stopped.")

    return 0


def cmd_speak(args: argparse.Namespace) -> int:
    """Send an audio file to a running stream server."""
    import json
    import urllib.error
    import urllib.request

    audio_path = args.audio_path
    port = args.port
    host = args.host

    if not Path(audio_path).exists():
        print(f"  ERROR: Audio file not found: {audio_path}")
        return 1

    url = f"http://{host}:{port}/speak"

    ext = Path(audio_path).suffix.lower()
    content_types = {
        ".wav": "audio/wav",
        ".mp3": "audio/mpeg",
        ".ogg": "audio/ogg",
        ".flac": "audio/flac",
        ".m4a": "audio/mp4",
    }
    content_type = content_types.get(ext, "application/octet-stream")

    with open(audio_path, "rb") as f:
        audio_data = f.read()

    file_kb = len(audio_data) / 1024
    print(f"  Sending {Path(audio_path).name} ({file_kb:.1f} KB) to {url}")

    try:
        req = urllib.request.Request(
            url,
            data=audio_data,
            headers={"Content-Type": content_type},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode())
            duration = result.get("duration_seconds", 0)
            print(f"  OK — {duration}s of audio queued for playback")
            return 0
    except urllib.error.URLError as e:
        print(f"  ERROR: Could not connect to server at {url}")
        print(f"  Is 'bithuman stream' running? ({e.reason})")
        return 1
    except Exception as e:
        print(f"  ERROR: {e}")
        return 1


def cmd_action(args: argparse.Namespace) -> int:
    """Trigger a video action on a running stream server."""
    import json
    import urllib.error
    import urllib.request

    action_name = args.action_name
    target_video = args.target_video
    port = args.port
    host = args.host

    url = f"http://{host}:{port}/action"

    body = {}
    if action_name:
        body["action"] = action_name
    if target_video:
        body["target_video"] = target_video

    if not body:
        print("  ERROR: Provide an action name or --target-video")
        return 1

    payload = json.dumps(body).encode("utf-8")

    parts = []
    if action_name:
        parts.append(f"action '{action_name}'")
    if target_video:
        parts.append(f"target_video '{target_video}'")
    print(f"  Sending {', '.join(parts)} to {url}")

    try:
        req = urllib.request.Request(
            url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode())
            if result.get("status") == "playing":
                print(f"  Playing now")
            else:
                print(f"  Response: {result}")
            return 0
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read().decode())
            msg = err.get("error", str(e))
            available = err.get("available")
            print(f"  ERROR: {msg}")
            if available:
                print(f"  Available videos: {', '.join(available)}")
        except Exception:
            print(f"  ERROR: {e}")
        return 1
    except urllib.error.URLError as e:
        print(f"  ERROR: Could not connect to server at {url}")
        print(f"  Is 'bithuman stream' running? ({e.reason})")
        return 1
    except Exception as e:
        print(f"  ERROR: {e}")
        return 1


def main() -> int:
    # Suppress noisy OpenMP deprecation warning from numpy/onnxruntime
    os.environ.setdefault("KMP_WARNINGS", "0")

    from bithuman._version import __version__

    parser = argparse.ArgumentParser(
        prog="bithuman",
        description="bithuman — Real-time avatar engine. Generate lip-synced video, stream live avatars, and manage .imx models.",
        epilog="Documentation: https://docs.bithuman.ai  |  Homepage: https://bithuman.ai",
    )
    parser.add_argument(
        "--version", action="version",
        version=f"bithuman {__version__}",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # convert subcommand
    convert_parser = subparsers.add_parser(
        "convert",
        help="Convert .imx model to optimized IMX v2 format (4x smaller, instant loading)",
    )
    convert_parser.add_argument("imx_path", help="Path to .imx model file (TAR format)")
    convert_parser.add_argument(
        "--output", "-o",
        help="Output .imx path (default: overwrite original)",
    )
    convert_parser.add_argument(
        "--quality", "-q",
        type=int, default=80,
        help="WebP compression quality 1-100 (default: 80)",
    )
    convert_parser.add_argument(
        "--max-resolution",
        type=int, default=1280,
        dest="max_resolution",
        help="Downscale videos exceeding this max dimension (default: 1280)",
    )

    # validate subcommand
    validate_parser = subparsers.add_parser(
        "validate",
        help="Validate IMX model(s) by testing if they load correctly",
    )
    validate_parser.add_argument(
        "path",
        help="Path to .imx file, agent directory, or parent directory",
    )
    validate_parser.add_argument(
        "--workers", "-w",
        type=int, default=4,
        help="Number of parallel workers (default: 4)",
    )

    # info subcommand
    info_parser = subparsers.add_parser(
        "info",
        help="Show model information (format, audio, videos, metadata)",
    )
    info_parser.add_argument("path", help="Path to .imx model file")

    # list-videos subcommand
    list_videos_parser = subparsers.add_parser(
        "list-videos",
        help="List all videos contained in a model",
    )
    list_videos_parser.add_argument("path", help="Path to .imx model file")

    # generate subcommand
    generate_parser = subparsers.add_parser(
        "generate",
        help="Generate lip-synced video from avatar model + audio file",
    )
    generate_parser.add_argument("path", help="Path to .imx model file")
    generate_parser.add_argument("--audio", "-a", required=True, help="Path to audio file (.wav, .mp3, etc.)")
    generate_parser.add_argument("--output", "-o", help="Output video path (default: output.mp4)")
    generate_parser.add_argument("--key", "-k", help="API key (default: BITHUMAN_API_KEY env var)")
    generate_parser.add_argument("--max-resolution", "-r", type=int, default=1280,
                                 help="Cap long side at this resolution (default: 1280)")
    generate_parser.add_argument("--workers", "-w", type=int, default=1,
                                 help="Parallel workers for batch processing (0 = auto, 1 = sequential)")
    generate_parser.add_argument("--verbose", "-v", action="store_true",
                                 help="Show debug/warning logs from the runtime")

    # stream subcommand
    stream_parser = subparsers.add_parser(
        "stream",
        help="Start a live avatar streaming server with browser preview",
    )
    stream_parser.add_argument("path", help="Path to .imx model file")
    stream_parser.add_argument("--port", "-p", type=int, default=3001,
                               help="HTTP server port (default: 3001)")
    stream_parser.add_argument("--key", "-k",
                               help="API key (default: BITHUMAN_API_KEY env var)")
    stream_parser.add_argument("--quality", "-q", type=int, default=80,
                               help="JPEG quality 1-100 (default: 80)")
    stream_parser.add_argument("--verbose", "-v", action="store_true",
                               help="Show debug/warning logs from the runtime")

    # speak subcommand
    speak_parser = subparsers.add_parser(
        "speak",
        help="Send an audio file to a running stream server",
    )
    speak_parser.add_argument("audio_path", help="Path to audio file (.wav, .mp3, etc.)")
    speak_parser.add_argument("--port", "-p", type=int, default=3001,
                              help="Server port (default: 3001)")
    speak_parser.add_argument("--host", default="localhost",
                              help="Server host (default: localhost)")

    # action subcommand
    action_parser = subparsers.add_parser(
        "action",
        help="Trigger a video action on a running stream server (e.g. wave, nod)",
    )
    action_parser.add_argument("action_name", nargs="?", help="Action video name to play (e.g. wave, nod)")
    action_parser.add_argument("--target-video", "-t", dest="target_video",
                               help="Switch to a different talking video")
    action_parser.add_argument("--port", "-p", type=int, default=3001,
                               help="Server port (default: 3001)")
    action_parser.add_argument("--host", default="localhost",
                               help="Server host (default: localhost)")

    # snapshot subcommand (hidden — internal use only)
    snapshot_parser = subparsers.add_parser("snapshot", help=argparse.SUPPRESS)
    snapshot_parser.add_argument("path", help="Path to .imx model file")
    snapshot_parser.add_argument("--video", "-v", required=True, help="Video name")
    snapshot_parser.add_argument("--frame", "-f", type=int, required=True, help="Source frame number (0-indexed)")
    snapshot_parser.add_argument("--output", "-o", help="Output file path")
    # Hide snapshot from help output
    for action in parser._subparsers._actions:
        if hasattr(action, "_choices_actions"):
            action._choices_actions = [a for a in action._choices_actions if a.dest != "snapshot"]
            visible = [k for k in action.choices if k != "snapshot"]
            action.metavar = "{" + ",".join(visible) + "}"

    args = parser.parse_args()

    if args.command == "convert":
        return cmd_convert(args)
    elif args.command == "validate":
        return cmd_validate(args)
    elif args.command == "info":
        return cmd_info(args)
    elif args.command == "list-videos":
        return cmd_list_videos(args)
    elif args.command == "snapshot":
        return cmd_snapshot(args)
    elif args.command == "generate":
        return cmd_generate(args)
    elif args.command == "stream":
        return cmd_stream(args)
    elif args.command == "speak":
        return cmd_speak(args)
    elif args.command == "action":
        return cmd_action(args)
    else:
        parser.print_help()
        return 1
