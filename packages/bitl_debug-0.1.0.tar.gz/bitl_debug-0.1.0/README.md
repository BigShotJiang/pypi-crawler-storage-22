# bitl-debug

> Debug utilities for Python with BitL Debug Bar integration.

[![PyPI version](https://img.shields.io/pypi/v/bitl-debug.svg)](https://pypi.org/project/bitl-debug/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

## Installation

```bash
pip install bitl-debug

# With Django support
pip install bitl-debug[django]

# With Flask support  
pip install bitl-debug[flask]
```

## Quick Start

```python
from bitl_debug import dump, dd

# Dump a value (continues execution)
dump({"user": "John", "age": 30})
dump(my_variable, "My Label")

# Dump and die (stops execution)
dd(suspicious_value)
```

## Features

### dump(value, label=None)

Send a value to BitL Debug Bar. Returns the value for chaining.

```python
from bitl_debug import dump

user = {"name": "John", "email": "john@example.com"}
dump(user, "Current User")

# Chain dumps
result = dump(calculate_something())
```

### dd(value, label=None)

Dump and die - sends a value and exits the process.

```python
from bitl_debug import dd

# Debug and stop here
dd(suspicious_value, "Check this!")

# Code below never runs
```

### log_error(error, label=None)

Log errors with full stack traces.

```python
from bitl_debug import log_error

try:
    risky_operation()
except Exception as e:
    log_error(e)
    # Handle error...
```

### log_query(sql, bindings=None, duration_ms=None)

Log database queries with timing.

```python
from bitl_debug import log_query

log_query("SELECT * FROM users WHERE id = %s", [1], 12.5)
```

## Django Integration

Add the middleware to your `settings.py`:

```python
MIDDLEWARE = [
    'bitl_debug.middleware.DjangoMiddleware',
    # ... other middleware
]
```

All requests will be automatically logged to BitL Debug Bar.

## Flask Integration

```python
from flask import Flask
from bitl_debug.middleware import flask_middleware

app = Flask(__name__)
flask_middleware(app)

@app.route('/')
def hello():
    return 'Hello World!'
```

## Configuration

```python
from bitl_debug import configure

configure(
    host="127.0.0.1",  # BitL debug server host
    port=8765,         # BitL debug server port
    enabled=True,      # Enable/disable debugging
)

# Disable in production
import os
configure(enabled=os.environ.get("DEBUG", "false").lower() == "true")
```

## Requirements

- Python 3.10+
- BitL app running with Debug Server enabled

## License

MIT
