"""BitL Debug - Debug utilities for Python with BitL Debug Bar integration."""

from .client import configure, is_enabled
from .dump import dump, dd, log_error, log_warning, log_query

__version__ = "0.1.0"
__all__ = [
    "dump",
    "dd", 
    "log_error",
    "log_warning",
    "log_query",
    "configure",
    "is_enabled",
]
