"""BitL debug client for sending data to the debug server."""

import json
import urllib.request
import urllib.error
from datetime import datetime
from typing import Any, Optional
import traceback
import inspect

_config = {
    "host": "127.0.0.1",
    "port": 8765,
    "enabled": True,
}


def configure(
    host: str = "127.0.0.1",
    port: int = 8765,
    enabled: bool = True,
) -> None:
    """Configure the BitL debug client.
    
    Args:
        host: BitL debug server host (default: 127.0.0.1)
        port: BitL debug server port (default: 8765)
        enabled: Enable/disable debugging (default: True)
    """
    _config["host"] = host
    _config["port"] = port
    _config["enabled"] = enabled


def is_enabled() -> bool:
    """Check if BitL debugging is enabled."""
    return _config["enabled"]


def get_caller_info() -> tuple[Optional[str], Optional[int]]:
    """Get the caller's file and line number."""
    # Skip: get_caller_info, send, dump/dd/log_*
    stack = inspect.stack()
    if len(stack) >= 4:
        frame = stack[3]
        return frame.filename, frame.lineno
    return None, None


def serialize(value: Any) -> Any:
    """Serialize a value for JSON encoding."""
    if value is None:
        return None
    
    if isinstance(value, (str, int, float, bool)):
        return value
    
    if isinstance(value, bytes):
        return {
            "__type": "bytes",
            "length": len(value),
            "preview": value[:100].hex(),
        }
    
    if isinstance(value, datetime):
        return {
            "__type": "datetime",
            "value": value.isoformat(),
        }
    
    if isinstance(value, Exception):
        return {
            "__type": "Exception",
            "name": type(value).__name__,
            "message": str(value),
            "traceback": traceback.format_exception(type(value), value, value.__traceback__),
        }
    
    if isinstance(value, (list, tuple)):
        return [serialize(item) for item in value]
    
    if isinstance(value, dict):
        return {str(k): serialize(v) for k, v in value.items()}
    
    if isinstance(value, set):
        return {
            "__type": "set",
            "values": [serialize(item) for item in value],
        }
    
    if hasattr(value, "__dict__"):
        return {
            "__type": type(value).__name__,
            **{k: serialize(v) for k, v in value.__dict__.items() if not k.startswith("_")},
        }
    
    return str(value)


def send(
    payload_type: str,
    content: Any,
    label: Optional[str] = None,
    file: Optional[str] = None,
    line: Optional[int] = None,
) -> None:
    """Send a payload to the BitL debug server."""
    if not _config["enabled"]:
        return
    
    if file is None or line is None:
        file, line = get_caller_info()
    
    payload = {
        "type": payload_type,
        "content": serialize(content),
        "label": label,
        "file": file,
        "line": line,
        "timestamp": datetime.now().isoformat(),
        "language": "python",
    }
    
    try:
        data = json.dumps(payload).encode("utf-8")
        url = f"http://{_config['host']}:{_config['port']}/dump"
        
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        
        with urllib.request.urlopen(req, timeout=1) as response:
            response.read()
    except (urllib.error.URLError, TimeoutError, OSError):
        # Silently ignore connection errors (BitL not running)
        pass
