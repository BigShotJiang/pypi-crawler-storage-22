"""Dump functions for BitL Debug."""

import sys
from typing import Any, Optional, List

from .client import send, get_caller_info


def dump(value: Any, label: Optional[str] = None) -> Any:
    """Dump a value to BitL Debug Bar.
    
    Args:
        value: The value to dump
        label: Optional label for the dump
        
    Returns:
        The original value (for chaining)
        
    Example:
        >>> dump({"user": "John", "age": 30})
        >>> dump(my_variable, "My Label")
        >>> result = dump(calculate_something())  # Chain
    """
    file, line = get_caller_info()
    send("dump", value, label=label, file=file, line=line)
    return value


def dd(value: Any, label: Optional[str] = None) -> None:
    """Dump a value and die (exit the process).
    
    Args:
        value: The value to dump
        label: Optional label for the dump
        
    Example:
        >>> dd(suspicious_value)  # Dumps and exits
    """
    file, line = get_caller_info()
    send("dump", value, label=label or "🛑 dd()", file=file, line=line)
    sys.exit(1)


def log_error(
    error: Exception,
    label: Optional[str] = None,
) -> None:
    """Log an error to BitL Debug Bar.
    
    Args:
        error: The exception to log
        label: Optional label (defaults to exception class name)
        
    Example:
        >>> try:
        ...     risky_operation()
        ... except Exception as e:
        ...     log_error(e)
    """
    file, line = get_caller_info()
    send(
        "error",
        error,
        label=label or type(error).__name__,
        file=file,
        line=line,
    )


def log_warning(message: str, context: Optional[Any] = None) -> None:
    """Log a warning to BitL Debug Bar.
    
    Args:
        message: Warning message
        context: Optional context data
    """
    file, line = get_caller_info()
    send(
        "warning",
        {"message": message, "context": context},
        file=file,
        line=line,
    )


def log_query(
    sql: str,
    bindings: Optional[List[Any]] = None,
    duration_ms: Optional[float] = None,
) -> None:
    """Log a database query to BitL Debug Bar.
    
    Args:
        sql: The SQL query string
        bindings: Query parameter bindings
        duration_ms: Query execution time in milliseconds
        
    Example:
        >>> log_query("SELECT * FROM users WHERE id = %s", [1], 12.5)
    """
    file, line = get_caller_info()
    send(
        "query",
        {
            "sql": sql,
            "bindings": bindings or [],
            "duration": duration_ms,
        },
        file=file,
        line=line,
    )
