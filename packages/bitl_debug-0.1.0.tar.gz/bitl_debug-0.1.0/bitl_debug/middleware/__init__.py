"""Middleware for web frameworks."""

try:
    from .django import BitLDebugMiddleware as DjangoMiddleware
except ImportError:
    DjangoMiddleware = None

try:
    from .flask import bitl_debug_middleware as flask_middleware
except ImportError:
    flask_middleware = None

__all__ = ["DjangoMiddleware", "flask_middleware"]
