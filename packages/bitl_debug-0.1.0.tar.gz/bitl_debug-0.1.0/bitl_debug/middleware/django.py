"""Django middleware for BitL Debug."""

import time
from typing import Callable

from ..client import send, is_enabled


class BitLDebugMiddleware:
    """Django middleware to log requests to BitL Debug Bar.
    
    Add to MIDDLEWARE in settings.py:
        MIDDLEWARE = [
            'bitl_debug.middleware.DjangoMiddleware',
            # ... other middleware
        ]
    """
    
    def __init__(self, get_response: Callable):
        self.get_response = get_response
    
    def __call__(self, request):
        if not is_enabled():
            return self.get_response(request)
        
        start_time = time.time()
        response = self.get_response(request)
        duration = (time.time() - start_time) * 1000  # ms
        
        send(
            "request",
            {
                "method": request.method,
                "path": request.path,
                "url": request.build_absolute_uri(),
                "status": response.status_code,
                "duration": round(duration, 2),
                "headers": self._sanitize_headers(dict(request.headers)),
                "query": dict(request.GET),
                "ip": self._get_client_ip(request),
            },
            label=f"{request.method} {request.path}",
        )
        
        return response
    
    def _sanitize_headers(self, headers: dict) -> dict:
        """Remove sensitive headers."""
        sensitive = {"authorization", "cookie", "x-api-key", "x-auth-token"}
        return {
            k: "[REDACTED]" if k.lower() in sensitive else v
            for k, v in headers.items()
        }
    
    def _get_client_ip(self, request) -> str:
        """Get client IP from request."""
        x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
        if x_forwarded_for:
            return x_forwarded_for.split(",")[0].strip()
        return request.META.get("REMOTE_ADDR", "")
