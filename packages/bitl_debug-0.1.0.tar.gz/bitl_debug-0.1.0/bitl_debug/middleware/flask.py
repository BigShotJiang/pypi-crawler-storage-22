"""Flask middleware for BitL Debug."""

import time
from functools import wraps

from ..client import send, is_enabled


def bitl_debug_middleware(app):
    """Flask middleware to log requests to BitL Debug Bar.
    
    Usage:
        from flask import Flask
        from bitl_debug.middleware import flask_middleware
        
        app = Flask(__name__)
        flask_middleware(app)
    """
    
    @app.before_request
    def before_request():
        from flask import g
        g.bitl_start_time = time.time()
    
    @app.after_request
    def after_request(response):
        if not is_enabled():
            return response
        
        from flask import request, g
        
        start_time = getattr(g, "bitl_start_time", None)
        duration = (time.time() - start_time) * 1000 if start_time else 0
        
        send(
            "request",
            {
                "method": request.method,
                "path": request.path,
                "url": request.url,
                "status": response.status_code,
                "duration": round(duration, 2),
                "headers": _sanitize_headers(dict(request.headers)),
                "query": dict(request.args),
                "ip": request.remote_addr,
            },
            label=f"{request.method} {request.path}",
        )
        
        return response
    
    return app


def _sanitize_headers(headers: dict) -> dict:
    """Remove sensitive headers."""
    sensitive = {"authorization", "cookie", "x-api-key", "x-auth-token"}
    return {
        k: "[REDACTED]" if k.lower() in sensitive else v
        for k, v in headers.items()
    }
