#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Branch command - view and switch branches across repos."""

import os
import re
import shutil
import subprocess
import sys
from typing import Dict, List, Optional, Set, Tuple

from ..core import (
    Colors,
    current_branch,
    current_head,
    fzf_available,
    get_fzf_color_args,
    get_fzf_preview_resize_bindings,
    load_defaults,
    repo_is_clean,
    save_defaults,
)
from .common import (
    collect_repos,
    repo_display_name,
    prompt_action,
    run_cmd,
    create_pull_branch,
    copy_to_clipboard,
)

def fzf_branch_repos(repos: List[str]) -> int:
    """Interactive fzf-based branch management. Returns exit code."""
    if not repos:
        print("No repos found.")
        return 1

    def get_branches(repo: str) -> List[str]:
        """Get list of local and remote branches for a repo."""
        try:
            # Get local branches
            local = subprocess.check_output(
                ["git", "-C", repo, "branch", "--format=%(refname:short)"],
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip().splitlines()

            # Get remote branches (strip origin/ prefix for display)
            remote = subprocess.check_output(
                ["git", "-C", repo, "branch", "-r", "--format=%(refname:short)"],
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip().splitlines()

            # Combine: local first, then remote (excluding HEAD)
            branches = local[:]
            for r in remote:
                if r.endswith("/HEAD"):
                    continue
                # Strip origin/ prefix if it matches a local branch
                short = r.replace("origin/", "", 1) if r.startswith("origin/") else r
                if short not in branches:
                    branches.append(r)  # Keep full name for remote-only

            return branches
        except subprocess.CalledProcessError:
            return []

    def checkout_branch(repo: str, target: str) -> Tuple[bool, str]:
        """Checkout a branch in a repo. Returns (success, message)."""
        if not repo_is_clean(repo):
            return False, "dirty (has uncommitted changes)"

        # Handle origin/branch format
        if target.startswith("origin/"):
            local_name = target[7:]  # Strip origin/
            # Check if local branch exists
            local_exists = subprocess.run(
                ["git", "-C", repo, "rev-parse", "--verify", local_name],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            ).returncode == 0
            if local_exists:
                target = local_name
            else:
                # Create tracking branch
                try:
                    subprocess.run(
                        ["git", "-C", repo, "checkout", "-b", local_name, "--track", target],
                        check=True,
                        capture_output=True,
                        text=True,
                    )
                    return True, f"created and switched to {local_name} (tracking {target})"
                except subprocess.CalledProcessError as e:
                    return False, e.stderr.strip() or "checkout failed"

        try:
            subprocess.run(
                ["git", "-C", repo, "checkout", target],
                check=True,
                capture_output=True,
                text=True,
            )
            return True, f"switched to {target}"
        except subprocess.CalledProcessError as e:
            return False, e.stderr.strip() or "checkout failed"

    def show_branch_picker(repo: str) -> Optional[str]:
        """Show fzf picker for branches. Returns selected branch or None."""
        display = repo_display_name(repo)
        current = current_branch(repo) or ""
        branches = get_branches(repo)

        if not branches:
            print(f"\n  No branches found in {display}")
            return None

        menu_lines = []
        for branch in branches:
            if branch == current:
                menu_lines.append(f"{branch}\t● {branch} (current)")
            elif branch.startswith("origin/"):
                menu_lines.append(f"{branch}\t  {branch} (remote)")
            else:
                menu_lines.append(f"{branch}\t  {branch}")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--no-info",
                    "--height", "~50%",
                    "--header", f"Switch {display} to: (←=back)",
                    "--prompt", "Branch: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                    "--bind", "esc:become(echo BACK)",
                    "--bind", "left:become(echo BACK)",
                    "--bind", "q:become(echo BACK)",
                ] + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return None

        if result.returncode != 0 or not result.stdout.strip():
            return None

        output = result.stdout.strip()
        if output == "BACK":
            return None

        # Extract branch name (first field)
        return output.split("\t")[0]

    def build_menu_lines() -> str:
        """Build fzf menu input with header as last line (appears at top in fzf)."""
        max_name_len = 20

        # First pass to get max name length
        for repo in repos:
            display = repo_display_name(repo)
            if len(display) > max_name_len:
                max_name_len = len(display)

        # Data lines
        data_lines = []
        for idx, repo in enumerate(repos, start=1):
            display = repo_display_name(repo)
            branch = current_branch(repo) or "(detached)"
            is_clean = repo_is_clean(repo)
            status = f"{Colors.green('[clean]')}" if is_clean else f"{Colors.red('[DIRTY]')}"
            line = f"{repo}\t{idx:<4} {display:<{max_name_len}} {branch:<20} {status}"
            data_lines.append(line)

        # Reverse so item N is first (appears at bottom), item 1 near end
        menu_lines = list(reversed(data_lines))

        # Column header as LAST line (appears at TOP in default fzf layout)
        header_line = f"HEADER\t{'#':<4} {'Name':<{max_name_len}} {'Branch':<20} Status"
        # Separator line under header (second-to-last, appears just below header)
        sep_len = 4 + 1 + max_name_len + 1 + 20 + 1 + 8  # rough width matching columns
        separator = f"SEPARATOR\t{'─' * sep_len}"
        menu_lines.append(separator)
        menu_lines.append(header_line)

        return "\n".join(menu_lines)

    header = "Enter/→=switch branch | B=switch all | q=quit"

    def switch_all_repos(target_branch: str) -> None:
        """Switch all repos to the same branch."""
        print()
        for repo in repos:
            display = repo_display_name(repo)
            current = current_branch(repo)
            if current == target_branch:
                print(f"  {display}: already on {target_branch}")
                continue
            success, msg = checkout_branch(repo, target_branch)
            if success:
                print(f"  {Colors.green(display)}: {msg}")
            else:
                print(f"  {display}: {Colors.red(msg)}")
        print()

    while True:
        menu_input = build_menu_lines()

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--no-info",
                    "--ansi",
                    "--height", "~50%",
                    "--header", header,
                    "--prompt", "Branch: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                    "--bind", "q:become(echo QUIT)",
                    "--bind", "B:become(echo BRANCH_ALL)",
                    "--bind", "right:accept",
                ] + get_fzf_color_args(),
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            print("fzf not found. Use CLI: bit branch <repo> <branch>")
            return 1

        if result.returncode != 0 or not result.stdout.strip():
            break

        output = result.stdout.strip()

        if output == "QUIT":
            break
        elif output == "BRANCH_ALL":
            # Prompt for branch name and switch all repos
            print()
            try:
                target_branch = input("Switch all repos to branch: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nCancelled.")
                continue
            if not target_branch:
                print("No branch specified.")
                continue
            switch_all_repos(target_branch)
            continue
        elif "\t" in output:
            # Enter/right was pressed - show branch picker (ignore header/separator lines)
            repo_path = output.split("\t")[0]
            if repo_path in ("HEADER", "SEPARATOR"):
                continue
            selected_branch = show_branch_picker(repo_path)
            if selected_branch:
                display = repo_display_name(repo_path)
                current = current_branch(repo_path)
                if selected_branch == current:
                    print(f"\n  {display}: already on {selected_branch}")
                else:
                    success, msg = checkout_branch(repo_path, selected_branch)
                    if success:
                        print(f"\n  {Colors.green(display)}: {msg}")
                    else:
                        print(f"\n  {display}: {Colors.red(msg)}")

    return 0



def run_branch(args) -> int:
    """View and switch branches across repos."""
    defaults = load_defaults(args.defaults_file)
    repos, _repo_sets = collect_repos(args.bblayers, defaults)

    def checkout_branch(repo: str, target: str) -> Tuple[bool, str]:
        """Checkout a branch in a repo. Returns (success, message)."""
        if not repo_is_clean(repo):
            return False, "dirty (has uncommitted changes)"

        # Check if branch exists locally
        local_exists = subprocess.run(
            ["git", "-C", repo, "rev-parse", "--verify", target],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0

        # Check if branch exists on origin
        remote_ref = f"origin/{target}"
        remote_exists = subprocess.run(
            ["git", "-C", repo, "rev-parse", "--verify", remote_ref],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0

        if not local_exists and not remote_exists:
            return False, f"branch '{target}' not found locally or on origin"

        try:
            subprocess.run(
                ["git", "-C", repo, "checkout", target],
                check=True,
                capture_output=True,
                text=True,
            )
            return True, f"switched to {target}"
        except subprocess.CalledProcessError as e:
            return False, e.stderr.strip() or "checkout failed"

    # Handle --all mode
    if args.all_repos:
        if not args.target_branch:
            print("Error: --all requires a branch name")
            print("Usage: bit branch --all <branch>")
            return 1

        print(f"Switching all repos to branch: {args.target_branch}\n")
        had_errors = False
        for repo in repos:
            display = repo_display_name(repo)
            success, msg = checkout_branch(repo, args.target_branch)
            if success:
                print(f"→ {Colors.green(display)}: {msg}")
            else:
                print(f"→ {display}: {Colors.red(msg)}")
                had_errors = True
        return 1 if had_errors else 0

    # If no repo specified, use fzf interactive interface
    if args.repo is None:
        return fzf_branch_repos(repos)

    # Find the target repo by index, display name, or path
    target_repo = None
    try:
        idx = int(args.repo)
        if 1 <= idx <= len(repos):
            target_repo = repos[idx - 1]
        else:
            print(f"Invalid index {idx}. Valid range: 1-{len(repos)}")
            return 1
    except ValueError:
        # Try matching by display name first
        for repo in repos:
            if repo_display_name(repo).lower() == args.repo.lower():
                target_repo = repo
                break
        # Then try as path
        if not target_repo and os.path.isdir(args.repo):
            target_repo = os.path.abspath(args.repo)
        # Finally try partial path match
        if not target_repo:
            for repo in repos:
                if args.repo in repo or repo.endswith(args.repo):
                    target_repo = repo
                    break

    if not target_repo:
        print(f"Repo not found: {args.repo}")
        return 1

    # If no branch specified, show current branch for this repo
    if args.target_branch is None:
        display = repo_display_name(target_repo)
        branch = current_branch(target_repo) or "(detached)"
        is_clean = repo_is_clean(target_repo)
        status = Colors.green("[clean]") if is_clean else Colors.red("[DIRTY]")
        print(f"Repo: {target_repo}")
        print(f"Display name: {display}")
        print(f"Branch: {Colors.bold(branch)} {status}")
        return 0

    # Switch to the specified branch
    display = repo_display_name(target_repo)
    success, msg = checkout_branch(target_repo, args.target_branch)
    if success:
        print(f"→ {Colors.green(display)}: {msg}")
        return 0
    else:
        print(f"→ {display}: {Colors.red(msg)}")
        return 1


# ------------------------ Prepare Export ------------------------


def get_local_commits(repo: str, branch: str) -> Tuple[List[Tuple[str, str]], Optional[str]]:
    """
    Get local commits between origin/<branch> and HEAD.
    Returns (list of (hash, subject) tuples in chronological order oldest-first, base_ref or None).
    """
    remote_ref = f"origin/{branch}"
    remote_exists = subprocess.run(
        ["git", "-C", repo, "rev-parse", "--verify", remote_ref],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode == 0

    if not remote_exists:
        return [], None

    try:
        # Get commits oldest-first (--reverse)
        output = subprocess.check_output(
            ["git", "-C", repo, "log", "--reverse", "--format=%H %s", f"{remote_ref}..HEAD"],
            text=True,
        )
    except subprocess.CalledProcessError:
        return [], remote_ref

    commits = []
    for line in output.strip().splitlines():
        if line:
            parts = line.split(" ", 1)
            if len(parts) == 2:
                commits.append((parts[0], parts[1]))
            elif len(parts) == 1:
                commits.append((parts[0], ""))

    return commits, remote_ref



def prompt_branch_name(prompt: str = "Branch name for PR (Enter to skip): ") -> Optional[str]:
    """Prompt user for branch name. Returns None if skipped."""
    try:
        name = input(prompt).strip()
        return name if name else None
    except (EOFError, KeyboardInterrupt):
        print()  # Newline after ^C
        return None



def fzf_multiselect_commits(
    repo: str,
    branch: str,
    commits: List[Tuple[str, str]],
    base_ref: str = "",
    header_text: str = "",
    skip_branch_prompt: bool = False,
) -> Optional[Tuple[List[str], str, bool]]:
    """
    Use fzf to multi-select commits for upstream grouping.
    Supports:
    - Tab: range selection (first Tab = start, second Tab = end, selects all between)
    - Space: toggle individual commits
    - b: request branch name prompt after selection
    Returns (selected_hashes in oldest-first order, action, branch_mode, want_backup) where action is:
    - "selected": User made selections
    - "skip": User chose to skip this repo
    - "skip_rest": User chose to skip all remaining repos
    - None if cancelled (Escape pressed)
    branch_mode is None, "create" (b key), or "replace" (B key)
    want_backup is True if user pressed '!' for backup
    """
    if not commits:
        return ([], "skip", None, False)

    display_name = repo_display_name(repo)

    # Get upstream commits for context (dimmed)
    upstream_commits = []
    if base_ref:
        upstream_commits = get_upstream_context_commits(repo, base_ref, count=3)

    # Build menu: upstream context -> separator -> local commits
    # fzf with --height reverses display, so input order = bottom-to-top display
    menu_lines = []

    # Upstream commits for context (will appear at bottom, dimmed)
    if upstream_commits:
        for hash_val, subject in reversed(upstream_commits):
            dimmed = Colors.dim(f"   {hash_val[:12]} {subject[:70]}")
            menu_lines.append(dimmed)

    # Separator
    menu_lines.append("────────────────────────────────────────")

    # Local commits in green (will appear at top after fzf reversal)
    for hash_val, subject in commits:
        green_line = Colors.green(f"   {hash_val[:12]} {subject[:70]}")
        menu_lines.append(green_line)

    # Menu options at very top
    menu_options = [
        f"►► Select ALL {len(commits)} commits for upstream",
        "►► Select NONE (skip this repo)",
        "── [S] Skip all remaining repos ──",
        "────────────────────────────────────────",
    ]

    menu_input = "\n".join(menu_options) + "\n" + "\n".join(menu_lines)

    header = f"Repo: {Colors.bold(display_name)}  Branch: {Colors.bold(branch)}\n"
    header += f"Local commits: {len(commits)}\n"
    if header_text:
        header += header_text + "\n"
    if skip_branch_prompt:
        header += "Space=range | Tab=single | !=backup | ?=preview | Enter=confirm"
    else:
        header += "Space=range | Tab=single | b/B=branch | !=backup | ?=preview | Enter"

    # Temp files for tracking fzf interactions
    range_file = f"/tmp/fzf_range_{os.getpid()}"
    branch_file = f"/tmp/fzf_branch_{os.getpid()}"
    backup_file = f"/tmp/fzf_backup_{os.getpid()}"
    if os.path.exists(range_file):
        os.remove(range_file)
    if os.path.exists(branch_file):
        os.remove(branch_file)
    if os.path.exists(backup_file):
        os.remove(backup_file)

    # Preview command to show commit details
    # {1} is the first field (hash), git show fails gracefully for non-commits
    preview_cmd = f'git -C {repo} show --stat --color=always {{1}} 2>/dev/null || echo "Select a commit to preview"'

    # Shell script to build combined prompt showing branch, backup, and range marker state
    prompt_script = (
        f'br=; bk=; rng=; '
        f'[ -f {branch_file} ] && {{ c=$(cat {branch_file}); [ "$c" = B ] && br="[+BRANCH]" || br="[+branch]"; }}; '
        f'[ -f {backup_file} ] && bk="[!backup]"; '
        f'[ -f {range_file} ] && {{ n=$(wc -l < {range_file}); [ "$n" -gt 0 ] && rng="[range:$n]"; }}; '
        f'echo "Select$br$bk$rng: "'
    )

    # Build fzf command arguments
    fzf_args = [
        "fzf",
        "--multi",
        "--no-sort",
        "--ansi",
        "--height", "~60%",
        "--header", header,
        "--prompt", "Select for upstream: ",
        "--marker", "> ",
        "--info", "inline",
        "--preview", preview_cmd,
        "--preview-window", "down,50%,hidden,wrap",
        "--bind", "?:toggle-preview",
        "--bind", "ctrl-d:preview-half-page-down",
        "--bind", "ctrl-u:preview-half-page-up",
        "--bind", "page-down:preview-page-down",
        "--bind", "page-up:preview-page-up",
        "--bind", "tab:toggle",
        "--bind", f"space:toggle+execute-silent(echo {{}} >> {range_file})+transform-prompt({prompt_script})+down",
        "--bind", "s:become(echo SKIP_THIS)",
        "--bind", "S:become(echo SKIP_REST)",
    ]

    # Add 'b'/'B' bindings to flag branch creation request (doesn't exit fzf)
    # 'b' = create branch (skip if exists), 'B' = replace existing branch
    if not skip_branch_prompt:
        fzf_args.extend([
            "--bind", f"b:execute-silent(echo b > {branch_file})+transform-prompt({prompt_script})",
            "--bind", f"B:execute-silent(echo B > {branch_file})+transform-prompt({prompt_script})",
        ])

    # Add '!' binding to toggle backup mode
    fzf_args.extend([
        "--bind", f"!:execute-silent(touch {backup_file})+transform-prompt({prompt_script})",
    ])

    # Add preview window resize bindings and theme colors
    fzf_args.extend(get_fzf_preview_resize_bindings())
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        if os.path.exists(range_file):
            os.remove(range_file)
        if os.path.exists(branch_file):
            os.remove(branch_file)
        if os.path.exists(backup_file):
            os.remove(backup_file)
        return None  # fzf not found

    # Read range markers if any
    range_markers = []
    if os.path.exists(range_file):
        with open(range_file) as f:
            range_markers = [line.strip() for line in f.readlines() if line.strip()]
        os.remove(range_file)

    # Check if user pressed 'b' or 'B' for branch creation
    # 'b' = create (skip if exists), 'B' = replace (delete if exists)
    branch_mode = None  # None, "create", or "replace"
    if os.path.exists(branch_file):
        with open(branch_file) as f:
            content = f.read().strip()
        os.remove(branch_file)
        if content == "B":
            branch_mode = "replace"
        elif content == "b":
            branch_mode = "create"

    # Check if user pressed '!' for backup
    want_backup = os.path.exists(backup_file)
    if os.path.exists(backup_file):
        os.remove(backup_file)

    if result.returncode != 0 or not result.stdout.strip():
        return None  # Cancelled with Escape

    selected_lines = result.stdout.strip().splitlines()

    # Check for special outputs from keybindings
    if len(selected_lines) == 1:
        line = selected_lines[0].strip()
        if line == "SKIP_THIS":
            return ([], "skip", branch_mode, want_backup)
        if line == "SKIP_REST":
            return ([], "skip_rest", branch_mode, want_backup)

    # Check for menu options
    for line in selected_lines:
        if "Select ALL" in line:
            return ([h for h, _ in commits], "selected", branch_mode, want_backup)
        if "Select NONE" in line or "skip this repo" in line.lower():
            return ([], "skip", branch_mode, want_backup)
        if "Skip all remaining" in line:
            return ([], "skip_rest", branch_mode, want_backup)

    # Extract selected commit hashes
    hash_set = {h[:12]: h for h, _ in commits}  # Map short hash to full hash
    # Also create index mapping for range calculation
    hash_to_idx = {h[:12]: i for i, (h, _) in enumerate(commits)}

    selected_hashes = set()

    # Process range markers (Tab presses) - fill in all commits between first and last
    if len(range_markers) >= 2:
        # Extract hashes from range markers
        range_hashes = []
        for marker in range_markers:
            parts = marker.strip().split(maxsplit=1)
            if parts and parts[0] in hash_set:
                range_hashes.append(parts[0])

        if len(range_hashes) >= 2:
            # Get indices of first and last range marker
            first_hash = range_hashes[0]
            last_hash = range_hashes[-1]
            if first_hash in hash_to_idx and last_hash in hash_to_idx:
                start_idx = hash_to_idx[first_hash]
                end_idx = hash_to_idx[last_hash]
                # Ensure start <= end
                if start_idx > end_idx:
                    start_idx, end_idx = end_idx, start_idx
                # Add all commits in range
                for i in range(start_idx, end_idx + 1):
                    selected_hashes.add(commits[i][0])

    # Process space-selected commits (from fzf output)
    for line in selected_lines:
        stripped = line.strip()
        if stripped.startswith("►") or stripped.startswith("─"):
            continue  # Skip menu items
        parts = stripped.split(maxsplit=1)
        if parts and parts[0] in hash_set:
            selected_hashes.add(hash_set[parts[0]])

    # Return in original (oldest-first) order
    selected_ordered = [h for h, _ in commits if h in selected_hashes]
    return (selected_ordered, "selected", branch_mode, want_backup)



def get_upstream_context_commits(repo: str, base_ref: str, count: int = 5) -> List[Tuple[str, str]]:
    """Get recent commits from upstream for context display."""
    try:
        output = subprocess.check_output(
            ["git", "-C", repo, "log", "--format=%H %s", f"-n{count}", base_ref],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        return []

    commits = []
    for line in output.strip().splitlines():
        if line:
            parts = line.split(" ", 1)
            if len(parts) == 2:
                commits.append((parts[0], parts[1]))
            elif len(parts) == 1:
                commits.append((parts[0], ""))
    return commits



def get_upstream_to_pull(repo: str, branch: str, count: int = 50) -> List[Tuple[str, str]]:
    """Get commits in origin/<branch> that are not in HEAD (commits to pull)."""
    remote_ref = f"origin/{branch}"
    try:
        output = subprocess.check_output(
            ["git", "-C", repo, "log", "--format=%H %s", f"-n{count}", f"HEAD..{remote_ref}"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        return []

    commits = []
    for line in output.strip().splitlines():
        if line:
            parts = line.split(" ", 1)
            if len(parts) == 2:
                commits.append((parts[0], parts[1]))
            elif len(parts) == 1:
                commits.append((parts[0], ""))
    return commits



def fzf_select_insertion_point(
    repo: str,
    branch: str,
    base_ref: str,
    remaining_commits: List[Tuple[str, str]],
    selected_commits: List[Tuple[str, str]] = None,
    current_branch_mode: Optional[str] = None,
) -> Tuple[Optional[str], Optional[str]]:
    """
    Use fzf to select insertion point for upstream commits.
    Shows a unified view: local commits (newest first), separator, upstream context.
    Selected commits are marked with ">>" prefix.
    Returns (insertion_point, branch_mode):
    - insertion_point: base_ref, a commit hash, or None if cancelled
    - branch_mode: None, "create", or "replace" (can be set/changed here with b/B)
    """
    display_name = repo_display_name(repo)
    selected_commits = selected_commits or []
    selected_set = {h for h, _ in selected_commits}
    num_selected = len(selected_commits)

    # Get upstream commits for context
    upstream_commits = get_upstream_context_commits(repo, base_ref)

    # Temp file for branch mode (may already have value from selection screen)
    branch_file = f"/tmp/fzf_branch_{os.getpid()}"
    if current_branch_mode:
        with open(branch_file, "w") as f:
            f.write("B" if current_branch_mode == "replace" else "b")

    # Build display for fzf
    # Show commits in the order they'll be AFTER reordering:
    # upstream context -> selected commits (>>) -> default/separator -> remaining local
    menu_lines = []

    # Upstream commits for context (dimmed)
    if upstream_commits:
        for hash_val, subject in reversed(upstream_commits):
            dimmed = Colors.dim(f"   {hash_val[:12]} {subject[:70]}")
            menu_lines.append(dimmed)

    # Selected commits (will be moved here after reorder) - in green
    for hash_val, subject in selected_commits:
        green_line = Colors.green(f">> {hash_val[:12]} {subject[:70]}")
        menu_lines.append(green_line)

    # Default insertion point and separator (the cut line)
    menu_lines.append(f"►► {base_ref} (default - insert here)")
    menu_lines.append("────────────────────────────────────────")

    # Remaining local commits (not selected)
    for hash_val, subject in remaining_commits:
        menu_lines.append(f"   {hash_val[:12]} {subject[:70]}")

    menu_input = "\n".join(menu_lines)

    # Position of default line: upstream + selected + 1 (1-indexed for fzf)
    num_upstream = len(upstream_commits) if upstream_commits else 0
    num_selected = len(selected_commits)
    default_line_pos = num_upstream + num_selected + 1

    # Shell script for dynamic prompt showing branch mode
    prompt_script = (
        f'br=; '
        f'[ -f {branch_file} ] && {{ c=$(cat {branch_file}); [ "$c" = B ] && br="[+BRANCH]" || br="[+branch]"; }}; '
        f'echo "Insert {num_selected}$br after: "'
    )

    # Build initial prompt based on current branch mode
    if current_branch_mode == "replace":
        initial_prompt = f"Insert {num_selected}[+BRANCH] after: "
    elif current_branch_mode == "create":
        initial_prompt = f"Insert {num_selected}[+branch] after: "
    else:
        initial_prompt = f"Insert {num_selected} after: "

    header = f"Repo: {Colors.bold(display_name)}  Branch: {Colors.bold(branch)}\n"
    header += f"Selected: {num_selected} commits (marked with >>)\n"
    header += "b=branch | B=replace branch | Select insertion point"

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-multi",
                "--no-sort",
                "--ansi",
                "--layout=reverse-list",
                "--height", "~50%",
                "--header", header,
                "--prompt", initial_prompt,
                "--sync",
                "--bind", f"load:pos({default_line_pos})",
                "--bind", f"b:execute-silent(echo b > {branch_file})+transform-prompt({prompt_script})",
                "--bind", f"B:execute-silent(echo B > {branch_file})+transform-prompt({prompt_script})",
            ] + get_fzf_color_args(),
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return base_ref, current_branch_mode  # Default if fzf not available

    # Read branch mode from file
    branch_mode = current_branch_mode
    if os.path.exists(branch_file):
        with open(branch_file) as f:
            content = f.read().strip()
        if content == "B":
            branch_mode = "replace"
        elif content == "b":
            branch_mode = "create"
        os.remove(branch_file)

    if result.returncode != 0 or not result.stdout.strip():
        return None, branch_mode  # Cancelled

    selected = result.stdout.strip()

    # Check if default was selected
    if base_ref in selected:
        return base_ref, branch_mode

    # Strip whitespace and ignore separator line
    selected = selected.strip()
    if selected.startswith("───"):
        return base_ref, branch_mode

    # Extract commit hash
    parts = selected.split(maxsplit=1)
    if parts:
        # Handle ">>" prefix for selected commits
        hash_part = parts[0].lstrip(">").strip()
        # Find full hash in remaining commits (local)
        for h, _ in remaining_commits:
            if h[:12] == hash_part:
                return h, branch_mode
        # Check selected commits too
        for h, _ in selected_commits:
            if h[:12] == hash_part:
                return h, branch_mode
        # If selected an upstream commit, treat as default
        for h, _ in upstream_commits:
            if h[:12] == hash_part:
                return base_ref, branch_mode

    return base_ref, branch_mode  # Fallback to default


# ------------------------ Browse Command ------------------------



