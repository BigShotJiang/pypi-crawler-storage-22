#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Recipe command - search and browse BitBake recipes."""

import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import urllib.error
import urllib.parse
from typing import Dict, List, Optional, Tuple

from ..core import Colors, fzf_available, get_fzf_color_args, get_fzf_preview_resize_bindings, load_defaults
from .common import (
    resolve_bblayers_path,
    resolve_base_and_layers,
    dedupe_preserve_order,
    layer_display_name,
    extract_layer_paths,
)
from .projects import get_preview_window_arg, get_recipe_use_bitbake_layers


# =============================================================================
# Cache Management
# =============================================================================

def _get_recipe_cache_dir() -> str:
    """Get path to recipe cache directory."""
    cache_dir = os.path.expanduser("~/.cache/bit")
    os.makedirs(cache_dir, exist_ok=True)
    return cache_dir


def _get_cache_hash(layer_paths: List[str]) -> str:
    """Generate cache hash from sorted layer paths."""
    sorted_paths = sorted(layer_paths)
    content = "\n".join(sorted_paths)
    return hashlib.md5(content.encode()).hexdigest()[:12]


def _load_recipe_cache(layer_paths: List[str]) -> Optional[List[dict]]:
    """Load recipe cache if valid (< 5 minutes old)."""
    cache_dir = _get_recipe_cache_dir()
    cache_hash = _get_cache_hash(layer_paths)
    cache_path = os.path.join(cache_dir, f"recipe-index-{cache_hash}.json")

    if not os.path.isfile(cache_path):
        return None

    try:
        cache_age = time.time() - os.path.getmtime(cache_path)
        if cache_age > 300:  # 5 minutes TTL
            return None

        with open(cache_path, "r") as f:
            data = json.load(f)
            return data.get("recipes")
    except (json.JSONDecodeError, OSError, KeyError):
        return None


def _save_recipe_cache(layer_paths: List[str], recipes: List[dict]) -> None:
    """Save recipe cache."""
    cache_dir = _get_recipe_cache_dir()
    cache_hash = _get_cache_hash(layer_paths)
    cache_path = os.path.join(cache_dir, f"recipe-index-{cache_hash}.json")

    try:
        with open(cache_path, "w") as f:
            json.dump({
                "timestamp": time.time(),
                "recipes": recipes,
            }, f)
    except OSError:
        pass


# =============================================================================
# Recipe Metadata Parsing
# =============================================================================

def _parse_recipe_metadata(filepath: str) -> dict:
    """
    Extract metadata from a .bb recipe file using regex.

    Returns dict with:
    - SUMMARY, DESCRIPTION, LICENSE, HOMEPAGE, SECTION, DEPENDS
    """
    metadata = {
        "SUMMARY": "",
        "DESCRIPTION": "",
        "LICENSE": "",
        "HOMEPAGE": "",
        "SECTION": "",
        "DEPENDS": "",
    }

    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except (OSError, IOError):
        return metadata

    # Parse each variable
    for var in metadata.keys():
        # Match VAR = "value" or VAR = 'value'
        # Also handle ?= and ??= but prefer =
        patterns = [
            rf'^{var}\s*=\s*"([^"]*)"',
            rf"^{var}\s*=\s*'([^']*)'",
            rf'^{var}\s*\?=\s*"([^"]*)"',
            rf"^{var}\s*\?=\s*'([^']*)'",
        ]

        for pattern in patterns:
            match = re.search(pattern, content, re.MULTILINE)
            if match:
                metadata[var] = match.group(1).strip()
                break

    return metadata


def _extract_pn_pv(filename: str) -> Tuple[str, str]:
    """
    Extract PN (recipe name) and PV (version) from filename.

    Handles:
    - recipe_version.bb -> (recipe, version)
    - recipe.bb -> (recipe, "")
    - recipe-name_1.2.3.bb -> (recipe-name, 1.2.3)
    - recipe_%.bbappend -> (recipe, %) for version-wildcard appends
    - recipe.bbappend -> (recipe, "")
    """
    # Remove .bb or .bbappend extension
    if filename.endswith(".bbappend"):
        basename = filename[:-9]
    elif filename.endswith(".bb"):
        basename = filename[:-3]
    else:
        basename = filename

    # Split on underscore for version
    if "_" in basename:
        parts = basename.rsplit("_", 1)
        pn = parts[0]
        pv = parts[1] if len(parts) > 1 else ""
    else:
        pn = basename
        pv = ""

    return pn, pv


# =============================================================================
# Recipe Scanning
# =============================================================================

def _scan_recipes_from_layers(
    layer_paths: List[str],
    force: bool = False,
    progress: bool = True,
) -> List[dict]:
    """
    Scan layers for recipes using file glob.

    Returns list of recipe dicts with:
    - pn, pv, path, layer, layer_name
    - SUMMARY, DESCRIPTION, LICENSE, HOMEPAGE, SECTION, DEPENDS
    """
    if not force:
        cached = _load_recipe_cache(layer_paths)
        if cached is not None:
            return cached

    recipes = []
    seen_recipes = set()  # Track (pn, layer) to avoid duplicates

    if progress:
        print(Colors.dim("Scanning recipes..."), end=" ", flush=True)

    total_layers = len(layer_paths)

    for idx, layer_path in enumerate(layer_paths):
        layer_name = layer_display_name(layer_path)

        # Glob for recipes: recipes-*/*/*.bb and recipes-*/*/*.bbappend
        pattern = os.path.join(layer_path, "recipes-*", "*", "*.bb")
        bb_files = glob.glob(pattern)

        # Also check for recipes directly in recipes-*/*.bb (less common)
        pattern2 = os.path.join(layer_path, "recipes-*", "*.bb")
        bb_files.extend(glob.glob(pattern2))

        # Also glob for bbappend files
        pattern_append = os.path.join(layer_path, "recipes-*", "*", "*.bbappend")
        bb_files.extend(glob.glob(pattern_append))
        pattern_append2 = os.path.join(layer_path, "recipes-*", "*.bbappend")
        bb_files.extend(glob.glob(pattern_append2))

        for bb_path in bb_files:
            filename = os.path.basename(bb_path)

            # Determine if this is a recipe or append
            is_append = filename.endswith(".bbappend")

            pn, pv = _extract_pn_pv(filename)

            # Track unique entries per layer (separate tracking for recipes vs appends)
            entry_type = "append" if is_append else "recipe"
            key = (pn, layer_path, entry_type)
            if key in seen_recipes:
                continue
            seen_recipes.add(key)

            # Parse metadata
            metadata = _parse_recipe_metadata(bb_path)

            recipes.append({
                "pn": pn,
                "pv": pv,
                "path": bb_path,
                "layer": layer_path,
                "layer_name": layer_name,
                "type": entry_type,
                **metadata,
            })

    if progress:
        print(Colors.dim(f"{len(recipes)} recipes found"))

    # Save to cache
    _save_recipe_cache(layer_paths, recipes)

    return recipes


def _scan_configured_recipes(
    bblayers_path: str,
    force: bool = False,
    use_bitbake_layers: bool = True,
) -> Tuple[List[dict], List[str]]:
    """
    Get recipes from configured layers.

    First tries bitbake-layers show-recipes if available and use_bitbake_layers is True,
    then falls back to file scan.

    Args:
        bblayers_path: Path to bblayers.conf
        force: Force cache rebuild
        use_bitbake_layers: If True, try bitbake-layers first (default True)

    Returns (recipes, layer_paths).
    """
    # Get configured layer paths
    try:
        from .common import extract_layer_paths
        layer_paths = extract_layer_paths(bblayers_path)
    except SystemExit:
        return [], []

    # Try bitbake-layers if available and enabled (more accurate, includes bbappends)
    if use_bitbake_layers and shutil.which("bitbake-layers") and not force:
        recipes = _try_bitbake_layers_recipes()
        if recipes:
            return recipes, layer_paths

    # Fall back to file scan
    recipes = _scan_recipes_from_layers(layer_paths, force=force)
    return recipes, layer_paths


def _try_bitbake_layers_recipes() -> Optional[List[dict]]:
    """
    Try to get recipes via bitbake-layers show-recipes.

    Returns list of recipe dicts or None if unavailable/failed.
    """
    try:
        result = subprocess.run(
            ["bitbake-layers", "show-recipes", "-f"],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            return None

        # Parse output - format is:
        # recipe-name:
        #   layer-name version
        recipes = []
        current_pn = None
        for line in result.stdout.splitlines():
            line = line.rstrip()
            if not line:
                continue
            if line.endswith(":") and not line.startswith(" "):
                current_pn = line[:-1].strip()
            elif line.startswith("  ") and current_pn:
                # Parse "  layer-name version"
                parts = line.strip().split()
                if len(parts) >= 2:
                    layer_name = parts[0]
                    pv = parts[1]
                    recipes.append({
                        "pn": current_pn,
                        "pv": pv,
                        "path": "",  # bitbake-layers doesn't give path
                        "layer": "",
                        "layer_name": layer_name,
                        "SUMMARY": "",
                        "DESCRIPTION": "",
                        "LICENSE": "",
                        "HOMEPAGE": "",
                        "SECTION": "",
                        "DEPENDS": "",
                    })

        return recipes if recipes else None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


# =============================================================================
# Layer Index API
# =============================================================================

def _get_recipe_index_cache_path(branch: str) -> str:
    """Get path to recipe index API cache file."""
    cache_dir = _get_recipe_cache_dir()
    return os.path.join(cache_dir, f"recipe-api-{branch}.json")


def _fetch_recipe_index(branch: str = "master", force: bool = False, search: str = "") -> Optional[List[dict]]:
    """
    Fetch recipes from layers.openembedded.org API.

    Args:
        branch: Branch to filter by (default: master)
        force: Force refresh, ignore cache
        search: Optional search query (sent to API for server-side filtering)

    Returns list of recipe dicts or None on error.
    """
    # Only use cache for full fetches (no search query)
    cache_path = _get_recipe_index_cache_path(branch)
    cache_max_age = 2 * 60 * 60  # 2 hours

    if not search and not force and os.path.isfile(cache_path):
        try:
            cache_age = time.time() - os.path.getmtime(cache_path)
            if cache_age < cache_max_age:
                with open(cache_path, "r") as f:
                    data = json.load(f)
                    return data.get("recipes")
        except (json.JSONDecodeError, OSError, KeyError):
            pass

    # Fetch from API
    # The recipes endpoint is paginated, we need to fetch all pages
    api_base = "https://layers.openembedded.org/layerindex/api/recipes/"
    all_recipes = []

    # Build URL with optional search parameter
    if search:
        encoded_search = urllib.parse.quote(search)
        next_url = f"{api_base}?format=json&search={encoded_search}"
        print(Colors.dim(f"Searching index for '{search}'..."), end=" ", flush=True)
    else:
        next_url = f"{api_base}?format=json"
        print(Colors.dim("Fetching recipe index..."), end=" ", flush=True)

    try:
        page = 0
        while next_url and page < 50:  # Safety limit
            page += 1
            with urllib.request.urlopen(next_url, timeout=30) as resp:
                data = json.loads(resp.read().decode())

            # API may return paginated results
            if isinstance(data, list):
                all_recipes.extend(data)
                next_url = None
            elif isinstance(data, dict):
                results = data.get("results", data.get("objects", []))
                all_recipes.extend(results)
                next_url = data.get("next")
            else:
                break

        print(Colors.dim(f"{len(all_recipes)} recipes"))

        # Transform to our format
        recipes = []
        for entry in all_recipes:
            # Get branch info - filter by branch
            lb = entry.get("layerbranch", {})
            branch_info = lb.get("branch", {}) if isinstance(lb, dict) else {}
            entry_branch = branch_info.get("name", "") if isinstance(branch_info, dict) else ""

            # The API structure varies - adapt as needed
            pn = entry.get("pn", entry.get("name", ""))
            pv = entry.get("pv", "")
            summary = entry.get("summary", "")
            description = entry.get("description", "")
            section = entry.get("section", "")
            license_val = entry.get("license", "")
            homepage = entry.get("homepage", "")

            # Get layer name from layerbranch
            layer_name = ""
            if isinstance(lb, dict):
                layer_info = lb.get("layer", {})
                if isinstance(layer_info, dict):
                    layer_name = layer_info.get("name", "")

            if pn:
                recipes.append({
                    "pn": pn,
                    "pv": pv,
                    "path": "",  # Remote, no local path
                    "layer": "",
                    "layer_name": layer_name,
                    "SUMMARY": summary,
                    "DESCRIPTION": description,
                    "LICENSE": license_val,
                    "HOMEPAGE": homepage,
                    "SECTION": section,
                    "DEPENDS": "",
                    "source": "index",
                    "branch": entry_branch,
                })

        # Save to cache
        try:
            with open(cache_path, "w") as f:
                json.dump({"timestamp": time.time(), "recipes": recipes}, f)
        except OSError:
            pass

        return recipes

    except urllib.error.URLError as e:
        print(Colors.dim("failed"))
        # Try stale cache
        if os.path.isfile(cache_path):
            try:
                with open(cache_path, "r") as f:
                    data = json.load(f)
                    if data.get("recipes"):
                        print(Colors.yellow(f"Using cached data (network error)"))
                        return data["recipes"]
            except (json.JSONDecodeError, OSError, KeyError):
                pass
        print(f"Error fetching recipe index: {e}")
        return None
    except json.JSONDecodeError as e:
        print(Colors.dim("failed"))
        print(f"Error parsing response: {e}")
        return None


# =============================================================================
# FZF Browser
# =============================================================================

def _build_recipe_menu(
    recipes: List[dict],
    source_name: str,
) -> str:
    """Build fzf menu input for recipe list."""
    if not recipes:
        return ""

    # Separate recipes from appends
    regular_recipes = [r for r in recipes if r.get("type") != "append"]
    append_recipes = [r for r in recipes if r.get("type") == "append"]

    # Calculate column widths across all entries
    all_recipes = regular_recipes + append_recipes
    max_pn_len = max(len(r["pn"]) for r in all_recipes) if all_recipes else 20
    max_pn_len = min(max_pn_len, 30)
    max_pv_len = max(len(r.get("pv", "")) for r in all_recipes) if all_recipes else 10
    max_pv_len = min(max_pv_len, 15)
    max_layer_len = max(len(r.get("layer_name", "")) for r in all_recipes) if all_recipes else 15
    max_layer_len = min(max_layer_len, 20)

    menu_lines = []

    def format_recipe(recipe, is_append=False):
        pn = recipe["pn"][:30]
        pv = recipe.get("pv", "")[:15]
        layer_name = recipe.get("layer_name", "")[:20]
        summary = recipe.get("SUMMARY", "")[:50]
        path = recipe.get("path", "")

        # Color based on type and source
        is_remote = recipe.get("source") == "index"
        if is_append:
            # Appends shown in yellow/magenta
            colored_pn = Colors.yellow(f"{pn:<{max_pn_len}}")
            type_marker = Colors.dim("(append)")
        elif is_remote:
            colored_pn = Colors.cyan(f"{pn:<{max_pn_len}}")
            type_marker = ""
        else:
            colored_pn = Colors.green(f"{pn:<{max_pn_len}}")
            type_marker = ""

        if type_marker:
            line = f"{path}\t{colored_pn}  {pv:<{max_pv_len}}  {layer_name:<{max_layer_len}}  {type_marker} {summary}"
        else:
            line = f"{path}\t{colored_pn}  {pv:<{max_pv_len}}  {layer_name:<{max_layer_len}}  {summary}"
        return line

    # Add regular recipes first
    for recipe in regular_recipes:
        menu_lines.append(format_recipe(recipe, is_append=False))

    # Add separator if we have both types
    if regular_recipes and append_recipes:
        # fzf separator line (non-selectable)
        menu_lines.append(f"---\t{Colors.dim('── Appends (' + str(len(append_recipes)) + ') ──')}")

    # Add appends
    for recipe in append_recipes:
        menu_lines.append(format_recipe(recipe, is_append=True))

    return "\n".join(menu_lines)


def _build_recipe_preview(recipe: dict) -> str:
    """Build preview content for a recipe."""
    lines = []

    pn = recipe.get("pn", "")
    pv = recipe.get("pv", "")
    layer_name = recipe.get("layer_name", "")
    path = recipe.get("path", "")

    lines.append(f"{Colors.bold(pn)}")
    if pv:
        lines.append(f"Version: {pv}")
    lines.append(f"Layer: {layer_name}")
    if path:
        lines.append(f"Path: {path}")
    lines.append("")

    summary = recipe.get("SUMMARY", "")
    if summary:
        lines.append(f"{Colors.cyan('Summary:')}")
        lines.append(f"  {summary}")
        lines.append("")

    description = recipe.get("DESCRIPTION", "")
    if description:
        lines.append(f"{Colors.cyan('Description:')}")
        # Word wrap
        for line in description.split("\n"):
            lines.append(f"  {line}")
        lines.append("")

    license_val = recipe.get("LICENSE", "")
    if license_val:
        lines.append(f"{Colors.cyan('License:')} {license_val}")

    homepage = recipe.get("HOMEPAGE", "")
    if homepage:
        lines.append(f"{Colors.cyan('Homepage:')} {homepage}")

    section = recipe.get("SECTION", "")
    if section:
        lines.append(f"{Colors.cyan('Section:')} {section}")

    depends = recipe.get("DEPENDS", "")
    if depends:
        lines.append(f"{Colors.cyan('Depends:')} {depends}")

    return "\n".join(lines)


def _recipe_fzf_browser(
    recipes: List[dict],
    source_name: str,
    query: str = "",
    allow_source_switch: bool = True,
    is_remote: bool = False,
    available_sources: List[str] = None,
):
    """
    Interactive fzf browser for recipes.

    Key bindings:
    - Enter: View recipe in $EDITOR or less
    - ctrl-e: Edit recipe in $EDITOR (disabled for remote)
    - alt-c: Copy path to clipboard
    - ctrl-f: Show full file in preview
    - ctrl-i: Show metadata info in preview
    - alt-s: Cycle through sources (Configured → Local → Index)
    - left: Go back to source selection menu
    - pgup/pgdn: Scroll preview
    - ?: Toggle preview
    - esc: Quit

    Returns:
    - 0: Normal exit
    - 1: Error
    - "menu": Go back to source selection menu
    - ("switch", source): Switch to specified source
    """
    if not recipes:
        print("No recipes found.")
        return 1

    if not fzf_available():
        # Fall back to text list
        for recipe in recipes:
            pn = recipe.get("pn", "")
            pv = recipe.get("pv", "")
            layer_name = recipe.get("layer_name", "")
            print(f"  {Colors.green(pn):<30}  {pv:<15}  {layer_name}")
        return 0

    # Build menu
    menu_input = _build_recipe_menu(recipes, source_name)

    # Build preview script
    # We'll use temp files - one for data, one for the preview script
    import tempfile
    preview_data = {r.get("path", r.get("pn", "")): r for r in recipes}
    preview_data_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
    json.dump(preview_data, preview_data_file)
    preview_data_file.close()

    # Create a preview script file to avoid shell escaping issues
    preview_script = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
    preview_script.write(f'''#!/usr/bin/env python3
import json
import sys

key = sys.argv[1] if len(sys.argv) > 1 else ""
# Strip any surrounding quotes that fzf might add
key = key.strip("'\\\"")
with open("{preview_data_file.name}", "r") as f:
    data = json.load(f)

recipe = data.get(key, {{}})
if not recipe:
    print(f"No data for: {{key}}")
    sys.exit(0)

pn = recipe.get("pn", "")
pv = recipe.get("pv", "")
layer_name = recipe.get("layer_name", "")
path = recipe.get("path", "")
summary = recipe.get("SUMMARY", "")
description = recipe.get("DESCRIPTION", "")
license_val = recipe.get("LICENSE", "")
homepage = recipe.get("HOMEPAGE", "")
section = recipe.get("SECTION", "")
depends = recipe.get("DEPENDS", "")

print(f"\\033[1m{{pn}}\\033[0m")
if pv:
    print(f"Version: {{pv}}")
print(f"Layer: {{layer_name}}")
if path:
    print(f"Path: {{path}}")
print()
if summary:
    print("\\033[36mSummary:\\033[0m")
    print(f"  {{summary}}")
    print()
if description:
    print("\\033[36mDescription:\\033[0m")
    for line in description.split("\\n"):
        print(f"  {{line}}")
    print()
if license_val:
    print(f"\\033[36mLicense:\\033[0m {{license_val}}")
if homepage:
    print(f"\\033[36mHomepage:\\033[0m {{homepage}}")
if section:
    print(f"\\033[36mSection:\\033[0m {{section}}")
if depends:
    print(f"\\033[36mDepends:\\033[0m {{depends}}")
''')
    preview_script.close()

    # Preview commands - metadata view and full file view
    # Note: fzf's {1} is already shell-quoted, don't add extra quotes
    preview_metadata = f'python3 "{preview_script.name}" {{1}}'
    # For file preview, check if file exists (remote recipes won't have local path)
    preview_file = 'if [ -f {1} ]; then cat {1}; else echo "Remote recipe - no local file available"; echo ""; echo "Path: {1}"; fi'

    # Build header - three lines to fit all keybindings (use ctrl/alt so typing works)
    header_line1 = f"[{source_name}] Type to filter"
    header_line2 = "Enter=view | "
    if not is_remote:
        header_line2 += "ctrl-e=edit | "
    header_line2 += "alt-c=copy | alt-d=deps | ctrl-f=file | ctrl-i=info"
    header_line3 = "alt-s=switch source | ←=back | pgup/pgdn=scroll | esc=quit"
    header = f"{header_line1}\n{header_line2}\n{header_line3}"

    # Determine expected keys (use modifiers so typing works)
    expect_keys = ["ctrl-e", "alt-c", "alt-d", "esc", "left", "alt-s"]

    preview_window = get_preview_window_arg("50%")

    fzf_args = [
        "fzf",
        "--no-multi",
        "--ansi",
        "--height", "100%",
        "--layout=reverse-list",  # Prompt at bottom, A-Z top to bottom, first item selected
        "--no-hscroll",  # Keep recipe name visible, don't scroll to match
        "--header", header,
        "--prompt", f"Recipe ({source_name}): ",
        "--with-nth", "2..",
        "--delimiter", "\t",
        "--preview", preview_metadata,
        "--preview-window", preview_window,
        "--bind", "?:toggle-preview",
        "--bind", f"ctrl-f:change-preview({preview_file})",
        "--bind", f"ctrl-i:change-preview({preview_metadata})",
        "--bind", "pgup:preview-page-up",
        "--bind", "pgdn:preview-page-down",
        "--bind", "esc:abort",
        "--expect", ",".join(expect_keys),
    ]

    # Add initial query if provided
    if query:
        fzf_args.extend(["--query", query])

    fzf_args.extend(get_fzf_preview_resize_bindings())
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return 1
    finally:
        # Clean up temp files
        for f in [preview_data_file.name, preview_script.name]:
            try:
                os.unlink(f)
            except OSError:
                pass

    if result.returncode != 0 or not result.stdout.strip():
        return 0

    # Parse output
    lines = result.stdout.split("\n")
    key = lines[0].strip() if lines else ""
    selected = lines[1].split("\t")[0].strip() if len(lines) > 1 else ""

    if not selected:
        return 0

    # Find the selected recipe
    recipe = None
    for r in recipes:
        if r.get("path") == selected or r.get("pn") == selected:
            recipe = r
            break

    if not recipe:
        return 0

    # Handle actions (modifier keys so typing works)
    if key == "alt-c":
        # Copy path to clipboard
        path = recipe.get("path", recipe.get("pn", ""))
        if path:
            _copy_to_clipboard(path)
            print(f"Copied: {path}")
        return _recipe_fzf_browser(recipes, source_name, query, allow_source_switch, is_remote, available_sources)

    if key == "ctrl-e" and not is_remote:
        # Edit in $EDITOR
        path = recipe.get("path", "")
        if path and os.path.isfile(path):
            editor = os.environ.get("EDITOR", "vi")
            subprocess.run([editor, path])
        return _recipe_fzf_browser(recipes, source_name, query, allow_source_switch, is_remote, available_sources)

    if key == "alt-d" and not is_remote:
        # Show recipe dependencies
        path = recipe.get("path", "")
        pn = recipe.get("pn", "")
        if path and os.path.isfile(path):
            from .deps import _parse_recipe_depends, _render_recipe_tree_ascii, RecipeInfo
            depends, rdepends = _parse_recipe_depends(path)
            layer_name = recipe.get("layer_name", os.path.basename(os.path.dirname(os.path.dirname(os.path.dirname(path)))))
            recipe_info = RecipeInfo(
                name=pn,
                version=recipe.get("pv", ""),
                path=path,
                layer=layer_name,
                depends=depends,
                rdepends=rdepends,
            )
            print(f"\n{_render_recipe_tree_ascii(recipe_info, include_rdepends=True)}\n")
            input("Press Enter to continue...")
        return _recipe_fzf_browser(recipes, source_name, query, allow_source_switch, is_remote, available_sources)

    if key == "esc":
        return 0

    if key == "left":
        # Go back to menu
        return "menu"

    if key == "alt-s":
        # Cycle to next source
        if available_sources and len(available_sources) > 1:
            # Map display names to source keys
            source_key_map = {
                "Configured": "configured",
                "Local": "local",
                "Index": "index",
            }
            # Find current source key - handle combined names like "Configured+Local"
            current_key = None
            source_name_lower = source_name.lower()
            for display, key_name in source_key_map.items():
                if source_name == display or source_name_lower == key_name:
                    current_key = key_name
                    break

            # If source_name is combined (e.g., "Configured+Local"), use first available as current
            if current_key is None and "+" in source_name:
                # Take the first part
                first_part = source_name.split("+")[0]
                current_key = source_key_map.get(first_part, first_part.lower())

            if current_key and current_key in available_sources:
                idx = available_sources.index(current_key)
                next_idx = (idx + 1) % len(available_sources)
                next_source = available_sources[next_idx]
                return ("switch", next_source)
            elif available_sources:
                # Just pick the first available source if current not found
                return ("switch", available_sources[0])
        # Fall back to menu if can't cycle
        return "menu"

    # Enter - view recipe
    path = recipe.get("path", "")
    if path and os.path.isfile(path):
        # Use $EDITOR if set, otherwise less
        pager = os.environ.get("PAGER", "less")
        subprocess.run([pager, path])
    else:
        # Remote recipe - show preview
        preview = _build_recipe_preview(recipe)
        pager = os.environ.get("PAGER", "less")
        subprocess.run([pager], input=preview, text=True)

    return _recipe_fzf_browser(recipes, source_name, query, allow_source_switch, is_remote, available_sources)


def _copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard."""
    clipboard_cmds = [
        ["xclip", "-selection", "clipboard"],
        ["xsel", "--clipboard", "--input"],
        ["pbcopy"],
    ]

    for cmd in clipboard_cmds:
        if shutil.which(cmd[0]):
            try:
                subprocess.run(cmd, input=text, text=True, check=True)
                return True
            except subprocess.CalledProcessError:
                continue
    return False


# =============================================================================
# Source Selection Menu
# =============================================================================

def _source_selection_menu(has_local: bool = True) -> Optional[Tuple[str, str, List[str], List[str], str]]:
    """
    Show unified source selection menu with toggles and browse/search options.

    Returns:
    - Tuple of (action, query, sources, search_fields, sort_by) where:
      - action: "browse" or "search"
      - query: what was typed in the prompt
      - sources: list of enabled sources ["configured", "local", "index"]
      - search_fields: list of fields to search ["name", "summary", "description"]
      - sort_by: "name" or "layer"
    - None: Cancelled
    """
    if not fzf_available():
        # Text-based fallback
        print("\nRecipe Search:")
        if has_local:
            print("  Sources: configured layers, local layers")
            source = input("Enter search term (or empty to browse all): ").strip()
            if source:
                return ("search", source, ["configured", "local"], ["name"], "name")
            return ("browse", "", ["configured", "local"], ["name"], "name")
        else:
            print("  Source: layer index (no local project)")
            source = input("Enter search term (or empty to browse all): ").strip()
            if source:
                return ("search", source, ["index"], ["name"], "name")
            return ("browse", "", ["index"], ["name"], "name")

    # Build menu with toggles and actions
    menu_lines = []

    # Source toggles (selected by default based on has_local)
    if has_local:
        menu_lines.append("toggle:configured\t  [x] Configured      (layers in bblayers.conf)")
        menu_lines.append("toggle:local\t  [x] Local           (configured + discovered)")
    menu_lines.append("toggle:index\t  [ ] Layer index     (remote API)")

    # Separator and actions
    menu_lines.append("---\t  " + "─" * 45)
    menu_lines.append("browse\t  > Browse            (show all, type to filter)")
    menu_lines.append("search\t  > Search            (type query above, Enter to search)")

    menu_input = "\n".join(menu_lines)

    # Track toggle states - sources, search fields, and sort
    toggle_states = {
        "configured": has_local,
        "local": has_local,
        "index": not has_local,
        "name": True,        # Search recipe name (default on)
        "summary": False,    # Search SUMMARY field
        "description": False, # Search DESCRIPTION field
        "sort_by_layer": False,  # Sort by layer instead of name
    }

    # Create temp files for dynamic menu reload
    import tempfile

    state_file = tempfile.NamedTemporaryFile(mode='w', suffix='.state', delete=False)
    menu_script = tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False)

    # Write initial state
    json.dump(toggle_states, state_file)
    state_file.close()

    # Write menu generation script
    # Order: first items appear at bottom (near prompt) in default fzf layout
    menu_script.write(f'''#!/bin/bash
state=$(cat "{state_file.name}")
configured=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('configured') else '[ ]')")
local=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('local') else '[ ]')")
index=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('index') else '[ ]')")
name=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('name') else '[ ]')")
summary=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('summary') else '[ ]')")
description=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('description') else '[ ]')")
sort_layer=$(echo "$state" | python3 -c "import sys,json; d=json.load(sys.stdin); print('layer' if d.get('sort_by_layer') else 'name')")
# Actions first (at bottom, near prompt)
echo "search	  > Search            (type query below, Enter)"
echo "browse	  > Browse            (show all, filter in browser)"
echo "---	  ── Actions ─────────────────────────────────"
# Sort option
echo "toggle:sort_by_layer	  Sort: $sort_layer"
echo "---	  ── Options ─────────────────────────────────"
# Source toggles (middle section)
echo "toggle:index	  $index Index   (remote API)"
''')
    if has_local:
        menu_script.write('''echo "toggle:local	  $local Local   (configured + discovered)"
echo "toggle:configured	  $configured Config (layers in bblayers.conf)"
''')
    menu_script.write('''echo "---	  ── Sources ─────────────────────────────────"
# Search field toggles (at top)
echo "toggle:description	  $description Description"
echo "toggle:summary	  $summary Summary"
echo "toggle:name	  $name Name"
echo "---	  ── Search In ───────────────────────────────"
''')
    menu_script.close()
    os.chmod(menu_script.name, 0o755)

    # Write toggle script
    toggle_script = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
    toggle_script.write(f'''#!/usr/bin/env python3
import sys, json
key = sys.argv[1] if len(sys.argv) > 1 else ""
if key.startswith("toggle:"):
    source = key.replace("toggle:", "")
    with open("{state_file.name}", "r") as f:
        state = json.load(f)
    state[source] = not state.get(source, False)
    with open("{state_file.name}", "w") as f:
        json.dump(state, f)
''')
    toggle_script.close()
    os.chmod(toggle_script.name, 0o755)

    try:
        # Generate initial menu
        initial_menu = subprocess.check_output(["bash", menu_script.name], text=True)

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--disabled",  # Disable filtering - query is just captured, not used to filter
            "--height", "~20",
            "--header", "Space=toggle | Enter=select | Type query for Search | Esc=quit",
            "--prompt", "Query: ",
            "--print-query",
            "--with-nth", "2..",
            "--delimiter", "\t",
            "--bind", f"space:execute-silent(python3 {toggle_script.name} {{1}})+reload(bash {menu_script.name})",
            "--bind", "esc:abort",
        ]
        fzf_args.extend(get_fzf_color_args())

        result = subprocess.run(
            fzf_args,
            input=initial_menu,
            stdout=subprocess.PIPE,
            text=True,
        )

        if result.returncode != 0:
            return None

        # Read final toggle state
        with open(state_file.name, "r") as f:
            toggle_states = json.load(f)

        # Parse output: query on first line, selection on second
        lines = result.stdout.split("\n")
        query = lines[0].strip() if len(lines) > 0 else ""
        selected = lines[1].split("\t")[0].strip() if len(lines) > 1 else ""

        # Handle separator - user somehow selected it, ignore
        if selected == "---" or selected.startswith("toggle:"):
            return None

        # Handle browse/search actions
        sort_by = "layer" if toggle_states.get("sort_by_layer") else "name"
        if selected == "browse":
            sources = [s for s, enabled in toggle_states.items() if enabled and s in ("configured", "local", "index")]
            search_fields = [s for s, enabled in toggle_states.items() if enabled and s in ("name", "summary", "description")]
            if not sources:
                print("No sources selected. Enable at least one source.")
                return None
            return ("browse", query, sources, search_fields or ["name"], sort_by)
        elif selected == "search":
            sources = [s for s, enabled in toggle_states.items() if enabled and s in ("configured", "local", "index")]
            search_fields = [s for s, enabled in toggle_states.items() if enabled and s in ("name", "summary", "description")]
            if not sources:
                print("No sources selected. Enable at least one source.")
                return None
            if not query:
                print("No query entered. Type a search term first.")
                return None
            return ("search", query, sources, search_fields or ["name"], sort_by)

        return None

    finally:
        # Clean up temp files
        for f in [state_file.name, menu_script.name, toggle_script.name]:
            try:
                os.unlink(f)
            except OSError:
                pass


# =============================================================================
# Main Entry Point
# =============================================================================

def run_recipe(args) -> int:
    """
    Main entry point for recipe command.

    Args:
        args: Parsed command line arguments with:
            - query: Optional search query
            - browse: Browse all local recipes
            - configured: Search configured layers only
            - local: Search all local layers
            - index: Search layer index API
            - layer: Filter to specific layer
            - section: Filter by SECTION
            - list: Text output (no fzf)
            - force: Rebuild cache
            - branch: Branch for layer index (default: master)
    """
    query = getattr(args, "query", None) or ""
    browse_mode = getattr(args, "browse", False)
    configured_mode = getattr(args, "configured", False)
    local_mode = getattr(args, "local", False)
    index_mode = getattr(args, "index", False)
    layer_filter = getattr(args, "layer", None)
    section_filter = getattr(args, "section", None)
    list_mode = getattr(args, "list", False)
    force = getattr(args, "force", False)
    branch = getattr(args, "branch", "master")
    bblayers = getattr(args, "bblayers", None)

    # Load defaults for configuration options
    defaults_file = getattr(args, "defaults_file", ".bit.defaults")
    defaults = load_defaults(defaults_file)

    # Configuration: use bitbake-layers for configured recipes (default: True)
    # Configurable via 'bit config' -> Settings -> Recipe Scan
    use_bitbake_layers = get_recipe_use_bitbake_layers()

    # Search field options from CLI
    search_name = getattr(args, "name", False)
    search_summary = getattr(args, "summary", False)
    search_description = getattr(args, "description", False)

    # Sort option from CLI
    sort_by = getattr(args, "sort", None) or "name"  # default: sort by name

    # Check if we have a local project context
    bblayers_path = resolve_bblayers_path(bblayers)
    has_local = bblayers_path is not None

    # Determine mode from CLI flags or show unified menu
    action = "browse"  # default
    sources = []
    search_fields = ["name"]  # default: search name only

    # Build search_fields from CLI options (if any specified)
    if search_name or search_summary or search_description:
        search_fields = []
        if search_name:
            search_fields.append("name")
        if search_summary:
            search_fields.append("summary")
        if search_description:
            search_fields.append("description")

    # Track if we're using interactive menu (allows looping back)
    use_interactive_menu = False

    if browse_mode:
        action = "browse"
        sources = ["configured", "local"] if has_local else ["index"]
    elif configured_mode:
        # If query provided, use search action to pre-filter
        action = "search" if query else "browse"
        sources = ["configured"]
    elif local_mode:
        action = "search" if query else "browse"
        sources = ["local"]
    elif index_mode:
        action = "search" if query else "browse"
        sources = ["index"]
    elif not has_local:
        # No local context - auto-select index
        action = "browse"
        sources = ["index"]
        print(Colors.dim("No local project found, using layer index."))
    else:
        use_interactive_menu = True

    # Main loop - allows returning to menu from browser
    while True:
        if use_interactive_menu:
            # Show unified source selection menu
            result = _source_selection_menu(has_local)
            if not result:
                return 0
            action, menu_query, sources, menu_search_fields, menu_sort_by = result
            # Use menu query
            query = menu_query
            # Use menu search fields if no CLI options specified
            if not (search_name or search_summary or search_description):
                search_fields = menu_search_fields
            # Use menu sort_by if no CLI --sort specified
            if not getattr(args, "sort", None):
                sort_by = menu_sort_by

        # Fetch recipes from all enabled sources
        all_recipes = []
        source_names = []
        is_remote = False

        # Helper to detect if query looks like a regex pattern
        def looks_like_regex(q: str) -> bool:
            regex_chars = set('^$.*+?[](){}|\\')
            return any(c in regex_chars for c in q)

        def fetch_from_source(src: str) -> List[dict]:
            nonlocal is_remote
            if src == "index":
                is_remote = True
                # Pass query for server-side search (only for search action)
                api_search = query if action == "search" else ""
                # Warn if query looks like regex (index API doesn't support regex)
                if api_search and looks_like_regex(api_search):
                    print(Colors.yellow(f"Warning: Index API doesn't support regex. '{api_search}' will be treated as literal text."))
                return _fetch_recipe_index(branch, force, search=api_search) or []
            elif src == "local":
                if has_local:
                    pairs, _ = resolve_base_and_layers(bblayers_path, defaults, discover_all=True)
                    layer_paths = dedupe_preserve_order(layer for layer, _ in pairs)
                    return _scan_recipes_from_layers(layer_paths, force=force)
                return []
            elif src == "configured":
                if has_local:
                    recipes, _ = _scan_configured_recipes(bblayers_path, force=force, use_bitbake_layers=use_bitbake_layers)
                    return recipes
                return []
            return []

        for src in sources:
            recipes = fetch_from_source(src)
            all_recipes.extend(recipes)
            source_names.append(src.capitalize())

        # Dedupe by (pn, layer_name)
        seen = set()
        unique_recipes = []
        for r in all_recipes:
            key = (r.get("pn", ""), r.get("layer_name", ""))
            if key not in seen:
                seen.add(key)
                unique_recipes.append(r)
        recipes = unique_recipes

        source_name = "+".join(source_names) if source_names else "Local"

        # Apply filters
        if layer_filter:
            recipes = [r for r in recipes if layer_filter.lower() in r.get("layer_name", "").lower()]

        if section_filter:
            recipes = [r for r in recipes if section_filter.lower() in r.get("SECTION", "").lower()]

        # Helper to check if recipe matches query based on search_fields (supports regex)
        def recipe_matches(r: dict, q: str) -> bool:
            try:
                pattern = re.compile(q, re.IGNORECASE)
            except re.error:
                # Fall back to literal match if invalid regex
                q_lower = q.lower()
                if "name" in search_fields and q_lower in r.get("pn", "").lower():
                    return True
                if "summary" in search_fields and q_lower in r.get("SUMMARY", "").lower():
                    return True
                if "description" in search_fields and q_lower in r.get("DESCRIPTION", "").lower():
                    return True
                return False

            if "name" in search_fields and pattern.search(r.get("pn", "")):
                return True
            if "summary" in search_fields and pattern.search(r.get("SUMMARY", "")):
                return True
            if "description" in search_fields and pattern.search(r.get("DESCRIPTION", "")):
                return True
            return False

        # For "search" action, filter by query before showing
        if action == "search" and query:
            pre_filter_count = len(recipes)
            recipes = [r for r in recipes if recipe_matches(r, query)]
            fields_str = "+".join(search_fields)
            print(f"Search '{query}' in [{fields_str}]: {len(recipes)} matches (from {pre_filter_count} recipes)")
            initial_query = ""  # Don't re-filter in browser
        elif list_mode and query:
            # For --list mode, also filter
            recipes = [r for r in recipes if recipe_matches(r, query)]
            initial_query = ""
        else:
            initial_query = query

        # Sort recipes
        if sort_by == "layer":
            # Sort by layer name, then by recipe name within each layer
            recipes = sorted(recipes, key=lambda r: (r.get("layer_name", "").lower(), r.get("pn", "").lower()))
        else:
            # Sort by recipe name A-Z (default)
            recipes = sorted(recipes, key=lambda r: r.get("pn", "").lower())

        # Output
        if list_mode:
            # Text output
            if not recipes:
                print("No recipes found.")
                return 1

            for recipe in recipes:
                pn = recipe.get("pn", "")
                pv = recipe.get("pv", "")
                layer_name = recipe.get("layer_name", "")
                path = recipe.get("path", "")
                print(f"{pn:<30}  {pv:<15}  {layer_name:<20}  {path}")
            return 0

        # Determine available sources for cycling
        available_sources = []
        if has_local:
            available_sources.extend(["configured", "local"])
        available_sources.append("index")

        # FZF browser with source cycling
        current_source_name = source_name
        current_recipes = recipes
        current_is_remote = is_remote

        while True:
            browser_result = _recipe_fzf_browser(
                current_recipes,
                current_source_name,
                query=initial_query,
                allow_source_switch=has_local,
                is_remote=current_is_remote,
                available_sources=available_sources,
            )

            # Check if user wants to switch source inline
            if isinstance(browser_result, tuple) and browser_result[0] == "switch":
                next_source = browser_result[1]
                print(f"Switching to {next_source.capitalize()}...")

                # Fetch from the new source
                current_is_remote = (next_source == "index")
                current_recipes = fetch_from_source(next_source)

                # Apply filters
                if layer_filter:
                    current_recipes = [r for r in current_recipes if layer_filter.lower() in r.get("layer_name", "").lower()]
                if section_filter:
                    current_recipes = [r for r in current_recipes if section_filter.lower() in r.get("SECTION", "").lower()]

                # Sort
                if sort_by == "layer":
                    current_recipes = sorted(current_recipes, key=lambda r: (r.get("layer_name", "").lower(), r.get("pn", "").lower()))
                else:
                    current_recipes = sorted(current_recipes, key=lambda r: r.get("pn", "").lower())

                current_source_name = next_source.capitalize()
                continue  # Re-show browser with new source

            # Check if user wants to go back to menu
            if browser_result == "menu" and use_interactive_menu:
                break  # Break inner loop to go back to source selection menu

            # Normal exit
            return browser_result if isinstance(browser_result, int) else 0

        continue  # Continue outer while loop (back to menu)
