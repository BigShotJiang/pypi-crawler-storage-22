#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Search command - search OpenEmbedded Layer Index."""

import json
import os
import shutil
import subprocess
import sys
import urllib.request
from typing import List, Optional

from ..core import Colors, get_fzf_color_args, get_fzf_preview_resize_bindings
from .init import _fetch_layer_index, _fetch_layer_dependencies

def run_search(args) -> int:
    """Search OpenEmbedded Layer Index for layers."""
    branch = args.branch
    query = args.query
    force = getattr(args, "force", False)

    # Fetch layers (from cache or API)
    data = _fetch_layer_index(force=force)
    if data is None:
        return 1

    # Filter by branch and deduplicate
    seen = set()
    layers = []
    for entry in data:
        entry_branch = entry.get("branch", {}).get("name", "")
        if entry_branch != branch:
            continue
        layer_info = entry.get("layer", {})
        name = layer_info.get("name", "")
        if name in seen:
            continue
        seen.add(name)
        layers.append({
            "name": name,
            "summary": layer_info.get("summary", ""),
            "description": layer_info.get("description", ""),
            "vcs_url": layer_info.get("vcs_url", ""),
            "vcs_subdir": entry.get("vcs_subdir", ""),
        })

    # Filter by query if provided
    if query:
        query_lower = query.lower()
        layers = [
            l for l in layers
            if query_lower in l["name"].lower()
            or query_lower in l["summary"].lower()
            or query_lower in l["description"].lower()
        ]

    if not layers:
        if query:
            print(f"No layers found matching '{query}' on branch '{branch}'")
        else:
            print(f"No layers found on branch '{branch}'")
        return 1

    # Handle --clone flag
    do_clone = getattr(args, "clone", False)
    clone_target = getattr(args, "target", None)
    if do_clone:
        # Try exact match first
        exact = next((l for l in layers if l["name"].lower() == query.lower()), None) if query else None
        if exact:
            layer = exact
        elif len(layers) == 1:
            layer = layers[0]
        else:
            print(f"Multiple layers match '{query}' - be more specific or use exact name:")
            for l in sorted(layers, key=lambda x: x["name"])[:10]:
                print(f"  {l['name']}")
            if len(layers) > 10:
                print(f"  ... and {len(layers) - 10} more")
            return 1

        if not layer["vcs_url"]:
            print(f"No VCS URL for {layer['name']}")
            return 1

        # Show dependencies
        deps = _fetch_layer_dependencies(layer["name"], branch)
        if deps:
            required = [d["name"] for d in deps if d["required"]]
            optional = [d["name"] for d in deps if not d["required"]]
            if required:
                print(f"{Colors.yellow('Dependencies')}: {', '.join(required)}")
            if optional:
                print(f"{Colors.dim('Optional')}: {', '.join(optional)}")

        # Determine target directory
        target = clone_target or f"layers/{layer['name']}"
        if os.path.exists(target):
            print(f"Target already exists: {target}")
            return 1

        print(f"Cloning {layer['name']} ({layer['vcs_url']}) -> {target}")
        try:
            subprocess.run(
                ["git", "clone", "-b", branch, layer["vcs_url"], target],
                check=True,
            )
            print(f"{Colors.green('Done.')}")
            if layer["vcs_subdir"]:
                print(f"Layer path: {target}/{layer['vcs_subdir']}")
            return 0
        except subprocess.CalledProcessError as e:
            print(f"{Colors.red('Clone failed')}: {e}")
            return 1

    # Handle --info flag (scriptable output)
    do_info = getattr(args, "info", False)
    if do_info:
        if not query:
            print("Error: --info requires a layer name", file=sys.stderr)
            return 1
        # Try exact match first
        exact = next((l for l in layers if l["name"].lower() == query.lower()), None)
        if exact:
            layer = exact
        elif len(layers) == 1:
            layer = layers[0]
        else:
            print(f"Error: Multiple layers match '{query}' - be more specific:", file=sys.stderr)
            for l in sorted(layers, key=lambda x: x["name"])[:10]:
                print(f"  {l['name']}", file=sys.stderr)
            return 1

        # Output machine-readable info
        print(f"name={layer['name']}")
        print(f"url={layer['vcs_url']}")
        if layer["vcs_subdir"]:
            print(f"subdir={layer['vcs_subdir']}")
        deps = _fetch_layer_dependencies(layer["name"], branch)
        if deps:
            required = [d["name"] for d in deps if d["required"]]
            optional = [d["name"] for d in deps if not d["required"]]
            if required:
                print(f"depends={','.join(required)}")
            if optional:
                print(f"optional={','.join(optional)}")
        return 0

    # Calculate max name length for alignment
    max_name_len = max(len(l["name"]) for l in layers)
    max_name_len = min(max_name_len, 35)  # Cap at 35 chars

    # Interactive selection with fzf if available
    if shutil.which("fzf") and not query:
        # Build menu for fzf with alignment
        # Format: name\tdisplay\tsummary\tdescription\tvcs_url\tvcs_subdir
        menu_lines = []
        for l in sorted(layers, key=lambda x: x["name"]):
            name = l["name"][:35]
            summary = l["summary"][:50] if l["summary"] else ""
            display = f"{name:<{max_name_len}}  {summary}"
            # Escape special chars in description for shell
            desc = l["description"].replace("'", "'\\''").replace("\n", " ") if l["description"] else ""
            vcs_url = l["vcs_url"] or ""
            vcs_subdir = l["vcs_subdir"] or ""
            menu_lines.append(f"{l['name']}\t{display}\t{desc}\t{vcs_url}\t{vcs_subdir}")

        # Preview command to format layer details
        preview_cmd = r'''
            echo -e "\033[1m{1}\033[0m"
            echo
            echo "{3}" | fold -s -w 70
            echo
            if [ -n "{4}" ]; then
                echo -e "\033[36mClone:\033[0m git clone {4}"
            fi
            if [ -n "{5}" ]; then
                echo -e "\033[36mLayer:\033[0m {5}"
            fi
        '''

        while True:
            try:
                result = subprocess.run(
                    [
                        "fzf",
                        "--height", "~70%",
                        "--header", f"OpenEmbedded Layers ({branch}) | Enter=copy clone cmd | Ctrl-y=clone | ?=preview | Esc=quit",
                        "--prompt", "Search: ",
                        "--with-nth", "2",
                        "--delimiter", "\t",
                        "--preview", preview_cmd,
                        "--preview-window", "right:50%:wrap",
                        "--bind", "?:toggle-preview",
                        "--bind", r"ctrl-y:become(printf 'CLONE\t%s\t%s\n' {1} {4})",
                    ] + get_fzf_preview_resize_bindings() + get_fzf_color_args(),
                    input="\n".join(menu_lines),
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                break

            if result.returncode != 0 or not result.stdout.strip():
                break

            output = result.stdout.strip()

            if output.startswith("CLONE\t"):
                # Clone the layer repo - output is "CLONE\t<name>\t<url>"
                parts = output.split("\t")
                layer_name = parts[1] if len(parts) > 1 else ""
                vcs_url = parts[2] if len(parts) > 2 else ""
                if not vcs_url:
                    print(f"\n  No VCS URL for {layer_name}")
                    continue

                # Show dependencies
                print()
                deps = _fetch_layer_dependencies(layer_name, branch)
                if deps:
                    required = [d["name"] for d in deps if d["required"]]
                    optional = [d["name"] for d in deps if not d["required"]]
                    if required:
                        print(f"  {Colors.yellow('Dependencies')}: {', '.join(required)}")
                    if optional:
                        print(f"  {Colors.dim('Optional')}: {', '.join(optional)}")

                # Prompt for target directory
                default_target = f"layers/{layer_name}"
                try:
                    target = input(f"Clone {layer_name} to [{default_target}]: ").strip()
                except (EOFError, KeyboardInterrupt):
                    print("\nCancelled.")
                    continue
                if not target:
                    target = default_target

                if os.path.exists(target):
                    print(f"  {Colors.yellow('exists')}: {target}")
                    continue

                print(f"  Cloning {vcs_url} -> {target}...")
                try:
                    subprocess.run(
                        ["git", "clone", "-b", branch, vcs_url, target],
                        check=True,
                    )
                    print(f"  {Colors.green('done')}")
                except subprocess.CalledProcessError as e:
                    print(f"  {Colors.red('failed')}: {e}")
                continue

            # Enter was pressed - show details
            selected_name = output.split("\t")[0]
            selected = next((l for l in layers if l["name"] == selected_name), None)
            if selected:
                _show_layer_details(selected, branch)

        return 0

    # Text output with alignment
    print(f"\n{Colors.bold(f'Layers on {branch} branch')} ({len(layers)} results)\n")
    for l in sorted(layers, key=lambda x: x["name"]):
        name = l["name"][:35]
        summary = l["summary"][:60] if l["summary"] else ""
        print(f"  {Colors.green(f'{name:<{max_name_len}}')}  {summary}")
        if l["vcs_url"]:
            subdir = f" (subdir: {l['vcs_subdir']})" if l["vcs_subdir"] else ""
            print(f"  {' ' * max_name_len}  {Colors.dim(l['vcs_url'])}{Colors.dim(subdir)}")

    return 0


def _show_layer_details(layer: dict, branch: str) -> None:
    """Show detailed info for a layer and offer to clone."""
    print()
    print(f"  {Colors.bold(layer['name'])}")
    print()
    if layer["summary"]:
        print(f"  {layer['summary']}")
        print()
    if layer["description"]:
        # Word wrap description
        desc = layer["description"]
        for line in desc.split("\n"):
            print(f"  {line}")
        print()
    if layer["vcs_url"]:
        print(f"  {Colors.cyan('Clone:')} git clone {layer['vcs_url']}")
        if layer["vcs_subdir"]:
            print(f"  {Colors.cyan('Layer path:')} {layer['vcs_subdir']}")
        print()

    # Offer to copy clone command
    clone_cmd = f"git clone {layer['vcs_url']}"
    if layer["vcs_subdir"]:
        clone_cmd += f"  # layer in: {layer['vcs_subdir']}"

    try:
        if shutil.which("xclip"):
            subprocess.run(["xclip", "-selection", "clipboard"], input=clone_cmd.encode(), check=True)
            print(Colors.dim("  (clone command copied to clipboard)"))
        elif shutil.which("xsel"):
            subprocess.run(["xsel", "--clipboard", "--input"], input=clone_cmd.encode(), check=True)
            print(Colors.dim("  (clone command copied to clipboard)"))
    except Exception:
        pass


