#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Update command - git pull/rebase layer repositories."""

import subprocess
import sys
from typing import List, Optional, Tuple

from ..core import (
    Colors,
    current_branch,
    load_defaults,
    save_defaults,
)
from .common import (
    collect_repos,
    find_repo_by_identifier,
    load_resume,
    save_resume,
    prompt_action,
    run_cmd,
    repo_display_name,
)

def run_update(args) -> int:
    defaults = load_defaults(args.defaults_file)
    discover_all = getattr(args, 'all', False)
    repos, _repo_sets = collect_repos(args.bblayers, defaults, discover_all=discover_all)

    # If specific repo requested, filter to just that one
    if getattr(args, 'repo', None):
        target_repo = find_repo_by_identifier(repos, args.repo, defaults)
        if not target_repo:
            print(f"Repo not found: {args.repo}")
            return 1
        repos = [target_repo]

    resume_state = load_resume(args.resume_file) if args.resume else None
    next_idx = 0
    if resume_state:
        saved_idx, saved_repos = resume_state
        if saved_repos == repos and 0 <= saved_idx < len(repos):
            next_idx = saved_idx
            print(f"Resuming from index {next_idx+1}/{len(repos)} using {args.resume_file}.")
        else:
            print("Resume data does not match current layer repos; starting over.")

    if args.resume:
        save_resume(args.resume_file, next_idx, repos)

    completed = False
    idx = next_idx - 1
    try:
        for idx in range(next_idx, len(repos)):
            repo = repos[idx]
            default_action = defaults.get(repo, "rebase")
            branch = current_branch(repo)
            action = prompt_action(repo, branch, default_action, use_fzf=not args.plain)
            if action is None:
                continue
            op, target, new_default = action

            if new_default:
                defaults[repo] = new_default
                save_defaults(args.defaults_file, defaults)

            if op == "quit":
                print("Aborting on user request.")
                break
            if op == "skip":
                if args.resume:
                    save_resume(args.resume_file, idx + 1, repos)
                continue

            if op == "custom":
                print(f"Custom command in {repo}")
                run_cmd(repo, target, args.dry_run, shell=True)
            else:
                remote_ref = f"origin/{target}"
                verb = "pull --rebase" if op == "rebase" else "pull"
                print(f"Updating {repo}: git {verb} {remote_ref}")
                if op == "rebase":
                    run_cmd(repo, ["git", "pull", "--rebase", "origin", target], args.dry_run)
                elif op == "merge":
                    run_cmd(repo, ["git", "pull", "origin", target], args.dry_run)

            if args.resume:
                save_resume(args.resume_file, idx + 1, repos)
        else:
            completed = True
    except subprocess.CalledProcessError as exc:
        print(f"Command failed in {repo}: {exc}")
        return exc.returncode or 1

    if args.resume and completed and os.path.exists(args.resume_file):
        os.remove(args.resume_file)

    return 0


def get_repo_log(repo: str, branch: str, remote_exists: bool, max_commits: int, show_all: bool) -> Tuple[str, List[str]]:
    remote_ref = f"origin/{branch}"
    log_args = ["git", "-C", repo, "log", "--oneline"]
    desc = ""
    if remote_exists:
        log_args.append(f"{remote_ref}..HEAD")
        desc = f"local commits vs {remote_ref}"
    else:
        log_args.extend(["-n", str(max_commits if not show_all else 1000000)])
        desc = f"recent commits (no {remote_ref})"

    try:
        out = subprocess.check_output(log_args, text=True)
    except subprocess.CalledProcessError:
        return "failed to read log", []

    lines = [line for line in out.strip().splitlines() if line.strip()]
    return desc, lines


def get_upstream_commits(repo: str, branch: str) -> List[str]:
    """Get commits in origin/<branch> that are not in HEAD (pending upstream changes)."""
    remote_ref = f"origin/{branch}"
    try:
        out = subprocess.check_output(
            ["git", "-C", repo, "log", "--oneline", f"HEAD..{remote_ref}"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return [line for line in out.strip().splitlines() if line.strip()]
    except subprocess.CalledProcessError:
        return []


def fetch_repo(repo: str) -> bool:
    """Fetch from origin. Returns True on success."""
    try:
        subprocess.run(
            ["git", "-C", repo, "fetch", "origin"],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return True
    except subprocess.CalledProcessError:
        return False



def run_single_repo_update(repo: str, branch: str, action: str) -> bool:
    """Run update for a single repo. action: 'rebase' or 'merge'. Returns True on success."""
    if not branch:
        print(f"  No branch (detached HEAD)")
        return False

    try:
        if action == "rebase":
            print(f"  git pull --rebase origin/{branch}")
            subprocess.run(
                ["git", "-C", repo, "pull", "--rebase", "origin", branch],
                check=True,
            )
        elif action == "merge":
            print(f"  git pull origin/{branch}")
            subprocess.run(
                ["git", "-C", repo, "pull", "origin", branch],
                check=True,
            )
        else:
            return False

        print(f"  Done.")
        return True
    except subprocess.CalledProcessError as e:
        print(f"  Failed: {e}")
        return False


