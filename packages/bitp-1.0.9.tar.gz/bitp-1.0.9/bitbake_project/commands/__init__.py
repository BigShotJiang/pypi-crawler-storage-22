#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Commands package for bit.

This package contains all command implementations:
- update: git pull/rebase layer repos
- explore: interactively explore commits
- export: export patches
- config: view and configure settings
- branch: view and switch branches
- search: search layer index
- init: setup build environment
- repos: list repositories
- projects: manage multiple project directories
"""

# Import all run_* functions for CLI dispatch
from .update import run_update, run_single_repo_update
from .explore import run_explore, run_status
from .export import run_export, run_prepare_export
from .config import run_config, run_config_edit
from .branch import run_branch
from .search import run_search
from .init import run_init, run_init_shell, run_bootstrap
from .repos import run_repos
from .projects import run_projects, get_current_project, set_current_project
from .recipe import run_recipe
from .fragment import run_fragment
from .deps import run_deps
from .patches import run_patches

# Also export fzf_available for CLI
from ..core import fzf_available

__all__ = [
    "run_update",
    "run_single_repo_update",
    "run_explore",
    "run_status",
    "run_export",
    "run_prepare_export",
    "run_config",
    "run_config_edit",
    "run_branch",
    "run_search",
    "run_init",
    "run_init_shell",
    "run_bootstrap",
    "run_repos",
    "run_projects",
    "get_current_project",
    "set_current_project",
    "run_recipe",
    "run_fragment",
    "run_deps",
    "run_patches",
    "fzf_available",
]
