# bitrepl

A REPL for bitwise and arithmetic operations. See results in hex, binary, and decimal (signed/unsigned) simultaneously.

Built for C systems programming courses.

## Installation

```bash
pip install bitrepl
```

## Usage

```bash
bitrepl
```

```
[32-bit] > 0xFF & 0x0F
$0:
  Hex:       0x0000000F
  Binary:    0000 0000 0000 0000 0000 0000 0000 1111
  Unsigned:  15
  Signed:    15

[32-bit] > ~0
$1:
  Hex:       0xFFFFFFFF
  Binary:    1111 1111 1111 1111 1111 1111 1111 1111
  Unsigned:  4294967295
  Signed:    -1
```

## Features

- **Multi-format output**: Every result shows hex, binary, unsigned, and signed representations
- **C-style operators**: `&` `|` `^` `~` `<<` `>>` `+` `-` `*` `/` `%`
- **Number formats**: Decimal (`255`), hex (`0xFF`), binary (`0b1111`), octal (`0o17`)
- **Configurable bit width**: 8, 16, 32, or 64 bits
- **Result comparison**: Compare multiple results side-by-side
- **Variables**: Store and reuse values

## Commands

| Command | Description |
|---------|-------------|
| `:width N` | Set bit width (8, 16, 32, 64) |
| `:cmp` | Compare last 2 results side-by-side |
| `:cmp N` | Compare last N results |
| `:vars` | Show stored variables |
| `:clear` | Clear result history |
| `:help` | Show help |
| `:quit` | Exit |

## Variables

Reference previous results with `$0`, `$1`, etc:

```
[32-bit] > 0xFF
$0: ...

[32-bit] > $0 << 8
$1: ...
```

Store named variables:

```
[32-bit] > $mask = 0xFF
[32-bit] > 0xABCD & $mask
```

## Comparison

Compare signed vs unsigned interpretation of the same bit pattern:

```
[8-bit] > 127
[8-bit] > 128
[8-bit] > :cmp
======================================================
COMPARISON:
------------------------------------------------------
          127                   128
------------------------------------------------------
Hex:      0x7F                  0x80
Binary:   0111 1111             1000 0000
Unsigned: 127                   128
Signed:   127                   -128
======================================================
```

## License

MIT
