"""bitrepl - A REPL for bitwise and arithmetic operations."""

__version__ = "0.1.0"
