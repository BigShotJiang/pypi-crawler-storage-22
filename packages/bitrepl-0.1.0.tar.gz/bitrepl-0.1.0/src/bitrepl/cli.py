#!/usr/bin/env python3
"""
bitrepl - A REPL for bitwise and arithmetic operations
Displays results in hex, binary, decimal (signed and unsigned)
Designed for C systems programming courses.
"""

import readline
import sys

# Default bit width (can be changed with :width command)
BIT_WIDTH = 32

def format_binary(value, width):
    """Format value as binary with spacing every 4 bits."""
    if value < 0:
        # Two's complement for negative numbers
        value = (1 << width) + value
    mask = (1 << width) - 1
    value = value & mask
    binary = format(value, f'0{width}b')
    # Add space every 4 bits for readability
    spaced = ' '.join(binary[i:i+4] for i in range(0, len(binary), 4))
    return spaced

def to_signed(value, width):
    """Convert unsigned value to signed interpretation."""
    mask = (1 << width) - 1
    value = value & mask
    if value >= (1 << (width - 1)):
        return value - (1 << width)
    return value

def to_unsigned(value, width):
    """Convert value to unsigned interpretation."""
    mask = (1 << width) - 1
    if value < 0:
        return (1 << width) + value
    return value & mask

def display_result(value, width, label="Result"):
    """Display a value in multiple formats."""
    unsigned = to_unsigned(value, width)
    signed = to_signed(unsigned, width)

    print(f"  {'Hex:':<10} 0x{unsigned:0{width//4}X}")
    print(f"  {'Binary:':<10} {format_binary(unsigned, width)}")
    print(f"  {'Unsigned:':<10} {unsigned}")
    print(f"  {'Signed:':<10} {signed}")

def display_comparison(results, width):
    """Display multiple results side by side for comparison."""
    if len(results) < 2:
        return

    # Calculate column width based on bit width
    col_width = max(22, width + 12)
    total_width = col_width * len(results) + 10

    print("\n" + "=" * total_width)
    print("COMPARISON:")
    print("-" * total_width)

    # Header
    header = f"{'':10}"
    for expr, _ in results:
        expr_display = expr[:col_width-2] if len(expr) > col_width-2 else expr
        header += f"{expr_display:<{col_width}}"
    print(header)
    print("-" * total_width)

    # Hex row
    row = f"{'Hex:':<10}"
    for _, val in results:
        unsigned = to_unsigned(val, width)
        hex_str = f"0x{unsigned:0{width//4}X}"
        row += f"{hex_str:<{col_width}}"
    print(row)

    # Binary row
    row = f"{'Binary:':<10}"
    for _, val in results:
        unsigned = to_unsigned(val, width)
        binary = format_binary(unsigned, width)
        row += f"{binary:<{col_width}}"
    print(row)

    # Unsigned row
    row = f"{'Unsigned:':<10}"
    for _, val in results:
        unsigned = to_unsigned(val, width)
        row += f"{unsigned:<{col_width}}"
    print(row)

    # Signed row
    row = f"{'Signed:':<10}"
    for _, val in results:
        unsigned = to_unsigned(val, width)
        signed = to_signed(unsigned, width)
        row += f"{signed:<{col_width}}"
    print(row)

    print("=" * total_width)

def safe_eval(expr, width):
    """Safely evaluate a bitwise/arithmetic expression."""
    # Replace C-style operators
    expr = expr.replace('~', ' custom_not ')

    # Define custom NOT that respects bit width
    def custom_not(x):
        mask = (1 << width) - 1
        return (~x) & mask

    # Allowed names and functions
    safe_dict = {
        'custom_not': custom_not,
        '__builtins__': {},
    }

    # Parse the expression
    try:
        # Handle the custom_not operator
        tokens = expr.split()
        result_tokens = []
        i = 0
        while i < len(tokens):
            if tokens[i] == 'custom_not':
                if i + 1 < len(tokens):
                    result_tokens.append(f'custom_not({tokens[i+1]})')
                    i += 2
                else:
                    raise ValueError("~ requires an operand")
            else:
                result_tokens.append(tokens[i])
                i += 1
        expr = ' '.join(result_tokens)

        result = eval(expr, safe_dict)
        return int(result)
    except Exception as e:
        raise ValueError(f"Invalid expression: {e}")

def print_help():
    """Print help message."""
    print("""
bitrepl - Bitwise Operations REPL
=================================

OPERATORS:
  &       Bitwise AND          |       Bitwise OR
  ^       Bitwise XOR          ~       Bitwise NOT
  <<      Left shift           >>      Right shift
  +  -  *  /  %                Arithmetic operators

NUMBER FORMATS:
  255     Decimal              0xFF    Hexadecimal
  0b1111  Binary               0o17    Octal

COMMANDS:
  :width N     Set bit width (8, 16, 32, 64). Current: {width}
  :cmp         Compare last two results
  :cmp N       Compare last N results
  :clear       Clear result history
  :vars        Show stored variables
  :help        Show this help
  :quit        Exit (or Ctrl+D)

VARIABLES:
  Use $0, $1, etc. to reference previous results
  Use $name = expr to store named variables

EXAMPLES:
  0xFF & 0x0F          -> Bitwise AND
  1 << 8               -> Left shift
  ~0                   -> Bitwise NOT (all 1s)
  0xDEADBEEF >> 16     -> Right shift
  $0 | $1              -> OR of last two results
  $mask = 0xFF         -> Store variable
  $val & $mask         -> Use variable
""".format(width=BIT_WIDTH))

def main():
    global BIT_WIDTH

    print("bitrepl - Bitwise Operations REPL")
    print(f"Bit width: {BIT_WIDTH} | Type :help for commands | Ctrl+D to exit")
    print()

    history = []  # List of (expression, value) tuples
    variables = {}  # Named variables

    try:
        while True:
            try:
                prompt = f"[{BIT_WIDTH}-bit] > "
                line = input(prompt).strip()

                if not line:
                    continue

                # Handle commands
                if line.startswith(':'):
                    parts = line.split()
                    cmd = parts[0].lower()

                    if cmd == ':quit' or cmd == ':q':
                        break
                    elif cmd == ':help' or cmd == ':h':
                        print_help()
                    elif cmd == ':width' or cmd == ':w':
                        if len(parts) > 1:
                            try:
                                new_width = int(parts[1])
                                if new_width in [8, 16, 32, 64]:
                                    BIT_WIDTH = new_width
                                    print(f"Bit width set to {BIT_WIDTH}")
                                else:
                                    print("Width must be 8, 16, 32, or 64")
                            except ValueError:
                                print("Invalid width")
                        else:
                            print(f"Current width: {BIT_WIDTH}")
                    elif cmd == ':cmp' or cmd == ':c':
                        n = 2
                        if len(parts) > 1:
                            try:
                                n = int(parts[1])
                            except ValueError:
                                pass
                        if len(history) >= 2:
                            display_comparison(history[-n:], BIT_WIDTH)
                        else:
                            print("Need at least 2 results to compare")
                    elif cmd == ':clear':
                        history.clear()
                        print("History cleared")
                    elif cmd == ':vars' or cmd == ':v':
                        if variables:
                            print("Variables:")
                            for name, val in variables.items():
                                unsigned = to_unsigned(val, BIT_WIDTH)
                                print(f"  ${name} = {val} (0x{unsigned:X})")
                        else:
                            print("No variables defined")
                    else:
                        print(f"Unknown command: {cmd}")
                    continue

                # Check for variable assignment
                if '=' in line and line.split('=')[0].strip().startswith('$'):
                    var_part, expr_part = line.split('=', 1)
                    var_name = var_part.strip()[1:]  # Remove $
                    if var_name.isidentifier():
                        # Substitute variables in expression
                        expr = expr_part.strip()
                        for name, val in variables.items():
                            expr = expr.replace(f'${name}', str(val))
                        for i, (_, val) in enumerate(history):
                            expr = expr.replace(f'${i}', str(val))

                        result = safe_eval(expr, BIT_WIDTH)
                        variables[var_name] = result
                        print(f"${var_name} =")
                        display_result(result, BIT_WIDTH)
                        continue

                # Substitute variables
                expr = line
                for name, val in variables.items():
                    expr = expr.replace(f'${name}', str(val))
                for i, (_, val) in enumerate(history):
                    expr = expr.replace(f'${i}', str(val))

                # Evaluate expression
                result = safe_eval(expr, BIT_WIDTH)
                history.append((line, result))

                print(f"${len(history)-1}:")
                display_result(result, BIT_WIDTH)
                print()

            except ValueError as e:
                print(f"Error: {e}")
            except KeyboardInterrupt:
                print("\nUse :quit or Ctrl+D to exit")

    except EOFError:
        print("\nGoodbye!")

if __name__ == '__main__':
    main()
