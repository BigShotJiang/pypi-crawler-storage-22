from enum import Enum
from dataclasses import dataclass
from typing import Optional, Any, List, TypeVar, Type, cast, Callable
from uuid import UUID
from datetime import datetime
import dateutil.parser


T = TypeVar("T")
EnumT = TypeVar("EnumT", bound=Enum)


def from_str(x: Any) -> str:
    assert isinstance(x, str)
    return x


def from_none(x: Any) -> Any:
    assert x is None
    return x


def from_union(fs, x):
    for f in fs:
        try:
            return f(x)
        except:
            pass
    assert False


def to_enum(c: Type[EnumT], x: Any) -> EnumT:
    assert isinstance(x, c)
    return x.value


def from_int(x: Any) -> int:
    assert isinstance(x, int) and not isinstance(x, bool)
    return x


def to_class(c: Type[T], x: Any) -> dict:
    assert isinstance(x, c)
    return cast(Any, x).to_dict()


def from_bool(x: Any) -> bool:
    assert isinstance(x, bool)
    return x


def from_list(f: Callable[[Any], T], x: Any) -> List[T]:
    assert isinstance(x, list)
    return [f(y) for y in x]


def from_datetime(x: Any) -> datetime:
    return dateutil.parser.parse(x)


class DeviceType(Enum):
    """Device type to send to Bitwarden. Defaults to SDK"""

    ANDROID = "Android"
    ANDROID_AMAZON = "AndroidAmazon"
    CHROME_BROWSER = "ChromeBrowser"
    CHROME_EXTENSION = "ChromeExtension"
    DUCK_DUCK_GO_BROWSER = "DuckDuckGoBrowser"
    EDGE_BROWSER = "EdgeBrowser"
    EDGE_EXTENSION = "EdgeExtension"
    FIREFOX_BROWSER = "FirefoxBrowser"
    FIREFOX_EXTENSION = "FirefoxExtension"
    IE_BROWSER = "IEBrowser"
    I_OS = "iOS"
    LINUX_CLI = "LinuxCLI"
    LINUX_DESKTOP = "LinuxDesktop"
    MAC_OS_CLI = "MacOsCLI"
    MAC_OS_DESKTOP = "MacOsDesktop"
    OPERA_BROWSER = "OperaBrowser"
    OPERA_EXTENSION = "OperaExtension"
    SAFARI_BROWSER = "SafariBrowser"
    SAFARI_EXTENSION = "SafariExtension"
    SDK = "SDK"
    SERVER = "Server"
    UNKNOWN_BROWSER = "UnknownBrowser"
    UWP = "UWP"
    VIVALDI_BROWSER = "VivaldiBrowser"
    VIVALDI_EXTENSION = "VivaldiExtension"
    WINDOWS_CLI = "WindowsCLI"
    WINDOWS_DESKTOP = "WindowsDesktop"


@dataclass
class ClientSettings:
    """Basic client behavior settings. These settings specify the various targets and behavior
    of the
    Bitwarden Client. They are optional and uneditable once the client is initialized.
    
    Defaults to
    
    ```
    # use bitwarden_core::{ClientSettings, DeviceType};
    let settings = ClientSettings {
    identity_url: "https://identity.bitwarden.com".to_string(),
    api_url: "https://api.bitwarden.com".to_string(),
    user_agent: "Bitwarden Rust-SDK".to_string(),
    device_type: DeviceType::SDK,
    bitwarden_client_version: None,
    bitwarden_package_type: None,
    device_identifier: None,
    };
    let default = ClientSettings::default();
    ```
    """
    api_url: Optional[str] = None
    """The api url of the targeted Bitwarden instance. Defaults to `https://api.bitwarden.com`"""

    bitwarden_client_version: Optional[str] = None
    """Bitwarden Client Version to send to Bitwarden. Optional for now in transition period."""

    bitwarden_package_type: Optional[str] = None
    """Bitwarden Package Type to send to Bitwarden. We should evaluate this field to see if it
    should be optional later.
    """
    device_identifier: Optional[str] = None
    """Device identifier to send to Bitwarden. Optional for now in transition period."""

    device_type: Optional[DeviceType] = None
    """Device type to send to Bitwarden. Defaults to SDK"""

    identity_url: Optional[str] = None
    """The identity url of the targeted Bitwarden instance. Defaults to
    `https://identity.bitwarden.com`
    """
    user_agent: Optional[str] = None
    """The user_agent to sent to Bitwarden. Defaults to `Bitwarden Rust-SDK`"""

    @staticmethod
    def from_dict(obj: Any) -> 'ClientSettings':
        assert isinstance(obj, dict)
        api_url = from_union([from_str, from_none], obj.get("apiUrl"))
        bitwarden_client_version = from_union([from_none, from_str], obj.get("bitwardenClientVersion"))
        bitwarden_package_type = from_union([from_none, from_str], obj.get("bitwardenPackageType"))
        device_identifier = from_union([from_none, from_str], obj.get("deviceIdentifier"))
        device_type = from_union([DeviceType, from_none], obj.get("deviceType"))
        identity_url = from_union([from_str, from_none], obj.get("identityUrl"))
        user_agent = from_union([from_str, from_none], obj.get("userAgent"))
        return ClientSettings(api_url, bitwarden_client_version, bitwarden_package_type, device_identifier, device_type, identity_url, user_agent)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.api_url is not None:
            result["apiUrl"] = from_union([from_str, from_none], self.api_url)
        if self.bitwarden_client_version is not None:
            result["bitwardenClientVersion"] = from_union([from_none, from_str], self.bitwarden_client_version)
        if self.bitwarden_package_type is not None:
            result["bitwardenPackageType"] = from_union([from_none, from_str], self.bitwarden_package_type)
        if self.device_identifier is not None:
            result["deviceIdentifier"] = from_union([from_none, from_str], self.device_identifier)
        if self.device_type is not None:
            result["deviceType"] = from_union([lambda x: to_enum(DeviceType, x), from_none], self.device_type)
        if self.identity_url is not None:
            result["identityUrl"] = from_union([from_str, from_none], self.identity_url)
        if self.user_agent is not None:
            result["userAgent"] = from_union([from_str, from_none], self.user_agent)
        return result


@dataclass
class CancellationTest:
    duration_millis: int

    @staticmethod
    def from_dict(obj: Any) -> 'CancellationTest':
        assert isinstance(obj, dict)
        duration_millis = from_int(obj.get("duration_millis"))
        return CancellationTest(duration_millis)

    def to_dict(self) -> dict:
        result: dict = {}
        result["duration_millis"] = from_int(self.duration_millis)
        return result


@dataclass
class ErrorTest:
    pass

    @staticmethod
    def from_dict(obj: Any) -> 'ErrorTest':
        assert isinstance(obj, dict)
        return ErrorTest()

    def to_dict(self) -> dict:
        result: dict = {}
        return result


@dataclass
class DebugCommand:
    cancellation_test: Optional[CancellationTest] = None
    error_test: Optional[ErrorTest] = None

    @staticmethod
    def from_dict(obj: Any) -> 'DebugCommand':
        assert isinstance(obj, dict)
        cancellation_test = from_union([CancellationTest.from_dict, from_none], obj.get("cancellationTest"))
        error_test = from_union([ErrorTest.from_dict, from_none], obj.get("errorTest"))
        return DebugCommand(cancellation_test, error_test)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.cancellation_test is not None:
            result["cancellationTest"] = from_union([lambda x: to_class(CancellationTest, x), from_none], self.cancellation_test)
        if self.error_test is not None:
            result["errorTest"] = from_union([lambda x: to_class(ErrorTest, x), from_none], self.error_test)
        return result


@dataclass
class PasswordGeneratorRequest:
    """Password generator request options."""

    avoid_ambiguous: bool
    """When set to true, the generated password will not contain ambiguous characters.
    The ambiguous characters are: I, O, l, 0, 1
    """
    length: int
    """The length of the generated password.
    Note that the password length must be greater than the sum of all the minimums.
    """
    lowercase: bool
    """Include lowercase characters (a-z)."""

    numbers: bool
    """Include numbers (0-9)."""

    special: bool
    """Include special characters: ! @ # $ % ^ & *"""

    uppercase: bool
    """Include uppercase characters (A-Z)."""

    min_lowercase: Optional[int] = None
    """The minimum number of lowercase characters in the generated password.
    When set, the value must be between 1 and 9. This value is ignored if lowercase is false.
    """
    min_number: Optional[int] = None
    """The minimum number of numbers in the generated password.
    When set, the value must be between 1 and 9. This value is ignored if numbers is false.
    """
    min_special: Optional[int] = None
    """The minimum number of special characters in the generated password.
    When set, the value must be between 1 and 9. This value is ignored if special is false.
    """
    min_uppercase: Optional[int] = None
    """The minimum number of uppercase characters in the generated password.
    When set, the value must be between 1 and 9. This value is ignored if uppercase is false.
    """

    @staticmethod
    def from_dict(obj: Any) -> 'PasswordGeneratorRequest':
        assert isinstance(obj, dict)
        avoid_ambiguous = from_bool(obj.get("avoidAmbiguous"))
        length = from_int(obj.get("length"))
        lowercase = from_bool(obj.get("lowercase"))
        numbers = from_bool(obj.get("numbers"))
        special = from_bool(obj.get("special"))
        uppercase = from_bool(obj.get("uppercase"))
        min_lowercase = from_union([from_none, from_int], obj.get("minLowercase"))
        min_number = from_union([from_none, from_int], obj.get("minNumber"))
        min_special = from_union([from_none, from_int], obj.get("minSpecial"))
        min_uppercase = from_union([from_none, from_int], obj.get("minUppercase"))
        return PasswordGeneratorRequest(avoid_ambiguous, length, lowercase, numbers, special, uppercase, min_lowercase, min_number, min_special, min_uppercase)

    def to_dict(self) -> dict:
        result: dict = {}
        result["avoidAmbiguous"] = from_bool(self.avoid_ambiguous)
        result["length"] = from_int(self.length)
        result["lowercase"] = from_bool(self.lowercase)
        result["numbers"] = from_bool(self.numbers)
        result["special"] = from_bool(self.special)
        result["uppercase"] = from_bool(self.uppercase)
        if self.min_lowercase is not None:
            result["minLowercase"] = from_union([from_none, from_int], self.min_lowercase)
        if self.min_number is not None:
            result["minNumber"] = from_union([from_none, from_int], self.min_number)
        if self.min_special is not None:
            result["minSpecial"] = from_union([from_none, from_int], self.min_special)
        if self.min_uppercase is not None:
            result["minUppercase"] = from_union([from_none, from_int], self.min_uppercase)
        return result


@dataclass
class GeneratorsCommand:
    """Generate a password
    
    Returns: [String]
    """
    generate_password: PasswordGeneratorRequest

    @staticmethod
    def from_dict(obj: Any) -> 'GeneratorsCommand':
        assert isinstance(obj, dict)
        generate_password = PasswordGeneratorRequest.from_dict(obj.get("generatePassword"))
        return GeneratorsCommand(generate_password)

    def to_dict(self) -> dict:
        result: dict = {}
        result["generatePassword"] = to_class(PasswordGeneratorRequest, self.generate_password)
        return result


@dataclass
class AccessTokenLoginRequest:
    """Login to Bitwarden with access token"""

    access_token: str
    """Bitwarden service API access token"""

    state_file: Optional[str] = None
    """Path to the state file"""

    @staticmethod
    def from_dict(obj: Any) -> 'AccessTokenLoginRequest':
        assert isinstance(obj, dict)
        access_token = from_str(obj.get("accessToken"))
        state_file = from_union([from_none, from_str], obj.get("stateFile"))
        return AccessTokenLoginRequest(access_token, state_file)

    def to_dict(self) -> dict:
        result: dict = {}
        result["accessToken"] = from_str(self.access_token)
        if self.state_file is not None:
            result["stateFile"] = from_union([from_none, from_str], self.state_file)
        return result


@dataclass
class ProjectCreateRequest:
    name: str
    organization_id: UUID
    """Organization where the project will be created"""

    @staticmethod
    def from_dict(obj: Any) -> 'ProjectCreateRequest':
        assert isinstance(obj, dict)
        name = from_str(obj.get("name"))
        organization_id = UUID(obj.get("organizationId"))
        return ProjectCreateRequest(name, organization_id)

    def to_dict(self) -> dict:
        result: dict = {}
        result["name"] = from_str(self.name)
        result["organizationId"] = str(self.organization_id)
        return result


@dataclass
class ProjectsDeleteRequest:
    ids: List[UUID]
    """IDs of the projects to delete"""

    @staticmethod
    def from_dict(obj: Any) -> 'ProjectsDeleteRequest':
        assert isinstance(obj, dict)
        ids = from_list(lambda x: UUID(x), obj.get("ids"))
        return ProjectsDeleteRequest(ids)

    def to_dict(self) -> dict:
        result: dict = {}
        result["ids"] = from_list(lambda x: str(x), self.ids)
        return result


@dataclass
class ProjectGetRequest:
    id: UUID
    """ID of the project to retrieve"""

    @staticmethod
    def from_dict(obj: Any) -> 'ProjectGetRequest':
        assert isinstance(obj, dict)
        id = UUID(obj.get("id"))
        return ProjectGetRequest(id)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = str(self.id)
        return result


@dataclass
class ProjectsListRequest:
    organization_id: UUID
    """Organization to retrieve all the projects from"""

    @staticmethod
    def from_dict(obj: Any) -> 'ProjectsListRequest':
        assert isinstance(obj, dict)
        organization_id = UUID(obj.get("organizationId"))
        return ProjectsListRequest(organization_id)

    def to_dict(self) -> dict:
        result: dict = {}
        result["organizationId"] = str(self.organization_id)
        return result


@dataclass
class ProjectPutRequest:
    id: UUID
    """ID of the project to modify"""

    name: str
    organization_id: UUID
    """Organization ID of the project to modify"""

    @staticmethod
    def from_dict(obj: Any) -> 'ProjectPutRequest':
        assert isinstance(obj, dict)
        id = UUID(obj.get("id"))
        name = from_str(obj.get("name"))
        organization_id = UUID(obj.get("organizationId"))
        return ProjectPutRequest(id, name, organization_id)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = str(self.id)
        result["name"] = from_str(self.name)
        result["organizationId"] = str(self.organization_id)
        return result


@dataclass
class ProjectsCommand:
    """* Requires Authentication
    * Requires using an Access Token for login or calling Sync at least once
    
    Retrieve a project by the provided identifier
    
    Returns: [ProjectResponse](bitwarden::secrets_manager::projects::ProjectResponse)
    
    * Requires Authentication
    * Requires using an Access Token for login or calling Sync at least once
    
    Creates a new project in the provided organization using the given data
    
    Returns: [ProjectResponse](bitwarden::secrets_manager::projects::ProjectResponse)
    
    * Requires Authentication
    * Requires using an Access Token for login or calling Sync at least once
    
    Lists all projects of the given organization
    
    Returns: [ProjectsResponse](bitwarden::secrets_manager::projects::ProjectsResponse)
    
    * Requires Authentication
    * Requires using an Access Token for login or calling Sync at least once
    
    Updates an existing project with the provided ID using the given data
    
    Returns: [ProjectResponse](bitwarden::secrets_manager::projects::ProjectResponse)
    
    * Requires Authentication
    * Requires using an Access Token for login or calling Sync at least once
    
    Deletes all the projects whose IDs match the provided ones
    
    Returns:
    [ProjectsDeleteResponse](bitwarden::secrets_manager::projects::ProjectsDeleteResponse)
    """
    get: Optional[ProjectGetRequest] = None
    create: Optional[ProjectCreateRequest] = None
    list: Optional[ProjectsListRequest] = None
    update: Optional[ProjectPutRequest] = None
    delete: Optional[ProjectsDeleteRequest] = None

    @staticmethod
    def from_dict(obj: Any) -> 'ProjectsCommand':
        assert isinstance(obj, dict)
        get = from_union([ProjectGetRequest.from_dict, from_none], obj.get("get"))
        create = from_union([ProjectCreateRequest.from_dict, from_none], obj.get("create"))
        list = from_union([ProjectsListRequest.from_dict, from_none], obj.get("list"))
        update = from_union([ProjectPutRequest.from_dict, from_none], obj.get("update"))
        delete = from_union([ProjectsDeleteRequest.from_dict, from_none], obj.get("delete"))
        return ProjectsCommand(get, create, list, update, delete)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.get is not None:
            result["get"] = from_union([lambda x: to_class(ProjectGetRequest, x), from_none], self.get)
        if self.create is not None:
            result["create"] = from_union([lambda x: to_class(ProjectCreateRequest, x), from_none], self.create)
        if self.list is not None:
            result["list"] = from_union([lambda x: to_class(ProjectsListRequest, x), from_none], self.list)
        if self.update is not None:
            result["update"] = from_union([lambda x: to_class(ProjectPutRequest, x), from_none], self.update)
        if self.delete is not None:
            result["delete"] = from_union([lambda x: to_class(ProjectsDeleteRequest, x), from_none], self.delete)
        return result


@dataclass
class SecretCreateRequest:
    key: str
    note: str
    organization_id: UUID
    """Organization where the secret will be created"""

    value: str
    project_ids: Optional[List[UUID]] = None
    """IDs of the projects that this secret will belong to"""

    @staticmethod
    def from_dict(obj: Any) -> 'SecretCreateRequest':
        assert isinstance(obj, dict)
        key = from_str(obj.get("key"))
        note = from_str(obj.get("note"))
        organization_id = UUID(obj.get("organizationId"))
        value = from_str(obj.get("value"))
        project_ids = from_union([from_none, lambda x: from_list(lambda x: UUID(x), x)], obj.get("projectIds"))
        return SecretCreateRequest(key, note, organization_id, value, project_ids)

    def to_dict(self) -> dict:
        result: dict = {}
        result["key"] = from_str(self.key)
        result["note"] = from_str(self.note)
        result["organizationId"] = str(self.organization_id)
        result["value"] = from_str(self.value)
        if self.project_ids is not None:
            result["projectIds"] = from_union([from_none, lambda x: from_list(lambda x: str(x), x)], self.project_ids)
        return result


@dataclass
class SecretsDeleteRequest:
    ids: List[UUID]
    """IDs of the secrets to delete"""

    @staticmethod
    def from_dict(obj: Any) -> 'SecretsDeleteRequest':
        assert isinstance(obj, dict)
        ids = from_list(lambda x: UUID(x), obj.get("ids"))
        return SecretsDeleteRequest(ids)

    def to_dict(self) -> dict:
        result: dict = {}
        result["ids"] = from_list(lambda x: str(x), self.ids)
        return result


@dataclass
class SecretGetRequest:
    id: UUID
    """ID of the secret to retrieve"""

    @staticmethod
    def from_dict(obj: Any) -> 'SecretGetRequest':
        assert isinstance(obj, dict)
        id = UUID(obj.get("id"))
        return SecretGetRequest(id)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = str(self.id)
        return result


@dataclass
class SecretsGetRequest:
    ids: List[UUID]
    """IDs of the secrets to retrieve"""

    @staticmethod
    def from_dict(obj: Any) -> 'SecretsGetRequest':
        assert isinstance(obj, dict)
        ids = from_list(lambda x: UUID(x), obj.get("ids"))
        return SecretsGetRequest(ids)

    def to_dict(self) -> dict:
        result: dict = {}
        result["ids"] = from_list(lambda x: str(x), self.ids)
        return result


@dataclass
class SecretIdentifiersRequest:
    organization_id: UUID
    """Organization to retrieve all the secrets from"""

    @staticmethod
    def from_dict(obj: Any) -> 'SecretIdentifiersRequest':
        assert isinstance(obj, dict)
        organization_id = UUID(obj.get("organizationId"))
        return SecretIdentifiersRequest(organization_id)

    def to_dict(self) -> dict:
        result: dict = {}
        result["organizationId"] = str(self.organization_id)
        return result


@dataclass
class SecretsSyncRequest:
    organization_id: UUID
    """Organization to sync secrets from"""

    last_synced_date: Optional[datetime] = None
    """Optional date time a sync last occurred"""

    @staticmethod
    def from_dict(obj: Any) -> 'SecretsSyncRequest':
        assert isinstance(obj, dict)
        organization_id = UUID(obj.get("organizationId"))
        last_synced_date = from_union([from_none, from_datetime], obj.get("lastSyncedDate"))
        return SecretsSyncRequest(organization_id, last_synced_date)

    def to_dict(self) -> dict:
        result: dict = {}
        result["organizationId"] = str(self.organization_id)
        if self.last_synced_date is not None:
            result["lastSyncedDate"] = from_union([from_none, lambda x: x.isoformat()], self.last_synced_date)
        return result


@dataclass
class SecretPutRequest:
    id: UUID
    """ID of the secret to modify"""

    key: str
    note: str
    organization_id: UUID
    """Organization ID of the secret to modify"""

    value: str
    project_ids: Optional[List[UUID]] = None

    @staticmethod
    def from_dict(obj: Any) -> 'SecretPutRequest':
        assert isinstance(obj, dict)
        id = UUID(obj.get("id"))
        key = from_str(obj.get("key"))
        note = from_str(obj.get("note"))
        organization_id = UUID(obj.get("organizationId"))
        value = from_str(obj.get("value"))
        project_ids = from_union([from_none, lambda x: from_list(lambda x: UUID(x), x)], obj.get("projectIds"))
        return SecretPutRequest(id, key, note, organization_id, value, project_ids)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = str(self.id)
        result["key"] = from_str(self.key)
        result["note"] = from_str(self.note)
        result["organizationId"] = str(self.organization_id)
        result["value"] = from_str(self.value)
        if self.project_ids is not None:
            result["projectIds"] = from_union([from_none, lambda x: from_list(lambda x: str(x), x)], self.project_ids)
        return result


@dataclass
class SecretsCommand:
    """* Requires Authentication
    * Requires using an Access Token for login or calling Sync at least once
    
    Retrieve a secret by the provided identifier
    
    Returns: [SecretResponse](bitwarden::secrets_manager::secrets::SecretResponse)
    
    * Requires Authentication
    * Requires using an Access Token for login or calling Sync at least once
    
    Retrieve secrets by the provided identifiers
    
    Returns: [SecretsResponse](bitwarden::secrets_manager::secrets::SecretsResponse)
    
    * Requires Authentication
    * Requires using an Access Token for login or calling Sync at least once
    
    Creates a new secret in the provided organization using the given data
    
    Returns: [SecretResponse](bitwarden::secrets_manager::secrets::SecretResponse)
    
    * Requires Authentication
    * Requires using an Access Token for login or calling Sync at least once
    
    Lists all secret identifiers of the given organization, to then retrieve each secret, use
    `CreateSecret`
    
    Returns:
    [SecretIdentifiersResponse](bitwarden::secrets_manager::secrets::SecretIdentifiersResponse)
    
    * Requires Authentication
    * Requires using an Access Token for login or calling Sync at least once
    
    Updates an existing secret with the provided ID using the given data
    
    Returns: [SecretResponse](bitwarden::secrets_manager::secrets::SecretResponse)
    
    * Requires Authentication
    * Requires using an Access Token for login or calling Sync at least once
    
    Deletes all the secrets whose IDs match the provided ones
    
    Returns:
    [SecretsDeleteResponse](bitwarden::secrets_manager::secrets::SecretsDeleteResponse)
    
    * Requires Authentication
    * Requires using an Access Token for login
    
    Retrieve the secrets accessible by the authenticated machine account
    Optionally, provide the last synced date to assess whether any changes have occurred
    If changes are detected, retrieves all the secrets accessible by the authenticated
    machine
    account
    
    Returns: [SecretsSyncResponse](bitwarden::secrets_manager::secrets::SecretsSyncResponse)
    """
    get: Optional[SecretGetRequest] = None
    get_by_ids: Optional[SecretsGetRequest] = None
    create: Optional[SecretCreateRequest] = None
    list: Optional[SecretIdentifiersRequest] = None
    update: Optional[SecretPutRequest] = None
    delete: Optional[SecretsDeleteRequest] = None
    sync: Optional[SecretsSyncRequest] = None

    @staticmethod
    def from_dict(obj: Any) -> 'SecretsCommand':
        assert isinstance(obj, dict)
        get = from_union([SecretGetRequest.from_dict, from_none], obj.get("get"))
        get_by_ids = from_union([SecretsGetRequest.from_dict, from_none], obj.get("getByIds"))
        create = from_union([SecretCreateRequest.from_dict, from_none], obj.get("create"))
        list = from_union([SecretIdentifiersRequest.from_dict, from_none], obj.get("list"))
        update = from_union([SecretPutRequest.from_dict, from_none], obj.get("update"))
        delete = from_union([SecretsDeleteRequest.from_dict, from_none], obj.get("delete"))
        sync = from_union([SecretsSyncRequest.from_dict, from_none], obj.get("sync"))
        return SecretsCommand(get, get_by_ids, create, list, update, delete, sync)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.get is not None:
            result["get"] = from_union([lambda x: to_class(SecretGetRequest, x), from_none], self.get)
        if self.get_by_ids is not None:
            result["getByIds"] = from_union([lambda x: to_class(SecretsGetRequest, x), from_none], self.get_by_ids)
        if self.create is not None:
            result["create"] = from_union([lambda x: to_class(SecretCreateRequest, x), from_none], self.create)
        if self.list is not None:
            result["list"] = from_union([lambda x: to_class(SecretIdentifiersRequest, x), from_none], self.list)
        if self.update is not None:
            result["update"] = from_union([lambda x: to_class(SecretPutRequest, x), from_none], self.update)
        if self.delete is not None:
            result["delete"] = from_union([lambda x: to_class(SecretsDeleteRequest, x), from_none], self.delete)
        if self.sync is not None:
            result["sync"] = from_union([lambda x: to_class(SecretsSyncRequest, x), from_none], self.sync)
        return result


@dataclass
class Command:
    """Login with Secrets Manager Access Token
    
    This command is for initiating an authentication handshake with Bitwarden.
    
    Returns: [ApiKeyLoginResponse](bitwarden::auth::login::ApiKeyLoginResponse)
    """
    login_access_token: Optional[AccessTokenLoginRequest] = None
    secrets: Optional[SecretsCommand] = None
    projects: Optional[ProjectsCommand] = None
    generators: Optional[GeneratorsCommand] = None
    debug: Optional[DebugCommand] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Command':
        assert isinstance(obj, dict)
        login_access_token = from_union([AccessTokenLoginRequest.from_dict, from_none], obj.get("loginAccessToken"))
        secrets = from_union([SecretsCommand.from_dict, from_none], obj.get("secrets"))
        projects = from_union([ProjectsCommand.from_dict, from_none], obj.get("projects"))
        generators = from_union([GeneratorsCommand.from_dict, from_none], obj.get("generators"))
        debug = from_union([DebugCommand.from_dict, from_none], obj.get("debug"))
        return Command(login_access_token, secrets, projects, generators, debug)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.login_access_token is not None:
            result["loginAccessToken"] = from_union([lambda x: to_class(AccessTokenLoginRequest, x), from_none], self.login_access_token)
        if self.secrets is not None:
            result["secrets"] = from_union([lambda x: to_class(SecretsCommand, x), from_none], self.secrets)
        if self.projects is not None:
            result["projects"] = from_union([lambda x: to_class(ProjectsCommand, x), from_none], self.projects)
        if self.generators is not None:
            result["generators"] = from_union([lambda x: to_class(GeneratorsCommand, x), from_none], self.generators)
        if self.debug is not None:
            result["debug"] = from_union([lambda x: to_class(DebugCommand, x), from_none], self.debug)
        return result


@dataclass
class Authenticator:
    pass

    @staticmethod
    def from_dict(obj: Any) -> 'Authenticator':
        assert isinstance(obj, dict)
        return Authenticator()

    def to_dict(self) -> dict:
        result: dict = {}
        return result


@dataclass
class Duo:
    host: str
    signature: str

    @staticmethod
    def from_dict(obj: Any) -> 'Duo':
        assert isinstance(obj, dict)
        host = from_str(obj.get("host"))
        signature = from_str(obj.get("signature"))
        return Duo(host, signature)

    def to_dict(self) -> dict:
        result: dict = {}
        result["host"] = from_str(self.host)
        result["signature"] = from_str(self.signature)
        return result


@dataclass
class Email:
    email: str
    """The email to request a 2fa TOTP for"""

    @staticmethod
    def from_dict(obj: Any) -> 'Email':
        assert isinstance(obj, dict)
        email = from_str(obj.get("email"))
        return Email(email)

    def to_dict(self) -> dict:
        result: dict = {}
        result["email"] = from_str(self.email)
        return result


@dataclass
class Remember:
    pass

    @staticmethod
    def from_dict(obj: Any) -> 'Remember':
        assert isinstance(obj, dict)
        return Remember()

    def to_dict(self) -> dict:
        result: dict = {}
        return result


@dataclass
class WebAuthn:
    pass

    @staticmethod
    def from_dict(obj: Any) -> 'WebAuthn':
        assert isinstance(obj, dict)
        return WebAuthn()

    def to_dict(self) -> dict:
        result: dict = {}
        return result


@dataclass
class YubiKey:
    nfc: bool
    """Whether the stored yubikey supports near field communication"""

    @staticmethod
    def from_dict(obj: Any) -> 'YubiKey':
        assert isinstance(obj, dict)
        nfc = from_bool(obj.get("nfc"))
        return YubiKey(nfc)

    def to_dict(self) -> dict:
        result: dict = {}
        result["nfc"] = from_bool(self.nfc)
        return result


@dataclass
class TwoFactorProviders:
    authenticator: Optional[Authenticator] = None
    duo: Optional[Duo] = None
    """Duo-backed 2fa"""

    email: Optional[Email] = None
    """Email 2fa"""

    organization_duo: Optional[Duo] = None
    """Duo-backed 2fa operated by an organization the user is a member of"""

    remember: Optional[Remember] = None
    """Presence indicates the user has stored this device as bypassing 2fa"""

    web_authn: Optional[WebAuthn] = None
    """WebAuthn-backed 2fa"""

    yubi_key: Optional[YubiKey] = None
    """Yubikey-backed 2fa"""

    @staticmethod
    def from_dict(obj: Any) -> 'TwoFactorProviders':
        assert isinstance(obj, dict)
        authenticator = from_union([Authenticator.from_dict, from_none], obj.get("authenticator"))
        duo = from_union([Duo.from_dict, from_none], obj.get("duo"))
        email = from_union([Email.from_dict, from_none], obj.get("email"))
        organization_duo = from_union([Duo.from_dict, from_none], obj.get("organizationDuo"))
        remember = from_union([Remember.from_dict, from_none], obj.get("remember"))
        web_authn = from_union([WebAuthn.from_dict, from_none], obj.get("webAuthn"))
        yubi_key = from_union([YubiKey.from_dict, from_none], obj.get("yubiKey"))
        return TwoFactorProviders(authenticator, duo, email, organization_duo, remember, web_authn, yubi_key)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.authenticator is not None:
            result["authenticator"] = from_union([lambda x: to_class(Authenticator, x), from_none], self.authenticator)
        if self.duo is not None:
            result["duo"] = from_union([lambda x: to_class(Duo, x), from_none], self.duo)
        if self.email is not None:
            result["email"] = from_union([lambda x: to_class(Email, x), from_none], self.email)
        if self.organization_duo is not None:
            result["organizationDuo"] = from_union([lambda x: to_class(Duo, x), from_none], self.organization_duo)
        if self.remember is not None:
            result["remember"] = from_union([lambda x: to_class(Remember, x), from_none], self.remember)
        if self.web_authn is not None:
            result["webAuthn"] = from_union([lambda x: to_class(WebAuthn, x), from_none], self.web_authn)
        if self.yubi_key is not None:
            result["yubiKey"] = from_union([lambda x: to_class(YubiKey, x), from_none], self.yubi_key)
        return result


@dataclass
class APIKeyLoginResponse:
    authenticated: bool
    force_password_reset: bool
    """Whether or not the user is required to update their master password"""

    reset_master_password: bool
    """TODO: What does this do?"""

    two_factor: Optional[TwoFactorProviders] = None

    @staticmethod
    def from_dict(obj: Any) -> 'APIKeyLoginResponse':
        assert isinstance(obj, dict)
        authenticated = from_bool(obj.get("authenticated"))
        force_password_reset = from_bool(obj.get("forcePasswordReset"))
        reset_master_password = from_bool(obj.get("resetMasterPassword"))
        two_factor = from_union([TwoFactorProviders.from_dict, from_none], obj.get("twoFactor"))
        return APIKeyLoginResponse(authenticated, force_password_reset, reset_master_password, two_factor)

    def to_dict(self) -> dict:
        result: dict = {}
        result["authenticated"] = from_bool(self.authenticated)
        result["forcePasswordReset"] = from_bool(self.force_password_reset)
        result["resetMasterPassword"] = from_bool(self.reset_master_password)
        if self.two_factor is not None:
            result["twoFactor"] = from_union([lambda x: to_class(TwoFactorProviders, x), from_none], self.two_factor)
        return result


@dataclass
class ResponseForAPIKeyLoginResponse:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[APIKeyLoginResponse] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForAPIKeyLoginResponse':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([APIKeyLoginResponse.from_dict, from_none], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForAPIKeyLoginResponse(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(APIKeyLoginResponse, x), from_none], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


@dataclass
class PasswordLoginResponse:
    authenticated: bool
    force_password_reset: bool
    """Whether or not the user is required to update their master password"""

    reset_master_password: bool
    """TODO: What does this do?"""

    two_factor: Optional[TwoFactorProviders] = None
    """The available two factor authentication options. Present only when authentication fails
    due
    to requiring a second authentication factor.
    """

    @staticmethod
    def from_dict(obj: Any) -> 'PasswordLoginResponse':
        assert isinstance(obj, dict)
        authenticated = from_bool(obj.get("authenticated"))
        force_password_reset = from_bool(obj.get("forcePasswordReset"))
        reset_master_password = from_bool(obj.get("resetMasterPassword"))
        two_factor = from_union([TwoFactorProviders.from_dict, from_none], obj.get("twoFactor"))
        return PasswordLoginResponse(authenticated, force_password_reset, reset_master_password, two_factor)

    def to_dict(self) -> dict:
        result: dict = {}
        result["authenticated"] = from_bool(self.authenticated)
        result["forcePasswordReset"] = from_bool(self.force_password_reset)
        result["resetMasterPassword"] = from_bool(self.reset_master_password)
        if self.two_factor is not None:
            result["twoFactor"] = from_union([lambda x: to_class(TwoFactorProviders, x), from_none], self.two_factor)
        return result


@dataclass
class ResponseForPasswordLoginResponse:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[PasswordLoginResponse] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForPasswordLoginResponse':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([PasswordLoginResponse.from_dict, from_none], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForPasswordLoginResponse(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(PasswordLoginResponse, x), from_none], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


@dataclass
class AccessTokenLoginResponse:
    authenticated: bool
    force_password_reset: bool
    """Whether or not the user is required to update their master password"""

    reset_master_password: bool
    """TODO: What does this do?"""

    two_factor: Optional[TwoFactorProviders] = None

    @staticmethod
    def from_dict(obj: Any) -> 'AccessTokenLoginResponse':
        assert isinstance(obj, dict)
        authenticated = from_bool(obj.get("authenticated"))
        force_password_reset = from_bool(obj.get("forcePasswordReset"))
        reset_master_password = from_bool(obj.get("resetMasterPassword"))
        two_factor = from_union([TwoFactorProviders.from_dict, from_none], obj.get("twoFactor"))
        return AccessTokenLoginResponse(authenticated, force_password_reset, reset_master_password, two_factor)

    def to_dict(self) -> dict:
        result: dict = {}
        result["authenticated"] = from_bool(self.authenticated)
        result["forcePasswordReset"] = from_bool(self.force_password_reset)
        result["resetMasterPassword"] = from_bool(self.reset_master_password)
        if self.two_factor is not None:
            result["twoFactor"] = from_union([lambda x: to_class(TwoFactorProviders, x), from_none], self.two_factor)
        return result


@dataclass
class ResponseForAccessTokenLoginResponse:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[AccessTokenLoginResponse] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForAccessTokenLoginResponse':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([AccessTokenLoginResponse.from_dict, from_none], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForAccessTokenLoginResponse(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(AccessTokenLoginResponse, x), from_none], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


@dataclass
class SecretIdentifierResponse:
    id: UUID
    key: str
    organization_id: UUID

    @staticmethod
    def from_dict(obj: Any) -> 'SecretIdentifierResponse':
        assert isinstance(obj, dict)
        id = UUID(obj.get("id"))
        key = from_str(obj.get("key"))
        organization_id = UUID(obj.get("organizationId"))
        return SecretIdentifierResponse(id, key, organization_id)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = str(self.id)
        result["key"] = from_str(self.key)
        result["organizationId"] = str(self.organization_id)
        return result


@dataclass
class SecretIdentifiersResponse:
    data: List[SecretIdentifierResponse]

    @staticmethod
    def from_dict(obj: Any) -> 'SecretIdentifiersResponse':
        assert isinstance(obj, dict)
        data = from_list(SecretIdentifierResponse.from_dict, obj.get("data"))
        return SecretIdentifiersResponse(data)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = from_list(lambda x: to_class(SecretIdentifierResponse, x), self.data)
        return result


@dataclass
class ResponseForSecretIdentifiersResponse:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[SecretIdentifiersResponse] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForSecretIdentifiersResponse':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([SecretIdentifiersResponse.from_dict, from_none], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForSecretIdentifiersResponse(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(SecretIdentifiersResponse, x), from_none], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


@dataclass
class SecretResponse:
    creation_date: datetime
    id: UUID
    key: str
    note: str
    organization_id: UUID
    revision_date: datetime
    value: str
    project_id: Optional[UUID] = None

    @staticmethod
    def from_dict(obj: Any) -> 'SecretResponse':
        assert isinstance(obj, dict)
        creation_date = from_datetime(obj.get("creationDate"))
        id = UUID(obj.get("id"))
        key = from_str(obj.get("key"))
        note = from_str(obj.get("note"))
        organization_id = UUID(obj.get("organizationId"))
        revision_date = from_datetime(obj.get("revisionDate"))
        value = from_str(obj.get("value"))
        project_id = from_union([from_none, lambda x: UUID(x)], obj.get("projectId"))
        return SecretResponse(creation_date, id, key, note, organization_id, revision_date, value, project_id)

    def to_dict(self) -> dict:
        result: dict = {}
        result["creationDate"] = self.creation_date.isoformat()
        result["id"] = str(self.id)
        result["key"] = from_str(self.key)
        result["note"] = from_str(self.note)
        result["organizationId"] = str(self.organization_id)
        result["revisionDate"] = self.revision_date.isoformat()
        result["value"] = from_str(self.value)
        if self.project_id is not None:
            result["projectId"] = from_union([from_none, lambda x: str(x)], self.project_id)
        return result


@dataclass
class ResponseForSecretResponse:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[SecretResponse] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForSecretResponse':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([SecretResponse.from_dict, from_none], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForSecretResponse(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(SecretResponse, x), from_none], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


@dataclass
class SecretsResponse:
    data: List[SecretResponse]

    @staticmethod
    def from_dict(obj: Any) -> 'SecretsResponse':
        assert isinstance(obj, dict)
        data = from_list(SecretResponse.from_dict, obj.get("data"))
        return SecretsResponse(data)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = from_list(lambda x: to_class(SecretResponse, x), self.data)
        return result


@dataclass
class ResponseForSecretsResponse:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[SecretsResponse] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForSecretsResponse':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([SecretsResponse.from_dict, from_none], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForSecretsResponse(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(SecretsResponse, x), from_none], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


@dataclass
class SecretDeleteResponse:
    id: UUID
    error: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'SecretDeleteResponse':
        assert isinstance(obj, dict)
        id = UUID(obj.get("id"))
        error = from_union([from_none, from_str], obj.get("error"))
        return SecretDeleteResponse(id, error)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = str(self.id)
        if self.error is not None:
            result["error"] = from_union([from_none, from_str], self.error)
        return result


@dataclass
class SecretsDeleteResponse:
    data: List[SecretDeleteResponse]

    @staticmethod
    def from_dict(obj: Any) -> 'SecretsDeleteResponse':
        assert isinstance(obj, dict)
        data = from_list(SecretDeleteResponse.from_dict, obj.get("data"))
        return SecretsDeleteResponse(data)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = from_list(lambda x: to_class(SecretDeleteResponse, x), self.data)
        return result


@dataclass
class ResponseForSecretsDeleteResponse:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[SecretsDeleteResponse] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForSecretsDeleteResponse':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([SecretsDeleteResponse.from_dict, from_none], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForSecretsDeleteResponse(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(SecretsDeleteResponse, x), from_none], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


@dataclass
class SecretsSyncResponse:
    has_changes: bool
    secrets: Optional[List[SecretResponse]] = None

    @staticmethod
    def from_dict(obj: Any) -> 'SecretsSyncResponse':
        assert isinstance(obj, dict)
        has_changes = from_bool(obj.get("hasChanges"))
        secrets = from_union([from_none, lambda x: from_list(SecretResponse.from_dict, x)], obj.get("secrets"))
        return SecretsSyncResponse(has_changes, secrets)

    def to_dict(self) -> dict:
        result: dict = {}
        result["hasChanges"] = from_bool(self.has_changes)
        if self.secrets is not None:
            result["secrets"] = from_union([from_none, lambda x: from_list(lambda x: to_class(SecretResponse, x), x)], self.secrets)
        return result


@dataclass
class ResponseForSecretsSyncResponse:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[SecretsSyncResponse] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForSecretsSyncResponse':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([SecretsSyncResponse.from_dict, from_none], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForSecretsSyncResponse(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(SecretsSyncResponse, x), from_none], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


@dataclass
class ProjectResponse:
    creation_date: datetime
    id: UUID
    name: str
    organization_id: UUID
    revision_date: datetime

    @staticmethod
    def from_dict(obj: Any) -> 'ProjectResponse':
        assert isinstance(obj, dict)
        creation_date = from_datetime(obj.get("creationDate"))
        id = UUID(obj.get("id"))
        name = from_str(obj.get("name"))
        organization_id = UUID(obj.get("organizationId"))
        revision_date = from_datetime(obj.get("revisionDate"))
        return ProjectResponse(creation_date, id, name, organization_id, revision_date)

    def to_dict(self) -> dict:
        result: dict = {}
        result["creationDate"] = self.creation_date.isoformat()
        result["id"] = str(self.id)
        result["name"] = from_str(self.name)
        result["organizationId"] = str(self.organization_id)
        result["revisionDate"] = self.revision_date.isoformat()
        return result


@dataclass
class ResponseForProjectResponse:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[ProjectResponse] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForProjectResponse':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([ProjectResponse.from_dict, from_none], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForProjectResponse(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(ProjectResponse, x), from_none], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


@dataclass
class ProjectsResponse:
    data: List[ProjectResponse]

    @staticmethod
    def from_dict(obj: Any) -> 'ProjectsResponse':
        assert isinstance(obj, dict)
        data = from_list(ProjectResponse.from_dict, obj.get("data"))
        return ProjectsResponse(data)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = from_list(lambda x: to_class(ProjectResponse, x), self.data)
        return result


@dataclass
class ResponseForProjectsResponse:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[ProjectsResponse] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForProjectsResponse':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([ProjectsResponse.from_dict, from_none], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForProjectsResponse(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(ProjectsResponse, x), from_none], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


@dataclass
class ProjectDeleteResponse:
    id: UUID
    error: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'ProjectDeleteResponse':
        assert isinstance(obj, dict)
        id = UUID(obj.get("id"))
        error = from_union([from_none, from_str], obj.get("error"))
        return ProjectDeleteResponse(id, error)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = str(self.id)
        if self.error is not None:
            result["error"] = from_union([from_none, from_str], self.error)
        return result


@dataclass
class ProjectsDeleteResponse:
    data: List[ProjectDeleteResponse]

    @staticmethod
    def from_dict(obj: Any) -> 'ProjectsDeleteResponse':
        assert isinstance(obj, dict)
        data = from_list(ProjectDeleteResponse.from_dict, obj.get("data"))
        return ProjectsDeleteResponse(data)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = from_list(lambda x: to_class(ProjectDeleteResponse, x), self.data)
        return result


@dataclass
class ResponseForProjectsDeleteResponse:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[ProjectsDeleteResponse] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForProjectsDeleteResponse':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([ProjectsDeleteResponse.from_dict, from_none], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForProjectsDeleteResponse(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(ProjectsDeleteResponse, x), from_none], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


@dataclass
class ResponseForString:
    success: bool
    """Whether or not the SDK request succeeded."""

    data: Optional[str] = None
    """The response data. Populated if `success` is true."""

    error_message: Optional[str] = None
    """A message for any error that may occur. Populated if `success` is false."""

    @staticmethod
    def from_dict(obj: Any) -> 'ResponseForString':
        assert isinstance(obj, dict)
        success = from_bool(obj.get("success"))
        data = from_union([from_none, from_str], obj.get("data"))
        error_message = from_union([from_none, from_str], obj.get("errorMessage"))
        return ResponseForString(success, data, error_message)

    def to_dict(self) -> dict:
        result: dict = {}
        result["success"] = from_bool(self.success)
        if self.data is not None:
            result["data"] = from_union([from_none, from_str], self.data)
        if self.error_message is not None:
            result["errorMessage"] = from_union([from_none, from_str], self.error_message)
        return result


def client_settings_from_dict(s: Any) -> ClientSettings:
    return ClientSettings.from_dict(s)


def client_settings_to_dict(x: ClientSettings) -> Any:
    return to_class(ClientSettings, x)


def device_type_from_dict(s: Any) -> DeviceType:
    return DeviceType(s)


def device_type_to_dict(x: DeviceType) -> Any:
    return to_enum(DeviceType, x)


def command_from_dict(s: Any) -> Command:
    return Command.from_dict(s)


def command_to_dict(x: Command) -> Any:
    return to_class(Command, x)


def access_token_login_request_from_dict(s: Any) -> AccessTokenLoginRequest:
    return AccessTokenLoginRequest.from_dict(s)


def access_token_login_request_to_dict(x: AccessTokenLoginRequest) -> Any:
    return to_class(AccessTokenLoginRequest, x)


def secrets_command_from_dict(s: Any) -> SecretsCommand:
    return SecretsCommand.from_dict(s)


def secrets_command_to_dict(x: SecretsCommand) -> Any:
    return to_class(SecretsCommand, x)


def secret_get_request_from_dict(s: Any) -> SecretGetRequest:
    return SecretGetRequest.from_dict(s)


def secret_get_request_to_dict(x: SecretGetRequest) -> Any:
    return to_class(SecretGetRequest, x)


def secrets_get_request_from_dict(s: Any) -> SecretsGetRequest:
    return SecretsGetRequest.from_dict(s)


def secrets_get_request_to_dict(x: SecretsGetRequest) -> Any:
    return to_class(SecretsGetRequest, x)


def secret_create_request_from_dict(s: Any) -> SecretCreateRequest:
    return SecretCreateRequest.from_dict(s)


def secret_create_request_to_dict(x: SecretCreateRequest) -> Any:
    return to_class(SecretCreateRequest, x)


def secret_identifiers_request_from_dict(s: Any) -> SecretIdentifiersRequest:
    return SecretIdentifiersRequest.from_dict(s)


def secret_identifiers_request_to_dict(x: SecretIdentifiersRequest) -> Any:
    return to_class(SecretIdentifiersRequest, x)


def secret_put_request_from_dict(s: Any) -> SecretPutRequest:
    return SecretPutRequest.from_dict(s)


def secret_put_request_to_dict(x: SecretPutRequest) -> Any:
    return to_class(SecretPutRequest, x)


def secrets_delete_request_from_dict(s: Any) -> SecretsDeleteRequest:
    return SecretsDeleteRequest.from_dict(s)


def secrets_delete_request_to_dict(x: SecretsDeleteRequest) -> Any:
    return to_class(SecretsDeleteRequest, x)


def secrets_sync_request_from_dict(s: Any) -> SecretsSyncRequest:
    return SecretsSyncRequest.from_dict(s)


def secrets_sync_request_to_dict(x: SecretsSyncRequest) -> Any:
    return to_class(SecretsSyncRequest, x)


def projects_command_from_dict(s: Any) -> ProjectsCommand:
    return ProjectsCommand.from_dict(s)


def projects_command_to_dict(x: ProjectsCommand) -> Any:
    return to_class(ProjectsCommand, x)


def project_get_request_from_dict(s: Any) -> ProjectGetRequest:
    return ProjectGetRequest.from_dict(s)


def project_get_request_to_dict(x: ProjectGetRequest) -> Any:
    return to_class(ProjectGetRequest, x)


def project_create_request_from_dict(s: Any) -> ProjectCreateRequest:
    return ProjectCreateRequest.from_dict(s)


def project_create_request_to_dict(x: ProjectCreateRequest) -> Any:
    return to_class(ProjectCreateRequest, x)


def projects_list_request_from_dict(s: Any) -> ProjectsListRequest:
    return ProjectsListRequest.from_dict(s)


def projects_list_request_to_dict(x: ProjectsListRequest) -> Any:
    return to_class(ProjectsListRequest, x)


def project_put_request_from_dict(s: Any) -> ProjectPutRequest:
    return ProjectPutRequest.from_dict(s)


def project_put_request_to_dict(x: ProjectPutRequest) -> Any:
    return to_class(ProjectPutRequest, x)


def projects_delete_request_from_dict(s: Any) -> ProjectsDeleteRequest:
    return ProjectsDeleteRequest.from_dict(s)


def projects_delete_request_to_dict(x: ProjectsDeleteRequest) -> Any:
    return to_class(ProjectsDeleteRequest, x)


def generators_command_from_dict(s: Any) -> GeneratorsCommand:
    return GeneratorsCommand.from_dict(s)


def generators_command_to_dict(x: GeneratorsCommand) -> Any:
    return to_class(GeneratorsCommand, x)


def password_generator_request_from_dict(s: Any) -> PasswordGeneratorRequest:
    return PasswordGeneratorRequest.from_dict(s)


def password_generator_request_to_dict(x: PasswordGeneratorRequest) -> Any:
    return to_class(PasswordGeneratorRequest, x)


def debug_command_from_dict(s: Any) -> DebugCommand:
    return DebugCommand.from_dict(s)


def debug_command_to_dict(x: DebugCommand) -> Any:
    return to_class(DebugCommand, x)


def response_for_api_key_login_response_from_dict(s: Any) -> ResponseForAPIKeyLoginResponse:
    return ResponseForAPIKeyLoginResponse.from_dict(s)


def response_for_api_key_login_response_to_dict(x: ResponseForAPIKeyLoginResponse) -> Any:
    return to_class(ResponseForAPIKeyLoginResponse, x)


def api_key_login_response_from_dict(s: Any) -> APIKeyLoginResponse:
    return APIKeyLoginResponse.from_dict(s)


def api_key_login_response_to_dict(x: APIKeyLoginResponse) -> Any:
    return to_class(APIKeyLoginResponse, x)


def two_factor_providers_from_dict(s: Any) -> TwoFactorProviders:
    return TwoFactorProviders.from_dict(s)


def two_factor_providers_to_dict(x: TwoFactorProviders) -> Any:
    return to_class(TwoFactorProviders, x)


def authenticator_from_dict(s: Any) -> Authenticator:
    return Authenticator.from_dict(s)


def authenticator_to_dict(x: Authenticator) -> Any:
    return to_class(Authenticator, x)


def email_from_dict(s: Any) -> Email:
    return Email.from_dict(s)


def email_to_dict(x: Email) -> Any:
    return to_class(Email, x)


def duo_from_dict(s: Any) -> Duo:
    return Duo.from_dict(s)


def duo_to_dict(x: Duo) -> Any:
    return to_class(Duo, x)


def yubi_key_from_dict(s: Any) -> YubiKey:
    return YubiKey.from_dict(s)


def yubi_key_to_dict(x: YubiKey) -> Any:
    return to_class(YubiKey, x)


def remember_from_dict(s: Any) -> Remember:
    return Remember.from_dict(s)


def remember_to_dict(x: Remember) -> Any:
    return to_class(Remember, x)


def web_authn_from_dict(s: Any) -> WebAuthn:
    return WebAuthn.from_dict(s)


def web_authn_to_dict(x: WebAuthn) -> Any:
    return to_class(WebAuthn, x)


def response_for_password_login_response_from_dict(s: Any) -> ResponseForPasswordLoginResponse:
    return ResponseForPasswordLoginResponse.from_dict(s)


def response_for_password_login_response_to_dict(x: ResponseForPasswordLoginResponse) -> Any:
    return to_class(ResponseForPasswordLoginResponse, x)


def password_login_response_from_dict(s: Any) -> PasswordLoginResponse:
    return PasswordLoginResponse.from_dict(s)


def password_login_response_to_dict(x: PasswordLoginResponse) -> Any:
    return to_class(PasswordLoginResponse, x)


def response_for_access_token_login_response_from_dict(s: Any) -> ResponseForAccessTokenLoginResponse:
    return ResponseForAccessTokenLoginResponse.from_dict(s)


def response_for_access_token_login_response_to_dict(x: ResponseForAccessTokenLoginResponse) -> Any:
    return to_class(ResponseForAccessTokenLoginResponse, x)


def access_token_login_response_from_dict(s: Any) -> AccessTokenLoginResponse:
    return AccessTokenLoginResponse.from_dict(s)


def access_token_login_response_to_dict(x: AccessTokenLoginResponse) -> Any:
    return to_class(AccessTokenLoginResponse, x)


def response_for_secret_identifiers_response_from_dict(s: Any) -> ResponseForSecretIdentifiersResponse:
    return ResponseForSecretIdentifiersResponse.from_dict(s)


def response_for_secret_identifiers_response_to_dict(x: ResponseForSecretIdentifiersResponse) -> Any:
    return to_class(ResponseForSecretIdentifiersResponse, x)


def secret_identifiers_response_from_dict(s: Any) -> SecretIdentifiersResponse:
    return SecretIdentifiersResponse.from_dict(s)


def secret_identifiers_response_to_dict(x: SecretIdentifiersResponse) -> Any:
    return to_class(SecretIdentifiersResponse, x)


def secret_identifier_response_from_dict(s: Any) -> SecretIdentifierResponse:
    return SecretIdentifierResponse.from_dict(s)


def secret_identifier_response_to_dict(x: SecretIdentifierResponse) -> Any:
    return to_class(SecretIdentifierResponse, x)


def response_for_secret_response_from_dict(s: Any) -> ResponseForSecretResponse:
    return ResponseForSecretResponse.from_dict(s)


def response_for_secret_response_to_dict(x: ResponseForSecretResponse) -> Any:
    return to_class(ResponseForSecretResponse, x)


def secret_response_from_dict(s: Any) -> SecretResponse:
    return SecretResponse.from_dict(s)


def secret_response_to_dict(x: SecretResponse) -> Any:
    return to_class(SecretResponse, x)


def response_for_secrets_response_from_dict(s: Any) -> ResponseForSecretsResponse:
    return ResponseForSecretsResponse.from_dict(s)


def response_for_secrets_response_to_dict(x: ResponseForSecretsResponse) -> Any:
    return to_class(ResponseForSecretsResponse, x)


def secrets_response_from_dict(s: Any) -> SecretsResponse:
    return SecretsResponse.from_dict(s)


def secrets_response_to_dict(x: SecretsResponse) -> Any:
    return to_class(SecretsResponse, x)


def response_for_secrets_delete_response_from_dict(s: Any) -> ResponseForSecretsDeleteResponse:
    return ResponseForSecretsDeleteResponse.from_dict(s)


def response_for_secrets_delete_response_to_dict(x: ResponseForSecretsDeleteResponse) -> Any:
    return to_class(ResponseForSecretsDeleteResponse, x)


def secrets_delete_response_from_dict(s: Any) -> SecretsDeleteResponse:
    return SecretsDeleteResponse.from_dict(s)


def secrets_delete_response_to_dict(x: SecretsDeleteResponse) -> Any:
    return to_class(SecretsDeleteResponse, x)


def secret_delete_response_from_dict(s: Any) -> SecretDeleteResponse:
    return SecretDeleteResponse.from_dict(s)


def secret_delete_response_to_dict(x: SecretDeleteResponse) -> Any:
    return to_class(SecretDeleteResponse, x)


def response_for_secrets_sync_response_from_dict(s: Any) -> ResponseForSecretsSyncResponse:
    return ResponseForSecretsSyncResponse.from_dict(s)


def response_for_secrets_sync_response_to_dict(x: ResponseForSecretsSyncResponse) -> Any:
    return to_class(ResponseForSecretsSyncResponse, x)


def secrets_sync_response_from_dict(s: Any) -> SecretsSyncResponse:
    return SecretsSyncResponse.from_dict(s)


def secrets_sync_response_to_dict(x: SecretsSyncResponse) -> Any:
    return to_class(SecretsSyncResponse, x)


def response_for_project_response_from_dict(s: Any) -> ResponseForProjectResponse:
    return ResponseForProjectResponse.from_dict(s)


def response_for_project_response_to_dict(x: ResponseForProjectResponse) -> Any:
    return to_class(ResponseForProjectResponse, x)


def project_response_from_dict(s: Any) -> ProjectResponse:
    return ProjectResponse.from_dict(s)


def project_response_to_dict(x: ProjectResponse) -> Any:
    return to_class(ProjectResponse, x)


def response_for_projects_response_from_dict(s: Any) -> ResponseForProjectsResponse:
    return ResponseForProjectsResponse.from_dict(s)


def response_for_projects_response_to_dict(x: ResponseForProjectsResponse) -> Any:
    return to_class(ResponseForProjectsResponse, x)


def projects_response_from_dict(s: Any) -> ProjectsResponse:
    return ProjectsResponse.from_dict(s)


def projects_response_to_dict(x: ProjectsResponse) -> Any:
    return to_class(ProjectsResponse, x)


def response_for_projects_delete_response_from_dict(s: Any) -> ResponseForProjectsDeleteResponse:
    return ResponseForProjectsDeleteResponse.from_dict(s)


def response_for_projects_delete_response_to_dict(x: ResponseForProjectsDeleteResponse) -> Any:
    return to_class(ResponseForProjectsDeleteResponse, x)


def projects_delete_response_from_dict(s: Any) -> ProjectsDeleteResponse:
    return ProjectsDeleteResponse.from_dict(s)


def projects_delete_response_to_dict(x: ProjectsDeleteResponse) -> Any:
    return to_class(ProjectsDeleteResponse, x)


def project_delete_response_from_dict(s: Any) -> ProjectDeleteResponse:
    return ProjectDeleteResponse.from_dict(s)


def project_delete_response_to_dict(x: ProjectDeleteResponse) -> Any:
    return to_class(ProjectDeleteResponse, x)


def response_for_string_from_dict(s: Any) -> ResponseForString:
    return ResponseForString.from_dict(s)


def response_for_string_to_dict(x: ResponseForString) -> Any:
    return to_class(ResponseForString, x)

