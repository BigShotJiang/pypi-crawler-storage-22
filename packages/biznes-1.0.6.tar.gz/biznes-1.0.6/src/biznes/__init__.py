"""
Biznes - Edukacyjna gra symulująca zakładanie startupu w Polsce
"""

__version__ = "1.0.0"
__author__ = "Softreck"

from .shell import BiznesShell, main

__all__ = ["BiznesShell", "main"]
