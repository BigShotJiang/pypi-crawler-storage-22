"""
Biznes - Entry point dla uruchamiania jako moduł
python -m biznes
"""

from .shell import main

if __name__ == "__main__":
    main()
