"""Allow running the package directly: python -m bjam_toolbox"""

from bjam_toolbox.launcher import main

if __name__ == "__main__":
    main()
