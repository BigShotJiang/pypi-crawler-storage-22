"""BJAM Toolbox — default configuration and config loader."""
