"""Backwards-compatibility shim — all config lives in pyproject.toml."""
from setuptools import setup

setup()
