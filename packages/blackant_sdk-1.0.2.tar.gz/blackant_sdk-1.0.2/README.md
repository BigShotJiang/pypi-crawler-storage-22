# Python REST API docker template

A simple template to implement REST APIs using Python Flask & docker.

## Build arguments

### INSTALL_DEBUG_TOOLS

If it's set to True, ptvsd is installed during build to be able to do live debugging.

## Environment variables

### CALCULATION_NAME

Name of the calculation. Mandatory parameter.

### SERVER_PORT

Port which on the server runs. Default: 5000

### DEBUG_MODE

A switch to select between debug and release mode. If it is set to True, a Flask server will be started in debug mode and a ptvsd server. Otherwise, it is served using gevent production server. Default: False

### OBJECT_STORAGE_URL

Url for the object storage. Mandatory if the code uses object storage.

### OBJECT_STORAGE_ACCESS_KEY

Public key for the object storage.

### OBJECT_STORAGE_SECRET_KEY

Private key for the object storage.

### SCHEDULER_URL

Callback url of the scheduler.

## Commands

### Build

```sh
docker-compose build
```

### Run

```sh
docker-compose up
```

### Create task

You can use the tools/send_request.py script to send a simple request to the calculation container.

### Debug

If you use Visual Studio Code, there is a debug configuration called Python: Remote Attach which will start a debug session and connect to your running container.

## Documentation

Full HTML and PDF documentation can be generated from any revision using the generate_documentation job in the CI.
After the job have run successfully, the artifacts are stored for one day.
If it's necessary it can be rerun any time.


......
