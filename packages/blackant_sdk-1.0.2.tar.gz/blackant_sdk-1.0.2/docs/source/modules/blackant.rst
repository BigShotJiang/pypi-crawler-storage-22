BlackAnt Core Module
====================

The BlackAnt core module provides the main entry point and common functionality
for the BlackAnt SDK. It includes the primary client interface, exception handling,
and core utilities that are used throughout the framework.

.. automodule:: blackant
   :members:
   :undoc-members:
   :show-inheritance:

Core Client
-----------

Main BlackAnt client providing unified access to all SDK functionality.

.. automodule:: blackant.client
   :members:
   :undoc-members:
   :show-inheritance:

Exception Handling
------------------

Core exception classes and error handling utilities.

.. automodule:: blackant.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

The BlackAnt SDK is organized into the following major modules:

.. toctree::
   :maxdepth: 2

   auth
   docker
   http
   api
   services
   config
   utils
   patterns