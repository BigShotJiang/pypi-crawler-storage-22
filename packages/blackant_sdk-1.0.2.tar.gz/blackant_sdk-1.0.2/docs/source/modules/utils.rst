Utils Module
============

This module provides essential utility functions and services for the BlackAnt SDK,
including logging, caching, serialization, validation, and cryptographic operations.

.. automodule:: blackant.utils
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

Logging
~~~~~~~

Centralized logging system with colorized output, request tracking, and sensitive data filtering.

.. automodule:: blackant.utils.logging
   :members:
   :undoc-members:
   :show-inheritance:

Caching
~~~~~~~

Thread-safe caching mechanisms for improved performance.

.. automodule:: blackant.utils.cache
   :members:
   :undoc-members:
   :show-inheritance:

Serialization
~~~~~~~~~~~~~

JSON and binary serialization utilities with type safety.

.. automodule:: blackant.utils.serialization
   :members:
   :undoc-members:
   :show-inheritance:

Validation
~~~~~~~~~~

Input validation and data integrity checking utilities.

.. automodule:: blackant.utils.validation
   :members:
   :undoc-members:
   :show-inheritance:

Cryptography
~~~~~~~~~~~~

Cryptographic utilities for secure operations.

.. automodule:: blackant.utils.crypto
   :members:
   :undoc-members:
   :show-inheritance:

State Management
~~~~~~~~~~~~~~~~

State management utilities for application lifecycle.

.. automodule:: blackant.utils.state
   :members:
   :undoc-members:
   :show-inheritance:

Request ID
~~~~~~~~~~

Request tracking and correlation ID management.

.. automodule:: blackant.utils.request_id
   :members:
   :undoc-members:
   :show-inheritance:

Storage
~~~~~~~

Generic storage abstraction layer.

.. automodule:: blackant.utils.store
   :members:
   :undoc-members:
   :show-inheritance: