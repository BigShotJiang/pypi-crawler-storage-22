"""BlackAnt SDK package.

Main entry point for BlackAnt SDK providing Docker operations
with automatic authentication through BlackAnt platform.
"""

from .client import BlackAntClient
from .auth import BlackAntAuth
from .docker import BlackAntDockerClient
from .services import ServiceRegistry
from .exceptions import (
    BlackAntException,
    BlackAntAuthenticationError,
    BlackAntDockerError,
    BlackAntConnectionError,
    BlackAntConfigurationError
)

__version__ = "1.0.0"

__all__ = [
    "BlackAntClient",
    "BlackAntAuth",
    "BlackAntDockerClient",
    "ServiceRegistry",
    "BlackAntException",
    "BlackAntAuthenticationError",
    "BlackAntDockerError",
    "BlackAntConnectionError",
    "BlackAntConfigurationError"
]
