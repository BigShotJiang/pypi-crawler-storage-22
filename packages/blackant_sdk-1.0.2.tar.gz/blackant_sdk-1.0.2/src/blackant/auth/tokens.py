"""Authentication token storage module.

Provides storage for user and admin authentication tokens
using the Store base class with thread-safe access.
"""

from ..utils.store import Store


class AuthTokenStore(Store):
    """Authentication token storage class.

    Stores user and admin authentication tokens for later use
    in API requests. Uses thread-local storage for thread safety.
    """

    @property
    def user_token(self):
        """str or None: User-level Bearer token for API authentication."""
        return self._get("user")

    @user_token.setter
    def user_token(self, value):
        """Set the user-level Bearer token.

        Args:
            value (str or None): The Bearer token string or None to clear.
        """
        self._set("user", value)

    @property
    def admin_token(self):
        """str or None: Admin-level Bearer token for privileged API access."""
        return self._get("admin")

    @admin_token.setter
    def admin_token(self, value):
        """Set the admin-level Bearer token.

        Args:
            value (str or None): The admin Bearer token string or None to clear.
        """
        self._set("admin", value)

    def clean_up(self):
        """Clean up stored tokens.

        Removes both user and admin tokens from storage.
        """
        try:
            self._del("user")
        except AttributeError:
            pass
        try:
            self._del("admin")
        except AttributeError:
            pass
