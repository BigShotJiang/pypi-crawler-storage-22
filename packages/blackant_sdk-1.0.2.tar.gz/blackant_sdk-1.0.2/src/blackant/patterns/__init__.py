"""Pattern implementations for BlackAnt SDK."""
