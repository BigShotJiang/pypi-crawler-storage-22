"""Singleton pattern implementation for BlackAnt SDK."""

import threading


class Singleton(type):
    """Singleton metaclass implementation.

    Thread-safe singleton pattern using metaclass approach.
    Ensures only one instance per class exists across the application.
    """
    _instances = {}
    _lock = threading.Lock()

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            with cls._lock:
                if cls not in cls._instances:
                    cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]
