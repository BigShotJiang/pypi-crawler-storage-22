"""BlackAnt Services module.

Service registry and lifecycle management components with both
HTTP API (external) and Docker SDK (internal) support.
"""

from .registry import ServiceRegistry
from .dao import ServiceManagerDAO

__all__ = ["ServiceRegistry", "ServiceManagerDAO"]
