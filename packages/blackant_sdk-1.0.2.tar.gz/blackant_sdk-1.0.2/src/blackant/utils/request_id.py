import uuid
import time


class RequestIdGenerator:  # pylint: disable=too-few-public-methods
    def __init__(self, header_name="X-Request-ID"):
        self.header_name = header_name
        self._counter = 0

    def generate_id(self):
        self._counter += 1
        timestamp = int(time.time() * 1000)
        return f"req_{timestamp}_{self._counter}_{uuid.uuid4().hex[:8]}"
