import abc


class CalculationBase:
    def __init__(self, logger):
        self._logger = logger

    @abc.abstractproperty
    def result(self):
        raise NotImplementedError

    @abc.abstractmethod
    def set_up(self):
        raise NotImplementedError

    @abc.abstractmethod
    def run(self):
        raise NotImplementedError

    @abc.abstractmethod
    def tear_down(self):
        raise NotImplementedError

    @abc.abstractmethod
    def stop(self):
        raise NotImplementedError
