#!/usr/bin/env python3
"""Simple calculation implementation for BlackAnt SDK build_service testing."""

import json
import time
import os
from datetime import datetime


def calculate(data):
    """Simple calculation function.

    Args:
        data: Input data dictionary with 'numbers' list

    Returns:
        dict: Calculation result
    """
    numbers = data.get('numbers', [])

    # Simple calculation: sum of numbers
    result = sum(numbers)

    # Add some processing time to simulate real calculation
    time.sleep(0.5)

    return {
        'result': result,
        'count': len(numbers),
        'average': result / len(numbers) if numbers else 0,
        'timestamp': datetime.now().isoformat(),
        'service_name': os.getenv('SERVICE_NAME', 'simple-calc')
    }


def main():
    """Main function for standalone execution."""
    # Test data
    test_data = {
        'numbers': [1, 2, 3, 4, 5, 10, 15, 20]
    }

    print("🧮 BlackAnt Calculation Service Starting...")
    print(f"📊 Input data: {test_data}")

    result = calculate(test_data)

    print(f"✅ Calculation completed: {json.dumps(result, indent=2)}")
    print("🎯 Service ready for BlackAnt deployment!")


if __name__ == '__main__':
    main()