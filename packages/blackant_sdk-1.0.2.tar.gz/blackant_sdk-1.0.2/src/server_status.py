#!/usr/bin/python3

import enum

from blackant.patterns.singleton import Singleton


class ServerStatus(enum.Enum):
    OK = 1
    FAILED = 2


class ServerStatusStore(metaclass=Singleton):
    __status = ServerStatus.OK
    __message = ""

    @property
    def status(self) -> ServerStatus:
        return self.__status

    @status.setter
    def status(self, value: ServerStatus) -> None:
        self.__status = value

    @property
    def message(self) -> str:
        return self.__message

    @message.setter
    def message(self, value: str) -> None:
        self.__message = value
