class InvalidStorageUsageException(Exception):
    pass


class StorageOperationFailedException(Exception):
    pass


class StorageCreationFailedException(Exception):
    pass
