import abc

from flask_restful import reqparse


class RequestParserBase(reqparse.RequestParser):
    @abc.abstractmethod
    def validate(self, request):
        pass

    @abc.abstractmethod
    def parse(self, request):
        pass
