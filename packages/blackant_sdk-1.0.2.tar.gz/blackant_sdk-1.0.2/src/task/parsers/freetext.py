import werkzeug.exceptions

from task.parsers.base import RequestParserBase


class FreeTextInputParser(RequestParserBase):
    def __init__(self, loc):
        super().__init__()

        self.__loc = loc

    def validate(self, request):
        if not isinstance(request[self.__loc], str):
            raise werkzeug.exceptions.BadRequest("Freetext input must be text type")

    def parse(self, request):
        if not request or self.__loc not in request.keys():
            return ""
        return request[self.__loc]
