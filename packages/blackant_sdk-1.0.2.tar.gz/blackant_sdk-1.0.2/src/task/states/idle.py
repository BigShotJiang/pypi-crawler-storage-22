from task.states.base import TaskStateBase
from task.states.set_up import TaskSetUpState


class TaskIdleState(TaskStateBase):
    @property
    def name(self):
        return "idle"

    def run(self):
        self._task.logger.info("Start processing")
        self._task.change_state(TaskSetUpState(self._task))
