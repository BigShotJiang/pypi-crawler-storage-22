from calculation.errors import CalculationError

from task.states.base import TaskStateBase
from task.states.error import TaskErrorState
from task.states.tear_down import TaskTearDownState


class TaskRunningState(TaskStateBase):
    @property
    def name(self):
        return "running"

    def run(self):
        try:
            self._task.logger.info("Running calculation")
            self._task.calculation.run()
            self._task.change_state(TaskTearDownState(self._task))
        except CalculationError as calculation_error:
            self._task.logger.error("Calculation error occurred during running phase")
            self._task.logger.exception(calculation_error)
            self._task.change_state(TaskErrorState(self._task))
