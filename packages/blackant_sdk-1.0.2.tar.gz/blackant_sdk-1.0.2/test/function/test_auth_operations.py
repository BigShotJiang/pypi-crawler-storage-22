#!/usr/bin/env python3
"""Authentication and authorization functional tests.

Tests BlackAnt authentication functionality.
"""

import sys
import os
import unittest

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'src'))

from blackant import BlackAntAuth


class TestAuthOperations(unittest.TestCase):
    """Test authentication operations."""

    def setUp(self):
        """Set up test environment."""
        # Get credentials from environment variables
        test_user = os.getenv("BLACKANT_TEST_USER", "admin")
        test_password = os.getenv("BLACKANT_TEST_PASSWORD")

        if not test_password:
            self.skipTest("BLACKANT_TEST_PASSWORD not set in environment")

        self.auth = BlackAntAuth(
            user=test_user,
            password=test_password,
            login_url=os.getenv("BLACKANT_LOGIN_URL", "http://localhost/api/auth/login")
        )

    def test_authentication(self):
        """Test basic authentication."""
        token = self.auth.get_token()
        self.assertIsInstance(token, str)
        self.assertNotEqual(token, "")
        self.assertTrue(token.startswith("eyJ"))  # JWT format

    def test_is_authenticated(self):
        """Test authentication status check."""
        # Should be False initially
        self.assertFalse(self.auth.is_authenticated())

        # Should be True after getting token
        self.auth.get_token()
        self.assertTrue(self.auth.is_authenticated())


    def test_logout(self):
        """Test logout functionality."""
        # Get token first
        self.auth.get_token()
        self.assertTrue(self.auth.is_authenticated())

        # Logout
        self.auth.logout()
        self.assertFalse(self.auth.is_authenticated())


if __name__ == '__main__':
    unittest.main(verbosity=2)