"""Unit tests for AuthTokenStore."""

import unittest
from src.blackant.auth.tokens import AuthTokenStore


class TestAuthTokenStore(unittest.TestCase):
    """Test cases for AuthTokenStore."""

    def setUp(self):
        """Set up test fixtures."""
        self.store = AuthTokenStore()
        self.store.clean_up()  # Ensure clean state

    def tearDown(self):
        """Clean up after tests."""
        self.store.clean_up()

    def test_user_token_property(self):
        """Test user token property getter and setter."""
        # Initially should be None
        self.assertIsNone(self.store.user_token)

        # Set and get user token
        test_token = "user_token_123"
        self.store.user_token = test_token
        self.assertEqual(self.store.user_token, test_token)

    def test_admin_token_property(self):
        """Test admin token property getter and setter."""
        # Initially should be None
        self.assertIsNone(self.store.admin_token)

        # Set and get admin token
        test_token = "admin_token_456"
        self.store.admin_token = test_token
        self.assertEqual(self.store.admin_token, test_token)

    def test_both_tokens_independent(self):
        """Test that user and admin tokens are independent."""
        user_token = "user_123"
        admin_token = "admin_456"

        self.store.user_token = user_token
        self.store.admin_token = admin_token

        self.assertEqual(self.store.user_token, user_token)
        self.assertEqual(self.store.admin_token, admin_token)

    def test_clean_up(self):
        """Test that clean_up removes all tokens."""
        self.store.user_token = "user_token"
        self.store.admin_token = "admin_token"

        self.store.clean_up()

        self.assertIsNone(self.store.user_token)
        self.assertIsNone(self.store.admin_token)

    def test_singleton_behavior(self):
        """Test that AuthTokenStore behaves as singleton."""
        store1 = AuthTokenStore()
        store2 = AuthTokenStore()

        self.assertIs(store1, store2)

        store1.user_token = "shared_token"
        self.assertEqual(store2.user_token, "shared_token")


if __name__ == "__main__":
    unittest.main()