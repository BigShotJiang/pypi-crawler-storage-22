"""Integration tests for HTTP module."""

import unittest
from unittest.mock import patch
import requests_mock
from src.blackant.http.client import HTTPClient


class TestHTTPIntegration(unittest.TestCase):
    """Integration test cases for HTTP module."""

    def setUp(self):
        """Set up test fixtures."""
        with patch('src.blackant.http.client.get_logger'), \
                patch('src.blackant.http.client.set_request_id'), \
                patch('src.blackant.http.client.clear_request_id'):
            self.client = HTTPClient("https://api.blackant.app")

    @requests_mock.Mocker()
    def test_full_request_cycle(self, mock_requests):
        """Test complete request cycle with authentication."""
        # Setup mock response
        mock_requests.get(
            "https://api.blackant.app/api/v1/services",
            json={"services": []},
            status_code=200
        )

        # Set authentication token
        self.client.auth_token_store.user_token = "test_user_token"

        # Make request
        with patch('src.blackant.http.client.set_request_id'), \
                patch('src.blackant.http.client.clear_request_id'):
            response = self.client.send_request("/api/v1/services", "GET")

        # Verify response
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"services": []})

        # Verify request was made with correct headers
        request_history = mock_requests.request_history[0]
        self.assertEqual(request_history.headers["Authorization"], "Bearer test_user_token")
        self.assertIn("X-Request-ID", request_history.headers)

    @requests_mock.Mocker()
    def test_post_request_with_json(self, mock_requests):
        """Test POST request with JSON payload."""
        # Setup mock response
        mock_requests.post(
            "https://api.blackant.app/api/v1/services",
            json={"id": "123", "name": "test-service"},
            status_code=201
        )

        # Prepare test data
        test_data = {"name": "test-service", "image": "nginx:latest"}

        # Make request
        with patch('src.blackant.http.client.set_request_id'), \
                patch('src.blackant.http.client.clear_request_id'):
            response = self.client.send_request("/api/v1/services", "POST", json=test_data, anonymous=True)

        # Verify response
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json()["name"], "test-service")

        # Verify request payload
        request_history = mock_requests.request_history[0]
        self.assertEqual(request_history.json(), test_data)

    def test_multiple_clients_different_endpoints(self):
        """Test multiple HTTP clients for different endpoints."""
        with patch('src.blackant.http.client.get_logger'), \
                patch('src.blackant.http.client.set_request_id'), \
                patch('src.blackant.http.client.clear_request_id'):
            blackant_client = HTTPClient("https://api.blackant.app")
            keycloak_client = HTTPClient("https://auth.blackant.app")

        # Verify different base URLs
        self.assertEqual(blackant_client.base_url, "https://api.blackant.app")
        self.assertEqual(keycloak_client.base_url, "https://auth.blackant.app")

        # Verify shared token store (singleton behavior)
        blackant_client.auth_token_store.user_token = "shared_token"
        self.assertEqual(keycloak_client.auth_token_store.user_token, "shared_token")


if __name__ == "__main__":
    unittest.main()