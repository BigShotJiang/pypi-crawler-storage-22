import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'src'))

from blackant.utils.logging import init_logging, get_logger, set_request_id, clear_request_id


def test_basic_logging():
    print("=== Basic Logging Test ===")

    init_logging(
        app_name="TestApp",
        log_level="DEBUG"
    )

    main_logger = get_logger("main")
    http_logger = get_logger("http")

    main_logger.debug("This is a debug message")
    main_logger.info("This is an info message")
    main_logger.warning("This is a warning message")
    main_logger.error("This is an error message")

    print("\n=== Request ID Test ===")
    set_request_id("test_req_12345")
    http_logger.info("Message with request ID")

    clear_request_id()
    http_logger.info("Message without request ID")

    print("\n=== Sensitive Data Filtering Test ===")
    http_logger.info("User authenticated with Bearer abc123token456")
    http_logger.info("API key configured: api_key=secret_key_789")


def test_color_disable():
    print("\n=== Color Disable Test ===")

    init_logging(
        app_name="NoColorApp",
        enable_colors=False,
        log_level="INFO"
    )

    logger = get_logger("test")
    logger.info("This message should have no colors")
    logger.error("This error should also have no colors")


if __name__ == "__main__":
    test_basic_logging()
    test_color_disable()