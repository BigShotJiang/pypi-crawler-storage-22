"""Unit tests for Store base class."""

import unittest
import threading
from src.blackant.utils.store import Store


class TestStore(unittest.TestCase):
    """Test cases for Store base class."""

    def setUp(self):
        """Set up test fixtures."""
        self.store = Store()

    def test_get_nonexistent_attribute(self):
        """Test getting non-existent attribute returns None."""
        result = self.store._get("nonexistent")
        self.assertIsNone(result)

    def test_set_and_get_attribute(self):
        """Test setting and getting attributes."""
        self.store._set("test_key", "test_value")
        result = self.store._get("test_key")
        self.assertEqual(result, "test_value")

    def test_delete_attribute(self):
        """Test deleting attributes."""
        self.store._set("test_key", "test_value")
        self.store._del("test_key")
        result = self.store._get("test_key")
        self.assertIsNone(result)

    def test_thread_isolation(self):
        """Test that Store is thread-isolated."""
        results = {}

        def worker(thread_id):
            store = Store()  # Should be same instance due to Singleton
            store._set("thread_id", thread_id)
            results[thread_id] = store._get("thread_id")

        threads = []
        for i in range(5):
            thread = threading.Thread(target=worker, args=(i,))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        # Each thread should have its own value
        for i in range(5):
            self.assertEqual(results[i], i)


if __name__ == "__main__":
    unittest.main()