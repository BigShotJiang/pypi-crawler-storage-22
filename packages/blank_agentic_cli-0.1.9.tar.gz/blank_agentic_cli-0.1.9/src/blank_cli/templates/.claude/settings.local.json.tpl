{
  "permissions": {
    "allow": []
  }
}
