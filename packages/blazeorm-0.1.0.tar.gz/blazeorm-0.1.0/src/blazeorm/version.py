"""
Version information for BlazeORM.
"""

__version__ = "0.1.0"
