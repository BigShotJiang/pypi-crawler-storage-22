# blitzrank

A fast and efficient reranking library for ML applications.

## Installation

```bash
pip install blitzrank
```

## Status

This package is currently in early development. Stay tuned for updates!

## License

MIT
