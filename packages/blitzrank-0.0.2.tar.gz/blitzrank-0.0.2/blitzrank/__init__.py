"""blitzrank - A fast and efficient reranking library for ML applications."""

__version__ = "0.0.2"
