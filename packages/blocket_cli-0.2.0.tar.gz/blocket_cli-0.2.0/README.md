# blocket-cli

[![CI](https://github.com/lennart-johansson/blocket-cli/actions/workflows/ci.yml/badge.svg)](https://github.com/lennart-johansson/blocket-cli/actions/workflows/ci.yml)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://python.org)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

Fast CLI for searching [Blocket.se](https://www.blocket.se) — Sweden's largest marketplace.

Designed for agents, scripts, and quick terminal lookups. Minimal dependencies, structured output.

## Install

```bash
pip install blocket-cli
```

Or with [uv](https://docs.astral.sh/uv/):

```bash
uv tool install blocket-cli
```

## Usage

### Search listings

```bash
blocket search "soffa"
blocket search "iphone 15" -l stockholm --price-max 8000
blocket search "mountainbike" -c sports --sort price-asc -n 10
blocket search "ps5" -c electronics -o json | jq '.results[:3]'
```

### Get ad details

```bash
blocket ad 20851738
blocket ad 20851738 -o json
```

### Browse filters

```bash
blocket categories
blocket locations
```

## Output formats

| Flag | Format | Use case |
|------|--------|----------|
| (default) | Human-readable table | Terminal browsing |
| `-o json` | Compact JSON | Piping to `jq`, API consumption |
| `-o jsonl` | One JSON object per line | Streaming, log processing |

## Search options

| Option | Description |
|--------|-------------|
| `-l`, `--location` | Filter by Swedish county (e.g. `stockholm`, `skane`) |
| `-c`, `--category` | Filter by category (e.g. `electronics`, `furniture`) |
| `--price-min` | Minimum price in SEK |
| `--price-max` | Maximum price in SEK |
| `--sort` | Sort order (`relevance`, `price-asc`, `price-desc`, `date`) |
| `-n`, `--limit` | Max results to display |
| `-p`, `--page` | Page number |
| `-o`, `--output` | Output format (`table`, `json`, `jsonl`) |

## Agent integration

The JSON output is designed for LLM agents and automation:

```bash
# Structured search results
blocket search "cykel" -l stockholm --price-max 5000 -o json

# Stream results line by line
blocket search "soffa" -o jsonl

# Filter by category
blocket search "lampa" -c furniture -o json | jq '[.results[] | {title: .heading, price: .price.amount, location}]'
```

## License

MIT
