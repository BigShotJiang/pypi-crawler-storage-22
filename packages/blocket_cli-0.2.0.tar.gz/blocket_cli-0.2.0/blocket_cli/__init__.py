"""Fast CLI for searching Blocket.se — optimized for agents and scripting."""

__version__ = "0.2.0"
