"""Blocket.se search API client."""

from __future__ import annotations

import json
from html.parser import HTMLParser

import httpx

BASE = "https://www.blocket.se"
SEARCH_URL = f"{BASE}/recommerce/forsale/search/api/search/SEARCH_ID_BAP_COMMON"
CAR_SEARCH_URL = f"{BASE}/mobility/search/api/search/SEARCH_ID_CAR_USED"
BOAT_SEARCH_URL = f"{BASE}/mobility/search/api/search/SEARCH_ID_BOAT_USED"
MC_SEARCH_URL = f"{BASE}/mobility/search/api/search/SEARCH_ID_MC_USED"

HEADERS = {
    "User-Agent": "blocket-cli/0.2.0 (https://github.com/lennart-johansson/blocket-cli)",
}

LOCATIONS = {
    "blekinge": "0.300010",
    "dalarna": "0.300020",
    "gotland": "0.300009",
    "gavleborg": "0.300021",
    "halland": "0.300013",
    "jamtland": "0.300023",
    "jonkoping": "0.300006",
    "kalmar": "0.300008",
    "kronoberg": "0.300007",
    "norrbotten": "0.300025",
    "skane": "0.300012",
    "stockholm": "0.300001",
    "sodermanland": "0.300004",
    "uppsala": "0.300003",
    "varmland": "0.300017",
    "vasterbotten": "0.300024",
    "vasternorrland": "0.300022",
    "vastmanland": "0.300019",
    "vastra-gotaland": "0.300014",
    "orebro": "0.300018",
    "ostergotland": "0.300005",
}

CATEGORIES = {
    "business": "0.91",
    "home-garden": "0.67",
    "pets": "0.77",
    "electronics": "0.93",
    "vehicle-parts": "0.90",
    "family": "0.68",
    "fashion": "0.71",
    "art": "0.76",
    "furniture": "0.78",
    "sports": "0.69",
    "hobby": "0.86",
}

# Swedish display names for categories
CATEGORY_LABELS = {
    "business": "Affärsverksamhet",
    "home-garden": "Bygg och trädgård",
    "pets": "Djur och tillbehör",
    "electronics": "Elektronik och vitvaror",
    "vehicle-parts": "Fordonstillbehör",
    "family": "Föräldrar och barn",
    "fashion": "Kläder, kosmetika och accessoarer",
    "art": "Konst och antikt",
    "furniture": "Möbler och inredning",
    "sports": "Sport och friluftsliv",
    "hobby": "Underhållning och hobby",
}


FUELS = {
    "bensin": "1",
    "diesel": "2",
    "el": "4",
    "etanol": "2441",
    "cng": "3",
    "hybrid-bensin": "6",
    "hybrid-diesel": "8",
    "hybrid-gas": "5",
    "plugin-bensin": "1352",
    "plugin-diesel": "1356",
}

FUEL_LABELS = {
    "bensin": "Bensin",
    "diesel": "Diesel",
    "el": "El",
    "etanol": "Etanol",
    "cng": "CNG",
    "hybrid-bensin": "Hybrid (bensin)",
    "hybrid-diesel": "Hybrid (diesel)",
    "hybrid-gas": "Hybrid (gas)",
    "plugin-bensin": "Plug-in (bensin)",
    "plugin-diesel": "Plug-in (diesel)",
}

TRANSMISSIONS = {
    "manuell": "1",
    "automat": "2",
}

TRANSMISSION_LABELS = {
    "manuell": "Manuell",
    "automat": "Automatisk",
}


def _resolve_fuel(name: str) -> str:
    code = FUELS.get(name.lower())
    if not code:
        raise ValueError(f"Unknown fuel '{name}'. Valid: {', '.join(sorted(FUELS))}")
    return code


def _resolve_transmission(name: str) -> str:
    code = TRANSMISSIONS.get(name.lower())
    if not code:
        raise ValueError(f"Unknown transmission '{name}'. Valid: {', '.join(sorted(TRANSMISSIONS))}")
    return code


def _resolve_location(name: str) -> str:
    code = LOCATIONS.get(name.lower())
    if not code:
        raise ValueError(f"Unknown location '{name}'. Valid: {', '.join(sorted(LOCATIONS))}")
    return code


def _resolve_category(name: str) -> str:
    code = CATEGORIES.get(name.lower())
    if not code:
        raise ValueError(f"Unknown category '{name}'. Valid: {', '.join(sorted(CATEGORIES))}")
    return code


def search(
    query: str,
    *,
    location: str | None = None,
    category: str | None = None,
    price_min: int | None = None,
    price_max: int | None = None,
    sort: str | None = None,
    page: int = 1,
) -> dict:
    """Search listings on Blocket."""
    params: list[tuple[str, str]] = [("q", query), ("page", str(page))]
    if location:
        params.append(("location", _resolve_location(location)))
    if category:
        params.append(("category", _resolve_category(category)))
    if price_min is not None:
        params.append(("price_from", str(price_min)))
    if price_max is not None:
        params.append(("price_to", str(price_max)))
    if sort:
        params.append(("sort", sort))

    r = httpx.get(SEARCH_URL, params=params, headers=HEADERS, timeout=15, follow_redirects=True)
    r.raise_for_status()
    return r.json()


def get_ad(ad_id: int | str) -> dict:
    """Fetch full ad details from the item page's structured data."""
    # Try recommerce first (most common), fall back to mobility
    for path in ("recommerce/forsale/item", "mobility/item"):
        url = f"{BASE}/{path}/{ad_id}"
        r = httpx.get(url, headers=HEADERS, timeout=15, follow_redirects=True)
        if r.status_code == 200:
            result = _extract_product_data(r.text)
            if result:
                return result

    return {"error": f"Could not find ad {ad_id}"}


def _extract_product_data(html: str) -> dict | None:
    """Extract JSON-LD Product data from HTML."""

    class _LDJsonExtractor(HTMLParser):
        def __init__(self):
            super().__init__()
            self._capture = False
            self.scripts: list[str] = []

        def handle_starttag(self, tag, attrs):
            if tag == "script" and dict(attrs).get("type") == "application/ld+json":
                self._capture = True

        def handle_data(self, data):
            if self._capture:
                self.scripts.append(data)

        def handle_endtag(self, tag):
            if tag == "script":
                self._capture = False

    parser = _LDJsonExtractor()
    parser.feed(html)

    for script in parser.scripts:
        try:
            data = json.loads(script)
            if isinstance(data, dict) and data.get("@type") == "Product":
                return data
        except json.JSONDecodeError:
            continue

    return None


def search_cars(
    query: str,
    *,
    location: str | None = None,
    price_min: int | None = None,
    price_max: int | None = None,
    year_min: int | None = None,
    year_max: int | None = None,
    mileage_min: int | None = None,
    mileage_max: int | None = None,
    fuel: str | None = None,
    transmission: str | None = None,
    sort: str | None = None,
    page: int = 1,
) -> dict:
    """Search used cars on Blocket."""
    params: list[tuple[str, str]] = [("q", query), ("page", str(page))]
    if location:
        params.append(("location", _resolve_location(location)))
    if price_min is not None:
        params.append(("price_from", str(price_min)))
    if price_max is not None:
        params.append(("price_to", str(price_max)))
    if year_min is not None:
        params.append(("year_from", str(year_min)))
    if year_max is not None:
        params.append(("year_to", str(year_max)))
    if mileage_min is not None:
        params.append(("mileage_from", str(mileage_min)))
    if mileage_max is not None:
        params.append(("mileage_to", str(mileage_max)))
    if fuel:
        params.append(("fuel", _resolve_fuel(fuel)))
    if transmission:
        params.append(("transmission", _resolve_transmission(transmission)))
    if sort:
        params.append(("sort", sort))

    r = httpx.get(CAR_SEARCH_URL, params=params, headers=HEADERS, timeout=15, follow_redirects=True)
    r.raise_for_status()
    return r.json()


def search_boats(
    query: str,
    *,
    location: str | None = None,
    price_min: int | None = None,
    price_max: int | None = None,
    length_min: int | None = None,
    length_max: int | None = None,
    sort: str | None = None,
    page: int = 1,
) -> dict:
    """Search used boats on Blocket."""
    params: list[tuple[str, str]] = [("q", query), ("page", str(page))]
    if location:
        params.append(("location", _resolve_location(location)))
    if price_min is not None:
        params.append(("price_from", str(price_min)))
    if price_max is not None:
        params.append(("price_to", str(price_max)))
    if length_min is not None:
        params.append(("length_feet_from", str(length_min)))
    if length_max is not None:
        params.append(("length_feet_to", str(length_max)))
    if sort:
        params.append(("sort", sort))

    r = httpx.get(BOAT_SEARCH_URL, params=params, headers=HEADERS, timeout=15, follow_redirects=True)
    r.raise_for_status()
    return r.json()


def search_mc(
    query: str,
    *,
    location: str | None = None,
    price_min: int | None = None,
    price_max: int | None = None,
    year_min: int | None = None,
    year_max: int | None = None,
    mileage_min: int | None = None,
    mileage_max: int | None = None,
    sort: str | None = None,
    page: int = 1,
) -> dict:
    """Search used motorcycles on Blocket."""
    params: list[tuple[str, str]] = [("q", query), ("page", str(page))]
    if location:
        params.append(("location", _resolve_location(location)))
    if price_min is not None:
        params.append(("price_from", str(price_min)))
    if price_max is not None:
        params.append(("price_to", str(price_max)))
    if year_min is not None:
        params.append(("year_from", str(year_min)))
    if year_max is not None:
        params.append(("year_to", str(year_max)))
    if mileage_min is not None:
        params.append(("mileage_from", str(mileage_min)))
    if mileage_max is not None:
        params.append(("mileage_to", str(mileage_max)))
    if sort:
        params.append(("sort", sort))

    r = httpx.get(MC_SEARCH_URL, params=params, headers=HEADERS, timeout=15, follow_redirects=True)
    r.raise_for_status()
    return r.json()
