"""Blocket CLI — search Blocket.se from the terminal."""

from __future__ import annotations

import sys

import click

from . import api, format


@click.group()
@click.version_option()
def main():
    """Search Blocket.se from the command line.

    Fast, minimal CLI for searching Sweden's largest marketplace.
    Designed for scripting, agents, and quick lookups.
    """
    pass


@main.command()
@click.argument("query")
@click.option("-l", "--location", help="County filter (e.g. stockholm, skane)")
@click.option("-c", "--category", help="Category filter (use 'blocket categories' to list)")
@click.option("--price-min", type=int, help="Minimum price (SEK)")
@click.option("--price-max", type=int, help="Maximum price (SEK)")
@click.option(
    "--sort",
    type=click.Choice(["relevance", "price-asc", "price-desc", "date"], case_sensitive=False),
    help="Sort order",
)
@click.option("-n", "--limit", type=int, help="Max results to show")
@click.option("-p", "--page", type=int, default=1, help="Page number")
@click.option("-o", "--output", type=click.Choice(["table", "json", "jsonl"]), default="table", help="Output format")
@click.option("--raw", is_flag=True, help="Full API response (default: slim agent-friendly fields)")
def search(
    query: str,
    location: str | None,
    category: str | None,
    price_min: int | None,
    price_max: int | None,
    sort: str | None,
    limit: int | None,
    page: int,
    output: str,
    raw: bool,
):
    """Search listings on Blocket.

    \b
    Examples:
        blocket search "soffa" -l stockholm --price-max 5000
        blocket search "iphone 15" -c electronics --sort price-asc
        blocket search "cykel" -c sports -o json
    """
    sort_map = {
        "relevance": "RELEVANCE",
        "price-asc": "PRICE_ASC",
        "price-desc": "PRICE_DESC",
        "date": "PUBLISHED_DESC",
    }
    try:
        data = api.search(
            query,
            location=location,
            category=category,
            price_min=price_min,
            price_max=price_max,
            sort=sort_map.get(sort, sort) if sort else None,
            page=page,
        )
        format.print_results(data, output=output, limit=limit, raw=raw)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("ad_id")
@click.option("-o", "--output", type=click.Choice(["table", "json"]), default="table", help="Output format")
def ad(ad_id: str, output: str):
    """Get full details for a specific ad.

    \b
    Examples:
        blocket ad 20851738
        blocket ad 20851738 -o json
    """
    try:
        data = api.get_ad(ad_id)
        format.print_ad(data, output=output)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


CAR_SORT_CHOICES = [
    "relevance", "price-asc", "price-desc", "date",
    "mileage-asc", "mileage-desc", "year-asc", "year-desc",
]
CAR_SORT_MAP = {
    "relevance": "RELEVANCE",
    "price-asc": "PRICE_ASC",
    "price-desc": "PRICE_DESC",
    "date": "PUBLISHED_DESC",
    "mileage-asc": "MILEAGE_ASC",
    "mileage-desc": "MILEAGE_DESC",
    "year-asc": "YEAR_ASC",
    "year-desc": "YEAR_DESC",
}


@main.command()
@click.argument("query")
@click.option("-l", "--location", help="County filter (e.g. stockholm, skane)")
@click.option("--price-min", type=int, help="Minimum price (SEK)")
@click.option("--price-max", type=int, help="Maximum price (SEK)")
@click.option("--year-min", type=int, help="Minimum model year")
@click.option("--year-max", type=int, help="Maximum model year")
@click.option("--mileage-min", type=int, help="Minimum mileage (mil)")
@click.option("--mileage-max", type=int, help="Maximum mileage (mil)")
@click.option("--fuel", help="Fuel type (use 'blocket fuels' to list)")
@click.option("--transmission", help="Transmission (manuell, automat)")
@click.option("--sort", type=click.Choice(CAR_SORT_CHOICES, case_sensitive=False), help="Sort order")
@click.option("-n", "--limit", type=int, help="Max results to show")
@click.option("-p", "--page", type=int, default=1, help="Page number")
@click.option("-o", "--output", type=click.Choice(["table", "json", "jsonl"]), default="table", help="Output format")
@click.option("--raw", is_flag=True, help="Full API response (default: slim agent-friendly fields)")
def cars(
    query: str,
    location: str | None,
    price_min: int | None,
    price_max: int | None,
    year_min: int | None,
    year_max: int | None,
    mileage_min: int | None,
    mileage_max: int | None,
    fuel: str | None,
    transmission: str | None,
    sort: str | None,
    limit: int | None,
    page: int,
    output: str,
    raw: bool,
):
    """Search used cars on Blocket.

    \b
    Examples:
        blocket cars "vw alltrack" --year-min 2015 --mileage-max 8000
        blocket cars "tesla model 3" --fuel el --sort price-asc
        blocket cars "volvo xc60" -l stockholm -o json
    """
    try:
        data = api.search_cars(
            query,
            location=location,
            price_min=price_min,
            price_max=price_max,
            year_min=year_min,
            year_max=year_max,
            mileage_min=mileage_min,
            mileage_max=mileage_max,
            fuel=fuel,
            transmission=transmission,
            sort=CAR_SORT_MAP.get(sort, sort) if sort else None,
            page=page,
        )
        format.print_car_results(data, output=output, limit=limit, raw=raw)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
@click.argument("query")
@click.option("-l", "--location", help="County filter (e.g. stockholm, skane)")
@click.option("--price-min", type=int, help="Minimum price (SEK)")
@click.option("--price-max", type=int, help="Maximum price (SEK)")
@click.option("--length-min", type=int, help="Minimum length (ft)")
@click.option("--length-max", type=int, help="Maximum length (ft)")
@click.option(
    "--sort",
    type=click.Choice(["relevance", "price-asc", "price-desc", "date"], case_sensitive=False),
    help="Sort order",
)
@click.option("-n", "--limit", type=int, help="Max results to show")
@click.option("-p", "--page", type=int, default=1, help="Page number")
@click.option("-o", "--output", type=click.Choice(["table", "json", "jsonl"]), default="table", help="Output format")
@click.option("--raw", is_flag=True, help="Full API response (default: slim agent-friendly fields)")
def boats(
    query: str,
    location: str | None,
    price_min: int | None,
    price_max: int | None,
    length_min: int | None,
    length_max: int | None,
    sort: str | None,
    limit: int | None,
    page: int,
    output: str,
    raw: bool,
):
    """Search used boats on Blocket.

    \b
    Examples:
        blocket boats "segelbat" --length-min 30
        blocket boats "bayliner" --sort price-asc -o json
    """
    sort_map = {
        "relevance": "RELEVANCE",
        "price-asc": "PRICE_ASC",
        "price-desc": "PRICE_DESC",
        "date": "PUBLISHED_DESC",
    }
    try:
        data = api.search_boats(
            query,
            location=location,
            price_min=price_min,
            price_max=price_max,
            length_min=length_min,
            length_max=length_max,
            sort=sort_map.get(sort, sort) if sort else None,
            page=page,
        )
        format.print_boat_results(data, output=output, limit=limit, raw=raw)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


MC_SORT_CHOICES = [
    "relevance", "price-asc", "price-desc", "date",
    "mileage-asc", "mileage-desc", "year-asc", "year-desc",
]
MC_SORT_MAP = {
    "relevance": "RELEVANCE",
    "price-asc": "PRICE_ASC",
    "price-desc": "PRICE_DESC",
    "date": "PUBLISHED_DESC",
    "mileage-asc": "MILEAGE_ASC",
    "mileage-desc": "MILEAGE_DESC",
    "year-asc": "YEAR_ASC",
    "year-desc": "YEAR_DESC",
}


@main.command()
@click.argument("query")
@click.option("-l", "--location", help="County filter (e.g. stockholm, skane)")
@click.option("--price-min", type=int, help="Minimum price (SEK)")
@click.option("--price-max", type=int, help="Maximum price (SEK)")
@click.option("--year-min", type=int, help="Minimum model year")
@click.option("--year-max", type=int, help="Maximum model year")
@click.option("--mileage-min", type=int, help="Minimum mileage (mil)")
@click.option("--mileage-max", type=int, help="Maximum mileage (mil)")
@click.option("--sort", type=click.Choice(MC_SORT_CHOICES, case_sensitive=False), help="Sort order")
@click.option("-n", "--limit", type=int, help="Max results to show")
@click.option("-p", "--page", type=int, default=1, help="Page number")
@click.option("-o", "--output", type=click.Choice(["table", "json", "jsonl"]), default="table", help="Output format")
@click.option("--raw", is_flag=True, help="Full API response (default: slim agent-friendly fields)")
def mc(
    query: str,
    location: str | None,
    price_min: int | None,
    price_max: int | None,
    year_min: int | None,
    year_max: int | None,
    mileage_min: int | None,
    mileage_max: int | None,
    sort: str | None,
    limit: int | None,
    page: int,
    output: str,
    raw: bool,
):
    """Search used motorcycles on Blocket.

    \b
    Examples:
        blocket mc "yamaha mt-07" --year-min 2020
        blocket mc "harley" --sort price-desc -o json
    """
    try:
        data = api.search_mc(
            query,
            location=location,
            price_min=price_min,
            price_max=price_max,
            year_min=year_min,
            year_max=year_max,
            mileage_min=mileage_min,
            mileage_max=mileage_max,
            sort=MC_SORT_MAP.get(sort, sort) if sort else None,
            page=page,
        )
        format.print_mc_results(data, output=output, limit=limit, raw=raw)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@main.command()
def fuels():
    """List available fuel types for car search."""
    for name in sorted(api.FUELS):
        label = api.FUEL_LABELS.get(name, "")
        click.echo(f"{name:<20} {label}")


@main.command()
def categories():
    """List available categories."""
    for name in sorted(api.CATEGORIES):
        label = api.CATEGORY_LABELS.get(name, "")
        click.echo(f"{name:<20} {label}")


@main.command()
def locations():
    """List available locations (Swedish counties)."""
    for name in sorted(api.LOCATIONS):
        click.echo(name)
