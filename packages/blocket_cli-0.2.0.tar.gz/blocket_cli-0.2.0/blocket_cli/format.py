"""Output formatting for Blocket CLI."""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from typing import Any


def _json_compact(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def _slim(doc: dict) -> dict:
    """Strip a listing to agent-essential fields."""
    price = doc.get("price", {})
    out: dict[str, Any] = {
        "id": doc.get("id"),
        "heading": doc.get("heading"),
        "price": price.get("amount"),
        "currency": price.get("currency_code", "SEK"),
        "location": doc.get("location"),
        "url": doc.get("canonical_url"),
    }
    ts = doc.get("timestamp")
    if ts:
        out["date"] = datetime.fromtimestamp(ts / 1000, tz=timezone.utc).strftime("%Y-%m-%d")
    for extra in doc.get("extras", []):
        if extra.get("id") == "brand" and extra.get("values"):
            out["brand"] = extra["values"][0]
    return out


def _slim_car(doc: dict) -> dict:
    """Strip a car listing to agent-essential fields."""
    price = doc.get("price", {})
    out: dict[str, Any] = {
        "id": doc.get("id"),
        "heading": doc.get("heading"),
        "price": price.get("amount"),
        "currency": price.get("currency_code", "SEK"),
        "location": doc.get("location"),
        "url": doc.get("canonical_url"),
    }
    ts = doc.get("timestamp")
    if ts:
        out["date"] = datetime.fromtimestamp(ts / 1000, tz=timezone.utc).strftime("%Y-%m-%d")
    if doc.get("year"):
        out["year"] = doc["year"]
    if doc.get("mileage") is not None:
        out["mileage_mil"] = doc["mileage"]
    if doc.get("make"):
        out["make"] = doc["make"]
    if doc.get("model"):
        out["model"] = doc["model"]
    if doc.get("fuel"):
        out["fuel"] = doc["fuel"]
    if doc.get("transmission"):
        out["transmission"] = doc["transmission"]
    return out


def _slim_boat(doc: dict) -> dict:
    """Strip a boat listing to agent-essential fields."""
    price = doc.get("price", {})
    out: dict[str, Any] = {
        "id": doc.get("id"),
        "heading": doc.get("heading"),
        "price": price.get("amount"),
        "currency": price.get("currency_code", "SEK"),
        "location": doc.get("location"),
        "url": doc.get("canonical_url"),
    }
    ts = doc.get("timestamp")
    if ts:
        out["date"] = datetime.fromtimestamp(ts / 1000, tz=timezone.utc).strftime("%Y-%m-%d")
    if doc.get("year"):
        out["year"] = doc["year"]
    if doc.get("length") is not None:
        out["length_ft"] = doc["length"]
    if doc.get("make"):
        out["make"] = doc["make"]
    if doc.get("boat_class"):
        out["boat_class"] = doc["boat_class"]
    if doc.get("motor_type"):
        out["motor_type"] = doc["motor_type"]
    return out


def _slim_mc(doc: dict) -> dict:
    """Strip a motorcycle listing to agent-essential fields."""
    price = doc.get("price", {})
    out: dict[str, Any] = {
        "id": doc.get("id"),
        "heading": doc.get("heading"),
        "price": price.get("amount"),
        "currency": price.get("currency_code", "SEK"),
        "location": doc.get("location"),
        "url": doc.get("canonical_url"),
    }
    ts = doc.get("timestamp")
    if ts:
        out["date"] = datetime.fromtimestamp(ts / 1000, tz=timezone.utc).strftime("%Y-%m-%d")
    if doc.get("year"):
        out["year"] = doc["year"]
    if doc.get("make"):
        out["make"] = doc["make"]
    if doc.get("mileage") is not None:
        out["mileage_mil"] = doc["mileage"]
    return out


def print_results(data: dict, *, output: str = "table", limit: int | None = None, raw: bool = False) -> None:
    """Print search results."""
    docs = data.get("docs", [])
    total = data.get("metadata", {}).get("result_size", {}).get("match_count", len(docs))

    if limit:
        docs = docs[:limit]

    if output == "json":
        results = docs if raw else [_slim(d) for d in docs]
        print(_json_compact({"total": total, "results": results}))
        return

    if output == "jsonl":
        for doc in docs:
            print(_json_compact(doc if raw else _slim(doc)))
        return

    if not docs:
        print("No results found.", file=sys.stderr)
        return

    print(f"Found {total:,} listings (showing {len(docs)}):\n")

    for doc in docs:
        price = doc.get("price", {})
        amount = price.get("amount")
        currency = price.get("price_unit", "kr")
        location = doc.get("location", "")
        heading = doc.get("heading", "Untitled")
        url = doc.get("canonical_url", "")

        price_str = f"{amount:,} {currency}".replace(",", " ") if amount else "—"

        print(f"  {heading}")
        print(f"  {price_str} · {location}")
        print(f"  {url}")
        print()


def print_ad(data: dict, *, output: str = "table") -> None:
    """Print ad details."""
    if output == "json":
        print(_json_compact(data))
        return

    if "error" in data:
        print(f"Error: {data['error']}", file=sys.stderr)
        return

    title = data.get("name", data.get("title", "Untitled"))
    desc = data.get("description", "")
    offers = data.get("offers", {})
    price = offers.get("price", "")
    currency = offers.get("priceCurrency", "SEK")
    condition = data.get("itemCondition", "").split("/")[-1] if data.get("itemCondition") else ""
    brand = ""
    if isinstance(data.get("brand"), dict):
        brand = data["brand"].get("name", "")
    url = data.get("url", "")

    print(title)
    print("=" * min(len(title), 60))
    if brand:
        print(f"Brand:     {brand}")
    if price:
        print(f"Price:     {price} {currency}")
    if condition:
        print(f"Condition: {condition}")
    if desc:
        print(f"\n{desc}")
    if url:
        print(f"\n{url}")


def _fmt_price(doc: dict) -> str:
    price = doc.get("price", {})
    amount = price.get("amount")
    currency = price.get("price_unit", "kr")
    return f"{amount:,} {currency}".replace(",", " ") if amount else "—"


def print_car_results(data: dict, *, output: str = "table", limit: int | None = None, raw: bool = False) -> None:
    """Print car search results."""
    docs = data.get("docs", [])
    total = data.get("metadata", {}).get("result_size", {}).get("match_count", len(docs))

    if limit:
        docs = docs[:limit]

    if output == "json":
        results = docs if raw else [_slim_car(d) for d in docs]
        print(_json_compact({"total": total, "results": results}))
        return

    if output == "jsonl":
        for doc in docs:
            print(_json_compact(doc if raw else _slim_car(doc)))
        return

    if not docs:
        print("No results found.", file=sys.stderr)
        return

    print(f"Found {total:,} cars (showing {len(docs)}):\n")

    for doc in docs:
        heading = doc.get("heading", "Untitled")
        location = doc.get("location", "")
        year = doc.get("year", "")
        mileage = doc.get("mileage")
        fuel = doc.get("fuel", "")
        url = doc.get("canonical_url", "")

        mileage_str = f"{mileage:,} mil".replace(",", " ") if mileage is not None else ""
        details = " · ".join(filter(None, [str(year) if year else "", mileage_str, fuel]))

        print(f"  {heading}")
        print(f"  {_fmt_price(doc)} · {location}")
        if details:
            print(f"  {details}")
        print(f"  {url}")
        print()


def print_boat_results(data: dict, *, output: str = "table", limit: int | None = None, raw: bool = False) -> None:
    """Print boat search results."""
    docs = data.get("docs", [])
    total = data.get("metadata", {}).get("result_size", {}).get("match_count", len(docs))

    if limit:
        docs = docs[:limit]

    if output == "json":
        results = docs if raw else [_slim_boat(d) for d in docs]
        print(_json_compact({"total": total, "results": results}))
        return

    if output == "jsonl":
        for doc in docs:
            print(_json_compact(doc if raw else _slim_boat(doc)))
        return

    if not docs:
        print("No results found.", file=sys.stderr)
        return

    print(f"Found {total:,} boats (showing {len(docs)}):\n")

    for doc in docs:
        heading = doc.get("heading", "Untitled")
        location = doc.get("location", "")
        year = doc.get("year", "")
        length = doc.get("length")
        boat_class = doc.get("boat_class", "")
        url = doc.get("canonical_url", "")

        length_str = f"{length} ft" if length else ""
        details = " · ".join(filter(None, [str(year) if year else "", length_str, boat_class]))

        print(f"  {heading}")
        print(f"  {_fmt_price(doc)} · {location}")
        if details:
            print(f"  {details}")
        print(f"  {url}")
        print()


def print_mc_results(data: dict, *, output: str = "table", limit: int | None = None, raw: bool = False) -> None:
    """Print motorcycle search results."""
    docs = data.get("docs", [])
    total = data.get("metadata", {}).get("result_size", {}).get("match_count", len(docs))

    if limit:
        docs = docs[:limit]

    if output == "json":
        results = docs if raw else [_slim_mc(d) for d in docs]
        print(_json_compact({"total": total, "results": results}))
        return

    if output == "jsonl":
        for doc in docs:
            print(_json_compact(doc if raw else _slim_mc(doc)))
        return

    if not docs:
        print("No results found.", file=sys.stderr)
        return

    print(f"Found {total:,} motorcycles (showing {len(docs)}):\n")

    for doc in docs:
        heading = doc.get("heading", "Untitled")
        location = doc.get("location", "")
        year = doc.get("year", "")
        mileage = doc.get("mileage")
        url = doc.get("canonical_url", "")

        mileage_str = f"{mileage:,} mil".replace(",", " ") if mileage is not None else ""
        details = " · ".join(filter(None, [str(year) if year else "", mileage_str]))

        print(f"  {heading}")
        print(f"  {_fmt_price(doc)} · {location}")
        if details:
            print(f"  {details}")
        print(f"  {url}")
        print()
