"""Tests for the API client (no network calls)."""

from __future__ import annotations

import json

import pytest

from blocket_cli.api import (
    CATEGORIES,
    FUELS,
    LOCATIONS,
    _extract_product_data,
    _resolve_category,
    _resolve_fuel,
    _resolve_location,
    _resolve_transmission,
)


class TestResolveLocation:
    def test_valid(self):
        assert _resolve_location("stockholm") == "0.300001"

    def test_case_insensitive(self):
        assert _resolve_location("Stockholm") == "0.300001"

    def test_invalid(self):
        with pytest.raises(ValueError, match="Unknown location 'narnia'"):
            _resolve_location("narnia")

    def test_all_locations_have_codes(self):
        for name, code in LOCATIONS.items():
            assert code.startswith("0.3000"), f"{name} has unexpected code {code}"


class TestResolveCategory:
    def test_valid(self):
        assert _resolve_category("electronics") == "0.93"

    def test_case_insensitive(self):
        assert _resolve_category("Electronics") == "0.93"

    def test_invalid(self):
        with pytest.raises(ValueError, match="Unknown category 'weapons'"):
            _resolve_category("weapons")

    def test_all_categories_have_codes(self):
        for name, code in CATEGORIES.items():
            assert code.startswith("0."), f"{name} has unexpected code {code}"


class TestExtractProductData:
    def test_extracts_product(self):
        product = {"@type": "Product", "name": "Soffa", "offers": {"price": "500"}}
        html = f'<html><head><script type="application/ld+json">{json.dumps(product)}</script></head></html>'
        assert _extract_product_data(html) == product

    def test_ignores_non_product(self):
        other = {"@type": "Organization", "name": "Blocket"}
        html = f'<html><script type="application/ld+json">{json.dumps(other)}</script></html>'
        assert _extract_product_data(html) is None

    def test_handles_multiple_scripts(self):
        org = {"@type": "Organization", "name": "Blocket"}
        product = {"@type": "Product", "name": "Cykel"}
        html = (
            f'<script type="application/ld+json">{json.dumps(org)}</script>'
            f'<script type="application/ld+json">{json.dumps(product)}</script>'
        )
        assert _extract_product_data(html) == product

    def test_handles_invalid_json(self):
        html = '<script type="application/ld+json">not json</script>'
        assert _extract_product_data(html) is None

    def test_handles_no_scripts(self):
        assert _extract_product_data("<html><body>Hello</body></html>") is None


class TestResolveFuel:
    def test_valid(self):
        assert _resolve_fuel("diesel") == "2"

    def test_case_insensitive(self):
        assert _resolve_fuel("El") == "4"

    def test_invalid(self):
        with pytest.raises(ValueError, match="Unknown fuel 'hydrogen'"):
            _resolve_fuel("hydrogen")

    def test_all_fuels_have_codes(self):
        for name, code in FUELS.items():
            assert code.isdigit() or code.startswith("1"), f"{name} has unexpected code {code}"


class TestResolveTransmission:
    def test_valid(self):
        assert _resolve_transmission("automat") == "2"

    def test_case_insensitive(self):
        assert _resolve_transmission("Manuell") == "1"

    def test_invalid(self):
        with pytest.raises(ValueError, match="Unknown transmission 'cvt'"):
            _resolve_transmission("cvt")
