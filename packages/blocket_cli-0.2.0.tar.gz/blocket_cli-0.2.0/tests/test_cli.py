"""Tests for CLI commands (mocked HTTP)."""

from __future__ import annotations

import json
from unittest.mock import patch

from click.testing import CliRunner

from blocket_cli.cli import main

SEARCH_RESPONSE = {
    "docs": [
        {
            "id": "1",
            "heading": "Test soffa",
            "price": {"amount": 2000, "currency_code": "SEK", "price_unit": "kr"},
            "location": "Stockholm",
            "canonical_url": "https://www.blocket.se/item/1",
            "timestamp": 1700000000000,
            "extras": [],
            "image_urls": ["https://img.com/1.jpg"],
            "coordinates": {"lat": 59.0, "lon": 18.0},
        }
    ],
    "metadata": {"result_size": {"match_count": 1}},
}


def _mock_search(*args, **kwargs):
    return SEARCH_RESPONSE


def _mock_get_ad(*args, **kwargs):
    return {
        "@type": "Product",
        "name": "Test soffa",
        "description": "En fin soffa",
        "offers": {"price": "2000", "priceCurrency": "SEK"},
        "url": "https://www.blocket.se/item/1",
    }


class TestSearchCommand:
    def test_table_output(self):
        with patch("blocket_cli.cli.api.search", _mock_search):
            result = CliRunner().invoke(main, ["search", "soffa"])
        assert result.exit_code == 0
        assert "Test soffa" in result.output
        assert "2 000 kr" in result.output

    def test_json_output_is_slim(self):
        with patch("blocket_cli.cli.api.search", _mock_search):
            result = CliRunner().invoke(main, ["search", "soffa", "-o", "json"])
        data = json.loads(result.output)
        listing = data["results"][0]
        assert listing["id"] == "1"
        assert listing["price"] == 2000
        assert "image_urls" not in listing
        assert "coordinates" not in listing

    def test_json_raw_output(self):
        with patch("blocket_cli.cli.api.search", _mock_search):
            result = CliRunner().invoke(main, ["search", "soffa", "-o", "json", "--raw"])
        data = json.loads(result.output)
        listing = data["results"][0]
        assert "image_urls" in listing
        assert "coordinates" in listing

    def test_limit(self):
        with patch("blocket_cli.cli.api.search", _mock_search):
            result = CliRunner().invoke(main, ["search", "soffa", "-o", "json", "-n", "1"])
        data = json.loads(result.output)
        assert len(data["results"]) == 1

    def test_invalid_category(self):
        result = CliRunner().invoke(main, ["search", "x", "-c", "badcat"])
        assert result.exit_code == 1
        assert "Unknown category" in result.output

    def test_invalid_location(self):
        result = CliRunner().invoke(main, ["search", "x", "-l", "narnia"])
        assert result.exit_code == 1
        assert "Unknown location" in result.output


class TestAdCommand:
    def test_table_output(self):
        with patch("blocket_cli.cli.api.get_ad", _mock_get_ad):
            result = CliRunner().invoke(main, ["ad", "1"])
        assert result.exit_code == 0
        assert "Test soffa" in result.output
        assert "2000 SEK" in result.output

    def test_json_output(self):
        with patch("blocket_cli.cli.api.get_ad", _mock_get_ad):
            result = CliRunner().invoke(main, ["ad", "1", "-o", "json"])
        data = json.loads(result.output)
        assert data["name"] == "Test soffa"


CAR_SEARCH_RESPONSE = {
    "docs": [
        {
            "id": "100",
            "heading": "Volvo V60 D4",
            "price": {"amount": 189000, "currency_code": "SEK", "price_unit": "kr"},
            "location": "Stockholm",
            "canonical_url": "https://www.blocket.se/mobility/item/100",
            "timestamp": 1700000000000,
            "year": 2019,
            "mileage": 4500,
            "make": "Volvo",
            "model": "V60",
            "fuel": "Diesel",
            "transmission": "Automatisk",
            "extras": [],
        }
    ],
    "metadata": {"result_size": {"match_count": 1}},
}

BOAT_SEARCH_RESPONSE = {
    "docs": [
        {
            "id": "200",
            "heading": "Bayliner 742",
            "price": {"amount": 450000, "currency_code": "SEK", "price_unit": "kr"},
            "location": "Göteborg",
            "canonical_url": "https://www.blocket.se/mobility/item/200",
            "timestamp": 1700000000000,
            "year": 2020,
            "length": 24,
            "make": "Bayliner",
            "boat_class": "Bowrider",
            "motor_type": "Utombordare",
            "extras": [],
        }
    ],
    "metadata": {"result_size": {"match_count": 1}},
}

MC_SEARCH_RESPONSE = {
    "docs": [
        {
            "id": "300",
            "heading": "Yamaha MT-07",
            "price": {"amount": 69000, "currency_code": "SEK", "price_unit": "kr"},
            "location": "Malmö",
            "canonical_url": "https://www.blocket.se/mobility/item/300",
            "timestamp": 1700000000000,
            "year": 2021,
            "make": "Yamaha",
            "mileage": 800,
            "extras": [],
        }
    ],
    "metadata": {"result_size": {"match_count": 1}},
}


class TestCarsCommand:
    def test_table_output(self):
        with patch("blocket_cli.cli.api.search_cars", return_value=CAR_SEARCH_RESPONSE):
            result = CliRunner().invoke(main, ["cars", "volvo"])
        assert result.exit_code == 0
        assert "Volvo V60 D4" in result.output
        assert "189 000 kr" in result.output
        assert "4 500 mil" in result.output

    def test_json_output_is_slim(self):
        with patch("blocket_cli.cli.api.search_cars", return_value=CAR_SEARCH_RESPONSE):
            result = CliRunner().invoke(main, ["cars", "volvo", "-o", "json"])
        data = json.loads(result.output)
        listing = data["results"][0]
        assert listing["id"] == "100"
        assert listing["year"] == 2019
        assert listing["mileage_mil"] == 4500
        assert listing["make"] == "Volvo"
        assert listing["fuel"] == "Diesel"
        assert "extras" not in listing

    def test_invalid_fuel(self):
        result = CliRunner().invoke(main, ["cars", "volvo", "--fuel", "hydrogen"])
        assert result.exit_code == 1
        assert "Unknown fuel" in result.output

    def test_invalid_location(self):
        result = CliRunner().invoke(main, ["cars", "volvo", "-l", "narnia"])
        assert result.exit_code == 1
        assert "Unknown location" in result.output


class TestBoatsCommand:
    def test_table_output(self):
        with patch("blocket_cli.cli.api.search_boats", return_value=BOAT_SEARCH_RESPONSE):
            result = CliRunner().invoke(main, ["boats", "bayliner"])
        assert result.exit_code == 0
        assert "Bayliner 742" in result.output
        assert "450 000 kr" in result.output

    def test_json_output_is_slim(self):
        with patch("blocket_cli.cli.api.search_boats", return_value=BOAT_SEARCH_RESPONSE):
            result = CliRunner().invoke(main, ["boats", "bayliner", "-o", "json"])
        data = json.loads(result.output)
        listing = data["results"][0]
        assert listing["id"] == "200"
        assert listing["length_ft"] == 24
        assert listing["boat_class"] == "Bowrider"
        assert "extras" not in listing


class TestMcCommand:
    def test_table_output(self):
        with patch("blocket_cli.cli.api.search_mc", return_value=MC_SEARCH_RESPONSE):
            result = CliRunner().invoke(main, ["mc", "yamaha"])
        assert result.exit_code == 0
        assert "Yamaha MT-07" in result.output
        assert "69 000 kr" in result.output

    def test_json_output_is_slim(self):
        with patch("blocket_cli.cli.api.search_mc", return_value=MC_SEARCH_RESPONSE):
            result = CliRunner().invoke(main, ["mc", "yamaha", "-o", "json"])
        data = json.loads(result.output)
        listing = data["results"][0]
        assert listing["id"] == "300"
        assert listing["year"] == 2021
        assert listing["make"] == "Yamaha"
        assert "extras" not in listing


class TestListCommands:
    def test_categories(self):
        result = CliRunner().invoke(main, ["categories"])
        assert result.exit_code == 0
        assert "electronics" in result.output

    def test_locations(self):
        result = CliRunner().invoke(main, ["locations"])
        assert result.exit_code == 0
        assert "stockholm" in result.output

    def test_fuels(self):
        result = CliRunner().invoke(main, ["fuels"])
        assert result.exit_code == 0
        assert "diesel" in result.output
        assert "el" in result.output
