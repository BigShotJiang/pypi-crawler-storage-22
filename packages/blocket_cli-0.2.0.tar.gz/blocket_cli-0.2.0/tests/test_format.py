"""Tests for output formatting."""

from __future__ import annotations

import json

from blocket_cli.format import _slim, _slim_boat, _slim_car, _slim_mc


class TestSlim:
    def test_essential_fields(self):
        doc = {
            "id": "123",
            "heading": "Test item",
            "price": {"amount": 500, "currency_code": "SEK", "price_unit": "kr"},
            "location": "Stockholm",
            "canonical_url": "https://www.blocket.se/item/123",
            "timestamp": 1700000000000,
        }
        result = _slim(doc)
        assert result == {
            "id": "123",
            "heading": "Test item",
            "price": 500,
            "currency": "SEK",
            "location": "Stockholm",
            "url": "https://www.blocket.se/item/123",
            "date": "2023-11-14",
        }

    def test_strips_images_and_coordinates(self):
        doc = {
            "id": "1",
            "heading": "X",
            "price": {"amount": 100, "currency_code": "SEK"},
            "location": "A",
            "canonical_url": "https://example.com",
            "image": {"url": "https://img.com/1.jpg", "width": 800, "height": 600},
            "image_urls": ["https://img.com/1.jpg", "https://img.com/2.jpg"],
            "coordinates": {"lat": 59.0, "lon": 18.0},
            "flags": ["private"],
            "labels": [{"id": "private", "text": "Privat"}],
            "ad_type": 67,
            "distance": 0.0,
            "main_search_key": "SEARCH_ID_BAP_ALL",
        }
        result = _slim(doc)
        assert "image" not in result
        assert "image_urls" not in result
        assert "coordinates" not in result
        assert "flags" not in result
        assert "labels" not in result
        assert "ad_type" not in result
        assert "distance" not in result
        assert "main_search_key" not in result

    def test_extracts_brand(self):
        doc = {
            "id": "1",
            "heading": "Phone",
            "price": {"amount": 3000, "currency_code": "SEK"},
            "location": "Malmö",
            "canonical_url": "https://example.com",
            "extras": [{"id": "brand", "values": ["Apple"]}],
        }
        assert _slim(doc)["brand"] == "Apple"

    def test_no_brand_when_missing(self):
        doc = {
            "id": "1",
            "heading": "Thing",
            "price": {"amount": 100, "currency_code": "SEK"},
            "location": "A",
            "canonical_url": "https://example.com",
            "extras": [],
        }
        assert "brand" not in _slim(doc)

    def test_no_timestamp(self):
        doc = {
            "id": "1",
            "heading": "X",
            "price": {},
            "location": "A",
            "canonical_url": "https://example.com",
        }
        result = _slim(doc)
        assert "date" not in result

    def test_output_is_json_serializable(self):
        doc = {
            "id": "1",
            "heading": "Ö-ring",
            "price": {"amount": 50, "currency_code": "SEK"},
            "location": "Göteborg",
            "canonical_url": "https://example.com",
            "timestamp": 1700000000000,
            "extras": [{"id": "brand", "values": ["IKEA"]}],
        }
        dumped = json.dumps(_slim(doc), ensure_ascii=False)
        assert "Ö-ring" in dumped
        assert "Göteborg" in dumped


class TestSlimCar:
    def test_essential_fields(self):
        doc = {
            "id": "100",
            "heading": "Volvo V60 D4",
            "price": {"amount": 189000, "currency_code": "SEK"},
            "location": "Stockholm",
            "canonical_url": "https://www.blocket.se/mobility/item/100",
            "timestamp": 1700000000000,
            "year": 2019,
            "mileage": 4500,
            "make": "Volvo",
            "model": "V60",
            "fuel": "Diesel",
            "transmission": "Automatisk",
            "image": {"url": "https://img.com/1.jpg"},
            "coordinates": {"lat": 59.0, "lon": 18.0},
            "flags": [],
        }
        result = _slim_car(doc)
        assert result["year"] == 2019
        assert result["mileage_mil"] == 4500
        assert result["make"] == "Volvo"
        assert result["model"] == "V60"
        assert result["fuel"] == "Diesel"
        assert result["transmission"] == "Automatisk"
        assert "image" not in result
        assert "coordinates" not in result
        assert "flags" not in result

    def test_missing_optional_fields(self):
        doc = {
            "id": "1",
            "heading": "Car",
            "price": {"amount": 100, "currency_code": "SEK"},
            "location": "A",
            "canonical_url": "https://example.com",
        }
        result = _slim_car(doc)
        assert "year" not in result
        assert "mileage_mil" not in result
        assert "make" not in result


class TestSlimBoat:
    def test_essential_fields(self):
        doc = {
            "id": "200",
            "heading": "Bayliner 742",
            "price": {"amount": 450000, "currency_code": "SEK"},
            "location": "Göteborg",
            "canonical_url": "https://www.blocket.se/mobility/item/200",
            "timestamp": 1700000000000,
            "year": 2020,
            "length": 24,
            "make": "Bayliner",
            "boat_class": "Bowrider",
            "motor_type": "Utombordare",
        }
        result = _slim_boat(doc)
        assert result["year"] == 2020
        assert result["length_ft"] == 24
        assert result["make"] == "Bayliner"
        assert result["boat_class"] == "Bowrider"
        assert result["motor_type"] == "Utombordare"


class TestSlimMc:
    def test_essential_fields(self):
        doc = {
            "id": "300",
            "heading": "Yamaha MT-07",
            "price": {"amount": 69000, "currency_code": "SEK"},
            "location": "Malmö",
            "canonical_url": "https://www.blocket.se/mobility/item/300",
            "timestamp": 1700000000000,
            "year": 2021,
            "make": "Yamaha",
            "mileage": 800,
        }
        result = _slim_mc(doc)
        assert result["year"] == 2021
        assert result["make"] == "Yamaha"
        assert result["mileage_mil"] == 800
