from setuptools import setup, find_packages

# get requirements from requirements.txt
with open("requirements.txt") as f:
    requirements = f.read().splitlines()

setup(
    name="blocks_control_sdk",  
    version="0.2.0rc2",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "blocks_control_sdk": [
            "prompts/base/*.j2",
            "prompts/sections/*.j2",
        ],
    },
    install_requires=requirements,
    description="A unified Python interface to interact with popular coding agents.",
    author="BlocksOrg",
    license="AGPL",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author_email="dev@blocks.team",
    url="https://github.com/BlocksOrg/blocks-control-sdk",  
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: GNU Affero General Public License v3",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
        "Topic :: Software Development :: Build Tools",
        "Topic :: Software Development :: Bug Tracking",
        "Topic :: Software Development :: Debuggers",
        "Topic :: Software Development :: Code Generators",
        "Topic :: Software Development :: Version Control :: Git",
        "Topic :: Communications :: Chat",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires='>=3.9',  
)
