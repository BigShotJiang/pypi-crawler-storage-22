"""Blockchain Discrete Event Simulator."""

__version__ = "1.5.0"
