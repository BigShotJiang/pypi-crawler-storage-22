athor = 'BloodSpider'
description = 'BloodSpider 是 Spider 系列必备的辅助库, 方便开发者理解程序运行逻辑'
version = '1.0.6'
contact_method = {
    "wexin": "duyanbz"
}