import requests
# 代理IP工具类
class ProxyIpToolkit:
    """
    代理IP工具类
    ~~~~~~~~~~~~~~~~~~~~~
    极安代理: https://www.ja.cn/user
    """
    
    def __init__(self):
        pass

        
        
