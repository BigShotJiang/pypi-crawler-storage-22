"""Bloop error reporting client for Python."""

import atexit
import hashlib
import hmac
import json
import sys
import threading
import traceback
import urllib.request
from typing import Any, Optional


class BloopClient:
    """Captures and sends error events to a bloop server.

    Usage:
        client = BloopClient("https://bloop.example.com", "your-project-key")
        client.capture("TypeError", "something went wrong", stack="...")
        client.close()

    Or as a context manager:
        with BloopClient("https://bloop.example.com", "key") as client:
            client.capture("ValueError", "bad input")
    """

    def __init__(
        self,
        endpoint: str,
        project_key: str,
        *,
        flush_interval: float = 5.0,
        max_buffer_size: int = 100,
        environment: str = "production",
        release: str = "",
        auto_capture: bool = False,
    ) -> None:
        self.endpoint = endpoint.rstrip("/")
        self.project_key = project_key
        self.flush_interval = flush_interval
        self.max_buffer_size = max_buffer_size
        self.environment = environment
        self.release = release

        self._buffer: list[dict[str, Any]] = []
        self._trace_buffer: list[dict[str, Any]] = []
        self._custom_model_costs: dict[str, dict[str, float]] = {}
        self._lock = threading.Lock()
        self._closed = False
        self._timer: Optional[threading.Timer] = None
        self._original_excepthook = sys.excepthook
        self._original_threading_excepthook: Any = None

        if auto_capture:
            self._install_excepthook()

        self._schedule_flush()
        atexit.register(self.close)

    def _install_excepthook(self) -> None:
        original = sys.excepthook

        def hook(exc_type, exc_value, exc_tb):
            self.capture_exception(exc_value, exc_tb=exc_tb)
            self.flush()
            original(exc_type, exc_value, exc_tb)

        sys.excepthook = hook

        # Hook threading.excepthook for crashes in spawned threads (Python 3.8+)
        if hasattr(threading, "excepthook"):
            self._original_threading_excepthook = threading.excepthook

            def thread_hook(args):
                self.capture_exception(args.exc_value, exc_tb=args.exc_traceback)
                self.flush()
                if self._original_threading_excepthook:
                    self._original_threading_excepthook(args)

            threading.excepthook = thread_hook

    def capture_exception(
        self,
        exc: BaseException,
        *,
        exc_tb: Any = None,
        source: str = "python",
        route_or_procedure: str = "",
        screen: str = "",
        metadata: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Capture a Python exception with full traceback.

        Args:
            exc: The exception to capture.
            exc_tb: Optional traceback object. If not provided, uses exc.__traceback__.
        """
        tb = exc_tb or exc.__traceback__
        stack = "".join(traceback.format_exception(type(exc), exc, tb))
        self.capture(
            error_type=type(exc).__name__,
            message=str(exc),
            source=source,
            stack=stack,
            route_or_procedure=route_or_procedure,
            screen=screen,
            metadata=metadata,
            **kwargs,
        )

    def capture(
        self,
        error_type: str,
        message: str,
        *,
        source: str = "python",
        stack: str = "",
        route_or_procedure: str = "",
        screen: str = "",
        metadata: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Buffer an error event for sending."""
        if self._closed:
            return

        import time

        event: dict[str, Any] = {
            "timestamp": int(time.time() * 1000),
            "source": source,
            "environment": self.environment,
            "error_type": error_type,
            "message": message,
        }
        if self.release:
            event["release"] = self.release
        if stack:
            event["stack"] = stack
        if route_or_procedure:
            event["route_or_procedure"] = route_or_procedure
        if screen:
            event["screen"] = screen
        if metadata:
            event["metadata"] = metadata

        # Allow extra kwargs to pass through
        for k, v in kwargs.items():
            if k not in event:
                event[k] = v

        with self._lock:
            self._buffer.append(event)
            if len(self._buffer) >= self.max_buffer_size:
                self._flush_locked()

    def start_trace(
        self,
        name: str,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        input: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
        prompt_name: Optional[str] = None,
        prompt_version: Optional[str] = None,
    ) -> "Trace":
        """Create a new LLM trace. Call trace.end() when done."""
        from bloop.tracing import Trace

        return Trace(
            client=self,
            name=name,
            session_id=session_id,
            user_id=user_id,
            input=input,
            metadata=metadata,
            prompt_name=prompt_name,
            prompt_version=prompt_version,
        )

    def trace(self, name: str, **kwargs: Any) -> "Trace":
        """Alias for start_trace, usable as context manager."""
        return self.start_trace(name, **kwargs)

    def wrap_openai(self, client: Any) -> Any:
        """Wrap an OpenAI-compatible client for automatic LLM tracing.

        Works with any OpenAI-compatible provider (OpenAI, Minimax, Kimi, etc.).
        Provider is auto-detected from the client's base_url.
        """
        from bloop.integrations.openai import wrap_openai_client

        return wrap_openai_client(self, client)

    def wrap_anthropic(self, client: Any) -> Any:
        """Wrap an Anthropic client for automatic LLM tracing."""
        from bloop.integrations.anthropic import wrap_anthropic_client

        return wrap_anthropic_client(self, client)

    def set_model_costs(self, model: str, costs: dict[str, float]) -> None:
        """Override or add custom model pricing.

        Args:
            model: Model name (e.g. "my-fine-tune")
            costs: Dict with "input" and "output" keys (per-token cost in dollars)
        """
        self._custom_model_costs[model] = costs

    def _enqueue_trace(self, trace: Any) -> None:
        """Called by Trace.end() to push completed trace to buffer."""
        with self._lock:
            self._trace_buffer.append(trace.to_dict())
            if len(self._trace_buffer) >= self.max_buffer_size:
                self._flush_traces_locked()

    def _flush_traces_locked(self) -> None:
        """Flush trace buffer while holding the lock."""
        if not self._trace_buffer:
            return
        traces = self._trace_buffer[:]
        self._trace_buffer.clear()
        thread = threading.Thread(target=self._send_traces, args=(traces,), daemon=True)
        thread.start()

    def _send_traces(self, traces: list[dict[str, Any]]) -> None:
        """Send traces to the bloop server in batches of 50."""
        for i in range(0, len(traces), 50):
            batch = traces[i : i + 50]
            body = json.dumps({"traces": batch}).encode("utf-8")
            signature = hmac.new(
                self.project_key.encode("utf-8"),
                body,
                hashlib.sha256,
            ).hexdigest()
            req = urllib.request.Request(
                f"{self.endpoint}/v1/traces/batch",
                data=body,
                headers={
                    "Content-Type": "application/json",
                    "X-Signature": signature,
                    "X-Project-Key": self.project_key,
                },
                method="POST",
            )
            try:
                with urllib.request.urlopen(req, timeout=10) as resp:
                    resp.read()
            except Exception:
                pass  # Fire and forget

    def flush(self) -> None:
        """Send all buffered events and traces immediately."""
        with self._lock:
            self._flush_locked()
            self._flush_traces_locked()

    def _flush_locked(self) -> None:
        """Flush buffer while holding the lock."""
        if not self._buffer:
            return

        events = self._buffer[:]
        self._buffer.clear()

        # Send in background to avoid blocking
        thread = threading.Thread(target=self._send, args=(events,), daemon=True)
        thread.start()

    def _send(self, events: list[dict[str, Any]]) -> None:
        """Send events to the bloop server."""
        if len(events) == 1:
            url = f"{self.endpoint}/v1/ingest"
            body = json.dumps(events[0]).encode("utf-8")
        else:
            url = f"{self.endpoint}/v1/ingest/batch"
            body = json.dumps({"events": events}).encode("utf-8")

        signature = hmac.new(
            self.project_key.encode("utf-8"),
            body,
            hashlib.sha256,
        ).hexdigest()

        req = urllib.request.Request(
            url,
            data=body,
            headers={
                "Content-Type": "application/json",
                "X-Signature": signature,
                "X-Project-Key": self.project_key,
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                resp.read()
        except Exception:
            pass  # Fire and forget — don't crash the host app

    def _schedule_flush(self) -> None:
        """Schedule the next periodic flush."""
        if self._closed:
            return
        self._timer = threading.Timer(self.flush_interval, self._periodic_flush)
        self._timer.daemon = True
        self._timer.start()

    def _periodic_flush(self) -> None:
        """Called by the timer to flush and reschedule."""
        self.flush()
        self._schedule_flush()

    def close(self) -> None:
        """Flush remaining events and stop the background timer."""
        self._closed = True
        if self._timer:
            self._timer.cancel()
        self.flush()
        sys.excepthook = self._original_excepthook
        if self._original_threading_excepthook is not None and hasattr(threading, "excepthook"):
            threading.excepthook = self._original_threading_excepthook
        atexit.unregister(self.close)

    def __enter__(self) -> "BloopClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
