"""Bloop error reporting and LLM tracing client for Python."""

import hashlib
import hmac
import json
import threading
import time
import urllib.error
import urllib.request
import uuid
from typing import Any, Dict, List, Optional


class BloopClient:
    """Captures and sends error events and LLM traces to a bloop server.

    Usage:
        client = BloopClient("https://bloop.example.com", "your-project-key")
        client.capture("TypeError", "something went wrong", stack="...")
        client.close()

    Or as a context manager:
        with BloopClient("https://bloop.example.com", "key") as client:
            client.capture("ValueError", "bad input")
    """

    def __init__(
        self,
        endpoint: str,
        project_key: str,
        flush_interval: float = 5.0,
        max_buffer_size: int = 100,
        environment: str = "production",
        release: str = "",
        auto_capture: bool = False,
    ):
        self.endpoint = endpoint.rstrip("/")
        self.project_key = project_key
        self.flush_interval = flush_interval
        self.max_buffer_size = max_buffer_size
        self.environment = environment
        self.release = release
        self.auto_capture = auto_capture

        self._buffer: List[Dict[str, Any]] = []
        self._trace_buffer: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._timer: Optional[threading.Timer] = None
        self._closed = False

        self._schedule_flush()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # ── Error Tracking ──

    def capture(
        self,
        error_type: str,
        message: str,
        source: str = "python",
        stack: str = "",
        route_or_procedure: str = "",
        screen: str = "",
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs,
    ):
        """Buffer an error event for sending."""
        event = {
            "timestamp": int(time.time()),
            "source": source,
            "environment": self.environment,
            "release": self.release,
            "error_type": error_type,
            "message": message,
            "stack": stack,
            "route_or_procedure": route_or_procedure,
            "screen": screen,
            "metadata": metadata or {},
        }
        with self._lock:
            self._buffer.append(event)
            if len(self._buffer) >= self.max_buffer_size:
                self._flush_locked()

    # ── LLM Tracing ──

    def trace(
        self,
        name: str = "",
        trace_id: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        prompt_name: Optional[str] = None,
        prompt_version: Optional[str] = None,
    ) -> "Trace":
        """Create a new LLM trace. Use as a context manager or call .end() manually.

        Example:
            with client.trace(name="chat") as t:
                with t.span(model="gpt-4o") as s:
                    s.set_tokens(100, 50)
        """
        return Trace(
            client=self,
            name=name,
            trace_id=trace_id or uuid.uuid4().hex,
            session_id=session_id,
            user_id=user_id,
            prompt_name=prompt_name,
            prompt_version=prompt_version,
        )

    def _send_trace(self, trace_data: Dict[str, Any]):
        """Buffer a completed trace for batch sending."""
        with self._lock:
            self._trace_buffer.append(trace_data)
            if len(self._trace_buffer) >= 10:
                self._flush_traces_locked()

    # ── Auto-Instrumentation ──

    def wrap_openai(self, openai_client):
        """Wrap an OpenAI client instance for automatic LLM tracing.

        Returns a proxied client that auto-traces all chat.completions.create() calls.
        Cost is calculated server-side -- no pricing config needed.

        Example:
            from openai import OpenAI
            openai = client.wrap_openai(OpenAI())
            response = openai.chat.completions.create(model="gpt-4o", messages=[...])
        """
        from .integrations.openai import wrap_openai
        return wrap_openai(openai_client, self)

    def wrap_anthropic(self, anthropic_client):
        """Wrap an Anthropic client instance for automatic LLM tracing.

        Returns a proxied client that auto-traces all messages.create() calls.
        Cost is calculated server-side -- no pricing config needed.

        Example:
            import anthropic
            client_ai = client.wrap_anthropic(anthropic.Anthropic())
            response = client_ai.messages.create(model="claude-3-5-sonnet-20241022", ...)
        """
        from .integrations.anthropic import wrap_anthropic
        return wrap_anthropic(anthropic_client, self)

    def auto_instrument(self):
        """Global monkey-patch: auto-instrument OpenAI and Anthropic modules.

        Patches the default client classes so all instances are automatically traced.
        Call this once at startup.

        Example:
            client = BloopClient(endpoint="...", project_key="...")
            client.auto_instrument()
            # All OpenAI/Anthropic calls are now auto-traced
        """
        from .integrations import auto_instrument
        auto_instrument(self)

    # ── Flush & Transport ──

    def flush(self):
        """Send all buffered events and traces immediately."""
        with self._lock:
            self._flush_locked()
            self._flush_traces_locked()

    def _flush_locked(self):
        """Flush error event buffer while holding the lock."""
        if not self._buffer:
            return
        events = self._buffer[:]
        self._buffer.clear()
        self._send_events(events)

    def _flush_traces_locked(self):
        """Flush trace buffer while holding the lock."""
        if not self._trace_buffer:
            return
        traces = self._trace_buffer[:]
        self._trace_buffer.clear()
        threading.Thread(
            target=self._send_traces_batch, args=(traces,), daemon=True
        ).start()

    def _send_events(self, events: List[Dict[str, Any]]):
        """Send error events to the bloop server."""
        if len(events) == 1:
            self._post("/v1/ingest", events[0])
        else:
            self._post("/v1/ingest/batch", {"events": events})

    def _send_traces_batch(self, traces: List[Dict[str, Any]]):
        """Send traces in a batch POST."""
        try:
            self._post("/v1/traces/batch", {"traces": traces})
        except Exception:
            pass  # Fire-and-forget for trace telemetry

    def _post(self, path: str, payload: Dict[str, Any]):
        """POST JSON to bloop with HMAC auth."""
        body = json.dumps(payload).encode("utf-8")
        sig = hmac.new(
            self.project_key.encode(), body, hashlib.sha256
        ).hexdigest()
        req = urllib.request.Request(
            f"{self.endpoint}{path}",
            data=body,
            headers={
                "Content-Type": "application/json",
                "X-Signature": sig,
            },
        )
        try:
            with urllib.request.urlopen(req) as resp:
                resp.read()
        except Exception:
            pass  # Silently drop on failure (never crash the app)

    def _schedule_flush(self):
        """Schedule the next periodic flush."""
        if self._closed:
            return
        self._timer = threading.Timer(self.flush_interval, self._timer_flush)
        self._timer.daemon = True
        self._timer.start()

    def _timer_flush(self):
        """Called by the timer to flush and reschedule."""
        self.flush()
        self._schedule_flush()

    def close(self):
        """Flush remaining events and stop the background timer."""
        self._closed = True
        if self._timer:
            self._timer.cancel()
        self.flush()


class Trace:
    """Represents an LLM trace with spans. Use as a context manager."""

    def __init__(
        self,
        client: BloopClient,
        name: str,
        trace_id: str,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        prompt_name: Optional[str] = None,
        prompt_version: Optional[str] = None,
    ):
        self._client = client
        self.id = trace_id
        self.name = name
        self.session_id = session_id
        self.user_id = user_id
        self.prompt_name = prompt_name
        self.prompt_version = prompt_version
        self.status = "completed"
        self.input: Optional[str] = None
        self.output: Optional[str] = None
        self.metadata: Optional[Dict[str, Any]] = None
        self._spans: List[Dict[str, Any]] = []
        self._started_at = int(time.time() * 1000)
        self._ended_at: Optional[int] = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.status = "error"
        self.end()

    def span(
        self,
        span_type: str = "generation",
        name: str = "",
        model: Optional[str] = None,
        provider: Optional[str] = None,
        parent_span_id: Optional[str] = None,
    ) -> "Span":
        """Create a new span within this trace."""
        return Span(
            trace=self,
            span_type=span_type,
            name=name,
            model=model,
            provider=provider,
            parent_span_id=parent_span_id,
        )

    def _add_span(self, span_data: Dict[str, Any]):
        self._spans.append(span_data)

    def end(self):
        """End the trace and send it to bloop."""
        self._ended_at = int(time.time() * 1000)
        trace_data: Dict[str, Any] = {
            "id": self.id,
            "name": self.name,
            "status": self.status,
            "started_at": self._started_at,
            "ended_at": self._ended_at,
            "spans": self._spans,
        }
        if self.session_id:
            trace_data["session_id"] = self.session_id
        if self.user_id:
            trace_data["user_id"] = self.user_id
        if self.input is not None:
            trace_data["input"] = self.input
        if self.output is not None:
            trace_data["output"] = self.output
        if self.metadata is not None:
            trace_data["metadata"] = self.metadata
        if self.prompt_name is not None:
            trace_data["prompt_name"] = self.prompt_name
        if self.prompt_version is not None:
            trace_data["prompt_version"] = self.prompt_version

        self._client._send_trace(trace_data)


class Span:
    """Represents a single LLM call span. Use as a context manager."""

    def __init__(
        self,
        trace: Trace,
        span_type: str = "generation",
        name: str = "",
        model: Optional[str] = None,
        provider: Optional[str] = None,
        parent_span_id: Optional[str] = None,
    ):
        self._trace = trace
        self.id = uuid.uuid4().hex
        self.span_type = span_type
        self.name = name
        self.model = model
        self.provider = provider
        self.parent_span_id = parent_span_id
        self.input_tokens: int = 0
        self.output_tokens: int = 0
        self.cost: float = 0.0
        self.latency_ms: int = 0
        self.time_to_first_token_ms: Optional[int] = None
        self.status: str = "ok"
        self.error_message: Optional[str] = None
        self.input: Optional[str] = None
        self.output: Optional[str] = None
        self.metadata: Optional[Dict[str, Any]] = None
        self._started_at = int(time.time() * 1000)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.status = "error"
            self.error_message = str(exc_val)
        self.end()

    def set_tokens(self, input_tokens: int = 0, output_tokens: int = 0):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens

    def set_cost(self, cost: float):
        self.cost = cost

    def set_latency(self, latency_ms: int, time_to_first_token_ms: Optional[int] = None):
        self.latency_ms = latency_ms
        self.time_to_first_token_ms = time_to_first_token_ms

    def set_error(self, message: str):
        self.status = "error"
        self.error_message = message

    def end(self):
        """End the span and add it to the parent trace."""
        ended_at = int(time.time() * 1000)
        if self.latency_ms == 0:
            self.latency_ms = ended_at - self._started_at

        span_data: Dict[str, Any] = {
            "id": self.id,
            "span_type": self.span_type,
            "name": self.name,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cost": self.cost,
            "latency_ms": self.latency_ms,
            "status": self.status,
            "started_at": self._started_at,
            "ended_at": ended_at,
        }
        if self.model:
            span_data["model"] = self.model
        if self.provider:
            span_data["provider"] = self.provider
        if self.parent_span_id:
            span_data["parent_span_id"] = self.parent_span_id
        if self.time_to_first_token_ms is not None:
            span_data["time_to_first_token_ms"] = self.time_to_first_token_ms
        if self.error_message:
            span_data["error_message"] = self.error_message
        if self.input is not None:
            span_data["input"] = self.input
        if self.output is not None:
            span_data["output"] = self.output
        if self.metadata is not None:
            span_data["metadata"] = self.metadata

        self._trace._add_span(span_data)
