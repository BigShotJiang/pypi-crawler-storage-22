"""Auto-instrumentation integrations for OpenAI and Anthropic."""

from .openai import wrap_openai
from .anthropic import wrap_anthropic

__all__ = ["wrap_openai", "wrap_anthropic", "auto_instrument"]


def auto_instrument(bloop_client):
    """Global monkey-patch: replace OpenAI and Anthropic client classes.

    After calling this, any new OpenAI() or Anthropic() instance will be
    automatically instrumented for LLM tracing.
    """
    try:
        import openai
        _original_openai_init = openai.OpenAI.__init__

        def _patched_openai_init(self, *args, **kwargs):
            _original_openai_init(self, *args, **kwargs)
            wrap_openai(self, bloop_client, in_place=True)

        openai.OpenAI.__init__ = _patched_openai_init
    except ImportError:
        pass

    try:
        import anthropic
        _original_anthropic_init = anthropic.Anthropic.__init__

        def _patched_anthropic_init(self, *args, **kwargs):
            _original_anthropic_init(self, *args, **kwargs)
            wrap_anthropic(self, bloop_client, in_place=True)

        anthropic.Anthropic.__init__ = _patched_anthropic_init
    except ImportError:
        pass
