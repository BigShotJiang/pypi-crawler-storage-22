"""Anthropic auto-instrumentation for bloop LLM tracing.

Wraps `messages.create()` to automatically capture:
- Model, tokens, latency, TTFT (streaming), errors
- Cost is always 0 -- calculated server-side from pricing table
"""

import functools
import time
from typing import Any


def _detect_provider(client) -> str:
    """Detect provider from Anthropic client's base_url."""
    try:
        base_url = str(getattr(client, "base_url", getattr(client, "_base_url", "")))
        if "anthropic.com" in base_url:
            return "anthropic"
        from urllib.parse import urlparse
        host = urlparse(base_url).hostname or "anthropic"
        return host.split(".")[0]
    except Exception:
        return "anthropic"


def wrap_anthropic(anthropic_client, bloop_client, in_place: bool = False):
    """Wrap an Anthropic client for automatic LLM tracing.

    Args:
        anthropic_client: An anthropic.Anthropic() instance
        bloop_client: A bloop.BloopClient instance
        in_place: If True, patches the client in-place instead of wrapping

    Returns:
        The wrapped client (or the same client if in_place=True)
    """
    provider = _detect_provider(anthropic_client)
    original_create = anthropic_client.messages.create

    @functools.wraps(original_create)
    def traced_create(*args, **kwargs):
        model = kwargs.get("model", args[0] if args else "unknown")
        stream = kwargs.get("stream", False)
        start_ms = int(time.time() * 1000)

        trace = bloop_client.trace(name=f"{provider}/{model}")
        span = trace.span(
            span_type="generation",
            name="messages.create",
            model=model,
            provider=provider,
        )

        if stream:
            return _handle_streaming(
                original_create, args, kwargs, trace, span, start_ms
            )

        try:
            response = original_create(*args, **kwargs)
            end_ms = int(time.time() * 1000)

            # Extract usage from Anthropic response
            usage = getattr(response, "usage", None)
            if usage:
                span.set_tokens(
                    input_tokens=getattr(usage, "input_tokens", 0) or 0,
                    output_tokens=getattr(usage, "output_tokens", 0) or 0,
                )

            span.set_latency(end_ms - start_ms)
            span.cost = 0.0  # Server-side pricing
            span.model = getattr(response, "model", model)
            span.end()
            trace.end()
            return response

        except Exception as e:
            end_ms = int(time.time() * 1000)
            span.set_latency(end_ms - start_ms)
            span.set_error(str(e))
            span.end()
            trace.status = "error"
            trace.end()
            raise

    anthropic_client.messages.create = traced_create

    if in_place:
        return anthropic_client
    return anthropic_client


def _handle_streaming(original_create, args, kwargs, trace, span, start_ms):
    """Handle streaming responses, capturing TTFT and final usage."""
    response_stream = original_create(*args, **kwargs)
    first_token_seen = False
    input_tokens = 0
    output_tokens = 0
    model = kwargs.get("model", "unknown")

    def traced_stream():
        nonlocal first_token_seen, input_tokens, output_tokens, model
        try:
            for event in response_stream:
                if not first_token_seen:
                    event_type = getattr(event, "type", "")
                    if event_type == "content_block_delta":
                        first_token_seen = True
                        ttft = int(time.time() * 1000) - start_ms
                        span.time_to_first_token_ms = ttft

                # Track usage from message_start event
                event_type = getattr(event, "type", "")
                if event_type == "message_start":
                    msg = getattr(event, "message", None)
                    if msg:
                        model = getattr(msg, "model", model)
                        usage = getattr(msg, "usage", None)
                        if usage:
                            input_tokens = getattr(usage, "input_tokens", 0) or 0

                # Track output tokens from message_delta event
                if event_type == "message_delta":
                    usage = getattr(event, "usage", None)
                    if usage:
                        output_tokens = getattr(usage, "output_tokens", 0) or 0

                yield event

            # Stream ended successfully
            end_ms = int(time.time() * 1000)
            span.set_tokens(input_tokens, output_tokens)
            span.set_latency(end_ms - start_ms)
            span.cost = 0.0
            span.model = model
            span.end()
            trace.end()

        except Exception as e:
            end_ms = int(time.time() * 1000)
            span.set_tokens(input_tokens, output_tokens)
            span.set_latency(end_ms - start_ms)
            span.set_error(str(e))
            span.end()
            trace.status = "error"
            trace.end()
            raise

    return traced_stream()
