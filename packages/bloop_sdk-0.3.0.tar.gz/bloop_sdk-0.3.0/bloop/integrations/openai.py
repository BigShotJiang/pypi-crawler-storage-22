"""OpenAI auto-instrumentation for bloop LLM tracing.

Wraps `chat.completions.create()` to automatically capture:
- Model, tokens, latency, TTFT (streaming), errors
- Cost is always 0 -- calculated server-side from pricing table
"""

import functools
import time
from typing import Any


# Provider auto-detection from base URL
PROVIDER_MAP = {
    "api.openai.com": "openai",
    "api.minimax.io": "minimax",
    "api.moonshot.ai": "kimi",
    "generativelanguage.googleapis.com": "google",
}


def _detect_provider(client) -> str:
    """Detect provider from OpenAI client's base_url."""
    try:
        base_url = str(getattr(client, "base_url", ""))
        for domain, provider in PROVIDER_MAP.items():
            if domain in base_url:
                return provider
        # Extract hostname as fallback
        from urllib.parse import urlparse
        host = urlparse(base_url).hostname or "openai"
        return host.split(".")[0]
    except Exception:
        return "openai"


def wrap_openai(openai_client, bloop_client, in_place: bool = False):
    """Wrap an OpenAI client for automatic LLM tracing.

    Args:
        openai_client: An openai.OpenAI() instance
        bloop_client: A bloop.BloopClient instance
        in_place: If True, patches the client in-place instead of wrapping

    Returns:
        The wrapped client (or the same client if in_place=True)
    """
    provider = _detect_provider(openai_client)
    original_create = openai_client.chat.completions.create

    @functools.wraps(original_create)
    def traced_create(*args, **kwargs):
        model = kwargs.get("model", args[0] if args else "unknown")
        stream = kwargs.get("stream", False)
        start_ms = int(time.time() * 1000)

        trace = bloop_client.trace(name=f"{provider}/{model}")
        span = trace.span(
            span_type="generation",
            name=f"chat.completions.create",
            model=model,
            provider=provider,
        )

        if stream:
            return _handle_streaming(
                original_create, args, kwargs, trace, span, start_ms
            )

        try:
            response = original_create(*args, **kwargs)
            end_ms = int(time.time() * 1000)

            # Extract usage
            usage = getattr(response, "usage", None)
            if usage:
                span.set_tokens(
                    input_tokens=getattr(usage, "prompt_tokens", 0) or 0,
                    output_tokens=getattr(usage, "completion_tokens", 0) or 0,
                )

            span.set_latency(end_ms - start_ms)
            span.cost = 0.0  # Server-side pricing
            span.model = getattr(response, "model", model)
            span.end()
            trace.end()
            return response

        except Exception as e:
            end_ms = int(time.time() * 1000)
            span.set_latency(end_ms - start_ms)
            span.set_error(str(e))
            span.end()
            trace.status = "error"
            trace.end()
            raise

    openai_client.chat.completions.create = traced_create

    if in_place:
        return openai_client
    return openai_client


def _handle_streaming(original_create, args, kwargs, trace, span, start_ms):
    """Handle streaming responses, capturing TTFT and final usage."""
    response_stream = original_create(*args, **kwargs)
    first_token_seen = False
    input_tokens = 0
    output_tokens = 0
    model = kwargs.get("model", "unknown")

    def traced_stream():
        nonlocal first_token_seen, input_tokens, output_tokens, model
        try:
            for chunk in response_stream:
                if not first_token_seen:
                    first_token_seen = True
                    ttft = int(time.time() * 1000) - start_ms
                    span.time_to_first_token_ms = ttft

                # Track model from chunk
                chunk_model = getattr(chunk, "model", None)
                if chunk_model:
                    model = chunk_model

                # Track usage from final chunk (OpenAI includes it with stream_options)
                usage = getattr(chunk, "usage", None)
                if usage:
                    input_tokens = getattr(usage, "prompt_tokens", 0) or 0
                    output_tokens = getattr(usage, "completion_tokens", 0) or 0

                yield chunk

            # Stream ended successfully
            end_ms = int(time.time() * 1000)
            span.set_tokens(input_tokens, output_tokens)
            span.set_latency(end_ms - start_ms)
            span.cost = 0.0
            span.model = model
            span.end()
            trace.end()

        except Exception as e:
            end_ms = int(time.time() * 1000)
            span.set_tokens(input_tokens, output_tokens)
            span.set_latency(end_ms - start_ms)
            span.set_error(str(e))
            span.end()
            trace.status = "error"
            trace.end()
            raise

    return traced_stream()
