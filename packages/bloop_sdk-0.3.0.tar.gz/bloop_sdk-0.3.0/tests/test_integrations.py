"""Tests for auto-instrumentation integrations.

These tests use mock objects to simulate OpenAI/Anthropic clients
without requiring the actual libraries to be installed.
"""

import time
import unittest
from unittest.mock import MagicMock, patch
from bloop.client import BloopClient


class MockUsage:
    def __init__(self, prompt_tokens=0, completion_tokens=0, input_tokens=0, output_tokens=0):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


class MockResponse:
    def __init__(self, model="gpt-4o", usage=None):
        self.model = model
        self.usage = usage or MockUsage()


class MockCompletions:
    def create(self, **kwargs):
        return MockResponse(
            model=kwargs.get("model", "gpt-4o"),
            usage=MockUsage(prompt_tokens=100, completion_tokens=50),
        )


class MockChat:
    def __init__(self):
        self.completions = MockCompletions()


class MockOpenAIClient:
    base_url = "https://api.openai.com/v1"

    def __init__(self):
        self.chat = MockChat()


class MockAnthropicUsage:
    def __init__(self, input_tokens=0, output_tokens=0):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


class MockAnthropicResponse:
    def __init__(self, model="claude-3-5-sonnet-20241022", usage=None):
        self.model = model
        self.usage = usage or MockAnthropicUsage()


class MockMessages:
    def create(self, **kwargs):
        return MockAnthropicResponse(
            model=kwargs.get("model", "claude-3-5-sonnet-20241022"),
            usage=MockAnthropicUsage(input_tokens=200, output_tokens=80),
        )


class MockAnthropicClient:
    base_url = "https://api.anthropic.com"

    def __init__(self):
        self.messages = MockMessages()


class TestOpenAIIntegration(unittest.TestCase):
    def test_wrap_openai_captures_trace(self):
        bloop = BloopClient("http://localhost:5332", "test-key")
        bloop._post = MagicMock()  # Mock HTTP calls

        openai_client = MockOpenAIClient()
        wrapped = bloop.wrap_openai(openai_client)

        response = wrapped.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )

        assert response.model == "gpt-4o"
        assert response.usage.prompt_tokens == 100
        assert response.usage.completion_tokens == 50

        # Verify a trace was buffered
        assert len(bloop._trace_buffer) == 1
        trace = bloop._trace_buffer[0]
        assert trace["name"] == "openai/gpt-4o"
        assert len(trace["spans"]) == 1
        span = trace["spans"][0]
        assert span["model"] == "gpt-4o"
        assert span["provider"] == "openai"
        assert span["input_tokens"] == 100
        assert span["output_tokens"] == 50
        assert span["cost"] == 0.0  # Server-side pricing
        assert span["latency_ms"] >= 0

        bloop.close()

    def test_wrap_openai_captures_error(self):
        bloop = BloopClient("http://localhost:5332", "test-key")
        bloop._post = MagicMock()

        openai_client = MockOpenAIClient()

        # Make create() raise an error
        def failing_create(**kwargs):
            raise RuntimeError("API rate limited")

        openai_client.chat.completions.create = failing_create
        wrapped = bloop.wrap_openai(openai_client)

        with self.assertRaises(RuntimeError):
            wrapped.chat.completions.create(model="gpt-4o", messages=[])

        assert len(bloop._trace_buffer) == 1
        trace = bloop._trace_buffer[0]
        assert trace["status"] == "error"
        span = trace["spans"][0]
        assert span["status"] == "error"
        assert "rate limited" in span["error_message"]

        bloop.close()

    def test_provider_detection(self):
        from bloop.integrations.openai import _detect_provider

        client = MockOpenAIClient()
        assert _detect_provider(client) == "openai"

        client.base_url = "https://api.minimax.io/v1"
        assert _detect_provider(client) == "minimax"


class TestAnthropicIntegration(unittest.TestCase):
    def test_wrap_anthropic_captures_trace(self):
        bloop = BloopClient("http://localhost:5332", "test-key")
        bloop._post = MagicMock()

        anthropic_client = MockAnthropicClient()
        wrapped = bloop.wrap_anthropic(anthropic_client)

        response = wrapped.messages.create(
            model="claude-3-5-sonnet-20241022",
            messages=[{"role": "user", "content": "Hello"}],
            max_tokens=1024,
        )

        assert response.model == "claude-3-5-sonnet-20241022"

        assert len(bloop._trace_buffer) == 1
        trace = bloop._trace_buffer[0]
        assert trace["name"] == "anthropic/claude-3-5-sonnet-20241022"
        span = trace["spans"][0]
        assert span["model"] == "claude-3-5-sonnet-20241022"
        assert span["provider"] == "anthropic"
        assert span["input_tokens"] == 200
        assert span["output_tokens"] == 80
        assert span["cost"] == 0.0

        bloop.close()


class TestManualTracing(unittest.TestCase):
    def test_context_manager_trace(self):
        bloop = BloopClient("http://localhost:5332", "test-key")
        bloop._post = MagicMock()

        with bloop.trace(name="test-trace") as t:
            with t.span(model="gpt-4o", provider="openai") as s:
                s.set_tokens(100, 50)

        assert len(bloop._trace_buffer) == 1
        trace = bloop._trace_buffer[0]
        assert trace["name"] == "test-trace"
        assert trace["status"] == "completed"
        assert len(trace["spans"]) == 1
        span = trace["spans"][0]
        assert span["input_tokens"] == 100
        assert span["output_tokens"] == 50

        bloop.close()

    def test_error_in_trace_sets_status(self):
        bloop = BloopClient("http://localhost:5332", "test-key")
        bloop._post = MagicMock()

        try:
            with bloop.trace(name="failing-trace") as t:
                with t.span(model="gpt-4o") as s:
                    raise ValueError("bad input")
        except ValueError:
            pass

        trace = bloop._trace_buffer[0]
        assert trace["status"] == "error"
        span = trace["spans"][0]
        assert span["status"] == "error"
        assert "bad input" in span["error_message"]

        bloop.close()


if __name__ == "__main__":
    unittest.main()
