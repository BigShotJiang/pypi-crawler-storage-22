from kirin import types


class State:
    pass


StateType = types.PyClass(State)


class MeasurementFuture:
    pass


MeasurementFutureType = types.PyClass(MeasurementFuture)
