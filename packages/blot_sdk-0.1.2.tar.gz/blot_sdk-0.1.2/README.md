# BLOT SDK

**Autonomous trading bots for Solana** — Self-replicating, AI-powered trading infrastructure.

[![PyPI version](https://badge.fury.io/py/blot-sdk.svg)](https://badge.fury.io/py/blot-sdk)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Features

- **AI-Powered** — Integrated with OpenClaw for intelligent decision making
- **24/7 Autonomous** — Bots run continuously without human intervention
- **Self-Cloning** — Automatic replication across distributed nodes for maximum resilience
- **Zero-Logging** — Complete privacy, no transaction data stored
- **High Speed** — Sub-50ms execution on Solana
- **Easy to Use** — Simple Python API for complex trading strategies

## Installation

```bash
pip install blot-sdk
```

## Quick Start

```python
from blot_sdk import Bot, SniperBot, DCABot

# Initialize with your wallet
bot = Bot(
    private_key="your_private_key",
    rpc_url="https://api.mainnet-beta.solana.com"
)

# Create a sniper bot
sniper = SniperBot(
    target="new",           # Snipe all new tokens
    buy_amount=0.5,         # Buy with 0.5 SOL
    take_profit=[2.0, 5.0], # Sell at 2x and 5x
    stop_loss=0.5,          # Stop loss at -50%
)

# Deploy to BLOT infrastructure
bot.deploy(sniper, duration_days=30)
```

## Available Bots

### Sniper Bot
Instantly purchase tokens the moment liquidity is added.

```python
from blot_sdk import SniperBot

bot = SniperBot(
    target="new",
    buy_amount=0.5,
    min_liquidity=10,
    take_profit=[2.0, 5.0, 10.0],
    stop_loss=0.5,
    check_honeypot=True,
    check_rug=True,
)
```

### DCA Bot
Dollar-cost averaging into any Solana token.

```python
from blot_sdk import DCABot

bot = DCABot(
    token="SOL",
    amount=100,              # USDC per purchase
    frequency="daily",
    time="09:00",
    buy_only_below=150,      # Only buy if SOL < $150
)
```

### Copy Trade Bot
Mirror the trades of successful wallets.

```python
from blot_sdk import CopyTradeBot

bot = CopyTradeBot(
    wallets=["wallet1...", "wallet2..."],
    size_mode="percentage",
    size_value=10,           # 10% of their trade size
    copy_sells=True,
)
```

### Grid Bot
Profit from sideways markets with automated grid trading.

```python
from blot_sdk import GridBot

bot = GridBot(
    base_token="SOL",
    quote_token="USDC",
    lower_price=120,
    upper_price=180,
    grid_count=20,
    total_investment=100,
)
```

## Autonomy & Self-Preservation

BLOT bots operate 24/7 without downtime, automatically clone themselves across distributed nodes, and execute trades with zero human intervention:

```python
from blot_sdk import Bot

bot = Bot(private_key="...")

# Enable 24/7 autonomous operation
bot.enable_autonomy(
    mode="persistent",
    auto_restart=True,
    health_checks=True
)

# Enable self-cloning on threat detection
bot.enable_self_cloning(
    trigger="on_threat",
    target_nodes=3,
    regions=["us", "eu", "asia"]
)

# Zero-logging mode for privacy
bot.set_logging(enabled=False)

# Auto-migrate if node goes down
bot.on_node_failure(action="migrate", priority="immediate")
```

## Self-Cloning

BLOT bots automatically clone themselves across distributed nodes:

```python
from blot_sdk import SniperBot

bot = SniperBot(
    # ... config ...
    clone_count=5,                    # Minimum active clones
    regions=["us", "eu", "asia"],     # Geographic distribution
    failover_timeout=100,             # ms before electing new leader
)
```

## AI Integration

Leverage OpenClaw AI for intelligent trading decisions:

```python
from blot_sdk import Bot, AI

bot = Bot(private_key="...")

# AI-powered market analysis
analysis = await bot.ai.analyze_token("JUP")
print(analysis.sentiment)      # bullish/bearish
print(analysis.risk_score)     # 0-100
print(analysis.recommendation) # buy/sell/hold

# AI-filtered copy trading
copy_bot = CopyTradeBot(
    wallets=["..."],
    ai_filter=True,
    ai_confidence_threshold=0.7,
)
```

## Documentation

Full documentation available at [blot.cloud/docs](https://blot.cloud/docs)

## Requirements

- Python 3.9+
- Solana wallet with SOL for transaction fees
- $BLOT tokens for runtime access

## Links

- Website: [blot.cloud](https://blot.cloud)
- Documentation: [blot.cloud/docs](https://blot.cloud/docs)
- PyPI: [pypi.org/project/blot-sdk](https://pypi.org/project/blot-sdk)
- X: [@bloboratory](https://x.com/bloboratory)

## License

MIT License - see [LICENSE](LICENSE) for details.
