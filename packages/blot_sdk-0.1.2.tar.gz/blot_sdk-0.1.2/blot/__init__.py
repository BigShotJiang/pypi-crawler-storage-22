"""
BLOT SDK - Autonomous Trading Bots for Solana

Self-replicating, AI-powered trading infrastructure.
"""

__version__ = "0.1.0"
__author__ = "BLOT Team"

from blot.bot import Bot
from blot.bots.sniper import SniperBot
from blot.bots.dca import DCABot
from blot.bots.copy_trade import CopyTradeBot
from blot.bots.grid import GridBot
from blot.ai import AI
from blot.config import Config

__all__ = [
    "Bot",
    "SniperBot",
    "DCABot",
    "CopyTradeBot",
    "GridBot",
    "AI",
    "Config",
    "__version__",
]

