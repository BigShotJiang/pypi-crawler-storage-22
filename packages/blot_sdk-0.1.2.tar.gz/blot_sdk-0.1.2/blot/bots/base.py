"""Base bot class for BLOT SDK."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class BaseBot(ABC):
    """Base class for all BLOT trading bots.
    
    All bot types inherit from this class.
    
    Attributes:
        clone_count: Number of bot clones to maintain.
        regions: Geographic regions for clone distribution.
        failover_timeout: Milliseconds before electing new leader.
    """
    
    # Cloning settings
    clone_count: int = 3
    regions: List[str] = field(default_factory=lambda: ["us", "eu", "asia"])
    failover_timeout: int = 100  # ms
    sync_interval: int = 50  # ms
    
    @abstractmethod
    def validate(self) -> bool:
        """Validate bot configuration.
        
        Returns:
            True if configuration is valid.
            
        Raises:
            ValueError: If configuration is invalid.
        """
        pass
    
    def to_dict(self) -> dict:
        """Convert bot configuration to dictionary."""
        return {
            k: v for k, v in self.__dict__.items()
            if not k.startswith('_')
        }

