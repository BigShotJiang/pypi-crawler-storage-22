"""Copy Trade Bot for BLOT SDK."""

from dataclasses import dataclass, field
from typing import Optional, List, Literal

from blot.bots.base import BaseBot


@dataclass
class CopyTradeBot(BaseBot):
    """Copy Trade Bot - Mirror trades of successful wallets.
    
    The Copy Trade Bot monitors specified wallet addresses and
    automatically replicates their trades in real-time.
    
    Example:
        ```python
        from blot import CopyTradeBot
        
        bot = CopyTradeBot(
            wallets=["wallet1...", "wallet2..."],
            size_mode="percentage",
            size_value=10,       # 10% of their trade size
            copy_sells=True,
            ai_filter=True,
        )
        ```
    
    Attributes:
        wallets: List of wallet addresses to copy.
        size_mode: How to size positions ('fixed' or 'percentage').
        size_value: Position size value (SOL if fixed, percent if percentage).
        max_position: Maximum position size in SOL.
        copy_sells: Whether to also copy sell orders.
        min_trade_size: Minimum trade size to copy in SOL.
        blacklist_tokens: Token symbols to never trade.
        only_verified: Only trade verified tokens.
        ai_filter: Use AI to filter trades.
        ai_confidence_threshold: Minimum AI confidence to copy trade.
    """
    
    # Wallets to copy
    wallets: List[str] = field(default_factory=list)
    
    # Position sizing
    size_mode: Literal["fixed", "percentage"] = "percentage"
    size_value: float = 10.0  # SOL if fixed, percent if percentage
    max_position: float = 1.0  # SOL
    
    # Trade filters
    copy_sells: bool = True
    min_trade_size: float = 0.1  # SOL
    
    # Token filters
    blacklist_tokens: List[str] = field(default_factory=list)
    whitelist_tokens: Optional[List[str]] = None
    only_verified: bool = False
    
    # AI settings
    ai_filter: bool = False
    ai_confidence_threshold: float = 0.7
    
    # Execution
    delay: int = 0  # seconds delay before copying
    slippage: float = 1.0  # percent
    
    def validate(self) -> bool:
        """Validate bot configuration."""
        if not self.wallets:
            raise ValueError("At least one wallet address is required")
        if self.size_mode not in ["fixed", "percentage"]:
            raise ValueError("size_mode must be 'fixed' or 'percentage'")
        if self.size_value <= 0:
            raise ValueError("size_value must be positive")
        if self.max_position <= 0:
            raise ValueError("max_position must be positive")
        if self.slippage < 0 or self.slippage > 100:
            raise ValueError("slippage must be between 0 and 100")
        return True

