"""DCA Bot for BLOT SDK."""

from dataclasses import dataclass, field
from typing import Optional, List

from blot.bots.base import BaseBot


@dataclass
class DCABot(BaseBot):
    """DCA Bot - Dollar-cost averaging into any Solana token.
    
    The DCA Bot automatically purchases tokens on a schedule,
    reducing the impact of volatility by spreading purchases over time.
    
    Example:
        ```python
        from blot import DCABot
        
        bot = DCABot(
            token="SOL",
            amount=100,          # USDC per purchase
            frequency="daily",
            time="09:00",
            buy_only_below=150,  # Only buy if SOL < $150
        )
        ```
    
    Attributes:
        token: Token symbol or address to accumulate.
        amount: Amount in quote currency per purchase.
        frequency: Purchase frequency ('hourly', 'daily', 'weekly', or cron expression).
        time: Time of purchase in UTC (HH:MM format).
        buy_only_below: Only buy if price is below this value.
        time_variance: Random offset in minutes to avoid detection.
        max_single_order: Maximum single order size (will split if exceeded).
        order_delay: Delay between split orders in seconds.
    """
    
    # Target settings
    token: str = "SOL"
    quote_token: str = "USDC"
    
    # Purchase settings
    amount: float = 100.0  # Quote currency per purchase
    frequency: str = "daily"  # hourly, daily, weekly, or cron
    time: str = "09:00"  # UTC
    
    # Conditions
    buy_only_below: Optional[float] = None
    buy_only_above: Optional[float] = None
    
    # Anti-detection
    time_variance: int = 0  # minutes
    
    # Order splitting
    max_single_order: Optional[float] = None
    order_delay: int = 30  # seconds
    
    # Routing
    use_jupiter: bool = True
    slippage: float = 0.5  # percent
    
    def validate(self) -> bool:
        """Validate bot configuration."""
        if self.amount <= 0:
            raise ValueError("amount must be positive")
        if self.frequency not in ["hourly", "daily", "weekly"] and not self.frequency.startswith("cron:"):
            raise ValueError("frequency must be 'hourly', 'daily', 'weekly', or a cron expression")
        if self.slippage < 0 or self.slippage > 100:
            raise ValueError("slippage must be between 0 and 100")
        if self.time_variance < 0:
            raise ValueError("time_variance must be non-negative")
        return True

