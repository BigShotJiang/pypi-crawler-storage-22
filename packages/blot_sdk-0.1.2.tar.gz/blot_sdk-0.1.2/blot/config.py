"""Configuration management for BLOT SDK."""

from dataclasses import dataclass, field
from typing import Optional, List
import os


@dataclass
class Config:
    """BLOT SDK Configuration.
    
    Attributes:
        api_key: Your BLOT API key for accessing the infrastructure.
        rpc_url: Solana RPC endpoint URL.
        network: Network to use ('mainnet-beta', 'devnet', 'testnet').
        clone_count: Number of bot clones to maintain.
        regions: Geographic regions for clone distribution.
    """
    
    api_key: Optional[str] = field(default_factory=lambda: os.getenv("BLOT_API_KEY"))
    rpc_url: str = "https://api.mainnet-beta.solana.com"
    network: str = "mainnet-beta"
    clone_count: int = 3
    regions: List[str] = field(default_factory=lambda: ["us", "eu", "asia"])
    failover_timeout: int = 100  # ms
    sync_interval: int = 50  # ms
    
    # Security limits
    max_trade_size: Optional[float] = None  # SOL
    max_daily_volume: Optional[float] = None  # SOL
    max_slippage: float = 5.0  # percent
    
    def __post_init__(self):
        if self.network not in ["mainnet-beta", "devnet", "testnet"]:
            raise ValueError(f"Invalid network: {self.network}")
    
    @classmethod
    def from_env(cls) -> "Config":
        """Create config from environment variables."""
        return cls(
            api_key=os.getenv("BLOT_API_KEY"),
            rpc_url=os.getenv("BLOT_RPC_URL", "https://api.mainnet-beta.solana.com"),
            network=os.getenv("BLOT_NETWORK", "mainnet-beta"),
        )
    
    @classmethod
    def from_file(cls, path: str) -> "Config":
        """Load config from YAML file."""
        try:
            import yaml
            with open(path, 'r') as f:
                data = yaml.safe_load(f)
            return cls(**data)
        except ImportError:
            raise ImportError("PyYAML required for config file support: pip install pyyaml")

