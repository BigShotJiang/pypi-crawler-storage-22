"""BLOT Trading Strategies - Aliases for bots."""

# Re-export bots as strategies for backwards compatibility
from blot.bots.sniper import SniperBot as SniperStrategy
from blot.bots.dca import DCABot as DCAStrategy
from blot.bots.copy_trade import CopyTradeBot as CopyTradeStrategy
from blot.bots.grid import GridBot as GridStrategy

__all__ = [
    "SniperStrategy",
    "DCAStrategy",
    "CopyTradeStrategy",
    "GridStrategy",
]

