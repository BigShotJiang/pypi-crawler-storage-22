"""Tests for BLOT bots."""

import pytest
from blot import SniperBot, DCABot, CopyTradeBot, GridBot


class TestSniperBot:
    """Tests for SniperBot."""
    
    def test_default_config(self):
        """Test default configuration."""
        bot = SniperBot()
        assert bot.target == "new"
        assert bot.buy_amount == 0.5
        assert bot.check_honeypot is True
    
    def test_validate_positive_amount(self):
        """Test that buy_amount must be positive."""
        bot = SniperBot(buy_amount=0)
        with pytest.raises(ValueError, match="buy_amount must be positive"):
            bot.validate()
    
    def test_validate_valid_dex(self):
        """Test that DEX must be valid."""
        bot = SniperBot(dex="invalid")
        with pytest.raises(ValueError, match="Invalid DEX"):
            bot.validate()
    
    def test_valid_config(self):
        """Test valid configuration passes validation."""
        bot = SniperBot(
            target="new",
            buy_amount=1.0,
            take_profit=[2.0, 5.0],
            stop_loss=0.5,
        )
        assert bot.validate() is True


class TestDCABot:
    """Tests for DCABot."""
    
    def test_default_config(self):
        """Test default configuration."""
        bot = DCABot()
        assert bot.token == "SOL"
        assert bot.amount == 100.0
        assert bot.frequency == "daily"
    
    def test_validate_positive_amount(self):
        """Test that amount must be positive."""
        bot = DCABot(amount=0)
        with pytest.raises(ValueError, match="amount must be positive"):
            bot.validate()


class TestCopyTradeBot:
    """Tests for CopyTradeBot."""
    
    def test_default_config(self):
        """Test default configuration."""
        bot = CopyTradeBot(wallets=["wallet1"])
        assert bot.size_mode == "percentage"
        assert bot.copy_sells is True
    
    def test_validate_requires_wallets(self):
        """Test that at least one wallet is required."""
        bot = CopyTradeBot()
        with pytest.raises(ValueError, match="At least one wallet"):
            bot.validate()


class TestGridBot:
    """Tests for GridBot."""
    
    def test_default_config(self):
        """Test default configuration."""
        bot = GridBot()
        assert bot.base_token == "SOL"
        assert bot.mode == "arithmetic"
    
    def test_validate_price_range(self):
        """Test that lower_price must be less than upper_price."""
        bot = GridBot(lower_price=200, upper_price=100)
        with pytest.raises(ValueError, match="lower_price must be less than upper_price"):
            bot.validate()
    
    def test_grid_levels_arithmetic(self):
        """Test arithmetic grid level calculation."""
        bot = GridBot(lower_price=100, upper_price=200, grid_count=3)
        levels = bot.grid_levels
        assert len(levels) == 3
        assert levels[0] == 100
        assert levels[1] == 150
        assert levels[2] == 200

