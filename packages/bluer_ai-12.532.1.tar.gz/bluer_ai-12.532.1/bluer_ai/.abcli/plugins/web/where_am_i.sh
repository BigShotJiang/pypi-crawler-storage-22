#! /usr/bin/env bash

function bluer_ai_web_where_am_i() {
    curl ifconfig.co/json
}
