from bluer_ai import VERSION


def test_version():
    assert VERSION
