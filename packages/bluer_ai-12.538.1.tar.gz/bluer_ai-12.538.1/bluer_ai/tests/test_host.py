from bluer_ai.host import signature


def test_signature():
    assert signature()
