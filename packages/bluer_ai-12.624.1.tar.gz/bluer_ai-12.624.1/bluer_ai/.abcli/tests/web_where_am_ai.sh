#! /usr/bin/env bash

function test_bluer_ai_web_where_am_i() {
    if [[ "$BLUER_AI_WEB_IS_ACCESSIBLE" == 0 ]]; then
        bluer_ai_log_warning "web is not accessible, skipping test."
        return
    fi

    bluer_ai_web_where_am_i
}
