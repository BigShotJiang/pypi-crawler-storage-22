from blueness import module
from bluer_options.help.functions import help_main

from bluer_journal import NAME
from bluer_journal.help.functions import help_functions

NAME = module.name(__file__, NAME)


help_main(NAME, help_functions)
