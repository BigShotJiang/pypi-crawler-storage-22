from bluer_options.logger import get_logger
from bluer_journal import ICON

logger = get_logger(ICON)
