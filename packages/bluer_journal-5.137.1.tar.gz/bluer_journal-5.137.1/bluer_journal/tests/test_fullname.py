from bluer_journal import fullname


def test_fullname():
    assert fullname()
