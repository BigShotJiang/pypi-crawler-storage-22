from bluer_journal.host import signature


def test_signature():
    assert signature()
