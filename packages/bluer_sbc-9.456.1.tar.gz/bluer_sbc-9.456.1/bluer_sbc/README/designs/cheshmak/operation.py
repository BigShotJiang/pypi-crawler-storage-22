docs = [
    {
        "path": "../docs/cheshmak/operation.md",
    },
]
