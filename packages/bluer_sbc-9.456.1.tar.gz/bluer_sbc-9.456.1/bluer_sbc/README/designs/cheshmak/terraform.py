docs = [
    {
        "path": "../docs/cheshmak/terraform.md",
    }
]
