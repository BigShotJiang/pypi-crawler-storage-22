# anchor: body

- previous design(s): [v1](./v1.md), [v2](./v2.md).

|   |   |   |
| --- | --- | --- |
| [![image](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121404.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121404.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121414.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121414.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121420.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121420.jpg?raw=true) |
| [![image](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121423.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121423.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121427.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121427.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121435.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121435.jpg?raw=true) |
| [![image](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121452.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/anchor/v3/20251211_121452.jpg?raw=true) |  |  |
