title:::

- born out of `bryce`.
- previous design(s): [v1](./v1.md), [v2](./v2.md).

items:::