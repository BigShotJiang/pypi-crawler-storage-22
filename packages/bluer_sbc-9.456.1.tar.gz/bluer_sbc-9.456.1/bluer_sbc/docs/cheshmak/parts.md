# cheshmak: parts

|   |   |   |   |   |   |   |   |   |   |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| [`16 AWG wire`](../parts/16-awg-wire.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/16-awg-wire.jpeg?raw=true)](../parts/16-awg-wire.md) 20 cm x (red + black/blue) | [`AC to DC power adapter`](../parts/power-adapter.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/power-adapter.jpg?raw=true)](../parts/power-adapter.md) 12 V DC, 5 A | [`DC power plug, 5.5 mm`](../parts/dc-power-plug.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/charging-port.jpg?raw=true)](../parts/dc-power-plug.md)  | [`Raspberry Pi.`](../parts/rpi.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/rpi3bplus.png?raw=true)](../parts/rpi.md)  | [`XL4015: 8 - 36 VDC -> 1.25 - 32 VDC, 5A`](../parts/XL4015.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/XL4015.png?raw=true)](../parts/XL4015.md)  | [`gen1-s blue bracket`](../parts/gen1-s-blue-bracket.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/gen1-s.png?raw=true)](../parts/gen1-s-blue-bracket.md)  | [`hdmi cable`](../parts/hdmi-cable.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/hdmi-cable.jpg?raw=true)](../parts/hdmi-cable.md)  | [`keyboard`](../parts/keyboard.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/keyboard.jpg?raw=true)](../parts/keyboard.md)  | [`micro hdmi adapter`](../parts/micro-hdmi-adapter.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/micro-hdmi-adapter.jpg?raw=true)](../parts/micro-hdmi-adapter.md)  | [`nuts, bolts, and spacers`](../parts/nuts-bolts-spacers.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/nuts-bolts-spacers.jpg?raw=true)](../parts/nuts-bolts-spacers.md) M2.5: (4 x bolt + 4 x nut + 12 x 10 mm spacer), M3: (4 x bolt + 5 x nut + 4 x 15 mm spacer + 5 x 25 mm spacer) |
| [`on/off DC switch with indicator led`](../parts/dc-switch.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/on-off-switch.png?raw=true)](../parts/dc-switch.md)  | [`plexiglass, 2 mm or 2.5 mm thickness`](../parts/plexiglass.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/plexiglass.jpg?raw=true)](../parts/plexiglass.md) 14 cm x 9.5 cm | [`single-sided PCB, 14 cm x 9.5 cm`](../parts/PCB-single-14x9_5.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/pcb-14x9_5cm.jpg?raw=true)](../parts/PCB-single-14x9_5.md)  | [`the swallow shield`](../parts/swallow-shield.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/swallow-3d.png?raw=true)](../parts/swallow-shield.md)  |  |  |  |  |  |  |

1. [16 AWG wire](../parts/16-awg-wire.md): 20 cm x (red + black/blue).
1. [AC to DC power adapter](../parts/power-adapter.md): 12 V DC, 5 A.
1. [DC power plug, 5.5 mm](../parts/dc-power-plug.md).
1. [Raspberry Pi.](../parts/rpi.md).
1. [XL4015: 8 - 36 VDC -> 1.25 - 32 VDC, 5A](../parts/XL4015.md).
1. [gen1-s blue bracket](../parts/gen1-s-blue-bracket.md).
1. [hdmi cable](../parts/hdmi-cable.md).
1. [keyboard](../parts/keyboard.md).
1. [micro hdmi adapter](../parts/micro-hdmi-adapter.md).
1. [nuts, bolts, and spacers](../parts/nuts-bolts-spacers.md): M2.5: (4 x bolt + 4 x nut + 12 x 10 mm spacer), M3: (4 x bolt + 5 x nut + 4 x 15 mm spacer + 5 x 25 mm spacer).
1. [on/off DC switch with indicator led](../parts/dc-switch.md).
1. [plexiglass, 2 mm or 2.5 mm thickness](../parts/plexiglass.md): 14 cm x 9.5 cm.
1. [single-sided PCB, 14 cm x 9.5 cm](../parts/PCB-single-14x9_5.md).
1. [the swallow shield](../parts/swallow-shield.md).
