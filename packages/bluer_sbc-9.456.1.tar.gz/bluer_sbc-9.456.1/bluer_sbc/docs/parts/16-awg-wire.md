# parts: 16-awg-wire

- 16 AWG wire

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/16-awg-wire.jpeg?raw=true) |
