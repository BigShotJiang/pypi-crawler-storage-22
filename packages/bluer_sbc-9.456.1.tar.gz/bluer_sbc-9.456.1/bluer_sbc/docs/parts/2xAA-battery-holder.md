# parts: 2xAA-battery-holder

- 2 x AA battery holder

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/2xAA-battery-holder.jpg?raw=true) |
