# parts: 5v-unmanaged-10-100-switch

- 5V unmanaged 10/100 switch

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/5v-unmanaged-10-100-switch.jpg?raw=true) |
