# parts: LJ-6V-battery

- 6V DC (4 cell) NICD battery
- https://www.digikala.com/product/dkp-3213588/%C3%98/

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/LJ-6V-battery.jpg?raw=true) |
