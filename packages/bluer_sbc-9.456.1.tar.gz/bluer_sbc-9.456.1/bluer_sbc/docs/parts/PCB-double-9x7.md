# parts: PCB-double-9x7

- double-sided PCB, 9 cm x 7 cm

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/PCB-double-9x7.jpeg?raw=true) |
