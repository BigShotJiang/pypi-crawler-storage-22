# parts: ceramic-terminal

- ceramic terminal

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/ceramic-terminal.jpg?raw=true) |
