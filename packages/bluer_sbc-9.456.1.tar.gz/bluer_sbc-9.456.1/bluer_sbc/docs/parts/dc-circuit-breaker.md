# parts: dc-circuit-breaker

- DC circuit breaker

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/mcb-3.jpg?raw=true) |
