# parts: dc-motor-12-VDC-45W

- 12 VDC motor, 20-45 W
- type 1: 9,000 RPM, output ~60 RPM
- type 2: 10,000 RPM, output 72 RPM
- https://parsbike.com/product/%D9%85%D9%88%D8%AA%D9%88%D8%B1-%DA%AF%DB%8C%D8%B1%D8%A8%DA%A9%D8%B3-%D9%85%D8%A7%D8%B4%DB%8C%D9%86-%D8%B4%D8%A7%D8%B1%DA%98%DB%8C-%D9%88-%D9%85%D9%88%D8%AA%D9%88%D8%B1-%D8%B4%D8%A7%D8%B1%DA%98%DB%8C/

|   |   |   |
| --- | --- | --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/gearbox1.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/gearbox2.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/gearbox3.jpg?raw=true) |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/gearbox4.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/gearbox5.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/gearbox6.jpg?raw=true) |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/gearbox7.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/gearbox8.jpg?raw=true) |  |
