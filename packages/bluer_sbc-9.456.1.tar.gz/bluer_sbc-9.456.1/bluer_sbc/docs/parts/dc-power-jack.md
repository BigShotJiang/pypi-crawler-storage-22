# parts: dc-power-jack

- DC power jack, 5.5 mm

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/charger-socket.jpg?raw=true) |
