# parts: dfplayer-mini

- DFPlayer Mini, audio file player
- eg: https://www.digikala.com/product/dkp-2077160/%D9%85%D8%A7%DA%98%D9%88%D9%84-%D9%BE%D8%AE%D8%B4-%D9%81%D8%A7%DB%8C%D9%84-%D9%87%D8%A7%DB%8C-%D8%B5%D9%88%D8%AA%DB%8C-%D9%85%D8%AF%D9%84-dfplayer/

|   |   |   |
| --- | --- | --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dFPlayer-mini-1.png?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dFPlayer-mini-2.png?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dFPlayer-mini-3.png?raw=true) |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dFPlayer-mini-4.png?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dFPlayer-mini-5.png?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dFPlayer-mini-6.png?raw=true) |
