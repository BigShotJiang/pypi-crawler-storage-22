# parts: dsn-vc288

- DSN-VC288, panel mount, 4-30 VDC, 10A (50A with shunt resistor), voltmeter ammeter
- https://hamguyparts.com/files/Download/Chinese%20DVA.pdf
- https://www.skytech.ir/DownLoad/File/11515_DSN-VC288.pdf
- https://soldered.com/learn/hum-built-in-voltmeter-ammeter-100v-10a/

|   |   |   |
| --- | --- | --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dsn-vc288.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dsn-vc288-connection.jpg?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dsn-vc288-measurements.jpeg?raw=true) |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/dsn-vc288-shunt.png?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/shunt.png?raw=true) |  |
