# parts: front-wheels

- front wheels

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/front-wheels.jpg?raw=true) |
