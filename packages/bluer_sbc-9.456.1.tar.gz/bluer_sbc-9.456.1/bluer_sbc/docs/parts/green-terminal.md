# parts: green-terminal

- green terminal

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/green-terminal.jpg?raw=true) |
