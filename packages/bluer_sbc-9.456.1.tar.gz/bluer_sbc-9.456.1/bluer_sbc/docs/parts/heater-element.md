# parts: heater-element

- heater element

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/heater-element.jpg?raw=true) |
