# parts: li-ion-charger

- Li-Ion battery charger, 12.6 VDC, 1 A

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/power-adapter.jpg?raw=true) |
