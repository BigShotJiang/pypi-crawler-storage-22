# parts: micro-hdmi-adapter

- micro hdmi adapter

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/micro-hdmi-adapter.jpg?raw=true) |
