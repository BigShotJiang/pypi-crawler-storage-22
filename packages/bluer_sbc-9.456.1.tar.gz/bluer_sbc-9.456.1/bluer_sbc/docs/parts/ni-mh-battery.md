# parts: ni-mh-battery

- Ni-MH AA, 2400 mAh, 1.2 VDC

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/ni-mh-battery.jpg?raw=true) |
