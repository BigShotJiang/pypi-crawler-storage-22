# parts: numpad

- numpad

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/numpad.jpg?raw=true) |
