# parts: plexiglass

- plexiglass, 2 mm or 2.5 mm thickness

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/plexiglass.jpg?raw=true) |
