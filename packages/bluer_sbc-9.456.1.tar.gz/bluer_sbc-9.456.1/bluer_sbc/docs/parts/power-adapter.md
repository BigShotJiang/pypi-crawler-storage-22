# parts: power-adapter

- AC to DC power adapter

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/power-adapter.jpg?raw=true) |
