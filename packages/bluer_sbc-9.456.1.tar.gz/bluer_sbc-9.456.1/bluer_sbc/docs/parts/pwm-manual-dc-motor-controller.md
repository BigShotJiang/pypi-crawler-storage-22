# parts: pwm-manual-dc-motor-controller

- pwm manual DC motor controller, 12 V, ≥ 5 A

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/pwm-manual-dc-motor-controller.jpg?raw=true) |
