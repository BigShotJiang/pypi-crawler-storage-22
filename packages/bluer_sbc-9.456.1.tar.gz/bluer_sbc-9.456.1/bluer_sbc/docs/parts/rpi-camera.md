# parts: rpi-camera

- Raspberry Pi Camera, V1.3
- https://www.raspberrypi.com/documentation/accessories/camera.html
- https://shop.sb-components.co.uk/products/raspberry-pi-camera

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/rpi-camera.jpg?raw=true) |
