# parts: rpi3bp

- Raspberry Pi 3B+

|   |   |
| --- | --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/rpi3bplus.png?raw=true) | ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/gpio-pinout.png?raw=true) |
