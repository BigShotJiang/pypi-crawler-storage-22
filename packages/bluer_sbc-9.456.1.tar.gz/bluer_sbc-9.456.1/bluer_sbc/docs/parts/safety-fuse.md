# parts: safety-fuse

- safety fuse
- residual current device (RCD / GFCI)

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/safety-fuse.jpg?raw=true) |
