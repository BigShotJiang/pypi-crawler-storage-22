# parts: ultrasonic-sensor

- HC-SR04: ultrasonic-sensor
- [datasheet](https://cdn.sparkfun.com/datasheets/Sensors/Proximity/HCSR04.pdf)
- 1m ~= 6ms
- fov = 15 - 30 deg

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/HC-SR04.jpg?raw=true) |
