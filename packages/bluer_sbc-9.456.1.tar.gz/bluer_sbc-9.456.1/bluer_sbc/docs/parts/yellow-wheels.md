# parts: yellow-wheels

- wheels for gearboxed DC motor

|   |
| --- |
| ![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/yellow-wheels.jpg?raw=true) |
