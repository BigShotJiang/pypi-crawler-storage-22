title:::

> a regulated, 1.25 - 32 VDC, 5A, bus based on [XL4015](./parts/XL4015.md)

items:::

## parts

parts_images:::

parts_list:::