# swallow: body

- previous design(s): [v1](./v1.md), [v2](./v2.md), [v3](./v3.md), [v4](./v4.md), [v5](./v5.md).

|   |   |   |
| --- | --- | --- |
| [![image](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/01.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/01.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/02.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/02.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/03.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/03.jpg?raw=true) |
| [![image](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/04.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/04.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/05.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/05.jpg?raw=true) | [![image](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/06.jpg?raw=true)](https://github.com/kamangir/assets2/blob/main/swallow/design/v6/06.jpg?raw=true) |
