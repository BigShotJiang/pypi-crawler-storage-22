# swallow: parts

[swallow-head](../swallow-head) + ⬇️

|   |   |   |   |   |   |
| --- | --- | --- | --- | --- | --- |
| [`43 A, H-Bridge Motor Driver`](../parts/BTS7960.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/bts7960.jpg?raw=true)](../parts/BTS7960.md) 2 x | [`auto power connectors`](../parts/connector.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/connector.jpg?raw=true)](../parts/connector.md) 3 females | [`nuts, bolts, and spacers`](../parts/nuts-bolts-spacers.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/nuts-bolts-spacers.jpg?raw=true)](../parts/nuts-bolts-spacers.md) M3: (4 x nut + 8 x 25 mm spacer + 4 x 30 mm spacer) | [`single-sided PCB, 14 cm x 9.5 cm`](../parts/PCB-single-14x9_5.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/pcb-14x9_5cm.jpg?raw=true)](../parts/PCB-single-14x9_5.md)  | [`solid cable 1-1.5 mm^2`](../parts/solid-cable-1-15.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/solid-cable-1-15.jpg?raw=true)](../parts/solid-cable-1-15.md) 20 cm x (red + black/blue) | [`white terminal`](../parts/white-terminal.md) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sbc/parts/white-terminal.jpg?raw=true)](../parts/white-terminal.md) 8 x |

1. [43 A, H-Bridge Motor Driver](../parts/BTS7960.md): 2 x.
1. [auto power connectors](../parts/connector.md): 3 females.
1. [nuts, bolts, and spacers](../parts/nuts-bolts-spacers.md): M3: (4 x nut + 8 x 25 mm spacer + 4 x 30 mm spacer).
1. [single-sided PCB, 14 cm x 9.5 cm](../parts/PCB-single-14x9_5.md).
1. [solid cable 1-1.5 mm^2](../parts/solid-cable-1-15.md): 20 cm x (red + black/blue).
1. [white terminal](../parts/white-terminal.md): 8 x.
