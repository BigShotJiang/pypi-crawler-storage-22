from bluer_ugv.README.ugvs.comparison.features.classes import Feature


class UVDeliveryFeature(Feature):
    nickname = "uv_delivery"
    long_name = "حمل پهپاد و رهپاد"

    comparison_as_str = {}
