#! /usr/bin/env bash

alias @rangin=bluer_ugv_rangin

alias @swallow=bluer_ugv_swallow

alias @ugv=bluer_ugv
