docs = [
    {
        "path": f"../docs/aliases/{alias}",
    }
    for alias in [
        "",
        "swallow.md",
        "ugv.md",
    ]
]
