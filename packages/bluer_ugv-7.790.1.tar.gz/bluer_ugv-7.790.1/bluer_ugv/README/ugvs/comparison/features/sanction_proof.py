from bluer_ugv.README.ugvs.comparison.features.classes import Feature


class SanctionProofFeature(Feature):
    nickname = "sanction_proof"
    long_name = "تحریم گریزی"

    comparison_as_str = {}
