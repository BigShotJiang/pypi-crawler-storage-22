from bluer_ugv.README.rangin.items import items

docs = [
    {
        "items": items,
        "path": "../docs/rangin",
    },
]
