docs = [
    {
        "path": "../docs/rangin/terraform.md",
    },
]
