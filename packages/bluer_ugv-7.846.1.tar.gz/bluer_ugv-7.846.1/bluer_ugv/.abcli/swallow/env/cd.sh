#! /usr/bin/env bash

function bluer_ugv_swallow_env_cd() {
    cd $abcli_path_assets/env/
}
