docs = [
    {
        "path": "../docs/rangin/operation.md",
    },
]
