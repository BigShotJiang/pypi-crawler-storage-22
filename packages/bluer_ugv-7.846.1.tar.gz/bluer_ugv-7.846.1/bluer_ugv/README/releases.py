docs = [
    {
        "path": "../docs/releases",
    },
    {
        "path": "../docs/releases/one.md",
    },
    {
        "path": "../docs/releases/two.md",
    },
]
