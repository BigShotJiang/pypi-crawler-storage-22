docs = [
    {
        "path": "../docs/swallow/digital/design/ethernet.md",
    },
]
