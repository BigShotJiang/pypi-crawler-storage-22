from blues_lib.ability.atom.webdriver.DriverAbility import DriverAbility

class WindowBase(DriverAbility):
  """
  Working with windows and tabs
  Reference : https://www.selenium.dev/documentation/webdriver/interactions/windows/
  """
  
  pass
