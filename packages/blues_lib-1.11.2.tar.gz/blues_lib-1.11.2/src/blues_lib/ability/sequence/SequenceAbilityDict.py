from selenium.webdriver.remote.webdriver import WebDriver

# element 
from blues_lib.ability.sequence.AbilitySequence import AbilitySequence
from blues_lib.ability.sequence.loop.AbilityOrder import AbilityOrder
from blues_lib.ability.sequence.loop.AbilityPage import AbilityPage
from blues_lib.ability.sequence.loop.AbilityFor import AbilityFor


class SequenceAbilityDict():

  @classmethod
  def get(cls,driver:WebDriver)->dict:
    return {
      AbilityOrder.__name__:AbilityOrder(driver),
      AbilitySequence.__name__:AbilitySequence(driver),
      AbilityPage.__name__:AbilityPage(driver),
      AbilityFor.__name__:AbilityFor(driver),
    }