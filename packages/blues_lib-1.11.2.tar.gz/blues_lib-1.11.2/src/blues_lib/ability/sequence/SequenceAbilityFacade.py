from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.ability.sequence.SequenceAbilityDict import SequenceAbilityDict
from blues_lib.dp.facade.DynamicFacade import DynamicFacade

class SequenceAbilityProxy(DynamicFacade):

  def __init__(self,driver:WebDriver) -> None:
    self._class_instances = SequenceAbilityDict.get(driver)
    super().__init__()