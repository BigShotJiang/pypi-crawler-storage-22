from typing import Callable
from selenium.webdriver.chrome.webdriver import WebDriver
from blues_lib.types.common import AbilityOpts,SeqOpts,SeqHookOpts
from blues_lib.ability.atom.webdriver.interaction.Frame import Frame
from blues_lib.util.BluesDateTime import BluesDateTime

class SequenceHook:

  def __init__(self,driver:WebDriver,options:SeqOpts):
    self._driver = driver
    self._options = options
    self.frame = Frame(driver)
    
  def before_cast(self):
    '''
    do something before exec
    Args:
      options (SeqOpts): the sequence options
    '''
    before_opts:SeqHookOpts = self._options.get('before')
    if not before_opts:
      return

    self._exec_for_delay('before',before_opts)
    self._exec_for_frame('before')
    self._exec_for_callback('before',before_opts)
  
  def after_cast(self,results:list|dict|None):
    after_opts:SeqHookOpts = self._options.get('after')
    if not after_opts:
      return

    self._exec_for_delay('after',after_opts)
    self._exec_for_frame('after')
    self._exec_for_callback('after',after_opts,results)
  
  def _exec_for_callback(self,when:str,hook_opts:SeqHookOpts,results:list|dict|None=None):
    callback:Callable|None = hook_opts.get('callback')
    if not callback:
      return
    print(f'call {when} callback {callback.__name__}')

  def _exec_for_frame(self,when:str):
    frame_opts:AbilityOpts|None = self._options.get('frame')
    if not frame_opts or not isinstance(frame_opts,dict):
      return

    if when == 'before':
      self.frame.switch_to_frame(frame_opts)
    elif when == 'after':
      self.frame.switch_to_default_content()
  
  def _exec_for_delay(self,when:str,hook_opts:SeqHookOpts):
    delay:int|float = float(hook_opts.get('delay') or 0)
    if delay > 0:
      BluesDateTime.count_down({
        'duration':delay,
        'title':f'wait {when} cast'
      })
