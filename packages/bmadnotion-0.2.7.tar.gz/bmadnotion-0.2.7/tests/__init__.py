"""bmadnotion tests."""
