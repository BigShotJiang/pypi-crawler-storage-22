def main():
    print("Hello from bmi-driver-py!")


if __name__ == "__main__":
    main()
