# Stage 01: Bump minor version
. "$PSScriptRoot\_bump_lib.ps1"; Initialize-Bump; Invoke-Bump -BumpType minor -ScriptDir $PSScriptRoot
