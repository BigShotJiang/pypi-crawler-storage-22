from typing import Tuple, List

# value, min, max, [warnings]
ComputedImpacts = Tuple[float, float, float, List[str]]
