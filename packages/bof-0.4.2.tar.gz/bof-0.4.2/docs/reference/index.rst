=========
Reference
=========


Fuzz
--------

.. include:: fuzz.rst

.. automodule:: bof.fuzz
    :members:


Feature Extraction
-------------------

.. include:: feature_extraction.rst

.. automodule:: bof.feature_extraction
    :members:



Common
--------------------
The `common` module contains miscellaneous classes and functions.

.. automodule:: bof.common
    :members:
