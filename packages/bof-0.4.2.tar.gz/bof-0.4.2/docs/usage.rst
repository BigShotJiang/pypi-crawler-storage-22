=====
Usage
=====

To use Bag of Factors in a project::

    import bof

Look at examples from the reference_ section to see how to use it.

.. _reference: https://balouf.github.io/bof/reference/index.html
