"""High-level async BOJ statistics client.

This is the primary public interface of boj-mcp. All BOJ operations —
dataset listing, downloading, and parsing — flow through :class:`BojClient`.

Example::

    import asyncio
    from boj_mcp import BojClient

    async def main():
        async with BojClient() as client:
            datasets = await client.list_datasets()
            df = await client.get_dataset("cgpi_m_en")
            print(df.head())

    asyncio.run(main())
"""

from __future__ import annotations

import io
import re
import zipfile
from pathlib import Path

import httpx
import polars as pl
from loguru import logger

from boj_mcp.models import DataFrameInfo, Dataset

# BOJ statistics base URL
_BASE_URL = "https://www.stat-search.boj.or.jp/info/"
_DOWNLOAD_PAGE = f"{_BASE_URL}dload_en.html"

# Default cache directory
_DEFAULT_CACHE_DIR = Path.home() / ".cache" / "boj-mcp"

# HTTP timeout
_DEFAULT_TIMEOUT = 60.0

# Security limits
_MAX_ZIP_SIZE = 200 * 1024 * 1024  # 200 MB decompressed limit

# Valid dataset name pattern (alphanumeric, hyphens, underscores only)
_VALID_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]+$")


class BojClient:
    """Async client for BOJ statistics flat files.

    Provides methods to list available datasets, download ZIP files,
    and parse CSV data into Polars DataFrames.

    Args:
        cache_dir: Directory for caching downloaded files.
        timeout: HTTP request timeout in seconds.
    """

    def __init__(
        self,
        cache_dir: Path | str | None = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        self._timeout = timeout
        self._cache_dir = Path(cache_dir) if cache_dir else _DEFAULT_CACHE_DIR
        self._cache_dir.mkdir(parents=True, exist_ok=True, mode=0o700)

        self._http = httpx.AsyncClient(
            timeout=self._timeout,
            headers={"Accept": "text/html,application/zip,*/*"},
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()

    async def __aenter__(self) -> BojClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    async def list_datasets(self) -> list[Dataset]:
        """List available flat file datasets from BOJ.

        Scrapes the download page to find ZIP file links.

        Returns:
            List of :class:`Dataset` objects.
        """
        logger.info("Fetching dataset list from BOJ...")
        resp = await self._http.get(_DOWNLOAD_PAGE)
        resp.raise_for_status()

        html = resp.text
        datasets: list[Dataset] = []

        # Find all ZIP file links
        # Pattern: <a href="filename.zip">Description</a>
        pattern = r'<a\s+href="([^"]+\.zip)"[^>]*>([^<]+)</a>'
        matches = re.findall(pattern, html, re.IGNORECASE)

        for href, desc in matches:
            name = href.replace(".zip", "").split("/")[-1]
            url = href if href.startswith("http") else f"{_BASE_URL}{href}"

            # Categorize based on filename
            category = _categorize_dataset(name)

            datasets.append(
                Dataset(
                    name=name,
                    url=url,
                    description=desc.strip(),
                    category=category,
                )
            )

        logger.info(f"Found {len(datasets)} datasets")
        return datasets

    async def get_dataset(
        self,
        name: str,
        *,
        force_download: bool = False,
    ) -> pl.DataFrame:
        """Download and parse a dataset.

        Downloads the ZIP file, extracts CSV, and parses it into a
        Polars DataFrame. Uses cache unless force_download is True.

        Args:
            name: Dataset name (e.g., "cgpi_m_en").
            force_download: If True, re-download even if cached.

        Returns:
            Polars DataFrame with the dataset contents.

        Raises:
            ValueError: If the dataset is not found.
        """
        # Validate dataset name to prevent path traversal
        if not _VALID_NAME_RE.match(name):
            raise ValueError(f"Invalid dataset name: {name!r}")

        cache_path = self._cache_dir / f"{name}.zip"

        if not force_download and cache_path.exists():
            logger.debug(f"Using cached file: {cache_path}")
            zip_data = cache_path.read_bytes()
        else:
            # Download
            url = f"{_BASE_URL}{name}.zip"
            logger.info(f"Downloading {name} from {url}...")
            resp = await self._http.get(url)
            resp.raise_for_status()
            zip_data = resp.content

            # Save to cache with restricted permissions
            cache_path.write_bytes(zip_data)
            cache_path.chmod(0o600)
            logger.info(f"Cached to {cache_path}")

        # Parse ZIP
        return self._parse_zip(zip_data, name)

    def _parse_zip(self, zip_data: bytes, name: str) -> pl.DataFrame:
        """Parse ZIP file contents into DataFrame.

        Security: validates entry names (ZIP Slip) and limits decompressed
        size (ZIP Bomb).
        """
        with zipfile.ZipFile(io.BytesIO(zip_data)) as zf:
            # Find CSV file (usually named like "data.csv" or similar)
            csv_files: list[str] = []
            for entry in zf.infolist():
                # ZIP Slip: reject entries with path traversal
                if entry.filename.startswith("/") or ".." in entry.filename:
                    raise ValueError(f"Unsafe ZIP entry: {entry.filename}")
                # ZIP Bomb: reject entries with excessive decompressed size
                if entry.file_size > _MAX_ZIP_SIZE:
                    raise ValueError(
                        f"ZIP entry too large ({entry.file_size} bytes): {entry.filename}"
                    )
                if entry.filename.endswith(".csv"):
                    csv_files.append(entry.filename)

            if not csv_files:
                raise ValueError(f"No CSV file found in {name}.zip")

            # Use the first CSV file
            csv_name = csv_files[0]
            logger.debug(f"Reading {csv_name} from ZIP...")

            with zf.open(csv_name) as f:
                # Read with Shift_JIS encoding (important!)
                csv_bytes = f.read()
                csv_text = csv_bytes.decode("shift_jis", errors="replace")

                # Parse CSV
                df = pl.read_csv(io.StringIO(csv_text))

                logger.info(f"Loaded {name}: {df.shape[0]} rows x {df.shape[1]} cols")
                return df

    def get_dataframe_info(self, df: pl.DataFrame, name: str) -> DataFrameInfo:
        """Get metadata about a loaded DataFrame."""
        return DataFrameInfo(
            dataset_name=name,
            shape=df.shape,
            columns=df.columns,
        )


def _categorize_dataset(name: str) -> str:
    """Categorize dataset based on filename prefix/keyword."""
    name_lower = name.lower()
    # Use prefix or word-boundary matching to avoid false positives
    # (e.g. 'co' should not match 'fof_consolidated')
    prefix = name_lower.split("_")[0] if "_" in name_lower else name_lower

    if "cgpi" in name_lower or "sppi" in name_lower:
        return "Prices"
    elif prefix == "co":
        return "Surveys"
    elif "fof" in name_lower:
        return "Flow of Funds"
    elif prefix == "bp" or name_lower.startswith("bp"):
        return "Balance of Payments"
    elif "iip" in name_lower:
        return "International Investment"
    elif "bis" in name_lower:
        return "BIS Statistics"
    elif prefix == "mm" or "money" in name_lower:
        return "Money Stock"
    elif prefix == "ir" or "interest" in name_lower:
        return "Interest Rates"
    elif prefix == "fx" or "exchange" in name_lower:
        return "Foreign Exchange"
    else:
        return "Other"
