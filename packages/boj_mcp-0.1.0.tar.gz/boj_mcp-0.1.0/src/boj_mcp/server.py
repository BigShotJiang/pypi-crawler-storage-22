"""MCP server exposing BOJ statistics tools to LLMs via FastMCP.

This module defines the MCP (Model Context Protocol) server that allows
AI assistants like Claude to search and retrieve Bank of Japan statistics.

Usage with Claude Desktop (add to ``claude_desktop_config.json``)::

    {
      "mcpServers": {
        "boj": {
          "command": "uvx",
          "args": ["boj-mcp", "serve"]
        }
      }
    }
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Annotated, Any

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

from fastmcp import FastMCP
from pydantic import Field

from boj_mcp.client import BojClient

# Lazily initialized client with lock for concurrent-safe access
_client: BojClient | None = None
_client_lock = asyncio.Lock()


async def _get_client() -> BojClient:
    """Return the shared BojClient, creating it on first call."""
    global _client
    if _client is not None:
        return _client
    async with _client_lock:
        if _client is None:
            _client = BojClient()
    return _client


@asynccontextmanager
async def _lifespan(server: FastMCP[dict[str, Any]]) -> AsyncIterator[dict[str, Any]]:
    """Manage BojClient lifecycle."""
    global _client
    yield {}
    if _client is not None:
        await _client.close()
        _client = None


mcp = FastMCP(
    name="BOJ",
    lifespan=_lifespan,
    instructions=(
        "BOJ MCP server provides tools for accessing Bank of Japan statistics.\n\n"
        "You can list available datasets (CGPI, SPPI, TANKAN, Flow of Funds, etc.), "
        "download and analyze statistical data.\n\n"
        "Key tools:\n"
        "- list_datasets: Show available flat file datasets\n"
        "- get_dataset: Download and parse a specific dataset\n"
        "- search_series: Search for time series by keyword\n"
        "- get_series_data: Get data for a specific series\n\n"
        "All data comes from the Bank of Japan's official statistics portal."
    ),
)


@mcp.tool()
async def list_datasets() -> list[dict[str, Any]]:
    """List available BOJ flat file datasets.

    Returns all downloadable datasets including:
    - CGPI (Corporate Goods Price Index)
    - SPPI (Services Producer Price Index)
    - TANKAN (Short-term Economic Survey)
    - Flow of Funds
    - Balance of Payments
    - BIS Statistics
    """
    client = await _get_client()
    datasets = await client.list_datasets()
    return [
        {
            "name": d.name,
            "description": d.description,
            "category": d.category,
            "url": d.url,
        }
        for d in datasets
    ]


@mcp.tool()
async def get_dataset(
    name: Annotated[
        str,
        Field(description="Dataset name (e.g., 'cgpi_m_en', 'sppi_m_en', 'co')"),
    ],
) -> dict[str, Any]:
    """Download and parse a BOJ dataset.

    Downloads the ZIP file, extracts the CSV, and returns a preview
    of the data along with column information.

    Example: get_dataset("cgpi_m_en") → Corporate Goods Price Index
    """
    client = await _get_client()
    df = await client.get_dataset(name)

    # Get basic info
    info = client.get_dataframe_info(df, name)

    # Return preview (first 20 rows) and metadata
    return {
        "dataset_name": name,
        "shape": info.shape,
        "columns": info.columns,
        "preview": df.head(20).to_dicts(),
        "note": "Use get_series_data or download via CLI for full dataset",
    }


@mcp.tool()
async def search_series(
    keyword: Annotated[
        str,
        Field(description="Search keyword (English or Japanese). Example: 'CGPI' or '企業物価'"),
    ],
    dataset: Annotated[
        str | None,
        Field(description="Optional: Limit search to specific dataset (e.g., 'cgpi_m_en')"),
    ] = None,
) -> list[dict[str, Any]]:
    """Search for time series by keyword.

    Searches series descriptions in BOJ datasets.
    Returns matching series codes and descriptions.

    Example: search_series("electricity") → series related to electricity prices
    """
    client = await _get_client()

    # If dataset specified, search only that one
    if dataset:
        df = await client.get_dataset(dataset)
        # Search in description columns (typically contains series info)
        results = _search_in_dataframe(df, keyword, dataset)
        return results[:20]  # Limit results

    # Otherwise, list datasets and suggest searching specific ones
    datasets = await client.list_datasets()

    # Filter datasets that might contain the keyword
    matching_datasets = [
        d
        for d in datasets
        if keyword.lower() in d.name.lower()
        or keyword.lower() in d.description.lower()
        or keyword.lower() in d.category.lower()
    ]

    return [
        {
            "type": "dataset_suggestion",
            "name": d.name,
            "description": d.description,
            "category": d.category,
            "suggestion": f"Try: get_dataset('{d.name}') then search within",
        }
        for d in matching_datasets[:10]
    ]


@mcp.tool()
async def get_series_data(
    series_code: Annotated[
        str,
        Field(description="Series code (e.g., '0000' for CGPI total)"),
    ],
    dataset: Annotated[
        str,
        Field(description="Dataset name (e.g., 'cgpi_m_en')"),
    ],
    start_date: Annotated[
        str | None,
        Field(description="Start date in YYYY-MM format (optional)"),
    ] = None,
    end_date: Annotated[
        str | None,
        Field(description="End date in YYYY-MM format (optional)"),
    ] = None,
) -> dict[str, Any]:
    """Get time series data for a specific series.

    Extracts data for a single series from a dataset, optionally
    filtered by date range.

    Example: get_series_data("0000", "cgpi_m_en", "2020-01", "2024-12")
    """
    client = await _get_client()
    df = await client.get_dataset(dataset)

    # Try to find the series in the dataframe
    # BOJ CSVs typically have a 'code' or similar column
    results = _extract_series_from_df(df, series_code, start_date, end_date)

    return {
        "series_code": series_code,
        "dataset": dataset,
        "data": results[:100],  # Limit output
        "count": len(results),
    }


def _search_in_dataframe(
    df: Any,
    keyword: str,
    dataset: str,
) -> list[dict[str, Any]]:
    """Search for keyword in dataframe columns."""
    import polars as pl

    keyword_lower = keyword.lower()
    results: list[dict[str, Any]] = []

    # Look for description/name columns
    text_columns = [
        c
        for c in df.columns
        if any(x in c.lower() for x in ["desc", "name", "item", "series", "品目", "名称"])
    ]

    for col in text_columns:
        try:
            # Filter rows containing keyword
            mask = df[col].cast(pl.Utf8).str.to_lowercase().str.contains(keyword_lower)
            matched = df.filter(mask)

            for row in matched.head(20).to_dicts():
                if row not in results:
                    results.append(
                        {
                            "dataset": dataset,
                            "column": col,
                            **row,
                        }
                    )
        except Exception:
            continue

    return results


def _extract_series_from_df(
    df: Any,
    series_code: str,
    start_date: str | None,
    end_date: str | None,
) -> list[dict[str, Any]]:
    """Extract series data from dataframe."""
    import polars as pl

    # Try to find code column
    code_columns = [
        c for c in df.columns if any(x in c.lower() for x in ["code", "コード", "品目コード"])
    ]

    if not code_columns:
        # If no code column, return first few rows as sample
        return df.head(10).to_dicts()

    code_col = code_columns[0]

    try:
        # Filter by series code
        # BOJ codes might be numeric, so try both string and int matching
        mask = df[code_col].cast(pl.Utf8) == str(series_code)
        filtered = df.filter(mask)

        if len(filtered) == 0:
            return []

        # Convert to long format if needed
        results = filtered.to_dicts()

        return results
    except Exception:
        return []
