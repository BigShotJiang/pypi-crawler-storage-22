"""Tests for boj_mcp.cli."""

from __future__ import annotations

from click.testing import CliRunner

from boj_mcp.cli import cli


class TestDatasetsCommand:
    """Tests for datasets command."""

    def test_datasets_help(self) -> None:
        """Test datasets command help message."""
        runner = CliRunner()
        result = runner.invoke(cli, ["datasets", "--help"])
        assert result.exit_code == 0
        assert "datasets" in result.output.lower()


class TestDataCommand:
    """Tests for data command."""

    def test_data_help(self) -> None:
        """Test data command help message."""
        runner = CliRunner()
        result = runner.invoke(cli, ["data", "--help"])
        assert result.exit_code == 0
        assert "data" in result.output
        assert "--format" in result.output
        assert "--rows" in result.output


class TestSearchCommand:
    """Tests for search command."""

    def test_search_help(self) -> None:
        """Test search command help message."""
        runner = CliRunner()
        result = runner.invoke(cli, ["search", "--help"])
        assert result.exit_code == 0
        assert "search" in result.output.lower()
        assert "--dataset" in result.output


class TestTestCommand:
    """Tests for test command."""

    def test_test_help(self) -> None:
        """Test test command help message."""
        runner = CliRunner()
        result = runner.invoke(cli, ["test", "--help"])
        assert result.exit_code == 0
        assert "test" in result.output.lower()


class TestServeCommand:
    """Tests for serve command."""

    def test_serve_help(self) -> None:
        """Test serve command help message."""
        runner = CliRunner()
        result = runner.invoke(cli, ["serve", "--help"])
        assert result.exit_code == 0
        assert "serve" in result.output.lower()
        assert "--transport" in result.output


class TestVersionCommand:
    """Tests for version command."""

    def test_version(self) -> None:
        """Test version command."""
        runner = CliRunner()
        result = runner.invoke(cli, ["version"])
        assert result.exit_code == 0
        assert "boj-mcp" in result.output
        assert "0.1.0" in result.output


class TestCLI:
    """Tests for main CLI."""

    def test_cli_help(self) -> None:
        """Test main CLI help message."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "datasets" in result.output
        assert "data" in result.output
        assert "search" in result.output
        assert "test" in result.output
        assert "serve" in result.output

    def test_cli_verbose(self) -> None:
        """Test verbose flag."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--verbose", "version"])
        assert result.exit_code == 0
