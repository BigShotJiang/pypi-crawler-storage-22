"""boj-mcp: Bank of Japan statistics data MCP tool.

Quick start::

    import asyncio
    from boj_mcp import BojClient

    async def main():
        async with BojClient() as client:
            # List available datasets
            datasets = await client.list_datasets()
            print(datasets[0].name)  # "cgpi_m_en"

            # Download and parse dataset
            df = await client.get_dataset("cgpi_m_en")
            print(df.head())

    asyncio.run(main())
"""

from boj_mcp.client import BojClient
from boj_mcp.models import DataPoint, Dataset, Series

__all__ = [
    "BojClient",
    "DataPoint",
    "Dataset",
    "Series",
]

__version__ = "0.1.2"
