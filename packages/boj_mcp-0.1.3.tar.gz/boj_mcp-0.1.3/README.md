# boj-mcp

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: Apache-2.0](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)

Bank of Japan statistics data MCP tool - First Python implementation.

## What is this?

**boj-mcp** provides programmatic access to the Bank of Japan's statistical flat files (CGPI, SPPI, TANKAN, Flow of Funds, etc.). It's the first Python implementation - previously only available via the R `BOJ` package (CRAN).

- Download and analyze BOJ flat files (ZIP → CSV)
- **Shift_JIS encoding** handled automatically
- Polars DataFrame export for high-performance analysis
- MCP server for AI assistant integration
- **No API key required** - all data is publicly available

## Data Sources

### Flat Files (16 datasets)
- **CGPI**: Corporate Goods Price Index
- **SPPI**: Services Producer Price Index  
- **TANKAN**: Short-term Economic Survey (短観)
- **Flow of Funds**: 資金循環統計
- **Balance of Payments**: 国際収支統計
- **IIP**: International Investment Position
- **BIS Statistics**: Bank for International Settlements data

## Quick Start

### Installation

```bash
pip install boj-mcp
# or
uv add boj-mcp
```

### 30-Second Example

```python
import asyncio
from boj_mcp import BojClient

async def main():
    async with BojClient() as client:
        # List available datasets
        datasets = await client.list_datasets()
        print(f"Found {len(datasets)} datasets")

        # Download and analyze CGPI (Corporate Goods Price Index)
        df = await client.get_dataset("cgpi_m_en")
        print(df.head())

asyncio.run(main())
```

### CLI Quick Start

```bash
# List available datasets
boj-mcp datasets

# Download CGPI data
boj-mcp data cgpi_m_en --rows 30

# Search for series
boj-mcp search "electricity"

# Test connectivity
boj-mcp test

# Start MCP server
boj-mcp serve
```

## MCP Server

Add to Claude Desktop config:

```json
{
  "mcpServers": {
    "boj": {
      "command": "uvx",
      "args": ["boj-mcp", "serve"]
    }
  }
}
```

### Available MCP Tools

| Tool | Description |
|------|-------------|
| `list_datasets` | List available flat file datasets |
| `get_dataset` | Download and parse a specific dataset |
| `search_series` | Search for time series by keyword |
| `get_series_data` | Get data for a specific series code |

## Python API

```python
import asyncio
from boj_mcp import BojClient

async def main():
    async with BojClient() as client:
        # List datasets
        datasets = await client.list_datasets()
        
        # Download dataset
        df = await client.get_dataset("cgpi_m_en")
        
        # Get metadata
        info = client.get_dataframe_info(df, "cgpi_m_en")
        print(f"Shape: {info.shape}")
        print(f"Columns: {info.columns}")

asyncio.run(main())
```

## Technical Notes

### Shift_JIS Encoding

BOJ flat files use Shift_JIS encoding. boj-mcp handles this automatically:

```python
csv_text = csv_bytes.decode('shift_jis', errors='replace')
```

### CSV Structure

BOJ CSV files come in two formats:
- **Wide format**: `code, desc, struc, [date1, date2, ...]`
- **Long format**: `code, freq, date, obs_value`

boj-mcp auto-detects and handles both.

### Caching

Downloaded ZIP files are cached in `~/.cache/boj-mcp/` to avoid re-downloading.

## Data Attribution & Disclaimer

This project uses data from the [Bank of Japan](https://www.boj.or.jp/) (日本銀行).

**Source**: Bank of Japan, Statistical Data ([https://www.stat-search.boj.or.jp/](https://www.stat-search.boj.or.jp/))

> **Disclaimer**: This project is neither officially related to nor endorsed by the Bank of Japan.
> Please avoid overloading the BOJ servers with unnecessary requests.
> The Bank of Japan assumes no responsibility for consequences arising from the use of its data.
> For commercial use of BOJ data, please contact the BOJ Public Relations Department.

## Related Projects

- [R BOJ package](https://github.com/stefanangrick/BOJ) - Original R implementation (reference)
- [edinet-mcp](https://github.com/ajtgjmdjp/edinet-mcp) - EDINET financial data
- [estat-mcp](https://github.com/ajtgjmdjp/estat-mcp) - e-Stat government statistics

## License

Apache-2.0

<!-- mcp-name: io.github.ajtgjmdjp/boj-mcp -->
