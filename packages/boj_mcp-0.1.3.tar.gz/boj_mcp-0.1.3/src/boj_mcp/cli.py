"""Command-line interface for boj-mcp.

Provides five commands:
- ``boj-mcp datasets``: List available datasets
- ``boj-mcp data``: Download and display dataset
- ``boj-mcp search``: Search for series by keyword
- ``boj-mcp test``: Test connectivity
- ``boj-mcp serve``: Start the MCP server
"""

from __future__ import annotations

import asyncio
import json
import sys
from typing import TYPE_CHECKING, Any, Literal, cast

import click
from loguru import logger

if TYPE_CHECKING:
    from boj_mcp.models import Dataset


@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Enable debug logging.")
def cli(verbose: bool) -> None:
    """Bank of Japan statistics data tools and MCP server."""
    level = "DEBUG" if verbose else "INFO"
    logger.remove()
    logger.add(sys.stderr, level=level, format="{time:HH:mm:ss} | {level:<7} | {message}")


@cli.command()
def datasets() -> None:
    """List available BOJ flat file datasets.

    Examples:

        boj-mcp datasets
    """
    from boj_mcp.client import BojClient

    async def _run() -> list[Dataset]:
        async with BojClient() as client:
            return await client.list_datasets()

    try:
        datasets = asyncio.run(_run())
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    if not datasets:
        click.echo("No datasets found.")
        return

    # Group by category
    by_category: dict[str, list[Dataset]] = {}
    for d in datasets:
        by_category.setdefault(d.category, []).append(d)

    click.echo(f"Available datasets ({len(datasets)} total):\n")

    for category, items in sorted(by_category.items()):
        click.echo(f"\n【{category}】")
        for d in items:
            desc = d.description[:50] + ".." if len(d.description) > 50 else d.description
            click.echo(f"  {d.name:<20} {desc}")


@cli.command()
@click.argument("name")
@click.option(
    "--format",
    "-f",
    "fmt",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.option(
    "--rows",
    "-n",
    default=20,
    help="Number of rows to display (default: 20).",
)
def data(name: str, fmt: str, rows: int) -> None:
    """Download and display a dataset.

    Examples:

        boj-mcp data cgpi_m_en

        boj-mcp data sppi_m_en --format json --rows 50
    """
    import polars as pl  # noqa: TC002 — runtime import

    from boj_mcp.client import BojClient

    async def _run() -> pl.DataFrame:
        async with BojClient() as client:
            return await client.get_dataset(name)

    try:
        df = asyncio.run(_run())
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    if fmt == "json":
        click.echo(json.dumps(df.head(rows).to_dicts(), ensure_ascii=False, indent=2))
        return

    # Table format
    click.echo(f"Dataset: {name}")
    click.echo(f"Shape: {df.shape[0]} rows x {df.shape[1]} cols\n")

    # Display with polars' built-in formatting
    click.echo(str(df.head(rows)))


@cli.command()
@click.argument("keyword")
@click.option(
    "--dataset",
    "-d",
    default=None,
    help="Limit search to specific dataset.",
)
def search(keyword: str, dataset: str | None) -> None:
    """Search for time series by keyword.

    Examples:

        boj-mcp search "electricity"

        boj-mcp search "企業物価" --dataset cgpi_m_en
    """
    from boj_mcp.client import BojClient

    async def _run() -> list[Any]:
        async with BojClient() as client:
            if dataset:
                # Search within specific dataset
                df = await client.get_dataset(dataset)
                # Simple search in string columns
                import polars as pl

                results = []
                for col in df.columns:
                    try:
                        lowered = df[col].cast(pl.Utf8).str.to_lowercase()
                        mask = lowered.str.contains(keyword.lower())
                        matched = df.filter(mask)
                        results.extend(matched.head(10).to_dicts())
                    except Exception:
                        continue
                return results
            else:
                # List datasets that might match
                datasets = await client.list_datasets()
                return [
                    d
                    for d in datasets
                    if keyword.lower() in d.name.lower()
                    or keyword.lower() in d.description.lower()
                ]

    try:
        results = asyncio.run(_run())
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    if not results:
        click.echo(f"No results found for '{keyword}'.")
        return

    if dataset:
        click.echo(f"Found {len(results)} matches in {dataset}:\n")
        for i, r in enumerate(results[:20], 1):
            click.echo(f"  {i}. {r}")
    else:
        click.echo(f"Datasets matching '{keyword}':\n")
        for d in results:
            click.echo(f"  {d.name:<20} {d.description}")


@cli.command("test")
def test_connection() -> None:
    """Test connectivity to BOJ statistics site.

    Verifies that the BOJ download page is accessible.
    """
    from boj_mcp import __version__

    click.echo(f"boj-mcp v{__version__}\n")

    click.echo("Testing connectivity to Bank of Japan...")

    from boj_mcp.client import BojClient

    async def _test() -> str:
        async with BojClient() as client:
            datasets = await client.list_datasets()
            return f"Found {len(datasets)} datasets"

    try:
        result = asyncio.run(_test())
        click.echo(f"[OK]   {result}")
    except Exception as e:
        click.echo(f"[FAIL] Connection error: {e}", err=True)
        sys.exit(1)

    click.echo("\nAll checks passed.")


@cli.command()
@click.option(
    "--transport",
    type=click.Choice(["stdio", "sse"]),
    default="stdio",
    help="MCP transport protocol.",
)
def serve(transport: str) -> None:
    """Start the BOJ MCP server.

    For Claude Desktop, add this to your config:

        {"mcpServers": {"boj": {"command": "uvx", "args": ["boj-mcp", "serve"]}}}
    """
    from boj_mcp.server import mcp

    logger.info(f"Starting BOJ MCP server ({transport} transport)")
    mcp.run(transport=cast('Literal["stdio", "sse"]', transport))


@cli.command()
def version() -> None:
    """Show version information."""
    from boj_mcp import __version__

    click.echo(f"boj-mcp {__version__}")


if __name__ == "__main__":
    cli()
