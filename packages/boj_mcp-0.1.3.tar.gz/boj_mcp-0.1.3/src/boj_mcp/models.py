"""Domain models for BOJ statistics data.

All public models use Pydantic v2 for validation and serialization.
"""

from __future__ import annotations

from datetime import date  # noqa: TC003 — needed at runtime by Pydantic
from typing import Any

from pydantic import BaseModel, Field


class Dataset(BaseModel):
    """A BOJ flat file dataset.

    Attributes:
        name: Dataset identifier (e.g., "cgpi_m_en").
        url: Download URL for the ZIP file.
        description: Human-readable description.
        category: Dataset category (e.g., "Prices", "Flow of Funds").
    """

    name: str
    url: str
    description: str = ""
    category: str = ""

    model_config = {"frozen": True}


class Series(BaseModel):
    """A time series within a dataset.

    Attributes:
        code: Series identifier code.
        name: Series description.
        unit: Unit of measurement.
        frequency: Data frequency ("M", "Q", "A" for monthly/quarterly/annual).
        dataset: Parent dataset name.
    """

    code: str
    name: str
    unit: str = ""
    frequency: str = ""
    dataset: str = ""

    model_config = {"frozen": True}


class DataPoint(BaseModel):
    """A single observation in a time series.

    Attributes:
        date: Observation date.
        value: Numeric value (can be float or None for missing data).
        series_code: Reference to the series.
        dataset: Parent dataset name.
    """

    date: date
    value: float | None
    series_code: str
    dataset: str

    model_config = {"frozen": True}


class DataFrameInfo(BaseModel):
    """Metadata about a loaded dataset DataFrame.

    Attributes:
        dataset_name: Name of the dataset.
        shape: (rows, columns) tuple.
        columns: List of column names.
        date_range: (start_date, end_date) if available.
    """

    dataset_name: str
    shape: tuple[int, int]
    columns: list[str] = Field(default_factory=list)
    date_range: tuple[str, str] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "dataset_name": self.dataset_name,
            "shape": self.shape,
            "columns": self.columns,
            "date_range": self.date_range,
        }
