"""Tests for boj_mcp.client."""

from __future__ import annotations

import zipfile
from io import BytesIO
from pathlib import Path  # noqa: TC003 — used by pytest tmp_path fixture
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from boj_mcp.client import BojClient, _categorize_dataset


class TestBojClient:
    """Tests for BojClient."""

    def test_client_initialization(self) -> None:
        """Test basic client initialization."""
        client = BojClient()
        assert client._timeout == 60.0
        assert client._cache_dir.name == "boj-mcp"

    def test_client_custom_cache(self, tmp_path: Path) -> None:
        """Test client with custom cache directory."""
        client = BojClient(cache_dir=tmp_path)
        assert client._cache_dir == tmp_path

    @pytest.mark.asyncio
    async def test_client_context_manager(self) -> None:
        """Test async context manager."""
        async with BojClient() as client:
            assert isinstance(client, BojClient)

    @pytest.mark.asyncio
    async def test_list_datasets(self) -> None:
        """Test listing datasets."""
        client = BojClient()

        # Mock HTML response
        html_content = """
        <html>
        <body>
        <a href="cgpi_m_en.zip">Corporate Goods Price Index</a>
        <a href="sppi_m_en.zip">Services Producer Price Index</a>
        </body>
        </html>
        """

        mock_response = MagicMock()
        mock_response.text = html_content
        mock_response.raise_for_status = MagicMock()

        with patch.object(client._http, "get", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = mock_response

            datasets = await client.list_datasets()

            assert len(datasets) == 2
            assert datasets[0].name == "cgpi_m_en"
            assert datasets[1].name == "sppi_m_en"
            assert datasets[0].category == "Prices"

    @pytest.mark.asyncio
    async def test_get_dataset_from_cache(self, tmp_path: Path) -> None:
        """Test loading dataset from cache."""
        client = BojClient(cache_dir=tmp_path)

        # Create a mock ZIP file with CSV
        csv_content = "code,desc,2024-01\n0000,Total,100.0\n"
        zip_buffer = BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("data.csv", csv_content)

        # Write to cache
        cache_file = tmp_path / "test_dataset.zip"
        cache_file.write_bytes(zip_buffer.getvalue())

        df = await client.get_dataset("test_dataset")

        assert df.shape[0] == 1
        assert df.shape[1] == 3
        # Check value exists (Polars may parse as int 0 instead of str "0000")
        val = df["code"][0]
        assert str(val) in ["0", "0000"]

    @pytest.mark.asyncio
    async def test_get_dataset_download(self, tmp_path: Path) -> None:
        """Test downloading dataset when not cached."""
        client = BojClient(cache_dir=tmp_path)

        # Create a mock ZIP file with CSV
        csv_content = "code,desc,2024-01\n0000,Total,100.0\n"
        zip_buffer = BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("data.csv", csv_content)

        mock_response = MagicMock()
        mock_response.content = zip_buffer.getvalue()
        mock_response.raise_for_status = MagicMock()

        with patch.object(client._http, "get", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = mock_response

            df = await client.get_dataset("cgpi_m_en")

            assert df.shape[0] == 1
            mock_get.assert_called_once()


class TestInputValidation:
    """Tests for input validation and security."""

    @pytest.mark.asyncio
    async def test_reject_path_traversal(self) -> None:
        """Test that path traversal in dataset names is rejected."""
        client = BojClient()
        with pytest.raises(ValueError, match="Invalid dataset name"):
            await client.get_dataset("../../etc/passwd")

    @pytest.mark.asyncio
    async def test_reject_slash_in_name(self) -> None:
        """Test that slashes in dataset names are rejected."""
        client = BojClient()
        with pytest.raises(ValueError, match="Invalid dataset name"):
            await client.get_dataset("foo/bar")

    def test_zip_slip_rejected(self) -> None:
        """Test that ZIP entries with path traversal are rejected."""
        client = BojClient()
        zip_buffer = BytesIO()
        with zipfile.ZipFile(zip_buffer, "w") as zf:
            zf.writestr("../../../etc/evil.csv", "data")
        with pytest.raises(ValueError, match="Unsafe ZIP entry"):
            client._parse_zip(zip_buffer.getvalue(), "test")


class TestCategorizeDataset:
    """Tests for _categorize_dataset helper."""

    def test_categorize_cgpi(self) -> None:
        """Test CGPI categorization."""
        assert _categorize_dataset("cgpi_m_en") == "Prices"

    def test_categorize_sppi(self) -> None:
        """Test SPPI categorization."""
        assert _categorize_dataset("sppi_m_en") == "Prices"

    def test_categorize_tankan(self) -> None:
        """Test TANKAN categorization."""
        assert _categorize_dataset("co") == "Surveys"

    def test_categorize_fof(self) -> None:
        """Test Flow of Funds categorization."""
        assert _categorize_dataset("fof") == "Flow of Funds"
        assert _categorize_dataset("fof2_en") == "Flow of Funds"

    def test_categorize_bop(self) -> None:
        """Test Balance of Payments categorization."""
        assert _categorize_dataset("bp_m_en") == "Balance of Payments"

    def test_categorize_iip(self) -> None:
        """Test IIP categorization."""
        assert _categorize_dataset("qiip_q_en") == "International Investment"

    def test_categorize_bis(self) -> None:
        """Test BIS categorization."""
        assert _categorize_dataset("bis1-1_q_en") == "BIS Statistics"
        assert _categorize_dataset("bis2-2_q_en") == "BIS Statistics"

    def test_categorize_other(self) -> None:
        """Test unknown dataset categorization."""
        assert _categorize_dataset("unknown") == "Other"
