"""Tests for boj_mcp.models."""

from __future__ import annotations

from datetime import date

import pytest
from pydantic import ValidationError

from boj_mcp.models import DataFrameInfo, DataPoint, Dataset, Series


class TestDataset:
    """Tests for Dataset model."""

    def test_dataset_creation(self) -> None:
        """Test Dataset creation."""
        d = Dataset(
            name="cgpi_m_en",
            url="https://example.com/cgpi.zip",
            description="Corporate Goods Price Index",
            category="Prices",
        )
        assert d.name == "cgpi_m_en"
        assert d.url == "https://example.com/cgpi.zip"
        assert d.description == "Corporate Goods Price Index"
        assert d.category == "Prices"

    def test_dataset_frozen(self) -> None:
        """Test Dataset is immutable."""
        d = Dataset(name="test", url="http://test.com")
        with pytest.raises(ValidationError):
            d.name = "modified"  # type: ignore[misc]


class TestSeries:
    """Tests for Series model."""

    def test_series_creation(self) -> None:
        """Test Series creation."""
        s = Series(
            code="0000",
            name="All commodities",
            unit="Index",
            frequency="M",
            dataset="cgpi_m_en",
        )
        assert s.code == "0000"
        assert s.name == "All commodities"
        assert s.unit == "Index"
        assert s.frequency == "M"
        assert s.dataset == "cgpi_m_en"


class TestDataPoint:
    """Tests for DataPoint model."""

    def test_datapoint_creation(self) -> None:
        """Test DataPoint creation."""
        dp = DataPoint(
            date=date(2024, 1, 1),
            value=105.2,
            series_code="0000",
            dataset="cgpi_m_en",
        )
        assert dp.date == date(2024, 1, 1)
        assert dp.value == 105.2
        assert dp.series_code == "0000"
        assert dp.dataset == "cgpi_m_en"

    def test_datapoint_none_value(self) -> None:
        """Test DataPoint with None value (missing data)."""
        dp = DataPoint(
            date=date(2024, 1, 1),
            value=None,
            series_code="0000",
            dataset="cgpi_m_en",
        )
        assert dp.value is None


class TestDataFrameInfo:
    """Tests for DataFrameInfo model."""

    def test_dataframe_info_creation(self) -> None:
        """Test DataFrameInfo creation."""
        info = DataFrameInfo(
            dataset_name="cgpi_m_en",
            shape=(1000, 50),
            columns=["code", "name", "2024-01", "2024-02"],
            date_range=("2024-01", "2024-12"),
        )
        assert info.dataset_name == "cgpi_m_en"
        assert info.shape == (1000, 50)
        assert len(info.columns) == 4
        assert info.date_range == ("2024-01", "2024-12")

    def test_dataframe_info_to_dict(self) -> None:
        """Test DataFrameInfo to_dict method."""
        info = DataFrameInfo(
            dataset_name="cgpi_m_en",
            shape=(1000, 50),
            columns=["code", "name"],
        )
        d = info.to_dict()
        assert d["dataset_name"] == "cgpi_m_en"
        assert d["shape"] == (1000, 50)
        assert d["columns"] == ["code", "name"]
