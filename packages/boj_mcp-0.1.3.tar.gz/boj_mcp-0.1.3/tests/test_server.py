"""Tests for boj_mcp.server (MCP tools)."""

from __future__ import annotations

import pytest


class TestServerHelpers:
    """Tests for server helper functions."""

    def test_search_in_dataframe(self) -> None:
        """Test _search_in_dataframe helper."""
        import polars as pl

        from boj_mcp.server import _search_in_dataframe

        df = pl.DataFrame(
            {
                "code": ["0000", "0001", "0002"],
                "desc": ["Total", "Electricity", "Gas"],
            }
        )

        results = _search_in_dataframe(df, "electricity", "cgpi_m_en")

        assert len(results) == 1
        assert results[0]["desc"] == "Electricity"

    def test_search_in_dataframe_no_match(self) -> None:
        """Test _search_in_dataframe with no matches."""
        import polars as pl

        from boj_mcp.server import _search_in_dataframe

        df = pl.DataFrame(
            {
                "code": ["0000", "0001"],
                "desc": ["Total", "Electricity"],
            }
        )

        results = _search_in_dataframe(df, "nonexistent", "cgpi_m_en")

        assert len(results) == 0

    def test_extract_series_from_df(self) -> None:
        """Test _extract_series_from_df helper."""
        import polars as pl

        from boj_mcp.server import _extract_series_from_df

        df = pl.DataFrame(
            {
                "code": ["0000", "0000", "0001"],
                "date": ["2024-01", "2024-02", "2024-01"],
                "value": [100.0, 101.0, 200.0],
            }
        )

        results = _extract_series_from_df(df, "0000", None, None)

        assert len(results) == 2


class TestServerInitialization:
    """Tests for server initialization."""

    @pytest.mark.asyncio
    async def test_get_client_creates_singleton(self) -> None:
        """Test _get_client creates singleton."""
        # Reset client for test
        import boj_mcp.server
        from boj_mcp.server import _get_client

        boj_mcp.server._client = None

        client1 = await _get_client()
        client2 = await _get_client()

        assert client1 is client2


class TestMCPDecoratedTools:
    """Tests that MCP tools are properly decorated."""

    def test_tools_exist(self) -> None:
        """Test that MCP tools are registered."""
        from boj_mcp.server import mcp

        # Verify the server module loads correctly with decorated tools
        assert mcp is not None
        assert mcp.name == "BOJ"
