# Bokk — AI-Powered CLI Accounting for Developers

## Brand & Assets

| Asset | Value |
|-------|-------|
| Domain | bokk.ai, bokk.se |
| X | @bokk_ai |
| Instagram | @bokk_ai |
| GitHub | github.com/bokk-ai |
| PyPI | bokk-ai |
| CLI command | `bokk` |

## What Is It

CLI-first, AI-powered Swedish accounting tool built for developers and small businesses. Bank-statement-driven, kontantmetoden by default, with clean APIs for future web/mobile UI.

## Core Design Decisions

- **Bank statement first** — the bank transaction is the bokföring trigger (kontantmetoden)
- **CLI first** — dev-friendly, scriptable, pipe-friendly
- **Local first** — SQLite, no cloud dependency for MVP
- **AI-layered categorization** — pattern match → RAG → LLM (minimize token usage)
- **Clean API layer** — core is a Python library, CLI is just one consumer
- **Storage-agnostic** — repository pattern, SQLite now, PostgreSQL later
- **Fakturametoden as add-on** — architecture supports it, but MVP is kontantmetoden only

## Swedish Compliance (Bokföringslagen)

- Grundbokföring (chronological recording)
- Huvudbokföring (systematic by account)
- Verifikationer (linked to each entry)
- Systemdokumentation (BFL 5 kap 11§)
- Behandlingshistorik (change log, no silent edits)
- 7-year archiving
- Corrections via new entries, not overwrites
- BAS-kontoplan (de facto standard)
- SIE4 export
- Momsredovisning (kontantmetoden = moms when paid)
- No certification/approval needed from Skatteverket

## AI Categorization Layers

```
Transaction in
  ├─ Layer 1: Pattern match (free, instant)
  │   Exact/fuzzy match on merchant name → known BAS account + moms
  ├─ Layer 2: RAG / embeddings (cheap, fast)
  │   Similar transactions from history, local embeddings
  └─ Layer 3: LLM (smart, costs tokens)
      Only for genuinely new/ambiguous transactions
      Context: BAS-kontoplan + booking history
```

## Tech Stack

- Python
- Typer (CLI framework)
- Rich (terminal output)
- SQLite (storage)
- Pydantic (data models / API)
- WeasyPrint (PDF reports)
- ChromaDB or similar (local embeddings for RAG)

## MVP Scope

### Input
- Monthly bank statement (CSV/PDF download)

### Core Flow
1. `bokk import statement.csv` — parse bank statement
2. `bokk review` — AI categorizes, user confirms/corrects
3. `bokk log` — git-log style verifikation history
4. `bokk status` — period overview
5. `bokk export sie4 2025` — SIE4 file
6. `bokk export moms 2025-Q1` — momsunderlag
7. `bokk report balans 2025` — PDF balansrapport
8. `bokk report resultat 2025` — PDF resultatrapport

### Not in MVP
- Live bank feed (GoCardless — add later)
- Invoice matching / reskontra
- Fakturametoden
- Web UI / mobile
- Multi-user / cloud

## Future Additions
- GoCardless bank API integration
- Fakturametoden support (reskontra)
- FastAPI server wrapping core API
- Web UI
- Skatteverket API integration (digital momsdeklaration)
- `brew install bokk`

## Context
- Built for Jonas's Swedish company (few transactions/month, mostly costs/licenses)
- Kontantmetoden
- Mostly dormant/cost-based company
- Target: 5-minute monthly accounting after initial training
