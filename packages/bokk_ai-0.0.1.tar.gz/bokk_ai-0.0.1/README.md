# 📚 Bokk — AI-Powered CLI Accounting

> Swedish bokföring for developers. Bank-statement-driven, AI-categorized, SIE4-ready.

**Coming soon.** Follow [@bokk_ai](https://x.com/bokk_ai) for updates.

## Install

```bash
pip install bokk-ai
```

## What It Will Do

```bash
bokk import bank-statement.csv   # Import bank transactions
bokk review                      # AI categorizes, you confirm
bokk log                         # Git-log style verification history
bokk status                      # Period overview
bokk export sie4 2025            # SIE4 export
bokk report balans 2025          # PDF balance report
```

## Links

- 🌐 [bokk.ai](https://bokk.ai)
- 🐙 [GitHub](https://github.com/bokk-ai/bokk)
- 🐦 [Twitter/X](https://x.com/bokk_ai)
