"""Bokk — AI-powered CLI accounting for developers."""

__version__ = "0.0.1"
