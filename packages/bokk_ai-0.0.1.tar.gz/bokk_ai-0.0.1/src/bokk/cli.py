"""Bokk CLI — AI-powered accounting for developers."""

import typer

app = typer.Typer(help="AI-powered CLI accounting for developers.")


@app.command()
def version():
    """Show version."""
    from bokk import __version__
    typer.echo(f"bokk {__version__}")


if __name__ == "__main__":
    app()
