import subprocess
import json
import argparse
import os
import datetime
import re
from docker import errors
from bomancli.base_logger import logging
from bomancli.Config import Config
# --- Git Helper Functions ---

def ensure_full_git_history():
    try:
        is_shallow = subprocess.check_output(
            ["git", "rev-parse", "--is-shallow-repository"],
            text=True
        ).strip()

        if is_shallow == "true":
            logging.info("[INFO] Shallow repository detected. Fetching full history...")
            subprocess.run(
                ["git", "fetch", "--prune", "--unshallow"],
                check=False
            )
        else:
            logging.info("[INFO] Repository already has full history.")

    except Exception as e:
        logging.error(f"[WARN] Could not determine git history depth: {e}", file=sys.stderr)





def run_git_command(cmd, cwd=None):
    """Run a git command and return output."""
    try:
        if cwd and not os.path.exists(cwd):
            return None, "cwd_not_found"
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
            cwd=cwd,
            encoding='utf-8', 
            errors='replace'
        )
        if result.returncode != 0:
            return None, result.stderr.strip()
        return result.stdout.strip(), None
    except Exception as e:
        logging.error(f"Error running git command {' '.join(cmd)}: {e}")
        return None, str(e)

def get_branch_info(repo_root="."):
    """Fetch current branch name, commit, and remote."""
    branch, _ = run_git_command(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_root)
    commit, _ = run_git_command(["git", "rev-parse", "HEAD"], cwd=repo_root)
    remote, _ = run_git_command(["git", "config", "--get", "remote.origin.url"], cwd=repo_root)
    
    return {
        "name": branch,
        "head_commit": commit,
        "remote_url": remote
    }

# --- Blame Logic ---

def get_owner_from_lines(file_path, start_line, end_line):
    # Ensure file exists
    if not os.path.isfile(file_path):
        return None, "file_not_found_on_disk"

    cmd = [
        "git", "blame",
        "-w", "-M", "-C",
        "-L", f"{start_line},{end_line}",
        "--line-porcelain",
        "--", file_path
    ]

    result, error = run_git_command(cmd)
    
    if error:
        return None, error

    line_authors = []

    line_authors = []
    current = {}

    for line in result.splitlines():
        # Check for new block start (Hash Line)
        # Format: <40-hex-sha> <orig_line> <final_line> [<group_lines>]
        if re.match(r'^[a-f0-9]{40}\s', line):
            # If we have a previous block with sufficient data, save it
            if "author" in current:
                line_authors.append(current)
            # Start new block
            current = {}
            parts = line.split(" ")
            current["commit"] = parts[0]
            continue

        if line.startswith("author "):
            current["author"] = line.replace("author ", "")
        elif line.startswith("author-mail "):
            current["email"] = line.replace("author-mail ", "").strip("<>")
        elif line.startswith("author-time "):
            current["author_time"] = int(line.replace("author-time ", ""))
        elif line.startswith("committer-time "):
             pass
        elif line.startswith("summary "):
            current["summary"] = line.replace("summary ", "")
        elif line.startswith("\t"):  # actual code line
            current["code"] = line.strip()
            
    # Capture the last block
    if "author" in current:
        line_authors.append(current)

    if not line_authors:
        return None, f"no_authors_parsed_from_blame. Raw output start: {result[:200]!r}"

    # Aggregate stats for this specific block
    unique_authors = {}
    
    for entry in line_authors:
        email = entry.get("email")
        if email not in unique_authors:
            unique_authors[email] = {
                "name": entry.get("author"),
                "email": email,
                "commit": entry.get("commit"),
                "line_count": 0,
                "timestamps": []
            }
        unique_authors[email]["line_count"] += 1
        unique_authors[email]["timestamps"].append(entry.get("author_time"))

    # Sort by line count
    sorted_authors = sorted(unique_authors.values(), key=lambda x: x["line_count"], reverse=True)
    
    if not sorted_authors:
        return None, "no_sorted_authors"

    # Determine primary owner for this finding
    primary = sorted_authors[0]
    
    # Calculate most recent time
    all_timestamps = [t for a in unique_authors.values() for t in a["timestamps"]]
    most_recent_ts = max(all_timestamps) if all_timestamps else 0
    most_recent_str = datetime.datetime.fromtimestamp(most_recent_ts).strftime("%Y-%m-%d %H:%M:%S")

    return {
        "file": file_path,
        "lines": f"{start_line}-{end_line}",
        "authors": sorted_authors,
        "primary_owner": primary["name"],
        "primary_email": primary["email"],
        "primary_commit": primary["commit"],
        "updated_at": most_recent_str
    }, None

# --- Main Enrichment Logic ---

def normalize_path(path):
    # Remove leading prefixes often found in container scans
    if path.startswith("/src/"): 
        return path[5:]
    elif path.startswith("src/"): 
        return path[4:]
    return path.lstrip("/")

def enrich_files(input_path, output_path):
    # 1. Load Input

    logging.info(f"Loading {input_path}...")
    
    #logging.info('checking git swallow')

    ensure_full_git_history()
    
    try:
        with open(input_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        logging.error(f"Error reading input file: {e}")
        return

    # Handle if root is list
    results = data.get("results", []) if isinstance(data, dict) else data
    if isinstance(data, list):
        # normalize structure
        data = {"results": results}

    # 2. Prepare Globals
    git_users_registry = {} # key: email, value: stats
    
    logging.info(f"Processing {len(results)} findings...")

    # 3. Process Findings
    for idx, result in enumerate(results):
        path = normalize_path(result.get("path", ""))
        
        # Determine lines
        start_line = None
        if isinstance(result.get("start"), dict):
            start_line = result.get("start", {}).get("line")
        else:
            start_line = result.get("start_line") or result.get("start") # fallback

        end_line = None
        if isinstance(result.get("end"), dict):
            end_line = result.get("end", {}).get("line")
        else:
            end_line = result.get("end_line") or result.get("end") or start_line

        if not path or not start_line:
            result["attribution"] = {"status": "skipped_invalid_path_or_line"}
            continue

        if not os.path.exists(path):
            result["attribution"] = {"status": "file_not_found", "original_path": result.get("path")}
            continue
        
        # Get Blame
        blame_info, blame_error = get_owner_from_lines(path, int(start_line), int(end_line))
        
        if blame_info:
            # Enriched Attribution Field
            result["attribution"] = {
                "developer": blame_info["primary_owner"],
                "email": blame_info["primary_email"],
                "commit": blame_info["primary_commit"],
                "updated_at": blame_info["updated_at"],
                "confidence": "high",
                "status": "attributed",
                "all_authors": blame_info["authors"] # optional detail
            }

            # Update Global Registry
            for author in blame_info["authors"]:
                email = author["email"]
                if email not in git_users_registry:
                    git_users_registry[email] = {
                        "name": author["name"],
                        "email": email,
                        "total_attributed_findings": 0,
                        "last_active_ts": 0
                    }
                
                # Update stats
                reg = git_users_registry[email]
                if author["name"] == blame_info["primary_owner"]:
                     # Only count as 'attributed finding' if they are the primary owner? 
                     # Or count participation? Let's count if they are primary owner.
                     reg["total_attributed_findings"] += 1
                
                # Update activity time
                # author["timestamps"] is a list of ts
                if author["timestamps"]:
                    max_ts = max(author["timestamps"])
                    if max_ts > reg["last_active_ts"]:
                        reg["last_active_ts"] = max_ts

        else:
            result["attribution"] = {"status": "blame_failed", "error": blame_error}
    
    # 4. Finalize Globals
    
    # Valid Git Users
    final_users = []
    for email, stats in git_users_registry.items():
        stats["last_active"] = datetime.datetime.fromtimestamp(stats["last_active_ts"]).strftime("%Y-%m-%d %H:%M:%S")
        del stats["last_active_ts"]
        final_users.append(stats)
    
    data["git_users"] = final_users

    # Branch Info
    logging.info("Fetching branch info...")
    data["branch_info"] = get_branch_info()

    # 5. Write Output
    logging.info(f"Writing results to {output_path}...")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    logging.info("Done.")

def main():
    parser = argparse.ArgumentParser(description="Enrich OpenGrep findings with Git Blame information.")
    parser.add_argument("--input", "-i", required=True, help="Input OpenGrep JSON file")
    parser.add_argument("--output", "-o", default="opengrep_enriched.json", help="Output JSON file")
    
    args = parser.parse_args()
    enrich_files(args.input, args.output)

if __name__ == "__main__":
    main()
