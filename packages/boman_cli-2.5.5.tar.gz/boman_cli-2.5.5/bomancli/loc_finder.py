import os
from docker import errors
from bomancli.base_logger import logging
from bomancli.Config import Config
docker = Config.docker_client


###line counts based on given file extension --  MM

def countlines(start,lines=0, header=False, begin_start=None,extentsion='.py'):
    # if header:
    #     print('{:>10} |{:>10} | {:<20}'.format('Added', 'Total', 'filename'))
    #     print('{:->11}|{:->11}|{:->20}'.format('', '', ''))

    # lang_extensions = {
    # #     'nodejs':'.js',
    # #     'python':'.py',
    # #     'php':'.php',
    # #     'ruby':'.rb',
    # #     'go':'.go',
    # #     'java':'.java',
    # #     'python-snyk':'.py',
    # #     'node-snyk':'.js',
    # #     'ruby-snyk':'.rb',
    # #     'csharp':'.cs'
    # # }

    # # #print(lang_extensions['js'])





    if extentsion is None:
        print(extentsion)
        return 0

    for thing in os.listdir(start):
        thing = os.path.join(start, thing)
        if os.path.isfile(thing):
            if thing.endswith(extentsion):
                with open(thing, 'r') as f:
                    newlines = f.readlines()
                    newlines = len(newlines)
                    lines += newlines

                    if begin_start is not None:
                        reldir_of_thing = '.' + thing.replace(begin_start, '')
                    else:
                        reldir_of_thing = '.' + thing.replace(start, '')

                    # print('{:>10} |{:>10} | {:<20}'.format(
                    #         newlines, lines, reldir_of_thing))


    for thing in os.listdir(start):
        thing = os.path.join(start, thing)
        if os.path.isdir(thing):
            lines = countlines(thing, lines, header=False, begin_start=start)

    return lines




#print(countlines('/home/boxuser/box/Vuln-code/',extentsion='.rb'))




def run_cloc_docker():
    
    docker_image="bomanai/cloc:latest"
    userid= Config.userid
    detach=False
    command_line = f"{Config.build_dir} --json --out=/{Config.build_dir}/cloc.json"
    tool_name ='cloc'
    logging.info('Generating loc')
    try:

        logging.info('Cloc Docker: Preparing %s scan for jenkins env with %s user ', tool_name , userid)    

       
        container_output = docker.containers.run(docker_image, command_line, volumes={Config.sast_build_dir: {
                        'bind': Config.sast_build_dir}}, user=userid,detach=detach, remove=True)
        logging.info('Cloc Docker: SUCCESS !!!. Message: %s Scan Completed',tool_name)

    except errors.ContainerError as exc:
        msg='\n The following error has been recorded while scanning SAST'
        Utils.logError(msg,str(exc))
        logging.error(f'SAST Docker: Failed !!!, Message: Some Error recorded while scanning {str(exc)}')
        Config.sast_scan_status = 'Failed'
        Config.sast_errors = f'Exit Status {exc.exit_status}:{str(exc)}]'
