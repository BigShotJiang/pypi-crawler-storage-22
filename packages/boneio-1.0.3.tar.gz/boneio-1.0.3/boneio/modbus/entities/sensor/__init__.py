# Backwards compatibility aliases
from boneio.modbus.entities.sensor.binary import ModbusBinarySensor
from boneio.modbus.entities.sensor.numeric import ModbusNumericSensor

__all__ = ["ModbusBinarySensor", "ModbusNumericSensor"]