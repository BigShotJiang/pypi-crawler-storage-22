def main() -> None:
    print("Hello from bonepick!")
