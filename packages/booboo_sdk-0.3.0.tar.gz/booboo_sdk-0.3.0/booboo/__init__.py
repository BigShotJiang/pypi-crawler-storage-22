from ._client import BoobooClient

_client = None


def init(dsn, endpoint="https://api.booboo.dev/ingest/", app=None):
    """Initialize booboo error tracking.

    Always hooks sys.excepthook. Auto-detects Django (no app needed).
    Pass app for Flask/FastAPI integration.
    """
    global _client
    _client = BoobooClient(dsn, endpoint)
    _client.install(app)


def capture_exception(exc=None):
    """Manually capture an exception. Uses sys.exc_info() if exc is None."""
    if _client:
        _client.capture_exception(exc)
