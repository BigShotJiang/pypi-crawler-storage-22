import atexit
import sys
import threading
import requests
from ._stacktrace import extract_frames


class BoobooClient:
    def __init__(self, dsn, endpoint):
        self.dsn = dsn
        self.endpoint = endpoint
        self._orig_excepthook = None
        self._pending = []
        self._lock = threading.Lock()
        atexit.register(self._flush)

    def install(self, app=None):
        """Hook sys.excepthook, auto-detect Django, register Flask/FastAPI handlers."""
        self._orig_excepthook = sys.excepthook
        sys.excepthook = self._excepthook

        # Django: auto-detect via signal import
        try:
            from django.core.signals import got_request_exception

            got_request_exception.connect(self._django_handler)
        except ImportError:
            pass

        if app is not None:
            self._install_framework(app)

    def _install_framework(self, app):
        try:
            import flask

            if isinstance(app, flask.Flask):
                self._install_flask(app)
                return
        except ImportError:
            pass

        try:
            import fastapi

            if isinstance(app, fastapi.FastAPI):
                self._install_fastapi(app)
                return
        except ImportError:
            pass

    def _install_flask(self, app):
        client = self

        @app.errorhandler(Exception)
        def _booboo_flask_handler(exc):
            try:
                from flask import request

                request_data = {"method": request.method, "path": request.path}
            except Exception:
                request_data = None
            client._capture_and_send(exc, request_data=request_data)
            raise exc

        return _booboo_flask_handler

    def _install_fastapi(self, app):
        client = self

        @app.exception_handler(Exception)
        async def _booboo_fastapi_handler(request, exc):
            request_data = {"method": request.method, "path": str(request.url.path)}
            client._capture_and_send(exc, request_data=request_data)
            raise exc

        return _booboo_fastapi_handler

    def _excepthook(self, exc_type, exc_value, exc_tb):
        self._capture_and_send(exc_value)
        if self._orig_excepthook:
            self._orig_excepthook(exc_type, exc_value, exc_tb)

    def _django_handler(self, sender, request=None, **kwargs):
        exc = sys.exc_info()[1]
        if exc:
            request_data = None
            if request:
                request_data = {"method": request.method, "path": request.path}
            self._capture_and_send(exc, request_data=request_data)

    def capture_exception(self, exc=None):
        """Public API: capture an exception manually."""
        if exc is None:
            exc = sys.exc_info()[1]
        if exc is not None:
            self._capture_and_send(exc)

    def _capture_and_send(self, exc, request_data=None):
        try:
            frames = extract_frames(exc)
        except Exception:
            frames = []

        payload = {
            "message": str(exc),
            "exception_type": type(exc).__name__,
            "level": "error",
            "stacktrace": frames,
        }
        if request_data:
            payload["request"] = request_data

        t = threading.Thread(target=self._do_send, args=(payload,))
        with self._lock:
            self._pending.append(t)
        t.start()

    def _flush(self):
        """Wait for all pending sends to complete (called at exit)."""
        with self._lock:
            threads = list(self._pending)
        for t in threads:
            t.join(timeout=5)

    def _do_send(self, payload):
        try:
            requests.post(
                self.endpoint,
                json=payload,
                headers={"X-Booboo-DSN": self.dsn},
                timeout=5,
            )
        except Exception:
            pass
