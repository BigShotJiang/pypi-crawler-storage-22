import linecache
from ._scrubber import scrub_vars

CONTEXT_LINES = 5


def extract_frames(exc):
    """Walk exc.__traceback__, return list of frame dicts with rich context."""
    frames = []
    tb = exc.__traceback__
    while tb is not None:
        frame = tb.tb_frame
        lineno = tb.tb_lineno
        filename = frame.f_code.co_filename
        function = frame.f_code.co_name

        context_line = linecache.getline(filename, lineno).rstrip("\n")

        all_lines = linecache.getlines(filename)
        start = max(0, lineno - 1 - CONTEXT_LINES)
        end = min(len(all_lines), lineno + CONTEXT_LINES)
        pre_context = [l.rstrip("\n") for l in all_lines[start : lineno - 1]]
        post_context = [l.rstrip("\n") for l in all_lines[lineno:end]]

        local_vars = scrub_vars(frame.f_locals)

        frames.append(
            {
                "filename": filename,
                "function": function,
                "lineno": lineno,
                "context_line": context_line,
                "pre_context": pre_context,
                "post_context": post_context,
                "vars": local_vars,
            }
        )
        tb = tb.tb_next
    return frames
