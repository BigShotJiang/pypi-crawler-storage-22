"""Configuration management for BookBot."""
