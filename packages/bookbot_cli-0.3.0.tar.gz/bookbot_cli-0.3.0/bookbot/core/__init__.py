"""Core functionality for BookBot."""
