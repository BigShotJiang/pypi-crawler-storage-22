"""IO operations for BookBot."""
