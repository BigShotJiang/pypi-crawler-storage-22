"""Test suite for BookBot."""
