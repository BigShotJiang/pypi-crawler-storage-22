"""TUI interface for BookBot."""
