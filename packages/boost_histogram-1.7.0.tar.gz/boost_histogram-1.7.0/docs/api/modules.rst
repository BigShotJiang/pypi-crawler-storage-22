
.. toctree::
   :maxdepth: 4

   boost_histogram
