# Bootsec

Security baseline for your project. One command, you're set.

## The Problem

You're shipping fast. Security? "We'll add it later."

Later never comes. Then some bot finds your AWS keys on GitHub at 3am.

## The Fix

```bash
pip install bootsec
bootsec go
```

That's it. 60 seconds. Done.

You now have:
- `.gitignore` that actually blocks secrets
- `SECURITY.md` so people can report vulns
- `docs/security-checklist.md` for pre-launch
- `.pre-commit-config.yaml` that catches mistakes before you commit

No config files. No 200-page docs. No BS.

## Commands

| Command | What it does |
|---------|--------------|
| `bootsec go` | Setup everything |
| `bootsec guard` | Pre-commit check (<1 sec) |
| `bootsec peek` | Preview before applying |
| `bootsec packs` | See available packs |

## How It Works

1. **Scans** your repo (Node? Python? Flutter? We got you)
2. **Generates** security docs for your stack
3. **Guards** your commits so you don't push secrets
4. **Merges** with your existing files (never overwrites)

## What You Get

| File | Why |
|------|-----|
| `.gitignore` | Blocks secrets, build junk |
| `.env.example` | Template for env vars |
| `SECURITY.md` | Vuln reporting |
| `docs/security-checklist.md` | Pre-launch checklist |
| `.pre-commit-config.yaml` | Commit guard |

## Examples

```bash
bootsec go           # basic setup
bootsec go --ci      # + GitHub Actions
bootsec peek         # just preview, no changes
```

## Design

- Merge, don't overwrite
- No network calls
- Pure Python, zero deps
- Fast. Like, actually fast.

---

## Want More?

**[Bootsec Pro](https://beatdown0x.gumroad.com/l/vytstl)** unlocks the good stuff:

| Command | What it does |
|---------|--------------|
| `bootsec check` | Security audit with score (0-100) |
| `bootsec scan` | Find vulnerable deps |
| `bootsec deps` | Audit npm/pip/cargo/go/ruby/php |
| `bootsec sbom` | Generate SBOM |
| `bootsec ai` | AI fix suggestions |

Plus: **85+ secret patterns**, Docker/K8s checks, supply chain security.

**[Get Pro](https://beatdown0x.gumroad.com/l/vytstl)**

---

## Requirements

- Python 3.10+
- Git

## License

MIT

---

*Code audited by my buddy Claude. He finds bugs at 3am without complaining. Truly built different.*
