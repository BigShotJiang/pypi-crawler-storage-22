"""Security checks for bootsec (free version).

FAST mode only - for guard command.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

# Limits
FILE_READ_CAP = 64 * 1024  # 64KB per file

# Directories to always skip
SKIP_DIRS = {".git", "node_modules", ".venv", "venv", "dist", "build", ".dart_tool", "__pycache__", ".next", ".nuxt"}

# Signal files for fast mode
SIGNAL_FILES = [
    "package.json", "package-lock.json", "pnpm-lock.yaml", "yarn.lock",
    "pyproject.toml", "requirements.txt", "poetry.lock",
    "pubspec.yaml", "pubspec.lock",
    "README.md",
]

# Risky patterns (conservative for fast mode)
ENV_FILE_PATTERN = re.compile(r"^\.env(\..+)?$")
PRIVATE_KEY_PATTERN = re.compile(r"-----BEGIN\s+(RSA|DSA|EC|OPENSSH|PGP|ENCRYPTED)?\s*PRIVATE\s+KEY-----")

# Core secret patterns for fast mode
SECRET_PATTERNS = [
    # AWS
    (re.compile(r"AKIA[0-9A-Z]{16}"), "AWS Access Key", "high", 25),
    # GitHub
    (re.compile(r"ghp_[a-zA-Z0-9]{36}"), "GitHub PAT", "high", 25),
    (re.compile(r"github_pat_[a-zA-Z0-9]{22}_[a-zA-Z0-9]{59}"), "GitHub PAT (fine-grained)", "high", 25),
    # Stripe
    (re.compile(r"sk_live_[a-zA-Z0-9]{24,}"), "Stripe Live Key", "high", 25),
    # Slack
    (re.compile(r"xox[baprs]-[0-9]{10,13}-[0-9]{10,13}[a-zA-Z0-9-]*"), "Slack Token", "high", 25),
    # Database URLs
    (re.compile(r"(?i)(mongodb(\+srv)?|postgres(ql)?|mysql|redis)://[^:\s]+:[^@\s]+@[^\s]+"), "Database URL with credentials", "high", 25),
    # Private keys
    (re.compile(r"-----BEGIN\s+(RSA|DSA|EC|OPENSSH)?\s*PRIVATE\s+KEY-----"), "Private Key", "high", 25),
]

# False positive contexts
FALSE_POSITIVE_CONTEXTS = [
    re.compile(r"(?i)(example|sample|test|dummy|fake|placeholder|your[_-]?|my[_-]?|xxx|replace[_-]?me)"),
    re.compile(r"<[A-Z_]+>"),
    re.compile(r"\$\{[^}]+\}"),
    re.compile(r"\{\{[^}]+\}\}"),
]


@dataclass
class Finding:
    name: str
    severity: str  # "high", "med", "low"
    points: int
    source: str = ""


@dataclass
class CheckResult:
    mode: str  # "fast"
    findings: list[Finding] = field(default_factory=list)
    files_scanned: int = 0
    bytes_scanned: int = 0

    @property
    def score(self) -> int:
        total = sum(f.points for f in self.findings)
        return max(0, min(100, 100 - total))

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "high")

    @property
    def med_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "med")

    @property
    def low_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "low")


def fast_checks(directory: Path) -> CheckResult:
    """Fast mode: signal files only, high-confidence issues."""
    result = CheckResult(mode="fast")

    # Check for .env files in root
    for item in directory.iterdir():
        if item.is_file() and ENV_FILE_PATTERN.match(item.name):
            if item.name != ".env.example":
                result.findings.append(Finding(
                    f".env file tracked: {item.name}",
                    "high", 25, item.name
                ))

    # Check baseline docs
    _check_baseline_docs(directory, result)

    # Check staged files for secrets
    _check_staged_secrets(directory, result)

    return result


def _check_baseline_docs(directory: Path, result: CheckResult) -> None:
    """Check for missing baseline docs."""
    checks = [
        (".gitignore", "gitignore", "high", 20),
        ("SECURITY.md", "security policy", "high", 20),
        (".pre-commit-config.yaml", "commit guard", "med", 8),
    ]

    for path, name, severity, points in checks:
        fpath = directory / path
        if not fpath.exists():
            result.findings.append(Finding(name, severity, points, path))


def _check_staged_secrets(directory: Path, result: CheckResult) -> None:
    """Check staged files for secrets."""
    import subprocess

    try:
        proc = subprocess.run(
            ["git", "diff", "--cached", "--name-only"],
            cwd=directory,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if proc.returncode != 0:
            return

        staged_files = [f for f in proc.stdout.strip().split("\n") if f]
    except Exception:
        return

    for relpath in staged_files:
        fpath = directory / relpath
        if not fpath.exists() or not fpath.is_file():
            continue

        try:
            content = fpath.read_text(errors="ignore")[:FILE_READ_CAP]
            _check_content_secrets(content, relpath, result)
        except Exception:
            pass


def _check_content_secrets(content: str, filepath: str, result: CheckResult) -> None:
    """Scan content for secrets."""
    for pattern, name, severity, points in SECRET_PATTERNS:
        matches = pattern.findall(content)
        for match in matches:
            match_str = match if isinstance(match, str) else match[0]

            # Check for false positives
            context_start = max(0, content.find(match_str) - 50)
            context_end = min(len(content), content.find(match_str) + len(match_str) + 50)
            context = content[context_start:context_end]

            is_false_positive = any(fp.search(context) for fp in FALSE_POSITIVE_CONTEXTS)

            if not is_false_positive:
                result.findings.append(Finding(
                    f"{name} in staged file",
                    severity, points, filepath
                ))
                break  # One finding per pattern per file
