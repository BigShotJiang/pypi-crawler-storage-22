"""Bootsec CLI - Free version.

Security baseline for your project. One command, you're set.
"""
from __future__ import annotations

import json
import random
import subprocess
import sys
from pathlib import Path

from bootsec.checks import fast_checks
from bootsec.profiles import Profile
from bootsec.renderer import detect_project_type, generate_files
from bootsec.packs import suggest_packs, select_packs_by_layer, list_packs

VERSION = "0.8.0"
BOOTSEC_DIR = ".bootsec"
GUMROAD_URL = "https://beatdown0x.gumroad.com/l/vytstl"

# UI
BAR_WIDTH = 24
CHICK = "🐤"


def score_bar(score: int) -> str:
    """Generate ASCII progress bar."""
    filled = int((score / 100) * BAR_WIDTH)
    filled = max(0, min(BAR_WIDTH, filled))
    empty = BAR_WIDTH - filled
    return "█" * filled + "░" * empty


def print_splash():
    """Print friendly splash."""
    print(f"\n  {CHICK} bootsec v{VERSION}\n")


def print_seal():
    """Print success seal."""
    print(f"  {CHICK}")


def print_help():
    """Print friendly help."""
    print(f"""
  {CHICK} bootsec v{VERSION}

  Security baseline for your project. One command, you're set.

  ─────────────────────────────────────────────────────────────

  Commands:

    bootsec go          Set up security baseline (docs + guard)
    bootsec guard       Pre-commit check (runs in <1 second)
    bootsec peek        Preview what 'go' would create
    bootsec packs       See all available security packs

  Options:

    --ci                Include GitHub Actions workflow
    --full              Enable extra security packs

  ─────────────────────────────────────────────────────────────

  Examples:

    $ bootsec go                 # Quick setup
    $ bootsec go --ci            # Setup + GitHub Actions
    $ bootsec peek               # See what would be created

  ─────────────────────────────────────────────────────────────

  {CHICK} Want deeper security scans?

  Bootsec Pro gives you:
    • Deep scans (85+ secret patterns)
    • Vulnerability detection
    • Dependency audits
    • SBOM generation
    • AI-powered fixes

  → {GUMROAD_URL}

  ─────────────────────────────────────────────────────────────
""")


def print_pro_feature(cmd: str):
    """Friendly message for Pro features."""
    print(f"""
  {CHICK} Hey! '{cmd}' is a Pro feature.

  ─────────────────────────────────────────────────────────────

  Bootsec Pro includes:

    ✓ check     Deep security audit (85+ secret patterns)
    ✓ scan      Vulnerability detection (OSV database)
    ✓ deps      Dependency audits (npm, pip, cargo, go...)
    ✓ sbom      SBOM generation (CycloneDX, SPDX)
    ✓ ai        AI-powered fix suggestions

  ─────────────────────────────────────────────────────────────

  Get it here → {GUMROAD_URL}

  After purchase:
    1. You'll get a license key
    2. Download bootsec-pro
    3. Run: bootsec activate YOUR-LICENSE-KEY
    4. All Pro features unlocked!

  ─────────────────────────────────────────────────────────────

  Thanks for using Bootsec! {CHICK}
""")


def print_upsell():
    """Friendly upsell message."""
    tips = [
        f"Tip: Deep scan your repo with 'bootsec check' → {GUMROAD_URL}",
        f"Tip: Find vulnerabilities with 'bootsec scan' → {GUMROAD_URL}",
        f"Tip: Audit dependencies with 'bootsec deps' → {GUMROAD_URL}",
    ]
    print(f"\n  {CHICK} {random.choice(tips)}\n")


def maybe_show_upsell():
    """Show upsell 1 in 4 times."""
    if random.randint(1, 4) == 1:
        print_upsell()


def write_manifest(directory: Path, pack_names: list[str], project_type: str, reasons: list[str]) -> None:
    """Write manifest file."""
    baseline_dir = directory / "docs" / "baseline"
    baseline_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        "version": VERSION,
        "project_type": project_type,
        "packs": pack_names,
        "reasons": reasons,
    }

    manifest_path = baseline_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2))


# ─────────────────────────────────────────────────────────────────────────────
# Commands
# ─────────────────────────────────────────────────────────────────────────────

def cmd_go(args: list[str]) -> int:
    """Full setup: docs + commit guard."""
    directory = Path.cwd()
    full_mode = "--full" in args
    include_ci = "--ci" in args

    print_splash()

    # Detect project type
    project_type = detect_project_type(directory)
    print(f"  Detected: {project_type}")

    # Select packs
    suggestions = suggest_packs(directory)
    selection = select_packs_by_layer(suggestions, full_mode=full_mode)
    pack_names = selection.all_packs()
    reasons = []
    for s in suggestions:
        if s.pack_name in pack_names:
            reasons.append(f"{s.reason} → {s.pack_name}")
    print(f"  Packs: {', '.join(pack_names)}")

    # Create profile
    profile = Profile(
        name="startup",
        gitignore=True,
        env_example=True,
        security_md=True,
        checklist=True,
        pre_commit=True,
        github_actions=include_ci,
        with_secret_scanner=False,
    )

    # Generate files
    results = generate_files(directory, profile, project_type, dry_run=False, pack_names=pack_names)

    # Write manifest
    write_manifest(directory, pack_names, project_type, reasons)

    # Count actions
    created = sum(1 for r in results if r.action == "create")
    updated = sum(1 for r in results if r.action == "update")

    # Install pre-commit
    precommit_config = directory / ".pre-commit-config.yaml"
    if precommit_config.exists():
        try:
            subprocess.run(
                ["pre-commit", "install"],
                cwd=directory,
                capture_output=True,
                timeout=30,
            )
            print("  Pre-commit hooks installed")
        except Exception:
            pass

    print()
    print(f"  Done! Created {created} files, updated {updated}.")
    print()
    print_seal()
    maybe_show_upsell()
    return 0


def cmd_guard(args: list[str]) -> int:
    """Pre-commit guard check."""
    directory = Path.cwd()

    result = fast_checks(directory)

    if result.high_count > 0:
        bar = score_bar(result.score)

        print(f"\n  ✗ Guard blocked commit  [{bar}] {result.score}/100")
        print()

        for f in result.findings[:5]:
            severity_mark = "!" if f.severity == "high" else "~"
            print(f"  {severity_mark} {f.name}")

        if len(result.findings) > 5:
            print(f"  ... and {len(result.findings) - 5} more")

        print()
        print("  Fix these issues and try again.")
        print()
        return 1
    else:
        print_seal()
        return 0


def cmd_peek(args: list[str]) -> int:
    """Preview what go would create."""
    directory = Path.cwd()
    full_mode = "--full" in args
    include_ci = "--ci" in args

    print_splash()

    project_type = detect_project_type(directory)
    print(f"  Stack: {project_type}")

    suggestions = suggest_packs(directory)
    selection = select_packs_by_layer(suggestions, full_mode=full_mode)
    pack_names = selection.all_packs()
    print(f"  Packs: {', '.join(pack_names)}")
    print()

    profile = Profile(
        name="startup",
        gitignore=True,
        env_example=True,
        security_md=True,
        checklist=True,
        pre_commit=True,
        github_actions=include_ci,
        with_secret_scanner=False,
    )

    results = generate_files(directory, profile, project_type, dry_run=True, pack_names=pack_names)

    print("  Would create/update:")
    print()
    for r in results:
        icon = "+" if r.action == "create" else "~"
        print(f"    {icon} {r.path}")

    print()
    print(f"  Total: {len(results)} files")
    print()
    print("  Run 'bootsec go' to apply these changes.")
    print()
    maybe_show_upsell()
    return 0


def cmd_review(args: list[str]) -> int:
    """Preview coverage layers."""
    directory = Path.cwd()
    full_mode = "--full" in args

    print_splash()

    suggestions = suggest_packs(directory)
    selection = select_packs_by_layer(suggestions, full_mode=full_mode)
    pack_names = selection.all_packs()

    print("  Security coverage:\n")
    for s in suggestions:
        if s.pack_name in pack_names:
            print(f"    ✓ {s.pack_name}")
            print(f"      {s.reason}")
            print()

    maybe_show_upsell()
    return 0


def cmd_packs(args: list[str]) -> int:
    """List all available packs."""
    print_splash()
    print("  Available security packs:\n")

    for pack in list_packs():
        print(f"    • {pack.name}")
        if pack.description:
            print(f"      {pack.description}")
        print()

    maybe_show_upsell()
    return 0


def cmd_version(args: list[str]) -> int:
    """Show version."""
    print(f"bootsec {VERSION}")
    return 0


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

COMMANDS = {
    "go": cmd_go,
    "guard": cmd_guard,
    "peek": cmd_peek,
    "review": cmd_review,
    "packs": cmd_packs,
    "version": cmd_version,
    # Aliases
    "init": cmd_go,
}

# Pro commands that show friendly upgrade message
PRO_COMMANDS = {"check", "scan", "deps", "sbom", "ai", "audit", "deep"}


def main() -> int:
    """Main entry point."""
    args = sys.argv[1:]

    # Handle flags
    if not args or args[0] in ("--help", "-h", "help", "hey"):
        print_help()
        return 0

    if args[0] in ("--version", "-v", "-V"):
        return cmd_version(args)

    cmd = args[0].lower()
    cmd_args = args[1:]

    # Check for Pro command
    if cmd in PRO_COMMANDS:
        print_pro_feature(cmd)
        return 0

    # Run command
    if cmd in COMMANDS:
        try:
            return COMMANDS[cmd](cmd_args)
        except KeyboardInterrupt:
            print("\n  Cancelled.")
            return 130
        except Exception as e:
            print(f"\n  Oops! Something went wrong: {e}")
            print("  Please report this at: github.com/gqnxx/Bootsec/issues")
            return 1

    # Unknown command
    print(f"\n  Unknown command: {cmd}")
    print("  Run 'bootsec help' to see available commands.")
    print()
    return 1


if __name__ == "__main__":
    sys.exit(main())
