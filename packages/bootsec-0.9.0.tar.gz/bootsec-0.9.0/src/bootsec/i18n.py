"""Internationalization for Bootsec CLI output.

Omar voice: 27-year-old builder, nerdy, confident, friendly.
80% clear + direct, 20% humor (max 1 line per section).
"""
from __future__ import annotations

import os

LANG_AR = "ar"
LANG_EN = "en"

# Phrasing library - consistent voice across all output
MESSAGES = {
    # Success/status - only place for emojis
    "all_good": {"en": "All good", "ar": "يا قوت"},
    "almost_there": {"en": "Almost there", "ar": "قريب"},
    "fix_and_retry": {"en": "Fix and try again", "ar": "أصلح وحاول مرة ثانية"},

    # Score comments (Omar style - one per score range)
    "score_90": {"en": "Beast mode. This is clean.", "ar": "يا وحش… هذا اسمه شغل."},
    "score_75": {"en": "Solid. A couple tweaks and you're set.", "ar": "ممتاز… باقي كم لمسة وتكمل."},
    "score_60": {"en": "Decent. Fix the items below.", "ar": "زين… بس سوّ اللي تحت."},
    "score_40": {"en": "Needs work. We're not here to panic, just fix it.", "ar": "نحتاج نرتّب… بس لا تقلق."},
    "score_0": {"en": "Hold up. We stopped you for a reason.", "ar": "وقف… وقفناك لسبب."},

    # Section markers (◉ prefix)
    "scan": {"en": "scan", "ar": "فحص"},
    "plan": {"en": "plan", "ar": "خطة"},
    "apply": {"en": "apply", "ar": "تطبيق"},
    "guard": {"en": "guard", "ar": "حماية"},

    # Action markers
    "created": {"en": "created", "ar": "تم"},
    "updated": {"en": "updated", "ar": "تحديث"},
    "skipped": {"en": "skipped", "ar": "تخطّي"},

    # Status messages
    "commit_guard_enabled": {"en": "commit guard enabled", "ar": "حماية الكوميت مفعّلة"},
    "install_failed": {"en": "install failed", "ar": "فشل التثبيت"},
    "not_initialized": {"en": "Not initialized", "ar": "غير مهيّأ"},

    # Labels
    "detected": {"en": "Detected", "ar": "اكتشف"},
    "packs": {"en": "Packs", "ar": "حزم"},
    "why": {"en": "why", "ar": "لماذا"},
    "suggested": {"en": "suggested", "ar": "مقترح"},
    "issues": {"en": "issue(s)", "ar": "مشكلة"},
    "file_s": {"en": "file(s)", "ar": "ملف"},

    # Hint prefixes
    "fix": {"en": "Fix", "ar": "الحل"},
    "run": {"en": "Run", "ar": "شغّل"},
    "warning": {"en": "heads up", "ar": "تنبيه"},

    # Scan modes
    "mode": {"en": "mode", "ar": "الوضع"},
    "mode_fast": {"en": "fast", "ar": "سريع"},
    "mode_deep": {"en": "deep", "ar": "عميق"},
}


_current_lang: str | None = None


def detect_lang() -> str:
    """Detect language from environment. Priority: BOOTSEC_LANG > LANG/LC_ALL > en."""
    # Check explicit setting
    bootsec_lang = os.environ.get("BOOTSEC_LANG", "").lower()
    if bootsec_lang in (LANG_AR, LANG_EN):
        return bootsec_lang

    # Check system locale
    for var in ("LANG", "LC_ALL", "LC_MESSAGES"):
        val = os.environ.get(var, "").lower()
        if val.startswith("ar"):
            return LANG_AR

    return LANG_EN


def set_lang(lang: str) -> None:
    """Override the detected language."""
    global _current_lang
    if lang in (LANG_AR, LANG_EN, "auto"):
        _current_lang = None if lang == "auto" else lang


def get_lang() -> str:
    """Get current language."""
    if _current_lang is not None:
        return _current_lang
    return detect_lang()


def t(key: str) -> str:
    """Translate a message key to current language."""
    lang = get_lang()
    msg = MESSAGES.get(key, {})
    return msg.get(lang, msg.get("en", key))


def parse_lang_arg(args: list[str]) -> list[str]:
    """Parse --lang flag from args and set language. Returns args without --lang."""
    result = []
    i = 0
    while i < len(args):
        if args[i] == "--lang" and i + 1 < len(args):
            set_lang(args[i + 1].lower())
            i += 2
        else:
            result.append(args[i])
            i += 1
    return result
