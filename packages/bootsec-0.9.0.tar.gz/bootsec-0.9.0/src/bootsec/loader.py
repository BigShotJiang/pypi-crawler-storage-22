from importlib import resources


def get_template(category: str, name: str) -> str:
    try:
        return resources.files("bootsec.templates").joinpath(category, name).read_text()
    except FileNotFoundError:
        pass

    try:
        return resources.files("bootsec.templates").joinpath("common", name).read_text()
    except FileNotFoundError:
        return ""


def render(template: str, **variables: str) -> str:
    result = template
    for key, value in variables.items():
        result = result.replace(f"{{{{{key}}}}}", str(value))
    return result


def get_pack_template(pack_name: str, name: str) -> str:
    try:
        return resources.files("bootsec.templates").joinpath("packs", pack_name, name).read_text()
    except (FileNotFoundError, TypeError):
        return ""
