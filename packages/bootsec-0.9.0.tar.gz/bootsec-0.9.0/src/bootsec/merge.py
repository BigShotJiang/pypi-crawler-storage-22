import re

BEGIN_MARKER = "# === BEGIN BOOTSEC ==="
END_MARKER = "# === END BOOTSEC ==="


def merge_block(existing: str, new_block: str) -> str:
    if not existing:
        return new_block

    pattern = re.compile(
        rf"{re.escape(BEGIN_MARKER)}.*?{re.escape(END_MARKER)}",
        re.DOTALL
    )

    if pattern.search(existing):
        return pattern.sub(new_block.strip(), existing)

    lines = existing.rstrip().split("\n")
    lines.append("")
    lines.append(new_block.strip())
    return "\n".join(lines) + "\n"


def has_marker(content: str) -> bool:
    return BEGIN_MARKER in content and END_MARKER in content
