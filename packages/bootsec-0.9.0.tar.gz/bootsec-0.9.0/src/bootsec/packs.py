from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path

from .signals import scan_repo
from .loader import get_pack_template


@dataclass
class Pack:
    name: str
    description: str
    layer: str  # core, baseline, platform, data, team
    checklist_items: list[str] = field(default_factory=list)
    security_items: list[str] = field(default_factory=list)
    creates_baseline: bool = False


# Pack layers for structured selection
LAYER_CORE = "core"
LAYER_BASELINE = "baseline"
LAYER_PLATFORM = "platform"
LAYER_DATA = "data"
LAYER_TEAM = "team"

PACKS: dict[str, Pack] = {
    # Core - always included
    "core-baseline": Pack(
        name="core-baseline",
        description="Universal security controls (always on)",
        layer=LAYER_CORE,
    ),
    # Baseline - regional, pick one
    "sa-baseline": Pack(
        name="sa-baseline",
        description="Regional baseline controls",
        layer=LAYER_BASELINE,
        creates_baseline=True,
    ),
    "global-baseline": Pack(
        name="global-baseline",
        description="International baseline controls",
        layer=LAYER_BASELINE,
        creates_baseline=True,
    ),
    # Platform - pick one
    "api-backend": Pack(
        name="api-backend",
        description="API and backend services",
        layer=LAYER_PLATFORM,
    ),
    "web-app": Pack(
        name="web-app",
        description="Web application security",
        layer=LAYER_PLATFORM,
    ),
    "mobile-app": Pack(
        name="mobile-app",
        description="Mobile application security",
        layer=LAYER_PLATFORM,
    ),
    "cli-tool": Pack(
        name="cli-tool",
        description="CLI tool security",
        layer=LAYER_PLATFORM,
    ),
    "startup-saas": Pack(
        name="startup-saas",
        description="SaaS application essentials",
        layer=LAYER_PLATFORM,
    ),
    # Data - pick one if detected
    "payments": Pack(
        name="payments",
        description="Payment and financial data",
        layer=LAYER_DATA,
        creates_baseline=True,
    ),
    "health-data": Pack(
        name="health-data",
        description="Health and patient data",
        layer=LAYER_DATA,
        creates_baseline=True,
    ),
    "pii": Pack(
        name="pii",
        description="Personal data handling",
        layer=LAYER_DATA,
        creates_baseline=True,
    ),
    # Team/profile packs
    "enterprise-lite": Pack(
        name="enterprise-lite",
        description="Lightweight enterprise controls",
        layer=LAYER_TEAM,
        creates_baseline=True,
    ),
}


@dataclass
class PackSuggestion:
    pack_name: str
    confidence: float
    reason: str


def suggest_packs(directory: Path) -> list[PackSuggestion]:
    """Suggest packs based on repo signals."""
    signals = scan_repo(directory)
    suggestions = []

    # Baseline detection
    if signals.has_saudi_hints or signals.has_arabic:
        suggestions.append(PackSuggestion("sa-baseline", 0.9, "regional hints"))
    else:
        suggestions.append(PackSuggestion("global-baseline", 0.7, "default"))

    # Platform detection
    if signals.has_api_framework or signals.has_docker:
        suggestions.append(PackSuggestion("api-backend", 0.8, "API/Docker detected"))

    if signals.has_mobile or signals.stack == "flutter":
        suggestions.append(PackSuggestion("mobile-app", 0.85, "mobile detected"))

    if signals.stack == "node" and not signals.has_mobile:
        suggestions.append(PackSuggestion("web-app", 0.6, "Node.js web"))

    # Data detection
    if signals.has_health_keywords:
        suggestions.append(PackSuggestion("health-data", 0.9, "health keywords"))

    if signals.has_payment_keywords:
        suggestions.append(PackSuggestion("payments", 0.9, "payment keywords"))

    if signals.has_auth_keywords:
        suggestions.append(PackSuggestion("startup-saas", 0.75, "auth patterns"))
        suggestions.append(PackSuggestion("pii", 0.7, "user auth = PII"))

    suggestions.sort(key=lambda x: x.confidence, reverse=True)
    return suggestions


@dataclass
class LayerSelection:
    """Result of layer-based pack selection."""
    core: str = "core-baseline"
    baseline: str | None = None
    platform: str | None = None
    data: str | None = None
    extra: list[str] = field(default_factory=list)
    suggested_extras: list[PackSuggestion] = field(default_factory=list)

    def all_packs(self) -> list[str]:
        """Return all selected packs in order."""
        packs = [self.core]
        if self.baseline:
            packs.append(self.baseline)
        if self.platform:
            packs.append(self.platform)
        if self.data:
            packs.append(self.data)
        packs.extend(self.extra)
        return packs

    def count(self) -> int:
        return len(self.all_packs())


def select_packs_by_layer(
    suggestions: list[PackSuggestion],
    full_mode: bool = False,
    confidence_threshold: float = 0.7,
) -> LayerSelection:
    """
    Select packs by layer:
    - core: always on
    - baseline: 1 max (regional)
    - platform: 1 max
    - data: 1 max
    - full_mode: allows 1 extra from suggestions
    """
    selection = LayerSelection()
    used_layers = {LAYER_CORE}

    for s in suggestions:
        if s.confidence < confidence_threshold:
            continue

        pack = PACKS.get(s.pack_name)
        if not pack:
            continue

        layer = pack.layer

        if layer == LAYER_BASELINE and not selection.baseline:
            selection.baseline = s.pack_name
            used_layers.add(layer)
        elif layer == LAYER_PLATFORM and not selection.platform:
            selection.platform = s.pack_name
            used_layers.add(layer)
        elif layer == LAYER_DATA and not selection.data:
            selection.data = s.pack_name
            used_layers.add(layer)
        elif layer == LAYER_TEAM and full_mode and len(selection.extra) < 1:
            selection.extra.append(s.pack_name)
        elif layer in (LAYER_PLATFORM, LAYER_DATA):
            # Already have one in this layer, suggest as extra
            selection.suggested_extras.append(s)

    # Default baseline if none selected
    if not selection.baseline:
        selection.baseline = "global-baseline"

    return selection


def get_pack(name: str) -> Pack | None:
    return PACKS.get(name)


def list_packs() -> list[Pack]:
    return list(PACKS.values())


def get_packs_by_layer(layer: str) -> list[Pack]:
    return [p for p in PACKS.values() if p.layer == layer]


def render_pack_checklist(pack_names: list[str]) -> str:
    """Render checklist content for given packs."""
    blocks = []
    for name in pack_names:
        content = get_pack_template(name, "checklist.md.tmpl")
        if content:
            blocks.append(content.strip())
    return "\n\n".join(blocks)


def render_pack_security(pack_names: list[str]) -> str:
    """Render security content for given packs."""
    blocks = []
    for name in pack_names:
        content = get_pack_template(name, "security.md.tmpl")
        if content:
            blocks.append(content.strip())
    return "\n\n".join(blocks)


def render_pack_baseline(pack_names: list[str]) -> str:
    """Render baseline docs for packs that create baselines."""
    blocks = []
    for name in pack_names:
        pack = PACKS.get(name)
        if pack and pack.creates_baseline:
            content = get_pack_template(name, "baseline.md.tmpl")
            if content:
                blocks.append(content.strip())
    return "\n\n".join(blocks)


def render_pack_evidence(pack_names: list[str]) -> str:
    """Render evidence pack content."""
    blocks = []
    for name in pack_names:
        content = get_pack_template(name, "evidence.md.tmpl")
        if content:
            blocks.append(content.strip())
    return "\n\n".join(blocks)


# Coverage tags for internal tracking
COVERAGE_TAGS = {
    "access_control": ["access.mfa", "access.least_privilege", "api.auth"],
    "secrets": ["secrets.no_repo", "secrets.env_usage"],
    "logging": ["logging.what", "logging.no_sensitive", "health.access_log"],
    "backup_restore": ["backup.exists", "backup.restore_test"],
    "incident_response": ["incident.runbook"],
    "vendor_mgmt": ["vendor.review"],
    "data_protection": ["pii.encrypt", "health.encrypt_rest", "payment.tokenize"],
    "input_validation": ["api.input_validation", "web.xss", "cli.input"],
}


def get_coverage_summary(pack_names: list[str]) -> dict[str, int]:
    """Count coverage tags from selected packs."""
    counts = {tag: 0 for tag in COVERAGE_TAGS}

    for name in pack_names:
        content = get_pack_template(name, "checklist.md.tmpl")
        if content:
            for tag, keys in COVERAGE_TAGS.items():
                for key in keys:
                    if f"bs:key={key}" in content:
                        counts[tag] += 1

    return {k: v for k, v in counts.items() if v > 0}
