from dataclasses import dataclass


@dataclass
class Profile:
    name: str
    gitignore: bool = True
    env_example: bool = True
    security_md: bool = True
    checklist: bool = True
    pre_commit: bool = True
    github_actions: bool = True
    with_secret_scanner: bool = False


PROFILES = {
    "startup": Profile(
        name="startup",
        gitignore=True,
        env_example=True,
        security_md=True,
        checklist=True,
        pre_commit=True,
        github_actions=True,
        with_secret_scanner=False,
    ),
    "solo": Profile(
        name="solo",
        gitignore=True,
        env_example=True,
        security_md=True,
        checklist=True,
        pre_commit=False,
        github_actions=False,
        with_secret_scanner=False,
    ),
    "team": Profile(
        name="team",
        gitignore=True,
        env_example=True,
        security_md=True,
        checklist=True,
        pre_commit=True,
        github_actions=True,
        with_secret_scanner=False,
    ),
}


def get_profile(name: str) -> Profile:
    return PROFILES.get(name, PROFILES["startup"])
