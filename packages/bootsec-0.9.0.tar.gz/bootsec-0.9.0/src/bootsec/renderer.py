from __future__ import annotations
from pathlib import Path
from dataclasses import dataclass

from .loader import get_template, get_pack_template
from .profiles import Profile
from .merge import merge_block


@dataclass
class GeneratedFile:
    path: str
    action: str


def detect_project_type(directory: Path) -> str:
    """Detect project type based on config files."""
    # Mobile first
    if (directory / "pubspec.yaml").exists():
        return "flutter"

    # JS/Node ecosystem
    if (directory / "package.json").exists():
        return "node"

    # Python
    if any((directory / f).exists() for f in ["pyproject.toml", "requirements.txt", "setup.py", "Pipfile"]):
        return "python"

    # Go
    if (directory / "go.mod").exists():
        return "go"

    # Rust
    if (directory / "Cargo.toml").exists():
        return "rust"

    # Java/JVM
    if any((directory / f).exists() for f in ["pom.xml", "build.gradle", "build.gradle.kts"]):
        return "java"

    # Ruby
    if (directory / "Gemfile").exists():
        return "ruby"

    # PHP
    if (directory / "composer.json").exists():
        return "php"

    # .NET
    if list(directory.glob("*.csproj")) or list(directory.glob("*.sln")):
        return "dotnet"

    return "common"


def generate_files(
    directory: Path,
    profile: Profile,
    project_type: str,
    dry_run: bool = False,
    pack_names: list[str] | None = None,
) -> list[GeneratedFile]:
    results = []
    pack_names = pack_names or []

    # Ensure core-baseline is always first
    if "core-baseline" not in pack_names:
        pack_names = ["core-baseline"] + pack_names

    if profile.gitignore:
        result = generate_gitignore(directory, project_type, dry_run)
        if result:
            results.append(result)

    if profile.env_example:
        result = generate_env_example(directory, dry_run)
        if result:
            results.append(result)

    if profile.security_md:
        result = generate_security_md(directory, dry_run, pack_names)
        if result:
            results.append(result)

    if profile.checklist:
        result = generate_checklist(directory, dry_run, pack_names)
        if result:
            results.append(result)

    if profile.pre_commit:
        result = generate_pre_commit(directory, dry_run, profile.with_secret_scanner)
        if result:
            results.append(result)

    if profile.github_actions:
        result = generate_github_actions(directory, dry_run)
        if result:
            results.append(result)

    if pack_names:
        baseline_results = generate_baseline_docs(directory, dry_run, pack_names)
        results.extend(baseline_results)

    return results


def generate_gitignore(directory: Path, project_type: str, dry_run: bool = False) -> GeneratedFile | None:
    gitignore_path = directory / ".gitignore"

    common_block = get_template("common", "gitignore.block.tmpl")
    extra_block = get_template(project_type, "gitignore.extra.tmpl")

    new_content = common_block
    if extra_block:
        lines = new_content.strip().split("\n")
        insert_idx = lines.index("# === END BOOTSEC ===")
        extra_lines = extra_block.strip().split("\n")
        lines = lines[:insert_idx] + [""] + extra_lines + [""] + lines[insert_idx:]
        new_content = "\n".join(lines)

    existing = ""
    action = "create"

    if gitignore_path.exists():
        existing = gitignore_path.read_text()
        action = "update"

    final_content = merge_block(existing, new_content)

    if not dry_run:
        gitignore_path.write_text(final_content)

    return GeneratedFile(path=".gitignore", action=action)


def generate_env_example(directory: Path, dry_run: bool = False) -> GeneratedFile | None:
    env_path = directory / ".env.example"

    if env_path.exists():
        return GeneratedFile(path=".env.example", action="skip") if dry_run else None

    content = get_template("common", "env.example.tmpl")

    if not dry_run:
        env_path.write_text(content)

    return GeneratedFile(path=".env.example", action="create")


def generate_security_md(
    directory: Path, dry_run: bool = False, pack_names: list[str] | None = None
) -> GeneratedFile | None:
    security_path = directory / "SECURITY.md"

    if security_path.exists():
        return GeneratedFile(path="SECURITY.md", action="skip") if dry_run else None

    content = get_template("common", "security.md.tmpl")

    if pack_names:
        from .packs import render_pack_security
        pack_content = render_pack_security(pack_names)
        if pack_content:
            content = content.replace("<!-- BOOTSEC:PACKS:SECURITY -->", pack_content)

    if not dry_run:
        security_path.write_text(content)

    return GeneratedFile(path="SECURITY.md", action="create")


def generate_checklist(
    directory: Path, dry_run: bool = False, pack_names: list[str] | None = None
) -> GeneratedFile | None:
    docs_dir = directory / "docs"
    checklist_path = docs_dir / "security-checklist.md"

    if checklist_path.exists():
        return GeneratedFile(path="docs/security-checklist.md", action="skip") if dry_run else None

    content = get_template("common", "checklist.md.tmpl")

    # Inject core-baseline first
    core_content = get_pack_template("core-baseline", "checklist.md.tmpl")
    if core_content:
        content = content.replace("<!-- BOOTSEC:CORE -->", core_content.strip())

    # Then inject other packs
    if pack_names:
        from .packs import render_pack_checklist
        # Exclude core-baseline since it's already injected
        other_packs = [p for p in pack_names if p != "core-baseline"]
        pack_content = render_pack_checklist(other_packs)
        if pack_content:
            content = content.replace("<!-- BOOTSEC:PACKS:CHECKLIST -->", pack_content)

    # Add stack-specific guidance
    project_type = detect_project_type(directory)
    stack_content = get_template(project_type, "checklist.extra.tmpl")
    if stack_content:
        content = content.replace("<!-- BOOTSEC:STACK -->", stack_content.strip())

    if not dry_run:
        docs_dir.mkdir(exist_ok=True)
        checklist_path.write_text(content)

    return GeneratedFile(path="docs/security-checklist.md", action="create")


def generate_pre_commit(
    directory: Path, dry_run: bool = False, with_secret_scanner: bool = False
) -> GeneratedFile | None:
    pre_commit_path = directory / ".pre-commit-config.yaml"

    if pre_commit_path.exists():
        return GeneratedFile(path=".pre-commit-config.yaml", action="skip") if dry_run else None

    if with_secret_scanner:
        content = get_template("common", "pre-commit-with-secret-scanner.yaml.tmpl")
    else:
        content = get_template("common", "pre-commit-config.yaml.tmpl")

    if not dry_run:
        pre_commit_path.write_text(content)

    return GeneratedFile(path=".pre-commit-config.yaml", action="create")


def generate_github_actions(directory: Path, dry_run: bool = False) -> GeneratedFile | None:
    workflows_dir = directory / ".github" / "workflows"
    security_yml_path = workflows_dir / "security.yml"

    if security_yml_path.exists():
        return GeneratedFile(path=".github/workflows/security.yml", action="skip") if dry_run else None

    content = get_template("common", "github-actions-security.yml.tmpl")

    if not dry_run:
        workflows_dir.mkdir(parents=True, exist_ok=True)
        security_yml_path.write_text(content)

    return GeneratedFile(path=".github/workflows/security.yml", action="create")


def generate_baseline_docs(
    directory: Path, dry_run: bool, pack_names: list[str]
) -> list[GeneratedFile]:
    results = []
    baseline_dir = directory / "docs" / "baseline"

    from .packs import render_pack_baseline, render_pack_evidence, PACKS

    has_baseline_pack = any(PACKS.get(p, None) and PACKS[p].creates_baseline for p in pack_names)

    if has_baseline_pack:
        baseline_path = baseline_dir / "security-baseline.md"
        if baseline_path.exists():
            if dry_run:
                results.append(GeneratedFile(path="docs/baseline/security-baseline.md", action="skip"))
        else:
            content = render_pack_baseline(pack_names)
            if content:
                if not dry_run:
                    baseline_dir.mkdir(parents=True, exist_ok=True)
                    baseline_path.write_text(content)
                results.append(GeneratedFile(path="docs/baseline/security-baseline.md", action="create"))

        evidence_path = baseline_dir / "evidence-pack.md"
        if evidence_path.exists():
            if dry_run:
                results.append(GeneratedFile(path="docs/baseline/evidence-pack.md", action="skip"))
        else:
            content = render_pack_evidence(pack_names)
            if content:
                if not dry_run:
                    baseline_dir.mkdir(parents=True, exist_ok=True)
                    evidence_path.write_text(content)
                results.append(GeneratedFile(path="docs/baseline/evidence-pack.md", action="create"))

    return results
