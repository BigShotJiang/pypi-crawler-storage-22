from __future__ import annotations
from pathlib import Path
from dataclasses import dataclass
import re


@dataclass
class RepoSignals:
    stack: str
    has_docker: bool = False
    has_api_framework: bool = False
    has_mobile: bool = False
    has_health_keywords: bool = False
    has_payment_keywords: bool = False
    has_auth_keywords: bool = False
    has_saudi_hints: bool = False
    has_arabic: bool = False
    has_database: bool = False
    has_cli: bool = False
    has_web_frontend: bool = False


# Stack detection order matters - more specific first
STACK_SIGNALS = [
    # Mobile
    ("flutter", ["pubspec.yaml"]),
    ("react-native", ["app.json", "metro.config.js"]),
    ("ios", ["*.xcodeproj", "*.xcworkspace", "Podfile"]),
    ("android", ["build.gradle", "settings.gradle"]),

    # Modern frontend frameworks (before generic node)
    ("next", ["next.config.js", "next.config.mjs", "next.config.ts"]),
    ("nuxt", ["nuxt.config.js", "nuxt.config.ts"]),
    ("remix", ["remix.config.js"]),
    ("astro", ["astro.config.mjs", "astro.config.ts"]),
    ("svelte", ["svelte.config.js"]),
    ("solid", ["solid.config.js", "vite.config.ts"]),

    # Desktop
    ("electron", ["electron.js", "electron-builder.json"]),
    ("tauri", ["src-tauri/tauri.conf.json"]),

    # Serverless
    ("serverless", ["serverless.yml", "serverless.yaml"]),
    ("vercel", ["vercel.json"]),
    ("netlify", ["netlify.toml"]),

    # Modern runtimes
    ("deno", ["deno.json", "deno.jsonc"]),
    ("bun", ["bunfig.toml"]),

    # Node (generic - after specific frameworks)
    ("node", ["package.json"]),

    # Backend
    ("python", ["pyproject.toml", "requirements.txt", "setup.py", "Pipfile"]),
    ("go", ["go.mod"]),
    ("rust", ["Cargo.toml"]),
    ("java", ["pom.xml", "build.gradle.kts"]),
    ("kotlin", ["build.gradle.kts", "settings.gradle.kts"]),
    ("scala", ["build.sbt"]),
    ("ruby", ["Gemfile"]),
    ("php", ["composer.json"]),
    ("dotnet", ["*.csproj", "*.fsproj", "*.sln"]),
    ("elixir", ["mix.exs"]),
    ("haskell", ["stack.yaml", "cabal.project"]),
    ("zig", ["build.zig"]),
]


def scan_repo(directory: Path) -> RepoSignals:
    signals = RepoSignals(stack="common")

    # Detect stack based on config files
    for stack_name, indicators in STACK_SIGNALS:
        for indicator in indicators:
            if "*" in indicator:
                # Glob pattern
                if list(directory.glob(indicator)):
                    signals.stack = stack_name
                    break
            elif (directory / indicator).exists():
                signals.stack = stack_name
                break
        if signals.stack != "common":
            break

    # Flutter implies mobile
    if signals.stack == "flutter":
        signals.has_mobile = True

    # Docker detection
    docker_files = ["Dockerfile", "docker-compose.yml", "docker-compose.yaml", "compose.yml"]
    if any((directory / f).exists() for f in docker_files):
        signals.has_docker = True

    # Mobile detection (platform dirs)
    if (directory / "android").is_dir() or (directory / "ios").is_dir():
        signals.has_mobile = True

    # Collect text for keyword analysis
    text_content = _collect_text(directory)

    # API framework detection (expanded)
    api_patterns = r"\b(fastapi|django|express|nestjs|flask|gin|echo|fiber|spring|rails|laravel|actix|rocket|axum|phoenix|sinatra|koa|hapi|graphql)\b"
    if re.search(api_patterns, text_content, re.IGNORECASE):
        signals.has_api_framework = True

    # Health/medical keywords
    health_patterns = r"\b(health|patient|medical|hl7|fhir|hipaa|clinic|diagnosis|pharmacy|hospital|ehr|emr)\b"
    if re.search(health_patterns, text_content, re.IGNORECASE):
        signals.has_health_keywords = True

    # Payment/fintech keywords
    payment_patterns = r"\b(stripe|paypal|checkout|payment|billing|invoice|subscription|merchant|transaction|pci|wallet)\b"
    if re.search(payment_patterns, text_content, re.IGNORECASE):
        signals.has_payment_keywords = True

    # Auth keywords
    auth_patterns = r"\b(firebase|supabase|auth0|cognito|oauth|jwt|session|passport|keycloak|okta)\b"
    if re.search(auth_patterns, text_content, re.IGNORECASE):
        signals.has_auth_keywords = True

    # Database keywords
    db_patterns = r"\b(postgres|mysql|mongodb|redis|sqlite|dynamodb|firestore|prisma|sequelize|typeorm|sqlalchemy|diesel|gorm)\b"
    if re.search(db_patterns, text_content, re.IGNORECASE):
        signals.has_database = True

    # CLI tool detection
    cli_patterns = r"\b(argparse|click|typer|commander|yargs|clap|cobra|structopt|cli|command[_-]?line)\b"
    if re.search(cli_patterns, text_content, re.IGNORECASE):
        signals.has_cli = True

    # Web frontend detection
    frontend_patterns = r"\b(react|vue|angular|svelte|nextjs|nuxt|gatsby|remix|vite|webpack|tailwind|bootstrap)\b"
    if re.search(frontend_patterns, text_content, re.IGNORECASE):
        signals.has_web_frontend = True

    # Saudi/regional hints
    saudi_patterns = r"\b(saudi|ksa|riyadh|jeddah|dammam|makkah|madinah)\b"
    if re.search(saudi_patterns, text_content, re.IGNORECASE):
        signals.has_saudi_hints = True

    # Arabic language detection
    arabic_pattern = r"[\u0600-\u06FF]"
    if re.search(arabic_pattern, text_content):
        signals.has_arabic = True

    return signals


README_MAX_BYTES = 60 * 1024  # 60KB limit for README scanning

# Files to scan for keyword detection
TEXT_FILES = [
    "README.md", "README", "README.rst",
    # Node/JS
    "package.json",
    # Python
    "pyproject.toml", "requirements.txt", "setup.py", "Pipfile",
    # Go
    "go.mod",
    # Rust
    "Cargo.toml",
    # Java
    "pom.xml", "build.gradle",
    # Ruby
    "Gemfile",
    # PHP
    "composer.json",
    # Flutter
    "pubspec.yaml",
]


def _collect_text(directory: Path) -> str:
    content = []

    for fname in TEXT_FILES:
        fpath = directory / fname
        if fpath.exists():
            try:
                text = fpath.read_text(errors="ignore")
                # Limit README to 60KB for performance
                if fname.startswith("README"):
                    text = text[:README_MAX_BYTES]
                content.append(text)
            except Exception:
                pass

    return "\n".join(content)
