"""UI module for Bootsec CLI.

Rich-based rendering with automatic fallback to plain text.
Single responsibility: presentation only.
"""
from __future__ import annotations

import os
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Any

# UI mode constants
UI_RICH = "rich"
UI_PLAIN = "plain"

# Score bar width
BAR_WIDTH = 24

# Severity colors (Rich markup)
SEVERITY_COLORS = {
    "high": "red",
    "med": "yellow",
    "low": "dim",
}


def _should_use_plain() -> bool:
    """Detect if we should use plain output."""
    # NO_COLOR standard
    if os.environ.get("NO_COLOR"):
        return True
    # Dumb terminal
    if os.environ.get("TERM") == "dumb":
        return True
    # Not a TTY (piping)
    if not sys.stdout.isatty():
        return True
    return False


def get_ui_mode(force_plain: bool = False) -> str:
    """Get the UI mode to use."""
    if force_plain:
        return UI_PLAIN
    if _should_use_plain():
        return UI_PLAIN
    return UI_RICH


def _get_console(ui_mode: str) -> "Any":
    """Get a Rich Console or None for plain mode."""
    if ui_mode == UI_PLAIN:
        return None
    try:
        from rich.console import Console
        return Console(highlight=False)
    except ImportError:
        return None


def score_bar(score: int) -> str:
    """Generate a score bar (24 chars, no colors)."""
    filled = int((score / 100) * BAR_WIDTH)
    filled = max(0, min(BAR_WIDTH, filled))
    empty = BAR_WIDTH - filled
    return "█" * filled + "░" * empty


def score_bar_rich(score: int) -> str:
    """Generate a Rich-formatted score bar with colors."""
    filled = int((score / 100) * BAR_WIDTH)
    filled = max(0, min(BAR_WIDTH, filled))
    empty = BAR_WIDTH - filled

    # Color based on score
    if score >= 75:
        color = "green"
    elif score >= 50:
        color = "yellow"
    else:
        color = "red"

    return f"[{color}]{'█' * filled}[/{color}][dim]{'░' * empty}[/dim]"


def print_header(ui_mode: str, title: str = "bootsec") -> None:
    """Print header."""
    console = _get_console(ui_mode)
    if console:
        from rich.panel import Panel
        console.print(Panel(f"[bold]{title}[/bold]", expand=False, border_style="dim"))
    else:
        print(f"\n  -- {title} --\n")


def print_help(ui_mode: str) -> None:
    """Print help screen."""
    help_text = """bootsec — security baseline for your project

  Free:
    go      Apply baseline docs + commit guard
    guard   Block commits with issues (pre-commit)

  Pro ($3.99/year):
    check   Audit your repo + show score
    scan    OSV vulnerability scan
    deps    Dependency audit (npm/pip/cargo)
    sbom    Software Bill of Materials
    ai      AI-friendly fix prompt
    peek    Preview what go would create

  bootsec pro       Show license status
  bootsec activate  Activate license key"""

    console = _get_console(ui_mode)
    if console:
        from rich.panel import Panel
        console.print(Panel(help_text, title="[bold]Help[/bold]", expand=False, border_style="blue"))
    else:
        print()
        for line in help_text.split("\n"):
            print(f"  {line}")
        print()


def print_score(
    ui_mode: str,
    mode: str,
    score: int,
    high: int,
    med: int,
    low: int,
    findings: list[tuple[str, str, int]],
    scope_line: str | None = None,
) -> None:
    """Print check output with score and findings."""
    console = _get_console(ui_mode)

    if console:
        _print_score_rich(console, mode, score, high, med, low, findings, scope_line)
    else:
        _print_score_plain(mode, score, high, med, low, findings, scope_line)


def _print_score_rich(
    console: "Any",
    mode: str,
    score: int,
    high: int,
    med: int,
    low: int,
    findings: list[tuple[str, str, int]],
    scope_line: str | None,
) -> None:
    """Rich version of score output."""
    from rich.table import Table
    from rich.panel import Panel

    # Header
    console.print(Panel("[bold]bootsec[/bold]", expand=False, border_style="dim"))

    # Mode line
    console.print(f"  [dim]mode:[/dim] {mode}")
    if scope_line:
        console.print(f"  [dim]{scope_line}[/dim]")

    # Score bar
    bar = score_bar_rich(score)
    console.print(f"\n  {score}/100  [{bar}]")

    # H/M/L counts with colors
    h_str = f"[red]H:{high}[/red]" if high > 0 else f"[dim]H:{high}[/dim]"
    m_str = f"[yellow]M:{med}[/yellow]" if med > 0 else f"[dim]M:{med}[/dim]"
    l_str = f"[dim]L:{low}[/dim]"
    console.print(f"  {h_str}  {m_str}  {l_str}")

    # Top 5 findings table
    if findings:
        console.print()
        table = Table(show_header=True, header_style="bold", box=None, padding=(0, 1))
        table.add_column("", width=1)  # Severity marker
        table.add_column("Finding", no_wrap=False)
        table.add_column("Fix", style="dim")

        for name, severity, points in findings[:5]:
            color = SEVERITY_COLORS.get(severity, "dim")
            marker = "!" if severity == "high" else "~" if severity == "med" else "-"
            fix = "bootsec go" if severity == "high" else "bootsec go --ci"
            table.add_row(f"[{color}]{marker}[/{color}]", f"[{color}]{name}[/{color}]", fix)

        console.print(table)

    console.print()


def _print_score_plain(
    mode: str,
    score: int,
    high: int,
    med: int,
    low: int,
    findings: list[tuple[str, str, int]],
    scope_line: str | None,
) -> None:
    """Plain text version of score output."""
    print("\n  -- bootsec --\n")
    print(f"  mode: {mode}")
    if scope_line:
        print(f"  {scope_line}")

    bar = score_bar(score)
    print(f"\n  {score}/100  [{bar}]")
    print(f"  H:{high}  M:{med}  L:{low}")

    if findings:
        print()
        for name, severity, points in findings[:5]:
            marker = "!" if severity == "high" else "~" if severity == "med" else "-"
            print(f"    {marker} {name}")

    print()


def print_guard_failure(
    ui_mode: str,
    mode: str,
    score: int,
    high_findings: list[tuple[str, str, int]],
    scope_line: str | None = None,
) -> None:
    """Print guard failure output."""
    console = _get_console(ui_mode)

    if console:
        from rich.panel import Panel

        console.print(Panel("[bold red]guard[/bold red]", expand=False, border_style="red"))
        console.print(f"  [dim]mode:[/dim] {mode}")
        if scope_line:
            console.print(f"  [dim]{scope_line}[/dim]")

        bar = score_bar_rich(score)
        console.print(f"\n  {score}/100  [{bar}]")

        console.print()
        for name, severity, points in high_findings[:2]:
            console.print(f"  [red]![/red] [red]{name}[/red]")

        console.print()
        console.print("  [bold]Fix and try again[/bold]")
        console.print("  [dim]Run:[/dim] bootsec go")
        console.print()
    else:
        print("\n  -- guard --\n")
        print(f"  mode: {mode}")
        if scope_line:
            print(f"  {scope_line}")

        bar = score_bar(score)
        print(f"\n  {score}/100  [{bar}]")

        print()
        for name, severity, points in high_findings[:2]:
            print(f"    ! {name}")

        print()
        print("  Fix and try again")
        print("  Run: bootsec go")
        print()


def print_guard_success(ui_mode: str) -> None:
    """Print guard success - ONLY place for 🐥."""
    # Always the same, regardless of UI mode
    print("All good ✅  🐥")


def print_ai_cta(ui_mode: str) -> None:
    """Print AI CTA (no emojis)."""
    console = _get_console(ui_mode)

    if console:
        console.print()
        console.print("  [dim]Wanna toss this to your AI agent?[/dim]")
        console.print("  [bold]→ bootsec ai[/bold]")
        console.print()
    else:
        print()
        print("  Wanna toss this to your AI agent?")
        print("  → bootsec ai")
        print()


def print_go_summary(
    ui_mode: str,
    created: list[str],
    updated: list[str],
    skipped: list[str],
    show_next: bool = False,
) -> None:
    """Print go command summary."""
    console = _get_console(ui_mode)

    if console:
        _print_go_rich(console, created, updated, skipped, show_next)
    else:
        _print_go_plain(created, updated, skipped, show_next)

    # Support message
    print("  If Bootsec saved you time: buymeacoffee.com/batdown")
    print()


def _print_go_rich(
    console: "Any",
    created: list[str],
    updated: list[str],
    skipped: list[str],
    show_next: bool,
) -> None:
    """Rich version of go summary."""
    from rich.table import Table
    from rich.panel import Panel

    # Summary counts
    console.print(Panel("[bold]bootsec go[/bold]", expand=False, border_style="green"))

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Label", style="dim")
    table.add_column("Count", justify="right")

    table.add_row("Created", f"[green]{len(created)}[/green]")
    table.add_row("Updated", f"[yellow]{len(updated)}[/yellow]")
    if skipped:
        table.add_row("Skipped", f"[dim]{len(skipped)}[/dim]")

    console.print(table)
    console.print()

    # List files (max 12)
    all_files = [(f, "green", "[+]") for f in created] + [(f, "yellow", "[~]") for f in updated]
    for path, color, marker in all_files[:12]:
        console.print(f"  [{color}]{marker}[/{color}] {path}")

    if len(all_files) > 12:
        console.print(f"  [dim]... and {len(all_files) - 12} more[/dim]")

    console.print()
    console.print("[green]All good ✅  🐥[/green]")

    if show_next:
        console.print()
        console.print("[dim]next:[/dim] pre-commit install")

    console.print()


def _print_go_plain(
    created: list[str],
    updated: list[str],
    skipped: list[str],
    show_next: bool,
) -> None:
    """Plain version of go summary."""
    print("\n  -- bootsec go --\n")

    print(f"  Created: {len(created)}")
    print(f"  Updated: {len(updated)}")
    if skipped:
        print(f"  Skipped: {len(skipped)}")

    print()

    all_files = [(f, "[+]") for f in created] + [(f, "[~]") for f in updated]
    for path, marker in all_files[:12]:
        print(f"    {marker} {path}")

    if len(all_files) > 12:
        print(f"    ... and {len(all_files) - 12} more")

    print()
    print("  All good ✅  🐥")

    if show_next:
        print()
        print("  next: pre-commit install")

    print()


def print_peek_summary(
    ui_mode: str,
    detected: str,
    packs: list[str],
    created: list[str],
    updated: list[str],
) -> None:
    """Print peek preview."""
    console = _get_console(ui_mode)

    if console:
        from rich.panel import Panel

        console.print(Panel("[bold]bootsec peek[/bold]", expand=False, border_style="blue"))
        console.print(f"  [dim]Detected:[/dim] {detected}")
        console.print(f"  [dim]Packs:[/dim] {', '.join(packs)}")
        console.print()

        for path in created:
            console.print(f"  [green][+][/green] {path}")
        for path in updated:
            console.print(f"  [yellow][~][/yellow] {path}")

        console.print()
        console.print(f"  [dim]Plan: {len(created)}+ {len(updated)}~[/dim]")
        console.print()
    else:
        print("\n  -- peek --\n")
        print(f"  Detected: {detected}")
        print(f"  Packs: {', '.join(packs)}")
        print()

        for path in created:
            print(f"  [+] {path}")
        for path in updated:
            print(f"  [~] {path}")

        print()
        print(f"  Plan: {len(created)}+ {len(updated)}~")
        print()
