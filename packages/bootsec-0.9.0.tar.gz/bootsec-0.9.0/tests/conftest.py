"""Pytest configuration."""
import pytest


@pytest.fixture(autouse=True)
def reset_cwd(tmp_path, monkeypatch):
    """Reset working directory after each test."""
    original_cwd = tmp_path
    yield
