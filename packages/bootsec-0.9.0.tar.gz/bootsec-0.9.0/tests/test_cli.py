"""Tests for bootsec free CLI."""
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest
from bootsec.cli import main, cmd_go, cmd_guard, cmd_peek


class TestGoCommand:
    """Test bootsec go command."""

    def test_go_creates_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            os.chdir(tmpdir)
            Path(tmpdir, "package.json").write_text('{"name": "test"}')

            with patch("sys.argv", ["bootsec", "go"]):
                result = main()

            assert result == 0
            assert (Path(tmpdir) / ".gitignore").exists()
            assert (Path(tmpdir) / "SECURITY.md").exists()

    def test_go_with_ci_flag(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            os.chdir(tmpdir)
            Path(tmpdir, "package.json").write_text('{"name": "test"}')

            with patch("sys.argv", ["bootsec", "go", "--ci"]):
                result = main()

            assert result == 0
            assert (Path(tmpdir) / ".github" / "workflows" / "security.yml").exists()


class TestGuardCommand:
    """Test bootsec guard command."""

    def test_guard_passes_clean_repo(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            os.chdir(tmpdir)
            (Path(tmpdir) / ".gitignore").write_text(".env\n*.key")
            (Path(tmpdir) / "SECURITY.md").write_text("# Security\n\nReport issues.")
            (Path(tmpdir) / ".pre-commit-config.yaml").write_text("repos: []")

            with patch("sys.argv", ["bootsec", "guard"]):
                result = main()

            assert result == 0

    def test_guard_fails_missing_gitignore(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            os.chdir(tmpdir)

            with patch("sys.argv", ["bootsec", "guard"]):
                result = main()

            assert result == 1


class TestPeekCommand:
    """Test bootsec peek command."""

    def test_peek_shows_files(self, capsys):
        with tempfile.TemporaryDirectory() as tmpdir:
            os.chdir(tmpdir)
            Path(tmpdir, "package.json").write_text('{"name": "test"}')

            with patch("sys.argv", ["bootsec", "peek"]):
                result = main()

            assert result == 0
            out = capsys.readouterr().out
            assert "Would create" in out


class TestProUpsell:
    """Test Pro command upsells."""

    def test_check_shows_upsell(self, capsys):
        with patch("sys.argv", ["bootsec", "check"]):
            result = main()

        out = capsys.readouterr().out
        assert "Pro" in out or "pro" in out
        assert result == 0

    def test_scan_shows_upsell(self, capsys):
        with patch("sys.argv", ["bootsec", "scan"]):
            result = main()

        out = capsys.readouterr().out
        assert "Pro" in out or "pro" in out

    def test_deps_shows_upsell(self, capsys):
        with patch("sys.argv", ["bootsec", "deps"]):
            result = main()

        out = capsys.readouterr().out
        assert "Pro" in out or "pro" in out


class TestHelp:
    """Test help command."""

    def test_help_shows_commands(self, capsys):
        with patch("sys.argv", ["bootsec", "help"]):
            main()

        out = capsys.readouterr().out
        assert "go" in out
        assert "guard" in out
        assert "Pro" in out or "bootsec.dev" in out


class TestVersion:
    """Test version command."""

    def test_version(self, capsys):
        with patch("sys.argv", ["bootsec", "--version"]):
            main()

        out = capsys.readouterr().out
        assert "0.8.0" in out
