# Maaş Dönüşüm Kütüphanesi

Türkiye'deki bordro hesaplamalarını basitleştiren Python kütüphanesi. Brüt maaştan net maaşa, net maaştan brüt maaşa dönüşüm yapmanızı sağlar.

## 🚀 Özellikler

- ✅ **Brüt → Net** dönüşümü (aylık ve yıllık)
- ✅ **Net → Brüt** dönüşümü (aylık ve yıllık)
- ✅ Kademeli gelir vergisi hesaplama
- ✅ Asgari ücret istisnası desteği
- ✅ **30+ farklı sigorta tipi** desteği (Normal çalışan, Emekli, Çırak, Stajyer, vs.)
- ✅ Engelli çalışan indirimleri (1., 2., 3. derece)
- ✅ BES (Bireysel Emeklilik Sistemi) kesintisi
- ✅ 2026 güncel parametreleri

## Kurulum

```bash
pip install pandas
```

Kütüphaneyi projenize dahil edin:

```python
from bordro import brut_net_aylik, brut_net_yillik, net_brut_aylik, net_brut_yillik
```

## Parametreler

### Sigorta Tipi Kodları (Öne Çıkanlar)

| Kod | Açıklama | SGK (İşçi) | İşsizlik (İşçi) | Vergi Muaf |
|-----|----------|------------|-----------------|------------|
| **"00"** | SGK'ya Tabi Değil | %0 | %0 | Hayır |
| **"01"** | Normal Çalışan (En Yaygın) | %14 | %1 | Hayır |
| **"02"** | Emekli (SGDP) | %7.5 | %0 | Hayır |
| **"07"** | Çırak / Öğrenci | %0 | %0 | **Evet** |
| **"13"** | İşsizliksiz Normal | %14 | %0 | Hayır |
| **"19"** | Hükümlü ve Tutuklu | %0 | %0 | **Evet** |
| **"22"** | Stajyer Öğrenci | %0 | %0 | **Evet** |
| **"25"** | İŞKUR Kursiyer | %0 | %0 | **Evet** |

**Not:** Toplam 30+ sigorta tipi mevcuttur. Tüm liste için `2026.json` dosyasına bakınız.

### Engellilik Dereceleri

| Kod | Açıklama | Aylık İndirim (2026) |
|-----|----------|----------------------|
| **"0"** | Engelli değil | 0 TL |
| **"1"** | 1. Derece | 12,000 TL |
| **"2"** | 2. Derece | 7,000 TL |
| **"3"** | 3. Derece | 3,000 TL |

### 2026 Güncel Parametreler

| Parametre | Değer |
|-----------|-------|
| **Asgari Ücret (Brüt)** | 33,030 TL |
| **SGK Tavanı** | 297,270 TL (Asgari ücret × 9) |
| **Damga Vergisi** | %0.759 |
| **BES Varsayılan Oran** | %3 |

### Gelir Vergisi Dilimleri (2026)

| Matrah Aralığı | Vergi Oranı |
|----------------|-------------|
| 0 - 190,000 TL | %15 |
| 190,000 - 400,000 TL | %20 |
| 400,000 - 1,500,000 TL | %27 |
| 1,500,000 - 5,300,000 TL | %35 |
| 5,300,000 TL üzeri | %40 |

## 📁 Proje Yapısı

```
proje/
│
├── core.py                    # Ana modül (hesaplama motoru)
├── parametreler/              # Yıllık parametre dosyaları
│   └── 2026.json             # 2026 yılı parametreleri
│                             # (Asgari ücret, vergiler, sigorta tipleri vb.)
└── README.md                 # Bu dosya
```

## 💡 Kullanım Örnekleri

### Örnek 1: Normal Çalışan vs Emekli Çalışan

```python
# Normal çalışan
normal = brut_net_aylik(60000, sigorta_tipi_kodu="01")
print(f"Normal Çalışan Net: {normal['net']:.2f} TL")
print(f"SGK: {normal['sgk_isci']:.2f} TL")

# Emekli çalışan (daha az SGK kesilir)
emekli = brut_net_aylik(60000, sigorta_tipi_kodu="02")
print(f"Emekli Net: {emekli['net']:.2f} TL")
print(f"SGK: {emekli['sgk_isci']:.2f} TL")
print(f"Fark: {emekli['net'] - normal['net']:.2f} TL")
```

### Örnek 2: Farklı Aylardaki Net Maaş Farkı (Kümülatif Vergi)

```python
# Ocak ayı
ocak = brut_net_aylik(70000, ay=1)
print(f"Ocak Net: {ocak['net']:.2f} TL")

# Haziran ayı
haziran = brut_net_aylik(70000, ay=6)
print(f"Haziran Net: {haziran['net']:.2f} TL")

# Aralık ayı (kümülatif vergi nedeniyle daha düşük)
aralik = brut_net_aylik(70000, ay=12)
print(f"Aralık Net: {aralik['net']:.2f} TL")

print(f"Ocak-Aralık Farkı: {ocak['net'] - aralik['net']:.2f} TL")
```

### Örnek 3: Engelli Çalışan Hesaplaması

```python
# Normal çalışan
normal = brut_net_aylik(50000)

# 1. derece engelli (12,000 TL indirim)
engelli_1 = brut_net_aylik(50000, engel_derecesi="1")

# 2. derece engelli (7,000 TL indirim)
engelli_2 = brut_net_aylik(50000, engel_derecesi="2")

# 3. derece engelli (3,000 TL indirim)
engelli_3 = brut_net_aylik(50000, engel_derecesi="3")

print(f"Normal Net: {normal['net']:.2f} TL")
print(f"1. Derece Net: {engelli_1['net']:.2f} TL (+{engelli_1['net'] - normal['net']:.2f} TL)")
print(f"2. Derece Net: {engelli_2['net']:.2f} TL (+{engelli_2['net'] - normal['net']:.2f} TL)")
print(f"3. Derece Net: {engelli_3['net']:.2f} TL (+{engelli_3['net'] - normal['net']:.2f} TL)")
```

### Örnek 4: BES ile Vergi Avantajı

```python
# BES olmadan
bes_yok = brut_net_aylik(80000, bes=False)

# %3 BES ile
bes_3 = brut_net_aylik(80000, bes=True, bes_orani=0.03)

print(f"BES Yok - Net: {bes_yok['net']:.2f} TL")
print(f"BES %3 - Net: {bes_3['net']:.2f} TL, BES: {bes_3['bes']:.2f} TL")
```

---

**Not**: Bu kütüphane **2026 yılı** Türkiye bordro mevzuatına göre hazırlanmıştır. Yeni yıllarda `parametreler/` klasöründe yeni JSON dosyası oluşturarak güncelleyebilirsiniz.