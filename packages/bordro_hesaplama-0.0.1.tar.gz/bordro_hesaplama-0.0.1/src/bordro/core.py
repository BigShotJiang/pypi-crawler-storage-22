"""
MAAŞ DÖNÜŞÜM ÇEKİRDEK MODÜLÜ (CORE)
- Brütten Nete & Netten Brüte Çeviri
- Aylık ve Yıllık Hesaplama
"""

import json
import os
import pandas as pd
from typing import Dict, List, Union, Optional


# PARAMETRE YÖNETİMİ

class BordroParametreleri:
    def __init__(self, yil: int = 2026):
        self.veriler = self._json_yukle(yil)

        self.ASGARI_UCRET_BRUT = self.veriler["ASGARI_UCRET_BRUT"]
        # Tavanı hesapla
        self.SGK_TAVAN = self.ASGARI_UCRET_BRUT * self.veriler["SGK_TAVAN_KATSAYI"]

        self.AYLAR = self.veriler["AYLAR"]
        self.ORAN_BES = self.veriler["ORANLAR"]["BES"]
        self.ORAN_DAMGA = self.veriler["ORANLAR"]["DAMGA"]

        # Sigorta Tipleri (Sadece işçi paylarını alacağız)
        self.SIGORTA_TIPLERI = self.veriler["SIGORTA_TIPLERI"]
        self.ENGELLILIK = self.veriler["ENGELLILIK_INDIRIMLERI"]

        # Vergi dilimlerindeki null değerini sonsuzluğa (inf) çevir
        dilimler = self.veriler["GELIR_VERGISI_DILIMLERI"]
        if dilimler[-1][0] is None: dilimler[-1][0] = float('inf')
        self.GELIR_VERGISI_DILIMLERI = dilimler

    def _json_yukle(self, yil: int) -> Dict:
        base_path = os.path.dirname(os.path.abspath(__file__))
        json_path = os.path.join(base_path, "parametreler", f"{yil}.json")
        if not os.path.exists(json_path):
            raise FileNotFoundError(f"Parametre dosyası bulunamadı: {json_path}")
        with open(json_path, 'r', encoding='utf-8') as f:
            return json.load(f)


# Global Sabitler
SABITLER = BordroParametreleri(2026)



# YARDIMCI FONKSİYONLAR

def yuvarla(sayi: float) -> float:
    """Para birimi yuvarlama (2 hane)"""
    return round(float(sayi or 0), 2)


def gelir_vergisi_hesapla(matrah: float, kumulatif_matrah: float = 0) -> float:
    """Kümülatif matraha göre dilimli gelir vergisi hesaplar."""
    toplam_vergi = 0
    hesaplanacak = matrah
    gecici_kumulatif = kumulatif_matrah

    for sinir, oran in SABITLER.GELIR_VERGISI_DILIMLERI:
        if gecici_kumulatif >= sinir:
            continue

        kalan_limit = sinir - gecici_kumulatif
        dilim_ici = min(hesaplanacak, kalan_limit)

        toplam_vergi += dilim_ici * oran
        hesaplanacak -= dilim_ici
        gecici_kumulatif += dilim_ici

        if hesaplanacak <= 0:
            break

    return toplam_vergi



# ANA FONKSİYON: BRÜT → NET (AYLIK)

def brut_net_aylik(brut_maas: float,
                   ay: int = 1,
                   devreden_matrah: Optional[float] = None,
                   sigorta_tipi_kodu: str = "01",
                   engel_derecesi: str = "0",
                   bes: bool = False,
                   bes_orani: Optional[float] = None) -> Dict:
    """
    Verilen brüt maaşın o ayki net karşılığını hesaplar.
    """

    # Parametre Hazırlığı
    ay_ismi = SABITLER.AYLAR[ay - 1]
    sigorta_bilgisi = SABITLER.SIGORTA_TIPLERI.get(sigorta_tipi_kodu, SABITLER.SIGORTA_TIPLERI["01"])
    engelli_indirim = SABITLER.ENGELLILIK.get(str(engel_derecesi), 0)

    # Devreden Matrah Yoksa Hesapla (Önceki ayları simüle et)
    if devreden_matrah is None:
        if ay == 1:
            devreden_matrah = 0
        else:
            kumulatif = 0
            for i in range(1, ay):
                onceki = brut_net_aylik(brut_maas, i, kumulatif,
                                        sigorta_tipi_kodu, engel_derecesi, bes, bes_orani)
                kumulatif = onceki['kumulatif_matrah']
            devreden_matrah = kumulatif

    # HESAPLAMA

    # 1. SGK ve İşsizlik (İşçi Payı)
    sgk_matrah = min(brut_maas, SABITLER.SGK_TAVAN)
    sgk_isci = yuvarla(sgk_matrah * sigorta_bilgisi["Isci_SGK"])
    issizlik_isci = yuvarla(sgk_matrah * sigorta_bilgisi["Isci_Iss"])

    # Gelir Vergisi
    gv_matrah = max(0, brut_maas - sgk_isci - issizlik_isci - engelli_indirim)

    if sigorta_bilgisi["Vergi_Muaf"]:
        odenecek_gv = 0
    else:
        # Asgari Ücret İstisnası Hesabı
        asgari_brut = SABITLER.ASGARI_UCRET_BRUT
        asgari_sgk = yuvarla(asgari_brut * 0.14)  # Standart %14
        asgari_iss = yuvarla(asgari_brut * 0.01)  # Standart %1
        asgari_gv_matrah = asgari_brut - asgari_sgk - asgari_iss

        asgari_kumulatif = asgari_gv_matrah * (ay - 1)

        # Vergi Hesapla
        gelir_vergisi = yuvarla(gelir_vergisi_hesapla(gv_matrah, devreden_matrah))
        istisna_gv = yuvarla(gelir_vergisi_hesapla(asgari_gv_matrah, asgari_kumulatif))

        # İstisnayı Düş
        odenecek_gv = max(0, gelir_vergisi - istisna_gv)

    # Damga Vergisi
    damga_vergisi = yuvarla(brut_maas * SABITLER.ORAN_DAMGA)
    asgari_damga = yuvarla(SABITLER.ASGARI_UCRET_BRUT * SABITLER.ORAN_DAMGA)
    odenecek_dv = max(0, damga_vergisi - asgari_damga)

    # BES Kesintisi
    # Brüt maaş değil, SGK matrahı kullanılır

    bes_tutari = 0
    if bes:
        kullanilacak_oran = bes_orani if bes_orani is not None else SABITLER.ORAN_BES
        bes_tutari = yuvarla(sgk_matrah * kullanilacak_oran)

    # NET MAAŞ
    toplam_kesinti = sgk_isci + issizlik_isci + odenecek_gv + odenecek_dv + bes_tutari
    net_maas = yuvarla(brut_maas - toplam_kesinti)

    return {
        'ay': ay_ismi,
        'brut': brut_maas,
        'net': net_maas,
        'kumulatif_matrah': devreden_matrah + gv_matrah,
        'sgk_isci': sgk_isci,
        'issizlik_isci': issizlik_isci,
        'gv': odenecek_gv,
        'dv': odenecek_dv,
        'bes': bes_tutari
    }


# ANA FONKSİYON: BRÜT → NET (YILLIK LİSTE)

def brut_net_yillik(brut_maas: float,
                    sigorta_tipi_kodu: str = "01",
                    engel_derecesi: str = "0",
                    bes: bool = False,
                    bes_orani: Optional[float] = None,
                    dataframe: bool = True) -> Union[pd.DataFrame, List[Dict]]:
    """Brüt maaşın 12 aylık dökümünü verir."""
    sonuclar = []
    kumulatif = 0

    for ay in range(1, 13):
        sonuc = brut_net_aylik(brut_maas, ay, kumulatif,
                               sigorta_tipi_kodu, engel_derecesi, bes, bes_orani)
        sonuclar.append(sonuc)
        kumulatif = sonuc['kumulatif_matrah']

    if dataframe:
        df = pd.DataFrame(sonuclar)
        toplam = df.select_dtypes(include=['number']).sum()
        toplam['ay'] = 'TOPLAM'
        df.loc['TOPLAM'] = toplam
        return df

    return sonuclar


# TERS FONKSİYON: NET → BRÜT (AYLIK)

def net_brut_aylik(hedef_net: float,
                   ay: int = 1,
                   devreden_matrah: float = 0,
                   sigorta_tipi_kodu: str = "01",
                   engel_derecesi: str = "0",
                   bes: bool = False,
                   bes_orani: Optional[float] = None) -> Dict:
    """
    İstenilen NET maaşı elde etmek için gereken BRÜT maaşı bulur.
    (Deneme-Yanılma / Bisection Yöntemi ile çalışır)
    BES varsa, hedefimiz (Cepteki Net + BES Kesintisi) toplamıdır.
    Böylece BES işveren maliyeti olmaz, çalışanın netinden düşer.
    """

    alt = hedef_net
    ust = hedef_net * 3.0  # Tahmini üst sınır

    # 50 adımda doğru sonuca yaklaş
    for _ in range(50):
        orta_brut = (alt + ust) / 2

        sonuc = brut_net_aylik(orta_brut, ay, devreden_matrah,
                               sigorta_tipi_kodu, engel_derecesi, bes, bes_orani)


        elimize_gecen_deger = sonuc['net']
        if bes:
            elimize_gecen_deger += sonuc['bes']

        fark = elimize_gecen_deger - hedef_net
        # ---------------------------

        if abs(fark) < 0.01:  # 1 kuruş hassasiyet
            return sonuc

        if fark < 0:  # Hesaplanan az geldiyse brütü artır
            alt = orta_brut
        else:  # Hesaplanan çok geldiyse brütü azalt
            ust = orta_brut

    return sonuc


# TERS FONKSİYON: NET → BRÜT (YILLIK)

def net_brut_yillik(hedef_net: float,
                    sigorta_tipi_kodu: str = "01",
                    engel_derecesi: str = "0",
                    bes: bool = False,
                    bes_orani: Optional[float] = None,
                    dataframe: bool = True) -> Union[pd.DataFrame, List[Dict]]:
    """Her ay ele o NET paranın geçmesi için gereken Brütleri hesaplar."""

    sonuclar = []
    kumulatif = 0

    for ay in range(1, 13):
        sonuc = net_brut_aylik(hedef_net, ay, kumulatif,
                               sigorta_tipi_kodu, engel_derecesi, bes, bes_orani)
        sonuclar.append(sonuc)
        kumulatif = sonuc['kumulatif_matrah']

    if dataframe:
        df = pd.DataFrame(sonuclar)
        toplam = df.select_dtypes(include=['number']).sum()
        toplam['ay'] = 'TOPLAM'
        df.loc['TOPLAM'] = toplam
        return df

    return sonuclar