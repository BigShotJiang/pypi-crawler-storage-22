import json
import multiprocessing
import os
import shutil
import threading
import time
from dataclasses import asdict, dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple, Union


def _sglang_launch_server_worker(args_payload: Dict[str, Any], kwargs_dict: Dict[str, Any]) -> None:
    import importlib as _importlib
    import inspect as _inspect

    http_server_mod = _importlib.import_module("sglang.srt.entrypoints.http_server")
    server_args_mod = _importlib.import_module("sglang.srt.server_args")

    try:
        signature = _inspect.signature(server_args_mod.ServerArgs)
        parameters = signature.parameters
        accepts_kwargs = any(p.kind == p.VAR_KEYWORD for p in parameters.values())
        if not accepts_kwargs:
            allowed = {
                name
                for name, param in parameters.items()
                if name != "self" and param.kind in (param.POSITIONAL_OR_KEYWORD, param.KEYWORD_ONLY)
            }
            args_payload = {k: v for k, v in args_payload.items() if k in allowed}
    except Exception:
        pass

    server_args_obj = server_args_mod.ServerArgs(**args_payload)
    http_server_mod.launch_server(server_args_obj, **kwargs_dict)

from ... import terminal
from ...abstractions.base.container import Container
from ...abstractions.base.runner import ASGI_DEPLOYMENT_STUB_TYPE, ASGI_SERVE_STUB_TYPE
from ...abstractions.endpoint import ASGI
from ...abstractions.image import Image
from ...abstractions.volume import CloudBucket, Volume
from ...channel import with_grpc_error_handling
from ...clients.endpoint import StartEndpointServeRequest, StartEndpointServeResponse
from ...clients.gateway import DeployStubRequest, DeployStubResponse
from ...config import ConfigContext
from ...type import Autoscaler, GpuType, GpuTypeAlias, QueueDepthAutoscaler

DEFAULT_SGLANG_CACHE_DIR = "./sglang_cache"


@dataclass
class SGLangArgs:
    """
    The configuration for the SGLang HTTP server. These map to the arguments in
    sglang.srt.server_args.ServerArgs. Additional or newer arguments can be passed
    via `extra_args`.
    """

    model_path: str = "qwen/qwen2.5-0.5b-instruct"
    model_source: str = "modelscope"
    model_name: Optional[str] = None
    auto_download: bool = True
    tokenizer_path: Optional[str] = None
    host: str = "0.0.0.0"
    port: int = 30000
    trust_remote_code: bool = False
    dtype: str = "auto"
    kv_cache_dtype: str = "auto"
    quantization: Optional[str] = None
    context_length: Optional[int] = None
    is_embedding: bool = False
    revision: Optional[str] = None
    download_dir: Optional[str] = DEFAULT_SGLANG_CACHE_DIR
    served_model_name: Optional[str] = None
    chat_template: Optional[str] = None
    api_key: Optional[str] = None
    json_model_override_args: str = "{}"
    preferred_sampling_params: Optional[str] = None
    lora_paths: Optional[List[str]] = None
    enable_lora: Optional[bool] = None
    max_lora_rank: Optional[int] = None
    lora_target_modules: Optional[str] = None
    mem_fraction_static: Optional[float] = None
    max_running_requests: Optional[int] = None
    max_total_tokens: Optional[int] = None
    chunked_prefill_size: Optional[int] = None
    max_prefill_tokens: Optional[int] = None
    schedule_policy: str = "fcfs"
    schedule_conservativeness: float = 1.0
    stream_interval: int = 1
    stream_output: bool = False
    random_seed: Optional[int] = None
    tensor_parallel_size: int = 1
    pipeline_parallel_size: int = 1
    data_parallel_size: int = 1
    log_level: str = "info"
    log_requests: bool = False
    enable_metrics: bool = False
    tool_call_parser: Optional[str] = None
    reasoning_parser: Optional[str] = None
    fastapi_root_path: str = ""
    extra_args: Optional[Dict[str, Any]] = None

    def to_server_args_kwargs(self) -> Dict[str, Any]:
        payload = {
            k: v
            for k, v in asdict(self).items()
            if k not in {"extra_args", "model_source", "auto_download"}
        }
        if "tensor_parallel_size" in payload:
            payload["tp_size"] = payload.pop("tensor_parallel_size")
        if "pipeline_parallel_size" in payload:
            payload["pp_size"] = payload.pop("pipeline_parallel_size")
        if "data_parallel_size" in payload:
            payload["dp_size"] = payload.pop("data_parallel_size")
        extra_args = self.extra_args or {}
        payload.update(extra_args)
        return {k: v for k, v in payload.items() if v is not None}


class SGLang(ASGI):
    """
    SGLang is a wrapper around the SGLang runtime that allows you to deploy it as an ASGI app.

    Parameters mirror the vLLM integration where possible.
    """

    def __init__(
        self,
        cpu: Union[int, float, str] = 1.0,
        memory: Union[int, str] = 128,
        gpu: Union[GpuTypeAlias, List[GpuTypeAlias]] = GpuType.NoGPU,
        gpu_count: int = 0,
        image: Image = Image(python_version="python3.11"),
        sglang_version: str = "0.5.7",
        workers: int = 1,
        concurrent_requests: int = 1,
        keep_warm_seconds: int = 60,
        max_pending_tasks: int = 100,
        timeout: int = 3600,
        authorized: bool = True,
        name: Optional[str] = None,
        volumes: Optional[List[Union[Volume, CloudBucket]]] = [],
        secrets: Optional[List[str]] = None,
        autoscaler: Autoscaler = QueueDepthAutoscaler(),
        sglang_args: Union[SGLangArgs, Dict[str, Any], Any] = SGLangArgs(),
    ):
        if isinstance(sglang_args, SGLangArgs) and sglang_args.download_dir == DEFAULT_SGLANG_CACHE_DIR:
            volumes.append(Volume(name="sglang_cache", mount_path=DEFAULT_SGLANG_CACHE_DIR))

        image = image.add_python_packages(
            [
                "fastapi",
                f"sglang=={sglang_version}",
                "modelscope",
            ]
        )
        image = image.add_commands(
            [
                "curl -fsSL https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.1-1_all.deb -o /tmp/cuda-keyring.deb && dpkg -i /tmp/cuda-keyring.deb && rm /tmp/cuda-keyring.deb",
                # 安装完整 CUDA 开发库 (PyTorch cpp_extension 编译需要 cusparse/cublas/cufft 等头文件)
                "apt-get update && apt-get install -y libnuma1 nvidia-cuda-toolkit ffmpeg cuda-libraries-dev-12-8 cuda-nvcc-12-8 && rm -rf /var/lib/apt/lists/*",
                # 创建 CUDA 软链接 (PyTorch cpp_extension 使用 CUDA_HOME)
                "ln -sf /usr/local/cuda-12.8 /usr/local/cuda",
                "ln -sf /usr/local/cuda/bin/nvcc /usr/local/bin/nvcc",
            ]
        )
        image = image.with_envs(
            "CUDA_HOME=/usr/local/cuda",
        )

        super().__init__(
            cpu=cpu,
            memory=memory,
            gpu=gpu,
            gpu_count=gpu_count,
            image=image,
            workers=workers,
            concurrent_requests=concurrent_requests,
            keep_warm_seconds=keep_warm_seconds,
            max_pending_tasks=max_pending_tasks,
            timeout=timeout,
            authorized=authorized,
            name=name,
            volumes=volumes,
            secrets=secrets,
            autoscaler=autoscaler,
        )

        self.sglang_args = sglang_args

    def __name__(self) -> str:
        return self.name or "sglang"

    def _build_server_args(self):
        try:
            from sglang.srt.server_args import ServerArgs
        except Exception as exc:  # pragma: no cover - handled at runtime in container
            raise RuntimeError("sglang is not available in the runtime image") from exc

        model_source, _, download_dir = self._resolve_source_settings()
        if model_source == "modelscope":
            os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
            os.environ.setdefault("HF_HUB_OFFLINE", "1")
            os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
            if download_dir:
                os.environ.setdefault("TRANSFORMERS_CACHE", download_dir)
                os.environ.setdefault("HF_HOME", download_dir)

        if isinstance(self.sglang_args, ServerArgs):
            return self.sglang_args

        if isinstance(self.sglang_args, SGLangArgs):
            payload = self.sglang_args.to_server_args_kwargs()
        elif isinstance(self.sglang_args, dict):
            payload = dict(self.sglang_args)
            if "tensor_parallel_size" in payload and "tp_size" not in payload:
                payload["tp_size"] = payload.pop("tensor_parallel_size")
            if "pipeline_parallel_size" in payload and "pp_size" not in payload:
                payload["pp_size"] = payload.pop("pipeline_parallel_size")
            if "data_parallel_size" in payload and "dp_size" not in payload:
                payload["dp_size"] = payload.pop("data_parallel_size")
        else:
            payload = dict(getattr(self.sglang_args, "__dict__", {}))

        if shutil.which("nvcc") is None:
            payload.setdefault("disable_cuda_graph", True)
            payload.setdefault("enable_torch_compile", False)

        payload = self._maybe_prepare_model_payload(payload)

        try:
            import inspect

            signature = inspect.signature(ServerArgs)
            parameters = signature.parameters
            accepts_kwargs = any(p.kind == p.VAR_KEYWORD for p in parameters.values())
            if not accepts_kwargs:
                allowed = {
                    name
                    for name, param in parameters.items()
                    if name != "self" and param.kind in (param.POSITIONAL_OR_KEYWORD, param.KEYWORD_ONLY)
                }
                unknown_keys = set(payload) - allowed
                if unknown_keys:
                    terminal.warn(
                        f"Removing unsupported SGLang ServerArgs fields: {', '.join(sorted(unknown_keys))}"
                    )
                payload = {k: v for k, v in payload.items() if k in allowed}
        except Exception:
            pass

        return ServerArgs(**payload)

    def _resolve_source_settings(self) -> Tuple[str, bool, Optional[str]]:
        if isinstance(self.sglang_args, SGLangArgs):
            model_source = (self.sglang_args.model_source or "modelscope").lower()
            auto_download = self.sglang_args.auto_download
            download_dir = self.sglang_args.download_dir
        elif isinstance(self.sglang_args, dict):
            model_source = (self.sglang_args.get("model_source") or "modelscope").lower()
            auto_download = self.sglang_args.get("auto_download", True)
            download_dir = self.sglang_args.get("download_dir")
        else:
            model_source = "modelscope"
            auto_download = True
            download_dir = None
        return model_source, auto_download, download_dir

    def _maybe_prepare_model_payload(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        model_source, auto_download, _ = self._resolve_source_settings()

        if not auto_download:
            return payload

        model_path = payload.get("model_path")
        if not model_path:
            return payload

        if model_source in ("local", "offline", "none"):
            return payload

        if model_source == "modelscope":
            try:
                from modelscope import snapshot_download  # type: ignore[import-not-found]
            except Exception as exc:  # pragma: no cover - optional dependency
                raise RuntimeError("modelscope is not available in the runtime image") from exc

            download_dir = payload.get("download_dir")
            token = os.environ.get("MODELSCOPE_TOKEN") or os.environ.get("MS_TOKEN")
            snapshot_kwargs = {
                "cache_dir": download_dir,
                "local_dir": download_dir,
                "token": token,
            }
            try:
                import inspect

                signature = inspect.signature(snapshot_download)
                if "local_dir_use_symlinks" in signature.parameters:
                    snapshot_kwargs["local_dir_use_symlinks"] = False
            except Exception:
                pass

            snapshot_kwargs = {k: v for k, v in snapshot_kwargs.items() if v is not None}

            local_dir = snapshot_download(model_path, **snapshot_kwargs)
            payload["model_path"] = local_dir
            if payload.get("tokenizer_path") is None:
                payload["tokenizer_path"] = local_dir
            payload.setdefault("local_files_only", True)
            return payload

        if model_source == "huggingface":
            if "HF_TOKEN" in os.environ:
                try:
                    import huggingface_hub

                    huggingface_hub.login(os.environ["HF_TOKEN"])
                except Exception:
                    pass
        else:
            raise ValueError("model_source must be 'huggingface', 'modelscope', or 'local'")
        return payload

    def _maybe_prepare_model(self, server_args: Any) -> None:
        model_source, auto_download, _ = self._resolve_source_settings()

        if not auto_download:
            return

        if model_source != "huggingface":
            return

        if "HF_TOKEN" in os.environ:
            try:
                import huggingface_hub

                huggingface_hub.login(os.environ["HF_TOKEN"])
            except Exception:
                pass

    def _resolve_model_name(self, server_args: Any) -> str:
        served_model_name = getattr(server_args, "served_model_name", None)
        if served_model_name:
            return served_model_name
        return getattr(server_args, "model_path", "default")

    def _log_torch_cuda_info(self) -> None:
        try:
            import torch

            try:
                is_available = torch.cuda.is_available()
            except Exception:
                is_available = False
            try:
                torch_version = torch.__version__
            except Exception:
                torch_version = "unknown"
            try:
                cuda_version = torch.version.cuda
            except Exception:
                cuda_version = "unknown"
            try:
                default_device = torch.Tensor([4, 5, 6]).device
            except Exception:
                default_device = "unknown"
            try:
                device_count = torch.cuda.device_count()
            except Exception:
                device_count = "unknown"

            terminal.print(torch_version)
            terminal.print(cuda_version)
            terminal.print(is_available)
            terminal.print(f"default device: {default_device}")
            terminal.print(f"available gpu devices: {device_count}")
        except Exception as exc:  # pragma: no cover - torch optional
            terminal.warn(f"Unable to query torch cuda info: {exc}")

    def get_invocation_commands(self, url: str) -> Tuple[str, List[str]]:
        header = "Invocation details (OpenAI-compatible API)"

        model_name = "default"
        if isinstance(self.sglang_args, SGLangArgs):
            model_name = self.sglang_args.served_model_name or self.sglang_args.model_path
        elif isinstance(self.sglang_args, dict):
            model_name = (
                self.sglang_args.get("served_model_name")
                or self.sglang_args.get("model_name")
                or self.sglang_args.get("model_path")
                or model_name
            )

        request_body = {
            "model": model_name,
            "messages": [{"role": "user", "content": "你好，请介绍一下自己"}],
        }
        formatted_body = json.dumps(request_body, ensure_ascii=False, indent=2)

        chat_url = url.rstrip("/") + "/v1/chat/completions"

        commands = [
            f"curl '{chat_url}' \\",
            "  -H 'Connection: keep-alive' \\",
            "  -H 'Content-Type: application/json' \\",
        ]

        if self.authorized:
            commands.append(f"  -H 'Authorization: Bearer {self.config_context.token}' \\")

        body_lines = formatted_body.split("\n")
        commands.append(f"  -d '{body_lines[0]}")
        for line in body_lines[1:-1]:
            commands.append(f"    {line}")
        commands.append(f"    {body_lines[-1]}'")

        return header, commands

    def set_handler(self, handler: str):
        self.handler = handler

    def func(self, *args: Any, **kwargs: Any):
        pass

    def __call__(self, *args: Any, **kwargs: Any):
        import importlib
        import inspect

        model_source, auto_download, download_dir = self._resolve_source_settings()
        if model_source == "modelscope":
            os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
            os.environ.setdefault("HF_HUB_OFFLINE", "1")
            os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
            if download_dir:
                os.environ.setdefault("TRANSFORMERS_CACHE", download_dir)
                os.environ.setdefault("HF_HOME", download_dir)
        elif model_source in ("local", "offline", "none"):
            os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
            os.environ.setdefault("HF_HUB_OFFLINE", "1")
            os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
            if download_dir:
                os.environ.setdefault("TRANSFORMERS_CACHE", download_dir)
                os.environ.setdefault("HF_HOME", download_dir)

        server_args = self._build_server_args()

        self._maybe_prepare_model(server_args)

        if getattr(server_args, "download_dir", None) and not os.path.exists(server_args.download_dir):
            os.makedirs(server_args.download_dir, exist_ok=True)

        self._log_torch_cuda_info()

        http_server = importlib.import_module("sglang.srt.entrypoints.http_server")

        if not hasattr(http_server, "launch_server"):
            raise RuntimeError("sglang http_server.launch_server not available")

        launch_server = http_server.launch_server
        launch_kwargs: Dict[str, Any] = {}
        signature = inspect.signature(launch_server)

        if "pipe_finish_writer" in signature.parameters:
            launch_kwargs["pipe_finish_writer"] = None
        if "launch_callback" in signature.parameters:
            launch_kwargs["launch_callback"] = None
        if "return_app_only" in signature.parameters:
            launch_kwargs["return_app_only"] = False
        if "return_fastapi_app" in signature.parameters:
            launch_kwargs["return_fastapi_app"] = False
        if "return_app" in signature.parameters:
            launch_kwargs["return_app"] = False
        if "run_http_server" in signature.parameters:
            launch_kwargs["run_http_server"] = True
        if "start_http_server" in signature.parameters:
            launch_kwargs["start_http_server"] = True

        try:
            if multiprocessing.get_start_method(allow_none=True) != "spawn":
                multiprocessing.set_start_method("spawn", force=True)
        except Exception:
            pass

        args_payload = (
            server_args.__dict__ if hasattr(server_args, "__dict__") else dict(server_args)
        )
        server_proc = multiprocessing.Process(
            target=_sglang_launch_server_worker,
            args=(args_payload, launch_kwargs),
            daemon=False,
        )
        server_proc.start()

        # Wait for the server to bind before serving proxy traffic.
        host = getattr(server_args, "host", "127.0.0.1")
        if host in ("0.0.0.0", "::"):
            host = "127.0.0.1"
        port = getattr(server_args, "port", 30000)
        while True:
            if not server_proc.is_alive():
                break
            try:
                import socket

                with socket.create_connection((host, port), timeout=0.5):
                    break
            except OSError:
                time.sleep(0.5)

        from fastapi import FastAPI, Request, Response
        from fastapi.responses import JSONResponse, StreamingResponse
        import httpx

        proxy_app = FastAPI()

        base_url = f"http://{host}:{port}"

        @proxy_app.get("/health")
        async def health_check():
            return {"status": "healthy"}

        @proxy_app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
        async def proxy(path: str, request: Request):
            url = f"{base_url}/{path}"
            if request.url.query:
                url = f"{url}?{request.url.query}"

            headers = dict(request.headers)
            headers.pop("host", None)

            async with httpx.AsyncClient(timeout=None) as client:
                req = client.build_request(
                    request.method,
                    url,
                    headers=headers,
                    content=await request.body(),
                )
                resp = await client.send(req, stream=True)

                response_headers = dict(resp.headers)
                if "transfer-encoding" in response_headers:
                    response_headers.pop("transfer-encoding")

                return StreamingResponse(
                    resp.aiter_raw(),
                    status_code=resp.status_code,
                    headers=response_headers,
                    media_type=resp.headers.get("content-type"),
                )

        return proxy_app

    def deploy(
        self,
        name: Optional[str] = None,
        context: Optional[ConfigContext] = None,
        invocation_details_func: Optional[Callable[..., None]] = None,
        **invocation_details_options: Any,
    ) -> Tuple[Dict[str, Any], bool]:
        self.name = name or self.name
        if not self.name:
            terminal.error(
                "You must specify an app name (either in the decorator or via the --name argument)."
            )

        if isinstance(self.sglang_args, SGLangArgs):
            if (
                self.sglang_args.download_dir
                and self.sglang_args.download_dir != DEFAULT_SGLANG_CACHE_DIR
                and self.sglang_args.download_dir not in [v.mount_path for v in self.volumes]
            ):
                terminal.error(
                    "The server's download directory must match a mount path in the volumes list."
                )

        if context is not None:
            self.config_context = context

        if not self.prepare_runtime(
            stub_type=ASGI_DEPLOYMENT_STUB_TYPE,
            force_create_stub=True,
        ):
            return {}, False

        terminal.header("Deploying")
        deploy_response: DeployStubResponse = self.gateway_stub.deploy_stub(
            DeployStubRequest(stub_id=self.stub_id, name=self.name)
        )

        self.deployment_id = deploy_response.deployment_id
        if deploy_response.ok:
            terminal.header("Deployed 🎉")
            if invocation_details_func:
                invocation_details_func(**invocation_details_options)
            else:
                self.print_invocation_snippet(**invocation_details_options)

        return {
            "deployment_id": deploy_response.deployment_id,
        }, deploy_response.ok

    @with_grpc_error_handling
    def serve(self, timeout: int = 0, url_type: str = ""):
        stub_type = ASGI_SERVE_STUB_TYPE

        if not self.prepare_runtime(func=self.func, stub_type=stub_type, force_create_stub=True):
            return False

        try:
            with terminal.progress("Serving endpoint..."):
                self.parent.print_invocation_snippet(url_type=url_type)
                return self._serve(dir=os.getcwd(), timeout=timeout)
        except KeyboardInterrupt:
            terminal.header("Stopping serve container")
            terminal.print("Goodbye 👋")
            os._exit(0)  # kills all threads immediately

    def _serve(self, *, dir: str, timeout: int = 0):
        r: StartEndpointServeResponse = self.endpoint_stub.start_endpoint_serve(
            StartEndpointServeRequest(
                stub_id=self.stub_id,
                timeout=timeout,
            )
        )
        if not r.ok:
            return terminal.error(r.error_msg)

        container = Container(container_id=r.container_id)
        container.attach(container_id=r.container_id, sync_dir=dir)
