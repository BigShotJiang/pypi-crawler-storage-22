# Boreal Push Queue — Architecture (Deep Dive)

## Filosofia do Projeto

O projeto resolve o problema de **Worker Bloqueante**. Em sistemas tradicionais, o worker precisa ter o código da lógica de negócio. No **Boreal Push Queue**, o worker é **genérico**: ele apenas recebe uma instrução de **onde bater** (URL) e **o que levar** (payload).

## Envelope da Mensagem

Quando você faz `boreal_queue.add(task)`, a mensagem enviada ao RabbitMQ não é apenas o dicionário `task`. A lib cria um envelope JSON com metadados e payload:

```json
{
  "metadata": {
    "target_url": "https://api.servico.com/endpoint",
    "method": "POST",
    "max_requests": 10,
    "timestamp": "2023-10-27T10:00:00Z"
  },
  "payload": {
    "id": 123,
    "name": "minha-task"
  }
}
```

## Por que isso é bom?

1. **Desacoplamento Total**: o serviço que envia a tarefa não precisa que o Worker seja atualizado toda vez que um novo endpoint for criado.
2. **Escalabilidade**: você pode subir múltiplas instâncias do `BorealWorker` para processar a mesma fila.
3. **Simulação de Serverless**: funciona de forma similar ao *Google Cloud Tasks* (push) — o receptor é apenas uma API REST comum.

## Controle de Fluxo (QoS)

O `max_requests` define o `basic_qos(prefetch_count=X)` no RabbitMQ, limitando quantas mensagens podem ficar pendentes de ACK ao mesmo tempo, evitando que o Worker tente processar um volume muito alto de requisições simultâneas.

## Cron Embutido (Deadcase via GET)

Opcionalmente, o `BorealWorker` pode executar um *cron* embutido que faz `GET` na URL do `BorealPushQueue` em um agendamento crontab. A ideia é usar o `GET` na mesma rota como um “deadcase”, enquanto o `POST` segue sendo o processamento das mensagens da fila.
