from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from .exceptions import BorealSerializationError


def utc_now_iso() -> str:
    return (
        datetime.now(timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z")
    )


def build_envelope(
    payload: Any,
    *,
    target_url: str,
    method: str,
    headers: Optional[Dict[str, str]] = None,
    max_requests: Optional[int] = None,
    timestamp: Optional[str] = None,
) -> Dict[str, Any]:
    metadata: Dict[str, Any] = {
        "target_url": target_url,
        "method": method.upper(),
        "timestamp": timestamp or utc_now_iso(),
    }
    if headers:
        metadata["headers"] = headers
    if max_requests is not None:
        metadata["max_requests"] = int(max_requests)
    return {"metadata": metadata, "payload": payload}


def dumps_envelope(envelope: Dict[str, Any]) -> bytes:
    try:
        return json.dumps(envelope, ensure_ascii=False).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise BorealSerializationError("Failed to serialize task envelope to JSON.") from exc


def loads_envelope(body: bytes) -> Dict[str, Any]:
    try:
        decoded = body.decode("utf-8")
        data = json.loads(decoded)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise BorealSerializationError("Failed to decode task envelope JSON.") from exc

    if not isinstance(data, dict):
        raise BorealSerializationError("Task envelope must be a JSON object.")
    if "metadata" not in data or "payload" not in data:
        raise BorealSerializationError("Task envelope must contain 'metadata' and 'payload'.")
    if not isinstance(data.get("metadata"), dict):
        raise BorealSerializationError("'metadata' must be a JSON object.")
    return data

