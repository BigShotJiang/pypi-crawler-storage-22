from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import pika

from ._envelope import build_envelope, dumps_envelope
from .config import get_rabbitmq_url
from .exceptions import BorealConfigError, BorealRabbitMQError

logger = logging.getLogger(__name__)


def _normalize_headers(headers: Optional[Dict[str, Any]]) -> Optional[Dict[str, str]]:
    if not headers:
        return None
    normalized: Dict[str, str] = {}
    for key, value in headers.items():
        normalized[str(key)] = str(value)
    return normalized


class BorealPushQueue:
    """
    Publisher: enfileira tarefas para serem executadas no futuro por um Worker.

    A mensagem enviada ao RabbitMQ é um envelope JSON contendo:
      - metadata: target_url, method, headers, max_requests, timestamp
      - payload: o dicionário/objeto da tarefa
    """

    def __init__(
        self,
        *,
        queue_name: str,
        url: str,
        method: str = "POST",
        max_requests: int = 10,
        crontab: Optional[str] = None,
        cron: bool = False,
        headers: Optional[Dict[str, Any]] = None,
        rabbitmq_url: Optional[str] = None,
        durable: bool = True,
    ) -> None:
        self.queue_name = queue_name
        self.url = url
        self.method = method.upper()
        self.max_requests = int(max_requests)
        self.crontab = crontab.strip() if isinstance(crontab, str) and crontab.strip() else None
        self.cron = bool(cron)
        self.headers = _normalize_headers(headers) or {}
        self.rabbitmq_url = get_rabbitmq_url(rabbitmq_url)
        self.durable = durable

        self._connection: Optional[pika.BlockingConnection] = None
        self._channel: Optional[pika.adapters.blocking_connection.BlockingChannel] = None

        if self.cron and not self.crontab:
            raise BorealConfigError("cron=True requires a valid crontab expression.")

    def _ensure_channel(self) -> pika.adapters.blocking_connection.BlockingChannel:
        if self._connection and self._connection.is_open and self._channel and self._channel.is_open:
            return self._channel
        try:
            params = pika.URLParameters(self.rabbitmq_url)
            self._connection = pika.BlockingConnection(params)
            self._channel = self._connection.channel()
            self._channel.queue_declare(queue=self.queue_name, durable=self.durable)
            return self._channel
        except Exception as exc:
            raise BorealRabbitMQError("Failed to connect/declare queue in RabbitMQ.") from exc

    def add(
        self,
        payload: Any,
        *,
        url: Optional[str] = None,
        method: Optional[str] = None,
        headers: Optional[Dict[str, Any]] = None,
        max_requests: Optional[int] = None,
    ) -> None:
        channel = self._ensure_channel()
        merged_headers = dict(self.headers)
        merged_headers.update(_normalize_headers(headers) or {})

        envelope = build_envelope(
            payload,
            target_url=url or self.url,
            method=(method or self.method),
            headers=merged_headers or None,
            max_requests=max_requests if max_requests is not None else self.max_requests,
        )
        body = dumps_envelope(envelope)

        properties = pika.BasicProperties(
            content_type="application/json",
            delivery_mode=2,  # persistent
        )

        try:
            channel.basic_publish(
                exchange="",
                routing_key=self.queue_name,
                body=body,
                properties=properties,
            )
        except Exception as exc:
            raise BorealRabbitMQError("Failed to publish message to RabbitMQ.") from exc

    def close(self) -> None:
        try:
            if self._connection and self._connection.is_open:
                self._connection.close()
        except Exception:
            logger.exception("Failed to close RabbitMQ connection.")
        finally:
            self._channel = None
            self._connection = None

    def __enter__(self) -> "BorealPushQueue":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()
