from __future__ import annotations

import os
from typing import Optional

from .exceptions import BorealConfigError

ENV_RABBITMQ_URL = "BOREAL_RABBITMQ_URL"
ENV_QUEUE_NAME = "BOREAL_QUEUE_NAME"
ENV_MAX_REQUESTS = "BOREAL_MAX_REQUESTS"
ENV_HTTP_TIMEOUT = "BOREAL_HTTP_TIMEOUT"
ENV_REQUEUE_ON_FAILURE = "BOREAL_REQUEUE_ON_FAILURE"

DEFAULT_RABBITMQ_URL = "amqp://guest:guest@localhost:5672/"
DEFAULT_MAX_REQUESTS = 10
DEFAULT_HTTP_TIMEOUT = 10.0
DEFAULT_REQUEUE_ON_FAILURE = True


def get_rabbitmq_url(explicit: Optional[str] = None) -> str:
    return explicit or os.getenv(ENV_RABBITMQ_URL) or DEFAULT_RABBITMQ_URL


def get_queue_name(explicit: Optional[str] = None) -> str:
    value = explicit or os.getenv(ENV_QUEUE_NAME)
    if not value:
        raise BorealConfigError(
            f"Queue name is required (pass queue_name or set {ENV_QUEUE_NAME})."
        )
    return value


def get_int_env(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise BorealConfigError(f"Invalid int for {name}: {raw!r}") from exc


def get_float_env(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    try:
        return float(raw)
    except ValueError as exc:
        raise BorealConfigError(f"Invalid float for {name}: {raw!r}") from exc


def get_bool_env(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    raw = raw.strip().lower()
    if raw in {"1", "true", "t", "yes", "y", "on"}:
        return True
    if raw in {"0", "false", "f", "no", "n", "off"}:
        return False
    raise BorealConfigError(f"Invalid boolean for {name}: {raw!r}")

