class BorealError(Exception):
    """Base exception for boreal-push-queue."""


class BorealConfigError(BorealError):
    """Raised when configuration is missing or invalid."""


class BorealSerializationError(BorealError):
    """Raised when a message cannot be serialized/deserialized."""


class BorealRabbitMQError(BorealError):
    """Raised when RabbitMQ interaction fails."""


class BorealHTTPError(BorealError):
    """Raised when an HTTP dispatch fails."""

