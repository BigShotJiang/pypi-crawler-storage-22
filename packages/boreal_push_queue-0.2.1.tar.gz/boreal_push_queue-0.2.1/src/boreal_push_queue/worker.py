from __future__ import annotations

import argparse
import logging
import os
import threading
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List, Optional

import httpx
import pika
from croniter import croniter

from ._envelope import loads_envelope
from .client import BorealPushQueue
from .config import (
    DEFAULT_HTTP_TIMEOUT,
    DEFAULT_MAX_REQUESTS,
    DEFAULT_REQUEUE_ON_FAILURE,
    ENV_HTTP_TIMEOUT,
    ENV_MAX_REQUESTS,
    ENV_QUEUE_NAME,
    ENV_RABBITMQ_URL,
    ENV_REQUEUE_ON_FAILURE,
    get_bool_env,
    get_float_env,
    get_int_env,
    get_queue_name,
    get_rabbitmq_url,
)
from .exceptions import BorealConfigError, BorealRabbitMQError, BorealSerializationError

logger = logging.getLogger(__name__)


def _coerce_int(value: Any) -> Optional[int]:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


class BorealWorker:
    """
    Consumer/Dispatcher: consome mensagens do RabbitMQ e dispara requisições HTTP.

    - QoS (`prefetch_count`) limita quantas mensagens ficam "in-flight" sem ACK.
    - Concorrência é controlada por `max_requests` (threads).
    """

    def __init__(
        self,
        push_queue: BorealPushQueue,
        *,
        rabbitmq_url: Optional[str] = None,
        max_requests: Optional[int] = None,
        http_timeout: Optional[float] = None,
        requeue_on_failure: Optional[bool] = None,
        durable: Optional[bool] = None,
    ) -> None:
        self.push_queue = push_queue
        self.queue_name = push_queue.queue_name
        self.rabbitmq_url = rabbitmq_url or push_queue.rabbitmq_url
        self._max_requests_configured = max_requests if max_requests is not None else int(push_queue.max_requests)
        self.http_timeout = (
            float(http_timeout) if http_timeout is not None else get_float_env(ENV_HTTP_TIMEOUT, DEFAULT_HTTP_TIMEOUT)
        )
        self.requeue_on_failure = (
            bool(requeue_on_failure)
            if requeue_on_failure is not None
            else get_bool_env(ENV_REQUEUE_ON_FAILURE, DEFAULT_REQUEUE_ON_FAILURE)
        )
        self.durable = bool(push_queue.durable) if durable is None else bool(durable)

        self._connection: Optional[pika.BlockingConnection] = None
        self._channel: Optional[pika.adapters.blocking_connection.BlockingChannel] = None
        self._executor: Optional[ThreadPoolExecutor] = None
        self._http: Optional[httpx.Client] = None
        self._max_requests_effective: Optional[int] = None
        self._stop_event = threading.Event()
        self._cron_thread: Optional[threading.Thread] = None

    def _set_concurrency(self, max_requests: int) -> None:
        if max_requests < 1:
            max_requests = 1
        if self._max_requests_effective == max_requests and self._executor is not None:
            return
        if self._executor is not None and self._max_requests_effective is not None:
            logger.warning(
                "Ignoring max_requests change from %s to %s (dynamic resizing not supported).",
                self._max_requests_effective,
                max_requests,
            )
            return

        if self._channel is None:
            raise BorealRabbitMQError("Worker channel is not initialized.")

        self._channel.basic_qos(prefetch_count=max_requests)
        self._executor = ThreadPoolExecutor(max_workers=max_requests)
        self._max_requests_effective = max_requests

    def _ensure_runtime(self) -> None:
        if self._connection and self._connection.is_open and self._channel and self._channel.is_open:
            return
        try:
            params = pika.URLParameters(get_rabbitmq_url(self.rabbitmq_url))
            self._connection = pika.BlockingConnection(params)
            self._channel = self._connection.channel()
            self._channel.queue_declare(queue=self.queue_name, durable=self.durable)
        except Exception as exc:
            raise BorealRabbitMQError("Failed to connect/declare queue in RabbitMQ.") from exc

        self._http = httpx.Client(timeout=self.http_timeout)

        self._set_concurrency(int(self._max_requests_configured))
        self._maybe_start_cron()

    def _maybe_start_cron(self) -> None:
        if not self.push_queue.cron:
            return
        if not self.push_queue.crontab:
            raise BorealConfigError("cron=True requires a valid crontab expression.")
        if self._cron_thread is not None and self._cron_thread.is_alive():
            return

        try:
            croniter(self.push_queue.crontab, datetime.now())
        except Exception as exc:
            raise BorealConfigError(f"Invalid crontab expression: {self.push_queue.crontab!r}") from exc

        self._cron_thread = threading.Thread(target=self._cron_loop, name="boreal-cron", daemon=True)
        self._cron_thread.start()

    def _cron_loop(self) -> None:
        assert self._http is not None
        assert self.push_queue.crontab is not None

        iterator = croniter(self.push_queue.crontab, datetime.now())

        logger.info("Cron enabled. Schedule=%s url=%s", self.push_queue.crontab, self.push_queue.url)

        while not self._stop_event.is_set():
            next_dt = iterator.get_next(datetime)
            while True:
                if self._stop_event.is_set():
                    return
                now = datetime.now()
                sleep_s = (next_dt - now).total_seconds()
                if sleep_s <= 0:
                    break
                self._stop_event.wait(timeout=min(sleep_s, 1.0))

            self._cron_tick()

    def _cron_tick(self) -> None:
        assert self._http is not None
        try:
            response = self._http.get(self.push_queue.url, headers=self.push_queue.headers or None)
        except Exception:
            logger.exception("Cron GET failed (exception).")
            return

        if 200 <= response.status_code < 300:
            logger.debug("Cron GET OK (status=%s).", response.status_code)
            return
        logger.warning("Cron GET failed (status=%s).", response.status_code)

    def _schedule_ack(self, delivery_tag: int) -> None:
        assert self._connection is not None
        assert self._channel is not None

        def _ack() -> None:
            if self._channel and self._channel.is_open:
                self._channel.basic_ack(delivery_tag=delivery_tag)

        self._connection.add_callback_threadsafe(_ack)

    def _schedule_nack(self, delivery_tag: int, *, requeue: bool) -> None:
        assert self._connection is not None
        assert self._channel is not None

        def _nack() -> None:
            if self._channel and self._channel.is_open:
                self._channel.basic_nack(delivery_tag=delivery_tag, requeue=requeue)

        self._connection.add_callback_threadsafe(_nack)

    def _dispatch_http(self, delivery_tag: int, envelope: Dict[str, Any]) -> None:
        assert self._http is not None

        metadata = envelope.get("metadata") or {}
        payload = envelope.get("payload")

        target_url = metadata.get("target_url") or self.push_queue.url
        http_method = str(metadata.get("method") or self.push_queue.method or "POST").upper()
        headers = dict(self.push_queue.headers or {})
        headers.update({str(k): str(v) for k, v in (metadata.get("headers") or {}).items()})

        if not target_url:
            logger.error("Dropping message without a dispatch URL (metadata.target_url or PushQueue url).")
            self._schedule_ack(delivery_tag)
            return

        request_kwargs: Dict[str, Any] = {"headers": headers or None}
        if http_method == "GET":
            if isinstance(payload, dict):
                request_kwargs["params"] = payload
        else:
            request_kwargs["json"] = payload

        try:
            response = self._http.request(http_method, str(target_url), **request_kwargs)
        except Exception:
            logger.exception("HTTP dispatch failed (exception).")
            if self.requeue_on_failure:
                self._schedule_nack(delivery_tag, requeue=True)
            else:
                self._schedule_ack(delivery_tag)
            return

        if 200 <= response.status_code < 300:
            self._schedule_ack(delivery_tag)
            return

        logger.warning(
            "HTTP dispatch failed (status=%s).",
            response.status_code,
        )
        if self.requeue_on_failure:
            self._schedule_nack(delivery_tag, requeue=True)
        else:
            self._schedule_ack(delivery_tag)

    def _on_message(self, ch, method, properties, body: bytes) -> None:  # noqa: ANN001
        delivery_tag = method.delivery_tag

        try:
            envelope = loads_envelope(body)
        except BorealSerializationError:
            logger.exception("Dropping message that is not a valid Boreal envelope JSON.")
            ch.basic_ack(delivery_tag=delivery_tag)
            return

        if self._executor is None:
            message_max = _coerce_int((envelope.get("metadata") or {}).get("max_requests"))
            self._set_concurrency(message_max or DEFAULT_MAX_REQUESTS)

        assert self._executor is not None
        self._executor.submit(self._dispatch_http, delivery_tag, envelope)

    def start(self) -> None:
        self._stop_event.clear()
        self._ensure_runtime()
        assert self._channel is not None

        self._channel.basic_consume(queue=self.queue_name, on_message_callback=self._on_message, auto_ack=False)
        try:
            logger.info("Worker started. Consuming queue=%s", self.queue_name)
            self._channel.start_consuming()
        except KeyboardInterrupt:
            logger.info("Worker stopping (KeyboardInterrupt).")
        finally:
            self.stop()

    def stop(self) -> None:
        self._stop_event.set()
        try:
            if self._channel and self._channel.is_open:
                try:
                    self._channel.stop_consuming()
                except Exception:
                    pass
        finally:
            if self._cron_thread is not None:
                self._cron_thread.join(timeout=max(self.http_timeout + 1.0, 5.0))
                self._cron_thread = None

            if self._executor is not None:
                self._executor.shutdown(wait=True)
                self._executor = None

            if self._http is not None:
                self._http.close()
                self._http = None

            if self._connection and self._connection.is_open:
                try:
                    self._connection.close()
                except Exception:
                    logger.exception("Failed to close RabbitMQ connection.")
            self._channel = None
            self._connection = None


def main(argv: Optional[List[str]] = None) -> None:
    parser = argparse.ArgumentParser(prog="boreal-worker", description="Consume a Boreal Push Queue and dispatch HTTP.")
    parser.add_argument("--queue-name", default=os.getenv(ENV_QUEUE_NAME), help=f"Queue name (env: {ENV_QUEUE_NAME}).")
    parser.add_argument("--url", required=True, help="PushQueue target URL (used by cron GET and as default dispatch target).")
    parser.add_argument("--method", default="POST", help="Default dispatch method for tasks produced by this PushQueue.")
    parser.add_argument(
        "--rabbitmq-url",
        default=os.getenv(ENV_RABBITMQ_URL),
        help=f"RabbitMQ URL (env: {ENV_RABBITMQ_URL}).",
    )
    parser.add_argument(
        "--max-requests",
        type=int,
        default=None,
        help=f"Concurrency/prefetch (env: {ENV_MAX_REQUESTS}).",
    )
    parser.add_argument(
        "--http-timeout",
        type=float,
        default=None,
        help=f"HTTP timeout seconds (env: {ENV_HTTP_TIMEOUT}).",
    )
    parser.add_argument("--cron", action="store_true", help="Enable embedded cron to call GET on the PushQueue URL.")
    parser.add_argument("--crontab", default=None, help="Crontab expression (required when --cron is enabled).")
    requeue_group = parser.add_mutually_exclusive_group()
    requeue_group.add_argument(
        "--requeue-on-failure",
        dest="requeue_on_failure",
        action="store_true",
        help=f"Requeue message on HTTP failure (env: {ENV_REQUEUE_ON_FAILURE}).",
    )
    requeue_group.add_argument(
        "--no-requeue-on-failure",
        dest="requeue_on_failure",
        action="store_false",
        help="Do not requeue on HTTP failure (ACK and drop).",
    )
    parser.set_defaults(requeue_on_failure=None)
    parser.add_argument("--log-level", default="INFO", help="Logging level (e.g. DEBUG, INFO, WARNING).")

    args = parser.parse_args(argv)

    logging.basicConfig(level=getattr(logging, str(args.log_level).upper(), logging.INFO))

    queue_name = get_queue_name(args.queue_name)
    rabbitmq_url = get_rabbitmq_url(args.rabbitmq_url)

    max_requests = args.max_requests
    if max_requests is None and os.getenv(ENV_MAX_REQUESTS) not in (None, ""):
        max_requests = get_int_env(ENV_MAX_REQUESTS, DEFAULT_MAX_REQUESTS)
    if max_requests is None:
        max_requests = DEFAULT_MAX_REQUESTS

    push_queue = BorealPushQueue(
        queue_name=queue_name,
        url=args.url,
        method=args.method,
        max_requests=max_requests,
        cron=bool(args.cron),
        crontab=args.crontab,
        rabbitmq_url=rabbitmq_url,
    )
    worker = BorealWorker(push_queue, http_timeout=args.http_timeout, requeue_on_failure=args.requeue_on_failure)
    worker.start()
