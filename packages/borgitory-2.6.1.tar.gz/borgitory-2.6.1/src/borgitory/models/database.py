import base64
import bcrypt
import hashlib
import logging
import uuid
import os
from datetime import datetime

from borgitory.config_module import (
    ASYNC_DATABASE_URL,
    DATA_DIR,
    DATABASE_URL,
    get_secret_key,
)
from borgitory.services.migrations.migration_factory import (
    create_migration_service_for_startup,
)
from borgitory.utils.datetime_utils import now_utc
from borgitory.models.enums import EncryptionType
from typing import List, Any

from cryptography.fernet import Fernet
from sqlalchemy import (
    Integer,
    String,
    DateTime,
    Boolean,
    Text,
    ForeignKey,
    Uuid,
)
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import Mapped, declarative_base, mapped_column
from sqlalchemy.orm import relationship


class StringUUID(uuid.UUID):
    """UUID subclass that returns string representation by default"""

    def __str__(self) -> str:
        return super().__str__()

    def __repr__(self) -> str:
        return f"'{super().__str__()}'"


class StringUuidType(Uuid[str]):
    """Custom UUID type that returns StringUUID objects"""

    def result_processor(self, dialect: Any, coltype: Any) -> Any:
        """Convert database result to StringUUID"""

        def process(value: Any) -> Any:
            if value is None:
                return None
            return StringUUID(value)

        return process


logger = logging.getLogger(__name__)

BCRYPT_MAX_PASSWORD_BYTES = 72


engine = create_async_engine(
    ASYNC_DATABASE_URL, connect_args={"check_same_thread": False}
)
async_session_maker = async_sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)

Base = declarative_base()

# Lazy-loaded cipher suite
_cipher_suite = None


def get_cipher_suite() -> Fernet:
    """Get or create the Fernet cipher suite."""
    global _cipher_suite
    if _cipher_suite is None:
        secret_key = get_secret_key()
        fernet_key = base64.urlsafe_b64encode(
            hashlib.sha256(secret_key.encode()).digest()
        )
        _cipher_suite = Fernet(fernet_key)
    return _cipher_suite

class Repository(Base):
    __tablename__ = "repositories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String, unique=True, index=True, nullable=False)
    path: Mapped[str] = mapped_column(String, nullable=False)
    encrypted_passphrase: Mapped[str | None] = mapped_column(String, nullable=True)
    encryption_type: Mapped[EncryptionType] = mapped_column(
        String, default=EncryptionType.NONE, nullable=False
    )
    encrypted_keyfile_content: Mapped[str | None] = mapped_column(
        Text, nullable=True
    )  # Encrypted keyfile content
    cache_dir: Mapped[str | None] = mapped_column(
        String, nullable=True
    )  # Custom BORG_CACHE_DIR path
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: now_utc())

    jobs: Mapped[List["Job"]] = relationship(
        "Job", back_populates="repository", cascade="all, delete-orphan"
    )
    schedules: Mapped[List["Schedule"]] = relationship(
        "Schedule", back_populates="repository", cascade="all, delete-orphan"
    )

    def set_passphrase(self, passphrase: str) -> None:
        self.encrypted_passphrase = (
            get_cipher_suite().encrypt(passphrase.encode()).decode()
        )

    def get_passphrase(self) -> str | None:
        if self.encrypted_passphrase:
            return (
                get_cipher_suite().decrypt(self.encrypted_passphrase.encode()).decode()
            )
        return None

    def set_keyfile_content(self, keyfile_content: str) -> None:
        """Encrypt and store keyfile content."""
        if keyfile_content:
            self.encrypted_keyfile_content = (
                get_cipher_suite().encrypt(keyfile_content.encode()).decode()
            )
        else:
            self.encrypted_keyfile_content = None

    def get_keyfile_content(self) -> str | None:
        """Decrypt and return keyfile content."""
        if self.encrypted_keyfile_content:
            return (
                get_cipher_suite()
                .decrypt(self.encrypted_keyfile_content.encode())
                .decode()
            )
        return None


class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[StringUUID] = mapped_column(
        StringUuidType(native_uuid=False),
        primary_key=True,
        index=True,
        default=uuid.uuid4,
    )  # UUID as primary key
    repository_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("repositories.id"), nullable=False
    )
    type: Mapped[str] = mapped_column(
        String, nullable=False
    )  # backup, restore, list, etc.
    status: Mapped[str] = mapped_column(
        String, nullable=False, default="pending"
    )  # pending, running, completed, failed
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    log_output: Mapped[str | None] = mapped_column(Text, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    container_id: Mapped[str | None] = mapped_column(String, nullable=True)
    cloud_sync_config_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("cloud_sync_configs.id"), nullable=True
    )
    prune_config_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("prune_configs.id"), nullable=True
    )
    check_config_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("repository_check_configs.id"), nullable=True
    )
    notification_config_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("notification_configs.id"), nullable=True
    )

    job_type: Mapped[str] = mapped_column(
        String, nullable=False, default="simple"
    )  # 'simple', 'composite'
    total_tasks: Mapped[int] = mapped_column(Integer, default=1)
    completed_tasks: Mapped[int] = mapped_column(Integer, default=0)

    repository: Mapped["Repository"] = relationship("Repository", back_populates="jobs")
    cloud_backup_config: Mapped["CloudSyncConfig"] = relationship("CloudSyncConfig")
    check_config: Mapped["RepositoryCheckConfig"] = relationship(
        "RepositoryCheckConfig"
    )
    tasks: Mapped[List["JobTask"]] = relationship(
        "JobTask", back_populates="job", cascade="all, delete-orphan"
    )


class JobTask(Base):
    __tablename__ = "job_tasks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    job_id: Mapped[StringUUID] = mapped_column(
        StringUuidType(native_uuid=False), ForeignKey("jobs.id"), nullable=False
    )  # UUID foreign key
    task_type: Mapped[str] = mapped_column(
        String, nullable=False
    )  # 'backup', 'cloud_sync', 'verify', etc.
    task_name: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[str] = mapped_column(
        String, nullable=False, default="pending"
    )  # 'pending', 'running', 'completed', 'failed', 'skipped'
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    output: Mapped[str | None] = mapped_column(Text, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    return_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    task_order: Mapped[int] = mapped_column(
        Integer, nullable=False
    )  # Order of execution within the job

    job: Mapped["Job"] = relationship("Job", back_populates="tasks")


class Schedule(Base):
    __tablename__ = "schedules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    repository_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("repositories.id"), nullable=False
    )
    name: Mapped[str] = mapped_column(String, nullable=False)
    cron_expression: Mapped[str] = mapped_column(String, nullable=False)
    source_path: Mapped[str] = mapped_column(String, nullable=False, default="/data")
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_run: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    next_run: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: now_utc())
    cloud_sync_config_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("cloud_sync_configs.id"), nullable=True
    )
    prune_config_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("prune_configs.id"), nullable=True
    )
    check_config_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("repository_check_configs.id"), nullable=True
    )
    notification_config_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("notification_configs.id"), nullable=True
    )
    pre_job_hooks: Mapped[str | None] = mapped_column(Text, nullable=True)
    post_job_hooks: Mapped[str | None] = mapped_column(Text, nullable=True)
    patterns: Mapped[str | None] = mapped_column(Text, nullable=True)

    repository: Mapped["Repository"] = relationship(
        "Repository", back_populates="schedules"
    )
    cloud_sync_config: Mapped["CloudSyncConfig"] = relationship("CloudSyncConfig")
    prune_config: Mapped["PruneConfig"] = relationship("PruneConfig")
    check_config: Mapped["RepositoryCheckConfig"] = relationship(
        "RepositoryCheckConfig"
    )
    notification_config: Mapped["NotificationConfig"] = relationship(
        "NotificationConfig"
    )


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    username: Mapped[str] = mapped_column(
        String, unique=True, index=True, nullable=False
    )
    password_hash: Mapped[str] = mapped_column(String, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: now_utc())
    last_login: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    sessions: Mapped[List["UserSession"]] = relationship(
        "UserSession", back_populates="user"
    )

    def set_password(self, password: str) -> None:
        """Hash and store the password. Raises ValueError if password exceeds bcrypt's 72-byte limit."""
        encoded = password.encode("utf-8")
        if len(encoded) > BCRYPT_MAX_PASSWORD_BYTES:
            raise ValueError(
                f"Password exceeds bcrypt limit of {BCRYPT_MAX_PASSWORD_BYTES} bytes"
            )
        self.password_hash = bcrypt.hashpw(
            encoded,
            bcrypt.gensalt()).decode("utf-8")

    def verify_password(self, password: str) -> bool:
        """Verify a password against the stored hash. Returns False if password exceeds 72 bytes."""
        encoded = password.encode("utf-8")
        if len(encoded) > BCRYPT_MAX_PASSWORD_BYTES:
            return False
        return bcrypt.checkpw(
            encoded,
            self.password_hash.encode("utf-8"),
        )


class UserSession(Base):
    __tablename__ = "user_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("users.id"), nullable=False
    )
    session_token: Mapped[str] = mapped_column(
        String, unique=True, index=True, nullable=False
    )
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    remember_me: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: now_utc())
    last_activity: Mapped[datetime] = mapped_column(DateTime, default=lambda: now_utc())
    user_agent: Mapped[str | None] = mapped_column(String, nullable=True)
    ip_address: Mapped[str | None] = mapped_column(String, nullable=True)

    user: Mapped["User"] = relationship("User", back_populates="sessions")


class Setting(Base):
    __tablename__ = "settings"

    key: Mapped[str] = mapped_column(String, primary_key=True, index=True)
    value: Mapped[str] = mapped_column(String, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: now_utc(), onupdate=lambda: now_utc()
    )


class PruneConfig(Base):
    __tablename__ = "prune_configs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String, nullable=False, index=True)
    strategy: Mapped[str] = mapped_column(
        String, nullable=False
    )  # "simple" or "advanced"

    # Simple strategy
    keep_within_days: Mapped[int | None] = mapped_column(Integer, nullable=True)

    # Advanced strategy
    keep_secondly: Mapped[int | None] = mapped_column(Integer, nullable=True)
    keep_minutely: Mapped[int | None] = mapped_column(Integer, nullable=True)
    keep_hourly: Mapped[int | None] = mapped_column(Integer, nullable=True)
    keep_daily: Mapped[int | None] = mapped_column(Integer, nullable=True)
    keep_weekly: Mapped[int | None] = mapped_column(Integer, nullable=True)
    keep_monthly: Mapped[int | None] = mapped_column(Integer, nullable=True)
    keep_yearly: Mapped[int | None] = mapped_column(Integer, nullable=True)

    # Options
    show_list: Mapped[bool] = mapped_column(Boolean, default=True)
    show_stats: Mapped[bool] = mapped_column(Boolean, default=True)
    save_space: Mapped[bool] = mapped_column(Boolean, default=False)
    compact_after: Mapped[bool] = mapped_column(Boolean, default=True)

    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: now_utc())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: now_utc(), onupdate=lambda: now_utc()
    )


class NotificationConfig(Base):
    __tablename__ = "notification_configs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String, nullable=False, index=True)
    provider: Mapped[str] = mapped_column(
        String, nullable=False
    )  # "pushover", "discord", "slack", "email", etc.

    # JSON configuration field for provider-specific settings
    provider_config: Mapped[str] = mapped_column(
        Text, nullable=False
    )  # JSON field for provider configuration

    # Common fields
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: now_utc())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: now_utc(), onupdate=lambda: now_utc()
    )


class CloudSyncConfig(Base):
    __tablename__ = "cloud_sync_configs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String, nullable=False, index=True)
    provider: Mapped[str] = mapped_column(
        String, nullable=False
    )  # "s3", "sftp", "azure", "gcp", etc.

    # JSON configuration field for provider-specific settings
    provider_config: Mapped[str] = mapped_column(
        Text, nullable=False
    )  # JSON field for provider configuration

    # Common fields
    path_prefix: Mapped[str] = mapped_column(String, default="", nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: now_utc())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: now_utc(), onupdate=lambda: now_utc()
    )


class RepositoryCheckConfig(Base):
    __tablename__ = "repository_check_configs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String, nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(String, nullable=True)

    # Check Type
    check_type: Mapped[str] = mapped_column(
        String, nullable=False, default="full"
    )  # "full", "repository_only", "archives_only"

    # Verification Options
    verify_data: Mapped[bool] = mapped_column(Boolean, default=False)
    repair_mode: Mapped[bool] = mapped_column(Boolean, default=False)
    save_space: Mapped[bool] = mapped_column(Boolean, default=False)

    # Advanced Options
    max_duration: Mapped[int | None] = mapped_column(Integer, nullable=True)  # seconds
    archive_prefix: Mapped[str | None] = mapped_column(String, nullable=True)
    archive_glob: Mapped[str | None] = mapped_column(String, nullable=True)
    first_n_archives: Mapped[int | None] = mapped_column(Integer, nullable=True)
    last_n_archives: Mapped[int | None] = mapped_column(Integer, nullable=True)

    # Metadata
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: now_utc())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: now_utc(), onupdate=lambda: now_utc()
    )


class UserInstalledPackage(Base):
    """Model for tracking user-installed packages for persistence across container restarts."""

    __tablename__ = "user_installed_packages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    package_name: Mapped[str] = mapped_column(String, nullable=False, index=True)
    version: Mapped[str] = mapped_column(String, nullable=False)
    installed_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: now_utc())

    # Metadata about the installation
    install_command: Mapped[str | None] = mapped_column(
        String, nullable=True
    )  # The exact command used
    dependencies_installed: Mapped[str | None] = mapped_column(
        Text, nullable=True
    )  # JSON list of deps that were also installed


async def init_db() -> None:
    """Initialize database and run migrations"""

    try:
        logger.info(f"Data directory: {DATA_DIR}")
        logger.info(f"Using database at: {DATABASE_URL}")

        os.makedirs(DATA_DIR, exist_ok=True)

        migration_service = create_migration_service_for_startup()
        if not migration_service.run_migrations():
            raise RuntimeError("Database migration failed")
    except Exception as e:
        logger.error(f"Database initialization error: {e}")
        raise
