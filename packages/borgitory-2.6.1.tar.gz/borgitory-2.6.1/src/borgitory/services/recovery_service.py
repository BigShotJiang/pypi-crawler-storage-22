"""
Recovery service for handling crashed or interrupted backup jobs.

This service handles cleanup when the application restarts after being
shut down or crashed while backup jobs were running.
"""

import logging

from borgitory.models.database import Repository
from borgitory.models.job_results import JobStatusEnum
from borgitory.utils.datetime_utils import now_utc
from borgitory.protocols.command_executor_protocol import CommandExecutorProtocol
import asyncio
from borgitory.utils.security import create_borg_command
from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession
from sqlalchemy import select

logger = logging.getLogger(__name__)


class RecoveryService:
    """Service to recover from application crashes during backup operations"""

    def __init__(
        self,
        command_executor: CommandExecutorProtocol,
        session_maker: async_sessionmaker[AsyncSession],
    ) -> None:
        """Initialize RecoveryService with command executor for cross-platform compatibility."""
        self.command_executor = command_executor
        self.session_maker = session_maker

    async def recover_stale_jobs(self) -> None:
        """
        Find backup jobs that were running when the app was shut down and clean them up.
        This should be called on application startup.

        All backup operations (manual and scheduled) use the job system.
        Legacy jobs are only used for utility operations (scan, list archives, etc.)
        which don't need recovery - they can simply be re-run if needed.
        """
        logger.info("Starting recovery: checking for interrupted jobs...")

        await self.recover_database_job_records()

        logger.info(
            "Recovery complete - all interrupted backup jobs cancelled and locks released"
        )

    async def recover_database_job_records(self) -> None:
        """
        Find database Job records that are marked as 'running' and mark them as failed.
        This handles the case where the app restarted and jobs are cleared from memory,
        but database records still show 'running' status.
        """
        try:
            logger.info("Checking database for interrupted job records...")

            async with self.session_maker() as db:
                from borgitory.models.database import Job, JobTask

                # Find all jobs in database marked as running or pending (interrupted before completion)
                result = await db.execute(
                    select(Job).where(Job.status.in_(["running", "pending"]))
                )
                interrupted_jobs = result.scalars().all()

                if not interrupted_jobs:
                    logger.info("No interrupted database job records found")
                    return

                logger.info(
                    f"Found {len(interrupted_jobs)} interrupted database job records"
                )

                for job in interrupted_jobs:
                    logger.info(
                        f"Cancelling database job record {job.id} ({job.job_type}) - was running since {job.started_at}"
                    )

                    # Mark job as failed
                    job.status = JobStatusEnum.FAILED
                    job.finished_at = now_utc()
                    job.error = f"Error: Job cancelled on startup - was running when application shut down (started: {job.started_at})"

                    # Mark all running tasks as failed
                    task_result = await db.execute(
                        select(JobTask).where(
                            JobTask.job_id == job.id,
                            JobTask.status.in_(["pending", "running", "in_progress"]),
                        )
                    )
                    running_tasks = task_result.scalars().all()

                    for task in running_tasks:
                        task.status = JobStatusEnum.FAILED
                        task.completed_at = now_utc()
                        task.error = "Task cancelled on startup - job was interrupted by application shutdown"
                        logger.info(f"  Task '{task.task_name}' marked as failed")

                    # Release repository lock if this was a backup job
                    if (
                        job.job_type in ["manual_backup", "scheduled_backup", "backup"]
                        and job.repository_id
                    ):
                        repo_result = await db.execute(
                            select(Repository).where(Repository.id == job.repository_id)
                        )
                        repository = repo_result.scalar_one_or_none()
                        if repository:
                            logger.info(
                                f"Releasing repository lock for: {repository.name}"
                            )
                            await self._release_repository_lock(repository)
                        else:
                            logger.warning(
                                f"Repository {job.repository_id} not found in database for job {job.id}"
                            )
                    else:
                        logger.debug(
                            f"Job {job.id} is not a backup job or has no repository_id - skipping lock release"
                        )

                # Commit all the changes
                await db.commit()
                logger.info("All interrupted database job records cancelled")

        except Exception as e:
            logger.error(f"Error recovering database job records: {e}")

    async def _release_repository_lock(self, repository: Repository) -> None:
        """Use borg break-lock to release any stale locks on a repository"""
        try:
            logger.info(f"Attempting to release lock on repository: {repository.name}")

            borg_command = create_borg_command(
                repository_path=repository.path,
                passphrase=repository.get_passphrase(),
                base_command="borg break-lock",
                additional_args=[],
            )
            # Execute the break-lock command with a timeout using command executor
            process = await self.command_executor.create_subprocess(
                command=borg_command.command,
                env=borg_command.environment,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(), timeout=30
                )

                if process.returncode == 0:
                    logger.info(
                        f"Successfully released lock on repository: {repository.name}"
                    )
                else:
                    # Log the error but don't fail - lock might not exist
                    stderr_text = stderr.decode() if stderr else "No error details"
                    logger.warning(
                        f"Break-lock returned {process.returncode} for {repository.name}: {stderr_text}"
                    )

            except asyncio.TimeoutError:
                logger.warning(
                    f"Break-lock timed out for repository: {repository.name}"
                )
                process.kill()

        except Exception as e:
            logger.error(f"Error releasing lock for repository {repository.name}: {e}")
