"""
Tests for auth HTMX functionality
"""

from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from borgitory.models.database import User, BCRYPT_MAX_PASSWORD_BYTES


class TestAuthHTMX:
    """Test class for auth HTMX functionality."""

    async def test_register_htmx_success(
        self, async_client_without_auth_or_user: AsyncClient, test_db: AsyncSession
    ) -> None:
        """Test registration via HTMX returns HTML template."""
        # Make HTMX request
        response = await async_client_without_auth_or_user.post(
            "/auth/register",
            data={"username": "testuser", "password": "testpassword"},
            headers={"hx-request": "true"},
        )

        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]

        # Check for success message
        assert "Registration successful! You can now log in." in response.text

        # Verify user was created in database
        result = await test_db.execute(select(User).where(User.username == "testuser"))
        user = result.scalar_one_or_none()
        assert user is not None
        assert user.username == "testuser"

    async def test_register_htmx_validation_error(
        self, async_client_without_auth_or_user: AsyncClient, test_db: AsyncSession
    ) -> None:
        """Test registration validation error via HTMX."""
        # Make HTMX request with invalid data
        response = await async_client_without_auth_or_user.post(
            "/auth/register",
            data={"username": "ab", "password": "123"},  # Too short
            headers={"hx-request": "true"},
        )

        assert response.status_code == 400
        assert "text/html" in response.headers["content-type"]

        # Check for error message
        assert "Username must be at least 3 characters" in response.text

    async def test_register_htmx_password_over_72_bytes_rejected(
        self, async_client_without_auth_or_user: AsyncClient, test_db: AsyncSession
    ) -> None:
        """Test registration rejects password over 72 bytes (UTF-8)."""
        long_password = "a" * (BCRYPT_MAX_PASSWORD_BYTES + 1)
        response = await async_client_without_auth_or_user.post(
            "/auth/register",
            data={"username": "testuser", "password": long_password},
            headers={"hx-request": "true"},
        )

        assert response.status_code == 400
        assert "72 bytes" in response.text

    async def test_login_htmx_success(
        self, async_client_without_auth: AsyncClient, test_db: AsyncSession
    ) -> None:
        """Test login via HTMX returns HTML template."""
        # Make HTMX request
        response = await async_client_without_auth.post(
            "/auth/login",
            data={"username": "test_user", "password": "test_password"},
            headers={"hx-request": "true"},
        )

        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]

        # Check for success message and HX-Redirect header
        assert "Login successful! Redirecting..." in response.text
        assert response.headers.get("HX-Redirect") == "/repositories"

    async def test_login_htmx_invalid_credentials(
        self, async_client_without_auth_or_user: AsyncClient, test_db: AsyncSession
    ) -> None:
        """Test login with invalid credentials via HTMX."""
        # Make HTMX request with invalid credentials
        response = await async_client_without_auth_or_user.post(
            "/auth/login",
            data={"username": "nonexistent", "password": "wrong"},
            headers={"hx-request": "true"},
        )

        assert response.status_code == 401
        assert "text/html" in response.headers["content-type"]

        # Check for error message
        assert "Invalid username or password" in response.text

    async def test_check_users_no_users_returns_register_form(
        self, async_client_without_auth_or_user: AsyncClient, test_db: AsyncSession
    ) -> None:
        """Test check-users endpoint returns register form when no users exist."""
        response = await async_client_without_auth_or_user.get("/auth/check-users")

        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]

        # Should return register form with welcome message
        assert "No users exist yet" in response.text
        assert "Create the first administrator account" in response.text
        assert 'id="register-form"' in response.text
        assert 'action="/auth/register"' in response.text

    async def test_check_users_with_users_returns_login_form(
        self, async_client_without_auth_or_user: AsyncClient, test_db: AsyncSession
    ) -> None:
        """Test check-users endpoint returns login form when users exist."""
        # Create a test user
        user = User()
        user.username = "existinguser"
        user.set_password("password123")
        test_db.add(user)
        await test_db.commit()

        response = await async_client_without_auth_or_user.get("/auth/check-users")

        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]

        # Should return login form
        assert 'id="login-form"' in response.text
        assert 'action="/auth/login"' in response.text
        assert "Remember me" in response.text
