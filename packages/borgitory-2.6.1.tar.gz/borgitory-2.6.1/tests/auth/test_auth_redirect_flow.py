"""
Test for auth redirect flow - debugging the login redirect issue
"""

from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from borgitory.models.database import User


class TestAuthRedirectFlow:
    """Test class for auth redirect flow debugging."""

    async def test_login_htmx_flow(
        self, async_client_without_auth: AsyncClient, test_db: AsyncSession
    ) -> None:
        """Test the complete HTMX login flow with cookie authentication."""
        # Make login request (HTMX-style)
        response = await async_client_without_auth.post(
            "/auth/login",
            data={"username": "test_user", "password": "test_password"},
            headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            },
        )

        # Should get a 200 OK with HTML success template
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "Login successful" in response.text

        # Should have set auth cookie
        assert "auth_token" in response.cookies
        auth_token = response.cookies["auth_token"]
        assert auth_token is not None and len(auth_token) > 0

        # Now try to access the main page with the cookie
        async_client_without_auth.cookies.set("auth_token", auth_token)
        response2 = await async_client_without_auth.get(
            "/",
            headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            },
            follow_redirects=False,
        )

        assert response2.status_code == 302
        assert response2.headers["location"] == "/repositories"

        response3 = await async_client_without_auth.get(
            "/repositories",
            headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            },
            follow_redirects=False,
        )

        assert response3.status_code == 200
        assert "Borgitory" in response3.text

    async def test_login_sets_cookie_correctly(
        self, async_client: AsyncClient, test_db: AsyncSession
    ) -> None:
        """Test that login sets the cookie with correct attributes via HTMX."""
        # Create a test user
        user = User()
        user.username = "cookietest"
        user.set_password("testpassword")
        test_db.add(user)
        await test_db.commit()

        # Make login request
        response = await async_client.post(
            "/auth/login",
            data={"username": "cookietest", "password": "testpassword"},
            headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            },
        )

        # Should get success response
        assert response.status_code == 200
        assert "Login successful" in response.text

        set_cookie_header = response.headers.get("set-cookie", "")

        assert "auth_token=" in set_cookie_header
        assert "HttpOnly" in set_cookie_header
        assert "samesite=lax" in set_cookie_header.lower()
