"""
Tests for BorgService - Core functionality tests
"""

import pytest
import re
from typing import List
from unittest.mock import Mock, AsyncMock

from borgitory.services.borg_service import BorgService
from borgitory.protocols.command_executor_protocol import CommandExecutorProtocol
from borgitory.protocols.path_protocols import PathServiceInterface
from borgitory.models.database import Repository
from borgitory.models.borg_info import BorgDefaultDirectories


@pytest.fixture
def mock_command_executor() -> Mock:
    """Create mock command executor."""
    mock = Mock(spec=CommandExecutorProtocol)
    mock.create_subprocess = AsyncMock()
    mock.execute_command = AsyncMock()
    return mock


@pytest.fixture
def mock_job_executor() -> Mock:
    """Create mock job executor."""
    return Mock()


@pytest.fixture
def mock_command_runner() -> Mock:
    """Create mock command runner."""
    return Mock()


@pytest.fixture
def mock_job_manager() -> Mock:
    """Create mock job manager."""
    return Mock()


@pytest.fixture
def mock_archive_service() -> Mock:
    """Create mock archive service."""
    return Mock()


@pytest.fixture
def mock_path_service(mock_command_executor: Mock) -> "PathServiceInterface":
    """Create path service with mock command executor."""
    from borgitory.services.path.path_service import PathService

    # Return a real PathService instance with the mock command executor
    # This way async methods like get_default_directories will work properly
    return PathService(command_executor=mock_command_executor)


@pytest.fixture
def borg_service(
    mock_job_executor: Mock,
    mock_command_runner: Mock,
    mock_job_manager: Mock,
    mock_archive_service: Mock,
    mock_command_executor: Mock,
    mock_path_service: Mock,
) -> BorgService:
    """Create BorgService with mock dependencies."""
    return BorgService(
        job_executor=mock_job_executor,
        command_runner=mock_command_runner,
        job_manager=mock_job_manager,
        archive_service=mock_archive_service,
        command_executor=mock_command_executor,
        path_service=mock_path_service,
    )


@pytest.fixture
def mock_repository() -> Mock:
    """Create mock repository."""
    repo = Mock(spec=Repository)
    repo.name = "test-repo"
    repo.path = "/test/repo/path"
    repo.cache_dir = None
    repo.get_passphrase.return_value = "test-passphrase"
    repo.get_keyfile_content.return_value = None
    return repo


class TestBorgServiceCore:
    """Test core BorgService functionality."""

    def test_service_initialization(
        self,
        mock_job_executor: Mock,
        mock_command_runner: Mock,
        mock_job_manager: Mock,
        mock_archive_service: Mock,
        mock_command_executor: Mock,
        mock_path_service: Mock,
    ) -> None:
        """Test BorgService initializes correctly with all dependencies."""
        service = BorgService(
            job_executor=mock_job_executor,
            command_runner=mock_command_runner,
            job_manager=mock_job_manager,
            archive_service=mock_archive_service,
            command_executor=mock_command_executor,
            path_service=mock_path_service,
        )

        assert service.job_executor is mock_job_executor
        assert service.command_runner is mock_command_runner
        assert service.job_manager is mock_job_manager
        assert service.archive_service is mock_archive_service
        assert service.command_executor is mock_command_executor
        assert service.path_service is mock_path_service

    def test_progress_pattern_matching(self, borg_service: BorgService) -> None:
        """Test that the progress pattern regex works correctly."""
        # Test pattern exists
        assert hasattr(borg_service, "progress_pattern")
        assert isinstance(borg_service.progress_pattern, re.Pattern)

        # Test pattern matching
        test_line = "1024 512 256 5 /home/user/test.txt"
        match = borg_service.progress_pattern.match(test_line)

        assert match is not None
        assert match.group("original_size") == "1024"
        assert match.group("compressed_size") == "512"
        assert match.group("deduplicated_size") == "256"
        assert match.group("nfiles") == "5"
        assert match.group("path") == "/home/user/test.txt"

    def test_has_required_methods(self, borg_service: BorgService) -> None:
        """Test that BorgService has all required methods."""
        required_methods = [
            "list_archives",
            "initialize_repository",
            "verify_repository_access",
        ]

        for method_name in required_methods:
            assert hasattr(borg_service, method_name)
            assert callable(getattr(borg_service, method_name))


class TestBorgServiceIntegration:
    """Test integration scenarios."""

    def test_dependency_injection_pattern(
        self,
        mock_job_executor: Mock,
        mock_command_runner: Mock,
        mock_job_manager: Mock,
        mock_archive_service: Mock,
        mock_command_executor: Mock,
        mock_path_service: Mock,
    ) -> None:
        """Test that BorgService follows proper dependency injection patterns."""
        # Should be able to create multiple instances with different dependencies
        service1 = BorgService(
            job_executor=mock_job_executor,
            command_runner=mock_command_runner,
            job_manager=mock_job_manager,
            archive_service=mock_archive_service,
            command_executor=mock_command_executor,
            path_service=mock_path_service,
        )

        # Create different mocks
        other_job_executor = Mock()
        other_command_executor = Mock(spec=CommandExecutorProtocol)

        service2 = BorgService(
            job_executor=other_job_executor,
            command_runner=mock_command_runner,
            job_manager=mock_job_manager,
            archive_service=mock_archive_service,
            command_executor=other_command_executor,
            path_service=mock_path_service,
        )

        # Services should have different dependencies
        assert service1.job_executor is not service2.job_executor
        assert service1.command_executor is not service2.command_executor

        # But same shared dependencies should be the same
        assert service1.command_runner is service2.command_runner
        assert service1.job_manager is service2.job_manager
        assert service1.archive_service is service2.archive_service
        assert service1.path_service is service2.path_service


class TestBorgDefaultDirectories:
    """Test get_default_directories method."""

    @pytest.mark.asyncio
    async def test_default_directories_with_no_env_vars(
        self, mock_path_service: PathServiceInterface, mock_command_executor: Mock
    ) -> None:
        """Test default directory resolution with no environment variables set."""

        async def mock_execute(cmd: List[str]) -> Mock:
            result = Mock()
            result.success = True
            if cmd[0] == "sh" and cmd[1] == "-c":
                result.stdout = (
                    "BORG_BASE_DIR=\n"
                    "HOME=/home/testuser\n"
                    "XDG_CACHE_HOME=\n"
                    "XDG_CONFIG_HOME=\n"
                    "TMPDIR=/tmp\n"
                    "HOME_FROM_CD=/home/testuser"
                )
            else:
                result.stdout = ""
            return result

        mock_command_executor.execute_command = AsyncMock(side_effect=mock_execute)
        result = await mock_path_service.get_default_directories()

        assert isinstance(result, BorgDefaultDirectories)
        assert result.base_dir == "/home/testuser"
        assert result.cache_dir == "/home/testuser/.cache/borg"
        assert result.config_dir == "/home/testuser/.config/borg"
        assert result.security_dir == "/home/testuser/.config/borg/security"
        assert result.keys_dir == "/home/testuser/.config/borg/keys"
        assert result.temp_dir == "/tmp"

    @pytest.mark.asyncio
    async def test_default_directories_with_borg_base_dir(
        self, mock_path_service: PathServiceInterface, mock_command_executor: Mock
    ) -> None:
        """Test directory resolution when BORG_BASE_DIR is explicitly set."""

        async def mock_execute(cmd: List[str]) -> Mock:
            result = Mock()
            result.success = True
            if cmd[0] == "sh" and cmd[1] == "-c":
                result.stdout = (
                    "BORG_BASE_DIR=/custom/borg/base\n"
                    "HOME=\n"
                    "XDG_CACHE_HOME=\n"
                    "XDG_CONFIG_HOME=\n"
                    "TMPDIR=/tmp\n"
                    "HOME_FROM_CD="
                )
            else:
                result.stdout = ""
            return result

        mock_command_executor.execute_command = AsyncMock(side_effect=mock_execute)
        result = await mock_path_service.get_default_directories()

        assert result.base_dir == "/custom/borg/base"
        assert result.cache_dir == "/custom/borg/base/.cache/borg"
        assert result.config_dir == "/custom/borg/base/.config/borg"
        assert result.security_dir == "/custom/borg/base/.config/borg/security"
        assert result.keys_dir == "/custom/borg/base/.config/borg/keys"

    @pytest.mark.asyncio
    async def test_default_directories_with_xdg_vars(
        self, mock_path_service: PathServiceInterface, mock_command_executor: Mock
    ) -> None:
        """Test XDG variables take precedence when BORG_BASE_DIR is not set."""

        async def mock_execute(cmd: List[str]) -> Mock:
            result = Mock()
            result.success = True
            if cmd[0] == "sh" and cmd[1] == "-c":
                result.stdout = (
                    "BORG_BASE_DIR=\n"
                    "HOME=/home/testuser\n"
                    "XDG_CACHE_HOME=/custom/cache\n"
                    "XDG_CONFIG_HOME=/custom/config\n"
                    "TMPDIR=/tmp\n"
                    "HOME_FROM_CD=/home/testuser"
                )
            else:
                result.stdout = ""
            return result

        mock_command_executor.execute_command = AsyncMock(side_effect=mock_execute)
        result = await mock_path_service.get_default_directories()

        assert result.base_dir == "/home/testuser"
        assert result.cache_dir == "/custom/cache/borg"
        assert result.config_dir == "/custom/config/borg"
        assert result.security_dir == "/custom/config/borg/security"
        assert result.keys_dir == "/custom/config/borg/keys"

    @pytest.mark.asyncio
    async def test_default_directories_borg_base_overrides_xdg(
        self, mock_path_service: PathServiceInterface, mock_command_executor: Mock
    ) -> None:
        """Test BORG_BASE_DIR overrides XDG variables when explicitly set."""

        async def mock_execute(cmd: List[str]) -> Mock:
            result = Mock()
            result.success = True
            if cmd[0] == "sh" and cmd[1] == "-c":
                result.stdout = (
                    "BORG_BASE_DIR=/custom/borg/base\n"
                    "HOME=\n"
                    "XDG_CACHE_HOME=/custom/cache\n"
                    "XDG_CONFIG_HOME=/custom/config\n"
                    "TMPDIR=/tmp\n"
                    "HOME_FROM_CD="
                )
            else:
                result.stdout = ""
            return result

        mock_command_executor.execute_command = AsyncMock(side_effect=mock_execute)
        result = await mock_path_service.get_default_directories()

        assert result.base_dir == "/custom/borg/base"
        assert result.cache_dir == "/custom/borg/base/.cache/borg"
        assert result.config_dir == "/custom/borg/base/.config/borg"

    def test_has_get_default_directories_method(
        self, mock_path_service: PathServiceInterface
    ) -> None:
        """Test that PathService has get_default_directories method."""
        assert hasattr(mock_path_service, "get_default_directories")
        assert callable(getattr(mock_path_service, "get_default_directories"))


class TestBorgServiceDeleteArchive:
    """Test delete_archive method."""

    @pytest.mark.asyncio
    async def test_delete_archive_success(
        self,
        borg_service: BorgService,
        mock_repository: Mock,
        mock_command_runner: Mock,
    ) -> None:
        """Test successful archive deletion."""
        mock_result = Mock()
        mock_result.success = True
        mock_result.return_code = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        mock_command_runner.run_command = AsyncMock(return_value=mock_result)

        result = await borg_service.delete_archive(mock_repository, "test-archive")

        assert result is True
        mock_command_runner.run_command.assert_called_once()

        call_args = mock_command_runner.run_command.call_args
        command = call_args[0][0]
        assert "borg" in command
        assert "delete" in command
        assert f"{mock_repository.path}::test-archive" in " ".join(command)

    @pytest.mark.asyncio
    async def test_delete_archive_failure_nonzero_return_code(
        self,
        borg_service: BorgService,
        mock_repository: Mock,
        mock_command_runner: Mock,
    ) -> None:
        """Test archive deletion failure with non-zero return code."""
        mock_result = Mock()
        mock_result.success = False
        mock_result.return_code = 2
        mock_result.stdout = ""
        mock_result.stderr = "Archive not found"

        mock_command_runner.run_command = AsyncMock(return_value=mock_result)

        with pytest.raises(Exception) as exc_info:
            await borg_service.delete_archive(mock_repository, "nonexistent-archive")

        assert "Failed to delete archive" in str(exc_info.value)
        assert "Archive not found" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_delete_archive_failure_command_error(
        self,
        borg_service: BorgService,
        mock_repository: Mock,
        mock_command_runner: Mock,
    ) -> None:
        """Test archive deletion when command runner throws exception."""
        mock_command_runner.run_command = AsyncMock(
            side_effect=Exception("Command execution failed")
        )

        with pytest.raises(Exception) as exc_info:
            await borg_service.delete_archive(mock_repository, "test-archive")

        assert "Failed to delete archive" in str(exc_info.value)
        assert "Command execution failed" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_delete_archive_with_cache_dir(
        self,
        borg_service: BorgService,
        mock_repository: Mock,
        mock_command_runner: Mock,
    ) -> None:
        """Test archive deletion works when cache directory is configured."""
        mock_repository.cache_dir = "/custom/cache"

        mock_result = Mock()
        mock_result.success = True
        mock_result.return_code = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        mock_command_runner.run_command = AsyncMock(return_value=mock_result)

        result = await borg_service.delete_archive(mock_repository, "test-archive")

        assert result is True
        mock_command_runner.run_command.assert_called_once()

    @pytest.mark.asyncio
    async def test_delete_archive_timeout_setting(
        self,
        borg_service: BorgService,
        mock_repository: Mock,
        mock_command_runner: Mock,
    ) -> None:
        """Test archive deletion uses appropriate timeout."""
        mock_result = Mock()
        mock_result.success = True
        mock_result.return_code = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        mock_command_runner.run_command = AsyncMock(return_value=mock_result)

        await borg_service.delete_archive(mock_repository, "test-archive")

        call_args = mock_command_runner.run_command.call_args
        timeout = call_args[1]["timeout"]
        assert timeout == 60
