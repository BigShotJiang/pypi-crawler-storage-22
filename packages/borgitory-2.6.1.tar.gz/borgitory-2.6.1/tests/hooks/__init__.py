"""
Tests for hook functionality.
"""
