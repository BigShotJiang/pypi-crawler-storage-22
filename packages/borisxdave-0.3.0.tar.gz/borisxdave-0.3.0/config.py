"""Boris configuration constants."""
import os

BORIS_DIR = os.path.dirname(os.path.abspath(__file__))
PLANS_DIR = os.path.join(BORIS_DIR, "plans")
LOGS_DIR = os.path.join(BORIS_DIR, "logs")
STATE_DIR = ".boris"
STATE_FILE = "state.json"
CLAUDE_CMD = "claude"
DEFAULT_MAX_ITERATIONS = 15
MAX_CORRECTIONS = 2
MAX_RETRIES = 1
