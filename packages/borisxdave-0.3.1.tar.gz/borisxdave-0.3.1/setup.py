import sysconfig
from setuptools import setup

setup(
    name="borisxdave",
    version="0.3.1",
    description="Boris - Autonomous Project Orchestrator",
    py_modules=["boris", "engine", "git_manager", "prompts", "state", "planner", "config", "file_lock"],
    data_files=[
        (sysconfig.get_path("purelib"), ["boris_prompt.md"]),
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "boris=boris:main",
            "borisxdave=boris:main",
        ],
    },
)
