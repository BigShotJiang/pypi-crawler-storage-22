"""Tests for Borse."""
