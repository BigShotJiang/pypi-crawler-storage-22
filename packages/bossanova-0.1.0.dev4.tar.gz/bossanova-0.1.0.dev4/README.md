# Bossanova

Bridging statistical cultures with some jazz.
