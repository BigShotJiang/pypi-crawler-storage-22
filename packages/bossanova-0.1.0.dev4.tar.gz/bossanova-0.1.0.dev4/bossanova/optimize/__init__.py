"""Optimization routines for bossanova."""

from bossanova.optimize.bobyqa import optimize_theta

__all__ = ["optimize_theta"]
