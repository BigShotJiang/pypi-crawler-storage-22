"""BotGuard SDK — secure your LLM applications with multi-tier threat detection."""

from .client import BotGuard, BotGuardAsync
from .types import ShieldResult, ShieldVerdict

__version__ = "0.1.2"
__all__ = ["BotGuard", "BotGuardAsync", "ShieldResult", "ShieldVerdict"]
