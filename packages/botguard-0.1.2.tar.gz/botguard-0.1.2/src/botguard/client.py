"""BotGuard SDK client — wraps OpenAI to route requests through BotGuard Shield."""

from __future__ import annotations

import json
from typing import Any, Dict, Generator, Iterator, List, Optional, Union

import httpx
from openai import OpenAI, AsyncOpenAI
from openai.types.chat import ChatCompletion, ChatCompletionChunk

from .types import ShieldResult, ShieldVerdict

_DEFAULT_API_URL = "https://agentguard-api-8ae872ce8db9.herokuapp.com"


class BotGuard:
    """Synchronous BotGuard client.

    Usage:
        guard = BotGuard(
            shield_id="sh_abc123",
            api_key="sk-...",
        )
        result = guard.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}],
        )
        if result.blocked:
            print("Blocked:", result.shield.reason)
        else:
            print(result.content)
    """

    def __init__(
        self,
        *,
        shield_id: str,
        api_key: str,
        api_url: str = _DEFAULT_API_URL,
        timeout: float = 120.0,
        **openai_kwargs: Any,
    ):
        self.shield_id = shield_id
        self.api_url = api_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout

        base_url = f"{self.api_url}/api/gateway/{self.shield_id}/v1"

        self._client = OpenAI(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            **openai_kwargs,
        )

        self.chat = _ChatNamespace(self)

    @property
    def openai(self) -> OpenAI:
        """Access the underlying OpenAI client."""
        return self._client


class BotGuardAsync:
    """Asynchronous BotGuard client.

    Usage:
        guard = BotGuardAsync(
            shield_id="sh_abc123",
            api_key="sk-...",
        )
        result = await guard.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}],
        )
    """

    def __init__(
        self,
        *,
        shield_id: str,
        api_key: str,
        api_url: str = _DEFAULT_API_URL,
        timeout: float = 120.0,
        **openai_kwargs: Any,
    ):
        self.shield_id = shield_id
        self.api_url = api_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout

        base_url = f"{self.api_url}/api/gateway/{self.shield_id}/v1"

        self._client = AsyncOpenAI(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            **openai_kwargs,
        )

        self.chat = _AsyncChatNamespace(self)

    @property
    def openai(self) -> AsyncOpenAI:
        """Access the underlying AsyncOpenAI client."""
        return self._client


def _extract_shield(data: dict) -> ShieldVerdict:
    """Parse _shield metadata from the API response."""
    meta = data.get("_shield", {})
    if not meta:
        return ShieldVerdict(action="allowed")

    return ShieldVerdict(
        action=meta.get("action", "allowed"),
        reason=meta.get("reason"),
        confidence=meta.get("confidence"),
        analysis_path=meta.get("analysisPath"),
        matched_patterns=meta.get("matchedPatterns"),
        pii_detections=meta.get("piiDetections"),
        guardrail_violation=meta.get("guardrailViolation"),
        policy_violation=meta.get("policyViolation"),
        latency_ms=meta.get("responseTimeMs"),
    )


class _Completions:
    """Synchronous chat.completions namespace."""

    def __init__(self, guard: BotGuard):
        self._guard = guard

    def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Union[ShieldResult, Iterator[ShieldResult]]:
        """Create a chat completion through BotGuard Shield.

        Returns a ShieldResult wrapping the response with shield metadata.
        When streaming, yields ShieldResult objects for each chunk.
        """
        if stream:
            return self._create_stream(model=model, messages=messages, **kwargs)

        base_url = str(self._guard._client.base_url).rstrip("/")
        url = f"{base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self._guard._api_key}",
            "Content-Type": "application/json",
        }
        body = {"model": model, "messages": messages, "stream": False, **kwargs}

        with httpx.Client(timeout=self._guard._timeout) as http:
            resp = http.post(str(url), json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        shield = _extract_shield(data)
        return ShieldResult(response=data, shield=shield)

    def _create_stream(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        **kwargs: Any,
    ) -> Iterator[ShieldResult]:
        base_url = str(self._guard._client.base_url).rstrip("/")
        url = f"{base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self._guard._api_key}",
            "Content-Type": "application/json",
        }
        body = {"model": model, "messages": messages, "stream": True, **kwargs}

        with httpx.Client(timeout=self._guard._timeout) as http:
            with http.stream("POST", str(url), json=body, headers=headers) as resp:
                resp.raise_for_status()
                shield_verdict = ShieldVerdict(action="allowed")
                for line in resp.iter_lines():
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:]
                    if payload == "[DONE]":
                        break
                    try:
                        chunk_data = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    if "_shield" in chunk_data:
                        shield_verdict = _extract_shield(chunk_data)
                    yield ShieldResult(response=chunk_data, shield=shield_verdict)


class _ChatNamespace:
    def __init__(self, guard: BotGuard):
        self.completions = _Completions(guard)


class _AsyncCompletions:
    """Async chat.completions namespace."""

    def __init__(self, guard: BotGuardAsync):
        self._guard = guard

    async def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Union[ShieldResult, Any]:
        """Create a chat completion through BotGuard Shield (async)."""
        if stream:
            return self._create_stream(model=model, messages=messages, **kwargs)

        base_url = str(self._guard._client.base_url).rstrip("/")
        url = f"{base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self._guard._api_key}",
            "Content-Type": "application/json",
        }
        body = {"model": model, "messages": messages, "stream": False, **kwargs}

        async with httpx.AsyncClient(timeout=self._guard._timeout) as http:
            resp = await http.post(str(url), json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        shield = _extract_shield(data)
        return ShieldResult(response=data, shield=shield)

    async def _create_stream(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        **kwargs: Any,
    ):
        base_url = str(self._guard._client.base_url).rstrip("/")
        url = f"{base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self._guard._api_key}",
            "Content-Type": "application/json",
        }
        body = {"model": model, "messages": messages, "stream": True, **kwargs}

        async with httpx.AsyncClient(timeout=self._guard._timeout) as http:
            async with http.stream("POST", str(url), json=body, headers=headers) as resp:
                resp.raise_for_status()
                shield_verdict = ShieldVerdict(action="allowed")
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:]
                    if payload == "[DONE]":
                        break
                    try:
                        chunk_data = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    if "_shield" in chunk_data:
                        shield_verdict = _extract_shield(chunk_data)
                    yield ShieldResult(response=chunk_data, shield=shield_verdict)


class _AsyncChatNamespace:
    def __init__(self, guard: BotGuardAsync):
        self.completions = _AsyncCompletions(guard)
