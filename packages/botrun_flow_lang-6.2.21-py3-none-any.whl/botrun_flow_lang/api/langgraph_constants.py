"""
LangGraph 常數定義

此檔案只包含常數定義，不包含任何會觸發重型 SDK 載入的 import。
這樣可以讓其他模組在只需要常數時，不會觸發 langchain_google_vertexai 等重型套件的載入。
"""

# Graph 名稱常數
LANGGRAPH_REACT_AGENT = "langgraph_react_agent"
GOV_SUBSIDY_AGENT = "gov_subsidy_agent"
PERPLEXITY_SEARCH_AGENT = "perplexity_search_agent"
