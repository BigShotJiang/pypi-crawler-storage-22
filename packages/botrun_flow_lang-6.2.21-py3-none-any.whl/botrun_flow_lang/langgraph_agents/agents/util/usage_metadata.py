"""
Usage Metadata 模組

提供 LLM 呼叫的 token 使用量追蹤功能。
"""

from dataclasses import dataclass, asdict
from typing import Dict, Any


@dataclass
class UsageMetadata:
    """Token usage metadata that matches the expected parsing format."""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    model: str = ""

    def __add__(self, other: "UsageMetadata") -> "UsageMetadata":
        """Combine two UsageMetadata objects."""
        return UsageMetadata(
            prompt_tokens=self.prompt_tokens + other.prompt_tokens,
            completion_tokens=self.completion_tokens + other.completion_tokens,
            total_tokens=self.total_tokens + other.total_tokens,
            cache_creation_input_tokens=self.cache_creation_input_tokens + other.cache_creation_input_tokens,
            cache_read_input_tokens=self.cache_read_input_tokens + other.cache_read_input_tokens,
            model=self.model or other.model,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)
