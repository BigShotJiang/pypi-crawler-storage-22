# MCP Server Rebrand: Deeper Investigation

**Date**: 2026-02-09  
**Status**: Complete  
**Confidence**: HIGH  
**Parent**: [investigation.md](./investigation.md)

## Detailed File-by-File Analysis

### 1. Directory Structure Change

```
mcp_server/botvegas_mcp/ → mcp_server/botvegas_mcp/
```

This is a simple rename. All internal imports are relative (`.client`, `.server`, etc.) so they'll continue to work.

---

### 2. pyproject.toml (6 changes)

**File**: `mcp_server/pyproject.toml`

| Line | Current | New |
|------|---------|-----|
| 2 | `name = "pinchr-mcp"` | `name = "botvegas-mcp"` |
| 4 | `description = "MCP Server for BotVegas Poker - AI agent interface"` | `description = "MCP Server for BotVegas Poker - AI agent interface"` |
| 9 | `{name = "BotVegas Team"}` | `{name = "BotVegas Team"}` |
| 11 | `keywords = [..., "pinchr"]` | `keywords = [..., "botvegas"]` |
| 39 | `pinchr-mcp = "botvegas_mcp.server:main"` | `botvegas-mcp = "botvegas_mcp.server:main"` |
| 46 | `packages = ["botvegas_mcp"]` | `packages = ["botvegas_mcp"]` |

---

### 3. README.md (Full Rewrite Required)

**File**: `mcp_server/README.md`

30+ matches. Needs complete rewrite with:
- Title: "BotVegas MCP Server"
- All references to Pinchr → BotVegas
- Environment variable: `PINCHR_API_URL` → `BOTVEGAS_API_URL`
- Module: `botvegas_mcp` → `botvegas_mcp`
- MCP server name: `pinchr` → `botvegas`
- **Tool names in tables**: `pinchr_*` → `botvegas_*` (already correct in code, but README is outdated)

---

### 4. Python Source Files

#### 4.1 `__init__.py` (5 changes)

**File**: `mcp_server/botvegas_mcp/__init__.py` → `mcp_server/botvegas_mcp/__init__.py`

```python
# Line 1: Docstring
"""BotVegas MCP Server - AI agent interface..."""  →  """BotVegas MCP Server - AI agent interface..."""

# Line 4: Docstring
"Texas Hold'em poker through the BotVegas API."  →  "Texas Hold'em poker through the BotVegas API."

# Lines 8, 11, 14: Usage examples
"python -m botvegas_mcp"  →  "python -m botvegas_mcp"
"mcp run botvegas_mcp/server.py"  →  "mcp run botvegas_mcp/server.py"
"mcp install botvegas_mcp/server.py"  →  "mcp install botvegas_mcp/server.py"
```

#### 4.2 `__main__.py` (2 changes)

**File**: `mcp_server/botvegas_mcp/__main__.py` → `mcp_server/botvegas_mcp/__main__.py`

```python
# Line 1: Docstring
"""Entry point for running botvegas_mcp as a module."""  →  """Entry point for running botvegas_mcp as a module."""

# Line 4: Usage
"python -m botvegas_mcp"  →  "python -m botvegas_mcp"
```

#### 4.3 `client.py` (9 changes)

**File**: `mcp_server/botvegas_mcp/client.py` → `mcp_server/botvegas_mcp/client.py`

```python
# Line 1-4: Docstring
"""HTTP client for BotVegas API..."""  →  """HTTP client for BotVegas API..."""
"wraps the BotVegas REST API"  →  "wraps the BotVegas REST API"

# Line 13-14: Class name + docstring
class PinchrAPIError(Exception):  →  class BotVegasAPIError(Exception):
    """Error from BotVegas API."""  →  """Error from BotVegas API."""

# Line 24-28: Class name + docstring
class PinchrClient:  →  class BotVegasClient:
    """HTTP client for BotVegas Poker API."""  →  """HTTP client for BotVegas Poker API."""
    "Errors are raised as PinchrAPIError."  →  "Errors are raised as BotVegasAPIError."

# Line 70: Exception raise
raise PinchrAPIError(  →  raise BotVegasAPIError(

# Line 314: Exception catch
except PinchrAPIError:  →  except BotVegasAPIError:
```

#### 4.4 `server.py` (~10 changes)

**File**: `mcp_server/botvegas_mcp/server.py` → `mcp_server/botvegas_mcp/server.py`

```python
# Line 1-5: Docstring
"""BotVegas MCP Server..."""  →  """BotVegas MCP Server..."""
"through the BotVegas API"  →  "through the BotVegas API"

# Line 17: Import
from .client import PinchrAPIError, PinchrClient  →  from .client import BotVegasAPIError, BotVegasClient

# Line 42: Logger name
logger_name = os.getenv("LOGGER_NAME", "botvegas_mcp")  →  logger_name = os.getenv("LOGGER_NAME", "botvegas_mcp")

# Line 65-66: Environment variables
PINCHR_API_URL = os.getenv("PINCHR_API_URL", ...)  →  BOTVEGAS_API_URL = os.getenv("BOTVEGAS_API_URL", ...)
PINCHR_API_BASE = f"{PINCHR_API_URL}/api"  →  BOTVEGAS_API_BASE = f"{BOTVEGAS_API_URL}/api"

# Line 434: Docstring
"""Context holding the BotVegas client..."""  →  """Context holding the BotVegas client..."""

# Line 436: Type hint
def __init__(self, client: PinchrClient, ...)  →  def __init__(self, client: BotVegasClient, ...)

# Line 443-444: Docstring + log
"""Manage the BotVegas HTTP client..."""  →  """Manage the BotVegas HTTP client..."""
logger.info(f"Initializing BotVegas MCP server...")  →  logger.info(f"Initializing BotVegas MCP server...")

# Line 447: Variable usage
base_url=PINCHR_API_BASE  →  base_url=BOTVEGAS_API_BASE

# Throughout: Exception handling
except PinchrAPIError as e:  →  except BotVegasAPIError as e:
```

**NOTE**: All tool function names are already `botvegas_*` ✅

#### 4.5 `token_manager.py` (6 changes)

**File**: `mcp_server/botvegas_mcp/token_manager.py` → `mcp_server/botvegas_mcp/token_manager.py`

```python
# Line 5: Docstring
"2. Encrypted file (~/.pinchr/tokens.enc)"  →  "2. Encrypted file (~/.botvegas/tokens.enc)"

# Line 26: Keyring service
KEYRING_SERVICE = "pinchr-mcp"  →  KEYRING_SERVICE = "botvegas-mcp"

# Line 27: Default token file
DEFAULT_TOKEN_FILE = Path.home() / ".pinchr" / "tokens.enc"  →  Path.home() / ".botvegas" / "tokens.enc"

# Line 39: Environment variable + default
os.getenv("PINCHR_TOKEN_PASSWORD", "pinchr-default-key")  →  os.getenv("BOTVEGAS_TOKEN_PASSWORD", "botvegas-default-key")

# Line 51: Salt
salt = b"pinchr-mcp-token-salt"  →  salt = b"botvegas-mcp-token-salt"

# Line 101: Comment
"requires PINCHR_TOKEN_PASSWORD env var"  →  "requires BOTVEGAS_TOKEN_PASSWORD env var"
```

#### 4.6 `transactions.py` (2 changes)

**File**: `mcp_server/botvegas_mcp/transactions.py` → `mcp_server/botvegas_mcp/transactions.py`

```python
# Line 1: Docstring
"""Transaction building and signing for BotVegas escrow..."""  →  """Transaction building and signing for BotVegas escrow..."""

# Line 9: Docstring
"returned by the BotVegas backend's"  →  "returned by the BotVegas backend's"
```

**NOTE**: `$BOTVEGAS` token references should stay as-is (that's the token name).

#### 4.7 `wallet.py` (1 change)

**File**: `mcp_server/botvegas_mcp/wallet.py` → `mcp_server/botvegas_mcp/wallet.py`

```python
# Line 1: Docstring
"""Local wallet management for BotVegas agents."""  →  """Local wallet management for BotVegas agents."""
```

**NOTE**: Already uses `botvegas-agent` service name and `~/.config/botvegas/` paths ✅

---

### 5. Test Files

#### 5.1 `tests/__init__.py` (1 change)

```python
"""Tests for BotVegas MCP Server."""  →  """Tests for BotVegas MCP Server."""
```

#### 5.2 `tests/test_client.py` (10 changes)

```python
# Line 1: Docstring
"""Tests for the BotVegas HTTP client."""  →  """Tests for the BotVegas HTTP client."""

# Line 7: Import
from botvegas_mcp.client import PinchrClient, PinchrAPIError  →  from botvegas_mcp.client import BotVegasClient, BotVegasAPIError

# Line 17-19: Fixture docstring + return
"""Create a PinchrClient with mocked HTTP."""  →  """Create a BotVegasClient with mocked HTTP."""
return PinchrClient(http=...)  →  return BotVegasClient(http=...)

# Line 22-23: Class name + docstring
class TestPinchrClient:  →  class TestBotVegasClient:
"""Test the BotVegasClient class."""  →  """Test the BotVegasClient class."""

# Line 65: Exception
with pytest.raises(PinchrAPIError) as exc_info:  →  with pytest.raises(BotVegasAPIError) as exc_info:

# Line 215-216: Class name + docstring
class TestPinchrAPIError:  →  class TestBotVegasAPIError:
"""Test the BotVegasAPIError exception."""  →  """Test the BotVegasAPIError exception."""

# Line 220: Exception usage
error = PinchrAPIError(404, "Not found", ...)  →  error = BotVegasAPIError(404, "Not found", ...)
```

#### 5.3 `tests/test_transactions.py` (10+ changes)

```python
# Line 10: Import
from botvegas_mcp.transactions import (  →  from botvegas_mcp.transactions import (

# Line 27: Import
from botvegas_mcp.wallet import CONFIG  →  from botvegas_mcp.wallet import CONFIG

# Lines 140, 146-149, 164-166: Patch paths
patch('botvegas_mcp.transactions.*')  →  patch('botvegas_mcp.transactions.*')
```

#### 5.4 `tests/test_wallet.py` (10+ changes)

```python
# Line 12: Import
from botvegas_mcp.wallet import (  →  from botvegas_mcp.wallet import (

# Lines 120, 134, 145, 155, 164, 183, 205, 230-231: Patch paths
patch('botvegas_mcp.wallet.*')  →  patch('botvegas_mcp.wallet.*')
```

---

### 6. Things That Should NOT Change

| Pattern | Reason |
|---------|--------|
| `$BOTVEGAS` | Token name (already correct) |
| `BOTVEGAS_MINT` | Token mint address config |
| `botvegas_*` tool names | Already rebranded |
| `botvegas-agent` service name | Already correct in wallet.py |
| `~/.config/botvegas/` | Already correct in wallet.py |
| `BOTVEGAS_TOKEN_MINT` env var | Token config (stays) |

---

### 7. Breaking Changes Summary

| Old | New | Impact |
|-----|-----|--------|
| `PINCHR_API_URL` env var | `BOTVEGAS_API_URL` | Users must update env |
| `PINCHR_TOKEN_PASSWORD` env var | `BOTVEGAS_TOKEN_PASSWORD` | Users must update env |
| `~/.pinchr/tokens.enc` | `~/.botvegas/tokens.enc` | Tokens won't migrate |
| `pinchr-mcp` keyring service | `botvegas-mcp` | Tokens won't migrate |
| `pinchr-mcp` package name | `botvegas-mcp` | Reinstall required |
| `python -m botvegas_mcp` | `python -m botvegas_mcp` | Update run commands |
| `pinchr` MCP server name | `botvegas` | Update MCP configs |

**Pre-production**: No migration needed. Clean slate approach.

---

### 8. Exact Change Counts

| File | Pinchr→BotVegas | Class Renames | Env Var | Path | Total |
|------|-----------------|---------------|---------|------|----- |
| pyproject.toml | 4 | 0 | 0 | 2 | **6** |
| README.md | 30+ | 0 | 5 | 5 | **40+** |
| __init__.py | 2 | 0 | 0 | 3 | **5** |
| __main__.py | 1 | 0 | 0 | 1 | **2** |
| client.py | 5 | 4 | 0 | 0 | **9** |
| server.py | 4 | 3 | 2 | 1 | **10** |
| token_manager.py | 3 | 0 | 1 | 2 | **6** |
| transactions.py | 2 | 0 | 0 | 0 | **2** |
| wallet.py | 1 | 0 | 0 | 0 | **1** |
| tests/__init__.py | 1 | 0 | 0 | 0 | **1** |
| tests/test_client.py | 2 | 6 | 0 | 2 | **10** |
| tests/test_transactions.py | 0 | 0 | 0 | 10 | **10** |
| tests/test_wallet.py | 0 | 0 | 0 | 10 | **10** |
| **TOTAL** | **55+** | **13** | **3** | **36** | **~112** |

---

## Implementation Plan

### Strategy: Separate Repository

Instead of renaming in-place within the pinchr repo, we'll:

1. **Create new repo** (`botvegas-mcp`) with fresh structure
2. **Copy files** from `pinchr/mcp_server/` to new repo
3. **Rename & rebrand** in the new repo only
4. **Publish to PyPI** as `botvegas-mcp`
5. **Keep pinchr repo unchanged** - no path changes, tests still work

**Benefits**:
- Zero changes to pinchr repo's test paths
- Clean PyPI package with proper name
- Independent versioning
- Can symlink back for local dev if needed

---

### Phase 1: Create New Repo & Copy Files

```bash
# Create new repo structure
mkdir botvegas-mcp
cp -r pinchr/mcp_server/botvegas_mcp botvegas-mcp/botvegas_mcp
cp -r pinchr/mcp_server/tests botvegas-mcp/tests
cp pinchr/mcp_server/pyproject.toml botvegas-mcp/
cp pinchr/mcp_server/README.md botvegas-mcp/
```

### Phase 2: Bulk String Replacements (in order)

Apply these replacements across all `.py` files in `mcp_server/`:

1. **Class names** (case-sensitive, exact match):
   - `PinchrAPIError` → `BotVegasAPIError`
   - `PinchrClient` → `BotVegasClient`

2. **Module imports** (case-sensitive):
   - `botvegas_mcp` → `botvegas_mcp`

3. **Environment variables** (case-sensitive):
   - `PINCHR_API_URL` → `BOTVEGAS_API_URL`
   - `PINCHR_API_BASE` → `BOTVEGAS_API_BASE`
   - `PINCHR_TOKEN_PASSWORD` → `BOTVEGAS_TOKEN_PASSWORD`

4. **Service/path names** (case-sensitive):
   - `pinchr-mcp` → `botvegas-mcp`
   - `".pinchr"` → `".botvegas"`
   - `b"pinchr-mcp-token-salt"` → `b"botvegas-mcp-token-salt"`
   - `pinchr-default-key` → `botvegas-default-key`

5. **Brand name in text** (case-sensitive):
   - `Pinchr` → `BotVegas` (in docstrings/comments only)

### Phase 3: pyproject.toml Update
Manual edit with all 6 changes.

### Phase 4: README.md Rewrite
Complete rewrite with correct branding and tool names.

### Phase 5: Verification
```bash
cd mcp_server
pip install -e .
python -m botvegas_mcp --help  # Should work
pytest  # All tests should pass
```

---

## Checkpoint

**Findings**: 112 total touchpoints identified across 13 files. All changes are mechanical string replacements except README which needs a full rewrite.

**Confidence Level**: HIGH - Exhaustive analysis complete.

**Ready for Implementation**: Yes
