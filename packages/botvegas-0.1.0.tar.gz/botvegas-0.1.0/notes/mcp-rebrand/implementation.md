# MCP Server Rebrand: Implementation Plan

**Date**: 2026-02-09  
**Status**: Ready for Implementation  
**Parent**: [deeper_investigation.md](./deeper_investigation.md)

---

## Overview

Rebrand the MCP server from "Pinchr" to "BotVegas" with ~112 touchpoints across 13 files.

---

## Strategy: Separate Repository

### Why Separate Repo?

1. **No path changes in pinchr repo** - Tests, imports, CI all keep working
2. **Clean PyPI package** - `botvegas-mcp` as standalone package
3. **Independent versioning** - MCP server can version separately from backend
4. **Cleaner git history** - Fresh repo without pinchr history baggage

### Repository Structure

**New repo**: `botvegas-mcp` (or similar)

```
botvegas-mcp/
├── botvegas_mcp/           # The Python package (renamed from botvegas_mcp)
│   ├── __init__.py
│   ├── __main__.py
│   ├── client.py
│   ├── server.py
│   ├── token_manager.py
│   ├── transactions.py
│   └── wallet.py
├── tests/
│   ├── __init__.py
│   ├── test_client.py
│   ├── test_transactions.py
│   └── test_wallet.py
├── pyproject.toml
├── README.md
└── LICENSE
```

### Workflow

1. **Create new repo** with rebranded code
2. **Verify tests pass** in new repo
3. **Publish to PyPI** as `botvegas-mcp`
4. **Symlink back** (optional) for local dev: `ln -s /path/to/botvegas-mcp/botvegas_mcp mcp_server/botvegas_mcp`
5. **Keep pinchr repo's mcp_server/** as-is until fully migrated

### What Stays in Pinchr Repo

- `mcp_server/botvegas_mcp/` - Unchanged, still works
- All existing tests - No path changes needed
- CI/CD - No changes needed

---

## Execution Order

### Step 0: Create New Repo Structure

Copy `mcp_server/` contents to new location, then rename:

```
botvegas_mcp/ → botvegas_mcp/
```

**Note**: We'll do the rebranding IN the new repo, not in pinchr repo

---

### Step 2: Bulk Replace - Class Names

**Scope**: `mcp_server/botvegas_mcp/*.py` and `mcp_server/tests/*.py`

| Old | New | Files Affected |
|-----|-----|----------------|
| `PinchrAPIError` | `BotVegasAPIError` | client.py, server.py, test_client.py |
| `PinchrClient` | `BotVegasClient` | client.py, server.py, test_client.py |
| `TestPinchrClient` | `TestBotVegasClient` | test_client.py |
| `TestPinchrAPIError` | `TestBotVegasAPIError` | test_client.py |

**Tool**: `e_bulk_replace`

---

### Step 3: Bulk Replace - Module Names

| Old | New | Files Affected |
|-----|-----|----------------|
| `botvegas_mcp` | `botvegas_mcp` | All .py files |

**Tool**: `e_bulk_replace`

---

### Step 4: Bulk Replace - Environment Variables

| Old | New | Files Affected |
|-----|-----|----------------|
| `PINCHR_API_URL` | `BOTVEGAS_API_URL` | server.py |
| `PINCHR_API_BASE` | `BOTVEGAS_API_BASE` | server.py |
| `PINCHR_TOKEN_PASSWORD` | `BOTVEGAS_TOKEN_PASSWORD` | token_manager.py |

**Tool**: `e_bulk_replace`

---

### Step 5: Bulk Replace - Service/Path Names

| Old | New | Files Affected |
|-----|-----|----------------|
| `"pinchr-mcp"` | `"botvegas-mcp"` | token_manager.py, pyproject.toml |
| `".pinchr"` | `".botvegas"` | token_manager.py |
| `b"pinchr-mcp-token-salt"` | `b"botvegas-mcp-token-salt"` | token_manager.py |
| `pinchr-default-key` | `botvegas-default-key` | token_manager.py |

**Tool**: `e_bulk_replace`

---

### Step 6: Bulk Replace - Brand Name in Text

| Old | New | Context |
|-----|-----|--------|
| `BotVegas MCP` | `BotVegas MCP` | Docstrings, comments |
| `BotVegas API` | `BotVegas API` | Docstrings |
| `BotVegas Poker` | `BotVegas Poker` | Docstrings |
| `BotVegas Team` | `BotVegas Team` | pyproject.toml |
| `BotVegas HTTP` | `BotVegas HTTP` | Docstrings |
| `for BotVegas` | `for BotVegas` | Docstrings |
| `on BotVegas` | `on BotVegas` | Docstrings |
| `the BotVegas` | `the BotVegas` | Docstrings |

**Tool**: `e_bulk_replace`

---

### Step 7: Update pyproject.toml

**File**: `mcp_server/pyproject.toml`

Changes:
1. `name = "pinchr-mcp"` → `name = "botvegas-mcp"`
2. `description` (already handled by brand replace)
3. `authors` (already handled by brand replace)
4. `keywords = [..., "pinchr"]` → `keywords = [..., "botvegas"]`
5. `pinchr-mcp = "botvegas_mcp.server:main"` → `botvegas-mcp = "botvegas_mcp.server:main"`
6. `packages = ["botvegas_mcp"]` → `packages = ["botvegas_mcp"]`

**Tool**: `e_edit_file` with `multi_edit`

---

### Step 8: Rewrite README.md

**File**: `mcp_server/README.md`

Complete rewrite with:
- Title: "BotVegas MCP Server"
- All tool names: `botvegas_*`
- Environment: `BOTVEGAS_API_URL`
- Module: `botvegas_mcp`
- MCP server name: `botvegas`

**Tool**: `fs_write_file`

---

### Step 9: Verification

1. Search for any remaining "pinchr" (case-insensitive)
2. Run tests: `cd mcp_server && pytest`
3. Test module load: `python -m botvegas_mcp --help`

---

## Rollback Plan

Since we're working in a NEW repo, rollback is simple:
- Delete the new repo and start fresh
- Pinchr repo remains completely untouched

---

## Post-Implementation

### In New Repo (botvegas-mcp)
- [ ] Verify all tests pass
- [ ] Test module load: `python -m botvegas_mcp --help`
- [ ] Set up CI/CD (GitHub Actions)
- [ ] Publish to PyPI as `botvegas-mcp`
- [ ] Create GitHub release

### In Pinchr Repo (optional, later)
- [ ] Add `botvegas-mcp` as dependency (when ready to switch)
- [ ] Update any scripts that reference `botvegas_mcp`
- [ ] Eventually deprecate `mcp_server/botvegas_mcp/`

### Symlink Strategy (for local dev)
```bash
# If you want to test new package in pinchr context:
cd /path/to/pinchr/mcp_server
mv botvegas_mcp botvegas_mcp.bak  # Backup original
ln -s /path/to/botvegas-mcp/botvegas_mcp botvegas_mcp
# Now pinchr tests use new code but with old import path
```

---

## Estimated Changes

| Category | Count |
|----------|-------|
| Directory rename | 1 |
| Class renames | 4 unique, ~13 occurrences |
| Module name changes | ~36 occurrences |
| Environment variables | 3 unique, ~6 occurrences |
| Service/path names | 4 unique, ~8 occurrences |
| Brand text changes | ~50 occurrences |
| README rewrite | 1 file |
| **Total** | **~112 changes** |

---

## New Repo Checklist

### Initial Setup
- [ ] Create new GitHub repo: `botvegas-mcp`
- [ ] Copy files from `pinchr/mcp_server/` to new repo
- [ ] Rename `botvegas_mcp/` to `botvegas_mcp/`
- [ ] Move `tests/` to root level
- [ ] Update `.gitignore`

### Rebranding (Steps 2-8 above)
- [ ] Bulk replace class names
- [ ] Bulk replace module names  
- [ ] Bulk replace environment variables
- [ ] Bulk replace service/path names
- [ ] Bulk replace brand text
- [ ] Update pyproject.toml
- [ ] Rewrite README.md

### Verification
- [ ] `pip install -e .`
- [ ] `python -m botvegas_mcp --help`
- [ ] `pytest` - all tests pass
- [ ] Search for remaining "pinchr" (should be zero)

### Publishing
- [ ] Create PyPI account/token
- [ ] `python -m build`
- [ ] `twine upload dist/*`
- [ ] Verify install: `pip install botvegas-mcp`
