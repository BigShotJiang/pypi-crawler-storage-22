# MCP Server Rebrand Investigation: Pinchr → BotVegas

**Date**: 2026-02-09  
**Status**: Investigation Complete  
**Confidence**: HIGH

## Problem Statement

The MCP server package is named `botvegas_mcp` and contains references to "Pinchr" throughout the codebase. Need to rebrand to "BotVegas" for consistency with the deployed product at botvegas.gg.

## Investigation Findings

### 1. Package Structure

```
mcp_server/
├── botvegas_mcp/           # ← RENAME to botvegas_mcp
│   ├── __init__.py
│   ├── __main__.py
│   ├── client.py
│   ├── server.py         # ~1948 lines
│   ├── token_manager.py
│   ├── transactions.py
│   └── wallet.py
├── tests/
│   ├── __init__.py
│   ├── test_client.py
│   ├── test_transactions.py
│   └── test_wallet.py
├── pyproject.toml
└── README.md
```

### 2. Changes Required

#### 2.1 Directory Rename
- `mcp_server/botvegas_mcp/` → `mcp_server/botvegas_mcp/`

#### 2.2 pyproject.toml Updates
| Current | New |
|---------|-----|
| `name = "pinchr-mcp"` | `name = "botvegas-mcp"` |
| `description = "MCP Server for BotVegas Poker..."` | `description = "MCP Server for BotVegas Poker..."` |
| `authors = [{name = "BotVegas Team"}]` | `authors = [{name = "BotVegas Team"}]` |
| `keywords = [..., "pinchr"]` | `keywords = [..., "botvegas"]` |
| `pinchr-mcp = "botvegas_mcp.server:main"` | `botvegas-mcp = "botvegas_mcp.server:main"` |
| `packages = ["botvegas_mcp"]` | `packages = ["botvegas_mcp"]` |

#### 2.3 README.md Updates
- All references to "Pinchr" → "BotVegas"
- Environment variable: `PINCHR_API_URL` → `BOTVEGAS_API_URL`
- Module name: `botvegas_mcp` → `botvegas_mcp`
- MCP server name: `pinchr` → `botvegas`
- Tool prefix references: `pinchr_*` → `botvegas_*` (already done in code)

#### 2.4 Code File Updates

**`__init__.py`** (5 matches):
- Docstring references to "Pinchr"
- Module name `botvegas_mcp`

**`__main__.py`** (2 matches):
- Docstring references to `botvegas_mcp`

**`client.py`** (9 matches):
- Class names: `PinchrAPIError` → `BotVegasAPIError`
- Class names: `PinchrClient` → `BotVegasClient`
- Docstrings referencing "Pinchr"

**`server.py`** (~10 matches):
- Docstrings referencing "Pinchr"
- Import: `from .client import PinchrAPIError, PinchrClient`
- Logger name: `"botvegas_mcp"` → `"botvegas_mcp"`
- Environment variable: `PINCHR_API_URL` → `BOTVEGAS_API_URL`
- Variable names: `PINCHR_API_BASE` → `BOTVEGAS_API_BASE`
- Log messages referencing "Pinchr"
- **NOTE**: Tool function names are ALREADY `botvegas_*` ✅

**`token_manager.py`** (6 matches):
- File path: `~/.pinchr/tokens.enc` → `~/.botvegas/tokens.enc`
- Keyring service: `"pinchr-mcp"` → `"botvegas-mcp"`
- Environment variable: `PINCHR_TOKEN_PASSWORD` → `BOTVEGAS_TOKEN_PASSWORD`
- Salt: `b"pinchr-mcp-token-salt"` → `b"botvegas-mcp-token-salt"`
- Docstring references

**`transactions.py`** (2 matches):
- Docstring references to "Pinchr"

**`wallet.py`** (1 match):
- Docstring reference to "Pinchr agents"
- **NOTE**: `WalletConfig` already uses `botvegas-agent` and `~/.config/botvegas/` ✅

#### 2.5 Test File Updates

**`tests/__init__.py`** (1 match):
- Docstring

**`tests/test_client.py`** (10 matches):
- Import: `from botvegas_mcp.client import PinchrClient, PinchrAPIError`
- Class names in tests
- Docstrings

**`tests/test_transactions.py`** (10 matches):
- Import: `from botvegas_mcp.transactions import ...`
- Patch paths: `'botvegas_mcp.transactions.*'`

**`tests/test_wallet.py`** (10+ matches):
- Import: `from botvegas_mcp.wallet import ...`
- Patch paths: `'botvegas_mcp.wallet.*'`

### 3. Summary of Changes

| Category | Count |
|----------|-------|
| Directory rename | 1 |
| pyproject.toml changes | 6 |
| README.md (full rewrite) | 1 |
| Python file string replacements | ~66 |
| Test file import/patch updates | ~30 |
| **Total touchpoints** | ~100+ |

### 4. Migration Considerations

#### Breaking Changes
- Environment variable: `PINCHR_API_URL` → `BOTVEGAS_API_URL`
- Environment variable: `PINCHR_TOKEN_PASSWORD` → `BOTVEGAS_TOKEN_PASSWORD`
- Token storage location: `~/.pinchr/` → `~/.botvegas/`
- Keyring service name: `pinchr-mcp` → `botvegas-mcp`
- Package install name: `pinchr-mcp` → `botvegas-mcp`
- Module import: `botvegas_mcp` → `botvegas_mcp`

#### Data Migration
- Existing tokens in `~/.pinchr/tokens.enc` won't auto-migrate
- Existing keyring entries under `pinchr-mcp` won't auto-migrate
- Users will need to re-authenticate or manually move tokens

**Recommendation**: Since this is pre-production, no migration needed. Clean slate.

### 5. What's Already Done

✅ Tool function names are already `botvegas_*`  
✅ `wallet.py` config uses `botvegas-agent` and `~/.config/botvegas/`  
✅ References to `$BOTVEGAS` token throughout wallet code

## Implementation Plan

1. **Rename directory**: `botvegas_mcp/` → `botvegas_mcp/`
2. **Bulk replace in Python files**:
   - `PinchrAPIError` → `BotVegasAPIError`
   - `PinchrClient` → `BotVegasClient`
   - `botvegas_mcp` → `botvegas_mcp`
   - `PINCHR_API_URL` → `BOTVEGAS_API_URL`
   - `PINCHR_API_BASE` → `BOTVEGAS_API_BASE`
   - `PINCHR_TOKEN_PASSWORD` → `BOTVEGAS_TOKEN_PASSWORD`
   - `pinchr-mcp` → `botvegas-mcp`
   - `~/.pinchr/` → `~/.botvegas/`
   - `b"pinchr-mcp-token-salt"` → `b"botvegas-mcp-token-salt"`
   - `Pinchr` → `BotVegas` (in docstrings/comments)
3. **Update pyproject.toml**
4. **Rewrite README.md**
5. **Run tests** to verify nothing broke

## Checkpoint

**Findings Summary**: The MCP server has ~100 touchpoints requiring "Pinchr" → "BotVegas" rebranding. Most are straightforward string replacements. Tool names are already correct.

**Confidence Level**: HIGH - This is a mechanical refactoring task with clear patterns.

**Question**: Should I proceed with implementation?
