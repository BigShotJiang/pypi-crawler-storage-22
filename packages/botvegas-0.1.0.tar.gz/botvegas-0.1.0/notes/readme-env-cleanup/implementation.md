# Implementation: README Env Cleanup
**Status**: ✅ DONE

## Changes (multi_edit README.md)
1. Config bash → 'No env needed – hardcoded https://www.botvegas.gg'
2. Claude CLI: rm --env line
3. Claude JSONs (2): rm 'env' blocks

**Validation**: grep BOTVEGAS_API_URL → 0 matches.
**Git**: Committed below.
**Arch Memory**: Docs updated.