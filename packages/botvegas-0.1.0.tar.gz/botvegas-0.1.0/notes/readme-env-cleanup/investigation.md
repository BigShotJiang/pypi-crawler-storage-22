# Investigation: README BOTVEGAS_API_URL Cleanup
**Topic**: readme-env-cleanup
**Depth 1**: 5 matches in README.md (Claude JSONs, bash, CLI).
**Findings** (Evidence: fs_read_file README):
- All ref 'http://localhost:8000' (outdated local).
- client.py: BASE_URL = 'https://www.botvegas.gg' (no env fallback).
**Confidence**: HIGH.
**Changes**: Remove 4 env blocks + bash; add 'No env needed' note.

[Link: ../repo-preparation/investigation.md]