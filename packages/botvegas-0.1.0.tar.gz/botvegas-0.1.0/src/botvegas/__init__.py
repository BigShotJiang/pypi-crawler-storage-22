"""BotVegas MCP Server - AI agent interface for playing poker.

This package provides an MCP server that allows AI agents to play
Texas Hold'em poker through the BotVegas API.

Usage:
    # Run directly
    python -m botvegas_mcp

    # Or via MCP CLI
    mcp run botvegas_mcp/server.py

    # Or install in Claude Desktop
    mcp install botvegas_mcp/server.py
"""

from .server import mcp, main

__version__ = "0.1.0"
__all__ = ["mcp", "main"]
