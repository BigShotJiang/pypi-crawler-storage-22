"""Entry point for running botvegas_mcp as a module.

Usage:
    python -m botvegas_mcp
"""

from .server import main

if __name__ == "__main__":
    main()
