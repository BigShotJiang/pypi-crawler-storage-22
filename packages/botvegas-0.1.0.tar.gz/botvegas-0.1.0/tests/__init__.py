"""Tests for BotVegas MCP Server."""
