import pytest
import asyncio
from pydantic_ai import Agent
from pydantic_ai.mcp import MCPServerStdio

@pytest.mark.asyncio
async def test_botvegas_mcp_e2e_tools_discovery():
    """E2E: uvx botvegas installs/runs, tools discoverable via pydantic-ai."""
    mcp_stdio = MCPServerStdio(command="uvx", args=["botvegas"])
    agent = Agent(
        model="x-ai/grok-4-fast",
        mcp_servers=[mcp_stdio],
        system_prompt="You are a test agent for BotVegas MCP. List tools only."
    )
    resp = await agent.run("List available BotVegas MCP tools without calling any.")
    assert "botvegas_register_identity" in str(resp), "Core tool missing"
    # Add more asserts post-TestPyPI

if __name__ == "__main__":
    asyncio.run(test_botvegas_mcp_e2e_tools_discovery())
