# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

from __future__ import annotations

__all__ = ("SyncQbloxSystem",)

import contextlib
import weakref
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import numpy as np
from boulderopalscaleupsdk.device.controller.qblox import (
    OutputSequencerAcquisitions,
    PreparedProgram,
    SequencerAddr,
    process_sequencer_output,
)

from boulderopalscaleup.qblox import arm_sequencers, execute_armed_sequencers
from boulderopalscaleup.runtime._sync.executable import ExecUnit, NoResourceProxy
from boulderopalscaleup.runtime.abstract import ExecutionMode
from boulderopalscaleup.runtime.systems.qblox import BaseQbloxSystem, ConcatenateData, QbloxRoutines

if TYPE_CHECKING:
    from collections.abc import Iterator

    from qblox_instruments import Cluster

RawT = dict[SequencerAddr, OutputSequencerAcquisitions]


@dataclass
class _ClusterProxy:
    # Since the executable will contained bound units that hold onto these proxies, we want to
    # ensure a user cannot unintentionally extend the lifetime of the parent system by holding onto
    # the executable!
    _sys: weakref.ReferenceType[SyncQbloxSystem]

    @contextlib.contextmanager
    def get(self) -> Iterator[dict[str, Cluster]]:
        sys = self._sys()
        if sys is None:  # pragma: no cover
            raise RuntimeError("Resource proxy for QBLOX cluster is out-of-bounds.")
        if sys._stack is None:  # system will unreference the stack when it is closed
            raise RuntimeError("QBLOX system has closed.")
        yield sys._stack


class SyncQbloxSystem(BaseQbloxSystem[ExecUnit], execution_mode=ExecutionMode.SYNC):
    def get_resource_proxy(self) -> _ClusterProxy:
        return _ClusterProxy(weakref.ref(self))

    def make_unit(self, node_id: str, data: Any, routine: QbloxRoutines) -> ExecUnit:
        match routine:
            case QbloxRoutines.RUN_PROGRAM_RAW:
                return ExecUnit(node_id, data, self.get_resource_proxy(), _exec_program_raw)
            case QbloxRoutines.RUN_PROGRAM_PROCESSED:
                return ExecUnit(node_id, data, self.get_resource_proxy(), _exec_program_processed)
            case QbloxRoutines.CONCAT:
                return ExecUnit(node_id, data, NoResourceProxy(), _run_concatenate)


def _exec_program_raw(
    program: PreparedProgram,
    cluster: dict[str, Cluster],
) -> dict[SequencerAddr, OutputSequencerAcquisitions]:
    armed = arm_sequencers(program, cluster)
    return execute_armed_sequencers(armed)


def _run_concatenate(
    data: ConcatenateData,
    _: None,
) -> dict[str, list[float]]:
    """Concatenate raw results from dependency units.

    Results are injected via set_results() by SyncExecutable before execution.
    """
    return _concatenate_raw_results(
        {kk: vv.get() for kk, vv in data.dep_proxies.items()},
        data.dep_programs,
    )


def _concatenate_raw_results(
    raw_results: dict[str, RawT],
    programs: dict[str, PreparedProgram],
) -> dict[str, list[float]]:
    combined_bins: dict[str, list[np.ndarray]] = {}

    # QBLOXController._flatten_sequencer_results
    for node_id, raw in raw_results.items():
        program = programs[node_id]
        for seq_addr, seq_output in raw.items():
            seq_prog = program.get_sequencer_program(seq_addr)
            seq_results = process_sequencer_output(seq_prog, seq_output)
            for result_key, result_bins in seq_results.bins.items():
                if result_key not in combined_bins:
                    combined_bins[result_key] = []
                combined_bins[result_key].append(result_bins)

    # QBLOXController._results_post_process
    ret: dict[str, list[float]] = {}
    for result_key, bins_list in combined_bins.items():
        concatenated = np.concatenate(bins_list)
        ret[f"{result_key}_i"] = np.real(concatenated).tolist()
        ret[f"{result_key}_q"] = np.imag(concatenated).tolist()

    return ret


def _exec_program_processed(
    program: PreparedProgram,
    cluster: dict[str, Cluster],
) -> dict[str, list[float]]:
    raw = _exec_program_raw(program, cluster)
    bins: dict[str, np.ndarray] = {}
    for seq_addr, seq_output in raw.items():
        seq_prog = program.get_sequencer_program(seq_addr)
        seq_results = process_sequencer_output(seq_prog, seq_output)
        bins |= seq_results.bins

    ret = {}
    for result_key, result_bins in bins.items():
        ret[f"{result_key}_i"] = np.real(result_bins).tolist()
        ret[f"{result_key}_q"] = np.imag(result_bins).tolist()
    return ret
