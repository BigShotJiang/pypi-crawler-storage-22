# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import qm

if TYPE_CHECKING:
    from boulderopalscaleupsdk.device.controller.quantum_machines import QuaProgram
    from qm.jobs.running_qm_job import RunningQmJob


def exec_qua_program(
    qua_program: QuaProgram,
    qm_instance: qm.QuantumMachine,
) -> dict[str, np.ndarray]:
    """Execute a Qua program and return formatted results.

    Parameters
    ----------
    qua_program : QuaProgram
        The Qua program to execute, containing both program and config.
    qm_instance : qm.QuantumMachine
        The Quantum Machine instance for executing programs.

    Returns
    -------
    dict[str, np.ndarray]
        Formatted results with stream names as keys and numpy arrays as values.
    """
    job = qm_instance.execute(qm.Program(program=qua_program.program))

    return _fetch_and_format_results(job)


def _fetch_and_format_results(job: RunningQmJob) -> dict[str, np.ndarray]:
    """Fetch results from a QM job and format them.

    Parameters
    ----------
    job: RunningQmJob
        The running Quantum Machines job (RunningQmJob or JobApi).

    Returns
    -------
    dict[str, np.ndarray]
        Results with stream names as keys and numpy arrays as values.
    """

    def _format(data):
        """Format structured arrays by extracting the 'value' field."""
        if (
            type(data) is np.ndarray
            and data.ndim > 0
            and len(data) > 0
            and type(data[0]) is np.void
            and len(data.dtype.names or []) == 1
        ):
            data = data["value"]
        return data

    result_handles = job.result_handles
    result_handles.wait_for_all_values()

    results = {}
    for stream_name in list(result_handles.keys()):
        if hasattr(result_handles, stream_name):
            fetched_data = result_handles.get(stream_name).fetch_all()  # type: ignore[union-attr]
            if fetched_data is not None:
                results[stream_name] = _format(fetched_data)

    return results
