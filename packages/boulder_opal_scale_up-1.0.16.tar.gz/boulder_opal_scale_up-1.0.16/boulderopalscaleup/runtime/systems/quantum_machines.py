# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

from __future__ import annotations

__all__ = (
    "OPXOctaveInfo",
    "OPXSystemInfo",
    "SyncOPXSystem",
)

import contextlib
import json
import logging
import weakref
from typing import TYPE_CHECKING, ClassVar

import qm
from boulderopalscaleupsdk.runtime.manifest import (
    ManifestNode,
    QuaProgramNode,
    SupportedSystem,
)
from pydantic import BaseModel
from qm.octave import QmOctaveConfig

from boulderopalscaleup.runtime._sync.executable import ExecUnit
from boulderopalscaleup.runtime._sync.quantum_machines import exec_qua_program
from boulderopalscaleup.runtime.abstract import ExecutionMode

if TYPE_CHECKING:
    from collections.abc import Iterator

    from boulderopalscaleup.runtime.abstract import ExecutableIntermediate
    from boulderopalscaleup.runtime.manifest import ManifestGraph

LOGGER = logging.getLogger(__name__)


class OPXOctaveInfo(BaseModel):
    """Information for an Octave device.

    Attributes
    ----------
    name : str
        Octave device name.
    host : str
        Hostname or IP address of the Octave.
    port : int
        Port number for Octave connection.
    """

    name: str
    host: str
    port: int


class OPXSystemInfo(BaseModel):
    """System information for OPX controllers.

    Attributes
    ----------
    exec_mode : ExecutionMode
        Execution mode (currently only SYNC supported).
    host : str
        Hostname or IP address of the Quantum Machines Manager.
    port : int
        Port number for QMM connection.
    octaves : list[OPXOctaveInfo]
        List of Octave devices info.
    """

    exec_mode: ExecutionMode = ExecutionMode.SYNC
    host: str
    port: int
    octaves: list[OPXOctaveInfo] = []

    @classmethod
    def loads(cls, data: str) -> OPXSystemInfo:
        """Deserialize system info from JSON string."""
        return cls.model_validate_json(data)

    def dumps(self) -> str:
        """Serialize system info to JSON string."""
        return self.model_dump_json()

    def build_system(self) -> SyncOPXSystem:
        """Build and initialize an OPX system.

        Connects to QMM with optional Octave configuration built from octaves list.

        Returns
        -------
        SyncOPXSystem
            Initialized OPX system ready for binding.
        """
        octave_config = None
        if self.octaves:
            octave_config = QmOctaveConfig()
            for octave in self.octaves:
                octave_config.add_device_info(
                    name=octave.name,
                    host=octave.host,
                    port=octave.port,
                )

        qmm = qm.QuantumMachinesManager(
            host=self.host,
            port=self.port,
            octave=octave_config,
        )

        return SyncOPXSystem(qmm=qmm)


class _QMProxy:
    """Resource proxy for Quantum Machine.

    Uses weak reference to prevent executables from extending system lifetime.
    """

    def __init__(self, sys_ref: weakref.ReferenceType[SyncOPXSystem]):
        self._sys = sys_ref

    @contextlib.contextmanager
    def get(self) -> Iterator[qm.QuantumMachine]:
        """Get managed access to the QM resource.

        Yields
        ------
        qm.QuantumMachine | qm.QmApi
            The Quantum Machine instance.

        Raises
        ------
        RuntimeError
            If the system has been garbage collected or closed.
        """
        sys = self._sys()
        if sys is None:  # pragma: no cover
            raise RuntimeError("Resource proxy for QM is out-of-bounds.")
        if sys._qm_instance is None:
            raise RuntimeError("OPX system has no QM instance.")

        yield sys._qm_instance


class SyncOPXSystem:
    """Synchronous execution system for OPX controllers.

    Attributes
    ----------
    implements : SupportedSystem
        Identifies this as a Quantum Machines system.
    exec_mode : ExecutionMode
        Synchronous execution mode.
    """

    implements: ClassVar[SupportedSystem] = SupportedSystem.QUANTUM_MACHINES
    exec_mode: ClassVar[ExecutionMode] = ExecutionMode.SYNC

    def __init__(
        self,
        qmm: qm.QuantumMachinesManager,
    ):
        """Initialize OPX system.

        Parameters
        ----------
        qmm : qm.QuantumMachinesManager
            Quantum Machines Manager instance.
        """
        self._qmm: qm.QuantumMachinesManager | None = qmm
        self._qm_instance: qm.QuantumMachine | None = None

    def close(self) -> None:
        """Close the system and release resources."""
        if self._qm_instance is not None:
            try:
                self._qm_instance.close()
            except Exception as e:  # noqa: BLE001
                LOGGER.warning("Failed to close QM instance: %s", e)
            self._qm_instance = None
        self._qmm = None

    def get_resource_proxy(self) -> _QMProxy:
        """Get resource proxy for Quantum Machine.

        Returns
        -------
        _QMProxy
            Resource proxy for QM instance.
        """
        return _QMProxy(weakref.ref(self))

    def bind(
        self,
        node: ManifestNode,
        _: ManifestGraph,
        intermediate: ExecutableIntermediate[ExecUnit],
    ) -> ExecutableIntermediate[ExecUnit]:
        """Bind a manifest node to an execution unit.

        Parameters
        ----------
        node : ManifestNode
            The manifest node to bind.
        graph : ManifestGraph
            The complete manifest graph for context.
        intermediate : ExecutableIntermediate[ExecUnit]
            The intermediate executable being constructed.

        Returns
        -------
        ExecutableIntermediate[ExecUnit]
            Updated intermediate with bound unit.

        Raises
        ------
        TypeError
            If node type is not supported by this system.
        """
        match node:
            case QuaProgramNode():
                self._bind_qua_program(node, intermediate)
            case _:  # pragma: no cover
                raise TypeError(
                    f"OPX runtime does not support node of type {type(node).__name__}",
                )
        return intermediate

    def _bind_qua_program(
        self,
        node: QuaProgramNode,
        intermediate: ExecutableIntermediate[ExecUnit],
    ) -> None:
        """Bind a QuaProgramNode to an execution unit.

        Parameters
        ----------
        node : QuaProgramNode
            The Qua program node to bind.
        intermediate : ExecutableIntermediate[ExecUnit]
            The intermediate executable being constructed.
        """
        config_json = node.data.config.root.model_dump_json(
            exclude={"qm_version"},
            exclude_none=True,
        )

        if self._qmm is None:
            raise RuntimeError("Cannot bind program: OPX system has been closed.")

        if self._qm_instance is None:
            qua_config = json.loads(config_json)
            self._qm_instance = self._qmm.open_qm(qua_config)  # type: ignore[assignment]

        unit = ExecUnit(
            id=node.id,
            data=node.data,
            resource_proxy=self.get_resource_proxy(),
            run_func=exec_qua_program,
        )
        intermediate.set_unit(node.id, unit)
