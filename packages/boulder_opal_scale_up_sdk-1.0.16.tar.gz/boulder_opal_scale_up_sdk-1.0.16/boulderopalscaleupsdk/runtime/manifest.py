# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

from __future__ import annotations

import enum
from typing import Annotated, Literal, Self

from pydantic import BaseModel, Field

from boulderopalscaleupsdk.device.controller.qblox import (
    PreparedProgram,  # noqa: TC001 - Required for pydantic model
)
from boulderopalscaleupsdk.device.controller.quantum_machines import QuaProgram  # noqa: TC001


class SupportedSystem(enum.StrEnum):
    QUANTUM_MACHINES = "QUANTUM_MACHINES"
    QBLOX = "QBLOX"


class Manifest(BaseModel):
    nodes: list[Node]
    end_node: str

    def dumps(self) -> str:
        """Serialize the manifest to a JSON string."""
        return self.model_dump_json()

    @classmethod
    def loads(cls, data: str) -> Self:
        """Deserialize the manifest from a JSON string."""
        return cls.model_validate_json(data)


class ManifestNode(BaseModel):
    system: SupportedSystem
    id: str
    depends_on: list[str] = Field(default_factory=list)


class PreparedProgramNode(ManifestNode):
    node_type: Literal["PreparedProgram"] = "PreparedProgram"
    system: SupportedSystem = SupportedSystem.QBLOX
    data: PreparedProgram


class QuaProgramNode(ManifestNode):
    node_type: Literal["QuaProgram"] = "QuaProgram"
    system: SupportedSystem = SupportedSystem.QUANTUM_MACHINES
    data: QuaProgram


class ConcatenateProgramResultsNode(ManifestNode):
    node_type: Literal["ConcatenateProgramResults"] = "ConcatenateProgramResults"
    system: SupportedSystem


Node = Annotated[
    PreparedProgramNode | QuaProgramNode | ConcatenateProgramResultsNode,
    Field(discriminator="node_type"),
]
