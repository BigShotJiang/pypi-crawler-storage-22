while True:
    input()
