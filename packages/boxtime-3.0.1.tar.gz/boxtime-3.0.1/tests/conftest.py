"""Shared fixtures for tests — mock asyncpg pool and Supabase client."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from boxtime.clients.cointime_client import Cointime


# ── asyncpg backend fixtures ─────────────────────────────────────────

@pytest.fixture
def mock_pool():
    """A MagicMock standing in for an asyncpg connection pool."""
    pool = AsyncMock()
    pool.fetchrow = AsyncMock(return_value=None)
    pool.fetch = AsyncMock(return_value=[])
    pool.close = AsyncMock()
    return pool


@pytest.fixture
def pg_cointime(mock_pool):
    """A Cointime instance using the asyncpg backend with a mock pool."""
    ct = Cointime(database_url="postgresql://test:5432/test")
    ct._pool = mock_pool
    return ct


# ── Supabase backend fixtures ────────────────────────────────────────

@pytest.fixture
def mock_sb():
    """A MagicMock standing in for a Supabase Client."""
    return MagicMock()


@pytest.fixture
def sb_cointime(mock_sb):
    """A Cointime instance using the Supabase backend with a mock client."""
    ct = Cointime()  # default = Supabase
    ct._sb = mock_sb
    return ct
