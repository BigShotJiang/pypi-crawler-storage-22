"""Pydantic models for boxtime."""

from boxtime.models.cointime.cointime_data_point import CointimeDataPoint

__all__ = [
    "CointimeDataPoint",
]
