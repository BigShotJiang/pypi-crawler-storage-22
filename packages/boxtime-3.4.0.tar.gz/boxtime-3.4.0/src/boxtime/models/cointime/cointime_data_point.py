"""CointimeDataPoint model — a single cointime observation with optional price."""

from typing import Optional

from pydantic import BaseModel


class CointimeDataPoint(BaseModel):
    """A cointime metric value at a specific block height with optional price.

    Returned by the convenience ``get_coinblocks_*`` methods on
    :class:`~boxtime.clients.cointime_client.Cointime`.
    """

    height: int
    """Block height."""

    timestamp: int
    """Block timestamp in milliseconds."""

    value: int
    """Cointime value in nanoERG-blocks (CBC, CBD, or CBS)."""

    price: Optional[float] = None
    """ERG/USD price at this timestamp (None if not requested or unavailable)."""
