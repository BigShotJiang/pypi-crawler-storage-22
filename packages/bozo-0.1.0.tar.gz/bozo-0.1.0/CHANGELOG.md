# Changelog

All notable changes to this project are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

---

## [0.1.0] - 2026-02-04

### Added

- **Core logging setup** with `bozo.setup()` one-liner configuration
- **Multiple output handlers**: console (colored), text files, JSON, HTTP shipping
- **Structured logging** with context-aware nested data
- **Sensitive data redaction** with `bozo.redact()` for passwords and secrets
- **Context management** with `bozo.log_context()` for request/operation tracking
- **Real-time web viewer** (optional) for log streaming and monitoring
- **Environment presets**: Development (pretty) and Production (plain) modes
- **Third-party suppression** to reduce noise from verbose libraries
- **Python warnings capture** routing warnings through structured logging
- **Automatic log rotation** with configurable directory management
- **Type-safe API** with full type hints for IDE support (Python 3.13+)
- **Thread-safe operations** for concurrent logging in multi-threaded environments
- **Bounded queue** for web viewer with configurable limits
- **File handler cleanup** with `max_runs_to_keep` parameter
- **Error file support** for separate ERROR+ level logging
- **HTTP endpoint support** for log aggregation platforms
- **Development-friendly defaults** requiring minimal configuration
- **Comprehensive test coverage** (81% coverage, 346 tests)

### Key Features

- Zero-config defaults suitable for most applications
- Simultaneous logging to multiple backends
- Sensible directory structure: `~/.local/share/bozo/{app}/`
- Optional real-time browser-based dashboard
- Full typing support for type checkers and IDE autocomplete
- MIT Licensed and open source

### Known Limitations

- Requires Python 3.13 or later
- Web viewer feature requires `fastapi` and `uvicorn` (installed via `bozo[viewer]`)
- HTTP log shipping requires network connectivity to endpoint

### Initial Release Notes

This is the first stable release of bozo. The library provides a complete,
production-ready logging solution that is:

- **Easy to use**: Single function call to set up logging
- **Powerful**: Multiple output formats and streaming capabilities
- **Safe**: Type-safe with comprehensive test coverage
- **Extensible**: Clean architecture for adding custom handlers

The API is stable and ready for production use.
