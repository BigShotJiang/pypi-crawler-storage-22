
# Security Policy

## Reporting a Vulnerability

If you discover a security issue, please **do not open a public issue**.

Instead, report it privately via email:

📧 **contact@tejusgupta.dev**

Please include:

- Description of the vulnerability
- Steps to reproduce (if applicable)
- Potential impact

I’ll do my best to respond promptly.

---

Thanks for helping keep the project secure.
