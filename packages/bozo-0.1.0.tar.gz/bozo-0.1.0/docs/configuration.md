---
layout: default
title: Configuration reference
nav_order: 3
---

# Configuration reference

This page documents every argument accepted by `bozo.setup()`. bozo uses a global configuration; call `setup()` once at application startup.

## `bozo.setup()` arguments

| Name | Type | Default | Behavior |
|---|---|---|---|
| `app_name` | `str` | required | Application name used for log file naming. |
| `environment` | `Environment` | `Environment.DEVELOPMENT` | Controls development vs production formatting. |
| `log_dir` | `str \| None` | `None` | Directory for log files. When `None`, a platform-appropriate user log directory is used. |
| `enable_console` | `bool` | `True` | Enables console logging (stdout). |
| `console_level` | `LogLevel` | `LogLevel.INFO` | Minimum level for console output. |
| `enable_file` | `bool` | `True` | Enables text file logging. |
| `file_level` | `LogLevel` | `LogLevel.DEBUG` | Minimum level for text file output. |
| `enable_error_file` | `bool` | `True` | Enables a separate error log file (ERROR+ only). |
| `enable_json` | `bool` | `True` | Enables JSON file logging. |
| `json_level` | `LogLevel` | `LogLevel.DEBUG` | Minimum level for JSON file output. |
| `enable_http` | `bool` | `False` | Enables HTTP log shipping. |
| `http_endpoint` | `str \| None` | `None` | Endpoint URL used for HTTP log shipping. Required when `enable_http=True`. |
| `enable_viewer` | `bool` | `False` | Enables the web viewer handler. Requires `bozo[viewer]`. |
| `viewer_queue_size` | `int` | `1000` | Max size of the in-memory queue for viewer streaming. |
| `viewer_host` | `str` | `"127.0.0.1"` | Host address for the viewer server. |
| `viewer_port` | `int` | `8080` | Port for the viewer server. |
| `viewer_export_limit` | `int` | `50000` | Max number of logs to export from the viewer. |
| `max_runs_to_keep` | `int \| None` | `None` | Max run directories to keep. `None` means unlimited. |
| `suppress_third_party` | `bool` | `True` | Reduces verbosity from common third-party libraries. |
| `capture_warnings` | `bool` | `True` | Routes Python warnings through logging. |

## Environments

- **DEVELOPMENT**: console output is optimized for readability (colored, human-friendly).
- **PRODUCTION**: console output is plain and stable for machine parsing.

## Outputs

- **Console**: stdout output with a configurable minimum level.
- **File**: text log file written to the configured log directory.
- **Error file**: a separate file containing ERROR and CRITICAL logs only.
- **JSON**: JSON line output for ingestion by log systems.
- **HTTP**: sends structured logs to an external viewer.

## Safe defaults and global rules

- Console, file, JSON, and error file logging are enabled by default.
- HTTP and viewer outputs are disabled by default.
- The configuration is global for the process. Call `setup()` once at startup.
