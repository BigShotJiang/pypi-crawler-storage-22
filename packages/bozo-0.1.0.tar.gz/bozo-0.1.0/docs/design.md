---
layout: default
title: Design philosophy
nav_order: 10
---

# Design philosophy

This page explains the goals and non-goals of bozo. It exists to prevent ambiguity and reduce long-term maintenance friction.

## Why bozo exists

bozo provides a structured logging system that is reliable, typed, and safe in production. It focuses on predictable output formats and operational stability.

## What bozo does not try to solve

- It is not a log aggregation platform.
- It does not provide tracing or metrics.
- It does not manage external storage or retention policies.
- It does not replace application monitoring tools.

## Why the API is minimal

A small API surface keeps usage consistent and reduces long-term breaking changes. bozo exposes only the functions needed for configuration, logging, context, and optional viewing.

## Logging must never crash applications

Logging should be non-fatal. bozo is designed so that log calls do not bring down the process. This is critical in production environments where logs are diagnostic, not essential for correctness.

## Why the viewer is optional

The viewer is a development tool. It adds dependencies and runtime behavior that is unnecessary for production use. Keeping it optional preserves a minimal and stable core.

## Stability and compatibility goals

- Public API changes are minimized.
- Default behavior is conservative and safe.
- Backward compatibility is preferred when possible.
