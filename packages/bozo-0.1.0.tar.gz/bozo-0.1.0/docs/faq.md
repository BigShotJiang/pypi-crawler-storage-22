---
layout: default
title: FAQ
nav_order: 9
---

# FAQ

## Where are logs stored?

By default, bozo writes logs to a platform-appropriate user log directory. You can override this with `log_dir` in `setup()`.

## Can bozo be used with existing logging?

bozo configures logging globally. If you already have logging configured, evaluate whether you want bozo to replace that configuration at startup.

## How do I disable certain outputs?

Use the `enable_*` flags in `setup()`:

```python
bozo.setup(
    "myapp",
    enable_console=True,
    enable_file=False,
    enable_json=False,
    enable_http=False,
)
```

## The viewer is not working. What should I check?

- Install viewer dependencies: `pip install bozo[viewer]`
- Ensure `enable_viewer=True` in `setup()`
- Confirm the host/port are reachable

## Are there performance concerns?

Logging has overhead, especially at high volume. Use appropriate log levels, avoid logging large payloads, and disable outputs you do not need.
