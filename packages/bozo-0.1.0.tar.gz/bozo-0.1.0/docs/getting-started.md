---
layout: default
title: Getting started
nav_order: 2
---

# Getting started

## Installation

```bash
pip install bozo
# Optional web viewer
pip install bozo[viewer]
```

## First-time setup

Call `setup()` once at application startup. bozo uses a global configuration.

```python
import bozo

bozo.setup("myapp")
```

## Getting a logger

Use `get(__name__)` to create a structured logger for a module.

```python
log = bozo.get(__name__)
```

## Structured logging example

```python
log.info("user_login", user_id=42, email="user@example.com")
```
