---
layout: default
title: Overview
description: Official documentation for bozo
nav_order: 1
---

# bozo documentation

bozo is a production-grade structured logging library for Python. It is strongly typed (Python 3.13+), built on top of structlog, and enforces JSON-safe log values. Logging is designed to be non-fatal: log calls should not crash your application.

## Minimal example

```python
import bozo

bozo.setup("myapp")
log = bozo.get(__name__)
log.info("started", version="0.1.0")
```

## Documentation sections

- [Getting started](getting-started)
- [Configuration reference](configuration)
- [Logging](logging)
- [Context](context)
- [Redaction](redaction)
- [Web viewer](viewer)
- [Typing](typing)
- [FAQ](faq)
- [Design philosophy](design)
