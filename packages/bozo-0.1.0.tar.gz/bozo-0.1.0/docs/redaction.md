---
layout: default
title: Redaction
nav_order: 6
---

# Redaction

bozo provides redaction to avoid emitting sensitive values into logs.

## Why redaction exists

Logs often include request bodies, tokens, or credentials. Redaction allows you to keep the structure of a log entry while removing the sensitive value.

## How `bozo.redact()` works

`bozo.redact()` returns a placeholder value that is safe to log.

```python
log.info("auth", username="alice", password=bozo.redact("secret"))
```

The original value is not logged.

## Security guarantees

- The redacted value never appears in log output.
- The placeholder is consistent and explicit.

## What redaction does not do

- It does not encrypt or otherwise protect the original value in memory.
- It does not scan or scrub arbitrary objects or dictionaries.
- It does not prevent sensitive values from being logged if you pass them directly.

## Best practices

- Use `bozo.redact()` at the call site for any secret.
- Prefer explicit whitelisting of safe fields.
- Avoid logging full request bodies unless required.
