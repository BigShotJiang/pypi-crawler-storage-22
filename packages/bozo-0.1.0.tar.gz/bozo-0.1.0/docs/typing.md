---
layout: default
title: Typing
nav_order: 8
---

# Typing

bozo is designed to be strongly typed and safe to use with static type checkers.

## Type guarantees

- The public API is fully type-annotated.
- Log values are restricted to JSON-safe types.
- Type checking helps prevent invalid log values at development time.

## `LogValue`

`LogValue` is the accepted type for structured log fields:

```
str | int | float | bool | None | list[LogValue] | dict[str, LogValue]
```

This restriction ensures logs are JSON-safe and prevents runtime serialization errors.

## How typing prevents logging failures

By rejecting unsupported types in type checking, you can catch mistakes before runtime. This aligns with bozo’s goal that logging should not crash applications.

## Type checkers

bozo works with common tools:

- **mypy**
- **pyright**

If a value is not compatible with `LogValue`, convert it to a JSON-safe type explicitly.

## `.pyi` stubs and `py.typed`

bozo ships inline type hints and includes a `py.typed` marker so type checkers treat the package as typed. Separate `.pyi` stub files are not required.
