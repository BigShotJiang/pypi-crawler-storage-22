---
layout: default
title: Web viewer
nav_order: 7
---

# Web viewer

The web viewer provides a real-time view of logs in a browser. It is optional and intended primarily for development and debugging.

## When to use it

- **Development**: useful for local inspection and quick troubleshooting.
- **Production**: typically disabled; use log aggregation systems instead.

## Enable the viewer

Install optional dependencies:

```bash
pip install bozo[viewer]
```

Enable the viewer during setup:

```python
bozo.setup("myapp", enable_viewer=True)
```

## Start and stop

```python
url = bozo.start_viewer(open_browser=True)
# ...
bozo.stop_viewer()
```

## Memory safety

The viewer uses a bounded in-memory queue. When the queue is full, older entries may be dropped to prevent unbounded memory growth. You can adjust the limit with `viewer_queue_size`.

## Optional dependencies

The viewer depends on `fastapi`, `uvicorn`, and `aiofiles`. These are only installed when using `bozo[viewer]`.
