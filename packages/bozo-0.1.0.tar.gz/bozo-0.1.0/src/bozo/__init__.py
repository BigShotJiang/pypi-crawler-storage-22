# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""bozo - Production-grade structured logging with optional real-time web viewer.

Simple, powerful, and fully typed.

Basic usage:
    >>> import bozo

    >>> bozo.setup("myapp")
    >>> log = bozo.get(__name__)

    >>> log.info("started", version="1.0.0")

    >>> with bozo.log_context(request_id="abc-123"):
    >>>     log.info("processing", user_id=42)
    >>>     log.warning("sensitive", password=bozo.redact("secret"))

Web viewer (requires: pip install bozo[viewer]):
    >>> bozo.start_viewer(open_browser=True)
"""

from importlib.metadata import version as pkg_version

from bozo._main import (
    clear_context,
    get,
    log_context,
    redact,
    set_context,
    setup,
    start_viewer,
    stop_viewer,
)
from bozo._types import (
    AppName,
    BoundLogger,
    Environment,
    LogLevel,
    ModuleName,
    RedactedValue,
)

__version__ = pkg_version("bozo")

__all__ = [
    "AppName",
    "BoundLogger",
    "Environment",
    "LogLevel",
    "ModuleName",
    "RedactedValue",
    "clear_context",
    "get",
    "log_context",
    "redact",
    "set_context",
    "setup",
    "start_viewer",
    "stop_viewer",
]
