# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Run directory cleanup for bozo.

Manages old run directories based on max_runs_to_keep configuration.
"""

from __future__ import annotations

import operator
import shutil
import uuid
import warnings
from pathlib import Path
from typing import TYPE_CHECKING

from bozo._types import RunId

if TYPE_CHECKING:
    from bozo._types import LogDirPath
else:
    LogDirPath = str


def is_valid_run_id(name: str) -> bool:
    """Check if a directory name is a valid UUID (run_id).

    Args:
        name: Directory name to check.

    Returns:
        True if the name is a valid UUID, False otherwise.
    """
    try:
        uuid.UUID(name)
    except ValueError:
        return False
    return True


def cleanup_old_runs(
    log_dir: LogDirPath,
    max_runs_to_keep: int,
    current_run_id: RunId,
) -> int:
    """Remove old run directories beyond the maximum to keep.

    Directories are sorted by modification time (newest first).
    The current run is never deleted.

    Args:
        log_dir: Path to the log directory containing run subdirectories.
        max_runs_to_keep: Maximum number of run directories to retain.
        current_run_id: The current run ID (will not be deleted).

    Returns:
        Number of directories deleted.

    Raises:
        ValueError: If max_runs_to_keep is less than 1.
    """
    if max_runs_to_keep < 1:
        msg = "max_runs_to_keep must be >= 1"
        raise ValueError(msg)

    log_path = Path(log_dir)
    if not log_path.exists():
        return 0

    # Get all valid run directories
    run_dirs: list[tuple[Path, float]] = []
    for entry in log_path.iterdir():
        if entry.is_dir() and is_valid_run_id(entry.name):
            # Don't include current run in cleanup consideration
            if entry.name == current_run_id:
                continue
            try:
                mtime = entry.stat().st_mtime
                run_dirs.append((entry, mtime))
            except OSError:
                # Skip if we can't stat the directory
                continue

    # Sort by modification time (newest first)
    run_dirs.sort(key=operator.itemgetter(1), reverse=True)

    # Keep max_runs_to_keep - 1 (current run counts as 1)
    dirs_to_keep = max_runs_to_keep - 1
    dirs_to_delete = run_dirs[dirs_to_keep:]

    deleted_count = 0
    for dir_path, _ in dirs_to_delete:
        try:
            shutil.rmtree(dir_path)
            deleted_count += 1
        except OSError as e:
            warnings.warn(
                f"[bozo] Failed to delete old run directory {dir_path}: {e}",
                stacklevel=2,
            )

    if deleted_count > 0:
        warnings.warn(
            (
                f"[bozo] Cleaned up {deleted_count} old run director"
                f"{'ies' if deleted_count > 1 else 'y'}"
            ),
            stacklevel=2,
        )

    return deleted_count


def list_runs(log_dir: LogDirPath) -> list[tuple[RunId, float, int]]:
    """List all run directories with metadata.

    Args:
        log_dir: Path to the log directory.

    Returns:
        List of tuples: (run_id, created_timestamp, log_file_count)
        Sorted by creation time (newest first).
    """
    log_path = Path(log_dir)
    if not log_path.exists():
        return []

    runs: list[tuple[RunId, float, int]] = []
    for entry in log_path.iterdir():
        if entry.is_dir() and is_valid_run_id(entry.name):
            try:
                mtime = entry.stat().st_mtime
                # Count log files in the directory
                log_count = sum(1 for f in entry.iterdir() if f.is_file())
                runs.append((RunId(entry.name), mtime, log_count))
            except OSError:
                continue

    # Sort by modification time (newest first)
    runs.sort(key=operator.itemgetter(1), reverse=True)
    return runs
