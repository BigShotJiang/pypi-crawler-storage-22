# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Context management for bozo.

Thread-safe and async-safe context binding using structlog.contextvars.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import TYPE_CHECKING

from structlog.contextvars import (
    bind_contextvars,
    clear_contextvars,
    unbind_contextvars,
)

if TYPE_CHECKING:
    from collections.abc import Iterator

    from bozo._types import LogValue
else:
    Iterator = object

    LogValue = object


def set_context(**kwargs: LogValue) -> None:
    """Set logging context (thread/async-safe).

    Context values are automatically included in all subsequent log entries
    until cleared.

    Example:
        bozo.set_context(request_id='req-123', user_id=456)
        log.info("processing")  # includes request_id and user_id

    Args:
        **kwargs: Key-value pairs to add to logging context.
    """
    bind_contextvars(**kwargs)


def clear_context(*keys: str) -> None:
    """Clear specific context keys or all context.

    Example:
        bozo.clear_context('request_id', 'user_id')  # Clear specific keys
        bozo.clear_context()  # Clear all context

    Args:
        *keys: Specific keys to clear. If empty, clears all context.
    """
    if keys:
        unbind_contextvars(*keys)
    else:
        clear_contextvars()


@contextmanager
def log_context(**kwargs: LogValue) -> Iterator[None]:
    """Temporary logging context (thread/async-safe).

    Context is automatically cleared when exiting the context manager.

    Example:
        with bozo.log_context(request_id='req-123'):
            log.info("processing")  # includes request_id
        log.info("done")  # request_id cleared

    Args:
        **kwargs: Key-value pairs to add to logging context.

    Yields:
        None
    """
    bind_contextvars(**kwargs)
    try:
        yield
    finally:
        unbind_contextvars(*kwargs.keys())
