# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Structlog processors and formatter configuration for bozo.

Fully typed structlog integration with shared processors.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import structlog
from structlog.dev import ConsoleRenderer

from bozo._types import (
    Environment,
)

if TYPE_CHECKING:
    import logging

    from bozo._types import (
        LogProcessor,
    )
else:
    logging = object

    LogProcessor = object


def get_shared_processors() -> list[LogProcessor]:
    """Get shared structlog processors.

    These processors are applied to all log entries regardless of output.

    Returns:
        List of structlog processors.
    """
    return [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,  # Add logger name to all logs
        structlog.stdlib.PositionalArgumentsFormatter(),  # Format %s args into message
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]


class MinimalConsoleRenderer:
    """Custom console renderer that only shows: time, level, logger name, and message.

    Strips all extra fields/context for clean console output.
    """

    def __init__(self, colors: bool = True) -> None:
        self._colors = colors
        self._console_renderer = ConsoleRenderer(colors=colors)

    def __call__(
        self,
        _: structlog.types.WrappedLogger,
        __: str,
        event_dict: structlog.types.EventDict,
    ) -> str:
        # Extract only the fields we want
        timestamp = event_dict.get("timestamp", "")
        level = event_dict.get("level", "")
        logger_name = event_dict.get("logger", "")
        event = event_dict.get("event", "")

        # Format level with colors if enabled
        if self._colors:
            level_colors = {
                "debug": "\x1b[2m",  # dim
                "info": "\x1b[34m",  # blue
                "warning": "\x1b[33m",  # yellow
                "error": "\x1b[31m",  # red
                "critical": "\x1b[31;1m",  # bold red
            }
            timestamp_color = "\x1b[90m"  # bright black
            level_color = level_colors.get(level, "")
            logger_name_color = "\x1b[36m"  # cyan
            event_color = "\x1b[97m"  # bold_white
            reset = "\x1b[0m"

            timestamp_str = f"{timestamp_color}{timestamp}{reset}"
            level_str = f"[{level_color}{level:<8}{reset}]"
            logger_name_str = f"{logger_name_color}{logger_name}{reset}"
            event_str = f"{event_color}{event}{reset}"

        else:
            timestamp_str = f"{timestamp}"
            level_str = f"[{level:<8}]"
            logger_name_str = f"{logger_name}"
            event_str = f"{event}"

        # Build minimal output: timestamp level logger message
        return f"{timestamp_str} {level_str} {logger_name_str:<30} - {event_str}"


def configure_structlog(shared_processors: list[LogProcessor]) -> None:
    """Configure structlog with shared processors.

    This sets up structlog to work with Python's standard logging,
    applying the shared processors to all log entries.

    Args:
        shared_processors: Processors to apply to all log entries.
    """
    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


def build_formatters(
    shared_processors: list[LogProcessor],
    environment: Environment,
) -> tuple[logging.Formatter, logging.Formatter, logging.Formatter]:
    """Build formatters for console, text file, and JSON output.

    Args:
        shared_processors: Processors to apply in the formatter chain.
        environment: Application environment (affects console coloring).

    Returns:
        Tuple of (console_formatter, text_formatter, json_formatter).
    """
    # Console formatter - minimal output: time, level, logger, message only
    console_formatter = structlog.stdlib.ProcessorFormatter(
        processor=MinimalConsoleRenderer(colors=environment == Environment.DEVELOPMENT),
        foreign_pre_chain=shared_processors,
    )

    # Text file formatter - key=value pairs (includes logger name)
    text_formatter = structlog.stdlib.ProcessorFormatter(
        processor=structlog.processors.KeyValueRenderer(),
        foreign_pre_chain=shared_processors,
    )

    # JSON formatter - machine-readable (includes logger name)
    json_formatter = structlog.stdlib.ProcessorFormatter(
        processor=structlog.processors.JSONRenderer(),
        foreign_pre_chain=shared_processors,
    )

    return console_formatter, text_formatter, json_formatter
