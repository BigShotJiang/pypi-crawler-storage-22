# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Logging handlers for bozo.

Includes console, file, JSON, HTTP, and web viewer handlers.
All handlers are strictly typed.
"""

from __future__ import annotations

import atexit
import logging
import logging.handlers
import queue
import sys
import threading
from typing import TYPE_CHECKING, ClassVar, override

import colorlog
import requests

from bozo._types import (
    HTTP_STATUS_CODE_200_OK,
    LOG_FILE_ENCODING,
    Environment,
)
from bozo._viewer._queue import BoundedLogQueue

if TYPE_CHECKING:
    from bozo._types import (
        BackupCount,
        BatchSize,
        FlushInterval,
        HttpEndpoint,
        LogFilePath,
        LogLevel,
        MaxBytes,
        QueueSize,
        RunId,
    )
else:
    BackupCount = int
    BatchSize = int
    FlushInterval = float
    HttpEndpoint = str
    LogFilePath = str
    LogLevel = object
    MaxBytes = int
    QueueSize = int
    RunId = str

logger = logging.getLogger(__name__)


# =============================================================================
# Custom Handler Classes
# =============================================================================


class JSONRotatingFileHandler(logging.handlers.RotatingFileHandler):
    """RotatingFileHandler that identifies itself as a JSON handler.

    Used by formatter application logic to select JSON formatter.
    """

    is_json: ClassVar[bool] = True

    def __init__(
        self,
        filename: LogFilePath,
        max_bytes: MaxBytes,
        backup_count: BackupCount,
        encoding: str = LOG_FILE_ENCODING,
    ) -> None:
        super().__init__(
            filename=filename,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding=encoding,
        )


class AsyncHTTPHandler(logging.Handler):
    """Non-blocking HTTP handler that batches logs and sends asynchronously.

    Uses a queue and background thread to avoid blocking the main application.
    Logs are batched and sent at configurable intervals.
    """

    is_http: ClassVar[bool] = True

    def __init__(
        self,
        endpoint_url: HttpEndpoint,
        batch_size: BatchSize,
        flush_interval: FlushInterval,
    ) -> None:
        super().__init__()
        self._endpoint_url: HttpEndpoint = endpoint_url
        self._batch_size: BatchSize = batch_size
        self._flush_interval: FlushInterval = flush_interval

        # Internal queue (bounded to prevent memory issues)
        self._log_queue: queue.Queue[str] = queue.Queue(maxsize=1000)

        # Shutdown coordination
        self._shutdown_flag: threading.Event = threading.Event()

        # Background worker thread
        self._worker_thread: threading.Thread = threading.Thread(
            target=self._batch_worker,
            daemon=True,
            name="bozo-http-worker",
        )
        self._worker_thread.start()

        # Register cleanup on exit
        atexit.register(self.close)

    @override
    def emit(self, record: logging.LogRecord) -> None:
        """Add log to queue (non-blocking)."""
        try:
            log_entry = self.format(record)
            # Non-blocking put - drop if queue full
            self._log_queue.put_nowait(log_entry)
        except queue.Full:
            # Silently drop if queue is full (don't block the app)
            pass
        except Exception:  # noqa: BLE001
            # Only handle expected formatting / logging errors
            self.handleError(record)

    def _batch_worker(self) -> None:
        """Background worker that batches and sends logs."""
        batch: list[str] = []

        while not self._shutdown_flag.is_set():
            try:
                # Wait for log with timeout
                log_entry = self._log_queue.get(timeout=0.1)
                batch.append(log_entry)

                # Send batch if full
                if len(batch) >= self._batch_size:
                    self._send_batch(batch)
                    batch = []

            except queue.Empty:
                # Send partial batch if we have logs waiting
                if batch:
                    self._send_batch(batch)
                    batch = []
            except Exception as e:
                err_str = f"HTTP batch worker encountered an error: {e}"
                logger.exception(err_str)

        # Send remaining logs on shutdown
        if batch:
            self._send_batch(batch)

    def _send_batch(self, batch: list[str]) -> None:
        """Send a batch of logs to the HTTP endpoint."""
        if not batch:
            return

        try:
            response = requests.post(
                self._endpoint_url,
                json={"logs": batch},
                timeout=5,
            )

            if response.status_code != HTTP_STATUS_CODE_200_OK:
                logger.error("[bozo] HTTP log send failed: %s", response.status_code)

        except requests.exceptions.RequestException as e:
            logger.exception(
                "[bozo] Failed to send logs to %s: %s",
                self._endpoint_url,
                f"{type(e).__name__}",
            )
        except Exception as e:
            err_str = f"Unexpected error sending logs to {self._endpoint_url}: {e}"
            logger.exception(err_str)

    @override
    def close(self) -> None:
        """Gracefully shutdown the handler."""
        self._shutdown_flag.set()

        # Wait for worker thread to finish
        self._worker_thread.join(timeout=5)

        if self._worker_thread.is_alive():
            logger.warning("[bozo] HTTP log worker thread did not shut down in time")

        super().close()


class WebViewerHandler(logging.Handler):
    """Handler that publishes logs to the web viewer's bounded queue.

    Enables real-time SSE streaming to connected web viewers.
    """

    is_viewer: ClassVar[bool] = True

    def __init__(self, run_id: RunId, queue_size: QueueSize) -> None:
        super().__init__()
        self._run_id: RunId = run_id
        self._queue_size: QueueSize = queue_size
        self._queue: BoundedLogQueue | None = None

    def _ensure_queue(self) -> BoundedLogQueue:
        """Lazily initialize the queue.

        Returns:
            The BoundedLogQueue instance.
        """
        if self._queue is None:
            self._queue = BoundedLogQueue.get_or_create(self._run_id, self._queue_size)
        return self._queue

    @override
    def emit(self, record: logging.LogRecord) -> None:
        """Format and push log to viewer queue."""
        try:
            log_entry = self.format(record)
            queue = self._ensure_queue()
            queue.put_nowait(log_entry)
        except Exception:  # noqa: BLE001
            self.handleError(record)


# =============================================================================
# Handler Builder Functions
# =============================================================================


def build_console_handler(
    environment: Environment,
    level: LogLevel,
) -> logging.Handler:
    """Build a console (stdout) handler.

    In development: colorized output via colorlog.
    In production: plain text output.

    Args:
        environment: Current environment (dev or prod).
        level: Minimum log level for console output.

    Returns:
        Configured console logging handler.
    """
    handler = logging.StreamHandler(sys.stdout)

    formatter: logging.Formatter

    if environment == Environment.DEVELOPMENT:
        formatter = colorlog.ColoredFormatter(
            "%(log_color)s%(asctime)s | %(levelname)-8s%(reset)s | "
            "%(blue)s%(name)s%(reset)s | %(message)s",
            datefmt="%H:%M:%S",
            log_colors={
                "DEBUG": "cyan",
                "INFO": "green",
                "WARNING": "yellow",
                "ERROR": "red",
                "CRITICAL": "bold_red",
            },
        )
    else:
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

    handler.setFormatter(formatter)
    handler.setLevel(level.to_logging_level())
    return handler


def build_text_file_handler(
    file_path: LogFilePath,
    max_bytes: MaxBytes,
    backup_count: BackupCount,
    level: LogLevel,
) -> logging.handlers.RotatingFileHandler:
    """Build a rotating text file handler.

    Args:
        file_path: Path to the log file.
        max_bytes: Maximum size of each log file before rotation.
        backup_count: Number of backup files to keep.
        level: Minimum log level for file output.

    Returns:
        Configured rotating file logging handler.
    """
    handler = logging.handlers.RotatingFileHandler(
        filename=file_path,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding=LOG_FILE_ENCODING,
    )
    handler.setLevel(level.to_logging_level())
    return handler


def build_error_file_handler(
    file_path: LogFilePath,
    max_bytes: MaxBytes,
    backup_count: BackupCount,
) -> logging.handlers.RotatingFileHandler:
    """Build a rotating error file handler (ERROR+ only).

    Args:
        file_path: Path to the error log file.
        max_bytes: Maximum size of each log file before rotation.
        backup_count: Number of backup files to keep.

    Returns:
        Configured rotating error file logging handler.
    """
    handler = logging.handlers.RotatingFileHandler(
        filename=file_path,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding=LOG_FILE_ENCODING,
    )
    handler.setLevel(logging.ERROR)
    return handler


def build_json_file_handler(
    file_path: LogFilePath,
    max_bytes: MaxBytes,
    backup_count: BackupCount,
    level: LogLevel,
) -> JSONRotatingFileHandler:
    """Build a rotating JSON file handler.

    Args:
        file_path: Path to the JSON log file.
        max_bytes: Maximum size of each log file before rotation.
        backup_count: Number of backup files to keep.
        level: Minimum log level for JSON file output.

    Returns:
        Configured rotating JSON file logging handler.
    """
    handler = JSONRotatingFileHandler(
        filename=file_path,
        max_bytes=max_bytes,
        backup_count=backup_count,
    )
    handler.setLevel(level.to_logging_level())
    return handler


def build_http_handler(
    endpoint_url: HttpEndpoint,
    batch_size: BatchSize,
    flush_interval: FlushInterval,
    level: LogLevel,
) -> AsyncHTTPHandler:
    """Build an async HTTP log shipping handler.

    Args:
        endpoint_url: HTTP endpoint URL for log shipping.
        batch_size: Number of logs to batch before sending.
        flush_interval: Time interval (seconds) to flush logs.
        level: Minimum log level for HTTP output.

    Returns:
        Configured async HTTP logging handler.
    """
    handler = AsyncHTTPHandler(
        endpoint_url=endpoint_url,
        batch_size=batch_size,
        flush_interval=flush_interval,
    )
    handler.setLevel(level.to_logging_level())
    return handler


def build_viewer_handler(
    run_id: RunId,
    queue_size: QueueSize,
    level: LogLevel,
) -> WebViewerHandler:
    """Build a web viewer handler for SSE streaming.

    Args:
        run_id: Current run identifier.
        queue_size: Maximum size of the in-memory log queue.
        level: Minimum log level for viewer output.

    Returns:
        Configured web viewer logging handler.
    """
    handler = WebViewerHandler(run_id=run_id, queue_size=queue_size)
    handler.setLevel(level.to_logging_level())
    return handler
