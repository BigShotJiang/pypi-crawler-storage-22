# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Main module for bozo.

Provides setup and core logging functions.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import TYPE_CHECKING, cast

import structlog

from bozo._context import clear_context as _clear_context
from bozo._context import log_context as _log_context
from bozo._context import set_context as _set_context
from bozo._models import LoggingConfig
from bozo._state import set_config
from bozo._types import (
    REDACTED_PLACEHOLDER,
    Environment,
    ExportLimit,
    HostAddress,
    LogLevel,
    PortNumber,
    QueueSize,
)
from bozo._viewer import start_viewer as _start_viewer
from bozo._viewer import stop_viewer as _stop_viewer

if TYPE_CHECKING:
    from collections.abc import Iterator

    from bozo._types import (
        AppName,
        BoundLogger,
        LogValue,
        ModuleName,
        RedactedValue,
    )
else:
    Iterator = object

    AppName = object
    BoundLogger = object
    LogValue = object
    ModuleName = object
    RedactedValue = object


def setup(  # noqa: PLR0913
    app_name: AppName,
    *,
    environment: Environment = Environment.DEVELOPMENT,
    log_dir: str | None = None,
    # Console options
    enable_console: bool = True,
    console_level: LogLevel = LogLevel.INFO,
    # File options
    enable_file: bool = True,
    file_level: LogLevel = LogLevel.DEBUG,
    enable_error_file: bool = True,
    # JSON options
    enable_json: bool = True,
    json_level: LogLevel = LogLevel.DEBUG,
    # HTTP shipping options
    enable_http: bool = False,
    http_endpoint: str | None = None,
    # Viewer options
    enable_viewer: bool = False,
    viewer_queue_size: int = 1000,
    viewer_host: str = "127.0.0.1",
    viewer_port: int = 8080,
    viewer_export_limit: int = 50000,
    # Cleanup options
    max_runs_to_keep: int | None = None,
    # Third-party suppression
    suppress_third_party: bool = True,
    # Warnings capture
    capture_warnings: bool = True,
) -> None:
    """Setup logging with sensible defaults.

    This is the main entry point for configuring bozo. Call this once
    at application startup before creating any loggers.

    Args:
        app_name: Application name (used for log file naming).
        environment: 'development' (colored output) or 'production' (plain).
        log_dir: Directory for log files (default: platformdirs user_log_path).
        enable_console: Enable console (stdout) logging.
        console_level: Minimum level for console output.
        enable_file: Enable text file logging.
        file_level: Minimum level for text file output.
        enable_error_file: Enable separate error log file (ERROR+ only).
        enable_json: Enable JSON file logging.
        json_level: Minimum level for JSON file output.
        enable_http: Enable HTTP log shipping.
        http_endpoint: HTTP endpoint URL for log shipping.
        enable_viewer: Enable web viewer handler (for real-time streaming).
        viewer_queue_size: Max size of in-memory queue for viewer.
        viewer_host: Host for web viewer server.
        viewer_port: Port for web viewer server.
        viewer_export_limit: Max logs to export from viewer.
        max_runs_to_keep: Max run directories to keep (None = unlimited).
        suppress_third_party: Suppress verbose third-party library logs.
        capture_warnings: Capture Python warnings and route to logging.

    Example:
        >>> import bozo

        >>> # Simple setup - returns a logger
        >>> log = bozo.setup("myapp")
        >>> log.info("hello")

        >>> # Production setup
        >>> log = bozo.setup(
        >>>     "myapp",
        >>>     environment=bozo.Environment.PRODUCTION,
        >>>     enable_viewer=True,
        >>> )
    """
    config = LoggingConfig(
        app_name=app_name,
        environment=environment,
        log_dir=log_dir,  # type: ignore[arg-type]
        enable_console=enable_console,
        console_level=console_level,
        enable_file=enable_file,
        file_level=file_level,
        enable_error_file=enable_error_file,
        enable_json=enable_json,
        json_level=json_level,
        enable_http=enable_http,
        http_endpoint=http_endpoint,  # type: ignore[arg-type]
        enable_viewer=enable_viewer,
        viewer_queue_size=QueueSize(viewer_queue_size),
        viewer_host=HostAddress(viewer_host),
        viewer_port=PortNumber(viewer_port),
        viewer_export_limit=ExportLimit(viewer_export_limit),
        max_runs_to_keep=max_runs_to_keep,
        suppress_third_party=suppress_third_party,
        capture_warnings=capture_warnings,
    )

    config.setup()
    set_config(config)


def get(name: ModuleName) -> BoundLogger:
    """Get a logger instance for a module.

    Args:
        name: Module name (typically __name__).

    Returns:
        A structlog BoundLogger instance.

    Example:
        >>> import bozo

        >>> bozo.setup("myapp")
        >>> log = bozo.get(__name__)

        >>> log.info("hello", key="value")
        >>> log.error("failed", exc_info=True)
    """
    return cast("BoundLogger", structlog.get_logger(name))


def redact(value: LogValue) -> RedactedValue:
    """Redact a sensitive value in logs.

    Returns a placeholder string instead of the actual value.

    Args:
        value: The sensitive value to redact (not used, just for API).

    Returns:
        The redacted placeholder string.

    Example:
        >>> log.info("auth", password=bozo.redact(user_password))
        >>> # Logs: password='***REDACTED***'
    """
    _ = value  # Explicitly unused
    return REDACTED_PLACEHOLDER


def start_viewer(
    host: str | None = None,
    port: int | None = None,
    open_browser: bool = False,
) -> str:
    """Start the web viewer server.

    Requires the [viewer] extra:
        pip install bozo[viewer]

    Args:
        host: Host address (default: from config or 127.0.0.1).
        port: Port number (default: from config or 8080).
        open_browser: Open viewer in default browser.

    Returns:
        The URL where the viewer is accessible.

    Example:
        >>> import bozo

        >>> bozo.setup("myapp", enable_viewer=True)
        >>> url = bozo.start_viewer(open_browser=True)
        >>> print(f"Viewer at: {url}")
    """
    host_typed = HostAddress(host) if host is not None else None
    port_typed = PortNumber(port) if port is not None else None

    return _start_viewer(host=host_typed, port=port_typed, open_browser=open_browser)


def stop_viewer(timeout: float = 5.0) -> None:
    """Stop the web viewer server.

    Args:
        timeout: Max seconds to wait for shutdown.

    Example:
        >>> bozo.stop_viewer()
    """
    _stop_viewer(timeout=timeout)


@contextmanager
def log_context(**kwargs: LogValue) -> Iterator[None]:
    """Temporary logging context (thread/async-safe).

    Context values are automatically included in all log entries
    within the context manager, and removed when exiting.

    Args:
        **kwargs: Key-value pairs to add to logging context.

    Yields:
        None

    Example:
        >>> with bozo.log_context(request_id="abc-123", user_id=456):
        >>>     log.info("processing")  # includes request_id and user_id
        >>> log.info("done")  # context cleared
    """
    with _log_context(**kwargs):
        yield


def set_context(**kwargs: LogValue) -> None:
    """Set persistent logging context (thread/async-safe).

    Context values are included in all subsequent log entries
    until explicitly cleared.

    Args:
        **kwargs: Key-value pairs to add to logging context.

    Example:
        >>> bozo.set_context(service="api", version="1.0")
        >>> log.info("started")  # includes service and version
    """
    _set_context(**kwargs)


def clear_context(*keys: str) -> None:
    """Clear logging context.

    Args:
        *keys: Specific keys to clear. If empty, clears all context.

    Example:
        >>> bozo.clear_context("request_id")  # Clear specific key
        >>> bozo.clear_context()  # Clear all context
    """
    _clear_context(*keys)
