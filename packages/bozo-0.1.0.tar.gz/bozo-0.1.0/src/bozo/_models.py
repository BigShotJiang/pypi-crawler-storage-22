# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Pydantic configuration models for bozo.

Fully typed configuration with validation and sensible defaults.
"""

from __future__ import annotations

import logging
import pathlib
import uuid
from typing import TYPE_CHECKING, Annotated, ClassVar

import platformdirs
from pydantic import (
    BaseModel,
    Field,
    field_validator,
    model_validator,
)

from bozo._cleanup import cleanup_old_runs
from bozo._formatters import (
    build_formatters,
    configure_structlog,
    get_shared_processors,
)
from bozo._handlers import (
    JSONRotatingFileHandler,
    WebViewerHandler,
    build_console_handler,
    build_error_file_handler,
    build_http_handler,
    build_json_file_handler,
    build_text_file_handler,
    build_viewer_handler,
)
from bozo._types import (
    DEFAULT_BACKUP_COUNT,
    DEFAULT_BATCH_SIZE,
    DEFAULT_CAPTURE_WARNINGS,
    DEFAULT_EXPORT_LIMIT,
    DEFAULT_FLUSH_INTERVAL,
    DEFAULT_MAX_BYTES,
    DEFAULT_QUEUE_SIZE,
    DEFAULT_VIEWER_HOST,
    DEFAULT_VIEWER_PORT,
    ERROR_LOG_SUFFIX,
    JSON_LOG_SUFFIX,
    LOG_FILE_ENCODING,
    MAX_PORT_NUMBER,
    MIN_BACKUP_COUNT,
    MIN_FILE_SIZE_BYTES,
    MIN_PORT_NUMBER,
    MIN_QUEUE_SIZE,
    TEXT_LOG_SUFFIX,
    AppName,
    Environment,
    HttpEndpoint,
    LogDirPath,
    LogFilePath,
    LogLevel,
    RunId,
)

if TYPE_CHECKING:
    from pydantic import (
        HttpUrl,
    )

    from bozo._types import (
        BackupCount,
        BatchSize,
        ExportLimit,
        FlushInterval,
        HostAddress,
        MaxBytes,
        PortNumber,
        QueueSize,
    )
else:
    HttpUrl = str

    BackupCount = int
    BatchSize = int
    ExportLimit = int
    FlushInterval = float
    HostAddress = str
    MaxBytes = int
    PortNumber = int
    QueueSize = int


class LoggingConfig(BaseModel):
    """Comprehensive logging configuration.

    All fields are strictly typed with sensible defaults.
    Use platformdirs for cross-platform log directory by default.

    Example:
        config = LoggingConfig(app_name=AppName("myapp"))
        config.setup()
    """

    model_config = {"frozen": False, "validate_assignment": True}

    # Class-level constants (not configurable per-instance)
    LOG_FILE_ENCODING: ClassVar[str] = LOG_FILE_ENCODING
    TEXT_LOG_SUFFIX: ClassVar[str] = TEXT_LOG_SUFFIX
    ERROR_LOG_SUFFIX: ClassVar[str] = ERROR_LOG_SUFFIX
    JSON_LOG_SUFFIX: ClassVar[str] = JSON_LOG_SUFFIX

    # ==========================================================================
    # Core configuration
    # ==========================================================================

    app_name: AppName = Field(
        ...,
        description="Application name for log file naming",
    )

    run_id: RunId = Field(
        default_factory=lambda: RunId(str(uuid.uuid4())),
        description="Unique run ID for log correlation",
    )

    environment: Environment = Field(
        default=Environment.DEVELOPMENT,
        description="Application environment (development/production)",
    )

    log_dir: LogDirPath | None = Field(
        default=None,
        description="Directory for log files (default: platformdirs user_log_path)",
    )

    # ==========================================================================
    # Console logging
    # ==========================================================================

    enable_console: bool = Field(
        default=True,
        description="Enable console (stdout) logging",
    )

    console_level: LogLevel = Field(
        default=LogLevel.INFO,
        description="Minimum log level for console output",
    )

    # ==========================================================================
    # Text file logging
    # ==========================================================================

    enable_file: bool = Field(
        default=True,
        description="Enable text file logging",
    )

    file_level: LogLevel = Field(
        default=LogLevel.DEBUG,
        description="Minimum log level for text file output",
    )

    enable_error_file: bool = Field(
        default=True,
        description="Enable separate error log file (ERROR+ only)",
    )

    text_file_max_bytes: MaxBytes = Field(
        default=DEFAULT_MAX_BYTES,
        description="Maximum text log file size before rotation (bytes)",
    )

    text_file_backup_count: BackupCount = Field(
        default=DEFAULT_BACKUP_COUNT,
        description="Number of backup text log files to keep",
    )

    # ==========================================================================
    # JSON file logging
    # ==========================================================================

    enable_json: bool = Field(
        default=True,
        description="Enable JSON file logging",
    )

    json_level: LogLevel = Field(
        default=LogLevel.DEBUG,
        description="Minimum log level for JSON file output",
    )

    json_file_max_bytes: MaxBytes = Field(
        default=DEFAULT_MAX_BYTES,
        description="Maximum JSON log file size before rotation (bytes)",
    )

    json_file_backup_count: BackupCount = Field(
        default=DEFAULT_BACKUP_COUNT,
        description="Number of backup JSON log files to keep",
    )

    # ==========================================================================
    # HTTP log shipping
    # ==========================================================================

    enable_http: bool = Field(
        default=False,
        description="Enable HTTP log shipping",
    )

    http_endpoint: HttpUrl | None = Field(
        default=None,
        description="HTTP endpoint URL for log shipping",
    )

    http_batch_size: BatchSize = Field(
        default=DEFAULT_BATCH_SIZE,
        description="Number of logs to batch per HTTP request",
    )

    http_flush_interval: FlushInterval = Field(
        default=DEFAULT_FLUSH_INTERVAL,
        description="Interval (seconds) to flush HTTP log batches",
    )

    http_level: LogLevel = Field(
        default=LogLevel.INFO,
        description="Minimum log level for HTTP shipping",
    )

    # ==========================================================================
    # Web viewer
    # ==========================================================================

    enable_viewer: bool = Field(
        default=False,
        description="Enable web viewer handler (for real-time streaming)",
    )

    viewer_host: HostAddress = Field(
        default=DEFAULT_VIEWER_HOST,
        description="Host address for web viewer server",
    )

    viewer_port: PortNumber = Field(
        default=DEFAULT_VIEWER_PORT,
        description="Port number for web viewer server",
    )

    viewer_queue_size: QueueSize = Field(
        default=DEFAULT_QUEUE_SIZE,
        description="Maximum size of in-memory log queue for viewer",
    )

    viewer_export_limit: ExportLimit = Field(
        default=DEFAULT_EXPORT_LIMIT,
        description="Maximum number of logs to export",
    )

    # ==========================================================================
    # Third-party library suppression
    # ==========================================================================

    suppress_third_party: bool = Field(
        default=True,
        description="Suppress verbose third-party library logs",
    )

    libraries_to_suppress: tuple[str, ...] = Field(
        default=(
            "urllib3",
            "requests",
            "boto3",
            "botocore",
            "httpx",
            "httpcore",
            "asyncio",
        ),
        description="List of library names to suppress logs from",
    )

    # ==========================================================================
    # Python warnings capture
    # ==========================================================================

    capture_warnings: bool = Field(
        default=False,
        description="Capture Python warnings and route to logging",
    )

    warnings_level: LogLevel = Field(
        default=LogLevel.WARNING,
        description="Log level for captured Python warnings",
    )

    # ==========================================================================
    # Run cleanup
    # ==========================================================================

    max_runs_to_keep: Annotated[int, Field(ge=1)] | None = Field(
        default=None,
        description="Maximum number of run directories to keep (None = unlimited)",
    )

    # ==========================================================================
    # Validators
    # ==========================================================================

    @field_validator("app_name")
    @classmethod
    def validate_app_name(cls, v: AppName) -> AppName:
        """Ensure app_name is not empty or whitespace.

        Args:
            v: Application name to validate.

        Returns:
            Validated application name.

        Raises:
            ValueError: If app_name is empty or whitespace.
        """
        if not v or not v.strip():
            msg = "app_name must not be empty"
            raise ValueError(msg)
        return AppName(v.strip())

    @field_validator("text_file_max_bytes", "json_file_max_bytes")
    @classmethod
    def validate_max_bytes(cls, v: MaxBytes) -> MaxBytes:
        """Ensure max_bytes is positive.

        Args:
            v: Maximum bytes value to validate.

        Returns:
            Validated maximum bytes value.

        Raises:
            ValueError: If max_bytes is not positive.
        """
        if v <= MIN_FILE_SIZE_BYTES:
            msg = "max_bytes must be > 0"
            raise ValueError(msg)
        return v

    @field_validator("text_file_backup_count", "json_file_backup_count")
    @classmethod
    def validate_backup_count(cls, v: BackupCount) -> BackupCount:
        """Ensure backup_count is non-negative.

        Args:
            v: Backup count value to validate.

        Returns:
            Validated backup count value.

        Raises:
            ValueError: If backup_count is negative.
        """
        if v < MIN_BACKUP_COUNT:
            msg = "backup_count must be >= 0"
            raise ValueError(msg)
        return v

    @field_validator("viewer_port")
    @classmethod
    def validate_port(cls, v: PortNumber) -> PortNumber:
        """Ensure port is in valid range.

        Args:
            v: Port number to validate.

        Returns:
            Validated port number.

        Raises:
            ValueError: If port is not between 1 and 65535.
        """
        if not (MIN_PORT_NUMBER <= v <= MAX_PORT_NUMBER):
            msg = "port must be between 1 and 65535"
            raise ValueError(msg)
        return v

    @field_validator("viewer_queue_size")
    @classmethod
    def validate_queue_size(cls, v: QueueSize) -> QueueSize:
        """Ensure queue_size is positive.

        Args:
            v: Queue size value to validate.

        Returns:
            Validated queue size value.

        Raises:
            ValueError: If queue_size is not positive.
        """
        if v <= MIN_QUEUE_SIZE:
            msg = "queue_size must be > 0"
            raise ValueError(msg)
        return v

    @model_validator(mode="after")
    def validate_http_config(self) -> LoggingConfig:
        """Ensure HTTP endpoint is provided when HTTP is enabled.

        Returns:
            The LoggingConfig instance.

        Raises:
            ValueError: If HTTP is enabled but no endpoint is provided,
                        or if HTTP is disabled but an endpoint is provided.
        """
        if self.enable_http and not self.http_endpoint:
            msg = "http_endpoint required when enable_http=True"
            raise ValueError(msg)
        if not self.enable_http and self.http_endpoint:
            msg = "http_endpoint provided but enable_http=False"
            raise ValueError(msg)
        return self

    @model_validator(mode="after")
    def validate_error_file_requires_file(self) -> LoggingConfig:
        """Ensure error file requires file logging enabled.

        Returns:
            The LoggingConfig instance.

        Raises:
            ValueError: If enable_error_file is True but enable_file is False.
        """
        if self.enable_error_file and not self.enable_file:
            msg = "enable_error_file=True requires enable_file=True"
            raise ValueError(msg)
        return self

    @model_validator(mode="after")
    def validate_third_party_suppression(self) -> LoggingConfig:
        """Ensure libraries list is not empty when suppression enabled.

        Returns:
            The LoggingConfig instance.

        Raises:
            ValueError: If suppress_third_party is True
                        but libraries_to_suppress is empty.
        """
        if self.suppress_third_party and not self.libraries_to_suppress:
            msg = "libraries_to_suppress cannot be empty when suppress_third_party=True"
            raise ValueError(msg)
        return self

    @model_validator(mode="after")
    def resolve_log_dir(self) -> LoggingConfig:
        """Resolve log_dir to platformdirs default if not specified.

        Returns:
            The LoggingConfig instance with log_dir resolved.
        """
        if self.log_dir is None:
            default_path = platformdirs.user_log_path(
                appname=self.app_name,
                ensure_exists=True,
            )
            self.log_dir = LogDirPath(str(default_path))
        return self

    @model_validator(mode="after")
    def ensure_run_log_dir(self) -> LoggingConfig:
        """Create run-specific log directory.

        Returns:
            The LoggingConfig instance.
        """
        run_dir = self.run_log_dir
        pathlib.Path(run_dir).mkdir(exist_ok=True, parents=True)
        return self

    # ==========================================================================
    # Computed properties
    # ==========================================================================

    @property
    def run_log_dir(self) -> LogDirPath:
        """Get run-specific log directory path.

        Returns:
            Path to the run-specific log directory.

        Raises:
            RuntimeError: If log_dir is not resolved.
        """
        if self.log_dir is None:
            msg = "log_dir not resolved"
            raise RuntimeError(msg)

        run_id_dir_path = pathlib.Path(self.log_dir) / self.run_id
        return LogDirPath(str(run_id_dir_path))

    @property
    def text_file_path(self) -> LogFilePath:
        """Get text log file path."""
        text_file_path = (
            pathlib.Path(self.run_log_dir) / f"{self.app_name}{self.TEXT_LOG_SUFFIX}"
        )
        return LogFilePath(str(text_file_path))

    @property
    def error_file_path(self) -> LogFilePath:
        """Get error log file path."""
        error_file_path = (
            pathlib.Path(self.run_log_dir) / f"{self.app_name}{self.ERROR_LOG_SUFFIX}"
        )
        return LogFilePath(str(error_file_path))

    @property
    def json_file_path(self) -> LogFilePath:
        """Get JSON log file path."""
        json_file_path = (
            pathlib.Path(self.run_log_dir) / f"{self.app_name}{self.JSON_LOG_SUFFIX}"
        )
        return LogFilePath(str(json_file_path))

    @property
    def http_endpoint_str(self) -> HttpEndpoint | None:
        """Get HTTP endpoint as string."""
        if self.http_endpoint is None:
            return None
        return HttpEndpoint(str(self.http_endpoint))

    # ==========================================================================
    # Setup method
    # ==========================================================================

    def setup(self) -> None:
        """Initialize logging with this configuration.

        This configures:
        - structlog processors and formatters
        - Console, file, JSON, HTTP, and viewer handlers
        - Third-party library log suppression
        - Python warnings capture
        - Run directory cleanup (if max_runs_to_keep set)
        """
        # Cleanup old runs first
        if self.max_runs_to_keep is not None and self.log_dir is not None:
            cleanup_old_runs(self.log_dir, self.max_runs_to_keep, self.run_id)

        # Build handlers
        handlers: list[logging.Handler] = []

        # Get shared processors
        shared_processors = get_shared_processors()

        # Configure structlog
        configure_structlog(shared_processors)

        # Console handler
        if self.enable_console:
            handlers.append(build_console_handler(self.environment, self.console_level))

        # Text file handler
        if self.enable_file:
            handlers.append(
                build_text_file_handler(
                    self.text_file_path,
                    self.text_file_max_bytes,
                    self.text_file_backup_count,
                    self.file_level,
                )
            )

        # Error file handler
        if self.enable_error_file:
            handlers.append(
                build_error_file_handler(
                    self.error_file_path,
                    self.text_file_max_bytes,
                    self.text_file_backup_count,
                )
            )

        # JSON file handler
        if self.enable_json:
            handlers.append(
                build_json_file_handler(
                    self.json_file_path,
                    self.json_file_max_bytes,
                    self.json_file_backup_count,
                    self.json_level,
                )
            )

        # HTTP handler
        if self.enable_http and self.http_endpoint_str is not None:
            handlers.append(
                build_http_handler(
                    self.http_endpoint_str,
                    self.http_batch_size,
                    self.http_flush_interval,
                    self.http_level,
                )
            )

        # Viewer handler (for real-time SSE streaming)
        if self.enable_viewer:
            handlers.append(
                build_viewer_handler(
                    self.run_id,
                    self.viewer_queue_size,
                    self.json_level,
                )
            )

        # Build and apply formatters
        console_fmt, text_fmt, json_fmt = build_formatters(
            shared_processors, self.environment
        )

        # Apply formatters to handlers
        _apply_formatters(handlers, console_fmt, text_fmt, json_fmt)

        # Configure root logger
        _configure_root_logger(handlers)

        # Suppress third-party libraries
        if self.suppress_third_party:
            _suppress_libraries(self.libraries_to_suppress)

        # Capture Python warnings
        if self.capture_warnings:
            _capture_warnings(self.warnings_level)


# Rebuild model to properly resolve forward references from TYPE_CHECKING
LoggingConfig.model_rebuild()


# =============================================================================
# Private helper functions
# =============================================================================


def _apply_formatters(
    handlers: list[logging.Handler],
    console_fmt: logging.Formatter,
    text_fmt: logging.Formatter,
    json_fmt: logging.Formatter,
) -> None:
    """Apply appropriate formatters to each handler.

    Args:
        handlers: List of logging handlers.
        console_fmt: Formatter for console output.
        text_fmt: Formatter for text file output.
        json_fmt: Formatter for JSON output.
    """
    for handler in handlers:
        if isinstance(handler, logging.StreamHandler) and not isinstance(
            handler, logging.FileHandler
        ):
            handler.setFormatter(console_fmt)
        elif isinstance(handler, (JSONRotatingFileHandler, WebViewerHandler)):
            handler.setFormatter(json_fmt)
        else:
            handler.setFormatter(text_fmt)


def _configure_root_logger(handlers: list[logging.Handler]) -> None:
    """Configure the root logger with handlers."""
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    for handler in list(root.handlers):
        handler.close()
        root.removeHandler(handler)

    for handler in handlers:
        root.addHandler(handler)


def _suppress_libraries(libraries: tuple[str, ...]) -> None:
    """Suppress verbose logs from third-party libraries."""
    for lib in libraries:
        logging.getLogger(lib).setLevel(logging.WARNING)


def _capture_warnings(level: LogLevel) -> None:
    """Capture Python warnings and route to logging."""
    logging.captureWarnings(DEFAULT_CAPTURE_WARNINGS)
    logging.getLogger("py.warnings").setLevel(level.to_logging_level())
