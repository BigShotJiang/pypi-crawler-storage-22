# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Internal global state management for bozo.

This module holds the singleton state for the logging configuration
and viewer thread. All access is through typed getter/setter functions.
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from bozo._models import LoggingConfig
else:
    LoggingConfig = object


class _GlobalState:
    """Thread-safe global state container."""

    __slots__ = ("_config", "_lock", "_viewer_thread")

    def __init__(self) -> None:
        self._config: LoggingConfig | None = None
        self._viewer_thread: threading.Thread | None = None
        self._lock: threading.Lock = threading.Lock()

    @property
    def config(self) -> LoggingConfig | None:
        """Get current logging configuration.

        Returns:
            Current LoggingConfig or None if not set.
        """
        with self._lock:
            return self._config

    @config.setter
    def config(self, config: LoggingConfig) -> None:
        """Set logging configuration."""
        with self._lock:
            self._config = config

    @property
    def viewer_thread(self) -> threading.Thread | None:
        """Get viewer thread if running.

        Returns:
            Viewer thread or None if not running.
        """
        with self._lock:
            return self._viewer_thread

    @viewer_thread.setter
    def viewer_thread(self, thread: threading.Thread | None) -> None:
        """Set or clear viewer thread."""
        with self._lock:
            self._viewer_thread = thread

    @property
    def is_configured(self) -> bool:
        """Check if logging has been configured."""
        with self._lock:
            return self._config is not None

    @property
    def is_viewer_running(self) -> bool:
        """Check if viewer is running."""
        with self._lock:
            return self._viewer_thread is not None and self._viewer_thread.is_alive()

    def require_config(self) -> LoggingConfig:
        """Get config or raise if not configured.

        Returns:
            Current LoggingConfig.

        Raises:
            RuntimeError: If logging is not configured.
        """
        with self._lock:
            if self._config is None:
                msg = "bozo not configured. Call bozo.setup() first."
                raise RuntimeError(msg)
            return self._config

    def reset(self) -> None:
        """Reset all state (for testing)."""
        with self._lock:
            self._config = None
            self._viewer_thread = None


# Singleton instance
_state = _GlobalState()


# =============================================================================
# Public accessor functions
# =============================================================================


def get_config() -> LoggingConfig | None:
    """Get current logging configuration.

    Returns:
        Current LoggingConfig or None if not set.
    """
    return _state.config


def set_config(config: LoggingConfig) -> None:
    """Set logging configuration."""
    _state.config = config


def require_config() -> LoggingConfig:
    """Get config or raise RuntimeError if not configured.

    Returns:
        Current LoggingConfig.
    """
    return _state.require_config()


def is_configured() -> bool:
    """Check if logging has been configured.

    Returns:
        True if logging is configured, False otherwise.
    """
    return _state.is_configured


def get_viewer_thread() -> threading.Thread | None:
    """Get viewer thread if running.

    Returns:
        Viewer thread or None if not running.
    """
    return _state.viewer_thread


def set_viewer_thread(thread: threading.Thread | None) -> None:
    """Set or clear viewer thread."""
    _state.viewer_thread = thread


def is_viewer_running() -> bool:
    """Check if viewer is running.

    Returns:
        True if viewer is running, False otherwise.
    """
    return _state.is_viewer_running


def reset_state() -> None:
    """Reset all state (for testing)."""
    _state.reset()
