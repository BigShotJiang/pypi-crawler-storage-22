# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Custom types, enums, and constants for bozo.

All types are strictly defined - no open str/int types in public API.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from enum import IntEnum, StrEnum
from typing import (
    Annotated,
    Any,
    Final,
    Literal,
    NewType,
    TypedDict,
)

import structlog

# =============================================================================
# Custom NewTypes for strict typing
# =============================================================================

AppName = str
"""Application name for log file naming (e.g., 'myapp')"""

ModuleName = str
"""Module name for logger identification (e.g., '__main__')"""

RunId = NewType("RunId", str)
"""UUID string identifying a logging run"""

LogDirPath = NewType("LogDirPath", str)
"""Absolute path to log directory"""

LogFilePath = NewType("LogFilePath", str)
"""Absolute path to a log file"""

HttpEndpoint = NewType("HttpEndpoint", str)
"""HTTP URL endpoint for log shipping"""

RedactedValue = NewType("RedactedValue", str)
"""Placeholder for redacted sensitive values"""

EventId = NewType("EventId", int)
"""Unique identifier for log events in SSE stream"""

Cursor = NewType("Cursor", int)
"""Byte offset cursor for paginated log reading"""

QueueSize = NewType("QueueSize", int)
"""Maximum size for bounded log queue"""

BatchSize = NewType("BatchSize", int)
"""Number of logs to batch per HTTP request"""

FlushInterval = NewType("FlushInterval", float)
"""Interval in seconds to flush logs"""

MaxBytes = NewType("MaxBytes", int)
"""Maximum file size in bytes"""

BackupCount = NewType("BackupCount", int)
"""Number of backup files to keep"""

PortNumber = NewType("PortNumber", int)
"""TCP port number (1-65535)"""

HostAddress = NewType("HostAddress", str)
"""Host address (IP or hostname)"""

ExportLimit = NewType("ExportLimit", int)
"""Maximum number of logs to export"""

DropCount = NewType("DropCount", int)
"""Number of dropped log entries"""

Timestamp = NewType("Timestamp", str)
"""ISO 8601 formatted timestamp string"""

LogMessage = NewType("LogMessage", str)
"""Log message content"""

# Type for any log context value (structured logging accepts various types)
LogValue = str | int | float | bool | list["LogValue"] | dict[str, "LogValue"] | None


# =============================================================================
# Enums
# =============================================================================


class LogLevel(IntEnum):
    """Log level enumeration matching Python's logging levels."""

    DEBUG = logging.DEBUG
    INFO = logging.INFO
    WARNING = logging.WARNING
    ERROR = logging.ERROR
    CRITICAL = logging.CRITICAL

    @classmethod
    def from_string(cls, level: str) -> LogLevel:
        """Convert string to LogLevel.

        Args:
            level: Log level name (case-insensitive).

        Returns:
            Corresponding LogLevel enum member.
        """
        return cls[level.upper()]

    def to_logging_level(self) -> int:
        """Convert to Python logging level.

        Returns:
            Corresponding logging level integer.
        """
        return self.value


class Environment(StrEnum):
    """Application environment."""

    DEVELOPMENT = "development"
    PRODUCTION = "production"


class LogFormat(StrEnum):
    """Log output format."""

    TEXT = "text"
    JSON = "json"


class ExportFormat(StrEnum):
    """Log export format."""

    JSON = "json"
    TEXT = "text"


class ThemeMode(StrEnum):
    """UI theme mode."""

    SYSTEM = "system"
    LIGHT = "light"
    DARK = "dark"


# =============================================================================
# TypedDicts for structured data
# =============================================================================


class LogEntryDict(TypedDict, total=False):
    """Structure of a log entry."""

    id: EventId
    timestamp: Timestamp
    level: str
    event: str
    message: LogMessage
    module: ModuleName
    run_id: RunId
    _synthetic: bool
    _gap: bool


class LogStatsDict(TypedDict):
    """Log statistics by level."""

    debug: int
    info: int
    warning: int
    error: int
    critical: int
    total: int


class RunInfoDict(TypedDict):
    """Information about a logging run."""

    run_id: RunId
    created_at: Timestamp
    log_count: int
    is_current: bool
    app_name: AppName


class PaginatedLogsDict(TypedDict):
    """Paginated log response."""

    logs: list[LogEntryDict]
    next_cursor: Cursor | None
    has_more: bool
    total_count: int


class ExportPreviewDict(TypedDict):
    """Export preview response."""

    count: int
    exceeds_limit: bool
    limit: ExportLimit


class DropNotificationDict(TypedDict):
    """Drop notification structure."""

    id: EventId
    level: Literal["WARNING"]
    event: Literal["viewer_backpressure"]
    message: LogMessage
    dropped_count: DropCount
    timestamp: Timestamp
    _synthetic: Literal[True]


class GapNotificationDict(TypedDict):
    """Gap notification for missed logs during reconnection."""

    id: EventId
    level: Literal["WARNING"]
    event: Literal["viewer_reconnection_gap"]
    message: LogMessage
    missed_from: EventId
    timestamp: Timestamp
    _gap: Literal[True]


# =============================================================================
# Type Aliases
# =============================================================================

type BoundLogger = structlog.stdlib.BoundLogger
"""Type alias for structlog bound logger"""

type LogProcessor = Any
"""Type alias for structlog processor"""

type LogRecord = logging.LogRecord
"""Type alias for logging.LogRecord"""

type Handler = logging.Handler
"""Type alias for logging.Handler"""

type Formatter = logging.Formatter
"""Type alias for logging.Formatter"""

type FilterFunc = Callable[[LogEntryDict], bool]
"""Function to filter log entries"""

# Annotated types with constraints
PositiveInt = Annotated[int, "Must be > 0"]
NonNegativeInt = Annotated[int, "Must be >= 0"]
PositiveFloat = Annotated[float, "Must be > 0"]


# =============================================================================
# Constants - Final and immutable
# =============================================================================

# Redaction
REDACTED_PLACEHOLDER: Final[RedactedValue] = RedactedValue("***REDACTED***")

# File encoding
LOG_FILE_ENCODING: Final[str] = "utf-8"

# File suffixes
TEXT_LOG_SUFFIX: Final[str] = ".log"
ERROR_LOG_SUFFIX: Final[str] = ".error.log"
JSON_LOG_SUFFIX: Final[str] = ".json.log"

# Default values
DEFAULT_QUEUE_SIZE: Final[QueueSize] = QueueSize(1000)
DEFAULT_BATCH_SIZE: Final[BatchSize] = BatchSize(50)
DEFAULT_FLUSH_INTERVAL: Final[FlushInterval] = FlushInterval(2.0)
DEFAULT_MAX_BYTES: Final[MaxBytes] = MaxBytes(5 * 1024 * 1024)  # 5MB
DEFAULT_BACKUP_COUNT: Final[BackupCount] = BackupCount(10)
DEFAULT_VIEWER_HOST: Final[HostAddress] = HostAddress("127.0.0.1")
DEFAULT_VIEWER_PORT: Final[PortNumber] = PortNumber(8080)
DEFAULT_EXPORT_LIMIT: Final[ExportLimit] = ExportLimit(50000)
DEFAULT_PAGE_SIZE: Final[int] = 100

# Drop notification threshold
DROP_NOTIFICATION_THRESHOLD: Final[DropCount] = DropCount(100)

# Reverse file reader chunk size
FILE_CHUNK_SIZE: Final[int] = 8192  # 8KB

# HTTP status codes
HTTP_STATUS_CODE_200_OK: Final[int] = 200

# Port number range
MIN_PORT_NUMBER: Final[int] = 1
MAX_PORT_NUMBER: Final[int] = 65535

# Minimum backup count
MIN_BACKUP_COUNT: Final[int] = 0

# Minimum file size in bytes
MIN_FILE_SIZE_BYTES: Final[int] = 1

# Minimum queue size
MIN_QUEUE_SIZE: Final[int] = 1

# Capture warnings by default
DEFAULT_CAPTURE_WARNINGS: Final[bool] = True


# =============================================================================
# Viewer API Endpoints - Final and immutable
# =============================================================================


class ViewerEndpoints:
    """Immutable viewer API endpoint definitions."""

    ROOT: Final[str] = "/"
    API_RUNS: Final[str] = "/api/runs"
    API_LOGS: Final[str] = "/api/logs/{run_id}"
    API_STREAM: Final[str] = "/api/logs/{run_id}/stream"
    API_STATS: Final[str] = "/api/stats/{run_id}"
    API_EXPORT: Final[str] = "/api/export/{run_id}"
    API_EXPORT_COUNT: Final[str] = "/api/export/{run_id}/count"

    def __init__(self) -> None:
        """Prevent instantiation.

        Raises:
            TypeError: Always raised to prevent instantiation.
        """
        msg = "ViewerEndpoints cannot be instantiated"
        raise TypeError(msg)


# =============================================================================
# Keyboard Shortcuts
# =============================================================================


class KeyboardShortcut(TypedDict):
    """Keyboard shortcut definition."""

    key: str
    description: str
    category: Literal["Navigation", "Filters", "Actions", "View"]


KEYBOARD_SHORTCUTS: Final[tuple[KeyboardShortcut, ...]] = (
    # Navigation
    {"key": "j", "description": "Next log entry", "category": "Navigation"},
    {"key": "k", "description": "Previous log entry", "category": "Navigation"},
    {"key": "↑", "description": "Previous log entry", "category": "Navigation"},
    {"key": "↓", "description": "Next log entry", "category": "Navigation"},
    {
        "key": "Enter",
        "description": "Expand/collapse log details",
        "category": "Navigation",
    },
    {"key": "Home", "description": "Go to first log", "category": "Navigation"},
    {"key": "End", "description": "Go to latest log", "category": "Navigation"},
    # Filters
    {"key": "1", "description": "Toggle DEBUG filter", "category": "Filters"},
    {"key": "2", "description": "Toggle INFO filter", "category": "Filters"},
    {"key": "3", "description": "Toggle WARNING filter", "category": "Filters"},
    {"key": "4", "description": "Toggle ERROR filter", "category": "Filters"},
    {"key": "5", "description": "Toggle CRITICAL filter", "category": "Filters"},
    {"key": "0", "description": "Reset all filters", "category": "Filters"},
    {"key": "/", "description": "Focus search input", "category": "Filters"},
    {"key": "Ctrl+F", "description": "Focus search input", "category": "Filters"},
    # Actions
    {"key": "g", "description": "Toggle auto-scroll", "category": "Actions"},
    {"key": "e", "description": "Open export menu", "category": "Actions"},
    {"key": "r", "description": "Reconnect SSE stream", "category": "Actions"},
    # View
    {
        "key": "t",
        "description": "Cycle theme (system → light → dark)",
        "category": "View",
    },
    {"key": "?", "description": "Toggle help modal", "category": "View"},
    {"key": "F1", "description": "Toggle help modal", "category": "View"},
    {
        "key": "Escape",
        "description": "Close modal / Clear search / Blur",
        "category": "View",
    },
    {"key": "[", "description": "Toggle sidebar (mobile)", "category": "View"},
)
