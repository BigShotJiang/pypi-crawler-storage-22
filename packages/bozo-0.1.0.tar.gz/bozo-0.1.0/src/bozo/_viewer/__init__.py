# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Public API for the bozo web viewer.

Provides start_viewer() and stop_viewer() functions.
"""

from __future__ import annotations

from bozo._viewer._main import start_viewer, stop_viewer

__all__ = ["start_viewer", "stop_viewer"]
