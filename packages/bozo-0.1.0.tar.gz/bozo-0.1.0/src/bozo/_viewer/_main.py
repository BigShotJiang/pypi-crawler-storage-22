# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Main module for bozo viewer.

Provides start_viewer() and stop_viewer() functions.
"""

from __future__ import annotations

import webbrowser
from importlib.util import find_spec
from typing import TYPE_CHECKING

from bozo._state import is_viewer_running, require_config, set_viewer_thread
from bozo._viewer._server import ViewerServer, get_server, set_server

if TYPE_CHECKING:
    from bozo._types import HostAddress, PortNumber
else:
    HostAddress = str
    PortNumber = int


def require_dependency(module: str, display_name: str) -> None:
    """Check if a dependency is installed, raise ImportError if not.

    Args:
        module: The module name to check.
        display_name: The human-readable name of the dependency.

    Raises:
        ImportError: If the dependency is not installed.
    """
    if find_spec(module) is None:
        msg = f"{display_name} is not installed."
        raise ImportError(msg)


def start_viewer(
    host: HostAddress | None = None,
    port: PortNumber | None = None,
    open_browser: bool = False,
) -> str:
    """Start the web viewer server.

    Requires the [viewer] extra to be installed:
        pip install bozo[viewer]

    Args:
        host: Host address to bind to (default: from config or 127.0.0.1).
        port: Port number to bind to (default: from config or 8080).
        open_browser: Whether to open the viewer in the default browser.

    Returns:
        The URL where the viewer is accessible.

    Raises:
        ImportError: If viewer dependencies are not installed.
        RuntimeError: If logging is not configured to a directory.
    """
    # Check viewer dependencies
    try:
        require_dependency("fastapi", "FastAPI")
        require_dependency("uvicorn", "Uvicorn")
    except ImportError as e:
        msg = (
            "Web viewer requires additional dependencies."
            "Install with: pip install bozo[viewer]"
        )
        raise ImportError(msg) from e

    # Get config
    config = require_config()

    # Use provided values or fall back to config
    actual_host = host if host is not None else config.viewer_host
    actual_port = port if port is not None else config.viewer_port

    # Check if already running
    if is_viewer_running():
        server = get_server()
        if server is not None:
            return server.url

    # Create and start server

    if not config.log_dir:
        msg = "Viewer requires logging to a directory."
        raise RuntimeError(msg)

    server = ViewerServer(
        log_dir=config.log_dir,
        current_run_id=config.run_id,
        host=actual_host,
        port=actual_port,
        export_limit=config.viewer_export_limit,
    )

    server.start()
    set_server(server)

    url = server.url

    if open_browser:
        webbrowser.open(url)

    return url


def stop_viewer(timeout: float = 5.0) -> None:
    """Stop the web viewer server.

    Args:
        timeout: Maximum time to wait for server shutdown.
    """
    server = get_server()
    if server is not None:
        server.stop(timeout=timeout)
        set_server(None)
        set_viewer_thread(None)
