# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Bounded log queue for web viewer SSE streaming.

Thread-safe queue with drop tracking and synthetic notifications.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import threading
from collections import deque
from datetime import UTC, datetime
from typing import TYPE_CHECKING, ClassVar

from bozo._types import (
    DROP_NOTIFICATION_THRESHOLD,
    DropCount,
    EventId,
    LogMessage,
    Timestamp,
)

if TYPE_CHECKING:
    from bozo._types import (
        DropNotificationDict,
        GapNotificationDict,
        QueueSize,
        RunId,
    )
else:
    DropNotificationDict = dict
    GapNotificationDict = dict
    QueueSize = int
    RunId = str


class BoundedLogQueue:
    """Thread-safe bounded queue for log entries with SSE streaming support.

    Features:
    - Fixed-size deque (drops oldest when full)
    - Auto-incrementing event IDs for SSE Last-Event-ID support
    - Drop tracking with synthetic notification injection
    - Async event signaling for real-time streaming
    - Replay from event ID for reconnection support
    """

    # Class-level registry of queues by run_id
    _queues: ClassVar[dict[RunId, BoundedLogQueue]] = {}
    _registry_lock: ClassVar[threading.Lock] = threading.Lock()

    def __init__(self, run_id: RunId, max_size: QueueSize) -> None:
        self._run_id: RunId = run_id
        self._max_size: QueueSize = max_size

        # Thread-safe deque with max size
        self._buffer: deque[tuple[EventId, str]] = deque(maxlen=max_size)
        self._lock: threading.Lock = threading.Lock()

        # Auto-incrementing event ID
        self._next_event_id: EventId = EventId(1)

        # Drop tracking
        self._drop_count: DropCount = DropCount(0)
        self._total_drops: DropCount = DropCount(0)

        # Async notification (created lazily when async access needed)
        self._async_event: asyncio.Event | None = None
        self._async_loop: asyncio.AbstractEventLoop | None = None

    @classmethod
    def get_or_create(cls, run_id: RunId, max_size: QueueSize) -> BoundedLogQueue:
        """Get existing queue or create new one for run_id.

        Args:
            run_id: The run ID for the queue.
            max_size: Maximum size of the queue.

        Returns:
            The BoundedLogQueue instance for the given run_id.
        """
        with cls._registry_lock:
            if run_id not in cls._queues:
                cls._queues[run_id] = cls(run_id, max_size)
            return cls._queues[run_id]

    @classmethod
    def get(cls, run_id: RunId) -> BoundedLogQueue | None:
        """Get existing queue for run_id (returns None if not found).

        Args:
            run_id: The run ID for the queue.

        Returns:
            The BoundedLogQueue instance for the given run_id, or None if not found.
        """
        with cls._registry_lock:
            return cls._queues.get(run_id)

    @classmethod
    def remove(cls, run_id: RunId) -> None:
        """Remove queue for run_id from registry."""
        with cls._registry_lock:
            cls._queues.pop(run_id, None)

    @classmethod
    def list_run_ids(cls) -> list[RunId]:
        """List all active run IDs.

        Returns:
            List of run IDs with active queues.
        """
        with cls._registry_lock:
            return list(cls._queues.keys())

    def put_nowait(self, log_entry: str) -> EventId:
        """Add log entry to queue (non-blocking).

        If queue is full, oldest entry is dropped and drop counter incremented.
        Synthetic drop notifications are injected at threshold intervals.

        Args:
            log_entry: JSON-formatted log entry string.

        Returns:
            The event ID assigned to this log entry.
        """
        with self._lock:
            # Check if we need to drop oldest
            if len(self._buffer) >= self._max_size:
                self._drop_count = DropCount(self._drop_count + 1)
                self._total_drops = DropCount(self._total_drops + 1)

                # Inject synthetic drop notification at threshold
                if (
                    self._drop_count == 1
                    or self._drop_count % DROP_NOTIFICATION_THRESHOLD == 0
                ):
                    self._inject_drop_notification()

            # Assign event ID and add to buffer
            event_id = self._next_event_id
            self._next_event_id = EventId(self._next_event_id + 1)
            self._buffer.append((event_id, log_entry))

            # Signal async waiters
            self._signal_async()

            return event_id

    def _inject_drop_notification(self) -> None:
        """Inject a synthetic drop notification into the queue."""
        notification: DropNotificationDict = {
            "id": self._next_event_id,
            "level": "WARNING",
            "event": "viewer_backpressure",
            "message": LogMessage(
                f"⚠️ {self._drop_count} log(s) dropped - viewer cannot keep up"
            ),
            "dropped_count": self._drop_count,
            "timestamp": Timestamp(datetime.now(UTC).isoformat()),
            "_synthetic": True,
        }

        # Increment event ID for notification
        self._next_event_id = EventId(self._next_event_id + 1)

        # Add notification (this may also drop, but that's ok)
        self._buffer.append((notification["id"], json.dumps(notification)))

    def _signal_async(self) -> None:
        """Signal async event if set."""
        if self._async_event is not None and self._async_loop is not None:
            with contextlib.suppress(RuntimeError):
                self._async_loop.call_soon_threadsafe(self._async_event.set)

    def get_async_event(self, loop: asyncio.AbstractEventLoop) -> asyncio.Event:
        """Get or create async event for the given loop.

        Args:
            loop: The asyncio event loop.

        Returns:
            The asyncio.Event instance for signaling.
        """
        with self._lock:
            if self._async_event is None or self._async_loop != loop:
                self._async_event = asyncio.Event()
                self._async_loop = loop
            return self._async_event

    def get_all(self) -> list[tuple[EventId, str]]:
        """Get all entries in the queue.

        Returns:
            List of tuples of (event_id, log_entry).
        """
        with self._lock:
            return list(self._buffer)

    def get_from_id(self, from_event_id: EventId) -> list[tuple[EventId, str]] | None:
        """Get all entries from a specific event ID forward.

        Used for SSE reconnection with Last-Event-ID.

        Args:
            from_event_id: The event ID to start from (exclusive).

        Returns:
            List of entries after the given ID, or None if ID not found in buffer.
        """
        with self._lock:
            # Find the starting point
            entries: list[tuple[EventId, str]] = []
            found = False

            for event_id, entry in self._buffer:
                if found:
                    entries.append((event_id, entry))
                elif event_id == from_event_id:
                    found = True

            return entries if found else None

    def create_gap_notification(self, missed_from_id: EventId) -> tuple[EventId, str]:
        """Create a gap notification for missed logs during reconnection.

        Args:
            missed_from_id: The last event ID the client received.

        Returns:
            Tuple of (event_id, JSON-encoded notification).
        """
        with self._lock:
            notification: GapNotificationDict = {
                "id": self._next_event_id,
                "level": "WARNING",
                "event": "viewer_reconnection_gap",
                "message": LogMessage("Some logs were missed during disconnection"),
                "missed_from": missed_from_id,
                "timestamp": Timestamp(datetime.now(UTC).isoformat()),
                "_gap": True,
            }

            event_id = self._next_event_id
            self._next_event_id = EventId(self._next_event_id + 1)

            return (event_id, json.dumps(notification))

    def get_latest_id(self) -> EventId | None:
        """Get the latest event ID in the queue.

        Returns:
            The latest EventId, or None if the queue is empty.
        """
        with self._lock:
            if self._buffer:
                return self._buffer[-1][0]
            return None

    def __len__(self) -> int:
        """Get current queue length.

        Returns:
            Number of entries in the queue.
        """
        with self._lock:
            return len(self._buffer)

    @property
    def run_id(self) -> RunId:
        """Get the run ID for this queue."""
        return self._run_id

    @property
    def drop_count(self) -> DropCount:
        """Get current drop count since last notification."""
        with self._lock:
            return self._drop_count

    @property
    def total_drops(self) -> DropCount:
        """Get total number of drops."""
        with self._lock:
            return self._total_drops
