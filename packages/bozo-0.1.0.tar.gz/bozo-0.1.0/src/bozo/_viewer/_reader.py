# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Reverse file reader for cursor-based pagination.

Reads JSON log files backwards for efficient historical log loading.
"""

from __future__ import annotations

import contextlib
import json
from typing import TYPE_CHECKING

from anyio import Path

from bozo._types import (
    DEFAULT_PAGE_SIZE,
    FILE_CHUNK_SIZE,
    Cursor,
    ExportFormat,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from anyio import AsyncFile

    from bozo._types import (
        LogEntryDict,
        LogFilePath,
        PaginatedLogsDict,
    )
else:
    AsyncIterator = object
    AsyncFile = object

    LogEntryDict = dict
    LogFilePath = str
    PaginatedLogsDict = dict


async def _read_chunk_backwards(
    f: AsyncFile[bytes],
    *,
    position: Cursor,
    chunk_size: int,
    leftover: bytes,
) -> tuple[list[bytes], bytes, Cursor]:
    chunk_start = max(0, position - chunk_size)
    size = position - chunk_start

    await f.seek(chunk_start)
    chunk = await f.read(size)

    data = chunk + leftover
    lines = data.split(b"\n")

    if chunk_start > 0:
        new_leftover = lines[0]
        lines = lines[1:]
    else:
        new_leftover = b""

    return lines, new_leftover, Cursor(chunk_start)


def _parse_json_lines(
    lines: list[bytes],
    *,
    limit: int,
    logs: list[LogEntryDict],
) -> None:
    for line in reversed(lines):
        if not line.strip():
            continue

        try:
            logs.append(json.loads(line.decode("utf-8")))
            if len(logs) >= limit:
                return
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue


async def read_json_log_backwards(
    file_path: LogFilePath,
    cursor: Cursor | None = None,
    limit: int = DEFAULT_PAGE_SIZE,
) -> PaginatedLogsDict:
    path = Path(file_path)

    if not await path.exists():
        return {
            "logs": [],
            "next_cursor": None,
            "has_more": False,
            "total_count": 0,
        }

    file_size = (await path.stat()).st_size
    if file_size == 0:
        return {
            "logs": [],
            "next_cursor": None,
            "has_more": False,
            "total_count": 0,
        }

    position = cursor if cursor is not None else Cursor(file_size)
    logs: list[LogEntryDict] = []
    leftover = b""

    async with await path.open("rb") as f:
        while position > 0 and len(logs) < limit:
            lines, leftover, position = await _read_chunk_backwards(
                f,
                position=position,
                chunk_size=FILE_CHUNK_SIZE,
                leftover=leftover,
            )

            _parse_json_lines(lines, limit=limit, logs=logs)

        if position == 0 and leftover and len(logs) < limit:
            with contextlib.suppress(json.JSONDecodeError, UnicodeDecodeError):
                logs.append(json.loads(leftover.decode("utf-8")))

    next_cursor = position if position > 0 else None
    total_count = await _count_lines_fast(path)

    return {
        "logs": logs,
        "next_cursor": next_cursor,
        "has_more": next_cursor is not None and next_cursor > 0,
        "total_count": total_count,
    }


async def read_json_log_forward(
    file_path: LogFilePath,
    cursor: Cursor | None = None,
    limit: int = DEFAULT_PAGE_SIZE,
) -> PaginatedLogsDict:
    """Read JSON log file forward from cursor position.

    Args:
        file_path: Path to the JSON log file.
        cursor: Byte offset to start reading from (None = start of file).
        limit: Maximum number of log entries to return.

    Returns:
        PaginatedLogsDict with logs, next_cursor, has_more, and total_count.
    """
    path = Path(file_path)
    if not await path.exists():
        return {
            "logs": [],
            "next_cursor": None,
            "has_more": False,
            "total_count": 0,
        }

    file_size = (await path.stat()).st_size
    position = cursor if cursor is not None else Cursor(0)

    logs: list[LogEntryDict] = []

    async with await path.open("rb") as f:
        await f.seek(position)

        # If not at start, skip partial line
        if position > 0:
            await f.readline()

        while len(logs) < limit:
            line = await f.readline()
            if not line:
                break

            try:
                entry: LogEntryDict = json.loads(line.decode("utf-8"))
                logs.append(entry)
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue

        # Get next cursor position
        next_position = await f.tell()
        has_more = next_position < file_size

    next_cursor = Cursor(next_position) if has_more else None
    total_count = await _count_lines_fast(path)

    return {
        "logs": logs,
        "next_cursor": next_cursor,
        "has_more": has_more,
        "total_count": total_count,
    }


async def _count_lines_fast(path: Path) -> int:
    """Fast line count using buffered reading.

    For very large files, this returns an approximate count.

    Args:
        path: Path to the file.

    Returns:
        Approximate number of lines in the file.
    """
    count = 0
    async with await path.open("rb") as f:
        while True:
            chunk = await f.read(FILE_CHUNK_SIZE * 8)
            if not chunk:
                break
            count += chunk.count(b"\n")
    return count


async def count_logs_with_filter(
    file_path: LogFilePath,
    levels: set[str] | None = None,
    from_time: str | None = None,
    to_time: str | None = None,
    search: str | None = None,
) -> int:
    """Count logs matching filter criteria.

    Args:
        file_path: Path to the JSON log file.
        levels: Set of level names to include (None = all).
        from_time: ISO timestamp lower bound.
        to_time: ISO timestamp upper bound.
        search: Text to search for in log entries.

    Returns:
        Number of matching log entries.
    """
    path = Path(file_path)
    if not await path.exists():
        return 0

    count = 0
    async with await path.open("r", encoding="utf-8") as f:
        async for line in f:
            if not line.strip():
                continue

            try:
                entry: LogEntryDict = json.loads(line)

                if not _matches_filter(entry, levels, from_time, to_time, search):
                    continue

                count += 1
            except (json.JSONDecodeError, KeyError):
                continue

    return count


def _matches_filter(
    entry: LogEntryDict,
    levels: set[str] | None,
    from_time: str | None,
    to_time: str | None,
    search: str | None,
) -> bool:
    """Check if log entry matches filter criteria.

    Args:
        entry: Log entry dictionary.
        levels: Set of level names to include (None = all).
        from_time: ISO timestamp lower bound.
        to_time: ISO timestamp upper bound.
        search: Text to search for in log entry.

    Returns:
        True if entry matches all filters, False otherwise.
    """
    # Level filter
    if levels is not None:
        level = entry.get("level", "").upper()
        if level not in levels:
            return False

    # Time filters
    timestamp = entry.get("timestamp", "")
    if from_time and timestamp < from_time:
        return False
    if to_time and timestamp > to_time:
        return False

    # Search filter (case-insensitive)
    if search:
        search_lower = search.lower()
        # Search in event, message, and all string values
        found = False
        for value in entry.values():
            if isinstance(value, str) and search_lower in value.lower():
                found = True
                break
        if not found:
            return False

    return True


async def export_logs(  # noqa: PLR0913, PLR0917
    file_path: LogFilePath,
    export_format: ExportFormat,
    limit: int,
    levels: set[str] | None = None,
    from_time: str | None = None,
    to_time: str | None = None,
    search: str | None = None,
) -> AsyncIterator[str]:
    """Export logs as a streaming iterator.

    Args:
        file_path: Path to the JSON log file.
        export_format: Export format (json or text).
        limit: Maximum number of logs to export.
        levels: Set of level names to include (None = all).
        from_time: ISO timestamp lower bound.
        to_time: ISO timestamp upper bound.
        search: Text to search for.

    Yields:
        Formatted log entries (one per line).

    Raises:
        StopAsyncIteration: When no more logs are available.
    """
    path = Path(file_path)
    if not await path.exists():
        raise StopAsyncIteration

    count = 0
    async with await path.open("r", encoding="utf-8") as f:
        async for line in f:
            if count >= limit:
                break

            if not line.strip():
                continue

            try:
                entry: LogEntryDict = json.loads(line)

                if not _matches_filter(entry, levels, from_time, to_time, search):
                    continue

                if export_format == ExportFormat.JSON:
                    yield line
                else:
                    # Text format
                    timestamp = entry.get("timestamp", "")
                    level = entry.get("level", "UNKNOWN")
                    event = entry.get("event", "")
                    module = entry.get("module", "")
                    message = entry.get("message", event)

                    if module:
                        yield f"{timestamp} [{level}] {module}: {message}\n"
                    else:
                        yield f"{timestamp} [{level}] {message}\n"

                count += 1
            except (json.JSONDecodeError, KeyError):
                continue
