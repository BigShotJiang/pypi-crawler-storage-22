# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""FastAPI routes for the bozo web viewer.

Provides REST API and SSE endpoints for log viewing.
"""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Annotated

from anyio import Path
from fastapi import Query
from fastapi.responses import HTMLResponse, StreamingResponse

from bozo._cleanup import list_runs
from bozo._types import (
    JSON_LOG_SUFFIX,
    AppName,
    Cursor,
    ExportFormat,
    ExportLimit,
    LogFilePath,
    RunId,
    Timestamp,
    ViewerEndpoints,
)
from bozo._viewer._queue import BoundedLogQueue
from bozo._viewer._reader import (
    count_logs_with_filter,
    export_logs,
    read_json_log_backwards,
)
from bozo._viewer._template import VIEWER_HTML

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from fastapi import FastAPI

    from bozo._types import (
        ExportPreviewDict,
        LogDirPath,
        LogStatsDict,
        PaginatedLogsDict,
        RunInfoDict,
    )
else:
    AsyncIterator = object
    FastAPI = object

    ExportPreviewDict = dict
    LogDirPath = str
    LogStatsDict = dict
    PaginatedLogsDict = dict
    RunInfoDict = dict


def create_routes(  # noqa: C901, PLR0915
    app: FastAPI, log_dir: LogDirPath, current_run_id: RunId, export_limit: int
) -> None:
    """Create and register all viewer routes.

    Args:
        app: FastAPI application instance.
        log_dir: Path to the log directory.
        current_run_id: The current run ID.
        export_limit: Maximum number of logs to export.
    """

    @app.get(ViewerEndpoints.ROOT, response_class=HTMLResponse)
    def viewer_root() -> HTMLResponse:  # pyright: ignore[reportUnusedFunction]
        """Serve the main viewer HTML page.

        Returns:
            HTMLResponse with the viewer page.
        """
        return HTMLResponse(content=VIEWER_HTML)

    @app.get(ViewerEndpoints.API_RUNS)
    async def get_runs() -> list[RunInfoDict]:  # pyright: ignore[reportUnusedFunction]
        """List all available runs.

        Returns:
            List of run info dictionaries.
        """
        runs_data = list_runs(log_dir)
        result: list[RunInfoDict] = []

        for run_id, mtime, log_count in runs_data:
            # Get app name from first log file (exclude .json.log and .error.log)
            run_path = Path(log_dir) / run_id
            app_name = "unknown"
            async for f in run_path.iterdir():
                if (
                    f.name.endswith(".log")
                    and not f.name.endswith(".json.log")
                    and not f.name.endswith(".error.log")
                ):
                    app_name = f.stem
                    break

            result.append(
                {
                    "run_id": run_id,
                    "created_at": Timestamp(
                        datetime.fromtimestamp(mtime, UTC).isoformat()
                    ),
                    "log_count": log_count,
                    "is_current": run_id == current_run_id,
                    "app_name": AppName(app_name),
                }
            )

        return result

    @app.get(ViewerEndpoints.API_LOGS)
    async def get_logs(  # pyright: ignore[reportUnusedFunction]
        run_id: str,
        cursor: int | None = None,
        limit: int = 100,
    ) -> PaginatedLogsDict:
        """Get paginated logs for a run.

        Args:
            run_id: The run ID to fetch logs for.
            cursor: Byte offset to start reading from (None = end of file).
            limit: Maximum number of log entries to return.

        Returns:
            PaginatedLogsDict with logs, next_cursor, has_more, and total_count.
        """
        # Clamp limit
        limit = max(1, min(1000, limit))

        json_path = await _get_json_log_path(log_dir, RunId(run_id))
        if not json_path:
            return {
                "logs": [],
                "next_cursor": None,
                "has_more": False,
                "total_count": 0,
            }

        cursor_typed = Cursor(cursor) if cursor is not None else None
        return await read_json_log_backwards(json_path, cursor_typed, limit)

    @app.get(ViewerEndpoints.API_STREAM)
    def stream_logs(  # pyright: ignore[reportUnusedFunction]
        run_id: str,
    ) -> StreamingResponse:
        """SSE stream for real-time log updates.

        Args:
            run_id: The run ID to stream logs for.

        Returns:
            StreamingResponse with SSE log stream.
        """

        async def event_generator() -> AsyncIterator[str]:
            last_event_id: int | None = None

            # Get queue for current run
            queue = BoundedLogQueue.get(RunId(run_id))

            if queue is None:
                # No queue exists - this is a historical run
                # Stream all entries from file then end
                json_path = await _get_json_log_path(log_dir, RunId(run_id))
                if json_path:
                    async_path = Path(json_path)
                    async with await async_path.open(encoding="utf-8") as f:
                        event_id = 1
                        async for line in f:
                            if line.strip():
                                yield f"id: {event_id}\ndata: {line.strip()}\n\n"
                                event_id += 1
                return

            # Stream new events from the queue
            loop = asyncio.get_running_loop()
            event = queue.get_async_event(loop)

            while True:
                # Wait for new events with timeout (keepalive)
                try:
                    await asyncio.wait_for(event.wait(), timeout=30.0)
                    event.clear()
                except TimeoutError:
                    # Send keepalive comment to keep connection alive
                    yield ": keepalive\n\n"
                    continue

                # Get all new entries from queue
                entries = queue.get_all()
                for event_id, entry in entries:
                    if last_event_id is not None and event_id <= last_event_id:
                        continue
                    yield f"id: {event_id}\ndata: {entry}\n\n"
                    last_event_id = event_id

        return StreamingResponse(
            event_generator(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    @app.get(ViewerEndpoints.API_STATS)
    async def get_stats(  # pyright: ignore[reportUnusedFunction]  # noqa: C901
        run_id: str,
    ) -> LogStatsDict:
        """Get log statistics for a run.

        Args:
            run_id: The run ID to fetch stats for.

        Returns:
            LogStatsDict with counts per log level and total.
        """
        json_path = await _get_json_log_path(log_dir, RunId(run_id))
        if not json_path:
            return {
                "debug": 0,
                "info": 0,
                "warning": 0,
                "error": 0,
                "critical": 0,
                "total": 0,
            }

        stats: LogStatsDict = {
            "debug": 0,
            "info": 0,
            "warning": 0,
            "error": 0,
            "critical": 0,
            "total": 0,
        }

        async_path = Path(json_path)
        try:
            async with await async_path.open(encoding="utf-8") as f:
                async for line in f:
                    if not line.strip():
                        continue
                    try:
                        entry = json.loads(line)
                        level = entry.get("level", "INFO").lower()
                        if level == "debug":
                            stats["debug"] += 1
                        elif level == "info":
                            stats["info"] += 1
                        elif level == "warning":
                            stats["warning"] += 1
                        elif level == "error":
                            stats["error"] += 1
                        elif level == "critical":
                            stats["critical"] += 1
                        stats["total"] += 1
                    except json.JSONDecodeError:
                        continue
        except FileNotFoundError:
            pass

        return stats

    @app.get(ViewerEndpoints.API_EXPORT_COUNT)
    async def get_export_count(  # pyright: ignore[reportUnusedFunction]
        run_id: str,
        levels: str | None = None,
        search: str | None = None,
        from_time: Annotated[str | None, Query(alias="from")] = None,
        to_time: Annotated[str | None, Query(alias="to")] = None,
    ) -> ExportPreviewDict:
        """Get count of logs that would be exported (for size warning).

        Args:
            run_id: The run ID to fetch log count for.
            levels: Comma-separated log levels to include (None = all).
            search: Text to search for in log entries.
            from_time: ISO timestamp lower bound.
            to_time: ISO timestamp upper bound.

        Returns:
            ExportPreviewDict with count, exceeds_limit, and limit.
        """
        json_path = await _get_json_log_path(log_dir, RunId(run_id))
        if not json_path:
            return {
                "count": 0,
                "exceeds_limit": False,
                "limit": ExportLimit(export_limit),
            }

        level_set = set(levels.upper().split(",")) if levels else None
        count = await count_logs_with_filter(
            json_path, level_set, from_time, to_time, search
        )

        return {
            "count": count,
            "exceeds_limit": count > export_limit,
            "limit": ExportLimit(export_limit),
        }

    @app.get(ViewerEndpoints.API_EXPORT)
    async def export_run_logs(  # pyright: ignore[reportUnusedFunction]  # noqa: PLR0913, PLR0917
        run_id: str,
        export_format: str = "json",
        limit: int | None = None,
        levels: str | None = None,
        search: str | None = None,
        from_time: Annotated[str | None, Query(alias="from")] = None,
        to_time: Annotated[str | None, Query(alias="to")] = None,
    ) -> StreamingResponse:
        """Export logs as downloadable file.

        Args:
            run_id: The run ID to export logs for.
            export_format: "json" or "text" format.
            limit: Maximum number of log entries to export.
            levels: Comma-separated log levels to include (None = all).
            search: Text to search for in log entries.
            from_time: ISO timestamp lower bound.
            to_time: ISO timestamp upper bound.

        Returns:
            StreamingResponse with log file download.
        """
        json_path = await _get_json_log_path(log_dir, RunId(run_id))

        export_format = (
            ExportFormat.JSON if export_format == "json" else ExportFormat.TEXT
        )
        actual_limit = min(limit or export_limit, export_limit)
        level_set = set(levels.upper().split(",")) if levels else None

        async def generate() -> AsyncIterator[str]:
            try:
                if json_path:
                    async for chunk in export_logs(
                        json_path,
                        export_format,
                        actual_limit,
                        level_set,
                        from_time,
                        to_time,
                        search,
                    ):
                        yield chunk
            except StopAsyncIteration:
                return

        filename = (
            f"{run_id[:8]}.{'json' if export_format == ExportFormat.JSON else 'txt'}"
        )
        media_type = (
            "application/json" if export_format == ExportFormat.JSON else "text/plain"
        )

        return StreamingResponse(
            generate(),
            media_type=media_type,
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
            },
        )


async def _get_json_log_path(log_dir: LogDirPath, run_id: RunId) -> LogFilePath | None:
    """Get the JSON log file path for a run.

    Args:
        log_dir: Path to the log directory.
        run_id: The run ID to get the log file for.

    Returns:
        LogFilePath if found, else None.
    """
    run_path = Path(log_dir) / run_id
    if not await run_path.exists():
        return None

    async for f in run_path.iterdir():
        if f.name.endswith(JSON_LOG_SUFFIX):
            return LogFilePath(str(f))

    return None
