# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""FastAPI server for the bozo web viewer.

Manages the uvicorn server lifecycle in a background thread.
"""

from __future__ import annotations

import asyncio
import threading
from typing import TYPE_CHECKING

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from bozo._viewer._routes import create_routes

if TYPE_CHECKING:
    from bozo._types import (
        ExportLimit,
        HostAddress,
        LogDirPath,
        PortNumber,
        RunId,
    )
else:
    ExportLimit = int
    HostAddress = str
    LogDirPath = str
    PortNumber = int
    RunId = str


class ViewerServer:
    """Manages the FastAPI/uvicorn server for the log viewer.

    Runs in a background daemon thread to avoid blocking the main application.
    """

    def __init__(
        self,
        log_dir: LogDirPath,
        current_run_id: RunId,
        host: HostAddress,
        port: PortNumber,
        export_limit: ExportLimit,
    ) -> None:
        self._log_dir = log_dir
        self._current_run_id = current_run_id
        self._host = host
        self._port = port
        self._export_limit = export_limit

        self._app: FastAPI | None = None
        self._server_thread: threading.Thread | None = None
        self._should_exit = threading.Event()

    def _create_app(self) -> FastAPI:
        """Create and configure the FastAPI application.

        Returns:
            Configured FastAPI app instance.
        """
        app = FastAPI(
            title="bozo Viewer",
            description="Real-time log viewer for bozo",
            version="0.1.0",
            docs_url=None,  # Disable Swagger UI
            redoc_url=None,  # Disable ReDoc
        )

        # Add CORS middleware for development
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # Register routes
        create_routes(
            app,
            self._log_dir,
            self._current_run_id,
            self._export_limit,
        )

        return app

    def _run_server(self) -> None:
        """Run the uvicorn server (called in background thread)."""
        self._app = self._create_app()

        config = uvicorn.Config(
            app=self._app,
            host=self._host,
            port=self._port,
            log_level="warning",
            access_log=False,
        )

        server = uvicorn.Server(config)

        # Run the server
        asyncio.run(server.serve())

    def start(self) -> None:
        """Start the viewer server in a background thread."""
        if self._server_thread is not None and self._server_thread.is_alive():
            return  # Already running

        self._should_exit.clear()
        self._server_thread = threading.Thread(
            target=self._run_server,
            daemon=True,
            name="bozo-viewer",
        )
        self._server_thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        """Stop the viewer server."""
        self._should_exit.set()

        if self._server_thread is not None:
            self._server_thread.join(timeout=timeout)
            self._server_thread = None

    def is_running(self) -> bool:
        """Check if the server is running.

        Returns:
            True if the server thread is alive, False otherwise.
        """
        return self._server_thread is not None and self._server_thread.is_alive()

    @property
    def url(self) -> str:
        """Get the viewer URL."""
        return f"http://{self._host}:{self._port}"


class _ServerManager:
    """Manages the singleton ViewerServer instance."""

    _server: ViewerServer | None = None

    @classmethod
    def get_server(cls) -> ViewerServer | None:
        """Get the current server instance.

        Returns:
            The current ViewerServer instance, or None if not set.
        """
        return cls._server

    @classmethod
    def set_server(cls, server: ViewerServer | None) -> None:
        """Set the server instance."""
        cls._server = server


_server_manager = _ServerManager()


def get_server() -> ViewerServer | None:
    """Get the current server instance.

    Returns:
        The current ViewerServer instance, or None if not set.
    """
    return _server_manager.get_server()


def set_server(server: ViewerServer | None) -> None:
    """Set the server instance."""
    _server_manager.set_server(server)
