# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Embedded HTML/CSS/JS template for the bozo web viewer.

Single-page application with:
- System-default dark mode (with localStorage override)
- Real-time SSE streaming
- Keyboard shortcuts with help modal
- Mobile-responsive with touch gestures
- Log filtering and export
"""

from __future__ import annotations

from typing import Final

from bozo._types import KEYBOARD_SHORTCUTS

# Build keyboard shortcut help HTML
_SHORTCUT_SECTIONS: dict[str, list[tuple[str, str]]] = {
    "Navigation": [],
    "Filters": [],
    "Actions": [],
    "View": [],
}

for shortcut in KEYBOARD_SHORTCUTS:
    _SHORTCUT_SECTIONS[shortcut["category"]].append(
        (
            shortcut["key"],
            shortcut["description"],
        )
    )

_SHORTCUT_HTML_PARTS: list[str] = []
for category, shortcuts in _SHORTCUT_SECTIONS.items():
    _SHORTCUT_HTML_PARTS.append(f'<div class="shortcut-category"><h4>{category}</h4>')
    for key, desc in shortcuts:
        key_html = "".join(f"<kbd>{k.strip()}</kbd>" for k in key.split("+"))
        _SHORTCUT_HTML_PARTS.append(
            f'<div class="shortcut-item">{key_html}<span>{desc}</span></div>'
        )
    _SHORTCUT_HTML_PARTS.append("</div>")

SHORTCUT_HELP_HTML: Final[str] = "\n".join(_SHORTCUT_HTML_PARTS)

VIEWER_HTML: Final[str] = (
    """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title>bozo Viewer</title>
<style>
/* ============================================================================
   CSS Variables - Light theme (default)
   ============================================================================ */
:root {
  --bg-primary: #ffffff;
  --bg-secondary: #f5f5f5;
  --bg-tertiary: #e8e8e8;
  --bg-hover: #f0f0f0;
  --text-primary: #1a1a1a;
  --text-secondary: #666666;
  --text-muted: #999999;
  --border-color: #e0e0e0;
  --border-strong: #cccccc;
  --accent: #4a90d9;
  --accent-hover: #3a7bc8;
  --success: #28a745;
  --warning: #ffc107;
  --error: #dc3545;
  --critical: #7b1fa2;
  --debug: #17a2b8;
  --info: #28a745;
  --shadow: rgba(0, 0, 0, 0.1);
  --shadow-strong: rgba(0, 0, 0, 0.2);
  --sidebar-width: 280px;
  --toolbar-height: 52px;
  --stats-height: 40px;
}

/* ============================================================================
   Dark theme
   ============================================================================ */
@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]) {
    --bg-primary: #1a1a2e;
    --bg-secondary: #16213e;
    --bg-tertiary: #0f3460;
    --bg-hover: #1f4068;
    --text-primary: #eaeaea;
    --text-secondary: #b0b0b0;
    --text-muted: #707070;
    --border-color: #2a2a4a;
    --border-strong: #3a3a5a;
    --accent: #4fc3f7;
    --accent-hover: #29b6f6;
    --shadow: rgba(0, 0, 0, 0.3);
    --shadow-strong: rgba(0, 0, 0, 0.5);
  }
}

[data-theme="dark"] {
  --bg-primary: #1a1a2e;
  --bg-secondary: #16213e;
  --bg-tertiary: #0f3460;
  --bg-hover: #1f4068;
  --text-primary: #eaeaea;
  --text-secondary: #b0b0b0;
  --text-muted: #707070;
  --border-color: #2a2a4a;
  --border-strong: #3a3a5a;
  --accent: #4fc3f7;
  --accent-hover: #29b6f6;
  --shadow: rgba(0, 0, 0, 0.3);
  --shadow-strong: rgba(0, 0, 0, 0.5);
}

/* ============================================================================
   Base styles
   ============================================================================ */
*, *::before, *::after { box-sizing: border-box; }

html, body {
  margin: 0;
  padding: 0;
  height: 100%;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, sans-serif;
  font-size: 14px;
  line-height: 1.5;
  background: var(--bg-primary);
  color: var(--text-primary);
  overflow: hidden;
}

button {
  cursor: pointer;
  font-family: inherit;
  font-size: inherit;
  border: none;
  background: none;
  color: inherit;
  padding: 0;
}

input, select {
  font-family: inherit;
  font-size: inherit;
  color: var(--text-primary);
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: 4px;
  padding: 6px 10px;
}

input:focus, select:focus, button:focus {
  outline: 2px solid var(--accent);
  outline-offset: 1px;
}

/* ============================================================================
   Layout
   ============================================================================ */
.app-container {
  display: flex;
  height: 100vh;
  width: 100vw;
}

/* Sidebar */
.sidebar {
  width: var(--sidebar-width);
  background: var(--bg-secondary);
  border-right: 1px solid var(--border-color);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  z-index: 100;
}

.sidebar-header {
  padding: 16px;
  border-bottom: 1px solid var(--border-color);
}

.sidebar-header h1 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 8px;
}

.sidebar-header h1::before {
  content: "📋";
}

.run-list {
  flex: 1;
  overflow-y: auto;
  padding: 8px;
}

.run-item {
  display: flex;
  flex-direction: column;
  padding: 10px 12px;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.15s;
  margin-bottom: 4px;
}

.run-item:hover { background: var(--bg-hover); }
.run-item.active { background: var(--bg-tertiary); }
.run-item.current { border-left: 3px solid var(--accent); }

.run-item-header {
  display: flex;
  align-items: center;
  gap: 8px;
}

.run-item-id {
  font-family: monospace;
  font-size: 12px;
  color: var(--text-secondary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
}

.live-badge {
  background: var(--success);
  color: white;
  font-size: 10px;
  font-weight: 600;
  padding: 2px 6px;
  border-radius: 10px;
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.6; }
}

.run-item-meta {
  font-size: 11px;
  color: var(--text-muted);
  margin-top: 4px;
}

/* Main content */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
}

/* Toolbar */
.toolbar {
  height: var(--toolbar-height);
  padding: 8px 16px;
  background: var(--bg-secondary);
  border-bottom: 1px solid var(--border-color);
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: nowrap;
  overflow-x: auto;
}

.filter-group {
  display: flex;
  align-items: center;
  gap: 4px;
}

.level-btn {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  opacity: 0.5;
  transition: opacity 0.15s, background 0.15s;
}

.level-btn.active { opacity: 1; }
.level-btn.debug { background: var(--debug); color: white; }
.level-btn.info { background: var(--info); color: white; }
.level-btn.warning { background: var(--warning); color: black; }
.level-btn.error { background: var(--error); color: white; }
.level-btn.critical { background: var(--critical); color: white; }

.search-input {
  width: 200px;
  padding-left: 32px;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23999' stroke-width='2'%3E%3Ccircle cx='11' cy='11' r='8'/%3E%3Cpath d='m21 21-4.35-4.35'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: 8px center;
}

.toolbar-spacer { flex: 1; }

.toolbar-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 6px 12px;
  border-radius: 4px;
  background: var(--bg-tertiary);
  transition: background 0.15s;
}

.toolbar-btn:hover { background: var(--bg-hover); }
.toolbar-btn.active { background: var(--accent); color: white; }

.toolbar-btn svg {
  width: 16px;
  height: 16px;
}

/* Log list */
.log-container {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 0;
}

.log-entry {
  display: flex;
  flex-direction: column;
  padding: 8px 16px;
  border-bottom: 1px solid var(--border-color);
  cursor: pointer;
  transition: background 0.1s;
}

.log-entry:hover { background: var(--bg-hover); }
.log-entry.selected { background: var(--bg-tertiary); }
.log-entry.synthetic { opacity: 0.7; font-style: italic; }

.log-entry-main {
  display: flex;
  align-items: flex-start;
  gap: 12px;
}

.log-time {
  font-family: monospace;
  font-size: 12px;
  color: var(--text-muted);
  flex-shrink: 0;
  width: 90px;
}

.log-level {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  padding: 2px 6px;
  border-radius: 3px;
  flex-shrink: 0;
  width: 70px;
  text-align: center;
}

.log-level.debug { background: var(--debug); color: white; }
.log-level.info { background: var(--info); color: white; }
.log-level.warning { background: var(--warning); color: black; }
.log-level.error { background: var(--error); color: white; }
.log-level.critical { background: var(--critical); color: white; }

.log-module {
  font-family: monospace;
  font-size: 12px;
  color: var(--text-secondary);
  flex-shrink: 0;
  max-width: 150px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.log-message {
  flex: 1;
  word-break: break-word;
  white-space: pre-wrap;
}

.log-details {
  display: none;
  margin-top: 12px;
  padding: 12px;
  background: var(--bg-secondary);
  border-radius: 6px;
  overflow-x: auto;
}

.log-entry.expanded .log-details { display: block; }

.log-details-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

.log-details-table th,
.log-details-table td {
  padding: 6px 12px;
  text-align: left;
  border-bottom: 1px solid var(--border-color);
}

.log-details-table th {
  font-weight: 600;
  color: var(--text-secondary);
  width: 150px;
}

.log-details-table td {
  font-family: monospace;
  word-break: break-all;
  position: relative;
  padding-right: 40px;
}

.copy-btn {
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  padding: 4px 8px;
  background: var(--bg-tertiary);
  border: 1px solid var(--border-color);
  border-radius: 4px;
  font-size: 11px;
  opacity: 0;
  transition: opacity 0.15s, background 0.15s;
  cursor: pointer;
}

.log-details-table tr:hover .copy-btn,
.copy-btn:focus {
  opacity: 1;
}

.copy-btn:hover {
  background: var(--bg-hover);
  border-color: var(--accent);
}

.copy-btn:active {
  background: var(--accent);
  color: white;
}

.copy-btn.copied {
  background: var(--success);
  color: white;
  opacity: 1;
}

.log-message-container {
  position: relative;
  flex: 1;
}

.log-message {
  word-break: break-word;
  white-space: pre-wrap;
  padding-right: 40px;
}

.log-message-copy {
  position: absolute;
  right: 0;
  top: 0;
  padding: 2px 6px;
  background: var(--bg-tertiary);
  border: 1px solid var(--border-color);
  border-radius: 4px;
  font-size: 11px;
  opacity: 0;
  transition: opacity 0.15s, background 0.15s;
  cursor: pointer;
}

.log-entry:hover .log-message-copy,
.log-message-copy:focus {
  opacity: 1;
}

.log-message-copy:hover {
  background: var(--bg-hover);
  border-color: var(--accent);
}

.log-message-copy:active {
  background: var(--accent);
  color: white;
}

.log-message-copy.copied {
  background: var(--success);
  color: white;
  opacity: 1;
}

/* Stats bar */
.stats-bar {
  height: var(--stats-height);
  padding: 0 16px;
  background: var(--bg-secondary);
  border-top: 1px solid var(--border-color);
  display: flex;
  align-items: center;
  gap: 16px;
  font-size: 12px;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 6px;
}

.stat-count {
  font-weight: 600;
  font-family: monospace;
}

.stat-count.debug { color: var(--debug); }
.stat-count.info { color: var(--info); }
.stat-count.warning { color: var(--warning); }
.stat-count.error { color: var(--error); }
.stat-count.critical { color: var(--critical); }

/* Jump to latest FAB */
.jump-fab {
  position: fixed;
  bottom: calc(var(--stats-height) + 20px);
  right: 20px;
  background: var(--accent);
  color: white;
  padding: 10px 16px;
  border-radius: 24px;
  box-shadow: 0 4px 12px var(--shadow-strong);
  display: none;
  align-items: center;
  gap: 6px;
  font-weight: 500;
  z-index: 50;
}

.jump-fab.visible { display: flex; }
.jump-fab:hover { background: var(--accent-hover); }

/* ============================================================================
   Modals
   ============================================================================ */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 200;
}

.modal-overlay.visible { display: flex; }

.modal {
  background: var(--bg-primary);
  border-radius: 12px;
  box-shadow: 0 8px 32px var(--shadow-strong);
  max-width: 600px;
  max-height: 80vh;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.modal-header {
  padding: 16px 20px;
  border-bottom: 1px solid var(--border-color);
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.modal-header h2 {
  margin: 0;
  font-size: 18px;
}

.modal-close {
  font-size: 24px;
  opacity: 0.5;
  transition: opacity 0.15s;
}

.modal-close:hover { opacity: 1; }

.modal-body {
  padding: 20px;
  overflow-y: auto;
}

/* Help modal */
.shortcut-category {
  margin-bottom: 20px;
}

.shortcut-category h4 {
  margin: 0 0 8px 0;
  color: var(--text-secondary);
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.shortcut-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 6px 0;
}

kbd {
  display: inline-block;
  padding: 3px 8px;
  background: var(--bg-tertiary);
  border: 1px solid var(--border-strong);
  border-radius: 4px;
  font-family: monospace;
  font-size: 12px;
  min-width: 24px;
  text-align: center;
}

/* Export modal */
.export-options {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.export-option {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  background: var(--bg-secondary);
  border: 1px solid var(--border);
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s, border-color 0.15s;
  text-align: left;
  width: 100%;
  color: var(--text-primary);
}

.export-option:hover {
  background: var(--bg-tertiary);
  border-color: var(--text-secondary);
}

.export-option-icon {
  font-size: 24px;
}

.export-warning {
  background: var(--warning);
  color: black;
  padding: 12px;
  border-radius: 8px;
  margin-bottom: 16px;
}

/* ============================================================================
   Mobile styles
   ============================================================================ */
@media (max-width: 768px) {
  .sidebar {
    position: fixed;
    left: calc(-1 * var(--sidebar-width));
    top: 0;
    bottom: 0;
    transition: left 0.3s ease;
    box-shadow: 4px 0 16px var(--shadow);
  }

  .sidebar.open { left: 0; }

  .sidebar-backdrop {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 99;
    display: none;
  }

  .sidebar.open + .sidebar-backdrop { display: block; }

  .toolbar {
    gap: 8px;
    padding: 8px;
  }

  .search-input { width: 120px; }

  .mobile-menu-btn {
    display: flex;
    padding: 8px;
  }

  .log-time { width: 70px; font-size: 11px; }
  .log-level { width: 50px; font-size: 10px; }
  .log-module { display: none; }
}

@media (min-width: 769px) {
  .mobile-menu-btn { display: none; }
  .sidebar-backdrop { display: none !important; }
}

/* ============================================================================
   Loading & empty states
   ============================================================================ */
.loading-spinner {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px;
  color: var(--text-muted);
}

.loading-spinner::before {
  content: "";
  width: 24px;
  height: 24px;
  border: 2px solid var(--border-color);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
  margin-right: 12px;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 20px;
  color: var(--text-muted);
  text-align: center;
}

.empty-state-icon {
  font-size: 48px;
  margin-bottom: 16px;
}

/* ============================================================================
   Dropdown menu
   ============================================================================ */
.dropdown {
  position: relative;
}

.dropdown-menu {
  position: absolute;
  top: 100%;
  right: 0;
  background: var(--bg-primary);
  border: 1px solid var(--border-color);
  border-radius: 8px;
  box-shadow: 0 4px 16px var(--shadow-strong);
  min-width: 180px;
  display: none;
  z-index: 150;
}

.dropdown.open .dropdown-menu { display: block; }

.dropdown-item {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 10px 14px;
  text-align: left;
  transition: background 0.15s;
}

.dropdown-item:hover { background: var(--bg-hover); }
.dropdown-item:first-child { border-radius: 8px 8px 0 0; }
.dropdown-item:last-child { border-radius: 0 0 8px 8px; }

/* Connection status */
.connection-status {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--text-muted);
}

.connection-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--text-muted);
}

.connection-dot.connected { background: var(--success); }
.connection-dot.connecting { background: var(--warning); animation: pulse 1s infinite; }
.connection-dot.disconnected { background: var(--error); }
</style>
</head>
<body>

<div class="app-container">
  <!-- Sidebar -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
      <h1>bozo</h1>
    </div>
    <div class="run-list" id="runList">
      <div class="loading-spinner">Loading runs...</div>
    </div>
  </aside>
  <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

  <!-- Main content -->
  <main class="main-content">
    <!-- Toolbar -->
    <div class="toolbar">
      <button class="mobile-menu-btn toolbar-btn" id="mobileMenuBtn" title="Toggle sidebar ([)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 12h18M3 6h18M3 18h18"/>
        </svg>
      </button>

      <div class="filter-group" id="levelFilters">
        <button class="level-btn debug active" data-level="DEBUG" title="Toggle DEBUG (1)">DBG</button>
        <button class="level-btn info active" data-level="INFO" title="Toggle INFO (2)">INF</button>
        <button class="level-btn warning active" data-level="WARNING" title="Toggle WARNING (3)">WRN</button>
        <button class="level-btn error active" data-level="ERROR" title="Toggle ERROR (4)">ERR</button>
        <button class="level-btn critical active" data-level="CRITICAL" title="Toggle CRITICAL (5)">CRT</button>
      </div>

      <input type="text" class="search-input" id="searchInput" placeholder="Search logs... (/)" title="Search (/)">

      <div class="toolbar-spacer"></div>

      <div class="connection-status" id="connectionStatus">
        <span class="connection-dot"></span>
        <span class="connection-text">Disconnected</span>
      </div>

      <button class="toolbar-btn" id="autoScrollBtn" title="Toggle auto-scroll (G)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 5v14M5 12l7 7 7-7"/>
        </svg>
        <span>Auto</span>
      </button>

      <div class="dropdown" id="exportDropdown">
        <button class="toolbar-btn" id="exportBtn" title="Export logs (E)">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>
          </svg>
          <span>Export</span>
        </button>
      </div>

      <button class="toolbar-btn" id="themeBtn" title="Toggle theme (T)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" id="themeIcon">
          <circle cx="12" cy="12" r="5"/>
          <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>
        </svg>
      </button>

      <button class="toolbar-btn" id="helpBtn" title="Keyboard shortcuts (H)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"/>
          <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3M12 17h.01"/>
        </svg>
      </button>
    </div>

    <!-- Log list -->
    <div class="log-container" id="logContainer">
      <div class="empty-state">
        <div class="empty-state-icon">📋</div>
        <div>Select a run to view logs</div>
      </div>
    </div>

    <!-- Stats bar -->
    <div class="stats-bar">
      <div class="stat-item">
        <span>Total:</span>
        <span class="stat-count" id="statTotal">0</span>
      </div>
      <div class="stat-item">
        <span>Debug:</span>
        <span class="stat-count debug" id="statDebug">0</span>
      </div>
      <div class="stat-item">
        <span>Info:</span>
        <span class="stat-count info" id="statInfo">0</span>
      </div>
      <div class="stat-item">
        <span>Warning:</span>
        <span class="stat-count warning" id="statWarning">0</span>
      </div>
      <div class="stat-item">
        <span>Error:</span>
        <span class="stat-count error" id="statError">0</span>
      </div>
      <div class="stat-item">
        <span>Critical:</span>
        <span class="stat-count critical" id="statCritical">0</span>
      </div>
    </div>
  </main>
</div>

<!-- Jump to latest FAB -->
<button class="jump-fab" id="jumpFab">
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M12 5v14M5 12l7 7 7-7"/>
  </svg>
  Jump to latest
</button>

<!-- Help modal -->
<div class="modal-overlay" id="helpModal">
  <div class="modal">
    <div class="modal-header">
      <h2>⌨️ Keyboard Shortcuts</h2>
      <button class="modal-close" id="helpModalClose">&times;</button>
    </div>
    <div class="modal-body">
      """  # noqa: E501, S608
    + SHORTCUT_HELP_HTML
    + """
      <p style="margin-top: 20px; color: var(--text-muted); font-size: 12px;">
        Note: Some shortcuts may conflict with browser shortcuts. Focus the log viewer to use them.
      </p>
    </div>
  </div>
</div>

<!-- Export modal -->
<div class="modal-overlay" id="exportModal">
  <div class="modal">
    <div class="modal-header">
      <h2>📥 Export Logs</h2>
      <button class="modal-close" id="exportModalClose">&times;</button>
    </div>
    <div class="modal-body">
      <div class="export-warning" id="exportWarningText" style="display: none;">
        Export contains more logs than the limit.
      </div>
      <div class="export-options">
        <button class="export-option" data-format="json">
          <span class="export-option-icon">📄</span>
          <div>
            <div><strong>Export JSON</strong></div>
            <div style="font-size: 12px; color: var(--text-secondary);">All logs in JSON format</div>
          </div>
        </button>
        <button class="export-option" data-format="text">
          <span class="export-option-icon">📝</span>
          <div>
            <div><strong>Export Text</strong></div>
            <div style="font-size: 12px; color: var(--text-secondary);">All logs in plain text</div>
          </div>
        </button>
        <button class="export-option" data-format="json-filtered">
          <span class="export-option-icon">🔍</span>
          <div>
            <div><strong>Export Filtered JSON</strong></div>
            <div style="font-size: 12px; color: var(--text-secondary);">Only logs matching current filters</div>
          </div>
        </button>
        <button class="export-option" data-format="text-filtered">
          <span class="export-option-icon">🔎</span>
          <div>
            <div><strong>Export Filtered Text</strong></div>
            <div style="font-size: 12px; color: var(--text-secondary);">Only logs matching current filters</div>
          </div>
        </button>
      </div>
    </div>
  </div>
</div>

<script>
// ============================================================================
// State
// ============================================================================
const state = {
  currentRunId: null,
  isCurrentRun: false,
  runs: [],
  logs: [],
  eventSource: null,
  autoScroll: true,
  selectedIndex: -1,
  expandedIndices: new Set(), // Track which logs are expanded
  filters: {
    levels: new Set(['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']),
    search: '',
  },
  stats: { debug: 0, info: 0, warning: 0, error: 0, critical: 0, total: 0 },
  exportLimit: 50000,
  lastEventId: null,
};

// ============================================================================
// DOM Elements
// ============================================================================
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const elements = {
  sidebar: $('#sidebar'),
  sidebarBackdrop: $('#sidebarBackdrop'),
  runList: $('#runList'),
  logContainer: $('#logContainer'),
  searchInput: $('#searchInput'),
  levelFilters: $('#levelFilters'),
  autoScrollBtn: $('#autoScrollBtn'),
  jumpFab: $('#jumpFab'),
  helpModal: $('#helpModal'),
  exportModal: $('#exportModal'),
  exportDropdown: $('#exportDropdown'),
  exportBtn: $('#exportBtn'),
  connectionStatus: $('#connectionStatus'),
  themeBtn: $('#themeBtn'),
};

// ============================================================================
// Theme Management
// ============================================================================
function getTheme() {
  return localStorage.getItem('log-viewer-theme') || 'system';
}

function setTheme(theme) {
  localStorage.setItem('log-viewer-theme', theme);
  if (theme === 'system') {
    document.documentElement.removeAttribute('data-theme');
  } else {
    document.documentElement.setAttribute('data-theme', theme);
  }
}

function cycleTheme() {
  const current = getTheme();
  const next = current === 'system' ? 'light' : current === 'light' ? 'dark' : 'system';
  setTheme(next);
}

// Initialize theme
setTheme(getTheme());

// ============================================================================
// API Functions
// ============================================================================
async function fetchRuns() {
  try {
    const res = await fetch('/api/runs');
    state.runs = await res.json();
    renderRunList();
  } catch (e) {
    console.error('Failed to fetch runs:', e);
  }
}

async function fetchStats(runId) {
  try {
    const res = await fetch(`/api/stats/${runId}`);
    state.stats = await res.json();
    renderStats();
  } catch (e) {
    console.error('Failed to fetch stats:', e);
  }
}

async function fetchLogs(runId, cursor = null) {
  try {
    let url = `/api/logs/${runId}?limit=100`;
    if (cursor) url += `&cursor=${cursor}`;
    const res = await fetch(url);
    return await res.json();
  } catch (e) {
    console.error('Failed to fetch logs:', e);
    return { logs: [], next_cursor: null, has_more: false };
  }
}

async function checkExportCount(runId, filtered = false) {
  try {
    let url = `/api/export/${runId}/count`;
    if (filtered) {
      const params = buildFilterParams();
      if (params) url += `?${params}`;
    }
    const res = await fetch(url);
    return await res.json();
  } catch (e) {
    console.error('Failed to check export count:', e);
    return { count: 0, exceeds_limit: false };
  }
}

function buildFilterParams() {
  const params = new URLSearchParams();
  if (state.filters.levels.size < 5) {
    params.set('levels', Array.from(state.filters.levels).join(','));
  }
  if (state.filters.search) {
    params.set('search', state.filters.search);
  }
  return params.toString();
}

// ============================================================================
// SSE Streaming
// ============================================================================
function connectSSE(runId) {
  disconnectSSE();

  updateConnectionStatus('connecting');

  let url = `/api/logs/${runId}/stream`;
  if (state.lastEventId) {
    url += `?last_event_id=${state.lastEventId}`;
  }

  state.eventSource = new EventSource(url);

  state.eventSource.onopen = () => {
    updateConnectionStatus('connected');
  };

  state.eventSource.onmessage = (event) => {
    try {
      const log = JSON.parse(event.data);
      state.lastEventId = event.lastEventId || log.id;
      addLog(log);
    } catch (e) {
      console.error('Failed to parse SSE message:', e);
    }
  };

  state.eventSource.onerror = () => {
    updateConnectionStatus('disconnected');
    // Auto-reconnect after 2 seconds
    setTimeout(() => {
      if (state.currentRunId === runId && state.isCurrentRun) {
        connectSSE(runId);
      }
    }, 2000);
  };
}

function disconnectSSE() {
  if (state.eventSource) {
    state.eventSource.close();
    state.eventSource = null;
  }
  updateConnectionStatus('disconnected');
}

function updateConnectionStatus(status) {
  const dot = elements.connectionStatus.querySelector('.connection-dot');
  const text = elements.connectionStatus.querySelector('.connection-text');

  dot.className = 'connection-dot ' + status;
  text.textContent = status.charAt(0).toUpperCase() + status.slice(1);
}

// ============================================================================
// Rendering
// ============================================================================
function renderRunList() {
  if (!state.runs.length) {
    elements.runList.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📂</div><div>No runs found</div></div>';
    return;
  }

  elements.runList.innerHTML = state.runs.map(run => `
    <div class="run-item ${run.is_current ? 'current' : ''} ${run.run_id === state.currentRunId ? 'active' : ''}"
         data-run-id="${run.run_id}">
      <div class="run-item-header">
        <span class="run-item-id">${run.run_id.slice(0, 8)}...</span>
        ${run.is_current ? '<span class="live-badge">LIVE</span>' : ''}
      </div>
      <div class="run-item-meta">
        ${new Date(run.created_at).toLocaleString()} • ${run.log_count} logs
      </div>
    </div>
  `).join('');

  // Add click handlers
  elements.runList.querySelectorAll('.run-item').forEach(el => {
    el.addEventListener('click', () => selectRun(el.dataset.runId));
  });
}

function renderStats() {
  $('#statTotal').textContent = state.stats.total;
  $('#statDebug').textContent = state.stats.debug;
  $('#statInfo').textContent = state.stats.info;
  $('#statWarning').textContent = state.stats.warning;
  $('#statError').textContent = state.stats.error;
  $('#statCritical').textContent = state.stats.critical;
}

function renderLogs() {
  const filtered = filterLogsWithIndices(state.logs);

  if (!filtered.length) {
    elements.logContainer.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📋</div><div>No logs match your filters</div></div>';
    return;
  }

  elements.logContainer.innerHTML = filtered.map(({ log, originalIndex }) => renderLogEntry(log, originalIndex)).join('');

  // Add click handlers using event delegation
  elements.logContainer.querySelectorAll('.log-entry').forEach(el => {
    el.addEventListener('click', (e) => {
      // Don't toggle if clicking on a copy button or selecting text
      if (e.target.classList.contains('copy-btn') ||
          e.target.classList.contains('log-message-copy') ||
          window.getSelection().toString().length > 0) {
        return;
      }

      // Get the original index from the clicked element
      const index = parseInt(el.getAttribute('data-original-index'), 10);
      if (!isNaN(index)) {
        toggleLogExpansion(index);
      }
    });
  });

  // Add copy button handlers
  elements.logContainer.querySelectorAll('.copy-btn, .log-message-copy').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation(); // Prevent log expansion toggle

      const value = btn.getAttribute('data-copy-value');
      if (!value) return;

      try {
        await navigator.clipboard.writeText(value);

        // Show feedback
        const originalText = btn.textContent;
        btn.textContent = '✓ Copied';
        btn.classList.add('copied');

        setTimeout(() => {
          btn.textContent = originalText;
          btn.classList.remove('copied');
        }, 1500);
      } catch (err) {
        console.error('Failed to copy:', err);
        btn.textContent = '✗ Failed';
        setTimeout(() => {
          btn.textContent = 'Copy';
        }, 1500);
      }
    });
  });

  if (state.autoScroll) {
    scrollToBottom();
  }
}

function renderLogEntry(log, originalIndex) {
  const level = (log.level || 'INFO').toLowerCase();
  const time = log.timestamp ? new Date(log.timestamp).toLocaleTimeString() : '';
  const message = log.message || log.event || '';
  const module = log.module || '';
  const isSynthetic = log._synthetic || log._gap;
  const isExpanded = state.expandedIndices.has(originalIndex);

  const details = Object.entries(log)
    .filter(([k]) => !['id', 'timestamp', 'level', 'event', 'message', 'module', '_synthetic', '_gap'].includes(k))
    .map(([k, v]) => {
      const valueStr = JSON.stringify(v);
      return `<tr><th>${escapeHtml(k)}</th><td>${escapeHtml(valueStr)}<button class="copy-btn" data-copy-value="${escapeHtml(valueStr)}" title="Copy value">Copy</button></td></tr>`;
    })
    .join('');

  return `
    <div class="log-entry ${isSynthetic ? 'synthetic' : ''} ${isExpanded ? 'expanded' : ''} ${originalIndex === state.selectedIndex ? 'selected' : ''}" data-original-index="${originalIndex}">
      <div class="log-entry-main">
        <span class="log-time">${time}</span>
        <span class="log-level ${level}">${log.level || 'INFO'}</span>
        <span class="log-module">${escapeHtml(module)}</span>
        <div class="log-message-container">
          <span class="log-message">${escapeHtml(message)}</span>
          <button class="log-message-copy" data-copy-value="${escapeHtml(message)}" title="Copy message">Copy</button>
        </div>
      </div>
      ${details ? `<div class="log-details"><table class="log-details-table"><tbody>${details}</tbody></table></div>` : ''}
    </div>
  `;
}

function addLog(log) {
  state.logs.push(log);

  // Update stats
  const level = (log.level || 'INFO').toLowerCase();
  if (state.stats[level] !== undefined) {
    state.stats[level]++;
  }
  state.stats.total++;
  renderStats();

  // Add to DOM if passes filter
  if (passesFilter(log)) {
    const originalIndex = state.logs.length - 1;
    const html = renderLogEntry(log, originalIndex);
    const temp = document.createElement('div');
    temp.innerHTML = html;
    const el = temp.firstElementChild;

    el.addEventListener('click', (e) => {
      // Don't toggle if clicking on a copy button or selecting text
      if (e.target.classList.contains('copy-btn') ||
          e.target.classList.contains('log-message-copy') ||
          window.getSelection().toString().length > 0) {
        return;
      }

      const index = parseInt(el.getAttribute('data-original-index'), 10);
      if (!isNaN(index)) {
        toggleLogExpansion(index);
      }
    });

    // Add copy button handlers
    el.querySelectorAll('.copy-btn, .log-message-copy').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();

        const value = btn.getAttribute('data-copy-value');
        if (!value) return;

        try {
          await navigator.clipboard.writeText(value);

          const originalText = btn.textContent;
          btn.textContent = '✓ Copied';
          btn.classList.add('copied');

          setTimeout(() => {
            btn.textContent = originalText;
            btn.classList.remove('copied');
          }, 1500);
        } catch (err) {
          console.error('Failed to copy:', err);
          btn.textContent = '✗ Failed';
          setTimeout(() => {
            btn.textContent = 'Copy';
          }, 1500);
        }
      });
    });

    elements.logContainer.appendChild(el);

    if (state.autoScroll) {
      scrollToBottom();
    } else {
      elements.jumpFab.classList.add('visible');
    }
  }
}

function filterLogs(logs) {
  return logs.filter(passesFilter);
}

function filterLogsWithIndices(logs) {
  const result = [];
  logs.forEach((log, index) => {
    if (passesFilter(log)) {
      result.push({ log, originalIndex: index });
    }
  });
  return result;
}

function passesFilter(log) {
  const level = (log.level || 'INFO').toUpperCase();
  if (!state.filters.levels.has(level)) return false;

  if (state.filters.search) {
    const search = state.filters.search.toLowerCase();
    const text = JSON.stringify(log).toLowerCase();
    if (!text.includes(search)) return false;
  }

  return true;
}

function toggleLogExpansion(originalIndex) {
  // Toggle the expanded state
  if (state.expandedIndices.has(originalIndex)) {
    state.expandedIndices.delete(originalIndex);
  } else {
    state.expandedIndices.add(originalIndex);
  }

  // Find the element with this original index and toggle its class
  const el = elements.logContainer.querySelector(`[data-original-index="${originalIndex}"]`);
  if (el) {
    el.classList.toggle('expanded');
    state.selectedIndex = el.classList.contains('expanded') ? originalIndex : -1;
  }
}

function scrollToBottom() {
  elements.logContainer.scrollTop = elements.logContainer.scrollHeight;
}

function escapeHtml(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ============================================================================
// Run Selection
// ============================================================================
async function selectRun(runId) {
  state.currentRunId = runId;
  state.logs = [];
  state.lastEventId = null;
  state.selectedIndex = -1;
  state.expandedIndices.clear();

  const run = state.runs.find(r => r.run_id === runId);
  state.isCurrentRun = run?.is_current || false;

  // Update sidebar
  elements.runList.querySelectorAll('.run-item').forEach(el => {
    el.classList.toggle('active', el.dataset.runId === runId);
  });

  // Close mobile sidebar
  elements.sidebar.classList.remove('open');

  // Show loading
  elements.logContainer.innerHTML = '<div class="loading-spinner">Loading logs...</div>';

  // Fetch stats
  await fetchStats(runId);

  // Always fetch existing logs first
  const data = await fetchLogs(runId);
  state.logs = data.logs.reverse();
  renderLogs();

  if (state.isCurrentRun) {
    // Connect to SSE for real-time updates on current run
    connectSSE(runId);
  } else {
    disconnectSSE();
  }
}

// ============================================================================
// Event Handlers
// ============================================================================

// Level filter toggles
elements.levelFilters.addEventListener('click', (e) => {
  const btn = e.target.closest('.level-btn');
  if (!btn) return;

  const level = btn.dataset.level;
  btn.classList.toggle('active');

  if (btn.classList.contains('active')) {
    state.filters.levels.add(level);
  } else {
    state.filters.levels.delete(level);
  }

  renderLogs();
});

// Search input
let searchTimeout;
elements.searchInput.addEventListener('input', (e) => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => {
    state.filters.search = e.target.value;
    renderLogs();
  }, 150);
});

// Auto-scroll toggle
elements.autoScrollBtn.addEventListener('click', () => {
  state.autoScroll = !state.autoScroll;
  elements.autoScrollBtn.classList.toggle('active', state.autoScroll);
  if (state.autoScroll) {
    scrollToBottom();
    elements.jumpFab.classList.remove('visible');
  }
});

// Jump to latest
elements.jumpFab.addEventListener('click', () => {
  state.autoScroll = true;
  elements.autoScrollBtn.classList.add('active');
  scrollToBottom();
  elements.jumpFab.classList.remove('visible');
});

// Scroll detection for auto-scroll pause
elements.logContainer.addEventListener('scroll', () => {
  const { scrollTop, scrollHeight, clientHeight } = elements.logContainer;
  const isAtBottom = scrollTop + clientHeight >= scrollHeight - 50;

  if (!isAtBottom && state.autoScroll) {
    state.autoScroll = false;
    elements.autoScrollBtn.classList.remove('active');
  }

  elements.jumpFab.classList.toggle('visible', !isAtBottom && state.logs.length > 0);
});

// Mobile sidebar
$('#mobileMenuBtn').addEventListener('click', () => {
  elements.sidebar.classList.toggle('open');
});

elements.sidebarBackdrop.addEventListener('click', () => {
  elements.sidebar.classList.remove('open');
});

// Theme toggle
elements.themeBtn.addEventListener('click', cycleTheme);

// Help modal
$('#helpBtn').addEventListener('click', () => {
  elements.helpModal.classList.add('visible');
});

$('#helpModalClose').addEventListener('click', () => {
  elements.helpModal.classList.remove('visible');
});

elements.helpModal.addEventListener('click', (e) => {
  if (e.target === elements.helpModal) {
    elements.helpModal.classList.remove('visible');
  }
});

// Export dropdown
$('#exportBtn').addEventListener('click', () => {
  elements.exportDropdown.classList.toggle('open');
});

// Export button opens modal
elements.exportBtn.addEventListener('click', () => {
  if (!state.currentRunId) return;
  elements.exportModal.classList.add('visible');
});

// Export modal options
elements.exportModal.querySelectorAll('.export-option[data-format]').forEach(btn => {
  btn.addEventListener('click', async () => {
    const format = btn.dataset.format;
    const filtered = format.includes('filtered');
    const type = format.replace('-filtered', '');

    if (!state.currentRunId) return;

    // Check export count
    const { count, exceeds_limit } = await checkExportCount(state.currentRunId, filtered);

    if (exceeds_limit) {
      // Show warning but still download (with limit applied)
      triggerExport(type, filtered, state.exportLimit);
    } else {
      triggerExport(type, filtered);
    }

    elements.exportModal.classList.remove('visible');
  });
});

$('#exportModalClose').addEventListener('click', () => {
  elements.exportModal.classList.remove('visible');
});

function triggerExport(format, filtered, limit = null) {
  let url = `/api/export/${state.currentRunId}?format=${format}`;
  if (filtered) {
    const params = buildFilterParams();
    if (params) url += `&${params}`;
  }
  if (limit) url += `&limit=${limit}`;

  window.location.href = url;
}

// ============================================================================
// Keyboard Shortcuts
// ============================================================================
document.addEventListener('keydown', (e) => {
  // Skip if typing in input
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
    if (e.key === 'Escape') {
      e.target.blur();
      state.filters.search = '';
      elements.searchInput.value = '';
      renderLogs();
    }
    return;
  }

  switch (e.key) {
    case 'h':
    case 'H':
      e.preventDefault();
      elements.helpModal.classList.toggle('visible');
      break;
    case '/':
      e.preventDefault();
      elements.searchInput.focus();
      break;
    case 'Escape':
      elements.helpModal.classList.remove('visible');
      elements.exportModal.classList.remove('visible');
      elements.exportDropdown.classList.remove('open');
      elements.sidebar.classList.remove('open');
      break;
    case 'g':
    case 'G':
      state.autoScroll = !state.autoScroll;
      elements.autoScrollBtn.classList.toggle('active', state.autoScroll);
      if (state.autoScroll) scrollToBottom();
      break;
    case 't':
    case 'T':
      cycleTheme();
      break;
    case 'e':
    case 'E':
      elements.exportDropdown.classList.toggle('open');
      break;
    case 'r':
    case 'R':
      if (state.isCurrentRun && state.currentRunId) {
        connectSSE(state.currentRunId);
      }
      break;
    case '[':
      elements.sidebar.classList.toggle('open');
      break;
    case '1':
      toggleLevel('DEBUG');
      break;
    case '2':
      toggleLevel('INFO');
      break;
    case '3':
      toggleLevel('WARNING');
      break;
    case '4':
      toggleLevel('ERROR');
      break;
    case '5':
      toggleLevel('CRITICAL');
      break;
    case '0':
      resetFilters();
      break;
    case 'j':
    case 'ArrowDown':
      navigateLogs(1);
      break;
    case 'k':
    case 'ArrowUp':
      navigateLogs(-1);
      break;
    case 'Enter':
      if (state.selectedIndex >= 0) {
        toggleLogExpansion(state.selectedIndex);
      }
      break;
    case 'Home':
      elements.logContainer.scrollTop = 0;
      break;
    case 'End':
      scrollToBottom();
      break;
  }
});

function toggleLevel(level) {
  const btn = elements.levelFilters.querySelector(`[data-level="${level}"]`);
  if (btn) btn.click();
}

function resetFilters() {
  state.filters.levels = new Set(['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']);
  state.filters.search = '';
  elements.searchInput.value = '';
  elements.levelFilters.querySelectorAll('.level-btn').forEach(btn => {
    btn.classList.add('active');
  });
  renderLogs();
}

function navigateLogs(delta) {
  const filtered = filterLogs(state.logs);
  if (!filtered.length) return;

  const newIndex = Math.max(0, Math.min(filtered.length - 1, state.selectedIndex + delta));
  if (newIndex === state.selectedIndex) return;

  // Deselect old
  const oldEl = elements.logContainer.querySelector('.log-entry.selected');
  if (oldEl) oldEl.classList.remove('selected', 'expanded');

  state.selectedIndex = newIndex;

  // Select new
  const entries = elements.logContainer.querySelectorAll('.log-entry');
  if (entries[newIndex]) {
    entries[newIndex].classList.add('selected');
    entries[newIndex].scrollIntoView({ block: 'nearest' });
  }
}

// ============================================================================
// Touch Gestures (Mobile)
// ============================================================================
let touchStartX = 0;
let touchStartY = 0;

document.addEventListener('touchstart', (e) => {
  touchStartX = e.touches[0].clientX;
  touchStartY = e.touches[0].clientY;
}, { passive: true });

document.addEventListener('touchend', (e) => {
  const touchEndX = e.changedTouches[0].clientX;
  const touchEndY = e.changedTouches[0].clientY;

  const deltaX = touchEndX - touchStartX;
  const deltaY = touchEndY - touchStartY;

  // Horizontal swipe detection
  if (Math.abs(deltaX) > 50 && Math.abs(deltaX) > Math.abs(deltaY)) {
    if (deltaX > 0 && touchStartX < 30) {
      // Swipe right from edge - open sidebar
      elements.sidebar.classList.add('open');
    } else if (deltaX < 0 && elements.sidebar.classList.contains('open')) {
      // Swipe left - close sidebar
      elements.sidebar.classList.remove('open');
    }
  }
}, { passive: true });

// ============================================================================
// Initialize
// ============================================================================
async function init() {
  // Load auto-scroll preference
  state.autoScroll = localStorage.getItem('log-viewer-autoscroll') !== 'false';
  elements.autoScrollBtn.classList.toggle('active', state.autoScroll);

  // Fetch runs
  await fetchRuns();

  // Auto-select current run if available
  const currentRun = state.runs.find(r => r.is_current);
  if (currentRun) {
    selectRun(currentRun.run_id);
  }
}

// Save auto-scroll preference on change
const originalAutoScroll = Object.getOwnPropertyDescriptor(state, 'autoScroll');
Object.defineProperty(state, 'autoScroll', {
  get() { return this._autoScroll; },
  set(v) {
    this._autoScroll = v;
    localStorage.setItem('log-viewer-autoscroll', v);
  }
});
state._autoScroll = true;

init();
</script>
</body>
</html>
"""  # noqa: E501
)
