# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Test package for bozo._viewer subpackage."""
