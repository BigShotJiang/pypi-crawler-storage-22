# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._viewer._main module.

Tests viewer start/stop functions.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Generator
from unittest.mock import Mock, patch

import pytest

from bozo._main import setup
from bozo._state import reset_state
from bozo._types import HostAddress, PortNumber
from bozo._viewer._main import start_viewer, stop_viewer

if TYPE_CHECKING:
    from pathlib import Path
else:
    Path = object


@pytest.fixture(autouse=True)
def reset_logging() -> Generator[None, None, None]:
    """Reset logging state before and after each test."""
    reset_state()
    yield
    reset_state()


class TestStartViewer:
    """Tests for start_viewer function."""

    def test_requires_fastapi(self, tmp_path: Path) -> None:
        """Test that start_viewer requires FastAPI."""
        setup("testapp", log_dir=str(tmp_path))

        with patch("bozo._viewer._main.find_spec", return_value=None):
            with pytest.raises(ImportError, match="Web viewer requires"):
                start_viewer()

    def test_requires_configuration(self) -> None:
        """Test that start_viewer requires bozo to be configured."""
        with pytest.raises(RuntimeError, match="bozo not configured"):
            start_viewer()

    @patch("bozo._viewer._main.find_spec")
    @patch("bozo._viewer._main.ViewerServer")
    def test_uses_config_defaults(
        self, mock_server_class: Mock, mock_find_spec: Mock, tmp_path: Path
    ) -> None:
        """Test that start_viewer uses config defaults."""
        setup("testapp", enable_viewer=True, log_dir=str(tmp_path))

        mock_server = Mock()
        mock_server.url = "http://127.0.0.1:8080"
        mock_server_class.return_value = mock_server

        url = start_viewer()

        assert url == "http://127.0.0.1:8080"
        mock_server.start.assert_called_once()

    @patch("bozo._viewer._main.find_spec")
    @patch("bozo._viewer._main.ViewerServer")
    def test_uses_provided_host_port(
        self, mock_server_class: Mock, mock_find_spec: Mock, tmp_path: Path
    ) -> None:
        """Test that start_viewer uses provided host and port."""
        setup("testapp", enable_viewer=True, log_dir=str(tmp_path))

        mock_server = Mock()
        mock_server.url = "http://localhost:9000"
        mock_server_class.return_value = mock_server

        start_viewer(host=HostAddress("localhost"), port=PortNumber(9000))

        # Verify server was created with custom host/port
        call_args = mock_server_class.call_args
        assert call_args is not None

    @patch("bozo._viewer._main.find_spec")
    @patch("bozo._viewer._main.ViewerServer")
    @patch("webbrowser.open")
    def test_opens_browser(
        self,
        mock_browser: Mock,
        mock_server_class: Mock,
        mock_find_spec: Mock,
        tmp_path: Path,
    ) -> None:
        """Test that start_viewer opens browser when requested."""
        setup("testapp", enable_viewer=True, log_dir=str(tmp_path))

        mock_server = Mock()
        mock_server.url = "http://127.0.0.1:8080"
        mock_server_class.return_value = mock_server

        start_viewer(open_browser=True)

        mock_browser.assert_called_once_with("http://127.0.0.1:8080")

    @patch("bozo._viewer._main.find_spec")
    @patch("bozo._viewer._main.ViewerServer")
    def test_does_not_open_browser_by_default(
        self, mock_server_class: Mock, mock_find_spec: Mock, tmp_path: Path
    ) -> None:
        """Test that start_viewer doesn't open browser by default."""
        setup("testapp", enable_viewer=True, log_dir=str(tmp_path))

        mock_server = Mock()
        mock_server.url = "http://127.0.0.1:8080"
        mock_server_class.return_value = mock_server

        with patch("webbrowser.open") as mock_browser:
            start_viewer(open_browser=False)
            mock_browser.assert_not_called()

    def test_requires_log_dir(self, tmp_path: Path) -> None:
        """Test that start_viewer requires a log directory."""
        # Setup without log_dir defaults to platformdirs, so this test
        # verifies the viewer requires a configured log directory
        setup("testapp", log_dir=str(tmp_path))

        with patch("bozo._viewer._main.find_spec"):
            with patch("bozo._viewer._main.ViewerServer") as mock_server_class:
                mock_server = Mock()
                mock_server.url = "http://127.0.0.1:8080"
                mock_server_class.return_value = mock_server

                start_viewer()

                # Should have been called
                mock_server.start.assert_called_once()


class TestStopViewer:
    """Tests for stop_viewer function."""

    @patch("bozo._viewer._main.get_server")
    def test_stop_with_no_server(self, mock_get_server: Mock) -> None:
        """Test stop_viewer with no running server."""
        mock_get_server.return_value = None

        # Should not raise error
        stop_viewer()

    @patch("bozo._viewer._main.get_server")
    @patch("bozo._viewer._main.set_server")
    def test_stop_with_running_server(
        self, mock_set_server: Mock, mock_get_server: Mock
    ) -> None:
        """Test stop_viewer with running server."""
        mock_server = Mock()
        mock_get_server.return_value = mock_server

        stop_viewer()

        mock_server.stop.assert_called_once()
        mock_set_server.assert_called_once_with(None)

    @patch("bozo._viewer._main.get_server")
    def test_stop_with_custom_timeout(self, mock_get_server: Mock) -> None:
        """Test stop_viewer with custom timeout."""
        mock_server = Mock()
        mock_get_server.return_value = mock_server

        stop_viewer(timeout=10.0)

        mock_server.stop.assert_called_once_with(timeout=10.0)


class TestRequireDependency:
    """Tests for require_dependency function."""

    def test_existing_module(self) -> None:
        """Test require_dependency with existing module."""
        from bozo._viewer._main import require_dependency

        # Should not raise for built-in module
        require_dependency("os", "OS")

    def test_missing_module(self) -> None:
        """Test require_dependency with missing module."""
        from bozo._viewer._main import require_dependency

        with pytest.raises(ImportError, match="nonexistent_module is not installed"):
            require_dependency("nonexistent_module", "nonexistent_module")


class TestViewerIntegration:
    """Integration tests for viewer functions."""

    @patch("bozo._viewer._main.find_spec")
    @patch("bozo._viewer._main.ViewerServer")
    def test_start_stop_cycle(
        self, mock_server_class: Mock, mock_find_spec: Mock, tmp_path: Path
    ) -> None:
        """Test starting and stopping viewer."""
        setup("testapp", enable_viewer=True, log_dir=str(tmp_path))

        mock_server = Mock()
        mock_server.url = "http://127.0.0.1:8080"
        mock_server_class.return_value = mock_server

        # Start viewer
        url = start_viewer()
        assert url == "http://127.0.0.1:8080"

        # Stop viewer
        with patch("bozo._viewer._main.get_server", return_value=mock_server):
            stop_viewer()

        mock_server.stop.assert_called_once()
