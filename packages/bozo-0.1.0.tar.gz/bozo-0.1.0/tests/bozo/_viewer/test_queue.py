# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._viewer._queue module.

Tests bounded log queue with SSE streaming support.
"""

from __future__ import annotations

import asyncio
import json

import pytest

from bozo._types import DropCount, EventId, QueueSize, RunId
from bozo._viewer._queue import BoundedLogQueue


@pytest.fixture
def run_id() -> RunId:
    """Create a test run ID."""
    return RunId("12345678-1234-1234-1234-123456789012")


@pytest.fixture
def queue(run_id: RunId) -> BoundedLogQueue:
    """Create a bounded log queue."""
    # Remove any existing queue
    BoundedLogQueue.remove(run_id)
    return BoundedLogQueue.get_or_create(run_id, QueueSize(100))


class TestBoundedLogQueueInit:
    """Tests for BoundedLogQueue initialization."""

    def test_init(self, run_id: RunId) -> None:
        """Test queue initialization."""
        BoundedLogQueue.remove(run_id)
        queue = BoundedLogQueue(run_id, QueueSize(50))

        assert queue._run_id == run_id  # pyright: ignore[reportPrivateUsage]
        assert queue._max_size == QueueSize(50)  # pyright: ignore[reportPrivateUsage]
        assert len(queue._buffer) == 0  # pyright: ignore[reportPrivateUsage]
        assert queue._next_event_id == EventId(1)  # pyright: ignore[reportPrivateUsage]

    def test_get_or_create_new(self, run_id: RunId) -> None:
        """Test get_or_create creates new queue."""
        BoundedLogQueue.remove(run_id)
        queue = BoundedLogQueue.get_or_create(run_id, QueueSize(100))

        assert queue is not None
        assert queue._run_id == run_id  # pyright: ignore[reportPrivateUsage]

    def test_get_or_create_existing(self, run_id: RunId) -> None:
        """Test get_or_create returns existing queue."""
        BoundedLogQueue.remove(run_id)
        queue1 = BoundedLogQueue.get_or_create(run_id, QueueSize(100))
        queue2 = BoundedLogQueue.get_or_create(run_id, QueueSize(100))

        assert queue1 is queue2

    def test_get_nonexistent(self, run_id: RunId) -> None:
        """Test get returns None for nonexistent queue."""
        BoundedLogQueue.remove(run_id)
        queue = BoundedLogQueue.get(run_id)

        assert queue is None

    def test_get_existing(self, run_id: RunId) -> None:
        """Test get returns existing queue."""
        BoundedLogQueue.remove(run_id)
        created = BoundedLogQueue.get_or_create(run_id, QueueSize(100))
        retrieved = BoundedLogQueue.get(run_id)

        assert retrieved is created

    def test_remove(self, run_id: RunId) -> None:
        """Test removing queue from registry."""
        BoundedLogQueue.remove(run_id)
        BoundedLogQueue.get_or_create(run_id, QueueSize(100))

        BoundedLogQueue.remove(run_id)

        queue = BoundedLogQueue.get(run_id)
        assert queue is None

    def test_list_run_ids_empty(self) -> None:
        """Test listing run IDs when empty."""
        # Clear all queues first
        for run_id in BoundedLogQueue.list_run_ids():
            BoundedLogQueue.remove(run_id)

        run_ids = BoundedLogQueue.list_run_ids()
        # May not be empty if other tests are running
        assert isinstance(run_ids, list)

    def test_list_run_ids_with_queues(self) -> None:
        """Test listing run IDs with queues."""
        run_id1 = RunId("11111111-1111-1111-1111-111111111111")
        run_id2 = RunId("22222222-2222-2222-2222-222222222222")

        BoundedLogQueue.remove(run_id1)
        BoundedLogQueue.remove(run_id2)

        BoundedLogQueue.get_or_create(run_id1, QueueSize(100))
        BoundedLogQueue.get_or_create(run_id2, QueueSize(100))

        run_ids = BoundedLogQueue.list_run_ids()

        assert run_id1 in run_ids
        assert run_id2 in run_ids


class TestPutNowait:
    """Tests for put_nowait method."""

    def test_put_single_entry(self, queue: BoundedLogQueue) -> None:
        """Test adding single entry."""
        log_entry = json.dumps({"level": "INFO", "message": "test"})
        event_id = queue.put_nowait(log_entry)

        assert event_id == EventId(1)
        assert len(queue._buffer) == 1  # pyright: ignore[reportPrivateUsage]

    def test_put_multiple_entries(self, queue: BoundedLogQueue) -> None:
        """Test adding multiple entries."""
        for i in range(5):
            log_entry = json.dumps({"level": "INFO", "message": f"test {i}"})
            queue.put_nowait(log_entry)

        assert len(queue._buffer) == 5  # pyright: ignore[reportPrivateUsage]

    def test_event_id_increments(self, queue: BoundedLogQueue) -> None:
        """Test that event ID increments."""
        id1 = queue.put_nowait("log1")
        id2 = queue.put_nowait("log2")
        id3 = queue.put_nowait("log3")

        assert id1 == EventId(1)
        assert id2 == EventId(2)
        assert id3 == EventId(3)

    def test_drops_oldest_when_full(self, run_id: RunId) -> None:
        """Test that oldest entry is dropped when queue is full."""
        BoundedLogQueue.remove(run_id)
        small_queue = BoundedLogQueue(run_id, QueueSize(3))

        small_queue.put_nowait("log1")
        small_queue.put_nowait("log2")
        small_queue.put_nowait("log3")
        small_queue.put_nowait("log4")  # Should drop log1

        assert len(small_queue._buffer) == 3  # pyright: ignore[reportPrivateUsage]

        # Get all entries
        entries = small_queue.get_all()
        messages: list[str] = []
        for entry in entries:
            payload = entry[1]
            if payload.lstrip().startswith("{"):
                parsed = json.loads(payload)
                messages.append(parsed.get("message", payload))
            else:
                messages.append(payload)

        # log1 should be dropped
        assert "log1" not in str(messages)

    def test_increments_drop_count(self, run_id: RunId) -> None:
        """Test that drop count is incremented."""
        BoundedLogQueue.remove(run_id)
        small_queue = BoundedLogQueue(run_id, QueueSize(2))

        small_queue.put_nowait("log1")
        small_queue.put_nowait("log2")

        assert small_queue.drop_count == DropCount(0)

        small_queue.put_nowait("log3")  # Drops log1

        assert small_queue.drop_count == DropCount(1)
        assert small_queue.total_drops == DropCount(1)


class TestGetAll:
    """Tests for get_all method."""

    def test_get_all_empty(self, queue: BoundedLogQueue) -> None:
        """Test get_all with empty queue."""
        entries = queue.get_all()

        assert entries == []

    def test_get_all_with_entries(self, queue: BoundedLogQueue) -> None:
        """Test get_all with entries."""
        queue.put_nowait("log1")
        queue.put_nowait("log2")
        queue.put_nowait("log3")

        entries = queue.get_all()

        assert len(entries) == 3
        assert entries[0][0] == EventId(1)
        assert entries[1][0] == EventId(2)
        assert entries[2][0] == EventId(3)

    def test_get_all_returns_copy(self, queue: BoundedLogQueue) -> None:
        """Test that get_all returns a copy."""
        queue.put_nowait("log1")

        entries1 = queue.get_all()
        entries2 = queue.get_all()

        assert entries1 is not entries2
        assert entries1 == entries2


class TestGetFromId:
    """Tests for get_from_id method."""

    def test_get_from_id_exact_match(self, queue: BoundedLogQueue) -> None:
        """Test getting entries from exact event ID."""
        queue.put_nowait("log1")
        queue.put_nowait("log2")
        queue.put_nowait("log3")

        entries = queue.get_from_id(EventId(2))

        assert entries is not None
        assert len(entries) == 1
        assert entries[0][0] == EventId(3)

    def test_get_from_id_first(self, queue: BoundedLogQueue) -> None:
        """Test getting entries from first event ID."""
        queue.put_nowait("log1")
        queue.put_nowait("log2")
        queue.put_nowait("log3")

        entries = queue.get_from_id(EventId(1))

        assert entries is not None
        assert len(entries) == 2

    def test_get_from_id_nonexistent(self, queue: BoundedLogQueue) -> None:
        """Test get_from_id with nonexistent event ID."""
        queue.put_nowait("log1")
        queue.put_nowait("log2")

        entries = queue.get_from_id(EventId(999))

        assert entries is None

    def test_get_from_id_after_drop(self, run_id: RunId) -> None:
        """Test get_from_id after entries are dropped."""
        BoundedLogQueue.remove(run_id)
        small_queue = BoundedLogQueue(run_id, QueueSize(3))

        small_queue.put_nowait("log1")
        small_queue.put_nowait("log2")
        small_queue.put_nowait("log3")
        small_queue.put_nowait("log4")  # Drops log1

        # Try to get from dropped event
        entries = small_queue.get_from_id(EventId(1))

        assert entries is None  # Event 1 was dropped


class TestAsyncIntegration:
    """Tests for async integration."""

    @pytest.mark.asyncio
    async def test_get_async_event(self, queue: BoundedLogQueue) -> None:
        """Test getting async event."""
        loop = asyncio.get_running_loop()
        event = queue.get_async_event(loop)

        assert isinstance(event, asyncio.Event)
        assert not event.is_set()

    @pytest.mark.asyncio
    async def test_async_event_signaled_on_put(self, queue: BoundedLogQueue) -> None:
        """Test that async event is signaled on put."""
        loop = asyncio.get_running_loop()
        event = queue.get_async_event(loop)

        # Put entry in separate task
        async def put_entry() -> None:
            await asyncio.sleep(0.1)
            queue.put_nowait("test log")

        task = asyncio.create_task(put_entry())

        # Wait for event
        await asyncio.wait_for(event.wait(), timeout=1.0)

        assert event.is_set()
        await task

    @pytest.mark.asyncio
    async def test_async_event_reused_for_same_loop(
        self, queue: BoundedLogQueue
    ) -> None:
        """Test that async event is reused for the same loop."""
        loop = asyncio.get_running_loop()
        event1 = queue.get_async_event(loop)
        event2 = queue.get_async_event(loop)

        assert event1 is event2


class TestThreadSafety:
    """Tests for thread safety."""

    def test_concurrent_put(self, queue: BoundedLogQueue) -> None:
        """Test concurrent put operations."""
        import threading

        def worker(index: int) -> None:
            for i in range(10):
                queue.put_nowait(f"log{index}-{i}")

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(5)]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All entries should be added (or dropped if queue full)
        entries = queue.get_all()
        assert len(entries) <= 100  # Queue size

    def test_concurrent_get_all(self, queue: BoundedLogQueue) -> None:
        """Test concurrent get_all operations."""
        import threading

        queue.put_nowait("log1")
        queue.put_nowait("log2")

        results: list[list[tuple[EventId, str]]] = []

        def worker() -> None:
            entries = queue.get_all()
            results.append(entries)

        threads = [threading.Thread(target=worker) for _ in range(5)]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All threads should get the same results
        assert len(results) == 5
        assert all(len(r) == 2 for r in results)
