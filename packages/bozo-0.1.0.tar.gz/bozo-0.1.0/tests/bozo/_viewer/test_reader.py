# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._viewer._reader module.

Tests reverse file reading and pagination.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

import pytest

from bozo._types import LogFilePath
from bozo._viewer._reader import (
    count_logs_with_filter,
    read_json_log_backwards,
    read_json_log_forward,
)

if TYPE_CHECKING:
    from pytest import TempPathFactory
else:
    TempPathFactory = object


@pytest.fixture
def json_log_file(tmp_path_factory: TempPathFactory) -> Path:
    """Create a test JSON log file."""
    log_file = tmp_path_factory.mktemp("logs") / "test.json.log"

    # Write test log entries
    entries = [
        {"timestamp": "2026-01-01T00:00:00", "level": "INFO", "event": f"message {i}"}
        for i in range(10)
    ]

    with open(log_file, "w") as f:
        for entry in entries:
            f.write(json.dumps(entry) + "\n")

    return log_file


class TestReadJsonLogBackwards:
    """Tests for read_json_log_backwards function."""

    @pytest.mark.asyncio
    async def test_read_nonexistent_file(self) -> None:
        """Test reading nonexistent file."""
        result = await read_json_log_backwards(
            LogFilePath("/nonexistent/file.json"), cursor=None, limit=10
        )

        assert result["logs"] == []
        assert result["next_cursor"] is None
        assert result["has_more"] is False
        assert result["total_count"] == 0

    @pytest.mark.asyncio
    async def test_read_empty_file(self, tmp_path: Path) -> None:
        """Test reading empty file."""
        empty_file = tmp_path / "empty.json.log"
        empty_file.touch()

        result = await read_json_log_backwards(
            LogFilePath(str(empty_file)), cursor=None, limit=10
        )

        assert result["logs"] == []
        assert result["next_cursor"] is None
        assert result["has_more"] is False

    @pytest.mark.asyncio
    async def test_read_all_logs(self, json_log_file: Path) -> None:
        """Test reading all logs."""
        result = await read_json_log_backwards(
            LogFilePath(str(json_log_file)), cursor=None, limit=100
        )

        assert len(result["logs"]) == 10
        assert result["next_cursor"] is None
        assert result["has_more"] is False

    @pytest.mark.asyncio
    async def test_read_with_limit(self, json_log_file: Path) -> None:
        """Test reading with limit."""
        result = await read_json_log_backwards(
            LogFilePath(str(json_log_file)), cursor=None, limit=5
        )

        assert len(result["logs"]) == 5
        assert result["total_count"] == 10

    @pytest.mark.asyncio
    async def test_read_backwards_order(self, json_log_file: Path) -> None:
        """Test that logs are read in reverse order."""
        result = await read_json_log_backwards(
            LogFilePath(str(json_log_file)), cursor=None, limit=3
        )

        # Should get last 3 entries in reverse order (newest first)
        assert len(result["logs"]) == 3


class TestReadJsonLogForward:
    """Tests for read_json_log_forward function."""

    @pytest.mark.asyncio
    async def test_read_nonexistent_file(self) -> None:
        """Test reading nonexistent file."""
        result = await read_json_log_forward(
            LogFilePath("/nonexistent/file.json"), cursor=None, limit=10
        )

        assert result["logs"] == []
        assert result["next_cursor"] is None
        assert result["has_more"] is False

    @pytest.mark.asyncio
    async def test_read_from_start(self, json_log_file: Path) -> None:
        """Test reading from start of file."""
        result = await read_json_log_forward(
            LogFilePath(str(json_log_file)), cursor=None, limit=5
        )

        assert len(result["logs"]) == 5
        assert result["next_cursor"] is not None
        assert result["has_more"] is True

    @pytest.mark.asyncio
    async def test_read_with_cursor(self, json_log_file: Path) -> None:
        """Test reading from specific cursor."""
        # First read to get cursor
        result1 = await read_json_log_forward(
            LogFilePath(str(json_log_file)), cursor=None, limit=5
        )

        # Read next page
        result2 = await read_json_log_forward(
            LogFilePath(str(json_log_file)),
            cursor=result1["next_cursor"],
            limit=5,
        )

        assert len(result2["logs"]) == 4

    @pytest.mark.asyncio
    async def test_read_all_logs(self, json_log_file: Path) -> None:
        """Test reading all logs forward."""
        result = await read_json_log_forward(
            LogFilePath(str(json_log_file)), cursor=None, limit=100
        )

        assert len(result["logs"]) == 10
        assert result["next_cursor"] is None or not result["has_more"]


class TestCountLogsWithFilter:
    """Tests for count_logs_with_filter function."""

    @pytest.mark.asyncio
    async def test_count_nonexistent_file(self) -> None:
        """Test counting logs in nonexistent file."""
        count = await count_logs_with_filter(
            LogFilePath("/nonexistent/file.json"),
            levels=None,
            from_time=None,
            to_time=None,
            search=None,
        )

        assert count == 0

    @pytest.mark.asyncio
    async def test_count_all_logs(self, json_log_file: Path) -> None:
        """Test counting all logs."""
        count = await count_logs_with_filter(
            LogFilePath(str(json_log_file)),
            levels=None,
            from_time=None,
            to_time=None,
            search=None,
        )

        assert count == 10

    @pytest.mark.asyncio
    async def test_count_with_level_filter(self, json_log_file: Path) -> None:
        """Test counting with level filter."""
        count = await count_logs_with_filter(
            LogFilePath(str(json_log_file)),
            levels={"INFO"},
            from_time=None,
            to_time=None,
            search=None,
        )

        assert count == 10  # All entries are INFO level

    @pytest.mark.asyncio
    async def test_count_with_search(self, json_log_file: Path) -> None:
        """Test counting with search filter."""
        count = await count_logs_with_filter(
            LogFilePath(str(json_log_file)),
            levels=None,
            from_time=None,
            to_time=None,
            search="message 5",
        )

        assert count == 1

    @pytest.mark.asyncio
    async def test_count_with_time_filter(self, json_log_file: Path) -> None:
        """Test counting with time filter."""
        count = await count_logs_with_filter(
            LogFilePath(str(json_log_file)),
            levels=None,
            from_time="2025-12-31T00:00:00",
            to_time="2026-12-31T00:00:00",
            search=None,
        )

        assert count == 10  # All entries in 2026

    @pytest.mark.asyncio
    async def test_count_with_multiple_filters(self, json_log_file: Path) -> None:
        """Test counting with multiple filters."""
        count = await count_logs_with_filter(
            LogFilePath(str(json_log_file)),
            levels={"INFO"},
            from_time="2026-01-01T00:00:00",
            to_time="2026-12-31T00:00:00",
            search="message",
        )

        assert count == 10  # All entries match all filters
