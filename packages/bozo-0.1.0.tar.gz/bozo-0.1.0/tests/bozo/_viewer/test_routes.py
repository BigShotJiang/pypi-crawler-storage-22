# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._viewer._routes module.

Tests FastAPI routes and endpoints.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from bozo._types import ExportLimit, LogDirPath, RunId


class TestViewerRoutes:
    """Tests for viewer routes."""

    @pytest.fixture
    def test_client(
        self,
        tmp_path: pytest.TempPathFactory,
    ) -> TestClient:
        """Create a test FastAPI client."""
        from fastapi import FastAPI

        from bozo._viewer._routes import create_routes

        app = FastAPI()
        create_routes(
            app,
            LogDirPath(str(tmp_path)),
            RunId("12345678-1234-1234-1234-123456789012"),
            ExportLimit(50000),
        )
        return TestClient(app)

    def test_viewer_root(self, test_client: TestClient) -> None:
        """Test GET / returns HTML."""
        response = test_client.get("/")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]

    def test_get_runs(self, test_client: TestClient) -> None:
        """Test GET /api/runs."""
        response = test_client.get("/api/runs")
        assert response.status_code == 200
        assert isinstance(response.json(), list)

    def test_get_logs(self, test_client: TestClient) -> None:
        """Test GET /api/logs/{run_id}."""
        response = test_client.get(
            "/api/logs/12345678-1234-1234-1234-123456789012",
            params={"limit": 100},
        )
        assert response.status_code == 200
        data = response.json()
        assert "logs" in data
        assert "next_cursor" in data
        assert "has_more" in data

    def test_get_stats(self, test_client: TestClient) -> None:
        """Test GET /api/stats/{run_id}."""
        response = test_client.get("/api/stats/12345678-1234-1234-1234-123456789012")
        assert response.status_code == 200
        data = response.json()
        assert "total" in data
        assert "debug" in data
        assert "info" in data

    def test_get_export_count(self, test_client: TestClient) -> None:
        """Test GET /api/export/{run_id}/count."""
        response = test_client.get(
            "/api/export/12345678-1234-1234-1234-123456789012/count"
        )
        assert response.status_code == 200
        data = response.json()
        assert "count" in data
        assert "exceeds_limit" in data
