# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._viewer._server module.

Tests ViewerServer class and server management.
"""

from __future__ import annotations

from unittest.mock import Mock, patch

from bozo._types import ExportLimit, HostAddress, LogDirPath, PortNumber, RunId
from bozo._viewer._server import ViewerServer, get_server, set_server


class TestViewerServer:
    """Tests for ViewerServer class."""

    def test_init(self) -> None:
        """Test ViewerServer initialization."""
        server = ViewerServer(
            log_dir=LogDirPath("/tmp/logs"),
            current_run_id=RunId("12345678-1234-1234-1234-123456789012"),
            host=HostAddress("127.0.0.1"),
            port=PortNumber(8080),
            export_limit=ExportLimit(50000),
        )

        assert server._host == "127.0.0.1"  # pyright: ignore[reportPrivateUsage]
        assert server._port == 8080  # pyright: ignore[reportPrivateUsage]
        assert server._log_dir == "/tmp/logs"  # pyright: ignore[reportPrivateUsage]

    def test_url_property(self) -> None:
        """Test URL property."""
        server = ViewerServer(
            log_dir=LogDirPath("/tmp/logs"),
            current_run_id=RunId("12345678-1234-1234-1234-123456789012"),
            host=HostAddress("localhost"),
            port=PortNumber(9000),
            export_limit=ExportLimit(50000),
        )

        assert server.url == "http://localhost:9000"

    @patch("bozo._viewer._server.FastAPI")
    def test_create_app(self, mock_fastapi: Mock) -> None:
        """Test _create_app method."""
        server = ViewerServer(
            log_dir=LogDirPath("/tmp/logs"),
            current_run_id=RunId("12345678-1234-1234-1234-123456789012"),
            host=HostAddress("127.0.0.1"),
            port=PortNumber(8080),
            export_limit=ExportLimit(50000),
        )

        mock_app = Mock()
        mock_fastapi.return_value = mock_app

        app = server._create_app()  # pyright: ignore[reportPrivateUsage]

        assert app is not None
        mock_app.add_middleware.assert_called()

    @patch("bozo._viewer._server.uvicorn.Server")
    @patch("bozo._viewer._server.asyncio.run")
    def test_run_server(self, mock_run: Mock, mock_server: Mock) -> None:
        """Test _run_server method."""
        server = ViewerServer(
            log_dir=LogDirPath("/tmp/logs"),
            current_run_id=RunId("12345678-1234-1234-1234-123456789012"),
            host=HostAddress("127.0.0.1"),
            port=PortNumber(8080),
            export_limit=ExportLimit(50000),
        )

        # This would normally run in a thread
        # Just verify it creates uvicorn server
        mock_uvicorn_server = Mock()
        mock_server.return_value = mock_uvicorn_server

        # Can't easily test this without starting actual thread
        # So just verify initialization worked
        assert (
            server._app is None  # pyright: ignore[reportPrivateUsage]
        )  # Not started yet

    def test_is_running_false_initially(self) -> None:
        """Test is_running returns False initially."""
        server = ViewerServer(
            log_dir=LogDirPath("/tmp/logs"),
            current_run_id=RunId("12345678-1234-1234-1234-123456789012"),
            host=HostAddress("127.0.0.1"),
            port=PortNumber(8080),
            export_limit=ExportLimit(50000),
        )

        assert server.is_running() is False

    def test_stop_when_not_running(self) -> None:
        """Test stop when server is not running."""
        server = ViewerServer(
            log_dir=LogDirPath("/tmp/logs"),
            current_run_id=RunId("12345678-1234-1234-1234-123456789012"),
            host=HostAddress("127.0.0.1"),
            port=PortNumber(8080),
            export_limit=ExportLimit(50000),
        )

        # Should not raise error
        server.stop()


class TestServerManager:
    """Tests for server manager functions."""

    def test_get_server_initially_none(self) -> None:
        """Test get_server returns None initially."""
        set_server(None)  # Clear any existing server
        server = get_server()
        assert server is None

    def test_set_and_get_server(self) -> None:
        """Test setting and getting server."""
        mock_server = Mock(spec=ViewerServer)
        set_server(mock_server)

        server = get_server()
        assert server is mock_server

    def test_set_server_to_none(self) -> None:
        """Test setting server to None."""
        mock_server = Mock(spec=ViewerServer)
        set_server(mock_server)
        set_server(None)

        server = get_server()
        assert server is None

    def test_overwrite_server(self) -> None:
        """Test overwriting existing server."""
        mock_server1 = Mock(spec=ViewerServer)
        mock_server2 = Mock(spec=ViewerServer)

        set_server(mock_server1)
        set_server(mock_server2)

        server = get_server()
        assert server is mock_server2
