# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._viewer._template module.

Tests HTML template and constants.
"""

from __future__ import annotations

from bozo._viewer._template import SHORTCUT_HELP_HTML, VIEWER_HTML


class TestViewerTemplate:
    """Tests for VIEWER_HTML template."""

    def test_viewer_html_is_string(self) -> None:
        """Test that VIEWER_HTML is a string."""
        assert isinstance(VIEWER_HTML, str)

    def test_viewer_html_not_empty(self) -> None:
        """Test that VIEWER_HTML is not empty."""
        assert len(VIEWER_HTML) > 0

    def test_viewer_html_is_html(self) -> None:
        """Test that VIEWER_HTML contains HTML."""
        assert "<!DOCTYPE html>" in VIEWER_HTML
        assert "<html" in VIEWER_HTML
        assert "</html>" in VIEWER_HTML

    def test_viewer_html_has_head(self) -> None:
        """Test that VIEWER_HTML has head section."""
        assert "<head>" in VIEWER_HTML
        assert "</head>" in VIEWER_HTML

    def test_viewer_html_has_body(self) -> None:
        """Test that VIEWER_HTML has body section."""
        assert "<body>" in VIEWER_HTML
        assert "</body>" in VIEWER_HTML

    def test_viewer_html_has_title(self) -> None:
        """Test that VIEWER_HTML has title."""
        assert "<title>" in VIEWER_HTML
        assert "bozo" in VIEWER_HTML.lower()

    def test_viewer_html_has_css(self) -> None:
        """Test that VIEWER_HTML has CSS."""
        assert "<style>" in VIEWER_HTML
        assert "</style>" in VIEWER_HTML

    def test_viewer_html_has_javascript(self) -> None:
        """Test that VIEWER_HTML has JavaScript."""
        assert "<script>" in VIEWER_HTML
        assert "</script>" in VIEWER_HTML

    def test_viewer_html_valid_structure(self) -> None:
        """Test that VIEWER_HTML has valid basic structure."""
        # Check for basic HTML5 structure
        assert VIEWER_HTML.count("<html") == VIEWER_HTML.count("</html>")
        assert VIEWER_HTML.count("<head>") == VIEWER_HTML.count("</head>")
        assert VIEWER_HTML.count("<body>") == VIEWER_HTML.count("</body>")


class TestShortcutHelpHTML:
    """Tests for SHORTCUT_HELP_HTML."""

    def test_shortcut_help_is_string(self) -> None:
        """Test that SHORTCUT_HELP_HTML is a string."""
        assert isinstance(SHORTCUT_HELP_HTML, str)

    def test_shortcut_help_not_empty(self) -> None:
        """Test that SHORTCUT_HELP_HTML is not empty."""
        assert len(SHORTCUT_HELP_HTML) > 0

    def test_shortcut_help_has_categories(self) -> None:
        """Test that SHORTCUT_HELP_HTML has category sections."""
        assert "Navigation" in SHORTCUT_HELP_HTML
        assert "Filters" in SHORTCUT_HELP_HTML
        assert "Actions" in SHORTCUT_HELP_HTML
        assert "View" in SHORTCUT_HELP_HTML

    def test_shortcut_help_has_kbd_tags(self) -> None:
        """Test that SHORTCUT_HELP_HTML has keyboard tags."""
        assert "<kbd>" in SHORTCUT_HELP_HTML
        assert "</kbd>" in SHORTCUT_HELP_HTML

    def test_shortcut_help_has_descriptions(self) -> None:
        """Test that SHORTCUT_HELP_HTML has shortcut descriptions."""
        # Should have some common shortcuts
        assert any(key in SHORTCUT_HELP_HTML for key in ["j", "k", "Enter", "Escape"])
