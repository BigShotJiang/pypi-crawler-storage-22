# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._cleanup module.

Tests all functions and edge cases for run directory cleanup.
"""

from __future__ import annotations

import uuid
from pathlib import Path
from typing import TYPE_CHECKING

import pytest

from bozo._cleanup import is_valid_run_id, cleanup_old_runs, list_runs
from bozo._types import LogDirPath, RunId

if TYPE_CHECKING:
    from pytest import TempPathFactory
else:
    TempPathFactory = object


@pytest.fixture
def log_dir(tmp_path_factory: TempPathFactory) -> Path:
    """Create a temporary log directory."""
    return tmp_path_factory.mktemp("logs")


class TestIsValidRunId:
    """Tests for is_valid_run_id function."""

    def test_valid_uuid(self) -> None:
        """Test with valid UUID."""
        valid_uuid = str(uuid.uuid4())
        assert is_valid_run_id(valid_uuid)

    def test_valid_uuid_uppercase(self) -> None:
        """Test with uppercase UUID."""
        valid_uuid = str(uuid.uuid4()).upper()
        assert is_valid_run_id(valid_uuid)

    def test_valid_uuid_with_hyphens(self) -> None:
        """Test with standard UUID format with hyphens."""
        valid_uuid = "123e4567-e89b-12d3-a456-426614174000"
        assert is_valid_run_id(valid_uuid)

    def test_invalid_string(self) -> None:
        """Test with invalid string."""
        assert not is_valid_run_id("not-a-uuid")

    def test_empty_string(self) -> None:
        """Test with empty string."""
        assert not is_valid_run_id("")

    def test_numeric_string(self) -> None:
        """Test with numeric string."""
        assert not is_valid_run_id("12345")

    def test_partial_uuid(self) -> None:
        """Test with partial UUID."""
        assert not is_valid_run_id("123e4567-e89b")

    def test_special_characters(self) -> None:
        """Test with special characters."""
        assert not is_valid_run_id("abc-def-ghi-jkl-mno!")


class TestCleanupOldRuns:
    """Tests for cleanup_old_runs function."""

    def test_cleanup_no_directories(self, log_dir: Path) -> None:
        """Test cleanup with no directories."""
        current_run = RunId(str(uuid.uuid4()))
        result = cleanup_old_runs(
            LogDirPath(str(log_dir)),
            max_runs_to_keep=5,
            current_run_id=current_run,
        )
        assert result == 0

    def test_cleanup_nonexistent_directory(self) -> None:
        """Test cleanup with nonexistent directory."""
        current_run = RunId(str(uuid.uuid4()))
        result = cleanup_old_runs(
            LogDirPath("/nonexistent/path"),
            max_runs_to_keep=5,
            current_run_id=current_run,
        )
        assert result == 0

    def test_cleanup_keeps_current_run(self, log_dir: Path) -> None:
        """Test that current run is never deleted."""
        current_run = RunId(str(uuid.uuid4()))
        current_run_dir = log_dir / current_run
        current_run_dir.mkdir()

        result = cleanup_old_runs(
            LogDirPath(str(log_dir)),
            max_runs_to_keep=1,
            current_run_id=current_run,
        )

        assert result == 0
        assert current_run_dir.exists()

    def test_cleanup_removes_old_runs(self, log_dir: Path) -> None:
        """Test that old runs are removed."""
        # Create 5 old run directories
        old_runs = [RunId(str(uuid.uuid4())) for _ in range(5)]
        for run_id in old_runs:
            (log_dir / run_id).mkdir()

        current_run = RunId(str(uuid.uuid4()))
        (log_dir / current_run).mkdir()

        # Keep only 3 runs (including current)
        with pytest.warns(UserWarning, match="Cleaned up"):
            result = cleanup_old_runs(
                LogDirPath(str(log_dir)),
                max_runs_to_keep=3,
                current_run_id=current_run,
            )

        assert result == 3  # Should delete 3 old runs
        assert (log_dir / current_run).exists()

    def test_cleanup_keeps_newest_runs(self, log_dir: Path) -> None:
        """Test that newest runs are kept."""
        # Create runs with different modification times
        import time

        runs: list[tuple[RunId, Path]] = []
        for _ in range(5):
            run_id = RunId(str(uuid.uuid4()))
            run_dir = log_dir / run_id
            run_dir.mkdir()
            runs.append((run_id, run_dir))
            time.sleep(0.01)  # Ensure different mtimes

        current_run = RunId(str(uuid.uuid4()))
        (log_dir / current_run).mkdir()

        # Keep 3 runs total (including current)
        with pytest.warns(UserWarning, match="Cleaned up"):
            cleanup_old_runs(
                LogDirPath(str(log_dir)),
                max_runs_to_keep=3,
                current_run_id=current_run,
            )

        # The 2 newest old runs should remain
        remaining = [d.name for d in log_dir.iterdir() if d.is_dir()]
        assert len(remaining) == 3
        assert current_run in remaining

    def test_cleanup_invalid_max_runs(self, log_dir: Path) -> None:
        """Test with invalid max_runs_to_keep."""
        current_run = RunId(str(uuid.uuid4()))

        with pytest.raises(ValueError, match="max_runs_to_keep must be >= 1"):
            cleanup_old_runs(
                LogDirPath(str(log_dir)),
                max_runs_to_keep=0,
                current_run_id=current_run,
            )

        with pytest.raises(ValueError, match="max_runs_to_keep must be >= 1"):
            cleanup_old_runs(
                LogDirPath(str(log_dir)),
                max_runs_to_keep=-1,
                current_run_id=current_run,
            )

    def test_cleanup_ignores_invalid_directories(self, log_dir: Path) -> None:
        """Test that non-UUID directories are ignored."""
        # Create invalid directories
        (log_dir / "not-a-uuid").mkdir()
        (log_dir / "12345").mkdir()
        (log_dir / ".hidden").mkdir()

        # Create valid run directory
        old_run = RunId(str(uuid.uuid4()))
        (log_dir / old_run).mkdir()

        current_run = RunId(str(uuid.uuid4()))
        (log_dir / current_run).mkdir()

        with pytest.warns(UserWarning, match="Cleaned up"):
            result = cleanup_old_runs(
                LogDirPath(str(log_dir)),
                max_runs_to_keep=1,
                current_run_id=current_run,
            )

        # Should delete the one valid old run
        assert result == 1

        # Invalid directories should still exist
        assert (log_dir / "not-a-uuid").exists()
        assert (log_dir / "12345").exists()

    def test_cleanup_handles_permission_errors(self, log_dir: Path) -> None:
        """Test cleanup handles directories that can't be deleted."""
        old_run = RunId(str(uuid.uuid4()))
        old_run_dir = log_dir / old_run
        old_run_dir.mkdir()

        current_run = RunId(str(uuid.uuid4()))
        (log_dir / current_run).mkdir()

        # Make directory read-only (on Unix systems)
        import os
        import stat

        if os.name != "nt":  # Skip on Windows
            old_run_dir.chmod(stat.S_IRUSR | stat.S_IXUSR)

            try:
                with pytest.warns(UserWarning):
                    result = cleanup_old_runs(
                        LogDirPath(str(log_dir)),
                        max_runs_to_keep=1,
                        current_run_id=current_run,
                    )
                assert result in {0, 1}
            finally:
                # Restore permissions for cleanup
                if old_run_dir.exists():
                    old_run_dir.chmod(stat.S_IRWXU)

    def test_cleanup_exactly_at_limit(self, log_dir: Path) -> None:
        """Test when number of runs equals max_runs_to_keep."""
        # Create 2 old runs
        for _ in range(2):
            run_id = RunId(str(uuid.uuid4()))
            (log_dir / run_id).mkdir()

        current_run = RunId(str(uuid.uuid4()))
        (log_dir / current_run).mkdir()

        # Total 3 runs, keep 3
        result = cleanup_old_runs(
            LogDirPath(str(log_dir)),
            max_runs_to_keep=3,
            current_run_id=current_run,
        )

        assert result == 0
        assert len(list(log_dir.iterdir())) == 3

    def test_cleanup_with_files_in_directory(self, log_dir: Path) -> None:
        """Test cleanup works with files in run directories."""
        old_run = RunId(str(uuid.uuid4()))
        old_run_dir = log_dir / old_run
        old_run_dir.mkdir()
        (old_run_dir / "test.log").write_text("log data")

        current_run = RunId(str(uuid.uuid4()))
        (log_dir / current_run).mkdir()

        with pytest.warns(UserWarning, match="Cleaned up"):
            result = cleanup_old_runs(
                LogDirPath(str(log_dir)),
                max_runs_to_keep=1,
                current_run_id=current_run,
            )

        assert result == 1
        assert not old_run_dir.exists()


class TestListRuns:
    """Tests for list_runs function."""

    def test_list_empty_directory(self, log_dir: Path) -> None:
        """Test listing runs with empty directory."""
        result = list_runs(LogDirPath(str(log_dir)))
        assert result == []

    def test_list_nonexistent_directory(self) -> None:
        """Test listing runs with nonexistent directory."""
        result = list_runs(LogDirPath("/nonexistent/path"))
        assert result == []

    def test_list_single_run(self, log_dir: Path) -> None:
        """Test listing single run."""
        run_id = RunId(str(uuid.uuid4()))
        run_dir = log_dir / run_id
        run_dir.mkdir()
        (run_dir / "test.log").write_text("log")

        result = list_runs(LogDirPath(str(log_dir)))

        assert len(result) == 1
        assert result[0][0] == run_id
        assert result[0][2] == 1  # log count

    def test_list_multiple_runs(self, log_dir: Path) -> None:
        """Test listing multiple runs."""
        runs: list[RunId] = []
        for _ in range(3):
            run_id = RunId(str(uuid.uuid4()))
            run_dir = log_dir / run_id
            run_dir.mkdir()
            runs.append(run_id)

        result = list_runs(LogDirPath(str(log_dir)))

        assert len(result) == 3
        run_ids = [r[0] for r in result]
        assert set(run_ids) == set(runs)

    def test_list_runs_sorted_by_time(self, log_dir: Path) -> None:
        """Test that runs are sorted by modification time (newest first)."""
        import time

        run_ids: list[RunId] = []
        for _ in range(3):
            run_id = RunId(str(uuid.uuid4()))
            run_dir = log_dir / run_id
            run_dir.mkdir()
            run_ids.append(run_id)
            time.sleep(0.01)

        result = list_runs(LogDirPath(str(log_dir)))

        # Should be in reverse order (newest first)
        assert result[0][0] == run_ids[-1]
        assert result[-1][0] == run_ids[0]

    def test_list_runs_with_log_count(self, log_dir: Path) -> None:
        """Test that log count is correct."""
        run_id = RunId(str(uuid.uuid4()))
        run_dir = log_dir / run_id
        run_dir.mkdir()

        # Create multiple log files
        for i in range(5):
            (run_dir / f"test{i}.log").write_text(f"log {i}")

        result = list_runs(LogDirPath(str(log_dir)))

        assert len(result) == 1
        assert result[0][2] == 5  # log count

    def test_list_runs_ignores_invalid_directories(self, log_dir: Path) -> None:
        """Test that non-UUID directories are ignored."""
        # Create invalid directories
        (log_dir / "not-a-uuid").mkdir()
        (log_dir / "12345").mkdir()

        # Create valid run
        run_id = RunId(str(uuid.uuid4()))
        (log_dir / run_id).mkdir()

        result = list_runs(LogDirPath(str(log_dir)))

        assert len(result) == 1
        assert result[0][0] == run_id

    def test_list_runs_handles_stat_errors(self, log_dir: Path) -> None:
        """Test that runs with stat errors are skipped."""
        run_id = RunId(str(uuid.uuid4()))
        run_dir = log_dir / run_id
        run_dir.mkdir()

        result = list_runs(LogDirPath(str(log_dir)))
        assert len(result) == 1

    def test_list_runs_includes_timestamp(self, log_dir: Path) -> None:
        """Test that timestamp is included in results."""
        run_id = RunId(str(uuid.uuid4()))
        run_dir = log_dir / run_id
        run_dir.mkdir()

        result = list_runs(LogDirPath(str(log_dir)))

        assert len(result) == 1
        assert isinstance(result[0][1], float)  # timestamp
        assert result[0][1] > 0

    def test_list_runs_empty_run_directory(self, log_dir: Path) -> None:
        """Test listing run with no log files."""
        run_id = RunId(str(uuid.uuid4()))
        run_dir = log_dir / run_id
        run_dir.mkdir()

        result = list_runs(LogDirPath(str(log_dir)))

        assert len(result) == 1
        assert result[0][2] == 0  # log count

    def test_list_runs_with_subdirectories(self, log_dir: Path) -> None:
        """Test that subdirectories are not counted as logs."""
        run_id = RunId(str(uuid.uuid4()))
        run_dir = log_dir / run_id
        run_dir.mkdir()

        # Create files and subdirectories
        (run_dir / "test.log").write_text("log")
        (run_dir / "subdir").mkdir()

        result = list_runs(LogDirPath(str(log_dir)))

        assert len(result) == 1
        assert result[0][2] == 1  # Only files are counted
