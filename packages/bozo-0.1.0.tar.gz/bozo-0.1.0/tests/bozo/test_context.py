# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._context module.

Tests context management functions and thread safety.
"""

from __future__ import annotations

import threading
from typing import Generator

import pytest
import structlog

from bozo._context import clear_context, log_context, set_context


@pytest.fixture(autouse=True)
def clear_all_context() -> Generator[None, None, None]:
    """Clear all context before and after each test."""
    structlog.contextvars.clear_contextvars()
    yield
    structlog.contextvars.clear_contextvars()


class TestSetContext:
    """Tests for set_context function."""

    def test_set_single_value(self) -> None:
        """Test setting single context value."""
        set_context(user_id=123)

        # Get logger and check context
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_set_multiple_values(self) -> None:
        """Test setting multiple context values."""
        set_context(user_id=123, request_id="abc", service="api")

        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_set_overwrites_existing(self) -> None:
        """Test that setting same key overwrites existing value."""
        set_context(user_id=123)
        set_context(user_id=456)

        # Context should have the new value
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_set_accumulates_different_keys(self) -> None:
        """Test that different keys accumulate."""
        set_context(user_id=123)
        set_context(request_id="abc")

        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_set_with_string_value(self) -> None:
        """Test setting string value."""
        set_context(name="test")
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_set_with_int_value(self) -> None:
        """Test setting int value."""
        set_context(count=42)
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_set_with_float_value(self) -> None:
        """Test setting float value."""
        set_context(score=3.14)
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_set_with_bool_value(self) -> None:
        """Test setting bool value."""
        set_context(is_active=True)
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_set_with_none_value(self) -> None:
        """Test setting None value."""
        set_context(optional_value=None)
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_set_with_list_value(self) -> None:
        """Test setting list value."""
        set_context(items=[1, 2, 3])
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_set_with_dict_value(self) -> None:
        """Test setting dict value."""
        set_context(metadata={"key": "value"})
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_set_empty_kwargs(self) -> None:
        """Test setting with no arguments."""
        set_context()
        _ = structlog.get_logger()
        # Should not raise error


class TestClearContext:
    """Tests for clear_context function."""

    def test_clear_all_context(self) -> None:
        """Test clearing all context."""
        set_context(user_id=123, request_id="abc")
        clear_context()

        # Context should be empty
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_clear_specific_keys(self) -> None:
        """Test clearing specific context keys."""
        set_context(user_id=123, request_id="abc", service="api")
        clear_context("user_id", "request_id")

        # Only service should remain
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_clear_single_key(self) -> None:
        """Test clearing single context key."""
        set_context(user_id=123, request_id="abc")
        clear_context("user_id")

        # Only request_id should remain
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_clear_nonexistent_key(self) -> None:
        """Test clearing nonexistent key doesn't error."""
        set_context(user_id=123)
        clear_context("nonexistent")

        # Should not raise error
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_clear_empty_context(self) -> None:
        """Test clearing already empty context."""
        clear_context()

        # Should not raise error
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_clear_multiple_times(self) -> None:
        """Test clearing multiple times."""
        set_context(user_id=123)
        clear_context()
        clear_context()

        # Should not raise error
        log = structlog.get_logger()
        assert hasattr(log, "_context")


class TestLogContext:
    """Tests for log_context context manager."""

    def test_context_manager_adds_context(self) -> None:
        """Test that context manager adds context."""
        with log_context(user_id=123):
            log = structlog.get_logger()
            assert hasattr(log, "_context")

    def test_context_manager_removes_context(self) -> None:
        """Test that context is removed after exiting."""
        with log_context(user_id=123):
            pass

        # Context should be cleared
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_context_manager_multiple_values(self) -> None:
        """Test context manager with multiple values."""
        with log_context(user_id=123, request_id="abc"):
            log = structlog.get_logger()
            assert hasattr(log, "_context")

    def test_nested_context_managers(self) -> None:
        """Test nested context managers."""
        with log_context(user_id=123):
            with log_context(request_id="abc"):
                log = structlog.get_logger()
                assert hasattr(log, "_context")

    def test_context_manager_exception_cleanup(self) -> None:
        """Test that context is cleaned up even on exception."""
        try:
            with log_context(user_id=123):
                raise ValueError("test error")
        except ValueError:
            pass

        # Context should be cleared
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_context_manager_with_existing_context(self) -> None:
        """Test context manager with existing context."""
        set_context(service="api")

        with log_context(user_id=123):
            log = structlog.get_logger()
            assert hasattr(log, "_context")

        # Original context should remain
        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_context_manager_empty_kwargs(self) -> None:
        """Test context manager with no arguments."""
        with log_context():
            _ = structlog.get_logger()
            # Should not raise error


class TestThreadSafety:
    """Tests for thread safety of context management."""

    def test_context_is_thread_local(self) -> None:
        """Test that context is isolated between threads."""
        results: list[bool] = []

        def worker(value: int) -> None:
            set_context(thread_id=value)
            import time

            time.sleep(0.01)  # Simulate work
            log = structlog.get_logger()
            results.append(hasattr(log, "_context"))

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(5)]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(results) == 5
        assert all(results)

    def test_clear_context_is_thread_local(self) -> None:
        """Test that clearing context in one thread doesn't affect others."""
        results: list[bool] = []

        def worker(should_clear: bool) -> None:
            set_context(value=1)
            import time

            time.sleep(0.01)

            if should_clear:
                clear_context()

            log = structlog.get_logger()
            results.append(hasattr(log, "_context"))

        threads = [
            threading.Thread(target=worker, args=(i % 2 == 0,)) for i in range(4)
        ]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(results) == 4

    def test_log_context_is_thread_local(self) -> None:
        """Test that log_context is isolated between threads."""
        results: list[bool] = []

        def worker(value: int) -> None:
            with log_context(thread_id=value):
                import time

                time.sleep(0.01)
                log = structlog.get_logger()
                results.append(hasattr(log, "_context"))

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(5)]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(results) == 5


class TestAsyncSafety:
    """Tests for async safety of context management."""

    @pytest.mark.asyncio
    async def test_context_in_async_function(self) -> None:
        """Test using context in async function."""
        set_context(async_value=123)

        import asyncio

        await asyncio.sleep(0.01)

        log = structlog.get_logger()
        assert hasattr(log, "_context")

    @pytest.mark.asyncio
    async def test_log_context_in_async_function(self) -> None:
        """Test using log_context in async function."""
        with log_context(async_value=123):
            import asyncio

            await asyncio.sleep(0.01)
            log = structlog.get_logger()
            assert hasattr(log, "_context")

    @pytest.mark.asyncio
    async def test_clear_context_in_async_function(self) -> None:
        """Test clearing context in async function."""
        set_context(async_value=123)

        import asyncio

        await asyncio.sleep(0.01)
        clear_context()

        log = structlog.get_logger()
        assert hasattr(log, "_context")


class TestContextIntegration:
    """Integration tests for context management."""

    def test_context_persists_across_logger_calls(self) -> None:
        """Test that context persists across multiple logger calls."""
        set_context(persistent_value=123)

        log1 = structlog.get_logger("module1")
        log2 = structlog.get_logger("module2")

        # Both loggers should have access to the context
        assert hasattr(log1, "_context")
        assert hasattr(log2, "_context")

    def test_context_accumulation(self) -> None:
        """Test that context values accumulate."""
        set_context(value1=1)
        set_context(value2=2)
        set_context(value3=3)

        log = structlog.get_logger()
        assert hasattr(log, "_context")

    def test_context_override(self) -> None:
        """Test that later values override earlier ones."""
        set_context(value=1)
        set_context(value=2)
        set_context(value=3)

        log = structlog.get_logger()
        assert hasattr(log, "_context")
