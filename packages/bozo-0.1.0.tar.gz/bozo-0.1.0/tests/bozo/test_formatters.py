# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._formatters module.

Tests all formatter functions and processors.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import structlog

from bozo._formatters import (
    MinimalConsoleRenderer,
    build_formatters,
    configure_structlog,
    get_shared_processors,
)
from bozo._types import Environment

if TYPE_CHECKING:
    pass


class TestGetSharedProcessors:
    """Tests for get_shared_processors function."""

    def test_returns_list(self) -> None:
        """Test that get_shared_processors returns a list."""
        processors = get_shared_processors()
        assert isinstance(processors, list)

    def test_returns_processors(self) -> None:
        """Test that processors are returned."""
        processors = get_shared_processors()
        assert len(processors) > 0

    def test_includes_context_merger(self) -> None:
        """Test that contextvars merger is included."""
        processors = get_shared_processors()
        assert structlog.contextvars.merge_contextvars in processors

    def test_includes_logger_name(self) -> None:
        """Test that logger name adder is included."""
        processors = get_shared_processors()
        assert any(
            isinstance(p, type(structlog.stdlib.add_logger_name))
            or p == structlog.stdlib.add_logger_name
            for p in processors
        )

    def test_includes_log_level(self) -> None:
        """Test that log level processor is included."""
        processors = get_shared_processors()
        assert any(
            p == structlog.processors.add_log_level
            or getattr(p, "__name__", "") == "add_log_level"
            or "log_level"
            in str(type(p)).lower()  # pyright: ignore[reportUnknownArgumentType]
            for p in processors
        )

    def test_includes_timestamper(self) -> None:
        """Test that timestamper is included."""
        processors = get_shared_processors()
        assert any(isinstance(p, structlog.processors.TimeStamper) for p in processors)

    def test_includes_exception_formatter(self) -> None:
        """Test that exception formatter is included."""
        processors = get_shared_processors()
        # Check for format_exc_info
        assert structlog.processors.format_exc_info in processors


class TestMinimalConsoleRenderer:
    """Tests for MinimalConsoleRenderer class."""

    def test_init_with_colors(self) -> None:
        """Test initialization with colors enabled."""
        renderer = MinimalConsoleRenderer(colors=True)
        assert renderer._colors is True  # pyright: ignore[reportPrivateUsage]

    def test_init_without_colors(self) -> None:
        """Test initialization with colors disabled."""
        renderer = MinimalConsoleRenderer(colors=False)
        assert renderer._colors is False  # pyright: ignore[reportPrivateUsage]

    def test_call_returns_string(self) -> None:
        """Test that calling renderer returns a string."""
        renderer = MinimalConsoleRenderer(colors=False)
        event_dict = {
            "timestamp": "2026-01-01T00:00:00",
            "level": "info",
            "logger": "test",
            "event": "test message",
        }

        result = renderer(None, "", event_dict)
        assert isinstance(result, str)

    def test_formats_timestamp(self) -> None:
        """Test that timestamp is included in output."""
        renderer = MinimalConsoleRenderer(colors=False)
        event_dict = {
            "timestamp": "2026-01-01T00:00:00",
            "level": "info",
            "logger": "test",
            "event": "test message",
        }

        result = renderer(None, "", event_dict)
        assert "2026-01-01T00:00:00" in result

    def test_formats_level(self) -> None:
        """Test that log level is included in output."""
        renderer = MinimalConsoleRenderer(colors=False)
        event_dict = {
            "timestamp": "2026-01-01T00:00:00",
            "level": "info",
            "logger": "test",
            "event": "test message",
        }

        result = renderer(None, "", event_dict)
        assert "info" in result.lower()

    def test_formats_logger_name(self) -> None:
        """Test that logger name is included in output."""
        renderer = MinimalConsoleRenderer(colors=False)
        event_dict = {
            "timestamp": "2026-01-01T00:00:00",
            "level": "info",
            "logger": "test.module",
            "event": "test message",
        }

        result = renderer(None, "", event_dict)
        assert "test.module" in result

    def test_formats_event(self) -> None:
        """Test that event message is included in output."""
        renderer = MinimalConsoleRenderer(colors=False)
        event_dict = {
            "timestamp": "2026-01-01T00:00:00",
            "level": "info",
            "logger": "test",
            "event": "test message",
        }

        result = renderer(None, "", event_dict)
        assert "test message" in result

    def test_colors_enabled(self) -> None:
        """Test that colors are added when enabled."""
        renderer = MinimalConsoleRenderer(colors=True)
        event_dict = {
            "timestamp": "2026-01-01T00:00:00",
            "level": "info",
            "logger": "test",
            "event": "test message",
        }

        result = renderer(None, "", event_dict)
        # Check for ANSI escape codes
        assert "\x1b[" in result

    def test_colors_disabled(self) -> None:
        """Test that colors are not added when disabled."""
        renderer = MinimalConsoleRenderer(colors=False)
        event_dict = {
            "timestamp": "2026-01-01T00:00:00",
            "level": "info",
            "logger": "test",
            "event": "test message",
        }

        result = renderer(None, "", event_dict)
        # Check for no ANSI escape codes
        assert "\x1b[" not in result

    def test_different_log_levels(self) -> None:
        """Test rendering different log levels."""
        renderer = MinimalConsoleRenderer(colors=True)
        levels = ["debug", "info", "warning", "error", "critical"]

        for level in levels:
            event_dict = {
                "timestamp": "2026-01-01T00:00:00",
                "level": level,
                "logger": "test",
                "event": "test message",
            }
            result = renderer(None, "", event_dict)
            assert level in result.lower()

    def test_missing_fields(self) -> None:
        """Test rendering with missing fields."""
        renderer = MinimalConsoleRenderer(colors=False)
        event_dict = {"event": "test message"}

        result = renderer(None, "", event_dict)
        assert "test message" in result

    def test_empty_event_dict(self) -> None:
        """Test rendering with empty event dict."""
        renderer = MinimalConsoleRenderer(colors=False)
        event_dict: dict[str, object] = {}

        result = renderer(None, "", event_dict)
        assert isinstance(result, str)


class TestConfigureStructlog:
    """Tests for configure_structlog function."""

    def test_configures_structlog(self) -> None:
        """Test that structlog is configured."""
        processors = get_shared_processors()
        configure_structlog(processors)

        # Verify structlog is configured
        logger = structlog.get_logger()
        assert logger is not None

    def test_with_empty_processors(self) -> None:
        """Test configuration with empty processor list."""
        configure_structlog([])

        logger = structlog.get_logger()
        assert logger is not None

    def test_logger_factory(self) -> None:
        """Test that logger factory is set."""
        processors = get_shared_processors()
        configure_structlog(processors)

        logger = structlog.get_logger("test")
        assert logger is not None


class TestBuildFormatters:
    """Tests for build_formatters function."""

    def test_returns_three_formatters(self) -> None:
        """Test that three formatters are returned."""
        processors = get_shared_processors()
        console_fmt, text_fmt, json_fmt = build_formatters(
            processors, Environment.DEVELOPMENT
        )

        assert isinstance(console_fmt, logging.Formatter)
        assert isinstance(text_fmt, logging.Formatter)
        assert isinstance(json_fmt, logging.Formatter)

    def test_development_environment(self) -> None:
        """Test formatters for development environment."""
        processors = get_shared_processors()
        console_fmt, text_fmt, json_fmt = build_formatters(
            processors, Environment.DEVELOPMENT
        )

        assert console_fmt is not None
        assert text_fmt is not None
        assert json_fmt is not None

    def test_production_environment(self) -> None:
        """Test formatters for production environment."""
        processors = get_shared_processors()
        console_fmt, text_fmt, json_fmt = build_formatters(
            processors, Environment.PRODUCTION
        )

        assert console_fmt is not None
        assert text_fmt is not None
        assert json_fmt is not None

    def test_console_formatter_type(self) -> None:
        """Test that console formatter is ProcessorFormatter."""
        processors = get_shared_processors()
        console_fmt, _, _ = build_formatters(processors, Environment.DEVELOPMENT)

        assert isinstance(console_fmt, structlog.stdlib.ProcessorFormatter)

    def test_text_formatter_type(self) -> None:
        """Test that text formatter is ProcessorFormatter."""
        processors = get_shared_processors()
        _, text_fmt, _ = build_formatters(processors, Environment.DEVELOPMENT)

        assert isinstance(text_fmt, structlog.stdlib.ProcessorFormatter)

    def test_json_formatter_type(self) -> None:
        """Test that JSON formatter is ProcessorFormatter."""
        processors = get_shared_processors()
        _, _, json_fmt = build_formatters(processors, Environment.DEVELOPMENT)

        assert isinstance(json_fmt, structlog.stdlib.ProcessorFormatter)

    def test_with_empty_processors(self) -> None:
        """Test building formatters with empty processor list."""
        console_fmt, text_fmt, json_fmt = build_formatters([], Environment.DEVELOPMENT)

        assert console_fmt is not None
        assert text_fmt is not None
        assert json_fmt is not None


class TestFormatterIntegration:
    """Integration tests for formatters."""

    def test_format_log_record(self) -> None:
        """Test formatting a log record."""
        processors = get_shared_processors()
        console_fmt, _, _ = build_formatters(processors, Environment.DEVELOPMENT)

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="test message",
            args=(),
            exc_info=None,
        )

        result = console_fmt.format(record)
        assert isinstance(result, str)

    def test_format_with_exception(self) -> None:
        """Test formatting a log record with exception."""
        processors = get_shared_processors()
        _, text_fmt, _ = build_formatters(processors, Environment.DEVELOPMENT)

        try:
            raise ValueError("test error")
        except ValueError:
            import sys

            exc_info = sys.exc_info()

        record = logging.LogRecord(
            name="test",
            level=logging.ERROR,
            pathname="test.py",
            lineno=1,
            msg="error occurred",
            args=(),
            exc_info=exc_info,
        )

        result = text_fmt.format(record)
        assert isinstance(result, str)
        assert len(result) > 0
