# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._handlers module.

Tests all handler classes and builder functions.
"""

from __future__ import annotations

import logging
import logging.handlers
import time
from pathlib import Path
from typing import TYPE_CHECKING
from unittest.mock import Mock, patch

import pytest
import requests

from bozo._handlers import (
    AsyncHTTPHandler,
    JSONRotatingFileHandler,
    WebViewerHandler,
    build_console_handler,
    build_error_file_handler,
    build_http_handler,
    build_json_file_handler,
    build_text_file_handler,
    build_viewer_handler,
)
from bozo._types import (
    BatchSize,
    Environment,
    FlushInterval,
    HttpEndpoint,
    LogFilePath,
    LogLevel,
    QueueSize,
    RunId,
    MaxBytes,
    BackupCount,
)

if TYPE_CHECKING:
    from pytest import TempPathFactory
else:
    TempPathFactory = object


@pytest.fixture
def temp_log_file(tmp_path_factory: TempPathFactory) -> Path:
    """Create a temporary log file path."""
    return tmp_path_factory.mktemp("logs") / "test.log"


class TestJSONRotatingFileHandler:
    """Tests for JSONRotatingFileHandler class."""

    def test_has_is_json_attribute(self, temp_log_file: Path) -> None:
        """Test that handler has is_json attribute."""
        handler = JSONRotatingFileHandler(
            filename=LogFilePath(str(temp_log_file)),
            max_bytes=MaxBytes(1024),
            backup_count=BackupCount(3),
        )
        assert hasattr(handler, "is_json")
        assert handler.is_json is True
        handler.close()

    def test_inherits_from_rotating_handler(self, temp_log_file: Path) -> None:
        """Test that handler inherits from RotatingFileHandler."""
        handler = JSONRotatingFileHandler(
            filename=LogFilePath(str(temp_log_file)),
            max_bytes=MaxBytes(1024),
            backup_count=BackupCount(3),
        )
        assert isinstance(handler, logging.handlers.RotatingFileHandler)
        handler.close()

    def test_creates_file(self, temp_log_file: Path) -> None:
        """Test that handler creates the log file."""
        handler = JSONRotatingFileHandler(
            filename=LogFilePath(str(temp_log_file)),
            max_bytes=MaxBytes(1024),
            backup_count=BackupCount(3),
        )

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="test message",
            args=(),
            exc_info=None,
        )
        handler.emit(record)
        handler.close()

        assert temp_log_file.exists()

    def test_rotation(self, temp_log_file: Path) -> None:
        """Test that handler rotates files."""
        handler = JSONRotatingFileHandler(
            filename=LogFilePath(str(temp_log_file)),
            max_bytes=MaxBytes(100),  # Small size to trigger rotation
            backup_count=BackupCount(2),
        )

        # Write enough logs to trigger rotation
        for i in range(20):
            record = logging.LogRecord(
                name="test",
                level=logging.INFO,
                pathname="test.py",
                lineno=1,
                msg=f"test message {i}" * 10,
                args=(),
                exc_info=None,
            )
            handler.emit(record)

        handler.close()

        # Check that backup files were created
        parent_dir = temp_log_file.parent
        backup_files = list(parent_dir.glob(f"{temp_log_file.name}.*"))
        assert len(backup_files) > 0


class TestAsyncHTTPHandler:
    """Tests for AsyncHTTPHandler class."""

    def test_has_is_http_attribute(self) -> None:
        """Test that handler has is_http attribute."""
        handler = AsyncHTTPHandler(
            endpoint_url=HttpEndpoint("http://localhost:8000/logs"),
            batch_size=BatchSize(10),
            flush_interval=FlushInterval(1.0),
        )
        assert hasattr(handler, "is_http")
        assert handler.is_http is True
        handler.close()

    def test_starts_worker_thread(self) -> None:
        """Test that handler starts worker thread."""
        handler = AsyncHTTPHandler(
            endpoint_url=HttpEndpoint("http://localhost:8000/logs"),
            batch_size=BatchSize(10),
            flush_interval=FlushInterval(1.0),
        )

        assert handler._worker_thread is not None  # pyright: ignore[reportPrivateUsage]
        assert handler._worker_thread.is_alive()  # pyright: ignore[reportPrivateUsage]
        handler.close()

    def test_emit_adds_to_queue(self) -> None:
        """Test that emit adds log to queue."""
        handler = AsyncHTTPHandler(
            endpoint_url=HttpEndpoint("http://localhost:8000/logs"),
            batch_size=BatchSize(10),
            flush_interval=FlushInterval(1.0),
        )

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="test message",
            args=(),
            exc_info=None,
        )

        handler.setFormatter(logging.Formatter("%(message)s"))
        handler.emit(record)

        # Give time for queue to process
        time.sleep(0.1)

        assert (
            handler._log_queue.qsize() >= 0  # pyright: ignore[reportPrivateUsage]
        )  # Should have processed or be processing
        handler.close()

    def test_queue_full_handling(self) -> None:
        """Test handling when queue is full."""
        handler = AsyncHTTPHandler(
            endpoint_url=HttpEndpoint("http://localhost:8000/logs"),
            batch_size=BatchSize(10),
            flush_interval=FlushInterval(1.0),
        )

        # Fill queue
        handler.setFormatter(logging.Formatter("%(message)s"))
        for i in range(1100):  # More than queue size
            record = logging.LogRecord(
                name="test",
                level=logging.INFO,
                pathname="test.py",
                lineno=1,
                msg=f"message {i}",
                args=(),
                exc_info=None,
            )
            handler.emit(record)

        # Should not raise exception
        handler.close()

    @patch("requests.post")
    def test_send_batch_success(self, mock_post: Mock) -> None:
        """Test successful batch sending."""
        mock_post.return_value.status_code = 200

        handler = AsyncHTTPHandler(
            endpoint_url=HttpEndpoint("http://localhost:8000/logs"),
            batch_size=BatchSize(2),
            flush_interval=FlushInterval(0.1),
        )

        handler.setFormatter(logging.Formatter("%(message)s"))

        # Send enough logs to trigger batch
        for i in range(3):
            record = logging.LogRecord(
                name="test",
                level=logging.INFO,
                pathname="test.py",
                lineno=1,
                msg=f"message {i}",
                args=(),
                exc_info=None,
            )
            handler.emit(record)

        time.sleep(0.3)  # Wait for batch to be sent

        handler.close()

        # Should have called post
        assert mock_post.called

    @patch("requests.post")
    def test_send_batch_failure(self, mock_post: Mock) -> None:
        """Test handling of failed batch sending."""
        mock_post.return_value.status_code = 500

        handler = AsyncHTTPHandler(
            endpoint_url=HttpEndpoint("http://localhost:8000/logs"),
            batch_size=BatchSize(2),
            flush_interval=FlushInterval(0.1),
        )

        handler.setFormatter(logging.Formatter("%(message)s"))

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="message",
            args=(),
            exc_info=None,
        )
        handler.emit(record)

        time.sleep(0.3)

        # Should not raise exception
        handler.close()

    @patch("requests.post")
    def test_send_batch_exception(self, mock_post: Mock) -> None:
        """Test handling of exception during batch sending."""
        mock_post.side_effect = requests.exceptions.RequestException("Connection error")

        handler = AsyncHTTPHandler(
            endpoint_url=HttpEndpoint("http://localhost:8000/logs"),
            batch_size=BatchSize(2),
            flush_interval=FlushInterval(0.1),
        )

        handler.setFormatter(logging.Formatter("%(message)s"))

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="message",
            args=(),
            exc_info=None,
        )
        handler.emit(record)

        time.sleep(0.3)

        # Should not raise exception
        handler.close()

    def test_close_stops_thread(self) -> None:
        """Test that close stops worker thread."""
        handler = AsyncHTTPHandler(
            endpoint_url=HttpEndpoint("http://localhost:8000/logs"),
            batch_size=BatchSize(10),
            flush_interval=FlushInterval(1.0),
        )

        assert handler._worker_thread.is_alive()  # pyright: ignore[reportPrivateUsage]

        handler.close()

        # Wait for thread to stop
        time.sleep(0.2)

        assert (
            not handler._worker_thread.is_alive()  # pyright: ignore[reportPrivateUsage]
        )


class TestWebViewerHandler:
    """Tests for WebViewerHandler class."""

    def test_has_is_viewer_attribute(self) -> None:
        """Test that handler has is_viewer attribute."""
        handler = WebViewerHandler(
            run_id=RunId("12345678-1234-1234-1234-123456789012"),
            queue_size=QueueSize(100),
        )
        assert hasattr(handler, "is_viewer")
        assert handler.is_viewer is True

    def test_lazy_queue_initialization(self) -> None:
        """Test that queue is initialized lazily."""
        handler = WebViewerHandler(
            run_id=RunId("12345678-1234-1234-1234-123456789012"),
            queue_size=QueueSize(100),
        )

        assert handler._queue is None  # pyright: ignore[reportPrivateUsage]

    def test_emit_initializes_queue(self) -> None:
        """Test that emit initializes queue."""
        handler = WebViewerHandler(
            run_id=RunId("12345678-1234-1234-1234-123456789012"),
            queue_size=QueueSize(100),
        )

        handler.setFormatter(logging.Formatter("%(message)s"))

        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="test message",
            args=(),
            exc_info=None,
        )

        handler.emit(record)

        assert handler._queue is not None  # pyright: ignore[reportPrivateUsage]


class TestBuildConsoleHandler:
    """Tests for build_console_handler function."""

    def test_development_environment(self) -> None:
        """Test building console handler for development."""
        handler = build_console_handler(Environment.DEVELOPMENT, LogLevel.INFO)

        assert isinstance(handler, logging.StreamHandler)
        assert handler.level == logging.INFO

    def test_production_environment(self) -> None:
        """Test building console handler for production."""
        handler = build_console_handler(Environment.PRODUCTION, LogLevel.WARNING)

        assert isinstance(handler, logging.StreamHandler)
        assert handler.level == logging.WARNING

    def test_different_log_levels(self) -> None:
        """Test building handlers with different log levels."""
        levels = [
            (LogLevel.DEBUG, logging.DEBUG),
            (LogLevel.INFO, logging.INFO),
            (LogLevel.WARNING, logging.WARNING),
            (LogLevel.ERROR, logging.ERROR),
            (LogLevel.CRITICAL, logging.CRITICAL),
        ]

        for level, expected in levels:
            handler = build_console_handler(Environment.DEVELOPMENT, level)
            assert handler.level == expected

    def test_has_formatter(self) -> None:
        """Test that handler has formatter set."""
        handler = build_console_handler(Environment.DEVELOPMENT, LogLevel.INFO)

        assert handler.formatter is not None


class TestBuildTextFileHandler:
    """Tests for build_text_file_handler function."""

    def test_creates_handler(self, temp_log_file: Path) -> None:
        """Test creating text file handler."""
        handler = build_text_file_handler(
            LogFilePath(str(temp_log_file)),
            max_bytes=MaxBytes(1024),
            backup_count=BackupCount(3),
            level=LogLevel.DEBUG,
        )

        assert isinstance(handler, logging.handlers.RotatingFileHandler)
        assert handler.level == logging.DEBUG
        handler.close()

    def test_different_parameters(self, temp_log_file: Path) -> None:
        """Test creating handler with different parameters."""
        handler = build_text_file_handler(
            LogFilePath(str(temp_log_file)),
            max_bytes=MaxBytes(2048),
            backup_count=BackupCount(5),
            level=LogLevel.WARNING,
        )

        assert handler.maxBytes == 2048
        assert handler.backupCount == 5
        assert handler.level == logging.WARNING
        handler.close()


class TestBuildErrorFileHandler:
    """Tests for build_error_file_handler function."""

    def test_creates_handler(self, temp_log_file: Path) -> None:
        """Test creating error file handler."""
        handler = build_error_file_handler(
            LogFilePath(str(temp_log_file)),
            max_bytes=MaxBytes(1024),
            backup_count=BackupCount(3),
        )

        assert isinstance(handler, logging.handlers.RotatingFileHandler)
        assert handler.level == logging.ERROR
        handler.close()

    def test_always_error_level(self, temp_log_file: Path) -> None:
        """Test that handler is always at ERROR level."""
        handler = build_error_file_handler(
            LogFilePath(str(temp_log_file)),
            max_bytes=MaxBytes(1024),
            backup_count=BackupCount(3),
        )

        assert handler.level == logging.ERROR
        handler.close()


class TestBuildJSONFileHandler:
    """Tests for build_json_file_handler function."""

    def test_creates_handler(self, temp_log_file: Path) -> None:
        """Test creating JSON file handler."""
        handler = build_json_file_handler(
            LogFilePath(str(temp_log_file)),
            max_bytes=MaxBytes(1024),
            backup_count=BackupCount(3),
            level=LogLevel.DEBUG,
        )

        assert isinstance(handler, JSONRotatingFileHandler)
        assert handler.level == logging.DEBUG
        handler.close()

    def test_has_is_json(self, temp_log_file: Path) -> None:
        """Test that handler has is_json attribute."""
        handler = build_json_file_handler(
            LogFilePath(str(temp_log_file)),
            max_bytes=MaxBytes(1024),
            backup_count=BackupCount(3),
            level=LogLevel.INFO,
        )

        assert hasattr(handler, "is_json")
        assert handler.is_json is True
        handler.close()


class TestBuildHTTPHandler:
    """Tests for build_http_handler function."""

    def test_creates_handler(self) -> None:
        """Test creating HTTP handler."""
        handler = build_http_handler(
            HttpEndpoint("http://localhost:8000/logs"),
            batch_size=BatchSize(50),
            flush_interval=FlushInterval(2.0),
            level=LogLevel.INFO,
        )

        assert isinstance(handler, AsyncHTTPHandler)
        assert handler.level == logging.INFO
        handler.close()

    def test_has_is_http(self) -> None:
        """Test that handler has is_http attribute."""
        handler = build_http_handler(
            HttpEndpoint("http://localhost:8000/logs"),
            batch_size=BatchSize(50),
            flush_interval=FlushInterval(2.0),
            level=LogLevel.INFO,
        )

        assert hasattr(handler, "is_http")
        assert handler.is_http is True
        handler.close()


class TestBuildViewerHandler:
    """Tests for build_viewer_handler function."""

    def test_creates_handler(self) -> None:
        """Test creating viewer handler."""
        handler = build_viewer_handler(
            RunId("12345678-1234-1234-1234-123456789012"),
            queue_size=QueueSize(1000),
            level=LogLevel.DEBUG,
        )

        assert isinstance(handler, WebViewerHandler)
        assert handler.level == logging.DEBUG

    def test_has_is_viewer(self) -> None:
        """Test that handler has is_viewer attribute."""
        handler = build_viewer_handler(
            RunId("12345678-1234-1234-1234-123456789012"),
            queue_size=QueueSize(1000),
            level=LogLevel.DEBUG,
        )

        assert hasattr(handler, "is_viewer")
        assert handler.is_viewer is True
