# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo main module (__init__.py and _main.py).

Tests all public API functions.
"""

from __future__ import annotations

from pathlib import Path
from typing import Generator

import structlog

import pytest

from bozo import (
    clear_context,
    get,
    log_context,
    redact,
    set_context,
    setup,
)
from bozo._state import reset_state
from bozo._types import AppName, Environment, LogLevel, REDACTED_PLACEHOLDER


@pytest.fixture(autouse=True)
def reset_logging() -> Generator[None, None, None]:
    """Reset logging state before and after each test."""
    reset_state()
    yield
    reset_state()


class TestSetup:
    """Tests for setup function."""

    def test_basic_setup(self, tmp_path: Path) -> None:
        """Test basic setup with minimal parameters."""
        setup("testapp", log_dir=str(tmp_path))

        from bozo._state import is_configured

        assert is_configured()

    def test_setup_with_app_name_type(self, tmp_path: Path) -> None:
        """Test setup with AppName type."""
        setup(AppName("testapp"), log_dir=str(tmp_path))

        from bozo._state import is_configured

        assert is_configured()

    def test_setup_development_environment(self, tmp_path: Path) -> None:
        """Test setup with development environment."""
        setup(
            "testapp",
            environment=Environment.DEVELOPMENT,
            log_dir=str(tmp_path),
        )

        from bozo._state import get_config

        config = get_config()
        assert config is not None
        assert config.environment == Environment.DEVELOPMENT

    def test_setup_production_environment(self, tmp_path: Path) -> None:
        """Test setup with production environment."""
        setup(
            "testapp",
            environment=Environment.PRODUCTION,
            log_dir=str(tmp_path),
        )

        from bozo._state import get_config

        config = get_config()
        assert config is not None
        assert config.environment == Environment.PRODUCTION

    def test_setup_disable_console(self, tmp_path: Path) -> None:
        """Test setup with console disabled."""
        setup("testapp", enable_console=False, log_dir=str(tmp_path))

        from bozo._state import get_config

        config = get_config()
        assert config is not None
        assert config.enable_console is False

    def test_setup_disable_file(self, tmp_path: Path) -> None:
        """Test setup with file logging disabled."""
        setup(
            "testapp",
            enable_file=False,
            enable_error_file=False,
            log_dir=str(tmp_path),
        )

        from bozo._state import get_config

        config = get_config()
        assert config is not None
        assert config.enable_file is False

    def test_setup_custom_log_levels(self, tmp_path: Path) -> None:
        """Test setup with custom log levels."""
        setup(
            "testapp",
            console_level=LogLevel.WARNING,
            file_level=LogLevel.DEBUG,
            log_dir=str(tmp_path),
        )

        from bozo._state import get_config

        config = get_config()
        assert config is not None
        assert config.console_level == LogLevel.WARNING
        assert config.file_level == LogLevel.DEBUG

    def test_setup_with_viewer(self, tmp_path: Path) -> None:
        """Test setup with viewer enabled."""
        setup("testapp", enable_viewer=True, log_dir=str(tmp_path))

        from bozo._state import get_config

        config = get_config()
        assert config is not None
        assert config.enable_viewer is True

    def test_setup_creates_log_files(self, tmp_path: Path) -> None:
        """Test that setup creates log directory."""
        setup("testapp", log_dir=str(tmp_path))

        from bozo._state import get_config

        config = get_config()
        assert config is not None

        # Log directory should exist
        log_dir = Path(config.run_log_dir)
        assert log_dir.exists()

    def test_setup_configures_structlog(self, tmp_path: Path) -> None:
        """Test that setup configures structlog."""
        setup("testapp", log_dir=str(tmp_path))

        # Should be able to get logger
        logger = structlog.get_logger()
        assert logger is not None

    def test_setup_multiple_times(self, tmp_path: Path) -> None:
        """Test that setup can be called multiple times."""
        setup("testapp1", log_dir=str(tmp_path / "1"))
        setup("testapp2", log_dir=str(tmp_path / "2"))

        from bozo._state import get_config

        config = get_config()
        assert config is not None
        assert config.app_name == AppName("testapp2")


class TestGet:
    """Tests for get function."""

    def test_get_returns_logger(self, tmp_path: Path) -> None:
        """Test that get returns a logger."""
        setup("testapp", log_dir=str(tmp_path))

        logger = get(__name__)
        assert logger is not None

    def test_get_with_module_name(self, tmp_path: Path) -> None:
        """Test get with module name."""
        setup("testapp", log_dir=str(tmp_path))

        logger = get("test.module")
        assert logger is not None

    def test_get_different_loggers(self, tmp_path: Path) -> None:
        """Test getting different loggers."""
        setup("testapp", log_dir=str(tmp_path))

        logger1 = get("module1")
        logger2 = get("module2")

        assert logger1 is not logger2

    def test_logger_has_methods(self, tmp_path: Path) -> None:
        """Test that logger has expected methods."""
        setup("testapp", log_dir=str(tmp_path))

        logger = get(__name__)

        assert hasattr(logger, "debug")
        assert hasattr(logger, "info")
        assert hasattr(logger, "warning")
        assert hasattr(logger, "error")
        assert hasattr(logger, "critical")


class TestRedact:
    """Tests for redact function."""

    def test_redact_returns_placeholder(self) -> None:
        """Test that redact returns placeholder."""
        result = redact("password123")
        assert result == REDACTED_PLACEHOLDER

    def test_redact_with_different_values(self) -> None:
        """Test redact with different value types."""
        assert redact("secret") == REDACTED_PLACEHOLDER
        assert redact(12345) == REDACTED_PLACEHOLDER
        assert redact({"key": "value"}) == REDACTED_PLACEHOLDER

    def test_redact_ignores_input(self) -> None:
        """Test that redact ignores the input value."""
        assert redact("password") == redact("different")


class TestSetContext:
    """Tests for set_context function."""

    def test_set_context_basic(self, tmp_path: Path) -> None:
        """Test basic set_context."""
        setup("testapp", log_dir=str(tmp_path))

        set_context(user_id=123)

        # Context should be set
        logger = get(__name__)
        assert logger is not None

    def test_set_context_multiple_values(self, tmp_path: Path) -> None:
        """Test set_context with multiple values."""
        setup("testapp", log_dir=str(tmp_path))

        set_context(user_id=123, request_id="abc", service="api")

        logger = get(__name__)
        assert logger is not None

    def test_set_context_various_types(self, tmp_path: Path) -> None:
        """Test set_context with various value types."""
        setup("testapp", log_dir=str(tmp_path))

        set_context(
            string_val="test",
            int_val=42,
            float_val=3.14,
            bool_val=True,
            none_val=None,
            list_val=[1, 2, 3],
            dict_val={"key": "value"},
        )

        logger = get(__name__)
        assert logger is not None


class TestClearContext:
    """Tests for clear_context function."""

    def test_clear_all(self, tmp_path: Path) -> None:
        """Test clearing all context."""
        setup("testapp", log_dir=str(tmp_path))

        set_context(user_id=123, request_id="abc")
        clear_context()

        logger = get(__name__)
        assert logger is not None

    def test_clear_specific_keys(self, tmp_path: Path) -> None:
        """Test clearing specific context keys."""
        setup("testapp", log_dir=str(tmp_path))

        set_context(user_id=123, request_id="abc", service="api")
        clear_context("user_id", "request_id")

        logger = get(__name__)
        assert logger is not None


class TestLogContext:
    """Tests for log_context context manager."""

    def test_log_context_basic(self, tmp_path: Path) -> None:
        """Test basic log_context usage."""
        setup("testapp", log_dir=str(tmp_path))

        with log_context(user_id=123):
            logger = get(__name__)
            assert logger is not None

    def test_log_context_cleanup(self, tmp_path: Path) -> None:
        """Test that log_context cleans up."""
        setup("testapp", log_dir=str(tmp_path))

        with log_context(user_id=123):
            pass

        logger = get(__name__)
        assert logger is not None

    def test_log_context_nested(self, tmp_path: Path) -> None:
        """Test nested log_context."""
        setup("testapp", log_dir=str(tmp_path))

        with log_context(user_id=123):
            with log_context(request_id="abc"):
                logger = get(__name__)
                assert logger is not None

    def test_log_context_exception_handling(self, tmp_path: Path) -> None:
        """Test that log_context cleans up on exception."""
        setup("testapp", log_dir=str(tmp_path))

        try:
            with log_context(user_id=123):
                raise ValueError("test")
        except ValueError:
            pass

        logger = get(__name__)
        assert logger is not None


class TestIntegration:
    """Integration tests for main API."""

    def test_full_logging_workflow(self, tmp_path: Path) -> None:
        """Test complete logging workflow."""
        # Setup
        setup("testapp", log_dir=str(tmp_path))

        # Get logger
        logger = get(__name__)

        # Set context
        set_context(service="api")

        # Log with context
        with log_context(request_id="req-123"):
            logger.info("processing request", user_id=456)

        # Log sensitive data
        logger.info("login attempt", password=redact("secret"))

        # Clear context
        clear_context()

        # Continue logging
        logger.debug("final log")

    def test_multiple_loggers(self, tmp_path: Path) -> None:
        """Test using multiple loggers."""
        setup("testapp", log_dir=str(tmp_path))

        log1 = get("module1")
        log2 = get("module2")

        set_context(global_value="test")

        log1.info("from module 1")
        log2.info("from module 2")

    def test_environment_switching(self, tmp_path: Path) -> None:
        """Test switching environments."""
        # Development
        setup(
            "testapp",
            environment=Environment.DEVELOPMENT,
            log_dir=str(tmp_path / "dev"),
        )

        log = get(__name__)
        log.info("dev log")

        reset_state()

        # Production
        setup(
            "testapp",
            environment=Environment.PRODUCTION,
            log_dir=str(tmp_path / "prod"),
        )

        log = get(__name__)
        log.info("prod log")
