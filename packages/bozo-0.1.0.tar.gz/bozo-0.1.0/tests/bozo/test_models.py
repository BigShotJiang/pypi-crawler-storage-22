# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._models module.

Tests LoggingConfig model and validators.
"""

from __future__ import annotations

import uuid
from pathlib import Path

import pytest
from pydantic import ValidationError

from bozo._models import LoggingConfig
from bozo._types import (
    AppName,
    BackupCount,
    Environment,
    LogDirPath,
    LogLevel,
    QueueSize,
    RunId,
)


class TestLoggingConfigInit:
    """Tests for LoggingConfig initialization."""

    def test_minimal_init(self) -> None:
        """Test initialization with minimal required parameters."""
        config = LoggingConfig(app_name=AppName("testapp"))

        assert config.app_name == AppName("testapp")
        assert config.environment == Environment.DEVELOPMENT
        assert isinstance(config.run_id, str)

    def test_init_with_all_parameters(self, tmp_path: Path) -> None:
        """Test initialization with all parameters."""
        run_id = RunId(str(uuid.uuid4()))
        config = LoggingConfig(
            app_name=AppName("testapp"),
            run_id=run_id,
            environment=Environment.PRODUCTION,
            log_dir=LogDirPath(str(tmp_path)),
            enable_console=True,
            console_level=LogLevel.INFO,
            enable_file=True,
            file_level=LogLevel.DEBUG,
            enable_json=True,
            json_level=LogLevel.DEBUG,
            enable_viewer=True,
            viewer_queue_size=QueueSize(1000),
        )

        assert config.app_name == AppName("testapp")
        assert config.run_id == run_id
        assert config.environment == Environment.PRODUCTION
        assert config.enable_console is True

    def test_auto_generated_run_id(self) -> None:
        """Test that run_id is auto-generated if not provided."""
        config = LoggingConfig(app_name=AppName("testapp"))

        assert config.run_id is not None
        # Should be valid UUID
        uuid.UUID(config.run_id)


class TestValidators:
    """Tests for LoggingConfig validators."""

    def test_validate_app_name_empty(self) -> None:
        """Test that empty app_name raises error."""
        with pytest.raises(ValidationError):
            LoggingConfig(app_name=AppName(""))

    def test_validate_app_name_whitespace(self) -> None:
        """Test that whitespace-only app_name raises error."""
        with pytest.raises(ValidationError):
            LoggingConfig(app_name=AppName("   "))

    def test_validate_max_bytes_positive(self) -> None:
        """Test that max_bytes must be positive."""
        with pytest.raises(ValidationError):
            LoggingConfig(
                app_name=AppName("testapp"),
                text_file_max_bytes=0,  # type: ignore[arg-type]
            )

    def test_validate_backup_count_non_negative(self) -> None:
        """Test that backup_count must be non-negative."""
        config = LoggingConfig(
            app_name=AppName("testapp"),
            text_file_backup_count=BackupCount(0),
        )
        assert config.text_file_backup_count == 0

    def test_validate_port_range(self) -> None:
        """Test that port must be in valid range."""
        with pytest.raises(ValidationError):
            LoggingConfig(
                app_name=AppName("testapp"),
                viewer_port=0,  # type: ignore[arg-type]
            )

        with pytest.raises(ValidationError):
            LoggingConfig(
                app_name=AppName("testapp"),
                viewer_port=70000,  # type: ignore[arg-type]
            )

    def test_validate_queue_size_positive(self) -> None:
        """Test that queue_size must be positive."""
        with pytest.raises(ValidationError):
            LoggingConfig(
                app_name=AppName("testapp"),
                viewer_queue_size=QueueSize(0),
            )

    def test_validate_http_endpoint_required(self) -> None:
        """Test that HTTP endpoint is required when HTTP enabled."""
        with pytest.raises(ValidationError, match="http_endpoint required"):
            LoggingConfig(
                app_name=AppName("testapp"),
                enable_http=True,
                http_endpoint=None,
            )

    def test_validate_error_file_requires_file(self) -> None:
        """Test that error file requires file logging enabled."""
        with pytest.raises(ValidationError, match="enable_error_file=True requires"):
            LoggingConfig(
                app_name=AppName("testapp"),
                enable_file=False,
                enable_error_file=True,
            )


class TestComputedProperties:
    """Tests for computed properties."""

    def test_run_log_dir(self, tmp_path: Path) -> None:
        """Test run_log_dir property."""
        config = LoggingConfig(
            app_name=AppName("testapp"),
            log_dir=LogDirPath(str(tmp_path)),
        )

        run_log_dir = config.run_log_dir
        assert tmp_path.name in run_log_dir or str(tmp_path) in run_log_dir

    def test_text_file_path(self, tmp_path: Path) -> None:
        """Test text_file_path property."""
        config = LoggingConfig(
            app_name=AppName("testapp"),
            log_dir=LogDirPath(str(tmp_path)),
        )

        text_file = config.text_file_path
        assert "testapp" in text_file
        assert ".log" in text_file

    def test_error_file_path(self, tmp_path: Path) -> None:
        """Test error_file_path property."""
        config = LoggingConfig(
            app_name=AppName("testapp"),
            log_dir=LogDirPath(str(tmp_path)),
        )

        error_file = config.error_file_path
        assert "testapp" in error_file
        assert ".error.log" in error_file

    def test_json_file_path(self, tmp_path: Path) -> None:
        """Test json_file_path property."""
        config = LoggingConfig(
            app_name=AppName("testapp"),
            log_dir=LogDirPath(str(tmp_path)),
        )

        json_file = config.json_file_path
        assert "testapp" in json_file
        assert ".json.log" in json_file


class TestSetupMethod:
    """Tests for setup method."""

    def test_setup_creates_directories(self, tmp_path: Path) -> None:
        """Test that setup creates necessary directories."""
        config = LoggingConfig(
            app_name=AppName("testapp"),
            log_dir=LogDirPath(str(tmp_path)),
        )

        config.setup()

        # Run directory should exist
        run_dir = Path(config.run_log_dir)
        assert run_dir.exists()

    def test_setup_configures_logging(self, tmp_path: Path) -> None:
        """Test that setup configures logging."""
        config = LoggingConfig(
            app_name=AppName("testapp"),
            log_dir=LogDirPath(str(tmp_path)),
        )

        config.setup()

        # Should be able to get logger after setup
        import logging

        logger = logging.getLogger()
        assert logger is not None

    def test_setup_with_all_handlers(self, tmp_path: Path) -> None:
        """Test setup with all handlers enabled."""
        config = LoggingConfig(
            app_name=AppName("testapp"),
            log_dir=LogDirPath(str(tmp_path)),
            enable_console=True,
            enable_file=True,
            enable_json=True,
            enable_viewer=True,
        )

        config.setup()

        import logging

        logger = logging.getLogger()
        # Should have multiple handlers
        assert len(logger.handlers) > 0
