# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._state module.

Tests global state management and thread safety.
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Generator

import pytest

from bozo._models import LoggingConfig
from bozo._state import (
    get_config,
    get_viewer_thread,
    is_configured,
    is_viewer_running,
    require_config,
    reset_state,
    set_config,
    set_viewer_thread,
)
from bozo._types import AppName

if TYPE_CHECKING:
    pass


@pytest.fixture(autouse=True)
def reset_global_state() -> Generator[None, None, None]:
    """Reset global state before and after each test."""
    reset_state()
    yield
    reset_state()


class TestGetConfig:
    """Tests for get_config function."""

    def test_returns_none_initially(self) -> None:
        """Test that get_config returns None initially."""
        config = get_config()
        assert config is None

    def test_returns_set_config(self) -> None:
        """Test that get_config returns the set config."""
        config = LoggingConfig(app_name=AppName("test"))
        set_config(config)

        result = get_config()
        assert result is config


class TestSetConfig:
    """Tests for set_config function."""

    def test_sets_config(self) -> None:
        """Test setting config."""
        config = LoggingConfig(app_name=AppName("test"))
        set_config(config)

        assert get_config() is config

    def test_overwrites_existing_config(self) -> None:
        """Test that set_config overwrites existing config."""
        config1 = LoggingConfig(app_name=AppName("test1"))
        config2 = LoggingConfig(app_name=AppName("test2"))

        set_config(config1)
        set_config(config2)

        assert get_config() is config2


class TestRequireConfig:
    """Tests for require_config function."""

    def test_raises_when_not_configured(self) -> None:
        """Test that require_config raises when not configured."""
        with pytest.raises(RuntimeError, match="bozo not configured"):
            require_config()

    def test_returns_config_when_configured(self) -> None:
        """Test that require_config returns config when configured."""
        config = LoggingConfig(app_name=AppName("test"))
        set_config(config)

        result = require_config()
        assert result is config


class TestIsConfigured:
    """Tests for is_configured function."""

    def test_returns_false_initially(self) -> None:
        """Test that is_configured returns False initially."""
        assert is_configured() is False

    def test_returns_true_when_configured(self) -> None:
        """Test that is_configured returns True when configured."""
        config = LoggingConfig(app_name=AppName("test"))
        set_config(config)

        assert is_configured() is True

    def test_returns_false_after_reset(self) -> None:
        """Test that is_configured returns False after reset."""
        config = LoggingConfig(app_name=AppName("test"))
        set_config(config)
        reset_state()

        assert is_configured() is False


class TestGetViewerThread:
    """Tests for get_viewer_thread function."""

    def test_returns_none_initially(self) -> None:
        """Test that get_viewer_thread returns None initially."""
        thread = get_viewer_thread()
        assert thread is None

    def test_returns_set_thread(self) -> None:
        """Test that get_viewer_thread returns the set thread."""

        def dummy_target() -> None:
            pass

        thread = threading.Thread(target=dummy_target)
        set_viewer_thread(thread)

        result = get_viewer_thread()
        assert result is thread


class TestSetViewerThread:
    """Tests for set_viewer_thread function."""

    def test_sets_thread(self) -> None:
        """Test setting viewer thread."""

        def dummy_target() -> None:
            pass

        thread = threading.Thread(target=dummy_target)
        set_viewer_thread(thread)

        assert get_viewer_thread() is thread

    def test_clears_thread(self) -> None:
        """Test clearing viewer thread."""

        def dummy_target() -> None:
            pass

        thread = threading.Thread(target=dummy_target)
        set_viewer_thread(thread)
        set_viewer_thread(None)

        assert get_viewer_thread() is None


class TestIsViewerRunning:
    """Tests for is_viewer_running function."""

    def test_returns_false_initially(self) -> None:
        """Test that is_viewer_running returns False initially."""
        assert is_viewer_running() is False

    def test_returns_false_when_thread_not_set(self) -> None:
        """Test that is_viewer_running returns False when thread not set."""
        assert is_viewer_running() is False

    def test_returns_true_when_thread_alive(self) -> None:
        """Test that is_viewer_running returns True when thread is alive."""
        import time

        def long_running_task() -> None:
            time.sleep(0.5)

        thread = threading.Thread(target=long_running_task)
        thread.start()
        set_viewer_thread(thread)

        assert is_viewer_running() is True

        thread.join()

    def test_returns_false_when_thread_dead(self) -> None:
        """Test that is_viewer_running returns False when thread is dead."""

        def quick_task() -> None:
            pass

        thread = threading.Thread(target=quick_task)
        thread.start()
        set_viewer_thread(thread)

        thread.join()  # Wait for thread to finish

        assert is_viewer_running() is False


class TestResetState:
    """Tests for reset_state function."""

    def test_clears_config(self) -> None:
        """Test that reset_state clears config."""
        config = LoggingConfig(app_name=AppName("test"))
        set_config(config)

        reset_state()

        assert get_config() is None

    def test_clears_viewer_thread(self) -> None:
        """Test that reset_state clears viewer thread."""

        def dummy_target() -> None:
            pass

        thread = threading.Thread(target=dummy_target)
        set_viewer_thread(thread)

        reset_state()

        assert get_viewer_thread() is None

    def test_clears_all_state(self) -> None:
        """Test that reset_state clears all state."""
        config = LoggingConfig(app_name=AppName("test"))
        set_config(config)

        def dummy_target() -> None:
            pass

        thread = threading.Thread(target=dummy_target)
        set_viewer_thread(thread)

        reset_state()

        assert get_config() is None
        assert get_viewer_thread() is None
        assert is_configured() is False


class TestThreadSafety:
    """Tests for thread safety of state management."""

    def test_concurrent_set_config(self) -> None:
        """Test that concurrent set_config calls are thread-safe."""
        configs = [LoggingConfig(app_name=AppName(f"test{i}")) for i in range(10)]

        def worker(config: LoggingConfig) -> None:
            set_config(config)

        threads = [
            threading.Thread(target=worker, args=(config,)) for config in configs
        ]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # One of the configs should be set
        result = get_config()
        assert result is not None
        assert result in configs

    def test_concurrent_get_config(self) -> None:
        """Test that concurrent get_config calls are thread-safe."""
        config = LoggingConfig(app_name=AppName("test"))
        set_config(config)

        results: list[LoggingConfig | None] = []

        def worker() -> None:
            result = get_config()
            results.append(result)

        threads = [threading.Thread(target=worker) for _ in range(10)]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All results should be the same config
        assert all(r is config for r in results)

    def test_concurrent_is_configured(self) -> None:
        """Test that concurrent is_configured calls are thread-safe."""
        config = LoggingConfig(app_name=AppName("test"))
        set_config(config)

        results: list[bool] = []

        def worker() -> None:
            result = is_configured()
            results.append(result)

        threads = [threading.Thread(target=worker) for _ in range(10)]

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All results should be True
        assert all(results)

    def test_concurrent_viewer_thread_operations(self) -> None:
        """Test that concurrent viewer thread operations are thread-safe."""

        def dummy_target() -> None:
            import time

            time.sleep(0.1)

        threads_to_set = [threading.Thread(target=dummy_target) for _ in range(5)]
        results: list[bool] = []

        def worker(thread: threading.Thread) -> None:
            thread.start()
            set_viewer_thread(thread)
            result = get_viewer_thread()
            results.append(result is not None)

        worker_threads = [
            threading.Thread(target=worker, args=(t,)) for t in threads_to_set
        ]

        for t in worker_threads:
            t.start()
        for t in worker_threads:
            t.join()

        for t in threads_to_set:
            if t.is_alive():
                t.join()

        # All operations should have succeeded
        assert len(results) == 5


class TestStateIntegration:
    """Integration tests for state management."""

    def test_full_lifecycle(self) -> None:
        """Test full lifecycle of state management."""
        # Initially not configured
        assert not is_configured()
        assert get_config() is None

        # Set config
        config = LoggingConfig(app_name=AppName("test"))
        set_config(config)

        assert is_configured()
        assert get_config() is config
        assert require_config() is config

        # Set viewer thread
        def dummy_target() -> None:
            import time

            time.sleep(0.1)

        thread = threading.Thread(target=dummy_target)
        thread.start()
        set_viewer_thread(thread)

        assert get_viewer_thread() is thread
        assert is_viewer_running()

        # Reset state
        reset_state()

        assert not is_configured()
        assert get_config() is None
        assert get_viewer_thread() is None

        thread.join()

    def test_multiple_config_changes(self) -> None:
        """Test multiple configuration changes."""
        configs = [LoggingConfig(app_name=AppName(f"test{i}")) for i in range(5)]

        for config in configs:
            set_config(config)
            assert get_config() is config
            assert is_configured()

        # Last config should be active
        assert get_config() is configs[-1]
