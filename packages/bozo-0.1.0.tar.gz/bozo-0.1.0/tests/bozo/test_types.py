# Copyright (c) 2026 Tejus Gupta
# SPDX-License-Identifier: MIT
"""Comprehensive tests for bozo._types module.

Tests all type definitions, enums, and constants.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import pytest

from bozo._types import (
    DEFAULT_BACKUP_COUNT,
    DEFAULT_BATCH_SIZE,
    DEFAULT_EXPORT_LIMIT,
    DEFAULT_FLUSH_INTERVAL,
    DEFAULT_MAX_BYTES,
    DEFAULT_QUEUE_SIZE,
    DEFAULT_VIEWER_HOST,
    DEFAULT_VIEWER_PORT,
    DROP_NOTIFICATION_THRESHOLD,
    Environment,
    ExportFormat,
    FILE_CHUNK_SIZE,
    KEYBOARD_SHORTCUTS,
    LOG_FILE_ENCODING,
    LogFormat,
    LogLevel,
    MAX_PORT_NUMBER,
    MIN_BACKUP_COUNT,
    MIN_FILE_SIZE_BYTES,
    MIN_PORT_NUMBER,
    MIN_QUEUE_SIZE,
    REDACTED_PLACEHOLDER,
    ThemeMode,
    ViewerEndpoints,
)

if TYPE_CHECKING:
    pass


class TestLogLevel:
    """Tests for LogLevel enum."""

    def test_debug_value(self) -> None:
        """Test DEBUG enum value."""
        assert LogLevel.DEBUG.value == logging.DEBUG

    def test_info_value(self) -> None:
        """Test INFO enum value."""
        assert LogLevel.INFO.value == logging.INFO

    def test_warning_value(self) -> None:
        """Test WARNING enum value."""
        assert LogLevel.WARNING.value == logging.WARNING

    def test_error_value(self) -> None:
        """Test ERROR enum value."""
        assert LogLevel.ERROR.value == logging.ERROR

    def test_critical_value(self) -> None:
        """Test CRITICAL enum value."""
        assert LogLevel.CRITICAL.value == logging.CRITICAL

    def test_from_string_lowercase(self) -> None:
        """Test from_string with lowercase input."""
        assert LogLevel.from_string("debug") == LogLevel.DEBUG
        assert LogLevel.from_string("info") == LogLevel.INFO
        assert LogLevel.from_string("warning") == LogLevel.WARNING
        assert LogLevel.from_string("error") == LogLevel.ERROR
        assert LogLevel.from_string("critical") == LogLevel.CRITICAL

    def test_from_string_uppercase(self) -> None:
        """Test from_string with uppercase input."""
        assert LogLevel.from_string("DEBUG") == LogLevel.DEBUG
        assert LogLevel.from_string("INFO") == LogLevel.INFO

    def test_from_string_mixed_case(self) -> None:
        """Test from_string with mixed case input."""
        assert LogLevel.from_string("DeBuG") == LogLevel.DEBUG
        assert LogLevel.from_string("InFo") == LogLevel.INFO

    def test_from_string_invalid(self) -> None:
        """Test from_string with invalid input."""
        with pytest.raises(KeyError):
            LogLevel.from_string("INVALID")

    def test_to_logging_level(self) -> None:
        """Test to_logging_level conversion."""
        assert LogLevel.DEBUG.to_logging_level() == logging.DEBUG
        assert LogLevel.INFO.to_logging_level() == logging.INFO
        assert LogLevel.WARNING.to_logging_level() == logging.WARNING
        assert LogLevel.ERROR.to_logging_level() == logging.ERROR
        assert LogLevel.CRITICAL.to_logging_level() == logging.CRITICAL


class TestEnvironment:
    """Tests for Environment enum."""

    def test_development_value(self) -> None:
        """Test DEVELOPMENT enum value."""
        assert Environment.DEVELOPMENT.value == "development"

    def test_production_value(self) -> None:
        """Test PRODUCTION enum value."""
        assert Environment.PRODUCTION.value == "production"

    def test_equality(self) -> None:
        """Test enum equality."""
        assert Environment.DEVELOPMENT == Environment.DEVELOPMENT
        assert Environment.PRODUCTION == Environment.PRODUCTION


class TestLogFormat:
    """Tests for LogFormat enum."""

    def test_text_value(self) -> None:
        """Test TEXT enum value."""
        assert LogFormat.TEXT.value == "text"

    def test_json_value(self) -> None:
        """Test JSON enum value."""
        assert LogFormat.JSON.value == "json"


class TestExportFormat:
    """Tests for ExportFormat enum."""

    def test_json_value(self) -> None:
        """Test JSON enum value."""
        assert ExportFormat.JSON.value == "json"

    def test_text_value(self) -> None:
        """Test TEXT enum value."""
        assert ExportFormat.TEXT.value == "text"


class TestThemeMode:
    """Tests for ThemeMode enum."""

    def test_system_value(self) -> None:
        """Test SYSTEM enum value."""
        assert ThemeMode.SYSTEM.value == "system"

    def test_light_value(self) -> None:
        """Test LIGHT enum value."""
        assert ThemeMode.LIGHT.value == "light"

    def test_dark_value(self) -> None:
        """Test DARK enum value."""
        assert ThemeMode.DARK.value == "dark"


class TestConstants:
    """Tests for module constants."""

    def test_redacted_placeholder(self) -> None:
        """Test REDACTED_PLACEHOLDER constant."""
        assert REDACTED_PLACEHOLDER == "***REDACTED***"
        assert isinstance(REDACTED_PLACEHOLDER, str)

    def test_log_file_encoding(self) -> None:
        """Test LOG_FILE_ENCODING constant."""
        assert LOG_FILE_ENCODING == "utf-8"

    def test_default_queue_size(self) -> None:
        """Test DEFAULT_QUEUE_SIZE constant."""
        assert DEFAULT_QUEUE_SIZE == 1000
        assert isinstance(DEFAULT_QUEUE_SIZE, int)

    def test_default_batch_size(self) -> None:
        """Test DEFAULT_BATCH_SIZE constant."""
        assert DEFAULT_BATCH_SIZE == 50
        assert isinstance(DEFAULT_BATCH_SIZE, int)

    def test_default_flush_interval(self) -> None:
        """Test DEFAULT_FLUSH_INTERVAL constant."""
        assert DEFAULT_FLUSH_INTERVAL == 2.0
        assert isinstance(DEFAULT_FLUSH_INTERVAL, float)

    def test_default_max_bytes(self) -> None:
        """Test DEFAULT_MAX_BYTES constant."""
        assert DEFAULT_MAX_BYTES == 5 * 1024 * 1024
        assert isinstance(DEFAULT_MAX_BYTES, int)

    def test_default_backup_count(self) -> None:
        """Test DEFAULT_BACKUP_COUNT constant."""
        assert DEFAULT_BACKUP_COUNT == 10
        assert isinstance(DEFAULT_BACKUP_COUNT, int)

    def test_default_viewer_host(self) -> None:
        """Test DEFAULT_VIEWER_HOST constant."""
        assert DEFAULT_VIEWER_HOST == "127.0.0.1"

    def test_default_viewer_port(self) -> None:
        """Test DEFAULT_VIEWER_PORT constant."""
        assert DEFAULT_VIEWER_PORT == 8080
        assert isinstance(DEFAULT_VIEWER_PORT, int)

    def test_default_export_limit(self) -> None:
        """Test DEFAULT_EXPORT_LIMIT constant."""
        assert DEFAULT_EXPORT_LIMIT == 50000
        assert isinstance(DEFAULT_EXPORT_LIMIT, int)

    def test_drop_notification_threshold(self) -> None:
        """Test DROP_NOTIFICATION_THRESHOLD constant."""
        assert DROP_NOTIFICATION_THRESHOLD == 100
        assert isinstance(DROP_NOTIFICATION_THRESHOLD, int)

    def test_file_chunk_size(self) -> None:
        """Test FILE_CHUNK_SIZE constant."""
        assert FILE_CHUNK_SIZE == 8192
        assert isinstance(FILE_CHUNK_SIZE, int)

    def test_port_number_range(self) -> None:
        """Test port number range constants."""
        assert MIN_PORT_NUMBER == 1
        assert MAX_PORT_NUMBER == 65535
        assert MIN_PORT_NUMBER < MAX_PORT_NUMBER

    def test_min_backup_count(self) -> None:
        """Test MIN_BACKUP_COUNT constant."""
        assert MIN_BACKUP_COUNT == 0

    def test_min_file_size_bytes(self) -> None:
        """Test MIN_FILE_SIZE_BYTES constant."""
        assert MIN_FILE_SIZE_BYTES == 1

    def test_min_queue_size(self) -> None:
        """Test MIN_QUEUE_SIZE constant."""
        assert MIN_QUEUE_SIZE == 1


class TestViewerEndpoints:
    """Tests for ViewerEndpoints class."""

    def test_root_endpoint(self) -> None:
        """Test ROOT endpoint."""
        assert ViewerEndpoints.ROOT == "/"

    def test_api_runs_endpoint(self) -> None:
        """Test API_RUNS endpoint."""
        assert ViewerEndpoints.API_RUNS == "/api/runs"

    def test_api_logs_endpoint(self) -> None:
        """Test API_LOGS endpoint."""
        assert ViewerEndpoints.API_LOGS == "/api/logs/{run_id}"

    def test_api_stream_endpoint(self) -> None:
        """Test API_STREAM endpoint."""
        assert ViewerEndpoints.API_STREAM == "/api/logs/{run_id}/stream"

    def test_api_stats_endpoint(self) -> None:
        """Test API_STATS endpoint."""
        assert ViewerEndpoints.API_STATS == "/api/stats/{run_id}"

    def test_api_export_endpoint(self) -> None:
        """Test API_EXPORT endpoint."""
        assert ViewerEndpoints.API_EXPORT == "/api/export/{run_id}"

    def test_api_export_count_endpoint(self) -> None:
        """Test API_EXPORT_COUNT endpoint."""
        assert ViewerEndpoints.API_EXPORT_COUNT == "/api/export/{run_id}/count"

    def test_cannot_instantiate(self) -> None:
        """Test that ViewerEndpoints cannot be instantiated."""
        with pytest.raises(TypeError, match="cannot be instantiated"):
            ViewerEndpoints()


class TestKeyboardShortcuts:
    """Tests for KEYBOARD_SHORTCUTS constant."""

    def test_is_tuple(self) -> None:
        """Test that KEYBOARD_SHORTCUTS is a tuple."""
        assert isinstance(KEYBOARD_SHORTCUTS, tuple)

    def test_not_empty(self) -> None:
        """Test that KEYBOARD_SHORTCUTS is not empty."""
        assert len(KEYBOARD_SHORTCUTS) > 0

    def test_all_have_required_keys(self) -> None:
        """Test that all shortcuts have required keys."""
        for shortcut in KEYBOARD_SHORTCUTS:
            assert "key" in shortcut
            assert "description" in shortcut
            assert "category" in shortcut

    def test_all_categories_valid(self) -> None:
        """Test that all categories are valid."""
        valid_categories = {"Navigation", "Filters", "Actions", "View"}
        for shortcut in KEYBOARD_SHORTCUTS:
            assert shortcut["category"] in valid_categories

    def test_all_keys_are_strings(self) -> None:
        """Test that all keys are strings."""
        for shortcut in KEYBOARD_SHORTCUTS:
            assert isinstance(shortcut["key"], str)
            assert len(shortcut["key"]) > 0

    def test_all_descriptions_are_strings(self) -> None:
        """Test that all descriptions are strings."""
        for shortcut in KEYBOARD_SHORTCUTS:
            assert isinstance(shortcut["description"], str)
            assert len(shortcut["description"]) > 0

    def test_navigation_shortcuts_exist(self) -> None:
        """Test that navigation shortcuts exist."""
        nav_shortcuts = [s for s in KEYBOARD_SHORTCUTS if s["category"] == "Navigation"]
        assert len(nav_shortcuts) > 0

    def test_filter_shortcuts_exist(self) -> None:
        """Test that filter shortcuts exist."""
        filter_shortcuts = [s for s in KEYBOARD_SHORTCUTS if s["category"] == "Filters"]
        assert len(filter_shortcuts) > 0

    def test_action_shortcuts_exist(self) -> None:
        """Test that action shortcuts exist."""
        action_shortcuts = [s for s in KEYBOARD_SHORTCUTS if s["category"] == "Actions"]
        assert len(action_shortcuts) > 0

    def test_view_shortcuts_exist(self) -> None:
        """Test that view shortcuts exist."""
        view_shortcuts = [s for s in KEYBOARD_SHORTCUTS if s["category"] == "View"]
        assert len(view_shortcuts) > 0


class TestNewTypes:
    """Tests for NewType definitions."""

    def test_app_name_type(self) -> None:
        """Test AppName type."""
        from bozo._types import AppName

        app_name = AppName("myapp")
        assert isinstance(app_name, str)
        assert app_name == "myapp"

    def test_module_name_type(self) -> None:
        """Test ModuleName type."""
        from bozo._types import ModuleName

        module_name = ModuleName("__main__")
        assert isinstance(module_name, str)
        assert module_name == "__main__"

    def test_run_id_type(self) -> None:
        """Test RunId type."""
        from bozo._types import RunId

        run_id = RunId("12345678-1234-1234-1234-123456789012")
        assert isinstance(run_id, str)

    def test_log_dir_path_type(self) -> None:
        """Test LogDirPath type."""
        from bozo._types import LogDirPath

        log_dir = LogDirPath("/path/to/logs")
        assert isinstance(log_dir, str)

    def test_log_file_path_type(self) -> None:
        """Test LogFilePath type."""
        from bozo._types import LogFilePath

        log_file = LogFilePath("/path/to/logs/app.log")
        assert isinstance(log_file, str)

    def test_http_endpoint_type(self) -> None:
        """Test HttpEndpoint type."""
        from bozo._types import HttpEndpoint

        endpoint = HttpEndpoint("http://localhost:8000/logs")
        assert isinstance(endpoint, str)

    def test_queue_size_type(self) -> None:
        """Test QueueSize type."""
        from bozo._types import QueueSize

        queue_size = QueueSize(1000)
        assert isinstance(queue_size, int)

    def test_batch_size_type(self) -> None:
        """Test BatchSize type."""
        from bozo._types import BatchSize

        batch_size = BatchSize(50)
        assert isinstance(batch_size, int)

    def test_port_number_type(self) -> None:
        """Test PortNumber type."""
        from bozo._types import PortNumber

        port = PortNumber(8080)
        assert isinstance(port, int)

    def test_host_address_type(self) -> None:
        """Test HostAddress type."""
        from bozo._types import HostAddress

        host = HostAddress("127.0.0.1")
        assert isinstance(host, str)


class TestTypedDicts:
    """Tests for TypedDict definitions."""

    def test_log_entry_dict_structure(self) -> None:
        """Test LogEntryDict structure."""
        from bozo._types import EventId, LogEntryDict, Timestamp

        entry: LogEntryDict = {
            "id": EventId(1),
            "timestamp": Timestamp("2026-01-01T00:00:00"),
            "level": "INFO",
            "event": "test",
        }
        assert "id" in entry
        assert "timestamp" in entry

    def test_log_stats_dict_structure(self) -> None:
        """Test LogStatsDict structure."""
        from bozo._types import LogStatsDict

        stats: LogStatsDict = {
            "debug": 10,
            "info": 20,
            "warning": 5,
            "error": 2,
            "critical": 0,
            "total": 37,
        }
        assert stats["debug"] == 10
        assert stats["total"] == 37

    def test_run_info_dict_structure(self) -> None:
        """Test RunInfoDict structure."""
        from bozo._types import AppName, RunId, RunInfoDict, Timestamp

        info: RunInfoDict = {
            "run_id": RunId("12345678-1234-1234-1234-123456789012"),
            "created_at": Timestamp("2026-01-01T00:00:00"),
            "log_count": 100,
            "is_current": True,
            "app_name": AppName("myapp"),
        }
        assert info["is_current"] is True
