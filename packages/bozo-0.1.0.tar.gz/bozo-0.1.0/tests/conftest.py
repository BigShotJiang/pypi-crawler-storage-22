from __future__ import annotations

import logging
import uuid
from pathlib import Path
from collections.abc import Generator
from typing import Any

import pytest

from bozo._state import reset_state


@pytest.fixture(autouse=True)
def reset_logging_config() -> Generator[None, None, None]:
    """Reset bozo and stdlib logging state before and after each test."""
    reset_state()

    root = logging.getLogger()
    for handler in root.handlers[:]:
        root.removeHandler(handler)
        handler.close()
    root.setLevel(logging.WARNING)

    yield

    for handler in root.handlers[:]:
        root.removeHandler(handler)
        handler.close()


@pytest.fixture
def temp_log_dir(tmp_path: Path) -> Path:
    log_dir = tmp_path / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    return log_dir


@pytest.fixture
def sample_log_entries() -> list[dict[str, Any]]:
    return [
        {"event": "test1", "level": "info"},
        {"event": "test2", "level": "warning"},
        {"event": "test3", "level": "error"},
    ]


@pytest.fixture
def isolated_logger_name() -> str:
    return f"test.logger.{uuid.uuid4().hex[:8]}"


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line("markers", "unit: fast unit tests")
    config.addinivalue_line("markers", "integration: integration tests")
    config.addinivalue_line("markers", "slow: slow tests")


def pytest_collection_modifyitems(
    config: pytest.Config,  # noqa: ARG001
    items: list[pytest.Item],
) -> None:
    for item in items:
        if "asyncio" in item.keywords:
            item.add_marker(pytest.mark.asyncio)
        if "integration" in item.nodeid.lower():
            item.add_marker(pytest.mark.integration)
        if any(k in item.nodeid.lower() for k in ("slow", "performance", "load")):
            item.add_marker(pytest.mark.slow)
