"""Helper functions for license CLI commands.

Extracted from license.py to maintain architecture limits.
"""

from __future__ import annotations

import json
import os
import platform
import shutil
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel

from bpsai_pair.licensing import (
    CATEGORY_TO_FEATURES,
    SignedLicense,
    clear_license_cache,
)

console = Console()


def print_json(data: dict) -> None:
    """Print JSON to stdout without Rich formatting."""
    sys.stdout.write(json.dumps(data, indent=2))
    sys.stdout.write("\n")
    sys.stdout.flush()


def get_license_file_path() -> Path | None:
    """Get the path to the currently loaded license file."""
    env_path = os.environ.get("PAIRCODER_LICENSE")
    if env_path:
        path = Path(env_path)
        if path.exists():
            return path

    home_license = Path.home() / ".paircoder" / "license.json"
    if home_license.exists():
        return home_license

    cwd_license = Path.cwd() / ".paircoder" / "license.json"
    if cwd_license.exists():
        return cwd_license

    return None


def format_expiry(license_data: SignedLicense | None) -> str:
    """Format expiration date for display."""
    if license_data is None:
        return "N/A"
    expires = license_data.payload.expires_at
    if expires is None:
        return "Never (Perpetual)"
    return expires.strftime("%Y-%m-%d")


def build_status_json(license_data, tier, tier_display, features) -> dict:
    """Build JSON dict for status output."""
    if license_data:
        return {
            "tier": tier,
            "tier_display": tier_display,
            "type": license_data.payload.type,
            "email": license_data.payload.email,
            "name": license_data.payload.name,
            "expires_at": (
                license_data.payload.expires_at.isoformat()
                if license_data.payload.expires_at
                else None
            ),
            "founder_number": license_data.payload.founder_number,
            "feature_count": len(features),
            "features": sorted(features),
        }
    return {
        "tier": tier,
        "tier_display": tier_display,
        "type": None,
        "email": None,
        "name": None,
        "expires_at": None,
        "founder_number": None,
        "feature_count": len(features),
        "features": sorted(features),
    }


def print_status_rich(license_data, tier_display, features) -> None:
    """Print status in Rich format."""
    console.print()
    if license_data is None:
        _print_solo_status(features)
    else:
        _print_licensed_status(license_data, tier_display, features)
    console.print()


def _print_solo_status(features) -> None:
    """Print Solo tier status panel."""
    panel = Panel(
        f"[bold]Tier:[/bold]     Solo (Free)\n"
        f"[bold]Features:[/bold] {len(features)} available\n"
        f"\n"
        f"[dim]No license file found.[/dim]\n"
        f"[dim]Using free tier with basic features.[/dim]",
        title="[bold blue]License Status[/bold blue]",
        border_style="blue",
    )
    console.print(panel)
    console.print()
    console.print("[yellow]Upgrade at:[/yellow] https://paircoder.ai/pricing")


def _print_licensed_status(license_data, tier_display, features) -> None:
    """Print licensed status panel."""
    founder_info = ""
    if license_data.payload.founder_number:
        founder_info = f"\n[bold]Founder #:[/bold] {license_data.payload.founder_number}"
    panel = Panel(
        f"[bold]Tier:[/bold]     {tier_display}\n"
        f"[bold]Type:[/bold]     {license_data.payload.type.title()}\n"
        f"[bold]Email:[/bold]    {license_data.payload.email}\n"
        f"[bold]Expires:[/bold]  {format_expiry(license_data)}\n"
        f"[bold]Features:[/bold] {len(features)} available{founder_info}",
        title="[bold green]License Status[/bold green]",
        border_style="green",
    )
    console.print(panel)


def print_features_rich(tier, tier_display, license_data) -> None:
    """Print features in Rich format."""
    console.print()
    console.print(f"[bold]Available Features ({tier_display})[/bold]")
    console.print("─" * 40)
    console.print()

    licensed_categories = license_data.payload.features if license_data else ["basic_features"]
    for category in licensed_categories:
        if category in CATEGORY_TO_FEATURES:
            cat_features = CATEGORY_TO_FEATURES[category]
            if cat_features:
                cat_name = category.replace("_", " ").title()
                features_str = ", ".join(sorted(cat_features))
                console.print(f"[bold cyan]{cat_name}:[/bold cyan]")
                console.print(f"  {features_str}")
                console.print()

    if tier == "solo":
        _print_locked_features()
    console.print()


def _print_locked_features() -> None:
    """Print locked features section for solo tier."""
    console.print("[dim]━" * 40 + "[/dim]")
    console.print()
    console.print("[yellow]Locked Features (Pro tier):[/yellow]")
    pro_features = CATEGORY_TO_FEATURES.get("pro_features", set())
    if pro_features:
        console.print(f"  [dim]{', '.join(sorted(pro_features))}[/dim]")
    console.print()
    console.print("[dim]Upgrade at: https://paircoder.ai/pricing[/dim]")


def is_wsl() -> bool:
    """Check if running in Windows Subsystem for Linux."""
    try:
        return "microsoft" in platform.uname().release.lower()
    except Exception:
        return False


def validate_license_file(license_file: Path) -> SignedLicense:
    """Validate and parse a license file. Raises typer.Exit on error."""
    if not license_file.exists():
        console.print(f"[red]Error:[/red] License file not found: {license_file}")

        # Add WSL-specific hint
        if is_wsl():
            console.print()
            console.print("[yellow]WSL Tip:[/yellow] Windows downloads are typically at:")
            console.print("  /mnt/c/Users/<YourName>/Downloads/")
            console.print()
            console.print("Example:")
            console.print("  [cyan]bpsai-pair license install /mnt/c/Users/kevin/Downloads/license.json[/cyan]")

        raise typer.Exit(1)

    try:
        content = license_file.read_text()
        data = json.loads(content)
    except json.JSONDecodeError as e:
        console.print(f"[red]Error:[/red] Invalid JSON in license file: {e}")
        raise typer.Exit(1)

    try:
        return SignedLicense(**data)
    except Exception as e:
        console.print(f"[red]Error:[/red] Invalid license format: {e}")
        raise typer.Exit(1)


def install_license_file(license_file: Path, dest_file: Path) -> None:
    """Copy license file to destination."""
    dest_file.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(license_file, dest_file)
    clear_license_cache()


def should_prompt_activation(license_data, machine_id: str) -> bool:
    """Check if we should prompt for machine activation.

    Returns True if:
    - License has machine binding (max_machines is set)
    - Current machine is not already activated
    """
    if license_data is None:
        return False

    max_machines = getattr(license_data.payload, "max_machines", None)
    if max_machines is None:
        return False

    activated = getattr(license_data.payload, "activated_machines", []) or []
    for m in activated:
        if getattr(m, "machine_id", None) == machine_id:
            return False

    return True


def show_deactivation_instructions() -> None:
    """Show instructions for deactivating machines."""
    console.print()
    console.print("To activate this machine, first deactivate another:")
    console.print("  1. Run: [cyan]bpsai-pair license machines[/cyan]")
    console.print("  2. Identify machine to remove")
    console.print("  3. Run: [cyan]bpsai-pair license deactivate[/cyan] on that machine")
    console.print("  4. Then: [cyan]bpsai-pair license activate[/cyan] on this machine")


def handle_activation_error(error_msg: str) -> None:
    """Handle activation error, show machines if slots exhausted."""
    console.print()
    if "403" in error_msg or "slot" in error_msg.lower():
        console.print("[yellow]No activation slots available.[/yellow]")
        show_deactivation_instructions()
    else:
        console.print(f"[red]Activation failed:[/red] {error_msg}")
    console.print()


def build_machines_json(
    result, current_machine_id: str, mask_fn, show_full_ids: bool = False
) -> dict:
    """Build JSON dict for machines list output.

    Args:
        result: MachinesListResult from API.
        current_machine_id: Current machine's ID for marking.
        mask_fn: Function to mask machine IDs.
        show_full_ids: If True, include full unmasked machine IDs.
    """
    machines_data = []
    for m in result.machines:
        machine_entry = {
            "machine_id": m.machine_id if show_full_ids else mask_fn(m.machine_id),
            "machine_name": m.machine_name,
            "activated_at": m.activated_at,
            "is_current": m.machine_id == current_machine_id,
        }
        machines_data.append(machine_entry)

    return {
        "machines": machines_data,
        "machines_used": result.machines_used,
        "machines_allowed": result.machines_allowed,
    }


def print_machines_table(result, current_machine_id: str, mask_fn) -> None:
    """Print machines list as rich table."""
    from rich.table import Table

    table = Table(title="Activated Machines")
    table.add_column("Machine ID", style="cyan")
    table.add_column("Name")
    table.add_column("Activated")

    for m in result.machines:
        is_current = m.machine_id == current_machine_id
        machine_display = mask_fn(m.machine_id)
        if is_current:
            machine_display += " [green](this machine)[/green]"
        name_display = m.machine_name or "[dim]-[/dim]"
        date_display = m.activated_at[:10] if m.activated_at else "-"
        table.add_row(machine_display, name_display, date_display)

    console.print(table)
    console.print()
    console.print(f"[bold]Slots:[/bold] {result.machines_used}/{result.machines_allowed} used")
    console.print()


def do_activation(license_data, machine_id: str) -> None:
    """Perform machine activation and handle errors."""
    from bpsai_pair.licensing.activation import ActivationError, activate_machine

    try:
        result = activate_machine(license_data.payload.license_id, machine_id)
        console.print()
        console.print("[green]✓[/green] Machine activated!")
        console.print(f"  Machines: {result.machines_used}/{result.machines_allowed} used")
    except ActivationError as e:
        handle_activation_error(str(e))


def handle_activation_prompt(
    license_data, machine_id: str, mask_fn, auto_activate: bool
) -> None:
    """Handle machine activation prompt after license install."""
    import typer

    console.print()
    console.print("[bold]Machine Activation[/bold]")
    console.print(f"  Machine ID: {mask_fn(machine_id)}")

    if auto_activate:
        do_activation(license_data, machine_id)
        return

    if typer.confirm("Activate this machine?", default=True):
        do_activation(license_data, machine_id)
    else:
        console.print()
        console.print("[dim]Skipping activation. Run 'bpsai-pair license activate' later.[/dim]")
    console.print()
