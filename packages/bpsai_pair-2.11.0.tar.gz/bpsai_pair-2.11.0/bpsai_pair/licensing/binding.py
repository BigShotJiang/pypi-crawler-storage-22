"""Machine binding verification for license validation.

Checks if the current machine is activated in the license and handles
grace periods for new machines.
"""

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .machine import get_machine_id
from .schema import LicensePayload


# Grace period for new machines before blocking (days)
GRACE_PERIOD_DAYS = 3


class MachineNotActivated(Exception):
    """Raised when the current machine is not activated in the license."""

    def __init__(
        self, slots_available: bool, max_machines: int, current_count: int
    ) -> None:
        self.slots_available = slots_available
        self.max_machines = max_machines
        self.current_count = current_count

        if slots_available:
            message = (
                f"This machine is not activated. "
                f"You have {max_machines - current_count} of {max_machines} "
                f"activation slots available. "
                f"Run 'bpsai-pair license activate' to activate this machine."
            )
        else:
            message = (
                f"This machine is not activated and all {max_machines} "
                f"activation slots are in use. "
                f"Run 'bpsai-pair license machines' to see activated machines, "
                f"then 'bpsai-pair license deactivate <machine-id>' to free a slot."
            )
        super().__init__(message)


def _get_paircoder_dir() -> Path:
    """Get the .paircoder directory path."""
    return Path.home() / ".paircoder"


def is_machine_activated(payload: LicensePayload) -> bool:
    """Check if the current machine is activated in the license.

    Args:
        payload: The license payload to check.

    Returns:
        True if machine is activated or license doesn't require binding.
        Note: Returns True for empty activation lists when slots are available,
        as the machine can be auto-activated on first use.
    """
    # Legacy licenses without machine binding always pass
    if payload.max_machines is None:
        return True

    current_machine_id = get_machine_id()

    # Check if current machine is in activated list
    for activation in payload.activated_machines:
        if activation.machine_id == current_machine_id:
            return True

    # Machine not in list
    # Special case: if no machines are activated yet and slots available,
    # treat as activated (will auto-activate on first use)
    current_count = len(payload.activated_machines)
    if current_count == 0 and payload.max_machines > 0:
        return True

    return False


def check_machine_binding(payload: LicensePayload) -> None:
    """Verify machine is activated, raising exception if not.

    Args:
        payload: The license payload to check.

    Raises:
        MachineNotActivated: If machine is not activated and binding is required.
    """
    # Legacy licenses without machine binding always pass
    if payload.max_machines is None:
        return

    current_machine_id = get_machine_id()

    # Check if current machine is in activated list
    for activation in payload.activated_machines:
        if activation.machine_id == current_machine_id:
            return

    # Machine not activated - determine if slots are available
    current_count = len(payload.activated_machines)
    slots_available = current_count < payload.max_machines

    raise MachineNotActivated(
        slots_available=slots_available,
        max_machines=payload.max_machines,
        current_count=current_count,
    )


def get_available_slots(payload: LicensePayload) -> int | None:
    """Get the number of available activation slots.

    Args:
        payload: The license payload to check.

    Returns:
        Number of available slots, or None for unlimited licenses.
    """
    if payload.max_machines is None:
        return None

    current_count = len(payload.activated_machines)
    return payload.max_machines - current_count


def record_first_seen() -> None:
    """Record when this machine first used PairCoder.

    Creates machine_state.json with first_seen_at timestamp if it doesn't exist.
    Does not overwrite existing records.
    """
    paircoder_dir = _get_paircoder_dir()
    state_file = paircoder_dir / "machine_state.json"

    # Don't overwrite existing first_seen_at
    if state_file.exists():
        try:
            data = json.loads(state_file.read_text())
            if "first_seen_at" in data:
                return
        except (json.JSONDecodeError, OSError):
            pass

    # Create directory if needed
    paircoder_dir.mkdir(parents=True, exist_ok=True)

    # Record first seen timestamp
    data = {"first_seen_at": datetime.now(timezone.utc).isoformat()}
    state_file.write_text(json.dumps(data))


def is_in_grace_period() -> bool:
    """Check if machine is within the grace period.

    Returns:
        True if within grace period, False if expired or no record exists.
    """
    paircoder_dir = _get_paircoder_dir()
    state_file = paircoder_dir / "machine_state.json"

    if not state_file.exists():
        return False

    try:
        data = json.loads(state_file.read_text())
        first_seen_str = data.get("first_seen_at")
        if not first_seen_str:
            return False

        first_seen = datetime.fromisoformat(first_seen_str)
        grace_end = first_seen + timedelta(days=GRACE_PERIOD_DAYS)

        return datetime.now(timezone.utc) < grace_end

    except (json.JSONDecodeError, OSError, ValueError):
        return False
