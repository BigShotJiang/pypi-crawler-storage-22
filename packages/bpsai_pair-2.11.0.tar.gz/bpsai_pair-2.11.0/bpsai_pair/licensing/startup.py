"""Startup license validation.

This module handles license validation during CLI startup:
- Validates license against API (with offline fallback)
- Caches result for session (avoids re-validation per command)
- Supports --offline flag and PAIRCODER_OFFLINE env var
- Provides warning/error messages for display
"""

import logging
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from .core import load_license
from .online import (
    LicenseRevoked,
    NetworkError,
    OfflineValidationExpired,
    ValidationResult,
    is_online_validation_enabled,
    validate_with_fallback,
)

logger = logging.getLogger(__name__)

# Session-level cache to avoid re-validation per command
_session_validation_result: Optional[ValidationResult] = None


def _get_paircoder_dir() -> Path:
    """Get the .paircoder directory path."""
    return Path.home() / ".paircoder"


def is_offline_flag_set() -> bool:
    """Check if --offline flag is in command line args."""
    return "--offline" in sys.argv


def clear_session_cache() -> None:
    """Clear the session validation cache."""
    global _session_validation_result
    _session_validation_result = None


def _create_error_result(message: str, from_cache: bool = False) -> ValidationResult:
    """Create a validation result for error cases."""
    return ValidationResult(
        valid=False,
        revoked=False,
        machine_activated=False,
        machines_used=0,
        machines_allowed=0,
        message=message,
        from_cache=from_cache,
    )


def _create_revoked_result(
    message: str, reason: str | None = None, revoked_at=None
) -> ValidationResult:
    """Create a validation result for revoked licenses."""
    return ValidationResult(
        valid=False,
        revoked=True,
        revoked_at=revoked_at,
        revoked_reason=reason,
        machine_activated=False,
        machines_used=0,
        machines_allowed=0,
        message=message,
        from_cache=True,
    )


# Number of days before expiration to start warning
EXPIRATION_WARNING_DAYS = 7


def _get_expiration_warning(expires_at: Optional[datetime]) -> Optional[str]:
    """Get warning message if license is expiring soon.

    Args:
        expires_at: License expiration datetime, or None for perpetual.

    Returns:
        Warning message if expiring within 7 days, None otherwise.
    """
    if expires_at is None:
        return None

    now = datetime.now(timezone.utc)
    days_remaining = (expires_at - now).days

    if days_remaining > EXPIRATION_WARNING_DAYS:
        return None

    if days_remaining <= 0:
        return "License has expired. Renew at https://paircoder.ai/pricing"
    elif days_remaining == 1:
        return "License expires tomorrow. Renew at https://paircoder.ai/pricing"
    else:
        return f"License expires in {days_remaining} days. Renew at https://paircoder.ai/pricing"


def _should_skip_validation() -> bool:
    """Check if validation should be skipped."""
    if not is_online_validation_enabled() or is_offline_flag_set():
        logger.debug("Skipping online validation (offline mode)")
        return True
    return False


def _get_license_id():
    """Get the license ID from the installed license."""
    try:
        signed_license = load_license()
    except Exception:
        signed_license = None

    if signed_license is None:
        logger.debug("Skipping online validation (no license)")
        return None

    return signed_license.payload.license_id


def _cache_and_return(result: ValidationResult) -> ValidationResult:
    """Cache and return the validation result."""
    global _session_validation_result
    _session_validation_result = result
    return result


def run_startup_validation() -> Optional[ValidationResult]:
    """Run license validation on CLI startup.

    Returns:
        ValidationResult if validation was performed, None if skipped.
        The result is cached for the session.
    """
    global _session_validation_result

    if _session_validation_result is not None:
        return _session_validation_result

    if _should_skip_validation():
        return None

    license_id = _get_license_id()
    if license_id is None:
        return None

    try:
        result = validate_with_fallback(license_id)
        return _cache_and_return(result)
    except LicenseRevoked as e:
        # Revoked licenses fail immediately - create result with revoked flag
        return _cache_and_return(_create_revoked_result(str(e), e.reason, e.revoked_at))
    except OfflineValidationExpired as e:
        return _cache_and_return(_create_error_result(str(e), from_cache=True))
    except NetworkError as e:
        logger.warning(f"Startup validation failed: {e}")
        return _cache_and_return(_create_error_result(str(e), from_cache=False))


def get_validation_warning(result: ValidationResult) -> Optional[str]:
    """Get a warning message for the validation result.

    Args:
        result: The validation result to check.

    Returns:
        Warning message string, or None if no warning needed.
    """
    if result.revoked:
        reason = result.revoked_reason or "No reason provided"
        return f"License revoked: {reason}"

    if not result.valid:
        return result.message or "License validation failed"

    if result.from_cache:
        return "Using cached license validation (offline mode)"

    if not result.machine_activated:
        if result.machines_used >= (result.machines_allowed or 0):
            return "Machine not activated. No slots available."
        return "Machine not activated on this license."

    # Check for approaching expiration (7 days warning)
    expiration_warning = _get_expiration_warning(result.expires_at)
    if expiration_warning:
        return expiration_warning

    return None
