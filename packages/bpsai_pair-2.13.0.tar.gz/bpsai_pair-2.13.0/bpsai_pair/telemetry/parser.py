"""Parser for Claude Code session data.

This module extracts execution metrics from Claude Code session transcripts
stored in ~/.claude/projects/. It handles JSONL format parsing, timestamp
extraction, and token usage aggregation.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class MessageCounts:
    """Counts of different message types in a session."""

    user: int = 0
    assistant: int = 0
    tool: int = 0
    system: int = 0

    @property
    def total(self) -> int:
        """Total number of messages."""
        return self.user + self.assistant + self.tool + self.system


@dataclass
class SessionMetrics:
    """Metrics extracted from a Claude Code session."""

    session_id: str | None
    project_path: str | None
    start_time: datetime | None
    end_time: datetime | None
    duration_seconds: float
    message_counts: MessageCounts
    total_input_tokens: int
    total_output_tokens: int
    model: str | None
    version: str | None
    git_branch: str | None
    is_complete: bool


@dataclass
class _SessionAccumulator:
    """Internal accumulator for collecting session data during parsing."""

    session_id: str | None = None
    version: str | None = None
    git_branch: str | None = None
    model: str | None = None
    project_path: str | None = None
    timestamps: list[datetime] | None = None
    counts: MessageCounts | None = None
    total_input: int = 0
    total_output: int = 0
    has_user: bool = False
    has_assistant: bool = False

    def __post_init__(self) -> None:
        if self.timestamps is None:
            self.timestamps = []
        if self.counts is None:
            self.counts = MessageCounts()


class ClaudeSessionParser:
    """Parser for Claude Code session transcript files.

    Claude Code stores session data in ~/.claude/projects/<project-hash>/
    where each session is stored as a .jsonl file containing message entries.
    """

    def __init__(self, claude_dir: Path | None = None):
        """Initialize the parser.

        Args:
            claude_dir: Path to Claude config directory. Defaults to ~/.claude
        """
        if claude_dir is None:
            claude_dir = Path.home() / ".claude"
        self.claude_dir = Path(claude_dir)
        self.projects_dir = self.claude_dir / "projects"

    def _project_path_to_hash(self, project_path: str) -> str:
        """Convert a project path to Claude's hash format."""
        normalized = project_path.rstrip("/")
        return normalized.replace("/", "-")

    def find_sessions(self, project_path: str) -> list[Path]:
        """Find all session files for a given project.

        Args:
            project_path: Absolute path to the project directory

        Returns:
            List of paths to session .jsonl files, sorted by modification time
        """
        project_hash = self._project_path_to_hash(project_path)
        project_dir = self.projects_dir / project_hash

        if not project_dir.exists():
            return []

        session_files = [f for f in project_dir.glob("*.jsonl") if f.is_file()]
        session_files.sort(key=lambda f: f.stat().st_mtime, reverse=True)
        return session_files

    def parse_session(self, session_file: Path) -> list[dict[str, Any]]:
        """Parse a single session transcript file.

        Args:
            session_file: Path to the .jsonl session file

        Returns:
            List of parsed JSON entries from the file
        """
        if not session_file.exists():
            return []

        entries: list[dict[str, Any]] = []
        try:
            with open(session_file, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entries.append(json.loads(line))
                    except json.JSONDecodeError as e:
                        logger.debug(
                            "Skipping malformed JSON at %s:%d: %s",
                            session_file, line_num, e
                        )
        except OSError as e:
            logger.warning("Error reading session file %s: %s", session_file, e)

        return entries

    def _parse_timestamp(self, timestamp_str: str) -> datetime | None:
        """Parse ISO 8601 timestamp string to datetime."""
        try:
            if timestamp_str.endswith("Z"):
                timestamp_str = timestamp_str[:-1] + "+00:00"
            return datetime.fromisoformat(timestamp_str)
        except (ValueError, TypeError):
            return None

    def _classify_message_type(self, entry: dict[str, Any]) -> str:
        """Classify an entry into message type."""
        entry_type = entry.get("type", "")
        if entry_type == "user" and "toolUseResult" in entry:
            return "tool"
        if entry_type in ("user", "assistant", "system"):
            return entry_type
        return "other"

    def _extract_token_usage(self, entry: dict[str, Any]) -> tuple[int, int]:
        """Extract input and output token counts from an entry."""
        message = entry.get("message", {})
        usage = message.get("usage", {})
        if not usage:
            return 0, 0

        input_tokens = (
            usage.get("input_tokens", 0)
            + usage.get("cache_creation_input_tokens", 0)
            + usage.get("cache_read_input_tokens", 0)
        )
        return input_tokens, usage.get("output_tokens", 0)

    def _extract_metadata(self, entry: dict[str, Any], acc: _SessionAccumulator) -> None:
        """Extract session metadata from an entry into accumulator."""
        if acc.session_id is None and "sessionId" in entry:
            acc.session_id = entry["sessionId"]
        if acc.version is None and "version" in entry:
            acc.version = entry["version"]
        if acc.git_branch is None and "gitBranch" in entry:
            acc.git_branch = entry["gitBranch"]
        if acc.project_path is None and "cwd" in entry:
            acc.project_path = entry["cwd"]

        if acc.model is None and entry.get("type") == "assistant":
            message = entry.get("message", {})
            if "model" in message:
                acc.model = message["model"]

    def _process_entry(self, entry: dict[str, Any], acc: _SessionAccumulator) -> None:
        """Process a single entry and update the accumulator."""
        self._extract_metadata(entry, acc)

        if "timestamp" in entry:
            ts = self._parse_timestamp(entry["timestamp"])
            if ts and acc.timestamps is not None:
                acc.timestamps.append(ts)

        msg_type = self._classify_message_type(entry)
        if acc.counts is not None:
            if msg_type == "user":
                acc.counts.user += 1
                acc.has_user = True
            elif msg_type == "assistant":
                acc.counts.assistant += 1
                acc.has_assistant = True
            elif msg_type == "tool":
                acc.counts.tool += 1
            elif msg_type == "system":
                acc.counts.system += 1

        if entry.get("type") == "assistant":
            input_t, output_t = self._extract_token_usage(entry)
            acc.total_input += input_t
            acc.total_output += output_t

    def _build_metrics(self, acc: _SessionAccumulator) -> SessionMetrics:
        """Build SessionMetrics from accumulated data."""
        timestamps = acc.timestamps or []
        start_time = min(timestamps) if timestamps else None
        end_time = max(timestamps) if timestamps else None
        duration = 0.0
        if start_time and end_time:
            duration = (end_time - start_time).total_seconds()

        return SessionMetrics(
            session_id=acc.session_id,
            project_path=acc.project_path,
            start_time=start_time,
            end_time=end_time,
            duration_seconds=duration,
            message_counts=acc.counts or MessageCounts(),
            total_input_tokens=acc.total_input,
            total_output_tokens=acc.total_output,
            model=acc.model,
            version=acc.version,
            git_branch=acc.git_branch,
            is_complete=acc.has_user and acc.has_assistant,
        )

    def _empty_metrics(self) -> SessionMetrics:
        """Return empty SessionMetrics for empty sessions."""
        return SessionMetrics(
            session_id=None,
            project_path=None,
            start_time=None,
            end_time=None,
            duration_seconds=0.0,
            message_counts=MessageCounts(),
            total_input_tokens=0,
            total_output_tokens=0,
            model=None,
            version=None,
            git_branch=None,
            is_complete=False,
        )

    def extract_metrics(self, entries: list[dict[str, Any]]) -> SessionMetrics:
        """Extract metrics from parsed session entries.

        Args:
            entries: List of parsed session entries

        Returns:
            SessionMetrics dataclass with extracted data
        """
        if not entries:
            return self._empty_metrics()

        acc = _SessionAccumulator()
        for entry in entries:
            self._process_entry(entry, acc)

        return self._build_metrics(acc)

    def get_all_metrics(self, project_path: str) -> list[SessionMetrics]:
        """Get metrics for all sessions in a project.

        Args:
            project_path: Absolute path to the project directory

        Returns:
            List of SessionMetrics for each session file
        """
        session_files = self.find_sessions(project_path)
        metrics_list: list[SessionMetrics] = []

        for session_file in session_files:
            entries = self.parse_session(session_file)
            if entries:
                metrics_list.append(self.extract_metrics(entries))

        return metrics_list
