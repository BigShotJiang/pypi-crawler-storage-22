"""Usage snapshot builder for license validation payloads.

Assembles anonymized usage data from TelemetryStore and AuditLog,
respecting the configured privacy level. The snapshot piggybacks on
existing license validation calls — no extra network requests.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from bpsai_pair.telemetry.audit import AuditLog
from bpsai_pair.telemetry.collectors import (
    EnvironmentCollector,
    FeatureUsageCollector,
    PerformanceCollector,
)
from bpsai_pair.telemetry.schema import Outcome, PrivacyLevel
from bpsai_pair.telemetry.store import TelemetryStore

logger = logging.getLogger(__name__)


@dataclass
class UsageSnapshot:
    """Tiered usage snapshot payload for license validation.

    MINIMAL fields are always populated, including error_count and
    estimation_accuracy which feed calibration. STANDARD and FULL
    fields default to None and are only set at the appropriate level.
    """

    # MINIMAL (always populated)
    total_tokens: int
    sessions: int
    tasks_completed: int
    hours_active: float
    audit_hash: str | None
    snapshot_at: datetime
    cli_version: str | None
    os_info: str | None
    python_version: str | None

    # MINIMAL optional (populated by builder at all levels)
    error_count: int | None = None
    estimation_accuracy: dict | None = None

    # STANDARD (populated at STANDARD+ privacy)
    feature_usage: dict | None = None
    cache_hit_rate: float | None = None

    # FULL (populated at FULL privacy)
    model_routing: dict | None = None
    workflow_patterns: dict | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary for JSON transmission.

        Excludes None optional fields to minimize payload size.
        """
        d: dict[str, Any] = {
            "total_tokens": self.total_tokens,
            "sessions": self.sessions,
            "tasks_completed": self.tasks_completed,
            "hours_active": self.hours_active,
            "audit_hash": self.audit_hash,
            "snapshot_at": self.snapshot_at.isoformat(),
            "cli_version": self.cli_version,
            "os_info": self.os_info,
            "python_version": self.python_version,
        }

        # Only include non-None optional fields
        for attr in (
            "feature_usage",
            "error_count",
            "cache_hit_rate",
            "estimation_accuracy",
            "model_routing",
            "workflow_patterns",
        ):
            value = getattr(self, attr)
            if value is not None:
                d[attr] = value

        return d


def build_usage_snapshot(
    project_root: Path, privacy_level: PrivacyLevel
) -> UsageSnapshot:
    """Build a usage snapshot from local telemetry data.

    Args:
        project_root: Path to the project root directory.
        privacy_level: Current privacy level controlling data inclusion.

    Returns:
        UsageSnapshot with fields populated according to privacy level.
    """
    store = TelemetryStore(project_root)
    audit_file = project_root / ".paircoder" / "telemetry" / "audit.jsonl"
    audit = AuditLog(audit_file)
    records = store.query(limit=10000)

    snapshot = _build_minimal_snapshot(store, audit, records)

    if privacy_level in (PrivacyLevel.STANDARD, PrivacyLevel.FULL):
        _enrich_standard_tier(snapshot, store)

    if privacy_level == PrivacyLevel.FULL:
        _enrich_full_tier(snapshot, records)

    return snapshot


def _build_minimal_snapshot(
    store: TelemetryStore, audit: AuditLog, records: list
) -> UsageSnapshot:
    """Build a MINIMAL-tier snapshot from store data."""
    stats = store.get_stats()
    env_data = EnvironmentCollector().collect()
    tasks_completed = sum(1 for r in records if r.outcome == Outcome.SUCCESS)
    error_count = sum(1 for r in records if r.outcome == Outcome.FAIL)

    return UsageSnapshot(
        total_tokens=stats.total_tokens,
        sessions=stats.total_records,
        tasks_completed=tasks_completed,
        hours_active=stats.total_duration_seconds / 3600.0,
        audit_hash=_get_audit_hash(audit),
        snapshot_at=datetime.now(timezone.utc),
        cli_version=env_data.get("cli_version"),
        os_info=env_data.get("os_info"),
        python_version=env_data.get("python_version"),
        error_count=error_count,
        estimation_accuracy=_build_estimation_accuracy(records),
    )


def _enrich_standard_tier(snapshot: UsageSnapshot, store: TelemetryStore) -> None:
    """Add STANDARD-tier data to an existing snapshot."""
    snapshot.feature_usage = FeatureUsageCollector(store).collect()
    perf_data = PerformanceCollector(store).collect()
    snapshot.cache_hit_rate = perf_data.get("cache_hit_rate")


def _enrich_full_tier(snapshot: UsageSnapshot, records: list) -> None:
    """Add FULL-tier data to an existing snapshot."""
    snapshot.model_routing = _build_model_routing(records)
    snapshot.workflow_patterns = _build_workflow_patterns(records)


def _get_audit_hash(audit: AuditLog) -> str | None:
    """Get the latest audit hash if the chain is valid."""
    is_valid, _ = audit.verify()
    if not is_valid:
        return None
    entries = audit.get_entries(limit=1)
    if not entries:
        return None
    return entries[0].entry_hash


def _build_estimation_accuracy(records: list) -> dict:
    """Build estimation accuracy data from records."""
    if not records:
        return {}
    durations = [r.duration_seconds for r in records]
    return {
        "total_records": len(records),
        "avg_duration": sum(durations) / len(durations),
    }


def _build_model_routing(records: list) -> dict:
    """Build model routing stats from records."""
    if not records:
        return {}
    from collections import Counter

    models: Counter[str] = Counter()
    for r in records:
        models[r.model] += 1
    return dict(models)


def _build_workflow_patterns(records: list) -> dict:
    """Build workflow pattern data from records."""
    if not records:
        return {}
    from collections import Counter

    task_types: Counter[str] = Counter()
    for r in records:
        task_types[r.task_type] += 1
    return dict(task_types)
