"""Workspace configuration parser.

Parses .paircoder-workspace.yaml files into validated WorkspaceConfig
objects, with directory hierarchy search and validation rules.
"""

from __future__ import annotations

from pathlib import Path

import yaml

from bpsai_pair.workspace.schema import ProjectConfig, WorkspaceConfig

_CONFIG_FILENAME = ".paircoder-workspace.yaml"


class WorkspaceParser:
    """Parses and validates workspace configuration files."""

    def parse(self, config_path: Path) -> WorkspaceConfig:
        """Parse a workspace config YAML file.

        Args:
            config_path: Path to .paircoder-workspace.yaml.

        Returns:
            Parsed WorkspaceConfig.

        Raises:
            FileNotFoundError: If config_path does not exist.
            ValueError: If YAML is invalid or required fields missing.
        """
        if not config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")

        try:
            raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in {config_path}: {e}") from e

        if not raw or not isinstance(raw, dict):
            raise ValueError(f"Empty or invalid config in {config_path}")

        if "name" not in raw:
            raise ValueError("Workspace config missing required field: name")
        if "projects" not in raw:
            raise ValueError("Workspace config missing required field: projects")

        root_path = config_path.parent
        projects = _parse_projects(raw.get("projects", {}))

        return WorkspaceConfig(
            name=raw["name"],
            projects=projects,
            root_path=root_path,
            config_path=config_path,
        )

    def find_workspace_config(self, start_path: Path) -> Path | None:
        """Search up directory tree for a workspace config file.

        Args:
            start_path: Directory to start searching from.

        Returns:
            Path to config file, or None if not found.
        """
        current = start_path.resolve()
        while True:
            candidate = current / _CONFIG_FILENAME
            if candidate.exists():
                return candidate
            parent = current.parent
            if parent == current:
                return None
            current = parent

    def validate(self, config: WorkspaceConfig) -> list[str]:
        """Validate a workspace configuration.

        Returns:
            List of error messages. Empty list means valid.
        """
        errors: list[str] = []

        if not config.projects:
            errors.append("At least one project must be defined")
            return errors

        project_names = set(config.projects.keys())

        for name, proj in config.projects.items():
            # Check path traversal — resolved path must be under root
            abs_path = (config.root_path / proj.path).resolve()
            if not str(abs_path).startswith(str(config.root_path.resolve())):
                errors.append(
                    f"Project '{name}': path outside workspace root "
                    f"(path traversal): {proj.path}"
                )
                continue

            # Check path exists
            if not abs_path.exists():
                errors.append(
                    f"Project '{name}': path does not exist: {proj.path}"
                )

            # Check consumer references
            for ref in proj.consumers:
                if ref not in project_names:
                    errors.append(
                        f"Project '{name}': consumer '{ref}' "
                        f"is not a defined project"
                    )

            # Check consumes references
            for ref in proj.consumes:
                if ref not in project_names:
                    errors.append(
                        f"Project '{name}': consumes '{ref}' "
                        f"is not a defined project"
                    )

        # Check for circular dependencies
        errors.extend(_check_cycles(config.projects))

        return errors


def _parse_projects(raw_projects: dict) -> dict[str, ProjectConfig]:
    """Parse project entries from raw YAML dict."""
    projects: dict[str, ProjectConfig] = {}
    for key, val in raw_projects.items():
        if not isinstance(val, dict):
            val = {}
        projects[key] = ProjectConfig(
            name=key,
            path=Path(val.get("path", f"./{key}")),
            repo=val.get("repo"),
            consumers=val.get("consumers", []),
            consumes=val.get("consumes", []),
            branch=val.get("branch", "main"),
        )
    return projects


def _check_cycles(projects: dict[str, ProjectConfig]) -> list[str]:
    """Check for circular dependencies via DFS."""
    errors: list[str] = []
    visited: set[str] = set()
    in_stack: set[str] = set()

    def dfs(name: str) -> bool:
        if name in in_stack:
            return True
        if name in visited:
            return False
        visited.add(name)
        in_stack.add(name)
        proj = projects.get(name)
        if proj:
            for dep in proj.consumes:
                if dep in projects and dfs(dep):
                    return True
        in_stack.discard(name)
        return False

    for name in projects:
        visited.clear()
        in_stack.clear()
        if dfs(name):
            errors.append(f"Circular dependency detected involving '{name}'")

    return errors
