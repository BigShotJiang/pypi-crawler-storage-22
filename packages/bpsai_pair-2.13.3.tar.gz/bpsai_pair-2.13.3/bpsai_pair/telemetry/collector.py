"""Telemetry collector for automatic data collection on task completion.

This module integrates all telemetry components to collect metrics
when tasks are completed, applying privacy filtering and audit logging.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from bpsai_pair.telemetry.audit import AuditLog
from bpsai_pair.telemetry.config import TelemetryConfig
from bpsai_pair.telemetry.parser import ClaudeSessionParser
from bpsai_pair.telemetry.privacy import PrivacyFilter
from bpsai_pair.telemetry.schema import (
    Outcome,
    TelemetryRecord,
    TokenUsage,
)
from bpsai_pair.telemetry.store import TelemetryStore

logger = logging.getLogger(__name__)

SNAPSHOT_FILENAME = "session_snapshot.json"


class TelemetryCollector:
    """Collects and stores telemetry data for completed tasks.

    Integrates:
    - ClaudeSessionParser: Find and parse session data
    - PrivacyFilter: Apply privacy level filtering
    - TelemetryStore: Persist telemetry records
    - AuditLog: Create tamper-evident audit entries
    """

    def __init__(
        self, project_root: Path, config: TelemetryConfig | None = None
    ) -> None:
        """Initialize the telemetry collector.

        Args:
            project_root: Path to the project root directory
            config: Optional telemetry configuration (loads default if not provided)
        """
        self.project_root = project_root
        self.config = config or TelemetryConfig.load(project_root)

        self.parser = ClaudeSessionParser()
        self.store = TelemetryStore(project_root)
        self._telemetry_dir = project_root / ".paircoder" / "telemetry"
        self.audit = AuditLog(self._telemetry_dir / "audit.jsonl")
        self.filter = PrivacyFilter(self.config.privacy_level)
        self._snapshot = self._load_snapshot()

    def collect_for_task(
        self,
        task_id: str,
        task_type: str,
        outcome: Outcome,
    ) -> TelemetryRecord | None:
        """Collect telemetry for a completed task.

        This method:
        1. Checks if collection is enabled
        2. Finds the most recent session for the project
        3. Parses session data to extract metrics
        4. Creates a TelemetryRecord
        5. Applies privacy filtering
        6. Stores the record
        7. Updates the audit log

        All errors are caught and logged - this method never raises
        to ensure task completion is not blocked by telemetry failures.

        Args:
            task_id: The ID of the completed task
            task_type: The type of task (feature, bugfix, chore, etc.)
            outcome: The outcome of the task (SUCCESS, FAIL, PARTIAL)

        Returns:
            The stored TelemetryRecord, or None if collection is disabled,
            privacy is OFF, no session found, or an error occurs.
        """
        try:
            return self._collect_internal(task_id, task_type, outcome)
        except Exception as e:
            logger.warning("Telemetry collection failed (non-blocking): %s", e)
            return None

    def _collect_internal(
        self,
        task_id: str,
        task_type: str,
        outcome: Outcome,
    ) -> TelemetryRecord | None:
        """Internal collection logic that may raise exceptions."""
        # Check if telemetry is enabled
        if not self.config.enabled:
            logger.debug("Telemetry collection disabled")
            return None

        # Find sessions for this project
        session_metrics = self._get_session_metrics()
        if session_metrics is None:
            logger.debug("No session found for project")
            return None

        # Create telemetry record with delta computation
        record = self._create_record(task_id, task_type, outcome, session_metrics)

        # Save snapshot of current cumulative values for next delta
        self._save_snapshot(session_metrics)

        # Apply privacy filtering
        filtered_record = self.filter.filter(record)
        if filtered_record is None:
            return None

        # Store the record
        self.store.append(filtered_record)

        # Create audit entry
        self.audit.append(
            "record_added",
            {
                "task_id": filtered_record.task_id,
                "task_type": filtered_record.task_type,
                "outcome": filtered_record.outcome.value,
            },
        )

        return filtered_record

    def _get_session_metrics(self):
        """Find and parse the most recent session for this project."""
        project_path = str(self.project_root.resolve())
        sessions = self.parser.find_sessions(project_path)

        if not sessions:
            return None

        # Use the most recent session (first in sorted list)
        most_recent = sessions[0]
        entries = self.parser.parse_session(most_recent)

        if not entries:
            return None

        return self.parser.extract_metrics(entries)

    def _create_record(
        self,
        task_id: str,
        task_type: str,
        outcome: Outcome,
        metrics,
    ) -> TelemetryRecord:
        """Create a TelemetryRecord from session metrics (delta-aware)."""
        repo = self._extract_repo_name(metrics.project_path)
        input_tokens, output_tokens, duration, interventions, compactions = (
            self._compute_deltas(metrics)
        )

        tokens = TokenUsage(input=input_tokens, output=output_tokens)

        return TelemetryRecord(
            task_id=task_id,
            task_type=task_type,
            repo=repo,
            model=metrics.model or "unknown",
            tokens=tokens,
            duration_seconds=int(duration),
            human_interventions=interventions,
            compactions=compactions,
            outcome=outcome,
            timestamp=datetime.now(timezone.utc),
            privacy_level=self.config.privacy_level,
        )

    def _compute_deltas(self, metrics) -> tuple[int, int, float, int, int]:
        """Compute per-task deltas from cumulative session metrics.

        Returns (input_tokens, output_tokens, duration, interventions, compactions).
        If no snapshot or session changed, returns raw values.
        """
        compactions = getattr(metrics, "compactions", 0)
        snap = self._snapshot
        if not snap or snap.get("session_id") != metrics.session_id:
            return (
                metrics.total_input_tokens,
                metrics.total_output_tokens,
                metrics.duration_seconds,
                metrics.message_counts.user,
                compactions,
            )

        return (
            max(0, metrics.total_input_tokens - snap.get("total_input_tokens", 0)),
            max(0, metrics.total_output_tokens - snap.get("total_output_tokens", 0)),
            max(0, metrics.duration_seconds - snap.get("duration_seconds", 0)),
            max(0, metrics.message_counts.user - snap.get("user_messages", 0)),
            max(0, compactions - snap.get("compactions", 0)),
        )

    def _load_snapshot(self) -> dict[str, Any] | None:
        """Load the session snapshot from disk."""
        path = self._telemetry_dir / SNAPSHOT_FILENAME
        try:
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if "session_id" in data and "total_input_tokens" in data:
                    return data
        except Exception:
            logger.debug("Could not load session snapshot, starting fresh")
        return None

    def _save_snapshot(self, metrics) -> None:
        """Save the current cumulative metrics as a snapshot for next delta."""
        self._telemetry_dir.mkdir(parents=True, exist_ok=True)
        snapshot = {
            "session_id": metrics.session_id,
            "total_input_tokens": metrics.total_input_tokens,
            "total_output_tokens": metrics.total_output_tokens,
            "duration_seconds": metrics.duration_seconds,
            "user_messages": metrics.message_counts.user,
            "compactions": getattr(metrics, "compactions", 0),
        }
        path = self._telemetry_dir / SNAPSHOT_FILENAME
        try:
            path.write_text(json.dumps(snapshot), encoding="utf-8")
            self._snapshot = snapshot
        except Exception:
            logger.debug("Could not save session snapshot")

    def _extract_repo_name(self, project_path: str | None) -> str:
        """Extract repository name from project path."""
        if not project_path:
            return self.project_root.name

        path = Path(project_path)
        return path.name or self.project_root.name
