"""Execute and display helpers for the upgrade command.

Extracted from upgrade_helpers.py for architecture compliance.
Contains: execute sub-functions, config defaults, and display helpers.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING
import shutil

from rich.console import Console

if TYPE_CHECKING:
    from .upgrade import UpgradePlan


# ---------------------------------------------------------------------------
# Execute sub-functions
# ---------------------------------------------------------------------------


def _execute_skills(
    results: dict,
    project_root: Path,
    bundled_skills: dict[str, dict],
    plan: UpgradePlan,
) -> None:
    """Copy all files per skill (file-by-file to preserve project-only files)."""
    for skill_name in plan.skills_to_add:
        if skill_name in bundled_skills:
            _copy_skill_files(project_root, skill_name, bundled_skills[skill_name])
            results["skills_added"] += 1

    for skill_name in plan.skills_to_update:
        if skill_name in bundled_skills:
            _copy_skill_files(project_root, skill_name, bundled_skills[skill_name])
            results["skills_updated"] += 1


def _copy_skill_files(
    project_root: Path,
    skill_name: str,
    skill_data: dict,
) -> None:
    """Copy individual skill files without removing project-only files."""
    dst_dir = project_root / ".claude" / "skills" / skill_name
    for rel_path, abs_path in skill_data["files"]:
        dst = dst_dir / rel_path
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(abs_path, dst)


def _execute_agents(
    results: dict,
    project_root: Path,
    bundled_agents: dict,
    plan: UpgradePlan,
) -> None:
    """Copy agent files."""
    dst_dir = project_root / ".claude" / "agents"
    for agent_name in plan.agents_to_add:
        if agent_name in bundled_agents:
            dst_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(bundled_agents[agent_name], dst_dir / f"{agent_name}.md")
            results["agents_added"] += 1

    for agent_name in plan.agents_to_update:
        if agent_name in bundled_agents:
            dst_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(bundled_agents[agent_name], dst_dir / f"{agent_name}.md")
            results["agents_updated"] += 1


def _execute_commands(
    results: dict,
    project_root: Path,
    bundled_commands: dict,
    plan: UpgradePlan,
) -> None:
    """Copy command files."""
    dst_dir = project_root / ".claude" / "commands"
    for cmd_name in plan.commands_to_add:
        if cmd_name in bundled_commands:
            dst_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(bundled_commands[cmd_name], dst_dir / f"{cmd_name}.md")
            results["commands_added"] += 1

    for cmd_name in plan.commands_to_update:
        if cmd_name in bundled_commands:
            dst_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(bundled_commands[cmd_name], dst_dir / f"{cmd_name}.md")
            results["commands_updated"] += 1


def _execute_docs(
    results: dict,
    project_root: Path,
    template: Path,
    plan: UpgradePlan,
) -> None:
    """Copy doc files."""
    for doc_rel in plan.docs_to_update:
        src = template / doc_rel
        dst = project_root / doc_rel
        if src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            results["docs_updated"] += 1


_CONFIG_DEFAULTS = {
    "trello": {
        "enabled": False,
        "board_id": "",
    },
    "hooks": {
        "enabled": True,
        "on_task_start": ["start_timer", "sync_trello", "update_state"],
        "on_task_complete": [
            "arch_check_modified",
            "contract_break_check",
            "stop_timer",
            "record_metrics",
            "workspace_impact_scan",
            "telemetry_snapshot",
            "feedback_calibrate",
            "sync_trello",
            "update_state",
            "check_unblocked",
        ],
        "on_task_block": ["sync_trello", "update_state"],
    },
    "estimation": {
        "complexity_to_hours": {
            "xs": {"range": [0, 15], "hours": [0.5, 1.0, 2.0]},
            "s": {"range": [16, 30], "hours": [1.0, 2.0, 4.0]},
            "m": {"range": [31, 50], "hours": [2.0, 4.0, 8.0]},
            "l": {"range": [51, 75], "hours": [4.0, 8.0, 16.0]},
            "xl": {"range": [76, 100], "hours": [8.0, 16.0, 32.0]},
        }
    },
    "metrics": {
        "enabled": True,
        "store_path": ".paircoder/history/metrics.jsonl",
    },
}


def _execute_config(
    results: dict,
    project_root: Path,
    plan: UpgradePlan,
    console: Console,
) -> None:
    """Add missing config sections (merge, don't overwrite)."""
    if not plan.config_sections_to_add:
        return

    config_path = project_root / ".paircoder" / "config.yaml"
    if not config_path.exists():
        return

    try:
        import yaml
        config_data = yaml.safe_load(
            config_path.read_text(encoding="utf-8")
        ) or {}

        for section in plan.config_sections_to_add:
            if section in _CONFIG_DEFAULTS:
                config_data[section] = _CONFIG_DEFAULTS[section]
                results["config_sections_added"] += 1

        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(config_data, f, default_flow_style=False, sort_keys=False)
    except Exception as e:
        console.print(f"[yellow]Warning: Could not update config: {e}[/yellow]")


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------


def print_upgrade_plan(plan: UpgradePlan, console: Console) -> None:
    """Print the Rich output for the upgrade plan."""
    console.print("\n[bold]Upgrade Plan:[/bold]\n")

    _print_list(console, "Skills to add", plan.skills_to_add, "+")
    _print_list(console, "Skills to update", plan.skills_to_update, "~")
    _print_list(console, "Agents to add", plan.agents_to_add, "+")
    _print_list(console, "Agents to update", plan.agents_to_update, "~")
    _print_list(console, "Commands to add", plan.commands_to_add, "+")
    _print_list(console, "Commands to update", plan.commands_to_update, "~")
    _print_list(console, "Docs to update", plan.docs_to_update, "~")
    _print_list(console, "Config sections to add", plan.config_sections_to_add, "+")

    if plan.warnings:
        console.print("\n  [yellow]Warnings:[/yellow]")
        for w in plan.warnings:
            console.print(f"    ! {w}")


def _print_list(
    console: Console,
    label: str,
    items: list,
    prefix: str,
) -> None:
    """Print a labeled list of items if non-empty."""
    if not items:
        return
    console.print(f"  [cyan]{label}:[/cyan]")
    for item in items:
        console.print(f"    {prefix} {item}")


def print_upgrade_summary(
    results: dict,
    do_skills: bool,
    do_agents: bool,
    do_commands: bool,
    do_docs: bool,
    do_config: bool,
    console: Console,
) -> None:
    """Print the Rich output for upgrade results."""
    summary_parts: list[str] = []
    if do_skills and (results["skills_added"] or results["skills_updated"]):
        summary_parts.append(
            f"{results['skills_added']} skills added, "
            f"{results['skills_updated']} updated"
        )
    if do_agents and (results["agents_added"] or results["agents_updated"]):
        summary_parts.append(
            f"{results['agents_added']} agents added, "
            f"{results['agents_updated']} updated"
        )
    if do_commands and (results["commands_added"] or results["commands_updated"]):
        summary_parts.append(
            f"{results['commands_added']} commands added, "
            f"{results['commands_updated']} updated"
        )
    if do_docs and results["docs_updated"]:
        summary_parts.append(f"{results['docs_updated']} docs updated")
    if do_config and results["config_sections_added"]:
        summary_parts.append(
            f"{results['config_sections_added']} config sections added"
        )

    if summary_parts:
        console.print(f"  {', '.join(summary_parts)}")
