"""Enrichment hook handlers (fire-and-forget, never block).

Enrichment hooks run during task lifecycle events to capture
telemetry, run calibration, and scan workspace impact. They
never set blocked=True — failures are logged and swallowed.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from bpsai_pair.core.hooks import HookContext

logger = logging.getLogger(__name__)


def workspace_impact_scan(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Scan workspace for cross-repo impact of recent changes.

    Non-blocking: logs results but never blocks completion.
    """
    root = project_root or _find_project_root()
    workspace = _load_workspace(root) if root else None
    if workspace is None:
        return {"scanned": False, "reason": "No workspace configured"}

    merge_base = _get_merge_base(root)
    if merge_base is None:
        return {"scanned": False, "reason": "Could not determine merge base"}

    try:
        all_changes = _gather_workspace_changes(workspace, merge_base)
        if not all_changes:
            return {"scanned": True, "changes": 0}

        from bpsai_pair.workspace.impact import ImpactAnalyzer

        report = ImpactAnalyzer(workspace).analyze(all_changes)
        logger.info(
            "Workspace impact scan: %d change(s), severity=%s, affected=%s",
            len(all_changes), report.severity, report.affected_repos,
        )
        return {
            "scanned": True,
            "changes": len(all_changes),
            "severity": report.severity,
            "affected_repos": report.affected_repos,
        }
    except Exception as e:
        logger.warning("Workspace impact scan failed: %s", e)
        return {"scanned": False, "reason": str(e)}


def telemetry_snapshot(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Capture a telemetry usage snapshot on task completion.

    Non-blocking: logs results but never blocks completion.
    """
    root = project_root or _find_project_root()
    snapshot = _build_snapshot(root) if root else None

    if snapshot is None:
        return {"captured": False, "reason": "No telemetry data available"}

    try:
        data = snapshot.to_dict()
        logger.info(
            "Telemetry snapshot: %d tokens, %d sessions",
            data.get("total_tokens", 0), data.get("sessions", 0),
        )
        return {
            "captured": True,
            "total_tokens": data.get("total_tokens", 0),
            "sessions": data.get("sessions", 0),
        }
    except Exception as e:
        logger.warning("Telemetry snapshot failed: %s", e)
        return {"captured": False, "reason": str(e)}


def feedback_calibrate(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Run feedback calibration check on task completion.

    Non-blocking: logs accuracy metrics but never blocks.
    """
    root = project_root or _find_project_root()
    engine = _get_calibration_engine(root) if root else None

    if engine is None:
        return {"calibrated": False, "reason": "Calibration engine not available"}

    try:
        if not engine.is_calibrated:
            calibration = engine.calibrate()
        else:
            calibration = engine.get_calibration()

        logger.info(
            "Feedback calibration: token_accuracy=%.2f, duration_accuracy=%.2f",
            getattr(calibration, "token_accuracy", 0),
            getattr(calibration, "duration_accuracy", 0),
        )
        return {
            "calibrated": True,
            "token_accuracy": getattr(calibration, "token_accuracy", None),
            "duration_accuracy": getattr(calibration, "duration_accuracy", None),
        }
    except Exception as e:
        logger.warning("Feedback calibration failed: %s", e)
        return {"calibrated": False, "reason": str(e)}


# ---- Helpers ----


def _gather_workspace_changes(workspace: Any, merge_base: str) -> list[Any]:
    """Gather contract changes across all workspace projects."""
    from bpsai_pair.workspace.contracts import ContractDetector

    detector = ContractDetector(workspace)
    all_changes: list[Any] = []
    for name in workspace.get_project_names():
        project = workspace.get_project(name)
        if project is None:
            continue
        repo_path = workspace.root_path / project.path
        if not repo_path.exists():
            continue
        all_changes.extend(
            detector.detect_changes(repo_path, merge_base, repo_name=name)
        )
    return all_changes


def _find_project_root() -> Path | None:
    """Find the project root by searching for .paircoder directory."""
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        if (parent / ".paircoder").is_dir():
            return parent
    return None


def _load_workspace(project_root: Path) -> Any:
    """Load workspace config if it exists."""
    try:
        from bpsai_pair.workspace.parser import WorkspaceParser

        parser = WorkspaceParser()
        config_path = parser.find_workspace_config(project_root)
        if config_path is None:
            return None
        return parser.parse(config_path)
    except (ImportError, FileNotFoundError, ValueError):
        return None


def _get_merge_base(project_root: Path) -> str | None:
    """Get the merge base commit for the current branch."""
    import subprocess

    try:
        default_branch = _detect_default_branch(project_root)
        result = subprocess.run(
            ["git", "merge-base", "HEAD", default_branch],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def _detect_default_branch(project_root: Path) -> str:
    """Detect the default branch (main/master/trunk) for a repo."""
    import subprocess

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "origin/HEAD"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            ref = result.stdout.strip()
            return ref.split("/", 1)[-1] if "/" in ref else ref
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return "main"


def _build_snapshot(project_root: Path) -> Any:
    """Build a usage snapshot, returning None on failure."""
    try:
        from bpsai_pair.telemetry.config import TelemetryConfig
        from bpsai_pair.telemetry.snapshot import build_usage_snapshot

        config = TelemetryConfig.load(project_root)
        return build_usage_snapshot(project_root, config.privacy_level)
    except Exception:
        return None


def _get_calibration_engine(project_root: Path) -> Any:
    """Get a CalibrationEngine, returning None on failure."""
    try:
        from bpsai_pair.feedback.calibration import CalibrationEngine

        return CalibrationEngine(project_root)
    except Exception:
        return None
