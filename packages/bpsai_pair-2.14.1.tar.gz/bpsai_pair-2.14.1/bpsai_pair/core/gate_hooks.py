"""Gate hook handlers that can block task completion.

Gate hooks run during on_task_complete and return blocked=True
when violations are found, preventing the task from completing
until issues are resolved.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Any

from bpsai_pair.core.hooks import HookContext

logger = logging.getLogger(__name__)


def arch_check_modified(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Check architecture violations on files changed in this task.

    Returns blocked=True if any error-level violations are found.
    Warnings are reported but do not block.
    """
    root = project_root or _find_project_root()
    if root is None:
        return {"blocked": False, "reason": "Skipped: no project root"}

    changed = _get_changed_py_files(root)
    if not changed:
        return {"blocked": False, "files_checked": 0, "reason": "No Python files changed"}

    try:
        from bpsai_pair.core.enforcement_checker import ArchitectureEnforcer

        enforcer = ArchitectureEnforcer.from_config(root)
    except (ImportError, Exception) as e:
        logger.warning("Could not load ArchitectureEnforcer: %s", e)
        return {"blocked": False, "reason": f"Skipped: {e}"}

    errors, warnings, details = _run_arch_checks(enforcer, changed)
    return _build_arch_result(ctx, errors, warnings, details, len(changed))


def contract_break_check(
    ctx: HookContext,
    *,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Check for cross-repo contract breaks in changed files.

    Returns blocked=True if high-severity contract changes are
    detected that affect consumer repos.
    """
    root = project_root or _find_project_root()
    if root is None:
        return {"blocked": False, "reason": "No workspace configured"}

    workspace = _load_workspace(root)
    if workspace is None:
        return {"blocked": False, "reason": "No workspace configured"}

    merge_base = _get_merge_base(root)
    if merge_base is None:
        return {"blocked": False, "reason": "Skipped: could not determine merge base"}

    try:
        from bpsai_pair.workspace.contracts import ContractDetector
        from bpsai_pair.workspace.impact import ImpactAnalyzer

        detector = ContractDetector(workspace)
        analyzer = ImpactAnalyzer(workspace)
    except ImportError as e:
        return {"blocked": False, "reason": f"Skipped: {e}"}

    all_changes = _gather_contract_changes(detector, workspace, merge_base)
    if not all_changes:
        return {"blocked": False, "changes": 0}

    report = analyzer.analyze(all_changes)
    return _build_contract_result(ctx, report, len(all_changes))


# ---- Internal helpers ----


def _run_arch_checks(
    enforcer: Any, changed: list[Path],
) -> tuple[int, int, list[str]]:
    """Run architecture checks on changed files, return (errors, warnings, details)."""
    errors = 0
    warnings = 0
    details: list[str] = []
    for filepath in changed:
        if not filepath.exists():
            continue
        for v in enforcer.check_file(filepath):
            if getattr(v, "severity", "error") == "warning":
                warnings += 1
            else:
                errors += 1
                details.append(f"{filepath.name}: {v}")
    return errors, warnings, details


def _build_arch_result(
    ctx: HookContext, errors: int, warnings: int,
    details: list[str], files_checked: int,
) -> dict[str, Any]:
    """Build the result dict for arch_check_modified."""
    result: dict[str, Any] = {
        "files_checked": files_checked,
        "error_count": errors,
        "warning_count": warnings,
    }
    if errors > 0:
        result["blocked"] = True
        result["violations"] = details[:10]
        logger.warning(
            "Architecture gate blocked task %s: %d error(s)",
            ctx.task_id, errors,
        )
    else:
        result["blocked"] = False
    return result


def _gather_contract_changes(
    detector: Any, workspace: Any, merge_base: str,
) -> list[Any]:
    """Gather contract changes across all workspace projects."""
    all_changes: list[Any] = []
    for name in workspace.get_project_names():
        project = workspace.get_project(name)
        if project is None:
            continue
        repo_path = workspace.root_path / project.path
        if not repo_path.exists():
            continue
        changes = detector.detect_changes(repo_path, merge_base, repo_name=name)
        all_changes.extend(changes)
    return all_changes


def _build_contract_result(
    ctx: HookContext, report: Any, change_count: int,
) -> dict[str, Any]:
    """Build the result dict for contract_break_check."""
    result: dict[str, Any] = {
        "changes": change_count,
        "severity": report.severity,
        "affected_repos": report.affected_repos,
        "actions": report.recommended_actions[:5],
    }
    if report.severity == "high" and report.affected_repos:
        result["blocked"] = True
        logger.warning(
            "Contract gate blocked task %s: %d change(s) affecting %s",
            ctx.task_id, change_count, report.affected_repos,
        )
    else:
        result["blocked"] = False
    return result


# ---- Shared helpers ----


def _get_changed_py_files(project_root: Path) -> list[Path]:
    """Get Python files changed in the current worktree.

    Checks both uncommitted tracked changes (staged + unstaged)
    and new untracked .py files, so violations are caught before commit.
    """
    try:
        # Uncommitted tracked changes vs HEAD
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=15,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return []
    if result.returncode != 0:
        return []

    paths: set[Path] = set()
    for line in result.stdout.strip().split("\n"):
        if line.strip().endswith(".py"):
            paths.add(project_root / line.strip())

    # Also include new untracked .py files
    try:
        untracked = subprocess.run(
            ["git", "ls-files", "--others", "--exclude-standard", "*.py"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=15,
        )
        if untracked.returncode == 0:
            for line in untracked.stdout.strip().split("\n"):
                if line.strip().endswith(".py"):
                    paths.add(project_root / line.strip())
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return list(paths)


def _find_project_root() -> Path | None:
    """Find the project root by searching for .paircoder directory."""
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        if (parent / ".paircoder").is_dir():
            return parent
    return None


def _load_workspace(project_root: Path) -> Any:
    """Load workspace config if it exists."""
    try:
        from bpsai_pair.workspace.parser import WorkspaceParser

        parser = WorkspaceParser()
        config_path = parser.find_workspace_config(project_root)
        if config_path is None:
            return None
        return parser.parse(config_path)
    except (ImportError, FileNotFoundError, ValueError) as e:
        logger.debug("Could not load workspace: %s", e)
        return None


def _get_merge_base(project_root: Path) -> str | None:
    """Get the merge base commit for the current branch."""
    try:
        default_branch = _detect_default_branch(project_root)
        result = subprocess.run(
            ["git", "merge-base", "HEAD", default_branch],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def _detect_default_branch(project_root: Path) -> str:
    """Detect the default branch (main/master/trunk) for a repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "origin/HEAD"],
            cwd=str(project_root),
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            # Returns "origin/main" → extract "main"
            ref = result.stdout.strip()
            return ref.split("/", 1)[-1] if "/" in ref else ref
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return "main"
