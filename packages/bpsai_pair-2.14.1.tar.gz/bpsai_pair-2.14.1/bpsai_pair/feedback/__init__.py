"""Feedback module for calibration and estimation from telemetry data.

This module processes historical telemetry into actionable estimates,
enabling data-driven task sizing and model recommendations.
"""

from bpsai_pair.feedback.anomaly import Anomaly, AnomalyDetector, AnomalyType
from bpsai_pair.feedback.calibration import CalibrationEngine
from bpsai_pair.feedback.classifier import TASK_TYPES, TaskTypeClassifier
from bpsai_pair.feedback.overhead import OverheadMetrics, OverheadTracker
from bpsai_pair.feedback.schema import CalibrationData, EffortLevel, TaskTypeStats
from bpsai_pair.feedback.scoring import (
    Recommendation,
    ScoringFactor,
    ValueExtractionScorer,
    ValueScore,
)
from bpsai_pair.feedback.service import FeedbackService

__all__ = [
    "Anomaly",
    "AnomalyDetector",
    "AnomalyType",
    "CalibrationData",
    "CalibrationEngine",
    "EffortLevel",
    "FeedbackService",
    "OverheadMetrics",
    "OverheadTracker",
    "TASK_TYPES",
    "TaskTypeClassifier",
    "Recommendation",
    "ScoringFactor",
    "TaskTypeStats",
    "ValueExtractionScorer",
    "ValueScore",
]
