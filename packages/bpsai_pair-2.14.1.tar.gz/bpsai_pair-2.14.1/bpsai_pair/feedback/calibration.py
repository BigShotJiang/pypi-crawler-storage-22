"""Calibration engine for processing telemetry into actionable estimates.

Transforms raw telemetry records into statistical coefficients that
enable data-driven task sizing and model recommendations.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from bpsai_pair.feedback.schema import CalibrationData, TaskTypeStats
from bpsai_pair.feedback.stats import mean, percentile, recommend_model, std_dev
from bpsai_pair.telemetry.schema import Outcome, TelemetryRecord
from bpsai_pair.telemetry.store import TelemetryStore

logger = logging.getLogger(__name__)

# Cache staleness threshold
_CACHE_MAX_AGE = timedelta(hours=24)

# Default estimates when no data exists
_DEFAULT_AVG_TOKENS = 30_000.0
_DEFAULT_STD_DEV = 10_000.0
_DEFAULT_P80_TOKENS = 40_000.0
_DEFAULT_AVG_DURATION_SECONDS = 2700.0
_DEFAULT_MODEL = "sonnet"


class CalibrationEngine:
    """Processes telemetry data into calibration estimates.

    Usage:
        engine = CalibrationEngine(project_root)
        engine.calibrate()
        estimate = engine.estimate_tokens("feature")
        # {"avg": 48200, "p80": 58000, "std_dev": 5000, "recommended_model": "sonnet"}
    """

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root
        self.store = TelemetryStore(project_root)
        self.cache_path = (
            project_root / ".paircoder" / "feedback" / "calibration.json"
        )
        self._calibration: CalibrationData | None = None

    def calibrate(self, min_samples: int = 1) -> CalibrationData:
        """Process all telemetry into calibration data.

        Args:
            min_samples: Minimum records per task type to include.

        Returns:
            CalibrationData with per-type statistics.
        """
        records = self.store.query(limit=10_000)
        now = datetime.now(timezone.utc)

        if not records:
            self._calibration = CalibrationData(
                task_types={}, last_calibrated=now, total_records=0
            )
            self._save_cache(self._calibration)
            return self._calibration

        # Group records by task_type
        groups: dict[str, list[TelemetryRecord]] = {}
        for r in records:
            groups.setdefault(r.task_type, []).append(r)

        task_types: dict[str, TaskTypeStats] = {}
        for task_type, group in groups.items():
            if len(group) < min_samples:
                continue
            task_types[task_type] = _compute_stats(task_type, group)

        self._calibration = CalibrationData(
            task_types=task_types,
            last_calibrated=now,
            total_records=len(records),
        )
        self._save_cache(self._calibration)
        return self._calibration

    def estimate_tokens(self, task_type: str) -> dict[str, Any]:
        """Get token estimates for a task type.

        Returns:
            Dict with avg, p80, std_dev, recommended_model.
        """
        stats = self._get_stats(task_type)
        return {
            "avg": stats.avg_tokens,
            "p80": stats.p80_tokens,
            "std_dev": stats.std_dev,
            "recommended_model": stats.recommended_model,
        }

    def estimate_duration(self, task_type: str) -> dict[str, Any]:
        """Get duration estimates for a task type.

        Returns:
            Dict with avg_minutes and p80_minutes.
        """
        stats = self._get_stats(task_type)
        records = self.store.query(task_type=task_type, limit=10_000)
        durations = [float(r.duration_seconds) for r in records]

        if durations:
            p80_seconds = percentile(durations, 80)
        else:
            p80_seconds = stats.avg_duration_seconds * 1.3

        return {
            "avg_minutes": stats.avg_duration_seconds / 60.0,
            "p80_minutes": p80_seconds / 60.0,
        }

    def get_model_recommendation(
        self, task_type: str, complexity: str = "medium"
    ) -> str:
        """Get recommended model based on task type and complexity.

        Returns:
            Model name: "haiku", "sonnet", or "opus".
        """
        return self._get_stats(task_type).recommended_model

    def estimate_effort(
        self, task_type: str, complexity: int | None = None
    ) -> str:
        """Get recommended effort level for a task type.

        Uses complexity override if provided, otherwise maps by task type.

        Args:
            task_type: The type of task.
            complexity: Optional complexity score (0-100).

        Returns:
            Effort string: "low", "medium", or "high".
        """
        if complexity is not None:
            if complexity < 20:
                return "low"
            if complexity <= 40:
                return "medium"
            return "high"
        return _effort_for_type(task_type)

    def check_budget_fit(
        self, estimated_tokens: int, target_utilization: float = 0.8
    ) -> dict[str, Any]:
        """Check if estimated tokens fit within budget target.

        Args:
            estimated_tokens: Estimated token count for the task.
            target_utilization: Budget utilization target (0.0-1.0).

        Returns:
            Dict with fits_budget bool and utilization float.
        """
        cal = self.get_calibration()
        if cal.total_records == 0:
            budget = 200_000
        else:
            all_tokens = [s.avg_tokens for s in cal.task_types.values()]
            budget = max(all_tokens) * 3 if all_tokens else 200_000

        effective_budget = budget * target_utilization
        utilization = estimated_tokens / budget if budget > 0 else 0.0

        return {
            "fits_budget": estimated_tokens <= effective_budget,
            "utilization": round(utilization, 3),
            "budget": budget,
            "effective_budget": effective_budget,
        }

    # -- Cache management --

    def _save_cache(self, data: CalibrationData) -> None:
        """Save calibration data to JSON cache."""
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.cache_path.write_text(
            json.dumps(data.to_dict(), indent=2), encoding="utf-8"
        )

    def _load_cache(self) -> CalibrationData | None:
        """Load calibration data from JSON cache."""
        if not self.cache_path.exists():
            return None
        try:
            raw = json.loads(self.cache_path.read_text(encoding="utf-8"))
            return CalibrationData.from_dict(raw)
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            logger.debug("Failed to load calibration cache: %s", e)
            return None

    def is_cache_stale(self) -> bool:
        """Check if cache is stale (>24h old or missing)."""
        cached = self._load_cache()
        if cached is None:
            return True
        age = datetime.now(timezone.utc) - cached.last_calibrated
        return age > _CACHE_MAX_AGE

    # -- Internal helpers --

    @property
    def is_calibrated(self) -> bool:
        """Check if calibration data is available (in memory or cache)."""
        if self._calibration is not None:
            return True
        return self._load_cache() is not None

    def get_calibration(self) -> CalibrationData:
        """Get current calibration, loading from cache if needed."""
        if self._calibration is not None:
            return self._calibration
        cached = self._load_cache()
        if cached is not None:
            self._calibration = cached
            return cached
        return self.calibrate()

    def _get_stats(self, task_type: str) -> TaskTypeStats:
        """Get stats for a task type, returning defaults if missing."""
        cal = self.get_calibration()
        if task_type in cal.task_types:
            return cal.task_types[task_type]
        return TaskTypeStats(
            task_type=task_type,
            sample_count=0,
            avg_tokens=_DEFAULT_AVG_TOKENS,
            std_dev=_DEFAULT_STD_DEV,
            p80_tokens=_DEFAULT_P80_TOKENS,
            avg_duration_seconds=_DEFAULT_AVG_DURATION_SECONDS,
            success_rate=0.0,
            recommended_model=_DEFAULT_MODEL,
        )


_LOW_EFFORT_TYPES = {"docs_page", "config", "schema"}
_MEDIUM_EFFORT_TYPES = {"cli_command", "test_suite"}


def _effort_for_type(task_type: str) -> str:
    """Map task type to default effort level."""
    if task_type in _LOW_EFFORT_TYPES:
        return "low"
    if task_type in _MEDIUM_EFFORT_TYPES:
        return "medium"
    return "high"


def _compute_stats(
    task_type: str, records: list[TelemetryRecord]
) -> TaskTypeStats:
    """Compute statistical summary for a group of records."""
    tokens = [float(r.tokens.total) for r in records]
    durations = [float(r.duration_seconds) for r in records]
    successes = sum(1 for r in records if r.outcome == Outcome.SUCCESS)

    avg_tokens = mean(tokens)
    token_std = std_dev(tokens)
    p80_tokens = percentile(tokens, 80)
    avg_duration = mean(durations)
    success_rate = successes / len(records) if records else 0.0
    recommended = recommend_model(avg_tokens)

    return TaskTypeStats(
        task_type=task_type,
        sample_count=len(records),
        avg_tokens=avg_tokens,
        std_dev=token_std,
        p80_tokens=p80_tokens,
        avg_duration_seconds=avg_duration,
        success_rate=success_rate,
        recommended_model=recommended,
        recommended_effort=_effort_for_type(task_type),
    )
