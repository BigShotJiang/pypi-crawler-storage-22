"""Statistical helper functions for calibration calculations.

Provides mean, standard deviation, percentile, and model recommendation
logic used by the CalibrationEngine.
"""

from __future__ import annotations

import math

# Model recommendation thresholds (average total tokens)
HAIKU_THRESHOLD = 20_000
SONNET_THRESHOLD = 60_000


def mean(values: list[float]) -> float:
    """Calculate arithmetic mean."""
    if not values:
        return 0.0
    return sum(values) / len(values)


def std_dev(values: list[float]) -> float:
    """Calculate population standard deviation."""
    if len(values) < 2:
        return 0.0
    avg = mean(values)
    variance = sum((x - avg) ** 2 for x in values) / len(values)
    return math.sqrt(variance)


def percentile(values: list[float], pct: int) -> float:
    """Calculate percentile using linear interpolation."""
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    k = (pct / 100.0) * (len(sorted_vals) - 1)
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return sorted_vals[int(k)]
    return sorted_vals[f] * (c - k) + sorted_vals[c] * (k - f)


def recommend_model(avg_tokens: float) -> str:
    """Recommend model based on average token usage.

    - haiku: avg_tokens < 20K (simple docs/fixes)
    - sonnet: 20K-60K tokens (standard features)
    - opus: >60K tokens (complex refactors)
    """
    if avg_tokens < HAIKU_THRESHOLD:
        return "haiku"
    if avg_tokens < SONNET_THRESHOLD:
        return "sonnet"
    return "opus"
