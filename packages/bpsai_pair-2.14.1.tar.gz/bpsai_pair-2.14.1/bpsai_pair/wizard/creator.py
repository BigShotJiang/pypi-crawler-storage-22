"""Project creator for the setup wizard.

This module generates file previews, config previews, and creates
project files based on wizard session data.
"""

from __future__ import annotations

import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from bpsai_pair.init_bundled_cli import (
    _find_template_traversable,
    copytree_non_destructive,
)

try:
    from importlib.resources import as_file
except ImportError:
    from importlib_resources import as_file  # py<=3.8 fallback


# Files that will be created in .paircoder/
PREVIEW_FILES = [
    ".paircoder/",
    ".paircoder/config.yaml",
    ".paircoder/capabilities.yaml",
    ".paircoder/context/",
    ".paircoder/context/project.md",
    ".paircoder/context/state.md",
    ".paircoder/context/workflow.md",
    ".paircoder/security/",
    ".paircoder/security/sandbox.yaml",
    ".paircoder/security/allowlist.yaml",
    ".paircoder/plans/",
    ".paircoder/tasks/",
    ".claude/",
    ".claude/settings.json",
    ".claude/skills/",
    ".claude/commands/",
    ".claude/agents/",
    "CLAUDE.md",
]


class ProjectCreator:
    """Creates project files from wizard session data."""

    def __init__(
        self,
        project_data: dict[str, Any] | None = None,
        enforcement_data: dict[str, Any] | None = None,
        session_data: dict[str, Any] | None = None,
    ) -> None:
        if session_data is not None:
            self._session_data = session_data
            self.project = session_data.get("project", {})
            self.enforcement = session_data.get("enforcement", {})
        else:
            self._session_data = {
                "project": project_data or {},
                "enforcement": enforcement_data or {},
            }
            self.project = project_data or {}
            self.enforcement = enforcement_data or {}

    def preview_files(self) -> list[str]:
        """Return list of files that will be created."""
        return list(PREVIEW_FILES)

    def preview_config(self) -> str:
        """Return config.yaml content as a YAML string."""
        config = self._build_config()
        return yaml.dump(config, default_flow_style=False, sort_keys=False)

    def backup_existing(self, target_dir: Path) -> Path | None:
        """Backup existing config files if present."""
        config_file = target_dir / "config.yaml"
        if not config_file.exists():
            return None

        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        backup_dir = target_dir.parent / f".paircoder-backup-{timestamp}"
        shutil.copytree(target_dir, backup_dir)
        return backup_dir

    def create(self, target_dir: Path) -> bool:
        """Create all project files in the target directory."""
        target_dir.mkdir(parents=True, exist_ok=True)

        # Write config.yaml
        config_yaml = self.preview_config()
        (target_dir / "config.yaml").write_text(config_yaml, encoding="utf-8")

        # Scaffold files from bundled template FIRST
        # This copies capabilities.yaml, workflow.md, state.md from the full templates
        # We do this before writing any other files so copytree_non_destructive
        # can copy the complete templates
        self._scaffold_from_template(target_dir.parent)

        # Write context files that need dynamic content (project.md with project name)
        context_dir = target_dir / "context"
        context_dir.mkdir(exist_ok=True)
        self._write_project_md(context_dir)

        # Write .env.example if integrations are enabled
        self._write_env_example(target_dir.parent)

        return True

    def _build_config(self) -> dict[str, Any]:
        """Build the config.yaml dictionary using ConfigBuilder."""
        from bpsai_pair.wizard.config_builder import ConfigBuilder

        builder = ConfigBuilder(self._session_data)
        return builder.build()

    def _write_project_md(self, context_dir: Path) -> None:
        """Write project.md with dynamic project info.

        Note: capabilities.yaml, workflow.md, and state.md are copied from
        the bundled template via _scaffold_from_template() to ensure
        they contain the full content rather than minimal placeholders.

        project.md is always written/overwritten because it contains
        project-specific info (name, goal) that must be populated dynamically.
        """
        name = self.project.get("name", "Project")
        goal = self.project.get("goal", "")

        project_md = f"""# Project Context

## What Is This Project?

**Project:** {name}
**Primary Goal:** {goal}

## Repository Structure

```
project/
├── .paircoder/              # PairCoder system files
│   ├── config.yaml          # Project configuration
│   ├── capabilities.yaml    # LLM capability manifest
│   ├── context/             # Project memory (project.md, state.md, workflow.md)
│   ├── plans/               # Active plans
│   └── tasks/               # Task files by plan
├── .claude/                 # Claude Code integration
│   ├── agents/              # Custom agent definitions
│   ├── skills/              # Model-invoked skills
│   └── settings.json        # Hooks configuration
├── src/                     # Source code
├── tests/                   # Test files
└── docs/                    # Documentation
```

## Tech Stack

<!-- Update with your actual tech stack -->
- **Language:** TBD
- **Framework:** TBD
- **Database:** TBD
- **Testing:** TBD

## Key Constraints

| Constraint | Requirement |
|------------|-------------|
| **Test Coverage** | Minimum 80% coverage |
| **Dependencies** | Review required for new deps |
| **Secrets** | Never commit secrets or credentials |
| **Compatibility** | No breaking changes without major version |

## Architecture Principles

<!-- Update these to match your project's principles -->

1. **Simplicity First** — Start simple, add complexity only when needed
2. **Test-Driven** — Write tests before implementation
3. **Documentation** — Keep docs updated with code changes

## How to Work Here

1. Read `.paircoder/context/state.md` for current plan/task status
2. Check `.paircoder/capabilities.yaml` to understand available actions
3. Follow the active skill for structured work
4. Update `state.md` after completing significant work

## Key Files

| File | Purpose |
|------|---------|
| `.paircoder/config.yaml` | Project configuration |
| `.paircoder/capabilities.yaml` | What LLMs can do here |
| `.paircoder/context/state.md` | Current status and active work |
| `src/` | Source code |
| `tests/` | Test files |
"""
        (context_dir / "project.md").write_text(project_md, encoding="utf-8")

    def _scaffold_from_template(self, project_root: Path) -> int:
        """Copy bundled scaffold files (skills, agents, commands, etc.).

        Uses copytree_non_destructive so wizard-written files are preserved.
        Returns number of files copied, or 0 if template not found.
        """
        template_traversable = _find_template_traversable()
        if template_traversable is None:
            return 0

        try:
            with as_file(template_traversable) as template_root:
                return copytree_non_destructive(template_root, project_root)
        except Exception:
            return 0

    def _write_env_example(self, project_root: Path) -> None:
        """Write .env.example with secret placeholders."""
        lines: list[str] = []

        trello = self._session_data.get("trello", {})
        if trello.get("enabled") or trello.get("board_id"):
            lines.append("# Trello (required for trello sync)")
            lines.append("TRELLO_API_KEY=")
            lines.append("TRELLO_TOKEN=")
            lines.append("")

        github = self._session_data.get("github", {})
        if github.get("repo_url"):
            lines.append("# GitHub (required for auto-PR)")
            lines.append("GITHUB_TOKEN=")
            lines.append("")

        mcp = self._session_data.get("mcp", {})
        if mcp.get("enabled"):
            lines.append("# MCP Server")
            lines.append("MCP_SECRET=")
            lines.append("")

        if not lines:
            return

        env_path = project_root / ".env.example"
        env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
