"""Cross-repo orchestrator for intelligence-powered planning.

WorkspaceOrchestrator enables Navigator to use the feedback intelligence
system for cross-repo planning. It analyzes task scope across repos,
sizes tasks using calibration data, and assigns models and effort levels.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from bpsai_pair.workspace.task_push import push_task_files


@dataclass
class CrossRepoTask:
    """A task scoped to a specific repo in a cross-repo plan.

    Attributes:
        repo: Target repository name.
        task_id_prefix: ID prefix (e.g., 'CLI-T34').
        title: Task title/description.
        estimated_tokens: Estimated token usage.
        recommended_model: Model recommendation (haiku/sonnet/opus).
        effort_level: Effort level (low/medium/high).
        depends_on: Task IDs this task depends on.
    """

    repo: str
    task_id_prefix: str
    title: str
    estimated_tokens: int
    recommended_model: str
    effort_level: str
    depends_on: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "repo": self.repo,
            "task_id_prefix": self.task_id_prefix,
            "title": self.title,
            "estimated_tokens": self.estimated_tokens,
            "recommended_model": self.recommended_model,
            "effort_level": self.effort_level,
            "depends_on": self.depends_on,
        }


class WorkspaceOrchestrator:
    """Intelligence-powered cross-repo planning orchestrator.

    Uses FeedbackService to estimate tokens, assign models, and
    size tasks within budget constraints.

    Usage:
        orch = WorkspaceOrchestrator(workspace_config, feedback_service)
        scope = orch.analyze_scope("Add API endpoint and CLI command")
        tasks = orch.plan_tasks(scope)
        orch.assign_models(tasks)
        orch.assign_effort(tasks)
        orch.push_tasks(tasks)
    """

    def __init__(self, workspace: Any, feedback: Any) -> None:
        self.workspace = workspace
        self.feedback = feedback

    def analyze_scope(self, description: str) -> dict[str, list[str]]:
        """Determine impacted repos from a feature description.

        Scans the description for project name mentions and keywords,
        then includes consumers of any directly-impacted project.

        Returns:
            Dict mapping repo name to list of change descriptions.
        """
        if not description:
            return {}

        scope: dict[str, list[str]] = {}
        desc_lower = description.lower()

        for name in self.workspace.get_project_names():
            if name.lower() in desc_lower:
                scope[name] = [description]

        directly_impacted = list(scope.keys())
        for name in directly_impacted:
            project = self.workspace.get_project(name)
            if project and hasattr(project, "consumers"):
                for consumer in project.consumers:
                    if consumer not in scope:
                        scope[consumer] = [
                            f"Consumer of {name}: may need updates"
                        ]

        return scope

    def plan_tasks(
        self, scope: dict[str, list[str]]
    ) -> list[CrossRepoTask]:
        """Produce cross-repo task list with token estimates.

        Each scope entry becomes a CrossRepoTask. Consumer repos
        get dependencies on their provider's tasks.
        """
        if not scope:
            return []

        tasks: list[CrossRepoTask] = []
        for repo, changes in scope.items():
            prefix = f"{repo.upper()}-T34"
            for change in changes:
                estimate = self.feedback.estimate_tokens(change)
                tasks.append(CrossRepoTask(
                    repo=repo,
                    task_id_prefix=prefix,
                    title=change,
                    estimated_tokens=estimate.get(
                        "p80", estimate.get("avg", 5000)
                    ),
                    recommended_model=estimate.get(
                        "recommended_model", "sonnet"
                    ),
                    effort_level="medium",
                ))

        _set_dependencies(tasks, self.workspace)
        for task in tasks:
            self.feedback.check_budget_fit(task.estimated_tokens)
        return tasks

    def assign_models(self, tasks: list[CrossRepoTask]) -> None:
        """Assign recommended models using feedback intelligence."""
        for task in tasks:
            task.recommended_model = self.feedback.get_model_recommendation(
                task.title, task.effort_level
            )

    def assign_effort(self, tasks: list[CrossRepoTask]) -> None:
        """Assign effort levels using feedback intelligence."""
        for task in tasks:
            task.effort_level = self.feedback.get_effort_recommendation(
                task.title
            )

    def push_tasks(
        self,
        tasks: list[CrossRepoTask],
        *,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Write .task.md files to sibling repos.

        Delegates to task_push module for file operations.
        """
        return push_task_files(
            tasks, self.workspace, dry_run=dry_run
        )


def _set_dependencies(tasks: list[CrossRepoTask], workspace: Any) -> None:
    """Set depends_on for consumer tasks based on workspace graph."""
    repo_task_prefixes: dict[str, list[str]] = {}
    for task in tasks:
        repo_task_prefixes.setdefault(task.repo, []).append(
            task.task_id_prefix
        )

    for task in tasks:
        project = workspace.get_project(task.repo)
        if not project or not hasattr(project, "consumes"):
            continue
        for provider in project.consumes:
            if provider in repo_task_prefixes:
                for prefix in repo_task_prefixes[provider]:
                    dep_id = f"{prefix}.1"
                    if dep_id not in task.depends_on:
                        task.depends_on.append(dep_id)
