"""
Enforcement commands for Claude Code hooks.

These commands are designed to be called from PreToolUse hooks to validate
and potentially block tool operations that would violate workflow rules.

Exit codes:
- 0: Operation allowed
- 2: Operation blocked (PreToolUse will prevent the tool from running)
"""

import sys
import json
import re
from pathlib import Path
from typing import Optional

import typer

app = typer.Typer(
    help="Enforcement gates for Claude Code hooks",
    context_settings={"help_option_names": ["-h", "--help"]}
)


def find_paircoder_dir() -> Optional[Path]:
    """Find .paircoder directory."""
    try:
        from ..core.ops import find_paircoder_dir as _find
        return _find()
    except Exception:
        return None


def is_trello_enabled() -> bool:
    """Check if Trello integration is enabled."""
    import yaml
    paircoder_dir = find_paircoder_dir()
    if not paircoder_dir:
        return False
    config_path = paircoder_dir / "config.yaml"
    if not config_path.exists():
        return False
    try:
        with open(config_path, encoding='utf-8') as f:
            config = yaml.safe_load(f) or {}
        return config.get("trello", {}).get("enabled", False) and config.get("trello", {}).get("board_id")
    except Exception:
        return False


def is_strict_ac_enabled() -> bool:
    """Check if strict AC verification is enabled."""
    import yaml
    paircoder_dir = find_paircoder_dir()
    if not paircoder_dir:
        return False
    config_path = paircoder_dir / "config.yaml"
    if not config_path.exists():
        return False
    try:
        with open(config_path, encoding='utf-8') as f:
            config = yaml.safe_load(f) or {}
        return config.get("enforcement", {}).get("strict_ac_verification", False)
    except Exception:
        return False


def get_trello_card_for_task(task_id: str) -> Optional[dict]:
    """Get Trello card info for a task.

    Returns:
        dict with "found": True — card found successfully
        dict with "error": str — Trello API/network error
        None — no card linked to this task
    """
    try:
        from ..commands.state import get_trello_card_status
        result = get_trello_card_status(task_id)
        if result.get("found"):
            return result
        return None
    except Exception as e:
        return {"error": str(e)}


def is_card_in_done_list(card_info: dict) -> bool:
    """Check if Trello card is in a Done list."""
    list_name = card_info.get("list_name", "").lower()
    done_lists = ["done", "deployed", "complete", "deployed/done"]
    return any(done in list_name for done in done_lists)


def extract_task_id_from_path(file_path: str) -> Optional[str]:
    """Extract task ID from file path like .../T29.5.7.task.md"""
    path = Path(file_path)
    if not path.name.endswith(".task.md"):
        return None
    # Extract task ID (everything before .task.md)
    task_id = path.name.replace(".task.md", "")
    return task_id


def extract_status_from_content(content: str) -> Optional[str]:
    """Extract status from YAML frontmatter in content."""
    # Look for status field in frontmatter
    match = re.search(r'^status:\s*(\S+)', content, re.MULTILINE)
    if match:
        return match.group(1).strip().strip('"').strip("'")
    return None


def log_fail_open(task_id: str, reason: str, detail: str = "") -> None:
    """Log a fail-open decision for audit trail."""
    import datetime
    paircoder_dir = find_paircoder_dir()
    if not paircoder_dir:
        return
    log_path = paircoder_dir / "bypass_log.jsonl"
    entry = {
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "action": "enforce_task_edit_fail_open",
        "task_id": task_id,
        "reason": reason,
    }
    if detail:
        entry["detail"] = detail
    try:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass


def output_block_message(reason: str) -> None:
    """Output a blocking message in the format Claude Code expects."""
    # Exit code 2 blocks in PreToolUse
    # stderr is shown to Claude as feedback
    sys.stderr.write(f"\n{'='*60}\n")
    sys.stderr.write("BLOCKED BY ENFORCEMENT GATE\n")
    sys.stderr.write(f"{'='*60}\n\n")
    sys.stderr.write(f"{reason}\n\n")
    sys.stderr.write("This edit has been prevented to maintain workflow integrity.\n")
    sys.stderr.write(f"{'='*60}\n")


@app.command("task-edit")
def enforce_task_edit(
    file_path: str = typer.Option(..., "--file", "-f", help="Path to file being edited"),
    new_content: str = typer.Option("", "--new-content", "-c", help="New content (from stdin if not provided)"),
    old_content: str = typer.Option("", "--old-content", "-o", help="Old content for comparison"),
):
    """Enforce task edit rules for PreToolUse hook.

    Exit codes: 0 = allowed, 2 = blocked.
    """
    if not new_content and not sys.stdin.isatty():
        new_content = sys.stdin.read()
    from .enforce_task_edit import run_task_edit_enforcement
    run_task_edit_enforcement(file_path, new_content, old_content)


@app.command("state-edit")
def enforce_state_edit(
    file_path: str = typer.Option(..., "--file", "-f", help="Path to file being edited"),
    new_content: str = typer.Option("", "--new-content", "-c", help="New content"),
):
    """Enforce state.md edit rules for PreToolUse hook.

    Exit codes: 0 = allowed, 2 = blocked.
    """
    if not new_content and not sys.stdin.isatty():
        new_content = sys.stdin.read()
    from .enforce_state_edit import run_state_edit_enforcement
    run_state_edit_enforcement(file_path, new_content)


def find_task_file(task_id: str, paircoder_dir: Path) -> Optional[Path]:
    """Find task file for a given task ID."""
    tasks_dir = paircoder_dir / "tasks"
    if not tasks_dir.exists():
        return None

    # Search for task file in all subdirectories
    for task_file in tasks_dir.rglob(f"{task_id}.task.md"):
        return task_file
    return None


def extract_status_from_file(task_file: Path) -> Optional[str]:
    """Extract status from a task file's YAML frontmatter."""
    try:
        content = task_file.read_text(encoding='utf-8')
        return extract_status_from_content(content)
    except Exception:
        return None
