"""Display formatting helpers for feedback commands.

Separates Rich console formatting from command logic
to keep each file under architecture limits.
"""

from __future__ import annotations

from typing import Any

from rich.console import Console

console = Console()


def _format_tokens(tokens: float) -> str:
    """Format token count for display."""
    if tokens >= 1000:
        return f"{tokens / 1000:.1f}K"
    return str(int(tokens))


def _format_minutes(minutes: float) -> str:
    """Format duration in minutes for display."""
    if minutes < 1:
        return f"{minutes * 60:.0f}s"
    return f"~{minutes:.0f} min"


def print_status_output(
    cal_status: dict[str, Any],
    anomaly_summary: dict[str, Any],
    type_estimates: dict[str, dict[str, Any]],
) -> None:
    """Print feedback status in human-readable format."""
    console.print("\n[bold]Feedback System Status[/bold]")
    console.print("=" * 40)

    # Calibration health
    calibrated = cal_status.get("calibrated", False)
    total = cal_status.get("total_records", 0)
    stale = cal_status.get("stale", True)
    types = cal_status.get("task_types", [])

    if calibrated:
        stale_str = "[yellow]stale[/yellow]" if stale else "[green]up to date[/green]"
        console.print(f"  Calibration: {stale_str}")
    else:
        console.print("  Calibration: [dim]No data[/dim]")

    console.print(f"  Total samples: {total}")
    console.print(f"  Task types tracked: {len(types)}")

    # Task type estimates
    if type_estimates:
        console.print("\n[bold]Task Type Estimates:[/bold]")
        for task_type, est in sorted(type_estimates.items()):
            tokens_str = _format_tokens(est["avg"])
            dur_str = _format_minutes(est["avg_minutes"])
            model = est["recommended_model"]
            console.print(
                f"  {task_type:<14} avg {tokens_str} tokens, "
                f"{dur_str}, model: {model}"
            )

    # Anomaly summary
    total_anomalies = anomaly_summary.get("total_anomalies", 0)
    by_severity = anomaly_summary.get("by_severity", {})
    warnings = by_severity.get("warning", 0)
    criticals = by_severity.get("critical", 0)
    console.print(
        f"\n  Anomalies (last 30 days): "
        f"{warnings} warnings, {criticals} critical"
    )
    console.print()


def print_accuracy_output(performance: dict[str, Any]) -> None:
    """Print accuracy comparison in human-readable format."""
    console.print("\n[bold]Feedback Accuracy Report[/bold]")
    console.print("=" * 40)

    total = performance.get("total_tasks", 0)
    if total == 0:
        console.print("  No telemetry data available.")
        console.print()
        return

    success_rate = performance.get("success_rate", 0.0)
    total_tokens = performance.get("total_tokens", 0)
    avg_tokens = performance.get("avg_tokens_per_task", 0.0)
    period = performance.get("period_days", 7)
    by_type = performance.get("tasks_by_type", {})

    console.print(f"  Period: last {period} days")
    console.print(f"  Total tasks: {total}")
    console.print(f"  Success rate: {success_rate * 100:.0f}%")
    console.print(f"  Total tokens: {_format_tokens(total_tokens)}")
    console.print(f"  Avg tokens/task: {_format_tokens(avg_tokens)}")

    if by_type:
        console.print("\n[bold]Tasks by Type:[/bold]")
        for task_type, count in sorted(by_type.items()):
            console.print(f"  {task_type:<14} {count} tasks")

    console.print()


def print_calibrate_output(cal_data: dict[str, Any]) -> None:
    """Print calibration results in human-readable format."""
    console.print("\n[bold]Calibration Complete[/bold]")
    console.print("=" * 40)

    total = cal_data.get("total_records", 0)
    types = cal_data.get("task_types", {})

    if total == 0:
        console.print("  No telemetry data available for calibration.")
        console.print()
        return

    console.print(f"  Records processed: {total}")
    console.print(f"  Task types: {len(types)}")

    if types:
        console.print("\n[bold]Calibrated Estimates:[/bold]")
        for task_type, stats in sorted(types.items()):
            tokens_str = _format_tokens(stats["avg_tokens"])
            model = stats["recommended_model"]
            samples = stats["sample_count"]
            console.print(
                f"  {task_type:<14} avg {tokens_str} tokens, "
                f"model: {model} ({samples} samples)"
            )

    console.print()


def print_demand_summary(demand: dict[str, Any]) -> None:
    """Print fleet demand signals summary."""
    features = demand.get("features", {})
    if not features:
        return

    stale = [f for f, d in features.items() if d.get("stale")]
    top = sorted(
        features.items(),
        key=lambda x: x[1].get("adoption_rate", 0),
        reverse=True,
    )[:5]

    console.print("[bold]Fleet Demand Signals:[/bold]")
    for name, data in top:
        rate = data.get("adoption_rate", 0)
        label = "[yellow]stale[/yellow]" if data.get("stale") else ""
        console.print(f"  {name:<20} {rate * 100:.0f}% adoption  {label}")

    if stale:
        console.print(f"\n  [yellow]Stale features ({len(stale)}):[/yellow] {', '.join(stale)}")
    console.print()


def print_query_output(
    task_type: str,
    token_est: dict[str, Any],
    dur_est: dict[str, Any],
    sample_count: int,
    success_rate: float,
    recommended_effort: str = "high",
) -> None:
    """Print query results in human-readable format."""
    console.print(f"\n[bold]Task Type: {task_type}[/bold]")
    console.print("=" * 40)

    console.print(f"  Samples: {sample_count}")
    avg_str = _format_tokens(token_est["avg"])
    p80_str = _format_tokens(token_est["p80"])
    console.print(f"  Token estimate: {avg_str} avg (p80: {p80_str})")

    avg_min = _format_minutes(dur_est["avg_minutes"])
    p80_min = _format_minutes(dur_est["p80_minutes"])
    console.print(f"  Duration: {avg_min} avg (p80: {p80_min})")

    console.print(f"  Recommended model: {token_est['recommended_model']}")
    console.print(f"  Recommended effort: {recommended_effort}")
    console.print(f"  Success rate: {success_rate * 100:.0f}%")
    console.print()
