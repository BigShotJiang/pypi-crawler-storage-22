"""Telemetry management commands.

Part of Sprint 32 Product Intelligence (Telemetry).
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from ..core import ops
from ..licensing.core import require_feature
from ..telemetry.audit import AuditLog
from ..telemetry.config import TelemetryConfig
from ..telemetry.schema import PrivacyLevel
from ..telemetry.store import TelemetryStore
from .telemetry_export import (
    format_records_csv,
    format_records_json,
    format_records_jsonl,
    parse_date,
)
from .telemetry_helpers import (
    StatusData,
    _format_bytes,
    _format_tokens,
    build_status_json,
    collect_status_data,
    print_status_output,
)

console = Console()


def print_json(data: dict) -> None:
    """Print JSON to stdout without Rich formatting."""
    sys.stdout.write(json.dumps(data, indent=2))
    sys.stdout.write("\n")
    sys.stdout.flush()


def repo_root() -> Path:
    """Get repo root with better error message."""
    p = ops.find_project_root()
    if not ops.GitOps.is_repo(p):
        console.print(
            "[red]Error: Not in a git repository.[/red]\n"
            "Please run from your project root directory (where .git exists)."
        )
        raise typer.Exit(1)
    return p


# Telemetry sub-app
app = typer.Typer(
    help="Telemetry collection management",
    context_settings={"help_option_names": ["-h", "--help"]},
)


@app.command("status")
@require_feature("telemetry")
def telemetry_status(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show telemetry collection status and statistics."""
    root = repo_root()
    data = collect_status_data(root)

    if json_out:
        print_json(build_status_json(data))
    else:
        print_status_output(data)


# Privacy level choices for typer
PRIVACY_CHOICES = ["minimal", "standard", "full"]


def _print_config_details(config: TelemetryConfig) -> None:
    """Print current configuration with explanations."""
    console.print("\n[bold]Telemetry Configuration[/bold]")
    console.print("=" * 40)
    console.print()

    enabled_str = "[green]yes[/green]" if config.enabled else "[red]no[/red]"
    console.print(f"  Enabled: {enabled_str}")
    console.print(f"  Privacy Level: {config.privacy_level.value}")
    retention_str = "forever" if config.retention_days == 0 else f"{config.retention_days} days"
    console.print(f"  Retention: {retention_str}")
    console.print()

    console.print("[bold]Privacy Level Details:[/bold]")
    console.print("  [dim]minimal[/dim]  - Mandatory baseline (aggregates, errors, estimation accuracy)")
    console.print("  [dim]standard[/dim] - + feature usage, cache hit rate (default)")
    console.print("  [dim]full[/dim]     - + model routing, workflow patterns (opt-in)")
    console.print()
    console.print("Use --privacy <level> to change. MINIMAL is always active.")
    console.print()


def _log_config_change(root: Path, changes: dict[str, Any]) -> None:
    """Log configuration change to audit log."""
    telemetry_dir = root / ".paircoder" / "telemetry"
    audit_file = telemetry_dir / "audit.jsonl"
    audit = AuditLog(audit_file)
    audit.append("config_changed", changes)


def _print_config_changes(changes: dict[str, Any]) -> None:
    """Print configuration changes that were made."""
    console.print("\n[bold]Configuration updated:[/bold]")
    if "enabled" in changes:
        if changes["enabled"]:
            console.print("  Telemetry [green]enabled[/green]")
        else:
            console.print("  Telemetry [red]disabled[/red]")
    if "privacy_level" in changes:
        console.print(f"  Privacy level set to: {changes['privacy_level']}")
    if "retention_days" in changes:
        if changes["retention_days"] == 0:
            console.print("  Retention set to: forever")
        else:
            console.print(f"  Retention set to: {changes['retention_days']} days")
    console.print()


def _validate_privacy_level(privacy: str | None) -> None:
    """Validate privacy level, raising typer.Exit(2) on invalid values."""
    if privacy is None:
        return
    if privacy == "off":
        console.print("[red]Error: Privacy level 'off' is no longer supported.[/red]")
        console.print(
            "MINIMAL telemetry is now mandatory for license validation and product health.\n"
            "Valid choices: minimal, standard, full"
        )
        raise typer.Exit(2)
    if privacy not in PRIVACY_CHOICES:
        console.print(f"[red]Error: Invalid privacy level '{privacy}'.[/red]")
        console.print(f"Valid choices: {', '.join(PRIVACY_CHOICES)}")
        raise typer.Exit(2)


def _apply_config_changes(
    config: TelemetryConfig, enable: bool, disable: bool, privacy: str | None, retention: int | None,
) -> dict[str, Any]:
    """Apply configuration changes and return changes dict."""
    changes: dict[str, Any] = {}
    if enable:
        config.enabled = True
        changes["enabled"] = True
    if disable:
        config.enabled = False
        changes["enabled"] = False
    if privacy is not None:
        config.privacy_level = PrivacyLevel(privacy)
        changes["privacy_level"] = privacy
    if retention is not None:
        config.retention_days = retention
        changes["retention_days"] = retention
    return changes


@app.command("config")
def telemetry_config(
    enable: bool = typer.Option(False, "--enable", help="Enable telemetry collection"),
    disable: bool = typer.Option(False, "--disable", help="Disable telemetry collection"),
    privacy: str = typer.Option(None, "--privacy", help="Set privacy level (minimal, standard, full)"),
    retention: int = typer.Option(None, "--retention", help="Set retention period in days (0 = forever)"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Configure telemetry settings."""
    root = repo_root()
    config = TelemetryConfig.load(root)
    _validate_privacy_level(privacy)
    changes = _apply_config_changes(config, enable, disable, privacy, retention)

    if changes:
        config.save(root)
        _log_config_change(root, changes)
        _print_config_changes(changes)
    elif json_out:
        print_json({
            "enabled": config.enabled,
            "privacy_level": config.privacy_level.value,
            "retention_days": config.retention_days,
        })
    else:
        _print_config_details(config)


# Export format choices
FORMAT_CHOICES = ["json", "jsonl", "csv"]


def _log_export(root: Path, format_type: str, anonymized: bool, record_count: int) -> None:
    """Log export request to audit log."""
    telemetry_dir = root / ".paircoder" / "telemetry"
    audit_file = telemetry_dir / "audit.jsonl"
    audit = AuditLog(audit_file)
    audit.append("export_requested", {
        "format": format_type,
        "anonymized": anonymized,
        "record_count": record_count,
    })


def _format_export(records: list, format_type: str, anonymize: bool) -> str:
    """Format records in the specified format."""
    if format_type == "json":
        return format_records_json(records, anonymize=anonymize)
    elif format_type == "jsonl":
        return format_records_jsonl(records, anonymize=anonymize)
    return format_records_csv(records, anonymize=anonymize)


def _write_export(content: str, output: str | None, record_count: int) -> None:
    """Write export content to file or stdout."""
    if output:
        Path(output).write_text(content, encoding="utf-8")
        console.print(f"Exported {record_count} records to {output}")
    else:
        sys.stdout.write(content)
        if content and not content.endswith("\n"):
            sys.stdout.write("\n")
        sys.stdout.flush()


@app.command("export")
@require_feature("telemetry")
def telemetry_export(
    format_type: str = typer.Option("json", "--format", help="Output format (json, jsonl, csv)"),
    output: str = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
    since: str = typer.Option(None, "--since", help="Export records since date (YYYY-MM-DD)"),
    until: str = typer.Option(None, "--until", help="Export records until date (YYYY-MM-DD)"),
    task_type: str = typer.Option(None, "--task-type", help="Filter by task type"),
    anonymize: bool = typer.Option(False, "--anonymize", help="Remove identifying information"),
):
    """Export telemetry data for analysis or backup."""
    root = repo_root()

    if format_type not in FORMAT_CHOICES:
        console.print(f"[red]Error: Invalid format '{format_type}'.[/red]")
        console.print(f"Valid choices: {', '.join(FORMAT_CHOICES)}")
        raise typer.Exit(2)

    since_dt = parse_date(since) if since else None
    until_dt = parse_date(until) if until else None

    store = TelemetryStore(root)
    records = store.query(task_type=task_type, since=since_dt, until=until_dt, limit=100000)

    content = _format_export(records, format_type, anonymize)
    _log_export(root, format_type, anonymize, len(records))
    _write_export(content, output, len(records))
