"""Helper functions for telemetry commands.

This module contains display helpers extracted from telemetry.py
to maintain architecture compliance (max 15 functions per file).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from rich.console import Console

from ..telemetry.audit import AuditLog
from ..telemetry.config import TelemetryConfig
from ..telemetry.schema import TelemetryRecord
from ..telemetry.store import TelemetryStats, TelemetryStore

console = Console()


def _format_bytes(size: int) -> str:
    """Format byte size to human-readable string."""
    if size < 1024:
        return f"{size} bytes"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    else:
        return f"{size / (1024 * 1024):.1f} MB"


def _format_tokens(tokens: int) -> str:
    """Format token count with thousands separator and K suffix."""
    if tokens >= 1000:
        return f"{tokens / 1000:.1f}K"
    return str(tokens)


@dataclass
class StatusData:
    """Collected data for telemetry status display."""

    config: TelemetryConfig
    stats: TelemetryStats
    records: list[TelemetryRecord]
    storage_bytes: int
    oldest_date: str | None
    audit_count: int
    audit_valid: bool
    audit_error: str | None
    last_audit_time: datetime | None


def collect_status_data(root: Path) -> StatusData:
    """Collect all data needed for status display."""
    config = TelemetryConfig.load(root)
    store = TelemetryStore(root)
    stats = store.get_stats()

    telemetry_dir = root / ".paircoder" / "telemetry"
    audit_file = telemetry_dir / "audit.jsonl"
    audit = AuditLog(audit_file)
    audit_entries = audit.get_entries(limit=1)
    audit_valid, audit_error = audit.verify()
    audit_count = len(audit.get_entries(limit=10000))

    storage_bytes = 0
    telemetry_file = telemetry_dir / "telemetry.jsonl"
    if telemetry_file.exists():
        storage_bytes = telemetry_file.stat().st_size
    if audit_file.exists():
        storage_bytes += audit_file.stat().st_size

    records = store.query(limit=10000)
    oldest_date = None
    if records:
        oldest_date = min(r.timestamp for r in records).strftime("%Y-%m-%d")

    last_audit_time = audit_entries[0].timestamp if audit_entries else None

    return StatusData(
        config=config,
        stats=stats,
        records=records,
        storage_bytes=storage_bytes,
        oldest_date=oldest_date,
        audit_count=audit_count,
        audit_valid=audit_valid,
        audit_error=audit_error,
        last_audit_time=last_audit_time,
    )


def build_status_json(data: StatusData) -> dict[str, Any]:
    """Build JSON output dictionary from status data."""
    return {
        "enabled": data.config.enabled,
        "privacy_level": data.config.privacy_level.value,
        "retention_days": data.config.retention_days,
        "statistics": {
            "total_records": data.stats.total_records,
            "total_tokens": data.stats.total_tokens,
            "total_duration_seconds": data.stats.total_duration_seconds,
            "success_rate": data.stats.success_rate,
            "by_task_type": data.stats.avg_tokens_by_task_type,
            "storage_bytes": data.storage_bytes,
            "oldest_record": data.oldest_date,
        },
        "audit": {
            "entries": data.audit_count,
            "valid": data.audit_valid,
            "error": data.audit_error,
            "last_entry": (
                data.last_audit_time.isoformat() if data.last_audit_time else None
            ),
        },
    }


def print_status_output(data: StatusData) -> None:
    """Print rich formatted status output."""
    console.print("\n[bold]Telemetry Status[/bold]")
    console.print("=" * 40)
    console.print()

    # Config section
    if data.config.enabled:
        console.print("  Collection: [green]enabled[/green]")
    else:
        console.print("  Collection: [red]disabled[/red]")
    console.print(f"  Privacy Level: {data.config.privacy_level.value}")
    console.print(f"  Retention: {data.config.retention_days} days")
    console.print()

    # Stats section
    _print_stats_section(data.stats, data.records, data.storage_bytes, data.oldest_date)

    # Audit section
    _print_audit_section(
        data.audit_count, data.audit_valid, data.audit_error, data.last_audit_time
    )


def _print_stats_section(
    stats: TelemetryStats,
    records: list[TelemetryRecord],
    storage_bytes: int,
    oldest_date: str | None,
) -> None:
    """Print statistics section."""
    console.print("[bold]Statistics:[/bold]")
    if stats.total_records == 0:
        console.print("  No telemetry data collected yet.")
        console.print()
        return

    console.print(f"  Total Records: {stats.total_records}")
    if oldest_date:
        console.print(f"  Since: {oldest_date}")
    console.print(f"  Storage: {_format_bytes(storage_bytes)}")
    console.print(f"  Total Tokens: {_format_tokens(stats.total_tokens)}")
    console.print(f"  Success Rate: {stats.success_rate * 100:.1f}%")
    console.print()

    if stats.avg_tokens_by_task_type:
        console.print("[bold]By Task Type:[/bold]")
        type_counts: dict[str, int] = {}
        for r in records:
            type_counts[r.task_type] = type_counts.get(r.task_type, 0) + 1

        for task_type, avg_tokens in stats.avg_tokens_by_task_type.items():
            count = type_counts.get(task_type, 0)
            console.print(
                f"  {task_type}: {count} records, avg {_format_tokens(int(avg_tokens))} tokens"
            )
        console.print()


def _print_audit_section(
    audit_count: int,
    audit_valid: bool,
    audit_error: str | None,
    last_audit_time: datetime | None,
) -> None:
    """Print audit log section."""
    console.print("[bold]Audit Log:[/bold]")
    console.print(f"  Entries: {audit_count}")
    if audit_valid:
        console.print("  Chain Valid: [green]✓[/green]")
    else:
        console.print(f"  Chain Valid: [red]✗[/red] (warning: {audit_error})")
    if last_audit_time:
        last_entry = last_audit_time.strftime("%Y-%m-%d %H:%M:%S")
        console.print(f"  Last Entry: {last_entry}")
    console.print()
