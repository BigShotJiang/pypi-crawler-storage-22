"""Helpers for the upgrade command.

Extracted from upgrade.py to keep file sizes under architecture limits.
Contains: discovery functions, plan sub-functions, and orchestrators.
Execute/display helpers live in upgrade_execute.py.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Optional

from rich.console import Console

if TYPE_CHECKING:
    from .upgrade import UpgradePlan

# Re-export execute/display helpers so callers can import from here
from .upgrade_execute import (  # noqa: F401
    _RUNTIME_DIRS,
    _execute_skills,
    _execute_agents,
    _execute_commands,
    _execute_docs,
    _execute_config,
    _execute_fleet_calibration,
    _execute_fleet_demand,
    _execute_runtime_dirs,
    _execute_telemetry_bootstrap,
    print_upgrade_plan,
    print_upgrade_summary,
)


# ---------------------------------------------------------------------------
# Discovery functions
# ---------------------------------------------------------------------------


def get_template_dir() -> Optional[Path]:
    """Get path to cookiecutter template in installed package.

    Uses importlib.resources for robust package data access that works
    in both development mode and when pip-installed from a wheel.
    """
    template_subpath = ("cookiecutter-paircoder", "{{cookiecutter.project_slug}}")

    # Primary: Use importlib.resources (works for both dev and installed)
    try:
        import importlib.resources as resources

        data_dir = resources.files("bpsai_pair.data")
        template_traversable = data_dir.joinpath(*template_subpath)
        template_dir = Path(str(template_traversable))
        if template_dir.exists():
            return template_dir
    except (ModuleNotFoundError, TypeError, AttributeError):
        pass

    # Fallback: Development mode with direct file path
    cli_dir = Path(__file__).parent.parent
    template_dir = cli_dir / "data" / template_subpath[0] / template_subpath[1]
    if template_dir.exists():
        return template_dir

    return None


def get_bundled_skills(template: Path) -> dict[str, dict]:
    """Get all skills with full directory contents.

    Returns:
        skill_name -> {"root": Path, "files": [(rel_path, abs_path), ...]}
    """
    skills_dir = template / ".claude" / "skills"
    skills: dict[str, dict] = {}

    if not skills_dir.exists():
        return skills

    for skill_dir in skills_dir.iterdir():
        if not skill_dir.is_dir():
            continue
        skill_file = skill_dir / "SKILL.md"
        if not skill_file.exists():
            continue
        files = [
            (f.relative_to(skill_dir), f)
            for f in skill_dir.rglob("*")
            if f.is_file()
        ]
        skills[skill_dir.name] = {"root": skill_dir, "files": files}

    return skills


def get_bundled_agents(template: Path) -> dict:
    """Get all agents bundled with the CLI."""
    agents_dir = template / ".claude" / "agents"
    agents = {}

    if agents_dir.exists():
        for agent_file in agents_dir.glob("*.md"):
            agents[agent_file.stem] = agent_file

    return agents


def get_bundled_commands(template: Path) -> dict:
    """Get all commands bundled with the CLI."""
    commands_dir = template / ".claude" / "commands"
    commands = {}

    if commands_dir.exists():
        for cmd_file in commands_dir.glob("*.md"):
            commands[cmd_file.stem] = cmd_file

    return commands


# ---------------------------------------------------------------------------
# Plan sub-functions
# ---------------------------------------------------------------------------


def _plan_skills(
    plan: UpgradePlan,
    project_root: Path,
    bundled_skills: dict[str, dict],
) -> None:
    """Compare all files in each skill directory to detect changes."""
    project_skills_dir = project_root / ".claude" / "skills"

    for skill_name, skill_data in bundled_skills.items():
        project_skill_dir = project_skills_dir / skill_name
        if not project_skill_dir.exists():
            plan.skills_to_add.append(skill_name)
            continue

        try:
            if _any_file_differs(skill_data["files"], project_skill_dir):
                plan.skills_to_update.append(skill_name)
        except Exception:
            plan.warnings.append(f"Could not compare skill: {skill_name}")


def _any_file_differs(
    bundled_files: list[tuple[Path, Path]],
    project_skill_dir: Path,
) -> bool:
    """Return True if any bundled file differs from the project copy."""
    for rel_path, abs_path in bundled_files:
        project_file = project_skill_dir / rel_path
        if not project_file.exists():
            return True
        if project_file.read_bytes() != abs_path.read_bytes():
            return True
    return False


def _plan_agents(
    plan: UpgradePlan, project_root: Path, bundled_agents: dict,
) -> None:
    """Detect agents to add or update."""
    project_agents_dir = project_root / ".claude" / "agents"

    for agent_name, agent_path in bundled_agents.items():
        project_agent = project_agents_dir / f"{agent_name}.md"
        if not project_agent.exists():
            plan.agents_to_add.append(agent_name)
        else:
            try:
                if project_agent.read_bytes() != agent_path.read_bytes():
                    plan.agents_to_update.append(agent_name)
            except Exception:
                plan.warnings.append(f"Could not compare agent: {agent_name}")


def _plan_commands(
    plan: UpgradePlan, project_root: Path, bundled_commands: dict,
) -> None:
    """Detect commands to add or update."""
    project_commands_dir = project_root / ".claude" / "commands"

    for cmd_name, cmd_path in bundled_commands.items():
        project_cmd = project_commands_dir / f"{cmd_name}.md"
        if not project_cmd.exists():
            plan.commands_to_add.append(cmd_name)
        else:
            try:
                if project_cmd.read_bytes() != cmd_path.read_bytes():
                    plan.commands_to_update.append(cmd_name)
            except Exception:
                plan.warnings.append(f"Could not compare command: {cmd_name}")


def _plan_docs(
    plan: UpgradePlan, project_root: Path, template: Path,
) -> None:
    """Detect safe docs to update. AGENTS.md is excluded."""
    safe_docs = [
        ("CLAUDE.md", "CLAUDE.md"),
        (".paircoder/capabilities.yaml", ".paircoder/capabilities.yaml"),
        (".paircoder/context/workflow.md", ".paircoder/context/workflow.md"),
        (".claude/settings.json", ".claude/settings.json"),
    ]

    for template_rel, project_rel in safe_docs:
        template_file = template / template_rel
        project_file = project_root / project_rel

        if not template_file.exists():
            continue
        if not project_file.exists():
            plan.docs_to_update.append(project_rel)
        else:
            try:
                if project_file.read_bytes() != template_file.read_bytes():
                    plan.docs_to_update.append(project_rel)
            except Exception:
                plan.warnings.append(f"Could not compare doc: {project_rel}")


def _plan_config(plan: UpgradePlan, project_root: Path) -> None:
    """Detect missing config sections and stale version."""
    from ..core.config_defaults import CONFIG_SCHEMA_VERSION

    config_path = project_root / ".paircoder" / "config.yaml"
    if not config_path.exists():
        return

    try:
        import yaml
        config = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}

        # Detect stale version
        current_version = str(config.get("version", ""))
        if current_version != CONFIG_SCHEMA_VERSION:
            plan.config_version_stale = True

        required_sections = ["trello", "hooks", "estimation", "metrics"]
        for section in required_sections:
            if section not in config:
                plan.config_sections_to_add.append(section)
    except Exception:
        plan.warnings.append("Could not parse config.yaml")


def _plan_runtime_dirs(plan: UpgradePlan, project_root: Path) -> None:
    """Detect missing runtime directories (telemetry, feedback, history)."""
    paircoder_dir = project_root / ".paircoder"
    if not paircoder_dir.exists():
        return
    for dirname in _RUNTIME_DIRS:
        if not (paircoder_dir / dirname).exists():
            plan.dirs_to_create.append(dirname)


# ---------------------------------------------------------------------------
# Orchestrators (called from upgrade.py)
# ---------------------------------------------------------------------------


def plan_upgrade(project_root: Path, template: Path) -> "UpgradePlan":
    """Create upgrade plan by comparing project to template."""
    from .upgrade import UpgradePlan

    plan = UpgradePlan()
    _plan_skills(plan, project_root, get_bundled_skills(template))
    _plan_agents(plan, project_root, get_bundled_agents(template))
    _plan_commands(plan, project_root, get_bundled_commands(template))
    _plan_docs(plan, project_root, template)
    _plan_config(plan, project_root)
    _plan_runtime_dirs(plan, project_root)
    return plan


def execute_upgrade(
    project_root: Path,
    template: Path,
    plan: "UpgradePlan",
    skills: bool = True,
    agents: bool = True,
    commands: bool = True,
    docs: bool = True,
    config: bool = True,
    console: Console | None = None,
) -> dict:
    """Execute the upgrade plan.

    Returns:
        Dict with counts of what was updated.
    """
    if console is None:
        console = Console()

    results = {
        "skills_added": 0,
        "skills_updated": 0,
        "agents_added": 0,
        "agents_updated": 0,
        "commands_added": 0,
        "commands_updated": 0,
        "docs_updated": 0,
        "config_sections_added": 0,
        "dirs_created": 0,
    }

    if skills:
        _execute_skills(results, project_root, get_bundled_skills(template), plan)
    if agents:
        _execute_agents(results, project_root, get_bundled_agents(template), plan)
    if commands:
        _execute_commands(results, project_root, get_bundled_commands(template), plan)
    if docs:
        _execute_docs(results, project_root, template, plan)
    if config:
        _execute_config(results, project_root, plan, console)
    # Runtime dirs and telemetry bootstrap are always ensured regardless of
    # what was selected for upgrade, because intelligence features need them.
    _execute_runtime_dirs(results, project_root)
    _execute_telemetry_bootstrap(results, project_root)
    _execute_fleet_calibration(results, project_root)
    _execute_fleet_demand(results, project_root)

    return results
