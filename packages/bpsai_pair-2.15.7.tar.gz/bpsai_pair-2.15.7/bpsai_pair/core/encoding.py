"""Windows console encoding configuration.

On Windows, the default console encoding is often cp1252 (Western European),
which does not support Unicode characters like emoji. This module provides
a function to reconfigure stdout/stderr to use UTF-8 encoding on Windows.

This fix is specifically for Windows and is a no-op on other platforms
(Linux, macOS, WSL) where UTF-8 is typically the default encoding.
"""
import platform
import sys


def configure_encoding() -> None:
    """Configure stdout/stderr to use UTF-8 encoding on Windows.

    This function:
    - Only runs on Windows (platform.system() == "Windows")
    - Only reconfigures streams that are not already UTF-8
    - Handles streams without reconfigure() method gracefully
    - Is idempotent (safe to call multiple times)

    On non-Windows platforms, this function does nothing to avoid
    interfering with the native encoding configuration.
    """
    # Only apply fix on Windows
    if platform.system() != "Windows":
        return

    for stream in [sys.stdout, sys.stderr]:
        _reconfigure_stream_utf8(stream)


def _reconfigure_stream_utf8(stream) -> None:
    """Reconfigure a single stream to UTF-8 if needed.

    Args:
        stream: A file-like object (sys.stdout or sys.stderr)
    """
    # Get current encoding (may be None for some streams)
    encoding = getattr(stream, "encoding", None)

    # Skip if already UTF-8 (case-insensitive check)
    if encoding and encoding.lower().replace("-", "") == "utf8":
        return

    # Try to reconfigure to UTF-8
    reconfigure = getattr(stream, "reconfigure", None)
    if reconfigure and callable(reconfigure):
        try:
            reconfigure(encoding="utf-8")
        except Exception:
            # Silently ignore errors (e.g., stream doesn't support reconfigure)
            pass
