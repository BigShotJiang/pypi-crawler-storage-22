"""Model routing hook handler.

Selects the appropriate model for a task using data-driven routing
(per-model calibration stats) when available, falling back to static
complexity-based routing from config.yaml.

Non-blocking: logs decision but never blocks task start.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from bpsai_pair.core.hook_types import HookContext
from bpsai_pair.core.routing import DataDrivenRouter, get_routing_config

logger = logging.getLogger(__name__)


def select_model(
    ctx: HookContext,
    config: dict,
    paircoder_dir: Path,
) -> dict[str, Any]:
    """Select model based on calibration data or static routing config.

    Tries data-driven routing first (cheapest model meeting quality
    threshold from calibration stats). Falls back to static complexity
    routing when insufficient calibration data.

    Never blocks — errors fall back to default model.
    """
    task_type = _get_task_type(ctx)
    complexity = _get_complexity(ctx)

    data_driven = False
    model = _try_data_driven(task_type, config, paircoder_dir)

    if model is not None:
        data_driven = True
    else:
        routing = get_routing_config()
        model = routing.get_model(complexity=complexity, task_type=task_type)

    ctx.extra["routed_model"] = model
    logger.info(
        "Routed task %s (type=%s, cx=%d) → %s (data_driven=%s)",
        ctx.task_id, task_type, complexity, model, data_driven,
    )

    _persist_decision(paircoder_dir, ctx.task_id, model, task_type, complexity)

    return {
        "routed_model": model,
        "task_type": task_type,
        "complexity": complexity,
        "data_driven": data_driven,
    }


def _try_data_driven(
    task_type: str, config: dict, paircoder_dir: Path,
) -> str | None:
    """Attempt data-driven model selection; return None on failure."""
    cal = _get_calibration_data(paircoder_dir)
    if cal is None:
        return None
    router = DataDrivenRouter.from_config(config)
    return router.select_model(task_type, cal)


def _get_calibration_data(paircoder_dir: Path) -> Any:
    """Load calibration data from cache, returning None on failure."""
    try:
        from bpsai_pair.feedback.calibration import CalibrationEngine

        project_root = paircoder_dir.parent
        engine = CalibrationEngine(project_root)
        if engine.is_calibrated:
            return engine.get_calibration()
    except Exception:
        logger.debug("Could not load calibration data for routing")
    return None


def _persist_decision(
    paircoder_dir: Path,
    task_id: str,
    model: str,
    task_type: str,
    complexity: int,
) -> None:
    """Write routing decision to disk for telemetry collection."""
    decision = {
        "task_id": task_id,
        "routed_model": model,
        "task_type": task_type,
        "complexity": complexity,
    }
    try:
        path = paircoder_dir / f"routing_decision_{task_id}.json"
        path.write_text(json.dumps(decision), encoding="utf-8")
    except OSError:
        logger.debug("Could not persist routing decision")


def _get_task_type(ctx: HookContext) -> str:
    """Extract task type from context, defaulting to 'feature'."""
    if ctx.task is None:
        return "feature"
    return getattr(ctx.task, "type", "feature") or "feature"


def _get_complexity(ctx: HookContext) -> int:
    """Extract complexity from context, defaulting to 50."""
    if ctx.task is None:
        return 50
    cx = getattr(ctx.task, "complexity", None)
    return cx if cx is not None else 50
