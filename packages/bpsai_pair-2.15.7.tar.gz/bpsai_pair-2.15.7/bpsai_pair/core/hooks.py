"""Hook system for task state changes.

Orchestrates hooks on events; logic lives in hook_metrics, hook_trello,
hook_budget, hook_state, gate_hooks, and enrichment_hooks modules.
"""

import logging
from pathlib import Path
from typing import Callable, Dict, List

from bpsai_pair.core.hook_types import HookContext, HookResult  # noqa: F401 re-export

logger = logging.getLogger(__name__)

# Maps private method names to (module_path, function_name, arg_style).
# arg_style: "cfg_pd" = (ctx, config, paircoder_dir),
#             "pd" = (ctx, paircoder_dir), "cfg" = (ctx, config)
_DELEGATE_MAP: Dict[str, tuple[str, str, str]] = {
    "_start_timer": ("bpsai_pair.core.hook_metrics", "start_timer", "cfg_pd"),
    "_stop_timer": ("bpsai_pair.core.hook_metrics", "stop_timer", "cfg_pd"),
    "_record_metrics": ("bpsai_pair.core.hook_metrics", "record_metrics", "pd"),
    "_sync_trello": ("bpsai_pair.core.hook_trello", "sync_trello", "cfg"),
    "_update_state": ("bpsai_pair.core.hook_state", "update_state", "pd"),
    "_check_unblocked": ("bpsai_pair.core.hook_state", "check_unblocked", "pd"),
    "_log_trello_activity": ("bpsai_pair.core.hook_trello", "log_trello_activity", "cfg"),
    "_record_task_completion": ("bpsai_pair.core.hook_metrics", "record_task_completion", "pd"),
    "_record_velocity": ("bpsai_pair.core.hook_metrics", "record_velocity", "pd"),
    "_record_token_usage": ("bpsai_pair.core.hook_metrics", "record_token_usage", "pd"),
    "_apply_token_learning": ("bpsai_pair.core.hook_metrics", "apply_token_learning", "cfg_pd"),
    "_check_token_budget": ("bpsai_pair.core.hook_budget", "check_token_budget", "cfg_pd"),
}


class HookRunner:
    """Runs configured hooks on events."""

    def __init__(self, config: dict, paircoder_dir: Path):
        self.config = config
        self.paircoder_dir = Path(paircoder_dir)
        self._gate_hooks: set[str] = {"arch_check_modified", "contract_break_check"}
        self._cleanup_hooks: set[str] = {
            "stop_timer", "record_metrics", "sync_trello", "update_state",
            "check_unblocked",
        }
        self._handlers: Dict[str, Callable] = _build_handlers(self)
        self._register_external_hooks()

    def __getattr__(self, name: str):
        """Delegate _hook_name calls to extracted modules (test compat)."""
        if name not in _DELEGATE_MAP:
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
        import importlib
        mod_path, func_name, style = _DELEGATE_MAP[name]
        fn = getattr(importlib.import_module(mod_path), func_name)
        args = {"cfg_pd": (self.config, self.paircoder_dir),
                "cfg": (self.config,), "pd": (self.paircoder_dir,)}[style]
        delegate = lambda ctx, f=fn, a=args: f(ctx, *a)
        self.__dict__[name] = delegate  # cache for subsequent access
        return delegate

    def _check_token_budget(self, ctx: HookContext) -> dict:
        from bpsai_pair.core.hook_budget import check_token_budget
        return check_token_budget(ctx, self.config, self.paircoder_dir)

    def _register_external_hooks(self) -> None:
        """Register gate and enrichment hooks from external modules."""
        try:
            from bpsai_pair.core.gate_hooks import (
                arch_check_modified, contract_break_check,
            )
            pd = self.paircoder_dir
            self._handlers["arch_check_modified"] = (
                lambda ctx: arch_check_modified(ctx, project_root=pd.parent)
            )
            self._handlers["contract_break_check"] = (
                lambda ctx: contract_break_check(ctx, project_root=pd.parent)
            )
        except ImportError:
            logger.debug("Gate hooks module not available")

        try:
            from bpsai_pair.core.hook_routing import select_model
            pd = self.paircoder_dir
            self._handlers["select_model"] = (
                lambda ctx: select_model(ctx, self.config, pd)
            )
        except ImportError:
            logger.debug("Routing hook module not available")

        try:
            from bpsai_pair.core.enrichment_hooks import (
                agent_team_telemetry, calibration_update_incremental,
                feedback_calibrate, telemetry_snapshot, workspace_impact_scan,
            )
            pd = self.paircoder_dir
            self._handlers.update({
                "workspace_impact_scan": lambda ctx: workspace_impact_scan(ctx, project_root=pd.parent),
                "telemetry_snapshot": lambda ctx: telemetry_snapshot(ctx, project_root=pd.parent),
                "feedback_calibrate": lambda ctx: feedback_calibrate(ctx, project_root=pd.parent),
                "agent_team_telemetry": lambda ctx: agent_team_telemetry(ctx, project_root=pd.parent),
                "calibration_update_incremental": lambda ctx: calibration_update_incremental(ctx, project_root=pd.parent),
            })
        except ImportError:
            logger.debug("Enrichment hooks module not available")

    @property
    def enabled(self) -> bool:
        """Check if hooks are enabled."""
        return self.config.get("hooks", {}).get("enabled", True)

    def get_hooks_for_event(self, event: str) -> List[str]:
        """Get list of hooks configured for an event."""
        return self.config.get("hooks", {}).get(event, [])

    def run_hooks(self, event: str, context: HookContext) -> List[HookResult]:
        """Run all hooks for an event."""
        if not self.enabled:
            logger.debug("Hooks disabled, skipping")
            return []

        hooks = self.get_hooks_for_event(event)
        if not hooks:
            logger.debug(f"No hooks configured for {event}")
            return []

        results = []
        gate_blocked = False

        for hook_name in hooks:
            if gate_blocked and hook_name not in self._cleanup_hooks:
                continue
            result = self._run_single_hook(hook_name, context)
            results.append(result)
            if result.blocked and hook_name in self._gate_hooks:
                gate_blocked = True
                logger.warning(
                    "Gate hook %s blocked task %s: %s",
                    hook_name, context.task_id, result.result,
                )

        return results

    def _run_single_hook(self, hook_name: str, context: HookContext) -> HookResult:
        """Run a single hook."""
        handler = self._handlers.get(hook_name)

        if not handler:
            logger.warning(f"Unknown hook: {hook_name}")
            return HookResult(
                hook=hook_name,
                success=False,
                error=f"Unknown hook: {hook_name}",
            )

        try:
            result = handler(context)
            is_blocked = (
                hook_name in self._gate_hooks
                and isinstance(result, dict)
                and result.get("blocked", False)
            )
            logger.info(f"Hook {hook_name} completed for {context.task_id}")
            return HookResult(
                hook=hook_name, success=True, result=result, blocked=is_blocked,
            )
        except Exception as e:
            logger.error(f"Hook {hook_name} failed: {e}")
            return HookResult(hook=hook_name, success=False, error=str(e))


def _build_handlers(runner: HookRunner) -> Dict[str, Callable]:
    """Build handler dict from delegate map."""
    import importlib
    handlers: Dict[str, Callable] = {}
    for attr_name, (mod_path, func_name, style) in _DELEGATE_MAP.items():
        hook_name = attr_name.lstrip("_")
        mod = importlib.import_module(mod_path)
        fn = getattr(mod, func_name)
        if style == "cfg_pd":
            handlers[hook_name] = (
                lambda ctx, f=fn, r=runner: f(ctx, r.config, r.paircoder_dir)
            )
        elif style == "cfg":
            handlers[hook_name] = (
                lambda ctx, f=fn, r=runner: f(ctx, r.config)
            )
        else:
            handlers[hook_name] = (
                lambda ctx, f=fn, r=runner: f(ctx, r.paircoder_dir)
            )
    return handlers


def load_config(paircoder_dir: Path) -> dict:
    """Load configuration from config.yaml."""
    import yaml

    config_path = paircoder_dir / "config.yaml"
    if config_path.exists():
        return yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    return {}


def get_hook_runner(paircoder_dir: Path) -> HookRunner:
    """Get a HookRunner instance for the project."""
    config = load_config(paircoder_dir)
    return HookRunner(config, paircoder_dir)
