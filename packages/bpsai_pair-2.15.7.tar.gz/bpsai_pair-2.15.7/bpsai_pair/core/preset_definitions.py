"""Preset definitions — data constants for built-in presets.

Contains COMMON_EXCLUDES, the PRESETS dictionary with all 8 built-in
preset instances, and helper functions for preset lookup.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from .presets import Preset


# Common pack excludes shared across presets
COMMON_EXCLUDES = [
    ".git",
    ".venv",
    "__pycache__",
    "node_modules",
    "dist",
    "build",
    "*.log",
    "*.bak",
]


# Pre-defined presets
PRESETS: Dict[str, Preset] = {
    "python-cli": Preset(
        name="python-cli",
        description="Python CLI application with Click/Typer",
        project_type="Python CLI",
        coverage_target=80,
        python_formatter="ruff",
        ci_type="python",
        pack_excludes=COMMON_EXCLUDES + [
            "*.egg-info",
            ".pytest_cache",
            ".mypy_cache",
            ".ruff_cache",
            "htmlcov",
            ".coverage",
        ],
    ),

    "python-api": Preset(
        name="python-api",
        description="Python REST API with Flask/FastAPI",
        project_type="Python API",
        coverage_target=85,
        python_formatter="ruff",
        ci_type="python",
        pack_excludes=COMMON_EXCLUDES + [
            "*.egg-info",
            ".pytest_cache",
            ".mypy_cache",
            ".ruff_cache",
            "htmlcov",
            ".coverage",
            "instance/",
            "*.db",
            "*.sqlite",
        ],
    ),

    "react": Preset(
        name="react",
        description="React/Next.js frontend application",
        project_type="React App",
        coverage_target=75,
        node_formatter="prettier",
        ci_type="node",
        pack_excludes=COMMON_EXCLUDES + [
            ".next",
            ".cache",
            "coverage",
            "*.tsbuildinfo",
            ".turbo",
        ],
    ),

    "fullstack": Preset(
        name="fullstack",
        description="Full-stack application (Python backend + React frontend)",
        project_type="Full-Stack App",
        coverage_target=80,
        python_formatter="ruff",
        node_formatter="prettier",
        ci_type="fullstack",
        pack_excludes=COMMON_EXCLUDES + [
            "*.egg-info",
            ".pytest_cache",
            ".mypy_cache",
            ".ruff_cache",
            "htmlcov",
            ".coverage",
            ".next",
            ".cache",
            "coverage",
            "*.tsbuildinfo",
        ],
    ),

    "library": Preset(
        name="library",
        description="Python library/package for distribution",
        project_type="Python Library",
        coverage_target=90,
        python_formatter="ruff",
        ci_type="python",
        pack_excludes=COMMON_EXCLUDES + [
            "*.egg-info",
            ".pytest_cache",
            ".mypy_cache",
            ".ruff_cache",
            "htmlcov",
            ".coverage",
            "dist/",
            "build/",
            "*.whl",
            "*.tar.gz",
        ],
    ),

    "minimal": Preset(
        name="minimal",
        description="Minimal configuration with essential defaults only",
        project_type="Project",
        coverage_target=70,
        ci_type="fullstack",
        pack_excludes=COMMON_EXCLUDES,
        enabled_flows=["tdd-implement", "review"],
    ),

    "autonomous": Preset(
        name="autonomous",
        description="Full autonomy configuration with Trello integration",
        project_type="Autonomous Project",
        coverage_target=80,
        ci_type="python",
        pack_excludes=COMMON_EXCLUDES + [
            "*.egg-info",
            ".pytest_cache",
            ".mypy_cache",
            ".ruff_cache",
            "htmlcov",
            ".coverage",
        ],
        enabled_flows=[
            "design-plan-implement",
            "tdd-implement",
            "review",
            "finish-branch",
        ],
        model_routing={
            "by_complexity": {
                "trivial": {"max_score": 20, "model": "claude-haiku-4-5"},
                "simple": {"max_score": 40, "model": "claude-haiku-4-5"},
                "moderate": {"max_score": 60, "model": "claude-sonnet-4-5"},
                "complex": {"max_score": 80, "model": "claude-opus-4-6"},
                "epic": {"max_score": 100, "model": "claude-opus-4-6"},
            }
        },
    ),

    "bps": Preset(
        name="bps",
        description="BPS AI Software preset with 7-list Trello workflow",
        project_type="BPS Project",
        coverage_target=80,
        ci_type="python",
        pack_excludes=COMMON_EXCLUDES + [
            "*.egg-info",
            ".pytest_cache",
            ".mypy_cache",
            ".ruff_cache",
            "htmlcov",
            ".coverage",
        ],
        enabled_flows=[
            "design-plan-implement",
            "tdd-implement",
            "review",
            "finish-branch",
        ],
        model_routing={
            "by_complexity": {
                "trivial": {"max_score": 20, "model": "claude-haiku-4-5"},
                "simple": {"max_score": 40, "model": "claude-haiku-4-5"},
                "moderate": {"max_score": 60, "model": "claude-sonnet-4-5"},
                "complex": {"max_score": 80, "model": "claude-opus-4-6"},
                "epic": {"max_score": 100, "model": "claude-opus-4-6"},
            }
        },
        trello_config={
            "lists": {
                "backlog": "Intake / Backlog",
                "ready": "Planned / Ready",
                "in_progress": "In Progress",
                "review": "Review / Testing",
                "done": "Deployed / Done",
                "blocked": "Issues / Tech Debt",
                "notes": "Notes / Ops Log",
            },
            "card_format": "[{stack}] {title}",
            "labels": {
                "frontend": {"name": "Frontend", "color": "green"},
                "backend": {"name": "Backend", "color": "blue"},
                "worker": {"name": "Worker / Function", "color": "purple"},
                "deployment": {"name": "Deployment", "color": "red"},
                "bug": {"name": "Bug / Issue", "color": "orange"},
                "security": {"name": "Security / Admin", "color": "yellow"},
                "docs": {"name": "Documentation", "color": "sky"},
                "ai": {"name": "AI / ML Integration", "color": "black"},
            },
            "custom_fields": {
                "project": "Project",
                "stack": "Stack",
                "status": "Status",
                "effort": "Effort",
                "deployment_tag": "Deployment Tag",
            },
            "automation": {
                "on_task_start": {
                    "move_to_list": "In Progress",
                    "add_comment": "\U0001f916 {agent} started working on this task",
                },
                "on_task_complete": {
                    "move_to_list": "Deployed / Done",
                    "add_comment": "\u2705 Task completed by {agent}\n\n{summary}",
                },
                "on_task_block": {
                    "move_to_list": "Issues / Tech Debt",
                    "add_comment": "\u26a0\ufe0f Task blocked: {reason}",
                },
                "on_task_review": {
                    "move_to_list": "Review / Testing",
                    "add_comment": "\U0001f50d {agent} submitted for review",
                },
            },
            "status_mapping": {
                "Intake / Backlog": "pending",
                "Planned / Ready": "pending",
                "In Progress": "in_progress",
                "Review / Testing": "in_progress",
                "Deployed / Done": "done",
                "Issues / Tech Debt": "blocked",
            },
        },
        hooks_config={
            "enabled": True,
            "on_task_start": ["start_timer", "sync_trello", "update_state"],
            "on_task_complete": [
                "arch_check_modified",
                "contract_break_check",
                "stop_timer",
                "record_token_usage",
                "apply_token_learning",
                "workspace_impact_scan",
                "telemetry_snapshot",
                "calibration_update_incremental",
                "feedback_calibrate",
                "sync_trello",
                "update_state",
                "check_unblocked",
            ],
            "on_task_block": ["sync_trello", "update_state"],
        },
    ),
}


def get_preset(name: str) -> Optional[Preset]:
    """Get a preset by name."""
    return PRESETS.get(name)


def list_presets() -> List[Preset]:
    """List all available presets."""
    return list(PRESETS.values())


def get_preset_names() -> List[str]:
    """Get names of all available presets."""
    return list(PRESETS.keys())
