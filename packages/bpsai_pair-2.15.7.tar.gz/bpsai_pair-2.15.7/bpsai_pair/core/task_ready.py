"""Task Readiness Detection and Hook Firing.

Determines when a task is ready for work and fires the on_task_ready hook.

A task is considered "ready" when it has:
1. A title
2. A plan assigned
3. Acceptance criteria defined (checklist items in body)
4. Status is "pending" (not blocked, in_progress, done, etc.)
"""

import logging
import re
from pathlib import Path
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..planning.models import Task

from .hooks import HookRunner, HookContext, HookResult, load_config

logger = logging.getLogger(__name__)

# Pattern to detect acceptance criteria in task body
AC_PATTERN = re.compile(r'[-*]\s+\[([ xX])\]\s+.+', re.MULTILINE)


def has_acceptance_criteria(task: "Task") -> bool:
    """Check if task has acceptance criteria defined.

    Looks for markdown checklist items (- [ ] or - [x]) in the task body.

    Args:
        task: Task object to check

    Returns:
        True if task has at least one AC item
    """
    if not task.body:
        return False

    matches = AC_PATTERN.findall(task.body)
    return len(matches) > 0


def is_task_ready(task: "Task") -> bool:
    """Determine if a task is ready for work.

    A task is ready when:
    1. Has a title
    2. Has a plan assigned
    3. Has acceptance criteria
    4. Status is "pending"

    Args:
        task: Task object to check

    Returns:
        True if task meets all readiness criteria
    """
    from ..planning.models import TaskStatus

    # Must have a title
    if not task.title or not task.title.strip():
        logger.debug(f"Task {task.id} not ready: no title")
        return False

    # Must have a plan
    if not task.plan_id or not task.plan_id.strip():
        logger.debug(f"Task {task.id} not ready: no plan")
        return False

    # Must have acceptance criteria
    if not has_acceptance_criteria(task):
        logger.debug(f"Task {task.id} not ready: no acceptance criteria")
        return False

    # Must be in pending status (not started, blocked, etc.)
    if task.status != TaskStatus.PENDING:
        logger.debug(f"Task {task.id} not ready: status is {task.status}")
        return False

    return True


def fire_on_task_ready(
    task: "Task",
    paircoder_dir: Path,
    agent: Optional[str] = None,
) -> List[HookResult]:
    """Fire the on_task_ready hook for a task.

    Only fires if the task meets readiness criteria.

    Args:
        task: Task object
        paircoder_dir: Path to .paircoder directory
        agent: Optional agent name

    Returns:
        List of hook results, empty if task not ready or hooks disabled
    """
    # Check if task is ready
    if not is_task_ready(task):
        logger.debug(f"Task {task.id} does not meet ready criteria, skipping hook")
        return []

    # Load config and create runner
    config = load_config(paircoder_dir)
    runner = HookRunner(config, paircoder_dir)

    # Create context
    ctx = HookContext(
        task_id=task.id,
        task=task,
        event="on_task_ready",
        agent=agent,
    )

    # Run hooks
    logger.info(f"Firing on_task_ready for {task.id}")
    results = runner.run_hooks("on_task_ready", ctx)

    return results


def check_and_fire_ready(
    task: "Task",
    paircoder_dir: Path,
    agent: Optional[str] = None,
) -> tuple[bool, List[HookResult]]:
    """Check task readiness and fire hook if ready.

    Convenience function that returns both the readiness check result
    and any hook results.

    Args:
        task: Task object
        paircoder_dir: Path to .paircoder directory
        agent: Optional agent name

    Returns:
        Tuple of (is_ready, hook_results)
    """
    ready = is_task_ready(task)
    results = []

    if ready:
        results = fire_on_task_ready(task, paircoder_dir, agent)

    return ready, results
