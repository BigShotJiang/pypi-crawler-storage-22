"""Fleet calibration client for pulling fleet-wide defaults from the API.

Fetches aggregated calibration data from the PairCoder API and merges
it with local calibration. Fleet data seeds defaults for new users;
local data takes priority when sufficient samples exist.
"""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from bpsai_pair.feedback.schema import CalibrationData, TaskTypeStats

logger = logging.getLogger(__name__)

_DEFAULT_API_URL = os.environ.get("PAIRCODER_API_URL", "https://api.paircoder.ai")
_FLEET_ENDPOINT = "/fleet/calibration"
_DEMAND_ENDPOINT = "/fleet/demand-signals"
_TIMEOUT = 10


class FleetCalibrationClient:
    """Fetches fleet calibration data from the API."""

    def __init__(self, api_url: str = _DEFAULT_API_URL) -> None:
        self.api_url = api_url.rstrip("/")

    def fetch(self) -> dict[str, Any] | None:
        """Fetch fleet calibration data from the API."""
        return self._fetch_endpoint(_FLEET_ENDPOINT, "calibration")

    def fetch_demand_signals(self) -> dict[str, Any] | None:
        """Fetch fleet demand signals from the API."""
        return self._fetch_endpoint(_DEMAND_ENDPOINT, "demand signals")

    def _fetch_endpoint(self, endpoint: str, label: str) -> dict[str, Any] | None:
        """Fetch and parse JSON from a fleet endpoint."""
        url = f"{self.api_url}{endpoint}"
        req = urllib.request.Request(url, method="GET")
        req.add_header("Accept", "application/json")

        try:
            with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
                body = resp.read()
                return json.loads(body)
        except (urllib.error.URLError, urllib.error.HTTPError) as e:
            logger.warning("Fleet %s fetch failed: %s", label, e)
            return None
        except (json.JSONDecodeError, ValueError) as e:
            logger.warning("Fleet %s response invalid: %s", label, e)
            return None


_CONFIDENCE_DIVISOR = 20


def _local_confidence(stats: TaskTypeStats) -> float:
    """Compute local confidence score from sample count."""
    return min(stats.sample_count / _CONFIDENCE_DIVISOR, 1.0)


def merge_fleet_data(
    local_cal: CalibrationData,
    fleet_data: dict[str, Any],
    project_root: Path,
) -> CalibrationData:
    """Merge fleet calibration into local data using confidence comparison.

    For each task type: fleet overrides local only when fleet confidence
    exceeds local confidence. New task types are always seeded from fleet.

    Args:
        local_cal: Current local calibration.
        fleet_data: Fleet response from API.
        project_root: Project root for saving merged result.

    Returns:
        Updated CalibrationData with fleet data merged in.
    """
    fleet_types = fleet_data.get("task_types", {})

    for task_type, fleet_stats in fleet_types.items():
        fleet_conf = fleet_stats.get("confidence", 0.0)
        local_stats = local_cal.task_types.get(task_type)

        if local_stats is None:
            logger.info(
                "Fleet merge: seeding '%s' from fleet (confidence=%.2f)",
                task_type, fleet_conf,
            )
            local_cal.task_types[task_type] = _fleet_to_stats(task_type, fleet_stats)
            continue

        local_conf = _local_confidence(local_stats)
        if fleet_conf > local_conf:
            logger.info(
                "Fleet merge: upgrading '%s' — fleet confidence %.2f > local %.2f",
                task_type, fleet_conf, local_conf,
            )
            local_cal.task_types[task_type] = _fleet_to_stats(task_type, fleet_stats)
        else:
            logger.info(
                "Fleet merge: keeping local '%s' — local confidence %.2f >= fleet %.2f",
                task_type, local_conf, fleet_conf,
            )

    _save_calibration(local_cal, project_root)
    return local_cal


def _fleet_to_stats(task_type: str, fleet: dict[str, Any]) -> TaskTypeStats:
    """Convert fleet API response entry to TaskTypeStats.

    Maps avg_estimation_error → avg_tokens because calibration uses token
    counts as the unit of estimation error (predicted vs actual tokens).
    """
    avg = fleet.get("avg_estimation_error", 30000.0)
    p80 = fleet.get("p80_estimation_error", avg * 1.3)
    return TaskTypeStats(
        task_type=task_type,
        sample_count=fleet.get("sample_count", 0),
        avg_tokens=avg,
        std_dev=abs(p80 - avg) * 0.8,
        p80_tokens=p80,
        avg_duration_seconds=1800.0,
        success_rate=0.9,
        recommended_model="sonnet",
    )


def _save_calibration(cal: CalibrationData, project_root: Path) -> None:
    """Save calibration data to JSON cache."""
    cache_path = project_root / ".paircoder" / "feedback" / "calibration.json"
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(
        json.dumps(cal.to_dict(), indent=2), encoding="utf-8",
    )


_DEMAND_CACHE = "demand-signals.json"


def cache_demand_signals(data: dict[str, Any], project_root: Path) -> None:
    """Save demand signals to local cache."""
    cache_path = project_root / ".paircoder" / "feedback" / _DEMAND_CACHE
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def load_demand_signals(project_root: Path) -> dict[str, Any] | None:
    """Load cached demand signals, or None if missing."""
    cache_path = project_root / ".paircoder" / "feedback" / _DEMAND_CACHE
    if not cache_path.exists():
        return None
    try:
        return json.loads(cache_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, ValueError):
        return None
