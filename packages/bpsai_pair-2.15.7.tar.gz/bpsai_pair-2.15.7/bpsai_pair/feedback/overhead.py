"""Human overhead tracking and analysis.

Tracks the gap between Claude execution time and total human time,
revealing hidden overhead from validation, error correction, context
switching, and manual coordination.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from bpsai_pair.telemetry.schema import Outcome, TelemetryRecord
from bpsai_pair.telemetry.store import TelemetryStore

# Overhead estimation constants
# Each intervention adds ~15% overhead (context switch + review)
_INTERVENTION_OVERHEAD_FACTOR = 0.15
# Each compaction adds ~25% overhead (lost context + re-orientation)
_COMPACTION_OVERHEAD_FACTOR = 0.25

# Thresholds for pattern detection
_HIGH_INTERVENTION_THRESHOLD = 5
_HIGH_COMPACTION_THRESHOLD = 2
_HIGH_FAILURE_RATE_THRESHOLD = 0.3


@dataclass
class OverheadMetrics:
    """Overhead metrics for a single task."""

    task_id: str
    claude_duration_seconds: int
    human_duration_seconds: int
    overhead_ratio: float
    intervention_count: int
    compaction_count: int

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "task_id": self.task_id,
            "claude_duration_seconds": self.claude_duration_seconds,
            "human_duration_seconds": self.human_duration_seconds,
            "overhead_ratio": self.overhead_ratio,
            "intervention_count": self.intervention_count,
            "compaction_count": self.compaction_count,
        }


class OverheadTracker:
    """Tracks and analyzes human overhead in AI-augmented tasks.

    Overhead ratio interpretation:
    - < 1.5x: Excellent (minimal overhead)
    - 1.5-3x: Normal (expected validation)
    - 3-5x: Elevated (investigate cause)
    - > 5x: Problem (workflow issue)
    """

    def __init__(self, project_root: Path) -> None:
        self.store = TelemetryStore(project_root)

    def calculate_overhead(
        self,
        task_id: str,
        human_duration_seconds: int | None = None,
    ) -> OverheadMetrics | None:
        """Calculate overhead for a specific task.

        Args:
            task_id: Task identifier to look up.
            human_duration_seconds: Explicit human wall-clock time.
                If not provided, estimates from interventions/compactions.

        Returns:
            OverheadMetrics or None if task not found.
        """
        records = self.store.query(task_id=task_id, limit=1)
        if not records:
            return None

        record = records[0]
        claude_dur = record.duration_seconds

        if human_duration_seconds is not None:
            human_dur = human_duration_seconds
        else:
            human_dur = _estimate_human_duration(record)

        ratio = human_dur / claude_dur if claude_dur > 0 else 1.0

        return OverheadMetrics(
            task_id=task_id,
            claude_duration_seconds=claude_dur,
            human_duration_seconds=human_dur,
            overhead_ratio=round(ratio, 2),
            intervention_count=record.human_interventions,
            compaction_count=record.compactions,
        )

    def get_average_overhead(
        self, task_type: str | None = None
    ) -> dict[str, Any]:
        """Get average overhead ratio, optionally by task type.

        Args:
            task_type: Optional filter by task type.

        Returns:
            Dict with overall_avg_ratio and by_type breakdown.
        """
        records = self.store.query(
            task_type=task_type, limit=10_000
        )
        if not records:
            return {"overall_avg_ratio": 0.0, "by_type": {}}

        ratios = [_compute_ratio(r) for r in records]
        overall = sum(ratios) / len(ratios)

        by_type: dict[str, list[float]] = {}
        for r, ratio in zip(records, ratios):
            by_type.setdefault(r.task_type, []).append(ratio)

        type_avgs = {
            t: round(sum(rs) / len(rs), 2) for t, rs in by_type.items()
        }

        return {
            "overall_avg_ratio": round(overall, 2),
            "by_type": type_avgs,
        }

    def get_overhead_breakdown(self) -> dict[str, Any]:
        """Break down overhead by source.

        Returns:
            Dict with intervention, compaction, and failure stats.
        """
        records = self.store.query(limit=10_000)
        if not records:
            return {
                "total_interventions": 0,
                "avg_interventions": 0.0,
                "total_compactions": 0,
                "avg_compactions": 0.0,
                "failure_rate": 0.0,
                "total_tasks": 0,
            }

        total_interventions = sum(r.human_interventions for r in records)
        total_compactions = sum(r.compactions for r in records)
        failures = sum(1 for r in records if r.outcome == Outcome.FAIL)
        count = len(records)

        return {
            "total_interventions": total_interventions,
            "avg_interventions": round(total_interventions / count, 2),
            "total_compactions": total_compactions,
            "avg_compactions": round(total_compactions / count, 2),
            "failure_rate": round(failures / count, 3),
            "total_tasks": count,
        }

    def identify_high_overhead_patterns(self) -> list[dict[str, str]]:
        """Find patterns that correlate with high overhead.

        Returns:
            List of dicts with pattern name and recommendation.
        """
        records = self.store.query(limit=10_000)
        if not records:
            return []

        count = len(records)
        avg_interventions = (
            sum(r.human_interventions for r in records) / count
        )
        avg_compactions = sum(r.compactions for r in records) / count
        failure_rate = (
            sum(1 for r in records if r.outcome == Outcome.FAIL) / count
        )

        return _detect_patterns(
            avg_interventions, avg_compactions, failure_rate
        )


def _detect_patterns(
    avg_interventions: float,
    avg_compactions: float,
    failure_rate: float,
) -> list[dict[str, str]]:
    """Detect overhead patterns from aggregate metrics."""
    patterns: list[dict[str, str]] = []

    if avg_interventions >= _HIGH_INTERVENTION_THRESHOLD:
        patterns.append({
            "pattern": "high_interventions",
            "recommendation": (
                f"Average interventions is high ({avg_interventions:.1f}). "
                "Consider clearer task specs or smaller scope."
            ),
        })

    if avg_compactions >= _HIGH_COMPACTION_THRESHOLD:
        patterns.append({
            "pattern": "high_compactions",
            "recommendation": (
                f"Average compactions is high ({avg_compactions:.1f}). "
                "Tasks may be too large for context window."
            ),
        })

    if failure_rate >= _HIGH_FAILURE_RATE_THRESHOLD:
        patterns.append({
            "pattern": "high_failure_rate",
            "recommendation": (
                f"Failure rate is {failure_rate:.0%}. "
                "Review task requirements and acceptance criteria."
            ),
        })

    return patterns


def _estimate_human_duration(record: TelemetryRecord) -> int:
    """Estimate human wall-clock time from telemetry signals."""
    base = record.duration_seconds
    intervention_overhead = (
        record.human_interventions * _INTERVENTION_OVERHEAD_FACTOR * base
    )
    compaction_overhead = (
        record.compactions * _COMPACTION_OVERHEAD_FACTOR * base
    )
    return int(base + intervention_overhead + compaction_overhead)


def _compute_ratio(record: TelemetryRecord) -> float:
    """Compute overhead ratio for a single record."""
    human_dur = _estimate_human_duration(record)
    if record.duration_seconds <= 0:
        return 1.0
    return human_dur / record.duration_seconds
