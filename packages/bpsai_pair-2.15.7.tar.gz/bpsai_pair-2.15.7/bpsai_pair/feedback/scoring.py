"""Value extraction scoring algorithm.

Quantifies how much value a user has extracted from PairCoder.
Used server-side for refund abuse detection and locally for testing.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class Recommendation(Enum):
    """Refund recommendation based on value extraction score."""

    APPROVE = "APPROVE"
    REVIEW = "REVIEW"
    FLAG = "FLAG"


@dataclass
class ScoringFactor:
    """Individual factor contributing to the value score."""

    name: str
    raw_value: float
    weighted_score: float
    weight: float

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "name": self.name,
            "raw_value": self.raw_value,
            "weighted_score": self.weighted_score,
            "weight": self.weight,
        }


@dataclass
class ValueScore:
    """Result of value extraction scoring."""

    score: int
    recommendation: Recommendation
    factors: list[ScoringFactor] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "score": self.score,
            "recommendation": self.recommendation.value,
            "factors": [f.to_dict() for f in self.factors],
        }


# Scoring thresholds: tokens per "full points", sessions, hours, tasks
_WEIGHTS = {
    "tokens": {"max_points": 40, "threshold": 100_000, "key": "total_tokens", "weight": 0.4},
    "sessions": {"max_points": 20, "threshold": 10, "key": "sessions", "weight": 0.2},
    "hours": {"max_points": 20, "threshold": 5.0, "key": "hours_active", "weight": 0.2},
    "tasks": {"max_points": 20, "threshold": 40, "key": "tasks_completed", "weight": 0.2},
}

# Timestamp gap threshold (30 days) for anomaly detection
_GAP_THRESHOLD_DAYS = 30


class ValueExtractionScorer:
    """Scores how much value a user has extracted from PairCoder."""

    def score(self, snapshot: dict[str, Any]) -> ValueScore:
        """Compute value extraction score from a snapshot dict.

        Args:
            snapshot: Dict with total_tokens, sessions, hours_active, tasks_completed.

        Returns:
            ValueScore with 0-100 score, recommendation, and factor breakdown.
        """
        factors = _compute_factors(snapshot)
        raw_total = sum(f.weighted_score for f in factors)
        clamped = min(int(raw_total), 100)
        recommendation = _get_recommendation(clamped)
        return ValueScore(score=clamped, recommendation=recommendation, factors=factors)

    def cross_reference(self, snapshots: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Detect tamper patterns across sequential snapshots.

        Args:
            snapshots: List of snapshot dicts ordered chronologically.

        Returns:
            List of anomaly dicts with pattern, severity, and details.
        """
        if len(snapshots) < 2:
            return []

        anomalies: list[dict[str, Any]] = []
        for i in range(1, len(snapshots)):
            prev, curr = snapshots[i - 1], snapshots[i]
            anomalies.extend(_check_pair(prev, curr))
        return anomalies


def _compute_factors(snapshot: dict[str, Any]) -> list[ScoringFactor]:
    """Compute scoring factors from a snapshot dict."""
    factors = []
    for name, cfg in _WEIGHTS.items():
        raw = max(snapshot.get(cfg["key"], 0) or 0, 0)
        ratio = raw / cfg["threshold"] if cfg["threshold"] else 0
        weighted = min(ratio * cfg["max_points"], cfg["max_points"])
        factors.append(ScoringFactor(
            name=name,
            raw_value=raw,
            weighted_score=round(weighted, 2),
            weight=cfg["weight"],
        ))
    return factors


def _get_recommendation(score: int) -> Recommendation:
    """Map score to recommendation."""
    if score < 20:
        return Recommendation.APPROVE
    if score < 50:
        return Recommendation.REVIEW
    return Recommendation.FLAG


def _check_pair(prev: dict, curr: dict) -> list[dict[str, Any]]:
    """Check a pair of snapshots for anomalies."""
    anomalies: list[dict[str, Any]] = []
    _check_decreasing(prev, curr, "total_tokens", "tokens_decreased", "high", anomalies)
    _check_decreasing(prev, curr, "sessions", "sessions_decreased", "medium", anomalies)
    _check_hash_chain(prev, curr, anomalies)
    _check_timestamp_gap(prev, curr, anomalies)
    return anomalies


def _check_decreasing(
    prev: dict, curr: dict, key: str, pattern: str, severity: str,
    anomalies: list[dict[str, Any]],
) -> None:
    """Flag if a monotonic counter decreased between snapshots."""
    p_val = prev.get(key, 0) or 0
    c_val = curr.get(key, 0) or 0
    if not isinstance(p_val, (int, float)) or not isinstance(c_val, (int, float)):
        return
    if c_val < p_val:
        anomalies.append({
            "pattern": pattern,
            "severity": severity,
            "previous": p_val,
            "current": c_val,
        })


def _check_hash_chain(prev: dict, curr: dict, anomalies: list[dict[str, Any]]) -> None:
    """Flag if audit hash chain shows a break.

    The audit_hash is the latest entry_hash from the audit log. It naturally
    changes whenever new telemetry is recorded, so two different non-None
    hashes are normal. A real break is when the hash transitions to/from None
    (chain verification failed during snapshot building, or suspiciously
    recovered).
    """
    prev_hash = prev.get("audit_hash")
    curr_hash = curr.get("audit_hash")
    if (prev_hash is None) != (curr_hash is None):
        anomalies.append({
            "pattern": "hash_chain_break",
            "severity": "high",
            "previous_hash": prev_hash,
            "current_hash": curr_hash,
        })


def _check_timestamp_gap(prev: dict, curr: dict, anomalies: list[dict[str, Any]]) -> None:
    """Flag suspiciously large gaps between snapshot timestamps."""
    prev_ts = prev.get("snapshot_at")
    curr_ts = curr.get("snapshot_at")
    if prev_ts is None or curr_ts is None:
        return
    try:
        if isinstance(prev_ts, str):
            prev_dt = datetime.fromisoformat(prev_ts)
        else:
            prev_dt = prev_ts
        if isinstance(curr_ts, str):
            curr_dt = datetime.fromisoformat(curr_ts)
        else:
            curr_dt = curr_ts
        # Normalize timezone awareness to prevent TypeError on subtraction
        if prev_dt.tzinfo is None and curr_dt.tzinfo is not None:
            prev_dt = prev_dt.replace(tzinfo=timezone.utc)
        elif prev_dt.tzinfo is not None and curr_dt.tzinfo is None:
            curr_dt = curr_dt.replace(tzinfo=timezone.utc)
        gap_days = abs((curr_dt - prev_dt).total_seconds()) / 86400
        if gap_days > _GAP_THRESHOLD_DAYS:
            anomalies.append({
                "pattern": "timestamp_gap",
                "severity": "low",
                "gap_days": round(gap_days, 1),
            })
    except (ValueError, TypeError):
        pass
