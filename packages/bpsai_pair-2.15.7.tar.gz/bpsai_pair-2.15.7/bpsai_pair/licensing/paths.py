"""License file path utilities.

This module provides path resolution for license files.
"""

import os
from pathlib import Path


def get_public_key_path() -> Path:
    """Get the path to the embedded public key."""
    return Path(__file__).parent / "public_key.pem"


def get_license_paths() -> list[Path]:
    """Get ordered list of paths to search for license file.

    Returns paths in priority order:
    1. PAIRCODER_LICENSE env var (if set)
    2. ~/.paircoder/license.json
    3. ./.paircoder/license.json (current directory)
    """
    paths: list[Path] = []

    # 1. Environment variable takes highest precedence
    env_path = os.environ.get("PAIRCODER_LICENSE")
    if env_path:
        paths.append(Path(env_path))

    # 2. User home directory
    home_license = Path.home() / ".paircoder" / "license.json"
    paths.append(home_license)

    # 3. Current working directory
    cwd_license = Path.cwd() / ".paircoder" / "license.json"
    paths.append(cwd_license)

    return paths
