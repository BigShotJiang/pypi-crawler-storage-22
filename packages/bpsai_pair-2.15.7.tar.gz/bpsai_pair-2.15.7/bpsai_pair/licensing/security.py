"""Security utilities for license module.

This module provides security hardening features:
- Rate limiting with exponential backoff
- Secure file permissions
- Cache clearing
- Security event logging
- Constant-time comparison for timing attack protection
"""

import hmac
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Rate limiting constants
MAX_BACKOFF_SECONDS = 300  # 5 minutes maximum
BASE_BACKOFF_SECONDS = 1.0


def _get_paircoder_dir() -> Path:
    """Get the .paircoder directory path."""
    return Path.home() / ".paircoder"


def _get_rate_limit_file() -> Path:
    """Get the rate limit state file path."""
    return _get_paircoder_dir() / "rate_limit.json"


def calculate_backoff_delay(failure_count: int) -> float:
    """Calculate exponential backoff delay based on failure count.

    Args:
        failure_count: Number of consecutive failures.

    Returns:
        Delay in seconds before next retry attempt.
    """
    if failure_count <= 0:
        return 0.0

    # Exponential backoff: 1, 2, 4, 8, 16, 32, 64, 128, 256, 300 (capped)
    delay = BASE_BACKOFF_SECONDS * (2 ** (failure_count - 1))
    return min(delay, MAX_BACKOFF_SECONDS)


def _load_rate_limit_state() -> dict[str, Any]:
    """Load rate limit state from file."""
    rate_file = _get_rate_limit_file()
    if not rate_file.exists():
        return {"failures": 0, "last_failure_at": None}

    try:
        return json.loads(rate_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {"failures": 0, "last_failure_at": None}


def _save_rate_limit_state(state: dict[str, Any]) -> None:
    """Save rate limit state to file with secure permissions."""
    rate_file = _get_rate_limit_file()
    rate_file.parent.mkdir(parents=True, exist_ok=True)

    rate_file.write_text(json.dumps(state, indent=2), encoding="utf-8")
    _set_secure_permissions(rate_file)


def should_rate_limit() -> bool:
    """Check if requests should be rate limited.

    Returns:
        True if currently in backoff period, False otherwise.
    """
    state = _load_rate_limit_state()
    failures = state.get("failures", 0)

    if failures == 0:
        return False

    last_failure = state.get("last_failure_at")
    if not last_failure:
        return False

    try:
        last_failure_dt = datetime.fromisoformat(last_failure)
        backoff = calculate_backoff_delay(failures)
        now = datetime.now(timezone.utc)
        elapsed = (now - last_failure_dt).total_seconds()

        return elapsed < backoff
    except (ValueError, TypeError):
        return False


def record_validation_failure() -> None:
    """Record a validation failure for rate limiting."""
    state = _load_rate_limit_state()
    state["failures"] = state.get("failures", 0) + 1
    state["last_failure_at"] = datetime.now(timezone.utc).isoformat()
    _save_rate_limit_state(state)

    log_security_event(
        "validation_failure",
        {"failure_count": state["failures"]},
    )


def clear_rate_limit() -> None:
    """Clear rate limit state after successful validation."""
    rate_file = _get_rate_limit_file()
    if rate_file.exists():
        rate_file.unlink()


def _set_secure_permissions(file_path: Path) -> None:
    """Set secure file permissions (0o600 = owner read/write only)."""
    try:
        os.chmod(file_path, 0o600)
    except OSError:
        # Log but don't fail - permission errors on some systems
        logger.debug(f"Could not set permissions on {file_path}")


def set_cache_file_permissions(cache_file: Path) -> None:
    """Set secure permissions on cache file.

    Args:
        cache_file: Path to the cache file.
    """
    _set_secure_permissions(cache_file)


def clear_license_cache() -> bool:
    """Clear all license cache files.

    Removes:
    - license_cache.json (validation cache)
    - rate_limit.json (rate limit state)

    Returns:
        True if at least one file was removed, False otherwise.
    """
    paircoder_dir = _get_paircoder_dir()
    removed = False

    cache_file = paircoder_dir / "license_cache.json"
    if cache_file.exists():
        cache_file.unlink()
        removed = True
        log_security_event("cache_cleared", {"file": "license_cache.json"})

    rate_file = paircoder_dir / "rate_limit.json"
    if rate_file.exists():
        rate_file.unlink()
        removed = True
        log_security_event("cache_cleared", {"file": "rate_limit.json"})

    return removed


def log_security_event(event_type: str, details: dict[str, Any]) -> None:
    """Log a security-relevant event.

    Security events are logged in structured format for SIEM integration.

    Args:
        event_type: Type of security event (e.g., "validation_failure").
        details: Additional event details (must not contain sensitive data).
    """
    event = {
        "event_type": event_type,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        **details,
    }
    logger.info(f"security_event: {json.dumps(event)}")


def constant_time_compare(a: str | bytes, b: str | bytes) -> bool:
    """Compare two strings/bytes in constant time.

    Prevents timing attacks by ensuring comparison takes the same
    time regardless of where strings differ.

    Args:
        a: First string/bytes to compare.
        b: Second string/bytes to compare.

    Returns:
        True if equal, False otherwise.
    """
    # Convert strings to bytes for hmac.compare_digest
    if isinstance(a, str):
        a = a.encode("utf-8")
    if isinstance(b, str):
        b = b.encode("utf-8")

    return hmac.compare_digest(a, b)
