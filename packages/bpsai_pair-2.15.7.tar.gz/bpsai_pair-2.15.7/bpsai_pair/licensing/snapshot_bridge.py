"""Bridge between licensing and telemetry modules for snapshot payloads.

Provides safe snapshot building that never fails or blocks license validation.
"""

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _get_project_root() -> Path:
    """Get the current project root (.paircoder directory search)."""
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        if (parent / ".paircoder").is_dir():
            return parent
    return cwd


def _build_snapshot_safe() -> dict[str, Any] | None:
    """Build usage snapshot, returning None on any failure."""
    try:
        from bpsai_pair.telemetry.config import TelemetryConfig
        from bpsai_pair.telemetry.snapshot import build_usage_snapshot
    except ImportError:
        logger.debug("Telemetry modules not available for snapshot")
        return None

    try:
        project_root = _get_project_root()
        config = TelemetryConfig.load(project_root)
        snapshot = build_usage_snapshot(project_root, config.privacy_level)
        return snapshot.to_dict()
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as e:
        logger.warning("Failed to build usage snapshot: %s", e, exc_info=True)
        return None
