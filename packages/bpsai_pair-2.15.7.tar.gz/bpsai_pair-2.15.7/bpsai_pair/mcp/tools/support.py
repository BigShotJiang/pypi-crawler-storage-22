"""MCP support tool for creating tickets mid-session.

Registers paircoder_support_create so Claude Code can file
support tickets on behalf of the developer.
"""

from __future__ import annotations

from typing import Any

from ...support.auth import get_support_jwt
from ...support.client import SupportClient
from ...support.system_info import collect_system_info


def register_support_tools(server: Any) -> None:
    """Register support tools with the MCP server."""

    @server.tool()
    async def paircoder_support_create(
        ticket_type: str,
        title: str,
        description: str = "",
    ) -> dict:
        """Create a support ticket with auto-attached system info.

        Args:
            ticket_type: Ticket type (bug, feature, question, billing, general)
            title: Brief title for the ticket
            description: Detailed description of the issue

        Returns:
            Ticket dict on success, or error dict on failure.
        """
        jwt_result = get_support_jwt()
        if jwt_result is None:
            return {"error": "No license found. Install a license first."}

        sys_info = collect_system_info()
        client = SupportClient(jwt_result["token"])
        ticket = client.create_ticket(
            title=title,
            ticket_type=ticket_type,
            description=description,
            system_info=sys_info,
        )

        if ticket is None:
            return {"error": "Failed to create ticket. Try again later."}

        return ticket
