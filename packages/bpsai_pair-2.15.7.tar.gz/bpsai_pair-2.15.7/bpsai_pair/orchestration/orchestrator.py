"""
Orchestrator service for multi-agent task routing.

Intelligently routes tasks to the most appropriate AI coding agent
based on task characteristics, agent capabilities, cost, and availability.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

import yaml

from .handoff import HandoffManager
from .orchestrator_helpers import (
    analyze_task_file,
    calculate_strength_score,
    execute_with_claude,
    execute_with_planner,
    execute_with_reviewer,
    find_task_file,
)
from .orchestrator_models import (
    AgentCapabilities,
    AgentName,
    Assignment,
    RoutingDecision,
    TaskCharacteristics,
    TaskComplexity,
    TaskScope,
    TaskType,
)
from .planner import should_trigger_planner
from .reviewer import should_trigger_reviewer

logger = logging.getLogger(__name__)


class Orchestrator:
    """
    Orchestrates task routing and execution across multiple AI agents.

    Routes tasks to the most appropriate agent based on capabilities,
    manages handoffs between agents, and monitors execution.
    """

    # Default agent capabilities
    DEFAULT_AGENTS: dict[AgentName, AgentCapabilities] = {
        "claude-code": AgentCapabilities(
            name="claude-code",
            strengths=[
                "complex-reasoning",
                "architecture-design",
                "code-review",
                "documentation",
                "planning",
            ],
            weaknesses=["rapid-iteration", "bulk-file-operations"],
            cost_per_1k_tokens=0.015,
            context_limit=200000,
            availability="local",
        ),
        "cursor": AgentCapabilities(
            name="cursor",
            strengths=["ide-integration", "interactive-editing", "ui-development"],
            weaknesses=["headless-operation", "automation"],
            cost_per_1k_tokens=0.012,
            context_limit=100000,
            availability="optional",
        ),
    }

    def __init__(
        self,
        project_root: Optional[Path] = None,
        capabilities_path: Optional[Path] = None,
        available_agents: Optional[list[AgentName]] = None,
        preferences: Optional[dict[str, Any]] = None,
    ):
        self.project_root = project_root or Path.cwd()
        self.agents = self._load_capabilities(capabilities_path)
        self.available_agents = available_agents or ["claude-code"]
        self.preferences = preferences or {}
        self.sessions: dict[str, Any] = {}
        self.handoff_manager = HandoffManager(project_root=self.project_root)

    def _load_capabilities(
        self, path: Optional[Path] = None
    ) -> dict[AgentName, AgentCapabilities]:
        """Load agent capabilities from config or use defaults."""
        if path and path.exists():
            return self._parse_capabilities_file(path)

        project_config = self._load_project_config()
        orchestration_config = project_config.get("orchestration", {})
        agents_config = orchestration_config.get("agents", {})

        if agents_config:
            return self._parse_agents_config(agents_config)

        return self.DEFAULT_AGENTS.copy()

    def _parse_capabilities_file(self, path: Path) -> dict[AgentName, AgentCapabilities]:
        """Parse capabilities from a YAML file."""
        with open(path, encoding='utf-8') as f:
            data = yaml.safe_load(f)
            return self._parse_agents_config(data.get("agents", {}))

    def _parse_agents_config(self, agents_config: dict) -> dict[AgentName, AgentCapabilities]:
        """Parse agents configuration into AgentCapabilities."""
        agents = {}
        for name, caps in agents_config.items():
            agents[name] = AgentCapabilities(
                name=name,
                strengths=caps.get("strengths", []),
                weaknesses=caps.get("weaknesses", []),
                cost_per_1k_tokens=caps.get("cost_per_1k_tokens", 0.01),
                context_limit=caps.get("context_limit", 200000),
                availability=caps.get("availability", "local"),
            )
        return agents if agents else self.DEFAULT_AGENTS.copy()

    def _load_project_config(self) -> dict:
        """Load project config.yaml."""
        try:
            config_file = self.project_root / ".paircoder" / "config.yaml"
            if config_file.exists():
                with open(config_file, encoding="utf-8") as f:
                    return yaml.safe_load(f) or {}
        except Exception:
            pass
        return {}

    def analyze_task(self, task_id: str) -> TaskCharacteristics:
        """Analyze a task and determine its characteristics."""
        return analyze_task_file(task_id, self.project_root)

    def select_agent(
        self,
        task: TaskCharacteristics,
        constraints: Optional[dict[str, Any]] = None,
    ) -> RoutingDecision:
        """Select the best agent for a task."""
        constraints = constraints or {}
        scores: dict[AgentName, RoutingDecision] = {}

        for agent_name in self.available_agents:
            agent = self.agents.get(agent_name)
            if not agent:
                continue

            score = 0.0
            reasoning = []

            # Strength match (40%)
            strength_score = calculate_strength_score(task, agent)
            score += strength_score * 0.4
            if strength_score > 0.5:
                reasoning.append(f"Good strength match ({strength_score:.2f})")

            # Cost efficiency (20%)
            cost_score = 1.0 - (agent.cost_per_1k_tokens / 0.02)
            score += max(0, cost_score) * 0.2
            if agent.cost_per_1k_tokens < 0.012:
                reasoning.append("Cost efficient")

            # Context fit (20%)
            context_score = 1.0 if task.estimated_tokens < agent.context_limit * 0.8 else 0.5
            score += context_score * 0.2
            if context_score < 1.0:
                reasoning.append("Context may be tight")

            # Availability (10%)
            availability_score = 1.0 if agent.availability == "local" else 0.5
            score += availability_score * 0.1

            # User preference (10%)
            if constraints.get("prefer") == agent_name:
                score += 0.1
                reasoning.append("User preferred")

            scores[agent_name] = RoutingDecision(
                agent=agent_name, score=score, reasoning=reasoning
            )

        best = max(scores.values(), key=lambda x: x.score)
        return best

    def assign_task(
        self,
        task_id: str,
        constraints: Optional[dict[str, Any]] = None,
    ) -> Assignment:
        """Analyze a task and assign it to the best agent."""
        task = self.analyze_task(task_id)
        decision = self.select_agent(task, constraints)

        permission_mode = "auto"
        if task.task_type in [TaskType.DESIGN, TaskType.REVIEW]:
            permission_mode = "plan"

        assignment = Assignment(
            task_id=task_id,
            agent=decision.agent,
            permission_mode=permission_mode,
            score=decision.score,
            reasoning="; ".join(decision.reasoning),
        )

        logger.info(
            f"Assigned {task_id} to {decision.agent} "
            f"(score: {decision.score:.2f}, mode: {permission_mode})"
        )

        return assignment

    def execute(
        self,
        assignment: Assignment,
        dry_run: bool = False,
    ) -> Assignment:
        """Execute a task assignment."""
        if dry_run:
            logger.info(f"[DRY RUN] Would execute {assignment.task_id} with {assignment.agent}")
            assignment.status = "completed"
            assignment.result = {"dry_run": True}
            return assignment

        assignment.status = "running"

        try:
            task = self.analyze_task(assignment.task_id)

            use_planner = should_trigger_planner(
                task_type=task.task_type.value.upper(),
                task_title=task.description,
            )
            use_reviewer = should_trigger_reviewer(
                task_type=task.task_type.value.upper(),
                task_title=task.description,
            )

            if use_planner and assignment.permission_mode == "plan":
                result = self._execute_with_planner(assignment)
            elif use_reviewer and assignment.permission_mode == "plan":
                result = self._execute_with_reviewer(assignment)
            elif assignment.agent == "claude-code":
                result = self._execute_with_claude(assignment)
            else:
                raise ValueError(f"Unknown agent: {assignment.agent}")

            assignment.result = result
            assignment.status = "completed" if result.get("success", False) else "failed"

        except Exception as e:
            logger.error(f"Execution failed: {e}")
            assignment.status = "failed"
            assignment.result = {"error": str(e)}

        return assignment

    def _execute_with_claude(self, assignment: Assignment) -> dict[str, Any]:
        """Execute task with Claude Code."""
        task = self.analyze_task(assignment.task_id)
        return execute_with_claude(assignment, self.project_root, task.description)

    def _execute_with_planner(self, assignment: Assignment) -> dict[str, Any]:
        """Execute a design/planning task with the planner agent."""
        return execute_with_planner(assignment, self.project_root)

    def _execute_with_reviewer(self, assignment: Assignment) -> dict[str, Any]:
        """Execute a code review task with the reviewer agent."""
        return execute_with_reviewer(assignment, self.project_root)

    def _find_task_file(self, task_id: str) -> Optional[Path]:
        """Find the task file for a given task ID."""
        return find_task_file(task_id, self.project_root)

    def handoff(
        self,
        assignment: Assignment,
        target_agent: AgentName,
        conversation_summary: str = "",
    ) -> Assignment:
        """Hand off a task from one agent to another."""
        package_path = self.handoff_manager.pack(
            task_id=assignment.task_id,
            source_agent=assignment.agent,
            target_agent=target_agent,
            conversation_summary=conversation_summary,
        )

        logger.info(f"Created handoff package: {package_path}")

        new_assignment = Assignment(
            task_id=assignment.task_id,
            agent=target_agent,
            reasoning=f"Handoff from {assignment.agent}",
        )

        return new_assignment

    def run(
        self,
        task_ids: list[str],
        constraints: Optional[dict[str, Any]] = None,
        dry_run: bool = False,
    ) -> list[Assignment]:
        """Execute multiple tasks with optimal routing."""
        assignments = []

        for task_id in task_ids:
            assignment = self.assign_task(task_id, constraints)
            if not dry_run:
                assignment = self.execute(assignment, dry_run=dry_run)
            assignments.append(assignment)

        return assignments
