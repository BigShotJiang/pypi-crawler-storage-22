"""
Extracted helpers for orchestrator execution and task analysis.

Contains standalone functions for task file discovery, task analysis,
strength scoring, and agent execution (claude, planner, reviewer).
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Any, Optional

from .headless import HeadlessSession
from .orchestrator_models import (
    AgentCapabilities,
    Assignment,
    TaskCharacteristics,
    TaskComplexity,
    TaskScope,
    TaskType,
)
from .planner import PlannerAgent
from .reviewer import ReviewerAgent

logger = logging.getLogger(__name__)


def find_task_file(task_id: str, project_root: Path) -> Optional[Path]:
    """Find the task file for a given task ID."""
    task_dir = project_root / ".paircoder" / "tasks"
    if not task_dir.exists():
        return None
    for task_file in task_dir.rglob(f"{task_id}*.md"):
        return task_file
    return None


def analyze_task_file(task_id: str, project_root: Path) -> TaskCharacteristics:
    """Analyze a task file and determine its characteristics."""
    task_file = find_task_file(task_id, project_root)

    if not task_file:
        logger.warning(f"Task file not found for {task_id}, using defaults")
        return TaskCharacteristics(task_id=task_id)

    content = task_file.read_text(encoding="utf-8").lower()

    task_type = _detect_task_type(content)
    complexity = _detect_complexity(content)
    scope = _detect_scope(content)
    estimated_tokens = len(content) // 4

    return TaskCharacteristics(
        task_id=task_id,
        task_type=task_type,
        complexity=complexity,
        scope=scope,
        estimated_tokens=estimated_tokens,
        requires_reasoning=task_type in [TaskType.DESIGN, TaskType.REVIEW],
        requires_iteration=task_type in [TaskType.IMPLEMENT, TaskType.REFACTOR],
        description=content[:200],
    )


def _detect_task_type(content: str) -> TaskType:
    """Detect task type from file content."""
    if "design" in content or "architecture" in content:
        return TaskType.DESIGN
    elif "review" in content or "check" in content:
        return TaskType.REVIEW
    elif "refactor" in content:
        return TaskType.REFACTOR
    elif "fix" in content or "bug" in content:
        return TaskType.FIX
    elif "test" in content:
        return TaskType.TEST
    elif "document" in content or "docs" in content:
        return TaskType.DOCUMENT
    return TaskType.IMPLEMENT


def _detect_complexity(content: str) -> TaskComplexity:
    """Detect task complexity from file content."""
    if "simple" in content or "trivial" in content:
        return TaskComplexity.LOW
    elif "complex" in content or "challenging" in content:
        return TaskComplexity.HIGH
    return TaskComplexity.MEDIUM


def _detect_scope(content: str) -> TaskScope:
    """Detect task scope from file content."""
    if "multiple files" in content or "cross-module" in content:
        return TaskScope.CROSS_MODULE
    elif "multi-file" in content or "several files" in content:
        return TaskScope.MULTI_FILE
    return TaskScope.SINGLE_FILE


def calculate_strength_score(
    task: TaskCharacteristics, agent: AgentCapabilities
) -> float:
    """Calculate how well agent strengths match task requirements."""
    task_needs: list[str] = []

    if task.task_type == TaskType.DESIGN:
        task_needs.extend(["architecture-design", "planning", "complex-reasoning"])
    elif task.task_type == TaskType.REVIEW:
        task_needs.extend(["code-review", "complex-reasoning"])
    elif task.task_type == TaskType.REFACTOR:
        task_needs.extend(["refactoring", "file-operations"])
    elif task.task_type == TaskType.IMPLEMENT:
        task_needs.extend(["implementation", "rapid-iteration"])
    elif task.task_type == TaskType.FIX:
        task_needs.extend(["implementation", "rapid-iteration"])

    if task.requires_reasoning:
        task_needs.append("complex-reasoning")
    if task.requires_iteration:
        task_needs.append("rapid-iteration")

    if not task_needs:
        return 0.5

    matches = sum(1 for need in task_needs if need in agent.strengths)
    weaknesses = sum(1 for need in task_needs if need in agent.weaknesses)

    return (matches - weaknesses * 0.5) / len(task_needs)


def execute_with_claude(
    assignment: Assignment, project_root: Path, task_description: str
) -> dict[str, Any]:
    """Execute task with Claude Code."""
    session = HeadlessSession(
        permission_mode=assignment.permission_mode,
        working_dir=project_root,
    )

    prompt = f"Work on {assignment.task_id}: {task_description}"
    response = session.invoke(prompt)

    return {
        "success": not response.is_error,
        "result": response.result,
        "tokens": response.total_tokens,
        "cost": response.cost_usd,
    }


def execute_with_planner(
    assignment: Assignment, project_root: Path
) -> dict[str, Any]:
    """Execute a design/planning task with the planner agent."""
    planner = PlannerAgent(
        agents_dir=project_root / ".claude" / "agents",
        working_dir=project_root,
    )

    task_dir = project_root / ".paircoder"
    context_dir = task_dir / "context"

    plan = planner.plan(
        task_id=assignment.task_id,
        task_dir=task_dir,
        context_dir=context_dir,
    )

    return {
        "success": True,
        "result": plan.raw_output or plan.summary,
        "plan": plan.to_dict(),
        "phases": len(plan.phases),
        "files_to_modify": plan.files_to_modify,
        "complexity": plan.estimated_complexity,
    }


def _get_git_diff(project_root: Path) -> tuple[str, list[str]]:
    """Get git diff and changed files list."""
    try:
        diff_result = subprocess.run(
            ["git", "diff", "HEAD"], cwd=project_root,
            capture_output=True, text=True, timeout=30,
        )
        diff = diff_result.stdout if diff_result.returncode == 0 else ""
        files_result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD"], cwd=project_root,
            capture_output=True, text=True, timeout=30,
        )
        changed = files_result.stdout.strip().split("\n") if files_result.returncode == 0 else []
        return diff, [f for f in changed if f]
    except Exception as e:
        logger.warning(f"Could not get git diff: {e}")
        return "", []


def execute_with_reviewer(
    assignment: Assignment, project_root: Path
) -> dict[str, Any]:
    """Execute a code review task with the reviewer agent."""
    reviewer = ReviewerAgent(
        agents_dir=project_root / ".claude" / "agents",
        working_dir=project_root,
    )
    diff, changed_files = _get_git_diff(project_root)
    output = reviewer.review(
        diff=diff, changed_files=changed_files, include_file_contents=True,
    )
    return {
        "success": True,
        "result": output.raw_output or output.summary,
        "review": output.to_dict(),
        "verdict": output.verdict.value,
        "blockers": output.blocker_count,
        "warnings": output.warning_count,
        "has_blockers": output.has_blockers,
    }
