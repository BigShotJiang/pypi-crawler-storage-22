"""
Security Agent Implementation.

Provides the SecurityAgent class for pre-execution security review.
The security agent operates in read-only mode (permissionMode: plan) and
acts as a gatekeeper that can block unsafe operations.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from .invoker import AgentDefinition, AgentInvoker, InvocationResult
from .security_models import (
    SecurityAction,
    SecurityDecision,
    SecurityFinding,
)

logger = logging.getLogger(__name__)

# Default location for agent definitions
DEFAULT_AGENTS_DIR = ".claude/agents"

# Command patterns for trigger detection
ALWAYS_BLOCKED_PATTERNS = [
    r"rm\s+-rf\s+/(?!\.|tmp)",  # rm -rf / (not ./ or /tmp)
    r"curl\s+.*\|\s*(?:ba)?sh",  # curl | bash
    r"wget\s+.*\|\s*(?:ba)?sh",  # wget | bash
    r"sudo\s+rm",  # sudo rm
]

REQUIRES_REVIEW_PATTERNS = [
    r"pip\s+install",
    r"npm\s+install",
    r"git\s+push",
    r"git\s+commit",
    r"docker\s+",
    r"chmod\s+",
    r"chown\s+",
]

ALWAYS_ALLOWED_PATTERNS = [
    r"^git\s+status$",
    r"^git\s+diff",
    r"^git\s+log",
    r"^pytest\s+",
    r"^bpsai-pair\s+",
    r"^ls\s+",
    r"^cat\s+[^|]*$",  # cat without pipe
    r"^grep\s+",
]

AUTH_KEYWORDS = [
    "auth", "login", "credential", "password", "secret", "token",
    "api key", "apikey", "api_key", "oauth", "jwt",
]


@dataclass
class SecurityAgent:
    """
    Security agent for pre-execution review.

    Uses the AgentInvoker framework to invoke the security agent
    defined in .claude/agents/security.md. Always operates in
    read-only 'plan' permission mode.

    Example:
        >>> agent = SecurityAgent()
        >>> decision = agent.review_command("rm -rf /tmp/test")
        >>> if decision.is_blocked:
        ...     print(f"Blocked: {decision.summary}")

        >>> # Or review code changes
        >>> decision = agent.review_code(diff="...", changed_files=["auth.py"])
        >>> for finding in decision.findings:
        ...     print(f"{finding.severity}: {finding.reason}")
    """

    agents_dir: Path = field(default_factory=lambda: Path(DEFAULT_AGENTS_DIR))
    working_dir: Optional[Path] = None
    timeout_seconds: int = 300
    agent_name: str = "security"
    permission_mode: str = "plan"  # Always read-only

    _invoker: Optional[AgentInvoker] = field(default=None, repr=False)
    _agent_definition: Optional[AgentDefinition] = field(default=None, repr=False)

    def __post_init__(self):
        """Initialize the agent invoker."""
        if not self.agents_dir.is_absolute():
            base = self.working_dir or Path.cwd()
            self.agents_dir = base / self.agents_dir

    def _get_invoker(self) -> AgentInvoker:
        """Get or create the AgentInvoker instance."""
        if self._invoker is None:
            self._invoker = AgentInvoker(
                agents_dir=self.agents_dir,
                working_dir=self.working_dir,
                timeout_seconds=self.timeout_seconds,
            )
        return self._invoker

    def load_agent_definition(self) -> AgentDefinition:
        """Load the security agent definition."""
        if self._agent_definition is None:
            self._agent_definition = self._get_invoker().load_agent(self.agent_name)
        return self._agent_definition

    def build_context(
        self,
        command: str = "",
        diff: str = "",
        changed_files: Optional[list[str]] = None,
        operation_type: str = "review",
    ) -> str:
        """Build context string for security review."""
        context_parts = []

        context_parts.append(f"## Operation Type: {operation_type}")

        if command:
            context_parts.append(f"## Command to Review\n\n```bash\n{command}\n```")

        if diff:
            context_parts.append(f"## Code Diff\n\n```diff\n{diff}\n```")

        if changed_files:
            files_list = "\n".join(f"- {f}" for f in changed_files)
            context_parts.append(f"## Changed Files\n\n{files_list}")

        return "\n\n---\n\n".join(context_parts) if context_parts else "No context provided"

    def invoke(self, prompt: str, **kwargs) -> InvocationResult:
        """Invoke the security agent with a prompt."""
        invoker = self._get_invoker()
        return invoker.invoke(self.agent_name, prompt, **kwargs)

    def review_command(self, command: str) -> SecurityDecision:
        """Review a command for security issues."""
        context = self.build_context(command=command, operation_type="command")

        review_prompt = f"""Review the following command for security issues before execution.

You are a security gatekeeper. Analyze this command and determine:
- Should it be BLOCKED? (dangerous, destructive, leaks secrets)
- Should it require REVIEW? (installs packages, modifies permissions, network ops)
- Is it ALLOWED? (safe, standard development command)

Respond with your decision using the format:
- ## 🛑 BLOCKED: [type] for dangerous commands
- ## ⚠️ REQUIRES REVIEW: [type] for risky commands
- ## ✅ ALLOWED: [type] for safe commands

Include:
- **Reason:** explanation
- **SOC2 Controls:** relevant controls (CC6.1, CC7.1, etc.)
- **To Proceed:** (for blocks) what the user should do instead

---

{context}"""

        result = self.invoke(review_prompt)

        if not result.success:
            logger.error(f"Security review failed: {result.error}")
            return SecurityDecision.block(
                reason=f"Security review failed: {result.error}",
                soc2_controls=["CC6.1"],
                suggested_fixes=["Retry the security review", "Contact administrator"],
            )

        return SecurityDecision.from_raw_text(result.output)

    def review_code(
        self,
        diff: str = "",
        changed_files: Optional[list[str]] = None,
    ) -> SecurityDecision:
        """Review code changes for security issues."""
        context = self.build_context(
            diff=diff,
            changed_files=changed_files,
            operation_type="commit",
        )

        review_prompt = f"""Review the following code changes for security issues before commit.

You are a security gatekeeper. Analyze these changes for:
- Hardcoded secrets (API keys, passwords, tokens)
- Injection vulnerabilities (SQL, command, path traversal)
- Dangerous patterns (unsafe deserialization, RCE vectors)
- Sensitive data in logs or error messages

Respond with your decision using the format:
- ## 🛑 BLOCKED: [type] for security vulnerabilities
- ## ⚠️ REQUIRES REVIEW: [type] for risky patterns
- ## ✅ ALLOWED: [type] for clean code

Include:
- **Reason:** or **Concern:** explanation
- **Detected:** or **Details:** specific issues found
- **SOC2 Controls:** relevant controls
- **To Proceed:** remediation steps

---

{context}"""

        result = self.invoke(review_prompt)

        if not result.success:
            logger.error(f"Security review failed: {result.error}")
            return SecurityDecision.block(
                reason=f"Security review failed: {result.error}",
                soc2_controls=["CC7.1"],
                suggested_fixes=["Retry the security review"],
            )

        return SecurityDecision.from_raw_text(result.output)


def should_trigger_security(
    command: Optional[str] = None,
    task_title: Optional[str] = None,
    pre_commit: bool = False,
    pre_pr: bool = False,
    explicit_request: bool = False,
) -> bool:
    """Determine if the security agent should be triggered."""
    if explicit_request:
        return True

    if pre_commit or pre_pr:
        return True

    if command:
        for pattern in ALWAYS_BLOCKED_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                return True

        for pattern in REQUIRES_REVIEW_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                return True

        for pattern in ALWAYS_ALLOWED_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                return False

    if task_title:
        title_lower = task_title.lower()
        if any(keyword in title_lower for keyword in AUTH_KEYWORDS):
            return True

    return False


def invoke_security(
    command: Optional[str] = None,
    diff: Optional[str] = None,
    changed_files: Optional[list[str]] = None,
    working_dir: Optional[Path] = None,
    agents_dir: Optional[Path] = None,
    timeout: int = 300,
) -> SecurityDecision:
    """Convenience function for invoking the security agent."""
    agent = SecurityAgent(
        agents_dir=agents_dir or Path(DEFAULT_AGENTS_DIR),
        working_dir=working_dir,
        timeout_seconds=timeout,
    )

    if command is not None:
        return agent.review_command(command)

    if diff is not None:
        return agent.review_code(
            diff=diff,
            changed_files=changed_files,
        )

    # Default to allow if nothing to review
    return SecurityDecision.allow()
