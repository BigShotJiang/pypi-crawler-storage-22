"""
Security data models for structured security decisions.

Contains SecurityAction, SecurityFinding, and SecurityDecision —
the core data structures used by the security agent and its callers.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from .security_parser import parse_blocked_section, parse_warning_section


class SecurityAction(Enum):
    """
    Security decision action types.

    Ordering: ALLOW < WARN < BLOCK (by severity)
    """

    ALLOW = "allow"
    WARN = "warn"
    BLOCK = "block"

    def __lt__(self, other: "SecurityAction") -> bool:
        order = [SecurityAction.ALLOW, SecurityAction.WARN, SecurityAction.BLOCK]
        return order.index(self) < order.index(other)

    @classmethod
    def from_string(cls, value: str) -> "SecurityAction":
        """
        Create action from string value.

        Handles various formats:
        - "allow", "allowed", "ok" -> ALLOW
        - "warn", "warning", "review" -> WARN
        - "block", "blocked", "deny", "denied" -> BLOCK
        """
        value_lower = value.lower().strip()

        if value_lower in ("allow", "allowed", "ok", "pass", "passed"):
            return cls.ALLOW
        elif value_lower in ("warn", "warning", "review", "caution"):
            return cls.WARN
        elif value_lower in ("block", "blocked", "deny", "denied", "reject", "rejected"):
            return cls.BLOCK

        # Default to BLOCK for safety (fail safe)
        return cls.BLOCK


@dataclass
class SecurityFinding:
    """
    A single security finding.

    Represents a security issue or concern found during review
    with severity, SOC2 control references, and suggested fixes.
    """

    action: SecurityAction
    severity: str  # critical, high, medium, low
    reason: str
    details: list[str] = field(default_factory=list)
    soc2_controls: list[str] = field(default_factory=list)
    suggested_fixes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "action": self.action.value,
            "severity": self.severity,
            "reason": self.reason,
            "details": self.details,
            "soc2_controls": self.soc2_controls,
            "suggested_fixes": self.suggested_fixes,
        }


@dataclass
class SecurityDecision:
    """
    Structured output from the security agent.

    Contains the overall decision (ALLOW/WARN/BLOCK), individual findings,
    and summary information for audit logging.
    """

    action: SecurityAction
    findings: list[SecurityFinding] = field(default_factory=list)
    summary: str = ""
    raw_output: str = ""

    @property
    def is_allowed(self) -> bool:
        """Check if the operation is allowed to proceed."""
        return self.action == SecurityAction.ALLOW

    @property
    def is_blocked(self) -> bool:
        """Check if the operation is blocked."""
        return self.action == SecurityAction.BLOCK

    @property
    def has_warnings(self) -> bool:
        """Check if the decision has any warnings."""
        return self.action == SecurityAction.WARN or any(
            f.action == SecurityAction.WARN for f in self.findings
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "action": self.action.value,
            "is_allowed": self.is_allowed,
            "is_blocked": self.is_blocked,
            "has_warnings": self.has_warnings,
            "findings": [f.to_dict() for f in self.findings],
            "summary": self.summary,
        }

    @classmethod
    def allow(cls, summary: str = "Security checks passed.") -> "SecurityDecision":
        """Create an allowed decision with no issues."""
        return cls(
            action=SecurityAction.ALLOW,
            findings=[],
            summary=summary,
        )

    @classmethod
    def block(
        cls,
        reason: str,
        soc2_controls: Optional[list[str]] = None,
        suggested_fixes: Optional[list[str]] = None,
        details: Optional[list[str]] = None,
        severity: str = "critical",
    ) -> "SecurityDecision":
        """Create a blocked decision with reason."""
        finding = SecurityFinding(
            action=SecurityAction.BLOCK,
            severity=severity,
            reason=reason,
            details=details or [],
            soc2_controls=soc2_controls or [],
            suggested_fixes=suggested_fixes or [],
        )
        return cls(
            action=SecurityAction.BLOCK,
            findings=[finding],
            summary=f"BLOCKED: {reason}",
        )

    @classmethod
    def warn(
        cls,
        reason: str,
        soc2_controls: Optional[list[str]] = None,
        suggested_fixes: Optional[list[str]] = None,
        details: Optional[list[str]] = None,
        severity: str = "medium",
    ) -> "SecurityDecision":
        """Create a warning decision requiring review."""
        finding = SecurityFinding(
            action=SecurityAction.WARN,
            severity=severity,
            reason=reason,
            details=details or [],
            soc2_controls=soc2_controls or [],
            suggested_fixes=suggested_fixes or [],
        )
        return cls(
            action=SecurityAction.WARN,
            findings=[finding],
            summary=f"REQUIRES REVIEW: {reason}",
        )

    @classmethod
    def from_raw_text(cls, raw_text: str) -> "SecurityDecision":
        """Parse security decision from raw markdown output."""
        findings: list[SecurityFinding] = []
        summary = ""
        action = SecurityAction.ALLOW

        blocked = parse_blocked_section(raw_text)
        if blocked:
            action = SecurityAction.BLOCK
            summary = blocked["summary"]
            findings.append(SecurityFinding(
                action=SecurityAction.BLOCK, severity="critical",
                reason=blocked["reason"], details=blocked["details"],
                soc2_controls=blocked["soc2_controls"],
                suggested_fixes=blocked["suggested_fixes"],
            ))

        warned = parse_warning_section(raw_text)
        if warned and action != SecurityAction.BLOCK:
            action = SecurityAction.WARN
            summary = warned["summary"]
            findings.append(SecurityFinding(
                action=SecurityAction.WARN, severity=warned["severity"],
                reason=warned["reason"], details=warned["details"],
                soc2_controls=warned["soc2_controls"],
            ))

        if action == SecurityAction.ALLOW:
            allowed_match = re.search(
                r"##\s*✅\s*ALLOWED[:\s]*(.*?)(?:\n|$)",
                raw_text, re.IGNORECASE,
            )
            if allowed_match:
                summary = "Security checks passed."

        return cls(
            action=action,
            findings=findings,
            summary=summary or "Security review complete.",
            raw_output=raw_text,
        )

    def format_message(self) -> str:
        """Format the decision as a human-readable message."""
        lines = []

        if self.is_blocked:
            lines.append(f"🛑 {self.summary}")
            for finding in self.findings:
                if finding.action == SecurityAction.BLOCK:
                    lines.append(f"\nReason: {finding.reason}")
                    if finding.details:
                        lines.append("Detected:")
                        for detail in finding.details:
                            lines.append(f"  - {detail}")
                    if finding.soc2_controls:
                        lines.append(f"SOC2 Controls: {', '.join(finding.soc2_controls)}")
                    if finding.suggested_fixes:
                        lines.append("To Proceed:")
                        for fix in finding.suggested_fixes:
                            lines.append(f"  - {fix}")

        elif self.has_warnings:
            lines.append(f"⚠️ {self.summary}")
            for finding in self.findings:
                if finding.action == SecurityAction.WARN:
                    lines.append(f"\nConcern: {finding.reason}")
                    if finding.details:
                        lines.append("Details:")
                        for detail in finding.details:
                            lines.append(f"  - {detail}")
                    if finding.soc2_controls:
                        lines.append(f"SOC2 Controls: {', '.join(finding.soc2_controls)}")

        else:
            lines.append(f"✅ {self.summary}")

        return "\n".join(lines)


