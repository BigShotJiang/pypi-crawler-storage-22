"""
Security decision parsing from raw markdown output.

Extracts structured data from the security agent's markdown-formatted
responses. Returns plain dicts to avoid circular imports with security_models.
"""

from __future__ import annotations

import re


def parse_blocked_section(raw_text: str) -> dict | None:
    """Parse a BLOCKED section from raw markdown.

    Returns dict with keys: summary, reason, details, soc2_controls,
    suggested_fixes — or None if no blocked section found.
    """
    blocked_match = re.search(
        r"##\s*🛑\s*BLOCKED[:\s]*(.*?)(?:\n|$)", raw_text, re.IGNORECASE,
    )
    if not blocked_match:
        return None

    summary = f"BLOCKED: {blocked_match.group(1).strip()}"
    reason_match = re.search(
        r"\*\*Reason:\*\*\s*(.*?)(?:\n\n|\n\*\*|$)",
        raw_text, re.DOTALL | re.IGNORECASE,
    )
    reason = reason_match.group(1).strip() if reason_match else "Security issue detected"

    details = extract_list_items(raw_text, r"\*\*Detected:\*\*")
    soc2_controls = extract_soc2_controls(raw_text)

    fixes_match = re.search(
        r"\*\*To Proceed:\*\*\s*(.*?)(?:\n##|\Z)", raw_text, re.DOTALL | re.IGNORECASE,
    )
    suggested_fixes = [fixes_match.group(1).strip()] if fixes_match else []

    return {
        "summary": summary,
        "reason": reason,
        "details": details,
        "soc2_controls": soc2_controls,
        "suggested_fixes": suggested_fixes,
    }


def parse_warning_section(raw_text: str) -> dict | None:
    """Parse a REQUIRES REVIEW section from raw markdown.

    Returns dict with keys: summary, reason, details, soc2_controls,
    severity — or None if no warning section found.
    """
    warn_match = re.search(
        r"##\s*⚠️\s*REQUIRES\s*REVIEW[:\s]*(.*?)(?:\n|$)", raw_text, re.IGNORECASE,
    )
    if not warn_match:
        return None

    summary = f"REQUIRES REVIEW: {warn_match.group(1).strip()}"
    concern_match = re.search(
        r"\*\*Concern:\*\*\s*(.*?)(?:\n\n|\n\*\*|$)",
        raw_text, re.DOTALL | re.IGNORECASE,
    )
    reason = concern_match.group(1).strip() if concern_match else "Requires review"

    details = extract_list_items(raw_text, r"\*\*Details:\*\*")
    soc2_controls = extract_soc2_controls(raw_text)

    risk_match = re.search(
        r"\*\*Risk\s*Level:\*\*\s*(\w+)", raw_text, re.IGNORECASE,
    )
    severity = risk_match.group(1).lower() if risk_match else "medium"

    return {
        "summary": summary,
        "reason": reason,
        "details": details,
        "soc2_controls": soc2_controls,
        "severity": severity,
    }


def extract_list_items(text: str, header_pattern: str) -> list[str]:
    """Extract list items following a header."""
    items = []
    header_match = re.search(
        f"{header_pattern}\\s*(.*?)(?:\\n\\*\\*|\\n##|\\Z)",
        text, re.DOTALL | re.IGNORECASE,
    )
    if header_match:
        content = header_match.group(1)
        for line in content.split("\n"):
            line = line.strip()
            if line.startswith("-") or line.startswith("*"):
                items.append(line.lstrip("-*").strip())
    return items


def extract_soc2_controls(text: str) -> list[str]:
    """Extract SOC2 control references from text."""
    controls = []
    soc2_match = re.search(
        r"\*\*SOC2\s*Controls?:\*\*\s*(.*?)(?:\n\n|\n\*\*|$)",
        text, re.IGNORECASE,
    )
    if soc2_match:
        controls_text = soc2_match.group(1)
        controls = re.findall(r"CC\d+\.\d+", controls_text)
    return controls
