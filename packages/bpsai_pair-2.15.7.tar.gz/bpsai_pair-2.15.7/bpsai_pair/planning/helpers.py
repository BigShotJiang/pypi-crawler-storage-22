"""Shared helper functions for planning commands.

Utilities extracted from commands.py for better code organization.
"""

from datetime import datetime
from pathlib import Path
from typing import Optional, TYPE_CHECKING
import json
import re

from rich.console import Console

if TYPE_CHECKING:
    from .models import Task
    from .parser import TaskParser
    from .state import StateManager

# Shared console instance for all planning commands
console = Console()


def find_paircoder_dir() -> Path:
    """Find .paircoder directory in current or parent directories."""
    from ..core.ops import find_paircoder_dir as _find_paircoder_dir
    return _find_paircoder_dir()


def get_state_manager() -> "StateManager":
    """Get a StateManager instance for the current project."""
    from .state import StateManager
    return StateManager(find_paircoder_dir())


def is_trello_enabled() -> bool:
    """Check if Trello is enabled in config (trello.enabled + board_id)."""
    try:
        paircoder_dir = find_paircoder_dir()
        config_path = paircoder_dir / "config.yaml"
        if not config_path.exists():
            return False

        import yaml
        with open(config_path, encoding='utf-8') as f:
            config = yaml.safe_load(f) or {}

        trello_config = config.get("trello", {})
        return trello_config.get("enabled", False) and trello_config.get("board_id")
    except Exception:
        return False


def get_linked_trello_card(task_id: str) -> Optional[str]:
    """Get Trello card ID from task's frontmatter (trello_card_id or trello_url)."""
    from .parser import TaskParser, parse_frontmatter

    try:
        paircoder_dir = find_paircoder_dir()
        task_parser = TaskParser(paircoder_dir / "tasks")

        # Find the task file
        task = task_parser.get_task_by_id(task_id)
        if not task or not task.source_path:
            return None

        # Read the task file to get frontmatter
        with open(task.source_path, "r", encoding="utf-8") as f:
            content = f.read()

        # Parse frontmatter
        frontmatter, _ = parse_frontmatter(content)
        if not frontmatter:
            return None

        # Check for trello_card_id
        if "trello_card_id" in frontmatter:
            card_id = frontmatter["trello_card_id"]
            # Format as TRELLO-XXX if it's just a number
            if isinstance(card_id, (int, str)):
                card_str = str(card_id)
                if card_str.isdigit():
                    return f"TRELLO-{card_str}"
                elif card_str.startswith("TRELLO-"):
                    return card_str
                else:
                    return card_str  # Return as-is (could be shortLink)

        # Check for trello_url
        if "trello_url" in frontmatter:
            url = frontmatter["trello_url"]
            # Extract ID from URL like https://trello.com/c/ABC123/...
            match = re.search(r'/c/([^/]+)', url)
            if match:
                return match.group(1)

        return None
    except Exception:
        return None


def log_bypass(command: str, task_id: str, reason: str = "forced") -> None:
    """Log bypass to .paircoder/history/bypass_log.jsonl for audit."""
    try:
        paircoder_dir = find_paircoder_dir()
        log_path = paircoder_dir / "history" / "bypass_log.jsonl"
        log_path.parent.mkdir(parents=True, exist_ok=True)

        entry = {
            "timestamp": datetime.now().isoformat(),
            "command": command,
            "task_id": task_id,
            "reason": reason,
        }

        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass  # Best effort logging



def check_for_manual_edits(paircoder_dir: Path, tasks: list) -> list:
    """Detect manual edits by comparing file status with CLI cache."""
    import os
    from .cli_update_cache import get_cli_update_cache, detect_manual_edit

    cli_cache = get_cli_update_cache(paircoder_dir)
    manual_edits = []

    for task in tasks:
        # Get task file path
        task_file = paircoder_dir / "tasks" / f"{task.id}.task.md"
        if not task_file.exists():
            continue

        # Get file modification time
        file_mtime = datetime.fromtimestamp(os.path.getmtime(task_file))

        # Check for manual edit
        result = detect_manual_edit(
            cache=cli_cache,
            task_id=task.id,
            file_mtime=file_mtime,
            current_status=task.status.value,
        )

        if result["detected"]:
            manual_edits.append({
                "task_id": task.id,
                "current_status": result["current_status"],
                "last_cli_status": result["last_cli_status"],
                "last_cli_update": result["last_cli_update"],
                "file_mtime": result["file_mtime"],
            })

    return manual_edits


def show_time_tracking(task: "Task", paircoder_dir: Path) -> None:
    """Display estimated vs actual hours with variance for a task."""
    # Always show estimated hours
    estimate = task.estimated_hours
    console.print(f"\n[cyan]Estimated:[/cyan] {estimate.expected_hours:.1f}h ({estimate.size_band.upper()}) [{estimate.min_hours:.1f}h - {estimate.max_hours:.1f}h]")

    # Try to get actual hours from time tracking
    actual_hours = task.get_actual_hours(paircoder_dir)

    if actual_hours is not None:
        # Calculate variance
        variance_hours = actual_hours - estimate.expected_hours
        if estimate.expected_hours > 0:
            variance_percent = (variance_hours / estimate.expected_hours) * 100
        else:
            variance_percent = 0.0

        console.print(f"[cyan]Actual:[/cyan] {actual_hours:.1f}h")

        # Show variance with color coding
        sign = "+" if variance_hours > 0 else ""
        if abs(variance_percent) <= 10:
            color = "green"  # Accurate estimate
        elif variance_hours > 0:
            color = "red"  # Took longer than estimated
        else:
            color = "yellow"  # Finished early

        console.print(f"[cyan]Variance:[/cyan] [{color}]{sign}{variance_hours:.1f}h ({sign}{variance_percent:.1f}%)[/{color}]")


def populate_files_touched(task: "Task", tasks_dir: Path) -> None:
    """Parse files_touched from task file's Files section."""
    # Find task file
    task_file = None
    for ext in [".task.md", ".md"]:
        candidate = tasks_dir / f"{task.id}{ext}"
        if candidate.exists():
            task_file = candidate
            break

    if not task_file:
        task.files_touched = []
        return

    try:
        content = task_file.read_text(encoding="utf-8")

        # Find "Files to Modify" section
        files = []
        in_files_section = False

        for line in content.split("\n"):
            line_stripped = line.strip()

            # Check for section header
            if line_stripped.startswith("# Files") or line_stripped.startswith("## Files"):
                in_files_section = True
                continue

            # Check for next section
            if in_files_section and line_stripped.startswith("#"):
                break

            # Parse file entries
            if in_files_section and line_stripped.startswith("- "):
                file_path = line_stripped[2:].strip()
                # Handle backticks around file paths
                file_path = file_path.strip("`")
                if file_path:
                    files.append(file_path)

        task.files_touched = files
    except Exception:
        task.files_touched = []


def update_task_with_card_id(task: "Task", card_id: str, task_parser: "TaskParser") -> bool:
    """Insert trello_card_id into task file's frontmatter."""
    try:
        # Find task file - use source_path if available, otherwise search
        task_file = None
        if hasattr(task, 'source_path') and task.source_path:
            task_file = task.source_path
        else:
            # Search for task file in tasks directory
            for ext in [".task.md", ".md"]:
                candidate = task_parser.tasks_dir / f"{task.id}{ext}"
                if candidate.exists():
                    task_file = candidate
                    break

        if not task_file or not task_file.exists():
            return False

        content = task_file.read_text(encoding="utf-8")

        # Insert trello_card_id into frontmatter
        if "trello_card_id:" not in content:
            # Find end of frontmatter
            lines = content.split("\n")
            new_lines = []
            in_frontmatter = False
            inserted = False

            for line in lines:
                if line.strip() == "---":
                    if in_frontmatter and not inserted:
                        # Insert before closing ---
                        new_lines.append(f'trello_card_id: "{card_id}"')
                        inserted = True
                    in_frontmatter = not in_frontmatter
                new_lines.append(line)

            task_file.write_text("\n".join(new_lines), encoding="utf-8")
            return True

        return False
    except Exception:
        return False
