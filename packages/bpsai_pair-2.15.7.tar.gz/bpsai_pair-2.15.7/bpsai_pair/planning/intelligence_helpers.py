"""Shared helpers for intelligence modules.

Small utility functions used by plan_intelligence.py and
potentially other intelligence-related modules.
"""

from __future__ import annotations


def _complexity_to_label(complexity: int) -> str:
    """Convert numeric complexity to label for model recommendation."""
    if complexity <= 20:
        return "low"
    if complexity <= 50:
        return "medium"
    return "high"


def _compute_confidence(total_records: int) -> str:
    """Compute confidence level from record count."""
    if total_records >= 20:
        return "high"
    if total_records >= 5:
        return "medium"
    if total_records >= 1:
        return "low"
    return "none"
