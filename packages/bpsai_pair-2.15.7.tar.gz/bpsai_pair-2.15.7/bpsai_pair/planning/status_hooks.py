"""Hook execution and display for task status changes.

Extracted from helpers.py for architecture compliance.
Handles running status-change hooks and displaying results
(Trello sync, timer, budget).
"""

from pathlib import Path
from typing import TYPE_CHECKING

from . import helpers as _helpers

if TYPE_CHECKING:
    from .models import Task

_STATUS_TO_EVENT = {
    "in_progress": "on_task_start",
    "review": "on_task_review",
    "done": "on_task_complete",
    "blocked": "on_task_block",
}


def _display_hook_result(result) -> None:
    """Display a single successful hook result to the user."""
    data = result.result
    if not data:
        return
    if data.get("trello_synced"):
        target_list = data.get("target_list", "")
        _helpers.console.print(f"  [dim]\u2192 Trello: moved to '{target_list}'[/dim]")
    elif data.get("timer_started"):
        _helpers.console.print("  [dim]\u2192 Timer started[/dim]")
    elif data.get("timer_stopped"):
        fd = data.get("formatted_duration", "")
        ft = data.get("formatted_total", "")
        if fd and ft:
            _helpers.console.print(f"  [dim]\u2192 Timer stopped: {fd} (total: {ft})[/dim]")
        else:
            dur = data.get("duration_seconds", 0)
            _helpers.console.print(f"  [dim]\u2192 Timer stopped ({dur:.0f}s)[/dim]")
    elif data.get("routed_model"):
        model = data["routed_model"]
        dd = " (data-driven)" if data.get("data_driven") else ""
        _helpers.console.print(f"  [dim]\u2192 Model: {model}{dd}[/dim]")
    elif data.get("budget_checked"):
        tokens = data.get("estimated_tokens", 0)
        pct = data.get("budget_percent", 0)
        cost = (tokens / 1000) * 0.015
        over = data.get("over_threshold", False)
        if over:
            _helpers.console.print(
                f"  [yellow]\u2192 Budget: ~{tokens:,} tokens (~${cost:.2f}) \u2014 "
                f"{pct:.0f}% of limit[/yellow]"
            )
        else:
            _helpers.console.print(
                f"  [dim]\u2192 Budget: ~{tokens:,} tokens (~${cost:.2f})[/dim]"
            )


def _report_hook_results(results) -> None:
    """Display results from hook execution."""
    for result in results:
        if result.success:
            _display_hook_result(result)
        elif result.error and "Not connected" not in result.error:
            _helpers.console.print(f"  [yellow]\u2192 {result.hook}: {result.error}[/yellow]")


def run_status_hooks(
    paircoder_dir: Path,
    task_id: str,
    new_status: str,
    task: "Task",
    outcome=None,
    error_context: str | None = None,
) -> None:
    """Trigger hooks (timer, Trello) based on task status change."""
    telemetry_record = None
    if new_status == "done":
        telemetry_record = _collect_task_telemetry(
            task_id, task, paircoder_dir,
            outcome=outcome, error_context=error_context,
        )

    try:
        from ..core.hooks import HookRunner, HookContext, load_config

        config = load_config(paircoder_dir)
        runner = HookRunner(config, paircoder_dir)
        if not runner.enabled:
            return

        event = _STATUS_TO_EVENT.get(new_status)
        if not event:
            return

        extra = {"summary": f"Task updated to {new_status}"}
        if telemetry_record is not None:
            extra["telemetry_record"] = telemetry_record
        ctx = HookContext(
            task_id=task_id, task=task, event=event,
            agent="cli", extra=extra,
        )
        _report_hook_results(runner.run_hooks(event, ctx))

    except ImportError:
        pass  # Hooks module not available
    except Exception as e:
        _helpers.console.print(f"  [yellow]\u2192 Hooks error: {e}[/yellow]")


def _get_estimation_fields_from_task(
    task_id: str, task: "Task", paircoder_dir: Path,
) -> dict:
    """Extract estimation metadata from task object and time cache."""
    fields = {"task_type": task.type if task else "unknown",
              "estimated_tokens": None, "estimated_hours": None,
              "actual_hours": None, "estimated_complexity": None}
    try:
        if task:
            fields["estimated_tokens"] = task.estimated_tokens.total_tokens
            fields["estimated_complexity"] = task.complexity
            fields["estimated_hours"] = task.estimated_hours.expected_hours
    except Exception:
        pass
    try:
        from ..integrations.time_tracking import LocalTimeCache
        cache_path = paircoder_dir / "time-tracking-cache.json"
        if cache_path.exists():
            hrs = LocalTimeCache(cache_path).get_total(task_id).total_seconds() / 3600
            if hrs > 0:
                fields["actual_hours"] = hrs
    except Exception:
        pass
    return fields


def _collect_task_telemetry(
    task_id: str,
    task: "Task",
    paircoder_dir: Path,
    outcome=None,
    error_context: str | None = None,
) -> dict | None:
    """Collect telemetry for a completed task (non-blocking).

    Returns:
        The telemetry record as a dict, or None if collection failed.
    """
    import logging
    logger = logging.getLogger(__name__)

    try:
        from ..telemetry.collector import TelemetryCollector
        from ..telemetry.schema import Outcome

        if outcome is None:
            outcome = Outcome.SUCCESS

        fields = _get_estimation_fields_from_task(task_id, task, paircoder_dir)
        project_root = paircoder_dir.parent
        collector = TelemetryCollector(project_root)
        result = collector.collect_for_task(
            task_id, fields["task_type"], outcome,
            estimated_tokens=fields["estimated_tokens"],
            error_context=error_context,
            estimated_hours=fields["estimated_hours"],
            actual_hours=fields["actual_hours"],
            estimated_complexity=fields["estimated_complexity"],
        )

        if result:
            logger.debug("Telemetry collected for task %s", task_id)
            return result.to_dict()
        return None
    except Exception as e:
        # Never fail task completion due to telemetry errors
        logger.debug("Telemetry collection skipped: %s", e)
