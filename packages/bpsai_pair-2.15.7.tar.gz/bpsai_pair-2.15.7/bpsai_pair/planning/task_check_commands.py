"""Task acceptance criteria check commands.

Commands for viewing and toggling AC items on tasks.
"""
from typing import Optional

import typer

from .parser import PlanParser, TaskParser
from .helpers import console, find_paircoder_dir


def task_check(
    task_id: str = typer.Argument(..., help="Task ID"),
    item_text: str = typer.Argument(
        None,
        help="Text of AC item to check (partial match). Omit to list all AC items."
    ),
    uncheck: bool = typer.Option(False, "--uncheck", "-u", help="Uncheck instead of check"),
    plan_id: Optional[str] = typer.Option(None, "--plan", "-p", help="Plan ID to narrow search"),
):
    """Check or uncheck acceptance criteria items.

    Use without item_text to list all AC items and their status.
    Use with item_text to check/uncheck a specific item (partial text match).

    Examples:
        bpsai-pair task check T29.6.3                        # List all AC items
        bpsai-pair task check T29.6.3 "tests pass"           # Check item containing "tests pass"
        bpsai-pair task check T29.6.3 "tests pass" --uncheck # Uncheck item
    """
    paircoder_dir = find_paircoder_dir()
    task_parser = TaskParser(paircoder_dir / "tasks")
    plan_parser = PlanParser(paircoder_dir / "plans")

    plan_slug = None
    if plan_id:
        plan = plan_parser.get_plan_by_id(plan_id)
        if plan:
            plan_slug = plan.slug

    task = task_parser.get_task_by_id(task_id, plan_slug)
    if not task:
        console.print(f"[red]Task not found: {task_id}[/red]")
        raise typer.Exit(1)

    ac_items = task.acceptance_criteria
    if not ac_items:
        console.print(f"[yellow]No acceptance criteria found in task {task_id}[/yellow]")
        console.print("[dim]AC items should be in the task file under '# Acceptance Criteria'[/dim]")
        console.print("[dim]Format: - [ ] Item text[/dim]")
        return

    if not item_text:
        _list_ac_items(task_id, ac_items)
        return

    _toggle_ac_item(task_parser, task_id, item_text, uncheck, plan_slug)


def _list_ac_items(task_id, ac_items):
    """Display all AC items and their status."""
    console.print(f"[bold]Acceptance Criteria for {task_id}[/bold]")
    console.print(f"{'=' * 50}")
    for ac in ac_items:
        check = "✓" if ac.checked else "○"
        color = "green" if ac.checked else "dim"
        console.print(f"  [{color}]{check}[/{color}] {ac.text}")

    unchecked_count = len([ac for ac in ac_items if not ac.checked])
    if unchecked_count > 0:
        console.print(f"\n[yellow]{unchecked_count} item(s) unchecked[/yellow]")
    else:
        console.print(f"\n[green]All {len(ac_items)} item(s) checked ✓[/green]")


def _toggle_ac_item(task_parser, task_id, item_text, uncheck, plan_slug):
    """Check or uncheck a specific AC item."""
    success = task_parser.update_ac_item(task_id, item_text, not uncheck, plan_slug)

    if success:
        action = "Unchecked" if uncheck else "Checked"
        console.print(f"[green]✓ {action}: {item_text}[/green]")

        task = task_parser.get_task_by_id(task_id, plan_slug)
        if task:
            unchecked = task.unchecked_ac
            if not unchecked:
                console.print("[green]All acceptance criteria now verified![/green]")
            else:
                console.print(f"[dim]{len(unchecked)} item(s) remaining[/dim]")
    else:
        console.print(f"[red]Item not found matching: {item_text}[/red]")
        console.print("[dim]Use 'bpsai-pair task check {task_id}' to see all items[/dim]")
        raise typer.Exit(1)


def task_ac(
    task_id: str = typer.Argument(..., help="Task ID"),
    plan_id: Optional[str] = typer.Option(None, "--plan", "-p", help="Plan ID to narrow search"),
):
    """Show acceptance criteria status for a task.

    Alias for 'task check <task_id>' without an item.
    """
    task_check(task_id=task_id, item_text=None, uncheck=False, plan_id=plan_id)
