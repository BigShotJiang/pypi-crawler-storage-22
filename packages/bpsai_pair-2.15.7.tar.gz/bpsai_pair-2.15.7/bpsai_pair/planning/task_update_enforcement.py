"""Enforcement gates for task update --status done.

Pre-flight checks that block task completion when enforcement
conditions are not met. Each function either passes silently
or raises typer.Exit(1) to block.
"""
from pathlib import Path
from typing import Optional

import typer

from .helpers import (
    console,
    get_linked_trello_card,
    is_trello_enabled,
    log_bypass,
)


def _is_strict_ac_enabled(paircoder_dir: Path) -> bool:
    """Check if strict_ac_verification is enabled in config."""
    import yaml

    config_path = paircoder_dir / "config.yaml"
    if not config_path.exists():
        return False
    with open(config_path, encoding='utf-8') as f:
        config = yaml.safe_load(f) or {}
    return config.get("enforcement", {}).get("strict_ac_verification", False)


def enforce_local_only_block(paircoder_dir: Path, task_id: str) -> None:
    """Block --local-only when strict_ac_verification is enabled."""
    if not _is_strict_ac_enabled(paircoder_dir):
        return
    console.print("\n[red]❌ BLOCKED: --local-only is disabled when strict_ac_verification is enabled.[/red]")
    console.print("")
    console.print("[yellow]Use the proper Trello workflow:[/yellow]")
    console.print("  [cyan]bpsai-pair ttask done <TRELLO-ID> --summary \"...\"[/cyan]")
    console.print("")
    console.print("To find the Trello card ID:")
    console.print("  [cyan]bpsai-pair ttask list[/cyan]")
    console.print("")
    console.print("[dim]This ensures acceptance criteria are verified before completion.[/dim]")
    raise typer.Exit(1)


def enforce_no_hooks_block(paircoder_dir: Path) -> None:
    """Block --no-hooks when completing tasks in strict mode."""
    if not _is_strict_ac_enabled(paircoder_dir):
        return
    console.print("\n[red]❌ BLOCKED: --no-hooks is disabled when completing tasks in strict mode.[/red]")
    console.print("")
    console.print("[yellow]Hooks ensure proper workflow:[/yellow]")
    console.print("  - Trello card sync")
    console.print("  - Timer tracking")
    console.print("  - Metrics recording")
    console.print("")
    console.print("[dim]Use the proper Trello workflow instead:[/dim]")
    console.print("  [cyan]bpsai-pair ttask done <TRELLO-ID> --summary \"...\"[/cyan]")
    raise typer.Exit(1)


def enforce_trello_card_redirect(
    task_id: str, force_local: bool
) -> None:
    """Block completion if task has linked Trello card (unless --force-local)."""
    trello_card_id = get_linked_trello_card(task_id)
    if trello_card_id and not force_local:
        console.print(f"\n[red]❌ BLOCKED: Task has linked Trello card {trello_card_id}[/red]")
        console.print("")
        console.print("[yellow]Complete via Trello:[/yellow]")
        console.print(f"  [cyan]bpsai-pair ttask done {trello_card_id} --summary \"...\"[/cyan]")
        console.print("")
        console.print("[dim]This ensures acceptance criteria are verified.[/dim]")
        console.print("[dim]Or use --force-local to bypass (logged for audit).[/dim]")
        raise typer.Exit(1)

    elif trello_card_id and force_local:
        log_bypass("task update --force-local", task_id, f"Bypassed Trello card redirect ({trello_card_id})")
        console.print(f"[yellow]⚠ Bypassing Trello card redirect for {trello_card_id} (logged)[/yellow]")

    elif is_trello_enabled():
        console.print(
            "\n[yellow]⚠ Note: Trello is enabled but this task has no linked card. "
            "Completing locally.[/yellow]"
        )


def enforce_skip_state_check_block(paircoder_dir: Path, task_id: str) -> None:
    """Block --skip-state-check when strict_ac_verification is enabled."""
    if not _is_strict_ac_enabled(paircoder_dir):
        return
    console.print(
        "\n[red]❌ BLOCKED: --skip-state-check is disabled when strict_ac_verification is enabled.[/red]")
    console.print("")
    console.print("[yellow]You must update state.md before completing tasks:[/yellow]")
    console.print("  1. Edit [cyan].paircoder/context/state.md[/cyan]")
    console.print(f"  2. Mark [yellow]{task_id}[/yellow] as done in task list")
    console.print("  3. Add session entry under \"What Was Just Done\"")
    console.print("  4. Update \"What's Next\" section")
    console.print("")
    console.print("[dim]This ensures all work is properly documented.[/dim]")
    raise typer.Exit(1)


def enforce_local_only_reason(task_id: str, reason: str) -> None:
    """Validate --local-only has a reason, log the bypass."""
    if not reason:
        console.print("[red]❌ --local-only requires --reason to explain the bypass[/red]")
        raise typer.Exit(1)
    log_bypass("task update --local-only", task_id, reason)
    console.print(f"[yellow]⚠ Updating local task only (logged): {reason}[/yellow]")
