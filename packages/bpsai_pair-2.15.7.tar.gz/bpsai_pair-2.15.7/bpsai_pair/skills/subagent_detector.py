"""Subagent Gap Detector — detects patterns benefiting from Claude Code subagents.

Re-exports SubagentGap from subagent_patterns and SubagentGapPersistence
from subagent_parser. Contains SubagentGapDetector class and convenience
functions.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from .subagent_parser import SubagentGapPersistence
from .subagent_patterns import (
    ISOLATION_KEYWORDS,
    MODEL_KEYWORDS,
    PERSONA_KEYWORDS,
    READ_ONLY_PATTERNS,
    RESUMABLE_KEYWORDS,
    SubagentGap,
)

logger = logging.getLogger(__name__)

# Re-export for backward compatibility
__all__ = [
    "SubagentGap",
    "SubagentGapDetector",
    "SubagentGapPersistence",
    "detect_subagent_gaps",
    "format_subagent_gap_notification",
]


class SubagentGapDetector:
    """Detects patterns that suggest subagent creation."""

    def __init__(
        self,
        existing_subagents: Optional[List[str]] = None,
        confidence_threshold: float = 0.3,
    ):
        self.existing_subagents = [s.lower() for s in (existing_subagents or [])]
        self.confidence_threshold = confidence_threshold

    def detect_from_history(
        self, history_path: Path,
        existing_subagents: Optional[List[str]] = None,
    ) -> List[SubagentGap]:
        """Analyze session history for subagent patterns."""
        if existing_subagents is not None:
            self.existing_subagents = [s.lower() for s in existing_subagents]

        sessions = self._load_sessions(history_path)
        if not sessions:
            return []

        gaps: List[SubagentGap] = []
        gaps.extend(self._detect_persona_patterns(sessions))
        gaps.extend(self._detect_isolation_patterns(sessions))
        gaps.extend(self._detect_resumable_patterns(sessions))
        gaps.extend(self._detect_tool_restriction_patterns(sessions))

        gaps = self._merge_similar_gaps(gaps)
        gaps = [g for g in gaps if g.confidence >= self.confidence_threshold]

        for gap in gaps:
            if self._overlaps_existing(gap.suggested_name):
                gap.confidence *= 0.3
                gap.indicators.append("overlaps_existing_subagent")

        gaps.sort(key=lambda g: g.confidence, reverse=True)
        return gaps

    def _load_sessions(self, history_path: Path) -> List[Dict[str, Any]]:
        """Load session data from history files."""
        sessions: List[Dict[str, Any]] = []
        if not history_path.exists():
            return sessions

        changes_log = history_path / "changes.log"
        if changes_log.exists():
            try:
                content = changes_log.read_text(encoding="utf-8")
                for line in content.strip().split("\n")[-200:]:
                    if line:
                        sessions.append({"type": "command", "content": line})
            except Exception as e:
                logger.warning(f"Error reading changes log: {e}")

        for session_file in history_path.glob("session-*.jsonl"):
            try:
                content = session_file.read_text(encoding="utf-8")
                for line in content.strip().split("\n"):
                    if line:
                        try:
                            sessions.append(json.loads(line))
                        except json.JSONDecodeError:
                            sessions.append({"type": "text", "content": line})
            except Exception as e:
                logger.warning(f"Error reading session file {session_file}: {e}")

        return sessions

    def _detect_persona_patterns(self, sessions: List[Dict[str, Any]]) -> List[SubagentGap]:
        """Find patterns where user requested specific personas."""
        persona_matches: Dict[str, List[str]] = {}
        for session in sessions:
            content = session.get("content", "").lower()
            for keyword in PERSONA_KEYWORDS:
                if keyword in content:
                    persona = self._extract_persona_name(content, keyword)
                    if persona:
                        persona_matches.setdefault(persona, []).append(content[:100])

        gaps = []
        for persona, occurrences in persona_matches.items():
            if len(occurrences) >= 2:
                confidence = self._calculate_confidence(["persona_request"], len(occurrences))
                gaps.append(SubagentGap(
                    id=f"persona-{persona.replace(' ', '-')}",
                    suggested_name=self._to_kebab_case(persona),
                    description=f"Specialized {persona} for focused analysis",
                    confidence=confidence, indicators=["persona_request"],
                    suggested_persona=f"You are a {persona}. Focus on...",
                    source_commands=occurrences[:5],
                    occurrence_count=len(occurrences),
                    needs_context_isolation=True,
                ))
        return gaps

    def _detect_isolation_patterns(self, sessions: List[Dict[str, Any]]) -> List[SubagentGap]:
        """Find patterns where context isolation would help."""
        matches = self._match_keywords(sessions, ISOLATION_KEYWORDS)
        if len(matches) < 2:
            return []
        confidence = self._calculate_confidence(["context_isolation"], len(matches))
        return [SubagentGap(
            id="context-isolated-worker", suggested_name="isolated-analyzer",
            description="Context-isolated worker for parallel analysis",
            confidence=confidence, indicators=["context_isolation_requested"],
            needs_context_isolation=True, source_commands=matches[:5],
            occurrence_count=len(matches), estimated_context_savings=5000,
        )]

    def _detect_resumable_patterns(self, sessions: List[Dict[str, Any]]) -> List[SubagentGap]:
        """Find patterns where resumability is needed."""
        matches = self._match_keywords(sessions, RESUMABLE_KEYWORDS)
        if len(matches) < 2:
            return []
        confidence = self._calculate_confidence(["resumability"], len(matches))
        return [SubagentGap(
            id="resumable-task-worker", suggested_name="persistent-task-handler",
            description="Resumable worker for multi-session tasks",
            confidence=confidence, indicators=["resumability_requested"],
            needs_resumability=True, source_commands=matches[:5],
            occurrence_count=len(matches),
        )]

    def _detect_tool_restriction_patterns(self, sessions: List[Dict[str, Any]]) -> List[SubagentGap]:
        """Find patterns with consistent tool subsets."""
        matches = self._match_keywords(sessions, READ_ONLY_PATTERNS)
        if len(matches) < 3:
            return []
        confidence = self._calculate_confidence(["tool_restriction"], len(matches))
        return [SubagentGap(
            id="read-only-reviewer", suggested_name="code-reviewer",
            description="Read-only reviewer that cannot modify files",
            confidence=confidence, indicators=["read_only_pattern"],
            suggested_tools=["Read", "Grep", "Glob", "Bash"],
            needs_context_isolation=True, source_commands=matches[:5],
            occurrence_count=len(matches),
        )]

    def _match_keywords(
        self, sessions: List[Dict[str, Any]], keywords: List[str],
    ) -> List[str]:
        """Match keywords across sessions, returning matched content snippets."""
        matches: List[str] = []
        for session in sessions:
            content = session.get("content", "").lower()
            for keyword in keywords:
                if keyword in content:
                    matches.append(content[:100])
                    break
        return matches

    def _extract_persona_name(self, content: str, keyword: str) -> Optional[str]:
        """Extract persona name from content near keyword."""
        idx = content.find(keyword)
        if idx == -1:
            return None
        after = content[idx + len(keyword):].strip()
        words = re.findall(r"[a-z]+", after[:50])
        if not words:
            return None
        persona_words = []
        for word in words[:3]:
            if word not in {"a", "an", "the", "and", "or", "for", "to", "be"}:
                persona_words.append(word)
            if len(persona_words) >= 2:
                break
        return " ".join(persona_words) if persona_words else None

    def _to_kebab_case(self, text: str) -> str:
        """Convert text to kebab-case."""
        result = re.sub(r"[\s_]+", "-", text.lower())
        result = re.sub(r"[^a-z0-9-]", "", result)
        result = re.sub(r"-+", "-", result)
        return result.strip("-")

    def _calculate_confidence(self, indicators: List[str], occurrences: int) -> float:
        """Calculate confidence score for a gap."""
        indicator_score = min(len(indicators) * 0.2 + 0.2, 0.6)
        occurrence_score = min(occurrences / 10, 0.3)
        return min(indicator_score + occurrence_score, 0.95)

    def _overlaps_existing(self, name: str) -> bool:
        """Check if name overlaps with existing subagent."""
        name_words = set(name.lower().split("-"))
        for existing in self.existing_subagents:
            if name_words & set(existing.split("-")):
                return True
        return False

    def _merge_similar_gaps(self, gaps: List[SubagentGap]) -> List[SubagentGap]:
        """Merge gaps with similar names."""
        if not gaps:
            return gaps
        merged: Dict[str, SubagentGap] = {}
        for gap in gaps:
            key = gap.suggested_name
            if key in merged:
                existing = merged[key]
                if gap.confidence > existing.confidence:
                    existing.confidence = gap.confidence
                existing.indicators = list(set(existing.indicators + gap.indicators))
                existing.occurrence_count += gap.occurrence_count
                existing.source_commands.extend(gap.source_commands[:3])
            else:
                merged[key] = gap
        return list(merged.values())


def detect_subagent_gaps(
    history_dir: Path,
    subagents_dir: Optional[Path] = None,
) -> List[SubagentGap]:
    """High-level function to detect subagent gaps from history."""
    existing_subagents: List[str] = []
    if subagents_dir and subagents_dir.exists():
        for agent_file in subagents_dir.glob("*.md"):
            existing_subagents.append(agent_file.stem)

    claude_agents = history_dir.parent.parent / ".claude" / "agents"
    if claude_agents.exists():
        for agent_file in claude_agents.glob("*.md"):
            existing_subagents.append(agent_file.stem)

    detector = SubagentGapDetector(existing_subagents=existing_subagents)
    return detector.detect_from_history(history_dir)


def format_subagent_gap_notification(gap: SubagentGap) -> str:
    """Format a subagent gap notification message."""
    lines = [
        "Subagent Gap Detected", "",
        f"Pattern suggests a '{gap.suggested_name}' subagent:",
    ]
    if gap.indicators:
        lines.append(f"  Indicators: {', '.join(gap.indicators)}")
    if gap.suggested_persona:
        lines.append(f"  Persona: {gap.suggested_persona[:50]}...")
    if gap.suggested_tools:
        lines.append(f"  Tools: {', '.join(gap.suggested_tools)}")
    if gap.suggested_model:
        lines.append(f"  Model: {gap.suggested_model}")
    lines.extend(["", "Would you like to create this subagent?",
                   f"Confidence: {gap.confidence:.0%}"])
    if gap.estimated_context_savings:
        lines.append(f"Est. context savings: ~{gap.estimated_context_savings} tokens")
    return "\n".join(lines)
