"""Subagent gap persistence — save/load detected gaps to history.

Contains SubagentGapPersistence class for JSONL-based storage
of detected subagent gaps.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import List

from .subagent_patterns import SubagentGap

logger = logging.getLogger(__name__)


class SubagentGapPersistence:
    """Handles persisting detected subagent gaps to history."""

    def __init__(self, history_dir: Path):
        self.history_dir = history_dir
        self.gap_file = history_dir / "subagent-gaps.jsonl" if history_dir else None

    def save_gap(self, gap: SubagentGap) -> None:
        """Save a gap to history."""
        if not self.gap_file:
            return

        self.history_dir.mkdir(parents=True, exist_ok=True)

        existing_gaps = self.load_gaps()

        updated = False
        for i, existing in enumerate(existing_gaps):
            if existing.id == gap.id:
                if gap.confidence > existing.confidence:
                    existing_gaps[i] = gap
                updated = True
                break

        if not updated:
            existing_gaps.append(gap)

        with open(self.gap_file, "w", encoding="utf-8") as f:
            for g in existing_gaps:
                f.write(json.dumps(g.to_dict()) + "\n")

    def load_gaps(self) -> List[SubagentGap]:
        """Load gaps from history."""
        if not self.gap_file or not self.gap_file.exists():
            return []

        gaps = []
        try:
            content = self.gap_file.read_text(encoding="utf-8")
            for line in content.strip().split("\n"):
                if line:
                    try:
                        data = json.loads(line)
                        gaps.append(SubagentGap.from_dict(data))
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            logger.warning(f"Error loading subagent gaps: {e}")

        return gaps

    def clear_gaps(self) -> None:
        """Clear all gaps from history."""
        if self.gap_file and self.gap_file.exists():
            self.gap_file.write_text("", encoding="utf-8")
