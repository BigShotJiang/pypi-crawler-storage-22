"""
Skill Suggestion Module - Analyzes session patterns to suggest new skills.

Pattern detection is in pattern_detector.py.
Suggestion generation is in skill_suggester.py.
"""

import re
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from .validator import SkillValidator

# Re-export for backwards compatibility
from .pattern_detector import (  # noqa: F401
    PatternDetector,
    TRIVIAL_PATTERNS,
    GENERIC_COMMANDS,
)
from .skill_suggester import SkillSuggester  # noqa: F401

logger = logging.getLogger(__name__)

# Skill names that are permanently blocked from creation
BLOCKED_SKILL_NAMES = {
    "testing-fixes",
    "test-fix",
    "test-and-fix",
    "pytest-fix",
    "git-add-commit",
    "git-commit-push",
    "install-run",
}


class SkillSuggestionError(Exception):
    """Error during skill suggestion operations."""
    pass


class HistoryParser:
    """Parses session history files to extract command patterns."""

    def __init__(self, history_dir: Optional[Path] = None):
        self.history_dir = history_dir

    def get_sessions(self) -> List[Dict[str, Any]]:
        """Get list of sessions from session log."""
        if not self.history_dir or not self.history_dir.exists():
            return []

        sessions_log = self.history_dir / "sessions.log"
        if not sessions_log.exists():
            return []

        sessions = []
        try:
            content = sessions_log.read_text(encoding="utf-8")
            for line in content.strip().split("\n"):
                if not line:
                    continue
                match = re.match(r"(\S+)\s+session_start\s+id=(\S+)", line)
                if match:
                    sessions.append({
                        "timestamp": match.group(1),
                        "id": match.group(2),
                    })
        except Exception as e:
            logger.warning(f"Error parsing sessions log: {e}")

        return sessions

    def get_changes(self) -> List[Dict[str, Any]]:
        """Get list of changes from changes log."""
        if not self.history_dir or not self.history_dir.exists():
            return []

        changes_log = self.history_dir / "changes.log"
        if not changes_log.exists():
            return []

        changes = []
        try:
            content = changes_log.read_text(encoding="utf-8")
            for line in content.strip().split("\n"):
                if not line:
                    continue
                parts = line.split()
                if parts:
                    changes.append({
                        "timestamp": parts[0],
                        "data": " ".join(parts[1:]) if len(parts) > 1 else "",
                    })
        except Exception as e:
            logger.warning(f"Error parsing changes log: {e}")

        return changes

    def get_command_history(self) -> List[Dict[str, Any]]:
        """Get command history for pattern analysis."""
        return []


class SkillDraftCreator:
    """Creates skill draft files from suggestions."""

    TEMPLATE = '''---
name: {name}
description: {description}
---

# {title}

## Overview

This skill was auto-generated based on detected workflow patterns.

## Pattern Detected

{pattern_description}

## Usage

Activated when performing {activation_context}.

## Workflow

{workflow_steps}

## Notes

- Confidence: {confidence}%
- Based on {occurrences} observed occurrences
- Estimated savings: {estimated_savings}

---
*This is a draft skill. Review and customize before use.*
'''

    def __init__(self, skills_dir: Path):
        self.skills_dir = skills_dir
        self.validator = SkillValidator(skills_dir)

    def create_draft(self, suggestion: Dict[str, Any], force: bool = False) -> Dict[str, Any]:
        """Create a skill draft from a suggestion."""
        name = suggestion.get("name", "")
        if not name:
            raise SkillSuggestionError("Suggestion missing 'name' field")

        if name.lower() in BLOCKED_SKILL_NAMES:
            raise SkillSuggestionError(
                f"Skill name '{name}' is permanently blocked. "
                f"This pattern is too trivial to be a skill."
            )

        skill_dir = self.skills_dir / name
        skill_file = skill_dir / "SKILL.md"

        if skill_dir.exists() and not force:
            raise SkillSuggestionError(f"Skill '{name}' already exists. Use --force to overwrite.")

        content = self._generate_content(suggestion)

        skill_dir.mkdir(parents=True, exist_ok=True)
        skill_file.write_text(content, encoding="utf-8")

        validation = self.validator.validate_skill(skill_dir)
        if not validation["valid"]:
            self.validator.fix_skill(skill_dir)
            validation = self.validator.validate_skill(skill_dir)

        return {
            "success": True,
            "path": str(skill_file),
            "validation": validation,
        }

    def _generate_content(self, suggestion: Dict[str, Any]) -> str:
        """Generate SKILL.md content from suggestion."""
        name = suggestion.get("name", "unknown")
        description = suggestion.get("description", "Auto-generated skill.")
        pattern = suggestion.get("pattern", [])
        confidence = suggestion.get("confidence", 0)
        occurrences = suggestion.get("occurrences", 0)
        estimated_savings = suggestion.get("estimated_savings", "unknown")

        title = " ".join(word.capitalize() for word in name.split("-"))
        pattern_description = " → ".join(pattern) if pattern else "No pattern data"

        if pattern:
            activation_context = pattern[0].lower()
        else:
            activation_context = "the related workflow"

        workflow_steps = ""
        for i, cmd in enumerate(pattern, 1):
            workflow_steps += f"{i}. Execute `{cmd}`\n"
        if not workflow_steps:
            workflow_steps = "1. (Define workflow steps)"

        return self.TEMPLATE.format(
            name=name,
            description=description,
            title=title,
            pattern_description=pattern_description,
            activation_context=activation_context,
            workflow_steps=workflow_steps.strip(),
            confidence=confidence,
            occurrences=occurrences,
            estimated_savings=estimated_savings,
        )


def suggest_skills(
    history_dir: Optional[Path] = None,
    skills_dir: Optional[Path] = None,
    min_occurrences: int = 3,
) -> List[Dict[str, Any]]:
    """High-level function to analyze history and suggest skills."""
    parser = HistoryParser(history_dir=history_dir)
    history = parser.get_command_history()

    detector = PatternDetector(min_occurrences=min_occurrences)
    patterns = detector.detect_patterns(history)

    suggester = SkillSuggester(skills_dir=skills_dir)
    suggestions = suggester.generate_suggestions(patterns)

    return suggestions
