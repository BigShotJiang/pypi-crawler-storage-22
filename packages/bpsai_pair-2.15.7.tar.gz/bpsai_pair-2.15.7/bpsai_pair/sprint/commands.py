"""Sprint CLI commands for PairCoder.

Provides commands for sprint lifecycle management including
listing sprints and completing sprints with checklists.

Extracted from planning/cli_commands.py as part of EPIC-003 Phase 2.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import typer
from rich.console import Console
from rich.table import Table

# Import from planning module
from ..planning.models import Task, TaskStatus
from ..planning.parser import PlanParser, TaskParser
from ..planning.state import StateManager
from ..tasks.archiver import TaskArchiver
from ..tasks.lifecycle import TaskLifecycle, TaskState

console = Console()

app = typer.Typer(
    help="Sprint lifecycle management commands",
    context_settings={"help_option_names": ["-h", "--help"]}
)


def find_paircoder_dir() -> Path:
    """Find .paircoder directory in current or parent directories."""
    from ..core.ops import find_paircoder_dir as _find_paircoder_dir
    return _find_paircoder_dir()


def get_state_manager() -> StateManager:
    """Get a StateManager instance for the current project."""
    return StateManager(find_paircoder_dir())


# Sprint completion checklist items
SPRINT_COMPLETION_CHECKLIST = [
    ("Cookie cutter template synced", "Have you synced changes to the cookie cutter template?"),
    ("CHANGELOG.md updated", "Have you updated CHANGELOG.md with new features/fixes?"),
    ("Documentation updated", "Have you updated relevant documentation?"),
    ("Tests passing", "Are all tests passing?"),
    ("Version bumped (if release)", "Have you bumped the version number if this is a release?"),
]


def _validate_skip_checklist(skip_checklist: bool, reason: str, sprint_id: str) -> None:
    """Validate and log checklist skip if requested."""
    if not skip_checklist:
        return
    if not reason:
        console.print("[red]❌ --skip-checklist requires --reason[/red]")
        console.print("[dim]Example: --skip-checklist --reason 'Hotfix deployment'[/dim]")
        raise typer.Exit(1)
    from ..core.bypass_log import log_bypass
    log_bypass(
        command="sprint complete",
        target=sprint_id,
        reason=reason,
        bypass_type="skip_checklist",
    )


def _resolve_plan(paircoder_dir: Path, plan_id: Optional[str]) -> tuple[str, Any]:
    """Resolve plan ID and load plan. Returns (plan_id, plan)."""
    if not plan_id:
        state_manager = get_state_manager()
        state = state_manager.load_state()
        if state and state.active_plan_id:
            plan_id = state.active_plan_id
        else:
            console.print("[red]No active plan. Specify --plan or set an active plan.[/red]")
            raise typer.Exit(1)

    plan_parser = PlanParser(paircoder_dir / "plans")
    plan = plan_parser.get_plan_by_id(plan_id)
    if not plan:
        console.print(f"[red]Plan not found: {plan_id}[/red]")
        raise typer.Exit(1)
    return plan_id, plan


def _show_sprint_status(sprint_id: str, plan_id: str, sprint_tasks: list[Task]) -> None:
    """Display sprint task stats and warn about incomplete tasks."""
    completed = len([t for t in sprint_tasks if t.status == TaskStatus.DONE])
    total = len(sprint_tasks)

    console.print(f"\n[bold]Completing Sprint: {sprint_id}[/bold]")
    console.print(f"Plan: {plan_id}")
    console.print(f"Tasks: {completed}/{total} completed\n")

    if total > 0 and completed < total:
        incomplete = [t for t in sprint_tasks if t.status != TaskStatus.DONE]
        console.print("[yellow]Warning: Some tasks are incomplete:[/yellow]")
        for task in incomplete[:5]:
            console.print(f"  - {task.id}: {task.title} ({task.status.value})")
        if len(incomplete) > 5:
            console.print(f"  ... and {len(incomplete) - 5} more")
        console.print()


def _run_checklist(sprint_id: str) -> None:
    """Run the interactive pre-completion checklist."""
    console.print("[bold]Pre-completion Checklist:[/bold]\n")

    all_confirmed = True
    responses = {}

    for item_id, question in SPRINT_COMPLETION_CHECKLIST:
        response = typer.confirm(f"  {question}", default=False)
        responses[item_id] = response
        if not response:
            all_confirmed = False

    console.print()
    console.print("[bold]Checklist Summary:[/bold]")
    for item_id, question in SPRINT_COMPLETION_CHECKLIST:
        status = "[green]✓[/green]" if responses[item_id] else "[red]✗[/red]"
        console.print(f"  {status} {item_id}")
    console.print()

    if not all_confirmed:
        console.print("[yellow]Some items are not complete.[/yellow]")
        proceed = typer.confirm("Proceed anyway?", default=False)
        if not proceed:
            console.print("[dim]Sprint completion cancelled.[/dim]")
            console.print("\n[bold]To generate release tasks:[/bold]")
            console.print(f"  bpsai-pair release plan --sprint {sprint_id}")
            raise typer.Exit(0)


def _show_next_steps(sprint_id: str, archived: bool) -> None:
    """Print next steps based on whether archival ran."""
    console.print("\n[bold]Next Steps:[/bold]")
    if archived:
        console.print("  1. Generate changelog: [dim]bpsai-pair task changelog-preview[/dim]")
        console.print(f"  2. Create release: [dim]bpsai-pair release plan --sprint {sprint_id}[/dim]")
    else:
        console.print("  1. Archive completed tasks: [dim]bpsai-pair task archive[/dim]")
        console.print("  2. Generate changelog: [dim]bpsai-pair task changelog-preview[/dim]")
        console.print(f"  3. Create release: [dim]bpsai-pair release plan --sprint {sprint_id}[/dim]")


@app.command("complete")
def sprint_complete(
    sprint_id: str = typer.Argument(..., help="Sprint ID to complete"),
    skip_checklist: bool = typer.Option(False, "--skip-checklist", help="Skip checklist (logged)"),
    reason: str = typer.Option("", "--reason", "-r", help="Reason for skip (required with --skip-checklist)"),
    plan_id: Optional[str] = typer.Option(None, "--plan", "-p", help="Plan ID (uses active if not set)"),
    archive: bool = typer.Option(True, "--archive/--no-archive", help="Auto-archive completed tasks"),
):
    """Complete a sprint with checklist verification and optional archival."""
    paircoder_dir = find_paircoder_dir()
    _validate_skip_checklist(skip_checklist, reason, sprint_id)
    plan_id, plan = _resolve_plan(paircoder_dir, plan_id)

    sprint_found = any(
        s.id == sprint_id or s.id == f"{plan_id}-{sprint_id}"
        for s in plan.sprints
    )
    if not sprint_found:
        console.print(f"[yellow]Warning: Sprint '{sprint_id}' not found in plan. Continuing anyway.[/yellow]")

    task_parser = TaskParser(paircoder_dir / "tasks")
    sprint_tasks = [t for t in task_parser.list_tasks() if t.sprint == sprint_id]
    _show_sprint_status(sprint_id, plan_id, sprint_tasks)

    if not skip_checklist:
        _run_checklist(sprint_id)

    console.print(f"\n[green]✓ Sprint {sprint_id} marked as complete[/green]")

    if archive:
        console.print("\n[bold]Archiving tasks:[/bold]")
        _archive_sprint_tasks(paircoder_dir, sprint_tasks, plan_id)

    _show_next_steps(sprint_id, archive)
    _check_state_size(paircoder_dir)


STATE_SIZE_THRESHOLD = 200


def _archive_sprint_tasks(
    paircoder_dir: Path, sprint_tasks: list[Task], plan_slug: str
) -> None:
    """Archive completed sprint tasks via TaskLifecycle and TaskArchiver.

    Uses TaskLifecycle to load tasks as TaskMetadata (with TaskState enum)
    which is what TaskArchiver.archive_batch expects. The planning Task
    objects use TaskStatus.DONE, but the archiver gates on TaskState.COMPLETED.
    """
    if not sprint_tasks:
        console.print("[dim]  No tasks to archive.[/dim]")
        return

    root_dir = paircoder_dir.parent
    lifecycle = TaskLifecycle(paircoder_dir / "tasks")
    plan_dir = paircoder_dir / "tasks" / plan_slug

    # Load tasks via lifecycle (produces TaskMetadata with TaskState)
    if plan_dir.exists():
        archivable = lifecycle.get_tasks_by_status(
            plan_dir, [TaskState.COMPLETED, TaskState.CANCELLED]
        )
    else:
        # Flat storage fallback
        archivable = lifecycle.get_tasks_by_status(
            paircoder_dir / "tasks", [TaskState.COMPLETED, TaskState.CANCELLED]
        )
        sprint_ids = {t.id for t in sprint_tasks}
        archivable = [t for t in archivable if t.id in sprint_ids]

    if not archivable:
        console.print("[dim]  No completed tasks to archive.[/dim]")
        return

    archiver = TaskArchiver(root_dir)
    result = archiver.archive_batch(archivable, plan_slug)

    if result.archived:
        console.print(
            f"[green]  ✓ {len(result.archived)} task(s) archived[/green]"
        )
    if result.skipped:
        console.print(f"[dim]  {len(result.skipped)} skipped[/dim]")
    if result.errors:
        console.print(f"[red]  {len(result.errors)} error(s):[/red]")
        for err in result.errors:
            console.print(f"[red]    - {err}[/red]")


def _check_state_size(paircoder_dir: Path) -> None:
    """Warn if state.md exceeds size threshold."""
    state_file = paircoder_dir / "context" / "state.md"
    if not state_file.exists():
        return
    line_count = len(state_file.read_text().splitlines())
    if line_count > STATE_SIZE_THRESHOLD:
        console.print(
            f"\n[yellow]⚠ state.md is {line_count} lines "
            f"(threshold: {STATE_SIZE_THRESHOLD})[/yellow]"
        )
        console.print(
            "[dim]  Consider condensing — detailed context belongs in archive, "
            "state.md should stay navigational.[/dim]"
        )


def _build_sprint_table(plan_id: str, sprints: list[Any], all_tasks: list[Task]) -> Table:
    """Build a Rich table of sprint stats."""
    table = Table(title=f"Sprints in {plan_id}")
    table.add_column("Sprint", style="cyan")
    table.add_column("Goal")
    table.add_column("Tasks", justify="right")
    table.add_column("Done", justify="right")
    table.add_column("Points", justify="right")

    for sprint in sprints:
        sprint_tasks = [t for t in all_tasks if t.sprint == sprint.id]
        completed = len([t for t in sprint_tasks if t.status == TaskStatus.DONE])
        total = len(sprint_tasks)
        points = sum(t.complexity for t in sprint_tasks)

        status = f"{completed}/{total}"
        if total > 0 and completed == total:
            status = f"[green]{status}[/green]"

        table.add_row(
            sprint.id,
            sprint.goal[:40] + "..." if len(sprint.goal) > 40 else sprint.goal,
            str(total),
            status,
            str(points),
        )
    return table


@app.command("list")
def sprint_list(
    plan_id: Optional[str] = typer.Option(None, "--plan", "-p", help="Plan ID (uses active if not set)"),
):
    """List sprints in a plan."""
    paircoder_dir = find_paircoder_dir()
    plan_id, plan = _resolve_plan(paircoder_dir, plan_id)

    if not plan.sprints:
        console.print("[dim]No sprints defined in this plan.[/dim]")
        return

    task_parser = TaskParser(paircoder_dir / "tasks")
    all_tasks = task_parser.list_tasks()
    console.print(_build_sprint_table(plan_id, plan.sprints, all_tasks))
