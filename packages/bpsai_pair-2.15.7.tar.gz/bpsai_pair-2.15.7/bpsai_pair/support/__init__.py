"""Support portal integration for PairCoder CLI."""
