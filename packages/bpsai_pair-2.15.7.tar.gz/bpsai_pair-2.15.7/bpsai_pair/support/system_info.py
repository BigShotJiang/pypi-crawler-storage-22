"""System info collection for support tickets.

Gathers local environment details to attach to support tickets
for faster debugging context.
"""

from __future__ import annotations

import platform
import sys
from importlib import metadata
from pathlib import Path
from typing import Optional


def _read_state_field(field: str) -> Optional[str]:
    """Read a field from .paircoder/context/state.md if it exists."""
    try:
        from ..core.ops import find_paircoder_dir

        pd = find_paircoder_dir()
        if pd is None:
            return None

        state_path = pd / "context" / "state.md"
        if not state_path.exists():
            return None

        text = state_path.read_text()
        for line in text.splitlines():
            if line.startswith(f"## {field}"):
                # Next non-empty line is the value
                idx = text.splitlines().index(line)
                for next_line in text.splitlines()[idx + 1 :]:
                    stripped = next_line.strip()
                    if stripped and not stripped.startswith("##"):
                        return stripped
                    if stripped.startswith("##"):
                        break
                return None
    except Exception:
        return None


def collect_system_info() -> dict:
    """Collect system info for a support ticket."""
    try:
        version = metadata.version("bpsai-pair")
    except Exception:
        version = "unknown"

    info = {
        "paircoder_version": version,
        "python_version": sys.version,
        "os_info": f"{platform.system()} {platform.release()}",
        "active_plan": _read_state_field("Current Plan"),
        "active_task": _read_state_field("Current Task"),
    }
    return info
