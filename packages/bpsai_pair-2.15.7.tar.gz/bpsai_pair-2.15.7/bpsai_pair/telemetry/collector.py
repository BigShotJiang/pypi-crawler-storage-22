"""Telemetry collector for automatic data collection on task completion.

This module integrates all telemetry components to collect metrics
when tasks are completed, applying privacy filtering and audit logging.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from bpsai_pair.telemetry.audit import AuditLog
from bpsai_pair.telemetry.config import TelemetryConfig
from bpsai_pair.telemetry.parser import ClaudeSessionParser
from bpsai_pair.telemetry.privacy import PrivacyFilter
from bpsai_pair.telemetry.schema import (
    Outcome,
    TelemetryRecord,
    TokenUsage,
)
from bpsai_pair.telemetry.store import TelemetryStore

logger = logging.getLogger(__name__)

SNAPSHOT_FILENAME = "session_snapshot.json"


class TelemetryCollector:
    """Collects and stores telemetry data for completed tasks.

    Integrates:
    - ClaudeSessionParser: Find and parse session data
    - PrivacyFilter: Apply privacy level filtering
    - TelemetryStore: Persist telemetry records
    - AuditLog: Create tamper-evident audit entries
    """

    def __init__(
        self, project_root: Path, config: TelemetryConfig | None = None
    ) -> None:
        """Initialize the telemetry collector.

        Args:
            project_root: Path to the project root directory
            config: Optional telemetry configuration (loads default if not provided)
        """
        self.project_root = project_root
        self.config = config or TelemetryConfig.load(project_root)

        self.parser = ClaudeSessionParser()
        self.store = TelemetryStore(project_root)
        self._telemetry_dir = project_root / ".paircoder" / "telemetry"
        self.audit = AuditLog(self._telemetry_dir / "audit.jsonl")
        self.filter = PrivacyFilter(self.config.privacy_level)
        self._snapshot = self._load_snapshot()
        self._cached_integrations: list[str] | None = None

    def collect_for_task(
        self,
        task_id: str,
        task_type: str,
        outcome: Outcome,
        estimated_tokens: int | None = None,
        error_context: str | None = None,
        estimated_hours: float | None = None,
        actual_hours: float | None = None,
        estimated_complexity: int | None = None,
        features_used: list[str] | None = None,
        friction_signals: dict[str, int] | None = None,
        sprint: str | None = None,
        complexity: int | None = None,
    ) -> TelemetryRecord | None:
        """Collect telemetry for a completed task.

        All errors are caught and logged - this method never raises
        to ensure task completion is not blocked by telemetry failures.

        Returns:
            The stored TelemetryRecord, or None if collection is disabled,
            privacy is OFF, no session found, or an error occurs.
        """
        try:
            return self._collect_internal(
                task_id, task_type, outcome, estimated_tokens, error_context,
                estimated_hours, actual_hours, estimated_complexity,
                features_used, friction_signals, sprint, complexity,
            )
        except Exception as e:
            logger.warning("Telemetry collection failed (non-blocking): %s", e)
            return None

    def _collect_internal(
        self,
        task_id: str, task_type: str, outcome: Outcome,
        estimated_tokens: int | None = None, error_context: str | None = None,
        estimated_hours: float | None = None, actual_hours: float | None = None,
        estimated_complexity: int | None = None,
        features_used: list[str] | None = None,
        friction_signals: dict[str, int] | None = None,
        sprint: str | None = None, complexity: int | None = None,
    ) -> TelemetryRecord | None:
        """Internal collection logic that may raise exceptions."""
        if not self.config.enabled:
            return None

        session_metrics = self._get_session_metrics()
        is_sessionless = session_metrics is None
        if not is_sessionless:
            record = self._create_record(
                task_id, task_type, outcome, session_metrics,
                estimated_tokens, error_context,
                estimated_hours, actual_hours, estimated_complexity,
                sprint, complexity,
            )
            # Save snapshot to establish/advance the delta baseline for the next task.
            # This must happen even when the record is replaced by a sessionless fallback
            # (session boundary case), otherwise subsequent delta computations break.
            self._save_snapshot(session_metrics)
            if record.duration_seconds < 1 and record.tokens.input == 0:  # session boundary
                is_sessionless = True
        if is_sessionless:
            record = self._create_sessionless_record(
                task_id, task_type, outcome, estimated_tokens,
                error_context, estimated_hours, actual_hours,
                estimated_complexity, sprint, complexity,
            )

        if record is None:
            return None
        self._enrich_record(record, task_id, features_used, friction_signals)
        if is_sessionless:
            record.friction_signals["sessionless"] = 1
        elif record.duration_seconds < 1:
            logger.warning("Rejecting record for %s: duration %ds < 1s", task_id, record.duration_seconds)
            return None

        filtered = self.filter.filter(record)
        if filtered is None:
            return None
        self.store.append(filtered)
        self.audit.append("record_added", {"task_id": filtered.task_id,
                          "task_type": filtered.task_type, "outcome": filtered.outcome.value})
        return filtered

    def _enrich_record(
        self, record: TelemetryRecord, task_id: str,
        features_used: list[str] | None, friction_signals: dict[str, int] | None,
    ) -> None:
        """Enrich record with routing, features, and friction data."""
        record.routed_model = self._read_routing_decision(task_id)
        record.features_used = self._merge_features(
            features_used or [], self._detect_active_integrations(),
        )
        record.friction_signals = self._build_friction_signals(
            record, friction_signals,
        )

    def _get_session_metrics(self):
        """Find and parse the most recent session for this project."""
        project_path = str(self.project_root.resolve())
        sessions = self.parser.find_sessions(project_path)

        if not sessions:
            return None

        # Use the most recent session (first in sorted list)
        most_recent = sessions[0]
        entries = self.parser.parse_session(most_recent)

        if not entries:
            return None

        return self.parser.extract_metrics(entries)

    def _create_record(
        self,
        task_id: str,
        task_type: str,
        outcome: Outcome,
        metrics,
        estimated_tokens: int | None = None,
        error_context: str | None = None,
        estimated_hours: float | None = None,
        actual_hours: float | None = None,
        estimated_complexity: int | None = None,
        sprint: str | None = None,
        complexity: int | None = None,
    ) -> TelemetryRecord:
        """Create a TelemetryRecord from session metrics (delta-aware)."""
        repo = self._extract_repo_name(metrics.project_path)
        input_tokens, output_tokens, duration, interventions, compactions = (
            self._compute_deltas(metrics)
        )

        tokens = TokenUsage(input=input_tokens, output=output_tokens)
        session_id = (
            metrics.session_id
            or os.environ.get("CLAUDE_SESSION_ID")
            or f"{task_id}-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')}"
        )

        return TelemetryRecord(
            task_id=task_id,
            task_type=task_type,
            repo=repo,
            model=metrics.model or os.environ.get("CLAUDE_MODEL") or "sonnet",
            tokens=tokens,
            duration_seconds=int(duration),
            human_interventions=interventions,
            compactions=compactions,
            outcome=outcome,
            timestamp=datetime.now(timezone.utc),
            privacy_level=self.config.privacy_level,
            estimated_tokens=estimated_tokens,
            error_context=error_context,
            session_id=session_id,
            estimated_hours=estimated_hours,
            actual_hours=actual_hours,
            estimated_complexity=estimated_complexity,
            sprint=sprint,
            complexity=complexity,
        )

    def _create_sessionless_record(
        self,
        task_id: str, task_type: str, outcome: Outcome,
        estimated_tokens: int | None = None, error_context: str | None = None,
        estimated_hours: float | None = None, actual_hours: float | None = None,
        estimated_complexity: int | None = None,
        sprint: str | None = None, complexity: int | None = None,
    ) -> TelemetryRecord:
        """Create a TelemetryRecord without session data (in-session fallback).

        Uses env vars, estimated tokens, and time-tracking cache for duration.
        """
        model = os.environ.get("CLAUDE_MODEL") or "sonnet"
        session_id = (
            os.environ.get("CLAUDE_SESSION_ID")
            or f"{task_id}-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')}"
        )
        input_tok = (estimated_tokens // 2) if estimated_tokens else 0
        output_tok = (estimated_tokens - input_tok) if estimated_tokens else 0
        duration = 0
        try:
            cache_path = self.project_root / ".paircoder" / "time-tracking-cache.json"
            if cache_path.exists():
                from bpsai_pair.integrations.time_tracking import LocalTimeCache
                td = LocalTimeCache(cache_path).get_total(task_id)
                duration = max(0, int(td.total_seconds()))
        except Exception:
            logger.debug("Could not read timer duration for %s", task_id)

        return TelemetryRecord(
            task_id=task_id, task_type=task_type,
            repo=self.project_root.name,
            model=model, tokens=TokenUsage(input=input_tok, output=output_tok),
            duration_seconds=duration,
            human_interventions=0, compactions=0,
            outcome=outcome, timestamp=datetime.now(timezone.utc),
            privacy_level=self.config.privacy_level,
            estimated_tokens=estimated_tokens, error_context=error_context,
            session_id=session_id,
            estimated_hours=estimated_hours, actual_hours=actual_hours,
            estimated_complexity=estimated_complexity,
            sprint=sprint, complexity=complexity,
        )

    def _compute_deltas(self, metrics) -> tuple[int, int, float, int, int]:
        """Compute per-task deltas from cumulative session metrics.

        Returns (input_tokens, output_tokens, duration, interventions, compactions).
        If no snapshot or session changed, returns zeros (cannot compute delta).
        """
        compactions = getattr(metrics, "compactions", 0)
        snap = self._snapshot
        if not snap or snap.get("session_id") != metrics.session_id:
            logger.debug(
                "Session boundary: no delta available (snap=%s, session=%s)",
                snap.get("session_id") if snap else None,
                metrics.session_id,
            )
            return (0, 0, 0.0, 0, 0)

        return (
            max(0, metrics.total_input_tokens - snap.get("total_input_tokens", 0)),
            max(0, metrics.total_output_tokens - snap.get("total_output_tokens", 0)),
            max(0, metrics.duration_seconds - snap.get("duration_seconds", 0)),
            max(0, metrics.message_counts.user - snap.get("user_messages", 0)),
            max(0, compactions - snap.get("compactions", 0)),
        )

    def _load_snapshot(self) -> dict[str, Any] | None:
        """Load the session snapshot from disk."""
        path = self._telemetry_dir / SNAPSHOT_FILENAME
        try:
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if "session_id" in data and "total_input_tokens" in data:
                    return data
        except Exception:
            logger.debug("Could not load session snapshot, starting fresh")
        return None

    def _save_snapshot(self, metrics) -> None:
        """Save the current cumulative metrics as a snapshot for next delta."""
        self._telemetry_dir.mkdir(parents=True, exist_ok=True)
        snapshot = {
            "session_id": metrics.session_id,
            "total_input_tokens": metrics.total_input_tokens,
            "total_output_tokens": metrics.total_output_tokens,
            "duration_seconds": metrics.duration_seconds,
            "user_messages": metrics.message_counts.user,
            "compactions": getattr(metrics, "compactions", 0),
        }
        path = self._telemetry_dir / SNAPSHOT_FILENAME
        try:
            path.write_text(json.dumps(snapshot), encoding="utf-8")
            self._snapshot = snapshot
        except Exception:
            logger.debug("Could not save session snapshot")

    def _read_routing_decision(self, task_id: str) -> str | None:
        """Read the per-task routing decision file and clean up after read."""
        path = self.project_root / ".paircoder" / f"routing_decision_{task_id}.json"
        try:
            if not path.exists():
                return None
            data = json.loads(path.read_text(encoding="utf-8"))
            model = data.get("routed_model")
            try:
                path.unlink()
            except OSError:
                pass
            return model
        except Exception:
            logger.debug("Could not read routing decision for %s", task_id)
        return None

    def _detect_active_integrations(self) -> list[str]:
        """Detect active integrations and features from the project config.

        Cached after first call since config rarely changes during a session.
        """
        if self._cached_integrations is not None:
            return self._cached_integrations
        config_path = self.project_root / ".paircoder" / "config.yaml"
        try:
            if not config_path.exists():
                self._cached_integrations = []
                return []
            data = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        except Exception:
            self._cached_integrations = []
            return []
        detected: list[str] = []
        # Integrations (external services)
        for key in ("trello", "github"):
            if data.get(key):
                detected.append(f"int:{key}")
        # Features (internal config sections)
        for key in (
            "hooks", "metrics", "architecture", "containment",
            "estimation", "enforcement",
        ):
            if data.get(key):
                detected.append(f"feat:{key}")
        self._cached_integrations = detected
        return detected

    @staticmethod
    def _build_friction_signals(
        record: TelemetryRecord,
        explicit: dict[str, int] | None,
    ) -> dict[str, int]:
        """Build friction_signals by merging explicit values with auto-derived."""
        signals: dict[str, int] = dict(explicit or {})
        if record.compactions > 0:
            signals.setdefault("compactions", record.compactions)
        if record.human_interventions > 0:
            signals.setdefault("human_interventions", record.human_interventions)
        return signals

    @staticmethod
    def _merge_features(explicit: list[str], detected: list[str]) -> list[str]:
        """Merge explicit and detected features, deduplicating."""
        seen: set[str] = set()
        merged: list[str] = []
        for f in explicit + detected:
            if f not in seen:
                seen.add(f)
                merged.append(f)
        return merged

    def _extract_repo_name(self, project_path: str | None) -> str:
        """Extract repository name from project path."""
        if not project_path:
            return self.project_root.name

        path = Path(project_path)
        return path.name or self.project_root.name
