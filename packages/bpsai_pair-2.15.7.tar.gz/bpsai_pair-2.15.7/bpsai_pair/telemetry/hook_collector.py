"""Hook event telemetry collector.

Captures SubagentStart/Stop hook events as TelemetryRecords,
enabling calibration from agent team execution data.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from bpsai_pair.telemetry.schema import (
    Outcome,
    PrivacyLevel,
    TelemetryRecord,
    TokenUsage,
)
from bpsai_pair.telemetry.store import TelemetryStore

logger = logging.getLogger(__name__)


@dataclass
class HookTelemetryRecord:
    """Intermediate record from a hook event.

    Attributes:
        agent_id: Unique agent identifier.
        agent_type: Agent role (driver/reviewer/navigator).
        team_name: Agent team name.
        duration_seconds: Execution duration.
        token_count: Tokens used (0 if unknown).
        source: Always "agent_hook" for hook-sourced records.
        timestamp: When the event occurred.
    """

    agent_id: str
    agent_type: str
    team_name: str
    duration_seconds: int
    source: str = "agent_hook"
    token_count: int = 0
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "team_name": self.team_name,
            "duration_seconds": self.duration_seconds,
            "token_count": self.token_count,
            "source": self.source,
            "timestamp": self.timestamp.isoformat(),
        }


class HookCollector:
    """Collects telemetry from hook events.

    Never raises exceptions — follows the same non-blocking pattern
    as TelemetryCollector to avoid disrupting agent execution.
    """

    def __init__(
        self, project_root: Path, *, store: TelemetryStore | None = None,
    ) -> None:
        self.project_root = project_root
        self.store = store or TelemetryStore(project_root)

    def collect_subagent_stop(
        self, event: dict[str, Any],
    ) -> HookTelemetryRecord | None:
        """Capture a SubagentStop event as telemetry.

        Args:
            event: Dict with agent_id, agent_type, team_name,
                   duration_seconds, token_count, transcript_path.

        Returns:
            HookTelemetryRecord on success, None on error.
        """
        try:
            hook_record = _parse_stop_event(event)
            telemetry_record = _to_telemetry_record(hook_record)
            self.store.append(telemetry_record)
            return hook_record
        except Exception:
            logger.warning("Failed to collect hook telemetry", exc_info=True)
            return None


def _parse_stop_event(event: dict[str, Any]) -> HookTelemetryRecord:
    """Parse a SubagentStop event dict into a HookTelemetryRecord."""
    ts_str = event.get("timestamp", "")
    if ts_str:
        timestamp = datetime.fromisoformat(ts_str)
    else:
        timestamp = datetime.now(timezone.utc)

    return HookTelemetryRecord(
        agent_id=event.get("agent_id", "unknown"),
        agent_type=event.get("agent_type", "unknown"),
        team_name=event.get("team_name", ""),
        duration_seconds=event.get("duration_seconds", 0),
        token_count=event.get("token_count", 0),
        source="agent_hook",
        timestamp=timestamp,
    )


def _to_telemetry_record(hook: HookTelemetryRecord) -> TelemetryRecord:
    """Convert a HookTelemetryRecord to a TelemetryRecord for storage."""
    half = hook.token_count // 2
    return TelemetryRecord(
        task_id=f"hook:{hook.agent_id}",
        task_type=f"agent_hook:{hook.agent_type}",
        repo=hook.team_name,
        model="unknown",
        tokens=TokenUsage(input=half, output=hook.token_count - half),
        duration_seconds=hook.duration_seconds,
        human_interventions=0,
        compactions=0,
        outcome=Outcome.SUCCESS,
        timestamp=hook.timestamp,
        privacy_level=PrivacyLevel.MINIMAL,
    )
