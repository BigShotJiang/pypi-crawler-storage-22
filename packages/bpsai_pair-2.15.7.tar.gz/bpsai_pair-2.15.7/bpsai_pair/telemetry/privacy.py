"""Privacy filtering for telemetry records.

This module provides filtering of telemetry records based on privacy levels,
ensuring users have full control over what data is collected and stored.
"""

from __future__ import annotations

from dataclasses import replace

from bpsai_pair.telemetry.schema import PrivacyLevel, TelemetryRecord


class PrivacyFilter:
    """Filter telemetry records based on privacy level.

    MINIMAL is the mandatory baseline — it always returns a record.
    Privacy levels control what data is collected:
    - MINIMAL: Aggregates + errors + estimation accuracy (redacts task_id, repo)
    - STANDARD: + feature usage, cache hit rate (default; keeps task_id, repo)
    - FULL: + model routing, workflow patterns (keeps all fields)
    """

    REDACTED = "[redacted]"

    def __init__(self, level: PrivacyLevel) -> None:
        """Initialize the privacy filter.

        Args:
            level: The privacy level to apply when filtering
        """
        self.level = level

    def filter(self, record: TelemetryRecord) -> TelemetryRecord:
        """Filter a telemetry record based on the configured privacy level.

        Args:
            record: The telemetry record to filter

        Returns:
            Filtered record with redacted fields.
            Always returns a new record object, never mutates the original.
        """
        if self.level == PrivacyLevel.MINIMAL:
            return self._filter_minimal(record)

        if self.level == PrivacyLevel.STANDARD:
            return self._filter_standard(record)

        # FULL level - keep everything
        return self._filter_full(record)

    def _filter_minimal(self, record: TelemetryRecord) -> TelemetryRecord:
        """Apply MINIMAL privacy level filtering.

        Redacts identifying information while keeping aggregate metrics.
        """
        return replace(
            record,
            task_id=self.REDACTED,
            repo=self.REDACTED,
            privacy_level=PrivacyLevel.MINIMAL,
        )

    def _filter_standard(self, record: TelemetryRecord) -> TelemetryRecord:
        """Apply STANDARD privacy level filtering.

        Keeps task metadata and outcomes, suitable for feedback loop.
        """
        return replace(
            record,
            privacy_level=PrivacyLevel.STANDARD,
        )

    def _filter_full(self, record: TelemetryRecord) -> TelemetryRecord:
        """Apply FULL privacy level filtering.

        Keeps all data unchanged except setting privacy level.
        """
        return replace(
            record,
            privacy_level=PrivacyLevel.FULL,
        )
