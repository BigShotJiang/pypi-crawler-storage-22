"""Unified telemetry schema for PairCoder execution metrics.

This module defines the data structures for capturing telemetry data
from task executions, including token usage, timing, and outcomes.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)

# Warning threshold for task-level token values. Records above this
# are logged as warnings for monitoring but values are preserved.
MAX_TASK_TOKENS = 500_000


class ValidationError(Exception):
    """Raised when telemetry data fails validation."""

    pass


class Outcome(Enum):
    """Task execution outcome."""

    SUCCESS = "success"
    FAIL = "fail"
    PARTIAL = "partial"


class PrivacyLevel(Enum):
    """Telemetry privacy level controlling what data is collected.

    MINIMAL is the mandatory baseline (always active). STANDARD and FULL
    are opt-in tiers that share additional anonymized data during license
    validation.
    """

    MINIMAL = "minimal"  # Mandatory baseline: aggregates + errors + estimation accuracy
    STANDARD = "standard"  # + feature usage, cache hit rate (default)
    FULL = "full"  # + model routing, workflow patterns (opt-in)


@dataclass
class TokenUsage:
    """Token usage metrics for a task execution."""

    input: int
    output: int
    cache_read: int = 0
    cache_write: int = 0

    def __post_init__(self) -> None:
        """Validate token counts and warn on outliers."""
        self._validate()
        if self.input > MAX_TASK_TOKENS:
            logger.warning("input tokens %d exceeds MAX_TASK_TOKENS (%d)", self.input, MAX_TASK_TOKENS)
        if self.output > MAX_TASK_TOKENS:
            logger.warning("output tokens %d exceeds MAX_TASK_TOKENS (%d)", self.output, MAX_TASK_TOKENS)

    def _validate(self) -> None:
        """Validate all token counts are non-negative."""
        if self.input < 0:
            raise ValidationError("input tokens cannot be negative")
        if self.output < 0:
            raise ValidationError("output tokens cannot be negative")
        if self.cache_read < 0:
            raise ValidationError("cache_read tokens cannot be negative")
        if self.cache_write < 0:
            raise ValidationError("cache_write tokens cannot be negative")

    @property
    def total(self) -> int:
        """Total billable tokens (input + output, excludes cache)."""
        return self.input + self.output

    def to_dict(self) -> dict[str, int]:
        """Serialize to dictionary."""
        return {
            "input": self.input,
            "output": self.output,
            "cache_read": self.cache_read,
            "cache_write": self.cache_write,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TokenUsage:
        """Deserialize from dictionary."""
        return cls(
            input=data["input"],
            output=data["output"],
            cache_read=data.get("cache_read", 0),
            cache_write=data.get("cache_write", 0),
        )


@dataclass
class TelemetryRecord:
    """A single telemetry record capturing task execution metrics."""

    task_id: str
    task_type: str
    repo: str
    model: str
    tokens: TokenUsage
    duration_seconds: int
    human_interventions: int
    compactions: int
    outcome: Outcome
    timestamp: datetime
    privacy_level: PrivacyLevel
    estimated_tokens: int | None = None
    error_context: str | None = None
    session_id: str | None = None
    estimated_hours: float | None = None
    actual_hours: float | None = None
    estimated_complexity: int | None = None
    routed_model: str | None = None
    sprint: str | None = None
    complexity: int | None = None
    features_used: list[str] = field(default_factory=list)
    friction_signals: dict[str, int] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate record after initialization."""
        self._validate()

    def _validate(self) -> None:
        """Validate all record fields."""
        if not self.task_id:
            raise ValidationError("task_id cannot be empty")
        if not self.repo:
            raise ValidationError("repo cannot be empty")
        if self.duration_seconds < 0:
            raise ValidationError("duration_seconds cannot be negative")
        if self.human_interventions < 0:
            raise ValidationError("human_interventions cannot be negative")
        if self.compactions < 0:
            raise ValidationError("compactions cannot be negative")
        if self.estimated_tokens is not None and self.estimated_tokens < 0:
            raise ValidationError("estimated_tokens cannot be negative")
        if self.estimated_hours is not None and self.estimated_hours < 0:
            raise ValidationError("estimated_hours cannot be negative")
        if self.actual_hours is not None and self.actual_hours < 0:
            raise ValidationError("actual_hours cannot be negative")
        if self.estimated_complexity is not None and self.estimated_complexity < 0:
            raise ValidationError("estimated_complexity cannot be negative")
        if self.complexity is not None and self.complexity < 0:
            raise ValidationError("complexity cannot be negative")

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        d: dict[str, Any] = {
            "task_id": self.task_id,
            "task_type": self.task_type,
            "repo": self.repo,
            "model": self.model,
            "tokens": self.tokens.to_dict(),
            "duration_seconds": self.duration_seconds,
            "human_interventions": self.human_interventions,
            "compactions": self.compactions,
            "outcome": self.outcome.value,
            "timestamp": self.timestamp.isoformat(),
            "privacy_level": self.privacy_level.value,
        }
        if self.estimated_tokens is not None:
            d["estimated_tokens"] = self.estimated_tokens
        if self.error_context is not None:
            d["error_context"] = self.error_context
        if self.session_id is not None:
            d["session_id"] = self.session_id
        if self.estimated_hours is not None:
            d["estimated_hours"] = self.estimated_hours
        if self.actual_hours is not None:
            d["actual_hours"] = self.actual_hours
        if self.estimated_complexity is not None:
            d["estimated_complexity"] = self.estimated_complexity
        if self.routed_model is not None:
            d["routed_model"] = self.routed_model
        if self.sprint is not None:
            d["sprint"] = self.sprint
        if self.complexity is not None:
            d["complexity"] = self.complexity
        if self.features_used:
            d["features_used"] = list(self.features_used)
        if self.friction_signals:
            d["friction_signals"] = dict(self.friction_signals)
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TelemetryRecord:
        """Deserialize from dictionary."""
        timestamp = data["timestamp"]
        if isinstance(timestamp, str):
            timestamp = datetime.fromisoformat(timestamp)

        return cls(
            task_id=data["task_id"],
            task_type=data["task_type"],
            repo=data["repo"],
            model=data["model"],
            tokens=TokenUsage.from_dict(data["tokens"]),
            duration_seconds=data["duration_seconds"],
            human_interventions=data["human_interventions"],
            compactions=data["compactions"],
            outcome=Outcome(data["outcome"]),
            timestamp=timestamp,
            privacy_level=PrivacyLevel(data["privacy_level"]),
            estimated_tokens=data.get("estimated_tokens"),
            error_context=data.get("error_context"),
            session_id=data.get("session_id"),
            estimated_hours=data.get("estimated_hours"),
            actual_hours=data.get("actual_hours"),
            estimated_complexity=data.get("estimated_complexity"),
            routed_model=data.get("routed_model"),
            sprint=data.get("sprint"),
            complexity=data.get("complexity"),
            features_used=data.get("features_used", []),
            friction_signals=data.get("friction_signals", {}),
        )

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> TelemetryRecord:
        """Deserialize from JSON string."""
        return cls.from_dict(json.loads(json_str))
