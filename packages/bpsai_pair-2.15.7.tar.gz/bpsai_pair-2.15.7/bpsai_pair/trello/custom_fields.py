"""Custom field operations for Trello cards.

Extracted from client.py for modular architecture.
"""

import logging
from typing import Any, Dict, List, Optional, Union

from .client import CustomFieldDefinition  # noqa: F811

logger = logging.getLogger(__name__)


class CustomFieldMixin:
    """Mixin providing custom field operations on Trello cards."""

    # These attributes are provided by TrelloService
    client: Any
    board: Any

    def get_custom_fields(self) -> List[CustomFieldDefinition]:
        """Get all custom field definitions for the current board."""
        if not self.board:
            raise ValueError("Board not set. Call set_board() first.")

        definitions = self.board.get_custom_field_definitions()
        result = []

        for defn in definitions:
            options = {}
            if defn.field_type == 'list':
                options = defn.list_options

            result.append(CustomFieldDefinition(
                id=defn.id,
                name=defn.name,
                field_type=defn.field_type,
                options=options
            ))

        return result

    def get_custom_field_by_name(self, name: str) -> Optional[CustomFieldDefinition]:
        """Find a custom field by name (case-insensitive)."""
        fields = self.get_custom_fields()
        name_lower = name.lower()

        for field in fields:
            if field.name.lower() == name_lower:
                return field

        return None

    def set_custom_field_value(
        self,
        card: Any,
        field: CustomFieldDefinition,
        value: Union[str, int, float, bool]
    ) -> bool:
        """Set a custom field value on a card."""
        try:
            post_args = _build_field_post_args(field, value)
            if post_args is None:
                return False

            self.client.fetch_json(
                f'/card/{card.id}/customField/{field.id}/item',
                http_method='PUT',
                post_args=post_args
            )
            return True

        except Exception as e:
            logger.error(f"Failed to set custom field '{field.name}': {e}")
            return False

    def set_card_status(
        self,
        card: Any,
        status: str,
        status_field_name: str = "Status"
    ) -> bool:
        """Set the Status custom field on a card."""
        field = self.get_custom_field_by_name(status_field_name)
        if not field:
            logger.warning(f"Status field '{status_field_name}' not found on board")
            return False

        if field.field_type != 'list':
            logger.warning(f"Status field must be a list type, got {field.field_type}")
            return False

        return self.set_custom_field_value(card, field, status)

    def set_card_custom_fields(
        self,
        card: Any,
        field_values: Dict[str, Union[str, int, float, bool]]
    ) -> Dict[str, bool]:
        """Set multiple custom fields on a card."""
        results = {}

        for field_name, value in field_values.items():
            field = self.get_custom_field_by_name(field_name)
            if not field:
                logger.debug(f"Custom field '{field_name}' not found on board, skipping")
                results[field_name] = False
                continue

            results[field_name] = self.set_custom_field_value(card, field, value)

        return results

    def set_effort_field(self, card: Any, complexity: int, field_name: str = "Effort") -> bool:
        """Set the Effort custom field based on complexity score."""
        from .client import EffortMapping

        field = self.get_custom_field_by_name(field_name)
        if not field:
            logger.warning(f"Effort field '{field_name}' not found on board")
            return False

        if field.field_type == 'number':
            return self.set_custom_field_value(card, field, complexity)
        elif field.field_type == 'list':
            effort_mapping = EffortMapping()
            effort = effort_mapping.get_effort(complexity)
            return self.set_custom_field_value(card, field, effort)
        else:
            logger.warning(f"Effort field must be number or list type, got {field.field_type}")
            return False

    def get_board_structure(self) -> Dict[str, Any]:
        """Fetch complete board configuration (lists, custom fields, labels)."""
        if not self.board:
            raise ValueError("Board not set. Call set_board() first.")

        lists = {lst.name: lst.id for lst in self.board.all_lists()}

        custom_fields = {}
        for field in self.get_custom_fields():
            custom_fields[field.name] = {
                "id": field.id,
                "type": field.field_type,
                "options": field.options,
            }

        labels = {}
        for lbl in self.get_labels():
            if lbl['name']:
                labels[lbl['name']] = lbl['id']

        return {
            "lists": lists,
            "custom_fields": custom_fields,
            "labels": labels,
        }

    def create_card_with_custom_fields(
        self,
        list_name: str,
        name: str,
        desc: str = "",
        custom_fields: Optional[Dict[str, Any]] = None
    ) -> Optional[Any]:
        """Create a card with custom fields."""
        target_list = self.lists.get(list_name)
        if not target_list:
            logger.error(f"List '{list_name}' not found")
            return None

        try:
            card = target_list.add_card(name=name, desc=desc)

            if custom_fields:
                self.set_card_custom_fields(card, custom_fields)

            return card

        except Exception as e:
            logger.error(f"Failed to create card: {e}")
            return None


def _build_field_post_args(
    field: CustomFieldDefinition,
    value: Union[str, int, float, bool]
) -> Optional[dict]:
    """Build the POST args for setting a custom field value."""
    if field.field_type == 'text':
        return {'value': {'text': str(value)}}
    elif field.field_type == 'number':
        return {'value': {'number': str(value)}}
    elif field.field_type == 'checkbox':
        return {'value': {'checked': 'true' if value else 'false'}}
    elif field.field_type == 'list':
        option_id = _find_option_id(field, value)
        if not option_id:
            logger.warning(f"Option '{value}' not found for field '{field.name}'")
            return None
        return {'idValue': option_id}
    elif field.field_type == 'date':
        return {'value': {'date': str(value)}}
    else:
        logger.warning(f"Unknown field type: {field.field_type}")
        return None


def _find_option_id(field: CustomFieldDefinition, value: Union[str, int, float, bool]) -> Optional[str]:
    """Find the option ID for a list-type custom field value."""
    value_str = str(value)
    for opt_id, opt_text in field.options.items():
        if opt_text.lower() == value_str.lower():
            return opt_id
    return None
