"""Workspace module for multi-repo configuration and management.

This module enables cross-repo awareness through workspace configuration,
project discovery, validation, and audit logging.
"""

from bpsai_pair.workspace.agent_spawning import AgentConfig, RoleMapping
from bpsai_pair.workspace.agent_teams import AgentTeamInfo, detect_agent_teams
from bpsai_pair.workspace.audit import WorkspaceAuditEntry, WorkspaceAuditLog
from bpsai_pair.workspace.contracts import ContractChange, ContractDetector
from bpsai_pair.workspace.discovery import ProjectDiscovery, ProjectState
from bpsai_pair.workspace.impact import ImpactAnalyzer, ImpactReport
from bpsai_pair.workspace.orchestrator import CrossRepoTask, WorkspaceOrchestrator
from bpsai_pair.workspace.parser import WorkspaceParser
from bpsai_pair.workspace.permissions import PermissionMapping, PermissionProfile
from bpsai_pair.workspace.schema import ProjectConfig, WorkspaceConfig

__all__ = [
    "AgentConfig",
    "AgentTeamInfo",
    "ContractChange",
    "ContractDetector",
    "CrossRepoTask",
    "ImpactAnalyzer",
    "ImpactReport",
    "PermissionMapping",
    "PermissionProfile",
    "ProjectConfig",
    "RoleMapping",
    "ProjectDiscovery",
    "ProjectState",
    "WorkspaceAuditEntry",
    "WorkspaceAuditLog",
    "WorkspaceConfig",
    "WorkspaceOrchestrator",
    "WorkspaceParser",
    "detect_agent_teams",
]
