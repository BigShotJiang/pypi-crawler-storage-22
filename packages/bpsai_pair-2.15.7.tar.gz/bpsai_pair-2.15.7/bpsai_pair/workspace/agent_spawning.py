"""Role-based agent spawning with effort pass-through.

Maps PairCoder roles (Navigator/Driver/Reviewer) to Claude Code agent
team members, propagating effort levels from the calibration engine.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

_ALL_ROLES = ["navigator", "driver", "reviewer"]

_ROLE_MAPPINGS = {
    "navigator": {"team_role": "lead", "default_effort": "high"},
    "driver": {"team_role": "teammate", "default_effort": "medium"},
    "reviewer": {"team_role": "teammate", "default_effort": "medium"},
}


@dataclass
class RoleMapping:
    """Mapping from PairCoder role to agent team role.

    Attributes:
        paircoder_role: PairCoder role name.
        team_role: Agent team role (lead/teammate).
        default_effort: Default effort level for this role.
    """

    paircoder_role: str
    team_role: str
    default_effort: str

    def to_dict(self) -> dict[str, str]:
        """Serialize to dictionary."""
        return {
            "paircoder_role": self.paircoder_role,
            "team_role": self.team_role,
            "default_effort": self.default_effort,
        }


@dataclass
class AgentConfig:
    """Configuration for a single agent in a team.

    Attributes:
        agent_name: Unique name for this agent.
        paircoder_role: PairCoder role (navigator/driver/reviewer).
        team_role: Agent team role (lead/teammate).
        effort_level: Effort level from calibration.
        project: Target project name.
    """

    agent_name: str
    paircoder_role: str
    team_role: str
    effort_level: str
    project: str

    def to_dict(self) -> dict[str, str]:
        """Serialize to dictionary."""
        return {
            "agent_name": self.agent_name,
            "paircoder_role": self.paircoder_role,
            "team_role": self.team_role,
            "effort_level": self.effort_level,
            "project": self.project,
        }


def get_role_mapping(role: str) -> RoleMapping:
    """Get the team role mapping for a PairCoder role."""
    mapping = _ROLE_MAPPINGS.get(
        role.lower(),
        {"team_role": "teammate", "default_effort": "medium"},
    )
    return RoleMapping(
        paircoder_role=role.lower(),
        team_role=mapping["team_role"],
        default_effort=mapping["default_effort"],
    )


def read_skill_roles(skill_path: Path) -> list[str]:
    """Read agent-roles from a skill's SKILL.md frontmatter.

    Returns:
        List of role names, or empty list if not found.
    """
    if not skill_path.exists():
        return []
    try:
        content = skill_path.read_text(encoding="utf-8")
        frontmatter = _parse_frontmatter(content)
        roles = frontmatter.get("agent-roles", [])
        if isinstance(roles, list) and roles == ["any"]:
            return list(_ALL_ROLES)
        return [r for r in roles if isinstance(r, str)]
    except Exception:
        logger.debug("Failed to read skill roles from %s", skill_path)
        return []


def generate_agent_configs(
    workspace: Any, feedback: Any,
) -> list[AgentConfig]:
    """Generate agent team configs from workspace and feedback.

    Creates one config per (project, role) combination. Navigator
    always gets high effort; Driver uses feedback recommendation;
    Reviewer defaults to medium.
    """
    if not workspace.projects:
        return []

    configs: list[AgentConfig] = []
    for proj_name in workspace.projects:
        for role in _ALL_ROLES:
            mapping = get_role_mapping(role)
            effort = _resolve_effort(role, feedback)
            configs.append(AgentConfig(
                agent_name=f"{proj_name}-{role}",
                paircoder_role=role,
                team_role=mapping.team_role,
                effort_level=effort,
                project=proj_name,
            ))
    return configs


def _resolve_effort(role: str, feedback: Any) -> str:
    """Resolve effort level for a role using feedback service."""
    if role == "navigator":
        return "high"
    if role == "reviewer":
        return "medium"
    try:
        return feedback.get_effort_recommendation(role)
    except Exception:
        return get_role_mapping(role).default_effort


def _parse_frontmatter(content: str) -> dict[str, Any]:
    """Parse YAML frontmatter from markdown content."""
    if not content.startswith("---"):
        return {}
    end = content.find("---", 3)
    if end == -1:
        return {}
    try:
        return yaml.safe_load(content[3:end]) or {}
    except yaml.YAMLError:
        return {}
