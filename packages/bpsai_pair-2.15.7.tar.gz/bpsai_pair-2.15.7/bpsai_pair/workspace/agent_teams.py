"""Agent team detection for workspace status.

Scans ~/.claude/teams/ for active Claude Code agent teams
and reports their status in workspace commands.

Read-only: never writes to ~/.claude/teams/.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class AgentTeamInfo:
    """Information about a detected agent team."""

    team_name: str
    agent_count: int
    agent_ids: list[str]
    created_at: datetime
    is_active: bool

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "team_name": self.team_name,
            "agent_count": self.agent_count,
            "agent_ids": self.agent_ids,
            "created_at": self.created_at.isoformat(),
            "is_active": self.is_active,
        }


def detect_agent_teams(
    claude_dir: Path | None = None,
) -> list[AgentTeamInfo]:
    """Scan ~/.claude/teams/ for active agent teams.

    Args:
        claude_dir: Override for ~/.claude directory (for testing).

    Returns:
        List of detected agent teams. Empty list if none found.
    """
    teams_dir = (claude_dir or Path.home() / ".claude") / "teams"
    if not teams_dir.exists():
        return []

    teams: list[AgentTeamInfo] = []
    try:
        for team_dir in sorted(teams_dir.iterdir()):
            if not team_dir.is_dir():
                continue
            config_path = team_dir / "config.json"
            if not config_path.exists():
                continue
            team = _parse_team_config(team_dir, config_path)
            if team is not None:
                teams.append(team)
    except PermissionError:
        logger.debug("Permission denied reading teams directory: %s", teams_dir)
    except OSError as e:
        logger.debug("Error reading teams directory: %s", e)

    return teams


def _parse_team_config(
    team_dir: Path, config_path: Path,
) -> AgentTeamInfo | None:
    """Parse a team config.json into AgentTeamInfo."""
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        logger.debug("Failed to parse team config %s: %s", config_path, e)
        return None

    agents = raw.get("agents", [])
    agent_ids = [a.get("agent_id", "") for a in agents if isinstance(a, dict)]

    created_str = raw.get("created_at", "")
    try:
        created_at = datetime.fromisoformat(created_str)
    except (ValueError, TypeError):
        created_at = datetime.now(timezone.utc)

    return AgentTeamInfo(
        team_name=raw.get("team_name", team_dir.name),
        agent_count=len(agent_ids),
        agent_ids=agent_ids,
        created_at=created_at,
        is_active=raw.get("is_active", True),
    )
