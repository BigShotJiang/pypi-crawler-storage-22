"""Workspace-level audit log storage.

Tracks cross-repo operations in a JSONL file at workspace root,
providing traceability for multi-project operations.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_LOG_FILENAME = ".paircoder-audit.jsonl"


@dataclass
class WorkspaceAuditEntry:
    """A single workspace audit log entry.

    Attributes:
        timestamp: When the action occurred (UTC).
        action: Action type (task_created, pull_completed, etc.).
        projects: Projects involved in the action.
        details: Action-specific data.
        user: Git user who performed the action, or None.
    """

    timestamp: datetime
    action: str
    projects: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)
    user: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "action": self.action,
            "projects": self.projects,
            "details": self.details,
            "user": self.user,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WorkspaceAuditEntry:
        """Deserialize from dictionary."""
        ts = data["timestamp"]
        if isinstance(ts, str):
            ts = datetime.fromisoformat(ts)
        return cls(
            timestamp=ts,
            action=data["action"],
            projects=data.get("projects", []),
            details=data.get("details", {}),
            user=data.get("user"),
        )

    def to_json_line(self) -> str:
        """Serialize to a single JSON line."""
        return json.dumps(self.to_dict())


class WorkspaceAuditLog:
    """Workspace-level audit log backed by a JSONL file."""

    def __init__(self, workspace_root: Path) -> None:
        self.log_path = workspace_root / _LOG_FILENAME

    def append(
        self,
        action: str,
        projects: list[str],
        details: dict[str, Any],
        user: str | None = None,
    ) -> WorkspaceAuditEntry:
        """Append an audit entry.

        Returns:
            The created WorkspaceAuditEntry.
        """
        entry = WorkspaceAuditEntry(
            timestamp=datetime.now(timezone.utc),
            action=action,
            projects=projects,
            details=details,
            user=user,
        )
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(entry.to_json_line() + "\n")
        return entry

    def query(
        self,
        action: str | None = None,
        project: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[WorkspaceAuditEntry]:
        """Query audit entries with optional filters."""
        entries = self._read_all()
        if action is not None:
            entries = [e for e in entries if e.action == action]
        if project is not None:
            entries = [e for e in entries if project in e.projects]
        if since is not None:
            entries = [e for e in entries if e.timestamp >= since]
        return entries[:limit]

    def get_project_history(
        self, project: str,
    ) -> list[WorkspaceAuditEntry]:
        """Get all entries involving a specific project."""
        return self.query(project=project, limit=10000)

    def _read_all(self) -> list[WorkspaceAuditEntry]:
        """Read all valid entries from the JSONL file."""
        if not self.log_path.exists():
            return []
        entries: list[WorkspaceAuditEntry] = []
        try:
            with open(self.log_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entries.append(
                            WorkspaceAuditEntry.from_dict(json.loads(line))
                        )
                    except (json.JSONDecodeError, KeyError, ValueError):
                        logger.debug("Skipping malformed audit line")
        except OSError as e:
            logger.warning("Error reading audit log: %s", e)
        return entries
