"""Contract change detector for cross-repo impact analysis.

Detects API schema changes, CLI command signature changes, route changes,
and config format changes in a repo since a given commit.
"""

from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Heuristic patterns for contract-relevant files
_PATTERNS: list[tuple[str, str]] = [
    ("schema", "schema_change"),
    ("route", "route_change"),
    ("endpoint", "route_change"),
    ("command", "command_change"),
    ("cli", "command_change"),
]

_CONFIG_EXTENSIONS = {".yaml", ".yml", ".json"}
_IGNORE_PREFIXES = ("tests/", "test_", "docs/", "doc/")


@dataclass
class ContractChange:
    """A detected contract-level change in a repository.

    Attributes:
        repo: Repository name where the change occurred.
        file: Relative file path that changed.
        change_type: Type of change (schema/route/command/config).
        description: Human-readable change description.
        affected_consumers: Projects that may be impacted.
    """

    repo: str
    file: str
    change_type: str
    description: str
    affected_consumers: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "repo": self.repo,
            "file": self.file,
            "change_type": self.change_type,
            "description": self.description,
            "affected_consumers": self.affected_consumers,
        }


class ContractDetector:
    """Detects contract-level changes in workspace repos.

    Uses git diff to find changed files, then applies heuristics
    to classify changes and map them to affected consumers.
    """

    def __init__(self, workspace: Any) -> None:
        self.workspace = workspace

    def detect_changes(
        self,
        repo_path: Path,
        since_commit: str,
        *,
        repo_name: str = "",
    ) -> list[ContractChange]:
        """Detect contract changes since a given commit.

        Args:
            repo_path: Absolute path to the repo.
            since_commit: Git commit hash to diff from.
            repo_name: Repo name for consumer lookup.

        Returns:
            List of detected ContractChange objects.
        """
        files = _get_changed_files(repo_path, since_commit)
        consumers = _get_consumers(self.workspace, repo_name)
        changes: list[ContractChange] = []

        for filepath in files:
            change_type = _classify_file(filepath)
            if change_type is None:
                continue
            changes.append(ContractChange(
                repo=repo_name or str(repo_path.name),
                file=filepath,
                change_type=change_type,
                description=f"{change_type.replace('_', ' ').title()}: {filepath}",
                affected_consumers=consumers,
            ))

        return changes


def _get_changed_files(repo_path: Path, since_commit: str) -> list[str]:
    """Get list of files changed since a commit using git diff."""
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", since_commit, "HEAD"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.TimeoutExpired:
        logger.warning("git diff timed out in %s", repo_path)
        return []
    if result.returncode != 0:
        logger.warning("git diff failed in %s: %s", repo_path, result.stderr)
        return []
    return [f for f in result.stdout.strip().split("\n") if f]


def _classify_file(filepath: str) -> str | None:
    """Classify a file path as a contract change type, or None."""
    lower = filepath.lower()
    if any(lower.startswith(prefix) for prefix in _IGNORE_PREFIXES):
        return None

    path = Path(filepath)
    if path.suffix in _CONFIG_EXTENSIONS:
        return "config_change"

    for keyword, change_type in _PATTERNS:
        if keyword in lower:
            return change_type

    return None


def _get_consumers(workspace: Any, repo_name: str) -> list[str]:
    """Get consumers of a repo from the workspace dependency graph."""
    if not repo_name:
        return []
    project = workspace.get_project(repo_name)
    if project and hasattr(project, "consumers"):
        return list(project.consumers)
    return []
