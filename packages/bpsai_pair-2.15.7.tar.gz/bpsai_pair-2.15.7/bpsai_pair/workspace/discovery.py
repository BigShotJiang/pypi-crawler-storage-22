"""Project discovery and validation.

Locates and validates all projects in a workspace, providing runtime
verification that workspace configuration matches filesystem state.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from bpsai_pair.workspace.git_ops import git_branch, git_is_dirty, git_last_commit
from bpsai_pair.workspace.schema import WorkspaceConfig


@dataclass
class ProjectState:
    """Runtime state of a project in the workspace.

    Attributes:
        name: Project identifier.
        path: Absolute path to project directory.
        exists: Whether the path exists on disk.
        is_git_repo: Whether path contains .git directory.
        current_branch: Current git branch, or None.
        has_paircoder: Whether path contains .paircoder directory.
        last_commit: Short hash of last commit, or None.
        is_dirty: Whether working tree has uncommitted changes.
    """

    name: str
    path: Path
    exists: bool
    is_git_repo: bool
    current_branch: str | None
    has_paircoder: bool
    last_commit: str | None
    is_dirty: bool

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "name": self.name,
            "path": str(self.path),
            "exists": self.exists,
            "is_git_repo": self.is_git_repo,
            "current_branch": self.current_branch,
            "has_paircoder": self.has_paircoder,
            "last_commit": self.last_commit,
            "is_dirty": self.is_dirty,
        }


class ProjectDiscovery:
    """Discovers and validates projects in a workspace."""

    def __init__(self, workspace: WorkspaceConfig) -> None:
        self.workspace = workspace

    def discover_all(self) -> dict[str, ProjectState]:
        """Discover state of all projects in workspace."""
        return {
            name: self.discover_project(name)
            for name in self.workspace.projects
        }

    def discover_project(self, name: str) -> ProjectState:
        """Discover state of a single project."""
        proj = self.workspace.get_project(name)
        if proj is None:
            return ProjectState(
                name=name,
                path=self.workspace.root_path / name,
                exists=False,
                is_git_repo=False,
                current_branch=None,
                has_paircoder=False,
                last_commit=None,
                is_dirty=False,
            )

        abs_path = self.workspace.root_path / proj.path
        exists = abs_path.is_dir()

        if not exists:
            return ProjectState(
                name=name, path=abs_path, exists=False,
                is_git_repo=False, current_branch=None,
                has_paircoder=False, last_commit=None, is_dirty=False,
            )

        is_git = (abs_path / ".git").exists()
        has_paircoder = (abs_path / ".paircoder").exists()
        branch = git_branch(abs_path) if is_git else None
        last_commit = git_last_commit(abs_path) if is_git else None
        is_dirty = git_is_dirty(abs_path) if is_git else False

        return ProjectState(
            name=name, path=abs_path, exists=True,
            is_git_repo=is_git, current_branch=branch,
            has_paircoder=has_paircoder, last_commit=last_commit,
            is_dirty=is_dirty,
        )

    def get_valid_projects(self) -> list[str]:
        """Return names of valid, accessible projects.

        A project is valid if it exists, is a git repo, and has .paircoder.
        """
        states = self.discover_all()
        return [
            name for name, s in states.items()
            if s.exists and s.is_git_repo and s.has_paircoder
        ]

    def get_issues(self) -> list[str]:
        """Return list of discovery issues and warnings."""
        states = self.discover_all()
        issues: list[str] = []

        for name, s in states.items():
            if not s.exists:
                issues.append(f"Project '{name}': path does not exist")
            elif not s.is_git_repo:
                issues.append(f"Project '{name}': not a git repository")
            elif not s.has_paircoder:
                issues.append(
                    f"Project '{name}': missing .paircoder directory"
                )
            if s.is_dirty:
                issues.append(
                    f"Project '{name}': has uncommitted changes"
                )

        return issues


