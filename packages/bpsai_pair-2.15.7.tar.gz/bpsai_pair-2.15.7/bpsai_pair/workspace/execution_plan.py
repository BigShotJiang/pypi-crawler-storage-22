"""Execution plan generation with dependency resolution.

Sorts tasks into parallelizable phases, assigns agent configs,
and formats an execution plan for display.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _to_int_tokens(value: Any) -> int:
    """Coerce token estimate to int (handles int/float/TokenEstimate)."""
    if isinstance(value, (int, float)):
        return int(value)
    if hasattr(value, "total_tokens"):
        return int(value.total_tokens)
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


@dataclass
class ExecutionPhase:
    """A group of tasks that can execute in parallel.

    Attributes:
        phase_number: 1-indexed phase number.
        task_ids: Task IDs in this phase (sorted).
    """

    phase_number: int
    task_ids: list[str] = field(default_factory=list)

    @property
    def is_parallel(self) -> bool:
        """True if phase contains multiple tasks."""
        return len(self.task_ids) > 1


def resolve_phases(tasks: list[Any]) -> list[ExecutionPhase]:
    """Topologically sort tasks into parallelizable execution phases.

    Missing dependencies (not in task list) are treated as resolved.
    """
    if not tasks:
        return []

    task_ids = {t.id for t in tasks}
    # Filter depends_on to only include known task IDs
    deps: dict[str, set[str]] = {}
    for t in tasks:
        known_deps = {d for d in t.depends_on if d in task_ids}
        deps[t.id] = known_deps

    phases: list[ExecutionPhase] = []
    scheduled: set[str] = set()
    phase_num = 0

    max_phases = len(task_ids) + 1
    while len(scheduled) < len(task_ids) and phase_num < max_phases:
        phase_num += 1
        # Find tasks whose dependencies are all scheduled
        ready = sorted(
            tid for tid in task_ids - scheduled
            if deps[tid] <= scheduled
        )
        if not ready:
            # Circular dependency — schedule remaining
            ready = sorted(task_ids - scheduled)
        phases.append(ExecutionPhase(
            phase_number=phase_num,
            task_ids=ready,
        ))
        scheduled.update(ready)

    return phases


def format_execution_plan(
    phases: list[ExecutionPhase],
    task_map: dict[str, Any],
) -> str:
    """Format execution phases into a human-readable plan string."""
    if not phases:
        return "No tasks to execute."

    lines: list[str] = []
    total_tokens = 0

    for phase in phases:
        mode = "parallel" if phase.is_parallel else "sequential"
        lines.append(
            f"Phase {phase.phase_number} ({mode}, "
            f"{len(phase.task_ids)} task(s)):"
        )
        for tid in phase.task_ids:
            task = task_map.get(tid)
            if not task:
                lines.append(f"  - {tid} (unknown)")
                continue
            title = getattr(task, "title", tid)
            model = getattr(task, "recommended_model", "sonnet")
            effort = getattr(task, "effort_level", "medium")
            tokens = _to_int_tokens(getattr(task, "estimated_tokens", 0))
            total_tokens += tokens
            lines.append(
                f"  - {tid}: {title}"
                f"  [model={model}, effort={effort}, "
                f"~{tokens:,} tokens]"
            )
        lines.append("")

    lines.append(f"Total: {sum(len(p.task_ids) for p in phases)} tasks, "
                 f"{len(phases)} phases, ~{total_tokens:,} tokens")
    return "\n".join(lines)


def enrich_tasks_with_intelligence(
    tasks: list[Any], project_root: Path
) -> list[Any]:
    """Enrich tasks with intelligence-driven model escalation.

    Queries StateQuery per task and upgrades model to opus when
    escalation is recommended. Fails gracefully on any error.
    """
    try:
        from bpsai_pair.feedback.state_query import StateQuery
        sq = StateQuery(project_root)
    except (ImportError, OSError):
        logger.debug("StateQuery unavailable, skipping enrichment")
        return tasks

    for task in tasks:
        try:
            task_type = getattr(task, "type", "feature")
            model = getattr(task, "recommended_model", "sonnet")
            if sq.should_escalate_model(task_type, model):
                task.recommended_model = "opus"
        except (AttributeError, OSError, ValueError, RuntimeError):
            logger.debug("Enrichment failed for task %s", getattr(task, "id", "?"))
            continue

    return tasks


def build_execution_plan(
    tasks: list[Any], project_root: Path | None = None
) -> dict[str, Any]:
    """Build a complete execution plan from tasks.

    When project_root is provided, enriches tasks with intelligence
    before resolving phases.
    """
    if project_root is not None:
        enrich_tasks_with_intelligence(tasks, project_root)

    phases = resolve_phases(tasks)
    task_map = {t.id: t for t in tasks}
    formatted = format_execution_plan(phases, task_map)

    total_tokens = sum(
        _to_int_tokens(getattr(t, "estimated_tokens", 0)) for t in tasks
    )

    return {
        "phases": phases,
        "formatted": formatted,
        "total_tasks": len(tasks),
        "total_phases": len(phases),
        "total_tokens": total_tokens,
    }
