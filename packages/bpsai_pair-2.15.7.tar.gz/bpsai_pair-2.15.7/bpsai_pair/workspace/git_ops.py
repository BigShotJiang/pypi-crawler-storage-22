"""Shared git operations for workspace modules.

Provides common git helpers used by both discovery.py and
workspace_helpers.py to avoid duplication.
"""

from __future__ import annotations

import subprocess
from pathlib import Path


def git_branch(path: Path) -> str | None:
    """Get current git branch name."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=path, capture_output=True, text=True, timeout=5,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except (subprocess.SubprocessError, OSError):
        return None


def git_last_commit(path: Path) -> str | None:
    """Get short hash of last commit."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=path, capture_output=True, text=True, timeout=5,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except (subprocess.SubprocessError, OSError):
        return None


def git_is_dirty(path: Path) -> bool:
    """Check for uncommitted changes."""
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=path, capture_output=True, text=True, timeout=5,
        )
        return bool(result.stdout.strip()) if result.returncode == 0 else False
    except (subprocess.SubprocessError, OSError):
        return False


def git_pull(path: Path, rebase: bool = False) -> subprocess.CompletedProcess:
    """Run git pull in a project directory."""
    cmd = ["git", "pull"]
    if rebase:
        cmd.append("--rebase")
    return subprocess.run(
        cmd, cwd=path, capture_output=True, text=True, timeout=30,
    )
