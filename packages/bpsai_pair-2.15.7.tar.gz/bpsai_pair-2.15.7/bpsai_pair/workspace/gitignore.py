"""Gitignore management for workspace project initialization.

Ensures standard PairCoder patterns are present in a project's .gitignore.
"""

from __future__ import annotations

from pathlib import Path

# Patterns for ephemeral/session data that should not be committed
_PAIRCODER_PATTERNS = [
    ".paircoder/history/",
    ".paircoder/cache/",
    ".paircoder/.cli_version",
    ".paircoder/telemetry/telemetry.jsonl",
    ".paircoder/telemetry/audit.jsonl",
    ".paircoder/telemetry/session_snapshot.json",
    ".paircoder/feedback/calibration.json",
    ".claude/",
]

_SECTION_HEADER = "# PairCoder — ephemeral/session data"


def ensure_gitignore(project_path: Path) -> list[str]:
    """Ensure .gitignore contains standard PairCoder patterns.

    Creates .gitignore if missing. Appends only patterns not already present.
    Idempotent — safe to call multiple times.

    Args:
        project_path: Root directory of the project.

    Returns:
        List of patterns that were added (empty if all already present).
    """
    gitignore_path = project_path / ".gitignore"
    existing = _read_existing(gitignore_path)
    missing = [p for p in _PAIRCODER_PATTERNS if p not in existing]
    if not missing:
        return []
    _append_patterns(gitignore_path, missing, existing)
    return missing


def _read_existing(gitignore_path: Path) -> set[str]:
    """Read existing .gitignore lines into a set for lookup."""
    if not gitignore_path.exists():
        return set()
    content = gitignore_path.read_text(encoding="utf-8")
    return {line.strip() for line in content.splitlines()}


def _append_patterns(
    gitignore_path: Path, patterns: list[str], existing: set[str],
) -> None:
    """Append missing patterns to .gitignore with section header."""
    lines: list[str] = []
    if gitignore_path.exists():
        current = gitignore_path.read_text(encoding="utf-8")
        if current and not current.endswith("\n"):
            lines.append("")
    if _SECTION_HEADER not in existing:
        lines.append("")
        lines.append(_SECTION_HEADER)
    for pattern in patterns:
        lines.append(pattern)
    lines.append("")
    with gitignore_path.open("a", encoding="utf-8") as f:
        f.write("\n".join(lines))
