"""Consumer impact analyzer for cross-repo change tracking.

Traces workspace dependency graphs to determine which consumer repos
need updates when contract changes are detected.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from bpsai_pair.workspace.contracts import ContractChange

_SEVERITY_ORDER = {
    "schema_change": "high",
    "route_change": "high",
    "command_change": "medium",
    "config_change": "low",
}

_SEVERITY_RANK = {"low": 0, "medium": 1, "high": 2}

_ACTION_TEMPLATES = {
    "schema_change": "Update {consumer} to match new schema from {repo}",
    "route_change": "Update {consumer} API client for route changes in {repo}",
    "command_change": "Review {consumer} for CLI command changes in {repo}",
    "config_change": "Check {consumer} config compatibility with {repo}",
}


@dataclass
class ImpactReport:
    """Report of impact analysis across workspace repos.

    Attributes:
        changes: Original contract changes analyzed.
        affected_repos: Unique list of affected consumer repos.
        recommended_actions: Human-readable action items.
        severity: Overall severity (low/medium/high).
    """

    changes: list[ContractChange] = field(default_factory=list)
    affected_repos: list[str] = field(default_factory=list)
    recommended_actions: list[str] = field(default_factory=list)
    severity: str = "low"

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "changes": [c.to_dict() for c in self.changes],
            "affected_repos": self.affected_repos,
            "recommended_actions": self.recommended_actions,
            "severity": self.severity,
        }


class ImpactAnalyzer:
    """Analyzes contract changes to determine cross-repo impact.

    Usage:
        analyzer = ImpactAnalyzer(workspace_config)
        report = analyzer.analyze(changes)
    """

    def __init__(self, workspace: Any) -> None:
        self.workspace = workspace

    def analyze(self, changes: list[ContractChange]) -> ImpactReport:
        """Analyze contract changes and produce an impact report.

        Args:
            changes: List of detected contract changes.

        Returns:
            ImpactReport with affected repos, actions, and severity.
        """
        if not changes:
            return ImpactReport()

        affected = _collect_affected_repos(changes)
        severity = _compute_severity(changes)
        actions = _generate_actions(changes)

        return ImpactReport(
            changes=changes,
            affected_repos=sorted(affected),
            recommended_actions=actions,
            severity=severity,
        )


def _collect_affected_repos(changes: list[ContractChange]) -> set[str]:
    """Collect unique affected consumer repos from all changes."""
    affected: set[str] = set()
    for change in changes:
        affected.update(change.affected_consumers)
    return affected


def _compute_severity(changes: list[ContractChange]) -> str:
    """Compute overall severity as the max across all changes."""
    max_rank = 0
    for change in changes:
        sev = _SEVERITY_ORDER.get(change.change_type, "low")
        max_rank = max(max_rank, _SEVERITY_RANK.get(sev, 0))
    for name, rank in _SEVERITY_RANK.items():
        if rank == max_rank:
            return name
    return "low"


def _generate_actions(changes: list[ContractChange]) -> list[str]:
    """Generate recommended actions for each change."""
    actions: list[str] = []
    for change in changes:
        template = _ACTION_TEMPLATES.get(
            change.change_type,
            "Review {consumer} for changes in {repo}",
        )
        if change.affected_consumers:
            for consumer in change.affected_consumers:
                actions.append(
                    template.format(consumer=consumer, repo=change.repo)
                )
        else:
            actions.append(
                f"Review impact of {change.change_type} in {change.repo}"
            )
    return actions
