"""Workspace-aware project initializer.

Orchestrates project initialization: validate target, detect stack,
read sibling conventions, build config, scaffold files, update .gitignore.
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from bpsai_pair.workspace.gitignore import ensure_gitignore
from bpsai_pair.workspace.project_md import (
    detect_key_directories,
    generate_project_md,
)
from bpsai_pair.workspace.schema import WorkspaceConfig
from bpsai_pair.workspace.sibling_conventions import (
    ConventionDefaults,
    SiblingConventionReader,
)
from bpsai_pair.workspace.stack_detect import StackInfo, detect_stack


@dataclass
class InitResult:
    """Result of a project initialization attempt."""

    project_name: str
    project_path: Path
    created_files: list[str] = field(default_factory=list)
    inherited_from: list[str] = field(default_factory=list)
    stack_classification: str = "generic"
    dry_run: bool = False
    error: str | None = None
    error_code: int = 0


class ProjectInitializer:
    """Orchestrates workspace-aware project initialization."""

    def __init__(self, workspace: WorkspaceConfig) -> None:
        self._workspace = workspace

    def initialize(
        self, name: str, *, force: bool = False,
        dry_run: bool = False, include_claude: bool = True,
    ) -> InitResult:
        """Initialize a single project in the workspace."""
        error = self._validate(name, force)
        if error is not None:
            return error

        project = self._workspace.get_project(name)
        project_path = self._workspace.root_path / project.path
        stack = detect_stack(project_path)
        conventions = SiblingConventionReader(self._workspace).read_conventions(name)

        if dry_run:
            return InitResult(
                project_name=name, project_path=project_path,
                stack_classification=stack.classification,
                inherited_from=conventions.source_projects, dry_run=True,
            )

        if force and (project_path / ".paircoder").exists():
            _backup_existing(project_path / ".paircoder")

        created = _scaffold_project(
            project_path, name, self._workspace.name,
            project, stack, conventions, include_claude,
        )
        return InitResult(
            project_name=name, project_path=project_path,
            created_files=created, inherited_from=conventions.source_projects,
            stack_classification=stack.classification,
        )

    def _validate(self, name: str, force: bool) -> InitResult | None:
        """Validate target project. Returns InitResult with error, or None."""
        project = self._workspace.get_project(name)
        if project is None:
            return InitResult(
                project_name=name, project_path=Path("."),
                error=f"Project '{name}' not found in workspace",
                error_code=1,
            )
        project_path = self._workspace.root_path / project.path
        if not project_path.exists():
            return InitResult(
                project_name=name, project_path=project_path,
                error=f"Project path does not exist: {project_path}",
                error_code=3,
            )
        if (project_path / ".paircoder").exists() and not force:
            return InitResult(
                project_name=name, project_path=project_path,
                error="Already initialized. Use --force to overwrite.",
                error_code=2,
            )
        return None

    def initialize_all(
        self, *, force: bool = False, dry_run: bool = False,
        include_claude: bool = True,
    ) -> list[InitResult]:
        """Initialize all projects in the workspace."""
        results: list[InitResult] = []
        for name in self._workspace.get_project_names():
            try:
                result = self.initialize(
                    name, force=force, dry_run=dry_run,
                    include_claude=include_claude,
                )
            except Exception as exc:
                result = InitResult(
                    project_name=name,
                    project_path=self._workspace.root_path / name,
                    error=str(exc),
                )
            results.append(result)
        return results


def _backup_existing(paircoder_dir: Path) -> Path:
    """Create timestamped backup of existing .paircoder/ directory."""
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup = paircoder_dir.parent / f".paircoder-backup-{timestamp}"
    shutil.copytree(paircoder_dir, backup)
    shutil.rmtree(paircoder_dir)
    return backup


def _scaffold_project(
    project_path: Path, name: str, workspace_name: str,
    project_config: Any, stack: StackInfo,
    conventions: ConventionDefaults, include_claude: bool,
) -> list[str]:
    """Create .paircoder/ structure with config, project.md, and gitignore."""
    created: list[str] = []
    paircoder_dir = project_path / ".paircoder"
    context_dir = paircoder_dir / "context"
    context_dir.mkdir(parents=True, exist_ok=True)
    for subdir in ("plans", "tasks", "history", "cache"):
        (paircoder_dir / subdir).mkdir(exist_ok=True)

    config = _build_config(name, workspace_name, stack, conventions)
    (paircoder_dir / "config.yaml").write_text(
        yaml.dump(config, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    created.append("config.yaml")

    key_dirs = detect_key_directories(project_path)
    md_content = generate_project_md(
        name, workspace_name, project_config, stack, key_dirs,
    )
    (context_dir / "project.md").write_text(md_content, encoding="utf-8")
    created.append("context/project.md")

    _scaffold_from_template(project_path, include_claude)
    _inject_version_safe(project_path)
    ensure_gitignore(project_path)
    return created


def _build_config(
    name: str, workspace_name: str,
    stack: StackInfo, conventions: ConventionDefaults,
) -> dict[str, Any]:
    """Build config.yaml dict from stack info and inherited conventions."""
    config: dict[str, Any] = {
        "project": {"name": name},
        "workspace": {"name": workspace_name},
    }
    if conventions.models:
        config["models"] = conventions.models
    if conventions.architecture:
        config["architecture"] = conventions.architecture
    if conventions.coverage_target is not None:
        config["project"]["coverage_target"] = conventions.coverage_target
    if conventions.main_branch:
        config["workflow"] = {"main_branch": conventions.main_branch}
    if conventions.pack_excludes:
        config["pack"] = {"excludes": conventions.pack_excludes}
    if conventions.trello_enabled is not None:
        config["trello"] = {"enabled": conventions.trello_enabled}
    config["stack"] = {
        "classification": stack.classification,
        "language": stack.language,
    }
    if stack.framework:
        config["stack"]["framework"] = stack.framework
    return config


def _inject_version_safe(project_root: Path) -> None:
    """Inject package version into capabilities.yaml, ignoring errors."""
    try:
        from bpsai_pair.init_bundled_cli import inject_version
        inject_version(project_root)
    except Exception as exc:
        import logging
        logging.getLogger(__name__).debug("Version injection failed: %s", exc)


def _scaffold_from_template(project_root: Path, include_claude: bool) -> int:
    """Copy bundled scaffold files (capabilities, workflow, state, etc.)."""
    try:
        from importlib.resources import as_file

        from bpsai_pair.init_bundled_cli import (
            copytree_non_destructive,
            find_template_traversable,
        )

        template = find_template_traversable()
        if template is None:
            return 0
        with as_file(template) as template_root:
            copied = copytree_non_destructive(template_root, project_root)
        if not include_claude:
            _remove_claude_scaffold(project_root)
        return copied
    except Exception:
        return 0


def _remove_claude_scaffold(project_root: Path) -> None:
    """Remove .claude/ directory if --no-claude was requested."""
    claude_dir = project_root / ".claude"
    if claude_dir.exists():
        shutil.rmtree(claude_dir)
