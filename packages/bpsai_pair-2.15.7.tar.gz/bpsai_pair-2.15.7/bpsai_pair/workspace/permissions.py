"""Permission mode mapping for agent teams.

Maps PairCoder containment tiers to Claude Code permission modes,
enabling per-agent permission enforcement based on role.

Role → Permission Mode mapping:
- Navigator → plan (read-only, planning coordination)
- Driver → auto (file edit allowed, config blocked)
- Reviewer → plan (read-only with audit write)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

_BLOCKED_PATHS_DRIVER = [
    ".env",
    ".env.local",
    ".env.production",
    "credentials.json",
    "secrets.yaml",
    ".paircoder/config.yaml",
    "CLAUDE.md",
    ".claude/skills/",
    ".claude/agents/",
]

_ROLE_PROFILES: dict[str, dict[str, Any]] = {
    "navigator": {
        "permission_mode": "plan",
        "containment_tier": "readonly",
        "allowed_paths": [],
        "blocked_paths": [],
    },
    "driver": {
        "permission_mode": "auto",
        "containment_tier": "readwrite",
        "allowed_paths": ["src/", "lib/", "tests/", ".paircoder/tasks/"],
        "blocked_paths": list(_BLOCKED_PATHS_DRIVER),
    },
    "reviewer": {
        "permission_mode": "plan",
        "containment_tier": "readonly",
        "allowed_paths": [],
        "blocked_paths": [],
    },
}

_DEFAULT_PROFILE: dict[str, Any] = {
    "permission_mode": "plan",
    "containment_tier": "readonly",
    "allowed_paths": [],
    "blocked_paths": [],
}


@dataclass
class PermissionMapping:
    """Maps a PairCoder role to a Claude Code permission mode.

    Attributes:
        paircoder_role: PairCoder role name.
        claude_permission_mode: Claude Code permission mode (auto/plan/full).
        containment_tier: Containment tier (blocked/readonly/readwrite).
        rationale: Why this mapping was chosen.
    """

    paircoder_role: str
    claude_permission_mode: str
    containment_tier: str
    rationale: str

    def to_dict(self) -> dict[str, str]:
        """Serialize to dictionary."""
        return {
            "paircoder_role": self.paircoder_role,
            "claude_permission_mode": self.claude_permission_mode,
            "containment_tier": self.containment_tier,
            "rationale": self.rationale,
        }


@dataclass
class PermissionProfile:
    """Permission profile for a specific role.

    Attributes:
        role: PairCoder role name.
        permission_mode: Claude Code permission mode.
        containment_tier: Containment tier.
        allowed_paths: Paths explicitly allowed for writing.
        blocked_paths: Paths blocked from access.
    """

    role: str
    permission_mode: str
    containment_tier: str
    allowed_paths: list[str] = field(default_factory=list)
    blocked_paths: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "role": self.role,
            "permission_mode": self.permission_mode,
            "containment_tier": self.containment_tier,
            "allowed_paths": self.allowed_paths,
            "blocked_paths": self.blocked_paths,
        }


def get_permission_profile(role: str) -> PermissionProfile:
    """Get the permission profile for a PairCoder role."""
    key = role.lower()
    data = _ROLE_PROFILES.get(key, _DEFAULT_PROFILE)
    return PermissionProfile(
        role=key,
        permission_mode=data["permission_mode"],
        containment_tier=data["containment_tier"],
        allowed_paths=list(data.get("allowed_paths", [])),
        blocked_paths=list(data.get("blocked_paths", [])),
    )


def generate_team_permissions(
    agent_configs: list[Any],
) -> list[dict[str, Any]]:
    """Generate permission configs for a list of agent configs.

    Takes AgentConfig objects from agent_spawning and produces
    permission configuration dicts for each agent.
    """
    results: list[dict[str, Any]] = []
    for config in agent_configs:
        profile = get_permission_profile(config.paircoder_role)
        results.append({
            "agent_name": config.agent_name,
            "role": config.paircoder_role,
            "permission_mode": profile.permission_mode,
            "containment_tier": profile.containment_tier,
            "allowed_paths": profile.allowed_paths,
            "blocked_paths": profile.blocked_paths,
        })
    return results
