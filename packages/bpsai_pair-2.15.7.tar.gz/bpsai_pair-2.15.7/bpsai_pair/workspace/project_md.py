"""Workspace-aware project.md generation.

Generates project.md content with workspace context, tech stack,
key directories, and dependency relationships.
"""

from __future__ import annotations

from pathlib import Path

from bpsai_pair.workspace.schema import ProjectConfig
from bpsai_pair.workspace.stack_detect import StackInfo

# Directories to scan for, in display order
_KNOWN_DIRS = [
    "src", "lib", "app", "tests", "test", "docs", "scripts", "config",
]


def generate_project_md(
    project_name: str,
    workspace_name: str,
    project_config: ProjectConfig,
    stack: StackInfo,
    key_directories: list[str],
) -> str:
    """Generate workspace-aware project.md content.

    Args:
        project_name: Name of the project being initialized.
        workspace_name: Name of the parent workspace.
        project_config: Project configuration from workspace.
        stack: Detected tech stack information.
        key_directories: List of key directory names (e.g. ["src/", "tests/"]).

    Returns:
        Complete project.md content as a string.
    """
    sections = [
        _header_section(project_name, workspace_name),
        _workspace_role_section(workspace_name, project_config),
        _tech_stack_section(stack),
    ]
    if key_directories:
        sections.append(_key_directories_section(key_directories))
    sections.append(_getting_started_section())
    return "\n".join(sections)


def _header_section(project_name: str, workspace_name: str) -> str:
    """Generate header with project name and workspace context."""
    return (
        f"# {project_name}\n\n"
        f"> Part of the **{workspace_name}** workspace\n"
    )


def _workspace_role_section(
    workspace_name: str, config: ProjectConfig,
) -> str:
    """Generate workspace role section with relationships."""
    lines = ["\n## Workspace Role\n"]
    lines.append(f"- **Workspace:** {workspace_name}")
    if config.repo:
        lines.append(f"- **Repository:** {config.repo}")
    if config.consumers:
        names = ", ".join(config.consumers)
        lines.append(f"- **Consumed by:** {names}")
    if config.consumes:
        names = ", ".join(config.consumes)
        lines.append(f"- **Depends on:** {names}")
    return "\n".join(lines) + "\n"


def _tech_stack_section(stack: StackInfo) -> str:
    """Generate tech stack section from StackInfo."""
    lines = ["\n## Tech Stack\n"]
    lines.append(f"- **Language:** {stack.language}")
    if stack.framework:
        lines.append(f"- **Framework:** {stack.framework}")
    lines.append(f"- **Classification:** {stack.classification}")
    if stack.test_framework:
        lines.append(f"- **Test Framework:** {stack.test_framework}")
    return "\n".join(lines) + "\n"


def _key_directories_section(directories: list[str]) -> str:
    """Generate key directories section."""
    lines = ["\n## Key Directories\n"]
    for d in directories:
        lines.append(f"- `{d}`")
    return "\n".join(lines) + "\n"


def _getting_started_section() -> str:
    """Generate getting started placeholder section."""
    return (
        "\n## Getting Started\n\n"
        "<!-- TODO: Add setup instructions, dev commands, and local development notes -->\n"
    )


def detect_key_directories(project_path: Path) -> list[str]:
    """Scan for common project directories.

    Returns:
        List of directory names with trailing slash (e.g. ["src/", "tests/"]).
    """
    found = []
    for name in _KNOWN_DIRS:
        if (project_path / name).is_dir():
            found.append(f"{name}/")
    return found
