"""Workspace configuration schema.

Defines data structures for multi-repo workspace configuration,
enabling cross-repo awareness and orchestration.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class ProjectConfig:
    """Configuration for a single project in a workspace.

    Attributes:
        name: Project identifier (e.g., 'cli', 'api', 'web').
        path: Relative path from workspace root.
        repo: GitHub repo URL (optional).
        consumers: Projects that depend on this one.
        consumes: Projects this depends on.
        branch: Default branch name.
    """

    name: str
    path: Path
    repo: str | None = None
    consumers: list[str] = field(default_factory=list)
    consumes: list[str] = field(default_factory=list)
    branch: str = "main"

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "name": self.name,
            "path": str(self.path),
            "repo": self.repo,
            "consumers": self.consumers,
            "consumes": self.consumes,
            "branch": self.branch,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProjectConfig:
        """Deserialize from dictionary."""
        return cls(
            name=data["name"],
            path=Path(data["path"]),
            repo=data.get("repo"),
            consumers=data.get("consumers", []),
            consumes=data.get("consumes", []),
            branch=data.get("branch", "main"),
        )


@dataclass
class WorkspaceConfig:
    """Configuration for a multi-repo workspace.

    Attributes:
        name: Workspace name.
        projects: Dict mapping project name to ProjectConfig.
        root_path: Absolute path to workspace root directory.
        config_path: Path to the .paircoder-workspace.yaml file.
    """

    name: str
    projects: dict[str, ProjectConfig]
    root_path: Path
    config_path: Path

    def get_project_names(self) -> list[str]:
        """Return list of project names."""
        return list(self.projects.keys())

    def get_project(self, name: str) -> ProjectConfig | None:
        """Return project by name, or None if not found."""
        return self.projects.get(name)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "name": self.name,
            "projects": {k: v.to_dict() for k, v in self.projects.items()},
            "root_path": str(self.root_path),
            "config_path": str(self.config_path),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WorkspaceConfig:
        """Deserialize from dictionary."""
        projects = {
            k: ProjectConfig.from_dict({**v, "name": k})
            for k, v in data["projects"].items()
        }
        return cls(
            name=data["name"],
            projects=projects,
            root_path=Path(data["root_path"]),
            config_path=Path(data["config_path"]),
        )
