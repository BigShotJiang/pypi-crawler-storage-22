"""Sibling convention reader for workspace project initialization.

Reads config.yaml from initialized sibling projects and merges
inheritable settings into convention defaults.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from bpsai_pair.workspace.schema import WorkspaceConfig


@dataclass
class ConventionDefaults:
    """Merged defaults from sibling project configs."""

    models: dict[str, str] | None = None
    routing: dict[str, Any] | None = None
    architecture: dict[str, Any] | None = None
    coverage_target: int | None = None
    main_branch: str | None = None
    pack_excludes: list[str] = field(default_factory=list)
    trello_enabled: bool | None = None
    source_projects: list[str] = field(default_factory=list)


class SiblingConventionReader:
    """Reads config.yaml from initialized siblings and merges conventions."""

    def __init__(self, workspace: WorkspaceConfig) -> None:
        self._workspace = workspace

    def read_conventions(self, exclude_project: str) -> ConventionDefaults:
        """Read and merge conventions from all siblings except exclude_project."""
        configs = self._collect_sibling_configs(exclude_project)
        if not configs:
            return ConventionDefaults()
        return self._merge_configs(configs)

    def _collect_sibling_configs(
        self, exclude: str,
    ) -> list[tuple[str, dict[str, Any]]]:
        """Read config.yaml from each initialized sibling."""
        configs: list[tuple[str, dict[str, Any]]] = []
        for name, proj in self._workspace.projects.items():
            if name == exclude:
                continue
            config = self._read_sibling_config(name, proj.path)
            if config is not None:
                configs.append((name, config))
        return configs

    def _read_sibling_config(
        self, name: str, rel_path: Path,
    ) -> dict[str, Any] | None:
        """Read a single sibling's config.yaml, return None if unreadable."""
        config_path = self._workspace.root_path / rel_path / ".paircoder" / "config.yaml"
        if not config_path.exists():
            return None
        try:
            data = yaml.safe_load(config_path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else None
        except (yaml.YAMLError, OSError):
            return None

    def _merge_configs(
        self, configs: list[tuple[str, dict[str, Any]]],
    ) -> ConventionDefaults:
        """Merge sibling configs into ConventionDefaults.

        Strategies:
        - First-sibling-wins: models, routing, architecture, coverage, trello
        - Majority-wins: main_branch
        - Union: pack_excludes
        """
        source_projects = [name for name, _ in configs]

        # First-sibling-wins for simple settings
        models = _first_value(configs, "models")
        routing = _first_value(configs, "routing")
        architecture = _first_value(configs, "architecture")
        coverage_target = _first_nested(configs, "project", "coverage_target")
        trello_enabled = _first_nested(configs, "trello", "enabled")

        # Majority-wins for main_branch
        main_branch = _majority_value(configs, "workflow", "main_branch")

        # Union for pack excludes
        pack_excludes = _union_list(configs, "pack", "excludes")

        return ConventionDefaults(
            models=models,
            routing=routing,
            architecture=architecture,
            coverage_target=coverage_target,
            main_branch=main_branch,
            pack_excludes=pack_excludes,
            trello_enabled=trello_enabled,
            source_projects=source_projects,
        )


def _first_value(
    configs: list[tuple[str, dict[str, Any]]], key: str,
) -> Any | None:
    """Return first non-None value for a top-level key."""
    for _, cfg in configs:
        val = cfg.get(key)
        if val is not None:
            return val
    return None


def _first_nested(
    configs: list[tuple[str, dict[str, Any]]], section: str, key: str,
) -> Any | None:
    """Return first non-None value for a nested key (section.key)."""
    for _, cfg in configs:
        section_data = cfg.get(section)
        if isinstance(section_data, dict):
            val = section_data.get(key)
            if val is not None:
                return val
    return None


def _majority_value(
    configs: list[tuple[str, dict[str, Any]]], section: str, key: str,
) -> str | None:
    """Return the most common value for a nested key."""
    from collections import Counter
    values: list[str] = []
    for _, cfg in configs:
        section_data = cfg.get(section)
        if isinstance(section_data, dict):
            val = section_data.get(key)
            if val is not None:
                values.append(val)
    if not values:
        return None
    return Counter(values).most_common(1)[0][0]


def _union_list(
    configs: list[tuple[str, dict[str, Any]]], section: str, key: str,
) -> list[str]:
    """Union all list values for a nested key across configs."""
    result: set[str] = set()
    for _, cfg in configs:
        section_data = cfg.get(section)
        if isinstance(section_data, dict):
            val = section_data.get(key)
            if isinstance(val, list):
                result.update(val)
    return sorted(result)
