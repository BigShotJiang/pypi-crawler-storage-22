"""Tech stack detection for workspace projects.

Scans project directories for marker files and classifies the tech stack.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

# Classification → Trello-compatible stack label
_STACK_LABELS: dict[str, str] = {
    "python-azure-functions": "Worker/Function",
    "python-fastapi": "Worker/Function",
    "python-django": "Worker/Function",
    "python-package": "Package",
    "javascript-next": "React",
    "javascript-react": "React",
    "javascript-node": "Worker/Function",
    "generic": "Package",
}


@dataclass(frozen=True)
class StackInfo:
    """Result of stack detection for a project directory."""

    classification: str
    language: str
    framework: str | None
    detected_markers: list[str] = field(default_factory=list)
    test_framework: str | None = None
    stack_label: str = "Package"


def detect_stack(project_path: Path) -> StackInfo:
    """Detect the tech stack of a project from directory markers.

    Checks heuristics in priority order (most specific first).

    Args:
        project_path: Root directory of the project to scan.

    Returns:
        StackInfo with classification, language, framework, and evidence.
    """
    result = _check_python_frameworks(project_path)
    if result:
        return result

    markers = _check_python_package(project_path)
    if markers:
        return _build_info("python-package", "python", None, markers, project_path)

    result = _check_javascript(project_path)
    if result:
        return result

    return _build_info("generic", "unknown", None, [], project_path)


def _check_python_frameworks(path: Path) -> StackInfo | None:
    """Check for specific Python frameworks (most specific first)."""
    # Azure Functions: host.json + function_app.py
    if (path / "host.json").exists() and (path / "function_app.py").exists():
        return _build_info(
            "python-azure-functions", "python", "Azure Functions",
            ["host.json", "function_app.py"], path,
        )

    has_requirements = (path / "requirements.txt").exists()

    # FastAPI: requirements.txt + src/ + fastapi in requirements
    if has_requirements and (path / "src").is_dir():
        try:
            reqs = (path / "requirements.txt").read_text(encoding="utf-8").lower()
        except (OSError, UnicodeDecodeError):
            reqs = ""
        if "fastapi" in reqs:
            markers = ["requirements.txt", "src/"]
            if (path / "openapi.json").exists():
                markers.append("openapi.json")
            return _build_info(
                "python-fastapi", "python", "FastAPI", markers, path,
            )

    # Django: requirements.txt + manage.py
    if has_requirements and (path / "manage.py").exists():
        return _build_info(
            "python-django", "python", "Django",
            ["requirements.txt", "manage.py"], path,
        )

    return None


def _check_javascript(path: Path) -> StackInfo | None:
    """Check for JavaScript frameworks (most specific first)."""
    pkg_path = path / "package.json"
    if not pkg_path.exists():
        return None

    markers = ["package.json"]

    # Next.js: package.json + next.config.*
    next_cfg = next(path.glob("next.config.*"), None)
    if next_cfg is not None:
        markers.append(next_cfg.name)
        return _build_info(
            "javascript-next", "javascript", "Next.js", markers, path,
        )

    # React: package.json + src/ + "react" in dependencies
    if (path / "src").is_dir():
        try:
            pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            if "react" in deps:
                return _build_info(
                    "javascript-react", "javascript", "React", markers, path,
                )
        except (json.JSONDecodeError, KeyError):
            pass

    # Generic Node.js: just package.json
    return _build_info("javascript-node", "javascript", None, markers, path)


def _check_python_package(path: Path) -> list[str]:
    """Check for Python package markers (pyproject.toml or setup.py)."""
    markers = []
    if (path / "pyproject.toml").exists():
        markers.append("pyproject.toml")
    if (path / "setup.py").exists():
        markers.append("setup.py")
    return markers


def _detect_test_framework(path: Path) -> str | None:
    """Detect test framework from marker files."""
    if (path / "pytest.ini").exists() or (path / "conftest.py").exists():
        return "pytest"
    if next(path.glob("jest.config.*"), None) is not None:
        return "jest"
    return None


def _build_info(
    classification: str,
    language: str,
    framework: str | None,
    markers: list[str],
    project_path: Path,
) -> StackInfo:
    """Build a StackInfo with stack_label and test_framework."""
    return StackInfo(
        classification=classification,
        language=language,
        framework=framework,
        detected_markers=markers,
        test_framework=_detect_test_framework(project_path),
        stack_label=_STACK_LABELS.get(classification, "Package"),
    )
