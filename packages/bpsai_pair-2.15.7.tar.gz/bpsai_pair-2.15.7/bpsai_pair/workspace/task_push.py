"""Cross-repo task file push operations.

Writes .task.md files to sibling repo .paircoder/tasks/ directories
and records the operation in the workspace audit log.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from bpsai_pair.workspace.audit import WorkspaceAuditLog

logger = logging.getLogger(__name__)


def push_task_files(
    tasks: list[Any],
    workspace: Any,
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Write .task.md files to sibling repo .paircoder/tasks/ dirs.

    Returns:
        Summary dict with pushed/skipped counts and file list.
    """
    pushed = 0
    skipped = 0
    files: list[str] = []
    repo_counters: dict[str, int] = {}

    for task in tasks:
        task_dir = _resolve_task_dir(workspace.root_path, task.repo, workspace)
        if task_dir is None:
            skipped += 1
            continue

        if task.repo not in repo_counters:
            repo_counters[task.repo] = _max_existing_seq(
                task_dir, task.task_id_prefix,
            )
        seq = repo_counters[task.repo] + 1
        repo_counters[task.repo] = seq
        task_id = f"{task.task_id_prefix}.{seq}"
        filename = f"{task_id}.task.md"
        filepath = str(task_dir / filename)

        if dry_run:
            files.append(filepath)
            continue

        task_dir.mkdir(parents=True, exist_ok=True)
        (task_dir / filename).write_text(
            _render_task_md(task, task_id), encoding="utf-8"
        )
        files.append(filepath)
        pushed += 1

    if dry_run:
        return _dry_run_result(files, skipped)

    if pushed > 0:
        _record_audit(tasks, workspace, pushed, files)

    return {"pushed": pushed, "skipped": skipped, "files": files}


def _dry_run_result(files: list[str], skipped: int) -> dict[str, Any]:
    """Build the result dict for a dry-run push."""
    return {
        "dry_run": True,
        "would_push": len(files),
        "files": files,
        "pushed": 0,
        "skipped": skipped,
    }


def _record_audit(
    tasks: list[Any], workspace: Any, pushed: int, files: list[str],
) -> None:
    """Record the push operation in the workspace audit log."""
    repos = list({
        t.repo for t in tasks
        if _resolve_task_dir(workspace.root_path, t.repo, workspace)
    })
    audit = WorkspaceAuditLog(workspace.root_path)
    audit.append(
        action="tasks_pushed",
        projects=repos,
        details={"count": pushed, "files": files},
    )


def _max_existing_seq(task_dir: Path, prefix: str) -> int:
    """Find the highest existing sequence number for a prefix in task_dir."""
    if not task_dir.exists():
        return 0
    max_seq = 0
    for f in task_dir.iterdir():
        name = f.name
        if name.startswith(prefix + ".") and name.endswith(".task.md"):
            # Extract sequence: "CLI-T35.3.task.md" → "3"
            middle = name[len(prefix) + 1 : -len(".task.md")]
            try:
                max_seq = max(max_seq, int(middle))
            except ValueError:
                continue
    return max_seq


def _resolve_task_dir(
    root: Path, repo: str, workspace: Any,
) -> Path | None:
    """Resolve the .paircoder/tasks/ directory for a repo."""
    project = workspace.get_project(repo)
    if project is None:
        return None
    repo_path = root / Path(project.path)
    if not repo_path.exists():
        logger.warning("Sibling directory missing: %s", repo_path)
        return None
    return repo_path / ".paircoder" / "tasks"


def _yaml_quote(value: str) -> str:
    """Quote a YAML string value if it contains special characters."""
    if (
        any(c in value for c in (":", "#", "\n", "'", '"', "{", "}", "[", "]"))
        or (value and value[0] in ("@", "*", "!"))
    ):
        escaped = value.replace("'", "''")
        return f"'{escaped}'"
    return value


def _render_task_md(task: Any, task_id: str) -> str:
    """Render a CrossRepoTask as a .task.md file."""
    deps = (
        "\n" + "\n".join(f"- {d}" for d in task.depends_on)
        if task.depends_on
        else " []"
    )
    title = _yaml_quote(task.title)
    return (
        f"---\n"
        f"id: {task_id}\n"
        f"title: {title}\n"
        f"type: feature\n"
        f"priority: P1\n"
        f"complexity: {task.estimated_tokens // 100}\n"
        f"status: pending\n"
        f"recommended_model: {task.recommended_model}\n"
        f"effort_level: {task.effort_level}\n"
        f"depends_on:{deps}\n"
        f"---\n\n"
        f"# {task.title}\n\n"
        f"Estimated tokens: {task.estimated_tokens}\n"
    )
