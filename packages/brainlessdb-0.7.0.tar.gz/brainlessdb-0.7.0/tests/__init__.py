"""Brainless DB test suite."""
