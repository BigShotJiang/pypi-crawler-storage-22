"""Test graceful error handling during bucket deserialization.

Verifies that corrupt items in buckets are skipped with a logged error
while valid items still load successfully.
"""

import logging
from uuid import uuid1

import msgspec
import pytest

from brainlessdb import BrainlessDB
from brainlessdb.struct import ConfigWrapper
from tests.conftest import UserV1
from tests.mock_nats import MockNats


@pytest.fixture
def nats():
    return MockNats()


@pytest.fixture
async def db_and_users(nats):
    """Create a DB with UserV1 collection connected to mock NATS."""
    db = BrainlessDB(nats, namespace="test", flush_interval=0)
    users = db.collection(UserV1)
    return db, users


class TestCorruptConfigBucket:
    """Test load() skips corrupt entries in config bucket."""

    @pytest.mark.asyncio
    async def test_corrupt_config_entry_skipped(self, nats, db_and_users, caplog):
        db, users = db_and_users
        await db.start()

        # Add a valid user and flush
        valid = UserV1(id=1, username="alice")
        users.add(valid)
        await db.flush()
        valid_uuid = str(valid.uuid)

        # Stop watch to avoid interference during reload
        await db.unwatch()

        # Inject corrupt data directly into config bucket
        js = nats.jetstream()
        kv = await js.key_value("UserV1")
        await kv.put("corrupt-uuid-1", b"not valid json {{{")

        # Reload collection
        users.clear()
        users._loaded = False

        with caplog.at_level(logging.ERROR, logger="brainlessdb.collection"):
            count = await users.load()

        assert count == 1
        assert users.get(valid_uuid) is not None
        assert users.get("corrupt-uuid-1") is None
        assert "Failed to decode config for 'corrupt-uuid-1'" in caplog.text

        await db.stop()

    @pytest.mark.asyncio
    async def test_all_corrupt_config_loads_zero(self, nats, db_and_users, caplog):
        db, users = db_and_users

        # Inject only corrupt data before start
        js = nats.jetstream()
        kv = await js.create_key_value(type("C", (), {"bucket": "UserV1"})())
        await kv.put("bad-1", b"???")
        await kv.put("bad-2", b"{invalid")

        with caplog.at_level(logging.ERROR, logger="brainlessdb.collection"):
            await db.start()

        assert len(users) == 0
        assert "Failed to decode config" in caplog.text

        await db.stop()

    @pytest.mark.asyncio
    async def test_valid_entries_survive_alongside_corrupt(self, nats, db_and_users, caplog):
        db, users = db_and_users
        await db.start()

        # Flush two valid users
        u1 = UserV1(id=1, username="alice")
        u2 = UserV1(id=2, username="bob")
        users.add(u1)
        users.add(u2)
        await db.flush()

        # Stop watch to avoid interference during reload
        await db.unwatch()

        # Inject corrupt entry
        js = nats.jetstream()
        kv = await js.key_value("UserV1")
        await kv.put("corrupt-1", b"nope")

        # Reload
        users.clear()
        users._loaded = False
        with caplog.at_level(logging.ERROR, logger="brainlessdb.collection"):
            count = await users.load()

        assert count == 2
        assert users.find(username="alice") is not None
        assert users.find(username="bob") is not None

        await db.stop()


class TestCorruptStateBucket:
    """Test load() skips corrupt entries in state bucket."""

    @pytest.mark.asyncio
    async def test_corrupt_state_entry_skipped(self, nats, caplog):
        from typing import Annotated

        from msgspec import Meta

        from brainlessdb import BrainlessDBFeat, BrainlessStruct

        class AgentV1(BrainlessStruct):
            id: int = 0
            status: Annotated[int, Meta(extra={"brainlessdb_flags": BrainlessDBFeat.STATE})] = 0

        db = BrainlessDB(nats, namespace="test", flush_interval=0)
        agents = db.collection(AgentV1)
        await db.start()

        # Add valid agent and flush
        a1 = AgentV1(id=1, status=1)
        agents.add(a1)
        await db.flush()
        a1_uuid = str(a1.uuid)

        # Stop watch to avoid interference
        await db.unwatch()

        # Inject corrupt state data
        js = nats.jetstream()
        kv = await js.key_value("AgentV1-State")
        await kv.put("corrupt-state-uuid", b"not json!!!")

        # Reload
        agents.clear()
        agents._loaded = False
        with caplog.at_level(logging.ERROR, logger="brainlessdb.collection"):
            count = await agents.load()

        assert count == 1
        assert agents.get(a1_uuid) is not None
        assert "Failed to decode key 'corrupt-state-uuid' from bucket 'AgentV1-State'" in caplog.text

        await db.stop()


class TestCorruptLocalBucket:
    """Test load() skips corrupt entries in local bucket."""

    @pytest.mark.asyncio
    async def test_corrupt_local_entry_skipped(self, nats, caplog):
        from typing import Optional

        from msgspec import Struct

        from brainlessdb import BrainlessDB, BrainlessStruct

        class TestLocal(Struct):
            sid: int = 0

        class ItemV1(BrainlessStruct):
            id: int = 0
            _: Optional[TestLocal] = None

        db = BrainlessDB(nats, namespace="test", flush_interval=0)
        items = db.collection(ItemV1)
        await db.start()

        # Add valid item
        i1 = ItemV1(id=1, _=TestLocal(sid=42))
        items.add(i1)
        await db.flush()

        # Stop watch to avoid interference
        await db.unwatch()

        # Inject corrupt local data
        js = nats.jetstream()
        kv = await js.key_value("ItemV1-TestLocal")
        await kv.put("corrupt-local-uuid", b"{{bad}}")

        # Reload
        items.clear()
        items._loaded = False
        with caplog.at_level(logging.ERROR, logger="brainlessdb.collection"):
            count = await items.load()

        assert count == 1
        assert items.get(str(i1.uuid)) is not None
        assert "Failed to decode key 'corrupt-local-uuid' from bucket 'ItemV1-TestLocal'" in caplog.text

        await db.stop()


class TestCorruptEntityAssembly:
    """Test load() skips entities that fail during _from_parts assembly."""

    @pytest.mark.asyncio
    async def test_invalid_config_data_skipped(self, nats, db_and_users, caplog):
        """Config data that decodes as JSON but fails struct conversion."""
        db, users = db_and_users

        js = nats.jetstream()
        kv = await js.create_key_value(type("C", (), {"bucket": "UserV1"})())

        # Valid ConfigWrapper but with data that will fail msgspec.convert
        bad_uuid = str(uuid1())
        bad_wrapper = ConfigWrapper.create({"id": "not-an-int", "username": [1, 2, 3]}, "test")
        await kv.put(bad_uuid, msgspec.json.encode(bad_wrapper))

        # Valid entry with proper UUID and data
        good_uuid = str(uuid1())
        good_wrapper = ConfigWrapper.create({"id": 1, "username": "alice"}, "test")
        await kv.put(good_uuid, msgspec.json.encode(good_wrapper))

        with caplog.at_level(logging.ERROR, logger="brainlessdb.collection"):
            await db.start()

        assert len(users) == 1
        assert users.get(good_uuid) is not None
        assert users.get(bad_uuid) is None
        assert f"Failed to build entity '{bad_uuid}'" in caplog.text

        await db.stop()

    @pytest.mark.asyncio
    async def test_mix_of_all_error_types(self, nats, db_and_users, caplog):
        """Corrupt config JSON, invalid assembly, and valid entries all together."""
        db, users = db_and_users

        js = nats.jetstream()
        kv = await js.create_key_value(type("C", (), {"bucket": "UserV1"})())

        # 1. Corrupt JSON - fails at decode
        await kv.put("corrupt-json", b"not json")

        # 2. Valid JSON, bad schema - fails at entity assembly
        bad_uuid = str(uuid1())
        bad_wrapper = ConfigWrapper.create({"id": [1, 2], "username": {"nested": True}}, "test")
        await kv.put(bad_uuid, msgspec.json.encode(bad_wrapper))

        # 3. Valid entry
        good_uuid = str(uuid1())
        good_wrapper = ConfigWrapper.create({"id": 42, "username": "valid"}, "test")
        await kv.put(good_uuid, msgspec.json.encode(good_wrapper))

        with caplog.at_level(logging.ERROR, logger="brainlessdb.collection"):
            await db.start()

        assert len(users) == 1
        assert users.get(good_uuid) is not None
        assert users.get(good_uuid).username == "valid"
        assert "Failed to decode config for 'corrupt-json'" in caplog.text
        assert f"Failed to build entity '{bad_uuid}'" in caplog.text

        await db.stop()
