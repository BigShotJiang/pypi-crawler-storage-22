"""Test thread safety - add/delete from worker threads."""

import asyncio
import threading

import pytest

from brainlessdb import BrainlessDB

from .conftest import UserV1


class TestThreadSafety:
    """Thread safety when operations cross thread boundaries."""

    @pytest.mark.asyncio
    async def test_add_from_worker_thread_schedules_flush(self):
        """Adding from a worker thread must trigger auto-flush."""
        db = BrainlessDB(namespace="test", flush_interval=0.05)
        users = db.collection(UserV1)
        await db.start()

        done = threading.Event()

        def worker():
            users.add(UserV1(id=1, username="alice"))
            done.set()

        t = threading.Thread(target=worker)
        t.start()
        done.wait(timeout=2)

        # Wait for auto-flush (interval=0.05 + margin)
        await asyncio.sleep(0.2)

        assert len(users) == 1
        assert len(users._dirty) == 0, "Flush was never scheduled from worker thread"

    @pytest.mark.asyncio
    async def test_delete_from_worker_thread_schedules_flush(self):
        """Deleting from a worker thread must trigger auto-flush."""
        db = BrainlessDB(namespace="test", flush_interval=0.05)
        users = db.collection(UserV1)
        await db.start()

        users.add(UserV1(id=1, username="alice"))
        await db.flush()
        uid = list(users._entities.keys())[0]

        # Cancel any leftover flush task from add()
        if db._flush_task:
            db._flush_task.cancel()
            try:
                await db._flush_task
            except asyncio.CancelledError:
                pass
            db._flush_task = None

        done = threading.Event()

        def worker():
            users.delete(uid)
            done.set()

        t = threading.Thread(target=worker)
        t.start()
        done.wait(timeout=2)

        await asyncio.sleep(0.2)

        assert len(users) == 0
        assert len(users._deleted) == 0, "Flush was never scheduled from worker thread"

    @pytest.mark.asyncio
    async def test_schedule_flush_from_worker_thread(self):
        """schedule_flush called from worker thread must schedule on event loop."""
        db = BrainlessDB(namespace="test", flush_interval=0.05)
        users = db.collection(UserV1)
        await db.start()

        # Add directly on event loop thread
        users.add(UserV1(id=1, username="alice"))
        assert len(users._dirty) == 1

        # Cancel any auto-scheduled flush
        if db._flush_task:
            db._flush_task.cancel()
            try:
                await db._flush_task
            except asyncio.CancelledError:
                pass
            db._flush_task = None

        # Now trigger flush from worker thread
        done = threading.Event()

        def worker():
            db.schedule_flush()
            done.set()

        t = threading.Thread(target=worker)
        t.start()
        done.wait(timeout=2)

        await asyncio.sleep(0.2)

        assert len(users._dirty) == 0, "schedule_flush from worker thread did nothing"
