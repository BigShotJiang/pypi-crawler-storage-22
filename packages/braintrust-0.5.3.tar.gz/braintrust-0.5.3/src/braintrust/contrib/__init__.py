"""Braintrust contrib integrations.

This module contains officially supported integrations with third-party frameworks.
These integrations are optional and require additional dependencies.
"""
