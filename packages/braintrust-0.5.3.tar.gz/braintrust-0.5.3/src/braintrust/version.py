VERSION = "0.5.3"

# this will be templated during the build
GIT_COMMIT = "ce261c13723e8985e61819f6df56298f863155d0"
