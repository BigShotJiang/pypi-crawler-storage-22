from pathlib import Path
import struct
import numpy as np

from .recording import Recording
from .RecordingMetadata import RecordingMetadata
from .errors import BreesyError
from .log import logger
from .type_hints import enforce_type_hints


@enforce_type_hints
def load_edf(filename: str) -> Recording:
    """Load an EDF (European Data Format) file.

    :param filename: Path to the EDF file

    :return: Recording object containing the loaded data
    """
    with open(filename, 'rb') as f:
        # Read fixed header (256 bytes)
        header = {}
        header['version'] = f.read(8).decode('ascii').strip()
        header['patient_id'] = f.read(80).decode('ascii').strip()
        header['recording_id'] = f.read(80).decode('ascii').strip()
        header['start_date'] = f.read(8).decode('ascii').strip()
        header['start_time'] = f.read(8).decode('ascii').strip()
        header['header_bytes'] = int(f.read(8).decode('ascii').strip())
        header['reserved'] = f.read(44).decode('ascii').strip()
        header['num_records'] = int(f.read(8).decode('ascii').strip())
        header['record_duration'] = float(f.read(8).decode('ascii').strip())
        header['num_signals'] = int(f.read(4).decode('ascii').strip())

        num_signals = header['num_signals']

        # Read signal headers (256 bytes per signal)
        signal_headers = {}
        signal_headers['label'] = [f.read(16).decode('ascii').strip() for _ in range(num_signals)]

        signal_headers['transducer'] = [f.read(80).decode('ascii').strip() for _ in range(num_signals)]
        signal_headers['physical_dim'] = [f.read(8).decode('ascii').strip() for _ in range(num_signals)]
        signal_headers['physical_min'] = [float(f.read(8).decode('ascii').strip()) for _ in range(num_signals)]
        signal_headers['physical_max'] = [float(f.read(8).decode('ascii').strip()) for _ in range(num_signals)]
        signal_headers['digital_min'] = [int(f.read(8).decode('ascii').strip()) for _ in range(num_signals)]
        signal_headers['digital_max'] = [int(f.read(8).decode('ascii').strip()) for _ in range(num_signals)]
        signal_headers['prefilter'] = [f.read(80).decode('ascii').strip() for _ in range(num_signals)]
        signal_headers['samples_per_record'] = [int(f.read(8).decode('ascii').strip()) for _ in range(num_signals)]
        signal_headers['reserved'] = [f.read(32) for _ in range(num_signals)]

        # Calculate scaling factors for each signal
        scaling_factors = []
        offsets = []
        for i in range(num_signals):
            digital_range = signal_headers['digital_max'][i] - signal_headers['digital_min'][i]
            physical_range = signal_headers['physical_max'][i] - signal_headers['physical_min'][i]
            if digital_range != 0:
                scaling_factors.append(physical_range / digital_range)
                offsets.append(signal_headers['physical_min'][i] - signal_headers['digital_min'][i] * scaling_factors[i])
            else:
                scaling_factors.append(1.0)
                offsets.append(0.0)

        # Read data records
        num_records = header['num_records']
        samples_per_record = signal_headers['samples_per_record']

        # Calculate total samples for each signal
        total_samples = [samples_per_record[i] * num_records for i in range(num_signals)]

        # Initialize data arrays for each signal
        data = [np.zeros(total_samples[i]) for i in range(num_signals)]

        # Read all data records
        for record_idx in range(num_records):
            for signal_idx in range(num_signals):
                n_samples = samples_per_record[signal_idx]
                # Read 16-bit signed integers
                raw_samples = struct.unpack(f'<{n_samples}h', f.read(n_samples * 2))
                # Convert to physical values
                start_idx = record_idx * n_samples
                end_idx = start_idx + n_samples
                data[signal_idx][start_idx:end_idx] = [
                    raw_samples[i] * scaling_factors[signal_idx] + offsets[signal_idx]
                    for i in range(n_samples)
                ]

    # Filter out annotation channels (EDF+ format)
    channel_names = signal_headers['label']
    eeg_indices = [i for i, label in enumerate(channel_names) if 'EDF Annotations' not in label]
    if len(eeg_indices) < len(channel_names):
        logger.warning(f"Found {len(channel_names) - len(eeg_indices)} annotation channel(s) which will be ignored. Breesy plans to support them in future.")
        data = [data[i] for i in eeg_indices]
        channel_names = [channel_names[i] for i in eeg_indices]
        # TODO: create events from annotations

    # Determine sample rate for each signal
    sample_rates = [samples_per_record[i] / header['record_duration'] for i in eeg_indices]
    if len(set(sample_rates)) == 1:
        sample_rate = float(sample_rates[0])
    else:
        raise BreesyError("Data contains variable sample rate. Currently, Breesy does not support such files, sorry :(")


    # Create metadata
    metadata = RecordingMetadata(
        name=Path(filename).stem,
        file_path=Path(filename),
        description=f"EDF data loaded from {filename}"
    )

    return Recording(
        data=np.array(data),
        channel_names=channel_names,
        sample_rate=sample_rate,
        metadata=metadata
    )