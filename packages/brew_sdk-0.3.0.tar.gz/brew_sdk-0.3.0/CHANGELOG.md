# Changelog

## 0.3.0 (2026-02-03)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/GetBrew/brew-python-sdk/compare/v0.2.0...v0.3.0)

### Features

* **client:** add custom JSON encoder for extended type support ([11ad7ae](https://github.com/GetBrew/brew-python-sdk/commit/11ad7ae652f437bbeb408b9cae951e5ae4281699))

## 0.2.0 (2026-01-28)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/GetBrew/brew-python-sdk/compare/v0.1.0...v0.2.0)

### Features

* **api:** api update ([ec4e068](https://github.com/GetBrew/brew-python-sdk/commit/ec4e0682f928323d3a3d222336dbbaa0c217ce97))


### Chores

* **ci:** upgrade `actions/github-script` ([e69e877](https://github.com/GetBrew/brew-python-sdk/commit/e69e877a6d7977563a6df9d5b80c5a9ebb83c87b))

## 0.1.0 (2026-01-21)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/GetBrew/brew-python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([2260b6b](https://github.com/GetBrew/brew-python-sdk/commit/2260b6b69b8afb6445b8b3deffa2a518e04e359e))


### Chores

* configure new SDK language ([375c6d1](https://github.com/GetBrew/brew-python-sdk/commit/375c6d1a3a37f397ff38cd7900c29b4a0dbb1352))
* update SDK settings ([2ecb007](https://github.com/GetBrew/brew-python-sdk/commit/2ecb007217d2269988b273e31f2a9bbd7e107014))
* update SDK settings ([f9a8a95](https://github.com/GetBrew/brew-python-sdk/commit/f9a8a953fee090d15e2fbd5780e07f4caa8fd08e))
