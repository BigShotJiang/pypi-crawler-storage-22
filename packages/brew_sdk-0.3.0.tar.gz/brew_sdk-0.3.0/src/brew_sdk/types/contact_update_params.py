# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["ContactUpdateParams"]


class ContactUpdateParams(TypedDict, total=False):
    email: Required[str]
    """Email address of contact to update (lookup key)"""

    custom_fields: Annotated[Dict[str, object], PropertyInfo(alias="customFields")]
    """Custom fields to merge (not replace)"""

    first_name: Annotated[str, PropertyInfo(alias="firstName")]

    last_name: Annotated[str, PropertyInfo(alias="lastName")]

    subscribed: bool
