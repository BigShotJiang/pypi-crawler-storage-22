# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["ImportGetStatusParams"]


class ImportGetStatusParams(TypedDict, total=False):
    import_id: Annotated[str, PropertyInfo(alias="importId")]
    """Import job ID (omit to list recent imports)"""
