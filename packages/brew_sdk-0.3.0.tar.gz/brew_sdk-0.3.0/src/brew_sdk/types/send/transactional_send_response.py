# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["TransactionalSendResponse", "Data", "DataResult", "Meta"]


class DataResult(BaseModel):
    id: Optional[str] = None
    """Email ID (if successful)"""

    email: Optional[str] = None

    error: Optional[str] = None
    """Error message (if failed)"""


class Data(BaseModel):
    failed: Optional[int] = None
    """Number of emails that failed"""

    results: Optional[List[DataResult]] = None

    sent: Optional[int] = None
    """Number of emails sent successfully"""


class Meta(BaseModel):
    request_id: Optional[str] = FieldInfo(alias="requestId", default=None)


class TransactionalSendResponse(BaseModel):
    data: Data

    success: Literal[True]

    meta: Optional[Meta] = None
