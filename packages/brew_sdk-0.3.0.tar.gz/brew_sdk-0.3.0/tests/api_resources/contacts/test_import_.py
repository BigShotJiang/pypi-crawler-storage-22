# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from brew_sdk import BrewSDK, AsyncBrewSDK
from tests.utils import assert_matches_type
from brew_sdk.types.contacts import (
    ImportCreateResponse,
    ImportGetStatusResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestImport:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: BrewSDK) -> None:
        import_ = client.contacts.import_.create(
            contacts=[{"email": "john@example.com"}, {"email": "jane@example.com"}],
        )
        assert_matches_type(ImportCreateResponse, import_, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: BrewSDK) -> None:
        response = client.contacts.import_.with_raw_response.create(
            contacts=[{"email": "john@example.com"}, {"email": "jane@example.com"}],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        import_ = response.parse()
        assert_matches_type(ImportCreateResponse, import_, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: BrewSDK) -> None:
        with client.contacts.import_.with_streaming_response.create(
            contacts=[{"email": "john@example.com"}, {"email": "jane@example.com"}],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            import_ = response.parse()
            assert_matches_type(ImportCreateResponse, import_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_status(self, client: BrewSDK) -> None:
        import_ = client.contacts.import_.get_status()
        assert_matches_type(ImportGetStatusResponse, import_, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_status_with_all_params(self, client: BrewSDK) -> None:
        import_ = client.contacts.import_.get_status(
            import_id="importId",
        )
        assert_matches_type(ImportGetStatusResponse, import_, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_status(self, client: BrewSDK) -> None:
        response = client.contacts.import_.with_raw_response.get_status()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        import_ = response.parse()
        assert_matches_type(ImportGetStatusResponse, import_, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_status(self, client: BrewSDK) -> None:
        with client.contacts.import_.with_streaming_response.get_status() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            import_ = response.parse()
            assert_matches_type(ImportGetStatusResponse, import_, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncImport:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncBrewSDK) -> None:
        import_ = await async_client.contacts.import_.create(
            contacts=[{"email": "john@example.com"}, {"email": "jane@example.com"}],
        )
        assert_matches_type(ImportCreateResponse, import_, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncBrewSDK) -> None:
        response = await async_client.contacts.import_.with_raw_response.create(
            contacts=[{"email": "john@example.com"}, {"email": "jane@example.com"}],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        import_ = await response.parse()
        assert_matches_type(ImportCreateResponse, import_, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncBrewSDK) -> None:
        async with async_client.contacts.import_.with_streaming_response.create(
            contacts=[{"email": "john@example.com"}, {"email": "jane@example.com"}],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            import_ = await response.parse()
            assert_matches_type(ImportCreateResponse, import_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_status(self, async_client: AsyncBrewSDK) -> None:
        import_ = await async_client.contacts.import_.get_status()
        assert_matches_type(ImportGetStatusResponse, import_, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_status_with_all_params(self, async_client: AsyncBrewSDK) -> None:
        import_ = await async_client.contacts.import_.get_status(
            import_id="importId",
        )
        assert_matches_type(ImportGetStatusResponse, import_, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_status(self, async_client: AsyncBrewSDK) -> None:
        response = await async_client.contacts.import_.with_raw_response.get_status()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        import_ = await response.parse()
        assert_matches_type(ImportGetStatusResponse, import_, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_status(self, async_client: AsyncBrewSDK) -> None:
        async with async_client.contacts.import_.with_streaming_response.get_status() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            import_ = await response.parse()
            assert_matches_type(ImportGetStatusResponse, import_, path=["response"])

        assert cast(Any, response.is_closed) is True
