# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from brew_sdk import BrewSDK, AsyncBrewSDK
from tests.utils import assert_matches_type
from brew_sdk.types.send import TransactionalSendResponse, TransactionalDocumentationResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestTransactional:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_documentation(self, client: BrewSDK) -> None:
        transactional = client.send.transactional.documentation()
        assert_matches_type(TransactionalDocumentationResponse, transactional, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_documentation(self, client: BrewSDK) -> None:
        response = client.send.transactional.with_raw_response.documentation()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transactional = response.parse()
        assert_matches_type(TransactionalDocumentationResponse, transactional, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_documentation(self, client: BrewSDK) -> None:
        with client.send.transactional.with_streaming_response.documentation() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transactional = response.parse()
            assert_matches_type(TransactionalDocumentationResponse, transactional, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_send(self, client: BrewSDK) -> None:
        transactional = client.send.transactional.send(
            chat_id="abc123",
            to="user@example.com",
        )
        assert_matches_type(TransactionalSendResponse, transactional, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_send_with_all_params(self, client: BrewSDK) -> None:
        transactional = client.send.transactional.send(
            chat_id="abc123",
            to="user@example.com",
            from_="dev@stainless.com",
            reply_to="dev@stainless.com",
            subject="subject",
            variables={
                "firstName": "bar",
                "orderNumber": "bar",
                "trackingUrl": "bar",
            },
        )
        assert_matches_type(TransactionalSendResponse, transactional, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_send(self, client: BrewSDK) -> None:
        response = client.send.transactional.with_raw_response.send(
            chat_id="abc123",
            to="user@example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transactional = response.parse()
        assert_matches_type(TransactionalSendResponse, transactional, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_send(self, client: BrewSDK) -> None:
        with client.send.transactional.with_streaming_response.send(
            chat_id="abc123",
            to="user@example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transactional = response.parse()
            assert_matches_type(TransactionalSendResponse, transactional, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncTransactional:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_documentation(self, async_client: AsyncBrewSDK) -> None:
        transactional = await async_client.send.transactional.documentation()
        assert_matches_type(TransactionalDocumentationResponse, transactional, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_documentation(self, async_client: AsyncBrewSDK) -> None:
        response = await async_client.send.transactional.with_raw_response.documentation()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transactional = await response.parse()
        assert_matches_type(TransactionalDocumentationResponse, transactional, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_documentation(self, async_client: AsyncBrewSDK) -> None:
        async with async_client.send.transactional.with_streaming_response.documentation() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transactional = await response.parse()
            assert_matches_type(TransactionalDocumentationResponse, transactional, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_send(self, async_client: AsyncBrewSDK) -> None:
        transactional = await async_client.send.transactional.send(
            chat_id="abc123",
            to="user@example.com",
        )
        assert_matches_type(TransactionalSendResponse, transactional, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_send_with_all_params(self, async_client: AsyncBrewSDK) -> None:
        transactional = await async_client.send.transactional.send(
            chat_id="abc123",
            to="user@example.com",
            from_="dev@stainless.com",
            reply_to="dev@stainless.com",
            subject="subject",
            variables={
                "firstName": "bar",
                "orderNumber": "bar",
                "trackingUrl": "bar",
            },
        )
        assert_matches_type(TransactionalSendResponse, transactional, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_send(self, async_client: AsyncBrewSDK) -> None:
        response = await async_client.send.transactional.with_raw_response.send(
            chat_id="abc123",
            to="user@example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transactional = await response.parse()
        assert_matches_type(TransactionalSendResponse, transactional, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_send(self, async_client: AsyncBrewSDK) -> None:
        async with async_client.send.transactional.with_streaming_response.send(
            chat_id="abc123",
            to="user@example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transactional = await response.parse()
            assert_matches_type(TransactionalSendResponse, transactional, path=["response"])

        assert cast(Any, response.is_closed) is True
