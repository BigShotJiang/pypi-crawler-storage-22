# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from brew_sdk import BrewSDK, AsyncBrewSDK
from tests.utils import assert_matches_type
from brew_sdk.types import ContactDeleteResponse, ContactUpdateResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestContacts:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update(self, client: BrewSDK) -> None:
        contact = client.contacts.update(
            email="john@example.com",
        )
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: BrewSDK) -> None:
        contact = client.contacts.update(
            email="john@example.com",
            custom_fields={
                "company": "bar",
                "department": "bar",
            },
            first_name="Johnny",
            last_name="lastName",
            subscribed=True,
        )
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: BrewSDK) -> None:
        response = client.contacts.with_raw_response.update(
            email="john@example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = response.parse()
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: BrewSDK) -> None:
        with client.contacts.with_streaming_response.update(
            email="john@example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = response.parse()
            assert_matches_type(ContactUpdateResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_delete(self, client: BrewSDK) -> None:
        contact = client.contacts.delete(
            email="john@example.com",
        )
        assert_matches_type(ContactDeleteResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_delete_with_all_params(self, client: BrewSDK) -> None:
        contact = client.contacts.delete(
            email="john@example.com",
            delete_fields=["string"],
        )
        assert_matches_type(ContactDeleteResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: BrewSDK) -> None:
        response = client.contacts.with_raw_response.delete(
            email="john@example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = response.parse()
        assert_matches_type(ContactDeleteResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: BrewSDK) -> None:
        with client.contacts.with_streaming_response.delete(
            email="john@example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = response.parse()
            assert_matches_type(ContactDeleteResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncContacts:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncBrewSDK) -> None:
        contact = await async_client.contacts.update(
            email="john@example.com",
        )
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncBrewSDK) -> None:
        contact = await async_client.contacts.update(
            email="john@example.com",
            custom_fields={
                "company": "bar",
                "department": "bar",
            },
            first_name="Johnny",
            last_name="lastName",
            subscribed=True,
        )
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncBrewSDK) -> None:
        response = await async_client.contacts.with_raw_response.update(
            email="john@example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = await response.parse()
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncBrewSDK) -> None:
        async with async_client.contacts.with_streaming_response.update(
            email="john@example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = await response.parse()
            assert_matches_type(ContactUpdateResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncBrewSDK) -> None:
        contact = await async_client.contacts.delete(
            email="john@example.com",
        )
        assert_matches_type(ContactDeleteResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_delete_with_all_params(self, async_client: AsyncBrewSDK) -> None:
        contact = await async_client.contacts.delete(
            email="john@example.com",
            delete_fields=["string"],
        )
        assert_matches_type(ContactDeleteResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncBrewSDK) -> None:
        response = await async_client.contacts.with_raw_response.delete(
            email="john@example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = await response.parse()
        assert_matches_type(ContactDeleteResponse, contact, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncBrewSDK) -> None:
        async with async_client.contacts.with_streaming_response.delete(
            email="john@example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = await response.parse()
            assert_matches_type(ContactDeleteResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True
