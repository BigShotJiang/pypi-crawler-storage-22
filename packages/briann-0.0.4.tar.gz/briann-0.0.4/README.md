# BrIANN
This is a package for developing brain inspired artificial neural networks. 

Bla bla blub
