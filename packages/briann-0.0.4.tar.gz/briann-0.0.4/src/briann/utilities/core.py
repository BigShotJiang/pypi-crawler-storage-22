 
class Adapter():
    pass
