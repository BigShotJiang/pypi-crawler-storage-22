import os
import re
from email.utils import parseaddr

def _get_env(name: str) -> str:
    """
    Mengambil environment variable yang wajib tersedia.

    Fungsi ini digunakan sebagai helper internal untuk memastikan
    bahwa suatu environment variable telah diset sebelum digunakan.

    Args:
        name (str):
            Nama environment variable.

    Returns:
        str:
            Nilai dari environment variable tersebut.

    Raises:
        RuntimeError:
            Jika environment variable tidak ditemukan atau kosong.
    """
    value = os.getenv(name)

    if not value:
        raise RuntimeError(
            f"{name} environment variable is not set."
        )

    return value
  
def get_userid():
    """
    Mengambil Hadoop user ID dari environment variable.

    Returns:
        str:
            User ID Hadoop yang tersimpan pada
            environment variable `HADOOP_USER_NAME`.

    Example:
        >>> get_userid()
        'bribrain_sac'
    """
    return _get_env("HADOOP_USER_NAME")


def get_username() -> str:
    """
    Menghasilkan nama lengkap berdasarkan Git author email.

    Nama akan dibentuk dari bagian local email
    (sebelum '@') dengan memisahkan kata menggunakan
    delimiter umum seperti titik (.), underscore (_),
    atau tanda minus (-).

    Returns:
        str:
            Nama lengkap dalam format kapital di setiap kata.

    Raises:
        RuntimeError:
            Jika `GIT_AUTHOR_EMAIL` tidak valid atau tidak tersedia.

    Example:
        >>> get_username()
        'Andri Ariyanto'
    """
    email = _get_env("GIT_AUTHOR_EMAIL")

    _, addr = parseaddr(email)

    if not addr or "@" not in addr:
        raise RuntimeError(
            "GIT_AUTHOR_EMAIL is invalid. Expected a valid email format."
        )

    local_part = addr.split("@", 1)[0]

    # Split on common separators: . _ -
    words = re.split(r"[._-]+", local_part)

    return " ".join(word.capitalize() for word in words if word)

def get_email():
    """
    Mengambil Git author email dari environment variable.

    Returns:
        str:
            Email yang tersimpan pada
            environment variable `GIT_AUTHOR_EMAIL`.

    Example:
        >>> get_email()
        'user@example.com'
    """
    return _get_env("GIT_AUTHOR_EMAIL")


def get_project_url():
    """
    Mengambil URL project dari environment variable.

    Returns:
        str:
            URL project yang tersimpan pada
            environment variable `CDSW_PROJECT_URL`.
    """
    return _get_env("CDSW_PROJECT_URL")


def get_project_id():
    """
    Mengambil ID project dari environment variable.

    Returns:
        str:
            ID project yang tersimpan pada
            environment variable `CDSW_PROJECT_ID`.
    """
    return _get_env("CDSW_PROJECT_ID")


def get_project_num():
    """
    Mengambil nomor project dari environment variable.

    Returns:
        str:
            Nomor project yang tersimpan pada
            environment variable `CDSW_PROJECT_NUM`.
    """
    return _get_env("CDSW_PROJECT_NUM")


def get_project_name(env="dev", case=None, delimiter="_"):
    """
    Membentuk nama project dengan format yang dapat disesuaikan.

    Nama project diambil dari environment variable `CDSW_PROJECT`,
    kemudian dapat dimodifikasi berdasarkan environment deployment,
    format huruf, dan delimiter.

    Args:
        env (str, optional):
            Environment deployment.

            Pilihan:
            - "dev"  : menambahkan prefix `dev`
            - "prod" : tanpa prefix

            Default: "dev"

        case (str | None, optional):
            Mengatur format huruf pada hasil akhir.

            Pilihan:
            - None   : mempertahankan format asli
            - "lower": mengubah seluruh teks menjadi huruf kecil
            - "upper": mengubah seluruh teks menjadi huruf besar

            Default: None

        delimiter (str | None, optional):
            Karakter pemisah untuk menggantikan tanda minus ("-").

            - Jika string diberikan → semua "-" diganti.
            - Jika None → delimiter asli dipertahankan.

            Default: "_"

    Returns:
        str:
            Nama project yang telah diformat.

    Raises:
        ValueError:
            Jika parameter `env` atau `case` tidak valid.

    Example:
        >>> get_project_name()
        'dev_bribrain_pipeline'

        >>> get_project_name(env="prod", case="upper")
        'BRIBRAIN_PIPELINE'

        >>> get_project_name(delimiter=None)
        'dev-bribrain-pipeline'
    """
    if env not in {"dev", "prod"}:
        raise ValueError("env must be 'dev' or 'prod'")

    if case not in {None, "lower", "upper"}:
        raise ValueError("case must be None, 'lower', or 'upper'")

    # extract project name
    project = os.environ["CDSW_PROJECT"]

    # Change delimiter ONLY if provided
    if delimiter is not None:
        project = project.replace("-", delimiter)
        join_delimiter = delimiter
    else:
        join_delimiter = "-"  # use original delimiter

    # Add prefix BEFORE case transformation
    if env == "dev":
        project = f"dev{join_delimiter}{project}"

    # Apply case to entire string
    if case == "lower":
        project = project.lower()
    elif case == "upper":
        project = project.upper()

    return project
  

def get_proxy() -> dict:
    """
    Mengambil konfigurasi proxy HTTP dan HTTPS
    dari environment variable.

    Returns:
        dict:
            Dictionary berisi konfigurasi proxy yang tersedia.

            Jika tidak ada proxy yang diset,
            fungsi akan mengembalikan dictionary kosong.

    Example:
        >>> get_proxy()
        {
            "http": "http://proxy.company.com:8080",
            "https": "https://proxy.company.com:8080"
        }
    """
    proxies = {}

    http_proxy = _get_env("http_proxy")
    https_proxy = _get_env("https_proxy")

    if http_proxy:
        proxies["http"] = http_proxy

    if https_proxy:
        proxies["https"] = https_proxy

    return proxies









