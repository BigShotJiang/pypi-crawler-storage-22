# https://fonts.google.com/icons

PRIORITY_ICON = "\uf16a"  # fire

DUE_DATE_ICON = "\uf540"  # calendar with clock

FLAG_ICON = "\ue153"  # flag
