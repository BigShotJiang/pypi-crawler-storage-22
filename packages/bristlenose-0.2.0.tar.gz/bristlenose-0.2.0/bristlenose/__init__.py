"""Bristlenose: User-research transcription and quote extraction engine."""

__version__ = "0.2.0"
