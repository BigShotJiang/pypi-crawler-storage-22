"""Allow running as python -m bristlenose."""

from bristlenose.cli import app

app()
