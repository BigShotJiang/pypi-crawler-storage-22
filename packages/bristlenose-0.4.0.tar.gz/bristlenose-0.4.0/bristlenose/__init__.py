"""Bristlenose: User-research transcription and quote extraction engine."""

__version__ = "0.4.0"
