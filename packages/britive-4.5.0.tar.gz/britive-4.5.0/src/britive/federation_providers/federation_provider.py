class FederationProvider:
    def __init__(self) -> None:
        pass

    def get_token(self) -> None:
        raise NotImplementedError
