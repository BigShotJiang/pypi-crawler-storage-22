# Release v0.5.6

Date: 2026-01-29
Changes since 0.5.5

- chore: prepare release v0.5.6 (3a23f42)
- docs: update contributors (b36012b)
- ci: replace the locaiton of gh command to get pr number (e522e6b)
- fix: cast NIfTI dataobj shape (f0bae05)
- fix: make type aliases explicit (ad1d065)
- ci: add actions:write permission to trigger other workflow. (2a4a71d)
- ci: fix Zenodo badge update retry logic (ff66a7d)
- Update Zenodo DOI badge (a6d453e)
- ci(release): allow OIDC by granting id-token permission (db29a36)
