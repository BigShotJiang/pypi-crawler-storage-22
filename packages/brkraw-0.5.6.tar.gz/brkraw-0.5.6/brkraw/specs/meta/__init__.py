from __future__ import annotations

from .validator import validate_meta

__all__ = ["validate_meta"]
