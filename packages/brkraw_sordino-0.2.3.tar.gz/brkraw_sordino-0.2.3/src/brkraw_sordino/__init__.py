"""BrkRaw SORDINO-ZTE converter hook package."""

from .hook import get_dataobj

__all__ = ["__version__", "get_dataobj"]

__version__ = "0.2.0"
