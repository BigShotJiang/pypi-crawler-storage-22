from typing import Callable

Command = Callable[[], None]