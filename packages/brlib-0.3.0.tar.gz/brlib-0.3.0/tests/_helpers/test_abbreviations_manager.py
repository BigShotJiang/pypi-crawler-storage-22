"""Tests the methods of the `AbbreviationsManager` singleton."""

# noinspection PyProtectedMember
from brlib._helpers.abbreviations_manager import abv_man


def test_cache() -> None:
    """Tests that the contents are the same when loaded from cache and the web."""
    # on the CI runner, the DataFrame has already been loaded from the web and cached
    # locally, you'll have to delete the cache file to replicate this behavior
    expected_df = abv_man.df.copy()
    assert abv_man._has_valid_cache
    abv_man._load()
    compared = abv_man.df.compare(expected_df)
    assert compared.empty


def test_correct_abvs() -> None:
    """Tests the outputs of the `correct_abvs` method."""
    assert abv_man.correct_abvs("OAK", 2025, era_adjustment=True) == ["ATH"]
    assert abv_man.correct_abvs("OAK", 2025, era_adjustment=False) == []
    assert abv_man.correct_abvs("BAL", 1915, era_adjustment=True) == ["SLB", "BAL"]
    assert abv_man.correct_abvs("BAL", 1915, era_adjustment=False) == ["BAL"]
    assert abv_man.correct_abvs("LAA", 1977, era_adjustment=False) == ["CAL"]
    assert abv_man.correct_abvs("LAA", 1907, era_adjustment=False) == []
    assert abv_man.correct_abvs("SER", 2025, era_adjustment=False) == []
    assert abv_man.correct_abvs("PC", 1939, era_adjustment=True) == ["TC", "TC2"]
    assert abv_man.correct_abvs("TC", 1939, era_adjustment=True) == ["TC", "TC2"]
    assert abv_man.correct_abvs("TC2", 1939, era_adjustment=True) == ["TC", "TC2"]
    assert abv_man.correct_abvs("TC", 1939, era_adjustment=False) == ["TC"]
    assert abv_man.correct_abvs("TC2", 1939, era_adjustment=False) == ["TC2"]


def test_franchise_abv() -> None:
    """Tests the outputs of the `franchise_abv` method."""
    assert abv_man.franchise_abv("ATH", 1876) == "ATH"
    assert abv_man.franchise_abv("BAL", 1915) == "BLT"
    assert abv_man.franchise_abv("OAK", 2025) == ""
    assert abv_man.franchise_abv("SER", 2025) == ""


def test_all_team_abvs() -> None:
    """Tests the outputs of the `all_team_abvs` method."""
    assert abv_man.all_team_abvs("ATH", 2025) == ["ATH", "KCA", "OAK", "PHA"]
    assert abv_man.all_team_abvs("OAK", 2025) == []
    assert abv_man.all_team_abvs("SER", 2025) == []


def test_to_alias() -> None:
    """Tests the outputs of the `to_alias` method."""
    assert abv_man.to_alias("SEA", 2025) == "SEA"
    assert abv_man.to_alias("KCA", 1963) == "KC1"
    assert abv_man.to_alias("PBS", 2025) == "PBS"
    assert abv_man.to_alias("SER", 2025) == "SER"


def test_to_regular() -> None:
    """Tests the outputs of the `to_regular` method."""
    assert abv_man.to_regular("SEA", 2025) == "SEA"
    assert abv_man.to_regular("KCA", 1999) == "KCR"
    assert abv_man.to_regular("KC1", 2025) == "KC1"
    assert abv_man.to_regular("SER", 2025) == "SER"
