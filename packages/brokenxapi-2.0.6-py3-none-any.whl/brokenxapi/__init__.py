from .client import BrokenXAPI
import logging


__all__ = ["BrokenXAPI"]



logger = logging.getLogger("BrokenXAPI")

logger.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
logger.info("🚀 BROKENXAPI INITIALIZED")
logger.info("⚡ Powered by Broken X Network")
logger.info("🔐 Join Telegram: @AboutBrokenX • @BrokenXNetwork1 For Future Updates")
logger.info("Thanks ❤‍🩹 For Using BrokenxAPI") 
logger.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
