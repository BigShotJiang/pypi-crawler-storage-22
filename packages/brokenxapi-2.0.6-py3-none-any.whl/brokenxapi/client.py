import aiohttp
from typing import Optional


class BrokenXAPI:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://mrbroken-brokenxbots.hf.space",
        timeout: int = 30,
    ):
        if not api_key or not isinstance(api_key, str):
            raise ValueError("api_key must be a non-empty string")

        self.api_key = api_key.strip()
        self.base_url = base_url.rstrip("/")
        self._session: Optional[aiohttp.ClientSession] = None
        self._timeout = aiohttp.ClientTimeout(total=timeout)

    async def __aenter__(self):
        self._session = aiohttp.ClientSession(
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=self._timeout,
        )
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if self._session:
            await self._session.close()
            self._session = None

    def _require_session(self):
        if not self._session:
            raise RuntimeError("BrokenXAPI session not initialized. Use: async with BrokenXAPI(...) as api:")

    async def _get(self, path: str, params: dict | None = None):
        self._require_session()
        url = f"{self.base_url}{path}"

        # yarl/aiohttp: only str/int/float allowed in params
        if params:
            clean = {}
            for k, v in params.items():
                if v is None:
                    continue
                if isinstance(v, bool):
                    v = "true" if v else "false"   # <-- FIX
                    # alternatively: v = int(v)
                clean[k] = v
            params = clean

        async with self._session.get(url, params=params) as r:
            r.raise_for_status()
            return await r.json()

    # -------- PUBLIC METHODS --------

    async def search(self, query: str, video: bool = False, limit: int = 20):
        return await self._get(
            "/search",
            {
                "q": str(query),
                "video": video,     # bool is OK now; _get converts it
                "limit": int(limit),
            },
        )

    async def download(self, video_id: str, media: str = "audio"):
        if media not in ("audio", "video"):
            raise ValueError("media must be 'audio' or 'video'")

        return await self._get(
            f"/download/{media}",
            {"video_id": str(video_id)},
        )
