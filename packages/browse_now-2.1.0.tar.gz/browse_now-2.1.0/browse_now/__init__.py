"""
Browse Now

Browser automation CLI for Nowledge Mem AI-Now agent.
Provides browser control via the Nowledge Mem extension.
"""

from .client import BrowserClient, BrowserClientSync
from .types import (
    BridgeCommand,
    BridgeResponse,
    ClickResult,
    FillResult,
    NavigateResult,
    TabInfo,
    TabsListResult,
)

__version__ = "2.0.71"
__all__ = [
    "BrowserClient",
    "BrowserClientSync",
    "BridgeCommand",
    "BridgeResponse",
    "ClickResult",
    "FillResult",
    "NavigateResult",
    "TabInfo",
    "TabsListResult",
]
