#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import itertools
import json
import os
import re
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Deque, Dict, List, Optional

# Keep Chromium stable in CI/dev machines where /dev/shm can be small.
os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-dev-shm-usage")

try:
    from mcp.server.fastmcp import FastMCP
except ImportError as exc:  # pragma: no cover - handled at runtime
    raise SystemExit(
        "Missing dependency 'mcp'. Install with: python3 -m pip install -r requirements.txt"
    ) from exc

try:
    from PyQt5.QtCore import QEventLoop, QObject, QTimer, QUrl, pyqtSignal
    from PyQt5.QtWebEngineWidgets import QWebEngineDownloadItem, QWebEnginePage, QWebEngineProfile, QWebEngineView
    from PyQt5.QtWidgets import QApplication, QMainWindow, QTabWidget
    import PyQt5.sip as sip
except ImportError as exc:  # pragma: no cover - handled at runtime
    raise SystemExit(
        "Missing dependency 'PyQt5/PyQtWebEngine'. Install with: python3 -m pip install -r requirements.txt"
    ) from exc

try:
    from .storage import BrowserStore, InMemoryKeyValueStore, JsonKeyValueStore
except ImportError:  # pragma: no cover - allows running this module directly
    from storage import BrowserStore, InMemoryKeyValueStore, JsonKeyValueStore


_DEBUG = os.getenv("AI_BROWSER_MCP_DEBUG", "").lower() in ("1", "true", "yes", "y", "on")


def _debug(message: str) -> None:
    if not _DEBUG:
        return
    print(f"[browser_use] {message}", file=sys.stderr, flush=True)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def is_ci_environment() -> bool:
    ci_markers = (
        "CI",
        "GITHUB_ACTIONS",
        "BUILDKITE",
        "CIRCLECI",
        "GITLAB_CI",
        "TRAVIS",
        "TF_BUILD",
    )
    return any(os.getenv(marker) for marker in ci_markers)


class UiBridge(QObject):
    _invoke = pyqtSignal(object)

    def __init__(self, ui_thread_id: int) -> None:
        super().__init__()
        self._ui_thread_id = ui_thread_id
        self._invoke.connect(self._run_on_ui_thread)

    def _run_on_ui_thread(self, callback: Callable[[], None]) -> None:
        callback()

    def run(self, callback: Callable[[], Any], timeout: float = 20.0) -> Any:
        if threading.get_ident() == self._ui_thread_id:
            return callback()

        done = threading.Event()
        slot: Dict[str, Any] = {}

        def wrapped() -> None:
            try:
                slot["result"] = callback()
            except Exception as error:  # pragma: no cover - propagated to caller
                slot["error"] = error
            finally:
                done.set()

        self._invoke.emit(wrapped)

        if not done.wait(timeout):
            raise TimeoutError(f"Timed out waiting for UI thread after {timeout:.1f}s")

        if "error" in slot:
            raise slot["error"]

        return slot.get("result")


class LoggingWebPage(QWebEnginePage):
    def __init__(
        self,
        on_log: Callable[[Dict[str, Any]], None],
        parent: Optional[QObject] = None,
        profile: Optional[QWebEngineProfile] = None,
    ) -> None:
        if profile is not None:
            super().__init__(profile, parent)
        else:
            super().__init__(parent)
        self._on_log = on_log

    def javaScriptConsoleMessage(
        self,
        level: QWebEnginePage.JavaScriptConsoleMessageLevel,
        message: str,
        line_number: int,
        source_id: str,
    ) -> None:
        level_map = {
            QWebEnginePage.InfoMessageLevel: "info",
            QWebEnginePage.WarningMessageLevel: "warning",
            QWebEnginePage.ErrorMessageLevel: "error",
        }
        self._on_log(
            {
                "timestamp": utc_now_iso(),
                "level": level_map.get(level, str(level)),
                "message": message,
                "line": int(line_number),
                "source": source_id,
            }
        )


@dataclass
class BrowserTab:
    tab_id: int
    view: QWebEngineView
    page: LoggingWebPage
    is_loading: bool = False


class BrowserRuntime:
    def __init__(
        self,
        start_url: str,
        show_window: bool,
        screenshot_dir: Path,
        profile_dir: Path,
        downloads_dir: Path,
        db_path: Path,
        kv_path: Path,
        max_console_logs: int,
        max_action_history: int,
        width: int,
        height: int,
    ) -> None:
        self.app = QApplication.instance() or QApplication(sys.argv)
        self._ui_thread_id = threading.get_ident()
        self.bridge = UiBridge(self._ui_thread_id)

        self._logs: Deque[Dict[str, Any]] = deque(maxlen=max_console_logs)
        self._logs_lock = threading.Lock()
        self._action_history: Deque[Dict[str, Any]] = deque(maxlen=max_action_history)
        self._action_history_lock = threading.Lock()
        self._downloads_lock = threading.Lock()
        self._downloads: Dict[str, Dict[str, Any]] = {}
        self._download_id_counter = itertools.count(1)

        self.screenshot_dir = screenshot_dir
        self.screenshot_dir.mkdir(parents=True, exist_ok=True)
        self.downloads_dir = downloads_dir
        self.downloads_dir.mkdir(parents=True, exist_ok=True)
        self._show_window = bool(show_window)
        self.store = BrowserStore(db_path=db_path)
        self.persistent_kv_store = JsonKeyValueStore(path=kv_path)
        self.memory_kv_store = InMemoryKeyValueStore()
        # Backward-compatible alias used by legacy browser_kv_* tools.
        self.kv_store = self.persistent_kv_store

        self.window = QMainWindow()
        self.window.resize(width, height)
        self.window.setWindowTitle("browser_use")
        self.tab_widget = QTabWidget(self.window)
        self.tab_widget.setTabsClosable(True)
        self.tab_widget.setMovable(True)
        self.tab_widget.currentChanged.connect(self._on_current_tab_changed)
        self.tab_widget.tabCloseRequested.connect(self._on_tab_close_requested)
        self.window.setCentralWidget(self.tab_widget)

        self._tabs: Dict[int, BrowserTab] = {}
        self._tab_id_counter = itertools.count(1)

        self._is_loading = False
        self.view = QWebEngineView(self.tab_widget)

        # Use a named profile with on-disk storage so auth cookies/localStorage survive
        # navigations and reloads in headed runs.
        self.profile_dir = profile_dir
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.profile = QWebEngineProfile("ai-browser", self.window)
        self.profile.setPersistentCookiesPolicy(QWebEngineProfile.ForcePersistentCookies)
        self.profile.setCachePath(str((self.profile_dir / "cache").resolve()))
        self.profile.setPersistentStoragePath(str((self.profile_dir / "storage").resolve()))
        self.profile.setHttpCacheType(QWebEngineProfile.DiskHttpCache)
        self.profile.downloadRequested.connect(self._on_download_requested)

        self.page = LoggingWebPage(self._append_console_log, self.view, profile=self.profile)
        self.view.setPage(self.page)

        first_tab = self._create_tab_ui(start_url=start_url, make_active=True)
        self._set_active_tab_ui(first_tab.tab_id)

        if show_window:
            self.window.show()
            self.window.raise_()
            self.window.activateWindow()
            self.app.processEvents()

    def _current_tab_ui(self) -> Optional[BrowserTab]:
        index = self.tab_widget.currentIndex()
        if index < 0:
            return None
        widget = self.tab_widget.widget(index)
        if widget is None:
            return None
        raw_id = widget.property("tab_id")
        try:
            tab_id = int(raw_id)
        except (TypeError, ValueError):
            return None
        return self._tabs.get(tab_id)

    def _tab_index_for_id_ui(self, tab_id: int) -> int:
        for index in range(self.tab_widget.count()):
            widget = self.tab_widget.widget(index)
            if widget is None:
                continue
            raw_id = widget.property("tab_id")
            try:
                if int(raw_id) == int(tab_id):
                    return index
            except (TypeError, ValueError):
                continue
        return -1

    def _set_active_tab_ui(self, tab_id: int) -> None:
        tab = self._tabs.get(int(tab_id))
        if tab is None:
            return
        self.view = tab.view
        self.page = tab.page
        self._is_loading = bool(tab.is_loading)

    def _tab_payload_ui(self, tab: BrowserTab, index: int) -> Dict[str, Any]:
        return {
            "tab_id": tab.tab_id,
            "index": int(index),
            "title": tab.view.title(),
            "url": tab.view.url().toString(),
            "loading": bool(tab.is_loading),
            "is_current": index == self.tab_widget.currentIndex(),
        }

    def _list_tabs_ui(self) -> Dict[str, Any]:
        tabs: List[Dict[str, Any]] = []
        for index in range(self.tab_widget.count()):
            widget = self.tab_widget.widget(index)
            if widget is None:
                continue
            raw_id = widget.property("tab_id")
            try:
                tab_id = int(raw_id)
            except (TypeError, ValueError):
                continue
            tab = self._tabs.get(tab_id)
            if tab is None:
                continue
            tabs.append(self._tab_payload_ui(tab=tab, index=index))

        current = self._current_tab_ui()
        return {
            "count": len(tabs),
            "current_tab_id": current.tab_id if current else None,
            "tabs": tabs,
            "timestamp": utc_now_iso(),
        }

    def _set_tab_title_ui(self, tab_id: int, title: str) -> None:
        index = self._tab_index_for_id_ui(tab_id)
        if index < 0:
            return
        label = (title or "").strip()[:70] or f"tab {tab_id}"
        self.tab_widget.setTabText(index, label)

    def _create_tab_ui(self, start_url: str = "about:blank", make_active: bool = True) -> BrowserTab:
        tab_id = next(self._tab_id_counter)
        view = QWebEngineView(self.tab_widget)
        page = LoggingWebPage(self._append_console_log, view, profile=self.profile)
        view.setPage(page)
        view.setProperty("tab_id", tab_id)

        tab = BrowserTab(tab_id=tab_id, view=view, page=page, is_loading=False)
        self._tabs[tab_id] = tab

        view.loadStarted.connect(lambda tid=tab_id: self._on_load_started(tid))
        view.loadFinished.connect(lambda ok, tid=tab_id: self._on_load_finished(tid, ok))
        page.titleChanged.connect(lambda title, tid=tab_id: self._set_tab_title_ui(tid, title))

        index = self.tab_widget.addTab(view, f"tab {tab_id}")
        if make_active:
            self.tab_widget.setCurrentIndex(index)

        target_url = str(start_url or "").strip() or "about:blank"
        view.setUrl(QUrl(target_url))
        return tab

    def _close_tab_by_index_ui(self, index: int) -> Dict[str, Any]:
        if index < 0 or index >= self.tab_widget.count():
            raise ValueError(f"Invalid tab index: {index}")

        widget = self.tab_widget.widget(index)
        if widget is None:
            raise ValueError(f"No tab at index {index}")
        raw_id = widget.property("tab_id")
        try:
            tab_id = int(raw_id)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Invalid tab_id at index {index}: {raw_id}") from exc

        self.tab_widget.removeTab(index)
        tab = self._tabs.pop(tab_id, None)
        if tab is not None:
            tab.view.deleteLater()

        if self.tab_widget.count() == 0:
            self._create_tab_ui(start_url="about:blank", make_active=True)

        current = self._current_tab_ui()
        if current is not None:
            self._set_active_tab_ui(current.tab_id)

        return {
            "closed_tab_id": tab_id,
            "count": int(self.tab_widget.count()),
            "current_tab_id": current.tab_id if current else None,
            "timestamp": utc_now_iso(),
        }

    def _on_tab_close_requested(self, index: int) -> None:
        try:
            result = self._close_tab_by_index_ui(index)
            self._record_action(
                "tab_closed",
                {
                    "tab_id": result.get("closed_tab_id"),
                    "remaining_tabs": result.get("count"),
                },
            )
        except Exception as exc:
            self._record_action("tab_close_error", {"index": index, "error": str(exc)})

    def _on_current_tab_changed(self, index: int) -> None:
        if index < 0:
            return
        current = self._current_tab_ui()
        if current is None:
            return
        self._set_active_tab_ui(current.tab_id)
        self._record_action("tab_switched", {"tab_id": current.tab_id, "index": int(index)})

    def _should_record_history_url(self, url: str) -> bool:
        normalized = str(url or "").strip().lower()
        if not normalized:
            return False
        if normalized.startswith(("about:", "data:", "javascript:", "qrc:", "chrome-error://")):
            return False
        return True

    def _on_load_started(self, tab_id: int) -> None:
        tab = self._tabs.get(int(tab_id))
        if tab is None:
            return
        tab.is_loading = True
        current = self._current_tab_ui()
        if current and current.tab_id == tab.tab_id:
            self._is_loading = True
        self._record_action(
            "load_started",
            {
                "tab_id": tab_id,
                "url": tab.view.url().toString(),
                "title": tab.view.title(),
            },
        )

    def _on_load_finished(self, tab_id: int, ok: bool) -> None:
        tab = self._tabs.get(int(tab_id))
        if tab is None:
            return
        tab.is_loading = False
        current = self._current_tab_ui()
        if current and current.tab_id == tab.tab_id:
            self._is_loading = False

        url = tab.view.url().toString()
        title = tab.view.title()
        if ok and self._should_record_history_url(url):
            try:
                self.store.record_visit(title=title, url=url, visit_time=utc_now_iso(), tab_id=tab_id)
            except Exception as exc:
                self._record_action("history_store_error", {"tab_id": tab_id, "error": str(exc)})

        self._record_action(
            "load_finished",
            {
                "tab_id": tab_id,
                "ok": bool(ok),
                "url": url,
                "title": title,
            },
        )

    def _append_console_log(self, log: Dict[str, Any]) -> None:
        with self._logs_lock:
            self._logs.append(log)

    def _record_action(self, action: str, details: Optional[Dict[str, Any]] = None) -> None:
        event: Dict[str, Any] = {
            "timestamp": utc_now_iso(),
            "action": action,
        }
        if details:
            event["details"] = details
        with self._action_history_lock:
            self._action_history.append(event)

    def _state_ui(self) -> Dict[str, Any]:
        current = self._current_tab_ui()
        if current is None:
            return {
                "url": "",
                "title": "",
                "loading": False,
                "can_go_back": False,
                "can_go_forward": False,
                "current_tab_id": None,
                "tab_count": 0,
                "timestamp": utc_now_iso(),
            }
        history = current.page.history()
        return {
            "url": current.view.url().toString(),
            "title": current.view.title(),
            "loading": bool(current.is_loading),
            "can_go_back": history.canGoBack(),
            "can_go_forward": history.canGoForward(),
            "current_tab_id": current.tab_id,
            "tab_count": len(self._tabs),
            "timestamp": utc_now_iso(),
        }

    def _run_navigation_action_ui(self, trigger: Callable[[], None], timeout_ms: int) -> Dict[str, Any]:
        current = self._current_tab_ui()
        if current is None:
            raise RuntimeError("No active tab")
        view = current.view

        loop = QEventLoop()
        timer = QTimer()
        timer.setSingleShot(True)

        state: Dict[str, Any] = {"done": False, "ok": False}

        def on_load_finished(ok: bool) -> None:
            state["done"] = True
            state["ok"] = bool(ok)
            if loop.isRunning():
                loop.quit()

        def on_timeout() -> None:
            if loop.isRunning():
                loop.quit()

        view.loadFinished.connect(on_load_finished)
        timer.timeout.connect(on_timeout)

        trigger()
        timer.start(timeout_ms)
        loop.exec_()
        timer.stop()

        try:
            view.loadFinished.disconnect(on_load_finished)
        except TypeError:
            pass

        if not state["done"]:
            raise TimeoutError(f"Navigation timed out after {timeout_ms}ms")

        return {
            "ok": state["ok"],
            "url": view.url().toString(),
            "title": view.title(),
            "tab_id": current.tab_id,
            "timestamp": utc_now_iso(),
        }

    def _run_js_ui(self, script: str, timeout_ms: int = 15000) -> Any:
        loop = QEventLoop()
        timer = QTimer()
        timer.setSingleShot(True)

        state: Dict[str, Any] = {"done": False, "result": None}

        def on_result(result: Any) -> None:
            state["done"] = True
            state["result"] = result
            if loop.isRunning():
                loop.quit()

        def on_timeout() -> None:
            if loop.isRunning():
                loop.quit()

        timer.timeout.connect(on_timeout)
        current = self._current_tab_ui()
        if current is None:
            raise RuntimeError("No active tab")
        current.page.runJavaScript(script, on_result)
        timer.start(timeout_ms)
        loop.exec_()
        timer.stop()

        if not state["done"]:
            raise TimeoutError(f"JavaScript execution timed out after {timeout_ms}ms")

        return state["result"]

    def _navigate_ui(self, url: str, timeout_ms: int) -> Dict[str, Any]:
        target = QUrl(url)
        if not target.isValid():
            raise ValueError(f"Invalid URL: {url}")
        current = self._current_tab_ui()
        if current is None:
            raise RuntimeError("No active tab")
        return self._run_navigation_action_ui(lambda: current.view.setUrl(target), timeout_ms=timeout_ms)

    def navigate(self, url: str, timeout_ms: int = 20000) -> Dict[str, Any]:
        timeout = max(2.0, (timeout_ms / 1000.0) + 2.0)
        try:
            result = self.bridge.run(lambda: self._navigate_ui(url, timeout_ms), timeout=timeout)
        except Exception as exc:
            self._record_action(
                "navigate",
                {
                    "target_url": url,
                    "timeout_ms": int(timeout_ms),
                    "ok": False,
                    "error": str(exc),
                },
            )
            raise

        self._record_action(
            "navigate",
            {
                "target_url": url,
                "timeout_ms": int(timeout_ms),
                "ok": bool(result.get("ok")),
                "url": result.get("url"),
                "title": result.get("title"),
            },
        )
        return result

    def state(self) -> Dict[str, Any]:
        return self.bridge.run(self._state_ui, timeout=5.0)

    def tabs_list(self) -> Dict[str, Any]:
        return self.bridge.run(self._list_tabs_ui, timeout=5.0)

    def new_tab(self, url: str = "about:blank", make_active: bool = True) -> Dict[str, Any]:
        def _new_tab_ui() -> Dict[str, Any]:
            created = self._create_tab_ui(start_url=url or "about:blank", make_active=bool(make_active))
            index = self._tab_index_for_id_ui(created.tab_id)
            payload = self._tab_payload_ui(created, index=index if index >= 0 else self.tab_widget.currentIndex())
            payload["timestamp"] = utc_now_iso()
            return payload

        result = self.bridge.run(_new_tab_ui, timeout=8.0)
        self._record_action(
            "tab_new",
            {
                "tab_id": result.get("tab_id"),
                "url": result.get("url"),
                "make_active": bool(make_active),
            },
        )
        return result

    def switch_tab(self, tab_id: int) -> Dict[str, Any]:
        def _switch_ui() -> Dict[str, Any]:
            index = self._tab_index_for_id_ui(int(tab_id))
            if index < 0:
                raise ValueError(f"Unknown tab_id: {tab_id}")
            self.tab_widget.setCurrentIndex(index)
            current = self._current_tab_ui()
            if current is None:
                raise RuntimeError("Failed to switch tab")
            self._set_active_tab_ui(current.tab_id)
            result = self._tab_payload_ui(current, index=index)
            result["timestamp"] = utc_now_iso()
            return result

        result = self.bridge.run(_switch_ui, timeout=5.0)
        self._record_action("tab_switch", {"tab_id": result.get("tab_id"), "index": result.get("index")})
        return result

    def close_tab(self, tab_id: Optional[int] = None) -> Dict[str, Any]:
        def _close_ui() -> Dict[str, Any]:
            if tab_id is None:
                index = self.tab_widget.currentIndex()
            else:
                index = self._tab_index_for_id_ui(int(tab_id))
            return self._close_tab_by_index_ui(index=index)

        result = self.bridge.run(_close_ui, timeout=8.0)
        self._record_action(
            "tab_close",
            {
                "closed_tab_id": result.get("closed_tab_id"),
                "current_tab_id": result.get("current_tab_id"),
            },
        )
        return result

    def eval_js(self, script: str, timeout_ms: int = 15000, record_action: bool = True) -> Any:
        timeout = max(2.0, (timeout_ms / 1000.0) + 2.0)
        try:
            result = self.bridge.run(lambda: self._run_js_ui(script, timeout_ms=timeout_ms), timeout=timeout)
        except Exception as exc:
            if record_action:
                self._record_action(
                    "eval_js",
                    {
                        "ok": False,
                        "timeout_ms": int(timeout_ms),
                        "script_chars": len(script),
                        "error": str(exc),
                    },
                )
            raise

        if record_action:
            self._record_action(
                "eval_js",
                {
                    "ok": True,
                    "timeout_ms": int(timeout_ms),
                    "script_chars": len(script),
                    "result_type": type(result).__name__,
                },
            )
        return result

    def get_dom(self, selector: str = "html", index: int = 0, include_html: bool = True) -> Dict[str, Any]:
        selector_json = json.dumps(selector)
        include_html_js = "true" if include_html else "false"

        script = f"""
(() => {{
  const selector = {selector_json};
  const index = {int(index)};
  const nodes = Array.from(document.querySelectorAll(selector));
  const el = nodes[index] || null;

  if (!el) {{
    return {{
      found: false,
      selector,
      index,
      count: nodes.length,
      pageUrl: window.location.href,
      title: document.title,
    }};
  }}

  const attributes = {{}};
  for (const attr of Array.from(el.attributes || [])) {{
    attributes[attr.name] = attr.value;
  }}

  return {{
    found: true,
    selector,
    index,
    count: nodes.length,
    tag: (el.tagName || "").toLowerCase(),
    id: el.id || null,
    classes: Array.from(el.classList || []),
    text: (el.innerText || "").slice(0, 4000),
    value: ("value" in el) ? el.value : null,
    html: {include_html_js} ? el.outerHTML : null,
    attributes,
    rect: (() => {{
      const r = el.getBoundingClientRect();
      return {{ x: r.x, y: r.y, width: r.width, height: r.height }};
    }})(),
    pageUrl: window.location.href,
    title: document.title,
  }};
}})();
        """.strip()

        result = self.eval_js(script, record_action=False)
        if not isinstance(result, dict):
            raise RuntimeError("Unexpected get_dom response from page")
        return result

    def describe_dom_tree(
        self,
        selector: str = "body",
        max_depth: int = 2,
        max_children: int = 20,
        max_text: int = 240,
    ) -> Dict[str, Any]:
        selector_json = json.dumps(selector)

        script = f"""
(() => {{
  const selector = {selector_json};
  const maxDepth = {int(max_depth)};
  const maxChildren = {int(max_children)};
  const maxText = {int(max_text)};

  function toNode(node, depth) {{
    if (!node) return null;

    const info = {{
      tag: (node.tagName || "").toLowerCase(),
      id: node.id || null,
      classes: Array.from(node.classList || []),
      text: (node.innerText || "").trim().slice(0, maxText),
      children: []
    }};

    if (depth >= maxDepth) {{
      return info;
    }}

    const kids = Array.from(node.children || []).slice(0, maxChildren);
    info.children = kids
      .map((child) => toNode(child, depth + 1))
      .filter((value) => value !== null);

    return info;
  }}

  const root = document.querySelector(selector);
  if (!root) {{
    return {{ found: false, selector, pageUrl: window.location.href, title: document.title }};
  }}

  return {{
    found: true,
    selector,
    tree: toNode(root, 0),
    pageUrl: window.location.href,
    title: document.title,
  }};
}})();
        """.strip()

        result = self.eval_js(script, record_action=False)
        if not isinstance(result, dict):
            raise RuntimeError("Unexpected describe_dom_tree response from page")
        return result

    def query_selector_all(self, selector: str, limit: int = 25) -> Dict[str, Any]:
        selector_json = json.dumps(selector)

        script = f"""
(() => {{
  const selector = {selector_json};
  const limit = {int(limit)};
  const elements = Array.from(document.querySelectorAll(selector)).slice(0, limit);
  return {{
    selector,
    total: document.querySelectorAll(selector).length,
    returned: elements.length,
    items: elements.map((el, index) => ({{
      index,
      tag: (el.tagName || "").toLowerCase(),
      id: el.id || null,
      classes: Array.from(el.classList || []),
      text: (el.innerText || "").trim().slice(0, 500),
      value: ("value" in el) ? el.value : null,
      href: el.href || null,
      ariaLabel: el.getAttribute("aria-label"),
    }})),
    pageUrl: window.location.href,
    title: document.title,
  }};
}})();
        """.strip()

        result = self.eval_js(script, record_action=False)
        if not isinstance(result, dict):
            raise RuntimeError("Unexpected query_selector_all response from page")
        return result

    def click(self, selector: str, index: int = 0) -> Dict[str, Any]:
        selector_json = json.dumps(selector)

        script = f"""
(() => {{
  const selector = {selector_json};
  const index = {int(index)};
  const elements = Array.from(document.querySelectorAll(selector));
  const element = elements[index];

  if (!element) {{
    return {{ ok: false, selector, index, count: elements.length, error: "Element not found" }};
  }}

  const tag = (element.tagName || "").toLowerCase();

  element.scrollIntoView({{ block: "center", inline: "center", behavior: "instant" }});
  element.focus();
  element.dispatchEvent(new MouseEvent("mousedown", {{ bubbles: true, cancelable: true }}));
  element.dispatchEvent(new MouseEvent("mouseup", {{ bubbles: true, cancelable: true }}));
  element.dispatchEvent(new MouseEvent("click", {{ bubbles: true, cancelable: true }}));

  return {{
    ok: true,
    selector,
    index,
    count: elements.length,
    tag,
    text: (element.innerText || "").trim().slice(0, 300),
    href: element.href || null,
    pageUrl: window.location.href,
    title: document.title,
  }};
}})();
        """.strip()

        result = self.eval_js(script, record_action=False)
        if not isinstance(result, dict):
            raise RuntimeError("Unexpected click response from page")
        self._record_action(
            "click",
            {
                "selector": selector,
                "index": int(index),
                "ok": bool(result.get("ok")),
                "target_url": result.get("pageUrl"),
                "target_title": result.get("title"),
                "tag": result.get("tag"),
                "text": result.get("text"),
            },
        )
        return result

    def type_text(
        self,
        selector: str,
        text: str,
        index: int = 0,
        clear_first: bool = True,
        submit: bool = False,
    ) -> Dict[str, Any]:
        selector_json = json.dumps(selector)
        text_json = json.dumps(text)
        clear_first_js = "true" if clear_first else "false"
        submit_js = "true" if submit else "false"

        script = f"""
(() => {{
  const selector = {selector_json};
  const text = {text_json};
  const index = {int(index)};
  const clearFirst = {clear_first_js};
  const submit = {submit_js};

  const elements = Array.from(document.querySelectorAll(selector));
  const element = elements[index];

  if (!element) {{
    return {{ ok: false, selector, index, count: elements.length, error: "Element not found" }};
  }}

  const inputType = (typeof element.getAttribute === "function" ? (element.getAttribute("type") || "") : "").toLowerCase();
  const isPassword = inputType === "password";

  element.scrollIntoView({{ block: "center", inline: "center", behavior: "instant" }});
  element.focus();

  if (element.isContentEditable) {{
    if (clearFirst) {{
      element.innerText = "";
    }}
    element.innerText = clearFirst ? text : `${{element.innerText || ""}}${{text}}`;
  }} else if ("value" in element) {{
    const readValue = () => (typeof element.value === "string" ? element.value : "");
    const nextValue = clearFirst ? text : `${{readValue()}}${{text}}`;
    const previousValue = readValue();

    // Use the native property setter to support React/Vue controlled inputs.
    const ownDescriptor = Object.getOwnPropertyDescriptor(element, "value");
    const proto = Object.getPrototypeOf(element);
    const protoDescriptor = proto ? Object.getOwnPropertyDescriptor(proto, "value") : null;
    const setter = (protoDescriptor && protoDescriptor.set) || (ownDescriptor && ownDescriptor.set);

    if (setter) {{
      setter.call(element, nextValue);
    }} else {{
      element.value = nextValue;
    }}

    // React tracks previous values on controlled inputs; this nudges its change detector.
    const tracker = element._valueTracker;
    if (tracker && typeof tracker.setValue === "function") {{
      tracker.setValue(previousValue);
    }}
  }} else {{
    return {{
      ok: false,
      selector,
      index,
      count: elements.length,
      error: "Element does not accept text input",
      tag: (element.tagName || "").toLowerCase(),
    }};
  }}

  if (typeof InputEvent === "function") {{
    element.dispatchEvent(
      new InputEvent("input", {{
        bubbles: true,
        cancelable: false,
        data: text,
        inputType: clearFirst ? "insertReplacementText" : "insertText",
      }})
    );
  }} else {{
    element.dispatchEvent(new Event("input", {{ bubbles: true }}));
  }}
  element.dispatchEvent(new Event("change", {{ bubbles: true }}));

  // Fallback for React controlled inputs where synthetic dispatch can be ignored.
  const reactPropsKey = Object.keys(element).find((key) => key.startsWith("__reactProps$"));
  if (reactPropsKey) {{
    const reactProps = element[reactPropsKey];
    const syntheticEvent = {{
      target: element,
      currentTarget: element,
      type: "change",
      bubbles: true,
      cancelable: false,
      defaultPrevented: false,
      preventDefault: () => {{}},
      stopPropagation: () => {{}},
      persist: () => {{}},
      nativeEvent: null,
    }};
    if (reactProps && typeof reactProps.onChange === "function") {{
      reactProps.onChange(syntheticEvent);
    }}
    if (reactProps && typeof reactProps.onInput === "function") {{
      reactProps.onInput({{ ...syntheticEvent, type: "input" }});
    }}
  }}

  if (submit) {{
    const form = element.form || element.closest("form");
    if (form) {{
      if (typeof form.requestSubmit === "function") {{
        form.requestSubmit();
      }} else {{
        form.submit();
      }}
    }} else {{
      element.dispatchEvent(new KeyboardEvent("keydown", {{ key: "Enter", code: "Enter", bubbles: true }}));
      element.dispatchEvent(new KeyboardEvent("keyup", {{ key: "Enter", code: "Enter", bubbles: true }}));
    }}
  }}

  return {{
    ok: true,
    selector,
    index,
    count: elements.length,
    input_type: inputType || null,
    is_password: isPassword,
    value: ("value" in element && !isPassword) ? element.value : null,
    text: element.isContentEditable ? element.innerText : null,
    pageUrl: window.location.href,
    title: document.title,
  }};
}})();
        """.strip()

        result = self.eval_js(script, record_action=False)
        if not isinstance(result, dict):
            raise RuntimeError("Unexpected type_text response from page")
        selector_lower = selector.lower()
        is_sensitive = bool(result.get("is_password")) or any(
            token in selector_lower for token in ("password", "passwd", "pass", "token", "secret", "api_key", "otp")
        )
        if is_sensitive:
            typed_value: Any = {"redacted": True, "chars": len(text)}
        else:
            typed_value = text if len(text) <= 160 else f"{text[:160]}..."

        self._record_action(
            "type_text",
            {
                "selector": selector,
                "index": int(index),
                "clear_first": bool(clear_first),
                "submit": bool(submit),
                "ok": bool(result.get("ok")),
                "input_type": result.get("input_type"),
                "is_password": bool(result.get("is_password")),
                "typed": typed_value,
                "page_url": result.get("pageUrl"),
                "page_title": result.get("title"),
            },
        )
        return result

    def wait_for_selector(self, selector: str, timeout_ms: int = 8000, poll_ms: int = 150) -> Dict[str, Any]:
        deadline = time.time() + (timeout_ms / 1000.0)

        while time.time() < deadline:
            selector_json = json.dumps(selector)
            exists = self.eval_js(
                f"document.querySelector({selector_json}) !== null",
                timeout_ms=max(poll_ms, 500),
                record_action=False,
            )
            if bool(exists):
                result = {
                    "found": True,
                    "selector": selector,
                    "timestamp": utc_now_iso(),
                    "state": self.state(),
                }
                self._record_action(
                    "wait_for_selector",
                    {
                        "selector": selector,
                        "found": True,
                        "timeout_ms": int(timeout_ms),
                    },
                )
                return result
            time.sleep(max(0.03, poll_ms / 1000.0))

        result = {
            "found": False,
            "selector": selector,
            "timeout_ms": timeout_ms,
            "timestamp": utc_now_iso(),
            "state": self.state(),
        }
        self._record_action(
            "wait_for_selector",
            {
                "selector": selector,
                "found": False,
                "timeout_ms": int(timeout_ms),
            },
        )
        return result

    def get_navigation_history(self, limit: int = 200) -> Dict[str, Any]:
        def _history_ui() -> Dict[str, Any]:
            current = self._current_tab_ui()
            if current is None:
                return {
                    "count": 0,
                    "total": 0,
                    "current_index": -1,
                    "entries": [],
                    "state": self._state_ui(),
                    "timestamp": utc_now_iso(),
                }
            history = current.page.history()
            items = list(history.items())
            total = len(items)
            max_items = max(1, int(limit))
            start_index = max(0, total - max_items)
            current_index = history.currentItemIndex()

            entries: List[Dict[str, Any]] = []
            for idx, item in enumerate(items[start_index:], start=start_index):
                original_url = item.originalUrl().toString() if hasattr(item, "originalUrl") else ""
                entries.append(
                    {
                        "index": idx,
                        "is_current": idx == current_index,
                        "offset_from_current": idx - current_index,
                        "title": item.title() or "",
                        "url": item.url().toString(),
                        "original_url": original_url or None,
                    }
                )

            return {
                "count": len(entries),
                "total": total,
                "current_index": current_index,
                "tab_id": current.tab_id,
                "entries": entries,
                "state": self._state_ui(),
                "timestamp": utc_now_iso(),
            }

        return self.bridge.run(_history_ui, timeout=5.0)

    def go_back(self, steps: int = 1, timeout_ms: int = 20000) -> Dict[str, Any]:
        requested_steps = max(1, int(steps))
        timeout = max(2.0, (timeout_ms / 1000.0) + 2.0)

        def _go_back_ui() -> Dict[str, Any]:
            current = self._current_tab_ui()
            if current is None:
                raise RuntimeError("No active tab")
            history = current.page.history()
            moved = 0
            step_results: List[Dict[str, Any]] = []

            for _ in range(requested_steps):
                if not history.canGoBack():
                    break
                step_result = self._run_navigation_action_ui(current.view.back, timeout_ms=timeout_ms)
                step_results.append(step_result)
                moved += 1
                if not step_result.get("ok"):
                    break

            return {
                "ok": moved > 0 and all(bool(step.get("ok")) for step in step_results),
                "direction": "back",
                "requested_steps": requested_steps,
                "moved_steps": moved,
                "steps": step_results,
                "state": self._state_ui(),
                "timestamp": utc_now_iso(),
            }

        result = self.bridge.run(_go_back_ui, timeout=timeout)
        self._record_action(
            "go_back",
            {
                "requested_steps": requested_steps,
                "moved_steps": result.get("moved_steps"),
                "ok": bool(result.get("ok")),
                "url": result.get("state", {}).get("url"),
            },
        )
        return result

    def go_forward(self, steps: int = 1, timeout_ms: int = 20000) -> Dict[str, Any]:
        requested_steps = max(1, int(steps))
        timeout = max(2.0, (timeout_ms / 1000.0) + 2.0)

        def _go_forward_ui() -> Dict[str, Any]:
            current = self._current_tab_ui()
            if current is None:
                raise RuntimeError("No active tab")
            history = current.page.history()
            moved = 0
            step_results: List[Dict[str, Any]] = []

            for _ in range(requested_steps):
                if not history.canGoForward():
                    break
                step_result = self._run_navigation_action_ui(current.view.forward, timeout_ms=timeout_ms)
                step_results.append(step_result)
                moved += 1
                if not step_result.get("ok"):
                    break

            return {
                "ok": moved > 0 and all(bool(step.get("ok")) for step in step_results),
                "direction": "forward",
                "requested_steps": requested_steps,
                "moved_steps": moved,
                "steps": step_results,
                "state": self._state_ui(),
                "timestamp": utc_now_iso(),
            }

        result = self.bridge.run(_go_forward_ui, timeout=timeout)
        self._record_action(
            "go_forward",
            {
                "requested_steps": requested_steps,
                "moved_steps": result.get("moved_steps"),
                "ok": bool(result.get("ok")),
                "url": result.get("state", {}).get("url"),
            },
        )
        return result

    def reload(self, timeout_ms: int = 20000, bypass_cache: bool = False) -> Dict[str, Any]:
        timeout = max(2.0, (timeout_ms / 1000.0) + 2.0)

        def _reload_ui() -> Dict[str, Any]:
            current = self._current_tab_ui()
            if current is None:
                raise RuntimeError("No active tab")

            def _trigger_reload() -> None:
                if bypass_cache and hasattr(QWebEnginePage, "ReloadAndBypassCache"):
                    current.page.triggerAction(QWebEnginePage.ReloadAndBypassCache)
                else:
                    current.view.reload()

            result = self._run_navigation_action_ui(_trigger_reload, timeout_ms=timeout_ms)
            result["bypass_cache"] = bool(bypass_cache)
            return result

        result = self.bridge.run(_reload_ui, timeout=timeout)
        self._record_action(
            "reload",
            {
                "ok": bool(result.get("ok")),
                "timeout_ms": int(timeout_ms),
                "bypass_cache": bool(bypass_cache),
                "url": result.get("url"),
            },
        )
        return result

    def wait_for_url(
        self,
        pattern: str,
        timeout_ms: int = 15000,
        poll_ms: int = 150,
        regex: bool = False,
        ignore_case: bool = True,
        invert_match: bool = False,
    ) -> Dict[str, Any]:
        deadline = time.time() + (timeout_ms / 1000.0)
        poll_seconds = max(0.03, poll_ms / 1000.0)

        compiled_pattern: Optional[re.Pattern[str]] = None
        if regex:
            flags = re.IGNORECASE if ignore_case else 0
            compiled_pattern = re.compile(pattern, flags)

        while time.time() < deadline:
            state = self.state()
            current_url = str(state.get("url") or "")
            if regex:
                matched = compiled_pattern.search(current_url) is not None if compiled_pattern else False
            else:
                left = current_url.lower() if ignore_case else current_url
                right = pattern.lower() if ignore_case else pattern
                matched = right in left

            condition_met = (not matched) if invert_match else matched
            if condition_met:
                result = {
                    "matched": True,
                    "pattern": pattern,
                    "regex": bool(regex),
                    "ignore_case": bool(ignore_case),
                    "invert_match": bool(invert_match),
                    "state": state,
                    "timestamp": utc_now_iso(),
                }
                self._record_action(
                    "wait_for_url",
                    {
                        "pattern": pattern,
                        "matched": True,
                        "regex": bool(regex),
                        "invert_match": bool(invert_match),
                        "timeout_ms": int(timeout_ms),
                    },
                )
                return result

            time.sleep(poll_seconds)

        result = {
            "matched": False,
            "pattern": pattern,
            "regex": bool(regex),
            "ignore_case": bool(ignore_case),
            "invert_match": bool(invert_match),
            "timeout_ms": timeout_ms,
            "state": self.state(),
            "timestamp": utc_now_iso(),
        }
        self._record_action(
            "wait_for_url",
            {
                "pattern": pattern,
                "matched": False,
                "regex": bool(regex),
                "invert_match": bool(invert_match),
                "timeout_ms": int(timeout_ms),
            },
        )
        return result

    def list_interactive_elements(self, limit: int = 200, include_hidden: bool = False) -> Dict[str, Any]:
        include_hidden_js = "true" if include_hidden else "false"

        script = f"""
(() => {{
  const limit = {max(1, int(limit))};
  const includeHidden = {include_hidden_js};
  const selector = 'a,button,input,textarea,select,summary,[role=\"button\"],[contenteditable=\"true\"],label[for]';
  const nodes = Array.from(document.querySelectorAll(selector));

  const escapeCss = (value) => {{
    if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') {{
      return CSS.escape(value);
    }}
    return String(value).replace(/[^a-zA-Z0-9_-]/g, (ch) => '\\\\' + ch);
  }};

  const quoteAttr = (value) => String(value).replace(/\"/g, '\\\\\"');

  const isVisible = (el) => {{
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return rect.width > 0 &&
      rect.height > 0 &&
      style.visibility !== 'hidden' &&
      style.display !== 'none' &&
      style.opacity !== '0';
  }};

  const selectorHint = (el) => {{
    const tag = (el.tagName || '').toLowerCase();
    if (el.id) return `#${{escapeCss(el.id)}}`;

    const name = el.getAttribute('name');
    if (name) return `${{tag}}[name=\"${{quoteAttr(name)}}\"]`;

    const ariaLabel = el.getAttribute('aria-label');
    if (ariaLabel) return `${{tag}}[aria-label=\"${{quoteAttr(ariaLabel)}}\"]`;

    const role = el.getAttribute('role');
    if (role === 'button' && tag !== 'button') return '[role=\"button\"]';

    if (tag === 'a' && el.getAttribute('href')) return `a[href=\"${{quoteAttr(el.getAttribute('href'))}}\"]`;

    const classes = Array.from(el.classList || []).slice(0, 2).filter(Boolean);
    if (classes.length > 0) {{
      return `${{tag}}.${{classes.map((c) => escapeCss(c)).join('.')}}`;
    }}

    return tag || '*';
  }};

  const textOf = (el) => {{
    const direct = (el.innerText || el.textContent || '').trim();
    if (direct) return direct.slice(0, 300);
    return (
      el.getAttribute('placeholder') ||
      el.getAttribute('aria-label') ||
      el.getAttribute('title') ||
      ''
    ).slice(0, 300);
  }};

  const items = [];
  for (const [index, el] of nodes.entries()) {{
    const visible = isVisible(el);
    if (!includeHidden && !visible) continue;

    const tag = (el.tagName || '').toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase() || null;
    const role = el.getAttribute('role');

    items.push({{
      index,
      selector_hint: selectorHint(el),
      tag,
      type,
      role: role || null,
      id: el.id || null,
      name: el.getAttribute('name'),
      text: textOf(el),
      placeholder: el.getAttribute('placeholder'),
      aria_label: el.getAttribute('aria-label'),
      href: el.getAttribute('href'),
      disabled: !!el.disabled,
      checked: !!el.checked,
      visible,
      classes: Array.from(el.classList || []),
    }});

    if (items.length >= limit) break;
  }}

  return {{
    selector,
    total_candidates: nodes.length,
    returned: items.length,
    include_hidden: includeHidden,
    items,
    pageUrl: window.location.href,
    title: document.title,
  }};
}})();
        """.strip()

        result = self.eval_js(script, record_action=False)
        if not isinstance(result, dict):
            raise RuntimeError("Unexpected list_interactive_elements response from page")

        self._record_action(
            "list_interactive_elements",
            {
                "returned": result.get("returned"),
                "total_candidates": result.get("total_candidates"),
                "include_hidden": bool(include_hidden),
            },
        )
        return result

    @staticmethod
    def _download_state_label(state: Any) -> str:
        candidates = (
            ("DownloadRequested", "requested"),
            ("DownloadInProgress", "in_progress"),
            ("DownloadCompleted", "completed"),
            ("DownloadCancelled", "cancelled"),
            ("DownloadInterrupted", "interrupted"),
        )
        try:
            raw = int(state)
        except Exception:
            raw = None
        for attr, label in candidates:
            if hasattr(QWebEngineDownloadItem, attr):
                if raw == int(getattr(QWebEngineDownloadItem, attr)):
                    return label
        return "unknown"

    @staticmethod
    def _download_payload(entry: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "download_id": entry.get("download_id"),
            "tab_id": entry.get("tab_id"),
            "url": entry.get("url"),
            "suggested_file_name": entry.get("suggested_file_name"),
            "target_path": entry.get("target_path"),
            "status": entry.get("status"),
            "decision": entry.get("decision"),
            "received_bytes": entry.get("received_bytes"),
            "total_bytes": entry.get("total_bytes"),
            "error": entry.get("error"),
            "created_at": entry.get("created_at"),
            "updated_at": entry.get("updated_at"),
        }

    def _persist_download_entry(self, entry: Dict[str, Any]) -> None:
        self.store.upsert_download(
            token=str(entry.get("download_id")),
            tab_id=entry.get("tab_id"),
            url=entry.get("url"),
            suggested_file_name=entry.get("suggested_file_name"),
            target_path=entry.get("target_path"),
            status=str(entry.get("status") or "pending"),
            decision=str(entry.get("decision") or "pending"),
            created_at=str(entry.get("created_at") or utc_now_iso()),
            updated_at=str(entry.get("updated_at") or utc_now_iso()),
            received_bytes=int(entry.get("received_bytes") or 0),
            total_bytes=int(entry.get("total_bytes") or 0),
            error=entry.get("error"),
        )

    def _on_download_requested(self, item: QWebEngineDownloadItem) -> None:
        download_id = f"dl-{int(time.time() * 1000)}-{next(self._download_id_counter)}"
        current = self._current_tab_ui()
        tab_id = current.tab_id if current else None

        suggested = ""
        try:
            suggested = item.downloadFileName() or ""
        except Exception:
            suggested = ""
        if not suggested:
            url_path_name = Path(item.url().path()).name if item.url().isValid() else ""
            suggested = url_path_name or f"download-{download_id}.bin"

        target_path = str((self.downloads_dir / suggested).resolve())
        try:
            item.setPath(target_path)
        except Exception:
            pass

        now = utc_now_iso()
        entry: Dict[str, Any] = {
            "download_id": download_id,
            "tab_id": tab_id,
            "url": item.url().toString(),
            "suggested_file_name": suggested,
            "target_path": target_path,
            "status": "pending_decision",
            "decision": "pending",
            "received_bytes": 0,
            "total_bytes": 0,
            "error": None,
            "created_at": now,
            "updated_at": now,
            "item": item,
        }
        with self._downloads_lock:
            self._downloads[download_id] = entry

        try:
            item.accept()
            if hasattr(item, "pause"):
                item.pause()
        except Exception as exc:
            entry["error"] = str(exc)
            entry["status"] = "interrupted"

        item.downloadProgress.connect(
            lambda received, total, did=download_id: self._on_download_progress(did, received, total)
        )
        if hasattr(item, "stateChanged"):
            item.stateChanged.connect(lambda state, did=download_id: self._on_download_state_changed(did, state))
        if hasattr(item, "finished"):
            item.finished.connect(lambda did=download_id: self._on_download_finished(did))

        self._persist_download_entry(entry)
        self._record_action(
            "download_requested",
            {
                "download_id": download_id,
                "url": entry.get("url"),
                "suggested_file_name": suggested,
                "tab_id": tab_id,
            },
        )

    def _on_download_progress(self, download_id: str, received: int, total: int) -> None:
        with self._downloads_lock:
            entry = self._downloads.get(download_id)
            if not entry:
                return
            entry["received_bytes"] = int(received)
            entry["total_bytes"] = int(total)
            if entry.get("decision") == "accepted":
                entry["status"] = "in_progress"
            entry["updated_at"] = utc_now_iso()
            snapshot = dict(entry)
        self._persist_download_entry(snapshot)

    def _on_download_state_changed(self, download_id: str, state: Any) -> None:
        label = self._download_state_label(state)
        with self._downloads_lock:
            entry = self._downloads.get(download_id)
            if not entry:
                return
            if label != "unknown":
                entry["status"] = label
            entry["updated_at"] = utc_now_iso()
            snapshot = dict(entry)
        self._persist_download_entry(snapshot)

    def _on_download_finished(self, download_id: str) -> None:
        with self._downloads_lock:
            entry = self._downloads.get(download_id)
            if not entry:
                return
            item = entry.get("item")
            state = item.state() if item is not None and hasattr(item, "state") else None
            label = self._download_state_label(state)
            if label != "unknown":
                entry["status"] = label
            if not entry.get("status") or entry.get("status") == "pending_decision":
                entry["status"] = "finished"
            if entry.get("decision") == "pending" and entry.get("status") in ("cancelled", "interrupted"):
                entry["decision"] = "auto_cancelled"
            try:
                if item is not None and hasattr(item, "interruptReasonString"):
                    err = item.interruptReasonString() or None
                    entry["error"] = err
            except Exception:
                pass
            entry["item"] = None
            entry["updated_at"] = utc_now_iso()
            snapshot = dict(entry)
        self._persist_download_entry(snapshot)
        self._record_action(
            "download_finished",
            {
                "download_id": download_id,
                "status": snapshot.get("status"),
                "error": snapshot.get("error"),
            },
        )

    def list_downloads(self, limit: int = 300, status: Optional[str] = None) -> Dict[str, Any]:
        rows = self.store.list_downloads(limit=limit, status=status)
        for row in rows:
            if "download_id" not in row:
                row["download_id"] = row.get("download_token")
        return {
            "count": len(rows),
            "downloads": rows,
            "timestamp": utc_now_iso(),
        }

    def decide_download(self, download_id: str, accept: bool, path: Optional[str] = None) -> Dict[str, Any]:
        def _decide_ui() -> Dict[str, Any]:
            with self._downloads_lock:
                entry = self._downloads.get(download_id)
                if not entry:
                    stored = self.store.get_download(download_id)
                    if stored is None:
                        raise ValueError(f"Unknown download id: {download_id}")
                    return dict(stored)

                item = entry.get("item")
                if item is None:
                    raise RuntimeError(f"Download item not available for {download_id}")
                if sip.isdeleted(item):
                    raise RuntimeError(f"Download item already finalized for {download_id}")

                if accept:
                    target_path = str((Path(path).expanduser() if path else Path(entry["target_path"])).resolve())
                    Path(target_path).parent.mkdir(parents=True, exist_ok=True)
                    item.setPath(target_path)
                    if hasattr(item, "resume"):
                        item.resume()
                    else:
                        item.accept()
                    entry["target_path"] = target_path
                    entry["decision"] = "accepted"
                    entry["status"] = "in_progress"
                else:
                    item.cancel()
                    entry["decision"] = "rejected"
                    entry["status"] = "rejected"

                entry["updated_at"] = utc_now_iso()
                snapshot = dict(entry)

            self._persist_download_entry(snapshot)
            payload = self._download_payload(snapshot)
            payload["timestamp"] = utc_now_iso()
            return payload

        result = self.bridge.run(_decide_ui, timeout=10.0)
        self._record_action(
            "download_decision",
            {
                "download_id": download_id,
                "accept": bool(accept),
                "status": result.get("status") if isinstance(result, dict) else None,
            },
        )
        return result

    def cancel_download(self, download_id: str) -> Dict[str, Any]:
        return self.decide_download(download_id=download_id, accept=False)

    def get_persistent_history(self, limit: int = 200, search: Optional[str] = None) -> Dict[str, Any]:
        rows = self.store.list_history(limit=limit, search=search)
        return {
            "count": len(rows),
            "history": rows,
            "db_path": str(self.store.db_path),
            "timestamp": utc_now_iso(),
        }

    def clear_persistent_history(self) -> Dict[str, Any]:
        cleared = self.store.clear_history()
        self._record_action("clear_persistent_history", {"cleared": cleared})
        return {
            "cleared": cleared,
            "db_path": str(self.store.db_path),
            "timestamp": utc_now_iso(),
        }

    def persistent_kv_set(self, key: str, value: Any) -> Dict[str, Any]:
        record = self.persistent_kv_store.set(key=key, value=value)
        self._record_action("persistent_kv_set", {"key": key})
        return {
            "ok": True,
            "store": "persistent",
            "path": str(self.persistent_kv_store.path),
            "record": record,
            "timestamp": utc_now_iso(),
        }

    def persistent_kv_get(self, key: str, default: Any = None) -> Dict[str, Any]:
        record = self.persistent_kv_store.get(key=key)
        found = record is not None
        self._record_action("persistent_kv_get", {"key": key, "found": found})
        return {
            "found": found,
            "store": "persistent",
            "path": str(self.persistent_kv_store.path),
            "record": record,
            "value": record.get("value") if record else default,
            "timestamp": utc_now_iso(),
        }

    def persistent_kv_delete(self, key: str) -> Dict[str, Any]:
        deleted = self.persistent_kv_store.delete(key=key)
        self._record_action("persistent_kv_delete", {"key": key, "deleted": deleted})
        return {
            "deleted": bool(deleted),
            "store": "persistent",
            "path": str(self.persistent_kv_store.path),
            "timestamp": utc_now_iso(),
        }

    def persistent_kv_list(self, prefix: Optional[str] = None, limit: int = 500) -> Dict[str, Any]:
        rows = self.persistent_kv_store.list(prefix=prefix, limit=limit)
        return {
            "count": len(rows),
            "store": "persistent",
            "path": str(self.persistent_kv_store.path),
            "items": rows,
            "timestamp": utc_now_iso(),
        }

    def persistent_kv_query(
        self,
        contains: Optional[str] = None,
        key_regex: Optional[str] = None,
        value_regex: Optional[str] = None,
        limit: int = 200,
    ) -> Dict[str, Any]:
        rows = self.persistent_kv_store.query(
            contains=contains,
            key_regex=key_regex,
            value_regex=value_regex,
            limit=limit,
        )
        return {
            "count": len(rows),
            "store": "persistent",
            "path": str(self.persistent_kv_store.path),
            "items": rows,
            "timestamp": utc_now_iso(),
        }

    def persistent_kv_clear(self, prefix: Optional[str] = None) -> Dict[str, Any]:
        cleared = self.persistent_kv_store.clear(prefix=prefix)
        self._record_action("persistent_kv_clear", {"prefix": prefix, "cleared": cleared})
        return {
            "cleared": int(cleared),
            "store": "persistent",
            "path": str(self.persistent_kv_store.path),
            "timestamp": utc_now_iso(),
        }

    def memory_kv_set(self, key: str, value: Any) -> Dict[str, Any]:
        record = self.memory_kv_store.set(key=key, value=value)
        self._record_action("memory_kv_set", {"key": key})
        return {
            "ok": True,
            "store": "memory",
            "record": record,
            "timestamp": utc_now_iso(),
        }

    def memory_kv_get(self, key: str, default: Any = None) -> Dict[str, Any]:
        record = self.memory_kv_store.get(key=key)
        found = record is not None
        self._record_action("memory_kv_get", {"key": key, "found": found})
        return {
            "found": found,
            "store": "memory",
            "record": record,
            "value": record.get("value") if record else default,
            "timestamp": utc_now_iso(),
        }

    def memory_kv_delete(self, key: str) -> Dict[str, Any]:
        deleted = self.memory_kv_store.delete(key=key)
        self._record_action("memory_kv_delete", {"key": key, "deleted": deleted})
        return {
            "deleted": bool(deleted),
            "store": "memory",
            "timestamp": utc_now_iso(),
        }

    def memory_kv_list(self, prefix: Optional[str] = None, limit: int = 500) -> Dict[str, Any]:
        rows = self.memory_kv_store.list(prefix=prefix, limit=limit)
        return {
            "count": len(rows),
            "store": "memory",
            "items": rows,
            "timestamp": utc_now_iso(),
        }

    def memory_kv_query(
        self,
        contains: Optional[str] = None,
        key_regex: Optional[str] = None,
        value_regex: Optional[str] = None,
        limit: int = 200,
    ) -> Dict[str, Any]:
        rows = self.memory_kv_store.query(
            contains=contains,
            key_regex=key_regex,
            value_regex=value_regex,
            limit=limit,
        )
        return {
            "count": len(rows),
            "store": "memory",
            "items": rows,
            "timestamp": utc_now_iso(),
        }

    def memory_kv_clear(self, prefix: Optional[str] = None) -> Dict[str, Any]:
        cleared = self.memory_kv_store.clear(prefix=prefix)
        self._record_action("memory_kv_clear", {"prefix": prefix, "cleared": cleared})
        return {
            "cleared": int(cleared),
            "store": "memory",
            "timestamp": utc_now_iso(),
        }

    # Legacy aliases preserved for backwards compatibility.
    def kv_set(self, key: str, value: Any) -> Dict[str, Any]:
        return self.persistent_kv_set(key=key, value=value)

    def kv_get(self, key: str, default: Any = None) -> Dict[str, Any]:
        return self.persistent_kv_get(key=key, default=default)

    def kv_delete(self, key: str) -> Dict[str, Any]:
        return self.persistent_kv_delete(key=key)

    def kv_list(self, prefix: Optional[str] = None, limit: int = 500) -> Dict[str, Any]:
        return self.persistent_kv_list(prefix=prefix, limit=limit)

    def kv_query(
        self,
        contains: Optional[str] = None,
        key_regex: Optional[str] = None,
        value_regex: Optional[str] = None,
        limit: int = 200,
    ) -> Dict[str, Any]:
        return self.persistent_kv_query(
            contains=contains,
            key_regex=key_regex,
            value_regex=value_regex,
            limit=limit,
        )

    def get_action_history(self, limit: int = 200, action: Optional[str] = None, clear: bool = False) -> Dict[str, Any]:
        with self._action_history_lock:
            all_items = list(self._action_history)
            if action:
                all_items = [item for item in all_items if item.get("action") == action]
            data = all_items[-max(1, int(limit)) :]
            if clear:
                self._action_history.clear()

        return {
            "count": len(data),
            "events": data,
            "timestamp": utc_now_iso(),
        }

    def clear_action_history(self) -> Dict[str, Any]:
        with self._action_history_lock:
            cleared = len(self._action_history)
            self._action_history.clear()

        return {
            "cleared": cleared,
            "timestamp": utc_now_iso(),
        }

    def snapshot(
        self,
        selector: str = "body",
        max_depth: int = 2,
        max_children: int = 20,
        max_text: int = 240,
        include_console_logs: bool = True,
        console_limit: int = 100,
        include_navigation_history: bool = True,
        navigation_limit: int = 120,
        include_action_history: bool = True,
        action_limit: int = 120,
        include_tabs: bool = True,
        include_downloads: bool = True,
        download_limit: int = 120,
        include_persistent_history: bool = True,
        persistent_history_limit: int = 120,
        include_kv_store: bool = True,
        kv_limit: int = 120,
        include_memory_kv_store: bool = True,
        memory_kv_limit: int = 120,
        include_screenshot: bool = False,
        screenshot_path: Optional[str] = None,
        screenshot_base64: bool = False,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "state": self.state(),
            "dom_tree": self.describe_dom_tree(
                selector=selector,
                max_depth=max_depth,
                max_children=max_children,
                max_text=max_text,
            ),
            "timestamp": utc_now_iso(),
        }

        if include_console_logs:
            payload["console_logs"] = self.get_console_logs(limit=console_limit, clear=False)

        if include_navigation_history:
            payload["navigation_history"] = self.get_navigation_history(limit=navigation_limit)

        if include_action_history:
            payload["action_history"] = self.get_action_history(limit=action_limit, clear=False)

        if include_tabs:
            payload["tabs"] = self.tabs_list()

        if include_downloads:
            payload["downloads"] = self.list_downloads(limit=download_limit)

        if include_persistent_history:
            payload["persistent_history"] = self.get_persistent_history(limit=persistent_history_limit)

        if include_kv_store:
            persistent_kv_payload = self.persistent_kv_list(limit=kv_limit)
            payload["kv_store"] = persistent_kv_payload
            payload["persistent_kv_store"] = persistent_kv_payload

        if include_memory_kv_store:
            payload["memory_kv_store"] = self.memory_kv_list(limit=memory_kv_limit)

        if include_screenshot:
            payload["screenshot"] = self.capture_screenshot(path=screenshot_path, include_base64=screenshot_base64)

        self._record_action(
            "snapshot",
            {
                "selector": selector,
                "include_console_logs": bool(include_console_logs),
                "include_navigation_history": bool(include_navigation_history),
                "include_action_history": bool(include_action_history),
                "include_tabs": bool(include_tabs),
                "include_downloads": bool(include_downloads),
                "include_persistent_history": bool(include_persistent_history),
                "include_kv_store": bool(include_kv_store),
                "include_memory_kv_store": bool(include_memory_kv_store),
                "include_screenshot": bool(include_screenshot),
            },
        )
        return payload

    def capture_screenshot(self, path: Optional[str] = None, include_base64: bool = False) -> Dict[str, Any]:
        if path:
            target = Path(path)
        else:
            target = self.screenshot_dir / f"shot-{int(time.time() * 1000)}.png"

        def _capture_ui() -> Dict[str, str]:
            target.parent.mkdir(parents=True, exist_ok=True)

            # In headed mode, prefer the real OS window capture so screenshots match what the user sees.
            platform = os.getenv("QT_QPA_PLATFORM", "").lower()
            can_capture_window = self._show_window and self.window.isVisible() and platform != "offscreen"

            pixmap = None
            capture_source = "view"

            if can_capture_window:
                self.app.processEvents()
                window = self.window
                window_handle = window.windowHandle() if window else None
                screen = window_handle.screen() if window_handle else self.app.primaryScreen()
                window_id = int(window.winId()) if window else 0

                if screen and window_id:
                    candidate = screen.grabWindow(window_id)
                    if not candidate.isNull():
                        pixmap = candidate
                        capture_source = "window"

            if pixmap is None:
                current = self._current_tab_ui()
                candidate = current.view.grab() if current is not None else None
                if candidate is not None and not candidate.isNull():
                    pixmap = candidate
                    capture_source = "view"

            if pixmap is None or pixmap.isNull():
                raise RuntimeError("Capture failed: browser surface is empty")

            saved = pixmap.save(str(target), "PNG")
            if not saved:
                raise RuntimeError(f"Could not save screenshot to {target}")
            return {
                "path": str(target.resolve()),
                "capture_source": capture_source,
            }

        capture_result = self.bridge.run(_capture_ui, timeout=10.0)
        screenshot_path = capture_result["path"]
        payload: Dict[str, Any] = {
            "path": screenshot_path,
            "capture_source": capture_result.get("capture_source", "view"),
            "timestamp": utc_now_iso(),
            "state": self.state(),
        }

        if include_base64:
            png_bytes = Path(screenshot_path).read_bytes()
            payload["base64_png"] = base64.b64encode(png_bytes).decode("ascii")

        self._record_action(
            "capture_screenshot",
            {
                "path": screenshot_path,
                "capture_source": payload.get("capture_source"),
                "include_base64": bool(include_base64),
            },
        )
        return payload

    def get_console_logs(self, limit: int = 200, clear: bool = False) -> Dict[str, Any]:
        with self._logs_lock:
            data = list(self._logs)[-max(1, int(limit)) :]
            if clear:
                self._logs.clear()

        return {
            "count": len(data),
            "logs": data,
            "timestamp": utc_now_iso(),
        }

    def clear_console_logs(self) -> Dict[str, Any]:
        with self._logs_lock:
            cleared = len(self._logs)
            self._logs.clear()
        self._record_action("clear_console_logs", {"cleared": cleared})
        return {
            "cleared": cleared,
            "timestamp": utc_now_iso(),
        }

    def set_window_visibility(self, visible: bool) -> Dict[str, Any]:
        def _set_ui() -> Dict[str, Any]:
            if visible:
                self.window.show()
                self.window.raise_()
                self.window.activateWindow()
            else:
                self.window.hide()

            current = self._current_tab_ui()
            if current is None:
                return {
                    "visible": self.window.isVisible(),
                    "url": "",
                    "title": "",
                    "loading": False,
                    "can_go_back": False,
                    "can_go_forward": False,
                    "current_tab_id": None,
                    "timestamp": utc_now_iso(),
                }
            history = current.page.history()
            return {
                "visible": self.window.isVisible(),
                "url": current.view.url().toString(),
                "title": current.view.title(),
                "loading": current.is_loading,
                "can_go_back": history.canGoBack(),
                "can_go_forward": history.canGoForward(),
                "current_tab_id": current.tab_id,
                "timestamp": utc_now_iso(),
            }

        result = self.bridge.run(_set_ui, timeout=5.0)
        self._record_action(
            "set_window_visibility",
            {
                "visible": bool(result.get("visible")),
                "url": result.get("url"),
            },
        )
        return result

    def stop(self) -> None:
        try:
            self.store.close()
        except Exception:
            pass
        try:
            self.bridge.run(lambda: self.app.quit(), timeout=3.0)
        except Exception:
            pass

    def exec_forever(self) -> int:
        return int(self.app.exec_())


def build_mcp_server(runtime: BrowserRuntime) -> FastMCP:
    server = FastMCP("browser_use")

    @server.tool()
    def browser_state() -> Dict[str, Any]:
        """Return current URL, title, load state, and navigation capabilities."""
        return runtime.state()

    @server.tool()
    def browser_navigate(url: str, timeout_ms: int = 20000) -> Dict[str, Any]:
        """Navigate to a URL and wait for loadFinished."""
        return runtime.navigate(url=url, timeout_ms=timeout_ms)

    @server.tool()
    def browser_tabs_list() -> Dict[str, Any]:
        """Return all open tabs with id/index/title/url and current tab pointer."""
        return runtime.tabs_list()

    @server.tool()
    def browser_tab_new(url: str = "about:blank", make_active: bool = True) -> Dict[str, Any]:
        """Open a new tab and optionally activate it."""
        return runtime.new_tab(url=url, make_active=make_active)

    @server.tool()
    def browser_tab_switch(tab_id: int) -> Dict[str, Any]:
        """Switch current context to tab_id."""
        return runtime.switch_tab(tab_id=tab_id)

    @server.tool()
    def browser_tab_close(tab_id: Optional[int] = None) -> Dict[str, Any]:
        """Close a tab by id (or current tab if omitted)."""
        return runtime.close_tab(tab_id=tab_id)

    @server.tool()
    def browser_wait_for_url(
        pattern: str,
        timeout_ms: int = 15000,
        poll_ms: int = 150,
        regex: bool = False,
        ignore_case: bool = True,
        invert_match: bool = False,
    ) -> Dict[str, Any]:
        """Poll until current URL matches (or no longer matches) a text/regex pattern."""
        return runtime.wait_for_url(
            pattern=pattern,
            timeout_ms=timeout_ms,
            poll_ms=poll_ms,
            regex=regex,
            ignore_case=ignore_case,
            invert_match=invert_match,
        )

    @server.tool()
    def browser_go_back(steps: int = 1, timeout_ms: int = 20000) -> Dict[str, Any]:
        """Navigate back in browser history by one or more steps."""
        return runtime.go_back(steps=steps, timeout_ms=timeout_ms)

    @server.tool()
    def browser_go_forward(steps: int = 1, timeout_ms: int = 20000) -> Dict[str, Any]:
        """Navigate forward in browser history by one or more steps."""
        return runtime.go_forward(steps=steps, timeout_ms=timeout_ms)

    @server.tool()
    def browser_reload(timeout_ms: int = 20000, bypass_cache: bool = False) -> Dict[str, Any]:
        """Reload current page and wait for completion."""
        return runtime.reload(timeout_ms=timeout_ms, bypass_cache=bypass_cache)

    @server.tool()
    def browser_get_navigation_history(limit: int = 200) -> Dict[str, Any]:
        """Return browser navigation history entries with current index and URLs."""
        return runtime.get_navigation_history(limit=limit)

    @server.tool()
    def browser_get_action_history(limit: int = 200, action: Optional[str] = None, clear: bool = False) -> Dict[str, Any]:
        """Return tool-level action history (navigate/click/type/waits/screenshots/etc.)."""
        return runtime.get_action_history(limit=limit, action=action, clear=clear)

    @server.tool()
    def browser_clear_action_history() -> Dict[str, Any]:
        """Clear tool-level action history."""
        return runtime.clear_action_history()

    @server.tool()
    def browser_get_downloads(limit: int = 300, status: Optional[str] = None) -> Dict[str, Any]:
        """List download records (persisted in SQLite) with status/decision/progress."""
        return runtime.list_downloads(limit=limit, status=status)

    @server.tool()
    def browser_decide_download(download_id: str, accept: bool, path: Optional[str] = None) -> Dict[str, Any]:
        """Accept or reject a pending download. Optional custom path when accept=true."""
        return runtime.decide_download(download_id=download_id, accept=accept, path=path)

    @server.tool()
    def browser_cancel_download(download_id: str) -> Dict[str, Any]:
        """Cancel/reject a download by id."""
        return runtime.cancel_download(download_id=download_id)

    @server.tool()
    def browser_get_persistent_history(limit: int = 200, search: Optional[str] = None) -> Dict[str, Any]:
        """Return SQLite-backed browsing history (URL/title/visit_count/last visit time)."""
        return runtime.get_persistent_history(limit=limit, search=search)

    @server.tool()
    def browser_clear_persistent_history() -> Dict[str, Any]:
        """Clear SQLite-backed browsing history."""
        return runtime.clear_persistent_history()

    @server.tool()
    def browser_persist_kv_set(key: str, value: Any) -> Dict[str, Any]:
        """Set a JSON-serializable key/value entry in persistent local memory (disk JSON)."""
        return runtime.persistent_kv_set(key=key, value=value)

    @server.tool()
    def browser_persist_kv_get(key: str, default: Any = None) -> Dict[str, Any]:
        """Get a key from persistent local memory (disk JSON)."""
        return runtime.persistent_kv_get(key=key, default=default)

    @server.tool()
    def browser_persist_kv_delete(key: str) -> Dict[str, Any]:
        """Delete a key from persistent local memory (disk JSON)."""
        return runtime.persistent_kv_delete(key=key)

    @server.tool()
    def browser_persist_kv_list(prefix: Optional[str] = None, limit: int = 500) -> Dict[str, Any]:
        """List persistent key/value records, optionally filtered by key prefix."""
        return runtime.persistent_kv_list(prefix=prefix, limit=limit)

    @server.tool()
    def browser_persist_kv_query(
        contains: Optional[str] = None,
        key_regex: Optional[str] = None,
        value_regex: Optional[str] = None,
        limit: int = 200,
    ) -> Dict[str, Any]:
        """Query persistent key/value memory by contains and/or regex filters."""
        return runtime.persistent_kv_query(
            contains=contains,
            key_regex=key_regex,
            value_regex=value_regex,
            limit=limit,
        )

    @server.tool()
    def browser_persist_kv_clear(prefix: Optional[str] = None) -> Dict[str, Any]:
        """Clear persistent key/value records. Use prefix for scoped cleanup."""
        return runtime.persistent_kv_clear(prefix=prefix)

    @server.tool()
    def browser_mem_kv_set(key: str, value: Any) -> Dict[str, Any]:
        """Set a JSON-serializable key/value entry in process memory (non-persistent)."""
        return runtime.memory_kv_set(key=key, value=value)

    @server.tool()
    def browser_mem_kv_get(key: str, default: Any = None) -> Dict[str, Any]:
        """Get a key from process memory (non-persistent)."""
        return runtime.memory_kv_get(key=key, default=default)

    @server.tool()
    def browser_mem_kv_delete(key: str) -> Dict[str, Any]:
        """Delete a key from process memory (non-persistent)."""
        return runtime.memory_kv_delete(key=key)

    @server.tool()
    def browser_mem_kv_list(prefix: Optional[str] = None, limit: int = 500) -> Dict[str, Any]:
        """List process-memory key/value records, optionally filtered by key prefix."""
        return runtime.memory_kv_list(prefix=prefix, limit=limit)

    @server.tool()
    def browser_mem_kv_query(
        contains: Optional[str] = None,
        key_regex: Optional[str] = None,
        value_regex: Optional[str] = None,
        limit: int = 200,
    ) -> Dict[str, Any]:
        """Query process-memory key/value entries by contains and/or regex filters."""
        return runtime.memory_kv_query(
            contains=contains,
            key_regex=key_regex,
            value_regex=value_regex,
            limit=limit,
        )

    @server.tool()
    def browser_mem_kv_clear(prefix: Optional[str] = None) -> Dict[str, Any]:
        """Clear process-memory key/value records. Use prefix for scoped cleanup."""
        return runtime.memory_kv_clear(prefix=prefix)

    @server.tool()
    def browser_kv_set(key: str, value: Any) -> Dict[str, Any]:
        """Legacy alias for persistent key/value set (equivalent to browser_persist_kv_set)."""
        return runtime.persistent_kv_set(key=key, value=value)

    @server.tool()
    def browser_kv_get(key: str, default: Any = None) -> Dict[str, Any]:
        """Legacy alias for persistent key/value get (equivalent to browser_persist_kv_get)."""
        return runtime.persistent_kv_get(key=key, default=default)

    @server.tool()
    def browser_kv_delete(key: str) -> Dict[str, Any]:
        """Legacy alias for persistent key/value delete (equivalent to browser_persist_kv_delete)."""
        return runtime.persistent_kv_delete(key=key)

    @server.tool()
    def browser_kv_list(prefix: Optional[str] = None, limit: int = 500) -> Dict[str, Any]:
        """Legacy alias for persistent key/value list (equivalent to browser_persist_kv_list)."""
        return runtime.persistent_kv_list(prefix=prefix, limit=limit)

    @server.tool()
    def browser_kv_query(
        contains: Optional[str] = None,
        key_regex: Optional[str] = None,
        value_regex: Optional[str] = None,
        limit: int = 200,
    ) -> Dict[str, Any]:
        """Legacy alias for persistent key/value query (equivalent to browser_persist_kv_query)."""
        return runtime.persistent_kv_query(
            contains=contains,
            key_regex=key_regex,
            value_regex=value_regex,
            limit=limit,
        )

    @server.tool()
    def browser_get_dom(selector: str = "html", index: int = 0, include_html: bool = True) -> Dict[str, Any]:
        """Return DOM info for a selector including tag/id/classes/text/value and optional HTML."""
        return runtime.get_dom(selector=selector, index=index, include_html=include_html)

    @server.tool()
    def browser_describe_dom_tree(
        selector: str = "body",
        max_depth: int = 2,
        max_children: int = 20,
        max_text: int = 240,
    ) -> Dict[str, Any]:
        """Return a compact, recursive DOM tree snapshot from a root selector."""
        return runtime.describe_dom_tree(
            selector=selector,
            max_depth=max_depth,
            max_children=max_children,
            max_text=max_text,
        )

    @server.tool()
    def browser_query_selector_all(selector: str, limit: int = 25) -> Dict[str, Any]:
        """List matching nodes for a CSS selector with compact metadata."""
        return runtime.query_selector_all(selector=selector, limit=limit)

    @server.tool()
    def browser_list_interactive_elements(limit: int = 200, include_hidden: bool = False) -> Dict[str, Any]:
        """List clickable/editable elements with selector hints for fast agent action planning."""
        return runtime.list_interactive_elements(limit=limit, include_hidden=include_hidden)

    @server.tool()
    def browser_click(selector: str, index: int = 0) -> Dict[str, Any]:
        """Click an element by CSS selector and index."""
        return runtime.click(selector=selector, index=index)

    @server.tool()
    def browser_type_text(
        selector: str,
        text: str,
        index: int = 0,
        clear_first: bool = True,
        submit: bool = False,
    ) -> Dict[str, Any]:
        """Type into an input/textarea/contenteditable node and optionally submit."""
        return runtime.type_text(
            selector=selector,
            text=text,
            index=index,
            clear_first=clear_first,
            submit=submit,
        )

    @server.tool()
    def browser_wait_for_selector(selector: str, timeout_ms: int = 8000, poll_ms: int = 150) -> Dict[str, Any]:
        """Poll until a selector appears or timeout expires."""
        return runtime.wait_for_selector(selector=selector, timeout_ms=timeout_ms, poll_ms=poll_ms)

    @server.tool()
    def browser_eval_js(script: str, timeout_ms: int = 15000) -> Any:
        """Execute JavaScript in page context and return serializable result."""
        return runtime.eval_js(script=script, timeout_ms=timeout_ms)

    @server.tool()
    def browser_capture_screenshot(path: Optional[str] = None, include_base64: bool = False) -> Dict[str, Any]:
        """Capture viewport screenshot. Set include_base64=true if the agent needs inline image bytes."""
        return runtime.capture_screenshot(path=path, include_base64=include_base64)

    @server.tool()
    def browser_get_console_logs(limit: int = 200, clear: bool = False) -> Dict[str, Any]:
        """Return captured JavaScript console logs."""
        return runtime.get_console_logs(limit=limit, clear=clear)

    @server.tool()
    def browser_clear_console_logs() -> Dict[str, Any]:
        """Clear captured JavaScript console logs."""
        return runtime.clear_console_logs()

    @server.tool()
    def browser_set_window_visibility(visible: bool) -> Dict[str, Any]:
        """Show or hide the live browser window (useful for realtime desktop sessions)."""
        return runtime.set_window_visibility(visible=visible)

    @server.tool()
    def browser_snapshot(
        selector: str = "body",
        max_depth: int = 2,
        max_children: int = 20,
        max_text: int = 240,
        include_console_logs: bool = True,
        console_limit: int = 100,
        include_navigation_history: bool = True,
        navigation_limit: int = 120,
        include_action_history: bool = True,
        action_limit: int = 120,
        include_tabs: bool = True,
        include_downloads: bool = True,
        download_limit: int = 120,
        include_persistent_history: bool = True,
        persistent_history_limit: int = 120,
        include_kv_store: bool = True,
        kv_limit: int = 120,
        include_memory_kv_store: bool = True,
        memory_kv_limit: int = 120,
        include_screenshot: bool = False,
        screenshot_path: Optional[str] = None,
        screenshot_base64: bool = False,
    ) -> Dict[str, Any]:
        """Single-call page snapshot for agents: state + DOM tree + logs + histories (+ optional screenshot)."""
        return runtime.snapshot(
            selector=selector,
            max_depth=max_depth,
            max_children=max_children,
            max_text=max_text,
            include_console_logs=include_console_logs,
            console_limit=console_limit,
            include_navigation_history=include_navigation_history,
            navigation_limit=navigation_limit,
            include_action_history=include_action_history,
            action_limit=action_limit,
            include_tabs=include_tabs,
            include_downloads=include_downloads,
            download_limit=download_limit,
            include_persistent_history=include_persistent_history,
            persistent_history_limit=persistent_history_limit,
            include_kv_store=include_kv_store,
            kv_limit=kv_limit,
            include_memory_kv_store=include_memory_kv_store,
            memory_kv_limit=memory_kv_limit,
            include_screenshot=include_screenshot,
            screenshot_path=screenshot_path,
            screenshot_base64=screenshot_base64,
        )

    return server


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="browser_use MCP server")
    parser.add_argument(
        "--mode",
        choices=("auto", "headed", "headless"),
        default="auto",
        help="Runtime mode. auto=headed on desktop, headless in CI.",
    )
    parser.add_argument("--url", default="about:blank", help="Initial URL")
    parser.add_argument("--headless", action="store_true", help="Run Qt with offscreen platform")
    parser.add_argument("--hide-window", action="store_true", help="Do not show the browser window")
    parser.add_argument(
        "--screenshot-dir",
        default="",
        help="Directory where screenshots are saved (default: package-local screenshots)",
    )
    parser.add_argument(
        "--profile-dir",
        default="",
        help="Directory used for browser profile storage (default: package-local profile)",
    )
    parser.add_argument(
        "--downloads-dir",
        default="",
        help="Directory where accepted downloads are written (default: package-local data/downloads)",
    )
    parser.add_argument(
        "--db-path",
        default="",
        help="SQLite DB path for persistent history/download metadata (default: package-local data/browser.sqlite3)",
    )
    parser.add_argument(
        "--kv-path",
        default="",
        help="Persistent JSON key/value store path (default: package-local data/kv_store.json)",
    )
    parser.add_argument("--width", type=int, default=1365, help="Initial viewport width")
    parser.add_argument("--height", type=int, default=900, help="Initial viewport height")
    parser.add_argument("--max-console-logs", type=int, default=1500, help="Max console log entries in memory")
    parser.add_argument("--max-action-history", type=int, default=3000, help="Max action history entries in memory")
    parser.add_argument(
        "--boot-check-seconds",
        type=int,
        default=0,
        help="Run for N seconds then quit (for local health checks)",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    _debug(
        "starting",
    )

    resolved_headless = False
    if args.mode == "headless":
        resolved_headless = True
    elif args.mode == "headed":
        resolved_headless = False
    else:
        resolved_headless = is_ci_environment()

    # Backward-compatible override.
    if args.headless:
        resolved_headless = True

    if resolved_headless:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

    os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")

    package_dir = Path(__file__).resolve().parent
    data_dir = package_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    screenshot_dir = (
        Path(args.screenshot_dir).expanduser().resolve()
        if str(args.screenshot_dir).strip()
        else (package_dir / "screenshots")
    )
    profile_dir = (
        Path(args.profile_dir).expanduser().resolve()
        if str(args.profile_dir).strip()
        else (package_dir / "profile")
    )
    db_path = Path(args.db_path).expanduser().resolve() if str(args.db_path).strip() else (data_dir / "browser.sqlite3")
    downloads_dir = (
        Path(args.downloads_dir).expanduser().resolve()
        if str(args.downloads_dir).strip()
        else (data_dir / "downloads")
    )
    kv_path = Path(args.kv_path).expanduser().resolve() if str(args.kv_path).strip() else (data_dir / "kv_store.json")

    _debug("initializing Qt runtime")
    runtime = BrowserRuntime(
        start_url=args.url,
        show_window=not (resolved_headless or args.hide_window),
        screenshot_dir=screenshot_dir,
        profile_dir=profile_dir,
        downloads_dir=downloads_dir,
        db_path=db_path,
        kv_path=kv_path,
        max_console_logs=max(100, int(args.max_console_logs)),
        max_action_history=max(200, int(args.max_action_history)),
        width=max(640, int(args.width)),
        height=max(480, int(args.height)),
    )
    _debug(f"Qt runtime ready (show_window={not (resolved_headless or args.hide_window)})")

    mcp_server = build_mcp_server(runtime)
    _debug("FastMCP built")

    def run_mcp() -> None:
        try:
            _debug("MCP stdio server starting")
            mcp_server.run(transport="stdio")
        finally:
            _debug("MCP stdio server stopped; quitting Qt")
            runtime.stop()

    mcp_thread = threading.Thread(target=run_mcp, name="mcp-stdio", daemon=True)
    mcp_thread.start()

    if args.boot_check_seconds > 0:
        timer = QTimer()
        timer.setSingleShot(True)
        timer.timeout.connect(runtime.stop)
        timer.start(max(1, int(args.boot_check_seconds)) * 1000)

    return runtime.exec_forever()


if __name__ == "__main__":
    raise SystemExit(main())
