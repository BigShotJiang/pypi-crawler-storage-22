from __future__ import annotations

import json
import re
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class BrowserStore:
    """Tiny SQLite-backed persistence layer for history/downloads."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._migrate()

    def _migrate(self) -> None:
        with self._lock:
            cur = self._conn.cursor()
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT DEFAULT '',
                    url TEXT NOT NULL UNIQUE,
                    visit_time TEXT NOT NULL,
                    visit_count INTEGER NOT NULL DEFAULT 1,
                    last_tab_id INTEGER
                )
                """
            )
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS downloads (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    download_token TEXT NOT NULL UNIQUE,
                    tab_id INTEGER,
                    url TEXT,
                    suggested_file_name TEXT,
                    target_path TEXT,
                    status TEXT NOT NULL DEFAULT 'pending',
                    decision TEXT NOT NULL DEFAULT 'pending',
                    received_bytes INTEGER NOT NULL DEFAULT 0,
                    total_bytes INTEGER NOT NULL DEFAULT 0,
                    error TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            cur.execute("CREATE INDEX IF NOT EXISTS idx_history_visit_time ON history(visit_time DESC)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_downloads_updated_at ON downloads(updated_at DESC)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_downloads_status ON downloads(status)")
            self._conn.commit()

    @staticmethod
    def _rows_to_dicts(rows: List[sqlite3.Row]) -> List[Dict[str, Any]]:
        return [dict(row) for row in rows]

    def record_visit(self, title: str, url: str, visit_time: str, tab_id: Optional[int]) -> Dict[str, Any]:
        safe_title = str(title or "")
        safe_url = str(url or "").strip()
        if not safe_url:
            raise ValueError("url cannot be empty")

        with self._lock:
            cur = self._conn.cursor()
            existing = cur.execute("SELECT id, visit_count FROM history WHERE url = ?", (safe_url,)).fetchone()
            if existing:
                cur.execute(
                    """
                    UPDATE history
                    SET title = ?, visit_time = ?, visit_count = ?, last_tab_id = ?
                    WHERE id = ?
                    """,
                    (
                        safe_title,
                        visit_time,
                        int(existing["visit_count"]) + 1,
                        tab_id,
                        int(existing["id"]),
                    ),
                )
            else:
                cur.execute(
                    """
                    INSERT INTO history (title, url, visit_time, visit_count, last_tab_id)
                    VALUES (?, ?, ?, 1, ?)
                    """,
                    (safe_title, safe_url, visit_time, tab_id),
                )
            self._conn.commit()
            row = cur.execute("SELECT * FROM history WHERE url = ?", (safe_url,)).fetchone()
            return dict(row) if row else {}

    def list_history(self, limit: int = 200, search: Optional[str] = None) -> List[Dict[str, Any]]:
        max_rows = max(1, int(limit))
        with self._lock:
            cur = self._conn.cursor()
            if search:
                pattern = f"%{search}%"
                rows = cur.execute(
                    """
                    SELECT * FROM history
                    WHERE url LIKE ? OR title LIKE ?
                    ORDER BY visit_time DESC
                    LIMIT ?
                    """,
                    (pattern, pattern, max_rows),
                ).fetchall()
            else:
                rows = cur.execute(
                    "SELECT * FROM history ORDER BY visit_time DESC LIMIT ?",
                    (max_rows,),
                ).fetchall()
            return self._rows_to_dicts(rows)

    def clear_history(self) -> int:
        with self._lock:
            cur = self._conn.cursor()
            count_row = cur.execute("SELECT COUNT(*) AS c FROM history").fetchone()
            cleared = int(count_row["c"]) if count_row else 0
            cur.execute("DELETE FROM history")
            self._conn.commit()
            return cleared

    def upsert_download(
        self,
        token: str,
        tab_id: Optional[int],
        url: Optional[str],
        suggested_file_name: Optional[str],
        target_path: Optional[str],
        status: str,
        decision: str,
        created_at: str,
        updated_at: str,
        received_bytes: int = 0,
        total_bytes: int = 0,
        error: Optional[str] = None,
    ) -> Dict[str, Any]:
        with self._lock:
            cur = self._conn.cursor()
            existing = cur.execute(
                "SELECT id FROM downloads WHERE download_token = ?",
                (token,),
            ).fetchone()
            if existing:
                cur.execute(
                    """
                    UPDATE downloads
                    SET tab_id = ?,
                        url = ?,
                        suggested_file_name = ?,
                        target_path = ?,
                        status = ?,
                        decision = ?,
                        received_bytes = ?,
                        total_bytes = ?,
                        error = ?,
                        updated_at = ?
                    WHERE download_token = ?
                    """,
                    (
                        tab_id,
                        url,
                        suggested_file_name,
                        target_path,
                        status,
                        decision,
                        int(received_bytes),
                        int(total_bytes),
                        error,
                        updated_at,
                        token,
                    ),
                )
            else:
                cur.execute(
                    """
                    INSERT INTO downloads (
                        download_token,
                        tab_id,
                        url,
                        suggested_file_name,
                        target_path,
                        status,
                        decision,
                        received_bytes,
                        total_bytes,
                        error,
                        created_at,
                        updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        token,
                        tab_id,
                        url,
                        suggested_file_name,
                        target_path,
                        status,
                        decision,
                        int(received_bytes),
                        int(total_bytes),
                        error,
                        created_at,
                        updated_at,
                    ),
                )
            self._conn.commit()
            row = cur.execute(
                "SELECT * FROM downloads WHERE download_token = ?",
                (token,),
            ).fetchone()
            return dict(row) if row else {}

    def list_downloads(self, limit: int = 300, status: Optional[str] = None) -> List[Dict[str, Any]]:
        max_rows = max(1, int(limit))
        with self._lock:
            cur = self._conn.cursor()
            if status:
                rows = cur.execute(
                    """
                    SELECT * FROM downloads
                    WHERE status = ?
                    ORDER BY updated_at DESC
                    LIMIT ?
                    """,
                    (status, max_rows),
                ).fetchall()
            else:
                rows = cur.execute(
                    "SELECT * FROM downloads ORDER BY updated_at DESC LIMIT ?",
                    (max_rows,),
                ).fetchall()
            return self._rows_to_dicts(rows)

    def get_download(self, token: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            cur = self._conn.cursor()
            row = cur.execute(
                "SELECT * FROM downloads WHERE download_token = ?",
                (token,),
            ).fetchone()
            return dict(row) if row else None

    def close(self) -> None:
        with self._lock:
            self._conn.close()


class JsonKeyValueStore:
    """Simple JSON key-value store for agent scratch memory."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._data: Dict[str, Dict[str, Any]] = {}
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            self._save()
            return
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            payload = {}

        items = payload.get("items", {}) if isinstance(payload, dict) else {}
        if not isinstance(items, dict):
            items = {}

        normalized: Dict[str, Dict[str, Any]] = {}
        for key, item in items.items():
            if not isinstance(key, str):
                continue
            if isinstance(item, dict) and "value" in item:
                created_at = str(item.get("created_at") or utc_now_iso())
                updated_at = str(item.get("updated_at") or created_at)
                normalized[key] = {
                    "value": item.get("value"),
                    "created_at": created_at,
                    "updated_at": updated_at,
                }
            else:
                now = utc_now_iso()
                normalized[key] = {
                    "value": item,
                    "created_at": now,
                    "updated_at": now,
                }

        self._data = normalized
        self._save()

    def _save(self) -> None:
        payload = {
            "version": 1,
            "items": self._data,
        }
        self.path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def set(self, key: str, value: Any) -> Dict[str, Any]:
        safe_key = str(key or "").strip()
        if not safe_key:
            raise ValueError("key cannot be empty")
        # Ensure the value is JSON-serializable to keep the file consistent.
        json.loads(json.dumps(value))

        with self._lock:
            existing = self._data.get(safe_key)
            created_at = existing.get("created_at") if isinstance(existing, dict) else utc_now_iso()
            record = {
                "value": value,
                "created_at": created_at,
                "updated_at": utc_now_iso(),
            }
            self._data[safe_key] = record
            self._save()
            return {
                "key": safe_key,
                **record,
            }

    def get(self, key: str) -> Optional[Dict[str, Any]]:
        safe_key = str(key or "").strip()
        if not safe_key:
            return None
        with self._lock:
            record = self._data.get(safe_key)
            if not record:
                return None
            return {
                "key": safe_key,
                **record,
            }

    def delete(self, key: str) -> bool:
        safe_key = str(key or "").strip()
        if not safe_key:
            return False
        with self._lock:
            existed = safe_key in self._data
            if existed:
                del self._data[safe_key]
                self._save()
            return existed

    def list(self, prefix: Optional[str] = None, limit: int = 500) -> List[Dict[str, Any]]:
        max_rows = max(1, int(limit))
        with self._lock:
            keys = sorted(self._data.keys())
            if prefix:
                keys = [key for key in keys if key.startswith(prefix)]
            rows: List[Dict[str, Any]] = []
            for key in keys[:max_rows]:
                rows.append({"key": key, **self._data[key]})
            return rows

    def query(
        self,
        contains: Optional[str] = None,
        key_regex: Optional[str] = None,
        value_regex: Optional[str] = None,
        limit: int = 200,
    ) -> List[Dict[str, Any]]:
        max_rows = max(1, int(limit))
        contains_lc = contains.lower() if contains else None

        compiled_key: Optional[re.Pattern[str]] = re.compile(key_regex) if key_regex else None
        compiled_value: Optional[re.Pattern[str]] = re.compile(value_regex) if value_regex else None

        with self._lock:
            rows: List[Dict[str, Any]] = []
            for key in sorted(self._data.keys()):
                item = self._data[key]
                value_text = json.dumps(item.get("value"), ensure_ascii=False, sort_keys=True)
                key_match = compiled_key.search(key) is not None if compiled_key else True
                value_match = compiled_value.search(value_text) is not None if compiled_value else True
                contains_match = True
                if contains_lc:
                    contains_match = contains_lc in key.lower() or contains_lc in value_text.lower()
                if key_match and value_match and contains_match:
                    rows.append({"key": key, **item})
                if len(rows) >= max_rows:
                    break
            return rows

    def clear(self, prefix: Optional[str] = None) -> int:
        with self._lock:
            if prefix:
                keys = [key for key in self._data.keys() if key.startswith(prefix)]
            else:
                keys = list(self._data.keys())

            for key in keys:
                del self._data[key]

            if keys:
                self._save()
            return len(keys)


class InMemoryKeyValueStore:
    """Process-lifetime key-value memory that is not written to disk."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._data: Dict[str, Dict[str, Any]] = {}

    def set(self, key: str, value: Any) -> Dict[str, Any]:
        safe_key = str(key or "").strip()
        if not safe_key:
            raise ValueError("key cannot be empty")
        json.loads(json.dumps(value))

        with self._lock:
            existing = self._data.get(safe_key)
            created_at = existing.get("created_at") if isinstance(existing, dict) else utc_now_iso()
            record = {
                "value": value,
                "created_at": created_at,
                "updated_at": utc_now_iso(),
            }
            self._data[safe_key] = record
            return {
                "key": safe_key,
                **record,
            }

    def get(self, key: str) -> Optional[Dict[str, Any]]:
        safe_key = str(key or "").strip()
        if not safe_key:
            return None
        with self._lock:
            record = self._data.get(safe_key)
            if not record:
                return None
            return {
                "key": safe_key,
                **record,
            }

    def delete(self, key: str) -> bool:
        safe_key = str(key or "").strip()
        if not safe_key:
            return False
        with self._lock:
            existed = safe_key in self._data
            if existed:
                del self._data[safe_key]
            return existed

    def list(self, prefix: Optional[str] = None, limit: int = 500) -> List[Dict[str, Any]]:
        max_rows = max(1, int(limit))
        with self._lock:
            keys = sorted(self._data.keys())
            if prefix:
                keys = [key for key in keys if key.startswith(prefix)]
            rows: List[Dict[str, Any]] = []
            for key in keys[:max_rows]:
                rows.append({"key": key, **self._data[key]})
            return rows

    def query(
        self,
        contains: Optional[str] = None,
        key_regex: Optional[str] = None,
        value_regex: Optional[str] = None,
        limit: int = 200,
    ) -> List[Dict[str, Any]]:
        max_rows = max(1, int(limit))
        contains_lc = contains.lower() if contains else None

        compiled_key: Optional[re.Pattern[str]] = re.compile(key_regex) if key_regex else None
        compiled_value: Optional[re.Pattern[str]] = re.compile(value_regex) if value_regex else None

        with self._lock:
            rows: List[Dict[str, Any]] = []
            for key in sorted(self._data.keys()):
                item = self._data[key]
                value_text = json.dumps(item.get("value"), ensure_ascii=False, sort_keys=True)
                key_match = compiled_key.search(key) is not None if compiled_key else True
                value_match = compiled_value.search(value_text) is not None if compiled_value else True
                contains_match = True
                if contains_lc:
                    contains_match = contains_lc in key.lower() or contains_lc in value_text.lower()
                if key_match and value_match and contains_match:
                    rows.append({"key": key, **item})
                if len(rows) >= max_rows:
                    break
            return rows

    def clear(self, prefix: Optional[str] = None) -> int:
        with self._lock:
            if prefix:
                keys = [key for key in self._data.keys() if key.startswith(prefix)]
            else:
                keys = list(self._data.keys())

            for key in keys:
                del self._data[key]
            return len(keys)
