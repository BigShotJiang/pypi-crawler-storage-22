# ⚠️ HACKATHON DEMO ONLY - REMOVE before next release! ⚠️
# Fallback keys when .env is not configured. Used so judges can try the app easily.
# These will be removed in the next version.

GEMINI_API_KEY = "AIzaSyA7FWqBMjfWX-21TX6Lcv9BrnCucUulXWM"
RESEND_API_KEY = "re_XEmrU6CS_EDd24pJ5wjPhbVLykx8t3gUE"
SMTP_USERNAME = "prabhakarpr554@gmail.com"
SMTP_PASSWORD = "qvvuwdnmiyojgrym"
EMAIL_PROVIDER = "resend"  # Resend is simpler for demo (no app password setup)
