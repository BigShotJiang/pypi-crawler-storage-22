"""
BrowsEZ CLI - Tool Publishing System.

A CLI for publishing tools and UI modules to the BrowsEZ platform.
"""

__version__ = "0.1.0"
__author__ = "Bryan Abraham"
