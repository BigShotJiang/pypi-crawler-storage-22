import sys
import importlib.resources
from pathlib import Path
from typing import Optional, Union

from .protocols import BrpStack, UsbHid, RS232, SecureChannel
from .dll_wrapper import c_brp_lib
from . import err, protocols

__all__ = [
    "c_brp_lib",
    "BrpStack",
    "UsbHid",
    "RS232",
    "SecureChannel",
    "protocols",
    "get_brp_lib_path",
    "set_brp_lib_path",
]

def get_brp_lib_path() -> Optional[Path]:
    return c_brp_lib.dll_path


def set_brp_lib_path(path: Union[Path, str]) -> None:
    c_brp_lib.dll_path = Path(path)


def _autodetect_brp_lib() -> None:
    arch = 64 if sys.maxsize > 2 ** 32 else 32
    platform = sys.platform.replace("win32", "win")
    extension = {
        "win": "dll"
    }.get(platform, "unknown")
    dll_name = f"brp_lib.{platform}{arch}.{extension}"

    root_resource = importlib.resources.files("brp_lib")
    dll_resource = root_resource / dll_name
    dll_path = Path(str(dll_resource))
    if dll_path.exists():
        set_brp_lib_path(dll_path)


_autodetect_brp_lib()
