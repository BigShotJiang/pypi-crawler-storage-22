import ctypes
import typing
import functools
from contextlib import suppress
from pathlib import Path
from typing import Any, Protocol, TypeVar, Callable, Optional
from typing_extensions import Annotated, ParamSpec, Never

from .err import BrpError


buf = ctypes.POINTER(ctypes.c_char)
time = ctypes.c_ulong
errcode = ctypes.c_uint
layer_id = ctypes.c_int
socket = ctypes.c_int


class protocol_t(ctypes.Structure):
    pass


protocol = ctypes.POINTER(protocol_t)


class frame_t(ctypes.Structure):
    _fields_ = [
        ("ptr", buf),  # type is brp_buf, but in python
        # buf is defined in the scope of
        # this class definition...
        ("act_size", ctypes.c_size_t),
        ("total_size", ctypes.c_size_t),
    ]  # last read/write of frame failed


frame = ctypes.POINTER(frame_t)


class frame_reader_t(ctypes.Structure):
    _fields_ = [("frame", frame), ("ptr", buf), ("err", ctypes.c_bool)]


frame_reader = ctypes.POINTER(frame_reader_t)


class mempool_object_t(ctypes.Structure):
    pass


mempool = ctypes.POINTER(mempool_object_t)

mempool_object_t._fields_ = [
    ("prev", ctypes.POINTER(mempool_object_t)),
    ("next", ctypes.POINTER(mempool_object_t)),
    ("buf", ctypes.c_char_p),
]


class ioiter_t(ctypes.Structure):
    pass


ioiter = ctypes.POINTER(ioiter_t)
ioiter_p = ctypes.POINTER(ioiter)


cb_generic_t = ctypes.CFUNCTYPE(errcode, protocol)
cb_recv_any_frame_t = ctypes.CFUNCTYPE(errcode, protocol, time)
cb_fmt_spec_t = ctypes.CFUNCTYPE(ctypes.c_int, frame, ctypes.c_void_p)
cb_recv_frame_t = ctypes.CFUNCTYPE(
    errcode, protocol, time, cb_fmt_spec_t, ctypes.c_void_p
)
cb_get_id_t = ctypes.CFUNCTYPE(
    errcode, protocol, ctypes.POINTER(ctypes.c_char_p), frame
)

protocol_t._fields_ = [
    ("protocol_id", ctypes.c_int),
    ("layer_id", layer_id),
    ("base_protocol", protocol),
    ("cb_open", cb_generic_t),
    ("cb_close", cb_generic_t),
    ("cb_send_frame", cb_generic_t),
    ("cb_recv_any_frame", cb_recv_any_frame_t),
    ("cb_recv_frame", cb_recv_frame_t),
    ("cb_flush", cb_generic_t),
    ("cb_destroy", cb_generic_t),
    ("cb_get_id", cb_get_id_t),
    ("opened", ctypes.c_bool),
    ("send_frame", frame_t),
    ("recv_frame", frame_t),
    ("recv_delay", time),
    ("mempool", mempool_object_t),
    ("friendly_name", ctypes.c_char_p),
]


R = TypeVar("R", covariant=True)
P = ParamSpec("P")
C = TypeVar("C", bound=type)


class CBrpLibFunction(Protocol[P, R]):
    def __call__(self, *args: P.args, **kwargs: P.kwargs) -> R:
        ...


CharP = Annotated[ctypes.Array[ctypes.c_char], ctypes.c_char_p]
CharPP = Annotated[Any, ctypes.POINTER(ctypes.c_char_p)]
CInt = Annotated[int, ctypes.c_int]
CSize = Annotated[int, ctypes.c_size_t]
CSizeP = Annotated[Any, ctypes.POINTER(ctypes.c_size_t)]
CUShortP = Annotated[Any, ctypes.POINTER(ctypes.c_ushort)]
CChar = Annotated[bytes, ctypes.c_char]
CBool = Annotated[bool, ctypes.c_bool]
CBuf = Annotated[bytes, buf]
CLongLong = Annotated[int, ctypes.c_longlong]
CTime = Annotated[int, ctypes.c_ulong]
CProtocol = Annotated[Any, protocol]
CProtocolP = Annotated[Any, ctypes.POINTER(protocol)]
CFrame = Annotated[Any, frame]
CFrameReader = Annotated[Any, frame_reader]
CSocket = Annotated[int, socket]
CMempool = Annotated[Any, mempool]
CIoiter = Annotated[Any, ioiter]
CIoiterP = Annotated[Any, ioiter_p]
CUShort = Annotated[int, ctypes.c_ushort]

ErrorCode = Annotated[None, errcode]


def _to_ctype(t: Any) -> Any:
    if t is type(None):
        return None

    args = typing.get_args(t)
    if args:
        return args[1]

    return t


def _get_log_link(prot: Any) -> Optional[str]:
    path_ptr = c_brp_lib.brp_get_log_path(prot, None)
    if not path_ptr:
        return None

    path = Path(ctypes.string_at(path_ptr).decode('utf-8'))
    if not path.exists():
        return None
    url = f"{path.as_uri()}"

    anchor_ptr = ctypes.c_char_p()
    c_brp_lib.brp_get_current_log_anchor(prot, ctypes.byref(anchor_ptr), None)
    if anchor_ptr.value:
        return f"{url}{anchor_ptr.value.decode('utf-8')}"
    return url


def with_error_handling(fn: Callable[P, int]) -> Callable[P, None]:
    @functools.wraps(fn)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> None:
        result = fn(*args, **kwargs)
        if result:
            log_url = None
            with suppress():
                if len(args) > 0 and isinstance(args[0], protocol):
                    log_url = _get_log_link(args[0])
            raise BrpError.from_error_code(result, log_url=log_url)

    return wrapper


def _not_implemented(name: str, version: str, *args: object, **kwargs: object) -> Never:
    raise NotImplementedError(f"{name} is not implemented in brp_lib {version}")


class CBrpLib:
    brp_get_version: CBrpLibFunction[[], CharP]
    brp_create: CBrpLibFunction[[], CProtocol]
    brp_destroy: CBrpLibFunction[[CProtocol], ErrorCode]
    brp_set_io: CBrpLibFunction[[CProtocol, CProtocol], ErrorCode]
    brp_open: CBrpLibFunction[[CProtocol], ErrorCode]
    brp_close: CBrpLibFunction[[CProtocol], ErrorCode]
    brp_suppress_monitoring: CBrpLibFunction[[CProtocol], ErrorCode]
    brp_get_io_id: CBrpLibFunction[[CProtocol, CharPP, CFrame], ErrorCode]
    brp_get_friendly_name: CBrpLibFunction[[CProtocol, CharPP], ErrorCode]
    brp_ioiter_create: CBrpLibFunction[[], CIoiter]
    brp_ioiter_create_usb_hid: CBrpLibFunction[[], CIoiter]
    brp_ioiter_next: CBrpLibFunction[[CIoiter, CProtocolP], ErrorCode]
    brp_ioiter_destroy: CBrpLibFunction[[CIoiterP], None]
    brp_create_usb_hid: CBrpLibFunction[[CLongLong], CProtocol]
    brp_create_rs232: CBrpLibFunction[[CharP, CInt, CChar], CProtocol]
    brp_create_secure_channel: CBrpLibFunction[[CInt, CBuf, CInt], CProtocol]
    brp_set_crypto: CBrpLibFunction[[CProtocol, CProtocol], ErrorCode]
    brp_set_monitor: CBrpLibFunction[[CProtocol, CInt], ErrorCode]
    brp_send_frame: CBrpLibFunction[[CProtocol], ErrorCode]
    brp_recv_any_frame: CBrpLibFunction[[CProtocol, CInt], ErrorCode]
    brp_exec_cmd: CBrpLibFunction[[CProtocol, CInt, CBuf, CSize, CBuf, CSize, CSizeP, CTime], ErrorCode]
    brp_frame_rest: CBrpLibFunction[[CFrameReader], CSize]
    brp_frame_init: CBrpLibFunction[[CFrame], None]
    brp_frame_deinit: CBrpLibFunction[[CFrame], None]
    brp_frame_write_start: CBrpLibFunction[[CFrame], None]
    brp_frame_write: CBrpLibFunction[[CFrame, CBuf, CSize], None]
    brp_frame_write_err: CBrpLibFunction[[CFrame], CBool]
    brp_frame_read_start: CBrpLibFunction[[CFrameReader, CFrame], None]
    brp_frame_read: CBrpLibFunction[[CFrameReader, CBuf, CSize], None]
    brp_frame_read_err: CBrpLibFunction[[CFrameReader], CBool]
    brp_frame_read_eof: CBrpLibFunction[[CFrameReader], CBool]
    brp_annotation_start: CBrpLibFunction[[CProtocol], None]
    brp_annotation_end: CBrpLibFunction[[CProtocol, CBool, CharP], None]
    brp_set_log_path: CBrpLibFunction[[CProtocol, CharP], ErrorCode]
    brp_get_current_log_anchor: CBrpLibFunction[[CProtocol, CharPP, CMempool], ErrorCode]
    brp_get_log_path: CBrpLibFunction[[CProtocol, CMempool], CharP]

    def __init__(self) -> None:
        self.__dll_path: Optional[Path] = None

    @property
    def dll_path(self) -> Optional[Path]:
        return self.__dll_path

    @dll_path.setter
    def dll_path(self, dll_path: Path) -> None:
        self.__dll_path = dll_path.absolute()
        dll = ctypes.CDLL(str(self.__dll_path))

        for name, annotation in type(self).__annotations__.items():
            if typing.get_origin(annotation) == CBrpLibFunction:
                argtypes, restype = typing.get_args(annotation)
                fn = getattr(dll, name, None)
                if fn is None:
                    fn = functools.partial(
                        _not_implemented,
                        name=name,
                        version=bytes(self.brp_get_version()).decode("ascii")
                                if name != "brp_get_version"
                                else "<unknown>"
                    )
                else:
                    fn.restype = _to_ctype(restype)
                    fn.argtypes = tuple(map(_to_ctype, argtypes))
                    if restype == ErrorCode:
                        fn = with_error_handling(fn)
                setattr(self, name, fn)

    def __getattr__(self, item: str) -> Any:
        if item in type(self).__annotations__:
            raise RuntimeError("Please initialize the brp_lib path calling `brp_lib.set_brp_lib_path('.../libbrp_lib.so')`.")
        return super().__getattribute__(item)


c_brp_lib = CBrpLib()
