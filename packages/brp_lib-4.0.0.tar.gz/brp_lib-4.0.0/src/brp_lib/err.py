import abc
from typing import Dict, Type, Optional

__all__ = [
    "BrpError",
    "DeviceError",
    "CommunicationError",
    "CommUnsupported",
    "CommAccessDeniedError",
    "CommTimeoutError",
    "CommFrameFormatError",
    "CommUndefined",
    "LibError",
    "LibInvalidCallError",
    "LibNonRecoverableError",
    "LibOsError",
    "LibUndefinedError",
    "InternalError",
    "CommandTimeoutError",
    "FrameFormatError",
    "InvalidApiCallError",
    "OutOfMemoryError",
    "BrpNotImplementedError",
    "BusyError",
    "ClosedError",
    "BufferOverflowError",
    "OpenIOError",
    "WriteIOError",
    "WaitIOError",
    "ReadIOError",
    "CloseIOError",
    "PayloadFormatError",
    "CryptoFormatError",
    "SecurityLevelNotSupportedError",
    "UnsupportedCommandError",
    "CommandDeniedError",
    "UnexpectedFrameError",
    "BrpTimeoutError",
    "CalledInvalidFrameError",
    "ExistingLayerError",
    "GenRandomDataError",
    "InvalidKeyError",
    "NoDeviceFoundError",
    "AmbiguousDeviceError",
    "PayloadTooLongError",
    "PayloadTooShortError",
]

class BrpError(Exception, metaclass=abc.ABCMeta):
    ErrorCodeMap: Dict[int, Type["BrpError"]] = {}

    ErrorCode: Optional[int] = None
    URL: Optional[str] = None

    def __init_subclass__(cls) -> None:
        if cls.ErrorCode is not None:
            already_registered_class = cls.ErrorCodeMap.get(cls.ErrorCode)
            if already_registered_class is not None:
                if issubclass(cls, already_registered_class):
                    return
                raise TypeError(f"multiple exceptions defined for same status code {hex(cls.ErrorCode)} ({cls} and {already_registered_class})")
            cls.ErrorCodeMap[cls.ErrorCode] = cls

    @classmethod
    def from_error_code(cls, ec: int, *, log_url: Optional[str] = None) -> "BrpError":
        error_class: Type["BrpError"] = cls.ErrorCodeMap.get(ec, cls)
        return error_class(log_url=log_url)

    def __init__(self, message: str = "", *, log_url: Optional[str] = None) -> None:
        self.log_url = log_url
        super().__init__(message)

    def __str__(self) -> str:
        return "\n".join(
            map(str,
                filter(
                    lambda i: i is not None, [
                        f"0x{self.ErrorCode:08X} {super()!s}\n",
                        f"DESC: {self.__doc__.strip() if self.__doc__ else None}",
                        f"DOCS: {self.URL}" if self.URL else None,
                        f"LOGS: {self.log_url}" if self.log_url else None,
                    ]
                )
            )
        )


class CommunicationError(BrpError, metaclass=abc.ABCMeta):
    """Any kind of device <-> host communication problem"""


class CommUnsupported(CommunicationError, metaclass=abc.ABCMeta):
    """A command cannot be executed as the device does not support the requested feature"""


class CommAccessDeniedError(CommunicationError, metaclass=abc.ABCMeta):
    """A command cannot be executed as the device does not allow access this features in the current operations mode"""


class CommTimeoutError(CommunicationError, metaclass=abc.ABCMeta):
    """A the device or host exceeded the allowed time for sending a frame"""


class CommFrameFormatError(CommunicationError, metaclass=abc.ABCMeta):
    """The device or host send a frame that does not correspond the expected frame"""


class CommUndefined(CommunicationError, metaclass=abc.ABCMeta):
    """any device <-> host communication problem which is not categoriezed by one of the BRP_ERRGRP_COMM_* macros"""


class LibError(BrpError, metaclass=abc.ABCMeta):
    """Any error which occured in the library"""


class LibInvalidCallError(LibError, metaclass=abc.ABCMeta):
    """The libraries API was used in an invalid manner"""


class LibNonRecoverableError(LibError, metaclass=abc.ABCMeta):
    """A fatal error occured, which the library cannot recover from. The application should be closed"""


class LibOsError(LibError, metaclass=abc.ABCMeta):
    """A error in the operating system layer (i.e. hardware drivers) occured"""


class LibUndefinedError(LibError, metaclass=abc.ABCMeta):
    """any library specific error which is not one of the BRP_ERRGRP_LIB_* macros"""


class DeviceError(BrpError, metaclass=abc.ABCMeta):
    """
    A command failed to execute due to a error on the device side which is
    not host communication related (card error, ...)

    The lower 16bits of the error code will contains the command group code and
    the status code (see also #BRP_ERR_STATUS() on how to construct a specific
    error code).
    The exact list of error codes returned by the device can be found
    in the @ref baltech_sdk.
    """


class InternalError(LibNonRecoverableError):
    """This error must not be returned if the library operates correctly.
    It is only returned, if a bug in the implementation was detected."""
    ErrorCode = 0x20000001


class CommandTimeoutError(CommTimeoutError):
    """A BRP command that was send by brp_send_frame() exceeded the specified
    timeout (see also brp_send_cmd() / brp_exec_cmd()).

    **Attention:** must not be intermixed with #BRP_ERR_TIMEOUT."""
    ErrorCode = 0x02000002


class FrameFormatError(CommFrameFormatError):
    """The frame returned from the reader does not match the format expected
    by the BRP protocol."""
    ErrorCode = 0x04000003


class InvalidApiCallError(LibInvalidCallError):
    """Returned if the a parameter contains an invalid value.
    I.e. if a required pointer is set to NULL."""
    ErrorCode = 0x10000004


class OutOfMemoryError(LibNonRecoverableError):
    """The heap has not enough memory to allocate a buffer that is required
    for the wanted operation."""
    ErrorCode = 0x20000005


class BrpNotImplementedError(LibInvalidCallError):
    """The requested feature is not implemented yet"""
    ErrorCode = 0x10000006


class BusyError(LibInvalidCallError):
    """The Library is not ready to send/receive data. Probably it is still
    processing another request."""
    ErrorCode = 0x10000007


class ClosedError(LibInvalidCallError):
    """The protocol/device is not opened"""
    ErrorCode = 0x10000008


class BufferOverflowError(CommFrameFormatError):
    """A Command's response is bigger than the buffer provided for the response."""
    ErrorCode = 0x04000009


class OpenIOError(LibOsError):
    """Failed to open the I/O connection"""
    ErrorCode = 0x4000000A


class WriteIOError(LibOsError):
    """Failed to send data via IO connection"""
    ErrorCode = 0x4000000B


class WaitIOError(LibOsError):
    """Failed to wait for data via IO connection"""
    ErrorCode = 0x4000000C


class ReadIOError(LibOsError):
    """Failed to wait for data via IO connection"""
    ErrorCode = 0x4000000D


class CloseIOError(LibOsError):
    """Failed to open the I/O connection"""
    ErrorCode = 0x4000000E


class PayloadFormatError(CommFrameFormatError):
    """The payload of a frame has invalid format"""
    ErrorCode = 0x0400000F


class CryptoFormatError(CommFrameFormatError):
    """The payload of an encrypted command had invalid format/response."""
    ErrorCode = 0x04000010


class SecurityLevelNotSupportedError(CommAccessDeniedError):
    """The given securitylevel is not supported"""
    ErrorCode = 0x01000016


class UnsupportedCommandError(CommUnsupported):
    """The specified BRP command is not supported by the connected device

    Internally the driver maps the status code BRP_ERR_STATUS(xxxx, 0x41) to this
    (cmdcode independant) error code."""
    ErrorCode = 0x00800020


class CommandDeniedError(CommAccessDeniedError):
    """The BRP command is not allowed to be executed from the current security level

    Internally the driver maps the status code BRP_ERR_STATUS(xxxx, 0x42) to this
    (cmdcode independant) error code."""
    ErrorCode = 0x01000021


class UnexpectedFrameError(CommFrameFormatError):
    """The received frame is a valid BRP frame but not expected in this protocol
    state."""
    ErrorCode = 0x04000022


class BrpTimeoutError(CommTimeoutError):
    """The response to a brp_recv_frame() / brp_recv_any_frame() is not returned
    within the specified timeout.

    **Attention:** Must not be intermixed with #BRP_ERR_CMD_TIMEOUT, which is
    returned if the timeout of a BRP command is exceeded (see brp_send_cmd())."""
    ErrorCode = 0x02000023


class CalledInvalidFrameError(LibInvalidCallError):
    """Returned if the a frame passed to a function to be transferred to the device
    has invalid format"""
    ErrorCode = 0x10000024


class ExistingLayerError(LibInvalidCallError):
    """The layer is tried to be added to a composite protocol
    (see brp_add_layer() / brp_set_layer()) although already added earlier.
    Or it is tried to be removed (brp_detach_layer()) also not part of the
    composite protocol."""
    ErrorCode = 0x10000025


class GenRandomDataError(LibOsError):
    """The OS failed to generate a random number"""
    ErrorCode = 0x40000026


class InvalidKeyError(CommAccessDeniedError):
    """The readers KEY does not match the key of the host."""
    ErrorCode = 0x01000027


class NoDeviceFoundError(OpenIOError):
    """No device was found when trying to open a connection."""
    ErrorCode = 0x40000028


class AmbiguousDeviceError(OpenIOError):
    """Multiple devices found but connection string does not uniquely identify one."""
    ErrorCode = 0x40000029


##############################################################################
#                    PYTHON ONLY EXCEPTIONS                                  #
##############################################################################

class PayloadTooLongError(PayloadFormatError):
    """Raised when payload contains more data than expected."""

    def __init__(self, additional_data: bytes) -> None:
        super().__init__()
        self.additional_data = additional_data

    def __str__(self) -> str:
        return f'{len(self.additional_data)} bytes of unexpected data'


class PayloadTooShortError(PayloadFormatError):
    """Raised when payload contains less data than expected."""

    def __init__(self, missing_bytes: int) -> None:
        super().__init__()
        self.missing_bytes = missing_bytes

    def __str__(self) -> str:
        if self.missing_bytes == 1:
            return "1 byte is missing"
        return f'{self.missing_bytes} bytes are missing'
