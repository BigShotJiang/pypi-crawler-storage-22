import abc
import ctypes
import os
from pathlib import Path
from typing import Any, Optional, TypeVar, Literal, Type, Union, Iterator
from contextlib import contextmanager

from .dll_wrapper import c_brp_lib, buf, frame_reader_t, frame_t, protocol

T = TypeVar("T")


class CProtocolWrapper(metaclass=abc.ABCMeta):
    def __init__(self, c_protocol: Any) -> None:
        self._c_protocol = c_protocol

    @property
    def __c_protocol__(self) -> Any:
        if self._c_protocol is None:
            raise RuntimeError("Protocol ownership has been transferred to a parent protocol")
        return self._c_protocol

    def __take_c_protocol__(self) -> Any:
        if self._c_protocol is None:
            raise RuntimeError("Protocol ownership has already been transferred")
        c_protocol = self._c_protocol
        self._c_protocol = None
        return c_protocol

    @property
    def closed(self) -> bool:
        return not self.__c_protocol__.contents.opened

    def open(self) -> None:
        c_brp_lib.brp_open(self.__c_protocol__)

    def close(self) -> None:
        c_brp_lib.brp_close(self.__c_protocol__)

    def __enter__(self) -> Any:
        if self.closed:
            self.open()
        return self

    def __exit__(self, exc_type: Type[Exception], exc_val: Exception, exc_tb: Any) -> None:
        if not self.closed:
            self.close()

    def __del__(self) -> None:
        # Check if _c_protocol exists and is not None (ownership not transferred)
        if hasattr(self, '_c_protocol') and self._c_protocol is not None:
            if not self.closed:
                self.close()
            c_brp_lib.brp_destroy(self._c_protocol)

    @property
    def id(self) -> str:
        """Device ID (e.g., serial number for USB HID devices)."""
        intf_name_ptr = ctypes.c_char_p()
        device_id_frame = frame_t()
        c_brp_lib.brp_frame_init(ctypes.pointer(device_id_frame))
        try:
            c_brp_lib.brp_get_io_id(self.__c_protocol__, ctypes.byref(intf_name_ptr), ctypes.pointer(device_id_frame))
            if device_id_frame.ptr:
                return ctypes.string_at(device_id_frame.ptr, device_id_frame.act_size).decode('utf-8', errors='replace').rstrip('\x00')
            return ""
        finally:
            c_brp_lib.brp_frame_deinit(ctypes.pointer(device_id_frame))

    @property
    def friendly_name(self) -> Optional[str]:
        """Human-readable device name (e.g., product name for USB HID devices)."""
        friendly_name_ptr = ctypes.c_char_p()
        c_brp_lib.brp_get_friendly_name(self.__c_protocol__, ctypes.byref(friendly_name_ptr))
        if friendly_name_ptr.value:
            return friendly_name_ptr.value.decode('utf-8', errors='replace')
        return None

    def __str__(self) -> str:
        """Return a string representation of the protocol."""
        name = self.friendly_name
        if name:
            return f"{name} {self.id} ({self.__class__.__name__})"
        return f"{self.id} ({self.__class__.__name__})"


class IoProtocol(CProtocolWrapper, metaclass=abc.ABCMeta):
    pass


class UsbHid(IoProtocol):
    def __init__(self, serialnumber: Optional[int] = None) -> None:
        self.serialnumber = serialnumber
        super().__init__(c_brp_lib.brp_create_usb_hid(serialnumber or 0))

    @classmethod
    def enumerate(cls) -> Iterator['UsbHid']:
        """
        Enumerate all connected Baltech USB HID devices.

        Yields UsbHid instances for each connected device. The caller is responsible
        for managing the lifecycle of yielded devices (e.g., using context managers).

        Example:
            >>> for device in UsbHid.enumerate():
            ...     with device:
            ...         print(f"Device: {device.friendly_name or device.id}")
            ...         # Use device for communication
        """
        # Create USB HID-specific iterator
        iter_handle = c_brp_lib.brp_ioiter_create_usb_hid()
        if not iter_handle:
            return

        try:
            while True:
                # Get next protocol
                protocol_ptr = protocol()
                c_brp_lib.brp_ioiter_next(iter_handle, ctypes.byref(protocol_ptr))

                # Check if we reached the end
                if not protocol_ptr:
                    break

                # Wrap the protocol from iterator in a UsbHid instance
                # The protocol already has friendly_name populated from the iterator
                device = cls.__new__(cls)
                device._c_protocol = protocol_ptr
                yield device
        finally:
            # Clean up iterator
            iter_ref = ctypes.pointer(iter_handle)
            c_brp_lib.brp_ioiter_destroy(iter_ref)


class RS232(IoProtocol):
    def __init__(self, comport: str, baudrate: int = 115200, parity: Literal[b"O", b"E", b"N"] = b"N") -> None:
        self.comport = comport
        comport_cstr = ctypes.create_string_buffer(comport.encode("ascii"))
        super().__init__(c_brp_lib.brp_create_rs232(comport_cstr, baudrate, parity))


class CryptoProtocol(CProtocolWrapper, metaclass=abc.ABCMeta):
    pass


class SecureChannel(CryptoProtocol):
    def __init__(self, *, security_level: int, key: bytes, security_mode: Literal["std", "plain", "stateless"] = "std") -> None:
        secmode = dict(std=0, plain=1, stateless=2).get(security_mode, 0)
        super().__init__(c_brp_lib.brp_create_secure_channel(security_level, key, secmode))


MonitorMode = Union[Literal["disabled", "enabled", "plaintext"], bool]


class AnnotationLogger:

    def __init__(self) -> None:
        self._message = ""
        self._fail = False

    def info(self, message: str) -> None:
        self._message += message

    def fail(self, message: str = "") -> None:
        self._fail = True
        self._message += message


class BrpStack(CProtocolWrapper):
    def __init__(
            self,
            io: IoProtocol,
            *,
            crypto: Optional[CryptoProtocol] = None,
            monitor: MonitorMode = "enabled",
            log_path: Optional[Union[str, Path]] = None,
            open: bool = False,
    ) -> None:
        super().__init__(c_brp_lib.brp_create())

        c_brp_lib.brp_set_io(self.__c_protocol__, io.__take_c_protocol__())

        if crypto:
            c_brp_lib.brp_set_crypto(self.__c_protocol__, crypto.__take_c_protocol__())

        if monitor not in (True, "enabled"):
            self.monitor = monitor

        if log_path is not None:
            self.log_path = Path(log_path)

        if open:
            self.open()

    def send_frame(self, frame: bytes) -> None:
        send_frame = ctypes.pointer(self.__c_protocol__.contents.send_frame)

        c_brp_lib.brp_frame_write_start(send_frame)
        c_brp_lib.brp_frame_write(send_frame, frame, len(frame))
        c_brp_lib.brp_frame_write_err(send_frame)
        c_brp_lib.brp_send_frame(self.__c_protocol__)

    def recv_any_frame(self, timeout: int = 0xFFFFFFFF) -> bytes:
        reader = frame_reader_t()
        c_brp_lib.brp_recv_any_frame(self.__c_protocol__, timeout)
        c_brp_lib.brp_frame_read_start(
            ctypes.pointer(reader), ctypes.pointer(self.__c_protocol__.contents.recv_frame)
        )
        rest = c_brp_lib.brp_frame_rest(ctypes.pointer(reader))

        result = ctypes.create_string_buffer(rest)
        c_brp_lib.brp_frame_read(ctypes.pointer(reader), buf(result), rest)  # type: ignore[call-overload]
        c_brp_lib.brp_frame_read_err(ctypes.pointer(reader))

        eof = c_brp_lib.brp_frame_read_eof(ctypes.pointer(reader))
        if not eof:
            raise RuntimeError("UnexpectedData")

        return result.raw

    def process_frame(self, frame: bytes) -> bytes:
        self.send_frame(frame)
        return self.recv_any_frame()

    def exec_cmd(self, cmd_code: int, params: bytes, *, timeout: int, max_resp_len: int = 65536) -> bytes:
        resp_buf = ctypes.create_string_buffer(max_resp_len)
        resp_len = ctypes.c_size_t()

        c_brp_lib.brp_exec_cmd(
            self.__c_protocol__,
            cmd_code,
            params,
            len(params),
            buf(resp_buf),  # type: ignore[call-overload]
            max_resp_len,
            ctypes.pointer(resp_len),
            timeout
        )

        return resp_buf.raw[:resp_len.value]

    def set_monitor(self, new_val: MonitorMode) -> None:
        map = {"disabled": 0, "enabled": 1, "plaintext": 2, False:0, True:1}
        c_brp_lib.brp_set_monitor(self.__c_protocol__, map[new_val])

    @contextmanager
    def annotate_log(self, comment:str="") -> Iterator[AnnotationLogger]:
        """
        Adds an annotations/comment to all brplogs that are executed within
        this context.

        Returns a contextmanager that allows to add further log-messages
        (log.info(...) or log.fail(...)). if at least one failure message is
        send the whole block is marked as failed.

        If an exception occurs the block will be marked as failed, too.
        If no log.fail() was called the exception text will be added to
        the log annotation.

        :param comment: A string that shall be added as annotation to the logs
        :return: a contextmanager of type AnnotationLogger()
        """
        annotation_logger = AnnotationLogger()
        annotation_logger.info(comment)
        try:
            c_brp_lib.brp_annotation_start(self.__c_protocol__)
            yield annotation_logger
        except Exception as exc:
            if not annotation_logger._fail:
                exc_text = f"{type(exc).__name__}: {str(exc)}"
                annotation_logger.fail(exc_text.splitlines()[0])
            raise
        finally:
            message_utf8 = annotation_logger._message.encode('utf8')
            message_cstr = ctypes.create_string_buffer(message_utf8)
            fail = annotation_logger._fail
            c_brp_lib.brp_annotation_end(
                self.__c_protocol__, not fail, message_cstr)

    monitor = property(fset=set_monitor)

    @property
    def current_log_anchor(self) -> Optional[str]:
        """
        Get the anchor ID of the current (last written) log entry.

        The anchor can be used to create direct links to specific log entries,
        e.g., ``f"file://{log_path}#{brp.current_log_anchor}"``

        :return: The anchor string (e.g., "_a3") in hex format, or None
            if no log entries have been written yet.
        """
        anchor_ptr = ctypes.c_char_p()
        c_brp_lib.brp_get_current_log_anchor(self.__c_protocol__, ctypes.byref(anchor_ptr), None)
        if anchor_ptr.value:
            return anchor_ptr.value.decode("ascii")
        return None

    @property
    def log_path(self) -> Optional[Path]:
        """
        Get the current log file path.

        :return: The full path to the log file currently being used,
                 or None if no monitor protocol is present.
        """
        path_ptr = c_brp_lib.brp_get_log_path(self.__c_protocol__, None)
        if path_ptr:
            # path_ptr is a c_char_p, convert to string
            path_str = ctypes.string_at(path_ptr).decode("utf-8")
            return Path(path_str)
        return None

    @log_path.setter
    def log_path(self, path: Union[str, Path]) -> None:
        """
        Set the log file path.

        :param path: The log file path. Can be a full file path
            (e.g., "C:/logs/debug.html"), a directory (uses the default
            filename schema {interface}-{instance}.html),
            or None to restore the default behavior.
        """
        if path is None:
            path_cstr = None
        else:
            path_obj = Path(path)
            if path_obj.is_dir():
                path_str = str(path_obj) + os.sep
            else:
                path_str = str(path)
            path_cstr = ctypes.create_string_buffer(path_str.encode("utf-8"))
        c_brp_lib.brp_set_log_path(self.__c_protocol__, path_cstr)

    @log_path.setter
    def log_path(self, path: Optional[Union[str, Path]]) -> None:
        """
        Set the log file path.

        :param path: The log file path. Can be a full file path
            (e.g., "C:/logs/debug.html"), a directory (uses the default
            filename schema {interface}-{instance}.html),
            or None to restore the default behavior.
        """
        if path is None:
            path_cstr = None
        else:
            path_obj = Path(path)
            if path_obj.is_dir():
                path_str = str(path_obj) + os.sep
            else:
                path_str = str(path)
            path_cstr = ctypes.create_string_buffer(path_str.encode("utf-8"))
        c_brp_lib.brp_set_log_path(self.__c_protocol__, path_cstr)  # type: ignore[arg-type]
