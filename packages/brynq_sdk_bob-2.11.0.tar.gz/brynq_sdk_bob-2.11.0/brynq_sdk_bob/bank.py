import pandas as pd
from brynq_sdk_functions import Functions
from .schemas.bank import BankGet


class Bank:
    def __init__(self, client):
        self.client = client
        self.schema = BankGet

    def get(self, person_ids: pd.Series, field_selection: list[str] = []) -> tuple[pd.DataFrame, pd.DataFrame]:
        data = []
        for person_id in person_ids:
            resp = self.client.session.get(url=f"{self.client.base_url}people/{person_id}/bank-accounts", timeout=self.client.timeout)
            resp.raise_for_status()
            temp_data = resp.json()['values']
            # when an employee has one or more bank accounts, the response is a list of dictionaries.
            for account in temp_data:
                account['employee_id'] = person_id
            data += temp_data

        df = pd.DataFrame(data)

        valid_banks, invalid_banks = Functions.validate_data(df=df, schema=BankGet, debug=True)

        return valid_banks, invalid_banks
