from datetime import datetime
from io import BytesIO

import pandas as pd
from brynq_sdk_functions import Functions


class CustomDocuments:
    def __init__(self, client):
        self.client = client

    def get(self, person_id: datetime) -> pd.DataFrame:
        resp = self.client.session.get(url=f"{self.client.base_url}docs/people/{person_id}", timeout=self.client.timeout)
        resp.raise_for_status()
        data = resp.json()['documents']
        df = pd.DataFrame(data)
        df = self.client.rename_camel_columns_to_snake_case(df)

        return df

    def get_folders(self) -> dict:
        resp = self.client.session.get(url=f"{self.client.base_url}docs/folders/metadata", timeout=self.client.timeout)
        resp.raise_for_status()
        data = resp.json()

        return data

    def create(self,
               person_id: datetime,
               folder_id: str,
               file_name: str,
               file_object: BytesIO):
        files = {"file": (file_name, file_object, "application/pdf")}
        resp = self.client.session.post(url=f"{self.client.base_url}docs/people/{person_id}/folders/{folder_id}/upload",
                                     files=files,
                                     timeout=self.client.timeout)
        resp.raise_for_status()
