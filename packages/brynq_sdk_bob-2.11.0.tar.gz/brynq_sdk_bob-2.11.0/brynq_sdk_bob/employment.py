import pandas as pd
import requests
from .schemas.employment import EmploymentGet
from brynq_sdk_functions import Functions


class Employment:
    def __init__(self, client):
        self.client = client
        self.schema = EmploymentGet

    def get(self) -> tuple[pd.DataFrame, pd.DataFrame]:
        request = requests.Request(method='GET',
                                   url=f"{self.client.base_url}bulk/people/employment",
                                   params={"includeArchived": "true"})
        data = self.client.get_paginated_result(request)
        df = pd.json_normalize(
            data,
            record_path='values',
            meta=['employeeId']
        )
        valid_contracts, invalid_contracts = Functions.validate_data(df=df, schema=self.schema, debug=True)

        return valid_contracts, invalid_contracts
