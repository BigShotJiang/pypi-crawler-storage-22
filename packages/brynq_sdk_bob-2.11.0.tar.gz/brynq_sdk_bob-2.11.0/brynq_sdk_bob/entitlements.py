from typing import Tuple
import pandas as pd
from brynq_sdk_functions import Functions
from brynq_sdk_bob.schemas.entitlements import EntitlementReportGet


class Entitlements:
    def __init__(self, client):
        self.client = client

    def get(self, report_id: str | None = None, debug: bool = False) -> tuple[pd.DataFrame, pd.DataFrame]:
        """
        Get entitlement history data from the Bob reports.

        Args:
            report_id: Optional report ID. If not provided, will search for 'Entitlement history' report.
            debug: Whether to print debug information.

        Returns:
            Tuple of (valid_entitlements, invalid_entitlements) DataFrames
        """
        reports_df, _ = self.client.reports.get()
        if report_id is None:
            entitlement_report = reports_df[reports_df['name'] == 'Entitlement history']
            if entitlement_report.empty:
                raise ValueError("Report 'Entitlement history' not found.")
            report_id = entitlement_report['id'].iloc[0]

        report_data = self.client.reports.download(report_id=report_id)
        df_raw = pd.json_normalize(report_data, record_path='employees')
        valid_entitlements, invalid_entitlements = Functions.validate_data(
            df=df_raw,
            schema=EntitlementReportGet,
            debug=debug,
        )

        return valid_entitlements, invalid_entitlements
