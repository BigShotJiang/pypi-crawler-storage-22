from datetime import datetime
import pandas as pd
from brynq_sdk_functions import Functions
from .schemas.named_lists import NamedListGet


class NamedLists:
    def __init__(self, client):
        self.client = client
        self.schema = NamedListGet

    def get(self) -> tuple[pd.DataFrame, pd.DataFrame]:
        """
        Get custom table data for an employee

        Args:
            list_name: The list name

        Returns:
            A tuple of (valid_data, invalid_data) as pandas DataFrames
        """
        url = f"{self.client.base_url}company/named-lists/"
        resp = self.client.session.get(url=url)
        resp.raise_for_status()
        data = resp.json()

        df = pd.DataFrame([
            {**item, "type": key}
            for key, group in data.items()
            for item in group["values"]
        ])

        # Normalize the nested JSON response
        valid_data, invalid_data = Functions.validate_data(df=df, schema=NamedListGet, debug=True)

        return valid_data, invalid_data
