from typing import Literal, TYPE_CHECKING

import pandas as pd
from brynq_sdk_functions import Functions
from brynq_sdk_bob.schemas.reports import ReportGet
if TYPE_CHECKING:
    from brynq_sdk_bob import Bob


class Reports:
    def __init__(self, client):
        self.client: Bob = client

    def get(self) -> tuple[pd.DataFrame, pd.DataFrame]:
        resp = self.client.session.get(url=f"{self.client.base_url}company/reports", timeout=self.client.timeout)
        resp.raise_for_status()
        data = resp.json()
        df = pd.json_normalize(
            data,
            record_path='views'
        )
        valid_reports, invalid_reports = Functions.validate_data(df=df, schema=ReportGet, debug=True)

        return valid_reports, invalid_reports

    def download(self, report_id: int | str = None, report_format: Literal["json", "csv"] = "json") -> dict | bytes:
        if report_id:
            url = f"{self.client.base_url}company/reports/{report_id}/download"
        else:
            raise ValueError("Either report_id or report_name must be provided")

        resp = self.client.session.get(url=url, timeout=self.client.timeout, params={"format": report_format})
        resp.raise_for_status()
        if report_format == "json":
            data = resp.json()
        elif report_format == "csv":
            data = resp.content
        else:
            raise ValueError(f"Invalid report format: {report_format}")

        return data
