import pandera as pa
import pandas as pd
from typing import Optional
from brynq_sdk_functions import BrynQPanderaDataFrameModel

class BankGet(BrynQPanderaDataFrameModel):
    id: pd.Int64Dtype = pa.Field(coerce=True, description="Bank ID", alias="id")
    employee_id: pd.StringDtype = pa.Field(coerce=True, description="Employee ID", alias="employee_id")
    amount: Optional[pd.Int64Dtype] = pa.Field(coerce=True, nullable=True, description="Amount", alias="amount")
    allocation: Optional[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Allocation", alias="allocation")
    branch_address: Optional[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Branch Address", alias="branchAddress")
    bank_name: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Bank Name", alias="bankName")
    account_number: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Account Number", alias="accountNumber")
    routing_number: Optional[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Routing Number", alias="routingNumber")
    bank_account_type: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Bank Account Type", alias="bankAccountType")
    bic_or_swift: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="BIC or SWIFT", alias="bicOrSwift")
    changed_by: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Changed By", alias="changedBy")
    iban: pd.StringDtype = pa.Field(coerce=True, description="IBAN", alias="iban")
    account_nickname: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Account Nickname", alias="accountNickname")
    use_for_bonus: Optional[pd.BooleanDtype] = pa.Field(coerce=True, nullable=True, description="Use for Bonus", alias="useForBonus")

    class Config:
        coerce = True
        strict = False
