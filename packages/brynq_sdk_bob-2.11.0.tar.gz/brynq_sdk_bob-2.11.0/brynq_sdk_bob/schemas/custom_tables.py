import pandera as pa
import pandas as pd
from brynq_sdk_functions import BrynQPanderaDataFrameModel

class CustomTableGet(BrynQPanderaDataFrameModel):
    id: pd.Int64Dtype = pa.Field(coerce=True, description="Custom Table ID", alias="id")
    employee_id: pd.StringDtype = pa.Field(coerce=True, description="Employee ID", alias="employee_id")

    class Config:
        coerce = True
class CustomTableMetadataGet(BrynQPanderaDataFrameModel):
    # Table information
    table_id: pd.StringDtype = pa.Field(coerce=True, description="Table ID", alias="table_id")
    table_name: pd.StringDtype = pa.Field(coerce=True, description="Table Name", alias="table_name")
    table_category: pd.StringDtype = pa.Field(coerce=True, description="Table Category", alias="table_category")
    table_description: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Table Description", alias="table_description")

    # Column information
    column_id: pd.StringDtype = pa.Field(coerce=True, description="Column ID", alias="column_id")
    column_name: pd.StringDtype = pa.Field(coerce=True, description="Column Name", alias="column_name")
    column_description: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Column Description", alias="column_description")
    column_mandatory: pd.BooleanDtype = pa.Field(coerce=True, description="Is Column Mandatory", alias="column_mandatory")
    column_type: pd.StringDtype = pa.Field(coerce=True, description="Column Type", alias="column_type")

    class Config:
        coerce = True
