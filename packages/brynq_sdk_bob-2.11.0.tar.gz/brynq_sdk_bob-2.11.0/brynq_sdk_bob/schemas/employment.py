import pandas as pd
from datetime import datetime
import pandera as pa
from typing import Optional
from brynq_sdk_functions import BrynQPanderaDataFrameModel

class EmploymentGet(BrynQPanderaDataFrameModel):
    id: pd.Int64Dtype = pa.Field(coerce=True, description="Employment ID", alias="id")
    employee_id: pd.StringDtype = pa.Field(coerce=True, description="Employee ID", alias="employeeId")
    active_effective_date: datetime = pa.Field(coerce=True, description="Active Effective Date", alias="activeEffectiveDate")
    contract: Optional[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Contract", alias="contract") # has a list of possible values
    creation_date: Optional[datetime] = pa.Field(coerce=True, nullable=True, description="Creation Date", alias="creationDate")
    effective_date: datetime = pa.Field(coerce=True, description="Effective Date", alias="effectiveDate")
    end_effective_date: Optional[datetime] = pa.Field(coerce=True, nullable=True, description="End Effective Date", alias="endEffectiveDate")
    fte: pd.Float64Dtype = pa.Field(coerce=True, description="FTE", alias="fte")
    is_current: pd.BooleanDtype = pa.Field(coerce=True, description="Is Current", alias="isCurrent")
    modification_date: Optional[datetime] = pa.Field(coerce=True, nullable=True, description="Modification Date", alias="modificationDate")
    salary_pay_type: Optional[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Salary Pay Type", alias="salaryPayType")
    weekly_hours: Optional[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Weekly Hours", alias="weeklyHours")
    # weekly_hours_sort_factor: pd.Int64Dtype = pa.Field(coerce=True, nullable=False)
    actual_working_pattern_working_pattern_type: Optional[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Actual Working Pattern Working Pattern Type", alias="actualWorkingPattern.workingPatternType")
    actual_working_pattern_days_sunday: Optional[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Actual Working Pattern Days Sunday", alias="actualWorkingPattern.days.sunday")
    actual_working_pattern_days_tuesday: Optional[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Actual Working Pattern Days Tuesday", alias="actualWorkingPattern.days.tuesday")
    actual_working_pattern_days_wednesday: Optional[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Actual Working Pattern Days Wednesday", alias="actualWorkingPattern.days.wednesday")
    actual_working_pattern_days_monday: Optional[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Actual Working Pattern Days Monday", alias="actualWorkingPattern.days.monday")
    actual_working_pattern_days_friday: Optional[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Actual Working Pattern Days Friday", alias="actualWorkingPattern.days.friday")
    actual_working_pattern_days_thursday: Optional[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Actual Working Pattern Days Thursday", alias="actualWorkingPattern.days.thursday")
    actual_working_pattern_days_saturday: Optional[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Actual Working Pattern Days Saturday", alias="actualWorkingPattern.days.saturday")

    class Config:
        coerce = True
