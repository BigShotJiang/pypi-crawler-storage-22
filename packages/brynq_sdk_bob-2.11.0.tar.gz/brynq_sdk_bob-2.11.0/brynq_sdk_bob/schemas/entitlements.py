import pandera as pa
from typing import Optional
import pandas as pd
from brynq_sdk_functions import BrynQPanderaDataFrameModel

class EntitlementReportGet(BrynQPanderaDataFrameModel):
    surname: Optional[pd.StringDtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Employee surname",
        alias="surname",
    )
    first_name: Optional[pd.StringDtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Employee first name",
        alias="firstName",
    )
    employee_id: pd.StringDtype = pa.Field(
        coerce=True,
        description="Employee identifier",
        alias="id",
    )
    entitlement_name: pd.StringDtype = pa.Field(
        coerce=True,
        description="Entitlement name",
        alias="payroll.entitlement.entitlement",
    )
    entitlement_is_current: pd.BooleanDtype = pa.Field(
        coerce=True,
        description="Whether entitlement is current",
        alias="payroll.entitlement.isCurrent",
    )
    entitlement_end_date: Optional[str] = pa.Field(
        coerce=True,
        nullable=True,
        description="Entitlement end date",
        alias="payroll.entitlement.endDate",
    )
    entitlement_can_be_deleted: pd.BooleanDtype = pa.Field(
        coerce=True,
        description="Whether entitlement can be deleted",
        alias="payroll.entitlement.canBeDeleted",
    )
    entitlement_amount_value: Optional[pd.Float64Dtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Entitlement amount value",
        alias="payroll.entitlement.amount.value",
    )
    entitlement_amount_currency: Optional[pd.StringDtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Entitlement currency",
        alias="payroll.entitlement.amount.currency",
    )
    entitlement_end_effective_date: Optional[str] = pa.Field(
        coerce=True,
        nullable=True,
        description="Entitlement end effective date",
        alias="payroll.entitlement.endEffectiveDate",
    )
    entitlement_change_reason: Optional[pd.StringDtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Reason for change",
        alias="payroll.entitlement.change.reason",
    )
    entitlement_change_changed_by: Optional[pd.StringDtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="User that changed the entitlement",
        alias="payroll.entitlement.change.changedBy",
    )
    entitlement_change_changed_by_id: Optional[pd.StringDtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Identifier of the user that changed the entitlement",
        alias="payroll.entitlement.change.changedById",
    )
    entitlement_id: pd.Int64Dtype = pa.Field(
        coerce=True,
        description="Entitlement record identifier",
        alias="payroll.entitlement.id",
    )
    entitlement_effective_date: Optional[str] = pa.Field(
        coerce=True,
        nullable=True,
        description="Entitlement effective date",
        alias="payroll.entitlement.effectiveDate",
    )
    entitlement_creation_date: Optional[str] = pa.Field(
        coerce=True,
        nullable=True,
        description="Entitlement creation date",
        alias="payroll.entitlement.creationDate",
    )
    entitlement_modification_date: Optional[str] = pa.Field(
        coerce=True,
        nullable=True,
        description="Entitlement modification date",
        alias="payroll.entitlement.modificationDate",
    )

    class Config:
        coerce = True

    class _Annotation:
        primary_key = "entitlement_id"
