import pandas as pd
import pandera as pa
from brynq_sdk_functions import BrynQPanderaDataFrameModel

class NamedListGet(BrynQPanderaDataFrameModel):
    id: pd.StringDtype = pa.Field(coerce=True, description="Named List ID", alias="id")
    value: pd.StringDtype = pa.Field(coerce=True, description="Named List Value", alias="value")
    name: pd.StringDtype = pa.Field(coerce=True, description="Named List Name", alias="name")
    archived: pd.BooleanDtype = pa.Field(coerce=True, description="Named List Archived", alias="archived")
    # children: Series[list] = pa.Field(coerce=True)
    type: pd.StringDtype = pa.Field(coerce=True, description="Named List Type", alias="type")

    class Config:
        coerce = True
