from typing import Optional

import pandas as pd
from datetime import datetime
import pandera as pa

from brynq_sdk_functions import BrynQPanderaDataFrameModel

class VariablePaymentGet(BrynQPanderaDataFrameModel):
    can_be_deleted: pd.BooleanDtype = pa.Field(nullable=True, coerce=True, description="Can Be Deleted", alias="canBeDeleted")
    department_percent: pd.Float64Dtype = pa.Field(nullable=True, coerce=True, description="Department Percent", alias="departmentPercent")
    payout_type: pd.StringDtype = pa.Field(coerce=True, description="Payout Type", alias="payoutType")
    num_of_salaries: Optional[pd.Int64Dtype] = pa.Field(nullable=True, coerce=True, description="Number of Salaries", alias="numOfSalaries")
    end_date: Optional[datetime] = pa.Field(nullable=True, coerce=True, description="End Date", alias="endDate")
    creation_date: datetime = pa.Field(coerce=True, description="Creation Date", alias="creationDate")
    percentage_of_annual_salary: pd.Float64Dtype = pa.Field(nullable=True, coerce=True, description="Percentage of Annual Salary", alias="percentageOfAnnualSalary")
    individual_percent: pd.Float64Dtype = pa.Field(nullable=True, coerce=True, description="Individual Percent", alias="individualPercent")
    variable_type: pd.StringDtype = pa.Field(nullable=True, coerce=True, description="Variable Type", alias="variableType")
    is_current: pd.BooleanDtype = pa.Field(nullable=True, coerce=True, description="Is Current", alias="isCurrent")
    modification_date: datetime = pa.Field(nullable=True, coerce=True, description="Modification Date", alias="modificationDate")
    company_percent: pd.Float64Dtype = pa.Field(nullable=True, coerce=True, description="Company Percent", alias="companyPercent")
    id: pd.Int64Dtype = pa.Field(coerce=True, description="ID", alias="id")
    end_effective_date: datetime = pa.Field(nullable=True, coerce=True, description="End Effective Date", alias="endEffectiveDate")
    payment_period: pd.StringDtype = pa.Field(coerce=True, description="Payment Period", alias="paymentPeriod")
    effective_date: datetime = pa.Field(coerce=True, description="Effective Date", alias="effectiveDate")
    amount_value: Optional[pd.Float64Dtype] = pa.Field(coerce=True, description="Amount Value", alias="amount.value")
    amount_alternative_value: Optional[pd.Float64Dtype] = pa.Field(coerce=True, description="Amount Value", alias="amount")
    amount_currency: Optional[pd.StringDtype] = pa.Field(coerce=True, description="Amount Currency", alias="amount.currency")
    change_changed_by: pd.StringDtype = pa.Field(nullable=True, coerce=True, description="Change Changed By", alias="change.changedBy")
    change_changed_by_id: pd.Int64Dtype = pa.Field(nullable=True, coerce=True, description="Change Changed By ID", alias="change.changedById")
    employee_id: pd.StringDtype = pa.Field(coerce=True, description="Employee ID", alias="employee_id") #set manually
    class Config:
        coerce = True

class ActualPaymentsGet(BrynQPanderaDataFrameModel):
    employee_id: pd.StringDtype = pa.Field(coerce=True, description="Employee ID", alias="employeeId")
    id: pd.Int64Dtype = pa.Field(coerce=True, description="Payment ID", alias="id")
    pay_date: datetime = pa.Field(coerce=True, description="Pay Date", alias="payDate")
    pay_type: pd.StringDtype = pa.Field(coerce=True, description="Pay Type", alias="payType")
    amount_value: pd.Float64Dtype = pa.Field(coerce=True, description="Amount Value", alias="amount.value")
    amount_currency: pd.StringDtype = pa.Field(coerce=True, description="Amount Currency", alias="amount.currency")
    change_changed_by: pd.StringDtype = pa.Field(nullable=True, coerce=True, description="Change Changed By", alias="change.changedBy")
    change_changed_by_id: pd.StringDtype = pa.Field(nullable=True, coerce=True, description="Change Changed By ID", alias="change.changedById")

    class Config:
        coerce = True

