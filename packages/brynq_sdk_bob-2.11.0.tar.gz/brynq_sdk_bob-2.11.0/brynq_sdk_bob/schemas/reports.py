import pandera as pa
from typing import Optional
import pandas as pd
from brynq_sdk_functions import BrynQPanderaDataFrameModel

class ReportGet(BrynQPanderaDataFrameModel):
    modification_date: Optional[str] = pa.Field(
        coerce=True,
        nullable=True,
        description="Modification date of the report view",
        alias="modificationDate",
    )
    created_by: pd.StringDtype = pa.Field(
        coerce=True,
        description="User identifier that created the report",
        alias="createdBy",
    )
    configuration_instructions: Optional[object] = pa.Field(
        coerce=True,
        nullable=True,
        description="Configuration instructions for the report view",
        alias="configuration.instructions",
    )
    configuration_changes: Optional[object] = pa.Field(
        coerce=True,
        nullable=True,
        description="Configuration changes associated with the report view",
        alias="configuration.changes",
    )
    configuration_display_preferences_export_configuration: Optional[object] = pa.Field(
        coerce=True,
        nullable=True,
        description="Export configuration within display preferences",
        alias="configuration.displayPreferences.exportConfiguration",
    )
    configuration_display_preferences_include_flat_json: pd.BooleanDtype = pa.Field(
        coerce=True,
        description="Flag to include flat JSON in the export",
        alias="configuration.displayPreferences.includeFlatJson",
    )
    configuration_display_preferences_date_format: Optional[pd.StringDtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Date format specified in display preferences",
        alias="configuration.displayPreferences.dateFormat",
    )
    configuration_display_preferences_support_error_wrapping: pd.BooleanDtype = pa.Field(
        coerce=True,
        description="Whether error wrapping is supported in display preferences",
        alias="configuration.displayPreferences.supportErrorWrapping",
    )
    configuration_display_preferences_columns_properties: Optional[object] = pa.Field(
        coerce=True,
        nullable=True,
        description="Column properties defined in display preferences",
        alias="configuration.displayPreferences.columnsProperties",
    )
    configuration_display_preferences_include_human_readable: pd.BooleanDtype = pa.Field(
        coerce=True,
        description="Flag to include human-readable output in display preferences",
        alias="configuration.displayPreferences.includeHumanReadable",
    )
    configuration_sort_by: Optional[object] = pa.Field(
        coerce=True,
        nullable=True,
        description="Sort configuration for the report view",
        alias="configuration.sortBy",
    )
    configuration_fields: Optional[object] = pa.Field(
        coerce=True,
        nullable=True,
        description="Fields included in the report view",
        alias="configuration.fields",
    )
    is_comparable: pd.BooleanDtype = pa.Field(
        coerce=True,
        description="Flag indicating if the report is comparable",
        alias="isComparable",
    )
    name: Optional[pd.StringDtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Name of the report view",
        alias="name",
    )
    description: Optional[pd.StringDtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Description of the report view",
        alias="description",
    )
    schedule_status: Optional[pd.StringDtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Scheduling status of the report view",
        alias="scheduleStatus",
    )
    is_scheduled: pd.BooleanDtype = pa.Field(
        coerce=True,
        description="Flag indicating if the report is scheduled",
        alias="isScheduled",
    )
    id: pd.StringDtype = pa.Field(
        coerce=True,
        description="Report identifier",
        alias="id",
    )
    type: pd.StringDtype = pa.Field(
        coerce=True,
        description="Type of the report",
        alias="type",
    )
    creation_date: str = pa.Field(
        coerce=True,
        description="Creation date of the report view",
        alias="creationDate",
    )
    folder_id: pd.Int64Dtype = pa.Field(
        coerce=True,
        description="Identifier of the folder containing the report view",
        alias="folderId",
    )

    class Config:
        coerce = True

    class _Annotation:
        primary_key = "id"
