from datetime import datetime
from typing import Optional

import pandas as pd
import pandera as pa

from brynq_sdk_functions import BrynQPanderaDataFrameModel

class WorkGet(BrynQPanderaDataFrameModel):
    can_be_deleted: pd.BooleanDtype = pa.Field(coerce=True, description="Can Be Deleted", alias="canBeDeleted")
    work_change_type: pd.StringDtype = pa.Field(coerce=True, description="Work Change Type", alias="workChangeType")
    creation_date: datetime = pa.Field(coerce=True, nullable=True, description="Creation Date", alias="creationDate")
    title: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Title", alias="title")
    is_current: pd.BooleanDtype = pa.Field(coerce=True, description="Is Current", alias="isCurrent")
    modification_date: datetime = pa.Field(coerce=True, nullable=True, description="Modification Date", alias="modificationDate")
    site: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Site", alias="site")
    site_id: pd.Int64Dtype = pa.Field(coerce=True, description="Site ID", alias="siteId")
    id: pd.Int64Dtype = pa.Field(coerce=True, description="ID", alias="id")
    end_effective_date: datetime = pa.Field(coerce=True, nullable=True, description="End Effective Date", alias="endEffectiveDate")
    active_effective_date: datetime = pa.Field(coerce=True, nullable=True, description="Active Effective Date", alias="activeEffectiveDate")
    department: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Department", alias="department")
    effective_date: datetime = pa.Field(coerce=True, nullable=True, description="Effective Date", alias="effectiveDate")
    change_changed_by: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Change Changed By", alias="change.changedBy")
    change_changed_by_id: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Change Changed By ID", alias="change.changedById")
    reports_to_id: Optional[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Reports To ID", alias="reportsTo.id")
    reports_to_first_name: Optional[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Reports To First Name", alias="reportsTo.firstName")
    reports_to_surname: Optional[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Reports To Surname", alias="reportsTo.surname")
    reports_to_email: Optional[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Reports To Email", alias="reportsTo.email")
    reports_to_display_name: Optional[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Reports To Display Name", alias="reportsTo.displayName")
    reports_to: Optional[pd.Int64Dtype] = pa.Field(coerce=True, nullable=True, description="Reports To", alias="reportsTo")
    employee_id: pd.StringDtype = pa.Field(coerce=True, description="Employee ID", alias="employeeId")

    class Config:
        coerce = True
