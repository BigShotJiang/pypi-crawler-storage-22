import pandas as pd
import requests
from brynq_sdk_functions import Functions
from .schemas.work import WorkGet


class Work:
    def __init__(self, client):
        self.client = client
        self.schema = WorkGet

    def get(self) -> tuple[pd.DataFrame, pd.DataFrame]:
        request = requests.Request(method='GET',
                                   url=f"{self.client.base_url}bulk/people/work",
                                   params={"includeArchived": "true"})
        data = self.client.get_paginated_result(request)
        df = pd.json_normalize(
            data,
            record_path='values',
            meta=['employeeId']
        )
        valid_work, invalid_work = Functions.validate_data(df=df, schema=self.schema, debug=True)

        return valid_work, invalid_work
