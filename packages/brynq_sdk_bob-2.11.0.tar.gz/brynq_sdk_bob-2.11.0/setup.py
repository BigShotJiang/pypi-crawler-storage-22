from setuptools import find_namespace_packages, setup

setup(
    name='brynq_sdk_bob',
    version='2.11.0',
    description='Bob wrapper from BrynQ',
    long_description='Bob wrapper from BrynQ',
    author='BrynQ',
    author_email='support@brynq.com',
    packages=find_namespace_packages(include=['brynq_sdk*']),
    license='BrynQ License',
    install_requires=[
        'brynq-sdk-brynq>=4,<5',
        'brynq-sdk-functions>=2.0.5',
        'pandas>=2.2.0,<3.0.0',
        'pydantic>=2.5.0,<3.0.0',
        'pandera>=0.16.0,<1.0.0',
    ],
    zip_safe=False,
)
