# Auto-generated schemas for category: job_catalog

import pandas as pd
import pandera as pa
import pandera.extensions as extensions
from brynq_sdk_functions import BrynQPanderaDataFrameModel
from typing import Optional, Annotated
from pydantic import BaseModel, Field, StringConstraints

class LevelsGet(BrynQPanderaDataFrameModel):
    id: pd.Int64Dtype = pa.Field(coerce=True, nullable=False, description="identifier for the job catalog level.", alias="id")
    role_id: pd.Int64Dtype = pa.Field(coerce=True, nullable=False, description="identifier for the job catalog role.", alias="role_id")
    name: pd.StringDtype = pa.Field(coerce=True, nullable=False, description="Level name.", alias="name")
    role_name: pd.StringDtype = pa.Field(coerce=True, nullable=False, description="Role name.", alias="role_name")
    order: pd.Int64Dtype = pa.Field(coerce=True, nullable=False, description="Order of the level.", alias="order")
    archived: pd.BooleanDtype = pa.Field(coerce=True, nullable=False, description="Shows if the role is archived.", alias="archived")
    is_default: pd.BooleanDtype = pa.Field(coerce=True, nullable=False, description="Shows if the level is the default one.", alias="is_default")

class RolesGet(BrynQPanderaDataFrameModel):
    id: pd.Int64Dtype = pa.Field(coerce=True, nullable=False, description="identifier for the job catalog role.", alias="id")
    company_id: pd.Int64Dtype = pa.Field(coerce=True, nullable=False, description="Identifier for the company.", alias="company_id")
    name: pd.StringDtype = pa.Field(coerce=True, nullable=False, description="Role name.", alias="name")
    description: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Role description.", alias="description")
    legal_entities_ids: pd.StringDtype = pa.Field(coerce=True, nullable=False, description="List of legal entities.", alias="legal_entities_ids")
    supervisors_ids: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="List of supervisors.", alias="supervisors_ids")
    competencies_ids: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="List of competencies.", alias="competencies_ids")
    archived: pd.BooleanDtype = pa.Field(coerce=True, nullable=False, description="Shows if the role is archived.", alias="archived")

class LevelsDelete(BaseModel):
    id: int = Field(..., description="ID", alias="id")

class RolesDelete(BaseModel):
    id: int = Field(..., description="ID", alias="id")

