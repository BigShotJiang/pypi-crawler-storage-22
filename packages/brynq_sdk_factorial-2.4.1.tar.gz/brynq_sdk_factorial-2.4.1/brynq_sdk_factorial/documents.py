import mimetypes
import os
import requests
import pandas as pd


class Documents:
    def __init__(self, factorial):
        self.factorial = factorial
        self.base_url = self.factorial.base_url
        self.base_endpoint = '/resources/documents/documents'
        self.folders_endpoint = '/resources/documents/folders'

    def get(self,
            by_pending_assignment: str = 'false',
            employee_ids: list[str] = None) -> pd.DataFrame:
        # Use locals() to get all function parameters as a dictionary. Do not move this down since it will include all variables in function scope
        func_params = list(locals().items())
        params = {}
        for param, value in func_params:
            if param != 'self' and value is not None:
                if isinstance(value, list):
                    params[f'{param}[]'] = value
                else:
                    params[param] = value

        has_next_page = True
        result_data = pd.DataFrame()
        while has_next_page:
            response = self.factorial.session.get(url=f'{self.base_url}{self.base_endpoint}',
                                                  params=params,
                                                  timeout=self.factorial.timeout)
            response.raise_for_status()
            response_data = response.json()
            result_data = pd.concat([result_data, pd.DataFrame(response_data['data'])])
            has_next_page = response_data['meta']['has_next_page']
            if has_next_page:
                params['after_id'] = response_data['meta']['end_cursor']

        return result_data

    def get_folders(self) -> pd.DataFrame:
        has_next_page = True
        result_data = pd.DataFrame()
        params = {}
        while has_next_page:
            response = self.factorial.session.get(url=f'{self.base_url}{self.folders_endpoint}',
                                                  params=params,
                                                  timeout=self.factorial.timeout)
            response.raise_for_status()
            response_data = response.json()
            result_data = pd.concat([result_data, pd.DataFrame(response_data['data'])])
            has_next_page = response_data['meta']['has_next_page']
            if has_next_page:
                params['after_id'] = response_data['meta']['end_cursor']

        return result_data

    def create(self,
               file_path: str,
               public: str,
               space: str,
               folder_id: str,
               is_pending_assignment: str,
               employee_id: str,
               author_id: str,
               company_id: str,
               request_esignature: bool = False) -> requests.Response:
        payload = {
            'public': public,
            'space': space,
            'folder_id': folder_id,
            'is_pending_assignment': is_pending_assignment,
            'employee_id': employee_id,
            'author_id': author_id,
            'company_id': company_id,
            'request_esignature': request_esignature,
        }

        file_name = os.path.basename(file_path)
        content_type, _ = mimetypes.guess_type(file_name)
        content_type = content_type or 'application/octet-stream'

        with open(file_path, 'rb') as file_binary:
            files = [('file', (file_name, file_binary, content_type))]
            response = self.factorial.session.post(url=f'{self.base_url}{self.base_endpoint}',
                                                   headers={'Content-Type': None},
                                                   data=payload,
                                                   files=files,
                                                   timeout=self.factorial.timeout)
        response.raise_for_status()
        return response

    def delete(self, document_id: str) -> requests.Response:
        response = self.factorial.session.delete(url=f'{self.base_url}{self.base_endpoint}/{document_id}', timeout=self.factorial.timeout)
        response.raise_for_status()
        return response
