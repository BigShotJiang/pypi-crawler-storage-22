# Schemas for implemented documents endpoints

import pandas as pd
import pandera as pa
import pandera.extensions as extensions
from brynq_sdk_functions import BrynQPanderaDataFrameModel
from pydantic import BaseModel, Field


class DocumentsGet(BrynQPanderaDataFrameModel):
    author_id: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="access identifier of the author, refers to /employees/employees endpoint.", alias="author_id")
    company_id: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="company identifier, refers to /api/me endpoint.", alias="company_id")
    content_type: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="document content type.", alias="content_type")
    created_at: pd.StringDtype = pa.Field(coerce=True, nullable=False, description="creation date of the document.", alias="created_at")
    employee_id: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="employee identifier associated to the document.", alias="employee_id")
    extension: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="document extension.", alias="extension")
    file_size: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="document file size in bytes.", alias="file_size")
    filename: pd.StringDtype = pa.Field(coerce=True, nullable=False, description="name of the document.", alias="filename")
    folder_id: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="folder identifier, references to documents/folders endpoint.", alias="folder_id")
    id: pd.Int64Dtype = pa.Field(coerce=True, nullable=False, description="document identifier.", alias="id")
    is_company_document: pd.BooleanDtype = pa.Field(coerce=True, nullable=True, description="flag that indicates if the document is a company document.", alias="is_company_document")
    is_management_document: pd.BooleanDtype = pa.Field(coerce=True, nullable=True, description="flag that indicates if the document is a management document.", alias="is_management_document")
    is_pending_assignment: pd.BooleanDtype = pa.Field(coerce=True, nullable=True, description="flag that indicates if the document is pending assignment.", alias="is_pending_assignment")
    leave_id: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="leave identifier associated to the document, refers to /timeoff/leaves endpoint.", alias="leave_id")
    public: pd.BooleanDtype = pa.Field(coerce=True, nullable=False, description="flag to indicate if the document is public.", alias="public")
    signature_status: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="document signature status.", alias="signature_status")
    signees: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="list of signee access identifiers associated to the document, refers to /employees/employees endpoint.", alias="signees")
    space: pd.StringDtype = pa.Field(coerce=True, nullable=False, description="document space.", alias="space")
    updated_at: pd.StringDtype = pa.Field(coerce=True, nullable=False, description="last update date of the document.", alias="updated_at")
    deleted_at: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="deletion date of the document.", alias="deleted_at")

class FoldersGet(BrynQPanderaDataFrameModel):
    active: pd.BooleanDtype = pa.Field(coerce=True, nullable=False, description="Whether the folder is active or not", alias="active")
    company_id: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="Company ID of the folder", alias="company_id")
    id: pd.Int64Dtype = pa.Field(coerce=True, nullable=False, description="Folder ID", alias="id")
    name: pd.StringDtype = pa.Field(coerce=True, nullable=False, description="Folder name", alias="name")
    parent_folder_id: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="Id of the parent folder", alias="parent_folder_id")
    space: pd.StringDtype = pa.Field(coerce=True, nullable=False, description="The space of the folder is related to the place where the folder is displayed.", alias="space")

class DocumentsCreate(BaseModel):
    file_path: str = Field(..., description='Local path to the file that will be uploaded', alias='file_path')
    public: bool = Field(..., description='String flag, e.g. "false"', alias='public')
    space: str = Field(..., description='Space, e.g. "employee_my_documents"', alias='space')
    folder_id: str = Field(..., description='Folder ID as string', alias='folder_id')
    is_pending_assignment: bool = Field(..., description='String flag, e.g. "false"', alias='is_pending_assignment')
    employee_id: str = Field(..., description='Employee ID as string', alias='employee_id')
    author_id: str = Field(..., description='Author ID as string', alias='author_id')
    company_id: str = Field(..., description='Company ID as string', alias='company_id')
    request_esignature: bool = Field(..., description='String flag, e.g. "false"', alias='request_esignature')


class DocumentsDelete(BaseModel):
    id: int = Field(..., description="ID", alias="id")

class FoldersCreate(BaseModel):
    company_id: int = Field(..., description="Company ID", alias="company_id")
    name: str = Field(..., description="Folder name", alias="name")
    space: str = Field(..., description='The space of the folder is related to the type of documents that will be stored in it. You should always use employee_my_documents', alias="space")

class FoldersUpdate(BaseModel):
    id: int = Field(..., description="ID", alias="id")
    active: bool = Field(..., description="Whether the folder is active or not", alias="active")
    company_id: Optional[int] = Field(None, description="Company ID of the folder", alias="company_id")
    name: str = Field(..., description="Folder name", alias="name")
    parent_folder_id: Optional[int] = Field(None, description="Id of the parent folder", alias="parent_folder_id")
    space: str = Field(..., description="The space of the folder is related to the place where the folder is displayed.", alias="space")

class FoldersDelete(BaseModel):
    id: int = Field(..., description="ID", alias="id")
