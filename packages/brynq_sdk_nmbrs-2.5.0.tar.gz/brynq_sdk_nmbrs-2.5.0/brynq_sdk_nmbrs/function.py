from typing import Any, Dict, Union

import pandas as pd
import requests
from zeep.exceptions import Fault
from zeep.helpers import serialize_object

from brynq_sdk_functions import Functions as BrynQFunctions

from .schemas.function import (
    EmployeeFunctionGet,
    FunctionGet,
    FunctionUpdate,
)


class EmployeeFunction:
    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self,
            created_from: str = None) -> tuple[pd.DataFrame, pd.DataFrame]:
        functions = pd.DataFrame()
        for company in self.nmbrs.company_ids:
            functions = pd.concat([functions, self._get(company, created_from)])

        valid_functions, invalid_functions = BrynQFunctions.validate_data(df=functions, schema=EmployeeFunctionGet, debug=True)

        return valid_functions, invalid_functions

    def _get(self,
            company_id: str,
            created_from: str = None) -> pd.DataFrame:
        params = {}
        if created_from:
            params['createdFrom'] = created_from
        try:
            request = requests.Request(method='GET', url=f"{self.nmbrs.base_url}companies/{company_id}/employees/functions", params=params)
            data = self.nmbrs.get_paginated_result(request)
            df = pd.json_normalize(
                data,
                record_path='functions',
                meta=['employeeId']
            )
        except requests.HTTPError:
            df = pd.DataFrame()
        return df

    def update(self, employee_id: str, data: Dict[str, Any]):
        """
        Update a function for an employee using Pydantic validation.

        Args:
            employee_id: The ID of the employee
            data: Dictionary containing function data with fields matching
                 the FunctionUpdate schema (using camelCase field names)

        Returns:
            Response from the API
        """
        # Validate with Pydantic model
        nested_data = self.nmbrs.flat_dict_to_nested_dict(data, FunctionUpdate)
        function_model = FunctionUpdate(**nested_data)

        # Convert validated model to dict for API payload
        payload = function_model.model_dump(exclude_none=True, by_alias=True)

        # Send request
        resp = self.nmbrs.session.put(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/function",
            json=payload,
            timeout=self.nmbrs.timeout
        )
        return resp

    def get_current(self, employee_id: Union[int, str]) -> pd.DataFrame:
        """
        Get current function for a specific employee using SOAP API.

        Args:
            employee_id: The ID of the employee

        Returns:
            DataFrame with current function
        """
        try:
            response = self.nmbrs.soap_client_employees.service.Function_GetCurrent(
                EmployeeId=int(employee_id),
                _soapheaders={'AuthHeaderWithDomain': self.nmbrs.soap_auth_header_employees}
            )

            if response:
                serialized = serialize_object(response)
                if not isinstance(serialized, list):
                    serialized = [serialized]
                df = pd.DataFrame(serialized)
                df['employee_id'] = str(employee_id)
                return df
            else:
                return pd.DataFrame()

        except Fault as e:
            raise Exception(f"SOAP request failed: {str(e)}")


class Functions:
    """
    Master Functions (Debtor level) - manages function definitions.
    Uses DebtorService SOAP API for create, update, delete.
    """
    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self, debtor_id: str = None) -> tuple[pd.DataFrame, pd.DataFrame]:
        """
        Get all functions for debtor(s).

        Args:
            debtor_id: Optional debtor ID. If not provided, fetches for all debtors.

        Returns:
            Tuple of (valid_functions, invalid_functions) DataFrames
        """
        if debtor_id:
            df = self._get(debtor_id)
        else:
            df = pd.DataFrame()
            for debtor in self.nmbrs.debtor_ids:
                df = pd.concat([df, self._get(debtor)])

        if df.empty:
            return df, pd.DataFrame()

        valid_functions, invalid_functions = BrynQFunctions.validate_data(df=df, schema=FunctionGet, debug=self.nmbrs.debug)
        return valid_functions, invalid_functions

    def _get(self, debtor_id: str) -> pd.DataFrame:
        """
        Internal method to get functions for a single debtor.
        """
        try:
            request = requests.Request(method='GET',
                                       url=f"{self.nmbrs.base_url}debtors/{debtor_id}/functions",
                                       params={"includeArchived": "true"})

            data = self.nmbrs.get_paginated_result(request)
            df = pd.DataFrame(data)
            df['debtorId'] = debtor_id

        except requests.HTTPError:
            df = pd.DataFrame()

        return df
