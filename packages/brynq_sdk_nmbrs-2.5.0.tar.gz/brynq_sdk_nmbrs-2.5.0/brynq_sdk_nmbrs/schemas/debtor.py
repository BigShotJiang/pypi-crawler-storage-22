import pandera as pa
from pandera.typing import Series, String

from brynq_sdk_functions import BrynQPanderaDataFrameModel


# ---------------------------
# Get Schemas
# ---------------------------
class DebtorsGet(BrynQPanderaDataFrameModel):
    debtor_id: Series[String] = pa.Field(coerce=True, description="Debtor ID", alias="debtorId")
    number: Series[String] = pa.Field(coerce=True, description="Debtor number", alias="number")
    name: Series[String] = pa.Field(coerce=True, description="Debtor name", alias="name")

    class _Annotation:
        primary_key = "debtor_id"
