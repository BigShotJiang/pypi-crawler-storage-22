from typing import Literal, Optional

import pandas as pd
import pandera as pa
from pydantic import BaseModel, ConfigDict, Field

from brynq_sdk_functions import BrynQPanderaDataFrameModel


# ---------------------------
# Get Schemas - Employee Wage Tax Settings
# ---------------------------
class EmployeeWageTaxSettingsGet(BrynQPanderaDataFrameModel):
    """Schema for validating employee wage tax settings data."""
    employee_id: pd.StringDtype = pa.Field(coerce=True, description="Employee ID", alias="employeeId")
    wage_tax_settings_id: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Wage tax settings ID", alias="wageTaxSettingsId")
    wage_tax: pd.BooleanDtype = pa.Field(coerce=True, nullable=True, description="Wage tax", alias="wageTax")
    wage_tax_rebate: pd.BooleanDtype = pa.Field(coerce=True, nullable=True, description="Wage tax rebate (Loonheffingskorting)", alias="wageTaxRebate")
    single_elderly_discount: pd.BooleanDtype = pa.Field(coerce=True, nullable=True, description="Single elderly discount", alias="singleElderlyDiscount")
    color_table: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Color table (White/Green)", alias="colorTable")
    period_table: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Period table (Month/Week/4Week/Day)", alias="periodTable")
    income_type: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Income type", alias="incomeType")
    special_annual_salary_rate: pd.Float64Dtype = pa.Field(coerce=True, nullable=True, description="Special annual salary rate (Loonheffing BT)", alias="specialAnnualSalaryRate")
    special_table: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Special table", alias="specialTable")
    different_special_rate: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Different special rate (Afwijkend Bijzonder tarief %)", alias="differentSpecialRate")
    period_year: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="Period year", alias="period.year")
    period_period: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="Period", alias="period.period")
    created_at: str = pa.Field(coerce=True, nullable=True, description="Created at", alias="createdAt")

    class _Annotation:
        primary_key = "wage_tax_settings_id"
        foreign_keys = {
            "employee_id": {
                "parent_schema": "EmployeeSchema",
                "parent_column": "employee_id",
                "cardinality": "1:N"
            }
        }


# ---------------------------
# Create/Update Schemas
# ---------------------------
class Period(BaseModel):
    """Period model for specifying year and period."""
    model_config = ConfigDict(populate_by_name=True)

    year: int = Field(..., ge=1900, le=2100, example=2021, description="Year", alias="year")
    period: int = Field(..., ge=1, le=53, example=4, description="Period", alias="period")


class Calc30PercentRuling(BaseModel):
    """30 percent ruling settings."""
    model_config = ConfigDict(populate_by_name=True)

    cal_30_percent_ruling: Optional[str] = Field(None, example="None", description="30% ruling type", alias="Cal30PercentRuling")
    end_period: Optional[int] = Field(None, ge=1, le=53, example=12, description="End period", alias="endPeriod")
    end_year: Optional[int] = Field(None, ge=1900, le=2100, example=2025, description="End year", alias="endYear")


class EmployeeWageTaxSettingsCreate(BaseModel):
    """Schema for creating employee wage tax settings."""
    model_config = ConfigDict(populate_by_name=True)

    wage_tax: bool = Field(..., example=True, description="Wage tax", alias="wageTax")
    wage_tax_rebate: bool = Field(..., example=True, description="Wage tax rebate (Loonheffingskorting)", alias="wageTaxRebate")
    single_elderly_discount: bool = Field(..., example=False, description="Single elderly discount", alias="singleElderlyDiscount")
    color_table: Literal["White", "Green"] = Field(..., example="White", description="Color table", alias="colorTable")
    period_table: Literal["Month", "Week", "4Week", "Day"] = Field(..., example="Month", description="Period table", alias="periodTable")
    income_type: str = Field(..., example="11", description="Income type", alias="incomeType")
    special_annual_salary_rate: Optional[float] = Field(None, example=0.0, description="Special annual salary rate (Loonheffing BT)", alias="specialAnnualSalaryRate")
    special_table: str = Field(..., example="None", description="Special table", alias="specialTable")
    different_special_rate: Optional[float] = Field(None, example=0.0, description="Different special rate (Afwijkend Bijzonder tarief %)", alias="differentSpecialRate")
    calc_30_percent_ruling: Optional[Calc30PercentRuling] = Field(None, example={"Cal30PercentRuling": "None", "endPeriod": 12, "endYear": 2025}, description="30% ruling settings", alias="Calc30PercentRuling")
    period: Period = Field(..., example={"year": 2021, "period": 4}, description="Period to apply settings")
