from typing import Optional

import pandas as pd
import pandera as pa
from pydantic import BaseModel, ConfigDict, Field

from brynq_sdk_functions import BrynQPanderaDataFrameModel


# ---------------------------
# Get Schemas - Company SVW Settings
# ---------------------------
class CompanySVWSettingsGet(BrynQPanderaDataFrameModel):
    """Schema for validating company SVW settings data."""
    svw_settings_id: pd.StringDtype = pa.Field(coerce=True, description="SVW Settings ID", alias="SVWSettingsId")
    own_risk_dif_wga: pd.BooleanDtype = pa.Field(coerce=True, nullable=True, description="Own risk DIF WGA", alias="ownRiskDifWGA")
    own_risk_health_care: pd.BooleanDtype = pa.Field(coerce=True, nullable=True, description="Own risk health care", alias="ownRiskHealthCare")
    aof: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="AOF (Low/High)", alias="AOF")
    diff_wga_wn: pd.Float64Dtype = pa.Field(coerce=True, nullable=True, description="Diff WGA Wn", alias="diffWGAWn")
    diff_wga_wg: pd.Float64Dtype = pa.Field(coerce=True, nullable=True, description="Diff WGA Wg", alias="diffWGAWg")
    zw_wg: pd.Float64Dtype = pa.Field(coerce=True, nullable=True, description="ZW Wg", alias="zwWg")

    class _Annotation:
        primary_key = "svw_settings_id"


# ---------------------------
# Get Schemas - Employee SVW Settings
# ---------------------------
class EmployeeSVWSettingsGet(BrynQPanderaDataFrameModel):
    """Schema for validating employee SVW settings data."""
    employee_id: pd.StringDtype = pa.Field(coerce=True, description="Employee ID", alias="employeeId")
    zw: pd.BooleanDtype = pa.Field(coerce=True, nullable=True, description="ZW (Ziektewet)", alias="ZW")
    ww: pd.BooleanDtype = pa.Field(coerce=True, nullable=True, description="WW (Werkloosheidswet)", alias="WW")
    wao_wia: pd.BooleanDtype = pa.Field(coerce=True, nullable=True, description="WAO/WIA", alias="waoWia")
    nature_of_employment: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Nature of employment", alias="natureOfEmployment")
    phase_classification: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Phase classification", alias="phaseClassification")
    tax_sequence_number: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="Tax sequence number", alias="taxSequenceNumber")
    code_zvw: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Code ZVW", alias="codeZvw")
    income_related_contribution_zvw: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Income related contribution ZVW", alias="incomeRelatedContributionZvw")
    influence_obliged_insurance: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Influence obliged insurance", alias="influenceObligedInsurance")
    wage_cost_benefit_code: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="Wage cost benefit code", alias="wageCostBenefit.code")
    wage_cost_benefit_description: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Wage cost benefit description", alias="wageCostBenefit.description")
    wage_cost_benefit_end_period: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="Wage cost benefit end period", alias="wageCostBenefit.endPeriod")
    wage_cost_benefit_end_year: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="Wage cost benefit end year", alias="wageCostBenefit.endYear")
    cao_code: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="CAO code", alias="CAO.code")
    cao_description: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="CAO description", alias="CAO.CAODescription")
    hirer_cao_code: Optional[pd.Int64Dtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Hirer CAO code",
        alias="hirerCAO.code",
    )
    hirer_cao_description: Optional[pd.StringDtype] = pa.Field(
        coerce=True,
        nullable=True,
        description="Hirer CAO description",
        alias="hirerCAO.CAODescription",
    )
    period_year: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="Period year", alias="period.year")
    period_period: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="Period", alias="period.period")
    created_at: str = pa.Field(coerce=True, nullable=True, description="Created at", alias="createdAt")

    class _Annotation:
        primary_key = "employee_id"


# ---------------------------
# Create/Update Schemas
# ---------------------------
class Period(BaseModel):
    """Period model for specifying year and period."""
    model_config = ConfigDict(populate_by_name=True)

    period_year: int = Field(..., ge=1900, le=2100, example=2021, description="Year", alias="year")
    period_period: int = Field(..., ge=1, le=53, example=4, description="Period", alias="period")


class WageCostBenefit(BaseModel):
    """Wage cost benefit model."""
    model_config = ConfigDict(populate_by_name=True)

    code: Optional[int] = Field(None, example=1234, description="Wage cost benefit code", alias="code")
    end_period: Optional[int] = Field(None, ge=1, le=53, example=12, description="End period", alias="endPeriod")
    end_year: Optional[int] = Field(None, ge=1900, le=2100, example=2025, description="End year", alias="endYear")


class SVWSettingsCreate(BaseModel):
    """Schema for creating employee SVW settings."""
    model_config = ConfigDict(populate_by_name=True)

    zw: Optional[bool] = Field(None, example=True, description="ZW (Ziektewet)", alias="ZW")
    ww: Optional[bool] = Field(None, example=True, description="WW (Werkloosheidswet)", alias="WW")
    wao_wia: Optional[bool] = Field(None, example=True, description="WAO/WIA", alias="waoWia")
    nature_of_employment: int = Field(..., example=1, description="Nature of employment code (1, 4, 6, 7, 11, 18, 21, 22, 23, 24, 79, 81, 82, 83)", alias="natureOfEmployment")
    phase_classification: Optional[int] = Field(None, example=1, description="Phase classification (only for nature of employment 11)", alias="phaseClassification")
    code_zvw: str = Field(
        ...,
        pattern=r'^[ABGHIKLMN]$',
        example="A",
        description="Code ZVW (A, B, G, H, I, K, L, M, N)",
        alias="codeZvw",
    )
    tax_sequence_number: int = Field(..., ge=0, example=0, description="Tax sequence number", alias="taxSequenceNumber")
    income_related_contribution_zvw: int = Field(..., ge=0, example=0, description="Income related contribution ZVW", alias="incomeRelatedContributionZvw")
    influence_obliged_insurance: str = Field(
        ...,
        pattern=r'^[0ABDE]$',
        example="0",
        description="Influence obliged insurance (0, A, B, D, E)",
        alias="influenceObligedInsurance",
    )
    wage_cost_benefit_code: Optional[WageCostBenefit] = Field(None, example={"code": 1234, "endPeriod": 12, "endYear": 2025}, description="Wage cost benefit", alias="wageCostBenefit")
    cao_code: Optional[int] = Field(None, example=100, description="CAO code", alias="CAO")
    hirer_cao_code: Optional[int] = Field(None, example=100, description="Hirer CAO code", alias="hirerCAO")
    period: Period = Field(..., example={"year": 2021, "period": 4}, description="Period to apply settings")
