import logging
from typing import TYPE_CHECKING, Optional

import pandas as pd
import requests
from zeep.exceptions import Fault
from zeep.helpers import serialize_object

from .bank import Bank
from .costcenter import Costcenter
from .costunit import Costunit
from .hours import Hours
from .leave import LeaveGroup

if TYPE_CHECKING:
    from brynq_sdk_nmbrs import Nmbrs


class Companies:
    def __init__(self, nmbrs):
        self.nmbrs: Nmbrs = nmbrs
        self.costcenters = Costcenter(nmbrs)
        self.costunits = Costunit(nmbrs)
        self.hours = Hours(nmbrs)
        self.banks = Bank(nmbrs)
        self.logger = logging.getLogger(__name__)
        self.leave_groups = LeaveGroup(nmbrs)

    @property
    def soap_client_companies(self):
        return self.nmbrs.soap_client_companies

    def get(self) -> pd.DataFrame:
        try:
            request = requests.Request(method='GET',
                                    url=f"{self.nmbrs.base_url}companies")
            data = self.nmbrs.get_paginated_result(request)
            df = pd.DataFrame(data)
        except requests.HTTPError as e:
            if e.response.status_code == 403 and e.response.json().get("title") == "ForbiddenMultiDebtor.":
                df = pd.DataFrame()
                for debtor_id in self.nmbrs.debtor_ids:
                    request = requests.Request(method='GET',
                                        url=f"{self.nmbrs.base_url}debtors/{debtor_id}/companies")
                    data = self.nmbrs.get_paginated_result(request)
                    df = pd.concat([df, pd.DataFrame(data)])
            else:
                raise e
        # TODO: add validation

        return df

    def get_soap_ids(self) -> pd.DataFrame:
        """
        Get all companies using the SOAP API.

        Returns:
            pd.DataFrame: DataFrame containing all companies
        """
        try:
            # Make SOAP request with the proper header structure
            response = self.nmbrs.soap_client_companies.service.List_GetAll(
                _soapheaders=[self.nmbrs.soap_auth_header]
            )

            # Convert response to DataFrame
            if response:
                # Convert Zeep objects to Python dictionaries
                serialized_response = serialize_object(response)

                # TODO: add validation here
                # Convert to DataFrame
                df = pd.DataFrame(serialized_response)
                df = self.nmbrs._rename_camel_columns_to_snake_case(df)

                return df
            else:
                return pd.DataFrame()

        except Fault as e:
            raise Exception(f"SOAP request failed: {str(e)}")
        except Exception as e:
            self.logger.exception("Exception occurred:")
            raise Exception(f"Failed to get companies: {str(e)}")

    def get_current_period(self) -> int:
        try:
            df = pd.DataFrame()
            for company_id in self.nmbrs.company_ids:
                request = requests.Request(method='GET',
                                    url=f"{self.nmbrs.base_url}companies/{company_id}/period")
                data = self.nmbrs.get_paginated_result(request)
                df_temp = pd.json_normalize(data)
                df_temp['company_id'] = company_id
                df = pd.concat([df, df_temp])

            return df
        except Exception as e:
            self.logger.exception("Exception occurred:")
            raise Exception(f"Failed to get current period: {str(e)}")

    def get_wage_models(self,
                        company_id: Optional[str] = None,
                        period: Optional[int] = None,
                        year: Optional[int] = None) -> pd.DataFrame:
        """
        Get company wage models per period.

        Returns the available wage codes for employees of this company in the
        period consulted. If no period is used it returns the current period information.

        Args:
            company_id: Optional company ID. If not provided, fetches for all companies.
            period: Optional period filter
            year: Optional year filter

        Returns:
            DataFrame containing wage models
        """
        if company_id:
            return self._get_wage_models(company_id, period, year)

        df = pd.DataFrame()
        for company in self.nmbrs.company_ids:
            df = pd.concat([df, self._get_wage_models(company, period, year)])

        return df

    def _get_wage_models(self,
                         company_id: str,
                         period: Optional[int] = None,
                         year: Optional[int] = None) -> pd.DataFrame:
        """
        Internal method to get wage models for a single company.
        """
        params = {}
        if period is not None:
            params['period'] = period
        if year is not None:
            params['year'] = year

        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}companies/{company_id}/wagemodels",
            params=params
        )

        data = self.nmbrs.get_paginated_result(request)
        df = pd.DataFrame(data)

        if not df.empty:
            df['companyId'] = company_id

        return df

    def get_addresses(self, company_id: Optional[str] = None) -> pd.DataFrame:
        """
        Get addresses history for a company.

        Args:
            company_id: Optional company ID. If not provided, fetches for all companies.

        Returns:
            DataFrame containing company addresses
        """
        if company_id:
            return self._get_addresses(company_id)

        df = pd.DataFrame()
        for company in self.nmbrs.company_ids:
            df = pd.concat([df, self._get_addresses(company)])

        return df

    def _get_addresses(self, company_id: str) -> pd.DataFrame:
        """
        Internal method to get addresses for a single company.
        """
        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}companies/{company_id}/addresses"
        )

        data = self.nmbrs.get_paginated_result(request)
        df = pd.DataFrame(data)

        if not df.empty:
            df['companyId'] = company_id

        return df

    def get_contact_persons(self, company_id: Optional[str] = None) -> pd.DataFrame:
        """
        Get contact persons for a company.

        There's no history on these values.

        Args:
            company_id: Optional company ID. If not provided, fetches for all companies.

        Returns:
            DataFrame containing contact persons
        """
        if company_id:
            return self._get_contact_persons(company_id)

        df = pd.DataFrame()
        for company in self.nmbrs.company_ids:
            df = pd.concat([df, self._get_contact_persons(company)])

        return df

    def _get_contact_persons(self, company_id: str) -> pd.DataFrame:
        """
        Internal method to get contact persons for a single company.
        """
        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}companies/{company_id}/contactpersons"
        )

        data = self.nmbrs.get_paginated_result(request)
        df = pd.DataFrame(data)

        if not df.empty:
            df['companyId'] = company_id

        return df
