
import pandas as pd
import requests

from brynq_sdk_functions import Functions

from .department import Departments
from .function import Functions as NmbrsFunctions
from .schemas.debtor import DebtorsGet


class Debtors:
    """
    Class for handling debtor information.

    Endpoints:
        - GET /api/debtors
        - GET /api/debtors/info
        - GET /api/debtors/endcontractreasons/{Year}
    """

    def __init__(self, nmbrs):
        self.nmbrs = nmbrs
        self.departments = Departments(nmbrs)
        self.functions = NmbrsFunctions(nmbrs)

    def get(self) -> tuple:
        """
        Get a list of all debtors for the authenticated user.

        Returns:
            Tuple of (valid_data, invalid_data) DataFrames
        """
        request = requests.Request(method='GET',
                                   url=f"{self.nmbrs.base_url}debtors")
        data = self.nmbrs.get_paginated_result(request)

        df = pd.DataFrame(data)

        valid_debtors, invalid_debtors = Functions.validate_data(df=df, schema=DebtorsGet, debug=True)

        return valid_debtors, invalid_debtors

    def get_info(self) -> pd.DataFrame:
        """
        Get information about the authenticated debtor.

        Returns info about the debtor that the API keys belong to,
        including current settings and subscription details.

        Returns:
            DataFrame containing debtor info
        """
        resp = self.nmbrs.session.get(
            url=f"{self.nmbrs.base_url}debtors/info",
            timeout=self.nmbrs.timeout
        )
        resp.raise_for_status()
        data = resp.json()

        # Normalize the response if it's a dict
        if isinstance(data, dict):
            df = pd.json_normalize(data)
        else:
            df = pd.DataFrame(data)

        return df

    def get_end_contract_reasons(self, year: int) -> pd.DataFrame:
        """
        Get the available end contract reasons for a specific year.

        Args:
            year: The year to get end contract reasons for

        Returns:
            DataFrame containing end contract reasons
        """
        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}debtors/endcontractreasons/{year}"
        )

        data = self.nmbrs.get_paginated_result(request)
        df = pd.DataFrame(data)

        return df
