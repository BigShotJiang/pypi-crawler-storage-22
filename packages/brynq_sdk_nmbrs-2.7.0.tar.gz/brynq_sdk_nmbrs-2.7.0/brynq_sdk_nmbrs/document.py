import base64
from io import BytesIO
from typing import Any, BinaryIO, Dict, Optional

import pandas as pd
import requests
from zeep.exceptions import Fault

from .schemas.document import DocumentUpload


class EmployeeDocument:
    """Handle employee document operations via SOAP API."""

    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def upload(self, data: Dict[str, Any], file_content: bytes) -> bool:
        """
        Upload a document to an employee using SOAP API.

        Args:
            data: Dictionary containing document data with fields matching DocumentUpload schema:
                - employee_id: Employee ID
                - document_name: Document name (with extension, e.g., "contract.pdf")
                - document_type_guid: Document type GUID
            file_content: Binary content of the file to upload

        Returns:
            True if upload was successful
        """
        doc_model = DocumentUpload(**data)

        if self.nmbrs.mock_mode:
            return True

        try:
            # Convert file content to base64
            body_base64 = base64.b64encode(file_content)

            response = self.nmbrs.soap_client_employees.service.EmployeeDocument_UploadDocument(
                EmployeeId=doc_model.employee_id,
                StrDocumentName=doc_model.document_name,
                Body=body_base64,
                GuidDocumentType=doc_model.document_type_guid,
                _soapheaders={'AuthHeaderWithDomain': self.nmbrs.soap_auth_header_employees}
            )

            return response

        except Fault as e:
            raise Exception(f"SOAP request failed: {str(e)}")
        except Exception as e:
            raise Exception(f"Failed to upload document: {str(e)}")


class Payslip:
    """
    Class for handling employee payslips.

    Endpoints:
        - GET /api/employees/{employeeId}/payslipperperiod
    """

    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self,
            employee_id: str,
            period: int = None,
            year: int = None) -> BytesIO:
        """
        Get an employee payslip per period.

        Args:
            employee_id: The ID of the employee
            period: Optional period number
            year: Optional year

        Returns:
            BytesIO containing the payslip PDF
        """
        params = {}
        if period:
            params['period'] = period
        if year:
            params['year'] = year
        resp = self.nmbrs.session.get(f"{self.nmbrs.base_url}employees/{employee_id}/payslipperperiod/",
                                      params=params,
                                      timeout=self.nmbrs.timeout)
        resp.raise_for_status()
        task_id = resp.json()['taskId']

        resp = self.nmbrs.session.get(f"{self.nmbrs.base_url}documents/{task_id}", timeout=self.nmbrs.timeout)

        return BytesIO(resp.content)


class Document:
    """
    Class for handling employee documents.

    Endpoints:
        - GET /api/employees/{employeeId}/annualstatement
        - GET /api/employees/{employeeId}/documents/types
        - GET /api/employees/{employeeId}/documents/folders
        - POST /api/employees/{employeeId}/documents
        - GET /api/documents/{taskId}
    """

    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get_annual_statement(self, employee_id: str, year: Optional[int] = None) -> BytesIO:
        """
        Get an employee annual statement for the given year.

        Args:
            employee_id: The ID of the employee
            year: Optional year filter

        Returns:
            BytesIO containing the annual statement PDF
        """
        params = {}
        if year is not None:
            params['year'] = year

        resp = self.nmbrs.session.get(
            f"{self.nmbrs.base_url}employees/{employee_id}/annualstatement",
            params=params,
            timeout=self.nmbrs.timeout
        )
        resp.raise_for_status()
        task_id = resp.json()['taskId']

        # Retrieve the actual document content
        resp = self.nmbrs.session.get(
            f"{self.nmbrs.base_url}documents/{task_id}",
            timeout=self.nmbrs.timeout
        )

        return BytesIO(resp.content)

    def get_types(self, employee_id: str) -> pd.DataFrame:
        """
        Get the document types available for a specific employee.

        Args:
            employee_id: The ID of the employee

        Returns:
            DataFrame containing document types
        """
        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}employees/{employee_id}/documents/types"
        )

        data = self.nmbrs.get_paginated_result(request)
        return pd.DataFrame(data)

    def get_folders(self, employee_id: str) -> pd.DataFrame:
        """
        Get document folders for a specific employee.

        Args:
            employee_id: The ID of the employee

        Returns:
            DataFrame containing document folders
        """
        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}employees/{employee_id}/documents/folders"
        )

        data = self.nmbrs.get_paginated_result(request)
        return pd.DataFrame(data)

    def upload(self,
               employee_id: str,
               file: BinaryIO,
               file_name: str,
               file_extension: str,
               document_type: str,
               description: Optional[str] = None,
               number: Optional[str] = None,
               is_visible_for_employee: Optional[bool] = None,
               folder: Optional[str] = None,
               valid_from: Optional[str] = None,
               valid_to: Optional[str] = None):
        """
        Upload a document for a specific employee.

        Args:
            employee_id: The ID of the employee
            file: Binary file content to upload
            file_name: Name of the file
            file_extension: Extension of the file (e.g., "pdf", "docx")
            document_type: Type of the document
            description: Optional description of the document
            number: Optional document number
            is_visible_for_employee: Optional flag if document is visible for employee
            folder: Optional folder UUID to place document in
            valid_from: Optional valid from date (ISO format)
            valid_to: Optional valid to date (ISO format)

        Returns:
            Response from the API
        """
        if self.nmbrs.mock_mode:
            return {
                'employee_id': employee_id,
                'file_name': file_name,
                'file_extension': file_extension,
                'document_type': document_type,
                'description': description
            }

        # Prepare multipart form data
        files = {
            'file': (file_name, file)
        }

        data = {
            'fileName': file_name,
            'fileExtension': file_extension,
            'type': document_type
        }

        if description is not None:
            data['description'] = description
        if number is not None:
            data['number'] = number
        if is_visible_for_employee is not None:
            data['isVisibleForEmployee'] = str(is_visible_for_employee).lower()
        if folder is not None:
            data['folder'] = folder
        if valid_from is not None:
            data['validFrom'] = valid_from
        if valid_to is not None:
            data['validTo'] = valid_to

        resp = self.nmbrs.session.post(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/documents",
            data=data,
            files=files,
            timeout=self.nmbrs.timeout
        )
        resp.raise_for_status()
        return resp.json()

    def get_content(self, task_id: str) -> BytesIO:
        """
        Get document content by task ID.

        Use this to retrieve documents after getting a task ID from other endpoints.

        Args:
            task_id: The task ID from a previous document request

        Returns:
            BytesIO containing the document content
        """
        resp = self.nmbrs.session.get(
            f"{self.nmbrs.base_url}documents/{task_id}",
            timeout=self.nmbrs.timeout
        )

        return BytesIO(resp.content)
