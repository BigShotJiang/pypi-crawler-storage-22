import pandas as pd
import requests
from typing import Optional
from .schemas.extra_fields import ExtraFieldSettingsGet, EmployeeExtraFieldsGet
from brynq_sdk_functions import Functions


class ExtraFieldSettings:
    """
    Class for handling company-level extra field settings.

    Endpoints:
        - GET /api/companies/{companyId}/extrafieldSettings
    """

    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self, company_id: Optional[str] = None) -> tuple:
        """
        Get extra field settings for a company.

        Args:
            company_id: Optional company ID. If not provided, fetches for all companies.

        Returns:
            Tuple of (valid_data, invalid_data) DataFrames
        """
        if company_id:
            df = self._get(company_id)
        else:
            df = pd.DataFrame()
            for company in self.nmbrs.company_ids:
                df = pd.concat([df, self._get(company)])

        if df.empty:
            return df, pd.DataFrame()

        valid_data, invalid_data = Functions.validate_data(df=df, schema=ExtraFieldSettingsGet, debug=self.nmbrs.debug)
        return valid_data, invalid_data

    def _get(self, company_id: str) -> pd.DataFrame:
        """
        Internal method to get extra field settings for a single company.
        """
        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}companies/{company_id}/extrafieldSettings"
        )

        data = self.nmbrs.get_paginated_result(request)
        df = pd.DataFrame(data)

        if not df.empty:
            df['companyId'] = company_id

        return df


class EmployeeExtraFields:
    """
    Class for handling employee extra fields.

    Endpoints:
        - GET /api/companies/{companyId}/employees/extraFields
    """

    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self,
            company_id: Optional[str] = None,
            extra_field_type: Optional[str] = None) -> tuple:
        """
        Get extra fields for employees of a company.

        Args:
            company_id: Optional company ID. If not provided, fetches for all companies.
            extra_field_type: Optional filter by extra field type
                              (text, decimal, number, date, yesNo, textDate)

        Returns:
            Tuple of (valid_data, invalid_data) DataFrames
        """
        if company_id:
            df = self._get(company_id, extra_field_type)
        else:
            df = pd.DataFrame()
            for company in self.nmbrs.company_ids:
                df = pd.concat([df, self._get(company, extra_field_type)])

        if df.empty:
            return df, pd.DataFrame()

        valid_data, invalid_data = Functions.validate_data(df=df, schema=EmployeeExtraFieldsGet, debug=self.nmbrs.debug)
        return valid_data, invalid_data

    def _get(self,
             company_id: str,
             extra_field_type: Optional[str] = None) -> pd.DataFrame:
        """
        Internal method to get employee extra fields for a single company.
        """
        params = {}
        if extra_field_type is not None:
            params['extraFieldType'] = extra_field_type

        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}companies/{company_id}/employees/extraFields",
            params=params
        )

        data = self.nmbrs.get_paginated_result(request)

        # Normalize nested data structure
        df = pd.json_normalize(
            data,
            record_path='extraFields',
            meta=['employeeId']
        )

        if not df.empty:
            df['companyId'] = company_id

        return df
