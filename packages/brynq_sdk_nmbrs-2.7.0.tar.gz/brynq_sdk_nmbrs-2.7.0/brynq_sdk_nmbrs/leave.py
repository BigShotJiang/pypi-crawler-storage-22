from typing import Any, Dict

import pandas as pd
import requests
from zeep.exceptions import Fault

from datetime import datetime
from brynq_sdk_functions import Functions

from .schemas.leave import (
    LeaveBalanceGet,
    LeaveCreate,
    LeaveDelete,
    LeaveGet,
    LeaveUpdate,
    LeaveGroupGet
)


class Leave:
    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self,
            changed_from: str = None,
            year: int = None) -> tuple[pd.DataFrame, pd.DataFrame]:
        
        if year is None:
            year = datetime.now().year

        leave = pd.DataFrame()
        for company in self.nmbrs.company_ids:
            for target_year in range(2020, year + 1):
                leave = pd.concat([leave, self._get(company, changed_from, target_year)])

        valid_leave, invalid_leave = Functions.validate_data(df=leave, schema=LeaveGet, debug=True)

        return valid_leave, invalid_leave

    def _get(self,
            company_id: str,
            changed_from: str = None,
            year: int = None) -> pd.DataFrame:
        params = {}
        if changed_from:
            params['changed_from'] = changed_from
        if year is not None:
            params['year'] = year
        try:
            request = requests.Request(method='GET',
                                       url=f"{self.nmbrs.base_url}companies/{company_id}/employees/leaverequests",
                                       params=params)

            data = self.nmbrs.get_paginated_result(request)
            df = pd.json_normalize(
                data,
                record_path='EmployeeLeaveRequests',
                meta=['employeeId']
            )
        except requests.HTTPError:
            df = pd.DataFrame()

        return df

    def create(self, employee_id: str, data: Dict[str, Any]):
        """
        Create a new leave request for an employee using Pydantic validation.

        Args:
            employee_id: The ID of the employee
            data: Dictionary containing leave request data in the format matching LeaveCreate schema

        Returns:
            Response from the API
        """
        # Validate with Pydantic model - this will raise an error if required fields are missing
        nested_data = self.nmbrs.flat_dict_to_nested_dict(data, LeaveCreate)
        leave_model = LeaveCreate(**nested_data)

        if self.nmbrs.mock_mode:
            return leave_model

        # Convert validated model to dict for API payload
        payload = leave_model.model_dump(exclude_none=True, by_alias=True, mode="json")


        # Send request
        resp = self.nmbrs.session.post(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/leaverequest",
            json=payload,
            timeout=self.nmbrs.timeout
        )
        return resp

    def delete(self, employee_id: str, leave_request_id: str):
        """
        Delete a leave request for an employee.

        Args:
            employee_id: The ID of the employee
            leave_request_id: The ID of the leave request to delete

        Returns:
            Response from the API
        """
        # Create and validate a BankDelete model
        leave_model = LeaveDelete(leave_request_id=leave_request_id)

        if self.nmbrs.mock_mode:
            return leave_model

        # Send request
        resp = self.nmbrs.session.delete(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/leave/{leave_request_id}",
            timeout=self.nmbrs.timeout
        )
        return resp

    def update(self, data: Dict[str, Any]):
        """
        Update a leave request for an employee using SOAP API.
        (REST API does not support leave update)

        Args:
            data: Dictionary containing leave data with fields matching LeaveUpdate schema:
                - employee_id: Employee ID
                - leave_id: Leave ID
                - start_date: Start date
                - end_date: End date
                - description: Optional description

        Returns:
            Response from the API
        """
        leave_model = LeaveUpdate(**data)

        if self.nmbrs.mock_mode:
            return leave_model

        try:
            resp = self.nmbrs.soap_client_employees.service.Leave_Update(
                EmployeeId=leave_model.employee_id,
                Leave={
                    'Id': leave_model.leave_id,
                    'Start': leave_model.start_date,
                    'End': leave_model.end_date,
                    'Description': leave_model.description or ''
                },
                _soapheaders={'AuthHeaderWithDomain': self.nmbrs.soap_auth_header_employees}
            )
            return resp
        except Fault as e:
            raise Exception(f"SOAP request failed: {str(e)}")


class LeaveBalance:
    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self,
            changed_from: str = None) -> tuple[pd.DataFrame, pd.DataFrame]:
        leave = pd.DataFrame()
        for company in self.nmbrs.company_ids:
            leave = pd.concat([leave, self._get(company, changed_from)])

        valid_leave, invalid_leave = Functions.validate_data(df=leave, schema=LeaveBalanceGet, debug=True)

        return valid_leave, invalid_leave

    def _get(self,
            company_id: str,
            changed_from: str = None) -> pd.DataFrame:
        """
        Note: changed_from parameter is accepted for consistency but not used
        by the leaveBalances endpoint.
        """
        try:
            request = requests.Request(method='GET',
                                       url=f"{self.nmbrs.base_url}companies/{company_id}/employees/leaveBalances")

            data = self.nmbrs.get_paginated_result(request)
            df = pd.json_normalize(
                data,
                record_path='leaveBalances',
                meta=['employeeId']
            )
        except requests.HTTPError:
            df = pd.DataFrame()

        return df


class LeaveGroup:
    """
    Class for handling company leave groups.

    Endpoints:
        - GET /api/companies/{companyId}/leaveGroups
    """

    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self, company_id: str = None) -> pd.DataFrame:
        """
        Get leave groups available in a company.

        A company can have up to 4 leave groups defined.

        Args:
            company_id: Optional company ID. If not provided, fetches for all companies.

        Returns:
            DataFrame containing leave groups
        """
        if company_id:
            return self._get(company_id)
        else:
            leave_groups = pd.DataFrame()
            for company in self.nmbrs.company_ids:
                leave_groups = pd.concat([leave_groups, self._get(company)])
        return Functions.validate_data(df=leave_groups, schema=LeaveGroupGet, debug=True)

    def _get(self, company_id: str) -> pd.DataFrame:
        """
        Internal method to get leave groups for a single company.
        """
        try:
            request = requests.Request(
                method='GET',
                url=f"{self.nmbrs.base_url}companies/{company_id}/leaveGroups"
            )

            data = self.nmbrs.get_paginated_result(request)
            df = pd.DataFrame(data)

            if not df.empty:
                df['companyId'] = company_id

            return df
        except requests.HTTPError:
            return pd.DataFrame()
