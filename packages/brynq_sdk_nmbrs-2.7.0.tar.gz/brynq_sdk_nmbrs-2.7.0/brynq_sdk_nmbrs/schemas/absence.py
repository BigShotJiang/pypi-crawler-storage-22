import math
import pandas as pd
import pandera as pa
from pandera import Bool
import pandera.extensions as extensions
from brynq_sdk_functions import BrynQPanderaDataFrameModel
from typing import Optional, Annotated
from pydantic import BaseModel, Field, StringConstraints
from datetime import datetime

#<AbsenceId>int</AbsenceId>
# <Comment>string</Comment>
# <Percentage>int</Percentage>
# <Start>dateTime</Start>
# <RegistrationStartDate>dateTime</RegistrationStartDate>
# <End>dateTime</End>
# <RegistrationEndDate>dateTime</RegistrationEndDate>
# <Dossier>string</Dossier>
# <Dossiernr>int</Dossiernr>

class AbsenceGet(BrynQPanderaDataFrameModel):
    employee_id: pd.Int64Dtype = pa.Field(coerce=True, description="Employee ID", alias="EmployeeId")
    absence_id: pd.Int64Dtype = pa.Field(coerce=True, description="Absence ID", alias="AbsenceId")
    comment: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Comment", alias="Comment")
    percentage: pd.Int64Dtype = pa.Field(coerce=True, description="Percentage", alias="Percentage")
    start: datetime = pa.Field(coerce=True, description="Start", alias="Start")
    registration_start_date: datetime = pa.Field(coerce=True, description="Registration Start Date", alias="RegistrationStartDate")
    end: datetime = pa.Field(coerce=True, nullable=True, description="End", alias="End")
    registration_end_date: datetime = pa.Field(coerce=True, nullable=True, description="Registration End Date", alias="RegistrationEndDate")
    dossier: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Dossier", alias="Dossier")
    dossiernr: pd.Int64Dtype = pa.Field(coerce=True, nullable=True, description="Dossier Number", alias="Dossiernr")

    class _Annotation:
        primary_key = "absence_id"
        foreign_keys = {
            "employee_id": {
                "parent_schema": "EmployeeSchema",
                "parent_column": "employee_id",
                "cardinality": "N:1"
            }
        }

class AbsenceCreate(BaseModel):
    employee_id: Optional[int] = Field(None, example=1234567890, description="Employee ID", alias="EmployeeId")
    absence_id: int = Field(..., example=1, description="Absence ID", alias="AbsenceId")
    comment: Optional[str] = Field(None, example="Sick leave", description="Comment", alias="Comment")
    percentage: int = Field(..., ge=0, le=100, example=100, description="Percentage", alias="Percentage")
    start: datetime = Field(..., example="2021-01-01T00:00:00Z", description="Start", alias="Start")
    registration_start_date: datetime = Field(..., example="2021-01-01T00:00:00Z", description="Registration Start Date", alias="RegistrationStartDate")
    end: Optional[datetime] = Field(None, example="2021-01-10T00:00:00Z", description="End", alias="End")
    registration_end_date: Optional[datetime] = Field(None, example="2021-01-10T00:00:00Z", description="Registration End Date", alias="RegistrationEndDate")
    dossier: Optional[str] = Field(None, example="Sick leave dossier", description="Dossier", alias="Dossier")
    dossiernr: Optional[int] = Field(None, example=1, description="Dossier Number", alias="Dossiernr")
    new_dossier: bool = Field(..., example=True, description="New Dossier", alias="NewDossier")

    def to_soap_settings(self, soap_client):
        """Convert to SOAP Absence object"""
        AbsenceType = soap_client.get_type(
            '{https://api.nmbrs.nl/soap/v3/EmployeeService}Absence'
        )

        # Get payload with alias renaming, excluding employee_id field
        payload = self.model_dump(exclude_none=True, by_alias=True, exclude={'employee_id', 'new_dossier'})

        return AbsenceType(**payload)

    class Config:
        populate_by_name = True
