import pandas as pd
import pandera as pa

from brynq_sdk_functions import BrynQPanderaDataFrameModel

# ---------------------------
# Get Schemas
# ---------------------------
class DebtorsGet(BrynQPanderaDataFrameModel):
    debtor_id: pd.StringDtype = pa.Field(coerce=True, description="Debtor ID", alias="debtorId")
    number: pd.StringDtype = pa.Field(coerce=True, description="Debtor number", alias="number")
    name: pd.StringDtype = pa.Field(coerce=True, description="Debtor name", alias="name")

    class _Annotation:
        primary_key = "debtor_id"
