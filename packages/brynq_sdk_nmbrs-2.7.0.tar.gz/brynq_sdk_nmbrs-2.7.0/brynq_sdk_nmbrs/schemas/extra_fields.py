import pandas as pd
import pandera as pa
from brynq_sdk_functions import BrynQPanderaDataFrameModel

# ---------------------------
# Get Schemas - Company Extra Field Settings
# ---------------------------
class ExtraFieldSettingsGet(BrynQPanderaDataFrameModel):
    """Schema for validating company extra field settings data."""
    extra_field_id: pd.StringDtype = pa.Field(coerce=True, description="Extra field ID", alias="extraFieldId")
    name: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Extra field name", alias="name")
    extra_field_type: pd.StringDtype = pa.Field(
        coerce=True,
        nullable=True,
        isin=["text", "decimal", "number", "date", "yesNo", "textDate"],
        description="Extra field type",
        alias="extraFieldType"
    )

    class _Annotation:
        primary_key = "extra_field_id"

# ---------------------------
# Get Schemas - Employee Extra Fields
# ---------------------------
class EmployeeExtraFieldsGet(BrynQPanderaDataFrameModel):
    """Schema for validating employee extra fields data."""
    employee_id: pd.StringDtype = pa.Field(coerce=True, description="Employee ID", alias="employeeId")
    extra_field_id: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Extra field ID", alias="extraField.extraFieldId")
    extra_field_name: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Extra field name", alias="extraField.name")
    extra_field_type: pd.StringDtype = pa.Field(
        coerce=True,
        nullable=True,
        isin=["text", "decimal", "number", "date", "yesNo", "textDate"],
        description="Extra field type",
        alias="extraField.extraFieldType"
    )
    value: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Field value", alias="value")
    start_date: str = pa.Field(coerce=True, nullable=True, description="Start date", alias="startDate")

    class _Annotation:
        primary_key = "extra_field_id"
        foreign_keys = {
            "employee_id": {
                "parent_schema": "EmployeeSchema",
                "parent_column": "employee_id",
                "cardinality": "1:N"
            },
            "extra_field_id": {
                "parent_schema": "ExtraFieldSettingsGet",
                "parent_column": "extra_field_id",
                "cardinality": "N:1"
            }
        }
