from datetime import datetime
from enum import Enum
from typing import Annotated, Optional

import pandas as pd
import pandera as pa
import pandera.extensions as extensions
from pydantic import BaseModel, Field, StringConstraints

from brynq_sdk_functions import BrynQPanderaDataFrameModel

class LeaveGet(BrynQPanderaDataFrameModel):
    employee_id: pd.StringDtype = pa.Field(coerce=True, description="Employee ID", alias="employeeId")
    leave_requests_id: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Leave Requests ID", alias="leaveRequestsId")
    leave_group_id: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Leave Group ID", alias="leaveGroupId")
    status: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Leave Status", alias="status")
    leave_type: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Leave Type", alias="type")
    start_date: datetime = pa.Field(coerce=True, nullable=True, description="Leave Start Date", alias="startDate")
    end_date: datetime = pa.Field(coerce=True, nullable=True, description="Leave End Date", alias="endDate")
    hours: pd.Float64Dtype = pa.Field(coerce=True, nullable=True, description="Leave Hours", alias="hours")
    created_at: datetime = pa.Field(coerce=True, nullable=True, description="Leave Created At   ", alias="createdAt")
    changed_at: datetime = pa.Field(coerce=True, nullable=True, description="Leave Changed At", alias="changedAt")

    class _Annotation:
        primary_key = "leave_requests_id"
        foreign_keys = {
            "employee_id": {
                "parent_schema": "EmployeeSchema",
                "parent_column": "employee_id",
                "cardinality": "N:1"
            }
        }

class LeaveCreate(BaseModel):
    leave_group_id: str = Field(..., example="49a69eda-252e-4ccb-a220-38ea90511d4f", description="Leave Group ID", alias="leaveGroupId")
    start_date: datetime = Field(..., example="2025-01-01", description="Leave Start Date", alias="startDate")
    end_date: datetime = Field(..., example="2025-01-02", description="Leave End Date", alias="endDate")
    hours: float = Field(..., example=8.0, description="Leave Hours", alias="hours")
    description: Optional[str] = Field(None, example="Comment about leave request", description="Comment", alias="description")
    status: str = Field(..., example="Comment about leave request", description="Comment", alias="status")
    leave_type: str = Field(..., example="vacation", description="Leave Type", alias="type")

class LeaveDelete(BaseModel):
    leave_requests_id: str = Field(None, example="49a69eda-252e-4ccb-a220-38ea90511d4f", description="Leave Request ID", alias="leaverequestId")

class LeaveUpdate(BaseModel):
    """Schema for updating leave via SOAP API."""
    leave_request_id: int = Field(..., example=67890, description="Leave ID", alias="leaveId")
    start_date: datetime = Field(..., example="2025-01-01T00:00:00", description="Leave Start Date", alias="startDate")
    end_date: datetime = Field(..., example="2025-01-02T00:00:00", description="Leave End Date", alias="endDate")
    description: Optional[str] = Field(None, example="Vacation leave", description="Description", alias="description")

    class Config:
        populate_by_name = True

class LeaveBalanceGet(BrynQPanderaDataFrameModel):
    employee_id: pd.StringDtype = pa.Field(coerce=True, description="Employee ID", alias="employeeId")
    leave_group_id: pd.StringDtype = pa.Field(coerce=True, nullable=True, description="Leave Group ID", alias="leaveGroupId")
    balance: pd.Float64Dtype = pa.Field(coerce=True, nullable=True, description="Leave Balance", alias="leaveBalance")

    class _Annotation:
        primary_key = "employee_id"
        foreign_keys = {
            "leave_group_id": {
                "parent_schema": "LeaveGroupGet",
                "parent_column": "leave_group_id",
                "cardinality": "N:1"
            }
        }

class LeaveGroupGet(BrynQPanderaDataFrameModel):
    leave_group_id: str = pa.Field(coerce=True, nullable=True, description="Leave Group ID", alias="leaveGroupId")
    group: int = pa.Field(coerce=True, nullable=True, description="Leave Group", alias="group")
    description: Optional[str] = pa.Field(coerce=True, nullable=True, description="Description", alias="description")

    class _Annotation:
        primary_key = "leave_group_id"