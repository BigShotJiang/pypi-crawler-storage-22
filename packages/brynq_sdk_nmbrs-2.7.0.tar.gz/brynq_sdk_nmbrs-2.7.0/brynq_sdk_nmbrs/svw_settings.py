from typing import Any, Dict, Optional

import pandas as pd
import requests

from brynq_sdk_functions import Functions

from .schemas.svw_settings import (
    CompanySVWSettingsGet,
    EmployeeSVWSettingsGet,
    SVWSettingsCreate,
)


class CompanySVWSettings:
    """
    Class for handling company-level SVW (Social Insurance) settings.

    Endpoints:
        - GET /api/companies/{companyId}/svwsettings
    """

    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self,
            company_id: Optional[str] = None,
            year: Optional[int] = None,
            period: Optional[int] = None,
            created_from: Optional[str] = None) -> tuple:
        """
        Get company SVW settings (SVW table).

        Args:
            company_id: Optional company ID. If not provided, fetches for all companies.
            year: Optional year filter
            period: Optional period filter
            created_from: Optional datetime filter for records created after this date

        Returns:
            Tuple of (valid_data, invalid_data) DataFrames
        """
        if company_id:
            df = self._get(company_id, year, period, created_from)
        else:
            df = pd.DataFrame()
            for company in self.nmbrs.company_ids:
                df = pd.concat([df, self._get(company, year, period, created_from)])

        if df.empty:
            return df, pd.DataFrame()

        valid_data, invalid_data = Functions.validate_data(df=df, schema=CompanySVWSettingsGet, debug=self.nmbrs.debug)
        return valid_data, invalid_data

    def _get(self,
             company_id: str,
             year: Optional[int] = None,
             period: Optional[int] = None,
             created_from: Optional[str] = None) -> pd.DataFrame:
        """
        Internal method to get SVW settings for a single company.
        """
        params = {}
        if year is not None:
            params['year'] = year
        if period is not None:
            params['period'] = period
        if created_from is not None:
            params['createdFrom'] = created_from

        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}companies/{company_id}/svwsettings",
            params=params
        )

        data = self.nmbrs.get_paginated_result(request)
        df = pd.DataFrame(data)

        if not df.empty:
            df['companyId'] = company_id

        return df


class EmployeeSVWSettings:
    """
    Class for handling employee-level SVW (Social Insurance) settings.

    Endpoints:
        - GET /api/companies/{companyId}/employees/svwsettings
        - POST /api/employees/{employeeId}/SVWSettings
    """

    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self,
            company_id: Optional[str] = None,
            employee_id: Optional[str] = None,
            created_from: Optional[str] = None) -> tuple:
        """
        Get SVW settings history for employees of a company.

        Args:
            company_id: Optional company ID. If not provided, fetches for all companies.
            employee_id: Optional employee ID filter
            created_from: Optional datetime filter for records created after this date

        Returns:
            Tuple of (valid_data, invalid_data) DataFrames
        """
        if company_id:
            df = self._get(company_id, employee_id, created_from)
        else:
            df = pd.DataFrame()
            for company in self.nmbrs.company_ids:
                df = pd.concat([df, self._get(company, employee_id, created_from)])

        if df.empty:
            return df, pd.DataFrame()

        valid_data, invalid_data = Functions.validate_data(df=df, schema=EmployeeSVWSettingsGet, debug=self.nmbrs.debug)
        return valid_data, invalid_data

    def _get(self,
             company_id: str,
             employee_id: Optional[str] = None,
             created_from: Optional[str] = None) -> pd.DataFrame:
        """
        Internal method to get employee SVW settings for a single company.
        """
        params = {}
        if employee_id is not None:
            params['employeeId'] = employee_id
        if created_from is not None:
            params['createdFrom'] = created_from

        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}companies/{company_id}/employees/svwsettings",
            params=params
        )

        data = self.nmbrs.get_paginated_result(request)

        # Normalize nested data structure without meta key conflicts
        records = []
        for item in data:
            parent_employee_id = item.get("employeeId")
            for record in item.get("employeeSVWSettings", []) or []:
                if "employeeId" not in record:
                    record["employeeId"] = parent_employee_id
                # make it return hirerCAO consistently
                if record.get("hirerCAO") is None:
                    record["hirerCAO"] = {"code": None, "CAODescription": None}
                records.append(record)
        df = pd.json_normalize(records)
        if 'hirerCAO' in df.columns:
            hirer_cao_df = pd.json_normalize(df['hirerCAO']).add_prefix('hirerCAO.')
            if not hirer_cao_df.empty:
                hirer_cao_df = hirer_cao_df.reindex(df.index)
                df = pd.concat([df.drop(columns=['hirerCAO']), hirer_cao_df], axis=1)
            else:
                df = df.drop(columns=['hirerCAO'])

        if not df.empty:
            df['companyId'] = company_id

        return df

    def create(self, employee_id: str, data: Dict[str, Any]):
        """
        Create SVW settings for a specific employee.

        A new SVW settings entry will be created in Nmbrs, starting from the
        applied start period.

        Args:
            employee_id: The ID of the employee
            data: Dictionary containing SVW settings data matching SVWSettingsCreate schema:
                - ZW: bool (optional) - Ziektewet
                - WW: bool (optional) - Werkloosheidswet
                - waoWia: bool (optional) - WAO/WIA
                - natureOfEmployment: int (required) - Nature of employment code
                - phaseClassification: int (optional) - Phase classification
                - codeZvw: str (required) - Code ZVW (A, B, G, H)
                - taxSequenceNumber: int (required)
                - incomeRelatedContributionZvw: int (required)
                - influenceObligedInsurance: int (required)
                - wageCostBenefit: dict (optional)
                - CAO: int (optional)
                - hirerCAO: int (optional)
                - period: dict (required) with year and period

        Returns:
            Response from the API or validated model in mock mode
        """
        # Validate with Pydantic model
        nested_data = self.nmbrs.flat_dict_to_nested_dict(data, SVWSettingsCreate)
        svw_model = SVWSettingsCreate(**nested_data)

        if self.nmbrs.mock_mode:
            return svw_model

        # Convert validated model to dict for API payload
        payload = svw_model.model_dump(exclude_none=True, by_alias=True)

        # Send request
        resp = self.nmbrs.session.post(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/SVWSettings",
            json=payload,
            timeout=self.nmbrs.timeout
        )
        return resp
