from typing import Any, Dict, Optional, Tuple

import pandas as pd
import requests
from zeep.exceptions import Fault
from zeep.helpers import serialize_object

from brynq_sdk_functions import Functions

from .schemas.wage_tax import (
    CompanyWageTaxGet,
    CompanyWageTaxGetSOAP,
    WageTaxGet,
    WageTaxSettingsCreate,
    WageTaxSettingsGet,
    WageTaxUpdate,
)


class CompanyWageTax:
    """
    Class for handling company-level wage tax data via REST API.

    Endpoints:
        - GET /api/companies/{companyId}/wagetaxes
        - GET /api/companies/{companyId}/wagetaxes/{wageTaxId}/xml
        - GET /api/companies/{companyId}/wagetaxes/{wageTaxId}/sepa
    """

    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self,
            company_id: Optional[str] = None,
            year: Optional[int] = None) -> tuple:
        """
        Get wage tax declarations for a company.

        Args:
            company_id: Optional company ID. If not provided, fetches for all companies.
            year: Optional year filter. If not provided, returns current year.

        Returns:
            Tuple of (valid_data, invalid_data) DataFrames
        """
        if company_id:
            df = self._get(company_id, year)
        else:
            df = pd.DataFrame()
            for company in self.nmbrs.company_ids:
                df = pd.concat([df, self._get(company, year)])

        if df.empty:
            return df, pd.DataFrame()

        valid_data, invalid_data = Functions.validate_data(df=df, schema=CompanyWageTaxGet, debug=True)
        return valid_data, invalid_data

    def _get(self,
             company_id: str,
             year: Optional[int] = None) -> pd.DataFrame:
        """
        Internal method to get wage tax declarations for a single company.
        """
        params = {}
        if year is not None:
            params['year'] = year

        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}companies/{company_id}/wagetaxes",
            params=params
        )

        data = self.nmbrs.get_paginated_result(request)
        df = pd.DataFrame(data)

        if not df.empty:
            df['companyId'] = company_id

        return df

    def get_xml(self, company_id: str, wage_tax_id: str):
        """
        Get the XML file of a wage tax declaration.

        Args:
            company_id: The ID of the company
            wage_tax_id: The ID of the wage tax declaration

        Returns:
            Response containing the task ID for retrieving the XML file
        """
        resp = self.nmbrs.session.get(
            url=f"{self.nmbrs.base_url}companies/{company_id}/wagetaxes/{wage_tax_id}/xml",
            timeout=self.nmbrs.timeout
        )
        resp.raise_for_status()
        return resp.json()

    def get_sepa(self, company_id: str, wage_tax_id: str, year: int, payment_date: Optional[str] = None):
        """
        Get the SEPA (payment file) of a wage tax declaration.

        Args:
            company_id: The ID of the company
            wage_tax_id: The ID of the wage tax declaration
            year: The year of the search (required)
            payment_date: Optional payment date to be added to the payment file (ISO format)

        Returns:
            Response containing the task ID for retrieving the SEPA file
        """
        params = {'year': year}
        if payment_date is not None:
            params['paymentDate'] = payment_date

        resp = self.nmbrs.session.get(
            url=f"{self.nmbrs.base_url}companies/{company_id}/wagetaxes/{wage_tax_id}/sepa",
            params=params,
            timeout=self.nmbrs.timeout
        )
        resp.raise_for_status()
        return resp.json()


class WageTaxSettings:
    """Wage Tax Settings History - uses REST API."""

    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self,
            created_from: str = None,
            employee_id: str = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Get wage tax settings history for all employees across all companies.

        Args:
            created_from: Optional filter to get settings created from a specific date (ISO format)
            employee_id: Optional filter to get settings for a specific employee

        Returns:
            Tuple of (valid_settings, invalid_settings) DataFrames
        """
        wage_tax_settings = pd.DataFrame()
        for company in self.nmbrs.company_ids:
            wage_tax_settings = pd.concat([wage_tax_settings, self._get(company, created_from, employee_id)])

        valid_settings, invalid_settings = Functions.validate_data(
            df=wage_tax_settings,
            schema=WageTaxSettingsGet,
            debug=True
        )

        return valid_settings, invalid_settings

    def _get(self,
             company_id: str,
             created_from: str = None,
             employee_id: str = None) -> pd.DataFrame:
        """
        Get wage tax settings history for a specific company.

        Args:
            company_id: The ID of the company
            created_from: Optional filter to get settings created from a specific date
            employee_id: Optional filter to get settings for a specific employee

        Returns:
            DataFrame containing wage tax settings history
        """
        params = {}
        if created_from:
            params['createdFrom'] = created_from
        if employee_id:
            params['employeeId'] = employee_id

        request = requests.Request(
            method='GET',
            url=f"{self.nmbrs.base_url}companies/{company_id}/employees/wagetaxsettings",
            params=params
        )

        data = self.nmbrs.get_paginated_result(request)
        df = pd.json_normalize(
            data,
            record_path='wageTaxSettings',
            meta=['employeeId']
        )

        return df

    def create(self, employee_id: str, data: Dict[str, Any]):
        """
        Create a new wage tax setting for an employee using Pydantic validation.

        Args:
            employee_id: The ID of the employee
            data: Dictionary containing wage tax settings data with fields matching
                 the EmployeeWageTaxSettingsCreate schema (using camelCase field names)

        Returns:
            Response from the API
        """
        # Validate with Pydantic model
        nested_data = self.nmbrs.flat_dict_to_nested_dict(data, WageTaxSettingsCreate)
        wage_tax_model = WageTaxSettingsCreate(**nested_data)

        if self.nmbrs.mock_mode:
            return wage_tax_model

        # Convert validated model to dict for API payload
        payload = wage_tax_model.model_dump(exclude_none=True, by_alias=True)

        # Send request
        resp = self.nmbrs.session.post(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/wagetaxsetting",
            json=payload,
            timeout=self.nmbrs.timeout
        )
        return resp


class WageTax:
    def __init__(self, nmbrs):
        self.nmbrs = nmbrs
        self.soap_client_companies = nmbrs.soap_client_companies
        self.soap_client_employees = nmbrs.soap_client_employees

    def get_settings(self, year: int) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Get salary tables for all companies for a specific period and year.

        Args:
            period (int): The period number
            year (int): The year

        Returns:
            pd.DataFrame: DataFrame containing the salary tables
        """
        wagetax_settings = pd.DataFrame()
        for company in self.nmbrs.soap_company_ids.to_dict(orient='records'):
            wagetax_settings_temp = self._get(company['i_d'], year)
            if not wagetax_settings_temp.empty:
                wagetax_settings_temp['companyId'] = company['number']
                wagetax_settings = pd.concat([wagetax_settings, wagetax_settings_temp])

        valid_wagetax_settings, invalid_wagetax_settings = Functions.validate_data(df=wagetax_settings, schema=CompanyWageTaxGetSOAP, debug=True)

        # No validation schema for now, but could be added later
        return valid_wagetax_settings, invalid_wagetax_settings

    def _get(self, company_id: int, year: int) -> pd.DataFrame:
        """
        Get salary tables for a specific company, period and year.

        Args:
            company_id (int): The ID of the company
            period (int): The period number
            year (int): The year

        Returns:
            pd.DataFrame: DataFrame containing the salary tables
        """
        try:
            # Make SOAP request with the proper header structure
            response = self.soap_client_companies.service.WageTax_GetList(
                CompanyId=company_id,
                intYear=year,
                _soapheaders=[self.nmbrs.soap_auth_header]
            )

            # Convert response to DataFrame
            if response:
                # Convert Zeep objects to Python dictionaries
                serialized_response = serialize_object(response)

                # Convert to list if it's not already
                if not isinstance(serialized_response, list):
                    serialized_response = [serialized_response]

                # Convert to DataFrame
                df = pd.DataFrame(serialized_response)

                return df
            else:
                return pd.DataFrame()

        except Fault as e:
            raise Exception(f"SOAP request failed: {str(e)}")
        except Exception as e:
            raise Exception(f"Failed to get salary tables: {str(e)}")

    def get(self, employee_id: int) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Get wage tax settings for a specific employee.

        Args:
            employee_id (int): The ID of the employee

        Returns:
            pd.DataFrame: DataFrame containing the wage tax settings
        """
        try:
            # Get the auth header using the centralized method
            auth_header = self.nmbrs._get_soap_auth_header_employees()

            # Make SOAP request with the proper header structure
            response = self.soap_client_employees.service.WageTax_GetList(
                EmployeeId=employee_id,
                _soapheaders=[auth_header]
            )

            # Convert response to DataFrame
            if response:
                # Convert Zeep objects to Python dictionaries
                serialized_response = serialize_object(response)

                # Convert to list if it's not already
                if not isinstance(serialized_response, list):
                    serialized_response = [serialized_response]

                # Convert to DataFrame
                df = pd.DataFrame(serialized_response)
                df['EmployeeId'] = employee_id
                valid_wage_tax, invalid_wage_tax = Functions.validate_data(df=df, schema=WageTaxGet, debug=True)

                return valid_wage_tax, invalid_wage_tax
            else:
                return pd.DataFrame(), pd.DataFrame()

        except Fault as e:
            raise Exception(f"SOAP request failed: {str(e)}")
        except Exception as e:
            raise Exception(f"Failed to get wage tax settings: {str(e)}")

    def update(self, data: Dict[str, Any]) -> pd.DataFrame:
        try:
            wage_tax_model = WageTaxUpdate(**data)

            if self.nmbrs.mock_mode:
                return wage_tax_model

            # Use the model's built-in SOAP conversion method
            wage_tax_settings = wage_tax_model.to_soap_settings(self.nmbrs.soap_client_employees)

            # Make SOAP request with clean, simple call
            response = self.nmbrs.soap_client_employees.service.WageTax_UpdateCurrent(
                EmployeeId=wage_tax_model.employee_id,
                LoonheffingSettings=wage_tax_settings,
                _soapheaders=[self.nmbrs.soap_auth_header]
            )

            # Convert response to DataFrame
            if response:
                # Convert Zeep objects to Python dictionaries
                serialized_response = serialize_object(response)

                # Convert to list if it's not already
                if not isinstance(serialized_response, list):
                    serialized_response = [serialized_response]

                # Convert to DataFrame
                df = pd.DataFrame(serialized_response)

                return df
            else:
                return pd.DataFrame()

        except Fault as e:
            raise Exception(f"SOAP request failed: {str(e)}")
        except Exception as e:
            raise Exception(f"Failed to update WageTax: {str(e)}")
