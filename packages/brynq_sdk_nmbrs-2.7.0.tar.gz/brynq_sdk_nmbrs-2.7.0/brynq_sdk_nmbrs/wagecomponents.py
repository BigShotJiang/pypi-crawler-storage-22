from datetime import date, datetime
from typing import Any, Dict, Union

import pandas as pd
import requests

from brynq_sdk_functions import Functions

from .schemas.wagecomponents import (
    FixedWageComponentCreate,
    FixedWageComponentGet,
    FixedWageComponentUpdate,
    VariableWageComponentCreate,
    VariableWageComponentGet,
    VariableWageComponentUpdate,
    WageComponentDelete,
)


class EmployeeFixedWageComponents:
    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self,
            created_from: str = None,
            employee_id: str = None,
            period: int = None,
            year: int = None) -> tuple[pd.DataFrame, pd.DataFrame]:
        wagecomponents = pd.DataFrame()
        for company in self.nmbrs.company_ids:
            wagecomponents = pd.concat([wagecomponents, self._get(company, created_from, employee_id, period, year)])

        valid_wagecomponents, invalid_wagecomponents = Functions.validate_data(df=wagecomponents, schema=FixedWageComponentGet, debug=True)

        return valid_wagecomponents, invalid_wagecomponents

    def _get(self,
            company_id: str,
            created_from: str = None,
            employee_id: str = None,
            period: int = None,
            year: int = None) -> pd.DataFrame:
        params = {}
        if created_from:
            params['createdFrom'] = created_from
        if employee_id:
            params['employeeId'] = employee_id
        if year:
            params['year'] = year
        if period:
            params['period'] = period
        request = requests.Request(method='GET',
                                   url=f"{self.nmbrs.base_url}companies/{company_id}/employees/fixedwagecomponents",
                                   params=params)

        data = self.nmbrs.get_paginated_result(request)
        df = pd.json_normalize(
            data,
            record_path='fixedWageComponents',
            meta=['employeeId']
        )

        return df

    def create(self, employee_id: str, data: Dict[str, Any]):
        """
        Create a new fixed wage component for an employee using Pydantic validation.

        Args:
            employee_id: The ID of the employee
            data: Dictionary containing fixed wage component data with fields matching
                 the FixedWageComponentCreate schema (using camelCase field names)

        Returns:
            Response from the API
        """
        # Validate with Pydantic model - this will raise an error if required fields are missing
        nested_data = self.nmbrs.flat_dict_to_nested_dict(data, FixedWageComponentCreate)
        wage_component_model = FixedWageComponentCreate(**nested_data)

        if self.nmbrs.mock_mode:
            return wage_component_model

        # Convert validated model to dict for API payload
        payload = wage_component_model.model_dump(exclude_none=True, by_alias=True)

        # Send request
        resp = self.nmbrs.session.post(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/fixedwagecomponent",
            json=payload,
            timeout=self.nmbrs.timeout
        )
        return resp

    def update(self, employee_id: str, data: Dict[str, Any]):
        """
        Update an existing fixed wage component for an employee using Pydantic validation.

        Args:
            employee_id: The ID of the employee
            data: Dictionary containing fixed wage component data with fields matching
                 the FixedWageComponentUpdate schema (using camelCase field names)

        Returns:
            Response from the API
        """
        # Clean empty strings before validation
        data = {k: (None if v == "" else v) for k, v in data.items()}
        # Handle flat period_details fields
        if 'period_details_period' in data and data['period_details_period'] == "":
            data['period_details_period'] = None
        if 'period_details_year' in data and data['period_details_year'] == "":
            data['period_details_year'] = None
        if 'period_details' in data and isinstance(data['period_details'], dict):
            data['period_details'] = {k: (None if v == "" else v) for k, v in data['period_details'].items()}

        # Validate with Pydantic model - this will raise an error if required fields are missing
        nested_data = self.nmbrs.flat_dict_to_nested_dict(data, FixedWageComponentUpdate)
        wage_component_model = FixedWageComponentUpdate(**nested_data)

        if self.nmbrs.mock_mode:
            return wage_component_model

        # Convert validated model to dict for API payload
        payload = wage_component_model.model_dump(exclude_none=True, by_alias=True)

        # Send request
        resp = self.nmbrs.session.put(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/fixedwagecomponent",
            json=payload,
            timeout=self.nmbrs.timeout
        )
        return resp

    def delete(self, employee_id: str, wagecomponent_id: str):
        """
        Delete a wage component for an employee.

        Args:
            employee_id: The ID of the employee
            wagecomponent_id: The ID of the wage component to delete

        Returns:
            Response from the API
        """
        # Validate with Pydantic model
        delete_model = WageComponentDelete(fixed_wage_component_id=wagecomponent_id)

        if self.nmbrs.mock_mode:
            return delete_model

        resp = self.nmbrs.session.delete(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/wagecomponents/{wagecomponent_id}",
            timeout=self.nmbrs.timeout
        )
        return resp

    def get_historic(self, since: Union[date, datetime, str] = date(2020, 1, 1)) -> pd.DataFrame:
        """
        Extract historical fixed wage components from Nmbrs for all periods from since date to now.

        Args:
            since: Start date for historical extraction. Can be a date, datetime object,
                   or string in format 'dd-mm-yyyy'. Defaults to January 1, 2020.

        Returns:
            DataFrame with historical fixed wage components
        """
        if isinstance(since, str):
            since = datetime.strptime(since, '%d-%m-%Y').date()
        elif isinstance(since, datetime):
            since = since.date()

        year_since = since.year
        period_since = since.month
        now = datetime.now()
        year_now = now.year
        period_now = now.month

        list_dfs = []
        for year in range(year_since, year_now + 1):
            start_period = period_since if year == year_since else 1
            end_period = period_now if year == year_now else 12

            for period in range(start_period, end_period + 1):
                df_fixed_wage_components, _ = self.get(year=year, period=period)
                if not df_fixed_wage_components.empty:
                    df_fixed_wage_components['period_details_year'] = year
                    df_fixed_wage_components['period_details_period'] = period
                    list_dfs.append(df_fixed_wage_components)

        if not list_dfs:
            print("No valid fixed wage components found for history get.")
            return pd.DataFrame()

        df_fixed_wage_components_historic = pd.concat(list_dfs, ignore_index=True)

        # Create a composite integer key (YYYYMM) for min-maxing
        df_fixed_wage_components_historic['period_composite'] = (
            df_fixed_wage_components_historic['period_details_year'].fillna(0) * 100 +
            df_fixed_wage_components_historic['period_details_period'].fillna(0)
        )
        df_fixed_wage_components_historic['end_period_composite'] = (
            df_fixed_wage_components_historic['end_year'].fillna(0) * 100 +
            df_fixed_wage_components_historic['end_period'].fillna(0)
        )

        groupby_cols = ['fixed_wage_component_id']
        groupby_cols = [col for col in groupby_cols if col in df_fixed_wage_components_historic.columns]

        # Aggregation: Find the earliest composite date for start, and max end composite
        agg_dict = {
            'period_composite': 'min',
            'end_period_composite': 'max',
        }

        # Add all other columns (not in groupby or composite) with 'first' aggregation
        other_cols = [col for col in df_fixed_wage_components_historic.columns
                     if col not in groupby_cols and col not in ['period_composite', 'end_period_composite']]
        agg_dict.update({col: 'first' for col in other_cols})

        df_fixed_wage_components_historic = (
            df_fixed_wage_components_historic
            .groupby(groupby_cols, as_index=False, dropna=False)
            .agg(agg_dict)
        )

        # Decode the composite key back into separate Year and Period columns
        df_fixed_wage_components_historic['period_details_year'] = (df_fixed_wage_components_historic['period_composite'] // 100).astype('Int64')
        df_fixed_wage_components_historic['period_details_period'] = (df_fixed_wage_components_historic['period_composite'] % 100).astype('Int64')
        df_fixed_wage_components_historic['end_year'] = (df_fixed_wage_components_historic['end_period_composite'] // 100).astype('Int64')
        df_fixed_wage_components_historic['end_period'] = (df_fixed_wage_components_historic['end_period_composite'] % 100).astype('Int64')

        # Replace 0 values (from fillna) with pd.NA
        df_fixed_wage_components_historic['period_details_year'] = df_fixed_wage_components_historic['period_details_year'].replace(0, pd.NA)
        df_fixed_wage_components_historic['period_details_period'] = df_fixed_wage_components_historic['period_details_period'].replace(0, pd.NA)
        df_fixed_wage_components_historic['end_year'] = df_fixed_wage_components_historic['end_year'].replace(0, pd.NA)
        df_fixed_wage_components_historic['end_period'] = df_fixed_wage_components_historic['end_period'].replace(0, pd.NA)

        # Clean up
        df_fixed_wage_components_historic.drop(columns=['end_period_composite'], inplace=True)
        df_fixed_wage_components_historic.drop(columns=['period_composite'], inplace=True)
        int_cols = ['end_year', 'end_period']
        df_fixed_wage_components_historic = df_fixed_wage_components_historic.astype({c: 'Int64' for c in int_cols})

        return df_fixed_wage_components_historic


class EmployeeVariableWageComponents:
    def __init__(self, nmbrs):
        self.nmbrs = nmbrs

    def get(self,
            created_from: str = None,
            employee_id: str = None,
            period: int = None,
            year: int = None) -> tuple[pd.DataFrame, pd.DataFrame]:
        wagecomponents = pd.DataFrame()
        for company in self.nmbrs.company_ids:
            wagecomponents = pd.concat([wagecomponents, self._get(company, created_from, employee_id, period, year)])

        valid_wagecomponents, invalid_wagecomponents = Functions.validate_data(df=wagecomponents, schema=VariableWageComponentGet, debug=True)

        return valid_wagecomponents, invalid_wagecomponents

    def _get(self,
            company_id: str,
            created_from: str = None,
            employee_id: str = None,
            period: int = None,
            year: int = None) -> pd.DataFrame:
        params = {}
        if created_from:
            params['createdFrom'] = created_from
        if employee_id:
            params['employeeId'] = employee_id
        if year:
            params['year'] = year
        if period:
            params['period'] = period
        request = requests.Request(method='GET',
                                   url=f"{self.nmbrs.base_url}companies/{company_id}/employees/variablewagecomponents",
                                   params=params)

        data = self.nmbrs.get_paginated_result(request)
        df = pd.json_normalize(
            data,
            record_path='variablewagecomponents',
            meta=['employeeId']
        )

        return df

    def create(self, employee_id: str, data: Dict[str, Any]):
        """
        Create a new variable wage component for an employee using Pydantic validation.

        Args:
            employee_id: The ID of the employee
            data: Dictionary containing variable wage component data with fields matching
                 the VariableWageComponentCreate schema (using camelCase field names)

        Returns:
            Response from the API
        """
        # Clean empty strings before validation
        data = {k: (None if v == "" else v) for k, v in data.items()}
        # Handle flat period_details fields
        if 'period_details_period' in data and data['period_details_period'] == "":
            data['period_details_period'] = None
        if 'period_details_year' in data and data['period_details_year'] == "":
            data['period_details_year'] = None
        if 'period_details' in data and isinstance(data['period_details'], dict):
            data['period_details'] = {k: (None if v == "" else v) for k, v in data['period_details'].items()}

        # Validate with Pydantic model - this will raise an error if required fields are missing
        nested_data = self.nmbrs.flat_dict_to_nested_dict(data, VariableWageComponentCreate)
        wage_component_model = VariableWageComponentCreate(**nested_data)

        if self.nmbrs.mock_mode:
            return wage_component_model

        # Convert validated model to dict for API payload
        payload = wage_component_model.model_dump(exclude_none=True, by_alias=True)

        # Send request
        resp = self.nmbrs.session.post(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/variablewagecomponent",
            json=payload,
            timeout=self.nmbrs.timeout
        )
        return resp

    def update(self, employee_id: str, data: Dict[str, Any]):
        """
        Update an existing variable wage component for an employee using Pydantic validation.

        Args:
            employee_id: The ID of the employee
            data: Dictionary containing variable wage component data with fields matching
                 the VariableWageComponentUpdate schema (using camelCase field names)

        Returns:
            Response from the API
        """
        # Clean empty strings before validation
        data = {k: (None if v == "" else v) for k, v in data.items()}
        # Handle flat period_details fields
        if 'period_details_period' in data and data['period_details_period'] == "":
            data['period_details_period'] = None
        if 'period_details_year' in data and data['period_details_year'] == "":
            data['period_details_year'] = None
        if 'period_details' in data and isinstance(data['period_details'], dict):
            data['period_details'] = {k: (None if v == "" else v) for k, v in data['period_details'].items()}

        # Validate with Pydantic model - this will raise an error if required fields are missing
        nested_data = self.nmbrs.flat_dict_to_nested_dict(data, VariableWageComponentUpdate)
        wage_component_model = VariableWageComponentUpdate(**nested_data)

        if self.nmbrs.mock_mode:
            return wage_component_model

        # Convert validated model to dict for API payload
        payload = wage_component_model.model_dump(exclude_none=True, by_alias=True)

        # Send request
        resp = self.nmbrs.session.put(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/variablewagecomponent",
            json=payload,
            timeout=self.nmbrs.timeout
        )
        return resp

    def delete(self, employee_id: str, wagecomponent_id: str):
        """
        Delete a wage component for an employee.

        Args:
            employee_id: The ID of the employee
            wagecomponent_id: The ID of the wage component to delete

        Returns:
            Response from the API
        """
        # Validate with Pydantic model
        delete_model = WageComponentDelete(fixed_wage_component_id=wagecomponent_id)

        if self.nmbrs.mock_mode:
            return delete_model

        resp = self.nmbrs.session.delete(
            url=f"{self.nmbrs.base_url}employees/{employee_id}/wagecomponents/{wagecomponent_id}",
            timeout=self.nmbrs.timeout
        )
        return resp
