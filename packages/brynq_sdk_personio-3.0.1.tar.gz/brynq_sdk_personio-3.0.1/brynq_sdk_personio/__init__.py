import requests
import json
from typing import Literal, Optional
from brynq_sdk_brynq import BrynQ
from .employees import Employees
from .compensations import Compensations
from .custom_reports import CustomReports
from .documents import Documents
from .persons import Persons
from .employments import Employments


class Personio(BrynQ):
    """
    Personio SDK client for interacting with the Personio API.

    For the documentation of Personio, see: https://developer.personio.de/reference/auth

    Args:
        system_type: Optional system type for credential lookup ('source' or 'target')
        debug: Enable debug mode for verbose output
        attribute_set: Personio attribute set to use for person schema validation.
                      Options: 'default', 'afas'. Default is 'default'.
                      When 'afas' is selected, the PersonAFASGet schema is used which
                      includes AFAS-specific fields like BSN, IBAN, nationality, etc.

    Example:
        # Default usage
        personio = Personio()

        # With AFAS attribute set for Dutch payroll integration
        personio = Personio(attribute_set='afas')
    """

    # Available attribute sets
    ATTRIBUTE_SETS = ['default', 'afas']

    def __init__(
        self,
        system_type: Optional[Literal['source', 'target']] = None,
        debug: bool = False,
        attribute_set: Literal['default', 'afas'] = 'default'
    ):
        super().__init__()
        self.debug = debug
        self.timeout = 3600
        self.base_url = 'https://api.personio.de/'

        # Validate and store attribute set
        if attribute_set not in self.ATTRIBUTE_SETS:
            raise ValueError(f"Invalid attribute_set '{attribute_set}'. Must be one of: {self.ATTRIBUTE_SETS}")
        self.attribute_set = attribute_set

        # Get credentials and set up session
        credentials = self.interfaces.credentials.get(system="personio", system_type=system_type)
        credentials = credentials.get('data')

        # Get access tokens for both API versions
        self._access_token_v1 = self._get_access_token(credentials, version='v1')
        self._access_token_v2 = self._get_access_token(credentials, version='v2')

        # Set up session with common headers
        self.session = requests.Session()
        self.session.headers.update({
            'X-Personio-Partner-ID': 'BRYNQ',
            'X-Personio-App-ID': 'BRYNQ_COM'
        })

        # Initialize resource classes
        self.employees = Employees(self)
        self.custom_reports = CustomReports(self)
        self.documents = Documents(self)
        self.compensations = Compensations(self)
        self.persons = Persons(self)
        self.employments = Employments(self)

    def _get_access_token(self, credentials: dict, version: str = 'v2') -> str:
        """
        Get an access token for the specified API version.

        :param credentials: Dictionary containing client_id and client_secret
        :param version: API version ('v1' or 'v2')
        :returns: Access token string
        """
        payload = {
            "client_id": credentials['client_id'],
            "client_secret": credentials['client_secret'],
            "grant_type": "client_credentials"
        }

        if version == 'v1':
            url = f'{self.base_url}v1/auth'
            headers = {
                "accept": "application/json",
                "content-type": "application/json"
            }
            response = requests.post(url, headers=headers, data=json.dumps(payload), timeout=self.timeout)
        else:
            url = f'{self.base_url}v2/auth/token'
            headers = {
                "accept": "application/json",
                "content-type": "application/x-www-form-urlencoded"
            }
            response = requests.post(url, headers=headers, data=payload, timeout=self.timeout)

        response.raise_for_status()

        if version == 'v1':
            return response.json()['data']['token']
        return response.json()['access_token']

    def get_headers_v1(self) -> dict:
        """Get headers for v1 API requests."""
        return {
            'Authorization': f'Bearer {self._access_token_v1}',
            'Content-Type': 'application/json'
        }

    def get_headers_v2(self) -> dict:
        """Get headers for v2 API requests."""
        return {
            'Authorization': f'Bearer {self._access_token_v2}',
            'accept': 'application/json'
        }
