from typing import Optional, Tuple, Union, Dict, Any
import pandas as pd
import json
import requests

from brynq_sdk_functions import Functions
from .schemas.compensation import CompensationGet, CompensationTypeGet
from .schemas.person_pydantic import CompensationCreate, CompensationTypeCreate


class Compensations:
    """Compensations resource for the Personio v2 API."""

    def __init__(self, personio):
        self.personio = personio

    def get_types(self, limit: int = 100) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Returns a list of Compensation Types for an authorized company.

        The types include one-time and recurring Compensation Types.
        Bonuses should use recurring or one time types.

        :param limit: The maximum number of compensation types to fetch. Default is 100.
        :return: Tuple of (valid_data, invalid_data) DataFrames
        """
        url = f'{self.personio.base_url}v2/compensations/types?limit={limit}'
        headers = self.personio.get_headers_v2()

        response = self.personio.session.get(url, headers=headers, timeout=self.personio.timeout)
        response.raise_for_status()

        data = response.json()
        if data and '_data' in data:
            df = pd.DataFrame(data.get('_data'))
        else:
            df = pd.DataFrame()

        return Functions.validate_data(df=df, schema=CompensationTypeGet, debug=self.personio.debug)

    def get(
        self,
        limit: int = 100,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        person_id: Optional[int] = None,
        entity_id: Optional[int] = None
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Returns a list of payroll compensations of people for an authorized company.

        Compensations listed include base salary (excluding proration), hourly,
        one time compensation, recurring compensation, and bonuses.

        :param limit: The maximum number of compensations to fetch. Default is 100.
        :param start_date: A start date from which compensations are run. Format is ISO-8601.
        :param end_date: An end date to which compensations are run. Format is ISO-8601.
        :param person_id: Filter results matching a person id.
        :param entity_id: Filter results matching a legal entity id.
        :return: Tuple of (valid_data, invalid_data) DataFrames
        """
        base_url = f'{self.personio.base_url}v2/compensations'
        headers = self.personio.get_headers_v2()

        payload = {'limit': limit}
        if start_date:
            payload['start_date'] = start_date
        if end_date:
            payload['end_date'] = end_date
        if person_id:
            payload['person_id'] = person_id
        if entity_id:
            payload['entity_id'] = entity_id

        dfs = []
        url = base_url

        while True:
            response = self.personio.session.get(
                url,
                headers=headers,
                data=json.dumps(payload),
                timeout=self.personio.timeout
            )
            response.raise_for_status()

            data = response.json()
            if data and '_data' in data:
                dfs.append(pd.json_normalize(data.get('_data')))
                cursor = data.get('_meta', {}).get('links', {}).get('next', {}).get('href')
                if cursor:
                    url = cursor
                else:
                    break
            else:
                break

        df = pd.concat(dfs) if dfs else pd.DataFrame()
        df.columns = df.columns.str.replace('.', '_', regex=False)
        df = df.reset_index(drop=True)

        return Functions.validate_data(df=df, schema=CompensationGet, debug=self.personio.debug)

    def create(self, data: Union[CompensationCreate, Dict[str, Any]]) -> requests.Response:
        """
        Create a new compensation for a person.

        Uses the v2 API endpoint: POST /v2/compensations

        :param data: CompensationCreate model or dictionary with compensation data
        :return: Response object

        Example:
            comp_data = CompensationCreate(
                person_id="34629251",
                type_id="019b0905-ac8e-a2e0-f973-70db3ce5f8f4",
                amount=5000.00,
                currency="EUR",
                effective_from="2024-01-01",
                interval="MONTHLY"
            )
            response = personio.compensations.create(comp_data)
        """
        url = f'{self.personio.base_url}v2/compensations'
        headers = self.personio.get_headers_v2()

        # Convert Pydantic model to dict if necessary
        if isinstance(data, CompensationCreate):
            payload = data.model_dump(by_alias=True, exclude_none=True)
        else:
            payload = data

        response = self.personio.session.post(
            url,
            headers=headers,
            json=payload,
            timeout=self.personio.timeout
        )

        return response

    def create_type(self, data: Union[CompensationTypeCreate, Dict[str, Any]]) -> requests.Response:
        """
        Create a new compensation type.

        Uses the v2 API endpoint: POST /v2/compensations/types

        :param data: CompensationTypeCreate model or dictionary with compensation type data
        :return: Response object

        Example:
            type_data = CompensationTypeCreate(
                name="Quarterly Bonus",
                category="ONE_TIME"
            )
            response = personio.compensations.create_type(type_data)
        """
        url = f'{self.personio.base_url}v2/compensations/types'
        headers = self.personio.get_headers_v2()

        # Convert Pydantic model to dict if necessary
        if isinstance(data, CompensationTypeCreate):
            payload = data.model_dump(by_alias=True, exclude_none=True)
        else:
            payload = data

        response = self.personio.session.post(
            url,
            headers=headers,
            json=payload,
            timeout=self.personio.timeout
        )

        return response
