from typing import List, Optional
import pandas as pd
import json


class CustomReports:
    """Custom Reports resource for the Personio v1 API.

    Note: Custom reports return dynamic data based on report configuration,
    so no fixed schema validation is applied. The returned data structure
    depends on the specific report being fetched.
    """

    def __init__(self, personio):
        self.personio = personio

    def _flatten_items(self, items: List[dict]) -> List[dict]:
        """Flatten nested historical attributes into flat records."""
        flattened_data = []
        for item in items:
            employee_id = item['employee_id']
            historical_attributes = item['historical_attributes']
            record = {'employee_id': employee_id}

            for attr in historical_attributes:
                attribute_id = attr['attribute_id']
                value = attr.get('value', None)
                amount = attr.get('amount', None)
                effective_date = attr['effective_date']

                if value is not None:
                    record[attribute_id] = value
                    record[f'{attribute_id}_effective_date'] = effective_date
                if amount is not None:
                    record[attribute_id] = amount
                    record[f'{attribute_id}_effective_date'] = effective_date

            flattened_data.append(record)
        return flattened_data

    def get_multiple(
        self,
        report_ids: Optional[List[int]] = None,
        status: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Get metadata about existing custom reports.

        :param report_ids: A list of report IDs to filter the results.
        :param status: The status of the report to filter. Possible values: 'up_to_date'
        :return: DataFrame with report metadata
        """
        url = f'{self.personio.base_url}v1/company/custom-reports/reports'
        headers = self.personio.get_headers_v1()

        payload = {}
        if report_ids:
            payload['report_ids'] = ','.join(str(rid) for rid in report_ids)
        if status:
            possible_statuses = ['up_to_date']
            if status not in possible_statuses:
                raise ValueError(f'status must be one of: "{possible_statuses}"')
            payload['status'] = status

        response = self.personio.session.get(
            url,
            headers=headers,
            data=json.dumps(payload),
            timeout=self.personio.timeout
        )
        response.raise_for_status()

        data = response.json()
        if data and 'data' in data and len(data['data']) > 0:
            df = pd.json_normalize(data['data'][0]['attributes'])
        else:
            df = pd.DataFrame()

        return df

    def get(
        self,
        report_id: int,
        limit: int = 100,
        page: int = 1,
        locale: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Get the data of an existing Custom Report.

        :param report_id: The ID of the report to fetch.
        :param limit: Pagination limit per page. Default is 100.
        :param page: Page number to start from. Default is 1.
        :param locale: Locale used to translate localized fields.
        :return: DataFrame with report data
        """
        url = f'{self.personio.base_url}v1/company/custom-reports/reports/{report_id}'
        headers = self.personio.get_headers_v1()

        payload = {
            'limit': limit,
            'page': page
        }
        if locale:
            payload['locale'] = locale

        flattened_data = []
        while True:
            response = self.personio.session.get(
                url,
                headers=headers,
                data=json.dumps(payload),
                timeout=self.personio.timeout
            )
            response.raise_for_status()

            data = response.json()
            if data and 'data' in data and len(data['data']) > 0:
                items = data['data'][0]['attributes']['items']
                flattened_data += self._flatten_items(items)

            total_pages = data.get('metadata', {}).get('total_pages', 1)
            if page >= total_pages:
                break
            page += 1
            payload['page'] = page

        df = pd.DataFrame(flattened_data)
        df = df.reset_index(drop=True)

        return df

    def get_columns(
        self,
        report_id: Optional[int] = None,
        columns: Optional[List[str]] = None,
        locale: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Get human-readable labels for report table columns.

        This is particularly important for reports with custom attributes or
        absence data to match column IDs to their translations.

        :param report_id: The ID of the report to filter columns. If not provided, returns all columns.
        :param columns: List of column IDs to filter.
        :param locale: Locale used to translate localized fields.
        :return: DataFrame with column metadata
        """
        url = f'{self.personio.base_url}v1/company/custom-reports/columns'
        headers = self.personio.get_headers_v1()

        payload = {}
        if report_id:
            payload['report_id'] = report_id
        if columns:
            payload['columns'] = ','.join(columns)
        if locale:
            payload['locale'] = locale

        response = self.personio.session.get(
            url,
            headers=headers,
            data=json.dumps(payload),
            timeout=self.personio.timeout
        )
        response.raise_for_status()

        data = response.json()
        if data and 'data' in data:
            df = pd.json_normalize(data['data'])
        else:
            df = pd.DataFrame()

        return df
