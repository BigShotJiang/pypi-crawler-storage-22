import requests
import pandas as pd
from typing import BinaryIO, Optional, Tuple
import warnings

from brynq_sdk_functions import Functions
from .schemas.documents import DocumentCategoryGet, DocumentGet


class Documents:
    """Documents resource for the Personio API."""

    def __init__(self, personio):
        self.personio = personio

    def get_categories(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Fetches all document categories of the company.

        :return: Tuple of (valid_data, invalid_data) DataFrames
        """
        url = f'{self.personio.base_url}v1/company/document-categories'
        headers = self.personio.get_headers_v1()

        response = self.personio.session.get(url, headers=headers, timeout=self.personio.timeout)
        response.raise_for_status()

        df = pd.json_normalize(response.json()['data'])
        df = df.rename(columns={'attributes.name': 'description'})

        if 'type' in df.columns:
            del df['type']

        return Functions.validate_data(df=df, schema=DocumentCategoryGet, debug=self.personio.debug)

    def list(
        self,
        employee_id: str,
        category_id: Optional[str] = None,
        created_at_gt: Optional[str] = None,
        created_at_lt: Optional[str] = None,
        limit: int = 100
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Lists the metadata of Documents belonging to the provided owner ID.

        :param employee_id: Employee identifier (owner_id)
        :param category_id: Optional document category ID filter
        :param created_at_gt: Optional filter for documents created after this date
        :param created_at_lt: Optional filter for documents created before this date
        :param limit: Maximum number of documents to fetch. Default is 100.
        :return: Tuple of (valid_data, invalid_data) DataFrames
        """
        url = f'{self.personio.base_url}v2/document-management/documents'
        headers = self.personio.get_headers_v2()

        params = {'owner_id': employee_id, 'limit': limit}
        if category_id:
            params['category_id'] = category_id
        if created_at_gt:
            params['created_at.gt'] = created_at_gt
        if created_at_lt:
            params['created_at.lt'] = created_at_lt

        dfs = []
        while True:
            response = self.personio.session.get(
                url,
                headers=headers,
                params=params,
                timeout=self.personio.timeout
            )
            response.raise_for_status()

            data = response.json()
            if data and '_data' in data:
                dfs.append(pd.json_normalize(data.get('_data')))

            cursor = data.get('_meta', {}).get('links', {}).get('next', {}).get('href')
            if cursor:
                url = cursor
            else:
                break

        df = pd.concat(dfs) if dfs else pd.DataFrame()
        df.columns = df.columns.astype(str).str.replace('.', '_', regex=False)
        df = df.reset_index(drop=True)

        return Functions.validate_data(df=df, schema=DocumentGet, debug=self.personio.debug)

    def upload(
        self,
        title: str,
        employee_id: str,
        category_id: str,
        file: BinaryIO,
        comment: Optional[str] = None,
        date: Optional[str] = None
    ) -> requests.Response:
        """
        Uploads a document for an employee.

        :param title: Title of the document. Maximum length is 255 characters.
        :param employee_id: Employee identifier
        :param category_id: Document Category identifier
        :param file: The document file object. Maximum file size is 30MB.
        :param comment: Optional comment for the document.
        :param date: Optional date for the document. Format: Y-m-d
        :return: Response object
        """
        if len(title) > 255:
            warnings.warn('title must be a maximum of 255 characters')
            title = title[:254]

        # Check file size
        file.seek(0, 2)
        file_size = file.tell()
        file.seek(0)
        if file_size > 30 * 1024 * 1024:
            raise ValueError('file must be smaller than 30MB')

        url = f'{self.personio.base_url}v1/company/documents'

        # Get headers without Content-Type (will be set by requests for multipart)
        headers = self.personio.get_headers_v1()
        headers.pop('Content-Type', None)
        headers.update({'accept': 'application/json'})

        payload = {
            "title": title,
            "employee_id": employee_id,
            "category_id": category_id
        }
        if comment:
            payload['comment'] = comment
        if date:
            payload['date'] = date

        response = self.personio.session.post(
            url,
            headers=headers,
            data=payload,
            files={"file": (title, file, "application/pdf")},
            timeout=self.personio.timeout
        )

        return response
