from typing import Tuple
import requests
import pandas as pd

from brynq_sdk_functions import Functions
from .schemas.employees import EmployeeGet, AbsenceEntitlementGet, HolidayCalendarGet


class Employees:
    """Employees resource for the Personio v1 legacy API."""

    def __init__(self, personio):
        self.personio = personio

    def _rename_dynamic_columns(self, df: pd.DataFrame) -> tuple[pd.DataFrame, set[str]]:
        """
        Rename dynamic_* columns using their universal_id if available.

        Personio returns custom attributes with a structure like:
        "dynamic_18199455": {
            "label": "Include In NL Payroll",
            "value": "",
            "type": "list",
            "universal_id": "include_in_payroll.nl"
        }

        This method renames the .value column from dynamic_* to the universal_id
        when universal_id is present. The universal_id is used as-is (dots preserved).

        Returns:
            Tuple of (dataframe, set of universal_id column names after cleanup)
        """
        # Find all universal_id columns for dynamic fields
        uid_cols_in_df = [col for col in df.columns if '.universal_id' in col and 'dynamic_' in col]

        rename_map = {}
        universal_id_names = set()  # Track the final universal_id column names

        for uid_col in uid_cols_in_df:
            # Get the base path (e.g., 'attributes.dynamic_18199455')
            base_path = uid_col.rsplit('.universal_id', 1)[0]
            value_col = f'{base_path}.value'

            if value_col in df.columns:
                # Get the first non-null universal_id value from this column
                uid_values = df[uid_col].dropna().unique()
                if len(uid_values) > 0 and uid_values[0]:
                    uid_value = str(uid_values[0])
                    # Use universal_id as the new column name (preserve dots)
                    new_name = f'{base_path.rsplit(".", 1)[0]}.{uid_value}.value'
                    rename_map[value_col] = new_name
                    # Track the final column name after .value is removed
                    universal_id_names.add(uid_value)

        if rename_map:
            df = df.rename(columns=rename_map)

        return df, universal_id_names

    def get(self, limit: int = 100, offset: int = 0) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        This endpoint gives all the data for all the employees.

        The absence_entitlement and holiday_calendar are removed since those attributes
        can have multiple lines per employee. Call get_absence_entitlements and
        get_holiday_calendar to get those attributes.

        :param limit: Pagination attribute to limit the number of employees returned per page. Default is 100.
        :param offset: Pagination attribute to identify the first item in the collection to return. Default is 0.
        :return: Tuple of (valid_data, invalid_data) DataFrames
        """
        url = f'{self.personio.base_url}v1/company/employees?limit={limit}&offset={offset}'
        headers = self.personio.get_headers_v1()

        dfs = []
        page = 1
        while True:
            response = self.personio.session.get(url, headers=headers, timeout=self.personio.timeout)
            response.raise_for_status()
            dfs.append(pd.json_normalize(response.json()['data']))
            total_pages = response.json()['metadata']['total_pages']
            if page >= total_pages:
                break
            page += 1
            offset += limit
            url = f'{self.personio.base_url}v1/company/employees?limit={limit}&offset={offset}'

        df = pd.concat(dfs) if dfs else pd.DataFrame()

        # Rename dynamic_* columns using universal_id if available
        df, universal_id_cols = self._rename_dynamic_columns(df)

        # drop each column which ends with .label, .type and .universal_id
        df = df.drop(df.filter(regex=r'\.label$|\.type$|\.universal_id$').columns, axis=1)

        # Drop each column which starts with absence_entitlements or holiday_calendar
        df = df.drop(df.filter(regex=r'^attributes\.absence_entitlement|^attributes\.holiday_calendar').columns, axis=1)

        # These columns contain nested dicts, so their value is empty when json_normalized
        columns_to_drop = ['attributes.team.value', 'attributes.subcompany.value',
                          'attributes.department.value', 'attributes.office.value']
        existing_cols_to_drop = [col for col in columns_to_drop if col in df.columns]
        if existing_cols_to_drop:
            df = df.drop(columns=existing_cols_to_drop)

        # From the supervisor data, only keep the id column
        supervisor_cols = df.filter(regex=r'^attributes\.supervisor').columns
        for column in supervisor_cols:
            if column.endswith('.id.value'):
                df[column] = df[column].fillna(0)
                df.rename(columns={column: 'supervisor_id'}, inplace=True)
            else:
                df.drop(column, axis=1, inplace=True)

        # Clean up column names
        df.columns = df.columns.str.replace('attributes.', '', regex=False)
        df.columns = df.columns.str.replace('.value.id', '_id', regex=False)
        df.columns = df.columns.str.replace('.value.name', '', regex=False)
        df.columns = df.columns.str.replace('.value', '', regex=False)

        # Replace dots with underscores, but preserve dots in universal_id columns
        new_columns = []
        for col in df.columns:
            if col in universal_id_cols:
                new_columns.append(col)  # Keep dots for universal_id columns
            else:
                new_columns.append(col.replace('.', '_'))
        df.columns = new_columns

        if 'type' in df.columns:
            del df['type']

        df = df.reset_index(drop=True)

        return Functions.validate_data(df=df, schema=EmployeeGet, debug=self.personio.debug)

    def get_absence_entitlements(self, limit: int = 100, offset: int = 0) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Get absence entitlements per employee per absence type.

        :param limit: The maximum number of employees to fetch. Default is 100.
        :param offset: The offset to start fetching the employees. Default is 0.
        :return: Tuple of (valid_data, invalid_data) DataFrames
        """
        url = f'{self.personio.base_url}v1/company/employees?attributes[]=absence_entitlement&limit={limit}&offset={offset}'
        headers = self.personio.get_headers_v1()

        data = []
        page = 1
        while True:
            response = self.personio.session.get(url, headers=headers, timeout=self.personio.timeout)
            response.raise_for_status()
            for employee in response.json()['data']:
                employee_id = employee['attributes']['id']['value']
                absence_attr = employee['attributes'].get('absence_entitlement') or {}
                entitlements = absence_attr.get('value') or []
                for entitlement in entitlements:
                    entitlement_data = {
                        "employee_id": employee_id,
                        "absence_type": entitlement['attributes']['name'],
                        "absence_category": entitlement['attributes']['category'],
                        "entitlement": entitlement['attributes']['entitlement']
                    }
                    data.append(entitlement_data)
            total_pages = response.json()['metadata']['total_pages']
            if page >= total_pages:
                break
            page += 1
            offset += limit
            url = f'{self.personio.base_url}v1/company/employees?attributes[]=absence_entitlement&limit={limit}&offset={offset}'

        df = pd.DataFrame(data)

        return Functions.validate_data(df=df, schema=AbsenceEntitlementGet, debug=self.personio.debug)

    def get_holiday_calendar(self, limit: int = 100, offset: int = 0) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Get holiday calendar per employee.

        :param limit: The maximum number of employees to fetch. Default is 100.
        :param offset: The offset to start fetching the employees. Default is 0.
        :return: Tuple of (valid_data, invalid_data) DataFrames
        """
        url = f'{self.personio.base_url}v1/company/employees?attributes[]=holiday_calendar&limit={limit}&offset={offset}'
        headers = self.personio.get_headers_v1()

        data = []
        page = 1
        while True:
            response = self.personio.session.get(url, headers=headers, timeout=self.personio.timeout)
            response.raise_for_status()
            for employee in response.json()['data']:
                employee_id = employee['attributes']['id']['value']
                holiday_cal = employee['attributes'].get('holiday_calendar') or {}
                calendar = (holiday_cal.get('value') or {}).get('attributes', {})
                if calendar:
                    calendar_data = {
                        "employee_id": employee_id,
                        "calendar_id": calendar.get('id'),
                        "calendar_name": calendar.get('name'),
                        "country": calendar.get('country'),
                        "state": calendar.get('state')
                    }
                    data.append(calendar_data)
            total_pages = response.json()['metadata']['total_pages']
            if page >= total_pages:
                break
            page += 1
            offset += limit
            url = f'{self.personio.base_url}v1/company/employees?attributes[]=holiday_calendar&limit={limit}&offset={offset}'

        df = pd.DataFrame(data)

        return Functions.validate_data(df=df, schema=HolidayCalendarGet, debug=self.personio.debug)

    def create(self, data: dict) -> requests.Response:
        """
        Create a new employee.

        :param data: Employee data dictionary
        :return: Response object
        """
        url = f'{self.personio.base_url}v1/company/employees'
        headers = self.personio.get_headers_v1()
        response = self.personio.session.post(url, json=data, headers=headers, timeout=self.personio.timeout)
        response.raise_for_status()
        return response

    def update(self, employee_id: int, data: dict) -> requests.Response:
        """
        Update an existing employee.

        :param employee_id: The employee ID to update
        :param data: Employee data dictionary
        :return: Response object
        """
        url = f'{self.personio.base_url}v1/company/employees/{employee_id}'
        headers = self.personio.get_headers_v1()
        response = self.personio.session.patch(url, json=data, headers=headers, timeout=self.personio.timeout)
        response.raise_for_status()
        return response

    def get_absence_balance(self, employee_id: int) -> dict:
        """
        Get absence balance for an employee.

        :param employee_id: The employee ID
        :return: Absence balance data
        """
        url = f'{self.personio.base_url}v1/company/employees/{employee_id}/absence_balances'
        headers = self.personio.get_headers_v1()
        response = self.personio.session.get(url, headers=headers, timeout=self.personio.timeout)
        response.raise_for_status()
        return response.json()

    def get_attributes(self) -> dict:
        """
        Get employee attributes configuration.

        :return: Employee attributes data
        """
        url = f'{self.personio.base_url}v1/company/employee_attributes'
        headers = self.personio.get_headers_v1()
        response = self.personio.session.get(url, headers=headers, timeout=self.personio.timeout)
        response.raise_for_status()
        return response.json()

    def get_custom_attributes(self) -> dict:
        """
        Get custom employee attributes configuration.

        :return: Custom employee attributes data
        """
        url = f'{self.personio.base_url}v1/company/employee_custom_attributes'
        headers = self.personio.get_headers_v1()
        response = self.personio.session.get(url, headers=headers, timeout=self.personio.timeout)
        response.raise_for_status()
        return response.json()
