from typing import List, Optional, Tuple, Union, Dict, Any
import pandas as pd
import json
import requests

from brynq_sdk_functions import Functions
from .schemas.employment import EmploymentsGet
from .schemas.person_pydantic import EmploymentUpdate


class Employments:
    """Employments resource for the Personio v2 API."""

    def __init__(self, personio):
        self.personio = personio

    def get(
        self,
        person_id: str,
        limit: int = 50,
        updated_at: Optional[str] = None,
        ids: Optional[List[str]] = None
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Returns a list of employments of a given person.

        The employments are returned in sorted order, with the most recent
        employments appearing first.

        :param person_id: Filter results matching a person id (required)
        :param limit: The maximum number of employments to fetch. Default is 50.
        :param updated_at: Filter employments by updated date. Format is ISO-8601.
        :param ids: Filter results matching one or more provided employment ids.
        :return: Tuple of (valid_data, invalid_data) DataFrames
        """
        base_url = f'{self.personio.base_url}v2/persons/{person_id}/employments'
        headers = self.personio.get_headers_v2()

        payload = {'limit': limit}
        if updated_at:
            payload['updated_at'] = updated_at
        if ids:
            payload['id'] = ','.join(ids)

        dfs = []
        url = base_url

        while True:
            response = self.personio.session.get(
                url,
                headers=headers,
                data=json.dumps(payload),
                timeout=self.personio.timeout
            )
            response.raise_for_status()

            data = response.json()
            if data and '_data' in data:
                dfs.append(pd.json_normalize(data.get('_data')))

            cursor = data.get('_meta', {}).get('links', {}).get('next', {}).get('href')
            if cursor:
                url = cursor
            else:
                break

        df = pd.concat(dfs) if dfs else pd.DataFrame()
        df.columns = df.columns.str.replace('.', '_', regex=False)
        df = df.reset_index(drop=True)

        return Functions.validate_data(df=df, schema=EmploymentsGet, debug=self.personio.debug)

    def get_by_id(self, person_id: str, employment_id: str) -> Dict[str, Any]:
        """
        Retrieve a specific employment by ID.

        :param person_id: The person ID
        :param employment_id: The employment ID
        :return: Employment data dictionary
        """
        url = f'{self.personio.base_url}v2/persons/{person_id}/employments/{employment_id}'
        headers = self.personio.get_headers_v2()

        response = self.personio.session.get(url, headers=headers, timeout=self.personio.timeout)
        response.raise_for_status()

        return response.json()

    def update(
        self,
        person_id: str,
        employment_id: str,
        data: Union[EmploymentUpdate, Dict[str, Any]]
    ) -> requests.Response:
        """
        Update an existing employment.

        Uses the v2 API endpoint: PATCH /v2/persons/{person_id}/employments/{employment_id}

        :param person_id: The person ID
        :param employment_id: The employment ID to update
        :param data: EmploymentUpdate model or dictionary with fields to update
        :return: Response object

        Example:
            update_data = EmploymentUpdate(
                position="Senior Software Engineer",
                weekly_working_hours=32.0
            )
            response = personio.employments.update("34629251", "emp-123", update_data)
        """
        url = f'{self.personio.base_url}v2/persons/{person_id}/employments/{employment_id}'
        headers = self.personio.get_headers_v2()

        # Convert Pydantic model to dict if necessary
        if isinstance(data, EmploymentUpdate):
            payload = data.model_dump(by_alias=True, exclude_none=True)
        else:
            payload = data

        response = self.personio.session.patch(
            url,
            headers=headers,
            json=payload,
            timeout=self.personio.timeout
        )

        return response
