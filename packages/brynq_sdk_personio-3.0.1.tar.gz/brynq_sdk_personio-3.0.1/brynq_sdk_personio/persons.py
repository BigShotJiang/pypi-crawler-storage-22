from typing import List, Optional, Tuple, Union, Dict, Any
import pandas as pd
import requests

from brynq_sdk_functions import Functions
from .schemas.person import PERSON_SCHEMAS
from .schemas.person_pydantic import PersonCreate, PersonUpdate


class Persons:
    """Persons resource for the Personio API.

    GET operations use the v1 API for full attribute data.
    CREATE/UPDATE/DELETE operations use the v2 API.
    """

    def __init__(self, personio):
        self.personio = personio

    def _get_schema(self):
        """Get the appropriate person schema based on the client's attribute_set setting."""
        return PERSON_SCHEMAS.get(self.personio.attribute_set, PERSON_SCHEMAS['default'])

    def _rename_dynamic_columns(self, df: pd.DataFrame) -> tuple[pd.DataFrame, set[str]]:
        """
        Rename dynamic_* columns using their universal_id if available.

        Personio returns custom attributes with a structure like:
        "dynamic_18199455": {
            "label": "Include In NL Payroll",
            "value": "",
            "type": "list",
            "universal_id": "include_in_payroll.nl"
        }

        This method renames the .value column from dynamic_* to the universal_id
        when universal_id is present. The universal_id is used as-is (dots preserved).

        Returns:
            Tuple of (dataframe, set of universal_id column names after cleanup)
        """
        # Find all universal_id columns for dynamic fields
        uid_cols_in_df = [col for col in df.columns if '.universal_id' in col and 'dynamic_' in col]

        rename_map = {}
        universal_id_names = set()  # Track the final universal_id column names

        for uid_col in uid_cols_in_df:
            # Get the base path (e.g., 'attributes.dynamic_18199455')
            base_path = uid_col.rsplit('.universal_id', 1)[0]
            value_col = f'{base_path}.value'

            if value_col in df.columns:
                # Get the first non-null universal_id value from this column
                uid_values = df[uid_col].dropna().unique()
                if len(uid_values) > 0 and uid_values[0]:
                    uid_value = str(uid_values[0])
                    # Use universal_id as the new column name (preserve dots)
                    new_name = f'{base_path.rsplit(".", 1)[0]}.{uid_value}.value'
                    rename_map[value_col] = new_name
                    # Track the final column name after .value is removed
                    universal_id_names.add(uid_value)

        if rename_map:
            df = df.rename(columns=rename_map)

        return df, universal_id_names

    def get(
        self,
        limit: int = 100,
        offset: int = 0,
        employee_ids: Optional[List[int]] = None
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Returns a list of persons with all their attributes.

        Uses the v1 employees endpoint which returns full person data including
        organizational fields (office, department, team, position, etc.).

        The schema used for validation depends on the client's attribute_set setting:
        - 'default': Uses PersonGet schema (core fields only)
        - 'afas': Uses PersonAFASGet schema (includes AFAS-specific fields)

        :param limit: Pagination limit per page. Default is 100.
        :param offset: Pagination offset. Default is 0.
        :param employee_ids: Optional list of employee IDs to filter.
        :return: Tuple of (valid_data, invalid_data) DataFrames
        """
        url = f'{self.personio.base_url}v1/company/employees?limit={limit}&offset={offset}'
        headers = self.personio.get_headers_v1()

        dfs = []
        page = 1
        while True:
            response = self.personio.session.get(url, headers=headers, timeout=self.personio.timeout)
            response.raise_for_status()
            dfs.append(pd.json_normalize(response.json()['data']))
            total_pages = response.json()['metadata']['total_pages']
            if page >= total_pages:
                break
            page += 1
            offset += limit
            url = f'{self.personio.base_url}v1/company/employees?limit={limit}&offset={offset}'

        df = pd.concat(dfs) if dfs else pd.DataFrame()

        # Rename dynamic_* columns using universal_id if available
        df, universal_id_cols = self._rename_dynamic_columns(df)

        # drop each column which ends with .label, .type and .universal_id
        df = df.drop(df.filter(regex=r'\.label$|\.type$|\.universal_id$').columns, axis=1)

        # Drop absence_entitlement and holiday_calendar columns (they have multiple lines per employee)
        df = df.drop(df.filter(regex=r'^attributes\.absence_entitlement|^attributes\.holiday_calendar').columns, axis=1)

        # These columns contain nested dicts, so their value is empty when json_normalized
        columns_to_drop = ['attributes.team.value', 'attributes.subcompany.value',
                          'attributes.department.value', 'attributes.office.value']
        existing_cols_to_drop = [col for col in columns_to_drop if col in df.columns]
        if existing_cols_to_drop:
            df = df.drop(columns=existing_cols_to_drop)

        # From the supervisor data, only keep the id column
        supervisor_cols = df.filter(regex=r'^attributes\.supervisor').columns
        for column in supervisor_cols:
            if column.endswith('.id.value'):
                df[column] = df[column].fillna(0)
                df.rename(columns={column: 'supervisor_id'}, inplace=True)
            else:
                df.drop(column, axis=1, inplace=True)

        # Clean up column names
        df.columns = df.columns.str.replace('attributes.', '', regex=False)
        df.columns = df.columns.str.replace('.value.id', '_id', regex=False)
        df.columns = df.columns.str.replace('.value.name', '', regex=False)
        df.columns = df.columns.str.replace('.value', '', regex=False)

        # Replace dots with underscores, but preserve dots in universal_id columns
        new_columns = []
        for col in df.columns:
            if col in universal_id_cols:
                new_columns.append(col)  # Keep dots for universal_id columns
            else:
                new_columns.append(col.replace('.', '_'))
        df.columns = new_columns

        if 'type' in df.columns:
            del df['type']

        # Filter by employee_ids if provided
        if employee_ids:
            df = df[df['id'].isin(employee_ids)]

        df = df.reset_index(drop=True)

        # Use the schema based on attribute_set
        schema = self._get_schema()
        return Functions.validate_data(df=df, schema=schema, debug=self.personio.debug)

    def get_by_id(self, person_id: str) -> Dict[str, Any]:
        """
        Retrieve a specific person by ID.

        Uses the v2 API endpoint.

        :param person_id: The person ID
        :return: Person data dictionary
        """
        url = f'{self.personio.base_url}v2/persons/{person_id}'
        headers = self.personio.get_headers_v2()

        response = self.personio.session.get(url, headers=headers, timeout=self.personio.timeout)
        response.raise_for_status()

        return response.json()

    def create(self, data: Union[PersonCreate, Dict[str, Any]]) -> requests.Response:
        """
        Create a new person with employment.

        Uses the v2 API endpoint: POST /v2/persons

        :param data: PersonCreate model or dictionary with person data
        :return: Response object

        Example:
            person_data = PersonCreate(
                first_name="John",
                last_name="Doe",
                email="john.doe@company.com",
                employment_start_date="2024-01-15",
                position="Software Engineer"
            )
            response = personio.persons.create(person_data)
        """
        url = f'{self.personio.base_url}v2/persons'
        headers = self.personio.get_headers_v2()

        # Convert Pydantic model to dict if necessary
        if isinstance(data, PersonCreate):
            payload = data.model_dump(by_alias=True, exclude_none=True)
        else:
            payload = data

        response = self.personio.session.post(
            url,
            headers=headers,
            json=payload,
            timeout=self.personio.timeout
        )

        return response

    def update(self, person_id: str, data: Union[PersonUpdate, Dict[str, Any]]) -> requests.Response:
        """
        Update an existing person.

        Uses the v2 API endpoint: PATCH /v2/persons/{id}

        :param person_id: The person ID to update
        :param data: PersonUpdate model or dictionary with fields to update
        :return: Response object

        Example:
            update_data = PersonUpdate(
                first_name="Jonathan",
                preferred_name="Jon"
            )
            response = personio.persons.update("34629251", update_data)
        """
        url = f'{self.personio.base_url}v2/persons/{person_id}'
        headers = self.personio.get_headers_v2()

        # Convert Pydantic model to dict if necessary
        if isinstance(data, PersonUpdate):
            payload = data.model_dump(by_alias=True, exclude_none=True)
        else:
            payload = data

        response = self.personio.session.patch(
            url,
            headers=headers,
            json=payload,
            timeout=self.personio.timeout
        )

        return response

    def delete(self, person_id: str) -> requests.Response:
        """
        Delete a person.

        Uses the v2 API endpoint: DELETE /v2/persons/{id}

        WARNING: This permanently deletes the person and all associated data.

        :param person_id: The person ID to delete
        :return: Response object
        """
        url = f'{self.personio.base_url}v2/persons/{person_id}'
        headers = self.personio.get_headers_v2()

        response = self.personio.session.delete(
            url,
            headers=headers,
            timeout=self.personio.timeout
        )

        return response
