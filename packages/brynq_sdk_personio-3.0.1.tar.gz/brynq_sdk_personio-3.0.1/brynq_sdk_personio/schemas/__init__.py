# Personio SDK schemas

# Pandera schemas (GET operations - data validation)
from .absence import AbsenscePeriodGet, AbsenceTypeGet
from .company import LegalEntitiesGet, OrgUnitsGet, CostCentersGet
from .compensation import CompensationGet, CompensationTypeGet
from .documents import DocumentCategoryGet, DocumentGet
from .employees import EmployeeGet, AbsenceEntitlementGet, HolidayCalendarGet
from .employment import EmploymentsGet
from .person import PersonGet, PersonAFASGet, PERSON_SCHEMAS

# Pydantic schemas (CREATE/UPDATE operations - input validation)
from .person_pydantic import (
    PersonCreate,
    PersonUpdate,
    EmploymentUpdate,
    CompensationCreate,
    CompensationTypeCreate,
)

__all__ = [
    # === Pandera schemas (GET) ===
    # Absence
    'AbsenscePeriodGet',
    'AbsenceTypeGet',
    # Company
    'LegalEntitiesGet',
    'OrgUnitsGet',
    'CostCentersGet',
    # Compensation
    'CompensationGet',
    'CompensationTypeGet',
    # Documents
    'DocumentCategoryGet',
    'DocumentGet',
    # Employees (v1 legacy API)
    'EmployeeGet',
    'AbsenceEntitlementGet',
    'HolidayCalendarGet',
    # Employments (v2 API)
    'EmploymentsGet',
    # Person (v1 API) - with attribute set variants
    'PersonGet',
    'PersonAFASGet',
    'PERSON_SCHEMAS',

    # === Pydantic schemas (CREATE/UPDATE) ===
    'PersonCreate',
    'PersonUpdate',
    'EmploymentUpdate',
    'CompensationCreate',
    'CompensationTypeCreate',
]
