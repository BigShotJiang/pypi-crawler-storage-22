# Pandera schemas for Personio Compensation endpoints

import pandas as pd
import pandera as pa
from pandera.typing import Series

try:
    from brynq_sdk_functions import BrynQPanderaDataFrameModel
except ImportError:
    class BrynQPanderaDataFrameModel(pa.DataFrameModel):
        pass


class CompensationGet(BrynQPanderaDataFrameModel):
    """Schema for compensation records from the v2 API."""

    id: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=False, description="Unique identifier for the compensation record", alias="id")
    person_id: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=False, description="ID of the person receiving this compensation", alias="person_id")
    legal_entity_id: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="ID of the legal entity providing the compensation", alias="legal_entity_id")
    type_name: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the compensation type", alias="type_name")
    type_category: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Category of compensation (FIXED_SALARY, ONE_TIME, etc.)", alias="type_category")
    amount_value: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Compensation amount value", alias="amount_value")
    amount_currency: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Currency of the compensation amount", alias="amount_currency")
    interval: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Payment interval (MONTHLY, YEARLY, etc.)", alias="interval")
    effective_from: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Date from which this compensation is effective", alias="effective_from")
    weekly_working_hours: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Number of hours worked per week for this compensation", alias="weekly_working_hours")
    full_time_weekly_working_hours: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Standard full-time hours per week", alias="full_time_weekly_working_hours")

    class _Annotation:
        primary_key = "id"
        foreign_keys = {
            "person_id": {
                "parent_schema": "PersonGet",
                "parent_column": "id",
                "cardinality": "N:1"
            },
            "legal_entity_id": {
                "parent_schema": "LegalEntitiesGet",
                "parent_column": "id",
                "cardinality": "N:1"
            }
        }


class CompensationTypeGet(BrynQPanderaDataFrameModel):
    """Schema for compensation type records."""

    id: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=False, description="Unique identifier for the compensation type", alias="id")
    name: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the compensation type", alias="name")
    category: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=False, description="Category of the compensation type (ONE_TIME, RECURRING)", alias="category")

    class _Annotation:
        primary_key = "id"
        foreign_keys = {}
