# Pandera schemas for Personio Documents endpoint

import pandas as pd
import pandera as pa
from pandera.typing import Series

try:
    from brynq_sdk_functions import BrynQPanderaDataFrameModel
except ImportError:
    class BrynQPanderaDataFrameModel(pa.DataFrameModel):
        pass


class DocumentCategoryGet(BrynQPanderaDataFrameModel):
    """Schema for document category records."""

    id: Series[pd.Int64Dtype] = pa.Field(coerce=True, nullable=False, description="Unique identifier for the document category", alias="id")
    description: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Description/name of the document category", alias="description")

    class _Annotation:
        primary_key = "id"
        foreign_keys = {}


class DocumentGet(BrynQPanderaDataFrameModel):
    """Schema for document metadata records from the v2 API."""

    id: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=False, description="Unique identifier for the document", alias="id")
    owner_id: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=False, description="ID of the document owner (employee)", alias="owner_id")
    category_id: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="ID of the document category", alias="category_id")
    title: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Title of the document", alias="title")
    created_at: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Timestamp when the document was created", alias="created_at")

    class _Annotation:
        primary_key = "id"
        foreign_keys = {
            "owner_id": {
                "parent_schema": "EmployeeGet",
                "parent_column": "id",
                "cardinality": "N:1"
            },
            "category_id": {
                "parent_schema": "DocumentCategoryGet",
                "parent_column": "id",
                "cardinality": "N:1"
            }
        }
