# Pandera schemas for Personio Employees endpoint (v1 legacy API)

import pandas as pd
import pandera as pa
from pandera.typing import Series

try:
    from brynq_sdk_functions import BrynQPanderaDataFrameModel
except ImportError:
    class BrynQPanderaDataFrameModel(pa.DataFrameModel):
        pass


class EmployeeGet(BrynQPanderaDataFrameModel):
    """Schema for employee records from the v1 legacy API.

    Note: This schema covers core fields. Dynamic custom fields (dynamic_*)
    are not validated and will pass through as-is.
    """

    id: Series[pd.Int64Dtype] = pa.Field(coerce=True, nullable=False, description="Unique identifier for the employee", alias="id")
    first_name: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Employee's first name", alias="first_name")
    last_name: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Employee's last name", alias="last_name")
    preferred_name: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Employee's preferred name for daily use", alias="preferred_name")
    email: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Employee's email address", alias="email")
    gender: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Employee's gender", alias="gender")
    status: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Employment status (active, inactive, onboarding, leave)", alias="status")
    position: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Employee's job position", alias="position")
    employment_type: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Type of employment (internal, external)", alias="employment_type")
    weekly_working_hours: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Weekly working hours", alias="weekly_working_hours")
    hire_date: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Date the employee was hired", alias="hire_date")
    contract_end_date: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Contract end date if applicable", alias="contract_end_date")
    termination_date: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Employment termination date", alias="termination_date")
    termination_type: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Type of termination", alias="termination_type")
    termination_reason: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Reason for termination", alias="termination_reason")
    probation_period_end: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="End date of probation period", alias="probation_period_end")
    created_at: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Timestamp when the employee record was created", alias="created_at")
    last_modified_at: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Timestamp when the employee record was last modified", alias="last_modified_at")
    last_working_day: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Last working day", alias="last_working_day")
    profile_picture: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="URL to employee's profile picture", alias="profile_picture")

    # Organizational fields
    supervisor_id: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the employee's supervisor", alias="supervisor_id")
    department_id: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the employee's department", alias="department_id")
    department: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the employee's department", alias="department")
    office_id: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the employee's office", alias="office_id")
    office: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the employee's office", alias="office")
    team_id: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the employee's team", alias="team_id")
    team: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the employee's team", alias="team")
    subcompany_id: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the employee's subcompany/legal entity", alias="subcompany_id")
    subcompany: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the employee's subcompany/legal entity", alias="subcompany")

    # Salary fields
    fix_salary: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Fixed salary amount", alias="fix_salary")
    fix_salary_currency: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Currency of fixed salary", alias="fix_salary_currency")
    fix_salary_interval: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Payment interval for fixed salary", alias="fix_salary_interval")
    hourly_salary: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Hourly salary amount", alias="hourly_salary")
    hourly_salary_currency: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Currency of hourly salary", alias="hourly_salary_currency")

    # Work schedule fields
    work_schedule_id: Series[pd.Int64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the work schedule", alias="work_schedule_id")
    work_schedule: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the work schedule", alias="work_schedule")
    work_schedule_valid_from: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Start date of the work schedule", alias="work_schedule_valid_from")
    work_schedule_monday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Monday", alias="work_schedule_monday")
    work_schedule_tuesday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Tuesday", alias="work_schedule_tuesday")
    work_schedule_wednesday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Wednesday", alias="work_schedule_wednesday")
    work_schedule_thursday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Thursday", alias="work_schedule_thursday")
    work_schedule_friday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Friday", alias="work_schedule_friday")
    work_schedule_saturday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Saturday", alias="work_schedule_saturday")
    work_schedule_sunday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Sunday", alias="work_schedule_sunday")

    class Config:
        # Allow extra columns (for dynamic_* custom fields)
        strict = False

    class _Annotation:
        primary_key = "id"
        foreign_keys = {
            "supervisor_id": {
                "parent_schema": "EmployeeGet",
                "parent_column": "id",
                "cardinality": "N:1"
            },
            "department_id": {
                "parent_schema": "OrgUnitsGet",
                "parent_column": "id",
                "cardinality": "N:1"
            },
            "team_id": {
                "parent_schema": "OrgUnitsGet",
                "parent_column": "id",
                "cardinality": "N:1"
            }
        }


class AbsenceEntitlementGet(BrynQPanderaDataFrameModel):
    """Schema for employee absence entitlement records."""

    employee_id: Series[pd.Int64Dtype] = pa.Field(coerce=True, nullable=False, description="ID of the employee", alias="employee_id")
    absence_type: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=False, description="Name of the absence type", alias="absence_type")
    absence_category: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Category of the absence type", alias="absence_category")
    entitlement: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Entitlement amount", alias="entitlement")

    class _Annotation:
        primary_key = "employee_id"
        foreign_keys = {
            "employee_id": {
                "parent_schema": "EmployeeGet",
                "parent_column": "id",
                "cardinality": "N:1"
            }
        }


class HolidayCalendarGet(BrynQPanderaDataFrameModel):
    """Schema for employee holiday calendar records."""

    employee_id: Series[pd.Int64Dtype] = pa.Field(coerce=True, nullable=False, description="ID of the employee", alias="employee_id")
    calendar_id: Series[pd.Int64Dtype] = pa.Field(coerce=True, nullable=False, description="ID of the holiday calendar", alias="calendar_id")
    calendar_name: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the holiday calendar", alias="calendar_name")
    country: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Country of the holiday calendar", alias="country")
    state: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="State/region of the holiday calendar", alias="state")

    class _Annotation:
        primary_key = "employee_id"
        foreign_keys = {
            "employee_id": {
                "parent_schema": "EmployeeGet",
                "parent_column": "id",
                "cardinality": "N:1"
            }
        }
