# Pandera schemas for Personio Employments endpoint (v2 API)

import pandas as pd
import pandera as pa
from pandera.typing import Series

try:
    from brynq_sdk_functions import BrynQPanderaDataFrameModel
except ImportError:
    class BrynQPanderaDataFrameModel(pa.DataFrameModel):
        pass


class EmploymentsGet(BrynQPanderaDataFrameModel):
    """Schema for employment records from the v2 API."""

    person_id: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=False, description="Unique identifier for the person", alias="person_id")
    id: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=False, description="Unique identifier for the employment record", alias="id")
    status: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Current status of the employment", alias="status")
    weekly_working_hours: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Number of hours worked per week", alias="weekly_working_hours")
    probation_end_date: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Date when probation period ends", alias="probation_end_date")
    employment_start_date: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Date when employment started", alias="employment_start_date")
    full_time_weekly_working_hours: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Standard full-time hours per week", alias="full_time_weekly_working_hours")
    employment_end_date: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Date when employment ended (if applicable)", alias="employment_end_date")
    type: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Type of employment contract", alias="type")
    contract_end_date: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Date when contract ends", alias="contract_end_date")
    created_at: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Timestamp when the employment record was created", alias="created_at")
    updated_at: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Timestamp when the employment record was last updated", alias="updated_at")

    class Config:
        # Allow extra columns from the API response
        strict = False

    class _Annotation:
        primary_key = "id"
        foreign_keys = {}
