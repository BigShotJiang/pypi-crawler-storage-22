# Pandera schemas for Personio Person endpoints (v1 API)

import pandas as pd
import pandera as pa
from pandera.typing import Series

try:
    from brynq_sdk_functions import BrynQPanderaDataFrameModel
except ImportError:
    class BrynQPanderaDataFrameModel(pa.DataFrameModel):
        pass


class PersonGet(BrynQPanderaDataFrameModel):
    """Schema for person records from the v1 API.

    Note: This schema covers core fields. Dynamic custom fields (dynamic_*)
    are not validated and will pass through as-is.
    """

    id: Series[pd.Int64Dtype] = pa.Field(coerce=True, nullable=False, description="Unique identifier for the person", alias="id")
    first_name: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's first name", alias="first_name")
    last_name: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's last name", alias="last_name")
    preferred_name: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's preferred name for daily use", alias="preferred_name")
    email: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's email address", alias="email")
    gender: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's gender", alias="gender")
    status: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Current employment status of the person", alias="status")
    position: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's job position", alias="position")
    employment_type: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Type of employment (internal, external)", alias="employment_type")
    weekly_working_hours: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Weekly working hours", alias="weekly_working_hours")
    hire_date: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Date the person was hired", alias="hire_date")
    contract_end_date: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Contract end date if applicable", alias="contract_end_date")
    termination_date: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Employment termination date", alias="termination_date")
    termination_type: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Type of termination", alias="termination_type")
    termination_reason: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Reason for termination", alias="termination_reason")
    probation_period_end: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="End date of probation period", alias="probation_period_end")
    created_at: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Timestamp when the person record was created", alias="created_at")
    last_modified_at: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Timestamp when the person record was last modified", alias="last_modified_at")
    last_working_day: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Last working day", alias="last_working_day")
    profile_picture: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="URL to person's profile picture", alias="profile_picture")

    # Organizational fields
    supervisor_id: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the person's supervisor", alias="supervisor_id")
    department_id: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the person's department", alias="department_id")
    department: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the person's department", alias="department")
    office_id: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the person's office", alias="office_id")
    office: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the person's office", alias="office")
    team_id: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the person's team", alias="team_id")
    team: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the person's team", alias="team")
    subcompany_id: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the person's subcompany/legal entity", alias="subcompany_id")
    subcompany: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the person's subcompany/legal entity", alias="subcompany")

    # Salary fields
    fix_salary: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Fixed salary amount", alias="fix_salary")
    fix_salary_currency: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Currency of fixed salary", alias="fix_salary_currency")
    fix_salary_interval: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Payment interval for fixed salary", alias="fix_salary_interval")
    hourly_salary: Series[pd.Float64Dtype] = pa.Field(coerce=True, nullable=True, description="Hourly salary amount", alias="hourly_salary")
    hourly_salary_currency: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Currency of hourly salary", alias="hourly_salary_currency")

    # Work schedule fields
    work_schedule_id: Series[pd.Int64Dtype] = pa.Field(coerce=True, nullable=True, description="ID of the work schedule", alias="work_schedule_id")
    work_schedule: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Name of the work schedule", alias="work_schedule")
    work_schedule_valid_from: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Start date of the work schedule", alias="work_schedule_valid_from")
    work_schedule_monday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Monday", alias="work_schedule_monday")
    work_schedule_tuesday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Tuesday", alias="work_schedule_tuesday")
    work_schedule_wednesday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Wednesday", alias="work_schedule_wednesday")
    work_schedule_thursday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Thursday", alias="work_schedule_thursday")
    work_schedule_friday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Friday", alias="work_schedule_friday")
    work_schedule_saturday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Saturday", alias="work_schedule_saturday")
    work_schedule_sunday: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Working hours on Sunday", alias="work_schedule_sunday")

    class Config:
        # Allow extra columns (for dynamic_* custom fields)
        strict = False

    class _Annotation:
        primary_key = "id"
        foreign_keys = {
            "supervisor_id": {
                "parent_schema": "PersonGet",
                "parent_column": "id",
                "cardinality": "N:1"
            },
            "department_id": {
                "parent_schema": "OrgUnitsGet",
                "parent_column": "id",
                "cardinality": "N:1"
            },
            "team_id": {
                "parent_schema": "OrgUnitsGet",
                "parent_column": "id",
                "cardinality": "N:1"
            }
        }


class PersonAFASGet(PersonGet):
    """Schema for person records with AFAS attribute set fields.

    Extends PersonGet with AFAS-specific custom attributes for Dutch payroll integration.
    The aliases map to Personio universal_id values for custom attributes.
    """

    # AFAS-specific fields (NL payroll integration)
    include_in_nl_payroll: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Whether the person is included in the NL payroll", alias="include_in_payroll.nl")
    business_phone: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's business phone number", alias="phone")
    nationality: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's nationality", alias="nationality.nl")
    address_street: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's street address", alias="address_street")
    address_number: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's house number", alias="address_number")
    address_addition: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's house number addition", alias="address_addition")
    address_postalcode: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's postal code", alias="postcode")
    address_state: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's state", alias="address_state.nl")
    address_city: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's city", alias="city")
    iban: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's IBAN", alias="iban")
    partner_last_name: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's partner last name", alias="partner_last_name.nl")
    social_security_number: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's social security number (BSN)", alias="ssn")
    type_of_employee: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's type of employee for AFAS", alias="employee_type.nl.afas")
    employee_number: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's employee number for AFAS", alias="employee_number.nl.afas")
    salutation: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Person's salutation for AFAS", alias="salutation.nl.afas")

    class _Annotation:
        primary_key = "id"
        foreign_keys = {
            "supervisor_id": {
                "parent_schema": "PersonGet",
                "parent_column": "id",
                "cardinality": "N:1"
            }
        }


# Registry of available attribute set schemas
PERSON_SCHEMAS = {
    'default': PersonGet,
    'afas': PersonAFASGet,
}
