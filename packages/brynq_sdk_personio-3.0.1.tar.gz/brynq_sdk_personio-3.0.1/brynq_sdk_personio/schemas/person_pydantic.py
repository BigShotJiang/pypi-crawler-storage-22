# Pydantic schemas for Personio Person CREATE/UPDATE operations (v2 API)

from typing import Optional
from pydantic import BaseModel, Field


class PersonCreate(BaseModel):
    """Schema for creating a new person with employment in Personio.

    Based on: https://developer.personio.de/reference/post_v2-persons
    """

    first_name: str = Field(
        ...,
        description="Person's first name",
        alias="firstName",
        example="John"
    )
    last_name: str = Field(
        ...,
        description="Person's last name",
        alias="lastName",
        example="Doe"
    )
    email: str = Field(
        ...,
        description="Person's email address",
        alias="email",
        example="john.doe@company.com"
    )
    gender: Optional[str] = Field(
        None,
        description="Person's gender (male, female, diverse, not_specified)",
        alias="gender",
        example="male"
    )
    preferred_name: Optional[str] = Field(
        None,
        description="Person's preferred name",
        alias="preferredName",
        example="Johnny"
    )

    # Employment fields (required when creating a person)
    employment_start_date: str = Field(
        ...,
        description="Start date of employment (YYYY-MM-DD)",
        alias="employmentStartDate",
        example="2024-01-15"
    )
    employment_type: Optional[str] = Field(
        "INTERNAL",
        description="Type of employment (INTERNAL, EXTERNAL)",
        alias="employmentType",
        example="INTERNAL"
    )
    position: Optional[str] = Field(
        None,
        description="Job position/title",
        alias="position",
        example="Software Engineer"
    )
    department_id: Optional[str] = Field(
        None,
        description="ID of the department",
        alias="departmentId",
        example="12345"
    )
    office_id: Optional[str] = Field(
        None,
        description="ID of the office/workplace",
        alias="officeId",
        example="67890"
    )
    team_id: Optional[str] = Field(
        None,
        description="ID of the team",
        alias="teamId",
        example="11111"
    )
    legal_entity_id: Optional[str] = Field(
        None,
        description="ID of the legal entity",
        alias="legalEntityId",
        example="22222"
    )
    weekly_working_hours: Optional[float] = Field(
        None,
        description="Weekly working hours",
        alias="weeklyWorkingHours",
        example=40.0
    )

    class Config:
        populate_by_name = True


class PersonUpdate(BaseModel):
    """Schema for updating an existing person in Personio.

    Based on: https://developer.personio.de/reference/patch_v2-persons-id
    """

    first_name: Optional[str] = Field(
        None,
        description="Person's first name",
        alias="firstName",
        example="John"
    )
    last_name: Optional[str] = Field(
        None,
        description="Person's last name",
        alias="lastName",
        example="Doe"
    )
    email: Optional[str] = Field(
        None,
        description="Person's email address",
        alias="email",
        example="john.doe@company.com"
    )
    gender: Optional[str] = Field(
        None,
        description="Person's gender (male, female, diverse, not_specified)",
        alias="gender",
        example="male"
    )
    preferred_name: Optional[str] = Field(
        None,
        description="Person's preferred name",
        alias="preferredName",
        example="Johnny"
    )

    class Config:
        populate_by_name = True


class EmploymentUpdate(BaseModel):
    """Schema for updating an employment in Personio.

    Based on: https://developer.personio.de/reference/patch_v2-persons-person_id-employments-id
    """

    position: Optional[str] = Field(
        None,
        description="Job position/title",
        alias="position",
        example="Senior Software Engineer"
    )
    department_id: Optional[str] = Field(
        None,
        description="ID of the department",
        alias="departmentId",
        example="12345"
    )
    office_id: Optional[str] = Field(
        None,
        description="ID of the office/workplace",
        alias="officeId",
        example="67890"
    )
    team_id: Optional[str] = Field(
        None,
        description="ID of the team",
        alias="teamId",
        example="11111"
    )
    legal_entity_id: Optional[str] = Field(
        None,
        description="ID of the legal entity",
        alias="legalEntityId",
        example="22222"
    )
    supervisor_id: Optional[str] = Field(
        None,
        description="ID of the supervisor (person ID)",
        alias="supervisorId",
        example="33333"
    )
    weekly_working_hours: Optional[float] = Field(
        None,
        description="Weekly working hours",
        alias="weeklyWorkingHours",
        example=40.0
    )
    contract_end_date: Optional[str] = Field(
        None,
        description="Contract end date (YYYY-MM-DD)",
        alias="contractEndDate",
        example="2025-12-31"
    )
    probation_end_date: Optional[str] = Field(
        None,
        description="Probation end date (YYYY-MM-DD)",
        alias="probationEndDate",
        example="2024-04-15"
    )
    employment_type: Optional[str] = Field(
        None,
        description="Type of employment (INTERNAL, EXTERNAL)",
        alias="employmentType",
        example="INTERNAL"
    )

    class Config:
        populate_by_name = True


class CompensationCreate(BaseModel):
    """Schema for creating a compensation in Personio.

    Based on: https://developer.personio.de/reference/post_v2-compensations
    """

    person_id: str = Field(
        ...,
        description="ID of the person",
        alias="personId",
        example="34629251"
    )
    type_id: str = Field(
        ...,
        description="ID of the compensation type",
        alias="typeId",
        example="019b0905-ac8e-a2e0-f973-70db3ce5f8f4"
    )
    amount: float = Field(
        ...,
        description="Compensation amount",
        alias="amount",
        example=5000.00
    )
    currency: str = Field(
        ...,
        description="Currency code (ISO 4217)",
        alias="currency",
        example="EUR"
    )
    effective_from: str = Field(
        ...,
        description="Effective date (YYYY-MM-DD)",
        alias="effectiveFrom",
        example="2024-01-01"
    )
    interval: Optional[str] = Field(
        "MONTHLY",
        description="Payment interval (MONTHLY, YEARLY, ONE_TIME, etc.)",
        alias="interval",
        example="MONTHLY"
    )
    legal_entity_id: Optional[str] = Field(
        None,
        description="ID of the legal entity",
        alias="legalEntityId",
        example="710787"
    )

    class Config:
        populate_by_name = True


class CompensationTypeCreate(BaseModel):
    """Schema for creating a compensation type in Personio.

    Based on: https://developer.personio.de/reference/post_v2-compensations-types
    """

    name: str = Field(
        ...,
        description="Name of the compensation type",
        alias="name",
        example="Annual Bonus"
    )
    category: str = Field(
        ...,
        description="Category (ONE_TIME, RECURRING)",
        alias="category",
        example="ONE_TIME"
    )

    class Config:
        populate_by_name = True
