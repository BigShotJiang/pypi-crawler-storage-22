# Generated endpoint class for tag: Employees
from typing import Any, Dict, List, Tuple
from uuid import UUID

import pandas as pd
import requests

from brynq_sdk_functions import Functions

from .paychecks import PayChecks
from .pensions import Pensions
from .schemas.employees import (
    EmployeeAdditionalUpdate,
    EmployeeCreate,
    EmployeeEmploymentDataUpdate,
    EmployeeEmploymentUpdate,
    EmployeePatch,
    EmployeesGet,
    EmployeesGetById,
    EmployeeUpdate,
    StartSaldo,
)


class Employees:
    """
    Handles all employees-related operations in Zenegy API
    """

    def __init__(self, zenegy):
        """
        Initialize the Employees class.

        Args:
            zenegy: The Zenegy instance to use for API calls
        """
        self.zenegy = zenegy
        self.endpoint = f"api/companies/{self.zenegy.company_uid}/employees"

        # Initialize paychecks and pensions
        self.paychecks = PayChecks(zenegy)
        self.pensions = Pensions(zenegy)

    def get(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        GetEmployeeBasesAsync
        Returns:
            Tuple of (valid_data, invalid_data) DataFrames with employee information
        """
        try:
            # Make the API request and get raw response
            content = self.zenegy.get(endpoint=self.endpoint)

            # Get data from response
            data = content.get("data", [])

            # Normalize the data
            df = pd.json_normalize(
                data,
                sep='__'
            )

            if df.empty:
                return pd.DataFrame(), pd.DataFrame()

            # Validate data using schema
            valid_data, invalid_data = Functions.validate_data(df, EmployeesGet)
            return valid_data, invalid_data

        except Exception as e:
            raise Exception(f"Failed to retrieve employees: {str(e)}") from e

    def get_by_id(self, employee_uid: UUID) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        GetEmployeeAsync

        Args:
            employee_uid (UUID): The employee uid
        Returns:
            Tuple of (valid_data, invalid_data) DataFrames with employee information
        """
        endpoint = f"{self.endpoint}/{employee_uid}"
        try:
            # Make the API request and get raw response
            content = self.zenegy.get(endpoint=endpoint)

            # Normalize the data (content is already a dict)
            df = pd.json_normalize(
                [content],  # Wrap single object in list for normalization
                sep='__'
            )

            if df.empty:
                return pd.DataFrame(), pd.DataFrame()

            # Validate data using detailed by-id schema
            valid_data, invalid_data = Functions.validate_data(df, EmployeesGetById)
            return valid_data, invalid_data

        except Exception as e:
            raise Exception(f"Failed to retrieve employee by ID: {str(e)}") from e

    def create(self, data: Dict[str, Any]) -> requests.Response:
        """
        PostEmployeeAsync
        Args:
            data (Dict[str, Any]): The data
        Returns:
            requests.Response: The API response
        """
        try:
            req_data = EmployeeCreate(**data)
            req_body = req_data.model_dump(by_alias=True, mode='json', exclude_none=True)
            response = self.zenegy.post(endpoint=self.endpoint.lstrip('/'), json=req_body)
            patch_body = self.create_update_body(data)

            # if the patch body is bigger than the request body, that means that there are fields left for the patch:
            # Count actual fields at the lowest level for proper comparison
            patch_field_count = self._count_nested_fields(patch_body)
            if patch_field_count > len(req_body):
                response_data = response.json()
                if isinstance(response_data, str):
                    uid = response_data
                elif isinstance(response_data, dict):
                    uid = response_data['data']['uid']
                patch_endpoint = f"{self.endpoint}/{uid}"

                response = self.zenegy.put(
                    endpoint=patch_endpoint.lstrip('/'),
                    json=patch_body
                )
                self.zenegy.raise_for_status_with_details(response)
                return response

            self.zenegy.raise_for_status_with_details(response)
            return response
        except Exception as e:
            raise Exception(f"Failed to create employee: {str(e)}")

    def create_and_patch(self, data: Dict[str, Any]) -> requests.Response:
        """
        PostEmployeeAsync

        This method handles employee creation in two steps due to Zenegy API limitations:
        1. Create the employee via POST with a limited set of required fields.
        2. Patch the newly created employee with the full dataset to update remaining fields
           (some fields are read-only during creation but writable during updates).

        Args:
            data (Dict[str, Any]): The full employee data dictionary.

        Returns:
            requests.Response: The response from the initial POST creation request.
        """
        try:
            req_data = EmployeeCreate(**data)
            req_body = req_data.model_dump(by_alias=True, mode='json', exclude_none=True)
            response = self.zenegy.post(endpoint=self.endpoint.lstrip('/'), json=req_body)
            self.zenegy.raise_for_status_with_details(response)

            # Get the uid of the created employee
            response_data = response.json()
            if isinstance(response_data, str):
                uid = response_data
            elif isinstance(response_data, dict):
                uid = response_data['data']['uid']

            # Patch the employee with the fields (patch what was created is okay, overwrite with same value)
            self.patch(uid, data)

            return response
        except Exception as e:
            raise Exception(f"Failed to create employee: {str(e)}")

    def upsert(self, data: Dict[str, Any]) -> requests.Response:
        """
        UpsertEmployeeAsync

        Args:
            data (Dict[str, Any]): The data to update

        Returns:
            requests.Response: The API response
        """
        endpoint = f"api/companies/{self.zenegy.company_uid}/employees"
        try:
            req_body = self.create_update_body(data)
            uid = data.get('employee_uid')
            endpoint = f"{self.endpoint}/{uid}".lstrip('/')
            response = self.zenegy.put(endpoint=endpoint, json=req_body)
            self.zenegy.raise_for_status_with_details(response)
            return response
        except Exception as e:
            raise Exception(f"Failed to update employee: {str(e)}")

    def delete(self, employee_uid: UUID) -> requests.Response:
        """
        DeleteEmployee

        Args:
            employee_uid (UUID): The employee uid
        Returns:
            requests.Response: The API response
        """
        endpoint = f"{self.endpoint}/{employee_uid}"
        try:
            response = self.zenegy.delete(endpoint=endpoint)
            self.zenegy.raise_for_status_with_details(response)
            return response
        except Exception as e:
            raise Exception(f"Failed to delete employee: {str(e)}")

    def create_update_body(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create the update body for the employee.
        """
        # There is strange logic in Zenegy that you can create an employee with only a limited set of fields. Afterward, you have to patch the employee with the rest of the fields.
        update_data = EmployeeUpdate(**data)
        body = update_data.model_dump(by_alias=True, mode='json', exclude_none=True)


        #-- START TODO: This is a temporary solution to handle the additional fields for the contract related fields in mft.
        #additional fields for contract related fields
        schema_map = {
            "startSaldo": StartSaldo,
            "employmentData": EmployeeEmploymentDataUpdate,
            "employeeEmployment": EmployeeEmploymentUpdate,
            "employeeAditional": EmployeeAdditionalUpdate
        }

        result_body = {"updateEmployeeBase": body}

        # Initialize required top-level fields with empty objects (API requires these to always be present)
        result_body["startSaldo"] = {} # can be passed empty
        result_body["employeeEmployment"] = {}
        result_body["employeeAditional"] = {"monthlySalaryFixedBase": 0}

        # Check if any fields from data match schema fields, and serialize accordingly
        for schema_name, schema_class in schema_map.items():
            schema_fields = schema_class.model_fields.keys()
            # Find matching keys between data and schema fields
            matching_data = {k: v for k, v in data.items() if k in schema_fields}

            # Skip if employee_number is the only field present
            if matching_data:  # and not (len(matching_data) == 1 and 'employee_number' in matching_data):
                # Serialize the matching data using the schema
                schema_instance = schema_class(**matching_data)
                serialized_data = schema_instance.model_dump(by_alias=True, mode='json', exclude_none=True)

                # startSaldo appears both inside updateEmployeeBase and at top level
                if schema_name == "startSaldo":
                    result_body["updateEmployeeBase"][schema_name] = serialized_data
                    result_body[schema_name] = serialized_data
                # employmentData appears inside updateEmployeeBase
                elif schema_name == "employmentData":
                    result_body["updateEmployeeBase"][schema_name] = serialized_data
                # employeeEmployment and employeeAditional appear at top level
                else:
                    result_body[schema_name] = serialized_data
        #--END TODO
        return result_body

    def _count_nested_fields(self, data: Dict[str, Any]) -> int:
        """
        Count the actual fields at the lowest level of a nested dictionary.
        https://www.google.com/search?client=firefox-b-d&sca_esv=4acce884baa46368&sxsrf=AE3TifPbAKp8zW8Gczemzqd3WYBgKrcwlg:1761129017606&q=recursion&spell=1&sa=X&ved=2ahUKEwja3v3rzLeQAxUwwAIHHZJVKZUQBSgAegQIFhAB

        Args:
            data: Dictionary that may contain nested dictionaries

        Returns:
            int: Total count of fields at the lowest level
        """
        count = 0
        for value in data.values():
            if isinstance(value, dict):
                count += self._count_nested_fields(value)
            else:
                count += 1
        return count

    def patch(self, employee_uid: UUID, data: Dict[str, Any], op: str = "replace") -> requests.Response:
        """
        PatchEmployee

        Single entry point for patching employees using a flat data dictionary.
        Flat keys may include prefixes for nested fields using a single underscore '_',
        e.g., 'start_saldo_start_g_days', 'language_name'. All generated operations
        are grouped into one or more PATCH requests to avoid all-or-none failures.

        Args:
            employee_uid (UUID): The employee uid
            data (Dict[str, Any]): Flat dictionary with EmployeeUpdate fields (supports '_' prefix nesting in keys)
            op (str): Operation type; defaults to "replace"

        Returns:
            requests.Response: Single response from the batch PATCH request
        """
        try:
            if not op:
                raise ValueError("Patch operation 'op' must be provided")

            operation_batches = self.build_patch_operation_batches(data=data, op=op)
            if not operation_batches:
                raise ValueError("No valid fields to patch")

            endpoint = f"{self.endpoint}/{employee_uid}".lstrip('/')
            last_response = None
            for operations in operation_batches:
                response = self.zenegy.patch(endpoint=endpoint, json=operations)
                self.zenegy.raise_for_status_with_details(response)
                last_response = response
            return last_response
        except Exception as e:
            raise Exception(f"Failed to patch employee: {str(e)}")


    def build_patch_operation_batches(self, data: Dict[str, Any], op: str = "replace") -> List[List[Dict[str, Any]]]:
        """
        Build grouped JSON Patch operations from a flat employee data dictionary.
        Grouping reduces validation failures when certain fields must be updated together.

        Args:
            data (Dict[str, Any]): Flat data with pythonic keys (e.g., name, email, start_g_days)
            op (str): JSON Patch op. Defaults to "replace".

        Returns:
            List[List[Dict[str, Any]]]: Batches of JSON Patch operations
        """
        if not isinstance(data, dict):
            raise ValueError("data must be a dictionary")
        if not op:
            raise ValueError("Patch operation 'op' must be provided")

        def is_blank_value(value: Any) -> bool:
            if value is None:
                return True
            if isinstance(value, str) and value.strip() == "":
                return True
            if isinstance(value, str) and value in ("nan", "NaN"):
                return True
            try:
                if pd.isna(value):
                    return True
            except Exception:
                pass
            return False

        payloads: List[Dict[str, Any]] = []
        processed_fields: set[str] = set()

        # Address fields must be patched together and cannot be blank
        address_fields = ["address", "postal_number", "city"]
        if any(field in data for field in address_fields):
            address_payload: Dict[str, Any] = {}
            for field in address_fields:
                if field in data:
                    value = data.get(field)
                    if not is_blank_value(value):
                        address_payload[field] = value
                    processed_fields.add(field)
            if address_payload:
                payloads.append(address_payload)

        # reg_number and konto_number should be patched together
        bank_fields = ["reg_number", "konto_number"]
        if any(field in data for field in bank_fields):
            bank_payload: Dict[str, Any] = {}
            for field in bank_fields:
                if field in data:
                    bank_payload[field] = data[field]
                    processed_fields.add(field)
            if bank_payload:
                payloads.append(bank_payload)

        # swift should be patched together with iban if provided
        if "swift" in data:
            swift_payload: Dict[str, Any] = {"swift": data.get("swift")}
            processed_fields.add("swift")
            if "iban" in data:
                swift_payload["iban"] = data.get("iban")
                processed_fields.add("iban")
            payloads.append(swift_payload)

        # department_id and department_uid should be patched together when available
        if "department_id" in data:
            dept_payload: Dict[str, Any] = {"department_id": data.get("department_id")}
            processed_fields.add("department_id")
            if "department_uid" in data:
                dept_payload["department_uid"] = data.get("department_uid")
                processed_fields.add("department_uid")
            payloads.append(dept_payload)

        # Every other field is sent separately to avoid all-or-none failures
        for field, value in data.items():
            if field not in processed_fields:
                payloads.append({field: value})
                processed_fields.add(field)

        operation_batches: List[List[Dict[str, Any]]] = []
        for payload in payloads:
            validated = EmployeePatch(**payload)
            alias_dump: Dict[str, Any] = validated.model_dump(
                by_alias=True,
                mode='json',
                exclude_none=True,
                exclude_unset=True,
            )
            if not alias_dump:
                continue
            operations: List[Dict[str, Any]] = []
            for alias_key, value in alias_dump.items():
                operations.append({
                    "op": op,
                    "path": f"/{alias_key}",
                    "value": value,
                })
            if operations:
                operation_batches.append(operations)

        return operation_batches
