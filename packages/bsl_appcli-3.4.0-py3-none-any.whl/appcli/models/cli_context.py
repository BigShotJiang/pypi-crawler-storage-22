#!/usr/bin/env python3
# # -*- coding: utf-8 -*-

"""
Outlines the CLI context.
________________________________________________________________________________

Created by brightSPARK Labs
www.brightsparklabs.com
"""

# Imports only used for type checking. Use this paradigm to prevent circular dependencies.
from __future__ import annotations

import typing

if typing.TYPE_CHECKING:
    from appcli.orchestrators import Orchestrator

# standard libraries
from pathlib import Path
from typing import Dict, Iterable, NamedTuple, Tuple

# local libraries
from appcli.configuration.configuration_dir_state import (
    ConfigurationDirState,
    ConfigurationDirStateFactory,
)
from appcli.logger import logger
from appcli.variables_manager import VariablesManager

# ------------------------------------------------------------------------------
# CONSTANTS
# ------------------------------------------------------------------------------

SCHEMA_SUFFIX = ".schema.json"
""" The suffix for the validation schema files. """

IGNORE_INFIX = ".appcli"
""" An infix extension to ignore when copying schema files. """


# ------------------------------------------------------------------------------
# PUBLIC CLASSES
# ------------------------------------------------------------------------------


class CliContext(NamedTuple):
    """Shared context from a run of the CLI."""

    # ---------------------------------
    # data passed in when CLI invoked on the command line
    # ---------------------------------

    configuration_dir: Path
    """ Directory to read configuration files from. """

    data_dir: Path
    """ Directory to use for persistent data storage. """

    backup_dir: Path
    """ Directory to store backups in. """

    application_context_files_dir: Path
    """ Directory containing application context files. """

    additional_data_dirs: Iterable[Tuple[str, Path]]
    """ Additional directories to use for persistent data storage. """

    additional_env_variables: Iterable[Tuple[str, str]]
    """ Additional environment variables to define in CLI container. """

    environment: str
    """ Environment to run. """

    docker_credentials_file: Path
    """ Path to the Docker credentials file (config.json) on the host for private docker registries. """

    subcommand_args: tuple
    """ Arguments passed to CLI subcommand. """

    debug: bool
    """ True to enable debug level logging. """

    is_dev_mode: bool
    """ True if the application is running in DEV MODE. """

    orchestrator: Orchestrator
    """ The application configured Orchestrator object. """

    # ---------------------------------
    # CLI build data
    # ---------------------------------

    app_name_slug: str
    """ The application's name """

    app_version: str
    """ The application's version """

    commands: Dict
    """ Internal commands. """

    # ---------------------------------
    # DEV_MODE specific fields.
    # ---------------------------------

    dev_mode_variables: Dict[str, str] = {}
    """ A Dict of `DEV_MODE` env variables the user has supplied to the appliction.
    These are set with:
        MYAPP_DEV_MODE_FOO=BAR python -m myapp ...
    Which would result in:
        dev_mode_variables = {"MYAPP_DEV_MODE_FOO": "BAR"}
    """

    # ---------------------------------
    # derived data
    # ---------------------------------

    def get_configuration_dir_state(self) -> ConfigurationDirState:
        """Gets the state of the configuration, for use in validating whether
        a command can be used or not.

        Returns:
            ConfigurationDirState: The state of the configuration.
        """

        try:
            generated_configuration_dir = self.get_generated_configuration_dir()
        except AttributeError:
            # If configuration_dir is None (like when we do an 'install'), then this raises AttributeError exception.
            # We cannot determine the generated_configuration_dir, so set it to None.
            generated_configuration_dir = None

        configuration_dir_state: ConfigurationDirState = (
            ConfigurationDirStateFactory.get_state(
                self.configuration_dir,
                generated_configuration_dir,
                self.app_version,
                self.backup_dir,
            )
        )
        logger.debug(
            f"Derived configuration state [{configuration_dir_state.__class__.__name__}]"
        )
        return configuration_dir_state

    def get_key_file(self) -> Path:
        """Get the location of the key file for decrypting secrets

        Returns:
            Path: location of the key file
        """
        return Path(self.configuration_dir, "key")

    def get_generated_configuration_dir(self) -> Path:
        """Get the directory containing the generated configuration

        Returns:
            Path: directory of generated configuration
        """
        return self.configuration_dir.joinpath(".generated")

    def get_configuration_metadata_dir(self) -> Path:
        """Get the directory containing the metadata for app configuration

        Returns:
            Path: directory of application metadata
        """
        return self.configuration_dir.joinpath(".metadata")

    def get_app_configuration_file(self) -> Path:
        """Get the location of the configuration file

        Returns:
            Path: location of the configuration file
        """
        return self.configuration_dir.joinpath("settings.yml")

    def get_app_configuration_file_schema(self) -> Path:
        """Get the location of the configuration schema file

        Returns:
            Path: location of the configuration schema file
        """
        return self.configuration_dir.joinpath("settings.yml", SCHEMA_SUFFIX)

    def get_stack_configuration_file(self) -> Path:
        """Get the location of the configuration file

        Returns:
            Path: location of the configuration file
        """
        return self.configuration_dir.joinpath("stack-settings.yml")

    def get_stack_configuration_file_schema(self) -> Path:
        """Get the location of the configuration schema file

        Returns:
            Path: location of the configuration schema file
        """
        return self.configuration_dir.joinpath("stack-settings.yml", SCHEMA_SUFFIX)

    def get_baseline_template_overrides_dir(self) -> Path:
        """Get the directory of the configuration template overrides

        Returns:
            Path: directory of configuration template overrides
        """
        return self.configuration_dir.joinpath("overrides")

    def get_configurable_templates_dir(self) -> Path:
        """Get the directory containing client-specific templates that
        aren't overrides,
        but that need to be applied separately.

        Returns:
            Path: directory of configurable templates
        """
        return self.configuration_dir.joinpath("templates")

    def get_project_name(self, make_helm_safe: bool = False) -> str:
        """Get a unique name for the application and environment

        Arg:
            make_helm_safe (bool): Convert the project name to one that is safe for helm.
                Helm uses `[a-z0-9]([-a-z0-9]*[a-z0-9])?` for validation.
                See https://github.com/helm/helm/issues/6192

        Returns:
            str: the project name
        """
        # NOTE: Must be lowercase, see https://github.com/brightsparklabs/appcli/issues/301
        project_name = f"{self.app_name_slug}_{self.environment}".lower()
        if make_helm_safe:
            project_name = project_name.replace("_", "-")
        return project_name

    def get_variables_manager(self) -> VariablesManager:
        """Get the Variables Manager for the current cli context.

        Returns:
            VariablesManager: the variables manager for the current cli context.
        """
        return VariablesManager(
            configuration_file=self.get_app_configuration_file(),
            stack_configuration_file=self.get_stack_configuration_file(),
            key_file=self.get_key_file(),
            application_context_files_dir=self.application_context_files_dir,
        )
