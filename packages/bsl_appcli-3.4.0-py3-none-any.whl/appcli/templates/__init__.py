# This __init__.py is required because `importlib.resources` can only fetch resource files from within a regular package
# See https://realpython.com/python-import/#introducing-importlibresources
