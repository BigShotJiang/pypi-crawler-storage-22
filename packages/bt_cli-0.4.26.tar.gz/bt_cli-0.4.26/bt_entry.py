#!/usr/bin/env python3
"""Entry point for PyInstaller build."""
import sys
import os

# Add src to path for imports
if getattr(sys, 'frozen', False):
    # Running as PyInstaller bundle
    bundle_dir = sys._MEIPASS
else:
    # Running as script
    bundle_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, os.path.join(bundle_dir, 'src'))

from bt_cli.cli import app

if __name__ == "__main__":
    app()
