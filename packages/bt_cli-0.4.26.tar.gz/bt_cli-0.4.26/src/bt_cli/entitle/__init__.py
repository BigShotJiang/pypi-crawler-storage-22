"""Entitle product module."""
