"""Quick commands for EPM Windows - combine multiple API calls into single operations."""

from datetime import datetime, timezone
from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error, print_error, print_warning, print_success
from ...core.prompts import prompt_from_list

app = typer.Typer(no_args_is_help=True, help="Quick commands - common multi-step operations in one command")
console = Console()


@app.command("stale")
def stale_computers(
    hours: int = typer.Option(24, "--hours", "-h", help="Hours since last checkin (default: 24)"),
    group: Optional[str] = typer.Option(None, "--group", "-g", help="Filter by group name (partial match)"),
    delete: bool = typer.Option(False, "--delete", help="Delete stale computers after listing"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation when deleting"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Find computers that haven't checked in recently.

    Shows computers that haven't connected in the specified number of hours.
    Optionally filter by group name. Use --delete to remove stale computers.

    Examples:
        bt epmw quick stale                          # Not checked in for 24+ hours
        bt epmw quick stale --hours 48               # Not checked in for 48+ hours
        bt epmw quick stale -h 12 -g "Workstations"  # Workstations not seen for 12+ hours
        bt epmw quick stale -o json                  # JSON output for scripting
        bt epmw quick stale --hours 72 --delete      # Delete computers not seen for 72+ hours
        bt epmw quick stale --delete --force         # Delete without confirmation
    """
    from ..client import get_client

    try:
        client = get_client()

        console.print(f"[dim]Finding computers not seen in {hours}+ hours...[/dim]")
        computers = client.list_computers()

        now = datetime.now(timezone.utc)
        stale_computers = []

        for comp in computers:
            # Parse last connected time
            last_connected_str = comp.get("lastConnected")
            if not last_connected_str:
                # Never connected - consider stale
                stale_computers.append(comp)
                continue

            try:
                # Parse ISO format datetime
                last_connected = datetime.fromisoformat(last_connected_str.replace("Z", "+00:00"))
                hours_since = (now - last_connected).total_seconds() / 3600

                if hours_since >= hours:
                    comp["_hours_since"] = round(hours_since, 1)
                    stale_computers.append(comp)
            except (ValueError, TypeError):
                # Can't parse date - include it
                comp["_hours_since"] = None
                stale_computers.append(comp)

        # Filter by group if specified
        if group:
            group_lower = group.lower()
            stale_computers = [
                c for c in stale_computers
                if group_lower in (c.get("groupName") or "").lower()
            ]

        if output == "json":
            # Clean up internal field for JSON output
            for comp in stale_computers:
                if "_hours_since" in comp:
                    comp["hoursSinceLastCheckin"] = comp.pop("_hours_since")
            console.print_json(json.dumps(stale_computers, default=str))
        else:
            if stale_computers:
                title = f"Computers not seen in {hours}+ hours"
                if group:
                    title += f" (group: {group})"

                table = Table(title=title)
                table.add_column("Host", style="cyan")
                table.add_column("Domain", style="yellow")
                table.add_column("Group", style="green")
                table.add_column("Hours Since", style="red", justify="right")
                table.add_column("Last Connected", style="dim")
                table.add_column("Status", style="magenta")

                for comp in stale_computers:
                    hours_since = comp.get("_hours_since")
                    hours_display = f"{hours_since:.1f}" if hours_since is not None else "N/A"

                    last_connected = comp.get("lastConnected", "Never")
                    if last_connected and last_connected != "Never":
                        # Format to readable date
                        try:
                            dt = datetime.fromisoformat(last_connected.replace("Z", "+00:00"))
                            last_connected = dt.strftime("%Y-%m-%d %H:%M")
                        except (ValueError, TypeError):
                            pass

                    table.add_row(
                        comp.get("host", ""),
                        comp.get("domain", "") or "-",
                        comp.get("groupName", "") or "-",
                        hours_display,
                        last_connected,
                        comp.get("connectionStatus", ""),
                    )

                console.print(table)
                console.print(f"\n[dim]Total: {len(stale_computers)} computer(s)[/dim]")

                # Delete stale computers if requested
                if delete and stale_computers:
                    console.print()
                    if not force:
                        confirm = typer.confirm(
                            f"Delete {len(stale_computers)} stale computer(s)?"
                        )
                        if not confirm:
                            console.print("[yellow]Deletion cancelled.[/yellow]")
                            raise typer.Exit(0)

                    console.print("[dim]Deleting stale computers...[/dim]")
                    deleted_count = 0
                    failed_count = 0
                    for comp in stale_computers:
                        comp_id = comp.get("id")
                        comp_host = comp.get("host", "Unknown")
                        try:
                            client.delete_computer(comp_id)
                            console.print(f"  [green]Deleted:[/green] {comp_host}")
                            deleted_count += 1
                        except Exception as e:
                            console.print(f"  [red]Failed:[/red] {comp_host} - {e}")
                            failed_count += 1

                    console.print()
                    print_success(f"Deleted {deleted_count} computer(s)")
                    if failed_count > 0:
                        print_warning(f"Failed to delete {failed_count} computer(s)")
            else:
                msg = f"All computers have checked in within the last {hours} hours"
                if group:
                    msg += f" (in group matching '{group}')"
                console.print(f"[green]{msg}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick stale")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick stale")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "quick stale")
        raise typer.Exit(1)


@app.command("disconnected")
def disconnected_computers(
    group: Optional[str] = typer.Option(None, "--group", "-g", help="Filter by group name (partial match)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Find computers with disconnected status.

    Shows all computers that are currently marked as disconnected.

    Examples:
        bt epmw quick disconnected
        bt epmw quick disconnected -g "Servers"
        bt epmw quick disconnected -o json
    """
    from ..client import get_client

    try:
        client = get_client()

        console.print("[dim]Finding disconnected computers...[/dim]")
        computers = client.list_computers()

        # Filter to disconnected status
        disconnected = [
            c for c in computers
            if c.get("connectionStatus", "").lower() == "disconnected"
        ]

        # Filter by group if specified
        if group:
            group_lower = group.lower()
            disconnected = [
                c for c in disconnected
                if group_lower in (c.get("groupName") or "").lower()
            ]

        if output == "json":
            console.print_json(json.dumps(disconnected, default=str))
        else:
            if disconnected:
                title = "Disconnected Computers"
                if group:
                    title += f" (group: {group})"

                table = Table(title=title)
                table.add_column("Host", style="cyan")
                table.add_column("Domain", style="yellow")
                table.add_column("Group", style="green")
                table.add_column("Days Disconnected", style="red", justify="right")
                table.add_column("Last Connected", style="dim")

                for comp in disconnected:
                    days_disc = comp.get("daysDisconnected", 0)

                    last_connected = comp.get("lastConnected", "Never")
                    if last_connected and last_connected != "Never":
                        try:
                            dt = datetime.fromisoformat(last_connected.replace("Z", "+00:00"))
                            last_connected = dt.strftime("%Y-%m-%d %H:%M")
                        except (ValueError, TypeError):
                            pass

                    table.add_row(
                        comp.get("host", ""),
                        comp.get("domain", "") or "-",
                        comp.get("groupName", "") or "-",
                        str(days_disc),
                        last_connected,
                    )

                console.print(table)
                console.print(f"\n[dim]Total: {len(disconnected)} computer(s)[/dim]")
            else:
                msg = "No disconnected computers found"
                if group:
                    msg += f" in group matching '{group}'"
                console.print(f"[green]{msg}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick disconnected")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick disconnected")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "quick disconnected")
        raise typer.Exit(1)


@app.command("status")
def group_status(
    group: Optional[str] = typer.Option(None, "--group", "-g", help="Filter by group name (partial match)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Show computer status summary by group.

    Displays counts of connected/disconnected computers per group.

    Examples:
        bt epmw quick status
        bt epmw quick status -g "Datacenter"
        bt epmw quick status -o json
    """
    from ..client import get_client

    try:
        client = get_client()

        console.print("[dim]Getting computer status by group...[/dim]")
        computers = client.list_computers()

        # Filter by group if specified
        if group:
            group_lower = group.lower()
            computers = [
                c for c in computers
                if group_lower in (c.get("groupName") or "").lower()
            ]

        # Group by group name
        groups: dict = {}
        for comp in computers:
            group_name = comp.get("groupName") or "(No Group)"
            if group_name not in groups:
                groups[group_name] = {"connected": 0, "disconnected": 0, "total": 0}

            groups[group_name]["total"] += 1
            status = comp.get("connectionStatus", "").lower()
            if status == "connected":
                groups[group_name]["connected"] += 1
            else:
                groups[group_name]["disconnected"] += 1

        if output == "json":
            console.print_json(json.dumps(groups, default=str))
        else:
            if groups:
                table = Table(title="Computer Status by Group")
                table.add_column("Group", style="cyan")
                table.add_column("Connected", style="green", justify="right")
                table.add_column("Disconnected", style="red", justify="right")
                table.add_column("Total", style="bold", justify="right")

                total_connected = 0
                total_disconnected = 0
                total_all = 0

                for group_name, counts in sorted(groups.items()):
                    table.add_row(
                        group_name,
                        str(counts["connected"]),
                        str(counts["disconnected"]),
                        str(counts["total"]),
                    )
                    total_connected += counts["connected"]
                    total_disconnected += counts["disconnected"]
                    total_all += counts["total"]

                # Add totals row
                table.add_row(
                    "[bold]TOTAL[/bold]",
                    f"[bold green]{total_connected}[/bold green]",
                    f"[bold red]{total_disconnected}[/bold red]",
                    f"[bold]{total_all}[/bold]",
                )

                console.print(table)
            else:
                console.print("[yellow]No computers found[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick status")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick status")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "quick status")
        raise typer.Exit(1)


@app.command("move-computer")
def move_computer(
    computer: Optional[str] = typer.Option(None, "--computer", "-c", help="Computer name or ID (partial match for name)"),
    group: Optional[str] = typer.Option(None, "--group", "-g", help="Target group name or ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Move a computer to a different group.

    Interactive workflow to change a computer's group membership.
    Lists computers (optionally filtered), then lists available groups,
    and moves the selected computer to the selected group.

    Examples:
        bt epmw quick move-computer                           # Interactive selection
        bt epmw quick move-computer -c "CorpWS01"             # Filter by computer name
        bt epmw quick move-computer -c "CorpWS01" -g "Servers"  # Specify both
        bt epmw quick move-computer -c "CorpWS01" -g "Servers" -f  # Skip confirmation
    """
    from ..client import get_client

    try:
        client = get_client()

        # Step 1: Get and filter computers
        console.print("[dim]Fetching computers...[/dim]")
        computers = client.list_computers()

        if not computers:
            print_error("No computers found")
            raise typer.Exit(1)

        # Filter by computer name/ID if provided
        if computer:
            computer_lower = computer.lower()
            filtered = [
                c for c in computers
                if computer_lower in (c.get("host") or "").lower()
                or computer_lower in (c.get("id") or "").lower()
            ]
            if not filtered:
                print_error(f"No computers matching '{computer}'")
                raise typer.Exit(1)
            computers = filtered

        # Show computers and select one
        if len(computers) == 1:
            selected_computer = computers[0]
            console.print(f"[dim]Found computer: {selected_computer.get('host')}[/dim]")
        else:
            # Show list and prompt for selection
            table = Table(title="Available Computers")
            table.add_column("#", style="dim", justify="right")
            table.add_column("Host", style="cyan")
            table.add_column("Domain", style="yellow")
            table.add_column("Current Group", style="green")
            table.add_column("Status", style="magenta")

            for idx, comp in enumerate(computers, 1):
                table.add_row(
                    str(idx),
                    comp.get("host", ""),
                    comp.get("domain", "") or "-",
                    comp.get("groupName", "") or "-",
                    comp.get("connectionStatus", ""),
                )
            console.print(table)

            selection = typer.prompt("Select computer number", type=int)
            if selection < 1 or selection > len(computers):
                print_error(f"Invalid selection. Choose 1-{len(computers)}")
                raise typer.Exit(1)
            selected_computer = computers[selection - 1]

        computer_id = selected_computer.get("id")
        computer_host = selected_computer.get("host")
        current_group = selected_computer.get("groupName") or "(No Group)"

        # Step 2: Get and filter groups
        console.print("[dim]Fetching groups...[/dim]")
        groups = client.list_groups()

        if not groups:
            print_error("No groups found")
            raise typer.Exit(1)

        # Filter by group name/ID if provided
        if group:
            group_lower = group.lower()
            filtered = [
                g for g in groups
                if group_lower in (g.get("name") or "").lower()
                or group_lower in (g.get("id") or "").lower()
            ]
            if not filtered:
                print_error(f"No groups matching '{group}'")
                raise typer.Exit(1)
            groups = filtered

        # Show groups and select one
        if len(groups) == 1:
            selected_group = groups[0]
            console.print(f"[dim]Target group: {selected_group.get('name')}[/dim]")
        else:
            # Show list and prompt for selection
            table = Table(title="Available Groups")
            table.add_column("#", style="dim", justify="right")
            table.add_column("Name", style="cyan")
            table.add_column("Computers", style="green", justify="right")
            table.add_column("Policy", style="yellow")

            for idx, grp in enumerate(groups, 1):
                table.add_row(
                    str(idx),
                    grp.get("name", ""),
                    str(grp.get("computerCount", 0)),
                    grp.get("policyName", "") or "-",
                )
            console.print(table)

            selection = typer.prompt("Select target group number", type=int)
            if selection < 1 or selection > len(groups):
                print_error(f"Invalid selection. Choose 1-{len(groups)}")
                raise typer.Exit(1)
            selected_group = groups[selection - 1]

        group_id = selected_group.get("id")
        group_name = selected_group.get("name")

        # Check if already in target group
        if current_group == group_name:
            console.print(f"[yellow]Computer '{computer_host}' is already in group '{group_name}'[/yellow]")
            raise typer.Exit(0)

        # Step 3: Confirm and move
        if not force:
            console.print()
            console.print(f"[bold]Move computer:[/bold] {computer_host}")
            console.print(f"[bold]From group:[/bold] {current_group}")
            console.print(f"[bold]To group:[/bold] {group_name}")
            console.print()
            confirm = typer.confirm("Proceed with move?")
            if not confirm:
                console.print("[yellow]Cancelled.[/yellow]")
                raise typer.Exit(0)

        # Perform the move
        console.print("[dim]Moving computer to group...[/dim]")
        client.assign_computers_to_group(group_id, [computer_id])

        if output == "json":
            result = {
                "computer": {
                    "id": computer_id,
                    "host": computer_host,
                },
                "previousGroup": current_group,
                "newGroup": group_name,
                "success": True,
            }
            console.print_json(json.dumps(result, default=str))
        else:
            print_success(f"Moved '{computer_host}' from '{current_group}' to '{group_name}'")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "quick move-computer")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "quick move-computer")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "quick move-computer")
        raise typer.Exit(1)
