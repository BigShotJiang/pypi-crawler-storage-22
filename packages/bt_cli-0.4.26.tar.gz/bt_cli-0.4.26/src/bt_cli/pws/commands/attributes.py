"""Attribute commands for Password Safe."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_table, print_json, print_error, print_success, print_api_error

app = typer.Typer(no_args_is_help=True, help="Manage attributes")


@app.command("list")
def list_attributes(
    attribute_type: Optional[str] = typer.Option(
        None, "--type", "-t",
        help="Filter by type: Asset, ManagedSystem, ManagedAccount"
    ),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List all defined attributes."""
    from bt_cli.pws.client import get_client

    try:
        with get_client() as client:
            attributes = client.list_attributes(attribute_type=attribute_type)

        if output == OutputFormat.JSON:
            print_json(attributes)
        else:
            columns = [
                ("ID", "AttributeID"),
                ("Name", "AttributeName"),
                ("Type", "AttributeType"),
                ("Description", "Description"),
            ]
            print_table(attributes, columns, title="Attributes")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list attributes")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list attributes")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list attributes")
        raise typer.Exit(1)


@app.command("get")
def get_attribute(
    attribute_id: int = typer.Argument(..., help="Attribute ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Get attribute details."""
    from bt_cli.pws.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        with get_client() as client:
            attr = client.get_attribute(attribute_id)

        if output == OutputFormat.JSON:
            print_json(attr)
        else:
            name = attr.get("AttributeName", "")
            attr_type = attr.get("AttributeType", "")
            description = attr.get("Description", "") or "-"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Type:[/dim] {attr_type}\n"
                f"[dim]Description:[/dim] {description}",
                title="Attribute Details",
                subtitle=f"ID: {attr.get('AttributeID', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get attribute")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get attribute")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get attribute")
        raise typer.Exit(1)


@app.command("show-for-system")
def show_system_attributes(
    system_id: int = typer.Argument(..., help="Managed System ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Show attributes assigned to a managed system."""
    from bt_cli.pws.client import get_client

    try:
        with get_client() as client:
            attributes = client.get_managed_system_attributes(system_id)

        if output == OutputFormat.JSON:
            print_json(attributes)
        else:
            if not attributes:
                print_error(f"No attributes assigned to managed system {system_id}")
                return

            columns = [
                ("ID", "AttributeID"),
                ("Name", "AttributeName"),
                ("Type", "AttributeType"),
            ]
            print_table(attributes, columns, title=f"Attributes for Managed System {system_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "show system attributes")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "show system attributes")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "show system attributes")
        raise typer.Exit(1)


@app.command("assign")
def assign_attribute(
    system_id: int = typer.Argument(..., help="Managed System ID"),
    attribute_id: int = typer.Argument(..., help="Attribute ID to assign"),
):
    """Assign an attribute to a managed system."""
    from bt_cli.pws.client import get_client

    try:
        with get_client() as client:
            client.assign_managed_system_attribute(system_id, attribute_id)
            print_success(f"Assigned attribute {attribute_id} to managed system {system_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "assign attribute")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "assign attribute")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "assign attribute")
        raise typer.Exit(1)


@app.command("remove")
def remove_attribute(
    system_id: int = typer.Argument(..., help="Managed System ID"),
    attribute_id: int = typer.Argument(..., help="Attribute ID to remove"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Remove an attribute from a managed system."""
    from bt_cli.pws.client import get_client

    if not force:
        typer.confirm(
            f"Remove attribute {attribute_id} from managed system {system_id}?",
            abort=True
        )

    try:
        with get_client() as client:
            client.remove_managed_system_attribute(system_id, attribute_id)
            print_success(f"Removed attribute {attribute_id} from managed system {system_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "remove attribute")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "remove attribute")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "remove attribute")
        raise typer.Exit(1)
