"""EPMW module tests."""
