---
name: Feature Request
about: Suggest a feature for the BugStack Python SDK
title: "[Feature] "
labels: enhancement
---

**Describe the feature**
A clear description of what you'd like.

**Use case**
Why is this feature useful? What problem does it solve?

**Proposed API**
```python
# How would you like to use this feature?
```
