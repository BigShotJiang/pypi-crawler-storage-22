## Summary

<!-- What does this PR do? -->

## Test Plan

- [ ] Tests added/updated
- [ ] All tests pass (`pytest`)
- [ ] Linting passes (`ruff check .`)
- [ ] Type checking passes (`mypy src/bugstack`)
