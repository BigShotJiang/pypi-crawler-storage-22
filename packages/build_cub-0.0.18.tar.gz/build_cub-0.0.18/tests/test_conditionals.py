"""Tests for the expression-based conditional system."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from build_cub.models._conditionals import Condition, Conditionals, Parts
from build_cub.utils._dsl import DSLParser


class TestParts:
    """Tests for the Parts NamedTuple path parser."""

    def test_platform_path(self) -> None:
        parts = Parts.create("platform.darwin")
        assert parts.type == "platform"
        assert parts.when == "darwin"

    def test_env_path(self) -> None:
        parts = Parts.create("env.BUILD_CUB_DEBUG")
        assert parts.type == "env"
        assert parts.when == "BUILD_CUB_DEBUG"

    def test_python_path(self) -> None:
        parts = Parts.create("python.3_14")
        assert parts.type == "python"
        assert parts.when == "3_14"

    def test_custom_path(self) -> None:
        parts = Parts.create("my_custom_thing")
        assert parts.type == "my_custom_thing"
        assert parts.when == ""


class TestConditionCreate:
    """Tests for Condition.create() with implicit when generation."""

    def test_platform_implicit_when(self) -> None:
        cond = Condition.create("platform.darwin", expr="settings.do_thing()")
        assert cond.type == "platform"
        assert cond.when == "platform.os == 'darwin'"
        assert cond.expr == "settings.do_thing()"

    def test_platform_explicit_when_override(self) -> None:
        cond = Condition.create("platform.darwin", expr="settings.do_thing()", when="custom_check")
        assert cond.when == "custom_check"

    def test_env_implicit_when(self) -> None:
        cond = Condition.create("env.BUILD_CUB_DEBUG", expr="settings.add_flag()")
        assert cond.type == "env"
        assert cond.when == "'BUILD_CUB_DEBUG' in env"

    def test_python_implicit_when(self) -> None:
        cond = Condition.create("python.3_14", expr="print('hello')")
        assert cond.type == "python"
        assert cond.when == "python >= (3, 14)"

    def test_python_3_12(self) -> None:
        cond = Condition.create("python.3_12", expr="print('old python')")
        assert cond.when == "python >= (3, 12)"

    def test_custom_defaults_to_true(self) -> None:
        cond = Condition.create("my_custom", expr="settings.whatever()")
        assert cond.type == "custom"
        assert cond.when == "True"


class TestConditionalsModel:
    """Tests for the Conditionals Pydantic model."""

    def test_empty_conditionals(self) -> None:
        cond = Conditionals()
        assert cond.empty
        assert not cond.not_empty

    def test_captures_platform_conditional(self) -> None:
        cond = Conditionals.model_validate({"platform": {"darwin": {"expr": "settings.add_flag()"}}})
        assert cond.not_empty
        assert "platform.darwin" in cond._collected
        collected = cond._collected["platform.darwin"]
        assert collected.type == "platform"
        assert collected.when == "platform.os == 'darwin'"

    def test_captures_env_conditional(self) -> None:
        cond = Conditionals.model_validate({"env": {"BUILD_CUB_DEBUG": {"expr": "settings.add_debug()"}}})
        assert "env.BUILD_CUB_DEBUG" in cond._collected
        collected = cond._collected["env.BUILD_CUB_DEBUG"]
        assert collected.type == "env"
        assert collected.when == "'BUILD_CUB_DEBUG' in env"

    def test_captures_python_conditional(self) -> None:
        cond = Conditionals.model_validate({"python": {"3_14": {"expr": "print('py314')"}}})
        assert "python.3_14" in cond._collected
        collected = cond._collected["python.3_14"]
        assert collected.when == "python >= (3, 14)"

    def test_captures_explicit_when(self) -> None:
        cond = Conditionals.model_validate(
            {
                "custom_thing": {
                    "when": "platform.os == 'linux' and 'SPECIAL' in env",
                    "expr": "settings.linux_special()",
                }
            }
        )
        assert "custom_thing" in cond._collected
        collected = cond._collected["custom_thing"]
        assert collected.type == "custom"
        assert collected.when == "platform.os == 'linux' and 'SPECIAL' in env"

    def test_multiple_conditionals(self) -> None:
        cond = Conditionals.model_validate(
            {
                "platform": {"darwin": {"expr": "a()"}, "linux": {"expr": "b()"}},
                "env": {"DEBUG": {"expr": "c()"}},
            }
        )
        assert len(cond._collected) == 3
        assert "platform.darwin" in cond._collected
        assert "platform.linux" in cond._collected
        assert "env.DEBUG" in cond._collected


class TestDSLParserConditions:
    """Tests for DSLParser evaluating conditions."""

    def test_eval_true_simple(self) -> None:
        dsl = DSLParser(namespace={"x": 5})
        assert dsl.eval_true("x == 5")
        assert not dsl.eval_true("x == 10")

    def test_eval_platform_check(self) -> None:
        mock_platform = MagicMock()
        mock_platform.os = "darwin"
        dsl = DSLParser(namespace={"platform": mock_platform})
        assert dsl.eval_true("platform.os == 'darwin'")
        assert not dsl.eval_true("platform.os == 'linux'")

    def test_eval_python_version(self) -> None:
        dsl = DSLParser(namespace={"python": (3, 14)})
        assert dsl.eval_true("python >= (3, 14)")
        assert dsl.eval_true("python >= (3, 12)")
        assert not dsl.eval_true("python >= (3, 15)")

    def test_eval_env_function(self) -> None:
        env = {"EXISTS"}

        dsl = DSLParser(namespace={"env": env})
        assert dsl.eval_true("'EXISTS' in env")
        assert not dsl.eval_true("'NOPE' in env")

    def test_eval_compound_condition(self) -> None:
        mock_platform = MagicMock()
        mock_platform.os = "darwin"

        env = {"DEBUG"}

        dsl = DSLParser(namespace={"platform": mock_platform, "env": env})
        assert dsl.eval_true("platform.os == 'darwin' and 'DEBUG' in env")
        assert not dsl.eval_true("platform.os == 'linux' and 'DEBUG' in env")


class TestDSLParserExec:
    """Tests for DSLParser executing actions."""

    def test_exec_method_call(self) -> None:
        mock_settings = MagicMock()
        dsl = DSLParser(namespace={"settings": mock_settings})
        dsl.exec_action("settings.add_to_compile_args(['-g'])")
        mock_settings.add_to_compile_args.assert_called_once_with(["-g"])

    def test_exec_multiple_args(self) -> None:
        mock_settings = MagicMock()
        dsl = DSLParser(namespace={"settings": mock_settings})
        dsl.exec_action("settings.add_to_compile_args(['-O3', '-ffast-math'])")
        mock_settings.add_to_compile_args.assert_called_once_with(["-O3", "-ffast-math"])

    def test_exec_rejects_forbidden_nodes(self) -> None:
        dsl = DSLParser(namespace={})
        with pytest.raises(ValueError, match="Invalid expression"):
            dsl.exec_action("import os")

    def test_exec_rejects_dunder_access(self) -> None:
        dsl = DSLParser(namespace={"x": "hello"})
        with pytest.raises(ValueError, match="Invalid expression"):
            dsl.exec_action("x.__class__")


class TestApplyAll:
    """Integration tests for Conditionals.apply_all()."""

    def test_apply_all_platform_match(self, monkeypatch: pytest.MonkeyPatch) -> None:
        mock_platform = MagicMock()
        mock_platform.os = "darwin"
        mock_python = (3, 14)

        mock_global_config = MagicMock()
        mock_global_config.platform = mock_platform
        mock_global_config.python_ver = mock_python

        monkeypatch.setattr("build_cub.models._conditionals.global_config", mock_global_config)

        mock_settings = MagicMock()
        mock_settings._SETTINGS_ = True
        mock_printer = MagicMock()

        cond = Conditionals.model_validate(
            {
                "env_var_prefix": "TEST_",
                "platform": {"darwin": {"expr": "settings.add_to_compile_args(['-darwin-flag'])"}},
            }
        )

        cond.apply_all(mock_settings, printer=mock_printer)
        mock_settings.add_to_compile_args.assert_called_once_with(["-darwin-flag"])

    def test_apply_all_platform_no_match(self, monkeypatch: pytest.MonkeyPatch) -> None:
        mock_platform = MagicMock()
        mock_platform.os = "linux"
        mock_python = (3, 14)

        mock_global_config = MagicMock()
        mock_global_config.platform = mock_platform
        mock_global_config.python_ver = mock_python

        monkeypatch.setattr("build_cub.models._conditionals.global_config", mock_global_config)

        mock_settings = MagicMock()
        mock_settings._SETTINGS_ = True
        mock_printer = MagicMock()

        cond = Conditionals.model_validate(
            {
                "env_var_prefix": "TEST_",
                "platform": {"darwin": {"expr": "settings.add_to_compile_args(['-darwin-flag'])"}},
            }
        )

        cond.apply_all(mock_settings, printer=mock_printer)
        mock_settings.add_to_compile_args.assert_not_called()

    def test_apply_all_env_with_prefix(self, monkeypatch: pytest.MonkeyPatch) -> None:
        mock_platform = MagicMock()
        mock_platform.os = "darwin"
        mock_python = (3, 14)

        mock_global_config = MagicMock()
        mock_global_config.platform = mock_platform
        mock_global_config.python_ver = mock_python

        monkeypatch.setattr("build_cub.models._conditionals.global_config", mock_global_config)
        monkeypatch.setenv("BUILD_CUB_DEBUG", "1")

        mock_settings = MagicMock()
        mock_settings._SETTINGS_ = True
        mock_printer = MagicMock()

        cond = Conditionals.model_validate(
            {
                "env_var_prefix": "BUILD_CUB_",
                "env": {"BUILD_CUB_DEBUG": {"expr": "settings.add_to_compile_args(['-g'])"}},
            }
        )

        cond.apply_all(mock_settings, printer=mock_printer)
        mock_settings.add_to_compile_args.assert_called_once_with(["-g"])


# ruff: noqa: D102
