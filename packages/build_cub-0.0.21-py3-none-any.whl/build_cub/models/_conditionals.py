from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, NamedTuple, Self

from pydantic import BaseModel, ConfigDict, PrivateAttr, model_validator

from build_cub.utils import EMPTY_IMMUTABLE_LIST, ColorPrinter, global_config, item_check
from build_cub.utils._dsl import DSLParser

if TYPE_CHECKING:
    from ._base import BaseBackendSettings


type ConditionType = Literal["custom", "platform", "env", "python"]


class NULL_CLASS:  # noqa: N801
    """It's Null, what else do you need to know?"""

    def __getattr__(self, item: str) -> None:
        return None


class Parts(NamedTuple):
    type: Any = "custom"
    when: Any = ""

    @classmethod
    def create(cls, path: str) -> Self:
        return cls(*path.removeprefix(".conditionals.").split("."))


@dataclass(slots=True)
class Condition:
    type: ConditionType = "custom"
    when: str = ""
    expr: str = ""

    @classmethod
    def create(cls, path: str, expr: str, when: str | None = None) -> Self:
        parts: Parts = Parts.create(path)
        match parts.type:
            case "platform":
                if when is None:
                    when = f"platform.os == '{parts.when}'"
                return cls(type="platform", when=when, expr=expr)
            case "env":
                if when is None:
                    when = f"'{parts.when}' in env"
                return cls(type="env", when=when, expr=expr)
            case "python":
                if when is None:
                    version: tuple[int, ...] = item_check(2, tuple(parts.when.split("_")), int)
                    when = f"python >= {version}"
                return cls(type="python", when=when, expr=expr)
            case _:
                if when is None:
                    when = "True"
                return cls(type="custom", when=when, expr=expr)


class Conditionals(BaseModel):
    """Smart container that handles [conditionals.*] with when/expr syntax."""

    model_config = ConfigDict(extra="allow")
    env_var_prefix: str = ""
    _collected: dict[str, Condition] = PrivateAttr(default_factory=dict)

    @property
    def env_var_checks(self) -> bool:
        return any(cond.type == "env" for cond in self._collected.values())

    @property
    def empty(self) -> bool:
        return not self._collected

    @property
    def not_empty(self) -> bool:
        return bool(self._collected)

    @model_validator(mode="after")
    def capture_conditionals(self) -> Self:
        def _dict_check(current: Any, path: list[str] | None = None) -> None:
            if isinstance(current, dict):
                for key, value in current.items():
                    new_path = [*path, key] if path else [key]
                    if isinstance(value, dict) and "when" in value and "expr" in value:
                        conditions_key: str = ".".join(new_path)
                        conditions[conditions_key] = Condition.create(conditions_key, value["expr"], value["when"])
                    elif isinstance(value, dict) and "expr" in value:
                        conditions_key = ".".join(new_path)
                        conditions[conditions_key] = Condition.create(conditions_key, value["expr"])
                    _dict_check(value, new_path)

        extra: dict[str, Any] | None = self.model_extra
        if extra is None:
            return self
        conditions: dict[str, Condition] = {}
        for key, value in extra.items():
            _dict_check({key: value})
        self._collected = conditions
        return self

    def apply_all(
        self,
        obj: Any,
        printer: ColorPrinter,
        backends: list[BaseBackendSettings] = EMPTY_IMMUTABLE_LIST,
    ) -> None:
        """Evaluate and apply all conditionals using the DSL parser."""
        from build_cub.models._build_data import BuildData

        prefix: str = self.env_var_prefix
        if not prefix:
            if isinstance(obj, BuildData):
                prefix = obj.general.name.upper()
            else:
                raise ValueError("Please set a `env_var_prefix` in `bear_build.toml`")

        def env_filter() -> set[str]:
            from os import environ

            env_filtered = set()
            for key in environ:
                if key.startswith(prefix):
                    env_filtered.add(key)
            return env_filtered

        settings = (
            obj.defaults.settings if isinstance(obj, BuildData) else obj if hasattr(obj, "_SETTINGS_") else NULL_CLASS()
        )
        env_filtered: set[str] = set()
        if self.env_var_checks:
            env_filtered = env_filter()

        namespace: dict[str, Any] = {
            "settings": settings,
            "platform": global_config.platform,
            "python": global_config.python_ver,
            "env": env_filtered,
            "print": printer.info,
        }

        for backend in backends:
            if backend.enabled:
                namespace[backend.name] = backend

        dsl: DSLParser = DSLParser(namespace=namespace)

        try:
            truthy_conds: dict[str, Condition] = {
                name: cond for name, cond in self._collected.items() if dsl.eval_true(cond.when)
            }
        except Exception as e:
            printer.error(f"Failed to evaluate conditionals: {e}")
            return

        dsl.set_mode("validation")

        for name, cond in truthy_conds.items():
            try:
                printer.debug(f"Applying conditional '{name}'...")
                dsl.exec_action(cond.expr)
            except Exception as e:
                printer.warn(f"Conditional '{name}' failed: {e}")
