"""Native C/C++ compilation backend."""

from __future__ import annotations

from typing import TYPE_CHECKING

from lazy_bear import lazy

from ._cpp_base import CppBackendBase

if TYPE_CHECKING:
    from build_cub.models._backends import NativeSettings
    from build_cub.models._build_data import BuildData
    from build_cub.plugins import BuildCubHook
    from build_cub.utils._printer import ColorPrinter
else:
    NativeSettings = lazy("build_cub.models._backends", "NativeSettings")
    BuildCubHook = lazy("build_cub.plugins", "BuildCubHook")


class NativeBackend(CppBackendBase[NativeSettings]):
    """Native C/C++ compilation backend."""

    name: str = "native"
    dependencies: tuple[str, ...] = ("setuptools",)
    display_name: str = "Native C/C++"
    language: str = "c"

    def __init__(self, should_run: bool, settings: BuildData, printer: ColorPrinter, hook: BuildCubHook) -> None:
        """Initialize the native C/C++ backend."""
        super().__init__(should_run, settings, printer, hook)
