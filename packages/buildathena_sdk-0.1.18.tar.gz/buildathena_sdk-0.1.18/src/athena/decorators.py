"""Decorators for defining Athena blocks and entrypoints."""

import functools
import inspect
from collections.abc import Callable
from typing import Any, TypeVar

from pydantic import BaseModel

from athena.types import BlockInput, BlockOutput, BlockSpec, EntrypointSpec

F = TypeVar("F", bound=Callable[..., Any])


def block(
    name: str | None = None,
    description: str | None = None,
    inputs: list[str] | None = None,
    outputs: list[str] | None = None,
    config: type[BaseModel] | None = None,
    config_path: str | None = None,
    secrets: list[str] | None = None,
    credentials: list[str] | None = None,
) -> Callable[[F], F]:
    """Decorator to define an Athena block.

    Usage:
        @block(
            name="TrainVAE",
            inputs=["data"],
            outputs=["checkpoint", "samples"],
            config=TrainVAEConfig,
            config_path="codex/configs/blocks/train_vae.yaml",
            secrets=["OPENAI_API_KEY"],
        )
        async def train_vae(ctx: BlockContext, config: TrainVAEConfig) -> dict:
            ...

    Args:
        name: Block name (defaults to function name)
        description: Block description (defaults to function docstring)
        inputs: List of input names
        outputs: List of output names
        config: Pydantic model class for config schema validation
        config_path: Path to config file, relative to workspace root
        secrets: List of required secret names resolved at runtime (e.g., ['OPENAI_API_KEY'])
        credentials: Deprecated alias for secrets. Use secrets instead.
    """
    # Merge secrets and credentials (credentials is deprecated alias)
    resolved_secrets = secrets or credentials or []

    def decorator(func: F) -> F:
        # Store block metadata on the function
        block_name = name or func.__name__
        block_description = description or func.__doc__

        # Build input specs
        input_specs = []
        if inputs:
            for input_name in inputs:
                input_specs.append(
                    BlockInput(
                        name=input_name,
                        type="Any",
                        required=True,
                    )
                )

        # Build output specs
        output_specs = []
        if outputs:
            for output_name in outputs:
                output_specs.append(
                    BlockOutput(
                        name=output_name,
                        type="ArtifactRef",
                    )
                )

        # Build config schema
        config_schema = None
        if config:
            config_schema = config.model_json_schema()

        # Create block spec
        spec = BlockSpec(
            name=block_name,
            description=block_description,
            inputs=input_specs,
            outputs=output_specs,
            config_schema=config_schema,
            config_path=config_path,
            secrets=resolved_secrets,
        )

        # Attach spec to function
        func.__athena_block__ = spec  # type: ignore[attr-defined]
        func.__athena_config_class__ = config  # type: ignore[attr-defined]

        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def wrapper(*args: Any, **kwargs: Any) -> Any:
                return await func(*args, **kwargs)
        else:

            @functools.wraps(func)
            async def wrapper(*args: Any, **kwargs: Any) -> Any:
                return func(*args, **kwargs)

        # Copy attributes to wrapper
        wrapper.__athena_block__ = spec  # type: ignore[attr-defined]
        wrapper.__athena_config_class__ = config  # type: ignore[attr-defined]

        return wrapper  # type: ignore[return-value]

    return decorator


def get_block_spec(func: Callable[..., Any]) -> BlockSpec | None:
    """Get the block spec from a decorated function."""
    return getattr(func, "__athena_block__", None)


def get_config_class(func: Callable[..., Any]) -> type[BaseModel] | None:
    """Get the config class from a decorated function."""
    return getattr(func, "__athena_config_class__", None)


def entrypoint(
    name: str | None = None,
    description: str | None = None,
    config: type[BaseModel] | None = None,
) -> Callable[[F], F]:
    """Decorator to define an Athena pipeline entrypoint.

    Entrypoints define pipeline entry points that create a flow of blocks.
    They are discovered statically and traced to extract the DAG structure.

    Usage:
        @entrypoint(
            name="GeologyPipeline",
            description="Train VAE and LDM for geology data",
            config=PipelineConfig,
        )
        def geology_pipeline(config: PipelineConfig) -> None:
            vae_out = TrainVAE(config.vae).run(data=config.data)
            ldm_out = TrainLDM(config.ldm).run(vae=vae_out.checkpoint)
            ...
    """

    def decorator(func: F) -> F:
        # Store entrypoint metadata on the function
        entrypoint_name = name or func.__name__
        entrypoint_description = description or func.__doc__

        # Build config schema
        config_schema = None
        if config:
            config_schema = config.model_json_schema()

        # Create entrypoint spec
        spec = EntrypointSpec(
            name=entrypoint_name,
            description=entrypoint_description,
            config_schema=config_schema,
            module_path=func.__module__,
            function_name=func.__name__,
        )

        # Attach spec to function
        func.__athena_entrypoint__ = spec  # type: ignore[attr-defined]
        func.__athena_config_class__ = config  # type: ignore[attr-defined]

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return func(*args, **kwargs)

        # Copy attributes to wrapper
        wrapper.__athena_entrypoint__ = spec  # type: ignore[attr-defined]
        wrapper.__athena_config_class__ = config  # type: ignore[attr-defined]

        return wrapper  # type: ignore[return-value]

    return decorator


def get_entrypoint_spec(func: Callable[..., Any]) -> EntrypointSpec | None:
    """Get the entrypoint spec from a decorated function."""
    return getattr(func, "__athena_entrypoint__", None)
