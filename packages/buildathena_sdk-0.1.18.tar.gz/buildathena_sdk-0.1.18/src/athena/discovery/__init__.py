"""Discovery module for finding blocks and tracing flows.

This module provides tools for:
- Scanning workspaces to discover @block and @entrypoint decorated functions
- Tracing flow graphs from entrypoint functions using AST analysis
- CLI commands for discovery operations
"""

from athena.discovery.flow_tracer import FlowTracer, trace_entrypoint
from athena.discovery.scanner import WorkspaceScanner, scan_workspace
from athena.discovery.schemas import (
    BlockRegistry,
    DiscoveredBlock,
    DiscoveredEntrypoint,
    FlowEdge,
    FlowGraph,
    FlowNode,
    InputSpec,
    OutputSpec,
)

__all__ = [
    # Scanner
    "WorkspaceScanner",
    "scan_workspace",
    # Flow tracer
    "FlowTracer",
    "trace_entrypoint",
    # Schemas
    "BlockRegistry",
    "DiscoveredBlock",
    "DiscoveredEntrypoint",
    "FlowGraph",
    "FlowNode",
    "FlowEdge",
    "InputSpec",
    "OutputSpec",
]
