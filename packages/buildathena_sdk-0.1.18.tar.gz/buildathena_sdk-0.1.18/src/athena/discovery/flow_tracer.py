"""Flow tracer for extracting DAG structure from entrypoints.

This module provides AST-based analysis to trace block invocations
within entrypoint functions and extract the flow graph (DAG structure).
"""

import ast
import logging
from dataclasses import dataclass
from pathlib import Path

from athena.discovery.schemas import (
    BlockRegistry,
    FlowEdge,
    FlowGraph,
    FlowNode,
)

logger = logging.getLogger(__name__)


@dataclass
class TracedCall:
    """A traced block invocation."""

    block_name: str
    config_path: str | None
    inputs: dict[str, str]  # input_name -> source expression
    output_var: str | None
    position: int


@dataclass
class VariableBinding:
    """Tracks what a variable is bound to."""

    node_id: str | None = None  # If it's the output of a block
    output_name: str | None = None  # Which output of the block
    expression: str | None = None  # Original expression if not a block output


class FlowVisitor(ast.NodeVisitor):
    """AST visitor that traces block invocations in a function."""

    def __init__(self, known_blocks: set[str]) -> None:
        """Initialize the visitor.

        Args:
            known_blocks: Set of known block names for validation.
        """
        self.known_blocks = known_blocks
        self.calls: list[TracedCall] = []
        self.variables: dict[str, VariableBinding] = {}
        self._position = 0
        self._name_counts: dict[str, int] = {}  # per-name counter for node IDs

    def visit_Assign(self, node: ast.Assign) -> None:
        """Visit assignment statements to track variable bindings."""
        # Handle simple single-target assignments
        if len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name):
                call_info = self._extract_block_call(node.value)
                if call_info:
                    block_name, config_path, inputs = call_info
                    self._position += 1

                    self.calls.append(
                        TracedCall(
                            block_name=block_name,
                            config_path=config_path,
                            inputs=inputs,
                            output_var=target.id,
                            position=self._position,
                        )
                    )

                    # Track the variable binding (per-name index, not global position)
                    count = self._name_counts.get(block_name, 0)
                    self._name_counts[block_name] = count + 1
                    node_id = f"{block_name}_{count}"
                    self.variables[target.id] = VariableBinding(
                        node_id=node_id,
                        output_name="result",  # Default output name
                        expression=None,
                    )
                else:
                    # Track other variable assignments for reference resolution
                    self.variables[target.id] = VariableBinding(
                        node_id=None,
                        output_name=None,
                        expression=ast.unparse(node.value),
                    )

        self.generic_visit(node)

    def visit_Expr(self, node: ast.Expr) -> None:
        """Visit expression statements for block calls without assignment."""
        call_info = self._extract_block_call(node.value)
        if call_info:
            block_name, config_path, inputs = call_info
            self._position += 1

            self.calls.append(
                TracedCall(
                    block_name=block_name,
                    config_path=config_path,
                    inputs=inputs,
                    output_var=None,
                    position=self._position,
                )
            )

        self.generic_visit(node)

    def _extract_block_call(self, node: ast.expr) -> tuple[str, str | None, dict[str, str]] | None:
        """Extract block call information from an expression.

        Handles patterns like:
        - BlockName(config).run(inputs)
        - BlockName().run(inputs)
        - BlockName.run(inputs)  # class method style

        Returns:
            Tuple of (block_name, config_path, inputs) or None if not a block call.
        """
        # Pattern: SomeBlock(...).run(...)
        if not isinstance(node, ast.Call):
            return None

        # Check for .run(...) method call
        if not isinstance(node.func, ast.Attribute):
            return None

        if node.func.attr != "run":
            return None

        run_target = node.func.value
        block_name: str | None = None
        config_path: str | None = None

        # Pattern: BlockName(config).run(...)
        if isinstance(run_target, ast.Call):
            if isinstance(run_target.func, ast.Name):
                block_name = run_target.func.id
            elif isinstance(run_target.func, ast.Attribute):
                block_name = run_target.func.attr

            # Extract config path from constructor arguments
            if run_target.args:
                config_path = ast.unparse(run_target.args[0])
            elif run_target.keywords:
                for kw in run_target.keywords:
                    if kw.arg == "config":
                        config_path = ast.unparse(kw.value)
                        break

        # Pattern: BlockName.run(...) - class method style
        elif isinstance(run_target, ast.Name):
            block_name = run_target.id

        if block_name is None:
            return None

        # Validate that this is a known block (optional)
        # In strict mode, we could skip unknown blocks

        # Extract inputs from .run() call
        inputs: dict[str, str] = {}
        for kw in node.keywords:
            if kw.arg is not None:
                inputs[kw.arg] = ast.unparse(kw.value)

        # Handle positional arguments (less common but possible)
        for i, arg in enumerate(node.args):
            inputs[f"_arg_{i}"] = ast.unparse(arg)

        return (block_name, config_path, inputs)


def _resolve_input_source(
    input_expr: str, variables: dict[str, VariableBinding]
) -> tuple[str | None, str | None]:
    """Resolve an input expression to a source node and output.

    Returns:
        Tuple of (source_node_id, output_name) or (None, None) if not resolvable.
    """
    # Handle attribute access like "vae_out.checkpoint"
    parts = input_expr.split(".")
    var_name = parts[0]

    if var_name in variables:
        binding = variables[var_name]
        if binding.node_id:
            # It's a block output
            output_name = parts[1] if len(parts) > 1 else "result"
            return (binding.node_id, output_name)

    return (None, None)


class FlowTracer:
    """Traces flow graphs from entrypoint functions."""

    def __init__(self, registry: BlockRegistry | None = None) -> None:
        """Initialize the tracer.

        Args:
            registry: Optional BlockRegistry for block validation.
        """
        self.registry = registry
        self.known_blocks = self._build_known_blocks()

    def _build_known_blocks(self) -> set[str]:
        """Build set of known block names from registry."""
        if self.registry is None:
            return set()
        return {b.name for b in self.registry.blocks}

    def trace_file(self, file_path: Path, function_name: str) -> FlowGraph | None:
        """Trace a flow graph from an entrypoint function.

        Args:
            file_path: Path to the Python file containing the entrypoint.
            function_name: Name of the entrypoint function to trace.

        Returns:
            FlowGraph if successful, None if the function could not be found.
        """
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(file_path))
        except (SyntaxError, UnicodeDecodeError) as e:
            logger.error(f"Could not parse {file_path}: {e}")
            return None

        # Find the function definition
        func_def = None
        for node in ast.walk(tree):
            if (
                isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                and node.name == function_name
            ):
                func_def = node
                break

        if func_def is None:
            logger.error(f"Function {function_name} not found in {file_path}")
            return None

        return self._trace_function(func_def, file_path, function_name)

    def _trace_function(
        self,
        func_def: ast.FunctionDef | ast.AsyncFunctionDef,
        file_path: Path,
        function_name: str,
    ) -> FlowGraph:
        """Trace a single function definition."""
        visitor = FlowVisitor(self.known_blocks)

        # Visit the function body
        for stmt in func_def.body:
            visitor.visit(stmt)

        # Build nodes from traced calls (per-name indexing for node IDs)
        nodes: list[FlowNode] = []
        node_id_map: dict[int, str] = {}  # position -> node_id
        name_counts: dict[str, int] = {}

        for call in visitor.calls:
            count = name_counts.get(call.block_name, 0)
            name_counts[call.block_name] = count + 1
            node_id = f"{call.block_name}_{count}"
            node_id_map[call.position] = node_id

            # Try to find block path from registry by function_name
            # (AST extracts the Python function name, not decorator metadata)
            block_path = ""
            if self.registry:
                for block in self.registry.blocks:
                    if block.function_name == call.block_name:
                        block_path = block.file_path
                        break

            nodes.append(
                FlowNode(
                    id=node_id,
                    block_id=call.block_name,
                    block_path=block_path,
                    config_path=call.config_path,
                    position=call.position - 1,
                )
            )

        # Build edges from input references
        edges: list[FlowEdge] = []

        for call in visitor.calls:
            target_node_id = node_id_map[call.position]

            for input_name, input_expr in call.inputs.items():
                source_node_id, output_name = _resolve_input_source(input_expr, visitor.variables)

                if source_node_id and output_name:
                    edges.append(
                        FlowEdge(
                            from_node=source_node_id,
                            from_output=output_name,
                            to_node=target_node_id,
                            to_input=input_name,
                        )
                    )

        # Compute relative path
        try:
            workspace = Path(self.registry.workspace) if self.registry else file_path.parent
            relative_path = str(file_path.relative_to(workspace))
        except ValueError:
            relative_path = str(file_path)

        return FlowGraph(
            entrypoint=function_name,
            entrypoint_path=relative_path,
            nodes=nodes,
            edges=edges,
        )


def trace_entrypoint(
    file_path: str | Path,
    function_name: str,
    registry: BlockRegistry | None = None,
) -> FlowGraph | None:
    """Convenience function to trace a single entrypoint.

    Args:
        file_path: Path to the Python file.
        function_name: Name of the entrypoint function.
        registry: Optional BlockRegistry for validation and path resolution.

    Returns:
        FlowGraph if successful, None otherwise.
    """
    path = Path(file_path) if isinstance(file_path, str) else file_path
    tracer = FlowTracer(registry)
    return tracer.trace_file(path, function_name)
