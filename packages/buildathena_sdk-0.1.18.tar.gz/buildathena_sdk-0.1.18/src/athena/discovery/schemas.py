"""Pydantic models for discovery output.

These models define the JSON structure for block registry and flow graph output.
"""

from typing import Any

from pydantic import BaseModel, Field


class InputSpec(BaseModel):
    """Specification for a block input."""

    name: str
    type: str
    required: bool = True


class OutputSpec(BaseModel):
    """Specification for a block output."""

    name: str
    type: str


class DiscoveredBlock(BaseModel):
    """A discovered block in the workspace."""

    name: str
    file_path: str = Field(description="Relative path to the block file")
    function_name: str = Field(description="Name of the decorated function")
    inputs: list[InputSpec] = Field(default_factory=list)
    outputs: list[OutputSpec] = Field(default_factory=list)
    config_schema: dict[str, Any] | None = None
    config_path: str | None = Field(
        default=None,
        description="Path to config file, relative to workspace root",
    )
    secrets: list[str] = Field(
        default_factory=list,
        description="List of required secret names (e.g., ['OPENAI_API_KEY'])",
    )

    @property
    def credentials(self) -> list[str]:
        """Deprecated alias for secrets."""
        return self.secrets

    description: str | None = None
    language: str = "python"


class DiscoveredEntrypoint(BaseModel):
    """A discovered entrypoint in the workspace."""

    name: str
    file_path: str = Field(description="Relative path to the entrypoint file")
    function_name: str = Field(description="Name of the decorated function")
    config_schema: dict[str, Any] | None = None
    description: str | None = None
    language: str = "python"


class DiscoveredHandler(BaseModel):
    """A discovered storage handler in the workspace."""

    name: str
    schemes: list[str] = Field(description="URI schemes this handler supports (e.g., ['s3', 'gs'])")
    file_path: str = Field(description="Relative path to the handler file")
    function_name: str = Field(description="Name of the decorated function")
    description: str | None = None
    language: str = "python"


class BlockRegistry(BaseModel):
    """Registry of all discovered blocks, entrypoints, and handlers in a workspace."""

    version: str = "1.0"
    language: str = Field(description="Language of the scanner that produced this registry")
    workspace: str = Field(description="Absolute path to the workspace root")
    blocks: list[DiscoveredBlock] = Field(default_factory=list)
    entrypoints: list[DiscoveredEntrypoint] = Field(default_factory=list)
    handlers: list[DiscoveredHandler] = Field(default_factory=list)
    scan_errors: list[dict[str, Any]] = Field(default_factory=list)


class FlowNode(BaseModel):
    """A node in the flow graph representing a block invocation."""

    id: str = Field(description="Unique node ID within the flow")
    block_id: str = Field(description="Block identifier (function/class name)")
    block_path: str = Field(description="Relative path to the block file")
    config_path: str | None = Field(
        default=None, description="Dotted path to config attribute (e.g., 'config.vae')"
    )
    position: int = Field(description="Order of invocation in the flow")


class FlowEdge(BaseModel):
    """An edge in the flow graph representing data flow or execution ordering between blocks."""

    from_node: str = Field(description="Source node ID")
    from_output: str | None = Field(
        default=None, description="Output name from source node (None for ordering-only)"
    )
    to_node: str = Field(description="Target node ID")
    to_input: str | None = Field(
        default=None, description="Input name on target node (None for ordering-only)"
    )


class FlowGraph(BaseModel):
    """Complete flow graph extracted from an entrypoint."""

    version: str = "1.0"
    entrypoint: str = Field(description="Name of the entrypoint function")
    entrypoint_path: str = Field(description="Relative path to the entrypoint file")
    nodes: list[FlowNode] = Field(default_factory=list)
    edges: list[FlowEdge] = Field(default_factory=list)
