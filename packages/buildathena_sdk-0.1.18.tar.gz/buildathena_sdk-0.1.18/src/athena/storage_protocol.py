"""Storage backend protocol.

This module re-exports StorageBackend from athena.storage for backwards
compatibility. New code should import from athena.storage directly.

DEPRECATED: Import from athena.storage instead.
"""

from athena.storage.protocol import StorageBackend

__all__ = ["StorageBackend"]
