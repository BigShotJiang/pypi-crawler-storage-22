"""Tests for FlowTracer."""

from pathlib import Path

import pytest

from athena.discovery.flow_tracer import FlowTracer, trace_entrypoint
from athena.discovery.schemas import BlockRegistry, DiscoveredBlock


@pytest.fixture
def mock_registry() -> BlockRegistry:
    """Create a mock block registry."""
    return BlockRegistry(
        language="python",
        workspace="/test/workspace",
        blocks=[
            DiscoveredBlock(
                name="TrainVAE",
                file_path="blocks/train_vae.py",
                function_name="train_vae",
                inputs=[],
                outputs=[],
            ),
            DiscoveredBlock(
                name="TrainLDM",
                file_path="blocks/train_ldm.py",
                function_name="train_ldm",
                inputs=[],
                outputs=[],
            ),
            DiscoveredBlock(
                name="TrainSurrogates",
                file_path="blocks/train_surrogates.py",
                function_name="train_surrogates",
                inputs=[],
                outputs=[],
            ),
        ],
        entrypoints=[],
    )


@pytest.fixture
def simple_pipeline_file(tmp_path: Path) -> Path:
    """Create a simple pipeline file."""
    file_path = tmp_path / "pipeline.py"
    file_path.write_text(
        '''
def simple_pipeline(config):
    """Simple two-step pipeline."""
    vae_out = TrainVAE(config.vae).run(data=config.data)
    ldm_out = TrainLDM(config.ldm).run(vae=vae_out.checkpoint, data=config.data)
    return ldm_out
'''
    )
    return file_path


@pytest.fixture
def branching_pipeline_file(tmp_path: Path) -> Path:
    """Create a pipeline file with branching."""
    file_path = tmp_path / "branching_pipeline.py"
    file_path.write_text(
        '''
def branching_pipeline(config):
    """Pipeline with branching."""
    vae_out = TrainVAE(config.vae).run(data=config.data)
    surrogates_out = TrainSurrogates(config.surrogates).run(vae=vae_out.checkpoint)
    ldm_out = TrainLDM(config.ldm).run(
        vae=vae_out.checkpoint,
        surrogates=surrogates_out.checkpoints
    )
    return ldm_out
'''
    )
    return file_path


class TestFlowTracer:
    """Tests for FlowTracer."""

    def test_trace_simple_pipeline(
        self, simple_pipeline_file: Path, mock_registry: BlockRegistry
    ) -> None:
        """Test tracing a simple two-step pipeline."""
        tracer = FlowTracer(mock_registry)
        flow = tracer.trace_file(simple_pipeline_file, "simple_pipeline")

        assert flow is not None
        assert flow.entrypoint == "simple_pipeline"
        assert len(flow.nodes) == 2

        node_names = {n.block_id for n in flow.nodes}
        assert "TrainVAE" in node_names
        assert "TrainLDM" in node_names

    def test_trace_captures_edges(
        self, simple_pipeline_file: Path, mock_registry: BlockRegistry
    ) -> None:
        """Test that tracing captures data flow edges."""
        tracer = FlowTracer(mock_registry)
        flow = tracer.trace_file(simple_pipeline_file, "simple_pipeline")

        assert flow is not None
        assert len(flow.edges) >= 1

        # Find edge from VAE to LDM
        vae_to_ldm = [e for e in flow.edges if "TrainVAE" in e.from_node]
        assert len(vae_to_ldm) >= 1
        assert vae_to_ldm[0].from_output == "checkpoint"
        assert vae_to_ldm[0].to_input == "vae"

    def test_trace_captures_config_path(
        self, simple_pipeline_file: Path, mock_registry: BlockRegistry
    ) -> None:
        """Test that tracing captures config paths."""
        tracer = FlowTracer(mock_registry)
        flow = tracer.trace_file(simple_pipeline_file, "simple_pipeline")

        assert flow is not None
        vae_node = next(n for n in flow.nodes if n.block_id == "TrainVAE")
        assert vae_node.config_path == "config.vae"

    def test_trace_captures_positions(
        self, simple_pipeline_file: Path, mock_registry: BlockRegistry
    ) -> None:
        """Test that nodes have correct positions."""
        tracer = FlowTracer(mock_registry)
        flow = tracer.trace_file(simple_pipeline_file, "simple_pipeline")

        assert flow is not None
        vae_node = next(n for n in flow.nodes if n.block_id == "TrainVAE")
        ldm_node = next(n for n in flow.nodes if n.block_id == "TrainLDM")

        assert vae_node.position < ldm_node.position

    def test_trace_branching_pipeline(
        self, branching_pipeline_file: Path, mock_registry: BlockRegistry
    ) -> None:
        """Test tracing a pipeline with branching."""
        tracer = FlowTracer(mock_registry)
        flow = tracer.trace_file(branching_pipeline_file, "branching_pipeline")

        assert flow is not None
        assert len(flow.nodes) == 3

        # Should have edges from VAE to both surrogates and LDM
        vae_edges = [e for e in flow.edges if "TrainVAE" in e.from_node]
        assert len(vae_edges) >= 2

    def test_trace_nonexistent_function(
        self, simple_pipeline_file: Path, mock_registry: BlockRegistry
    ) -> None:
        """Test tracing a non-existent function returns None."""
        tracer = FlowTracer(mock_registry)
        flow = tracer.trace_file(simple_pipeline_file, "nonexistent")

        assert flow is None

    def test_trace_without_registry(self, simple_pipeline_file: Path) -> None:
        """Test tracing works without a registry."""
        tracer = FlowTracer(None)
        flow = tracer.trace_file(simple_pipeline_file, "simple_pipeline")

        assert flow is not None
        assert len(flow.nodes) == 2

    def test_trace_entrypoint_convenience(
        self, simple_pipeline_file: Path, mock_registry: BlockRegistry
    ) -> None:
        """Test trace_entrypoint convenience function."""
        flow = trace_entrypoint(simple_pipeline_file, "simple_pipeline", mock_registry)

        assert flow is not None
        assert len(flow.nodes) == 2


class TestFlowTracerEdgeCases:
    """Tests for flow tracer edge cases."""

    def test_trace_empty_function(self, tmp_path: Path) -> None:
        """Test tracing an empty function."""
        file_path = tmp_path / "empty.py"
        file_path.write_text(
            '''
def empty_pipeline(config):
    """Empty pipeline."""
    pass
'''
        )

        tracer = FlowTracer(None)
        flow = tracer.trace_file(file_path, "empty_pipeline")

        assert flow is not None
        assert len(flow.nodes) == 0
        assert len(flow.edges) == 0

    def test_trace_async_function(self, tmp_path: Path) -> None:
        """Test tracing an async function."""
        file_path = tmp_path / "async_pipeline.py"
        file_path.write_text(
            '''
async def async_pipeline(config):
    """Async pipeline."""
    vae_out = TrainVAE(config.vae).run(data=config.data)
    return vae_out
'''
        )

        tracer = FlowTracer(None)
        flow = tracer.trace_file(file_path, "async_pipeline")

        assert flow is not None
        assert len(flow.nodes) == 1

    def test_trace_block_without_assignment(self, tmp_path: Path) -> None:
        """Test tracing blocks called without assignment."""
        file_path = tmp_path / "no_assign.py"
        file_path.write_text(
            '''
def no_assign_pipeline(config):
    """Pipeline without variable assignment."""
    TrainVAE(config.vae).run(data=config.data)
    TrainLDM(config.ldm).run(data=config.data)
'''
        )

        tracer = FlowTracer(None)
        flow = tracer.trace_file(file_path, "no_assign_pipeline")

        assert flow is not None
        assert len(flow.nodes) == 2
        # No edges since outputs aren't captured
        assert len(flow.edges) == 0

    def test_trace_nested_config(self, tmp_path: Path) -> None:
        """Test tracing with nested config paths."""
        file_path = tmp_path / "nested.py"
        file_path.write_text(
            '''
def nested_pipeline(config):
    """Pipeline with nested config."""
    vae_out = TrainVAE(config.models.vae).run(data=config.data.train)
    return vae_out
'''
        )

        tracer = FlowTracer(None)
        flow = tracer.trace_file(file_path, "nested_pipeline")

        assert flow is not None
        vae_node = flow.nodes[0]
        assert vae_node.config_path == "config.models.vae"

    def test_trace_file_with_syntax_error(self, tmp_path: Path) -> None:
        """Test tracing a file with syntax errors."""
        file_path = tmp_path / "bad.py"
        file_path.write_text(
            """
def broken(:
    pass
"""
        )

        tracer = FlowTracer(None)
        flow = tracer.trace_file(file_path, "broken")

        assert flow is None
