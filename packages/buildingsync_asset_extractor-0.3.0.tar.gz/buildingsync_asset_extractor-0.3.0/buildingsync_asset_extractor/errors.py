class BSyncProcessorError(Exception):
    pass
