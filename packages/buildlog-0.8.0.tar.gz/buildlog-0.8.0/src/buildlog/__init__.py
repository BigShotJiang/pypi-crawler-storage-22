"""buildlog - Engineering notebook for AI-assisted development."""

__version__ = "0.8.0"
