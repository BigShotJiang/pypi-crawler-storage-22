# Build Journal: [TITLE]

**Date:** [YYYY-MM-DD]
**Duration:** [X hours]

## What I Did

[What you built, fixed, or changed. 2-3 sentences.]

## What Went Wrong

[Mistakes, surprises, dead ends. Be specific — these become rules.]

## What I Learned

### Improvements

- [One thing to do differently next time]
- [One thing that worked well to repeat]

*More sections: see _TEMPLATE.md for the full format.*
