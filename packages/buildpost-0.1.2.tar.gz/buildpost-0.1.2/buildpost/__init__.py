"""BuildPost - Turn your git commits into social media posts using AI."""

__version__ = "0.1.2"
__author__ = "BuildPost Team"
__description__ = "Turn your git commits into social media posts using AI"
