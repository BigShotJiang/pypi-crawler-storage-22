{
    fps: [conf.js]
    conf:{}
}