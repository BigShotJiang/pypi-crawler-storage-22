# Bunjee

Developer Swiss Army knife — 15+ tools, zero dependencies.

One `pip install`, instant power in your terminal.

## Install

```bash
pip install bunjee
```

## Quick commands

```bash
bunjee                        # Interactive hub with animated startup
bunjee init myapp             # Scaffold a Python project
bunjee serve                  # Instant HTTP file server (port 8000)
bunjee gen password           # Generate a secure password
bunjee gen uuid               # Generate a UUID
bunjee gen token              # URL-safe token
bunjee tree                   # Directory tree viewer
bunjee tree -d 2              # Tree with max depth
bunjee json data.json         # Pretty-print JSON
bunjee json data.json -q users.0.name  # Query into JSON
bunjee hash file.txt          # SHA256 hash a file
bunjee hash "hello" -a md5    # Hash a string
bunjee port 8080              # Check if port is open
bunjee port 8000 --scan --to 9000  # Scan port range
bunjee timer 5m               # Countdown timer
bunjee timer 90s -l "Break"   # Timer with label
bunjee todo add "fix bug"     # Add a todo (persists in ~/.bunjee/)
bunjee todo                   # List todos
bunjee todo done -n 1         # Mark todo #1 done
bunjee b64 "hello world"      # Base64 encode
bunjee b64 -d "aGVsbG8="     # Base64 decode
bunjee count                  # Lines of code by file type
bunjee diff a.py b.py         # Unified diff of two files
bunjee env                    # System & Python info
bunjee env --path             # Inspect PATH entries
bunjee ip                     # Show your IP addresses
bunjee lorem -w 100           # Generate placeholder text
```

## Interactive hub

Run `bunjee` with no arguments to launch the interactive hub:

- **15 code snippets** — retry, cache, dataclass, decorators, async, argparse, pathlib, logging, and more
- **8 tutorials** — CLI building, API clients, testing, git, Docker, PyPI publishing
- **7 project templates** — project layout, FastAPI, Flask, Dockerfile, GitHub Actions, Makefile
- **7 utilities** — slugify, JSON, timestamps, passwords, UUIDs, base64, hashing

## Zero dependencies

Every feature uses only the Python standard library. No pip surprises.

## Build and publish

```bash
python3 -m pip install --upgrade build twine
python3 -m build
export TWINE_USERNAME=__token__
export TWINE_PASSWORD='pypi-YOUR-TOKEN'
python3 -m twine upload dist/*
```
