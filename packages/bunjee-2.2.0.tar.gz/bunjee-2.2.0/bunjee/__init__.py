"""Bunjee CLI package."""

__all__ = ["main"]
