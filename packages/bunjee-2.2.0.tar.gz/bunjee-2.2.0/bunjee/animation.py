"""Cinematic startup animation for Bunjee."""
from __future__ import annotations

import math
import shutil
import sys
import time

CSI = "\x1b["
RESET = f"{CSI}0m"
HIDE_CURSOR = f"{CSI}?25l"
SHOW_CURSOR = f"{CSI}?25h"


def move_to(row: int, col: int) -> str:
    return f"{CSI}{row};{col}H"


def clear_screen() -> str:
    return f"{CSI}2J{CSI}H"


def center_text_start_col(width: int, text: str) -> int:
    return max(1, (width - len(text)) // 2 + 1)


def paint_base_blue(width: int, height: int) -> None:
    out = []
    for row in range(1, height + 1):
        out.append(f"{move_to(row, 1)}\x1b[48;5;18m{' ' * width}{RESET}")
    sys.stdout.write("".join(out))
    sys.stdout.flush()


def watery_blue(width: int, height: int) -> None:
    center_row = height / 2
    center_col = width / 2
    for phase in range(16):
        out = []
        for row in range(1, height + 1):
            line = []
            for col in range(1, width + 1):
                distance = abs(row - center_row) + abs(col - center_col)
                ripple = int((distance * 0.6 + phase * 1.9) % 8)
                shimmer = int((row * 0.7 + col * 0.3 + phase * 2.2) % 11)
                bg, fg, ch = 18, 117, " "
                if ripple in (0, 1):
                    bg, ch = 20, "~"
                elif ripple == 2:
                    bg, ch = 19, "."
                if shimmer in (0, 10):
                    bg, fg, ch = 21, 159, "~"
                line.append(f"\x1b[38;5;{fg};48;5;{bg}m{ch}")
            line.append(RESET)
            out.append(f"{move_to(row, 1)}{''.join(line)}")
        sys.stdout.write("".join(out))
        sys.stdout.flush()
        time.sleep(0.065)


def lava_spread(width: int, height: int) -> None:
    center_row = height // 2
    center_col = width // 2
    max_radius = int(math.hypot(center_row, center_col)) + 2
    for radius in range(1, max_radius + 1):
        out = []
        for row in range(1, height + 1):
            line = []
            for col in range(1, width + 1):
                dist = int(math.hypot(row - center_row, col - center_col))
                wobble = ((row * 3 + col * 5 + radius * 7) % 4) - 2
                if dist <= radius + wobble:
                    heat = (dist + radius) % 6
                    if heat <= 1:
                        bg = 196
                    elif heat <= 3:
                        bg = 202
                    else:
                        bg = 208
                    spark = "*" if (row + col + radius) % 23 == 0 else " "
                    line.append(f"\x1b[38;5;226;48;5;{bg}m{spark}")
                else:
                    line.append("\x1b[48;5;18m ")
            line.append(RESET)
            out.append(f"{move_to(row, 1)}{''.join(line)}")
        sys.stdout.write("".join(out))
        sys.stdout.flush()
        time.sleep(0.036 if radius < max_radius * 0.65 else 0.055)


def render_big_bungee(width: int, height: int) -> None:
    glyphs = {
        "B": ["####  ", "#   # ", "####  ", "#   # ", "#   # ", "####  "],
        "U": ["#   # ", "#   # ", "#   # ", "#   # ", "#   # ", " ###  "],
        "N": ["#   # ", "##  # ", "# # # ", "#  ## ", "#   # ", "#   # "],
        "G": [" #### ", "#     ", "# ### ", "#   # ", "#   # ", " #### "],
        "E": ["##### ", "#     ", "####  ", "#     ", "#     ", "##### "],
    }
    art = [""] * 6
    for letter in "BUNGEE":
        block = glyphs[letter]
        for row in range(6):
            art[row] += block[row] + " "

    start_row = max(2, height // 2 - len(art) // 2)
    start_col = center_text_start_col(width, art[0].rstrip())
    out = []
    for idx, line in enumerate(art):
        row = start_row + idx
        if row > height:
            break
        if row + 1 <= height:
            out.append(
                f"{move_to(row + 1, min(width, start_col + 2))}"
                f"\x1b[38;5;52;48;5;18m{line}{RESET}"
            )
        painted = []
        half = max(1, len(line) // 2)
        for i, ch in enumerate(line):
            color = "\x1b[1;91;48;5;18m" if i < half else "\x1b[1;92;48;5;18m"
            painted.append(f"{color}{ch}")
        painted.append(RESET)
        out.append(f"{move_to(row, start_col)}{''.join(painted)}")
    sys.stdout.write("".join(out))
    sys.stdout.flush()
    time.sleep(0.7)


def play_intro() -> None:
    if not sys.stdout.isatty() or not sys.stdin.isatty():
        return
    width, height = shutil.get_terminal_size(fallback=(100, 30))
    width = max(width, 40)
    height = max(height, 16)
    try:
        sys.stdout.write(HIDE_CURSOR)
        sys.stdout.write(clear_screen())
        sys.stdout.flush()
        paint_base_blue(width, height)
        watery_blue(width, height)
        lava_spread(width, height)
        render_big_bungee(width, height)
    finally:
        sys.stdout.write(RESET + SHOW_CURSOR)
        sys.stdout.flush()
