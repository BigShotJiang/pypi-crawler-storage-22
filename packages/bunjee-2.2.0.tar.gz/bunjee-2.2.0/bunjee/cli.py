"""Bunjee — 15+ developer tools, zero dependencies."""
from __future__ import annotations

import argparse
import shutil
from datetime import datetime, timezone

CSI = "\x1b["
RESET = f"{CSI}0m"
TITLE = "\x1b[1;97m"
ACCENT = "\x1b[1;96m"
GREEN = "\x1b[1;92m"
YELLOW = "\x1b[1;93m"
MUTED = "\x1b[38;5;250m"

# ── Expanded snippet library ─────────────────────────────────────────────

SNIPPETS: dict[str, str] = {
    "retry": (
        "from time import sleep\n\n"
        "for attempt in range(1, 6):\n"
        "    try:\n"
        "        result = flaky_call()\n"
        "        break\n"
        "    except Exception:\n"
        "        if attempt == 5:\n"
        "            raise\n"
        "        sleep(2 ** attempt)"
    ),
    "cache": (
        "from functools import lru_cache\n\n"
        "@lru_cache(maxsize=256)\n"
        "def expensive_lookup(key: str) -> dict:\n"
        "    return fetch_from_api(key)"
    ),
    "dataclass": (
        "from dataclasses import dataclass\n\n"
        "@dataclass(slots=True)\n"
        "class User:\n"
        "    id: int\n"
        "    email: str\n"
        "    active: bool = True"
    ),
    "timing": (
        "from time import perf_counter\n\n"
        "start = perf_counter()\n"
        "run_job()\n"
        'print(f"Elapsed: {perf_counter() - start:.3f}s")'
    ),
    "context manager": (
        "from contextlib import contextmanager\n\n"
        "@contextmanager\n"
        "def managed_resource():\n"
        "    resource = acquire()\n"
        "    try:\n"
        "        yield resource\n"
        "    finally:\n"
        "        resource.close()"
    ),
    "async gather": (
        "import asyncio\n\n"
        "async def fetch_all(urls: list[str]):\n"
        "    async with aiohttp.ClientSession() as session:\n"
        "        tasks = [session.get(u) for u in urls]\n"
        "        return await asyncio.gather(*tasks)"
    ),
    "argparse cli": (
        "import argparse\n\n"
        "parser = argparse.ArgumentParser(description='My tool')\n"
        "parser.add_argument('input', help='Input file')\n"
        "parser.add_argument('-o', '--output', default='out.txt')\n"
        "parser.add_argument('-v', '--verbose', action='store_true')\n"
        "args = parser.parse_args()"
    ),
    "pathlib basics": (
        "from pathlib import Path\n\n"
        "p = Path('data')\n"
        "p.mkdir(exist_ok=True)\n"
        "files = list(p.glob('**/*.json'))\n"
        "(p / 'output.txt').write_text('done')"
    ),
    "logging setup": (
        "import logging\n\n"
        "logging.basicConfig(\n"
        "    level=logging.INFO,\n"
        "    format='%(asctime)s %(levelname)s %(message)s',\n"
        "    handlers=[logging.StreamHandler(), logging.FileHandler('app.log')]\n"
        ")\n"
        "log = logging.getLogger(__name__)"
    ),
    "env config": (
        "import os\n\n"
        "class Config:\n"
        "    DB_URL = os.environ['DATABASE_URL']\n"
        "    DEBUG = os.getenv('DEBUG', 'false').lower() == 'true'\n"
        "    PORT = int(os.getenv('PORT', '8000'))\n"
        "    SECRET = os.environ['SECRET_KEY']"
    ),
    "subprocess run": (
        "import subprocess\n\n"
        "result = subprocess.run(\n"
        "    ['git', 'status', '--short'],\n"
        "    capture_output=True, text=True, check=True\n"
        ")\n"
        "print(result.stdout)"
    ),
    "file read write": (
        "from pathlib import Path\n\n"
        "# Read\n"
        "text = Path('data.txt').read_text()\n"
        "lines = text.splitlines()\n\n"
        "# Write\n"
        "Path('output.txt').write_text('\\n'.join(lines))\n\n"
        "# Append\n"
        "with open('log.txt', 'a') as f:\n"
        "    f.write('new line\\n')"
    ),
    "dict tricks": (
        "# Merge dicts\n"
        "merged = {**defaults, **overrides}\n\n"
        "# Safe get with default\n"
        "val = config.get('key', 'fallback')\n\n"
        "# Dict comprehension\n"
        "filtered = {k: v for k, v in data.items() if v > 0}\n\n"
        "# Defaultdict\n"
        "from collections import defaultdict\n"
        "groups = defaultdict(list)"
    ),
    "list comprehension": (
        "# Filter + transform\n"
        "names = [u.name.upper() for u in users if u.active]\n\n"
        "# Flatten\n"
        "flat = [x for row in matrix for x in row]\n\n"
        "# With enumerate\n"
        "indexed = [(i, v) for i, v in enumerate(items) if v]\n\n"
        "# Dict from pairs\n"
        "lookup = {row['id']: row for row in rows}"
    ),
    "decorator": (
        "import functools\n"
        "import time\n\n"
        "def timer(func):\n"
        "    @functools.wraps(func)\n"
        "    def wrapper(*args, **kwargs):\n"
        "        start = time.perf_counter()\n"
        "        result = func(*args, **kwargs)\n"
        "        elapsed = time.perf_counter() - start\n"
        "        print(f'{func.__name__} took {elapsed:.3f}s')\n"
        "        return result\n"
        "    return wrapper"
    ),
}

TUTORIALS: dict[str, list[str]] = {
    "Build a CLI": [
        "Use argparse for flags and subcommands.",
        "Put command handlers in small functions.",
        "Return exit codes from main().",
        "Package with [project.scripts] in pyproject.toml.",
    ],
    "API Client Basics": [
        "Wrap requests in a dedicated client class.",
        "Set timeouts on every request.",
        "Retry only safe/idempotent calls.",
        "Parse and validate response shape before use.",
    ],
    "Testing Fast": [
        "Write unit tests for pure logic first.",
        "Use fixtures for setup reuse.",
        "Mock network and filesystem boundaries.",
        "Run pytest -q in pre-commit or CI.",
    ],
    "Git Workflow": [
        "Branch from main for every feature: git checkout -b feat/name.",
        "Commit small and often with clear messages.",
        "Rebase before merging to keep history clean.",
        "Use git stash when switching context mid-work.",
    ],
    "Virtual Environments": [
        "Create: python -m venv .venv",
        "Activate: source .venv/bin/activate (or .venv\\Scripts\\activate on Windows).",
        "Install deps: pip install -r requirements.txt",
        "Freeze: pip freeze > requirements.txt",
    ],
    "Publish to PyPI": [
        "Add pyproject.toml with [project] metadata.",
        "Build: python -m build",
        "Upload: twine upload dist/*",
        "Install anywhere: pip install your-package",
    ],
    "Docker Basics": [
        "Write a Dockerfile: FROM python:3.12-slim, COPY, RUN pip install, CMD.",
        "Build: docker build -t myapp .",
        "Run: docker run -p 8000:8000 myapp",
        "Use docker compose for multi-service setups.",
    ],
    "Error Handling": [
        "Catch specific exceptions, never bare except:.",
        "Use try/finally or context managers for cleanup.",
        "Log errors with traceback info before re-raising.",
        "Create custom exception classes for your domain.",
    ],
}

TEMPLATES: dict[str, str] = {
    "project layout": (
        "my_app/\n"
        "  pyproject.toml\n"
        "  README.md\n"
        "  src/my_app/__init__.py\n"
        "  src/my_app/cli.py\n"
        "  tests/test_cli.py"
    ),
    "fastapi starter": (
        "pip install fastapi uvicorn\n\n"
        "from fastapi import FastAPI\n"
        "app = FastAPI()\n\n"
        '@app.get("/health")\n'
        "def health():\n"
        '    return {"ok": True}'
    ),
    "flask starter": (
        "pip install flask\n\n"
        "from flask import Flask, jsonify\n"
        "app = Flask(__name__)\n\n"
        "@app.route('/health')\n"
        "def health():\n"
        "    return jsonify(ok=True)\n\n"
        "if __name__ == '__main__':\n"
        "    app.run(debug=True)"
    ),
    "worker loop": (
        "import time\n\n"
        "while True:\n"
        "    process_next_job()\n"
        "    time.sleep(1)"
    ),
    "dockerfile": (
        "FROM python:3.12-slim\n"
        "WORKDIR /app\n"
        "COPY pyproject.toml .\n"
        "RUN pip install --no-cache-dir .\n"
        "COPY . .\n"
        'CMD ["python", "-m", "myapp"]'
    ),
    "github action": (
        "name: CI\n"
        "on: [push, pull_request]\n"
        "jobs:\n"
        "  test:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "      - uses: actions/checkout@v4\n"
        "      - uses: actions/setup-python@v5\n"
        "        with:\n"
        "          python-version: '3.12'\n"
        "      - run: pip install -e '.[test]'\n"
        "      - run: pytest"
    ),
    "makefile": (
        ".PHONY: dev test lint build\n\n"
        "dev:\n"
        "\tpip install -e '.[dev]'\n\n"
        "test:\n"
        "\tpytest -q\n\n"
        "lint:\n"
        "\truff check .\n\n"
        "build:\n"
        "\tpython -m build"
    ),
}


# ── Hub display helpers ──────────────────────────────────────────────────

def clear_screen() -> str:
    return f"{CSI}2J{CSI}H"


def hr() -> None:
    cols = shutil.get_terminal_size(fallback=(100, 30)).columns
    print(f"{MUTED}{'-' * min(cols - 2, 96)}{RESET}")


def show_list_menu(title: str, items: list[str]) -> str:
    print(clear_screen(), end="")
    print(f"{TITLE}{title}{RESET}")
    hr()
    for idx, item in enumerate(items, start=1):
        print(f"{ACCENT}{idx:>2}.{RESET} {item}")
    print(f"{ACCENT} 0.{RESET} Back")
    hr()
    return input(f"{GREEN}Select option:{RESET} ").strip()


def show_code(title: str, code: str) -> None:
    print(clear_screen(), end="")
    print(f"{TITLE}{title}{RESET}")
    hr()
    print(code)
    hr()
    input(f"{MUTED}Press Enter to go back...{RESET}")


# ── Hub menus ────────────────────────────────────────────────────────────

def snippets_menu() -> None:
    keys = list(SNIPPETS.keys())
    while True:
        choice = show_list_menu("Bunjee Snippet Library", [k.replace("_", " ").title() for k in keys])
        if choice == "0":
            return
        if choice.isdigit() and 1 <= int(choice) <= len(keys):
            key = keys[int(choice) - 1]
            show_code(f"Snippet: {key}", SNIPPETS[key])


def tutorials_menu() -> None:
    keys = list(TUTORIALS.keys())
    while True:
        choice = show_list_menu("Bunjee Tutorials", keys)
        if choice == "0":
            return
        if choice.isdigit() and 1 <= int(choice) <= len(keys):
            key = keys[int(choice) - 1]
            print(clear_screen(), end="")
            print(f"{TITLE}Tutorial: {key}{RESET}")
            hr()
            for i, step in enumerate(TUTORIALS[key], start=1):
                print(f"{YELLOW}{i}.{RESET} {step}")
            hr()
            input(f"{MUTED}Press Enter to go back...{RESET}")


def templates_menu() -> None:
    keys = list(TEMPLATES.keys())
    while True:
        choice = show_list_menu("Bunjee Templates", [k.title() for k in keys])
        if choice == "0":
            return
        if choice.isdigit() and 1 <= int(choice) <= len(keys):
            key = keys[int(choice) - 1]
            show_code(f"Template: {key}", TEMPLATES[key])


def utilities_menu() -> None:
    while True:
        choice = show_list_menu(
            "Bunjee Utilities",
            [
                "Slugify text",
                "JSON pretty print",
                "Now timestamp",
                "Generate password",
                "Generate UUID",
                "Base64 encode / decode",
                "Hash a string",
            ],
        )
        if choice == "0":
            return
        if choice == "1":
            text = input("Text: ").strip().lower()
            slug = "-".join("".join(ch for ch in token if ch.isalnum()) for token in text.split())
            print(f"\n{GREEN}Slug:{RESET} {slug}\n")
            input(f"{MUTED}Press Enter to continue...{RESET}")
        elif choice == "2":
            print("Paste one-line JSON:")
            raw = input().strip()
            try:
                import json
                print(json.dumps(json.loads(raw), indent=2, sort_keys=True))
            except Exception as exc:
                print(f"{YELLOW}Invalid JSON:{RESET} {exc}")
            print()
            input(f"{MUTED}Press Enter to continue...{RESET}")
        elif choice == "3":
            print(f"\n{GREEN}UTC now:{RESET} {datetime.now(timezone.utc).isoformat()}\n")
            input(f"{MUTED}Press Enter to continue...{RESET}")
        elif choice == "4":
            import secrets
            import string
            alphabet = string.ascii_letters + string.digits + "!@#$%&*-_=+"
            pw = "".join(secrets.choice(alphabet) for _ in range(20))
            print(f"\n{GREEN}Password:{RESET} {pw}\n")
            input(f"{MUTED}Press Enter to continue...{RESET}")
        elif choice == "5":
            import uuid
            print(f"\n{GREEN}UUID:{RESET} {uuid.uuid4()}\n")
            input(f"{MUTED}Press Enter to continue...{RESET}")
        elif choice == "6":
            import base64
            action = input("(e)ncode or (d)ecode? ").strip().lower()
            text = input("Text: ").strip()
            if action.startswith("e"):
                print(f"\n{GREEN}Encoded:{RESET} {base64.b64encode(text.encode()).decode()}\n")
            else:
                try:
                    print(f"\n{GREEN}Decoded:{RESET} {base64.b64decode(text).decode()}\n")
                except Exception as e:
                    print(f"{YELLOW}Error:{RESET} {e}\n")
            input(f"{MUTED}Press Enter to continue...{RESET}")
        elif choice == "7":
            import hashlib
            text = input("String to hash: ").strip()
            print(f"\n{GREEN}SHA256:{RESET} {hashlib.sha256(text.encode()).hexdigest()}")
            print(f"{GREEN}MD5:{RESET}    {hashlib.md5(text.encode()).hexdigest()}\n")
            input(f"{MUTED}Press Enter to continue...{RESET}")


def search_menu() -> None:
    query = input("Search keyword: ").strip().lower()
    if not query:
        return
    print(clear_screen(), end="")
    print(f"{TITLE}Search Results for '{query}'{RESET}")
    hr()
    hits = 0
    for name, code in SNIPPETS.items():
        if query in name or query in code.lower():
            print(f"{GREEN}Snippet:{RESET} {name}")
            hits += 1
    for name, steps in TUTORIALS.items():
        joined = " ".join(steps).lower()
        if query in name.lower() or query in joined:
            print(f"{GREEN}Tutorial:{RESET} {name}")
            hits += 1
    for name, body in TEMPLATES.items():
        if query in name.lower() or query in body.lower():
            print(f"{GREEN}Template:{RESET} {name}")
            hits += 1
    if hits == 0:
        print(f"{YELLOW}No matches found.{RESET}")
    hr()
    input(f"{MUTED}Press Enter to continue...{RESET}")


def about_screen() -> None:
    print(clear_screen(), end="")
    print(f"{TITLE}About Bunjee{RESET}")
    hr()
    print("Bunjee is a zero-dependency developer Swiss Army knife.")
    print()
    print("  Interactive hub:   bunjee")
    print("  Scaffold project:  bunjee init myapp")
    print("  HTTP server:       bunjee serve")
    print("  Generate secrets:  bunjee gen password")
    print("  Directory tree:    bunjee tree")
    print("  Pretty-print JSON: bunjee json file.json")
    print("  Hash files:        bunjee hash file.txt")
    print("  Check ports:       bunjee port 8080")
    print("  Countdown timer:   bunjee timer 5m")
    print("  Todo list:         bunjee todo add \"my task\"")
    print("  Base64:            bunjee b64 hello")
    print("  Line counter:      bunjee count")
    print("  File diff:         bunjee diff a.py b.py")
    print("  System info:       bunjee env")
    print("  Your IP:           bunjee ip")
    print("  Lorem ipsum:       bunjee lorem --words 100")
    print()
    print(f"{MUTED}All commands work with zero external dependencies.{RESET}")
    hr()
    input(f"{MUTED}Press Enter to continue...{RESET}")


def run_hub() -> None:
    while True:
        print(clear_screen(), end="")
        print(f"{TITLE}BUNGEE Developer Hub{RESET}")
        print(f"{MUTED}Your developer Swiss Army knife. Type a number to explore.{RESET}")
        hr()
        print(f"{ACCENT} 1.{RESET} Snippet library ({len(SNIPPETS)} snippets)")
        print(f"{ACCENT} 2.{RESET} Tutorials ({len(TUTORIALS)} guides)")
        print(f"{ACCENT} 3.{RESET} Project templates ({len(TEMPLATES)} templates)")
        print(f"{ACCENT} 4.{RESET} Utilities")
        print(f"{ACCENT} 5.{RESET} Search everything")
        print(f"{ACCENT} 6.{RESET} About / all commands")
        print(f"{ACCENT} 0.{RESET} Exit")
        hr()
        choice = input(f"{GREEN}Select option:{RESET} ").strip()
        if choice == "1":
            snippets_menu()
        elif choice == "2":
            tutorials_menu()
        elif choice == "3":
            templates_menu()
        elif choice == "4":
            utilities_menu()
        elif choice == "5":
            search_menu()
        elif choice == "6":
            about_screen()
        elif choice == "0":
            print(f"{MUTED}Goodbye from Bunjee.{RESET}")
            return


# ── Argparse CLI ─────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="bunjee",
        description="Bunjee — 15+ developer tools, zero dependencies.",
    )
    p.add_argument("--no-animation", action="store_true", help="Skip startup animation")
    sub = p.add_subparsers(dest="command")

    # init
    s = sub.add_parser("init", help="Scaffold a new Python project")
    s.add_argument("name", help="Project name (e.g. my-tool)")
    s.add_argument("--dest", help="Parent directory (default: current)")

    # serve
    s = sub.add_parser("serve", help="Start a quick HTTP file server")
    s.add_argument("dir", nargs="?", help="Directory to serve (default: .)")
    s.add_argument("-p", "--port", type=int, default=8000)

    # gen
    s = sub.add_parser("gen", help="Generate passwords, UUIDs, tokens")
    s.add_argument("kind", choices=["password", "uuid", "token", "hex", "pin"])
    s.add_argument("-l", "--length", type=int, help="Length (for password/token/hex/pin)")

    # tree
    s = sub.add_parser("tree", help="Show directory tree")
    s.add_argument("dir", nargs="?", help="Directory (default: .)")
    s.add_argument("-d", "--depth", type=int, default=0, help="Max depth (0=unlimited)")
    s.add_argument("-a", "--all", action="store_true", help="Show hidden files")

    # json
    s = sub.add_parser("json", help="Pretty-print & query JSON")
    s.add_argument("file", nargs="?", default="-", help="JSON file (default: stdin)")
    s.add_argument("-q", "--query", help="Dot-path query (e.g. data.users.0.name)")
    s.add_argument("-c", "--compact", action="store_true", help="Compact output")
    s.add_argument("-s", "--sort", action="store_true", help="Sort keys")
    s.add_argument("-k", "--keys", action="store_true", help="Show only top-level keys")

    # hash
    s = sub.add_parser("hash", help="Hash a file or string")
    s.add_argument("target", help="File path or string to hash")
    s.add_argument("-a", "--algo", default="sha256", help="Algorithm (default: sha256)")

    # port
    s = sub.add_parser("port", help="Check if a port is open")
    s.add_argument("port", type=int, help="Port number")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--scan", action="store_true", help="Scan a range of ports")
    s.add_argument("--to", type=int, help="End of scan range")

    # timer
    s = sub.add_parser("timer", help="Countdown timer (e.g. 5m, 90s, 1h)")
    s.add_argument("duration", help="Duration: 30s, 5m, 1h, or seconds")
    s.add_argument("-l", "--label", help="Label for the timer")

    # todo
    s = sub.add_parser("todo", help="Persistent todo list")
    s.add_argument("action", nargs="?", choices=["list", "add", "done", "undo", "rm", "clear"])
    s.add_argument("text", nargs="*", help="Todo text (for add)")
    s.add_argument("-n", "--number", type=int, help="Todo number (for done/undo/rm)")

    # b64
    s = sub.add_parser("b64", help="Base64 encode/decode")
    s.add_argument("text", nargs="*", help="Text to encode (or decode with -d)")
    s.add_argument("-d", "--decode", action="store_true")
    s.add_argument("-f", "--file", help="File to encode")

    # ip
    sub.add_parser("ip", help="Show your IP addresses")

    # env
    s = sub.add_parser("env", help="System & environment info")
    s.add_argument("var", nargs="?", help="Specific env var to show")
    s.add_argument("--path", action="store_true", help="Show PATH entries")

    # lorem
    s = sub.add_parser("lorem", help="Generate placeholder text")
    s.add_argument("-w", "--words", type=int, default=50, help="Word count")

    # diff
    s = sub.add_parser("diff", help="Diff two files")
    s.add_argument("file_a", help="First file")
    s.add_argument("file_b", help="Second file")

    # count
    s = sub.add_parser("count", help="Count lines of code by file type")
    s.add_argument("dir", nargs="?", help="Directory (default: .)")

    return p


COMMANDS = [
    {
        "name": "init",
        "short": "Scaffold a Python project",
        "usage": "bunjee init <name> [--dest DIR]",
        "examples": [
            "bunjee init myapp",
            "bunjee init my-tool --dest ~/projects",
        ],
        "detail": (
            "Creates a complete Python project with pyproject.toml,\n"
            "  CLI entry point, starter test, .gitignore, and README.\n"
            "  Ready to pip install -e . and publish to PyPI."
        ),
    },
    {
        "name": "serve",
        "short": "HTTP file server",
        "usage": "bunjee serve [dir] [-p PORT]",
        "examples": [
            "bunjee serve",
            "bunjee serve ./build -p 3000",
        ],
        "detail": (
            "Starts an instant HTTP server to serve files from a directory.\n"
            "  Defaults to current directory on port 8000."
        ),
    },
    {
        "name": "gen",
        "short": "Generate secrets",
        "usage": "bunjee gen <type> [-l LENGTH]",
        "examples": [
            "bunjee gen password",
            "bunjee gen password -l 32",
            "bunjee gen uuid",
            "bunjee gen token -l 48",
            "bunjee gen hex",
            "bunjee gen pin -l 8",
        ],
        "detail": (
            "Generate cryptographically secure passwords, UUIDs,\n"
            "  URL-safe tokens, hex strings, or numeric PINs.\n"
            "  Types: password, uuid, token, hex, pin"
        ),
    },
    {
        "name": "tree",
        "short": "Directory tree",
        "usage": "bunjee tree [dir] [-d DEPTH] [-a]",
        "examples": [
            "bunjee tree",
            "bunjee tree src -d 2",
            "bunjee tree -a",
        ],
        "detail": (
            "Display a directory tree with coloured output.\n"
            "  Automatically skips __pycache__, node_modules, .git, .venv.\n"
            "  Use -a to show hidden files, -d to limit depth."
        ),
    },
    {
        "name": "json",
        "short": "Pretty-print & query JSON",
        "usage": "bunjee json <file> [-q PATH] [-c] [-s] [-k]",
        "examples": [
            "bunjee json data.json",
            "bunjee json data.json -q users.0.name",
            "bunjee json data.json -k",
            "bunjee json data.json -s -c",
            "curl api.example.com | bunjee json -",
        ],
        "detail": (
            "Pretty-print JSON files with coloured keys.\n"
            "  -q  Dot-path query to drill into nested data\n"
            "  -k  Show only top-level keys\n"
            "  -s  Sort keys    -c  Compact output\n"
            "  Use - to read from stdin (pipe friendly)."
        ),
    },
    {
        "name": "hash",
        "short": "Hash files or strings",
        "usage": "bunjee hash <target> [-a ALGO]",
        "examples": [
            "bunjee hash myfile.txt",
            'bunjee hash "hello world"',
            "bunjee hash myfile.txt -a md5",
            "bunjee hash secret.key -a sha512",
        ],
        "detail": (
            "Hash a file or string with any algorithm.\n"
            "  Default: sha256. Also supports md5, sha1, sha512, etc.\n"
            "  Auto-detects whether the target is a file or a string."
        ),
    },
    {
        "name": "port",
        "short": "Check ports",
        "usage": "bunjee port <port> [--host HOST] [--scan] [--to END]",
        "examples": [
            "bunjee port 8080",
            "bunjee port 3000 --host 192.168.1.1",
            "bunjee port 8000 --scan --to 9000",
        ],
        "detail": (
            "Check if a port is open or scan a range.\n"
            "  Use --scan to sweep a range of ports.\n"
            "  Use --to to set the end of the scan range."
        ),
    },
    {
        "name": "timer",
        "short": "Countdown timer",
        "usage": "bunjee timer <duration> [-l LABEL]",
        "examples": [
            "bunjee timer 5m",
            "bunjee timer 90s",
            "bunjee timer 1h",
            'bunjee timer 25m -l "Focus session"',
        ],
        "detail": (
            "Animated countdown timer with progress bar.\n"
            "  Accepts: 30s, 5m, 1h, or plain seconds.\n"
            "  Ctrl-C to cancel. Add -l for a label."
        ),
    },
    {
        "name": "todo",
        "short": "Persistent todo list",
        "usage": "bunjee todo [action] [text] [-n NUM]",
        "examples": [
            "bunjee todo",
            'bunjee todo add "fix login bug"',
            "bunjee todo done -n 1",
            "bunjee todo undo -n 1",
            "bunjee todo rm -n 2",
            "bunjee todo clear",
        ],
        "detail": (
            "A persistent todo list stored in ~/.bunjee/todos.json.\n"
            "  Survives across terminal sessions.\n"
            "  Actions: list (default), add, done, undo, rm, clear"
        ),
    },
    {
        "name": "b64",
        "short": "Base64 encode / decode",
        "usage": "bunjee b64 <text> [-d] [-f FILE]",
        "examples": [
            'bunjee b64 "hello world"',
            "bunjee b64 -d aGVsbG8gd29ybGQ=",
            "bunjee b64 -f image.png",
        ],
        "detail": (
            "Encode text or files to base64, or decode base64 strings.\n"
            "  -d  Decode mode\n"
            "  -f  Encode a file instead of text"
        ),
    },
    {
        "name": "count",
        "short": "Lines of code by type",
        "usage": "bunjee count [dir]",
        "examples": [
            "bunjee count",
            "bunjee count src/",
        ],
        "detail": (
            "Count lines of code grouped by file extension.\n"
            "  Skips .git, __pycache__, node_modules, .venv, dist, build.\n"
            "  Shows files and lines per extension, sorted by lines."
        ),
    },
    {
        "name": "diff",
        "short": "Diff two files",
        "usage": "bunjee diff <file_a> <file_b>",
        "examples": [
            "bunjee diff old.py new.py",
            "bunjee diff config.json config.backup.json",
        ],
        "detail": (
            "Unified diff with coloured output.\n"
            "  Green = added lines, Yellow = removed lines."
        ),
    },
    {
        "name": "env",
        "short": "System & Python info",
        "usage": "bunjee env [var] [--path]",
        "examples": [
            "bunjee env",
            "bunjee env HOME",
            "bunjee env --path",
        ],
        "detail": (
            "Show OS, Python version, current directory, and key env vars.\n"
            "  Pass a var name to check a specific variable.\n"
            "  --path shows all PATH entries with existence checks."
        ),
    },
    {
        "name": "ip",
        "short": "Show IP addresses",
        "usage": "bunjee ip",
        "examples": ["bunjee ip"],
        "detail": "Show your hostname, local IP, and LAN IP.",
    },
    {
        "name": "lorem",
        "short": "Placeholder text",
        "usage": "bunjee lorem [-w COUNT]",
        "examples": [
            "bunjee lorem",
            "bunjee lorem -w 200",
        ],
        "detail": "Generate lorem ipsum placeholder text.\n  Default: 50 words. Use -w to set word count.",
    },
]


def _clear() -> str:
    return f"{CSI}2J{CSI}H"


def _hr() -> None:
    cols = shutil.get_terminal_size(fallback=(100, 30)).columns
    print(f"{MUTED}{'─' * min(cols - 2, 80)}{RESET}")


def _show_home() -> None:
    print(_clear(), end="")
    print()
    print(f"  {TITLE}B U N J E E{RESET}")
    print(f"  {MUTED}15+ tools. Zero dependencies. Just works.{RESET}")
    print()
    _hr()
    for i, cmd in enumerate(COMMANDS, 1):
        num = f"{ACCENT}{i:>2}{RESET}"
        name = f"{GREEN}{cmd['name']:>6s}{RESET}"
        print(f"  {num}  {name}  {cmd['short']}")
    print()
    print(f"  {ACCENT} 0{RESET}  {MUTED}Exit{RESET}")
    _hr()


def _show_detail(cmd: dict) -> None:
    print(_clear(), end="")
    print()
    print(f"  {TITLE}{cmd['name']}{RESET}  {MUTED}{cmd['short']}{RESET}")
    print()
    _hr()
    print(f"  {ACCENT}Usage{RESET}")
    print(f"    {cmd['usage']}")
    print()
    print(f"  {ACCENT}Examples{RESET}")
    for ex in cmd["examples"]:
        print(f"    {GREEN}${RESET} {ex}")
    print()
    print(f"  {ACCENT}Details{RESET}")
    print(f"    {cmd['detail']}")
    print()
    _hr()


def interactive_menu() -> None:
    while True:
        _show_home()
        choice = input(f"  {GREEN}>{RESET} ").strip()
        if choice == "0" or choice.lower() in ("q", "quit", "exit"):
            print(f"\n  {MUTED}Bye.{RESET}\n")
            return
        if choice.isdigit() and 1 <= int(choice) <= len(COMMANDS):
            cmd = COMMANDS[int(choice) - 1]
            _show_detail(cmd)
            input(f"  {MUTED}Press Enter to go back...{RESET}")


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command is None:
        from .animation import play_intro
        if not args.no_animation:
            play_intro()
        interactive_menu()
        return

    from . import tools

    dispatch = {
        "init": tools.cmd_init,
        "serve": tools.cmd_serve,
        "gen": tools.cmd_gen,
        "tree": tools.cmd_tree,
        "json": tools.cmd_json,
        "hash": tools.cmd_hash,
        "port": tools.cmd_port,
        "timer": tools.cmd_timer,
        "todo": tools.cmd_todo,
        "b64": tools.cmd_b64,
        "ip": tools.cmd_ip,
        "env": tools.cmd_env,
        "lorem": tools.cmd_lorem,
        "diff": tools.cmd_diff,
        "count": tools.cmd_count,
    }

    handler = dispatch.get(args.command)
    if handler:
        handler(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
