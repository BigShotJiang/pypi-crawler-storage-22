"""Developer power tools — zero external dependencies."""
from __future__ import annotations

import base64
import hashlib
import http.server
import json
import os
import pathlib
import secrets
import socket
import string
import sys
import time
import uuid


# ── colours ──────────────────────────────────────────────────────────────
G = "\x1b[1;92m"   # green
Y = "\x1b[1;93m"   # yellow
C = "\x1b[1;96m"   # cyan
M = "\x1b[38;5;250m"  # muted
R = "\x1b[0m"      # reset
B = "\x1b[1m"      # bold

_COLOUR = sys.stdout.isatty()


def _c(code: str, text: str) -> str:
    return f"{code}{text}{R}" if _COLOUR else text


# ── bunjee init ──────────────────────────────────────────────────────────

_PYPROJECT = """\
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "{name}"
version = "0.1.0"
description = ""
readme = "README.md"
requires-python = ">=3.9"
license = "MIT"

[project.scripts]
{name} = "{pkg}.cli:main"

[tool.setuptools.packages.find]
include = ["{pkg}*"]
"""

_CLI_PY = """\
def main() -> None:
    print("Hello from {name}!")


if __name__ == "__main__":
    main()
"""

_TEST_PY = """\
from {pkg}.cli import main


def test_main(capsys):
    main()
    assert "{name}" in capsys.readouterr().out
"""

_INIT_PY = """\
from .cli import main

__all__ = ["main"]
"""

_GITIGNORE = """\
__pycache__/
*.pyc
*.egg-info/
dist/
build/
.venv/
.env
"""


def cmd_init(args) -> None:
    name = args.name
    pkg = name.replace("-", "_")
    dest = pathlib.Path(args.dest or ".") / name

    if dest.exists():
        print(_c(Y, f"Directory {dest} already exists."))
        return

    # create structure
    (dest / pkg).mkdir(parents=True)
    (dest / "tests").mkdir()

    (dest / "pyproject.toml").write_text(_PYPROJECT.format(name=name, pkg=pkg))
    (dest / pkg / "__init__.py").write_text(_INIT_PY.format(pkg=pkg))
    (dest / pkg / "cli.py").write_text(_CLI_PY.format(name=name))
    (dest / "tests" / f"test_cli.py").write_text(_TEST_PY.format(name=name, pkg=pkg))
    (dest / "README.md").write_text(f"# {name}\n")
    (dest / ".gitignore").write_text(_GITIGNORE)

    print(_c(G, f"Project created at {dest}/"))
    print(f"  {pkg}/cli.py      — your code")
    print(f"  tests/test_cli.py — starter test")
    print(f"  pyproject.toml    — ready to build & publish")
    print()
    print(f"  cd {dest} && pip install -e . && {name}")


# ── bunjee serve ─────────────────────────────────────────────────────────

def cmd_serve(args) -> None:
    directory = os.path.abspath(args.dir or ".")
    port = args.port

    class Handler(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **kw):
            super().__init__(*a, directory=directory, **kw)

        def log_message(self, fmt, *log_args):
            ts = time.strftime("%H:%M:%S")
            print(f"  {_c(M, ts)}  {log_args[0]}  {_c(C, str(log_args[1]))}")

    print(_c(G, f"Serving {directory}"))
    print(f"  http://localhost:{port}")
    print(_c(M, "  Ctrl-C to stop"))
    try:
        http.server.HTTPServer(("", port), Handler).serve_forever()
    except KeyboardInterrupt:
        print(_c(M, "\nStopped."))


# ── bunjee gen ───────────────────────────────────────────────────────────

def cmd_gen(args) -> None:
    kind = args.kind

    if kind == "password":
        length = args.length or 20
        alphabet = string.ascii_letters + string.digits + "!@#$%&*-_=+"
        pw = "".join(secrets.choice(alphabet) for _ in range(length))
        print(_c(G, "Password: ") + pw)

    elif kind == "uuid":
        print(_c(G, "UUID: ") + str(uuid.uuid4()))

    elif kind == "token":
        length = args.length or 32
        print(_c(G, "Token: ") + secrets.token_urlsafe(length))

    elif kind == "hex":
        length = args.length or 32
        print(_c(G, "Hex: ") + secrets.token_hex(length))

    elif kind == "pin":
        length = args.length or 6
        pin = "".join(secrets.choice(string.digits) for _ in range(length))
        print(_c(G, "PIN: ") + pin)

    else:
        print(_c(Y, f"Unknown type '{kind}'. Use: password, uuid, token, hex, pin"))


# ── bunjee tree ──────────────────────────────────────────────────────────

def cmd_tree(args) -> None:
    root = pathlib.Path(args.dir or ".").resolve()
    depth = args.depth
    show_hidden = args.all

    if not root.is_dir():
        print(_c(Y, f"Not a directory: {root}"))
        return

    print(_c(B, str(root)))
    _print_tree(root, "", depth, show_hidden, 0)


def _print_tree(path: pathlib.Path, prefix: str, max_depth: int, show_hidden: bool, level: int) -> None:
    if max_depth and level >= max_depth:
        return
    try:
        entries = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
    except PermissionError:
        return

    # filter
    if not show_hidden:
        entries = [e for e in entries if not e.name.startswith(".")]
    # skip common noise
    entries = [e for e in entries if e.name not in {"__pycache__", "node_modules", ".git", ".venv", "venv"}]

    for i, entry in enumerate(entries):
        is_last = i == len(entries) - 1
        connector = "└── " if is_last else "├── "
        colour = C if entry.is_dir() else ""
        print(f"{prefix}{connector}{_c(colour, entry.name)}")
        if entry.is_dir():
            extension = "    " if is_last else "│   "
            _print_tree(entry, prefix + extension, max_depth, show_hidden, level + 1)


# ── bunjee json ──────────────────────────────────────────────────────────

def cmd_json(args) -> None:
    source = args.file

    if source == "-" or not source:
        raw = sys.stdin.read()
    else:
        p = pathlib.Path(source)
        if not p.exists():
            print(_c(Y, f"File not found: {source}"))
            return
        raw = p.read_text()

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        print(_c(Y, f"Invalid JSON: {e}"))
        return

    if args.query:
        for key in args.query.split("."):
            if isinstance(data, dict):
                data = data.get(key)
            elif isinstance(data, list) and key.isdigit():
                data = data[int(key)]
            else:
                print(_c(Y, f"Cannot traverse into {type(data).__name__} with key '{key}'"))
                return
            if data is None:
                print(_c(Y, "null"))
                return

    if args.compact:
        print(json.dumps(data, separators=(",", ":")))
    elif args.keys and isinstance(data, dict):
        for k in data:
            print(k)
    else:
        output = json.dumps(data, indent=2, sort_keys=args.sort, ensure_ascii=False)
        if _COLOUR:
            output = _colorize_json(output)
        print(output)


def _colorize_json(text: str) -> str:
    lines = []
    for line in text.split("\n"):
        stripped = line.lstrip()
        if stripped.startswith('"') and '": ' in stripped:
            key_end = stripped.index('": ')
            key = stripped[: key_end + 1]
            rest = stripped[key_end + 1 :]
            indent = line[: len(line) - len(stripped)]
            lines.append(f"{indent}{C}{key}{R}{rest}")
        else:
            lines.append(line)
    return "\n".join(lines)


# ── bunjee hash ──────────────────────────────────────────────────────────

def cmd_hash(args) -> None:
    algo = args.algo
    target = args.target

    if algo not in hashlib.algorithms_available:
        print(_c(Y, f"Unknown algorithm '{algo}'. Available: md5, sha1, sha256, sha512"))
        return

    h = hashlib.new(algo)

    p = pathlib.Path(target)
    if p.is_file():
        with open(p, "rb") as f:
            while chunk := f.read(8192):
                h.update(chunk)
        label = f"({algo}) {p.name}"
    else:
        h.update(target.encode())
        label = f"({algo}) string"

    print(f"{_c(G, label)}  {h.hexdigest()}")


# ── bunjee port ──────────────────────────────────────────────────────────

def cmd_port(args) -> None:
    port = args.port
    host = args.host or "127.0.0.1"

    if args.scan:
        lo, hi = (port, port + 100) if not args.to else (port, args.to + 1)
        print(_c(B, f"Scanning {host}:{lo}-{hi - 1}"))
        found = 0
        for p in range(lo, hi):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.15)
                if s.connect_ex((host, p)) == 0:
                    print(f"  {_c(G, 'OPEN')}  {host}:{p}")
                    found += 1
        if found == 0:
            print(_c(M, "  No open ports found."))
        return

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        result = s.connect_ex((host, port))

    if result == 0:
        print(f"  {_c(G, 'OPEN')}  {host}:{port}")
    else:
        print(f"  {_c(Y, 'CLOSED')}  {host}:{port}")


# ── bunjee timer ─────────────────────────────────────────────────────────

def _parse_duration(s: str) -> int:
    s = s.strip().lower()
    if s.endswith("h"):
        return int(float(s[:-1]) * 3600)
    if s.endswith("m"):
        return int(float(s[:-1]) * 60)
    if s.endswith("s"):
        return int(float(s[:-1]))
    return int(s)


def cmd_timer(args) -> None:
    total = _parse_duration(args.duration)
    label = args.label or ""

    if label:
        print(_c(B, f"  {label}"))

    try:
        for remaining in range(total, 0, -1):
            mins, secs = divmod(remaining, 60)
            hrs, mins = divmod(mins, 60)
            display = f"{hrs:02d}:{mins:02d}:{secs:02d}" if hrs else f"{mins:02d}:{secs:02d}"
            bar_width = 30
            filled = int((total - remaining) / total * bar_width)
            bar = f"{'█' * filled}{'░' * (bar_width - filled)}"
            sys.stdout.write(f"\r  {_c(G, display)}  {bar}  ")
            sys.stdout.flush()
            time.sleep(1)
    except KeyboardInterrupt:
        print(_c(Y, "\n  Timer cancelled."))
        return

    sys.stdout.write(f"\r  {_c(G, '00:00')}  {'█' * 30}  \n")
    print(_c(G, "  Done!") + (" 🔔" if _COLOUR else " DING!"))


# ── bunjee todo ──────────────────────────────────────────────────────────

_TODO_FILE = pathlib.Path.home() / ".bunjee" / "todos.json"


def _load_todos() -> list[dict]:
    if _TODO_FILE.exists():
        return json.loads(_TODO_FILE.read_text())
    return []


def _save_todos(todos: list[dict]) -> None:
    _TODO_FILE.parent.mkdir(parents=True, exist_ok=True)
    _TODO_FILE.write_text(json.dumps(todos, indent=2))


def cmd_todo(args) -> None:
    action = args.action or "list"

    if action == "list":
        todos = _load_todos()
        if not todos:
            print(_c(M, "  No todos yet. Add one with: bunjee todo add \"my task\""))
            return
        for i, t in enumerate(todos, 1):
            check = _c(G, "✓") if t.get("done") else _c(Y, "○")
            text = _c(M, t["text"]) if t.get("done") else t["text"]
            print(f"  {check} {i}. {text}")
        done = sum(1 for t in todos if t.get("done"))
        print(f"\n  {_c(M, f'{done}/{len(todos)} completed')}")

    elif action == "add":
        text = " ".join(args.text) if args.text else ""
        if not text:
            print(_c(Y, "Usage: bunjee todo add \"task description\""))
            return
        todos = _load_todos()
        todos.append({"text": text, "done": False, "added": time.strftime("%Y-%m-%d %H:%M")})
        _save_todos(todos)
        print(_c(G, f"  Added: ") + text)

    elif action == "done":
        idx = args.number
        if not idx:
            print(_c(Y, "Usage: bunjee todo done 1"))
            return
        todos = _load_todos()
        if 1 <= idx <= len(todos):
            todos[idx - 1]["done"] = True
            _save_todos(todos)
            print(_c(G, f"  Done: ") + todos[idx - 1]["text"])
        else:
            print(_c(Y, f"  No todo #{idx}"))

    elif action == "undo":
        idx = args.number
        if not idx:
            print(_c(Y, "Usage: bunjee todo undo 1"))
            return
        todos = _load_todos()
        if 1 <= idx <= len(todos):
            todos[idx - 1]["done"] = False
            _save_todos(todos)
            print(_c(C, f"  Reopened: ") + todos[idx - 1]["text"])
        else:
            print(_c(Y, f"  No todo #{idx}"))

    elif action == "rm":
        idx = args.number
        if not idx:
            print(_c(Y, "Usage: bunjee todo rm 1"))
            return
        todos = _load_todos()
        if 1 <= idx <= len(todos):
            removed = todos.pop(idx - 1)
            _save_todos(todos)
            print(_c(Y, f"  Removed: ") + removed["text"])
        else:
            print(_c(Y, f"  No todo #{idx}"))

    elif action == "clear":
        _save_todos([])
        print(_c(M, "  All todos cleared."))


# ── bunjee b64 ───────────────────────────────────────────────────────────

def cmd_b64(args) -> None:
    if args.decode:
        try:
            if args.text:
                raw = " ".join(args.text)
            else:
                raw = sys.stdin.read().strip()
            decoded = base64.b64decode(raw).decode("utf-8", errors="replace")
            print(decoded)
        except Exception as e:
            print(_c(Y, f"Decode error: {e}"))
    else:
        if args.text:
            data = " ".join(args.text).encode()
        elif args.file:
            data = pathlib.Path(args.file).read_bytes()
        else:
            data = sys.stdin.buffer.read()
        print(base64.b64encode(data).decode())


# ── bunjee ip ────────────────────────────────────────────────────────────

def cmd_ip(args) -> None:
    hostname = socket.gethostname()
    try:
        local_ip = socket.gethostbyname(hostname)
    except socket.gaierror:
        local_ip = "unknown"

    print(f"  {_c(G, 'Hostname:')}  {hostname}")
    print(f"  {_c(G, 'Local IP:')}  {local_ip}")

    # try to get the real LAN IP
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            lan_ip = s.getsockname()[0]
        print(f"  {_c(G, 'LAN IP:  ')}  {lan_ip}")
    except Exception:
        pass


# ── bunjee env ───────────────────────────────────────────────────────────

def cmd_env(args) -> None:
    import platform

    print(_c(B, "  System"))
    print(f"    OS:       {platform.system()} {platform.release()}")
    print(f"    Machine:  {platform.machine()}")
    print(f"    Python:   {platform.python_version()} ({sys.executable})")
    print(f"    CWD:      {os.getcwd()}")
    print()

    if args.var:
        val = os.environ.get(args.var, _c(Y, "(not set)"))
        print(f"  {_c(G, args.var)} = {val}")
        return

    if args.path:
        print(_c(B, "  PATH entries"))
        for p in os.environ.get("PATH", "").split(os.pathsep):
            exists = pathlib.Path(p).exists()
            mark = _c(G, "✓") if exists else _c(Y, "✗")
            print(f"    {mark} {p}")
        return

    print(_c(B, "  Key env vars"))
    for var in ["HOME", "USER", "SHELL", "EDITOR", "VIRTUAL_ENV", "CONDA_DEFAULT_ENV", "PATH"]:
        val = os.environ.get(var)
        if val:
            if var == "PATH":
                val = f"({len(val.split(os.pathsep))} entries)"
            print(f"    {_c(C, var):>30s}  {val}")


# ── bunjee lorem ─────────────────────────────────────────────────────────

_LOREM = (
    "Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor "
    "incididunt ut labore et dolore magna aliqua Ut enim ad minim veniam quis nostrud "
    "exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat Duis aute "
    "irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla "
    "pariatur Excepteur sint occaecat cupidatat non proident sunt in culpa qui officia "
    "deserunt mollit anim id est laborum"
)


def cmd_lorem(args) -> None:
    words = _LOREM.split()
    count = args.words or 50
    out = []
    for i in range(count):
        w = words[i % len(words)]
        if i == 0 or (i > 0 and out[-1].endswith(".")):
            w = w.capitalize()
        out.append(w)
        if (i + 1) % 15 == 0 and i < count - 1:
            out[-1] += "."
    if not out[-1].endswith("."):
        out[-1] += "."
    print(" ".join(out))


# ── bunjee diff ──────────────────────────────────────────────────────────

def cmd_diff(args) -> None:
    import difflib

    file_a = pathlib.Path(args.file_a)
    file_b = pathlib.Path(args.file_b)

    if not file_a.exists():
        print(_c(Y, f"Not found: {file_a}"))
        return
    if not file_b.exists():
        print(_c(Y, f"Not found: {file_b}"))
        return

    lines_a = file_a.read_text().splitlines(keepends=True)
    lines_b = file_b.read_text().splitlines(keepends=True)

    diff = difflib.unified_diff(lines_a, lines_b, fromfile=str(file_a), tofile=str(file_b))
    for line in diff:
        if line.startswith("+") and not line.startswith("+++"):
            sys.stdout.write(_c(G, line))
        elif line.startswith("-") and not line.startswith("---"):
            sys.stdout.write(_c(Y, line))
        elif line.startswith("@@"):
            sys.stdout.write(_c(C, line))
        else:
            sys.stdout.write(line)


# ── bunjee count ─────────────────────────────────────────────────────────

def cmd_count(args) -> None:
    target = pathlib.Path(args.dir or ".").resolve()
    exts: dict[str, dict] = {}
    total_files = 0
    total_lines = 0

    for root, dirs, files in os.walk(target):
        # skip noise
        dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", "node_modules", ".venv", "venv", ".tox", "dist", "build"}]
        for f in files:
            fp = pathlib.Path(root) / f
            ext = fp.suffix or "(no ext)"
            if ext not in exts:
                exts[ext] = {"files": 0, "lines": 0}
            exts[ext]["files"] += 1
            total_files += 1
            try:
                lines = len(fp.read_text(errors="replace").splitlines())
                exts[ext]["lines"] += lines
                total_lines += lines
            except (PermissionError, OSError):
                pass

    if not exts:
        print(_c(M, "  No files found."))
        return

    sorted_exts = sorted(exts.items(), key=lambda x: x[1]["lines"], reverse=True)
    print(f"  {'Extension':>12s}  {'Files':>7s}  {'Lines':>9s}")
    print(f"  {'─' * 12}  {'─' * 7}  {'─' * 9}")
    for ext, info in sorted_exts[:20]:
        print(f"  {_c(C, ext):>20s}  {info['files']:>7d}  {info['lines']:>9d}")
    print(f"  {'─' * 12}  {'─' * 7}  {'─' * 9}")
    print(f"  {_c(G, 'Total'):>20s}  {total_files:>7d}  {total_lines:>9d}")
