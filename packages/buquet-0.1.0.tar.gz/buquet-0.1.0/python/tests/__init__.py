"""buquet test suite."""

from __future__ import annotations
