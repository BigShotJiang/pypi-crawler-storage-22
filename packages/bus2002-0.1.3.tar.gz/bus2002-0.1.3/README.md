# BUS 2002 Datasets

A Python package containing curated datasets for Washington and Lee University's BUS 202/215: Business Analytics course.

## Installation

```bash
pip install bus2002
```

## Usage

```python
from bus2002 import load_students

# Load student data
students_df = load_students()
print(students_df.head())

# List all available datasets
from bus2002 import list_datasets
list_datasets()
```

## Available Datasets

1. **students.csv** - Sample student data with names and ages

## Features

- 📦 Datasets bundled with the package (works offline after installation)
- 🚀 Easy-to-use loading functions
- 📚 Built-in documentation
- 🔄 Version controlled

## Requirements

- Python >= 3.7
- pandas >= 1.3.0

## Author

**Dr. Bright Frimpong**  
Assistant Professor, Business Administration  
Williams School of Commerce, Economics, and Politics  
Washington and Lee University

## License

MIT License - Free for educational use

## Updates

To get the latest version:
```bash
pip install --upgrade bus2002
```

## Support

For questions or issues, contact: bfrimpong@wlu.edu
