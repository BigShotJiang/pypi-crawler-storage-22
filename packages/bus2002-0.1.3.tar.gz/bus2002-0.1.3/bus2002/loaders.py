"""
Data loading functions for BUS 202/215: Business Analytics
Washington and Lee University
"""

import pandas as pd
import pkg_resources

def load_students():
    """
    Load the students dataset with names and ages.
    
    Returns:
        pandas.DataFrame: Student data with Name and Age columns
    
    Example:
        >>> from bus2002 import load_students
        >>> df = load_students()
        >>> df.head()
    """
    filepath = pkg_resources.resource_filename(
        'bus2002', 'data/students.csv'
    )
    return pd.read_csv(filepath)

def load_tips():
    """
    Load the tips dataset.
    
    Returns:
        pandas.DataFrame: Tips data
    
    Example:
        >>> from bus2002 import load_tips
        >>> df = load_tips()
        >>> df.head()
    """
    filepath = pkg_resources.resource_filename(
        'bus2002', 'data/tips.xlsx'
    )
    return pd.read_excel(filepath)

def load_car_crashes():
    """
    Load the car crashes dataset.
    
    Returns:
        pandas.DataFrame: Car crashes data
    
    Example:
        >>> from bus2002 import load_car_crashes
        >>> df = load_car_crashes()
        >>> df.head()
    """
    filepath = pkg_resources.resource_filename(
        'bus2002', 'data/car_crashes.xlsx'
    )
    return pd.read_excel(filepath)

def list_datasets():
    """
    List all available datasets in the package.
    
    Returns:
        list: Names of all available datasets
    """
    datasets = [
        'students',
        'tips',
        'car_crashes'
    ]
    print("Available datasets:")
    for dataset in datasets:
        print(f"  - {dataset}")
    return datasets
