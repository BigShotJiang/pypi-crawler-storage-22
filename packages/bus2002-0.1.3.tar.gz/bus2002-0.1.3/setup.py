from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="bus2002",
    version="0.1.3",
    author="Bright Frimpong",
    author_email="bfrimpong@wlu.edu",
    description="Curated datasets for WLU BUS 202 Business Analytics",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/brightambrose/bus2002",
    packages=find_packages(),
    package_data={
        'bus2002': ['data/*.csv', 'data/*.xlsx']
    },
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Education",
        "Topic :: Education",
    ],
    python_requires='>=3.7',
    install_requires=[
        'pandas>=1.3.0',
    ],
    extras_require={
        'dev': ['pytest', 'twine'],
    },
)
