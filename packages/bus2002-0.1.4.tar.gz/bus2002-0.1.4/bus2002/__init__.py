"""
BUS 2002 Datasets
================

A collection of curated datasets for Washington and Lee University
BUS 202/215: Business Analytics

Usage:
    >>> from bus202 import load_students
    >>> df = load_students()

Author: Dr. Bright Frimpong
Department: Business Administration, Williams School
"""

from .loaders import (
    load_students,
    load_tips,
    load_car_crashes,
    list_datasets
)

__version__ = "0.1.4"
__author__ = "Bright Frimpong"

__all__ = [
    'load_students',
    'load_tips',
    'load_car_crashes',
    'list_datasets'
]
