# BusBotMemory SDK

LLM-powered working memory for Vietnamese bus booking bots.

## Installation

```bash
pip install busbot-memory
```

Or install from source:
```bash
cd busbot-memory
pip install -e .
```

## Quick Start

```python
import asyncio
from busbot_memory import BusBotMemory, BusBotConfig

async def main():
    # Configure (set GROQ_API_KEY env var or pass directly)
    config = BusBotConfig(groq_api_key="gsk_xxx")
    
    # Initialize memory for a session
    memory = BusBotMemory(
        session_id="call_001",
        customer_id="0987654321",
        config=config
    )
    
    # Process messages
    result = await memory.process("đặt 2 vé đi đà nẵng ngày mai 8h sáng")
    
    print(result.state.slots)
    # {"destination": "Đà Nẵng", "date": "ngày mai", "time": "08:00", "quantity": 2}

asyncio.run(main())
```

## Features

- **LLM-powered extraction**: Uses Groq (llama-3.3-70b) for accurate entity extraction
- **Change-of-mind detection**: Automatically detects when user changes their booking
- **State tracking**: Maintains structured booking state with missing slot tracking
- **Low latency**: Optimized for < 250ms processing time
- **Fallback support**: Falls back to regex when LLM is unavailable

## Configuration

```python
config = BusBotConfig(
    # LLM Provider (at least one required)
    groq_api_key="gsk_xxx",           # Primary - fast & free
    openai_api_key="sk-xxx",          # Optional fallback
    
    # Performance
    latency_target_ms=250,
    enable_fallback=True,             # Use regex if LLM fails
    
    # Memory settings
    max_working_items=20,
    max_context_window=5,
)
```

## ProcessResult

```python
result = await memory.process(message)

result.entities       # Extracted entities
result.state          # BookingState object
result.is_noise       # Is filler message ("ừ", "ok")
result.is_change      # Did user change their mind
result.changes        # List of changes made
result.intent         # Detected intent
result.latency_ms     # Processing time
```

## License

MIT
