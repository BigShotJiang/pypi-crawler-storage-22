"""Configuration for BusBot Memory SDK"""

import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class BusBotConfig:
    """
    SDK Configuration
    
    Example:
        config = BusBotConfig(
            groq_api_key="gsk_xxx",
            redis_url="redis://localhost:6379",
            domain="bus_booking"
        )
    """
    # LLM Provider
    groq_api_key: Optional[str] = field(
        default_factory=lambda: os.getenv("GROQ_API_KEY")
    )
    groq_model: str = "llama-3.3-70b-versatile"
    groq_fallback_model: str = "llama-3.1-8b-instant"
    
    # OpenAI (optional, for higher quality)
    openai_api_key: Optional[str] = field(
        default_factory=lambda: os.getenv("OPENAI_API_KEY")
    )
    openai_model: str = "gpt-4o-mini"
    
    # Storage
    redis_url: Optional[str] = field(
        default_factory=lambda: os.getenv("REDIS_URL")
    )
    session_ttl_seconds: int = 3600       # 1 hour
    user_memory_ttl_days: int = 30        # 30 days
    
    # Domain
    domain: str = "bus_booking"
    
    # Memory settings
    max_working_items: int = 20
    max_context_window: int = 5
    
    # Performance
    latency_target_ms: int = 250
    enable_fallback: bool = True          # Fallback to regex if LLM fails
    enable_metrics: bool = True           # Track latency metrics
    
    # Logging
    log_level: str = "INFO"
    log_extractions: bool = False         # Log LLM extraction results
    
    def validate(self) -> bool:
        """Validate configuration"""
        if not self.groq_api_key and not self.openai_api_key:
            raise ValueError("At least one of groq_api_key or openai_api_key must be set")
        return True
