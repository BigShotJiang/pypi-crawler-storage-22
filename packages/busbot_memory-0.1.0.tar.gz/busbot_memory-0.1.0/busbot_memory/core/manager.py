"""
BusBotMemory - Main SDK Entry Point

This is the primary class users will interact with.
"""

import time
import logging
from typing import Optional, List
from collections import deque

from busbot_memory.core.config import BusBotConfig
from busbot_memory.core.models import (
    BookingState,
    MemoryItem,
    MemoryMetadata,
    ProcessResult,
    ExtractionResult,
)
from busbot_memory.extractors.llm import LLMExtractor
from busbot_memory.extractors.regex import RegexExtractor
from busbot_memory.state.manager import StateManager

logger = logging.getLogger(__name__)


class BusBotMemory:
    """
    LLM-powered working memory for bus booking bots
    
    Example:
        from busbot_memory import BusBotMemory, BusBotConfig
        
        config = BusBotConfig(groq_api_key="gsk_xxx")
        memory = BusBotMemory(
            session_id="call_001",
            customer_id="0987654321",
            config=config
        )
        
        result = await memory.process("đặt 2 vé đi đà nẵng ngày mai")
        print(result.state.slots)  # {"destination": "Đà Nẵng", "quantity": 2, ...}
    """
    
    def __init__(
        self,
        session_id: str,
        customer_id: Optional[str] = None,
        config: Optional[BusBotConfig] = None,
    ):
        self.session_id = session_id
        self.customer_id = customer_id
        self.config = config or BusBotConfig()
        
        # Validate config
        self.config.validate()
        
        # Initialize components
        self._llm_extractor = LLMExtractor(self.config)
        self._regex_extractor = RegexExtractor()
        self._state_manager = StateManager()
        
        # Working memory storage
        self._memory: deque = deque(maxlen=self.config.max_working_items)
        
        # Booking state
        self._state: BookingState = self._state_manager.create_initial_state()
        
        # User memory (persistent info)
        self._user_memory: dict = {}
        
        # Metrics
        self._latencies: List[int] = []
        
        logger.info(f"BusBotMemory initialized: session={session_id}")
    
    async def process(self, message: str, role: str = "user") -> ProcessResult:
        """
        Process a message and update memory + state
        
        This is the main entry point for the SDK.
        
        Args:
            message: The message to process
            role: "user" or "assistant"
            
        Returns:
            ProcessResult with entities, state, changes, and latency
        """
        start_time = time.perf_counter()
        
        # Build context from recent memory
        context = self._build_context()
        
        # Extract entities using LLM (with fallback)
        try:
            extraction = await self._llm_extractor.extract(message, context)
        except Exception as e:
            logger.warning(f"LLM extraction failed: {e}")
            if self.config.enable_fallback:
                extraction = await self._regex_extractor.extract(message, context)
            else:
                raise
        
        # Skip state update for noise messages
        changes = []
        if not extraction.is_noise:
            # Update state
            self._state, changes = self._state_manager.update(
                self._state,
                extraction
            )
            
            # Add to memory
            self._add_to_memory(message, role, extraction)
            
            # Extract user info if present
            self._extract_user_info(extraction)
        
        # Calculate latency
        latency_ms = int((time.perf_counter() - start_time) * 1000)
        self._latencies.append(latency_ms)
        
        if self.config.enable_metrics:
            logger.debug(f"Process latency: {latency_ms}ms")
        
        return ProcessResult(
            entities=extraction.entities,
            state=self._state,
            is_noise=extraction.is_noise,
            is_change=extraction.is_change,
            changes=changes,
            intent=extraction.intent,
            confidence=extraction.confidence,
            latency_ms=latency_ms,
        )
    
    def _build_context(self) -> str:
        """Build context string from recent memory"""
        if not self._memory:
            return "Đây là tin nhắn đầu tiên trong cuộc hội thoại."
        
        recent = list(self._memory)[-self.config.max_context_window:]
        
        lines = []
        for item in recent:
            role_label = "User" if item.role == "user" else "Bot"
            lines.append(f"{role_label}: {item.content}")
        
        # Add current state summary
        if self._state.slots:
            state_str = ", ".join(f"{k}={v}" for k, v in self._state.slots.items())
            lines.append(f"Current booking: {state_str}")
        
        return "\n".join(lines)
    
    def _add_to_memory(
        self,
        message: str,
        role: str,
        extraction: ExtractionResult
    ):
        """Add message to working memory"""
        item = MemoryItem(
            content=message,
            key=f"{role}_{len(self._memory)}",
            role=role,
            metadata=MemoryMetadata(
                confidence=extraction.confidence,
                tags=list(extraction.entities.keys()),
            ),
        )
        self._memory.append(item)
    
    def _extract_user_info(self, extraction: ExtractionResult):
        """Extract and store user information"""
        user_fields = ["customer_name", "customer_phone"]
        for field in user_fields:
            if field in extraction.entities:
                self._user_memory[field] = extraction.entities[field]
    
    # ========================================================================
    # State Access
    # ========================================================================
    
    @property
    def state(self) -> BookingState:
        """Get current booking state"""
        return self._state
    
    @property
    def memory(self) -> List[MemoryItem]:
        """Get all memory items"""
        return list(self._memory)
    
    @property
    def user_memory(self) -> dict:
        """Get user persistent memory"""
        return self._user_memory.copy()
    
    # ========================================================================
    # Metrics
    # ========================================================================
    
    def get_metrics(self) -> dict:
        """Get performance metrics"""
        if not self._latencies:
            return {"count": 0}
        
        sorted_latencies = sorted(self._latencies)
        
        return {
            "count": len(self._latencies),
            "avg_ms": sum(self._latencies) // len(self._latencies),
            "p50_ms": sorted_latencies[len(sorted_latencies) // 2],
            "p95_ms": sorted_latencies[int(len(sorted_latencies) * 0.95)],
            "max_ms": max(self._latencies),
        }
    
    # ========================================================================
    # Serialization
    # ========================================================================
    
    def to_dict(self) -> dict:
        """Export memory state for persistence"""
        return {
            "session_id": self.session_id,
            "customer_id": self.customer_id,
            "state": self._state.to_dict(),
            "memory": [item.to_dict() for item in self._memory],
            "user_memory": self._user_memory,
            "metrics": self.get_metrics(),
        }
    
    def load_state(self, state_dict: dict):
        """Load state from dict (e.g., from Redis)"""
        if "state" in state_dict:
            self._state = BookingState.from_dict(state_dict["state"])
        if "user_memory" in state_dict:
            self._user_memory = state_dict["user_memory"]
        if "memory" in state_dict:
            self._memory.clear()
            for item_dict in state_dict["memory"]:
                self._memory.append(MemoryItem.from_dict(item_dict))
