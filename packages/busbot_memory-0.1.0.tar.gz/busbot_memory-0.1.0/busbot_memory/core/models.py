"""Core data models for BusBot Memory SDK"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Dict, List, Optional
from enum import Enum


class Intent(str, Enum):
    """Possible user intents"""
    BOOK_TICKET = "book_ticket"
    CANCEL = "cancel"
    RESCHEDULE = "reschedule"
    INQUIRY = "inquiry"
    COMPLAINT = "complaint"
    CONFIRM = "confirm"
    GREETING = "greeting"
    UNCLEAR = "unclear"


@dataclass
class BookingState:
    """
    Structured booking state - tracks all slot values
    
    Example:
        state = BookingState(
            intent=Intent.BOOK_TICKET,
            slots={"destination": "Đà Nẵng", "time": "08:00"},
            missing_slots=["customer_name", "phone"]
        )
    """
    intent: str = Intent.UNCLEAR.value
    slots: Dict[str, Any] = field(default_factory=dict)
    missing_slots: List[str] = field(default_factory=list)
    confidence: float = 0.0
    last_updated: str = field(default_factory=lambda: datetime.now().isoformat())
    
    # Slot definitions for bus booking domain
    SLOT_TYPES = [
        "departure",       # Điểm đi
        "destination",     # Điểm đến
        "date",            # Ngày đi
        "time",            # Giờ đi
        "quantity",        # Số vé
        "seat_type",       # Loại ghế
        "customer_name",   # Tên khách
        "customer_phone",  # SĐT khách
    ]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "intent": self.intent,
            "slots": self.slots,
            "missing_slots": self.missing_slots,
            "confidence": self.confidence,
            "last_updated": self.last_updated,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BookingState":
        return cls(
            intent=data.get("intent", Intent.UNCLEAR.value),
            slots=data.get("slots", {}),
            missing_slots=data.get("missing_slots", []),
            confidence=data.get("confidence", 0.0),
            last_updated=data.get("last_updated", datetime.now().isoformat()),
        )
    
    def update_slots(self, new_slots: Dict[str, Any]) -> List[str]:
        """
        Update slots and return list of changes made
        
        Returns:
            List of change descriptions, e.g. ["destination: Hải Phòng → Đà Nẵng"]
        """
        changes = []
        for key, new_value in new_slots.items():
            if new_value is None:
                continue
            old_value = self.slots.get(key)
            if old_value != new_value:
                if old_value:
                    changes.append(f"{key}: {old_value} → {new_value}")
                else:
                    changes.append(f"{key}: {new_value}")
                self.slots[key] = new_value
                
                # Remove from missing if was missing
                if key in self.missing_slots:
                    self.missing_slots.remove(key)
        
        self.last_updated = datetime.now().isoformat()
        self._update_confidence()
        return changes
    
    def _update_confidence(self):
        """Calculate confidence based on filled slots"""
        filled = len(self.slots)
        total = filled + len(self.missing_slots)
        self.confidence = filled / total if total > 0 else 0.0


@dataclass
class MemoryMetadata:
    """Metadata for memory items"""
    memory_type: str = "working"  # working, user, long_term
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    confidence: float = 1.0
    source: str = "conversation"
    tags: List[str] = field(default_factory=list)
    usage_count: int = 0
    importance: float = 0.5
    is_obsolete: bool = False
    superseded_by: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class MemoryItem:
    """Single memory item in working memory"""
    id: str = field(default_factory=lambda: datetime.now().strftime("%Y%m%d%H%M%S%f"))
    content: str = ""
    key: str = ""
    role: str = "user"  # user, assistant
    metadata: MemoryMetadata = field(default_factory=MemoryMetadata)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "content": self.content,
            "key": self.key,
            "role": self.role,
            "metadata": self.metadata.to_dict(),
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryItem":
        metadata = MemoryMetadata(**data.get("metadata", {}))
        return cls(
            id=data.get("id", ""),
            content=data.get("content", ""),
            key=data.get("key", ""),
            role=data.get("role", "user"),
            metadata=metadata,
        )


@dataclass
class ExtractionResult:
    """Result from LLM entity extraction"""
    entities: Dict[str, Any] = field(default_factory=dict)
    intent: str = Intent.UNCLEAR.value
    is_noise: bool = False
    is_change: bool = False
    changed_fields: List[str] = field(default_factory=list)
    confidence: float = 0.0
    raw_response: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ProcessResult:
    """
    Final result from memory.process() call
    
    This is the main output that users of the SDK will work with.
    """
    entities: Dict[str, Any] = field(default_factory=dict)
    state: BookingState = field(default_factory=BookingState)
    is_noise: bool = False
    is_change: bool = False
    changes: List[str] = field(default_factory=list)
    intent: str = Intent.UNCLEAR.value
    confidence: float = 0.0
    latency_ms: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "entities": self.entities,
            "state": self.state.to_dict(),
            "is_noise": self.is_noise,
            "is_change": self.is_change,
            "changes": self.changes,
            "intent": self.intent,
            "confidence": self.confidence,
            "latency_ms": self.latency_ms,
        }
