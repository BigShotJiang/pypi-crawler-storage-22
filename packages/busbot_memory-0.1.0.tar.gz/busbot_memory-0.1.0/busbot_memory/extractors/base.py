"""Base extractor interface"""

from abc import ABC, abstractmethod
from typing import Optional
from busbot_memory.core.models import ExtractionResult


class BaseExtractor(ABC):
    """Abstract base class for entity extractors"""
    
    @abstractmethod
    async def extract(
        self,
        message: str,
        context: Optional[str] = None
    ) -> ExtractionResult:
        """
        Extract entities from message
        
        Args:
            message: User message to extract from
            context: Optional conversation context
            
        Returns:
            ExtractionResult with entities, intent, and flags
        """
        pass
