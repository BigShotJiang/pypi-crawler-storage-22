"""LLM-based entity extractor using Groq"""

import json
import logging
from typing import Optional

from busbot_memory.extractors.base import BaseExtractor
from busbot_memory.core.models import ExtractionResult
from busbot_memory.core.config import BusBotConfig

logger = logging.getLogger(__name__)


# Optimized prompt for Vietnamese bus booking - compact for low latency
EXTRACTION_PROMPT = """Bạn là NLU system cho đặt vé xe Việt Nam. Extract thông tin từ tin nhắn.

OUTPUT JSON:
{
  "entities": {
    "departure": "điểm đi nếu có",
    "destination": "điểm đến nếu có", 
    "date": "YYYY-MM-DD hoặc 'ngày mai'/'hôm nay' nếu có",
    "time": "HH:MM nếu có (8 giờ sáng = 08:00, 2 giờ chiều = 14:00)",
    "quantity": số nguyên nếu có,
    "seat_type": "ghế ngồi|giường nằm|limousine nếu có",
    "customer_name": "họ tên nếu có",
    "customer_phone": "số điện thoại nếu có"
  },
  "intent": "book_ticket|cancel|reschedule|inquiry|complaint|confirm|greeting|unclear",
  "is_noise": true nếu chỉ là filler ("ừ","ok","dạ","chờ xíu"),
  "is_change": true nếu đổi thông tin đã cung cấp trước đó,
  "changed_fields": ["field1"] nếu is_change=true,
  "confidence": 0.0-1.0
}

RULES:
- Chỉ điền field nếu có info, bỏ null
- is_noise=true với câu filler vô nghĩa
- Chỉ trả JSON, không giải thích

CONTEXT: {context}
MESSAGE: {message}"""


class LLMExtractor(BaseExtractor):
    """
    LLM-based entity extractor using Groq (primary) or OpenAI (fallback)
    
    Example:
        extractor = LLMExtractor(config)
        result = await extractor.extract("đặt 2 vé đi đà nẵng ngày mai")
    """
    
    def __init__(self, config: BusBotConfig):
        self.config = config
        self._groq_client = None
        self._openai_client = None
    
    @property
    def groq_client(self):
        """Lazy init Groq client"""
        if self._groq_client is None and self.config.groq_api_key:
            try:
                from groq import AsyncGroq
                self._groq_client = AsyncGroq(api_key=self.config.groq_api_key)
            except ImportError:
                logger.warning("groq package not installed")
        return self._groq_client
    
    @property
    def openai_client(self):
        """Lazy init OpenAI client"""
        if self._openai_client is None and self.config.openai_api_key:
            try:
                from openai import AsyncOpenAI
                self._openai_client = AsyncOpenAI(api_key=self.config.openai_api_key)
            except ImportError:
                logger.warning("openai package not installed")
        return self._openai_client
    
    async def extract(
        self,
        message: str,
        context: Optional[str] = None
    ) -> ExtractionResult:
        """
        Extract entities using Groq LLM
        
        Falls back to OpenAI if Groq fails and openai_api_key is configured.
        """
        try:
            return await self._extract_with_groq(message, context)
        except Exception as e:
            logger.warning(f"Groq extraction failed: {e}")
            
            if self.openai_client:
                logger.info("Falling back to OpenAI")
                return await self._extract_with_openai(message, context)
            
            raise
    
    async def _extract_with_groq(
        self,
        message: str,
        context: Optional[str] = None
    ) -> ExtractionResult:
        """Extract using Groq"""
        if not self.groq_client:
            raise RuntimeError("Groq client not available")
        
        prompt = EXTRACTION_PROMPT.format(
            message=message,
            context=context or "Không có context"
        )
        
        try:
            response = await self.groq_client.chat.completions.create(
                model=self.config.groq_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=500,
                response_format={"type": "json_object"},
            )
            
            raw = response.choices[0].message.content
            return self._parse_response(raw)
            
        except Exception as e:
            # Try fallback model
            logger.warning(f"Primary model failed, trying fallback: {e}")
            
            response = await self.groq_client.chat.completions.create(
                model=self.config.groq_fallback_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=500,
            )
            
            raw = response.choices[0].message.content
            return self._parse_response(raw)
    
    async def _extract_with_openai(
        self,
        message: str,
        context: Optional[str] = None
    ) -> ExtractionResult:
        """Extract using OpenAI"""
        if not self.openai_client:
            raise RuntimeError("OpenAI client not available")
        
        prompt = EXTRACTION_PROMPT.format(
            message=message,
            context=context or "Không có context"
        )
        
        response = await self.openai_client.chat.completions.create(
            model=self.config.openai_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
            max_tokens=500,
            response_format={"type": "json_object"},
        )
        
        raw = response.choices[0].message.content
        return self._parse_response(raw)
    
    def _parse_response(self, raw: str) -> ExtractionResult:
        """Parse LLM response into ExtractionResult"""
        try:
            # Clean up response if needed
            raw = raw.strip()
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            
            data = json.loads(raw)
            
            # Extract entities, removing null values
            entities = {k: v for k, v in data.get("entities", {}).items() if v is not None}
            
            return ExtractionResult(
                entities=entities,
                intent=data.get("intent", "unclear"),
                is_noise=data.get("is_noise", False),
                is_change=data.get("is_change", False),
                changed_fields=data.get("changed_fields", []),
                confidence=data.get("confidence", 0.5),
                raw_response=raw,
            )
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse LLM response: {e}\nRaw: {raw}")
            return ExtractionResult(
                confidence=0.0,
                raw_response=raw,
            )
