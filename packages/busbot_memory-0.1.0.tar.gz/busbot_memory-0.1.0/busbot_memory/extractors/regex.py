"""Regex-based entity extractor (fallback)"""

import re
from typing import Optional

from busbot_memory.extractors.base import BaseExtractor
from busbot_memory.core.models import ExtractionResult


# Vietnam provinces/cities
LOCATIONS = (
    r"Hà Nội|Hải Phòng|Hải Dương|Nam Định|Ninh Bình|Thái Bình|Vĩnh Phúc|Bắc Ninh|"
    r"Bắc Giang|Quảng Ninh|Lạng Sơn|Cao Bằng|Hòa Bình|Sơn La|Lai Châu|Điện Biên|"
    r"Lào Cai|Yên Bái|Phú Thọ|Tuyên Quang|Thái Nguyên|Hà Giang|Sài Gòn|TP HCM|"
    r"TP\.?\s*HCM|Hồ Chí Minh|Đà Nẵng|Huế|Quảng Nam|Quảng Ngãi|Bình Định|Phú Yên|"
    r"Khánh Hòa|Nha Trang|Ninh Thuận|Bình Thuận|Đà Lạt|Lâm Đồng|Bình Phước|Tây Ninh|"
    r"Bình Dương|Đồng Nai|Vũng Tàu|Bà Rịa|Long An|Tiền Giang|Mỹ Tho|Bến Tre|Trà Vinh|"
    r"Vĩnh Long|Cần Thơ|Đồng Tháp|An Giang|Kiên Giang|Hậu Giang|Sóc Trăng|Bạc Liêu|"
    r"Cà Mau|Nghệ An|Vinh|Hà Tĩnh|Quảng Bình|Quảng Trị|Kon Tum|Gia Lai|Đắk Lắk|"
    r"Đắk Nông|Buôn Ma Thuột"
)

PATTERNS = {
    "location": rf"\b({LOCATIONS})\b",
    "time": r"\b(\d{1,2})\s*(?:h|giờ|:|g)\s*(\d{0,2})\b",
    "date": r"(ngày mai|hôm nay|hôm qua|ngày kia|\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?)",
    "phone": r"\b(0\d{9}|0\d{3}[\s.-]?\d{3}[\s.-]?\d{3,4})\b",
    "quantity": r"\b(\d+)\s*(vé|ghế|chỗ|người|suất)\b",
    "seat_type": r"\b(ghế ngồi|giường nằm|limousine|vip|thường)\b",
}

NOISE_PATTERNS = [
    r"^(ừ|uh|à|ờ|dạ|vâng|ok|được|rồi|nhé|nha)\s*$",
    r"^(xin chào|chào|hello|hi|alo)\s*",
    r"^(cảm ơn|thanks|thank you)\s*$",
]

INTENT_KEYWORDS = {
    "book_ticket": ["đặt", "mua", "lấy", "book"],
    "cancel": ["hủy", "cancel", "không đi nữa"],
    "reschedule": ["đổi", "chuyển", "thay đổi", "dời"],
    "inquiry": ["hỏi", "giá", "mấy giờ", "còn không", "bao nhiêu"],
    "complaint": ["khiếu nại", "phàn nàn", "tệ", "chán"],
    "confirm": ["xác nhận", "đồng ý", "ok", "được"],
}


class RegexExtractor(BaseExtractor):
    """
    Regex-based entity extractor
    
    Used as fallback when LLM is unavailable or fails.
    Lower accuracy but zero latency and no API costs.
    """
    
    async def extract(
        self,
        message: str,
        context: Optional[str] = None
    ) -> ExtractionResult:
        """Extract entities using regex patterns"""
        entities = {}
        
        # Extract locations
        locations = re.findall(PATTERNS["location"], message, re.IGNORECASE)
        if locations:
            # First location = destination (simplified logic)
            entities["destination"] = locations[0]
            if len(locations) > 1:
                entities["departure"] = locations[1]
        
        # Extract time
        time_match = re.search(PATTERNS["time"], message, re.IGNORECASE)
        if time_match:
            hour = time_match.group(1)
            minute = time_match.group(2) or "00"
            # Simple AM/PM detection
            if "chiều" in message or "tối" in message:
                hour = str(int(hour) + 12) if int(hour) < 12 else hour
            entities["time"] = f"{int(hour):02d}:{int(minute):02d}"
        
        # Extract date
        date_match = re.search(PATTERNS["date"], message, re.IGNORECASE)
        if date_match:
            entities["date"] = date_match.group(1)
        
        # Extract phone
        phone_match = re.search(PATTERNS["phone"], message)
        if phone_match:
            entities["customer_phone"] = phone_match.group(1).replace(" ", "").replace("-", "")
        
        # Extract quantity
        qty_match = re.search(PATTERNS["quantity"], message)
        if qty_match:
            entities["quantity"] = int(qty_match.group(1))
        
        # Extract seat type
        seat_match = re.search(PATTERNS["seat_type"], message, re.IGNORECASE)
        if seat_match:
            entities["seat_type"] = seat_match.group(1).lower()
        
        # Check if noise
        is_noise = any(
            re.match(pattern, message.strip(), re.IGNORECASE)
            for pattern in NOISE_PATTERNS
        )
        
        # Detect intent
        intent = self._detect_intent(message)
        
        return ExtractionResult(
            entities=entities,
            intent=intent,
            is_noise=is_noise,
            is_change=False,  # Regex can't detect change-of-mind reliably
            changed_fields=[],
            confidence=0.7 if entities else 0.3,
        )
    
    def _detect_intent(self, message: str) -> str:
        """Simple keyword-based intent detection"""
        message_lower = message.lower()
        
        for intent, keywords in INTENT_KEYWORDS.items():
            if any(kw in message_lower for kw in keywords):
                return intent
        
        return "unclear"
