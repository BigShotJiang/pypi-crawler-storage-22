"""State management for booking flow"""

import logging
from typing import Optional, Tuple, List

from busbot_memory.core.models import BookingState, ExtractionResult

logger = logging.getLogger(__name__)


class StateManager:
    """
    Manages booking state updates
    
    Handles:
    - Merging new entities into state
    - Tracking changes (change-of-mind)
    - Managing missing slots
    """
    
    # Default slots to track for bus booking
    DEFAULT_SLOTS = [
        "departure",
        "destination", 
        "date",
        "time",
        "quantity",
        "seat_type",
        "customer_name",
        "customer_phone",
    ]
    
    def __init__(self, slot_types: Optional[List[str]] = None):
        self.slot_types = slot_types or self.DEFAULT_SLOTS
    
    def update(
        self,
        current_state: BookingState,
        extraction: ExtractionResult
    ) -> Tuple[BookingState, List[str]]:
        """
        Update state with extracted entities
        
        Args:
            current_state: Current booking state
            extraction: Extraction result from LLM/regex
            
        Returns:
            Tuple of (updated_state, list_of_changes)
        """
        # Update intent if detected
        if extraction.intent and extraction.intent != "unclear":
            current_state.intent = extraction.intent
        
        # Update slots
        changes = current_state.update_slots(extraction.entities)
        
        # Track changes from LLM change-of-mind detection
        if extraction.is_change and extraction.changed_fields:
            for field in extraction.changed_fields:
                if field not in [c.split(":")[0] for c in changes]:
                    changes.append(f"{field}: changed")
        
        # Update missing slots
        current_state.missing_slots = self._calculate_missing_slots(current_state)
        
        logger.debug(f"State updated: {len(changes)} changes, {len(current_state.missing_slots)} missing")
        
        return current_state, changes
    
    def _calculate_missing_slots(self, state: BookingState) -> List[str]:
        """Calculate which slots are still missing"""
        # For booking intent, we need certain slots
        if state.intent == "book_ticket":
            required = ["destination", "date", "time", "quantity", "customer_name", "customer_phone"]
        elif state.intent == "reschedule":
            required = ["date", "time"]
        elif state.intent == "cancel":
            required = ["customer_phone"]
        else:
            required = ["destination"]
        
        missing = [slot for slot in required if slot not in state.slots]
        return missing
    
    def create_initial_state(self) -> BookingState:
        """Create a fresh booking state"""
        return BookingState(
            missing_slots=self._calculate_missing_slots(BookingState())
        )
