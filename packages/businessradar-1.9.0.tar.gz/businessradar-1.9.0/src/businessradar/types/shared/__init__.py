# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .portfolio_company_detail_request import PortfolioCompanyDetailRequest as PortfolioCompanyDetailRequest
