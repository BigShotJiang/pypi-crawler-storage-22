"""Developer-mode SDK authentication helpers.

This package is intentionally local-only and stores auth material in plaintext
under the user's home directory for development convenience.
"""
