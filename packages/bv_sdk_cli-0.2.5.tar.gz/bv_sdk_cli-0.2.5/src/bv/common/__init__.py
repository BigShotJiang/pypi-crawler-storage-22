"""Common utilities for Bot Velocity SDK."""

from bv.common.url_resolver import BaseUrlResolver

__all__ = ["BaseUrlResolver"]
