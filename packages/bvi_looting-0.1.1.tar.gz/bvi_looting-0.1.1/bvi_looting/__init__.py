"""
bvi_looting — клиент к боту для решения олимпиадных задач по информатике.
Отправляйте задачи на удалённый сервер; решения сохраняются в .txt на сервере,
контекст и история хранятся в сессии.
"""
from bvi_looting.client import BviLootingClient

__all__ = ["BviLootingClient"]
__version__ = "0.1.1"
