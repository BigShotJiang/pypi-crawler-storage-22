"""
Клиент к серверу BVI Looting Bot.
Хранит session_id для контекста и предоставляет методы solve() и get_history().
"""
import requests
from typing import Optional
from uuid import uuid4


class BviLootingClient:
    """
    Клиент к боту на удалённом сервере.
    Использование:
        client = BviLootingClient(base_url="https://your-server.com")
        result = client.solve("Даны два числа a, b. Найти сумму.")
        print(result["code"], result["explanation"])
        history = client.get_history()
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        session_id: Optional[str] = None,
        password: Optional[str] = None,
        timeout: int = 120,
    ):
        self.base_url = base_url.rstrip("/")
        self.session_id = session_id or str(uuid4())
        self.password = password
        self.timeout = timeout

    def _headers(self) -> dict:
        h = {}
        if self.password:
            h["Authorization"] = f"Bearer {self.password}"
        return h

    def solve(
        self,
        task: str,
        lang: str = "python",
    ) -> dict:
        """
        Отправить задачу на сервер, получить код и пояснение.
        Сервер сохранит решение в .txt и обновит историю сессии.
        Возвращает: {"session_id", "code", "explanation", "solution_file"}.
        """
        url = f"{self.base_url}/solve"
        payload = {
            "task": task,
            "session_id": self.session_id,
            "lang": lang,
        }
        r = requests.post(url, json=payload, headers=self._headers(), timeout=self.timeout)
        r.raise_for_status()
        data = r.json()
        self.session_id = data.get("session_id", self.session_id)
        return {
            "session_id": self.session_id,
            "code": data.get("code", ""),
            "explanation": data.get("explanation", ""),
            "solution_file": data.get("solution_file", ""),
        }

    def get_history(self, session_id: Optional[str] = None) -> dict:
        """
        Получить историю запросов с сервера.
        Если session_id не передан — используется текущая сессия клиента.
        """
        url = f"{self.base_url}/history"
        params = {}
        if session_id is not None:
            params["session_id"] = session_id
        else:
            params["session_id"] = self.session_id
        r = requests.get(url, params=params, headers=self._headers(), timeout=self.timeout)
        r.raise_for_status()
        return r.json()

    def health(self) -> bool:
        """Проверить доступность сервера (с учётом пароля)."""
        try:
            r = requests.get(f"{self.base_url}/health", headers=self._headers(), timeout=5)
            return r.status_code == 200
        except Exception:
            return False
