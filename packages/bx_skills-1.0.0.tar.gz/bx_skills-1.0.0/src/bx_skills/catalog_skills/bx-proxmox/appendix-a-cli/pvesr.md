# pvesr - Storage Replication

*[Chapter Index](_index.md) | [Main Index](../SKILL.md)*

<id>: [1-9][0-9]{2,8}-\d{1,9}
Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e.
<GUEST>-<JOBNUM>.

- `--force` <boolean> (default = 0)
Will remove the jobconfig entry, but will not cleanup.

- `--keep` <boolean> (default = 0)
Keep replicated data at target (do not remove).

```
pvesr disable <id>
```

Disable a replication job.

<id>: [1-9][0-9]{2,8}-\d{1,9}
Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e.
<GUEST>-<JOBNUM>.

```
pvesr enable <id>
```

Enable a replication job.

<id>: [1-9][0-9]{2,8}-\d{1,9}
Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e.
<GUEST>-<JOBNUM>.

```
pvesr finalize-local-job <id> [<extra-args>] [OPTIONS]
```

Finalize a replication job. This removes all replications snapshots with timestamps different than <last_sync>.

<id>: [1-9][0-9]{2,8}-\d{1,9}
Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e.
<GUEST>-<JOBNUM>.

<extra-args>: <array>
The list of volume IDs to consider.

- `--last_sync` <integer> (0 - N)
Time (UNIX epoch) of last successful sync. If not specified, all replication snapshots gets removed.

```
pvesr help [OPTIONS]
```

Get help about specified command.

- `--extra-args` <array>
Shows help for a specific command


- `--verbose` <boolean>
Verbose output format.

```
pvesr list
```

List replication jobs.

```
pvesr prepare-local-job <id> [<extra-args>] [OPTIONS]
```

Prepare for starting a replication job. This is called on the target node before replication starts. This call
is for internal use, and return a JSON object on stdout. The method first test if VM <vmid> reside on the
local node. If so, stop immediately. After that the method scans all volume IDs for snapshots, and removes
all replications snapshots with timestamps different than <last_sync>. It also removes any unused volumes.
Returns a hash with boolean markers for all volumes with existing replication snapshots.

<id>: [1-9][0-9]{2,8}-\d{1,9}
Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e.
<GUEST>-<JOBNUM>.

<extra-args>: <array>
The list of volume IDs to consider.

- `--force` <boolean> (default = 0)
Allow to remove all existion volumes (empty volume list).

- `--last_sync` <integer> (0 - N)
Time (UNIX epoch) of last successful sync. If not specified, all replication snapshots get removed.

- `--parent_snapname` <string>
The name of the snapshot.

- `--scan` <string>
List of storage IDs to scan for stale volumes.

```
pvesr read <id>
```

Read replication job configuration.

<id>: [1-9][0-9]{2,8}-\d{1,9}
Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e.
<GUEST>-<JOBNUM>.

```
pvesr run [OPTIONS]
```

This method is called by the systemd-timer and executes all (or a specific) sync jobs.

- `--id` [1-9][0-9]{2,8}-\d{1,9}
Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e.
<GUEST>-<JOBNUM>.


- `--mail` <boolean> (default = 0)
Send an email notification in case of a failure.

- `--verbose` <boolean> (default = 0)
Print more verbose logs to stdout.

```
pvesr schedule-now <id>
```

Schedule replication job to start as soon as possible.

<id>: [1-9][0-9]{2,8}-\d{1,9}
Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e.
<GUEST>-<JOBNUM>.

```
pvesr set-state <vmid> <state>
```

Set the job replication state on migration. This call is for internal use. It will accept the job state as ja JSON
obj.

<vmid>: <integer> (100 - 999999999)
The (unique) ID of the VM.

<state>: <string>
Job state as JSON decoded string.

```
pvesr status [OPTIONS]
```

List status of all replication jobs on this node.

- `--guest` <integer> (100 - 999999999)
Only list replication jobs for this guest.

```
pvesr update <id> [OPTIONS]
```

Update replication job configuration.

<id>: [1-9][0-9]{2,8}-\d{1,9}
Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e.
<GUEST>-<JOBNUM>.

- `--comment` <string>
Description.

- `--delete` <string>
A list of settings you want to delete.


- `--digest` <string>
Prevent changes if current configuration file has a different digest. This can be used to prevent concurrent modifications.

- `--disable` <boolean>
Flag to disable/deactivate the entry.

- `--rate` <number> (1 - N)
Rate limit in mbps (megabytes per second) as floating point number.

- `--remove_job` <full | local>
Mark the replication job for removal. The job will remove all local replication snapshots. When set
to full, it also tries to remove replicated volumes on the target. The job then removes itself from the
configuration file.

- `--schedule` <string> (default = */15)
Storage replication schedule. The format is a subset of systemd calendar events.

- `--source` <string>
For internal use, to detect if the guest was stolen.

A.15


```
pveum - Proxmox VE User Manager
```


```
pveum <COMMAND> [ARGS] [OPTIONS]
```


```
pveum acl delete <path> --roles <string> [OPTIONS]
```

Update Access Control List (add or remove permissions).

<path>: <string>
Access control path

- `--groups` <string>
List of groups.

- `--propagate` <boolean> (default = 1)
Allow to propagate (inherit) permissions.

- `--roles` <string>
List of roles.

- `--tokens` <string>
List of API tokens.

- `--users` <string>
List of users.

## See also

- [Storage Replication](../ch09-storage-replication.md)

