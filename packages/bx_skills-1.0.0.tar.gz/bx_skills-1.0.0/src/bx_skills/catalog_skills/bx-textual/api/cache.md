*API reference: `textual.cache`*
