*API reference: `textual.constants`*
