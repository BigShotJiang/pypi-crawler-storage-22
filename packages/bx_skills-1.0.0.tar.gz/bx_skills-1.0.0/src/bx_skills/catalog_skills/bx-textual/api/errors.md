*API reference: `textual.errors`*
