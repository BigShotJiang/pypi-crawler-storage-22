*API reference: `textual.filter`*
