*API reference: `textual.timer`*
