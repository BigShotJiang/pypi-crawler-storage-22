*API reference: `textual.types`*
