*API reference: `textual.walk`*
