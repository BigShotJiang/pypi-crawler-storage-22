from .config import Config
from .singleton import SingletonConfig

__all__ = ["Config", "SingletonConfig"]
