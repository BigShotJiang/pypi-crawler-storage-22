from .lenet import B_LeNet5_Paper
from .alexnet import B_AlexNet_Paper
from .nin import B_NiN_Paper_CIFAR, B_NiN_Paper_ImageNet
from .vgg import B_VGG11_Paper, B_VGG13_Paper, B_VGG16_Paper, B_VGG19_Paper

__all__ = [
    'B_LeNet5_Paper',
    'B_AlexNet_Paper',
    'B_NiN_Paper_CIFAR', 'B_NiN_Paper_ImageNet',
    'B_VGG11_Paper', 'B_VGG13_Paper', 'B_VGG16_Paper', 'B_VGG19_Paper'
]