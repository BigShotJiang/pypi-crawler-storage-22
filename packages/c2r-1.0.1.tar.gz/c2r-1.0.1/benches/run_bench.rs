use c2r_core::bench_harness;

fn main() {
    bench_harness::run_benchmark();
}
