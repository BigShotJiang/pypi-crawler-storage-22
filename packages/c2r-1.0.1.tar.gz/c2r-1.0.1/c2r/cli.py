import click
import os
import sys
import shutil
import json
import subprocess
from pathlib import Path

# Try to import the Rust extension
try:
    import c2r_core as c2r
except ImportError:
    # If not installed via maturin/pip, try local build for dev
    sys.path.append(os.getcwd())
    try:
        import c2r_core as c2r
    except ImportError:
        print("Error: c2r_core Rust extension not found.")
        print("Please run `maturin develop` or `cargo build`.")
        if os.path.exists("c2r_core.so"):
             import c2r_core as c2r
        else:
             print("Critical: Rust backend missing.")

@click.group()
def main():
    """Ferrum: Industrial C++ to Rust Transpiler"""
    pass

@main.command()
@click.argument('input_path', type=click.Path(exists=True))
@click.option('-o', '--output', 'output_path', type=click.Path(), required=True, help="Output directory for the Rust project")
def migrate(input_path, output_path):
    """Migrate a C++ project or file to a Rust Cargo project."""

    input_path = Path(input_path)
    output_path = Path(output_path)

    click.echo(f"🚀 Starting Migration: {input_path} -> {output_path}")

    try:
        c2r.init_logging()
    except:
        pass

    reconstructor = c2r.Reconstructor()

    if not output_path.exists():
        output_path.mkdir(parents=True)
        click.echo(f"Created output directory: {output_path}")

    src_dir = output_path / "src"
    src_dir.mkdir(exist_ok=True)

    models_dir = src_dir / "models"
    models_dir.mkdir(exist_ok=True)

    utils_dir = src_dir / "utils"
    utils_dir.mkdir(exist_ok=True)

    tests_dir = output_path / "tests"
    tests_dir.mkdir(exist_ok=True)

    # Updated Cargo.toml template with production crates
    cargo_toml = f"""[package]
name = "{output_path.name}"
version = "0.1.0"
edition = "2021"

[dependencies]
parking_lot = "0.12"
serde = {{ version = "1.0", features = ["derive"] }}
serde_json = "1.0"
thiserror = "1.0"
tokio = {{ version = "1", features = ["full"] }}
anyhow = "1.0"
lazy_static = "1.4"
"""
    with open(output_path / "Cargo.toml", "w") as f:
        f.write(cargo_toml)
    click.echo("Generated Cargo.toml")

    files_to_process = []
    if input_path.is_file():
        files_to_process.append(input_path)
    else:
        files_to_process.extend(input_path.glob("**/*.cpp"))
        files_to_process.extend(input_path.glob("**/*.h"))

    main_rs_content = "// Ferrum Generated Main Entry\n\nfn main() {\n    println!(\"Hello from Ferrum migrated code!\");\n}\n"

    total_safety_score = 0
    file_count = 0
    report_lines = []

    for cpp_file in files_to_process:
        click.echo(f"Processing {cpp_file.name}...")
        with open(cpp_file, "r") as f:
            code = f.read()

        # Use new analyze_report API
        json_report = reconstructor.analyze_report(code)
        report = json.loads(json_report)
        rust_code = report["generated_code"]
        safety_score = report["safety_score"]
        unsafe_events = report["unsafe_events"]

        total_safety_score += safety_score
        file_count += 1

        report_lines.append(f"## {cpp_file.name}")
        report_lines.append(f"- **Safety Score:** {safety_score:.2f}%")
        if unsafe_events:
            report_lines.append("- **Risks Detected:**")
            for event in unsafe_events:
                report_lines.append(f"  - ⚠️ {event}")
        else:
            report_lines.append("- **Status:** Clean")
        report_lines.append("")

        # Heuristic: if file is named main.cpp, it's main.rs
        if "main" in cpp_file.name.lower():
            main_rs_content = rust_code
        else:
            model_name = cpp_file.stem.lower() + ".rs"
            with open(models_dir / model_name, "w") as f:
                f.write(rust_code)
            click.echo(f"  -> Generated models/{model_name}")

    with open(src_dir / "main.rs", "w") as f:
        f.write(main_rs_content)
    click.echo("Generated src/main.rs")

    # Generate Formal Report
    avg_score = total_safety_score / file_count if file_count > 0 else 100.0
    report_content = f"""# Migration Report: {input_path.name}

**Total Files:** {file_count}
**Average Safety Score:** {avg_score:.2f}%

{chr(10).join(report_lines)}
"""
    with open(output_path / "migration_report.md", "w") as f:
        f.write(report_content)
    click.echo("Generated migration_report.md")

    click.echo("\n✅ Migration Complete. Your Rust project is ready.")
    click.echo(f"Run: cd {output_path} && cargo build")

@main.command()
@click.argument('input_path', type=click.Path(exists=True))
def analyze(input_path):
    """Analyze a C++ project without generating code."""
    input_path = Path(input_path)
    click.echo(f"🔍 Analyzing: {input_path}")

    try:
        c2r.init_logging()
    except:
        pass

    reconstructor = c2r.Reconstructor()

    files = []
    if input_path.is_file():
        files.append(input_path)
    else:
        files.extend(input_path.glob("**/*.cpp"))

    for cpp_file in files:
        click.echo(f"\n📄 {cpp_file.name}")
        with open(cpp_file, "r") as f:
            code = f.read()

        json_report = reconstructor.analyze_report(code)
        report = json.loads(json_report)

        score = report["safety_score"]
        click.echo(f"  Safety Score: {score:.2f}%")

        if report["unsafe_events"]:
            for risk in report["unsafe_events"]:
                click.echo(f"  🔴 RISK: {risk}")
        else:
            click.echo("  ✅ No critical risks detected.")

if __name__ == '__main__':
    main()
