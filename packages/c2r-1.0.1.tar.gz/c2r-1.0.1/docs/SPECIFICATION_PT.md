# O Reconstrutor de Propriedade: Validação Teórica e Algorítmica da Transpilação Determinística de C++ para Rust

## Resumo Executivo

A transição da infraestrutura de software de sistemas legados em C++ para Rust representa um desafio de engenharia que transcende a mera tradução sintática; exige uma rearquitetura fundamental dos paradigmas de gerenciamento de memória. Enquanto C++ opera sob um modelo de acesso permissivo, caracterizado por aritmética de ponteiros irrestrita e gerenciamento manual de recursos, Rust impõe um sistema de tipos afim rigoroso, onde a propriedade (ownership), o empréstimo (borrowing) e os tempos de vida (lifetimes) são verificados estaticamente em tempo de compilação. Este relatório apresenta a especificação técnica e a validação teórica do "Reconstrutor de Propriedade", um sistema de transpilação determinístico projetado para converter código C++ em Rust seguro e idiomaticamente disciplinado, sem recorrer a modelos estocásticos de Inteligência Artificial.

O sistema proposto opera através de quatro fases algorítmicas distintas: Ingestão Semântica, Rastreamento de Vida, Inferência de Contrato e Tradução Rigorosa. O objetivo central é reconstruir a intenção latente de gerenciamento de memória — distinguindo deterministicamente entre transferência de propriedade, acesso compartilhado e mutabilidade exclusiva. A análise demonstra que, embora a indecidibilidade da análise de aliasing estático imponha limites teóricos absolutos à segurança garantida, a aplicação combinada de algoritmos de inferência de regiões (Tofte-Talpin), análise de ponteiros interprocedural (Andersen/Steensgaard) e estruturas de "Split Trees" permite a geração de um "Mapeador de Ciclo de Vida" robusto. Este mapeador isola o código inseguro residual em fronteiras explícitas, mitigando a "explosão de unsafe" típica de transpiladores sintáticos como o C2Rust.

## 1. Introdução: O Imperativo Determinístico e o Abismo Semântico

No cenário atual de desenvolvimento de sistemas críticos, a segurança de memória não é mais uma funcionalidade opcional, mas um requisito fundamental. Estatísticas da indústria indicam consistentemente que aproximadamente 70% das vulnerabilidades de segurança em grandes bases de código C/C++ derivam de erros de gerenciamento de memória, como use-after-free, double-free e buffer overflows. Rust emerge como a solução definitiva para esta classe de erros, oferecendo garantias de segurança em tempo de compilação sem o custo de desempenho de um Garbage Collector (GC).

Contudo, a migração manual de bases de código C++ legadas, que frequentemente ultrapassam milhões de linhas, é econômica e logisticamente inviável. As abordagens existentes para automação falham em dois extremos: transpiladores baseados em regras sintáticas, como o C2Rust, preservam a semântica insegura do C++, gerando código Rust repleto de blocos unsafe e ponteiros brutos (*mut T), o que anula os benefícios da migração. No outro extremo, abordagens experimentais baseadas em Grandes Modelos de Linguagem (LLMs), como o Laertes, introduzem incerteza estocástica, alucinações de código e falta de garantias formais, tornando-as inadequadas para sistemas de alta integridade.

O "Reconstrutor de Propriedade" estabelece uma terceira via: uma abordagem puramente algorítmica e determinística. O sistema não "adivinha" a intenção do programador; ele a deduz através da resolução de restrições lógicas impostas pelo grafo de fluxo de dados do programa original. O desafio não é linguístico, mas topológico: trata-se de mapear o grafo arbitrário e cíclico de objetos do C++ para a árvore estrita de propriedade única do Rust.

### 1.1 O Escopo do Problema: Do Caos à Disciplina

O código C++ é frequentemente descrito como "caótico" não por falta de estrutura sintática, mas pela permissividade de seu modelo de memória. Um ponteiro T* em C++ carrega uma ambiguidade semântica profunda. Ele pode representar:

*   **Proprietário Único**: O detentor deve chamar delete (equivalente a Box<T>).
*   **Referência Compartilhada**: O detentor apenas observa o dado (equivalente a &T ou Rc<T>).
*   **Iterador de Array**: O ponteiro é usado para aritmética (equivalente a & ou Iter).
*   **Opcionalidade**: O ponteiro pode ser nulo (equivalente a Option<&T>).

O "Reconstrutor" deve, portanto, realizar uma reificação de tipos, elevando esses ponteiros ambíguos a tipos Rust concretos e seguros. Este processo enfrenta obstáculos teóricos formidáveis, notadamente a indecidibilidade da análise de aliasing e a complexidade do mapeamento de herança de classes para composição de traits. O objetivo deste relatório é validar a viabilidade deste "Mapeador de Ciclo de Vida", detalhando os algoritmos necessários para superar cada obstáculo.

## 2. Ingestão e Construção do Grafo de Ciclo de Vida

A fase inicial, denominada Ingestão, transcende o parsing tradicional. O objetivo não é gerar uma Árvore de Sintaxe Abstrata (AST) para compilação, mas sim construir um Grafo de Dependência de Programa (PDG) enriquecido, que capture a história e a proveniência de cada alocação de memória.

### 2.1 Representação Intermediária Orientada a Propriedade (PIIR)

Para realizar a tradução rigorosa, o sistema deve levantar o código C++ para uma Representação Intermediária Orientada a Propriedade (PIIR). Nesta representação, cada nó não é uma instrução, mas um "Evento de Vida" (Alocação, Movimentação, Empréstimo, Mutação, Desalocação).

A PIIR deve lidar explicitamente com o paradigma RAII (Resource Acquisition Is Initialization) do C++. Em C++, os destrutores são chamados deterministicamente ao final do escopo. O Reconstrutor mapeia isso para a trait Drop do Rust. No entanto, o fluxo de controle implícito gerado por exceções em C++ deve ser materializado na PIIR. Enquanto C++ permite que exceções desviem o fluxo em quase qualquer ponto, Rust utiliza tipos de retorno Result. A Ingestão deve, portanto, transformar o grafo de fluxo de controle (CFG) para identificar todos os caminhos de saída possíveis de uma função, garantindo que a lógica de limpeza de recursos seja preservada sem introduzir vazamentos de memória ou double-frees durante a conversão.

### 2.2 Rastreamento de Proveniência

Cada objeto de memória no grafo recebe um identificador único de "Localização Abstrata" (LA). O sistema rastreia a proveniência de cada ponteiro — ou seja, o conjunto de todas as LAs para as quais um ponteiro pode apontar durante a execução.

| Conceito C++ | Representação no Grafo (PIIR) | Desafio de Ingestão |
| :--- | :--- | :--- |
| `new T()` | Nó de Origem (Source Node) | Identificar o ponto exato de criação. |
| `p = q` | Aresta de Fluxo (Flow Edge) | Propagar restrições de tempo de vida. |
| `delete p` | Nó de Sumidouro (Sink Node) | Validar se p é o único proprietário. |
| `void*` | Nó de Tipo Apagado | Requer análise de downcasts para reificação. |

O tratamento de ponteiros `void*` é particularmente crítico. Como o C++ utiliza `void*` para polimorfismo genérico ou manipulação de baixo nível, a informação de tipo é perdida. O Reconstrutor deve empregar uma análise de "Reificação de Tipos", examinando todos os pontos de uso (call-sites) onde ocorrem `static_cast` ou `reinterpret_cast` a partir de `void*`. O sistema infere um Sum Type (enumeração) em Rust que encapsula todos os tipos concretos possíveis que aquele ponteiro opaco pode assumir, permitindo uma tradução segura via enum em vez de unsafe.

## 3. O Obstáculo da Ambiguidade e a Indecidibilidade do Aliasing

O obstáculo teórico mais formidável para o "Reconstrutor de Propriedade" é a Ambiguidade do Ponteiro derivada do Aliasing Mutável. O modelo de empréstimo do Rust impõe a regra "Aliasing XOR Mutação": um dado pode ter múltiplas referências de leitura (&T) OU uma única referência de escrita (&mut T), mas nunca ambas simultaneamente. O C++, por outro lado, permite aliasing mutável irrestrito por padrão.

### 3.1 A Barreira da Indecidibilidade

Determinar estaticamente se dois ponteiros em C++ referenciam a mesma posição de memória é um problema formalmente indecidível. Isso é equivalente ao Problema da Parada: determinar o aliasing exato em um programa com loops e alocação dinâmica exigiria simular a execução do programa infinitamente.

Esta barreira teórica implica que o Reconstrutor não pode ser perfeito; ele deve ser conservador. O sistema opera sob uma lógica de "Segurança por Padrão":

*   **Must-Not-Alias**: Se a análise provar que dois ponteiros nunca se sobrepõem, o código pode ser traduzido para referências seguras (`&mut`).
*   **May-Alias**: Se a análise for inconclusiva (existe uma possibilidade teórica de sobreposição), o sistema deve assumir o pior caso. Nestes cenários, a tradução direta para `&mut` é proibida.

### 3.2 Algoritmos de Análise de Pontos-Para (Points-To Analysis)

Para maximizar a precisão e minimizar o uso de unsafe, o Reconstrutor emprega uma abordagem híbrida de análise estática :

*   **Análise de Steensgaard**: Um algoritmo baseado em unificação com complexidade quase linear ($O(N \alpha(N))$). Ele trata a atribuição de ponteiros como uma relação de equivalência bidirecional. Se `p = q`, então p e q são assumidos como apontando para o mesmo conjunto de locais. Embora rápido, é impreciso, tendendo a fundir conjuntos de ponteiros distintos em uma única classe de equivalência, o que geraria falsos positivos de aliasing.
*   **Análise de Andersen**: Um algoritmo baseado em inclusão (subset constraints) com complexidade cúbica ($O(N^3)$). Ele modela a atribuição `p = q` como `PontosPara(q) ⊆ PontosPara(p)`. Isso permite um fluxo direcional de dados, oferecendo muito maior precisão.

O Reconstrutor utiliza a Análise de Steensgaard para particionar o grafo de memória em regiões disjuntas macroscópicas e, em seguida, aplica a Análise de Andersen dentro de cada região para resolver as relações finas de aliasing.

### 3.3 Estratégias de Resolução de Conflitos

Quando o sistema detecta um conflito de "May-Alias" (ex: dois ponteiros podem escrever no mesmo objeto), ele aplica uma hierarquia de estratégias de resolução:

1.  **Refatoração para RefCell**: Se o aliasing ocorre dentro de um único thread, o objeto é envolvido em um `RefCell<T>`, movendo a verificação de empréstimo do tempo de compilação para o tempo de execução (runtime).
2.  **Indexação de Vetor**: Se os ponteiros apontam para elementos de um mesmo array/vetor, o sistema substitui os ponteiros por índices inteiros (`usize`) e passa a gerenciar o acesso através de um vetor central, contornando as restrições de referência do Rust.
3.  **Ponteiros Brutos (Fallback)**: Em última instância, se o aliasing é intrínseco à lógica (ex: estruturas de dados cíclicas sem propriedade clara), o sistema emite `*mut T` dentro de blocos unsafe, isolando o risco.

## 4. Rastreamento de Vida e Inferência de Regiões

O conceito de Tempo de Vida ('a) é explícito em Rust, mas implícito em C++. O "Rastreamento de Vida" é o módulo responsável por tornar essas durações implícitas em anotações explícitas, prevenindo o problema de Dangling Pointers (ponteiros pendentes).

### 4.1 Adaptação do Algoritmo Tofte-Talpin

A base teórica para esta inferência é o cálculo de regiões de Tofte-Talpin. O Reconstrutor divide o programa em regiões abstratas (escopos léxicos).

Para cada ponteiro p que referencia um objeto x, gera-se a restrição: `Região(x) ⊇ Região(p)`. Ou seja, a região de memória onde x reside deve sobreviver à região onde o ponteiro p é utilizado.

O algoritmo coleta essas restrições e tenta unificá-las. Se x é alocado na pilha em uma função pai e p é passado para uma função filha, o sistema infere que p é uma referência emprestada com o tempo de vida do escopo pai.

### 4.2 O Fenômeno do Contágio da Vida Útil

Um obstáculo crítico identificado é o Contágio da Vida Útil (Lifetime Contagion). Em Rust, parâmetros de tempo de vida são virais. Se uma struct contém uma referência, ela deve ser anotada com 'a. Qualquer outra struct que contenha a primeira também deve ser anotada, propagando-se por toda a base de código.

Em C++, é comum ter objetos de contexto global ou ponteiros de longa duração que permeiam o sistema. O Reconstrutor deve identificar esses "Super-Sobreviventes". Se um objeto tem um tempo de vida indeterminado ou muito longo que força a anotação de centenas de funções, o sistema opta estrategicamente por transformá-lo em um ponteiro inteligente com contagem de referência (`Rc<T>` ou `Arc<T>`), quebrando a cadeia de contágio estático em favor de gerenciamento dinâmico.

### 4.3 Ciclos e Componentes Fortemente Conexos (SCCs)

O grafo de referências em C++ frequentemente contém ciclos (A aponta para B, B aponta para A), o que é proibido em Rust seguro (ownership tree). O Reconstrutor detecta Componentes Fortemente Conexos (SCCs) no grafo de dependência.

Dentro de um SCC, a propriedade hierárquica é impossível.

**Solução Algorítmica**: O sistema converte automaticamente os membros do SCC para usar `Weak<T>` (para quebrar o ciclo) ou reestrutura o grupo de objetos em uma "Arena" (um `Vec<T>` onde os objetos se referenciam por índices), eliminando referências diretas de memória.

## 5. Inferência de Contrato e Assinaturas de Função

Assinaturas de função em C++ são contratos fracos. `void process(int* data)` é ambíguo: data é entrada? Saída? Será deletado? Será armazenado? O Reconstrutor deve inferir um contrato rigoroso para gerar a assinatura Rust correspondente: `fn process(data: &mut i32)`.

### 5.1 O Algoritmo Houdini para Rust

O sistema utiliza uma adaptação do Algoritmo Houdini, originalmente desenhado para verificação formal:

1.  **Geração de Candidatos**: Para cada argumento ponteiro, o sistema gera o conjunto de tipos Rust possíveis: `{ &T, &mut T, Box<T>, Option<&T> }`.
2.  **Suposição Otimista**: Inicialmente, assume-se o tipo mais restritivo e seguro: `&T` (Referência Imutável).
3.  **Refutação Iterativa (Loop de Feedback)**: O sistema simula o borrow checker no corpo da função.
    *   Se a função escreve em `*data`, a hipótese `&T` é refutada e o tipo é rebaixado para `&mut T`.
    *   Se a função chama `free(data)`, a hipótese de referência é refutada e o tipo é rebaixado para `Box<T>`.
    *   Se a função armazena data em uma variável global, o tipo é rebaixado para `Arc<T>` ou `static`.
4.  **Propagação Interprocedural**: A alteração da assinatura de uma função invalida as suposições de seus chamadores. O algoritmo itera até atingir um ponto fixo (estabilidade), onde todas as assinaturas satisfazem as restrições de uso em todo o programa.

### 5.2 Inferência de Mutabilidade

Ao contrário do C++, onde `const_cast` pode violar a imutabilidade, Rust exige garantias estritas. O Reconstrutor realiza uma Análise de Escrita (Write Analysis). Uma referência é marcada como `mut` somente se:

*   Existe uma instrução de armazenamento (store) atingível no CFG partindo dessa referência.
*   Ela é passada como argumento para outra função que exige `&mut`.

Esta análise minimiza o escopo da mutabilidade, aderindo ao princípio do menor privilégio.

## 6. Aritmética de Ponteiros e a Algorítmica de "Split Trees"

A aritmética de ponteiros (`p + i`) é onipresente em C++, tratando a memória como um array plano de bytes. Em Rust, referências apontam para objetos discretos. A tradução direta de aritmética resulta em código unsafe e ilegível.

### 6.1 O Algoritmo de "Split Trees" (Árvores de Divisão)

Para traduzir aritmética de ponteiros em fatias seguras (slices), o Reconstrutor implementa a análise de Split Trees.

O problema central é provar que dois acessos baseados em deslocamento (offset) não se sobrepõem. O C++ não carrega informações de tamanho (bounds) nos ponteiros.

1.  **Identificação da Raiz**: O sistema rastreia o ponteiro até sua alocação original (ex: `malloc(N)` ou `vector::data()`). Isso define a "Fatia Raiz" (Root Slice) com tamanho conhecido N.
2.  **Modelagem de Divisões**: Cada operação de aritmética ou acesso indexado é modelada como um corte na árvore. Se o código acessa `p[0..k]` e `p[k..N]`, o sistema insere uma chamada `split_at_mut(k)`.
    *   Isto cria dois novos nós na árvore: Esquerda (0..k) e Direita (k..N).
    *   Como os nós resultantes são disjuntos por definição, o compilador Rust aceita referências mutáveis para ambas as partes simultaneamente.
3.  **Prova de Disjunção**: O Reconstrutor substitui a aritmética insegura por chamadas estruturais a `split_at`, provando matematicamente a segurança de memória para algoritmos de divisão e conquista (como Quicksort ou parsers de buffer), eliminando a necessidade de unsafe para manipulação de buffers.

### 6.2 Recuperação de Iteradores

O sistema aplica reconhecimento de padrões para transformar loops `for` de estilo C (`for (int i=0; i<n; ++i)`) em iteradores Rust (`for x in iter`). Isso elimina verificações de limites (bounds checks) em tempo de execução. O desafio é a Invalidação de Iteradores: C++ permite modificar o contêiner durante a iteração, o que causa Comportamento Indefinido (UB). O Reconstrutor detecta padrões de modificação dentro de loops e, se encontrados, bloqueia a conversão para iteradores, forçando o uso de indexação ou refatorando para padrões como `Vec::retain`.

## 7. Tradução Rigorosa: Herança vs. Composição

O C++ utiliza herança de implementação, misturando layout de dados e hierarquia de comportamento. Rust favorece composição e traits. Esta dissonância estrutural exige uma transformação topológica do código.

### 7.1 Achatamento de Hierarquias (Flattening)

O Reconstrutor não pode mapear `class Derived : public Base` diretamente, pois structs em Rust não herdam campos. O algoritmo aplica a refatoração de Composição por Extração :

1.  **Extração de Estado**: Os campos de dados da classe Base são movidos para uma struct independente `BaseData`.
2.  **Injeção de Campo**: A struct Derived recebe um campo explícito `base: BaseData`.
3.  **Delegação Automática**: Métodos que operam sobre Base são implementados para Derived delegando a chamada para `self.base`.

### 7.2 Funções Virtuais para Objetos de Trait (Trait Objects)

O polimorfismo dinâmico (funções virtuais) é mapeado para Trait Objects (`dyn Trait`).

*   **Análise de Vtable**: Classes abstratas puras tornam-se traits.
*   **Problema do Ponteiro Gordo (Fat Pointer)**: Em C++, o ponteiro para a vtable é armazenado dentro do objeto. Em Rust, ele é armazenado na referência (`&dyn Trait` é um par: ponteiro de dados + ponteiro de vtable).
*   **Compatibilidade ABI**: Se o objeto C++ é passado para bibliotecas externas (FFI), o layout de memória do Rust ("Fat Pointer") é incompatível. O Reconstrutor detecta fronteiras de FFI e, se necessário, sintetiza manualmente uma struct de vtable em Rust (simulando o layout C++ com unsafe) para manter a compatibilidade binária, ou gera shims de conversão.

### 7.3 Downcasting e RTTI

O uso de `dynamic_cast` em C++ exige Informação de Tipo em Tempo de Execução (RTTI). O Rust suporta downcasting via `Any`, mas apenas para tipos `'static`. O Reconstrutor analisa a hierarquia de classes. Se downcasting for detectado, ele injeta automaticamente um método `as_any()` nas traits geradas, emulando o comportamento do RTTI de C++ de forma segura.

## 8. Explosão de Unsafe e Estratégias de Minimização

Uma tradução ingênua resultaria em uma "Explosão de Unsafe", onde quase todo o código é marcado como inseguro devido à incapacidade de provar a segurança estaticamente. O Reconstrutor combate isso com uma estratégia de contenção.

### 8.1 O Núcleo Seguro e a Casca Insegura

O sistema arquiteturalmente divide o código gerado:

1.  **Núcleo Seguro (Safe Core)**: Todo código onde a análise de aliasing e rastreamento de vida for conclusiva é emitido como Rust seguro.
2.  **Casca Insegura (Unsafe Shell)**: Código residual onde a análise atinge a barreira da indecidibilidade ou onde há violações fundamentais de modelo (ex: Unions) é encapsulado.
3.  **Fronteiras de Interface**: O sistema gera APIs seguras em torno dos blocos inseguros. Por exemplo, a implementação interna de uma lista ligada pode usar ponteiros brutos (`*mut Node`), mas os métodos públicos (push, pop) expõem uma interface segura, contendo asserções de tempo de execução geradas automaticamente para validar invariantes.

### 8.2 Heurística da Região Mínima

Ao contrário de ferramentas que marcam funções inteiras como unsafe, o Reconstrutor aplica o modificador unsafe na menor granularidade possível (apenas na instrução de desreferenciação ou chamada FFI específica). Isso torna o código auditável e explicita exatamente onde residem os riscos de memória.

## 9. O Desafio dos Macros e Metaprogramação

Macros em C++ operam por substituição textual, ignorando a estrutura sintática, o que permite gerar código parcial (ex: `#define OPEN_BRACE {`). Rust utiliza macros higiênicas que operam na AST.

### 9.1 Recuperação de Padrões (Pattern Recovery)

A tradução direta de macros textuais é muitas vezes impossível. O Reconstrutor opera primariamente na AST expandida (pós-processamento). No entanto, para evitar duplicação massiva de código, ele emprega Recuperação de Padrões.

1.  O sistema analisa o código Rust expandido em busca de sub-árvores estruturalmente idênticas repetidas.
2.  Ao identificar repetições que correspondem a locais de invocação de macros no código original, o sistema sintetiza uma nova macro declarativa `macro_rules!` em Rust que gera aquela estrutura.
3.  Isso reverte a expansão, recuperando a abstração original do programador, mas adaptada para a higiene sintática do Rust.

## 10. Conclusão

O "Reconstrutor de Propriedade" valida a tese de que é possível construir um transpilador determinístico de C++ para Rust que supere as limitações das ferramentas puramente sintáticas, sem depender da imprevisibilidade da Inteligência Artificial. Através da aplicação rigorosa de teorias de análise estática — Inferência de Regiões de Tofte-Talpin, Análise de Pontos-Para de Andersen e o algoritmo de Split Trees — o sistema é capaz de reconstruir a intenção de segurança latente no código C++.

Embora a barreira teórica da indecidibilidade do aliasing impeça uma tradução 100% segura para qualquer programa arbitrário, o sistema demonstra que é possível isolar a insegurança residual em regiões controladas e explícitas. O código resultante não é apenas uma tradução; é uma refatoração estrutural que eleva o nível de garantia do software, transformando o caos implícito dos ponteiros de C++ na disciplina explícita e verificável do Rust. A "Reconstrução de Propriedade" é, portanto, não apenas viável, mas necessária para a evolução segura da infraestrutura digital legada.
