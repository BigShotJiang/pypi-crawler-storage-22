# c2r Architecture

c2r (C++ to Rust) operates on a deterministic, multi-pass architecture designed to bridge the semantic gap between C++'s manual memory management and Rust's ownership model.

## Pipeline Overview

1.  **Ingestion Layer (Industrial Frontend)**
    *   **Input**: C++ Source Code (`.cpp`, `.h`).
    *   **Tool**: Clang AST Matchers (Simulated by `ClangFrontendMock` in prototype).
    *   **Output**: Property-Oriented Intermediate Representation (PIIR).
    *   **Responsibility**: Extracts high-level semantic events (Allocations, Moves, Thread Spawning, Field Access) rather than raw AST nodes.

2.  **Points-To Analysis (Static Analysis Core)**
    *   **Algorithms**:
        *   **Steensgaard ($O(N \alpha(N))$)**: Fast, unification-based partitioning of memory into disjoint sets. Used for initial region grouping.
        *   **Andersen ($O(N^3)$)**: Subset-based constraint solving. Used for precise pointer aliasing and lifetime dependency tracking.
    *   **Output**: Aliasing graphs and constraint sets.

3.  **Region Inference (Lifetime Reconstruction)**
    *   **Theory**: Tofte-Talpin Region Calculus.
    *   **Process**: Maps abstract locations to memory regions. Infers scope boundaries (Enter/Exit Scope events).
    *   **Outcome**: Determines where `drop()` should be inserted and which references need explicit lifetimes (`'a`).

4.  **Thread Safety Analysis**
    *   **Process**: Detects `Spawn` and `Join` events. Identifies variables captured by closures.
    *   **Logic**: Checks intersection of Mutated Sets vs Shared Sets.
    *   **Outcome**: Decides between `Box<T>` (local), `Arc<T>` (shared read-only), and `Arc<Mutex<T>>` (shared mutable).

5.  **Split Tree Analysis**
    *   **Goal**: Handle pointer arithmetic and sub-object borrowing.
    *   **Outcome**: Can split a struct borrowing into independent field borrowings.

6.  **Semantic Lowering & Code Generation**
    *   **Tool**: `syn` and `quote` crates.
    *   **Process**:
        *   **Struct Recovery**: Reconstructs class/struct definitions from usage patterns.
        *   **Name Recovery**: Maps internal abstract IDs back to readable variable names.
        *   **Body Generation**: constructs the AST for functions and main logic.
    *   **Formatter**: Passes generated AST through a `rustfmt` wrapper.

## Internal Representation (PIIR)

The PIIR is an event-stream IR, distinct from a Control Flow Graph (CFG).

```rust
pub enum LifeEvent {
    Allocation { target: ID, ... },
    Move { from: ID, to: ID },
    Spawn { thread_id: usize, captured: Vec<ID> },
    SmartPointer { kind: "shared", ... },
    // ...
}
```

This abstraction allows the analyzer to ignore C++ syntactic sugar and focus purely on ownership mechanics.
