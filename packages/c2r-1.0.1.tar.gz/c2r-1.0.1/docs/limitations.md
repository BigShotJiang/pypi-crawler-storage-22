# Limitations & Constraints

While c2r aims for industrial-grade translation, the semantic gap between C++ and Rust imposes fundamental limits.

## Semantic Fallbacks

When strict ownership cannot be proven, c2r employs a tiered fallback strategy:

1.  **Safe Idiomatic Rust**: The goal. `Box`, `Arc`, `&T`.
2.  **Runtime Managed (Interior Mutability)**: `Rc<RefCell<T>>`. Used when cyclic references or complex aliasing are detected.
3.  **Unsafe Rust**: `unsafe { ... }`. Used for raw pointer arithmetic, unions, or use-after-free patterns that cannot be resolved safely.
4.  **FFI Stub**: `extern "C"`. Used for unresolvable external library dependencies.

## Current Limitations (v1.0.0)

### 1. C++ Templates
*   **Support**: Basic containers (`std::vector`, `std::shared_ptr`) are mapped to Rust equivalents.
*   **Limitation**: Complex template metaprogramming (SFINAE, variadic templates) is NOT fully reconstructed. They are typically lowered to specific instantiations found in the code or opaque blobs.

### 2. Exceptions
*   **Support**: None.
*   **Future Plan**: Map `try/catch` blocks to `Result<T, E>` bubbling. Currently, exceptions are ignored, which may lead to panic-on-error behavior in Rust.

### 3. Macros
*   **Limitation**: C preprocessor macros are expanded before ingestion. The original macro structure is lost in the generated Rust code.

### 4. Inheritance
*   **Support**: Basic base classes.
*   **Limitation**: Deep inheritance hierarchies and multiple inheritance are difficult to map to Rust traits. Currently flattened or mapped to composition where possible.

### 5. Standard Library
*   **Support**: `iostream` (partial), `thread`, `mutex`, `vector`, `unordered_map`.
*   **Limitation**: Vast majority of STL (algorithms, chrono, filesystem) is not yet mapped.
