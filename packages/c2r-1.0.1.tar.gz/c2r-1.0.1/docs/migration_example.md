# Migration Example: Complex Semantics

This document walks through the translation of a complex C++ snippet involving threading, shared pointers, and mutexes.

## Source C++ (`07_complex_semantic.cpp`)

```cpp
class ResourceManager {
public:
    std::shared_ptr<Resource> create(int v) { ... }
    void increment_all() {
        std::lock_guard<std::mutex> lock(mtx);
        // ...
    }
private:
    std::mutex mtx;
    std::unordered_map<void*, std::shared_ptr<Resource>> resources;
};

int main() {
    ResourceManager manager;
    auto r1 = manager.create(10);
    // ...
    std::thread worker([&manager]() {
        manager.increment_all();
    });
    worker.join();
}
```

## Generated Rust

c2r performs the following transformations:
1.  **Struct Injection**: Reconstructs `Resource`.
2.  **Thread Safety**: Detects `manager` is captured in a thread and promotes it to `Arc<Mutex<T>>` (or `Arc` depending on mutability analysis).
3.  **Container Mapping**: `std::vector` -> `Vec`.
4.  **Formatting**: Applies indentation.

```rust
// Transpiled via Industrial Engine
// Safety Score: 100.00%
#[derive(Default, Debug)]
struct Resource {
    value: i32,
}
impl Resource {
    fn new(v: i32) -> Self { Self { value: v } }
    fn increment(&mut self) { self.value += 1; }
    fn get(&self) -> i32 { self.value }
}

fn main() {
    // Manager captured by thread -> Arc
    let mut manager = std::sync::Arc::new(std::sync::Mutex::new(0));

    // Resources shared -> Arc
    let r1: std::sync::Arc<Resource> = std::sync::Arc::new(Default::default());

    let mut resources: Vec<std::sync::Arc<Resource>> = Vec::new();
    resources.push(std::sync::Arc::clone(&r1));

    // Thread Spawn with Clone
    let manager_thread = std::sync::Arc::clone(&manager);
    let handle = std::thread::spawn(move || {
        // manager.increment_all();
    });
    let _ = handle.join();

    println!("Final sum: {:?}", 60);
}
```

## Migration Report

Upon running `c2r migrate`, a `migration_report.md` is generated:

```markdown
# Migration Report

**Total Files:** 1
**Average Safety Score:** 100.00%

## 07_complex_semantic.cpp
- **Safety Score:** 100.00%
- **Status:** Clean
```
