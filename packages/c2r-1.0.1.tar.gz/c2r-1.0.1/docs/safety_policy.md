# Safety & Code Generation Policy

c2r strictly follows a safety hierarchy when generating Rust code.

## 1. Safe Rust (Preferred)
*   **Constructs**: `Box<T>`, `&T`, `&mut T`.
*   **Conditions**:
    *   Strict ownership is proven (single owner).
    *   Lifetimes can be resolved via Region Inference.
    *   No data races detected by Thread Safety analysis.

## 2. Shared Safe Rust (Reference Counting)
*   **Constructs**: `Rc<T>`, `Arc<T>`.
*   **Conditions**:
    *   Multiple owners detected (Aliasing > 1).
    *   If threaded: Must use `Arc<T>`.
    *   If shared mutation: Must use interior mutability (`RefCell` / `Mutex`).

## 3. Unsafe Fallback (Explicit Opt-In)
*   **Constructs**: `unsafe { ... }`.
*   **Conditions**:
    *   **Raw Pointer Arithmetic**: Offset calculations that cannot be mapped to Split Trees.
    *   **Use-After-Free**: Detected by analysis but user opted to preserve behavior (risk flagged).
    *   **Unions**: C-style unions without tag tracking.

## 4. FFI Boundaries
*   **Constructs**: `extern "C"`, `#[link]`.
*   **Conditions**:
    *   Calls to external libraries not present in the ingestion set.
    *   System calls or unknown intrinsics.

## Decision Logic

```rust
if analysis.is_proven_safe() {
    generate_safe_rust()
} else if analysis.is_shared() {
    generate_arc_rc()
} else if analysis.is_external() {
    generate_ffi()
} else {
    generate_unsafe_block_with_warning()
}
```
