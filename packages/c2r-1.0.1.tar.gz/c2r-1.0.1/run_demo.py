import os
import sys
import glob
import subprocess
import shutil

# Ensure the shared object is in the path
sys.path.append(os.getcwd())

LIB_NAME = "c2r_core.so"

def build_extension():
    print("Building Rust extension...")
    try:
        subprocess.check_call(["cargo", "build", "--quiet"])
        # Find the built library
        # It's usually in target/debug/libc2r_core.so (Linux) or .dylib (Mac) or .dll (Windows)
        # We assume Linux environment here based on .so requirement
        src_path = "target/debug/libc2r_core.so"
        if os.path.exists(src_path):
            shutil.copy(src_path, LIB_NAME)
            print(f"Successfully built and copied to {LIB_NAME}")
        else:
             print(f"Error: Could not find built library at {src_path}")
             sys.exit(1)
    except subprocess.CalledProcessError as e:
        print(f"Build failed: {e}")
        sys.exit(1)

# Check if library exists, if not, build it
if not os.path.exists(LIB_NAME):
    build_extension()

try:
    import c2r_core as c2r
except ImportError as e:
    print(f"Failed to import Rust module: {e}")
    print("Attempting to rebuild...")
    build_extension()
    try:
        import c2r_core as c2r
    except ImportError as e2:
        print(f"Still failed to import: {e2}")
        sys.exit(1)

def run_pipeline():
    # Initialize Rust logger (will output to stderr/stdout based on RUST_LOG env var)
    try:
        c2r.init_logging()
    except Exception as e:
        print(f"Logging init warning: {e}")

    reconstructor = c2r.Reconstructor()

    samples = sorted(glob.glob("tests/cpp_samples/*.cpp"))

    print(f"Found {len(samples)} C++ samples to process.\n")

    for sample_file in samples:
        print("="*60)
        print(f"PROCESSING: {sample_file}")
        print("="*60)

        with open(sample_file, 'r') as f:
            cpp_code = f.read()

        print("--- [ C++ Input ] ---")
        print(cpp_code.strip())
        print("\n--- [ Rust Analysis & Translation Logs ] ---")

        # Call the Rust engine
        # The logs (info/warn/error) from Rust will appear here in the console
        rust_output = reconstructor.translate(cpp_code)

        print("\n--- [ Generated Rust Code ] ---")
        print(rust_output)
        print("\n")

if __name__ == "__main__":
    # Set default log level if not set
    if "RUST_LOG" not in os.environ:
        os.environ["RUST_LOG"] = "info"

    run_pipeline()
