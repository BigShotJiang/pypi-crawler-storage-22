use crate::piir::AbstractLocationId;
use std::collections::{HashMap, HashSet, VecDeque};

/// Andersen's Points-To Analysis
/// Complexity: O(N^3)
/// Model: Subset Constraints (Inclusion)
/// if p = q, then PointsTo(q) ⊆ PointsTo(p)
pub struct AndersenSolver {
    // Graph of constraints: A -> [B] means A ⊆ B (flow of data)
    // If 'q' flows to 'p', we have edge q -> p.
    subset_edges: HashMap<AbstractLocationId, HashSet<AbstractLocationId>>,

    // Points-To sets: What each pointer CAN point to.
    points_to: HashMap<AbstractLocationId, HashSet<AbstractLocationId>>,

    // Worklist for propagation
    worklist: VecDeque<AbstractLocationId>,
}

impl AndersenSolver {
    pub fn new() -> Self {
        Self {
            subset_edges: HashMap::new(),
            points_to: HashMap::new(),
            worklist: VecDeque::new(),
        }
    }

    /// Records an allocation: p = new T
    /// p points to { new_obj }
    pub fn add_allocation(&mut self, p: AbstractLocationId, obj: AbstractLocationId) {
        let pts = self.points_to.entry(p).or_insert_with(HashSet::new);
        if pts.insert(obj) {
            self.worklist.push_back(p);
        }
    }

    /// Records an assignment: p = q
    /// PointsTo(q) ⊆ PointsTo(p)
    /// Adds edge q -> p
    pub fn add_constraint(&mut self, p: AbstractLocationId, q: AbstractLocationId) {
        let edges = self.subset_edges.entry(q).or_insert_with(HashSet::new);
        if edges.insert(p) {
            // Since q's set might already have members, we must add q to worklist
            // to propagate its current members to p.
            self.worklist.push_back(q);
        }
    }

    /// Solve the constraints until fixed point.
    pub fn solve(&mut self) {
        while let Some(node) = self.worklist.pop_front() {
            // For each target 'next' where node -> next (meaning node ⊆ next)
            if let Some(targets) = self.subset_edges.get(&node).cloned() {
                let source_pts = self.points_to.entry(node).or_default().clone();

                for target in targets {
                    let target_pts = self.points_to.entry(target).or_default();
                    let mut changed = false;
                    for pt in &source_pts {
                        if target_pts.insert(*pt) {
                            changed = true;
                        }
                    }
                    if changed {
                        self.worklist.push_back(target);
                    }
                }
            }
        }
    }

    /// Check if two pointers MAY alias (intersection of points-to sets is non-empty)
    pub fn may_alias(&self, a: AbstractLocationId, b: AbstractLocationId) -> bool {
        if let (Some(pts_a), Some(pts_b)) = (self.points_to.get(&a), self.points_to.get(&b)) {
            !pts_a.is_disjoint(pts_b)
        } else {
            false
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_andersen_subset_propagation() {
        let mut solver = AndersenSolver::new();
        let p = AbstractLocationId(1);
        let q = AbstractLocationId(2);
        let r = AbstractLocationId(3);
        let obj = AbstractLocationId(100);

        // r = new Obj
        solver.add_allocation(r, obj);
        // q = r (q ⊇ r)
        solver.add_constraint(q, r);
        // p = q (p ⊇ q)
        solver.add_constraint(p, q);

        solver.solve();

        assert!(solver.may_alias(p, r)); // p should point to obj
        let pts_p = solver.points_to.get(&p).unwrap();
        assert!(pts_p.contains(&obj));
    }
}
