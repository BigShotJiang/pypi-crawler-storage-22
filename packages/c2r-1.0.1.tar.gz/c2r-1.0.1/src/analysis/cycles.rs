use crate::piir::AbstractLocationId;
use std::collections::{HashMap, HashSet};

/// Cycle Detection Analyzer
/// Detects Strongly Connected Components (SCCs) in the reference graph.
/// If a cycle is found (A -> B -> A), it suggests using Weak<T> or unsafe.

pub struct CycleDetector {
    // Adjacency list: from -> vec[to]
    adj: HashMap<AbstractLocationId, Vec<AbstractLocationId>>,
    pub cycles_detected: Vec<Vec<AbstractLocationId>>,
}

impl CycleDetector {
    pub fn new() -> Self {
        Self {
            adj: HashMap::new(),
            cycles_detected: Vec::new(),
        }
    }

    pub fn add_edge(&mut self, from: AbstractLocationId, to: AbstractLocationId) {
        self.adj.entry(from).or_default().push(to);
    }

    /// Run Tarjan's or DFS to find cycles.
    /// Simplified DFS for demo.
    pub fn detect_cycles(&mut self) {
        let mut visited = HashSet::new();
        let mut recursion_stack = HashSet::new();

        // Clone keys to avoid borrow issues
        let nodes: Vec<AbstractLocationId> = self.adj.keys().cloned().collect();

        for node in nodes {
            if self.dfs(node, &mut visited, &mut recursion_stack) {
                // Cycle found involving 'node'
                // In a real SCC algo we would collect the full component.
                // Here we just flag it.
                self.cycles_detected.push(vec![node]);
            }
        }
    }

    fn dfs(&self, u: AbstractLocationId, visited: &mut HashSet<AbstractLocationId>, stack: &mut HashSet<AbstractLocationId>) -> bool {
        visited.insert(u);
        stack.insert(u);

        if let Some(neighbors) = self.adj.get(&u) {
            for &v in neighbors {
                if !visited.contains(&v) {
                    if self.dfs(v, visited, stack) {
                        return true;
                    }
                } else if stack.contains(&v) {
                    return true;
                }
            }
        }

        stack.remove(&u);
        false
    }
}
