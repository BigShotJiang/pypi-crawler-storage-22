use crate::piir::{AbstractLocationId, RegionId};
use crate::disjoint_set::UnionFind;
use std::collections::HashMap;

/// Tofte-Talpin Region Inference
/// Goal: Infer the lifetime 'a for each pointer.
/// Constraint: if p points to x, then Region(x) must outlive Region(p).
/// Region(x) >= Region(p)
pub struct RegionInference {
    // Equivalence classes for regions (unification based for simplicity)
    region_sets: UnionFind<RegionId>,

    // Depth map: 0 = global, 1 = main, 2 = inner scope...
    // Larger depth = shorter lifetime.
    // If Region(x) >= Region(p), then Depth(Region(x)) <= Depth(Region(p))
    region_depths: HashMap<RegionId, usize>,

    // Map Location -> Region Variable
    loc_to_region: HashMap<AbstractLocationId, RegionId>,

    next_region_id: usize,
}

impl RegionInference {
    pub fn new() -> Self {
        Self {
            region_sets: UnionFind::new(),
            region_depths: HashMap::new(),
            loc_to_region: HashMap::new(),
            next_region_id: 0,
        }
    }

    pub fn new_region(&mut self, depth: usize) -> RegionId {
        let id = RegionId(self.next_region_id);
        self.next_region_id += 1;
        self.region_sets.make_set(id);
        self.region_depths.insert(id, depth);
        id
    }

    pub fn assign_region(&mut self, loc: AbstractLocationId, region: RegionId) {
        self.loc_to_region.insert(loc, region);
    }

    /// Add constraint: loc_source outlives loc_ptr
    /// e.g., p = &x;  x must outlive p.
    pub fn add_outlives_constraint(&mut self, loc_source: AbstractLocationId, loc_ptr: AbstractLocationId) {
        // Retrieve regions
        let r_source = *self.loc_to_region.get(&loc_source).expect("Source loc has no region");
        let r_ptr = *self.loc_to_region.get(&loc_ptr).expect("Ptr loc has no region");

        // Unify them? In standard TT, it's unification-based or inequality.
        // For this prototype, we'll Unify if they need to interact heavily,
        // or check depths.
        // Simple TT: Unify.
        self.region_sets.union(&r_source, &r_ptr);

        // After unification, the depth should be the MINIMUM (widest scope) of the two?
        // Actually, if we unify, they become the same lifetime.
        // A smarter approach is strict inequality, but that requires a graph solver.
        // We'll stick to Unification (Steensgaard-like for regions) as a robust fallback.
    }

    pub fn get_lifetime_name(&mut self, loc: AbstractLocationId) -> String {
        if let Some(r) = self.loc_to_region.get(&loc) {
            let root = self.region_sets.find(r);
            let depth = self.region_depths.get(&root).cloned().unwrap_or(0);
            if depth == 0 {
                "'static".to_string()
            } else {
                format!("'a{}", root.0)
            }
        } else {
            "'_".to_string()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_region_unification() {
        let mut infer = RegionInference::new();
        let global_depth = 0;
        let local_depth = 1;

        let r_global = infer.new_region(global_depth);
        let r_local = infer.new_region(local_depth);

        let loc_g = AbstractLocationId(1);
        let loc_l = AbstractLocationId(2);

        infer.assign_region(loc_g, r_global);
        infer.assign_region(loc_l, r_local);

        // Constraint: Global must outlive Local (natural)
        // But if we force them to unify (e.g., storing local ptr in global var),
        // they become same region.
        infer.add_outlives_constraint(loc_g, loc_l);

        assert!(infer.region_sets.same_set(&r_global, &r_local));
    }
}
