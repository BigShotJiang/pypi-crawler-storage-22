use crate::piir::AbstractLocationId;
use std::collections::HashMap;

/// Split Tree Logic
/// Transforms pointer arithmetic (p + i) into safe slices.
pub struct SplitTreeSolver {
    // Maps a base pointer to its active splits
    // Base -> Sorted List of Split Points
    splits: HashMap<AbstractLocationId, Vec<isize>>,
}

impl SplitTreeSolver {
    pub fn new() -> Self {
        Self {
            splits: HashMap::new(),
        }
    }

    /// Register a split request at a specific offset
    pub fn request_split(&mut self, base: AbstractLocationId, offset: isize) {
        let list = self.splits.entry(base).or_default();
        if !list.contains(&offset) {
            list.push(offset);
            list.sort();
        }
    }

    /// Generate the Rust code to perform the splits
    /// e.g. "let (left, right) = base.split_at_mut(k);"
    pub fn generate_split_code(&self, base: AbstractLocationId) -> Vec<String> {
        let mut code = Vec::new();
        if let Some(offsets) = self.splits.get(&base) {
            // Very naive generation just to prove logic
            for (i, off) in offsets.iter().enumerate() {
                code.push(format!("// Split Tree: Splitting var_{} at offset {}", base.0, off));
                code.push(format!("let (part_{}_a, part_{}_b) = var_{}.split_at_mut({});", i, i, base.0, off));
            }
        }
        code
    }
}
