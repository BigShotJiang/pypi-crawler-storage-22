use crate::disjoint_set::UnionFind;
use crate::piir::{AbstractLocationId, LifeEvent};

pub struct SteensgaardSolver {
    // Equivalence classes for pointers.
    // If p and q are in the same set, they MIGHT point to the same memory locations.
    pub points_to_sets: UnionFind<AbstractLocationId>,
}

impl SteensgaardSolver {
    pub fn new() -> Self {
        Self {
            points_to_sets: UnionFind::new(),
        }
    }

    pub fn process_event(&mut self, event: &LifeEvent) {
        match event {
            LifeEvent::Allocation { target, .. } => {
                // p = new ...
                // p is in its own set initially (or added if not exists)
                self.points_to_sets.make_set(*target);
            }
            LifeEvent::Move { from, to } => {
                // p = q
                // Unify the sets of p and q because they now point to the same thing
                self.points_to_sets.union(from, to);
            }
            // Mutation and Deallocation don't change the points-to graph structure directly
            // in this simplified model (flow-insensitive), they utilize it.
            _ => {}
        }
    }

    pub fn may_alias(&mut self, a: AbstractLocationId, b: AbstractLocationId) -> bool {
        if a == b {
            return true;
        }
        self.points_to_sets.same_set(&a, &b)
    }
}
