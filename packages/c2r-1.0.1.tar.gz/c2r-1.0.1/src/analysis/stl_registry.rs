use std::collections::HashMap;

pub struct STLRegistry {
    pub map: HashMap<String, String>,
}

impl STLRegistry {
    pub fn new() -> Self {
        let mut map = HashMap::new();
        // Filesystem
        map.insert("std::filesystem".into(), "std::fs".into());
        map.insert("std::filesystem::path".into(), "std::path::PathBuf".into());

        // Threads & Sync
        map.insert("std::thread".into(), "std::thread".into());
        map.insert("std::mutex".into(), "std::sync::Mutex".into());
        map.insert("std::lock_guard".into(), "std::sync::MutexGuard".into()); // Approximate
        map.insert("std::atomic".into(), "std::sync::atomic".into());

        // Containers
        map.insert("std::vector".into(), "Vec".into());
        map.insert("std::string".into(), "String".into());
        map.insert("std::unordered_map".into(), "std::collections::HashMap".into());
        map.insert("std::map".into(), "std::collections::BTreeMap".into());

        // IO
        map.insert("std::cout".into(), "println!".into()); // Handled via logic, but good for ref
        map.insert("std::cerr".into(), "eprintln!".into());

        Self { map }
    }

    pub fn lookup(&self, cpp_type: &str) -> Option<String> {
        self.map.get(cpp_type).cloned()
    }
}
