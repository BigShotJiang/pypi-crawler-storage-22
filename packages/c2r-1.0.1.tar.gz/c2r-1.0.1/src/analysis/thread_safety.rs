use crate::piir::AbstractLocationId;
use std::collections::{HashMap, HashSet};

/// Thread Safety Analyzer
/// Detects if variables are shared across threads and potentially race-prone.
/// If a variable is mutated and accessed by multiple threads, it requires synchronization (Arc<Mutex>).

pub struct ThreadSafetyAnalysis {
    // thread_id -> set of vars accessed
    thread_access: HashMap<usize, HashSet<AbstractLocationId>>,

    // var -> is mutated?
    mutated_vars: HashSet<AbstractLocationId>,

    // Vars that need Arc<Mutex<T>>
    pub shared_mutable_vars: HashSet<AbstractLocationId>,

    current_thread: usize,
}

impl ThreadSafetyAnalysis {
    pub fn new() -> Self {
        Self {
            thread_access: HashMap::new(),
            mutated_vars: HashSet::new(),
            shared_mutable_vars: HashSet::new(),
            current_thread: 0, // 0 = main thread
        }
    }

    pub fn set_current_thread(&mut self, tid: usize) {
        self.current_thread = tid;
    }

    pub fn record_access(&mut self, var: AbstractLocationId) {
        self.thread_access.entry(self.current_thread)
            .or_default()
            .insert(var);
    }

    pub fn record_mutation(&mut self, var: AbstractLocationId) {
        self.mutated_vars.insert(var);
        self.record_access(var);
    }

    pub fn analyze_safety(&mut self) {
        // For each variable, count how many threads access it
        let mut var_threads: HashMap<AbstractLocationId, HashSet<usize>> = HashMap::new();

        for (tid, vars) in &self.thread_access {
            for var in vars {
                var_threads.entry(*var).or_default().insert(*tid);
            }
        }

        for (var, threads) in var_threads {
            if threads.len() > 1 {
                // Shared!
                if self.mutated_vars.contains(&var) {
                    // Shared AND Mutated -> Data Race Candidate -> Needs Arc<Mutex>
                    self.shared_mutable_vars.insert(var);
                } else {
                    // Shared but Read-Only -> Needs Arc (but maybe not Mutex)
                    // For simplicity, we flag for Arc
                }
            }
        }
    }
}
