/// Trait Bound Inference
/// Maps C++ operators to Rust Traits.

use std::collections::HashSet;
use crate::piir::AbstractLocationId;

pub struct TraitInference {
    // Map abstract location to required traits
    pub required_traits: std::collections::HashMap<AbstractLocationId, HashSet<String>>,
}

impl TraitInference {
    pub fn new() -> Self {
        Self {
            required_traits: std::collections::HashMap::new(),
        }
    }

    pub fn infer_trait(&mut self, lhs: AbstractLocationId, op: &str) {
        let trait_name = match op {
            "+" => "std::ops::Add",
            "-" => "std::ops::Sub",
            "*" => "std::ops::Mul",
            "/" => "std::ops::Div",
            "==" => "PartialEq",
            "<" | ">" => "PartialOrd",
            _ => return,
        };

        self.required_traits.entry(lhs).or_default().insert(trait_name.to_string());
    }
}
