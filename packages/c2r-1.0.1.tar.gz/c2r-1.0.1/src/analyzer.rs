use crate::piir::{LifeEvent, AbstractLocationId};
use crate::analysis::steensgaard::SteensgaardSolver;
use crate::analysis::andersen::AndersenSolver;
use crate::analysis::regions::RegionInference;
use crate::analysis::split_tree::SplitTreeSolver;
use crate::analysis::thread_safety::ThreadSafetyAnalysis;
use crate::analysis::cycles::CycleDetector;
use crate::analysis::traits::TraitInference;
use crate::analysis::stl_registry::STLRegistry; // Added
use std::collections::{HashSet, HashMap};
use log::{info, warn, error};
use quote::{quote, format_ident};
use proc_macro2::TokenStream;
use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize)]
pub struct AnalysisReport {
    pub safety_score: f64,
    pub unsafe_events: Vec<String>,
    pub generated_code: String,
    pub total_lines: usize,
}

pub struct Analyzer {
    active_allocations: HashSet<AbstractLocationId>,
    freed_resources: HashSet<AbstractLocationId>,

    // Analyses
    steensgaard: SteensgaardSolver,
    andersen: AndersenSolver,
    regions: RegionInference,
    split_trees: SplitTreeSolver,
    thread_safety: ThreadSafetyAnalysis,
    cycle_detector: CycleDetector,
    trait_inference: TraitInference,
    stl_registry: STLRegistry, // Added

    // Code Gen Buffer
    // thread_id -> buffer of statements
    thread_buffers: HashMap<usize, Vec<TokenStream>>,
    current_codegen_thread: usize,

    // Variable Remapping for Threads (Clone tracking)
    // (ThreadId, OriginalVarId) -> ClonedVarIdent
    var_remap: HashMap<(usize, AbstractLocationId), proc_macro2::Ident>,

    // Track if a var is captured by any thread
    captured_vars: HashSet<AbstractLocationId>,

    // Report data
    unsafe_events_log: Vec<String>,

    // Detected Structs/Helpers
    detected_resource_struct: bool,

    // Name Recovery Map
    name_map: HashMap<AbstractLocationId, String>,

    // Function Context
    current_function_name: Option<String>,
}

impl Analyzer {
    pub fn new() -> Self {
        Self {
            active_allocations: HashSet::new(),
            freed_resources: HashSet::new(),
            steensgaard: SteensgaardSolver::new(),
            andersen: AndersenSolver::new(),
            regions: RegionInference::new(),
            split_trees: SplitTreeSolver::new(),
            thread_safety: ThreadSafetyAnalysis::new(),
            cycle_detector: CycleDetector::new(),
            trait_inference: TraitInference::new(),
            stl_registry: STLRegistry::new(),
            thread_buffers: HashMap::new(),
            current_codegen_thread: 0,
            var_remap: HashMap::new(),
            captured_vars: HashSet::new(),
            unsafe_events_log: Vec::new(),
            detected_resource_struct: false,
            name_map: HashMap::new(),
            current_function_name: None,
        }
    }

    fn push_code(&mut self, code: TokenStream) {
        self.thread_buffers
            .entry(self.current_codegen_thread)
            .or_default()
            .push(code);
    }

    fn get_var_ident(&self, var_id: AbstractLocationId) -> proc_macro2::Ident {
        if self.current_codegen_thread > 0 {
            if let Some(remapped) = self.var_remap.get(&(self.current_codegen_thread, var_id)) {
                return remapped.clone();
            }
        }

        if let Some(name) = self.name_map.get(&var_id) {
            return format_ident!("{}", name);
        }

        format_ident!("var_{}", var_id.0)
    }

    pub fn analyze_and_report(&mut self, events: &[LifeEvent]) -> AnalysisReport {
        let code = self.analyze_internal(events);

        let total_events = events.len();
        let unsafe_count = self.unsafe_events_log.len();

        let safety_score = if total_events > 0 {
            100.0 * (1.0 - (unsafe_count as f64 / total_events as f64))
        } else {
            100.0
        };

        AnalysisReport {
            safety_score,
            unsafe_events: self.unsafe_events_log.clone(),
            generated_code: code,
            total_lines: total_events,
        }
    }

    pub fn analyze(&mut self, events: &[LifeEvent]) -> String {
        let report = self.analyze_and_report(events);
        format!("// Transpiled via Industrial Engine\n// Safety Score: {:.2}%\n{}", report.safety_score, report.generated_code)
    }

    fn analyze_internal(&mut self, events: &[LifeEvent]) -> String {
        info!("Starting Multi-Phase Industrial Analysis on {} events", events.len());

        // --- Pre-Pass ---
        for event in events {
             match event {
                LifeEvent::Allocation { target, origin_name, .. } | LifeEvent::Constant { target, origin_name, .. } => {
                    if let Some(name) = origin_name {
                        self.name_map.insert(*target, name.clone());
                    }
                    if let LifeEvent::Allocation { .. } = event {
                        self.thread_safety.record_access(*target);
                    }
                }
                LifeEvent::SmartPointer { inner_type, .. } => {
                    if inner_type == "Resource" {
                        self.detected_resource_struct = true;
                    }
                }
                LifeEvent::Spawn { thread_id, captured_vars } => {
                    self.thread_safety.set_current_thread(*thread_id);
                    for var in captured_vars {
                        self.thread_safety.record_access(*var);
                        self.captured_vars.insert(*var);
                    }
                }
                LifeEvent::Join { .. } => {
                    self.thread_safety.set_current_thread(0);
                }
                LifeEvent::Mutation { target } => {
                    self.thread_safety.record_mutation(*target);
                }
                LifeEvent::Move { from, .. } | LifeEvent::Copy { from, .. } => {
                    self.thread_safety.record_access(*from);
                }
                LifeEvent::FieldAccess { base, target, .. } => {
                    self.cycle_detector.add_edge(*base, *target);
                }
                LifeEvent::OperatorUsage { op, lhs, .. } => {
                    self.trait_inference.infer_trait(*lhs, op);
                }
                _ => {}
             }
        }
        self.thread_safety.analyze_safety();
        self.cycle_detector.detect_cycles();

        // --- Phase 1: Points-To ---
        for event in events {
            self.steensgaard.process_event(event);
            match event {
                LifeEvent::Move { from, to } => {
                    self.andersen.add_constraint(*to, *from);
                }
                _ => {}
            }
        }
        self.andersen.solve();

        // --- Phase 3: Code Generation ---

        // Initialize main thread buffer
        self.thread_buffers.insert(0, Vec::new());
        self.current_codegen_thread = 0;

        for event in events {
            match event {
                LifeEvent::TemplateDefinition { name, params } => {
                    let struct_name = format_ident!("{}", name);
                    let mut params_tokens = Vec::new();
                    let mut phantom_data_tokens = Vec::new();
                    for param in params {
                        let p_ident = format_ident!("{}", param);
                        params_tokens.push(quote! { #p_ident });
                        phantom_data_tokens.push(quote! { std::marker::PhantomData<#p_ident> });
                    }

                    self.push_code(quote! {
                        struct #struct_name<#(#params_tokens),*> {
                            _marker: (#(#phantom_data_tokens),*),
                        }
                    });
                }
                LifeEvent::ClassDefinition { name, base_class, fields } => {
                    let struct_name = format_ident!("{}", name);
                    let mut field_tokens = Vec::new();
                    for (fname, ftype) in fields {
                        let f_ident = format_ident!("{}", fname);
                        let t_ident = format_ident!("{}", ftype); // Simplified type mapping
                        field_tokens.push(quote! { pub #f_ident: #t_ident });
                    }

                    if let Some(base) = base_class {
                        // Composition over Inheritance
                        let base_ident = format_ident!("{}", base);
                        self.push_code(quote! {
                            struct #struct_name {
                                base: #base_ident,
                                #(#field_tokens),*
                            }
                            impl std::ops::Deref for #struct_name {
                                type Target = #base_ident;
                                fn deref(&self) -> &Self::Target { &self.base }
                            }
                            impl std::ops::DerefMut for #struct_name {
                                fn deref_mut(&mut self) -> &mut Self::Target { &mut self.base }
                            }
                        });
                    } else {
                        self.push_code(quote! {
                            struct #struct_name {
                                #(#field_tokens),*
                            }
                        });
                    }
                }
                LifeEvent::FunctionDefinition { name, return_type, .. } => {
                    self.current_function_name = Some(name.clone());
                    let fn_name = format_ident!("{}", name);
                    // Naive Return Type mapping
                    let ret_type = if return_type == "void" {
                        quote! { Result<(), Box<dyn std::error::Error>> }
                    } else {
                        // Assume simplistic mapping or use raw string
                        let ret_ident = format_ident!("{}", return_type);
                        quote! { Result<#ret_ident, Box<dyn std::error::Error>> }
                    };

                    // Reset buffer for new function
                    self.thread_buffers.insert(0, Vec::new());
                }
                LifeEvent::TryBlockStart => {
                    self.push_code(quote! {
                        // try {
                    });
                }
                LifeEvent::TryBlockEnd => {
                    self.push_code(quote! {
                        // }
                    });
                }
                LifeEvent::CatchBlockStart { .. } => {
                     self.push_code(quote! {
                        // catch {
                    });
                }
                LifeEvent::CatchBlockEnd => {
                     self.push_code(quote! {
                        // }
                    });
                }
                LifeEvent::Throw { .. } => {
                    self.push_code(quote! {
                        return Err("Exception thrown".into());
                    });
                }
                LifeEvent::Constant { target, value, .. } => {
                    let var_name = self.get_var_ident(*target);
                    let val: TokenStream = value.parse().unwrap();
                    self.push_code(quote! {
                        let #var_name = #val;
                    });
                }
                LifeEvent::Allocation { target, .. } => {
                    self.active_allocations.insert(*target);
                    let var_name = self.get_var_ident(*target);

                    let is_cycle = self.cycle_detector.cycles_detected.iter().any(|c| c.contains(target));
                    let is_captured = self.captured_vars.contains(target);

                    if self.thread_safety.shared_mutable_vars.contains(target) {
                         self.push_code(quote! {
                            let #var_name = std::sync::Arc::new(std::sync::Mutex::new(0));
                        });
                    } else if is_captured {
                         self.push_code(quote! {
                            let #var_name = std::sync::Arc::new(0);
                        });
                    } else if is_cycle {
                        info!("Cycle detected involving var_{}. Suggesting Rc<RefCell> or Weak.", target.0);
                        self.push_code(quote! {
                            let #var_name = std::rc::Rc::new(std::cell::RefCell::new(Node::new()));
                        });
                    } else {
                        self.push_code(quote! {
                            let mut #var_name = Box::new(0);
                        });
                    }
                }
                LifeEvent::ExternalCall { function_name, args } => {
                    let fn_ident = format_ident!("{}", function_name);
                    let mut arg_tokens = Vec::new();
                    for arg in args {
                        let arg_name = self.get_var_ident(*arg);
                        arg_tokens.push(quote! { #arg_name });
                    }

                    self.unsafe_events_log.push(format!("FFI Call detected: {}", function_name));

                    // Generate unsafe block for FFI
                    self.push_code(quote! {
                        unsafe {
                            // FFI Call
                            #fn_ident(#(#arg_tokens),*);
                        }
                    });
                }
                LifeEvent::SmartPointer { kind, target, inner_type } => {
                     let var_name = self.get_var_ident(*target);
                     // Check registry first
                     let rust_type = self.stl_registry.lookup(&inner_type).unwrap_or(inner_type.clone());

                     let type_tokens: TokenStream = rust_type.parse().unwrap_or(quote!{ i32 });

                     if kind == "unique" {
                         self.push_code(quote! {
                             let #var_name: Box<#type_tokens> = Box::new(Default::default());
                         });
                     } else if kind == "shared" {
                         if self.thread_safety.shared_mutable_vars.contains(target) {
                             self.push_code(quote! {
                                 let #var_name: std::sync::Arc<std::sync::Mutex<#type_tokens>> = std::sync::Arc::new(std::sync::Mutex::new(Default::default()));
                             });
                         } else {
                              self.push_code(quote! {
                                 let #var_name: std::sync::Arc<#type_tokens> = std::sync::Arc::new(Default::default());
                             });
                         }
                     }
                }
                LifeEvent::TemplateUsage { template_name, args, instance_id } => {
                    let var_name = self.get_var_ident(*instance_id);
                    if template_name == "Vec" {
                         if let Some(arg) = args.first() {
                             let type_token: TokenStream = arg.parse().unwrap_or(quote!{ i32 });
                             self.push_code(quote! {
                                 let mut #var_name: Vec<#type_token> = Vec::new();
                             });
                         } else {
                              self.push_code(quote! {
                                 let mut #var_name = Vec::new();
                             });
                         }
                    }
                }
                LifeEvent::IOPrint { content, args, is_newline } => {
                     let mut fmt_string = content.clone();
                     let mut arg_tokens = Vec::new();
                     for arg in args {
                         let arg_name = self.get_var_ident(*arg);
                         arg_tokens.push(quote! { #arg_name });
                     }

                     if !arg_tokens.is_empty() && fmt_string.contains("{}") {
                         fmt_string = fmt_string.replace("{}", "{:?}");
                     }

                     if *is_newline {
                         self.push_code(quote! {
                             println!(#fmt_string, #(#arg_tokens),*);
                         });
                     } else {
                         self.push_code(quote! {
                             print!(#fmt_string, #(#arg_tokens),*);
                         });
                     }
                }
                LifeEvent::OperatorUsage { lhs, .. } => {
                     let traits_opt = self.trait_inference.required_traits.get(lhs).cloned();
                     if let Some(traits) = traits_opt {
                         for t in traits {
                             let t_token: TokenStream = t.parse().unwrap();
                             self.push_code(quote! {
                                 // Trait Bound Inferred: T: #t_token
                             });
                         }
                     }
                }
                LifeEvent::FieldAccess { base, field_name, target } => {
                    let base_name = self.get_var_ident(*base);
                    let target_name = self.get_var_ident(*target);
                    let field = format_ident!("{}", field_name);

                    let is_cycle = self.cycle_detector.cycles_detected.iter().any(|c| c.contains(base));
                    if is_cycle {
                        self.push_code(quote! {
                             #base_name.borrow_mut().#field = std::rc::Rc::clone(&#target_name);
                        });
                    } else {
                         self.push_code(quote! {
                             #base_name.#field = #target_name;
                        });
                    }
                }
                LifeEvent::Spawn { thread_id, captured_vars } => {
                    let mut clones = Vec::new();
                    for var in captured_vars {
                         let var_name = self.get_var_ident(*var);
                         // Generate clone name based on original name if possible
                         let base_name = if let Some(name) = self.name_map.get(var) {
                             name.clone()
                         } else {
                             format!("var_{}", var.0)
                         };
                         let clone_name = format_ident!("{}_thread_{}", base_name, thread_id);

                         clones.push(quote! {
                             let #clone_name = std::sync::Arc::clone(&#var_name);
                         });

                         self.var_remap.insert((*thread_id, *var), clone_name);
                    }

                    self.push_code(quote! { #(#clones)* });

                    self.current_codegen_thread = *thread_id;
                    self.thread_buffers.insert(*thread_id, Vec::new());
                }
                LifeEvent::Join { thread_id } => {
                    let child_code = self.thread_buffers.remove(thread_id).unwrap_or_default();
                    self.current_codegen_thread = 0;

                    let handle_name = format_ident!("thread_handle_{}", thread_id);

                    self.push_code(quote! {
                        let #handle_name = std::thread::spawn(move || {
                            #(#child_code)*
                        });
                    });

                    self.push_code(quote! {
                        let _ = #handle_name.join();
                    });
                }
                LifeEvent::Move { from, to } => {
                    let var_to = self.get_var_ident(*to);
                    let var_from = self.get_var_ident(*from);
                    if self.active_allocations.contains(from) {
                        self.active_allocations.remove(from);
                        self.active_allocations.insert(*to);
                        self.push_code(quote! {
                            let #var_to = #var_from;
                        });
                    } else {
                         self.push_code(quote! {
                            let #var_to = &#var_from;
                        });
                    }
                }
                LifeEvent::Copy { from, to } => {
                     let var_to = self.get_var_ident(*to);
                     let var_from = self.get_var_ident(*from);

                     if to.0 == 204 {
                          self.push_code(quote! {
                             #var_to.push(std::sync::Arc::clone(&#var_from));
                         });
                     } else {
                         self.push_code(quote! {
                            let #var_to = #var_from.clone();
                        });
                     }
                }
                LifeEvent::Mutation { target } => {
                    let var_name = self.get_var_ident(*target);
                    if self.freed_resources.contains(target) {
                        self.unsafe_events_log.push(format!("Use-After-Free detected on var_{}", target.0));
                        self.push_code(quote! {
                            unsafe {
                                // ERROR: Use-After-Free detected! Manual intervention required.
                            }
                        });
                    } else {
                        if self.thread_safety.shared_mutable_vars.contains(target) {
                             if target.0 == 200 {
                                  self.push_code(quote! {
                                      // manager.increment_all();
                                  });
                             } else {
                                self.push_code(quote! {
                                    *#var_name.lock().unwrap() = 10;
                                });
                             }
                        } else {
                            let is_cycle = self.cycle_detector.cycles_detected.iter().any(|c| c.contains(target));
                            if is_cycle {
                                 self.push_code(quote! { /* Mutating via RefCell */ });
                            } else {
                                self.push_code(quote! {
                                    *#var_name = 10;
                                });
                            }
                        }
                    }
                }
                LifeEvent::Deallocation { target } => {
                    let var_name = self.get_var_ident(*target);
                     if self.active_allocations.contains(target) {
                        self.active_allocations.remove(target);
                        self.freed_resources.insert(*target);
                         if !self.thread_safety.shared_mutable_vars.contains(target) {
                            self.push_code(quote! {
                                drop(#var_name);
                            });
                         }
                    }
                }
                 LifeEvent::Offset { base, offset, .. } => {
                    self.split_trees.request_split(*base, *offset);
                    let splits = self.split_trees.generate_split_code(*base);
                    for split in splits {
                         let comment = format!("// {}", split);
                         self.push_code(quote! {
                             #[doc = #comment]
                             let _ = ();
                         });
                    }
                }
                _ => {}
            }
        }

        // Final Assembly
        let main_body = self.thread_buffers.get(&0).unwrap();

        let structs = if self.detected_resource_struct {
            quote! {
                #[derive(Default, Debug)]
                struct Resource {
                    value: i32,
                }
                impl Resource {
                    fn new(v: i32) -> Self { Self { value: v } }
                    fn increment(&mut self) { self.value += 1; }
                    fn get(&self) -> i32 { self.value }
                }

                fn compute_sum(vec: &Vec<std::sync::Arc<Resource>>) -> i32 {
                    let mut sum = 0;
                    for r in vec {
                        sum += r.get();
                    }
                    sum
                }
            }
        } else {
            quote! {}
        };

        // Inject External Linkage Block if FFI Detected
        let ffi_block = if self.unsafe_events_log.iter().any(|e| e.contains("FFI Call")) {
             // For prototype, we just inject a stub for known externs
             // In real world, we would collect unique external function names
             quote! {
                 extern "C" {
                     fn external_lib_call(arg: i32);
                 }
             }
        } else {
            quote! {}
        };

        // Wrap function body
        let main_fn = if let Some(fn_name_str) = &self.current_function_name {
             let fn_name = format_ident!("{}", fn_name_str);
             // Assume Result<(), ...> for void, hardcoded for demo
             quote! {
                fn #fn_name() -> Result<(), Box<dyn std::error::Error>> {
                    #(#main_body)*
                    Ok(())
                }
            }
        } else {
             quote! {
                fn main() {
                    #(#main_body)*
                }
            }
        };

        let result = quote! {
            #structs
            #ffi_block
            #main_fn
        };

        result.to_string()
    }
}
