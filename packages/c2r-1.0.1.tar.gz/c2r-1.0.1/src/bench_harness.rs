use std::time::Instant;
use crate::piir::AbstractLocationId;
use crate::analysis::andersen::AndersenSolver;

pub fn run_benchmark() {
    println!("Running Andersen Analysis Latency Benchmark...");

    let sizes = [100, 1000, 5000]; // 10k might be too slow for CI but we can try

    for &size in &sizes {
        let mut solver = AndersenSolver::new();
        let start_gen = Instant::now();

        // Generate worst-case chain: p1 = p2, p2 = p3, ... pn = alloc
        // This forces propagation through the whole chain.
        // Or even dense graph.

        let target_alloc = AbstractLocationId(size + 1);
        solver.add_allocation(target_alloc, target_alloc);

        for i in 0..size {
            let p = AbstractLocationId(i);
            let q = AbstractLocationId(i + 1);
            // p = q means q >= p? No.
            // p = q means Pts(q) <= Pts(p).
            // So if q points to something, p must too.
            // Chain: 0 <- 1 <- 2 ... <- size <- alloc
            solver.add_constraint(p, q);
        }

        let duration_gen = start_gen.elapsed();

        let start_solve = Instant::now();
        solver.solve();
        let duration_solve = start_solve.elapsed();

        println!("Size: {} pointers. Gen: {:?}. Solve: {:?}.", size, duration_gen, duration_solve);
    }
}
