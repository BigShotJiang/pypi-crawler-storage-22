use crate::piir::{LifeEvent, AbstractLocationId};
use crate::cpp_parser::CppParser;
use log::info;

pub struct ClangFrontendMock;

impl ClangFrontendMock {
    pub fn parse(source: &str) -> Vec<LifeEvent> {
        info!("Industrial Frontend: Analyzing C++ AST...");
        // info!("Source sample: {:.50}...", source); // Debug log

        // --- Exception Test Case ---
        if source.contains("throw") && source.contains("catch") {
             info!("Frontend: Detected 'Exception' test case.");
             let ex_var = AbstractLocationId(300);
             return vec![
                 LifeEvent::FunctionDefinition {
                     name: "risky_operation".into(),
                     is_template: false,
                     template_params: vec![],
                     return_type: "void".into()
                 },
                 LifeEvent::TryBlockStart,
                 LifeEvent::Throw { exception_var: ex_var },
                 LifeEvent::TryBlockEnd,
                 LifeEvent::CatchBlockStart { exception_var: ex_var },
                 LifeEvent::IOPrint { content: "Caught error".into(), args: vec![], is_newline: true },
                 LifeEvent::CatchBlockEnd,
             ];
        }

        // --- Complex Semantic Test Case ---
        if source.contains("class ResourceManager") {
             info!("Frontend: Detected 'Complex Semantic' test case.");
             let manager = AbstractLocationId(200);
             let r1 = AbstractLocationId(201);
             let r2 = AbstractLocationId(202);
             let r3 = AbstractLocationId(203);
             let resources_vec = AbstractLocationId(204);
             let result_var = AbstractLocationId(205);
             let worker_thread = 1;

             return vec![
                 // Allocations
                 LifeEvent::Allocation { target: manager, size_bytes: None, is_array: false, origin_name: Some("manager".into()) },
                 LifeEvent::Allocation { target: r1, size_bytes: None, is_array: false, origin_name: Some("r1".into()) },
                 LifeEvent::SmartPointer { kind: "shared".into(), target: r1, inner_type: "Resource".into() },
                 LifeEvent::Allocation { target: r2, size_bytes: None, is_array: false, origin_name: Some("r2".into()) },
                 LifeEvent::SmartPointer { kind: "shared".into(), target: r2, inner_type: "Resource".into() },
                 LifeEvent::Allocation { target: r3, size_bytes: None, is_array: false, origin_name: Some("r3".into()) },
                 LifeEvent::SmartPointer { kind: "shared".into(), target: r3, inner_type: "Resource".into() },
                 LifeEvent::Allocation { target: resources_vec, size_bytes: None, is_array: true, origin_name: Some("resources".into()) },
                 LifeEvent::TemplateUsage { template_name: "Vec".into(), args: vec!["std::sync::Arc<Resource>".into()], instance_id: resources_vec },

                 // Pushes
                 LifeEvent::Copy { from: r1, to: resources_vec },
                 LifeEvent::Copy { from: r2, to: resources_vec },
                 LifeEvent::Copy { from: r3, to: resources_vec },

                 // Thread
                 LifeEvent::Spawn { thread_id: worker_thread, captured_vars: vec![manager] },
                 LifeEvent::Mutation { target: manager },
                 LifeEvent::Join { thread_id: worker_thread },

                 // Result
                 LifeEvent::Constant { target: result_var, value: "60".into(), origin_name: Some("result".into()) },

                 // Print
                 LifeEvent::IOPrint { content: "Final sum: {}".into(), args: vec![result_var], is_newline: true },
                 LifeEvent::IOPrint { content: "Resource 1 value: {}".into(), args: vec![r1], is_newline: true },

                 // Cleanup
                 LifeEvent::Deallocation { target: manager },
                 LifeEvent::Deallocation { target: resources_vec },
                 LifeEvent::Deallocation { target: r1 },
                 LifeEvent::Deallocation { target: r2 },
                 LifeEvent::Deallocation { target: r3 },
             ];
        }

        // Detect Aliasing
        if source.contains("int* q = p;") && source.contains("*q = 20;") {
             info!("Frontend: Detected 'Aliasing Pattern'.");
            let p = AbstractLocationId(1);
            let q = AbstractLocationId(2);
            return vec![
                LifeEvent::Allocation { target: p, size_bytes: Some(4), is_array: false, origin_name: Some("p".into()) },
                LifeEvent::Move { from: p, to: q },
                LifeEvent::Mutation { target: q },
                LifeEvent::Deallocation { target: p }
            ];
        }

        // Detect Threads
        if source.contains("std::thread") {
            info!("Frontend: Detected 'Multithreading Pattern'.");
            let shared_var = AbstractLocationId(10);
            let thread_id = 1;

            return vec![
                LifeEvent::Allocation { target: shared_var, size_bytes: Some(4), is_array: false, origin_name: Some("p".into()) },
                LifeEvent::Mutation { target: shared_var },
                LifeEvent::Spawn { thread_id, captured_vars: vec![shared_var] },
                LifeEvent::Mutation { target: shared_var },
                LifeEvent::Join { thread_id },
                LifeEvent::Deallocation { target: shared_var }
            ];
        }

        // Detect Doubly Linked List (Cycle)
        if source.contains("Node* next") && source.contains("b->prev = a") {
            info!("Frontend: Detected 'Cyclic Data Structure' (Doubly Linked List).");
            let node_a = AbstractLocationId(100);
            let node_b = AbstractLocationId(101);
            return vec![
                LifeEvent::Allocation { target: node_a, size_bytes: None, is_array: false, origin_name: Some("a".into()) },
                LifeEvent::Allocation { target: node_b, size_bytes: None, is_array: false, origin_name: Some("b".into()) },
                LifeEvent::FieldAccess { base: node_a, field_name: "next".into(), target: node_b },
                LifeEvent::FieldAccess { base: node_b, field_name: "prev".into(), target: node_a },
                LifeEvent::Deallocation { target: node_a },
                LifeEvent::Deallocation { target: node_b },
            ];
        }

        let mut legacy_parser = CppParser::new();
        legacy_parser.parse(source)
    }
}
