use regex::Regex;
use crate::piir::{LifeEvent, AbstractLocationId};
use std::collections::HashMap;
use log::{info, debug};

pub struct CppParser {
    next_id: usize,
    var_map: HashMap<String, AbstractLocationId>,
}

impl CppParser {
    pub fn new() -> Self {
        Self {
            next_id: 1,
            var_map: HashMap::new(),
        }
    }

    fn get_or_create_var(&mut self, name: &str) -> AbstractLocationId {
        if let Some(id) = self.var_map.get(name) {
            *id // Copy is derived now
        } else {
            let id = AbstractLocationId(self.next_id);
            self.next_id += 1;
            self.var_map.insert(name.to_string(), id);
            debug!("Discovered new variable: {} -> {:?}", name, id);
            id
        }
    }

    pub fn parse(&mut self, source: &str) -> Vec<LifeEvent> {
        let mut events = Vec::new();

        // Regex patterns for simplified C++ parsing
        // int* p = new int(42);
        let re_alloc = Regex::new(r"(\w+)\s*\*\s*(\w+)\s*=\s*new\s+(\w+)").unwrap();
        // delete p;
        let re_delete = Regex::new(r"delete\s+(\w+)").unwrap();
        // *p = 10; (Mutation - Check BEFORE assignment to capture *p)
        let re_mutate = Regex::new(r"\*(\w+)\s*=").unwrap();
        // q = p; (Move/Copy - Check LAST)
        // Ensure LHS does not start with *
        let re_assign = Regex::new(r"^\s*(\w+)\s*=\s*(\w+)\s*;").unwrap();
        // int* q = p; (Pointer initialization copy)
        let re_ptr_init = Regex::new(r"(\w+)\s*\*\s*(\w+)\s*=\s*(\w+)\s*;").unwrap();

        for (line_no, line) in source.lines().enumerate() {
            let line = line.trim();
            if line.is_empty() || line.starts_with("//") {
                continue;
            }

            info!("Parsing line {}: {}", line_no + 1, line);

            if let Some(caps) = re_alloc.captures(line) {
                let var_name = caps.get(2).unwrap().as_str();
                let target_id = self.get_or_create_var(var_name);
                events.push(LifeEvent::Allocation {
                    target: target_id,
                    size_bytes: Some(4), // Assume int for now
                    is_array: false,
                    origin_name: None, // No Name Recovery for legacy parser
                });
                info!("Detected ALLOCATION for {}", var_name);
            } else if let Some(caps) = re_delete.captures(line) {
                let var_name = caps.get(1).unwrap().as_str();
                let target_id = self.get_or_create_var(var_name);
                events.push(LifeEvent::Deallocation {
                    target: target_id,
                });
                info!("Detected DEALLOCATION for {}", var_name);
            } else if let Some(caps) = re_mutate.captures(line) {
                let var_name = caps.get(1).unwrap().as_str();
                let target_id = self.get_or_create_var(var_name);
                events.push(LifeEvent::Mutation {
                    target: target_id,
                });
                info!("Detected MUTATION on {}", var_name);
            } else if let Some(caps) = re_assign.captures(line) {
                let lhs = caps.get(1).unwrap().as_str();
                let rhs = caps.get(2).unwrap().as_str();

                // Avoid matching "int* p = new..." again if simple regex overlaps
                // But re_alloc is checked first, so this is just a backup check
                if !line.contains("new") {
                    let to_id = self.get_or_create_var(lhs);
                    let from_id = self.get_or_create_var(rhs);
                    events.push(LifeEvent::Move {
                        from: from_id,
                        to: to_id,
                    });
                    info!("Detected MOVE from {} to {}", rhs, lhs);
                }
            } else if let Some(caps) = re_ptr_init.captures(line) {
                 // int* q = p;
                 let lhs = caps.get(2).unwrap().as_str();
                 let rhs = caps.get(3).unwrap().as_str();

                 if !line.contains("new") {
                    let to_id = self.get_or_create_var(lhs);
                    let from_id = self.get_or_create_var(rhs);
                    events.push(LifeEvent::Move {
                        from: from_id,
                        to: to_id,
                    });
                    info!("Detected POINTER INIT COPY from {} to {}", rhs, lhs);
                 }
            }
        }

        events
    }
}
