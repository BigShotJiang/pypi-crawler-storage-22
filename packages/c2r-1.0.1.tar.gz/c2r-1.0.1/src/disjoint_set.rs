use std::collections::HashMap;
use std::hash::Hash;

#[derive(Debug, Clone)]
pub struct UnionFind<T: Eq + Hash + Clone> {
    parent: HashMap<T, T>,
    rank: HashMap<T, usize>,
}

impl<T: Eq + Hash + Clone> UnionFind<T> {
    pub fn new() -> Self {
        Self {
            parent: HashMap::new(),
            rank: HashMap::new(),
        }
    }

    pub fn make_set(&mut self, x: T) {
        if !self.parent.contains_key(&x) {
            self.parent.insert(x.clone(), x.clone());
            self.rank.insert(x, 0);
        }
    }

    pub fn find(&mut self, x: &T) -> T {
        if !self.parent.contains_key(x) {
            self.make_set(x.clone());
        }

        // Find root
        let mut root = x.clone();
        while let Some(p) = self.parent.get(&root) {
            if p == &root {
                break;
            }
            root = p.clone();
        }

        // Path compression
        let mut curr = x.clone();
        while let Some(p) = self.parent.get(&curr) {
            if p == &root {
                break;
            }
            let next = p.clone();
            self.parent.insert(curr, root.clone());
            curr = next;
        }

        root
    }

    pub fn union(&mut self, x: &T, y: &T) {
        let root_x = self.find(x);
        let root_y = self.find(y);

        if root_x != root_y {
            let rank_x = *self.rank.get(&root_x).unwrap();
            let rank_y = *self.rank.get(&root_y).unwrap();

            if rank_x < rank_y {
                self.parent.insert(root_x, root_y);
            } else if rank_x > rank_y {
                self.parent.insert(root_y, root_x);
            } else {
                self.parent.insert(root_y, root_x.clone());
                self.rank.insert(root_x, rank_x + 1);
            }
        }
    }

    pub fn same_set(&mut self, x: &T, y: &T) -> bool {
        self.find(x) == self.find(y)
    }
}
