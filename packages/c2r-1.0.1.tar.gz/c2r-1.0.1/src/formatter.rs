use std::process::{Command, Stdio};
use std::io::Write;

pub fn format_rust_code(code: &str) -> String {
    let mut child = Command::new("rustfmt")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .spawn();

    if let Ok(mut child) = child {
        if let Some(mut stdin) = child.stdin.take() {
            let _ = stdin.write_all(code.as_bytes());
        }
        if let Ok(output) = child.wait_with_output() {
            if output.status.success() {
                return String::from_utf8_lossy(&output.stdout).to_string();
            }
        }
    }

    // Fallback: Basic Indentation
    let mut formatted = String::new();
    let mut indent = 0;
    for char in code.chars() {
        if char == '{' {
            formatted.push(char);
            formatted.push('\n');
            indent += 1;
            formatted.push_str(&"    ".repeat(indent));
        } else if char == '}' {
            formatted.push('\n');
            indent = indent.saturating_sub(1);
            formatted.push_str(&"    ".repeat(indent));
            formatted.push(char);
        } else if char == ';' {
            formatted.push(char);
            formatted.push('\n');
            formatted.push_str(&"    ".repeat(indent));
        } else {
            formatted.push(char);
        }
    }
    formatted
}
