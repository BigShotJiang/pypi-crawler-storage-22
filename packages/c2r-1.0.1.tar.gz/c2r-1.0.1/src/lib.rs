use pyo3::prelude::*;
use serde_json;

mod piir;
mod cpp_parser;
mod analyzer;
mod disjoint_set;
mod analysis;
mod clang_frontend_mock;
mod formatter;
pub mod bench_harness;

use clang_frontend_mock::ClangFrontendMock;
use analyzer::Analyzer;

/// A Python module implemented in Rust.
#[pymodule]
fn c2r_core(_py: Python, m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Register the class
    m.add_class::<PyReconstructor>()?;
    // Setup logging function
    m.add_function(wrap_pyfunction!(init_logging, m)?)?;
    Ok(())
}

#[pyfunction]
fn init_logging() {
    let _ = env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).try_init();
}

#[pyclass(name = "Reconstructor")]
struct PyReconstructor;

#[pymethods]
impl PyReconstructor {
    #[new]
    fn new() -> Self {
        PyReconstructor
    }

    /// Transpiles C++ code string to Rust, returning the result and logging analysis steps.
    fn translate(&self, source_code: String) -> String {
        let mut analyzer = Analyzer::new();
        let events = ClangFrontendMock::parse(&source_code);
        let output = analyzer.analyze(&events);
        formatter::format_rust_code(&output)
    }

    /// Analyzes the code and returns a JSON report including metrics and the generated code.
    fn analyze_report(&self, source_code: String) -> String {
        let mut analyzer = Analyzer::new();
        let events = ClangFrontendMock::parse(&source_code);
        let mut report = analyzer.analyze_and_report(&events);

        // Format the code in the report
        report.generated_code = formatter::format_rust_code(&format!("// Transpiled via Industrial Engine\n// Safety Score: {:.2}%\n{}", report.safety_score, report.generated_code));

        serde_json::to_string(&report).unwrap_or_default()
    }
}
