use std::collections::HashSet;

/// Identificador único de uma Localização Abstrata (LA).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct AbstractLocationId(pub usize);

/// Identificador de Região (Tofte-Talpin).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct RegionId(pub usize);

/// Nível de segurança para geração de código.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SafetyLevel {
    Safe,
    Unsafe,
    FFI,
}

/// Representa um objeto de memória no grafo.
#[derive(Debug, Clone)]
#[allow(dead_code)]
pub struct AbstractLocation {
    pub id: AbstractLocationId,
    pub debug_info: String,
    pub is_heap: bool, // Heap vs Stack
}

/// Eventos de Vida que compõem a PIIR (Expandido para Nível Industrial).
#[derive(Debug, Clone)]
#[allow(dead_code)]
pub enum LifeEvent {
    // --- Basic Memory ---
    Allocation {
        target: AbstractLocationId,
        size_bytes: Option<usize>,
        is_array: bool,
        origin_name: Option<String>, // Name Recovery
    },
    Move {
        from: AbstractLocationId,
        to: AbstractLocationId,
    },
    Copy {
        from: AbstractLocationId,
        to: AbstractLocationId,
    },
    Mutation {
        target: AbstractLocationId,
    },
    Deallocation {
        target: AbstractLocationId,
    },

    // --- Scopes & Control Flow (Tofte-Talpin) ---
    EnterScope {
        region_id: RegionId,
    },
    ExitScope {
        region_id: RegionId,
    },

    // --- Pointer Arithmetic (Split Trees) ---
    Offset {
        base: AbstractLocationId,
        target: AbstractLocationId, // The resulting pointer
        offset: isize,
    },

    // --- OO & Structs ---
    FieldAccess {
        base: AbstractLocationId,
        field_name: String,
        target: AbstractLocationId, // Pointer to the field
    },
    ClassDefinition {
        name: String,
        base_class: Option<String>,
        fields: Vec<(String, String)>, // name, type
    },

    // --- Function Boundaries ---
    FunctionCall {
        function_name: String,
        args: Vec<AbstractLocationId>,
        ret: Option<AbstractLocationId>,
    },
    FunctionDefinition {
        name: String,
        is_template: bool,
        template_params: Vec<String>,
        return_type: String, // "Result<T, E>" handled in Analyzer
    },

    // --- Exceptions ---
    TryBlockStart,
    TryBlockEnd,
    CatchBlockStart {
        exception_var: AbstractLocationId,
    },
    CatchBlockEnd,
    Throw {
        exception_var: AbstractLocationId,
    },

    // --- External / FFI ---
    ExternalCall {
        function_name: String,
        args: Vec<AbstractLocationId>,
    },

    // --- Threading ---
    Spawn {
        thread_id: usize,
        captured_vars: Vec<AbstractLocationId>,
    },
    Join {
        thread_id: usize,
    },

    // --- Smart Pointers & Templates ---
    SmartPointer {
        kind: String, // "unique" or "shared"
        target: AbstractLocationId,
        inner_type: String, // e.g., "int", "Node"
    },
    TemplateUsage {
        template_name: String, // "std::vector"
        args: Vec<String>, // ["int"]
        instance_id: AbstractLocationId,
    },
    TemplateDefinition {
        name: String,
        params: Vec<String>,
    },
    OperatorUsage {
        op: String, // "+", "=="
        lhs: AbstractLocationId,
        rhs: AbstractLocationId,
    },

    // --- Semantic I/O ---
    IOPrint {
        content: String, // Format string or variable
        args: Vec<AbstractLocationId>,
        is_newline: bool,
    },
    // --- Primitives (for simple constants/results) ---
    Constant {
        target: AbstractLocationId,
        value: String, // "0", "10", "true"
        origin_name: Option<String>,
    },
}

#[derive(Debug, Clone)]
pub struct Provenance {
    pub possible_locations: HashSet<AbstractLocationId>,
}

impl Provenance {
    pub fn new() -> Self {
        Self {
            possible_locations: HashSet::new(),
        }
    }
    pub fn add_location(&mut self, loc: AbstractLocationId) {
        self.possible_locations.insert(loc);
    }
}
