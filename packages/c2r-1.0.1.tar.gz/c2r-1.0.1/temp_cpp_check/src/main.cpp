#include <thread>
#include <vector>
#include <memory>
#include "math/vector.h"

void main() {
    std::shared_ptr<int> shared_counter = std::make_shared<int>(0);
    std::thread t([&]() {
        *shared_counter = 1;
    });
    t.join();
}
