template<typename T>
class Vector {
public:
    T add(T a, T b) { return a + b; }
};
