void main() {
    int* p = new int(42);
    *p = 10;
    delete p;
}
