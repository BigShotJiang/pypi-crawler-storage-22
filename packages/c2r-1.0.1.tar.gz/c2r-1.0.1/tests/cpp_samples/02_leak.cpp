void main() {
    int* p = new int(100);
    int* q = p;
    // Missing delete p or q
}
