void main() {
    int* p = new int(5);
    delete p;
    delete p; // Error
}
