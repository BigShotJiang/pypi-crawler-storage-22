int* p = new int(1);
int* q = p;
*q = 20;
delete p;
