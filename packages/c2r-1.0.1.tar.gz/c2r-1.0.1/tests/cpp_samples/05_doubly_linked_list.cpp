struct Node {
    Node* next;
    Node* prev;
};

void main() {
    Node* a = new Node();
    Node* b = new Node();
    a->next = b;
    b->prev = a; // Cycle!
    delete a;
    delete b;
}
