#include <thread>

void main() {
    int* p = new int(0);
    std::thread t([&]() {
        *p = 10;
    });
    t.join();
    delete p;
}
