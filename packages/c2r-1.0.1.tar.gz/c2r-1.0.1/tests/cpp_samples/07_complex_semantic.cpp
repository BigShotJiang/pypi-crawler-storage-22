#include <iostream>
#include <vector>
#include <memory>
#include <thread>
#include <mutex>
#include <unordered_map>
#include <functional>

class Resource {
public:
    explicit Resource(int v) : value(v) {}
    void increment() { value++; }
    int get() const { return value; }
private:
    int value;
};

class ResourceManager {
public:
    std::shared_ptr<Resource> create(int v) {
        auto res = std::make_shared<Resource>(v);
        resources[res.get()] = res;
        return res;
    }

    void increment_all() {
        std::lock_guard<std::mutex> lock(mtx);
        for (auto& [ptr, res] : resources) {
            res->increment();
        }
    }

private:
    std::mutex mtx;
    std::unordered_map<void*, std::shared_ptr<Resource>> resources;
};

int compute_sum(const std::vector<std::shared_ptr<Resource>>& vec) {
    int sum = 0;
    for (const auto& r : vec) {
        sum += r->get();
    }
    return sum;
}

int main() {
    ResourceManager manager;

    auto r1 = manager.create(10);
    auto r2 = manager.create(20);
    auto r3 = manager.create(30);

    std::vector<std::shared_ptr<Resource>> resources = { r1, r2, r3 };

    std::thread worker([&manager]() {
        for (int i = 0; i < 5; ++i) {
            manager.increment_all();
        }
    });

    worker.join();

    int result = compute_sum(resources);
    std::cout << "Final sum: " << result << std::endl;

    // Lambda capturing shared_ptr
    auto printer = [r1]() {
        std::cout << "Resource 1 value: " << r1->get() << std::endl;
    };

    printer();

    return 0;
}
