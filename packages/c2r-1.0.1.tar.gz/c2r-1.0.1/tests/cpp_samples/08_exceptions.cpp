void risky_operation() {
    throw std::runtime_error("Error");
}

void main() {
    try {
        risky_operation();
    } catch (const std::exception& e) {
        std::cout << "Caught error" << std::endl;
    }
}
