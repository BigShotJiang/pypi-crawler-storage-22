// Transpiled via Industrial Engine
// Safety Score: 100.00%
#[derive(Default, Debug)]
struct Resource {
    value: i32,
}
impl Resource {
    fn new(v: i32) -> Self {
        Self { value: v }
    }
    fn increment(&mut self) {
        self.value += 1;
    }
    fn get(&self) -> i32 {
        self.value
    }
}
fn compute_sum(vec: &Vec<std::sync::Arc<Resource>>) -> i32 {
    let mut sum = 0;
    for r in vec {
        sum += r.get();
    }
    sum
}
fn main() {
    let mut var_200 = std::sync::Arc::new(std::sync::Mutex::new(0));
    let var_201: std::sync::Arc<Resource> = std::sync::Arc::new(Default::default());
    let var_202: std::sync::Arc<Resource> = std::sync::Arc::new(Default::default());
    let var_203: std::sync::Arc<Resource> = std::sync::Arc::new(Default::default());
    let mut var_204: Vec<std::sync::Arc<Resource>> = Vec::new();
    var_204.push(std::sync::Arc::clone(&var_201));
    var_204.push(std::sync::Arc::clone(&var_202));
    var_204.push(std::sync::Arc::clone(&var_203));
    let var_200_thread_1 = std::sync::Arc::clone(&var_200);
    let thread_handle_1 = std::thread::spawn(move || {
        // manager.increment_all();
    });
    let _ = thread_handle_1.join();
    let var_205 = 60;
    println!("Final sum: {:?}", var_205);
    println!("Resource 1 value: {:?}", var_201);
    drop(var_200);
    drop(var_204);
    drop(var_201);
    drop(var_202);
    drop(var_203);
}
