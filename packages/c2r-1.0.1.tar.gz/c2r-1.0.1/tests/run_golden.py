import os
import sys
import glob
import subprocess
import difflib

# Ensure module is built and path is set (reuse run_demo logic if needed)
sys.path.append(os.getcwd())

try:
    import c2r_core as c2r
except ImportError:
    print("Error: c2r_core not found. Run cargo build first.")
    sys.exit(1)

def normalize(code):
    return "\n".join([line.rstrip() for line in code.strip().splitlines()])

def run_golden_tests():
    c2r.init_logging()
    reconstructor = c2r.Reconstructor()

    golden_dir = "tests/golden"
    input_dir = "tests/cpp_samples"

    # Map input file to golden file
    # For now only testing 07 because others have changing output names (var_X) that might differ if logic changes
    test_cases = {
        "07_complex_semantic.cpp": "07_complex_semantic.rs"
    }

    failed = False

    for cpp_file, rs_file in test_cases.items():
        cpp_path = os.path.join(input_dir, cpp_file)
        golden_path = os.path.join(golden_dir, rs_file)

        print(f"Running Golden Test: {cpp_file} -> {rs_file} ... ", end="")

        if not os.path.exists(golden_path):
            print("SKIPPED (Golden file missing)")
            continue

        with open(cpp_path, 'r') as f:
            cpp_code = f.read()

        with open(golden_path, 'r') as f:
            expected_code = normalize(f.read())

        generated_code = normalize(reconstructor.translate(cpp_code))

        if generated_code == expected_code:
            print("PASS")
        else:
            print("FAIL")
            failed = True
            print("--- Diff ---")
            diff = difflib.unified_diff(
                expected_code.splitlines(),
                generated_code.splitlines(),
                fromfile="Expected",
                tofile="Generated",
                lineterm=""
            )
            for line in diff:
                print(line)
            print("------------")

    if failed:
        sys.exit(1)

if __name__ == "__main__":
    run_golden_tests()
