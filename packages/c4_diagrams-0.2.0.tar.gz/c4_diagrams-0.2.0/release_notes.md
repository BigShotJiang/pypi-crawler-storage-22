## 0.2.0 (2026-02-15)

### Feat

- **core**: refactor init args for diagram components
- **cli**: add c4 cli

