## 0.3.0 (2026-02-16)

### Feat

- **core**: improve index macros
- **plantuml**: add new c4 style support

