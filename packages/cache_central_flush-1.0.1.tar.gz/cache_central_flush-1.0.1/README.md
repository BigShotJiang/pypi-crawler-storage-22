# cache_central_flush

A lightweight client package to asynchronously trigger centralized
Redis and CDN cache invalidation via API.

## Usage

```python
from cache_central_flush import flush_cache

flush_cache(entity_id=123, entity_type="college", WEB_API_KEY)
