import threading
from .client import central_cache_flush

def flush_cache(entity_id, entity_type, APIKEY):
    """
    Public method used by all services
    """
    threading.Thread(target=central_cache_flush,args=(entity_id, entity_type, APIKEY),daemon=True,).start()
