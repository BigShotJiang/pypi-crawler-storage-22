import os
import requests

def _get_api_url():
    base_url = "https://api.careers360.com/"
    if not base_url:
        raise RuntimeError("CNEXT_BACKEND_SERVICE env not set")
    return f"{base_url}api/1/common-cdn-invalidate"


def central_cache_flush(entity_id, entity_type, APIKEY):
    payload = {
        "entity_id": entity_id,
        "entity_type": entity_type,
    }

    headers = {
        "Content-Type": "application/json",
        "x-api-key": APIKEY,
    }

    try:
        requests.post(
            _get_api_url(),
            json=payload,
            headers=headers,
            timeout=2,
        )
    except Exception:
        # fire-and-forget: don't break caller
        pass
