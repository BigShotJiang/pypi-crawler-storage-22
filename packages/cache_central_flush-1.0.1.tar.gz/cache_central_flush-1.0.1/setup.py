from setuptools import setup, find_packages

setup(
    name="cache_central_flush",
    version="1.0.1",
    description="Lightweight client package to asynchronously trigger centralized cache invalidation via API",
    packages=find_packages(),
    install_requires=[
        "requests>=2.20,<3",
    ],
    python_requires=">=3.6",
)
