"""Framework adapters for cacheql."""
