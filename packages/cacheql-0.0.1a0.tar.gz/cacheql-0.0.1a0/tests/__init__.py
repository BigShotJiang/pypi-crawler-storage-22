"""Tests for cacheql."""
