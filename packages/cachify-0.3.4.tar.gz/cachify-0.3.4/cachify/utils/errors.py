class CacheKeyError(ValueError):
    pass
