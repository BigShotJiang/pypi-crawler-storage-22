import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import CompanyBase, CompanyBaseModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Retrieve details of a specific company")
async def show(
    ctx: typer.Context,
    company_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = CompanyBase(conn, api_schema)
            model = await ctrl.fetch(company_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Update a company's attributes")
async def update(
    ctx: typer.Context,
    company_id: Annotated[UUID, typer.Argument(help="Resource ID to update")],
    name: Annotated[
        Optional[str], typer.Option(help="Company name (must be unique)")
    ] = None,
    kvknr: Annotated[
        Optional[str], typer.Option(help="Chamber of Commerce registration number")
    ] = None,
    phone: Annotated[
        Optional[str], typer.Option(help="Phone number from NL, BE, DE, GB or US")
    ] = None,
    email: Annotated[
        Optional[str],
        typer.Option(help="Company email address (validated with DNS check)"),
    ] = None,
    email_invoice: Annotated[
        Optional[str],
        typer.Option(help="Email for invoicing (defaults to email if not given)"),
    ] = None,
    vat_number: Annotated[
        Optional[str], typer.Option(help="VAT number (validated if provided)")
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = CompanyBase(conn, api_schema)
            model = await ctrl.fetch(company_id)
            if name is not None:
                model["name"] = name
            if kvknr is not None:
                model["kvknr"] = kvknr
            if phone is not None:
                model["phone"] = phone
            if email is not None:
                model["email"] = email
            if email_invoice is not None:
                model["email_invoice"] = email_invoice
            if vat_number is not None:
                model["vat_number"] = vat_number
            await ctrl.update(model)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(name="list-addresses", help="List all addresses for a company")
async def list_addresses(
    ctx: typer.Context,
    company_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
    street: Annotated[
        Optional[str],
        typer.Option(
            help="Can contain any letter (combined with accent) from any language, any kind of hyphen or dash, single or alternative quote or space."
        ),
    ] = None,
    number: Annotated[
        Optional[str], typer.Option(help="Can contain any number from any language.")
    ] = None,
    suffix: Annotated[
        Optional[str],
        typer.Option(
            help="Can contain any letter or number from any language or space."
        ),
    ] = None,
    zipcode: Annotated[
        Optional[str],
        typer.Option(help="Must contain valid zipcode from NL,BE,DE,GB or US."),
    ] = None,
    city: Annotated[
        Optional[str],
        typer.Option(help="Can contain any letter from any language or space."),
    ] = None,
    state: Annotated[
        Optional[str],
        typer.Option(
            help="Can contain any letter (combined with accent) from any language, any kind of hyphen or dash, single or alternative quote or space."
        ),
    ] = None,
    country: Annotated[
        Optional[str], typer.Option(help="Must contain two uppercase letters (A-Z).")
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the address was created. (exact match)"),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the address was created. (greater than or equal)"
        ),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the address was created. (less than or equal)"
        ),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the address was created. (greater than)"),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the address was created. (less than)"),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the address was last updated. (exact match)"),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the address was last updated. (greater than or equal)"
        ),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the address was last updated. (less than or equal)"
        ),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the address was last updated. (greater than)"
        ),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the address was last updated. (less than)"),
    ] = None,
    user: Annotated[
        Optional[UUID], typer.Option(help="The user associated with this address.")
    ] = None,
    company: Annotated[
        Optional[UUID], typer.Option(help="The company associated with this address.")
    ] = None,
):
    """List all addresses for a company"""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = CompanyBase(conn, api_schema)
            parent_model = await parent_ctrl.fetch(company_id)

            # Build modifier for filtering and includes
            modifier = []
            if street is not None:
                modifier.append(Filter(street=street))
            if number is not None:
                modifier.append(Filter(number=number))
            if suffix is not None:
                modifier.append(Filter(suffix=suffix))
            if zipcode is not None:
                modifier.append(Filter(zipcode=zipcode))
            if city is not None:
                modifier.append(Filter(city=city))
            if state is not None:
                modifier.append(Filter(state=state))
            if country is not None:
                modifier.append(Filter(country=country))
            if created_at is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at]="
                        + created_at.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_gte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_gte]="
                        + created_at_gte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_lte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_lte]="
                        + created_at_lte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_gt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_gt]="
                        + created_at_gt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_lt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_lt]="
                        + created_at_lt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at]="
                        + updated_at.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_gte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_gte]="
                        + updated_at_gte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_lte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_lte]="
                        + updated_at_lte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_gt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_gt]="
                        + updated_at_gt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_lt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_lt]="
                        + updated_at_lt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if user is not None:
                modifier.append(Filter(user=str(user)))
            if company is not None:
                modifier.append(Filter(company=str(company)))

            # Table definition
            tabledef: TableDef = [
                {"header": Column("Id", no_wrap=True), "column": "id"},
                {"header": "Id", "column": "id"},
                {"header": "Street", "column": "street"},
                {"header": "City", "column": "city"},
                {"header": "Country", "column": "country"},
                {"header": "Created", "column": "created_at"},
                {"header": "Updated", "column": "updated_at"},
            ]

            # List related resources
            await list_relation_resources(
                ctx, parent_model, "addresses", tabledef, modifier
            )
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(
    name="show-account", help="Retrieve the account associated with a company"
)
async def show_account(
    ctx: typer.Context,
    company_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
):
    """Retrieve the account associated with a company"""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = CompanyBase(conn, api_schema)
            parent_model = await parent_ctrl.fetch(company_id)

            # Fetch and show related resource
            await parent_model["account"].fetch()
            related = parent_model["account"].resource

            show_resource(ctx, related)
    except DocumentError as e:
        await print_document_error(e)
