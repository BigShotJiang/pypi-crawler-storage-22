from typing import Optional
from .common import BaseController, BaseModel


class AddressBaseModel(BaseModel):
    pass


class AddressBase(BaseController[AddressBaseModel]):
    _class = AddressBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "addresses"

        super().__init__(connection, api_schema)
