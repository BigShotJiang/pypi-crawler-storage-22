from typing import Optional
from .common import BaseController, BaseModel


class CompanyBaseModel(BaseModel):
    pass


class CompanyBase(BaseController[CompanyBaseModel]):
    _class = CompanyBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "companies"

        super().__init__(connection, api_schema)
