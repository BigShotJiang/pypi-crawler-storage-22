from typing import Optional
from .common import BaseController, BaseModel


class CompanyUpdateModel(BaseModel):
    pass


class CompanyUpdate(BaseController[CompanyUpdateModel]):
    _class = CompanyUpdateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "companies"

        super().__init__(connection, api_schema)
