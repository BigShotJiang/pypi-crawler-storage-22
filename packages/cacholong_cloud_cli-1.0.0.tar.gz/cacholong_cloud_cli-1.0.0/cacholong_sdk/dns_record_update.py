from typing import Optional
from .common import BaseController, BaseModel


class DnsRecordUpdateModel(BaseModel):
    pass


class DnsRecordUpdate(BaseController[DnsRecordUpdateModel]):
    _class = DnsRecordUpdateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-records"

        super().__init__(connection, api_schema)
