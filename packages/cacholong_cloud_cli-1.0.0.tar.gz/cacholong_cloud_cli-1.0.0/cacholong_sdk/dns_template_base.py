from typing import Optional
from .common import BaseController, BaseModel


class DnsTemplateBaseModel(BaseModel):
    pass


class DnsTemplateBase(BaseController[DnsTemplateBaseModel]):
    _class = DnsTemplateBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-templates"

        super().__init__(connection, api_schema)
