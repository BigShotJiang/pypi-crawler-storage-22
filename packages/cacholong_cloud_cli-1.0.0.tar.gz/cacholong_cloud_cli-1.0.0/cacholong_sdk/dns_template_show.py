from typing import Optional
from .common import BaseController, BaseModel


class DnsTemplateShowModel(BaseModel):
    pass


class DnsTemplateShow(BaseController[DnsTemplateShowModel]):
    _class = DnsTemplateShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-templates"

        super().__init__(connection, api_schema)
