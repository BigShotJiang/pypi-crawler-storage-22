from typing import Optional
from .common import BaseController, BaseModel


class DnsZoneBaseModel(BaseModel):
    pass


class DnsZoneBase(BaseController[DnsZoneBaseModel]):
    _class = DnsZoneBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-zones"

        super().__init__(connection, api_schema)
