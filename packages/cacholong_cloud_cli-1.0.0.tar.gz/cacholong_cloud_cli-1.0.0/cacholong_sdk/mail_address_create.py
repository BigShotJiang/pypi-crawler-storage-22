from typing import Optional
from .common import BaseController, BaseModel


class MailAddressCreateModel(BaseModel):
    pass


class MailAddressCreate(BaseController[MailAddressCreateModel]):
    _class = MailAddressCreateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-addresses"

        super().__init__(connection, api_schema)
