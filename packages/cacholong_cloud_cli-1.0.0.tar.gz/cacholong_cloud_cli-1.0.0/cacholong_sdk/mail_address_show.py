from typing import Optional
from .common import BaseController, BaseModel


class MailAddressShowModel(BaseModel):
    pass


class MailAddressShow(BaseController[MailAddressShowModel]):
    _class = MailAddressShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-addresses"

        super().__init__(connection, api_schema)
