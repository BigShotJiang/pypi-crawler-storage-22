from typing import Optional
from .common import BaseController, BaseModel


class UserShowModel(BaseModel):
    pass


class UserShow(BaseController[UserShowModel]):
    _class = UserShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "users"

        super().__init__(connection, api_schema)
