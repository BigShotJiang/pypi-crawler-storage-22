"""Cache backend implementations.
"""
