import OCP.Cocoa
from typing import *
from typing import Iterable as iterable
from typing import Iterator as iterator
from numpy import float64
_Shape = Tuple[int, ...]
import io
import OCP.Aspect
import OCP.TCollection
import OCP.Quantity
import OCP.Standard
import OCP.Graphic3d
__all__  = [
"Cocoa_LocalPool",
"Cocoa_Window"
]
class Cocoa_LocalPool():
    """
    Auxiliary class to create local pool.
    """
    def __init__(self) -> None: ...
    pass
class Cocoa_Window(OCP.Aspect.Aspect_Window, OCP.Standard.Standard_Transient):
    """
    This class defines Cocoa windowThis class defines Cocoa window
    """
    def Background(self) -> OCP.Aspect.Aspect_Background: 
        """
        Returns the window background.
        """
    def BackgroundFillMethod(self) -> OCP.Aspect.Aspect_FillMethod: 
        """
        Returns the current image background fill mode.
        """
    def ConvertPointFromBacking(self,thePnt : OCP.Graphic3d.Graphic3d_Vec2d) -> OCP.Graphic3d.Graphic3d_Vec2d: 
        """
        Convert point from backing store units to logical units.
        """
    def ConvertPointToBacking(self,thePnt : OCP.Graphic3d.Graphic3d_Vec2d) -> OCP.Graphic3d.Graphic3d_Vec2d: 
        """
        Convert point from logical units into backing store units.
        """
    def DecrementRefCounter(self) -> int: 
        """
        Decrements the reference counter of this object; returns the decremented value
        """
    def Delete(self) -> None: 
        """
        Memory deallocator for transient classes
        """
    def DevicePixelRatio(self) -> float: 
        """
        Return device pixel ratio (logical to backing store scale factor).
        """
    def Dimensions(self) -> OCP.Graphic3d.Graphic3d_Vec2i: 
        """
        Returns window dimensions.
        """
    def DisplayConnection(self) -> OCP.Aspect.Aspect_DisplayConnection: 
        """
        Returns connection to Display or NULL.
        """
    def DoMapping(self) -> bool: 
        """
        Apply the mapping change to the window <me>
        """
    def DoResize(self) -> OCP.Aspect.Aspect_TypeOfResize: 
        """
        Applies the resizing to the window <me>
        """
    def DumpJson(self,theOStream : io.BytesIO,theDepth : int=-1) -> None: 
        """
        Dumps the content of me into the stream
        """
    def DynamicType(self) -> OCP.Standard.Standard_Type: ...
    def GetRefCount(self) -> int: 
        """
        Get the reference counter of this object
        """
    def GradientBackground(self) -> OCP.Aspect.Aspect_GradientBackground: 
        """
        Returns the window gradient background.
        """
    def HView(self) -> NSView: 
        """
        Returns associated NSView
        """
    def IncrementRefCounter(self) -> None: 
        """
        Increments the reference counter of this object
        """
    def InvalidateContent(self,theDisp : OCP.Aspect.Aspect_DisplayConnection=None) -> None: 
        """
        Invalidate entire window content by setting NSView::setNeedsDisplay property. Call will be implicitly redirected to the main thread when called from non-GUI thread.
        """
    @overload
    def IsInstance(self,theType : OCP.Standard.Standard_Type) -> bool: 
        """
        Returns a true value if this is an instance of Type.

        Returns a true value if this is an instance of TypeName.
        """
    @overload
    def IsInstance(self,theTypeName : str) -> bool: ...
    @overload
    def IsKind(self,theType : OCP.Standard.Standard_Type) -> bool: 
        """
        Returns true if this is an instance of Type or an instance of any class that inherits from Type. Note that multiple inheritance is not supported by OCCT RTTI mechanism.

        Returns true if this is an instance of TypeName or an instance of any class that inherits from TypeName. Note that multiple inheritance is not supported by OCCT RTTI mechanism.
        """
    @overload
    def IsKind(self,theTypeName : str) -> bool: ...
    def IsMapped(self) -> bool: 
        """
        Returns True if the window <me> is opened
        """
    def IsVirtual(self) -> bool: 
        """
        Returns True if the window <me> is virtual
        """
    def Map(self) -> None: 
        """
        Opens the window <me>
        """
    def NativeFBConfig(self) -> __GLXFBConfigRec: 
        """
        Returns nothing on OS X
        """
    def NativeHandle(self) -> int: 
        """
        Returns native Window handle
        """
    def NativeParentHandle(self) -> int: 
        """
        Returns parent of native Window handle
        """
    def Position(self) -> tuple[int, int, int, int]: 
        """
        Returns The Window POSITION in PIXEL
        """
    def Ratio(self) -> float: 
        """
        Returns The Window RATIO equal to the physical WIDTH/HEIGHT dimensions
        """
    @overload
    def SetBackground(self,theBack : OCP.Aspect.Aspect_Background) -> None: 
        """
        Modifies the window background.

        Modifies the window background.

        Modifies the window gradient background.

        Modifies the window gradient background.
        """
    @overload
    def SetBackground(self,theColor : OCP.Quantity.Quantity_Color) -> None: ...
    @overload
    def SetBackground(self,theBackground : OCP.Aspect.Aspect_GradientBackground) -> None: ...
    @overload
    def SetBackground(self,theFirstColor : OCP.Quantity.Quantity_Color,theSecondColor : OCP.Quantity.Quantity_Color,theFillMethod : OCP.Aspect.Aspect_GradientFillMethod) -> None: ...
    def SetHView(self,theView : NSView) -> None: 
        """
        Setup new NSView.
        """
    def SetTitle(self,theTitle : OCP.TCollection.TCollection_AsciiString) -> None: 
        """
        Sets window title.
        """
    def SetVirtual(self,theVirtual : bool) -> None: 
        """
        Setup the virtual state
        """
    def Size(self) -> tuple[int, int]: 
        """
        Returns The Window SIZE in PIXEL
        """
    def This(self) -> OCP.Standard.Standard_Transient: 
        """
        Returns non-const pointer to this object (like const_cast). For protection against creating handle to objects allocated in stack or call from constructor, it will raise exception Standard_ProgramError if reference counter is zero.
        """
    def TopLeft(self) -> OCP.Graphic3d.Graphic3d_Vec2i: 
        """
        Returns window top-left corner.
        """
    def Unmap(self) -> None: 
        """
        Closes the window <me>
        """
    @staticmethod
    def VirtualKeyFromNative_s(theKey : int) -> int: 
        """
        Convert Carbon virtual key into Aspect_VKey.
        """
    @overload
    def __init__(self,theTitle : str,thePxLeft : int,thePxTop : int,thePxWidth : int,thePxHeight : int) -> None: ...
    @overload
    def __init__(self,theViewNS : NSView) -> None: ...
    @overload
    def __init__(self,arg0 : capsule) -> None: ...
    @staticmethod
    def get_type_descriptor_s() -> OCP.Standard.Standard_Type: ...
    @staticmethod
    def get_type_name_s() -> str: ...
    pass
