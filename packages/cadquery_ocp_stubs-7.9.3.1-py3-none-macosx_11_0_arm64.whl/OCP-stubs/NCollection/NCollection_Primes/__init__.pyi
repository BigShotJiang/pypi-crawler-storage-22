import OCP.NCollection.NCollection_Primes
from typing import *
from typing import Iterable as iterable
from typing import Iterator as iterator
from numpy import float64
_Shape = Tuple[int, ...]
__all__  = [
"NextPrimeForMap"
]
def NextPrimeForMap(theN : int) -> int:
    """
    Returns the next prime number greater than or equal to theN.
    """
