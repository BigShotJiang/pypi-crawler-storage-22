import OCP.OpenGl.OpenGl_Raytrace
from typing import *
from typing import Iterable as iterable
from typing import Iterator as iterator
from numpy import float64
_Shape = Tuple[int, ...]
import OCP.OpenGl
__all__  = [
"IsRaytracedElement",
"IsRaytracedGroup"
]
@overload
def IsRaytracedElement(theNode : OCP.OpenGl.OpenGl_ElementNode) -> bool:
    """
    Checks to see if the element contains ray-trace geometry.

    Checks to see if the element contains ray-trace geometry.
    """
@overload
def IsRaytracedElement(theElement : OCP.OpenGl.OpenGl_Element) -> bool:
    pass
def IsRaytracedGroup(theGroup : OCP.OpenGl.OpenGl_Group) -> bool:
    """
    Checks to see if the group contains ray-trace geometry.
    """
