import OCP.SelectMgr.SelectMgr_MatOp
from typing import *
from typing import Iterable as iterable
from typing import Iterator as iterator
from numpy import float64
_Shape = Tuple[int, ...]
import OCP.SelectMgr
import OCP.gp
__all__  = [
"Transform"
]
def Transform(theTrsf : OCP.gp.gp_Trsf,theVec : OCP.SelectMgr.SelectMgr_Vec3) -> OCP.SelectMgr.SelectMgr_Vec3:
    pass
