import OCP.TopoDS.TopoDS
from typing import *
from typing import Iterable as iterable
from typing import Iterator as iterator
from numpy import float64
_Shape = Tuple[int, ...]
import OCP.TopoDS
__all__  = [
"CompSolid",
"Compound",
"Edge",
"Face",
"Shell",
"Solid",
"Vertex",
"Wire"
]
def CompSolid(theShape : OCP.TopoDS.TopoDS_Shape) -> OCP.TopoDS.TopoDS_CompSolid:
    """
    Casts shape theShape to the more specialized return type, CompSolid.

    Casts shape theShape to the more specialized return type, CompSolid.
    """
def Compound(theShape : OCP.TopoDS.TopoDS_Shape) -> OCP.TopoDS.TopoDS_Compound:
    """
    Casts shape theShape to the more specialized return type, Compound.

    Casts shape theShape to the more specialized return type, Compound.
    """
def Edge(theShape : OCP.TopoDS.TopoDS_Shape) -> OCP.TopoDS.TopoDS_Edge:
    """
    Casts shape theShape to the more specialized return type, Edge.

    Casts shape theShape to the more specialized return type, Edge.
    """
def Face(theShape : OCP.TopoDS.TopoDS_Shape) -> OCP.TopoDS.TopoDS_Face:
    """
    Casts shape theShape to the more specialized return type, Face.

    Casts shape theShape to the more specialized return type, Face.
    """
def Shell(theShape : OCP.TopoDS.TopoDS_Shape) -> OCP.TopoDS.TopoDS_Shell:
    """
    Casts shape theShape to the more specialized return type, Shell.

    Casts shape theShape to the more specialized return type, Shell.
    """
def Solid(theShape : OCP.TopoDS.TopoDS_Shape) -> OCP.TopoDS.TopoDS_Solid:
    """
    Casts shape theShape to the more specialized return type, Solid.

    Casts shape theShape to the more specialized return type, Solid.
    """
def Vertex(theShape : OCP.TopoDS.TopoDS_Shape) -> OCP.TopoDS.TopoDS_Vertex:
    """
    Casts shape theShape to the more specialized return type, Vertex.

    Casts shape theShape to the more specialized return type, Vertex.
    """
def Wire(theShape : OCP.TopoDS.TopoDS_Shape) -> OCP.TopoDS.TopoDS_Wire:
    """
    Casts shape theShape to the more specialized return type, Wire.

    Casts shape theShape to the more specialized return type, Wire.
    """
