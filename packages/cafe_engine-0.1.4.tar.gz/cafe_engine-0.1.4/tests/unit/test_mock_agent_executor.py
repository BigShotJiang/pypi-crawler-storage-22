"""Tests for MockAgentExecutor."""

import pytest
from cafe.agents.mock_executor import MockAgentExecutor
from cafe.core.types import AgentConfig, AgentCLI, TokenUsage


class TestMockAgentExecutor:
    """測試 MockAgentExecutor 基本功能"""

    def test_default_response(self):
        """測試預設回應為 READY_FOR_REVIEW"""
        # Arrange
        config = AgentConfig(name="TestAgent", cli=AgentCLI.CLAUDE)
        executor = MockAgentExecutor(config=config)

        # Act
        agent_response = executor.execute("test prompt")

        # Assert
        assert "CAFE_READY_FOR_REVIEW" in agent_response.response
        assert isinstance(agent_response.token_usage, TokenUsage)

    def test_custom_response(self):
        """測試自訂回應"""
        # Arrange
        config = AgentConfig(name="TestAgent", cli=AgentCLI.CLAUDE)
        executor = MockAgentExecutor(
            config=config,
            response="NEED_CLARIFICATION\n請提供更多資訊"
        )

        # Act
        agent_response = executor.execute("test prompt")

        # Assert
        assert "NEED_CLARIFICATION" in agent_response.response
        assert "請提供更多資訊" in agent_response.response

    def test_tracks_call_count(self):
        """測試追蹤呼叫次數"""
        # Arrange
        config = AgentConfig(name="TestAgent", cli=AgentCLI.CLAUDE)
        executor = MockAgentExecutor(config=config)
        
        # Act
        executor.execute("prompt 1")
        executor.execute("prompt 2")
        executor.execute("prompt 3")
        
        # Assert
        assert executor.call_count == 3

    def test_saves_last_prompt(self):
        """測試儲存最後一次 prompt"""
        # Arrange
        config = AgentConfig(name="TestAgent", cli=AgentCLI.CLAUDE)
        executor = MockAgentExecutor(config=config)
        
        # Act
        executor.execute("first prompt")
        executor.execute("second prompt")
        
        # Assert
        assert executor.last_prompt == "second prompt"

    def test_saves_last_tools(self):
        """測試儲存最後一次 tools"""
        # Arrange
        config = AgentConfig(name="TestAgent", cli=AgentCLI.CLAUDE)
        executor = MockAgentExecutor(config=config)
        
        # Act
        executor.execute("prompt", tools=["bash", "read"])
        
        # Assert
        assert executor.last_tools == ["bash", "read"]

    def test_set_response_changes_response(self):
        """測試動態修改回應"""
        # Arrange
        config = AgentConfig(name="TestAgent", cli=AgentCLI.CLAUDE)
        executor = MockAgentExecutor(config=config, response="first")

        # Act
        agent_response1 = executor.execute("prompt")
        executor.set_response("second")
        agent_response2 = executor.execute("prompt")

        # Assert
        assert agent_response1.response == "first"
        assert agent_response2.response == "second"

    def test_custom_token_usage(self):
        """測試自訂 token usage"""
        # Arrange
        config = AgentConfig(name="TestAgent", cli=AgentCLI.CLAUDE)
        custom_usage = TokenUsage(input_tokens=100, output_tokens=50)
        executor = MockAgentExecutor(config=config, token_usage=custom_usage)

        # Act
        agent_response = executor.execute("prompt")

        # Assert
        assert agent_response.token_usage.input_tokens == 100
        assert agent_response.token_usage.output_tokens == 50

    def test_reset_clears_tracking(self):
        """測試 reset 清除追蹤資料"""
        # Arrange
        config = AgentConfig(name="TestAgent", cli=AgentCLI.CLAUDE)
        executor = MockAgentExecutor(config=config)
        executor.execute("prompt", tools=["bash"])
        
        # Act
        executor.reset()
        
        # Assert
        assert executor.call_count == 0
        assert executor.last_prompt is None
        assert executor.last_tools is None

    def test_config_accessible(self):
        """測試可以存取 config"""
        # Arrange
        config = AgentConfig(name="TestAgent", cli=AgentCLI.GEMINI)
        executor = MockAgentExecutor(config=config)
        
        # Assert
        assert executor.config.name == "TestAgent"
        assert executor.config.cli == AgentCLI.GEMINI
