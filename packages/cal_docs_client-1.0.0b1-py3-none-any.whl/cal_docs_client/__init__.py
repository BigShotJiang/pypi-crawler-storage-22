# ────────────────────────────────────────────────────────────────────────────────────────
#   __init__.py
#   ───────────
#
#   cal-docs-client package root.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

from .version import VERSION_STR

__all__ = ["VERSION_STR"]
