# ────────────────────────────────────────────────────────────────────────────────────────
#   version.py
#   ──────────
#
#   Version handling for cal-docs-client.
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _get_version() -> str:
    """Get the version string from the generated _version.py or return DEV."""
    try:
        # fmt: off
        from ._version import __version__ as _v  # pyright: ignore[reportMissingImports,reportUnknownVariableType]  # noqa: I001
        # fmt: on

        return str(_v)  # pyright: ignore[reportUnknownArgumentType]
    except ImportError:
        return "DEV"


VERSION_STR: str = _get_version()
