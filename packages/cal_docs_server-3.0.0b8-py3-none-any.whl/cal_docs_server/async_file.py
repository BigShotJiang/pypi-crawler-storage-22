# ----------------------------------------------------------------------------------------
#   async_file
#   ----------
#
#   Provides async file functions
#
#   License
#   -------
#   MIT License - Copyright 2025-2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena
#
#   Version History
#   ---------------
#   Mar 2024 - Created
#   Dec 2025 - New version 2
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import asyncio
import contextlib
import io
from collections.abc import AsyncGenerator
from typing import Literal
from typing import cast

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------

BinaryFileMode = Literal["rb", "wb", "w+b"]
TextFileMode = Literal["r", "rt", "w", "wt", "w+", "w+t"]


# ----------------------------------------------------------------------------------------
#   Classes
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
class BinaryFile:
    def __init__(self, file: io.BufferedIOBase):
        self.__file = file

    async def read(self, size: int = -1) -> bytes:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.__file.read, size)

    async def write(self, data: bytes) -> None:
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self.__file.write, data)

    async def close(self) -> None:
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self.__file.close)


# ----------------------------------------------------------------------------------------
class TextFile:
    def __init__(self, file: io.TextIOWrapper):
        self.__file = file

    async def read(self, size: int = -1) -> str:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.__file.read, size)

    async def write(self, data: str) -> None:
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self.__file.write, data)

    async def close(self) -> None:
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self.__file.close)


# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
@contextlib.asynccontextmanager
async def open_binary(
    file_path: str, mode: BinaryFileMode = "rb"
) -> AsyncGenerator[BinaryFile]:
    loop = asyncio.get_running_loop()
    file = await loop.run_in_executor(None, open, file_path, mode)
    assert isinstance(file, io.BufferedIOBase)

    # file = await _open_binary(file_path, mode)
    file_class = BinaryFile(file)
    try:
        yield file_class
    finally:
        await file_class.close()


# ----------------------------------------------------------------------------------------
@contextlib.asynccontextmanager
async def open_text(
    file_path: str, mode: TextFileMode = "rt"
) -> AsyncGenerator[TextFile]:
    loop = asyncio.get_running_loop()
    file = await loop.run_in_executor(None, open, file_path, mode)
    file_class = TextFile(cast("io.TextIOWrapper", file))
    try:
        yield file_class
    finally:
        await file_class.close()
