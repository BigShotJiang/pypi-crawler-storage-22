# ----------------------------------------------------------------------------------------
#   auth
#   ----
#
#   Token-based authentication for API endpoints
#
#   License
#   -------
#   MIT License - Copyright 2025-2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via Claude)
#
#   Version History
#   ---------------
#   Feb 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import json
import logging
import time
from typing import Any
from typing import TypedDict
from aiohttp import web

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------


class TokenInfo(TypedDict):
    """Information about a token's permissions."""

    name: str  # Human-readable token name
    projects: list[str] | None  # None = all projects allowed
    allow_overwrite: bool
    allow_delete: bool
    existing_projects_only: bool


TokensDict = dict[str, TokenInfo]

# ----------------------------------------------------------------------------------------
#   Token Cache
# ----------------------------------------------------------------------------------------

_tokens_cache: TokensDict = {}
_tokens_cache_time: float = 0.0
_TOKENS_CACHE_TTL: float = 5.0  # Reload tokens at most every 5 seconds

# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def _json_dumps(data: Any) -> str:
    """JSON serializer with consistent formatting and trailing newline."""
    return json.dumps(data, indent=2) + "\n"


# ----------------------------------------------------------------------------------------
def load_tokens(file_path: str | None) -> TokensDict:
    """
    Loads authentication tokens from a JSON file.
    Returns empty dict if file_path is None or on any error (logged).

    Format:
    {
        "tokens": {
            "admin": {
                "token": "abc123xyz",
                "allow_overwrite": true
            },
            "ci-pipeline": {
                "token": "def456uvw",
                "projects": ["my-project"]
            }
        }
    }

    Key is a human-readable name. Fields:
    - token (required): the actual secret token value
    - projects (optional): list of allowed projects. Omit for all projects
    - allow_overwrite (optional): defaults to false. Set true to allow overwrites
    - allow_delete (optional): defaults to false. Set true to allow deleting versions
    - existing_projects_only (optional): defaults to false. Set true to only allow
      uploading new versions to existing projects
    """

    if file_path is None:
        return {}

    try:
        with open(file_path) as f:
            data: dict[str, dict[str, dict[str, Any]]] = json.load(f)
    except FileNotFoundError:
        logging.error("Tokens file not found: %s", file_path)
        return {}
    except json.JSONDecodeError as e:
        logging.error("Invalid JSON in tokens file %s: %s", file_path, e)
        return {}
    except PermissionError:
        logging.error("Permission denied reading tokens file: %s", file_path)
        return {}
    except OSError as e:
        logging.error("Error reading tokens file %s: %s", file_path, e)
        return {}

    tokens: TokensDict = {}
    for name, entry in data.get("tokens", {}).items():
        token_str: str = entry.get("token", "")
        if token_str:
            tokens[token_str] = {
                "name": name,
                "projects": entry.get("projects"),  # None = all projects
                "allow_overwrite": entry.get("allow_overwrite", False),
                "allow_delete": entry.get("allow_delete", False),
                "existing_projects_only": entry.get("existing_projects_only", False),
            }

    return tokens


# ----------------------------------------------------------------------------------------
def get_tokens(request: web.Request) -> TokensDict:
    """
    Gets the current tokens, reloading from file if cache has expired.
    Reloads at most every 5 seconds to avoid excessive file reads.
    """

    global _tokens_cache, _tokens_cache_time

    tokens_file: str | None = request.app.get("tokens_file")
    if tokens_file is None:
        return {}

    now = time.time()
    if now - _tokens_cache_time >= _TOKENS_CACHE_TTL:
        _tokens_cache = load_tokens(tokens_file)
        _tokens_cache_time = now
        logging.debug("Reloaded tokens from %s", tokens_file)

    return _tokens_cache


# ----------------------------------------------------------------------------------------
def get_token_info(request: web.Request) -> TokenInfo | None:
    """
    Gets the TokenInfo for the request's token, or None if invalid/missing.
    """

    tokens = get_tokens(request)

    if not tokens:
        return None

    token = request.headers.get("X-Token", "")
    if token and token in tokens:
        return tokens[token]

    return None


# ----------------------------------------------------------------------------------------
def check_auth(request: web.Request) -> bool:
    """
    Validates the request has a valid authentication token.
    Checks X-Token header for the token value.
    Returns True if valid, False otherwise.
    """

    return get_token_info(request) is not None


# ----------------------------------------------------------------------------------------
def check_project_allowed(request: web.Request, project: str) -> bool:
    """
    Checks if the token is allowed to upload to the specified project.
    Returns False if token is invalid or project not allowed.
    """

    token_info = get_token_info(request)
    if token_info is None:
        return False

    allowed_projects = token_info["projects"]
    if allowed_projects is None:
        return True  # No restriction

    return project in allowed_projects


# ----------------------------------------------------------------------------------------
def check_overwrite_allowed(request: web.Request) -> bool:
    """
    Checks if the token is allowed to overwrite existing directories.
    Returns False if token is invalid or overwrite not allowed.
    """

    token_info = get_token_info(request)
    if token_info is None:
        return False

    return token_info["allow_overwrite"]


# ----------------------------------------------------------------------------------------
def check_delete_allowed(request: web.Request) -> bool:
    """
    Checks if the token is allowed to delete existing directories.
    Returns False if token is invalid or delete not allowed.
    """

    token_info = get_token_info(request)
    if token_info is None:
        return False

    return token_info["allow_delete"]


# ----------------------------------------------------------------------------------------
def check_existing_projects_only(request: web.Request) -> bool:
    """
    Checks if the token is restricted to existing projects only.
    Returns True if token requires existing projects, False otherwise.
    """

    token_info = get_token_info(request)
    if token_info is None:
        return False

    return token_info["existing_projects_only"]


# ----------------------------------------------------------------------------------------
def get_token_name(request: web.Request) -> str | None:
    """
    Gets the human-readable name of the token used in the request.
    Returns None if no valid token.
    """

    token_info = get_token_info(request)
    if token_info is None:
        return None

    return token_info["name"]


# ----------------------------------------------------------------------------------------
def require_auth(request: web.Request) -> web.Response | None:
    """
    Helper that returns 401 response if auth fails, None if auth succeeds.
    Usage:
        if error := require_auth(request):
            return error
    """

    if not check_auth(request):
        return web.json_response(
            dumps=_json_dumps,
            data={"error": "Unauthorized", "message": "Valid API token required"},
            status=401,
        )
    return None
