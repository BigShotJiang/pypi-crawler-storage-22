# ----------------------------------------------------------------------------------------
#   cache_render_index
#   ------------------
#
#   This caches the index page so it doesn't render it on every request, only if enough
#   time has passed between previous render.
#
#   License
#   -------
#   MIT License - Copyright 2025-2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena
#
#   Version History
#   ---------------
#   Mar 2024 - Created
#   Dec 2025 - New version 2
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import asyncio
import time
from . import index_docs
from . import render_index

# ----------------------------------------------------------------------------------------
#   Constants
# ----------------------------------------------------------------------------------------

CACHE_TIME_SECONDS = 20

# ----------------------------------------------------------------------------------------
#   Globals
# ----------------------------------------------------------------------------------------

g_last_rendered_html: str = ""
g_last_rendered_time: float = 0
g_currently_rendering: bool = False
g_version_redirects: dict[str, str] = {}

# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
async def cache_render_index(
    root_directory: str, server_name: str = "Documents Server"
) -> tuple[str, dict[str, str]]:
    """
    Builds index from `root_directory` and renders it into HTML. This will cache the
    result for a certain amount of time and re use it if another request comes in
    within the time.
    Returns a tuple of (html, version_redirects dict)
    """

    global g_last_rendered_time
    global g_last_rendered_html
    global g_currently_rendering
    global g_version_redirects

    if g_currently_rendering:
        # If already rendering, then just wait for this one to finish and then return
        # it rather than start another one.
        await _wait_for_render()

    elif time.time() - g_last_rendered_time > CACHE_TIME_SECONDS:
        # Been too long so render a new one.
        g_currently_rendering = True

        # Build the index
        index_list = await index_docs.make_index(root_directory=root_directory)

        # Get version redirects
        g_version_redirects = index_docs.get_version_redirects(index_list)

        # Render HTML
        html = await render_index.render_index_from_list(
            index_list, server_name=server_name
        )
        g_last_rendered_html = html
        g_currently_rendering = False
        g_last_rendered_time = time.time()

    else:
        # Otherwise just use the current cache
        pass

    return g_last_rendered_html, g_version_redirects


# ----------------------------------------------------------------------------------------
async def _wait_for_render() -> None:
    """
    Waits until `g_currently_rendering` is False
    """

    global g_currently_rendering

    while g_currently_rendering:
        await asyncio.sleep(0.05)
