# ----------------------------------------------------------------------------------------
#   main
#   ----
#
#   Starting point for the asyncio
#
#   License
#   -------
#   MIT License - Copyright 2025-2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena
#
#   Version History
#   ---------------
#   Mar 2024 - Created
#   Dec 2025 - New version 2
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import argparse
import asyncio
import json
import os
import sys
from typing import Any
from . import index_docs
from . import render_index
from . import version
from . import web_server

# ----------------------------------------------------------------------------------------
#   Constants
# ----------------------------------------------------------------------------------------

DEFAULT_CONFIG_DISPLAY = "~/.config/cal-docs-server/config.json"
DEFAULT_CONFIG_PATH = os.path.expanduser(DEFAULT_CONFIG_DISPLAY)

# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def _load_config(config_path: str | None) -> dict[str, Any]:
    """
    Loads configuration from a JSON file.
    If config_path is None, tries to load from DEFAULT_CONFIG_PATH.
    Returns empty dict if file doesn't exist (only for default path).
    """

    path = config_path or DEFAULT_CONFIG_PATH
    is_explicit = config_path is not None

    if not os.path.isfile(path):
        if is_explicit:
            print(f"Error: Config file not found: {path}", file=sys.stderr)
            sys.exit(1)
        return {}

    try:
        with open(path) as f:
            config: dict[str, Any] = json.load(f)
        return config
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON in config file {path}: {e}", file=sys.stderr)
        sys.exit(1)


# ----------------------------------------------------------------------------------------
async def main(argv: list[str]) -> int:
    """
    Main function
    """

    parser = argparse.ArgumentParser(
        prog="cal-docs-server",
        description=(
            "CAL Documentation Server - A lightweight web server for hosting "
            "versioned documentation with automatic indexing, markdown support, "
            "and a REST API for programmatic access and uploads."
        ),
        epilog=(
            "Configuration file: Options can be specified in a JSON config file. The"
            f" server looks for {DEFAULT_CONFIG_DISPLAY} by default. Use --config to"
            " specify a different file. CLI arguments override config file values."
        ),
    )
    parser.add_argument(
        "--version", action="version", version=f"cal-docs-server {version.VERSION_STR}"
    )
    parser.add_argument(
        "--config",
        "-c",
        metavar="PATH",
        help=(
            f"path to JSON config file (default: {DEFAULT_CONFIG_DISPLAY}). "
            "Config file options: docs, port, name, tokens, base_url"
        ),
    )
    parser.add_argument(
        "--port",
        "-p",
        type=int,
        metavar="PORT",
        help="port to listen on (default: 80)",
    )
    parser.add_argument(
        "--docs",
        "-d",
        metavar="PATH",
        help="path to documentation root directory (required)",
    )
    parser.add_argument(
        "--name",
        "-n",
        metavar="NAME",
        help="server name displayed on index page (default: Documents Server)",
    )
    parser.add_argument(
        "--json",
        "-j",
        action="store_true",
        help="output documentation index as JSON to stdout instead of running server",
    )
    parser.add_argument(
        "--html",
        "-H",
        action="store_true",
        help="output index page HTML to stdout instead of running server",
    )
    parser.add_argument(
        "--tokens",
        "-t",
        metavar="PATH",
        help="path to JSON file containing API tokens for upload authentication",
    )
    parser.add_argument(
        "--base-url",
        "-b",
        metavar="URL",
        help="base URL for links in API responses (e.g., https://docs.example.com)",
    )
    args = parser.parse_args(argv)

    # Load config file (default or specified)
    config = _load_config(args.config)

    # Merge config with CLI args (CLI takes precedence)
    # Map config keys to their defaults
    docs = args.docs or config.get("docs")
    port = args.port if args.port is not None else config.get("port", 80)
    name = args.name or config.get("name", "Documents Server")
    tokens = args.tokens or config.get("tokens")
    base_url = args.base_url or config.get("base_url")

    # Expand ~ in paths
    if docs:
        docs = os.path.expanduser(docs)
    if tokens:
        tokens = os.path.expanduser(tokens)

    # Validate required options
    if not docs:
        parser.error("--docs is required (either via CLI or config file)")

    if args.json:
        index_list = await index_docs.make_index(docs)
        index_json = json.dumps(index_list, indent=2)
        print(index_json)
        return 0
    elif args.html:
        index_html = await render_index.render_index(docs, server_name=name)
        print(index_html)
        return 0

    await web_server.launch_web_server(
        root_directory=docs,
        port=port,
        server_name=name,
        tokens_file=tokens,
        base_url=base_url,
    )

    # Continue until terminated
    while True:
        await asyncio.sleep(1)
