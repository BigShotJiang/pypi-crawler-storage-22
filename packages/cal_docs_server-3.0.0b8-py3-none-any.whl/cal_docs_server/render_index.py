# ----------------------------------------------------------------------------------------
#   render_index
#   ------------
#
#   Renders the `IndexList` produced in `index_docs.make_index` into an HTML page
#
#   License
#   -------
#   MIT License - Copyright 2025-2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena
#
#   Version History
#   ---------------
#   Mar 2024 - Created
#   Dec 2025 - New version 2
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import importlib.resources
import os
import string
from . import async_file
from . import index_docs
from .index_docs import IndexItemDict
from .index_docs import IndexList

# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------

g_template_file: str | None = None

# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
async def render_index(
    root_directory: str, server_name: str = "Documents Server"
) -> str:
    """
    Builds index from `root_directory` and renders it into HTML
    """

    index_list: IndexList = await index_docs.make_index(root_directory=root_directory)
    return await render_index_from_list(index_list, server_name)


# ----------------------------------------------------------------------------------------
async def render_index_from_list(
    index_list: IndexList, server_name: str = "Documents Server"
) -> str:
    """
    Renders an already-built index list into HTML
    """
    template: str = await _get_template()

    content = await _create_generated_content(index_list)
    template_subs = {"INSERT_DATA": content, "SERVER_NAME": server_name}
    html = string.Template(template).substitute(template_subs)

    return html


# ----------------------------------------------------------------------------------------
#   Private Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
async def _get_template() -> str:
    """
    Reads the template HTML file. It is stored as a resource within the server.
    Caches it so it only reads once.
    """
    global g_template_file

    if not g_template_file:
        file_folder = importlib.resources.files("cal_docs_server.resources")
        file_path: str = os.path.join(str(file_folder), "index_template.html")
        async with async_file.open_text(file_path, "rt") as f:
            g_template_file = await f.read()
    return g_template_file


# ----------------------------------------------------------------------------------------
async def _create_generated_content(index_list: IndexList) -> str:
    """
    Takes the json string of the scan and produces the html content from it. This does not
    include the template this is the "middle" section that gets inserted into the template
    """

    text: str = ""
    index_item: IndexItemDict
    for index_item in index_list:
        item_text = await _single_item_content(index_item)
        text += item_text
    return text


# ----------------------------------------------------------------------------------------
async def _single_item_content(index_item: IndexItemDict) -> str:
    """
    Generates the HTML for a specific index item
    """

    # Build the card HTML
    text = '<div class="doc-card">\n'
    text += '  <div class="doc-header">\n'

    # Add logo if available
    if logo_ref := index_item["logo_ref"]:
        text += (
            f'    <img src="{logo_ref}" class="doc-logo" alt="{index_item["name"]}'
            ' logo">\n'
        )

    # Add title
    text += '    <div class="doc-title">\n'
    # Always use the unversioned directory_name for the link
    text += (
        "      <h3><a"
        f' href="{index_item["directory_name"]}">{index_item["name"]}</a></h3>\n'
    )
    text += "    </div>\n"
    text += "  </div>\n"

    # Add description if available
    if index_item["description"]:
        text += f'  <div class="doc-description">{index_item["description"]}</div>\n'

    # Add version links
    text += '  <div class="doc-versions">\n'
    # Always use the unversioned directory_name for the "Latest" link
    text += (
        f'    <a href="{index_item["directory_name"]}" class="version-link'
        ' latest">Latest</a>\n'
    )

    if index_item["versions"]:
        version_count = len(index_item["versions"])
        version_text = f"{version_count} version" + ("s" if version_count != 1 else "")

        text += f"""    <button class="versions-toggle">
      <span class="version-count">{version_text}</span>
      <svg fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
      </svg>
    </button>
  </div>
  <div class="versions-list">
"""
        for version in index_item["versions"]:
            text += (
                f'    <a href="{version["directory_name"]}"'
                f' class="version-link">{version["version"]}</a>\n'
            )
        text += "  </div>\n"
    else:
        text += "  </div>\n"

    text += "</div>\n"

    return text
