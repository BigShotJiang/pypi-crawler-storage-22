# ----------------------------------------------------------------------------------------
#   render_md
#   ---------
#
#   Renders a MarkDown file into HTML
#
#   License
#   -------
#   MIT License - Copyright 2025-2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena
#
#   Version History
#   ---------------
#   Mar 2024 - Created
#   Dec 2025 - New version 2
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import asyncio
import importlib.resources
import os
import string
import markdown
from . import async_file

# ----------------------------------------------------------------------------------------
#   Globals
# ----------------------------------------------------------------------------------------

g_md_template: str | None = None
"""Cache the template file"""

# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
async def md_to_html(md: bytes) -> bytes:
    """
    Converts the MarkDown file data to html and returns it.
    """

    contents_html: str = await _async_md_convert(md)

    template = await _get_template()
    template_subs = {"INSERT_DATA": contents_html}
    html = string.Template(template).substitute(template_subs)

    return html.encode()


# ----------------------------------------------------------------------------------------
#   Private Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
async def _get_template() -> str:
    """
    Reads the template HTML file. It is stored as a resource within the server.
    """

    global g_md_template

    if not g_md_template:
        file_folder = importlib.resources.files("cal_docs_server.resources")
        file_path: str = os.path.join(str(file_folder), "md_template.html")
        async with async_file.open_text(file_path, "rt") as f:
            file_contents = await f.read()
        g_md_template = file_contents

    return g_md_template


# ----------------------------------------------------------------------------------------
async def _async_md_convert(md: bytes) -> str:
    """
    Wraps markdown.markdown in a thread,
    """

    md_text = md.decode(errors="replace")
    html = await asyncio.to_thread(markdown.markdown, md_text, extensions=["extra"])
    return html
