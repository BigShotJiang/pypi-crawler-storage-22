# ----------------------------------------------------------------------------------------
#   version
#   -------
#
#   Version string handling - imports from generated _version.py at build time,
#   falls back to "DEV" when not built.
#
#   License
#   -------
#   MIT License - Copyright 2025-2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena
#
#   Version History
#   ---------------
#   Nov 2025 - Created
#   Feb 2026 - Switched to _version.py pattern
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Version
# ----------------------------------------------------------------------------------------


def _get_version() -> str:
    try:
        # fmt: off
        from ._version import __version__ as _v  # pyright: ignore[reportMissingImports,reportUnknownVariableType]  # noqa: I001
        # fmt: on

        return str(_v)  # pyright: ignore[reportUnknownArgumentType]
    except ImportError:
        return "DEV"


VERSION_STR: str = _get_version()
