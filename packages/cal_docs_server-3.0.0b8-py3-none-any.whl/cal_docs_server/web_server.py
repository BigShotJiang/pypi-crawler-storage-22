# ----------------------------------------------------------------------------------------
#   web_server
#   ----------
#
#   Runs the web server using aiohttp
#
#   License
#   -------
#   MIT License - Copyright 2025-2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena
#
#   Version History
#   ---------------
#   Mar 2024 - Created
#   Dec 2025 - New version 2
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import importlib.resources
import mimetypes
import os
from collections.abc import Awaitable
from collections.abc import Callable
from functools import partial
from aiohttp import web
from . import api
from . import async_file
from . import render_md
from .cache_render_index import cache_render_index
from .version import VERSION_STR

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------

Handler = Callable[[web.Request], Awaitable[web.StreamResponse]]

# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
async def launch_web_server(
    root_directory: str,
    port: int,
    server_name: str = "Documents Server",
    tokens_file: str | None = None,
    base_url: str | None = None,
) -> None:
    """
    Launches the web server listening on `port` and serving from `root_directory`
    """

    app = web.Application(middlewares=[_set_server_name])
    app["server_name"] = server_name
    app["tokens_file"] = tokens_file  # Tokens loaded dynamically with 5s cache
    # Strip trailing slash from base_url if provided
    app["base_url"] = base_url.rstrip("/") if base_url else ""

    # API routes (must be registered before the catch-all static route)
    api.setup_api_routes(app, root_directory)

    app.router.add_get("/", partial(_serve_index, root_directory=root_directory))
    app.router.add_get("/help", _serve_help)

    app.router.add_get(
        "/{path:.*}", partial(_serve_static, root_directory=root_directory)
    )

    runner = web.AppRunner(app)
    await runner.setup()
    server = web.TCPSite(runner, "0.0.0.0", port)
    await server.start()

    print(f"CAL Docs Server started on port: {port}")

    if not app["tokens_file"]:
        print("Warning: No API tokens configured - uploads will be rejected")


# ----------------------------------------------------------------------------------------
#   Private Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
@web.middleware
async def _set_server_name(
    request: web.Request, handler: Handler
) -> web.StreamResponse:
    """
    This replaces the Server header with our name. Odd that its not just a parameter
    to pass to `web.Application` but apparently it isn't.
    """

    response = await handler(request)
    response.headers["Server"] = f"cal-docs-server/{VERSION_STR}"
    return response


# ----------------------------------------------------------------------------------------
async def _serve_static(request: web.Request, root_directory: str) -> web.Response:
    """
    Handles requests for the static files.
    """

    path: str = request.match_info.get("path", "").replace("%20", " ")
    if ".." in path:
        return web.Response(status=400, text="Invalid URL\n")

    # Check for convenient download URL: /{project}-{version}-docs.zip
    if path.endswith("-docs.zip") and "/" not in path:
        return await _serve_zip_download(request, path, root_directory)

    # Check if this path should be redirected to a versioned directory
    # Get the first component of the path (the package name)
    path_parts = path.split("/")
    base_package = path_parts[0] if path_parts else ""

    # Check if we have a version redirect for this package
    version_redirects = request.app.get("version_redirects", {})
    if base_package and base_package in version_redirects:
        # Redirect to the versioned directory
        versioned_dir = version_redirects[base_package]
        # Replace the first path component with the versioned directory
        path_parts[0] = versioned_dir
        path = "/".join(path_parts)

    file_path: str = os.path.join(root_directory, path)

    if os.path.isdir(file_path):
        if not request.path.endswith("/"):
            # If URL doesn't end with a slash we send it a redirect
            return web.HTTPFound(location=request.path + "/")

        # A directory specified means we want to get index.html or index.md
        html_file_path = os.path.join(file_path, "index.html")
        md_file_path = os.path.join(file_path, "index.md")
        if os.path.isfile(html_file_path):
            file_path = html_file_path
        elif os.path.isfile(md_file_path):
            file_path = md_file_path

    if os.path.isfile(file_path):
        try:
            async with async_file.open_binary(file_path, "rb") as f:
                file_contents = await f.read()
            if file_path.endswith(".md"):
                # Convert MarkDown to html on the fly
                content_type = "text/html"
                file_contents = await render_md.md_to_html(file_contents)
            else:
                content_type = (
                    mimetypes.guess_type(file_path)[0] or "application/octet-stream"
                )
            response_page = web.Response(body=file_contents, content_type=content_type)
            return response_page
        except OSError:
            # File became unavailable between check and read
            return web.HTTPNotFound(text="404 Not found\n")

    # We haven't served a response yet. So return a 404
    return web.HTTPNotFound(text="404 Not found\n")


# ----------------------------------------------------------------------------------------
async def _serve_zip_download(
    _request: web.Request, path: str, root_directory: str
) -> web.Response:
    """
    Handles convenient download URLs like /{project}-{version}-docs.zip.
    Parses the filename, resolves the version, and returns a ZIP of the docs directory.
    """

    parsed = api.parse_docs_filename(path)
    if not parsed:
        return web.HTTPNotFound(text="404 Not found\n")

    project, version = parsed

    version_dir = await api.resolve_version_dir(root_directory, project, version)
    if not version_dir:
        return web.HTTPNotFound(text="404 Not found\n")

    zip_data = api.create_docs_zip(root_directory, version_dir)
    if zip_data is None:
        return web.HTTPNotFound(text="404 Not found\n")

    return web.Response(
        body=zip_data,
        content_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="{version_dir}-docs.zip"'
        },
    )


# ----------------------------------------------------------------------------------------
async def _serve_index(request: web.Request, root_directory: str) -> web.Response:
    """
    Handles requests for the main index page.
    """

    try:
        server_name = request.app.get("server_name", "Documents Server")
        text, version_redirects = await cache_render_index(
            root_directory=root_directory, server_name=server_name
        )

        # Store version redirects in the app for use by _serve_static
        request.app["version_redirects"] = version_redirects

        response_page = web.Response(body=text, content_type="text/html")
        return response_page
    except Exception as e:
        return web.Response(
            text=f"Error loading index: {e}\n",
            status=500,
            content_type="text/plain",
        )


# ----------------------------------------------------------------------------------------
async def _serve_help(_request: web.Request) -> web.Response:
    """
    Handles requests for the /help page - serves the help markdown file from resources.
    """

    try:
        file_folder = importlib.resources.files("cal_docs_server.resources")
        file_path = os.path.join(str(file_folder), "help.md")

        async with async_file.open_binary(file_path, "rb") as f:
            file_contents = await f.read()

        # Render markdown to HTML
        html_content = await render_md.md_to_html(file_contents)

        response_page = web.Response(body=html_content, content_type="text/html")
        return response_page
    except Exception as e:
        return web.Response(
            text=f"Error loading help: {e}\n",
            status=500,
            content_type="text/plain",
        )
