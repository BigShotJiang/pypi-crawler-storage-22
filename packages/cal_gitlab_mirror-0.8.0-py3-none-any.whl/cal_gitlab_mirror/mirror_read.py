# ----------------------------------------------------------------------------------------
#   mirror_read
#   -----------
#
#   Read mode implementation - clone/fetch from source GitLab, create bundles
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Jan 2026 - Created
#   Feb 2026 - Replaced --since with manifest-based incremental bundles
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import json
import logging
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
from dataclasses import dataclass
from dataclasses import field
from datetime import UTC
from datetime import datetime
from pathlib import Path
from typing import Any
from .git_ops import clone_mirror
from .git_ops import create_bundle
from .git_ops import fetch_mirror
from .git_ops import get_repo_refs
from .git_ops import is_git_repo
from .gitlab_api import GitLabClient
from .gitlab_api import ProjectInfo

# ----------------------------------------------------------------------------------------
#   Constants
# ----------------------------------------------------------------------------------------

DEFAULT_CACHE_DIR = ".mirror-cache"
MANIFEST_VERSION = 1

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------


@dataclass
class BundleResult:
    """Result of bundling a single project."""

    success: bool
    refs: dict[str, str] = field(default_factory=lambda: {})
    unchanged: bool = False


# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def _load_manifest(manifest_path: str) -> dict[str, Any]:
    """
    Load a manifest file from disk.

    Parameters:
        manifest_path: Path to the manifest JSON file

    Returns:
        Parsed manifest dict, or empty structure if file doesn't exist
    """
    path = Path(manifest_path)
    if not path.exists():
        return {}

    try:
        with open(path) as f:
            data: dict[str, Any] = json.load(f)
            logging.info(f"Loaded manifest from {manifest_path}")
            return data
    except (json.JSONDecodeError, OSError) as e:
        logging.warning(f"Could not read manifest {manifest_path}: {e}")
        return {}


# ----------------------------------------------------------------------------------------
def _save_manifest(
    manifest_path: str,
    *,
    source_url: str,
    source_group: str,
    repos: dict[str, dict[str, Any]],
) -> None:
    """
    Write manifest file to disk.

    Parameters:
        manifest_path: Path to write the manifest JSON file
        source_url: Source GitLab instance URL
        source_group: Source group/namespace
        repos: Dict mapping relative paths to repo state
    """
    manifest = {
        "version": MANIFEST_VERSION,
        "generated": datetime.now(UTC).isoformat(),
        "source_url": source_url,
        "source_group": source_group,
        "repos": repos,
    }

    path = Path(manifest_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)

    print(f"Manifest written to {manifest_path}")


# ----------------------------------------------------------------------------------------
def read_from_source(
    *,
    source_url: str,
    source_token: str,
    source_group: str,
    output_dir: str,
    cache_dir: str | None = None,
    manifest_path: str | None = None,
    full_mirror: bool = False,
    delete_first: bool = False,
    jobs: int = 1,
) -> int:
    """
    Clone or fetch repositories from source GitLab and create bundles.

    Creates bundle files in output_dir that can be transferred to another system.
    Uses a separate cache directory for bare repos to enable incremental bundles.

    Parameters:
        source_url: Source GitLab instance URL
        source_token: Personal access token for source
        source_group: Group/namespace to mirror
        output_dir: Local directory to store bundle files
        cache_dir: Directory for cached bare repos (default: .mirror-cache)
        manifest_path: Path to manifest file for incremental mode
        full_mirror: Force full clone even if repo exists in cache
        delete_first: Delete the output directory before mirroring
        jobs: Number of parallel jobs

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    import shutil

    output_path = Path(output_dir)
    cache_path = Path(cache_dir) if cache_dir else Path(DEFAULT_CACHE_DIR)

    # Load manifest for incremental mode
    prev_manifest: dict[str, Any] = {}
    if manifest_path:
        prev_manifest = _load_manifest(manifest_path)

    prev_repos: dict[str, Any] = prev_manifest.get("repos", {})

    # Delete output directory if requested
    if delete_first and output_path.exists():
        print(f"Deleting {output_dir}...")
        shutil.rmtree(output_path)

    print(f"Connecting to {source_url}...")
    client = GitLabClient(source_url, source_token)

    print(f"Listing projects in {source_group}...")
    try:
        projects = client.list_group_projects(source_group)
    except Exception as e:
        print(f"Error listing projects: {e}")
        return 1

    print(f"Found {len(projects)} projects")

    if not projects:
        print("No projects found in group")
        return 0

    # Ensure directories exist
    output_path.mkdir(parents=True, exist_ok=True)
    cache_path.mkdir(parents=True, exist_ok=True)

    # Filter out empty/archived/no-repo projects first
    work_items: list[ProjectInfo] = []
    skipped = 0
    for project in projects:
        if project.repository_access_level == "disabled":
            print(f"Skipping {project.path_with_namespace} (no repository)")
            skipped += 1
        elif project.empty_repo:
            print(f"Skipping {project.path_with_namespace} (empty repo)")
            skipped += 1
        elif project.archived:
            print(f"Skipping {project.path_with_namespace} (archived)")
            skipped += 1
        else:
            work_items.append(project)

    if not work_items:
        print("No projects to process")
        return 0

    errors: list[str] = []
    bundled = 0
    unchanged = 0
    total = len(work_items)

    # Collect new manifest state from results
    new_repos: dict[str, dict[str, Any]] = {}

    effective_jobs = min(jobs, total)
    if effective_jobs > 1:
        print(f"Processing {total} projects with {effective_jobs} parallel jobs...")
    else:
        print(f"Processing {total} projects...")

    if effective_jobs > 1:
        # Parallel processing
        with ThreadPoolExecutor(max_workers=effective_jobs) as executor:
            future_to_project: dict[Any, tuple[ProjectInfo, str]] = {}
            for project in work_items:
                rel_path = project.path_with_namespace
                if rel_path.startswith(source_group + "/"):
                    rel_path = rel_path[len(source_group) + 1 :]
                prev_refs = prev_repos.get(rel_path, {}).get("refs", {})

                future = executor.submit(
                    _bundle_single_project,
                    project=project,
                    output_dir=output_path,
                    cache_dir=cache_path,
                    source_group=source_group,
                    token=source_token,
                    full_mirror=full_mirror,
                    prev_refs=prev_refs if manifest_path else None,
                )
                future_to_project[future] = (project, rel_path)

            completed = 0
            for future in as_completed(future_to_project):
                project, rel_path = future_to_project[future]
                completed += 1
                prefix = f"[{completed}/{total}]"
                try:
                    result = future.result()
                    if result.unchanged:
                        print(f"{prefix} UNCHANGED: {project.path_with_namespace}")
                        unchanged += 1
                    elif result.success:
                        print(f"{prefix} OK: {project.path_with_namespace}")
                        bundled += 1
                    else:
                        errors.append(f"{project.path_with_namespace}: bundle failed")
                        print(f"{prefix} FAILED: {project.path_with_namespace}")
                    if result.refs:
                        new_repos[rel_path] = {"refs": result.refs}
                except Exception as e:
                    errors.append(f"{project.path_with_namespace}: {e}")
                    print(f"{prefix} ERROR: {project.path_with_namespace}: {e}")
                    logging.exception(f"Failed to bundle {project.path_with_namespace}")
    else:
        # Sequential processing
        for i, project in enumerate(work_items, 1):
            rel_path = project.path_with_namespace
            if rel_path.startswith(source_group + "/"):
                rel_path = rel_path[len(source_group) + 1 :]
            prev_refs = prev_repos.get(rel_path, {}).get("refs", {})

            prefix = f"[{i}/{total}]"
            try:
                result = _bundle_single_project(
                    project=project,
                    output_dir=output_path,
                    cache_dir=cache_path,
                    source_group=source_group,
                    token=source_token,
                    full_mirror=full_mirror,
                    prev_refs=prev_refs if manifest_path else None,
                )
                if result.unchanged:
                    print(f"{prefix} UNCHANGED: {project.path_with_namespace}")
                    unchanged += 1
                elif result.success:
                    print(f"{prefix} OK: {project.path_with_namespace}")
                    bundled += 1
                else:
                    errors.append(f"{project.path_with_namespace}: bundle failed")
                    print(f"{prefix} FAILED: {project.path_with_namespace}")
                if result.refs:
                    new_repos[rel_path] = {"refs": result.refs}
            except Exception as e:
                errors.append(f"{project.path_with_namespace}: {e}")
                print(f"{prefix} ERROR: {project.path_with_namespace}: {e}")
                logging.exception(f"Failed to bundle {project.path_with_namespace}")

    # Write updated manifest if manifest_path was specified
    if manifest_path:
        # Preserve entries for repos not in this run
        merged_repos = dict(prev_repos)
        merged_repos.update(new_repos)

        _save_manifest(
            manifest_path,
            source_url=source_url,
            source_group=source_group,
            repos=merged_repos,
        )

    # Summary
    print()
    mode = "incremental (manifest)" if manifest_path else "full"
    summary = f"Bundled ({mode}): {bundled}"
    if unchanged:
        summary += f", Unchanged: {unchanged}"
    summary += f", Skipped: {skipped}, Errors: {len(errors)}"
    print(summary)

    if errors:
        print("\nErrors:")
        for err in errors:
            print(f"  - {err}")
        return 1

    return 0


# ----------------------------------------------------------------------------------------
def _bundle_single_project(
    *,
    project: ProjectInfo,
    output_dir: Path,
    cache_dir: Path,
    source_group: str,
    token: str,
    full_mirror: bool,
    prev_refs: dict[str, str] | None,
) -> BundleResult:
    """
    Clone/fetch a project and create a bundle file.

    Parameters:
        project: Project info from GitLab
        output_dir: Base directory for bundle files
        cache_dir: Directory for cached bare repos
        source_group: Source group prefix to strip from paths
        token: GitLab token for authentication
        full_mirror: Force full clone
        prev_refs: Previous refs from manifest (None = full bundle, empty dict = first run)

    Returns:
        BundleResult with success status, current refs, and unchanged flag
    """
    import shutil

    # Strip source group prefix from path
    relative_path = project.path_with_namespace
    if relative_path.startswith(source_group + "/"):
        relative_path = relative_path[len(source_group) + 1 :]

    # Paths
    cache_repo_path = cache_dir / f"{relative_path}.git"
    bundle_path = output_dir / f"{relative_path}.bundle"

    # Ensure cache parent directory exists (bundle dir created only when needed)
    cache_repo_path.parent.mkdir(parents=True, exist_ok=True)

    # Clone or fetch to cache
    if is_git_repo(str(cache_repo_path)) and not full_mirror:
        # Repo exists in cache, fetch updates
        logging.info(f"Fetching updates for {project.path_with_namespace}")
        success = fetch_mirror(str(cache_repo_path), token=token)
    else:
        # Clone new repo to cache
        if cache_repo_path.exists():
            shutil.rmtree(cache_repo_path)

        logging.info(f"Cloning {project.path_with_namespace}")
        success = clone_mirror(
            project.http_url_to_repo,
            str(cache_repo_path),
            token=token,
        )

    if not success:
        return BundleResult(success=False)

    # Get current refs from the cached repo
    current_refs = get_repo_refs(str(cache_repo_path))

    # Check if refs have changed since last manifest
    if prev_refs is not None and current_refs == prev_refs:
        logging.info(f"No changes for {project.path_with_namespace}")
        return BundleResult(success=True, refs=current_refs, unchanged=True)

    # Determine basis SHAs for incremental bundle
    basis_shas: list[str] | None = None
    if prev_refs:
        # Use unique SHA values from previous refs as basis
        basis_shas = list(set(prev_refs.values()))

    # Create bundle
    logging.info(f"Creating bundle for {project.path_with_namespace}")
    bundle_ok = create_bundle(
        str(cache_repo_path),
        str(bundle_path),
        basis_shas=basis_shas,
    )

    return BundleResult(success=bundle_ok, refs=current_refs if bundle_ok else {})
