# ----------------------------------------------------------------------------------------
#   mirror_write
#   ------------
#
#   Write mode implementation - push bundles to destination GitLab
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Jan 2026 - Created
#   Feb 2026 - Refactored for true parallel push (pre-compute API state, lock-free git)
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import logging
import tempfile
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
from dataclasses import dataclass
from pathlib import Path
from .git_ops import clone_from_bundle
from .git_ops import clone_mirror
from .git_ops import fetch_from_bundle
from .git_ops import push_mirror
from .gitlab_api import GitLabClient
from .gitlab_api import GroupInfo

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------


@dataclass
class _PushWorkItem:
    """Pre-computed push work item with all GitLab API data resolved."""

    relative_path: str
    bundle_path: Path
    dest_project_path: str
    dest_url: str
    project_id: int
    project_exists: bool


# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def _find_bundles(base_dir: Path) -> list[Path]:
    """
    Find all bundle files in a directory.

    Parameters:
        base_dir: Directory to search

    Returns:
        List of paths to .bundle files
    """
    bundles: list[Path] = []
    for path in base_dir.rglob("*.bundle"):
        if path.is_file():
            bundles.append(path)
    return sorted(bundles)


# ----------------------------------------------------------------------------------------
def _collect_namespace_paths(
    work_items: list[tuple[str, Path]], dest_group: str
) -> list[str]:
    """
    Collect all unique namespace paths needed for work items,
    including all intermediate parent paths.

    Parameters:
        work_items: List of (relative_path, bundle_path) tuples
        dest_group: Base destination group

    Returns:
        Namespace paths sorted by depth (shallowest first)
    """
    all_paths: set[str] = set()
    for relative_path, _ in work_items:
        dest_project_path = f"{dest_group}/{relative_path}"
        namespace = "/".join(dest_project_path.split("/")[:-1])
        # Add namespace and all its parents
        parts = namespace.split("/")
        for i in range(1, len(parts) + 1):
            all_paths.add("/".join(parts[:i]))

    return sorted(all_paths, key=lambda p: p.count("/"))


# ----------------------------------------------------------------------------------------
def _ensure_all_groups(
    client: GitLabClient,
    namespace_paths: list[str],
    *,
    visibility: str = "private",
) -> dict[str, GroupInfo] | None:
    """
    Ensure all group hierarchies exist for the given namespace paths.

    Processes paths sorted by depth so parents are always created before
    children. Caches results to avoid redundant API calls.

    Parameters:
        client: GitLab client
        namespace_paths: List of full namespace paths, sorted shallowest first
        visibility: Visibility level for newly created groups

    Returns:
        Dict mapping full namespace path to GroupInfo, or None on failure
    """
    cache: dict[str, GroupInfo] = {}

    for path in namespace_paths:
        if path in cache:
            continue

        group = client.get_group(path)
        if group is not None:
            # Group exists - update visibility
            logging.debug(f"Updating visibility for group: {path}")
            client.update_group_visibility(group.id, visibility)
            cache[path] = group
        else:
            # Create the group - look up parent from cache
            parts = path.split("/")
            slug = parts[-1]
            parent_id: int | None = None
            if len(parts) > 1:
                parent_path = "/".join(parts[:-1])
                parent = cache.get(parent_path)
                if parent is None:
                    logging.error(f"Parent group {parent_path} not in cache for {path}")
                    return None
                parent_id = parent.id

            logging.info(f"Creating group: {path}")
            try:
                group = client.create_group(
                    slug, slug, parent_id, visibility=visibility
                )
                print(f"  Created group: {path}")
                cache[path] = group
            except Exception as e:
                logging.error(f"Failed to create group {path}: {e}")
                return None

    return cache


# ----------------------------------------------------------------------------------------
def _ensure_all_projects(
    client: GitLabClient,
    work_items: list[tuple[str, Path]],
    dest_group: str,
    group_cache: dict[str, GroupInfo],
    *,
    visibility: str = "private",
) -> tuple[list[_PushWorkItem], list[str]]:
    """
    Ensure all destination projects exist, creating them if needed.

    Parameters:
        client: GitLab client
        work_items: List of (relative_path, bundle_path) tuples
        dest_group: Base destination group
        group_cache: Pre-computed group hierarchy cache
        visibility: Visibility level for new projects

    Returns:
        Tuple of (resolved work items, error messages for failed items)
    """
    resolved: list[_PushWorkItem] = []
    errors: list[str] = []

    for relative_path, bundle_path in work_items:
        dest_project_path = f"{dest_group}/{relative_path}"
        dest_namespace = "/".join(dest_project_path.split("/")[:-1])

        namespace_info = group_cache.get(dest_namespace)
        if namespace_info is None:
            msg = f"{relative_path}: namespace {dest_namespace} not found in cache"
            logging.error(msg)
            errors.append(msg)
            continue

        existing = client.get_project(dest_project_path)

        if existing is not None:
            # Project exists - update visibility
            logging.debug(f"Updating visibility for project: {dest_project_path}")
            client.update_project_visibility(existing.id, visibility)
            resolved.append(
                _PushWorkItem(
                    relative_path=relative_path,
                    bundle_path=bundle_path,
                    dest_project_path=dest_project_path,
                    dest_url=existing.http_url_to_repo,
                    project_id=existing.id,
                    project_exists=True,
                )
            )
        else:
            # Create project
            project_name = dest_project_path.split("/")[-1]
            logging.info(f"Creating project: {dest_project_path}")
            try:
                created = client.create_project(
                    project_name, namespace_info.id, visibility=visibility
                )
                print(f"  Created project: {dest_project_path}")
                resolved.append(
                    _PushWorkItem(
                        relative_path=relative_path,
                        bundle_path=bundle_path,
                        dest_project_path=dest_project_path,
                        dest_url=created.http_url_to_repo,
                        project_id=created.id,
                        project_exists=False,
                    )
                )
            except Exception as e:
                msg = f"{relative_path}: failed to create project: {e}"
                logging.error(msg)
                errors.append(msg)

    return resolved, errors


# ----------------------------------------------------------------------------------------
def write_to_dest(
    *,
    dest_url: str,
    dest_token: str,
    dest_group: str,
    input_dir: str,
    jobs: int = 1,
    public: bool = False,
) -> int:
    """
    Push bundle files to destination GitLab.

    Scans input directory for .bundle files and pushes them to destination.
    All GitLab API setup (groups, projects) is done upfront before parallel
    git operations begin.

    Parameters:
        dest_url: Destination GitLab instance URL
        dest_token: Personal access token for destination
        dest_group: Target group/namespace
        input_dir: Local directory containing bundle files
        jobs: Number of parallel jobs
        public: If True, create groups and projects with public visibility

    Returns:
        Exit code (0 for success, non-zero for error)
    """
    visibility = "public" if public else "private"
    input_path = Path(input_dir)

    if not input_path.exists():
        print(f"Error: Input directory does not exist: {input_dir}")
        return 1

    # Find all bundles (skip .cache directory)
    print(f"Scanning {input_dir} for bundles...")
    all_bundles = _find_bundles(input_path)
    # Filter out bundles in .cache directory
    bundles = [b for b in all_bundles if ".cache" not in b.parts]

    if not bundles:
        print("No bundle files found")
        return 0

    print(f"Found {len(bundles)} bundles")

    print(f"Connecting to {dest_url}...")
    client = GitLabClient(dest_url, dest_token)

    # Build work items
    work_items: list[tuple[str, Path]] = []
    for bundle_path in bundles:
        relative_path = bundle_path.relative_to(input_path)
        relative_str = str(relative_path)
        if relative_str.endswith(".bundle"):
            relative_str = relative_str[:-7]
        work_items.append((relative_str, bundle_path))

    # Pre-compute all namespace paths and ensure groups exist
    print("Verifying destination groups...")
    namespace_paths = _collect_namespace_paths(work_items, dest_group)
    group_cache = _ensure_all_groups(client, namespace_paths, visibility=visibility)
    if group_cache is None:
        print("Error: Could not create/access required groups")
        return 1

    # Pre-create/verify all projects
    print("Verifying destination projects...")
    push_work_items, setup_errors = _ensure_all_projects(
        client, work_items, dest_group, group_cache, visibility=visibility
    )

    errors: list[str] = list(setup_errors)
    pushed = 0
    total = len(push_work_items)

    if total == 0 and not errors:
        print("No projects to process")
        return 0

    effective_jobs = min(jobs, total) if total > 0 else 1
    if effective_jobs > 1:
        print(f"Pushing {total} bundles with {effective_jobs} parallel jobs...")
    else:
        print(f"Pushing {total} bundles...")

    if effective_jobs > 1 and total > 0:
        # Parallel processing
        with ThreadPoolExecutor(max_workers=effective_jobs) as executor:
            future_to_item = {
                executor.submit(
                    _push_single_bundle,
                    work_item=work_item,
                    client=client,
                    dest_token=dest_token,
                ): work_item.relative_path
                for work_item in push_work_items
            }

            completed = 0
            for future in as_completed(future_to_item):
                relative_str = future_to_item[future]
                completed += 1
                prefix = f"[{completed}/{total}]"
                try:
                    success = future.result()
                    if success:
                        print(f"{prefix} OK: {relative_str}")
                        pushed += 1
                    else:
                        errors.append(f"{relative_str}: push failed")
                        print(f"{prefix} FAILED: {relative_str}")
                except Exception as e:
                    errors.append(f"{relative_str}: {e}")
                    print(f"{prefix} ERROR: {relative_str}: {e}")
                    logging.exception(f"Failed to push {relative_str}")
    else:
        # Sequential processing
        for i, work_item in enumerate(push_work_items, 1):
            prefix = f"[{i}/{total}]"
            try:
                success = _push_single_bundle(
                    work_item=work_item,
                    client=client,
                    dest_token=dest_token,
                )
                if success:
                    print(f"{prefix} OK: {work_item.relative_path}")
                    pushed += 1
                else:
                    errors.append(f"{work_item.relative_path}: push failed")
                    print(f"{prefix} FAILED: {work_item.relative_path}")
            except Exception as e:
                errors.append(f"{work_item.relative_path}: {e}")
                print(f"{prefix} ERROR: {work_item.relative_path}: {e}")
                logging.exception(f"Failed to push {work_item.relative_path}")

    # Summary
    print()
    print(f"Pushed: {pushed}, Errors: {len(errors)}")

    if errors:
        print("\nErrors:")
        for err in errors:
            print(f"  - {err}")
        return 1

    return 0


# ----------------------------------------------------------------------------------------
def _push_single_bundle(
    *,
    work_item: _PushWorkItem,
    client: GitLabClient,
    dest_token: str,
) -> bool:
    """
    Push a single bundle to destination (git operations only).

    All GitLab API setup (groups, projects) is done before this function
    is called. This function only performs git clone/fetch/push and
    per-project branch protection management.

    Parameters:
        work_item: Pre-computed work item with all API data resolved
        client: GitLab client (for branch protection only)
        dest_token: Token for git authentication

    Returns:
        True on success, False on failure
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_repo = Path(temp_dir) / "repo.git"

        if work_item.project_exists:
            # Project exists - this might be an incremental bundle
            # Clone from destination first, then fetch from bundle
            logging.info(f"Cloning existing repo from {work_item.dest_url}")
            if not clone_mirror(work_item.dest_url, str(temp_repo), token=dest_token):
                logging.warning("Could not clone from destination, trying bundle only")
                # Fall back to bundle-only approach
                if not clone_from_bundle(str(work_item.bundle_path), str(temp_repo)):
                    return False
            else:
                # Fetch updates from bundle
                logging.info(f"Fetching updates from bundle {work_item.bundle_path}")
                if not fetch_from_bundle(str(temp_repo), str(work_item.bundle_path)):
                    logging.error("Failed to fetch from bundle")
                    return False
        else:
            # New project - clone directly from bundle (must be full bundle)
            if not clone_from_bundle(str(work_item.bundle_path), str(temp_repo)):
                logging.error(
                    "Failed to clone from bundle. "
                    "For new projects, a full bundle is required."
                )
                return False

        # Temporarily unprotect branches for push
        protected_branches: list[str] = []
        if work_item.project_exists:
            protected_branches = client.list_protected_branches(work_item.project_id)
            for branch in protected_branches:
                logging.info(f"Temporarily unprotecting branch: {branch}")
                client.unprotect_branch(work_item.project_id, branch)

        # Push to destination
        logging.info(f"Pushing to {work_item.dest_url}")
        push_success = push_mirror(
            str(temp_repo),
            work_item.dest_url,
            token=dest_token,
        )

        # Re-protect branches
        for branch in protected_branches:
            logging.info(f"Re-protecting branch: {branch}")
            client.protect_branch(work_item.project_id, branch)

        return push_success
