"""
Setup configuration for calibrate-suite

Supports both pip installation and ROS2 ament_cmake integration.
For ROS2: colcon build --packages-select calibrate-suite
For pip: pip install -e .
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="calibrate-suite",
    version="0.1.1",
    description="camera-lidar calibration suite with GUI and fleet management",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Jamih",
    author_email="ajamiu46@gmail.com",
    url="https://github.com/Opera5/calibrate-suite",
    license="MIT",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    entry_points={
        "console_scripts": [
            "calibrate-suite=utils.cli_calibrate:main",
            "fleet-server=utils.cli_fleet_server:main",
            "calibrate-camera=calibrate_camera:main",
        ],
    },
    package_data={
        "": [
            "fleet_server/templates/*.html",
            "gui/assets/**/*",
            "config/**/*",
            "rviz_configs/**/*",
        ],
    },
    install_requires=[
        "numpy>=1.20.0",
        "scipy>=1.7.0",
        "scikit-learn>=1.0.0",
        "Flask==2.3.3",
        "requests==2.31.0",
        "python-dotenv==1.0.0",
        "pyyaml>=6.0",
    ],
    extras_require={
        "cv": [
            "opencv-python>=4.5.0",
        ],
        "3d": [
            "open3d>=0.13.0",
        ],
        "visualization": [
            "matplotlib>=3.3.0",
        ],
        "gui": [
            "PyQt5>=5.15.0",
            "pyqtgraph>=0.13.0",
        ],
        "full": [
            "opencv-python>=4.5.0",
            "open3d>=0.13.0",
            "matplotlib>=3.3.0",
            "PyQt5>=5.15.0",
            "pyqtgraph>=0.13.0",
        ],
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "black>=23.0",
            "flake8>=6.0",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)
