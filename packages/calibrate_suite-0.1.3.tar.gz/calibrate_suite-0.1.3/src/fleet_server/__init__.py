"""
Fleet Server - REST API for Calibration Management

Provides web dashboard and REST API for managing robot calibration results.
"""

__version__ = "0.1.0"

def create_app(debug=False, env_file=None):
   
    import os
    from pathlib import Path
    from flask import Flask
    
    # Load environment configuration if specified
    if env_file and os.path.exists(env_file):
        from dotenv import load_dotenv
        load_dotenv(env_file)
    
    # Import app from main module (when installed via pip/setup.py)
    try:
        # When installed as package
        from fleet_server.app import app as flask_app
    except ImportError:
        # Fallback for development (src in path)
        from .app import app as flask_app
    
    if debug:
        flask_app.config['DEBUG'] = True
        flask_app.config['ENV'] = 'development'
    
    return flask_app
