"""Fleet Server - Calibration Artifact Management

REST API server for managing robot calibration results across a fleet.
Handles upload, storage, retrieval, and visualization of calibration data.
"""

import os
import datetime
import json
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_from_directory, abort
import sqlite3

from .config import get_config, Config

# Initialize configuration and directories BEFORE importing utils
config = get_config()
config.ensure_directories()

# Now safe to import utils (which uses logging)
from .utils import logger, sanitize_filename, validate_upload, get_safe_path, format_filesize

# Create Flask app
app = Flask(__name__, template_folder='templates')

DB_PATH = config.DATABASE_PATH
UPLOAD_FOLDER = config.UPLOAD_FOLDER
MAX_UPLOAD_SIZE = config.MAX_UPLOAD_SIZE

logger.info(f"Fleet Server starting in {config.FLASK_ENV} mode")
logger.info(f"Database: {DB_PATH}")
logger.info(f"Upload folder: {UPLOAD_FOLDER}")

def init_db():
    """Initialize SQLite database with required schema"""
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        # Robots Table
        c.execute('''CREATE TABLE IF NOT EXISTS robots
                     (id TEXT PRIMARY KEY, 
                      name TEXT, 
                      model TEXT, 
                      last_calib_date TEXT,
                      status TEXT DEFAULT 'active')''')
        
        # Calibrations Table with more metadata
        c.execute('''CREATE TABLE IF NOT EXISTS calibrations
                     (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                      robot_id TEXT, 
                      timestamp TEXT, 
                      artifacts_path TEXT,
                      file_size INTEGER,
                      score REAL,
                      notes TEXT,
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      FOREIGN KEY(robot_id) REFERENCES robots(id))''')
        
        # Create indices for faster queries
        c.execute('''CREATE INDEX IF NOT EXISTS idx_robot_id 
                     ON calibrations(robot_id)''')
        c.execute('''CREATE INDEX IF NOT EXISTS idx_timestamp 
                     ON calibrations(timestamp)''')
        
        conn.commit()
        conn.close()
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        raise

# Initialize database on startup
init_db()

@app.template_filter('basename')
def basename_filter(s):
    """Jinja2 filter to get basename of path"""
    return os.path.basename(s)

@app.template_filter('filesize')
def filesize_filter(size_bytes):
    """Jinja2 filter to format file size"""
    return format_filesize(size_bytes)

@app.template_filter('format_timestamp')
def format_timestamp_filter(timestamp_str):
    """Jinja2 filter to format timestamp from YYYYMMDD_HHMMSS to readable format"""
    if not timestamp_str:
        return 'Unknown'
    try:
        # Parse from YYYYMMDD_HHMMSS format
        dt = datetime.datetime.strptime(timestamp_str, '%Y%m%d_%H%M%S')
        # Return in readable format: YYYY-MM-DD HH:MM:SS
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    except (ValueError, TypeError):
        return timestamp_str

@app.before_request
def log_request():
    """Log incoming requests"""
    logger.debug(f"{request.method} {request.path}")

@app.after_request
def log_response(response):
    """Log outgoing responses"""
    logger.debug(f"Response: {response.status_code}")
    return response

# ============================================================================
# ROUTES
# ============================================================================

@app.route('/')
def index():
    """Dashboard showing robots and recent calibrations"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        c.execute("SELECT * FROM robots ORDER BY last_calib_date DESC")
        robots = c.fetchall()
        
        c.execute("""SELECT * FROM calibrations 
                     ORDER BY timestamp DESC LIMIT 20""")
        recent = c.fetchall()
        
        conn.close()
        logger.info(f"Dashboard accessed: {len(robots)} robots, {len(recent)} recent calibrations")
        return render_template('index.html', robots=robots, recent=recent)
    
    except Exception as e:
        logger.error(f"Dashboard error: {e}")
        return render_template('error.html', error=str(e)), 500

@app.route('/api/robots', methods=['GET'])
def get_robots():
    """API endpoint: Get all robots"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM robots ORDER BY last_calib_date DESC")
        robots = [dict(row) for row in c.fetchall()]
        conn.close()
        
        return jsonify({'status': 'success', 'robots': robots}), 200
    except Exception as e:
        logger.error(f"Get robots error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/files/<path:filename>')
def serve_file(filename):
    """Serve uploaded calibration files with security checks"""
    try:
        # Sanitize filename and check path
        safe_filename = sanitize_filename(filename)
        safe_path = get_safe_path(UPLOAD_FOLDER, safe_filename)
        
        if safe_path is None:
            logger.warning(f"Attempted unsafe file access: {filename}")
            abort(403)
        
        if not os.path.exists(safe_path):
            logger.warning(f"File not found: {safe_path}")
            abort(404)
        
        logger.info(f"Serving file: {safe_filename}")
        return send_from_directory(UPLOAD_FOLDER, safe_filename)
    
    except Exception as e:
        logger.error(f"File serve error: {e}")
        abort(500)

@app.route('/view/<int:calib_id>')
def view_calibration(calib_id):
    """View 3D visualization of calibration result"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        c.execute("SELECT * FROM calibrations WHERE id = ?", (calib_id,))
        calib = c.fetchone()
        conn.close()
        
        if calib:
            filename = os.path.basename(calib['artifacts_path'])
            file_url = f"/files/{filename}"
            logger.info(f"Viewing calibration {calib_id}")
            return render_template('viewer.html', file_url=file_url, calib=calib)
        else:
            logger.warning(f"Calibration not found: {calib_id}")
            abort(404)
    
    except Exception as e:
        logger.error(f"View calibration error: {e}")
        abort(500)

@app.route('/api/upload', methods=['POST'])
def upload_calibration():
    """Upload calibration artifacts and metadata"""
    try:
        # Validate request
        if 'artifacts' not in request.files:
            logger.warning("Upload: No file part in request")
            return jsonify({'error': 'No file part'}), 400
        
        file = request.files['artifacts']
        if file.filename == '':
            logger.warning("Upload: Empty filename")
            return jsonify({'error': 'No selected file'}), 400
        
        # Parse metadata
        meta_str = request.form.get('metadata', '{}')
        try:
            metadata = json.loads(meta_str)
        except json.JSONDecodeError:
            logger.warning("Upload: Invalid JSON metadata")
            return jsonify({'error': 'Invalid metadata JSON'}), 400
        
        robot_id = metadata.get('robot_id', 'unknown')
        score = float(metadata.get('score', 0.0))
        notes = metadata.get('notes', '')
        
        # Validate upload
        is_valid, error_msg = validate_upload(file, file.filename)
        if not is_valid:
            logger.warning(f"Upload validation failed for {robot_id}: {error_msg}")
            return jsonify({'error': error_msg}), 400
        
        # Sanitize filename
        original_filename = file.filename
        filename = sanitize_filename(original_filename)
        if not filename:
            logger.warning(f"Upload: Could not sanitize filename {original_filename}")
            return jsonify({'error': 'Invalid filename'}), 400
        
        # Generate unique filename
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        final_filename = f"{robot_id}_{ts}_{filename}"
        filepath = os.path.join(UPLOAD_FOLDER, final_filename)
        
        # Save file
        file.save(filepath)
        file_size = os.path.getsize(filepath)
        
        # Update database
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        try:
            # Upsert Robot
            c.execute("""INSERT OR REPLACE INTO robots 
                         (id, name, model, last_calib_date, status) 
                         VALUES (?, ?, ?, ?, 'active')""",
                      (robot_id, metadata.get('robot_name', robot_id), 
                       metadata.get('robot_model', 'Unknown'), ts))
            
            # Insert Calibration
            c.execute("""INSERT INTO calibrations 
                         (robot_id, timestamp, artifacts_path, file_size, score, notes) 
                         VALUES (?, ?, ?, ?, ?, ?)""",
                      (robot_id, ts, final_filename, file_size, score, notes))
            
            conn.commit()
            calib_id = c.lastrowid
            conn.close()
            
            logger.info(f"Upload successful: Robot={robot_id}, File={final_filename}, Size={format_filesize(file_size)}, Score={score:.4f}")
            
            return jsonify({
                'status': 'success', 
                'id': calib_id,
                'filename': final_filename,
                'file_size': file_size
            }), 201
        
        except sqlite3.Error as e:
            conn.close()
            logger.error(f"Database error during upload: {e}")
            return jsonify({'error': f'Database error: {str(e)}'}), 500
    
    except Exception as e:
        logger.error(f"Upload error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/calibrations/<robot_id>', methods=['GET'])
def get_robot_calibrations(robot_id):
    """Get all calibrations for a specific robot"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        c.execute("""SELECT * FROM calibrations 
                     WHERE robot_id = ? 
                     ORDER BY timestamp DESC""", (robot_id,))
        calibrations = [dict(row) for row in c.fetchall()]
        conn.close()
        
        logger.info(f"Retrieved {len(calibrations)} calibrations for {robot_id}")
        return jsonify({'status': 'success', 'calibrations': calibrations}), 200
    
    except Exception as e:
        logger.error(f"Get robot calibrations error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get fleet statistics"""
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        c.execute("SELECT COUNT(*) FROM robots")
        robot_count = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM calibrations")
        calib_count = c.fetchone()[0]
        
        c.execute("SELECT AVG(score) FROM calibrations")
        avg_score = c.fetchone()[0] or 0.0
        
        c.execute("SELECT AVG(file_size) FROM calibrations")
        avg_size = c.fetchone()[0] or 0
        
        conn.close()
        
        logger.info(f"Stats: {robot_count} robots, {calib_count} calibrations")
        
        return jsonify({
            'status': 'success',
            'robots': robot_count,
            'calibrations': calib_count,
            'avg_score': round(avg_score, 4),
            'avg_file_size': format_filesize(int(avg_size))
        }), 200
    
    except Exception as e:
        logger.error(f"Get stats error: {e}")
        return jsonify({'error': str(e)}), 500

# ============================================================================
# ERROR HANDLERS
# ============================================================================

@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors"""
    logger.warning(f"404 Not Found: {request.path}")
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(e):
    """Handle 500 errors"""
    logger.error(f"500 Internal Server Error: {str(e)}")
    return jsonify({'error': 'Internal server error'}), 500

# ============================================================================
# MAIN
# ============================================================================

if __name__ == '__main__':
    try:
        logger.info(f"Starting Fleet Server on {config.FLASK_HOST}:{config.FLASK_PORT}")
        app.run(
            host=config.FLASK_HOST,
            port=config.FLASK_PORT,
            debug=config.FLASK_DEBUG,
            use_reloader=False  # Disable reloader in production
        )
    except Exception as e:
        logger.error(f"Failed to start server: {e}")
        raise

