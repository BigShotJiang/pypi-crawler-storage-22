"""Fleet Server Configuration Management

Loads environment variables from .env file and provides defaults.
"""

import os
from pathlib import Path

# Try to import dotenv, fallback if not available
try:
    from dotenv import load_dotenv
    DOTENV_AVAILABLE = True
except ImportError:
    DOTENV_AVAILABLE = False

# Load .env file from fleet_server directory if dotenv is available
FLEET_SERVER_DIR = Path(__file__).parent.absolute()
ENV_FILE = FLEET_SERVER_DIR / '.env'
if DOTENV_AVAILABLE and ENV_FILE.exists():
    load_dotenv(ENV_FILE)

class Config:
    """Base configuration"""
    # Server Settings
    FLASK_HOST = os.getenv('FLASK_HOST', '0.0.0.0')
    FLASK_PORT = int(os.getenv('FLASK_PORT', 5000))
    FLASK_ENV = os.getenv('FLASK_ENV', 'development')
    FLASK_DEBUG = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    
    # Database Path (use absolute path)
    DATABASE_PATH = os.getenv(
        'DATABASE_PATH', 
        str(FLEET_SERVER_DIR / 'fleet.db')
    )
    
    # Upload Directory (use absolute path)
    UPLOAD_FOLDER = os.getenv(
        'UPLOAD_FOLDER',
        str(FLEET_SERVER_DIR / 'uploads')
    )
    
    # Logs Directory
    LOGS_FOLDER = str(FLEET_SERVER_DIR / 'logs')
    LOG_FILE = os.getenv(
        'LOG_FILE',
        str(FLEET_SERVER_DIR / 'logs' / 'fleet_server.log')
    )
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    
    # Security Settings
    MAX_UPLOAD_SIZE = int(os.getenv('MAX_UPLOAD_SIZE', 104857600))  # 100MB default
    ALLOWED_EXTENSIONS = set(os.getenv('ALLOWED_EXTENSIONS', 'yaml,yml,pcd,zip').split(','))
    
    # API Settings
    API_KEY_ENABLED = os.getenv('API_KEY_ENABLED', 'False').lower() == 'true'
    API_KEY = os.getenv('API_KEY', 'your_secret_key_here')
    
    @classmethod
    def ensure_directories(cls):
        """Create required directories if they don't exist"""
        Path(cls.UPLOAD_FOLDER).mkdir(parents=True, exist_ok=True)
        Path(cls.LOGS_FOLDER).mkdir(parents=True, exist_ok=True)

# Development Configuration
class DevelopmentConfig(Config):
    FLASK_ENV = 'development'
    FLASK_DEBUG = True

# Production Configuration
class ProductionConfig(Config):
    FLASK_ENV = 'production'
    FLASK_DEBUG = False

# Testing Configuration
class TestingConfig(Config):
    TESTING = True
    FLASK_DEBUG = True
    DATABASE_PATH = str(FLEET_SERVER_DIR / 'test_fleet.db')

# Select configuration based on environment
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
}

def get_config(env=None):
    """Get configuration object based on environment"""
    if env is None:
        env = os.getenv('FLASK_ENV', 'development')
    return config.get(env, DevelopmentConfig)
