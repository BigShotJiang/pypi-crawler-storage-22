"""Fleet Server Utility Functions

Provides input validation, file handling, and logging utilities.
"""

import os
import re
import logging
from pathlib import Path
from .config import Config

# Configure logging
def setup_logging():
    """Setup logging for fleet server"""
    log_file = Config.LOG_FILE
    log_level = getattr(logging, Config.LOG_LEVEL, logging.INFO)
    
    logger = logging.getLogger('fleet_server')
    logger.setLevel(log_level)
    
    # Ensure log directory exists
    log_dir = os.path.dirname(log_file)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)
    
    # File handler
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(log_level)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    
    # Formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger

logger = setup_logging()

def sanitize_filename(filename):
    """
    Sanitize filename to prevent directory traversal attacks.
    
    Args:
        filename: Original filename from upload
        
    Returns:
        Safe filename string
    """
    # Remove path components
    filename = os.path.basename(filename)
    
    # Remove potentially dangerous characters
    # Keep only alphanumeric, dash, underscore, dot
    filename = re.sub(r'[^\w\-\.]', '_', filename)
    
    # Remove multiple dots (prevents .pcd.exe attacks)
    filename = re.sub(r'\.{2,}', '.', filename)
    
    # Limit length
    name, ext = os.path.splitext(filename)
    if len(name) > 100:
        name = name[:100]
    filename = name + ext
    
    return filename

def validate_file_extension(filename, allowed=None):
    """
    Validate file extension against allowed list.
    
    Args:
        filename: Filename to validate
        allowed: Set of allowed extensions (defaults to Config.ALLOWED_EXTENSIONS)
        
    Returns:
        True if extension is allowed, False otherwise
    """
    if allowed is None:
        allowed = Config.ALLOWED_EXTENSIONS
    
    _, ext = os.path.splitext(filename)
    ext = ext.lstrip('.').lower()
    
    return ext in allowed

def validate_file_size(file_obj, max_size=None):
    """
    Validate file size.
    
    Args:
        file_obj: File-like object to validate
        max_size: Maximum size in bytes (defaults to Config.MAX_UPLOAD_SIZE)
        
    Returns:
        True if within size limit, False otherwise
    """
    if max_size is None:
        max_size = Config.MAX_UPLOAD_SIZE
    
    file_obj.seek(0, os.SEEK_END)
    size = file_obj.tell()
    file_obj.seek(0)
    
    return size <= max_size

def validate_upload(file_obj, filename):
    """
    Comprehensive validation for file uploads.
    
    Args:
        file_obj: File object from request
        filename: Filename from upload
        
    Returns:
        Tuple (is_valid, error_message)
    """
    # Check filename
    if not filename or filename == '':
        return False, "No filename provided"
    
    # Check extension
    if not validate_file_extension(filename):
        return False, f"File type not allowed. Allowed: {', '.join(Config.ALLOWED_EXTENSIONS)}"
    
    # Check file size
    if not validate_file_size(file_obj):
        max_mb = Config.MAX_UPLOAD_SIZE / (1024 * 1024)
        return False, f"File too large (max {max_mb:.0f}MB)"
    
    return True, "Valid"

def get_safe_path(base_dir, filename):
    """
    Get safe absolute path within base directory.
    Prevents directory traversal attacks.
    
    Args:
        base_dir: Base directory (absolute path)
        filename: Requested filename
        
    Returns:
        Safe absolute path if within base_dir, None otherwise
    """
    base = Path(base_dir).resolve()
    requested = (base / filename).resolve()
    
    # Ensure requested path is within base directory
    try:
        requested.relative_to(base)
        return str(requested)
    except ValueError:
        logger.warning(f"Attempted directory traversal: {requested}")
        return None

def format_filesize(size_bytes):
    """
    Format bytes to human-readable size.
    
    Args:
        size_bytes: Size in bytes
        
    Returns:
        Formatted string (e.g., "1.5 MB")
    """
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} TB"
