#!/usr/bin/env python3
import sys
import signal
from PyQt5.QtWidgets import QApplication
from .windows.main_window import MainWindow

def main():
    # Allow Ctrl+C to kill the app
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    app = QApplication(sys.argv)
    
    # Set application metadata
    app.setApplicationName("CalibStudio")
    app.setApplicationVersion("1.0.0")

    window = MainWindow()
    window.show()

    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
