from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QComboBox, QTextEdit, QMessageBox,
                             QGroupBox, QFileDialog, QProgressBar, QRadioButton, QButtonGroup,
                             QDoubleSpinBox, QGridLayout)
from PyQt5.QtCore import QProcess, Qt
import os
import sys

class CalibratorWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.process = None
        self.current_script = None
        self.initUI()

    def initUI(self):
        main_layout = QVBoxLayout()

        # ========== 2D Board Segmentation Parameters ==========
        params_2d_group = QGroupBox("2D Board Segmentation Parameters (Optional)")
        params_2d_layout = QGridLayout()
        
        # Intrinsics file path
        intrinsics_layout = QHBoxLayout()
        self.intrinsics_input = QLineEdit()
        self.intrinsics_input.setPlaceholderText("Path to camera_intrinsics.yaml (leave empty for default)")
        btn_intrinsics_browse = QPushButton("Browse...")
        btn_intrinsics_browse.setMaximumWidth(100)
        btn_intrinsics_browse.clicked.connect(self.browse_intrinsics_file)
        intrinsics_layout.addWidget(QLabel("Intrinsics File:"))
        intrinsics_layout.addWidget(self.intrinsics_input)
        intrinsics_layout.addWidget(btn_intrinsics_browse)
        params_2d_layout.addLayout(intrinsics_layout, 0, 0, 1, 3)
        
        # Tag Size (meters)
        tag_size_layout = QHBoxLayout()
        self.tag_size_input = QLineEdit()
        self.tag_size_input.setText("0.04")
        self.tag_size_input.setMaximumWidth(100)
        self.tag_size_input.setToolTip("AprilTag size in meters (default: 0.04)")
        tag_size_layout.addWidget(QLabel("Tag Size (m):"))
        tag_size_layout.addWidget(self.tag_size_input)
        tag_size_layout.addStretch()
        params_2d_layout.addLayout(tag_size_layout, 1, 0)
        
        # Tag Spacing (meters)
        tag_spacing_layout = QHBoxLayout()
        self.tag_spacing_input = QLineEdit()
        self.tag_spacing_input.setText("0.01")
        self.tag_spacing_input.setMaximumWidth(100)
        self.tag_spacing_input.setToolTip("Spacing between tags in meters (default: 0.01)")
        tag_spacing_layout.addWidget(QLabel("Tag Spacing (m):"))
        tag_spacing_layout.addWidget(self.tag_spacing_input)
        tag_spacing_layout.addStretch()
        params_2d_layout.addLayout(tag_spacing_layout, 1, 1)
        
        # Grid Rows
        grid_rows_layout = QHBoxLayout()
        self.grid_rows_input = QLineEdit()
        self.grid_rows_input.setText("8")
        self.grid_rows_input.setMaximumWidth(100)
        self.grid_rows_input.setToolTip("Number of tag rows (default: 8)")
        grid_rows_layout.addWidget(QLabel("Grid Rows:"))
        grid_rows_layout.addWidget(self.grid_rows_input)
        grid_rows_layout.addStretch()
        params_2d_layout.addLayout(grid_rows_layout, 1, 2)
        
        # Grid Cols
        grid_cols_layout = QHBoxLayout()
        self.grid_cols_input = QLineEdit()
        self.grid_cols_input.setText("11")
        self.grid_cols_input.setMaximumWidth(100)
        self.grid_cols_input.setToolTip("Number of tag columns (default: 11)")
        grid_cols_layout.addWidget(QLabel("Grid Cols:"))
        grid_cols_layout.addWidget(self.grid_cols_input)
        grid_cols_layout.addStretch()
        params_2d_layout.addLayout(grid_cols_layout, 2, 0)
        
        # Board Width (with margins)
        board_w_layout = QHBoxLayout()
        self.board_w_input = QLineEdit()
        self.board_w_input.setText("0.609")
        self.board_w_input.setMaximumWidth(100)
        self.board_w_input.setToolTip("Board width in meters including white margins (default: 0.609)")
        board_w_layout.addWidget(QLabel("Board Width (m):"))
        board_w_layout.addWidget(self.board_w_input)
        board_w_layout.addStretch()
        params_2d_layout.addLayout(board_w_layout, 2, 1)
        
        # Board Height (with margins)
        board_h_layout = QHBoxLayout()
        self.board_h_input = QLineEdit()
        self.board_h_input.setText("0.457")
        self.board_h_input.setMaximumWidth(100)
        self.board_h_input.setToolTip("Board height in meters including white margins (default: 0.457)")
        board_h_layout.addWidget(QLabel("Board Height (m):"))
        board_h_layout.addWidget(self.board_h_input)
        board_h_layout.addStretch()
        params_2d_layout.addLayout(board_h_layout, 2, 2)
        
        params_2d_group.setLayout(params_2d_layout)
        main_layout.addWidget(params_2d_group)

        # ========== Configuration Section ==========
        config_group = QGroupBox("Configuration")
        config_layout = QVBoxLayout()
        
        # Data Root Directory
        data_root_layout = QHBoxLayout()
        self.data_root_input = QLineEdit()
        cwd = os.getcwd()
        # Default to calib_data/new_captures
        default_root = os.path.join(cwd, "calib_data/new_captures")
        self.data_root_input.setText(default_root)
        self.data_root_input.setPlaceholderText("Path to calib_data (e.g., calib_data/new_captures)")
        
        btn_browse = QPushButton("Browse...")
        btn_browse.setMaximumWidth(100)
        btn_browse.clicked.connect(self.browse_data_root)
        
        data_root_layout.addWidget(QLabel("Data Root:"))
        data_root_layout.addWidget(self.data_root_input)
        data_root_layout.addWidget(btn_browse)
        config_layout.addLayout(data_root_layout)
        
        # Best N Poses (for calibration quality filter)
        best_n_layout = QHBoxLayout()
        self.best_n_input = QLineEdit()
        self.best_n_input.setText("15")
        self.best_n_input.setMaximumWidth(100)
        best_n_layout.addWidget(QLabel("Best N Poses:"))
        best_n_layout.addWidget(self.best_n_input)
        best_n_layout.addStretch()
        config_layout.addLayout(best_n_layout)
        
        config_group.setLayout(config_layout)
        main_layout.addWidget(config_group)
        
        # ========== Calibration Steps Section ==========
        steps_group = QGroupBox("Calibration Workflow")
        steps_layout = QVBoxLayout()
        
        # Step 1: Camera Detection
        step1_layout = QHBoxLayout()
        step1_label = QLabel("Step 1: Camera Detection (AprilTag Corners)")
        step1_label.setStyleSheet("font-weight: bold; color: #1976D2;")
        self.btn_camtag = QPushButton("Run Camera Detection")
        self.btn_camtag.setStyleSheet("""
            QPushButton { background-color: #1976D2; color: white; padding: 8px; font-weight: bold; border-radius: 4px; }
            QPushButton:hover { background-color: #1565C0; }
            QPushButton:disabled { background-color: #BDBDBD; }
        """)
        self.btn_camtag.clicked.connect(self.run_camera_detection)
        step1_layout.addWidget(step1_label)
        step1_layout.addStretch()
        step1_layout.addWidget(self.btn_camtag)
        steps_layout.addLayout(step1_layout)
        
        # Step 2: LiDAR Detection
        step2_layout = QHBoxLayout()
        step2_label = QLabel("Step 2: LiDAR Detection (Board Corners)")
        step2_label.setStyleSheet("font-weight: bold; color: #388E3C;")
        self.btn_lidtag = QPushButton("Run LiDAR Detection")
        self.btn_lidtag.setStyleSheet("""
            QPushButton { background-color: #388E3C; color: white; padding: 8px; font-weight: bold; border-radius: 4px; }
            QPushButton:hover { background-color: #2E7D32; }
            QPushButton:disabled { background-color: #BDBDBD; }
        """)
        self.btn_lidtag.clicked.connect(lambda: self.run_script("2d_board_segmentation.py", "--lidar"))
        step2_layout.addWidget(step2_label)
        step2_layout.addStretch()
        step2_layout.addWidget(self.btn_lidtag)
        steps_layout.addLayout(step2_layout)
        
        # Step 3: Calibration
        step3_layout = QHBoxLayout()
        step3_label = QLabel("Step 3: Extrinsic Calibration (Optimization)")
        step3_label.setStyleSheet("font-weight: bold; color: #D32F2F;")
        self.btn_aprilboard = QPushButton("Run Calibration")
        self.btn_aprilboard.setStyleSheet("""
            QPushButton { background-color: #D32F2F; color: white; padding: 8px; font-weight: bold; border-radius: 4px; }
            QPushButton:hover { background-color: #C62828; }
            QPushButton:disabled { background-color: #BDBDBD; }
        """)
        self.btn_aprilboard.clicked.connect(lambda: self.run_script("2d_3d_calibrator.py"))
        step3_layout.addWidget(step3_label)
        step3_layout.addStretch()
        step3_layout.addWidget(self.btn_aprilboard)
        steps_layout.addLayout(step3_layout)
        
        steps_group.setLayout(steps_layout)
        main_layout.addWidget(steps_group)
        
        # ========== Progress Bar ===========
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)
        
        # ========== Log Output ==========
        log_group = QGroupBox("Log Output")
        log_layout = QVBoxLayout()
        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet("font-family: Monospace; font-size: 9pt;")
        self.log_area.setMinimumHeight(400)
        log_layout.addWidget(self.log_area)
        log_group.setLayout(log_layout)
        main_layout.addWidget(log_group, 1)  # Give log more space
        
        # ========== Quick Action Buttons ==========
        action_layout = QHBoxLayout()
        
        btn_run_all = QPushButton("Run All Steps (Sequential)")
        btn_run_all.setStyleSheet("""
            QPushButton { background-color: #FF9800; color: white; padding: 10px; font-weight: bold; border-radius: 4px; }
            QPushButton:hover { background-color: #F57C00; }
        """)
        btn_run_all.clicked.connect(self.run_all_steps)
        
        btn_clear_log = QPushButton("Clear Log")
        btn_clear_log.setMaximumWidth(100)
        btn_clear_log.clicked.connect(self.log_area.clear)
        
        action_layout.addWidget(btn_run_all)
        action_layout.addStretch()
        action_layout.addWidget(btn_clear_log)
        main_layout.addLayout(action_layout, 0)
        
        main_layout.addStretch()
        self.setLayout(main_layout)

    def browse_data_root(self):
        """Open file browser to select data root directory"""
        folder = QFileDialog.getExistingDirectory(self, "Select Data Root Directory")
        if folder:
            self.data_root_input.setText(folder)

    def browse_intrinsics_file(self):
        """Open file browser to select camera intrinsics YAML file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, 
            "Select Camera Intrinsics File", 
            "",
            "YAML Files (*.yaml *.yml);;All Files (*)"
        )
        if file_path:
            self.intrinsics_input.setText(file_path)

    def get_2d_board_args(self):
        """Build 2D board segmentation arguments from GUI inputs"""
        args = []
        
        # Intrinsics file (optional)
        intrinsics = self.intrinsics_input.text().strip()
        if intrinsics:
            args.extend(["--intrinsics", intrinsics])
        
        # Tag size (optional, skip if default)
        tag_size = self.tag_size_input.text().strip()
        if tag_size and tag_size != "0.04":
            args.extend(["--tag_size", tag_size])
        
        # Tag spacing (optional, skip if default)
        tag_spacing = self.tag_spacing_input.text().strip()
        if tag_spacing and tag_spacing != "0.01":
            args.extend(["--tag_spacing", tag_spacing])
        
        # Grid rows (optional, skip if default)
        grid_rows = self.grid_rows_input.text().strip()
        if grid_rows and grid_rows != "8":
            args.extend(["--grid_rows", grid_rows])
        
        # Grid cols (optional, skip if default)
        grid_cols = self.grid_cols_input.text().strip()
        if grid_cols and grid_cols != "11":
            args.extend(["--grid_cols", grid_cols])
        
        # Board width (optional, skip if default)
        board_w = self.board_w_input.text().strip()
        if board_w and board_w != "0.609":
            args.extend(["--board_w", board_w])
        
        # Board height (optional, skip if default)
        board_h = self.board_h_input.text().strip()
        if board_h and board_h != "0.457":
            args.extend(["--board_h", board_h])
        
        return args

    def run_camera_detection(self):
        """Run camera detection with configured parameters"""
        board_args = self.get_2d_board_args()
        camera_args = ["--camera"] + board_args
        self.run_script("2d_board_segmentation.py", camera_args)

    def run_script(self, script_name, script_args=""):
        """Run a calibration script with optional arguments (args can be string or list)"""
        data_root = self.data_root_input.text()
        best_n = self.best_n_input.text()
        
        if not data_root or not os.path.exists(data_root):
            QMessageBox.warning(self, "Error", f"Invalid data root: {data_root}")
            return
        
        # Disable all buttons during execution
        self.set_buttons_enabled(False)
        self.log_area.clear()
        self.log_area.append(f"🚀 Running {script_name}...")
        self.log_area.append(f"   Data Root: {data_root}")
        
        # Display arguments (convert list to string for display)
        if script_args:
            if isinstance(script_args, list):
                args_display = " ".join(script_args)
            else:
                args_display = script_args
            self.log_area.append(f"   Arguments: {args_display}")
        
        if script_name == "2d_3d_calibrator.py":
            self.log_area.append(f"   Best N Poses: {best_n}")
        self.log_area.append("")
        
        self.current_script = script_name
        self.process = QProcess()
        self.process.readyReadStandardOutput.connect(self.handle_stdout)
        self.process.readyReadStandardError.connect(self.handle_stderr)
        self.process.finished.connect(self.on_finished)
        
        # Get script path
        script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), f"../../{script_name}"))
        
        if not os.path.exists(script_path):
            self.log_area.append(f"❌ Script not found: {script_path}")
            self.set_buttons_enabled(True)
            return
        
        cmd = sys.executable  # Use the same Python interpreter
        args = [script_path]
        
        # Add script-specific arguments (handle both list and string)
        if script_args:
            if isinstance(script_args, list):
                args.extend(script_args)
            else:
                args.extend(script_args.split())
        
        # Always add data_root
        args.extend(["--data_root", data_root])
        
        if script_name == "2d_3d_calibrator.py":
            args.extend(["--best_n", best_n])
        
        self.process.start(cmd, args)

    def run_all_steps(self):
        """Run all 3 steps sequentially"""
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Sequential Execution")
        msg_box.setText(
            "Running all steps sequentially:\n"
            "1. Camera Detection\n"
            "2. LiDAR Detection\n"
            "3. 2D_3D_Calibration\n\n"
            "This will take a few minutes...")
        msg_box.setIcon(QMessageBox.Information)
        msg_box.setStandardButtons(QMessageBox.Ok)
        
        # Style the dialog with dark background
        msg_box.setStyleSheet("""
            QMessageBox {
                background-color: #2B2B2B;
            }
            QMessageBox QLabel {
                color: #FFFFFF;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 6px 20px;
                border-radius: 4px;
                font-weight: bold;
                min-width: 60px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        
        msg_box.exec_()
        
        # Build 2D board segmentation args from GUI
        board_args = self.get_2d_board_args()
        camera_args = ["--camera"] + board_args
        lidar_args = ["--lidar"] + board_args
        
        self.steps_queue = [
            ("2d_board_segmentation.py", camera_args), 
            ("2d_board_segmentation.py", lidar_args), 
            ("2d_3d_calibrator.py", "")
        ]
        self.current_step_index = 0
        self.run_next_step()

    def run_next_step(self):
        """Run the next step in the queue"""
        if self.current_step_index < len(self.steps_queue):
            script, script_args = self.steps_queue[self.current_step_index]
            step_num = self.current_step_index + 1
            self.log_area.append(f"\n{'='*80}")
            if script_args:
                self.log_area.append(f"STEP {step_num}/3: {script} {script_args}")
            else:
                self.log_area.append(f"STEP {step_num}/3: {script}")
            self.log_area.append(f"{'='*80}\n")
            self.run_script(script, script_args)
        else:
            self.log_area.append(f"\n{'='*80}")
            self.log_area.append("✅ ALL STEPS COMPLETED SUCCESSFULLY!")
            self.log_area.append(f"{'='*80}\n")
            self.set_buttons_enabled(True)

    def handle_stdout(self):
        """Handle stdout from process"""
        data = self.process.readAllStandardOutput()
        text = data.data().decode()
        self.log_area.append(text)

    def handle_stderr(self):
        """Handle stderr from process"""
        data = self.process.readAllStandardError()
        text = data.data().decode()
        self.log_area.append(f"<span style='color:red'>{text}</span>")

    def on_finished(self):
        """Handle process completion"""
        exit_code = self.process.exitCode()
        
        if exit_code == 0:
            self.log_area.append(f"\n✅ {self.current_script} completed successfully!")
        else:
            self.log_area.append(f"\n❌ {self.current_script} failed with exit code {exit_code}")
        
        # Check if we have more steps to run
        if hasattr(self, 'steps_queue'):
            if exit_code != 0:
                # Step failed - show error and stop
                self.set_buttons_enabled(True)
                msg_box = QMessageBox(self)
                msg_box.setWindowTitle("Error")
                msg_box.setText(f"Step {self.current_step_index + 1} failed. Check logs for details.")
                msg_box.setIcon(QMessageBox.Critical)
                msg_box.setStyleSheet("""
                    QMessageBox {
                        background-color: #3A3A3A;
                    }
                    QMessageBox QLabel {
                        color: #FFFFFF;
                    }
                    QPushButton {
                        background-color: #f44336;
                        color: white;
                        padding: 6px 20px;
                        border-radius: 4px;
                        font-weight: bold;
                        min-width: 60px;
                    }
                    QPushButton:hover {
                        background-color: #da190b;
                    }
                """)
                msg_box.exec_()
                return
            
            self.current_step_index += 1
            if self.current_step_index < len(self.steps_queue):
                self.run_next_step()
            else:
                self.log_area.append(f"\n{'='*80}")
                self.log_area.append("✅ ALL STEPS COMPLETED!")
                self.log_area.append(f"{'='*80}\n")
                self.set_buttons_enabled(True)
        else:
            self.set_buttons_enabled(True)

    def set_buttons_enabled(self, enabled):
        """Enable/disable all action buttons"""
        self.btn_camtag.setEnabled(enabled)
        self.btn_lidtag.setEnabled(enabled)
        self.btn_aprilboard.setEnabled(enabled)

# 3D-3D CALIBRATOR WIDGET (Separate from 2D-3D)

class ThreeDCalibratorWidget(QWidget):
    """3D-3D Calibration using point cloud segmentation and optimization"""
    
    def __init__(self):
        super().__init__()
        self.process = None
        self.current_script = None
        self.initUI()

    def initUI(self):
        # Apply global style for inputs in this widget
        self.setStyleSheet("""
            QDoubleSpinBox {
                background-color: #424242;
                color: white;
                padding: 4px;
                border: 1px solid #666;
                border-radius: 4px;
                selection-background-color: #1976D2;
            }
            QDoubleSpinBox:focus {
                border: 1px solid #4CAF50;
            }
            QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {
                background-color: #555;
                border-radius: 2px;
                width: 16px;
            }
            QDoubleSpinBox::up-button:hover, QDoubleSpinBox::down-button:hover {
                background-color: #777;
            }
            QComboBox {
                background-color: #424242;
                color: white;
                padding: 4px;
                border: 1px solid #666;
                border-radius: 4px;
            }
            QComboBox:on {
                background-color: #424242;
            }
            QComboBox QAbstractItemView {
                background-color: #424242;
                color: white;
                selection-background-color: #1976D2;
                border: 1px solid #666;
            }
            QLineEdit {
                background-color: #424242;
                color: white;
                padding: 4px;
                border: 1px solid #666;
                border-radius: 4px;
            }
        """)

        main_layout = QVBoxLayout()

        # ========== Root Folder Selection (Top-level) ==========
        root_group = QGroupBox("Data Management")
        root_layout = QVBoxLayout()
        
        # Data Root Directory
        data_root_layout = QHBoxLayout()
        self.data_root_input = QLineEdit()
        cwd = os.getcwd()
        # Default to calib_data/cb_data for 3D-3D
        default_root = os.path.join(cwd, "calib_data/cb_data")
        self.data_root_input.setText(default_root)
        self.data_root_input.setPlaceholderText("Path to calib_data (e.g., calib_data/cb_data)")
        
        btn_browse = QPushButton("Browse...")
        btn_browse.setMaximumWidth(100)
        btn_browse.clicked.connect(self.browse_data_root)
        
        data_root_layout.addWidget(QLabel("Root Directory:"))
        data_root_layout.addWidget(self.data_root_input)
        data_root_layout.addWidget(btn_browse)
        root_layout.addLayout(data_root_layout)
        
        root_group.setLayout(root_layout)
        main_layout.addWidget(root_group)

        # ========== Board Segmentation Section ==========
        segmentation_group = QGroupBox("Board Segmentation Parameters")
        segmentation_layout = QHBoxLayout()  # Side-by-side layout for sensors
        
        # --- LiDAR Panel ---
        lidar_panel = QGroupBox("LiDAR Settings")
        lidar_panel.setStyleSheet("QGroupBox { border: 1px solid #4CAF50; border-radius: 6px; margin-top: 10px; } QGroupBox::title { color: #4CAF50; }")
        lidar_layout = QVBoxLayout()
        
        # LiDAR Axis Info (Compact)
        l_axis_label = QLabel("<b>Axis (ROS):</b> X=Fwd, Y=Left, Z=Up")
        l_axis_label.setStyleSheet("color: #AAA; font-size: 9pt;") # Lighter gray for better visibility on dark bg
        lidar_layout.addWidget(l_axis_label)
        
        # LiDAR BBox
        self.lidar_inputs = {'min': {}, 'max': {}}
        l_grid = QGridLayout()
        l_grid.setHorizontalSpacing(5)
        l_grid.setVerticalSpacing(2)
        
        axes = ['X', 'Y', 'Z']
        defaults_l = {'min': [-0.5, -0.8, -0.4], 'max': [2.3, 0.9, 1.0]}
        
        for i, axis in enumerate(axes):
            l_grid.addWidget(QLabel(f"{axis} Min:"), i, 0)
            self.lidar_inputs['min'][axis] = QDoubleSpinBox()
            self.lidar_inputs['min'][axis].setRange(-10, 10)
            self.lidar_inputs['min'][axis].setSingleStep(0.1)
            self.lidar_inputs['min'][axis].setValue(defaults_l['min'][i])
            l_grid.addWidget(self.lidar_inputs['min'][axis], i, 1)
            
            l_grid.addWidget(QLabel(f"{axis} Max:"), i, 2)
            self.lidar_inputs['max'][axis] = QDoubleSpinBox()
            self.lidar_inputs['max'][axis].setRange(-10, 10)
            self.lidar_inputs['max'][axis].setSingleStep(0.1)
            self.lidar_inputs['max'][axis].setValue(defaults_l['max'][i])
            l_grid.addWidget(self.lidar_inputs['max'][axis], i, 3)
            
        lidar_layout.addLayout(l_grid)
        
        # Run Button
        btn_lidar = QPushButton("Run LiDAR Seg")
        btn_lidar.setStyleSheet("""
            QPushButton { background-color: #388E3C; color: white; padding: 5px; border-radius: 4px; }
            QPushButton:hover { background-color: #4CAF50; }
        """)
        btn_lidar.clicked.connect(lambda: self.run_extract_board('lidar'))
        lidar_layout.addWidget(btn_lidar)
        lidar_panel.setLayout(lidar_layout)
        segmentation_layout.addWidget(lidar_panel)
        
        # --- Camera Panel ---
        camera_panel = QGroupBox("Camera Settings")
        camera_panel.setStyleSheet("QGroupBox { border: 1px solid #1976D2; border-radius: 6px; margin-top: 10px; } QGroupBox::title { color: #1976D2; }")
        camera_layout = QVBoxLayout()
        
        # Camera Axis Info (Compact)
        c_axis_label = QLabel("<b>Axis (Optical):</b> X=Right, Y=Down, Z=Fwd")
        c_axis_label.setStyleSheet("color: #AAA; font-size: 9pt;")
        camera_layout.addWidget(c_axis_label)
        
        # Camera BBox
        self.camera_inputs = {'min': {}, 'max': {}}
        c_grid = QGridLayout()
        c_grid.setHorizontalSpacing(5)
        c_grid.setVerticalSpacing(2)
        
        defaults_c = {'min': [-0.9, -0.68, 0.3], 'max': [0.5, 1.0, 2.5]}
        
        for i, axis in enumerate(axes):
            c_grid.addWidget(QLabel(f"{axis} Min:"), i, 0)
            self.camera_inputs['min'][axis] = QDoubleSpinBox()
            self.camera_inputs['min'][axis].setRange(-10, 10)
            self.camera_inputs['min'][axis].setSingleStep(0.1)
            self.camera_inputs['min'][axis].setValue(defaults_c['min'][i])
            c_grid.addWidget(self.camera_inputs['min'][axis], i, 1)
            
            c_grid.addWidget(QLabel(f"{axis} Max:"), i, 2)
            self.camera_inputs['max'][axis] = QDoubleSpinBox()
            self.camera_inputs['max'][axis].setRange(-10, 10)
            self.camera_inputs['max'][axis].setSingleStep(0.1)
            self.camera_inputs['max'][axis].setValue(defaults_c['max'][i])
            c_grid.addWidget(self.camera_inputs['max'][axis], i, 3)
            
        camera_layout.addLayout(c_grid)
        
        # Run Button
        btn_camera = QPushButton("Run Camera Seg")
        btn_camera.setStyleSheet("""
            QPushButton { background-color: #1976D2; color: white; padding: 5px; border-radius: 4px; }
            QPushButton:hover { background-color: #2196F3; }
        """)
        btn_camera.clicked.connect(lambda: self.run_extract_board('camera'))
        camera_layout.addWidget(btn_camera)
        camera_panel.setLayout(camera_layout)
        segmentation_layout.addWidget(camera_panel)
        
        segmentation_group.setLayout(segmentation_layout)
        main_layout.addWidget(segmentation_group)
        
        # ========== Calibration Method ==========
        calib_group = QGroupBox("Calibration Algorithm")
        calib_layout = QHBoxLayout()
        
        calib_layout.addWidget(QLabel("Method:"))
        self.method_combo = QComboBox()
        self.method_combo.addItems([
            "Umeyama (SVD only)", 
            "Optimization (Basin Hopping)", 
            "Both (Sequential Refinement)"
        ])
        self.method_combo.setCurrentIndex(2) # Default to Both
        calib_layout.addWidget(self.method_combo)
        
        btn_run_calib = QPushButton("Run Calibration Only")
        btn_run_calib.setStyleSheet("""
            QPushButton { background-color: #D32F2F; color: white; padding: 10px; font-weight: bold; border-radius: 4px; }
            QPushButton:hover { background-color: #C62828; }
        """)
        btn_run_calib.clicked.connect(self.run_calibration)
        calib_layout.addWidget(btn_run_calib)
        
        calib_group.setLayout(calib_layout)
        main_layout.addWidget(calib_group)
        
        # ========== Quick Action ==========
        action_group = QGroupBox("Batch Processing")
        action_layout_box = QHBoxLayout()
        
        btn_run_all = QPushButton("Run All Sequentially (Cam Seg -> LiDAR Seg -> Calibration)")
        btn_run_all.setStyleSheet("""
            QPushButton { background-color: #FF9800; color: white; padding: 12px; font-weight: bold; border-radius: 6px; font-size: 11pt; }
            QPushButton:hover { background-color: #F57C00; }
        """)
        btn_run_all.clicked.connect(self.run_all_steps_3d)
        action_layout_box.addWidget(btn_run_all)
        action_group.setLayout(action_layout_box)
        main_layout.addWidget(action_group)
        
        # ========== Progress Bar ==========
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)
        
        # ========== Log Output ==========
        log_group = QGroupBox("Log Output")
        log_layout = QVBoxLayout()
        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet("font-family: Monospace; font-size: 9pt;")
        self.log_area.setMinimumHeight(350)
        log_layout.addWidget(self.log_area)
        log_group.setLayout(log_layout)
        main_layout.addWidget(log_group)
        
        # ========== Action Buttons ==========
        action_layout = QHBoxLayout()
        
        btn_clear_log = QPushButton("Clear Log")
        btn_clear_log.setMaximumWidth(100)
        btn_clear_log.clicked.connect(self.log_area.clear)
        
        action_layout.addStretch()
        action_layout.addWidget(btn_clear_log)
        main_layout.addLayout(action_layout)
        
        self.setLayout(main_layout)

    def browse_data_root(self):
        """Open file browser to select data root directory"""
        folder = QFileDialog.getExistingDirectory(self, "Select Data Root Directory")
        if folder:
            self.data_root_input.setText(folder)

    def get_bbox_args(self, sensor):
        """Helper to build bbox arguments for a sensor"""
        if sensor == 'lidar':
            inputs = self.lidar_inputs
        else: # sensor == 'camera'
            inputs = self.camera_inputs
            
        min_bound = [inputs['min'][ax].value() for ax in ['X', 'Y', 'Z']]
        max_bound = [inputs['max'][ax].value() for ax in ['X', 'Y', 'Z']]
        
        return f"--min-bound {min_bound[0]:.2f} {min_bound[1]:.2f} {min_bound[2]:.2f} --max-bound {max_bound[0]:.2f} {max_bound[1]:.2f} {max_bound[2]:.2f}"

    def run_extract_board(self, sensor_type):
        """Run board extraction for specific sensor"""
        data_root = self.data_root_input.text().strip()
        
        if not data_root:
            QMessageBox.warning(self, "Error", "Please select a data root directory")
            return
        
        if not os.path.exists(data_root):
            QMessageBox.warning(self, "Error", f"Data root directory not found: {data_root}")
            return
        
        # Determine script args
        bbox_args = self.get_bbox_args(sensor_type)
        if sensor_type == "lidar":
            args = f"--lidar {bbox_args}"
        else: # sensor_type == "camera"
            args = f"--camera {bbox_args}"
        
        self.run_script("3d_board_segmentation.py", args)

    def run_calibration(self):
        """Run calibration script"""
        data_root = self.data_root_input.text().strip()
        
        if not data_root:
            QMessageBox.warning(self, "Error", "Please select a data root directory")
            return
        
        if not os.path.exists(data_root):
            QMessageBox.warning(self, "Error", f"Data root directory not found: {data_root}")
            return
        
        method_index = self.method_combo.currentIndex()
        if method_index == 0:
            method = "umeyama"
        elif method_index == 1:
            method = "optimize"
        else: # index == 2
            method = "both"
        
        script = "3d_3d_calibrator.py"
        args = f"--method {method} --base_dir {data_root}"
        self.run_script(script, args)

    def run_all_steps_3d(self):
        """Run all 3D calibration steps sequentially"""
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Sequential Execution")
        msg_box.setText(
            "Running all 3D calibration steps sequentially:\n"
            "1. Camera Board Segmentation\n"
            "2. LiDAR Board Segmentation\n"
            "3. 3D-3D Calibration\n\n"
            "This will take several minutes...")
        msg_box.setIcon(QMessageBox.Information)
        msg_box.setStandardButtons(QMessageBox.Ok)
        msg_box.setStyleSheet("QMessageBox { background-color: #2B2B2B; } QLabel { color: white; } QPushButton { background-color: #4CAF50; color: white; }")
        
        if msg_box.exec_() != QMessageBox.Ok:
            return
        
        # Build args using current UI values
        cam_seg_args = self.get_bbox_args('camera')
        lid_seg_args = self.get_bbox_args('lidar')
        
        # Calibration Method
        method_index = self.method_combo.currentIndex()
        if method_index == 0: method = "umeyama"
        elif method_index == 1: method = "optimize"
        else: method = "both"
        
        data_root = self.data_root_input.text().strip()
        calib_args = f"--method {method} --base_dir {data_root}"
        
        # Queue steps
        self.steps_queue_3d = [
            ("3d_board_segmentation.py", f"--camera {cam_seg_args}"),
            ("3d_board_segmentation.py", f"--lidar {lid_seg_args}"),
            ("3d_3d_calibrator.py", calib_args)
        ]
        self.current_step_index_3d = 0
        self.run_next_step_3d()

    def run_next_step_3d(self):
        """Run the next step in the 3D queue"""
        if self.current_step_index_3d < len(self.steps_queue_3d):
            script, script_args = self.steps_queue_3d[self.current_step_index_3d]
            step_num = self.current_step_index_3d + 1
            
            self.log_area.append(f"\n{'='*80}")
            self.log_area.append(f"[STEP {step_num}/3] Running: {script} {script_args}")
            self.log_area.append(f"{'='*80}\n")
            
            self.process = QProcess()
            self.process.readyReadStandardOutput.connect(self.handle_stdout)
            self.process.readyReadStandardError.connect(self.handle_stderr)
            self.process.finished.connect(self.on_step_finished_3d)
            
            # Build and run command
            cmd = f"python3 {script} {script_args}"
            
            # Set working directory to src (go up from gui/widgets to src)
            current_file = os.path.abspath(__file__)
            src_dir = os.path.dirname(os.path.dirname(os.path.dirname(current_file)))
            
            self.progress_bar.setVisible(True)
            self.progress_bar.setRange(0, 0)
            
            self.process.start("bash", ["-c", f"cd {src_dir} && {cmd}"])
        else:
            self.log_area.append(f"\n{'='*80}")
            self.log_area.append("✅ All 3D calibration steps completed successfully!")
            self.log_area.append(f"{'='*80}\n")
            self.progress_bar.setVisible(False)

    def on_step_finished_3d(self, exit_code, exit_status):
        """Handle completion of each step and move to next"""
        if exit_code == 0:
            self.log_area.append(f"✅ Step {self.current_step_index_3d + 1} completed successfully\n")
            self.current_step_index_3d += 1
            self.run_next_step_3d()
        else:
            self.log_area.append(f"❌ Step {self.current_step_index_3d + 1} failed with exit code {exit_code}\n")
            self.progress_bar.setVisible(False)
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Error")
            msg_box.setText(f"Step {self.current_step_index_3d + 1} failed. Check logs for details.")
            msg_box.setIcon(QMessageBox.Critical)
            msg_box.setStyleSheet("""
                QMessageBox {
                    background-color: #3A3A3A;
                }
                QMessageBox QLabel {
                    color: #FFFFFF;
                }
                QPushButton {
                    background-color: #f44336;
                    color: white;
                    padding: 6px 20px;
                    border-radius: 4px;
                    font-weight: bold;
                    min-width: 60px;
                }
                QPushButton:hover {
                    background-color: #da190b;
                }
            """)
            msg_box.exec_()

    def run_script(self, script_name, args="", working_dir=None):
        """Run a Python script with arguments"""
        if self.process is not None and self.process.state() != QProcess.NotRunning:
            QMessageBox.warning(self, "Warning", "A script is already running. Please wait.")
            return
        
        self.current_script = script_name
        self.log_area.append(f"\n{'='*60}")
        self.log_area.append(f"Running: {script_name} {args}")
        self.log_area.append(f"{'='*60}\n")
        
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)  # Indeterminate progress
        
        self.process = QProcess()
        self.process.readyReadStandardOutput.connect(self.handle_stdout)
        self.process.readyReadStandardError.connect(self.handle_stderr)
        self.process.finished.connect(self.process_finished)
        
        # Build command
        cmd = f"python3 {script_name} {args}"
        
        # Set working directory
        if working_dir is None:
            src_dir = os.path.dirname(os.path.abspath(__file__))
            src_dir = os.path.dirname(os.path.dirname(src_dir))  # Go up to src/
        else:
            src_dir = working_dir
        
        self.process.setWorkingDirectory(src_dir)
        self.process.start("bash", ["-c", cmd])

    def handle_stdout(self):
        """Handle standard output from process"""
        data = self.process.readAllStandardOutput()
        text = data.data().decode('utf-8', errors='replace')
        # Append text preserving formatting
        self.log_area.insertPlainText(text)
        # Auto-scroll to bottom
        self.log_area.verticalScrollBar().setValue(self.log_area.verticalScrollBar().maximum())

    def handle_stderr(self):
        """Handle standard error from process"""
        data = self.process.readAllStandardError()
        text = data.data().decode('utf-8', errors='replace')
        # Append stderr with color
        self.log_area.insertHtml(f"<span style='color: #FF6B6B;'>{text}</span>")
        # Auto-scroll to bottom
        self.log_area.verticalScrollBar().setValue(self.log_area.verticalScrollBar().maximum())

    def process_finished(self):
        """Handle process completion"""
        self.progress_bar.setVisible(False)
        exit_code = self.process.exitCode()
        
        # Add completion message
        if exit_code == 0:
            completion_msg = f"\n{'='*60}\n✅ Process completed successfully!\n{'='*60}\n"
        else:
            completion_msg = f"\n{'='*60}\n❌ Process failed with exit code {exit_code}\n{'='*60}\n"
        
        self.log_area.insertPlainText(completion_msg)
        # Auto-scroll to bottom
        self.log_area.verticalScrollBar().setValue(self.log_area.verticalScrollBar().maximum())
        self.process = None

