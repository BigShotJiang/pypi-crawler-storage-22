from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QGroupBox, QLineEdit, QComboBox, QTextEdit, 
                             QRadioButton, QCheckBox, QFileDialog, QMessageBox)
from PyQt5.QtCore import pyqtSignal, Qt, QProcess
import os
import glob
import json
import subprocess

class ExtractorWidget(QWidget):
    """
    Recorder Widget adapted for 3D-3D (LiDAR-Camera) Calibration.
    (Formerly MultimodalRecorderWidget)
    """
    back_clicked = pyqtSignal()

    def __init__(self, enable_depth=True, script_name="3d_3d_data_extractor.py"):
        super().__init__()
        self.enable_depth = enable_depth
        self.script_name = script_name
        self.record_process = None
        self.diag_process = None
        self.initUI()
        
    def initUI(self):
        # Dark Theme Stylesheet
        self.setStyleSheet("""
            QLineEdit, QComboBox, QListWidget {
                background-color: #404040;
                color: #ffffff;
                border: 1px solid #666;
                padding: 5px;
            }
            QLineEdit:disabled, QComboBox:disabled, QListWidget:disabled {
                background-color: #2a2a2a;
                color: #888;
            }
            QMessageBox {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            QMessageBox QLabel {
                color: #ffffff;
            }
            QGroupBox { 
                font-weight: bold; 
                border: 1px solid #555; 
                border-radius: 5px;
                margin-top: 7px; 
                padding-top: 5px;
            } 
            QGroupBox::title { 
                subcontrol-origin: margin; 
                left: 10px; 
                padding: 0 3px 0 3px; 
            }
            QComboBox QAbstractItemView {
                background-color: #404040;
                color: #ffffff;
                selection-background-color: #4CAF50;
                selection-color: white;
            }
            /* Removed global QPushButton style */
        """)
        
        layout = QVBoxLayout()
        layout.setSpacing(6)
        layout.setContentsMargins(5, 5, 5, 5)

        # 1. Source Type
        type_group = QGroupBox("Input Type & Sync Mode")
        type_layout = QHBoxLayout()
        type_layout.setContentsMargins(5, 5, 5, 5)
        type_layout.setSpacing(65)
        
        self.rb_live = QRadioButton("Live Stream (ROS2)")
        self.rb_bag = QRadioButton("Rosbag Recording")
        self.rb_live.setChecked(True)
        self.rb_live.toggled.connect(self.update_ui_state)
        
        # Add checkbox for requiring all topics
        self.chk_require_all = QCheckBox("Require All Topics")
        self.chk_require_all.setToolTip("When checked, all 4 topics must be present. When unchecked, only available topics will be recorded.")
        self.chk_require_all.setChecked(False)  # Default to flexible mode
        
        # Sync Mode checkbox
        self.chk_strict_sync = QCheckBox("Timestamp Sync")
        self.chk_strict_sync.setToolTip(
            "✓ CHECKED: ApproximateTimeSynchronizer (real sensors)\n"
            "✗ UNCHECKED: Latest Messages (bag replay)\n"
            "Auto-fallback if clock skew detected!"
        )
        self.chk_strict_sync.setChecked(True)  # Default: WITH timestamp
        
        type_layout.addWidget(self.rb_live)
        type_layout.addWidget(self.rb_bag)
        type_layout.addSpacing(65)
        type_layout.addWidget(self.chk_require_all)
        type_layout.addSpacing(65)
        type_layout.addWidget(self.chk_strict_sync)
        type_layout.addStretch()
        type_group.setLayout(type_layout)
        layout.addWidget(type_group)

        # 2. Configuration (Topics & Bag)
        self.config_group = QGroupBox("Configuration")
        conf_layout = QVBoxLayout()
        conf_layout.setContentsMargins(5, 5, 5, 5)
        
        # Live Config (Multimodal Topics)
        self.live_widget = QWidget()
        live_l = QVBoxLayout()
        live_l.setContentsMargins(0, 0, 0, 0)
        
        # Topic Rows
        self.combo_lidar = QComboBox()
        self.combo_cam = QComboBox()
        self.combo_depth = QComboBox()
        self.combo_info = QComboBox()
        
        btn_refresh = QPushButton("🔄 Scan") 
        btn_refresh.setFixedWidth(80)
        btn_refresh.clicked.connect(self.scan_topics)
        
        # Layout for topics
        row_lidar = QHBoxLayout()
        row_lidar.addWidget(QLabel("LiDAR:"))
        row_lidar.addWidget(self.combo_lidar, 1)
        row_lidar.addWidget(btn_refresh)
        
        row_cam = QHBoxLayout()
        row_cam.addWidget(QLabel("Image:"))
        row_cam.addWidget(self.combo_cam, 1)
        
        if self.enable_depth:
            row_depth = QHBoxLayout()
            row_depth.addWidget(QLabel("CamDepth:"))
            row_depth.addWidget(self.combo_depth, 1)
        
        row_info = QHBoxLayout()
        row_info.addWidget(QLabel("CamInfo:"))
        row_info.addWidget(self.combo_info, 1)
        
        live_l.addLayout(row_lidar)
        live_l.addLayout(row_cam)
        if self.enable_depth:
            live_l.addLayout(row_depth)
        live_l.addLayout(row_info)
        self.live_widget.setLayout(live_l)
        conf_layout.addWidget(self.live_widget)
        
        # Bag Config
        self.bag_widget = QWidget()
        self.bag_widget.setVisible(False)
        bag_l = QVBoxLayout()
        bag_l.setContentsMargins(0, 0, 0, 0)
        
        # Rosbag file selection
        bag_file_l = QHBoxLayout()
        self.bag_path = QLineEdit()
        self.bag_path.setPlaceholderText("Path to Rosbag Folder")
        btn_browse_bag = QPushButton("Browse")
        btn_browse_bag.clicked.connect(self.browse_bag)
        self.cb_loop = QCheckBox("Loop")
        self.cb_loop.setChecked(True)
        bag_file_l.addWidget(QLabel("Folder:"))
        bag_file_l.addWidget(self.bag_path, 1)
        bag_file_l.addWidget(btn_browse_bag)
        bag_file_l.addWidget(self.cb_loop)
        bag_l.addLayout(bag_file_l)
        
        # Topic selection for rosbag
        self.bag_topics_widget = QWidget()
        bag_topics_l = QVBoxLayout()
        bag_topics_l.setContentsMargins(0, 0, 0, 0)
        
        # Topic Rows for bag mode
        self.bag_combo_lidar = QComboBox()
        self.bag_combo_cam = QComboBox()
        self.bag_combo_depth = QComboBox()
        self.bag_combo_info = QComboBox()
        
        btn_scan_bag = QPushButton("🔄 Scan")
        btn_scan_bag.setFixedWidth(80)
        btn_scan_bag.clicked.connect(self.scan_bag_topics)
        
        # Layout for bag topics
        bag_row_lidar = QHBoxLayout()
        bag_row_lidar.addWidget(QLabel("LiDAR:"))
        bag_row_lidar.addWidget(self.bag_combo_lidar, 1)
        bag_row_lidar.addWidget(btn_scan_bag)
        
        bag_row_cam = QHBoxLayout()
        bag_row_cam.addWidget(QLabel("Image:"))
        bag_row_cam.addWidget(self.bag_combo_cam, 1)
        
        if self.enable_depth:
            bag_row_depth = QHBoxLayout()
            bag_row_depth.addWidget(QLabel("CamDepth:"))
            bag_row_depth.addWidget(self.bag_combo_depth, 1)
        
        bag_row_info = QHBoxLayout()
        bag_row_info.addWidget(QLabel("CamInfo:"))
        bag_row_info.addWidget(self.bag_combo_info, 1)
        
        bag_topics_l.addLayout(bag_row_lidar)
        bag_topics_l.addLayout(bag_row_cam)
        if self.enable_depth:
            bag_topics_l.addLayout(bag_row_depth)
        bag_topics_l.addLayout(bag_row_info)
        self.bag_topics_widget.setLayout(bag_topics_l)
        bag_l.addWidget(self.bag_topics_widget)
        
        self.bag_widget.setLayout(bag_l)
        conf_layout.addWidget(self.bag_widget)
        
        self.config_group.setLayout(conf_layout)
        layout.addWidget(self.config_group)

        # 3. Output Settings
        out_group = QGroupBox("Output & Visual Settings")
        out_layout = QHBoxLayout()
        out_layout.setContentsMargins(6, 6, 6, 6)
        
        # Names
        name_v = QVBoxLayout()
        self.out_folder = QLineEdit()
        self.out_folder.setPlaceholderText("Folder Name (e.g 'set1')")
        self.pose_prefix = QLineEdit()
        self.pose_prefix.setPlaceholderText("Prefix (e.g 'pose')")
        
        r1 = QHBoxLayout()
        r1.addWidget(QLabel("Folder:"))
        r1.addWidget(self.out_folder)
        name_v.addLayout(r1)
        
        r2 = QHBoxLayout()
        r2.addWidget(QLabel("Prefix:"))
        r2.addWidget(self.pose_prefix)
        name_v.addLayout(r2)
        out_layout.addLayout(name_v, 1)
        
        # RViz
        rviz_v = QVBoxLayout()
        self.rviz_combo = QComboBox()
        self.scan_rviz_configs()
        self.rviz_new = QLineEdit()
        self.rviz_new.setPlaceholderText("New Config Name")
        
        rr1 = QHBoxLayout()
        rr1.addWidget(QLabel("RViz Config:"))
        rr1.addWidget(self.rviz_combo)
        rviz_v.addLayout(rr1)
        
        rr2 = QHBoxLayout()
        rr2.addWidget(QLabel("Create New:"))
        rr2.addWidget(self.rviz_new)
        rviz_v.addLayout(rr2)
        out_layout.addLayout(rviz_v, 1)
        
        out_group.setLayout(out_layout)
        layout.addWidget(out_group)
        
        # 4. Log
        self.rec_log = QTextEdit()
        self.rec_log.setReadOnly(True)
        self.rec_log.setStyleSheet("background-color: #1e1e1e; color: #00ff00; font-family: Monospace;")
        layout.addWidget(self.rec_log, 1)
        
        # 6. Controls
        ctrl_layout = QHBoxLayout()
        self.btn_start = QPushButton("▶ Start")
        self.btn_start.setStyleSheet("""
            QPushButton { background-color: #4CAF50; color: white; padding: 10px; font-weight: bold; }
            QPushButton:hover { background-color: #66BB6A; }
        """)
        self.btn_start.clicked.connect(self.start_process)
        
        self.btn_pause = QPushButton("⏯ Play/Pause")
        self.btn_pause.setStyleSheet("""
            QPushButton { background-color: #2196F3; color: white; padding: 10px; }
            QPushButton:hover { background-color: #42A5F5; }
        """)
        self.btn_pause.clicked.connect(self.toggle_pause)
        self.btn_pause.setEnabled(False)
        
        self.btn_capture = QPushButton("📸 Capture Set")
        self.btn_capture.setStyleSheet("""
            QPushButton { background-color: #FF9800; color: white; padding: 10px; font-weight: bold; }
            QPushButton:hover { background-color: #FFA726; }
        """)
        self.btn_capture.clicked.connect(self.capture_frame)
        self.btn_capture.setEnabled(False)
        
        self.btn_stop = QPushButton("⏹ Stop")
        self.btn_stop.setStyleSheet("""
            QPushButton { background-color: #d32f2f; color: white; padding: 10px; }
            QPushButton:hover { background-color: #ef5350; }
        """)
        self.btn_stop.clicked.connect(self.stop_process)
        self.btn_stop.setEnabled(False)
        
        ctrl_layout.addWidget(self.btn_start)
        ctrl_layout.addWidget(self.btn_pause)
        ctrl_layout.addWidget(self.btn_capture)
        ctrl_layout.addWidget(self.btn_stop)
        layout.addLayout(ctrl_layout)
        
        # Back Btn (Consistency)
        btn_back = QPushButton("Back")
        btn_back.clicked.connect(self.on_back_clicked)
        # Explicit style to match SingleLiDAR
        btn_back.setStyleSheet("""
            QPushButton { background-color: #2E8B57; border-radius: 8px; color: white; padding: 5px; }
            QPushButton:hover { background-color: #689F38; }
        """)
        layout.addWidget(btn_back)
        
        self.setLayout(layout)

    def on_back_clicked(self):
        self.stop_process()
        self.back_clicked.emit()

    # --- Logic Methods ---
    def update_ui_state(self):
        is_live = self.rb_live.isChecked()
        self.live_widget.setVisible(is_live)
        self.bag_widget.setVisible(not is_live)
        self.btn_pause.setEnabled(False)

    def scan_topics(self):
        self.rec_log.append("Scanning ROS2 topics...")
        self.combo_lidar.clear()
        self.combo_cam.clear()
        self.combo_depth.clear()
        self.combo_info.clear()
        
        script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), f"../../{self.script_name}"))
        proc = subprocess.run(['python3', script_path, '--mode', 'discover', '--format', 'json'], 
                              capture_output=True, text=True)
        try:
            data = json.loads(proc.stdout)
            
            # Populate from backend categorization
            self.combo_lidar.addItems(sorted(data.get('lidar', [])))
            self.combo_cam.addItems(sorted(data.get('image', [])))
            self.combo_depth.addItems(sorted(data.get('depth', [])))
            self.combo_info.addItems(sorted(data.get('cam_info', [])))
            
            # Count real topics (exclude 'None')
            total = sum(len([x for x in v if x != 'None']) for v in data.values() if isinstance(v, list))
            self.rec_log.append(f"Topics scanned. Found {total} active topics.")
            
        except json.JSONDecodeError:
            self.rec_log.append("Error scanning topics.")
    
    def scan_bag_topics(self):
        bag_path = self.bag_path.text().strip()
        if not bag_path or not os.path.exists(bag_path):
            QMessageBox.warning(self, "Warning", "Please select a valid rosbag folder first.")
            return
            
        self.rec_log.append("Scanning rosbag topics...")
        self.bag_combo_lidar.clear()
        self.bag_combo_cam.clear()
        self.bag_combo_depth.clear()
        self.bag_combo_info.clear()
        
        script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), f"../../{self.script_name}"))
        proc = subprocess.run(['python3', script_path, '--mode', 'discover_bag', '--bag', bag_path, '--format', 'json'], 
                              capture_output=True, text=True)
        
        self.rec_log.append(f"Script stdout: {proc.stdout}")
        self.rec_log.append(f"Script stderr: {proc.stderr}")
        
        try:
            data = json.loads(proc.stdout)
            
            # Populate from backend categorization
            self.bag_combo_lidar.addItems(data.get('lidar', ['None']))
            self.bag_combo_cam.addItems(data.get('image', ['None']))
            self.bag_combo_depth.addItems(data.get('depth', ['None']))
            self.bag_combo_info.addItems(data.get('cam_info', ['None']))
            
            # Count real topics (exclude 'None')
            total = sum(len([x for x in v if x != 'None']) for v in data.values() if isinstance(v, list))
            self.rec_log.append(f"Rosbag topics scanned. Found {total} topics.")
            
        except json.JSONDecodeError as e:
            self.rec_log.append(f"JSON decode error: {e}")
            self.rec_log.append(f"Raw output: {repr(proc.stdout)}")
        except Exception as e:
            self.rec_log.append(f"Unexpected error: {e}")

    def scan_rviz_configs(self):
        self.rviz_combo.clear()
        config_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../rviz_configs"))
        os.makedirs(config_dir, exist_ok=True)
        files = glob.glob(os.path.join(config_dir, "*.rviz"))
        names = [os.path.basename(f) for f in files]
        if not names: self.rviz_combo.addItem("default_calib.rviz")
        else: self.rviz_combo.addItems(sorted(names))

    def browse_bag(self):
        path = QFileDialog.getExistingDirectory(self, "Select Rosbag Folder", "")
        if path: self.bag_path.setText(path)
        
    def start_process(self):
        script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), f"../../{self.script_name}"))
        is_live = self.rb_live.isChecked()
        args = ["-u", script_path]
        
        # Determine sync mode based on checkbox
        sync_mode = 'strict' if self.chk_strict_sync.isChecked() else 'relaxed'
        
        if is_live:
            lidar = self.combo_lidar.currentText()
            cam = self.combo_cam.currentText()
            
            if self.enable_depth:
                depth = self.combo_depth.currentText()
            else:
                depth = 'None'
                
            info = self.combo_info.currentText()
            
            if not lidar or not cam:
                QMessageBox.warning(self, "Warning", "Select at least LiDAR and Camera topics.")
                return
            
            args.extend(['--mode', 'live', 
                         '--lidar_topic', lidar,
                         '--camera_topic', cam, 
                         '--depth_topic', depth, 
                         '--caminfo_topic', info,
                         '--sync-mode', sync_mode])
            
            # Add require_all_topics flag if checkbox is checked
            if self.chk_require_all.isChecked():
                args.append('--require_all_topics')
            
            self.btn_pause.setEnabled(True) # Enabled for Master Pause
        else:
            bag = self.bag_path.text().strip()
            if not os.path.exists(bag):
                QMessageBox.warning(self, "Warning", "Invalid bag path.")
                return
            
            # Get selected topics for bag mode
            bag_lidar = self.bag_combo_lidar.currentText()
            bag_cam = self.bag_combo_cam.currentText()
            
            if self.enable_depth:
                bag_depth = self.bag_combo_depth.currentText()
            else:
                bag_depth = 'None'
                
            bag_info = self.bag_combo_info.currentText()
            
            args.extend(['--mode', 'bag', '--bag', bag,
                         '--lidar_topic', bag_lidar,
                         '--camera_topic', bag_cam,
                         '--depth_topic', bag_depth,
                         '--caminfo_topic', bag_info,
                         '--sync-mode', sync_mode])
            
            # Add require_all_topics flag if checkbox is checked
            if self.chk_require_all.isChecked():
                args.append('--require_all_topics')
            
            if not self.cb_loop.isChecked(): args.append('--play_once')
            self.btn_pause.setEnabled(True)
        
        # Naming & RViz
        if self.out_folder.text(): args.extend(['--output_name', self.out_folder.text()])
        if self.pose_prefix.text(): args.extend(['--pose_prefix', self.pose_prefix.text()])
        
        new_rviz = self.rviz_new.text().strip()
        sel_rviz = self.rviz_combo.currentText()
        if new_rviz: 
            if not new_rviz.endswith('.rviz'): new_rviz += '.rviz'
            args.extend(['--rviz_config', new_rviz])
        elif sel_rviz:
            args.extend(['--rviz_config', sel_rviz])

        self.rec_log.clear()
        self.rec_log.append(f"🟢 Starting Process: {'Live' if is_live else 'Bag'} Mode (Multimodal)")
        
        self.record_process = QProcess()
        self.record_process.readyReadStandardOutput.connect(self.handle_stdout)
        self.record_process.readyReadStandardError.connect(self.handle_stderr)
        self.record_process.finished.connect(self.on_finished)
        self.record_process.start("python3", args)
        
        self.btn_start.setEnabled(False)
        self.btn_capture.setEnabled(True)
        self.btn_stop.setEnabled(True)
        
        # Disable configs
        self.live_widget.setEnabled(False)
        self.bag_widget.setEnabled(False)
        self.out_folder.setEnabled(False)
        self.pose_prefix.setEnabled(False)
        self.rviz_combo.setEnabled(False)

    def stop_process(self):
        if self.record_process and self.record_process.state() == QProcess.Running:
            self.rec_log.append("🛑 Stopping process and closing RViz...")
            self.record_process.write(b'q\n')
            self.record_process.waitForFinished(3000)  # Wait longer for graceful shutdown
            if self.record_process.state() == QProcess.Running:
                self.rec_log.append("⚠️ Force killing process...")
                self.record_process.kill()
                self.record_process.waitForFinished(1000)
        
        # Force kill any remaining RViz processes
        try:
            import subprocess
            subprocess.run(['pkill', '-f', 'rviz2'], capture_output=True)
            self.rec_log.append("🔧 Cleaned up RViz processes")
        except Exception as e:
            self.rec_log.append(f"⚠️ RViz cleanup warning: {e}")

    def capture_frame(self):
        if self.record_process: self.record_process.write(b'n\n')

    def toggle_pause(self):
        if self.record_process: self.record_process.write(b'p\n')

    def handle_stdout(self):
        data = self.record_process.readAllStandardOutput()
        self.rec_log.append(data.data().decode().strip())
        
    def handle_stderr(self):
        data = self.record_process.readAllStandardError()
        text = data.data().decode().strip()
        self.rec_log.append(text)
        
        # Check for topic validation error
        if "[ERROR] All topics are 'None'" in text:
            QMessageBox.critical(self, "Topic Error", 
                "All topics are 'None'.\n\nPlease select valid topics before starting the process.")
            self.stop_process()
        elif "[ERROR] Some topics are 'None'" in text:
            # Determine expected topic count based on script
            if self.script_name == "2d_3d_data_extractor.py":
                topic_count = "3"
                mode_name = "2D-3D"
            else:
                topic_count = "4" 
                mode_name = "3D-3D"
            
            QMessageBox.critical(self, "Topic Error", 
                f"Some topics are 'None'.\n\nWhen 'Require All Topics' is checked, all {topic_count} topics must be selected for {mode_name} calibration mode.")
            self.stop_process()

    def on_finished(self):
        self.btn_start.setEnabled(True)
        self.btn_capture.setEnabled(False)
        self.btn_stop.setEnabled(False)
        self.btn_pause.setEnabled(False)
        
        self.live_widget.setEnabled(True)
        self.bag_widget.setEnabled(True)
        self.out_folder.setEnabled(True)
        self.pose_prefix.setEnabled(True)
        self.rviz_combo.setEnabled(True)
        self.scan_rviz_configs()
        
        self.rec_log.append("\n✅ Process Stopped.")

