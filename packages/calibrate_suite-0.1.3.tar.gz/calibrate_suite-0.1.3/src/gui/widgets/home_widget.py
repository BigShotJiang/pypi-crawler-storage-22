import os
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QSizePolicy, QSpacerItem, QFrame, QGraphicsDropShadowEffect)
from PyQt5.QtCore import Qt, pyqtSignal, QRect
from PyQt5.QtGui import QFont, QPixmap, QPainter, QBrush, QPalette, QColor

class HomeWidget(QWidget):
    # Signals to tell MainWindow to switch keys
    # 1: Single LiDAR, 2: 3D-3D, 3: 2D-3D
    navigate = pyqtSignal(int) 

    def __init__(self):
        super().__init__()
        self.initUI()

    def rounded_pixmap(self, path, size=200, radius=100):
        # Build absolute path relative to this script
        base_dir = os.path.dirname(os.path.abspath(__file__))
        abs_path = os.path.join(base_dir, "..", "assets", path)
        abs_path = os.path.abspath(abs_path)
        pixmap = QPixmap(abs_path)
        if pixmap.isNull():
            print(f"Warning: Logo image not found at {abs_path}")
            return QPixmap(size, size)  # Return empty pixmap
        pixmap = pixmap.scaled(size, size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        rounded = QPixmap(size, size)
        rounded.fill(Qt.transparent)

        painter = QPainter(rounded)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(QBrush(pixmap))
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(QRect(0, 0, size, size), radius, radius)
        painter.end()

        return rounded

    def initUI(self):
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(40)

        # 1. Company Logo & Name
        title_label = QLabel("VIRYA AUTONOMOUS")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("font-size: 40px; font-weight: bold; color: #4CAF50;")
        layout.addWidget(title_label)

        # Add shadow effect to title
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(8)
        shadow.setColor(QColor(0, 0, 0, 160))
        shadow.setOffset(2, 2)
        title_label.setGraphicsEffect(shadow)  

        # Logo with rounded edges
        logo_label = QLabel()
        logo_label.setAlignment(Qt.AlignCenter)
        logo_label.setPixmap(self.rounded_pixmap("virya.jpg", size=200, radius=100))
        layout.addWidget(logo_label)

        # Spacer
        layout.addSpacerItem(QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding))

        # 2. "Select Calibration Type"
        subtitle = QLabel("Choose Calibration Mode")
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("font-size: 24px; color: #e0e0e0; margin-bottom: 20px;")
        layout.addWidget(subtitle)

        # 3. Buttons Container
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(30)
        btn_layout.setAlignment(Qt.AlignCenter)

        # Button Style
        btn_style = """
            QPushButton {
                background-color: #32CD32;
                color: white;
                border: 1px solid #228B22;
                border-radius: 15px;
                padding: 30px;
                font-size: 18px;
                min-width: 180px;
            }
            QPushButton:hover {
                background-color: #3CB371;
                border-color: #228B22;
            }
            QPushButton:pressed {
                background-color: #228B22;
            }
        """

        self.btn_single = QPushButton("Single LiDAR\nCalibration")
        self.btn_single.setStyleSheet(btn_style)
        self.btn_single.clicked.connect(lambda: self.navigate.emit(1))
        
        self.btn_3d3d = QPushButton("3D-3D\nCalibration")
        self.btn_3d3d.setStyleSheet(btn_style)
        self.btn_3d3d.clicked.connect(lambda: self.navigate.emit(2))
        
        self.btn_2d3d = QPushButton("2D-3D\nCalibration")
        self.btn_2d3d.setStyleSheet(btn_style)
        self.btn_2d3d.clicked.connect(lambda: self.navigate.emit(3))

        btn_layout.addWidget(self.btn_single)
        btn_layout.addWidget(self.btn_3d3d)
        btn_layout.addWidget(self.btn_2d3d)

        layout.addLayout(btn_layout)
        
        # Bottom spacer
        layout.addSpacerItem(QSpacerItem(20, 100, QSizePolicy.Minimum, QSizePolicy.Expanding))

        self.setLayout(layout)