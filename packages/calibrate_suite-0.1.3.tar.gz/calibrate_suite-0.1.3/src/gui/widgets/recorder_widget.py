from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QComboBox, QMessageBox, 
                             QGroupBox, QCheckBox)
from PyQt5.QtCore import QProcess
import datetime
import os

class RecorderWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.process = None
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # Config
        group = QGroupBox("Recording Configuration")
        form = QVBoxLayout()

        # Output Name
        name_layout = QHBoxLayout()
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("e.g. calibration_run_1")
        name_layout.addWidget(QLabel("Session Name:"))
        name_layout.addWidget(self.name_input)
        form.addLayout(name_layout)

        # Topics (Simplified for now)
        self.topics = [
            "/velodyne_points",
            "/zed/zed_node/left/image_rect_color",
            "/zed/zed_node/depth/depth_registered",
            "/zed/zed_node/left/camera_info",
            "/tf",
            "/tf_static"
        ]
        
        form.addWidget(QLabel("Recording Topics:"))
        for topic in self.topics:
            cb = QCheckBox(topic)
            cb.setChecked(True)
            cb.setEnabled(False) # Forcing these for now
            form.addWidget(cb)

        group.setLayout(form)
        layout.addWidget(group)

        # Controls
        btn_layout = QHBoxLayout()
        self.btn_rec = QPushButton("🟢 Start Recording")
        self.btn_rec.clicked.connect(self.toggle_recording)
        self.btn_rec.setStyleSheet("""
            QPushButton { background-color: #d32f2f; color: white; font-size: 16px; padding: 15px; }
            QPushButton:hover { background-color: #ef5350; }
        """)
        
        self.lbl_status = QLabel("Status: Idle")
        self.lbl_status.setStyleSheet("color: #888; font-weight: bold;")

        btn_layout.addWidget(self.btn_rec)
        btn_layout.addWidget(self.lbl_status)
        layout.addLayout(btn_layout)

        layout.addStretch()
        self.setLayout(layout)

    def toggle_recording(self):
        if self.process is None:
            self.start_recording()
        else:
            self.stop_recording()

    def start_recording(self):
        name = self.name_input.text().strip()
        if not name:
            name = f"calib_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

        # Setup Process
        self.process = QProcess()
        self.process.readyReadStandardError.connect(self.handle_stderr)
        self.process.readyReadStandardOutput.connect(self.handle_stdout)
        
        cmd = "ros2"
        args = ["bag", "record", "-o", name] + self.topics
        
        self.process.start(cmd, args)
        self.process.waitForStarted()

        if self.process.state() == QProcess.Running:
            self.btn_rec.setText("🔴 Stop Recording")
            self.btn_rec.setStyleSheet("""
                QPushButton { background-color: #333; color: white; font-size: 16px; padding: 15px; }
                QPushButton:hover { background-color: #555; }
            """)
            self.lbl_status.setText(f"Recording to: {name}...")
            self.lbl_status.setStyleSheet("color: #4CAF50; font-weight: bold;")
            self.name_input.setEnabled(False)
        else:
            QMessageBox.critical(self, "Error", "Failed to start recording process.")
            self.process = None

    def stop_recording(self):
        if self.process:
            # Send SIGINT (Ctrl+C)
            self.process.terminate()
            self.process.waitForFinished(2000)
            if self.process.state() == QProcess.Running:
                self.process.kill() # Force kill if stuck
            
            self.process = None
            self.btn_rec.setText("🟢 Start Recording")
            self.btn_rec.setStyleSheet("""
                QPushButton { background-color: #d32f2f; color: white; font-size: 16px; padding: 15px; }
                QPushButton:hover { background-color: #ef5350; }
            """)
            self.lbl_status.setText("Status: Saved")
            self.lbl_status.setStyleSheet("color: #2196F3; font-weight: bold;")
            self.name_input.setEnabled(True)

    def handle_stderr(self):
        data = self.process.readAllStandardError()
        print(f"[RECORDER STDERR] {data.data().decode()}")

    def handle_stdout(self):
        data = self.process.readAllStandardOutput()
        print(f"[RECORDER STDOUT] {data.data().decode()}")
