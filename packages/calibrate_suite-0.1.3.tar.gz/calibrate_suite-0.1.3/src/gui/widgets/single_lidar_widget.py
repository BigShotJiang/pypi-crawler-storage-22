from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QStackedWidget, QFileDialog, 
                             QLineEdit, QSpinBox, QMessageBox, QGroupBox, QTextEdit, 
                             QComboBox, QRadioButton, QButtonGroup, QCheckBox, QSizePolicy,
                             QListWidget, QListWidgetItem, QAbstractItemView, QTabWidget)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QProcess
import os
import json
import subprocess
import glob

# --- Widget ---
class SingleLidarWidget(QWidget):
    go_home = pyqtSignal() # Signal to return to main menu

    def __init__(self):
        super().__init__()
        self.calib_process = None
        self.record_process = None
        self.diag_process = None
        self.initUI()

    def initUI(self):
        # Apply dark style to inputs for legibility
        self.setStyleSheet("""
            QLineEdit, QComboBox, QListWidget, QSpinBox, QDoubleSpinBox {
                background-color: #404040;
                color: #ffffff;
                border: 1px solid #666;
                padding: 5px;
            }
            QLineEdit:disabled, QComboBox:disabled, QListWidget:disabled {
                background-color: #2a2a2a;
                color: #888;
            }
            QMessageBox {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            QMessageBox QLabel {
                color: #ffffff;
            }
            QComboBox QAbstractItemView {
                background-color: #404040;
                color: #ffffff;
                selection-background-color: #4CAF50;
                selection-color: white;
                border: 1px solid #666;
            }
            QListWidget::item {
                padding: 5px;
            }
            QListWidget::item:selected {
                background-color: #4CAF50;
                color: white;
            }
            /* Removed global QPushButton style to allow buttons to retain default or specific colors */
            /* Removed global QPushButton style */
        """)

        main_layout = QVBoxLayout()
        
        # Header (Home Button)
        header = QHBoxLayout()
        btn_back = QPushButton("← Home")
        btn_back.clicked.connect(self.go_home.emit)
        btn_back.setFixedWidth(100)
        btn_back.setStyleSheet("""
            QPushButton { background-color: #2E8B57; border-radius: 8px; color: white; }
            QPushButton:hover { background-color: #689F38; }
        """)
        header.addWidget(btn_back)
        
        title = QLabel("Single LiDAR Calibration")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #4CAF50;")
        title.setAlignment(Qt.AlignCenter)
        header.addWidget(title)
        header.addStretch()
        main_layout.addLayout(header)
        
        # Tabs
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabBar::tab {
                min-width: 150px;
                padding: 10px;
                font-weight: bold;
            }
            QTabBar::tab:selected {
                background-color: #2E8B57;
                color: white;
            }
        """)
        
        # Tab 1: Recorder
        self.tab_record = self.create_recorder_ui()
        self.tabs.addTab(self.tab_record, "Record / Capture Data")
        
        # Tab 2: Calibration
        self.tab_files = self.create_file_ui()
        self.tabs.addTab(self.tab_files, "Calibrate from Files")
        
        main_layout.addWidget(self.tabs)
        self.setLayout(main_layout)



    def create_recorder_ui(self):
        w = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(6)  # Adjusted to 5px (+1)
        layout.setContentsMargins(5, 5, 5, 5)

        # Reduced top margin stye for GroupBoxes to save vertical space
        group_style = """
            QGroupBox { 
                font-weight: bold; 
                border: 1px solid #555; 
                border-radius: 5px;
                margin-top: 7px; /* Compact top margin */
                padding-top: 5px;
            } 
            QGroupBox::title { 
                subcontrol-origin: margin; 
                left: 10px; 
                padding: 0 3px 0 3px; 
            }
        """

        # 1. Source Type
        type_group = QGroupBox("Input Type")
        type_group.setStyleSheet(group_style)
        type_layout = QHBoxLayout()
        type_layout.setContentsMargins(5, 5, 5, 5) # Slight internal padding
        self.rb_live = QRadioButton("Live Stream (ROS2)")
        self.rb_bag = QRadioButton("Rosbag Recording")
        self.rb_live.setChecked(True)
        self.rb_live.toggled.connect(self.update_rec_ui_state)
        type_layout.addWidget(self.rb_live)
        type_layout.addWidget(self.rb_bag)
        type_group.setLayout(type_layout)
        layout.addWidget(type_group, 0) # No stretch

        # 2. Configuration
        self.config_stack = QStackedWidget()
        # No fixed height, let it size naturally but minimally
        
        # Live
        live_w = QWidget()
        live_l = QHBoxLayout()
        live_l.setContentsMargins(0, 0, 0, 0)
        
        # MULTI-SELECTION LIST
        self.topic_list = QListWidget()
        self.topic_list.setSelectionMode(QAbstractItemView.NoSelection) # We use checkboxes
        self.topic_list.setFixedHeight(80) # Fixed height to not consume too much space
        
        btn_refresh = QPushButton("🔄 Scan Topics") 
        btn_refresh.setFixedWidth(150)
        btn_refresh.clicked.connect(self.scan_topics)
        
        live_l.addWidget(QLabel("LiDAR Topics:"))
        live_l.addWidget(self.topic_list, 1)
        live_l.addWidget(btn_refresh)
        live_w.setLayout(live_l)
        
        # Bag
        bag_w = QWidget()
        bag_l = QVBoxLayout()
        bag_l.setContentsMargins(1, 1, 1, 1)
        
        # Row 1: Folder
        row_folder = QHBoxLayout()
        self.bag_path = QLineEdit()
        self.bag_path.setPlaceholderText("Path to Rosbag Folder")
        btn_browse_bag = QPushButton("Browse")
        btn_browse_bag.clicked.connect(self.browse_bag)
        self.cb_loop = QCheckBox("Loop")
        self.cb_loop.setChecked(True)
        
        row_folder.addWidget(QLabel("Folder:"))
        row_folder.addWidget(self.bag_path, 1)
        row_folder.addWidget(btn_browse_bag)
        row_folder.addWidget(self.cb_loop)
        bag_l.addLayout(row_folder)
        
        # Row 2: Topic Selection (List Widget style)
        row_topic = QHBoxLayout()
        row_topic.setContentsMargins(0, 0, 0, 0)
        
        self.bag_topic_list = QListWidget()
        self.bag_topic_list.setSelectionMode(QAbstractItemView.NoSelection)
        self.bag_topic_list.setFixedHeight(80)
        
        btn_scan_bag = QPushButton("🔄 Scan Topics") 
        btn_scan_bag.setFixedWidth(150)
        btn_scan_bag.clicked.connect(self.scan_bag_topics)
        
        row_topic.addWidget(QLabel("LiDAR Topics:"))
        row_topic.addWidget(self.bag_topic_list, 1)
        row_topic.addWidget(btn_scan_bag)
        bag_l.addLayout(row_topic)
        
        # Info Label
        lbl_info = QLabel("ℹ️ LiDAR topic should be for 3D cloud (PointCloud2)")
        lbl_info.setStyleSheet("color: #AAA; font-size: 10px; margin-left: 5px;")
        bag_l.addWidget(lbl_info)
        
        bag_w.setLayout(bag_l)
        
        self.config_stack.addWidget(live_w)
        self.config_stack.addWidget(bag_w)
        layout.addWidget(self.config_stack, 0)

        # 3. Output Settings (Expanded with RViz)
        out_group = QGroupBox("Output & Visual Settings")
        out_group.setStyleSheet(group_style)
        out_layout = QHBoxLayout()
        out_layout.setContentsMargins(6, 6, 6, 6)
        
        # Sub-layout for Names
        name_v = QVBoxLayout()
        out_layout.addLayout(name_v, 1)
        
        self.out_folder = QLineEdit()
        self.out_folder.setPlaceholderText("Folder Name (e.g 'dataset_1')")
        self.pose_prefix = QLineEdit()
        self.pose_prefix.setPlaceholderText("Pose Prefix (e.g 'scan')")
        
        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Folder:"))
        row1.addWidget(self.out_folder)
        name_v.addLayout(row1)
        
        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Prefix:"))
        row2.addWidget(self.pose_prefix)
        name_v.addLayout(row2)

        # RViz settings
        rviz_v = QVBoxLayout()
        out_layout.addLayout(rviz_v, 1)
        
        self.rviz_combo = QComboBox()
        self.scan_rviz_configs()
        
        self.rviz_new = QLineEdit()
        self.rviz_new.setPlaceholderText("New Config Name (optional)")
        
        r1 = QHBoxLayout()
        r1.addWidget(QLabel("RViz Config:"))
        r1.addWidget(self.rviz_combo)
        rviz_v.addLayout(r1)
        
        r2 = QHBoxLayout()
        r2.addWidget(QLabel("Create New:"))
        r2.addWidget(self.rviz_new)
        rviz_v.addLayout(r2)

        out_group.setLayout(out_layout)
        layout.addWidget(out_group, 0)

        # 4. Output Log
        self.rec_log = QTextEdit()
        self.rec_log.setReadOnly(True)
        self.rec_log.setStyleSheet("background-color: #1e1e1e; color: #00ff00; font-family: Monospace;")
        # Give the log window the stretch priority (1) while others are 0
        layout.addWidget(self.rec_log, 1)
        
        # 6. Controls
        ctrl_layout = QHBoxLayout()
        self.btn_start_rec = QPushButton("▶ Start")
        self.btn_start_rec.setStyleSheet("""
            QPushButton { background-color: #4CAF50; color: white; padding: 10px; font-weight: bold; }
            QPushButton:hover { background-color: #66BB6A; }
        """)
        self.btn_start_rec.clicked.connect(self.start_listening)
        
        self.btn_play_pause = QPushButton("⏯ Play/Pause")
        self.btn_play_pause.setStyleSheet("""
            QPushButton { background-color: #2196F3; color: white; padding: 10px; }
            QPushButton:hover { background-color: #42A5F5; }
        """)
        self.btn_play_pause.clicked.connect(self.toggle_pause)
        self.btn_play_pause.setEnabled(False) 
        
        self.btn_capture = QPushButton("📸 Capture Frame")
        self.btn_capture.setStyleSheet("""
            QPushButton { background-color: #FF9800; color: white; padding: 10px; font-weight: bold; }
            QPushButton:hover { background-color: #FFA726; }
        """)
        self.btn_capture.clicked.connect(self.capture_pose)
        self.btn_capture.setEnabled(False)
        
        self.btn_stop_rec = QPushButton("⏹ Stop")
        self.btn_stop_rec.setStyleSheet("""
            QPushButton { background-color: #d32f2f; color: white; padding: 10px; }
            QPushButton:hover { background-color: #ef5350; }
        """)
        self.btn_stop_rec.clicked.connect(self.stop_listening)
        self.btn_stop_rec.setEnabled(False)

        ctrl_layout.addWidget(self.btn_start_rec)
        ctrl_layout.addWidget(self.btn_play_pause)
        ctrl_layout.addWidget(self.btn_capture)
        ctrl_layout.addWidget(self.btn_stop_rec)
        layout.addLayout(ctrl_layout, 0)
        
        # 7. Back Button
        btn_back = QPushButton("← Back")
        btn_back.clicked.connect(self.back_from_record)
        btn_back.setStyleSheet("""
            QPushButton { background-color: #2E8B57; border-radius: 8px; color: white; padding: 8px; font-weight: bold; }
            QPushButton:hover { background-color: #689F38; }
        """)
        layout.addWidget(btn_back, 0)

        
        w.setLayout(layout)
        return w

    def create_file_ui(self):
        w = QWidget()
        layout = QVBoxLayout()
        

        
        # Title
        lbl = QLabel("Select 2 Point Clouds (PCD)")
        lbl.setStyleSheet("font-size: 18px; font-weight: bold; margin: 10px;")
        lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(lbl)
        
        # Form
        form_group = QGroupBox()
        form_layout = QVBoxLayout()
        
        # Source
        src_layout = QHBoxLayout()
        self.src_path = QLineEdit()
        self.src_path.setPlaceholderText("Path to Source .pcd")
        self.src_path.textChanged.connect(self.validate_file_inputs)
        btn_src = QPushButton("Browse")
        btn_src.clicked.connect(lambda: self.browse_file(self.src_path))
        src_layout.addWidget(QLabel("Source Cloud:"))
        src_layout.addWidget(self.src_path)
        src_layout.addWidget(btn_src)
        form_layout.addLayout(src_layout)
        
        # Target
        tgt_layout = QHBoxLayout()
        self.tgt_path = QLineEdit()
        self.tgt_path.setPlaceholderText("Path to Target .pcd")
        self.tgt_path.textChanged.connect(self.validate_file_inputs)
        btn_tgt = QPushButton("Browse")
        btn_tgt.clicked.connect(lambda: self.browse_file(self.tgt_path))
        tgt_layout.addWidget(QLabel("Target Cloud:"))
        tgt_layout.addWidget(self.tgt_path)
        tgt_layout.addWidget(btn_tgt)
        form_layout.addLayout(tgt_layout)
        
        form_group.setLayout(form_layout)
        layout.addWidget(form_group)
        
        # Action
        self.btn_calib = QPushButton("Begin Calibration")
        self.btn_calib.clicked.connect(self.run_calibration)
        self.btn_calib.setEnabled(False) 
        self.btn_calib.setStyleSheet("""
            QPushButton {
                background-color: #E65100; 
                color: white; 
                padding: 15px; 
                font-size: 16px; 
                font-weight: bold;
                border-radius: 12px;
            }
            QPushButton:hover {
                background-color: #F57C00;
            }
            QPushButton:disabled {
                background-color: #555;
                color: #888;
            }
        """)
        layout.addWidget(self.btn_calib)
        
        # Logs
        layout.addWidget(QLabel("Process Output:"))
        self.calib_log = QTextEdit()
        self.calib_log.setReadOnly(True)
        self.calib_log.setStyleSheet("font-family: Monospace; font-size: 12px; background-color: #1e1e1e; color: #00ff00;")
        layout.addWidget(self.calib_log)
        
        # Back Button
        btn_back = QPushButton("← Back")
        btn_back.clicked.connect(self.go_home.emit)
        btn_back.setStyleSheet("""
            QPushButton { background-color: #2E8B57; border-radius: 8px; color: white; padding: 8px; font-weight: bold; }
            QPushButton:hover { background-color: #689F38; }
        """)
        layout.addWidget(btn_back)
        
        w.setLayout(layout)
        return w

    # --- Recorder Logic ---
    def update_rec_ui_state(self):
        is_live = self.rb_live.isChecked()
        self.config_stack.setCurrentIndex(0 if is_live else 1)
        self.btn_play_pause.setEnabled(False) # Reset

    def scan_topics(self):
        self.rec_log.append("Scanning ROS2 topics...")
        self.topic_list.clear()
        
        script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../single_data_extractor.py"))
        proc = subprocess.run(['python3', script_path, '--mode', 'discover', '--format', 'json'], 
                              capture_output=True, text=True)
        
        try:
            data = json.loads(proc.stdout)
            topics = data.get('lidar', [])
            for t in topics:
                item = QListWidgetItem(t)
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                item.setCheckState(Qt.Unchecked)
                self.topic_list.addItem(item)
                
            self.rec_log.append(f"Found {len(topics)} LiDAR topics.")
        except json.JSONDecodeError:
            self.rec_log.append("Error scanning topics.")

    def scan_bag_topics(self):
        bag_path = self.bag_path.text().strip()
        if not bag_path or not os.path.exists(bag_path):
            QMessageBox.warning(self, "Warning", "Please select a valid rosbag folder first.")
            return
            
        self.rec_log.append("Scanning rosbag topics...")
        self.bag_topic_list.clear() # Clear list
        
        script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../single_data_extractor.py"))
        proc = subprocess.run(['python3', script_path, '--mode', 'discover_bag', '--bag', bag_path, '--format', 'json'], 
                              capture_output=True, text=True)
        
        try:
            data = json.loads(proc.stdout)
            lidar_topics = data.get('lidar', [])
            
            # Populate ListWidget with Checkboxes
            for t in lidar_topics:
                if t == 'None': continue
                item = QListWidgetItem(t)
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                item.setCheckState(Qt.Unchecked)
                self.bag_topic_list.addItem(item)
                
            self.rec_log.append(f"Rosbag topics scanned. Found {self.bag_topic_list.count()} LiDAR topics.")
        except json.JSONDecodeError:
            self.rec_log.append("Error scanning topics.")
            self.rec_log.append(f"Output: {proc.stdout}")

    def scan_rviz_configs(self):
        self.rviz_combo.clear()
        # Default dir
        config_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../rviz_configs"))
        os.makedirs(config_dir, exist_ok=True)
        
        files = glob.glob(os.path.join(config_dir, "*.rviz"))
        names = [os.path.basename(f) for f in files]
        
        if not names:
            self.rviz_combo.addItem("default_calib.rviz")
        else:
            self.rviz_combo.addItems(sorted(names))
            
    def browse_bag(self):
        path = QFileDialog.getExistingDirectory(self, "Select Rosbag Folder", "")
        if path:
            self.bag_path.setText(path)

    def start_listening(self):
        script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../single_data_extractor.py"))
        is_live = self.rb_live.isChecked()
        
        args = ["-u", script_path]
        
        if is_live:
            # Collect checked items
            selected_topics = []
            for i in range(self.topic_list.count()):
                item = self.topic_list.item(i)
                if item.checkState() == Qt.Checked:
                    selected_topics.append(item.text())
            
            if not selected_topics:
                QMessageBox.warning(self, "Warning", "Select at least one LiDAR topic.")
                return
            
            # Join with commas
            topic_str = ",".join(selected_topics)
            args.extend(['--mode', 'live', '--lidar_topic', topic_str])
            self.btn_play_pause.setEnabled(True) # Enabled for Master Pause feature
        else:
            bag = self.bag_path.text().strip()
            if not os.path.exists(bag):
                QMessageBox.warning(self, "Warning", "Select a valid rosbag folder.")
                return
            args.extend(['--mode', 'bag', '--bag', bag])
            if not self.cb_loop.isChecked():
                args.append('--play_once')
            
            # Add topics if checked
            bag_topics = []
            for i in range(self.bag_topic_list.count()):
                item = self.bag_topic_list.item(i)
                if item.checkState() == Qt.Checked:
                    bag_topics.append(item.text())
            
            if bag_topics:
                # Comma separated for multi-topic support
                args.extend(['--lidar_topic', ",".join(bag_topics)])
            else:
                 QMessageBox.warning(self, "Warning", "Please select at least one LiDAR topic from the list.")
                 return
                
            self.btn_play_pause.setEnabled(True)

        # args.extend(['--calib_mode', 'single_lidar']) # Deprecated in single_data_extractor
        
        # Naming Args
        folder_name = self.out_folder.text().strip()
        if folder_name:
            args.extend(['--output_name', folder_name])
            
        pose_prefix = self.pose_prefix.text().strip()
        if pose_prefix:
            args.extend(['--pose_prefix', pose_prefix])
            
        # RViz Logic
        new_rviz = self.rviz_new.text().strip()
        selected_rviz = self.rviz_combo.currentText().strip()
        
        if new_rviz:
            if not new_rviz.endswith('.rviz'): new_rviz += '.rviz'
            args.extend(['--rviz_config', new_rviz])
        elif selected_rviz:
            args.extend(['--rviz_config', selected_rviz])

        self.rec_log.clear()
        self.rec_log.append(f"🟢 Starting Process: {'Live' if is_live else 'Bag'} Mode")
        
        self.record_process = QProcess()
        self.record_process.readyReadStandardOutput.connect(self.handle_rec_stdout)
        self.record_process.readyReadStandardError.connect(self.handle_rec_stderr)
        self.record_process.finished.connect(self.on_rec_finished)
        
        self.record_process.start("python3", args)
        
        self.btn_start_rec.setEnabled(False)
        self.btn_capture.setEnabled(True)
        self.btn_stop_rec.setEnabled(True)
        
        # Disable inputs
        self.rb_live.setEnabled(False)
        self.rb_bag.setEnabled(False)
        self.out_folder.setEnabled(False)
        self.pose_prefix.setEnabled(False)
        self.rviz_combo.setEnabled(False)
        self.rviz_new.setEnabled(False)
        self.topic_list.setEnabled(False)

    def stop_listening(self):
        if self.record_process and self.record_process.state() == QProcess.Running:
            self.record_process.write(b'q\n')
            self.record_process.waitForFinished(1000)
            if self.record_process.state() == QProcess.Running:
                self.record_process.kill()
        # Finished signal will handle UI reset

    def on_rec_finished(self):
        self.btn_start_rec.setEnabled(True)
        self.btn_capture.setEnabled(False)
        self.btn_stop_rec.setEnabled(False)
        self.btn_play_pause.setEnabled(False)
        
        # Re-enable inputs
        self.rb_live.setEnabled(True)
        self.rb_bag.setEnabled(True)
        self.out_folder.setEnabled(True)
        self.pose_prefix.setEnabled(True)
        self.rviz_combo.setEnabled(True)
        self.rviz_new.setEnabled(True)
        self.topic_list.setEnabled(True)
        
        # SCAN REFRESH in case a new RViz was created
        self.scan_rviz_configs()
        
        self.rec_log.append("\n✅ Process Stopped.")

    def capture_pose(self):
        if self.record_process and self.record_process.state() == QProcess.Running:
            self.record_process.write(b'n\n')

    def toggle_pause(self):
        if self.record_process and self.record_process.state() == QProcess.Running:
            self.record_process.write(b'p\n')

    def handle_rec_stdout(self):
        data = self.record_process.readAllStandardOutput()
        self.rec_log.append(data.data().decode().strip())

    def handle_rec_stderr(self):
        data = self.record_process.readAllStandardError()
        self.rec_log.append(data.data().decode().strip())

    def back_from_record(self):
        self.stop_listening()
        self.go_home.emit()

    # --- Calibration Logic ---
    def browse_file(self, line_edit):
        fname, _ = QFileDialog.getOpenFileName(self, "Select PCD", "", "Point Clouds (*.pcd)")
        if fname:
            line_edit.setText(fname)

    def validate_file_inputs(self):
        src = self.src_path.text().strip()
        tgt = self.tgt_path.text().strip()
        valid = bool(src) and bool(tgt) and os.path.exists(src) and os.path.exists(tgt)
        self.btn_calib.setEnabled(valid)

    def run_calibration(self):
        src = self.src_path.text()
        tgt = self.tgt_path.text()
        
        self.calib_log.clear()
        self.calib_log.append(f"Starting Calibration...\nSource: {src}\nTarget: {tgt}")
        self.btn_calib.setEnabled(False)
        self.btn_calib.setText("Running...")
        
        self.calib_process = QProcess()
        self.calib_process.readyReadStandardOutput.connect(self.handle_calib_stdout)
        self.calib_process.readyReadStandardError.connect(self.handle_calib_stderr)
        self.calib_process.finished.connect(self.on_calib_finished)
        
        script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../single_lidar_calib.py"))
        
        cmd = "python3"
        args = ["-u", script_path, "--src", src, "--tgt", tgt]
        self.calib_process.start(cmd, args)

    def handle_calib_stdout(self):
        data = self.calib_process.readAllStandardOutput()
        self.calib_log.append(data.data().decode())

    def handle_calib_stderr(self):
        data = self.calib_process.readAllStandardError()
        self.calib_log.append(data.data().decode())

    def on_calib_finished(self):
        self.btn_calib.setEnabled(True)
        self.btn_calib.setText("Begin Calibration")
        self.calib_log.append("\n✅ Calibration Process Finished.")
        
    def cleanup(self):
        if self.calib_process and self.calib_process.state() == QProcess.Running:
            self.calib_process.kill()
        if self.record_process and self.record_process.state() == QProcess.Running:
            self.record_process.kill()
        if self.diag_process and self.diag_process.state() == QProcess.Running:
            self.diag_process.kill()
