from PyQt5.QtWidgets import (QWidget, QTabWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QGroupBox, QLineEdit, QComboBox, QTextEdit, 
                             QRadioButton, QCheckBox, QFileDialog, QMessageBox, QSizePolicy, QScrollArea)
from PyQt5.QtCore import pyqtSignal, Qt, QProcess
import os
import glob
import json
import subprocess
import sys
from pathlib import Path

# Add src/ to path for utils import
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from utils import wrap_with_back

# Import existing widgets for other tabs
try:
    from ..widgets.extractor_widget import ExtractorWidget
    from ..widgets.calibrator_widget import CalibratorWidget
    from ..widgets.validator_widget import ValidatorWidget
    from ..widgets.uploader_widget import UploaderWidget
except ImportError:
    from gui.widgets.extractor_widget import ExtractorWidget
    from gui.widgets.calibrator_widget import CalibratorWidget
    from gui.widgets.validator_widget import ValidatorWidget
    from gui.widgets.uploader_widget import UploaderWidget

class TwoDThreeDWidget(QWidget):
    go_home = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        
        # Header
        header = QHBoxLayout()
        btn_back = QPushButton("← Home")
        btn_back.clicked.connect(self.go_home.emit)
        btn_back.setFixedWidth(100)
        btn_back.setStyleSheet("""
            QPushButton { background-color: #2E8B57; border-radius: 8px; color: white; }
            QPushButton:hover { background-color: #689F38; }
        """)
        header.addWidget(btn_back)
        
        title = QLabel("2D-3D Calibration (LiDAR-Camera)")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #FF9800;")
        header.addWidget(title)
        header.addStretch()
        layout.addLayout(header)

        # Tabs
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabBar::tab {
                min-width: 150px;
                padding: 8px;
                font-weight: bold;
            }
            QTabBar::tab:selected {
                background-color: #E65100;
                color: white;
            }
        """)
        self.init_tabs()
        layout.addWidget(self.tabs)
        
        self.setLayout(layout)

    def init_tabs(self):
        # 1. Record (Multimodal) - Uses ExtractorWidget
        rec_widget = ExtractorWidget(enable_depth=False, script_name="2d_3d_data_extractor.py")
        rec_widget.back_clicked.connect(self.go_home.emit)
        self.tabs.addTab(rec_widget, "Record (2D-3D)")
        
        # 2. Calibration (moved up after Record)
        self.tabs.addTab(wrap_with_back(CalibratorWidget(), self.go_home), "Calibrate")
        
        # 3. Validation with Visualization
        self.tabs.addTab(wrap_with_back(ValidatorWidget(), self.go_home), "Validate")
        
        # 4. Upload
        self.tabs.addTab(wrap_with_back(UploaderWidget(), self.go_home), "Fleet Upload")
