from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QMessageBox, QGroupBox, QFileDialog)
from PyQt5.QtCore import QThread, pyqtSignal
import os
import json
import requests

class UploadWorker(QThread):
    finished = pyqtSignal(bool, str)
    
    def __init__(self, server_url, file_path, robot_id, score):
        super().__init__()
        self.server_url = server_url
        self.file_path = file_path
        self.robot_id = robot_id
        self.score = score
        
    def run(self):
        try:
            url = f"{self.server_url}/api/upload"
            
            metadata = {
                'robot_id': self.robot_id,
                'score': self.score
            }
            
            with open(self.file_path, 'rb') as f:
                files = {'artifacts': f}
                data = {'metadata': json.dumps(metadata)}
                
                response = requests.post(url, files=files, data=data)
            
            if response.status_code in [200, 201]:
                self.finished.emit(True, "Upload Successful")
            else:
                self.finished.emit(False, f"Server Error: {response.status_code}")
                
        except Exception as e:
            self.finished.emit(False, str(e))

class UploaderWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        layout = QVBoxLayout()
        
        group = QGroupBox("Upload to Fleet Server")
        form = QVBoxLayout()
        
        # Server URL
        url_layout = QHBoxLayout()
        self.url_input = QLineEdit("http://localhost:5000")
        url_layout.addWidget(QLabel("Server URL:"))
        url_layout.addWidget(self.url_input)
        form.addLayout(url_layout)
        
        # Robot ID
        rid_layout = QHBoxLayout()
        self.rid_input = QLineEdit("AMR_001")
        rid_layout.addWidget(QLabel("Robot ID:"))
        rid_layout.addWidget(self.rid_input)
        form.addLayout(rid_layout)
        
        # File selector with browse button
        file_layout = QHBoxLayout()
        self.file_input = QLineEdit("calib_result.yaml")
        self.btn_browse = QPushButton("Browse...")
        self.btn_browse.clicked.connect(self.browse_file)
        self.btn_browse.setFixedWidth(100)
        file_layout.addWidget(QLabel("Result File:"))
        file_layout.addWidget(self.file_input)
        file_layout.addWidget(self.btn_browse)
        form.addLayout(file_layout)
        
        # Upload Button
        self.btn_upload = QPushButton("☁️ Upload Result")
        self.btn_upload.clicked.connect(self.start_upload)
        self.btn_upload.setStyleSheet("""
            QPushButton { background-color: #9C27B0; color: white; padding: 10px; }
            QPushButton:hover { background-color: #BA68C8; }
        """)
        form.addWidget(self.btn_upload)
        
        group.setLayout(form)
        layout.addWidget(group)
        self.setLayout(layout)
        
    def browse_file(self):
        """Open file dialog to select calibration result file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Calibration Result File",
            ".",  # Start in current directory
            "YAML files (*.yaml *.yml);;All files (*.*)"
        )
        if file_path:
            self.file_input.setText(file_path)
        
    def start_upload(self):
        path = self.file_input.text()
        url = self.url_input.text()
        rid = self.rid_input.text()
        
        if not os.path.exists(path):
            msg_box = QMessageBox(self)
            msg_box.setIcon(QMessageBox.Warning)
            msg_box.setWindowTitle("Error")
            msg_box.setText("Result file not found")
            msg_box.setStyleSheet("QMessageBox { background-color: #404040; color: white; }")
            msg_box.exec_()
            return
            
        # Parse score from yaml if possible, else 0
        score = 0.0
        try:
            # simple parse
            with open(path, 'r') as f:
                for line in f:
                    if "avg_point_to_plane_rmse_m" in line:
                         score = float(line.split(':')[1].strip())
                         break
        except:
            pass
            
        self.btn_upload.setEnabled(False)
        self.btn_upload.setText("Uploading...")
        
        self.worker = UploadWorker(url, path, rid, score)
        self.worker.finished.connect(self.on_finished)
        self.worker.start()
        
    def on_finished(self, success, msg):
        self.btn_upload.setEnabled(True)
        self.btn_upload.setText("☁️ Upload Result")
        
        if success:
            msg_box = QMessageBox(self)
            msg_box.setIcon(QMessageBox.Information)
            msg_box.setWindowTitle("Success")
            msg_box.setText(msg)
            msg_box.setStyleSheet("QMessageBox { background-color: #404040; color: white; }")
            msg_box.exec_()
        else:
            msg_box = QMessageBox(self)
            msg_box.setIcon(QMessageBox.Critical)
            msg_box.setWindowTitle("Error")
            msg_box.setText(msg)
            msg_box.setStyleSheet("QMessageBox { background-color: #404040; color: white; }")
            msg_box.exec_()
