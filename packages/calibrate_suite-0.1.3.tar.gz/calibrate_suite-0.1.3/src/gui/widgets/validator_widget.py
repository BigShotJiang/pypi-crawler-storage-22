from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QLineEdit, QFileDialog, QMessageBox, QGroupBox,
                             QScrollArea, QComboBox, QSpinBox, QTextEdit, QSplitter)
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import QProcess, Qt, QSize
import os
import sys
import glob

class ValidatorWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.process = None
        self.current_visualization = None
        self.initUI()

    def initUI(self):
        main_layout = QVBoxLayout()

        # ========== Configuration Section ==========
        config_group = QGroupBox("Visualization Configuration")
        config_layout = QVBoxLayout()
        
        # Data Root Directory
        data_root_layout = QHBoxLayout()
        self.data_root_input = QLineEdit()
        cwd = os.getcwd()
        default_root = os.path.join(cwd, "calib_data/new_captures")
        self.data_root_input.setText(default_root)
        self.data_root_input.setPlaceholderText("Path to calibration data (e.g., calib_data/new_captures)")
        
        btn_browse = QPushButton("Browse...")
        btn_browse.setMaximumWidth(100)
        btn_browse.clicked.connect(self.browse_data_root)
        
        data_root_layout.addWidget(QLabel("Data Root:"))
        data_root_layout.addWidget(self.data_root_input)
        data_root_layout.addWidget(btn_browse)
        config_layout.addLayout(data_root_layout)
        
        config_group.setLayout(config_layout)
        main_layout.addWidget(config_group)
        
        # ========== Generate Visualization Button ==========
        gen_layout = QHBoxLayout()
        self.btn_generate = QPushButton("Generate Alignment Visualization")
        self.btn_generate.setStyleSheet("""
            QPushButton { background-color: #FFA726; color: white; padding: 10px; font-weight: bold; border-radius: 4px; }
            QPushButton:hover { background-color: #FB8C00; }
            QPushButton:disabled { background-color: #BDBDBD; }
        """)
        self.btn_generate.clicked.connect(self.generate_visualization)
        gen_layout.addWidget(self.btn_generate)
        gen_layout.addStretch()
        main_layout.addLayout(gen_layout)
        
        # ========== Split Layout (Log on Left, Visualization on Right) ==========
        splitter = QSplitter(Qt.Horizontal)
        
        # LEFT SIDE: Log Output
        log_group = QGroupBox("Log Output")
        log_layout = QVBoxLayout()
        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet("font-family: Monospace; font-size: 9pt;")
        log_layout.addWidget(self.log_area)
        log_group.setLayout(log_layout)
        
        # RIGHT SIDE: Visualization
        viz_group = QGroupBox("Visualization")
        viz_layout = QVBoxLayout()
        
        # Pose Selector
        pose_select_layout = QHBoxLayout()
        pose_label = QLabel("Select Pose:")
        pose_label.setStyleSheet("color: #E0E0E0;")
        pose_select_layout.addWidget(pose_label)
        self.combo_pose = QComboBox()
        self.combo_pose.setStyleSheet("""
            QComboBox { 
                background-color: #3C3C3C; 
                color: #E0E0E0; 
                border: 1px solid #424242;
                padding: 5px;
                border-radius: 4px;
            }
            QComboBox::drop-down { border: none; }
            QComboBox::down-arrow { color: #E0E0E0; }
            QComboBox QAbstractItemView {
                background-color: #3C3C3C;
                color: #E0E0E0;
                selection-background-color: #FFA726;
            }
        """)
        self.combo_pose.currentIndexChanged.connect(self.on_pose_selected)
        pose_select_layout.addWidget(self.combo_pose)
        pose_select_layout.addStretch()
        viz_layout.addLayout(pose_select_layout)
        
        # Visualization Display Area
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setMinimumHeight(400)
        self.image_label.setStyleSheet("border: 1px solid #424242; background-color: #2C2C2C;")
        
        scroll_area = QScrollArea()
        scroll_area.setWidget(self.image_label)
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("background-color: #2C2C2C;")
        viz_layout.addWidget(scroll_area)
        
        # Statistics Display
        stats_layout = QHBoxLayout()
        self.stats_label = QLabel("No visualization loaded")
        self.stats_label.setStyleSheet("font-family: Monospace; font-size: 8pt; background-color: #2C2C2C; color: #E0E0E0; padding: 8px; border-radius: 4px; max-height: 80px;")
        self.stats_label.setWordWrap(True)
        stats_layout.addWidget(self.stats_label)
        viz_layout.addLayout(stats_layout)
        
        viz_group.setLayout(viz_layout)
        viz_group.setStyleSheet("background-color: #2C2C2C; color: #E0E0E0;")
        
        # Add both to splitter
        splitter.addWidget(log_group)
        splitter.addWidget(viz_group)
        splitter.setSizes([500, 500])  # Equal split
        splitter.setCollapsible(0, False)
        splitter.setCollapsible(1, False)
        splitter.setStyleSheet("background-color: #2C2C2C;")
        
        main_layout.addWidget(splitter, 1)  # Give splitter most of the space
        
        # ========== Action Buttons ==========
        action_layout = QHBoxLayout()
        
        btn_open_folder = QPushButton("Open Visualization Folder")
        btn_open_folder.clicked.connect(self.open_viz_folder)
        
        btn_refresh = QPushButton("Refresh Pose List")
        btn_refresh.clicked.connect(self.refresh_pose_list)
        
        btn_clear_log = QPushButton("Clear Log")
        btn_clear_log.setMaximumWidth(100)
        btn_clear_log.clicked.connect(self.log_area.clear)
        
        action_layout.addWidget(btn_open_folder)
        action_layout.addWidget(btn_refresh)
        action_layout.addStretch()
        action_layout.addWidget(btn_clear_log)
        main_layout.addLayout(action_layout)
        
        self.setLayout(main_layout)

    def browse_data_root(self):
        """Open file browser to select data root directory"""
        folder = QFileDialog.getExistingDirectory(self, "Select Data Root Directory")
        if folder:
            self.data_root_input.setText(folder)
            self.refresh_pose_list()

    def refresh_pose_list(self):
        """Refresh the list of available poses"""
        data_root = self.data_root_input.text()
        
        if not os.path.exists(data_root):
            self.log_area.append(f"⚠️  Data root not found: {data_root}")
            return
        
        # Find all pose directories
        pose_dirs = sorted(glob.glob(os.path.join(data_root, "pose_*")))
        
        self.combo_pose.blockSignals(True)
        self.combo_pose.clear()
        
        for pose_dir in pose_dirs:
            pose_name = os.path.basename(pose_dir)
            self.combo_pose.addItem(pose_name)
        
        self.combo_pose.blockSignals(False)
        
        if pose_dirs:
            self.log_area.append(f"✅ Found {len(pose_dirs)} poses")
            self.combo_pose.setCurrentIndex(0)
        else:
            self.log_area.append(f"⚠️  No pose directories found in {data_root}")

    def generate_visualization(self):
        """Generate alignment visualization using 2d_3d_overlay.py"""
        data_root = self.data_root_input.text()
        
        if not data_root or not os.path.exists(data_root):
            QMessageBox.warning(self, "Error", f"Invalid data root: {data_root}")
            return
        
        self.btn_generate.setEnabled(False)
        self.log_area.clear()
        self.log_area.append(f"🚀 Generating visualization for: {data_root}")
        self.log_area.append(f"This may take a minute...\n")
        
        self.process = QProcess()
        self.process.readyReadStandardOutput.connect(self.handle_stdout)
        self.process.readyReadStandardError.connect(self.handle_stderr)
        self.process.finished.connect(self.on_visualization_finished)
        
        # Get 2d_3d_overlay.py path
        script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../2d_3d_overlay.py"))
        
        if not os.path.exists(script_path):
            self.log_area.append(f"❌ Script not found: {script_path}")
            self.btn_generate.setEnabled(True)
            return
        
        cmd = sys.executable
        args = [script_path, "--data_root", data_root]
        
        self.process.start(cmd, args)

    def on_pose_selected(self, index):
        """Load and display the selected pose's visualization"""
        data_root = self.data_root_input.text()
        pose_name = self.combo_pose.currentText()
        
        if not pose_name:
            return
        
        viz_path = os.path.join(data_root, "alignment_viz", f"{pose_name}_viz.jpg")
        
        if os.path.exists(viz_path):
            self.display_visualization(viz_path, pose_name)
        else:
            self.image_label.setText(f"Visualization not found for {pose_name}\nRun 'Generate Alignment Visualization' first")
            self.stats_label.setText("No visualization loaded")

    def display_visualization(self, image_path, pose_name):
        """Display an image in the visualization area"""
        pixmap = QPixmap(image_path)
        
        if pixmap.isNull():
            self.image_label.setText(f"Failed to load image: {image_path}")
            return
        
        # Scale to fit in view while maintaining aspect ratio
        scaled_pixmap = pixmap.scaledToWidth(1400, Qt.SmoothTransformation)
        self.image_label.setPixmap(scaled_pixmap)
        
        # Update statistics
        self.stats_label.setText(
            f"Pose: {pose_name}\n"
            f"Image: {image_path}\n"
            f"Size: {pixmap.width()}x{pixmap.height()}px\n"
            f"\nVisualization shows:\n"
            f"🟢 Camera corners (green circles)\n"
            f"🔴 LiDAR corners (red crosses)\n"
            f"🟡 Error circles (size = error magnitude)\n"
            f"Red line: Centroid offset between sensors"
        )

    def handle_stdout(self):
        """Handle stdout from visualization process"""
        data = self.process.readAllStandardOutput()
        text = data.data().decode()
        self.log_area.append(text)

    def handle_stderr(self):
        """Handle stderr from visualization process"""
        data = self.process.readAllStandardError()
        text = data.data().decode()
        self.log_area.append(f"<span style='color:red'>{text}</span>")

    def on_visualization_finished(self):
        """Handle visualization generation completion"""
        exit_code = self.process.exitCode()
        
        if exit_code == 0:
            self.log_area.append(f"\n✅ Visualization generated successfully!")
            self.refresh_pose_list()
        else:
            self.log_area.append(f"\n❌ Visualization failed with exit code {exit_code}")
        
        self.btn_generate.setEnabled(True)

    def open_viz_folder(self):
        """Open visualization folder in file explorer"""
        data_root = self.data_root_input.text()
        viz_folder = os.path.join(data_root, "alignment_viz")
        
        if not os.path.exists(viz_folder):
            QMessageBox.warning(self, "Not Found", f"Visualization folder not found:\n{viz_folder}")
            return
        
        # Open folder based on OS
        if sys.platform == "win32":
            os.startfile(viz_folder)
        elif sys.platform == "darwin":  # macOS
            os.system(f"open '{viz_folder}'")
        else:  # Linux
            os.system(f"xdg-open '{viz_folder}'")


class ThreeDValidatorWidget(QWidget):
    """3D-3D Calibration Validation Widget - Point Cloud Overlay Visualization"""
    
    def __init__(self):
        super().__init__()
        self.process = None
        self.current_visualization = None
        self.initUI()

    def initUI(self):
        main_layout = QVBoxLayout()

        # ========== Configuration Section ==========
        config_group = QGroupBox("3D-3D Validation Configuration")
        config_layout = QVBoxLayout()
        
        # Data Root Directory
        data_root_layout = QHBoxLayout()
        self.data_root_input = QLineEdit()
        cwd = os.getcwd()
        default_root = os.path.join(cwd, "calib_data/cb_data")
        self.data_root_input.setText(default_root)
        self.data_root_input.setPlaceholderText("Path to calibration data (e.g., calib_data/cb_data)")
        
        btn_browse = QPushButton("Browse...")
        btn_browse.setMaximumWidth(100)
        btn_browse.clicked.connect(self.browse_data_root)
        
        data_root_layout.addWidget(QLabel("Data Root:"))
        data_root_layout.addWidget(self.data_root_input)
        data_root_layout.addWidget(btn_browse)
        config_layout.addLayout(data_root_layout)
        
        # Calibration File
        calib_layout = QHBoxLayout()
        self.calib_input = QLineEdit()
        self.calib_input.setText("final_extrinsic.yaml")
        self.calib_input.setPlaceholderText("Calibration YAML file")
        
        btn_calib_browse = QPushButton("Browse...")
        btn_calib_browse.setMaximumWidth(100)
        btn_calib_browse.clicked.connect(self.browse_calib_file)
        
        calib_layout.addWidget(QLabel("Calibration File:"))
        calib_layout.addWidget(self.calib_input)
        calib_layout.addWidget(btn_calib_browse)
        config_layout.addLayout(calib_layout)
        
        config_group.setLayout(config_layout)
        main_layout.addWidget(config_group)
        
        # ========== Generate Visualization Button ==========
        gen_layout = QHBoxLayout()
        self.btn_generate = QPushButton("Generate 3D Overlay Visualization")
        self.btn_generate.setStyleSheet("""
            QPushButton { background-color: #2196F3; color: white; padding: 10px; font-weight: bold; border-radius: 4px; }
            QPushButton:hover { background-color: #1976D2; }
            QPushButton:disabled { background-color: #BDBDBD; }
        """)
        self.btn_generate.clicked.connect(self.generate_visualization)
        gen_layout.addWidget(self.btn_generate)
        gen_layout.addStretch()
        main_layout.addLayout(gen_layout)
        
        # ========== Split Layout (Log on Left, Visualization on Right) ==========
        splitter = QSplitter(Qt.Horizontal)
        
        # LEFT SIDE: Log Output
        log_group = QGroupBox("Log Output")
        log_layout = QVBoxLayout()
        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet("font-family: Monospace; font-size: 9pt;")
        log_layout.addWidget(self.log_area)
        log_group.setLayout(log_layout)
        
        # RIGHT SIDE: Visualization
        viz_group = QGroupBox("3D Point Cloud Overlay")
        viz_layout = QVBoxLayout()
        
        # Pose Selector
        pose_select_layout = QHBoxLayout()
        pose_label = QLabel("Select Pose:")
        pose_label.setStyleSheet("color: #E0E0E0;")
        pose_select_layout.addWidget(pose_label)
        self.combo_pose = QComboBox()
        self.combo_pose.setStyleSheet("""
            QComboBox { 
                background-color: #3C3C3C; 
                color: #E0E0E0; 
                border: 1px solid #424242;
                padding: 5px;
                border-radius: 4px;
            }
            QComboBox::drop-down { border: none; }
            QComboBox::down-arrow { color: #E0E0E0; }
            QComboBox QAbstractItemView {
                background-color: #3C3C3C;
                color: #E0E0E0;
                selection-background-color: #2196F3;
            }
        """)
        self.combo_pose.currentIndexChanged.connect(self.on_pose_selected)
        pose_select_layout.addWidget(self.combo_pose)
        pose_select_layout.addStretch()
        viz_layout.addLayout(pose_select_layout)
        
        # Visualization Display Area
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setMinimumHeight(400)
        self.image_label.setStyleSheet("border: 1px solid #424242; background-color: #2C2C2C;")
        
        scroll_area = QScrollArea()
        scroll_area.setWidget(self.image_label)
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("background-color: #2C2C2C;")
        viz_layout.addWidget(scroll_area)
        
        # Statistics Display
        stats_layout = QHBoxLayout()
        self.stats_label = QLabel("No visualization loaded")
        self.stats_label.setStyleSheet("font-family: Monospace; font-size: 8pt; background-color: #2C2C2C; color: #E0E0E0; padding: 8px; border-radius: 4px; max-height: 100px;")
        self.stats_label.setWordWrap(True)
        stats_layout.addWidget(self.stats_label)
        viz_layout.addLayout(stats_layout)
        
        viz_group.setLayout(viz_layout)
        viz_group.setStyleSheet("background-color: #2C2C2C; color: #E0E0E0;")
        
        # Add both to splitter
        splitter.addWidget(log_group)
        splitter.addWidget(viz_group)
        splitter.setSizes([500, 500])  # Equal split
        splitter.setCollapsible(0, False)
        splitter.setCollapsible(1, False)
        splitter.setStyleSheet("background-color: #2C2C2C;")
        
        main_layout.addWidget(splitter, 1)  # Give splitter most of the space
        
        # ========== Action Buttons ==========
        action_layout = QHBoxLayout()
        
        btn_open_folder = QPushButton("Open Visualization Folder")
        btn_open_folder.clicked.connect(self.open_viz_folder)
        
        btn_refresh = QPushButton("Refresh Pose List")
        btn_refresh.clicked.connect(self.refresh_pose_list)
        
        btn_clear_log = QPushButton("Clear Log")
        btn_clear_log.setMaximumWidth(100)
        btn_clear_log.clicked.connect(self.log_area.clear)
        
        action_layout.addWidget(btn_open_folder)
        action_layout.addWidget(btn_refresh)
        action_layout.addStretch()
        action_layout.addWidget(btn_clear_log)
        main_layout.addLayout(action_layout)
        
        self.setLayout(main_layout)

    def browse_data_root(self):
        """Open file browser to select data root directory"""
        folder = QFileDialog.getExistingDirectory(self, "Select Data Root Directory")
        if folder:
            self.data_root_input.setText(folder)
            self.refresh_pose_list()

    def browse_calib_file(self):
        """Open file browser to select calibration file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Calibration File", "", "YAML Files (*.yaml *.yml);;All Files (*)"
        )
        if file_path:
            self.calib_input.setText(file_path)

    def refresh_pose_list(self):
        """Refresh the list of available poses"""
        data_root = self.data_root_input.text()
        
        if not os.path.exists(data_root):
            self.log_area.append(f"⚠️  Data root not found: {data_root}")
            return
        
        # Find all pose directories
        pose_dirs = sorted(glob.glob(os.path.join(data_root, "pose_*")))
        
        self.combo_pose.blockSignals(True)
        self.combo_pose.clear()
        
        for pose_dir in pose_dirs:
            pose_name = os.path.basename(pose_dir)
            self.combo_pose.addItem(pose_name)
        
        self.combo_pose.blockSignals(False)
        
        if pose_dirs:
            self.log_area.append(f"✅ Found {len(pose_dirs)} poses")
            self.combo_pose.setCurrentIndex(0)
        else:
            self.log_area.append(f"⚠️  No pose directories found in {data_root}")

    def generate_visualization(self):
        """Generate 3D overlay visualization using 3d_3d_overlay.py"""
        data_root = self.data_root_input.text()
        calib_file = self.calib_input.text()
        
        if not data_root or not os.path.exists(data_root):
            QMessageBox.warning(self, "Error", f"Invalid data root: {data_root}")
            return
        
        self.btn_generate.setEnabled(False)
        self.log_area.clear()
        self.log_area.append(f"🚀 Generating 3D overlays for: {data_root}")
        self.log_area.append(f"Using calibration: {calib_file}")
        self.log_area.append(f"This may take a few minutes...\n")
        
        self.process = QProcess()
        self.process.readyReadStandardOutput.connect(self.handle_stdout)
        self.process.readyReadStandardError.connect(self.handle_stderr)
        self.process.finished.connect(self.on_visualization_finished)
        
        # Get 3d_3d_overlay.py path
        script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../3d_3d_overlay.py"))
        
        if not os.path.exists(script_path):
            self.log_area.append(f"❌ Script not found: {script_path}")
            self.btn_generate.setEnabled(True)
            return
        
        cmd = sys.executable
        args = [script_path, "--data_root", data_root, "--calib", calib_file]
        
        self.process.start(cmd, args)

    def on_pose_selected(self, index):
        """Load and display the selected pose's visualization"""
        data_root = self.data_root_input.text()
        pose_name = self.combo_pose.currentText()
        
        if not pose_name:
            return
        
        viz_path = os.path.join(data_root, pose_name, "3d_overlay_viz.png")
        
        if os.path.exists(viz_path):
            self.display_visualization(viz_path, pose_name)
        else:
            self.image_label.setText(f"Visualization not found for {pose_name}\nRun 'Generate 3D Overlay Visualization' first")
            self.stats_label.setText("No visualization loaded")

    def display_visualization(self, image_path, pose_name):
        """Display an image in the visualization area"""
        pixmap = QPixmap(image_path)
        
        if pixmap.isNull():
            self.image_label.setText(f"Failed to load image: {image_path}")
            return
        
        # Scale to fit in view while maintaining aspect ratio
        scaled_pixmap = pixmap.scaledToWidth(1400, Qt.SmoothTransformation)
        self.image_label.setPixmap(scaled_pixmap)
        
        # Update statistics
        self.stats_label.setText(
            f"Pose: {pose_name}\n"
            f"Image: {image_path}\n"
            f"Size: {pixmap.width()}x{pixmap.height()}px\n"
            f"\nVisualization shows:\n"
            f"🟢 Green Points: LiDAR board points (projected to camera frame)\n"
            f"🔴 Red Box: Camera/depth board points (ground truth)\n"
            f"🟡 Green Box: LiDAR board bounding box\n"
            f"📏 Error: Centroid offset in pixels | IoU: Intersection over Union of bounding boxes"
        )

    def handle_stdout(self):
        """Handle stdout from visualization process"""
        data = self.process.readAllStandardOutput()
        text = data.data().decode()
        self.log_area.append(text)

    def handle_stderr(self):
        """Handle stderr from visualization process"""
        data = self.process.readAllStandardError()
        text = data.data().decode()
        self.log_area.append(f"<span style='color:red'>{text}</span>")

    def on_visualization_finished(self):
        """Handle visualization generation completion"""
        exit_code = self.process.exitCode()
        
        if exit_code == 0:
            self.log_area.append(f"\n✅ 3D overlays generated successfully!")
            self.refresh_pose_list()
        else:
            self.log_area.append(f"\n❌ Visualization failed with exit code {exit_code}")
        
        self.btn_generate.setEnabled(True)

    def open_viz_folder(self):
        """Open visualization folder in file explorer"""
        data_root = self.data_root_input.text()
        
        if not os.path.exists(data_root):
            QMessageBox.warning(self, "Not Found", f"Data root not found:\n{data_root}")
            return
        
        # Open folder based on OS
        if sys.platform == "win32":
            os.startfile(data_root)
        elif sys.platform == "darwin":  # macOS
            os.system(f"open '{data_root}'")
        else:  # Linux
            os.system(f"xdg-open '{data_root}'")

