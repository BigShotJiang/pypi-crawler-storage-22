from PyQt5.QtWidgets import QMainWindow, QStackedWidget, QLabel, QWidget, QVBoxLayout, QPushButton, QHBoxLayout
from PyQt5.QtCore import Qt
from .main_window_ui import setup_styles

# Import our new widgets
try:
    from ..widgets.home_widget import HomeWidget
    from ..widgets.single_lidar_widget import SingleLidarWidget
    from ..widgets.three_d_calib_widget import ThreeDThreeDWidget
    from ..widgets.two_d_calib_widget import TwoDThreeDWidget
except ImportError:
    from gui.widgets.home_widget import HomeWidget
    from gui.widgets.single_lidar_widget import SingleLidarWidget
    from gui.widgets.three_d_calib_widget import ThreeDThreeDWidget
    from gui.widgets.two_d_calib_widget import TwoDThreeDWidget

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VIRYA Calibration Suite")
        self.resize(1200, 800)
        
        setup_styles(self)

        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)

        self.init_ui()

    def init_ui(self):
        # 0: Home
        self.home_widget = HomeWidget()
        self.home_widget.navigate.connect(self.handle_navigation)
        self.stack.addWidget(self.home_widget)

        # 1: Single LiDAR
        self.single_lidar_widget = SingleLidarWidget()
        self.single_lidar_widget.go_home.connect(self.go_home)
        self.stack.addWidget(self.single_lidar_widget)

        # 2: 3D-3D
        self.three_d_widget = ThreeDThreeDWidget()
        self.three_d_widget.go_home.connect(self.go_home)
        self.stack.addWidget(self.three_d_widget)

        # 3: 2D-3D
        self.two_d_widget = TwoDThreeDWidget()
        self.two_d_widget.go_home.connect(self.go_home)
        self.stack.addWidget(self.two_d_widget)

    def handle_navigation(self, index):
        # index matches the stack index we assume (1, 2, 3)
        self.stack.setCurrentIndex(index)

    def go_home(self):
        self.stack.setCurrentIndex(0)
