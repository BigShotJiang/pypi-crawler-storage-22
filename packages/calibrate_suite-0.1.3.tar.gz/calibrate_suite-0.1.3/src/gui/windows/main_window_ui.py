def setup_styles(app):
    """Apply global stylesheets to the application/window."""
    style = """
    QMainWindow {
        background-color: #2b2b2b;
    }
    QWidget {
        color: #e0e0e0;
        font-family: "Ubuntu", "Liberation Sans", "DejaVu Sans", sans-serif;
        font-size: 14px;
    }
    QTabWidget::pane {
        border: 1px solid #444;
        background: #333;
    }
    QTabBar::tab {
        background: #2b2b2b;
        color: #aaa;
        padding: 10px 20px;
        border: 1px solid #444;
        border-bottom: none;
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
    }
    QTabBar::tab:selected {
        background: #444;
        color: white;
        font-weight: bold;
    }
    QPushButton {
        background-color: #3CB371;
        border: 1px solid #666;
        color: white;
        padding: 8px 16px;
        border-radius: 4px;
    }
    QPushButton:hover {
        background-color: #666;
    }
    QLineEdit {
        background-color: #444;
        border: 1px solid #555;
        color: white;
        padding: 6px;
        border-radius: 3px;
    }
    QGroupBox {
        border: 1px solid #555;
        border-radius: 5px;
        margin-top: 10px;
        font-weight: bold;
    }
    QGroupBox::title {
        subcontrol-origin: margin;
        subcontrol-position: top left;
        padding: 0 5px;
    }
    QTextEdit {
        background-color: #1e1e1e;
        color: #00ff00;
        font-family: "Ubuntu Mono", "Liberation Mono", "DejaVu Sans Mono", monospace;
        border: 1px solid #444;
    }
    """
    app.setStyleSheet(style)
