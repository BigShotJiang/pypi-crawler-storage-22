"""Shared calibration utilities."""

import os
import yaml
import numpy as np


def load_camera_intrinsics(data_root, intrinsics_file=None):
    """
    Load camera intrinsics from camera_intrinsics.yaml.
    """
    if intrinsics_file:
        intrinsics_path = intrinsics_file
    else:
        intrinsics_path = os.path.join(data_root, "camera_intrinsics.yaml")
    
    with open(intrinsics_path) as f:
        calib_data = yaml.safe_load(f)
    
    K = np.array(calib_data['camera_matrix'], dtype=np.float64)
    D = np.array(calib_data['dist_coeffs'], dtype=np.float64).ravel()
    
    return K, D
