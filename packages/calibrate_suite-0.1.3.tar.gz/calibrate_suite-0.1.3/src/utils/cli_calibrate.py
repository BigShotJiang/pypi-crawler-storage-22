#!/usr/bin/env python3
"""
Entry point for calibrate-suite GUI application.

Usage: calibrate-suite [options]
"""

import sys
import argparse


def main():
    """Launch the calibrate-suite GUI application."""
    parser = argparse.ArgumentParser(
        prog="calibrate-suite",
        description="Calibrate-Suite: Multi-Modal Sensor Calibration GUI",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="calibrate-suite 0.1.0",
    )
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run in headless mode (no GUI)",
    )

    args = parser.parse_args()

    if args.headless:
        print(
            "Headless mode not yet supported. Please use GUI or REST API (fleet-server)."
        )
        sys.exit(1)

    # Import here to avoid GUI dependencies when not needed
    try:
        from gui.main import main as gui_main

        gui_main()
    except ImportError as e:
        print(
            f"Error: GUI dependencies not installed. Please install with:\n"
            f"  pip install calibrate-suite[gui]\n"
            f"Or for full features:\n"
            f"  pip install calibrate-suite[full]"
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
