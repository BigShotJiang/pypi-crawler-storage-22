#!/usr/bin/env python3
"""
Entry point for calibrate-suite fleet server (REST API).

Usage: fleet-server [--host HOST] [--port PORT] [--debug]
"""

import sys
import argparse


def main():
    """Launch the fleet server REST API."""
    parser = argparse.ArgumentParser(
        prog="fleet-server",
        description="Calibrate-Suite Fleet Server: REST API for calibration management",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Server host address (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=5000,
        help="Server port (default: 5000)",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug mode",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="fleet-server (calibrate-suite 0.1.0)",
    )

    args = parser.parse_args()

    # Import here to avoid Flask dependencies when not needed
    try:
        from fleet_server.app import app

        print(f"Starting Fleet Server on {args.host}:{args.port}")
        print(f"Dashboard: http://{args.host}:{args.port}")
        print(f"API Docs: http://{args.host}:{args.port}/api/docs")
        print("Press Ctrl+C to stop server\n")

        app.run(host=args.host, port=args.port, debug=args.debug)

    except ImportError as e:
        print(
            f"Error: Fleet server dependencies not installed. Please install with:\n"
            f"  pip install calibrate-suite\n"
            f"If Flask is missing, try:\n"
            f"  pip install flask requests"
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
