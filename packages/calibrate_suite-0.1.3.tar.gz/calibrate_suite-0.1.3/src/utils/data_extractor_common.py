"""Shared data extractor utilities"""

import sys
import struct
import numpy as np
import open3d as o3d

def flush_print(msg):
    """Print with immediate stdout flush."""
    print(msg)
    sys.stdout.flush()


def save_pc2_to_pcd(msg, filename):
    """
    Convert ROS PointCloud2 message to PCD file.
    """
    try:
        field_names = [f.name for f in msg.fields]
        offsets = {f.name: f.offset for f in msg.fields}
        
        if 'x' not in offsets:
            flush_print("[WARN] PointCloud has no X field.")
            return
        
        n_points = msg.width * msg.height
        if n_points == 0:
            flush_print(f"[WARN] Empty point cloud (0 points) in {filename}")
            pc = o3d.geometry.PointCloud()
            o3d.io.write_point_cloud(filename, pc)
            return
        
        step = msg.point_step
        data = msg.data
        
        # Extract XYZ points
        off_x = offsets.get('x', 0)
        off_y = offsets.get('y', 4)
        off_z = offsets.get('z', 8)
        
        pts = np.zeros((n_points, 3), dtype=np.float32)
        
        for i in range(n_points):
            base = i * step
            try:
                pts[i, 0] = struct.unpack_from('f', data, base + off_x)[0]
                pts[i, 1] = struct.unpack_from('f', data, base + off_y)[0]
                pts[i, 2] = struct.unpack_from('f', data, base + off_z)[0]
            except struct.error as e:
                pts[i] = [0, 0, 0]
        
        # Filter out NaN and Inf points
        valid_mask = np.isfinite(pts).all(axis=1)
        valid_pts = pts[valid_mask]
        
        pc = o3d.geometry.PointCloud()
        if len(valid_pts) > 0:
            pc.points = o3d.utility.Vector3dVector(valid_pts.astype(np.float64))
        
        o3d.io.write_point_cloud(filename, pc)
        
    except Exception as e:
        flush_print(f"[ERR] Failed to save PCD {filename}: {e}")


def depth_to_camera_cloud(depth: np.ndarray, K: np.ndarray):
    """
    Convert depth image to camera point cloud using intrinsics.
    """
    h, w = depth.shape
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]
    
    u, v = np.meshgrid(np.arange(w), np.arange(h))
    z = depth.flatten()
    valid = np.isfinite(z) & (z > 0)
    
    if not np.any(valid):
        return o3d.geometry.PointCloud()
    
    x = (u.flatten()[valid] - cx) * z[valid] / fx
    y = (v.flatten()[valid] - cy) * z[valid] / fy
    pts = np.vstack((x, y, z[valid])).T
    
    pc = o3d.geometry.PointCloud()
    pc.points = o3d.utility.Vector3dVector(pts.astype(np.float64))
    return pc
