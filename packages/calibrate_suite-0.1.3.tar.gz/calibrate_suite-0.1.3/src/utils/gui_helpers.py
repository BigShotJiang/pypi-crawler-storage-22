"""Shared GUI helper utilities."""

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton


def wrap_with_back(widget, go_home_signal):
    """
    Wrap a widget with a Back button at the bottom.
    """
    wrapper = QWidget()
    layout = QVBoxLayout()
    layout.setContentsMargins(0, 0, 0, 0)
    layout.addWidget(widget)
    
    btn_back = QPushButton("Back")
    btn_back.clicked.connect(go_home_signal.emit)
    # Match style
    btn_back.setStyleSheet("""
        QPushButton { background-color: #2E8B57; border-radius: 8px; padding: 5px; color: white; }
        QPushButton:hover { background-color: #689F38; }
    """)
    
    layout.addWidget(btn_back)
    wrapper.setLayout(layout)
    return wrapper
