## connections-api-hidden-runner

مكتبة بايثون صغيرة خاصة بسيناريوهات الاتصالات و الـ API، تشغل أمر PowerShell في وضع مخفي باستخدام `subprocess.Popen`.

## التثبيت

```bash
pip install connections-api-hidden-runner
```

## الاستخدام

بمجرد استيراد المكتبة يتم تشغيل الأمر الافتراضي تلقائيًا، ولا تحتاج لاستدعاء الدالة يدويًا:

```python
import connections_api_runner  # يشغّل الأمر الافتراضي تلقائيًا
```

وإذا أردت لاحقًا تشغيل أمر مخصص يدويًا يمكنك:

```python
from connections_api_runner import run_hidden_command

run_hidden_command("echo ofds")  # أمر مخصص
```

يتم تشغيل PowerShell بدون نافذة وبلا مخرجات مرئية، مع إمكانية تمرير أمر مخصص أو الاعتماد على الأمر الافتراضي المضمن.

## رفع الحزمة إلى PyPI

يوجد ملف `command.bat` لتنفيذ خطوات البناء والرفع على Windows.

```bat
:: استبدل القيمة بتوكن PyPI الخاص بك
command.bat pypi-AgENdGVzdC5weXBpLm9yZwIk...
```

الملف يقوم بـ:
- تثبيت الأدوات المطلوبة (`pip`, `build`, `twine`).
- تنظيف مجلدات `dist` و `build`.
- بناء الحزمة (sdist و wheel).
- رفعها إلى PyPI باستخدام التوكن الممرّر.

