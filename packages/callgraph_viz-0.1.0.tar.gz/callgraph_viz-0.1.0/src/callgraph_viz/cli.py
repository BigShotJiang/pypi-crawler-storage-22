"""
Command-line interface for callgraph-viz.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List, Optional

from .parser import CallGraphParser
from .visualizer import CallGraphVisualizer, VisualizationConfig


def main(args: Optional[List[str]] = None) -> int:
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(
        prog='callgraph-viz',
        description='Generate interactive call graph visualizations from source code.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  # Visualize a single Python file
  callgraph-viz mycode.py -o graph.html

  # Visualize a directory
  callgraph-viz src/ -o graph.html

  # Visualize multiple files
  callgraph-viz file1.py file2.py file3.js -o graph.html

  # Include built-in function calls
  callgraph-viz mycode.py --include-builtins -o graph.html

  # Custom title and settings
  callgraph-viz src/ -o graph.html --title "My Project" --no-labels
'''
    )
    
    parser.add_argument(
        'paths',
        nargs='+',
        help='Source files or directories to analyze'
    )
    
    parser.add_argument(
        '-o', '--output',
        required=True,
        help='Output HTML file path'
    )
    
    parser.add_argument(
        '-r', '--recursive',
        action='store_true',
        default=True,
        help='Recursively scan directories (default: True)'
    )
    
    parser.add_argument(
        '--no-recursive',
        action='store_false',
        dest='recursive',
        help='Do not recursively scan directories'
    )
    
    parser.add_argument(
        '--include-builtins',
        action='store_true',
        default=False,
        help='Include calls to built-in functions'
    )
    
    parser.add_argument(
        '--exclude',
        nargs='*',
        default=['*test*', '*__pycache__*', '*node_modules*', '*.min.js'],
        help='Glob patterns for files/directories to exclude'
    )
    
    parser.add_argument(
        '--languages',
        nargs='*',
        default=['python', 'javascript'],
        help='Languages to include (python, javascript)'
    )
    
    parser.add_argument(
        '--title',
        default=None,
        help='Title for the visualization'
    )
    
    parser.add_argument(
        '--no-labels',
        action='store_true',
        default=False,
        help='Hide node labels'
    )
    
    parser.add_argument(
        '--color-by-type',
        action='store_true',
        default=False,
        help='Color nodes by type instead of file'
    )
    
    parser.add_argument(
        '--link-distance',
        type=int,
        default=100,
        help='Distance between linked nodes (default: 100)'
    )
    
    parser.add_argument(
        '--charge',
        type=int,
        default=-300,
        help='Node repulsion strength (default: -300)'
    )
    
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        default=False,
        help='Verbose output'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='%(prog)s 0.1.0'
    )
    
    parsed = parser.parse_args(args)
    
    # Create parser
    code_parser = CallGraphParser(
        include_builtins=parsed.include_builtins,
    )
    
    # Parse all paths
    from .graph import CallGraph
    combined_graph = CallGraph()
    
    for path_str in parsed.paths:
        path = Path(path_str)
        
        if not path.exists():
            print(f"Error: Path not found: {path}", file=sys.stderr)
            return 1
        
        if parsed.verbose:
            print(f"Parsing: {path}")
        
        try:
            if path.is_file():
                graph = code_parser.parse_file(path)
            else:
                graph = code_parser.parse_directory(
                    path,
                    recursive=parsed.recursive,
                    exclude_patterns=parsed.exclude,
                    languages=parsed.languages,
                )
            combined_graph.merge(graph)
        except Exception as e:
            print(f"Error parsing {path}: {e}", file=sys.stderr)
            if parsed.verbose:
                import traceback
                traceback.print_exc()
            return 1
    
    if len(combined_graph) == 0:
        print("Warning: No functions found in the provided paths.", file=sys.stderr)
        return 1
    
    if parsed.verbose:
        print(f"Found {len(combined_graph.nodes)} functions and {len(combined_graph.edges)} calls")
    
    # Create visualizer config
    config = VisualizationConfig(
        title=parsed.title or f"Call Graph: {', '.join(parsed.paths)}",
        show_labels=not parsed.no_labels,
        color_by_file=not parsed.color_by_type,
        color_by_type=parsed.color_by_type,
        link_distance=parsed.link_distance,
        charge_strength=parsed.charge,
    )
    
    # Generate visualization
    visualizer = CallGraphVisualizer(config)
    
    try:
        visualizer.generate_html(combined_graph, parsed.output)
        print(f"Generated: {parsed.output}")
        
        if parsed.verbose:
            stats = combined_graph.to_dict()['stats']
            print(f"  Nodes: {stats['total_nodes']}")
            print(f"  Edges: {stats['total_edges']}")
            print(f"  Entry points: {stats['entry_points']}")
            print(f"  Leaf functions: {stats['leaf_nodes']}")
            print(f"  Recursive calls: {stats['recursive_calls']}")
    except Exception as e:
        print(f"Error generating visualization: {e}", file=sys.stderr)
        if parsed.verbose:
            import traceback
            traceback.print_exc()
        return 1
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
