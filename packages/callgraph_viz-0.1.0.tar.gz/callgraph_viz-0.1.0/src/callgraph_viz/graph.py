"""
Graph data structures for call graph representation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Set, Optional
from enum import Enum


class NodeType(Enum):
    """Type of function/callable node."""
    FUNCTION = "function"
    METHOD = "method"
    CLASS = "class"
    MODULE = "module"
    BUILTIN = "builtin"
    EXTERNAL = "external"


@dataclass
class FunctionNode:
    """Represents a function or method in the call graph."""
    id: str  # Unique identifier (e.g., "module.Class.method")
    name: str  # Short name (e.g., "method")
    qualified_name: str  # Full qualified name
    file_path: Optional[str] = None
    line_number: Optional[int] = None
    end_line: Optional[int] = None
    node_type: NodeType = NodeType.FUNCTION
    class_name: Optional[str] = None
    module_name: Optional[str] = None
    docstring: Optional[str] = None
    is_async: bool = False
    is_generator: bool = False
    parameters: List[str] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "name": self.name,
            "qualified_name": self.qualified_name,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "end_line": self.end_line,
            "node_type": self.node_type.value,
            "class_name": self.class_name,
            "module_name": self.module_name,
            "docstring": self.docstring,
            "is_async": self.is_async,
            "is_generator": self.is_generator,
            "parameters": self.parameters,
        }


@dataclass
class CallEdge:
    """Represents a function call relationship."""
    caller_id: str  # ID of the calling function
    callee_id: str  # ID of the called function
    call_count: int = 1  # Number of times this call appears
    line_numbers: List[int] = field(default_factory=list)  # Lines where calls occur
    is_conditional: bool = False  # Is the call inside a conditional?
    is_loop: bool = False  # Is the call inside a loop?
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "source": self.caller_id,
            "target": self.callee_id,
            "call_count": self.call_count,
            "line_numbers": self.line_numbers,
            "is_conditional": self.is_conditional,
            "is_loop": self.is_loop,
        }


class CallGraph:
    """
    A directed graph representing function calls in a codebase.
    
    Nodes are functions/methods, edges are call relationships.
    """
    
    def __init__(self):
        self.nodes: Dict[str, FunctionNode] = {}
        self.edges: Dict[str, CallEdge] = {}  # Key: "caller_id->callee_id"
        self._callers: Dict[str, Set[str]] = {}  # callee_id -> set of caller_ids
        self._callees: Dict[str, Set[str]] = {}  # caller_id -> set of callee_ids
    
    def add_node(self, node: FunctionNode) -> None:
        """Add a function node to the graph."""
        self.nodes[node.id] = node
        if node.id not in self._callers:
            self._callers[node.id] = set()
        if node.id not in self._callees:
            self._callees[node.id] = set()
    
    def add_edge(
        self,
        caller_id: str,
        callee_id: str,
        line_number: Optional[int] = None,
        is_conditional: bool = False,
        is_loop: bool = False,
    ) -> None:
        """Add a call edge to the graph."""
        edge_key = f"{caller_id}->{callee_id}"
        
        if edge_key in self.edges:
            # Edge exists, increment count and add line number
            edge = self.edges[edge_key]
            edge.call_count += 1
            if line_number and line_number not in edge.line_numbers:
                edge.line_numbers.append(line_number)
            edge.is_conditional = edge.is_conditional or is_conditional
            edge.is_loop = edge.is_loop or is_loop
        else:
            # Create new edge
            line_numbers = [line_number] if line_number else []
            self.edges[edge_key] = CallEdge(
                caller_id=caller_id,
                callee_id=callee_id,
                call_count=1,
                line_numbers=line_numbers,
                is_conditional=is_conditional,
                is_loop=is_loop,
            )
        
        # Update adjacency sets
        if caller_id not in self._callees:
            self._callees[caller_id] = set()
        self._callees[caller_id].add(callee_id)
        
        if callee_id not in self._callers:
            self._callers[callee_id] = set()
        self._callers[callee_id].add(caller_id)
    
    def get_callers(self, node_id: str) -> Set[str]:
        """Get all functions that call the given function."""
        return self._callers.get(node_id, set())
    
    def get_callees(self, node_id: str) -> Set[str]:
        """Get all functions called by the given function."""
        return self._callees.get(node_id, set())
    
    def get_node(self, node_id: str) -> Optional[FunctionNode]:
        """Get a node by ID."""
        return self.nodes.get(node_id)
    
    def get_edge(self, caller_id: str, callee_id: str) -> Optional[CallEdge]:
        """Get an edge by caller and callee IDs."""
        edge_key = f"{caller_id}->{callee_id}"
        return self.edges.get(edge_key)
    
    def find_recursive_calls(self) -> List[str]:
        """Find all nodes that call themselves (direct recursion)."""
        recursive = []
        for node_id in self.nodes:
            if node_id in self._callees.get(node_id, set()):
                recursive.append(node_id)
        return recursive
    
    def find_entry_points(self) -> List[str]:
        """Find nodes with no callers (potential entry points)."""
        return [
            node_id for node_id, callers in self._callers.items()
            if not callers and node_id in self.nodes
        ]
    
    def find_leaf_nodes(self) -> List[str]:
        """Find nodes that don't call any other functions."""
        return [
            node_id for node_id, callees in self._callees.items()
            if not callees and node_id in self.nodes
        ]
    
    def get_depth(self, node_id: str, visited: Optional[Set[str]] = None) -> int:
        """Get the maximum call depth from a node."""
        if visited is None:
            visited = set()
        
        if node_id in visited:
            return 0  # Cycle detected
        
        visited.add(node_id)
        callees = self._callees.get(node_id, set())
        
        if not callees:
            return 0
        
        max_depth = 0
        for callee_id in callees:
            depth = self.get_depth(callee_id, visited.copy())
            max_depth = max(max_depth, depth + 1)
        
        return max_depth
    
    def to_dict(self) -> dict:
        """Convert the graph to a dictionary for JSON serialization."""
        return {
            "nodes": [node.to_dict() for node in self.nodes.values()],
            "edges": [edge.to_dict() for edge in self.edges.values()],
            "stats": {
                "total_nodes": len(self.nodes),
                "total_edges": len(self.edges),
                "entry_points": len(self.find_entry_points()),
                "leaf_nodes": len(self.find_leaf_nodes()),
                "recursive_calls": len(self.find_recursive_calls()),
            }
        }
    
    def merge(self, other: "CallGraph") -> None:
        """Merge another call graph into this one."""
        for node in other.nodes.values():
            if node.id not in self.nodes:
                self.add_node(node)
        
        for edge in other.edges.values():
            self.add_edge(
                edge.caller_id,
                edge.callee_id,
                edge.line_numbers[0] if edge.line_numbers else None,
                edge.is_conditional,
                edge.is_loop,
            )
            # Add remaining line numbers
            for line_num in edge.line_numbers[1:]:
                existing_edge = self.get_edge(edge.caller_id, edge.callee_id)
                if existing_edge and line_num not in existing_edge.line_numbers:
                    existing_edge.line_numbers.append(line_num)
    
    def filter_by_module(self, module_name: str) -> "CallGraph":
        """Create a new graph containing only nodes from the specified module."""
        filtered = CallGraph()
        
        for node in self.nodes.values():
            if node.module_name == module_name:
                filtered.add_node(node)
        
        for edge in self.edges.values():
            if edge.caller_id in filtered.nodes and edge.callee_id in filtered.nodes:
                filtered.add_edge(
                    edge.caller_id,
                    edge.callee_id,
                    edge.line_numbers[0] if edge.line_numbers else None,
                    edge.is_conditional,
                    edge.is_loop,
                )
        
        return filtered
    
    def __len__(self) -> int:
        return len(self.nodes)
    
    def __repr__(self) -> str:
        return f"CallGraph(nodes={len(self.nodes)}, edges={len(self.edges)})"
