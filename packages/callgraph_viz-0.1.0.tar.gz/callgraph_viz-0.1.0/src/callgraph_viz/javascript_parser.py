"""
JavaScript/TypeScript source code parser for extracting function definitions and calls.

Uses regex-based parsing for simplicity (no external dependencies).
For production use with complex JS, consider using tree-sitter or esprima.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, field

from .graph import CallGraph, FunctionNode, NodeType


@dataclass
class JSScope:
    """Tracks JavaScript parsing scope."""
    name: str
    type: NodeType
    class_name: Optional[str] = None
    parent: Optional["JSScope"] = None
    start_line: int = 0
    end_line: int = 0
    
    def get_qualified_name(self, name: str) -> str:
        """Get qualified name for a symbol."""
        parts = []
        scope = self
        while scope and scope.type != NodeType.MODULE:
            parts.append(scope.name)
            scope = scope.parent
        parts.reverse()
        parts.append(name)
        return ".".join(parts)


class JavaScriptParser:
    """
    Parser for JavaScript/TypeScript source code.
    
    Uses regex-based pattern matching to extract function definitions and calls.
    This is a lightweight approach that works for common patterns without
    requiring external dependencies like tree-sitter.
    """
    
    # Patterns for function definitions
    FUNCTION_PATTERNS = [
        # Regular function: function name(args) {
        r'function\s+(\w+)\s*\([^)]*\)\s*\{',
        # Arrow function assigned to variable: const name = (args) => {
        r'(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?\([^)]*\)\s*=>\s*\{?',
        # Arrow function assigned to variable (single arg): const name = arg => {
        r'(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(\w+)\s*=>\s*\{?',
        # Method definition in object/class: name(args) {
        r'^\s*(\w+)\s*\([^)]*\)\s*\{',
        # Async function: async function name(args) {
        r'async\s+function\s+(\w+)\s*\([^)]*\)\s*\{',
        # Class method: methodName(args) {
        r'^\s*(?:async\s+)?(\w+)\s*\([^)]*\)\s*\{',
        # Export function: export function name
        r'export\s+(?:default\s+)?(?:async\s+)?function\s+(\w+)',
        # Export const arrow: export const name = 
        r'export\s+(?:const|let)\s+(\w+)\s*=',
    ]
    
    # Patterns for class definitions
    CLASS_PATTERNS = [
        # class Name {
        r'class\s+(\w+)(?:\s+extends\s+\w+)?\s*\{',
        # export class Name {
        r'export\s+(?:default\s+)?class\s+(\w+)',
    ]
    
    # Pattern for function calls
    CALL_PATTERN = r'(\w+(?:\.\w+)*)\s*\('
    
    # Built-in functions to potentially exclude
    BUILTINS = {
        'console', 'Math', 'JSON', 'Object', 'Array', 'String', 'Number',
        'Boolean', 'Date', 'RegExp', 'Error', 'Promise', 'Map', 'Set',
        'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval',
        'parseInt', 'parseFloat', 'isNaN', 'isFinite', 'encodeURI',
        'decodeURI', 'encodeURIComponent', 'decodeURIComponent',
        'require', 'module', 'exports', 'process', 'Buffer',
        'fetch', 'alert', 'confirm', 'prompt', 'document', 'window',
    }
    
    def __init__(self, include_builtins: bool = False):
        """
        Initialize the parser.
        
        Args:
            include_builtins: Include calls to built-in functions
        """
        self.include_builtins = include_builtins
        self._compiled_patterns = [re.compile(p, re.MULTILINE) for p in self.FUNCTION_PATTERNS]
        self._class_patterns = [re.compile(p, re.MULTILINE) for p in self.CLASS_PATTERNS]
        self._call_pattern = re.compile(self.CALL_PATTERN)
    
    def parse_file(self, file_path: str | Path) -> CallGraph:
        """
        Parse a JavaScript/TypeScript file and extract its call graph.
        
        Args:
            file_path: Path to the JS/TS file
            
        Returns:
            CallGraph containing function definitions and calls
        """
        file_path = Path(file_path)
        
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()
        
        return self.parse_source(source, str(file_path))
    
    def parse_source(self, source: str, file_path: str = "<string>") -> CallGraph:
        """
        Parse JavaScript source code and extract its call graph.
        
        Args:
            source: JavaScript source code
            file_path: Optional file path for references
            
        Returns:
            CallGraph containing function definitions and calls
        """
        module_name = Path(file_path).stem if file_path != "<string>" else "module"
        graph = CallGraph()
        
        lines = source.split('\n')
        
        # First pass: find all function and class definitions
        functions: Dict[str, Tuple[int, int, Optional[str]]] = {}  # name -> (start_line, end_line, class_name)
        classes: Dict[str, Tuple[int, int]] = {}  # name -> (start_line, end_line)
        
        current_class: Optional[str] = None
        brace_depth = 0
        class_brace_start = 0
        
        for line_num, line in enumerate(lines, 1):
            # Track brace depth for scope
            brace_depth += line.count('{') - line.count('}')
            
            # Check for class definitions
            for pattern in self._class_patterns:
                match = pattern.search(line)
                if match:
                    class_name = match.group(1)
                    current_class = class_name
                    class_brace_start = brace_depth
                    
                    # Add class node
                    node_id = f"{module_name}.{class_name}"
                    class_node = FunctionNode(
                        id=node_id,
                        name=class_name,
                        qualified_name=node_id,
                        file_path=file_path,
                        line_number=line_num,
                        node_type=NodeType.CLASS,
                        module_name=module_name,
                    )
                    graph.add_node(class_node)
            
            # Check if we've exited the current class
            if current_class and brace_depth < class_brace_start:
                current_class = None
            
            # Check for function definitions
            for pattern in self._compiled_patterns:
                match = pattern.search(line)
                if match:
                    func_name = match.group(1)
                    if func_name and func_name not in ('if', 'for', 'while', 'switch', 'catch', 'with'):
                        # Determine node type and qualified name
                        if current_class:
                            node_type = NodeType.METHOD
                            qualified_name = f"{module_name}.{current_class}.{func_name}"
                        else:
                            node_type = NodeType.FUNCTION
                            qualified_name = f"{module_name}.{func_name}"
                        
                        # Check for async
                        is_async = 'async' in line[:match.start() + 20]
                        
                        functions[qualified_name] = (line_num, 0, current_class)
                        
                        # Create function node
                        func_node = FunctionNode(
                            id=qualified_name,
                            name=func_name,
                            qualified_name=qualified_name,
                            file_path=file_path,
                            line_number=line_num,
                            node_type=node_type,
                            class_name=current_class,
                            module_name=module_name,
                            is_async=is_async,
                        )
                        graph.add_node(func_node)
        
        # Second pass: find function calls within each function
        current_function: Optional[str] = None
        func_brace_depth = 0
        func_start_depth = 0
        in_conditional = False
        in_loop = False
        
        for line_num, line in enumerate(lines, 1):
            # Update brace tracking
            open_braces = line.count('{')
            close_braces = line.count('}')
            
            # Check if we're entering a function
            for func_name, (start_line, _, class_name) in functions.items():
                if start_line == line_num:
                    current_function = func_name
                    func_start_depth = func_brace_depth
            
            func_brace_depth += open_braces - close_braces
            
            # Check if we've exited the current function
            if current_function and func_brace_depth <= func_start_depth and close_braces > 0:
                current_function = None
            
            # Track conditional/loop context
            if re.search(r'\b(if|else|switch)\s*\(', line):
                in_conditional = True
            if re.search(r'\b(for|while|do)\s*[\(\{]', line):
                in_loop = True
            
            # Find function calls in this line
            if current_function:
                # Remove strings and comments to avoid false positives
                clean_line = self._remove_strings_and_comments(line)
                
                for match in self._call_pattern.finditer(clean_line):
                    call_target = match.group(1)
                    
                    # Skip built-in calls if not included
                    base_name = call_target.split('.')[0]
                    if not self.include_builtins and base_name in self.BUILTINS:
                        continue
                    
                    # Skip control flow keywords
                    if call_target in ('if', 'for', 'while', 'switch', 'catch', 'return', 'throw', 'new', 'typeof', 'instanceof'):
                        continue
                    
                    # Resolve call target
                    resolved_target = self._resolve_call_target(
                        call_target, module_name, functions, current_function
                    )
                    
                    if resolved_target:
                        graph.add_edge(
                            caller_id=current_function,
                            callee_id=resolved_target,
                            line_number=line_num,
                            is_conditional=in_conditional,
                            is_loop=in_loop,
                        )
            
            # Reset context at line end (simplified)
            if '}' in line:
                in_conditional = False
                in_loop = False
        
        return graph
    
    def _remove_strings_and_comments(self, line: str) -> str:
        """Remove string literals and comments from a line."""
        # Remove single-line comments
        line = re.sub(r'//.*$', '', line)
        # Remove string literals (simplified)
        line = re.sub(r'"[^"\\]*(?:\\.[^"\\]*)*"', '""', line)
        line = re.sub(r"'[^'\\]*(?:\\.[^'\\]*)*'", "''", line)
        line = re.sub(r'`[^`\\]*(?:\\.[^`\\]*)*`', '``', line)
        return line
    
    def _resolve_call_target(
        self,
        call_target: str,
        module_name: str,
        functions: Dict[str, Tuple[int, int, Optional[str]]],
        current_function: str,
    ) -> Optional[str]:
        """Resolve a call target to a function ID."""
        # Handle this.method() calls
        if call_target.startswith('this.'):
            method_name = call_target[5:]
            # Find the class of the current function
            for func_name, (_, _, class_name) in functions.items():
                if func_name == current_function and class_name:
                    target = f"{module_name}.{class_name}.{method_name}"
                    if target in functions:
                        return target
            return None
        
        # Check if it's a direct reference to a known function
        simple_target = f"{module_name}.{call_target}"
        if simple_target in functions:
            return simple_target
        
        # Check for method call on known class
        if '.' in call_target:
            parts = call_target.split('.')
            potential_target = f"{module_name}.{'.'.join(parts)}"
            if potential_target in functions:
                return potential_target
        
        # Return as external reference
        return f"external.{call_target}"
    
    def parse_directory(
        self,
        directory: str | Path,
        recursive: bool = True,
        exclude_patterns: Optional[List[str]] = None,
    ) -> CallGraph:
        """
        Parse all JavaScript/TypeScript files in a directory.
        
        Args:
            directory: Path to the directory
            recursive: Whether to search recursively
            exclude_patterns: Glob patterns for files to exclude
            
        Returns:
            Combined CallGraph from all files
        """
        directory = Path(directory)
        exclude_patterns = exclude_patterns or ["*node_modules*", "*test*", "*.min.js", "*dist*", "*build*"]
        
        combined_graph = CallGraph()
        
        extensions = ["*.js", "*.jsx", "*.ts", "*.tsx", "*.mjs"]
        
        for ext in extensions:
            pattern = f"**/{ext}" if recursive else ext
            for file_path in directory.glob(pattern):
                # Check exclusions
                should_exclude = False
                for excl_pattern in exclude_patterns:
                    if file_path.match(excl_pattern) or excl_pattern.replace('*', '') in str(file_path):
                        should_exclude = True
                        break
                
                if should_exclude:
                    continue
                
                try:
                    file_graph = self.parse_file(file_path)
                    combined_graph.merge(file_graph)
                except (ValueError, UnicodeDecodeError) as e:
                    print(f"Warning: Skipping {file_path}: {e}")
        
        return combined_graph
