"""
Unified parser interface for multiple languages.
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Union

from .graph import CallGraph
from .python_parser import PythonParser
from .javascript_parser import JavaScriptParser


class CallGraphParser:
    """
    Unified parser that automatically detects file types and delegates
    to the appropriate language-specific parser.
    """
    
    PYTHON_EXTENSIONS = {'.py', '.pyw', '.pyi'}
    JS_EXTENSIONS = {'.js', '.jsx', '.ts', '.tsx', '.mjs', '.cjs'}
    
    def __init__(
        self,
        include_builtins: bool = False,
        include_stdlib: bool = False,
    ):
        """
        Initialize the parser.
        
        Args:
            include_builtins: Include calls to built-in functions
            include_stdlib: Include calls to standard library functions
        """
        self.python_parser = PythonParser(
            include_builtins=include_builtins,
            include_stdlib=include_stdlib,
        )
        self.js_parser = JavaScriptParser(include_builtins=include_builtins)
    
    def parse_file(self, file_path: Union[str, Path]) -> CallGraph:
        """
        Parse a source file and extract its call graph.
        
        Automatically detects the language based on file extension.
        
        Args:
            file_path: Path to the source file
            
        Returns:
            CallGraph containing function definitions and calls
            
        Raises:
            ValueError: If the file type is not supported
        """
        file_path = Path(file_path)
        ext = file_path.suffix.lower()
        
        if ext in self.PYTHON_EXTENSIONS:
            return self.python_parser.parse_file(file_path)
        elif ext in self.JS_EXTENSIONS:
            return self.js_parser.parse_file(file_path)
        else:
            raise ValueError(f"Unsupported file type: {ext}")
    
    def parse_source(
        self,
        source: str,
        language: str,
        file_path: str = "<string>",
    ) -> CallGraph:
        """
        Parse source code and extract its call graph.
        
        Args:
            source: Source code
            language: Programming language ('python' or 'javascript')
            file_path: Optional file path for references
            
        Returns:
            CallGraph containing function definitions and calls
            
        Raises:
            ValueError: If the language is not supported
        """
        language = language.lower()
        
        if language in ('python', 'py'):
            return self.python_parser.parse_source(source, file_path)
        elif language in ('javascript', 'js', 'typescript', 'ts'):
            return self.js_parser.parse_source(source, file_path)
        else:
            raise ValueError(f"Unsupported language: {language}")
    
    def parse_directory(
        self,
        directory: Union[str, Path],
        recursive: bool = True,
        exclude_patterns: Optional[List[str]] = None,
        languages: Optional[List[str]] = None,
    ) -> CallGraph:
        """
        Parse all supported source files in a directory.
        
        Args:
            directory: Path to the directory
            recursive: Whether to search recursively
            exclude_patterns: Glob patterns for files to exclude
            languages: Languages to include (default: all supported)
            
        Returns:
            Combined CallGraph from all files
        """
        directory = Path(directory)
        languages = [l.lower() for l in (languages or ['python', 'javascript'])]
        
        combined_graph = CallGraph()
        
        if 'python' in languages or 'py' in languages:
            py_graph = self.python_parser.parse_directory(
                directory,
                recursive=recursive,
                exclude_patterns=exclude_patterns,
            )
            combined_graph.merge(py_graph)
        
        if 'javascript' in languages or 'js' in languages or 'typescript' in languages or 'ts' in languages:
            js_graph = self.js_parser.parse_directory(
                directory,
                recursive=recursive,
                exclude_patterns=exclude_patterns,
            )
            combined_graph.merge(js_graph)
        
        return combined_graph
    
    def parse_files(
        self,
        file_paths: List[Union[str, Path]],
    ) -> CallGraph:
        """
        Parse multiple source files and combine their call graphs.
        
        Args:
            file_paths: List of paths to source files
            
        Returns:
            Combined CallGraph from all files
        """
        combined_graph = CallGraph()
        
        for file_path in file_paths:
            try:
                file_graph = self.parse_file(file_path)
                combined_graph.merge(file_graph)
            except ValueError as e:
                print(f"Warning: Skipping {file_path}: {e}")
        
        return combined_graph
