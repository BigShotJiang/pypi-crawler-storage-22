"""
Python source code parser for extracting function definitions and calls.
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, field

from .graph import CallGraph, FunctionNode, NodeType


@dataclass
class Scope:
    """Tracks the current parsing scope."""
    name: str
    type: NodeType
    class_name: Optional[str] = None
    parent: Optional["Scope"] = None
    
    def get_qualified_name(self, name: str) -> str:
        """Get the fully qualified name for a symbol in this scope."""
        parts = []
        scope = self
        while scope:
            if scope.type != NodeType.MODULE:
                parts.append(scope.name)
            scope = scope.parent
        parts.reverse()
        parts.append(name)
        return ".".join(parts)


class CallVisitor(ast.NodeVisitor):
    """AST visitor that extracts function calls."""
    
    def __init__(self, module_name: str, file_path: str):
        self.module_name = module_name
        self.file_path = file_path
        self.graph = CallGraph()
        self.scope_stack: List[Scope] = []
        self.current_function: Optional[str] = None
        self.imports: Dict[str, str] = {}  # alias -> full module path
        self.from_imports: Dict[str, Tuple[str, str]] = {}  # name -> (module, original_name)
        self.in_conditional = False
        self.in_loop = False
        
    @property
    def current_scope(self) -> Optional[Scope]:
        return self.scope_stack[-1] if self.scope_stack else None
    
    def _get_node_id(self, name: str, scope: Optional[Scope] = None) -> str:
        """Generate a unique node ID."""
        if scope:
            return f"{self.module_name}.{scope.get_qualified_name(name)}"
        return f"{self.module_name}.{name}"
    
    def _resolve_call_target(self, node: ast.Call) -> Optional[str]:
        """Resolve the target of a function call."""
        func = node.func
        
        if isinstance(func, ast.Name):
            # Simple function call: foo()
            name = func.id
            
            # Check if it's an imported name
            if name in self.from_imports:
                module, original = self.from_imports[name]
                return f"{module}.{original}"
            if name in self.imports:
                return self.imports[name]
            
            # Check if it's a local function
            if self.current_scope:
                # Could be in current scope or parent scopes
                return self._get_node_id(name, self.current_scope.parent)
            return f"{self.module_name}.{name}"
            
        elif isinstance(func, ast.Attribute):
            # Method call: obj.method() or module.func()
            parts = []
            current = func
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            
            if isinstance(current, ast.Name):
                parts.append(current.id)
            else:
                # Complex expression, can't resolve statically
                return None
            
            parts.reverse()
            base = parts[0]
            
            # Check if base is an import alias
            if base in self.imports:
                parts[0] = self.imports[base]
            elif base in self.from_imports:
                module, original = self.from_imports[base]
                parts[0] = f"{module}.{original}"
            elif base == "self" and self.current_scope and self.current_scope.class_name:
                # self.method() call
                parts[0] = f"{self.module_name}.{self.current_scope.class_name}"
            
            return ".".join(parts)
        
        return None
    
    def visit_Import(self, node: ast.Import) -> None:
        """Track import statements."""
        for alias in node.names:
            name = alias.asname or alias.name
            self.imports[name] = alias.name
        self.generic_visit(node)
    
    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        """Track from...import statements."""
        module = node.module or ""
        for alias in node.names:
            name = alias.asname or alias.name
            self.from_imports[name] = (module, alias.name)
        self.generic_visit(node)
    
    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        """Visit a class definition."""
        parent_scope = self.current_scope
        class_scope = Scope(
            name=node.name,
            type=NodeType.CLASS,
            class_name=node.name,
            parent=parent_scope,
        )
        
        # Add class as a node
        node_id = self._get_node_id(node.name, parent_scope)
        class_node = FunctionNode(
            id=node_id,
            name=node.name,
            qualified_name=node_id,
            file_path=self.file_path,
            line_number=node.lineno,
            end_line=node.end_lineno,
            node_type=NodeType.CLASS,
            module_name=self.module_name,
            docstring=ast.get_docstring(node),
        )
        self.graph.add_node(class_node)
        
        self.scope_stack.append(class_scope)
        self.generic_visit(node)
        self.scope_stack.pop()
    
    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """Visit a function definition."""
        self._visit_function(node, is_async=False)
    
    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        """Visit an async function definition."""
        self._visit_function(node, is_async=True)
    
    def _visit_function(self, node, is_async: bool) -> None:
        """Common logic for function/async function definitions."""
        parent_scope = self.current_scope
        
        # Determine if this is a method or function
        is_method = parent_scope and parent_scope.type == NodeType.CLASS
        node_type = NodeType.METHOD if is_method else NodeType.FUNCTION
        
        func_scope = Scope(
            name=node.name,
            type=node_type,
            class_name=parent_scope.class_name if parent_scope else None,
            parent=parent_scope,
        )
        
        # Generate node ID
        node_id = self._get_node_id(node.name, parent_scope)
        
        # Extract parameters
        params = []
        for arg in node.args.args:
            params.append(arg.arg)
        for arg in node.args.posonlyargs:
            params.append(arg.arg)
        for arg in node.args.kwonlyargs:
            params.append(arg.arg)
        if node.args.vararg:
            params.append(f"*{node.args.vararg.arg}")
        if node.args.kwarg:
            params.append(f"**{node.args.kwarg.arg}")
        
        # Check if it's a generator
        is_generator = any(
            isinstance(child, (ast.Yield, ast.YieldFrom))
            for child in ast.walk(node)
        )
        
        # Create function node
        func_node = FunctionNode(
            id=node_id,
            name=node.name,
            qualified_name=node_id,
            file_path=self.file_path,
            line_number=node.lineno,
            end_line=node.end_lineno,
            node_type=node_type,
            class_name=parent_scope.class_name if parent_scope else None,
            module_name=self.module_name,
            docstring=ast.get_docstring(node),
            is_async=is_async,
            is_generator=is_generator,
            parameters=params,
        )
        self.graph.add_node(func_node)
        
        # Track current function for call edges
        old_function = self.current_function
        self.current_function = node_id
        
        self.scope_stack.append(func_scope)
        self.generic_visit(node)
        self.scope_stack.pop()
        
        self.current_function = old_function
    
    def visit_If(self, node: ast.If) -> None:
        """Track conditional context."""
        old_conditional = self.in_conditional
        self.in_conditional = True
        self.generic_visit(node)
        self.in_conditional = old_conditional
    
    def visit_For(self, node: ast.For) -> None:
        """Track loop context."""
        old_loop = self.in_loop
        self.in_loop = True
        self.generic_visit(node)
        self.in_loop = old_loop
    
    def visit_While(self, node: ast.While) -> None:
        """Track loop context."""
        old_loop = self.in_loop
        self.in_loop = True
        self.generic_visit(node)
        self.in_loop = old_loop
    
    def visit_Call(self, node: ast.Call) -> None:
        """Visit a function call."""
        if self.current_function:
            target = self._resolve_call_target(node)
            if target:
                self.graph.add_edge(
                    caller_id=self.current_function,
                    callee_id=target,
                    line_number=node.lineno,
                    is_conditional=self.in_conditional,
                    is_loop=self.in_loop,
                )
        
        self.generic_visit(node)


class PythonParser:
    """
    Parser for Python source code that extracts function call graphs.
    
    Uses Python's built-in AST module for accurate parsing.
    """
    
    def __init__(self, include_builtins: bool = False, include_stdlib: bool = False):
        """
        Initialize the parser.
        
        Args:
            include_builtins: Include calls to built-in functions
            include_stdlib: Include calls to standard library functions
        """
        self.include_builtins = include_builtins
        self.include_stdlib = include_stdlib
        # Get builtin names properly
        import builtins
        self.builtins = set(dir(builtins))
    
    def parse_file(self, file_path: str | Path) -> CallGraph:
        """
        Parse a Python file and extract its call graph.
        
        Args:
            file_path: Path to the Python file
            
        Returns:
            CallGraph containing function definitions and calls
        """
        file_path = Path(file_path)
        
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()
        
        return self.parse_source(source, str(file_path))
    
    def parse_source(self, source: str, file_path: str = "<string>") -> CallGraph:
        """
        Parse Python source code and extract its call graph.
        
        Args:
            source: Python source code
            file_path: Optional file path for error messages
            
        Returns:
            CallGraph containing function definitions and calls
        """
        # Derive module name from file path
        module_name = Path(file_path).stem if file_path != "<string>" else "module"
        
        try:
            tree = ast.parse(source, filename=file_path)
        except SyntaxError as e:
            raise ValueError(f"Failed to parse {file_path}: {e}")
        
        visitor = CallVisitor(module_name, file_path)
        visitor.visit(tree)
        
        # Filter out builtins if not included
        if not self.include_builtins:
            edges_to_remove = []
            for edge_key, edge in visitor.graph.edges.items():
                callee_name = edge.callee_id.split(".")[-1]
                if callee_name in self.builtins:
                    edges_to_remove.append(edge_key)
            for key in edges_to_remove:
                del visitor.graph.edges[key]
        
        return visitor.graph
    
    def parse_directory(
        self,
        directory: str | Path,
        recursive: bool = True,
        exclude_patterns: Optional[List[str]] = None,
    ) -> CallGraph:
        """
        Parse all Python files in a directory.
        
        Args:
            directory: Path to the directory
            recursive: Whether to search recursively
            exclude_patterns: Glob patterns for files to exclude
            
        Returns:
            Combined CallGraph from all files
        """
        directory = Path(directory)
        exclude_patterns = exclude_patterns or ["*test*", "*__pycache__*", "*.pyc"]
        
        combined_graph = CallGraph()
        
        pattern = "**/*.py" if recursive else "*.py"
        for file_path in directory.glob(pattern):
            # Check exclusions
            should_exclude = False
            for pattern in exclude_patterns:
                if file_path.match(pattern):
                    should_exclude = True
                    break
            
            if should_exclude:
                continue
            
            try:
                file_graph = self.parse_file(file_path)
                combined_graph.merge(file_graph)
            except (ValueError, UnicodeDecodeError) as e:
                # Skip files that can't be parsed
                print(f"Warning: Skipping {file_path}: {e}")
        
        return combined_graph
