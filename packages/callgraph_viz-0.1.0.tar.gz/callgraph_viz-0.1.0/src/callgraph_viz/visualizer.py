"""
Interactive HTML visualizer for call graphs using D3.js.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional, List
from dataclasses import dataclass

from .graph import CallGraph, NodeType


@dataclass
class VisualizationConfig:
    """Configuration for the visualization."""
    title: str = "Call Graph"
    width: int = 1200
    height: int = 800
    node_radius: int = 8
    link_distance: int = 100
    charge_strength: int = -300
    show_labels: bool = True
    show_arrows: bool = True
    color_by_file: bool = True
    color_by_type: bool = False
    highlight_recursive: bool = True
    enable_zoom: bool = True
    enable_drag: bool = True
    enable_search: bool = True


# D3.js visualization template (self-contained HTML)
HTML_TEMPLATE = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #1a1a2e;
            color: #eee;
            overflow: hidden;
        }}
        #container {{
            display: flex;
            height: 100vh;
        }}
        #sidebar {{
            width: 300px;
            background: #16213e;
            padding: 20px;
            overflow-y: auto;
            border-right: 1px solid #0f3460;
        }}
        #graph-container {{
            flex: 1;
            position: relative;
        }}
        svg {{
            width: 100%;
            height: 100%;
        }}
        h1 {{
            font-size: 1.4em;
            margin-bottom: 20px;
            color: #e94560;
        }}
        .search-box {{
            width: 100%;
            padding: 10px;
            border: 1px solid #0f3460;
            border-radius: 5px;
            background: #1a1a2e;
            color: #eee;
            margin-bottom: 15px;
        }}
        .search-box:focus {{
            outline: none;
            border-color: #e94560;
        }}
        .stats {{
            background: #0f3460;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
        }}
        .stats h3 {{
            font-size: 0.9em;
            color: #e94560;
            margin-bottom: 10px;
        }}
        .stat-row {{
            display: flex;
            justify-content: space-between;
            padding: 5px 0;
            border-bottom: 1px solid #16213e;
        }}
        .stat-row:last-child {{
            border-bottom: none;
        }}
        .stat-label {{
            color: #aaa;
        }}
        .stat-value {{
            color: #fff;
            font-weight: bold;
        }}
        .legend {{
            margin-top: 15px;
        }}
        .legend h3 {{
            font-size: 0.9em;
            color: #e94560;
            margin-bottom: 10px;
        }}
        .legend-item {{
            display: flex;
            align-items: center;
            padding: 5px 0;
        }}
        .legend-color {{
            width: 16px;
            height: 16px;
            border-radius: 50%;
            margin-right: 10px;
        }}
        .node-info {{
            margin-top: 15px;
            background: #0f3460;
            padding: 15px;
            border-radius: 5px;
            display: none;
        }}
        .node-info.active {{
            display: block;
        }}
        .node-info h3 {{
            font-size: 0.9em;
            color: #e94560;
            margin-bottom: 10px;
        }}
        .node-info-name {{
            font-size: 1.1em;
            font-weight: bold;
            word-break: break-all;
        }}
        .node-info-detail {{
            color: #aaa;
            font-size: 0.85em;
            margin-top: 5px;
        }}
        .node-info-list {{
            margin-top: 10px;
            max-height: 150px;
            overflow-y: auto;
        }}
        .node-info-list-item {{
            padding: 3px 0;
            font-size: 0.85em;
            color: #ccc;
            cursor: pointer;
        }}
        .node-info-list-item:hover {{
            color: #e94560;
        }}
        .tooltip {{
            position: absolute;
            background: rgba(15, 52, 96, 0.95);
            color: #fff;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 0.85em;
            pointer-events: none;
            z-index: 1000;
            max-width: 300px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
        }}
        .tooltip-title {{
            font-weight: bold;
            color: #e94560;
            margin-bottom: 5px;
        }}
        .tooltip-detail {{
            color: #aaa;
        }}
        .controls {{
            position: absolute;
            bottom: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
        }}
        .control-btn {{
            background: #0f3460;
            border: none;
            color: #fff;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.2s;
        }}
        .control-btn:hover {{
            background: #e94560;
        }}
        .link {{
            stroke: #4a5568;
            stroke-opacity: 0.6;
            fill: none;
        }}
        .link.highlighted {{
            stroke: #e94560;
            stroke-opacity: 1;
            stroke-width: 2px;
        }}
        .link.dimmed {{
            stroke-opacity: 0.1;
        }}
        .node circle {{
            stroke: #fff;
            stroke-width: 1.5px;
            cursor: pointer;
            transition: r 0.2s;
        }}
        .node.highlighted circle {{
            stroke: #e94560;
            stroke-width: 3px;
        }}
        .node.dimmed circle {{
            opacity: 0.2;
        }}
        .node.recursive circle {{
            stroke: #ffd700;
            stroke-width: 2px;
            stroke-dasharray: 3,3;
        }}
        .node-label {{
            font-size: 10px;
            fill: #aaa;
            pointer-events: none;
        }}
        .node.highlighted .node-label {{
            fill: #fff;
            font-weight: bold;
        }}
        .node.dimmed .node-label {{
            opacity: 0.2;
        }}
        marker {{
            fill: #4a5568;
        }}
        .highlighted marker {{
            fill: #e94560;
        }}
    </style>
</head>
<body>
    <div id="container">
        <div id="sidebar">
            <h1>{title}</h1>
            <input type="text" class="search-box" id="search" placeholder="Search functions...">
            
            <div class="stats">
                <h3>Statistics</h3>
                <div class="stat-row">
                    <span class="stat-label">Functions</span>
                    <span class="stat-value" id="stat-nodes">0</span>
                </div>
                <div class="stat-row">
                    <span class="stat-label">Calls</span>
                    <span class="stat-value" id="stat-edges">0</span>
                </div>
                <div class="stat-row">
                    <span class="stat-label">Entry Points</span>
                    <span class="stat-value" id="stat-entry">0</span>
                </div>
                <div class="stat-row">
                    <span class="stat-label">Leaf Functions</span>
                    <span class="stat-value" id="stat-leaf">0</span>
                </div>
                <div class="stat-row">
                    <span class="stat-label">Recursive</span>
                    <span class="stat-value" id="stat-recursive">0</span>
                </div>
            </div>
            
            <div class="legend">
                <h3>Node Types</h3>
                <div class="legend-item">
                    <div class="legend-color" style="background: #e94560;"></div>
                    <span>Function</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #0f3460;"></div>
                    <span>Method</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #533483;"></div>
                    <span>Class</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #4a5568;"></div>
                    <span>External</span>
                </div>
            </div>
            
            <div class="node-info" id="node-info">
                <h3>Selected Function</h3>
                <div class="node-info-name" id="info-name"></div>
                <div class="node-info-detail" id="info-file"></div>
                <div class="node-info-detail" id="info-type"></div>
                <div class="node-info-list" id="info-callers">
                    <strong>Called by:</strong>
                </div>
                <div class="node-info-list" id="info-callees">
                    <strong>Calls:</strong>
                </div>
            </div>
        </div>
        
        <div id="graph-container">
            <svg id="graph"></svg>
            <div class="controls">
                <button class="control-btn" id="btn-reset">Reset View</button>
                <button class="control-btn" id="btn-center">Center</button>
            </div>
        </div>
    </div>
    
    <div class="tooltip" id="tooltip" style="display: none;"></div>
    
    <script>
        // Graph data (injected by Python)
        const graphData = {graph_data};
        
        // Configuration
        const config = {config};
        
        // Color scale for node types
        const typeColors = {{
            'function': '#e94560',
            'method': '#0f3460',
            'class': '#533483',
            'module': '#1a5f7a',
            'builtin': '#718096',
            'external': '#4a5568'
        }};
        
        // Color scale for files
        const fileColors = d3.scaleOrdinal(d3.schemeCategory10);
        
        // Get unique files
        const files = [...new Set(graphData.nodes.map(n => n.file_path).filter(f => f))];
        
        // Setup SVG
        const svg = d3.select('#graph');
        const container = document.getElementById('graph-container');
        const width = container.clientWidth;
        const height = container.clientHeight;
        
        // Create zoom behavior
        const zoom = d3.zoom()
            .scaleExtent([0.1, 4])
            .on('zoom', (event) => {{
                g.attr('transform', event.transform);
            }});
        
        svg.call(zoom);
        
        // Main group for zoom/pan
        const g = svg.append('g');
        
        // Arrow marker
        svg.append('defs').append('marker')
            .attr('id', 'arrowhead')
            .attr('viewBox', '-0 -5 10 10')
            .attr('refX', 20)
            .attr('refY', 0)
            .attr('orient', 'auto')
            .attr('markerWidth', 6)
            .attr('markerHeight', 6)
            .append('path')
            .attr('d', 'M 0,-5 L 10,0 L 0,5')
            .attr('fill', '#4a5568');
        
        // Build node map
        const nodeMap = new Map(graphData.nodes.map(n => [n.id, n]));
        
        // Find recursive calls
        const recursiveCalls = new Set();
        graphData.edges.forEach(e => {{
            if (e.source === e.target) {{
                recursiveCalls.add(e.source);
            }}
        }});
        
        // Find entry points (no incoming edges)
        const hasIncoming = new Set(graphData.edges.map(e => e.target));
        const entryPoints = graphData.nodes.filter(n => !hasIncoming.has(n.id));
        
        // Find leaf nodes (no outgoing edges)
        const hasOutgoing = new Set(graphData.edges.map(e => e.source));
        const leafNodes = graphData.nodes.filter(n => !hasOutgoing.has(n.id));
        
        // Update stats
        document.getElementById('stat-nodes').textContent = graphData.nodes.length;
        document.getElementById('stat-edges').textContent = graphData.edges.length;
        document.getElementById('stat-entry').textContent = entryPoints.length;
        document.getElementById('stat-leaf').textContent = leafNodes.length;
        document.getElementById('stat-recursive').textContent = recursiveCalls.size;
        
        // Create force simulation
        const simulation = d3.forceSimulation(graphData.nodes)
            .force('link', d3.forceLink(graphData.edges)
                .id(d => d.id)
                .distance(config.link_distance))
            .force('charge', d3.forceManyBody()
                .strength(config.charge_strength))
            .force('center', d3.forceCenter(width / 2, height / 2))
            .force('collision', d3.forceCollide().radius(config.node_radius * 2));
        
        // Create links
        const link = g.append('g')
            .attr('class', 'links')
            .selectAll('path')
            .data(graphData.edges)
            .enter().append('path')
            .attr('class', 'link')
            .attr('marker-end', 'url(#arrowhead)')
            .attr('stroke-width', d => Math.min(Math.sqrt(d.call_count), 4));
        
        // Create nodes
        const node = g.append('g')
            .attr('class', 'nodes')
            .selectAll('g')
            .data(graphData.nodes)
            .enter().append('g')
            .attr('class', d => {{
                let classes = 'node';
                if (recursiveCalls.has(d.id)) classes += ' recursive';
                return classes;
            }})
            .call(d3.drag()
                .on('start', dragstarted)
                .on('drag', dragged)
                .on('end', dragended));
        
        // Add circles to nodes
        node.append('circle')
            .attr('r', d => {{
                // Size based on number of connections
                const connections = graphData.edges.filter(e => 
                    e.source.id === d.id || e.target.id === d.id
                ).length;
                return config.node_radius + Math.min(connections, 5);
            }})
            .attr('fill', d => {{
                if (config.color_by_file && d.file_path) {{
                    return fileColors(d.file_path);
                }}
                return typeColors[d.node_type] || typeColors['function'];
            }});
        
        // Add labels to nodes
        if (config.show_labels) {{
            node.append('text')
                .attr('class', 'node-label')
                .attr('dx', 12)
                .attr('dy', 4)
                .text(d => d.name);
        }}
        
        // Tooltip
        const tooltip = document.getElementById('tooltip');
        
        node.on('mouseover', (event, d) => {{
            // Show tooltip
            tooltip.innerHTML = `
                <div class="tooltip-title">${{d.name}}</div>
                <div class="tooltip-detail">${{d.qualified_name}}</div>
                ${{d.file_path ? `<div class="tooltip-detail">${{d.file_path}}:${{d.line_number || '?'}}</div>` : ''}}
                <div class="tooltip-detail">Type: ${{d.node_type}}</div>
            `;
            tooltip.style.display = 'block';
            tooltip.style.left = (event.pageX + 10) + 'px';
            tooltip.style.top = (event.pageY - 10) + 'px';
            
            // Highlight connected nodes
            highlightConnected(d);
        }});
        
        node.on('mouseout', () => {{
            tooltip.style.display = 'none';
            resetHighlight();
        }});
        
        node.on('click', (event, d) => {{
            showNodeInfo(d);
        }});
        
        // Highlight connected nodes
        function highlightConnected(d) {{
            const connected = new Set([d.id]);
            const connectedLinks = new Set();
            
            graphData.edges.forEach((e, i) => {{
                const sourceId = typeof e.source === 'object' ? e.source.id : e.source;
                const targetId = typeof e.target === 'object' ? e.target.id : e.target;
                
                if (sourceId === d.id) {{
                    connected.add(targetId);
                    connectedLinks.add(i);
                }}
                if (targetId === d.id) {{
                    connected.add(sourceId);
                    connectedLinks.add(i);
                }}
            }});
            
            node.classed('highlighted', n => connected.has(n.id))
                .classed('dimmed', n => !connected.has(n.id));
            
            link.classed('highlighted', (l, i) => connectedLinks.has(i))
                .classed('dimmed', (l, i) => !connectedLinks.has(i));
        }}
        
        function resetHighlight() {{
            node.classed('highlighted', false).classed('dimmed', false);
            link.classed('highlighted', false).classed('dimmed', false);
        }}
        
        // Show node info in sidebar
        function showNodeInfo(d) {{
            const infoPanel = document.getElementById('node-info');
            infoPanel.classList.add('active');
            
            document.getElementById('info-name').textContent = d.qualified_name;
            document.getElementById('info-file').textContent = d.file_path 
                ? `${{d.file_path}}:${{d.line_number || '?'}}` 
                : 'External';
            document.getElementById('info-type').textContent = `Type: ${{d.node_type}}${{d.is_async ? ' (async)' : ''}}`;
            
            // Find callers
            const callers = graphData.edges
                .filter(e => (typeof e.target === 'object' ? e.target.id : e.target) === d.id)
                .map(e => typeof e.source === 'object' ? e.source : nodeMap.get(e.source))
                .filter(n => n);
            
            // Find callees
            const callees = graphData.edges
                .filter(e => (typeof e.source === 'object' ? e.source.id : e.source) === d.id)
                .map(e => typeof e.target === 'object' ? e.target : nodeMap.get(e.target))
                .filter(n => n);
            
            const callersDiv = document.getElementById('info-callers');
            callersDiv.innerHTML = '<strong>Called by:</strong>';
            callers.forEach(c => {{
                const item = document.createElement('div');
                item.className = 'node-info-list-item';
                item.textContent = c.name || c.id;
                item.onclick = () => focusNode(c);
                callersDiv.appendChild(item);
            }});
            if (callers.length === 0) {{
                const item = document.createElement('div');
                item.className = 'node-info-list-item';
                item.textContent = '(none - entry point)';
                callersDiv.appendChild(item);
            }}
            
            const calleesDiv = document.getElementById('info-callees');
            calleesDiv.innerHTML = '<strong>Calls:</strong>';
            callees.forEach(c => {{
                const item = document.createElement('div');
                item.className = 'node-info-list-item';
                item.textContent = c.name || c.id;
                item.onclick = () => focusNode(c);
                calleesDiv.appendChild(item);
            }});
            if (callees.length === 0) {{
                const item = document.createElement('div');
                item.className = 'node-info-list-item';
                item.textContent = '(none - leaf function)';
                calleesDiv.appendChild(item);
            }}
        }}
        
        function focusNode(d) {{
            // Center view on node
            const transform = d3.zoomIdentity
                .translate(width / 2 - d.x, height / 2 - d.y);
            svg.transition().duration(500).call(zoom.transform, transform);
            
            // Highlight
            highlightConnected(d);
            showNodeInfo(d);
        }}
        
        // Search functionality
        const searchInput = document.getElementById('search');
        searchInput.addEventListener('input', (e) => {{
            const query = e.target.value.toLowerCase();
            if (!query) {{
                resetHighlight();
                return;
            }}
            
            const matches = new Set();
            graphData.nodes.forEach(n => {{
                if (n.name.toLowerCase().includes(query) || 
                    n.qualified_name.toLowerCase().includes(query)) {{
                    matches.add(n.id);
                }}
            }});
            
            node.classed('highlighted', n => matches.has(n.id))
                .classed('dimmed', n => !matches.has(n.id) && matches.size > 0);
            
            link.classed('dimmed', (l) => {{
                const sourceId = typeof l.source === 'object' ? l.source.id : l.source;
                const targetId = typeof l.target === 'object' ? l.target.id : l.target;
                return matches.size > 0 && !matches.has(sourceId) && !matches.has(targetId);
            }});
        }});
        
        // Control buttons
        document.getElementById('btn-reset').onclick = () => {{
            svg.transition().duration(500).call(
                zoom.transform,
                d3.zoomIdentity
            );
        }};
        
        document.getElementById('btn-center').onclick = () => {{
            // Find center of all nodes
            const cx = d3.mean(graphData.nodes, d => d.x);
            const cy = d3.mean(graphData.nodes, d => d.y);
            const transform = d3.zoomIdentity
                .translate(width / 2 - cx, height / 2 - cy);
            svg.transition().duration(500).call(zoom.transform, transform);
        }};
        
        // Update positions on tick
        simulation.on('tick', () => {{
            link.attr('d', d => {{
                const dx = d.target.x - d.source.x;
                const dy = d.target.y - d.source.y;
                return `M${{d.source.x}},${{d.source.y}}L${{d.target.x}},${{d.target.y}}`;
            }});
            
            node.attr('transform', d => `translate(${{d.x}},${{d.y}})`);
        }});
        
        // Drag functions
        function dragstarted(event, d) {{
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }}
        
        function dragged(event, d) {{
            d.fx = event.x;
            d.fy = event.y;
        }}
        
        function dragended(event, d) {{
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }}
        
        // Handle window resize
        window.addEventListener('resize', () => {{
            const newWidth = container.clientWidth;
            const newHeight = container.clientHeight;
            simulation.force('center', d3.forceCenter(newWidth / 2, newHeight / 2));
            simulation.alpha(0.3).restart();
        }});
    </script>
</body>
</html>
'''


class CallGraphVisualizer:
    """
    Generates interactive HTML visualizations of call graphs.
    
    Uses D3.js for rendering with features like:
    - Zoom and pan
    - Node dragging
    - Search/filter
    - Hover highlighting
    - Click to show details
    """
    
    def __init__(self, config: Optional[VisualizationConfig] = None):
        """
        Initialize the visualizer.
        
        Args:
            config: Visualization configuration
        """
        self.config = config or VisualizationConfig()
    
    def generate_html(self, graph: CallGraph, output_path: Optional[str | Path] = None) -> str:
        """
        Generate an interactive HTML visualization.
        
        Args:
            graph: The call graph to visualize
            output_path: Optional path to write the HTML file
            
        Returns:
            The generated HTML string
        """
        # Convert graph to JSON
        graph_data = graph.to_dict()
        graph_json = json.dumps(graph_data, indent=2)
        
        # Convert config to JSON
        config_dict = {
            'width': self.config.width,
            'height': self.config.height,
            'node_radius': self.config.node_radius,
            'link_distance': self.config.link_distance,
            'charge_strength': self.config.charge_strength,
            'show_labels': self.config.show_labels,
            'show_arrows': self.config.show_arrows,
            'color_by_file': self.config.color_by_file,
            'color_by_type': self.config.color_by_type,
            'highlight_recursive': self.config.highlight_recursive,
            'enable_zoom': self.config.enable_zoom,
            'enable_drag': self.config.enable_drag,
            'enable_search': self.config.enable_search,
        }
        config_json = json.dumps(config_dict)
        
        # Generate HTML
        html = HTML_TEMPLATE.format(
            title=self.config.title,
            graph_data=graph_json,
            config=config_json,
        )
        
        # Write to file if path provided
        if output_path:
            output_path = Path(output_path)
            output_path.write_text(html, encoding='utf-8')
        
        return html
    
    def generate_from_file(
        self,
        source_path: str | Path,
        output_path: str | Path,
        parser: Optional["CallGraphParser"] = None,
    ) -> str:
        """
        Parse a source file and generate visualization.
        
        Args:
            source_path: Path to the source file
            output_path: Path to write the HTML file
            parser: Optional parser instance
            
        Returns:
            The generated HTML string
        """
        from .parser import CallGraphParser
        
        parser = parser or CallGraphParser()
        graph = parser.parse_file(source_path)
        
        # Update title
        self.config.title = f"Call Graph: {Path(source_path).name}"
        
        return self.generate_html(graph, output_path)
    
    def generate_from_directory(
        self,
        directory: str | Path,
        output_path: str | Path,
        parser: Optional["CallGraphParser"] = None,
        recursive: bool = True,
    ) -> str:
        """
        Parse a directory and generate visualization.
        
        Args:
            directory: Path to the directory
            output_path: Path to write the HTML file
            parser: Optional parser instance
            recursive: Whether to search recursively
            
        Returns:
            The generated HTML string
        """
        from .parser import CallGraphParser
        
        parser = parser or CallGraphParser()
        graph = parser.parse_directory(directory, recursive=recursive)
        
        # Update title
        self.config.title = f"Call Graph: {Path(directory).name}"
        
        return self.generate_html(graph, output_path)
