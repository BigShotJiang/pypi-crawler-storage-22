"""Tests for the CLI."""

import pytest
import tempfile
from pathlib import Path

from callgraph_viz.cli import main


class TestCLI:
    """Tests for the command-line interface."""
    
    def test_cli_help(self, capsys):
        """Test CLI help output."""
        with pytest.raises(SystemExit) as exc_info:
            main(['--help'])
        
        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        assert 'callgraph-viz' in captured.out
        assert '--output' in captured.out
    
    def test_cli_version(self, capsys):
        """Test CLI version output."""
        with pytest.raises(SystemExit) as exc_info:
            main(['--version'])
        
        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        assert '0.1.0' in captured.out
    
    def test_cli_single_file(self):
        """Test CLI with a single Python file."""
        source = '''
def main():
    helper()

def helper():
    pass
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create source file
            source_path = Path(tmpdir) / "test.py"
            source_path.write_text(source)
            
            # Create output path
            output_path = Path(tmpdir) / "graph.html"
            
            # Run CLI
            result = main([str(source_path), '-o', str(output_path)])
            
            assert result == 0
            assert output_path.exists()
            
            content = output_path.read_text()
            assert 'main' in content
            assert 'helper' in content
    
    def test_cli_multiple_files(self):
        """Test CLI with multiple files."""
        source1 = '''
def func_a():
    pass
'''
        source2 = '''
def func_b():
    pass
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            path1 = Path(tmpdir) / "file1.py"
            path2 = Path(tmpdir) / "file2.py"
            path1.write_text(source1)
            path2.write_text(source2)
            
            output_path = Path(tmpdir) / "graph.html"
            
            result = main([str(path1), str(path2), '-o', str(output_path)])
            
            assert result == 0
            assert output_path.exists()
            
            content = output_path.read_text()
            assert 'func_a' in content
            assert 'func_b' in content
    
    def test_cli_directory(self):
        """Test CLI with a directory."""
        source = '''
def process():
    pass
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create subdirectory with source
            subdir = Path(tmpdir) / "src"
            subdir.mkdir()
            (subdir / "module.py").write_text(source)
            
            output_path = Path(tmpdir) / "graph.html"
            
            result = main([str(subdir), '-o', str(output_path)])
            
            assert result == 0
            assert output_path.exists()
    
    def test_cli_custom_title(self):
        """Test CLI with custom title."""
        source = '''
def main():
    pass
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            source_path = Path(tmpdir) / "test.py"
            source_path.write_text(source)
            output_path = Path(tmpdir) / "graph.html"
            
            result = main([
                str(source_path),
                '-o', str(output_path),
                '--title', 'My Custom Title'
            ])
            
            assert result == 0
            
            content = output_path.read_text()
            assert 'My Custom Title' in content
    
    def test_cli_verbose(self, capsys):
        """Test CLI with verbose output."""
        source = '''
def main():
    helper()

def helper():
    pass
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            source_path = Path(tmpdir) / "test.py"
            source_path.write_text(source)
            output_path = Path(tmpdir) / "graph.html"
            
            result = main([
                str(source_path),
                '-o', str(output_path),
                '-v'
            ])
            
            assert result == 0
            
            captured = capsys.readouterr()
            assert 'Parsing' in captured.out
            assert 'Nodes' in captured.out
    
    def test_cli_nonexistent_path(self, capsys):
        """Test CLI with nonexistent path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "graph.html"
            
            result = main([
                '/nonexistent/path.py',
                '-o', str(output_path)
            ])
            
            assert result == 1
            
            captured = capsys.readouterr()
            assert 'Error' in captured.err or 'not found' in captured.err
    
    def test_cli_include_builtins(self):
        """Test CLI with --include-builtins."""
        source = '''
def main():
    print("Hello")
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            source_path = Path(tmpdir) / "test.py"
            source_path.write_text(source)
            output_path = Path(tmpdir) / "graph.html"
            
            result = main([
                str(source_path),
                '-o', str(output_path),
                '--include-builtins'
            ])
            
            assert result == 0
    
    def test_cli_no_labels(self):
        """Test CLI with --no-labels."""
        source = '''
def main():
    pass
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            source_path = Path(tmpdir) / "test.py"
            source_path.write_text(source)
            output_path = Path(tmpdir) / "graph.html"
            
            result = main([
                str(source_path),
                '-o', str(output_path),
                '--no-labels'
            ])
            
            assert result == 0
            
            content = output_path.read_text()
            assert '"show_labels": false' in content
    
    def test_cli_color_by_type(self):
        """Test CLI with --color-by-type."""
        source = '''
def main():
    pass
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            source_path = Path(tmpdir) / "test.py"
            source_path.write_text(source)
            output_path = Path(tmpdir) / "graph.html"
            
            result = main([
                str(source_path),
                '-o', str(output_path),
                '--color-by-type'
            ])
            
            assert result == 0
            
            content = output_path.read_text()
            assert '"color_by_type": true' in content
    
    def test_cli_empty_result(self, capsys):
        """Test CLI when no functions are found."""
        source = '''
# Just a comment, no functions
x = 42
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            source_path = Path(tmpdir) / "test.py"
            source_path.write_text(source)
            output_path = Path(tmpdir) / "graph.html"
            
            result = main([
                str(source_path),
                '-o', str(output_path)
            ])
            
            assert result == 1
            
            captured = capsys.readouterr()
            assert 'No functions found' in captured.err or 'Warning' in captured.err
