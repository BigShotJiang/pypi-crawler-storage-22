"""Tests for the graph data structures."""

import pytest
from callgraph_viz.graph import CallGraph, FunctionNode, CallEdge, NodeType


class TestFunctionNode:
    """Tests for FunctionNode."""
    
    def test_create_function_node(self):
        """Test creating a basic function node."""
        node = FunctionNode(
            id="module.func",
            name="func",
            qualified_name="module.func",
        )
        assert node.id == "module.func"
        assert node.name == "func"
        assert node.node_type == NodeType.FUNCTION
    
    def test_function_node_with_metadata(self):
        """Test creating a function node with full metadata."""
        node = FunctionNode(
            id="module.Class.method",
            name="method",
            qualified_name="module.Class.method",
            file_path="/path/to/file.py",
            line_number=42,
            end_line=50,
            node_type=NodeType.METHOD,
            class_name="Class",
            module_name="module",
            docstring="A method that does something.",
            is_async=True,
            is_generator=False,
            parameters=["self", "arg1", "arg2"],
        )
        assert node.class_name == "Class"
        assert node.is_async is True
        assert len(node.parameters) == 3
    
    def test_function_node_to_dict(self):
        """Test converting a function node to dictionary."""
        node = FunctionNode(
            id="module.func",
            name="func",
            qualified_name="module.func",
            line_number=10,
        )
        d = node.to_dict()
        assert d["id"] == "module.func"
        assert d["name"] == "func"
        assert d["line_number"] == 10
        assert d["node_type"] == "function"


class TestCallEdge:
    """Tests for CallEdge."""
    
    def test_create_call_edge(self):
        """Test creating a basic call edge."""
        edge = CallEdge(
            caller_id="module.caller",
            callee_id="module.callee",
        )
        assert edge.caller_id == "module.caller"
        assert edge.callee_id == "module.callee"
        assert edge.call_count == 1
    
    def test_call_edge_with_context(self):
        """Test creating a call edge with context information."""
        edge = CallEdge(
            caller_id="module.caller",
            callee_id="module.callee",
            call_count=3,
            line_numbers=[10, 15, 20],
            is_conditional=True,
            is_loop=True,
        )
        assert edge.call_count == 3
        assert len(edge.line_numbers) == 3
        assert edge.is_conditional is True
        assert edge.is_loop is True
    
    def test_call_edge_to_dict(self):
        """Test converting a call edge to dictionary."""
        edge = CallEdge(
            caller_id="module.caller",
            callee_id="module.callee",
            call_count=2,
        )
        d = edge.to_dict()
        assert d["source"] == "module.caller"
        assert d["target"] == "module.callee"
        assert d["call_count"] == 2


class TestCallGraph:
    """Tests for CallGraph."""
    
    def test_create_empty_graph(self):
        """Test creating an empty call graph."""
        graph = CallGraph()
        assert len(graph) == 0
        assert len(graph.edges) == 0
    
    def test_add_node(self):
        """Test adding a node to the graph."""
        graph = CallGraph()
        node = FunctionNode(
            id="module.func",
            name="func",
            qualified_name="module.func",
        )
        graph.add_node(node)
        assert len(graph) == 1
        assert graph.get_node("module.func") == node
    
    def test_add_edge(self):
        """Test adding an edge to the graph."""
        graph = CallGraph()
        
        # Add nodes
        graph.add_node(FunctionNode(id="a", name="a", qualified_name="a"))
        graph.add_node(FunctionNode(id="b", name="b", qualified_name="b"))
        
        # Add edge
        graph.add_edge("a", "b", line_number=10)
        
        assert len(graph.edges) == 1
        edge = graph.get_edge("a", "b")
        assert edge is not None
        assert edge.caller_id == "a"
        assert edge.callee_id == "b"
    
    def test_add_duplicate_edge_increments_count(self):
        """Test that adding duplicate edges increments the call count."""
        graph = CallGraph()
        
        graph.add_node(FunctionNode(id="a", name="a", qualified_name="a"))
        graph.add_node(FunctionNode(id="b", name="b", qualified_name="b"))
        
        graph.add_edge("a", "b", line_number=10)
        graph.add_edge("a", "b", line_number=15)
        graph.add_edge("a", "b", line_number=20)
        
        assert len(graph.edges) == 1
        edge = graph.get_edge("a", "b")
        assert edge.call_count == 3
        assert edge.line_numbers == [10, 15, 20]
    
    def test_get_callers(self):
        """Test getting callers of a function."""
        graph = CallGraph()
        
        graph.add_node(FunctionNode(id="a", name="a", qualified_name="a"))
        graph.add_node(FunctionNode(id="b", name="b", qualified_name="b"))
        graph.add_node(FunctionNode(id="c", name="c", qualified_name="c"))
        
        graph.add_edge("a", "c")
        graph.add_edge("b", "c")
        
        callers = graph.get_callers("c")
        assert callers == {"a", "b"}
    
    def test_get_callees(self):
        """Test getting callees of a function."""
        graph = CallGraph()
        
        graph.add_node(FunctionNode(id="a", name="a", qualified_name="a"))
        graph.add_node(FunctionNode(id="b", name="b", qualified_name="b"))
        graph.add_node(FunctionNode(id="c", name="c", qualified_name="c"))
        
        graph.add_edge("a", "b")
        graph.add_edge("a", "c")
        
        callees = graph.get_callees("a")
        assert callees == {"b", "c"}
    
    def test_find_recursive_calls(self):
        """Test finding recursive function calls."""
        graph = CallGraph()
        
        graph.add_node(FunctionNode(id="a", name="a", qualified_name="a"))
        graph.add_node(FunctionNode(id="b", name="b", qualified_name="b"))
        
        graph.add_edge("a", "a")  # Self-recursion
        graph.add_edge("a", "b")
        
        recursive = graph.find_recursive_calls()
        assert "a" in recursive
        assert "b" not in recursive
    
    def test_find_entry_points(self):
        """Test finding entry points (functions with no callers)."""
        graph = CallGraph()
        
        graph.add_node(FunctionNode(id="main", name="main", qualified_name="main"))
        graph.add_node(FunctionNode(id="helper", name="helper", qualified_name="helper"))
        
        graph.add_edge("main", "helper")
        
        entry_points = graph.find_entry_points()
        assert "main" in entry_points
        assert "helper" not in entry_points
    
    def test_find_leaf_nodes(self):
        """Test finding leaf nodes (functions that don't call others)."""
        graph = CallGraph()
        
        graph.add_node(FunctionNode(id="main", name="main", qualified_name="main"))
        graph.add_node(FunctionNode(id="helper", name="helper", qualified_name="helper"))
        
        graph.add_edge("main", "helper")
        
        leaf_nodes = graph.find_leaf_nodes()
        assert "helper" in leaf_nodes
        assert "main" not in leaf_nodes
    
    def test_get_depth(self):
        """Test calculating call depth."""
        graph = CallGraph()
        
        graph.add_node(FunctionNode(id="a", name="a", qualified_name="a"))
        graph.add_node(FunctionNode(id="b", name="b", qualified_name="b"))
        graph.add_node(FunctionNode(id="c", name="c", qualified_name="c"))
        
        graph.add_edge("a", "b")
        graph.add_edge("b", "c")
        
        assert graph.get_depth("a") == 2
        assert graph.get_depth("b") == 1
        assert graph.get_depth("c") == 0
    
    def test_to_dict(self):
        """Test converting graph to dictionary."""
        graph = CallGraph()
        
        graph.add_node(FunctionNode(id="a", name="a", qualified_name="a"))
        graph.add_node(FunctionNode(id="b", name="b", qualified_name="b"))
        graph.add_edge("a", "b")
        
        d = graph.to_dict()
        assert len(d["nodes"]) == 2
        assert len(d["edges"]) == 1
        assert "stats" in d
    
    def test_merge_graphs(self):
        """Test merging two graphs."""
        graph1 = CallGraph()
        graph1.add_node(FunctionNode(id="a", name="a", qualified_name="a"))
        graph1.add_node(FunctionNode(id="b", name="b", qualified_name="b"))
        graph1.add_edge("a", "b")
        
        graph2 = CallGraph()
        graph2.add_node(FunctionNode(id="b", name="b", qualified_name="b"))
        graph2.add_node(FunctionNode(id="c", name="c", qualified_name="c"))
        graph2.add_edge("b", "c")
        
        graph1.merge(graph2)
        
        assert len(graph1) == 3
        assert len(graph1.edges) == 2
        assert graph1.get_edge("a", "b") is not None
        assert graph1.get_edge("b", "c") is not None
    
    def test_filter_by_module(self):
        """Test filtering graph by module."""
        graph = CallGraph()
        
        graph.add_node(FunctionNode(id="mod1.a", name="a", qualified_name="mod1.a", module_name="mod1"))
        graph.add_node(FunctionNode(id="mod1.b", name="b", qualified_name="mod1.b", module_name="mod1"))
        graph.add_node(FunctionNode(id="mod2.c", name="c", qualified_name="mod2.c", module_name="mod2"))
        
        graph.add_edge("mod1.a", "mod1.b")
        graph.add_edge("mod1.a", "mod2.c")
        
        filtered = graph.filter_by_module("mod1")
        
        assert len(filtered) == 2
        assert len(filtered.edges) == 1
        assert filtered.get_edge("mod1.a", "mod1.b") is not None
