"""Tests for the Python parser."""

import pytest
from callgraph_viz.python_parser import PythonParser
from callgraph_viz.graph import NodeType


class TestPythonParser:
    """Tests for PythonParser."""
    
    @pytest.fixture
    def parser(self):
        """Create a parser instance."""
        return PythonParser()
    
    def test_parse_simple_function(self, parser):
        """Test parsing a simple function definition."""
        source = '''
def hello():
    print("Hello")
'''
        graph = parser.parse_source(source)
        
        assert len(graph.nodes) == 1
        node = list(graph.nodes.values())[0]
        assert node.name == "hello"
        assert node.node_type == NodeType.FUNCTION
    
    def test_parse_function_with_args(self, parser):
        """Test parsing a function with arguments."""
        source = '''
def greet(name, greeting="Hello"):
    return f"{greeting}, {name}!"
'''
        graph = parser.parse_source(source)
        
        node = list(graph.nodes.values())[0]
        assert "name" in node.parameters
        assert "greeting" in node.parameters
    
    def test_parse_class_with_methods(self, parser):
        """Test parsing a class with methods."""
        source = '''
class Calculator:
    def __init__(self, value=0):
        self.value = value
    
    def add(self, x):
        self.value += x
        return self
    
    def get_value(self):
        return self.value
'''
        graph = parser.parse_source(source)
        
        # Should have class + 3 methods
        assert len(graph.nodes) == 4
        
        # Check class node
        class_node = graph.get_node("module.Calculator")
        assert class_node is not None
        assert class_node.node_type == NodeType.CLASS
        
        # Check method nodes
        init_node = graph.get_node("module.Calculator.__init__")
        assert init_node is not None
        assert init_node.node_type == NodeType.METHOD
        assert init_node.class_name == "Calculator"
    
    def test_parse_function_calls(self, parser):
        """Test parsing function calls."""
        source = '''
def helper():
    pass

def main():
    helper()
    helper()
'''
        graph = parser.parse_source(source)
        
        edge = graph.get_edge("module.main", "module.helper")
        assert edge is not None
        assert edge.call_count == 2
    
    def test_parse_method_calls(self, parser):
        """Test parsing method calls within a class."""
        source = '''
class MyClass:
    def method_a(self):
        self.method_b()
    
    def method_b(self):
        pass
'''
        graph = parser.parse_source(source)
        
        # Check edge from method_a to method_b
        edge = graph.get_edge("module.MyClass.method_a", "module.MyClass.method_b")
        assert edge is not None
    
    def test_parse_async_function(self, parser):
        """Test parsing async functions."""
        source = '''
async def fetch_data():
    return await get_response()

async def get_response():
    pass
'''
        graph = parser.parse_source(source)
        
        fetch_node = graph.get_node("module.fetch_data")
        assert fetch_node is not None
        assert fetch_node.is_async is True
    
    def test_parse_generator_function(self, parser):
        """Test parsing generator functions."""
        source = '''
def count_up(n):
    for i in range(n):
        yield i
'''
        graph = parser.parse_source(source)
        
        node = graph.get_node("module.count_up")
        assert node is not None
        assert node.is_generator is True
    
    def test_parse_nested_functions(self, parser):
        """Test parsing nested function definitions."""
        source = '''
def outer():
    def inner():
        pass
    inner()
'''
        graph = parser.parse_source(source)
        
        outer_node = graph.get_node("module.outer")
        inner_node = graph.get_node("module.outer.inner")
        
        assert outer_node is not None
        assert inner_node is not None
    
    def test_parse_imports(self, parser):
        """Test tracking imports."""
        source = '''
import os
from pathlib import Path

def process():
    os.getcwd()
    Path(".")
'''
        graph = parser.parse_source(source)
        
        # Should create edges to imported functions
        assert len(graph.edges) >= 1
    
    def test_parse_conditional_calls(self, parser):
        """Test detecting calls inside conditionals."""
        source = '''
def check():
    pass

def main():
    if True:
        check()
'''
        graph = parser.parse_source(source)
        
        edge = graph.get_edge("module.main", "module.check")
        assert edge is not None
        assert edge.is_conditional is True
    
    def test_parse_loop_calls(self, parser):
        """Test detecting calls inside loops."""
        source = '''
def process():
    pass

def main():
    for i in range(10):
        process()
'''
        graph = parser.parse_source(source)
        
        edge = graph.get_edge("module.main", "module.process")
        assert edge is not None
        assert edge.is_loop is True
    
    def test_exclude_builtins_by_default(self, parser):
        """Test that built-in calls are excluded by default."""
        source = '''
def main():
    print("Hello")
    len([1, 2, 3])
'''
        graph = parser.parse_source(source)
        
        # Should not have edges to print or len
        assert len(graph.edges) == 0
    
    def test_include_builtins(self):
        """Test including built-in calls."""
        parser = PythonParser(include_builtins=True)
        source = '''
def main():
    print("Hello")
'''
        graph = parser.parse_source(source)
        
        # Should have edge to print
        assert len(graph.edges) >= 1
    
    def test_parse_recursive_function(self, parser):
        """Test parsing recursive function calls."""
        source = '''
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)
'''
        graph = parser.parse_source(source)
        
        edge = graph.get_edge("module.factorial", "module.factorial")
        assert edge is not None
        
        recursive = graph.find_recursive_calls()
        assert "module.factorial" in recursive
    
    def test_parse_lambda_not_tracked(self, parser):
        """Test that lambdas are not tracked as named functions."""
        source = '''
def main():
    f = lambda x: x * 2
    return f(5)
'''
        graph = parser.parse_source(source)
        
        # Only main should be tracked
        assert len(graph.nodes) == 1
        assert "module.main" in graph.nodes
    
    def test_parse_docstrings(self, parser):
        """Test extracting docstrings."""
        source = '''
def documented():
    """This is a documented function."""
    pass
'''
        graph = parser.parse_source(source)
        
        node = graph.get_node("module.documented")
        assert node is not None
        assert node.docstring == "This is a documented function."
    
    def test_parse_multiline_function(self, parser):
        """Test parsing functions with multiple lines."""
        source = '''
def complex_function(a, b, c):
    """Does something complex."""
    result = a + b
    if result > 0:
        helper(result)
    for i in range(c):
        another_helper(i)
    return result

def helper(x):
    pass

def another_helper(y):
    pass
'''
        graph = parser.parse_source(source)
        
        assert len(graph.nodes) == 3
        
        # Check edges from complex_function
        assert graph.get_edge("module.complex_function", "module.helper") is not None
        assert graph.get_edge("module.complex_function", "module.another_helper") is not None
    
    def test_parse_syntax_error(self, parser):
        """Test handling syntax errors."""
        source = '''
def broken(
    # Missing closing paren
'''
        with pytest.raises(ValueError):
            parser.parse_source(source)
    
    def test_line_numbers(self, parser):
        """Test that line numbers are captured correctly."""
        source = '''
def first():
    pass

def second():
    pass
'''
        graph = parser.parse_source(source)
        
        first_node = graph.get_node("module.first")
        second_node = graph.get_node("module.second")
        
        assert first_node.line_number == 2
        assert second_node.line_number == 5
