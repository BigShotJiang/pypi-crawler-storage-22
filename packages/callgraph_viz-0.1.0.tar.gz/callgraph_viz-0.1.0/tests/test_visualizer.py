"""Tests for the visualizer."""

import pytest
import tempfile
import os
from pathlib import Path

from callgraph_viz.visualizer import CallGraphVisualizer, VisualizationConfig
from callgraph_viz.graph import CallGraph, FunctionNode, NodeType


class TestVisualizationConfig:
    """Tests for VisualizationConfig."""
    
    def test_default_config(self):
        """Test default configuration values."""
        config = VisualizationConfig()
        
        assert config.title == "Call Graph"
        assert config.width == 1200
        assert config.height == 800
        assert config.show_labels is True
        assert config.enable_zoom is True
        assert config.enable_search is True
    
    def test_custom_config(self):
        """Test custom configuration values."""
        config = VisualizationConfig(
            title="My Project",
            width=1600,
            height=900,
            show_labels=False,
            link_distance=150,
        )
        
        assert config.title == "My Project"
        assert config.width == 1600
        assert config.show_labels is False
        assert config.link_distance == 150


class TestCallGraphVisualizer:
    """Tests for CallGraphVisualizer."""
    
    @pytest.fixture
    def sample_graph(self):
        """Create a sample call graph for testing."""
        graph = CallGraph()
        
        # Add nodes
        graph.add_node(FunctionNode(
            id="module.main",
            name="main",
            qualified_name="module.main",
            file_path="module.py",
            line_number=10,
            node_type=NodeType.FUNCTION,
            module_name="module",
        ))
        
        graph.add_node(FunctionNode(
            id="module.helper",
            name="helper",
            qualified_name="module.helper",
            file_path="module.py",
            line_number=20,
            node_type=NodeType.FUNCTION,
            module_name="module",
        ))
        
        graph.add_node(FunctionNode(
            id="module.Calculator",
            name="Calculator",
            qualified_name="module.Calculator",
            file_path="module.py",
            line_number=30,
            node_type=NodeType.CLASS,
            module_name="module",
        ))
        
        graph.add_node(FunctionNode(
            id="module.Calculator.add",
            name="add",
            qualified_name="module.Calculator.add",
            file_path="module.py",
            line_number=35,
            node_type=NodeType.METHOD,
            class_name="Calculator",
            module_name="module",
        ))
        
        # Add edges
        graph.add_edge("module.main", "module.helper", line_number=12)
        graph.add_edge("module.main", "module.Calculator.add", line_number=14)
        graph.add_edge("module.helper", "module.helper", line_number=22)  # Recursive
        
        return graph
    
    def test_generate_html_string(self, sample_graph):
        """Test generating HTML as a string."""
        visualizer = CallGraphVisualizer()
        html = visualizer.generate_html(sample_graph)
        
        assert isinstance(html, str)
        assert "<!DOCTYPE html>" in html
        assert "<title>Call Graph</title>" in html
        assert "d3.js" in html or "d3.v7" in html
        assert "module.main" in html
        assert "module.helper" in html
    
    def test_generate_html_with_custom_title(self, sample_graph):
        """Test generating HTML with custom title."""
        config = VisualizationConfig(title="Test Project Graph")
        visualizer = CallGraphVisualizer(config)
        html = visualizer.generate_html(sample_graph)
        
        assert "Test Project Graph" in html
    
    def test_generate_html_to_file(self, sample_graph):
        """Test generating HTML to a file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "graph.html"
            
            visualizer = CallGraphVisualizer()
            html = visualizer.generate_html(sample_graph, output_path)
            
            assert output_path.exists()
            
            content = output_path.read_text()
            assert content == html
            assert "<!DOCTYPE html>" in content
    
    def test_html_contains_graph_data(self, sample_graph):
        """Test that HTML contains the graph data as JSON."""
        visualizer = CallGraphVisualizer()
        html = visualizer.generate_html(sample_graph)
        
        # Should contain node data
        assert '"id": "module.main"' in html
        assert '"name": "helper"' in html
        
        # Should contain edge data
        assert '"source": "module.main"' in html
        assert '"target": "module.helper"' in html
    
    def test_html_contains_stats(self, sample_graph):
        """Test that HTML contains statistics."""
        visualizer = CallGraphVisualizer()
        html = visualizer.generate_html(sample_graph)
        
        # Stats section should be in HTML
        assert "Statistics" in html
        assert "stat-nodes" in html
        assert "stat-edges" in html
    
    def test_html_contains_search(self, sample_graph):
        """Test that HTML contains search functionality."""
        visualizer = CallGraphVisualizer()
        html = visualizer.generate_html(sample_graph)
        
        assert 'id="search"' in html
        assert "Search functions" in html
    
    def test_html_contains_controls(self, sample_graph):
        """Test that HTML contains control buttons."""
        visualizer = CallGraphVisualizer()
        html = visualizer.generate_html(sample_graph)
        
        assert "Reset View" in html
        assert "Center" in html
    
    def test_html_contains_legend(self, sample_graph):
        """Test that HTML contains legend."""
        visualizer = CallGraphVisualizer()
        html = visualizer.generate_html(sample_graph)
        
        assert "Node Types" in html
        assert "Function" in html
        assert "Method" in html
        assert "Class" in html
    
    def test_empty_graph(self):
        """Test generating HTML for an empty graph."""
        graph = CallGraph()
        visualizer = CallGraphVisualizer()
        
        html = visualizer.generate_html(graph)
        
        assert isinstance(html, str)
        assert "<!DOCTYPE html>" in html
        # Should have empty nodes array
        assert '"nodes": []' in html
    
    def test_config_affects_output(self, sample_graph):
        """Test that configuration affects the output."""
        config = VisualizationConfig(
            link_distance=200,
            charge_strength=-500,
            color_by_file=False,
            color_by_type=True,
        )
        visualizer = CallGraphVisualizer(config)
        html = visualizer.generate_html(sample_graph)
        
        assert '"link_distance": 200' in html
        assert '"charge_strength": -500' in html
        assert '"color_by_file": false' in html
        assert '"color_by_type": true' in html
    
    def test_html_is_self_contained(self, sample_graph):
        """Test that HTML is self-contained (no local file references)."""
        visualizer = CallGraphVisualizer()
        html = visualizer.generate_html(sample_graph)
        
        # Should use CDN for D3.js
        assert "https://" in html
        # Should have inline styles
        assert "<style>" in html
        # Should have inline script
        assert "<script>" in html


class TestVisualizerIntegration:
    """Integration tests for the visualizer with parser."""
    
    def test_visualize_python_file(self):
        """Test visualizing a Python file."""
        source = '''
def main():
    helper()

def helper():
    pass
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            # Write source file
            source_path = Path(tmpdir) / "test.py"
            source_path.write_text(source)
            
            # Generate visualization
            output_path = Path(tmpdir) / "graph.html"
            visualizer = CallGraphVisualizer()
            html = visualizer.generate_from_file(source_path, output_path)
            
            assert output_path.exists()
            assert "main" in html
            assert "helper" in html
    
    def test_visualize_directory(self):
        """Test visualizing a directory of files."""
        source1 = '''
def func_a():
    pass
'''
        source2 = '''
def func_b():
    pass
'''
        with tempfile.TemporaryDirectory() as tmpdir:
            # Write source files
            (Path(tmpdir) / "file1.py").write_text(source1)
            (Path(tmpdir) / "file2.py").write_text(source2)
            
            # Generate visualization
            output_path = Path(tmpdir) / "graph.html"
            visualizer = CallGraphVisualizer()
            html = visualizer.generate_from_directory(tmpdir, output_path)
            
            assert output_path.exists()
            assert "func_a" in html
            assert "func_b" in html
