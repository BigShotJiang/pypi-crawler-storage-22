# callguard — DEPRECATED

**This package has been renamed to [edictum](https://pypi.org/project/edictum/).**

```bash
pip install edictum
```

All future development continues under the `edictum` name. This package exists only to redirect existing users.
