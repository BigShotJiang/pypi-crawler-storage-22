import warnings

warnings.warn(
    "callguard has been renamed to edictum. "
    "Install it with: pip install edictum",
    DeprecationWarning,
    stacklevel=2,
)
