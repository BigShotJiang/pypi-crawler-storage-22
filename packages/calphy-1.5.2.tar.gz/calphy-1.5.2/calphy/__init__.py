from calphy.input import Calculation
from calphy.liquid import Liquid
from calphy.solid import Solid
from calphy.alchemy import Alchemy
from calphy.routines import MeltingTemp

__version__ = "1.5.2"

def addtest(a,b):
    return a+b
