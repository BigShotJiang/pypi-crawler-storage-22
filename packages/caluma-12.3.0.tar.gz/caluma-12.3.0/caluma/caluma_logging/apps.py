from django.apps import AppConfig


class DefaultConfig(AppConfig):
    name = "caluma.caluma_logging"
