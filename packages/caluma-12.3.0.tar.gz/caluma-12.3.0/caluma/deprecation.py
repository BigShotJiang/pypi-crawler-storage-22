class CalumaDeprecationWarning(DeprecationWarning):
    pass
