class Cambo:
    def __init__(self):
        self.routes = {}

    def page(self, path):
        def wrapper(func):
            self.routes[path] = func
            return func
        return wrapper

    def run(self, host='127.0.0.1', port=8000):
        from http.server import BaseHTTPRequestHandler, HTTPServer

        class RequestHandler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path in self.server.app.routes:
                    response = self.server.app.routes[self.path]()
                    self.send_response(200)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    self.wfile.write(response.encode())
                else:
                    self.send_response(404)
                    self.end_headers()

        server = HTTPServer((host, port), RequestHandler)
        server.app = self
        print(f'Running on http://{host}:{port}')
        server.serve_forever()

