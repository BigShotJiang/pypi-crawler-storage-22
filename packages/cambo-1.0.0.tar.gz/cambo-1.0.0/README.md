An Web Development Framework Called "Cambo".
## Installation
```bash
pip install Cambo
```
## Usage
```python
import Cambo

cambo = Cambo.Cambo()

@cambo.page('/')
def main():
    return 'Welcome to Cambo!'

@cambo.page('/about')
def about():
    return 'This is a simple framework called Cambo.'

if __name__ == "__main__":
    cambo.run()
```
## Output
```
Running on http://127.0.0.1:8000
```
