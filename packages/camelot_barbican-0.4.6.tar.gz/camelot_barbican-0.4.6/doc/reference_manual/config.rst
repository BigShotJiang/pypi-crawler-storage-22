*********************
Project configuration
*********************
