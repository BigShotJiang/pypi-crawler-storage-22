**************************
Packages source management
**************************
