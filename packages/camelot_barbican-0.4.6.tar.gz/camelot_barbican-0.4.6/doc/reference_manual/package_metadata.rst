****************
Package metadata
****************
