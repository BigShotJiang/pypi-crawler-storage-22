"""unit tests for CI pipeline"""

import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import numpy as np

from camp2ascii import camp2ascii as c2a

class TestCamp2Ascii(unittest.TestCase):
    def test_compare_to_cardconvert_simple(self):

        tob3_file_names = sorted(f.name for f in Path("tests/tob3").glob("*30Min*.dat"))

        tob3_files = [Path(f"tests/tob3/{name}") for name in tob3_file_names]
        toa5_cc_file_names = [Path(f"tests/toa5-cc/TOA5_{name}") for name in tob3_file_names]
        toa5_c2a_dir = Path("tests/toa5-c2a")

        out_files = c2a(tob3_files, toa5_c2a_dir)

        c2a_data = pd.concat([pd.read_csv(f, skiprows=[0, 2, 3], parse_dates=["TIMESTAMP"], index_col="TIMESTAMP") for f in out_files]).sort_index()
        
        cc_data = pd.concat([pd.read_csv(f, skiprows=[0, 2, 3]) for f in toa5_cc_file_names])
        cc_data["TIMESTAMP"] = pd.to_datetime(cc_data["TIMESTAMP"], format="ISO8601")
        cc_data = cc_data.set_index("TIMESTAMP").sort_index()

        self.assertTrue(c2a_data.index.equals(cc_data.index), "Timestamps do not match")
        self.assertTrue(np.isclose(c2a_data.values, cc_data.values).all(), "Data values do not match")

if __name__ == "__main__":
    unittest.main()