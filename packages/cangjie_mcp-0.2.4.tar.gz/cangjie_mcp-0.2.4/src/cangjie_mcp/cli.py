"""CLI for Cangjie MCP server.

All CLI options can be configured via environment variables.
Run `cangjie-mcp --help` to see all options and their environment variables.

Environment variable naming:
- CANGJIE_* prefix for most options
- OPENAI_* prefix for OpenAI-related options
"""

from pathlib import Path
from typing import Annotated

import typer

from cangjie_mcp import __version__
from cangjie_mcp.cli_args import (
    ChunkSizeOption,
    DataDirOption,
    DebugOption,
    DocsVersionOption,
    EmbeddingOption,
    LangOption,
    LocalModelOption,
    LogFileOption,
    OpenAIApiKeyOption,
    OpenAIBaseUrlOption,
    OpenAIModelOption,
    PrebuiltUrlOption,
    RerankInitialKOption,
    RerankModelOption,
    RerankOption,
    RerankTopKOption,
    validate_embedding_type,
    validate_lang,
    validate_rerank_type,
)
from cangjie_mcp.config import Settings, set_settings
from cangjie_mcp.defaults import (
    DEFAULT_CHUNK_MAX_SIZE,
    DEFAULT_DOCS_LANG,
    DEFAULT_DOCS_VERSION,
    DEFAULT_EMBEDDING_TYPE,
    DEFAULT_LOCAL_MODEL,
    DEFAULT_OPENAI_BASE_URL,
    DEFAULT_OPENAI_MODEL,
    DEFAULT_RERANK_INITIAL_K,
    DEFAULT_RERANK_MODEL,
    DEFAULT_RERANK_TOP_K,
    DEFAULT_RERANK_TYPE,
    get_default_data_dir,
)
from cangjie_mcp.utils import setup_logging


def _version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        typer.echo(f"cangjie-mcp {__version__}")
        raise typer.Exit()


# Root app
app = typer.Typer(
    name="cangjie-mcp",
    help="MCP server for Cangjie programming language",
    invoke_without_command=True,
)

# Prebuilt index management
prebuilt_app = typer.Typer(help="Prebuilt index management commands")
app.add_typer(prebuilt_app, name="prebuilt")


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    _version: Annotated[
        bool,
        typer.Option(
            "--version",
            "-v",
            help="Show version and exit",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = False,
    # Docs options - using shared type aliases
    docs_version: DocsVersionOption = DEFAULT_DOCS_VERSION,
    lang: LangOption = DEFAULT_DOCS_LANG,
    embedding: EmbeddingOption = DEFAULT_EMBEDDING_TYPE,
    local_model: LocalModelOption = DEFAULT_LOCAL_MODEL,
    openai_api_key: OpenAIApiKeyOption = None,
    openai_base_url: OpenAIBaseUrlOption = DEFAULT_OPENAI_BASE_URL,
    openai_model: OpenAIModelOption = DEFAULT_OPENAI_MODEL,
    rerank: RerankOption = DEFAULT_RERANK_TYPE,
    rerank_model: RerankModelOption = DEFAULT_RERANK_MODEL,
    rerank_top_k: RerankTopKOption = DEFAULT_RERANK_TOP_K,
    rerank_initial_k: RerankInitialKOption = DEFAULT_RERANK_INITIAL_K,
    chunk_max_size: ChunkSizeOption = DEFAULT_CHUNK_MAX_SIZE,
    data_dir: DataDirOption = None,
    prebuilt_url: PrebuiltUrlOption = None,
    log_file: LogFileOption = None,
    debug: DebugOption = False,
) -> None:
    """Start the MCP server."""
    # If a subcommand is invoked, let it handle execution
    if ctx.invoked_subcommand is not None:
        return

    # Set up logging early
    setup_logging(log_file, debug)

    # Validate and build settings
    settings = Settings(
        docs_version=docs_version,
        docs_lang=validate_lang(lang),  # type: ignore[arg-type]
        embedding_type=validate_embedding_type(embedding),  # type: ignore[arg-type]
        local_model=local_model,
        openai_api_key=openai_api_key,
        openai_base_url=openai_base_url,
        openai_model=openai_model,
        rerank_type=validate_rerank_type(rerank),  # type: ignore[arg-type]
        rerank_model=rerank_model,
        rerank_top_k=rerank_top_k,
        rerank_initial_k=rerank_initial_k,
        chunk_max_size=chunk_max_size,
        data_dir=data_dir if data_dir else get_default_data_dir(),
        prebuilt_url=prebuilt_url,
    )
    set_settings(settings)

    # Create and run server
    from cangjie_mcp.server.factory import create_mcp_server

    mcp = create_mcp_server(settings)
    typer.echo("Starting MCP server...")
    mcp.run(transport="stdio")


@prebuilt_app.command("download")
def prebuilt_download(
    url: Annotated[
        str | None,
        typer.Option(
            "--url",
            "-u",
            help="URL to download from",
            envvar="CANGJIE_PREBUILT_URL",
        ),
    ] = None,
    data_dir: Annotated[
        Path | None,
        typer.Option(
            "--data-dir",
            "-d",
            help="Data directory path",
            envvar="CANGJIE_DATA_DIR",
        ),
    ] = None,
) -> None:
    """Download and install a prebuilt index."""
    from cangjie_mcp.prebuilt.manager import PrebuiltManager

    if not url:
        typer.echo("Error: No URL provided. Set CANGJIE_PREBUILT_URL or use --url")
        raise typer.Exit(1)

    actual_data_dir = data_dir or get_default_data_dir()

    mgr = PrebuiltManager(actual_data_dir)
    try:
        archive_path = mgr.download(url)
        mgr.install(archive_path)
    except Exception as e:
        typer.echo(f"Error: Failed to download: {e}")
        raise typer.Exit(1) from None


@prebuilt_app.command("build")
def prebuilt_build(
    version: Annotated[
        str | None,
        typer.Option(
            "--version",
            "-v",
            help="Documentation version (git tag)",
            envvar="CANGJIE_DOCS_VERSION",
        ),
    ] = None,
    lang: Annotated[
        str | None,
        typer.Option(
            "--lang",
            "-l",
            help="Documentation language (zh/en)",
            envvar="CANGJIE_DOCS_LANG",
        ),
    ] = None,
    embedding: Annotated[
        str | None,
        typer.Option(
            "--embedding",
            "-e",
            help="Embedding type (local/openai)",
            envvar="CANGJIE_EMBEDDING_TYPE",
        ),
    ] = None,
    local_model: Annotated[
        str | None,
        typer.Option(
            "--local-model",
            help="Local embedding model name",
            envvar="CANGJIE_LOCAL_MODEL",
        ),
    ] = None,
    openai_api_key: Annotated[
        str | None,
        typer.Option(
            "--openai-api-key",
            help="OpenAI API key",
            envvar="OPENAI_API_KEY",
        ),
    ] = None,
    openai_base_url: Annotated[
        str | None,
        typer.Option(
            "--openai-base-url",
            help="OpenAI API base URL",
            envvar="OPENAI_BASE_URL",
        ),
    ] = None,
    openai_model: Annotated[
        str | None,
        typer.Option(
            "--openai-model",
            help="OpenAI embedding model",
            envvar="OPENAI_EMBEDDING_MODEL",
        ),
    ] = None,
    chunk_size: Annotated[
        int | None,
        typer.Option(
            "--chunk-size",
            "-c",
            help="Max chunk size in characters",
            envvar="CANGJIE_CHUNK_MAX_SIZE",
        ),
    ] = None,
    data_dir: Annotated[
        Path | None,
        typer.Option(
            "--data-dir",
            "-d",
            help="Data directory",
            envvar="CANGJIE_DATA_DIR",
        ),
    ] = None,
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Output directory or file path"),
    ] = None,
) -> None:
    """Build a prebuilt index archive.

    Automatically clones documentation repository and builds the vector index
    before creating the archive.
    """
    from cangjie_mcp.indexer.embeddings import create_embedding_provider
    from cangjie_mcp.indexer.initializer import build_index
    from cangjie_mcp.indexer.store import VectorStore
    from cangjie_mcp.prebuilt.manager import PrebuiltManager

    # Build settings with optional overrides
    defaults = Settings()
    settings = Settings(
        docs_version=version if version else defaults.docs_version,
        docs_lang=validate_lang(lang) if lang else defaults.docs_lang,  # type: ignore[arg-type]
        embedding_type=validate_embedding_type(embedding) if embedding else defaults.embedding_type,  # type: ignore[arg-type]
        local_model=local_model if local_model else defaults.local_model,
        openai_api_key=openai_api_key,
        openai_base_url=openai_base_url if openai_base_url else defaults.openai_base_url,
        openai_model=openai_model if openai_model else defaults.openai_model,
        chunk_max_size=chunk_size if chunk_size else defaults.chunk_max_size,
        data_dir=data_dir if data_dir else defaults.data_dir,
    )
    set_settings(settings)

    typer.echo("Building Prebuilt Index Archive")
    typer.echo(f"  Version: {settings.docs_version}")
    typer.echo(f"  Language: {settings.docs_lang}")
    typer.echo(f"  Embedding: {settings.embedding_type}")
    typer.echo(f"  Chunk size: {settings.chunk_max_size}")
    typer.echo(f"  Data dir: {settings.data_dir}")
    typer.echo()

    # Build the index
    embedding_provider = create_embedding_provider(settings)
    store = VectorStore(
        db_path=settings.chroma_db_dir,
        embedding_provider=embedding_provider,
    )
    build_index(settings, store, embedding_provider)

    # Create archive
    typer.echo("Creating archive...")
    mgr = PrebuiltManager(settings.index_dir)

    try:
        archive_path = mgr.build(
            version=settings.docs_version,
            lang=settings.docs_lang,
            embedding_model=embedding_provider.get_model_name(),
            docs_source_dir=settings.docs_source_dir,
            output_path=output,
        )
        typer.echo(f"Archive built: {archive_path}")
    except Exception as e:
        typer.echo(f"Error: Failed to build archive: {e}")
        raise typer.Exit(1) from None


@prebuilt_app.command("list")
def prebuilt_list(
    data_dir: Annotated[
        Path | None,
        typer.Option(
            "--data-dir",
            "-d",
            help="Data directory path",
            envvar="CANGJIE_DATA_DIR",
        ),
    ] = None,
) -> None:
    """List available prebuilt indexes."""
    from cangjie_mcp.prebuilt.manager import PrebuiltManager

    actual_data_dir = data_dir or get_default_data_dir()
    mgr = PrebuiltManager(actual_data_dir)

    # List local archives
    local = mgr.list_local()

    if not local:
        typer.echo("No local prebuilt indexes found.")
    else:
        typer.echo("Local Prebuilt Indexes")
        typer.echo(f"  {'Version':<12} {'Language':<10} {'Embedding':<20} Path")
        typer.echo(f"  {'-' * 12} {'-' * 10} {'-' * 20} {'-' * 20}")
        for item in local:
            typer.echo(f"  {item.version:<12} {item.lang:<10} {item.embedding_model:<20} {item.path}")

    # Show currently installed index
    installed = mgr.get_installed_metadata()
    if installed:
        typer.echo()
        typer.echo("Currently Installed:")
        typer.echo(f"  Version: {installed.version}")
        typer.echo(f"  Language: {installed.lang}")
        typer.echo(f"  Embedding: {installed.embedding_model}")


if __name__ == "__main__":
    app()
