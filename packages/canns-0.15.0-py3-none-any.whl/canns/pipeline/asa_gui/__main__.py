"""Allow running as python -m canns.pipeline.asa_gui."""

from . import main

if __name__ == "__main__":
    raise SystemExit(main())
