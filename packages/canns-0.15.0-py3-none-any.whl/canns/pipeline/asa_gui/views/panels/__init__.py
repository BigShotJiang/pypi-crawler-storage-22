"""Panel components for ASA GUI."""
