"""Simple test to verify pytest is working."""


def test_pytest_working():
    """Test that pytest is configured correctly."""
    assert True
