import canvas_sak.core
from canvas_sak.commands import *

def main():
    canvas_sak.core.canvas_sak()

if __name__ == "__main__":
    main()
