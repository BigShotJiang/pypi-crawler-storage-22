"""CanViT: Hi-Res Active Vision with Canvas Attention. Coming soon."""
