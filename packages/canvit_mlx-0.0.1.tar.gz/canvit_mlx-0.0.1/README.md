# CanViT-MLX

Hi-Res Active Vision with Canvas Attention (MLX). Coming soon.
