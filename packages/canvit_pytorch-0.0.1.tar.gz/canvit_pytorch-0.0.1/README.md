# CanViT-PyTorch

Hi-Res Active Vision with Canvas Attention (PyTorch). Coming soon.
