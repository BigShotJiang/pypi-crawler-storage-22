# captcha-ocr

Minimal Python package scaffold for a CAPTCHA OCR module.

## Install (editable)

pip install -e .

## Usage

```python
from captcha_ocr import extract_text

text = extract_text("path/to/captcha.png")
print(text)
```

## Notes

This is a stub implementation. Wire in real OCR (e.g., with your chosen engine)
inside `extract_text`.
