from __future__ import annotations
from pathlib import Path
from typing import Union, TYPE_CHECKING

from PIL import Image

if TYPE_CHECKING:
    from PIL.Image import Image as PILImage
else:
    PILImage = None  # type: ignore


def calculate(a: float, b: float, operation: str) -> float:
    """
    Performs basic arithmetic operations.
    
    Args:
        a: First number
        b: Second number
        operation: One of '+', '-', '*', '/'
    
    Returns:
        Result of the calculation
    """
    if operation == '+':
        return a + b
    elif operation == '-':
        return a - b
    elif operation == '*':
        return a * b
    elif operation == '/':
        if b == 0:
            raise ValueError("Division by zero")
        return a / b
    else:
        raise ValueError(f"Unknown operation: {operation}")


def extract_text(image: Union[str, Path, "PILImage", bytes]) -> str:
    """
    Minimal placeholder OCR entrypoint.

    Accepts a file path, PIL Image, or bytes and returns a string.
    Replace with a real OCR implementation when ready.
    """
    if image is None:
        raise ValueError("image is required")

    if isinstance(image, (str, Path)):
        if Image is None:
            return ""
        try:
            with Image.open(image) as img:
                img.load()
        except Exception:
            return ""

    return ""
