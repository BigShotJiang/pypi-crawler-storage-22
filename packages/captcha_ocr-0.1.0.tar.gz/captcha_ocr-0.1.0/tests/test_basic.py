from captcha_ocr import extract_text


def test_extract_text_returns_str():
    assert isinstance(extract_text(b"fake-image-bytes"), str)
