from .anticaptcha import AntiCaptchaProvider
from .twocaptcha import TwoCaptchaProvider

__all__ = ["AntiCaptchaProvider", "TwoCaptchaProvider"]
