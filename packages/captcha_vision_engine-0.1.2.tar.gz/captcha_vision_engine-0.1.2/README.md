# captcha-solver

OCR-based Python library to solve two common image CAPTCHA styles. Ready for **PyPI**.

Requires **Tesseract OCR** installed on your system (not only the `pytesseract` pip package).

---

## CAPTCHA types this library solves

### 1. Image CAPTCHA — `solveImageCaptcha`

Clear character row (e.g. 6 characters).

![Noisy CAPTCHA example](https://raw.githubusercontent.com/Rahulkatoch99/CaptchaSolver/main/examples/noisy_example.png)



### 2. Noisy CAPTCHA  — `solveImageNoiseCaptcha`

Heavy background noise, diagonal lines, and speckles. Use when the text is obscured but still readable.
 Uses segmentation + per-character OCR. Returns one result or 25 candidate results to try until the form accepts one.

![Grid CAPTCHA example](https://raw.githubusercontent.com/Rahulkatoch99/CaptchaSolver/main/examples/grid_example.png)

---

## Install

```bash
pip install captcha-solver
```

**System dependency:** Install Tesseract OCR.

| Platform   | Command |
|-----------|---------|
| Ubuntu/Debian | `sudo apt-get install tesseract-ocr` |
| macOS     | `brew install tesseract` |
| Windows   | [Tesseract at UB Mannheim](https://github.com/UB-Mannheim/tesseract/wiki) — then set `TESSERACT_CMD` to the executable path if needed. |

---

## Usage

### Class-based API

```python
from captcha_solver import CaptchaSolver

solver = CaptchaSolver()

# Image CAPTCHA → one result
text = solver.solveImageCaptcha("path/to/Image.png")

# Noise CAPTCHA → one result (optional: num_chars, uppercase)
text = solver.solveImageNoiseCaptcha("path/to/noisy_captcha.png")

# Grid CAPTCHA → 25 candidate results (try each until form accepts)
results = solver.solve_grid_five_results("path/to/grid_captcha.png")
for i, r in enumerate(results, 1):
    print(f"{i}: {r}")
```



### Optional: Tesseract path (e.g. Windows)

```python
import os
os.environ["TESSERACT_CMD"] = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

from captcha_solver import CaptchaSolver
solver = CaptchaSolver()
# ... use as above
```

---

## Grid solver options

| Parameter   | Type  | Default | Description |
|------------|-------|---------|-------------|
| `num_chars` | `int \| None` | `5` | Expected number of characters; result is trimmed/padded to this length. |
| `uppercase` | `bool` | `True` | If `True`, return uppercase; if `False`, return lowercase. |

---


---

## Development

```bash
git clone https://github.com/Rahulkatoch99/CaptchaSolver
cd captcha-solver
pip install -e ".[dev]"
```

---

## License

MIT.
