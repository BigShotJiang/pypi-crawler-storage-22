"""
captcha_solver: OCR-based solvers for CAPTCHA images.

- solveImageCaptcha: Noisy CAPTCHAs (background noise, diagonal lines, speckles).
- solveImageNoiseCaptcha: Grid CAPTCHAs (clear character row). Optional: num_chars, uppercase.

Usage:

    from captcha_solver import CaptchaSolver

    solver = CaptchaSolver()
    result = solver.solveImageCaptcha("path/to/image.png")
    result = solver.solveImageNoiseCaptcha("path/to/image.png")
    # With optional params (grid only):
    result = solver.solveImageNoiseCaptcha("path/to/image.png", num_chars=6, uppercase=False)
    results = solver.solve_grid_five_results("path/to/image.png", num_chars=5, uppercase=True)
"""

from pathlib import Path
from typing import Union

from captcha_solver.noisy import solve_noisy as _solve_noisy
from captcha_solver.grid import solve_grid as _solve_grid
from captcha_solver.grid import solve_grid_five_results


def solveImageCaptcha(image_path: Union[str, Path]) -> str:
    """
    Solve CAPTCHAs with heavy noise, diagonal lines, and speckles.
    Accepts image path, returns extracted alphanumeric text.
    """
    return _solve_noisy(image_path)


def solveImageNoiseCaptcha(
    image_path: Union[str, Path],
    num_chars: int | None = None,
    uppercase: bool = True,
) -> str:
    """
    Solve CAPTCHAs with a clear character grid.

    Optional params:
    - num_chars: Expected number of characters (default: 5). Result is trimmed/padded to this length.
    - uppercase: If True (default), return in uppercase; if False, return in lowercase.
    """
    return _solve_grid(str(image_path), num_chars=num_chars, uppercase=uppercase)


class CaptchaSolver:
    """
    Solver for image CAPTCHAs. Use solveImageCaptcha (noisy) or solveImageNoiseCaptcha (grid).
    Grid methods accept optional num_chars and uppercase.
    """

    def solveImageCaptcha(self, image_path: Union[str, Path]) -> str:
        """
        Solve noisy CAPTCHAs (noise, lines, speckles). Accepts image path, returns result.
        """
        return solveImageCaptcha(image_path)

    def solveImageNoiseCaptcha(
        self,
        image_path: Union[str, Path],
        num_chars: int | None = None,
        uppercase: bool = True,
    ) -> str:
        """
        Solve grid CAPTCHAs (character row). Optional: num_chars, uppercase.
        """
        return solveImageNoiseCaptcha(image_path, num_chars=num_chars, uppercase=uppercase)

    def solve_grid_five_results(
        self,
        image_path: Union[str, Path],
        debug_dir: str | None = None,
        num_chars: int | None = None,
        uppercase: bool = True,
    ) -> list[str]:
        """
        Solve grid CAPTCHA with 25 OCR strategies; return 25 candidate strings.
        Optional: num_chars, uppercase.
        """
        return solve_grid_five_results(
            str(image_path),
            debug_dir=debug_dir,
            num_chars=num_chars,
            uppercase=uppercase,
        )


__all__ = [
    "CaptchaSolver",
    "solveImageCaptcha",
    "solveImageNoiseCaptcha",
]
__version__ = "0.1.0"
