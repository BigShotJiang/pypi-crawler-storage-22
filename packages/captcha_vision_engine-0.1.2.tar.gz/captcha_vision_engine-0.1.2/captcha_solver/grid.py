"""
Grid captcha text recognition using OpenCV and Tesseract OCR.

Pipeline (one full pass = one word):

    Captcha Image
         │
         ▼
    Preprocessing Layer
    (load → clean → binarize)
         │
         ▼
    Segmentation Layer
    (detect character regions)
         │
         ▼
    Character Normalization
    (crop → resize → pad)
         │
         ▼
    OCR Engine (Tesseract)
    (single-char recognition per region)
         │
         ▼
    Post-Processing
    (clean + enforce length)
         │
         ▼
    One word

- Run this pipeline once with one OCR strategy → 1 word (run()).
- Run this same process with 5 different OCR strategies → 5 words.
- Run that again 5 times (5 × 5 strategies) → 25 words (run_five_results()).

Optional params: num_chars, uppercase.
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import List, Tuple

import cv2
import numpy as np
import pytesseract

from captcha_solver.utils.process_image import get_clear_image

# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------
DEFAULT_IMAGE = "Image.png"
DEBUG_DIR = "debug_chars"
CHAR_CELL_WIDTH = 30
CHAR_CELL_HEIGHT = 32
MIN_CONTOUR_AREA = 150
MERGE_THRESHOLD = (
    1.5  # treat as multi-char if single contour wider than this * char width
)

# Tesseract: PSM 10 = single character (best for one glyph per image)
TESSERACT_CONFIG = (
    "--oem 3 "  # LSTM only
    "--psm 10 "  # single character
    "-c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
)
OCR_SCALE = 4  # scale up character image for better recognition
OCR_MIN_MEAN = 127  # below = invert so text is dark on light
PADDING_PX = 4  # padding around character before OCR

# Best single strategy (scale 4, PSM 8)
BEST_STRATEGY: Tuple[float, int, bool | None] = (4, 8, None)  # scale, PSM, force_invert

# 25 OCR strategies = 5 groups × 5 strategies. Process 5 baar with 5 strategies = 5 words;
# yeh process again 5 baar = 25 words.
OCR_STRATEGIES_GROUP_1: List[Tuple[float, int, bool | None]] = [
    (4, 8, None),    # 1: default best
    (5, 10, None),   # 2: larger scale, PSM 10
    (4, 10, None),   # 3: PSM 10
    (4, 8, True),    # 4: force invert
    (4, 8, False),   # 5: no invert
]
OCR_STRATEGIES_GROUP_2: List[Tuple[float, int, bool | None]] = [
    (3, 8, None),    # 6: smaller scale
    (3, 10, None),   # 7: scale 3, PSM 10
    (5, 8, None),    # 8: scale 5, PSM 8
    (5, 8, True),    # 9: scale 5, invert
    (6, 8, None),    # 10: scale 6
]
OCR_STRATEGIES_GROUP_3: List[Tuple[float, int, bool | None]] = [
    (6, 10, None),   # 11: scale 6, PSM 10
    (4, 7, None),    # 12: PSM 7 line
    (4, 7, True),    # 13: PSM 7, invert
    (4, 13, None),   # 14: PSM 13 raw
    (5, 7, None),    # 15: scale 5, PSM 7
]
OCR_STRATEGIES_GROUP_4: List[Tuple[float, int, bool | None]] = [
    (5, 10, True),   # 16: scale 5, PSM 10, invert
    (4, 10, True),   # 17: PSM 10, invert
    (4, 10, False),  # 18: PSM 10, no invert
    (5, 8, False),   # 19: scale 5, no invert
    (6, 8, True),    # 20: scale 6, invert
]
OCR_STRATEGIES_GROUP_5: List[Tuple[float, int, bool | None]] = [
    (6, 8, False),   # 21: scale 6, no invert
    (3, 8, True),    # 22: scale 3, invert
    (4, 13, True),   # 23: PSM 13, invert
    (5, 13, None),   # 24: scale 5, PSM 13
    (6, 7, None),    # 25: scale 6, PSM 7
]
OCR_STRATEGIES: List[Tuple[float, int, bool | None]] = (
    OCR_STRATEGIES_GROUP_1 + OCR_STRATEGIES_GROUP_2 + OCR_STRATEGIES_GROUP_3
    + OCR_STRATEGIES_GROUP_4 + OCR_STRATEGIES_GROUP_5
)

# Optional: set if Tesseract is not on PATH (e.g. Windows)
# pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# Grid captcha is typically 5 characters
CAPTCHA_LENGTH = 5


def alphanumeric_only(s: str) -> str:
    """
    Return a string containing only letters and digits; strip all other characters.

    How it works:
    - Iterates over the input string (or empty string if None) and keeps only
      characters for which c.isalnum() is True (A–Z, a–z, 0–9).
    - Used to sanitize OCR output so the captcha input receives no special chars.
    """
    return "".join(c for c in (s or "") if c.isalnum())


def fix_captcha_length(s: str, length: int = CAPTCHA_LENGTH) -> str:
    """
    Ensure the captcha string is exactly `length` characters (typically 5).

    How it works:
    - If len(s) > length: return s[:length].
    - If len(s) < length and s non-empty: pad on the right with the last character.
    - If s is empty: return "" (caller may skip or retry).
    """
    s = (s or "").strip()
    if not s:
        return ""
    if len(s) >= length:
        return s[:length]
    return s + s[-1] * (length - len(s))


# -----------------------------------------------------------------------------
# Image helpers
# -----------------------------------------------------------------------------
def tight_crop(binary_img: np.ndarray) -> np.ndarray:
    """
    Crop the image to the bounding box of all non-zero (foreground) pixels.

    How it works:
    - Finds coordinates where binary_img > 0, takes min/max along each axis.
    - Returns the smallest rectangle containing all foreground. If no foreground,
      returns the original image unchanged.
    """
    coords = np.column_stack(np.where(binary_img > 0))
    if coords.size == 0:
        return binary_img
    y0, x0 = coords.min(axis=0)
    y1, x1 = coords.max(axis=0) + 1
    return binary_img[y0:y1, x0:x1].copy()


def center_in_cell(img: np.ndarray, width: int, height: int) -> np.ndarray:
    """
    Place the image in the center of a fixed-size canvas; remainder is black.

    How it works:
    - Creates a (height, width) canvas of zeros. Copies img into the center so
      that any extra space is evenly distributed on all sides. Used to normalize
      character cell size before sending to Tesseract.
    """
    h, w = img.shape
    canvas = np.zeros((height, width), dtype=np.uint8)
    x0 = (width - w) // 2
    y0 = (height - h) // 2
    canvas[y0 : y0 + h, x0 : x0 + w] = img
    return canvas


def fit_to_cell(img: np.ndarray, cell_width: int, cell_height: int) -> np.ndarray:
    """
    Resize the image to fit inside (cell_width, cell_height) keeping aspect ratio, then center.

    How it works:
    - Computes scale = min(cell_width/w, cell_height/h), resizes img by that scale
      so it fits inside the cell without distortion.
    - Uses center_in_cell to place the resized image in a (cell_width, cell_height)
      canvas. Ensures every character region has the same dimensions for OCR.
    """
    h, w = img.shape
    scale = min(cell_width / w, cell_height / h)
    nw = max(1, int(round(w * scale)))
    nh = max(1, int(round(h * scale)))
    resized = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_NEAREST)
    return center_in_cell(resized, cell_width, cell_height)


def preprocess_for_ocr(
    img: np.ndarray,
    scale: float = OCR_SCALE,
    force_invert: bool | None = None,
    padding: int = PADDING_PX,
) -> np.ndarray:
    """
    Prepare a single-character image for Tesseract: set polarity, add padding, scale up.

    How it works:
    - Polarity: if force_invert is True, or None and image mean < OCR_MIN_MEAN, the
      image is inverted so text is dark on light (Tesseract prefers that).
    - Pads the image with a white (255) border of padding pixels on all sides.
    - Scales the result by (scale, scale) for better recognition. Returns a uint8 image.
    """
    if force_invert is True or (force_invert is None and np.mean(img) < OCR_MIN_MEAN):
        img = cv2.bitwise_not(img)
    h, w = img.shape
    padded = np.zeros((h + 2 * padding, w + 2 * padding), dtype=np.uint8)
    padded[:] = 255
    padded[padding : padding + h, padding : padding + w] = img
    scaled = cv2.resize(
        padded, None, fx=scale, fy=scale, interpolation=cv2.INTER_NEAREST
    )
    return scaled


def _ocr_one_attempt(
    cell_img: np.ndarray,
    scale: float,
    psm: int,
    force_invert: bool | None,
) -> str:
    """
    Run one Tesseract OCR pass on a single character cell; return one alphanumeric char or ''.

    How it works:
    - Preprocesses cell_img with the given scale and force_invert.
    - Runs pytesseract with OEM 3, given PSM, and whitelist A–Z a–z 0–9.
    - Returns the first character as uppercase if it is alphanumeric; otherwise ''.
    """
    img = preprocess_for_ocr(cell_img, scale=scale, force_invert=force_invert)
    config = (
        "--oem 3 "
        f"--psm {psm} "
        "-c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    )
    text = pytesseract.image_to_string(img, config=config).strip()
    if not text:
        return ""
    c = text[0].upper()
    return c if c.isalnum() else ""


def recognize_character(cell_img: np.ndarray, num_attempts: int = 1) -> str:
    """
    Recognize one character using the best single strategy (BEST_STRATEGY: scale 4, PSM 8).

    How it works:
    - Calls _ocr_one_attempt with BEST_STRATEGY (scale 4, PSM 8, auto invert).
    - num_attempts is kept for API compatibility but only one attempt is used.
    - Returns one uppercase alphanumeric character or ''.
    """
    scale, psm, force_invert = BEST_STRATEGY
    c = _ocr_one_attempt(cell_img, scale, psm, force_invert)
    return c.upper() if c else ""


def recognize_character_with_variant(
    cell_img: np.ndarray,
    scale: float,
    psm: int,
    force_invert: bool | None,
) -> str:
    """
    Recognize one character using a specific OCR strategy (scale, PSM, invert).

    How it works:
    - Calls _ocr_one_attempt with the given (scale, psm, force_invert). Used by
      run_five_results to get one character per strategy for each region.
    - Returns one uppercase alphanumeric character or '' (no special characters).
    """
    c = _ocr_one_attempt(cell_img, scale, psm, force_invert)
    return c.upper() if c and c.isalnum() else ""


# -----------------------------------------------------------------------------
# Preprocessing and segmentation
# -----------------------------------------------------------------------------
def load_and_preprocess(image_path: str) -> np.ndarray:
    """
    Load the captcha image and convert it to a binary image suitable for segmentation.

    How it works:
    - Calls get_clear_image(image_path) from process_image (grayscale, contrast, Otsu
      threshold, morphological close). Raises FileNotFoundError if the path is invalid
      or get_clear_image returns an error string.
    - Converts result to uint8. If mean > 127, inverts so text (foreground) is 255.
    - Applies minimal dilation to fix broken strokes. Returns a binary image where
      text is 255 and background 0 for contour/segment logic.
    """
    result = get_clear_image(image_path)
    if isinstance(result, str):
        raise FileNotFoundError(result)
    binary = np.asarray(result, dtype=np.uint8)
    # Ensure foreground (text) is 255 for contour/segment logic
    if binary.size > 0 and np.mean(binary) > 127:
        binary = cv2.bitwise_not(binary)
    # Minimal dilation to fix broken strokes without merging adjacent characters
    binary = cv2.dilate(binary, np.ones((1, 1), np.uint8))
    return binary


def get_character_regions(
    binary: np.ndarray,
    char_width: int,
    min_area: int,
    merge_threshold: float,
) -> Tuple[List[Tuple[int, int, int, int]], bool]:
    """
    Split the binary image into one region per character; return list of (x, y, w, h).

    How it works:
    - Finds contours (RETR_EXTERNAL), sorts left-to-right by x.
    - If there are no contours, or a single contour wider than char_width * merge_threshold,
      uses fixed-width slicing: divides the image into vertical strips of width char_width.
    - Otherwise uses each contour's bounding box, skipping regions smaller than min_area.
    - Returns (regions, use_fixed_slices): regions is list of (x, y, w, h); second value
      True when fixed-width slicing was used.
    """
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=lambda c: cv2.boundingRect(c)[0])
    h_img, w_img = binary.shape
    n_slices = max(1, w_img // char_width)
    use_fixed_slices = False

    if len(contours) == 0:
        use_fixed_slices = True
    elif len(contours) == 1:
        x, y, w, _ = cv2.boundingRect(contours[0])
        if w > char_width * merge_threshold:
            use_fixed_slices = True

    if use_fixed_slices:
        regions = []
        for i in range(n_slices):
            x0 = i * char_width
            x1 = min(x0 + char_width, w_img)
            if x1 <= x0:
                break
            regions.append((x0, 0, x1 - x0, h_img))
        return regions, True

    regions = []
    for c in contours:
        x, y, w, h = cv2.boundingRect(c)
        if w * h < min_area:
            continue
        regions.append((x, y, w, h))
    return regions, False


# -----------------------------------------------------------------------------
# Main pipeline
# -----------------------------------------------------------------------------
def run(
    image_path: str = DEFAULT_IMAGE,
    debug_dir: str | None = None,
    save_debug: bool = True,
    ocr_attempts: int = 1,
    num_chars: int | None = None,
    uppercase: bool = True,
) -> str:
    """
    Run the full OCR pipeline and return a single captcha string (alphanumeric only).

    Optional params:
    - num_chars: Expected number of characters in the captcha (default: 5). Result is
      trimmed or padded to this length.
    - uppercase: If True (default), return result in uppercase. If False, return in lowercase.

    How it works:
    - Loads and preprocesses the image with load_and_preprocess; optionally writes
      preprocessed.png to debug_dir.
    - Gets character regions with get_character_regions (contours or fixed-width).
    - For each region: tight_crop, fit_to_cell, then recognize_character (best strategy).
    - Optionally saves each character crop to debug_dir. Joins all characters and
      returns alphanumeric_only(...) so the result has no special characters.
    """
    length = num_chars if num_chars is not None else CAPTCHA_LENGTH
    os.makedirs(debug_dir, exist_ok=True) if debug_dir else None

    binary = load_and_preprocess(image_path)
    if debug_dir:
        cv2.imwrite(os.path.join(debug_dir, "preprocessed.png"), binary)

    regions, used_fixed = get_character_regions(
        binary,
        char_width=CHAR_CELL_WIDTH,
        min_area=MIN_CONTOUR_AREA,
        merge_threshold=MERGE_THRESHOLD,
    )

    result_chars: List[str] = []
    for i, (x, y, w, h) in enumerate(regions):
        cell = binary[y : y + h, x : x + w]
        cell = tight_crop(cell)
        cell = fit_to_cell(cell, CHAR_CELL_WIDTH, CHAR_CELL_HEIGHT)
        char = recognize_character(cell, num_attempts=ocr_attempts)
        result_chars.append(alphanumeric_only(char) if char else "")
        if debug_dir and save_debug:
            label = (result_chars[-1] or "x").replace(" ", "_")
            cv2.imwrite(
                os.path.join(debug_dir, f"{i:02d}_{label}.png"),
                cell,
            )

    raw = fix_captcha_length(alphanumeric_only("".join(result_chars).upper()), length=length)
    return raw.upper() if uppercase else raw.lower()


def run_five_results(
    image_path: str = DEFAULT_IMAGE,
    debug_dir: str | None = None,
    num_chars: int | None = None,
    uppercase: bool = True,
) -> List[str]:
    """
    Run recognition with 25 different OCR strategies; return 25 full captcha strings.

    Optional params:
    - num_chars: Expected number of characters in the captcha (default: 5).
    - uppercase: If True (default), each result is uppercase; if False, lowercase.

    How it works:
    - Loads and preprocesses the image once; optionally saves preprocessed.png to debug_dir.
    - Gets character regions once (same segmentation for all strategies).
    - For each of OCR_STRATEGIES (25 tuples of scale, PSM, force_invert): runs
      recognize_character_with_variant on each region, joins to a string, and applies
      alphanumeric_only. Appends that string to the results list.
    - Returns a list of 25 strings. Try each in the captcha field until one succeeds
      (or all 25 fail and a new captcha image is used).
    """
    length = num_chars if num_chars is not None else CAPTCHA_LENGTH
    binary = load_and_preprocess(image_path)
    if debug_dir:
        os.makedirs(debug_dir, exist_ok=True)
        cv2.imwrite(os.path.join(debug_dir, "preprocessed.png"), binary)

    regions, _ = get_character_regions(
        binary,
        char_width=CHAR_CELL_WIDTH,
        min_area=MIN_CONTOUR_AREA,
        merge_threshold=MERGE_THRESHOLD,
    )

    results: List[str] = []
    for scale, psm, force_invert in OCR_STRATEGIES:
        chars: List[str] = []
        for x, y, w, h in regions:
            cell = binary[y : y + h, x : x + w]
            cell = tight_crop(cell)
            cell = fit_to_cell(cell, CHAR_CELL_WIDTH, CHAR_CELL_HEIGHT)
            c = recognize_character_with_variant(cell, scale, psm, force_invert)
            chars.append(c)
        raw = fix_captcha_length(alphanumeric_only("".join(chars).upper()), length=length)
        results.append(raw.upper() if uppercase else raw.lower())
    return results


def main() -> int:
    """
    CLI entry point: recognize captcha from an image file.

    How it works:
    - Parses image path (default DEFAULT_IMAGE), --no-debug, --debug-dir, --attempts,
      --num-chars, --no-uppercase, and --five-results. If --five-results, runs run_five_results
      and prints all 25 strings; otherwise runs run() and prints the single result. Returns 0 on success,
      1 on FileNotFoundError or TesseractNotFoundError.
    """
    parser = argparse.ArgumentParser(description="Recognize captcha text (OCR only).")
    parser.add_argument(
        "image",
        nargs="?",
        default=DEFAULT_IMAGE,
        help=f"Input image path (default: {DEFAULT_IMAGE})",
    )
    parser.add_argument(
        "--no-debug",
        action="store_true",
        help="Do not save debug images",
    )
    parser.add_argument(
        "--debug-dir",
        default=None,
        metavar="DIR",
        help="Directory for debug crops (optional; no debug dir created if omitted)",
    )
    parser.add_argument(
        "--attempts",
        type=int,
        default=1,
        metavar="N",
        help="Unused (kept for CLI compatibility); only best strategy is used",
    )
    parser.add_argument(
        "--num-chars",
        type=int,
        default=None,
        metavar="N",
        help="Expected number of characters in captcha (default: 5)",
    )
    parser.add_argument(
        "--no-uppercase",
        action="store_true",
        help="Return result in lowercase instead of uppercase",
    )
    parser.add_argument(
        "--five-results",
        action="store_true",
        help="Output 25 different full results (one per OCR strategy) instead of one voted result",
    )
    args = parser.parse_args()

    try:
        if args.five_results:
            five = run_five_results(
                image_path=args.image,
                debug_dir=None if args.no_debug else args.debug_dir,
                num_chars=args.num_chars,
                uppercase=not args.no_uppercase,
            )
            print("25 different results:")
            for i, text in enumerate(five, 1):
                print(f"  Result {i}: {text}")
            return 0
        text = run(
            image_path=args.image,
            debug_dir=None if args.no_debug else args.debug_dir,
            save_debug=not args.no_debug,
            ocr_attempts=args.attempts,
            num_chars=args.num_chars,
            uppercase=not args.no_uppercase,
        )
        print("CAPTCHA RESULT:", text)
        return 0
    except FileNotFoundError as e:
        print(e, file=sys.stderr)
        return 1
    except pytesseract.TesseractNotFoundError:
        print(
            "Tesseract not found. Install tesseract-ocr and ensure it is on PATH.",
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    sys.exit(main())


# Public API wrappers (used by captcha_solver package)
def solve_grid(
    image_path: str,
    debug_dir: str | None = None,
    save_debug: bool = False,
    num_chars: int | None = None,
    uppercase: bool = True,
) -> str:
    """Solve grid CAPTCHA; single result. Optional: num_chars, uppercase."""
    return run(
        image_path=image_path,
        debug_dir=debug_dir,
        save_debug=save_debug,
        num_chars=num_chars,
        uppercase=uppercase,
    )


def solve_grid_five_results(
    image_path: str,
    debug_dir: str | None = None,
    num_chars: int | None = None,
    uppercase: bool = True,
) -> List[str]:
    """Solve grid CAPTCHA with 25 OCR strategies; return 25 candidate strings. Optional: num_chars, uppercase."""
    return run_five_results(
        image_path=image_path,
        debug_dir=debug_dir,
        num_chars=num_chars,
        uppercase=uppercase,
    )
