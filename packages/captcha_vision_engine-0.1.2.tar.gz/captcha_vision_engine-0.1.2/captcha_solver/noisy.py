"""
Noisy CAPTCHA solver: heavy background noise, diagonal lines, speckles.

Uses multiple preprocessing strategies and Tesseract PSM modes to extract
alphanumeric text. Use for any CAPTCHA with obscured text (noise, lines, dots).
"""

from __future__ import annotations

import os
import re
from pathlib import Path

from PIL import Image

try:
    import pytesseract
    OCR_AVAILABLE = True
    _tesseract_cmd = os.environ.get("TESSERACT_CMD")
    if _tesseract_cmd:
        pytesseract.pytesseract.tesseract_cmd = _tesseract_cmd
    try:
        pytesseract.get_tesseract_version()
        TESSERACT_AVAILABLE = True
    except Exception:
        TESSERACT_AVAILABLE = False
        OCR_AVAILABLE = False
except ImportError:
    OCR_AVAILABLE = False
    TESSERACT_AVAILABLE = False

TESSERACT_INSTALL_MSG = (
    "Tesseract OCR not installed or not in PATH. "
    "Ubuntu: sudo apt-get install tesseract-ocr | macOS: brew install tesseract | "
    "Or set TESSERACT_CMD env to tesseract executable."
)


def _preprocess_image(image: Image.Image) -> Image.Image:
    if image.mode == "RGBA":
        bg = Image.new("RGB", image.size, (255, 255, 255))
        bg.paste(image, mask=image.split()[3])
        image = bg
    elif image.mode not in ("L", "RGB"):
        image = image.convert("RGB")
    if image.mode != "L":
        image = image.convert("L")
    scale = 2.0
    new_size = (int(image.size[0] * scale), int(image.size[1] * scale))
    return image.resize(new_size, Image.Resampling.LANCZOS)


def _build_strategies(image: Image.Image):
    from PIL import ImageEnhance, ImageFilter
    import numpy as np
    strategies = []
    img1 = image.copy()
    ImageEnhance.Contrast(img1).enhance(3.0)
    strategies.append(("high_contrast_sharp", img1.filter(ImageFilter.SHARPEN)))
    arr = np.array(image.copy())
    t = np.mean(arr)
    strategies.append(("threshold", Image.fromarray(np.where(arr > t, 255, 0).astype(np.uint8))))
    strategies.append(("inverted_threshold", Image.fromarray(np.where(arr < t, 255, 0).astype(np.uint8))))
    img4 = image.copy()
    ImageEnhance.Contrast(img4).enhance(2.5)
    ImageEnhance.Brightness(img4).enhance(1.2)
    strategies.append(("contrast_brightness", img4))
    return strategies


def _run_ocr(image, config: str):
    text = pytesseract.image_to_string(image, config=config)
    return re.sub(r"[^A-Za-z0-9]", "", text.strip())


def solve_noisy(captcha_image_path: str | Path) -> str:
    """
    Solve CAPTCHAs with heavy noise, diagonal lines, and speckles.

    Use for images where text is obscured by background noise, lines, or dots.
    Uses multiple preprocessing strategies and Tesseract PSM modes.

    Args:
        captcha_image_path: Path to the CAPTCHA image (PNG, etc.).

    Returns:
        Extracted text (letters and digits only).

    Raises:
        RuntimeError: If OCR dependencies are missing or Tesseract is not installed.
    """
    if not OCR_AVAILABLE:
        raise RuntimeError("OCR not available. pip install pytesseract pillow")
    if not TESSERACT_AVAILABLE:
        raise RuntimeError(TESSERACT_INSTALL_MSG)
    try:
        from PIL import ImageEnhance, ImageFilter
        import numpy as np
    except ImportError:
        raise RuntimeError("PIL/numpy required for OCR preprocessing")

    path = Path(captcha_image_path)
    if not path.exists():
        raise FileNotFoundError(f"Image not found: {path}")

    image = Image.open(path)
    image = _preprocess_image(image)
    strategies = _build_strategies(image)
    psm_modes = [(7, "line"), (8, "word"), (13, "raw"), (6, "block")]
    whitelist = " -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    best_result, best_conf, best_config = "", 0, ""

    for psm_mode, psm_desc in psm_modes:
        try:
            config = f"--oem 3 --psm {psm_mode}" + whitelist
            cleaned = _run_ocr(image, config)
            if cleaned and len(cleaned) >= 3:
                try:
                    data = pytesseract.image_to_data(image, config=config, output_type=pytesseract.Output.DICT)
                    confs = [int(c) for c in data["conf"] if int(c) > 0]
                    avg = sum(confs) / len(confs) if confs else 0
                    if avg > best_conf:
                        best_result, best_conf, best_config = cleaned, avg, f"original+PSM{psm_mode}"
                except Exception:
                    if not best_result or len(cleaned) > len(best_result):
                        best_result, best_config = cleaned, f"original+PSM{psm_mode}"
        except Exception:
            continue

    if not best_result or best_conf < 50:
        for strategy_name, processed_img in strategies:
            for psm_mode, _ in psm_modes:
                try:
                    config = f"--oem 3 --psm {psm_mode}" + whitelist
                    cleaned = _run_ocr(processed_img, config)
                    if cleaned and len(cleaned) >= 3:
                        try:
                            data = pytesseract.image_to_data(processed_img, config=config, output_type=pytesseract.Output.DICT)
                            confs = [int(c) for c in data["conf"] if int(c) > 0]
                            avg = sum(confs) / len(confs) if confs else 0
                            if avg > best_conf:
                                best_result, best_conf, best_config = cleaned, avg, f"{strategy_name}+PSM{psm_mode}"
                        except Exception:
                            if not best_result or len(cleaned) > len(best_result):
                                best_result, best_config = cleaned, f"{strategy_name}+PSM{psm_mode}"
                except Exception:
                    continue

    if best_result:
        return best_result
    for psm in [7, 8, 13]:
        try:
            cleaned = _run_ocr(image, f"--oem 3 --psm {psm}")
            if cleaned and len(cleaned) >= 3:
                return cleaned
        except Exception:
            continue
    text = pytesseract.image_to_string(image, config="--oem 3 --psm 7")
    cleaned = re.sub(r"[^A-Za-z0-9]", "", text.strip())
    return cleaned if cleaned else text.strip()
