"""Internal utilities for captcha_solver."""
