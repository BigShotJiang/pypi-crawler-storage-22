"""
Image preprocessing for OCR (grid-style captcha).

Provides get_clear_image(): load image, grayscale, contrast, Otsu threshold,
and morphological closing to produce a clean binary image for character recognition.
"""

import cv2
import numpy as np


def get_clear_image(image_path: str):
    """
    Load an image and return a cleaned binary version for OCR.

    Pipeline: load → grayscale → contrast adjustment → Otsu thresholding
    → morphological closing (to fill small holes in characters).

    Args:
        image_path: Path to the image file (e.g. captcha PNG).

    Returns:
        numpy.ndarray: Binary image (text=255, background=0), or the string
        "Image not found" if the file cannot be loaded.
    """
    img = cv2.imread(image_path)
    if img is None:
        return "Image not found"

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    alpha, beta = 1.5, 0
    adjusted = cv2.convertScaleAbs(gray, alpha=alpha, beta=beta)
    _, thresh = cv2.threshold(
        adjusted, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    kernel = np.ones((2, 2), np.uint8)
    clean_img = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
    return clean_img
