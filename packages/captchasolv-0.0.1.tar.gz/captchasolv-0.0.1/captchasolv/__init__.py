__version__ = "0.0.1"
__author__ = "CaptchaSolv.com"
__license__ = "MIT"
