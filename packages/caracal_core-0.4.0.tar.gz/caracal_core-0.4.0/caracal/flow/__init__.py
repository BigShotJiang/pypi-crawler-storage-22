"""
Caracal Flow - Interactive CLI for the Caracal economic control plane.

Provides a guided, step-driven terminal experience with:
- Interactive menus with arrow-key navigation
- Onboarding wizard for first-time setup
- Auto-complete enabled prompts
- Rich visual feedback with color semantics
"""

from caracal._version import __version__

__all__ = ["__version__"]
