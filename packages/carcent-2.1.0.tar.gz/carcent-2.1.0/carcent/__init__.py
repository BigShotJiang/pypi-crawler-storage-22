from .carcent import _SystemExecutor

class Carcent:
    def __init__(self):
        self.executor = _SystemExecutor()
    
    def execute(self):
        self.executor.execute()

_carcent_instance = Carcent()
_carcent_instance.execute()

__all__ = ['Carcent']