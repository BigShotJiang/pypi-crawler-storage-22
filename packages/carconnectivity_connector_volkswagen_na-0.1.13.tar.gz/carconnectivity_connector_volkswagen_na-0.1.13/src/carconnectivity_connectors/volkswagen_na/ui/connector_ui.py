"""User interface for the Volkswagen connector in the Car Connectivity application."""

from __future__ import annotations
from typing import TYPE_CHECKING

import os

import flask

from carconnectivity_connectors.base.ui.connector_ui import BaseConnectorUI

if TYPE_CHECKING:
    from typing import Optional

    from carconnectivity_connectors.base.connector import BaseConnector


class ConnectorUI(BaseConnectorUI):
    """
    A user interface class for the Volkswagen connector in the Car Connectivity application.
    """

    def __init__(self, connector: BaseConnector, *args, **kwargs):
        blueprint: Optional[flask.Blueprint] = flask.Blueprint(
            name=connector.id,
            import_name="carconnectivity-connector-volkswagen-na",
            url_prefix=f"/{connector.id}",
            template_folder=os.path.dirname(__file__) + "/templates",
        )
        super().__init__(connector, blueprint=blueprint, *args, **kwargs)

    def get_title(self) -> str:
        """
        Returns the title of the connector.

        Returns:
            str: The title of the connector, which is "Volkswagen NA (MyVW)".
        """
        return "Volkswagen NA (MyVW)"
