"""Module just storing the Base class for SQLAlchemy models."""
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
