"""Django settings for CarConnectivity WebUI plugin."""
from __future__ import annotations
import os
import uuid
from pathlib import Path

# Build paths inside the project
BASE_DIR = Path(__file__).resolve().parent

# Import plugin config getter
from carconnectivity_plugins.webui.django_app import get_plugin_config

# Get plugin configuration
plugin_config = get_plugin_config()

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.environ.get('DJANGO_SECRET_KEY', uuid.uuid4().hex)

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = plugin_config.get('debug', False) if plugin_config else os.environ.get('DJANGO_DEBUG', 'False') == 'True'

# Allowed hosts from plugin config
ALLOWED_HOSTS = plugin_config.get('allowed_hosts', ['*']) if plugin_config else ['*']

# CSRF trusted origins from plugin config
CSRF_TRUSTED_ORIGINS = plugin_config.get('csrf_trusted_origins', []) if plugin_config else []

# Session and CSRF cookie security
SESSION_COOKIE_SECURE = plugin_config.get('session_cookie_secure', False) if plugin_config else False
CSRF_COOKIE_SECURE = plugin_config.get('csrf_cookie_secure', False) if plugin_config else False

# Application definition
INSTALLED_APPS = [
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.staticfiles',
    'carconnectivity_plugins.webui.django_app',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'carconnectivity_plugins.webui.django_app.middleware.CarConnectivityAuthMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'carconnectivity_plugins.webui.django_app.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.messages.context_processors.messages',
                'carconnectivity_plugins.webui.django_app.context_processors.navbar',
                'carconnectivity_plugins.webui.django_app.context_processors.car_connectivity',
            ],
        },
    },
]

WSGI_APPLICATION = 'carconnectivity_plugins.webui.django_app.wsgi.application'

# Database - not used, but required by Django
DATABASES = {}

# Session configuration - use cache-based sessions (in-memory)
SESSION_ENGINE = 'django.contrib.sessions.backends.cache'
SESSION_COOKIE_NAME = 'carconnectivity_sessionid'
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = 'Lax'

# Cache configuration
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'carconnectivity-cache',
        'TIMEOUT': 300,
        'OPTIONS': {
            'MAX_ENTRIES': 1000
        }
    }
}

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'

# Static files are in the django_app/static directory
# BASE_DIR points to the django_app directory in the installed package
import os
import logging
logger = logging.getLogger(__name__)

static_path = os.path.join(BASE_DIR, 'static')
logger.info(f"Django static path: {static_path}")
logger.info(f"Static path exists: {os.path.exists(static_path)}")

# Only add to STATICFILES_DIRS if the directory exists
if os.path.exists(static_path):
    STATICFILES_DIRS = [static_path]
    logger.info(f"STATICFILES_DIRS configured: {STATICFILES_DIRS}")
else:
    # Fallback: static files might be in a different location
    STATICFILES_DIRS = []
    logger.warning(f"Static directory not found at {static_path}")

# For serving static files in production without collectstatic
STATIC_ROOT = None

# Default primary key field type
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# CSRF settings
CSRF_COOKIE_NAME = 'carconnectivity_csrftoken'
CSRF_COOKIE_HTTPONLY = False
CSRF_COOKIE_SAMESITE = 'Lax'

# Security settings
SECURE_BROWSER_XSS_FILTER = True
X_FRAME_OPTIONS = 'DENY'

# Disable APPEND_SLASH to prevent 301 redirects on URLs without trailing slash
APPEND_SLASH = False

# Logging configuration
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'INFO',
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
        'carconnectivity': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': False,
        },
    },
}
