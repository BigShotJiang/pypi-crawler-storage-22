"""Views for CarConnectivity WebUI."""
