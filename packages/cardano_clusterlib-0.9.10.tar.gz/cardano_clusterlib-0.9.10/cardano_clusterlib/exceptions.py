class CLIError(Exception):
    pass
