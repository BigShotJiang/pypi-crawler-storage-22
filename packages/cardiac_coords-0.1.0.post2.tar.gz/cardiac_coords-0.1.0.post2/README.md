# Cardiac coordinates

A python package with various tools about cardiac coordinates systems.

If you use this package, please cite this
[EP Europace article](https://academic.oup.com/europace/article/20/suppl_3/iii94/5202155)
that mentions the "ventricular coordinates" and its use to register electro-anatomical
maps and imaging data (Figure 4).

```bibtex
@article{cedilnik2018fast,
  title={Fast personalized electrophysiological models from computed tomography images for ventricular tachycardia ablation planning},
  author={Cedilnik, Nicolas and Duchateau, Josselin and Dubois, R{\'e}mi and Sacher, Fr{\'e}d{\'e}ric and Ja{\"\i}s, Pierre and Cochet, Hubert and Sermesant, Maxime},
  journal={EP Europace},
  volume={20},
  number={suppl\_3},
  pages={iii94--iii101},
  year={2018},
  publisher={Oxford University Press}
}
```

## Features

### Ventricular coordinates

![Ventricular coordinates](./img/coords.png)

### Local coordinates systems

![Local coordinates systems](./img/local.png)

### Rule-based fiber orientation

![Rule-based fiber](./img/fiber.png)

### Bull's eye plots

![Bull's eye plot](./img/bullseye-phi.png)

## Documentation

The documentation is hosted on
[https://ncedilni.gitlabpages.inria.fr/cardiac-coords](https://ncedilni.gitlabpages.inria.fr/cardiac-coords).

## Installation

### Via pip or similar standard packaging tools

Stable versions are published to [PyPI.org](https://pypi.org/project/cardiac-coords/).
Just `pip install cardiac-coords` or similar with your favorite python project manager.

Development versions are published on
[gitlab packages](https://gitlab.inria.fr/ncedilni/cardiac-coords/-/packages/).

### From the git repository

Since this repo uses [Git Large File Storage](https://git-lfs.com/), make sure it is
installed.

```
pip install git+ssh://git@gitlab.inria.fr/ncedilni/cardiac-coords
```
