"""
# Cardiac coordinates

![PyPI - Version](https://img.shields.io/pypi/v/cardiac-coords)

[Homepage](https://gitlab.inria.fr/ncedilni/cardiac-coords/)

Coordinates systems of the heart.

The main entrypoint for using this package is the `CardiacCoordinates` class,
which provides a high-level interface with segmentations from imaging data
(i.e., data on regular grids) as inputs.

To work with arbitrary point clouds, one should use the lower-level interfaces
provided in the `cardiac_coords.coords` and `cardiac_coords.fiber` submodules.
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("cardiac_coords")
except PackageNotFoundError:
    # package is not installed
    __version__ = "dev"


from . import api, bullseye, coords, fiber, interp
from .api import CardiacCoordinates, CardiacSurfaceCoordinates

__all__ = (
    "CardiacCoordinates",
    "CardiacSurfaceCoordinates",
    "coords",
    "fiber",
    "interp",
    "bullseye",
    "api",
    "__version__",
)
