import warnings
from dataclasses import dataclass
from typing import Type, Unpack

import numpy as np
from matplotlib.figure import Figure

from .bullseye import BullsEyePlot
from .coords import aha, spherical_coordinates
from .fiber import LocalCoordinateSystem
from .interp import BaseInterpolator, CyclicLinearInterpolator
from .types import (
    AnyArray,
    ArrayType,
    BoolArray,
    BullsEyePlotKwargs,
    FloatArray,
    FloatArrayLike,
    IntArray,
    PointLike,
    PointsLike,
)


@dataclass
class CardiacSurfaceCoordinates:
    r"""
    High-level interface for "surfacic" cardiac coordinates, if your data is in the
    form of point clouds/surface meshes.


    """

    wall_points: PointsLike
    """
    The point cloud representing your data.
    """
    apex_direction: PointLike = (1.0, 0, 0)
    r"""
    A vector representing the "polar axis" for the spherical coordinates
    $\phi$ and $\theta$.
    """
    theta_zero_point: PointLike = (0.0, 0.0, 0.0)
    r"""
    For the polar angle $\theta$, a point in space defining where $\theta=0$.
    """
    center: PointLike | None = None
    r"""
    The origin of the spherical coordinates $\phi$ and $\theta$.
    """

    def __post_init__(self) -> None:
        self.wall_points = np.asarray(self.wall_points)
        if self.center is None:
            self.center = np.mean(self.wall_points, axis=0)
        self.phi, self.theta, self.distance = spherical_coordinates(
            points=self.wall_points,
            origin=self.center,
            polar_axis=self.apex_direction,
            theta_zero_point=self.theta_zero_point,
        )
        self.aha = aha(self.theta, self.phi)

    def project(
        self,
        values: AnyArray,
        target: "CardiacSurfaceCoordinates",
        interpolator_cls: Type[BaseInterpolator] = CyclicLinearInterpolator,
    ) -> FloatArray:
        """
        Project `values` on the wall points of this instance onto the wall points of `other`.

        :param values: An 1D array of values with values corresponding to `self.wall_points`.
        :param target: The `CardiacCoordinates` instance to project `values` onto.
        :param interpolator_cls: The interpolation method to use.

        :return: A float array of the same shape as `values`.
        """
        interpolator = interpolator_cls(self.phi, self.theta, None, values)
        return interpolator(target.phi, target.theta, None)

    def bullseye(
        self, scalars: FloatArrayLike, **kwargs: Unpack[BullsEyePlotKwargs]
    ) -> Figure:
        """
        Returns a bullseye projection of `scalars`, in the form of a matplotlib `Figure`.

        :param scalars: The values you want to see on the bullseye plot. Must have as many values
            as `wall_points`.
        :return: A matplotlib `Figure`, with the first `Axes` being the bullseye plot itself and
            a second one for the color bar.
        """
        return BullsEyePlot(self.phi, self.theta, scalars, **kwargs).fig()


@dataclass
class CardiacCoordinates:
    r"""
    High-level interface for "volumic" cardiac coordinates, if your data is in the
    form of binary masks.


    >>> from cardiac_coords.util import epi_and_endo  # sample data
    >>> epi, endo = epi_and_endo()
    >>> coords = CardiacCoordinates(epi=epi, endo=endo)

    The various values are accessed via attributes of the `CardiacCoordinates`
    instance. They have the same shape as the input.

    >>> coords.phi.shape == epi.shape
    True

    They are simply float numpy arrays.

    >>> coords.phi[coords.wall]
    array([2.48866596, 2.50362033, 2.5148138 , ..., 0.10166769, 0.09099695,
           0.10166769], shape=(6761,))

    $\phi$, $\theta$ and $\rho$ are
    [spherical coordinates](https://en.wikipedia.org/wiki/Spherical_coordinate_system),
    with a twist for $\rho$: it is not the euclidian distance from the origin but rather
    the depth through the myocardium. The radial distance can be accessed via
    the `distance` attribute (but is usually less useful).

    ![](../img/coords.png)

    `longitudinal`, `radial` and `circumferential` define local frames of
    reference.

    ![](../img/local.png)

    Fiber orientation can be estimated using the `streeter()` method.

    """

    endo: BoolArray
    """
    A binary mask, representing the inner surface of a cardiac cavity, a.k.a.
    "blood pool" or "endocardium".
    """
    epi: BoolArray
    """
    A binary mask, representing the outer surface of a cardiac cavity, a.k.a.
    "epicardium".
    """
    apex_direction: PointLike = (1.0, 0, 0)
    r"""
    A vector representing the "polar axis" for the spherical coordinates
    $\phi$ and $\theta$.
    """
    theta_zero_point: PointLike = (0.0, 0.0, 0.0)
    r"""
    For the polar angle $\theta$, a point in space defining where $\theta=0$.
    """
    spacing: PointLike = (1.0, 1.0, 1.0)
    """
    Spacing between the voxels.
    """
    center: PointLike | None = None
    r"""
    The origin of the spherical coordinates $\phi$ and $\theta$.
    """

    def __post_init__(self) -> None:
        for attr in "endo", "epi":
            mask = getattr(self, attr)
            if not np.isdtype(mask.dtype, np.bool):
                warnings.warn(
                    f"{attr} has not been passed as a boolean array, converting it"
                )
                setattr(self, attr, mask.astype(bool))

        self.endo[~self.epi] = False
        self.wall = self.endo ^ self.epi
        self.wall_points = np.argwhere(self.wall) * self.spacing
        self._surf_coords = CardiacSurfaceCoordinates(
            self.wall_points, self.apex_direction, self.theta_zero_point, self.center
        )
        self.center = self._surf_coords.center
        self.local = LocalCoordinateSystem.from_masks(
            self.endo, self.epi, self.apex_direction, self.spacing
        )

    def streeter(self, epi_angle: float = -60, endo_angle: float = 60) -> FloatArray:
        """
        Generates fiber orientation according to
        [Streeter](https://www.ahajournals.org/doi/10.1161/01.RES.24.3.339)
        rule-based method.

        :param epi_angle: Angle, in degrees, defining the fiber orientation
            at the epicardial surface.
        :param endo_angle: Angle, in degrees, defining the fiber orientation
            at the endocardial surface.
        :return: A 4D array of shape `(i, j, k, 3)`, the last axis being the
            components of the vectors.


        >>> from cardiac_coords.util import epi_and_endo  # sample data
        >>> epi, endo = epi_and_endo()
        >>> coords = CardiacCoordinates(epi=epi, endo=endo)
        >>> coords.streeter().shape
        (40, 25, 25, 3)

        ![](../img/fiber.png)

        """
        fiber = self.local.streeter(np.deg2rad(epi_angle), np.deg2rad(endo_angle))
        return self._unflatten(np.asarray(fiber), True)

    def _unflatten(self, data: ArrayType, vector: bool = False) -> ArrayType:
        if np.dtype(data.dtype).kind == "f":
            fill_value = np.nan
        else:
            fill_value = 0
        result = np.full(
            self.wall.shape + ((3,) if vector else ()), fill_value, data.dtype
        )
        result[self.wall] = data
        return result

    @property
    def phi(self) -> FloatArray:
        r"""
        Polar angle, $0$ at the apex, up to $\pi$.
        """
        return self._unflatten(self._surf_coords.phi)

    @property
    def theta(self) -> FloatArray:
        r"""
        Azimuthal angle ranging from $-\pi$ to $\pi$. The zero depends on what
        was passed for `theta_zero_point`.
        """
        return self._unflatten(self._surf_coords.theta)

    @property
    def rho(self) -> FloatArray:
        r"""
        A third coordinates corresponding to "how deep" we are in the myocardium.
        It is obtained by solving the heat equation $\Delta \rho = 0$ and
        forcing $\rho = 0$ at the endocardium and $\rho = 1$ at the epicardium.
        """
        return self._unflatten(self.local.rho)

    @property
    def distance(self) -> FloatArray:
        """
        Distance from `center`, a.k.a., "radial distance".
        """
        return self._unflatten(self._surf_coords.distance)

    @property
    def circumferential(self) -> FloatArray:
        """
        Circumferential vector field, a 4D `(i, j, k, 3)`-shaped array.
        """
        return self._unflatten(self.local.circumferential, True)

    @property
    def radial(self) -> FloatArray:
        """
        Radial vector field, a 4D `(i, j, k, 3)`-shaped array.
        """
        return self._unflatten(self.local.radial, True)

    @property
    def longitudinal(self) -> FloatArray:
        """
        Longitudinal vector field, a 4D `(i, j, k, 3)`-shaped array.
        """
        return self._unflatten(self.local.longitudinal, True)

    @property
    def aha(self) -> IntArray:
        """
        American Heart Association 17 segments of the left ventricle.

        A 3D `(i, j, k)`-shaped array of unsigned 8-bit integers from 1 to 17.
        """
        return self._unflatten(self._surf_coords.aha)

    def project(
        self,
        values: AnyArray,
        target: "CardiacCoordinates",
        interpolator_cls: Type[BaseInterpolator] = CyclicLinearInterpolator,
    ) -> FloatArray:
        """
        Project `values` on the wall of this instance onto the wall of `other`.

        :param values: An array of values, either 3D of the same shape as `self.wall` or
            1D with values corresponding to `self.wall_points`.
        :param target: The `CardiacCoordinates` instance to project `values` onto.
        :param interpolator_cls: The interpolation method to use.

        :return: A float array of the same shape as `values`.
        """
        flat = values.ndim == 1
        if not flat:
            values = values[self.wall]
        interpolator = interpolator_cls(
            self._surf_coords.phi, self._surf_coords.theta, self.local.rho, values
        )
        new_values = interpolator(
            target._surf_coords.phi, target._surf_coords.theta, target.local.rho
        )
        if flat:
            return new_values
        return target._unflatten(new_values)

    def bullseye(
        self,
        scalars: FloatArrayLike,
        rho_min: float = 0,
        rho_max: float = 1,
        **kwargs: Unpack[BullsEyePlotKwargs],
    ) -> Figure:
        r"""
        Returns a bullseye projection of `scalars`, in the form of a matplotlib `Figure`.

        Since bullseye plots are effectively plots of a surface, you can control which "layer"
        of the myocardium you want to project by setting a range with `rho_min` and `rho_max`.
        For instance, if you want what is more or less on the epicardial surface, you can use
        `rho_min=0.9`.

        :param scalars: The values you want to see on the bullseye plot.
        :param rho_min: Lower bound for rho.
        :param rho_max: Upper bound for rho.
        :param kwargs: Additional parameters passed to `cardiac_coords.bullseye.BullsEyePlot`.

        :return: A matplotlib `Figure`, with the first `Axes` being the bullseye plot itself and
            a second one for the color bar.

        >>> from cardiac_coords.util import epi_and_endo  # sample data
        >>> epi, endo = epi_and_endo()
        >>> coords = CardiacCoordinates(epi=epi, endo=endo)
        >>> coords.bullseye(coords.phi, title=r"$\phi$", cmap="inferno")
        <Figure size 550x500 with 2 Axes>

        You can then use `plt.show()` or `plt.savefig()`.

        ![](../img/bullseye-phi.png)

        """
        scalars = np.asarray(scalars)
        if scalars.ndim != 1:
            scalars = scalars[self.wall]

        filt = (rho_min <= self.local.rho) & (self.local.rho <= rho_max)
        return BullsEyePlot(
            self._surf_coords.phi[filt],
            self._surf_coords.theta[filt],
            scalars,
            **kwargs,
        ).fig()
