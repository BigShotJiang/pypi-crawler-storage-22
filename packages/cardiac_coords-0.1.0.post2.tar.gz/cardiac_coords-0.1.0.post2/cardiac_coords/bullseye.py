"""
This module implements methods to generate bull's eye plots from spherical coordinates.
"""

from dataclasses import dataclass
from functools import partial
from typing import Type

import numpy as np
from matplotlib import pyplot as plt
from matplotlib.colors import Colormap
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from matplotlib.patches import Circle

from .coords import AHA_DEFAULT_HEIGHT_DIVISIONS
from .interp import BaseInterpolator, CyclicLinearInterpolator
from .types import FloatArray, FloatArrayLike, MplColor


@dataclass
class BullsEyePlot:
    height: FloatArrayLike
    r"""A coordinate for which 0 is the apex, and values go up towards the base, e.g., the polar angle $\phi$,"""
    theta: FloatArrayLike
    """Azimuthal angle."""
    scalars: FloatArrayLike
    r"""Scalar values for each $(\text{height}, \theta)$ couple."""
    img_size: int = 201
    """Diameter (resolution) of the bull's eye disk, in pixels."""
    line_color: MplColor = "white"
    """Color of the lines separating AHA segments."""
    line_width: float = 3
    """Width of the lines separating AHA segments."""
    cbar_ratio: float = 20
    """Ratio between disk and color bar."""
    cmap: str | None | Colormap = None
    """Color map to represent scalars."""
    title: str | None = None
    """Global title for the plot."""
    height_divisions: tuple[float, float, float, float] = AHA_DEFAULT_HEIGHT_DIVISIONS
    """Divisions for the `height` values, i.e., the circles separating the segments 1-6, 7-12, 13-16 and 17."""

    def __post_init__(self) -> None:
        self.height = np.asarray(self.height)
        self.theta = np.asarray(self.theta)
        self.scalars = np.asarray(self.scalars)

    def _line(self, start: float, end: float, theta: float) -> Line2D:
        r = self.img_size / 2
        x1 = r * start * np.cos(theta) + r
        y1 = r * start * np.sin(theta) + r

        x2 = r * end * np.cos(theta) + r
        y2 = r * end * np.sin(theta) + r

        return Line2D(
            [x1, x2], [y1, y2], color=self.line_color, linewidth=self.line_width
        )

    def fig(self) -> Figure:
        """
        Get the figure.

        :return: A matplotlib figure with 2 axes: the bull's eye plot and the colorbar.
        """
        divs = self.height_divisions

        disk_scalars = _bullseye(self.scalars, self.height, self.theta, self.img_size)

        fig, axes = plt.subplots(
            ncols=2,
            width_ratios=[self.cbar_ratio, 1],
            layout="constrained",
            figsize=[5.5, 5],
        )

        if self.title:
            fig.suptitle(self.title)

        im = axes[0].imshow(disk_scalars, cmap=self.cmap)
        axes[0].axis("off")
        axes[0].set_xlim(0, self.img_size)
        axes[0].set_ylim(0, self.img_size)

        radius = self.img_size / 2
        for x in divs:
            axes[0].add_artist(
                Circle(
                    (radius, radius),
                    radius * x,
                    fill=False,
                    color=self.line_color,
                    linewidth=self.line_width,
                )
            )

        for i in range(6):
            axes[0].add_artist(self._line(divs[2], 1, 2 * i * np.pi / 6))
        for i in range(4):
            axes[0].add_artist(
                self._line(divs[2], divs[3], 2 * i * np.pi / 4 + np.pi / 4)
            )

        plt.colorbar(im, cax=axes[1])

        return fig


def _angles(v1: FloatArray, v2: FloatArray) -> FloatArray:
    x = np.arctan2(v2[1], v2[0]) - np.arctan2(v1[:, 1], v1[:, 0])
    # ensure [-pi, pi] range
    return np.mod(x + np.pi, 2 * np.pi) - np.pi


def _disk_eq(radius: float, i: int, j: int) -> bool:
    return (i - radius) ** 2 + (j - radius) ** 2 <= radius**2


def _bullseye(
    scalars: FloatArrayLike,
    src_height: FloatArrayLike,
    src_theta: FloatArrayLike,
    size: int,
    phi_max: float | None = None,
    theta_zero_vec: tuple[float, float] | FloatArrayLike = (0, -1),
    interpolator_cls: Type[BaseInterpolator] = CyclicLinearInterpolator,
) -> FloatArray:
    radius = size / 2
    src_height = np.asarray(src_height)

    if phi_max is None:
        phi_max = src_height.max()

    theta_zero_vec = np.asarray(theta_zero_vec, dtype=float)

    interpolator = interpolator_cls(src_height, src_theta, None, scalars)

    disk = np.fromfunction(partial(_disk_eq, radius), (size, size))

    indices = np.argwhere(disk)
    vecs = (indices - radius).astype(float)
    phis = np.linalg.norm(vecs / radius, axis=1) * phi_max
    thetas = _angles(vecs, theta_zero_vec)
    thetas *= -1
    result = np.full((size, size), np.nan)
    result[disk] = interpolator(phis, thetas)

    return result


__all__ = ("BullsEyePlot",)
