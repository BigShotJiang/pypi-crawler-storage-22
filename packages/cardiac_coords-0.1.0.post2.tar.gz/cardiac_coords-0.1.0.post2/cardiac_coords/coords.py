"""
Low-level interface for the computation of
[spherical coordinates](https://en.wikipedia.org/wiki/Spherical_coordinate_system).

See `cardiac_coords.CardiacCoordinates` for a higher-level interface.
"""

from typing import NamedTuple

import numpy as np

from .types import FloatArray, IntArray, PointLike, PointsLike


class SphericalCoordinates(NamedTuple):
    """
    A named tuple holding the results of `spherical_coordinates`.
    """

    phis: FloatArray
    """Polar angle."""
    thetas: FloatArray
    """Azimuthal angle."""
    distances: FloatArray
    """Radial distance."""


def spherical_coordinates(
    points: PointsLike,
    origin: PointLike,
    theta_zero_point: PointLike,
    polar_axis: PointLike,
) -> SphericalCoordinates:
    r"""
    Computes the spherical coordinates for a point cloud.

    >>> result = spherical_coordinates(
    ...     points=[[1, 0, 0], [0, 1, 0], [0, 0, 1]],
    ...     origin=[0, 0, 0],
    ...     theta_zero_point=[1, 0, 0],
    ...     polar_axis=[0, 0, 1],
    ... )
    >>> result.phis
    array([1.57079633, 1.57079633, 0.        ])
    >>> result.thetas
    array([-0.        ,  1.57079633,  0.        ])
    >>> result.distances
    array([1., 1., 1.])

    :param points: A `(n, 3)`-shaped array representing a point cloud for which
        we want spherical coordinates.
    :param origin: A `(3)`-shaped array representing the origin of the spherical
        coordinates.
    :param theta_zero_point: A `(3)`-shaped array used to define where
        $\theta = 0$.
    :param polar_axis: The polar axis of the spherical coordinates.

    :return: Spherical coordinates for all points passed as input.
    """
    # phis computation (azimut)
    origin_to_points = np.asarray(points) - origin
    polar_axis = np.asarray(polar_axis).astype(float)
    distances = np.linalg.norm(origin_to_points, axis=1)
    phis = np.arccos(
        (polar_axis * origin_to_points).sum(axis=1)
        / (distances * np.linalg.norm(polar_axis))
    )

    # thetas computation (polar)
    origin_to_septum = np.asarray(theta_zero_point) - origin
    ortho_origin_to_septum = np.cross(origin_to_septum, polar_axis)
    origin_to_points_long_axis_projection = project(polar_axis, origin_to_points)
    projected_origin_to_points = (
        origin_to_points - origin_to_points_long_axis_projection
    )
    projected_distances = np.linalg.norm(projected_origin_to_points, axis=1)
    cosines = (origin_to_septum * projected_origin_to_points).sum(axis=1) / (
        projected_distances * np.linalg.norm(origin_to_septum)
    )

    sinuses = (ortho_origin_to_septum * projected_origin_to_points).sum(axis=1) / (
        projected_distances * np.linalg.norm(ortho_origin_to_septum)
    )

    # for points aligned with long axis, theta value is NaN because undefined.
    # zeros sounds like a better value for this
    thetas = np.nan_to_num(-np.arctan2(sinuses, cosines))

    return SphericalCoordinates(phis, thetas, distances)


def project(vector: PointLike, vectors: PointsLike) -> FloatArray:
    """
    Project a list of vectors onto a vector.

    :param vector: the vector that vectors will be projected onto.
    :param vectors: the list of vectors we want to project.

    :return: List of projected vectors
    """
    vector = np.asarray(vector)
    vectors = np.asarray(vectors)
    return vector * (vector * vectors).sum(axis=1)[:, np.newaxis] / (vector**2).sum()


def aha(
    theta: FloatArray,
    height: FloatArray,
    height_div: tuple[float, float, float, float] | FloatArray | None = None,
) -> IntArray:
    """ """
    if height_div is None:
        height_max = np.max(height)
        height_div = height_max * np.asarray(AHA_DEFAULT_HEIGHT_DIVISIONS)

    result = np.full(theta.shape, 17, dtype=np.uint8)
    theta = (2 * np.pi / 3 - theta) % (2 * np.pi)

    count = 1
    for height_i, (height_max, height_min) in enumerate(
        zip(height_div[:-2], height_div[1:])
    ):
        height_mask = (height_max >= height) & (height > height_min)
        for i in range(6):
            theta_min = np.pi * i / 3
            theta_max = np.pi * (i + 1) / 3
            theta_mask = (theta_min <= theta) & (theta < theta_max)
            result[height_mask & theta_mask] = count
            count += 1

    theta += 1 * np.pi / 12
    theta %= 2 * np.pi
    for height_i, (height_max, height_min) in enumerate(
        zip(height_div[2:], height_div[3:])
    ):
        height_mask = (height_max >= height) & (height > height_min)
        for i in range(4):
            theta_min = np.pi * i / 2
            theta_max = np.pi * (i + 1) / 2
            theta_mask = (theta_min <= theta) & (theta < theta_max)
            result[height_mask & theta_mask] = count
            count += 1

    return result


AHA_DEFAULT_HEIGHT_DIVISIONS = (1, 0.7, 0.4, 0.15)

__all__ = (
    "spherical_coordinates",
    "SphericalCoordinates",
    "aha",
    "AHA_DEFAULT_HEIGHT_DIVISIONS",
)
