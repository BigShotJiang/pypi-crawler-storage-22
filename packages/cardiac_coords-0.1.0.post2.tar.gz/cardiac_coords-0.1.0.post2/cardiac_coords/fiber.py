"""
Low-level interface for the estimation of rule-based fiber orientation
([Streeter](https://www.ahajournals.org/doi/10.1161/01.RES.24.3.339)).

See `cardiac_coords.CardiacCoordinates` for a higher-level interface.
"""

import numpy as np
from pyezzi import Domain, ThicknessSolver

from .types import BoolArray, FloatArray, PointLike, PointsLike


class LocalCoordinateSystem:
    def __init__(
        self, rho: FloatArray, radial: PointsLike, long_axis: PointLike
    ) -> None:
        self.radial = np.asarray(radial)
        self.rho = np.asarray(rho)

        cross_circ = np.cross(np.asarray(radial), np.asarray(long_axis))
        norm_cross_circ = np.linalg.norm(cross_circ, axis=1)
        self.circumferential = cross_circ / norm_cross_circ[:, None]

        self.longitudinal = np.cross(self.circumferential, np.asarray(radial))
        self.longitudinal /= np.linalg.norm(self.longitudinal, axis=1)[:, None]
        self.longitudinal[norm_cross_circ < 1e-5] = long_axis

    @staticmethod
    def from_masks(
        endo: BoolArray,
        epi: BoolArray,
        long_axis: PointLike,
        spacing: PointLike = (1.0, 1.0, 1.0),
    ) -> "LocalCoordinateSystem":
        thickness_solver = ThicknessSolver(Domain(endo, epi, spacing))
        thickness_solver.solve_laplacian()

        radial = thickness_solver.flat_gradients
        radial = radial.reshape((len(radial) // 3, 3))

        assert thickness_solver.flat_laplace is not None
        return LocalCoordinateSystem(
            thickness_solver.flat_laplace,
            radial,
            long_axis,
        )

    def streeter(
        self,
        epi_angle: float = np.deg2rad(-60),
        endo_angle: float = np.deg2rad(60),
    ) -> list[FloatArray]:
        """
        Rule-based method for fiber orientation
        ([Streeter](https://www.ahajournals.org/doi/10.1161/01.RES.24.3.339)).

        :param epi_angle: Angle, in radians, defining the fiber orientation
            at the epicardial surface.
        :param endo_angle: Angle, in radians, defining the fiber orientation
            at the endocardial surface.

        """
        angles = (np.asarray(self.rho) * (endo_angle - epi_angle)) + epi_angle

        fibers = []
        for r, lo, c, a in zip(
            self.radial, self.longitudinal, self.circumferential, angles
        ):
            fibers += [np.array([r, lo, c]).T @ [0, np.sin(a), np.cos(a)]]

        return fibers


__all__ = ("LocalCoordinateSystem",)
