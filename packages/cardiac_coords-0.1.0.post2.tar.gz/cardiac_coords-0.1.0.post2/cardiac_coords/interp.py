"""
This module implements interpolation methods that are suited for cardiac coordinates.
"""

import numpy as np
from scipy.interpolate import LinearNDInterpolator, NearestNDInterpolator

from .types import FloatArray, FloatArray2DLike, FloatArrayLike


class BaseInterpolator:
    """
    An abstract base class for custom interpolation methods for cardiac coordinates.

    Concrete subclasses MUST override `_post_init()` and `_interp()`, and SHOULD
    override `_scale_phi()`, `_scale_theta()` and `_scale_rho()`.

    """

    def __init__(
        self,
        phi: FloatArrayLike,
        theta: FloatArrayLike,
        rho: FloatArrayLike | None,
        values: FloatArrayLike,
        cyclic: bool = True,
    ) -> None:
        r"""
        :param phi: azimuthal angle $\phi$
        :param theta: polar angle $\theta$
        :param rho: Optionally, a third "depth in the myocardium" coordinate, cf `CardiacCoordinates.rho`.
        :param values: The values used for interpolation
        :param cyclic: This concatenates $\theta$ with $\theta - 2\pi$ and $\theta + 2\pi$, a trick to account for
            the fact that $\theta=2pi$ and $\theta0$ are actually the same point. Should be set to `False` when
            the interpolation method incorporates this fact somewhere else.
        """
        phi = self._scale_phi(phi)
        theta = self._scale_theta(theta)
        rho = None if rho is None else self._scale_rho(rho)

        if cyclic:
            phi = np.concatenate([phi, phi, phi])
            theta = np.concatenate([theta + 2 * np.pi, theta, theta - 2 * np.pi])
            values = np.concatenate([values, values, values])
            if rho is not None:
                rho = np.concatenate([rho, rho, rho])

        if rho is None:
            points = np.array([phi, theta]).T
        else:
            points = np.array([phi, theta, rho]).T

        self._post_init(points, values)  # type:ignore[arg-type]

    def _post_init(self, points: FloatArray, values: FloatArray) -> None:
        """
        Called after `__init__()`, with points being a `(n_points, x)`-shaped array (x=2 or 3 depending
        on whether `rho` was passed or not).
        @public
        """
        raise NotImplementedError

    def __call__(
        self,
        phi: FloatArrayLike,
        theta: FloatArrayLike,
        rho: FloatArrayLike | None = None,
    ) -> FloatArray:
        """
        Interpolate values for `points`.

        :return: values interpolated at coordinates `points`.
        """
        points_list = [self._scale_phi(phi), self._scale_theta(theta)]

        if rho is not None:
            points_list.append(self._scale_rho(rho))

        return self._interp(np.array(points_list).T)

    def _interp(self, points: FloatArray) -> FloatArray:
        raise NotImplementedError

    @staticmethod
    def _scale_phi(phi: FloatArrayLike) -> FloatArray:
        r"""
        Scale the values of $\phi$.
        @public
        """
        return np.asarray(phi) / np.pi

    @staticmethod
    def _scale_theta(theta: FloatArrayLike) -> FloatArray:
        r"""
        Scale the values of $\theta$.
        @public
        """
        return (np.asarray(theta) + np.pi) / (2 * np.pi)

    @staticmethod
    def _scale_rho(rho: FloatArrayLike) -> FloatArray:
        r"""
        Scale the values of $\rho$.
        @public
        """
        return np.asarray(rho) / 0.5


class HybridInterpolator(BaseInterpolator):
    """
    A hybrid interpolator:

    - linear interpolation for points inside the convex hull of source;
    - points, nearest neighbor when outside.
    """

    def __init__(
        self,
        phi: FloatArrayLike,
        theta: FloatArrayLike,
        rho: FloatArrayLike | None,
        values: FloatArrayLike,
        cyclic: bool = False,
    ) -> None:
        super().__init__(phi, theta, rho, values, cyclic)

    def _post_init(self, points: FloatArray, values: FloatArray) -> None:
        self._linear = LinearNDInterpolator(points, values, rescale=False)
        self._nearest = NearestNDInterpolator(points, values, rescale=False)

    def _interp(self, points: FloatArray) -> FloatArray:
        result = self._linear(points)
        nans = np.isnan(result)
        result[nans] = self._nearest(points[nans])
        return result


class InverseDistanceWeightingPolarInterpolator(BaseInterpolator):
    """
    Interpolation based on [inverse distance weighting](https://en.wikipedia.org/wiki/Inverse_distance_weighting).

    Good in theory but does not scale well with the data size.
    """

    def __init__(
        self,
        phi: FloatArrayLike,
        theta: FloatArrayLike,
        rho: FloatArrayLike | None,
        values: FloatArrayLike,
        p: float = 10,
    ) -> None:
        super().__init__(phi, theta, rho, values, cyclic=False)
        self.p = p
        # Avoid division by zero
        self._epsilon = 1e-25

    def _post_init(self, points: FloatArray, values: FloatArray) -> None:
        self._known_points = points
        self._known_values = values

    def _circular_distance(self, points: FloatArray2DLike) -> FloatArray:
        points = np.asarray(points)
        # Radial distance
        r_dist = np.abs(self._known_points[:, 0][:, np.newaxis] - points[:, 0])
        # Angular distance (accounting for circular nature)
        theta_dist = np.abs(self._known_points[:, 1][:, np.newaxis] - points[:, 1])
        theta_dist = np.minimum(theta_dist, 2 * np.pi - theta_dist)
        return np.sqrt(r_dist**2 + theta_dist**2)

    def _interp(self, points: FloatArray) -> FloatArray:
        weights = 1.0 / (self._circular_distance(points) + self._epsilon) ** self.p
        # Normalize weights
        weights /= weights.sum(axis=0)
        # Compute interpolated values
        return np.dot(self._known_values, weights)


class CyclicLinearInterpolator(BaseInterpolator):
    r"""
    A linear interpolator, accounting for the cyclic nature of $\theta$.

    Should be good for most use cases.
    """

    def _post_init(self, points: FloatArray, values: FloatArray) -> None:
        self._linear = LinearNDInterpolator(points, values, rescale=False)

    def _interp(self, points: FloatArray) -> FloatArray:
        return self._linear(points)


__all__ = (
    "CyclicLinearInterpolator",
    "InverseDistanceWeightingPolarInterpolator",
    "HybridInterpolator",
    "BaseInterpolator",
)
