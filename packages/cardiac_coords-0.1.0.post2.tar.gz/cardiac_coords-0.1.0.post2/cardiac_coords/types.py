from typing import Any, Sequence, TypedDict, TypeVar

import numpy as np
import numpy.typing as npt
from matplotlib.colors import Colormap

FloatArray = npt.NDArray[np.floating]
FloatArrayLike = Sequence[float] | FloatArray
PointLike = FloatArrayLike | Sequence[float] | tuple[float, float, float]
PointsLike = FloatArrayLike | Sequence[PointLike]
BoolArray = npt.NDArray[np.bool]
IntArray = npt.NDArray[np.uint8]
ArrayType = TypeVar("ArrayType", bound=npt.NDArray[Any])
AnyArray = npt.NDArray[Any]

FloatArray2D = npt.NDArray[np.floating]
FloatArray2DLike = npt.NDArray[np.floating] | Sequence[Sequence[float]]

MplColor = tuple[float, float, float] | tuple[float, float, float, float] | str


# not DRY, cf https://github.com/python/mypy/issues/4128 :(
class BullsEyePlotKwargs(TypedDict, total=False):
    img_size: int
    line_color: MplColor
    line_width: float
    cbar_ratio: float
    cmap: str | None | Colormap
    title: str | None
    height_divisions: tuple[float, float, float, float]
