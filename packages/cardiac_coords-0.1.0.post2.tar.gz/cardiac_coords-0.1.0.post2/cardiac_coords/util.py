import numpy as np

from .types import BoolArray


def ellipsoid_mask(
    radius: float,
    shape: tuple[int, int, int] = (30, 30, 30),
    eccentricity: float = 3.0,
) -> BoolArray:
    def ellipsoid(x: int, y: int, z: int) -> bool:
        return ((x - center[0]) / eccentricity) ** 2 + (y - center[1]) ** 2 + (
            z - center[2]
        ) ** 2 < radius

    center = [shape[0] // 10, shape[1] // 2, shape[2] // 2]
    return np.fromfunction(ellipsoid, shape)  # type:ignore[arg-type]


def epi_and_endo(
    shape: tuple[int, int, int] = (40, 25, 25),
    radii: tuple[float, float] = (120, 40),
    eccentricities: tuple[float, float] = (3, 5),
) -> tuple[BoolArray, BoolArray]:
    epi = ellipsoid_mask(radii[0], shape, eccentricities[0])
    endo = ellipsoid_mask(radii[1], shape, eccentricities[1])
    return epi, endo
