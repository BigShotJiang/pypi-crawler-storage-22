from pathlib import Path

import numpy as np
import pyvista as pv
from matplotlib import pyplot as plt
from matplotlib import transforms

from cardiac_coords import CardiacCoordinates
from cardiac_coords.util import epi_and_endo


def plot_local() -> None:
    epi, endo = epi_and_endo()
    epi = epi[::2, ::2, ::2]
    endo = endo[::2, ::2, ::2]
    coords = CardiacCoordinates(endo=endo, epi=epi)

    fig, axes = plt.subplots(ncols=3, nrows=1, figsize=(6, 2), layout="constrained")

    for ax in axes.ravel():
        ax.set_xticks([])
        ax.set_yticks([])
        ax.axis("equal")

    x, y = np.argwhere(coords.wall[0]).T

    u, v = coords.radial[0][coords.wall[0]].T[1:]
    axes[0].set_title("Radial")
    axes[0].quiver(x, y, u, v)

    u, v = coords.circumferential[0][coords.wall[0]].T[1:]
    axes[1].set_title("Circumferential")
    axes[1].quiver(x, y, u, v)

    x, y = np.argwhere(coords.wall[:, :, 5]).T
    uv = coords.longitudinal[:, :, 5][coords.wall[:, :, 5]].T[:2]
    rot = transforms.Affine2D().rotate_deg(-90)
    u, v = rot.get_matrix()[:2, :2] @ uv
    axes[2].set_title("Longitudinal")
    axes[2].quiver(x, y, u, v, transform=rot + axes[2].transData)

    plt.savefig(IMG_PATH / "local.png")
    plt.close(fig)


def plot_coords() -> None:
    epi, endo = epi_and_endo()
    coords = CardiacCoordinates(endo=endo, epi=epi)

    fig, axes = plt.subplot_mosaic(
        [["theta", "rho", "phi"]],
        figsize=(6, 2),
        layout="constrained",
    )

    for ax in axes.values():
        ax.set_xticks([])
        ax.set_yticks([])
        ax.axis("equal")

    axes["theta"].set_title(r"$\theta$")
    axes["phi"].set_title(r"$\phi$")
    axes["rho"].set_title(r"$\rho$")

    data = {
        "theta": (coords.theta[0], [-3.14, 3.14], [r"$-\pi$", r"$\pi$"], "hsv"),
        "phi": (coords.phi[:, :, 10], [0, 3.14], ["0", r"$\pi$"], "viridis"),
        "rho": (coords.rho[0], [0, 1], [0, 1], "viridis"),
    }

    for key, (array, ticks, labels, cmap) in data.items():
        im = axes[key].imshow(array, vmin=ticks[0], vmax=ticks[1], cmap=cmap)
        cbar = plt.colorbar(im, orientation="horizontal")
        cbar.set_ticks(ticks)
        if labels:
            cbar.set_ticklabels(labels)

    plt.savefig(IMG_PATH / "coords.png")
    plt.close(fig)


def angles_between(v1, v2):
    cross_product = np.cross(v1, v2)
    dot_product = np.sum(v1 * v2, axis=1)
    return np.arctan2(np.linalg.norm(cross_product, axis=1), dot_product)


def plot_fiber(off_screen: bool = True) -> None:
    epi, endo = epi_and_endo()
    coords = CardiacCoordinates(endo=endo, epi=epi)

    fiber = coords.streeter()[coords.wall]

    mesh = pv.PolyData(coords.wall_points)
    mesh["fiber"] = fiber
    mesh["circumferential"] = coords.circumferential[coords.wall]

    angles = angles_between(fiber, coords.circumferential[coords.wall]) * 180 / 3.14
    # this is cheating, for visualisation purposes, because trying to get the signed
    # angle in the local coordinates system made my head explode!
    angles[coords.rho[coords.wall] > 0.5] *= -1

    glyphs = mesh.glyph(orient="fiber", geom=pv.Arrow(), factor=3)
    glyphs["Angle with circumferential direction"] = np.repeat(
        angles, glyphs.n_points // mesh.n_points
    )
    glyphs = glyphs.clip("y")
    pl = pv.Plotter(off_screen=off_screen)
    pl.add_mesh(glyphs, scalars="Angle with circumferential direction")
    # pl.show_axes()
    print(
        pl.show(
            window_size=(600, 400),
            cpos=[
                (-2.1533932351912455, 53.87660196671265, 43.74034457979865),
                (15.82170428056006, 7.244727069571271, 9.848251652439217),
                (-0.38134099425735435, -0.6351663559216018, 0.671671606072555),
            ],
            screenshot=IMG_PATH / "fiber.png",
            return_cpos=True,
        )
    )


def plot_bullseye() -> None:
    epi, endo = epi_and_endo()
    coords = CardiacCoordinates(epi=epi, endo=endo)
    fig = coords.bullseye(coords.phi, title=r"$\phi$", cmap="inferno")
    fig.savefig(IMG_PATH / "bullseye-phi.png")


IMG_PATH = Path(__file__).parent

plot_bullseye()
# plot_fiber()
# plot_local()
# plot_coords()
