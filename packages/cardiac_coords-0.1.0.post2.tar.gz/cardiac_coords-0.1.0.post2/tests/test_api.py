import numpy as np
import pytest

from cardiac_coords import interp


@pytest.mark.parametrize(
    "name",
    [
        "phi",
        "theta",
        "rho",
        "distance",
        "circumferential",
        "radial",
        "longitudinal",
        "aha",
    ],
)
def test_coords(coords, reference_coords, name):
    computed = getattr(coords, name)[coords.wall]
    reference = np.array(reference_coords[name])
    if name == "circumferential":
        # point 40 is at the apex and results are undeterministic
        computed[40] = reference[40]
    diff = np.abs(computed - reference)
    bad = diff > 0.001
    where = np.where(bad)
    assert not np.any(bad), (where, diff[where], computed[where], reference[where])


@pytest.mark.parametrize(
    "inputs",
    [(70, -70), (60, -80), (120, 50)],
)
def test_streeter(coords, reference_streeter, inputs):
    computed = coords.streeter(*inputs)[coords.wall]
    reference = np.array(reference_streeter[inputs])
    # point 40 is at the apex and results are undeterministic
    computed[40] = reference[40]
    diff = np.abs(computed - reference)
    bad = diff > 0.001
    where = np.where(bad)
    assert not np.any(bad), (where, diff[where], computed[where], reference[where])


all_interpolators = pytest.mark.parametrize(
    "interp_cls",
    [
        interp.HybridInterpolator,
        interp.CyclicLinearInterpolator,
        interp.InverseDistanceWeightingPolarInterpolator,
    ],
)


@all_interpolators
def test_project_symmetric_flat(coords, interp_cls):
    original = np.arange(len(coords.wall_points))
    projected = np.round(coords.project(original, coords, interpolator_cls=interp_cls))
    assert np.all(projected == original)


@all_interpolators
def test_project_symmetric_3d(coords, interp_cls):
    original = np.full_like(coords.wall, np.nan, dtype=float)
    original[coords.wall] = np.arange(len(coords.wall_points))
    projected = np.round(coords.project(original, coords, interpolator_cls=interp_cls))
    assert np.array_equal(projected, original, equal_nan=True)


@all_interpolators
def test_project_symmetric_surface(surface_coords, interp_cls):
    original = np.arange(len(surface_coords.wall_points))
    projected = np.round(
        surface_coords.project(original, surface_coords, interpolator_cls=interp_cls)
    )
    assert np.all(projected == original)
