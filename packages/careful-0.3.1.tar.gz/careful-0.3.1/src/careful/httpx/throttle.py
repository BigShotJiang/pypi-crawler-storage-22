import time
import types
import functools
import logging
from typing import Protocol, cast, Callable
from httpx import Client, Response

log = logging.getLogger("careful")


class ThrottledClient(Protocol):
    _last_request: float
    _requests_per_minute: float
    _request_frequency: float
    _no_throttle_request: Callable
    request: Callable


def _throttle_request(client: ThrottledClient, *args, **kwargs) -> Response:
    now = time.time()
    diff = client._request_frequency - (now - client._last_request)
    if diff > 0:
        log.debug("throttled, sleeping for %fs", diff)
        time.sleep(diff)
        client._last_request = time.time()
    else:
        client._last_request = now
    return client._no_throttle_request(*args, **kwargs)


def make_throttled_client(
    *,
    client: Client | None = None,
    requests_per_minute: float = 0,
) -> Client:
    if requests_per_minute <= 0:
        raise ValueError("requests per minute must be a positive number")

    if client is None:
        client = Client()

    tclient = cast(ThrottledClient, client)

    tclient._last_request = 0.0
    tclient._requests_per_minute = requests_per_minute
    tclient._request_frequency = 60.0 / requests_per_minute

    tclient._no_throttle_request = client.request
    tclient.request = types.MethodType(
        functools.wraps(client.request)(_throttle_request), client
    )
    return client
