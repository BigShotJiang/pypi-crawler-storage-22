1. Pensez à bien mettre un titre d'issue explicite par rapport au bug
2. Pensez à essayer au maximum d'aider le support (non garanti) avec des informations les plus claires et précises
3. Pensez à mettre le label

/label ~"Kind - Proposal"

### Constat
(ce qui motive cette proposition)

### Proposition

**Résumé**

*Pensez à ajouter les labels associés à la proposition*


**Détails techniques de la proposition si applicable**


