"""Tests for the LLM module.

uv run pytest line/v02/llm/tests/ -v
"""
