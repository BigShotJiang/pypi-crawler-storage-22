"""Tests for Carve settings loading."""

from pathlib import Path

from carve.settings import CarveSettings, load_settings


class TestLanguageMapSettings:
    """Tests for language_map and import_map in carvesettings.toml."""

    def test_default_settings_have_empty_maps(self) -> None:
        """Default CarveSettings have empty language_map and import_map."""
        settings = CarveSettings()
        assert settings.language_map == {}
        assert settings.import_map == {}

    def test_load_language_map_from_toml(self, tmp_path: Path) -> None:
        """language_map is loaded from carvesettings.toml."""
        toml = tmp_path / "carvesettings.toml"
        toml.write_text('[language_map]\n".djhtml" = "jinja"\n".tsx" = "javascript"\n')
        settings = load_settings(tmp_path)
        assert settings.language_map == {".djhtml": "jinja", ".tsx": "javascript"}

    def test_load_import_map_from_toml(self, tmp_path: Path) -> None:
        """import_map is loaded from carvesettings.toml."""
        toml = tmp_path / "carvesettings.toml"
        toml.write_text('[import_map]\nmyLang = "tree_sitter_python"\n')
        settings = load_settings(tmp_path)
        assert settings.import_map == {"myLang": "tree_sitter_python"}

    def test_missing_maps_default_to_empty(self, tmp_path: Path) -> None:
        """Missing language_map/import_map keys default to empty dicts."""
        toml = tmp_path / "carvesettings.toml"
        toml.write_text("sidecars = true\n")
        settings = load_settings(tmp_path)
        assert settings.language_map == {}
        assert settings.import_map == {}

    def test_missing_file_returns_defaults(self, tmp_path: Path) -> None:
        """Missing carvesettings.toml returns default settings."""
        settings = load_settings(tmp_path)
        assert settings.language_map == {}
        assert settings.import_map == {}
