"""Tests for mutations on injected languages (JS/CSS inside HTML)."""

from __future__ import annotations

from pathlib import Path

import pytest

from carve.tools import (
    delete,
    insert,
    project_import,
    search,
    update,
)

HTML_WITH_SCRIPT_AND_STYLE = """\
<html>
<head>
<script>
function greet(name) {
  return "Hello " + name;
}
</script>
<style>
body { color: red; }
</style>
</head>
<body></body>
</html>
"""


@pytest.fixture
def html_file(tmp_path: Path) -> Path:
    """Write an HTML file with script and style elements."""
    p = tmp_path / "page.html"
    p.write_text(HTML_WITH_SCRIPT_AND_STYLE)
    return p


class TestInsertIntoScriptElement:
    def test_insert_js_function(self, html_file: Path) -> None:
        """Insert a plain JS function into a script_element."""
        store = project_import(str(html_file))
        results = search(store, node_type="script_element")
        assert results, "script_element not found"
        script_id = results[0]["node_id"]

        result = insert(
            store,
            script_id,
            "end",
            'function farewell(name) {\n  return "Bye " + name;\n}',
            prompt="Add farewell function",
            model="test",
            notes="test insert JS",
        )
        assert "error" not in result, result
        assert "node_id" in result

        # Verify the inserted function is discoverable via node_type search
        found = search(store, node_type="function_declaration", scope=script_id)
        assert len(found) >= 2, "Expected at least 2 functions after insert"

    def test_insert_js_with_comparison_operators(self, html_file: Path) -> None:
        """JS with >=, <=, && operators must not be rejected as HTML."""
        store = project_import(str(html_file))
        results = search(store, node_type="script_element")
        script_id = results[0]["node_id"]

        snippet = (
            "function clamp(val, lo, hi) {\n"
            "  if (val >= hi && val <= hi) {\n"
            "    return hi;\n"
            "  }\n"
            "  return val >= lo ? val : lo;\n"
            "}"
        )
        result = insert(
            store,
            script_id,
            "end",
            snippet,
            prompt="Add clamp function with comparison operators",
            model="test",
            notes="test >= and <= in JS",
        )
        assert "error" not in result, result


class TestInsertIntoCSSStyleElement:
    def test_insert_css_rule(self, html_file: Path) -> None:
        """Insert a CSS rule into a style_element."""
        store = project_import(str(html_file))
        results = search(store, node_type="style_element")
        assert results, "style_element not found"
        style_id = results[0]["node_id"]

        result = insert(
            store,
            style_id,
            "end",
            ".highlight { background: yellow; }",
            prompt="Add highlight rule",
            model="test",
            notes="test insert CSS",
        )
        assert "error" not in result, result
        assert "node_id" in result


class TestUpdateInjectedNodes:
    def test_update_js_function(self, html_file: Path) -> None:
        """Update an existing JS function inside a script_element."""
        store = project_import(str(html_file))
        results = search(store, pattern="greet")
        assert results, "greet function not found"
        greet_id = results[0]["node_id"]

        result = update(
            store,
            greet_id,
            'function greet(name) {\n  return "Hi " + name + "!";\n}',
            prompt="Change greeting text",
            model="test",
            notes="test update JS",
        )
        assert "error" not in result, result
        assert result.get("success") is True

    def test_update_css_rule(self, html_file: Path) -> None:
        """Update an existing CSS rule inside a style_element."""
        store = project_import(str(html_file))
        results = search(store, node_type="rule_set")
        assert results, "No CSS rule_set found"
        rule_id = results[0]["node_id"]

        result = update(
            store,
            rule_id,
            "body { color: blue; font-size: 16px; }",
            prompt="Change body style",
            model="test",
            notes="test update CSS",
        )
        assert "error" not in result, result
        assert result.get("success") is True


class TestDeleteInjectedNodes:
    def test_delete_js_function(self, html_file: Path) -> None:
        """Delete a JS function from a script_element."""
        store = project_import(str(html_file))
        results = search(store, pattern="greet")
        assert results, "greet function not found"
        greet_id = results[0]["node_id"]

        result = delete(store, greet_id, notes="test delete JS")
        assert "error" not in result, result
        assert result.get("success") is True

        # Verify the function is gone
        post = search(store, pattern="greet")
        assert not any(r["node_id"] == greet_id for r in post)


class TestBatchInjectedNodes:
    def test_batch_insert_and_update(self, html_file: Path) -> None:
        """Batch with insert + update on injected nodes."""
        from carve.tools import batch

        store = project_import(str(html_file))
        results = search(store, pattern="greet")
        greet_id = results[0]["node_id"]

        script_results = search(store, node_type="script_element")
        script_id = script_results[0]["node_id"]

        result = batch(
            store,
            [
                {
                    "tool": "update",
                    "kwargs": {
                        "node_id": greet_id,
                        "snippet": 'function greet(name) {\n  return "Hey " + name;\n}',
                        "prompt": "batch update",
                        "model": "test",
                        "notes": "batch update JS",
                    },
                },
                {
                    "tool": "insert",
                    "kwargs": {
                        "parent_id": script_id,
                        "position": "end",
                        "snippet": "function add(a, b) {\n  return a + b;\n}",
                        "prompt": "batch insert",
                        "model": "test",
                        "notes": "batch insert JS",
                    },
                },
            ],
            notes="batch test",
        )
        assert result.get("success") is True, result

        # Verify both mutations applied
        found = search(store, pattern="add")
        assert any("add" in r["node_id"] for r in found)


class TestSearchFindsInjectedNodes:
    def test_search_finds_js_function(self, html_file: Path) -> None:
        """search() should find JS functions injected into HTML."""
        store = project_import(str(html_file))
        results = search(store, pattern="greet")
        assert results
        assert any("greet" in r["node_id"] for r in results)

    def test_search_finds_css_rule(self, html_file: Path) -> None:
        """search() should find CSS rules injected into HTML."""
        store = project_import(str(html_file))
        results = search(store, node_type="rule_set")
        assert results
