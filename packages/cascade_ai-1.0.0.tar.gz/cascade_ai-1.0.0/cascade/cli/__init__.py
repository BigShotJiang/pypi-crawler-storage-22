"""CLI module for Cascade."""
