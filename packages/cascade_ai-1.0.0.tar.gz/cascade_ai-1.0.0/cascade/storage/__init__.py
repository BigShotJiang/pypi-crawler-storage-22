"""Storage layer for Cascade."""
