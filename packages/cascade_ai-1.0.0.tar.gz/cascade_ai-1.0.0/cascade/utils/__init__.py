"""Utility functions for Cascade."""
