"""
Cascade SDK - Agent Observability Platform
"""

__version__ = "0.2.0b10"

from cascade.tracing import init_tracing, trace_run, trace_agent, get_tracer, get_current_agent
from cascade.llm_wrappers import wrap_llm_client
from cascade.tool_decorator import tool, function
from cascade.celestra_extensions import capture_reasoning
from cascade.evaluations import (
    CascadeEval,
    evaluate,
    get_failures,
    list_projects,
    list_traces,
    get_trace,
    get_trace_tree,
)

__all__ = [
    # Tracing
    "init_tracing",
    "trace_run",
    "trace_agent",
    "get_tracer",
    "get_current_agent",
    "wrap_llm_client",
    "tool",
    "function",
    "capture_reasoning",
    # Evaluation (full control)
    "CascadeEval",
    # Evaluation (convenience)
    "evaluate",
    "get_failures",
    # Traces & Projects (convenience)
    "list_projects",
    "list_traces",
    "get_trace",
    "get_trace_tree",
]

