"""Cased CLI - Query telemetry from your terminal."""

__version__ = "0.3.0"
