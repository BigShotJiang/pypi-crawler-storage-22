#!/usr/bin/env python3
"""
Cased CLI - Query telemetry from your terminal.

Usage:
    cased logs                       # last 100 logs
    cased logs --tail 50             # last 50 logs
    cased logs -f                    # follow (live tail)
    cased logs -f --tail 20          # follow with context
    cased errors --since 1h
    cased traces --service demo-web
    cased metrics --pod my-pod
    cased stats
    cased clusters
    cased investigate <event_id>   # Open error in Claude Code

Environment:
    CASED_API_KEY: Your Cased API key
    CASED_API_URL: API endpoint (default: https://app.cased.com)
"""

import json
import os
import sys
import time
import webbrowser
from pathlib import Path

import click
import httpx
from rich.console import Console
from rich.table import Table

from cased_cli.url_handler import SUPPORTED_APPS, install_url_handler

console = Console()

DEFAULT_API_URL = "https://app.cased.com"


def parse_since_to_hours(since: str) -> int:
    """Convert time string like '24h', '7d' to hours integer."""
    since = since.strip().lower()
    try:
        if since.endswith("h"):
            return int(since[:-1])
        elif since.endswith("d"):
            return int(since[:-1]) * 24
        elif since.endswith("w"):
            return int(since[:-1]) * 24 * 7
        else:
            # Assume hours if no suffix
            return int(since)
    except ValueError:
        return 24  # Default to 24 hours
CONFIG_DIR = Path.home() / ".config" / "cased"
CONFIG_FILE = CONFIG_DIR / "config.json"


def load_config_file():
    """Load configuration from config file."""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}
    return {}


def save_config(token: str, api_url: str = DEFAULT_API_URL, default_app: str = None):
    """Save configuration to file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config_data = {"token": token, "api_url": api_url}
    if default_app:
        config_data["default_app"] = default_app
    # Preserve existing default_app if not specified
    elif CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                existing = json.load(f)
                if existing.get("default_app"):
                    config_data["default_app"] = existing["default_app"]
        except (json.JSONDecodeError, IOError):
            pass
    with open(CONFIG_FILE, "w") as f:
        json.dump(config_data, f, indent=2)
    # Set restrictive permissions
    CONFIG_FILE.chmod(0o600)


def get_config():
    """Get API configuration from environment or config file."""
    # Priority: env vars > config file
    api_key = os.environ.get("CASED_API_KEY")
    api_url = os.environ.get("CASED_API_URL", DEFAULT_API_URL)

    if not api_key:
        config = load_config_file()
        api_key = config.get("token")
        api_url = config.get("api_url", api_url)

    if not api_key:
        console.print("[red]Error: Not authenticated[/red]")
        console.print("Run: cased configure")
        sys.exit(1)

    return api_key, api_url


def make_request(endpoint: str, params: dict = None) -> dict:
    """Make authenticated request to Cased telemetry API."""
    api_key, api_url = get_config()

    url = f"{api_url}/api/v1/telemetry/query/{endpoint}/"
    headers = {"Authorization": f"Bearer {api_key}"}

    try:
        response = httpx.get(url, params=params, headers=headers, timeout=30)
        response.raise_for_status()
        return response.json()
    except httpx.HTTPStatusError as e:
        console.print(f"[red]API Error: {e.response.status_code}[/red]")
        try:
            error = e.response.json()
            console.print(f"[red]{error.get('error', 'Unknown error')}[/red]")
        except Exception:
            console.print(f"[red]{e.response.text}[/red]")
        sys.exit(1)
    except httpx.RequestError as e:
        console.print(f"[red]Connection Error: {e}[/red]")
        sys.exit(1)


def make_agent_request(endpoint: str, params: dict = None) -> dict:
    """Make authenticated request to Cased agent API."""
    api_key, api_url = get_config()

    url = f"{api_url}/api/v1/agent/{endpoint}"
    headers = {"Authorization": f"Bearer {api_key}"}

    try:
        response = httpx.get(url, params=params, headers=headers, timeout=30)
        response.raise_for_status()
        return response.json()
    except httpx.HTTPStatusError as e:
        console.print(f"[red]API Error: {e.response.status_code}[/red]")
        try:
            error = e.response.json()
            console.print(f"[red]{error.get('detail', error.get('error', 'Unknown error'))}[/red]")
        except Exception:
            console.print(f"[red]{e.response.text}[/red]")
        sys.exit(1)
    except httpx.RequestError as e:
        console.print(f"[red]Connection Error: {e}[/red]")
        sys.exit(1)


@click.group()
@click.version_option(version="0.3.0")
def cli():
    """Cased CLI - Query telemetry from your terminal.

    Query errors, traces, and metrics collected by cased-agent.
    Designed to work with Claude Code for AI-native observability.

    Set CASED_API_KEY to authenticate.
    """
    pass


@cli.command()
@click.option("--since", default="24h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--level", help="Filter by level (error, warning, fatal)")
@click.option("--search", help="Search in exception type/value")
@click.option("--project", help="Filter by project ID")
@click.option("--limit", default=50, help="Max results")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def errors(since, level, search, project, limit, output_json):
    """Query error events.

    Examples:
        cased errors --since 1h
        cased errors --level error --search "KeyError"
        cased errors --since 7d --json
    """
    hours_back = parse_since_to_hours(since)
    params = {"hours_back": hours_back, "limit": limit}
    if level:
        params["level"] = level
    if search:
        params["query"] = search  # API expects 'query' not 'search'
    if project:
        params["project_id"] = project

    data = make_request("errors", params)
    events = data.get("errors", [])  # API returns 'errors' not 'events'

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    if not events:
        console.print("[yellow]No errors found[/yellow]")
        return

    table = Table(title=f"Errors (last {hours_back}h)")
    table.add_column("Event ID", style="cyan", max_width=12)
    table.add_column("Time", style="dim")
    table.add_column("Level", style="bold")
    table.add_column("Exception")
    table.add_column("Message", max_width=50)
    table.add_column("Env")

    for e in events:
        event_id = e.get("event_id", "")
        # Show first 8 chars of event_id for readability
        short_id = event_id[:8] + "..." if len(event_id) > 8 else event_id
        timestamp = e.get("timestamp", "")[:19]
        level_val = e.get("level", "")
        level_style = "red" if level_val in ("error", "fatal") else "yellow"
        table.add_row(
            short_id,
            timestamp,
            f"[{level_style}]{level_val}[/{level_style}]",
            e.get("exception_type") or "-",
            (e.get("exception_value") or "-")[:50],
            e.get("environment") or "-",
        )

    console.print(table)
    console.print(f"\n[dim]Total: {data.get('count', len(events))} errors | Use 'cased investigate <event_id>' for details[/dim]")


@cli.command()
@click.option("--since", default="1h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--cluster", help="Filter by cluster ID")
@click.option("--service", help="Filter by service name")
@click.option("--trace-id", help="Get all spans for a specific trace")
@click.option("--status", help="Filter by status (ok, error)")
@click.option("--limit", default=50, help="Max results")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def traces(since, cluster, service, trace_id, status, limit, output_json):
    """Query distributed traces.

    Examples:
        cased traces --since 1h
        cased traces --service demo-web --status error
        cased traces --trace-id abc123...
    """
    hours_back = parse_since_to_hours(since)
    params = {"hours_back": hours_back, "limit": limit}
    if cluster:
        params["cluster_id"] = cluster
    if service:
        params["service"] = service  # API expects 'service' not 'service_name'
    if trace_id:
        params["trace_id"] = trace_id
        params["action"] = "trace"  # Use action=trace for specific trace
    if status:
        params["status"] = status

    data = make_request("traces", params)
    spans = data.get("spans", [])

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    if not spans:
        console.print("[yellow]No traces found[/yellow]")
        return

    table = Table(title=f"Traces (last {since})")
    table.add_column("Time", style="dim")
    table.add_column("Service")
    table.add_column("Operation")
    table.add_column("Duration", justify="right")
    table.add_column("Status")
    table.add_column("HTTP")

    for s in spans:
        timestamp = s.get("timestamp", "")[:19]
        status_val = s.get("status_code", "ok")
        status_style = "red" if status_val == "error" else "green"
        duration = f"{s.get('duration_ms', 0):.2f}ms"
        http_info = ""
        if s.get("http_method"):
            http_info = f"{s.get('http_method')} {s.get('http_status_code', '')}"

        table.add_row(
            timestamp,
            s.get("service_name") or "-",
            s.get("span_name") or "-",
            duration,
            f"[{status_style}]{status_val}[/{status_style}]",
            http_info,
        )

    console.print(table)
    console.print(f"\n[dim]Total: {data.get('total', len(spans))} spans[/dim]")


@cli.command()
@click.option("--since", default="1h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--cluster", help="Filter by cluster ID")
@click.option("--namespace", help="Filter by namespace")
@click.option("--pod", help="Filter by pod name")
@click.option("--metric", help="Filter by metric name (cpu_percent, memory_bytes)")
@click.option("--limit", default=50, help="Max results")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def metrics(since, cluster, namespace, pod, metric, limit, output_json):
    """Query container metrics.

    Examples:
        cased metrics --since 1h
        cased metrics --pod my-pod-abc123
        cased metrics --metric cpu_percent --namespace default
    """
    params = {"since": since, "limit": limit}
    if cluster:
        params["cluster_id"] = cluster
    if namespace:
        params["namespace"] = namespace
    if pod:
        params["pod_name"] = pod
    if metric:
        params["metric_name"] = metric

    data = make_request("metrics", params)
    metrics_data = data.get("metrics", [])

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    if not metrics_data:
        console.print("[yellow]No metrics found[/yellow]")
        return

    table = Table(title=f"Metrics (last {since})")
    table.add_column("Time", style="dim")
    table.add_column("Pod")
    table.add_column("Container")
    table.add_column("Metric")
    table.add_column("Value", justify="right")

    for m in metrics_data:
        timestamp = m.get("timestamp", "")[:19]
        value = m.get("value", 0)
        metric_name = m.get("metric_name", "")

        # Format value based on metric type
        if "percent" in metric_name:
            value_str = f"{value:.1f}%"
        elif "bytes" in metric_name:
            value_str = f"{value / 1024 / 1024:.1f}MB"
        else:
            value_str = f"{value:.2f}"

        table.add_row(
            timestamp,
            m.get("pod_name") or "-",
            m.get("container_name") or "-",
            metric_name,
            value_str,
        )

    console.print(table)
    console.print(f"\n[dim]Total: {data.get('total', len(metrics_data))} metrics[/dim]")


@cli.command()
@click.option("--since", default="1h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--tail", "-n", default=100, help="Number of lines to show (default: 100)")
@click.option("--level", "-l", help="Filter by level (trace, debug, info, warn, error, fatal)")
@click.option("--service", "-s", help="Filter by service name")
@click.option("--search", "-q", help="Search in log messages")
@click.option("--follow", "-f", is_flag=True, help="Follow logs in real-time")
@click.option("--timestamps", "-t", is_flag=True, help="Show full timestamps")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def logs(since, tail, level, service, search, follow, timestamps, output_json):
    """Query application logs.

    Examples:
        cased logs                       # last 100 logs
        cased logs --tail 50             # last 50 logs
        cased logs -f                    # follow (live tail)
        cased logs -f --tail 20          # follow with 20 lines context
        cased logs --since 1h -l error   # errors from last hour
        cased logs -s api-server         # filter by service
        cased logs -q "timeout"          # search messages
        cased logs -t                    # show full timestamps
    """
    import time

    params = {"since": since, "limit": tail}
    if level:
        params["level"] = level
    if service:
        params["service_name"] = service
    if search:
        params["search"] = search

    def fetch_logs():
        return make_request("logs", params)

    def format_level(lvl, short=True):
        """Color-code log levels."""
        colors = {
            "fatal": "red bold",
            "error": "red",
            "warn": "yellow",
            "info": "blue",
            "debug": "dim",
            "trace": "dim",
        }
        short_names = {
            "fatal": "FTL",
            "error": "ERR",
            "warn": "WRN",
            "info": "INF",
            "debug": "DBG",
            "trace": "TRC",
        }
        style = colors.get(lvl, "white")
        label = short_names.get(lvl, lvl[:3].upper()) if short else lvl.upper()
        return f"[{style}]{label}[/{style}]"

    def print_log(log, show_timestamps=False):
        """Print a single log entry."""
        full_ts = log.get("timestamp", "")
        lvl = log.get("level", "info")
        svc = log.get("service_name") or "-"
        msg = log.get("message", "")

        if show_timestamps:
            # Full timestamp mode (like docker logs -t)
            timestamp = full_ts[:23]
            console.print(
                f"[dim]{timestamp}[/dim] {format_level(lvl)} [cyan]{svc[:15]:15}[/cyan] {msg}"
            )
        else:
            # Compact: short time, 3-char level, clean format
            timestamp = full_ts[11:19] if len(full_ts) > 19 else full_ts[:8]
            # Truncate message if too long
            max_msg_len = 80
            display_msg = msg[:max_msg_len] + "..." if len(msg) > max_msg_len else msg
            console.print(
                f"[dim]{timestamp}[/dim] {format_level(lvl)} [cyan]{svc[:15]:15}[/cyan] {display_msg}"
            )

    if follow:
        # Live tail mode - show initial context then stream
        seen_ids = set()

        # First fetch for context (respects --tail)
        data = fetch_logs()
        logs_data = data.get("logs", [])

        # Print initial context in chronological order
        for log in reversed(logs_data):
            print_log(log, show_timestamps=timestamps)
            seen_ids.add(log.get("log_id"))

        console.print("[bold green]● Live[/bold green] [dim](Ctrl+C to stop)[/dim]\n")

        try:
            while True:
                time.sleep(2)  # Poll every 2 seconds
                data = fetch_logs()
                logs_data = data.get("logs", [])

                # Print only new logs (in chronological order)
                new_logs = [log for log in reversed(logs_data) if log.get("log_id") not in seen_ids]

                for log in new_logs:
                    print_log(log, show_timestamps=timestamps)
                    seen_ids.add(log.get("log_id"))

                # Keep seen_ids from growing too large
                if len(seen_ids) > 1000:
                    seen_ids = set(list(seen_ids)[-500:])

        except KeyboardInterrupt:
            console.print("\n[dim]Stopped[/dim]")
            return

    # Normal mode
    data = fetch_logs()
    logs_data = data.get("logs", [])

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    if not logs_data:
        console.print("[yellow]No logs found[/yellow]")
        return

    # Print logs (newest first)
    for log in logs_data:
        print_log(log, show_timestamps=timestamps)

    console.print(f"\n[dim]{len(logs_data)} logs[/dim]")


@cli.command()
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def stats(output_json):
    """Get telemetry statistics summary.

    Shows overall counts and recent activity.
    """
    data = make_request("stats")

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    events = data.get("events", {})
    metrics_stats = data.get("metrics", {})
    traces_stats = data.get("traces", {})

    console.print("\n[bold]Telemetry Statistics[/bold]\n")

    # Events
    console.print("[bold cyan]Events[/bold cyan]")
    console.print(f"  Total events: {events.get('total_events', 0):,}")
    console.print(f"  Errors: [red]{events.get('error_count', 0):,}[/red]")
    console.print(f"  Fatal: [red]{events.get('fatal_count', 0):,}[/red]")
    console.print(f"  Last hour: {events.get('events_last_hour', 0):,}")
    console.print(f"  Last 24h: {events.get('events_last_24h', 0):,}")

    # Metrics
    console.print("\n[bold cyan]Metrics[/bold cyan]")
    console.print(f"  Total metrics: {metrics_stats.get('total_metrics', 0):,}")
    console.print(f"  Clusters: {metrics_stats.get('unique_clusters', 0)}")
    console.print(f"  Pods: {metrics_stats.get('unique_pods', 0)}")
    console.print(f"  Last hour: {metrics_stats.get('metrics_last_hour', 0):,}")

    # Traces
    console.print("\n[bold cyan]Traces[/bold cyan]")
    console.print(f"  Total spans: {traces_stats.get('total_spans', 0):,}")
    console.print(f"  Unique traces: {traces_stats.get('unique_traces', 0):,}")
    console.print(f"  Services: {traces_stats.get('unique_services', 0)}")
    console.print(f"  Last hour: {traces_stats.get('spans_last_hour', 0):,}")


@cli.command()
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def clusters(output_json):
    """List clusters with telemetry data.

    Shows all clusters that have sent metrics.
    """
    data = make_request("clusters")
    clusters_data = data.get("clusters", [])

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    if not clusters_data:
        console.print("[yellow]No clusters found[/yellow]")
        return

    table = Table(title="Clusters")
    table.add_column("Cluster ID")
    table.add_column("Namespaces", justify="right")
    table.add_column("Pods", justify="right")
    table.add_column("Metrics", justify="right")
    table.add_column("Last Seen", style="dim")

    for c in clusters_data:
        last_seen = c.get("last_seen", "")[:19] if c.get("last_seen") else "-"
        table.add_row(
            c.get("cluster_id") or "-",
            str(c.get("namespace_count", 0)),
            str(c.get("pod_count", 0)),
            f"{c.get('metric_count', 0):,}",
            last_seen,
        )

    console.print(table)
    console.print(f"\n[dim]Total: {data.get('total', len(clusters_data))} clusters[/dim]")


@cli.group()
def docs():
    """Manage knowledge base documents.

    Upload documentation to help Cased understand your organization.

    Examples:
        cased docs upload README.md
        cased docs upload --title "API Guide" api-docs.md
        cat notes.txt | cased docs upload --title "Meeting Notes" -
    """
    pass


@docs.command()
@click.argument("file", type=click.Path(exists=False), required=True)
@click.option("--title", "-t", help="Document title (default: filename)")
@click.option("--cleanup", is_flag=True, help="Clean up content with AI")
@click.option(
    "--format",
    "content_format",
    type=click.Choice(["markdown", "text", "conversation"]),
    default="markdown",
    help="Content format (default: markdown)",
)
def upload(file, title, cleanup, content_format):
    """Upload a document to the knowledge base.

    FILE can be a path to a file or '-' to read from stdin.

    Examples:
        cased docs upload README.md
        cased docs upload --title "Deployment Guide" docs/deploy.md
        cased docs upload --cleanup --format conversation meeting-notes.txt
        cat architecture.md | cased docs upload --title "Architecture" -
    """
    api_key, api_url = get_config()

    # Read content from file or stdin
    if file == "-":
        content = sys.stdin.read()
        if not title:
            console.print("[red]Error: --title is required when reading from stdin[/red]")
            sys.exit(1)
    else:
        file_path = click.Path(exists=True).convert(file, None, None)
        with open(file_path) as f:
            content = f.read()
        if not title:
            # Use filename without extension as title
            title = os.path.splitext(os.path.basename(file_path))[0]
            # Convert kebab-case or snake_case to Title Case
            title = title.replace("-", " ").replace("_", " ").title()

    if not content.strip():
        console.print("[red]Error: File is empty[/red]")
        sys.exit(1)

    # Check size limit (100KB)
    if len(content) > 100 * 1024:
        console.print("[red]Error: File too large (max 100KB)[/red]")
        sys.exit(1)

    # Upload to API
    url = f"{api_url}/api/v1/docs/"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "title": title,
        "content": content,
        "format": content_format,
        "cleanup": cleanup,
    }

    try:
        with console.status(f"Uploading '{title}'..."):
            response = httpx.post(url, json=payload, headers=headers, timeout=60)
            response.raise_for_status()
            data = response.json()

        console.print(f"[green]✓[/green] {data.get('message', 'Upload successful')}")
        if data.get("id"):
            console.print(f"[dim]Document ID: {data['id']}[/dim]")

    except httpx.HTTPStatusError as e:
        console.print(f"[red]Error: {e.response.status_code}[/red]")
        try:
            error = e.response.json()
            console.print(f"[red]{error.get('error', 'Unknown error')}[/red]")
        except Exception:
            console.print(f"[red]{e.response.text}[/red]")
        sys.exit(1)
    except httpx.RequestError as e:
        console.print(f"[red]Connection Error: {e}[/red]")
        sys.exit(1)


@cli.command()
@click.option("--since", default="24h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--status", help="Filter by status (created, agent_running, completed, failed, cancelled)")
@click.option("--type", "session_type", help="Filter by type (deploy_monitor, root_cause_analysis, general)")
@click.option("--limit", default=20, help="Max results")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def sessions(since, status, session_type, limit, output_json):
    """List AI agent sessions.

    Examples:
        cased sessions --since 24h
        cased sessions --status completed
        cased sessions --type root_cause_analysis
    """
    params = {"since": since, "limit": limit}
    if status:
        params["status"] = status
    if session_type:
        params["session_type"] = session_type

    data = make_agent_request("sessions/", params)

    # Handle paginated response
    if isinstance(data, dict) and "results" in data:
        sessions_data = data.get("results", [])
        total = data.get("count", len(sessions_data))
    else:
        sessions_data = data if isinstance(data, list) else []
        total = len(sessions_data)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    if not sessions_data:
        console.print("[yellow]No sessions found[/yellow]")
        return

    table = Table(title=f"Agent Sessions (last {since})")
    table.add_column("Time", style="dim")
    table.add_column("ID")
    table.add_column("Status")
    table.add_column("Type")
    table.add_column("Agent")
    table.add_column("Summary", max_width=40)

    for s in sessions_data:
        timestamp = s.get("created_at", "")[:19]
        session_id = s.get("id", "")[:12]
        status_val = s.get("session_status", "")

        # Color status
        status_colors = {
            "completed": "green",
            "failed": "red",
            "cancelled": "yellow",
            "agent_running": "cyan",
            "tool_executing": "cyan",
            "pending_user_input": "magenta",
        }
        status_style = status_colors.get(status_val, "white")

        # Get summary title if available
        summary = s.get("session_summary", {})
        summary_text = ""
        if isinstance(summary, dict):
            summary_text = summary.get("title", "") or summary.get("description", "")
        if not summary_text:
            summary_text = s.get("starting_agent_category", "") or "-"

        table.add_row(
            timestamp,
            session_id,
            f"[{status_style}]{status_val}[/{status_style}]",
            s.get("session_type", "-") or "-",
            s.get("starting_agent_category", "-") or "-",
            (summary_text or "-")[:40],
        )

    console.print(table)
    console.print(f"\n[dim]Total: {total} sessions[/dim]")


@cli.command()
@click.argument("session_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.option("--logs", is_flag=True, help="Show execution logs")
@click.option("--conversation", is_flag=True, help="Show conversation history")
def session(session_id, output_json, logs, conversation):
    """Get details for a specific agent session.

    Examples:
        cased session abc123
        cased session abc123 --logs
        cased session abc123 --conversation
    """
    data = make_agent_request(f"sessions/{session_id}/")

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    # Basic info
    console.print(f"\n[bold]Session {data.get('id', session_id)}[/bold]\n")

    status_val = data.get("session_status", "unknown")
    status_colors = {
        "completed": "green",
        "failed": "red",
        "cancelled": "yellow",
        "agent_running": "cyan",
    }
    status_style = status_colors.get(status_val, "white")

    console.print(f"  Status: [{status_style}]{status_val}[/{status_style}]")
    console.print(f"  Type: {data.get('session_type', '-')}")
    console.print(f"  Agent: {data.get('starting_agent_category', '-')}")
    console.print(f"  Model: {data.get('llm_model', '-')} ({data.get('model_provider', '-')})")
    console.print(f"  Created: {data.get('created_at', '-')[:19]}")
    console.print(f"  Updated: {data.get('updated_at', '-')[:19]}")

    # Summary
    summary = data.get("session_summary", {})
    if isinstance(summary, dict) and summary:
        console.print("\n[bold cyan]Summary[/bold cyan]")
        if summary.get("title"):
            console.print(f"  {summary.get('title')}")
        if summary.get("description"):
            console.print(f"  {summary.get('description')}")
        if summary.get("outcome"):
            console.print(f"  Outcome: {summary.get('outcome')}")
        if summary.get("key_actions"):
            console.print("  Actions:")
            for action in summary.get("key_actions", [])[:5]:
                console.print(f"    - {action}")

    # Execution logs (if requested)
    if logs:
        exec_logs = data.get("execution_logs", [])
        if exec_logs:
            console.print("\n[bold cyan]Execution Logs[/bold cyan]")
            for log in exec_logs[-20:]:  # Last 20 logs
                log_type = log.get("type", "info")
                log_style = "red" if log_type == "error" else "dim"
                console.print(f"  [{log_style}][{log_type}] {log.get('message', '')}[/{log_style}]")
        else:
            console.print("\n[dim]No execution logs[/dim]")

    # Conversation (if requested)
    if conversation:
        conv = data.get("conversation", [])
        if conv:
            console.print("\n[bold cyan]Conversation[/bold cyan]")
            for msg in conv[-10:]:  # Last 10 messages
                role = msg.get("role", "unknown")
                role_style = "green" if role == "assistant" else "blue"
                content = msg.get("content", "")
                if isinstance(content, str):
                    content = content[:200] + "..." if len(content) > 200 else content
                console.print(f"  [{role_style}]{role}:[/{role_style}] {content}")
        else:
            console.print("\n[dim]No conversation history[/dim]")


def validate_token(token: str, api_url: str = DEFAULT_API_URL) -> dict | None:
    """Validate a token and return user info if valid."""
    try:
        response = httpx.post(
            f"{api_url}/api/v1/cli/auth/validate",
            json={"token": token},
            timeout=10,
            follow_redirects=True,
        )
        if response.status_code == 200:
            data = response.json()
            if data.get("valid"):
                return data
    except Exception:
        pass
    return None


@cli.command()
@click.option("--force", is_flag=True, help="Re-authenticate even if already configured")
@click.option("--api-url", default=DEFAULT_API_URL, help="Cased API URL")
def configure(force, api_url):
    """Configure Cased CLI via web authentication.

    Opens your browser to authenticate with Cased and saves credentials locally.
    """
    console.print("[bold]Cased CLI Configuration[/bold]\n")

    # Check for existing authentication
    existing_token = os.environ.get("CASED_API_KEY")
    if not existing_token:
        config = load_config_file()
        existing_token = config.get("token")
        if config.get("api_url"):
            api_url = config.get("api_url")

    if existing_token and not force:
        # Validate token still works
        user_info = validate_token(existing_token, api_url)
        if user_info:
            console.print("[green]Already authenticated![/green]")
            console.print(f"  User: {user_info['user']['email']}")
            console.print(f"  Organization: {user_info['organization']['name']}")
            if CONFIG_FILE.exists():
                console.print(f"  Config: {CONFIG_FILE}")
            else:
                console.print("  [dim](using environment variable)[/dim]")
            console.print("\nRun 'cased configure --force' to re-authenticate")
            return

    # Initiate device code auth flow
    try:
        response = httpx.post(
            f"{api_url}/api/v1/cli/auth/initiate",
            json={},
            timeout=10,
            follow_redirects=True,
        )
        if response.status_code != 200:
            console.print(f"[red]API Error: {response.status_code}[/red]")
            console.print(f"[dim]Response: {response.text[:500]}[/dim]")
            return
        data = response.json()

        # Check for expected fields
        if "device_code" not in data:
            console.print(f"[red]Unexpected API response:[/red]")
            console.print(f"[dim]{data}[/dim]")
            console.print("\n[yellow]The API may not support device code auth yet.[/yellow]")
            sys.exit(1)

        device_code = data["device_code"]
        user_code = data["user_code"]
        verification_uri = data["verification_uri"]

        # Display the code prominently
        console.print()
        console.print("[bold]Enter this code in your browser:[/bold]")
        console.print()
        console.print(f"    [bold cyan]{user_code}[/bold cyan]")
        console.print()
        console.print(f"Visit: [link={verification_uri}]{verification_uri}[/link]")
        console.print()

        # Try to open browser
        try:
            webbrowser.open(verification_uri)
            console.print("[dim]Browser opened automatically[/dim]")
        except Exception:
            pass

        # Poll for completion
        console.print("\nWaiting for authorization...", end="")
        poll_interval = 2  # seconds
        max_attempts = 300  # 10 minutes total

        for _ in range(max_attempts):
            time.sleep(poll_interval)
            console.print(".", end="")

            try:
                poll_response = httpx.get(
                    f"{api_url}/api/v1/cli/auth/poll",
                    params={"device_code": device_code},
                    timeout=10,
                    follow_redirects=True,
                )
                poll_response.raise_for_status()
                poll_data = poll_response.json()

                if poll_data.get("status") == "complete":
                    token = poll_data.get("token")
                    if token:
                        save_config(token, api_url)
                        console.print("\n\n[green]Successfully authenticated![/green]")
                        console.print(f"[dim]Config saved to {CONFIG_FILE}[/dim]")

                        # Install URL handler for cased:// links (macOS only)
                        success, result = install_url_handler()
                        if success:
                            console.print(f"[green]URL handler installed![/green] cased:// links will open in your terminal")
                            console.print(f"[dim]App: {result}[/dim]")
                            console.print(f"[dim]Use 'cased set-app <app>' to change (supports: ghostty)[/dim]")
                        return
                    else:
                        console.print("\n\n[red]Authentication failed - no token received[/red]")
                        sys.exit(1)

            except httpx.HTTPStatusError as e:
                if e.response.status_code == 400:
                    # Code expired or invalid
                    console.print("\n\n[red]Authentication expired or cancelled[/red]")
                    sys.exit(1)
                raise

        console.print("\n\n[red]Authentication timed out[/red]")
        sys.exit(1)

    except httpx.HTTPStatusError as e:
        console.print(f"\n[red]API Error: {e.response.status_code}[/red]")
        try:
            error = e.response.json()
            console.print(f"[red]{error.get('error', 'Unknown error')}[/red]")
        except Exception:
            console.print(f"[red]{e.response.text}[/red]")
        sys.exit(1)
    except httpx.RequestError as e:
        console.print(f"\n[red]Connection Error: {e}[/red]")
        console.print("\n[dim]Manual configuration:[/dim]")
        console.print("  export CASED_API_KEY=your_api_key_here")
        console.print(f"\nGet your API key from: {api_url}/settings")
        sys.exit(1)


@cli.command()
@click.argument("event_id")
@click.option("--no-launch", is_flag=True, help="Print prompt instead of launching Claude Code")
@click.option("--json", "output_json", is_flag=True, help="Output error details as JSON")
def investigate(event_id, no_launch, output_json):
    """Open an error in Claude Code for investigation.

    Fetches the full error details (stacktrace, breadcrumbs, context) and
    launches Claude Code with a pre-built prompt to investigate and fix the issue.

    Examples:
        cased investigate abc123def456
        cased investigate abc123def456 --no-launch
    """
    import shutil
    import subprocess

    # Fetch error details
    params = {"action": "details", "event_id": event_id}
    data = make_request("errors", params)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    if not data or data.get("error"):
        console.print(f"[red]Error not found: {event_id}[/red]")
        sys.exit(1)

    # Extract error info
    exception_type = data.get("exception_type", "Unknown Error")
    exception_value = data.get("exception_value", "No message")
    environment = data.get("environment", "unknown")
    platform = data.get("platform", "unknown")
    release = data.get("release", "unknown")
    stacktrace = data.get("stacktrace", {})
    breadcrumbs = data.get("breadcrumbs", [])
    timestamp = data.get("timestamp", "")[:19]

    # Format stacktrace for prompt
    stacktrace_text = ""
    if stacktrace:
        values = stacktrace.get("values", [])
        if values:
            frames = values[0].get("stacktrace", {}).get("frames", [])
            if frames:
                stacktrace_text = "\n".join(
                    f"  {f.get('filename', '?')}:{f.get('lineno', '?')} in {f.get('function', '?')}"
                    + (
                        f"\n    {f.get('context_line', '').strip()}"
                        if f.get("context_line")
                        else ""
                    )
                    for f in reversed(frames[-10:])  # Last 10 frames, most recent first
                )

    # Format breadcrumbs
    breadcrumbs_text = ""
    if breadcrumbs and isinstance(breadcrumbs, list):
        recent = breadcrumbs[-5:]  # Last 5 breadcrumbs
        breadcrumbs_text = "\n".join(
            f"  [{b.get('category', 'log')}] {b.get('message', '')}"
            for b in recent
            if isinstance(b, dict) and b.get("message")
        )

    # Build the prompt
    prompt = f"""Investigate and help fix this error from Cased Telemetry:

**Error:** {exception_type}: {exception_value}
**Environment:** {environment}
**Platform:** {platform}
**Release:** {release}
**Time:** {timestamp}

**Stack Trace:**
{stacktrace_text or "  (no stacktrace available)"}
"""

    if breadcrumbs_text:
        prompt += f"""
**Recent Activity (breadcrumbs):**
{breadcrumbs_text}
"""

    prompt += """
Please:
1. Search the codebase for the relevant code
2. Analyze the root cause of this error
3. Suggest a fix or mitigation
"""

    if no_launch:
        console.print("\n[bold]Claude Code Prompt:[/bold]\n")
        console.print(prompt)
        console.print('\n[dim]Run with: claude "<prompt>"[/dim]')
        return

    # Check if claude is available
    claude_path = shutil.which("claude")
    if not claude_path:
        console.print("[red]Claude Code not found in PATH[/red]")
        console.print("Install it from: https://claude.ai/code")
        console.print("\n[dim]Prompt that would be used:[/dim]\n")
        console.print(prompt)
        sys.exit(1)

    # Launch Claude Code
    console.print("[bold]Opening error in Claude Code...[/bold]")
    console.print(f"[dim]{exception_type}: {exception_value[:60]}...[/dim]\n")

    try:
        subprocess.run([claude_path, prompt], check=True)
    except subprocess.CalledProcessError as e:
        console.print(f"[red]Failed to launch Claude Code: {e}[/red]")
        sys.exit(1)
    except KeyboardInterrupt:
        pass  # User cancelled


@cli.command()
def logout():
    """Log out and remove saved credentials."""
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
        console.print("[green]Logged out successfully[/green]")
    else:
        if os.environ.get("CASED_API_KEY"):
            console.print("[yellow]Note: CASED_API_KEY environment variable is still set[/yellow]")
            console.print("Remove it from your shell profile to fully log out")
        else:
            console.print("[yellow]Not currently logged in[/yellow]")


# === Source Maps Commands ===


@cli.group()
def sourcemaps():
    """Manage source maps for error de-minification.

    Upload source maps to show original source locations in JavaScript stack traces.
    """
    pass


@sourcemaps.command("upload")
@click.option("--project", "-p", required=True, help="Telemetry project ID or slug")
@click.option("--release", "-r", required=True, help="Release version (must match SDK config)")
@click.option("--url-prefix", help="URL prefix to strip when matching files")
@click.argument("files", nargs=-1, type=click.Path(exists=True))
def sourcemaps_upload(project, release, url_prefix, files):
    """Upload source maps for a release.

    Examples:
        cased sourcemaps upload -p my-app -r v1.2.3 dist/*.map
        cased sourcemaps upload -p my-app -r $GIT_SHA build/*.map
    """
    if not files:
        console.print("[red]Error: At least one file is required[/red]")
        sys.exit(1)

    api_key, api_url = get_config()
    url = f"{api_url}/api/v1/telemetry/projects/{project}/sourcemaps/"
    headers = {"Authorization": f"Bearer {api_key}"}

    # Filter to only .map files
    map_files = [f for f in files if f.endswith(".map")]
    if not map_files:
        console.print("[red]Error: No .map files found[/red]")
        sys.exit(1)

    # Prepare multipart upload
    files_data = []
    for f in map_files:
        files_data.append(("files", (os.path.basename(f), open(f, "rb"), "application/json")))

    data = {"release": release}
    if url_prefix:
        data["url_prefix"] = url_prefix

    console.print(f"Uploading {len(files_data)} source map(s) for release [bold]{release}[/bold]...")

    try:
        response = httpx.post(url, headers=headers, data=data, files=files_data, timeout=120)
        response.raise_for_status()
        result = response.json()

        console.print(f"[green]Successfully uploaded {len(result.get('uploaded', []))} source map(s)[/green]")
        for sm in result.get("uploaded", []):
            console.print(f"  - {sm.get('filename')} ({sm.get('size'):,} bytes)")

    except httpx.HTTPStatusError as e:
        console.print(f"[red]Upload failed: {e.response.status_code}[/red]")
        try:
            error = e.response.json()
            console.print(f"[red]{error.get('error', 'Unknown error')}[/red]")
        except Exception:
            console.print(f"[red]{e.response.text}[/red]")
        sys.exit(1)
    finally:
        for _, (_, f, _) in files_data:
            f.close()


@sourcemaps.command("list")
@click.option("--project", "-p", required=True, help="Telemetry project ID or slug")
@click.option("--release", "-r", help="Filter by release version")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def sourcemaps_list(project, release, output_json):
    """List uploaded source maps.

    Examples:
        cased sourcemaps list -p my-app
        cased sourcemaps list -p my-app -r v1.2.3
    """
    api_key, api_url = get_config()
    url = f"{api_url}/api/v1/telemetry/projects/{project}/sourcemaps/"
    headers = {"Authorization": f"Bearer {api_key}"}

    params = {}
    if release:
        params["release"] = release

    try:
        response = httpx.get(url, headers=headers, params=params, timeout=30)
        response.raise_for_status()
        data = response.json()
    except httpx.HTTPStatusError as e:
        console.print(f"[red]Error: {e.response.status_code}[/red]")
        sys.exit(1)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    sourcemaps_data = data.get("sourcemaps", [])
    if not sourcemaps_data:
        console.print("[yellow]No source maps found[/yellow]")
        return

    table = Table(title="Source Maps")
    table.add_column("Release")
    table.add_column("Filename")
    table.add_column("Size", justify="right")
    table.add_column("Created", style="dim")

    for sm in sourcemaps_data:
        created = sm.get("created_at", "")[:19]
        size = f"{sm.get('file_size', 0):,} bytes"
        table.add_row(
            sm.get("release", "-"),
            sm.get("filename", "-"),
            size,
            created,
        )

    console.print(table)
    console.print(f"\n[dim]Total: {len(sourcemaps_data)} source map(s)[/dim]")


@sourcemaps.command("delete")
@click.option("--project", "-p", required=True, help="Telemetry project ID or slug")
@click.option("--release", "-r", required=True, help="Release version to delete")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def sourcemaps_delete(project, release, yes):
    """Delete source maps for a release.

    Examples:
        cased sourcemaps delete -p my-app -r v1.2.3
        cased sourcemaps delete -p my-app -r v1.2.3 -y
    """
    if not yes:
        if not click.confirm(f"Delete all source maps for release {release}?"):
            console.print("[yellow]Cancelled[/yellow]")
            return

    api_key, api_url = get_config()
    url = f"{api_url}/api/v1/telemetry/projects/{project}/sourcemaps/{release}/"
    headers = {"Authorization": f"Bearer {api_key}"}

    try:
        response = httpx.delete(url, headers=headers, timeout=30)
        response.raise_for_status()
        result = response.json()
        console.print(f"[green]Deleted {result.get('deleted', 0)} source map(s) for release {release}[/green]")
    except httpx.HTTPStatusError as e:
        console.print(f"[red]Delete failed: {e.response.status_code}[/red]")
        try:
            error = e.response.json()
            console.print(f"[red]{error.get('error', 'Unknown error')}[/red]")
        except Exception:
            console.print(f"[red]{e.response.text}[/red]")
        sys.exit(1)


# === Performance Analysis Commands ===


@cli.group()
def perf():
    """Analyze performance of distributed traces.

    Detect slow spans, N+1 patterns, latency regressions, and more.
    """
    pass


@perf.command("slow")
@click.option("--since", default="1h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--threshold", default=500, type=float, help="Minimum duration in ms (default: 500)")
@click.option("--service", help="Filter by service name")
@click.option("--limit", default=50, help="Max results")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def perf_slow(since, threshold, service, limit, output_json):
    """Find slow spans exceeding duration threshold.

    Examples:
        cased perf slow --since 1h --threshold 500
        cased perf slow --service api --since 24h
        cased perf slow --json
    """
    params = {"since": since, "threshold_ms": threshold, "limit": limit}
    if service:
        params["service"] = service

    data = make_request("perf/slow", params)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    slow_spans = data.get("slow_spans", [])
    if not slow_spans:
        console.print("[yellow]No slow spans found[/yellow]")
        return

    table = Table(title=f"Slow Spans (>{threshold}ms, last {since})")
    table.add_column("Time", style="dim")
    table.add_column("Service")
    table.add_column("Operation", max_width=40)
    table.add_column("Duration", justify="right", style="red")
    table.add_column("HTTP")
    table.add_column("Trace ID", style="dim")

    for s in slow_spans:
        timestamp = s.get("timestamp", "")[:19]
        duration = f"{s.get('duration_ms', 0):.2f}ms"
        http_info = ""
        if s.get("http_method"):
            http_info = f"{s.get('http_method')} {s.get('http_status_code', '')}"

        table.add_row(
            timestamp,
            s.get("service_name") or "-",
            (s.get("span_name") or "-")[:40],
            duration,
            http_info,
            s.get("trace_id", "")[:12],
        )

    console.print(table)
    console.print(f"\n[dim]Threshold: {data.get('threshold_ms', threshold)}ms[/dim]")


@perf.command("latency")
@click.option("--since", default="1h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--service", help="Filter by service name")
@click.option("--group-by", default="service", type=click.Choice(["service", "endpoint", "both"]))
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def perf_latency(since, service, group_by, output_json):
    """Show latency percentiles (p50, p95, p99).

    Examples:
        cased perf latency --since 1h
        cased perf latency --service api --group-by endpoint
    """
    params = {"since": since, "group_by": group_by}
    if service:
        params["service"] = service

    data = make_request("perf/latency", params)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    stats = data.get("latency_stats", [])
    if not stats:
        console.print("[yellow]No latency data found[/yellow]")
        return

    table = Table(title=f"Latency Percentiles (last {since})")
    if group_by in ("service", "both"):
        table.add_column("Service")
    if group_by in ("endpoint", "both"):
        table.add_column("Endpoint", max_width=40)
    table.add_column("p50", justify="right")
    table.add_column("p95", justify="right")
    table.add_column("p99", justify="right")
    table.add_column("Count", justify="right")
    table.add_column("Errors", justify="right")

    for s in stats:
        row = []
        if group_by in ("service", "both"):
            row.append(s.get("service_name") or "-")
        if group_by in ("endpoint", "both"):
            row.append((s.get("span_name") or "-")[:40])

        row.extend([
            f"{s.get('p50_ms', 0):.1f}ms",
            f"{s.get('p95_ms', 0):.1f}ms",
            f"[{'red' if s.get('p99_ms', 0) > 1000 else 'white'}]{s.get('p99_ms', 0):.1f}ms[/]",
            f"{s.get('count', 0):,}",
            f"[{'red' if s.get('error_rate', 0) > 0.01 else 'green'}]{s.get('error_rate', 0)*100:.2f}%[/]",
        ])
        table.add_row(*row)

    console.print(table)


@perf.command("n1")
@click.option("--since", default="1h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--min-count", default=5, help="Minimum repetitions to flag (default: 5)")
@click.option("--limit", default=50, help="Max results")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def perf_n1(since, min_count, limit, output_json):
    """Detect N+1 query patterns.

    Finds traces with repeated similar database or HTTP calls,
    which often indicate N+1 problems.

    Examples:
        cased perf n1 --since 1h
        cased perf n1 --min-count 10 --json
    """
    params = {"since": since, "min_count": min_count, "limit": limit}

    data = make_request("perf/n1", params)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    issues = data.get("n1_issues", [])
    if not issues:
        console.print("[green]No N+1 patterns detected[/green]")
        return

    table = Table(title=f"N+1 Patterns Detected (last {since})")
    table.add_column("Time", style="dim")
    table.add_column("Service")
    table.add_column("Pattern", max_width=50)
    table.add_column("Count", justify="right", style="red")
    table.add_column("Total Time", justify="right")
    table.add_column("Trace ID", style="dim")

    for i in issues:
        timestamp = i.get("timestamp", "")[:19]
        table.add_row(
            timestamp,
            i.get("service_name") or "-",
            (i.get("pattern") or "-")[:50],
            str(i.get("count", 0)),
            f"{i.get('total_duration_ms', 0):.1f}ms",
            i.get("trace_id", "")[:12],
        )

    console.print(table)
    console.print(f"\n[yellow]Found {len(issues)} potential N+1 issues[/yellow]")


@perf.command("breakdown")
@click.argument("trace_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def perf_breakdown(trace_id, output_json):
    """Show service time breakdown for a trace.

    Analyzes where time was spent across different services.

    Examples:
        cased perf breakdown abc123def456
    """
    params = {"trace_id": trace_id}

    data = make_request("perf/breakdown", params)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    services = data.get("services", [])
    if not services:
        console.print(f"[yellow]No data found for trace {trace_id}[/yellow]")
        return

    total = data.get("total_duration_ms", 0)
    console.print(f"\n[bold]Trace {trace_id}[/bold]")
    console.print(f"Total Duration: {total:.2f}ms\n")

    table = Table(title="Service Breakdown")
    table.add_column("Service")
    table.add_column("Duration", justify="right")
    table.add_column("Percentage", justify="right")
    table.add_column("Spans", justify="right")
    table.add_column("Bar")

    for s in services:
        pct = s.get("percentage", 0)
        bar_width = int(pct / 2)  # Scale to 50 chars max
        bar = "[cyan]" + "█" * bar_width + "[/cyan]"

        table.add_row(
            s.get("service_name") or "-",
            f"{s.get('duration_ms', 0):.2f}ms",
            f"{pct:.1f}%",
            str(s.get("span_count", 0)),
            bar,
        )

    console.print(table)


@perf.command("regression")
@click.option("--service", required=True, help="Service name to analyze")
@click.option("--endpoint", help="Optional endpoint/span name filter")
@click.option("--baseline", default="7d", help="Baseline period (e.g., 7d for 7 days ago to 1 day ago)")
@click.option("--compare", default="1d", help="Comparison period (e.g., 1d for last 24 hours)")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def perf_regression(service, endpoint, baseline, compare, output_json):
    """Detect performance regressions.

    Compares latency between two time periods to find regressions.

    Examples:
        cased perf regression --service api
        cased perf regression --service api --baseline 7d --compare 1d
    """
    params = {"service": service, "baseline": baseline, "compare": compare}
    if endpoint:
        params["endpoint"] = endpoint

    data = make_request("perf/regression", params)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    console.print(f"\n[bold]Performance Regression Analysis: {service}[/bold]")
    if endpoint:
        console.print(f"Endpoint: {endpoint}")
    console.print()

    baseline_data = data.get("baseline", {})
    current_data = data.get("current", {})
    regression = data.get("regression", {})

    table = Table()
    table.add_column("Metric")
    table.add_column("Baseline", justify="right")
    table.add_column("Current", justify="right")
    table.add_column("Change", justify="right")

    p50_change = regression.get("p50_change_percent", 0)
    p95_change = regression.get("p95_change_percent", 0)

    p50_style = "red" if p50_change > 20 else ("green" if p50_change < -10 else "white")
    p95_style = "red" if p95_change > 20 else ("green" if p95_change < -10 else "white")

    table.add_row(
        "p50 Latency",
        f"{baseline_data.get('p50_ms', 0):.1f}ms",
        f"{current_data.get('p50_ms', 0):.1f}ms",
        f"[{p50_style}]{p50_change:+.1f}%[/{p50_style}]",
    )
    table.add_row(
        "p95 Latency",
        f"{baseline_data.get('p95_ms', 0):.1f}ms",
        f"{current_data.get('p95_ms', 0):.1f}ms",
        f"[{p95_style}]{p95_change:+.1f}%[/{p95_style}]",
    )
    table.add_row(
        "Sample Count",
        f"{baseline_data.get('count', 0):,}",
        f"{current_data.get('count', 0):,}",
        "",
    )

    console.print(table)

    if regression.get("is_significant"):
        console.print("\n[red bold]⚠ SIGNIFICANT REGRESSION DETECTED[/red bold]")
    else:
        console.print("\n[green]✓ No significant regression[/green]")


@perf.command("summary")
@click.option("--since", default="1h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def perf_summary(since, output_json):
    """Show overall performance summary.

    Examples:
        cased perf summary --since 1h
        cased perf summary --since 24h --json
    """
    data = make_request("perf/summary", {"since": since})

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    console.print(f"\n[bold]Performance Summary (last {since})[/bold]\n")

    console.print(f"  Total Spans: {data.get('total_spans', 0):,}")
    console.print(f"  Unique Traces: {data.get('unique_traces', 0):,}")
    console.print(f"  Unique Services: {data.get('unique_services', 0)}")
    console.print()
    console.print("[bold cyan]Latency[/bold cyan]")
    console.print(f"  Average: {data.get('avg_duration_ms', 0):.2f}ms")
    console.print(f"  p50: {data.get('p50_ms', 0):.2f}ms")
    console.print(f"  p95: {data.get('p95_ms', 0):.2f}ms")
    console.print(f"  p99: {data.get('p99_ms', 0):.2f}ms")
    console.print()

    error_rate = data.get("error_rate", 0)
    error_style = "red" if error_rate > 0.01 else "green"
    console.print(f"  Errors: {data.get('error_count', 0):,}")
    console.print(f"  Error Rate: [{error_style}]{error_rate*100:.2f}%[/{error_style}]")


# === LLM Monitoring Commands ===


@cli.group()
def llm():
    """Monitor LLM usage, costs, and performance.

    Track token usage, costs, latency, and errors across AI agent sessions.
    """
    pass


@llm.command("usage")
@click.option("--since", default="24h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--model", help="Filter by model name")
@click.option("--provider", help="Filter by provider (anthropic, openai, google)")
@click.option("--group-by", default="model", type=click.Choice(["model", "provider", "both"]))
@click.option("--limit", default=50, help="Max results")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def llm_usage(since, model, provider, group_by, limit, output_json):
    """Show LLM token usage statistics.

    Examples:
        cased llm usage --since 24h
        cased llm usage --group-by provider
        cased llm usage --model claude-3-5-sonnet-20241022
    """
    params = {"since": since, "group_by": group_by, "limit": limit}
    if model:
        params["model"] = model
    if provider:
        params["provider"] = provider

    data = make_request("llm/usage", params)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    usage_stats = data.get("usage_stats", [])
    if not usage_stats:
        console.print("[yellow]No LLM usage data found[/yellow]")
        return

    table = Table(title=f"LLM Token Usage (last {since})")
    if group_by in ("model", "both"):
        table.add_column("Model")
    if group_by in ("provider", "both"):
        table.add_column("Provider")
    table.add_column("Calls", justify="right")
    table.add_column("Input Tokens", justify="right")
    table.add_column("Output Tokens", justify="right")
    table.add_column("Cached", justify="right")

    for stat in usage_stats:
        row = []
        if group_by in ("model", "both"):
            row.append(stat.get("model", "-"))
        if group_by in ("provider", "both"):
            row.append(stat.get("provider", "-"))
        row.extend([
            f"{stat.get('call_count', 0):,}",
            f"{stat.get('total_input_tokens', 0):,}",
            f"{stat.get('total_output_tokens', 0):,}",
            f"{stat.get('total_cached_tokens', 0):,}",
        ])
        table.add_row(*row)

    console.print(table)

    totals = data.get("totals", {})
    console.print(f"\n[bold]Totals:[/bold]")
    console.print(f"  Calls: {totals.get('calls', 0):,}")
    console.print(f"  Total Tokens: {totals.get('total_tokens', 0):,}")


@llm.command("cost")
@click.option("--since", default="24h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--model", help="Filter by model name")
@click.option("--provider", help="Filter by provider")
@click.option("--group-by", default="model", type=click.Choice(["model", "provider", "both"]))
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def llm_cost(since, model, provider, group_by, output_json):
    """Show estimated LLM costs.

    Examples:
        cased llm cost --since 24h
        cased llm cost --model claude-3-5-sonnet-20241022
        cased llm cost --group-by provider
    """
    params = {"since": since, "group_by": group_by}
    if model:
        params["model"] = model
    if provider:
        params["provider"] = provider

    data = make_request("llm/cost", params)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    cost_stats = data.get("cost_stats", [])
    if not cost_stats:
        console.print("[yellow]No LLM cost data found[/yellow]")
        return

    table = Table(title=f"LLM Costs (last {since})")
    if group_by in ("model", "both"):
        table.add_column("Model")
    if group_by in ("provider", "both"):
        table.add_column("Provider")
    table.add_column("Calls", justify="right")
    table.add_column("Input Tokens", justify="right")
    table.add_column("Output Tokens", justify="right")
    table.add_column("Cost (USD)", justify="right", style="green")

    for stat in cost_stats:
        row = []
        if group_by in ("model", "both"):
            row.append(stat.get("model", "-"))
        if group_by in ("provider", "both"):
            row.append(stat.get("provider", "-"))
        row.extend([
            f"{stat.get('call_count', 0):,}",
            f"{stat.get('input_tokens', 0):,}",
            f"{stat.get('output_tokens', 0):,}",
            f"${stat.get('cost_usd', 0):.4f}",
        ])
        table.add_row(*row)

    console.print(table)
    console.print(f"\n[bold green]Total Cost: ${data.get('total_cost_usd', 0):.4f}[/bold green]")
    console.print(f"[dim]{data.get('pricing_note', '')}[/dim]")


@llm.command("latency")
@click.option("--since", default="24h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--model", help="Filter by model name")
@click.option("--provider", help="Filter by provider")
@click.option("--group-by", default="model", type=click.Choice(["model", "provider", "both"]))
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def llm_latency(since, model, provider, group_by, output_json):
    """Show LLM latency percentiles.

    Examples:
        cased llm latency --since 24h
        cased llm latency --model gpt-4o
    """
    params = {"since": since, "group_by": group_by}
    if model:
        params["model"] = model
    if provider:
        params["provider"] = provider

    data = make_request("llm/latency", params)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    latency_stats = data.get("latency_stats", [])
    if not latency_stats:
        console.print("[yellow]No LLM latency data found[/yellow]")
        return

    table = Table(title=f"LLM Latency (last {since})")
    if group_by in ("model", "both"):
        table.add_column("Model")
    if group_by in ("provider", "both"):
        table.add_column("Provider")
    table.add_column("Calls", justify="right")
    table.add_column("p50", justify="right")
    table.add_column("p95", justify="right")
    table.add_column("p99", justify="right")
    table.add_column("Avg", justify="right")

    for stat in latency_stats:
        row = []
        if group_by in ("model", "both"):
            row.append(stat.get("model", "-"))
        if group_by in ("provider", "both"):
            row.append(stat.get("provider", "-"))
        row.extend([
            f"{stat.get('call_count', 0):,}",
            f"{stat.get('p50_ms', 0):.0f}ms",
            f"{stat.get('p95_ms', 0):.0f}ms",
            f"{stat.get('p99_ms', 0):.0f}ms",
            f"{stat.get('avg_ms', 0):.0f}ms",
        ])
        table.add_row(*row)

    console.print(table)


@llm.command("errors")
@click.option("--since", default="24h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--model", help="Filter by model name")
@click.option("--provider", help="Filter by provider")
@click.option("--limit", default=20, help="Max error details to show")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def llm_errors(since, model, provider, limit, output_json):
    """Show LLM error statistics.

    Examples:
        cased llm errors --since 24h
        cased llm errors --model claude-3-5-sonnet-20241022
    """
    params = {"since": since, "limit": limit}
    if model:
        params["model"] = model
    if provider:
        params["provider"] = provider

    data = make_request("llm/errors", params)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    totals = data.get("totals", {})
    error_rate = totals.get("error_rate", 0)
    error_style = "red" if error_rate > 0.01 else "green"

    console.print(f"\n[bold]Overall Error Rate:[/bold] [{error_style}]{error_rate*100:.2f}%[/{error_style}]")
    console.print(f"  Total Calls: {totals.get('total_calls', 0):,}")
    console.print(f"  Error Count: {totals.get('error_count', 0):,}")

    error_stats = data.get("error_stats", [])
    if error_stats:
        console.print(f"\n[bold]Errors by Model:[/bold]")
        table = Table()
        table.add_column("Model")
        table.add_column("Provider")
        table.add_column("Errors", justify="right")
        table.add_column("Error Rate", justify="right")

        for stat in error_stats:
            rate = stat.get("error_rate", 0)
            rate_style = "red" if rate > 0.05 else "yellow" if rate > 0.01 else "green"
            table.add_row(
                stat.get("model", "-"),
                stat.get("provider", "-"),
                f"{stat.get('error_count', 0):,}",
                f"[{rate_style}]{rate*100:.2f}%[/{rate_style}]",
            )
        console.print(table)

    recent_errors = data.get("recent_errors", [])
    if recent_errors:
        console.print(f"\n[bold]Recent Errors:[/bold]")
        for err in recent_errors[:10]:
            timestamp = err.get("timestamp", "")[:19]
            console.print(f"  [{timestamp}] {err.get('model')}: {err.get('error', 'Unknown')[:80]}")


@llm.command("summary")
@click.option("--since", default="24h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def llm_summary(since, output_json):
    """Show overall LLM usage summary.

    Examples:
        cased llm summary --since 24h
        cased llm summary --since 7d
    """
    data = make_request("llm/summary", {"since": since})

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    total_calls = data.get("total_calls", 0)
    if total_calls == 0:
        console.print("[yellow]No LLM usage data found[/yellow]")
        return

    console.print(f"\n[bold]LLM Usage Summary (last {since})[/bold]\n")

    console.print("[bold]Usage:[/bold]")
    console.print(f"  Total Calls: {total_calls:,}")
    console.print(f"  Total Tokens: {data.get('total_tokens', 0):,}")
    console.print(f"  Input Tokens: {data.get('total_input_tokens', 0):,}")
    console.print(f"  Output Tokens: {data.get('total_output_tokens', 0):,}")
    console.print(f"  Cached Tokens: {data.get('total_cached_tokens', 0):,}")
    console.print()

    console.print("[bold]Cost:[/bold]")
    console.print(f"  [green]Estimated: ${data.get('estimated_cost_usd', 0):.4f}[/green]")
    console.print()

    console.print("[bold]Performance:[/bold]")
    console.print(f"  Avg Latency: {data.get('avg_latency_ms', 0):.0f}ms")
    console.print()

    error_rate = data.get("error_rate", 0)
    error_style = "red" if error_rate > 0.01 else "green"
    console.print("[bold]Errors:[/bold]")
    console.print(f"  Error Count: {data.get('error_count', 0):,}")
    console.print(f"  Error Rate: [{error_style}]{error_rate*100:.2f}%[/{error_style}]")
    console.print()

    console.print("[bold]Models:[/bold]")
    console.print(f"  Unique Models: {data.get('unique_models', 0)}")
    console.print(f"  Unique Providers: {data.get('unique_providers', 0)}")

    top_models = data.get("top_models", [])
    if top_models:
        console.print("\n[bold]Top Models:[/bold]")
        for m in top_models:
            console.print(f"  {m.get('model', '-')}: {m.get('calls', 0):,} calls")


@llm.command("sessions")
@click.option("--since", default="24h", help="Time range (e.g., 1h, 24h, 7d)")
@click.option("--sort-by", default="created", type=click.Choice(["cost", "calls", "tokens", "created"]))
@click.option("--limit", default=20, help="Max sessions to show")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def llm_sessions(since, sort_by, limit, output_json):
    """Show per-session LLM usage rollups.

    Analyze cost per conversation for multi-turn agent sessions.

    Examples:
        cased llm sessions --since 24h
        cased llm sessions --sort-by cost --limit 10
    """
    params = {"since": since, "sort_by": sort_by, "limit": limit}

    data = make_request("llm/sessions", params)

    if output_json:
        click.echo(json.dumps(data, indent=2))
        return

    sessions = data.get("sessions", [])
    if not sessions:
        console.print("[yellow]No sessions with LLM usage found[/yellow]")
        return

    table = Table(title=f"Session LLM Usage (last {since}, sorted by {sort_by})")
    table.add_column("Session ID", style="dim")
    table.add_column("Title", max_width=30)
    table.add_column("Status")
    table.add_column("Calls", justify="right")
    table.add_column("Tokens", justify="right")
    table.add_column("Cost", justify="right", style="green")
    table.add_column("Turns", justify="right")
    table.add_column("$/Turn", justify="right")

    for s in sessions:
        status = s.get("status", "-")
        status_style = "green" if status == "completed" else "yellow" if status == "agent_running" else "red"

        table.add_row(
            s.get("session_id", "")[:12],
            (s.get("title") or "-")[:30],
            f"[{status_style}]{status}[/{status_style}]",
            f"{s.get('llm_calls', 0):,}",
            f"{s.get('total_tokens', 0):,}",
            f"${s.get('total_cost_usd', 0):.4f}",
            str(s.get("turns", 0)),
            f"${s.get('cost_per_turn', 0):.4f}",
        )

    console.print(table)

    totals = data.get("totals", {})
    console.print(f"\n[bold]Totals for {totals.get('sessions', 0)} sessions:[/bold]")
    console.print(f"  Calls: {totals.get('calls', 0):,}")
    console.print(f"  Tokens: {totals.get('tokens', 0):,}")
    console.print(f"  [green]Cost: ${totals.get('cost_usd', 0):.4f}[/green]")


@cli.command("set-app")
@click.argument("app_name", required=False)
def set_app(app_name):
    """Set the default app for cased:// URLs.

    Supported apps: terminal (default), ghostty

    Examples:
        cased set-app ghostty    # Set Ghostty as default
        cased set-app terminal   # Reset to Terminal.app
        cased set-app            # Show current setting
    """
    config = load_config_file()

    if not app_name:
        # Show current setting
        current = config.get("default_app", "terminal")
        console.print(f"[bold]Current default app:[/bold] {current}")
        console.print(f"\n[dim]Supported apps: {', '.join(SUPPORTED_APPS)}[/dim]")
        console.print("[dim]You can also override per-URL with ?app=ghostty[/dim]")
        return

    app_name = app_name.lower()
    if app_name not in SUPPORTED_APPS:
        console.print(f"[red]Unknown app: {app_name}[/red]")
        console.print(f"Supported apps: {', '.join(SUPPORTED_APPS)}")
        return

    # Update config
    config["default_app"] = app_name
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)
    CONFIG_FILE.chmod(0o600)

    console.print(f"[green]Default app set to:[/green] {app_name}")
    console.print(f"[dim]cased:// URLs will now open in {app_name.title()}[/dim]")

    # Reinstall URL handler to update the config path reference
    success, result = install_url_handler()
    if success:
        console.print(f"[green]URL handler updated![/green]")


if __name__ == "__main__":
    cli()
