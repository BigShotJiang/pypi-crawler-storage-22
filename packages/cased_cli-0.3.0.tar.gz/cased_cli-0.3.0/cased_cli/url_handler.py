"""URL handler for cased:// protocol on macOS.

Supports opening cased:// URLs in various terminal emulators and editors.
"""

import os
import platform
import shutil
import subprocess
import tempfile
from pathlib import Path

# Supported applications for opening cased:// URLs
SUPPORTED_APPS = ["terminal", "ghostty"]

# Default config paths
CONFIG_DIR = Path.home() / ".config" / "cased"
CONFIG_FILE = CONFIG_DIR / "config.json"


def generate_applescript(config_path: str, cased_path: str) -> str:
    """Generate the AppleScript for handling cased:// URLs.

    Args:
        config_path: Path to the config file for reading default app preference.
        cased_path: Absolute path to the cased CLI executable.

    Returns:
        AppleScript source code as a string.
    """
    return f'''on open location theURL
    -- Parse URL: cased://investigate/EVENT_ID?app=ghostty
    -- First split off query string
    set AppleScript's text item delimiters to "?"
    set urlAndQuery to text items of theURL
    set baseURL to item 1 of urlAndQuery

    -- Parse query parameters for app
    set targetApp to ""
    if (count of urlAndQuery) > 1 then
        set queryString to item 2 of urlAndQuery
        set AppleScript's text item delimiters to "&"
        set queryParams to text items of queryString
        repeat with param in queryParams
            set AppleScript's text item delimiters to "="
            set paramParts to text items of param
            if (count of paramParts) >= 2 then
                if item 1 of paramParts is "app" then
                    set targetApp to item 2 of paramParts
                end if
            end if
        end repeat
    end if

    -- If no app specified in URL, try to read from config
    if targetApp is "" then
        try
            set configPath to "{config_path}"
            set configContent to do shell script "cat " & quoted form of configPath
            -- Simple JSON parsing for default_app
            set AppleScript's text item delimiters to "\\"default_app\\": \\""
            set configParts to text items of configContent
            if (count of configParts) > 1 then
                set AppleScript's text item delimiters to "\\""
                set appParts to text items of item 2 of configParts
                set targetApp to item 1 of appParts
            end if
        end try
    end if

    -- Default to terminal if still empty
    if targetApp is "" then
        set targetApp to "terminal"
    end if

    -- Parse the base URL path: cased://investigate/EVENT_ID
    set AppleScript's text item delimiters to "://"
    set urlParts to text items of baseURL

    if (count of urlParts) > 1 then
        set pathPart to item 2 of urlParts

        -- Split by /
        set AppleScript's text item delimiters to "/"
        set pathItems to text items of pathPart

        if (count of pathItems) >= 2 then
            set theCommand to item 1 of pathItems
            set eventId to item 2 of pathItems

            if theCommand is "investigate" then
                -- Sanitize eventId to prevent command injection (allow only alphanumeric, hyphens, underscores)
                set sanitizedEventId to do shell script "echo " & quoted form of eventId & " | tr -cd 'a-zA-Z0-9_-'"
                -- Use the cased CLI path detected at install time
                set casedCommand to "{cased_path} investigate " & sanitizedEventId

                -- Open in the appropriate terminal
                if targetApp is "ghostty" then
                    -- Ghostty: use .command file approach (same as Terminal)
                    my openWithCommandFile(casedCommand, "Ghostty")
                else
                    -- Default: Terminal.app via .command file
                    my openWithCommandFile(casedCommand, "Terminal")
                end if
            end if
        end if
    end if
end open location

on openWithCommandFile(theCommand, appName)
    set scriptPath to "/tmp/cased-investigate.command"
    do shell script "echo '#!/bin/bash' > " & scriptPath
    -- Source shell profile to get proper PATH and Python environment
    do shell script "echo 'source ~/.zshrc 2>/dev/null || source ~/.bashrc 2>/dev/null || true' >> " & scriptPath
    do shell script "echo " & quoted form of theCommand & " >> " & scriptPath
    do shell script "echo 'echo' >> " & scriptPath
    do shell script "echo 'echo Press any key to close...' >> " & scriptPath
    do shell script "echo 'read -n 1' >> " & scriptPath
    do shell script "chmod +x " & scriptPath
    if appName is "Terminal" then
        do shell script "open " & scriptPath
    else
        do shell script "open -a " & quoted form of appName & " " & scriptPath
    end if
end openWithCommandFile

'''


def install_url_handler(config_file: Path = CONFIG_FILE) -> tuple[bool, str]:
    """Install cased:// URL handler on macOS.

    Creates a macOS app bundle that handles cased:// URLs and opens them
    in the user's preferred terminal or editor application.

    Args:
        config_file: Path to the config file for reading default app preference.

    Returns:
        Tuple of (success: bool, message: str). Message is the app path on success,
        or error message on failure.
    """
    if platform.system() != "Darwin":
        return False, "URL handler only supported on macOS"

    # Find the cased CLI path at install time
    cased_path = shutil.which("cased")
    if not cased_path:
        return False, "Could not find 'cased' CLI in PATH. Ensure cased is installed."

    applescript = generate_applescript(str(config_file), cased_path)
    app_dir = Path.home() / "Applications" / "CasedURLHandler.app"

    try:
        # Create app using osacompile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.applescript', delete=False) as f:
            f.write(applescript)
            script_path = f.name

        # Compile AppleScript to app
        subprocess.run(
            ["osacompile", "-o", str(app_dir), script_path],
            check=True,
            capture_output=True
        )
        os.unlink(script_path)

        # Add URL scheme to Info.plist
        plist_path = app_dir / "Contents" / "Info.plist"
        subprocess.run([
            "/usr/libexec/PlistBuddy",
            "-c", "Add :CFBundleURLTypes array",
            str(plist_path)
        ], capture_output=True)
        subprocess.run([
            "/usr/libexec/PlistBuddy",
            "-c", "Add :CFBundleURLTypes:0 dict",
            str(plist_path)
        ], capture_output=True)
        subprocess.run([
            "/usr/libexec/PlistBuddy",
            "-c", "Add :CFBundleURLTypes:0:CFBundleURLName string 'Cased CLI'",
            str(plist_path)
        ], capture_output=True)
        subprocess.run([
            "/usr/libexec/PlistBuddy",
            "-c", "Add :CFBundleURLTypes:0:CFBundleURLSchemes array",
            str(plist_path)
        ], capture_output=True)
        subprocess.run([
            "/usr/libexec/PlistBuddy",
            "-c", "Add :CFBundleURLTypes:0:CFBundleURLSchemes:0 string 'cased'",
            str(plist_path)
        ], capture_output=True)

        # Register with Launch Services
        subprocess.run([
            "/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister",
            "-R", "-f", str(app_dir)
        ], capture_output=True)

        return True, str(app_dir)

    except subprocess.CalledProcessError as e:
        return False, f"Failed to create app: {e}"
    except Exception as e:
        return False, str(e)
