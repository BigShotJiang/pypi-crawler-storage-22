"""CASFA Python SDK - Content-Addressable Storage for Agents.

This SDK provides a Python client for interacting with the CASFA API,
mirroring the TypeScript Client V2 (`@agent-web-portal/casfa-client-v2`).

Example:
    >>> from casfa import create_casfa_client, CasfaClientConfig, TokenAuthConfig
    >>>
    >>> client = create_casfa_client(CasfaClientConfig(
    ...     base_url="https://casfa.example.com",
    ...     auth=TokenAuthConfig(type="token", token="casfa_xxx"),
    ...     realm_id="user:ABC123",
    ... ))
    >>>
    >>> # Get realm usage
    >>> result = await client.realm.get_usage()
    >>> if result.ok:
    ...     print(f"Nodes: {result.data.node_count}")
    ...
    >>> # Create a ticket
    >>> result = await client.tickets.create(
    ...     input=["node:abc123..."],
    ...     purpose="Process data",
    ... )
"""

# =============================================================================
# Main Client
# =============================================================================

from casfa.auth.p256 import P256Auth, create_p256_auth
from casfa.auth.permissions import (
    API_PERMISSIONS,
    ApiName,
    PermissionCheckResult,
    assert_access,
    can_access,
    check_permission,
    get_required_auth,
    is_public_api,
)
from casfa.auth.ticket import TicketAuth, create_ticket_auth
from casfa.auth.token import TokenAuth, create_token_auth

# =============================================================================
# Auth Strategies
# =============================================================================
from casfa.auth.user import UserAuth, create_user_auth
from casfa.client import CasfaClient, CasfaClientConfig, create_casfa_client

# =============================================================================
# Types - API
# =============================================================================
from casfa.types.api import (
    # Agent Token
    AgentTokenInfo,
    # AWP Client
    AwpAuthInitResponse,
    AwpAuthPollResponse,
    AwpClientInfo,
    # OAuth
    CognitoConfig,
    CreateAgentTokenResponse,
    DepotDetail,
    DepotHistoryEntry,
    # Depot
    DepotInfo,
    DictNodeMetadata,
    FileNodeMetadata,
    McpError,
    # MCP
    McpRequest,
    McpResponse,
    NodeKind,
    # Node
    NodeMetadata,
    # Pagination
    PaginatedResponse,
    PrepareNodesResult,
    # Realm
    RealmInfo,
    RealmUsage,
    SuccessorNodeMetadata,
    # Ticket
    TicketInfo,
    TicketListItem,
    TokenResponse,
    UserInfo,
    # Admin
    UserListItem,
    WritableConfig,
)

# =============================================================================
# Types - Auth
# =============================================================================
from casfa.types.auth import (
    AuthConfig,
    AuthState,
    AuthType,
    # P256
    P256AuthCallbacks,
    P256AuthConfig,
    P256AuthState,
    P256PollStatus,
    TicketAuthConfig,
    # Ticket
    TicketAuthState,
    TokenAuthConfig,
    # Token
    TokenAuthState,
    # User
    UserAuthCallbacks,
    UserAuthConfig,
    UserAuthState,
)

# =============================================================================
# Types - Providers
# =============================================================================
from casfa.types.providers import (
    HashProvider,
    KeyPairProvider,
    P256KeyPair,
    StorageProvider,
)

# =============================================================================
# Utils
# =============================================================================
from casfa.utils.errors import (
    CasfaError,
    CasfaErrorCode,
    create_error,
    is_casfa_error,
)
from casfa.utils.fetch import FetchResult, FetchResultErr, FetchResultOk

# =============================================================================
# Version
# =============================================================================

__version__ = "0.1.0"

__all__ = [
    # Client
    "CasfaClient",
    "CasfaClientConfig",
    "create_casfa_client",
    # API Types
    "CognitoConfig",
    "TokenResponse",
    "UserInfo",
    "AwpAuthInitResponse",
    "AwpAuthPollResponse",
    "AwpClientInfo",
    "AgentTokenInfo",
    "CreateAgentTokenResponse",
    "UserListItem",
    "RealmInfo",
    "RealmUsage",
    "TicketInfo",
    "TicketListItem",
    "WritableConfig",
    "DepotInfo",
    "DepotDetail",
    "DepotHistoryEntry",
    "NodeMetadata",
    "DictNodeMetadata",
    "FileNodeMetadata",
    "SuccessorNodeMetadata",
    "NodeKind",
    "PrepareNodesResult",
    "McpRequest",
    "McpResponse",
    "McpError",
    "PaginatedResponse",
    # Auth Types
    "AuthConfig",
    "AuthState",
    "AuthType",
    "UserAuthCallbacks",
    "UserAuthState",
    "UserAuthConfig",
    "TokenAuthState",
    "TokenAuthConfig",
    "TicketAuthState",
    "TicketAuthConfig",
    "P256AuthCallbacks",
    "P256AuthState",
    "P256AuthConfig",
    "P256PollStatus",
    # Provider Types
    "StorageProvider",
    "HashProvider",
    "KeyPairProvider",
    "P256KeyPair",
    # Auth Strategies
    "UserAuth",
    "create_user_auth",
    "TokenAuth",
    "create_token_auth",
    "TicketAuth",
    "create_ticket_auth",
    "P256Auth",
    "create_p256_auth",
    # Permissions
    "ApiName",
    "API_PERMISSIONS",
    "can_access",
    "assert_access",
    "get_required_auth",
    "is_public_api",
    "check_permission",
    "PermissionCheckResult",
    # Errors
    "CasfaError",
    "CasfaErrorCode",
    "create_error",
    "is_casfa_error",
    # Fetch Result
    "FetchResult",
    "FetchResultOk",
    "FetchResultErr",
    # Version
    "__version__",
]
