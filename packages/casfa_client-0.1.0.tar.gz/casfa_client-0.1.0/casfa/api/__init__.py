"""CASFA API namespaces."""

from casfa.api.admin import AdminApi
from casfa.api.auth import AuthApi
from casfa.api.depots import DepotApi
from casfa.api.mcp import McpApi
from casfa.api.nodes import NodeApi
from casfa.api.oauth import OAuthApi
from casfa.api.realm import RealmApi
from casfa.api.tickets import TicketApi

__all__ = [
    "OAuthApi",
    "AuthApi",
    "AdminApi",
    "McpApi",
    "RealmApi",
    "TicketApi",
    "DepotApi",
    "NodeApi",
]
