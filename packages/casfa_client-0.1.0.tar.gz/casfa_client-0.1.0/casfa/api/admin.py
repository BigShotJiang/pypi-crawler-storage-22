"""Admin API - User management for admins."""

from casfa.types.api import PaginatedResponse, UserListItem
from casfa.utils.fetch import Fetcher, FetchResult, FetchResultOk, RequestOptions


class AdminApi:
    """Admin API namespace for user management."""

    def __init__(self, fetcher: Fetcher) -> None:
        self._fetcher = fetcher

    async def list_users(
        self,
        *,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> FetchResult[PaginatedResponse[UserListItem]]:
        """List all users (admin only)."""
        params = []
        if cursor:
            params.append(f"cursor={cursor}")
        if limit:
            params.append(f"limit={limit}")

        path = "/api/admin/users"
        if params:
            path += "?" + "&".join(params)

        result = await self._fetcher.request(path)
        if result.ok:
            data = result.data
            items = [
                UserListItem(
                    user_id=item["user_id"],
                    email=item["email"],
                    role=item["role"],
                    created_at=item["created_at"],
                    realm_id=item.get("realm_id"),
                )
                for item in data.get("items", [])
            ]
            return FetchResultOk(
                ok=True,
                data=PaginatedResponse(
                    items=items,
                    next_cursor=data.get("next_cursor"),
                    total=data.get("total"),
                ),
                status=result.status,
            )
        return result

    async def update_user_role(
        self,
        *,
        user_id: str,
        role: str,
    ) -> FetchResult[UserListItem]:
        """Update a user's role (admin only)."""
        result = await self._fetcher.request(
            f"/api/admin/users/{user_id}/role",
            RequestOptions(
                method="PUT",
                body={"role": role},
            ),
        )
        if result.ok:
            data = result.data
            return FetchResultOk(
                ok=True,
                data=UserListItem(
                    user_id=data["user_id"],
                    email=data["email"],
                    role=data["role"],
                    created_at=data["created_at"],
                    realm_id=data.get("realm_id"),
                ),
                status=result.status,
            )
        return result
