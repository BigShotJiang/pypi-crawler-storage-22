"""Auth API - AWP Client and Agent Token management."""

from casfa.types.api import (
    AgentTokenInfo,
    AwpAuthInitResponse,
    AwpAuthPollResponse,
    AwpClientInfo,
    CreateAgentTokenResponse,
    PaginatedResponse,
)
from casfa.utils.fetch import Fetcher, FetchResult, FetchResultOk, RequestOptions


class AuthApi:
    """Auth API namespace for AWP clients and Agent tokens."""

    def __init__(self, fetcher: Fetcher) -> None:
        self._fetcher = fetcher

    # =========================================================================
    # AWP Client
    # =========================================================================

    async def init_client(
        self,
        *,
        pubkey: str,
        client_name: str,
    ) -> FetchResult[AwpAuthInitResponse]:
        """Initialize AWP client authorization."""
        result = await self._fetcher.request(
            "/api/auth/awp/init",
            RequestOptions(
                method="POST",
                body={"pubkey": pubkey, "client_name": client_name},
                skip_auth=True,
            ),
        )
        if result.ok:
            data = result.data
            return FetchResultOk(
                ok=True,
                data=AwpAuthInitResponse(
                    client_id=data["client_id"],
                    auth_url=data["auth_url"],
                    display_code=data["display_code"],
                    expires_in=data["expires_in"],
                ),
                status=result.status,
            )
        return result

    async def poll_client(
        self,
        *,
        client_id: str,
    ) -> FetchResult[AwpAuthPollResponse]:
        """Poll AWP client authorization status."""
        result = await self._fetcher.request(
            f"/api/auth/awp/poll/{client_id}",
            RequestOptions(skip_auth=True),
        )
        if result.ok:
            data = result.data
            return FetchResultOk(
                ok=True,
                data=AwpAuthPollResponse(
                    status=data["status"],
                    message=data.get("message"),
                ),
                status=result.status,
            )
        return result

    async def complete_client(
        self,
        *,
        pubkey: str,
        verification_code: str,
    ) -> FetchResult[dict]:
        """Complete AWP client authorization (requires user auth)."""
        result = await self._fetcher.request(
            "/api/auth/awp/complete",
            RequestOptions(
                method="POST",
                body={"pubkey": pubkey, "verification_code": verification_code},
            ),
        )
        return result

    async def list_clients(
        self,
        *,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> FetchResult[PaginatedResponse[AwpClientInfo]]:
        """List authorized AWP clients."""
        params = []
        if cursor:
            params.append(f"cursor={cursor}")
        if limit:
            params.append(f"limit={limit}")

        path = "/api/auth/clients"
        if params:
            path += "?" + "&".join(params)

        result = await self._fetcher.request(path)
        if result.ok:
            data = result.data
            items = [
                AwpClientInfo(
                    client_id=item["client_id"],
                    created_at=item["created_at"],
                    name=item.get("name"),
                    last_used_at=item.get("last_used_at"),
                )
                for item in data.get("items", [])
            ]
            return FetchResultOk(
                ok=True,
                data=PaginatedResponse(
                    items=items,
                    next_cursor=data.get("next_cursor"),
                    total=data.get("total"),
                ),
                status=result.status,
            )
        return result

    async def revoke_client(
        self,
        *,
        client_id: str,
    ) -> FetchResult[dict]:
        """Revoke an AWP client."""
        result = await self._fetcher.request(
            f"/api/auth/clients/{client_id}",
            RequestOptions(method="DELETE"),
        )
        return result

    # =========================================================================
    # Agent Token
    # =========================================================================

    async def create_agent_token(
        self,
        *,
        name: str,
        description: str | None = None,
        expires_in: int | None = None,
    ) -> FetchResult[CreateAgentTokenResponse]:
        """Create a new agent token."""
        body: dict = {"name": name}
        if description:
            body["description"] = description
        if expires_in:
            body["expiresIn"] = expires_in

        result = await self._fetcher.request(
            "/api/auth/tokens",
            RequestOptions(method="POST", body=body),
        )
        if result.ok:
            data = result.data
            return FetchResultOk(
                ok=True,
                data=CreateAgentTokenResponse(
                    token_id=data["token_id"],
                    token=data["token"],
                    name=data["name"],
                    expires_at=data.get("expires_at"),
                ),
                status=result.status,
            )
        return result

    async def list_agent_tokens(
        self,
        *,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> FetchResult[PaginatedResponse[AgentTokenInfo]]:
        """List agent tokens."""
        params = []
        if cursor:
            params.append(f"cursor={cursor}")
        if limit:
            params.append(f"limit={limit}")

        path = "/api/auth/tokens"
        if params:
            path += "?" + "&".join(params)

        result = await self._fetcher.request(path)
        if result.ok:
            data = result.data
            items = [
                AgentTokenInfo(
                    token_id=item["token_id"],
                    name=item["name"],
                    created_at=item["created_at"],
                    last_used_at=item.get("last_used_at"),
                    expires_at=item.get("expires_at"),
                )
                for item in data.get("items", [])
            ]
            return FetchResultOk(
                ok=True,
                data=PaginatedResponse(
                    items=items,
                    next_cursor=data.get("next_cursor"),
                    total=data.get("total"),
                ),
                status=result.status,
            )
        return result

    async def revoke_agent_token(
        self,
        *,
        token_id: str,
    ) -> FetchResult[dict]:
        """Revoke an agent token."""
        result = await self._fetcher.request(
            f"/api/auth/tokens/{token_id}",
            RequestOptions(method="DELETE"),
        )
        return result
