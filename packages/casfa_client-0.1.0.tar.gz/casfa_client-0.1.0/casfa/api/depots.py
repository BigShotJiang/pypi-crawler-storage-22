"""Depots API - Depot management."""

from typing import Callable

from casfa.types.api import DepotDetail, DepotHistoryEntry, DepotInfo, PaginatedResponse
from casfa.utils.fetch import Fetcher, FetchResult, FetchResultOk, RequestOptions


def _parse_depot(data: dict) -> DepotInfo:
    """Parse depot data from API response."""
    return DepotInfo(
        depot_id=data["depot_id"],
        realm_id=data["realm_id"],
        title=data["title"],
        root=data["root"],
        version=data["version"],
        created_at=data["created_at"],
        updated_at=data["updated_at"],
        description=data.get("description"),
    )


def _parse_depot_detail(data: dict) -> DepotDetail:
    """Parse depot detail data from API response."""
    history = []
    for entry in data.get("history", []):
        history.append(
            DepotHistoryEntry(
                root=entry["root"],
                version=entry["version"],
                committed_at=entry["committed_at"],
                message=entry.get("message"),
            )
        )

    return DepotDetail(
        depot_id=data["depot_id"],
        realm_id=data["realm_id"],
        title=data["title"],
        root=data["root"],
        version=data["version"],
        created_at=data["created_at"],
        updated_at=data["updated_at"],
        description=data.get("description"),
        history=history,
    )


class DepotApi:
    """Depot API namespace for depot management."""

    def __init__(self, fetcher: Fetcher, get_realm_id: Callable[[], str | None]) -> None:
        self._fetcher = fetcher
        self._get_realm_id = get_realm_id

    def _require_realm_id(self) -> str:
        """Get realm_id or raise error."""
        realm_id = self._get_realm_id()
        if not realm_id:
            raise ValueError("realm_id is required - set it on the client or in config")
        return realm_id

    async def create(
        self,
        *,
        title: str | None = None,
        max_history: int | None = None,
    ) -> FetchResult[DepotInfo]:
        """Create a new depot."""
        realm_id = self._require_realm_id()

        body: dict = {}
        if title is not None:
            body["title"] = title
        if max_history is not None:
            body["maxHistory"] = max_history

        result = await self._fetcher.request(
            f"/api/realm/{realm_id}/depots",
            RequestOptions(method="POST", body=body),
        )
        if result.ok:
            return FetchResultOk(
                ok=True,
                data=_parse_depot(result.data),
                status=result.status,
            )
        return result

    async def list(
        self,
        *,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> FetchResult[PaginatedResponse[DepotInfo]]:
        """List depots."""
        realm_id = self._require_realm_id()

        params = []
        if cursor:
            params.append(f"cursor={cursor}")
        if limit:
            params.append(f"limit={limit}")

        path = f"/api/realm/{realm_id}/depots"
        if params:
            path += "?" + "&".join(params)

        result = await self._fetcher.request(path)
        if result.ok:
            data = result.data
            items = [_parse_depot(item) for item in data.get("items", [])]
            return FetchResultOk(
                ok=True,
                data=PaginatedResponse(
                    items=items,
                    next_cursor=data.get("next_cursor"),
                    total=data.get("total"),
                ),
                status=result.status,
            )
        return result

    async def get(
        self,
        *,
        depot_id: str,
        max_history: int | None = None,
    ) -> FetchResult[DepotDetail]:
        """Get depot detail with history."""
        path = f"/api/depot/{depot_id}"
        if max_history is not None:
            path += f"?maxHistory={max_history}"

        result = await self._fetcher.request(path)
        if result.ok:
            return FetchResultOk(
                ok=True,
                data=_parse_depot_detail(result.data),
                status=result.status,
            )
        return result

    async def update(
        self,
        *,
        depot_id: str,
        title: str | None = None,
        max_history: int | None = None,
    ) -> FetchResult[DepotInfo]:
        """Update depot metadata."""
        body: dict = {}
        if title is not None:
            body["title"] = title
        if max_history is not None:
            body["maxHistory"] = max_history

        result = await self._fetcher.request(
            f"/api/depot/{depot_id}",
            RequestOptions(method="PATCH", body=body),
        )
        if result.ok:
            return FetchResultOk(
                ok=True,
                data=_parse_depot(result.data),
                status=result.status,
            )
        return result

    async def commit(
        self,
        *,
        depot_id: str,
        root: str,
        message: str | None = None,
        expected_root: str | None = None,
    ) -> FetchResult[DepotInfo]:
        """Commit a new version to depot."""
        body: dict = {"root": root}
        if message is not None:
            body["message"] = message
        if expected_root is not None:
            body["expectedRoot"] = expected_root

        result = await self._fetcher.request(
            f"/api/depot/{depot_id}/commit",
            RequestOptions(method="POST", body=body),
        )
        if result.ok:
            return FetchResultOk(
                ok=True,
                data=_parse_depot(result.data),
                status=result.status,
            )
        return result

    async def delete(
        self,
        *,
        depot_id: str,
    ) -> FetchResult[dict]:
        """Delete a depot."""
        result = await self._fetcher.request(
            f"/api/depot/{depot_id}",
            RequestOptions(method="DELETE"),
        )
        return result
