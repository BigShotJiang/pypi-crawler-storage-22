"""MCP API - JSON-RPC interface for tool calls."""

from typing import Any

from casfa.types.api import McpError, McpResponse
from casfa.utils.fetch import Fetcher, FetchResult, FetchResultOk, RequestOptions


class McpApi:
    """MCP API namespace for JSON-RPC tool calls."""

    def __init__(self, fetcher: Fetcher, get_realm_id: callable) -> None:
        self._fetcher = fetcher
        self._get_realm_id = get_realm_id
        self._request_id = 0

    def _next_id(self) -> int:
        """Generate next request ID."""
        self._request_id += 1
        return self._request_id

    async def call(
        self,
        *,
        method: str,
        params: dict[str, Any] | None = None,
    ) -> FetchResult[McpResponse]:
        """Make a raw MCP JSON-RPC call."""
        realm_id = self._get_realm_id()
        if not realm_id:
            from casfa.utils.errors import create_error
            from casfa.utils.fetch import FetchResultErr

            return FetchResultErr(
                ok=False,
                error=create_error("VALIDATION_ERROR", "realm_id is required for MCP calls"),
            )

        body = {
            "jsonrpc": "2.0",
            "id": self._next_id(),
            "method": method,
        }
        if params:
            body["params"] = params

        result = await self._fetcher.request(
            f"/api/realm/{realm_id}/mcp",
            RequestOptions(method="POST", body=body),
        )

        if result.ok:
            data = result.data
            error = None
            if "error" in data and data["error"]:
                err = data["error"]
                error = McpError(
                    code=err["code"],
                    message=err["message"],
                    data=err.get("data"),
                )

            return FetchResultOk(
                ok=True,
                data=McpResponse(
                    jsonrpc=data["jsonrpc"],
                    id=data["id"],
                    result=data.get("result"),
                    error=error,
                ),
                status=result.status,
            )
        return result

    async def list_tools(self) -> FetchResult[McpResponse]:
        """List available MCP tools."""
        return await self.call(method="tools/list")

    async def call_tool(
        self,
        *,
        name: str,
        arguments: dict[str, Any] | None = None,
    ) -> FetchResult[McpResponse]:
        """Call an MCP tool."""
        params: dict[str, Any] = {"name": name}
        if arguments:
            params["arguments"] = arguments

        return await self.call(method="tools/call", params=params)
