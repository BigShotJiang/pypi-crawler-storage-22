"""Nodes API - Node storage operations."""

from typing import Callable

from casfa.types.api import (
    DictNodeMetadata,
    FileNodeMetadata,
    NodeMetadata,
    PrepareNodesResult,
    SuccessorNodeMetadata,
)
from casfa.utils.fetch import Fetcher, FetchResult, FetchResultOk, RequestOptions


def _parse_node_metadata(data: dict) -> NodeMetadata:
    """Parse node metadata from API response."""
    kind = data["kind"]

    if kind == "dict":
        return DictNodeMetadata(
            key=data["key"],
            kind="dict",
            size=data["size"],
            children=data["children"],
        )
    elif kind == "file":
        return FileNodeMetadata(
            key=data["key"],
            kind="file",
            size=data["size"],
            content_type=data["content_type"],
            children_count=data["children_count"],
        )
    else:  # successor
        return SuccessorNodeMetadata(
            key=data["key"],
            kind="successor",
            size=data["size"],
            children_count=data["children_count"],
        )


class NodeApi:
    """Node API namespace for node storage operations."""

    def __init__(self, fetcher: Fetcher, get_realm_id: Callable[[], str | None]) -> None:
        self._fetcher = fetcher
        self._get_realm_id = get_realm_id

    def _require_realm_id(self) -> str:
        """Get realm_id or raise error."""
        realm_id = self._get_realm_id()
        if not realm_id:
            raise ValueError("realm_id is required - set it on the client or in config")
        return realm_id

    async def prepare(
        self,
        *,
        keys: list[str],
    ) -> FetchResult[PrepareNodesResult]:
        """Check which nodes exist and which are missing."""
        realm_id = self._require_realm_id()

        result = await self._fetcher.request(
            f"/api/realm/{realm_id}/nodes/prepare",
            RequestOptions(method="POST", body={"keys": keys}),
        )
        if result.ok:
            data = result.data
            return FetchResultOk(
                ok=True,
                data=PrepareNodesResult(
                    exists=data.get("exists", []),
                    missing=data.get("missing", []),
                ),
                status=result.status,
            )
        return result

    async def get_metadata(
        self,
        *,
        key: str,
    ) -> FetchResult[NodeMetadata]:
        """Get node metadata."""
        realm_id = self._require_realm_id()

        result = await self._fetcher.request(f"/api/realm/{realm_id}/node/{key}")
        if result.ok:
            return FetchResultOk(
                ok=True,
                data=_parse_node_metadata(result.data),
                status=result.status,
            )
        return result

    async def get(
        self,
        *,
        key: str,
    ) -> FetchResult[bytes]:
        """Download node content."""
        realm_id = self._require_realm_id()

        result = await self._fetcher.download_binary(f"/api/realm/{realm_id}/node/{key}/data")
        return result

    async def put(
        self,
        *,
        key: str,
        data: bytes,
        content_md5: str | None = None,
        blake3_hash: str | None = None,
    ) -> FetchResult[dict]:
        """Upload node content."""
        realm_id = self._require_realm_id()

        headers: dict[str, str] = {}
        if content_md5:
            headers["Content-MD5"] = content_md5
        if blake3_hash:
            headers["X-Blake3-Hash"] = blake3_hash

        result = await self._fetcher.upload_binary(
            f"/api/realm/{realm_id}/node/{key}/data",
            data,
            content_type="application/octet-stream",
            headers=headers,
        )
        return result

    async def upload(
        self,
        *,
        data: bytes,
    ) -> FetchResult[dict]:
        """Upload content and let server compute key."""
        realm_id = self._require_realm_id()

        result = await self._fetcher.upload_binary(
            f"/api/realm/{realm_id}/nodes/upload",
            data,
            content_type="application/octet-stream",
        )
        return result
