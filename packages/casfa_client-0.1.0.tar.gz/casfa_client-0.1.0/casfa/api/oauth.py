"""OAuth API - mirrors casfa-client-v2/api/oauth.ts."""

from casfa.types.api import CognitoConfig, TokenResponse, UserInfo
from casfa.utils.fetch import Fetcher, FetchResult, RequestOptions


class OAuthApi:
    """OAuth API namespace."""

    def __init__(self, fetcher: Fetcher) -> None:
        self._fetcher = fetcher
        self._cognito_config: CognitoConfig | None = None

    async def get_config(self) -> FetchResult[CognitoConfig]:
        """Get Cognito configuration."""
        result = await self._fetcher.request(
            "/api/oauth/config",
            RequestOptions(skip_auth=True),
        )
        if result.ok:
            data = result.data
            config = CognitoConfig(
                user_pool_id=data["user_pool_id"],
                client_id=data["client_id"],
                domain=data["domain"],
                region=data["region"],
            )
            self._cognito_config = config
            # Return with typed data
            from casfa.utils.fetch import FetchResultOk

            return FetchResultOk(ok=True, data=config, status=result.status)
        return result

    async def exchange_code(
        self,
        *,
        code: str,
        redirect_uri: str,
    ) -> FetchResult[TokenResponse]:
        """Exchange authorization code for tokens."""
        result = await self._fetcher.request(
            "/api/oauth/token",
            RequestOptions(
                method="POST",
                body={"code": code, "redirect_uri": redirect_uri},
                skip_auth=True,
            ),
        )
        if result.ok:
            data = result.data
            token_response = TokenResponse(
                access_token=data["access_token"],
                id_token=data["id_token"],
                token_type=data["token_type"],
                expires_in=data["expires_in"],
                refresh_token=data.get("refresh_token"),
            )
            from casfa.utils.fetch import FetchResultOk

            return FetchResultOk(ok=True, data=token_response, status=result.status)
        return result

    async def login(
        self,
        *,
        email: str,
        password: str,
    ) -> FetchResult[TokenResponse]:
        """Login with email and password."""
        result = await self._fetcher.request(
            "/api/oauth/login",
            RequestOptions(
                method="POST",
                body={"email": email, "password": password},
                skip_auth=True,
            ),
        )
        if result.ok:
            data = result.data
            token_response = TokenResponse(
                access_token=data["access_token"],
                id_token=data["id_token"],
                token_type=data["token_type"],
                expires_in=data["expires_in"],
                refresh_token=data.get("refresh_token"),
            )
            from casfa.utils.fetch import FetchResultOk

            return FetchResultOk(ok=True, data=token_response, status=result.status)
        return result

    async def refresh(
        self,
        *,
        refresh_token: str,
    ) -> FetchResult[TokenResponse]:
        """Refresh access token."""
        result = await self._fetcher.request(
            "/api/oauth/refresh",
            RequestOptions(
                method="POST",
                body={"refreshToken": refresh_token},
                skip_auth=True,
            ),
        )
        if result.ok:
            data = result.data
            token_response = TokenResponse(
                access_token=data["access_token"],
                id_token=data["id_token"],
                token_type=data["token_type"],
                expires_in=data["expires_in"],
                refresh_token=data.get("refresh_token"),
            )
            from casfa.utils.fetch import FetchResultOk

            return FetchResultOk(ok=True, data=token_response, status=result.status)
        return result

    async def get_me(self) -> FetchResult[UserInfo]:
        """Get current user information."""
        result = await self._fetcher.request("/api/oauth/me")
        if result.ok:
            data = result.data
            user_info = UserInfo(
                user_id=data["user_id"],
                email=data["email"],
                role=data["role"],
                realm_id=data.get("realm_id"),
            )
            from casfa.utils.fetch import FetchResultOk

            return FetchResultOk(ok=True, data=user_info, status=result.status)
        return result

    def build_auth_url(
        self,
        *,
        redirect_uri: str,
        state: str | None = None,
    ) -> str:
        """Build OAuth authorization URL."""
        if not self._cognito_config:
            raise RuntimeError("Call get_config() first to load Cognito configuration")

        url = (
            f"https://{self._cognito_config.domain}/oauth2/authorize"
            f"?client_id={self._cognito_config.client_id}"
            f"&response_type=code"
            f"&scope=openid+email+profile"
            f"&redirect_uri={redirect_uri}"
        )
        if state:
            url += f"&state={state}"
        return url
