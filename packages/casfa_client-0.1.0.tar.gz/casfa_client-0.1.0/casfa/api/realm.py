"""Realm API - Realm information and usage."""

from typing import Callable

from casfa.types.api import RealmInfo, RealmUsage
from casfa.utils.fetch import Fetcher, FetchResult, FetchResultOk


class RealmApi:
    """Realm API namespace for realm information and usage."""

    def __init__(self, fetcher: Fetcher, get_realm_id: Callable[[], str | None]) -> None:
        self._fetcher = fetcher
        self._get_realm_id = get_realm_id

    def _require_realm_id(self) -> str:
        """Get realm_id or raise error."""
        realm_id = self._get_realm_id()
        if not realm_id:
            raise ValueError("realm_id is required - set it on the client or in config")
        return realm_id

    async def get_info(self) -> FetchResult[RealmInfo]:
        """Get realm configuration and limits."""
        realm_id = self._require_realm_id()

        result = await self._fetcher.request(f"/api/realm/{realm_id}")
        if result.ok:
            data = result.data
            return FetchResultOk(
                ok=True,
                data=RealmInfo(
                    realm_id=data["realm_id"],
                    owner_id=data["owner_id"],
                    node_limit=data["node_limit"],
                    max_name_bytes=data["max_name_bytes"],
                ),
                status=result.status,
            )
        return result

    async def get_usage(self) -> FetchResult[RealmUsage]:
        """Get realm usage statistics."""
        realm_id = self._require_realm_id()

        result = await self._fetcher.request(f"/api/realm/{realm_id}/usage")
        if result.ok:
            data = result.data
            return FetchResultOk(
                ok=True,
                data=RealmUsage(
                    realm_id=data["realm_id"],
                    node_count=data["node_count"],
                    total_bytes=data["total_bytes"],
                ),
                status=result.status,
            )
        return result
