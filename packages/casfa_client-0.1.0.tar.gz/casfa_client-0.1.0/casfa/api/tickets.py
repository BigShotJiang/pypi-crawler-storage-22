"""Tickets API - Ticket management."""

from typing import Callable

from casfa.types.api import PaginatedResponse, TicketInfo, WritableConfig
from casfa.utils.fetch import Fetcher, FetchResult, FetchResultOk, RequestOptions


def _parse_ticket(data: dict) -> TicketInfo:
    """Parse ticket data from API response."""
    writable = None
    if data.get("writable"):
        w = data["writable"]
        writable = WritableConfig(
            quota=w.get("quota"),
            accept=w.get("accept"),
        )

    return TicketInfo(
        ticket_id=data["ticket_id"],
        realm_id=data["realm_id"],
        issuer_id=data["issuer_id"],
        scope=data.get("scope", []),
        output=data.get("output"),
        is_revoked=data.get("is_revoked", False),
        created_at=data["created_at"],
        expires_at=data["expires_at"],
        writable=writable,
        label=data.get("label"),
    )


class TicketApi:
    """Ticket API namespace for ticket management."""

    def __init__(self, fetcher: Fetcher, get_realm_id: Callable[[], str | None]) -> None:
        self._fetcher = fetcher
        self._get_realm_id = get_realm_id

    def _require_realm_id(self) -> str:
        """Get realm_id or raise error."""
        realm_id = self._get_realm_id()
        if not realm_id:
            raise ValueError("realm_id is required - set it on the client or in config")
        return realm_id

    async def create(
        self,
        *,
        input: list[str] | None = None,
        purpose: str | None = None,
        writable: WritableConfig | None = None,
        expires_in: int | None = None,
    ) -> FetchResult[TicketInfo]:
        """Create a new ticket."""
        realm_id = self._require_realm_id()

        body: dict = {}
        if input is not None:
            body["input"] = input
        if purpose is not None:
            body["purpose"] = purpose
        if writable is not None:
            w: dict = {}
            if writable.quota is not None:
                w["quota"] = writable.quota
            if writable.accept is not None:
                w["accept"] = writable.accept
            body["writable"] = w
        if expires_in is not None:
            body["expiresIn"] = expires_in

        result = await self._fetcher.request(
            f"/api/realm/{realm_id}/tickets",
            RequestOptions(method="POST", body=body),
        )
        if result.ok:
            return FetchResultOk(
                ok=True,
                data=_parse_ticket(result.data),
                status=result.status,
            )
        return result

    async def list(
        self,
        *,
        cursor: str | None = None,
        limit: int | None = None,
        status: str | None = None,
    ) -> FetchResult[PaginatedResponse[TicketInfo]]:
        """List tickets."""
        realm_id = self._require_realm_id()

        params = []
        if cursor:
            params.append(f"cursor={cursor}")
        if limit:
            params.append(f"limit={limit}")
        if status:
            params.append(f"status={status}")

        path = f"/api/realm/{realm_id}/tickets"
        if params:
            path += "?" + "&".join(params)

        result = await self._fetcher.request(path)
        if result.ok:
            data = result.data
            items = [_parse_ticket(item) for item in data.get("items", [])]
            return FetchResultOk(
                ok=True,
                data=PaginatedResponse(
                    items=items,
                    next_cursor=data.get("next_cursor"),
                    total=data.get("total"),
                ),
                status=result.status,
            )
        return result

    async def get(
        self,
        *,
        ticket_id: str,
    ) -> FetchResult[TicketInfo]:
        """Get ticket by ID."""
        result = await self._fetcher.request(f"/api/ticket/{ticket_id}")
        if result.ok:
            return FetchResultOk(
                ok=True,
                data=_parse_ticket(result.data),
                status=result.status,
            )
        return result

    async def commit(
        self,
        *,
        ticket_id: str,
        output: str,
    ) -> FetchResult[TicketInfo]:
        """Commit ticket output."""
        result = await self._fetcher.request(
            f"/api/ticket/{ticket_id}/commit",
            RequestOptions(method="POST", body={"output": output}),
        )
        if result.ok:
            return FetchResultOk(
                ok=True,
                data=_parse_ticket(result.data),
                status=result.status,
            )
        return result

    async def revoke(
        self,
        *,
        ticket_id: str,
    ) -> FetchResult[TicketInfo]:
        """Revoke a ticket."""
        result = await self._fetcher.request(
            f"/api/ticket/{ticket_id}/revoke",
            RequestOptions(method="POST"),
        )
        if result.ok:
            return FetchResultOk(
                ok=True,
                data=_parse_ticket(result.data),
                status=result.status,
            )
        return result

    async def delete(
        self,
        *,
        ticket_id: str,
    ) -> FetchResult[dict]:
        """Delete a ticket."""
        result = await self._fetcher.request(
            f"/api/ticket/{ticket_id}",
            RequestOptions(method="DELETE"),
        )
        return result
