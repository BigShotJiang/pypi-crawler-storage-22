"""CASFA auth strategies and permissions."""

from casfa.auth.p256 import P256Auth, create_p256_auth
from casfa.auth.permissions import (
    API_PERMISSIONS,
    ApiName,
    PermissionCheckResult,
    assert_access,
    can_access,
    check_permission,
    get_required_auth,
    is_public_api,
)
from casfa.auth.ticket import TicketAuth, create_ticket_auth
from casfa.auth.token import TokenAuth, create_token_auth
from casfa.auth.user import UserAuth, create_user_auth

__all__ = [
    # Permissions
    "API_PERMISSIONS",
    "ApiName",
    "PermissionCheckResult",
    "assert_access",
    "can_access",
    "check_permission",
    "get_required_auth",
    "is_public_api",
    # Auth strategies
    "TokenAuth",
    "create_token_auth",
    "TicketAuth",
    "create_ticket_auth",
    "UserAuth",
    "create_user_auth",
    "P256Auth",
    "create_p256_auth",
]
