"""P256 (AWP Client) auth strategy - mirrors casfa-client-v2/auth/p256.ts."""

import asyncio
import time
from typing import TYPE_CHECKING

from casfa.types.auth import AuthState, P256AuthConfig, P256AuthState, P256PollStatus
from casfa.types.providers import KeyPairProvider

if TYPE_CHECKING:
    from casfa.utils.fetch import Fetcher


class P256Auth:
    """P256 client authentication strategy for AWP."""

    def __init__(
        self,
        config: P256AuthConfig,
        key_provider: KeyPairProvider,
    ) -> None:
        self._callbacks = config.callbacks
        self._client_name = config.client_name
        self._key_provider = key_provider
        self._state = P256AuthState(
            type="p256",
            client_id=None,
            authorized=False,
        )
        self._fetcher: "Fetcher | None" = None
        self._public_key_hex: str | None = None
        self._private_key: bytes | None = None

    def set_fetcher(self, fetcher: "Fetcher") -> None:
        """Set the fetcher for making auth requests."""
        self._fetcher = fetcher

    def get_state(self) -> AuthState:
        """Get current authentication state."""
        return P256AuthState(
            type="p256",
            client_id=self._state.client_id,
            authorized=self._state.authorized,
        )

    async def get_auth_header(self) -> str | None:
        """P256 auth doesn't use Authorization header."""
        return None

    async def get_custom_headers(self) -> dict[str, str] | None:
        """Get custom headers with P256 signature."""
        if not self._state.authorized or not self._public_key_hex or not self._private_key:
            return None

        timestamp = str(int(time.time() * 1000))
        signature = await self._sign_timestamp(timestamp)

        return {
            "X-AWP-Pubkey": self._public_key_hex,
            "X-AWP-Timestamp": timestamp,
            "X-AWP-Signature": signature,
        }

    async def initialize(self) -> None:
        """Initialize P256 authentication - load or generate keys, then authorize."""
        # Load or generate key pair
        key_pair = await self._key_provider.load()
        if not key_pair:
            key_pair = await self._key_provider.generate()
            await self._key_provider.save(key_pair)

        self._public_key_hex = key_pair.public_key.hex()
        self._private_key = key_pair.private_key

        # Start authorization flow
        await self._authorize()

    async def handle_unauthorized(self) -> bool:
        """Handle 401 - re-authorize."""
        self._state.authorized = False
        try:
            await self._authorize()
            return True
        except Exception:
            return False

    async def _authorize(self) -> None:
        """Perform P256 client authorization flow."""
        if not self._fetcher or not self._public_key_hex:
            raise RuntimeError("Fetcher or public key not set")

        from casfa.utils.fetch import RequestOptions

        # Init client
        result = await self._fetcher.request(
            "/api/auth/awp/init",
            RequestOptions(
                method="POST",
                body={
                    "pubkey": self._public_key_hex,
                    "client_name": self._client_name,
                },
                skip_auth=True,
            ),
        )

        if not result.ok:
            raise RuntimeError(f"AWP init failed: {result.error.message}")

        init_data = result.data
        client_id = init_data["client_id"]
        auth_url = init_data["auth_url"]
        display_code = init_data["display_code"]

        self._state.client_id = client_id

        # Notify callback
        self._callbacks.on_auth_required(auth_url, display_code)

        # Poll for authorization
        await self._poll_authorization(client_id)

    async def _poll_authorization(self, client_id: str) -> None:
        """Poll for client authorization status."""
        if not self._fetcher:
            raise RuntimeError("Fetcher not set")

        from casfa.utils.fetch import RequestOptions

        while True:
            result = await self._fetcher.request(
                f"/api/auth/awp/poll/{client_id}",
                RequestOptions(skip_auth=True),
            )

            if not result.ok:
                raise RuntimeError(f"AWP poll failed: {result.error.message}")

            poll_data = result.data
            status = poll_data["status"]
            message = poll_data.get("message")

            poll_status = P256PollStatus(
                authorized=status == "authorized",
                client_id=client_id,
                message=message,
            )

            if status == "authorized":
                self._state.authorized = True
                self._callbacks.on_poll_status(poll_status)
                return

            if status in ("expired", "rejected"):
                self._callbacks.on_poll_status(poll_status)
                raise RuntimeError(f"AWP authorization {status}: {message}")

            # Pending - callback decides poll interval
            poll_interval = self._callbacks.on_poll_status(poll_status)
            if poll_interval is None:
                raise RuntimeError("AWP authorization cancelled by callback")

            await asyncio.sleep(poll_interval / 1000)

    async def _sign_timestamp(self, timestamp: str) -> str:
        """Sign timestamp with private key."""
        if not self._private_key:
            raise RuntimeError("Private key not set")

        data = timestamp.encode("utf-8")
        signature = await self._key_provider.sign(data, self._private_key)
        return signature.hex()


def create_p256_auth(config: P256AuthConfig, key_provider: KeyPairProvider) -> P256Auth:
    """Create a P256 client authentication strategy."""
    return P256Auth(config, key_provider)
