"""Permission matrix - mirrors casfa-client-v2/auth/permissions.ts."""

from dataclasses import dataclass
from typing import Literal

from casfa.types.auth import AuthState, AuthType
from casfa.utils.errors import CasfaError, create_permission_error

ApiName = Literal[
    # OAuth - public endpoints
    "oauth.getConfig",
    "oauth.exchangeCode",
    "oauth.login",
    "oauth.refresh",
    # OAuth - authenticated
    "oauth.getMe",
    # AWP Client - public
    "auth.initClient",
    "auth.pollClient",
    # AWP Client - user only
    "auth.completeClient",
    "auth.listClients",
    "auth.revokeClient",
    # Agent Token - user only
    "auth.createAgentToken",
    "auth.listAgentTokens",
    "auth.revokeAgentToken",
    # Admin - admin user only
    "admin.listUsers",
    "admin.updateUserRole",
    # MCP - user or agent
    "mcp.call",
    # Realm - user, agent, or ticket
    "realm.getInfo",
    "realm.getUsage",
    # Tickets
    "tickets.create",
    "tickets.list",
    "tickets.get",
    "tickets.commit",
    "tickets.revoke",
    "tickets.delete",
    # Depots
    "depots.create",
    "depots.list",
    "depots.get",
    "depots.update",
    "depots.commit",
    "depots.delete",
    # Nodes
    "nodes.prepare",
    "nodes.getMetadata",
    "nodes.get",
    "nodes.put",
]

# Permission requirements: None = public, list = any of the auth types allowed
API_PERMISSIONS: dict[ApiName, list[AuthType] | None] = {
    # OAuth - public
    "oauth.getConfig": None,
    "oauth.exchangeCode": None,
    "oauth.login": None,
    "oauth.refresh": None,
    # OAuth - authenticated
    "oauth.getMe": ["user"],
    # AWP Client - public
    "auth.initClient": None,
    "auth.pollClient": None,
    # AWP Client - user only
    "auth.completeClient": ["user"],
    "auth.listClients": ["user"],
    "auth.revokeClient": ["user"],
    # Agent Token - user only
    "auth.createAgentToken": ["user"],
    "auth.listAgentTokens": ["user"],
    "auth.revokeAgentToken": ["user"],
    # Admin - admin user only (role check done separately)
    "admin.listUsers": ["user"],
    "admin.updateUserRole": ["user"],
    # MCP - user or agent
    "mcp.call": ["user", "token"],
    # Realm - user, agent, or ticket
    "realm.getInfo": ["user", "token", "ticket"],
    "realm.getUsage": ["user", "token", "ticket"],
    # Tickets
    "tickets.create": ["user", "token"],
    "tickets.list": ["user", "token"],
    "tickets.get": ["user", "token", "ticket"],
    "tickets.commit": ["ticket"],
    "tickets.revoke": ["user", "token"],
    "tickets.delete": ["user"],
    # Depots
    "depots.create": ["user", "token"],
    "depots.list": ["user", "token", "ticket"],
    "depots.get": ["user", "token", "ticket"],
    "depots.update": ["user", "token"],
    "depots.commit": ["user", "token"],
    "depots.delete": ["user", "token"],
    # Nodes
    "nodes.prepare": ["user", "token", "ticket"],
    "nodes.getMetadata": ["user", "token", "ticket"],
    "nodes.get": ["user", "token", "ticket"],
    "nodes.put": ["user", "token", "ticket"],
}


def can_access(auth_state: AuthState | None, api: ApiName) -> bool:
    """Check if the current auth state can access the specified API."""
    required = API_PERMISSIONS.get(api)

    if required is None:
        return True  # Public API

    if auth_state is None:
        return False

    return auth_state.type in required


def assert_access(auth_state: AuthState | None, api: ApiName) -> None:
    """Assert that the current auth state can access the specified API.

    Raises:
        CasfaError: If permission is denied.
    """
    if not can_access(auth_state, api):
        required = API_PERMISSIONS.get(api) or ["none"]
        raise create_permission_error(api, required)


def get_required_auth(api: ApiName) -> list[AuthType] | None:
    """Get required auth types for an API."""
    return API_PERMISSIONS.get(api)


def is_public_api(api: ApiName) -> bool:
    """Check if API is public (no auth required)."""
    return API_PERMISSIONS.get(api) is None


@dataclass
class PermissionCheckResult:
    """Result of permission check."""

    allowed: bool
    error: CasfaError | None = None


def check_permission(auth_state: AuthState | None, api: ApiName) -> PermissionCheckResult:
    """Check permission and return result object."""
    if can_access(auth_state, api):
        return PermissionCheckResult(allowed=True)

    required = API_PERMISSIONS.get(api) or ["none"]
    return PermissionCheckResult(
        allowed=False,
        error=create_permission_error(api, required),
    )
