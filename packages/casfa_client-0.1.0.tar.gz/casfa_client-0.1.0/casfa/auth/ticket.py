"""Ticket auth strategy - mirrors casfa-client-v2/auth/ticket.ts."""

import time

from casfa.types.auth import AuthState, TicketAuthConfig, TicketAuthState


class TicketAuth:
    """Ticket authentication strategy."""

    def __init__(self, config: TicketAuthConfig) -> None:
        self._state = TicketAuthState(
            type="ticket",
            ticket_id=config.ticket_id,
            realm_id=config.realm_id,
            scope=None,
            writable=None,
            expires_at=None,
        )

    def get_state(self) -> AuthState:
        """Get current authentication state."""
        return TicketAuthState(
            type="ticket",
            ticket_id=self._state.ticket_id,
            realm_id=self._state.realm_id,
            scope=self._state.scope,
            writable=self._state.writable,
            expires_at=self._state.expires_at,
        )

    async def get_auth_header(self) -> str | None:
        """Get authorization header value."""
        return f"Ticket {self._state.ticket_id}"

    async def get_custom_headers(self) -> dict[str, str] | None:
        """Ticket auth doesn't use custom headers."""
        return None

    async def initialize(self) -> None:
        """No initialization needed for ticket."""
        pass

    async def handle_unauthorized(self) -> bool:
        """Check if ticket might be expired or revoked."""
        if self._state.expires_at:
            now_ms = int(time.time() * 1000)
            if now_ms > self._state.expires_at:
                return False  # Ticket is expired
        return False  # Ticket might be revoked or invalid

    # Additional methods for ticket state management

    def can_access_path(self, path: str) -> bool:
        """Check if the ticket allows access to a path."""
        if not self._state.scope:
            return True  # Full access if no scope specified
        return any(path == s or path.startswith(f"{s}/") for s in self._state.scope)

    def can_write(self) -> bool:
        """Check if the ticket allows write access."""
        return self._state.writable is True

    def update_info(
        self,
        *,
        realm_id: str | None = None,
        scope: list[str] | None = None,
        writable: bool | None = None,
        expires_at: int | None = None,
    ) -> None:
        """Update ticket information from server response."""
        if realm_id is not None:
            self._state.realm_id = realm_id
        if scope is not None:
            self._state.scope = scope
        if writable is not None:
            self._state.writable = writable
        if expires_at is not None:
            self._state.expires_at = expires_at

    @property
    def ticket_id(self) -> str:
        """Get the ticket ID."""
        return self._state.ticket_id

    @property
    def realm_id(self) -> str | None:
        """Get the realm ID."""
        return self._state.realm_id


def create_ticket_auth(config: TicketAuthConfig) -> TicketAuth:
    """Create a ticket authentication strategy."""
    return TicketAuth(config)
