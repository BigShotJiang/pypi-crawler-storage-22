"""Token auth strategy - mirrors casfa-client-v2/auth/token.ts."""

from casfa.types.auth import AuthState, TokenAuthConfig, TokenAuthState


class TokenAuth:
    """Agent token authentication strategy."""

    def __init__(self, config: TokenAuthConfig) -> None:
        self._token = config.token
        self._state = TokenAuthState(type="token", token=config.token)

    def get_state(self) -> AuthState:
        """Get current authentication state."""
        return TokenAuthState(type="token", token=self._state.token)

    async def get_auth_header(self) -> str | None:
        """Get authorization header value."""
        return f"AgentToken {self._token}"

    async def get_custom_headers(self) -> dict[str, str] | None:
        """Token auth doesn't use custom headers."""
        return None

    async def initialize(self) -> None:
        """No initialization needed for static token."""
        pass

    async def handle_unauthorized(self) -> bool:
        """Cannot refresh a static token."""
        return False


def create_token_auth(config: TokenAuthConfig) -> TokenAuth:
    """Create a token authentication strategy using an Agent Token."""
    return TokenAuth(config)
