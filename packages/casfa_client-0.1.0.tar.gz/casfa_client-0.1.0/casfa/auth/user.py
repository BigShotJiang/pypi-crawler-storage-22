"""User (OAuth) auth strategy - mirrors casfa-client-v2/auth/user.ts."""

import time
from typing import TYPE_CHECKING

from casfa.types.auth import AuthState, UserAuthConfig, UserAuthState

if TYPE_CHECKING:
    from casfa.utils.fetch import Fetcher


class UserAuth:
    """User OAuth authentication strategy."""

    def __init__(self, config: UserAuthConfig) -> None:
        self._callbacks = config.callbacks
        self._state = UserAuthState(
            type="user",
            access_token=None,
            refresh_token=None,
            expires_at=None,
        )
        self._fetcher: "Fetcher | None" = None
        self._cognito_config: dict | None = None

    def set_fetcher(self, fetcher: "Fetcher") -> None:
        """Set the fetcher for making auth requests."""
        self._fetcher = fetcher

    def get_state(self) -> AuthState:
        """Get current authentication state."""
        return UserAuthState(
            type="user",
            access_token=self._state.access_token,
            refresh_token=self._state.refresh_token,
            expires_at=self._state.expires_at,
        )

    async def get_auth_header(self) -> str | None:
        """Get authorization header value."""
        if self._state.access_token:
            return f"Bearer {self._state.access_token}"
        return None

    async def get_custom_headers(self) -> dict[str, str] | None:
        """User auth doesn't use custom headers."""
        return None

    async def initialize(self) -> None:
        """Initialize authentication - attempt silent refresh or request login."""
        # Try silent refresh first
        if self._callbacks.on_silent_refresh:
            token = await self._callbacks.on_silent_refresh()
            if token:
                self._state.refresh_token = token
                await self._do_refresh()
                return

        # Otherwise, do full auth flow
        await self._do_auth_flow()

    async def handle_unauthorized(self) -> bool:
        """Handle 401 - try to refresh token."""
        if self._state.refresh_token:
            try:
                await self._do_refresh()
                return True
            except Exception as e:
                retry_ms = self._callbacks.on_refresh_failed(e)
                if retry_ms is not None:
                    await self._sleep_ms(retry_ms)
                    return await self.handle_unauthorized()
        return False

    async def _do_auth_flow(self) -> None:
        """Perform full OAuth authorization flow."""
        if not self._fetcher:
            raise RuntimeError("Fetcher not set on UserAuth")

        # Get Cognito config
        from casfa.utils.fetch import RequestOptions

        result = await self._fetcher.request(
            "/api/oauth/config",
            RequestOptions(skip_auth=True),
        )
        if not result.ok:
            raise RuntimeError(f"Failed to get OAuth config: {result.error.message}")

        self._cognito_config = result.data

        # Build auth URL
        auth_url = self._build_auth_url()

        # Call callback to get authorization code
        code = await self._callbacks.on_auth_required(auth_url)

        # Exchange code for tokens
        await self._exchange_code(code)

    async def _do_refresh(self) -> None:
        """Refresh the access token."""
        if not self._fetcher or not self._state.refresh_token:
            raise RuntimeError("Cannot refresh: no fetcher or refresh token")

        from casfa.utils.fetch import RequestOptions

        result = await self._fetcher.request(
            "/api/oauth/refresh",
            RequestOptions(
                method="POST",
                body={"refreshToken": self._state.refresh_token},
                skip_auth=True,
            ),
        )

        if not result.ok:
            raise RuntimeError(f"Token refresh failed: {result.error.message}")

        self._update_tokens(result.data)

    async def _exchange_code(self, code: str) -> None:
        """Exchange authorization code for tokens."""
        if not self._fetcher:
            raise RuntimeError("Fetcher not set on UserAuth")

        from casfa.utils.fetch import RequestOptions

        # Get redirect URI from config (would be passed from client)
        redirect_uri = "http://localhost:3000/callback"  # Default, should be configurable

        result = await self._fetcher.request(
            "/api/oauth/token",
            RequestOptions(
                method="POST",
                body={"code": code, "redirect_uri": redirect_uri},
                skip_auth=True,
            ),
        )

        if not result.ok:
            raise RuntimeError(f"Token exchange failed: {result.error.message}")

        self._update_tokens(result.data)

    def _update_tokens(self, data: dict) -> None:
        """Update tokens from response."""
        self._state.access_token = data.get("access_token")
        self._state.refresh_token = data.get("refresh_token", self._state.refresh_token)

        expires_in = data.get("expires_in", 3600)
        self._state.expires_at = int(time.time() * 1000) + (expires_in * 1000)

    def _build_auth_url(self) -> str:
        """Build OAuth authorization URL."""
        if not self._cognito_config:
            raise RuntimeError("Cognito config not loaded")

        domain = self._cognito_config["domain"]
        client_id = self._cognito_config["client_id"]
        redirect_uri = "http://localhost:3000/callback"  # Should be configurable

        return (
            f"https://{domain}/oauth2/authorize"
            f"?client_id={client_id}"
            f"&response_type=code"
            f"&scope=openid+email+profile"
            f"&redirect_uri={redirect_uri}"
        )

    @staticmethod
    async def _sleep_ms(ms: int) -> None:
        """Sleep for milliseconds."""
        import asyncio

        await asyncio.sleep(ms / 1000)


def create_user_auth(config: UserAuthConfig) -> UserAuth:
    """Create a user OAuth authentication strategy."""
    return UserAuth(config)
