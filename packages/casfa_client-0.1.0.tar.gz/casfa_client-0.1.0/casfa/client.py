"""CasfaClient - main client factory and implementation."""

from dataclasses import dataclass
from typing import Union

from casfa.api.admin import AdminApi
from casfa.api.auth import AuthApi
from casfa.api.depots import DepotApi
from casfa.api.mcp import McpApi
from casfa.api.nodes import NodeApi
from casfa.api.oauth import OAuthApi
from casfa.api.realm import RealmApi
from casfa.api.tickets import TicketApi
from casfa.auth.p256 import P256Auth, create_p256_auth
from casfa.auth.ticket import TicketAuth, create_ticket_auth
from casfa.auth.token import TokenAuth, create_token_auth
from casfa.auth.user import UserAuth, create_user_auth
from casfa.types.auth import (
    AuthConfig,
    AuthState,
)
from casfa.types.providers import HashProvider, KeyPairProvider, StorageProvider
from casfa.utils.fetch import FetchConfig, Fetcher, create_fetch


@dataclass
class CasfaClientConfig:
    """Configuration for creating a CasfaClient."""

    base_url: str
    auth: AuthConfig
    storage: StorageProvider | None = None
    hash: HashProvider | None = None
    key_pair: KeyPairProvider | None = None
    realm_id: str | None = None


AuthStrategy = Union[TokenAuth, TicketAuth, UserAuth, P256Auth]


class CasfaClient:
    """CASFA client with API namespaces."""

    def __init__(
        self,
        fetcher: Fetcher,
        auth_strategy: AuthStrategy,
        realm_id: str | None = None,
    ) -> None:
        self._fetcher = fetcher
        self._auth = auth_strategy
        self._realm_id = realm_id

        # Initialize API namespaces
        self._oauth = OAuthApi(fetcher)
        self._auth_api = AuthApi(fetcher)
        self._admin = AdminApi(fetcher)
        self._mcp = McpApi(fetcher, self.get_realm_id)
        self._realm = RealmApi(fetcher, self.get_realm_id)
        self._tickets = TicketApi(fetcher, self.get_realm_id)
        self._depots = DepotApi(fetcher, self.get_realm_id)
        self._nodes = NodeApi(fetcher, self.get_realm_id)

    # =========================================================================
    # State Management
    # =========================================================================

    def get_auth_state(self) -> AuthState:
        """Get current authentication state."""
        return self._auth.get_state()

    def get_realm_id(self) -> str | None:
        """Get current realm ID."""
        # For ticket auth, try to get realm_id from ticket state
        if isinstance(self._auth, TicketAuth) and self._auth.realm_id:
            return self._auth.realm_id
        return self._realm_id

    def set_realm_id(self, realm_id: str) -> None:
        """Set current realm ID."""
        self._realm_id = realm_id

    # =========================================================================
    # API Namespaces
    # =========================================================================

    @property
    def oauth(self) -> OAuthApi:
        """OAuth API namespace."""
        return self._oauth

    @property
    def auth(self) -> AuthApi:
        """Auth API namespace (AWP clients and agent tokens)."""
        return self._auth_api

    @property
    def admin(self) -> AdminApi:
        """Admin API namespace."""
        return self._admin

    @property
    def mcp(self) -> McpApi:
        """MCP API namespace."""
        return self._mcp

    @property
    def realm(self) -> RealmApi:
        """Realm API namespace."""
        return self._realm

    @property
    def tickets(self) -> TicketApi:
        """Tickets API namespace."""
        return self._tickets

    @property
    def depots(self) -> DepotApi:
        """Depots API namespace."""
        return self._depots

    @property
    def nodes(self) -> NodeApi:
        """Nodes API namespace."""
        return self._nodes

    # =========================================================================
    # Lifecycle
    # =========================================================================

    async def close(self) -> None:
        """Close the client and release resources."""
        await self._fetcher.close()


def _create_auth_strategy(
    config: AuthConfig,
    key_pair_provider: KeyPairProvider | None = None,
) -> AuthStrategy:
    """Create auth strategy from config."""
    if config.type == "token":
        return create_token_auth(config)
    elif config.type == "ticket":
        return create_ticket_auth(config)
    elif config.type == "user":
        return create_user_auth(config)
    elif config.type == "p256":
        if not key_pair_provider:
            raise ValueError("P256 auth requires a KeyPairProvider")
        return create_p256_auth(config, key_pair_provider)
    else:
        raise ValueError(f"Unknown auth type: {config.type}")


def create_casfa_client(config: CasfaClientConfig) -> CasfaClient:
    """Create a CasfaClient instance.

    Args:
        config: Client configuration including base URL, auth, and optional providers.

    Returns:
        CasfaClient instance ready for use.

    Example:
        >>> client = create_casfa_client(CasfaClientConfig(
        ...     base_url="https://casfa.example.com",
        ...     auth=TokenAuthConfig(type="token", token="casfa_xxx"),
        ...     realm_id="user:ABC123",
        ... ))
        >>> result = await client.realm.get_usage()
        >>> if result.ok:
        ...     print(f"Nodes: {result.data.node_count}")
    """
    # Create auth strategy
    auth_strategy = _create_auth_strategy(config.auth, config.key_pair)

    # Create fetcher with auth
    fetcher = create_fetch(FetchConfig(base_url=config.base_url, auth=auth_strategy))

    # For user/p256 auth, set fetcher for auth flow
    if isinstance(auth_strategy, (UserAuth, P256Auth)):
        auth_strategy.set_fetcher(fetcher)

    # Create client
    client = CasfaClient(
        fetcher=fetcher,
        auth_strategy=auth_strategy,
        realm_id=config.realm_id,
    )

    return client
