"""CASFA types - API responses, auth state, and provider interfaces."""

from casfa.types.api import (
    # Agent Token
    AgentTokenInfo,
    # AWP Client
    AwpAuthInitResponse,
    AwpAuthPollResponse,
    AwpClientInfo,
    # OAuth
    CognitoConfig,
    CreateAgentTokenResponse,
    DepotDetail,
    DepotHistoryEntry,
    # Depot
    DepotInfo,
    DictNodeMetadata,
    FileNodeMetadata,
    McpError,
    # MCP
    McpRequest,
    McpResponse,
    NodeKind,
    # Node
    NodeMetadata,
    # Pagination
    PaginatedResponse,
    PrepareNodesResult,
    # Realm
    RealmInfo,
    RealmUsage,
    SuccessorNodeMetadata,
    # Ticket
    TicketInfo,
    TicketListItem,
    TokenResponse,
    UserInfo,
    # Admin
    UserListItem,
    WritableConfig,
)
from casfa.types.auth import (
    AuthConfig,
    AuthState,
    AuthType,
    # P256
    P256AuthCallbacks,
    P256AuthConfig,
    P256AuthState,
    P256PollStatus,
    TicketAuthConfig,
    # Ticket
    TicketAuthState,
    TokenAuthConfig,
    # Token
    TokenAuthState,
    # User
    UserAuthCallbacks,
    UserAuthConfig,
    UserAuthState,
)
from casfa.types.providers import (
    HashProvider,
    KeyPairProvider,
    P256KeyPair,
    StorageProvider,
)

__all__ = [
    # API Types
    "CognitoConfig",
    "TokenResponse",
    "UserInfo",
    "AwpAuthInitResponse",
    "AwpAuthPollResponse",
    "AwpClientInfo",
    "AgentTokenInfo",
    "CreateAgentTokenResponse",
    "UserListItem",
    "RealmInfo",
    "RealmUsage",
    "TicketInfo",
    "TicketListItem",
    "WritableConfig",
    "DepotInfo",
    "DepotDetail",
    "DepotHistoryEntry",
    "NodeMetadata",
    "DictNodeMetadata",
    "FileNodeMetadata",
    "SuccessorNodeMetadata",
    "NodeKind",
    "PrepareNodesResult",
    "McpRequest",
    "McpResponse",
    "McpError",
    "PaginatedResponse",
    # Auth Types
    "AuthConfig",
    "AuthState",
    "AuthType",
    "UserAuthCallbacks",
    "UserAuthState",
    "UserAuthConfig",
    "TokenAuthState",
    "TokenAuthConfig",
    "TicketAuthState",
    "TicketAuthConfig",
    "P256AuthCallbacks",
    "P256AuthState",
    "P256AuthConfig",
    "P256PollStatus",
    # Provider Types
    "StorageProvider",
    "HashProvider",
    "KeyPairProvider",
    "P256KeyPair",
]
