"""API response types - mirrors TypeScript casfa-client-v2/types/api.ts."""

from dataclasses import dataclass, field
from typing import Any, Generic, Literal, TypeVar, Union

T = TypeVar("T")

# =============================================================================
# OAuth Response Types
# =============================================================================


@dataclass
class CognitoConfig:
    """AWS Cognito configuration for OAuth."""

    user_pool_id: str
    client_id: str
    domain: str
    region: str


@dataclass
class TokenResponse:
    """OAuth token response."""

    access_token: str
    id_token: str
    token_type: str
    expires_in: int
    refresh_token: str | None = None


@dataclass
class UserInfo:
    """Current user information."""

    user_id: str
    email: str
    role: Literal["unauthorized", "authorized", "admin"]
    realm_id: str | None = None


# =============================================================================
# AWP Client Response Types
# =============================================================================


@dataclass
class AwpAuthInitResponse:
    """Response from AWP client initialization."""

    client_id: str
    auth_url: str
    display_code: str
    expires_in: int


@dataclass
class AwpAuthPollResponse:
    """Response from AWP client authorization polling."""

    status: Literal["pending", "authorized", "expired", "rejected"]
    message: str | None = None


@dataclass
class AwpClientInfo:
    """AWP client information."""

    client_id: str
    created_at: int  # ms since epoch
    name: str | None = None
    last_used_at: int | None = None


# =============================================================================
# Agent Token Response Types
# =============================================================================


@dataclass
class AgentTokenInfo:
    """Agent token information (excludes actual token value)."""

    token_id: str
    name: str
    created_at: int  # ms since epoch
    last_used_at: int | None = None
    expires_at: int | None = None


@dataclass
class CreateAgentTokenResponse:
    """Response from creating an agent token (includes token value)."""

    token_id: str
    token: str  # Only returned once
    name: str
    expires_at: int | None = None


# =============================================================================
# Admin Response Types
# =============================================================================


@dataclass
class UserListItem:
    """User item in admin user list."""

    user_id: str
    email: str
    role: Literal["unauthorized", "authorized", "admin"]
    created_at: int
    realm_id: str | None = None


# =============================================================================
# Realm Response Types
# =============================================================================


@dataclass
class RealmInfo:
    """Realm configuration and limits."""

    realm_id: str
    owner_id: str
    node_limit: int
    max_name_bytes: int


@dataclass
class RealmUsage:
    """Realm usage statistics."""

    realm_id: str
    node_count: int
    total_bytes: int


# =============================================================================
# Ticket Response Types
# =============================================================================


@dataclass
class WritableConfig:
    """Ticket write permission configuration."""

    quota: int | None = None
    accept: list[str] | None = None


@dataclass
class TicketInfo:
    """Ticket information."""

    ticket_id: str
    realm_id: str
    issuer_id: str
    scope: list[str]
    output: str | None
    is_revoked: bool
    created_at: int  # ms since epoch
    expires_at: int  # ms since epoch
    writable: WritableConfig | None = None
    label: str | None = None


# Alias for list responses
TicketListItem = TicketInfo


# =============================================================================
# Depot Response Types
# =============================================================================


@dataclass
class DepotInfo:
    """Depot information."""

    depot_id: str
    realm_id: str
    title: str
    root: str
    version: int
    created_at: int  # ms since epoch
    updated_at: int  # ms since epoch
    description: str | None = None


@dataclass
class DepotHistoryEntry:
    """Single entry in depot commit history."""

    root: str
    version: int
    committed_at: int  # ms since epoch
    message: str | None = None


@dataclass
class DepotDetail:
    """Depot with full history."""

    depot_id: str
    realm_id: str
    title: str
    root: str
    version: int
    created_at: int  # ms since epoch
    updated_at: int  # ms since epoch
    history: list[DepotHistoryEntry] = field(default_factory=list)
    description: str | None = None


# =============================================================================
# Node Response Types
# =============================================================================

NodeKind = Literal["dict", "file", "successor"]


@dataclass
class DictNodeMetadata:
    """Metadata for a dict node."""

    key: str
    kind: Literal["dict"]
    size: int
    children: dict[str, str]


@dataclass
class FileNodeMetadata:
    """Metadata for a file node."""

    key: str
    kind: Literal["file"]
    size: int
    content_type: str
    children_count: int


@dataclass
class SuccessorNodeMetadata:
    """Metadata for a successor node."""

    key: str
    kind: Literal["successor"]
    size: int
    children_count: int


NodeMetadata = Union[DictNodeMetadata, FileNodeMetadata, SuccessorNodeMetadata]


@dataclass
class PrepareNodesResult:
    """Result of checking node existence."""

    exists: list[str]
    missing: list[str]


# =============================================================================
# MCP Types
# =============================================================================


@dataclass
class McpRequest:
    """MCP JSON-RPC request."""

    jsonrpc: Literal["2.0"]
    id: str | int
    method: str
    params: dict[str, Any] | None = None


@dataclass
class McpError:
    """MCP JSON-RPC error."""

    code: int
    message: str
    data: Any | None = None


@dataclass
class McpResponse:
    """MCP JSON-RPC response."""

    jsonrpc: Literal["2.0"]
    id: str | int
    result: Any | None = None
    error: McpError | None = None


# =============================================================================
# Pagination Types
# =============================================================================


@dataclass
class PaginatedResponse(Generic[T]):
    """Paginated list response."""

    items: list[T]
    next_cursor: str | None = None
    total: int | None = None
