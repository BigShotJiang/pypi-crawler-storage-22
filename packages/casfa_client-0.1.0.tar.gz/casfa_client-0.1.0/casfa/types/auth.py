"""Auth types - mirrors TypeScript casfa-client-v2/types/auth.ts."""

from dataclasses import dataclass
from typing import Awaitable, Callable, Literal, Protocol, Union

# =============================================================================
# User Auth
# =============================================================================


@dataclass
class UserAuthCallbacks:
    """Callbacks for OAuth user authentication flow."""

    on_auth_required: Callable[[str], Awaitable[str]]  # (auth_url) -> code
    on_refresh_failed: Callable[[Exception], int | None]  # (error) -> retry_ms or None
    on_silent_refresh: Callable[[], Awaitable[str | None]] | None = None


@dataclass
class UserAuthState:
    """User authentication state."""

    type: Literal["user"]
    access_token: str | None
    refresh_token: str | None
    expires_at: int | None  # ms since epoch


@dataclass
class UserAuthConfig:
    """Configuration for user OAuth authentication."""

    type: Literal["user"]
    callbacks: UserAuthCallbacks


# =============================================================================
# Token Auth (Agent Token)
# =============================================================================


@dataclass
class TokenAuthState:
    """Agent Token authentication state."""

    type: Literal["token"]
    token: str


@dataclass
class TokenAuthConfig:
    """Configuration for agent token authentication."""

    type: Literal["token"]
    token: str


# =============================================================================
# P256 Auth (AWP Client)
# =============================================================================


@dataclass
class P256PollStatus:
    """Polling status during P256 client authorization."""

    authorized: bool
    client_id: str
    message: str | None = None


@dataclass
class P256AuthCallbacks:
    """Callbacks for P256 client authentication flow."""

    on_auth_required: Callable[[str, str], None]  # (auth_url, display_code)
    on_poll_status: Callable[[P256PollStatus], int | None]  # (status) -> poll_interval_ms or None


@dataclass
class P256AuthState:
    """P256 client authentication state."""

    type: Literal["p256"]
    client_id: str | None
    authorized: bool


@dataclass
class P256AuthConfig:
    """Configuration for P256 client authentication."""

    type: Literal["p256"]
    callbacks: P256AuthCallbacks
    client_name: str = "casfa-python-client"


# =============================================================================
# Ticket Auth
# =============================================================================


@dataclass
class TicketAuthState:
    """Ticket authentication state."""

    type: Literal["ticket"]
    ticket_id: str
    realm_id: str | None
    scope: list[str] | None
    writable: bool | None
    expires_at: int | None  # ms since epoch


@dataclass
class TicketAuthConfig:
    """Configuration for ticket authentication."""

    type: Literal["ticket"]
    ticket_id: str
    realm_id: str | None = None


# =============================================================================
# Combined Types
# =============================================================================

AuthState = Union[UserAuthState, TokenAuthState, P256AuthState, TicketAuthState]
AuthType = Literal["user", "token", "p256", "ticket"]
AuthConfig = Union[UserAuthConfig, TokenAuthConfig, P256AuthConfig, TicketAuthConfig]


# =============================================================================
# AuthStrategy Protocol
# =============================================================================


class AuthStrategy(Protocol):
    """Internal auth strategy protocol with state management."""

    def get_state(self) -> AuthState:
        """Get current authentication state."""
        ...

    async def get_auth_header(self) -> str | None:
        """Get authorization header value for requests."""
        ...

    async def get_custom_headers(self) -> dict[str, str] | None:
        """Get custom headers for P256 signature auth."""
        ...

    async def initialize(self) -> None:
        """Initialize or refresh authentication."""
        ...

    async def handle_unauthorized(self) -> bool:
        """Handle 401 unauthorized response. Returns True if retry should occur."""
        ...
