"""Provider interfaces - mirrors TypeScript casfa-client-v2/types/providers.ts."""

from dataclasses import dataclass
from typing import Protocol


@dataclass
class P256KeyPair:
    """P256 Key Pair for AWP client authentication."""

    public_key: bytes  # Uncompressed (65 bytes) or compressed (33 bytes)
    private_key: bytes  # 32 bytes


class StorageProvider(Protocol):
    """Storage Provider for caching CAS blocks locally."""

    async def has(self, key: str) -> bool:
        """Check if a block exists in storage."""
        ...

    async def get(self, key: str) -> bytes | None:
        """Get a block from storage, returns None if not found."""
        ...

    async def put(self, key: str, value: bytes) -> None:
        """Store a block in storage."""
        ...


class HashProvider(Protocol):
    """Hash Provider for computing content hashes."""

    async def sha256(self, data: bytes) -> bytes:
        """Compute SHA-256 hash of data."""
        ...

    async def blake3(self, data: bytes) -> bytes | None:
        """Compute BLAKE3 hash of data (optional, returns None if not supported)."""
        ...


class KeyPairProvider(Protocol):
    """Key Pair Provider for managing P256 client credentials."""

    async def load(self) -> P256KeyPair | None:
        """Load existing key pair, returns None if not found."""
        ...

    async def save(self, key_pair: P256KeyPair) -> None:
        """Save key pair to persistent storage."""
        ...

    async def generate(self) -> P256KeyPair:
        """Generate a new P256 key pair."""
        ...

    async def sign(self, data: bytes, private_key: bytes) -> bytes:
        """Sign data with the private key, returns DER-encoded signature."""
        ...
