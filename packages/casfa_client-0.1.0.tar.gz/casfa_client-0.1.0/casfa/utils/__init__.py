"""CASFA utilities - errors and HTTP fetch."""

from casfa.utils.errors import (
    CasfaError,
    CasfaErrorCode,
    create_error,
    create_permission_error,
    is_casfa_error,
    status_to_error_code,
)
from casfa.utils.fetch import (
    FetchConfig,
    Fetcher,
    FetchResult,
    FetchResultErr,
    FetchResultOk,
    RequestOptions,
    create_fetch,
)

__all__ = [
    # Errors
    "CasfaError",
    "CasfaErrorCode",
    "create_error",
    "create_permission_error",
    "is_casfa_error",
    "status_to_error_code",
    # Fetch
    "FetchConfig",
    "FetchResult",
    "FetchResultErr",
    "FetchResultOk",
    "Fetcher",
    "RequestOptions",
    "create_fetch",
]
