"""Error types - mirrors TypeScript casfa-client-v2/utils/errors.ts."""

from dataclasses import dataclass
from typing import Any, Literal

CasfaErrorCode = Literal[
    "UNAUTHORIZED",
    "FORBIDDEN",
    "NOT_FOUND",
    "CONFLICT",
    "VALIDATION_ERROR",
    "NETWORK_ERROR",
    "PERMISSION_DENIED",
    "AUTH_REQUIRED",
    "TOKEN_EXPIRED",
    "TICKET_EXPIRED",
    "TICKET_REVOKED",
    "QUOTA_EXCEEDED",
    "UNKNOWN",
]


@dataclass
class CasfaError:
    """Structured error type for CASFA operations."""

    code: CasfaErrorCode
    message: str
    status: int | None = None
    details: Any | None = None


def create_error(
    code: CasfaErrorCode,
    message: str,
    status: int | None = None,
    details: Any | None = None,
) -> CasfaError:
    """Create a CasfaError object."""
    return CasfaError(code=code, message=message, status=status, details=details)


def is_casfa_error(error: Any) -> bool:
    """Check if an error is a CasfaError."""
    return isinstance(error, CasfaError)


def status_to_error_code(status: int) -> CasfaErrorCode:
    """Map HTTP status to error code."""
    mapping: dict[int, CasfaErrorCode] = {
        401: "UNAUTHORIZED",
        403: "FORBIDDEN",
        404: "NOT_FOUND",
        409: "CONFLICT",
        400: "VALIDATION_ERROR",
        422: "VALIDATION_ERROR",
    }
    return mapping.get(status, "UNKNOWN")


def create_permission_error(api_name: str, required_auth: list[str]) -> CasfaError:
    """Permission denied error for unauthorized API access."""
    return create_error(
        "PERMISSION_DENIED",
        f"API '{api_name}' requires one of: {', '.join(required_auth)}",
        403,
    )


async def create_error_from_response(response: Any, body: dict[str, Any] | None) -> CasfaError:
    """Create error from HTTP response."""
    status = response.status_code
    code = status_to_error_code(status)

    # Try to extract error message from response body
    message = "Request failed"
    if body:
        if "message" in body:
            message = body["message"]
        elif "error" in body:
            message = body["error"]

    return create_error(code, message, status, body)
