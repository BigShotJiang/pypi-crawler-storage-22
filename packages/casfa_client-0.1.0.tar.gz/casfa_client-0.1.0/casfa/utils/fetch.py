"""Fetch wrapper with authentication - mirrors casfa-client-v2/utils/fetch.ts."""

from dataclasses import dataclass
from typing import Any, Generic, Literal, TypeVar

import httpx

from casfa.types.auth import AuthStrategy
from casfa.utils.errors import CasfaError, create_error, status_to_error_code

T = TypeVar("T")


@dataclass
class FetchConfig:
    """Configuration for fetch wrapper."""

    base_url: str
    auth: AuthStrategy


@dataclass
class RequestOptions:
    """Request options extending standard fetch options."""

    method: Literal["GET", "POST", "PUT", "PATCH", "DELETE"] = "GET"
    headers: dict[str, str] | None = None
    body: Any | None = None
    skip_auth: bool = False
    response_type: Literal["json", "blob", "text", "none"] = "json"


@dataclass
class FetchResultOk(Generic[T]):
    """Successful fetch result."""

    ok: Literal[True]
    data: T
    status: int


@dataclass
class FetchResultErr:
    """Failed fetch result."""

    ok: Literal[False]
    error: CasfaError


FetchResult = FetchResultOk[T] | FetchResultErr


def _ok(data: T, status: int) -> FetchResultOk[T]:
    """Create a successful result."""
    return FetchResultOk(ok=True, data=data, status=status)


def _err(error: CasfaError) -> FetchResultErr:
    """Create a failed result."""
    return FetchResultErr(ok=False, error=error)


class Fetcher:
    """HTTP client with authentication support."""

    def __init__(self, config: FetchConfig) -> None:
        self._base_url = config.base_url.rstrip("/")
        self._auth = config.auth
        self._client = httpx.AsyncClient(timeout=30.0)

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def request(
        self,
        path: str,
        options: RequestOptions | None = None,
    ) -> FetchResult[Any]:
        """Make an authenticated request."""
        opts = options or RequestOptions()
        url = f"{self._base_url}{path}"

        headers: dict[str, str] = dict(opts.headers) if opts.headers else {}

        # Add auth headers if not skipped
        if not opts.skip_auth:
            auth_header = await self._auth.get_auth_header()
            if auth_header:
                headers["Authorization"] = auth_header

            custom_headers = await self._auth.get_custom_headers()
            if custom_headers:
                headers.update(custom_headers)

        # Add content-type for JSON body
        if opts.body is not None and "Content-Type" not in headers:
            headers["Content-Type"] = "application/json"

        try:
            response = await self._client.request(
                method=opts.method,
                url=url,
                headers=headers,
                json=opts.body if opts.body is not None else None,
            )

            # Handle 401 with auth retry
            if response.status_code == 401 and not opts.skip_auth:
                retried = await self._auth.handle_unauthorized()
                if retried:
                    return await self.request(path, options)

            if not response.is_success:
                body = None
                try:
                    body = response.json()
                except Exception:
                    pass

                code = status_to_error_code(response.status_code)
                message = "Request failed"
                if body and isinstance(body, dict):
                    message = body.get("message", body.get("error", message))

                return _err(
                    create_error(code, message, response.status_code, body)
                )

            # Parse response based on type
            data: Any
            match opts.response_type:
                case "json":
                    data = response.json()
                case "blob":
                    data = response.content
                case "text":
                    data = response.text
                case "none":
                    data = None

            return _ok(data, response.status_code)

        except httpx.RequestError as e:
            return _err(
                create_error(
                    "NETWORK_ERROR",
                    str(e),
                    details={"exception": type(e).__name__},
                )
            )

    async def upload_binary(
        self,
        path: str,
        data: bytes,
        content_type: str = "application/octet-stream",
        headers: dict[str, str] | None = None,
    ) -> FetchResult[Any]:
        """Make a binary upload request."""
        url = f"{self._base_url}{path}"

        request_headers: dict[str, str] = {
            "Content-Type": content_type,
            **(headers or {}),
        }

        # Add auth headers
        auth_header = await self._auth.get_auth_header()
        if auth_header:
            request_headers["Authorization"] = auth_header

        custom_headers = await self._auth.get_custom_headers()
        if custom_headers:
            request_headers.update(custom_headers)

        try:
            response = await self._client.put(
                url=url,
                headers=request_headers,
                content=data,
            )

            if not response.is_success:
                body = None
                try:
                    body = response.json()
                except Exception:
                    pass

                code = status_to_error_code(response.status_code)
                message = "Upload failed"
                if body and isinstance(body, dict):
                    message = body.get("message", body.get("error", message))

                return _err(create_error(code, message, response.status_code, body))

            response_data = response.json()
            return _ok(response_data, response.status_code)

        except httpx.RequestError as e:
            return _err(
                create_error(
                    "NETWORK_ERROR",
                    str(e),
                    details={"exception": type(e).__name__},
                )
            )

    async def download_binary(self, path: str) -> FetchResult[bytes]:
        """Download binary data."""
        url = f"{self._base_url}{path}"

        request_headers: dict[str, str] = {}

        # Add auth headers
        auth_header = await self._auth.get_auth_header()
        if auth_header:
            request_headers["Authorization"] = auth_header

        custom_headers = await self._auth.get_custom_headers()
        if custom_headers:
            request_headers.update(custom_headers)

        try:
            response = await self._client.get(
                url=url,
                headers=request_headers,
            )

            if not response.is_success:
                body = None
                try:
                    body = response.json()
                except Exception:
                    pass

                code = status_to_error_code(response.status_code)
                message = "Download failed"
                if body and isinstance(body, dict):
                    message = body.get("message", body.get("error", message))

                return _err(create_error(code, message, response.status_code, body))

            return _ok(response.content, response.status_code)

        except httpx.RequestError as e:
            return _err(
                create_error(
                    "NETWORK_ERROR",
                    str(e),
                    details={"exception": type(e).__name__},
                )
            )


def create_fetch(config: FetchConfig) -> Fetcher:
    """Create a configured fetch instance."""
    return Fetcher(config)
