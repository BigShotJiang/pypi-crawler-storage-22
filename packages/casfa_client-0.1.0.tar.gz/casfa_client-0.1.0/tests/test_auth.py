"""Tests for auth strategies."""

import pytest

from casfa.auth.permissions import (
    API_PERMISSIONS,
    can_access,
    check_permission,
    is_public_api,
)
from casfa.auth.ticket import create_ticket_auth
from casfa.auth.token import create_token_auth
from casfa.types.auth import TicketAuthConfig, TicketAuthState, TokenAuthConfig, TokenAuthState


class TestTokenAuth:
    """Tests for TokenAuth strategy."""

    def test_create_token_auth(self) -> None:
        """Test creating a token auth strategy."""
        config = TokenAuthConfig(type="token", token="casfa_test_token")
        auth = create_token_auth(config)

        state = auth.get_state()
        assert isinstance(state, TokenAuthState)
        assert state.type == "token"
        assert state.token == "casfa_test_token"

    @pytest.mark.asyncio
    async def test_get_auth_header(self) -> None:
        """Test getting auth header."""
        config = TokenAuthConfig(type="token", token="casfa_test_token")
        auth = create_token_auth(config)

        header = await auth.get_auth_header()
        assert header == "AgentToken casfa_test_token"

    @pytest.mark.asyncio
    async def test_get_custom_headers(self) -> None:
        """Test custom headers are None for token auth."""
        config = TokenAuthConfig(type="token", token="casfa_test_token")
        auth = create_token_auth(config)

        headers = await auth.get_custom_headers()
        assert headers is None

    @pytest.mark.asyncio
    async def test_handle_unauthorized(self) -> None:
        """Test that token auth cannot handle unauthorized."""
        config = TokenAuthConfig(type="token", token="casfa_test_token")
        auth = create_token_auth(config)

        result = await auth.handle_unauthorized()
        assert result is False


class TestTicketAuth:
    """Tests for TicketAuth strategy."""

    def test_create_ticket_auth(self) -> None:
        """Test creating a ticket auth strategy."""
        config = TicketAuthConfig(
            type="ticket",
            ticket_id="ticket:01ABC123",
            realm_id="user:XYZ789",
        )
        auth = create_ticket_auth(config)

        state = auth.get_state()
        assert isinstance(state, TicketAuthState)
        assert state.type == "ticket"
        assert state.ticket_id == "ticket:01ABC123"
        assert state.realm_id == "user:XYZ789"

    @pytest.mark.asyncio
    async def test_get_auth_header(self) -> None:
        """Test getting auth header."""
        config = TicketAuthConfig(type="ticket", ticket_id="ticket:01ABC123")
        auth = create_ticket_auth(config)

        header = await auth.get_auth_header()
        assert header == "Ticket ticket:01ABC123"

    def test_can_access_path(self) -> None:
        """Test path access checking with scope."""
        config = TicketAuthConfig(type="ticket", ticket_id="ticket:01ABC123")
        auth = create_ticket_auth(config)

        # No scope = full access
        assert auth.can_access_path("node:abc123") is True

        # Set scope
        auth.update_info(scope=["node:abc123", "node:def456"])
        assert auth.can_access_path("node:abc123") is True
        assert auth.can_access_path("node:xyz789") is False

    def test_can_write(self) -> None:
        """Test write permission checking."""
        config = TicketAuthConfig(type="ticket", ticket_id="ticket:01ABC123")
        auth = create_ticket_auth(config)

        # Default = no write
        assert auth.can_write() is False

        # Set writable
        auth.update_info(writable=True)
        assert auth.can_write() is True


class TestPermissions:
    """Tests for permission checking."""

    def test_public_apis(self) -> None:
        """Test that public APIs are correctly identified."""
        public_apis = ["oauth.getConfig", "oauth.login", "auth.initClient"]
        for api in public_apis:
            assert is_public_api(api) is True  # type: ignore

    def test_authenticated_apis(self) -> None:
        """Test that authenticated APIs require auth."""
        assert is_public_api("oauth.getMe") is False
        assert is_public_api("tickets.create") is False
        assert is_public_api("nodes.put") is False

    def test_can_access_with_token(self) -> None:
        """Test permission checking with token auth."""
        token_state = TokenAuthState(type="token", token="test")

        # Token can access MCP
        assert can_access(token_state, "mcp.call") is True

        # Token can access tickets
        assert can_access(token_state, "tickets.create") is True
        assert can_access(token_state, "tickets.list") is True

        # Token cannot access user-only APIs
        assert can_access(token_state, "oauth.getMe") is False
        assert can_access(token_state, "auth.createAgentToken") is False

    def test_can_access_with_ticket(self) -> None:
        """Test permission checking with ticket auth."""
        ticket_state = TicketAuthState(
            type="ticket",
            ticket_id="ticket:01ABC123",
            realm_id=None,
            scope=None,
            writable=None,
            expires_at=None,
        )

        # Ticket can access nodes
        assert can_access(ticket_state, "nodes.get") is True
        assert can_access(ticket_state, "nodes.put") is True

        # Ticket can commit
        assert can_access(ticket_state, "tickets.commit") is True

        # Ticket cannot create new tickets
        assert can_access(ticket_state, "tickets.create") is False

    def test_check_permission_result(self) -> None:
        """Test check_permission returns proper result."""
        token_state = TokenAuthState(type="token", token="test")

        # Allowed
        result = check_permission(token_state, "tickets.create")
        assert result.allowed is True
        assert result.error is None

        # Denied
        result = check_permission(token_state, "oauth.getMe")
        assert result.allowed is False
        assert result.error is not None
        assert result.error.code == "PERMISSION_DENIED"

    def test_api_permissions_complete(self) -> None:
        """Test that all API names have permission definitions."""
        # All defined API names should have entries
        for api_name in API_PERMISSIONS:
            assert api_name is not None
