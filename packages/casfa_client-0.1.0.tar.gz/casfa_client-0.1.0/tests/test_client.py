"""Tests for CasfaClient."""

import pytest

from casfa import (
    CasfaClient,
    CasfaClientConfig,
    TokenAuthConfig,
    TokenAuthState,
    create_casfa_client,
)


class TestCasfaClient:
    """Tests for CasfaClient."""

    def test_create_client_with_token_auth(self) -> None:
        """Test creating a client with token auth."""
        client = create_casfa_client(
            CasfaClientConfig(
                base_url="https://casfa.example.com",
                auth=TokenAuthConfig(type="token", token="casfa_test"),
                realm_id="user:ABC123",
            )
        )

        assert isinstance(client, CasfaClient)

        # Check auth state
        state = client.get_auth_state()
        assert isinstance(state, TokenAuthState)
        assert state.token == "casfa_test"

        # Check realm_id
        assert client.get_realm_id() == "user:ABC123"

    def test_api_namespaces_exist(self) -> None:
        """Test that all API namespaces are accessible."""
        client = create_casfa_client(
            CasfaClientConfig(
                base_url="https://casfa.example.com",
                auth=TokenAuthConfig(type="token", token="casfa_test"),
            )
        )

        # All namespaces should be accessible
        assert client.oauth is not None
        assert client.auth is not None
        assert client.admin is not None
        assert client.mcp is not None
        assert client.realm is not None
        assert client.tickets is not None
        assert client.depots is not None
        assert client.nodes is not None

    def test_set_realm_id(self) -> None:
        """Test setting realm_id after creation."""
        client = create_casfa_client(
            CasfaClientConfig(
                base_url="https://casfa.example.com",
                auth=TokenAuthConfig(type="token", token="casfa_test"),
            )
        )

        assert client.get_realm_id() is None

        client.set_realm_id("user:XYZ789")
        assert client.get_realm_id() == "user:XYZ789"

    @pytest.mark.asyncio
    async def test_close_client(self) -> None:
        """Test closing the client."""
        client = create_casfa_client(
            CasfaClientConfig(
                base_url="https://casfa.example.com",
                auth=TokenAuthConfig(type="token", token="casfa_test"),
            )
        )

        # Should not raise
        await client.close()


class TestCasfaClientConfig:
    """Tests for CasfaClientConfig."""

    def test_config_with_required_fields(self) -> None:
        """Test config with only required fields."""
        config = CasfaClientConfig(
            base_url="https://casfa.example.com",
            auth=TokenAuthConfig(type="token", token="test"),
        )

        assert config.base_url == "https://casfa.example.com"
        assert config.auth.type == "token"
        assert config.realm_id is None
        assert config.storage is None
        assert config.hash is None

    def test_config_with_all_fields(self) -> None:
        """Test config with all optional fields."""
        config = CasfaClientConfig(
            base_url="https://casfa.example.com",
            auth=TokenAuthConfig(type="token", token="test"),
            realm_id="user:ABC123",
        )

        assert config.realm_id == "user:ABC123"
