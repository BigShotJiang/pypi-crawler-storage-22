"""Tests for types and errors."""

import pytest

from casfa.types.api import (
    DepotDetail,
    DepotHistoryEntry,
    DepotInfo,
    PaginatedResponse,
    TicketInfo,
    WritableConfig,
)
from casfa.utils.errors import (
    CasfaError,
    create_error,
    create_permission_error,
    is_casfa_error,
    status_to_error_code,
)


class TestCasfaError:
    """Tests for CasfaError."""

    def test_create_error(self) -> None:
        """Test creating an error."""
        error = create_error(
            "NOT_FOUND",
            "Resource not found",
            404,
            {"resource": "ticket"},
        )

        assert error.code == "NOT_FOUND"
        assert error.message == "Resource not found"
        assert error.status == 404
        assert error.details == {"resource": "ticket"}

    def test_is_casfa_error(self) -> None:
        """Test checking if error is CasfaError."""
        error = create_error("UNKNOWN", "Test error")
        assert is_casfa_error(error) is True

        assert is_casfa_error("not an error") is False
        assert is_casfa_error(None) is False
        assert is_casfa_error(Exception("test")) is False

    def test_status_to_error_code(self) -> None:
        """Test mapping HTTP status to error code."""
        assert status_to_error_code(401) == "UNAUTHORIZED"
        assert status_to_error_code(403) == "FORBIDDEN"
        assert status_to_error_code(404) == "NOT_FOUND"
        assert status_to_error_code(409) == "CONFLICT"
        assert status_to_error_code(400) == "VALIDATION_ERROR"
        assert status_to_error_code(422) == "VALIDATION_ERROR"
        assert status_to_error_code(500) == "UNKNOWN"

    def test_create_permission_error(self) -> None:
        """Test creating permission error."""
        error = create_permission_error("tickets.create", ["user", "token"])

        assert error.code == "PERMISSION_DENIED"
        assert "tickets.create" in error.message
        assert "user" in error.message
        assert "token" in error.message
        assert error.status == 403


class TestApiTypes:
    """Tests for API types."""

    def test_ticket_info(self) -> None:
        """Test TicketInfo dataclass."""
        ticket = TicketInfo(
            ticket_id="ticket:01ABC123",
            realm_id="user:XYZ789",
            issuer_id="user:ISSUER",
            scope=["node:abc", "node:def"],
            output=None,
            is_revoked=False,
            created_at=1704067200000,
            expires_at=1704153600000,
            writable=WritableConfig(quota=1024, accept=["image/*"]),
            label="Process images",
        )

        assert ticket.ticket_id == "ticket:01ABC123"
        assert ticket.scope == ["node:abc", "node:def"]
        assert ticket.writable is not None
        assert ticket.writable.quota == 1024
        assert ticket.writable.accept == ["image/*"]

    def test_depot_info(self) -> None:
        """Test DepotInfo dataclass."""
        depot = DepotInfo(
            depot_id="depot:01ABC123",
            realm_id="user:XYZ789",
            title="My Depot",
            root="node:root123",
            version=5,
            created_at=1704067200000,
            updated_at=1704153600000,
            description="Test depot",
        )

        assert depot.depot_id == "depot:01ABC123"
        assert depot.version == 5

    def test_depot_detail_with_history(self) -> None:
        """Test DepotDetail with history."""
        detail = DepotDetail(
            depot_id="depot:01ABC123",
            realm_id="user:XYZ789",
            title="My Depot",
            root="node:root123",
            version=3,
            created_at=1704067200000,
            updated_at=1704153600000,
            history=[
                DepotHistoryEntry(
                    root="node:root1",
                    version=1,
                    committed_at=1704067200000,
                    message="Initial commit",
                ),
                DepotHistoryEntry(
                    root="node:root2",
                    version=2,
                    committed_at=1704110400000,
                    message="Add files",
                ),
                DepotHistoryEntry(
                    root="node:root123",
                    version=3,
                    committed_at=1704153600000,
                    message="Update",
                ),
            ],
        )

        assert len(detail.history) == 3
        assert detail.history[0].version == 1
        assert detail.history[2].root == "node:root123"

    def test_paginated_response(self) -> None:
        """Test PaginatedResponse generic type."""
        response: PaginatedResponse[str] = PaginatedResponse(
            items=["a", "b", "c"],
            next_cursor="cursor123",
            total=10,
        )

        assert len(response.items) == 3
        assert response.next_cursor == "cursor123"
        assert response.total == 10

    def test_writable_config_optional_fields(self) -> None:
        """Test WritableConfig with optional fields."""
        # All None
        config = WritableConfig()
        assert config.quota is None
        assert config.accept is None

        # With values
        config = WritableConfig(quota=1024 * 1024)
        assert config.quota == 1024 * 1024
        assert config.accept is None
