# -*- coding: utf-8 -*-

# Copyright 2014 Spanish National Research Council (CSIC)
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

"""Cloud extractors for cASO."""

from caso.extract.openstack import CinderExtractor
from caso.extract.openstack import NeutronExtractor
from caso.extract.openstack import NovaExtractor
from caso.extract.prometheus import EnergyConsumptionExtractor

__all__ = [
    "NovaExtractor",
    "CinderExtractor",
    "NeutronExtractor",
    "EnergyConsumptionExtractor",
]
