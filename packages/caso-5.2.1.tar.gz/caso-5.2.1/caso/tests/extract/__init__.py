"""Tests for extractors."""
