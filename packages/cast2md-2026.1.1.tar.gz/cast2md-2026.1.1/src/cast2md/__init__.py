"""cast2md - Podcast transcription service."""

from importlib.metadata import version

__version__ = version("cast2md")
