"""Entry point for running cast2md as a module."""

from cast2md.cli import cli

if __name__ == "__main__":
    cli()
