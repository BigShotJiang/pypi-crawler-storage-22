"""Configuration module."""

from cast2md.config.settings import Settings, get_settings

__all__ = ["Settings", "get_settings"]
