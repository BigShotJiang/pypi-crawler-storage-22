"""Download module."""

from cast2md.download.downloader import download_episode

__all__ = ["download_episode"]
