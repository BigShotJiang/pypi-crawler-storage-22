"""MCP (Model Context Protocol) server for cast2md.

Provides tools and resources for Claude to interact with podcast feeds,
episodes, and transcripts.
"""
