"""Notification module for cast2md."""
