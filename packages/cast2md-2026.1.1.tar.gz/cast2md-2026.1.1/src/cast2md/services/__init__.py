"""Service layer for complex business logic."""
