"""Web UI module."""
