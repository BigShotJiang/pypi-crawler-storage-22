"""Data files for Castrel Bridge Proxy"""
