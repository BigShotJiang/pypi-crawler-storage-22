"""Tests for Castrel Bridge Proxy"""
