"""Tests for memory extractors."""
