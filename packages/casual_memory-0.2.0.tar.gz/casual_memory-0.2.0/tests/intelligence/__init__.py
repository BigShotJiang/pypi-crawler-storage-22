"""Tests for intelligence components."""
