"""CATAPA Private Authentication Constants.

This module contains constants used for CATAPA Private API authentication.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    NONE
"""

DEFAULT_TIMEOUT = 30
