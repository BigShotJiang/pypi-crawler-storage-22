"""CATAPA Private Python Client - Main Wrapper Class.

This module provides an ergonomic wrapper around the CATAPA Private API
with automatic session-based authentication and session management.

Authors:
    Handrian Alandi (handrian.alandi@gdplabs.id)

References:
    NONE
"""

from catapa_private.auth.catapa_private_auth import CatapaPrivateConfig
from catapa_private.session_client import SessionClient


class CatapaPrivate(SessionClient):
    """Main CATAPA Private wrapper class providing access to CATAPA Private API with automatic authentication.

    This wrapper provides a clean interface to all CATAPA Private API endpoints
    with automatic session-based authentication and cookie management.

    Features:
    - Automatic session-based authentication with username/password
    - Session cookies (SESSION-{tenant} and XSRF-TOKEN) are managed automatically
    - Thread-safe session management
    - No need to re-authenticate after session expiration (auto-refresh)
    - Simple, intuitive API for making authenticated requests

    Attributes:
        config (CatapaPrivateConfig): Configuration for CATAPA Private API authentication.

    Example:
        # Initialize the client
        client = CatapaPrivate(
            tenant="your-tenant",
            username="your-username",
            password="your-password"
        )

        # Make authenticated requests
        response = client.get("/timemanagement/attendance-statuses", params={"query": "(code:CUTPOT)"})
        data = response.json()

        # POST request
        response = client.post(
            "/timemanagement/jobs/missing-attendance-process",
            json={
                "attendanceStatusInId": "status-id",
                "startDate": "2025-01-01",
                "endDate": "2025-01-31"
            }
        )
    """

    def __init__(
        self,
        tenant: str,
        username: str,
        password: str,
        base_url: str = "https://api.catapa.com",
        timeout: int = 30,
    ) -> None:
        """Initialize the CATAPA Private client.

        Args:
            tenant (str): CATAPA tenant identifier.
            username (str): Username for authentication.
            password (str): Password for authentication.
            base_url (str, optional): Base URL for the CATAPA API. Defaults to "https://api.catapa.com".
            timeout (int, optional): Timeout for HTTP requests in seconds. Defaults to 30.
        """
        config = CatapaPrivateConfig(
            base_url=base_url,
            tenant=tenant,
            username=username,
            password=password,
            timeout=timeout,
        )
        super().__init__(config)
        self.config = config
