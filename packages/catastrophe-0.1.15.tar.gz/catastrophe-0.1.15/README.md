# destruction
a true calamity, this library is made to mass import the most used python libraries there are some random commands I added for testing purposes ignore them.

useful command to update: pip install --upgrade --no-deps git+https://github.com/burning-calamity/destruction.git
