class _install:
    def __repr__(self):
        return "to install this library without installing dependencies type in cmd:\n\npip install --no-deps git+https://github.com/burning-calamity/destruction.git"
    
    def __str__(self):
        return "to install this library without installing dependencies type in cmd:\n\npip install --no-deps git+https://github.com/burning-calamity/destruction.git"



install = _install()
