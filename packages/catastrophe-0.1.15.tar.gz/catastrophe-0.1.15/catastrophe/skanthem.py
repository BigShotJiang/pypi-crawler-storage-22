class _anthem:
    def __repr__(self):
        return "Slovakia national anthem lyrics - Slovak\nNad Tatrou sa blýska\nHromy divo bijú\nZastavme ich, bratia\nVeď sa ony stratia\nSlováci ožijú\n\n\n\n\nTo Slovensko naše\nPosiaľ tvrdo spalo\nAle blesky hromu\nVzbudzujú ho k tomu\nAby sa prebralo"
    
    def __str__(self):
        return "Slovakia national anthem lyrics - Slovak\nNad Tatrou sa blýska\nHromy divo bijú\nZastavme ich, bratia\nVeď sa ony stratia\nSlováci ožijú\n\n\n\n\nTo Slovensko naše\nPosiaľ tvrdo spalo\nAle blesky hromu\nVzbudzujú ho k tomu\nAby sa prebralo"
skanthem = _anthem()
