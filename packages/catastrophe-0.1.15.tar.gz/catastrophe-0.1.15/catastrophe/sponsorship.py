class _sp:
    def __repr__(self):
        return "subscribe to: https://www.youtube.com/@theyoutuberyoutubegod"
    
    def __str__(self):
        return "subscribe to: https://www.youtube.com/@theyoutuberyoutubegod"

sponsorship = _sp()
