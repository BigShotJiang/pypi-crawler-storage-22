class _Uninstaller:
    def __repr__(self):
        return "to uninstall this library type in cmd:\n\npip uninstall destruction"

    def __str__(self):
        return "to uninstall this library type in cmd:\n\npip uninstall destruction"


uninstaller = _Uninstaller()
