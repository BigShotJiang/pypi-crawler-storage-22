class _Updater:
    def __repr__(self):
        return "to update this library type in cmd:\n\npip install --upgrade destruction"

    def __str__(self):
        return "to update this library type in cmd:\n\npip install --upgrade destruction"


updater = _Updater()
