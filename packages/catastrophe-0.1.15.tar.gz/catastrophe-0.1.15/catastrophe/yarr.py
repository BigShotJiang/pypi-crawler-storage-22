class _yarr:
    def __repr__(self):
        return "Ahoy mate!"
    
    def __str__(self):
        return "Ahoy mate!"
yarr = _yarr()
