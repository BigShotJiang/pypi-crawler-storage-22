"""请求异常"""

class RequestException(Exception):
    """请求时出现异常"""
