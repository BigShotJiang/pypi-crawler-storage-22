"""catime - AI-generated hourly cat images."""

__version__ = "0.3.0"
