import numpy as np

from causalem import stochastic_matching

# ----- helper dataset ------------------------------------------------------
rng = np.random.default_rng(0)
n_per = 40
treat = np.repeat([0, 1, 2], n_per)  # three arms
score = rng.normal(size=treat.size)  # dummy scalar score


def _cluster_ok(cid, t):
    """Verify each non-negative cluster id has exactly one of each arm."""
    for c in np.unique(cid[cid >= 0]):
        idx = np.where(cid == c)[0]
        if len(idx) != 3:
            return False
        if set(t[idx]) != {0, 1, 2}:
            return False
    return True


# ---------------------------------------------------------------------------


def test_multi_deterministic():
    cid = stochastic_matching(
        treatment=treat,
        score=score,
        ref_group=0,
        nsmp=0,
    )
    assert cid.shape == (treat.size, 1)
    assert _cluster_ok(cid.ravel(), treat)


def test_multi_stochastic_reproducible():
    cid1 = stochastic_matching(
        treatment=treat,
        score=score,
        ref_group=0,
        scale=0.1,
        nsmp=2,
        random_state=123,
    )
    cid2 = stochastic_matching(
        treatment=treat,
        score=score,
        ref_group=0,
        scale=0.1,
        nsmp=2,
        random_state=123,
    )
    assert np.array_equal(cid1, cid2)
    # shape & cluster integrity
    assert cid1.shape == (treat.size, 2)
    assert _cluster_ok(cid1[:, 0], treat)
    assert _cluster_ok(cid1[:, 1], treat)


def test_multi_2d_score():
    # create a fake (G−1)=2 logit matrix
    score_2d = rng.normal(size=(treat.size, 2))
    cid = stochastic_matching(
        treatment=treat,
        score=score_2d,
        ref_group=0,
        nsmp=0,
    )
    assert _cluster_ok(cid.ravel(), treat)


# ---------------------------------------------------------------------------
# Scalability test
# ---------------------------------------------------------------------------
def test_multi_scalability_5k():
    """Test multi-arm matching scales to larger datasets."""
    np.random.seed(42)
    n_per_arm = 1_667  # ~5k total
    t = np.repeat([0, 1, 2], n_per_arm)
    score_2d = np.random.randn(len(t), 2)  # 2-D for 3 arms

    cid = stochastic_matching(
        treatment=t,
        score=score_2d,
        ref_group=0,
        caliper=1.0,  # Generous caliper for test
        nsmp=1,
        random_state=42,
    )

    assert cid.shape[0] == len(t)
    # Verify some clusters were formed
    assert (cid >= 0).any()
    # Verify cluster integrity for formed clusters
    for c in np.unique(cid[cid >= 0]):
        idx = np.where(cid == c)[0]
        # Each cluster should have one from each arm
        assert set(t[idx]) == {0, 1, 2}
