"""
Tests for std_matching parameter (SD-based caliper and scale).

These tests verify that the std_matching parameter correctly implements
relative (standard deviation-based) specification of matching parameters.
"""

import numpy as np
from sklearn.linear_model import LinearRegression, LogisticRegression

from causalem import estimate_te, load_data_lalonde
from causalem.estimation.ensemble import estimate_te_multi

# -------------------------------------------------------------------
# Fast test configuration (no bootstrap, minimal iterations)
# -------------------------------------------------------------------
KW_FAST = dict(
    niter=2,
    n_splits_propensity=2,
    n_splits_outcome=2,
    matching_is_stochastic=False,
    random_state_master=42,
)


# -------------------------------------------------------------------
# Test 1: std_matching=True vs False produces different results
# -------------------------------------------------------------------
def test_std_matching_changes_results():
    """Verify std_matching=True and False produce different treatment effects."""
    X, t, y = load_data_lalonde(raw=False)

    # Use a caliper value that will be very restrictive in absolute terms
    # but reasonable in SD terms
    res_abs = estimate_te(
        X,
        t,
        y,
        outcome_type="continuous",
        model_outcome=LinearRegression(),
        matching_scale=1.0,
        matching_caliper=0.1,  # 0.1 absolute units - very restrictive
        std_matching=False,
        **KW_FAST,
    )

    res_rel = estimate_te(
        X,
        t,
        y,
        outcome_type="continuous",
        model_outcome=LinearRegression(),
        matching_scale=1.0,
        matching_caliper=0.1,  # 0.1 SD - more reasonable
        std_matching=True,
        **KW_FAST,
    )

    # std_matching changes the interpretation, so number of matches should differ
    n_matched_abs = np.sum(res_abs["matching"] != -1)
    n_matched_rel = np.sum(res_rel["matching"] != -1)
    assert n_matched_abs != n_matched_rel  # Should be different
    # Both should produce valid results
    assert np.isfinite(res_abs["te"])
    assert np.isfinite(res_rel["te"])


# -------------------------------------------------------------------
# Test 2: Default values work correctly
# -------------------------------------------------------------------
def test_std_matching_defaults():
    """Verify default std_matching=True with caliper=0.2, scale=0.2 works."""
    X, t, y = load_data_lalonde(raw=False)

    # Should work with defaults (std_matching=True, caliper=0.2, scale=0.2)
    res = estimate_te(
        X,
        t,
        y,
        outcome_type="continuous",
        niter=1,
        n_splits_propensity=2,
        n_splits_outcome=2,
        random_state_master=42,
    )

    assert "te" in res
    assert np.isfinite(res["te"])
    assert "matching" in res


# -------------------------------------------------------------------
# Test 3: std_matching works with matching_caliper=None
# -------------------------------------------------------------------
def test_std_matching_with_no_caliper():
    """Verify std_matching handles matching_caliper=None correctly."""
    X, t, y = load_data_lalonde(raw=False)

    res = estimate_te(
        X,
        t,
        y,
        outcome_type="continuous",
        model_outcome=LinearRegression(),
        matching_scale=0.3,
        matching_caliper=None,  # No caliper
        std_matching=True,
        **KW_FAST,
    )

    assert "te" in res
    assert np.isfinite(res["te"])


# -------------------------------------------------------------------
# Test 4: std_matching works across outcome types
# -------------------------------------------------------------------
def test_std_matching_continuous_outcome():
    """Test std_matching with continuous outcome."""
    X, t, y = load_data_lalonde(raw=False)

    res = estimate_te(
        X,
        t,
        y,
        outcome_type="continuous",
        model_outcome=LinearRegression(),
        std_matching=True,
        matching_scale=0.2,
        matching_caliper=0.2,
        **KW_FAST,
    )

    assert np.isfinite(res["te"])


def test_std_matching_binary_outcome():
    """Test std_matching with binary outcome."""
    X, t, y = load_data_lalonde(raw=False)
    y_bin = (y > np.median(y)).astype(int)

    res = estimate_te(
        X,
        t,
        y_bin,
        outcome_type="binary",
        model_outcome=LogisticRegression(max_iter=500),
        std_matching=True,
        matching_scale=0.2,
        matching_caliper=0.2,
        **KW_FAST,
    )

    assert np.isfinite(res["te"])


# -------------------------------------------------------------------
# Test 5: std_matching works with multi-arm treatment
# -------------------------------------------------------------------
def test_std_matching_multi_arm():
    """Test std_matching with multi-arm treatment."""
    np.random.seed(42)
    n = 150
    X = np.random.randn(n, 3)
    t = np.random.choice(["A", "B", "C"], size=n, p=[0.4, 0.3, 0.3])
    y = X[:, 0] + (t == "B") * 1.0 + (t == "C") * 1.5 + np.random.randn(n) * 0.5

    res = estimate_te_multi(
        X,
        t,
        y,
        outcome_type="continuous",
        model_outcome=LinearRegression(),
        ref_group="A",
        std_matching=True,
        matching_scale=0.2,
        matching_caliper=0.2,
        niter=2,
        n_splits_propensity=2,
        n_splits_outcome=2,
        random_state_master=42,
    )

    assert "per_treatment" in res
    assert "pairwise" in res
    assert res["per_treatment"].shape[0] == 3
    assert res["pairwise"].shape[0] == 3


# -------------------------------------------------------------------
# Test 6: Verify SD scaling is actually happening
# -------------------------------------------------------------------
def test_std_matching_scales_with_propensity_spread():
    """
    Verify that with std_matching=True, the effective caliper adapts to
    propensity score spread.
    """
    # Create two datasets with different propensity score spreads
    np.random.seed(99)
    n = 100

    # Dataset 1: High separation (easy to match, large SD)
    X1 = np.random.randn(n, 2)
    X1[:50, 0] += 3  # Strong separation
    t1 = np.concatenate([np.ones(50), np.zeros(50)])
    y1 = X1[:, 0] + np.random.randn(n) * 0.5

    # Dataset 2: Low separation (hard to match, small SD)
    X2 = np.random.randn(n, 2)
    X2[:50, 0] += 0.3  # Weak separation
    t2 = np.concatenate([np.ones(50), np.zeros(50)])
    y2 = X2[:, 0] + np.random.randn(n) * 0.5

    # With std_matching=True and same caliper value (0.2),
    # should adapt to different PS spreads
    res1 = estimate_te(
        X1,
        t1,
        y1,
        outcome_type="continuous",
        model_outcome=LinearRegression(),
        matching_caliper=0.2,
        std_matching=True,
        niter=1,
        n_splits_propensity=2,
        n_splits_outcome=2,
        random_state_master=1,
    )

    res2 = estimate_te(
        X2,
        t2,
        y2,
        outcome_type="continuous",
        model_outcome=LinearRegression(),
        matching_caliper=0.2,
        std_matching=True,
        niter=1,
        n_splits_propensity=2,
        n_splits_outcome=2,
        random_state_master=1,
    )

    # Both should succeed (adaptive caliper)
    assert np.isfinite(res1["te"])
    assert np.isfinite(res2["te"])

    # Number of matches should differ due to different PS spreads
    n_matched_1 = np.sum(res1["matching"] != -1)
    n_matched_2 = np.sum(res2["matching"] != -1)
    # With high separation, FEWER units match (PS far apart even with adaptive caliper)
    # With low separation, MORE units match (PS close together)
    assert n_matched_2 > n_matched_1


# -------------------------------------------------------------------
# Test 7: Edge case - very restrictive caliper
# -------------------------------------------------------------------
def test_std_matching_restrictive_caliper():
    """Test that very restrictive caliper (0.01 SD) still produces matches."""
    X, t, y = load_data_lalonde(raw=False)

    res = estimate_te(
        X,
        t,
        y,
        outcome_type="continuous",
        model_outcome=LinearRegression(),
        matching_caliper=0.01,  # Very restrictive
        std_matching=True,
        niter=1,
        n_splits_propensity=2,
        n_splits_outcome=2,
        matching_is_stochastic=False,
        random_state_master=42,
    )

    # Should still get some matches (even if few)
    n_matched = np.sum(res["matching"] != -1)
    assert n_matched > 0
    assert np.isfinite(res["te"])


# -------------------------------------------------------------------
# Test 8: Reproducibility with std_matching
# -------------------------------------------------------------------
def test_std_matching_reproducibility():
    """Verify results are reproducible with same random_state_master."""
    X, t, y = load_data_lalonde(raw=False)

    res1 = estimate_te(
        X,
        t,
        y,
        outcome_type="continuous",
        model_outcome=LinearRegression(),
        std_matching=True,
        matching_scale=0.2,
        matching_caliper=0.2,
        **KW_FAST,
    )

    res2 = estimate_te(
        X,
        t,
        y,
        outcome_type="continuous",
        model_outcome=LinearRegression(),
        std_matching=True,
        matching_scale=0.2,
        matching_caliper=0.2,
        **KW_FAST,
    )

    # Should produce identical results
    assert np.isclose(res1["te"], res2["te"])
    assert np.array_equal(res1["matching"], res2["matching"])


# -------------------------------------------------------------------
# Test 9: std_matching parameter is passed through correctly
# -------------------------------------------------------------------
def test_std_matching_parameter_passthrough():
    """Verify std_matching is correctly passed through the call stack."""
    X, t, y = load_data_lalonde(raw=False)

    # Test with explicit False - should use absolute units
    res = estimate_te(
        X,
        t,
        y,
        outcome_type="continuous",
        model_outcome=LinearRegression(),
        matching_scale=1.0,  # Large absolute value
        matching_caliper=10.0,  # Large absolute value
        std_matching=False,  # Use absolute
        niter=1,
        n_splits_propensity=2,
        n_splits_outcome=2,
        random_state_master=42,
    )

    # Should succeed with loose absolute caliper
    assert np.isfinite(res["te"])
    # Should match most units (Lalonde is imbalanced, so not 100%)
    n_matched = np.sum(res["matching"] != -1)
    assert n_matched > 0.8 * len(t)  # At least 80% matched
