# (C) 2023 A. Voß setup@codebasedlearning.dev, a.voss@fh-aachen.de

#import os
#import sys
#sys.path.append(os.path.dirname(os.path.realpath(__file__)))  # enables relative local imports

#import setup

# src/yourlib/__init__.py
# from .setup import about_package
from . import setup

__all__ = ["setup"] # about_package.__name__
