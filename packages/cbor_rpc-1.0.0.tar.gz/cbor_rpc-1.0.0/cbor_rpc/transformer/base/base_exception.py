class NeedsMoreDataException(Exception):
    pass
