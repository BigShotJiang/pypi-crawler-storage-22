"""Allow running as `python -m cc_dump`."""

from cc_dump.cli import main

main()
