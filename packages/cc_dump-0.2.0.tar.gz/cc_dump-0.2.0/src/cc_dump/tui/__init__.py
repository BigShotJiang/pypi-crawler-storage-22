"""TUI package for cc-dump — Textual-based terminal user interface."""
