"""Tests for cc-dump hot-reload functionality."""
