# cc-status 项目概述

**项目名称**: cc-status
**许可证**: Apache License 2.0
**语言**: Python 3.9+ (推荐 3.11)
**包管理器**: uv

---

## 🎯 项目目标

Claude Code 状态栏功能相关的仓库，提供可配置的状态栏显示功能。

---

## 📁 项目结构 (Src Layout)

```
cc-status/
├── src/cc_status/           # 源代码
│   ├── __init__.py              # 版本信息和包级导出
│   ├── __main__.py              # CLI 入口点
│   ├── core/                    # 核心业务逻辑
│   ├── config/                  # 配置管理
│   ├── cli/                     # 命令行接口
│   ├── engine/                  # 引擎核心
│   │   ├── scheduler.py         # 任务调度器 (91% 覆盖率)
│   │   └── statusline_engine.py # 状态栏引擎 (77% 覆盖率)
│   ├── modules/                 # 模块系统
│   │   ├── base.py              # 基础模块 (87% 覆盖率)
│   │   └── registry.py          # 模块注册表 (92% 覆盖率)
│   ├── theme/                   # 主题系统
│   │   ├── builtins.py          # 内置主题
│   │   └── loader.py            # 主题加载器 (98% 覆盖率)
│   └── render/                  # 渲染系统
├── tests/                       # 测试文件
│   ├── conftest.py              # pytest 配置和共享 fixtures
│   └── unit/                    # 单元测试
│       ├── test_base_module.py  # ✅ 新增 (13 测试)
│       ├── test_registry.py     # ✅ 新增 (25 测试)
│       ├── test_scheduler.py    # ✅ 新增 (37 测试)
│       ├── test_theme_loader.py # ✅ 新增 (27 测试)
│       └── test_statusline_engine.py # ✅ 新增 (55 测试)
├── docs/                        # 文档目录
├── scripts/                     # 工具脚本
└── pyproject.toml               # 项目配置
```

---

## 🔧 技术栈

### 开发工具
- **包管理**: uv (极速依赖管理)
- **测试框架**: pytest >= 7.4.0
- **覆盖率**: pytest-cov >= 4.1.0
- **代码格式化**: black (行长 100)
- **代码检查**: ruff
- **类型检查**: mypy
- **构建工具**: hatchling

### 核心依赖
- **异步支持**: asyncio
- **线程安全**: threading.Lock
- **配置解析**: YAML
- **类型提示**: typing (Python 3.9+)

---

## 📊 测试状态 (2026-01-29)

### 核心引擎模块测试

| 模块 | 覆盖率 | 测试数量 | 状态 |
|------|-------|---------|------|
| theme/loader.py | 98% | 27 | ✅ |
| modules/registry.py | 92% | 25 | ✅ |
| engine/scheduler.py | 91% | 37 | ✅ |
| modules/base.py | 87% | 13 | ✅ |
| engine/statusline_engine.py | 77% | 55 | ✅ |
| **平均** | **89%** | **157** | ✅ |

### 测试特性
- ✅ 单例模式自动重置 (autouse fixture)
- ✅ 线程安全测试 (uuid 唯一性)
- ✅ Mock 外部依赖 (MagicMock, @patch)
- ✅ 临时文件管理 (tmp_path)
- ✅ AAA 模式 (Arrange-Act-Assert)

---

## 🚀 快速开始

### 环境初始化

```bash
# 安装 uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# 创建虚拟环境
uv venv

# 激活虚拟环境
source .venv/bin/activate  # macOS/Linux

# 安装依赖
uv pip install -e ".[dev]"
```

### 开发命令

```bash
# 代码格式化
black src/ tests/

# 代码检查
ruff check src/ tests/

# 类型检查
mypy src/

# 运行测试
pytest

# 带覆盖率测试
pytest --cov=cc_status --cov-report=html
```

---

## 🏗️ 架构设计

### 模块依赖关系

```
StatuslineEngine (引擎核心)
    ├── Scheduler (任务调度)
    ├── ThemeLoader (主题加载)
    └── ModuleRegistry (模块注册)
            └── BaseModule (基础模块)
```

### 设计模式

- **单例模式**: ModuleRegistry 确保全局唯一实例
- **工厂模式**: ThemeLoader 动态加载主题
- **观察者模式**: 回调机制 (output_update, state_change, error)
- **策略模式**: DisplayMode 枚举 (terminal, standalone)

---

## 📝 开发规范

### Git 提交格式

```
<类型>: <简短描述>

类型:
- 新增: 新功能
- 修复: Bug 修复
- 文档: 文档更新
- 重构: 代码重构
- 测试: 测试相关
- 配置: 配置或工具更新
```

### 代码风格
- 类型注解: 所有函数必须添加
- 文档字符串: 中文，Google 风格
- 命名约定: snake_case (变量/函数), PascalCase (类)
- 行长限制: 100 字符

---

## 🔄 发布流程

1. 更新 CHANGELOG.md
2. 更新版本号 (pyproject.toml 和 __init__.py)
3. 运行完整测试: `pytest`
4. 创建 Git 标签: `git tag -a v0.x.x -m "版本描述"`
5. 构建分发包: `python -m build`
6. 发布到 PyPI: `twine upload dist/*`

---

## 📚 相关文档

- 单元测试实施: `.serena/memories/session_20260129_unit_tests_implementation.md`
- 项目配置: `pyproject.toml`
- 开发指南: `CLAUDE.md`

---

**最后更新**: 2026-02-01
**维护者**: Michael
**状态**: ✅ 核心功能完整，18个已实现模块，PlanModule 引用已清理

## 📅 最近更新 (2026-02-01)

### PlanModule 引用清理
- 从 3 处配置中移除 `"plan"` 模块引用
- `commands.py:488` - preset_modules["full"]
- `powerline.py:331` - render_preset_full()
- `powerline.py:379` - PowerlineLayout.PRESETS["full"]
- 验证无遗漏引用，功能正常

### 当前可用模块（24个）
- 基础信息: dir, git_branch, git_status, version
- 模型与上下文: model, context_pct, context_bar
- 成本统计: cost_session, cost_today, cost_week, burn_rate
- 时间与计费: session_time, reset_timer, block_usage
- 实时监控: mcp_status, agent_status, todo_progress, activity_indicator
- 其他: ...

### 技术要点
- 模块删除必须清理所有配置引用
- 上下文依赖模块在无数据时自动隐藏
- 使用 `grep -r` 验证无遗漏引用
