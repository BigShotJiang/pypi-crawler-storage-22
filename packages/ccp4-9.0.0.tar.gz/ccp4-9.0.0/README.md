# CCP4 Software Suite - Version 9

This package provides version 9 of the CCP4 Software Suite for macromolecular X-ray crystallography.

## Installation

```bash
pip install ccp4==9.0.0
```

## About CCP4

CCP4 (Collaborative Computational Project Number 4) is a suite of programs for macromolecular X-ray crystallography. It provides tools for structure determination, refinement, and analysis.

## License

This package is distributed under the LGPL-3.0 license.

## Links

- [CCP4 Homepage](https://www.ccp4.ac.uk)
- [Documentation](https://www.ccp4.ac.uk/documentation.php)
