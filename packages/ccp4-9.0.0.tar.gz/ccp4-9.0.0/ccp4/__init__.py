"""CCP4 Software Suite - Version 9

CCP4 (Collaborative Computational Project Number 4) is a suite of programs
for macromolecular X-ray crystallography.
"""

__version__ = "9.0.0"
__author__ = "CCP4"
__license__ = "LGPL"

# Package metadata
VERSION = __version__
