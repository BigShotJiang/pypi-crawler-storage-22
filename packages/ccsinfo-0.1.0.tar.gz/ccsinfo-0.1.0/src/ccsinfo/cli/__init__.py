"""CLI module for ccsinfo."""
