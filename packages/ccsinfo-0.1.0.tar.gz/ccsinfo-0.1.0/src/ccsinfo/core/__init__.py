"""Core module for ccsinfo."""
