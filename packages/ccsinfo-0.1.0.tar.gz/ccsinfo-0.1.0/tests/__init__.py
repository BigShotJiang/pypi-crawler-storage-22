# Tests for ccsinfo
