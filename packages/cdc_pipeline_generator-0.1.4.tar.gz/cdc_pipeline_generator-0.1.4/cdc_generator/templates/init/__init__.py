"""Initialization templates."""
