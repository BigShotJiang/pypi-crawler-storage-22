# cde-onboard

Interactive TUI tutorials for onboarding engineers onto ONA Environments.

## Install

```bash
pipx install cde-onboard
```

## Usage

```bash
# Launch the interactive TUI
cde-onboard

# List lessons with progress
cde-onboard --list

# Jump to a specific lesson
cde-onboard --lesson 3

# Reset progress
cde-onboard --reset
```
