"""Allow running as `python -m cde_onboard`."""

from cde_onboard.cli import app

app()
