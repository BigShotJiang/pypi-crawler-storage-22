"""Application constants and paths."""

from pathlib import Path

APP_NAME = "cde-onboard"
APP_VERSION = "0.1.3"

# Progress is stored in the user's home directory
PROGRESS_DIR = Path.home() / ".cde-onboard"
PROGRESS_FILE = PROGRESS_DIR / "progress.json"

# Scaffolded files are written to a practice directory in the CWD
PRACTICE_DIR_NAME = "cde-onboard-practice"

# Total number of lessons
TOTAL_LESSONS = 7

# Lesson slugs (used as directory names and IDs)
LESSON_SLUGS: dict[int, str] = {
    0: "getting-started",
    1: "devcontainer-basics",
    2: "first-environment",
    3: "tasks",
    4: "services",
    5: "dotfiles",
    6: "multi-repo",
}
