"""Content and templates for lesson scaffolding."""
