#!/usr/bin/env bash
# Dotfiles install script for ONA environments
# This script runs automatically when ONA provisions your environment.
# It MUST be non-interactive (no prompts or user input).

set -euo pipefail

DOTFILES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Installing dotfiles from $DOTFILES_DIR..."

# Symlink dotfiles to home directory
for file in .bashrc .gitconfig; do
    if [ -f "$DOTFILES_DIR/$file" ]; then
        ln -sf "$DOTFILES_DIR/$file" "$HOME/$file"
        echo "  Linked $file"
    fi
done

echo "Dotfiles installation complete!"
