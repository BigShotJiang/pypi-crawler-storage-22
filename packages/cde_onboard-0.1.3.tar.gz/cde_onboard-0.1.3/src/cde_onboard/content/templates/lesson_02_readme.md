# Lesson 2: Setting Up Your First ONA Environment

This reference summarizes the core steps covered in Lesson 2.

## Checklist

- Authenticate with GitLab via OAuth in the ONA dashboard (one-time setup)
- Create a new environment from a GitLab repository
- Open the environment in VS Code Browser
- Understand the workspace location: `/workspaces/<repo-name>/`
- Enable prebuilds for faster startup
- Use the environment lifecycle actions: start, stop, resume, delete

## Key Notes

- ONA uses GitLab OAuth — no Personal Access Tokens required after the initial login.
- VS Code Browser is the primary connection method.
- Prebuilds rebuild your environment image when the default branch changes.
