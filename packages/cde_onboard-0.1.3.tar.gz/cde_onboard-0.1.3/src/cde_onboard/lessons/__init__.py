"""Lesson registry for the onboarding TUI."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cde_onboard.lessons.base import BaseLesson

# Lazy imports to avoid circular dependencies
_LESSON_CLASSES: list[type[BaseLesson]] | None = None


def _load_lessons() -> list[type[BaseLesson]]:
    """Import and return all lesson classes."""
    from cde_onboard.lessons.lesson_00_getting_started import GettingStartedLesson
    from cde_onboard.lessons.lesson_01_devcontainer import DevcontainerLesson
    from cde_onboard.lessons.lesson_02_first_environment import FirstEnvironmentLesson
    from cde_onboard.lessons.lesson_03_tasks import TasksLesson
    from cde_onboard.lessons.lesson_04_services import ServicesLesson
    from cde_onboard.lessons.lesson_05_dotfiles import DotfilesLesson
    from cde_onboard.lessons.lesson_06_multi_repo import MultiRepoLesson

    return [
        GettingStartedLesson,
        DevcontainerLesson,
        FirstEnvironmentLesson,
        TasksLesson,
        ServicesLesson,
        DotfilesLesson,
        MultiRepoLesson,
    ]


def get_all_lessons() -> list[type[BaseLesson]]:
    """Get all lesson classes, loading them lazily on first call."""
    global _LESSON_CLASSES
    if _LESSON_CLASSES is None:
        _LESSON_CLASSES = _load_lessons()
    return _LESSON_CLASSES


def get_lesson(number: int) -> BaseLesson:
    """Get an instantiated lesson by its number (0-6)."""
    for cls in get_all_lessons():
        if cls.meta().number == number:
            return cls()
    raise ValueError(f"No lesson with number {number}")
