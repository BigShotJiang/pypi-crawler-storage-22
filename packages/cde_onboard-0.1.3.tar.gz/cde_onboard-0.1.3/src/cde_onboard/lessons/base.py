"""Abstract base class for all lessons."""

from __future__ import annotations

from abc import ABC, abstractmethod

from cde_onboard.models import LessonMeta, LessonStep, ScaffoldFile


class BaseLesson(ABC):
    """Base class that all lessons must extend."""

    @classmethod
    @abstractmethod
    def meta(cls) -> LessonMeta:
        """Return lesson metadata (id, number, title, description, overview)."""
        ...

    @abstractmethod
    def steps(self) -> list[LessonStep]:
        """Return the ordered list of teaching steps."""
        ...

    @abstractmethod
    def scaffold_files(self) -> list[ScaffoldFile]:
        """Return the list of files to scaffold for this lesson."""
        ...
