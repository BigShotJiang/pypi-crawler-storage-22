"""Pydantic models for lessons, steps, progress, and scaffolding."""

from __future__ import annotations

from datetime import UTC, datetime

from pydantic import BaseModel, Field


class CodeBlock(BaseModel):
    """A syntax-highlighted code block shown during a lesson step."""

    language: str = "yaml"
    source: str
    filename: str | None = None


class LessonStep(BaseModel):
    """A single teaching step within a lesson."""

    title: str
    explanation: str  # Markdown content
    code: CodeBlock | None = None
    why: str | None = None  # Callout/tip text
    deep_dive: str | None = None  # Collapsible extra detail


class LessonMeta(BaseModel):
    """Metadata describing a lesson for menus and progress tracking."""

    id: str  # e.g. "devcontainer-basics"
    number: int  # 0-6
    title: str
    description: str
    overview: str  # Short summary shown in menu


class ScaffoldFile(BaseModel):
    """A file to be scaffolded (created) during a lesson."""

    relative_path: str  # e.g. ".devcontainer/devcontainer.json"
    template_name: str  # Name of the template in content/templates/
    description: str  # What this file does


class ProgressData(BaseModel):
    """Persistent progress data stored in ~/.cde-onboard/progress.json."""

    completed_lessons: list[str] = Field(default_factory=list)
    started_at: datetime | None = None
    last_activity: datetime | None = None

    def mark_completed(self, lesson_id: str) -> None:
        """Mark a lesson as completed and update timestamps."""
        if lesson_id not in self.completed_lessons:
            self.completed_lessons.append(lesson_id)
        now = datetime.now(UTC)
        if self.started_at is None:
            self.started_at = now
        self.last_activity = now

    def is_completed(self, lesson_id: str) -> bool:
        """Check if a lesson has been completed."""
        return lesson_id in self.completed_lessons

    @property
    def total_completed(self) -> int:
        """Number of completed lessons."""
        return len(self.completed_lessons)
