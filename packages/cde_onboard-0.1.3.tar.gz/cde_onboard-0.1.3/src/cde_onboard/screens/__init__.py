"""Textual screens for the onboarding TUI."""
