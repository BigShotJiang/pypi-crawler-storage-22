"""Completion screen — celebration when all lessons are done."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Center, Vertical
from textual.screen import Screen
from textual.widgets import Button, Footer, Header, Static

from cde_onboard.progress import ProgressManager


class CompletionScreen(Screen[None]):
    """Celebration screen shown when all lessons are completed."""

    def __init__(self, progress: ProgressManager) -> None:
        super().__init__()
        self.progress = progress

    def compose(self) -> ComposeResult:
        yield Header()
        with Center():
            with Vertical(id="completion-container"):
                yield Static(
                    "[bold green]Congratulations![/bold green]",
                    id="completion-title",
                )
                yield Static(
                    "You've completed all ONA onboarding lessons!\n\n"
                    "You now know how to configure dev containers, set up ONA environments, "
                    "define tasks and services, manage dotfiles, "
                    "and work with multiple repositories.\n\n"
                    "[bold cyan]What's Next?[/bold cyan]\n\n"
                    "[bold]1. Apply to Your Real Projects[/bold]\n"
                    "   • Copy configs from [cyan]cde-onboard-practice/[/cyan] to your team repos\n"
                    "   • Customize for your project's tech stack\n"
                    "   • Commit and push to GitLab\n"
                    "   • Create ONA environment and test\n\n"
                    "[bold]2. Enable Prebuilds[/bold]\n"
                    "   • In ONA dashboard → Projects → Associate your repository\n"
                    "   • Prebuilds automatically rebuild on git push\n"
                    "   • New environments start in seconds instead of minutes\n\n"
                    "[bold]3. Explore Advanced Topics[/bold]\n"
                    "   • Custom Docker images (beyond Microsoft base images)\n"
                    "   • Environment variables and secrets management\n"
                    "   • Advanced service orchestration patterns\n"
                    "   • Team conventions and shared configurations\n\n"
                    "[bold]4. Quick Reference Commands[/bold]\n"
                    "   [dim]gitpod automations task start <name>[/dim]\n"
                    "   [dim]gitpod automations service status[/dim]\n"
                    "   [dim]gitpod user dotfiles set --repository <url>[/dim]\n"
                    "   [dim]gitpod environment devcontainer rebuild[/dim]\n\n"
                    "[bold]5. Need Help?[/bold]\n"
                    "   • ONA documentation: https://ona-docs.example.com\n"
                    "   • Dev Container spec: https://containers.dev\n"
                    "   • Team Slack/Discord for questions\n\n"
                    "[dim]Tip: Review lessons anytime by choosing from the menu.[/dim]",
                    id="completion-summary",
                )
                yield Button("Back to Menu", id="btn-menu", variant="primary")
                yield Button("Quit", id="btn-quit", variant="default")
        yield Footer()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-menu":
            from cde_onboard.screens.welcome import WelcomeScreen

            # Clear all screens and go back to welcome
            while len(self.app.screen_stack) > 1:
                self.app.pop_screen()
            self.app.push_screen(WelcomeScreen(self.progress))
        elif event.button.id == "btn-quit":
            self.app.exit()
