"""Custom Textual widgets for the onboarding TUI."""
