"""Code panel widget — syntax-highlighted code block using Rich Syntax."""

from __future__ import annotations

from rich.syntax import Syntax
from textual.app import ComposeResult
from textual.widgets import Label, Static


class CodePanel(Static):
    """Displays a syntax-highlighted code block with optional filename header."""

    DEFAULT_CSS = """
    CodePanel {
        margin: 1 0;
        padding: 1;
        border: round $accent;
        background: $surface;
    }
    """

    def __init__(
        self,
        source: str,
        language: str = "yaml",
        filename: str | None = None,
    ) -> None:
        super().__init__()
        self._source = source
        self._language = language
        self._filename = filename

    def compose(self) -> ComposeResult:
        if self._filename:
            yield Label(f"[bold dim]{self._filename}[/bold dim]", classes="code-filename")
        syntax = Syntax(
            self._source,
            lexer=self._language,
            theme="monokai",
            line_numbers=True,
            word_wrap=True,
        )
        yield Static(syntax, classes="code-block")
