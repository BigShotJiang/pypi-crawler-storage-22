"""Info panel widget — callout box for tips, warnings, and explanations."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.widgets import Label, Static


class InfoPanel(Static):
    """A callout box for tips, explanations, and important notes."""

    DEFAULT_CSS = """
    InfoPanel {
        margin: 1 0;
        padding: 1;
        border: tall $warning;
        background: $boost;
    }
    """

    def __init__(self, content: str, title: str = "Note") -> None:
        super().__init__()
        self._content = content
        self._title = title

    def compose(self) -> ComposeResult:
        yield Label(f"[bold yellow]{self._title}[/bold yellow]")
        yield Label(str(self._content))
