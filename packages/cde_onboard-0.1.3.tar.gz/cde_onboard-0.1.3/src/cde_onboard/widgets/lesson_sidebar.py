"""Lesson sidebar widget — shows lesson list with progress indicators."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.widgets import Label, Static

from cde_onboard.lessons import get_all_lessons
from cde_onboard.progress import ProgressManager


class LessonSidebar(Static):
    """Left sidebar showing all lessons with completion status and active highlight."""

    DEFAULT_CSS = ""

    def __init__(self, progress: ProgressManager, active_lesson: int = 0) -> None:
        super().__init__()
        self.progress = progress
        self.active_lesson = active_lesson

    def compose(self) -> ComposeResult:
        yield Label("[bold]Lessons[/bold]", id="sidebar-title")
        for cls in get_all_lessons():
            meta = cls.meta()
            completed = self.progress.is_completed(meta.id)
            active = meta.number == self.active_lesson

            if completed:
                icon = "[green]✓[/green]"
            elif active:
                icon = "[cyan]▸[/cyan]"
            else:
                icon = "[dim]○[/dim]"

            if active:
                text = f"{icon} [bold]{meta.number}. {meta.title}[/bold]"
            else:
                text = f"{icon} {meta.number}. {meta.title}"
            yield Label(text, classes="sidebar-lesson")
