"""Shared pytest fixtures for cde-onboard tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from cde_onboard.models import (
    CodeBlock,
    LessonMeta,
    LessonStep,
    ProgressData,
    ScaffoldFile,
)
from cde_onboard.progress import ProgressManager


@pytest.fixture()
def progress_path(tmp_path: Path) -> Path:
    """Return a temporary path for the progress JSON file."""
    return tmp_path / "progress.json"


@pytest.fixture()
def progress_manager(progress_path: Path) -> ProgressManager:
    """Return a ProgressManager backed by a temp file."""
    return ProgressManager(path=progress_path)


@pytest.fixture()
def sample_code_block() -> CodeBlock:
    """Return a sample CodeBlock for testing."""
    return CodeBlock(
        language="yaml",
        source="services:\n  postgres:\n    image: postgres:16",
        filename="docker-compose.yaml",
    )


@pytest.fixture()
def sample_lesson_step(sample_code_block: CodeBlock) -> LessonStep:
    """Return a sample LessonStep with all optional fields populated."""
    return LessonStep(
        title="Test Step",
        explanation="This is a **test** explanation with markdown.",
        code=sample_code_block,
        why="Because testing is important.",
        deep_dive="Extra detail about this step.",
    )


@pytest.fixture()
def sample_lesson_meta() -> LessonMeta:
    """Return a sample LessonMeta for testing."""
    return LessonMeta(
        id="test-lesson",
        number=1,
        title="Test Lesson",
        description="A test lesson for unit tests.",
        overview="Short overview of the test lesson.",
    )


@pytest.fixture()
def sample_scaffold_file() -> ScaffoldFile:
    """Return a sample ScaffoldFile for testing."""
    return ScaffoldFile(
        relative_path=".ona/automations.yaml",
        template_name="automations_task.yaml",
        description="Task automations for testing.",
    )


@pytest.fixture()
def sample_scaffold_files() -> list[ScaffoldFile]:
    """Return a list of scaffold files representing a multi-file lesson."""
    return [
        ScaffoldFile(
            relative_path=".ona/automations.yaml",
            template_name="automations_service.yaml",
            description="Service automations.",
        ),
        ScaffoldFile(
            relative_path="docker-compose.yaml",
            template_name="docker_compose_service.yaml",
            description="Docker Compose with network_mode: host.",
        ),
    ]


@pytest.fixture()
def practice_dir(tmp_path: Path) -> Path:
    """Return a temporary base directory for scaffolding practice files."""
    return tmp_path / "practice"


@pytest.fixture()
def populated_progress_data() -> ProgressData:
    """Return a ProgressData with some lessons already completed."""
    data = ProgressData()
    data.mark_completed("devcontainer-basics")
    data.mark_completed("first-environment")
    return data
