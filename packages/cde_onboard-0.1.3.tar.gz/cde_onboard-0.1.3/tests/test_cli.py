"""Tests for the CLI entry point."""

from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from cde_onboard.cli import app
from cde_onboard.constants import APP_NAME, APP_VERSION, TOTAL_LESSONS
from cde_onboard.progress import ProgressManager

runner = CliRunner()


class TestVersion:
    """Tests for --version flag."""

    def test_version_output(self) -> None:
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert f"{APP_NAME} v{APP_VERSION}" in result.output

    def test_version_short_flag(self) -> None:
        result = runner.invoke(app, ["-v"])
        assert result.exit_code == 0
        assert APP_VERSION in result.output


class TestList:
    """Tests for --list flag."""

    def test_list_shows_table(self) -> None:
        result = runner.invoke(app, ["--list"])
        assert result.exit_code == 0
        assert "ONA Onboarding Lessons" in result.output

    def test_list_shows_all_lessons(self) -> None:
        result = runner.invoke(app, ["--list"])
        assert "Getting Started" in result.output
        assert "Dev Container Basics" in result.output
        assert "Tasks" in result.output
        assert "Services" in result.output
        assert "Dotfiles" in result.output
        assert "Managing Multiple Repos" in result.output

    def test_list_shows_completion_count(self) -> None:
        result = runner.invoke(app, ["--list"])
        assert f"/{TOTAL_LESSONS}" in result.output
        assert "lessons completed" in result.output


class TestReset:
    """Tests for --reset flag."""

    def test_reset_no_progress(self) -> None:
        result = runner.invoke(app, ["--reset"])
        assert result.exit_code == 0
        assert "No progress to clear" in result.output

    def test_reset_with_progress(self, tmp_path: Path) -> None:
        # Create some progress first
        progress_file = tmp_path / "progress.json"
        pm = ProgressManager(path=progress_file)
        pm.mark_completed("devcontainer-basics")
        pm.mark_completed("tasks")
        assert progress_file.exists()

        # Reset uses the default path, so we just check the CLI runs
        result = runner.invoke(app, ["--reset"])
        assert result.exit_code == 0


class TestLessonValidation:
    """Tests for --lesson flag validation."""

    def test_invalid_lesson_too_high(self) -> None:
        result = runner.invoke(app, ["--lesson", "99"])
        assert result.exit_code == 1
        assert "Error" in result.output
        assert "0" in result.output
        assert str(TOTAL_LESSONS - 1) in result.output

    def test_invalid_lesson_negative(self) -> None:
        result = runner.invoke(app, ["--lesson", "-1"])
        assert result.exit_code == 1
        assert "Error" in result.output

    def test_invalid_lesson_not_a_number(self) -> None:
        result = runner.invoke(app, ["--lesson", "abc"])
        assert result.exit_code != 0


class TestHelp:
    """Tests for --help flag."""

    def test_help_output(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "Interactive TUI tutorials" in result.output
        assert "--lesson" in result.output
        assert "--list" in result.output
        assert "--reset" in result.output
        assert "--version" in result.output
