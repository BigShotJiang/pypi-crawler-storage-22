import click

import cde_sepa.convert_csv as _convert_csv
import cde_sepa.create_sepa as _create_sepa
import cde_sepa.match_iban as _match_iban


@click.group()
def cli() -> None:
    pass


cli.add_command(_convert_csv.main, "convert")
cli.add_command(_create_sepa.main, "create")
cli.add_command(_match_iban.main, "match")


if __name__ == "__main__":
    cli()
