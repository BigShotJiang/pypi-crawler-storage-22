"""Tests for adam_spec module"""
