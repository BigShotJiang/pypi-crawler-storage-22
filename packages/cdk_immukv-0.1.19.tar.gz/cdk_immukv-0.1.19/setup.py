import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "cdk-immukv",
    "version": "0.1.19",
    "description": "AWS CDK constructs for ImmuKV - Immutable key-value store using S3 versioning",
    "license": "MIT",
    "url": "https://github.com/Portfoligno/immukv.git",
    "long_description_content_type": "text/markdown",
    "author": "ImmuKV Contributors",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://github.com/Portfoligno/immukv.git"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "cdk_immukv",
        "cdk_immukv._jsii"
    ],
    "package_data": {
        "cdk_immukv._jsii": [
            "cdk-immukv@0.1.19.jsii.tgz"
        ],
        "cdk_immukv": [
            "py.typed"
        ]
    },
    "python_requires": "~=3.9",
    "install_requires": [
        "aws-cdk-lib>=2.0.0, <3.0.0",
        "constructs>=10.0.0, <11.0.0",
        "jsii>=1.119.0, <2.0.0",
        "publication>=0.0.3",
        "typeguard>=2.13.3,<4.3.0"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Typing :: Typed",
        "Development Status :: 4 - Beta",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
