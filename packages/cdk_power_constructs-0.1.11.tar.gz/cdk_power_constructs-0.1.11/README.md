# CDK Power Constructs

A multi-language AWS CDK construct library providing reusable infrastructure patterns.

## Installation

### TypeScript/JavaScript

```bash
npm install cdk-power-constructs
```

### Python

```bash
pip install cdk-power-constructs
```

### Java

```xml
<dependency>
    <groupId>io.github.yourusername</groupId>
    <artifactId>cdk-power-constructs</artifactId>
    <version>0.1.0</version>
</dependency>
```

### Go

```bash
go get github.com/yourusername/cdk-power-constructs-go
```

## Usage

### TypeScript

```python
import { CdkPowerConstructs } from 'cdk-power-constructs';
import { Duration, Stack } from 'aws-cdk-lib';

const construct = new CdkPowerConstructs(this, 'MyConstruct', {
  visibilityTimeout: Duration.seconds(300),
});
```

### Python

```python
from cdk_power_constructs import CdkPowerConstructs
from aws_cdk import Duration

construct = CdkPowerConstructs(self, "MyConstruct",
    visibility_timeout=Duration.seconds(300)
)
```

## Development

* `npm run build` - Compile TypeScript and generate .jsii assembly
* `npm run watch` - Watch for changes and compile
* `npm run test` - Run unit tests
* `npm run package` - Generate packages for all languages

## License

Apache-2.0
