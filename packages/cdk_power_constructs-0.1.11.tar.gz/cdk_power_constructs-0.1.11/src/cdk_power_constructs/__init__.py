r'''
# CDK Power Constructs

A multi-language AWS CDK construct library providing reusable infrastructure patterns.

## Installation

### TypeScript/JavaScript

```bash
npm install cdk-power-constructs
```

### Python

```bash
pip install cdk-power-constructs
```

### Java

```xml
<dependency>
    <groupId>io.github.yourusername</groupId>
    <artifactId>cdk-power-constructs</artifactId>
    <version>0.1.0</version>
</dependency>
```

### Go

```bash
go get github.com/yourusername/cdk-power-constructs-go
```

## Usage

### TypeScript

```python
import { CdkPowerConstructs } from 'cdk-power-constructs';
import { Duration, Stack } from 'aws-cdk-lib';

const construct = new CdkPowerConstructs(this, 'MyConstruct', {
  visibilityTimeout: Duration.seconds(300),
});
```

### Python

```python
from cdk_power_constructs import CdkPowerConstructs
from aws_cdk import Duration

construct = CdkPowerConstructs(self, "MyConstruct",
    visibility_timeout=Duration.seconds(300)
)
```

## Development

* `npm run build` - Compile TypeScript and generate .jsii assembly
* `npm run watch` - Watch for changes and compile
* `npm run test` - Run unit tests
* `npm run package` - Generate packages for all languages

## License

Apache-2.0
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_sns as _aws_cdk_aws_sns_ceddda9d
import aws_cdk.aws_sqs as _aws_cdk_aws_sqs_ceddda9d
import constructs as _constructs_77d1e7e8


class CdkPowerConstructs(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="cdk-power-constructs.CdkPowerConstructs",
):
    '''
    :stability: experimental
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        visibility_timeout: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param visibility_timeout: (experimental) The visibility timeout for the SQS queue. Default: Duration.seconds(300)

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__69868510bd2ed704a1bf9406d14408f96270a717c8f9b0d88f2ec626e52192d1)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = CdkPowerConstructsProps(visibility_timeout=visibility_timeout)

        jsii.create(self.__class__, self, [scope, id, props])

    @builtins.property
    @jsii.member(jsii_name="queue")
    def queue(self) -> "_aws_cdk_aws_sqs_ceddda9d.Queue":
        '''
        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_sqs_ceddda9d.Queue", jsii.get(self, "queue"))

    @builtins.property
    @jsii.member(jsii_name="topic")
    def topic(self) -> "_aws_cdk_aws_sns_ceddda9d.Topic":
        '''
        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_sns_ceddda9d.Topic", jsii.get(self, "topic"))


@jsii.data_type(
    jsii_type="cdk-power-constructs.CdkPowerConstructsProps",
    jsii_struct_bases=[],
    name_mapping={"visibility_timeout": "visibilityTimeout"},
)
class CdkPowerConstructsProps:
    def __init__(
        self,
        *,
        visibility_timeout: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''
        :param visibility_timeout: (experimental) The visibility timeout for the SQS queue. Default: Duration.seconds(300)

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__17c0274a6eedf7973851a51fe3102cf024ed1cc92a606b6722e1fde5c0c1b273)
            check_type(argname="argument visibility_timeout", value=visibility_timeout, expected_type=type_hints["visibility_timeout"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if visibility_timeout is not None:
            self._values["visibility_timeout"] = visibility_timeout

    @builtins.property
    def visibility_timeout(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The visibility timeout for the SQS queue.

        :default: Duration.seconds(300)

        :stability: experimental
        '''
        result = self._values.get("visibility_timeout")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkPowerConstructsProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CdkPowerConstructs",
    "CdkPowerConstructsProps",
]

publication.publish()

def _typecheckingstub__69868510bd2ed704a1bf9406d14408f96270a717c8f9b0d88f2ec626e52192d1(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    visibility_timeout: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__17c0274a6eedf7973851a51fe3102cf024ed1cc92a606b6722e1fde5c0c1b273(
    *,
    visibility_timeout: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass
