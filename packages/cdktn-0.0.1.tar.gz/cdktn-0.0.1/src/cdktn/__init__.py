"""CDKTN placeholder."""
