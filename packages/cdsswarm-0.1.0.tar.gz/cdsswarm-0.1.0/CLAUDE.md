# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

cdsswarm is a Python CLI tool and library for downloading from the [CDS API](https://cds.climate.copernicus.eu/) concurrently with multiple workers. It has two display modes: an interactive Textual TUI with an htop-style worker table, and a plain-text script mode for CI/headless use.

## Environment

The virtualenv lives in `./venv`. Always use it for every Python command:

```bash
source ./venv/bin/activate
# or prefix commands directly:
./venv/bin/python …
./venv/bin/pip …
./venv/bin/pytest …
```

## Commands

```bash
# Install
./venv/bin/pip install -e ".[dev]"

# Run tests
./venv/bin/pytest -v

# Run a single test file
./venv/bin/pytest tests/test_core.py -v

# Run a single test
./venv/bin/pytest tests/test_core.py::TestSwarmDownloader::test_successful_download -v

# CLI usage
./venv/bin/cdsswarm requests.json --workers 4
./venv/bin/cdsswarm requests.json --workers 4 --mode script
./venv/bin/python -m cdsswarm --help
```

## Architecture

The codebase follows an adapter pattern to decouple download logic from display:

```
__init__.py          Public API: download() wraps SwarmDownloader + PlainTextAdapter
cli.py               CLI entry point, request file loading (JSON/YAML), mode selection
core.py              SwarmDownloader (ThreadPoolExecutor), Task/Result dataclasses
adapters.py          OutputAdapter ABC → PlainTextAdapter (script) / TextualAdapter (TUI)
textual_app.py       CdsswarmApp (Textual App), WorkerData, Message classes, screens
textual_app.tcss     CSS styling for the Textual TUI
_cds_utils.py        CDS status parsing, request cancellation (old+new API), tqdm monkey-patching
```

**Key flow:** `SwarmDownloader.run()` spawns worker threads that each create their own `cdsapi.Client` instance (thread safety). CDS API callbacks route messages through the `OutputAdapter` interface. The `TextualAdapter` uses `app.call_from_thread()` to post Textual `Message` subclasses to the main event loop. The plain-text adapter prints summary lines.

**Two entry paths:**
- **CLI** (`cli.py:main`): Reads task list from JSON/YAML file, picks interactive or script mode, shows TUI or text output. Only the CLI has TUI support.
- **Library** (`__init__.py:download`): Takes a `list[Task]`, returns `list[Result]`. Always uses `PlainTextAdapter`.

**CDS API compatibility:** Supports both old `cdsapi` and new `ecmwf-datastores` (CADS) for status parsing and request cancellation. The tqdm monkey-patch in `_cds_utils.py` intercepts download progress from cdsapi internals and routes it through the adapter.

## TUI

The interactive TUI (`textual_app.py`) uses the [Textual](https://textual.textualize.io/) framework and renders a `DataTable` with one row per worker:

```
W   │Status      │Prog  │Filename            │Started  │Elapsed  │Size      │DL %   │Request ID
0   │ running    │72%   │era5_2024_01.grib   │22:31:24 │2h30m05s │15.2 GB   │48%    │af1e2306-28c3...
1   │ successful │100%  │era5_2024_02.nc     │22:31:25 │1h15m00s │8.1 GB    │100% ✓ │b2f4a891-...
```

**Layout:**
- `TabbedContent` with Workers and Files tabs
- `WorkerInfoPanel` / `FilesInfoPanel` (Static widget) above the table
- `DataTable` with `cursor_type="row"` for built-in selection and scrolling
- `ProgressFooter` (Static, docked bottom) showing overall progress bar and ETA

**Screens:**
- `LogScreen` — pushed screen with `RichLog` for scrollable worker logs (Enter key)
- `ParamsScreen` — pushed screen showing full request parameters (a key)
- `ChecksumScreen` — `ModalScreen` for checksum mismatch dialog (blocks worker thread via `threading.Event`)

**Key bindings:** `q` quit, `t`/`Tab` switch tab, `Enter` open logs, `a` open params, `Esc` dismiss screens

**Thread safety:** Worker threads call `TextualAdapter` methods → `app.call_from_thread(app.post_message, msg)` → app handles messages on the main event loop. No manual locking needed.

**Status styling:** Rich `Text` objects with colored styles (e.g. `Text("running", style="bold yellow")`) replace curses color pairs.

The demo script `examples/demo_textual.py` simulates the full CDS lifecycle (accepted → running → successful → downloading → done) without API calls, useful for visual testing.

## Testing

Tests mock `cdsapi.Client` to avoid real API calls. The mock's `retrieve()` creates local files to simulate downloads. Tests use `tempfile.TemporaryDirectory` for file I/O isolation.

TUI tests use Textual's `app.run_test()` Pilot API for async testing. Tests post `Message` objects directly and verify app state and `DataTable` cell contents. No curses mocking needed.
