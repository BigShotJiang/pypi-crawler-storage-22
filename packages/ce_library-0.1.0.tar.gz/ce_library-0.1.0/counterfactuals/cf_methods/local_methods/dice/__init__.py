from .dice import DICE
