
```bash
python -m pip install cecli-dev
```
