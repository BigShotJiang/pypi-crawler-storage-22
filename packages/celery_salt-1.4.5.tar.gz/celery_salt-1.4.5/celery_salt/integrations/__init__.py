"""Integration modules for CelerySalt."""
