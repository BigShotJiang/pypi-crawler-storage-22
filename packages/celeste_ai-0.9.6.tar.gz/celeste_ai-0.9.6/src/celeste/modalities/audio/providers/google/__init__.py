"""Google provider for audio modality."""

from .client import GoogleAudioClient

__all__ = ["GoogleAudioClient"]
