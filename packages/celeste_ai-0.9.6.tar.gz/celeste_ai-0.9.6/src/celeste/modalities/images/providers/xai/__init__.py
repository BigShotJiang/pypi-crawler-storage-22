"""xAI provider for images modality."""

from .client import XAIImagesClient
from .models import MODELS

__all__ = ["MODELS", "XAIImagesClient"]
