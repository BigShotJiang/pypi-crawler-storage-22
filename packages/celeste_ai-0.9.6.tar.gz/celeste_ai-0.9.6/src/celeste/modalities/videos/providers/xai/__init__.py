"""xAI provider for videos modality."""

from .client import XAIVideosClient
from .models import MODELS

__all__ = ["MODELS", "XAIVideosClient"]
