"""Google Embeddings API provider package."""
