"""Ollama configuration."""

DEFAULT_BASE_URL = "http://localhost:11434"
