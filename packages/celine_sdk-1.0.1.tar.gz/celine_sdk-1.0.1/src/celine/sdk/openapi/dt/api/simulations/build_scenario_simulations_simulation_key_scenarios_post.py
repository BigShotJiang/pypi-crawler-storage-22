from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.build_scenario_request import BuildScenarioRequest
from ...models.build_scenario_response import BuildScenarioResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    simulation_key: str,
    *,
    body: BuildScenarioRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/simulations/{simulation_key}/scenarios".format(
            simulation_key=quote(str(simulation_key), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BuildScenarioResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = BuildScenarioResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[BuildScenarioResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    simulation_key: str,
    *,
    client: AuthenticatedClient | Client,
    body: BuildScenarioRequest,
) -> Response[BuildScenarioResponse | HTTPValidationError]:
    """Build Scenario

    Args:
        simulation_key (str):
        body (BuildScenarioRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BuildScenarioResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        simulation_key=simulation_key,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    simulation_key: str,
    *,
    client: AuthenticatedClient | Client,
    body: BuildScenarioRequest,
) -> BuildScenarioResponse | HTTPValidationError | None:
    """Build Scenario

    Args:
        simulation_key (str):
        body (BuildScenarioRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BuildScenarioResponse | HTTPValidationError
    """

    return sync_detailed(
        simulation_key=simulation_key,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    simulation_key: str,
    *,
    client: AuthenticatedClient | Client,
    body: BuildScenarioRequest,
) -> Response[BuildScenarioResponse | HTTPValidationError]:
    """Build Scenario

    Args:
        simulation_key (str):
        body (BuildScenarioRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BuildScenarioResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        simulation_key=simulation_key,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    simulation_key: str,
    *,
    client: AuthenticatedClient | Client,
    body: BuildScenarioRequest,
) -> BuildScenarioResponse | HTTPValidationError | None:
    """Build Scenario

    Args:
        simulation_key (str):
        body (BuildScenarioRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BuildScenarioResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            simulation_key=simulation_key,
            client=client,
            body=body,
        )
    ).parsed
