from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.health_response_status import HealthResponseStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.details import Details


T = TypeVar("T", bound="HealthResponse")


@_attrs_define
class HealthResponse:
    """Health check response.

    Attributes:
        policies_loaded (bool):
        status (HealthResponseStatus):
        version (str):
        details (Details | Unset):
    """

    policies_loaded: bool
    status: HealthResponseStatus
    version: str
    details: Details | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        policies_loaded = self.policies_loaded

        status = self.status.value

        version = self.version

        details: dict[str, Any] | Unset = UNSET
        if not isinstance(self.details, Unset):
            details = self.details.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "policies_loaded": policies_loaded,
                "status": status,
                "version": version,
            }
        )
        if details is not UNSET:
            field_dict["details"] = details

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.details import Details

        d = dict(src_dict)
        policies_loaded = d.pop("policies_loaded")

        status = HealthResponseStatus(d.pop("status"))

        version = d.pop("version")

        _details = d.pop("details", UNSET)
        details: Details | Unset
        if isinstance(_details, Unset):
            details = UNSET
        else:
            details = Details.from_dict(_details)

        health_response = cls(
            policies_loaded=policies_loaded,
            status=status,
            version=version,
            details=details,
        )

        health_response.additional_properties = d
        return health_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
