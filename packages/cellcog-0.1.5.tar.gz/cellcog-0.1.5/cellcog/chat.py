"""
CellCog SDK Chat Operations.

Handles chat creation, messaging, status, and history retrieval.
"""

import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import requests

from .config import Config
from .exceptions import APIError, AuthenticationError, ChatNotFoundError, PaymentRequiredError
from .files import FileProcessor


class ChatManager:
    """
    Manages chat operations for CellCog SDK.

    Handles:
    - Creating new chats
    - Sending messages
    - Getting chat status
    - Retrieving and transforming chat history
    - Streaming unseen messages with per-session tracking
    """

    def __init__(self, config: Config, file_processor: FileProcessor):
        self.config = config
        self.files = file_processor
        self._chats_dir = Path("~/.cellcog/chats").expanduser()

    def create(self, prompt: str, project_id: Optional[str] = None, chat_mode: str = "agent team") -> dict:
        """
        Create a new CellCog chat.

        Local files in SHOW_FILE tags are automatically uploaded.
        GENERATE_FILE tags are passed through for CellCog agent.

        Args:
            prompt: Initial prompt (can include SHOW_FILE, GENERATE_FILE tags)
            project_id: Optional CellCog project ID
            chat_mode: "agent team" (deep reasoning, multi-agent) or "agent" (single agent, faster)

        Returns:
            {
                "chat_id": str,
                "status": "processing" | "ready",
                "uploaded_files": [{"local": str, "blob": str}]
            }

        Raises:
            PaymentRequiredError: If account needs credits
            AuthenticationError: If API key is invalid
            APIError: For other API errors
        """
        self.config.require_configured()

        # Map user-friendly mode names to API values
        mode_mapping = {
            "agent team": "agent_in_the_loop",  # Multi-agent team for deep reasoning
            "agent": "human_in_the_loop",  # Single agent for step-by-step
        }
        api_chat_mode = mode_mapping.get(chat_mode, chat_mode)

        # Transform outgoing message - upload local files
        transformed, uploaded = self.files.transform_outgoing(prompt)

        # Create chat
        data = {"message": transformed, "chat_mode": api_chat_mode}
        if project_id:
            data["project_id"] = project_id

        resp = self._request("POST", "/cellcog/chat/new", data)

        return {
            "chat_id": resp["id"],
            "status": "processing" if resp["operating"] else "ready",
            "uploaded_files": uploaded,
        }

    def send_message(self, chat_id: str, message: str) -> dict:
        """
        Send a follow-up message to an existing chat.

        Use this to:
        - Answer CellCog's clarifying questions
        - Add new requirements mid-task
        - Continue a conversation after CellCog stops operating

        After sending, call stream_unseen_messages_and_wait_for_completion() to see CellCog's response.

        Args:
            chat_id: The chat to send to
            message: Message content (can include SHOW_FILE, GENERATE_FILE tags)

        Returns:
            {"status": "sent", "uploaded_files": [...]}

        Raises:
            ChatNotFoundError: If chat doesn't exist
            PaymentRequiredError: If account needs credits
            AuthenticationError: If API key is invalid
        """
        self.config.require_configured()

        # Transform outgoing message - upload local files
        transformed, uploaded = self.files.transform_outgoing(message)

        self._request("POST", f"/cellcog/chat/{chat_id}/messages", {"message": transformed})

        return {"status": "sent", "uploaded_files": uploaded}

    def get_status(self, chat_id: str) -> dict:
        """
        Get current status of a chat.

        Args:
            chat_id: The chat to check

        Returns:
            {
                "status": "processing" | "ready" | "error",
                "name": str,
                "is_operating": bool,
                "error_type": str | None  # "security_threat" or "out_of_memory"
            }

        Raises:
            ChatNotFoundError: If chat doesn't exist
        """
        self.config.require_configured()

        resp = self._request("GET", f"/cellcog/chat/{chat_id}")

        error_type = None
        if resp.get("is_security_threat"):
            error_type = "security_threat"
        elif resp.get("is_out_of_memory"):
            error_type = "out_of_memory"

        status = "error" if error_type else ("processing" if resp["operating"] else "ready")

        return {
            "status": status,
            "name": resp["name"],
            "is_operating": resp["operating"],
            "error_type": error_type,
        }

    def get_history(self, chat_id: str) -> dict:
        """
        Get chat history with all files downloaded and paths resolved.

        All SHOW_FILE tags in returned messages contain local paths.
        Files from CellCog are automatically downloaded.

        Args:
            chat_id: The chat to retrieve

        Returns:
            {
                "chat_id": str,
                "messages": [
                    {"role": "openclaw"|"cellcog", "content": str, "created_at": str}
                ],
                "created_at": str
            }

        Raises:
            ChatNotFoundError: If chat doesn't exist
        """
        self.config.require_configured()

        resp = self._request("GET", f"/cellcog/chat/{chat_id}/history")

        # Transform incoming messages - download files, replace blob_names with local paths
        messages = self.files.transform_incoming_history(
            resp["messages"],
            resp.get("blob_name_to_url", {}),
            chat_id,
        )

        return {
            "chat_id": resp["chat_id"],
            "messages": messages,
            "created_at": resp["createdAt"],
        }

    def list_chats(self, limit: int = 20) -> list:
        """
        List recent chats.

        Args:
            limit: Maximum number of chats to return (1-100)

        Returns:
            [
                {
                    "chat_id": str,
                    "name": str,
                    "status": "processing" | "ready",
                    "created_at": str | None,
                    "updated_at": str | None
                }
            ]
        """
        self.config.require_configured()

        resp = self._request("GET", f"/cellcog/chats?page=1&page_size={min(limit, 100)}")

        return [
            {
                "chat_id": c["id"],
                "name": c["name"],
                "status": "processing" if c["operating"] else "ready",
                "created_at": c.get("created_at"),
                "updated_at": c.get("updated_at"),
            }
            for c in resp["chats"]
        ]

    def wait_for_completion(
        self,
        chat_id: str,
        timeout_seconds: int = 600,
        poll_interval: int = 10,
        timeout: int = None,  # Backwards compatibility alias
    ) -> dict:
        """
        Poll until chat completes or timeout. Returns full history at end.

        NOTE: For real-time message streaming with per-session tracking, use
        stream_unseen_messages_and_wait_for_completion() instead.

        Args:
            chat_id: The chat to wait for
            timeout_seconds: Max wait time (default 10 minutes)
            poll_interval: Seconds between status checks (default 10)

        Returns:
            {
                "status": "completed" | "timeout" | "error",
                "history": dict | None,  # Same as get_history() if completed
                "elapsed_seconds": float,
                "error_type": str | None  # If status is "error"
            }
        """
        # Handle backwards compatibility
        if timeout is not None:
            timeout_seconds = timeout

        start = time.time()

        while time.time() - start < timeout_seconds:
            status = self.get_status(chat_id)

            if status["error_type"]:
                return {
                    "status": "error",
                    "history": None,
                    "elapsed_seconds": time.time() - start,
                    "error_type": status["error_type"],
                }

            if not status["is_operating"]:
                return {
                    "status": "completed",
                    "history": self.get_history(chat_id),
                    "elapsed_seconds": time.time() - start,
                    "error_type": None,
                }

            time.sleep(poll_interval)

        return {
            "status": "timeout",
            "history": None,
            "elapsed_seconds": timeout_seconds,
            "error_type": None,
        }

    def stream_unseen_messages_and_wait_for_completion(
        self,
        chat_id: str,
        session_id: str,
        timeout_seconds: int = 600,
        poll_interval: int = 10,
    ) -> dict:
        """
        Stream unseen messages and wait for chat completion.

        Messages are printed in standard format as they arrive. Both CellCog
        and OpenClaw messages are shown, so you can see what other sessions sent.

        Message format:
            <MESSAGE FROM cellcog on Chat {id} at {timestamp}>
            {content with file paths resolved}
            <MESSAGE END>

            <MESSAGE FROM openclaw on Chat {id} at {timestamp}>
            {content with file paths resolved}
            <MESSAGE END>

        When CellCog stops operating, the last CellCog message includes:
            [CellCog stopped operating on Chat {id} - waiting for response via send_message()]

        The seen message index is persisted per session to:
            ~/.cellcog/chats/{chat_id}/.seen_indices/{session_id}

        This allows multiple sessions to independently track their progress on
        the same chat without duplicate messages.

        Args:
            chat_id: The CellCog chat to watch
            session_id: Your OpenClaw session ID (for tracking seen messages).
                       Sub-sessions: extract UUID from session key (last part)
                       Main session: use sessions_list to get sessionId
            timeout_seconds: Max wait time (default 10 min)
            poll_interval: Seconds between checks (default 10)

        Returns:
            {
                "status": "completed" | "timeout" | "error",
                "messages_delivered": int,
                "elapsed_seconds": float,
                "error_type": str | None
            }

        Example:
            result = client.create_chat("Research quantum computing")
            chat_id = result["chat_id"]

            # Messages print automatically as they arrive
            client.stream_unseen_messages_and_wait_for_completion(
                chat_id,
                session_id="8c980d81-cec5-48a3-926f-2b04053dfde1"
            )
        """
        start = time.time()
        delivered_count = 0

        # Load persisted seen index for this specific session
        last_delivered_index = self._load_seen_index(chat_id, session_id)

        while time.time() - start < timeout_seconds:
            # Check status
            status = self.get_status(chat_id)

            if status["error_type"]:
                return {
                    "status": "error",
                    "messages_delivered": delivered_count,
                    "elapsed_seconds": time.time() - start,
                    "error_type": status["error_type"],
                }

            is_operating = status["is_operating"]

            # Fetch history
            history = self._request("GET", f"/cellcog/chat/{chat_id}/history")
            messages = self.files.transform_incoming_history(
                history["messages"],
                history.get("blob_name_to_url", {}),
                chat_id,
            )

            # Find last CellCog message index (for waiting notice)
            last_cellcog_idx = -1
            for i, msg in enumerate(messages):
                if msg["role"] == "cellcog":
                    last_cellcog_idx = i

            # Print ALL new messages (both cellcog and openclaw)
            for i, msg in enumerate(messages):
                if i <= last_delivered_index:
                    continue

                role = msg["role"]  # "cellcog" or "openclaw"
                timestamp = self._format_timestamp(msg["created_at"])

                # Print the message block
                print(f"<MESSAGE FROM {role} on Chat {chat_id} at {timestamp}>")
                print(msg["content"])
                print("<MESSAGE END>")

                # Add waiting notice only for last CellCog message when chat stopped
                if not is_operating and role == "cellcog" and i == last_cellcog_idx:
                    print(
                        f"[CellCog stopped operating on Chat {chat_id} - waiting for response via send_message()]"
                    )

                print()  # Blank line between messages
                delivered_count += 1

                # Update and persist index after each message
                last_delivered_index = i
                self._save_seen_index(chat_id, session_id, last_delivered_index)

            # Check completion
            if not is_operating:
                return {
                    "status": "completed",
                    "messages_delivered": delivered_count,
                    "elapsed_seconds": time.time() - start,
                    "error_type": None,
                }

            time.sleep(poll_interval)

        return {
            "status": "timeout",
            "messages_delivered": delivered_count,
            "elapsed_seconds": timeout_seconds,
            "error_type": None,
        }

    def _get_seen_indices_dir(self, chat_id: str) -> Path:
        """Get the directory for session-specific seen indices."""
        return self._chats_dir / chat_id / ".seen_indices"

    def _get_seen_index_path(self, chat_id: str, session_id: str) -> Path:
        """Get the path to a specific session's seen index file."""
        return self._get_seen_indices_dir(chat_id) / session_id

    def _load_seen_index(self, chat_id: str, session_id: str) -> int:
        """
        Load the last seen message index for a specific session.

        Returns -1 if no index file exists (fresh start).
        """
        index_path = self._get_seen_index_path(chat_id, session_id)
        try:
            if index_path.exists():
                content = index_path.read_text().strip()
                return int(content)
        except (ValueError, IOError):
            pass  # If file is corrupted or unreadable, start fresh
        return -1

    def _save_seen_index(self, chat_id: str, session_id: str, index: int) -> None:
        """
        Save the last seen message index for a specific session.

        Creates the directory structure if it doesn't exist.
        """
        index_path = self._get_seen_index_path(chat_id, session_id)
        try:
            index_path.parent.mkdir(parents=True, exist_ok=True)
            index_path.write_text(str(index))
        except IOError:
            pass  # Best effort - don't fail if we can't persist

    def _format_timestamp(self, iso_timestamp: str) -> str:
        """Convert ISO timestamp to readable format."""
        if not iso_timestamp:
            return "unknown time"
        try:
            # Handle various ISO formats
            if iso_timestamp.endswith("Z"):
                iso_timestamp = iso_timestamp[:-1] + "+00:00"
            dt = datetime.fromisoformat(iso_timestamp)
            return dt.strftime("%Y-%m-%d %H:%M UTC")
        except Exception:
            return iso_timestamp

    def check_pending(self) -> list:
        """
        Check all user's chats and return recently completed ones.

        Useful for OpenClaw's heartbeat loop to find completed work.

        Returns:
            [
                {
                    "chat_id": str,
                    "name": str,
                    "last_message_preview": str,  # Truncated last message
                }
            ]
        """
        self.config.require_configured()

        chats = self.list_chats(limit=20)
        completed = []

        for chat in chats:
            if chat["status"] == "ready":
                # Get last message preview
                try:
                    history = self.get_history(chat["chat_id"])
                    if history["messages"]:
                        last_msg = history["messages"][-1]
                        preview = last_msg["content"][:200]
                        if len(last_msg["content"]) > 200:
                            preview += "..."

                        completed.append(
                            {
                                "chat_id": chat["chat_id"],
                                "name": chat["name"],
                                "last_message_preview": preview,
                            }
                        )
                except Exception:
                    # Skip if we can't get history
                    pass

        return completed

    def _request(self, method: str, path: str, data: Optional[dict] = None) -> dict:
        """
        Make API request with error handling.

        Args:
            method: HTTP method
            path: API path (e.g., "/cellcog/chat/new")
            data: Optional request body

        Returns:
            Response JSON

        Raises:
            PaymentRequiredError: If 402 response
            AuthenticationError: If 401 response
            ChatNotFoundError: If 404 response
            APIError: For other errors
        """
        try:
            resp = requests.request(
                method=method,
                url=f"{self.config.api_base_url}{path}",
                headers={"X-API-Key": self.config.api_key},
                json=data,
                timeout=60,
            )
        except requests.RequestException as e:
            raise APIError(0, f"Request failed: {e}")

        if resp.status_code == 402:
            raise PaymentRequiredError(
                subscription_url="https://cellcog.ai/billing",
                email=self.config.email or "unknown",
            )

        if resp.status_code == 401:
            raise AuthenticationError("Invalid or expired API key")

        if resp.status_code == 404:
            raise ChatNotFoundError(f"Chat not found: {path}")

        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise APIError(resp.status_code, detail)

        return resp.json()
