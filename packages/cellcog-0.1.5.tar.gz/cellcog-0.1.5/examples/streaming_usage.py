"""
CellCog SDK Streaming Usage Example

This example demonstrates the recommended pattern for OpenClaw agents:
- Use stream_unseen_messages_and_wait_for_completion() to see messages as they arrive
- Pass your session_id for per-session tracking
- Respond to clarifying questions with send_message()
- Handle multi-session coordination
"""

from cellcog import CellCogClient, PaymentRequiredError, ConfigurationError


def main():
    client = CellCogClient()

    # Check if configured
    status = client.get_account_status()
    if not status["configured"]:
        print("CellCog not configured. Set CELLCOG_API_KEY or run setup_account()")
        return

    # Example 1: Simple streaming with session ID
    print("Example 1: Simple query with streaming")
    print("-" * 50)

    # Your session ID - see "Getting Your Session ID" in SKILL.md
    # Sub-sessions: extract UUID from end of session key
    # Main sessions: use sessions_list to get sessionId
    my_session_id = "example-session-id-12345"

    try:
        result = client.create_chat(
            "What are the key advances in quantum computing in 2026?",
            chat_mode="agent",
        )
        chat_id = result["chat_id"]
        print(f"Created chat: {chat_id}\n")

        # Messages print automatically as they arrive
        # Pass session_id for per-session tracking
        final = client.stream_unseen_messages_and_wait_for_completion(
            chat_id,
            session_id=my_session_id,
            timeout_seconds=300,
            poll_interval=10,
        )

        print(f"\nCompleted with status: {final['status']}")
        print(f"Messages delivered: {final['messages_delivered']}")

    except PaymentRequiredError as e:
        print(f"Payment required: {e.subscription_url}")
    except ConfigurationError as e:
        print(f"Configuration error: {e}")

    # Example 2: Handling clarifying questions
    print("\n" + "=" * 50)
    print("Example 2: Handling clarifying questions")
    print("-" * 50)

    """
    When CellCog asks a clarifying question, you'll see:
    
        <MESSAGE FROM cellcog on Chat abc123 at 2026-02-02 11:30 UTC>
        I'd like to create a comprehensive analysis for you. 
        Could you clarify: Do you want me to focus on hardware advances 
        or software/algorithm advances?
        <MESSAGE END>
        [CellCog stopped operating on Chat abc123 - waiting for response via send_message()]
    
    Then respond:
    
        client.send_message(chat_id, "Focus on hardware advances, particularly superconducting qubits")
        client.stream_unseen_messages_and_wait_for_completion(chat_id, my_session_id)
    
    CellCog will continue working and you'll see the next messages.
    """
    print("(See code comments for clarifying question handling pattern)")

    # Example 3: Multi-session coordination
    print("\n" + "=" * 50)
    print("Example 3: Multi-session coordination")
    print("-" * 50)

    """
    Multiple sessions can work on the same chat. Each session tracks its own
    seen messages independently.
    
    # Main session creates chat
    result = client.create_chat("Create a market analysis report")
    chat_id = result["chat_id"]
    main_session_id = "main-session-uuid"
    
    # Main session spawns sub-session, passes chat_id
    # Sub-session has its own session_id (from session key)
    sub_session_id = "sub-session-uuid"
    
    # Sub-session handles the work
    client.stream_unseen_messages_and_wait_for_completion(chat_id, sub_session_id)
    # Sub-session sees: initial prompt, CellCog's response
    
    # Sub-session answers clarifying question
    client.send_message(chat_id, "Focus on electric vehicles in Asia")
    client.stream_unseen_messages_and_wait_for_completion(chat_id, sub_session_id)
    # Sub-session sees: CellCog's final response
    
    # Later, main session checks in
    client.stream_unseen_messages_and_wait_for_completion(chat_id, main_session_id)
    # Main session sees ALL messages (it hasn't seen any yet):
    #   - Initial prompt (openclaw)
    #   - CellCog's clarifying question
    #   - Sub-session's answer (openclaw) 
    #   - CellCog's final response
    
    # Each session has independent tracking in:
    #   ~/.cellcog/chats/{chat_id}/.seen_indices/{session_id}
    """
    print("(See code comments for multi-session coordination pattern)")

    # Example 4: Getting your session ID
    print("\n" + "=" * 50)
    print("Example 4: Getting your session ID")
    print("-" * 50)

    """
    In OpenClaw, sessions have two identifiers:
    - Session Key: "agent:main:main" or "agent:main:subagent:8c980d81-..."
    - Session ID: "8c980d81-cec5-48a3-926f-2b04053dfde1" (UUID)
    
    For sub-sessions (spawned):
        Your session key contains the UUID at the end.
        Example: "agent:main:subagent:8c980d81-cec5-48a3-926f-2b04053dfde1"
        Session ID: "8c980d81-cec5-48a3-926f-2b04053dfde1"
    
    For main sessions:
        Use sessions_list tool to get your sessionId field.
    
    The session_id parameter ensures:
    - Your seen messages are tracked separately from other sessions
    - Process restarts don't cause duplicate messages
    - Multiple agents can coordinate on the same chat
    """
    print("(See code comments for session ID extraction)")


if __name__ == "__main__":
    main()
