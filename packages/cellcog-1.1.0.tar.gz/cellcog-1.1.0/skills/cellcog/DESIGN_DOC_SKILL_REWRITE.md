# CellCog Main Skill + SDK Updates — Design Document

**Author:** CodingAgent
**Date:** 2026-02-10
**Status:** Pending Approval

---

## Table of Contents

1. [SKILL.md Rewrite](#1-skillmd-rewrite)
2. [SDK: `delete_chat()` Method](#2-sdk-delete_chat-method)
3. [SDK: Event Tracking / Observability](#3-sdk-event-tracking--observability)
4. [SDK: Agent Feedback After Completion](#4-sdk-agent-feedback-after-completion)
5. [Implementation Plan](#5-implementation-plan)
6. [Open Questions](#6-open-questions)

---

## 1. SKILL.md Rewrite

### 1.1 Problem

OpenClaw's security scanner flagged several warnings on the CellCog main skill:

| Warning | Severity | Root Cause |
|---------|----------|------------|
| Credentials not declared in metadata | ! | `env` field was missing from frontmatter |
| Install mechanism not declared | ! | No `install` spec despite requiring `pip install cellcog` |
| Package cannot be vetted | ! | No repo URL, homepage, or verified source in metadata |
| Local files transmitted externally | info | `<SHOW_FILE>` uploads local files but this wasn't documented |
| Metadata doesn't match documented capability | info | Manifest gaps vs. SKILL.md content |

**Already fixed in frontmatter** (committed): Added `version`, `author`, `env: [CELLCOG_API_KEY]`, `install: { pip: cellcog }`, `os`, `bins`. Added "Security & Data Handling" section.

**Still needed:** A full content rewrite that builds trust holistically.

### 1.2 Key Decisions

#### Drop "Mothership" Language

**Decision: Remove it.**

"Mothership" adds jargon without value. No agent thinks "I need a mothership skill." They think "I need the CellCog SDK." The term appears exactly once (last line of SKILL.md). No satellite skill references it either.

| Current | Proposed |
|---------|----------|
| "This mothership skill shows you HOW to call CellCog" | "This skill shows you HOW to use CellCog" |
| "Satellite skills show you WHAT's possible" | "Capability skills show you WHAT's possible" |

#### Rename "Security & Data Handling" to "Your Data, Your Control"

The current section was bolted on at the bottom as a compliance checklist. The new version positions data control as a *feature* and trust differentiator.

Key additions:
- CellCog is a full platform (like ChatGPT/Manus) with web UI access
- `delete_chat()` for programmatic data deletion
- Complete data purge in ~15 seconds
- Open-source SDK, verifiable package
- #1 on DeepResearch Bench builds trust

#### Add `delete_chat()` to API Reference

The backend already supports it. This is the cornerstone of the data security story.

#### Move "Most Common Mistake" to "Tips for Better Results"

Same content, better framing.

#### Fold Tickets into API Reference

`create_ticket()` is just another SDK method — doesn't need its own section.

### 1.3 Proposed Information Architecture

```
FRONTMATTER (env, install, bins, version, author, os)

# CellCog - Any-to-Any for Agents
  Brief intro + #1 DeepResearch link + "full platform" positioning

## The Power of Any-to-Any
  Work With Multiple Files, Any Format
  Request Multiple Outputs, Different Modalities
  Why This Matters (comparison table)

## Quick Start
  Setup (pip install)
  Authentication (API key)

## Creating Tasks
  Basic Usage (fire-and-forget)
  Continuing a Conversation

## What You Receive
  Progress Updates
  Completion Notification

## API Reference
  create_chat()
  send_message()
  delete_chat()               <-- NEW
  get_history()
  get_status()
  create_ticket()             <-- Moved from standalone section
  restart_chat_tracking()

## Chat Modes
  Clarifying Questions

## Session Keys

## Tips for Better Results       <-- Renamed from "Most Common Mistake"

## CellCog Chats Are Conversations

## Your Data, Your Control       <-- Replaces "Security & Data Handling"
  Full Platform Access
  Data Deletion
  What Data Flows Where
  Credentials and API Keys
  Package Verification
  Background Process
  Local Storage

## Error Handling

## Error Recovery

## Quick Reference (table with delete_chat added)

## Explore CellCog Capabilities  <-- Renamed from "What CellCog Can Do"
  Skill catalog table (no mothership/satellite language)
```

### 1.4 What We Preserve

Every piece of information in the current SKILL.md is preserved:
- All code examples (create_chat, send_message, get_history, etc.)
- All explanation text (fire-and-forget, daemon, progress updates, etc.)
- Chat modes table and session keys table
- Clarifying questions guidance
- Error handling and recovery code
- Quick reference table
- Full skill catalog with philosophies
- All URLs (DeepResearch leaderboard, API keys page, PyPI, GitHub)

---

## 2. SDK: `delete_chat()` Method

### 2.1 Problem

Users need programmatic control to delete their data from CellCog servers. The backend already supports chat deletion via `DELETE /cellcog/chat/{chat_id}?confirm=true` with a thorough 15-step cleanup:

```
stop_container -> cleanup_redis -> delete_letterbox -> delete_chat_messages ->
delete_chat_usage -> delete_posts -> delete_gcs_chat_files -> delete_gcs_thumbnails ->
delete_nfs_repo -> delete_github_repo -> cleanup_linked_chats -> cleanup_llm_cache ->
delete_file_records -> delete_thumbnail_record -> delete_post_office
```

This purges everything within ~15 seconds.

### 2.2 Design

**New method in `client.py`:**

```python
def delete_chat(self, chat_id: str) -> dict:
    """
    Permanently delete a chat and all associated data from CellCog servers.

    This is irreversible. All server-side data is purged:
    messages, generated files, containers, metadata — everything.
    Deletion completes within ~15 seconds.

    Local files (downloads in ~/.cellcog/chats/{chat_id}/downloads/)
    are NOT deleted — they belong to you.

    Args:
        chat_id: Chat to delete (must not be currently operating)

    Returns:
        {"success": True, "message": str, "chat_id": str}

    Raises:
        409: Chat is currently operating or already being deleted
        404: Chat not found
    """
    self.config.require_configured()

    result = self._chat._request(
        "DELETE",
        f"/cellcog/chat/{chat_id}?confirm=true"
    )

    # Clean up local tracking state only (NOT user's downloaded files)
    self._cleanup_tracking_state(chat_id)

    return result
```

**New helper:**

```python
def _cleanup_tracking_state(self, chat_id: str):
    """Remove local tracking files for a deleted chat.
    Downloaded files are preserved — they belong to the user."""
    # Remove tracking file (daemon will stop monitoring)
    tracking_file = self._state.get_tracked_file_path(chat_id)
    if tracking_file.exists():
        tracking_file.unlink(missing_ok=True)

    # Remove seen indices (no longer relevant)
    seen_dir = Path(f"~/.cellcog/chats/{chat_id}/.seen_indices").expanduser()
    if seen_dir.exists():
        import shutil
        shutil.rmtree(seen_dir, ignore_errors=True)
```

### 2.3 Key Design Decision

**Do NOT delete local downloads.** The user ran `delete_chat()` to remove data from CellCog's servers. Their local files (downloaded reports, images, etc. in `~/.cellcog/chats/{chat_id}/downloads/`) belong to them. Deleting those would be an unwelcome side effect.

We only clean up:
- Tracking files (`~/.cellcog/tracked_chats/{chat_id}.json`) — so daemon stops monitoring
- Seen indices (`~/.cellcog/chats/{chat_id}/.seen_indices/`) — no longer relevant

### 2.4 SKILL.md Documentation

Add to API Reference section:

```markdown
### delete_chat()

Permanently delete a chat and all associated data from CellCog's servers:

    result = client.delete_chat(chat_id="abc123")
    print(result["message"])  # "Chat deletion initiated..."

This purges everything server-side within ~15 seconds: messages, generated files,
containers, and metadata. Your local downloads are preserved.

Note: Cannot delete a chat that's currently operating.
Wait for completion first.
```

Add to Quick Reference table:

```
| delete_chat(chat_id)     | Delete chat + all server data | Sync call |
```

---

## 3. SDK: Event Tracking / Observability

### 3.1 Problem

We have zero visibility into whether messages from CellCog are actually reaching OpenClaw agents. We don't know:
- How many chats are created via SDK vs. not delivered
- What percentage of completion notifications succeed vs. fail
- How long delivery takes
- Whether interim updates are helping or being ignored
- Whether the feedback/ticket system is being used at all

The daemon logs locally to `~/.cellcog/daemon.log`, but we have no server-side observability.

### 3.2 Design: Lightweight SDK Event Tracking

**Approach:** POST lightweight events to CellCog backend. Simple, no third-party dependencies, we own the data.

#### Backend: New Endpoint

```
POST /cellcog/sdk/events
```

**Request body:**
```json
{
    "events": [
        {
            "event_type": "chat_created",
            "chat_id": "abc123",
            "timestamp": "2026-02-10T14:30:00Z",
            "sdk_version": "1.0.0",
            "metadata": {
                "chat_mode": "agent team",
                "has_files": true
            }
        }
    ]
}
```

**Response:** `{"accepted": 3}` (just acknowledge receipt, fire-and-forget from SDK side)

#### Event Types

| Event Type | When Fired | Key Metadata |
|------------|------------|--------------|
| `chat_created` | `create_chat()` returns | `chat_mode`, `has_files` (bool), `file_count` |
| `message_sent` | `send_message()` returns | — |
| `tracking_started` | Daemon starts tracking a chat | `listener_count` |
| `completion_detected` | Daemon detects CHAT_COMPLETED | `detection_source` ("websocket" or "polling") |
| `delivery_attempted` | Daemon attempts delivery to session | `session_key`, `task_label` |
| `delivery_succeeded` | Message delivered to session | `session_key`, `messages_delivered`, `files_downloaded`, `delivery_duration_ms` |
| `delivery_failed` | Delivery failed (all parents tried) | `session_key`, `parents_attempted` |
| `interim_delivered` | Interim update delivered | `session_key`, `update_count` |
| `chat_deleted` | `delete_chat()` called | — |
| `fatal_error` | Daemon hits 426/401/402 | `error_type`, `listeners_notified` |
| `feedback_submitted` | Ticket created post-completion | `ticket_type`, `linked_chat_id` |

#### SDK: EventCollector Class

```python
# cellcog/events.py

class EventCollector:
    """
    Collects SDK events and sends them to CellCog backend in batches.

    - Events are queued in memory
    - Flushed every 30 seconds or when queue reaches 20 events
    - Fire-and-forget: failures are silently ignored (never block SDK operations)
    - Thread-safe for use from both client and daemon
    """

    def __init__(self, api_key: str, api_base_url: str):
        self._queue: list[dict] = []
        self._api_key = api_key
        self._api_base_url = api_base_url
        self._lock = threading.Lock()
        self._flush_thread: Optional[threading.Thread] = None
        self._running = False

    def track(self, event_type: str, chat_id: str, metadata: dict = None):
        """Queue an event. Never blocks or raises."""
        event = {
            "event_type": event_type,
            "chat_id": chat_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "sdk_version": self._get_version(),
            "metadata": metadata or {}
        }
        with self._lock:
            self._queue.append(event)
            if len(self._queue) >= 20:
                self._flush_async()

    def _flush_async(self):
        """Send queued events to backend. Non-blocking."""
        ...

    def _send_batch(self, events: list[dict]):
        """POST events to /cellcog/sdk/events. Silent on failure."""
        try:
            requests.post(
                f"{self._api_base_url}/cellcog/sdk/events",
                headers={"X-API-Key": self._api_key, ...},
                json={"events": events},
                timeout=5
            )
        except Exception:
            pass  # Never fail SDK operations for telemetry
```

#### Integration Points

**In `client.py`:**
```python
# In create_chat():
self._events.track("chat_created", chat_id, {
    "chat_mode": chat_mode,
    "has_files": bool(api_result.get("uploaded_files")),
    "file_count": len(api_result.get("uploaded_files", []))
})

# In delete_chat():
self._events.track("chat_deleted", chat_id)
```

**In `daemon/main.py`:**
```python
# In _handle_completion():
self._events.track("completion_detected", chat_id, {
    "detection_source": source  # "websocket" or "polling"
})

# After delivery attempt:
self._events.track("delivery_succeeded", chat_id, {
    "session_key": listener.session_key,
    "messages_delivered": result.delivered_count,
    "files_downloaded": len(result.downloaded_files),
    "delivery_duration_ms": duration_ms
})
```

#### Backend: Model and Storage

```python
# New model: py/cellcog/model/sdk_event.py

class SDKEvent(Document):
    meta = {"collection": "sdk_events", "indexes": [
        {"fields": ["event_type", "timestamp"]},
        {"fields": ["chat_id"]},
        {"fields": ["timestamp"], "expireAfterSeconds": 2592000}  # 30-day TTL
    ]}

    event_type = StringField(required=True)
    chat_id = StringField(required=True)
    user = ReferenceField("User", required=True)
    sdk_version = StringField()
    timestamp = DateTimeField(required=True)
    metadata = DictField(default={})
```

30-day TTL keeps the collection from growing unboundedly. For longer-term analytics we can aggregate into daily summaries via a Celery beat task.

### 3.3 Why Custom vs. Third-Party

| Option | Pros | Cons |
|--------|------|------|
| **Custom (proposed)** | Zero dependencies, we own data, CellCog-specific metrics, lightweight | Need to build dashboard |
| Sentry | Error tracking, good for crashes | Overkill for delivery events, SDK dependency |
| Segment/Mixpanel | Rich analytics | External dependency, cost, privacy concerns for SDK users |
| OpenTelemetry | Industry standard | Heavy dependency, complex setup for a small SDK |

**Recommendation: Custom.** We need ~10 event types specific to our delivery pipeline. A simple MongoDB collection with TTL index gives us everything we need. We can always add OpenTelemetry later if the SDK grows.

---

## 4. SDK: Agent Feedback After Completion

### 4.1 Problem

We have a `create_ticket()` method but OpenClaw agents are not submitting feedback after CellCog completes tasks. Possible reasons:
1. Agents don't know they should give feedback
2. The completion notification doesn't prompt for it
3. Feedback requires too many parameters
4. We don't know if notifications are even being delivered (solved by Section 3)

### 4.2 Design: Prompt Feedback in Completion Notification

The simplest fix: include a clear feedback prompt in the completion notification that agents receive.

**Current completion notification:**
```
[checkmark] quantum-research completed!

Chat ID: abc123
Messages delivered: 5
Files downloaded:
  - /outputs/research_report.pdf

[warning] YOUR TURN -- CellCog has finished and is waiting for you.
To continue this conversation:
  client.send_message(chat_id="abc123", message="your follow-up", ...)
If this task is complete, no action needed.

[message content]
```

**Proposed completion notification:**
```
[checkmark] quantum-research completed!

Chat ID: abc123
Messages delivered: 5
Files downloaded:
  - /outputs/research_report.pdf

[warning] YOUR TURN -- CellCog has finished and is waiting for you.
To continue this conversation:
  client.send_message(chat_id="abc123", message="your follow-up", ...)
If this task is complete, no action needed.

[star] FEEDBACK -- Help improve CellCog by rating this task:
  client.create_ticket(type="feedback", title="Brief summary", description="What went well or didn't", chat_id="abc123")
Quick options: quality issues, slow, great results, wrong format, missing data

[message content]
```

### 4.3 SKILL.md: Strengthen Feedback Guidance

In the SKILL.md, strengthen the feedback section:

```markdown
### create_ticket()

Submit feedback after any task — this directly improves CellCog:

    client.create_ticket(
        type="feedback",
        title="Research quality excellent",
        description="Found all relevant sources, well-structured.",
        chat_id="abc123",
        tags=["research", "positive"]
    )

**When to submit:** After every significant task. Positive, negative, or observations.
CellCog improves from all feedback.
```

### 4.4 Event Tracking for Feedback

Track feedback submissions as SDK events (`feedback_submitted`). This lets us measure:
- What % of completed chats receive feedback
- Which skill types get more feedback
- Feedback sentiment distribution

---

## 5. Implementation Plan

### Phase 1: SKILL.md Rewrite + delete_chat()
1. Write full SKILL.md from scratch (all content preserved, new structure)
2. Add `delete_chat()` and `_cleanup_tracking_state()` to `client.py`
3. Update completion notification in `daemon/main.py` to include feedback prompt
4. Publish updated skill version

### Phase 2: SDK Event Tracking
1. Create `cellcog/events.py` with `EventCollector` class
2. Integrate into `client.py` (create_chat, send_message, delete_chat)
3. Integrate into `daemon/main.py` (completion, delivery, interim, fatal errors)
4. Create backend endpoint `POST /cellcog/sdk/events`
5. Create `SDKEvent` model with TTL index
6. Publish SDK + deploy backend

### Phase 3: Dashboard and Analysis
1. Build admin dashboard for SDK event metrics
2. Celery beat task for daily aggregation
3. Alert on delivery failure rate spikes

---

## 6. Open Questions

1. **Phase 1 scope:** Should I implement everything in Phase 1 now (SKILL.md + delete_chat + feedback prompt), and then move to Phase 2 after you test?

2. **Version bump:** Should the skill go to 1.1.0 for Phase 1?

3. **Events endpoint auth:** Should `/cellcog/sdk/events` use the same API key auth as chat endpoints, or should it be unauthenticated (with rate limiting)?

4. **Event batching in daemon:** The daemon is async. Should the EventCollector use asyncio-native batching (aiohttp) in the daemon, or is a simple sync `requests.post` in a thread sufficient?

5. **Feedback in satellite skills:** Should satellite skill completion notifications also include feedback prompts, or just the core skill?
