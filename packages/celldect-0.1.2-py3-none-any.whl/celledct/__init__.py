import sys
import importlib.util

# 1. 定义基础模块名
_MODULE_BASE_NAMES = ['celldect20', 'celldect30']

# 2. 建立平台到实际文件名的精确映射
if sys.platform.startswith('win32'):
    # Windows 下的具体文件名
    _FILE_MAP = {
        'celldect20': 'celldect20.cp310-win_amd64.pyd',
        'celldect30': 'celldect30.cp310-win_amd64.pyd'
    }
elif sys.platform.startswith('linux'):
    # Linux 下的具体文件名
    _FILE_MAP = {
        'celldect20': 'celldect20.cpython-310-x86_64-linux-gnu.so',
        'celldect30': 'celldect30.cpython-310-x86_64-linux-gnu.so'
    }
else:
    raise OSError(f"Unsupported platform: {sys.platform}")

# 3. 动态加载每个模块
for _base_name in _MODULE_BASE_NAMES:
    # 获取当前平台对应的真实文件名
    _actual_filename = _FILE_MAP[_base_name]
    # 构建文件的绝对路径（__file__是当前__init__.py的路径）
    _file_path = f"{__file__.rstrip('__init__.pyo')}{_actual_filename}"

    # 使用文件名创建模块规格并加载
    _spec = importlib.util.spec_from_file_location(_base_name, _file_path)
    _module = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_module)

    # 将加载的模块暴露到当前包的命名空间
    globals()[_base_name] = _module

# 4. 清理内部变量（可选，使包接口更干净）
del sys, importlib, _MODULE_BASE_NAMES, _FILE_MAP, _base_name, _actual_filename, _file_path, _spec, _module

# 5. 定义 __all__
__all__ = ['celldect20', 'celldect30']