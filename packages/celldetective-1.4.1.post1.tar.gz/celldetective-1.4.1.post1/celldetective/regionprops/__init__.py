from ._regionprops import regionprops_table
