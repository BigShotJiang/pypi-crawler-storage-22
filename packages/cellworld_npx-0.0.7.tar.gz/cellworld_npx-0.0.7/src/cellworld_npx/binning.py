from .probe import cluster_probe_channels
from .recording import load_recording_from_file, Recording
from .io import parse_datetime_from_string
import numpy as np
import pandas as pd
from tqdm import tqdm
from glob import glob
from scipy.spatial import cKDTree
import os
import copy

class BinnedRecording(object):
    def __init__(self, recording_file, dt=0.005, format='spike',
                 bins=None, window=None, cluster_filter=None, 
                 amplitude_threshold=1000, spike_count_threshold=1, remove_duplicate_spikes=0,
                 verbose=False, load_spikes=True):
        self.recording_file = recording_file
        if type(recording_file) == Recording:
            self.recording = recording_file
        else:
            self.recording = load_recording_from_file(recording_file)
        self.behavior_data = pd.DataFrame()
        self.spikes = dict()
        self.spike_array = None
        self.clusters_info = pd.DataFrame()
        self.cluster_filter = cluster_filter
        self.clusters = filter_dataframe(self.recording.clusters_info, self.cluster_filter)
        self.dt = dt
        self.bins = bins
        self.window = window
        self.format = format
        self.x_offset = [0, 1200]
        self.spike_count_threshold = spike_count_threshold
        self.amplitude_threshold = amplitude_threshold
        self.remove_duplicate_spikes = remove_duplicate_spikes
        self.verbose = verbose
        self.load_spikes = load_spikes

    def load_data(self, amp_location=r'V:\spike_amplitudes', load_spikes=None):
        if load_spikes is not None:
            self.load_spikes = load_spikes
        amplitude_files = get_amplitude_files(self.recording, amp_location)
        if self.load_spikes:
            self.get_spike_data(amplitude_files)
        self.get_behavior_data()
    
    def resample(self, dt=None, window=None, load_spikes=None):
        if dt is not None:
            self.dt = dt
        if window is not None:
            self.window = window
        if load_spikes is not None:
            self.load_spikes = load_spikes
        if self.bins is None:
            self.bins = self.get_bins()

        self.behavior_data = bin_dataframe(self.behavior_data, bins=self.bins)

        if self.load_spikes:
            if self.format == 'mua':
                self.spike_array, self.mua_groups = self.bin_mua()
            else:
                self.spike_array = self.bin_spikes()

    def get_bins(self):
        if 'spike_times' in self.spikes:
            bins = np.arange(self.spikes['spike_times'].min(),
                             self.spikes['spike_times'].max(),
                             self.dt)
        else:
            bins = np.arange(self.behavior_data['time_stamp'].min(),
                             self.behavior_data['time_stamp'].max(),
                             self.dt)
        return bins

    def get_ops(self):
        return dict(recording_file=self.recording_file, 
                    dt=self.dt, 
                    format=self.format, 
                    bins=self.bins, 
                    window=self.window, 
                    cluster_filter=self.cluster_filter, 
                    amplitude_threshold=self.amplitude_threshold, 
                    spike_count_threshold=self.spike_count_threshold,
                    remove_duplicate_spikes=self.remove_duplicate_spikes,
                    verbose=self.verbose)
    
    def get_spike_data(self, amplitude_files=[]):
        self.clusters_info = self.recording.clusters_info
        if self.verbose:
            print("Loading spike data...")
        if not hasattr(self.recording, 'spike_times'):
            spike_times, clusters, _, probe_index = self.recording.get_spikes()
        else:
            spike_times = self.recording.spike_times
            clusters = self.recording.clusters
            probe_index = self.recording.probe_spike_index
        self.spikes['spike_times'] = spike_times
        self.spikes['clusters'] = clusters
        self.spikes['probe_index'] = probe_index
        if self.format == 'mua':
            assert len(amplitude_files) > 0, 'No amplitude data provided.'
            if self.verbose:
                print('Loading amplitude data...')
            amps = []
            positions = []
            for i,f in enumerate(amplitude_files):
                amps.append(np.load(f))
                pos = np.load(self.recording.spike_path[i] + '\spike_positions.npy')
                positions.append(pos)
            if len(amps) > 1:
                amps = np.vstack(amps)
                positions = np.vstack(positions)
            else:
                amps = amps[0]
                positions = positions[0]
            self.spikes['amps'] = np.ascontiguousarray(amps, dtype=np.float32)
            self.spikes['positions'] = np.ascontiguousarray(positions, dtype=np.float32)

        if self.clusters is not None:
            self._filter_spike_clusters(self.clusters)

        if self.remove_duplicate_spikes > 0:
            self._remove_duplicate_spikes()

    def get_behavior_data(self):
        if hasattr(self.recording, 'df'):
            self.behavior_data = self.recording.df.copy()
        else:
            self.behavior_data = self.recording.get_behavior_dataframe().copy()

    def bin_spikes(self):
        if self.bins is None:
            self.bins = self.get_bins()
        n_clusters = len(self.clusters_info)
        spike_array = np.nan * np.ones((len(self.bins), n_clusters))
        for i in tqdm(range(n_clusters), desc='Binning spikes... ', total=n_clusters, disable=not self.verbose):
            spike_times = self.spikes['spike_times'][(self.spikes['clusters'] == self.clusters_info.iloc[i].cluster_id) & 
                                                     (self.spikes['probe_index'] == self.clusters_info.iloc[i].probe_index)]
            spike_array[:,i] = bin_spikes(spike_times, self.bins, self.window)
        return spike_array
    
    def bin_mua(self):
        if self.bins is None:
            self.bins = self.get_bins()
        bins = np.hstack([self.bins - self.dt/2, self.bins[-1] + self.dt/2]) 

        # extract spike features per probe:
        groups = get_channel_groups(self.recording.get_channel_map())
        n_groups = groups[0]['channels'].shape[0]
        spike_group = np.zeros(self.spikes['spike_times'].shape[0])
        spike_features = np.zeros((self.spikes['spike_times'].shape[0], groups[0]['channels'].shape[-1])) 
        for i, probe in tqdm(enumerate(np.unique(self.spikes['probe_index'])), desc='Binning mua... ', disable=not self.verbose, total=len(np.unique(self.spikes['probe_index']))):
            I = self.spikes['probe_index'] == probe
            sg = assign_spike_groups(self.spikes['positions'][I,:], groups[probe]['com'])
            spike_features[I,:] = extract_spike_amplitude_features(self.spikes['amps'][I,:], sg, groups[probe]['channels'])
            spike_group[I] = sg + (n_groups * i) # accumulate spike group indices across probes

        # construct multiunit array in spike time order:
        st = np.argsort(self.spikes['spike_times'])
        mua = get_multiunits(self.spikes['spike_times'][st], spike_group[st], spike_features[st], bins)
        
        # drop spikes with high amplitudes (aka likely artifacts)
        bad = np.any(np.abs(mua) > self.amplitude_threshold, axis=1)
        mask = np.broadcast_to(bad[:, None, :], mua.shape)
        mua[mask] = np.nan
        
        # drop groups with a low number of spikes
        group_spikes = np.sum(np.all(~np.isnan(mua), axis=1), axis=0)
        mua = mua[:,:,group_spikes > self.spike_count_threshold]
        group_nums = np.unique(spike_group)[group_spikes > self.spike_count_threshold]

        return mua, group_nums 
        
    def __getitem__(self, key):
        '''custom slicing of BinnedRecording object'''
        if self.spike_array is None:
            raise ValueError("Spike array not initialized. Run load_data() first.")
        new_obj = copy.copy(self)  # shallow copy; we'll replace relevant fields below

        if isinstance(key, tuple):
            row_key, col_key = key
            if len(self.spike_array.shape) == 2:
                new_obj.spike_array = self.spike_array[row_key,:][:,col_key].copy()
            else:
                self._filter_spike_clusters(col_key)
                new_obj.spike_array, new_obj.mua_groups = self.bin_mua()[row_key,:,:]
            new_obj.clusters_info = self.clusters_info.iloc[_normalize_index(col_key, len(self.clusters_info))].copy()
            new_obj.behavior_data = self.behavior_data.iloc[_normalize_index(row_key, len(self.behavior_data))].copy()
        else:
            if len(self.spike_array.shape) == 2:
                new_obj.spike_array = self.spike_array[key,:].copy()
            else:
                new_obj.spike_array = self.spike_array[key,:,:].copy()
            new_obj.behavior_data = self.behavior_data.iloc[_normalize_index(key, len(self.behavior_data))].copy()
        return new_obj
    
    def __len__(self):
        if self.spike_array is None:
            raise ValueError("Spike array not initialized.")
        return self.spike_array.shape[0]
    
    def _filter_spike_clusters(self, index):
        if self.verbose:
            print('Filtering spikes... ', end='')
        if all(isinstance(e, bool) for e in index):
            assert len(index) == len(self.recording.clusters_info), 'boolean cluster list must match clusters_info shape'
            clusters = self.recording.clusters_info.cluster_id[index].to_list()
            probes = self.recording.clusters_info.probe_index[index].to_list()   

        # build index
        I = np.zeros(len(self.spikes['spike_times']), dtype=bool)
        for c, p in zip(clusters, probes):
            I[(self.spikes['clusters'] == c) & (self.spikes['probe_index'] == p)] = True
        if self.verbose:
            print(f'{I.sum()} / {len(self.spikes["spike_times"])} spikes kept...')

        for k in self.spikes.keys():
            self.spikes[k] = self.spikes[k][I]

    def _remove_duplicate_spikes(self):
        if self.verbose:
            print(f'Removing duplicate spikes (>{self.remove_duplicate_spikes})... ', end='')
        _, mask = remove_duplicates(
            self.spikes['spike_times'], 
            n=self.remove_duplicate_spikes, 
            keep_first=False)
        if self.verbose:
            print(f'{(~mask).sum()} / {len(self.spikes["spike_times"])} spikes kept...')
        for k in self.spikes.keys():
            self.spikes[k] = self.spikes[k][~mask]

    def plot_behavior_summary(self, fig=None):
        import matplotlib.pyplot as plt
        from matplotlib import gridspec
        if fig is None:
            fig = plt.figure(figsize=(12,8))
        
        gs = gridspec.GridSpec(2, 3)
        ax = fig.add_subplot(gs[0,0])
        ax.plot(self.recording.df.prey_location_x, self.recording.df.prey_location_y, '.', alpha=0.5, ms=1)
        ax.set_aspect('equal')

        ax = fig.add_subplot(gs[0,1])
        ax.plot(self.behavior_data.prey_location_x[::10], self.behavior_data.prey_location_y[::10], '-')
        ax.set_aspect('equal')

        ax = fig.add_subplot(gs[0,2])
        ax.plot(self.behavior_data.prey_location_x[::10], self.behavior_data.prey_location_y[::10], '-')
        ax.set_xlim([-0.075, 0.075])
        ax.set_ylim([0.45, 0.55])
        ax.set_aspect('equal')

        ax = fig.add_subplot(gs[1,:])
        ax.set_title(self.recording.experiment_name)
        I = self.behavior_data.prey_tracked_in_arena == True
        ax.plot(self.behavior_data.time_stamp[I][::10], self.behavior_data.prey_location_x[I][::10], '.', ms=1)
        if 'prey_tracked_in_entrance' in self.behavior_data.columns:
            I = self.behavior_data.prey_tracked_in_entrance == True
            ax.plot(self.behavior_data.time_stamp[I][::10], self.behavior_data.prey_location_x[I][::10], '.', ms=1)
        ax1 = ax.twinx()
        ax1.plot(self.behavior_data.time_stamp[I][::10], self.behavior_data.episode[I][::10], '-', color='tab:grey', zorder=-1)
        plt.show()


def bin_recording(ops, load_spikes=True):
    B = BinnedRecording(**ops)
    B.load_data(load_spikes=load_spikes)
    B.resample(load_spikes=load_spikes)
    return B

def get_amplitude_files(R, root=r'V:\spike_amplitudes'):
    files = glob(os.path.join(root, '*_spike_amplitudes.npy'))
    date = parse_datetime_from_string(R.experiment_name)
    dates = [parse_datetime_from_string(f) for f in files]
    dt = np.abs(np.array([(date - t).total_seconds() for t in dates]))
    return [files[i] for i in np.where(dt == dt.min())[0]]

def _normalize_index(idx, N):
    """
    Converts a slice, list of bool, list of ints, or np.ndarray index
    to a valid index for .iloc[]
    """
    if isinstance(idx, slice):
        return range(*idx.indices(N))
    elif isinstance(idx, (list, np.ndarray)):
        idx = np.asarray(idx)
        if idx.dtype == bool:
            # Boolean mask
            if idx.size != N:
                raise IndexError("Boolean index does not match array length.")
            return np.flatnonzero(idx)
        else:
            # List/array of indices
            return idx
    elif isinstance(idx, int):
        return [idx]
    else:
        raise TypeError(f"Unsupported index type: {type(idx)}")

def bin_dataframe(df, interval=0.05, bins=None, gap_threshold=0.05):
    if bins is None:
        bins = np.arange(df['time_stamp'].min(), df['time_stamp'].max(), interval)
    time_gap_mask = timestamp_gaps(df['time_stamp'].values, bins, interval, gap_threshold)
    prey_tracking_gap_mask = tracking_gaps(df['time_stamp'].values, df['prey_location_x'].values, bins, interval, gap_threshold)
    predator_tracking_gap_mask = tracking_gaps(df['time_stamp'].values, df['predator_location_x'].values, bins, interval, gap_threshold)
    # tracking_gap_mask = tracking_gaps(df['time_stamp'].values, df['prey_location_x'].values, bins, interval, gap_threshold) | time_gap_mask
    df_grid = pd.DataFrame({'time_stamp': bins})
    df_interp = pd.merge_asof(df_grid, df.sort_values('time_stamp'), on='time_stamp')
    for col in df_interp.columns:
        if col != 'time_stamp':
            if df[col].dtype == 'object':
                df_interp[col] = df_interp[col].interpolate(method='linear')
            elif any(keyword in col.lower() for keyword in ['heading', 'orientation', 'angle', 'direction', 'rotation']):
                df_interp[col] = interpolate_angles_circular(df[col], df['time_stamp'], bins)
            else:
                df_interp[col] = df_interp[col].interpolate(method='linear') #np.interp(bins, df['time_stamp'], df[col])
            # df_interp[col][tracking_gap_mask] = np.nan

            # remove tracking gaps
            if 'prey' in col:
                df_interp[col][prey_tracking_gap_mask] = np.nan
            elif 'predator' in col:
                df_interp[col][predator_tracking_gap_mask] = np.nan
            df_interp[col][time_gap_mask] = np.nan

            # remove interpolation artifacts in tracking frames (frames decrease in value)
            if col == 'tracking_frame':
                df_interp[col][np.diff(np.r_[0, df_interp["tracking_frame"].to_numpy()]) < 0] = np.nan

            # remove where prey rotation is unknown (close to 90 degrees)
            if col == 'prey_rotation':
                df_interp[col][np.isclose(np.array(df_interp.prey_rotation.to_list()), 90)] = np.nan


    return df_interp

def split_recordings():
    d = [
        {
            "recordings": [
                "OASIS_20250324_1412_CA024_oasis_island10_02_O10FULL",
                "OASIS_20250324_1436_CA024_oasis_island10_02_O10FULLBOT",
            ],
            "split_time": 1275,
        },
        {
            "recordings": [
                "OASIS_20250324_1412_CA024_oasis_island10_02_O10FULL",
                "OASIS_20250324_1436_CA024_oasis_island10_02_O10FULLTOP",
            ],
            "split_time": 1275,
        },
    ]

    return d

def timestamp_gaps(t, bins, interval=0.05, gap_threshold=None):
    dt = np.diff(t)
    med_dt = np.median(dt)
    if gap_threshold is None:
        gap_threshold = max(1.5 * interval, 3.0 * med_dt)
    long_gap_mask = np.zeros_like(bins, dtype=bool)
    long_gap_mask |= (bins < t[0]) | (bins > t[-1])

    gap_idx = np.nonzero(np.diff(t) > gap_threshold)[0]
    for i in gap_idx:
        left = t[i]
        right = t[i+1]
        long_gap_mask |= (bins > left) & (bins < right)

    return long_gap_mask

import numpy as np

def tracking_gaps(t, y, bins, interval=0.05, gap_threshold=1.0):
    t = np.asarray(t, dtype=float)
    y = np.asarray(y)
    bins = np.asarray(bins, dtype=float)
    if y.ndim == 1:
        valid = np.isfinite(y)
    else:
        valid = np.all(np.isfinite(y), axis=1)

    if np.count_nonzero(valid) < 2:
        mask = np.zeros_like(bins, dtype=bool)
        if t.size:
            mask |= (bins >= t.min()) & (bins <= t.max())
        return mask

    t_valid = t[valid]

    return timestamp_gaps(t_valid, bins, interval=interval, gap_threshold=gap_threshold)


def bin_spikes(spike_times, bin_centers, window_width, sort=False):
    spike_times = np.asarray(spike_times)
    bin_centers = np.asarray(bin_centers)
    if window_width is None:
        half_width = np.mean(np.diff(bin_centers)) / 2
    else:
        half_width = window_width / 2

    if sort:
        spike_times = np.sort(spike_times)

    left_edges = bin_centers - half_width
    right_edges = bin_centers + half_width

    left_idxs = np.searchsorted(spike_times, left_edges, side='left')
    right_idxs = np.searchsorted(spike_times, right_edges, side='right')

    counts = right_idxs - left_idxs
    return counts

def filter_dataframe(df, filters:dict, return_df=False):
    if filters is not None:
        filter_expr = ' & '.join([f"(df['{k}'] {v})" for k, v in filters.items()])
        if return_df:
            return df[eval(filter_expr)]
        else:
            return(eval(filter_expr).tolist())

def make_map_bins(ideal_bin_width=0.10, bin_range=(-0.05, 1.05), canonical_to_m=2.34, scaler=1, return_canonical=True):
    # range typically is (0,1) but in NPX hab there is extra space at either entrance
    bin_range = np.array(bin_range) * scaler
    n_bins = int(np.ceil((bin_range[1]*canonical_to_m - bin_range[0]*canonical_to_m) / ideal_bin_width))
    # n_bins = int(np.round((2.34*scaler) / ideal_bin_width))
    if return_canonical:
        bins = np.linspace(bin_range[0], bin_range[1], n_bins)
    else:
        bins = np.linspace(bin_range[0]*canonical_to_m, bin_range[1]*canonical_to_m, n_bins)
    bin_width = np.mean(np.diff(bins))
    bin_centers = bins[:-1] + bin_width/2
    return bins, bin_width, bin_centers

def remove_duplicates(arr, n=1, keep_first=False):
    arr = np.asarray(arr)

    _, inv, counts = np.unique(arr, return_inverse=True, return_counts=True)
    too_many = counts > n                   # per-unique-value

    if keep_first:
        # mask for first occurrence of each value (in original order)
        _, first_idx = np.unique(arr, return_index=True)
        first_mask = np.zeros(arr.shape[0], dtype=bool)
        first_mask[first_idx] = True

        # drop elements that belong to an over-repeated value, except the first occurrence
        drop_mask = too_many[inv] & ~first_mask
    else:
        drop_mask = too_many[inv]
    idx_drop = np.flatnonzero(drop_mask)

    return idx_drop, drop_mask

## angle interpolation
def unwrap_angles(angles):
    angles = np.array(angles)
    # Find where angles jump by more than π (indicating a wrap)
    diff = np.diff(angles)
    # Add 2π to negative jumps > π, subtract 2π from positive jumps > π
    diff[diff > np.pi] -= 2 * np.pi
    diff[diff < -np.pi] += 2 * np.pi
    # Reconstruct unwrapped angles
    unwrapped = np.zeros_like(angles)
    unwrapped[0] = angles[0]
    unwrapped[1:] = angles[0] + np.cumsum(diff)
    return unwrapped

def wrap_angles(angles):
    return np.arctan2(np.sin(angles), np.cos(angles))

def interpolate_angles_circular(angles, timestamps, new_timestamps):
    angles = np.array(angles)
    timestamps = np.array(timestamps)
    new_timestamps = np.array(new_timestamps)
    
    # Handle NaN values
    valid_mask = ~np.isnan(angles)
    if not np.any(valid_mask):
        return np.full_like(new_timestamps, np.nan)
    
    # Unwrap angles for linear interpolation
    unwrapped_angles = unwrap_angles(angles[valid_mask])
    valid_timestamps = timestamps[valid_mask]
    
    # Linear interpolation on unwrapped angles
    interpolated_unwrapped = np.interp(new_timestamps, valid_timestamps, unwrapped_angles)
    
    # Wrap back to [-π, π]
    interpolated_angles = wrap_angles(interpolated_unwrapped)
    
    return interpolated_angles

def interp_skip_nan_ranges(t, y, t_new, *, max_gap=None):
    t   = np.asarray(t,   dtype=float)
    y   = np.asarray(y,   dtype=float)
    t_new = np.asarray(t_new, dtype=float)
    print('skipping nan ranges')

    good = np.isfinite(y)
    if good.sum() < 2:
        # Not enough points to interpolate
        return np.full_like(t_new, np.nan, dtype=float)

    # 1) interpolate from valid samples only
    y_new = np.interp(t_new, t[good], y[good], left=np.nan, right=np.nan)

    # 2) find NaN runs in the original data
    bad = ~good
    bb = np.r_[False, bad, False]                       # sentinels
    edges = np.flatnonzero(bb[1:] != bb[:-1])           # start/stop indices
    runs = list(zip(edges[::2], edges[1::2]))           # [start, end) in index space

    # 3) for each NaN run, blank out t_new in that time interval
    for s, e in runs:
        left_edge  = t[s]
        right_edge = t[e-1]
        duration = right_edge - left_edge

        # Decide whether to keep this run as NaN
        keep_as_nan = (max_gap is None) or (duration > max_gap)
        if keep_as_nan:
            mask = (t_new >= left_edge) & (t_new <= right_edge)
            y_new[mask] = np.nan

    return y_new


## helper functions for formatting spikes in clusterless format
def find_amplitude_files(R, root=r'V:\spike_amplitudes'):
    return glob(os.path.join(root, f'{R.experiment_name}*_spike_amplitudes.npy'))


def get_channel_groups(channel_maps, n_channels=4, xoffset = [0, 0]):
    groups = []
    for i,map in enumerate(channel_maps):
        map[:,1] = map[:,1] + xoffset[i]
        group_channels, group_com = group_channel_map(map, n=n_channels)
        groups.append({'channels': group_channels, 
                       'com': group_com,
                       'channel_map': map})
    return groups

def group_channel_map(channel_map, n=4):
    #TODO test overlapping groups

    # group each block of channels into groups of n electrodes
    channel_blocks = cluster_probe_channels(channel_map)
    channel_groups = np.zeros(channel_blocks.shape)
    block_length = 0
    group_count = 0
    for b in np.unique(channel_blocks):
        for i,j in enumerate(range(0, (channel_blocks==b).sum(), n)):
            ind = block_length + j
            channel_groups[ind:ind+n] = i + group_count
        group_count = group_count + i + 1
        block_length = block_length + (channel_blocks==b).sum()

    # calculate group COM
    group_com = []
    for c in np.unique(channel_groups):
        group_com.append(channel_map[channel_groups==c, 1:].mean(0))
    group_com = np.vstack(group_com)

    # get closest channels
    group_channels = []
    for i in range(group_com.shape[0]):
        group_channels.append(np.argsort(np.sum((channel_map[:,1:] - group_com[i,:]) ** 2, axis=1) ** 0.5)[0:n])
    group_channels = np.vstack(group_channels)
    return group_channels, group_com

def assign_spike_groups(spike_positions, group_com):
    # ensure light dtype
    P = np.asarray(spike_positions, dtype=np.float32, order='C')
    G = np.asarray(group_com,      dtype=np.float32, order='C')

    tree = cKDTree(G)                         # build tree on centers (K × D)
    _, idx = tree.query(P, k=1, workers=-1)   # nearest center for each point (N queries)
    return idx.astype(np.int32)

def extract_spike_amplitude_features(spike_amps, spike_group, group_channels, n=None):
    """
    spike_amps:   (N, C) float array
    spike_group:  (N,)   int array; group id per spike
    group_channels: (G, n) int array OR list of length G with n ints each
    n: use the first n channels per group (optional)
    """
    A = np.asarray(spike_amps,  order="C")
    g = np.asarray(spike_group, dtype=np.int32)

    # Normalize group_channels to a 2D int array (G, n)
    if isinstance(group_channels, np.ndarray) and group_channels.ndim == 2:
        GC = group_channels.astype(np.int32, copy=False)
    else:
        GC = np.vstack([np.asarray(ch, dtype=np.int32) for ch in group_channels])

    if n is not None:
        GC = GC[:, :n]

    # For each spike, pick the channel list of its group → (N, n)
    cols = GC[g]
    features = np.take_along_axis(A, cols, axis=1)
    return features

def get_multiunits(spike_times, spike_group, spike_features, bins, check_duplicate_spikes=False):
    """
    Vectorized replacement for the loop version.
    Keeps the last spike's features in each (bin, group) cell,
    and optionally returns counts per cell.
    """
    spike_times   = np.asarray(spike_times)
    spike_group   = np.asarray(spike_group)
    spike_features= np.asarray(spike_features, order="C")
    ugroups       = np.unique(spike_group)            # sorted
    G             = ugroups.size
    F             = spike_features.shape[1]

    # digitize -> 0..nb-1 (drop out-of-range)
    s = np.digitize(spike_times, bins=bins, right=True) - 1
    nb = max(len(bins) - 1, 0)
    valid = (s >= 0) & (s < nb)
    if not np.any(valid):
        out = np.full((nb, F, G), np.nan, dtype=spike_features.dtype)
        if check_duplicate_spikes:
            return out, np.zeros((nb, G), dtype=np.int32)
        return out

    s  = s[valid]                                   # bin indices per spike
    gi = np.searchsorted(ugroups, spike_group[valid])  # group indices per spike
    idx_orig = np.nonzero(valid)[0]                 # original spike indices

    # For each (bin, group): keep the last spike index (max over idx_orig)
    last_idx = np.full((nb, G), -1, dtype=np.int64)
    np.maximum.at(last_idx, (s, gi), idx_orig)

    # Optional counts per (bin, group)
    if check_duplicate_spikes:
        counts = np.zeros((nb, G), dtype=np.int32)
        np.add.at(counts, (s, gi), 1)

    # Scatter selected (last) features into output
    out = np.full((nb, F, G), np.nan, dtype=spike_features.dtype)
    rr, cc = np.nonzero(last_idx >= 0)              # cells that got at least one spike
    src = last_idx[rr, cc]                          # spike indices to copy from
    out[rr, :, cc] = spike_features[src, :]

    return (out, counts) if check_duplicate_spikes else out
