from ..binning import BinnedRecording, bin_recording
from ..ratemaps import RateMaps
from ..celltile import get_world_mask
from ..probe import cluster_probe_channels
from replay_trajectory_classification import SortedSpikesClassifier, ClusterlessClassifier, Environment, RandomWalk, Uniform, Identity
from scipy.spatial.distance import squareform, pdist
import matplotlib.pyplot as plt
from scipy.stats import norm
from tqdm import tqdm
import statsmodels.api as sm
import torch.nn.functional as F
import torch
import gc
import numpy as np
import time
import copy
import pickle
import os
    
class BayesDecoderTorch(object):
    def __init__(self,
                 bins=None,
                 encoding_model='quadratic',
                 device='cuda',
                 mask='world',
                 smooth_sigma=3.0,
                 occupancy_cutoff=0,
                 smooth_constraint=False
                 ):
        self.name = 'Bayesian'
        self.encoding_model = encoding_model
        self.bins = bins
        self.device = device
        self.mask = mask
        self.smooth_sigma = smooth_sigma
        self.occupancy_cutoff = occupancy_cutoff
        self.smooth_constraint = smooth_constraint
        self.location_bins = self.get_location_bins()
        self.tuning_all = None
        self.std = None

    def get_mask(self, recording:BinnedRecording):
        mask = np.ones((len(self.bins) * len(self.bins),1))
        if self.mask == 'occupancy':
            occ = get_occupancy(recording.behavior_data.prey_location_x,
                                recording.behavior_data.prey_location_y,
                                self.bins,
                                cutoff=0.1,
                                dt=recording.dt)
            mask = (np.rot90(occ) > 0).flatten()
        elif self.mask == 'world':
            mask = get_world_mask(recording.recording.world, self.bins)
            mask = np.rot90(mask.reshape(len(self.bins)-1, len(self.bins)-1) < 1).flatten()
        return mask
    
    def get_variables(self, recording:BinnedRecording, remove_nans=True):
        X = recording.spike_array
        y = np.vstack([recording.behavior_data.prey_location_x, 
                       recording.behavior_data.prey_location_y]).T
        if remove_nans:
            invalid = np.any(np.isnan(X), axis=1) | np.any(np.isnan(y), axis=1)
            X = X[~invalid, :]
            y = y[~invalid, :]
        return X, y

    def get_location_bins(self):
        assert self.bins is not None, 'bins must be specified'
        bin_centers = self.bins[:-1] + np.mean(np.diff(self.bins)) / 2
        input_mat = np.meshgrid(bin_centers, bin_centers)
        xs = np.reshape(input_mat[0],[bin_centers.shape[0]*bin_centers.shape[0],1])
        ys = np.reshape(input_mat[1],[bin_centers.shape[0]*bin_centers.shape[0],1])
        return np.concatenate((xs,ys),axis=1)

    def fit_glm(self, recording:BinnedRecording, max_iter=2000, lr=1e-2, verbose=False):
        X, y = self.get_variables(recording)
        # Feature engineering
        if self.encoding_model == 'linear':
            Y_design = y
            bins_design = self.location_bins
        elif self.encoding_model == 'quadratic':
            Y_design = self.quadratic_features(y)
            bins_design = self.quadratic_features(self.location_bins)

        # Convert to torch tensors and push to device
        X = torch.tensor(X, dtype=torch.float32, device=self.device)
        Y_design = torch.tensor(Y_design, dtype=torch.float32, device=self.device)
        bins_design = torch.tensor(bins_design, dtype=torch.float32, device=self.device)

        n_obs, n_cells = X.shape
        n_bins = bins_design.shape[0]

        # Add intercept
        Y_design_ = torch.cat([torch.ones((Y_design.shape[0], 1), device=self.device), Y_design], dim=1)
        bins_design_ = torch.cat([torch.ones((bins_design.shape[0], 1), device=self.device), bins_design], dim=1)
        n_feat = Y_design_.shape[1]

        # Parallel weights for all cells: shape (n_cells, n_feat)
        weights = torch.zeros((n_cells, n_feat), device=self.device, requires_grad=True)
        optimizer = torch.optim.Adam([weights], lr=lr)

        targets = X # (n_obs, n_cells)

        for it in tqdm(range(max_iter), desc='Fitting Poisson GLMs (batch)', disable=not verbose):
            optimizer.zero_grad()
            eta = Y_design_ @ weights.T        # (n_obs, n_cells)
            mu = torch.exp(eta)
            loss = torch.sum(mu - targets * eta)
            loss.backward()
            optimizer.step()
            if verbose and it % 500 == 0:
                print(f"Iter {it}: Loss={loss.item():.4f}")

        # Predict tuning for all location bins, all cells at once
        with torch.no_grad():
            eta_pred = bins_design_ @ weights.T  # (n_bins, n_cells)
            mu_pred = torch.exp(eta_pred)        # (n_bins, n_cells)
        
        return mu_pred.cpu().numpy().T  # (n_cells, n_bins)

    def quadratic_features(self, arr):
        out = np.empty([arr.shape[0], 5])
        out[:,0] = arr[:,0] ** 2
        out[:,1] = arr[:,0]
        out[:,2] = arr[:,1] ** 2
        out[:,3] = arr[:,1]
        out[:,4] = arr[:,0] * arr[:,1]
        return out
    
    def fit_rate_map(self, recording:BinnedRecording, smooth_sigma=3, occupancy_cutoff=0):
        spike_maps = RateMaps(recording, 
                              bins=self.bins, 
                              smooth_sigma=smooth_sigma, 
                              occupancy_cutoff=occupancy_cutoff).rate_maps
        spike_maps = [s.T.flatten() for s in spike_maps]
        spike_maps = np.vstack(spike_maps)
        spike_maps[np.isnan(spike_maps)] = 0
        return spike_maps * recording.dt
    
    def fit(self, recording:BinnedRecording):
        if 'quadratic' in self.encoding_model or 'linear' in self.encoding_model:
            self.tuning_all = self.fit_glm(recording)
        else:
            self.tuning_all = self.fit_rate_map(recording, 
                                                smooth_sigma=self.smooth_sigma, 
                                                occupancy_cutoff=self.occupancy_cutoff)

        if self.mask is not None:
            mask = self.get_mask(recording)
            for i in range(self.tuning_all.shape[0]):
                self.tuning_all[i,:] = self.tuning_all[i,:] * mask

        _, y = self.get_variables(recording)
        dx = np.sqrt(np.sum(np.diff(y, axis=0)**2, axis=1))
        std = np.sqrt(np.mean(dx**2))
        self.std = std

        gc.collect()
        torch.cuda.empty_cache()


    def predict(self, recording:BinnedRecording, return_posterior=False, batch_size=1000):
        smooth_constraint = self.smooth_constraint
        X_test = recording.spike_array
        y_test = np.vstack([recording.behavior_data.prey_location_x, 
                            recording.behavior_data.prey_location_y]).T
        nt, n_cells = X_test.shape

        tuning_all = torch.tensor(self.tuning_all, dtype=torch.float32, device=self.device)  # (n_cells, n_bins)
        tuning_all = torch.nan_to_num(tuning_all, nan=0.0)
        location_bins = torch.tensor(self.location_bins, dtype=torch.float32, device=self.device)  # (n_bins, 2)
        n_bins = tuning_all.shape[1]

        X_test = torch.tensor(X_test, dtype=torch.float32, device=self.device)  # CPU batching for memory
        y_test_predicted = torch.empty((nt, 2), dtype=torch.float32, device=self.device)

        if return_posterior:
            posterior_array = torch.empty((nt, n_bins), dtype=torch.float32, device=self.device)

        # --- Smoothing: precompute transition matrix ---
        prob_dists = None
        if smooth_constraint:
            dists = squareform(pdist(self.location_bins), 'euclidean')
            prob_dists = norm.pdf(dists, 0, self.std)
            log_trans = torch.log(torch.tensor(prob_dists + 1e-12, dtype=torch.float32, device=self.device))

        # --- Precompute Poisson terms ---
        log_tuning = torch.log(tuning_all + 1e-8)  # (n_cells, n_bins)
        lam = tuning_all.unsqueeze(0)             # (1, n_cells, n_bins)
        log_lam = log_tuning.unsqueeze(0)         # (1, n_cells, n_bins)

        # --- Loop over batches ---
        log_belief = None  # used only if smooth_constraint is on
        for batch_start in tqdm(range(0, nt, batch_size), desc='Batch prediction'):
            batch_end = min(batch_start + batch_size, nt)
            batch_idx = slice(batch_start, batch_end)
            Xc = torch.clamp(X_test[batch_idx], max=170).round()  # (batch, n_cells)

            # Poisson log likelihood
            log_fact = torch.lgamma(Xc + 1).unsqueeze(-1)  # (batch, n_cells, 1)
            Xc_exp = Xc.unsqueeze(-1)                     # (batch, n_cells, 1)
            log_probs_batch = torch.sum(
                -lam + Xc_exp * log_lam - log_fact,
                dim=1  # sum over cells
            )  # (batch, n_bins)

            if smooth_constraint:
                for k in range(log_probs_batch.shape[0]):
                    t = batch_start + k
                    log_likelihood = log_probs_batch[k]
                    if t == 0:
                        log_belief = log_likelihood
                    else:
                        log_belief = torch.logsumexp(log_belief.unsqueeze(0) + log_trans, dim=1)
                        log_belief = log_belief + log_likelihood

                    loc_idx = torch.argmax(log_belief).item()
                    y_test_predicted[t] = self.location_bins[loc_idx].cpu()

                    if return_posterior:
                        lb = log_belief - torch.max(log_belief)
                        posterior_probs = torch.exp(lb)
                        posterior_probs /= posterior_probs.sum()
                        posterior_array[t] = posterior_probs.cpu()
            else:
                # --- Vectorized no-smoothing prediction ---
                #TODO: reshape posterior for each frame -- np.flipud(frame)
                max_idx = torch.argmax(log_probs_batch, dim=1)  # (batch,)
                y_test_predicted[batch_start:batch_end] = location_bins[max_idx]

                if return_posterior:
                    posterior_batch = logsumexp_normalize(log_probs_batch)
                    posterior_array[batch_start:batch_end] = posterior_batch

        posterior = posterior_array.cpu().numpy()
        y_predicted = y_test_predicted.cpu().numpy()

        del posterior_array, y_test_predicted, X_test, Xc, log_fact, Xc_exp, log_probs_batch, tuning_all, location_bins, log_tuning, lam, log_lam, prob_dists, log_belief, max_idx, posterior_batch
        gc.collect()
        torch.cuda.empty_cache()

        # print("\n[After cleanup] Tensors still on GPU:")
        for obj in gc.get_objects():
            try:
                if torch.is_tensor(obj) and obj.is_cuda:
                    print(f"Type: {type(obj)}, shape: {obj.shape}, device: {obj.device}")
            except:
                pass

        if return_posterior:
            return y_predicted, posterior, None
        else:
            return y_predicted

class SortedDecoder(object):
    def __init__(self,
                 bin_size=5,
                 states=['continuous', 'fragmented'],
                 movement_var=6,
                 position_var=6,
                 drop_causal_posterior=True,
                 algorithm='spiking_likelihhod_kde_gpu',
                 canonical_to_cm=234,
                 bin_count_threshold=0
                 ):
        self.name = 'SortedDecoder'
        self.bin_size = bin_size
        self.states = states
        self.movement_var = movement_var
        self.position_var = position_var
        self.drop_causal_posterior = drop_causal_posterior
        self.algorithm = algorithm
        self.canonical_to_cm = canonical_to_cm
        self.transitions = get_continuous_transitions(self.movement_var, self.states)
        self.environment = Environment(place_bin_size=bin_size, 
                                       position_range=(-0.05*234, 1.05*234), 
                                       alternate_binning=True,
                                       bin_count_threshold=bin_count_threshold)
        self.classifier = SortedSpikesClassifier(
            environments=[self.environment],
            continuous_transition_types=self.transitions,
            sorted_spikes_algorithm =self.algorithm,
            sorted_spikes_algorithm_params={'position_std': self.position_var})
        self.bins = None
        self.encoding_model = None
        
        
    def fit(self, recording:BinnedRecording):
        assert recording.format == 'spike', f'Must use "spike" formatted spikes for SortedClassifier'
        position = np.vstack([recording.behavior_data.prey_location_x, 
                              recording.behavior_data.prey_location_y]).T
        self.encoding_model = self.classifier.fit(position*self.canonical_to_cm, recording.spike_array)
        self.bins = self.encoding_model.environments[0].edges_[0]

    def predict(self, recording:BinnedRecording, return_posterior=False, batch_size=None):
        assert recording.format == 'spike', f'Must use "spike" formatted spikes for SortedClassifier'
        result = self.encoding_model.predict(spikes=recording.spike_array, time=recording.behavior_data.time_stamp, use_gpu=True)
        post = result.acausal_posterior.sum('state').stack(position=['x_position', 'y_position'])
        #TODO: reshape posterior for each frame -- np.flipud(frame.T)
        state_posterior = result.acausal_posterior.sum('x_position').sum('y_position').values
        y_predicted = post.position[post.argmax('position')]
        y_predicted = np.asarray(y_predicted.values.tolist())
        posterior = {'position': np.asarray(post),
                     'state': state_posterior}
        if return_posterior:
            return y_predicted, posterior
        else:
            return y_predicted
        
class ClusterlessDecoder(object):
    def __init__(self,
                bin_size=5,
                states=['continuous', 'fragmented'],
                movement_var=6,
                mark_variance=24,
                position_variance=6,
                drop_causal_posterior=True,
                algorithm='multiunit_likelihood_gpu',
                canonical_to_cm=234,
                bin_count_threshold=0,
                dilate=False,
                connectivity=1,
                mask_obstacles=False,
                infer_track_interior=True,
                environment_name='',
                ):
        self.name = 'ClusterlessDecoder'
        self.bin_size = bin_size
        self.states = states
        self.movement_var = movement_var
        self.mark_variance = mark_variance
        self.position_variance = position_variance
        self.drop_causal_posterior = drop_causal_posterior
        self.algorithm = algorithm
        self.canonical_to_cm = canonical_to_cm
        self.bin_count_threshold = bin_count_threshold
        self.dilate = dilate
        self.connectivity = connectivity
        self.mask_obstacles = mask_obstacles
        self.infer_track_interior = infer_track_interior
        self.environment_name = environment_name
        self.transitions = get_continuous_transitions(self.movement_var, self.states, environment_name=environment_name)
        self.environment = Environment(environment_name=environment_name,
                                       place_bin_size=bin_size, 
                                       position_range=(-0.075*234, 1.05*234), 
                                       alternate_binning=True,
                                       bin_count_threshold=bin_count_threshold,
                                       dilate=dilate,
                                       connectivity=connectivity,
                                       mask_obstacles=mask_obstacles,
                                       infer_track_interior=infer_track_interior)
        self.classifier = ClusterlessClassifier(
            environments=[self.environment],
            continuous_transition_types=self.transitions,
            clusterless_algorithm=self.algorithm,
            clusterless_algorithm_params={
                'mark_std': mark_variance, 
                'position_std': position_variance,
                'use_diffusion': False})
        self.bins = None
        self.encoding_model = None
        
    def fit(self, recording:BinnedRecording):
        assert recording.format == 'mua', f'Must use "mua" formatted spikes for ClusterlessClassifier'
        position = np.vstack([recording.behavior_data.prey_location_x, 
                              recording.behavior_data.prey_location_y]).T
        self.encoding_model = self.classifier.fit(position*self.canonical_to_cm, recording.spike_array)
        self.bins = self.encoding_model.environments[0].edges_[0]
        # self.encoding_model.environments[0].plot_grid()
        # plt.plot(position[:,0]*self.canonical_to_cm, position[:,1]*self.canonical_to_cm, 'r')
        # plt.show()

    def predict(self, recording:BinnedRecording, return_posterior=False, batch_size=None):
        assert recording.format == 'mua', f'Must use "mua" formatted spikes for ClusterlessClassifier'
        result = self.encoding_model.predict(multiunits=recording.spike_array, time=recording.behavior_data.time_stamp, use_gpu=True)
        post = result.acausal_posterior.sum('state').stack(position=['x_position', 'y_position'])
        #TODO: reshape posterior for each frame -- np.flipud(frame.T)
        state_posterior = result.acausal_posterior.sum('x_position').sum('y_position').values
        y_predicted = post.position[post.argmax('position')]
        y_predicted = np.asarray(y_predicted.values.tolist())
        posterior = {'position': np.asarray(post),
                     'state': state_posterior}
        if return_posterior:
            return y_predicted, posterior
        else:
            return y_predicted

        
            
class Decoder(object):
    def __init__(self, 
                 recording:BinnedRecording, 
                 model,
                 dt=None, 
                 window=None,
                 cv_folds=5,
                 batch_size=100):
        self.recording = recording
        self.recording_ops = recording.get_ops()
        self.model = model
        self.dt = dt
        if dt is None:
            self.dt = recording.dt
        self.window = window
        if window is None:
            self.window = recording.window
        self.window = window
        self.batch_size = batch_size
        self.cv_folds = cv_folds
        self.prediction = None
        self.posterior = None

    def train(self, train_index=None):
        # train
        if train_index is None:
            train_index = np.arange(0,len(self.recording.behavior_data))
        train_index = np.asarray(train_index)
        self.model.fit(self.recording[train_index])

    def test(self, test_index=None):
        # test
        if test_index is None:
            test_index = np.arange(0,len(self.recording.behavior_data))
        test_index = np.asarray(test_index)
        prediction, posterior = self.model.predict(self.recording[test_index], 
                                                   batch_size=self.batch_size, 
                                                   return_posterior=True)
        return prediction, posterior
    
    def train_test(self, train_index=None, test_index=None, n_splits=5,
                   results_path=None, overwrite=False, discard_recording=True):
        assert self.recording is not None

        # set up folder
        self.results_path = os.path.abspath(results_path) if results_path is not None else None
        if results_path is not None:
            os.makedirs(results_path, exist_ok=overwrite)
        
        # set up training and testing
        if train_index is None:
            train_index = np.zeros(len(self.recording.behavior_data)) == 0
        if test_index is None:
            if type(n_splits) == int:
                self.cv_folds = n_splits
            self.cv_runs = get_cv_folds(len(self.recording), n_folds=self.cv_folds, return_boolean=True)
        for run in self.cv_runs:
            run['train'] = train_index

        # train
        t0 = time.time()
        print(f'\t{time.time()-t0:0.2f} training...')
        self.train(train_index = train_index)

        # save trained model
        if results_path is not None:
            self.save(os.path.join(results_path, 'decoder.pkl'), discard_recording=discard_recording)

        # iterative testing
        prediction = []
        for i,run in enumerate(self.cv_runs):
            print('TEST SPLIT', i)

            # test
            print(f'\t{time.time()-t0:0.2f} testing...')
            pred, posterior = self.test(test_index = run['test'])
            prediction.append(pred)

            # save
            if results_path is not None:
                print(f'\t{time.time()-t0:0.2f} saving...')
                fn = os.path.join(results_path, f'cv_run_{i}_posterior.npz')
                np.savez(fn, **posterior)
        
        # save/return prediction
        prediction = np.vstack(prediction) 
        if results_path is not None:
            fn = os.path.join(results_path, 'cv_prediction.npy')
            np.save(fn, prediction)
        print(f'\t{time.time()-t0:0.2f} seconds total.')
        return prediction
        

    def cross_validate(self, results_path=None, overwrite=False, n_folds=None, discard_recording=True):
        # setup cross-validation
        if type(n_folds) == int:
            self.cv_folds = n_folds
        self.cv_runs = get_cv_folds(len(self.recording), n_folds=self.cv_folds, return_boolean=True)        
        
        self.results_path = os.path.abspath(results_path) if results_path is not None else None
        if results_path is not None:
            os.makedirs(results_path, exist_ok=overwrite)

        # cross-validate
        prediction = []
        t0 = time.time()
        for i,run in enumerate(self.cv_runs):
            print('CV FOLD', i)

            # train
            print(f'\t{time.time()-t0:0.2f} training...')
            self.train(train_index = run['train'])

            # test
            print(f'\t{time.time()-t0:0.2f} testing...')
            pred, posterior = self.test(test_index = run['test'])
            prediction.append(pred)

            # save
            if results_path is not None:
                print(f'\t{time.time()-t0:0.2f} saving...')
                fn = os.path.join(results_path, f'cv_run_{i}_posterior.npz')
                np.savez(fn, **posterior)

        # save model
        if results_path is not None:
            self.save(os.path.join(results_path, 'decoder.pkl'), discard_recording=discard_recording)
        
        # save/return prediction
        prediction = np.vstack(prediction) 
        if results_path is not None:
            fn = os.path.join(results_path, 'cv_prediction.npy')
            np.save(fn, prediction)
        print(f'\t{time.time()-t0:0.2f} seconds total.')
        return prediction
    
    def copy(self, deep=False):
        if deep:
            return copy.deepcopy(self)
        else:
            return copy.copy(self)
        
    def save(self, fn, discard_recording=True):
        decoder = self.copy(deep=True)
        if discard_recording:
            decoder.recording = None
        with open(fn, 'wb') as f:
            pickle.dump(decoder, f)
        del decoder

    def load_recording(self, ops=None, load_spikes=True):
        if ops is None:
            ops = self.recording_ops
        if self.recording is None:
            self.recording = bin_recording(ops, load_spikes=load_spikes)

    def load_results(self, results_path=None, load_posterior=True):
        if results_path is None:
            results_path = self.results_path
        assert self.results_path is not None, 'No results path specified.'

        self.prediction = np.load(os.path.join(self.results_path, 'cv_prediction.npy'))
        posterior = []
        state = []
        if load_posterior:
            for f in os.listdir(results_path):
                if 'posterior.npz' in f:
                    post = np.load(os.path.join(results_path, f))
                    posterior.append(post['position'])
                    state.append(post['state'])
            self.posterior = np.vstack(posterior)
            self.state = np.vstack(state)

        





## state space classifier helper functions
def get_continuous_transitions(movement_var=6, states=['continuous', 'fragmented'], environment_name=''):
    state_transitions = {'continuous': RandomWalk(movement_var=movement_var, environment_name=environment_name),
                        'fragmented': Uniform(environment_name=environment_name),
                        'stationary': Identity(environment_name=environment_name)}
    if 'continuous' in states and 'fragmented' in states and 'stationary' in states:
        return [
            [state_transitions['continuous'], state_transitions['fragmented'], state_transitions['stationary']],
            [state_transitions['fragmented'], state_transitions['fragmented'], state_transitions['fragmented']],
            [state_transitions['continuous'], state_transitions['fragmented'], state_transitions['stationary']],
            ]
    elif 'continuous' in states and 'fragmented' in states and 'stationary' not in states:
        return [
            [state_transitions['continuous'], state_transitions['fragmented']],
            [state_transitions['fragmented'], state_transitions['fragmented']]
            ]
    elif len(states) == 1:
        return state_transitions[states[0]]
    else:
        raise AssertionError("self.states must be ['continuous', 'fragmented', 'stationary'], ['continuous', 'fragmented'] or ['continuous'], ['fragmented'], or ['stationary']")

## bayesian helper functions
def logsumexp_normalize(log_probs):
    """ Numerically stable exp-normalize of log-probs (2D tensor) """
    log_probs = log_probs - torch.max(log_probs, dim=1, keepdim=True).values
    probs = torch.exp(log_probs)
    return probs / torch.sum(probs, dim=1, keepdim=True)

def log_p_norm(log_p):
    log_p = log_p - torch.max(log_p)  # for numerical stability
    posterior_probs = torch.exp(log_p)
    posterior_probs = posterior_probs / torch.sum(posterior_probs)  # normalize to 1
    return posterior_probs

def get_occupancy(x, y, bins, cutoff, dt):
        occupancy, _, _ = np.histogram2d(x, y, bins)
        occupancy = occupancy / (1 / dt)
        occupancy[occupancy < cutoff] = 0
        return occupancy

#GLM helper function for the NaiveBayesDecoder
def glm_run(Xr, Yr, X_range):

    X2 = sm.add_constant(Xr)

    poiss_model = sm.GLM(Yr, X2, family=sm.families.Poisson())
    try:
        glm_results = poiss_model.fit()
        #glm_results = poiss_model.fit_regularized(alpha=0.1, L1_wt=0) # regularization does not work well here
        Y_range=glm_results.predict(sm.add_constant(X_range))
    except np.linalg.LinAlgError:
        print("\nWARNING: LinAlgError")
        Y_range=np.mean(Yr)*np.ones([X_range.shape[0],1])
    except ValueError:
        print("\nWARNING: ValueError")
        Y_range=np.mean(Yr)*np.ones([X_range.shape[0],1])

    return Y_range


def group_channel_map(channel_map, n=4):
    #TODO test overlapping groups

    # group each block of channels into groups of n electrodes
    channel_blocks = cluster_probe_channels(channel_map)
    channel_groups = np.zeros(channel_blocks.shape)
    block_length = 0
    group_count = 0
    for b in np.unique(channel_blocks):
        for i,j in enumerate(range(0, (channel_blocks==b).sum(), n)):
            ind = block_length + j
            channel_groups[ind:ind+n] = i + group_count
        group_count = group_count + i + 1
        block_length = block_length + (channel_blocks==b).sum()

    # calculate group COM
    group_com = []
    for c in np.unique(channel_groups):
        group_com.append(channel_map[channel_groups==c, 1:].mean(0))
    group_com = np.vstack(group_com)

    # get four closest channels
    group_channels = []
    for i in range(group_com.shape[0]):
        group_channels.append(np.argsort(np.sum((channel_map[:,1:] - group_com[i,:]) ** 2, axis=1) ** 0.5)[0:n])
    group_channels = np.vstack(group_channels)
    return group_channels, group_com

def get_cv_folds(n_samples, n_folds=10, return_boolean=True):
    cv_runs = []
    run_size = int(np.ceil(n_samples / n_folds))
    for i in range(n_folds):
        train_bool = np.zeros(n_samples, dtype=bool)
        train_ind = [i*run_size, 
                    np.min([(i+1)*run_size, n_samples])]
        train_bool[train_ind[0]:train_ind[1]] = True
        if not return_boolean:
            train = np.argwhere(~train_bool)
            test = np.argwhere(train_bool)
        else:
            train = ~train_bool
            test = train_bool
        cv_runs.append({'train':train, 'test':test})
    return cv_runs
