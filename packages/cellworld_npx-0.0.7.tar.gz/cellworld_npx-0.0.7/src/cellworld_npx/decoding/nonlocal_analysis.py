from .decoder import Decoder
from ..plotting import display_oasis_world
from ..lfp import *
from ..utils import get_runs
import matplotlib.colors as colors
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import operator as op
import torch

mpl.rcParams['axes.formatter.useoffset'] = False

def get_decoder_metrics(decoder):
    xy = get_flattened_bins(decoder.model.bins)
    posterior_com, posterior_spread = com_and_spread_stream_torch(
        decoder.posterior,
        xy,
        batch_size=4096,
        device="cuda",
        metric="spread"
    )
    _, posterior_entropy = com_and_spread_stream_torch(
        decoder.posterior,
        xy,
        batch_size=4096,
        device="cuda",
        metric="entropy"
    )
    posterior_com_jump = com_jump_size(posterior_com)
    velocity = decoder.recording.behavior_data.prey_velocity * 234
    locations = np.vstack([decoder.recording.behavior_data.prey_location_x, 
                           decoder.recording.behavior_data.prey_location_y]).T
    decoding_error = np.linalg.norm(decoder.prediction - locations*234, axis=1)
    return pd.DataFrame({
            'time_stamp': decoder.recording.behavior_data.time_stamp,
            'velocity':             velocity,
            'posterior_com_jump':   posterior_com_jump,
            'posterior_spread':     posterior_spread,
            'posterior_entropy':    posterior_entropy,
            'decoding_error':       decoding_error,
            'continuous_state':     decoder.state[:,0],
            'fragmented_state':     decoder.state[:,1]
        })

def get_candidate_events(df, selection_criteria=None, dt=0.002):
    selection_criteria = set_selection_criteria(selection_criteria)
    I = []
    for k in selection_criteria:
        if 'duration' not in k:
            if selection_criteria[k]['use']:
                I.append(selection_criteria[k]['f'](df[k], selection_criteria[k]['cutoff']))
    I = np.all(np.vstack(I), axis=0).squeeze()
    
    # filter for durations
    remote_sequences = np.vstack(get_runs(I, 
                                          min_duration=int(selection_criteria['durations']['min_duration'] / dt),
                                          max_gap=int(selection_criteria['durations']['merge_length'] / dt)))
    candidates = remote_sequences[remote_sequences[:,-1] > int(selection_criteria['durations']['min_length'] / dt), :]
    
    return candidates, selection_criteria, I

def set_selection_criteria(criteria=None):
    defaults = {
        'velocity': {
            'cutoff': 5, # cm/s
            'f': op.lt,
            'limits': [0, 50],
            'use': False,
        },
        'posterior_com_jump': {
            'cutoff': 20, # cm (can be misleading with split posterior)
            'f': op.lt,
            'limits': [0, 234],
            'use': True,
        },
        'posterior_spread': {
            'cutoff': 20, # cm (try 40cm?)
            'f': op.lt,
            'limits': [0, 234],
            'use': True,
        },
        'posterior_entropy': {
            'cutoff': 5, # bits
            'f': op.lt,
            'limits': [0, 10],
            'use': False,
        },
        'decoding_error': {
            'cutoff': 20, # cm
            'f': op.gt,
            'limits': [0, 234],
            'use': True,
        },
        'continuous_state': {
            'cutoff': 0.8, # cm
            'f': op.gt,
            'limits': [0, 1],
            'use': False,
        },
        'durations': {
            'min_length': 0.1, # s
            'merge_length': 0.05, # s
            'min_duration': 0.01, # s (for subevents)
            'use': True,
        }
    }
    if criteria is None:
        return defaults
    else:
        assert isinstance(criteria, dict)
        new_criteria = defaults.copy()
        for k in new_criteria:
            if 'durations' not in k:
                new_criteria[k]['use'] = False
        for k in defaults:
            new_criteria[k] = defaults[k].copy()
            if k in criteria:
                for k2 in defaults[k]:
                    if k2 in criteria[k]:
                        new_criteria[k][k2] = criteria[k][k2]
                        new_criteria[k]['use'] = True
        return new_criteria

def get_flattened_bins(bins):
    centers = 0.5 * (bins[:-1] + bins[1:])
    Xc, Yc = np.meshgrid(centers, centers, indexing="ij")
    x_flat = Xc.ravel(order="C").astype(np.float32)
    y_flat = Yc.ravel(order="C").astype(np.float32)
    return x_flat, y_flat

@torch.no_grad()
def com_and_spread_stream_torch(
    posterior,              # (T,B) array-like OR iterable of (B,) frames
    xy,                     # (x_flat, y_flat) both (B,)
    batch_size=4096,
    device=None,
    metric="spread",        # "spread" or "entropy"
    entropy_base=2,         # 2 -> bits, np.e or None -> nats, other -> log base
    eps=1e-12,              # for entropy numerical stability
):
    """
    Computes center-of-mass (COM) for each frame, and either:
      - spread: sqrt( sum( ((x-com_x)^2 + (y-com_y)^2) * p ) )
      - entropy: Shannon entropy H = -sum(p * log(p))

    Assumes p is already normalized per frame (sum(p)=1).
    """
    if metric not in ("spread", "entropy"):
        raise ValueError(f"metric must be 'spread' or 'entropy', got {metric!r}")

    x_flat, y_flat = xy
    x_flat = np.asarray(x_flat, dtype=np.float32)
    y_flat = np.asarray(y_flat, dtype=np.float32)

    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"

    # Put bins on device once
    x = torch.as_tensor(x_flat, device=device, dtype=torch.float32).view(1, -1)  # (1,B)
    y = torch.as_tensor(y_flat, device=device, dtype=torch.float32).view(1, -1)  # (1,B)

    # Batch iterators
    def iter_batches_from_2d(arr2d):
        T = arr2d.shape[0]
        for i in range(0, T, batch_size):
            yield i, np.asarray(arr2d[i:i+batch_size], dtype=np.float32)

    def iter_batches_from_iter(frames_iter):
        buf = []
        start = 0
        for frame in frames_iter:
            buf.append(np.asarray(frame, dtype=np.float32))
            if len(buf) == batch_size:
                yield start, np.stack(buf, axis=0)
                start += len(buf)
                buf = []
        if buf:
            yield start, np.stack(buf, axis=0)

    if hasattr(posterior, "shape") and len(posterior.shape) == 2:
        batch_iter = iter_batches_from_2d(posterior)
    else:
        batch_iter = iter_batches_from_iter(posterior)

    # For entropy base conversion: log_base(p) = ln(p)/ln(base)
    # So H_base = -sum p*ln(p) / ln(base)
    if metric == "entropy":
        if entropy_base is None or entropy_base == np.e:
            log_div = 1.0
        else:
            log_div = float(np.log(entropy_base))

    com_chunks = []
    metric_chunks = []

    for _, chunk_np in batch_iter:
        p = torch.from_numpy(chunk_np).to(device, non_blocking=True)  # (bs,B)

        # COM (unnormalized, matching your NumPy)
        com_x = (p * x).sum(dim=1, keepdim=True)  # (bs,1)
        com_y = (p * y).sum(dim=1, keepdim=True)  # (bs,1)

        if metric == "spread":
            dx2 = (x - com_x).square()
            dy2 = (y - com_y).square()
            out = torch.sqrt(((dx2 + dy2) * p).sum(dim=1))  # (bs,)
            del dx2, dy2
        else:
            # Shannon entropy: -sum(p * log(p)), with safe handling of p=0
            p_safe = p.clamp_min(eps)
            out = -(p * torch.log(p_safe)).sum(dim=1)  # nats
            if log_div != 1.0:
                out = out / log_div  # convert to requested base

            del p_safe

        com = torch.cat([com_x, com_y], dim=1).cpu().numpy()  # (bs,2)
        out_np = out.cpu().numpy()                            # (bs,)

        com_chunks.append(com)
        metric_chunks.append(out_np)

        # free big tensors promptly
        del p, com_x, com_y, out

    com_all = np.vstack(com_chunks) if com_chunks else np.empty((0, 2), dtype=np.float32)
    metric_all = np.concatenate(metric_chunks) if metric_chunks else np.empty((0,), dtype=np.float32)
    return com_all, metric_all

def com_jump_size(com):
    com = np.vstack([[0., 0.5], com])
    return np.sqrt(np.sum(np.diff(com, axis=0) ** 2, axis=1))

def time_paint_latest(P, thr, use_T_minus_1=True, fill_value=np.nan):
    P = np.asarray(P)
    T = P.shape[0]

    denom = (T - 1) if use_T_minus_1 else T
    denom = max(denom, 1)

    mask = P > thr                         # (T,H,W) bool
    tvals = (np.arange(T, dtype=np.float32) / denom)[:, None, None]  # (T,1,1)

    # Put time value where mask true; else -inf so max ignores it
    painted = np.where(mask, tvals, -np.inf)   # (T,H,W)
    img = painted.max(axis=0)                  # (H,W)

    # bins never above threshold -> fill_value (e.g., NaN for transparency)
    img[~mask.any(axis=0)] = fill_value
    return img

def get_nearby_action(start_index, df, window=10, dt=0.002, subsample=50, velocity_cutoff=5):
    moving = (df.prey_velocity * 234) > velocity_cutoff
    if window > 0:
        nearby = range(start_index, np.min([len(moving), start_index+int(window/dt)]))
    elif window < 0:
        nearby = range(start_index, np.min([len(moving), start_index+int(window/dt)]), -1)
    if moving.iloc[nearby].sum()*dt > 0.1:
        return df.prey_location_x.iloc[nearby[::subsample]], df.prey_location_y.iloc[nearby[::subsample]]
    else:
        return df.prey_location_x.iloc[start_index], df.prey_location_y.iloc[start_index]
    
import numpy as np

def merge_events(events_per_ts, *,
                overlap_frac=0.25,  # overlap / min(lenA,lenB) >= overlap_frac
                max_gap=0,         # also merge if next.start <= cur.end + max_gap + 1
                return_numpy_bool=True):
    """
    events_per_ts: list of arrays
        Each element can be:
          - shape (n,) point indices
          - shape (n,2) intervals [start,end] (inclusive)
    Returns: list of [start, end, source_bool]
        source_bool is length n_ts boolean vector.
    """
    n_ts = len(events_per_ts)
    if n_ts > 63:
        raise ValueError("Bitmask method supports up to 63 time series (can be extended).")

    # --- flatten into (start, end, mask) ---
    S_list, E_list, M_list = [], [], []
    for i, ev in enumerate(events_per_ts):
        ev = np.asarray(ev)
        if ev.size == 0:
            continue

        if ev.ndim == 1:  # point events
            s = ev.astype(np.int64)
            e = s.copy()
        else:             # intervals
            s = ev[:, 0].astype(np.int64)
            e = ev[:, 1].astype(np.int64)
            s, e = np.minimum(s, e), np.maximum(s, e)

        S_list.append(s)
        E_list.append(e)
        M_list.append(np.full(s.shape, (1 << i), dtype=np.uint64))

    if not S_list:
        return []

    S = np.concatenate(S_list)
    E = np.concatenate(E_list)
    M = np.concatenate(M_list)

    # sort by (start, end)
    order = np.lexsort((E, S))
    S, E, M = S[order], E[order], M[order]

    # --- sweep merge ---
    out_s = [int(S[0])]
    out_e = [int(E[0])]
    out_m = [int(M[0])]

    for s, e, m in zip(S[1:], E[1:], M[1:]):
        s = int(s); e = int(e); m = int(m)

        cur_s, cur_e = out_s[-1], out_e[-1]

        # merge if close enough by gap
        if s <= cur_e + max_gap + 1:
            out_e[-1] = max(cur_e, e)
            out_m[-1] |= m
            continue

        # merge if overlap fraction condition holds
        inter = max(0, min(cur_e, e) - max(cur_s, s) + 1)
        if inter > 0:
            len_cur = cur_e - cur_s + 1
            len_new = e - s + 1
            if inter / min(len_cur, len_new) >= overlap_frac:
                out_s[-1] = min(cur_s, s)
                out_e[-1] = max(cur_e, e)
                out_m[-1] |= m
                continue

        out_s.append(s)
        out_e.append(e)
        out_m.append(m)

    # --- convert masks -> boolean vectors ---
    out_m = np.asarray(out_m, dtype=np.uint64)
    bitpos = np.arange(n_ts, dtype=np.uint64)
    source_bool = ((out_m[:, None] >> bitpos) & 1).astype(bool)  # (n_events, n_ts)

    if not return_numpy_bool:
        return [[out_s[i], out_e[i], source_bool[i].tolist()] for i in range(len(out_s))]
    else:
        return [[out_s[i], out_e[i], source_bool[i]] for i in range(len(out_s))]


    


## plotting
def plot_candidate(candidate, decoder, window=10, dt=0.002, p_thresh=0.05, ax=None, background=None):
    df = decoder.recording.behavior_data
    I = range(candidate[0], candidate[1])
    snippet = decoder.posterior[I,:].reshape(len(I),len(decoder.model.bins)-1,len(decoder.model.bins)-1)
    future_x, future_y = get_nearby_action(candidate[0], df, window=window)
    past_x, past_y = get_nearby_action(candidate[0], df, window=-window)

    if ax is None:
        _, ax = plt.subplots(1, 1, figsize=(4, 4))
    extent = np.array([decoder.model.bins[0], decoder.model.bins[-1], 
                       decoder.model.bins[0], decoder.model.bins[-1]]) / 234
    if background is None:
        display_oasis_world(decoder.recording.recording.experiments[0], ax=ax);
    else:
        ax.imshow(background['image'], extent=background['extent'], zorder=-7)
        plt.axis('off')
    ax.imshow(np.rot90(time_paint_latest(snippet, p_thresh)), cmap='cool', extent=extent, zorder=-7);
    ax.plot(df.prey_location_x[I[0]], df.prey_location_y[I[0]], 'kx', linewidth=2, ms=5, zorder=10);
    ax.plot(df.predator_location_x[I], df.predator_location_y[I], 'r', linewidth=2, zorder=10);
    ax.plot(future_x, future_y, 'k', ms=0.5, alpha=0.3, color='m');
    ax.plot(past_x, past_y, 'k', ms=0.5, alpha=0.3, color='c');
    ax.text(0.5, 0, f'{candidate[0]*dt:.2f} - {candidate[1]*dt:.2f}s', ha='center')
    return ax

def plot_criteria(index, selection_criteria, ax=None):
    if ax is None:
        _, ax = plt.subplots(1, 1, figsize=(4, 4))
    colors = [plt.get_cmap('tab10')(i % 10) for i in range(len(selection_criteria['measures'].keys()))]
    ax2 = ax.twinx()
    h = []
    for i, measure in enumerate(selection_criteria['measures'].keys()):
        if 'velocity' in measure:
            axis = ax2
            axis.set_ylim(0, 50)
            axis.set_ylabel('Velocity (cm/s)', color=colors[i])
            axis.tick_params(axis="y", colors=colors[i])
            axis.spines["right"].set_color(colors[i])
            for s in ["left", "bottom", "top"]:
                axis.spines[s].set_visible(False)
        else:
            axis = ax
            axis.set_ylim(0, 234)
            axis.set_ylabel('Posterior Measures (cm)')
        h.append(
            axis.plot(selection_criteria['times'][index[0]:index[1]],
                      selection_criteria['measures'][measure][index[0]:index[1]],
                      label=measure,
                      color=colors[i])[0]
        )
        line = axis.axhline(selection_criteria['cutoffs'][measure], color=colors[i], lw=1, alpha=0.5)
        line.set_linestyle((i*2, (3,3)))

    ax.legend(
        h, 
        [i.get_label() for i in h],
        loc='upper right',
        fontsize=8,
        markerscale=0.8,
        handlelength=1.2,
        handletextpad=0.4,
        labelspacing=0.3,
        borderpad=0.3,
        frameon=True,
    )
    return ax

def plot_selection_criteria(index, df, selection_criteria, ax=None):
    if ax is None:
        _, ax = plt.subplots(1, 1, figsize=(4, 4))
    colors = [plt.get_cmap('tab10')(i % 10) for i in range(len(selection_criteria.keys()))]

    h = []
    for i,k in enumerate(selection_criteria):
        if selection_criteria[k]['use'] & ('durations' not in k):
            h.append(
                        ax.plot(df.time_stamp[index[0]:index[1]],
                                df[k][index[0]:index[1]],
                                label=k,
                                color=colors[i])[0]
                    )
            line = ax.axhline(selection_criteria[k]['cutoff'], color=colors[i], lw=1, alpha=0.5)
            line.set_linestyle((i*2, (3,3)))

    ax.legend(
        h, 
        [i.get_label() for i in h],
        loc='upper right',
        fontsize=8,
        markerscale=0.8,
        handlelength=1.2,
        handletextpad=0.4,
        labelspacing=0.3,
        borderpad=0.3,
        frameon=True,
    )
    return ax

def plot_mua(decoder, times=None, ax=None):
    if ax is None:
        _,ax = plt.subplots(1, 1, figsize=(4, 4))
    time_index = (decoder.recording.behavior_data.time_stamp > times[0]) & (decoder.recording.behavior_data.time_stamp < times[1])
    time = decoder.recording.behavior_data.time_stamp[time_index].values
    if times is None:
        multiunit_spikes = np.any(~np.isnan(decoder.recording.spike_array), axis=1)
        spike_time_ind, neuron_ind = np.nonzero(multiunit_spikes)
    else:
        multiunit_spikes = np.any(~np.isnan(decoder.recording.spike_array[time_index,:,:]), axis=1)
        spike_time_ind, neuron_ind = np.nonzero(multiunit_spikes)
    plt.scatter(time[spike_time_ind], decoder.recording.mua_groups[neuron_ind], color='k', s=1)
    ax.set_yticks((0, multiunit_spikes.shape[1]))
    ax.set_ylabel('Channel Group Index')
    return ax

def plot_event(
        index, 
        decoder, 
        decimated_signals, 
        mean_spike_count=0, 
        std_spike_count=1, 
        background=None, 
        title=None,
        selection_criteria=None,
        df=None,
        pad=0.05,
        ):
    i0, i1 = index
    ts = decoder.recording.behavior_data.time_stamp
    c0, c1 = (ts.iloc[i0], ts.iloc[i1])
    times = [ts[i0] - pad, ts[i1] + pad]
    time_index = (ts > times[0]) & (ts < times[-1])
    time = 't_corrected'

    fig = plt.figure(1, figsize=(5,15)); fig.clf()
    gs = fig.add_gridspec(
        nrows=7, ncols=1,
        height_ratios=[2, 1.5, 2, 2, 1.5, 0.5, 0.5],  # <-- adjust these
        hspace=0.1                    # vertical spacing
    )
    ax = fig.add_subplot(gs[0,0])
    plot_candidate((i0, i1), decoder, ax=ax, background=background)
    if title is None:
        title = decoder.recording.recording.experiment_name
    ax.set_title(title, y=0.92)

    # if selection_criteria is not None:
    #     ax = fig.add_subplot(gs[1,0])
    #     ind = np.where(time_index)[0]
    #     plot_criteria((ind[0], ind[-1]), selection_criteria, ax=ax)
    #     for s in ["bottom", "top"]:
    #         ax.spines[s].set_visible(False)
    #     ax.axvline(c0, color="r", linestyle='--', lw=1)
    #     ax.axvline(c1, color="r", linestyle='--', lw=1) 
    #     ax.set_xticks([])
    #     ax.set_xlim(times)
    #     ax.hlines([10, 30, 40, 50], times[0], times[1], color='k', alpha=0.25, lw=0.5)

    if selection_criteria is not None:
        assert df is not None
        ax = fig.add_subplot(gs[1,0])
        ind = np.where(time_index)[0]
        plot_selection_criteria((ind[0], ind[-1]), df, selection_criteria, ax=ax)
        for s in ["bottom", "top"]:
            ax.spines[s].set_visible(False)
        ax.axvline(c0, color="r", linestyle='--', lw=1)
        ax.axvline(c1, color="r", linestyle='--', lw=1) 
        ax.set_xticks([])
        ax.set_xlim(times)

    for i,probe in enumerate(decimated_signals):
        ax = fig.add_subplot(gs[2+i,0])
        plot_lfp(decimated_signals[probe]['x'], 
                times=times, 
                sample_times=decimated_signals[probe][time], 
                scale=500, color='k', ax=ax, alpha=0.25)
        ax.set_title(probe)
        ax.set_xlim(times)
        ax.axis('off')
        ax.axvline(c0, color="r", linestyle='--', lw=1)
        ax.axvline(c1, color="r", linestyle='--', lw=1)
        ax.invert_yaxis()

    ax = fig.add_subplot(gs[4,0])
    plot_mua(decoder, times=times, ax=ax)
    for s in ["right", "bottom", "top"]:
        ax.spines[s].set_visible(False)
    ax.set_xticks([])
    ax.axhline(96.5, color='k', linestyle='--', lw=1)
    ax.axvline(c0, color="r", linestyle='--', lw=1)
    ax.axvline(c1, color="r", linestyle='--', lw=1)
    ax.set_xlim(times)
    ax.set_ylim(-1, 96*2+1)
    ax.invert_yaxis()

    ax = fig.add_subplot(gs[5,0])
    for p in decimated_signals:
        I = (decimated_signals[p][time] > times[0]) & (decimated_signals[p][time] < times[1])
        t = decimated_signals[p][time][I]
        y = np.abs(decimated_signals[p]['x'][:,I]).sum(axis=0)
        y = (y - decimated_signals[p]['mean']) / decimated_signals[p]['std']
        ax.plot(t, y, label=p.split('.')[-1], lw=1)
    spike_count = np.any(~np.isnan(decoder.recording.spike_array[time_index,:,:]), axis=1).sum(axis=1)
    ax.plot(ts[time_index], (spike_count-mean_spike_count) / std_spike_count, 'k', label='MUA')
    ax.legend(
        loc='upper right',
        fontsize=8,
        markerscale=0.8,
        handlelength=1.2,
        handletextpad=0.4,
        labelspacing=0.3,
        borderpad=0.3,
        frameon=True
    )
    for s in ["right", "bottom", "top"]:
        ax.spines[s].set_visible(False)
    ax.axvline(c0, color="r", linestyle='--', lw=1)
    ax.axvline(c1, color="r", linestyle='--', lw=1)
    ax.set_xticks([])
    ax.set_ylabel('Total Signal (z)')
    ax.set_xlim(times)

    ax = fig.add_subplot(gs[6,0])
    ax.set_xlim(times)
    ax.set_ylim(0, 1)
    ax.set_yticks([])
    ax.set_xlabel("Time (s)")
    for s in ["left", "right", "top"]:
        ax.spines[s].set_visible(False)
    t0, t1 = times
    x0 = (c0 - t0) / (t1 - t0)
    w  = (c1 - c0) / (t1 - t0)
    x0 = np.clip(x0, 0, 1)
    w  = np.clip(w, 0, 1 - x0)
    cax = inset_axes(
        ax,
        width="100%", height="45%",
        loc="lower left",
        bbox_to_anchor=(x0, 0.5, w, 0.25),   # (x, y, w, h) in ax-fraction units
        bbox_transform=ax.transAxes,
        borderpad=0
    )
    sm = plt.cm.ScalarMappable(cmap="cool", norm=colors.Normalize(vmin=c0, vmax=c1))
    sm.set_array([])
    cbar = fig.colorbar(sm, cax=cax, orientation="horizontal")
    cbar.ax.tick_params(length=2, pad=1)
    cbar.set_ticks([])
    ax.axvline(c0, color="r", linestyle='--', lw=1)
    ax.axvline(c1, color="r", linestyle='--', lw=1)

    plt.tight_layout()
        
