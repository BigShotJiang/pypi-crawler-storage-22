from matplotlib.colors import ListedColormap
from matplotlib import animation
from moviepy.video.io.bindings import mplfig_to_npimage
from ..plotting import display_oasis_world, get_arena_background
from .decoder import Decoder
import matplotlib.pyplot as plt
import numpy as np

class DecoderVideo(object):
    def __init__(self, decoder:Decoder, cached_background=False, posterior_scale='auto'):
        self.decoder = decoder
        #bins = self.decoder.model.bins
        #self.n_bins = len(bins) - 1
        self.n_bins = int(np.sqrt(self.decoder.posterior.shape[1]))
        scale = 1
        if hasattr(self.decoder.model, 'canonical_to_cm'):
            scale = 234
        r = decoder.model.environment.position_range
        self.background = None
        if cached_background:
            self.background = get_arena_background(decoder.recording.recording.experiments[0])
        if posterior_scale == 'auto':
            self.vmin = 0
            self.vmax = None
        else:
            assert len(posterior_scale) == 2
            self.vmin = posterior_scale[0]
            self.vmax = posterior_scale[1]
        self.extent = [r[0] / scale, r[1] / scale, 
                       r[0] / scale, r[1] / scale]

    def plot_frame(self, f=0, dpi=300, res=[720, 720], scale=234): 
        fig = plt.figure(999, figsize=(res[0]/dpi, res[1]/dpi))
        fig.clf()
        ax = fig.add_subplot(1,1,1)
        ax.set_axis_off()
        if self.background is None:
            display_oasis_world(self.decoder.recording.recording.experiments[0], 
                                self.decoder.recording.recording.world, 
                                fig=fig, 
                                ax=ax);
        else:
            ax.imshow(self.background['image'], 
                      extent=[i * scale for i in self.background['extent']], 
                      zorder=-8)
        info = self.decoder.recording.recording.experiment_info
        title = f'{info["mouse"]}: {info["suffix"]}\n{info["date"]}_{info["time"]}'
        ax.set_title(title, fontsize=10, y=0.89)
        cmap = get_cmap("Blues")
        post = self.decoder.posterior[f].reshape(self.n_bins, self.n_bins)
        if 'Sorted' in self.decoder.model.name or 'Clusterless' in self.decoder.model.name:
            post = np.flipud(post.T) #np.fliplr(np.rot90(post))
        else:
            post = np.flipud(post)
        handles = []
        vmin = self.vmin
        vmax = self.vmax
        if vmax is None:
            vmax = np.nanmax(post)
        h = ax.imshow(post, cmap=cmap, extent=self.extent, zorder=-7, 
                    vmin=vmin, vmax=vmax);
        handles.append(h)
        h, = ax.plot(self.decoder.recording.behavior_data.prey_location_x[f], 
                     self.decoder.recording.behavior_data.prey_location_y[f], 'co', 
                    markeredgecolor='k', zorder=10, markersize=3, label='mouse');
        handles.append(h)
        h, = ax.plot(self.decoder.recording.behavior_data.predator_location_x[f], 
                     self.decoder.recording.behavior_data.predator_location_y[f], 'mo', 
                    markeredgecolor='k', zorder=10, markersize=3, label='robot');
        handles.append(h)
        h = ax.text(0.5, 0.01, f'{self.decoder.recording.behavior_data.time_stamp[f]:0.3f} s', 
                    color='k', horizontalalignment='center');
        handles.append(h)
        h, = ax.plot(self.decoder.prediction[f, 0], self.decoder.prediction[f, 1], 'r.', 
                     markersize=1, zorder=10, alpha=1)
        handles.append(h)
        ax.legend(bbox_to_anchor=(0.8, 0.9), loc='upper left', 
                  fontsize=8, handletextpad=0.0, borderpad=0.1, labelspacing=0.1, handlelength=1);
        return handles, fig, ax

    def update_frame(self, f, h, scale=234, return_image=False):
        post = self.decoder.posterior[f].reshape(self.n_bins, self.n_bins)
        if 'Sorted' in self.decoder.model.name or 'Clusterless' in self.decoder.model.name:
            post = np.flipud(post.T) #np.fliplr(np.rot90(post))
        else:
            post = np.flipud(post)
        vmin = self.vmin
        vmax = self.vmax
        if vmax is None:
            vmax = np.nanmax(post)
        h[0].set_data(post)
        h[0].set_clim(vmin=vmin, vmax=vmax)
        h[1].set_xdata([self.decoder.recording.behavior_data.prey_location_x[f]])
        h[1].set_ydata([self.decoder.recording.behavior_data.prey_location_y[f]])
        h[2].set_xdata([self.decoder.recording.behavior_data.predator_location_x[f]])
        h[2].set_ydata([self.decoder.recording.behavior_data.predator_location_y[f]])
        h[3].set_text(f'{self.decoder.recording.behavior_data.time_stamp[f]:0.3f} s')
        h[4].set_xdata([self.decoder.prediction[f, 0]/scale])
        h[4].set_ydata([self.decoder.prediction[f, 1]/scale])
        if return_image:
            return mplfig_to_npimage(h[0].figure)
        else:
            return h
        
    def animate(self, window, frames=None, downsample=10, repeat=False):
        interval = int(self.decoder.dt * 1000)
        if frames is None:
            time = self.decoder.recording.behavior_data.time_stamp
            time_index = np.argwhere((time > window[0]) & (time < window[1])).squeeze()
            frames = range(time_index[0], time_index[-1])[0::downsample]
        h, fig, _ = self.plot_frame(0)
        anim = animation.FuncAnimation(fig, self.update_frame, fargs=(h,), repeat=repeat,
                                    frames=frames, interval=interval*downsample, blit=False)
        return anim
    
    def write(self, window, fn=None, downsample=10, slowdown=10, dpi=100, format='mp4'):
        fps = 1 / (self.decoder.dt * downsample)
        a = self.animate(window, downsample=downsample)
        writer = animation.writers['ffmpeg'](fps=fps/slowdown)
        if fn is None:
            fn = f'./decoding_frames_{downsample}subsamp_{slowdown}xslowdown_{window[0]:0.2f}-{window[-1]:0.2f}s.{format}'
        a.save(fn, writer=writer, dpi=dpi)

def get_cmap(name="Blues"):
    cmap_og = plt.get_cmap(name)
    rgba_lin = cmap_og(np.arange(cmap_og.N))
    rgba_lin[:,-1] = np.linspace(0, 1, cmap_og.N)
    return ListedColormap(rgba_lin)