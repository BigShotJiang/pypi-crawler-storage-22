import numpy as np
from datetime import datetime
from datetime import datetime, timedelta
from collections import defaultdict
from glob import glob
from kilosort import run_kilosort
from time import sleep
from .probe import create_kilosort_probe
import re
import os


def find_file(folder, fstr, joined=False):
    for root,dirs,files in os.walk(folder):
        files = [f for f in files if fstr in f]
        if len(files) > 0:
            if joined:
                return [os.sep.join([root, f]) for f in files]
            else:
                return root, files
        
def find_files(folder, filestr, foldstr='', strict=False, joined=False):
    """
    Lists files containing "fstr" in directory "folder". Optionally filter folders containing "foldstr".
    """
    d = []
    for root,dirs,files in os.walk(folder):
        if strict:
            file = [f for f in files if f == filestr]
        else:
            file = [f for f in files if filestr in f]            
        if (len(file) > 0) & (foldstr in root):
            if joined:
                d.extend([os.sep.join([root, f]) for f in file])
            else:
                d.append({'root': root, 'files': file})
    return d

def find_folders(root, foldstr, strict=False):
    d = []
    for root,dirs,files in os.walk(root):
        if strict:
            folders = [os.sep.join([root,f]) for f in dirs if os.sep.join([root,f]) == foldstr]
        else:
            folders = [os.sep.join([root,f]) for f in dirs if foldstr in os.sep.join([root,f])]            
        d.extend([f for f in folders])
    return d


def split_path(path):
    path = os.path.normpath(path)
    parts = path.split(os.sep)
    return parts

def walk_back(path, x:str):
    parts = split_path(path)
    i = [i for i in range(len(parts)) if x in parts[i]]
    assert len(i) == 1, f'multiple parent directories containing {x} found'
    return os.sep.join(parts[0:i[0]+1])

def match_date(dates, date, threshold=5*60):
    dt = np.abs(np.array([(date - t).total_seconds() for t in dates]))
    if any(dt < threshold):
        return np.argmin(dt)
    
def get_settings_file(dp):
    settings_file = None
    root = walk_back(dp, 'Record Node')
    settings_file = find_file(root, 'settings.xml', joined=True)
    if len(settings_file) > 0:
        return settings_file[0]
    else:
        raise IOError(f'No settings.xml file in {dp}')

def get_session_folders(sess_path=str):
    spk_path,_ = find_file(sess_path, 'cluster_group')
    beh_path,_ = find_file(sess_path, 'experiment.json')

    assert len(beh_path) > 0, f'No behavioral data found in {sess_path}'
    assert len(spk_path) > 0, f'No curated spike data found in {sess_path}'

    return spk_path, beh_path

def get_session_paths(sess_path=str):
    spk_path = find_files(sess_path, 'cluster_group')
    beh_path = find_files(sess_path, 'experiment.json')

    assert len(beh_path) > 0, f'No behavioral data found in {sess_path}'
    assert len(spk_path) > 0, f'No curated spike data found in {sess_path}'

    spk_paths = [f['root'] for f in spk_path]
    beh_paths = [f['root'] for f in beh_path]

    return spk_paths, beh_paths

def match_experiment_date(target_experiment, path_list=list, delta_t=3600):
    if type(target_experiment) != datetime:
        target_date = get_experiment_datetime(target_experiment)
    else:
        target_date = target_experiment
    dates = [get_experiment_datetime(p) for p in path_list]
    time_delta = [(d - target_date).total_seconds() for d in dates]
    candidate_experiments = [p for i,p in enumerate(path_list) if (np.abs(time_delta[i]) < delta_t)]
    return candidate_experiments

def get_experiment_datetime(experiment=str):
    if '\\\\' in experiment:
        experiment = experiment.split('\\\\')[-1]
    if '\\' in experiment:
        experiment = experiment.split('\\')[-1]
    return datetime.strptime('_'.join(experiment.split('_')[1:3]), '%Y%m%d_%H%M')

def get_mouse_files(spike_folder, behavior_database=str):
    parts = spike_folder.split(os.sep)
    path_list = os.listdir(behavior_database)
    for part in parts:
        matches = [p for p in path_list if part in p and not os.path.isfile(os.path.join(behavior_database,p))]
        if len(matches) > 1:
            return matches, part

def match_session_paths(spike_folder=str, behavior_database='D:\\behavior', sort=False, pre=-5, post=60):
    spk_path = find_files(spike_folder, 'cluster_group')
    if (len(spk_path) == 0) & sort:
        binary_files = find_files(spike_folder, 'continuous.dat', 'Neuropix-PXI')
        assert len(binary_files) > 0, f'No binary data found in {spike_folder}'
        for file in binary_files:
            print(f"\nRUNNING KILOSORT FOR {os.path.split(file['root'])[-1]}... this may take some time!")
            sleep(1)
            run_ks(file['root'], file['root'])
        spk_path = find_files(spike_folder, 'cluster_group')
    if len(spk_path) == 0:
        print(f'Warning: No curated spike data found in {spike_folder}, run kilosort.')
        spk_path = find_files(spike_folder, 'structure')

    # get behavioral sessions close to current spike session
    spike_date = datetime.strptime(spike_folder.split(os.sep)[-1], '%Y-%m-%d_%H-%M-%S')
    path_list, _ = get_mouse_files(spike_folder, behavior_database)
    behavior_dates = [datetime.strptime('_'.join(p.split('_')[1:3]), '%Y%m%d_%H%M') for p in path_list]
    time_delta = [(b - spike_date).total_seconds() for b in behavior_dates]
    candidate_sessions = [p for i,p in enumerate(path_list) if (time_delta[i] > pre*60) & (time_delta[i] < post*60)]
    # check if any other spike sessions are a better match to the candidates
    spike_files = os.listdir(os.sep.join(spike_folder.split(os.sep)[:-1]))
    spike_files = [s for s in spike_files if 'BAD' not in s and 'bad' not in s and 'Bad' not in s and 'merge' not in s]
    spike_dates = [datetime.strptime(f.split(os.sep)[-1], '%Y-%m-%d_%H-%M-%S') for f in spike_files]
    candidates = [datetime.strptime('_'.join(c.split('_')[1:3]), '%Y%m%d_%H%M') for c in candidate_sessions]

    mn = []
    for c in candidates:
        mn.append(np.min(np.abs([(c - sd).total_seconds() for sd in spike_dates])))
    if len(mn) > 0:
        better_candidates = np.array(mn) < np.min(np.abs(time_delta))
        if any(better_candidates):
            candidate_sessions = [c for i,c in enumerate(candidate_sessions) if not better_candidates[i]]

    spk_paths = [f['root'] for f in spk_path]
    beh_paths = [os.path.join(behavior_database, s) for s in candidate_sessions]
    
    return spk_paths, beh_paths

def get_episode_folders(behavior_path, return_valid=True):
    p = behavior_path

    if type(p) == list:
        folders = []
        episodes = []
        counter = 0
        for path in p:
            tmp = glob(os.path.join(path, 'episode_*'))
            folders.extend(tmp)
            episodes.extend([int(f.split(os.sep)[-1].split('_')[-1]) + counter for f in tmp])
            counter = counter + len(tmp)
    else:
        folders = glob(os.path.join(p, 'episode_*'))
        episodes = [int(f.split(os.sep)[-1].split('_')[-1]) for f in folders]

    if not return_valid:
        episode_is_valid = [1] * len(folders)
        return folders, episodes, episode_is_valid
    
    return get_valid_episodes(folders, episodes)

def get_recording_duration(recording_file, nchan=384, bytes_per_sample=2, ):
    size = os.path.getsize(recording_file)
    return size / (nchan * bytes_per_sample)

def parse_experiment_name(experiment_name=str):
    if experiment_name is not None:
        splitter = experiment_name.split('_')
        experiment_info = {'prefix': splitter[0], 
                            'date': splitter[1], 
                            'time': splitter[2],
                            'mouse': splitter[3],
                            'world': '_'.join(splitter[4:-1]),
                            'suffix': splitter[-1]}
        return experiment_info

def get_valid_episodes(folders=list(), episodes=list()):
    valid_folders = []
    valid_episodes = []
    episode_is_valid = []
    sync_data_present = []
    for i,f in enumerate(folders):
        episode_file = glob(os.path.join(f, '*episode*.json'))
        sync_file = glob(os.path.join(f, '*sync*.json'))
        if (len(episode_file) > 0) & (len(sync_file) > 0):
            valid_folders.append(f)
            valid_episodes.append(episodes[i])
            episode_is_valid.append(1)
        else:
            episode_is_valid.append(0)
        if (len(sync_file) > 0):
            sync_data_present.append(1)
    return valid_folders, valid_episodes, episode_is_valid, sync_data_present

def run_ks(data_dir, results_dir=None, probe=None):
    if results_dir is None:
        results_dir = os.path.join(data_dir, '..', '..')
    if probe is None:
        root = os.path.join(data_dir, '..', '..', '..', '..')
        xml = [os.path.join(root, f) for f in os.listdir(root) if 'settings.xml' in f]
        assert len(xml) > 0, f'No settings.xml file found in {root}, must provide probe object to use for sorting!'
        probe = create_kilosort_probe(xml[0])

    settings = {'data_dir': data_dir, 'results_dir': results_dir, 'n_chan_bin':probe['n_chan']}
    ops, st, clu, tF, Wall, similar_templates, is_ref, est_contam_rate, kept_spikes = \
        run_kilosort(settings=settings, probe=probe)
    

def parse_datetime_from_string(s, pattern=r'\d{8}_\d{4}', dt_format='%Y%m%d_%H%M'):
    match = re.search(pattern, s)
    if match:
        return datetime.strptime(match.group(), dt_format)
    return None

def parse_datetime_and_suffix(s, pattern=r'\d{8}_\d{4}', dt_format='%Y%m%d_%H%M'):
    match = re.search(pattern, s)
    if match:
        dt_str = match.group()
        dt = datetime.strptime(dt_str, dt_format)
        suffix = s[match.end():]  # everything after the date
        return dt, suffix
    return None, None

def group_experiments(strings, threshold_minutes=15,
                      pattern=r'\d{8}_\d{4}', dt_format='%Y%m%d_%H%M'):
    """
    Groups strings if they are within a time threshold and have the same suffix.
    
    Parameters:
        strings (list): List of strings with datetime info.
        threshold_minutes (int): Threshold in minutes to group by.
        pattern (str): Regex pattern to extract datetime.
        dt_format (str): Datetime format for parsing.
    
    Returns:
        list of lists: Groups of strings.
    """
    parsed = []
    for s in strings:
        dt, suffix = parse_datetime_and_suffix(s, pattern, dt_format)
        if dt is not None:
            parsed.append((s, dt, suffix))

    # Group by suffix
    suffix_groups = defaultdict(list)
    for item in parsed:
        suffix_groups[item[2]].append((item[0], item[1]))  # key: suffix

    # Now group each suffix group by time
    final_groups = []
    for suffix, items in suffix_groups.items():
        items.sort(key=lambda x: x[1])  # sort by datetime
        current_group = []

        for s, dt in items:
            if not current_group:
                current_group.append((s, dt))
            else:
                last_dt = current_group[-1][1]
                if (dt - last_dt) <= timedelta(minutes=threshold_minutes):
                    current_group.append((s, dt))
                else:
                    final_groups.append([x[0] for x in current_group])
                    current_group = [(s, dt)]
        
        if current_group:
            final_groups.append([x[0] for x in current_group])
    
    return final_groups


import os
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Callable, Dict, List, Optional, Sequence, Tuple, Union


# Finds the first YYYYMMDD and HHMM tokens in the name (with underscores or hyphens)
_DATE_TOKEN_RE = re.compile(r"(?P<date>\d{8})")
_TIME_TOKEN_RE = re.compile(r"(?P<time>\d{4})")
_SPIKE_DT_RE = re.compile(r"^(?P<dt>\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})$")

def parse_behavior_info_from_name(name: str) -> Optional[Tuple[datetime, str]]:
    """
    Behavior folder names look like:
      PREFIX_YYYYMMDD_HHMM_MOUSEID_...

    Mouse IDs can vary, but are ALWAYS the token immediately after the HHMM token.

    Returns (dt, mouse_id) or None if parsing fails.
    """
    # split on underscores (your examples use underscores)
    parts = name.split("_")
    if len(parts) < 4:
        return None

    # Find first occurrence of an 8-digit date token, and ensure the next token is 4-digit time
    date_idx = None
    for i, tok in enumerate(parts):
        if _DATE_TOKEN_RE.fullmatch(tok):
            if i + 1 < len(parts) and _TIME_TOKEN_RE.fullmatch(parts[i + 1]):
                date_idx = i
                break

    if date_idx is None:
        return None

    date_tok = parts[date_idx]
    time_tok = parts[date_idx + 1]
    if date_idx + 2 >= len(parts):
        return None

    mouse_id = parts[date_idx + 2]  # positional guarantee
    dt = datetime.strptime(f"{date_tok}_{time_tok}", "%Y%m%d_%H%M")
    return dt, mouse_id


def parse_spike_datetime_from_path(spike_folder: str) -> Optional[datetime]:
    base = os.path.basename(os.path.normpath(spike_folder))
    m = _SPIKE_DT_RE.match(base)
    if not m:
        return None
    return datetime.strptime(m.group("dt"), "%Y-%m-%d_%H-%M-%S")


def infer_input_type_and_metadata(session_folder: str):
    """
    Returns (input_type, input_dt, mouse_id)
      input_type in {"spike", "behavior"}
    """
    session_folder = os.path.normpath(session_folder)
    base = os.path.basename(session_folder)

    spk_dt = parse_spike_datetime_from_path(session_folder)
    if spk_dt is not None:
        mouse_id = os.path.basename(os.path.dirname(session_folder))
        if not mouse_id:
            raise ValueError(f"Could not infer mouse_id from spike parent: {session_folder}")
        return "spike", spk_dt, mouse_id

    beh = parse_behavior_info_from_name(base)
    if beh is not None:
        beh_dt, mouse_id = beh
        return "behavior", beh_dt, mouse_id

    raise ValueError(
        f"Could not parse input folder as spike or behavior:\n  {session_folder}\n"
        f"Spike folder name must be YYYY-mm-dd_HH-MM-SS\n"
        f"Behavior folder name must contain YYYYMMDD_HHMM and then mouse_id token."
    )



# -----------------------------
# Indexing sessions
# -----------------------------

@dataclass(frozen=True)
class SessionInfo:
    path: str
    dt: datetime


def index_spike_sessions(
    spike_mouse_root: str,
    *,
    exclude_keywords: Sequence[str] = ("BAD", "bad", "Bad", "merge"),
) -> List[SessionInfo]:
    out: List[SessionInfo] = []
    for name in os.listdir(spike_mouse_root):
        if any(k in name for k in exclude_keywords):
            continue
        full = os.path.join(spike_mouse_root, name)
        if not os.path.isdir(full):
            continue
        dt = parse_spike_datetime_from_path(full)
        if dt is None:
            continue
        out.append(SessionInfo(path=full, dt=dt))
    out.sort(key=lambda s: s.dt)
    return out


def index_behavior_sessions(
    behavior_database: str,
    mouse_id: str,
) -> List[SessionInfo]:
    out: List[SessionInfo] = []
    for name in os.listdir(behavior_database):
        full = os.path.join(behavior_database, name)
        if not os.path.isdir(full):
            continue
        info = parse_behavior_info_from_name(name)
        if info is None:
            continue
        dt, mid = info
        if mid != mouse_id:
            continue
        out.append(SessionInfo(path=full, dt=dt))
    out.sort(key=lambda s: s.dt)
    return out


# -----------------------------
# Matching logic (symmetric)
# -----------------------------

def _within_window(dt: datetime, center: datetime, pre_min: float, post_min: float) -> bool:
    ds = (dt - center).total_seconds()
    return (ds > pre_min * 60) and (ds < post_min * 60)

def _prune_candidates_by_best_match(
    *,
    input_session: SessionInfo,
    candidates: List[SessionInfo],
    all_on_input_side: List[SessionInfo],
    ties_ok: bool = True,
) -> List[SessionInfo]:
    """
    Keep candidate iff input_session is the closest session (on the input side)
    to that candidate. This is the symmetric version of:
      "check if any other spike sessions are a better match"

    ties_ok=True keeps candidates where input_session ties for closest.
    """
    if not candidates or not all_on_input_side:
        return candidates

    input_diffs = None  # lazy compute per candidate for ties check

    keep: List[SessionInfo] = []
    for c in candidates:
        diffs = np.array(
            [abs((s.dt - c.dt).total_seconds()) for s in all_on_input_side],
            dtype=float
        )
        best = float(np.min(diffs))
        input_dist = abs((input_session.dt - c.dt).total_seconds())

        if ties_ok:
            if input_dist <= best + 1e-9:
                keep.append(c)
        else:
            if input_dist < best - 1e-9:
                keep.append(c)

    return keep

def _norm_key(p: str) -> str:
    # Windows-safe: normalize slashes and case
    return os.path.normcase(os.path.normpath(p))

def _collect_behavior_matches_for_spike(
    *,
    spike_session: SessionInfo,
    all_beh: List[SessionInfo],
    all_spk: List[SessionInfo],
    pre: float,
    post: float,
    ties_ok: bool = True,
) -> List[SessionInfo]:
    # identical spike->behavior logic
    cand = [b for b in all_beh if _within_window(b.dt, spike_session.dt, pre, post)]
    cand = _prune_candidates_by_best_match(
        input_session=spike_session,
        candidates=cand,
        all_on_input_side=all_spk,
        ties_ok=ties_ok,
    )
    return cand


def _behavior_is_in_matches(
    *,
    behavior_path: str,
    behavior_dt: datetime,
    matches: List[SessionInfo],
    dt_tol_s: float = 30.0,
) -> bool:
    bkey = _norm_key(behavior_path)
    for m in matches:
        if _norm_key(m.path) == bkey:
            return True
        if abs((m.dt - behavior_dt).total_seconds()) <= dt_tol_s:
            return True
    return False



def match_session_paths_symmetric(
    session_folder: str,
    *,
    behavior_database: str = r"D:\behavior",
    spike_db_root: str = r"D:\spikes",
    pre: float = -15,
    post: float = 60,
    sort: bool = False,
    exclude_keywords: Sequence[str] = ("BAD", "bad", "Bad", "merge"),
    ties_ok: bool = True,
    # NEW: when starting from a behavior folder, expand to all behavior sessions
    # that match the matched spike session(s)
    expand_behavior_from_spikes: bool = True,
) -> Tuple[List[str], List[str]]:
    """
    Symmetric session matcher.

    Input:
      - spike session folder:  ...\\<mouse_id>\\YYYY-mm-dd_HH-MM-SS
      - behavior session folder: ...\\PREFIX_YYYYMMDD_HHMM_MOUSEID_...

    Output:
      spk_paths, beh_paths

    Behavior-input expansion:
      If a behavior folder is supplied and expand_behavior_from_spikes=True,
      this returns ALL behavior sessions (same mouse) that match the matched spike session(s),
      not just the supplied folder.
    """
    session_folder = os.path.normpath(session_folder)
    input_type, input_dt, mouse_id = infer_input_type_and_metadata(session_folder)

    # Index both sides
    all_beh = index_behavior_sessions(behavior_database, mouse_id)

    if input_type == "spike":
        spike_mouse_root = os.path.dirname(session_folder)
    else:
        spike_mouse_root = os.path.join(spike_db_root, mouse_id)
        if not os.path.isdir(spike_mouse_root):
            raise ValueError(
                "Could not locate spike mouse folder for behavior input.\n"
                f"Expected: {spike_mouse_root}\n"
                "Pass spike_db_root=... if spikes are elsewhere."
            )

    all_spk = index_spike_sessions(spike_mouse_root, exclude_keywords=exclude_keywords)

    # -----------------------
    # spike -> behavior
    # -----------------------
    if input_type == "spike":
        input_session = SessionInfo(path=session_folder, dt=input_dt)

        # candidates on behavior side
        cand = [b for b in all_beh if _within_window(b.dt, input_dt, pre, post)]
        cand = _prune_candidates_by_best_match(
            input_session=input_session,
            candidates=cand,
            all_on_input_side=all_spk,
            ties_ok=ties_ok,
        )
        beh_paths = [c.path for c in cand]

        # spike outputs (your original behavior)
        if sort:
            # assumes find_files, run_ks, sleep exist in your environment
            spk_path = find_files(session_folder, "cluster_group")
            if (len(spk_path) == 0) and sort:
                binary_files = find_files(session_folder, "continuous.dat", "Neuropix-PXI")
                assert len(binary_files) > 0, f"No binary data found in {session_folder}"
                for f in binary_files:
                    print(f"\nRUNNING KILOSORT FOR {os.path.split(f['root'])[-1]}... this may take some time!")
                    sleep(1)
                    run_ks(f["root"], f["root"])
                spk_path = find_files(session_folder, "cluster_group")

            if len(spk_path) == 0:
                print(f"Warning: No curated spike data found in {session_folder}, run kilosort.")
                spk_path = find_files(session_folder, "structure")

            spk_paths = [f["root"] for f in spk_path]
        else:
            spk_paths = [session_folder]

        return spk_paths, beh_paths

    # -----------------------
    # behavior -> spike (+ expand behavior)
    # -----------------------
    else:
        # behavior input
        input_session = SessionInfo(path=session_folder, dt=input_dt)

        # 1) spike candidates in window around this behavior dt (NO pruning here)
        spk_cand = [s for s in all_spk if _within_window(s.dt, input_dt, pre, post)]

        # 2) keep spikes that "explain" this behavior by spike->behavior matching
        spk_keep: List[SessionInfo] = []
        beh_union: dict[str, SessionInfo] = {}

        for s in spk_cand:
            beh_matches = _collect_behavior_matches_for_spike(
                spike_session=s,
                all_beh=all_beh,
                all_spk=all_spk,
                pre=pre,
                post=post,
                ties_ok=ties_ok,
            )

            # accept spike if its matched behavior set contains the input behavior
            if _behavior_is_in_matches(
                behavior_path=session_folder,
                behavior_dt=input_dt,
                matches=beh_matches,
            ):
                spk_keep.append(s)
                for b in beh_matches:
                    beh_union[b.path] = b

        # 3) fallback: if nothing passed the containment test, don't silently drop everything
        if not spk_keep:
            spk_keep = spk_cand
            for s in spk_keep:
                for b in _collect_behavior_matches_for_spike(
                    spike_session=s,
                    all_beh=all_beh,
                    all_spk=all_spk,
                    pre=pre,
                    post=post,
                    ties_ok=ties_ok,
                ):
                    beh_union[b.path] = b

        spk_paths = [s.path for s in spk_keep]

        # 4) return ALL matching behavior sessions (union), always including the supplied one
        beh_union: dict[str, SessionInfo] = {}

        # when adding matches:
        for b in beh_matches:
            beh_union[_norm_key(b.path)] = b

        # # always include the supplied one (deduped)
        # beh_union.setdefault(_norm_key(session_folder), SessionInfo(path=session_folder, dt=input_dt))

        # when returning:
        beh_paths = [b.path for b in sorted(beh_union.values(), key=lambda x: x.dt)]

        return spk_paths, beh_paths


