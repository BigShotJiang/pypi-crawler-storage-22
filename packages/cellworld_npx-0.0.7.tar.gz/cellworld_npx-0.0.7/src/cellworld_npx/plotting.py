from .probe import get_channel_map, get_probe_sites
from .io import get_settings_file
from cellworld import Display, World, Experiment
import math
import seaborn as sns
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors
from matplotlib import cm
from scipy import stats
from itertools import combinations
from matplotlib.collections import LineCollection
import os

plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['font.family'] = 'sans-serif'

def hist_norm(x, bins=np.linspace(0,50,25), ax=None, **kwargs):
    counts, bins = np.histogram(x, bins=bins)
    counts = counts/np.sum(counts)
    if ax is None:
        ax = plt.gca()
    ax.bar(bins[:-1], counts, width=np.diff(bins), align='edge', **kwargs)


def pie_plot(counts, labels, ax=None, format='count', **kwargs):
    def autopct_format(values):
        def my_format(pct):
            total = sum(values)
            val = int(round(pct*total/100.0))
            return '{v:d}'.format(v=val)
        return my_format
    if format == 'count':
        f = autopct_format(counts)
    else:
        f = '%1.1f%%'
    if ax is None:
        ax = plt.gca()
    ax.pie(counts, 
            labels=labels, 
            autopct=f,
            **kwargs)
    return ax


def swarm_plot(x_center, y_vals, color, marker='o',
               size=6, whisker_width=0.05, max_swarm_width=0.8,
               bw_method="silverman", epsilon=0, ax=None, **kwargs):

    if ax is None:
        _, ax = plt.subplots()

    kde = stats.gaussian_kde(y_vals, bw_method=bw_method)
    dens = kde(y_vals)
    dens /= dens.max()

    offsets = (np.random.rand(len(y_vals)) - 0.5)
    offsets *= max_swarm_width * dens

    ax.scatter(
        x_center + offsets,
        y_vals,
        s=size,
        color=color,
        marker=marker,
        edgecolors='none',
        **kwargs
    )

    # quartiles
    q1, q3 = np.percentile(y_vals, [25, 75])
    median = np.median(y_vals)
    iqr = q3 - q1
    low = np.min(y_vals[y_vals >= q1 - 1.5 * iqr])
    high = np.max(y_vals[y_vals <= q3 + 1.5 * iqr])

    ax.fill_betweenx([q1, q3],
                     x_center - whisker_width,
                     x_center + whisker_width,
                     color=color, alpha=1)

    ax.plot([x_center, x_center], [low, high], color=color, lw=1)

    ax.plot([x_center - whisker_width + epsilon,
             x_center + whisker_width - epsilon],
            [median, median], color='w', lw=1)

    ax.scatter(x_center, np.mean(y_vals), s=8, color='w', zorder=5)

    return ax
        

def kde_beeswarm(
    df, x, y,
    size=6,
    colors=None,
    markers=None,
    x_offset=0,
    bw_method="silverman",
    epsilon=0,
    max_swarm_width=0.8,
    whisker_width=0.05,
    auto_ylim=True,
    density_threshold=0.01,
    ylim_margin=0.05,
    test_type=None,              # e.g. 'parametric', 'nonparametric', 'parametric_paired'
    mc_correction='bonferroni',
    plot_significance=True,
    return_stats=False,
    group_order=None,
    ax=None,
    **kwargs
):
    # ---- determine category order ----
    unique_categories = df[x].dropna().unique()

    if group_order is None:
        # default: sorted unique values
        categories = np.sort(unique_categories)
    else:
        # keep only requested groups that actually exist in the data
        categories = [g for g in group_order if g in unique_categories]

    # nothing to plot
    if len(categories) == 0:
        if ax is None:
            _, ax = plt.subplots(figsize=(5, 4))
        if return_stats:
            return ax, None
        return ax

    # ---- colors / markers ----
    if colors is None:
        colors = plt.rcParams['axes.prop_cycle'].by_key()['color'][:len(categories)]
    else:
        # if a single color is passed, repeat it
        if isinstance(colors, (list, tuple, np.ndarray)):
            if len(colors) == 1:
                colors = list(colors) * len(categories)
            elif len(colors) < len(categories):
                # repeat / cycle if too short
                n_rep = int(np.ceil(len(categories) / len(colors)))
                colors = (list(colors) * n_rep)[:len(categories)]
            else:
                colors = list(colors)[:len(categories)]
        else:
            # single color string
            colors = [colors] * len(categories)

    if markers is None:
        markers = {c: 'o' for c in categories}

    if ax is None:
        _, ax = plt.subplots(figsize=(5, 4))

    data_dict = {}
    all_y_vals = []

    # ---- plotting loop in the specified order ----
    for i, cat in enumerate(categories):
        vals = pd.to_numeric(df[df[x] == cat][y], errors='coerce')
        vals = vals[~np.isnan(vals)]
        if len(vals) == 0:
            continue

        data_dict[cat] = vals
        all_y_vals.append(vals)

        swarm_plot(
            x_center=i + x_offset,
            y_vals=vals,
            color=colors[i],
            marker=markers.get(cat, 'o'),
            size=size,
            whisker_width=whisker_width,
            max_swarm_width=max_swarm_width,
            bw_method=bw_method,
            epsilon=epsilon,
            ax=ax,
            **kwargs
        )

    ax.set_xticks(range(len(categories)))
    ax.set_xticklabels(categories)
    ax.set_xlabel(x)
    ax.set_ylabel(y)

    # ---- auto y-limits by density ----
    if auto_ylim and len(all_y_vals) > 0:
        all_y_vals = np.concatenate(all_y_vals)
        y_min_data = np.min(all_y_vals)
        y_max_data = np.max(all_y_vals)

        if len(all_y_vals) > 1:
            try:
                kde = stats.gaussian_kde(all_y_vals, bw_method=bw_method)
                y_grid = np.linspace(y_min_data, y_max_data, 512)
                dens = kde(y_grid)
                dens /= dens.max()
                mask = dens >= density_threshold
                if np.any(mask):
                    y_min = y_grid[mask].min()
                    y_max = y_grid[mask].max()
                else:
                    y_min, y_max = y_min_data, y_max_data
            except Exception:
                y_min, y_max = y_min_data, y_max_data
        else:
            y_min, y_max = y_min_data, y_max_data

        if y_max == y_min:
            y_min -= 0.5
            y_max += 0.5

        pad = ylim_margin * (y_max - y_min)
        ax.set_ylim(y_min - pad, y_max + pad)

    # ---- statistics ----
    base_type, paired = _parse_test_type(test_type) if test_type is not None else (None, False)
    stats_results = None

    if base_type is not None:
        if paired:
            raise ValueError(
                "Paired tests for kde_beeswarm are not implemented. "
                "Use plot_connected_means with a subject/condition design "
                "for within-subject comparisons."
            )
        stats_results = run_group_stats(
            data_dict,
            test_type=base_type,
            mc_correction=mc_correction
        )

        if plot_significance and stats_results is not None:
            x_positions = {cat: i for i, cat in enumerate(categories)}
            annotate_stats_on_axis(ax, stats_results, x_positions)

    if return_stats:
        return ax, stats_results
    return ax



def plot_connected_means(
    df,
    groups,              # [subject_col, group_col]
    y_col,
    group_order=None,
    subject_markers=None,
    condition_colors=None,
    test_type=None,      # e.g. 'parametric', 'nonparametric_paired'
    mc_correction='bonferroni',
    plot_significance=True,
    return_stats=True,
    ax=None,
    **kwargs
):
    subject_col, group_col = groups

    # compute one mean per subject x condition
    means_df = (
        df.groupby([subject_col, group_col])[y_col]
          .mean()
          .reset_index()
    )

    if group_order is None:
        group_order = list(np.sort(means_df[group_col].unique()))
    else:
        group_order = [g for g in group_order if g in means_df[group_col].unique()]

    group_to_x = {g: i for i, g in enumerate(group_order)}

    if ax is None:
        _, ax = plt.subplots(figsize=(5, 4))

    # colors
    if condition_colors is None:
        prop = plt.rcParams['axes.prop_cycle'].by_key()['color']
        condition_colors = {g: prop[i % len(prop)] for i, g in enumerate(group_order)}
    else:
        # fill missing groups with default colors
        prop = plt.rcParams['axes.prop_cycle'].by_key()['color']
        for i, g in enumerate(group_order):
            if g not in condition_colors:
                condition_colors[g] = prop[i % len(prop)]

    # plot trajectories per subject
    for subject, sub in means_df.groupby(subject_col):
        sub = sub[sub[group_col].isin(group_order)].copy()
        if len(sub) == 0:
            continue

        sub['x'] = sub[group_col].map(group_to_x)
        sub = sub.sort_values('x')

        xs = sub['x'].values
        ys = sub[y_col].values
        conds = sub[group_col].values

        ax.plot(xs, ys, color='0.7', lw=1, alpha=0.7)
        marker = subject_markers.get(subject, 'o') if subject_markers is not None else 'o'
        ax.scatter(xs, ys,
                   c=[condition_colors[c] for c in conds],
                   marker=marker,
                   zorder=3,
                   **kwargs)

    ax.set_xticks(range(len(group_order)))
    ax.set_xticklabels(group_order)
    ax.set_xlabel(group_col)
    ax.set_ylabel(y_col)

    # ---- statistics ----
    base_type, paired = _parse_test_type(test_type) if test_type is not None else (None, False)
    stats_results = None

    if base_type is not None:
        if paired:
            # paired: use subject_col as the pairing index automatically
            stats_results = run_group_stats_paired(
                means_df,
                subject_col=subject_col,
                group_col=group_col,
                y_col=y_col,
                test_type=base_type,
                mc_correction=mc_correction
            )
        else:
            # unpaired: just compare pooled values per condition
            data_dict = {
                g: means_df[means_df[group_col] == g][y_col].dropna().values
                for g in group_order
            }
            stats_results = run_group_stats(
                data_dict,
                test_type=base_type,
                mc_correction=mc_correction
            )

        if plot_significance and stats_results is not None:
            annotate_stats_on_axis(ax, stats_results, group_to_x)

    if return_stats:
        return ax, stats_results
    return ax



def plot_df_over_time(df, x, y, grps, colors=None, markers=None, ax=None, **kwargs):
    if ax is None:
        ax = plt.gca()
    marker = 'o'
    color = None
    for label, group in df.groupby(grps):
        if markers:
            marker = markers[label[0]]
        if colors:
            color = colors[label[1]]
        ax.plot(group[x], group[y], color=color, linestyle='-', lw=1, label=label)
        ax.scatter(group[x], group[y], marker=marker, color=color, **kwargs)
    ax.set_xlabel(x)
    ax.set_ylabel(y)
    return ax

def add_legend(ax, spec_dict, location=(1.0, 1.0), multi=False, **kwargs):
    handles = []
    labels = []
    for label, spec in spec_dict.items():
            handle = ax.plot([], [], spec, **kwargs)
            handles.append(handle[0])
            labels.append(label)
    legend = ax.legend(handles, labels, loc='upper left', bbox_to_anchor=location)
    if multi:
        ax.add_artist(legend)
    return legend

def plot_place_field(row, extent=[-0.05, 1.05, -0.05, 1.05], ax=None, title='', autoscale=False, cmap='jet'):
    if ax is None:
        ax = plt.gca()
    rate_map = row.prey_rate_maps
    masked_array = np.ma.array(rate_map, mask=np.isnan(rate_map))
    cmap = cm.get_cmap(cmap)
    cmap.set_bad('white',1.)
    vmax = None
    if autoscale:
        vmax = np.nanmean(rate_map) + 3 * np.nanstd(rate_map)
    ax.imshow(np.rot90(masked_array), extent=extent, vmin=0, vmax=vmax, cmap=cmap)
    ax.text(0.9, 0, f'{np.nanmax(rate_map):0.1f}\n[{row.prey_spatial_info:0.1f}]', ha='left', va='bottom')
    ax.set_title(title)
    ax.axis('off')

def plot_probe(dp, ax=None, plot_full_probe='', aspect='auto', dx=1200, plot_scale=True, rasterized=True, **kwargs):
    if ax is None:
        _,ax = plt.subplots(1,1,figsize=(5,7))

    #cm = chan_map(dp, y_orig='tip', probe_version='local')
    if plot_full_probe != '':
        if '1' in plot_full_probe:
            offset = 11
        elif '2' in plot_full_probe:
            offset = 8
        else:
            raise ValueError('probe type must be np1/np2')
    x, y, _ = get_probe_sites(type=plot_full_probe, x_offset=offset)
    channel_maps = []
    x_offsets = []
    for i, root in enumerate(dp):
        x_offsets.append((i * dx))
        cm = get_channel_map(get_settings_file(root))
        ax.scatter(x + x_offsets[i], y, 1, 'grey', rasterized=rasterized)
        ax.scatter(cm[:,1] + x_offsets[i], cm[:,2], 1, 'k', rasterized=rasterized, **kwargs)
    mxx = (max(x_offsets) + max(x))
    mnx = min(x_offsets)
    r = mxx - mnx
    ax.set_xlim(mnx - (r/10), mxx + (r/10))
    ax.set_aspect(aspect)
    if plot_scale:
        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        offset_x = r/20
        offset_y = 500
        ax.plot([mnx-offset_x, mnx-offset_x], [mnx-offset_y, 1000], 'k')
        ax.plot([mnx-offset_x, mnx-offset_x + 100], [mnx-offset_y, mnx-offset_y], 'k')

    return channel_maps, x_offsets, ax

def display_oasis_world(e, w=None, ax=None, fig=None, plot_scale=False, show_cell=False):
    def _triangle_points(cell_loc, angle, cell_radius=0.026):
        cell_radius = 0.026
        cell_ori = math.radians(60-angle*60)
        pts = np.array([[cell_loc.x,cell_loc.y],
                        [cell_loc.x+math.cos(cell_ori-math.radians(30))*cell_radius,cell_loc.y+math.sin(cell_ori-math.radians(30))*cell_radius],
                        [cell_loc.x+math.cos(cell_ori+math.radians(30))*cell_radius,cell_loc.y+math.sin(cell_ori+math.radians(30))*cell_radius]])
        return pts

    if ax is None:
        _,ax = plt.subplots(1,1, figsize=(6,6))
    if fig is None:
        fig = ax.get_figure()
    if w is None:
        w = World.get_from_parameters_names('hexagonal', 'canonical', e.occlusions)
    else:
        if type(w) is str:
            w = World.get_from_parameters_names('hexagonal', 'canonical', w)
        else:
            w = w

    reward_locations = e.rewards_cells
    reward_angles = e.rewards_orientations
    reward_cmap = plt.cm.tab20

    d = Display(w, fig_size=(6,6), ax=ax, fig=fig, 
                show_cell=show_cell, habitat_edge_color='k', habitat_zorder=0, habitat_fill=False)
    ax.set_frame_on(False)
    if plot_scale:
        ax.plot([0,0.25/2.34], [0,0], 'k', linewidth=1.5)
        ax.text(0, 0.01, '25 cm')

    for i, cell in enumerate(reward_locations):
       d.cell(cell_id = cell, color='grey')
       pts = _triangle_points(w.cells[cell].location, reward_angles[i], d.cells_size)
       d.ax.add_patch(plt.Polygon(pts, facecolor=reward_cmap(i*2), edgecolor='black'))

    return d, ax

def display_world(w, ax=None, fig=None, show_cell=False):
    if ax is None:
        _,ax = plt.subplots(1,1, figsize=(6,6))
    if fig is None:
        fig = ax.get_figure()
    if type(w) is str:
        w = World.get_from_parameters_names('hexagonal', 'canonical', w)
    d = Display(w, fig_size=(6,6), ax=ax, fig=fig, 
                show_cell=show_cell, habitat_edge_color='k', habitat_zorder=0, habitat_fill=False)
    ax.set_frame_on(False)
    return d, ax

def get_arena_background(experiment, figsize=(4,4), dpi=300, check=False):
    tmp_fig, tmp_ax = plt.subplots(figsize=figsize, dpi=dpi)

    # display in fixed layout
    if type(experiment) is Experiment:
        _, ax = display_oasis_world(experiment, ax=tmp_ax)
    elif type(experiment) is World or type(experiment) is str:
        _, ax = display_world(experiment, ax=tmp_ax)
    ax.set_axis_off()
    ax.set_aspect('equal', adjustable='box')  # important for consistent mapping
    tmp_fig.canvas.draw()

    # get the bounding box and crop to the real axes
    renderer = tmp_fig.canvas.get_renderer()
    bbox = ax.get_window_extent(renderer=renderer)
    x0, y0, x1, y1 = map(int, map(round, bbox.extents))
    rgba = np.asarray(tmp_fig.canvas.buffer_rgba())
    bg_axes = rgba[y0:y1, x0:x1, :]
    xl = ax.get_xlim()
    yl = ax.get_ylim()
    extent = [xl[0], xl[1], yl[0], yl[1]]

    background = {"image": bg_axes, "extent": extent}

    if check:
        ax.imshow(bg_axes, extent=extent, origin="upper", zorder=10, alpha=0.25)  # image is top-left origin
        ax.set_xlim(xl); ax.set_ylim(yl)
        ax.set_aspect('equal', adjustable='box')
        plt.show()
    else:
        plt.close(tmp_fig)

    return background

def plot_color(x, y, c=None, cmap='viridis', linewidth=2, zorder=None, ax=None, Norm=None, alpha=1.0, lighten=1.0, label=None, rasterize=False):

    if c is None:
        c = np.ones(x.shape)

    if Norm is None:
        norm = plt.Normalize(c.min(), c.max())
    else:
        norm = plt.Normalize(Norm[0], Norm[1])

    points = np.array([x, y]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)
    lc = LineCollection(segments, cmap=cmap, norm=norm, capstyle="round")
    lc.set_array(c)
    lc.set_linewidth(linewidth)
    lc.set_zorder(zorder)
    lc.set_alpha(alpha)
    lc.set_rasterized(rasterize)
    if ax:
        line = ax.add_collection(lc)
    else:
        line = plt.gca().add_collection(lc)

    return line

def find_bounding_box(matrix):
    rows, cols = np.where(~np.isnan(matrix))
    if rows.size == 0 or cols.size == 0:
        return None  # All values are NaN
    
    # Bounding box coordinates
    row_min, row_max = rows.min(), rows.max()
    col_min, col_max = cols.min(), cols.max()
    
    return row_min, row_max, col_min, col_max

def plot_signal_with_events(signal, events, time=None, ax=None):
    if time is None:
        time = np.arange(len(signal))
    if events is None:
        events = []

    if ax is None:
        _, ax = plt.subplots(1,1)
    ax.plot(time, signal, label='Signal')

    # Overlay events
    for start, stop, _ in events:
        ax.axvspan(time[start], time[stop-1], color='orange', alpha=0.3)

def plot_place_spikes(x, y, t, st):
    spike_index = np.searchsorted(t[:-1], st)
    plt.plot(x, y, 'k')
    plt.scatter(x[spike_index], y[spike_index], c='r', s=2, zorder=10)





### statistics for plotting
def run_group_stats(data_dict, test_type='parametric', mc_correction='bonferroni'):
    """
    Unpaired tests.

    data_dict : {group_name: 1D array of values}
    test_type : 'parametric' or 'nonparametric'
    """
    if test_type is None:
        return None

    group_names = list(data_dict.keys())
    group_values = [np.asarray(v, float) for v in data_dict.values()]
    group_values = [v[~np.isnan(v)] for v in group_values]

    valid = [(g, v) for g, v in zip(group_names, group_values) if len(v) > 0]
    if len(valid) < 2:
        return None

    group_names = [g for g, _ in valid]
    group_values = [v for _, v in valid]

    stats_results = {
        'test_type': test_type,
        'paired': False,
        'omnibus': None,
        'pairwise': []
    }

    # ---- omnibus ----
    if test_type == 'parametric':
        if len(group_values) == 2:
            res = stats.ttest_ind(group_values[0], group_values[1], equal_var=False)
            stats_results['omnibus'] = {
                'test': 'ttest_ind',
                'groups': group_names,
                'statistic': float(res.statistic),
                'pvalue': float(res.pvalue)
            }
        else:
            res = stats.f_oneway(*group_values)
            stats_results['omnibus'] = {
                'test': 'anova',
                'groups': group_names,
                'statistic': float(res.statistic),
                'pvalue': float(res.pvalue)
            }

    else:  # nonparametric
        if len(group_values) == 2:
            res = stats.mannwhitneyu(group_values[0], group_values[1])
            stats_results['omnibus'] = {
                'test': 'mannwhitneyu',
                'groups': group_names,
                'statistic': float(res.statistic),
                'pvalue': float(res.pvalue)
            }
        else:
            res = stats.kruskal(*group_values)
            stats_results['omnibus'] = {
                'test': 'kruskal',
                'groups': group_names,
                'statistic': float(res.statistic),
                'pvalue': float(res.pvalue)
            }

    # ---- pairwise ----
    pairs = list(combinations(range(len(group_values)), 2))
    pvals = []
    pair_list = []

    for i, j in pairs:
        g1, g2 = group_names[i], group_names[j]
        v1, v2 = group_values[i], group_values[j]

        if test_type == 'parametric':
            res = stats.ttest_ind(v1, v2, equal_var=False)
            test_name = 'ttest_ind'
        else:
            res = stats.mannwhitneyu(v1, v2)
            test_name = 'mannwhitneyu'

        pvals.append(res.pvalue)
        pair_list.append({
            'test': test_name,
            'group1': g1,
            'group2': g2,
            'statistic': float(res.statistic),
            'p_raw': float(res.pvalue),
            'p_corr': None
        })

    pvals = np.asarray(pvals)
    m = len(pvals)

    if mc_correction == 'bonferroni' and m > 0:
        p_corr = np.minimum(pvals * m, 1.0)
    else:
        p_corr = pvals

    for k, p in enumerate(p_corr):
        pair_list[k]['p_corr'] = float(p)

    stats_results['pairwise'] = pair_list
    return stats_results

def run_group_stats_paired(
    df,
    subject_col,
    group_col,
    y_col,
    test_type='parametric',
    mc_correction='bonferroni'
):
    """
    Paired tests using long-form data:

        df[subject_col]  → defines pairs (e.g. mouse/session)
        df[group_col]    → within-subject factor (e.g. condition)
        df[y_col]        → measurement

    We aggregate by (subject, group) using the mean, pivot to wide,
    and then run paired tests (ttest_rel / wilcoxon) between conditions.
    """

    # one value per subject per condition
    wide = (
        df.groupby([subject_col, group_col])[y_col]
          .mean()
          .unstack(group_col)
    )

    group_names = list(wide.columns)
    if len(group_names) < 2:
        return None

    stats_results = {
        'test_type': test_type,
        'paired': True,
        'omnibus': None,
        'pairwise': []
    }

    # ---- Omnibus (nonparametric: Friedman; parametric omitted) ----
    if test_type == 'nonparametric' and len(group_names) >= 3:
        valid = wide.dropna(subset=group_names)
        if valid.shape[0] >= 2:
            res = stats.friedmanchisquare(
                *[valid[g].values for g in group_names]
            )
            stats_results['omnibus'] = {
                'test': 'friedmanchisquare',
                'groups': group_names,
                'statistic': float(res.statistic),
                'pvalue': float(res.pvalue)
            }
    # For parametric repeated-measures ANOVA we leave omnibus as None
    # to avoid giving a misleading test.

    # ---- Pairwise ----
    pairs = list(combinations(range(len(group_names)), 2))
    pvals = []
    pair_list = []

    for i, j in pairs:
        g1, g2 = group_names[i], group_names[j]
        v1 = wide[g1]
        v2 = wide[g2]
        mask = (~v1.isna()) & (~v2.isna())
        v1p = v1[mask].values
        v2p = v2[mask].values

        if len(v1p) < 2:
            continue  # not enough paired observations

        if test_type == 'parametric':
            res = stats.ttest_rel(v1p, v2p)
            test_name = 'ttest_rel'
        else:
            # Wilcoxon signed-rank test
            res = stats.wilcoxon(v1p, v2p, alternative='two-sided')
            test_name = 'wilcoxon'

        pvals.append(res.pvalue)
        pair_list.append({
            'test': test_name,
            'group1': g1,
            'group2': g2,
            'n_pairs': int(len(v1p)),
            'statistic': float(res.statistic),
            'p_raw': float(res.pvalue),
            'p_corr': None
        })

    pvals = np.asarray(pvals)
    m = len(pvals)
    if mc_correction == 'bonferroni' and m > 0:
        p_corr = np.minimum(pvals * m, 1.0)
    else:
        p_corr = pvals

    for k, p in enumerate(p_corr):
        pair_list[k]['p_corr'] = float(p)

    stats_results['pairwise'] = pair_list
    return stats_results


def annotate_stats_on_axis(ax, stats_results, x_positions, plot_alpha=0.05):
    """
    x_positions : dict {group_name: x_value}
    """
    if stats_results is None:
        return ax

    sig_pairs = [
        p for p in stats_results['pairwise']
        if p['p_corr'] < plot_alpha
    ]

    if len(sig_pairs) == 0:
        return ax

    # current limits
    ymin, ymax = ax.get_ylim()
    span = ymax - ymin
    base_y = ymax

    height = 0.02 * span
    spacing = 0.06 * span

    for idx, p in enumerate(sig_pairs):
        x1 = x_positions[p['group1']]
        x2 = x_positions[p['group2']]
        if x1 > x2:
            x1, x2 = x2, x1

        y = base_y + spacing * (idx + 1)

        # bracket
        ax.plot([x1, x1, x2, x2],
                [y, y + height, y + height, y],
                color='k', lw=1)

        # stars
        pc = p['p_corr']
        if pc < 0.001: stars = '***'
        elif pc < 0.01: stars = '**'
        elif pc < 0.05: stars = '*'
        else: stars = 'ns'

        ax.text((x1 + x2) / 2, y + height, stars,
                ha='center', va='bottom')

    ax.set_ylim(ymin, base_y + spacing * (len(sig_pairs) + 2))
    return ax

def _parse_test_type(test_type):
    """
    Parse test_type string.

    Allowed examples:
        None
        'parametric'
        'nonparametric'
        'parametric_paired'
        'nonparametric_paired'
    """
    if test_type is None:
        return None, False

    s = str(test_type).lower()
    paired = 'paired' in s

    if 'nonparametric' in s:
        base_type = 'nonparametric'
    elif 'parametric' in s:
        base_type = 'parametric'
    else:
        raise ValueError(
            "test_type must contain 'parametric' or 'nonparametric', "
            "optionally with '_paired'. Got: {!r}".format(test_type)
        )

    return base_type, paired

