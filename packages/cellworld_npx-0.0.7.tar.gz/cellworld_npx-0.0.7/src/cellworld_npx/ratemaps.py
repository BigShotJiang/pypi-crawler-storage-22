from .binning import BinnedRecording, make_map_bins
import numpy as np
from scipy.ndimage import gaussian_filter
from scipy.stats import pearsonr
from tqdm import tqdm
import torch.nn.functional as F
import torch
import gc
import cv2

import warnings
warnings.filterwarnings("ignore")

class RateMaps(object):
    def __init__(self, 
                recording:BinnedRecording,
                bins = None,
                bin_size=0.1, 
                smooth_sigma=1.0, 
                mask_nans=True,
                occupancy_cutoff=0.0,
                use_torch=True,
                coordinate_label='prey_location'):
        self.recording = recording
        self.bin_size = bin_size
        if bins is None:
            self.bins, _, _ = make_map_bins(self.bin_size)
        else:
            self.bins = bins
        self.smooth_sigma = smooth_sigma
        self.mask_nans = mask_nans
        self.use_torch = use_torch
        self.occupancy_cutoff = occupancy_cutoff
        self.coordinate_label = coordinate_label
        self.occupancy = self.get_occupancy(self.coordinate_label)
        self.rate_maps = self.get_rate_maps(self.coordinate_label)

    def get_occupancy(self, coordinate_label='prey_location'):
        x = self.recording.behavior_data[coordinate_label + '_x'].to_numpy()
        y = self.recording.behavior_data[coordinate_label + '_y'].to_numpy()
        occupancy = get_occupancy(x, y, bins=self.bins, cutoff=self.occupancy_cutoff, dt=self.recording.dt)
        return occupancy

    def run_shuffle_test(self, n_shuffles=500, per_neuron=True, coordinate_label='prey_location', batch_size=200, return_behavior_info=False):
        # get true rate maps
        assert hasattr(self, 'rate_maps'), 'Rate maps must be computed first'
        x, y, spike_counts_all, occupancy, bins = self.prepare_rate_maps_torch(coordinate_label)
        rate_maps_cuda = get_rate_maps_torch(spike_counts_all.T, x, y, bins, bins, occupancy, 
                                        self.smooth_sigma, self.mask_nans)
        true_info_torch = shannon_information_torch(rate_maps_cuda, occupancy)
        true_info = true_info_torch.cpu().numpy()

        # get behavior info if needed and cleanup
        if return_behavior_info:
            behavior_info = {
                'x': x.cpu().numpy(),
                'y': y.cpu().numpy(),
                'spike_counts_all': spike_counts_all.cpu().numpy(),
                'occupancy': occupancy.cpu().numpy(),
                'bins': bins.cpu().numpy()
            }
        del rate_maps_cuda, x, y, spike_counts_all, occupancy, bins, true_info_torch
        gc.collect()
        torch.cuda.empty_cache()

        # get shuffled rate maps
        shuffle_results = self.shuffle_rate_maps_batched_faster(n_shuffles, coordinate_label, per_neuron=per_neuron, return_info=True, batch_size=batch_size)
        shuffled_info = [s.cpu().numpy() for s in shuffle_results]
        shuffled_info = np.array(shuffled_info).T
        del shuffle_results
        gc.collect()
        torch.cuda.empty_cache()

        # calculate results
        p_value = np.sum(shuffled_info.T > np.atleast_2d(true_info), axis=0) / len(shuffled_info[0,:])
        if return_behavior_info:
            return true_info, shuffled_info, p_value, behavior_info
        else:
            return true_info, shuffled_info, p_value
    
    def get_rate_maps(self, coordinate_label='prey_location'):
        if self.use_torch:
            rate_maps = self.get_rate_maps_torch(coordinate_label)
        else:
            rate_maps = self.get_rate_maps_cpu(coordinate_label)
        return rate_maps

    def prepare_rate_maps_torch(self, coordinate_label='prey_location'):
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        x = torch.from_numpy(self.recording.behavior_data[f'{coordinate_label}_x'].to_numpy()).to(device)
        y = torch.from_numpy(self.recording.behavior_data[f'{coordinate_label}_y'].to_numpy()).to(device)
        spike_counts_all = torch.from_numpy(self.recording.spike_array).to(device)  # T x N
        occupancy = torch.from_numpy(self.occupancy).to(device)
        bins = torch.from_numpy(self.bins).to(device)
        return x, y, spike_counts_all, occupancy, bins
    
    def get_rate_maps_torch(self, coordinate_label='prey_location'):
        x, y, spike_counts_all, occupancy, bins = self.prepare_rate_maps_torch(coordinate_label)
        rate_maps_cuda = get_rate_maps_torch(spike_counts_all.T, x, y, bins, bins, occupancy, 
                                        self.smooth_sigma, self.mask_nans)
        rate_maps = [r.cpu().numpy() for r in rate_maps_cuda]
        del rate_maps_cuda, x, y, spike_counts_all, occupancy, bins
        gc.collect()
        torch.cuda.empty_cache()
        return rate_maps

    def get_rate_maps_cpu(self, coordinate_label='prey_location'):
        x = self.recording.behavior_data[coordinate_label + '_x'].to_numpy()
        y = self.recording.behavior_data[coordinate_label + '_y'].to_numpy()
        rate_maps = []
        for i in range(self.recording.spike_array.shape[0]):
            rate_maps.append(get_rate_map_cpu(self.recording.spike_array[i,:], 
                                          x,
                                          y,
                                          self.bins,
                                          self.bins,
                                          self.occupancy,
                                          self.smooth_sigma,
                                          self.mask_nans))
        return rate_maps
    
    def shuffle_rate_maps_batched_faster(
        self,
        n_shuffles: int = 100,
        coordinate_label: str = 'prey_location',
        per_neuron: bool = True,
        seed: int | None = 72289,
        return_info: bool = True,
        batch_size: int = 100,
    ):
        """
        GPU-copy-optimized version:
        - Avoids host sync (.item()) inside loop
        - No per-batch .cpu()/.numpy()
        - No empty_cache() churn
        - Single CPU transfer at the end (info path)
        """

        # ---- Prep data on the same device (avoid hidden copies) ----
        x, y, spikes_TN, occupancy, bins = self.prepare_rate_maps_torch(coordinate_label)
        device = spikes_TN.device
        T, N = spikes_TN.shape

        # Ensure ancillary tensors reside on the same device
        if not isinstance(bins, torch.Tensor):  bins = torch.as_tensor(bins, device=device)
        if not isinstance(occupancy, torch.Tensor): occupancy = torch.as_tensor(occupancy, device=device)
        if not isinstance(x, torch.Tensor): x = torch.as_tensor(x, device=device)
        if not isinstance(y, torch.Tensor): y = torch.as_tensor(y, device=device)

        if batch_size is None or batch_size <= 0:
            batch_size = N
        batch_size = int(batch_size)
        batch_ranges = [(i0, min(i0 + batch_size, N)) for i0 in range(0, N, batch_size)]

        k_globals = None
        if not per_neuron:
            g_cpu = torch.Generator(device='cpu')
            if seed is not None:
                g_cpu.manual_seed(seed)
            k_globals = torch.randint(0, T, (n_shuffles,), generator=g_cpu, device='cpu').tolist()

        g_gpu = torch.Generator(device=device)
        if seed is not None:
            # offset seed so GPU and CPU streams differ deterministically
            g_gpu.manual_seed(seed ^ 0x9E3779B97F4A7C15 & 0xFFFFFFFF)

        rows = torch.arange(T, device=device).unsqueeze(1)  # [T,1] reusable

        def roll_columns_time_block(TB: torch.Tensor, shifts_B: torch.Tensor) -> torch.Tensor:
            # TB: [T,B], shifts_B: [B] on device
            idx = (rows - shifts_B.unsqueeze(0)) % T       # [T,B]
            return TB.gather(0, idx)                       # [T,B]

        if return_info:
            info_all_shuffles = torch.empty((n_shuffles, N), device=device, dtype=torch.float32)
        else:
            maps_per_shuffle = []

        with torch.inference_mode():
            for sidx in tqdm(range(n_shuffles), desc='Shuffling rate maps'):
                if per_neuron:
                    k_global = None
                else:
                    k_global = k_globals[sidx]

                if return_info:
                    pass
                else:
                    maps_blocks = []

                for (i0, i1) in batch_ranges:
                    B = i1 - i0
                    if B <= 0:
                        continue

                    spikes_block = spikes_TN[:, i0:i1]

                    if per_neuron:
                        shifts_B = torch.randint(0, T, (B,), generator=g_gpu, device=device)
                        spikes_shuf_block = roll_columns_time_block(spikes_block, shifts_B)     # [T,B]
                    else:
                        spikes_shuf_block = torch.roll(spikes_block, shifts=k_global, dims=0)   # [T,B]

                    maps_block = get_rate_maps_torch(
                        spikes_shuf_block.transpose(0, 1),  # [B,T]
                        x, y,
                        bins, bins,
                        occupancy,
                        self.smooth_sigma,
                        self.mask_nans
                    )
                    if return_info:
                        info_B = shannon_information_torch(maps_block, occupancy)  # [B]
                        info_all_shuffles[sidx, i0:i1] = info_B
                    else:
                        if isinstance(maps_block, (list, tuple)):
                            maps_block = torch.stack(maps_block, dim=0)  # [B, ...]
                        maps_blocks.append(maps_block)

                if return_info:
                    pass  # handled by info_all_shuffles
                else:
                    if len(maps_blocks) == 1:
                        maps_dev = maps_blocks[0]
                    else:
                        maps_dev = torch.cat(maps_blocks, dim=0)  # [N, ...] on device
                    maps_per_shuffle.append(maps_dev)

        if return_info:
            out_cpu = info_all_shuffles.cpu()
            output = [out_cpu[s].contiguous() for s in range(n_shuffles)]
            return output

        else:
            output = [mp.cpu() for mp in maps_per_shuffle]
            return output
            
def calculate_split_half_correlation(B,
                                     bin_size=0.1, 
                                     smooth_sigma=1, 
                                     occupancy_cutoff=0.1,
                                     coordinate_label='prey_location'):
    mid = int(len(B)/2)
    RM_1 = RateMaps(B[:mid], 
                    bin_size=bin_size, 
                    smooth_sigma=smooth_sigma, 
                    occupancy_cutoff=occupancy_cutoff, 
                    coordinate_label=coordinate_label)
    RM_2 = RateMaps(B[mid:], 
                    bin_size=bin_size, 
                    smooth_sigma=smooth_sigma, 
                    occupancy_cutoff=occupancy_cutoff, 
                    coordinate_label=coordinate_label)
    spike_maps_1 = RM_1.rate_maps
    spike_maps_2 = RM_2.rate_maps
    corr = []; p = []
    for i in range(len(spike_maps_1)):
        nan_mask = ~np.isnan(spike_maps_1[i].ravel()) & ~np.isnan(spike_maps_2[i].ravel())
        c, pv = pearsonr(spike_maps_1[i].ravel()[nan_mask], spike_maps_2[i].ravel()[nan_mask])
        corr.append(c); p.append(pv)
    return corr, p
    
def run_place_test(R, 
                   dt=0.005, 
                   run_shuffle=True, 
                   bin_size=0.1, 
                   smooth_sigma=1, 
                   occupancy_cutoff=0.1, 
                   velocity_cutoff=0.017, 
                   coordinate_label='prey_location'):
    # bin the recording
    B = BinnedRecording(R, dt=dt)
    B.load_data()
    B.resample(load_spikes=True)
    include = (B.behavior_data.prey_velocity.values > velocity_cutoff)
    B = B[include]

    # get rate maps
    RM = RateMaps(B, bin_size=bin_size, smooth_sigma=smooth_sigma, occupancy_cutoff=occupancy_cutoff, coordinate_label=coordinate_label)
    spike_maps = RM.rate_maps

    # split half rate maps
    split_corr, split_p = calculate_split_half_correlation(B)

    if run_shuffle:
        # run shuffle test
        true_info, shuffled_info, p_value, behavior_info = RM.run_shuffle_test(n_shuffles=500, coordinate_label=coordinate_label, batch_size=2000, return_behavior_info=True)
        return spike_maps, true_info, shuffled_info, p_value, split_corr, split_p, behavior_info
    else:
        return spike_maps, split_corr, split_p
    
def get_rate_map_cpu(spike_counts, x_positions, y_positions, x_edges, y_edges, 
                     occupancy, smooth_sigma=1.0, mask_nans=True):
    if mask_nans:
        valid_mask = (~np.isnan(x_positions) &
                    ~np.isnan(y_positions) &
                    ~np.isnan(spike_counts))

        x_positions = x_positions[valid_mask]
        y_positions = y_positions[valid_mask]
        spike_counts = spike_counts[valid_mask]

    spike_map, _, _ = np.histogram2d(
        x_positions, y_positions,
        bins=[x_edges, y_edges],
        weights=spike_counts
    )

    with np.errstate(divide='ignore', invalid='ignore'):
        rate_map = spike_map / occupancy
        rate_map[occupancy == 0] = np.nan  # mask empty bins

    if smooth_sigma > 0:
        mask = np.isnan(rate_map)
        rate_map[mask] = 0
        rate_map = gaussian_filter(rate_map, sigma=smooth_sigma)
        rate_map[mask] = np.nan

    return rate_map

def get_occupancy(x, y, bins, cutoff, dt):
        occupancy, _, _ = np.histogram2d(x, y, bins)
        occupancy = occupancy / (1 / dt)
        occupancy[occupancy < cutoff] = 0
        return occupancy

def shannon_information_torch(
    maps_list,              # list/tuple of length N; each is [H, W] CUDA tensor
    occupancy,              # [H, W] CUDA tensor (counts or probs)
    normalize: bool = True, # True -> bits/spike; False -> bits/second
    eps: float = 1e-12
):
    dev = maps_list[0].device
    dt  = maps_list[0].dtype
    maps = torch.stack([torch.nan_to_num(m, nan=0.0) for m in maps_list], dim=0).to(dt)

    occ = torch.nan_to_num(occupancy, nan=0.0).to(device=dev, dtype=dt)
    occ_sum = torch.clamp(torch.nansum(occ), min=eps)
    occ = occ / occ_sum

    mfr = (maps * occ).sum(dim=(1, 2))
    mfr = torch.clamp(mfr, min=eps)

    r_safe = torch.clamp(maps, min=eps)
    log_term = torch.log2(r_safe / mfr.view(-1, 1, 1))
    info = (maps * occ * log_term).sum(dim=(1, 2))

    if normalize:
        info = info / mfr  # bits/spike

    return info.to(torch.float32)

def gaussian_kernel2d(kernel_size: int, sigma: float, device='cpu'):
    """Returns a 2D Gaussian kernel as a 4D tensor for conv2d."""
    ax = torch.arange(kernel_size, device=device) - kernel_size // 2
    xx, yy = torch.meshgrid(ax, ax, indexing='ij')
    kernel = torch.exp(-(xx**2 + yy**2) / (2. * sigma**2))
    kernel /= kernel.sum()

    # Shape (out_channels, in_channels/groups, H, W) for conv2d
    kernel = kernel.view(1, 1, kernel_size, kernel_size)
    return kernel

def smooth_rate_maps(rate_maps: torch.Tensor, sigma: float, kernel_size: int = None):
    """
    Applies 2D Gaussian smoothing to a batch of rate maps on GPU.
    rate_maps: (N, H, W)
    Returns: smoothed rate_maps (N, H, W)
    """
    device = rate_maps.device
    N, H, W = rate_maps.shape

    # NaN-safe mask
    nan_mask = torch.isnan(rate_maps)
    rate_maps = rate_maps.clone()
    rate_maps[nan_mask] = 0

    # Create Gaussian kernel
    if kernel_size is None:
        kernel_size = int(6 * sigma + 1) | 1  # ensure odd

    kernel = gaussian_kernel2d(kernel_size, sigma, device=device)

    # Prepare for conv2d: shape (N, 1, H, W)
    x = rate_maps.unsqueeze(1)

    # Weight mask to preserve valid regions
    weight_mask = (~nan_mask).float().unsqueeze(1)

    # Convolve
    smoothed = F.conv2d(x, kernel, padding=kernel_size // 2, groups=1)
    weights = F.conv2d(weight_mask, kernel, padding=kernel_size // 2, groups=1)

    # Normalize and restore NaNs
    smoothed = smoothed / weights
    smoothed[weights == 0] = float('nan')

    return smoothed.squeeze(1)  # shape: (N, H, W)


def get_rate_maps_torch(spike_counts_all, x_positions, y_positions, x_edges, y_edges, 
                        occupancy, smooth_sigma=1.0, mask_nans=True):
    device = spike_counts_all.device

    # remove nan data
    if mask_nans:
        # Find timepoints that are valid across all inputs
        valid_mask = (~torch.isnan(x_positions) &
                      ~torch.isnan(y_positions) &
                      ~torch.any(torch.isnan(spike_counts_all), dim=0))

        x_positions = x_positions[valid_mask]
        y_positions = y_positions[valid_mask]
        spike_counts_all = spike_counts_all[:, valid_mask]

    # handle position data
    n_bins_x, n_bins_y = len(x_edges)-1, len(y_edges)-1
    x_bin_idx = torch.bucketize(x_positions, x_edges) - 1
    y_bin_idx = torch.bucketize(y_positions, y_edges) - 1
    x_bin_idx = x_bin_idx.clamp(0, n_bins_x - 1)
    y_bin_idx = y_bin_idx.clamp(0, n_bins_y - 1)
    linear_idx = x_bin_idx * n_bins_y + y_bin_idx
    n_bins_total = n_bins_x * n_bins_y

    # count spikes
    n_units = spike_counts_all.shape[0]
    spike_maps = torch.zeros((n_units, n_bins_total), device=device)
    for i in range(n_units):
        spike_maps[i] = torch.bincount(linear_idx, weights=spike_counts_all[i], minlength=n_bins_total)
    spike_maps = spike_maps.reshape(n_units, n_bins_x, n_bins_y)

    # convert to rate
    occupancy_safe = occupancy.clone()
    occupancy_safe[occupancy_safe == 0] = float('inf')
    rate_maps = spike_maps / occupancy_safe  # broadcast

    # smooth
    if smooth_sigma > 0:
        spike_maps_cpu = spike_maps.cpu().numpy()
        smoothed_occupancy = gaussian_filter(occupancy.cpu().numpy(), sigma=smooth_sigma)
        for i in range(n_units):
            spike_maps_cpu[i] = gaussian_filter(spike_maps_cpu[i], sigma=smooth_sigma)
        spike_maps = torch.tensor(spike_maps_cpu, device=device)
        rate_maps = spike_maps / torch.tensor(smoothed_occupancy, device=device)
        # rate_maps_cpu = rate_maps.cpu().numpy()
        # for i in range(n_units):
        #     rate_maps_cpu[i] = gaussian_filter(rate_maps_cpu[i], sigma=smooth_sigma)
        # rate_maps = torch.tensor(rate_maps_cpu, device=device)

    # mask
    rate_maps[:, occupancy == 0] = float('nan')

    return rate_maps

def binary_image_outline(binary_im, extent=[0, 1, 0, 1]):
    ver_seg = np.where(binary_im[:,1:] != binary_im[:,:-1])
    hor_seg = np.where(binary_im[1:,:] != binary_im[:-1,:])
    l = []
    for p in zip(*hor_seg):
        l.append((p[1], p[0]+1))
        l.append((p[1]+1, p[0]+1))
        l.append((np.nan,np.nan))
    for p in zip(*ver_seg):
        l.append((p[1]+1, p[0]))
        l.append((p[1]+1, p[0]+1))
        l.append((np.nan, np.nan))
    segments = np.array(l)
    if len(segments.shape) == 2:
        segments[:,0] = extent[0] + (extent[1]-extent[0]) * segments[:,0] / binary_im.shape[1]
        segments[:,1] = extent[2] + (extent[3]-extent[2]) * segments[:,1] / binary_im.shape[0]
    return segments

def get_place_fields(rate_map, cutoff, min_area=3, extent=[0, 1, 0, 1]):
    img = (rate_map > cutoff).astype(np.uint8) * 255
    ccs = cv2.connectedComponentsWithStats(img, connectivity=8)
    fields = np.argwhere(ccs[2][:,-1] > min_area).squeeze() + 1
    mask = np.zeros(img.shape)
    outline = np.zeros((1,2))
    field_size = []
    if len(fields.shape) > 0:
        fields = fields[1:]
        for i in fields:
            mask = mask + (ccs[1] == i-1)
            field_size.append(ccs[2][i-1,-1])
        mask = mask.astype(np.uint8) * 255
        outline = binary_image_outline(mask, extent=extent)
    return mask, outline, field_size, ccs


def extract_place_fields(rate_map, threshold=0.2, connectivity=8, extent=[0, 1, 0, 1], min_pix=3, bin_size_m=0.1):
    rate_map = np.nan_to_num(rate_map, nan=0.0)
    binary = (rate_map >= threshold).astype(np.uint8)
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
        binary, connectivity=connectivity, ltype=cv2.CV_32S
    )

    fields = []
    for comp in range(1, num_labels):  # skip background = 0
        mask = labels == comp

        field_pixels = rate_map[mask]
        area_pixels = np.sum(mask)

        field_info = {
            "id": comp,
            "area_pixels": int(area_pixels),
            "area_m": area_pixels * (bin_size_m ** 2),
            "in_field_peak_rate": float(np.nanmax(field_pixels)),
            "in_field_mean_rate": float(np.nanmean(field_pixels)),
            "centroid_xy": tuple(centroids[comp]),  # (x, y)
            "outline": binary_image_outline(mask, extent=extent)
        }

        if area_pixels > min_pix:
            fields.append(field_info)
        else:
            labels[labels==comp] = 0

    return fields, labels
