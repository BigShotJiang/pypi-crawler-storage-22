import numpy as np
from cellworld import Experiment, World, Episode
from .episode import RecordingEpisode, RecordingEpisodes
from .sync import *
from .cluster_metrics import get_population, check_cluster_groups_file
from .utils import *
from .coverage import get_visit_histogram, make_map_bins, get_occupancy
from .celltile import get_world_mask
from .map import *
from .probe import *
from .lfp import *
from .io import *
from .pose import *
from .camera import *
from .backup import *
from scipy.signal import find_peaks
import matplotlib.pyplot as plt
import pandas as pd
from tqdm import tqdm
import os
import pickle
import gc
import torch


class Recording(object):
    def __init__(self, spike_folder, behavior_files=None, behavior_database='D:\\behavior', sort=False, post=60, merged_recording=dict()):
        if behavior_files is None:
            spike_files, behavior_files = match_session_paths_symmetric( #match_session_paths(
                spike_folder, 
                sort=sort, 
                post=post, 
                behavior_database=behavior_database
                )
            self.spike_path = [f['root'] for f in find_files(spike_files[0], 'cluster_group')]
            if len(behavior_files) == 0:
                # try old method if behavior files not found
                spike_files, behavior_files = match_session_paths(
                                                                spike_folder, 
                                                                sort=sort, 
                                                                post=post, 
                                                                behavior_database=behavior_database
                                                                )
                self.spike_path = spike_files
        else:
            self.spike_path = spike_folder
        self.behavior_path = behavior_files
        self.split_recording = None
        self.merged_recording = merged_recording
        self.experiment_name = self.get_experiment_name()
        self.experiment_info = parse_experiment_name(self.experiment_name)
        self.world = self.get_world()
        if len(self.spike_path) > 0:
            # load sync devices and probe/recording metadata
            self.get_spike_paths()
            self.probes, self.processors = self.get_processor_info()
            self.probe_names = self.probes.get('name')
            self.probe_index = {name: i for i,name in enumerate(self.probe_names)}


    def load_data(self, ops=None, skip_entrance_video=False):
        if ops is None and not hasattr(self, 'ops'):
            self.set_ops()
        self.episode_folders = []
        if len(self.behavior_path) > 0:
            # load experiment logs
            self.episode_folders, self.episode_num, self.episode_is_valid, self.sync_data_present = get_episode_folders(self.behavior_path)
            if not skip_entrance_video:
                self.load_entrance_video()
            self.load_sync_devices()
            self.load_experiments()
            self.episode_fs = self.get_average_fps()

        if len(self.spike_path) > 0:
            # load and align sync devices
            self.load_sync_devices()
            self.align_sync_devices('NI', plot_err=self.ops['plot_sync_results'])

            # load spike data
            self.spike_times, self.clusters, self.clusters_info, self.probe_spike_index = self.get_spikes()
            self.spike_fs = self.get_sync_device(self.probe_names[0]).sample_rate
    

    def process(self, fn=None, ops=None, split_recording=False):
        # standard processing pipeline
        if ops is None and not hasattr(self, 'ops'):
            ops = self.set_ops()
        elif ops is None and hasattr(self, 'ops'):
            ops = self.ops
        else:
            self.ops = ops
        self.load_data()
        self.info()
        self.drift_correct_episodes()
        self.df = self.get_behavior_dataframe()
        if split_recording:
            self.split()
        _ = self.get_population(recalculate=ops['recalculate_population'])
        _ = self.update_clust_info()
        if fn is not None:
            self.save(fn)

    def split(self):
        fn = os.path.join(self.spike_root, 'split.pkl')
        if os.path.exists(fn):
            self.split_recording = pickle.load(open(fn, 'rb'))
            split_time = self.split_recording['split_time']
            order = [i for i,r in enumerate(self.split_recording['recordings']) if r in self.experiment_name][0]
            if order == 0:
                self.df = self.df[self.df['time_stamp'] < split_time]
                I = self.spike_times < split_time
                self.spike_times = self.spike_times[I]
                self.clusters = self.clusters[I]
                self.probe_spike_index = self.probe_spike_index[I]
            else:
                self.df = self.df[self.df['time_stamp'] > split_time]
                I = self.spike_times > split_time
                self.spike_times = self.spike_times[I]
                self.clusters = self.clusters[I]
                self.probe_spike_index = self.probe_spike_index[I]

    def set_ops(self, 
            ideal_bin_width=0.10, # m
            place_tests=['prey', 'predator_visible', 'predator_not_visible'], 
            threshold_distance=0.15, # m
            remove_bad_frames=True,
            drop_tracking_errors=False,
            remove_bad_start_detections=True,
            remove_agent_swaps=True,
            velocity_cutoff=0.04, # m/s
            occupancy_cutoff=0.1, # s
            smooth=1.0,
            shuffles=500, 
            significant_p=95,
            kalman_filter=True,
            interpolate_missing=True,
            recalculate_population=False,
            plot_sync_results=False):
        bins,_,_ = make_map_bins(ideal_bin_width)
        self.ops = {'ideal_bin_width': ideal_bin_width,
                    'place_tests': place_tests,
                    'threshold_distance': threshold_distance,
                    'remove_bad_frames': remove_bad_frames,
                    'drop_tracking_errors': drop_tracking_errors,
                    'remove_bad_start_detections': remove_bad_start_detections,
                    'remove_agent_swaps': remove_agent_swaps,
                    'velocity_cutoff': velocity_cutoff / 2.34,
                    'occupancy_cutoff': occupancy_cutoff,
                    'smooth': smooth,
                    'shuffles': shuffles,
                    'significant_p': significant_p,
                    'kalman_filter': kalman_filter,
                    'interpolate_missing': interpolate_missing,
                    'recalculate_population': recalculate_population,
                    'bins': bins,
                    'plot_sync_results': plot_sync_results}
        return self.ops
    
    def run_place_tests(self, tests):
        if 'prey' in tests:
            _ = self.calculate_spatial_info(agents=['prey'], 
                                            use_cuda=True, 
                                            velocity_cutoff=self.ops['velocity_cutoff'], 
                                            occupancy_cutoff=self.ops['occupancy_cutoff'], 
                                            smooth=self.ops['smooth'],                                            
                                            its=self.ops['shuffles'],
                                            sig=self.ops['significant_p'])
        if 'predator_visible' in tests:
            _ = self.calculate_spatial_info(agents=['predator'], 
                                            visible=True, 
                                            use_cuda=True, 
                                            velocity_cutoff=self.ops['velocity_cutoff'], 
                                            occupancy_cutoff=self.ops['occupancy_cutoff'], 
                                            smooth=self.ops['smooth'],                                            
                                            its=self.ops['shuffles'],
                                            sig=self.ops['significant_p'])
        if 'predator_not_visible' in tests:
            _ = self.calculate_spatial_info(agents=['predator'], 
                                            visible=False, 
                                            use_cuda=True, 
                                            velocity_cutoff=self.ops['velocity_cutoff'], 
                                            occupancy_cutoff=self.ops['occupancy_cutoff'], 
                                            smooth=self.ops['smooth'],
                                            its=self.ops['shuffles'],
                                            sig=self.ops['significant_p'])
        if 'legacy' in tests:
            _ = self.calculate_spatial_info(velocity_cutoff=self.ops['velocity_cutoff'])
    

    def info(self):
        if len(self.behavior_path) > 0:
            print(f'\nRECORDING {self.experiment_name}')
            print(f'\tBehavioral experiments ({len(self.experiments)}): {len(self.episodes)} episodes, {self.behavior_duration/60:3.2f} minutes, {self.episode_fs:3.2f} samples/s')
            for i,p in enumerate(self.behavior_path):
                print(f'\t\tExperiment {i}: {p}')
        else:
            print('\tNo behavioral data found!')
        if len(self.spike_path) > 0:
            for p in range(len(self.spike_path)):
                print(f'\tNeuronal recording: {self.probes[p]["name"]}, {self.probes[p]["type"]}, {self.spike_fs} samples/s')
                print(f'\t\t{self.spike_path[p]}')
        else:
            print('\tNo spike data found!')


    def get_spike_paths(self):
        self.binary_files = self.get_files('continuous.dat')
        if self.binary_files is None:
            files = self.get_folders('continuous\\Neuropix')
        else:
            files = self.binary_files
        self.binary_paths = [os.path.split(f)[0] for f in files]
        self.kilosort_paths = os.path.split(self.get_file('params.py')[0])
        self.settings_file = self.get_file('settings.xml')[0]
        self.sync_messages_file = self.get_file('sync_messages.txt')[0]
        self.spike_root = os.path.split(self.sync_messages_file)[0]
        self.event_folder = os.path.join(self.spike_root, 'events')


    def save(self, fn=None, method='pickle'):
        self.close_binary_file()
        if fn is None:
            fn = f'{self.experiment_name}_recording.pkl'
        with open(fn, 'wb') as fid:
            pickle.dump(self, fid, protocol=pickle.HIGHEST_PROTOCOL)


    def load(self, fn=str):
        with open(fn, 'rb') as fid:
            recording = pickle.load(fid)
        return recording


    def get_sync_device(self, name):
        matches = SyncDevices()
        for names in self.sync_devices.get('name'):
            if name in names:
                #return self.sync_devices.where('name', names)[0]
                matches.append(self.sync_devices.where('name', names)[0])
        if len(matches) == 1:
            return matches[0]
        else:
            return matches
        
    
    def load_sync_info(self):
        with open(self.sync_messages_file) as f:
            lines = f.readlines()
            data = {}
            for line in lines:
                l = line.split(':')
                data[l[0]] = int(l[1].strip())
        return data


    def load_sync_devices(self):
        if not hasattr(self, 'sync_devices'):
            self.sync_devices = SyncDevices()

        # behavioral sync data
        if hasattr(self, 'episode_folders'):
            for i,f in enumerate(self.episode_folders):
                d = SyncDevice(f'episode_{self.episode_num[i]:03d}', f)
                if d.name not in self.sync_devices.get('name'):
                    self.sync_devices.append(d)

        # neural sync data
        # if hasattr(self, 'sync_messages_file'):
        #     sync_info = self.load_sync_info()
        #     for dev in sync_info:
        #         d = SyncDevice(dev, self.spike_root)
        #         if d.name not in self.sync_devices.get('name'):
        #             self.sync_devices.append(d)
        if hasattr(self, 'event_folder'):
            devices = [f for f in os.listdir(self.event_folder) if 'MessageCenter' not in f] #os.listdir(self.event_folder)
            for d in devices:
                d = SyncDevice(d, self.event_folder)
                if d.name not in self.sync_devices.get('name'):
                    self.sync_devices.append(d)

        # entrance video
        if hasattr(self, 'entrance_video'):
            entrance_video = self.entrance_video
            camera_devices = glob.glob(entrance_video.replace('.mp4', '*.json'))
            if len(camera_devices) > 0:
                for c in camera_devices:
                    d = SyncDevice().load_from_file(c)
                    if d.name not in self.sync_devices.get('name'):
                        self.sync_devices.append(d)
            d = SyncDevice(root=entrance_video, full_name='entrance_camera')
            if d.name not in self.sync_devices.get('name'):
                self.sync_devices.append(d)
        


    def align_sync_devices(self, reference_device='NI', plot_err=False, match_threshold=-3, rmse_threshold=1):
        ref_device = self.get_sync_device(reference_device)
        for name in self.sync_devices.get('name'):
            if 'episode' in name or 'Probe' in name or 'entrance_camera' in name:
                if '000' in name:
                    min_overlap = 1
                else:
                    min_overlap = 5
                if 'entrance_camera' in name:
                    rmse_threshold = 3
                self.get_sync_device(name).align(
                    device=ref_device, 
                    min_overlap=min_overlap, 
                    match_threshold=match_threshold, 
                    rmse_threshold=rmse_threshold, 
                    plot_err=plot_err
                    )


    def drift_correct_episodes(self, plot=False):
        if 'RecordingEpisodes' not in str(type(self.episodes)):
            episodes = RecordingEpisodes()

            for i,e in enumerate(self.episode_num):
                ep = RecordingEpisode()
                if len(self.episodes[i].trajectories) > 0:
                    episode_match = True
                    drift_coeffs = self.get_sync_device(f'episode_{e:03d}').drift_coeffs
                    if len(drift_coeffs) > 0:
                        z = drift_coeffs[0].coeffs
                    else:
                        print(f'Failed to align episode {e}... discarding episode')
                        episode_match = False

                if episode_match:
                        ep.valid_episode = True
                        ep.number = e
                        ep.folder = self.episode_folders[i]
                        ep.align_episode_times(z, self.episodes[i])
                        episodes.append(ep)

            self.episodes = episodes

        if plot:
            for ep in self.episodes:
                h = plot_diff(ep.frame_times, markersize=1)
                plt.eventplot([ep.start_time, ep.end_time], lineoffsets=0.01, linewidths=0.5, color=h[-1].get_color())
            plt.gca().set_yscale('log')


    def load_entrance_video(self, root=None, threshold=30*60):
        if root is None:
            root = os.path.split(self.behavior_path[0])[0]
        files = find_file(root, f"{self.experiment_info['mouse']}.mp4")
        match = None
        if files is not None:
            files = files[-1]
            experiment_time = datetime.strptime(f"{self.experiment_info['date']}_{self.experiment_info['time']}",'%Y%m%d_%H%M')
            movie_times = [datetime.strptime(f.split('_')[0], '%Y%m%d-%H%M%S') for f in files]
            match = match_date(movie_times, experiment_time, threshold=threshold)
        if match is not None:
            self.entrance_video = os.path.join(root, files[match])
            labelled_files = glob.glob(self.entrance_video.replace('.mp4', '') + '*.h5')
            if len(labelled_files) > 0:
                self.entrance_labels = labelled_files[0]
        else:
            print(f'No entrance video found')


    def load_experiments(self):
        self.experiments = []
        for p in self.behavior_path:
            self.experiments.append(Experiment.load_from_file(glob.glob(os.path.join(p, '*_experiment.json'))[0]))
        self.episodes = Episode_list()
        episode_num = self.episode_num.copy()
        episode_folders = self.episode_folders.copy()
        for i,f in enumerate(self.episode_folders):
            episode_file = glob.glob(os.path.join(f, '*episode*.json'))
            assert len(episode_file) > 0, f'Episode log not found in {f}'
            flag = False
            episode = Episode.load_from_file(episode_file[0])
            # episode.trajectories = episode.trajectories.get_unique_steps() # remove duplicate frames (this introduces many missed frames, removing)
            if len(episode.trajectories) == 0:
                print(f'{f} was empty, removing...')
                flag = True
            else:
                # deal with tracking errors
                if self.ops['drop_tracking_errors']:
                    # this drops an entire episode if there are any tracking errors
                    if bad_episode_tracking(episode, threshold_distance=self.ops['threshold_distance']):
                        print(f'{f} had a tracking error, removing...')
                        flag = True
                if self.ops['remove_bad_start_detections']:
                    # removes bad initial detections that triggered the episode start
                    episode, res = remove_bad_start_detections(episode)
                    if res['flag']:
                        print(f'WARNING: episode {self.episode_num[i]} was flagged because {res["reason"]}')
                        if len(episode.trajectories) == 0:
                            flag = True
                if self.ops['remove_agent_swaps']:
                    # removes frames where the agents swapped positions
                    episode = remove_swap_frames(episode)
                if self.ops['remove_bad_frames']:
                    # removes frames where tracking error is large
                    episode = clean_episode_tracking(episode, threshold_distance=self.ops['threshold_distance'])

            if not flag:
                episode = clean_episode_timestamps(episode)
                self.episodes.append(episode)
            else:
                episode_num.remove(self.episode_num[i])
                episode_folders.remove(self.episode_folders[i])
        self.episode_num = episode_num
        self.n_episodes = len(self.episodes)
        self.behavior_duration = self.get_behavior_duration()
        self.episode_folders = episode_folders
        assert len(self.episodes) == len(self.episode_num), f'{len(self.episodes)} episodes but {len(self.episode_num)} indexes'


    def format_recording_episodes(self):
        if 'RecordingEpisodes' not in str(type(self.episodes)):
            episodes = RecordingEpisodes()
            for i,e in enumerate(self.episode_num):
                ep = RecordingEpisode()
                ep.valid_episode = True
                ep.number = e
                ep.align_episode_times([1.0, 0.0], self.episodes[i])
                episodes.append(ep)
            self.episodes = episodes

    
    def get_file(self, filename:str):
        root_path = find_file(self.spike_path[0], 'settings.xml', joined=False)
        if root_path is None:
            root_path = walk_back(self.spike_path[0], 'Record Node')
        else: root_path = root_path[0]
        return find_file(root_path, filename, joined=True)
    
    def get_files(self, filename:str):
        root_path = find_file(self.spike_path[0], 'settings.xml', joined=False)
        if root_path is None:
            root_path = walk_back(self.spike_path[0], 'Record Node')
        else: root_path = root_path[0]
        return find_files(root_path, filename, joined=True)
    
    def get_folders(self, folder_name:str):
        root_path = find_file(self.spike_path[0], 'settings.xml', joined=False)
        if root_path is None:
            root_path = walk_back(self.spike_path[0], 'Record Node')
        else: root_path = root_path[0]
        return find_folders(root_path, folder_name)


    def open_binary_file(self, fn=None, hp_filter=False, whiten=False, dshift=False):
        if fn is None:
            if self.binary_files is None:
                self.get_spike_paths()
            fn = self.binary_files[0]
        self.binary_file, binary_ops = get_binary_file(fn, return_ops=True, hp_filter=hp_filter, whiten=whiten, dshift=dshift)
        if not hasattr(self, 'binary_ops'):
            self.binary_ops = binary_ops
        return self.binary_file, self.binary_ops
    

    def close_binary_file(self):
        if hasattr(self, 'binary_file'):
            delattr(self, 'binary_file')
        gc.collect()
        torch.cuda.empty_cache()


    def get_probe_sites(self):
        names = self.probes.get('type')
        return [get_probe_sites(n) for n in names]
    
    
    def get_channel_map(self, order='lfp'):
        return [get_channel_map(p, order=order) for p in self.probes]
    
    
    def save_channel_map(self):
        for s in self.probes:
            s.save_channel_map()
            
    
    def get_processor_info(self):
        return Probes(self.settings_file), Processors(self.settings_file)
    
    
    def get_episode_times(self):
        return np.vstack([self.episodes.get('start_time'), self.episodes.get('end_time')]).T
    
    
    def get_behavior_duration(self):
        return (self.episodes[-1].end_time - self.episodes[0].start_time).total_seconds()
    
    def get_neural_duration(self):
        if hasattr(self, 'binary_file'):
            pass
    

    def get_average_fps(self):
        fps = [self.sync_devices.where('name',f'episode_{n:03d}')[0].sample_rate for n in self.episode_num]
        return sum(fps) / len(fps)
    
    
    def get_experiment_name(self):
        if len(self.behavior_path) > 0:
            return self.behavior_path[0].split('\\')[-1]
        
        
    def get_world(self):
        if self.experiment_name is not None:
            world_string = self.experiment_info['world']
            if ('OASIS' in self.experiment_name) and (not 'FULL' in self.experiment_name) and (not 'full' in self.experiment_name):
                world = '00_00'
            else:
                world = world_string
            return World.get_from_parameters_names('hexagonal', 'canonical', world)


    def get_spikes(self, probe=None, correct_drift=True):
        if probe is None:
            probe_names = self.probe_names
        else:
            probe_names = [probe]

        spike_times = []
        clusters = []
        probe_index = []
        clusters_info = []
        for p in probe_names:
            probe_sync = self.get_sync_device(p)
            pn = probe_sync.name
            spike_path = self.spike_path[self.probe_index[pn]]

            # load and drift correct spike times, index probe
            fn = os.path.join(spike_path, 'spike_times.npy')
            spk_t = np.load(fn) / probe_sync.sample_rate
            if correct_drift:
                spk_t = np.polyval(probe_sync.drift_coeffs[0].coeffs, spk_t)
            spike_times.append(spk_t)
            probe_index.append([self.probe_index[pn]] * len(spk_t))

            # load clusters
            clusters.append(np.load(os.path.join(spike_path, 'spike_clusters.npy')))

            # load clusters info
            info_file = os.path.join(spike_path, 'cluster_info.tsv')
            if os.path.exists(info_file):
                clust_info = pd.read_csv(info_file, sep='\t', header=0)
            else:
                # update the cluster_group.tsv file to have a column group with correct IDs
                clust_info = check_cluster_groups_file(spike_path)
            clust_info['probe_name'] = pn
            clust_info['probe_index'] = self.probe_index[pn]
            clusters_info.append(clust_info)
        clusters_info = pd.concat(clusters_info)
        clusters_info.index = np.arange(len(clusters_info))

        return np.hstack(spike_times), np.hstack(clusters), clusters_info, np.hstack(probe_index)
    

    def get_spike_samples(self, probe=None):
        if probe is None:
            probe_names = self.probe_names
        else:
            probe_names = [probe]

        spike_samples = []
        clusters = []
        probe_index = []
        clusters_info = []
        for p in probe_names:
            probe_sync = self.get_sync_device(p)
            pn = probe_sync.name
            spike_path = self.spike_path[self.probe_index[pn]]

            # load and drift correct spike times, index probe
            fn = os.path.join(spike_path, 'spike_times.npy')
            ss = np.load(fn)
            spike_samples.append(ss)
            probe_index.append([self.probe_index[pn]] * len(ss))

            # load clusters
            clusters.append(np.load(os.path.join(spike_path, 'spike_clusters.npy')))

            # load clusters info
            info_file = os.path.join(spike_path, 'cluster_info.tsv')
            if os.path.exists(info_file):
                clust_info = pd.read_csv(info_file, sep='\t', header=0)
            else:
                # update the cluster_group.tsv file to have a column group with correct IDs
                clust_info = check_cluster_groups_file(spike_path)
            clust_info['probe_name'] = pn
            clust_info['probe_index'] = self.probe_index[pn]
            clusters_info.append(clust_info)
        clusters_info = pd.concat(clusters_info)
        clusters_info.index = np.arange(len(clusters_info))

        return np.hstack(spike_samples), np.hstack(clusters), clusters_info, np.hstack(probe_index)
        
    
    def download_continuous_data(self, again=False):
        for spike_path in self.spike_path:
            population_present = os.path.exists(os.path.join(spike_path, 'population.pkl'))
            if not os.path.exists(os.path.join(spike_path, 'continuous.dat')):
                if not population_present or again:
                    drive, tail = os.path.splitdrive(spike_path)
                    parts = tail.strip(os.sep).split(os.sep)
                    local = os.path.join(drive + os.sep, parts[0])
                    folder = spike_path.replace(local, '')
                    print(f'Downloading {spike_path}')
                    pull_continuous_data(folder, local, remote='dombeck_smb:DOMBECK_LAB\\Dombeck_Lab_Data_Backup\\Chris Angeloni\\spikes\\')

    def delete_continuous_data(self, timeout=10):
        for spike_path in self.spike_path:
            # fn = os.path.join(spike_path, 'continuous.dat')
            # fn = get_binary_path(spike_path)[i]
            files = find_files(spike_path, 'continuous.dat')
            continuous_files = [os.path.join(f['root'],f['files'][0]) for f in files]
            for fn in continuous_files:
                if os.path.exists(fn):
                    print(f'WARNING: DELETING {fn} IN {timeout} SECONDS, PRESS CTRL-C TO CANCEL!')
                    sleep(timeout)
                    os.remove(fn)
    
    def delete_partial_files(self):
        for spike_path in self.spike_path:
            partial_files = [f for f in os.listdir(spike_path) if '.partial' in f]
            for f in partial_files:
                os.remove(os.path.join(spike_path,f))

    def get_population(self, 
                       again=False, 
                       type='binary_waveform', 
                       save=True, 
                       download=False, 
                       delete=False, 
                       recalculate=False):
        if recalculate:
            download = True
            again = True
            save = True
            delete = True
        if not hasattr(self, 'population') or again:
            if download:
                self.download_continuous_data(again=again)
            self.population = get_population(self.spike_path, waveform_type=type, save=save, overwrite=again)
        if (not hasattr(self, 'population') or (len(self.population) == 0)) and not again:
            print(f'Loading population for {self.experiment_name}')
            self.population = self.load_population()
        if delete:
            self.delete_continuous_data()
        return self.population
    
    
    def load_population(self):
        return get_population(self.spike_path, save=False, overwrite=False)
    
    
    def update_clust_info(self, delete_population=True):
        assert(hasattr(self, 'clusters_info')), 'ERROR: Recording must have clust_info loaded!'
        assert(hasattr(self, 'population')), 'ERROR: Recording must have a Population loaded!'
        rows = []
        for c in tqdm(self.population, desc='Updating cluster info...'):
            assert(hasattr(c, 'qualities')), f'ERROR: Cluster {c.u} must have qualities computed'
            series = c.to_series(self.clusters_info)
            series['experiment'] = self.experiment_name
            series['prefix'] = self.experiment_info['prefix']
            series['date'] = self.experiment_info['date']
            series['time'] = self.experiment_info['time']
            series['mouse'] = self.experiment_info['mouse']
            series['world'] = self.experiment_info['world']
            series['suffix'] = self.experiment_info['suffix']
            rows.append(series)
        self.clusters_info = pd.concat(rows, axis=1).T
        if delete_population:
            self.population = []
        return self.clusters_info
    

    def refresh_clust_info(self):
        new_df = []
        for i,row in tqdm(self.clusters_info.iterrows(), desc='Refreshing cell info...'):
            #print(R.population[i].qualities.nspikes, row['n_spikes'])
            for key in row.keys():
                if hasattr(self.population[i], key):
                    row[key] = getattr(self.population[i], key)
                if hasattr(self.population[i].qualities, key):
                    row[key] = getattr(self.population[i].qualities, key)
            new_df.append(row)
        self.clusters_info = pd.concat(new_df, axis=1).T
        return self.clusters_info
    
    
    def recording_episodes_to_dict(self, fps=90):
        d = {'prey':    {'location': [], 
                         'time_stamp': [], 
                         'frame': [], 
                         'velocity': [], 
                         'outlier_frames': [],
                         'episode': [],
                         'occupancy': [],
                         'coverage': [],
                         'bins': [],
                         'fps': [],
                         'visible': [],
                         'tracked': [],
                         'rotation': []}, 
            'predator': {'location': [],
                         'time_stamp': [], 
                         'frame': [], 
                         'velocity': [], 
                         'outlier_frames': [],
                         'episode': [],
                         'occupancy': [],
                         'coverage': [],
                         'bins': [],
                         'fps': [],
                         'visible': [],
                         'tracked': [],
                         'rotation': []}}
        
        if not hasattr(self, 'ops'):
            smooth = True
            interpolate = True
            bins, _, _ = make_map_bins(0.1)
        else:
            smooth = self.ops['kalman_filter']
            interpolate = self.ops['interpolate_missing']
            bins = self.ops['bins']
        
        # build from dataframes
        dfs = []
        frame_count = 0
        for i,e in tqdm(enumerate(self.episodes), 
                        desc='Building episode dictionary...', 
                        total=len(self.episodes)):
            if e.valid_episode:
                tmp = episode_to_dataframe(e.episode, 
                                           self.world, 
                                           smooth=smooth, 
                                           interpolate=interpolate)
                _, ind = get_unique_frames(e.episode)
                aligned_frames = e.frame_times[ind]
                assert len(aligned_frames) == len(tmp['time_stamp']), f'aligned frame times {len(aligned_frames)} must be same length as original time_stamps {len(tmp["time_stamp"])}'
                tmp['time_stamp'] = aligned_frames
                tmp['episode'] = e.number
                tmp = tmp.reset_index()
                frames = tmp['frame'].copy()
                tmp['tracking_frame'] = frames
                tmp['frame'] = frames + frame_count
                frame_count += frames.max()
                dfs.append(tmp)
        df = pd.concat(dfs)
        df = df.reset_index()

        # convert visibility to boolean (much nicer later on)
        df['visible'][df['visible'] == 1] = True
        df['visible'][df['visible'] == 0] = False

        # append
        for agent in d.keys():
            I = ~np.any(np.isnan(np.vstack(df[f'{agent}_location'].values)), axis=1)
            for key in d[agent].keys():
                df_key = [i for i in list(df.columns) if i==key]
                if np.sum(I) == 0:
                    data = np.array([])
                elif len(df_key) == 1:
                    data = np.vstack(df[df_key[0]].loc[I])
                elif len(df_key) > 1:
                    df_key = [i for i in df_key if agent in i]
                    data = np.vstack(df[df_key[0]].loc[I])
                else:
                    data = np.array([])
                d[agent][key].append(data)
        # print(d['prey']['frame'], d['prey']['location'])
        # reshape
        for agent in d.keys():
            for key in d[agent].keys():
                if len(d[agent][key])> 0:
                    d[agent][key] = np.vstack(d[agent][key]).squeeze()

        # occupancy/coverage
        bins = bins
        mask = get_world_mask(self.world, bins)
        for agent in d.keys():
            d[agent]['time_stamp'] = np.sort(d[agent]['time_stamp']) # rarely, timestamps will come in out of order, which causes issues in other analysis
            if len(d[agent]['location']) > 0:
                d[agent]['occupancy'] = get_occupancy(d[agent]['location'][:,0], d[agent]['location'][:,1], bins, fps=fps)
                d[agent]['coverage'] = get_visit_histogram(d[agent]['location'][:,0], d[agent]['location'][:,1], bins=bins, mask=mask, dt=fps)
                d[agent]['bins'] = bins
                d[agent]['fps'] = fps

        return d, df
    
    def get_pose(self):
        if not hasattr(self, 'entrance_video'):
            self.load_entrance_video()
            self.load_sync_devices()
            self.align_sync_devices()

        # load pose data
        assert hasattr(self, 'entrance_labels'), f'No entrance pose labels found'
        pose, parts = get_pose_from_file(self.entrance_labels)
        P = pose_array(pose.copy(), likelihood_cutoff=0.8)

        # align frame times
        assert hasattr(self, 'entrance_video'), f'No entrance video found'
        camera_devices = self.get_sync_device('camera')
        if type(camera_devices) is SyncDevice:
            sync_coeffs = camera_devices.drift_coeffs[0].coeffs
            frames = np.arange(0,P.shape[-1]) 
            frame_times = np.polyval(sync_coeffs, frames / camera_devices.sample_rate)
        else:
            # for merged recordings, need to get frames separately from the first and second segments
            camera_devices = self.get_sync_device('merged')
            assert len(camera_devices) == 2, f'Need exactly 2 merged camera devices'

            # get the time where the recordings were merged (seconds in NI clock)
            offset = np.load(os.path.join(self.get_sync_device('NI').sync_path, 'merge_offset.npz'))['NI']
            ft = []
            for i,d in enumerate(camera_devices):
                sync_coeffs = d.drift_coeffs[0].coeffs
                ts = np.arange(0,P.shape[-1]) / d.sample_rate
                ts = np.polyval(sync_coeffs, ts)
                ft.append(ts)
            first_seg = ft[0] < offset; second_seg = ft[1] > offset
            frame_times = np.concatenate((ft[0][first_seg], ft[1][second_seg]))

            # remove pose data in the gap between the recordings
            merged_frames = first_seg | second_seg
            P = P[:,:,merged_frames]
            frames = np.where(merged_frames)[0]

        # get frame rate
        if type(camera_devices) == SyncDevice:
            fs = camera_devices.sample_rate
        else:
            fs = camera_devices[0].sample_rate # assume both cameras have same sample rate
            
        # apply camera transform
        C = Camera('entrance', self.entrance_video)
        warped_pose = []
        for i in range(P.shape[0]):
            points = P[i,:-1,:].squeeze().T
            warped_pose.append(C.apply_transform(points))
        warped_pose = np.stack(warped_pose, axis=0)
        return frame_times, warped_pose, fs, frames, P

    def get_entrance_pose(self):
        frame_times, warped_pose, fs, frames, P = self.get_pose()

        # get head data
        head_angle = get_head_angle(warped_pose)
        head_position, confidence = get_head_position(warped_pose, head_angle, likelihood=P[:,-1,:].squeeze())
        head_position, head_velocity = smooth_head_position(head_position, frame_times, dt=1/fs, return_velocity=True)
        
        # return as dataframe
        entrance_coordinates = np.array(get_entry_box_coordinates())
        entrance_coordinates[0,0] = 0.01
        entrance_coordinates[3,0] = 0.01
        pose_df = pd.DataFrame()
        pose_df['prey_location'] = head_position.tolist()
        pose_df['prey_velocity'] = head_velocity.tolist()
        pose_df['prey_rotation'] = head_angle.tolist()
        pose_df['prey_confidence'] = confidence.tolist()
        pose_df['time_stamp'] = frame_times.tolist()
        pose_df['prey_in_box'] =  contains(head_position, get_entry_box_coordinates()).tolist()
        pose_df['prey_in_entrance'] = contains(head_position, entrance_coordinates).tolist()
        pose_df['prey_tracked_in_entrance'] = (~np.all(np.isnan(np.vstack(pose_df['prey_location'].values)),axis=1)).tolist()
        pose_df['entrance_camera_data'] = np.ones(head_angle.shape).tolist()
        pose_df['entrance_camera_frame'] = frames.tolist()
        return pose_df
        
    def get_behavior_dataframe(self, remove_bad_frames=True):
        # get arena data and reformat
        _, arena_df = self.recording_episodes_to_dict()
        arena_df = clean_df_locations(arena_df)
        arena_df['prey_tracked_in_arena'] = ~np.isnan(arena_df['prey_location_x'])
        arena_df['predator_tracked_in_arena'] = ~np.isnan(arena_df['predator_location_x'])

        try:
            # get arena data and reformat
            entry_df = self.get_entrance_pose()
            entry_df = clean_df_locations(entry_df)

            # remove pose entries where the head wasnt tracked 
            # or if it was tracked outside of the entrance area
            entry_df = entry_df[entry_df['prey_in_entrance'] == True]
            entry_df = entry_df[entry_df['prey_tracked_in_entrance'] == True]

            # remove pose entries where the mouse was also tracked in the arena
            entry_df = entry_df[
                ~get_matched_times(np.vstack(entry_df['time_stamp']),
                                    np.vstack(arena_df['time_stamp'][arena_df['prey_tracked_in_arena']]))]
            
            # merge
            df = pd.concat([arena_df, entry_df], ignore_index=True)
            df = df.sort_values(by='time_stamp').reset_index()

        except Exception as e:
            print(f'{e} -- could not add entrance pose')
            df = arena_df

        if remove_bad_frames:
            # remove bad frames from merged data using a velocity filter
            v = get_velocity(np.vstack([df['prey_location_x'],df['prey_location_y']]).T, df['time_stamp'])
            df['prey_location_x'][v>3] = np.nan; df['prey_location_y'][v>3] = np.nan

            # remove frames where the prey was missing in the arena, detected in the entrance, 
            # but the tracking jump was implausible
            if 'prey_tracked_in_entrance' in df.columns:
                _, bad_detections = remove_false_entrance_detections(np.vstack([df['prey_location_x'], df['prey_location_y']]).T,
                                                                    df['prey_tracked_in_arena'],
                                                                    df['prey_tracked_in_entrance'],
                                                                    df['time_stamp'],
                                                                    quarantine_sec=5)
                df['prey_location_x'][bad_detections == 1] = np.nan
                df['prey_location_y'][bad_detections == 1] = np.nan
                df['prey_tracked_in_entrance'][bad_detections == 1] = np.nan
                df['prey_bad_entrance_detections'] = bad_detections

        return df


    def get_good_cells(self, fr_cutoff=0.1, use_ks_label=True):
        if 'prey_mean_firing_rate' in self.clusters_info.columns:
            fr_include = self.clusters_info.prey_mean_firing_rate > fr_cutoff
        else:
            fr_include = self.clusters_info.fr > fr_cutoff
        if use_ks_label:
            index = (self.clusters_info.KSLabel == 'good') & fr_include
        else:
            index = self.clusters_info.good_unit & fr_include
        return self.clusters_info[index].copy()
    
    
    def get_place_cells(self, agent='prey', value='spatial_info', info_cutoff=0.5, fr_cutoff=0.1, use_ks_label=True):
        good_cells = self.get_good_cells(fr_cutoff=fr_cutoff, use_ks_label=use_ks_label)
        return good_cells[(good_cells[f'{agent}_place_cell'] == True) & (good_cells[f'{agent}_{value}'] > info_cutoff)]
    

    def get_place_cell_channel_groups(self, cutoff=0.5):
        lfp_channel_map = self.get_channel_map(order='lfp')[0]
        channel_groups = cluster_probe_channels(lfp_channel_map)
        place_cell_channels = self.get_place_cells(cutoff=cutoff).ch.values.astype(int)
        return np.sort(np.argsort([np.sum(np.in1d(place_cell_channels, lfp_channel_map[channel_groups == g,0])) for g in np.unique(channel_groups)])[3:])


    def get_ca1_channels(self, ripple_distance=200, close_file=True, cutoff=0.5, time_index=None, plot=False, return_bad_channels=False):
        if not hasattr(self, 'binary_file'):
            self.open_binary_file()
        
        lfp_channel_map = self.get_channel_map(order='lfp')[0]
        channel_groups = cluster_probe_channels(lfp_channel_map)
        groups_index = np.unique(channel_groups)
        if len(groups_index) > 4:
            groups_index = self.get_place_cell_channel_groups(cutoff=cutoff)

        fs = self.binary_ops['fs']
        if time_index is None:
            time_index = range(fs*10)
        lfp_data = self.binary_file[time_index]
        if close_file:
            self.close_binary_file()

        x_ripple = filter_torch(lfp_data, [150, 250], order=1)
        bad_channels = get_bad_channels(x_ripple)
        ripple_power = rms_torch(x_ripple)
        ripple_power[bad_channels] = np.nan

        # find peak ripple power
        peak_channels = []
        for i,g in enumerate(groups_index):
            x0 = ripple_power[channel_groups == g].cpu()
            x = x0 - np.nanmin(x0)
            # x = gaussian_smoother(x, sd=1)
            pks, _ = find_peaks(x, prominence=1, distance=30)
            if plot:
                plt.plot(x); plt.plot(pks, x[pks], 'r.')
            smooth_max = lfp_channel_map[channel_groups == g,-2:][np.max(pks)]
            dists = distance(smooth_max, lfp_channel_map[channel_groups == g,-2:], axis=1)
            si = np.argsort(dists)
            true_max = si[np.argmax(x0[si[0:10]])]
            peak_channels.append(lfp_channel_map[channel_groups == g,:][true_max])
        peak_channels = np.vstack(peak_channels)

        # use only channels nearby those with high ripple power to target CA1
        ripple_channels = []
        for shank in range(4):
            channel_distance = distance(peak_channels[shank,1:], lfp_channel_map[:,1:])
            ripple_channels.extend(lfp_channel_map[channel_distance < ripple_distance,0])

        # remove bad channels
        _, a, b = np.intersect1d(ripple_channels, bad_channels, return_indices=True)
        ripple_channels = np.delete(ripple_channels, a)
        self.channels = {'peak_ripple_channels': peak_channels,
                         'all_ripple_channels': ripple_channels,
                         'bad_channels': bad_channels}

        if close_file:
            self.close_binary_file()
        del lfp_data, x_ripple, ripple_power, x0, x

        if return_bad_channels:
            return peak_channels, ripple_channels, bad_channels
        else:
            return peak_channels, ripple_channels
        
    
    def decimate_lfp(self, factor=20, chunk_time=2, hp_filter=False, whiten=False, dshift=False, close_file=True, verbose=False):
        def _decimate_lfp(fn, factor=20, chunk_time=2, hp_filter=False, whiten=False, dshift=False, close_file=True, verbose=False):
            if not hasattr(self, 'binary_file'):
                self.open_binary_file(fn, hp_filter=hp_filter, whiten=whiten, dshift=dshift)

            # setup
            fs = self.binary_ops['fs']
            duration = int(self.binary_file.shape[0] / fs) #np.ceil(self.binary_ops['runtime'])
            n_chunks = int(duration / chunk_time)
            chunk_size = int(fs * chunk_time)
            pad_size, new_pad_size = get_decimation_pad(fs, factor)

            # decimate
            resampler = [Resample(orig_freq=fs, new_freq=fs/factor).to('cuda:0')]
            decimated_signals = []
            decimated_samples = []
            for i in tqdm(range(n_chunks), disable=not verbose):
                chunk = (i*chunk_size, np.min([i*chunk_size + chunk_size, self.binary_file.shape[0]]))
                start = np.max([chunk[0]-pad_size, 0])
                end = np.min([chunk[1]+pad_size, self.binary_file.shape[0]])

                x = self.binary_file[start:end]
                x_dec = decimate_torch(x, resampler=resampler).cpu().numpy()
                t = range(chunk[0],chunk[1])[::factor]
                if i == 0:
                    x_dec = x_dec[:, :-new_pad_size]
                elif i == n_chunks:
                    x_dec = x_dec[:, new_pad_size:]
                else:
                    x_dec = x_dec[:, new_pad_size:-new_pad_size]
                assert x_dec.shape[1] == len(t), \
                    f'Time-signal mismatch in chunk {i}: time length ({len(t)}), signal length ({x_dec.shape[1]})'
                
                decimated_signals.append(x_dec)
                decimated_samples.append(t)

            # cleanup
            if close_file:
                self.close_binary_file()
            del x, x_dec, resampler
            gc.collect()
            torch.cuda.empty_cache()

            return np.hstack(decimated_signals), np.hstack(decimated_samples), fs, fs/factor
        
        dec_signals = {}
        for f in self.binary_files:
            if 'Probe' in f:
                probe = os.path.split(os.path.split(f)[0])[-1]
                print(probe)
                dev = self.get_sync_device(probe)
                if type(dev) == SyncDevices:
                    dev = dev[0]
                coeffs = dev.drift_coeffs[0].coeffs
                x, t, old_fs, new_fs = _decimate_lfp(f, factor=factor, chunk_time=chunk_time, hp_filter=hp_filter, whiten=whiten, dshift=dshift, close_file=close_file, verbose=verbose)
                dec_signals[probe] = {'x': x, 
                                    't': t / old_fs, 
                                    'coeffs': coeffs, 
                                    't_corrected': np.polyval(coeffs, t / old_fs)}
        return dec_signals


    def calculate_amplitude(self, sd=0.004, chunk_time=20, band='ripple', method='sum', channels=[0], duration=None, probe=None):
        if probe is None:
            fn = self.binary_files[0]
        else:
            fn = [b for b in self.binary_files if probe in b][0]
        self.close_binary_file()
        self.open_binary_file(fn)
        lfp_channel_map = self.get_channel_map('lfp')[0]
        I = channel_to_lfp(channels, lfp_channel_map)
        fs = self.binary_ops['fs']
        if duration is None:
            duration = int(self.binary_file.shape[0] / fs) #np.ceil(self.binary_ops['runtime'])
        n_chunks = int(np.ceil(duration / chunk_time))
        chunk_size = fs * chunk_time
        amps = []
        for i in tqdm(range(n_chunks)):
            chunk = (i*chunk_size, np.min([i*chunk_size + chunk_size, self.binary_file.shape[0]]))
            lfp = self.binary_file[chunk[0]:chunk[1]]
            if band == 'ripple':
                amps.append(get_ripple_amplitude(lfp[I,:], method=method, sd=sd, fs=fs))
            else:
                amps.append(get_amplitude(lfp[I,:], sd=sd, fs=fs, band=band, method=method))
        self.close_binary_file()
        if len(amps[0].shape) == 1:
            return np.hstack(amps)
        else:
            return np.vstack(amps).T
        
    def calculate_rms_amplitude(self, chunk_time=20, band=[6,12], channels=range(0, 384), duration=None, probe=None, verbose=False):
        if probe is None:
            fn = self.binary_files[0]
        else:
            fn = [b for b in self.binary_files if probe in b][0]
        self.close_binary_file()
        self.open_binary_file(fn)
        fs = self.binary_ops['fs']
        if duration is None:
            duration = int(self.binary_file.shape[0] / fs) #np.ceil(self.binary_ops['runtime'])
        n_chunks = int(duration / chunk_time)
        chunk_size = fs * chunk_time
        amps = []
        for i in tqdm(range(n_chunks), disable=not verbose):
            chunk = (i*chunk_size, np.min([i*chunk_size + chunk_size, self.binary_file.shape[0]]))
            lfp = self.binary_file[chunk[0]:chunk[1]]
            amps.append(get_rms_amplitude(lfp[channels,:], band=band))
        self.close_binary_file()
        if len(amps[0].shape) == 1:
            return np.hstack(amps)
        else:
            return np.vstack(amps).T
    
    
    def load_classifier_results(self, fn):
        with open(fn, 'rb') as fid:
            [data, binned_data, results, ops] = pickle.load(fid)
        p_location = []
        p_state = []
        for r in tqdm(results['cv_results']['results']):
            p_state.append(r.acausal_posterior.sum('x_position').sum('y_position'))
            p_location.append(r.acausal_posterior.sum('state').values)
        self.classifier_data = data
        self.classifier_location_posterior = np.vstack(p_location)
        self.classifier_state_posterior = np.vstack(p_state)
        self.classifier_ops = ops
        self.classifier_environment = results['cv_results']['classifiers'][0].environments[0]
        self.classifier_error = results['dist_error']
        self.classifer_map_estimate = results['map_estimate']


def load_world(occlusions):
    return 

def plot_syncs(x,y):

    fig,ax = plt.subplots(2,2)

    if len(x) == len(y):
        ax[0,0].plot(x, y)
        ax[1,0].plot(x - y)
        ax[1,1].hist((x - y))
    else:
        ax[0,0].set_title('Mismatch in sync event counts')

    ax[0,1].plot(x[:-1], np.diff(x),'ro')
    ax[0,1].plot(y[:-1], np.diff(y),'k.')
    ax[0,1].set_ylim((0,1.2))
    ax[0,1].set_xlim([x.max()-4.5, x.max()+0.5])

    return fig, ax

def plot_diff(x, **kwargs):
    h = plt.plot(x[:-1], np.diff(x), '.', **kwargs)
    return h
    
def load_recording(spike_folder, 
                   results_path='D:/chris-lab/projects/cellworld_npx/data', 
                   suffix='_recording'):
    spike_paths, behavior_paths = match_session_paths(spike_folder, sort=True)
    R = Recording(spike_folder=spike_paths, behavior_files=behavior_paths)
    fn = f'{results_path}/{R.experiment_name}{suffix}.pkl'
    R = load_recording_from_file(fn)
    return R

def load_recording_from_file(fn):
    if os.path.exists(fn):
        with open(fn, 'rb') as fid:
            R = pickle.load(fid)
    else:
        print(f'Recording file {fn} not found!')
        return None
    return R

def is_continous_path(path):
    return 'continuous.dat' in os.listdir(path)

def get_binary_path(root, filestr='continuous.dat', foldstr='Neuropix'):
    files = find_files(root, filestr=filestr, foldstr=foldstr)
    if len(files) > 0:
        return [os.path.join(files[0]['root'], f) for f in files[0]['files']]