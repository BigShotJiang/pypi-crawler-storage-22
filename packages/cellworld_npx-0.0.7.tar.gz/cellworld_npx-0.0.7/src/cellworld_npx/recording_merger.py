from cellworld_npx.sync import get_merged_syncs, SyncDevices
from .recording import get_binary_path, Recording
from .io import get_recording_duration
from .backup import copy_folder, run_ks
from scipy.optimize import minimize
from copy import deepcopy
from pathlib import Path
from tqdm import tqdm
import numpy as np
import os



class RecordingMerger(object):
    def __init__(self, path_a, path_b, output_folder, gapless=True, sort=False, verbose=False):
        self.path_a = path_a
        self.path_b = path_b
        self.output_folder = output_folder
        self.gapless = gapless
        self.sort = sort
        self.verbose = verbose
        self.output_binary = get_binary_path(self.output_folder)
        self.a_binary = get_binary_path(self.path_a)[0]
        self.b_binary = get_binary_path(self.path_b)[0]
        assert os.path.exists(self.a_binary), f'{self.a_binary} not found'
        assert os.path.exists(self.b_binary), f'{self.b_binary} not found'
        if self.verbose:
            print('\nMerging recordings:')
            print(f'\trecording 1: {self.path_a} ({get_recording_duration(self.a_binary)/30000:.2f}s)')
            print(f'\trecording 2: {self.path_b} ({get_recording_duration(self.b_binary)/30000:.2f}s)')
            print(f'\toutput folder: {self.output_folder}')
        

    def load_recordings(self):
        self.recording_a = Recording(spike_folder=self.path_a)
        self.recording_a.load_entrance_video()
        self.recording_a.load_sync_devices()
        self.recording_b = Recording(spike_folder=[self.path_b], behavior_files=[])
        self.recording_b.load_sync_devices()

        # start_offset = (self.recording_b.get_sync_device('Software').start_sample - self.recording_a.get_sync_device('Software').start_sample) / 1000
        # a_duration = get_recording_duration(self.recording_a.binary_files[0]) / self.recording_a.get_sync_device('ProbeA').sample_rate
        # time_gap = start_offset - a_duration
        # samples_gap = int(time_gap * self.recording_a.get_sync_device('ProbeA').sample_rate)

        self.start_offset = None
        self.a_duration = None
        self.time_gap = None
        self.samples_gap = None

    def binary_merged(self):
        assert os.path.exists(self.output_binary), f'{self.output_binary} not found'
        output_duration = get_recording_duration(self.output_binary)
        first_duration = get_recording_duration(self.a_binary)
        second_duration = get_recording_duration(self.b_binary)
        # print(output_duration, first_duration, second_duration)
        return output_duration == (first_duration + second_duration)

    def binary_sorted(self, verbose=False, fudge_factor=10*30000):
        first_duration = get_recording_duration(self.a_binary) + fudge_factor # fudge factor (default 10 sec)
        spikes = np.load(os.path.join(os.path.split(self.output_binary)[0], 'spike_times.npy'))
        if verbose:
            print(f'\tfirst recording duration {(first_duration - fudge_factor)/30000:.2f}s (+{fudge_factor/30000:.2f}s fudge factor) vs max spike duration {np.max(spikes)/30000:.2f}s: merged recording sorted = {np.max(spikes) > first_duration}')
        return np.max(spikes) > first_duration

    def copy_recording_folder(self):
        if self.output_binary is None or (len(self.output_binary) == 0):
            copy_folder(self.path_a, self.output_folder, verbose=True, extra_flags=["--exclude 'population.pkl'"])
        self.output_binary = get_binary_path(self.output_folder)[0]

    def merge_and_sort_binary(self, verbose=False):
        if not self.gapless:
            gap = self.samples_gap
        else:
            gap = 0
        assert os.path.exists(self.output_binary), f'{self.output_binary} not found'
        if not self.binary_merged():
            pad_then_append(self.output_binary, self.b_binary, samples_to_bytes(gap), show_progress=True)
        if self.binary_merged() & self.sort:
            if not self.binary_sorted(verbose=verbose):
                folder = os.path.split(self.output_binary)[0]
                run_ks(folder, folder)

    def offset_events(self):
        offset, samples_a, samples_b = self.match_events(save=False)
        offset = offset['NI']
        off, sse, res = minimize_offset(samples_a['NPX'], samples_b['NPX'], samples_a['NI'], samples_b['NI'], x_offset=offset, x0=0)
        assert sse < 1, f'Failed to align events: SSE ({sse:0.2f}) > 1'
        offset, samples_a, samples_b = self.match_events(save=True, NI_offset=off)


    def match_events(self, save=True, NI_offset=None):
        # match recording a
        devices = ['NPX', 'NI']
        dev_a = {}; ind = {}
        dev_a['NI'] = self.recording_a.get_sync_device('NI')
        dev_a['NPX'] = self.recording_a.get_sync_device('Neuropix')
        err, ind['NPX'], ind['NI'] = dev_a['NPX'].align(dev_a['NI'], return_err=True)
        states_a, samples_a = get_indexed_events(dev_a, ind)

        # load and align recording b
        dev_b = {}; ind = {}
        dev_b['NI'] = self.recording_b.get_sync_device('NI')
        dev_b['NPX'] = self.recording_b.get_sync_device('Neuropix')
        err, ind['NPX'], ind['NI'] = dev_b['NPX'].align(dev_b['NI'], return_err=True)
        states_b, samples_b = get_indexed_events(dev_b, ind)

        # set offsets
        offset = {}
        offset['NPX'] = dev_a['NPX'].get_total_samples() / dev_a['NPX'].sample_rate
        if NI_offset is None:
            offset['NI'] = offset['NPX']
        else:
            offset['NI'] = NI_offset
        self.offsets = offset

        # offset recording b
        for d in devices:
            samples_b[d] = ((samples_b[d]) + (offset[d] * dev_b[d].sample_rate)).astype(int)

        # merge and save
        new_samples = {}; new_states = {}
        for d in devices:
            new_samples[d] = np.concatenate([samples_a[d], samples_b[d]])
            new_states[d] = np.concatenate([states_a[d], states_b[d]])
            if save:
                new_path = self.output_folder + dev_b[d].sync_path.split(self.path_b)[-1]
                np.save(os.path.join(new_path, 'sample_numbers.npy'), new_samples[d])
                np.save(os.path.join(new_path, 'states.npy'), new_states[d])
                np.savez(os.path.join(new_path, 'merge_offset.npz'), **offset)

        for d in devices:
            samples_a[d] = samples_a[d] / dev_a[d].sample_rate
            samples_b[d] = samples_b[d] / dev_b[d].sample_rate

        return offset, samples_a, samples_b

    def match_camera_events(self, save=True):
        devices = {}
        devices['a'] = self.recording_a.get_sync_device('NI')
        devices['b'] = self.recording_b.get_sync_device('NI')
        camera_device = self.recording_a.sync_devices.where('name', 'entrance_camera')[0]

        # load merged recording
        R = Recording(self.output_folder)
        R.load_sync_devices()
        merged_device = R.get_sync_device('NI')

        # for each of the original recordings, get the best matching segment of camera events
        if self.verbose:
            print('\tFinding best matching camera events...')
        camera_devices = {}
        for d in devices.keys():
            results = {}
            i = 0
            while True:
                try:
                    camera_device.name = f'merged_camera_{i}'
                    res = camera_device.align(devices[d], plot_err=False, return_rmse=True, min_overlap=5, match_threshold=-2.5, verbose=False)
                    score = (np.min(res[0]) / (res[3])) * len(res[1])**3
                    # print(res[3], score)
                    results[f'{camera_device.name}'] = score
                except Exception as e:
                    if str(e) == 'list index out of range':
                        break
                i = i + 1
            camera = deepcopy(camera_device)
            camera.name = min(results, key=results.get)
            camera_devices[d] = camera

        # now align each camera event to the merged recording and save
        if self.verbose:
            print('\tAligning camera events to merged recording...')
        for d in devices.keys():
            res = camera_devices[d].align(merged_device, return_rmse=True, min_overlap=5, match_threshold=-2, plot_err=True, relaxed_fit=True)
            if save:
                camera_devices[d].to_jsonable()
                fn = camera_devices[d].sync_path.replace('.mp4', f'_{camera_devices[d].name}.json')
                camera_devices[d].save(fn)


    def merge(self):
        self.load_recordings();
        self.copy_recording_folder();
        self.merge_and_sort_binary(verbose=self.verbose);
        self.match_events();
        self.match_camera_events();








def get_indexed_events(dev, ind):
    states = {}; samples = {}
    for d in dev.keys():
        _, ev = dev[d].get_event_durations(state=1)
        on = (ev[0][ind[d]]*dev[d].sample_rate).astype(int)
        off = (ev[1][ind[d]]*dev[d].sample_rate).astype(int)
        assert len(on) == len(off)
        samples[d] = np.concatenate([on, off])
        si = np.argsort(samples[d])
        states[d] = np.concatenate([np.ones((len(on),1)), -1*np.ones((len(off),1))])[si].squeeze()
        samples[d] = samples[d][si].squeeze()
    return states, samples

def replace_sync_events(dev, coeff_idx=0):
    times = np.concatenate([dev.drift_coeffs[coeff_idx].matching_times[0][0], 
                            dev.drift_coeffs[coeff_idx].matching_times[0][1]])
    times = np.sort(times)
    all_times = np.round(dev.sync_times,1)
    I = np.isin(all_times, times)
    dev.sync_times = dev.sync_times[I]
    dev.sync_samples = dev.sync_samples[I]
    dev.sync_states = dev.sync_states[I]

def erf(ax, bx, ay, by, x_offset, y_offset):
    x = np.concatenate([ax, bx + x_offset])
    y = np.concatenate([ay, by + y_offset])
    z = np.polyfit(x, y, 1)
    return np.sum((y - np.polyval(z, x))**2)

def minimize_offset(ax, bx, ay, by, x_offset, x0=0.0, bounds=None, tol=1e-15):
    """
    Find offset that minimizes the line-fit SSE.
    """
    # Optional auto-bounds based on data span
    if bounds is None:
        span_y = max(np.ptp(np.concatenate([ay, by])), 1.0)
        bounds = (-span_y, span_y)

    res = minimize(
        fun=lambda off: erf(ax, bx, ay, by, x_offset, off),
        x0=np.array(x0, dtype=float),
        method="L-BFGS-B",
        bounds=[bounds],
        tol=tol
    )
    offset_opt = float(res.x)
    sse_opt = float(res.fun)
    return offset_opt, sse_opt, res

def samples_to_bytes(n_timepoints: int, n_channels: int= 384, bytes_per_sample: int = 2) -> int:
    return int(n_timepoints) * int(n_channels) * int(bytes_per_sample)

def pad_then_append(
    dst_path: str,
    src_path: str,
    zeros_bytes: int,
    chunk_bytes: int = 8 * 1024 * 1024,
    show_progress: bool = True,
):
    """
    Append `zeros_bytes` zero-bytes to the end of `dst_path`,
    then append the entire contents of `src_path` to `dst_path`,
    with a single progress bar (tqdm).

    Writes actual zeros (not sparse). Streaming I/O, cross-platform.
    """
    dst = Path(dst_path)
    src = Path(src_path)

    if dst.resolve() == src.resolve():
        raise ValueError("src_path and dst_path refer to the same file.")
    if zeros_bytes < 0:
        raise ValueError("zeros_bytes must be >= 0")

    dst.parent.mkdir(parents=True, exist_ok=True)

    # bytes we’re going to write in total
    src_size = src.stat().st_size
    total_to_write = zeros_bytes + src_size

    # progress bar (optional)
    pbar = tqdm(total=total_to_write, unit="B", desc='Merging binary files...', unit_scale=True, disable=not show_progress)
    try:
        with dst.open("ab", buffering=0) as f_out:
            # 1) append zeros
            if zeros_bytes > 0:
                zero_chunk = b"\x00" * min(chunk_bytes, zeros_bytes)
                remaining = zeros_bytes
                while remaining > 0:
                    n = min(len(zero_chunk), remaining)
                    f_out.write(zero_chunk[:n])
                    remaining -= n
                    pbar.update(n)

            # 2) append src file
            with src.open("rb", buffering=0) as f_in:
                while True:
                    buf = f_in.read(chunk_bytes)
                    if not buf:
                        break
                    f_out.write(buf)
                    pbar.update(len(buf))

        return dst.stat().st_size  # new size in bytes
    finally:
        pbar.close()

def merge_events(self):
        if not self.gapless:
            offset = self.start_offset
        else:
            offset = 0
        dev_npx = self.recording_a.get_sync_device('Neuropix')
        offset = dev_npx.get_total_samples() / dev_npx.sample_rate
        for d in ['Neuropix', 'NI']:
            # get first recording events
            dev_a = self.recording_a.get_sync_device(d)
            samples_a = dev_a.sync_samples
            states_a = dev_a.sync_states

            # because NPX unplugged, the Neuropix plugin crashes and stops recording events
            # therefore, need to drop NIDAQ events after the crash from samples_a/states_a
            if d == 'NI':
                states_a = states_a[((samples_a - dev_a.start_sample) / dev_a.sample_rate) < (offset - 0.85)]
                samples_a = samples_a[((samples_a - dev_a.start_sample) / dev_a.sample_rate) < (offset - 0.85)]

            # remove end state if left high
            if states_a[-1] == 1:
                states_a = states_a[:-1]
                samples_a = samples_a[:-1]

            # get second recording events and offset them
            dev_b = self.recording_b.get_sync_device(d)
            samples_b = ((dev_b.sync_samples - dev_b.start_sample) + (offset * dev_b.sample_rate)).astype(int)
            states_b = dev_b.sync_states

            # remove start state if starts high
            if states_b[0] == -1:
                states_b = states_b[1:]
                samples_b = samples_b[1:]

            # merge and save
            new_samples = np.concatenate([samples_a, samples_b])
            new_states = np.concatenate([states_a, states_b])
            new_path = self.output_folder + dev_b.sync_path.split(self.path_b)[-1]
            np.save(os.path.join(new_path, 'sample_numbers.npy'), new_samples)
            np.save(os.path.join(new_path, 'states.npy'), new_states)

        return offset