from .coverage import *
from .celltile import *
from .kalman import *
import numpy as np
from cellworld import *
from astropy.convolution import convolve
import torch
from scipy.ndimage import gaussian_filter
from scipy.stats import binned_statistic
import pandas as pd
from tqdm import tqdm
from collections import deque

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
pd.options.mode.chained_assignment = None  # default='warn'
np.seterr(divide='ignore', invalid='ignore')

## general functions
def distance(x, y=None, axis=1):
    if y is None:
        return np.linalg.norm(np.diff(x, axis=0), axis=axis)
    else:
        if len(x.shape) < 2:
            x = x[np.newaxis,:]
        assert x.shape[1] == y.shape[1], 'x and y have same number of columns'
        return np.linalg.norm(x - y, axis=axis)

def normalize(x, axis=0):
    return (x - np.nanmean(x, axis=axis)) / np.nanstd(x, axis=axis)

def convert_angle(weird_angle):
    '''
    converts cellworld rotation value to normal angle in left-hand coordinate system
    '''
    normal_angles = (90 - weird_angle) % 360
    normal_angles[normal_angles > 180] -= 360
    return normal_angles
# print(convert_angle(np.array([135,180, 270, 0, -10])))

def align_by_lag(x, y, lag):
    """
    Returns overlapping aligned segments (x_aligned, y_aligned) after applying lag to y.
    lag definition matches xcorr_overlap_corrected_fft:
      x[i] aligns with y[i - lag]

    So:
      lag > 0 => y delayed (shift forward): compare x[lag:] with y[:-lag]
      lag < 0 => y advanced (shift backward): compare x[:lag] with y[-lag:]
    """
    x = np.asarray(x)
    y = np.asarray(y)
    k = int(lag)

    if k > 0:
        return x[k:], y[:-k]
    elif k < 0:
        return x[:k], y[-k:]
    else:
        n = min(len(x), len(y))
        return x[:n], y[:n]


def xcorr_overlap_corrected_fft(x, y, max_lag=None, min_overlap=1000, eps=1e-12):
    """
    Overlap-corrected Pearson correlation vs lag for alignment.

    Lag convention:
      r[lag] computed over overlap of x[i] with y[i - lag]
      -> lag > 0 means y is shifted AFTER x (y lags; y must be shifted LEFT by lag to align)
      -> lag < 0 means y is shifted BEFORE x (y leads; y must be shifted RIGHT by |lag| to align)
    """
    x = np.asarray(x, dtype=np.float64).ravel()
    y = np.asarray(y, dtype=np.float64).ravel()
    nx, ny = len(x), len(y)

    # FFT dot-products using convolution with reversed y (unambiguous lag mapping)
    n_full = nx + ny - 1
    nfft = 1 << int(np.ceil(np.log2(n_full)))

    X = np.fft.rfft(x, n=nfft)
    Yr = np.fft.rfft(y[::-1], n=nfft)          # reverse y for convolution
    xy = np.fft.irfft(X * Yr, n=nfft)[:n_full] # dot-products for all lags

    lags = np.arange(-(ny - 1), nx)            # lag = index - (ny-1)

    # optionally restrict lags (recommended for speed/robustness)
    if max_lag is not None:
        max_lag = int(max_lag)
        keep = (lags >= -max_lag) & (lags <= max_lag)
        lags = lags[keep]
        xy = xy[keep]

    # prefix sums for overlap windows
    px  = np.concatenate([[0.0], np.cumsum(x)])
    px2 = np.concatenate([[0.0], np.cumsum(x * x)])
    py  = np.concatenate([[0.0], np.cumsum(y)])
    py2 = np.concatenate([[0.0], np.cumsum(y * y)])

    # overlap indices for each lag k:
    # x indices [sx, ex), y indices [sy, ey) where sy = sx - k
    sx = np.maximum(0, lags)
    ex = np.minimum(nx, ny + lags)  # works for negative/positive lags
    L = (ex - sx).astype(np.int64)

    sy = sx - lags
    ey = ex - lags

    sum_x  = px[ex]  - px[sx]
    sum_x2 = px2[ex] - px2[sx]
    sum_y  = py[ey]  - py[sy]
    sum_y2 = py2[ey] - py2[sy]

    Lf = L.astype(np.float64)
    cov  = xy - (sum_x * sum_y) / np.maximum(Lf, 1.0)
    varx = sum_x2 - (sum_x * sum_x) / np.maximum(Lf, 1.0)
    vary = sum_y2 - (sum_y * sum_y) / np.maximum(Lf, 1.0)

    denom = np.sqrt(np.maximum(varx, 0.0) * np.maximum(vary, 0.0)) + eps
    r = cov / denom

    bad = (L < min_overlap) | (varx < eps) | (vary < eps)
    r = r.astype(np.float64)
    r[bad] = np.nan

    return lags, r


def xcorr_fft_norm(x, y, max_lag=None, demean=True, eps=1e-12):
    x = np.asarray(x, dtype=np.float64).ravel()
    y = np.asarray(y, dtype=np.float64).ravel()
    assert x.ndim == 1 and y.ndim == 1
    assert len(x) == len(y), "This helper assumes equal lengths"

    n = len(x)
    if demean:
        x = x - x.mean()
        y = y - y.mean()

    denom = (np.linalg.norm(x) * np.linalg.norm(y)) + eps

    # zero-pad to avoid circular correlation: length >= 2n-1
    nfft = 1 << int(np.ceil(np.log2(2*n - 1)))

    X = np.fft.rfft(x, n=nfft)
    Y = np.fft.rfft(y, n=nfft)

    # cross-correlation: ifft(conj(X) * Y) gives lags 0..nfft-1 (circular)
    r_circ = np.fft.irfft(np.conj(X) * Y, n=nfft)

    # convert to linear "full" correlation ordering: lags = -(n-1)..(n-1)
    # r_full length = 2n-1
    r_full = np.concatenate([r_circ[-(n-1):], r_circ[:n]])
    r_full = r_full / denom
    lags_full = np.arange(-(n-1), n)

    if max_lag is None:
        return lags_full, r_full

    max_lag = int(max_lag)
    keep = (lags_full >= -max_lag) & (lags_full <= max_lag)
    return lags_full[keep], r_full[keep]

def xcorr_norm(x, y, max_lag=None, demean=True, eps=1e-12):
    x = np.asarray(x).ravel()
    y = np.asarray(y).ravel()
    assert x.ndim == 1 and y.ndim == 1, "x and y must be 1D"
    assert len(x) == len(y), "For this helper, x and y must be the same length"

    if demean:
        x = x - x.mean()
        y = y - y.mean()

    denom = (np.linalg.norm(x) * np.linalg.norm(y)) + eps

    # full cross-correlation (length 2N-1)
    r_full = np.correlate(x, y, mode="full") / denom
    lags_full = np.arange(-len(x) + 1, len(x))

    if max_lag is None:
        return lags_full, r_full

    max_lag = int(max_lag)
    keep = (lags_full >= -max_lag) & (lags_full <= max_lag)
    return lags_full[keep], r_full[keep]


## binning and formatting
def clean_df_locations(df):
    for c in df.columns:
        if 'location' in c:
            locs = np.vstack(df[c])
            if locs.shape[-1] == 2:
                df[f'{c}_x'] = locs[:,0]
                df[f'{c}_y'] = locs[:,1]
                df.drop(c, axis=1, inplace=True)
    return df

def bin_recording_old(R, dt=0.05, agent='prey', 
                  cell_index=None, skip_spikes=False, 
                  kalman_filter=False, show_progress=False, 
                  remove_missing_data=True, bins=None):
    d = format_behavior_data(R, agent=agent, kalman_filter=kalman_filter, show_progress=show_progress)

    # if dt is less than original sampling rate, do interpolation for behavioral data
    mode = 'bin'
    if dt < np.median(np.diff(d['time_stamp'])):
        mode = 'interpolate'
    
    # for each field, bin or interpolate as appropriate
    # ***NOTE: if there is no data in a binned interval and mode=='bin', those frames will be all NaNs
    if bins is None:
        bins = np.arange(np.nanmin(d['time_stamp']) - (dt/2), np.nanmax(d['time_stamp']) + (dt/2), dt)
    b = {k: [] for k in d.keys()}
    for k in tqdm(d.keys(), disable=not show_progress, desc='binning recording'):
        d[k] = np.array(d[k])
        if (len(d[k].shape) == 1) & (d[k].shape[0] > 0):
            if 'bin' in mode:
                b[k],_,_ = binned_statistic(d['time_stamp'], d[k], bins = bins)
            else:
                b[k] = np.interp(bins[:-1] + dt/2, d['time_stamp'], d[k])
            b[k] = b[k].tolist()
        elif len(d[k].shape) == 2:
            tmp = []
            for i in range(d[k].shape[1]):
                if 'bin' in mode:
                    out,_,_ = binned_statistic(d['time_stamp'], d[k][:,i].squeeze(), bins = bins)
                else:
                    out = np.interp(bins[:-1] + dt/2, d['time_stamp'], d[k][:,i].squeeze())
                tmp.append(out)
            b[k] = np.vstack(tmp).T.tolist()
        else:
            b.pop(k, None)

    if not skip_spikes:
        # bin spikes
        if cell_index is None:
            cell_index = R.clusters_info.KSLabel == 'good'
        good_cells = R.clusters_info[cell_index].cluster_id.values
        spike_times = []
        for u in good_cells:
            spike_times.append(np.array(R.spike_times[R.clusters == u]))
        b['neural_data'] = bin_spikes(spike_times, dt, bins[0], bins[-1])
        if (len(b['neural_data']) - len(b['time_stamp'])) == 1:
            b['neural_data'] = b['neural_data'][:-1,:]
        b['neural_data'] = b['neural_data'].tolist()
        [print(k, len(b[k])) for k in b.keys()]

    return pd.DataFrame.from_dict(b)

def bin_output(outputs, output_times, dt, wdw_start, wdw_end, downsample_factor=1):

    # Downsample output
    # We just take 1 out of every "downsample_factor" values
    if downsample_factor != 1: #Don't downsample if downsample_factor=1
        downsample_idxs = np.arange(0, output_times.shape[0], downsample_factor) #Get the idxs of values we are going to include after downsampling
        outputs = outputs[downsample_idxs,:] #Get the downsampled outputs
        output_times = output_times[downsample_idxs] #Get the downsampled output times

    # Put outputs into bins
    edges = np.arange(wdw_start, wdw_end, dt) #Get edges of time bins
    num_bins = edges.shape[0]-1 #Number of bins
    output_dim = outputs.shape[1] #Number of output features
    outputs_binned = np.empty([num_bins,output_dim]) #Initialize matrix of binned outputs
    #Loop through bins, and get the mean outputs in those bins
    for i in range(num_bins): #Loop through bins
        idxs = np.where((np.squeeze(output_times)>=edges[i]) & (np.squeeze(output_times)<edges[i+1]))[0] #Indices to consider the output signal (when it's in the correct time range)
        for j in range(output_dim): #Loop through output features
            outputs_binned[i,j] = np.nanmean(outputs[idxs,j])

    return outputs_binned

def bin_spikes(spike_times, dt, wdw_start, wdw_end):
    edges = np.arange(wdw_start-dt/2, wdw_end+dt/2, dt) #Get edges of time bins
    num_bins = edges.shape[0]-1 #Number of bins
    num_neurons = len(spike_times) #Number of neurons
    neural_data = np.empty([num_bins,num_neurons]) #Initialize array for binned neural data
    #Count number of spikes in each bin for each neuron, and put in array
    for i in range(num_neurons):
        neural_data[:,i] = np.histogram(spike_times[i], edges)[0]
    #print(neural_data.shape)
    return neural_data

def cell_title(u, clust_info, fields=['ch', 'depth', 'fr', 'n_spikes', 'KSLabel', 'spatial_decay', 
                                      'spike_width', 'spike_duration', 'waveform_snr', 'presence_ratio', 
                                      'refractory_violations', 'isi_violations', 'good_unit']):
    I = np.where(clust_info.cluster_id == u)[0][0]
    row = clust_info.iloc[I]
    title = [f"cell ID: {row.cluster_id} (index {I})\n"]
    for f in fields:
        if type(row[f]) is str:
            title.append(f"{f}: {row[f]}\n")
        else:
            title.append(f"{f}: {row[f]:3.2f}\n")
    return ''.join(title)


## rate map calculations
def compute_rate_map(spike_times, frame_times, location, occupancy, bins, smooth=None):
    #pos_i = np.digitize(spike_times, frame_times[:-1], right=False)
    pos_i = np.searchsorted(frame_times[:-1], spike_times)
    spike_count = get_histogram2(location[pos_i,0].squeeze(), location[pos_i,1].squeeze(), bins)
    spike_count[occupancy == 0] = 0
    rate_map = spike_count / occupancy
    if smooth is None:
        return rate_map
    else:
        mask = np.isnan(rate_map)
        rate_map[mask] = 0
        rate_map = gaussian_filter(rate_map, sigma=smooth)
        rate_map[mask] = np.nan
        return rate_map

def filter_spikes(spike_times, video_times, clust=[]):
    spikes = []
    if len(clust) > 0:
        clusters = []
    for e in range(video_times.shape[0]):
        I = (spike_times > video_times[e,0]) & (spike_times < video_times[e,1])
        spikes.append(spike_times[I])
        if len(clust) > 0:
            clusters.append(clust[I.squeeze()].squeeze())
    spike_times = np.hstack(spikes)
    if len(clust) > 0:
        clust = np.hstack(clusters)
        return spike_times, clust
    else:
        return spike_times

def get_spike_histogram(spike_times, frame_times, include, dt=0.001, use_cuda=False):
    t = np.arange(np.min(frame_times[include]), np.max(frame_times[include]), dt)
    incl = np.interp(t, frame_times, include) > 0.2
    tbins = np.append(t - (dt/2), t[-1] + (dt/2))

    if use_cuda:
        t = torch.from_numpy(t).to(torch.device("cuda:0"))
        incl = torch.from_numpy(incl).to(torch.device("cuda:0"))
        tbins = torch.from_numpy(tbins)
        spikec,_ = torch.histogram(torch.from_numpy(spike_times), bins=tbins)
        spikec = spikec.int().to(torch.device("cuda:0"))
    else:
        spikec,_ = np.histogram(spike_times, bins=tbins)

    return spikec, t, incl

def get_spike_times_from_histogram(spikec, t, use_cuda=False):
    if use_cuda:
        return torch.repeat_interleave(t[spikec > 0], spikec[spikec > 0])
    else:
        return np.repeat(t[spikec > 0], spikec[spikec > 0])

def shift_spiketimes_fast(spike_counts, t, incl, min_shift=5, max_shift=None, dt=None):
    if dt is None:
        dt = (t[-1] - t[0]) / len(t)
    if max_shift is None:
        max_shift = torch.max(t) / 2
    shift = min_shift + torch.randint(low=0, high=int(np.floor(max_shift*1000)), size=(1,1)) / 1000
    sf = spike_counts[incl == 1]; tf = t[incl == 1]
    shiftf = torch.roll(sf, int(shift/dt))
    return get_spike_times_from_histogram(shiftf, tf, use_cuda=True)


def shuffle_spiketimes(spike_times, epochs):
    shuffled = []
    assert (len(epochs.shape) == 2) & (epochs.shape[1] == 2), 'ERROR: epochs must be a 2D array with two columns!'
    for i in range(epochs.shape[0]):
        ep_start = epochs[i,0]
        ep_end = epochs[i,1]
        ep_spikes = spike_times[(spike_times >= ep_start) & (spike_times < ep_end)]
        if len(ep_spikes) > 0:
            ep_spikes0 = ep_spikes - ep_start
            ep_duration = ep_end - ep_start
            shuff_spikes = (ep_spikes0 + 5 + np.random.randint(0, np.floor(ep_duration*1000)) / 1000) % ep_duration
            shuff_spikes = shuff_spikes + ep_start
            shuff_spikes.sort()
            assert (~np.any(shuff_spikes < ep_start) & ~np.any(shuff_spikes > ep_end)), 'ERROR: spikes were shuffled outside of epoch boundaries!'
            shuffled.extend(shuff_spikes)
    return shuffled

def shannon_information(rate_map, occupancy, mfr=None, normalize=True, warn=False):
    '''
    shannon_information(rate_map, occupancy, normalize=False)

    calculates the shannon information of a rate map given the occupancy (p(observation)) per bin
    - rate_map: firing rates per bin
    - occupancy: probability of observing the agent in each bin (should sum to 1)
    - mfr: mean firing rate (Hz) of the cell
    - normalization (optional): if False (default), it will return information in bits/s
                                if True, it will return information in bits/spike
    '''
    occ = occupancy / np.nansum(occupancy) # occupancy sums to 1
    if not mfr:
        mfr = np.nansum(rate_map * occ) # mean firing rate according to Skaggs, 1992
    log = np.log2(rate_map / mfr)
    info = np.nansum(rate_map * occ * log)
    if normalize:
        info = info / mfr
    if warn & (info < 0):
        print('WARNING: information less than 0')
    return info, mfr


def spatial_info_perm(spike_times, frame_times, location, occupancy, bins, video_times, 
                      its=500, sig=95, normalize=True, occupancy_cutoff=0.0, mask=None):
    rate_map = compute_rate_map(spike_times, frame_times, location, occupancy, bins)
    occ_mask = (occupancy < occupancy_cutoff) & (occupancy > 0)
    rate_map[occ_mask] = 0
    occupancy[occ_mask] = 0
    if mask is not None:
        rate_map[mask.reshape(rate_map.shape)] = np.nan
        occupancy[mask.reshape(occupancy.shape)] = np.nan
    mean_firing_rate = np.nansum(rate_map * (occupancy / np.nansum(occupancy)))
    true_SI, _ = shannon_information(rate_map, occupancy, mfr=mean_firing_rate, normalize=normalize)

    shuff_SI = []
    shuff_map = []
    for i in range(its):
        shuff_spikes = shuffle_spiketimes(spike_times, video_times)
        rate_map_shuff = compute_rate_map(shuff_spikes, frame_times, location, occupancy, bins)
        ssi, _ = shannon_information(rate_map_shuff, occupancy, mfr=mean_firing_rate, normalize=normalize)
        shuff_SI.append(ssi)
        shuff_map.append(rate_map_shuff)

    percentile = np.percentile(shuff_SI, sig)
    percentile_map = np.percentile(np.stack(shuff_map, axis=2), sig, axis=2)
    return true_SI > percentile, true_SI, shuff_SI, rate_map, mean_firing_rate, percentile_map


def spatial_info_fast(spike_times, frame_times, include, location, occupancy, bins, 
                      its=500, sig=95, normalize=True, occupancy_cutoff=0.0, mask=None, smooth=None, 
                      return_shuffle=False, use_common_fr=False):
    spikec, t, incl = get_spike_histogram(spike_times, frame_times, include, dt=0.001, use_cuda=True)
    if spikec[incl].sum() <= 1: # randomly add two spikes with 1 or fewer spikes
        included = np.where(incl.to('cpu')==1)[0]
        I = included[np.random.randint(0, len(included), 2)] 
        spikec[I] = 1
    spiket = get_spike_times_from_histogram(spikec[incl], t[incl], use_cuda=True)
        
    times = frame_times[include]
    rate_map = compute_rate_map(spiket.to('cpu'), times, location, occupancy, bins, smooth=smooth)
    occ_mask = (occupancy < occupancy_cutoff) & (occupancy > 0)
    rate_map[occ_mask] = 0
    occupancy[occ_mask] = 0
    if mask is not None:
        rate_map[mask.reshape(rate_map.shape)] = np.nan
        occupancy[mask.reshape(occupancy.shape)] = np.nan
    if use_common_fr:
        mean_firing_rate = np.nansum(rate_map * (occupancy / np.nansum(occupancy)))
    else:
        mean_firing_rate = None
    true_SI, true_fr = shannon_information(rate_map, occupancy, mfr=mean_firing_rate, normalize=normalize)

    shuff_SI = []
    shuff_map = []
    min_shift = 5
    max_shift = int(np.floor(frame_times[-1] - frame_times[0])) - min_shift
    for i in range(its):
        shuff_spikes = shift_spiketimes_fast(spikec, t, incl, dt=0.001, min_shift=min_shift, max_shift=max_shift)
        rate_map_shuff = compute_rate_map(shuff_spikes.to('cpu'), times, location, occupancy, bins, smooth=smooth)
        ssi, _ = shannon_information(rate_map_shuff, occupancy, mfr=mean_firing_rate, normalize=normalize)
        shuff_SI.append(ssi)
        shuff_map.append(rate_map_shuff)

    percentile = np.percentile(shuff_SI, sig)
    percentile_map = np.percentile(np.stack(shuff_map, axis=2), sig, axis=2)
    if return_shuffle:
        return true_SI > percentile, true_SI, shuff_SI, rate_map, true_fr, percentile_map, shuff_map
    else:
        return true_SI > percentile, true_SI, shuff_SI, rate_map, true_fr, percentile_map

def check_shuffled_spikes(spike_times, frame_times, include):
    spikec, t, incl = get_spike_histogram(spike_times, frame_times, include, dt=0.001, use_cuda=True)
    if spikec[incl].sum() <= 1: # randomly add two spikes with 1 or fewer spikes
        included = np.where(incl.to('cpu')==1)[0]
        I = included[np.random.randint(0, len(included), 2)] 
        spikec[I] = 1
    shuff_spikes = shift_spiketimes_fast(spikec, t, incl, dt=0.001, min_shift=5, max_shift=500)
    return shuff_spikes

def get_epochs(x, t, start=None):
    assert len(x) == len(t), f'x must be same length as t'
    if start is None:
        x = np.append(x[0], x)
    else:
        x = np.append(start, x)
    starts = np.argwhere(np.diff(x.astype('int')) > 0).flatten()
    ends = np.argwhere(np.diff(x.astype('int')) < 0).flatten()
    starts, ends = clean_events(starts, ends)
    return np.vstack((t[starts], t[ends])).T

def get_tracked_frames(frames, cutoff=0.05):
    epochs = (np.diff(np.hstack((0, frames, np.inf))) > cutoff).astype(int)
    onsets = np.argwhere(np.diff(epochs) < 0).flatten()
    offsets = np.argwhere(np.diff(epochs) > 0).flatten()
    # plt.plot(np.diff(np.hstack((0, frames, np.inf))))
    onsets, offsets = clean_events(onsets, offsets)
    return np.hstack((frames[onsets], frames[offsets])), np.diff(np.hstack((frames[0], frames))) < cutoff


## behavior processing
def episode_to_dataframe(episode, world=None, number=np.nan, interpolate=False, smooth=False):
    # setup
    u_frames, ind = get_unique_frames(episode)
    df = pd.DataFrame(index=u_frames, columns=['time_stamp', 'episode', 'visible',
                            'prey_location', 'prey_velocity', 'prey_rotation',
                            'predator_location', 'predator_velocity', 'predator_rotation'])
    df.index.name = 'frame'
    df['episode'] = [number for i in range(len(df))]
    df['time_stamp'] = np.array(episode.trajectories.get('time_stamp'))[ind]

    # add captures
    captures = [np.argmin(np.abs(u_frames - c)) for c in episode.captures]
    df['captures'] = False
    df.iloc[captures, df.columns.get_loc('captures')] = True

    # add rewards
    rewards = [np.argmin(np.abs(df['time_stamp'] - r)) for r in episode.rewards_time_stamps]
    reward_id = np.nan
    if len(episode.rewards_sequence) > 0:
        reward_id = episode.rewards_sequence[0]
    df['reward_id'] = reward_id
    df['reward_location'] = [[np.nan, np.nan] for i in range(len(df))]
    if world and (len(episode.rewards_sequence) > 0):
        df['reward_location'] = [[world.cells[reward_id].location.x, 
                                 world.cells[reward_id].location.y] for i in range(len(df))]
    df['rewards'] = False
    if len(rewards) > 0:
        df.iloc[rewards, df.columns.get_loc('rewards')] = True

    # add position data
    df['prey_location'] = [[np.nan, np.nan] for i in range(len(df))]
    df['predator_location'] = [[np.nan, np.nan] for i in range(len(df))]
    agent_frames = {'prey': [], 'predator': []}
    for agent in ('prey', 'predator'):
        traj = episode.trajectories.where('agent_name', agent)
        if len(traj) > 1:
            locs = np.vstack([traj.get('location').get('x'), traj.get('location').get('y')]).T
            frames = traj.get('frame')
            t = np.array(traj.get('time_stamp'))
            if smooth:
                # locs, t = kalman_smoother(locs, t, return_results=False)
                locs, t = segmented_kalman_smoother(locs, t, gap_thresh=0.25)
            dist = np.sqrt(np.sum(np.diff(locs, axis=0)**2, axis=1))
            dt = np.diff(t)
            v = dist / dt
            v = np.concatenate([v, np.zeros(1)])
            df[f'{agent}_location'].loc[frames] = locs.tolist()
            df[f'{agent}_velocity'].loc[frames] = v
            df[f'{agent}_rotation'].loc[frames] = convert_angle(np.array(traj.get('rotation')))
            # agent_frames[agent] = {'frames': frames, 
            #                         'locs': locs}
            
    if interpolate:
        # interpolate missing frames
        for agent in ('prey', 'predator'):
            locs = np.vstack(df[f'{agent}_location'])
            locs = interpolate_short_nans_2d(locs, axis=0, max_run_length=180, max_delta=0.05)
            df[f'{agent}_location'] = locs.tolist()
            df[f'{agent}_velocity'] = get_velocity(locs, df['time_stamp'])

    if world:
        # calculate visibility
        w = get_world(world)
        vis = Location_visibility.from_world(w)
        visible = np.ones((len(df),1)) * np.nan
        for i in range(len(df)):
            row = df.iloc[i]
            if not np.isnan(row.prey_location[0]) and not np.isnan(row.predator_location[0]):
                is_visible = vis.is_visible(Location(row.prey_location[0], row.prey_location[1]),
                                            Location(row.predator_location[0], row.predator_location[1]))
                visible[i] = is_visible == 1
        df['visible'] = visible
    
    return df

def episodes_to_dict(episode_list, ideal_bin_width=0.1, fps=90, mask=None, world=None, return_dataframe=False, smooth=False):
    d = {'prey':   {'location': [], 
                    'time_stamp': [], 
                    'frame': [], 
                    'velocity': [], 
                    'outlier_frames': [],
                    'episode': [],
                    'occupancy': [],
                    'coverage': [],
                    'visible': []}, 
        'predator': {'location': [], 
                    'time_stamp': [], 
                    'frame': [], 
                    'velocity': [], 
                    'outlier_frames': [],
                    'episode': [],
                    'occupancy': [],
                    'coverage': [],
                    'visible': []}}

    # build from dataframes
    dfs = []
    for i,e in enumerate(episode_list):
        tmp = episode_to_dataframe(e, world, smooth=smooth)
        tmp['episode'] = i
        dfs.append(tmp)
    df = pd.concat(dfs)

    # append
    for agent in d.keys():
        vals = df[f'{agent}_location'].values
        if len(vals) > 0:
            I = ~np.any(np.isnan(np.vstack(vals)), axis=1)
        else:
            I = []         
        for key in d[agent].keys():
            df_key = [i for i in list(df.columns) if key in i]
            data = np.array([])
            if np.sum(I) > 0:
                if len(df_key) == 1:
                    data = np.vstack(df[df_key[0]].loc[I])
                elif len(df_key) == 2:
                    df_key = [i for i in df_key if agent in i]
                    data = np.vstack(df[df_key[0]].loc[I])
            if key == 'frame':
                data = df.index[I]
            d[agent][key].append(data)

    # reshape
    for agent in d.keys():
        for key in d[agent].keys():
            if len(d[agent][key]) > 0:
                d[agent][key] = np.vstack(d[agent][key])

    # occupancy/coverage
    bins, _, _ = make_map_bins(ideal_bin_width = ideal_bin_width)
    for agent in d.keys():
        d[agent]['time_stamp'] = np.sort(d[agent]['time_stamp']) # rarely, timestamps will come in out of order, which causes issues in other analysis
        if len(d[agent]['location']) > 1:
            d[agent]['occupancy'] = get_occupancy(d[agent]['location'][:,0], d[agent]['location'][:,1], bins, fps=fps)
            d[agent]['coverage'] = get_visit_histogram(d[agent]['location'][:,0], d[agent]['location'][:,1], bins=bins, mask=mask, dt=fps)

    if return_dataframe:
        return d, df
    else:
        return d

def align_agents(R, cutoff=0.01):
    data = R.trajectory_dict.copy()
    agents = ('prey', 'predator')
    index = {'prey': [], 'predator': []}
    timestamps = {'prey': np.sort(data['prey']['time_stamp']),
             'predator': np.sort(data['predator']['time_stamp'])}
    times = np.array([len(timestamps['prey']), len(timestamps['predator'])])
    agents = np.array(agents)[np.where((times / np.sum(times)) > cutoff)[0]]
    if len(agents) == 2:
        _, index['prey'], index['predator'] = np.intersect1d(timestamps['prey'], timestamps['predator'], return_indices=True)
    else:
        index[agents[0]] = np.arange(len(data[agents[0]]['velocity']))
        tracked = get_agent_tracked(data[agents[0]]['time_stamp'])
        tracked[tracked == 0] = np.nan
        data[agents[0]]['visible'] = tracked
    d = {'time_stamp': [], 'episode': [], 'visible': [], 
        'prey_location': [], 'prey_velocity': [], 
        'predator_location': [], 'predator_velocity': [],
        'prey_tracked': [], 'predator_tracked': []}
    for k in ('time_stamp', 'episode', 'visible'):
        tmp = []
        for agent in agents:
            tmp.append(data[agent][k][index[agent]])
        assert np.sum(np.diff(np.vstack(tmp),axis=0)) == 0, f'Detected a difference in pred/prey {k}'
        d[k] = tmp[0].squeeze()
    for agent in agents:
        d[f'{agent}_location'] = data[agent]['location'][index[agent]]
        d[f'{agent}_velocity'] = data[agent]['velocity'][index[agent]].squeeze()
        d[f'{agent}_tracked'] = get_agent_tracked(timestamps[agent][index[agent]])
    return d

def align_episode_agents(ep=Episode, cutoff=0.01):
    agents = ('prey', 'predator')
    index = {'prey': [], 'predator': []}
    trajectories = {'prey': ep.where('agent_name', 'prey'),
                    'predator': ep.where('agent_name', 'predator')}
    timestamps = {
        'prey': np.sort(np.array(trajectories['prey'].get('time_stamp'))),
        'predator': np.sort(np.array(trajectories['predator'].get('time_stamp')))
        }
    times = np.array([len(timestamps['prey']), len(timestamps['predator'])])
    agents = np.array(agents)[np.where((times / np.sum(times)) > cutoff)[0]]
    if len(agents) == 2:
        _, index['prey'], index['predator'] = np.intersect1d(timestamps['prey'], timestamps['predator'], return_indices=True)
    else:
        # align to prey by default
        index[agents[0]] = np.arange(len(timestamps[agents[0]]))
        tracked = get_agent_tracked(timestamps[agents[0]])
        tracked[tracked == 0] = np.nan
    d = {'time_stamp': [], 'frame': [], 
        'prey_location': [], 'predator_location': [],
        'prey_tracked': [], 'predator_tracked': []}
    for k in ('time_stamp', 'frame'):
        tmp = []
        for agent in agents:
            tmp.append(np.array(trajectories[agent].get(k)))
        assert np.sum(np.diff(np.vstack(tmp),axis=0)) == 0, f'Detected a difference in pred/prey {k}'
        d[k] = tmp[0].squeeze()
    for agent in agents:
        d[f'{agent}_location'] = np.array(trajectories[agent].get('location'))[index[agent]]
        d[f'{agent}_tracked'] = get_agent_tracked(timestamps[agent][index[agent]])
    return d

def format_behavior_data(R, agent='prey', kalman_filter=False, show_progress=False):
    if agent == 'both':
        d = align_agents(R)
        agent_present = [len(d[f'{a}_location']) for a in ('prey', 'predator')]
        assert (agent_present[0] > 0) | (agent_present[1] > 0), 'no agent data detected'
        agents = ('prey', 'predator')
        for i,a in enumerate(agent_present):
            if a == 0:
                print(f'Specified both agents but agent {agents[i]} not found... removing.')
                del d[f'{agents[i]}_location']; del d[f'{agents[i]}_velocity']

    else:
        assert (agent == 'prey') | (agent == 'predator'), f'agent must be prey or predator'
        d = R.trajectory_dict[agent].copy()
        d[f'{agent}_location'] = d.pop('location')
        d[f'{agent}_velocity'] = d.pop('velocity')
        d[f'{agent}_tracked'] = get_agent_tracked(d['time_stamp'])
        del d['occupancy']; del d['coverage']; del d['bins']; del d['fps']
    if kalman_filter:
        agents = [k.split('_')[0] for k in d.keys() if 'location' in k]
        for agent in agents:
            tracking_epochs = get_epochs(d[f'{agent}_tracked'], d['time_stamp'])
            for e in tqdm(range(tracking_epochs.shape[0]), disable=not show_progress, desc=f'kalman filtering {agent}'):
                I = (d['time_stamp'] >= tracking_epochs[e,0]) & (d['time_stamp'] < tracking_epochs[e,1])
                time = d['time_stamp'].squeeze()[I]
                locs = d[f'{agent}_location'][I,:]
                xs = kalman_smoother(locs, time)
                d[f'{agent}_location'][I,:] = xs
                d[f'{agent}_velocity'][I] = get_velocity(xs, time)
    return d

def get_agent_tracked(t, dt_cutoff=0.2, min_samps=3):
    ts = np.hstack((0,t,np.inf))
    I = (np.diff(ts) < dt_cutoff).astype(int)
    starts = np.where(np.diff(I) > 0)[0]
    stops = np.where(np.diff(I) < 0)[0]
    tracked = np.zeros(t.shape)
    for i in range(len(starts)):
        if stops[i] - starts[i] > min_samps:
            tracked[starts[i]:stops[i]] = 1
    return tracked

def interpolate_short_nans(arr, max_run_length=2, max_delta=np.inf):
    arr = np.array(arr).copy()
    is_nan = np.isnan(arr)
    
    # Identify runs of NaNs
    padded = np.pad(is_nan.astype(int), (1, 1), mode='constant')
    diff = np.diff(padded)

    starts = np.where(diff == 1)[0]
    ends   = np.where(diff == -1)[0]

    for start, end in zip(starts, ends):
        run_length = end - start
        if run_length <= max_run_length:
            # Check boundary conditions
            if start > 0 and end < len(arr):
                left_val = arr[start - 1]
                right_val = arr[end]
                if not np.isnan(left_val) and not np.isnan(right_val):
                    if abs(right_val - left_val) <= max_delta:
                        arr[start:end] = np.interp(
                            np.arange(start, end),
                            [start - 1, end],
                            [left_val, right_val]
                        )
    return arr

def get_outliers_index(x, threshold = 2):
  if threshold <= 0:
      raise ArithmeticError("threshold parameter should be > 0")
  threshold = sum(x)/len(x) * threshold
  last = x[0]
  outliers_index = []
  for i,v in enumerate(x):
      if abs(v-last) <= threshold:
          last = v
      else:
          outliers_index.append(i)
  return outliers_index

def nan_convolve(x, win=11):
    return convolve(x, np.ones(win)/win)


def clean_velocity(v, outlier_threshold = 2, win = int()):
    o = get_outliers_index(v, outlier_threshold)
    v_clean = np.array(v)
    v_clean[o] = np.nan
    if win:
        v_clean = convolve(v_clean, np.ones(win)/win)
    return v_clean

def get_world(world):
    assert world is not None, 'world must be a string or World object'
    if type(world) is str:
        return World.get_from_parameters_names('hexagonal', 'canonical', world)
    else:
        return world

def get_unique_frames(episode):
    return np.unique(episode.trajectories.get('frame'), return_index=True)

def recording_stats(R, cutoff=0.2):
    # mouse, datetime, experiment name, world, coverage, time spent in arena, total time, number of good units, number of clusters, number of place cells
    d = {'mouse': R.experiment_info['mouse'],
         'datetime': datetime.strptime(R.experiment_info['date'] + R.experiment_info['time'], '%Y%m%d%M%S'),
         'experiment': R.experiment_name,
         'suffix': R.experiment_info['suffix'],
         'world': R.experiment_info['world'],
         'coverage': np.nansum(R.trajectory_dict['prey']['coverage']>1) / np.sum(~np.isnan(R.trajectory_dict['prey']['coverage'])),
         'arena_time': len(R.trajectory_dict['prey']['visible']) / R.trajectory_dict['prey']['fps'],
         'total_time': R.duration,
         'n_episodes': len(R.episodes),
         'n_good_clusters': (R.clusters_info.KSLabel == 'good').sum(),
         'n_clusters': len(R.clusters_info),
         'n_place_cells': ((R.clusters_info.KSLabel == 'good') & (R.clusters_info.prey_place_cell) & (R.clusters_info.prey_spatial_info > cutoff)).sum()}
    return d


## event detection
def get_amplitude_events(amplitude, amplitude_cutoff=3, min_duration=0.02, min_interval=0.1, fs=30000):
    assert len(amplitude.shape) == 1, f'amplitude must be 1D (for now)'
    candidates = (amplitude > amplitude_cutoff).astype(int)
    starts = np.argwhere(np.diff(candidates) > 0)

    mean_crossings = (amplitude > 0).astype(int)
    crossing_starts = np.argwhere(np.diff(mean_crossings) > 0)
    crossing_stops = np.argwhere(np.diff(mean_crossings) < 0)

    true_starts = []
    true_stops = []
    for i,s in enumerate(starts):
        crossing_before = s - crossing_starts
        crossing_after = crossing_stops - s
        if not np.any(crossing_before > 0) or not np.any(crossing_after > 0):
            continue
        true_starts.append(s - np.min(crossing_before[crossing_before > 0]))
        true_stops.append(s + np.min(crossing_after[crossing_after > 0]))
    true_starts = np.array(true_starts)
    true_stops = np.array(true_stops)

    nearby_events = ((true_stops[1:] - true_starts[:-1]) / fs) < min_interval
    while np.sum(nearby_events) > 0:
        merges = np.argwhere(nearby_events)
        true_stops = np.delete(true_stops, merges)[:,np.newaxis]
        true_starts = np.delete(true_starts, merges+1)[:,np.newaxis]
        nearby_events = ((true_stops[1:] - true_starts[:-1]) / fs) < min_interval
        
    events = np.hstack([true_starts, true_stops])
    events = np.unique(events, axis=0)
    durations = np.diff(events, axis=1) / fs

    return events[durations.squeeze() > min_duration, :]

def clean_events(on_ev, off_ev):
    # if signal started high, discard first off event
    if off_ev[0] < on_ev[0]:
        off_ev = np.delete(off_ev, 0)

    # if signal ended high, discard last on event
    if off_ev[-1] < on_ev[-1]:
        on_ev = np.delete(on_ev, -1)

    return on_ev, off_ev

def get_runs(is_valid, max_gap=1, min_duration=2):
    is_valid = np.atleast_1d(is_valid)
    if is_valid.sum() > 0:
        diff = np.diff(is_valid.astype(int))
        starts = np.where(diff == 1)[0] + 1
        stops = np.where(diff == -1)[0] + 1
        if is_valid[0]:
            starts = np.insert(starts, 0, 0)
        if is_valid[-1]:
            stops = np.append(stops, len(is_valid))

        merged_starts = [starts[0]]
        merged_stops = []

        for i in range(1, len(starts)):
            gap = starts[i] - stops[i-1]
            if gap <= max_gap:
                # extend previous run
                continue
            else:
                # close previous run
                merged_stops.append(stops[i-1])
                merged_starts.append(starts[i])
        merged_stops.append(stops[-1])

        merged_starts = np.array(merged_starts)
        merged_stops = np.array(merged_stops)
        durations = merged_stops - merged_starts

        valid = durations >= min_duration
        filtered_starts = merged_starts[valid]
        filtered_stops = merged_stops[valid]
        filtered_durations = durations[valid]

        return list(zip(filtered_starts, filtered_stops, filtered_durations))
    
    else:
        return [[np.nan],[np.nan],[np.nan]]

def get_run_filter(x, max_gap=1, min_duration=2):
    runs = get_runs(x, max_gap=max_gap, min_duration=min_duration)
    bool_mask = np.zeros_like(x, dtype=bool)
    for run in runs:
        start, stop, duration = run
        bool_mask[start:stop] = True
    return bool_mask

def get_threshold_events(signal, threshold, edge_threshold=0, min_gap=1, min_duration=2):
    above_main = signal > threshold
    core_runs = get_runs(above_main, min_duration=min_duration)
    expanded_events = []

    for start, stop, _ in core_runs:
        # Backtrack to edge_threshold
        left = start
        while left > 0 and signal[left - 1] > edge_threshold:
            left -= 1

        # Forward-track to edge_thresh
        right = stop
        while right < len(signal) and signal[right] > edge_threshold:
            right += 1

        expanded_events.append((left, right, right - left))

    # Merge close events
    if not expanded_events:
        return []

    merged = [expanded_events[0]]
    for start, stop, _ in expanded_events[1:]:
        prev_start, prev_stop, _ = merged[-1]
        if start - prev_stop <= min_gap:
            # merge with previous
            new_start = prev_start
            new_stop = stop
            merged[-1] = (new_start, new_stop, new_stop - new_start)
        else:
            merged.append((start, stop, stop - start))

    return merged

def find_step_change_global(y, min_seg=50):
    """
    Find split k that best fits y ~ c1 (0..k-1), c2 (k..n-1), ignoring NaNs.
    Returns: (k, c1, c2, improvement)
      - k is the first index of the "after" segment
      - improvement is how much SSE is reduced versus single-level fit
    """
    y = np.asarray(y, dtype=float)
    n = y.size

    valid = ~np.isnan(y)
    x = np.where(valid, y, 0.0)
    c = valid.astype(float)

    # cumulative sums
    S  = np.cumsum(x)
    C  = np.cumsum(c)
    S2 = np.cumsum(x * x)

    total_S  = S[-1]
    total_C  = C[-1]
    total_S2 = S2[-1]

    if total_C < 2 * min_seg:
        raise ValueError("Not enough non-NaN samples for the requested min_seg.")

    # k splits into [0..k-1] and [k..n-1]
    ks = np.arange(1, n)  # possible split points

    C1 = C[ks - 1]
    S1 = S[ks - 1]
    S21 = S2[ks - 1]

    C2 = total_C - C1
    S2sum = total_S - S1
    S22 = total_S2 - S21

    # enforce min_seg non-NaN points in each segment
    ok = (C1 >= min_seg) & (C2 >= min_seg)

    # means
    m1 = np.empty_like(S1); m1[:] = np.nan
    m2 = np.empty_like(S2sum); m2[:] = np.nan
    m1[ok] = S1[ok] / C1[ok]
    m2[ok] = S2sum[ok] / C2[ok]

    # SSE for each side: sum(y^2) - 2*m*sum(y) + m^2*count
    sse1 = np.full_like(S1, np.inf, dtype=float)
    sse2 = np.full_like(S1, np.inf, dtype=float)
    sse1[ok] = S21[ok] - 2*m1[ok]*S1[ok] + (m1[ok]**2)*C1[ok]
    sse2[ok] = S22[ok] - 2*m2[ok]*S2sum[ok] + (m2[ok]**2)*C2[ok]

    sse = sse1 + sse2

    best_idx = np.argmin(sse)
    k = int(ks[best_idx])
    c1 = float(m1[best_idx])
    c2 = float(m2[best_idx])

    # baseline SSE (single level)
    m0 = total_S / total_C
    sse0 = total_S2 - 2*m0*total_S + (m0**2)*total_C
    improvement = float(sse0 - sse[best_idx])

    return k, c1, c2, improvement


## cellworld plotting
def get_experiment_world(experiment_str):
    if ('FULL' in experiment_str) or ('full' in experiment_str):
        if 'oasis_14_02_00' in experiment_str:
            w = World.get_from_parameters_names('hexagonal', 'canonical', 'oasis_14_02_00')
        elif 'oasis_14_02_01' in experiment_str:
            w = World.get_from_parameters_names('hexagonal', 'canonical', 'oasis_14_02_01')
        else:
            w = World.get_from_parameters_names('hexagonal', 'canonical', 'oasis_14_02')
    else:
        w = World.get_from_parameters_names('hexagonal', 'canonical', '00_00')
    return w


### episode cleaning functions
def remove_bad_start_detections(episode,
                                far_from_entrance_thresh=0.03,
                                near_entrance_thresh=0.035,
                                robot_time_tolerance_sec=5.0,
                                robot_check_sec=5.0,
                                min_robot_close_points=1,
                                min_near_entrance_points=3,
                                robot_close_thresh=0.15,
                                ):
    mouse_traj = episode.trajectories.where('agent_name', 'prey')
    mouse_t = mouse_traj.get('time_stamp')
    mouse_f = mouse_traj.get('frame')
    mouse_xy = np.vstack([mouse_traj.get('location').get('x'), mouse_traj.get('location').get('y')]).T

    robot_traj = episode.trajectories.where('agent_name', 'predator')
    robot_t = robot_traj.get('time_stamp')
    robot_xy = np.vstack([robot_traj.get('location').get('x'), robot_traj.get('location').get('y')]).T

    res = detect_robot_as_mouse(mouse_t, mouse_xy, robot_t, robot_xy, 
                                far_from_entrance_thresh=far_from_entrance_thresh,
                                near_entrance_thresh=near_entrance_thresh,
                                robot_time_tolerance_sec=robot_time_tolerance_sec,
                                robot_check_sec=robot_check_sec,
                                min_robot_close_points=min_robot_close_points,
                                min_near_entrance_points=min_near_entrance_points,
                                robot_close_thresh=robot_close_thresh,
                                )

    if res['flag']:
        clean_trajectory = Trajectories()
        try:
            first_good_frame = mouse_f[res['near_entrance_mouse_i'][0]]
            for step in episode.trajectories:
                if step.agent_name == 'prey':
                    if step.frame >= first_good_frame:
                        clean_trajectory.append(step)
                else:
                    clean_trajectory.append(step)
        except:
            print('No good start detected')
        episode.trajectories = clean_trajectory

    return episode, res


def interpolate_short_nans_2d(arr2d, axis=1, max_run_length=2, max_delta=np.inf):
    arr2d = np.array(arr2d).copy()
    
    # Select axis: rows (1) or columns (0)
    def interpolate_line(arr1d):
        is_nan = np.isnan(arr1d)
        padded = np.pad(is_nan.astype(int), (1, 1), mode='constant')
        diff = np.diff(padded)

        starts = np.where(diff == 1)[0]
        ends   = np.where(diff == -1)[0]

        for start, end in zip(starts, ends):
            run_length = end - start
            if run_length <= max_run_length:
                if start > 0 and end < len(arr1d):
                    left_val = arr1d[start - 1]
                    right_val = arr1d[end]
                    if not np.isnan(left_val) and not np.isnan(right_val):
                        if abs(right_val - left_val) <= max_delta:
                            arr1d[start:end] = np.interp(
                                np.arange(start, end),
                                [start - 1, end],
                                [left_val, right_val]
                            )
        return arr1d

    # Apply row-wise or column-wise
    if axis == 1:
        return np.apply_along_axis(interpolate_line, axis=1, arr=arr2d)
    elif axis == 0:
        return np.apply_along_axis(interpolate_line, axis=0, arr=arr2d)
    else:
        raise ValueError("Axis must be 0 (columns) or 1 (rows)")

def clean_boolean_time_jumps(timestamps, flags, threshold=1):
    timestamps = np.asarray(timestamps.copy())
    flags = np.asarray(flags.copy(), dtype=bool)
    
    if len(timestamps) != len(flags):
        raise ValueError("Timestamps and flags must be the same length.")

    # Compute time differences
    diffs = np.diff(timestamps)

    # Find indices where the jump is greater than threshold
    jump_indices = np.where(diffs > threshold)[0]

    # Set the flag at index before jump to False (ends "high" case)
    for i in jump_indices:
        flags[i] = False
    
    # Set the flag at index after jump to False (starts "high" case)
    for i in jump_indices:
        if i + 1 < len(flags):  # Make sure we don't go out of bounds
            flags[i + 1] = False

    return flags

def clean_episode_tracking(episode, threshold_distance=0.25):
    if len(episode.trajectories) == 0:
        return episode
    agent_trajectory = episode.trajectories.get_agent_trajectory('prey')
    clean_trajectory = Trajectories()
    prev_prey_location = agent_trajectory[0].location

    for i, step in enumerate(episode.trajectories):
        if step.agent_name == 'prey':
            # Compare to previous prey observation (sharp jump detection)
            dist = prev_prey_location.dist(step.location)

            if dist > threshold_distance:
                continue
            else:
                clean_trajectory.append(step)
                prev_prey_location = step.location  # update only when accepted
        else:
            clean_trajectory.append(step)

    episode.trajectories = clean_trajectory
    return episode

def bad_episode_tracking(episode, threshold_distance = 0.1, agent_name = 'prey'):
    agent_trajectory = episode.trajectories.get_agent_trajectory(agent_name)
    last_location = None
    flag = False
    for i,step in enumerate(agent_trajectory):
        if last_location is not None:
            if last_location.dist(step.location) > threshold_distance:
                print(i, last_location.dist(step.location),)
                flag = True
                break
        last_location = step.location
    return flag

def clean_episode_timestamps(episode):
    frames = episode.trajectories.get('frame')
    dt = episode.trajectories.get('time_stamp')[1] - episode.trajectories.get('time_stamp')[0]
    if dt < 0:
        episode.trajectories[0].time_stamp = 0
    if frames[0] > 0:
        last_frame = frames[0]
        for i,step in enumerate(episode.trajectories):
            if step.frame == last_frame:
                episode.trajectories[i].frame = 0
            else:
                break
    return episode

def detect_robot_as_mouse_at_start_async(
    t_mouse,
    mouse_xy,
    t_robot,
    robot_xy,
    entrance=(0.0, 0.5),

    # Fixed thresholds you asked for:
    far_from_entrance_thresh=0.2,
    near_entrance_thresh=0.1,

    # Strong robot-proximity evidence near start:
    robot_close_thresh=0.3,
    robot_check_sec=1.0,
    robot_time_tolerance_sec=1.0,
    min_robot_close_points=0,

    # "Real mouse enters later" evidence:
    # Search long after start; default no limit.
    max_search_sec=np.inf,
    min_near_entrance_points=2,

    # Robustness: require near-entrance points to be separated in time (avoid single-frame glitches)
    min_near_separation_sec=0.1,
):
    """
    Detects robot misdetected as mouse at the beginning for async mouse/robot streams.

    Misdetect criteria:
      A) First valid mouse detection is far from entrance (> 0.2 by default)
      B) In the first robot_check_sec after first mouse detection:
           mouse points are close to robot (< robot_close_thresh) when time-matched within robot_time_tolerance_sec
           for at least min_robot_close_points samples
      C) At some later time (can be minutes later):
           mouse is detected near entrance (< 0.1) at least min_near_entrance_points times
           with optional time-separation constraint (min_near_separation_sec)

    Inputs:
      t_mouse (Nm,), mouse_xy (Nm,2)
      t_robot (Nr,), robot_xy (Nr,2)
      NaNs allowed for missing detections.

    Returns dict with flag + diagnostics.
    """

    t_mouse = np.asarray(t_mouse, dtype=float)
    mouse_xy = np.asarray(mouse_xy, dtype=float)
    t_robot = np.asarray(t_robot, dtype=float)
    robot_xy = np.asarray(robot_xy, dtype=float)

    if mouse_xy.ndim != 2 or mouse_xy.shape[1] != 2:
        raise ValueError("mouse_xy must be shape (Nm,2)")
    if robot_xy.ndim != 2 or robot_xy.shape[1] != 2:
        raise ValueError("robot_xy must be shape (Nr,2)")
    if t_mouse.shape[0] != mouse_xy.shape[0]:
        raise ValueError("t_mouse and mouse_xy must have same length")
    if t_robot.shape[0] != robot_xy.shape[0]:
        raise ValueError("t_robot and robot_xy must have same length")

    entrance = np.asarray(entrance, dtype=float)

    mouse_valid = ~np.isnan(mouse_xy).any(axis=1)
    robot_valid = ~np.isnan(robot_xy).any(axis=1)

    if not np.any(mouse_valid):
        return {
            "flag": False,
            "reason": "no_mouse_detections",
            "first_mouse_i": None,
            "first_mouse_t": None,
            "first_mouse_dist_entrance": None,
            "robot_close_mouse_i": np.array([], dtype=int),
            "robot_close_pairs": [],
            "near_entrance_mouse_i": np.array([], dtype=int),
        }

    # Sort robot by time for nearest-neighbor time matching
    r_order = np.argsort(t_robot)
    t_robot_s = t_robot[r_order]
    robot_xy_s = robot_xy[r_order]
    robot_valid_s = robot_valid[r_order]

    def _nearest_robot_index(tq):
        """Return (sorted_robot_index, |dt|) for nearest valid robot sample to tq."""
        k = int(np.searchsorted(t_robot_s, tq))
        candidates = []
        if 0 <= k < len(t_robot_s): candidates.append(k)
        if 0 <= k - 1 < len(t_robot_s): candidates.append(k - 1)

        best = None
        best_dt = np.inf
        for kk in candidates:
            if not robot_valid_s[kk]:
                continue
            dt = abs(t_robot_s[kk] - tq)
            if dt < best_dt:
                best_dt = dt
                best = kk
        return best, best_dt

    # First valid mouse detection (as ordered in mouse stream)
    first_mouse_i = int(np.argmax(mouse_valid))
    first_mouse_t = float(t_mouse[first_mouse_i])
    first_mouse_dist_entrance = float(np.linalg.norm(mouse_xy[first_mouse_i] - entrance))

    # Gate A: far from entrance
    if first_mouse_dist_entrance <= far_from_entrance_thresh:
        return {
            "flag": False,
            "reason": "first_mouse_not_far_from_entrance",
            "first_mouse_i": first_mouse_i,
            "first_mouse_t": first_mouse_t,
            "first_mouse_dist_entrance": first_mouse_dist_entrance,
            "robot_close_mouse_i": np.array([], dtype=int),
            "robot_close_pairs": [],
            "near_entrance_mouse_i": np.array([], dtype=int),
        }

    # Gate B: early mouse points should match robot (time-matched) and be spatially close
    t0 = first_mouse_t
    t_end_robotcheck = t0 + float(robot_check_sec)

    start_window = (t_mouse >= t0) & (t_mouse <= t_end_robotcheck) & mouse_valid
    start_mouse_is = np.where(start_window)[0]

    close_pairs = []
    close_mouse_is = []

    for mi in start_mouse_is:
        rj_s, dt = _nearest_robot_index(t_mouse[mi])
        if rj_s is None or dt > robot_time_tolerance_sec:
            continue
        dist = float(np.linalg.norm(mouse_xy[mi] - robot_xy_s[rj_s]))
        if dist < robot_close_thresh:
            rj = int(r_order[rj_s])  # back to original robot index
            close_pairs.append((int(mi), int(rj), float(dt), dist))
            close_mouse_is.append(int(mi))

    close_mouse_is = np.array(close_mouse_is, dtype=int)

    if (close_mouse_is.size < min_robot_close_points) and (close_mouse_is.size > 0):
        return {
            "flag": False,
            "reason": "mouse_not_close_to_robot_at_start",
            "first_mouse_i": first_mouse_i,
            "first_mouse_t": first_mouse_t,
            "first_mouse_dist_entrance": first_mouse_dist_entrance,
            "robot_close_mouse_i": close_mouse_is,
            "robot_close_pairs": close_pairs,
            "near_entrance_mouse_i": np.array([], dtype=int),
        }

    # Gate C: real mouse appears near entrance at ANY later time (can be minutes later)
    # We search from t0 to t0 + max_search_sec (default inf = rest of stream).
    t_end_search = t0 + float(max_search_sec) if np.isfinite(max_search_sec) else np.inf
    later_window = (t_mouse >= t0) & (t_mouse <= t_end_search) & mouse_valid
    later_mouse_is = np.where(later_window)[0]

    if later_mouse_is.size == 0:
        return {
            "flag": False,
            "reason": "no_mouse_detections_after_start",
            "first_mouse_i": first_mouse_i,
            "first_mouse_t": first_mouse_t,
            "first_mouse_dist_entrance": first_mouse_dist_entrance,
            "robot_close_mouse_i": close_mouse_is,
            "robot_close_pairs": close_pairs,
            "near_entrance_mouse_i": np.array([], dtype=int),
        }

    d_entr = np.linalg.norm(mouse_xy[later_mouse_is] - entrance, axis=1)
    near_candidates = later_mouse_is[d_entr < near_entrance_thresh]
    near_candidates = near_candidates.astype(int)

    # Optional de-glitch: enforce a minimal separation in time between counted near-entrance points
    near_hits = []
    last_t = -np.inf
    for mi in near_candidates:
        tm = float(t_mouse[mi])
        if tm - last_t >= float(min_near_separation_sec):
            near_hits.append(mi)
            last_t = tm

    near_mouse_is = np.array(near_hits, dtype=int)
    

    if (near_mouse_is.size < min_near_entrance_points) and (near_mouse_is.size > 0):
        return {
            "flag": False,
            "reason": "no_later_near_entrance_mouse",
            "first_mouse_i": first_mouse_i,
            "first_mouse_t": first_mouse_t,
            "first_mouse_dist_entrance": first_mouse_dist_entrance,
            "robot_close_mouse_i": close_mouse_is,
            "robot_close_pairs": close_pairs,
            "near_entrance_mouse_i": near_mouse_is,
        }

    return {
        "flag": True,
        "reason": "robot_misdetected_as_mouse_at_start",
        "first_mouse_i": first_mouse_i,
        "first_mouse_t": first_mouse_t,
        "first_mouse_dist_entrance": first_mouse_dist_entrance,
        "robot_close_mouse_i": close_mouse_is,
        "robot_close_pairs": close_pairs,      # (mouse_i, robot_j, |dt|, dist)
        "near_entrance_mouse_i": near_mouse_is,
    }


def detect_robot_as_mouse(
    t_mouse,
    mouse_xy,
    t_robot,
    robot_xy,
    entrance=(0.0, 0.5),

    # Fixed thresholds you asked for:
    far_from_entrance_thresh=0.2,
    near_entrance_thresh=0.1,

    # Strong robot-proximity evidence near start:
    robot_close_thresh=0.3,
    robot_check_sec=1.0,
    robot_time_tolerance_sec=1.0,
    min_robot_close_points=0,

    # NEW: only used to test whether robot is missing *right at the start*
    robot_missing_sec=0.1,
    max_robot_valid_in_missing=1,

    # "Real mouse enters later" evidence:
    max_search_sec=np.inf,
    min_near_entrance_points=2,

    # Robustness
    min_near_separation_sec=0.1,
):
    """
    Detects robot misdetected as mouse at the beginning for async mouse/robot streams.

    Far-start mode (original intent):
      A) First valid mouse detection is far from entrance
      B) Early mouse points match robot (time-matched) and spatially close (optional)
      C) Later, mouse appears near entrance

    Entrance-start mode (added earlier):
      - allows first mouse detection near entrance, but requires:
          * >=1 close robot-match in [t0, t0+robot_check_sec]
          * robot is "effectively missing" in a SHORT window [t0, t0+robot_missing_sec]
          * later entrance evidence counted AFTER initial robot_check_sec window
          * depart then re-enter safeguard
    """

    t_mouse = np.asarray(t_mouse, dtype=float)
    mouse_xy = np.asarray(mouse_xy, dtype=float)
    t_robot = np.asarray(t_robot, dtype=float)
    robot_xy = np.asarray(robot_xy, dtype=float)

    if mouse_xy.ndim != 2 or mouse_xy.shape[1] != 2:
        raise ValueError("mouse_xy must be shape (Nm,2)")
    if robot_xy.ndim != 2 or robot_xy.shape[1] != 2:
        raise ValueError("robot_xy must be shape (Nr,2)")
    if t_mouse.shape[0] != mouse_xy.shape[0]:
        raise ValueError("t_mouse and mouse_xy must have same length")
    if t_robot.shape[0] != robot_xy.shape[0]:
        raise ValueError("t_robot and robot_xy must have same length")

    entrance = np.asarray(entrance, dtype=float)

    mouse_valid = ~np.isnan(mouse_xy).any(axis=1)
    robot_valid = ~np.isnan(robot_xy).any(axis=1)

    if not np.any(mouse_valid):
        return {
            "flag": False,
            "reason": "no_mouse_detections",
            "first_mouse_i": None,
            "first_mouse_t": None,
            "first_mouse_dist_entrance": None,
            "robot_close_mouse_i": np.array([], dtype=int),
            "robot_close_pairs": [],
            "near_entrance_mouse_i": np.array([], dtype=int),
        }

    # Sort robot by time for nearest-neighbor time matching
    r_order = np.argsort(t_robot)
    t_robot_s = t_robot[r_order]
    robot_xy_s = robot_xy[r_order]
    robot_valid_s = robot_valid[r_order]

    def _nearest_robot_index(tq):
        """Return (sorted_robot_index, |dt|) for nearest valid robot sample to tq."""
        k = int(np.searchsorted(t_robot_s, tq))
        candidates = []
        if 0 <= k < len(t_robot_s): candidates.append(k)
        if 0 <= k - 1 < len(t_robot_s): candidates.append(k - 1)

        best = None
        best_dt = np.inf
        for kk in candidates:
            if not robot_valid_s[kk]:
                continue
            dt = abs(t_robot_s[kk] - tq)
            if dt < best_dt:
                best_dt = dt
                best = kk
        return best, best_dt

    # First valid mouse detection (as ordered in mouse stream)
    first_mouse_i = int(np.argmax(mouse_valid))
    first_mouse_t = float(t_mouse[first_mouse_i])
    first_mouse_dist_entrance = float(np.linalg.norm(mouse_xy[first_mouse_i] - entrance))

    # Decide start mode
    if first_mouse_dist_entrance > float(far_from_entrance_thresh):
        start_mode = "far_start"
    elif first_mouse_dist_entrance <= float(near_entrance_thresh):
        start_mode = "entrance_start"
    else:
        start_mode = "buffer_zone"

    if start_mode == "buffer_zone":
        return {
            "flag": False,
            "reason": "first_mouse_not_far_from_entrance",
            "first_mouse_i": first_mouse_i,
            "first_mouse_t": first_mouse_t,
            "first_mouse_dist_entrance": first_mouse_dist_entrance,
            "robot_close_mouse_i": np.array([], dtype=int),
            "robot_close_pairs": [],
            "near_entrance_mouse_i": np.array([], dtype=int),
        }

    # Gate B: early mouse points should match robot (time-matched) and be spatially close
    t0 = first_mouse_t
    t_end_robotcheck = t0 + float(robot_check_sec)

    start_window = (t_mouse >= t0) & (t_mouse <= t_end_robotcheck) & mouse_valid
    start_mouse_is = np.where(start_window)[0]

    close_pairs = []
    close_mouse_is = []

    for mi in start_mouse_is:
        rj_s, dt = _nearest_robot_index(t_mouse[mi])
        if rj_s is None or dt > float(robot_time_tolerance_sec):
            continue
        dist = float(np.linalg.norm(mouse_xy[mi] - robot_xy_s[rj_s]))
        if dist < float(robot_close_thresh):
            rj = int(r_order[rj_s])  # back to original robot index
            close_pairs.append((int(mi), int(rj), float(dt), dist))
            close_mouse_is.append(int(mi))

    close_mouse_is = np.array(close_mouse_is, dtype=int)

    # Entrance-start: require at least some robot proximity evidence somewhere in the window
    required_close = int(min_robot_close_points)
    if start_mode == "entrance_start":
        required_close = max(1, required_close)

        # FIX: do NOT look across robot_check_sec (could be 5s).
        # Instead, require robot is "effectively missing" only right after t0 in a short window.
        t_missing_end = t0 + float(robot_missing_sec)
        robot_valid_missing_count = int(np.sum(
            (t_robot_s >= t0) & (t_robot_s <= t_missing_end) & robot_valid_s
        ))
        if robot_valid_missing_count > int(max_robot_valid_in_missing):
            return {
                "flag": False,
                "reason": "robot_present_near_start",
                "first_mouse_i": first_mouse_i,
                "first_mouse_t": first_mouse_t,
                "first_mouse_dist_entrance": first_mouse_dist_entrance,
                "robot_close_mouse_i": close_mouse_is,
                "robot_close_pairs": close_pairs,
                "near_entrance_mouse_i": np.array([], dtype=int),
                "robot_valid_missing_count": robot_valid_missing_count,
            }

    # Gate B enforcement (BUGFIX): if min/required > 0, 0 close points must FAIL.
    if required_close > 0 and close_mouse_is.size < required_close:
        return {
            "flag": False,
            "reason": "mouse_not_close_to_robot_at_start",
            "first_mouse_i": first_mouse_i,
            "first_mouse_t": first_mouse_t,
            "first_mouse_dist_entrance": first_mouse_dist_entrance,
            "robot_close_mouse_i": close_mouse_is,
            "robot_close_pairs": close_pairs,
            "near_entrance_mouse_i": np.array([], dtype=int),
        }

    # Gate C: later entrance evidence
    search_start_t = t0 if start_mode == "far_start" else (t0 + float(robot_check_sec))
    t_end_search = t0 + float(max_search_sec) if np.isfinite(max_search_sec) else np.inf
    later_window = (t_mouse >= search_start_t) & (t_mouse <= t_end_search) & mouse_valid
    later_mouse_is = np.where(later_window)[0]

    if later_mouse_is.size == 0:
        return {
            "flag": False,
            "reason": "no_mouse_detections_after_start",
            "first_mouse_i": first_mouse_i,
            "first_mouse_t": first_mouse_t,
            "first_mouse_dist_entrance": first_mouse_dist_entrance,
            "robot_close_mouse_i": close_mouse_is,
            "robot_close_pairs": close_pairs,
            "near_entrance_mouse_i": np.array([], dtype=int),
        }

    d_entr = np.linalg.norm(mouse_xy[later_mouse_is] - entrance, axis=1)
    near_candidates = later_mouse_is[d_entr < float(near_entrance_thresh)].astype(int)

    near_hits = []
    last_t = -np.inf
    for mi in near_candidates:
        tm = float(t_mouse[mi])
        if tm - last_t >= float(min_near_separation_sec):
            near_hits.append(mi)
            last_t = tm

    near_mouse_is = np.array(near_hits, dtype=int)

    if int(min_near_entrance_points) > 0 and near_mouse_is.size < int(min_near_entrance_points):
        return {
            "flag": False,
            "reason": "no_later_near_entrance_mouse",
            "first_mouse_i": first_mouse_i,
            "first_mouse_t": first_mouse_t,
            "first_mouse_dist_entrance": first_mouse_dist_entrance,
            "robot_close_mouse_i": close_mouse_is,
            "robot_close_pairs": close_pairs,
            "near_entrance_mouse_i": near_mouse_is,
        }

    # Entrance-start safeguard: depart then re-enter
    if start_mode == "entrance_start" and near_mouse_is.size > 0:
        t_first_later_near = float(t_mouse[near_mouse_is[0]])
        between = (t_mouse >= t0) & (t_mouse <= t_first_later_near) & mouse_valid
        if np.any(between):
            d_between = np.linalg.norm(mouse_xy[between] - entrance, axis=1)
            if not np.any(d_between > float(far_from_entrance_thresh)):
                return {
                    "flag": False,
                    "reason": "no_departure_before_later_entrance",
                    "first_mouse_i": first_mouse_i,
                    "first_mouse_t": first_mouse_t,
                    "first_mouse_dist_entrance": first_mouse_dist_entrance,
                    "robot_close_mouse_i": close_mouse_is,
                    "robot_close_pairs": close_pairs,
                    "near_entrance_mouse_i": near_mouse_is,
                }

    return {
        "flag": True,
        "reason": "robot_misdetected_as_mouse_at_start",
        "first_mouse_i": first_mouse_i,
        "first_mouse_t": first_mouse_t,
        "first_mouse_dist_entrance": first_mouse_dist_entrance,
        "robot_close_mouse_i": close_mouse_is,
        "robot_close_pairs": close_pairs,
        "near_entrance_mouse_i": near_mouse_is,
    }




from collections import deque

def remove_swap_frames(
    episode,
    threshold_distance=0.12,      # "far from prey anchor" (try 0.08–0.15)
    anchor_k=8,                  # rolling anchor size
    reacquire_distance=0.08,      # "back near anchor" -> drop suspect
    max_suspect_len=60,           # if suspect lasts this long, consider promoting
    promote_requires_motion=True,
    stuck_eps=0.003,              # per-step movement below this counts as stuck
    stuck_min_steps=4,            # how many consecutive tiny moves to call it stuck
):
    """
    Removes prey points likely caused by predator/robot being mislabeled as prey, or tracker latching
    onto a fixed point.

    Strategy:
      - Keep a rolling anchor from accepted prey points.
      - If a prey point is far from anchor, buffer it as 'suspect' (do NOT re-anchor yet).
      - If prey returns near anchor soon -> drop the suspect run.
      - Only if suspect persists long enough AND isn't stuck (and looks like real motion)
        do we accept it and re-anchor.

    Keeps all non-prey steps unchanged.
    """

    clean_trajectory = Trajectories()
    anchor_buf = deque(maxlen=anchor_k)     # accepted prey locations

    suspect_steps = []                      # buffered prey steps (potentially bad)
    suspect_locs  = []                      # their locations (for motion/stuck tests)

    def _anchor_location():
        ax = sum(p.x for p in anchor_buf) / len(anchor_buf)
        ay = sum(p.y for p in anchor_buf) / len(anchor_buf)
        return Location(ax, ay)

    def _is_stuck(locs):
        """True if last stuck_min_steps movements are all < stuck_eps."""
        if len(locs) < stuck_min_steps + 1:
            return False
        small = 0
        for i in range(-stuck_min_steps, 0):
            if locs[i].dist(locs[i-1]) < stuck_eps:
                small += 1
        return small == stuck_min_steps

    def _has_real_motion(locs):
        """Heuristic: total path length in suspect run should exceed some amount if it's real prey."""
        if len(locs) < 2:
            return False
        path = 0.0
        for a, b in zip(locs[:-1], locs[1:]):
            path += a.dist(b)
        # require at least a few "normal" steps worth of motion
        return path > (stuck_eps * 5)

    for step in episode.trajectories:
        if step.agent_name != "prey":
            # keep everything else
            clean_trajectory.append(step)
            continue

        loc = step.location

        # bootstrap anchor
        if len(anchor_buf) == 0:
            anchor_buf.append(loc)
            clean_trajectory.append(step)
            continue

        anchor = _anchor_location()
        dist_anchor = anchor.dist(loc)

        # --- if not currently in suspect mode ---
        if len(suspect_steps) == 0:
            if dist_anchor <= threshold_distance:
                # normal prey point
                clean_trajectory.append(step)
                anchor_buf.append(loc)
            else:
                # start suspect run
                suspect_steps.append(step)
                suspect_locs.append(loc)
            continue

        # --- if we ARE in suspect mode, extend or resolve it ---
        suspect_steps.append(step)
        suspect_locs.append(loc)

        # 1) If prey comes back near anchor, treat the whole suspect run as bad and drop it
        if dist_anchor <= reacquire_distance:
            # drop suspect run, accept this point, resume
            suspect_steps.clear()
            suspect_locs.clear()
            clean_trajectory.append(step)
            anchor_buf.append(loc)
            continue

        # 2) If suspect run looks "stuck" (latched), keep dropping until reacquire
        if _is_stuck(suspect_locs):
            # do nothing: keep buffering/dropping; we'll only exit on reacquire or promotion timeout
            continue

        # 3) If it lasts long enough, maybe it's a true regime change (e.g., tracker restarted)
        if len(suspect_steps) >= max_suspect_len:
            if promote_requires_motion and not _has_real_motion(suspect_locs):
                # still looks like latch; keep waiting
                continue

            # promote: accept the buffered steps and re-anchor onto the new track
            for s in suspect_steps:
                clean_trajectory.append(s)
                anchor_buf.append(s.location)

            suspect_steps.clear()
            suspect_locs.clear()
            continue

        # Otherwise: keep buffering (effectively dropping them for now)

    # If episode ends while in suspect mode: safest default is to DROP them
    # (If you prefer, you can promote at the end instead.)
    episode.trajectories = clean_trajectory
    return episode


def _coerce_tracked(x):
    """
    Convert array-like with {True, False, 1, 0, nan} to strict boolean:
    only literal True / 1 counts as tracked; nan -> False.
    """
    a = np.asarray(x)

    if a.dtype == object:
        return a == True  # noqa: E712

    if np.issubdtype(a.dtype, np.number):
        out = np.zeros(a.shape, dtype=bool)
        finite = np.isfinite(a)
        out[finite] = (a[finite].astype(float) != 0.0)
        return out

    if a.dtype == bool:
        return a

    return a == True  # noqa: E712


def remove_false_entrance_detections(
    fused_xy,                   # (T,2) float; NaNs allowed
    arena_tracked,              # (T,) True/False/nan or 1/0/nan
    entrance_tracked,           # (T,) True/False/nan or 1/0/nan
    t=None,                     # (T,) seconds; if None uses frame index
    max_speed=0.8,              # units/sec from last trusted arena anchor
    jump_dist=0.15,             # absolute distance from anchor considered impossible during dropout
    quarantine_sec=5.0,         # once triggered, keep filtering for this long (while arena missing)
    remove_to=np.nan,           # value to write when removing
    require_entrance_flag=True, # if True: only remove when entrance_tracked is True; if False: remove any far point during quarantine
):
    """
    Behavior:
      1) Use last valid (arena_tracked==True) fused position as anchor.
      2) When arena_tracked==False AND entrance_tracked==True AND fused point is implausible
         (speed > max_speed OR dist > jump_dist), trigger quarantine.
      3) While quarantined and arena is still missing, remove *intermittent* entrance detections that
         are far/fast relative to the same anchor, even if they are not consecutive.
      4) Quarantine ends when:
           - arena reacquires (arena_tracked becomes True with valid position), OR
           - time since quarantine start exceeds quarantine_sec.

    Returns:
      fused_clean : (T,2)
      removed_mask: (T,) bool
    """
    fused_xy = np.asarray(fused_xy, dtype=float)
    assert fused_xy.ndim == 2 and fused_xy.shape[1] == 2
    T = fused_xy.shape[0]

    arena_ok = _coerce_tracked(arena_tracked)
    ent_ok = _coerce_tracked(entrance_tracked)
    assert arena_ok.shape == (T,)
    assert ent_ok.shape == (T,)

    if t is None:
        t = np.arange(T, dtype=float)
    else:
        t = np.asarray(t, dtype=float)
        assert t.shape == (T,)

    def valid_row(xy):
        return np.isfinite(xy).all()

    fused_clean = fused_xy.copy()
    removed = np.zeros(T, dtype=bool)

    # Anchor: last trusted arena position/time
    anchor_pos = None
    anchor_t = None

    # Quarantine state
    quarantined = False
    quarantine_start_t = None

    for i in range(T):
        # If arena is tracked and we have a valid point, trust it and reset state
        if arena_ok[i] and valid_row(fused_clean[i]):
            anchor_pos = fused_clean[i].copy()
            anchor_t = t[i]
            quarantined = False
            quarantine_start_t = None
            continue

        # If we don't have an anchor yet, nothing to do
        if anchor_pos is None or anchor_t is None:
            continue

        arena_missing = (not arena_ok[i])

        # Check if quarantine should expire
        if quarantined:
            if (not arena_missing):
                # (rare) arena_ok True but fused invalid; don't auto-exit, wait for valid arena sample
                pass
            if quarantine_start_t is not None and (t[i] - quarantine_start_t) > quarantine_sec:
                quarantined = False
                quarantine_start_t = None

        # We only act on frames with a valid fused position
        if not valid_row(fused_clean[i]):
            continue

        # Compute plausibility relative to anchor
        dt = max(float(t[i] - anchor_t), 1e-9)
        d = float(np.linalg.norm(fused_clean[i] - anchor_pos))
        v = d / dt
        implausible = (v > max_speed) or (d > jump_dist)

        # Decide whether this frame is "candidate to remove"
        # - Outside quarantine: only consider entrance_tracked frames during arena missing
        # - Inside quarantine: remove intermittent entrance detections (and optionally any far points)
        if arena_missing:
            if not quarantined:
                candidate = ent_ok[i]  # entrance says tracked
                if candidate and implausible:
                    # Trigger quarantine and remove this point
                    quarantined = True
                    quarantine_start_t = t[i]
                    fused_clean[i, :] = remove_to
                    removed[i] = True
            else:
                # Quarantine: remove intermittent entrance detections that disagree with anchor
                if require_entrance_flag:
                    candidate = ent_ok[i]
                else:
                    candidate = True  # remove any far/fast point during quarantine, regardless of entrance flag

                if candidate and implausible:
                    fused_clean[i, :] = remove_to
                    removed[i] = True

    return fused_clean, removed
