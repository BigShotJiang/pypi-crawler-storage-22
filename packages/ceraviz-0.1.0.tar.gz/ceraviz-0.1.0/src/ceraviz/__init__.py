"""
CeraViz — Crystal structure visualization and Materials Project search.

Provides PyVista-based 3D visualization of crystal structures fetched from the
Materials Project API, with CrystalNN bond detection and interactive atom inspection.
"""

__version__ = "0.1.0"

from ceraviz.api import render_material
from ceraviz.structure import extract_materials, make_supercell
from ceraviz.renderer import view_crystal
from ceraviz.types import (
    MaterialTD,
    CrystalTD,
    AtomTD,
    LatticeTD,
    MaterialMetaTD,
)

__all__ = [
    "render_material",
    "extract_materials",
    "make_supercell",
    "view_crystal",
    "MaterialTD",
    "CrystalTD",
    "AtomTD",
    "LatticeTD",
    "MaterialMetaTD",
]
