"""Type definitions for crystal structures and materials."""

import numpy as np
from typing import List, Tuple, TypedDict


class AtomTD(TypedDict):
    element: str
    frac: np.ndarray
    cart: np.ndarray


class LatticeTD(TypedDict):
    abc: Tuple[float, float, float]
    angles: Tuple[float, float, float]
    vectors: np.ndarray
    volume: float
    pbc: Tuple[bool, bool, bool]


class CrystalTD(TypedDict):
    lattice: LatticeTD
    atoms: List[AtomTD]
    nsites: int
    elements: List[str]


class MaterialMetaTD(TypedDict):
    material_id: str
    formula: str
    chemsys: str
    symmetry_symbol: str
    symmetry_number: int
    crystal_system: str
    density: float
    is_stable: bool
    energy_above_hull: float


class MaterialTD(TypedDict):
    structure: CrystalTD
    meta: MaterialMetaTD
