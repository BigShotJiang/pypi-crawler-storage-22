"""Tests for ceraviz.api module."""

import os
import pytest

from ceraviz.api import _resolve_api_key


class TestResolveApiKey:
    def test_explicit_key(self):
        assert _resolve_api_key("my-key") == "my-key"

    def test_env_var(self, monkeypatch):
        monkeypatch.setenv("MP_API_KEY", "env-key")
        assert _resolve_api_key() == "env-key"

    def test_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("MP_API_KEY", "env-key")
        assert _resolve_api_key("explicit-key") == "explicit-key"

    def test_no_key_raises(self, monkeypatch):
        monkeypatch.delenv("MP_API_KEY", raising=False)
        with pytest.raises(ValueError, match="No Materials Project API key"):
            _resolve_api_key()
