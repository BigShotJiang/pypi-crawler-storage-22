"""Tests for ceraviz.colors module."""

from ceraviz.colors import (
    hex_to_rgb,
    get_element_color,
    formula_to_subscript,
    JMOL_COLORS,
    DEFAULT_COLOR,
)


class TestHexToRgb:
    def test_basic_colors(self):
        assert hex_to_rgb("#FF0000") == (255, 0, 0)
        assert hex_to_rgb("#00FF00") == (0, 255, 0)
        assert hex_to_rgb("#0000FF") == (0, 0, 255)

    def test_without_hash(self):
        assert hex_to_rgb("FF0000") == (255, 0, 0)

    def test_black_white(self):
        assert hex_to_rgb("#000000") == (0, 0, 0)
        assert hex_to_rgb("#FFFFFF") == (255, 255, 255)

    def test_mixed_values(self):
        assert hex_to_rgb("#BFA6A6") == (191, 166, 166)


class TestGetElementColor:
    def test_known_elements(self):
        assert get_element_color("O") == "#FF0D0D"
        assert get_element_color("Fe") == "#E06633"
        assert get_element_color("Si") == "#F0C8A0"

    def test_unknown_element(self):
        assert get_element_color("Xx") == DEFAULT_COLOR

    def test_all_jmol_colors_present(self):
        assert len(JMOL_COLORS) >= 100


class TestFormulaToSubscript:
    def test_simple(self):
        assert formula_to_subscript("Al2O3") == "Al₂O₃"

    def test_no_numbers(self):
        assert formula_to_subscript("NaCl") == "NaCl"

    def test_all_digits(self):
        assert formula_to_subscript("0123456789") == "₀₁₂₃₄₅₆₇₈₉"

    def test_complex_formula(self):
        assert formula_to_subscript("Eu2SiCl2O3") == "Eu₂SiCl₂O₃"

    def test_empty(self):
        assert formula_to_subscript("") == ""
