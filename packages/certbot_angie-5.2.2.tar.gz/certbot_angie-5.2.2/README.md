# certbot-angie

[Angie](https://angie.software/) plugin for [Certbot](https://certbot.eff.org/). Obtain and install TLS/SSL certificates from Let's Encrypt (or other CAs) when using Angie as a web server.

Angie is a drop-in replacement for nginx based on nginx 1.23.2+.

## Requirements

- **Python** 3.10 or newer
- **Certbot** (acme, certbot packages — installed automatically)
- **Angie** web server (1.0.0 or newer, based on nginx ≥ 1.23.2)

## Installation

### From PyPI

```bash
pip install certbot-angie
```

Or with Certbot in a virtual environment:

```bash
python3 -m venv /opt/certbot
/opt/certbot/bin/pip install certbot certbot-angie
```

### From source

```bash
git clone https://github.com/your-org/certbot-angie.git
cd certbot-angie
pip install .
```

## Usage

Use the `angie` plugin with Certbot:

```bash
certbot --installer angie
```

Obtain a certificate (Certbot will use the Angie installer by default if Angie is detected):

```bash
certbot certonly --installer angie -d example.com
```

### Plugin options

| Option | Default | Description |
|--------|---------|-------------|
| `--server-root` | `/etc/angie` (Linux), `/usr/local/etc/angie` (FreeBSD/macOS) | Angie configuration root directory |
| `--ctl` | `angie` | Path to the Angie binary (for `configtest` and version detection) |
| `--sleep-seconds` | `1` | Seconds to wait after reloading Angie |

Example:

```bash
certbot --installer angie --server-root /etc/angie --ctl /usr/sbin/angie
```

## Configuration

- Angie config root: typically `/etc/angie` (Linux) or `/usr/local/etc/angie` (FreeBSD/macOS).
- Main config file: `angie.conf` in the server root.
- Certbot stores its TLS options in the Certbot config directory (e.g. under `/etc/letsencrypt/`) and includes them from your Angie server blocks.

## Development

Install in editable mode with test dependencies:

```bash
pip install -e ".[test]"
pytest src/certbot_angie/_internal/tests/ -v
```

## License

Apache 2.0. See [LICENSE](LICENSE) for details.
