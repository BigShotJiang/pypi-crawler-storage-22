"""Angie plugin constants."""
import platform
from typing import Any

FREEBSD_DARWIN_SERVER_ROOT = "/usr/local/etc/angie"
LINUX_SERVER_ROOT = "/etc/angie"
PKGSRC_SERVER_ROOT = "/usr/pkg/etc/angie"

if platform.system() in ('FreeBSD', 'Darwin'):
    server_root_tmp = FREEBSD_DARWIN_SERVER_ROOT
elif platform.system() in ('NetBSD',):
    server_root_tmp = PKGSRC_SERVER_ROOT
else:
    server_root_tmp = LINUX_SERVER_ROOT

CLI_DEFAULTS: dict[str, Any] = {
    "server_root": server_root_tmp,
    "ctl": "angie",
    "sleep_seconds": 1
}
"""CLI defaults."""


MOD_SSL_CONF_DEST = "options-ssl-angie.conf"
"""Name of the mod_ssl config file as saved
in `certbot.configuration.NamespaceConfig.config_dir`."""

UPDATED_MOD_SSL_CONF_DIGEST = ".updated-options-ssl-angie-conf-digest.txt"
"""Name of the hash of the updated or informed mod_ssl_conf as saved
in `certbot.configuration.NamespaceConfig.config_dir`."""

ALL_SSL_OPTIONS_HASHES = [
    '297be921febb68e6fe142ff0ab6461341f44e8679732d5d9e736ef35dad92928',
    '1003e9f8ad61c188d42db375e127be42b00c932a4f915f27858f1318848178d2',
]
"""SHA256 hashes of the contents of all versions of MOD_SSL_CONF_SRC.
Angie is based on Nginx >= 1.23.2, so only the modern TLS config is used."""


def os_constant(key: str) -> Any:
    # XXX TODO: In the future, this could return different constants
    #           based on what OS we are running under.  To see an
    #           approach to how to handle different OSes, see the
    #           apache version of this file.  Currently, we do not
    #           actually have any OS-specific constants on Angie.
    """
    Get a constant value for operating system

    :param str key: name of cli constant
    :return: value of constant for active os
    """
    return CLI_DEFAULTS[key]


HSTS_ARGS = ['\"max-age=31536000\"', ' ', 'always']

HEADER_ARGS = {'Strict-Transport-Security': HSTS_ARGS}
