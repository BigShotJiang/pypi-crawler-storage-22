import rich

rich.print("")
