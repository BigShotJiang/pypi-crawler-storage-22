class StateOverrideNotSupportedError(Exception):
    pass
