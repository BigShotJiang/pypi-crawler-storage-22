# Repository Guidelines

## Project Structure & Module Organization

- `chainsaws/` is the main package.
- `chainsaws/aws/<service>/` contains service-specific modules, typically:
  - `<service>.py` for high-level APIs
  - `_<service>_internal.py` for low-level boto3 interactions
  - `<service>_models.py` for typed request/response models
  - `<service>_exception.py` for domain exceptions
- `chainsaws/aws/shared/` holds shared session/config/pagination utilities.
- `chainsaws/utils/` contains generic helpers used across services.
- `tests/` is the pytest test root (currently sparse; add tests here).
- `.github/workflows/build-and-deploy.yml` defines CI lint/build/publish flow.
- `chainsaws_playground/` is for local experiments; `dist/` and `lib_rust/target/` are generated artifacts.

## Build, Test, and Development Commands

```bash
uv sync
```

Installs project and dev dependencies into `.venv`.

```bash
uv run ruff check .
```

Runs the same lints used by CI.

```bash
uv run pytest -q
```

Runs tests using `pyproject.toml` pytest settings (`tests/`, `test_*.py`).

```bash
uv build
```

Builds wheel and sdist into `dist/`.

## Coding Style & Naming Conventions

- Target modern Python (requires `>=3.12`), with explicit type hints in public APIs.
- Use 4-space indentation and snake_case for modules, functions, and variables.
- Use PascalCase for classes and UPPER_SNAKE_CASE for constants.
- Keep existing module patterns (`*_models.py`, `*_exception.py`, `_<service>_internal.py`) when adding new services/features.
- Prefer using TypedDict for dictionary interface as it provides more clear explanation.
- Don't use Any type. Use stricter typing.
- Keep code Ruff-clean (`ruff.toml` and `[tool.ruff]` in `pyproject.toml`).

## Testing Guidelines

- Framework: `pytest`.
- Place tests in `tests/test_<feature>.py`.
- Name tests as `test_<behavior>()`.
- No coverage gate is configured yet; add focused unit tests for new features and regression tests for bug fixes.

## Commit & Pull Request Guidelines

- Follow observed commit style: `feat(scope): ...`, `fix(scope): ...`, `chore: ...`.
- Keep commits scoped and imperative; avoid mixing unrelated service changes.
- PRs should include: summary, affected AWS module(s), lint/test results, and linked issue(s).
- If API behavior changes, add concise before/after usage examples in the PR description.

## General AWS Service guidelines

- Use ap-northeast-2 for default region
