# AWS Kinesis Firehose Client

`chainsaws.aws.firehose` provides a typed, high-level wrapper for writing records to
an existing Firehose delivery stream.

## Quick Start

```python
from chainsaws.aws.firehose import FirehoseAPI

firehose = FirehoseAPI(delivery_stream_name="my-stream")
firehose.put_record({"message": "Hello, World!", "ts": "2024-01-01T00:00:00Z"})
```

## Configuration

```python
from chainsaws.aws.firehose import FirehoseAPI, FirehoseAPIConfig
from chainsaws.aws.shared.session import AWSCredentials

config = FirehoseAPIConfig(
    region="ap-northeast-2",
    credentials=AWSCredentials(
        aws_access_key_id="AKIAXXXXXXXXXXXXXXXX",
        aws_secret_access_key="XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        region_name="ap-northeast-2",
    ),
)

firehose = FirehoseAPI(delivery_stream_name="my-stream", config=config)
```

## Supported APIs

### `put_record`

```python
firehose.put_record("raw string")
firehose.put_record(b"binary bytes")
firehose.put_record({"id": 1, "type": "created"})
firehose.put_record([{"id": 1}, {"id": 2}])
```

- Supported types: `str | bytes | dict[str, object] | list[object]`
- Per-record size limit validation: `<= 1,000,000 bytes`

### `put_record_batch`

```python
records = [
    {"id": 1, "message": "Hello"},
    {"id": 2, "message": "World"},
]

# Backward-compatible mode (default): returns raw Firehose batch responses
raw_responses = firehose.put_record_batch(records)

# Detailed summary mode
summary = firehose.put_record_batch(
    records,
    batch_size=100,      # 1..500
    retry_failed=True,   # default: True
    max_retries=3,       # positive integer
    return_summary=True,
)
```

When `return_summary=True`, response shape is:

```python
{
    "total_records": 2,
    "successful_records": 2,
    "failed_records": [],     # final failures after retries
    "attempt_failures": [     # all failed attempts including retried ones
        {"record": b"...", "error": "...", "attempt": 1}
    ],
    "batch_responses": [...], # raw AWS responses per batch call
}
```

## Notes

- This module does not create S3 buckets or Firehose streams.
- Delivery stream provisioning can be done via AWS console/IaC or the low-level
  internal API (`chainsaws.aws.firehose._firehose_internal.Firehose`).
