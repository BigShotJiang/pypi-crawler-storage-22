"""AWS Lambda handler utilities for request/response handling and error management.

Provides structured request parsing and response formatting with error handling.
"""

import traceback
import asyncio
import inspect
from collections.abc import Callable
from functools import wraps
from typing import Any, Optional, TypedDict
from http import HTTPStatus
import logging

from chainsaws.utils.error_utils.error_utils import make_error_description
from chainsaws.aws.lambda_client.event_handler.handler_models import (
    HandlerConfig,
    JSONValue,
    LambdaEvent,
    LambdaResponse,
    RequestContext,
)
from chainsaws.aws.lambda_client.event_handler.exceptions import (
    AppError,
    HTTPException,
)

logger = logging.getLogger(__name__)


class ServiceErrorInfo(TypedDict, total=False):
    code: str | None
    message: str | None
    request_id: str | None
    http_status: int | None


class ErrorInfo(TypedDict, total=False):
    type: str
    status_code: int
    headers: dict[str, str]
    code: str


class ErrorBody(TypedDict, total=False):
    error: ErrorInfo
    detail: object
    traceback: str
    error_receiver_failed: str
    service_error: ServiceErrorInfo


def _resolve_awaitable_result(result: Any) -> Any:
    if inspect.isawaitable(result):
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(result)
        msg = "Cannot execute async lambda handler while an event loop is already running"
        raise RuntimeError(msg)
    return result


def aws_lambda_handler(
    error_receiver: Optional[Callable[[str], Any]] = None,
    content_type: str = "application/json",
    use_traceback: bool = True,
    ignore_error_codes: Optional[list[int | str]] = None,
) -> Callable:
    """Decorator for AWS Lambda handlers with error handling and response formatting.

    Args:
        error_receiver: Callback function for error notifications
        content_type: Response content type
        use_traceback: Include traceback in error responses
        ignore_error_codes: List of error codes (HTTP status codes or AppError codes) to ignore for notifications

    Example:
        @aws_lambda_handler(
            error_receiver=notify_slack,
            ignore_error_codes=[404, "USER_NOT_FOUND"]  # HTTP status codes or AppError codes
        )
        def handler(event, context):
            body = LambdaEvent.parse_obj(event).get_json_body()
            return {"message": "Success"}
    """
    config = HandlerConfig(
        error_receiver=error_receiver,
        content_type=content_type,
        use_traceback=use_traceback,
        ignore_error_codes=ignore_error_codes or [],
    )

    def should_notify_error(error_code: int | str) -> bool:
        """Check if error should trigger notification."""
        return error_code not in config.ignore_error_codes

    def decorator(func: Callable[..., Any]) -> Callable[..., dict]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> dict:
            event = args[0] if args else {}
            event_dict = event if isinstance(event, dict) else {}
            is_api_gateway = LambdaEvent.is_api_gateway_event(event_dict)

            try:
                result = _resolve_awaitable_result(func(*args, **kwargs))
                if result is None:
                    result = {}

                if isinstance(result, dict) and LambdaResponse.is_lambda_response(response=result):
                    return result

                return LambdaResponse.create(
                    body=result,
                    status_code=HTTPStatus.OK,
                    content_type=config.content_type,
                    serialize=is_api_gateway
                )

            except HTTPException as ex:
                error_info: ErrorInfo = {
                    "type": ex.__class__.__name__,
                    "status_code": ex.status_code,
                    "headers": ex.headers
                }

                if isinstance(ex, AppError):
                    error_info["code"] = ex.code
                    error_info["type"] = "AppError"

                error_body: ErrorBody = {
                    "error": error_info,
                    "detail": ex.detail,
                }

                if config.use_traceback:
                    error_body["traceback"] = str(traceback.format_exc())

                if config.error_receiver:
                    error_code = ex.code if isinstance(
                        ex, AppError) else ex.status_code
                    if should_notify_error(error_code):
                        try:
                            message = make_error_description(event_dict)
                            config.error_receiver(message)
                        except Exception as err:
                            error_body["error_receiver_failed"] = str(err)

                return LambdaResponse.create(
                    error_body,
                    status_code=ex.status_code,
                    headers=ex.headers,
                    content_type=config.content_type,
                    serialize=is_api_gateway
                )

            except Exception as ex:
                error_body: ErrorBody = {
                    "detail": str(ex),
                }

                status_code = HTTPStatus.INTERNAL_SERVER_ERROR
                if hasattr(ex, "response") and isinstance(getattr(ex, "response", None), dict):
                    error_info = getattr(ex, "response", {})
                    error_body.update({
                        "service_error": {
                            "code": error_info.get("Error", {}).get("Code"),
                            "message": error_info.get("Error", {}).get("Message"),
                            "request_id": error_info.get("ResponseMetadata", {}).get("RequestId"),
                            "http_status": error_info.get("ResponseMetadata", {}).get("HTTPStatusCode")
                        }
                    })
                    aws_status = error_info.get(
                        "ResponseMetadata", {}).get("HTTPStatusCode")
                    if isinstance(aws_status, int):
                        status_code = aws_status

                if config.use_traceback:
                    error_body["traceback"] = str(traceback.format_exc())

                if config.error_receiver and should_notify_error(status_code):
                    try:
                        message = make_error_description(event_dict)
                        config.error_receiver(message)
                    except Exception as err:
                        error_body["error_receiver_failed"] = str(err)

                return LambdaResponse.create(
                    body=error_body,
                    status_code=status_code,
                    content_type=config.content_type,
                    serialize=is_api_gateway
                )

        return wrapper
    return decorator


def get_event_data(event: dict[str, Any]) -> LambdaEvent:
    """Get event data."""
    return LambdaEvent.from_dict(event)


def get_body(event: dict[str, Any]) -> dict[str, JSONValue] | None:
    """Get JSON body from event."""
    return get_event_data(event).get_json_object_body()


def get_headers(event: dict[str, Any]) -> dict[str, str]:
    """Get request headers."""
    return get_event_data(event).headers


def get_source_ip(event: dict[str, Any]) -> str | None:
    """Get source IP address from event."""
    lambda_event = get_event_data(event)
    request_context = lambda_event.request_context
    identity = request_context.get("identity", {})
    return RequestContext.get_source_ip(identity)
