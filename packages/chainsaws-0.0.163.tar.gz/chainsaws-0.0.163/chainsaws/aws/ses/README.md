# AWS SES (Simple Email Service) API

A high-level Python interface for AWS Simple Email Service (SES) built on the SESv2 API. It provides an easy-to-use API for sending emails, managing templates, and handling bulk email operations.

## Features

- ✉️ Single and bulk email sending
- 📝 Template management
- 🚀 SESv2 native bulk email API
- 📊 Quota monitoring
- ✅ Email verification
- 🎨 HTML and plain text support
- 🏷️ Email tagging
- 🔒 Type-safe with dataclasses

## Installation

```bash
pip install chainsaws
```

## Quick Start

```python
from chainsaws.aws.ses import SESAPI, EmailAddress, EmailFormat

# Initialize the API
ses = SESAPI()

# Send a simple email
ses.send_email(
    recipients="user@example.com",
    subject="Welcome!",
    body="<h1>Welcome to our service!</h1>",
    email_format=EmailFormat.HTML
)
```

## Email Sending

### Single Email

```python
# Basic email
ses.send_email(
    recipients=["user@example.com"],
    subject="Hello!",
    body="Welcome to our service!",
    email_format=EmailFormat.TEXT
)

# HTML email with custom sender
ses.send_email(
    sender=EmailAddress(
        email="noreply@company.com",
        name="Company Name"
    ),
    recipients=["user@example.com"],
    subject="Welcome!",
    body="<h1>Welcome!</h1><p>Thanks for joining.</p>",
    email_format=EmailFormat.HTML,
    tags={"category": "welcome"}
)

# With CC and BCC
ses.send_email(
    recipients=["primary@example.com"],
    cc=["manager@example.com"],
    bcc=["archive@example.com"],
    subject="Project Update",
    body="Latest project status...",
    reply_to=["support@example.com"]
)
```

### Template Management

```python
# Create template
ses.create_template(
    name="welcome_template",
    subject="Welcome {{name}}!",
    html_content="""
    <h1>Welcome {{name}}!</h1>
    <p>Thanks for choosing {{company}}.</p>
    """
)

# Create or update template in one call
ses.upsert_template(
    name="welcome_template",
    subject="Welcome {{name}}!",
    html_content="<h1>Welcome {{name}}!</h1>"
)

# Send templated email
ses.send_template(
    template_name="welcome_template",
    recipients="user@example.com",
    template_data={
        "name": "John Doe",
        "company": "ACME Inc"
    }
)

# List templates
templates = ses.list_templates()
for template in templates["TemplatesMetadata"]:
    print(template["TemplateName"])
```

### Bulk Email Sending

```python
# Simple bulk send
results = ses.send_bulk_emails(
    recipients=[
        "user1@example.com",
        "user2@example.com",
        "user3@example.com"
    ],
    subject="Important Update",
    body="Service maintenance scheduled...",
    batch_size=100
)

# Templated bulk send with custom data
results = ses.send_bulk_emails(
    recipients=[
        {
            "email": "user1@example.com",
            "template_data": {"name": "User 1", "plan": "Premium"},
            "tags": {"type": "premium"}
        },
        {
            "email": "user2@example.com",
            "template_data": {"name": "User 2", "plan": "Basic"},
            "tags": {"type": "basic"}
        }
    ],
    template_name="welcome_template",
    batch_size=50,
    idempotency_key="campaign-2026-02-14",
    trace_tag_name="trace_id"
)

# Process results
for result in results:
    if result['status'] == 'success':
        print(f"Sent to {result['email']}: {result['message_id']}")
    else:
        print(f"Failed to send to {result['email']}: {result['error']}")
```

### Email Verification

```python
# Verify sender email
ses.verify_email("sender@company.com")

# List verified emails
verified = ses.list_verified_emails()

# List identities with optional filters
all_identities = ses.list_identities()
emails_only = ses.list_identities(identity_types=["EMAIL_ADDRESS"])
```

### Quota Management

```python
# Check sending quota
quota = ses.get_quota()
print(f"Sent in last 24h: {quota['sent_last_24_hours']}")
print(f"Maximum sends per 24h: {quota['max_24_hour_send']}")
print(f"Send rate: {quota['max_send_rate']} emails/second")
```

## Advanced Configuration

```python
from chainsaws.aws.ses import SESAPI, SESAPIConfig, EmailAddress, EmailFormat

ses = SESAPI(
    config=SESAPIConfig(
        region="ap-northeast-2",
        default_sender=EmailAddress(
            email="noreply@company.com",
            name="Company Name"
        ),
        default_configuration_set="default-config-set",
        default_format=EmailFormat.BOTH,
        credentials={
            "aws_access_key_id": "YOUR_ACCESS_KEY",
            "aws_secret_access_key": "YOUR_SECRET_KEY"
        }
    )
)
```

## Best Practices

1. **Batch Processing**: Use `send_bulk_emails` for sending to multiple recipients
2. **Template Usage**: Create reusable templates for consistent emails
3. **Error Handling**: Always check bulk send results for failures
4. **Quota Monitoring**: Monitor your sending quota to avoid limits
5. **Verification**: Verify sender emails before sending
6. **Tags**: Use tags to categorize and track emails

## Error Handling

```python
from chainsaws.aws.ses import SESException

try:
    ses.send_email(
        recipients="user@example.com",
        subject="Test",
        body="Test message"
    )
except SESException as e:
    logger.error(f"Failed to send email: {str(e)}")
```

## SESv2 Extras

```python
# Per-send configuration set and list management options
ses.send_email(
    recipients="user@example.com",
    subject="Newsletter",
    body="May updates",
    configuration_set_name="marketing",
    list_management_options={
        "contact_list_name": "users",
        "topic_name": "news"
    }
)

# Identity metadata
identity = ses.get_identity("user@example.com")
print(identity["verified_for_sending_status"])

# Suppression list management
ses.suppress_destination("bounced@example.com", reason="BOUNCE")
suppressed = ses.list_suppressed_destinations(reasons=["BOUNCE"])
ses.unsuppress_destination("bounced@example.com")

# Wait for identity verification
is_verified = ses.wait_for_identity_verification(
    "user@example.com",
    timeout_seconds=180,
    poll_interval_seconds=5,
)

# Build and send raw MIME email (attachments, multipart)
raw = SESAPI.build_raw_mime_email(
    sender="noreply@company.com",
    recipients="user@example.com",
    subject="Raw MIME Example",
    body_text="Plain text body",
    body_html="<h1>HTML body</h1>",
    attachments=[
        {
            "filename": "guide.txt",
            "data": b"hello",
            "content_type": "text/plain",
        }
    ],
)
ses.send_raw_email(recipients="user@example.com", raw_data=raw)

# Inline image helper
inline_image, cid = SESAPI.build_inline_image_attachment(
    filename="logo.png",
    data=b\"...\",
    content_type=\"image/png\"
)
# use in HTML: f'<img src=\"cid:{cid}\">' with attachments=[inline_image]
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.
