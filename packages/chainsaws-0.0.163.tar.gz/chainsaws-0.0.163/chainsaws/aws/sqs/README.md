# AWS SQS Client

`chainsaws.aws.sqs` provides a typed, high-level wrapper for SQS.

Configuration model is available as `chainsaws.aws.sqs.sqs_models.SQSAPIConfig`
(and kept compatible via `chainsaws.aws.sqs.sqs_config.SQSAPIConfig`).

## Quick Start

```python
from chainsaws.aws.sqs import SQSAPI

sqs = SQSAPI("https://sqs.ap-northeast-2.amazonaws.com/123456789012/my-queue")

# Send one message
send_resp = sqs.send_message({"type": "created", "id": 1})
print(send_resp.get("MessageId"))

# Receive and delete
recv_resp = sqs.receive_messages(max_number_of_messages=10, wait_time_seconds=20)
for msg in recv_resp.get("Messages", []):
    print(msg["Body"])
    sqs.delete_message(msg["ReceiptHandle"])
```

## Batch APIs

```python
# Send batch with strict partial-failure handling
resp = sqs.send_messages(
    messages=[{"k": "v1"}, {"k": "v2"}],
    strict=True,
)

# Delete batch with strict partial-failure handling
sqs.delete_messages(["rh1", "rh2"], strict=True)
```

When `strict=True`, `SQSBatchOperationError` is raised if SQS returns any failed entries.

## FIFO Queue Behavior

For `.fifo` queue URLs:
- `send_message()` and `send_message_batch()` require FIFO semantics.
- `MessageGroupId` defaults to `"default"` when omitted.
- `MessageDeduplicationId` defaults to MD5(body) when omitted.
- Per-message `delay_seconds` / `DelaySeconds` is rejected.

For standard queues, FIFO-only parameters are rejected early.

## Iteration Helper

```python
for msg in sqs.iter_messages(
    max_number_of_messages=10,
    wait_time_seconds=20,
    auto_delete=True,
    auto_delete_strict=True,
    stop_after=100,
):
    process(msg)
```

`iter_messages(auto_delete=True)` performs batched deletions for better throughput.

## Validation

The client validates common constraints before calling AWS:
- Batch size: `1..10`
- `max_number_of_messages`: `1..10`
- `wait_time_seconds`: `0..20`
- `visibility_timeout`: `0..43200`
- Message body size: `<= 256 KB`
- Message attributes: max `10`, supports `String|Number|Binary` and custom suffixes (e.g. `Number.int`)
- Message attribute names: AWS naming rules + reserved prefix (`AWS.` / `Amazon.`) rejection
- `receive_messages(message_attributes_names=...)`: supports `All`, `.*`, and `prefix.*`
- Batch `Id` format: `[A-Za-z0-9_-]{1,80}`

Validation errors raise `SQSValidationError`.

## Exceptions

- `SQSException`: Base exception
- `SQSValidationError`: Local parameter validation error
- `SQSBatchOperationError`: Batch response contains failed entries
