"""DynamoDB API wrapper for simplified table operations with partition management."""

from chainsaws.aws.dynamodb.dynamodb import DynamoDBAPI
from chainsaws.aws.dynamodb._dynamodb_inmemory_internal import InMemoryDynamoDBInternal
from chainsaws.aws.dynamodb.testing import (
    PartitionIndexForTest,
    create_inmemory_dynamodb_api,
    register_test_partition,
)
from chainsaws.aws.dynamodb.dynamodb_exception import (
    BatchOperationError,
    DuplicateIndexError,
    DynamoDBError,
    DynamoDBPartitionError,
    PartitionNotFoundError,
)
from chainsaws.aws.dynamodb.dynamodb_models import (
    DynamoDBAPIConfig,
    FilterCondition,
    FilterDict,
    DynamoIndex,
    DynamoModel,
    PartitionIndex,
    PartitionMap,
    PartitionMapConfig,
    PK,
    SK,
    sync,
    sync_all_models,
)

__all__ = [
    "BatchOperationError",
    "DynamoDBAPI",
    "DynamoDBAPIConfig",
    "DynamoDBError",
    "DynamoDBPartitionError",
    "DuplicateIndexError",
    "FilterCondition",
    "FilterDict",
    "InMemoryDynamoDBInternal",
    "PartitionIndexForTest",
    "DynamoIndex",
    "DynamoModel",
    "PartitionIndex",
    "PartitionMap",
    "PartitionMapConfig",
    "PartitionNotFoundError",
    "PK",
    "SK",
    "create_inmemory_dynamodb_api",
    "register_test_partition",
    "sync",
    "sync_all_models",
]
