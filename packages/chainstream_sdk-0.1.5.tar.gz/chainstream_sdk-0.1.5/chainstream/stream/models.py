"""Data models for the ChainStream WebSocket Stream API."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class TokenActivityType(str, Enum):
    """Token activity type."""

    SELL = "sell"
    BUY = "buy"
    ADD_LIQUIDITY = "add_liquidity"
    REMOVE_LIQUIDITY = "remove_liquidity"


class ChannelType(str, Enum):
    """Channel type for subscriptions."""

    NEW = "new"
    HOT = "trending"
    US_STOCKS = "us_stocks"
    COMPLETED = "completed"
    GRADUATED = "graduated"


class MetricType(str, Enum):
    """Metric type for measurements."""

    LIQUIDITY_IN_USD = "liquidity_in_usd"
    MIGRATED_RATIO = "migrated_ratio"


class RankingType(str, Enum):
    """Ranking type for token rankings."""

    NEW = "new"
    HOT = "trending"
    STOCKS = "stocks"
    FINAL_STRETCH = "completed"
    MIGRATED = "graduated"


class Dex(str, Enum):
    """DEX (Decentralized Exchange) type."""

    PUMP_FUN = "pump_fun"
    RAYDIUM_LAUNCHPAD = "raydium_launchpad"
    METEORA_DYNAMIC_BOUNDING_CURVE = "meteora_dynamic_bounding_curve"
    BONK_FUN = "bonk_fun"
    BOOP_FUN = "boop_fun"
    MOONIT_FUN = "moonit_fun"


class Resolution(str, Enum):
    """Candle resolution for time-based data."""

    S1 = "1s"
    S15 = "15s"
    S30 = "30s"
    M1 = "1m"
    M5 = "5m"
    M15 = "15m"
    H1 = "1h"
    H4 = "4h"
    H12 = "12h"
    D1 = "1d"


@dataclass
class TokenActivity:
    """Token activity data."""

    address: str
    price_usd: str
    amount: str
    activity_type: TokenActivityType
    tx_hash: str
    timestamp: int


@dataclass
class TokenStat:
    """Token statistics with multi-timeframe data."""

    address: str
    timestamp: int

    # 1-minute data
    buys_1m: Optional[int] = None
    sells_1m: Optional[int] = None
    buyers_1m: Optional[int] = None
    sellers_1m: Optional[int] = None
    buy_volume_in_usd_1m: Optional[str] = None
    sell_volume_in_usd_1m: Optional[str] = None
    price_1m: Optional[str] = None
    open_in_usd_1m: Optional[str] = None
    close_in_usd_1m: Optional[str] = None

    # 5-minute data
    buys_5m: Optional[int] = None
    sells_5m: Optional[int] = None
    buyers_5m: Optional[int] = None
    sellers_5m: Optional[int] = None
    buy_volume_in_usd_5m: Optional[str] = None
    sell_volume_in_usd_5m: Optional[str] = None
    price_5m: Optional[str] = None
    open_in_usd_5m: Optional[str] = None
    close_in_usd_5m: Optional[str] = None

    # 15-minute data
    buys_15m: Optional[int] = None
    sells_15m: Optional[int] = None
    buyers_15m: Optional[int] = None
    sellers_15m: Optional[int] = None
    buy_volume_in_usd_15m: Optional[str] = None
    sell_volume_in_usd_15m: Optional[str] = None
    price_15m: Optional[str] = None
    open_in_usd_15m: Optional[str] = None
    close_in_usd_15m: Optional[str] = None

    # 30-minute data
    buys_30m: Optional[int] = None
    sells_30m: Optional[int] = None
    buyers_30m: Optional[int] = None
    sellers_30m: Optional[int] = None
    buy_volume_in_usd_30m: Optional[str] = None
    sell_volume_in_usd_30m: Optional[str] = None
    price_30m: Optional[str] = None
    open_in_usd_30m: Optional[str] = None
    close_in_usd_30m: Optional[str] = None

    # 1-hour data
    buys_1h: Optional[int] = None
    sells_1h: Optional[int] = None
    buyers_1h: Optional[int] = None
    sellers_1h: Optional[int] = None
    buy_volume_in_usd_1h: Optional[str] = None
    sell_volume_in_usd_1h: Optional[str] = None
    price_1h: Optional[str] = None
    open_in_usd_1h: Optional[str] = None
    close_in_usd_1h: Optional[str] = None

    # 4-hour data
    buys_4h: Optional[int] = None
    sells_4h: Optional[int] = None
    buyers_4h: Optional[int] = None
    sellers_4h: Optional[int] = None
    buy_volume_in_usd_4h: Optional[str] = None
    sell_volume_in_usd_4h: Optional[str] = None
    price_4h: Optional[str] = None
    open_in_usd_4h: Optional[str] = None
    close_in_usd_4h: Optional[str] = None

    # 24-hour data
    buys_24h: Optional[int] = None
    sells_24h: Optional[int] = None
    buyers_24h: Optional[int] = None
    sellers_24h: Optional[int] = None
    buy_volume_in_usd_24h: Optional[str] = None
    sell_volume_in_usd_24h: Optional[str] = None
    price_24h: Optional[str] = None
    open_in_usd_24h: Optional[str] = None
    close_in_usd_24h: Optional[str] = None

    # Current price
    price: Optional[str] = None


@dataclass
class TokenHolder:
    """Token holder information."""

    token_address: str
    timestamp: int
    holders: Optional[int] = None
    top100_amount: Optional[str] = None
    top10_amount: Optional[str] = None
    top100_holders: Optional[int] = None
    top10_holders: Optional[int] = None
    top100_ratio: Optional[str] = None
    top10_ratio: Optional[str] = None
    creators_holders: Optional[int] = None
    creators_amount: Optional[str] = None
    creators_ratio: Optional[str] = None


@dataclass
class WalletBalance:
    """Wallet balance data."""

    wallet_address: str
    token_address: str
    token_price_in_usd: str
    balance: str
    timestamp: int


@dataclass
class WalletPnl:
    """Wallet profit and loss data."""

    wallet_address: str
    buys: int
    buy_amount: str
    buy_amount_in_usd: str
    average_buy_price_in_usd: str
    sell_amount: str
    sell_amount_in_usd: str
    sells: int
    wins: int
    win_ratio: str
    pnl_in_usd: str
    average_pnl_in_usd: str
    pnl_ratio: str
    profitable_days: int
    losing_days: int
    tokens: int
    resolution: str


@dataclass
class DexProtocol:
    """DEX protocol information."""

    program_address: Optional[str] = None
    protocol_family: Optional[str] = None
    protocol_name: Optional[str] = None


@dataclass
class NewToken:
    """New token data."""

    token_address: str
    name: str
    symbol: str
    created_at_ms: int
    decimals: Optional[int] = None
    launch_from: Optional[DexProtocol] = None


@dataclass
class TokenSupply:
    """Token supply data."""

    token_address: str
    timestamp: int
    supply: Optional[str] = None
    market_cap_in_usd: Optional[str] = None


@dataclass
class DexPoolBalance:
    """DEX pool balance data."""

    pool_address: str
    token_a_address: str
    token_a_liquidity_in_usd: str
    token_b_address: str
    token_b_liquidity_in_usd: str


@dataclass
class TokenLiquidity:
    """Token liquidity data."""

    token_address: str
    metric_type: MetricType
    value: str
    timestamp: int


@dataclass
class TokenMaxLiquidity:
    """Token max liquidity data (max liquidity in a single pool)."""

    token_address: str
    pool_address: str
    liquidity_in_usd: str
    liquidity_in_native: str
    timestamp: int


@dataclass
class TokenTotalLiquidity:
    """Token total liquidity data (total liquidity across all pools)."""

    token_address: str
    liquidity_in_usd: str
    liquidity_in_native: str
    pool_count: int
    timestamp: int


@dataclass
class TokenBondingCurve:
    """Token bonding curve data."""

    token_address: Optional[str] = None
    progress_ratio: Optional[str] = None


@dataclass
class SocialMedia:
    """Social media links."""

    twitter: Optional[str] = None
    telegram: Optional[str] = None
    website: Optional[str] = None
    tiktok: Optional[str] = None
    discord: Optional[str] = None
    facebook: Optional[str] = None
    github: Optional[str] = None
    instagram: Optional[str] = None
    linkedin: Optional[str] = None
    medium: Optional[str] = None
    reddit: Optional[str] = None
    youtube: Optional[str] = None
    bitbucket: Optional[str] = None


@dataclass
class TokenMetadata:
    """Token metadata."""

    token_address: str
    name: Optional[str] = None
    decimals: Optional[int] = None
    symbol: Optional[str] = None
    image_url: Optional[str] = None
    description: Optional[str] = None
    social_media: Optional[SocialMedia] = None
    created_at_ms: Optional[int] = None
    launch_from: Optional[DexProtocol] = None
    migrated_to: Optional[DexProtocol] = None


class PriceType(str, Enum):
    """Price type for candle data."""

    USD = "usd"
    NATIVE = "native"


@dataclass
class Candle:
    """Candlestick data for Token/Pool/Pair."""

    address: str
    open: str
    close: str
    high: str
    low: str
    volume: str
    resolution: str
    time: int
    number: int


# Alias for backward compatibility
TokenCandle = Candle


@dataclass
class TradeActivity:
    """Trade activity data."""

    token_address: str
    timestamp: int
    kind: str
    buy_amount: str
    buy_amount_in_usd: str
    buy_token_address: str
    buy_token_name: str
    buy_token_symbol: str
    buy_wallet_address: str
    sell_amount: str
    sell_amount_in_usd: str
    sell_token_address: str
    sell_token_name: str
    sell_token_symbol: str
    sell_wallet_address: str
    tx_hash: str


@dataclass
class WalletTokenPnl:
    """Wallet token profit and loss data."""

    wallet_address: str
    token_address: str
    token_price_in_usd: str
    timestamp: int
    open_time: int
    last_time: int
    close_time: int
    buy_amount: str
    buy_amount_in_usd: str
    buy_count: int
    buy_count_30d: int
    buy_count_7d: int
    sell_amount: str
    sell_amount_in_usd: str
    sell_count: int
    sell_count_30d: int
    sell_count_7d: int
    held_duration_timestamp: int
    average_buy_price_in_usd: str
    average_sell_price_in_usd: str
    unrealized_profit_in_usd: str
    unrealized_profit_ratio: str
    realized_profit_in_usd: str
    realized_profit_ratio: str
    total_realized_profit_in_usd: str
    total_realized_profit_ratio: str


@dataclass
class RankingTokenList:
    """Ranking token list data."""

    metadata: Optional[TokenMetadata] = None
    holder: Optional[TokenHolder] = None
    supply: Optional[TokenSupply] = None
    stat: Optional[TokenStat] = None
    bonding_curve: Optional[TokenBondingCurve] = None
