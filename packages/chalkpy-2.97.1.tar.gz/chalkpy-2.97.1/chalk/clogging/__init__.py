from chalk.clogging.chalk_logger import chalk_logger

# This module is deprecated -- backwards compatibility

__all__ = ["chalk_logger"]
