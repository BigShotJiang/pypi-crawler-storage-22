class CriticalException(Exception):
    pass
