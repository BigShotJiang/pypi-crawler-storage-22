from pathlib import Path

BASE_DIR = Path.cwd()
TEMPLATE_DIR = Path(__file__).parent.parent / "templates"
