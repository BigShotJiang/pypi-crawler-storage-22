import subprocess


class DVCRunner:

    @staticmethod
    def repro():
        subprocess.run(["dvc", "repro"], check=True)

    @staticmethod
    def pull():
        subprocess.run(["dvc", "pull"], check=True)
