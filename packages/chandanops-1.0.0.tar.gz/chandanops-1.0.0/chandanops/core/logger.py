import logging
from pathlib import Path


def setup_logger(log_dir="logs"):
    Path(log_dir).mkdir(exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[
            logging.FileHandler(Path(log_dir) / "pipeline.log"),
            logging.StreamHandler()
        ],
    )
    return logging.getLogger("chandanops")
