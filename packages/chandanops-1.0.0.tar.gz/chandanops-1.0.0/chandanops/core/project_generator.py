import shutil
from pathlib import Path
from chandanops.core.config import TEMPLATE_DIR


class ProjectGenerator:

    def create_project(self, name: str):
        target = Path(name)
        if target.exists():
            raise FileExistsError("Project already exists.")

        shutil.copytree(
            TEMPLATE_DIR / "ai_project",
            target
        )
