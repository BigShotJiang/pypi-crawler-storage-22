from pathlib import Path


class DockerGenerator:

    @staticmethod
    def generate():
        content = """
FROM python:3.11
WORKDIR /app
COPY . .
RUN pip install .
CMD ["chandanops", "serve"]
"""
        Path("Dockerfile").write_text(content)
