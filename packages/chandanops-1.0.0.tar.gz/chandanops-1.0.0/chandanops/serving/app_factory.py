from fastapi import FastAPI
from .model_loader import ModelLoader
from .routes import create_routes
from .middleware import logging_middleware


def create_app(model_path="artifacts/model.pkl"):
    app = FastAPI(title="ChandanOps Serving")

    model_loader = ModelLoader(model_path)
    router = create_routes(model_loader)

    app.include_router(router)
    app.middleware("http")(logging_middleware)

    return app
