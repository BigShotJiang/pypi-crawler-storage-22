import pickle
from pathlib import Path


class ModelLoader:

    def __init__(self, model_path):
        self.model_path = Path(model_path)
        self._model = None

    @property
    def model(self):
        if self._model is None:
            if not self.model_path.exists():
                raise FileNotFoundError("Model not found")
            with open(self.model_path, "rb") as f:
                self._model = pickle.load(f)
        return self._model
