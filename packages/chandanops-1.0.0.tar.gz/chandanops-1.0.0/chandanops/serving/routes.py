from fastapi import APIRouter
import numpy as np
from .schema_generator import RequestSchema


def create_routes(model_loader):
    router = APIRouter()

    @router.get("/health")
    def health():
        return {"status": "ok"}

    @router.post("/predict")
    def predict(request: RequestSchema):
        model = model_loader.model
        data = np.array([[request.feature1, request.feature2]])
        result = model.predict(data)
        return {"prediction": float(result[0])}

    return router
