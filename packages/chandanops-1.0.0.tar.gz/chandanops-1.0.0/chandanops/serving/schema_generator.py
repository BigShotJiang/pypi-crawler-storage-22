from pydantic import BaseModel


class RequestSchema(BaseModel):
    feature1: float
    feature2: float
