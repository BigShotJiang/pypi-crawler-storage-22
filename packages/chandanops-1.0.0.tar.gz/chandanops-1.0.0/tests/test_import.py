def test_import():
    import chandanops
    assert chandanops.__version__ == "1.0.0"
