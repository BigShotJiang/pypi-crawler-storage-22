# CHANfiG
# Copyright (C) 2022-Present, DanLing Team

# This file is part of CHANfiG.

# CHANfiG is free software: you can redistribute it and/or modify
# it under the terms of the following licenses:
# - The Unlicense
# - GNU Affero General Public License v3.0 or later
# - GNU General Public License v2.0 or later
# - BSD 4-Clause "Original" or "Old" License
# - MIT License
# - Apache License 2.0

# CHANfiG is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the LICENSE file for more details.

from __future__ import annotations

from .annotation import conform_annotation, get_annotations, get_cached_annotations, honor_annotation
from .functional import apply, apply_, parse_bool, suggest_key, to_chanfig, to_dict
from .null import NULL, Null
from .placeholder import find_circular_reference, find_placeholders
from .safe_eval import SafeEvalError, safe_eval_expr

__all__ = [
    "get_annotations",
    "get_cached_annotations",
    "conform_annotation",
    "honor_annotation",
    "find_placeholders",
    "find_circular_reference",
    "NULL",
    "Null",
    "parse_bool",
    "suggest_key",
    "to_dict",
    "to_chanfig",
    "safe_eval_expr",
    "SafeEvalError",
    "apply",
    "apply_",
]
