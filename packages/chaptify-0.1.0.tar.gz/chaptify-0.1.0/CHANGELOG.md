# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2026-02-04
- Initial public release: CLI for downloading/transcribing video and generating YouTube chapters + SEO.

