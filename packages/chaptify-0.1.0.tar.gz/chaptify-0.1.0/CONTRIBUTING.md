# Contributing to chaptify

Thanks for considering a contribution!

## How to contribute

1. **Fork** the repo and create a feature branch.
2. **Make your changes** with clear, focused commits.
3. **Run checks** (at least `python3 -m compileall -q src`).
4. **Open a PR** with a short description and any relevant context.

## Reporting issues

Please include:
- What you expected vs what happened
- CLI command used
- OS + Python version
- Logs or error messages

## Development setup (local)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[langchain,gemini]"
```

