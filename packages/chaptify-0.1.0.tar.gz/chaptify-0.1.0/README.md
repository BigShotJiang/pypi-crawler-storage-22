![chaptify logo](logo.png)

# chaptify

Chaptify is a CLI tool that turns a video (or YouTube link) into:
- YouTube chapters (starting at `0:00 Introduction`)
- Title ideas
- Short descriptions
- SEO tags

## Setup
```bash
chaptify init  (follow prompt to setup) 
```

## Usage

```bash
chaptify init  to setup 
chaptify aivideo.mp4
chaptify "https://www.youtube.com/watch?v=VIDEO_ID"
```

## Install (editable/dev)

```bash
# macOS one-liner (installs ffmpeg + yt-dlp, creates venv, tries editable install)
./scripts/install_macos.sh
```

## Install on PATH (pipx)

```bash
brew install pipx
pipx ensurepath
pipx install .
```

## Upgrade (local pipx install)

If you installed from this repo path, re-run from the repo root:

```bash
cd /Users/emmanuelcrown/Documents/Code/chaperfiy
pipx reinstall .
```

If you installed from PyPI later, use:

```bash
pipx upgrade chaptify
```

## Requirements

- Internet access to:
  - YouTube (for downloads)
  - Groq (for transcription, and optionally LLM)
  - OpenAI (if using `--llm-provider openai`)
- `ffmpeg` available on your `PATH` (macOS: `brew install ffmpeg`)
- `yt-dlp` available on your `PATH` (macOS: `brew install yt-dlp`)
- API keys:
  - `GROQ_API_KEY` (for transcription)
  - `OPENAI_API_KEY` (if using `--llm-provider openai`)
  - `GOOGLE_API_KEY` (if using Gemini via LangChain; install extra: `pip install -e '.[gemini,langchain]'`)

You can also put these in a local `.env` file:

```bash
GROQ_API_KEY=...
OPENAI_API_KEY=...
# GOOGLE_API_KEY=...
```

## Usage

```bash
chaptify aivideo.mp4
chaptify "https://www.youtube.com/watch?v=VIDEO_ID"
```

By default `chaptify` prints progress to stderr (download → chunk → transcribe → chapters → SEO). Use `--quiet` to suppress.

`chaptify` also caches downloads/chunks/transcripts under `.chaptify_cache/` (next to your output directory). Use `--clear-cache` to force a fresh run.
Short flag: `--cc`.

## Init & config

```bash
chaptify init
chaptify config show
chaptify config get provider
chaptify config set model gpt-5
chaptify config set groq_api_key <KEY>
```

You can also set API keys while running:

```bash
chaptify "https://www.youtube.com/watch?v=VIDEO_ID" --set-api-key groq=... --set-api-key openai=...
```

## Run from source (no install)

```bash
PYTHONPATH=src python3 -m chaptify "https://www.youtube.com/watch?v=VIDEO_ID"
./scripts/run_local.sh "https://www.youtube.com/watch?v=VIDEO_ID"
```

Outputs are written next to the source as:

- `<name>_chapter.txt`
- `<name>_seo.txt`

## Common options

```bash
chaptify aivideo.mp4 --llm-provider openai --llm-model gpt-5
chaptify aivideo.mp4 --llm-provider openai --llm-model gpt-5 --reasoning-effort medium --text-verbosity medium
chaptify aivideo.mp4 --llm-provider groq --llm-model llama-3.1-70b-versatile
chaptify aivideo.mp4 --llm-provider gemini --llm-model gemini-2.0-flash  # requires `pip install -e '.[gemini,langchain]'`
chaptify aivideo.mp4 --max-upload-mb 25
chaptify aivideo.mp4 --clear-cache
chaptify aivideo.mp4 --cc
chaptify aivideo.mp4 --cache-dir /tmp/chaptify-cache
```

## Publish (PyPI)

```bash
python3 -m build
python3 -m twine upload dist/*
```

## Preflight (no secrets)

```bash
./scripts/check_secrets.sh
```
