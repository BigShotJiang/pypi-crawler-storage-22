#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

echo "Scanning for potential API keys (best-effort)..."
rg -n --no-heading --hidden --glob '!**/.git/**' \
  -e 'GROQ_API_KEY\s*=\s*["'\'']?.+' \
  -e 'OPENAI_API_KEY\s*=\s*["'\'']?.+' \
  -e 'sk-[A-Za-z0-9]{20,}' \
  -e 'gsk_[A-Za-z0-9]{20,}' \
  -e 'AIza[0-9A-Za-z\-_]{20,}' \
  . || true

echo "Done."

