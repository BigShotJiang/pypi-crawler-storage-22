#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew is required on macOS. Install from https://brew.sh/ and re-run."
  exit 1
fi

echo "Installing system dependencies (ffmpeg, yt-dlp)..."
brew install ffmpeg yt-dlp

echo "Creating virtual environment (.venv)..."
python3 -m venv .venv

echo "Upgrading pip in venv..."
./.venv/bin/python -m pip install -U pip

echo "Installing Python deps for packaging/CLI (editable install)..."
echo "Note: this requires internet access to download build dependencies."
./.venv/bin/python -m pip install -e ".[langchain,gemini]" || {
  echo
  echo "Editable install failed (likely due to missing internet or optional deps)."
  echo "You can still run from source without installing the package:"
  echo "  PYTHONPATH=src python3 -m chaptify \"<file-or-youtube-url>\""
}

echo
echo "Done."
echo "Activate venv:  source .venv/bin/activate"
echo "Run:           chaptify \"<file-or-youtube-url>\""

