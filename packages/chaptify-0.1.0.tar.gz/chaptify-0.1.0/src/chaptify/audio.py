from __future__ import annotations

import math
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path


class FfmpegNotFoundError(RuntimeError):
    pass


class MediaProbeError(RuntimeError):
    pass


class AudioChunkError(RuntimeError):
    pass


@dataclass(frozen=True)
class AudioChunk:
    path: Path
    start_seconds: float
    duration_seconds: float


def _ensure_ffmpeg() -> None:
    if shutil.which("ffmpeg") is None:
        raise FfmpegNotFoundError("ffmpeg not found on PATH.")
    if shutil.which("ffprobe") is None:
        raise FfmpegNotFoundError("ffprobe not found on PATH.")


def probe_duration_seconds(path: Path) -> float:
    _ensure_ffmpeg()
    try:
        proc = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=nokey=1:noprint_wrappers=1",
                str(path),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        raise MediaProbeError(f"ffprobe failed for {path}: {exc.stderr.strip()}") from exc

    raw = proc.stdout.strip()
    try:
        return float(raw)
    except ValueError as exc:
        raise MediaProbeError(f"Could not parse duration from ffprobe output: {raw!r}") from exc


def _compute_chunk_seconds(max_upload_bytes: int, bitrate_kbps: int, safety: float = 0.85) -> int:
    # For CBR mp3, approximate bytes/sec = (kbps * 1000) / 8.
    bytes_per_second = (bitrate_kbps * 1000) / 8
    chunk_seconds = int(math.floor((max_upload_bytes * safety) / bytes_per_second))
    return max(chunk_seconds, 30)


def extract_and_chunk_to_mp3(
    *,
    input_path: Path,
    temp_dir: Path,
    max_upload_bytes: int,
    bitrate_kbps: int = 64,
    sample_rate_hz: int = 16000,
    channels: int = 1,
    max_attempts: int = 4,
) -> list[AudioChunk]:
    """
    Extract audio and encode to mp3 chunks suitable for upload.

    Uses fixed bitrate encoding so chunk sizing is predictable; retries with smaller
    chunk sizes if any output chunk exceeds max_upload_bytes.
    """
    _ensure_ffmpeg()
    temp_dir.mkdir(parents=True, exist_ok=True)

    attempt = 0
    chunk_seconds = _compute_chunk_seconds(max_upload_bytes, bitrate_kbps)

    while True:
        attempt += 1
        for p in temp_dir.glob("chunk_*.mp3"):
            p.unlink(missing_ok=True)

        out_pattern = str(temp_dir / "chunk_%03d.mp3")
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(input_path),
            "-map",
            "0:a:0",
            "-vn",
            "-ac",
            str(channels),
            "-ar",
            str(sample_rate_hz),
            "-b:a",
            f"{bitrate_kbps}k",
            "-f",
            "segment",
            "-segment_time",
            str(chunk_seconds),
            "-reset_timestamps",
            "1",
            out_pattern,
        ]

        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True)
        except subprocess.CalledProcessError as exc:
            raise AudioChunkError(f"ffmpeg failed: {exc.stderr.strip()}") from exc

        chunk_paths = sorted(temp_dir.glob("chunk_*.mp3"))
        if not chunk_paths:
            raise AudioChunkError("ffmpeg produced no chunks (no audio stream?)")

        largest = max(p.stat().st_size for p in chunk_paths)
        if largest <= max_upload_bytes:
            chunks: list[AudioChunk] = []
            cursor = 0.0
            for p in chunk_paths:
                dur = probe_duration_seconds(p)
                chunks.append(AudioChunk(path=p, start_seconds=cursor, duration_seconds=dur))
                cursor += dur
            return chunks

        if attempt >= max_attempts:
            raise AudioChunkError(
                f"Chunking failed: produced chunk of {largest / (1024 * 1024):.1f}MB "
                f"over limit {max_upload_bytes / (1024 * 1024):.1f}MB after {attempt} attempts."
            )

        # Reduce chunk size and retry.
        chunk_seconds = max(30, int(chunk_seconds * 0.7))


def load_chunks_from_dir(*, chunks_dir: Path) -> list[AudioChunk]:
    """
    Load `chunk_*.mp3` files from an existing directory and compute start offsets.
    """
    chunk_paths = sorted(chunks_dir.glob("chunk_*.mp3"))
    if not chunk_paths:
        raise AudioChunkError(f"No chunks found in {chunks_dir}")
    chunks: list[AudioChunk] = []
    cursor = 0.0
    for p in chunk_paths:
        dur = probe_duration_seconds(p)
        chunks.append(AudioChunk(path=p, start_seconds=cursor, duration_seconds=dur))
        cursor += dur
    return chunks
