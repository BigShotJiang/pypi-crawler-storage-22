from __future__ import annotations

import hashlib
import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional


def _sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def cache_key_for_url(url: str) -> str:
    return f"url-{_sha256_hex(url.strip())[:16]}"


def cache_key_for_file(path: Path) -> str:
    p = path.expanduser().resolve()
    st = p.stat()
    return f"file-{_sha256_hex(f'{p}:{st.st_size}:{st.st_mtime_ns}')[:16]}"


@dataclass(frozen=True)
class CachePaths:
    root: Path
    downloads_dir: Path
    chunks_dir: Path
    transcript_json: Path
    transcript_txt: Path
    meta_json: Path


def get_cache_paths(*, base_dir: Path, key: str) -> CachePaths:
    root = base_dir / ".chaptify_cache" / key
    return CachePaths(
        root=root,
        downloads_dir=root / "downloads",
        chunks_dir=root / "chunks",
        transcript_json=root / "transcript.json",
        transcript_txt=root / "transcript.txt",
        meta_json=root / "meta.json",
    )


def clear_cache(paths: CachePaths) -> None:
    shutil.rmtree(paths.root, ignore_errors=True)


def read_json(path: Path) -> Optional[dict[str, Any]]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
