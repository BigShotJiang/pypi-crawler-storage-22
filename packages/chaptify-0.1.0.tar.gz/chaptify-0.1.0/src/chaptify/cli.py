from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Optional

from chaptify.config import CONFIG_PATH, config_to_dict, load_config, prompt_init_config, save_config, set_config_value
from chaptify.env import load_env_upwards
from chaptify.pipeline import run_chaptify


def build_run_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="chaptify",
        description="Generate YouTube chapters + SEO from a local video/audio file or a YouTube URL.",
    )
    p.add_argument("input", help="Path to a local video/audio file, or a YouTube URL.")
    p.add_argument("--llm-provider", "--provider", dest="llm_provider", default=None, help="LLM provider: openai, gemini, groq.")
    p.add_argument("--llm-model", "--model", dest="llm_model", default=None, help="LLM model name (provider-specific).")
    p.add_argument(
        "--use-responses-api",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="OpenAI only: route GPT-5 requests via the Responses API (default: on for gpt-5*).",
    )
    p.add_argument(
        "--reasoning-effort",
        default=None,
        help="OpenAI Responses API only: reasoning effort (e.g. minimal/low/medium/high).",
    )
    p.add_argument(
        "--text-verbosity",
        default=None,
        help="OpenAI Responses API only: text verbosity (e.g. low/medium/high).",
    )
    p.add_argument(
        "--max-output-tokens",
        type=int,
        default=None,
        help="OpenAI Responses API only: max output tokens.",
    )
    p.add_argument("--groq-model", default="whisper-large-v3", help="Groq transcription model.")
    p.add_argument("--max-upload-mb", type=int, default=25, help="Max Groq upload size per chunk (MB).")
    p.add_argument(
        "--set-api-key",
        action="append",
        default=[],
        help="Convenience to set API keys in config. Example: --set-api-key groq=... --set-api-key openai=...",
    )
    p.add_argument("--keep-temp", action="store_true", help="Keep temp audio/chunk files for debugging.")
    p.add_argument(
        "--out-dir",
        default=None,
        help="Output directory (defaults to input file's directory, or CWD for YouTube URLs).",
    )
    p.add_argument(
        "--env-file",
        default=None,
        help="Path to a .env file (defaults to searching upward from current directory).",
    )
    p.add_argument(
        "--cache-dir",
        default=None,
        help="Cache directory (defaults to .chaptify_cache under output directory).",
    )
    p.add_argument(
        "--clear-cache",
        "--cc",
        action="store_true",
        help="Clear cached download/chunks/transcript for this input before running.",
    )
    p.add_argument("--quiet", action="store_true", help="Suppress progress output.")
    return p


def build_init_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="chaptify init", description="Initialize chaptify config.")
    return p


def build_config_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="chaptify config", description="Get or set config values.")
    sub = p.add_subparsers(dest="action", required=True)
    get_p = sub.add_parser("get", help="Get a config value.")
    get_p.add_argument("key", help="Config key (provider, model, groq_model, max_upload_mb, groq_api_key, openai_api_key).")
    set_p = sub.add_parser("set", help="Set a config value.")
    set_p.add_argument("key", help="Config key (provider, model, groq_model, max_upload_mb, groq_api_key, openai_api_key).")
    set_p.add_argument("value", help="New value.")
    show_p = sub.add_parser("show", help="Show all config values (masked).")
    return p


def main(argv: list[str] | None = None) -> None:
    argv = argv if argv is not None else sys.argv[1:]
    if argv and argv[0] == "init":
        build_init_parser().parse_args(argv[1:])
        config = prompt_init_config()
        save_config(config, CONFIG_PATH)
        print(f"Saved config: {CONFIG_PATH}")
        return
    if argv and argv[0] == "config":
        args = build_config_parser().parse_args(argv[1:])
        config = load_config(CONFIG_PATH)
        if args.action == "get":
            data = config_to_dict(config)
            print(data.get(args.key))
            return
        if args.action == "set":
            set_config_value(config, args.key, args.value)
            save_config(config, CONFIG_PATH)
            print(f"Saved config: {CONFIG_PATH}")
            return
        if args.action == "show":
            data = config_to_dict(config)
            # mask keys
            if data.get("groq_api_key"):
                data["groq_api_key"] = "***"
            if data.get("openai_api_key"):
                data["openai_api_key"] = "***"
            for k, v in data.items():
                print(f"{k} = {v}")
            return

    args = build_run_parser().parse_args(argv)

    env_file = Path(args.env_file).expanduser() if args.env_file else None
    load_env_upwards(start_dir=Path.cwd(), env_path=env_file)

    out_dir = Path(args.out_dir).expanduser() if args.out_dir else None
    cache_dir = Path(args.cache_dir).expanduser() if args.cache_dir else None

    config = load_config(CONFIG_PATH)

    # Apply --set-api-key updates (and update config on disk)
    if args.set_api_key:
        for pair in args.set_api_key:
            if "=" not in pair:
                continue
            k, v = pair.split("=", 1)
            set_config_value(config, k.strip(), v.strip())
        save_config(config, CONFIG_PATH)

    def report(msg: str) -> None:
        if not args.quiet:
            print(msg, file=sys.stderr)

    # Fill defaults from config if not explicitly set or in env
    llm_provider = args.llm_provider or config.default_provider or "openai"
    llm_model = args.llm_model or config.default_model
    groq_model = args.groq_model or (config.default_groq_model or "whisper-large-v3")
    max_upload_mb = args.max_upload_mb or (config.default_max_upload_mb or 25)

    # Set env keys from config if not present
    if not os.environ.get("GROQ_API_KEY") and config.groq_api_key:
        os.environ["GROQ_API_KEY"] = config.groq_api_key
    if not os.environ.get("OPENAI_API_KEY") and config.openai_api_key:
        os.environ["OPENAI_API_KEY"] = config.openai_api_key

    try:
        chapter_path, seo_path = run_chaptify(
            input_value=args.input,
            out_dir=out_dir,
            groq_model=groq_model,
            max_upload_mb=max_upload_mb,
            llm_provider=llm_provider,
            llm_model=llm_model,
            keep_temp=args.keep_temp,
            report=report,
            cache_dir=cache_dir,
            clear_cache=args.clear_cache,
            use_responses_api=args.use_responses_api,
            reasoning_effort=args.reasoning_effort,
            text_verbosity=args.text_verbosity,
            max_output_tokens=args.max_output_tokens,
        )
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc

    print(f"Chapters: {chapter_path}")
    print(f"SEO: {seo_path}")


if __name__ == "__main__":
    main()
