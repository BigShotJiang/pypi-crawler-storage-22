from __future__ import annotations

from dataclasses import dataclass
from getpass import getpass
from pathlib import Path
from typing import Any, Optional


CONFIG_DIR = Path.home() / ".config" / "chaptify"
CONFIG_PATH = CONFIG_DIR / "config.toml"


@dataclass
class ChaptifyConfig:
    groq_api_key: Optional[str] = None
    openai_api_key: Optional[str] = None
    default_provider: Optional[str] = None
    default_model: Optional[str] = None
    default_groq_model: Optional[str] = None
    default_max_upload_mb: Optional[int] = None


def _parse_value(raw: str) -> Any:
    s = raw.strip()
    if not s:
        return ""
    if s.startswith(("'", '"')) and s.endswith(("'", '"')) and len(s) >= 2:
        return s[1:-1]
    if s.isdigit():
        return int(s)
    if s.lower() in ("true", "false"):
        return s.lower() == "true"
    return s


def load_config(path: Path = CONFIG_PATH) -> ChaptifyConfig:
    if not path.exists():
        return ChaptifyConfig()

    current_section = ""
    data: dict[str, dict[str, Any]] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith(("#", ";")):
            continue
        if line.startswith("[") and line.endswith("]"):
            current_section = line[1:-1].strip()
            data.setdefault(current_section, {})
            continue
        if "=" in line:
            key, value = line.split("=", 1)
            key = key.strip()
            value = _parse_value(value)
            data.setdefault(current_section, {})[key] = value

    keys = data.get("keys", {})
    defaults = data.get("defaults", {})
    return ChaptifyConfig(
        groq_api_key=keys.get("groq_api_key"),
        openai_api_key=keys.get("openai_api_key"),
        default_provider=defaults.get("provider"),
        default_model=defaults.get("model"),
        default_groq_model=defaults.get("groq_model"),
        default_max_upload_mb=defaults.get("max_upload_mb"),
    )


def save_config(config: ChaptifyConfig, path: Path = CONFIG_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "[keys]",
        f'groq_api_key = "{config.groq_api_key or ""}"',
        f'openai_api_key = "{config.openai_api_key or ""}"',
        "",
        "[defaults]",
        f'provider = "{config.default_provider or ""}"',
        f'model = "{config.default_model or ""}"',
        f'groq_model = "{config.default_groq_model or ""}"',
        f"max_upload_mb = {config.default_max_upload_mb if config.default_max_upload_mb is not None else 25}",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def set_config_value(config: ChaptifyConfig, key: str, value: str) -> None:
    key = key.strip().lower()
    if key in ("groq_api_key", "groq", "groq_key"):
        config.groq_api_key = value
    elif key in ("openai_api_key", "openai", "openai_key"):
        config.openai_api_key = value
    elif key in ("provider", "default_provider"):
        config.default_provider = value
    elif key in ("model", "default_model"):
        config.default_model = value
    elif key in ("groq_model", "default_groq_model"):
        config.default_groq_model = value
    elif key in ("max_upload_mb", "default_max_upload_mb"):
        try:
            config.default_max_upload_mb = int(value)
        except ValueError:
            pass
    else:
        raise ValueError(f"Unknown config key: {key}")


def config_to_dict(config: ChaptifyConfig) -> dict[str, Any]:
    return {
        "groq_api_key": config.groq_api_key,
        "openai_api_key": config.openai_api_key,
        "provider": config.default_provider,
        "model": config.default_model,
        "groq_model": config.default_groq_model,
        "max_upload_mb": config.default_max_upload_mb,
        "path": str(CONFIG_PATH),
    }


def prompt_init_config() -> ChaptifyConfig:
    def ask(prompt: str, default: Optional[str] = None) -> str:
        suffix = f" [{default}]" if default else ""
        resp = input(f"{prompt}{suffix}: ").strip()
        return resp or (default or "")

    def ask_secret(prompt: str, default: Optional[str] = None) -> str:
        suffix = " [hidden]" if default else ""
        resp = getpass(f"{prompt}{suffix}: ").strip()
        return resp or (default or "")

    groq_key = ask_secret("GROQ_API_KEY (for transcription)")
    openai_key = ask_secret("OPENAI_API_KEY (for GPT-5)")
    provider = ask("Default LLM provider (openai/groq/gemini)", "openai")
    model = ask("Default LLM model", "gpt-5")
    groq_model = ask("Default Groq transcription model", "whisper-large-v3")
    max_upload_mb = ask("Max upload MB per chunk", "25")
    try:
        max_upload_mb_int = int(max_upload_mb)
    except ValueError:
        max_upload_mb_int = 25

    return ChaptifyConfig(
        groq_api_key=groq_key or None,
        openai_api_key=openai_key or None,
        default_provider=provider or None,
        default_model=model or None,
        default_groq_model=groq_model or None,
        default_max_upload_mb=max_upload_mb_int,
    )

