from __future__ import annotations

import os
from pathlib import Path
from typing import Optional


def _parse_env_line(line: str) -> tuple[str, str] | None:
    s = line.strip()
    if not s or s.startswith("#"):
        return None
    if "=" not in s:
        return None
    key, value = s.split("=", 1)
    key = key.strip()
    value = value.strip().strip("'").strip('"')
    if not key:
        return None
    return key, value


def _find_env_upwards(start_dir: Path) -> Optional[Path]:
    cur = start_dir.resolve()
    while True:
        candidate = cur / ".env"
        if candidate.exists():
            return candidate
        if cur.parent == cur:
            return None
        cur = cur.parent


def load_env_upwards(*, start_dir: Path, env_path: Optional[Path] = None) -> Optional[Path]:
    """
    Loads a `.env` file into process env without third-party deps.

    - If env_path is provided, loads only that file.
    - Otherwise searches for `.env` from start_dir up to filesystem root.
    - Does not overwrite existing environment variables.
    """
    path = env_path if env_path is not None else _find_env_upwards(start_dir)
    if path is None or not path.exists():
        return None

    for raw in path.read_text(encoding="utf-8").splitlines():
        parsed = _parse_env_line(raw)
        if not parsed:
            continue
        k, v = parsed
        os.environ.setdefault(k, v)
    return path

