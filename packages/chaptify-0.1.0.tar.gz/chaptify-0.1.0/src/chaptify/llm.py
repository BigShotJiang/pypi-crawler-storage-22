from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Any, Literal
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class LlmConfigError(RuntimeError):
    pass


LlmProvider = Literal["openai", "gemini", "groq"]


OPENAI_CHAT_URL = "https://api.openai.com/v1/chat/completions"
OPENAI_RESPONSES_URL = "https://api.openai.com/v1/responses"
GROQ_CHAT_URL = "https://api.groq.com/openai/v1/chat/completions"
DEFAULT_USER_AGENT = os.environ.get(
    "CHAPTIFY_USER_AGENT",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0 Safari/537.36",
)


def _post_json(
    *,
    url: str,
    headers: dict[str, str],
    payload: dict[str, Any],
    timeout_seconds: float,
    max_retries: int = 4,
) -> dict[str, Any]:
    backoff_seconds = 0.8
    last_exc: Exception | None = None

    for attempt in range(1, max_retries + 1):
        data = json.dumps(payload).encode("utf-8")
        req = Request(
            url=url,
            data=data,
            method="POST",
            headers={
                **headers,
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": DEFAULT_USER_AGENT,
            },
        )
        try:
            with urlopen(req, timeout=timeout_seconds) as resp:  # nosec - intended external request
                raw = resp.read()
            try:
                return json.loads(raw.decode("utf-8"))
            except Exception as exc:
                raise LlmConfigError("Invalid JSON response from LLM.") from exc
        except HTTPError as exc:
            status = exc.code
            msg = ""
            try:
                msg = exc.read().decode("utf-8", errors="replace")[:1500]
            except Exception:
                msg = str(exc)

            if status in (429,) or 500 <= status <= 599:
                last_exc = LlmConfigError(f"LLM request failed ({status}): {msg}")
                if attempt < max_retries:
                    retry_after = None
                    try:
                        ra = exc.headers.get("Retry-After") if exc.headers else None
                        retry_after = float(ra) if ra else None
                    except Exception:
                        retry_after = None
                    time.sleep(retry_after if retry_after is not None else backoff_seconds)
                    backoff_seconds = min(backoff_seconds * 2, 8.0)
                    continue
                raise last_exc from exc

            raise LlmConfigError(f"LLM request failed ({status}): {msg}") from exc
        except URLError as exc:
            last_exc = LlmConfigError(f"Network error calling LLM: {exc}")
            if attempt < max_retries:
                time.sleep(backoff_seconds)
                backoff_seconds = min(backoff_seconds * 2, 8.0)
                continue
            raise last_exc from exc

    if last_exc is not None:
        raise last_exc
    raise LlmConfigError("LLM request failed (unknown error).")


def _openai_compat_chat(
    *,
    url: str,
    api_key: str,
    model: str,
    system: str,
    user: str,
    temperature: float = 0.2,
    timeout_seconds: float = 180.0,
) -> str:
    payload: dict[str, Any] = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    }
    # GPT-5 models can be strict about sampling params; only default temperature (1)
    # may be accepted. Omit temperature for GPT-5.
    if not model.startswith("gpt-5"):
        payload["temperature"] = temperature
    headers = {"Authorization": f"Bearer {api_key}"}
    data = _post_json(url=url, headers=headers, payload=payload, timeout_seconds=timeout_seconds)

    try:
        return data["choices"][0]["message"]["content"].strip()
    except Exception as exc:
        raise LlmConfigError(
            "Unexpected LLM response shape (missing choices[0].message.content)."
        ) from exc


def _openai_responses(
    *,
    api_key: str,
    model: str,
    system: str,
    user: str,
    reasoning_effort: str | None = None,
    text_verbosity: str | None = None,
    max_output_tokens: int | None = None,
    timeout_seconds: float = 180.0,
) -> str:
    payload: dict[str, Any] = {
        "model": model,
        "input": [
            {
                "role": "system",
                "content": [{"type": "input_text", "text": system}],
            },
            {
                "role": "user",
                "content": [{"type": "input_text", "text": user}],
            },
        ],
    }
    if reasoning_effort:
        payload["reasoning"] = {"effort": reasoning_effort}
    if text_verbosity:
        payload["text"] = {"verbosity": text_verbosity}
    if max_output_tokens is not None:
        payload["max_output_tokens"] = int(max_output_tokens)

    headers = {"Authorization": f"Bearer {api_key}"}
    data = _post_json(url=OPENAI_RESPONSES_URL, headers=headers, payload=payload, timeout_seconds=timeout_seconds)

    if isinstance(data.get("output_text"), str) and data["output_text"].strip():
        return data["output_text"].strip()

    out = data.get("output")
    if isinstance(out, list):
        texts: list[str] = []
        for item in out:
            if not isinstance(item, dict):
                continue
            if item.get("type") != "message":
                continue
            content = item.get("content")
            if not isinstance(content, list):
                continue
            for c in content:
                if not isinstance(c, dict):
                    continue
                if c.get("type") == "output_text" and isinstance(c.get("text"), str):
                    texts.append(c["text"])
        joined = "\n".join(t.strip() for t in texts if t and t.strip()).strip()
        if joined:
            return joined

    raise LlmConfigError("Unexpected Responses API shape (no output_text/output content).")


CHAPTERS_SYSTEM = (
    "You are an expert YouTube editor. Your job is to create YouTube chapters from a transcript.\n"
    "Rules:\n"
    "- Output ONLY the chapters, one per line.\n"
    "- Format each line exactly like: M:SS Chapter name  (or H:MM:SS if needed)\n"
    "- The FIRST line MUST be: 0:00 Introduction\n"
    "- Use timestamps from the transcript. Timestamps must be increasing.\n"
    "- Create chapters at meaningful topic changes (key points), not every minor sentence.\n"
    "- Keep chapter names short and descriptive.\n"
)


CHAPTERS_USER = (
    "Transcript (timestamped):\n"
    "{transcript}\n\n"
    "Create the chapters now."
)


SEO_SYSTEM = (
    "You are a YouTube growth and SEO expert.\n"
    "Return ONLY the following sections, in this order:\n"
    "TITLES:\n"
    "- 5 SEO-optimized title options (one per line)\n"
    "DESCRIPTIONS:\n"
    "- 2 short description options (one per line)\n"
    "TAGS:\n"
    "- One line with comma-separated tags\n"
)


SEO_USER = (
    "Transcript (timestamped):\n"
    "{transcript}\n\n"
    "Generate TITLES, DESCRIPTIONS, and TAGS."
)


@dataclass(frozen=True)
class LlmOutputs:
    chapters: str
    seo: str


def _generate_single(
    *,
    provider: LlmProvider,
    model: str,
    system: str,
    user: str,
    use_responses_api: bool | None = None,
    reasoning_effort: str | None = None,
    text_verbosity: str | None = None,
    max_output_tokens: int | None = None,
) -> str:
    provider = provider.lower().strip()  # type: ignore[assignment]
    if provider == "gemini":
        # LangChain only (stdlib Gemini client not implemented).
        try:
            from langchain_core.prompts import ChatPromptTemplate  # type: ignore
        except Exception as exc:
            raise LlmConfigError("LangChain is not installed. Install with: pip install -e '.[langchain]'") from exc

        try:
            from langchain_google_genai import ChatGoogleGenerativeAI  # type: ignore
        except Exception as exc:
            raise LlmConfigError(
                "Gemini provider requires langchain-google-genai. Install with: pip install -e '.[gemini,langchain]'"
            ) from exc

        llm = ChatGoogleGenerativeAI(model=model, temperature=0.2)
        prompt = ChatPromptTemplate.from_messages([("system", system), ("human", user)])
        msg = (prompt | llm).invoke({})
        content = getattr(msg, "content", str(msg))
        return str(content).strip()

    if provider == "openai":
        api_key = os.environ.get("OPENAI_API_KEY", "").strip()
        if api_key:
            use_responses = use_responses_api
            if use_responses is None:
                use_responses = model.startswith("gpt-5")
            if use_responses:
                return _openai_responses(
                    api_key=api_key,
                    model=model,
                    system=system,
                    user=user,
                    reasoning_effort=reasoning_effort,
                    text_verbosity=text_verbosity,
                    max_output_tokens=max_output_tokens,
                )
            return _openai_compat_chat(url=OPENAI_CHAT_URL, api_key=api_key, model=model, system=system, user=user)

        # If OPENAI_API_KEY isn't set, try LangChain which may support alternative auth flows.
        try:
            from langchain_core.prompts import ChatPromptTemplate  # type: ignore
        except Exception as exc:
            raise LlmConfigError(
                "LangChain is not installed. Install with: pip install -e '.[langchain]'"
            ) from exc

        try:
            from langchain_openai import ChatOpenAI  # type: ignore
        except Exception as exc:
            raise LlmConfigError("langchain-openai is not installed. Install with: pip install -e '.[langchain]'") from exc

        llm = ChatOpenAI(model=model, temperature=0.2)
        prompt = ChatPromptTemplate.from_messages([("system", system), ("human", user)])
        msg = (prompt | llm).invoke({})
        content = getattr(msg, "content", str(msg))
        return str(content).strip()

    if provider == "groq":
        api_key = os.environ.get("GROQ_API_KEY", "").strip()
        if not api_key:
            raise LlmConfigError("Missing GROQ_API_KEY.")
        return _openai_compat_chat(
            url=GROQ_CHAT_URL,
            api_key=api_key,
            model=model,
            system=system,
            user=user,
        )

    raise LlmConfigError(f"Unsupported llm provider: {provider}")


def generate_chapters(
    *,
    provider: LlmProvider,
    model: str,
    transcript: str,
    use_responses_api: bool | None = None,
    reasoning_effort: str | None = None,
    text_verbosity: str | None = None,
    max_output_tokens: int | None = None,
) -> str:
    return _generate_single(
        provider=provider,
        model=model,
        system=CHAPTERS_SYSTEM,
        user=CHAPTERS_USER.format(transcript=transcript.strip()),
        use_responses_api=use_responses_api,
        reasoning_effort=reasoning_effort,
        text_verbosity=text_verbosity,
        max_output_tokens=max_output_tokens,
    )


def generate_seo(
    *,
    provider: LlmProvider,
    model: str,
    transcript: str,
    use_responses_api: bool | None = None,
    reasoning_effort: str | None = None,
    text_verbosity: str | None = None,
    max_output_tokens: int | None = None,
) -> str:
    return _generate_single(
        provider=provider,
        model=model,
        system=SEO_SYSTEM,
        user=SEO_USER.format(transcript=transcript.strip()),
        use_responses_api=use_responses_api,
        reasoning_effort=reasoning_effort,
        text_verbosity=text_verbosity,
        max_output_tokens=max_output_tokens,
    )


def generate_outputs(*, provider: LlmProvider, model: str, transcript: str) -> LlmOutputs:
    chapters = generate_chapters(provider=provider, model=model, transcript=transcript)
    seo = generate_seo(provider=provider, model=model, transcript=transcript)
    return LlmOutputs(chapters=chapters + "\n", seo=seo + "\n")
