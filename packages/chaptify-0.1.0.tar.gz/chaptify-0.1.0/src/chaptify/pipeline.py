from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path
from typing import Callable, Optional, Tuple
from typing import cast
import json

from chaptify.audio import extract_and_chunk_to_mp3, load_chunks_from_dir
from chaptify.cache import (
    cache_key_for_file,
    cache_key_for_url,
    clear_cache as clear_cache_dir,
    get_cache_paths,
    read_json,
    write_json,
)
from chaptify.llm import LlmProvider, generate_chapters, generate_seo
from chaptify.transcribe_groq import Transcript, TranscriptSegment, transcribe_chunks
from chaptify.utils import format_youtube_timestamp, is_url
from chaptify.youtube import download_youtube_audio


class ChaptifyError(RuntimeError):
    pass


def _normalize_chapters(text: str) -> str:
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        return "0:00 Introduction\n"

    first = lines[0]
    if not first.startswith("0:00"):
        lines.insert(0, "0:00 Introduction")
    elif first.lower() != "0:00 introduction":
        lines[0] = "0:00 Introduction"

    return "\n".join(lines) + "\n"


def _render_timestamped_transcript(segments) -> str:
    # One segment per line; keeps timestamps easy for the LLM to reference.
    lines: list[str] = []
    for seg in segments:
        ts = format_youtube_timestamp(seg.start_seconds)
        txt = " ".join(seg.text.split())
        if not txt:
            continue
        lines.append(f"{ts} {txt}")
    return "\n".join(lines).strip() + "\n"


def _transcript_from_json(payload: dict) -> Transcript:
    segments_raw = payload.get("segments")
    segments: list[TranscriptSegment] = []
    if isinstance(segments_raw, list):
        for seg in segments_raw:
            if not isinstance(seg, dict):
                continue
            start = seg.get("start_seconds")
            end = seg.get("end_seconds")
            text = seg.get("text")
            if not isinstance(start, (int, float)) or not isinstance(end, (int, float)) or not isinstance(text, str):
                continue
            segments.append(TranscriptSegment(start_seconds=float(start), end_seconds=float(end), text=text))
    segments.sort(key=lambda s: (s.start_seconds, s.end_seconds))
    return Transcript(segments=segments)


def _transcript_to_json(transcript: Transcript) -> dict:
    return {
        "segments": [
            {
                "start_seconds": s.start_seconds,
                "end_seconds": s.end_seconds,
                "text": s.text,
            }
            for s in transcript.segments
        ]
    }


def run_chaptify(
    *,
    input_value: str,
    out_dir: Optional[Path],
    groq_model: str,
    max_upload_mb: int,
    llm_provider: str,
    llm_model: Optional[str],
    keep_temp: bool,
    report: Optional[Callable[[str], None]] = None,
    cache_dir: Optional[Path] = None,
    clear_cache: bool = False,
    use_responses_api: Optional[bool] = None,
    reasoning_effort: Optional[str] = None,
    text_verbosity: Optional[str] = None,
    max_output_tokens: Optional[int] = None,
) -> Tuple[Path, Path]:
    if max_upload_mb <= 0:
        raise ChaptifyError("--max-upload-mb must be > 0")

    input_value = input_value.strip()
    tmp_root: Optional[Path] = None
    cleanup_tmp = False
    cache_paths = None

    def _report(msg: str) -> None:
        if report is not None:
            report(msg)

    try:
        if is_url(input_value):
            output_dir = out_dir or Path.cwd()
            key = cache_key_for_url(input_value)
            base = cache_dir or output_dir
            cache_paths = get_cache_paths(base_dir=base, key=key)
            if clear_cache:
                _report(f"Clearing cache: {cache_paths.root}")
                clear_cache_dir(cache_paths)
            cache_paths.downloads_dir.mkdir(parents=True, exist_ok=True)
            cache_paths.chunks_dir.mkdir(parents=True, exist_ok=True)
            _report(f"Cache: {cache_paths.root}")
            meta_existing = read_json(cache_paths.meta_json) or {}
            stem = meta_existing.get("stem") if isinstance(meta_existing, dict) else None
            if not isinstance(stem, str) or not stem.strip():
                stem = key

            if keep_temp:
                tmp_root = output_dir / ".chaptify_tmp"
                tmp_root.mkdir(parents=True, exist_ok=True)
            else:
                tmp_root = Path(tempfile.mkdtemp(prefix="chaptify_"))
                cleanup_tmp = True
        else:
            source_path = Path(input_value).expanduser()
            if not source_path.exists():
                raise ChaptifyError(f"Input file not found: {source_path}")
            stem = source_path.stem
            output_dir = out_dir or source_path.parent
            key = cache_key_for_file(source_path)
            base = cache_dir or output_dir
            cache_paths = get_cache_paths(base_dir=base, key=key)
            if clear_cache:
                _report(f"Clearing cache: {cache_paths.root}")
                clear_cache_dir(cache_paths)
            cache_paths.downloads_dir.mkdir(parents=True, exist_ok=True)
            cache_paths.chunks_dir.mkdir(parents=True, exist_ok=True)
            _report(f"Cache: {cache_paths.root}")
            if keep_temp:
                tmp_root = output_dir / ".chaptify_tmp"
                tmp_root.mkdir(parents=True, exist_ok=True)
            else:
                tmp_root = Path(tempfile.mkdtemp(prefix="chaptify_"))
                cleanup_tmp = True

        max_upload_bytes = max_upload_mb * 1024 * 1024

        # Chunk cache
        if cache_paths is None:
            raise ChaptifyError("Internal error: cache paths not initialized.")
        # Transcript cache (if present, can skip download/chunking entirely for URLs).
        meta = read_json(cache_paths.meta_json) or {}
        if isinstance(meta, dict) and isinstance(meta.get("stem"), str) and meta.get("stem"):
            stem = meta["stem"]

        if (
            isinstance(meta, dict)
            and meta.get("groq_model") == groq_model
            and meta.get("max_upload_mb") == max_upload_mb
            and cache_paths.transcript_json.exists()
            and cache_paths.transcript_txt.exists()
        ):
            _report(f"Using cached transcript: {cache_paths.transcript_txt}")
            payload = read_json(cache_paths.transcript_json) or {}
            transcript = _transcript_from_json(payload)
            transcript_for_llm = cache_paths.transcript_txt.read_text(encoding="utf-8")
        else:
            # Need a source file (download for URL).
            if is_url(input_value):
                cached_downloads = sorted(cache_paths.downloads_dir.glob("source.*"))
                if cached_downloads:
                    cached_source = max(cached_downloads, key=lambda p: p.stat().st_mtime)
                    _report(f"Using cached YouTube audio: {cached_source}")
                    source_path = cached_source
                else:
                    _report("Downloading YouTube audio...")
                    source_path = download_youtube_audio(url=input_value, out_dir=cache_paths.downloads_dir)
                    _report(f"Downloaded: {source_path}")
                stem = source_path.stem
            # Chunks
            chunks_meta_path = cache_paths.root / "chunks_meta.json"
            chunks_meta = read_json(chunks_meta_path) or {}
            reuse_chunks = (
                isinstance(chunks_meta, dict)
                and chunks_meta.get("max_upload_mb") == max_upload_mb
                and list(cache_paths.chunks_dir.glob("chunk_*.mp3"))
            )

            if reuse_chunks:
                _report(f"Using cached chunks: {cache_paths.chunks_dir}")
                chunks = load_chunks_from_dir(chunks_dir=cache_paths.chunks_dir)
            else:
                _report("Converting to audio + chunking for transcription...")
                chunks = extract_and_chunk_to_mp3(
                    input_path=source_path,
                    temp_dir=cache_paths.chunks_dir,
                    max_upload_bytes=max_upload_bytes,
                )
                write_json(
                    chunks_meta_path,
                    {
                        "max_upload_mb": max_upload_mb,
                        "chunks": [{"name": c.path.name, "bytes": c.path.stat().st_size} for c in chunks],
                    },
                )
                _report(f"Created {len(chunks)} chunk(s) at {cache_paths.chunks_dir}.")

            groq_key = os.environ.get("GROQ_API_KEY", "").strip()
            _report("Transcribing with Groq (Whisper)...")
            for i, c in enumerate(chunks, start=1):
                _report(f"  - chunk {i}/{len(chunks)}: {c.path.name}")
            transcript = transcribe_chunks(chunks=chunks, api_key=groq_key, model=groq_model)
            transcript_for_llm = _render_timestamped_transcript(transcript.segments)
            cache_paths.transcript_json.write_text(
                json.dumps(_transcript_to_json(transcript), indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            cache_paths.transcript_txt.write_text(transcript_for_llm, encoding="utf-8")
            write_json(
                cache_paths.meta_json,
                {
                    "input": input_value,
                    "stem": stem,
                    "groq_model": groq_model,
                    "max_upload_mb": max_upload_mb,
                },
            )
            _report(f"Transcription complete. Saved: {cache_paths.transcript_txt}")

        provider_raw = llm_provider.lower().strip()
        if provider_raw not in ("openai", "gemini", "groq"):
            raise ChaptifyError("--llm-provider must be one of: openai, gemini, groq")
        provider = cast(LlmProvider, provider_raw)
        model = (llm_model or os.environ.get("CHAPTIFY_LLM_MODEL") or "").strip()
        if not model:
            if provider == "openai":
                model = "gpt-5"
            elif provider == "gemini":
                model = "gemini-2.0-flash"
            else:
                model = "llama-3.1-70b-versatile"

        _report(f"Generating chapters with {provider}:{model} ...")
        chapters_text = generate_chapters(
            provider=provider,
            model=model,
            transcript=transcript_for_llm,
            use_responses_api=use_responses_api,
            reasoning_effort=reasoning_effort,
            text_verbosity=text_verbosity,
            max_output_tokens=max_output_tokens,
        )
        _report("Generating titles/descriptions/tags...")
        seo_text = generate_seo(
            provider=provider,
            model=model,
            transcript=transcript_for_llm,
            use_responses_api=use_responses_api,
            reasoning_effort=reasoning_effort,
            text_verbosity=text_verbosity,
            max_output_tokens=max_output_tokens,
        )

        chapter_path = output_dir / f"{stem}_chapter.txt"
        seo_path = output_dir / f"{stem}_seo.txt"

        _report("Saving outputs...")
        chapter_path.write_text(_normalize_chapters(chapters_text), encoding="utf-8")
        seo_path.write_text(seo_text.strip() + "\n", encoding="utf-8")

        return chapter_path, seo_path
    finally:
        if cleanup_tmp and tmp_root is not None:
            shutil.rmtree(tmp_root, ignore_errors=True)
