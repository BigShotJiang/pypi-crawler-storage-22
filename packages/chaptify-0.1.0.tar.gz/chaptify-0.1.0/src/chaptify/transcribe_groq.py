from __future__ import annotations

import json
import mimetypes
import os
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from chaptify.audio import AudioChunk


class GroqTranscriptionError(RuntimeError):
    pass


@dataclass(frozen=True)
class TranscriptSegment:
    start_seconds: float
    end_seconds: float
    text: str


@dataclass(frozen=True)
class Transcript:
    segments: list[TranscriptSegment]

    @property
    def text(self) -> str:
        return " ".join(s.text.strip() for s in self.segments if s.text.strip()).strip()


GROQ_TRANSCRIBE_URL = "https://api.groq.com/openai/v1/audio/transcriptions"
DEFAULT_USER_AGENT = os.environ.get(
    "CHAPTIFY_USER_AGENT",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0 Safari/537.36",
)


def _iter_segments_verbose_json(payload: dict[str, Any]) -> Iterable[dict[str, Any]]:
    segments = payload.get("segments")
    if isinstance(segments, list):
        for seg in segments:
            if isinstance(seg, dict):
                yield seg


def _multipart_encode(
    *,
    fields: list[tuple[str, str]],
    file_field: str,
    file_path: Path,
    filename: Optional[str] = None,
    content_type: Optional[str] = None,
) -> tuple[bytes, str]:
    boundary = f"----chaptify-{uuid.uuid4().hex}"
    crlf = b"\r\n"

    if filename is None:
        filename = file_path.name
    if content_type is None:
        content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"

    parts: list[bytes] = []
    for k, v in fields:
        parts.append(f"--{boundary}".encode())
        parts.append(f'Content-Disposition: form-data; name="{k}"'.encode())
        parts.append(b"")
        parts.append(v.encode())

    data = file_path.read_bytes()
    parts.append(f"--{boundary}".encode())
    parts.append(
        f'Content-Disposition: form-data; name="{file_field}"; filename="{filename}"'.encode()
    )
    parts.append(f"Content-Type: {content_type}".encode())
    parts.append(b"")
    parts.append(data)

    parts.append(f"--{boundary}--".encode())
    body = crlf.join(parts) + crlf
    return body, boundary


def _post_multipart_json(
    *,
    url: str,
    api_key: str,
    fields: list[tuple[str, str]],
    file_path: Path,
    timeout_seconds: float,
) -> dict[str, Any]:
    try:
        body, boundary = _multipart_encode(fields=fields, file_field="file", file_path=file_path)
    except OSError as exc:
        raise GroqTranscriptionError(f"Failed to read audio chunk {file_path}: {exc}") from exc

    req = Request(
        url=url,
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Accept": "application/json",
            "User-Agent": DEFAULT_USER_AGENT,
        },
    )

    try:
        with urlopen(req, timeout=timeout_seconds) as resp:  # nosec - intended external request
            raw = resp.read()
    except HTTPError as exc:
        msg = ""
        try:
            msg = exc.read().decode("utf-8", errors="replace")[:800]
        except Exception:
            msg = str(exc)
        hint = ""
        if exc.code == 403 and "error code: 1010" in msg:
            hint = (
                " (This is commonly a Cloudflare/WAF block; try disabling VPN/proxy or switching networks.)"
            )
        raise GroqTranscriptionError(
            f"Groq transcription failed ({exc.code}) for {file_path.name}: {msg}{hint}"
        ) from exc
    except URLError as exc:
        raise GroqTranscriptionError(f"Network error calling Groq for {file_path.name}: {exc}") from exc

    try:
        return json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise GroqTranscriptionError(f"Invalid JSON response from Groq for {file_path.name}") from exc


def transcribe_chunks(
    *,
    chunks: list[AudioChunk],
    api_key: str,
    model: str = "whisper-large-v3",
    timeout_seconds: float = 180.0,
) -> Transcript:
    """
    Transcribe audio chunks using Groq's OpenAI-compatible transcription endpoint.

    Requests `verbose_json` + segment timestamps, and offsets timestamps by each chunk's start time.
    """
    if not api_key:
        raise GroqTranscriptionError("Missing GROQ_API_KEY.")

    all_segments: list[TranscriptSegment] = []
    for chunk in chunks:
        fields = [
            ("model", model),
            ("response_format", "verbose_json"),
            ("timestamp_granularities[]", "segment"),
        ]
        payload = _post_multipart_json(
            url=GROQ_TRANSCRIBE_URL,
            api_key=api_key,
            fields=fields,
            file_path=chunk.path,
            timeout_seconds=timeout_seconds,
        )

        before_count = len(all_segments)
        for seg in _iter_segments_verbose_json(payload):
            start = seg.get("start")
            end = seg.get("end")
            text = seg.get("text", "")
            if not isinstance(text, str):
                continue
            if not isinstance(start, (int, float)) or not isinstance(end, (int, float)):
                continue
            all_segments.append(
                TranscriptSegment(
                    start_seconds=float(start) + chunk.start_seconds,
                    end_seconds=float(end) + chunk.start_seconds,
                    text=text,
                )
            )

        if len(all_segments) == before_count:
            text = payload.get("text", "")
            if isinstance(text, str) and text.strip():
                all_segments.append(
                    TranscriptSegment(
                        start_seconds=chunk.start_seconds,
                        end_seconds=chunk.start_seconds + chunk.duration_seconds,
                        text=text.strip(),
                    )
                )

    all_segments.sort(key=lambda s: (s.start_seconds, s.end_seconds))
    return Transcript(segments=all_segments)
