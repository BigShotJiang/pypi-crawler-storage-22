from __future__ import annotations

import re


_URL_RE = re.compile(r"^https?://", re.IGNORECASE)


def is_url(value: str) -> bool:
    return bool(_URL_RE.match(value.strip()))


def format_youtube_timestamp(seconds: float) -> str:
    total = max(0, int(seconds))
    hours = total // 3600
    minutes = (total % 3600) // 60
    secs = total % 60
    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"
