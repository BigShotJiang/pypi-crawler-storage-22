from __future__ import annotations

import shutil
import subprocess
from pathlib import Path


class YouTubeDownloadError(RuntimeError):
    pass


def download_youtube_audio(*, url: str, out_dir: Path) -> Path:
    """
    Downloads best-available audio for a YouTube URL.

    Returns the downloaded filepath.
    """
    out_dir.mkdir(parents=True, exist_ok=True)

    cached = sorted(out_dir.glob("source.*"))
    if cached:
        return max(cached, key=lambda p: p.stat().st_mtime)

    try:
        import yt_dlp  # type: ignore

        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": str(out_dir / "source.%(ext)s"),
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
        }

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            if not isinstance(info, dict):
                raise YouTubeDownloadError("yt-dlp did not return video info.")
            filename = ydl.prepare_filename(info)
            path = Path(filename)
            if path.exists():
                return path
            # Some extractors may alter extension; try requested_downloads.
            requested = info.get("requested_downloads")
            if isinstance(requested, list) and requested:
                filepath = requested[0].get("filepath")
                if isinstance(filepath, str) and Path(filepath).exists():
                    return Path(filepath)
            raise YouTubeDownloadError("yt-dlp reported success, but file not found on disk.")
    except ModuleNotFoundError:
        # Fallback to yt-dlp binary if present.
        if shutil.which("yt-dlp") is None:
            raise YouTubeDownloadError(
                "YouTube download requires `yt-dlp`. Install either the Python package `yt-dlp` "
                "or the `yt-dlp` command on your PATH."
            )
        outtmpl = str(out_dir / "source.%(ext)s")
        cmd = ["yt-dlp", "-f", "bestaudio/best", "--no-playlist", "-o", outtmpl, url]
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True)
        except subprocess.CalledProcessError as exc:
            raise YouTubeDownloadError(exc.stderr.strip() or exc.stdout.strip() or "yt-dlp failed") from exc

        candidates = sorted(out_dir.glob("source.*"))
        if not candidates:
            raise YouTubeDownloadError("yt-dlp finished but no files were created.")
        return max(candidates, key=lambda p: p.stat().st_mtime)
    except Exception as exc:
        # Normalize yt_dlp's DownloadError and other runtime failures.
        raise YouTubeDownloadError(str(exc)) from exc
