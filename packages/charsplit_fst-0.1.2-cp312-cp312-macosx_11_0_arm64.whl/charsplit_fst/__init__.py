from .charsplit_fst import *

__doc__ = charsplit_fst.__doc__
if hasattr(charsplit_fst, "__all__"):
    __all__ = charsplit_fst.__all__