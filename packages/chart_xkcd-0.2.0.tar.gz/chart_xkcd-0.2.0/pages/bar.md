::: chart_xkcd.bar
