::: chart_xkcd.line
