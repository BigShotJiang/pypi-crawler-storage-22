::: chart_xkcd.radar
