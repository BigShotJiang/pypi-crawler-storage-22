::: chart_xkcd.renderer
