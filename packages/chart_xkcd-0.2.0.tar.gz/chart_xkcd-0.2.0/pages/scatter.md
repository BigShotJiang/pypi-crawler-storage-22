::: chart_xkcd.scatter
