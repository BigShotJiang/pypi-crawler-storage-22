"""
PyPI 一键发布脚本
用法:
    python publish.py          # 发布到 PyPI
    python publish.py --test   # 发布到 TestPyPI
"""

import subprocess
import sys
import shutil
from pathlib import Path

DIST_DIR = Path(__file__).parent / "dist"


def run(cmd: str):
    """执行命令并实时输出"""
    print(f"\n>>> {cmd}")
    result = subprocess.run(cmd, shell=True)
    if result.returncode != 0:
        print(f"\n❌ 命令失败 (exit code: {result.returncode})")
        sys.exit(result.returncode)


def main():
    is_test = "--test" in sys.argv

    # 1. 清理 dist 目录
    if DIST_DIR.exists():
        print(f"🗑️  清理 {DIST_DIR} ...")
        shutil.rmtree(DIST_DIR)

    # 2. 构建
    print("📦 开始构建...")
    run("python -m build")

    # 3. 上传
    if is_test:
        print("🚀 上传到 TestPyPI...")
        run("python -m twine upload --repository testpypi dist/*")
    else:
        print("🚀 上传到 PyPI...")
        run("python -m twine upload dist/*")

    print("\n✅ 发布完成！")


if __name__ == "__main__":
    main()