#!/usr/bin/env python3
"""
CLI Options Test for ChatCMD
Tests all command-line options to ensure they work correctly
Run: python tests/test_cli_options.py
"""

import subprocess
import sys
import os
import tempfile
import shutil

# Colors for output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
BOLD = '\033[1m'
END = '\033[0m'

# Track results
passed = 0
failed = 0
skipped = 0
results = []


def run_cmd(args, input_text=None, timeout=30, expect_error=False):
    """Run chatcmd with given arguments"""
    cmd = [sys.executable, '-m', 'chatcmd'] + args
    try:
        result = subprocess.run(
            cmd,
            input=input_text,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        )
        success = (result.returncode == 0) if not expect_error else (result.returncode != 0)
        return success, result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return False, "", "Timeout", -1
    except Exception as e:
        return False, "", str(e), -1


def run_test(name, args, input_text=None, expect_in_output=None, expect_not_in_output=None,
         expect_error=False, skip_reason=None):
    """Run a single test"""
    global passed, failed, skipped

    if skip_reason:
        print(f"  {YELLOW}SKIP{END} {name}: {skip_reason}")
        skipped += 1
        results.append(('SKIP', name, skip_reason))
        return

    success, stdout, stderr, code = run_cmd(args, input_text, expect_error=expect_error)
    output = stdout + stderr

    # Check expected content
    if success and expect_in_output:
        for expected in expect_in_output:
            if expected.lower() not in output.lower():
                success = False
                break

    if success and expect_not_in_output:
        for not_expected in expect_not_in_output:
            if not_expected.lower() in output.lower():
                success = False
                break

    if success:
        print(f"  {GREEN}PASS{END} {name}")
        passed += 1
        results.append(('PASS', name, None))
    else:
        print(f"  {RED}FAIL{END} {name}")
        if stderr:
            print(f"       Error: {stderr[:200]}")
        failed += 1
        results.append(('FAIL', name, stderr[:200] if stderr else "Unknown error"))


def main():
    global passed, failed, skipped

    print(f"\n{BOLD}{CYAN}=" * 60)
    print("ChatCMD CLI Options Test")
    print("=" * 60 + f"{END}\n")

    # ============================================================
    # HELP & INFO OPTIONS
    # ============================================================
    print(f"{BOLD}[Help & Info Options]{END}")

    run_test("--help shows usage",
         ['--help'],
         expect_in_output=['usage', 'chatcmd'])

    run_test("-h shows usage",
         ['-h'],
         expect_in_output=['usage', 'chatcmd'])

    run_test("--version shows version",
         ['--version'],
         expect_in_output=['chatcmd'])

    run_test("-v shows version",
         ['-v'],
         expect_in_output=['chatcmd'])

    run_test("--library-info shows library info",
         ['--library-info'],
         expect_in_output=['library', 'naif'])

    run_test("-x shows library info",
         ['-x'],
         expect_in_output=['library', 'naif'])

    # ============================================================
    # MODEL OPTIONS
    # ============================================================
    print(f"\n{BOLD}[Model Options]{END}")

    run_test("--list-models shows available models",
         ['--list-models'],
         expect_in_output=['openai', 'model'])

    run_test("--current-model shows current model",
         ['--current-model'],
         expect_in_output=['current', 'model'])

    run_test("--model-info gpt-4 shows model info",
         ['--model-info', 'gpt-4'],
         expect_in_output=['gpt-4'])

    run_test("--model-info invalid shows error",
         ['--model-info', 'invalid-model-xyz'],
         expect_in_output=['not found'])

    # ============================================================
    # HISTORY OPTIONS
    # ============================================================
    print(f"\n{BOLD}[History Options]{END}")

    run_test("--cmd-total shows command count",
         ['--cmd-total'],
         expect_in_output=['total', 'command'])

    run_test("-t shows command count",
         ['-t'],
         expect_in_output=['total', 'command'])

    run_test("--get-cmd shows last command",
         ['--get-cmd'],
         expect_in_output=[])  # May be empty or show command

    run_test("-g shows last command",
         ['-g'],
         expect_in_output=[])

    run_test("--get-last=3 shows last 3 commands",
         ['--get-last=3'],
         expect_in_output=[])

    run_test("-G 3 shows last 3 commands",
         ['-G', '3'],
         expect_in_output=[])

    run_test("--db-size shows database size",
         ['--db-size'],
         expect_in_output=['db', 'size'])

    run_test("-s shows database size",
         ['-s'],
         expect_in_output=['db', 'size'])

    # ============================================================
    # PERFORMANCE OPTIONS
    # ============================================================
    print(f"\n{BOLD}[Performance Options]{END}")

    run_test("--performance-stats shows stats",
         ['--performance-stats'],
         expect_in_output=['performance', 'request'])

    # ============================================================
    # DEVELOPER TOOLS (non-interactive tests)
    # ============================================================
    print(f"\n{BOLD}[Developer Tools]{END}")

    run_test("--generate-uuid 4 generates UUID v4",
         ['--generate-uuid', '4'],
         expect_in_output=['uuid'])

    run_test("--generate-uuid 1 generates UUID v1 with warning",
         ['--generate-uuid', '1'],
         expect_in_output=['uuid', 'warning'])

    # ============================================================
    # TOOL OPTIONS (require input - test with echo pipe)
    # ============================================================
    print(f"\n{BOLD}[Tools with Input]{END}")

    run_test("--random-password generates password",
         ['--random-password'],
         expect_in_output=[])  # Just outputs password directly

    run_test("--random-password 32 generates 32-char password",
         ['--random-password', '32'],
         expect_in_output=[])  # Just outputs password directly

    run_test("--get-ip gets public IP",
         ['--get-ip'],
         expect_in_output=[])  # May fail without internet

    run_test("--random-useragent generates user agent",
         ['--random-useragent'],
         expect_in_output=[])

    run_test("--lookup-http-code looks up HTTP codes",
         ['--lookup-http-code'],
         input_text='200\n',
         expect_in_output=['ok'])  # Returns "OK" for 200

    run_test("--base64-encode encodes text",
         ['--base64-encode'],
         input_text='hello\n',
         expect_in_output=['aGVsbG8='])  # base64 of 'hello'

    run_test("--base64-decode decodes text",
         ['--base64-decode'],
         input_text='aGVsbG8=\n',
         expect_in_output=['hello'])

    run_test("--regex-pattern generates pattern",
         ['--regex-pattern'],
         input_text='email\n',
         expect_in_output=['@', 'regex'])

    run_test("--timestamp-convert unix converts timestamp",
         ['--timestamp-convert', 'readable'],
         input_text='1704067200\n',
         expect_in_output=['2024'])

    # ============================================================
    # API KEY OPTIONS (test error handling)
    # ============================================================
    print(f"\n{BOLD}[API Key Options]{END}")

    run_test("--get-model-key openai shows key status",
         ['--get-model-key', 'openai'],
         expect_in_output=[])  # May show key or "no key"

    run_test("--get-key shows openai key status",
         ['--get-key'],
         expect_in_output=[])

    # ============================================================
    # ERROR HANDLING
    # ============================================================
    print(f"\n{BOLD}[Error Handling]{END}")

    run_test("Invalid option shows error",
         ['--invalid-option-xyz'],
         expect_error=True)

    run_test("--cmd without API key shows setup prompt",
         ['--cmd'],
         input_text='exit\n',
         expect_in_output=[])

    # ============================================================
    # JSON MODE
    # ============================================================
    print(f"\n{BOLD}[JSON Mode]{END}")

    # Set JSON mode via environment
    os.environ['CHATCMD_JSON'] = '1'

    run_test("--list-models in JSON mode",
         ['--list-models'],
         expect_in_output=['models', '{'])

    run_test("--current-model in JSON mode",
         ['--current-model'],
         expect_in_output=['current', '{'])

    run_test("--performance-stats in JSON mode",
         ['--performance-stats'],
         expect_in_output=['stats', '{'])

    # Clean up
    del os.environ['CHATCMD_JSON']

    # ============================================================
    # SUMMARY
    # ============================================================
    print(f"\n{BOLD}{CYAN}=" * 60)
    print("TEST SUMMARY")
    print("=" * 60 + f"{END}")

    total = passed + failed + skipped
    print(f"\n  Total:   {total}")
    print(f"  {GREEN}Passed:  {passed}{END}")
    print(f"  {RED}Failed:  {failed}{END}")
    print(f"  {YELLOW}Skipped: {skipped}{END}")

    if failed > 0:
        print(f"\n{BOLD}{RED}Failed Tests:{END}")
        for status, name, error in results:
            if status == 'FAIL':
                print(f"  - {name}")
                if error:
                    print(f"    {error}")

    print(f"\n{'=' * 60}\n")

    # Return exit code
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
