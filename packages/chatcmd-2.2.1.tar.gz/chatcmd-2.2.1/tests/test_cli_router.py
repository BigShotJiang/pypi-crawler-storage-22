"""
Tests for the CLI command router.
Tests the refactored route() method and category dispatchers.
"""

import pytest
import sys
import os
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestCommandRouterInit:
    """Test CommandRouter initialization."""

    def test_router_initializes(self):
        """Router should initialize with required components."""
        from chatcmd.cli import CommandRouter

        # Mock the dependencies
        mock_args = {'--help': False, '--version': False}
        mock_db = MagicMock()
        mock_lookup = MagicMock()
        mock_api = MagicMock()
        mock_config = MagicMock()

        router = CommandRouter(mock_args, mock_db, mock_lookup, mock_api, mock_config)

        assert router.args == mock_args
        assert router.db_manager == mock_db
        assert router.enhanced_lookup == mock_lookup
        assert router.enhanced_api == mock_api
        assert router.model_config == mock_config


class TestRouteDispatcher:
    """Test the main route() method and category dispatchers."""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.cli import CommandRouter

        self.mock_db = MagicMock()
        self.mock_lookup = MagicMock()
        self.mock_api = MagicMock()
        self.mock_config = MagicMock()

        # Default args - all False
        self.default_args = {
            '--help': False, '--version': False, '--library-info': False,
            '--list-models': False, '--model-info': False, '--current-model': False,
            '--performance-stats': False, '--set-model-key': False, '--get-model-key': False,
            '--model': False, '--cmd': False, '--sql': False, '--color-code': False,
            '--port-lookup': False, '--no-copy': False, '--base64-encode': False,
            '--base64-decode': False, '--generate-uuid': False, '--random-password': None,
            '--regex-pattern': False, '--random-useragent': False, '--timestamp-convert': False,
            '--get-ip': False, '--lookup-http-code': False, '--get-cmd': False,
            '--get-last': False, '--delete-cmd': False, '--delete-last-cmd': False,
            '--cmd-total': False, '--clear-history': False, '--db-size': False,
            '--set-key': False, '--get-key': False, '--reset-config': False,
        }

    def create_router(self, **kwargs):
        """Create router with specific args."""
        from chatcmd.cli import CommandRouter

        args = self.default_args.copy()
        args.update(kwargs)

        return CommandRouter(args, self.mock_db, self.mock_lookup, self.mock_api, self.mock_config)

    def test_route_returns_bool(self):
        """Route should return boolean."""
        router = self.create_router()
        with patch.object(router, '_handle_help', return_value=True):
            result = router.route()
            assert isinstance(result, bool)

    def test_help_takes_priority(self):
        """--help should be handled first."""
        router = self.create_router(**{'--help': True, '--version': True})
        with patch.object(router, '_handle_help', return_value=True) as mock_help:
            router.route()
            mock_help.assert_called_once()

    def test_route_model_management_list_models(self):
        """--list-models should route to model management."""
        router = self.create_router(**{'--list-models': True})
        result = router._route_model_management()
        assert result == True
        self.mock_lookup.list_available_models.assert_called_once()

    def test_route_model_management_current_model(self):
        """--current-model should route to model management."""
        router = self.create_router(**{'--current-model': True})
        self.mock_lookup.get_current_model_info.return_value = {
            'model_name': 'test', 'model_display_name': 'Test',
            'provider_name': 'test', 'provider_configured': True
        }
        result = router._route_model_management()
        assert result == True

    def test_route_tools_password(self):
        """--random-password should route to tools."""
        router = self.create_router(**{'--random-password': '16'})
        with patch('chatcmd.cli.generate_password') as mock_gen:
            result = router._route_tools()
            assert result == True
            mock_gen.assert_called_once_with(16)

    def test_route_tools_uuid(self):
        """--generate-uuid should route to tools."""
        router = self.create_router(**{'--generate-uuid': '4'})
        with patch('chatcmd.cli.generate_uuid') as mock_gen:
            result = router._route_tools()
            assert result == True
            mock_gen.assert_called_once_with(4)

    def test_route_history_cmd_total(self):
        """--cmd-total should route to history."""
        router = self.create_router(**{'--cmd-total': True})
        with patch('chatcmd.commands.CMD') as mock_cmd:
            mock_cmd.get_commands_count.return_value = 10
            result = router._route_history()
            assert result == True

    def test_route_configuration_reset(self):
        """--reset-config should route to configuration."""
        router = self.create_router(**{'--reset-config': True})
        with patch.dict(os.environ, {'CHATCMD_YES': '1'}):
            self.mock_api.reset_configuration.return_value = True
            result = router._route_configuration()
            assert result == True

    def test_route_info_version(self):
        """--version should route to info."""
        router = self.create_router(**{'--version': True})
        result = router._route_info()
        assert result == True

    def test_route_returns_false_when_no_match(self):
        """Category routers should return False when no match."""
        router = self.create_router()
        assert router._route_model_management() == False
        assert router._route_ai_commands() == False
        assert router._route_tools() == False
        assert router._route_history() == False
        assert router._route_configuration() == False
        assert router._route_info() == False


class TestHelperMethods:
    """Test helper methods in CommandRouter."""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.cli import CommandRouter

        self.mock_db = MagicMock()
        self.mock_lookup = MagicMock()
        self.mock_api = MagicMock()
        self.mock_config = MagicMock()

        self.args = {'--model': False}
        self.router = CommandRouter(
            self.args, self.mock_db, self.mock_lookup, self.mock_api, self.mock_config
        )

    def test_get_selected_model_none(self):
        """Should return None when no model specified."""
        result = self.router._get_selected_model()
        assert result is None

    def test_get_selected_model_with_model(self):
        """Should return normalized model name."""
        self.router.args['--model'] = 'gpt-4'
        self.mock_config.normalize_model_name.return_value = 'gpt-4'
        result = self.router._get_selected_model()
        assert result == 'gpt-4'

    def test_is_any_provider_configured_true(self):
        """Should return True when a provider is configured."""
        self.mock_api.get_provider_api_key.side_effect = lambda p: 'key' if p == 'openai' else None
        result = self.router._is_any_provider_configured()
        assert result == True

    def test_is_any_provider_configured_false(self):
        """Should return False when no provider is configured."""
        self.mock_api.get_provider_api_key.return_value = None
        result = self.router._is_any_provider_configured()
        assert result == False

    def test_mask_api_key_long(self):
        """Should mask long API keys properly."""
        from chatcmd.cli import CommandRouter
        key = "sk-1234567890abcdefghij"
        masked = CommandRouter._mask_api_key(key)
        assert masked == "sk-12345...ghij"
        assert "1234567890" not in masked

    def test_mask_api_key_short(self):
        """Should fully mask short API keys."""
        from chatcmd.cli import CommandRouter
        key = "short"
        masked = CommandRouter._mask_api_key(key)
        assert masked == "***masked***"


class TestPasswordHandling:
    """Test password generation with constants."""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.cli import CommandRouter

        self.mock_db = MagicMock()
        self.mock_lookup = MagicMock()
        self.mock_api = MagicMock()
        self.mock_config = MagicMock()

    def test_password_default_length(self):
        """Should use DEFAULT_PASSWORD_LENGTH when not specified."""
        from chatcmd.cli import CommandRouter
        from chatcmd.constants import DEFAULT_PASSWORD_LENGTH

        args = {'--random-password': ''}  # Empty string
        router = CommandRouter(args, self.mock_db, self.mock_lookup, self.mock_api, self.mock_config)

        with patch('chatcmd.cli.generate_password') as mock_gen:
            router._handle_random_password()
            mock_gen.assert_called_once_with(DEFAULT_PASSWORD_LENGTH)

    def test_password_custom_length(self):
        """Should use custom length when specified."""
        from chatcmd.cli import CommandRouter

        args = {'--random-password': '32'}
        router = CommandRouter(args, self.mock_db, self.mock_lookup, self.mock_api, self.mock_config)

        with patch('chatcmd.cli.generate_password') as mock_gen:
            router._handle_random_password()
            mock_gen.assert_called_once_with(32)

    def test_password_length_clamped_min(self):
        """Should clamp length to MIN_PASSWORD_LENGTH."""
        from chatcmd.cli import CommandRouter
        from chatcmd.constants import MIN_PASSWORD_LENGTH

        args = {'--random-password': '0'}
        router = CommandRouter(args, self.mock_db, self.mock_lookup, self.mock_api, self.mock_config)

        with patch('chatcmd.cli.generate_password') as mock_gen:
            router._handle_random_password()
            mock_gen.assert_called_once_with(MIN_PASSWORD_LENGTH)

    def test_password_length_clamped_max(self):
        """Should clamp length to MAX_PASSWORD_LENGTH."""
        from chatcmd.cli import CommandRouter
        from chatcmd.constants import MAX_PASSWORD_LENGTH

        args = {'--random-password': '9999'}
        router = CommandRouter(args, self.mock_db, self.mock_lookup, self.mock_api, self.mock_config)

        with patch('chatcmd.cli.generate_password') as mock_gen:
            router._handle_random_password()
            mock_gen.assert_called_once_with(MAX_PASSWORD_LENGTH)

    def test_password_invalid_length_uses_default(self):
        """Should use default length for invalid input."""
        from chatcmd.cli import CommandRouter
        from chatcmd.constants import DEFAULT_PASSWORD_LENGTH

        args = {'--random-password': 'invalid'}
        router = CommandRouter(args, self.mock_db, self.mock_lookup, self.mock_api, self.mock_config)

        with patch('chatcmd.cli.generate_password') as mock_gen:
            router._handle_random_password()
            mock_gen.assert_called_once_with(DEFAULT_PASSWORD_LENGTH)


if __name__ == "__main__":
    pytest.main([__file__, '-v'])
