"""
Tests for the commands module.
Tests command history operations with proper type hints.
"""

import pytest
import sys
import os
import tempfile
import sqlite3

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestCommandHistoryOperations:
    """Test command history CRUD operations."""

    def setup_method(self):
        """Create a temporary database for testing."""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()

        from chatcmd.database.schema_manager import SchemaManager
        self.schema_manager = SchemaManager(self.temp_db.name)

        from chatcmd.commands import CMD
        self.cmd = CMD()

    def teardown_method(self):
        """Clean up temporary database."""
        self.schema_manager.close()
        os.unlink(self.temp_db.name)

    def test_add_cmd_returns_true_on_success(self):
        """add_cmd should return True on successful insert."""
        result = self.cmd.add_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            "test prompt",
            "ls -la"
        )
        assert result == True

    def test_add_cmd_with_model_info(self):
        """add_cmd should store model and provider info."""
        result = self.cmd.add_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            "test prompt",
            "git status",
            model_name="gpt-4",
            provider_name="openai"
        )
        assert result == True

        # Verify stored correctly
        self.schema_manager.cursor.execute(
            "SELECT model_name, provider_name FROM history ORDER BY id DESC LIMIT 1"
        )
        row = self.schema_manager.cursor.fetchone()
        assert row[0] == "gpt-4"
        assert row[1] == "openai"

    def test_get_commands_count_empty(self):
        """get_commands_count should return 0 for empty history."""
        count = self.cmd.get_commands_count(self.schema_manager.cursor)
        assert count == 0

    def test_get_commands_count_after_inserts(self):
        """get_commands_count should return correct count."""
        for i in range(5):
            self.cmd.add_cmd(
                self.schema_manager.conn,
                self.schema_manager.cursor,
                f"prompt {i}",
                f"command {i}"
            )

        count = self.cmd.get_commands_count(self.schema_manager.cursor)
        assert count == 5

    def test_delete_cmd_returns_true_on_success(self):
        """delete_cmd should return True when command deleted."""
        # Add a command
        self.cmd.add_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            "test",
            "ls"
        )

        # Delete it
        result = self.cmd.delete_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor
        )
        assert result == True

        # Verify deleted
        count = self.cmd.get_commands_count(self.schema_manager.cursor)
        assert count == 0

    def test_delete_cmd_returns_false_when_empty(self):
        """delete_cmd should return False when history is empty."""
        result = self.cmd.delete_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor
        )
        assert result == False

    def test_delete_last_num_cmd_deletes_correct_count(self):
        """delete_last_num_cmd should delete specified number of commands."""
        # Add 5 commands
        for i in range(5):
            self.cmd.add_cmd(
                self.schema_manager.conn,
                self.schema_manager.cursor,
                f"prompt {i}",
                f"command {i}"
            )

        # Delete 3
        result = self.cmd.delete_last_num_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            "3"
        )
        assert result == True

        # Verify 2 remain
        count = self.cmd.get_commands_count(self.schema_manager.cursor)
        assert count == 2

    def test_delete_last_num_cmd_returns_false_when_empty(self):
        """delete_last_num_cmd should return False when history is empty."""
        result = self.cmd.delete_last_num_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            "5"
        )
        assert result == False

    def test_delete_last_num_cmd_invalid_number(self):
        """delete_last_num_cmd should return False for invalid number."""
        result = self.cmd.delete_last_num_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            "invalid"
        )
        assert result == False

    def test_clear_history_returns_true(self):
        """clear_history should return True on success."""
        # Add some commands
        for i in range(3):
            self.cmd.add_cmd(
                self.schema_manager.conn,
                self.schema_manager.cursor,
                f"prompt {i}",
                f"command {i}"
            )

        # Clear
        result = self.cmd.clear_history(
            self.schema_manager.conn,
            self.schema_manager.cursor
        )
        assert result == True

        # Verify empty
        count = self.cmd.get_commands_count(self.schema_manager.cursor)
        assert count == 0


class TestCommandHistoryParameterizedQueries:
    """Test that all queries use parameterized inputs."""

    def setup_method(self):
        """Create a temporary database for testing."""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()

        from chatcmd.database.schema_manager import SchemaManager
        self.schema_manager = SchemaManager(self.temp_db.name)

        from chatcmd.commands import CMD
        self.cmd = CMD()

    def teardown_method(self):
        """Clean up temporary database."""
        self.schema_manager.close()
        os.unlink(self.temp_db.name)

    def test_add_cmd_escapes_sql_injection(self):
        """add_cmd should safely handle SQL injection attempts."""
        malicious_prompt = "'; DROP TABLE history; --"
        malicious_command = "ls'; DELETE FROM history; --"

        result = self.cmd.add_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            malicious_prompt,
            malicious_command
        )
        assert result == True

        # Table should still exist and contain the "malicious" data
        count = self.cmd.get_commands_count(self.schema_manager.cursor)
        assert count == 1

        # Verify data stored literally
        self.schema_manager.cursor.execute("SELECT prompt, command FROM history LIMIT 1")
        row = self.schema_manager.cursor.fetchone()
        assert row[0] == malicious_prompt
        assert row[1] == malicious_command

    def test_delete_last_num_cmd_clamps_extreme_values(self):
        """delete_last_num_cmd should clamp extreme values."""
        # Add some commands
        for i in range(3):
            self.cmd.add_cmd(
                self.schema_manager.conn,
                self.schema_manager.cursor,
                f"prompt {i}",
                f"command {i}"
            )

        # Try to delete more than exists
        self.cmd.delete_last_num_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            "10000"
        )

        # Should delete all, not error
        count = self.cmd.get_commands_count(self.schema_manager.cursor)
        assert count == 0

    def test_get_last_num_cmd_handles_negative(self):
        """get_last_num_cmd should handle negative numbers."""
        result = self.cmd.get_last_num_cmd(
            self.schema_manager.cursor,
            "-5"
        )
        # Should return False for invalid input
        assert result == False


class TestDatabaseSizeDisplay:
    """Test database size display function."""

    def setup_method(self):
        """Create a temporary database for testing."""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()

        from chatcmd.database.schema_manager import SchemaManager
        self.schema_manager = SchemaManager(self.temp_db.name)

        from chatcmd.commands import CMD
        self.cmd = CMD()

    def teardown_method(self):
        """Clean up temporary database."""
        self.schema_manager.close()
        os.unlink(self.temp_db.name)

    def test_get_db_size_runs_without_error(self):
        """get_db_size should run without raising exceptions."""
        # This function prints output, just verify it doesn't crash
        try:
            self.cmd.get_db_size(self.temp_db.name)
        except Exception as e:
            pytest.fail(f"get_db_size raised exception: {e}")

    def test_get_db_size_handles_small_file(self):
        """get_db_size should handle small files in bytes."""
        # The temp DB should be small
        import os
        size = os.path.getsize(self.temp_db.name)
        assert size > 0  # DB has some size

        # Function should not crash
        self.cmd.get_db_size(self.temp_db.name)


class TestErrorCodes:
    """Test that error codes from constants are used."""

    def test_error_codes_imported(self):
        """Commands module should import ERROR_CODES."""
        from chatcmd.commands import CMD
        from chatcmd.constants import ERROR_CODES

        # Verify error codes exist
        assert 'NO_COMMANDS' in ERROR_CODES
        assert 'INVALID_NUMBER' in ERROR_CODES
        assert 'DELETE_FAILED' in ERROR_CODES
        assert 'DELETE_ERROR' in ERROR_CODES
        assert 'DELETE_RANGE_ERROR' in ERROR_CODES
        assert 'CLEAR_HISTORY_ERROR' in ERROR_CODES


class TestTypeHints:
    """Test that type hints are properly defined."""

    def test_add_cmd_type_hints(self):
        """add_cmd should have proper type hints."""
        from chatcmd.commands import CMD
        import inspect

        sig = inspect.signature(CMD.add_cmd)
        params = sig.parameters

        # Check parameter annotations exist
        assert 'conn' in params
        assert 'cursor' in params
        assert 'prompt' in params
        assert 'command' in params

        # Check return type
        assert sig.return_annotation == bool

    def test_get_commands_count_type_hints(self):
        """get_commands_count should have proper type hints."""
        from chatcmd.commands import CMD
        import inspect

        sig = inspect.signature(CMD.get_commands_count)
        assert sig.return_annotation == int

    def test_delete_cmd_type_hints(self):
        """delete_cmd should have proper type hints."""
        from chatcmd.commands import CMD
        import inspect

        sig = inspect.signature(CMD.delete_cmd)
        assert sig.return_annotation == bool

    def test_clear_history_type_hints(self):
        """clear_history should have proper type hints."""
        from chatcmd.commands import CMD
        import inspect

        sig = inspect.signature(CMD.clear_history)
        assert sig.return_annotation == bool


if __name__ == "__main__":
    pytest.main([__file__, '-v'])
