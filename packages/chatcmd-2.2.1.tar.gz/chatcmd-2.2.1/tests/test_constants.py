"""
Tests for the constants module.
Ensures all constants are properly defined and have expected values.
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from chatcmd.constants import (
    DEFAULT_PASSWORD_LENGTH, MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH,
    DEFAULT_MAX_TOKENS, DEFAULT_SQL_MAX_TOKENS, DEFAULT_TEMPERATURE,
    DEFAULT_MODEL, DEFAULT_PROVIDER,
    HTTP_REQUEST_TIMEOUT, OLLAMA_REQUEST_TIMEOUT,
    MIN_PROMPT_WORDS, DEFAULT_STATS_LOOKBACK_DAYS, MAX_STATS_LOOKBACK_DAYS,
    DB_VACUUM_THRESHOLD,
    API_KEY_MASK_PREFIX_LENGTH, API_KEY_MASK_SUFFIX_LENGTH, API_KEY_MIN_LENGTH_FOR_MASK,
    SUPPORTED_PROVIDERS, ERROR_CODES
)


class TestPasswordConstants:
    """Test password-related constants."""

    def test_default_password_length(self):
        """Default password length should be 18."""
        assert DEFAULT_PASSWORD_LENGTH == 18

    def test_min_password_length(self):
        """Minimum password length should be 1."""
        assert MIN_PASSWORD_LENGTH == 1

    def test_max_password_length(self):
        """Maximum password length should be 1000."""
        assert MAX_PASSWORD_LENGTH == 1000

    def test_password_length_range_valid(self):
        """Default should be within min/max range."""
        assert MIN_PASSWORD_LENGTH <= DEFAULT_PASSWORD_LENGTH <= MAX_PASSWORD_LENGTH


class TestAIModelConstants:
    """Test AI model-related constants."""

    def test_default_max_tokens(self):
        """Default max tokens should be 100."""
        assert DEFAULT_MAX_TOKENS == 100

    def test_default_sql_max_tokens(self):
        """SQL max tokens should be higher than command max tokens."""
        assert DEFAULT_SQL_MAX_TOKENS > DEFAULT_MAX_TOKENS
        assert DEFAULT_SQL_MAX_TOKENS == 200

    def test_default_temperature(self):
        """Default temperature should be 0.7."""
        assert DEFAULT_TEMPERATURE == 0.7
        assert 0 <= DEFAULT_TEMPERATURE <= 1

    def test_default_model(self):
        """Default model should be gpt-3.5-turbo."""
        assert DEFAULT_MODEL == 'gpt-3.5-turbo'

    def test_default_provider(self):
        """Default provider should be openai."""
        assert DEFAULT_PROVIDER == 'openai'


class TestTimeoutConstants:
    """Test timeout-related constants."""

    def test_http_request_timeout(self):
        """HTTP request timeout should be reasonable."""
        assert HTTP_REQUEST_TIMEOUT == 3
        assert HTTP_REQUEST_TIMEOUT > 0

    def test_ollama_request_timeout(self):
        """Ollama timeout should be longer for local processing."""
        assert OLLAMA_REQUEST_TIMEOUT == 30
        assert OLLAMA_REQUEST_TIMEOUT > HTTP_REQUEST_TIMEOUT


class TestValidationConstants:
    """Test validation-related constants."""

    def test_min_prompt_words(self):
        """Minimum prompt words should be 3."""
        assert MIN_PROMPT_WORDS == 3

    def test_stats_lookback_days(self):
        """Stats lookback days should be reasonable."""
        assert DEFAULT_STATS_LOOKBACK_DAYS == 7
        assert MAX_STATS_LOOKBACK_DAYS == 365
        assert DEFAULT_STATS_LOOKBACK_DAYS <= MAX_STATS_LOOKBACK_DAYS


class TestDatabaseConstants:
    """Test database-related constants."""

    def test_vacuum_threshold(self):
        """Vacuum threshold should be reasonable."""
        assert DB_VACUUM_THRESHOLD == 50
        assert DB_VACUUM_THRESHOLD > 0


class TestAPIKeyMaskConstants:
    """Test API key masking constants."""

    def test_mask_prefix_length(self):
        """Mask prefix length should show enough to identify key type."""
        assert API_KEY_MASK_PREFIX_LENGTH == 8

    def test_mask_suffix_length(self):
        """Mask suffix length should show enough for verification."""
        assert API_KEY_MASK_SUFFIX_LENGTH == 4

    def test_min_length_for_mask(self):
        """Minimum length for masking should be prefix + suffix."""
        assert API_KEY_MIN_LENGTH_FOR_MASK == 12
        assert API_KEY_MIN_LENGTH_FOR_MASK >= API_KEY_MASK_PREFIX_LENGTH + API_KEY_MASK_SUFFIX_LENGTH


class TestSupportedProviders:
    """Test supported providers list."""

    def test_supported_providers_is_list(self):
        """Should be a list."""
        assert isinstance(SUPPORTED_PROVIDERS, list)

    def test_supported_providers_not_empty(self):
        """Should not be empty."""
        assert len(SUPPORTED_PROVIDERS) > 0

    def test_supported_providers_contains_expected(self):
        """Should contain all expected providers."""
        expected = ['openai', 'anthropic', 'google', 'cohere', 'ollama']
        for provider in expected:
            assert provider in SUPPORTED_PROVIDERS

    def test_default_provider_in_supported(self):
        """Default provider should be in supported list."""
        assert DEFAULT_PROVIDER in SUPPORTED_PROVIDERS


class TestErrorCodes:
    """Test error codes dictionary."""

    def test_error_codes_is_dict(self):
        """Should be a dictionary."""
        assert isinstance(ERROR_CODES, dict)

    def test_error_codes_not_empty(self):
        """Should not be empty."""
        assert len(ERROR_CODES) > 0

    def test_error_codes_are_integers(self):
        """All error codes should be integers."""
        for key, code in ERROR_CODES.items():
            assert isinstance(code, int), f"Error code '{key}' should be int"

    def test_error_codes_unique(self):
        """All error codes should be unique."""
        codes = list(ERROR_CODES.values())
        assert len(codes) == len(set(codes)), "Error codes should be unique"

    def test_expected_error_codes_exist(self):
        """Expected error codes should exist."""
        expected_keys = [
            'NO_COMMANDS', 'INVALID_NUMBER', 'DELETE_FAILED',
            'DELETE_ERROR', 'DELETE_RANGE_ERROR', 'CLEAR_HISTORY_ERROR'
        ]
        for key in expected_keys:
            assert key in ERROR_CODES, f"Error code '{key}' should exist"


if __name__ == "__main__":
    pytest.main([__file__, '-v'])
