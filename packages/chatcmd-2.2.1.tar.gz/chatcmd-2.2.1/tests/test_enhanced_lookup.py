"""
Tests for the enhanced lookup module.
Tests the refactored helper methods and security validations.
"""

import pytest
import sys
import os
import tempfile
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestEnhancedLookupInit:
    """Test EnhancedLookup initialization."""

    def test_initialization(self):
        """Should initialize with required components."""
        from chatcmd.lookup.enhanced_lookup import EnhancedLookup

        mock_db = MagicMock()
        lookup = EnhancedLookup(mock_db)

        assert lookup.db_manager == mock_db
        assert lookup.provider_factory is not None
        assert lookup.model_config is not None


class TestInvalidResponseDetection:
    """Test the consolidated _is_invalid_response method."""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.lookup.enhanced_lookup import EnhancedLookup

        self.mock_db = MagicMock()
        self.lookup = EnhancedLookup(self.mock_db)

    def test_empty_response_invalid(self):
        """Empty responses should be invalid."""
        assert self.lookup._is_invalid_response("") == True
        assert self.lookup._is_invalid_response(None) == True

    def test_sorry_response_invalid(self):
        """Responses with 'sorry' should be invalid."""
        assert self.lookup._is_invalid_response("Sorry, I cannot help") == True
        assert self.lookup._is_invalid_response("I'm sorry but...") == True

    def test_cannot_find_invalid(self):
        """Responses with 'cannot find' should be invalid."""
        assert self.lookup._is_invalid_response("Cannot find a command for that") == True

    def test_unable_to_invalid(self):
        """Responses with 'unable to' should be invalid."""
        assert self.lookup._is_invalid_response("Unable to generate command") == True

    def test_no_command_invalid(self):
        """Responses indicating no command should be invalid."""
        assert self.lookup._is_invalid_response("There is no command for that") == True
        assert self.lookup._is_invalid_response("No specific command exists") == True

    def test_valid_command_response(self):
        """Valid command responses should not be invalid."""
        assert self.lookup._is_invalid_response("ls -la") == False
        assert self.lookup._is_invalid_response("git commit -m 'test'") == False
        assert self.lookup._is_invalid_response("docker ps") == False

    def test_valid_sql_response(self):
        """Valid SQL responses should not be invalid."""
        assert self.lookup._is_invalid_response("SELECT * FROM users") == False
        assert self.lookup._is_invalid_response("INSERT INTO table VALUES (1)") == False


class TestCommandSafetyValidation:
    """Test _validate_command_safety method."""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.lookup.enhanced_lookup import EnhancedLookup

        self.mock_db = MagicMock()
        self.lookup = EnhancedLookup(self.mock_db)

    def test_safe_commands_pass(self):
        """Safe commands should pass validation."""
        assert self.lookup._validate_command_safety("ls -la") == True
        assert self.lookup._validate_command_safety("git status") == True
        assert self.lookup._validate_command_safety("docker ps") == True

    def test_semicolon_blocked(self):
        """Commands with semicolons should be blocked."""
        assert self.lookup._validate_command_safety("ls; rm -rf /") == False

    def test_pipe_blocked(self):
        """Commands with pipes should be blocked."""
        assert self.lookup._validate_command_safety("cat file | grep test") == False

    def test_and_operator_blocked(self):
        """Commands with && should be blocked."""
        assert self.lookup._validate_command_safety("true && rm -rf /") == False

    def test_or_operator_blocked(self):
        """Commands with || should be blocked."""
        assert self.lookup._validate_command_safety("false || rm -rf /") == False

    def test_redirect_blocked(self):
        """Commands with redirects should be blocked."""
        assert self.lookup._validate_command_safety("echo test > /etc/passwd") == False
        assert self.lookup._validate_command_safety("cat file >> /tmp/log") == False

    def test_backtick_substitution_blocked(self):
        """Commands with backticks should be blocked."""
        assert self.lookup._validate_command_safety("echo `whoami`") == False

    def test_dollar_substitution_blocked(self):
        """Commands with $() should be blocked."""
        assert self.lookup._validate_command_safety("echo $(whoami)") == False

    def test_variable_expansion_blocked(self):
        """Commands with ${} should be blocked."""
        assert self.lookup._validate_command_safety("echo ${PATH}") == False

    def test_null_byte_blocked(self):
        """Commands with null bytes should be blocked."""
        assert self.lookup._validate_command_safety("test\x00injection") == False

    def test_carriage_return_blocked(self):
        """Commands with carriage returns should be blocked."""
        assert self.lookup._validate_command_safety("test\rinjection") == False

    def test_heredoc_blocked(self):
        """Commands with heredoc should be blocked."""
        assert self.lookup._validate_command_safety("cat << EOF") == False

    def test_multiline_blocked(self):
        """Multi-line commands should be blocked."""
        assert self.lookup._validate_command_safety("ls\nrm -rf /") == False

    def test_unicode_semicolon_blocked(self):
        """Unicode semicolon variants should be blocked."""
        assert self.lookup._validate_command_safety("ls\uff1brm") == False

    def test_unicode_ampersand_blocked(self):
        """Unicode ampersand variants should be blocked."""
        assert self.lookup._validate_command_safety("true\uff06rm") == False


class TestSQLSafetyValidation:
    """Test _validate_sql_safety method."""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.lookup.enhanced_lookup import EnhancedLookup

        self.mock_db = MagicMock()
        self.lookup = EnhancedLookup(self.mock_db)

    def test_select_allowed(self):
        """SELECT statements should be allowed."""
        assert self.lookup._validate_sql_safety("SELECT * FROM users") == True

    def test_select_with_join_allowed(self):
        """Complex SELECT statements should be allowed."""
        assert self.lookup._validate_sql_safety(
            "SELECT u.name FROM users u JOIN orders o ON u.id = o.user_id"
        ) == True

    def test_drop_blocked(self):
        """DROP statements should be blocked."""
        assert self.lookup._validate_sql_safety("DROP TABLE users") == False

    def test_truncate_blocked(self):
        """TRUNCATE statements should be blocked."""
        assert self.lookup._validate_sql_safety("TRUNCATE TABLE users") == False

    def test_alter_blocked(self):
        """ALTER statements should be blocked."""
        assert self.lookup._validate_sql_safety("ALTER TABLE users ADD COLUMN age INT") == False

    def test_delete_blocked(self):
        """DELETE without SELECT should be blocked."""
        assert self.lookup._validate_sql_safety("DELETE FROM users WHERE id = 1") == False

    def test_update_blocked(self):
        """UPDATE without SELECT should be blocked."""
        assert self.lookup._validate_sql_safety("UPDATE users SET name = 'test'") == False

    def test_select_with_delete_comment_allowed(self):
        """SELECT with 'delete' in string should be allowed."""
        # This tests that we check for actual SQL keywords, not just substrings
        result = self.lookup._validate_sql_safety(
            "SELECT * FROM logs WHERE action = 'delete'"
        )
        assert result == True


class TestProviderValidation:
    """Test _get_validated_provider method."""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.lookup.enhanced_lookup import EnhancedLookup

        self.mock_db = MagicMock()
        self.lookup = EnhancedLookup(self.mock_db)

    def test_returns_none_when_provider_not_configured(self):
        """Should return None when provider is not configured."""
        self.mock_db.get_current_model.return_value = {
            'current_model': 'gpt-4',
            'current_provider': 'openai'
        }
        self.mock_db.get_provider.return_value = None

        result = self.lookup._get_validated_provider()
        assert result is None

    def test_returns_none_when_no_api_key(self):
        """Should return None when API key is missing (non-Ollama)."""
        self.mock_db.get_current_model.return_value = {
            'current_model': 'gpt-4',
            'current_provider': 'openai'
        }
        self.mock_db.get_provider.return_value = {
            'id': 1,
            'api_key': None,
            'base_url': None
        }

        result = self.lookup._get_validated_provider()
        assert result is None

    def test_ollama_works_without_api_key(self):
        """Ollama should work without API key."""
        self.mock_db.get_current_model.return_value = {
            'current_model': 'llama2',
            'current_provider': 'ollama'
        }
        self.mock_db.get_provider.return_value = {
            'id': 1,
            'api_key': None,
            'base_url': 'http://localhost:11434'
        }

        # Mock the provider factory to return a provider
        with patch.object(self.lookup.provider_factory, 'create_provider') as mock_create:
            mock_provider = MagicMock()
            mock_create.return_value = mock_provider

            result = self.lookup._get_validated_provider()
            # Should return tuple (provider, model, provider_name, provider_info)
            assert result is not None
            assert result[0] == mock_provider


class TestUserPromptHandling:
    """Test _get_user_prompt method."""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.lookup.enhanced_lookup import EnhancedLookup

        self.mock_db = MagicMock()
        self.lookup = EnhancedLookup(self.mock_db)

    def test_exit_returns_none(self):
        """Should return None when user types 'exit'."""
        with patch('builtins.input', return_value='exit'):
            result = self.lookup._get_user_prompt()
            assert result is None

    def test_valid_prompt_returned(self):
        """Should return valid prompt."""
        with patch('builtins.input', return_value='list all files in directory'):
            result = self.lookup._get_user_prompt()
            assert result == 'list all files in directory'

    def test_short_prompt_rejected(self):
        """Should reject prompts with too few words."""
        with patch('builtins.input', return_value='ls'):
            result = self.lookup._get_user_prompt()
            assert result is None


class TestClipboardHandling:
    """Test _copy_to_clipboard method."""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.lookup.enhanced_lookup import EnhancedLookup

        self.mock_db = MagicMock()
        self.lookup = EnhancedLookup(self.mock_db)

    def test_no_copy_skips_clipboard(self):
        """Should not copy when no_copy is True."""
        with patch('pyperclip.copy') as mock_copy:
            self.lookup._copy_to_clipboard("test", no_copy=True)
            mock_copy.assert_not_called()

    def test_copy_called_when_enabled(self):
        """Should copy when no_copy is False."""
        with patch('platform.system', return_value='Darwin'):
            with patch('pyperclip.copy') as mock_copy:
                self.lookup._copy_to_clipboard("test command", no_copy=False)
                mock_copy.assert_called_once_with("test command")


class TestPerformanceStats:
    """Test get_performance_stats method."""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.lookup.enhanced_lookup import EnhancedLookup

        self.mock_db = MagicMock()
        self.lookup = EnhancedLookup(self.mock_db)

    def test_empty_stats(self):
        """Should return empty stats when no data."""
        self.mock_db.get_usage_stats.return_value = []

        result = self.lookup.get_performance_stats()

        assert result['total_requests'] == 0
        assert result['successful_requests'] == 0
        assert result['failed_requests'] == 0
        assert result['average_response_time'] == 0
        assert result['models_used'] == []

    def test_stats_calculation(self):
        """Should calculate stats correctly."""
        self.mock_db.get_usage_stats.return_value = [
            {'success': True, 'response_time': 1.0, 'provider_name': 'openai', 'model_name': 'gpt-4'},
            {'success': True, 'response_time': 2.0, 'provider_name': 'openai', 'model_name': 'gpt-4'},
            {'success': False, 'response_time': 0.5, 'provider_name': 'openai', 'model_name': 'gpt-4'},
        ]

        result = self.lookup.get_performance_stats()

        assert result['total_requests'] == 3
        assert result['successful_requests'] == 2
        assert result['failed_requests'] == 1
        assert result['average_response_time'] == round((1.0 + 2.0 + 0.5) / 3, 2)

    def test_uses_default_days_constant(self):
        """Should use DEFAULT_STATS_LOOKBACK_DAYS."""
        from chatcmd.constants import DEFAULT_STATS_LOOKBACK_DAYS

        self.mock_db.get_usage_stats.return_value = []
        self.lookup.get_performance_stats()

        self.mock_db.get_usage_stats.assert_called_once_with(DEFAULT_STATS_LOOKBACK_DAYS)


class TestModelAvailability:
    """Test _is_model_available method."""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.lookup.enhanced_lookup import EnhancedLookup

        self.mock_db = MagicMock()
        self.lookup = EnhancedLookup(self.mock_db)

    def test_unavailable_when_no_provider(self):
        """Should return False when provider not configured."""
        self.mock_db.get_provider.return_value = None
        assert self.lookup._is_model_available('gpt-4', 'openai') == False

    def test_unavailable_when_no_api_key(self):
        """Should return False when no API key (non-Ollama)."""
        self.mock_db.get_provider.return_value = {'api_key': None}
        assert self.lookup._is_model_available('gpt-4', 'openai') == False

    def test_available_with_api_key(self):
        """Should return True when API key present."""
        self.mock_db.get_provider.return_value = {'api_key': 'sk-test'}
        assert self.lookup._is_model_available('gpt-4', 'openai') == True

    def test_ollama_always_available(self):
        """Ollama should be available without API key."""
        self.mock_db.get_provider.return_value = {'api_key': None}
        assert self.lookup._is_model_available('llama2', 'ollama') == True


if __name__ == "__main__":
    pytest.main([__file__, '-v'])
