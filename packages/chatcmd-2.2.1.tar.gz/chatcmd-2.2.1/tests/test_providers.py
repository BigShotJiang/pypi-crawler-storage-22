"""
Tests for the provider base class.
Tests shared methods that were consolidated from individual providers.
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestBaseProviderCleanCommand:
    """Test clean_command_output method in base provider."""

    def setup_method(self):
        """Set up a provider instance for testing."""
        from chatcmd.providers.openai_provider import OpenAIProvider
        self.provider = OpenAIProvider(api_key="sk-test123", model_name="gpt-4")

    def test_clean_empty_response(self):
        """Should return empty string for empty response."""
        assert self.provider.clean_command_output("") == ""
        assert self.provider.clean_command_output(None) == ""

    def test_clean_strips_whitespace(self):
        """Should strip leading/trailing whitespace."""
        result = self.provider.clean_command_output("  ls -la  ")
        assert result == "ls -la"

    def test_clean_removes_bash_code_block(self):
        """Should remove ```bash code blocks."""
        result = self.provider.clean_command_output("```bash\nls -la\n```")
        assert "```" not in result
        assert "ls -la" in result

    def test_clean_removes_sh_code_block(self):
        """Should remove ```sh code blocks."""
        result = self.provider.clean_command_output("```sh\ngit status\n```")
        assert "```" not in result
        assert "git status" in result

    def test_clean_removes_generic_code_block(self):
        """Should remove ``` code blocks."""
        result = self.provider.clean_command_output("```\ndocker ps\n```")
        assert "```" not in result
        assert "docker ps" in result

    def test_clean_removes_command_prefix(self):
        """Should remove 'Command:' prefix."""
        assert self.provider.clean_command_output("Command: ls -la").strip() == "ls -la"

    def test_clean_removes_various_prefixes(self):
        """Should remove various common prefixes."""
        prefixes = [
            "Use: ", "Try: ", "Run: ", "Execute: ",
            "Here is the command: ", "Here's the command: ",
        ]

        for prefix in prefixes:
            result = self.provider.clean_command_output(f"{prefix}ls -la")
            assert result.strip() == "ls -la", f"Failed for prefix: {prefix}"

    def test_clean_stops_at_explanatory_text(self):
        """Should stop at explanatory text."""
        response = "ls -la\nThis command lists all files"
        result = self.provider.clean_command_output(response)
        assert "This command" not in result
        assert "ls -la" in result

    def test_clean_rejects_backticks(self):
        """Should reject commands with backticks."""
        result = self.provider.clean_command_output("echo `whoami`")
        assert result == ""

    def test_clean_rejects_command_substitution(self):
        """Should reject commands with $()."""
        result = self.provider.clean_command_output("echo $(id)")
        assert result == ""

    def test_clean_rejects_heredoc(self):
        """Should reject commands with <<."""
        result = self.provider.clean_command_output("cat << EOF")
        assert result == ""

    def test_clean_removes_trailing_punctuation(self):
        """Should remove trailing punctuation."""
        assert self.provider.clean_command_output("ls -la.").strip() == "ls -la"
        assert self.provider.clean_command_output("git status!").strip() == "git status"


class TestBaseProviderCleanSQL:
    """Test clean_sql_output method in base provider."""

    def setup_method(self):
        """Set up a provider instance for testing."""
        from chatcmd.providers.openai_provider import OpenAIProvider
        self.provider = OpenAIProvider(api_key="sk-test123", model_name="gpt-4")

    def test_clean_empty_sql(self):
        """Should return empty string for empty response."""
        assert self.provider.clean_sql_output("") == ""

    def test_clean_removes_sql_code_block(self):
        """Should remove ```sql code blocks."""
        result = self.provider.clean_sql_output("```sql\nSELECT * FROM users\n```")
        assert "```" not in result
        assert "SELECT" in result

    def test_clean_removes_sql_prefix(self):
        """Should remove SQL-related prefixes."""
        prefixes = [
            "SQL Query: ", "The query is: ", "Here is the query: ",
        ]

        for prefix in prefixes:
            result = self.provider.clean_sql_output(f"{prefix}SELECT * FROM users")
            assert "SELECT" in result
            assert prefix.strip().rstrip(':') not in result

    def test_clean_stops_at_explanation(self):
        """Should stop at explanatory text in SQL."""
        response = "SELECT * FROM users\nThis query retrieves all users"
        result = self.provider.clean_sql_output(response)
        assert "This query" not in result
        assert "SELECT" in result


class TestBaseProviderIsValidCommand:
    """Test is_valid_command method."""

    def setup_method(self):
        """Set up a provider instance for testing."""
        from chatcmd.providers.openai_provider import OpenAIProvider
        self.provider = OpenAIProvider(api_key="sk-test123", model_name="gpt-4")

    def test_valid_commands(self):
        """Common commands should be valid."""
        valid_commands = [
            "git status", "npm install", "pip install flask",
            "docker ps", "kubectl get pods", "aws s3 ls",
            "ls -la", "cd /tmp", "mkdir test",
            "grep pattern file", "find . -name '*.py'",
        ]

        for cmd in valid_commands:
            assert self.provider.is_valid_command(cmd) == True, f"Should be valid: {cmd}"

    def test_invalid_commands(self):
        """Non-command text should be invalid."""
        invalid_texts = [
            "Sorry, I cannot help with that",
            "There is no command for this",
            "I don't know the answer",
            "Unable to generate command",
            "",
            "a",
        ]

        for text in invalid_texts:
            assert self.provider.is_valid_command(text) == False, f"Should be invalid: {text}"

    def test_sudo_commands_valid(self):
        """Sudo commands should be valid."""
        assert self.provider.is_valid_command("sudo apt-get update") == True

    def test_env_var_commands_valid(self):
        """Environment variable commands should be valid."""
        assert self.provider.is_valid_command("NODE_ENV=production node app.js") == True


class TestBaseProviderIsValidSQL:
    """Test is_valid_sql_query method."""

    def setup_method(self):
        """Set up a provider instance for testing."""
        from chatcmd.providers.openai_provider import OpenAIProvider
        self.provider = OpenAIProvider(api_key="sk-test123", model_name="gpt-4")

    def test_valid_sql_queries(self):
        """Valid SQL queries should pass."""
        valid_queries = [
            "SELECT * FROM users",
            "INSERT INTO users (name) VALUES ('test')",
            "UPDATE users SET name = 'test' WHERE id = 1",
            "DELETE FROM users WHERE id = 1",
            "CREATE TABLE test (id INT)",
            "SELECT u.name FROM users u JOIN orders o ON u.id = o.user_id",
        ]

        for query in valid_queries:
            assert self.provider.is_valid_sql_query(query) == True, \
                f"Should be valid SQL: {query}"

    def test_invalid_sql(self):
        """Non-SQL text should fail."""
        invalid = [
            "Sorry, I cannot generate a query",
            "There is no query for that",
            "",
            "ab",
        ]

        for text in invalid:
            assert self.provider.is_valid_sql_query(text) == False, \
                f"Should be invalid SQL: {text}"


class TestExtractCommandFromResponse:
    """Test _extract_command_from_response (now in base class)."""

    def setup_method(self):
        """Set up a provider instance for testing."""
        from chatcmd.providers.openai_provider import OpenAIProvider
        self.provider = OpenAIProvider(api_key="sk-test123", model_name="gpt-4")

    def test_extract_with_dollar_prefix(self):
        """Should extract command with $ prefix."""
        result = self.provider._extract_command_from_response("$ git status")
        assert result == "git status"

    def test_extract_with_angle_prefix(self):
        """Should extract command with > prefix."""
        result = self.provider._extract_command_from_response("> ls -la")
        assert result == "ls -la"

    def test_extract_from_multiline(self):
        """Should extract command from first valid line."""
        response = "Here is the command:\ngit status\nThis will show..."
        result = self.provider._extract_command_from_response(response)
        assert result == "git status"

    def test_extract_returns_none_when_no_command(self):
        """Should return None when no command found."""
        result = self.provider._extract_command_from_response(
            "I'm sorry, I cannot help with that"
        )
        assert result is None


class TestExtractSQLFromResponse:
    """Test _extract_sql_from_response (now in base class)."""

    def setup_method(self):
        """Set up a provider instance for testing."""
        from chatcmd.providers.openai_provider import OpenAIProvider
        self.provider = OpenAIProvider(api_key="sk-test123", model_name="gpt-4")

    def test_extract_simple_select(self):
        """Should extract SELECT statement."""
        response = "Here's the query:\nSELECT * FROM users"
        result = self.provider._extract_sql_from_response(response)
        assert "SELECT" in result
        assert "users" in result

    def test_extract_multiline_query(self):
        """Should extract multi-line SQL query."""
        response = """Here's the query:
SELECT u.name, o.total
FROM users u
JOIN orders o ON u.id = o.user_id
WHERE o.total > 100
This query joins users with orders."""
        result = self.provider._extract_sql_from_response(response)
        assert "SELECT" in result
        assert "JOIN" in result
        assert "This query" not in result

    def test_extract_returns_none_when_no_sql(self):
        """Should return None when no SQL found."""
        result = self.provider._extract_sql_from_response(
            "I cannot write that query"
        )
        assert result is None

    def test_extract_skips_comments(self):
        """Should skip SQL comments."""
        response = """-- This is a comment
SELECT * FROM users
/* Another comment */"""
        result = self.provider._extract_sql_from_response(response)
        assert "SELECT" in result
        assert "--" not in result


class TestProviderInheritance:
    """Test that all providers properly inherit from base."""

    def test_all_providers_have_extract_command(self):
        """All providers should inherit _extract_command_from_response."""
        from chatcmd.providers.openai_provider import OpenAIProvider
        from chatcmd.providers.anthropic_provider import AnthropicProvider
        from chatcmd.providers.cohere_provider import CohereProvider
        from chatcmd.providers.ollama_provider import OllamaProvider

        # Each provider should have the method from base class
        for ProviderClass, name in [
            (OpenAIProvider, 'openai'),
            (AnthropicProvider, 'anthropic'),
        ]:
            provider = ProviderClass(api_key="test", model_name="test")
            assert hasattr(provider, '_extract_command_from_response')
            assert hasattr(provider, '_extract_sql_from_response')
            assert hasattr(provider, 'clean_command_output')
            assert hasattr(provider, 'clean_sql_output')
            assert hasattr(provider, 'is_valid_command')
            assert hasattr(provider, 'is_valid_sql_query')


if __name__ == "__main__":
    pytest.main([__file__, '-v'])
