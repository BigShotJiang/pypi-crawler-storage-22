"""
Security and functionality tests for ChatCMD
Tests all security fixes and core functionality
"""

import pytest
import os
import sys
import tempfile
import sqlite3
import json
from unittest.mock import MagicMock, patch

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestInputValidation:
    """Test input validation security fixes"""

    def setup_method(self):
        from chatcmd.helpers import Helpers
        self.helpers = Helpers()

    def test_valid_input_basic(self):
        """Test basic valid input"""
        assert self.helpers.validate_input("list all files in directory") == True
        assert self.helpers.validate_input("git commit -m 'message'") == True
        assert self.helpers.validate_input("find files with .py extension") == True

    def test_reject_backticks(self):
        """Test that backticks are rejected (command injection prevention)"""
        assert self.helpers.validate_input("echo `whoami`") == False
        assert self.helpers.validate_input("ls `pwd`") == False

    def test_reject_command_substitution(self):
        """Test that $() command substitution is rejected"""
        assert self.helpers.validate_input("echo $(whoami)") == False
        assert self.helpers.validate_input("cat $(ls)") == False

    def test_reject_variable_expansion(self):
        """Test that ${} variable expansion is rejected"""
        assert self.helpers.validate_input("echo ${PATH}") == False
        assert self.helpers.validate_input("cat ${HOME}/.bashrc") == False

    def test_reject_null_bytes(self):
        """Test that null bytes are rejected"""
        assert self.helpers.validate_input("test\x00injection") == False

    def test_reject_carriage_return(self):
        """Test that carriage returns are rejected"""
        assert self.helpers.validate_input("test\rinjection") == False

    def test_reject_empty_input(self):
        """Test that empty input is rejected"""
        assert self.helpers.validate_input("") == False
        assert self.helpers.validate_input("   ") == False

    def test_allow_safe_special_chars(self):
        """Test that safe special characters are allowed"""
        assert self.helpers.validate_input("file-name_test.txt") == True
        assert self.helpers.validate_input("path/to/file") == True
        assert self.helpers.validate_input("command --flag=value") == True


class TestSQLInjectionPrevention:
    """Test SQL injection prevention fixes"""

    def setup_method(self):
        """Create a temporary database for testing"""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()

        from chatcmd.database.schema_manager import SchemaManager
        self.schema_manager = SchemaManager(self.temp_db.name)

    def teardown_method(self):
        """Clean up temporary database"""
        self.schema_manager.close()
        os.unlink(self.temp_db.name)

    def test_get_usage_stats_parameterized(self):
        """Test that get_usage_stats uses parameterized queries"""
        # This should not raise an error even with malicious input
        # The days parameter is now validated and parameterized
        result = self.schema_manager.get_usage_stats(days=30)
        assert isinstance(result, list)

    def test_get_usage_stats_validates_days(self):
        """Test that days parameter is validated"""
        # Should handle extreme values without SQL injection
        result = self.schema_manager.get_usage_stats(days=99999)
        assert isinstance(result, list)

        result = self.schema_manager.get_usage_stats(days=-1)
        assert isinstance(result, list)

    def test_add_provider_no_plaintext_key(self):
        """Test that API keys are not stored in plaintext"""
        provider_id = self.schema_manager.add_provider("test_provider", "sk-test123456789")
        assert provider_id is not None

        # Verify the key is stored as marker, not plaintext
        provider = self.schema_manager.get_provider("test_provider")
        assert provider is not None
        assert provider['api_key'] == "[SECURE]"
        assert "sk-test" not in str(provider['api_key'])


class TestSecureStorage:
    """Test secure storage functionality"""

    def test_secure_storage_availability(self):
        """Test that secure storage is available"""
        from chatcmd.helpers.secure_storage import SecureStorage
        storage = SecureStorage()
        # Should be available via keyring or encrypted file
        assert storage.is_available() in [True, False]  # Depends on system

    def test_file_permission_verification(self):
        """Test file permission verification method"""
        from chatcmd.helpers.secure_storage import SecureStorage
        storage = SecureStorage()

        # Create a temp file with secure permissions
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(b"test")
            temp_path = f.name

        try:
            os.chmod(temp_path, 0o600)
            # Should pass on Unix systems
            if os.name != 'nt':
                assert storage._verify_file_permissions(temp_path) == True
        finally:
            os.unlink(temp_path)


class TestDatabaseIntegrity:
    """Test database integrity check"""

    def setup_method(self):
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()

        from chatcmd.database.schema_manager import SchemaManager
        self.schema_manager = SchemaManager(self.temp_db.name)

    def teardown_method(self):
        self.schema_manager.close()
        os.unlink(self.temp_db.name)

    def test_integrity_check_passes(self):
        """Test that integrity check passes on valid database"""
        result = self.schema_manager._check_database_integrity()
        assert result == True


class TestCommandHistory:
    """Test command history functions"""

    def setup_method(self):
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()

        from chatcmd.database.schema_manager import SchemaManager
        self.schema_manager = SchemaManager(self.temp_db.name)

        from chatcmd.commands import CMD
        self.cmd = CMD()

    def teardown_method(self):
        self.schema_manager.close()
        os.unlink(self.temp_db.name)

    def test_add_command_to_history(self):
        """Test adding command to history"""
        result = self.cmd.add_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            "test prompt",
            "ls -la",
            model_name="gpt-4",
            provider_name="openai"
        )
        assert result == True

    def test_get_commands_count(self):
        """Test getting command count"""
        # Add some commands
        for i in range(5):
            self.cmd.add_cmd(
                self.schema_manager.conn,
                self.schema_manager.cursor,
                f"prompt {i}",
                f"command {i}"
            )

        count = self.cmd.get_commands_count(self.schema_manager.cursor)
        assert count == 5

    def test_delete_last_num_cmd_parameterized(self):
        """Test that delete uses parameterized query"""
        # Add commands
        for i in range(5):
            self.cmd.add_cmd(
                self.schema_manager.conn,
                self.schema_manager.cursor,
                f"prompt {i}",
                f"command {i}"
            )

        # Delete should work without SQL injection
        self.cmd.delete_last_num_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            "3"
        )

        count = self.cmd.get_commands_count(self.schema_manager.cursor)
        assert count == 2


class TestDangerousCommandDetection:
    """Test dangerous command detection in enhanced_lookup"""

    def setup_method(self):
        """Set up test fixtures."""
        from chatcmd.lookup.enhanced_lookup import EnhancedLookup
        self.lookup = EnhancedLookup(MagicMock())

    def test_dangerous_tokens_list(self):
        """Test that dangerous tokens are properly defined"""
        dangerous_tokens = [
            ';', '&&', '||', '|', '>', '>>', '2>', '2>>',
            '`', '$(', '${',
            '\x00', '\r',
            '<<',
            '\uff1b', '\uff06',  # Unicode variants
        ]

        for token in dangerous_tokens:
            # Each token should be detectable
            test_cmd = f"ls {token} rm -rf /"
            assert token in test_cmd

    def test_all_dangerous_tokens_blocked(self):
        """Each dangerous token should fail command validation."""
        dangerous_commands = [
            "ls; rm -rf /",
            "true && rm -rf /",
            "false || rm -rf /",
            "cat file | grep pass",
            "echo test > /etc/passwd",
            "echo test >> /tmp/log",
            "echo `whoami`",
            "echo $(id)",
            "echo ${HOME}",
            "test\x00inject",
            "test\rinjection",
            "cat << EOF",
            "echo test 2> /dev/null",
            "echo test 2>> /tmp/err",
            "ls\uff1brm",       # Unicode semicolon
            "true\uff06\uff06rm",  # Unicode ampersand
        ]

        for cmd in dangerous_commands:
            assert self.lookup._validate_command_safety(cmd) == False, \
                f"Should block: {repr(cmd)}"

    def test_safe_commands_allowed(self):
        """Safe commands should pass validation."""
        safe_commands = [
            "ls -la",
            "git status",
            "docker ps",
            "kubectl get pods",
            "aws s3 ls",
            "npm install express",
            "pip install flask",
        ]

        for cmd in safe_commands:
            assert self.lookup._validate_command_safety(cmd) == True, \
                f"Should allow: {repr(cmd)}"


class TestErrorMessageSanitization:
    """Test that error messages don't leak sensitive info"""

    def test_openai_error_sanitization(self):
        """Test OpenAI error message sanitization"""
        from chatcmd.providers.openai_provider import OpenAIProvider

        # Create provider with dummy key
        provider = OpenAIProvider(api_key="sk-test123", model_name="gpt-4")

        # Test sanitization method
        test_message = "Error with key sk-abc123xyz456 at /home/user/secret/path"
        sanitized = provider._sanitize_error_message(test_message)

        assert "sk-abc123xyz456" not in sanitized
        assert "[REDACTED_KEY]" in sanitized
        assert "/home/user" not in sanitized


class TestAPIKeyValidation:
    """Test API key validation"""

    def test_deprecated_validate_api_key(self):
        """Test that old validate_api_key shows deprecation warning"""
        from chatcmd.helpers import Helpers
        import warnings

        helpers = Helpers()

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            helpers.validate_api_key("sk-test123456789012345678901234567890")

            # Should have deprecation warning
            assert len(w) >= 1
            assert any(issubclass(warning.category, DeprecationWarning) for warning in w)


class TestDeveloperTools:
    """Test developer tools functionality"""

    def test_uuid_v1_uses_random_node(self):
        """Test that UUID v1 uses random node for privacy"""
        from chatcmd.features.developer_tools import DeveloperTools
        import uuid

        tools = DeveloperTools()

        # Generate multiple UUIDs
        uuids = []
        for _ in range(3):
            # We can't call generate_uuid directly as it prints to console
            # Instead, test the logic
            import random
            random_node = random.getrandbits(48) | 0x010000000000
            uuid_value = uuid.uuid1(node=random_node)
            uuids.append(uuid_value)

        # All should have multicast bit set (privacy protection)
        for u in uuids:
            node = u.node
            assert node & 0x010000000000  # Multicast bit should be set

class TestGoogleProviderImport:
    """Test Google provider import handling"""

    def test_google_provider_graceful_import(self):
        """Test that Google provider handles missing packages gracefully"""
        # This tests that the import structure is correct
        # The actual import may fail if no Google package is installed,
        # but it should be a controlled failure
        try:
            from chatcmd.providers.google_provider import USING_NEW_API, GoogleProvider
            # If we get here, one of the packages is installed
            assert USING_NEW_API in [True, False]
        except ImportError as e:
            # Expected if no Google package is installed
            assert "google" in str(e).lower()


class TestConfigNotPlaintext:
    """Test that config files don't store plaintext keys"""

    def test_config_stores_marker_not_key(self):
        """Test that config.json stores marker instead of key"""
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = os.path.join(temp_dir, 'config.json')

            # Simulate what enhanced_api does
            config = {
                'providers': {
                    'openai': {
                        'api_key_configured': True
                        # Note: no 'api_key' field with actual key
                    }
                }
            }

            with open(config_path, 'w') as f:
                json.dump(config, f)

            # Verify no plaintext key in file
            with open(config_path, 'r') as f:
                content = f.read()
                assert 'sk-' not in content


class TestProviderBaseClassSecurity:
    """Test security features in the base provider class."""

    def setup_method(self):
        """Set up test provider."""
        from chatcmd.providers.openai_provider import OpenAIProvider
        self.provider = OpenAIProvider(api_key="sk-test123", model_name="gpt-4")

    def test_clean_command_removes_markdown(self):
        """clean_command_output should remove markdown code blocks."""
        response = "```bash\nls -la\n```"
        cleaned = self.provider.clean_command_output(response)
        assert "```" not in cleaned
        assert "ls -la" in cleaned

    def test_clean_command_removes_prefixes(self):
        """clean_command_output should remove common prefixes."""
        prefixes_to_test = [
            "Command: ls -la",
            "The command is: ls -la",
            "Use: ls -la",
            "Try: ls -la",
            "Run: ls -la",
        ]

        for response in prefixes_to_test:
            cleaned = self.provider.clean_command_output(response)
            assert cleaned.strip() == "ls -la", f"Failed for: {response}"

    def test_clean_command_rejects_dangerous_tokens(self):
        """clean_command_output should reject dangerous tokens."""
        dangerous_responses = [
            "echo `whoami`",
            "echo $(id)",
            "cat << EOF",
        ]

        for response in dangerous_responses:
            cleaned = self.provider.clean_command_output(response)
            assert cleaned == "", f"Should reject: {response}"

    def test_clean_sql_removes_markdown(self):
        """clean_sql_output should remove markdown code blocks."""
        response = "```sql\nSELECT * FROM users\n```"
        cleaned = self.provider.clean_sql_output(response)
        assert "```" not in cleaned
        assert "SELECT" in cleaned


class TestAPIKeyMaskingSecurity:
    """Test API key masking prevents exposure."""

    def test_mask_hides_middle(self):
        """Masking should hide the middle of the key."""
        from chatcmd.cli import CommandRouter

        key = "sk-1234567890abcdefghijklmnop"
        masked = CommandRouter._mask_api_key(key)

        assert "1234567890" not in masked
        assert "abcdef" not in masked
        assert "sk-12345" in masked  # Prefix visible
        assert "mnop" in masked      # Suffix visible

    def test_mask_short_keys_completely(self):
        """Short keys should be completely masked."""
        from chatcmd.cli import CommandRouter

        short_key = "sk-short"
        masked = CommandRouter._mask_api_key(short_key)

        assert masked == "***masked***"
        assert "sk-short" not in masked


class TestSQLInjectionInCommands:
    """Test SQL injection prevention in commands module."""

    def setup_method(self):
        """Create temp database."""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.temp_db.close()

        from chatcmd.database.schema_manager import SchemaManager
        self.schema_manager = SchemaManager(self.temp_db.name)

        from chatcmd.commands import CMD
        self.cmd = CMD()

    def teardown_method(self):
        """Clean up."""
        self.schema_manager.close()
        os.unlink(self.temp_db.name)

    def test_sql_injection_in_prompt(self):
        """SQL injection in prompt field should be escaped."""
        injection = "test'; DROP TABLE history; --"

        self.cmd.add_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            injection,
            "ls"
        )

        # Table should still exist
        count = self.cmd.get_commands_count(self.schema_manager.cursor)
        assert count == 1

    def test_sql_injection_in_command(self):
        """SQL injection in command field should be escaped."""
        injection = "ls'; DELETE FROM history WHERE '1'='1"

        self.cmd.add_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            "test",
            injection
        )

        # Command should be stored literally
        self.schema_manager.cursor.execute("SELECT command FROM history LIMIT 1")
        stored = self.schema_manager.cursor.fetchone()[0]
        assert stored == injection

    def test_sql_injection_in_delete_number(self):
        """SQL injection in delete number should be prevented."""
        # Add commands
        for i in range(3):
            self.cmd.add_cmd(
                self.schema_manager.conn,
                self.schema_manager.cursor,
                f"prompt {i}",
                f"cmd {i}"
            )

        # Try SQL injection in number parameter
        injection = "1; DROP TABLE history; --"
        self.cmd.delete_last_num_cmd(
            self.schema_manager.conn,
            self.schema_manager.cursor,
            injection
        )

        # Table should still exist (injection should be treated as invalid)
        count = self.cmd.get_commands_count(self.schema_manager.cursor)
        # Should be 3 (nothing deleted) or 2 (1 deleted) but table exists
        assert count >= 0


class TestInputValidationEdgeCases:
    """Test edge cases in input validation."""

    def setup_method(self):
        """Set up helpers."""
        from chatcmd.helpers import Helpers
        self.helpers = Helpers()

    def test_unicode_null_rejected(self):
        """Unicode null characters should be rejected."""
        # Different null representations
        inputs = [
            "test\u0000inject",  # Unicode null
            "test\x00inject",   # Hex null
        ]

        for inp in inputs:
            assert self.helpers.validate_input(inp) == False

    def test_newline_injection(self):
        """Newline characters in prompts should be handled."""
        # Newlines might be used to inject commands
        inputs = [
            "list files\nrm -rf /",
            "test\n\nmalicious",
        ]

        for inp in inputs:
            # Newlines should be rejected or sanitized
            result = self.helpers.validate_input(inp)
            # The validator may allow or reject - test current behavior
            assert isinstance(result, bool)

    def test_very_long_input(self):
        """Very long inputs should be handled safely."""
        long_input = "a" * 100000

        # Should not crash
        try:
            result = self.helpers.validate_input(long_input)
            assert isinstance(result, bool)
        except Exception as e:
            pytest.fail(f"Should handle long input: {e}")

    def test_special_shell_chars(self):
        """Shell injection characters should be rejected by validate_input."""
        # validate_input blocks backticks, $(), ${}, ;;, null bytes, \r
        # Single ;, |, & are allowed since validate_input handles natural language prompts
        # (command-level safety is handled separately in _validate_command_safety)
        rejected_chars = [
            "test`id`",
            "test$(whoami)",
            "test${PATH}",
        ]

        for inp in rejected_chars:
            assert self.helpers.validate_input(inp) == False, f"Should reject: {inp}"

        # Single shell operators are allowed in prompts (natural language)
        allowed_chars = [
            "test;ls",
            "test|cat",
            "test&bg",
        ]

        for inp in allowed_chars:
            assert self.helpers.validate_input(inp) == True, f"Should allow in prompt: {inp}"


class TestProviderValidation:
    """Test provider-level security."""

    def test_openai_key_format_validation(self):
        """OpenAI key format should be validated."""
        from chatcmd.providers.openai_provider import OpenAIProvider

        # Valid format
        valid_provider = OpenAIProvider(
            api_key="sk-1234567890abcdefghijklmnopqrstuvwxyz",
            model_name="gpt-4"
        )
        assert valid_provider.validate_api_key() == True

        # Invalid format - too short
        short_provider = OpenAIProvider(api_key="sk-short", model_name="gpt-4")
        assert short_provider.validate_api_key() == False

        # Invalid format - wrong prefix
        wrong_prefix = OpenAIProvider(api_key="api-1234567890abcdef", model_name="gpt-4")
        assert wrong_prefix.validate_api_key() == False


def run_all_tests():
    """Run all tests and print summary"""
    print("=" * 60)
    print("ChatCMD Security & Functionality Tests")
    print("=" * 60)

    # Run with pytest
    exit_code = pytest.main([
        __file__,
        '-v',
        '--tb=short',
        '-x',  # Stop on first failure
    ])

    return exit_code


if __name__ == "__main__":
    exit(run_all_tests())
