"""
Tests for the tools module.
Tests encoding, generators, network, and lookup tools.
"""

import pytest
import sys
import os
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestBase64Encoding:
    """Test base64 encoding/decoding."""

    def test_encode_basic_text(self):
        """Should encode text to base64."""
        from chatcmd.tools.encoding import base64_encode

        with patch('pyperclip.copy'):
            result = base64_encode("hello")
            assert result == "aGVsbG8="

    def test_encode_empty_string(self):
        """Should encode empty string."""
        from chatcmd.tools.encoding import base64_encode

        with patch('pyperclip.copy'):
            result = base64_encode("")
            assert result == ""

    def test_encode_unicode(self):
        """Should encode unicode text."""
        from chatcmd.tools.encoding import base64_encode

        with patch('pyperclip.copy'):
            result = base64_encode("hello world!")
            assert result == "aGVsbG8gd29ybGQh"

    def test_decode_basic_text(self):
        """Should decode base64 to text."""
        from chatcmd.tools.encoding import base64_decode

        with patch('pyperclip.copy'):
            result = base64_decode("aGVsbG8=")
            assert result == "hello"

    def test_decode_invalid_input(self):
        """Should handle invalid base64 input gracefully."""
        from chatcmd.tools.encoding import base64_decode

        with patch('pyperclip.copy'):
            result = base64_decode("not-valid-base64!!!")
            assert result == ""  # Should return empty on error

    def test_roundtrip(self):
        """Encoding then decoding should return original text."""
        from chatcmd.tools.encoding import base64_encode, base64_decode

        original = "Test roundtrip encoding 123!"
        with patch('pyperclip.copy'):
            encoded = base64_encode(original)
            decoded = base64_decode(encoded)
            assert decoded == original


class TestUUIDGeneration:
    """Test UUID generation."""

    def test_uuid_v4_format(self):
        """UUID v4 should match standard format."""
        from chatcmd.tools.generators import generate_uuid
        import re

        with patch('pyperclip.copy'):
            result = generate_uuid(4)
            uuid_pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
            assert re.match(uuid_pattern, result), f"Invalid UUID v4 format: {result}"

    def test_uuid_v1_has_random_node(self):
        """UUID v1 should use random node for privacy."""
        from chatcmd.tools.generators import generate_uuid
        import uuid

        with patch('pyperclip.copy'):
            result = generate_uuid(1)
            parsed = uuid.UUID(result)
            # Multicast bit should be set (privacy protection)
            assert parsed.node & 0x010000000000

    def test_uuid_versions(self):
        """Should generate valid UUIDs for supported versions."""
        from chatcmd.tools.generators import generate_uuid

        for version in [1, 3, 4, 5]:
            with patch('pyperclip.copy'):
                result = generate_uuid(version)
                assert len(result) == 36  # UUID string length
                assert result.count('-') == 4

    def test_uuid_invalid_version(self):
        """Invalid version should fall back to v4."""
        from chatcmd.tools.generators import generate_uuid

        with patch('pyperclip.copy'):
            result = generate_uuid(99)
            assert len(result) == 36  # Should still generate valid UUID


class TestPasswordGeneration:
    """Test password generation."""

    def test_default_length(self):
        """Default password should be 18 characters."""
        from chatcmd.tools.generators import generate_password

        with patch('pyperclip.copy'):
            result = generate_password()
            assert len(result) == 18

    def test_custom_length(self):
        """Should generate password of specified length."""
        from chatcmd.tools.generators import generate_password

        for length in [8, 16, 32, 64]:
            with patch('pyperclip.copy'):
                result = generate_password(length)
                assert len(result) == length

    def test_min_length(self):
        """Should handle minimum length."""
        from chatcmd.tools.generators import generate_password

        with patch('pyperclip.copy'):
            result = generate_password(1)
            assert len(result) == 1

    def test_password_randomness(self):
        """Passwords should be unique."""
        from chatcmd.tools.generators import generate_password

        with patch('pyperclip.copy'):
            passwords = [generate_password(32) for _ in range(10)]
            assert len(set(passwords)) == 10  # All unique


class TestRegexPatternGeneration:
    """Test regex pattern generation."""

    def test_email_pattern(self):
        """Should generate email regex pattern."""
        from chatcmd.tools.generators import generate_regex_pattern
        import re

        with patch('pyperclip.copy'):
            pattern = generate_regex_pattern("email")
            # Should be a valid regex
            try:
                compiled = re.compile(pattern)
                assert compiled.match("test@example.com")
            except re.error:
                pytest.fail(f"Invalid regex: {pattern}")

    def test_url_pattern(self):
        """Should generate URL regex pattern."""
        from chatcmd.tools.generators import generate_regex_pattern

        with patch('pyperclip.copy'):
            pattern = generate_regex_pattern("url")
            assert len(pattern) > 0

    def test_phone_pattern(self):
        """Should generate phone regex pattern."""
        from chatcmd.tools.generators import generate_regex_pattern

        with patch('pyperclip.copy'):
            pattern = generate_regex_pattern("phone")
            assert len(pattern) > 0

    def test_unknown_returns_generic(self):
        """Unknown descriptions should return generic pattern."""
        from chatcmd.tools.generators import generate_regex_pattern

        with patch('pyperclip.copy'):
            pattern = generate_regex_pattern("some random text xyz")
            assert pattern == '.*'  # Generic catch-all


class TestTimestampConversion:
    """Test timestamp conversion."""

    def test_unix_to_readable(self):
        """Should convert Unix timestamp to readable format."""
        from chatcmd.tools.generators import convert_timestamp

        with patch('pyperclip.copy'):
            result = convert_timestamp("1704067200", "readable")
            assert "2024" in result

    def test_unix_to_iso(self):
        """Should convert Unix timestamp to ISO format."""
        from chatcmd.tools.generators import convert_timestamp

        with patch('pyperclip.copy'):
            result = convert_timestamp("1704067200", "iso")
            assert "2024" in result
            assert "T" in result  # ISO format separator

    def test_invalid_timestamp(self):
        """Should handle invalid timestamps gracefully."""
        from chatcmd.tools.generators import convert_timestamp

        with patch('pyperclip.copy'):
            result = convert_timestamp("not-a-timestamp", "unix")
            assert result == ""  # Should return empty on error


class TestHTTPCodeLookup:
    """Test HTTP code lookup."""

    def test_http_codes_defined(self):
        """HTTP codes dictionary should be populated."""
        from chatcmd.tools.lookup import HTTP_CODES

        assert len(HTTP_CODES) > 0
        assert '200' in HTTP_CODES
        assert '404' in HTTP_CODES
        assert '500' in HTTP_CODES

    def test_common_codes_exist(self):
        """Common HTTP codes should be defined."""
        from chatcmd.tools.lookup import HTTP_CODES

        common_codes = ['200', '201', '301', '302', '400', '401', '403', '404', '500', '502', '503']
        for code in common_codes:
            assert code in HTTP_CODES, f"Missing HTTP code: {code}"


class TestToolImports:
    """Test that all tools are properly exported."""

    def test_import_from_tools_package(self):
        """Should be able to import all tools from package."""
        from chatcmd.tools import (
            base64_encode, base64_decode,
            generate_uuid, generate_password, generate_regex_pattern,
            generate_user_agent, convert_timestamp,
            get_public_ip, lookup_http_code
        )

        # All should be callable
        assert callable(base64_encode)
        assert callable(base64_decode)
        assert callable(generate_uuid)
        assert callable(generate_password)
        assert callable(generate_regex_pattern)
        assert callable(generate_user_agent)
        assert callable(convert_timestamp)
        assert callable(get_public_ip)
        assert callable(lookup_http_code)


if __name__ == "__main__":
    pytest.main([__file__, '-v'])
