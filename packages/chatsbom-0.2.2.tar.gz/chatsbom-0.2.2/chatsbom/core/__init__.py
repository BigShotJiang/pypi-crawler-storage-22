# Core utilities
