import structlog
import typer
from rich.console import Console
from rich.progress import BarColumn
from rich.progress import MofNCompleteColumn
from rich.progress import Progress
from rich.progress import SpinnerColumn
from rich.progress import TaskProgressColumn
from rich.progress import TextColumn
from rich.progress import TimeElapsedColumn
from rich.progress import TimeRemainingColumn

from chatsbom.core.container import get_container
from chatsbom.core.decorators import handle_errors
from chatsbom.core.storage import load_jsonl
from chatsbom.core.storage import Storage
from chatsbom.models.language import Language
from chatsbom.services.release_service import ReleaseStats

logger = structlog.get_logger('release_command')
app = typer.Typer()


@app.callback(invoke_without_command=True)
@handle_errors
def main(
    token: str = typer.Option(
        None, envvar='GITHUB_TOKEN', help='GitHub Token',
    ),
    language: Language | None = typer.Option(None, help='Target Language'),
    force: bool = typer.Option(
        False, help='Force refresh even if valid data exists',
    ),
    limit: int | None = typer.Option(None, help='Limit number of items'),
):
    """
    Enrich repository with release information.
    Reads from: data/02-github-repo
    Writes to: data/03-github-release
    """
    container = get_container()
    config = container.config
    service = container.get_release_service(token)

    target_languages = [language] if language else list(Language)

    for lang in target_languages:
        lang_str = str(lang)
        input_path = config.paths.get_repo_list_path(lang_str)
        output_path = config.paths.get_release_list_path(lang_str)

        if not input_path.exists():
            logger.warning(
                f"No repo data found for {lang_str}", path=str(input_path),
            )
            continue

        repos = load_jsonl(input_path)
        if not repos:
            logger.warning('Empty repo list', language=lang_str)
            continue

        storage = Storage(output_path)
        stats = ReleaseStats(total=len(repos))

        with Progress(
            SpinnerColumn(),
            TextColumn('[progress.description]{task.description}'),
            BarColumn(),
            TaskProgressColumn(),
            MofNCompleteColumn(),
            TextColumn('•'),
            TimeElapsedColumn(),
            TextColumn('•'),
            TimeRemainingColumn(),
            console=Console(),  # Use a local Console instance for Progress
        ) as progress:
            task = progress.add_task(
                f"Fetching Releases {lang_str}...", total=len(repos),
            )

            count = 0
            for repo in repos:
                if limit and count >= limit:
                    break

                # Check if already processed in output
                if not force and repo.id in storage.visited_ids:
                    progress.advance(task)
                    stats.skipped += 1
                    continue

                enriched_data = service.process_repo(repo, stats, lang_str)
                if enriched_data:
                    storage.save(enriched_data)

                progress.advance(task)
                count += 1

        logger.info(
            'Release Enrichment Complete',
            language=lang_str,
            enriched=stats.enriched,
            skipped=stats.skipped,
            failed=stats.failed,
            api_requests=stats.api_requests,
        )
