# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Comprehensive code comments and docstrings throughout the codebase
- Detailed README.md with usage instructions, features, and examples
- CHANGELOG.md to track project changes
- PyPI packaging support with `setup.py` and `pyproject.toml`
- `MANIFEST.in` for including non-Python files in distribution
- `.gitignore` for build artifacts and development files
- `PYPI_UPLOAD.md` guide for publishing to PyPI
- Version number (`__version__ = "1.0.0"`) in main module
- Console script entry point: `check-duplicate-functions` command

### Changed
- Enhanced docstrings for all classes and functions with detailed parameter descriptions
- Improved inline comments explaining complex logic
- Updated module-level docstring with comprehensive usage information
- Enhanced error messages and documentation
- Updated README.md with PyPI installation instructions
- Added multiple installation options (PyPI, git clone, direct download)

### Documentation
- Added comprehensive README.md covering:
  - Features and capabilities
  - Installation and usage instructions (including PyPI)
  - Output format and exit codes
  - How the tool works internally
  - Special method handling
  - Limitations and error handling
  - Example use cases
- Added PyPI upload guide with step-by-step instructions

## [1.0.0] - Initial Release

### Added
- Initial implementation of duplicate function detection
- AST-based function analysis using Python's `ast` module
- Support for regular and async function detection
- Class context tracking for methods
- Special method exclusion (dunder methods)
- Function signature extraction with type annotation support
- Error handling for file operations and syntax errors
- Command-line interface

### Features
- Detects duplicate function names in Python files
- Handles async functions
- Tracks class context for methods
- Excludes special methods from duplicate checks
- Extracts and compares function signatures
- Comprehensive error handling
