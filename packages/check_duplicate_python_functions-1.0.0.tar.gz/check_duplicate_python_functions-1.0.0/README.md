# check-duplicate-python-functions

A Python tool to detect duplicate function names in Python source files using AST (Abstract Syntax Tree) parsing.

**Repository**: [https://github.com/pandiyarajk/check-duplicate-python-functions](https://github.com/pandiyarajk/check-duplicate-python-functions)

**Author**: Pandiyaraj Karuppasamy (pandiyarajk@live.com)

## Features

- **Detects duplicate function names**: Identifies functions with the same name defined multiple times in a file
- **AST-based analysis**: Uses Python's built-in AST module for accurate parsing
- **Handles async functions**: Properly identifies and distinguishes async functions
- **Class context awareness**: Tracks function context (module-level vs class methods)
- **Special method exclusion**: Excludes special methods (like `__init__`, `__str__`, etc.) from duplicate checks since they can legitimately appear in multiple classes
- **Signature extraction**: Extracts and compares function signatures including type annotations
- **Comprehensive error handling**: Handles file not found, permission errors, encoding issues, and syntax errors gracefully

## Requirements

- Python 3.6 or higher
- No external dependencies (uses only Python standard library)

## Installation

### Option 1: Install from PyPI (Recommended)
```bash
pip install check-duplicate-python-functions
```

After installation, you can use the command-line tool:
```bash
check-duplicate-functions <python_file_path>
```

### Option 2: Clone the repository
```bash
git clone https://github.com/pandiyarajk/check-duplicate-python-functions.git
cd check-duplicate-python-functions
python check_duplicate_functions.py <python_file_path>
```

### Option 3: Download directly
No installation required. Simply download the `check_duplicate_functions.py` file and run it:
```bash
python check_duplicate_functions.py <python_file_path>
```

## Usage

### If installed from PyPI:
```bash
check-duplicate-functions <python_file_path>
```

### If using the script directly:
```bash
python check_duplicate_functions.py <python_file_path>
```

### Examples

```bash
# Check a single Python file (PyPI installation)
check-duplicate-functions my_script.py

# Check a file in a subdirectory (PyPI installation)
check-duplicate-functions src/utils.py

# Using the script directly
python check_duplicate_functions.py my_script.py
python check_duplicate_functions.py src/utils.py
```

## Output

The script produces output only when duplicates are found or errors occur:

- **No duplicates**: Script exits silently with exit code 0
- **Duplicates found**: Prints each duplicate function name and the line numbers where it appears:
  ```
  [DUPLICATE] 'my_function' appears on lines: 10, 25, 42
  ```
- **Errors**: Prints error messages for file not found, syntax errors, etc.:
  ```
  [ERROR] File not found: nonexistent.py
  [ERROR] Syntax error in file.py: invalid syntax (line 5)
  ```

## Exit Codes

- `0`: Success (no duplicates found or analysis completed successfully)
- `1`: Error (invalid arguments, file not found, syntax error, or other issues)

## How It Works

1. **File Reading**: Reads the Python source file with UTF-8 encoding
2. **AST Parsing**: Parses the source code into an Abstract Syntax Tree
3. **Function Extraction**: Traverses the AST to extract all function definitions:
   - Regular functions (`def`)
   - Async functions (`async def`)
   - Methods within classes
   - Function signatures with type annotations
4. **Duplicate Detection**: Identifies functions with duplicate names (excluding special methods)
5. **Result Reporting**: Prints duplicate function names and their line numbers

## Special Methods

Special methods (dunder methods) like `__init__`, `__str__`, `__repr__`, etc. are excluded from duplicate checking because:
- They are expected to appear in multiple classes
- They serve specific purposes in Python's object model
- Having them in multiple classes is not considered a code quality issue

## Limitations

- Only analyzes a single file at a time (no recursive directory scanning)
- Does not detect duplicates across different files
- Special methods are excluded from duplicate detection
- Functions with identical names but different signatures are still reported as duplicates

## Error Handling

The script handles various error conditions:

- **File not found**: Returns appropriate error message
- **Permission denied**: Reports permission errors
- **Encoding errors**: Handles files with non-UTF-8 encoding issues
- **Syntax errors**: Reports Python syntax errors with line information
- **Unexpected errors**: Catches and reports any unexpected exceptions

## Example Use Cases

- **Code review**: Quickly identify potential duplicate function definitions before code review
- **Refactoring**: Find duplicate functions that might need to be consolidated
- **Code quality**: Maintain clean codebase by detecting accidental function name reuse
- **Large codebases**: Analyze individual files in large projects for duplicate functions

## License

This project is provided as-is for use in detecting duplicate functions in Python code.

## Contributing

Contributions are welcome! Please feel free to submit issues or pull requests on [GitHub](https://github.com/pandiyarajk/check-duplicate-python-functions).

## Author

**Pandiyaraj Karuppasamy**
- Email: pandiyarajk@live.com
- GitHub: [@pandiyarajk](https://github.com/pandiyarajk)
