"""Setup configuration for check-duplicate-python-functions package."""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

# Read version from the main module
version = {}
version_file = Path(__file__).parent / "check_duplicate_functions.py"
if version_file.exists():
    with open(version_file, "r", encoding="utf-8") as f:
        for line in f:
            if line.startswith("__version__"):
                exec(line, version)
                break

setup(
    name="check-duplicate-python-functions",
    version=version.get("__version__", "1.0.0"),
    author="Pandiyaraj Karuppasamy",
    author_email="pandiyarajk@live.com",
    description="A Python tool to detect duplicate function names in Python source files using AST parsing",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pandiyarajk/check-duplicate-python-functions",
    py_modules=["check_duplicate_functions"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Quality Assurance",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "check-duplicate-functions=check_duplicate_functions:main",
        ],
    },
    keywords="python, ast, duplicate, functions, code-quality, static-analysis, linter",
    project_urls={
        "Bug Reports": "https://github.com/pandiyarajk/check-duplicate-python-functions/issues",
        "Source": "https://github.com/pandiyarajk/check-duplicate-python-functions",
        "Documentation": "https://github.com/pandiyarajk/check-duplicate-python-functions#readme",
    },
)
