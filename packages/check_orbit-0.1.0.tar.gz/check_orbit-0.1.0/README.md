# check_orbit (pybind11 C++ extension)

This folder contains the C++/CMake-based pybind11 extension `check_orbit` used by the project.

Quick install (build and install into the active Python environment)

Prerequisites
- Python development headers and a C/C++ toolchain:
  - macOS: Xcode command line tools (clang)
  - Windows: MSVC Build Tools (matching the Python ABI)
- CMake

Install build dependencies and build:

```bash
python -m pip install --upgrade pip setuptools wheel scikit-build pybind11 cmake
cd core/cpp
python -m pip install .
```

This uses `scikit-build` to call CMake (the existing `CMakeLists.txt` in this folder).

Create a wheel (artifact) for distribution:

```bash
cd core/cpp
python -m pip wheel . -w ../dist
```

Notes
- Wheels are platform / Python-ABI specific. A wheel built on Windows will not work on macOS (and vice versa).
- If `pip` cannot find a compatible wheel on the target machine, it will attempt to build from source. The target machine must have the required build tools installed.
- For CI-built wheels, consider using `cibuildwheel` to produce many-platform wheels and publish to PyPI or GitHub Releases.
