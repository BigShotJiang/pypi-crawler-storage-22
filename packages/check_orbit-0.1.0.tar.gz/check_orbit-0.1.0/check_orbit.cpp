#include <sqlite3.h>
#include <vector>
#include <string>
#include <sstream>
#include <stdexcept>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

bool check_orbit_in_bounds(py::bytes geom_blob, double min_lat, double max_lat, double start_lon, double end_lon) {

    std::string geom_str = geom_blob;
    //release GIL
    py::gil_scoped_release_simple;

    std::istringstream stream(geom_str); 
    std::string line;

    while (std::getline(stream, line)) {    
        std::istringstream linestream(line); 
        std::string cell;
        int col = 0;
        double lat = 0.0;
        double lon = 0.0;

        while(std::getline(linestream, cell, ',')){
            if(col == 2) lat = std::stod(cell);
            if(col == 3) lon = std::stod(cell);
            col++;
        }

            if (lat >= min_lat && lat <= max_lat) {
                if (start_lon == end_lon) {
                    return true;
                }
                if (start_lon <= end_lon) {
                    if (lon >= start_lon && lon <= end_lon) {
                        return true;
                    }
                } else {
                    if (lon >= start_lon || lon <= end_lon) {
                        return true;
                    }
                }
            }
        }

    return false;  
}

std::pair<std::vector<double>, std::vector<double>> load_geom_from_db(int orbit_number, const std::string& db_path) {
    sqlite3* db;
    if (sqlite3_open(db_path.c_str(), &db) != SQLITE_OK) {
        throw std::runtime_error("Cannot open database: " + db_path);
    }

    sqlite3_stmt* stmt;
    const char* sql = "SELECT geom_tab FROM picker_dataset WHERE orbit_number=?;";
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        sqlite3_close(db);
        throw std::runtime_error("Failed to prepare statement");
    }

    sqlite3_bind_int(stmt, 1, orbit_number);

    std::vector<double> latitudes;
    std::vector<double> longitudes;

    if (sqlite3_step(stmt) == SQLITE_ROW) {
        const void* blob_data = sqlite3_column_blob(stmt, 0);
        int blob_size = sqlite3_column_bytes(stmt, 0);
        if (!blob_data || blob_size == 0) {
            sqlite3_finalize(stmt);
            sqlite3_close(db);
            throw std::runtime_error("geom_tab BLOB is empty");
        }

        std::string geom_str(reinterpret_cast<const char*>(blob_data), blob_size);
        std::istringstream stream(geom_str);
        std::string line;

        while (std::getline(stream, line)) {
            std::istringstream linestream(line);
            std::string cell;
            int col = 0;
            double lat = 0.0, lon = 0.0;
            while (std::getline(linestream, cell, ',')) {
                if (col == 2) lat = std::stod(cell);
                if (col == 3) lon = std::stod(cell);
                col++;
            }
            latitudes.push_back(lat);
            longitudes.push_back(lon);
        }
    } else {
        sqlite3_finalize(stmt);
        sqlite3_close(db);
        throw std::runtime_error("Orbit not found in database");
    }

    sqlite3_finalize(stmt);
    sqlite3_close(db);

    return {latitudes, longitudes};
}


PYBIND11_MODULE(check_orbit, m){
    m.def("check_orbit_in_bounds", &check_orbit_in_bounds);
    m.def("load_geom_from_db", &load_geom_from_db);
}
