from skbuild import setup

setup(
    name="check_orbit",
    version="0.1.0",
    description="Pybind11 `check_orbit` extension built with CMake",
    packages=[],
)
