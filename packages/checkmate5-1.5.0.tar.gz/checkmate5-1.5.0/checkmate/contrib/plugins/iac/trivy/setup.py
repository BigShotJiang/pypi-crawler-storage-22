from .analyzer import TrivyAnalyzer
from .issues_data import issues_data

analyzers = {
    'trivy':
        {
            'name': 'trivy',
            'title': 'Trivy',
            'class': TrivyAnalyzer,
            'language': 'iac',
            'issues_data': issues_data,
        },
}
