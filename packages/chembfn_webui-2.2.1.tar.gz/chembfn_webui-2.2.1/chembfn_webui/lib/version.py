# -*- coding: utf-8 -*-
# Author: Nianze A. TAO (omozawa SUENO)
"""
Version info.
"""

__version__ = "2.2.1"
__author__ = "Nianze A. TAO"
