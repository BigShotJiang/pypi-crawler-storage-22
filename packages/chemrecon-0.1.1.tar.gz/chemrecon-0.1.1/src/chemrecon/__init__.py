""" Defines metadata and the most general exports in the chemrecon.* namespace.
"""
# Metadata
__version__ = '0.1.1'  # Library version
__db_version__: list[str] = ['0.1.1']  # Compatible database versions


# Imports
import psycopg


# Connection and handler
import chemrecon.connection
from chemrecon.connection import (
    connect, connect_public, connect_local_docker, connect_local_docker_dev, disconnect,
    get_query_handler
)
from chemrecon.database.params import Params


# Project initialization
# Try to set the default database connection
try:
    disconnect()
    # connect_public()
except psycopg.OperationalError as e:
    print(f'Cannot connect to default database: {e}')

# Import from schema
from chemrecon.schema import *

from chemrecon.core.query_handler import QueryHandler
from chemrecon.core.populate_query_handler import PopulateQueryHandler

# Export identifier types
from chemrecon.core.id_types import *

# Entry creators
# from chemrecon.query.create_entry import (
#     entry,
#     compound_entry, reaction_entry, enzyme_entry,
#     aam_representation_entry, structure_representation_entry,
#     structure_entry, aam_entry,
#     enzyme_from_ec_number,
#     entry_from_identifiers_org
# )

from chemrecon.query.find_entry import (
    find_entry,
    find_compound_entry, find_reaction_entry, find_enzyme_entry,
    find_structure_representation_entry, find_aam_representation_entry,
    find_structure_entry, find_aam_entry
)

# Relation getters
from chemrecon.query.get_relations import *

# EntryGraphs
from chemrecon.entrygraph.entrygraph import EntryGraph, Vertex, Edge
from chemrecon.schema.direction import Direction
from chemrecon.entrygraph.filter import (
    EntryFilter, EntryFilterProcedure,
    RelationFilter, RelationFilterProcedure
)
from chemrecon.entrygraph.explorationprotocol import ExplorationProtocol
from chemrecon.entrygraph.explore import explore
from chemrecon.entrygraph.scoring import Scorer

# Pre-defined entrygraph types
from chemrecon.query.default_protocols import *

# Chemistry - Molecules
from chemrecon.chem.mol import Mol
