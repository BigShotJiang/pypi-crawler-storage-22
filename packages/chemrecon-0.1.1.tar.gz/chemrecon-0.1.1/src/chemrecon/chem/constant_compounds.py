""" Pre-defined molecules which skip lookup (water, co2, ...)
"""
# TODO