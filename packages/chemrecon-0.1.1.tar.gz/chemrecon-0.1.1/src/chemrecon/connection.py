""" Handles the global connection state of ChemRecon.
"""
from __future__ import annotations

import os.path

import chemrecon.core.query_handler
import chemrecon.core.populate_query_handler
from chemrecon.database.connect import postgres_connect
from chemrecon.database.params import Params, local_docker_pub, local_docker_dev, chemrecon_pub, chemrecon_dev

# Handler, default to public production database
# ----------------------------------------------------------------------------------------------------------------------
handler: chemrecon.core.query_handler.QueryHandler  # QueryHandler or PopulateQueryHandler

def get_query_handler() -> chemrecon.core.query_handler.QueryHandler:
    """ Returns the current database query handler."""
    return handler

def connect(params: Params, can_write: bool):
    """ Sets the database handler for the ChemRecon library to a custom database connection.
        Also defines whether the library is allowed to write/cache results in the database.
    """
    global handler

    conn = postgres_connect(params)
    if can_write:
        handler = chemrecon.core.populate_query_handler.PopulateQueryHandler(conn)
    else:
        handler = chemrecon.core.query_handler.QueryHandler(conn)

    # Done
    print(f'Handler set: {params.connection_string()}')

def disconnect():
    global handler
    handler = None

def connect_public():
    """ Sets the ChemRecon library to use a database connection to the public
        ChemRecon database maintained by the developer.
    """
    connect(chemrecon_pub, can_write = False)

def connect_public_dev():
    """ For developer use.
    """
    connect(chemrecon_dev, can_write = True)

def connect_local_docker():
    """ Sets the ChemRecon library to use a database in a local Docker container. Refer to the documentation for
        details on how to run and administrate this database.
    """
    connect(local_docker_pub, can_write = False)

def connect_local_docker_dev():
    """ Sets the ChemRecon library to use a database in a local Docker container. Refer to the documentation for
        details on how to run and administrate this database.
    """
    connect(local_docker_dev, can_write = True)


# Local cache files location
# ----------------------------------------------------------------------------------------------------------------------
cache_dir: str = 'cache/'

def init_cache():
    """ If cache dir doesn't exis
    """
    if not os.path.exists(cache_dir):
        os.makedirs(cache_dir)

def flush_cache():
    """ Remove all cached results
    """
    raise NotImplementedError()

def set_cache_dir(new_cache_dir: str):
    global cache_dir
    cache_dir = new_cache_dir


# Initialise the cache
init_cache()

# External tools / dependencies
# ----------------------------------------------------------------------------------------------------------------------
# Reaction Decoder Tool, RDT
# rdt_jar_location: str = './chemrecon/redistribute/rdt/'
# rdt_jar_filename: str = 'rdt-2.4.1-jar-with-dependencies.jar'
# rdt_jar_path: str = './chemrecon/redistribute/rdt/rdt-2.4.1-jar-with-dependencies.jar'
# TODO by default in chemrecon/dependencies/rdt/...

# def set_rdt_jar_path(path: str):
#     # TODO
#     raise NotImplementedError()
#     pass
