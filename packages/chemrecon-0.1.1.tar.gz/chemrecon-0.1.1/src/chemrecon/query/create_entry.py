# """ Contains methods to create entries to look up in the databases.
# """
#
#
# from chemrecon.core.id_types import (
#     IdentifierType, IdentifierTypeCompound, IdentifierTypeReaction, IdentifierTypeStructureRepresentation,
#     IdentifierTypeEnzyme, E_EC, IdentifierTypeAAM
# )
# from chemrecon.schema import (
#     Entry, Compound, Enzyme, Reaction, MolStructureRepr, MolStructure,
#     AAMRepr, AAM
# )
#
#
# # Direct creation of prototype entries
# # ----------------------------------------------------------------------------------------------------------------------
# def entry(id_type: IdentifierType, source_id: str) -> Entry:
#     """ Create a 'prototype' entry, which may or may not correspond to an actual entry in the database.
#     """
#     match id_type:
#         case IdentifierTypeCompound():
#             return compound_entry(id_type, source_id)
#         case IdentifierTypeReaction():
#             return reaction_entry(id_type, source_id)
#         case IdentifierTypeEnzyme():
#             return enzyme_entry(id_type, source_id)
#         case IdentifierTypeStructureRepresentation():
#             return structure_representation_entry(id_type, source_id)
#         case IdentifierTypeAAM():
#             return aam_representation_entry(id_type, source_id)
#         case _:
#             # Not implemented
#             raise NotImplementedError()
#
# def compound_entry(id_type: IdentifierTypeCompound, source_id: str) -> Compound:
#     """ TODO docs
#     """
#     return Compound(id_type = id_type, source_id = id_type.std_identifier(source_id))
#
# def reaction_entry(id_type: IdentifierTypeReaction, source_id: str) -> Reaction:
#     """ TODO docs
#     """
#     return Reaction(id_type = id_type, source_id = id_type.std_identifier(source_id))
#
# def enzyme_entry(id_type: IdentifierTypeEnzyme, source_id: str) -> Enzyme:
#     """ TODO docs
#     """
#     return Enzyme(id_type = id_type, source_id = id_type.std_identifier(source_id))
#
# def structure_representation_entry(id_type: IdentifierTypeStructureRepresentation, source_id: str) -> MolStructureRepr:
#     """ TODO docs
#     """
#     return MolStructureRepr(id_type = id_type, source_id = id_type.std_identifier(source_id))
#
# def aam_representation_entry(id_type: IdentifierTypeAAM, source_id: str) -> AAMRepr:
#     """ TODO docs
#     """
#     return AAMRepr(id_type = id_type, source_id = id_type.std_identifier(source_id))
#
# def structure_entry(smiles: str) -> MolStructure:
#     """ TODO docs
#     """
#     return MolStructure(smiles = smiles)
#
# def aam_entry(reaction_smiles: str) -> AAM:
#     """ TODO docs
#     """
#     return AAM(reaction_smiles = reaction_smiles)
#
#
# # Special for ec
# def enzyme_from_ec_number(ec_number: str) -> Enzyme:
#     """ Create a prototype enzyme entry from an EC number.
#     """
#     return Enzyme(id_type = E_EC, source_id = E_EC.std_identifier(ec_number))
#
#
# # Creation from identifiers.org strings
# # ----------------------------------------------------------------------------------------------------------------------
# def entry_from_identifiers_org(identifiers_org_string: str) -> Entry:
#     """ Create an entry from an identifiers.org string. If the string is not valid for any types in the database, raise
#         ValueError.
#     """
#     # TODO
#     # TODO raise ValueError if invalid string
#     raise NotImplementedError()
