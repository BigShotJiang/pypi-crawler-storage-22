""" Re-exports all concrete schema objects
"""
from __future__ import annotations

from chemrecon.schema.db_object import (Entry, SourceEntry, Relation, DatabaseObject, Column,
                                        ProceduralRelation, ProceduralGeneratorError, ComposedRelation)

from chemrecon.schema.enums import *

# Re-export entry types
from chemrecon.schema.entry_types.aam import AAM
from chemrecon.schema.entry_types.aam_repr import AAMRepr
from chemrecon.schema.entry_types.compound import Compound
from chemrecon.schema.entry_types.enzyme import Enzyme
from chemrecon.schema.entry_types.reaction import Reaction
from chemrecon.schema.entry_types.molstructure_repr import MolStructureRepr
from chemrecon.schema.entry_types.molstructure import MolStructure

# Re-export relation types (with corresponding inverses, defined in the same file as the main)
from chemrecon.schema.relation_types_source.aam_involves_molstructure_relation import *
from chemrecon.schema.relation_types_source.aam_repr_involves_molstructure_repr_relation import *
from chemrecon.schema.relation_types_procedural.aam_convert_relation import *
from chemrecon.schema.relation_types_composed.compound_has_molstructure_relation import *
from chemrecon.schema.relation_types_source.compound_has_structure_representation_relation import *
from chemrecon.schema.relation_types_source.compound_reference_relation import *
from chemrecon.schema.relation_types_composed.reaction_has_aam_relation import *
from chemrecon.schema.relation_types_source.reaction_has_aam_representation_relation import *
from chemrecon.schema.relation_types_source.reaction_has_enzyme_relation import *
from chemrecon.schema.relation_types_source.reaction_involves_compound_relation import *
from chemrecon.schema.relation_types_source.reaction_reference_relation import *
from chemrecon.schema.relation_types_procedural.molstructure_convert_relation import *
from chemrecon.schema.relation_types_source.molstructure_standardisation_relation import *

# Ontology
from chemrecon.schema.relation_types_source.ontology.compound_ontology import *
from chemrecon.schema.relation_types_source.ontology.reaction_ontology import *
from chemrecon.schema.relation_types_source.ontology.enzyme_ontology import *

# Procedural relation types, import only the relation, not the protocol
from chemrecon.schema.relation_types_procedural.compound_select_structure_proceduralrelation import (
    CompoundSelectStructure
)
from chemrecon.schema.relation_types_procedural.reaction_select_aam_proceduralrelation import (
    ReactionSelectAAM
)

# Export lists
entrytypes: list[type[Entry]] = [
    Compound, MolStructureRepr, MolStructure, Reaction, Enzyme,
    AAMRepr, AAM
]
relationtypes: list[type[Relation]] = [
    # Main source relations
    CompoundReference,
    CompoundHasStructureRepresentation, CompoundHasMolStructure,
    MolStructureConvert, MolStructureStandardization,
    ReactionReference,
    ReactionInvolvesCompound, CompoundParticipatesInReaction,
    ReactionHasEnzyme,
    ReactionHasAAMRepr,
    ReactionHasAAM,
    AAMReprInvolvesMolStructureRepr,
    AAMConvert,
    AAMInvolvesMolStructure,

    # Ontology, Compound
    CompoundIsA, CompoundHasInstance,
    CompoundHasNewID, CompoundHasOldID,
    CompoundHasPart, CompoundIsPartOf,
    CompoundHasConjugateAcid, CompoundHasConjugateBase,
    CompoundHasTautomer,
    CompoundHasStereoIsomer,
    CompoundHasIsotopologue,

    # Ontology, Reaction
    ReactionIsA, ReactionHasInstance,
    ReactionHasNewID, ReactionHasOldID,

    # Ontology, Enzyme
    EnzymeIsA, EnzymeHasInstance,
    EnzymeHasNewID, EnzymeHasOldID,

    # EntryGraph Procedural
    CompoundSelectStructure,
    ReactionSelectAAM,
]
