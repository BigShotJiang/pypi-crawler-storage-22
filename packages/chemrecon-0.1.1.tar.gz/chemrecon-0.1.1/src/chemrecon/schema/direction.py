from __future__ import annotations

from enum import Enum


class Direction(Enum):
    FORWARDS = 1  #: From source to target.
    BACKWARDS = 2  #: From target to source.
    BOTH = 3  #: Both of the above.
    SYMMETRIC = 4  #: To be used for symmetric relations.
