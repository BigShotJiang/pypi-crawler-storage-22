from typing import Optional

from chemrecon.schema import Entry
from chemrecon.schema.db_object import Column, col_recon_id

class AAM(Entry):
    """ Represents an atom-to-atom map.
    """

    # Attributes
    reaction_smiles: str  #: The canonical reaction SMILES string.

    # Database
    entrytype_name = 'AAM'
    _table_name = 'AAM'
    _columns = [
        col_recon_id,
        Column('reaction_smiles', str, index_hash = True),
    ]
    _index = [1]

    # Visualisation
    _draw_colour = '7AFF78'

    def __init__(
        self,
        reaction_smiles: str,
        recon_id: Optional[int] = None,
    ):
        super().__init__(recon_id)
        self.reaction_smiles = reaction_smiles

    def _vis_str(self) -> str:
        return self.reaction_smiles