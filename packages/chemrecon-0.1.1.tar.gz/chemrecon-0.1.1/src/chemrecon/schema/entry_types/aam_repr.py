from typing import Optional

from chemrecon.schema import Entry, IdTypeAAMEnum
from chemrecon.schema.db_object import Column, col_recon_id, col_source_id_hashed


class AAMRepr(Entry):
    """ Represents an enzyme entry. """
    # Attributes
    source_id: str  #: Identifier string. (**index**)
    id_type: IdTypeAAMEnum  #: The type of the identifier string (e.g. Reaction SMILES). (**index**)

    # Database
    entrytype_name = 'AAMRepr'
    _table_name = 'AAMRepr'
    _columns = [
        col_recon_id,
        col_source_id_hashed,
        Column('id_type', IdTypeAAMEnum),
    ]
    _index = [1, 2]

    # Visualisation
    _draw_colour = '7AFF78'

    def __init__(
        self,
        source_id: str,
        id_type: IdTypeAAMEnum,
        recon_id: Optional[int] = None,
    ):
        super().__init__(recon_id)
        self.source_id = source_id
        self.id_type = id_type

    def _vis_str(self) -> str:
        return f'{self.id_type.name}: {self.source_id}'