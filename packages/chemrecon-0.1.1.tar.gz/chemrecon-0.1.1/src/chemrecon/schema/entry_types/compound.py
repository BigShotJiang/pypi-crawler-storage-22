from typing import Optional

from chemrecon.schema import SourceEntry
from chemrecon.schema.db_object import (
    Column, col_name, col_properties, col_quality,
    col_recon_id,
    col_source_id,
)
from chemrecon.schema.enums import IdTypeCompoundEnum, Quality


class Compound(SourceEntry):
    """ Represents a compound entry.
    """
    # Attributes
    source_id: str  #: Identifier of the database entry. (**index**)
    id_type: IdTypeCompoundEnum  #: Source of the database entry. (**index**)
    name: Optional[str]  #: Name of the database entry. This May be the common name, IUPAC systematic name, or others.
    quality: Optional[Quality]  #: Indicates the quality of the entry, if this is specified by the source database.
    properties: list[str]  #: Additional properties

    # Database
    entrytype_name = 'Compound'
    _table_name = 'Compound'
    _columns = [
        col_recon_id,
        col_source_id,
        Column('id_type', IdTypeCompoundEnum),
        col_name,
        col_quality,
        col_properties,
    ]
    _index = [1, 2]

    # Visualisation
    _draw_colour = 'C6FFFF'

    def __init__(
            self,
            source_id: str,
            id_type: IdTypeCompoundEnum,
            name: Optional[str] = None,
            quality: Quality = None,
            recon_id: Optional[int] = None,
            properties: Optional[list[str]] = None,
    ):
        super().__init__(recon_id)
        self.source_id = source_id
        self.id_type = id_type
        self.name = name
        self.quality = quality
        self.properties = properties if properties else list()
