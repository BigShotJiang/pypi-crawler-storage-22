from typing import Optional

from chemrecon.schema import IdTypeEnzymeEnum, Quality
from chemrecon.schema.db_object import (
    Column, SourceEntry, col_name, col_properties, col_quality,
    col_recon_id,
    col_source_id,
)

class Enzyme(SourceEntry):
    """ Represents an enzyme entry. """
    # Attributes
    source_id: str  #: Identifier of the database entry. (**index**)
    id_type: IdTypeEnzymeEnum  #: Source of the database entry. Always ``EC`` as of the current version. (**index**)
    name: Optional[str]  #: Name of the enzyme.
    quality: Optional[Quality]  #: Indicates the quality of the entry, if this is specified by the source database.
    properties: list[str]  #: Additional properties

    # Database
    entrytype_name = 'Enzyme'
    _table_name = 'Enzyme'
    _columns = [
        col_recon_id,
        col_source_id,
        Column('id_type', IdTypeEnzymeEnum),
        col_name,
        col_quality,
        col_properties,
    ]
    _index = [1, 2]

    # Visualisation
    _draw_colour = 'F8FF9B'

    def __init__(
            self,
            source_id: str,
            id_type: IdTypeEnzymeEnum,
            name: Optional[str] = None,
            recon_id: Optional[int] = None,
            quality: Optional[Quality] = None,
            properties: Optional[list[str]] = None,
    ):
        super().__init__(recon_id)
        self.source_id = source_id
        self.id_type = id_type
        self.name = name
        self.quality = quality
        self.properties = properties if properties else list()
