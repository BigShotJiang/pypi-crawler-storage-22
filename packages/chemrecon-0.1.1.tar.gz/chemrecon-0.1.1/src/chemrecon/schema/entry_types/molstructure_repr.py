from typing import Optional

from chemrecon.schema import Column, Entry, IdTypeStructureRepresentationEnum
from chemrecon.schema.db_object import col_recon_id, col_source_id_hashed
class MolStructureRepr(Entry):
    """ Represents a representation of a structure, such as an S_SMILES string, S_MOLFILE or similar. """
    # Attributes
    source_id: str  #: Identifier string. (**index**)
    id_type: IdTypeStructureRepresentationEnum  #: The type of the identifier string (e.g. SMILES, InChI). (**index**)
    #: If marked as implicit, this molecular structure only exists implicitly in an atom-to-atom map, and is not
    #: directly referenced by a known compound.
    implicit: bool

    # Database
    entrytype_name = 'MolStructureRepr'
    _table_name = 'MolStructureRepr'
    _columns = [
        col_recon_id,
        col_source_id_hashed,
        Column('id_type', IdTypeStructureRepresentationEnum),
        Column('implicit', bool)
    ]
    _index = [1, 2]

    # Visualisation
    _draw_colour = '7AFF78'

    def __init__(
        self,
        source_id: str,
        implicit: bool,
        id_type: IdTypeStructureRepresentationEnum,
        recon_id: Optional[int] = None,
    ):
        super().__init__(recon_id)
        self.source_id = source_id
        self.id_type = id_type
        self.implicit = implicit

    def _vis_str(self) -> str:
        return f'{self.id_type.name}: {self.source_id}'
