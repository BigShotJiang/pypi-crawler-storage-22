from typing import Optional

from chemrecon.schema import IdTypeReactionEnum, Quality
from chemrecon.schema.db_object import (
    Column, SourceEntry, col_name, col_properties, col_quality,
    col_recon_id,
    col_source_id,
)

class Reaction(SourceEntry):
    """ Represents a compound entry. """
    # Attributes
    source_id: str  #: Identifier of the database entry. (**index**)
    id_type: IdTypeReactionEnum  #: Source of the database entry. (**index**)
    name: Optional[str]
    is_transport: Optional[bool]  #: Whether the reaction is explicitly marked as a transport reaction.
    is_reversible: Optional[bool]  #: Whether the reaction is explicitly marked as reversible.
    quality: Optional[Quality]  #: Indicates the quality of the entry, if this is specified by the source database.
    properties: list[str]  #: Additional properties

    # Database
    entrytype_name = 'Reaction'
    _table_name = 'Reaction'
    _columns = [
        col_recon_id,
        col_source_id,
        Column('id_type', IdTypeReactionEnum),
        col_name,
        Column('is_transport', bool),
        Column('is_reversible', bool),
        col_quality,
        col_properties,
    ]
    _index = [1, 2]

    # Visualisation
    _draw_colour = '9EFFA1'

    def __init__(
            self,
            source_id: str,
            id_type: IdTypeReactionEnum,
            name: Optional[str] = None,
            is_transport: Optional[bool] = None,
            is_reversible: Optional[bool] = None,
            quality: Optional[Quality] = None,
            recon_id: Optional[int] = None,
            properties: Optional[list[str]] = None,
    ):
        super().__init__(recon_id)
        self.source_id = source_id
        self.id_type = id_type
        self.name = name
        self.is_transport = is_transport
        self.is_reversible = is_reversible
        self.quality = quality
        self.properties = properties if properties else list()
