""" Enums and corresponding objects
"""

from __future__ import annotations

from enum import Enum

from chemrecon.core import id_types as id_types
from chemrecon.core.id_types import (
    IdentifierType,
)


class SourceDatabase(Enum):
    unknown = 0
    BIGG = 1
    CHEBI = 2
    ECMDB = 3
    MCSA = 4
    METAMDB = 5
    METANETX = 6
    PUBCHEM = 7
    MANUALLY_ADDED = 8
    AUTOMATIC = 9

    def __str__(self):
        return self.name
    def __repr__(self):
        return self.name


class Quality(Enum):
    unknown = 0
    automatic = 1
    preliminary = 2
    manual = 3
    manual_curated = 4

    def __str__(self):
        return self.name
    def __repr__(self):
        return self.name


class FeatureEnum(Enum):
    F = 1
    I = 2
    C = 3
    T = 4
    S = 5

    def __str__(self):
        return self.name
    def __repr__(self):
        return self.name


class IdTypeEnum(Enum):
    pass

    def __str__(self):
        return self.name
    def __repr__(self):
        return self.name


class IdTypeCompoundEnum(IdTypeEnum):
    unknown = id_types.C_UNKNOWN
    cname = id_types.C_NAME
    mnx = id_types.C_MNX
    bigg = id_types.C_BIGG
    chebi = id_types.C_CHEBI
    pubchem_cid = id_types.C_PUBCHEM
    kegg = id_types.C_KEGG
    ecmdb = id_types.C_ECMDB
    inchikey = id_types.C_INCHIKEY
    slm = id_types.C_SLM
    envipath = id_types.C_ENVIPATH
    lipidmaps = id_types.C_LIPIDMAPS
    hmdb = id_types.C_HMDB
    metacyc = id_types.C_METACYC
    seed = id_types.C_SEED
    sabiork = id_types.C_SABIORK
    reactome = id_types.C_REACTOME
    pdbe = id_types.C_PDBE
    biocyc = id_types.C_BIOCYC
    metamdb = id_types.C_METAMDB
    brenda = id_types.C_BRENDA

class IdTypeStructureRepresentationEnum(IdTypeEnum):
    unknown = id_types.S_UNKNOWN
    smiles = id_types.S_SMILES
    inchi = id_types.S_INCHI
    molfile = id_types.S_MOLFILE
    gml = id_types.S_GML


class IdTypeReactionEnum(IdTypeEnum):
    unknown = id_types.R_UNKNOWN
    rname = id_types.R_NAME
    mnx = id_types.R_MNX
    metacyc = id_types.R_METACYC
    bigg = id_types.R_BIGG
    seed = id_types.R_SEED
    kegg = id_types.R_KEGG
    rhea = id_types.R_RHEA
    sabiork = id_types.R_SABIORK
    metamdb = id_types.R_METAMDB
    mcsa = id_types.R_MCSA
    brenda = id_types.R_BRENDA


class IdTypeAAMEnum(IdTypeEnum):
    unknown = id_types.A_UNKNOWN
    reactionsmiles = id_types.A_REACTIONSMILES
    rxn = id_types.A_RXN
    gml_rule = id_types.A_GML_RULE


class IdTypeEnzymeEnum(IdTypeEnum):
    unknown = id_types.E_UNKNOWN
    ename = id_types.E_NAME
    ec = id_types.E_EC



# Enum registration
# ----------------------------------------------------------------------------------------------------------------
enum_register = [
    SourceDatabase, Quality, FeatureEnum,
    IdTypeCompoundEnum, IdTypeStructureRepresentationEnum,
    IdTypeReactionEnum, IdTypeAAMEnum, IdTypeEnzymeEnum
]

# Set the corresponding enum type for each IdType
for member in IdTypeCompoundEnum:
    if isinstance(member.value, IdentifierType):
        member.value.enum_type = IdTypeCompoundEnum.__getitem__(member.name)

for member in IdTypeReactionEnum:
    if isinstance(member.value, IdentifierType):
        member.value.enum_type = IdTypeReactionEnum.__getitem__(member.name)

for member in IdTypeStructureRepresentationEnum:
    if isinstance(member.value, IdentifierType):
        member.value.enum_type = IdTypeStructureRepresentationEnum.__getitem__(member.name)

for member in IdTypeEnzymeEnum:
    if isinstance(member.value, IdentifierType):
        member.value.enum_type = IdTypeEnzymeEnum.__getitem__(member.name)

for member in IdTypeAAMEnum:
    if isinstance(member.value, IdentifierType):
        member.value.enum_type = IdTypeAAMEnum.__getitem__(member.name)
