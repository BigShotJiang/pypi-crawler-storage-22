from typing import Optional

from chemrecon.schema.db_object import col_src
from chemrecon.schema import Reaction, AAM, ComposedRelation
from chemrecon.schema.enums import SourceDatabase
from chemrecon.schema.entry_types.aam_repr import AAMRepr
from chemrecon.schema.relation_types_procedural.aam_convert_relation import \
    AAMConvert
from chemrecon.schema.relation_types_source.reaction_has_aam_representation_relation import \
    ReactionHasAAMRepr


class ReactionHasAAM(ComposedRelation[Reaction, AAM, AAMRepr]):
    """ This relation gives the associated AAM of a reaction in a standardized format.
        This relation is composed of the `ReactionHasAAMRepr` relation and the `AAMConvert` relations.
        So if a reaction entry includes an RXN or GML representation of a map, this relation gives the same
        map in the standardized, ReactionSMILES-based format.
    """
    # Attributes
    src: SourceDatabase  #: The source database specifying this AAM.

    # Transitive
    rel_type_1 = ReactionHasAAMRepr
    rel_type_2 = AAMConvert
    intermediate_entrytype = AAMRepr

    # Database
    entrytype_name = 'Reaction has AAM'
    _table_name = 'ReactionHasAAM'
    symmetric = False
    source_entrytype = Reaction
    target_entrytype = AAM
    _attribute_columns = [
        col_src
    ]
    _index = [0]

    def __init__(
            self,
            rel_1: ReactionHasAAMRepr,
            rel_2: AAMConvert,
            intermediate: AAMRepr,
            recon_id_1: Optional[int] = None,
            recon_id_2: Optional[int] = None
    ):
        self.src = rel_1.src
        super().__init__(rel_1, rel_2, intermediate, recon_id_1, recon_id_2)

    def _vis_str(self) -> str:
        return f'{self.src.name}'
