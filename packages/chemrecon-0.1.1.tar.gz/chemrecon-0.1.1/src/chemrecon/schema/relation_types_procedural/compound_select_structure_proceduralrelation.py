from __future__ import annotations

from chemrecon.schema.procedural_relation_entrygraph import ProceduralRelationEG
from chemrecon.schema.direction import Direction
from chemrecon.entrygraph.scoring import Scorer
from chemrecon.schema.entry_types.compound import Compound
from chemrecon.schema.entry_types.molstructure import MolStructure
from chemrecon.schema.relation_types_composed.compound_has_molstructure_relation import CompoundHasMolStructure
from chemrecon.schema.relation_types_source.compound_reference_relation import CompoundReference
from chemrecon.schema.relation_types_source.molstructure_standardisation_relation import MolStructureStandardization
from chemrecon.entrygraph.explorationprotocol import ExplorationProtocol

ProtocolSelectStructure = ExplorationProtocol(
    relation_types = {
        (CompoundReference, Direction.SYMMETRIC),
        (CompoundHasMolStructure, Direction.FORWARDS),
        (MolStructureStandardization, Direction.FORWARDS),
    },
)
eg_scorer_compound_select_structure = Scorer[MolStructure](
    score_entry_type = MolStructure
)

class CompoundSelectStructure(ProceduralRelationEG[Compound, MolStructure]):
    """ Procedural relation which computes the most related molecular structures for a given compound using entry graph
        scoring.
    """

    # Database
    _table_name = 'CompoundSelectStructure'
    source_entrytype = Compound
    target_entrytype = MolStructure

    # For EG
    protocol = ProtocolSelectStructure
    entrygraph_scorer = eg_scorer_compound_select_structure
