from __future__ import annotations

from chemrecon.schema.direction import Direction
from chemrecon.entrygraph.scoring import Scorer
from chemrecon.schema.entry_types.aam import AAM
from chemrecon.schema.entry_types.enzyme import Enzyme
from chemrecon.schema.entry_types.reaction import Reaction
from chemrecon.schema.procedural_relation_entrygraph import ProceduralRelationEG
from chemrecon.schema.relation_types_composed.reaction_has_aam_relation import ReactionHasAAM
from chemrecon.schema.relation_types_source.reaction_has_enzyme_relation import ReactionHasEnzyme
from chemrecon.schema.relation_types_source.reaction_reference_relation import ReactionReference
from chemrecon.entrygraph.explorationprotocol import ExplorationProtocol

ProtocolSelectAAM = ExplorationProtocol(
    relation_types = {
        (ReactionReference, Direction.SYMMETRIC),
        (ReactionHasEnzyme, Direction.BOTH),
        (ReactionHasAAM, Direction.FORWARDS)
    },
    # TODO filter (filter out name entries)
)
eg_scorer_reaction_select_aam = Scorer(
    score_entry_type = AAM,
    # TODO more advanced weighing
)

class ReactionSelectAAM(ProceduralRelationEG[Reaction, AAM]):
    """ Procedural relation which computes the most related AAMs for a given reaction using entry graph scoring.
    """

    # Database
    _table_name = 'ReactionSelectAAM'
    source_entrytype = Reaction
    target_entrytype = AAM

    # For EG
    protocol = ProtocolSelectAAM
    entrygraph_scorer = eg_scorer_reaction_select_aam
