from typing import Optional

from chemrecon.schema import Relation, Compound, SourceDatabase, MolStructureRepr
from chemrecon.schema.db_object import col_src


class CompoundHasStructureRepresentation(Relation[Compound, MolStructureRepr]):
    """ Relates a compound entry to the structure representation (e.g. SMILES, InChI) given by that database.
    """
    # Attributes
    src: SourceDatabase  #: The source database containing this representation.

    # Database
    _table_name = 'CompoundHasStructureRepresentation'
    symmetric = False
    source_entrytype = Compound
    target_entrytype = MolStructureRepr
    _attribute_columns = [
        col_src
    ]
    _index = [0]

    def __init__(
        self,
        src: SourceDatabase = SourceDatabase.unknown,
        recon_id_1: Optional[int] = None,
        recon_id_2: Optional[int] = None
    ):
        super().__init__(recon_id_1, recon_id_2)
        self.src = src

    def _vis_str(self) -> str:
        return f'{self.src.name}'
