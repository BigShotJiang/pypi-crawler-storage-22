from typing import Optional

from chemrecon.schema import Relation, Compound, SourceDatabase
from chemrecon.schema.db_object import col_src


class CompoundReference(Relation[Compound, Compound]):
    """ Inter- or intra-database reference between compounds.
    """
    # Attributes
    src: SourceDatabase  #: The source of the relation

    # Database
    entrytype_name = 'Compound Reference'
    _table_name = 'CompoundReference'
    symmetric = True
    source_entrytype = Compound
    target_entrytype = Compound
    _attribute_columns = [
        col_src
    ]
    _index = [0]

    def __init__(
        self,
        src: SourceDatabase = SourceDatabase.unknown,
        recon_id_1: Optional[int] = None,
        recon_id_2: Optional[int] = None
    ):
        super().__init__(recon_id_1, recon_id_2)
        self.src = src

    def _vis_str(self) -> str:
        return f'ref ({self.src.name})'
