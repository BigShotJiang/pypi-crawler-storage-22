from typing import Optional

from chemrecon.schema.enums import SourceDatabase
from chemrecon.schema.db_object import Relation, col_src, InverseRelation
from chemrecon.schema.entry_types.enzyme import Enzyme


# Is A / Has Instance
# ----------------------------------------------------------------------------------------------------------------------
class EnzymeIsA(Relation[Enzyme, Enzyme]):
    """ Hierarchical relation which indicates that an enzyme is a member of a class of enzymes.
        The EC number means that this can be automatically resolved, e.g. `1.2.3.4` *is_a* `1.2.3`
    """
    # Attributes
    src: SourceDatabase  #: The source of the relation

    # Database
    entrytype_name = 'Is a'
    _table_name = 'EnzymeIsA'
    symmetric = False
    source_entrytype = Enzyme
    target_entrytype = Enzyme
    _attribute_columns = [
        col_src
    ]
    _index = [0]

    def __init__(
            self,
            src: SourceDatabase,
            recon_id_1: Optional[int] = None,
            recon_id_2: Optional[int] = None
    ):
        super().__init__(recon_id_1, recon_id_2)
        self.src = src

    def _vis_str(self) -> str:
        return f'is a'

class EnzymeHasInstance(InverseRelation[Enzyme, Enzyme]):
    """ Hierarchical relation which indicates that an enzyme is a member of a class of enzymes.
        The EC number means that this can be automatically resolved, e.g. `1.2.3.4` *is_a* `1.2.3`
    """
    # Attributes
    src: SourceDatabase  #: The source of the relation

    # Inverse
    inverse_main_relation = EnzymeIsA

    # Database
    entrytype_name = 'Has Instance'
    _table_name = 'EnzymeHasInstance'
    symmetric = False
    source_entrytype = Enzyme
    target_entrytype = Enzyme
    _attribute_columns = [
        col_src
    ]
    _index = [0]

    def __init__(
            self,
            src: SourceDatabase,
            recon_id_1: Optional[int] = None,
            recon_id_2: Optional[int] = None
    ):
        super().__init__(recon_id_1, recon_id_2)
        self.src = src

    def _vis_str(self) -> str:
        return f'has instance'

# Set Inverse
EnzymeIsA.has_inverse = EnzymeHasInstance

# New / Old id
# ----------------------------------------------------------------------------------------------------------------------
class EnzymeHasNewID(Relation[Enzyme, Enzyme]):
    """ Indicates correspondence between identifiers in different database versions. Can be used to resolve deprecated
        identifiers.
    """
    # Attributes
    src: SourceDatabase

    # Database
    entrytype_name = 'Has New ID'
    _table_name = 'EnzymeHasNewID'
    symmetric = False
    source_entrytype = Enzyme
    target_entrytype = Enzyme
    _attribute_columns = [
        col_src
    ]
    _index = [0]

    def __init__(
            self,
            src: SourceDatabase,
            recon_id_1: Optional[int] = None,
            recon_id_2: Optional[int] = None
    ):
        super().__init__(recon_id_1, recon_id_2)
        self.src = src

    def _vis_str(self) -> str:
        return f'new id'

class EnzymeHasOldID(InverseRelation[Enzyme, Enzyme]):
    """ Indicates correspondence between identifiers in different database versions. Can be used to resolve deprecated
        identifiers.
    """
    # Attributes
    src: SourceDatabase

    # Inverse
    inverse_main_relation = EnzymeHasNewID

    # Database
    entrytype_name = 'Has Old ID'
    _table_name = 'EnzymeHasOldID'
    symmetric = False
    source_entrytype = Enzyme
    target_entrytype = Enzyme
    _attribute_columns = [
        col_src
    ]
    _index = [0]

    def __init__(
            self,
            src: SourceDatabase,
            recon_id_1: Optional[int] = None,
            recon_id_2: Optional[int] = None
    ):
        super().__init__(recon_id_1, recon_id_2)
        self.src = src

    def _vis_str(self) -> str:
        return f'old id'

# Set Inverse
EnzymeHasNewID.has_inverse = EnzymeHasOldID
