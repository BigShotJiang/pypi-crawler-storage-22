from typing import Optional

from chemrecon.schema import Relation, Reaction, AAMRepr, SourceDatabase
from chemrecon.schema.db_object import col_src


class ReactionHasAAMRepr(Relation[Reaction, AAMRepr]):
    """ Relates a reaction entry to the given AAM representation (e.g. RXN file).
    """
    # Attributes
    src: SourceDatabase  #: The source database containing this AAM.

    # Database
    entrytype_name = 'Reaction has AAMRepr'
    _table_name = 'ReactionHasAAMRepr'
    symmetric = False
    source_entrytype = Reaction
    target_entrytype = AAMRepr
    _attribute_columns = [
        col_src
    ]
    _index = [0]

    def __init__(
        self,
        src: SourceDatabase = SourceDatabase.unknown,
        recon_id_1: Optional[int] = None,
        recon_id_2: Optional[int] = None
    ):
        super().__init__(recon_id_1, recon_id_2)
        self.src = src

    def _vis_str(self) -> str:
        return f'{self.src.name}'
