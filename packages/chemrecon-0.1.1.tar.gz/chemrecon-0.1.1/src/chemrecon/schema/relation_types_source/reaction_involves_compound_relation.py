from typing import Optional

from chemrecon.schema import Column, Relation, Reaction, Compound
from chemrecon.schema.db_object import InverseRelation
class ReactionInvolvesCompound(Relation[Reaction, Compound]):
    """ Each reaction is connected by this relation to the compounds which take part in the reaction, annotated
        with the stoichiometric coefficient.
    """
    # Attributes
    n: int  #: The stoichiometric coefficient of the compound in the reaction

    # Database
    entrytype_name = 'Reaction involves Compound'
    _table_name = 'ReactionInvolvesCompound'
    symmetric = False
    source_entrytype = Reaction
    target_entrytype = Compound
    _attribute_columns = [
        Column('n', int)
    ]
    _index = [0]

    def __init__(
        self,
        n: int,
        recon_id_1: Optional[int] = None,
        recon_id_2: Optional[int] = None
    ):
        super().__init__(recon_id_1, recon_id_2)
        self.n = n

    def _vis_str(self) -> str:
        return f'has compound ({self.n})'

class CompoundParticipatesInReaction(InverseRelation[Compound, Reaction]):
    """ Each reaction is connected by this relation to the compounds which take part in the reaction, annotated
        with the stoichiometric coefficient.
    """
    # Attributes
    n: int  #: The stoichiometric coefficient of the compound in the reaction

    # Inverse
    inverse_main_relation = ReactionInvolvesCompound

    # Database
    entrytype_name = 'Compound Participates in Reaction'
    _table_name = 'CompoundParticipatesInReaction'
    symmetric = False
    source_entrytype = Compound
    target_entrytype = Reaction
    _attribute_columns = [
        Column('n', int)
    ]
    _index = [0]

    def __init__(
        self,
        n: int,
        recon_id_1: Optional[int] = None,
        recon_id_2: Optional[int] = None
    ):
        super().__init__(recon_id_1, recon_id_2)
        self.n = n

    def _vis_str(self) -> str:
        return f'in reaction ({self.n})'

# Set inverse
ReactionInvolvesCompound.has_inverse = CompoundParticipatesInReaction
