from typing import Optional

from chemrecon.schema import Relation, Reaction, SourceDatabase
from chemrecon.schema.db_object import col_src

class ReactionReference(Relation[Reaction, Reaction]):
    """ Inter- or intra-database reference between reactions.
    """
    # Attributes
    src: SourceDatabase  #: The source of the reference.

    # Database
    entrytype_name = 'Reaction Reference'
    _table_name = 'ReactionReference'
    symmetric = True
    source_entrytype = Reaction
    target_entrytype = Reaction
    _attribute_columns = [
        col_src
    ]
    _index = [0]

    def __init__(
        self,
        src: SourceDatabase = SourceDatabase.unknown,
        recon_id_1: Optional[int] = None,
        recon_id_2: Optional[int] = None
    ):
        super().__init__(recon_id_1, recon_id_2)
        self.src = src

    def _vis_str(self) -> str:
        return f'ref ({self.src.name})'
