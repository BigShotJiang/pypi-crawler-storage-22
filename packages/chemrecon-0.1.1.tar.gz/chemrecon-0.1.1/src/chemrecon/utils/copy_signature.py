from collections.abc import Callable
from typing import Any, cast, ParamSpec, TypeVar

def copy_signature[**P, T](_origin: Callable[P, T]) -> Callable[[Callable[..., Any]], Callable[P, T]]:
    """ Decorates a function to inform type checker that it takes the same arguments as another function.
    """
    def decorator(target_function: Callable[..., Any]) -> Callable[P, T]:
        return cast(Callable[P, T], target_function)

    return decorator