from typing import Any


class EncodableList[T: Any](list[T]):
    """ Simple wrapper for built-in list class to allow for encoding for memoization purposes.
    """
    def encode(self, *args, **kwargs):
        return str([x.encode() for x in self.__iter__()]).encode()

    def __hash__(self):
        return self.encode().__hash__()
