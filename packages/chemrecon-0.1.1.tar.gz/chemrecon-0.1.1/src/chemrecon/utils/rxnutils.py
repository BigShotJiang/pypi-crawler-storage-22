import re

re_comment = re.compile(r'{(.*)}')


def extract_molblocks_v2000(rxnblock: str) -> list[tuple[str, str]]:
    """ Gets the individual molblocks for each compound involved in the reaction. Returns tuples of the
    molblock and comment string.
    """
    molblocks: list[tuple[str, str]] = list()

    for mol_n, mol_str in enumerate(rxnblock.split('$MOL')):

        # Skip the first, $RXN block
        if mol_str.startswith('$RXN'):
            continue

        # Comment
        comment_match = re.search(re_comment, mol_str)
        if comment_match:
            comment_str = comment_match[0]
        else:
            comment_str = ''

        # Block
        lines = mol_str.splitlines()

        # First, read count line to get number of atoms
        countline_i = 0
        while len(lines[countline_i]) == 0 or (not lines[countline_i].strip()[0].isnumeric()):
            countline_i += 1
        countline = lines[countline_i]

        countline_items = filter(lambda x: x, countline.split(' '))
        n_atoms = int(countline[0:3])
        molblock = '\n'.join(lines[1:])

        molblocks.append((molblock, comment_str))

    # Finalise
    return molblocks



