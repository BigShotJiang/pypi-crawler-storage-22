import os

def set_cwd():
    while os.getcwd().split('/')[-1] not in {
        'chemrecon',
        'ChemRecon',
        'src',
        'chemrecon_populator'
    }:
        os.chdir('..')

    print(f'Changed directory: {os.getcwd()}')
