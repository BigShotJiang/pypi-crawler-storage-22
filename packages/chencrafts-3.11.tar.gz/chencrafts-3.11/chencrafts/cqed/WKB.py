__all__ = ["WKB", "HeavyFlxnWKB", "DoubleWellHeavyFlxn"]

from scipy.optimize import minimize, root
import matplotlib.pyplot as plt
import numpy as np
import qutip as qt
from scipy.integrate import cumulative_trapezoid
from scipy.special import hermite
import math
import scqubits as scq
import warnings

from chencrafts.toolbox.plot import color_palettes
from chencrafts.cqed.qt_helper import trans_by_kets

from typing import Callable, Literal

EPSILON = 1e-5

class WKB:
    def __init__(
        self,
        mass: float,
        potential: Callable[[float], float],
        minimum_loc: float = 0.0,
        lvl: int = 0,
        refine_minimum: bool = True,
    ):
        """
        Compute low energy bound state wavefunction using WKB approximation.

        Note 1: Schrödinger equation is:
        [p^2 / (2m) + V(x)] * psi(x) = E * psi(x)
        The local oscillator approximation is:
        [p^2 / (2m) + 1/2 * m * omega^2 * x^2] * psi(x) = E * psi(x)
        
        Note 2: We take 
        - hbar = 1;
        - x and p as unitless;
        - [x, p] = i;
        - 1/m, omega, E are all in energy / angular frequency units.
        
        
        Parameters
        ----------
        minimum_loc : float
            Location of the potential local minimum. Specify refine_minimum=True to refine the minimum location.
        mass : float
            Mass of the particle (in units where ħ = 1).
        potential : Callable[[float], float]
            Potential energy function.
        lvl : int
            Energy level of the local state to compute. By default, compute the ground state.
        refine_minimum : bool
            Whether to refine the minimum location.
        """
        self.mass = mass
        self._potential = potential
        self.lvl = lvl
        self._minimum_loc = float(minimum_loc)
        
        self._refine_minimum = refine_minimum
        
        self._initialize()
            
    def _initialize(self):
        if self._refine_minimum:
            self._minimum_loc = self._find_minimum_loc(self._minimum_loc)
        else:
            self._minimum_loc = self._minimum_loc
            
    def potential(self, x: float) -> float:
        return self._potential(x)
        
    @property
    def minimum_loc(self) -> float:
        """
        Location of the potential local minimum.
        """
        return self._minimum_loc
    
    @minimum_loc.setter
    def minimum_loc(self, value: float):
        """
        Set the location of the potential local minimum.
        """
        self._minimum_loc = value
        if self._refine_minimum:
            self._minimum_loc = self._find_minimum_loc(value)
        
    def _find_minimum_loc(self, init_guess: float) -> float:
        """
        Find the potential local minimum around the initial guess.
        """
        # Try BFGS first (fast but sensitive to numerical issues)
        solution = minimize(
            lambda x: self.potential(x[0]),
            x0=[init_guess],
            method="BFGS",
            tol=EPSILON,
        )
        
        # If BFGS fails due to precision issues, try Nelder-Mead (more robust)
        if not solution.success:
            solution = minimize(
                lambda x: self.potential(x[0]),
                x0=[init_guess],
                method="Nelder-Mead",
                options={'xatol': EPSILON, 'fatol': EPSILON * 1e-2},
            )
        
        if not solution.success:
            raise RuntimeError(
                f"Could not locate a local minimum near {init_guess}: {solution.message}"
            )

        return float(solution.x[0])

    def potential_curvature(self, x: float, eps: float = EPSILON) -> float:
        """
        Second derivative of the potential via finite differences.
        """
        return (
            self.potential(x + eps)
            - 2 * self.potential(x)
            + self.potential(x - eps)
        ) / (eps ** 2)

    def omega(self) -> float:
        """
        Local harmonic frequency around the minimum (assumes ħ = 1).
        """
        vpp = self.potential_curvature(self.minimum_loc)
        if vpp <= 0:
            raise RuntimeError("Local curvature is non-positive; cannot define omega.")
        return (vpp / self.mass) ** 0.5

    def energy_above_minimum(self) -> float:
        """
        Energy above the potential minimum.
        """
        return (self.lvl + 0.5) * self.omega()

    def energy(self) -> float:
        """
        Local harmonic energy estimate for a given level (assumes ħ = 1).
        """
        return self.potential_minimum() + self.energy_above_minimum()
    
    def x_zpf(self) -> float:
        """
        Zero-point fluctuation of the position operator.
        """
        return np.sqrt(
            1 / 2 / self.mass / self.omega()
        )
        
    def p_zpf(self) -> float:
        """
        Zero-point fluctuation of the momentum operator.
        """
        return np.sqrt(
            self.mass * self.omega() / 2
        )
    
    def potential_minimum(self) -> float:
        """
        Potential value at the local minimum.
        """
        return self.potential(self.minimum_loc)
    
    def turning_point(self, region: Literal["left", "right"] = "left") -> float:
        """
        Find quantum-classical turning point x around the local minimum, i.e., potential(x) = E.
        """
        x0 = self.minimum_loc

        v0 = self.potential(x0)
        vpp = self.potential_curvature(x0)
        if vpp <= 0:
            raise RuntimeError("Local curvature is non-positive; cannot estimate energy.")

        energy = self.energy()

        def _f(x: float) -> float:
            return self.potential(x) - energy

        direction = -1.0 if region == "left" else 1.0
        dx = (2.0 * (energy - v0) / vpp) ** 0.5
        x_guess = x0 + direction * dx
        solution = root(lambda y: _f(y[0]), x0=[x_guess], tol=EPSILON)
        if not solution.success:
            raise RuntimeError(
                f"Could not locate turning point near {x_guess}: {solution.message}"
            )

        return float(solution.x[0])
    
    def wavefunction_mid(self, x: float | np.ndarray) -> complex | np.ndarray:
        """
        Wavefunction in the middle (clasically allowed) region, i.e., the local harmonic oscillator 
        wavefunction.
        """
        omega = self.omega()
        lvl = self.lvl
        prefactor = (
            np.power(self.mass * omega / np.pi, 0.25) 
            / np.sqrt(2**lvl * math.factorial(lvl))
        )
        xi = np.sqrt(self.mass * omega) * (x - self.minimum_loc)
        return prefactor * hermite(lvl)(xi) * np.exp(-xi**2 / 2)
    
    def momentum_func(self, x: float) -> float:
        """
        Momentum of the particle at a given position. It is imaginary 
        when the particle is in the classically forbidden region.
        """
        return np.sqrt(
            (2 + 0j) 
            * self.mass
            * (self.energy() - self.potential(x))
        )

    def wavefunction_forbidden(
        self, x: float | np.ndarray, dx: float = 0.1
    ) -> complex | np.ndarray:
        """
        Wavefunction in the classically forbidden region.
        
        Parameters
        ----------
        x : float | np.ndarray
            Position(s) to evaluate the wavefunction at.
        dx : float
            Step size for doing numerical integration by trapezoidal rule.
        eps : float
            Small shift to avoid singularity in the wavefunction.
        
        Returns
        -------
        complex | np.ndarray
            Wavefunction value(s) in the classically forbidden region.
        """
        left_tp = self.turning_point("left")
        right_tp = self.turning_point("right")
        
        if isinstance(x, float | int | complex):
            assert x < left_tp or x > right_tp, "x is in the classically allowed region"
            assert x != left_tp and x != right_tp, "x is at a turning point"
            region = "left" if x < left_tp else "right"
            x_array = np.array([x])
        else:
            assert np.all(x < left_tp) or np.all(x > right_tp), "Not all x are in the classically allowed region"
            assert not np.any(x == left_tp) and not np.any(x == right_tp), "Some x is at a turning point"
            region = "left" if np.all(x < left_tp) else "right"
            x_array = x
        
        # get x list for integration: unique values from uniform grid + x itself
        # they are ordered from the turning point to x
        if region == "left":
            full_x_array = np.sort(np.unique(np.concatenate([
                np.arange(left_tp, np.min(x_array), -dx), 
                x_array
            ])))[::-1]
        else:
            full_x_array = np.sort(np.unique(np.concatenate([
                np.arange(right_tp, np.max(x_array), dx), 
                x_array
            ])))
            
        # momentum, action integral
        full_momentum_array = self.momentum_func(full_x_array).imag
        full_action_array = cumulative_trapezoid(
            full_momentum_array, full_x_array, initial=0.0
        )
        # extract the wanted values in the original x_array order
        if region == "left":
            # full_x_array must be in an ascending order
            x_indices = np.searchsorted(full_x_array[::-1], x_array)
            x_indices = len(full_x_array) - 1 - x_indices
            full_action_array *= -1
        else:
            x_indices = np.searchsorted(full_x_array, x_array)
        momentum_array = full_momentum_array[x_indices]
        action_array = full_action_array[x_indices]
        
        # Coefficient
        # It seems that without the "hermite" prefactor, the wavefunction is 
        # more accurate at the turning point. Since this is anyway a 
        # "subdominant" / non-exponential prefactor that was added arbitrarily, 
        # we just replace it by (-1)**lvl.
        mass = self.mass
        omega = self.omega()
        lvl = self.lvl
        sign = (-1)**lvl if region == "left" else 1
        
        # coeff derived by myself
        # coeff = (
        #     sign
        #     * np.power(
        #         mass**2 * omega**2 * (2 * lvl + 1)
        #         / 4 / np.pi / np.e,
        #         0.25
        #     )
        #     * (2 * lvl + 1)**(lvl/2 + 1/4)
        #     / np.sqrt(2**lvl * math.factorial(lvl))
        #     * np.exp(-lvl / 2)
        # )
        
        # coeff from Song 2008, much more accurate than the coeff above
        g = lambda k: (
            np.sqrt(2 * np.pi)
            / math.factorial(k)
            * np.power(k + 1/2, k + 1/2)
            * np.exp(-(k + 1/2))
        )
        l_ho = np.sqrt(1 / mass / omega)    # different from x_zpf
        coeff = (
            sign
            * np.sqrt(g(lvl) / 2 / np.pi)
            / l_ho
        )
        
        wf_array = (
            coeff
            / np.sqrt(momentum_array)
            * np.exp(-action_array)
        )
        
        if isinstance(x, float | int | complex):
            return wf_array[0]
        else:
            return wf_array
        
    def _default_x_array(self) -> np.ndarray:
        """
        Default x array for plotting the wavefunction.
        """
        turning_points = self.turning_point("left"), self.turning_point("right")
        rough_size = np.abs(turning_points[1] - turning_points[0])
        return np.linspace(
            turning_points[0] - rough_size,
            turning_points[1] + rough_size, 
            101
        )
        
    def plot_potential(
        self,
        ax: plt.Axes = None,
        x_array: np.ndarray = None,
    ):
        """
        Plot the potential.
        """
        if ax is None:
            _, ax = plt.subplots()
            
        colors = color_palettes["PGL"]
        
        # x
        minimum_location = self.minimum_loc
        turning_points = self.turning_point("left"), self.turning_point("right")
        if x_array is None:
            x_array = self._default_x_array()
        
        # potential
        potential_list = self.potential(x_array)
        minimum_value = self.potential_minimum()
        energy = self.energy()
        ax.plot(x_array, potential_list, color=colors[1])
        ax.scatter([minimum_location], [minimum_value], color=colors[1], marker="o", zorder=10)
        ax.axvline(turning_points[0], color=colors[2], linestyle="--", zorder=10)
        ax.axvline(turning_points[1], color=colors[2], linestyle="--", zorder=10)
        ax.axhline(energy, color=colors[1], linestyle="--", zorder=10)
        
        return ax
        
        
    def plot_wavefunction(
        self,
        ax: plt.Axes = None,
        x_array: np.ndarray = None,
        scale: float = 1.0,
        shift: float = 0.0,
    ):
        """
        Plot the wavefunction.
        """
        if ax is None:
            _, ax = plt.subplots()
            
        colors = color_palettes["PGL"]
        
        # x
        turning_points = self.turning_point("left"), self.turning_point("right")
        if x_array is None:
            x_array = self._default_x_array()
        
        # wavefunction
        wf_mid = self.wavefunction_mid(x_array) * scale + shift
        ax.plot(x_array, wf_mid.real, color=colors[0], linestyle="--", zorder=10)
        x_left = x_array[x_array < turning_points[0]]
        wf_left = self.wavefunction_forbidden(x_left) * scale + shift
        ax.plot(x_left, wf_left.real, color=colors[0], linestyle="-", zorder=10)
        x_right = x_array[x_array > turning_points[1]]
        wf_right = self.wavefunction_forbidden(x_right) * scale + shift
        ax.plot(x_right, wf_right.real, color=colors[0], linestyle="-", zorder=10)
        
        ax.grid()
        
        return ax
    
    def plot(
        self, 
        ax: plt.Axes = None,
        wavefunction_scale: float = 1.0,
        x_array: np.ndarray = None,
    ):
        """
        Plot the potential and the wavefunction.
        
        Parameters
        ----------
        ax : plt.Axes
            Axes to plot on.
        wavefunction_scale : float
            Scale of the wavefunction.
        forbidden_region_extension : float
            Extension of the forbidden region.
        """
        ax = self.plot_potential(ax=ax, x_array=x_array)

        energy = self.energy()
        ax = self.plot_wavefunction(
            ax=ax, 
            x_array=x_array, 
            scale=wavefunction_scale,
            shift=energy,
        )
        
        return ax
    
    def coupling_strength(
        self, 
        other: "WKB", 
        evaluate_at: float = None,
        eps: float = EPSILON,
    ) -> complex:
        """
        Compute the coupling strength between two WKB wavefunctions.
        """
        assert self.mass == other.mass, "Two WKB objects must belong to the same system (i.e., have the same mass)."
        mass = self.mass
        
        if evaluate_at is None:
            min_loc_self = self.minimum_loc
            min_loc_other = other.minimum_loc
            evaluate_at = (min_loc_self + min_loc_other) / 2
        
        x_array = np.array([evaluate_at - eps/2, evaluate_at + eps/2])
        wf_self = self.wavefunction_forbidden(x_array)
        wf_other = other.wavefunction_forbidden(x_array)
        
        wf_val_self = np.average(wf_self)
        wf_val_other = np.average(wf_other)
        
        wf_grad_self = (wf_self[1] - wf_self[0]) / eps
        wf_grad_other = (wf_other[1] - wf_other[0]) / eps
        
        g = (
            - 1 / (2 * mass)
            * (wf_grad_self * wf_val_other - wf_val_self * wf_grad_other)
        )
        
        if other.minimum_loc < self.minimum_loc:
            g = -g
        
        return g
        
    def x_mat_elem(
        self,
        other: "WKB",
    ) -> complex:
        """
        Compute the matrix element of the position operator between two eigenstates 
        corresponding to the hybridized local WKB states.
        i.e., <\bar{self}|x|\bar{other}> where 
        |\bar{self}> = cos(theta) |self> + sin(theta) |other>
        and
        |\bar{other}> = -sin(theta) |self> + cos(theta) |other>.
        """
        assert self.mass == other.mass, "Two WKB objects must belong to the same system (i.e., have the same mass)."
        
        if self.lvl > 0 or other.lvl > 0:
            warnings.warn(
                "This method is unlikely to be accurate for high-lying states, "
                "as higher-lying eigenstates usually have multiple components "
                "in the neighboring wells."
            )
        
        if self.minimum_loc > other.minimum_loc:
            return other.x_mat_elem(self) 
        
        # In the |self>, |other> basis,
        # Hamiltonian = Delta * sigma_z + g * sigma_x
        energy_self = self.energy()
        energy_other = other.energy()
        Delta = (energy_other - energy_self) / 2
        g = self.coupling_strength(other)
        
        # position operator = x_avg * I + x_0 * sigma_z
        min_loc_self = self.minimum_loc
        min_loc_other = other.minimum_loc
        x_avg = (min_loc_self + min_loc_other) / 2
        x_0 = (min_loc_other - min_loc_self) / 2
        
        # eigenstates = cos(theta) * |self> + sin(theta) * |other>
        theta = 0.5 * np.arctan2(g, Delta)
        
        # matrix element
        # = <bar_self| (x_avg * I + x_0 * sigma_z) |bar_other>
        # = (cos θ <self| + sin θ <other|) x (-sin θ |self> + cos θ |other>)
        # since <self|x|other> = 0 (x is diagonal in local basis):
        # = -cos θ sin θ <self|x|self> + sin θ cos θ <other|x|other>
        # = sin θ cos θ [(x_avg + x_0) - (x_avg - x_0)]
        # = 2 x_0 sin θ cos θ
        x_mat_elem = 2 * x_0 * np.sin(theta) * np.cos(theta)
        
        return x_mat_elem
    
    def p_mat_elem(
        self,
        other: "WKB",
    ) -> complex:
        """
        Compute the matrix element of the momentum operator between two eigenstates 
        corresponding to the hybridized local WKB states.
        """
        assert self.mass == other.mass, "Two WKB objects must belong to the same system (i.e., have the same mass)."
        mass = self.mass
        energy_self = self.energy()
        energy_other = other.energy()
        
        x_mat_elem = self.x_mat_elem(other)
        p_mat_elem = (
            1j * mass 
            * (energy_other - energy_self)
            * x_mat_elem
        )
        
        return p_mat_elem
    
    def copy(self) -> "WKB":
        """
        Create a copy of the WKB object.
        
        Returns
        -------
        WKB
            A new WKB object with the same parameters.
        """
        return WKB(
            mass=self.mass,
            potential=self._potential,
            minimum_loc=self._minimum_loc,
            lvl=self.lvl,
            refine_minimum=False,  # Use already refined minimum_loc
        )
        
    
class HeavyFlxnWKB(WKB):
    def __init__(
        self,
        EJ: float,
        EC: float,
        EL: float,
        flux: float = 0.5,
        minimum_loc: float = 0.0,
        lvl: int = 0,
        refine_minimum: bool = True,
    ):
        """
        WKB wavefunction for a heavy fluxonium.
        
        Parameters
        ----------
        EJ : float
            Josephson energy (unit: GHz).
        EC : float
            Charging energy (unit: GHz).
        EL : float
            Inductance energy (unit: GHz).
        flux : float
            Flux through the fluxonium (unit: Phi_0).
        minimum_loc : float
            Location of the potential local minimum (unit: Phi_0 / 2pi).
            Note the unit is different from flux parameter by a factor of 2pi!
        lvl : int
            Energy level of the local state to compute. By default, compute the ground state.
        refine_minimum : bool
            Whether to refine the minimum location.
        """
        self._EJ = EJ
        self._EC = EC
        self._EL = EL
        self._flux = flux
        
        super().__init__(
            mass=1 / 8 / EC,
            potential=lambda phi: self._flxn_potential(phi, EJ, EL, flux),
            minimum_loc=minimum_loc,
            lvl=lvl,
            refine_minimum=refine_minimum,
        )
        
    @staticmethod
    def _flxn_potential(phi: float, EJ: float, EL: float, flux: float) -> float:
        return (
            -EJ * np.cos(phi + flux * np.pi * 2) 
            + EL / 2 * phi**2
        )
        
    def _initialize(self):
        self._potential = lambda phi: self._flxn_potential(
            phi, self._EJ, self._EL, self._flux
        )
        super()._initialize()
        
    @property
    def EJ(self) -> float:
        return self._EJ
    
    @EJ.setter
    def EJ(self, value: float):
        self._EJ = value
        self._initialize()
        
    @property
    def EC(self) -> float:
        return self._EC
    
    @EC.setter
    def EC(self, value: float):
        self._EC = value
        # don't need to reinitialize
        
    @property
    def EL(self) -> float:
        return self._EL
    
    @EL.setter
    def EL(self, value: float):
        self._EL = value
        self._initialize()
        
    @property
    def flux(self) -> float:
        return self._flux
    
    @flux.setter
    def flux(self, value: float):
        self._flux = value
        self._initialize()
        
    def omega(self) -> float:
        """
        Local harmonic frequency around the minimum (assumes ħ = 1).
        
        Overrides the parent class method to account for the weak anharmonicity.
        """
        vpp = self.potential_curvature(self.minimum_loc)
        if vpp <= 0:
            raise RuntimeError("Local curvature is non-positive; cannot define omega.")
        return (vpp / self.mass) ** 0.5 - self._EC
    
    def energy_above_minimum(self) -> float:
        """
        Energy above the potential minimum, taking into account the weak anharmonicity.
        """
        harmonic_energy = super().energy_above_minimum()
        EC = self._EC
        lvl = self.lvl
        return harmonic_energy - EC * lvl * (lvl - 1) / 2
        
    def _fluxonium_wavefunctions(
        self,
        truncated_dim: int = 6,
        cutoff: int = 220,
        x_array: np.ndarray = None,
        esys: (np.ndarray, np.ndarray) = None,
    ) -> np.ndarray:
        """
        Wavefunctions of the fluxonium

        Parameters
        ----------
        truncated_dim : int
            Number of energy eigenstates to include.
        cutoff : int
            Cutoff for the fluxonium.
        x_array : np.ndarray
            Grid of phi values to evaluate the wavefunctions at.
        esys : (np.ndarray, np.ndarray)
            Eigenvalues and eigenvectors of the fluxonium. This is 
            solely used for speeding up the computation if repeated calls 
            are made.
            
        Returns
        -------
        np.ndarray
            Wavefunctions of the fluxonium, shape: (truncated_dim, len(x_array)).
        """
        flxn = scq.Fluxonium(
            EJ=self._EJ,
            EC=self._EC,
            EL=self._EL,
            flux=self._flux,
            cutoff=cutoff,
            truncated_dim=truncated_dim,
        )
        if esys is None:
            esys = flxn.eigensys(truncated_dim)
        
        if x_array is None:
            x_array = self._default_x_array()
            
        # convert x_array to phi_grid
        phi_grid = scq.Grid1d(
            min_val=x_array[0],
            max_val=x_array[-1],
            pt_count=len(x_array),
        )
        if not np.all(x_array == phi_grid.make_linspace()):
            raise ValueError("Can't build a scqubits Grid1d object from the given x_array.")
        
        wf_list = [
            flxn.wavefunction(
                esys,
                lvl,
                phi_grid
            ).amplitudes
            for lvl in range(truncated_dim)
        ]
        
        return np.array(wf_list)
        
    def state_vector_exact(
        self, 
        truncated_dim: int = 6,
        cutoff: int = 220,
        x_array: np.ndarray = None,
        num_components: int = 2,
        esys: (np.ndarray, np.ndarray) = None,
    ) -> np.ndarray:
        """
        Find the state vector in the basis of energy eigenstates.
        
        Parameters
        ----------
        truncated_dim : int
            Number of energy eigenstates to include.
        cutoff : int
            Cutoff for the fluxonium.
        x_array : np.ndarray
            Grid of phi values to evaluate the wavefunctions at.
        esys : (np.ndarray, np.ndarray)
            Eigenvalues and eigenvectors of the fluxonium. This is 
            solely used for speeding up the computation if repeated calls 
            are made.
        num_components : int
            Number of non-zero components to keep in the state vector.
            
        Returns
        -------
        np.ndarray
            State vector in the basis of energy eigenstates, shape: (truncated_dim,).
        """
        
        if x_array is None:
            x_array = self._default_x_array()
        
        # Exact eigenstates
        wf_list = self._fluxonium_wavefunctions(truncated_dim, cutoff, x_array, esys)
        
        # Local oscillator state
        wf_lo = self.wavefunction_mid(x_array)
        
        inner_product_list = np.array([
            np.dot(wf_lo, wf.conj())
            for wf in wf_list
        ])
        
        # keep only the largest few inner products and set the rest to 0
        overlap_list = np.abs(inner_product_list)**2
        sorted_overlap_list = np.sort(overlap_list)[::-1]
        threshold = sorted_overlap_list[num_components-1]
        mask_to_zero = overlap_list < threshold
        inner_product_list[mask_to_zero] = 0.0
        
        # normalize the remaining inner products
        inner_product_list = inner_product_list / np.sqrt(np.sum(np.abs(inner_product_list)**2))
        
        # return the state vector
        return inner_product_list
        
    def wavefunction_exact(
        self, 
        x_array: np.ndarray = None, 
        truncated_dim: int = 6,
        cutoff: int = 220,
        num_components: int = 2,
        esys: (np.ndarray, np.ndarray) = None,
    ) -> np.ndarray:
        """
        Exact wavefunction for the heavy fluxonium.
        
        Parameters
        ----------
        x_array : np.ndarray
            Grid of phi values to evaluate the wavefunctions at.
        truncated_dim : int
            Number of energy eigenstates to include.
        cutoff : int
            Cutoff for the fluxonium.
        num_components : int
            Number of non-zero components to keep in the state vector.
        esys : (np.ndarray, np.ndarray)
            Eigenvalues and eigenvectors of the fluxonium. This is 
            solely used for speeding up the computation if repeated calls 
            are made.
            
        Returns
        -------
        np.ndarray
            Exact wavefunction, shape: (len(x_array),).
        """
        wf_list = self._fluxonium_wavefunctions(
            truncated_dim=truncated_dim, 
            cutoff=cutoff, 
            x_array=x_array,
            esys=esys,
        )
        
        state_vector = self.state_vector_exact(
            truncated_dim=truncated_dim, 
            cutoff=cutoff, 
            x_array=x_array, 
            num_components=num_components,
            esys=esys,
        )
        
        return np.dot(wf_list.T, state_vector)
    
    def plot_wavefunction(
        self,
        ax: plt.Axes = None,
        x_array: np.ndarray = None,
        scale: float = 1.0,
        shift: float = 0.0,
        exact_wf_dim: int = 6,
        exact_wf_num_comp: int = 2,
        exact_wf_cutoff: int = 220,
    ):
        """
        Plot the wavefunction.
        """
        ax = super().plot_wavefunction(
            ax=ax,
            x_array=x_array,
            scale=scale,
            shift=shift,
        )
        
        if x_array is None:
            x_array = self._default_x_array()
            
        wf_exact = self.wavefunction_exact(
            x_array,
            truncated_dim=exact_wf_dim,
            cutoff=exact_wf_cutoff,
            num_components=exact_wf_num_comp,
        )
        
        colors = color_palettes["PGL"]
        ax.plot(
            x_array, 
            wf_exact.real * scale + shift, 
            color=colors[4], 
            linestyle="--", 
            zorder=-10,
            label="Exact wavefunction",
        )
        
        return ax
        
    def plot(
        self,
        ax: plt.Axes = None,
        wavefunction_scale: float = 1.0,
        x_array: np.ndarray = None,
        exact_wf_dim: int = 6,
        exact_wf_num_comp: int = 2,
    ):
        """
        Plot the potential and the wavefunction.
        """
        ax = self.plot_potential(ax=ax, x_array=x_array)
        
        energy = self.energy()
        ax = self.plot_wavefunction(
            ax=ax, 
            x_array=x_array, 
            scale=wavefunction_scale,
            shift=energy,
            exact_wf_dim=exact_wf_dim,
            exact_wf_num_comp=exact_wf_num_comp,
        )
        return ax
    
    def copy(self) -> "HeavyFlxnWKB":
        """
        Create a copy of the HeavyFlxnWKB object.
        
        Returns
        -------
        HeavyFlxnWKB
            A new HeavyFlxnWKB object with the same parameters.
        """
        return HeavyFlxnWKB(
            EJ=self._EJ,
            EC=self._EC,
            EL=self._EL,
            flux=self._flux,
            minimum_loc=self._minimum_loc,
            lvl=self.lvl,
            refine_minimum=False,  # Use already refined minimum_loc
        )
    
class DoubleWellHeavyFlxn:

    def __init__(
        self, 
        EJ, 
        EC, 
        EL, 
        flux, 
        max_lvl,
        loc_1=np.pi, 
        loc_2=-np.pi
    ):
        """
        A subsystem of fluxonium qubit with states localized in two 
        selected potential wells.
        
        Parameters
        ----------
        EJ : float
            Josephson energy (unit: GHz).
        EC : float
            Charging energy (unit: GHz).
        EL : float
            Inductance energy (unit: GHz).
        flux : float
            Flux through the fluxonium (unit: Phi_0).
        max_lvl : int
            Number of energy eigenstates to include.
        loc_1 : float
            Location of the potential local minimum for the first well (unit: Phi_0 / 2pi).
        loc_2 : float
            Location of the potential local minimum for the second well (unit: Phi_0 / 2pi).
            Note the unit is different from flux parameter by a factor of 2pi!
        """
        
        self.EJ = EJ
        self.EC = EC
        self.EL = EL
        self.flux = flux
        self.loc_1 = loc_1
        self.loc_2 = loc_2
        self.max_lvl = max_lvl
        
    def build_approximated_system(self):
        self.build_wkb_list()
        self.build_hamiltonian()
        self.build_x_op()
        self.build_op_in_eigenbasis()
        self.build_p_op_in_eigenbasis()
        
    def build_exact_system(
        self, 
        truncated_dim: int = 12, 
        cutoff: int = 220,
        num_components: int = 2,
        warning_threshold: float = 1e-3,
    ):
        self.build_exact_flxn(truncated_dim=truncated_dim, cutoff=cutoff)
        self.find_exact_state_label(num_components=num_components, warning_threshold=warning_threshold)
        self.build_exact_ops()
        
    def build_wkb_list(self):
        levels = list(range(self.max_lvl))
        self.wkb_list_1 = [
            HeavyFlxnWKB(
                EJ=self.EJ,
                EC=self.EC,
                EL=self.EL,
                flux=self.flux,
                minimum_loc=self.loc_1,
                lvl=lvl,
            )
            for lvl in levels
        ]

        self.wkb_list_2 = [
            HeavyFlxnWKB(
                EJ=self.EJ,
                EC=self.EC,
                EL=self.EL,
                flux=self.flux,
                minimum_loc=self.loc_2,
                lvl=lvl,
            )
            for lvl in levels
        ]
        
    def build_hamiltonian(self):
        levels = list(range(self.max_lvl))
        ham = np.zeros((2*self.max_lvl, 2*self.max_lvl), dtype=complex)

        # self-energies
        for lvl in levels:
            ham[lvl, lvl] = self.wkb_list_1[lvl].energy()
            ham[lvl + self.max_lvl, lvl + self.max_lvl] = self.wkb_list_2[lvl].energy()

        # coupling energies
        for lvl_1 in levels:
            for lvl_2 in levels:
                
                wkb_1 = self.wkb_list_1[lvl_1]
                wkb_2 = self.wkb_list_2[lvl_2]
                
                g = wkb_1.coupling_strength(wkb_2)
                
                ham[lvl_1, lvl_2 + self.max_lvl] = g
                ham[lvl_2 + self.max_lvl, lvl_1] = g.conj()
            
        self.hamiltonian = qt.Qobj(ham)
        
    def build_x_op(self):
        levels = list(range(self.max_lvl))
        x_op = np.zeros((2*self.max_lvl, 2*self.max_lvl), dtype=complex)

        # diagonal terms
        for lvl in levels:
            x_op[lvl, lvl] = self.wkb_list_1[lvl].minimum_loc
            x_op[lvl + self.max_lvl, lvl + self.max_lvl] = self.wkb_list_2[lvl].minimum_loc

        # couplings
        zpf_1 = self.wkb_list_1[0].x_zpf()
        zpf_2 = self.wkb_list_2[0].x_zpf()
        for lvl in levels[1:]:
            x_op[lvl, lvl-1] = zpf_1 * np.sqrt(lvl)
            x_op[lvl-1, lvl] = zpf_1 * np.sqrt(lvl)
            x_op[lvl + self.max_lvl, lvl-1 + self.max_lvl] = zpf_2 * np.sqrt(lvl)
            x_op[lvl-1 + self.max_lvl, lvl + self.max_lvl] = zpf_2 * np.sqrt(lvl)

        self.x_op = qt.Qobj(x_op)

    def build_op_in_eigenbasis(self):
        evals, evecs = self.hamiltonian.eigenstates(2*self.max_lvl)

        # reorder based on bare states
        max_entries = [np.argmax(np.abs(evec.full().ravel())) for evec in evecs]
        order = np.argsort(max_entries)

        evals = evals[order]
        evecs = evecs[order]

        trans_op = trans_by_kets(evecs)
        ham_eig = trans_op.dag() * self.hamiltonian * trans_op
        x_op_eig = trans_op.dag() * self.x_op * trans_op

        self.hamiltonian_eig = ham_eig
        self.x_op_eig = x_op_eig
        
    def build_p_op_in_eigenbasis(self):
        p_op_eig = np.zeros((2*self.max_lvl, 2*self.max_lvl), dtype=complex)

        mass = self.wkb_list_1[0].mass

        # couplings
        for lvl_full_1 in range(2*self.max_lvl):
            for lvl_full_2 in range(lvl_full_1 + 1, 2*self.max_lvl):
                energy_1 = self.hamiltonian_eig[lvl_full_1, lvl_full_1]
                energy_2 = self.hamiltonian_eig[lvl_full_2, lvl_full_2]
                
                x_mat_elem = self.x_op_eig[lvl_full_1, lvl_full_2]
                p_mat_elem = (
                    1j * mass 
                    * (energy_2 - energy_1)
                    * x_mat_elem
                )
                p_op_eig[lvl_full_1, lvl_full_2] = p_mat_elem
                p_op_eig[lvl_full_2, lvl_full_1] = p_mat_elem.conj()

        self.p_op_eig = qt.Qobj(p_op_eig)
        
    def build_exact_flxn(
        self, 
        truncated_dim: int = 12, 
        cutoff: int = 220,
    ):
        
        self.exact_flxn = scq.Fluxonium(
            EJ=self.EJ,
            EC=self.EC,
            EL=self.EL,
            flux=self.flux,
            cutoff=cutoff,
            truncated_dim=truncated_dim
        )
        self.exact_esys = self.exact_flxn.eigensys(truncated_dim)
        
    def find_exact_state_label(
        self, 
        num_components: int = 2,
        warning_threshold: float = 1e-2,
    ):
        self.exact_state_label_1 = []
        self.exact_state_label_2 = []
        for idx, wkb in enumerate(self.wkb_list_1):
            comp = wkb.state_vector_exact(
                truncated_dim=self.exact_flxn.truncated_dim,
                cutoff=self.exact_flxn.cutoff,
                num_components=num_components,
                esys=self.exact_esys,
            )
            comp = np.abs(comp)**2
            if np.sum(comp > warning_threshold) > 1:
                warnings.warn(
                    f"The #{idx} localized WKB state in well 1 is a "
                    "superposition of multiple exact eigenstates."
                )
            self.exact_state_label_1.append(np.argmax(comp))
            
        for idx, wkb in enumerate(self.wkb_list_2):
            comp = wkb.state_vector_exact(
                truncated_dim=self.exact_flxn.truncated_dim,
                cutoff=self.exact_flxn.cutoff,
                num_components=num_components,
                esys=self.exact_esys,
            )
            comp = np.abs(comp)**2
            if np.sum(comp > warning_threshold) > 1:
                warnings.warn(
                    f"The #{idx} localized WKB state in well 2 is a "
                    "superposition of multiple exact eigenstates."
                )
            self.exact_state_label_2.append(np.argmax(comp))
            
    def build_exact_ops(self):
        # x Matrix element
        _phi_op_exact = self.exact_flxn.phi_operator(energy_esys=self.exact_esys)
        _n_op_exact = self.exact_flxn.n_operator(energy_esys=self.exact_esys)

        M = self.max_lvl
        idx1 = np.array(self.exact_state_label_1)
        idx2 = np.array(self.exact_state_label_2)

        phi_op_submat = np.zeros((2*M, 2*M), dtype=complex)
        n_op_submat = np.zeros((2*M, 2*M), dtype=complex)

        # Fill 2x2 block matrix using fancy indexing
        for op_sub, _op in [
            (phi_op_submat, _phi_op_exact), 
            (n_op_submat, _n_op_exact)
        ]:
            op_sub[:M, :M] = _op[np.ix_(idx1, idx1)]      # well 1 intra-coupling
            op_sub[M:, M:] = _op[np.ix_(idx2, idx2)]      # well 2 intra-coupling
            op_sub[:M, M:] = _op[np.ix_(idx1, idx2)]      # inter-well coupling
            op_sub[M:, :M] = _op[np.ix_(idx2, idx1)]

        self.x_op_eig_exact = qt.Qobj(phi_op_submat)
        self.p_op_eig_exact = qt.Qobj(n_op_submat)