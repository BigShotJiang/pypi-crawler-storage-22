__all__ = [
    "CpuLimit",
]

import contextlib
import importlib
import importlib.util
import os
from typing import Dict, Optional

_threadpool_limits = None
_threadpool_spec = importlib.util.find_spec("threadpoolctl")
if _threadpool_spec is not None and _threadpool_spec.loader is not None:  # pragma: no cover - optional dependency
    threadpoolctl = importlib.util.module_from_spec(_threadpool_spec)
    assert threadpoolctl is not None  # for type checkers
    _threadpool_spec.loader.exec_module(threadpoolctl)  # type: ignore[attr-defined]
    _threadpool_limits = getattr(threadpoolctl, "threadpool_limits", None)


class CpuLimit:
    """Context manager that restricts CPU-bound libraries to a fixed thread count."""

    _ENV_VARS = (
        "OMP_NUM_THREADS",
        "MKL_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "JAX_NUM_THREADS",
    )

    def __init__(self, num_cpus: int) -> None:
        if num_cpus <= 0:
            raise ValueError("num_cpus must be a positive integer")
        self._num_cpus = num_cpus
        self._saved_env: Dict[str, Optional[str]] = {}
        self._threadpool_ctx: Optional[contextlib.AbstractContextManager[None]] = None

    def __enter__(self) -> "CpuLimit":
        for env_var in self._ENV_VARS:
            self._saved_env[env_var] = os.environ.get(env_var)
            os.environ[env_var] = str(self._num_cpus)

        if _threadpool_limits is not None:
            self._threadpool_ctx = _threadpool_limits(self._num_cpus)
            self._threadpool_ctx.__enter__()  # type: ignore[attr-defined]

        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._threadpool_ctx is not None:
            self._threadpool_ctx.__exit__(exc_type, exc, tb)  # type: ignore[attr-defined]

        for env_var, previous in self._saved_env.items():
            if previous is None:
                os.environ.pop(env_var, None)
            else:
                os.environ[env_var] = previous
