{{ "`" + name + "`" }}
{{ "=" * (name | length + 2) }}

.. currentmodule:: {{ module }}

.. autoattribute:: {{ objname }}
