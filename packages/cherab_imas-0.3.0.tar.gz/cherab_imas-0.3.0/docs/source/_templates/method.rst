{{ "`" + name + "()`" }}
{{ "=" * (name | length + 4) }}

.. currentmodule:: {{ module }}

.. automethod:: {{ objname }}