# API Reference

This page contains auto-generated API reference documentation.

```{eval-rst}
.. autosummary::
   :toctree: _api/
   :recursive:
   :template: module.rst

   cherab.imas
```
