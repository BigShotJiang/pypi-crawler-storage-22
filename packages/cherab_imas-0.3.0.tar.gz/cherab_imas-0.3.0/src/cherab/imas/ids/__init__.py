"""Subpackage for handling IMAS IDS related data."""
