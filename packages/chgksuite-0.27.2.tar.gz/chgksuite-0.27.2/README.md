# chgksuite

Система для работы с пакетами ЧГК.

Документация: https://chgksuite.pecheny.me

Последняя версия в релизах: https://gitlab.com/peczony/chgksuite/-/releases