import os
import subprocess
import sys

import click

from chibi.config_generator import CONFIG_PATH, generate_default_config
from chibi.service import Service


def _get_service() -> Service:
    """Get an instance of the Service class.

    Returns:
        Service: Initialized service instance.
    """
    return Service()


@click.group()
def main() -> None:
    """Chibi CLI for managing the bot service."""
    pass


@main.command()
def start() -> None:
    """Start the Chibi bot service as a daemon."""
    service = _get_service()
    service.start()


@main.command()
def stop() -> None:
    """Stop the running Chibi bot service."""
    service = _get_service()
    service.stop()


@main.command()
def restart() -> None:
    """Restart the Chibi bot service."""
    service = _get_service()
    service.restart()


@main.command()
def config() -> None:
    """Open the Chibi configuration file in the default editor."""
    if not os.path.exists(CONFIG_PATH):
        click.echo("Creating default configuration...")
        generate_default_config()

    editor = os.environ.get("EDITOR", "vi")
    try:
        result = subprocess.call([editor, CONFIG_PATH])
        if result != 0:
            click.echo("Warning: Editor exited with non-zero status.", err=True)
    except FileNotFoundError:
        click.echo(f"Error: Editor '{editor}' not found.", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error opening editor: {e}", err=True)
        sys.exit(1)


@main.command()
def logs() -> None:
    """Tail the Chibi log file."""
    service = _get_service()
    log_path = service.log_path

    if not os.path.exists(log_path):
        click.echo(f"Log file {log_path} does not exist yet. Start the service first.")
        sys.exit(1)

    try:
        subprocess.call(["tail", "-n", "50", "-f", log_path])
    except KeyboardInterrupt:
        click.echo("\nLog tailing stopped.")
    except FileNotFoundError:
        click.echo("Error: 'tail' command not found.", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error tailing logs: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
