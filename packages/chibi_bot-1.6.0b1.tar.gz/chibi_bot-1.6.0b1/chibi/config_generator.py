import os
import shutil
from pathlib import Path

CHIBI_BOT_DIR = Path.home() / "chibi-bot"
DATA_DIR = CHIBI_BOT_DIR / "data"
SKILLS_DIR = CHIBI_BOT_DIR / "skills"
HOME_DIR = CHIBI_BOT_DIR / "home"

CONFIG_PATH = os.path.expanduser("~/.chibi/settings")

DEFAULT_CONFIG = """# Chibi Configuration File
# This file contains all environment variables supported by Chibi.
# Uncomment and set values as needed.

# ============================================================================
# CRITICAL - Required for basic operation
# ============================================================================

# Telegram bot token (REQUIRED)
# Get one from @BotFather on Telegram
TELEGRAM_BOT_TOKEN=

# ============================================================================
# IMPORTANT - At least one LLM API key is required
# ============================================================================

# OpenAI API key (for GPT-4, GPT-4o, etc.)
# OPENAI_API_KEY=

# Anthropic API key (for Claude models)
# ANTHROPIC_API_KEY=

# Google Gemini API key
# GEMINI_API_KEY=

# DeepSeek API key
# DEEPSEEK_API_KEY=

# Alibaba API key
# ALIBABA_API_KEY=

# Cloudflare API key
# CLOUDFLARE_API_KEY=

# Cloudflare account ID
# CLOUDFLARE_ACCOUNT_ID=

# Custom OpenAI API key
# CUSTOMOPENAI_API_KEY=

# Custom OpenAI URL (default: http://localhost:1234/v1)
CUSTOMOPENAI_URL=http://localhost:1234/v1

# Grok API key
# GROK_API_KEY=

# Mistral AI API key
# MISTRALAI_API_KEY=

# Moonshot AI API key
# MOONSHOTAI_API_KEY=

# MiniMax API key
# MINIMAX_API_KEY=

# Suno API key (for music generation)
# SUNO_API_ORG_API_KEY=

# ElevenLabs API key (for text-to-speech)
# ELEVEN_LABS_API_KEY=

# ============================================================================
# IMPORTANT - Storage configuration
# ============================================================================

# Redis connection URL (optional, for caching)
# redis=

# Redis password (optional)
# redis_password=

# AWS region for DynamoDB
# aws_region=

# AWS access key ID
# aws_access_key_id=

# AWS secret access key
# aws_secret_access_key=

# DynamoDB table name for users
# ddb_users_table=

# DynamoDB table name for messages
# ddb_messages_table=

# Local storage path (default: ~/chibi-bot/data)
local_data_path=~/chibi-bot/data

# ============================================================================
# IMPORTANT - Model and feature settings
# ============================================================================

# Hide model options in UI (default: false)
hide_models=false

# Hide imagine commands (default: false)
hide_imagine=false

# Monthly image generation limit (default: 0, unlimited)
IMAGE_GENERATIONS_LIMIT=0

# Comma-separated image generation whitelist (optional)
# IMAGE_GENERATIONS_WHITELIST=

# Comma-separated models whitelist (optional)
# MODELS_WHITELIST=

# Comma-separated tools whitelist (optional)
# TOOLS_WHITELIST=

# ============================================================================
# OPTIONAL - Directory settings
# ============================================================================

# AI agent home directory (default: ~/chibi-bot/home)
home_dir=~/chibi-bot/home

# AI agent working directory (default: ~/chibi-bot/home)
working_dir=~/chibi-bot/home

# Absolute path to directory with skills
skills_dir=~/chibi-bot/skills

# ============================================================================
# OPTIONAL - MCP configuration
# ============================================================================

# Enable MCP SSE (default: true)
enable_mcp_sse=true

# Enable MCP stdio (default: false)
enable_mcp_stdio=false

# ============================================================================
# OPTIONAL - Heartbeat monitoring
# ============================================================================

# Heartbeat check URL (optional)
# heartbeat_url=

# Heartbeat frequency in seconds (default: 60, minimum: 30)
heartbeat_frequency_call=60

# Heartbeat retry count (default: 3)
heartbeat_retry_calls=3

# Heartbeat proxy URL (optional)
# heartbeat_proxy=

# ============================================================================
# OPTIONAL - InfluxDB metrics
# ============================================================================

# InfluxDB URL (optional)
# influxdb_url=

# InfluxDB token (optional)
# influxdb_token=

# InfluxDB organization (optional)
# influxdb_org=

# InfluxDB bucket (optional)
# influxdb_bucket=

# ============================================================================
# OPTIONAL - Logging and debugging
# ============================================================================

# Log prompt data (default: false)
log_prompt_data=false

# ============================================================================
# OPTIONAL - Telegram settings
# ============================================================================

# Comma-separated group IDs whitelist (optional)
# GROUPS_WHITELIST=

# Comma-separated user IDs whitelist (optional)
# USERS_WHITELIST=
"""


def generate_default_config() -> None:
    """Generate default configuration file if it doesn't exist."""
    config_dir = os.path.dirname(CONFIG_PATH)
    Path(config_dir).mkdir(parents=True, exist_ok=True)

    if not os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "w") as config_file:
                config_file.write(DEFAULT_CONFIG)
            print(f"Created default configuration at {CONFIG_PATH}")
        except IOError as e:
            print(f"Error creating configuration file: {e}")

    # Create directory structure
    try:
        for directory in [CHIBI_BOT_DIR, DATA_DIR, SKILLS_DIR, HOME_DIR]:
            if not directory.exists():
                directory.mkdir(parents=True, exist_ok=True)
                print(f"Created directory: {directory}")
    except IOError as e:
        print(f"Error creating directories: {e}")

    # Sync Skills
    package_skills_dir = Path(__file__).parent.parent / "skills"
    if package_skills_dir.exists():
        try:
            synced_count = 0
            for skill_file in package_skills_dir.iterdir():
                if skill_file.is_file():
                    target_path = SKILLS_DIR / skill_file.name
                    if not target_path.exists():
                        shutil.copy2(skill_file, target_path)
                        synced_count += 1
            if synced_count > 0:
                print(f"Synced {synced_count} skills to {SKILLS_DIR}")
        except IOError as e:
            print(f"Error syncing skills: {e}")
