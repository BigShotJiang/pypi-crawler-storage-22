import os
import signal
import subprocess
import sys
from pathlib import Path
from typing import Optional

from dotenv import dotenv_values


class Service:
    """Service management for the Chibi bot."""

    def __init__(
        self,
        pid_path: Optional[str] = None,
        log_path: Optional[str] = None,
    ) -> None:
        """Initialize service with PID and log paths.

        Args:
            pid_path: Path to PID file. Defaults to ~/.chibi/chibi.pid.
            log_path: Path to log file. Defaults to ~/.chibi/logs/chibi.log.
        """
        home = Path.home()
        self.pid_path = pid_path or str(home / ".chibi" / "chibi.pid")
        self.log_path = log_path or str(home / ".chibi" / "logs" / "chibi.log")
        self.settings_path = home / "chibi-bot" / "settings"

    def _ensure_directories(self) -> None:
        """Ensure required directories exist."""
        Path(self.log_path).parent.mkdir(parents=True, exist_ok=True)
        Path(self.pid_path).parent.mkdir(parents=True, exist_ok=True)

    def _is_process_running(self, pid: int) -> bool:
        """Check if a process with the given PID is still running.

        Args:
            pid: Process ID to check.

        Returns:
            True if process is running, False otherwise.
        """
        try:
            os.kill(pid, 0)  # Signal 0 doesn't kill, just checks if process exists
            return True
        except (OSError, ProcessLookupError):
            return False

    def _read_pid(self) -> Optional[int]:
        """Read PID from PID file.

        Returns:
            PID if file exists and is valid, None otherwise.
        """
        if not os.path.exists(self.pid_path):
            return None
        try:
            with open(self.pid_path, "r") as pid_file:
                return int(pid_file.read().strip())
        except (ValueError, IOError):
            return None

    def _write_pid(self, pid: int) -> None:
        """Write PID to PID file atomically.

        Args:
            pid: Process ID to write.
        """
        with open(self.pid_path, "w") as pid_file:
            pid_file.write(str(pid))

    def start(self) -> None:
        """Start the bot service in background."""
        self._ensure_directories()

        pid = self._read_pid()
        if pid is not None and self._is_process_running(pid):
            print(f"Service is already running (PID: {pid}).")
            return

        # Clean up stale PID file if process is not running
        if os.path.exists(self.pid_path):
            try:
                os.remove(self.pid_path)
            except OSError:
                pass

        envs = os.environ.copy()

        if self.settings_path.exists():
            settings = dotenv_values(self.settings_path)
            envs.update(settings)

        try:
            # Start the bot process in background
            with open(self.log_path, "a") as log_file:
                process = subprocess.Popen(
                    [sys.executable, "-m", "chibi"],
                    stdout=log_file,
                    stderr=log_file,
                    start_new_session=True,  # Create new process group (Unix)
                    env=envs,
                )
                self._write_pid(process.pid)
            print(f"Service started (PID: {process.pid}).")
        except Exception as e:
            print(f"Error starting service: {e}")

    def stop(self) -> None:
        """Stop the bot service."""
        pid = self._read_pid()

        if pid is None:
            print("Service is not running.")
            return

        if not self._is_process_running(pid):
            print("Service is not running (stale PID file removed).")
            try:
                os.remove(self.pid_path)
            except OSError:
                pass
            return

        try:
            os.kill(pid, signal.SIGTERM)
            print(f"Service stopped (PID: {pid}).")
            try:
                os.remove(self.pid_path)
            except OSError:
                pass
        except ProcessLookupError:
            print("Service process not found.")
            try:
                os.remove(self.pid_path)
            except OSError:
                pass
        except Exception as e:
            print(f"Error stopping service: {e}")

    def restart(self) -> None:
        """Restart the bot service."""
        self.stop()
        self.start()
