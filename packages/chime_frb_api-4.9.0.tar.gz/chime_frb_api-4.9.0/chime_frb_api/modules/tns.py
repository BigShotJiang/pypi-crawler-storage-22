#!/usr/bin/env python
"""CHIME/FRB TNS API."""

import logging
from typing import Any, Dict

import requests

from chime_frb_api.core import API

log = logging.getLogger(__name__)


class TNS(API):
    """CHIME/FRB TNS API.

    Submit CHIME/FRB data to the Transient Name Server (TNS) for acquiring
    official TNS object names for CHIME/FRB events, and
    for searching the official TNS object name of an
    inputted CHIME/FRB event number.
    """

    def __init__(self, API: API):
        """CHIME/FRB TNS API Initialization."""
        self.API = API

    def _bool_param(self, value: bool) -> str:
        return "true" if value else "false"

    def _handle_error(self, error: Exception) -> Dict[str, Any]:
        response = getattr(error, "response", None)
        if response is not None:
            try:
                data = response.json()
            except Exception:
                data = {"message": getattr(response, "text", "")}
            return {
                "success": False,
                "status_code": response.status_code,
                "error": data,
            }
        return {"success": False, "error": str(error)}

    def submit(
        self,
        event_number: int,
        period: int,
        sandbox: bool = True,
        force: bool = False,
    ) -> Dict[str, Any]:
        """Submit CHIME/FRB event to TNS.

        Args:
            event_number: CHIME/FRB event number.
            period: Proprietary period in years.
            sandbox: If True, submit to sandbox TNS. If False, submit to live TNS.
            force: If True, submit even if a TNS name already exists.

        Returns:
            Dict response from the server.
        """
        if not isinstance(event_number, int):
            raise ValueError("event_number must be an integer")
        if not isinstance(period, int):
            raise ValueError("period must be an integer")

        if not force:
            search_response = self.search(
                event_number=event_number, sandbox=sandbox
            )
            tns_name = search_response.get("tns_name")
            if search_response.get("success") and tns_name not in (
                None,
                "UNKNOWN",
            ):
                log.info(
                    f"Event {event_number} already has TNS name {tns_name}. Submission aborted."
                )
                return {
                    "success": False,
                    "tns_name": tns_name,
                    "message": (
                        f"Event {event_number} already has TNS name {tns_name}. "
                        "Set force=True to resubmit."
                    ),
                    "requires_force": True,
                }

        if not sandbox:
            log.info(f"Submitting CHIME/FRB event {event_number} to live TNS")
        else:
            log.info(
                f"Submitting CHIME/FRB event {event_number} to sandbox TNS"
            )

        url = (
            f"/v2/tns/submit/{event_number}"
            f"?sandbox={self._bool_param(sandbox)}&period={period}"
        )

        try:
            return self.API.post(url)
        except requests.exceptions.RequestException as error:
            return self._handle_error(error)

    def search(
        self, event_number: int, sandbox: bool = False
    ) -> Dict[str, Any]:
        """Search TNS for a CHIME/FRB event by internal name.

        Args:
            event_number: Internal CHIME/FRB event number.
            sandbox: If True, search sandbox TNS. If False, search live TNS.

        Returns:
            Dict response from the server.
        """
        if not isinstance(event_number, int):
            raise ValueError("event_number must be an integer")

        if sandbox:
            log.info(
                f"Searching Sandbox TNS Service for CHIME/FRB event {event_number}"
            )
        else:
            log.info(f"Searching LIVE TNS for CHIME/FRB event {event_number}")

        url = (
            f"/v2/tns/search/{event_number}?sandbox={self._bool_param(sandbox)}"
        )
        try:
            return self.API.get(url)
        except requests.exceptions.RequestException as error:
            return self._handle_error(error)

    def change(
        self,
        tns_name: str,
        end_prop_period_date: str,
        sandbox: bool = True,
    ) -> Dict[str, Any]:
        """Change TNS proprietary period end date for an FRB.

        Args:
            tns_name: TNS object name (e.g., FRBYYYYMMDDX).
            end_prop_period_date: New end date (YYYY-MM-DD).
            sandbox: If True, target sandbox TNS. If False, target live TNS.
        Returns:
            Dict response from the server.
        """
        if not isinstance(tns_name, str) or not tns_name:
            raise ValueError("tns_name must be a non-empty string")
        if (
            not isinstance(end_prop_period_date, str)
            or not end_prop_period_date
        ):
            raise ValueError("end_prop_period_date must be a non-empty string")

        payload: Dict[str, Any] = {
            "objname": tns_name,
            "groupid": 86,
            "end_prop_period_date": end_prop_period_date,
            "frb_flag": 1,
        }

        if sandbox:
            log.info(
                f"Changing TNS proprietary period end date for {tns_name} to {end_prop_period_date} in Sandbox TNS"
            )
        else:
            log.info(
                f"Changing TNS proprietary period end date for {tns_name} to {end_prop_period_date} in LIVE TNS"
            )

        url = f"/v2/tns/change?sandbox={self._bool_param(sandbox)}"
        try:
            return self.API.post(url, json=payload)
        except requests.exceptions.RequestException as error:
            return self._handle_error(error)
