#!/usr/bin/env python

import pytest
import requests

from chime_frb_api.modules.tns import TNS


class DummyAPI:
    def __init__(self):
        self.calls = []

    def post(self, url: str, **kwargs):
        self.calls.append(("post", url, kwargs))
        return {"ok": True}

    def get(self, url: str, **kwargs):
        self.calls.append(("get", url, kwargs))
        return {"ok": True}


def test_submit_builds_url():
    api = DummyAPI()
    tns = TNS(api)
    resp = tns.submit(event_number=1, period=5, sandbox=True)
    assert resp == {"ok": True}
    assert api.calls[0][0] == "get"
    assert api.calls[0][1] == "/v2/tns/search/1?sandbox=true"
    assert api.calls[1][0] == "post"
    assert api.calls[1][1] == "/v2/tns/submit/1?sandbox=true&period=5"


def test_search_builds_url():
    api = DummyAPI()
    tns = TNS(api)
    resp = tns.search(event_number=123, sandbox=False)
    assert resp == {"ok": True}
    assert api.calls[0][1] == "/v2/tns/search/123?sandbox=false"


def test_change_payload():
    api = DummyAPI()
    tns = TNS(api)
    resp = tns.change(
        tns_name="FRB20191220F",
        end_prop_period_date="2030-01-01",
        sandbox=True,
    )
    assert resp == {"ok": True}
    method, url, kwargs = api.calls[0]
    assert method == "post"
    assert url == "/v2/tns/change?sandbox=true"
    assert kwargs["json"]["objname"] == "FRB20191220F"
    assert kwargs["json"]["groupid"] == 86
    assert kwargs["json"]["end_prop_period_date"] == "2030-01-01"
    assert kwargs["json"]["frb_flag"] == 1


def test_error_handling_on_http_error():
    class ErrorAPI(DummyAPI):
        def post(self, url: str, **kwargs):
            response = requests.Response()
            response.status_code = 500
            response._content = b'{"message":"fail"}'
            raise requests.exceptions.HTTPError("fail", response=response)

    api = ErrorAPI()
    tns = TNS(api)
    resp = tns.submit(event_number=1, period=5, sandbox=True, force=True)
    assert resp["success"] is False
    assert resp["status_code"] == 500
    assert resp["error"]["message"] == "fail"


def test_submit_invalid_types():
    api = DummyAPI()
    tns = TNS(api)
    with pytest.raises(ValueError):
        tns.submit(event_number="1", period=5, sandbox=True)
    with pytest.raises(ValueError):
        tns.submit(event_number=1, period="5", sandbox=True)


def test_submit_requires_force_when_tns_exists():
    class FoundAPI(DummyAPI):
        def get(self, url: str, **kwargs):
            self.calls.append(("get", url, kwargs))
            return {"success": True, "tns_name": "FRB20191220F"}

    api = FoundAPI()
    tns = TNS(api)
    resp = tns.submit(event_number=1, period=5, sandbox=True)
    assert resp["success"] is False
    assert resp["requires_force"] is True
    assert resp["tns_name"] == "FRB20191220F"
    assert len(api.calls) == 1
