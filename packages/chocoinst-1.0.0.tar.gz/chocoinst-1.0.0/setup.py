from setuptools import setup, find_packages

setup(
    name="chocoinst",
    version="1.0.0",
    author="Марк",
    author_email="deepseek748@gmail.com",
    description="🍫 ChocoInst - Установка программ через Chocolatey",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/Marrcus113/ChocoInst",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
    ],
    python_requires=">=3.8",
    install_requires=[
        "py-chocolatey>=0.4.1",
    ],
    entry_points={
        "console_scripts": [
            "chocoinst=chocoinst.cli:main",
        ],
    },
)