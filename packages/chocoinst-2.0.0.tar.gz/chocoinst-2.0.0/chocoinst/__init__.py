"""🍫 ChocoInst - Установка программ через Chocolatey"""

from .core import Chocolatey
from .programs import PROGRAMS

__version__ = "2.0.0"
__author__ = "Марк"