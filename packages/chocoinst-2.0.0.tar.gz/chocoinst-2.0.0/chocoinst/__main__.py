#!/usr/bin/env python
"""
🍫 ChocoInst - Главный файл
"""

import sys
from .menu import run_menu
from .core import Chocolatey

def main():
    if len(sys.argv) == 1:
        # Если без аргументов - запускаем меню
        run_menu()
    else:
        # Если с аргументами - работаем как CLI
        choco = Chocolatey()
        cmd = sys.argv[1]
        
        if cmd == 'install' and len(sys.argv) > 2:
            result = choco.install(sys.argv[2])
            print(result['stdout'] if result['success'] else result.get('stderr', 'Ошибка'))
        
        elif cmd == 'uninstall' and len(sys.argv) > 2:
            result = choco.uninstall(sys.argv[2])
            print(result['stdout'] if result['success'] else result.get('stderr', 'Ошибка'))
        
        elif cmd == 'list':
            packages = choco.list_local()
            for pkg in packages:
                print(pkg)
        
        elif cmd == 'search' and len(sys.argv) > 2:
            results = choco.search(sys.argv[2])
            for r in results:
                print(r)
        
        elif cmd == 'upgrade':
            result = choco.upgrade(sys.argv[2] if len(sys.argv) > 2 else 'all')
            print(result['stdout'] if result['success'] else result.get('stderr', 'Ошибка'))
        
        else:
            print("🍫 ChocoInst")
            print("Использование:")
            print("  chocoinst              - открыть меню")
            print("  chocoinst install ПАКЕТ")
            print("  chocoinst uninstall ПАКЕТ")
            print("  chocoinst list")
            print("  chocoinst search ЗАПРОС")
            print("  chocoinst upgrade [ПАКЕТ]")

if __name__ == '__main__':
    main()