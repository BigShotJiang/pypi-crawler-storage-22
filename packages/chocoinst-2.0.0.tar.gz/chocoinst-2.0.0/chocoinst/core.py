import subprocess
import os
from typing import List, Dict, Optional

class Chocolatey:
    """Полноценная библиотека для работы с Chocolatey"""
    
    def __init__(self):
        self.choco_path = self._find_choco()
    
    def _find_choco(self) -> str:
        """Ищет chocolatey в системе"""
        try:
            result = subprocess.run(['where', 'choco'], 
                                   capture_output=True, text=True, shell=True)
            if result.returncode == 0:
                return result.stdout.strip().split('\n')[0]
        except:
            pass
        return 'choco'  # надеемся что в PATH
    
    def _run(self, args: List[str]) -> Dict:
        """Запускает команду chocolatey"""
        cmd = [self.choco_path] + args
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, 
                                   timeout=300, shell=True)
            return {
                'success': result.returncode == 0,
                'stdout': result.stdout,
                'stderr': result.stderr,
                'command': ' '.join(cmd)
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    # === ОСНОВНЫЕ КОМАНДЫ ===
    
    def install(self, package: str, version: str = None, force: bool = False) -> Dict:
        """Устанавливает пакет"""
        args = ['install', package, '-y']
        if version:
            args.extend(['--version', version])
        if force:
            args.append('-f')
        return self._run(args)
    
    def uninstall(self, package: str, remove_deps: bool = False) -> Dict:
        """Удаляет пакет"""
        args = ['uninstall', package, '-y']
        if remove_deps:
            args.append('-r')
        return self._run(args)
    
    def upgrade(self, package: str = 'all') -> Dict:
        """Обновляет пакет(ы)"""
        return self._run(['upgrade', package, '-y'])
    
    def list_local(self) -> List[str]:
        """Список установленных пакетов"""
        result = self._run(['list', '--local-only'])
        if result['success']:
            lines = result['stdout'].split('\n')
            packages = []
            for line in lines:
                if line and 'packages installed' not in line and 'Chocolatey v' not in line:
                    packages.append(line.strip())
            return packages
        return []
    
    def search(self, query: str) -> List[str]:
        """Ищет пакеты"""
        result = self._run(['search', query])
        if result['success']:
            return [line.strip() for line in result['stdout'].split('\n') 
                   if line and 'Chocolatey v' not in line]
        return []
    
    def info(self, package: str) -> str:
        """Информация о пакете"""
        result = self._run(['info', package])
        return result['stdout'] if result['success'] else ''
    
    def outdated(self) -> List[str]:
        """Показывает устаревшие пакеты"""
        result = self._run(['outdated'])
        if result['success']:
            return [line.strip() for line in result['stdout'].split('\n') 
                   if line and 'Chocolatey v' not in line]
        return []
    
    def pin(self, package: str) -> Dict:
        """Закрепляет пакет (не обновляется)"""
        return self._run(['pin', 'add', '-n', package])
    
    def unpin(self, package: str) -> Dict:
        """Открепляет пакет"""
        return self._run(['pin', 'remove', '-n', package])
    
    def list_pinned(self) -> List[str]:
        """Список закрепленных пакетов"""
        result = self._run(['pin', 'list'])
        if result['success']:
            return [line.strip() for line in result['stdout'].split('\n') 
                   if line and line != 'No pinned packages.']
        return []
    
    def install_config(self, package: str, config: str) -> Dict:
        """Установка с дополнительной конфигурацией"""
        return self._run(['install', package, '-y', '--params', f"'{config}'"])
    
    def install_with_source(self, package: str, source: str) -> Dict:
        """Установка из конкретного источника"""
        return self._run(['install', package, '-y', '-s', source])
    
    def add_source(self, name: str, source: str) -> Dict:
        """Добавляет источник пакетов"""
        return self._run(['source', 'add', '-n', name, '-s', source])
    
    def remove_source(self, name: str) -> Dict:
        """Удаляет источник"""
        return self._run(['source', 'remove', '-n', name])
    
    def list_sources(self) -> List[str]:
        """Список источников"""
        result = self._run(['source', 'list'])
        if result['success']:
            return [line.strip() for line in result['stdout'].split('\n') 
                   if line and 'Chocolatey v' not in line]
        return []
    
    def export(self, filename: str = 'packages.config') -> Dict:
        """Экспортирует список пакетов в конфиг"""
        return self._run(['export', filename])
    
    def import_config(self, filename: str = 'packages.config') -> Dict:
        """Устанавливает пакеты из конфига"""
        return self._run(['install', filename])
    
    def cache_list(self) -> List[str]:
        """Список пакетов в кэше"""
        result = self._run(['cache', 'list'])
        if result['success']:
            return [line.strip() for line in result['stdout'].split('\n') 
                   if line and 'Chocolatey v' not in line]
        return []
    
    def cache_clear(self) -> Dict:
        """Очищает кэш"""
        return self._run(['cache', 'remove'])
    
    def feature_list(self) -> List[str]:
        """Список доступных функций"""
        result = self._run(['feature', 'list'])
        if result['success']:
            return [line.strip() for line in result['stdout'].split('\n') 
                   if line and 'Chocolatey v' not in line]
        return []
    
    def feature_enable(self, feature: str) -> Dict:
        """Включает функцию"""
        return self._run(['feature', 'enable', '-n', feature])
    
    def feature_disable(self, feature: str) -> Dict:
        """Отключает функцию"""
        return self._run(['feature', 'disable', '-n', feature])
    
    def config_list(self) -> str:
        """Показывает конфигурацию"""
        result = self._run(['config', 'list'])
        return result['stdout'] if result['success'] else ''
    
    def config_set(self, key: str, value: str) -> Dict:
        """Устанавливает значение конфига"""
        return self._run(['config', 'set', key, value])
    
    def config_unset(self, key: str) -> Dict:
        """Удаляет значение из конфига"""
        return self._run(['config', 'unset', key])
    
    def version(self) -> str:
        """Версия chocolatey"""
        result = self._run(['-v'])
        return result['stdout'].strip() if result['success'] else 'unknown'