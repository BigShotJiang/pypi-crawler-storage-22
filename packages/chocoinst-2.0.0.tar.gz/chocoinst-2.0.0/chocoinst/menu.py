import os
import sys
from .core import Chocolatey
from .programs import PROGRAMS, ALL_PROGRAMS

class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RED = '\033[91m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    RESET = '\033[0m'

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header(text):
    width = 60
    print(f"\n{Colors.BLUE}{'='*width}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.YELLOW}{text:^{width}}{Colors.RESET}")
    print(f"{Colors.BLUE}{'='*width}{Colors.RESET}")

def print_menu(options):
    for i, (key, text) in enumerate(options.items(), 1):
        print(f"{Colors.GREEN}{i:2}.{Colors.RESET} {text}")

def get_choice(max_choice):
    while True:
        try:
            choice = input(f"\n{Colors.YELLOW}👉 Выбери (1-{max_choice}, 0 назад): {Colors.RESET}")
            if choice == '0':
                return 0
            choice = int(choice)
            if 1 <= choice <= max_choice:
                return choice
            print(f"{Colors.RED}❌ От 1 до {max_choice}!{Colors.RESET}")
        except ValueError:
            print(f"{Colors.RED}❌ Введи число!{Colors.RESET}")

def show_progress(msg):
    print(f"{Colors.CYAN}⏳ {msg}...{Colors.RESET}")

def show_success(msg):
    print(f"{Colors.GREEN}✅ {msg}{Colors.RESET}")

def show_error(msg):
    print(f"{Colors.RED}❌ {msg}{Colors.RESET}")

def run_menu():
    choco = Chocolatey()
    
    while True:
        clear()
        print_header("🍫 CHOCOINST 2.0")
        print(f"\n{Colors.CYAN}Chocolatey версия: {choco.version()}{Colors.RESET}\n")
        
        main_menu = {
            1: "📦 Установить программу",
            2: "🗑️  Удалить программу",
            3: "📋 Список установленных",
            4: "🔍 Поиск программ",
            5: "⬆️  Обновить программы",
            6: "📁 Категории программ",
            7: "⭐ Популярное",
            8: "⚙️  Дополнительно",
        }
        
        print_menu(main_menu)
        print(f"{Colors.BLUE}{'─'*60}{Colors.RESET}")
        print(f"{Colors.RED}0.{Colors.RESET} 🚪 Выход")
        
        choice = get_choice(len(main_menu))
        if choice == 0:
            print(f"\n{Colors.GREEN}До свидания! 👋{Colors.RESET}")
            break
        
        elif choice == 1:  # Установка
            clear()
            print_header("📦 УСТАНОВКА ПРОГРАММЫ")
            pkg = input("Введи название пакета: ")
            if pkg:
                show_progress(f"Устанавливаю {pkg}")
                result = choco.install(pkg)
                if result['success']:
                    show_success(f"{pkg} установлен!")
                else:
                    show_error(f"Ошибка: {result.get('stderr', 'Неизвестная ошибка')}")
            input("\nНажми Enter...")
        
        elif choice == 2:  # Удаление
            clear()
            print_header("🗑️  УДАЛЕНИЕ ПРОГРАММЫ")
            pkg = input("Что удаляем? ")
            if pkg:
                show_progress(f"Удаляю {pkg}")
                result = choco.uninstall(pkg)
                if result['success']:
                    show_success(f"{pkg} удалён!")
                else:
                    show_error(f"Ошибка: {result.get('stderr', 'Неизвестная ошибка')}")
            input("\nНажми Enter...")
        
        elif choice == 3:  # Список
            clear()
            print_header("📋 УСТАНОВЛЕННЫЕ ПРОГРАММЫ")
            packages = choco.list_local()
            if packages:
                for i, pkg in enumerate(packages, 1):
                    print(f"{Colors.GREEN}{i:3}.{Colors.RESET} {pkg}")
            else:
                print("Ничего не найдено")
            input("\nНажми Enter...")
        
        elif choice == 4:  # Поиск
            clear()
            print_header("🔍 ПОИСК")
            query = input("Что ищем? ")
            if query:
                results = choco.search(query)
                if results:
                    for i, pkg in enumerate(results[:20], 1):  # первые 20
                        print(f"{Colors.GREEN}{i:3}.{Colors.RESET} {pkg}")
                else:
                    print("Ничего не найдено")
            input("\nНажми Enter...")
        
        elif choice == 5:  # Обновление
            clear()
            print_header("⬆️  ОБНОВЛЕНИЕ")
            show_progress("Проверяю обновления")
            outdated = choco.outdated()
            if outdated:
                print("Доступны обновления:")
                for pkg in outdated:
                    print(f"  • {pkg}")
                if input("\nОбновить всё? (y/n): ").lower() == 'y':
                    result = choco.upgrade()
                    if result['success']:
                        show_success("Обновлено!")
            else:
                print("Всё свежее!")
            input("\nНажми Enter...")
        
        elif choice == 6:  # Категории
            while True:
                clear()
                print_header("📁 КАТЕГОРИИ")
                cats = list(PROGRAMS.keys())
                for i, cat in enumerate(cats, 1):
                    print(f"{Colors.GREEN}{i:2}.{Colors.RESET} {cat.upper()}")
                print(f"{Colors.RED}0.{Colors.RESET} Назад")
                
                cat_choice = get_choice(len(cats))
                if cat_choice == 0:
                    break
                
                category = cats[cat_choice-1]
                clear()
                print_header(f"📁 {category.upper()}")
                for i, (pkg, name, desc) in enumerate(PROGRAMS[category], 1):
                    print(f"{Colors.GREEN}{i:2}.{Colors.RESET} {Colors.BOLD}{name}{Colors.RESET}")
                    print(f"     {desc}")
                print(f"\n{Colors.RED}0.{Colors.RESET} Назад")
                
                prog_choice = get_choice(len(PROGRAMS[category]))
                if prog_choice:
                    pkg, name, _ = PROGRAMS[category][prog_choice-1]
                    show_progress(f"Устанавливаю {name}")
                    result = choco.install(pkg)
                    if result['success']:
                        show_success(f"{name} установлен!")
                    input("\nНажми Enter...")
        
        elif choice == 7:  # Популярное
            clear()
            print_header("⭐ ПОПУЛЯРНЫЕ ПРОГРАММЫ")
            for i, (pkg, name, desc) in enumerate(ALL_PROGRAMS[:15], 1):
                print(f"{Colors.GREEN}{i:2}.{Colors.RESET} {Colors.BOLD}{name}{Colors.RESET}")
                print(f"     {desc}")
            print(f"\n{Colors.RED}0.{Colors.RESET} Назад")
            
            prog_choice = get_choice(15)
            if prog_choice:
                pkg, name, _ = ALL_PROGRAMS[prog_choice-1]
                show_progress(f"Устанавливаю {name}")
                result = choco.install(pkg)
                if result['success']:
                    show_success(f"{name} установлен!")
                input("\nНажми Enter...")
        
        elif choice == 8:  # Дополнительно
            clear()
            print_header("⚙️  ДОПОЛНИТЕЛЬНО")
            extra_menu = {
                1: "📦 Кэш пакетов",
                2: "🔗 Источники",
                3: "📌 Закреплённые",
                4: "⚙️ Функции",
                5: "📋 Конфигурация",
            }
            print_menu(extra_menu)
            print(f"{Colors.RED}0.{Colors.RESET} Назад")
            
            extra_choice = get_choice(len(extra_menu))
            if extra_choice == 1:  # Кэш
                clear()
                print_header("📦 КЭШ")
                cache = choco.cache_list()
                if cache:
                    for item in cache:
                        print(f"  • {item}")
                    if input("\nОчистить кэш? (y/n): ").lower() == 'y':
                        choco.cache_clear()
                        show_success("Кэш очищен")
                else:
                    print("Кэш пуст")
                input("\nНажми Enter...")
            
            elif extra_choice == 2:  # Источники
                clear()
                print_header("🔗 ИСТОЧНИКИ")
                sources = choco.list_sources()
                for src in sources:
                    print(f"  • {src}")
                input("\nНажми Enter...")
            
            elif extra_choice == 3:  # Закреплённые
                clear()
                print_header("📌 ЗАКРЕПЛЁННЫЕ")
                pinned = choco.list_pinned()
                if pinned:
                    for p in pinned:
                        print(f"  • {p}")
                else:
                    print("Нет закреплённых")
                input("\nНажми Enter...")
            
            elif extra_choice == 4:  # Функции
                clear()
                print_header("⚙️ ФУНКЦИИ")
                features = choco.feature_list()
                for f in features:
                    print(f"  • {f}")
                input("\nНажми Enter...")
            
            elif extra_choice == 5:  # Конфиг
                clear()
                print_header("📋 КОНФИГУРАЦИЯ")
                print(choco.config_list())
                input("\nНажми Enter...")