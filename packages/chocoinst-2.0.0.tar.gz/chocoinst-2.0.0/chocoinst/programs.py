# Категории программ
PROGRAMS = {
    'browsers': [
        ('googlechrome', 'Google Chrome', '🌐 Самый популярный браузер'),
        ('firefox', 'Firefox', '🦊 Быстрый и безопасный'),
        ('brave', 'Brave', '🛡️ Браузер с блокировкой рекламы'),
        ('opera', 'Opera', '🎮 Со встроенным VPN'),
    ],
    'dev': [
        ('vscode', 'VS Code', '💻 Лучший редактор кода'),
        ('python', 'Python', '🐍 Язык программирования'),
        ('git', 'Git', '📦 Контроль версий'),
        ('nodejs', 'Node.js', '⚡ JavaScript на сервере'),
    ],
    'utils': [
        ('everything', 'Everything', '🚀 Мгновенный поиск файлов'),
        ('7zip', '7-Zip', '🗜️ Работа с архивами'),
        ('vlc', 'VLC', '🎥 Видеоплеер'),
        ('sharex', 'ShareX', '📸 Скриншоты и запись'),
        ('notepadplusplus', 'Notepad++', '📝 Продвинутый блокнот'),
    ],
    'games': [
        ('steam', 'Steam', '🎮 Магазин игр'),
        ('discord', 'Discord', '💬 Общение для геймеров'),
        ('obs-studio', 'OBS Studio', '📺 Запись стримов'),
    ],
    'media': [
        ('spotify', 'Spotify', '🎵 Музыка'),
        ('gimp', 'GIMP', '🎨 Графический редактор'),
        ('audacity', 'Audacity', '🎤 Запись звука'),
    ]
}

# Плоский список всех программ
ALL_PROGRAMS = []
for cat in PROGRAMS.values():
    ALL_PROGRAMS.extend(cat)