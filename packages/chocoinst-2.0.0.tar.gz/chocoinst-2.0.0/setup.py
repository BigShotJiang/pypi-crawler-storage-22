from setuptools import setup, find_packages

setup(
    name="chocoinst",
    version="2.0.0",
    author="Марк",
    author_email="",
    description="🍫 ChocoInst - Установка программ через Chocolatey",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/Marrcus113/ChocoInst",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
    ],
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "chocoinst=chocoinst.__main__:main",
        ],
    },
)