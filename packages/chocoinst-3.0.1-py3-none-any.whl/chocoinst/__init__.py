"""🍫 ChocoInst - Установка программ через Chocolatey"""

from .core import Chocolatey
from .programs import PROGRAMS

__version__ = "3.0.1"
__author__ = "Марк"