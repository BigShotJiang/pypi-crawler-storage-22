import os
import sys
from .core import Chocolatey
from .programs import PROGRAMS, ALL_PROGRAMS

class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RED = '\033[91m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    RESET = '\033[0m'

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header(text):
    width = 60
    print(f"\n{Colors.BLUE}{'='*width}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.YELLOW}{text:^{width}}{Colors.RESET}")
    print(f"{Colors.BLUE}{'='*width}{Colors.RESET}")

def print_menu(options):
    for i, (key, text) in enumerate(options.items(), 1):
        print(f"{Colors.GREEN}{i:2}.{Colors.RESET} {text}")

def get_choice(max_choice):
    while True:
        try:
            choice = input(f"\n{Colors.YELLOW}👉 Выбери (1-{max_choice}, 0 назад): {Colors.RESET}")
            if choice == '0':
                return 0
            choice = int(choice)
            if 1 <= choice <= max_choice:
                return choice
            print(f"{Colors.RED}❌ От 1 до {max_choice}!{Colors.RESET}")
        except ValueError:
            print(f"{Colors.RED}❌ Введи число!{Colors.RESET}")

def show_progress(msg):
    print(f"{Colors.CYAN}⏳ {msg}...{Colors.RESET}")

def show_success(msg):
    print(f"{Colors.GREEN}✅ {msg}{Colors.RESET}")

def show_error(msg):
    print(f"{Colors.RED}❌ {msg}{Colors.RESET}")

def run_menu():
    choco = Chocolatey()
    
    while True:
        clear()
        print_header("🍫 CHOCOINST 3.0")
        print(f"\n{Colors.CYAN}Chocolatey версия: {choco.version()}{Colors.RESET}\n")
        
        # === НОВОЕ МЕНЮ С КАТЕГОРИЯМИ ===
        main_menu = {
            1: "🌐 Браузеры",
            2: "💻 Программирование",
            3: "🛠️ Утилиты",
            4: "🎮 Игры и общение",
            5: "🎵 Музыка и видео",
            6: "📁 Офис и документы",
            7: "🔧 Драйверы и система",
            8: "🔍 Поиск всех программ",
            9: "📋 Популярное (топ-20)",
        }
        
        print_menu(main_menu)
        print(f"{Colors.BLUE}{'─'*60}{Colors.RESET}")
        print(f"{Colors.RED}0.{Colors.RESET} 🚪 Выход")
        
        choice = get_choice(len(main_menu))
        if choice == 0:
            print(f"\n{Colors.GREEN}До свидания! 👋{Colors.RESET}")
            break
        
        # === ОБРАБОТКА КАТЕГОРИЙ ===
        category_map = {
            1: 'browsers',
            2: 'dev',
            3: 'utils',
            4: 'games',
            5: 'media',
            6: 'office',
            7: 'drivers',
        }
        
        if choice in category_map:
            category = category_map[choice]
            while True:
                clear()
                print_header(f"📁 {category.upper()}")
                programs = PROGRAMS.get(category, [])
                
                for i, (pkg, name, desc) in enumerate(programs, 1):
                    print(f"{Colors.GREEN}{i:2}.{Colors.RESET} {Colors.BOLD}{name}{Colors.RESET}")
                    print(f"     {desc}")
                
                print(f"\n{Colors.RED}0.{Colors.RESET} Назад")
                
                prog_choice = get_choice(len(programs))
                if prog_choice == 0:
                    break
                
                pkg, name, _ = programs[prog_choice-1]
                show_progress(f"Устанавливаю {name}")
                result = choco.install(pkg)
                if result and result.get('success'):
                    show_success(f"{name} установлен!")
                else:
                    show_error(f"Ошибка при установке {name}")
                input("\nНажми Enter...")
        
        elif choice == 8:  # Поиск
            clear()
            print_header("🔍 ПОИСК")
            query = input("Что ищем? ")
            if query:
                results = choco.search(query)
                if results:
                    print(f"\nНайдено {len(results[:20])} пакетов:")
                    for i, pkg in enumerate(results[:20], 1):
                        print(f"{Colors.GREEN}{i:2}.{Colors.RESET} {pkg}")
                    
                    print(f"\n{Colors.RED}0.{Colors.RESET} Назад")
                    pkg_choice = get_choice(min(20, len(results[:20])))
                    if pkg_choice:
                        pkg = results[pkg_choice-1].split()[0]  # берём только название
                        show_progress(f"Устанавливаю {pkg}")
                        result = choco.install(pkg)
                        if result and result.get('success'):
                            show_success(f"{pkg} установлен!")
                        else:
                            show_error(f"Ошибка при установке {pkg}")
                else:
                    print("❌ Ничего не найдено")
            input("\nНажми Enter...")
        
        elif choice == 9:  # Популярное
            clear()
            print_header("⭐ ПОПУЛЯРНОЕ (ТОП-20)")
            for i, (category, pkg, name, desc) in enumerate(ALL_PROGRAMS[:20], 1):
                print(f"{Colors.GREEN}{i:2}.{Colors.RESET} {Colors.BOLD}{name}{Colors.RESET}")
                print(f"     [{category}] {desc}")
            
            print(f"\n{Colors.RED}0.{Colors.RESET} Назад")
            prog_choice = get_choice(min(20, len(ALL_PROGRAMS[:20])))
            if prog_choice:
                category, pkg, name, desc = ALL_PROGRAMS[prog_choice-1]
                show_progress(f"Устанавливаю {name}")
                result = choco.install(pkg)
                if result and result.get('success'):
                    show_success(f"{name} установлен!")
                else:
                    show_error(f"Ошибка при установке {name}")
                input("\nНажми Enter...")

if __name__ == "__main__":
    run_menu()