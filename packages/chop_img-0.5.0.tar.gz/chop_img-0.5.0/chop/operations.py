"""Image operations for chop CLI.

Each operation takes a PIL Image and returns a modified PIL Image.
"""

from __future__ import annotations

from typing import Callable

from PIL import Image, ImageChops, ImageColor, ImageDraw, ImageEnhance, ImageFilter, ImageOps


def parse_size(size_str: str, current_size: tuple[int, int]) -> tuple[int, int]:
    """Parse size specification string.

    Supports:
        - "50%" - scale by percentage
        - "800x600" - exact dimensions
        - "w800" - width only, maintain aspect
        - "h600" - height only, maintain aspect

    Args:
        size_str: Size specification
        current_size: Current (width, height)

    Returns:
        (width, height) tuple
    """
    w, h = current_size

    # Percentage
    if size_str.endswith("%"):
        pct = float(size_str[:-1]) / 100.0
        return (int(w * pct), int(h * pct))

    # Width x Height
    if "x" in size_str:
        parts = size_str.lower().split("x")
        return (int(parts[0]), int(parts[1]))

    # Width only
    if size_str.lower().startswith("w"):
        new_w = int(size_str[1:])
        new_h = int(h * new_w / w)
        return (new_w, new_h)

    # Height only
    if size_str.lower().startswith("h"):
        new_h = int(size_str[1:])
        new_w = int(w * new_h / h)
        return (new_w, new_h)

    raise ValueError(f"Invalid size format: {size_str}")


def parse_crop(args: list[str], current_size: tuple[int, int]) -> tuple[int, int, int, int]:
    """Parse crop arguments.

    Supports:
        - x y w h (pixels)
        - x% y% w% h% (percentages)

    Args:
        args: List of 4 arguments
        current_size: Current (width, height)

    Returns:
        (x, y, width, height) tuple in pixels
    """
    if len(args) != 4:
        raise ValueError("crop requires 4 arguments: x y width height")

    w, h = current_size
    result = []

    for i, arg in enumerate(args):
        if arg.endswith("%"):
            pct = float(arg[:-1]) / 100.0
            # x and width use image width, y and height use image height
            if i % 2 == 0:  # x or width
                result.append(int(w * pct))
            else:  # y or height
                result.append(int(h * pct))
        else:
            result.append(int(arg))

    return tuple(result)


def op_resize(image: Image.Image, size_str: str) -> Image.Image:
    """Resize image.

    Args:
        image: Input image
        size_str: Size specification (50%, 800x600, w800, h600)

    Returns:
        Resized image
    """
    new_size = parse_size(size_str, image.size)
    return image.resize(new_size, Image.Resampling.LANCZOS)


def op_crop(image: Image.Image, x: int, y: int, width: int, height: int) -> Image.Image:
    """Crop image.

    Args:
        image: Input image
        x, y: Top-left corner
        width, height: Crop dimensions

    Returns:
        Cropped image
    """
    return image.crop((x, y, x + width, y + height))


def op_rotate(image: Image.Image, degrees: float) -> Image.Image:
    """Rotate image.

    Args:
        image: Input image
        degrees: Rotation angle (counter-clockwise)

    Returns:
        Rotated image
    """
    # Expand=True resizes to fit rotated content
    return image.rotate(degrees, expand=True, resample=Image.Resampling.BICUBIC)


def op_flip(image: Image.Image, direction: str) -> Image.Image:
    """Flip image horizontally or vertically.

    Args:
        image: Input image
        direction: "h" for horizontal, "v" for vertical

    Returns:
        Flipped image
    """
    if direction.lower() == "h":
        return image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    elif direction.lower() == "v":
        return image.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
    else:
        raise ValueError(f"direction must be 'h' or 'v', got {direction!r}")


# =============================================================================
# Padding and border operations
# =============================================================================


def _parse_color(color: str) -> tuple[int, int, int, int]:
    """Parse color string to RGBA tuple.

    Args:
        color: Color name, hex (#RGB, #RRGGBB), or "transparent"

    Returns:
        (R, G, B, A) tuple with values 0-255
    """
    if color.lower() == "transparent":
        return (0, 0, 0, 0)

    try:
        rgb = ImageColor.getrgb(color)
        if len(rgb) == 3:
            return (*rgb, 255)
        return rgb
    except ValueError:
        raise ValueError(f"Invalid color: {color}")


def op_pad(
    image: Image.Image,
    top: int,
    right: int | None = None,
    bottom: int | None = None,
    left: int | None = None,
    color: str = "transparent",
) -> Image.Image:
    """Add padding around image.

    Args:
        image: Input image
        top: Top padding (or uniform if only arg)
        right: Right padding (or horizontal if only top+right given)
        bottom: Bottom padding
        left: Left padding
        color: Padding color (name, hex, or "transparent")

    Supports:
        - pad(10): uniform 10px padding
        - pad(10, 20): 10 top/bottom, 20 left/right
        - pad(10, 20, 30, 40): top, right, bottom, left (CSS order)

    Returns:
        Padded image
    """
    # Parse padding values (CSS-style)
    if right is None:
        # Uniform padding
        t = r = b = l = top
    elif bottom is None:
        # Vertical, horizontal
        t = b = top
        r = l = right
    else:
        # All four specified
        t, r, b, l = top, right, bottom, left or right

    w, h = image.size
    new_w = w + l + r
    new_h = h + t + b

    fill_color = _parse_color(color)
    result = Image.new("RGBA", (new_w, new_h), fill_color)
    result.paste(image, (l, t))

    return result


def op_border(
    image: Image.Image,
    width: int,
    color: str = "black",
) -> Image.Image:
    """Add colored border around image.

    Args:
        image: Input image
        width: Border width in pixels
        color: Border color (name or hex)

    Returns:
        Image with border
    """
    fill_color = _parse_color(color)
    w, h = image.size
    new_w = w + width * 2
    new_h = h + width * 2

    result = Image.new("RGBA", (new_w, new_h), fill_color)
    result.paste(image, (width, width))

    return result


# =============================================================================
# Color and pixel operations
# =============================================================================


def op_brightness(image: Image.Image, factor: float) -> Image.Image:
    """Adjust image brightness.

    Args:
        image: Input image
        factor: Enhancement factor (0.0=black, 1.0=original, 2.0=double)

    Returns:
        Brightness-adjusted image
    """
    return ImageEnhance.Brightness(image).enhance(factor)


def op_contrast(image: Image.Image, factor: float) -> Image.Image:
    """Adjust image contrast.

    Args:
        image: Input image
        factor: Enhancement factor (0.0=grey, 1.0=original, 2.0=double)

    Returns:
        Contrast-adjusted image
    """
    return ImageEnhance.Contrast(image).enhance(factor)


def op_saturation(image: Image.Image, factor: float) -> Image.Image:
    """Adjust color saturation.

    Args:
        image: Input image
        factor: Enhancement factor (0.0=grayscale, 1.0=original, 2.0=double)

    Returns:
        Saturation-adjusted image
    """
    return ImageEnhance.Color(image).enhance(factor)


def op_sharpen(image: Image.Image, factor: float) -> Image.Image:
    """Adjust image sharpness.

    Args:
        image: Input image
        factor: Enhancement factor (0.0=blurred, 1.0=original, 2.0=sharpened)

    Returns:
        Sharpness-adjusted image
    """
    return ImageEnhance.Sharpness(image).enhance(factor)


def op_blur(image: Image.Image, radius: float) -> Image.Image:
    """Apply Gaussian blur.

    Args:
        image: Input image
        radius: Blur radius in pixels

    Returns:
        Blurred image
    """
    return image.filter(ImageFilter.GaussianBlur(radius))


def op_grayscale(image: Image.Image) -> Image.Image:
    """Convert to grayscale, preserving alpha channel.

    Args:
        image: Input image

    Returns:
        Grayscale image in RGBA mode
    """
    if image.mode == "RGBA":
        r, g, b, a = image.split()
        gray = image.convert("L")
        return Image.merge("RGBA", (gray, gray, gray, a))
    return image.convert("L").convert("RGBA")


def op_invert(image: Image.Image) -> Image.Image:
    """Invert image colors, preserving alpha channel.

    Args:
        image: Input image

    Returns:
        Color-inverted image
    """
    if image.mode == "RGBA":
        r, g, b, a = image.split()
        return Image.merge(
            "RGBA", (ImageOps.invert(r), ImageOps.invert(g), ImageOps.invert(b), a)
        )
    return ImageOps.invert(image)


# =============================================================================
# Trim, colorize, opacity, background operations
# =============================================================================


def op_trim(image: Image.Image, fuzz: int = 0) -> Image.Image:
    """Auto-crop uniform borders from image.

    For RGBA images: trims transparent edges by default.
    For opaque images: auto-detects border color from top-left corner.

    Args:
        image: Input image
        fuzz: Tolerance 0-255 for color matching (default 0 = exact)

    Returns:
        Trimmed image (or original if nothing to trim)
    """
    # Auto-detect background: sample top-left corner
    corner = image.getpixel((0, 0))
    if image.mode == "RGBA" and corner[3] == 0:
        # Corner is transparent — use alpha channel directly
        _, _, _, a = image.split()
        diff = a
    else:
        # Corner is opaque — diff RGB against corner color, ignore alpha
        rgb = image.convert("RGB")
        corner_rgb = corner[:3] if len(corner) > 3 else corner
        bg = Image.new("RGB", image.size, corner_rgb)
        diff = ImageChops.difference(rgb, bg)

    if fuzz > 0:
        # Threshold: pixels with difference <= fuzz become black (0)
        diff = diff.point(lambda p: 0 if p <= fuzz else p)

    bbox = diff.getbbox()
    if bbox is None:
        return image  # Nothing to trim (or entirely uniform)
    return image.crop(bbox)


def op_colorize(image: Image.Image, color: str, strength: float = 1.0) -> Image.Image:
    """Tint image with a color, preserving luminance.

    Args:
        image: Input image
        color: Named color or hex string
        strength: Blend factor 0.0 (none) to 1.0 (full tint), default 1.0

    Returns:
        Color-tinted image
    """
    rgba = image.convert("RGBA")
    r, g, b, a = rgba.split()

    # Compute luminance as grayscale
    gray = image.convert("L")

    # Parse target color
    tint_rgb = ImageColor.getrgb(color)
    if len(tint_rgb) == 4:
        tint_rgb = tint_rgb[:3]

    # Create tinted channels: scale tint color by luminance
    tinted_r = gray.point(lambda p: int(p * tint_rgb[0] / 255))
    tinted_g = gray.point(lambda p: int(p * tint_rgb[1] / 255))
    tinted_b = gray.point(lambda p: int(p * tint_rgb[2] / 255))

    tinted = Image.merge("RGBA", (tinted_r, tinted_g, tinted_b, a))

    if strength >= 1.0:
        return tinted
    if strength <= 0.0:
        return rgba

    # Blend original with tinted
    return Image.blend(rgba, tinted, strength)


def op_opacity(image: Image.Image, factor: float) -> Image.Image:
    """Set uniform opacity by scaling the alpha channel.

    Args:
        image: Input image
        factor: Opacity factor 0.0 (transparent) to 1.0 (opaque)

    Returns:
        Image with adjusted alpha
    """
    rgba = image.convert("RGBA")
    r, g, b, a = rgba.split()
    a = a.point(lambda p: int(p * factor))
    return Image.merge("RGBA", (r, g, b, a))


def op_background(image: Image.Image, color: str) -> Image.Image:
    """Flatten transparency onto a solid color background.

    Args:
        image: Input image (typically with transparency)
        color: Background color (name or hex)

    Returns:
        Fully opaque image (RGBA with A=255 everywhere)
    """
    fill_color = _parse_color(color)
    canvas = Image.new("RGBA", image.size, fill_color)
    rgba = image.convert("RGBA")
    canvas = Image.alpha_composite(canvas, rgba)
    return canvas


def op_mask(
    image: Image.Image, shape: str, radius: int = 0, invert: bool = False
) -> Image.Image:
    """Apply a shape mask to the image.

    Shapes:
        - "roundrect": rounded rectangle with given radius
        - "circle": circular mask (inscribed in image bounds)
        - "ellipse": elliptical mask filling image bounds

    Args:
        image: Input image
        shape: Shape name (roundrect, circle, ellipse)
        radius: Corner radius for roundrect (default 0)
        invert: If True, make inside transparent and outside opaque

    Returns:
        Masked image with alpha channel applied
    """
    w, h = image.size
    mask = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(mask)

    if shape == "roundrect":
        draw.rounded_rectangle([(0, 0), (w - 1, h - 1)], radius=radius, fill=255)
    elif shape == "circle":
        # Inscribed circle: centered, diameter = min(w, h)
        diameter = min(w, h)
        left = (w - diameter) // 2
        top = (h - diameter) // 2
        draw.ellipse(
            [(left, top), (left + diameter - 1, top + diameter - 1)], fill=255
        )
    elif shape == "ellipse":
        draw.ellipse([(0, 0), (w - 1, h - 1)], fill=255)
    else:
        raise ValueError(f"Unknown mask shape: {shape}. Use roundrect, circle, or ellipse.")

    if invert:
        mask = ImageOps.invert(mask)

    # Apply mask: multiply with existing alpha
    rgba = image.convert("RGBA")
    r, g, b, a = rgba.split()
    # Combine existing alpha with shape mask (min of both)
    a = ImageChops.multiply(a, mask)
    return Image.merge("RGBA", (r, g, b, a))


# =============================================================================
# Fit and fill operations
# =============================================================================


def op_fit(image: Image.Image, size_str: str) -> Image.Image:
    """Fit image within bounds, preserving aspect ratio.

    The image is scaled down (if needed) to fit entirely within
    the specified dimensions. The result may be smaller than
    the target in one dimension.

    Args:
        image: Input image
        size_str: Target size as "WxH" (e.g., "800x600")

    Returns:
        Fitted image (may be smaller than target in one dimension)
    """
    if "x" not in size_str.lower():
        raise ValueError(f"fit requires WxH format, got: {size_str}")

    parts = size_str.lower().split("x")
    target_w, target_h = int(parts[0]), int(parts[1])
    w, h = image.size

    # Calculate scale to fit within bounds
    scale = min(target_w / w, target_h / h)
    new_w = int(w * scale)
    new_h = int(h * scale)

    return image.resize((new_w, new_h), Image.Resampling.LANCZOS)


def op_fill(image: Image.Image, size_str: str) -> Image.Image:
    """Fill bounds completely, cropping excess (center crop).

    The image is scaled to completely fill the specified dimensions,
    then center-cropped to exact size.

    Args:
        image: Input image
        size_str: Target size as "WxH" (e.g., "800x600")

    Returns:
        Filled and cropped image (exact target size)
    """
    if "x" not in size_str.lower():
        raise ValueError(f"fill requires WxH format, got: {size_str}")

    parts = size_str.lower().split("x")
    target_w, target_h = int(parts[0]), int(parts[1])
    w, h = image.size

    # Calculate scale to fill bounds completely
    scale = max(target_w / w, target_h / h)
    scaled_w = int(w * scale)
    scaled_h = int(h * scale)

    # Scale up
    scaled = image.resize((scaled_w, scaled_h), Image.Resampling.LANCZOS)

    # Center crop to exact target size
    left = (scaled_w - target_w) // 2
    top = (scaled_h - target_h) // 2
    return scaled.crop((left, top, left + target_w, top + target_h))


# =============================================================================
# Composition operations
# =============================================================================


def _align_offset(
    size1: int, size2: int, align: str, is_horizontal: bool
) -> tuple[int, int]:
    """Calculate offsets for aligning two dimensions.

    Args:
        size1: First size (target)
        size2: Second size (to align)
        align: Alignment string (top/center/bottom or left/center/right)
        is_horizontal: True for horizontal alignment (left/center/right)

    Returns:
        (offset1, offset2) - offsets for each image
    """
    if size1 == size2:
        return (0, 0)

    max_size = max(size1, size2)

    if is_horizontal:
        # left/center/right
        if align == "left":
            return (0, 0)
        elif align == "right":
            return (max_size - size1, max_size - size2)
        else:  # center
            return ((max_size - size1) // 2, (max_size - size2) // 2)
    else:
        # top/center/bottom
        if align == "top":
            return (0, 0)
        elif align == "bottom":
            return (max_size - size1, max_size - size2)
        else:  # center
            return ((max_size - size1) // 2, (max_size - size2) // 2)


def op_hstack(
    image: Image.Image,
    other: Image.Image,
    align: str = "center",
    gap: int = 0,
    gap_color: str = "transparent",
) -> Image.Image:
    """Stack two images horizontally (side by side).

    Args:
        image: Left image
        other: Right image
        align: Vertical alignment (top, center, bottom)
        gap: Pixel spacing between images (default 0)
        gap_color: Color for gap space (default transparent)

    Returns:
        Combined image
    """
    w1, h1 = image.size
    w2, h2 = other.size

    # Calculate output dimensions
    out_width = w1 + gap + w2
    out_height = max(h1, h2)

    # Calculate vertical offsets for alignment
    offset1, offset2 = _align_offset(h1, h2, align, is_horizontal=False)

    # Create output image
    fill = _parse_color(gap_color)
    result = Image.new("RGBA", (out_width, out_height), fill)

    # Paste images
    result.paste(image, (0, offset1))
    result.paste(other, (w1 + gap, offset2))

    return result


def op_vstack(
    image: Image.Image,
    other: Image.Image,
    align: str = "center",
    gap: int = 0,
    gap_color: str = "transparent",
) -> Image.Image:
    """Stack two images vertically (one above the other).

    Args:
        image: Top image
        other: Bottom image
        align: Horizontal alignment (left, center, right)
        gap: Pixel spacing between images (default 0)
        gap_color: Color for gap space (default transparent)

    Returns:
        Combined image
    """
    w1, h1 = image.size
    w2, h2 = other.size

    # Calculate output dimensions
    out_width = max(w1, w2)
    out_height = h1 + gap + h2

    # Calculate horizontal offsets for alignment
    offset1, offset2 = _align_offset(w1, w2, align, is_horizontal=True)

    # Create output image
    fill = _parse_color(gap_color)
    result = Image.new("RGBA", (out_width, out_height), fill)

    # Paste images
    result.paste(image, (offset1, 0))
    result.paste(other, (offset2, h1 + gap))

    return result


def op_overlay(
    image: Image.Image,
    overlay: Image.Image,
    x: int,
    y: int,
    opacity: float = 1.0,
    paste: bool = False,
) -> Image.Image:
    """Overlay an image on top of another.

    Args:
        image: Base image
        overlay: Image to overlay
        x: X position for overlay
        y: Y position for overlay
        opacity: Opacity multiplier (0.0-1.0)
        paste: If True, hard paste without alpha blending

    Returns:
        Combined image
    """
    result = image.copy()

    # Apply opacity if needed
    if opacity < 1.0 and overlay.mode == "RGBA":
        # Modify alpha channel
        r, g, b, a = overlay.split()
        a = a.point(lambda p: int(p * opacity))
        overlay = Image.merge("RGBA", (r, g, b, a))

    if paste:
        # Hard paste (no blending)
        result.paste(overlay, (x, y))
    else:
        # Alpha composite
        # Create a full-size overlay layer
        layer = Image.new("RGBA", result.size, (0, 0, 0, 0))
        layer.paste(overlay, (x, y))
        result = Image.alpha_composite(result, layer)

    return result


def op_tile(image: Image.Image, cols: int, rows: int) -> Image.Image:
    """Tile an image NxM times.

    Args:
        image: Image to tile
        cols: Number of columns
        rows: Number of rows

    Returns:
        Tiled image
    """
    w, h = image.size
    result = Image.new("RGBA", (w * cols, h * rows), (0, 0, 0, 0))

    for row in range(rows):
        for col in range(cols):
            result.paste(image, (col * w, row * h))

    return result


def op_grid(
    image: Image.Image,
    others: list[Image.Image],
    cols: int = 2,
    gap: int = 0,
    gap_color: str = "transparent",
) -> Image.Image:
    """Arrange multiple images in a grid.

    The first image determines the cell size. All other images are
    resized to match.

    Args:
        image: First image (determines cell size)
        others: Additional images
        cols: Number of columns
        gap: Pixel spacing between cells (default 0)
        gap_color: Color for gap space (default transparent)

    Returns:
        Grid image
    """
    all_images = [image] + others
    cell_w, cell_h = image.size

    # Calculate grid dimensions
    total = len(all_images)
    rows = (total + cols - 1) // cols  # Ceiling division

    out_w = cell_w * cols + gap * (cols - 1)
    out_h = cell_h * rows + gap * (rows - 1)
    fill = _parse_color(gap_color)
    result = Image.new("RGBA", (out_w, out_h), fill)

    for i, img in enumerate(all_images):
        # Resize to cell size if needed
        if img.size != (cell_w, cell_h):
            img = img.resize((cell_w, cell_h), Image.Resampling.LANCZOS)

        row = i // cols
        col = i % cols
        x = col * (cell_w + gap)
        y = row * (cell_h + gap)
        result.paste(img, (x, y))

    return result


# =============================================================================
# Operations Registry
# =============================================================================


# Single-image transform operations
OPERATIONS: dict[str, Callable[..., Image.Image]] = {
    # Geometric
    "resize": op_resize,
    "crop": op_crop,
    "rotate": op_rotate,
    "flip": op_flip,
    "fit": op_fit,
    "fill": op_fill,
    # Padding/border
    "pad": op_pad,
    "border": op_border,
    # Color/pixel
    "brightness": op_brightness,
    "contrast": op_contrast,
    "saturation": op_saturation,
    "sharpen": op_sharpen,
    "blur": op_blur,
    "grayscale": op_grayscale,
    "invert": op_invert,
    # Trim/alpha/background
    "trim": op_trim,
    "colorize": op_colorize,
    "opacity": op_opacity,
    "background": op_background,
    "mask": op_mask,
    # Single-image composition
    "tile": op_tile,
}

# Multi-image composition operations — dispatched by execute_composition()
# in pipeline.py rather than through apply_operation().
COMPOSITION_OPS: set[str] = {"hstack", "vstack", "overlay", "grid"}


def apply_operation(
    image: Image.Image, op_name: str, *args, **kwargs
) -> Image.Image:
    """Apply a named single-image operation.

    Composition operations (hstack, vstack, overlay, grid) are handled
    by execute_composition() in pipeline.py, not here.

    Args:
        image: Input PIL Image
        op_name: Operation name (e.g., "resize", "flip")
        *args: Positional arguments for the operation
        **kwargs: Keyword arguments for the operation

    Returns:
        Processed PIL Image

    Raises:
        ValueError: If operation name is unknown
    """
    # Handle crop specially to parse arguments
    if op_name == "crop":
        x, y, w, h = args[0], args[1], args[2], args[3]
        if isinstance(x, str) or isinstance(y, str):
            x, y, w, h = parse_crop([str(x), str(y), str(w), str(h)], image.size)
        return op_crop(image, x, y, w, h)

    if op_name not in OPERATIONS:
        raise ValueError(f"Unknown operation: {op_name}")

    op_func = OPERATIONS[op_name]
    return op_func(image, *args, **kwargs)
