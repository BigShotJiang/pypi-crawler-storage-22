<h1>ChromaQuant</h1>
<i>A solution for automated gas chromatographic peak assignment and quantification</i>

<h4>Introduction</h4>
<img style="float: right;" align="right" width="256" alt="ChromaQuant Logo" src="https://github.com/JnliaH/ChromaQuant/blob/rebrand/images/ChromaQuantIcon.png">
ChromaQuant is an open-source toolkit designed to enable users to rapidly and precisely analyze chromatographic data. It offers tools for matching chromatographic signals to each other or to other tabulated data, writing formulas for dynamic Excel reporting, and peforming simple operations on tabulated data to produce properties like molecular weight.

The development of ChromaQuant is associated with the <a href="https://www.rorrerlab.com/">Rorrer Lab</a> at the University of Washington Department of Chemical engineering.

<h4>Installation</h4>
Install ChromaQuant by running the following command in the terminal/command prompt:<br>


> pip install chromaquant

<h4>Usage</h4>

ChromaQuant is currently under major renovations. Please tune back in for in-detail documentation on usage with examples!
