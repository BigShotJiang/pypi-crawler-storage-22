"""
Archive Manager — central orchestrator for maritime archive data.

Manages:
- Archive registry and metadata
- Data source clients for each archive (DAS, EIC, Carreira, Galleon, SOIC, etc.)
- Hull profile lookups
- Position uncertainty assessment
- GeoJSON export
- Aggregate statistics
"""

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from ..constants import (
    ARCHIVE_METADATA,
    MAX_PAGE_SIZE,
    NAVIGATION_ERAS,
)
from ..models.responses import decode_cursor, encode_cursor
from .clients import (
    CargoClient,
    CarreiraClient,
    CrewClient,
    DASClient,
    DSSClient,
    EICClient,
    GalleonClient,
    NOAAClient,
    SOICClient,
    UKHOClient,
    WreckClient,
)
from .cliwoc_tracks import (
    find_track_for_voyage,
    get_track,
    get_track_by_das_number,
)
from .hull_profiles import HULL_PROFILES
from .voc_routes import estimate_position, get_route as get_route_detail, suggest_route

logger = logging.getLogger(__name__)

# Default data directory relative to the project root
_DEFAULT_DATA_DIR = Path(__file__).resolve().parent.parent.parent.parent / "data"

# Sentinel value: fetch all matching records from clients (no truncation)
_FETCH_ALL = 999_999


@dataclass
class PaginatedResult:
    """Paginated search result with cursor metadata."""

    items: list[dict]
    total_count: int
    next_cursor: str | None
    has_more: bool


# Map archive IDs to CLIWOC nationality codes
_ARCHIVE_NATIONALITY = {
    "das": "NL",
    "eic": "UK",
    "carreira": "PT",
    "galleon": "ES",
    "soic": "SE",
}


class ArchiveManager:
    """
    Central orchestrator for maritime archive data access.

    Delegates data access to archive-specific clients that read from
    local JSON data files produced by the download scripts.
    """

    def __init__(self, data_dir: Path | None = None) -> None:
        self._archives = dict(ARCHIVE_METADATA)
        self._hull_profiles = dict(HULL_PROFILES)

        data_path = data_dir or _DEFAULT_DATA_DIR

        # Data source clients
        self._das_client = DASClient(data_dir=data_path)
        self._crew_client = CrewClient(data_dir=data_path)
        self._cargo_client = CargoClient(data_dir=data_path)
        self._wreck_client = WreckClient(data_dir=data_path)

        # Additional archive clients
        self._eic_client = EICClient(data_dir=data_path)
        self._carreira_client = CarreiraClient(data_dir=data_path)
        self._galleon_client = GalleonClient(data_dir=data_path)
        self._soic_client = SOICClient(data_dir=data_path)
        self._ukho_client = UKHOClient(data_dir=data_path)
        self._noaa_client = NOAAClient(data_dir=data_path)
        self._dss_client = DSSClient(data_dir=data_path)

        # Multi-archive dispatch: archive ID -> voyage client
        self._voyage_clients: dict[str, Any] = {
            "das": self._das_client,
            "eic": self._eic_client,
            "carreira": self._carreira_client,
            "galleon": self._galleon_client,
            "soic": self._soic_client,
        }

        # Multi-archive dispatch: archive ID -> wreck client
        self._wreck_clients: dict[str, Any] = {
            "maarer": self._wreck_client,
            "eic": self._eic_client,
            "carreira": self._carreira_client,
            "galleon": self._galleon_client,
            "soic": self._soic_client,
            "ukho": self._ukho_client,
            "noaa": self._noaa_client,
        }

        # Multi-archive dispatch: archive ID -> crew client
        self._crew_clients: dict[str, Any] = {
            "voc_crew": self._crew_client,
            "dss": self._dss_client,
        }

    # --- Pagination Helper --------------------------------------------------

    @staticmethod
    def _paginate(
        all_results: list[dict],
        max_results: int,
        cursor: str | None,
    ) -> PaginatedResult:
        """Slice a full result list into a page with cursor metadata."""
        page_size = min(max_results, MAX_PAGE_SIZE)
        offset = decode_cursor(cursor)
        total_count = len(all_results)
        page = all_results[offset : offset + page_size]
        next_offset = offset + page_size
        has_more = next_offset < total_count
        next_cursor = encode_cursor(next_offset) if has_more else None
        return PaginatedResult(
            items=page,
            total_count=total_count,
            next_cursor=next_cursor,
            has_more=has_more,
        )

    # --- Archive Registry ---------------------------------------------------

    def list_archives(self) -> list[dict]:
        """Return metadata for all available archives."""
        results = []
        for archive_id, meta in self._archives.items():
            results.append({"id": archive_id, **meta})
        return results

    def get_archive(self, archive_id: str) -> dict | None:
        """Return detailed metadata for a specific archive."""
        meta = self._archives.get(archive_id)
        if meta is None:
            return None
        return {"archive_id": archive_id, **meta}

    def get_available_archive_ids(self) -> list[str]:
        """Return list of available archive identifiers."""
        return list(self._archives.keys())

    # --- Voyage Operations --------------------------------------------------

    async def search_voyages(
        self,
        ship_name: str | None = None,
        captain: str | None = None,
        date_range: str | None = None,
        departure_port: str | None = None,
        destination_port: str | None = None,
        route: str | None = None,
        fate: str | None = None,
        archive: str | None = None,
        max_results: int = 50,
        cursor: str | None = None,
    ) -> PaginatedResult:
        """Search for voyages across all archives or a specific one."""
        search_kwargs = dict(
            ship_name=ship_name,
            captain=captain,
            date_range=date_range,
            departure_port=departure_port,
            destination_port=destination_port,
            route=route,
            fate=fate,
            max_results=_FETCH_ALL,
        )

        if archive and archive in self._voyage_clients:
            results = await self._voyage_clients[archive].search(**search_kwargs)
        elif archive:
            results = []
        else:
            # Query all voyage archives and merge results
            results = []
            for client in self._voyage_clients.values():
                results.extend(await client.search(**search_kwargs))
            # Deterministic sort for stable pagination across archives
            results.sort(key=lambda v: (v.get("departure_date") or "9999", v.get("voyage_id", "")))

        return self._paginate(results, max_results, cursor)

    async def get_voyage(self, voyage_id: str) -> dict | None:
        """Get full voyage details, routing to the correct archive client."""
        prefix = voyage_id.split(":")[0] if ":" in voyage_id else "das"
        client = self._voyage_clients.get(prefix, self._das_client)
        return await client.get_by_id(voyage_id)

    # --- Cross-Archive Linking ----------------------------------------------

    async def get_voyage_full(self, voyage_id: str, include_crew: bool = False) -> dict | None:
        """
        Get unified view of a voyage with all linked records.

        Returns the voyage record enriched with related wreck, vessel,
        hull profile, CLIWOC track, and optionally crew data.
        Includes confidence scores for each link.
        """
        voyage = await self.get_voyage(voyage_id)
        if not voyage:
            return None

        # Find linked wreck record (via voyage_id) -- check all wreck clients
        wreck = await self._find_wreck_for_voyage(voyage_id)

        # Find linked vessel record (via voyage_ids array, DAS only)
        vessel = self._das_client.get_vessel_for_voyage(voyage_id)

        # Find hull profile for ship type
        ship_type = voyage.get("ship_type")
        hull_profile = self.get_hull_profile(ship_type) if ship_type else None

        # Find linked CLIWOC track (with confidence)
        cliwoc_track, cliwoc_confidence = self._find_cliwoc_track_for_voyage(voyage)

        # Build link_confidence dict
        link_confidence: dict[str, float] = {}
        if wreck:
            link_confidence["wreck"] = 1.0
        if vessel:
            link_confidence["vessel"] = 1.0
        if hull_profile:
            link_confidence["hull_profile"] = 1.0
        if cliwoc_track:
            link_confidence["cliwoc_track"] = cliwoc_confidence

        # Optionally find crew
        crew = None
        if include_crew:
            crew = await self.find_crew_for_voyage(voyage_id)
            if crew:
                link_confidence["crew"] = min(
                    (c.get("link_confidence", 1.0) for c in crew), default=1.0
                )

        links_found = [
            k
            for k, v in {
                "wreck": wreck,
                "vessel": vessel,
                "hull_profile": hull_profile,
                "cliwoc_track": cliwoc_track,
                "crew": crew,
            }.items()
            if v
        ]

        return {
            "voyage": voyage,
            "wreck": wreck,
            "vessel": vessel,
            "hull_profile": hull_profile,
            "cliwoc_track": cliwoc_track,
            "crew": crew,
            "links_found": links_found,
            "link_confidence": link_confidence,
        }

    def _find_cliwoc_track_for_voyage(self, voyage: dict) -> tuple[dict | None, float]:
        """Try to find a CLIWOC track linked to this voyage.

        Returns (track_summary_or_None, confidence).
        """
        # Try DASnumber first (from CLIWOC 2.1 Full data, DAS only)
        voyage_number = voyage.get("voyage_number")
        if voyage_number:
            track = get_track_by_das_number(voyage_number)
            if track:
                # Return summary without full positions — confidence 1.0 (direct ID link)
                return {k: v for k, v in track.items() if k != "positions"}, 1.0

        # Fall back to fuzzy ship name + date + nationality matching
        ship_name = voyage.get("ship_name")
        archive = voyage.get("archive", "das")
        nationality = _ARCHIVE_NATIONALITY.get(archive, "NL")
        if ship_name:
            return find_track_for_voyage(
                ship_name=ship_name,
                departure_date=voyage.get("departure_date"),
                nationality=nationality,
            )

        return None, 0.0

    async def find_crew_for_voyage(
        self, voyage_id: str, min_confidence: float = 0.50
    ) -> list[dict]:
        """
        Find crew records linked to a voyage.

        Strategy:
        1. Exact: search VOC Opvarenden by voyage_id (indexed)
        2. Exact: search DSS musters by das_voyage_id, get linked crew
        3. Fuzzy: match DSS crew by ship_name + muster_date
        """
        results: list[dict] = []

        # 1. VOC Opvarenden exact match (via voyage_id index)
        try:
            voc_crew = await self._crew_client.search(voyage_id=voyage_id)
            for c in voc_crew:
                c["link_confidence"] = 1.0
                c["link_method"] = "exact_voyage_id"
            results.extend(voc_crew)
        except Exception:
            pass

        # 2. DSS musters linked by das_voyage_id
        try:
            musters = await self._dss_client.get_musters_for_voyage(voyage_id)
            for m in musters:
                m["link_confidence"] = 1.0
                m["link_method"] = "muster_das_voyage_id"
            results.extend(musters)
        except Exception:
            pass

        # 3. Fuzzy match DSS crew by ship name + date
        if not results:
            # Get the voyage to extract ship name and date
            voyage = await self.get_voyage(voyage_id)
            if voyage and voyage.get("ship_name"):
                from .entity_resolution import normalize_ship_name, levenshtein_similarity

                v_name = normalize_ship_name(voyage["ship_name"])
                v_date = voyage.get("departure_date")
                v_year = int(v_date[:4]) if v_date and len(v_date) >= 4 else None

                all_crew = await self._dss_client.search_crews(max_results=500)
                for c in all_crew:
                    c_name = normalize_ship_name(c.get("ship_name", ""))
                    name_sim = levenshtein_similarity(v_name, c_name)
                    if name_sim < 0.7:
                        continue

                    # Date proximity
                    c_date = c.get("muster_date")
                    c_year = int(c_date[:4]) if c_date and len(c_date) >= 4 else None
                    date_score = 1.0
                    if v_year and c_year:
                        diff = abs(v_year - c_year)
                        date_score = max(0.0, 1.0 - diff * 0.25)

                    confidence = 0.7 * name_sim + 0.3 * date_score
                    if confidence >= min_confidence:
                        c["link_confidence"] = round(confidence, 4)
                        c["link_method"] = "fuzzy_ship_date"
                        results.append(c)

        return results

    async def _find_wreck_for_voyage(self, voyage_id: str) -> dict | None:
        """Find a wreck record linked to a voyage, checking the appropriate client."""
        prefix = voyage_id.split(":")[0] if ":" in voyage_id else "das"
        # Normalise to prefixed form for consistent matching
        normalised = voyage_id if ":" in voyage_id else f"{prefix}:{voyage_id}"

        # For DAS voyages, check the MAARER wreck client
        if prefix == "das":
            return await self._wreck_client.get_by_voyage_id(normalised)

        # For other archives, the archive client handles its own wrecks
        client = self._voyage_clients.get(prefix)
        if client and hasattr(client, "get_wreck_by_voyage_id"):
            return await client.get_wreck_by_voyage_id(voyage_id)

        return None

    # --- Link Audit ---------------------------------------------------------

    async def audit_links(self) -> dict:
        """
        Audit cross-archive link quality against known ground truth.

        Uses wreck records with voyage_id fields and CLIWOC tracks with
        DAS numbers as ground truth to measure precision/recall of the
        entity resolution pipeline.
        """
        # --- Wreck links audit ---
        wreck_ground_truth = 0
        wreck_matched = 0
        for client in self._wreck_clients.values():
            if hasattr(client, "_get_wrecks"):
                for w in client._get_wrecks():
                    if w.get("voyage_id"):
                        wreck_ground_truth += 1
                        # Verify the linked voyage exists
                        v = await self.get_voyage(w["voyage_id"])
                        if v:
                            wreck_matched += 1
            elif hasattr(client, "get_by_voyage_id"):
                # WreckClient (MAARER): check via wreck data
                try:
                    wrecks = client._load_json(client.WRECKS_FILE)
                    for w in wrecks:
                        if w.get("voyage_id"):
                            wreck_ground_truth += 1
                            v = await self.get_voyage(w["voyage_id"])
                            if v:
                                wreck_matched += 1
                except Exception:
                    pass

        wreck_precision = 1.0 if wreck_matched > 0 else 0.0
        wreck_recall = wreck_matched / wreck_ground_truth if wreck_ground_truth > 0 else 0.0

        # --- CLIWOC links audit ---
        # Count direct DAS number links
        from .cliwoc_tracks import _DAS_INDEX, _load_tracks

        _load_tracks()
        direct_links = len(_DAS_INDEX)

        # Sample DAS voyages and try fuzzy matching
        fuzzy_matches = 0
        confidences: list[float] = []
        all_voyages = await self._das_client.search(max_results=500)
        for v in all_voyages:
            # Skip if already has direct DAS link
            voyage_number = v.get("voyage_number")
            if voyage_number and str(voyage_number) in _DAS_INDEX:
                continue

            ship_name = v.get("ship_name")
            if not ship_name:
                continue

            track, confidence = find_track_for_voyage(
                ship_name=ship_name,
                departure_date=v.get("departure_date"),
                nationality="NL",
            )
            if track and confidence >= 0.50:
                fuzzy_matches += 1
                confidences.append(confidence)

        mean_confidence = sum(confidences) / len(confidences) if confidences else 0.0
        high_count = sum(1 for c in confidences if c >= 0.70)
        moderate_count = sum(1 for c in confidences if c >= 0.50)

        # --- Crew links audit ---
        # Count VOC crew records with voyage_id
        try:
            crew_exact = len(await self._crew_client.search(max_results=100))
        except Exception:
            crew_exact = 0
        crew_fuzzy = 0  # DSS crew fuzzy matches counted separately

        # --- Confidence distribution ---
        all_confidences = [1.0] * direct_links + confidences
        distribution: dict[str, int] = {}
        buckets = [
            ("0.9-1.0", 0.9, 1.01),
            ("0.7-0.9", 0.7, 0.9),
            ("0.5-0.7", 0.5, 0.7),
        ]
        for label, lo, hi in buckets:
            distribution[label] = sum(1 for c in all_confidences if lo <= c < hi)

        total_evaluated = wreck_ground_truth + direct_links + len(all_voyages)

        return {
            "wreck_links": {
                "ground_truth_count": wreck_ground_truth,
                "matched_count": wreck_matched,
                "precision": round(wreck_precision, 4),
                "recall": round(wreck_recall, 4),
            },
            "cliwoc_links": {
                "direct_links": direct_links,
                "fuzzy_matches": fuzzy_matches,
                "mean_confidence": round(mean_confidence, 4),
                "high_confidence_count": high_count,
                "moderate_confidence_count": moderate_count,
            },
            "crew_links": {
                "exact_matches": crew_exact,
                "fuzzy_matches": crew_fuzzy,
            },
            "total_links_evaluated": total_evaluated,
            "confidence_distribution": distribution,
        }

    # --- Timeline -----------------------------------------------------------

    async def build_timeline(
        self,
        voyage_id: str,
        include_positions: bool = False,
        max_positions: int = 20,
    ) -> dict | None:
        """
        Build a chronological timeline of events for a voyage.

        Assembles events from multiple archives:
        - DAS voyage: departure, arrival
        - Route estimates: waypoint positions
        - CLIWOC tracks: observed ship positions
        - MAARER wrecks: loss event
        """
        voyage = await self.get_voyage(voyage_id)
        if not voyage:
            return None

        events: list[dict] = []
        data_sources: list[str] = []
        ship_name = voyage.get("ship_name")

        # --- Departure event ---
        dep_date = voyage.get("departure_date")
        dep_port = voyage.get("departure_port", "Unknown")
        if dep_date:
            data_sources.append("das")
            events.append(
                {
                    "date": dep_date,
                    "type": "departure",
                    "title": f"Departed {dep_port}",
                    "details": {
                        "port": dep_port,
                        "ship_name": ship_name,
                        "captain": voyage.get("captain"),
                    },
                    "position": None,
                    "source": "das",
                }
            )

        # --- Route waypoint estimates ---
        if dep_date:
            route_matches = suggest_route(
                departure_port=voyage.get("departure_port"),
                destination_port=voyage.get("destination_port"),
            )
            if route_matches:
                route_id = route_matches[0]["route_id"]
                route_data = get_route_detail(route_id)
                if route_data:
                    if "route_estimate" not in data_sources:
                        data_sources.append("route_estimate")
                    for wp in route_data.get("waypoints", [])[1:]:  # skip departure
                        try:
                            dep_dt = datetime.strptime(dep_date, "%Y-%m-%d")
                        except ValueError:
                            break
                        wp_date = dep_dt + timedelta(days=wp["cumulative_days"])
                        wp_date_str = wp_date.strftime("%Y-%m-%d")

                        est = estimate_position(
                            route_id=route_id,
                            departure_date=dep_date,
                            target_date=wp_date_str,
                        )
                        pos = None
                        if est and "estimated_position" in est:
                            ep = est["estimated_position"]
                            pos = {"lat": ep["lat"], "lon": ep["lon"]}

                        events.append(
                            {
                                "date": wp_date_str,
                                "type": "waypoint_estimate",
                                "title": f"Estimated at {wp['name']}",
                                "details": {
                                    "waypoint": wp["name"],
                                    "region": wp.get("region", ""),
                                    "cumulative_days": wp["cumulative_days"],
                                },
                                "position": pos,
                                "source": "route_estimate",
                            }
                        )

        # --- CLIWOC track positions ---
        cliwoc_track_info, _ = self._find_cliwoc_track_for_voyage(voyage)
        if cliwoc_track_info and include_positions:
            cliwoc_voyage_id = cliwoc_track_info.get("voyage_id")
            if cliwoc_voyage_id is not None:
                full_track = get_track(cliwoc_voyage_id)
                if full_track:
                    if "cliwoc" not in data_sources:
                        data_sources.append("cliwoc")
                    positions = full_track.get("positions", [])
                    # Sample positions if there are too many
                    if len(positions) > max_positions and max_positions > 0:
                        step = max(1, len(positions) // max_positions)
                        positions = positions[::step][:max_positions]
                    for p in positions:
                        if p.get("date") and p.get("lat") is not None:
                            events.append(
                                {
                                    "date": p["date"],
                                    "type": "cliwoc_position",
                                    "title": f"CLIWOC position ({p.get('lat', '?')}N, {p.get('lon', '?')}E)",
                                    "details": {
                                        "nationality": full_track.get("nationality"),
                                    },
                                    "position": {"lat": p["lat"], "lon": p["lon"]},
                                    "source": "cliwoc",
                                }
                            )
        elif cliwoc_track_info:
            if "cliwoc" not in data_sources:
                data_sources.append("cliwoc")

        # --- Wreck / loss event ---
        wreck = await self._find_wreck_for_voyage(voyage_id)
        if wreck:
            if "maarer" not in data_sources:
                data_sources.append("maarer")
            loss_date = wreck.get("loss_date")
            if loss_date:
                pos = None
                wreck_pos = wreck.get("position")
                if wreck_pos and wreck_pos.get("lat") is not None:
                    pos = {"lat": wreck_pos["lat"], "lon": wreck_pos["lon"]}
                events.append(
                    {
                        "date": loss_date,
                        "type": "loss",
                        "title": f"Lost: {wreck.get('loss_cause', 'unknown cause')}",
                        "details": {
                            "wreck_id": wreck.get("wreck_id"),
                            "loss_cause": wreck.get("loss_cause"),
                            "loss_location": wreck.get("loss_location"),
                            "region": wreck.get("region"),
                        },
                        "position": pos,
                        "source": "maarer",
                    }
                )

        # --- Arrival event ---
        arrival_date = voyage.get("arrival_date")
        dest_port = voyage.get("destination_port", "Unknown")
        if arrival_date and voyage.get("fate") != "wrecked":
            events.append(
                {
                    "date": arrival_date,
                    "type": "arrival",
                    "title": f"Arrived {dest_port}",
                    "details": {
                        "port": dest_port,
                    },
                    "position": None,
                    "source": "das",
                }
            )

        # Sort events chronologically
        events.sort(key=lambda e: e["date"])

        # Build GeoJSON LineString from positioned events
        geojson = None
        positioned = [
            e for e in events if e.get("position") and e["position"].get("lat") is not None
        ]
        if len(positioned) >= 2:
            coords = [[e["position"]["lon"], e["position"]["lat"]] for e in positioned]
            geojson = {
                "type": "Feature",
                "geometry": {
                    "type": "LineString",
                    "coordinates": coords,
                },
                "properties": {
                    "voyage_id": voyage_id,
                    "ship_name": ship_name,
                    "point_count": len(coords),
                },
            }

        return {
            "voyage_id": voyage_id,
            "ship_name": ship_name,
            "events": events,
            "data_sources": data_sources,
            "geojson": geojson,
        }

    # --- Wreck Operations ---------------------------------------------------

    async def search_wrecks(
        self,
        ship_name: str | None = None,
        date_range: str | None = None,
        region: str | None = None,
        cause: str | None = None,
        status: str | None = None,
        min_depth_m: float | None = None,
        max_depth_m: float | None = None,
        min_cargo_value: float | None = None,
        flag: str | None = None,
        vessel_type: str | None = None,
        gp_quality: int | None = None,
        archive: str | None = None,
        max_results: int = 100,
        cursor: str | None = None,
    ) -> PaginatedResult:
        """Search wreck records across all archives or a specific one."""
        search_kwargs = dict(
            ship_name=ship_name,
            date_range=date_range,
            region=region,
            cause=cause,
            status=status,
            min_depth_m=min_depth_m,
            max_depth_m=max_depth_m,
            min_cargo_value=min_cargo_value,
            flag=flag,
            vessel_type=vessel_type,
            gp_quality=gp_quality,
            max_results=_FETCH_ALL,
        )

        if archive and archive in self._wreck_clients:
            client = self._wreck_clients[archive]
            if hasattr(client, "search_wrecks"):
                results = await client.search_wrecks(**search_kwargs)
            else:
                results = await client.search(**search_kwargs)
        elif archive:
            results = []
        else:
            # Query all wreck archives and merge results
            results = []
            for client in self._wreck_clients.values():
                if hasattr(client, "search_wrecks"):
                    results.extend(await client.search_wrecks(**search_kwargs))
                else:
                    results.extend(await client.search(**search_kwargs))
            # Deterministic sort for stable pagination across archives
            results.sort(key=lambda w: (w.get("loss_date") or "9999", w.get("wreck_id", "")))

        return self._paginate(results, max_results, cursor)

    async def get_wreck(self, wreck_id: str) -> dict | None:
        """Get full wreck record, routing to the correct archive client."""
        # Determine which client handles this wreck ID
        if wreck_id.startswith("maarer:"):
            return await self._wreck_client.get_by_id(wreck_id)

        # Check compound prefixes: eic_wreck:, carreira_wreck:, etc.
        for prefix, client in [
            ("eic_wreck:", self._eic_client),
            ("carreira_wreck:", self._carreira_client),
            ("galleon_wreck:", self._galleon_client),
            ("soic_wreck:", self._soic_client),
            ("ukho_wreck:", self._ukho_client),
            ("noaa_wreck:", self._noaa_client),
        ]:
            if wreck_id.startswith(prefix):
                return await client.get_wreck_by_id(wreck_id)

        # Default to MAARER
        return await self._wreck_client.get_by_id(wreck_id)

    # --- Narrative Search ---------------------------------------------------

    @staticmethod
    def _parse_query_terms(query: str) -> list[str]:
        """Parse a query string into terms, respecting quoted phrases."""
        terms: list[str] = []
        remaining = query.strip()
        while remaining:
            if remaining[0] == '"':
                end = remaining.find('"', 1)
                if end == -1:
                    # Unmatched quote — treat rest as one term
                    terms.append(remaining[1:].strip())
                    break
                terms.append(remaining[1:end])
                remaining = remaining[end + 1 :].strip()
            else:
                parts = remaining.split(None, 1)
                terms.append(parts[0])
                remaining = parts[1] if len(parts) > 1 else ""
        return [t for t in terms if t]

    @staticmethod
    def _extract_snippet(text: str, terms: list[str], max_len: int = 200) -> str:
        """Extract a snippet around the first matching term."""
        text_lower = text.lower()
        best_pos = len(text)
        for term in terms:
            pos = text_lower.find(term.lower())
            if pos != -1 and pos < best_pos:
                best_pos = pos
        if best_pos == len(text):
            # No exact match found; return start of text
            return text[:max_len].strip()
        # Centre the snippet around the match
        half = max_len // 2
        start = max(0, best_pos - half)
        end = min(len(text), start + max_len)
        return text[start:end].strip()

    @staticmethod
    def _count_matches(text_lower: str, terms_lower: list[str]) -> int:
        """Count total occurrences of all terms in lowered text."""
        count = 0
        for term in terms_lower:
            start = 0
            while True:
                pos = text_lower.find(term, start)
                if pos == -1:
                    break
                count += 1
                start = pos + len(term)
        return count

    async def search_narratives(
        self,
        query: str,
        record_type: str | None = None,
        archive: str | None = None,
        max_results: int = 50,
        cursor: str | None = None,
    ) -> PaginatedResult:
        """
        Search free-text narrative fields across all archives.

        Scans voyage ``particulars`` and wreck ``particulars`` / ``loss_location``
        fields for matching terms.  All query terms must be present (AND logic).
        Quoted phrases are matched exactly.
        """
        terms = self._parse_query_terms(query)
        if not terms:
            return PaginatedResult(items=[], total_count=0, next_cursor=None, has_more=False)

        terms_lower = [t.lower() for t in terms]
        hits: list[dict] = []

        # --- Scan voyages ---
        if record_type in (None, "voyage"):
            voyage_clients = (
                {archive: self._voyage_clients[archive]}
                if archive and archive in self._voyage_clients
                else (
                    {} if archive and archive not in self._voyage_clients else self._voyage_clients
                )
            )
            for arc_id, client in voyage_clients.items():
                voyages = await client.search(max_results=_FETCH_ALL)
                for v in voyages:
                    text = v.get("particulars") or ""
                    if not text:
                        continue
                    text_lower = text.lower()
                    # All terms must be present (AND logic)
                    if not all(t in text_lower for t in terms_lower):
                        continue
                    match_count = self._count_matches(text_lower, terms_lower)
                    hits.append(
                        {
                            "record_id": v.get("voyage_id", ""),
                            "record_type": "voyage",
                            "archive": arc_id,
                            "ship_name": v.get("ship_name", "Unknown"),
                            "date": v.get("departure_date"),
                            "field": "particulars",
                            "snippet": self._extract_snippet(text, terms),
                            "match_count": match_count,
                        }
                    )

        # --- Scan wrecks ---
        if record_type in (None, "wreck"):
            wreck_clients = (
                {archive: self._wreck_clients[archive]}
                if archive and archive in self._wreck_clients
                else ({} if archive and archive not in self._wreck_clients else self._wreck_clients)
            )
            for arc_id, client in wreck_clients.items():
                if hasattr(client, "search_wrecks"):
                    wrecks = await client.search_wrecks(max_results=_FETCH_ALL)
                else:
                    wrecks = await client.search(max_results=_FETCH_ALL)
                for w in wrecks:
                    # Check both narrative fields
                    for field_name in ("particulars", "loss_location"):
                        text = w.get(field_name) or ""
                        if not text:
                            continue
                        text_lower = text.lower()
                        if not all(t in text_lower for t in terms_lower):
                            continue
                        match_count = self._count_matches(text_lower, terms_lower)
                        hits.append(
                            {
                                "record_id": w.get("wreck_id", ""),
                                "record_type": "wreck",
                                "archive": arc_id,
                                "ship_name": w.get("ship_name", "Unknown"),
                                "date": w.get("loss_date"),
                                "field": field_name,
                                "snippet": self._extract_snippet(text, terms),
                                "match_count": match_count,
                            }
                        )

        # Sort by relevance (match count desc), then date
        hits.sort(key=lambda h: (-h["match_count"], h.get("date") or "9999"))
        return self._paginate(hits, max_results, cursor)

    # --- Vessel Operations --------------------------------------------------

    async def search_vessels(
        self,
        name: str | None = None,
        ship_type: str | None = None,
        built_range: str | None = None,
        shipyard: str | None = None,
        chamber: str | None = None,
        min_tonnage: int | None = None,
        max_tonnage: int | None = None,
        archive: str | None = None,
        max_results: int = 50,
        cursor: str | None = None,
    ) -> PaginatedResult:
        """Search vessel records from local DAS data."""
        results = await self._das_client.search_vessels(
            name=name,
            ship_type=ship_type,
            chamber=chamber,
            min_tonnage=min_tonnage,
            max_tonnage=max_tonnage,
            max_results=_FETCH_ALL,
        )
        return self._paginate(results, max_results, cursor)

    async def get_vessel(self, vessel_id: str) -> dict | None:
        """Get full vessel specification."""
        return await self._das_client.get_vessel_by_id(vessel_id)

    # --- Crew Operations ----------------------------------------------------

    async def search_crew(
        self,
        name: str | None = None,
        rank: str | None = None,
        ship_name: str | None = None,
        voyage_id: str | None = None,
        origin: str | None = None,
        date_range: str | None = None,
        fate: str | None = None,
        archive: str = "voc_crew",
        max_results: int = 100,
        cursor: str | None = None,
    ) -> PaginatedResult:
        """Search crew records across VOC Opvarenden and/or DSS archives."""
        search_kwargs = dict(
            name=name,
            rank=rank,
            ship_name=ship_name,
            voyage_id=voyage_id,
            origin=origin,
            date_range=date_range,
            fate=fate,
            max_results=_FETCH_ALL,
        )

        if archive and archive in self._crew_clients:
            results = await self._crew_clients[archive].search(**search_kwargs)
        elif archive:
            results = []
        else:
            # Query all crew archives and merge results
            results = []
            for client in self._crew_clients.values():
                results.extend(await client.search(**search_kwargs))
            results.sort(
                key=lambda c: (
                    c.get("embarkation_date") or c.get("muster_date") or "9999",
                    c.get("crew_id", ""),
                )
            )

        return self._paginate(results, max_results, cursor)

    async def get_crew_member(self, crew_id: str) -> dict | None:
        """Get full crew member record, routing to the correct archive."""
        if crew_id.startswith("dss:"):
            return await self._dss_client.get_crew_by_id(crew_id)
        return await self._crew_client.get_by_id(crew_id)

    # --- Muster Operations --------------------------------------------------

    async def search_musters(
        self,
        ship_name: str | None = None,
        captain: str | None = None,
        date_range: str | None = None,
        location: str | None = None,
        das_voyage_id: str | None = None,
        year_start: int | None = None,
        year_end: int | None = None,
        max_results: int = 50,
        cursor: str | None = None,
    ) -> PaginatedResult:
        """Search GZMVOC ship-level muster records."""
        results = await self._dss_client.search_musters(
            ship_name=ship_name,
            captain=captain,
            date_range=date_range,
            location=location,
            das_voyage_id=das_voyage_id,
            year_start=year_start,
            year_end=year_end,
            max_results=_FETCH_ALL,
        )
        return self._paginate(results, max_results, cursor)

    async def get_muster(self, muster_id: str) -> dict | None:
        """Get full muster record details."""
        return await self._dss_client.get_muster_by_id(muster_id)

    async def compare_wages(
        self,
        group1_start: int,
        group1_end: int,
        group2_start: int,
        group2_end: int,
        rank: str | None = None,
        origin: str | None = None,
        source: str = "musters",
    ) -> dict:
        """Compare crew wage distributions between two time periods."""
        if source == "crews":
            g1 = await self._dss_client.search_crews(
                rank=rank,
                origin=origin,
                date_range=f"{group1_start}/{group1_end}",
                max_results=_FETCH_ALL,
            )
            g2 = await self._dss_client.search_crews(
                rank=rank,
                origin=origin,
                date_range=f"{group2_start}/{group2_end}",
                max_results=_FETCH_ALL,
            )
            wages1 = [c["monthly_pay_guilders"] for c in g1 if c.get("monthly_pay_guilders")]
            wages2 = [c["monthly_pay_guilders"] for c in g2 if c.get("monthly_pay_guilders")]
        else:
            g1 = await self._dss_client.search_musters(
                year_start=group1_start,
                year_end=group1_end,
                max_results=_FETCH_ALL,
            )
            g2 = await self._dss_client.search_musters(
                year_start=group2_start,
                year_end=group2_end,
                max_results=_FETCH_ALL,
            )
            wages1 = [m["mean_wage_guilders"] for m in g1 if m.get("mean_wage_guilders")]
            wages2 = [m["mean_wage_guilders"] for m in g2 if m.get("mean_wage_guilders")]

        def _stats(values: list[float]) -> tuple[float, float]:
            if not values:
                return 0.0, 0.0
            mean = sum(values) / len(values)
            sorted_v = sorted(values)
            n = len(sorted_v)
            median = sorted_v[n // 2] if n % 2 else (sorted_v[n // 2 - 1] + sorted_v[n // 2]) / 2
            return round(mean, 2), round(median, 2)

        mean1, median1 = _stats(wages1)
        mean2, median2 = _stats(wages2)
        diff_pct = round((mean2 - mean1) / mean1 * 100, 1) if mean1 else 0.0

        return {
            "group1_label": f"{group1_start}-{group1_end}",
            "group1_n": len(wages1),
            "group1_mean_wage": mean1,
            "group1_median_wage": median1,
            "group2_label": f"{group2_start}-{group2_end}",
            "group2_n": len(wages2),
            "group2_mean_wage": mean2,
            "group2_median_wage": median2,
            "difference_pct": diff_pct,
        }

    # --- Cargo Operations ---------------------------------------------------

    async def search_cargo(
        self,
        voyage_id: str | None = None,
        commodity: str | None = None,
        origin: str | None = None,
        destination: str | None = None,
        date_range: str | None = None,
        min_value: float | None = None,
        archive: str = "voc_cargo",
        max_results: int = 100,
        cursor: str | None = None,
    ) -> PaginatedResult:
        """Search cargo manifests."""
        results = await self._cargo_client.search(
            voyage_id=voyage_id,
            commodity=commodity,
            origin=origin,
            destination=destination,
            min_value=min_value,
            max_results=_FETCH_ALL,
        )
        return self._paginate(results, max_results, cursor)

    async def get_cargo_manifest(self, voyage_id: str) -> list[dict]:
        """Get full cargo manifest for a voyage."""
        return await self._cargo_client.search(voyage_id=voyage_id, max_results=1000)

    # --- Hull Profiles ------------------------------------------------------

    def get_hull_profile(self, ship_type: str) -> dict | None:
        """Return hydrodynamic hull profile for a ship type."""
        return self._hull_profiles.get(ship_type)

    def list_hull_profiles(self) -> list[str]:
        """Return available ship types with hull profiles."""
        return list(self._hull_profiles.keys())

    # --- Position Assessment ------------------------------------------------

    async def assess_position(
        self,
        voyage_id: str | None = None,
        wreck_id: str | None = None,
        position: dict | None = None,
        source_description: str | None = None,
        date: str | None = None,
    ) -> dict:
        """Assess quality and uncertainty of a historical position."""
        year = None
        pos = position or {}

        if voyage_id:
            voyage = await self.get_voyage(voyage_id)
            if voyage:
                loss_date = voyage.get("loss_date") or voyage.get("departure_date", "")
                if loss_date and len(loss_date) >= 4:
                    try:
                        year = int(loss_date[:4])
                    except ValueError:
                        pass
                if voyage.get("incident") and voyage["incident"].get("position"):
                    pos = voyage["incident"]["position"]
        elif wreck_id:
            wreck = await self.get_wreck(wreck_id)
            if wreck:
                if wreck.get("loss_date") and len(wreck["loss_date"]) >= 4:
                    year = int(wreck["loss_date"][:4])
                if wreck.get("position"):
                    pos = wreck["position"]
        elif date and len(date) >= 4:
            year = int(date[:4])

        nav_era = self._get_navigation_era(year)

        quality_score = 0.5
        uncertainty_km = nav_era.get("typical_accuracy_km", 50) if nav_era else 50
        uncertainty_type = "approximate"

        if source_description:
            desc_lower = source_description.lower()
            if "gps" in desc_lower or "surveyed" in desc_lower:
                quality_score = 0.95
                uncertainty_km = 0.1
                uncertainty_type = "precise"
            elif "multiple" in desc_lower or "triangulat" in desc_lower:
                quality_score = 0.7
                uncertainty_km = 5
                uncertainty_type = "triangulated"
            elif "dead reckoning" in desc_lower:
                quality_score = 0.4
                uncertainty_km = max(uncertainty_km, 30)
                uncertainty_type = "dead_reckoning"
            elif "approximate" in desc_lower or "general" in desc_lower:
                quality_score = 0.3
                uncertainty_km = 100
                uncertainty_type = "approximate"
            elif "regional" in desc_lower or "straits" in desc_lower:
                quality_score = 0.15
                uncertainty_km = 500
                uncertainty_type = "regional"

        quality_label = (
            "good" if quality_score > 0.7 else ("moderate" if quality_score > 0.4 else "poor")
        )

        return {
            "voyage_id": voyage_id,
            "wreck_id": wreck_id,
            "position": pos,
            "assessment": {
                "quality_score": round(quality_score, 2),
                "quality_label": quality_label,
                "uncertainty_type": uncertainty_type,
                "uncertainty_radius_km": uncertainty_km,
                "confidence": 0.68,
            },
            "factors": {
                "navigation_era": {
                    "year": year,
                    **(nav_era or {}),
                },
                "position_source": {
                    "type": "reconstructed" if not source_description else "described",
                    "description": source_description,
                },
            },
            "recommendations": {
                "for_drift_modelling": (
                    f"Use uncertainty envelope ({uncertainty_km}km radius). "
                    "Run Monte Carlo with position samples from entire "
                    "uncertainty region."
                ),
                "for_search": (
                    f"Search area must account for {uncertainty_km}km position "
                    "uncertainty compounded by drift uncertainty."
                ),
            },
            "comparable_cases": [],
        }

    # --- Statistics ---------------------------------------------------------

    async def get_statistics(
        self,
        archive: str | None = None,
        date_range: str | None = None,
        group_by: str | None = None,
    ) -> dict:
        """Get aggregate statistics across archives."""
        wrecks = (await self.search_wrecks(max_results=10000)).items

        if date_range:
            wrecks = self._filter_by_date_range(wrecks, date_range, "loss_date")

        losses_by_region: dict[str, int] = {}
        losses_by_cause: dict[str, int] = {}
        losses_by_status: dict[str, int] = {}
        losses_by_decade: dict[str, int] = {}
        total_lives_lost = 0
        total_cargo_value = 0

        for w in wrecks:
            region = w.get("region", "other")
            losses_by_region[region] = losses_by_region.get(region, 0) + 1

            cause = w.get("loss_cause", "unknown")
            losses_by_cause[cause] = losses_by_cause.get(cause, 0) + 1

            status = w.get("status", "unknown")
            losses_by_status[status] = losses_by_status.get(status, 0) + 1

            loss_date = w.get("loss_date", "")
            if loss_date and len(loss_date) >= 4:
                decade = f"{loss_date[:3]}0s"
                losses_by_decade[decade] = losses_by_decade.get(decade, 0) + 1

            total_lives_lost += w.get("lives_lost", 0) or 0
            total_cargo_value += w.get("cargo_value_guilders", 0) or 0

        return {
            "archives_included": [archive] if archive else list(self._wreck_clients.keys()),
            "date_range": date_range or "all",
            "summary": {
                "total_losses": len(wrecks),
                "lives_lost_total": total_lives_lost,
                "cargo_value_guilders_total": total_cargo_value,
            },
            "losses_by_region": losses_by_region,
            "losses_by_cause": losses_by_cause,
            "losses_by_status": losses_by_status,
            "losses_by_decade": dict(sorted(losses_by_decade.items())),
        }

    # --- GeoJSON Export -----------------------------------------------------

    async def export_geojson(
        self,
        wreck_ids: list[str] | None = None,
        region: str | None = None,
        status: str | None = None,
        archive: str | None = None,
        include_uncertainty: bool = True,
        include_voyage_data: bool = True,
    ) -> dict:
        """Export wreck positions as GeoJSON FeatureCollection."""
        if wreck_ids:
            wrecks = []
            for wid in wreck_ids:
                w = await self.get_wreck(wid)
                if w:
                    wrecks.append(w)
        else:
            wrecks = (
                await self.search_wrecks(
                    region=region, status=status, archive=archive, max_results=10000
                )
            ).items

        features = []
        for w in wrecks:
            pos = w.get("position", {})
            lat = pos.get("lat") if pos else None
            lon = pos.get("lon") if pos else None
            has_position = lat is not None and lon is not None

            properties: dict[str, Any] = {
                "wreck_id": w.get("wreck_id"),
                "ship_name": w.get("ship_name"),
                "loss_date": w.get("loss_date"),
                "loss_location": w.get("loss_location"),
                "region": w.get("region"),
                "status": w.get("status"),
            }

            if include_uncertainty and has_position:
                properties["uncertainty_km"] = pos.get("uncertainty_km", 50)

            if include_voyage_data:
                properties["ship_type"] = w.get("ship_type")
                properties["tonnage"] = w.get("tonnage")
                properties["loss_cause"] = w.get("loss_cause")
                properties["lives_lost"] = w.get("lives_lost")
                properties["depth_m"] = w.get("depth_estimate_m")

            # Use null geometry for wrecks without known coordinates
            geometry: dict[str, Any] | None = (
                {"type": "Point", "coordinates": [lon, lat]} if has_position else None
            )

            features.append(
                {
                    "type": "Feature",
                    "geometry": geometry,
                    "properties": properties,
                }
            )

        return {
            "type": "FeatureCollection",
            "features": features,
        }

    # --- Crew Demographics / Career / Survival -------------------------------

    _DEMOGRAPHICS_GROUP_BY = {"rank", "origin", "fate", "decade", "ship_name"}

    @staticmethod
    def _crew_group_key(record: dict, group_by: str) -> str:
        """Extract the grouping value from a crew record."""
        if group_by == "rank":
            return record.get("rank") or "unknown"
        if group_by == "origin":
            return record.get("origin") or "unknown"
        if group_by == "fate":
            return record.get("service_end_reason") or "unknown"
        if group_by == "decade":
            date = record.get("embarkation_date") or ""
            if len(date) >= 4:
                try:
                    year = int(date[:4])
                    return f"{year // 10 * 10}s"
                except ValueError:
                    pass
            return "unknown"
        if group_by == "ship_name":
            return record.get("ship_name") or "unknown"
        return "unknown"

    def _apply_crew_filters(
        self,
        records: list[dict],
        *,
        date_range: str | None = None,
        rank: str | None = None,
        origin: str | None = None,
        fate: str | None = None,
        ship_name: str | None = None,
    ) -> list[dict]:
        """Apply optional filters to crew records."""
        if rank:
            records = [r for r in records if self._contains(r.get("rank"), rank)]
        if origin:
            records = [r for r in records if self._contains(r.get("origin"), origin)]
        if fate:
            records = [r for r in records if r.get("service_end_reason") == fate]
        if ship_name:
            records = [r for r in records if self._contains(r.get("ship_name"), ship_name)]
        if date_range:
            records = self._filter_by_date_range(records, date_range, "embarkation_date")
        return records

    @staticmethod
    def _contains(haystack: str | None, needle: str) -> bool:
        """Case-insensitive substring match."""
        if not haystack:
            return False
        return needle.lower() in haystack.lower()

    def crew_demographics(
        self,
        group_by: str = "rank",
        *,
        date_range: str | None = None,
        rank: str | None = None,
        origin: str | None = None,
        fate: str | None = None,
        ship_name: str | None = None,
        top_n: int = 25,
    ) -> dict:
        """Aggregate crew demographics by a chosen dimension."""
        if group_by not in self._DEMOGRAPHICS_GROUP_BY:
            raise ValueError(
                f"Invalid group_by '{group_by}'. "
                f"Valid: {', '.join(sorted(self._DEMOGRAPHICS_GROUP_BY))}"
            )

        all_records = self._crew_client.all_records()
        total_records = len(all_records)
        filtered = self._apply_crew_filters(
            all_records,
            date_range=date_range,
            rank=rank,
            origin=origin,
            fate=fate,
            ship_name=ship_name,
        )
        total_filtered = len(filtered)

        # Group
        groups: dict[str, dict] = {}
        for rec in filtered:
            key = self._crew_group_key(rec, group_by)
            if key not in groups:
                groups[key] = {"count": 0, "fate_distribution": {}}
            groups[key]["count"] += 1
            fate_val = rec.get("service_end_reason") or "unknown"
            groups[key]["fate_distribution"][fate_val] = (
                groups[key]["fate_distribution"].get(fate_val, 0) + 1
            )

        # Sort descending by count
        sorted_groups = sorted(groups.items(), key=lambda x: x[1]["count"], reverse=True)

        # Apply top_n
        top_groups = sorted_groups[:top_n]
        other_count = sum(g[1]["count"] for g in sorted_groups[top_n:])

        result_groups = []
        for key, data in top_groups:
            pct = round(data["count"] / total_filtered * 100, 1) if total_filtered else 0.0
            result_groups.append(
                {
                    "group_key": key,
                    "count": data["count"],
                    "percentage": pct,
                    "fate_distribution": data["fate_distribution"],
                }
            )

        filters_applied: dict[str, str] = {}
        if date_range:
            filters_applied["date_range"] = date_range
        if rank:
            filters_applied["rank"] = rank
        if origin:
            filters_applied["origin"] = origin
        if fate:
            filters_applied["fate"] = fate
        if ship_name:
            filters_applied["ship_name"] = ship_name

        return {
            "total_records": total_records,
            "total_filtered": total_filtered,
            "group_by": group_by,
            "group_count": len(top_groups),
            "groups": result_groups,
            "other_count": other_count,
            "filters_applied": filters_applied,
        }

    def crew_career(
        self,
        name: str,
        origin: str | None = None,
    ) -> dict:
        """Reconstruct career(s) for individuals matching a name."""
        all_records = self._crew_client.all_records()

        # Filter by name substring
        matches = [r for r in all_records if self._contains(r.get("name"), name)]
        if origin:
            matches = [r for r in matches if r.get("origin", "").lower() == origin.lower()]

        total_matches = len(matches)

        # Group by (name_lower, origin_lower) to identify distinct individuals
        individuals: dict[tuple[str, str], list[dict]] = {}
        for rec in matches:
            key = (rec.get("name", "").lower(), (rec.get("origin") or "unknown").lower())
            if key not in individuals:
                individuals[key] = []
            individuals[key].append(rec)

        # Build career records (cap at 10 individuals)
        career_records = []
        for (_name_key, _origin_key), voyages in sorted(individuals.items())[:10]:
            # Sort voyages chronologically
            voyages.sort(key=lambda v: v.get("embarkation_date") or "9999")
            voyages = voyages[:50]  # Cap per individual

            dates = [v.get("embarkation_date") for v in voyages if v.get("embarkation_date")]
            first_date = dates[0] if dates else None
            last_date = dates[-1] if dates else None

            career_span = None
            if first_date and last_date and len(first_date) >= 4 and len(last_date) >= 4:
                try:
                    span = int(last_date[:4]) - int(first_date[:4])
                    career_span = round(span + 0.5, 1) if span > 0 else 0.0
                except ValueError:
                    pass

            # Ordered unique ranks and ships
            ranks_seen: list[str] = []
            ships_seen: list[str] = []
            for v in voyages:
                r = v.get("rank")
                if r and r not in ranks_seen:
                    ranks_seen.append(r)
                s = v.get("ship_name")
                if s and s not in ships_seen:
                    ships_seen.append(s)

            final_fate = voyages[-1].get("service_end_reason") if voyages else None

            career_records.append(
                {
                    "name": voyages[0].get("name", ""),
                    "origin": voyages[0].get("origin"),
                    "voyage_count": len(voyages),
                    "first_date": first_date,
                    "last_date": last_date,
                    "career_span_years": career_span,
                    "distinct_ships": ships_seen,
                    "ranks_held": ranks_seen,
                    "final_fate": final_fate,
                    "voyages": [
                        {
                            "crew_id": v.get("crew_id", ""),
                            "ship_name": v.get("ship_name"),
                            "voyage_id": v.get("voyage_id"),
                            "rank": v.get("rank"),
                            "embarkation_date": v.get("embarkation_date"),
                            "service_end_reason": v.get("service_end_reason"),
                        }
                        for v in voyages
                    ],
                }
            )

        return {
            "query_name": name,
            "query_origin": origin,
            "individual_count": len(career_records),
            "total_matches": total_matches,
            "individuals": career_records,
        }

    def crew_survival(
        self,
        group_by: str = "rank",
        *,
        date_range: str | None = None,
        rank: str | None = None,
        origin: str | None = None,
        top_n: int = 25,
    ) -> dict:
        """Compute survival / mortality / desertion rates by dimension."""
        if group_by not in self._DEMOGRAPHICS_GROUP_BY:
            raise ValueError(
                f"Invalid group_by '{group_by}'. "
                f"Valid: {', '.join(sorted(self._DEMOGRAPHICS_GROUP_BY))}"
            )

        all_records = self._crew_client.all_records()
        total_records = len(all_records)
        filtered = self._apply_crew_filters(
            all_records,
            date_range=date_range,
            rank=rank,
            origin=origin,
        )

        # Only records with known fate
        known_fate_map = {
            "returned": "survived",
            "survived": "survived",
            "died_voyage": "died_voyage",
            "died_asia": "died_asia",
            "deserted": "deserted",
            "discharged": "discharged",
        }
        with_fate = [r for r in filtered if r.get("service_end_reason") in known_fate_map]
        total_with_known_fate = len(with_fate)

        # Group
        groups: dict[str, dict[str, int]] = {}
        for rec in with_fate:
            key = self._crew_group_key(rec, group_by)
            if key not in groups:
                groups[key] = {
                    "total": 0,
                    "survived": 0,
                    "died_voyage": 0,
                    "died_asia": 0,
                    "deserted": 0,
                    "discharged": 0,
                }
            groups[key]["total"] += 1
            category = known_fate_map[rec["service_end_reason"]]
            groups[key][category] += 1

        # Sort descending by total
        sorted_groups = sorted(groups.items(), key=lambda x: x[1]["total"], reverse=True)
        top_groups = sorted_groups[:top_n]

        result_groups = []
        for key, data in top_groups:
            total = data["total"]
            if total == 0:
                continue
            result_groups.append(
                {
                    "group_key": key,
                    "total": total,
                    "survived": data["survived"],
                    "died_voyage": data["died_voyage"],
                    "died_asia": data["died_asia"],
                    "deserted": data["deserted"],
                    "discharged": data["discharged"],
                    "survival_rate": round(data["survived"] / total * 100, 1),
                    "mortality_rate": round(
                        (data["died_voyage"] + data["died_asia"]) / total * 100, 1
                    ),
                    "desertion_rate": round(data["deserted"] / total * 100, 1),
                }
            )

        filters_applied: dict[str, str] = {}
        if date_range:
            filters_applied["date_range"] = date_range
        if rank:
            filters_applied["rank"] = rank
        if origin:
            filters_applied["origin"] = origin

        return {
            "total_records": total_records,
            "total_with_known_fate": total_with_known_fate,
            "group_by": group_by,
            "group_count": len(result_groups),
            "groups": result_groups,
            "filters_applied": filters_applied,
        }

    # --- Private Helpers ----------------------------------------------------

    def _get_navigation_era(self, year: int | None) -> dict | None:
        """Look up navigation technology for a given year."""
        if year is None:
            return None
        for era_range, era_data in NAVIGATION_ERAS.items():
            start, end = era_range.split("-")
            if int(start) <= year <= int(end):
                return era_data
        return None

    def _filter_by_date_range(
        self, records: list[dict], date_range: str, date_field: str
    ) -> list[dict]:
        """Filter records by date range (YYYY/YYYY or YYYY-MM-DD/YYYY-MM-DD)."""
        parts = date_range.split("/")
        if len(parts) != 2:
            return records

        start_str, end_str = parts
        start_year = int(start_str[:4]) if len(start_str) >= 4 else 0
        end_year = int(end_str[:4]) if len(end_str) >= 4 else 9999

        filtered = []
        for r in records:
            date_val = r.get(date_field, "")
            if date_val and len(date_val) >= 4:
                try:
                    record_year = int(date_val[:4])
                except ValueError:
                    continue
                if start_year <= record_year <= end_year:
                    filtered.append(r)
        return filtered
