"""Archive data source clients."""

from .base import BaseArchiveClient
from .cargo_client import CargoClient
from .carreira_client import CarreiraClient
from .crew_client import CrewClient
from .das_client import DASClient
from .dss_client import DSSClient
from .eic_client import EICClient
from .galleon_client import GalleonClient
from .noaa_client import NOAAClient
from .soic_client import SOICClient
from .ukho_client import UKHOClient
from .wreck_client import WreckClient

__all__ = [
    "BaseArchiveClient",
    "CargoClient",
    "CarreiraClient",
    "CrewClient",
    "DASClient",
    "DSSClient",
    "EICClient",
    "GalleonClient",
    "NOAAClient",
    "SOICClient",
    "UKHOClient",
    "WreckClient",
]
