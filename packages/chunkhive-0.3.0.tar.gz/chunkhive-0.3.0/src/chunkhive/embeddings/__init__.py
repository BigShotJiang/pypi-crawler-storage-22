"""
ChunkHive Embeddings Module
============================

Semantic embeddings and vector search for code chunks.
"""

from .embedding_engine import (
    SemanticEmbeddingEngine,
    VectorSearchIndex,
    ModelConfig,
    AVAILABLE_MODELS,
    embed_chunks,
    create_search_index,
)

__all__ = [
    "SemanticEmbeddingEngine",
    "VectorSearchIndex",
    "ModelConfig",
    "AVAILABLE_MODELS",
    "embed_chunks",
    "create_search_index",
]