"""
ChunkHive Semantic Embedding Engine
====================================

Generate and manage vector embeddings for code chunks to enable semantic search,
similarity matching, and AI-powered code understanding.

This module provides embeddings using state-of-the-art code-specific models
like Microsoft's CodeBERT and similar transformers optimized for source code.

Author: ChunkHive
License: Apache 2.0
Version: 0.2.0
"""

from typing import List, Dict, Optional, Tuple, Any, TYPE_CHECKING
from pathlib import Path
import logging
import json
import pickle
from dataclasses import dataclass
import numpy as np

# Type checking imports (won't run at runtime if not installed)
if TYPE_CHECKING:
    from sentence_transformers import SentenceTransformer as ST
    import faiss as faiss_type
else:
    ST = Any
    faiss_type = Any

# Try to import actual libraries
try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False
    SentenceTransformer = Any  # type: ignore

try:
    import faiss  # type: ignore
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False
    faiss = Any  # type: ignore

from ..chunkers.schema import SemanticChunk


logger = logging.getLogger(__name__)


# =============================================================================
# EMBEDDING MODEL CONFIGURATIONS
# =============================================================================

@dataclass
class ModelConfig:
    """Configuration for an embedding model."""
    name: str
    model_id: str
    dimension: int
    description: str
    best_for: str


# Available pre-configured models
AVAILABLE_MODELS = {
    "codebert": ModelConfig(
        name="codebert",
        model_id="microsoft/codebert-base",
        dimension=768,
        description="Microsoft's CodeBERT - trained on code and documentation",
        best_for="General purpose code embedding"
    ),
    "unixcoder": ModelConfig(
        name="unixcoder",
        model_id="microsoft/unixcoder-base",
        dimension=768,
        description="Microsoft's UniXcoder - unified cross-modal pre-training",
        best_for="Code-to-code and code-to-text matching"
    ),
    "codesage": ModelConfig(
        name="codesage",
        model_id="codesage/codesage-small",
        dimension=1024,
        description="CodeSage - optimized for code understanding",
        best_for="Semantic code search and retrieval"
    ),
    "minilm": ModelConfig(
        name="minilm",
        model_id="sentence-transformers/all-MiniLM-L6-v2",
        dimension=384,
        description="Fast and lightweight general-purpose model",
        best_for="Quick prototyping and testing"
    ),
}


# =============================================================================
# SEMANTIC EMBEDDING ENGINE
# =============================================================================

class SemanticEmbeddingEngine:
    """
    Generate semantic vector embeddings for code chunks.
    
    This engine converts code chunks into dense vector representations that
    capture semantic meaning, enabling similarity search, clustering, and
    AI-powered code understanding.
    
    Features:
    - Multiple pre-trained models optimized for code
    - Batch processing for efficiency
    - Caching for faster repeated operations
    - FAISS integration for fast similarity search
    
    Attributes:
        model_name: Name of the embedding model being used
        dimension: Dimensionality of the embedding vectors
        model: The underlying sentence-transformer model
        
    Example:
        >>> engine = SemanticEmbeddingEngine(model_name="codebert")
        >>> chunks = [chunk1, chunk2, chunk3]
        >>> embeddings = engine.generate_embeddings(chunks)
        >>> print(f"Generated {len(embeddings)} embeddings")
    """
    
    def __init__(
        self,
        model_name: str = "minilm",
        device: str = "cpu",
        cache_dir: Optional[Path] = None
    ):
        """
        Initialize the semantic embedding engine.
        
        Args:
            model_name: Name of model to use (see AVAILABLE_MODELS)
            device: Device to run model on ('cpu' or 'cuda')
            cache_dir: Directory to cache model files
            
        Raises:
            ImportError: If sentence-transformers not installed
            ValueError: If model_name not recognized
        """
        if not SENTENCE_TRANSFORMERS_AVAILABLE:
            raise ImportError(
                "sentence-transformers not installed. "
                "Install with: pip install sentence-transformers"
            )
        
        if model_name not in AVAILABLE_MODELS:
            raise ValueError(
                f"Unknown model: {model_name}. "
                f"Available: {list(AVAILABLE_MODELS.keys())}"
            )
        
        self.model_config = AVAILABLE_MODELS[model_name]
        self.model_name = model_name
        self.dimension = self.model_config.dimension
        # self.dimension = self.model.get_sentence_embedding_dimension()

        self.device = device
        
        logger.info(f"Loading embedding model: {self.model_config.model_id}")
        
        try:
            self.model: Any = SentenceTransformer(  # type: ignore
                self.model_config.model_id,
                device=device,
                cache_folder=str(cache_dir) if cache_dir else None
            )
            logger.info(f"Model loaded successfully on {device}")
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            raise
    
    def generate_embeddings(
        self,
        chunks: List[SemanticChunk],
        batch_size: int = 32,
        show_progress: bool = True
    ) -> np.ndarray:
        """
        Generate embeddings for a list of code chunks.
        
        Args:
            chunks: List of SemanticChunk objects to embed
            batch_size: Number of chunks to process at once
            show_progress: Show progress bar during generation
            
        Returns:
            NumPy array of shape (len(chunks), dimension) containing embeddings
            
        Example:
            >>> engine = SemanticEmbeddingEngine()
            >>> embeddings = engine.generate_embeddings(chunks, batch_size=64)
            >>> print(embeddings.shape)  # (100, 768) for 100 chunks
        """
        if not chunks:
            return np.array([])
        
        logger.info(f"Generating embeddings for {len(chunks)} chunks")
        
        # Prepare texts for embedding (combine code + docstring)
        texts = []
        for chunk in chunks:
            # Create rich text representation
            text_parts = []
            
            # Add function/class name if available
            if chunk.ast.name:
                text_parts.append(f"Function: {chunk.ast.name}")
            
            # Add docstring if available
            if chunk.ast.docstring:
                text_parts.append(chunk.ast.docstring)
            
            # Add code
            text_parts.append(chunk.code)
            
            # Combine all parts
            full_text = "\n".join(text_parts)
            texts.append(full_text)
        
        # Generate embeddings
        try:
            embeddings = self.model.encode(  # type: ignore
                texts,
                batch_size=batch_size,
                show_progress_bar=show_progress,
                convert_to_numpy=True,
                normalize_embeddings=True  # L2 normalization
            )
            
            logger.info(f"Generated embeddings with shape: {embeddings.shape}")
            return embeddings  # type: ignore
            
        except Exception as e:
            logger.error(f"Error generating embeddings: {e}")
            raise
    
    def generate_embedding_for_query(self, query: str) -> np.ndarray:
        """
        Generate embedding for a search query.
        
        Args:
            query: Natural language query or code snippet
            
        Returns:
            NumPy array of shape (dimension,) containing the query embedding
            
        Example:
            >>> engine = SemanticEmbeddingEngine()
            >>> query_embedding = engine.generate_embedding_for_query(
            ...     "function to authenticate user"
            ... )
        """
        try:
            embedding = self.model.encode(  # type: ignore
                [query],
                convert_to_numpy=True,
                normalize_embeddings=True
            )
            return embedding[0]  # type: ignore
        except Exception as e:
            logger.error(f"Error generating query embedding: {e}")
            raise
    
    def attach_embeddings_to_chunks(
        self,
        chunks: List[SemanticChunk],
        embeddings: np.ndarray
    ) -> None:
        """
        Attach generated embeddings to chunk objects.
        
        Modifies chunks in-place by adding embedding and model info.
        
        Args:
            chunks: List of SemanticChunk objects
            embeddings: Array of embeddings matching chunks
            
        Example:
            >>> engine = SemanticEmbeddingEngine()
            >>> embeddings = engine.generate_embeddings(chunks)
            >>> engine.attach_embeddings_to_chunks(chunks, embeddings)
            >>> print(chunks[0].has_embedding())  # True
        """
        if len(chunks) != len(embeddings):
            raise ValueError(
                f"Mismatch: {len(chunks)} chunks vs {len(embeddings)} embeddings"
            )
        
        for chunk, embedding in zip(chunks, embeddings):
            chunk.embedding = embedding.tolist()
            chunk.embedding_model = self.model_config.model_id
        
        logger.info(f"Attached embeddings to {len(chunks)} chunks")


# =============================================================================
# VECTOR SEARCH INDEX
# =============================================================================

class VectorSearchIndex:
    """
    Fast similarity search using FAISS.
    
    Provides efficient k-nearest-neighbor search over code embeddings,
    enabling semantic code search and similarity matching.
    
    Features:
    - Fast approximate nearest neighbor search
    - Exact search for smaller datasets
    - Save/load index to disk
    - Multiple distance metrics
    
    Example:
        >>> index = VectorSearchIndex(dimension=768)
        >>> index.add_embeddings(embeddings, chunks)
        >>> results = index.search("authenticate user", engine, k=5)
    """
    
    def __init__(
        self,
        dimension: int,
        use_gpu: bool = False,
        index_type: str = "flat"
    ):
        """
        Initialize vector search index.
        
        Args:
            dimension: Dimension of embedding vectors
            use_gpu: Use GPU acceleration if available
            index_type: Type of index ('flat' for exact, 'ivf' for approximate)
            
        Raises:
            ImportError: If FAISS not installed
        """
        if not FAISS_AVAILABLE:
            raise ImportError(
                "faiss not installed. "
                "Install with: pip install faiss-cpu (or faiss-gpu)"
            )
        
        self.dimension = dimension
        self.use_gpu = use_gpu
        self.index_type = index_type
        self.chunks: List[SemanticChunk] = []
        
        # Create FAISS index
        if index_type == "flat":
            # Exact search (good for <100k vectors)
            self.index: Any = faiss.IndexFlatL2(dimension)  # type: ignore
        elif index_type == "ivf":
            # Approximate search (good for >100k vectors)
            quantizer: Any = faiss.IndexFlatL2(dimension)  # type: ignore
            self.index = faiss.IndexIVFFlat(quantizer, dimension, 100)  # type: ignore
        else:
            raise ValueError(f"Unknown index type: {index_type}")
        
        if use_gpu and hasattr(faiss, 'get_num_gpus') and faiss.get_num_gpus() > 0:  # type: ignore
            logger.info("Using GPU for FAISS index")
            self.index = faiss.index_cpu_to_gpu(  # type: ignore
                faiss.StandardGpuResources(), 0, self.index  # type: ignore
            )
        
        logger.info(f"Created {index_type} FAISS index (dimension={dimension})")
    
    def add_embeddings(
        self,
        embeddings: np.ndarray,
        chunks: List[SemanticChunk]
    ) -> None:
        """
        Add embeddings and their corresponding chunks to the index.
        
        Args:
            embeddings: Array of shape (n, dimension)
            chunks: List of n SemanticChunk objects
        """
        if len(embeddings) != len(chunks):
            raise ValueError("Embeddings and chunks must have same length")
        
        # Train index if needed (for IVF)
        if self.index_type == "ivf" and not self.index.is_trained:  # type: ignore
            logger.info("Training IVF index...")
            self.index.train(embeddings.astype('float32'))  # type: ignore
        
        # Add to index
        self.index.add(embeddings.astype('float32'))  # type: ignore
        self.chunks.extend(chunks)
        
        logger.info(f"Added {len(embeddings)} embeddings to index")
        logger.info(f"Total vectors in index: {self.index.ntotal}")  # type: ignore
    
    def search(
        self,
        query: str,
        embedding_engine: SemanticEmbeddingEngine,
        k: int = 5
    ) -> List[Tuple[SemanticChunk, float]]:
        """
        Search for similar code chunks.
        
        Args:
            query: Natural language query or code snippet
            embedding_engine: Engine to generate query embedding
            k: Number of results to return
            
        Returns:
            List of (chunk, distance) tuples, sorted by similarity
            
        Example:
            >>> results = index.search("function to hash password", engine, k=5)
            >>> for chunk, distance in results:
            ...     print(f"{chunk.ast.name}: distance={distance}")
        """
        if self.index.ntotal == 0:  # type: ignore
            logger.warning("Index is empty")
            return []
        
        # Generate query embedding
        query_embedding = embedding_engine.generate_embedding_for_query(query)
        query_embedding_2d = query_embedding.reshape(1, -1).astype('float32')
        
        # Search
        k = min(k, self.index.ntotal)  # Don't request more than available  # type: ignore
        distances, indices = self.index.search(query_embedding_2d, k)  # type: ignore
        
        # Return results
        results = []
        for idx, distance in zip(indices[0], distances[0]):
            if 0 <= idx < len(self.chunks):
                results.append((self.chunks[idx], float(distance)))
        
        return results
    
    def search_by_embedding(
        self,
        embedding: np.ndarray,
        k: int = 5
    ) -> List[Tuple[SemanticChunk, float]]:
        """
        Search using a pre-computed embedding.
        
        Args:
            embedding: Query embedding vector
            k: Number of results to return
            
        Returns:
            List of (chunk, distance) tuples
        """
        if self.index.ntotal == 0:  # type: ignore
            return []
        
        embedding_2d = embedding.reshape(1, -1).astype('float32')
        k = min(k, self.index.ntotal)  # type: ignore
        
        distances, indices = self.index.search(embedding_2d, k)  # type: ignore
        
        results = []
        for idx, distance in zip(indices[0], distances[0]):
            if 0 <= idx < len(self.chunks):
                results.append((self.chunks[idx], float(distance)))
        
        return results
    
    def save(self, path: Path) -> None:
        """Save index and chunks to disk."""
        path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save FAISS index
        faiss.write_index(self.index, str(path.with_suffix('.faiss')))  # type: ignore
        
        # Save chunks
        with open(path.with_suffix('.chunks'), 'wb') as f:
            pickle.dump(self.chunks, f)
        
        logger.info(f"Saved index to {path}")
    
    @classmethod
    def load(cls, path: Path, dimension: int) -> 'VectorSearchIndex':
        """Load index and chunks from disk."""
        # Load FAISS index
        index_obj = cls(dimension=dimension)
        index_obj.index = faiss.read_index(str(path.with_suffix('.faiss')))  # type: ignore
        
        # Load chunks
        with open(path.with_suffix('.chunks'), 'rb') as f:
            index_obj.chunks = pickle.load(f)
        
        logger.info(f"Loaded index from {path}")
        return index_obj


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def embed_chunks(
    chunks: List[SemanticChunk],
    model_name: str = "minilm",
    attach_to_chunks: bool = True
) -> np.ndarray:
    """
    Convenience function to embed chunks.
    
    Args:
        chunks: List of chunks to embed
        model_name: Model to use for embeddings
        attach_to_chunks: Whether to attach embeddings to chunk objects
        
    Returns:
        Array of embeddings
    """
    engine = SemanticEmbeddingEngine(model_name=model_name)
    embeddings = engine.generate_embeddings(chunks)
    
    if attach_to_chunks:
        engine.attach_embeddings_to_chunks(chunks, embeddings)
    
    return embeddings


def create_search_index(
    chunks: List[SemanticChunk],
    model_name: str = "minilm",
    index_type: str = "flat"
) -> Tuple[VectorSearchIndex, SemanticEmbeddingEngine]:
    """
    Convenience function to create a searchable index.
    
    Args:
        chunks: List of chunks to index
        model_name: Model to use for embeddings
        index_type: Type of FAISS index
        
    Returns:
        Tuple of (index, engine) ready for searching
    """
    # Generate embeddings
    engine = SemanticEmbeddingEngine(model_name=model_name)
    embeddings = engine.generate_embeddings(chunks)
    
    # Create index
    index = VectorSearchIndex(dimension=engine.dimension, index_type=index_type)
    index.add_embeddings(embeddings, chunks)
    
    return index, engine


# =============================================================================
# MODULE EXPORTS
# =============================================================================

__all__ = [
    "SemanticEmbeddingEngine",
    "VectorSearchIndex",
    "ModelConfig",
    "AVAILABLE_MODELS",
    "embed_chunks",
    "create_search_index",
]