"""
ChunkHive CLI - Embedding Commands
===================================

New commands for semantic embeddings and vector search.
Add these to your existing cli.py file.
"""

import typer
from pathlib import Path
from typing import Optional
import json


# Add this to your existing app
embed_app = typer.Typer()
# app.add_typer(embed_app, name="embed")  # Add to main app

@embed_app.command("generate")
def generate_embeddings(
    chunks_file: str = typer.Argument(..., help="Path to chunks.jsonl file"),
    output: Optional[str] = typer.Option(None, "-o", "--output", help="Output file path"),
    model: str = typer.Option("minilm", "--model", help="Model to use (minilm, codebert, unixcoder)"),
    batch_size: int = typer.Option(32, "--batch-size", help="Batch size for processing"),
):
    """
    Generate semantic embeddings for code chunks.
    
    Example:
        chunkhive embed generate chunks.jsonl -o chunks_embedded.jsonl
    """
    from rich.console import Console
    from rich.progress import Progress
    console = Console()
    
    try:
        from chunkhive.embeddings import SemanticEmbeddingEngine
        from chunkhive.chunkers.schema import SemanticChunk
        
        console.print(f"[cyan]Loading chunks from {chunks_file}...[/cyan]")
        
        # Load chunks
        chunks = []
        with open(chunks_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    chunk_data = json.loads(line)
                    chunk = SemanticChunk.from_dict(chunk_data)
                    chunks.append(chunk)
        
        console.print(f"[green]✓[/green] Loaded {len(chunks)} chunks")
        
        # Generate embeddings
        console.print(f"[cyan]Generating embeddings using {model}...[/cyan]")
        engine = SemanticEmbeddingEngine(model_name=model)
        embeddings = engine.generate_embeddings(chunks, batch_size=batch_size)
        engine.attach_embeddings_to_chunks(chunks, embeddings)
        
        console.print(f"[green]✓[/green] Generated {len(embeddings)} embeddings")
        
        # Save with embeddings
        output_file = output or chunks_file.replace('.jsonl', '_embedded.jsonl')

        # Create output directory if it doesn't exist
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            for chunk in chunks:
                f.write(json.dumps(chunk.to_dict()) + '\n')

        
        console.print(f"[green]✓[/green] Saved to {output_file}")
        console.print(f"[cyan]Embedding dimension: {engine.dimension}[/cyan]")
        
    except ImportError as e:
        console.print(f"[red]✗[/red] Missing dependencies: {e}")
        console.print("[yellow]Install with: pip install sentence-transformers faiss-cpu[/yellow]")
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}")


@embed_app.command("search")
def search_chunks(
    query: str = typer.Argument(..., help="Search query"),
    chunks_file: str = typer.Option(..., "--chunks", help="Path to chunks.jsonl with embeddings"),
    model: str = typer.Option("minilm", "--model", help="Model used for embeddings"),
    k: int = typer.Option(5, "-k", "--top-k", help="Number of results"),
):
    """
    Search code chunks semantically.
    
    Example:
        chunkhive embed search "authentication function" --chunks chunks_embedded.jsonl
    """
    from rich.console import Console
    from rich.table import Table
    console = Console()
    
    try:
        from chunkhive.embeddings import SemanticEmbeddingEngine, VectorSearchIndex
        from chunkhive.chunkers.schema import SemanticChunk
        import numpy as np
        
        console.print(f"[cyan]Loading chunks from {chunks_file}...[/cyan]")
        
        # Load chunks with embeddings
        chunks = []
        embeddings_list = []
        with open(chunks_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    chunk_data = json.loads(line)
                    chunk = SemanticChunk.from_dict(chunk_data)
                    if chunk.embedding:
                        chunks.append(chunk)
                        embeddings_list.append(chunk.embedding)
        
        if not chunks:
            console.print("[red]✗[/red] No chunks with embeddings found")
            return
        
        embeddings = np.array(embeddings_list)
        console.print(f"[green]✓[/green] Loaded {len(chunks)} chunks with embeddings")
        
        # Create search index
        console.print(f"[cyan]Building search index...[/cyan]")
        engine = SemanticEmbeddingEngine(model_name=model)
        index = VectorSearchIndex(dimension=engine.dimension)
        index.add_embeddings(embeddings, chunks)
        
        # Search
        console.print(f"[cyan]Searching for: '{query}'[/cyan]\n")
        results = index.search(query, engine, k=k)
        
        # Display results
        table = Table(title=f"Top {k} Results")
        table.add_column("#", style="cyan")
        table.add_column("File", style="green")
        table.add_column("Name", style="yellow")
        table.add_column("Type", style="blue")
        table.add_column("Distance", style="magenta")
        
        for i, (chunk, distance) in enumerate(results, 1):
            table.add_row(
                str(i),
                Path(chunk.file_path).name,
                chunk.ast.name or "N/A",
                chunk.chunk_type,
                f"{distance:.4f}"
            )
        
        console.print(table)
        
        # Show code preview for top result
        if results:
            top_chunk, _ = results[0]
            console.print(f"\n[bold]Top Result Code Preview:[/bold]")
            console.print(f"[dim]{top_chunk.get_code_preview(max_lines=10)}[/dim]")
        
    except ImportError as e:
        console.print(f"[red]✗[/red] Missing dependencies: {e}")
        console.print("[yellow]Install with: pip install sentence-transformers faiss-cpu[/yellow]")
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}")
        import traceback
        traceback.print_exc()


@embed_app.command("index")
def build_search_index(
    chunks_file: str = typer.Argument(..., help="Path to chunks.jsonl"),
    output: str = typer.Option("search_index", "-o", "--output", help="Output index path"),
    model: str = typer.Option("minilm", "--model", help="Model to use"),
):
    """
    Build a persistent search index.
    
    Example:
        chunkhive embed index chunks.jsonl -o my_index
    """
    from rich.console import Console
    console = Console()
    
    try:
        from chunkhive.embeddings import create_search_index
        from chunkhive.chunkers.schema import SemanticChunk
        import json
        
        console.print(f"[cyan]Loading chunks...[/cyan]")
        chunks = []
        with open(chunks_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    chunk = SemanticChunk.from_dict(json.loads(line))
                    chunks.append(chunk)
        
        console.print(f"[green]✓[/green] Loaded {len(chunks)} chunks")
        
        # Create index
        console.print(f"[cyan]Building search index with {model}...[/cyan]")
        index, engine = create_search_index(chunks, model_name=model)
        
        # Save
        output_path = Path(output)
        index.save(output_path)
        
        console.print(f"[green]✓[/green] Index saved to {output_path}")
        console.print(f"[cyan]Total vectors: {index.index.ntotal}[/cyan]")
        console.print(f"[cyan]Dimension: {engine.dimension}[/cyan]")
        
    except ImportError as e:
        console.print(f"[red]✗[/red] Missing dependencies: {e}")
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}")


@embed_app.command("models")
def list_models():
    """List available embedding models."""
    from rich.console import Console
    from rich.table import Table
    console = Console()
    
    try:
        from chunkhive.embeddings import AVAILABLE_MODELS
        
        table = Table(title="Available Embedding Models")
        table.add_column("Name", style="cyan")
        table.add_column("Model ID", style="green")
        table.add_column("Dimension", style="yellow")
        table.add_column("Best For", style="blue")
        
        for name, config in AVAILABLE_MODELS.items():
            table.add_row(
                name,
                config.model_id,
                str(config.dimension),
                config.best_for
            )
        
        console.print(table)
        console.print("\n[dim]Usage: chunkhive embed generate chunks.jsonl --model <name>[/dim]")
        
    except ImportError:
        console.print("[red]✗[/red] Embeddings module not available")


# Add these commands to your main CLI app in cli.py:
"""
# In your cli.py, add:

from .embeddings_cli import embed_app
app.add_typer(embed_app, name="embed")
"""
