"""Agent installation for Claude Code."""
