"""Agent and skill templates for Claude Code."""
