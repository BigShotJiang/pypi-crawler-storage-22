"""Agent templates."""
