"""Dart language support for Cicada."""

from cicada.languages.dart.indexer import DartSCIPIndexer

__all__ = ["DartSCIPIndexer"]
