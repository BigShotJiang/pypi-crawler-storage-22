"""Elixir code analysis module."""

from cicada.languages.elixir.parser import ElixirParser

__all__ = ["ElixirParser"]
