"""Go language support for Cicada."""

from cicada.languages.go.indexer import GoSCIPIndexer

__all__ = ["GoSCIPIndexer"]
