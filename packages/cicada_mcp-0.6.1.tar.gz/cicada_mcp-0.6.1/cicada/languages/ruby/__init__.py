"""Ruby language support for Cicada."""

from cicada.languages.ruby.indexer import RubySCIPIndexer

__all__ = ["RubySCIPIndexer"]
