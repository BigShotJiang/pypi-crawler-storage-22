# Manual Publishing to PyPI

## ✅ cich-prompt is READY!

The package builds successfully locally. Here's how to publish manually to PyPI.

## Prerequisites

```bash
python3 -m pip install --user build twine
```

## Step 1: Build the Package

```bash
cd /home/akash/projects/cich/project/python_packages/cich_prompt

# Clean previous builds
rm -rf build dist *.egg-info

# Build source distribution
python3 -m build --sdist

# Build wheel for current platform (Fedora/Linux)
python3 -m build --wheel
```

## Step 2: Test on TestPyPI First

```bash
# Upload to TestPyPI
python3 -m twine upload --repository testpypi dist/*

# Test install
python3 -m pip install --user --index-url https://test.pypi.org/simple/ cich-prompt

# Test it works
python3 -c "from cich_prompt import multiline_input, clipboard; print('Success!')"
```

## Step 3: Publish to Real PyPI

```bash
cd /home/akash/projects/cich/project/python_packages/cich_prompt

# Upload to PyPI
python3 -m twine upload dist/*
```

## PyPI Configuration

Create `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR-API-TOKEN-HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR-TESTPYPI-TOKEN-HERE
```

## Get API Tokens

- **PyPI**: https://pypi.org/manage/account/token/
- **TestPyPI**: https://test.pypi.org/manage/account/token/

## Quick Publish Script

```bash
#!/bin/bash
cd /home/akash/projects/cich/project/python_packages/cich_prompt
rm -rf build dist *.egg-info
python3 -m build
python3 -m twine upload dist/*
```

## Troubleshooting

### "Invalid distribution" error
- Make sure README.md exists
- Check pyproject.toml is valid

### "File already exists" error
- You're trying to upload the same version
- Bump version in pyproject.toml and __init__.py

### Build fails
- Check CMakeLists.txt has `POSITION_INDEPENDENT_CODE ON`
- Make sure pybind11 is installed: `pip install pybind11`

## Current Status

✅ Package builds locally
✅ Import works
✅ Ready for PyPI!

**No GitHub Actions** - Manual publishing only (as requested)
