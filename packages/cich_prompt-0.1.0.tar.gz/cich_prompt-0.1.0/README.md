# cich_prompt

Fast multiline terminal input and clipboard library with C++ core and Python bindings.

## Features

- **Multiline Input**: Advanced terminal input with vim-like editing
  - Ctrl+V or /clip: paste from clipboard
  - Ctrl+N: insert newline
  - Ctrl+W/U/K: delete word/to-start/to-end
  - Arrow keys, Home, End navigation
  - Ctrl+Left/Right: word navigation
  - Ctrl+Up/Down: buffer start/end

- **Clipboard**: Cross-platform clipboard operations
  - Supports X11 (xclip, xsel)
  - Supports Wayland (wl-copy, wl-paste)
  - Supports macOS (pbcopy, pbpaste)
  - Supports tmux clipboard
  - Async clipboard fetching with loading indicator

## Installation

```bash
pip install cich_prompt
```

## Quick Start

### Multiline Input

```python
from cich_prompt import multiline_input

# Get user input
text = multiline_input("Enter text: ")
print(f"You entered: {text}")
```

### Clipboard Operations

```python
from cich_prompt.clipboard import set_text, get_text

# Copy to clipboard
set_text("Hello, clipboard!")

# Paste from clipboard
content = get_text()
print(content)
```

### Edit Existing Text

```python
from cich_prompt import multiline_edit

initial = "Edit this text"
result = multiline_edit("Prompt: ", initial)
if result:
    print(f"Edited: {result}")
```

### Auto-return Mode

```python
from cich_prompt import multiline_input_autoreturn

# Auto-submits when input matches an option
options = ["yes", "no", "maybe"]
choice = multiline_input_autoreturn("Choose: ", options)
```

## Requirements

- Python 3.7+
- Linux or macOS (Windows not yet supported)
- C++17 compiler
- CMake 3.15+ (for building from source)

### Platform-Specific

**Linux**: For clipboard support, install one of:
- `xclip` (X11)
- `xsel` (X11)
- `wl-clipboard` (Wayland)

**macOS**: Built-in clipboard support

**Windows**: Not currently supported (uses Unix terminal APIs)

## Building from Source

```bash
git clone https://github.com/akash-sekhon-1/cich
cd cich/python_packages/cich_prompt
pip install -e .
```

## License

MIT License - see LICENSE file

## Author

Akash Sekhon (akashsekhon.de@gmail.com)

## Links

- GitHub: https://github.com/akash-sekhon-1/cich
- PyPI: https://pypi.org/project/cich_prompt/
