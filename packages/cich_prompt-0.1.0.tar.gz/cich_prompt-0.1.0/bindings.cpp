#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <csignal>
#include <optional>
#include <string>

#include "cich/input/multiline_input.hpp"
#include "cich/system/clipboard.hpp"

namespace py = pybind11;

// Helper to avoid LSP warnings
namespace {
    using clipboard::set_text;
    using clipboard::get_text;
}

// Wrappers that translate std::raise(SIGINT) from the C++ layer into
// Python's KeyboardInterrupt. The native multiline_input functions run
// with the GIL released (so the terminal I/O doesn't block Python
// threads). On Ctrl+C they raise SIGINT, which sets Python's internal
// interrupt flag. We re-acquire the GIL and call PyErr_CheckSignals()
// to turn that flag into a proper KeyboardInterrupt exception.
//
// The wrappers also handle the case where SIGINT was caught by a custom
// handler that didn't set the Python flag — we detect the empty return
// after a signal and force KeyboardInterrupt ourselves.

namespace {

std::string wrapped_multiline_input(const std::string& prompt, int timeout_ms) {
    std::string result;
    {
        py::gil_scoped_release release;
        result = input::multiline_input(prompt, timeout_ms);
    }
    // Back with GIL held. Check if a signal (SIGINT) was raised.
    if (PyErr_CheckSignals() != 0) {
        throw py::error_already_set();
    }
    return result;
}

std::optional<std::string> wrapped_multiline_edit(const std::string& prompt,
                                                   const std::string& initial,
                                                   bool enter_newline,
                                                   int timeout_ms) {
    std::optional<std::string> result;
    {
        py::gil_scoped_release release;
        result = input::multiline_edit(prompt, initial, enter_newline, timeout_ms);
    }
    if (PyErr_CheckSignals() != 0) {
        throw py::error_already_set();
    }
    return result;
}

std::string wrapped_multiline_input_autoreturn(const std::string& prompt,
                                                const std::vector<std::string>& options,
                                                int timeout_ms) {
    std::string result;
    {
        py::gil_scoped_release release;
        result = input::multiline_input_autoreturn(prompt, options, timeout_ms);
    }
    if (PyErr_CheckSignals() != 0) {
        throw py::error_already_set();
    }
    return result;
}

} // namespace

PYBIND11_MODULE(_cich_prompt, m) {
    m.doc() = "CICH Prompt - Input and Clipboard Python Bindings (Native Extension)";

    // Clipboard module
    py::module_ clipboard_module = m.def_submodule("clipboard", "Clipboard operations");

    clipboard_module.def("set_text", &set_text,
        py::arg("text"),
        py::arg("warn_tty") = true,
        py::arg("debug") = false,
        "Set text to system clipboard");

    clipboard_module.def("get_text", &get_text,
        py::arg("warn_tty") = true,
        py::arg("debug") = false,
        "Get text from system clipboard");

    // Input module
    py::module_ input_module = m.def_submodule("input", "Multiline input operations");

    input_module.def("multiline_input", &wrapped_multiline_input,
        py::arg("prompt"),
        py::arg("timeout_ms") = 0,
        "Get multiline input from user with the given prompt.\n"
        "timeout_ms: if > 0, returns get_timeout_sentinel() after this many ms of idle.\n"
        "Ctrl+C raises KeyboardInterrupt.");

    input_module.def("multiline_edit", &wrapped_multiline_edit,
        py::arg("prompt"),
        py::arg("initial"),
        py::arg("enter_newline") = true,
        py::arg("timeout_ms") = 0,
        "Edit existing text with multiline input.\n"
        "Ctrl+A returns get_editing_aborted_sentinel() to abort editing.\n"
        "timeout_ms: if > 0, returns get_timeout_sentinel() after this many ms of idle.\n"
        "Ctrl+C raises KeyboardInterrupt.");

    input_module.def("multiline_input_autoreturn", &wrapped_multiline_input_autoreturn,
        py::arg("prompt"),
        py::arg("options"),
        py::arg("timeout_ms") = 0,
        "Get multiline input with auto-return on matching options.\n"
        "timeout_ms: if > 0, returns get_timeout_sentinel() after this many ms of idle.\n"
        "Ctrl+C raises KeyboardInterrupt.");

    input_module.def("get_timeout_sentinel", []() -> std::string {
        return input::kTimeoutSentinel;
    }, "Returns the sentinel string used to indicate an input timeout (\"CICH_TIMEOUT_ERROR\").");

    input_module.def("get_editing_aborted_sentinel", []() -> std::string {
        return input::kEditingAbortedSentinel;
    }, "Returns the sentinel string used to indicate editing was aborted with Ctrl+A (\"EDITING_ABORTED\").");

    input_module.def("get_help_multiline_input", []() -> std::string {
        return input::kHelpMultilineInput;
    }, "Returns help text for multiline_input mode.");

    input_module.def("get_help_multiline_edit", []() -> std::string {
        return input::kHelpMultilineEdit;
    }, "Returns help text for multiline_edit mode.");

    input_module.def("get_help_multiline_input_autoreturn", []() -> std::string {
        return input::kHelpMultilineInputAutoreturn;
    }, "Returns help text for multiline_input_autoreturn mode.");
}