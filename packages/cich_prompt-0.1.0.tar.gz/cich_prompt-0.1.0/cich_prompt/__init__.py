"""
cich_prompt - Fast multiline input and clipboard library

High-performance terminal input library with:
- Multiline terminal input with advanced editing
- Cross-platform clipboard operations
- Vim-like editing features
- Async clipboard support
"""

__version__ = "0.1.0"

try:
    from . import _cich_prompt as _backend
except ImportError as e:
    raise ImportError(
        f"Failed to import cich_prompt native extension: {e}\n"
        "Make sure the package is properly installed."
    ) from e

# Re-export clipboard module
clipboard = _backend.clipboard

# Re-export input module
input = _backend.input

# Convenience imports
from ._cich_prompt.input import (
    multiline_input,
    multiline_edit,
    multiline_input_autoreturn,
    get_timeout_sentinel,
    get_editing_aborted_sentinel,
    get_help_multiline_input,
    get_help_multiline_edit,
    get_help_multiline_input_autoreturn,
)

from ._cich_prompt.clipboard import (
    set_text,
    get_text,
)

__all__ = [
    "__version__",
    "clipboard",
    "input",
    "multiline_input",
    "multiline_edit",
    "multiline_input_autoreturn",
    "get_timeout_sentinel",
    "get_editing_aborted_sentinel",
    "get_help_multiline_input",
    "get_help_multiline_edit",
    "get_help_multiline_input_autoreturn",
    "set_text",
    "get_text",
]
