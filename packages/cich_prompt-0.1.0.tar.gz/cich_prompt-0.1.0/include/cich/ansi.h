#ifndef CICH_ANSI_H
#define CICH_ANSI_H

#include <string>
#include <string_view>

namespace cich {
namespace ansi {

// ANSI escape codes for formatting
enum class Color {
    Default,
    Black, Red, Green, Yellow, Blue, Magenta, Cyan, White,
    BrightBlack, BrightRed, BrightGreen, BrightYellow, BrightBlue, BrightMagenta, BrightCyan, BrightWhite,
    // Add 256-color support later if needed
};

enum class Style {
    Default,
    Bold, Dim, Italic, Underline, Blink, Inverse, Hidden, Strikethrough,
    ResetBold, ResetDim, ResetItalic, ResetUnderline, ResetBlink, ResetInverse, ResetHidden, ResetStrikethrough
};

// Function to generate ANSI color code
std::string color_code(Color c);

// Function to generate ANSI style code
std::string style_code(Style s);

// Helper to apply color and style
std::string apply_style(std::string_view text, Color foreground = Color::Default, Color background = Color::Default, Style style = Style::Default);
std::string apply_style(std::string_view text, Color foreground, Style style);
std::string apply_style(std::string_view text, Style style);

extern const char* RESET_ALL; // Declare RESET_ALL here

} // namespace ansi
} // namespace cich

#endif // CICH_ANSI_H
