#ifndef CICH_AST_H
#define CICH_AST_H

#include <string>
#include <vector>
#include <memory>
#include <variant>

namespace cich {
namespace ast {

// Forward declare node types
struct Text;
struct Bold; // New
struct Italic; // New
struct CodeSpan; // New
struct Header;
struct Paragraph;
struct Blockquote;
struct List;
struct ListItem;
struct CodeBlock;
struct HorizontalRule;
struct Table;
struct TableRow;
struct TableCell;

// A document is a series of block-level nodes
using BlockNode = std::variant<Header, Paragraph, Blockquote, List, CodeBlock, HorizontalRule, Table>;
using Document = std::vector<BlockNode>;

// --- Inline Elements ---

// Define InlineNode variant
using InlineNode = std::variant<Text, Bold, Italic, CodeSpan>; // New

struct Text {
    std::string value;
};

struct Bold { // New
    std::vector<InlineNode> children;
};

struct Italic { // New
    std::vector<InlineNode> children;
};

struct CodeSpan { // New
    std::string content;
};

// --- Block Elements ---

struct Header {
    int level;
    std::vector<InlineNode> children; // Changed from std::vector<Text>
};

struct Paragraph {
    std::vector<InlineNode> children; // Changed from std::vector<Text>
};

struct Blockquote {
    std::vector<BlockNode> children; // Blockquotes can contain other blocks now
};

enum class ListType { Unordered, Ordered };

struct ListItem {
    std::vector<BlockNode> children; // List items can contain other blocks now
};

struct List {
    ListType type;
    std::vector<ListItem> children;
};

struct CodeBlock {
    std::string language;
    std::string content;
};

struct HorizontalRule {
};

struct TableCell {
    std::string text;
};

struct TableRow {
    std::vector<TableCell> cells;
};

enum class TableAlign { Left, Center, Right };

struct Table {
    TableRow header;
    std::vector<TableAlign> align;
    std::vector<TableRow> rows;
};

} // namespace ast
} // namespace cich

#endif // CICH_AST_H
