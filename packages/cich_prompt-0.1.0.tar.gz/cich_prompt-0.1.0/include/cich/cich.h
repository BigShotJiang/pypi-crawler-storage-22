#ifndef CICH_H
#define CICH_H

#include <string>
#include <string_view>
#include "render_options.h"

namespace cich {

/**
 * @brief Renders a Markdown string into a formatted string with ANSI escape codes.
 *
 * @param markdown_text The Markdown text to render.
 * @return std.string The rendered string.
 */
std::string render(std::string_view markdown_text);
std::string render(std::string_view markdown_text, const RenderOptions& options);

} // namespace cich

#endif // CICH_H
