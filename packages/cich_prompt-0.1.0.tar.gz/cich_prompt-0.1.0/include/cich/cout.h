#ifndef CICH_COUT_H
#define CICH_COUT_H

#include "ansi.h"
#include <string>
#include <string_view>
#include <stdexcept>

namespace cich {


// rename it console
class Cout {
public:
    // --- Basic Colors ---
    static void good(std::string_view text, std::string_view end = "\n");
    static void bad(std::string_view text, std::string_view end = "\n");
    static void yellow(std::string_view text, std::string_view end = "\n");
    static void normal(std::string_view text, std::string_view end = "\n");
    static void dim(std::string_view text, std::string_view end = "\n");
    static void bold(std::string_view text, std::string_view end = "\n");

    // --- Informational ---
    static void info(std::string_view text, std::string_view end = "\n");
    static void debug(std::string_view text, std::string_view end = "\n");
    static void header(std::string_view text, std::string_view end = "\n");
    static void step(std::string_view text, std::string_view end = "\n");
    static void prompt(std::string_view text, std::string_view end = " ");

    // --- Status Banners ---
    static void success(std::string_view text = "Done", std::string_view end = "\n");
    static void fail(std::string_view text = "Failed", std::string_view end = "\n");
    static void warning(std::string_view text = "Warning", std::string_view end = "\n");

    // --- Decorative ---
    static void rule(std::string_view title = "", int width = 0);

    // --- Text Styling ---
    static void highlight(std::string_view text, std::string_view end = "\n");
    static void underline(std::string_view text, std::string_view end = "\n");

    // --- Error ---
    static void fail_raise(std::string_view message, std::string_view end = "\n");

    // --- Markdown ---
    static void markdown(std::string_view text);

    // --- Terminal width detection ---
    static int terminal_width();
};

} // namespace cich

#endif // CICH_COUT_H
