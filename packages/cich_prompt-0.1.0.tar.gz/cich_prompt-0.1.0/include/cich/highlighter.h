#ifndef CICH_HIGHLIGHTER_H
#define CICH_HIGHLIGHTER_H

#include <string>
#include <string_view>
#include <vector>
#include <array>
#include <memory>
#include "ansi.h"

namespace cich {
namespace highlighter {

// --- Utility functions ---
inline bool is_identifier_start(char c) {
    return std::isalpha(static_cast<unsigned char>(c)) || c == '_';
}

inline bool is_identifier_char(char c) {
    return std::isalnum(static_cast<unsigned char>(c)) || c == '_';
}

inline bool is_digit(char c) {
    return std::isdigit(static_cast<unsigned char>(c));
}

enum class TokenType {
    Default = 0,
    Keyword,
    KeywordNamespace,
    Identifier,
    String,
    Comment,
    Number,
    Operator,
    Punctuation,
    Type,
    Function,
    Boolean,
    Preprocessor,
    Error,
    COUNT // must be last
};

struct Token {
    TokenType type;
    std::string_view value;
};

// --- Language Definition ---
struct LanguageRules {
    std::vector<std::string> keywords;
    std::vector<std::string> namespace_keywords;
    std::vector<std::string> types;
    std::vector<std::string> builtins;
    std::vector<std::string> operators;
    std::string line_comment_prefix;
    std::pair<std::string, std::string> block_comment_delimiters;
    std::pair<std::string, std::string> string_delimiters;
    std::pair<std::string, std::string> single_quote_string_delimiters;
    bool case_insensitive_keywords = false; // for SQL etc.
};

// --- Theme Mapping ---
struct Theme {
    static constexpr int NUM_TYPES = static_cast<int>(TokenType::COUNT);
    std::array<std::pair<ansi::Color, ansi::Style>, static_cast<size_t>(TokenType::COUNT)> token_styles;

    Theme() {
        // Initialize all to default
        for (auto& s : token_styles) {
            s = {ansi::Color::White, ansi::Style::Default};
        }
        token_styles[static_cast<int>(TokenType::Default)]      = {ansi::Color::White, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::Keyword)]       = {ansi::Color::Cyan, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::KeywordNamespace)] = {ansi::Color::Magenta, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::Identifier)]    = {ansi::Color::Cyan, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::String)]        = {ansi::Color::Green, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::Comment)]       = {ansi::Color::BrightBlack, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::Number)]        = {ansi::Color::Blue, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::Operator)]      = {ansi::Color::Magenta, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::Punctuation)]   = {ansi::Color::White, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::Type)]          = {ansi::Color::Blue, ansi::Style::Bold};
        token_styles[static_cast<int>(TokenType::Function)]      = {ansi::Color::Yellow, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::Boolean)]       = {ansi::Color::Magenta, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::Preprocessor)]  = {ansi::Color::Red, ansi::Style::Default};
        token_styles[static_cast<int>(TokenType::Error)]         = {ansi::Color::BrightRed, ansi::Style::Bold};
    }

    std::pair<ansi::Color, ansi::Style> get_style(TokenType type) const {
        int idx = static_cast<int>(type);
        if (idx >= 0 && idx < NUM_TYPES) {
            return token_styles[idx];
        }
        return {ansi::Color::White, ansi::Style::Default};
    }
};

// --- Lexer Interface ---
class Lexer {
public:
    virtual ~Lexer() = default;
    virtual std::vector<Token> tokenize(std::string_view code) const = 0;
};

// --- Lexer Factory ---
std::unique_ptr<Lexer> create_lexer(std::string_view language_name);

} // namespace highlighter
} // namespace cich

#endif // CICH_HIGHLIGHTER_H
