#ifndef CICH_INPUT_MULTILINE_INPUT_HPP
#define CICH_INPUT_MULTILINE_INPUT_HPP

#include <optional>
#include <string>
#include <vector>

namespace input {

// Sentinel returned by multiline_input / multiline_input_autoreturn on timeout.
inline const std::string kTimeoutSentinel = "CICH_TIMEOUT_ERROR";

// Sentinel returned by multiline_edit when Ctrl+A is pressed (editing aborted).
inline const std::string kEditingAbortedSentinel = "EDITING_ABORTED";

// Help text for multiline_input mode
inline const std::string kHelpMultilineInput =
    "Ctrl+V or /clip: paste | Ctrl+N: newline | Ctrl+W/U/K: delete word/to-start/to-end\n"
    "Ctrl+Up/Down: buffer start/end | Enter or Ctrl+D: submit";

// Help text for multiline_edit mode
inline const std::string kHelpMultilineEdit =
    "Ctrl+V or /clip: paste | Ctrl+N: newline | Ctrl+W/U/K: delete word/to-start/to-end\n"
    "Ctrl+Up/Down: buffer start/end | Ctrl+A: cancel | Ctrl+D: submit";

// Help text for multiline_input_autoreturn mode
inline const std::string kHelpMultilineInputAutoreturn =
    "Ctrl+V or /clip: paste | Ctrl+N: newline | Ctrl+W/U/K: delete word/to-start/to-end\n"
    "Ctrl+Up/Down: buffer start/end | Enter or Ctrl+D: submit (auto-submits on match)";

// 1) Normal multiline input:
// - Enter inserts newline
// - Ctrl+N inserts newline
// - Ctrl+W deletes previous word (or removes adjacent concealed paste block)
// - Ctrl+Delete deletes next word (or removes adjacent concealed paste block)
// - Ctrl+Left/Ctrl+Right jump by word
// - Up/Down move between lines preserving column
// - Home/End (or Ctrl+A/Ctrl+E) move to start/end of line
// - Ctrl+U/Ctrl+K delete to line start/end
// - Ctrl+V pastes clipboard (async, with loading indicator)
// - Typing /clip triggers the same clipboard paste behavior and replaces /clip
// - Ctrl+D submits
// - Ctrl+C raises SIGINT (keyboard interrupt)
// - timeout_ms: if > 0, returns kTimeoutSentinel after this many ms of idle
std::string multiline_input(const std::string& prompt, int timeout_ms = 0);

// 2) Edit pre-inserted message:
// - Same editing controls as multiline_input (except Ctrl+A, see below)
// - Ctrl+A aborts editing and returns kEditingAbortedSentinel
// - Home moves to start of line
// - enter_newline: if true, Enter inserts newline; if false, Enter submits
// - Ctrl+C raises SIGINT (keyboard interrupt)
// - Ctrl+D submits
// - timeout_ms: if > 0, returns kTimeoutSentinel after this many ms of idle
std::optional<std::string> multiline_edit(const std::string& prompt,
                                          const std::string& initial,
                                          bool enter_newline = true,
                                          int timeout_ms = 0);

// 3) Auto-return mode:
// - Same as multiline_input
// - Returns immediately when current buffer exactly matches one option
// - timeout_ms: if > 0, returns kTimeoutSentinel after this many ms of idle
std::string multiline_input_autoreturn(const std::string& prompt,
                                       const std::vector<std::string>& options,
                                       int timeout_ms = 0);

} // namespace input

#endif // CICH_INPUT_MULTILINE_INPUT_HPP