#ifndef CICH_PARSER_H
#define CICH_PARSER_H

#include "ast.h"
#include <string_view>
#include <vector> // Required for std::vector<std::string_view>
#include <optional> // Required for std::optional

namespace cich {

class Parser {
public:
    explicit Parser(std::string_view input);

    ast::Document parse();

private:
    std::string_view peek_line(size_t offset = 0) const;
    void consume_line();
    bool is_eof() const;
    void skip_empty_lines();

    ast::BlockNode parse_block();
    std::optional<ast::Header> parse_header();
    std::optional<ast::HorizontalRule> parse_horizontal_rule();
    std::optional<ast::Table> parse_table();
    std::optional<ast::CodeBlock> parse_code_block();
    std::optional<ast::Blockquote> parse_blockquote();
    std::optional<ast::List> parse_list(size_t indent_level = 0); // Modified
    ast::Paragraph parse_paragraph();

    std::vector<ast::InlineNode> parse_inline_elements(std::string_view text); // New declaration
    std::optional<std::pair<ast::InlineNode, size_t>> parse_inline(std::string_view text, size_t start_pos); // New declaration

    std::string_view m_input;
    std::vector<std::string_view> m_lines;
    size_t m_current_line_idx = 0;

    bool looks_like_list_item(std::string_view line, size_t indentation); // New declaration
};

} // namespace cich

#endif // CICH_PARSER_H
