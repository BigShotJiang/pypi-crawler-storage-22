#ifndef CICH_RENDER_OPTIONS_H
#define CICH_RENDER_OPTIONS_H

#include <cstdint>
#include <string>

namespace cich {

struct RenderOptions {
    // 0 means auto-detect (fallback to 80)
    uint32_t width = 0;
    bool wrap = true;

    // Theme name for syntax highlighting
    std::string theme = "monokai";

    // Code block rendering
    bool code_background = true;
    bool code_line_numbers = false;
    uint32_t code_line_start = 1;
    bool code_padding = true;

    // Typography
    uint32_t tab_size = 4;

    // Header panel
    bool header_border = false;

    // ANSI-only renderer (Tree-sitter removed)
    bool truecolor = true;
};

} // namespace cich

#endif // CICH_RENDER_OPTIONS_H
