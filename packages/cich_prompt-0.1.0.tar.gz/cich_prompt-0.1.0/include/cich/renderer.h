#ifndef CICH_RENDERER_H
#define CICH_RENDERER_H

#include "ast.h"
#include "ansi.h"
#include "highlighter.h"
#include "render_options.h"
#include <string>
#include <string_view>
#include <vector>

namespace cich {

class Renderer {
public:
    explicit Renderer(RenderOptions options = {});
    std::string render(const ast::Document& doc);

private:
    struct InlineStyle {
        ansi::Color fg = ansi::Color::Default;
        ansi::Color bg = ansi::Color::Default;
        bool bold = false;
        bool italic = false;
        bool underline = false;
    };

    struct StyledRun {
        std::string text;
        InlineStyle style;
    };

    std::vector<std::string> visit_block(const ast::Header& node, size_t indent = 0, std::string_view prefix = "");
    std::vector<std::string> visit_block(const ast::Paragraph& node, size_t indent = 0, std::string_view prefix = "");
    std::vector<std::string> visit_block(const ast::Blockquote& node, size_t indent = 0, std::string_view prefix = "");
    std::vector<std::string> visit_block(const ast::List& node, size_t indent = 0, std::string_view prefix = "");
    std::vector<std::string> visit_block(const ast::CodeBlock& node, size_t indent = 0, std::string_view prefix = "");
    std::vector<std::string> visit_block(const ast::HorizontalRule& node, size_t indent = 0, std::string_view prefix = "");
    std::vector<std::string> visit_block(const ast::Table& node, size_t indent = 0, std::string_view prefix = "");

    std::vector<StyledRun> render_inline_runs(const std::vector<ast::InlineNode>& nodes, InlineStyle base_style);
    std::vector<StyledRun> render_inline_run(const ast::InlineNode& node, InlineStyle base_style);

    std::vector<std::string> wrap_runs(const std::vector<StyledRun>& runs, size_t width, std::string_view first_prefix, std::string_view rest_prefix);
    std::string apply_style_change(const InlineStyle& from, const InlineStyle& to, bool force);

    void append_lines(const std::vector<std::string>& lines, bool add_blank_after);
    void append_blank_line();

    size_t effective_width() const;

    RenderOptions options_;
    std::vector<std::string> output_lines_;
    highlighter::Theme theme_;
};

} // namespace cich

#endif // CICH_RENDERER_H
