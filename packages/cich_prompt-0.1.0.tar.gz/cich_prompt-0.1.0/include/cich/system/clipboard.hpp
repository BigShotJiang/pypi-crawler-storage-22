#ifndef CICH_SYSTEM_CLIPBOARD_HPP
#define CICH_SYSTEM_CLIPBOARD_HPP

#include <string>
#include <string_view>

namespace clipboard {

bool set_text(std::string_view text, bool warn_tty = true, bool debug = false);
std::string get_text(bool warn_tty = true, bool debug = false);

} // namespace clipboard

#endif // CICH_SYSTEM_CLIPBOARD_HPP
