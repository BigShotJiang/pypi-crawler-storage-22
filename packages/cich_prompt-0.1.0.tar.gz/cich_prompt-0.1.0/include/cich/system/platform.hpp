#ifndef CICH_SYSTEM_PLATFORM_HPP
#define CICH_SYSTEM_PLATFORM_HPP

#include <string>

namespace platform {

enum class OSType {
    Linux,
    MacOS,
    Windows,
    Android,
    Unknown
};

struct LinuxDistroInfo {
    std::string id;
    std::string name;
    std::string version_id;
    std::string version_codename;
    std::string id_like;
};

struct PlatformInfo {
    OSType os = OSType::Unknown;
    std::string kernel_name;
    std::string kernel_release;
    std::string architecture;

    bool is_linux = false;
    bool is_termux = false;
    bool is_android = false;

    LinuxDistroInfo distro;
};

const PlatformInfo& detect_once();
PlatformInfo detect();
const char* to_string(OSType os) noexcept;

} // namespace platform

#endif // CICH_SYSTEM_PLATFORM_HPP
