#ifndef CICH_TERMINAL_H
#define CICH_TERMINAL_H

#include <cstdint>

namespace cich {

uint32_t detect_terminal_width();

} // namespace cich

#endif // CICH_TERMINAL_H
