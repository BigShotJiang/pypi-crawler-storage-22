#ifndef CICH_TRIE_H
#define CICH_TRIE_H

#include <array>
#include <string_view>
#include <vector>

namespace cich {

class OperatorTrie {
public:
    OperatorTrie() {
        nodes_.reserve(64);
        nodes_.emplace_back(); // root node at index 0
    }

    void insert(std::string_view op) {
        int current = 0;
        for (char c : op) {
            int idx = static_cast<unsigned char>(c);
            if (idx >= 128) continue;
            if (nodes_[current].children[idx] == -1) {
                nodes_[current].children[idx] = static_cast<int>(nodes_.size());
                nodes_.emplace_back();
            }
            current = nodes_[current].children[idx];
        }
        nodes_[current].is_terminal = true;
        nodes_[current].match_length = static_cast<int>(op.size());
    }

    // Returns length of longest matching operator starting at code[pos], or 0.
    int longest_match(std::string_view code, size_t pos) const {
        int current = 0;
        int best = 0;
        for (size_t i = pos; i < code.size(); ++i) {
            int idx = static_cast<unsigned char>(code[i]);
            if (idx >= 128 || nodes_[current].children[idx] == -1) break;
            current = nodes_[current].children[idx];
            if (nodes_[current].is_terminal) {
                best = nodes_[current].match_length;
            }
        }
        return best;
    }

private:
    struct Node {
        std::array<int, 128> children;
        bool is_terminal = false;
        int match_length = 0;

        Node() {
            children.fill(-1);
        }
    };

    std::vector<Node> nodes_;
};

} // namespace cich

#endif // CICH_TRIE_H
