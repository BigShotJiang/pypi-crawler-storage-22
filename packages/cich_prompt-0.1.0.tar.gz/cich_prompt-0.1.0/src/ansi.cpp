#include "cich/ansi.h"

namespace cich {
namespace ansi {

const char* RESET_ALL = "\033[0m";

// Static lookup tables — zero allocations for code generation
static constexpr const char* fg_table[] = {
    "",           // Default
    "\033[30m",   // Black
    "\033[31m",   // Red
    "\033[32m",   // Green
    "\033[33m",   // Yellow
    "\033[34m",   // Blue
    "\033[35m",   // Magenta
    "\033[36m",   // Cyan
    "\033[37m",   // White
    "\033[90m",   // BrightBlack
    "\033[91m",   // BrightRed
    "\033[92m",   // BrightGreen
    "\033[93m",   // BrightYellow
    "\033[94m",   // BrightBlue
    "\033[95m",   // BrightMagenta
    "\033[96m",   // BrightCyan
    "\033[97m",   // BrightWhite
};

static constexpr const char* bg_table[] = {
    "",            // Default
    "\033[40m",    // Black
    "\033[41m",    // Red
    "\033[42m",    // Green
    "\033[43m",    // Yellow
    "\033[44m",    // Blue
    "\033[45m",    // Magenta
    "\033[46m",    // Cyan
    "\033[47m",    // White
    "\033[100m",   // BrightBlack
    "\033[101m",   // BrightRed
    "\033[102m",   // BrightGreen
    "\033[103m",   // BrightYellow
    "\033[104m",   // BrightBlue
    "\033[105m",   // BrightMagenta
    "\033[106m",   // BrightCyan
    "\033[107m",   // BrightWhite
};

static constexpr const char* style_table[] = {
    "",           // Default
    "\033[1m",    // Bold
    "\033[2m",    // Dim
    "\033[3m",    // Italic
    "\033[4m",    // Underline
    "\033[5m",    // Blink
    "\033[7m",    // Inverse
    "\033[8m",    // Hidden
    "\033[9m",    // Strikethrough
    "\033[21m",   // ResetBold
    "\033[22m",   // ResetDim
    "\033[23m",   // ResetItalic
    "\033[24m",   // ResetUnderline
    "\033[25m",   // ResetBlink
    "\033[27m",   // ResetInverse
    "\033[28m",   // ResetHidden
    "\033[29m",   // ResetStrikethrough
};

std::string color_code(Color c) {
    return fg_table[static_cast<int>(c)];
}

std::string style_code(Style s) {
    return style_table[static_cast<int>(s)];
}

std::string apply_style(std::string_view text, Color foreground, Color background, Style style) {
    std::string result;
    result.reserve(text.size() + 32);

    if (foreground != Color::Default) {
        result.append(fg_table[static_cast<int>(foreground)]);
    } else if (background != Color::Default) {
        // Explicitly reset to default foreground when a background is applied.
        result.append("\033[39m");
    }
    if (background != Color::Default) {
        result.append(bg_table[static_cast<int>(background)]);
    }
    if (style != Style::Default) {
        result.append(style_table[static_cast<int>(style)]);
    } else if (foreground != Color::Default || background != Color::Default) {
        // Reset common styles explicitly when applying a styled span.
        result.append("\033[22m\033[23m\033[24m");
    }

    result.append(text.data(), text.size());
    return result;
}

std::string apply_style(std::string_view text, Color foreground, Style style) {
    return apply_style(text, foreground, Color::Default, style);
}

std::string apply_style(std::string_view text, Style style) {
    return apply_style(text, Color::Default, Color::Default, style);
}

} // namespace ansi
} // namespace cich
