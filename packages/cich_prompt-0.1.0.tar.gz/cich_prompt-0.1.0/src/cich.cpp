#include "cich/cich.h"
#include "cich/parser.h"
#include "cich/renderer.h" // Include the new renderer header

namespace cich {

std::string render(std::string_view markdown_text) {
    RenderOptions options;
    return render(markdown_text, options);
}

std::string render(std::string_view markdown_text, const RenderOptions& options) {
    Parser parser(markdown_text);
    ast::Document doc = parser.parse();

    Renderer renderer(options);
    return renderer.render(doc);
}

} // namespace cich
