#include "cich/cout.h"
#include "cich/cich.h"
#include <iostream>
#include <algorithm>

#ifdef __unix__
#include <sys/ioctl.h>
#include <unistd.h>
#endif

namespace cich {

// --- Helper ---
static void print_styled(std::string_view text, ansi::Color fg,
                         ansi::Style style = ansi::Style::Default,
                         ansi::Color bg = ansi::Color::Default,
                         std::string_view end = "\n") {
    if (fg == ansi::Color::Default && style == ansi::Style::Default && bg == ansi::Color::Default) {
        std::cout << text << end;
    } else {
        std::cout << ansi::apply_style(text, fg, bg, style) << end;
    }
}

// --- Basic Colors ---
void Cout::good(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::Green, ansi::Style::Default, ansi::Color::Default, end);
}

void Cout::bad(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::Red, ansi::Style::Default, ansi::Color::Default, end);
}

void Cout::yellow(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::Yellow, ansi::Style::Default, ansi::Color::Default, end);
}

void Cout::normal(std::string_view text, std::string_view end) {
    std::cout << text << end;
}

void Cout::dim(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::Default, ansi::Style::Dim, ansi::Color::Default, end);
}

void Cout::bold(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::Default, ansi::Style::Bold, ansi::Color::Default, end);
}

// --- Informational ---
void Cout::info(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::BrightBlue, ansi::Style::Default, ansi::Color::Default, end);
}

void Cout::debug(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::BrightBlack, ansi::Style::Default, ansi::Color::Default, end);
}

void Cout::header(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::Cyan, ansi::Style::Bold, ansi::Color::Default, end);
}

void Cout::step(std::string_view text, std::string_view end) {
    std::string prefixed = "\xe2\x86\x92 "; // → prefix
    prefixed.append(text.data(), text.size());
    print_styled(prefixed, ansi::Color::Green, ansi::Style::Default, ansi::Color::Default, end);
}

void Cout::prompt(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::BrightWhite, ansi::Style::Bold, ansi::Color::Blue, end);
}

// --- Status Banners ---
void Cout::success(std::string_view text, std::string_view end) {
    std::string msg = "\xe2\x9c\x93 "; // ✓ prefix
    msg.append(text.data(), text.size());
    print_styled(msg, ansi::Color::Green, ansi::Style::Bold, ansi::Color::Default, end);
}

void Cout::fail(std::string_view text, std::string_view end) {
    std::string msg = "\xe2\x9c\x97 "; // ✗ prefix
    msg.append(text.data(), text.size());
    print_styled(msg, ansi::Color::Red, ansi::Style::Bold, ansi::Color::Default, end);
}

void Cout::warning(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::Yellow, ansi::Style::Bold, ansi::Color::Default, end);
}

// --- Decorative ---
void Cout::rule(std::string_view title, int width) {
    if (width <= 0) {
        width = terminal_width();
    }
    width = std::max(width, 20);

    // UTF-8 for ─ is \xe2\x94\x80
    const std::string dash = "\xe2\x94\x80";

    if (title.empty()) {
        std::string line;
        line.reserve(width * 3);
        for (int i = 0; i < width; ++i) {
            line += dash;
        }
        std::cout << ansi::apply_style(line, ansi::Color::Cyan) << "\n";
        return;
    }

    std::string title_part = " ";
    title_part.append(title.data(), title.size());
    title_part += " ";
    int title_len = static_cast<int>(title.size()) + 2; // +2 for spaces

    if (title_len >= width - 4) {
        std::cout << ansi::apply_style(title_part, ansi::Color::Cyan) << "\n";
        return;
    }

    int line_len = width - title_len;
    int left_len = line_len / 2;
    int right_len = line_len - left_len;

    std::string left;
    for (int i = 0; i < left_len; ++i) left += dash;
    std::string right;
    for (int i = 0; i < right_len; ++i) right += dash;

    std::cout << ansi::apply_style(left, ansi::Color::Cyan)
              << title_part
              << ansi::apply_style(right, ansi::Color::Cyan)
              << "\n";
}

// --- Text Styling ---
void Cout::highlight(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::Yellow, ansi::Style::Bold, ansi::Color::Default, end);
}

void Cout::underline(std::string_view text, std::string_view end) {
    print_styled(text, ansi::Color::White, ansi::Style::Underline, ansi::Color::Default, end);
}

// --- Error ---
void Cout::fail_raise(std::string_view message, std::string_view end) {
    fail(message, end);
    throw std::runtime_error(std::string(message));
}

// --- Markdown ---
void Cout::markdown(std::string_view text) {
    cich::render(text);
}

// --- Terminal width ---
int Cout::terminal_width() {
#ifdef __unix__
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col > 0) {
        return ws.ws_col;
    }
#endif
    return 80;
}

} // namespace cich
