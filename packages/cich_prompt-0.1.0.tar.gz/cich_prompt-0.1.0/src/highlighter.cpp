


#include "cich/highlighter.h"
#include "cich/trie.h"
#include <algorithm>
#include <cctype>
#include <unordered_set>
#include <memory>

namespace cich {
namespace highlighter {

// --- SimpleLexer Implementation ---
class SimpleLexer : public Lexer {
public:
    explicit SimpleLexer(const LanguageRules& rules) : m_rules(rules) {
        for (const auto& kw : rules.keywords) m_keywords.insert(kw);
        for (const auto& kw : rules.namespace_keywords) m_namespace_keywords.insert(kw);
        for (const auto& type : rules.types) m_types.insert(type);
        for (const auto& builtin : rules.builtins) m_builtins.insert(builtin);
        for (const auto& op : rules.operators) {
            m_op_trie.insert(op);
        }

        // For case-insensitive languages, also insert lowercase versions
        if (rules.case_insensitive_keywords) {
            for (const auto& kw : rules.keywords) {
                std::string lower = kw;
                std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
                m_keywords.insert(lower);
            }
            for (const auto& kw : rules.namespace_keywords) {
                std::string lower = kw;
                std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
                m_namespace_keywords.insert(lower);
            }
            for (const auto& type : rules.types) {
                std::string lower = type;
                std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
                m_types.insert(lower);
            }
        }
    }

    std::vector<Token> tokenize(std::string_view code) const override {
        std::vector<Token> tokens;
        tokens.reserve(code.size() / 4);
        size_t current_pos = 0;

        while (current_pos < code.size()) {
            // Skip whitespace
            if (std::isspace(static_cast<unsigned char>(code[current_pos]))) {
                size_t start = current_pos;
                while (current_pos < code.size() && std::isspace(static_cast<unsigned char>(code[current_pos]))) {
                    current_pos++;
                }
                tokens.push_back({TokenType::Default, code.substr(start, current_pos - start)});
                continue;
            }

            // Preprocessor directives (# at start of line or after whitespace)
            if (code[current_pos] == '#' && m_rules.line_comment_prefix != "#") {
                // Check if this looks like a preprocessor directive (C/C++ style)
                size_t start = current_pos;
                current_pos = code.find('\n', start);
                if (current_pos == std::string_view::npos) current_pos = code.size();
                tokens.push_back({TokenType::Preprocessor, code.substr(start, current_pos - start)});
                continue;
            }

            // Line comments
            if (!m_rules.line_comment_prefix.empty() &&
                current_pos + m_rules.line_comment_prefix.size() <= code.size() &&
                code.substr(current_pos, m_rules.line_comment_prefix.size()) == m_rules.line_comment_prefix) {
                size_t start = current_pos;
                current_pos = code.find('\n', start);
                if (current_pos == std::string_view::npos) current_pos = code.size();
                tokens.push_back({TokenType::Comment, code.substr(start, current_pos - start)});
                continue;
            }

            // Block comments
            if (!m_rules.block_comment_delimiters.first.empty()) {
                auto& delim = m_rules.block_comment_delimiters;
                if (current_pos + delim.first.size() <= code.size() &&
                    code.substr(current_pos, delim.first.size()) == delim.first) {
                    size_t start = current_pos;
                    current_pos = code.find(delim.second, start + delim.first.size());
                    if (current_pos == std::string_view::npos) current_pos = code.size();
                    else current_pos += delim.second.size();
                    tokens.push_back({TokenType::Comment, code.substr(start, current_pos - start)});
                    continue;
                }
            }

            // Strings (double quotes)
            if (!m_rules.string_delimiters.first.empty() && code[current_pos] == m_rules.string_delimiters.first[0]) {
                size_t start = current_pos;
                char delimiter = code[current_pos];
                current_pos++;
                while (current_pos < code.size() && code[current_pos] != delimiter && code[current_pos] != '\n') {
                    if (code[current_pos] == '\\' && current_pos + 1 < code.size()) {
                        current_pos++;
                    }
                    current_pos++;
                }
                if (current_pos < code.size() && code[current_pos] == delimiter) {
                    current_pos++;
                }
                tokens.push_back({TokenType::String, code.substr(start, current_pos - start)});
                continue;
            }

            // Strings (single quotes)
            if (!m_rules.single_quote_string_delimiters.first.empty() && code[current_pos] == m_rules.single_quote_string_delimiters.first[0]) {
                size_t start = current_pos;
                char delimiter = code[current_pos];
                current_pos++;
                while (current_pos < code.size() && code[current_pos] != delimiter && code[current_pos] != '\n') {
                    if (code[current_pos] == '\\' && current_pos + 1 < code.size()) {
                        current_pos++;
                    }
                    current_pos++;
                }
                if (current_pos < code.size() && code[current_pos] == delimiter) {
                    current_pos++;
                }
                tokens.push_back({TokenType::String, code.substr(start, current_pos - start)});
                continue;
            }

            // Numbers
            if (is_digit(code[current_pos])) {
                size_t start = current_pos;
                // Handle hex (0x), binary (0b), octal (0o)
                if (code[current_pos] == '0' && current_pos + 1 < code.size()) {
                    char next = code[current_pos + 1];
                    if (next == 'x' || next == 'X' || next == 'b' || next == 'B' || next == 'o' || next == 'O') {
                        current_pos += 2;
                        while (current_pos < code.size() && (is_digit(code[current_pos]) ||
                               (code[current_pos] >= 'a' && code[current_pos] <= 'f') ||
                               (code[current_pos] >= 'A' && code[current_pos] <= 'F') ||
                               code[current_pos] == '_')) {
                            current_pos++;
                        }
                        tokens.push_back({TokenType::Number, code.substr(start, current_pos - start)});
                        continue;
                    }
                }
                while (current_pos < code.size() && (is_digit(code[current_pos]) || code[current_pos] == '_')) {
                    current_pos++;
                }
                if (current_pos < code.size() && code[current_pos] == '.') {
                    current_pos++;
                    while (current_pos < code.size() && (is_digit(code[current_pos]) || code[current_pos] == '_')) {
                        current_pos++;
                    }
                }
                // Exponent
                if (current_pos < code.size() && (code[current_pos] == 'e' || code[current_pos] == 'E')) {
                    current_pos++;
                    if (current_pos < code.size() && (code[current_pos] == '+' || code[current_pos] == '-')) {
                        current_pos++;
                    }
                    while (current_pos < code.size() && is_digit(code[current_pos])) {
                        current_pos++;
                    }
                }
                // Suffixes like f, L, UL, i32, etc.
                while (current_pos < code.size() && std::isalpha(static_cast<unsigned char>(code[current_pos]))) {
                    current_pos++;
                }
                tokens.push_back({TokenType::Number, code.substr(start, current_pos - start)});
                continue;
            }

            // Identifiers, Keywords, Types, Functions, Builtins
            if (is_identifier_start(code[current_pos])) {
                size_t start = current_pos;
                while (current_pos < code.size() && is_identifier_char(code[current_pos])) {
                    current_pos++;
                }
                std::string_view identifier_sv = code.substr(start, current_pos - start);
                std::string identifier(identifier_sv);

                // For case-insensitive languages, check both original and lowercase
                std::string lookup_key = identifier;
                if (m_rules.case_insensitive_keywords) {
                    std::transform(lookup_key.begin(), lookup_key.end(), lookup_key.begin(), ::tolower);
                }

                if (m_namespace_keywords.count(lookup_key)) {
                    tokens.push_back({TokenType::KeywordNamespace, identifier_sv});
                } else if (m_keywords.count(lookup_key)) {
                    tokens.push_back({TokenType::Keyword, identifier_sv});
                } else if (m_types.count(lookup_key)) {
                    tokens.push_back({TokenType::Type, identifier_sv});
                } else if (m_builtins.count(identifier)) {
                    tokens.push_back({TokenType::Function, identifier_sv});
                } else if (identifier == "true" || identifier == "false" ||
                           identifier == "True" || identifier == "False" ||
                           identifier == "TRUE" || identifier == "FALSE") {
                    tokens.push_back({TokenType::Boolean, identifier_sv});
                } else {
                    tokens.push_back({TokenType::Identifier, identifier_sv});
                }
                continue;
            }

            // Operators via trie — O(operator_length) instead of O(n_operators)
            int op_len = m_op_trie.longest_match(code, current_pos);
            if (op_len > 0) {
                tokens.push_back({TokenType::Operator, code.substr(current_pos, op_len)});
                current_pos += op_len;
                continue;
            }

            // Fallback: single character punctuation
            tokens.push_back({TokenType::Punctuation, code.substr(current_pos, 1)});
            current_pos++;
        }
        return tokens;
    }

private:
    const LanguageRules& m_rules;
    std::unordered_set<std::string> m_keywords;
    std::unordered_set<std::string> m_namespace_keywords;
    std::unordered_set<std::string> m_types;
    std::unordered_set<std::string> m_builtins;
    OperatorTrie m_op_trie;
};


// ============================================================================
// Language Definitions
// ============================================================================

static const LanguageRules& get_cpp_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "alignas", "alignof", "and", "and_eq", "asm", "atomic_cancel", "atomic_commit",
            "atomic_noexcept", "auto", "bitand", "bitor", "bool", "break", "case",
            "catch", "char", "char8_t", "char16_t", "char32_t", "class", "compl", "concept",
            "const", "consteval", "constexpr", "constinit", "const_cast", "continue",
            "co_await", "co_return", "co_yield", "decltype", "default", "delete", "do",
            "double", "dynamic_cast", "else", "enum", "explicit", "export", "extern",
            "false", "float", "for", "friend", "goto", "if", "inline", "int", "long",
            "mutable", "namespace", "new", "noexcept", "not", "not_eq", "nullptr",
            "operator", "or", "or_eq", "private", "protected", "public", "reflexpr",
            "register", "reinterpret_cast", "requires", "return", "short", "signed",
            "sizeof", "static", "static_assert", "static_cast", "struct", "switch",
            "synchronized", "template", "this", "thread_local", "throw", "true", "try",
            "typedef", "typeid", "typename", "union", "unsigned", "using", "virtual",
            "void", "volatile", "wchar_t", "while", "xor", "xor_eq",
        };
        rules.types = {
            "bool", "char", "double", "float", "int", "long", "short", "signed", "unsigned", "void", "wchar_t",
            "size_t", "ssize_t", "ptrdiff_t", "NULL", "nullptr_t",
            "string", "vector", "map", "set", "unordered_map", "unordered_set", "queue", "stack", "array", "tuple",
            "iostream", "fstream", "sstream", "algorithm", "memory", "variant", "optional", "cctype",
            "string_view", "unique_ptr", "shared_ptr", "weak_ptr", "pair",
        };
        rules.operators = {
            "...", "->*", "->", "::", "++", "--", "<<=", ">>=", "<<", ">>", "<=", ">=", "==", "!=", "&&", "||",
            "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "=",
            "<", ">", "!", "~", "+", "-", "*", "/", "%", "&", "|", "^",
            ".", ",", ";", ":", "?", "[", "]", "(", ")", "{", "}"
        };
        rules.line_comment_prefix = "//";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_python_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "False", "None", "True", "and", "as", "assert", "async", "await", "break",
            "class", "continue", "def", "del", "elif", "else", "except", "finally",
            "for", "from", "global", "if", "import", "in", "is", "lambda", "nonlocal",
            "not", "or", "pass", "raise", "return", "try", "while", "with", "yield"
        };
        rules.namespace_keywords = {"import", "from", "as"};
        rules.types = {
            "int", "float", "str", "bool", "list", "dict", "tuple", "set", "frozenset",
            "bytes", "bytearray", "memoryview", "complex", "range", "type", "object",
            "NoneType", "Exception", "BaseException",
        };
        rules.builtins = {
            "print", "len", "range", "enumerate", "zip", "map", "filter", "sorted",
            "reversed", "any", "all", "min", "max", "sum", "abs", "round", "pow",
            "isinstance", "issubclass", "hasattr", "getattr", "setattr", "delattr",
            "callable", "iter", "next", "super", "property", "classmethod", "staticmethod",
            "open", "input", "repr", "format", "hash", "id", "dir", "vars", "type",
            "help", "hex", "oct", "bin", "chr", "ord", "eval", "exec", "compile",
        };
        rules.operators = {
            "**=", "//=", "**", "*", "//", "/", "%", "+", "-", "<<", ">>", "&", "|", "^", "~",
            "<", ">", "<=", ">=", "==", "!=", "=", "+=", "-=", "*=", "/=", "%=",
            "&=", "|=", "^=",
            ".", ",", ":", ";", "(", ")", "[", "]", "{", "}", "@", "->"
        };
        rules.line_comment_prefix = "#";
        rules.block_comment_delimiters = {"\"\"\"", "\"\"\""};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_javascript_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "break", "case", "catch", "class", "const", "continue", "debugger", "default",
            "delete", "do", "else", "export", "extends", "finally", "for", "function",
            "if", "import", "in", "instanceof", "let", "new", "of", "return", "super",
            "switch", "this", "throw", "try", "typeof", "var", "void", "while", "with",
            "yield", "async", "await", "from", "as", "static", "get", "set"
        };
        rules.types = {
            "Array", "Boolean", "Date", "Error", "Function", "Map", "Number", "Object",
            "Promise", "Proxy", "RegExp", "Set", "String", "Symbol", "WeakMap", "WeakSet",
            "BigInt", "ArrayBuffer", "DataView", "Float32Array", "Float64Array",
            "Int8Array", "Int16Array", "Int32Array", "Uint8Array", "Uint16Array",
            "Uint32Array", "JSON", "Math", "console", "document", "window",
        };
        rules.builtins = {
            "parseInt", "parseFloat", "isNaN", "isFinite", "encodeURI", "decodeURI",
            "encodeURIComponent", "decodeURIComponent", "setTimeout", "setInterval",
            "clearTimeout", "clearInterval", "fetch", "require",
        };
        rules.operators = {
            "===", "!==", ">>>", ">>>=", "?.","\?\?", "=>", "...", "++", "--",
            "<<=", ">>=", "<<", ">>", "<=", ">=", "==", "!=", "&&", "||",
            "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "**=", "**",
            "=", "<", ">", "!", "~", "+", "-", "*", "/", "%", "&", "|", "^",
            ".", ",", ";", ":", "?", "[", "]", "(", ")", "{", "}"
        };
        rules.line_comment_prefix = "//";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_typescript_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "break", "case", "catch", "class", "const", "continue", "debugger", "default",
            "delete", "do", "else", "export", "extends", "finally", "for", "function",
            "if", "import", "in", "instanceof", "let", "new", "of", "return", "super",
            "switch", "this", "throw", "try", "typeof", "var", "void", "while", "with",
            "yield", "async", "await", "from", "as", "static", "get", "set",
            "type", "interface", "enum", "namespace", "declare", "abstract",
            "implements", "readonly", "keyof", "infer", "is", "asserts", "override",
            "satisfies", "module"
        };
        rules.types = {
            "Array", "Boolean", "Date", "Error", "Function", "Map", "Number", "Object",
            "Promise", "Proxy", "RegExp", "Set", "String", "Symbol", "WeakMap", "WeakSet",
            "BigInt", "ArrayBuffer", "DataView",
            "any", "unknown", "never", "string", "number", "boolean", "symbol", "bigint",
            "undefined", "null", "Record", "Partial", "Required", "Readonly", "Pick",
            "Omit", "Exclude", "Extract", "NonNullable", "ReturnType", "Parameters",
            "InstanceType", "Awaited",
        };
        rules.builtins = {
            "parseInt", "parseFloat", "isNaN", "isFinite", "encodeURI", "decodeURI",
            "encodeURIComponent", "decodeURIComponent", "setTimeout", "setInterval",
            "clearTimeout", "clearInterval", "fetch", "require",
        };
        rules.operators = {
            "===", "!==", ">>>", ">>>=", "?.","\?\?", "=>", "...", "++", "--",
            "<<=", ">>=", "<<", ">>", "<=", ">=", "==", "!=", "&&", "||",
            "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "**=", "**",
            "=", "<", ">", "!", "~", "+", "-", "*", "/", "%", "&", "|", "^",
            ".", ",", ";", ":", "?", "[", "]", "(", ")", "{", "}"
        };
        rules.line_comment_prefix = "//";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_java_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "abstract", "assert", "break", "case", "catch", "class", "const", "continue",
            "default", "do", "else", "enum", "extends", "final", "finally", "for", "goto",
            "if", "implements", "import", "instanceof", "interface", "native", "new",
            "package", "private", "protected", "public", "return", "static", "strictfp",
            "super", "switch", "synchronized", "this", "throw", "throws", "transient",
            "try", "volatile", "while", "yield", "sealed", "permits", "record", "var"
        };
        rules.types = {
            "boolean", "byte", "char", "double", "float", "int", "long", "short", "void",
            "String", "Integer", "Long", "Double", "Float", "Boolean", "Character", "Byte",
            "Short", "Object", "List", "Map", "Set", "ArrayList", "HashMap", "HashSet",
            "LinkedList", "TreeMap", "TreeSet", "Optional", "Stream", "Collection",
            "Iterator", "Iterable", "Comparable", "Runnable", "Callable", "Future",
        };
        rules.operators = {
            ">>>", "++", "--", "<<=", ">>=", ">>>=", "<<", ">>", "<=", ">=", "==", "!=",
            "&&", "||", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "->",
            "=", "<", ">", "!", "~", "+", "-", "*", "/", "%", "&", "|", "^",
            ".", ",", ";", ":", "?", "[", "]", "(", ")", "{", "}", "::", "@"
        };
        rules.line_comment_prefix = "//";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_go_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "break", "case", "chan", "const", "continue", "default", "defer", "else",
            "fallthrough", "for", "func", "go", "goto", "if", "import", "interface",
            "map", "package", "range", "return", "select", "struct", "switch", "type", "var"
        };
        rules.types = {
            "bool", "byte", "complex64", "complex128", "error", "float32", "float64",
            "int", "int8", "int16", "int32", "int64", "rune", "string", "uint", "uint8",
            "uint16", "uint32", "uint64", "uintptr", "any", "comparable",
        };
        rules.builtins = {
            "append", "cap", "close", "complex", "copy", "delete", "imag", "len",
            "make", "new", "panic", "print", "println", "real", "recover",
        };
        rules.operators = {
            ":=", "<-", "...", "++", "--", "<<=", ">>=", "&^=", "<<", ">>", "&^",
            "<=", ">=", "==", "!=", "&&", "||",
            "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=",
            "=", "<", ">", "!", "+", "-", "*", "/", "%", "&", "|", "^", "~",
            ".", ",", ";", ":", "[", "]", "(", ")", "{", "}"
        };
        rules.line_comment_prefix = "//";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_rust_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "as", "async", "await", "break", "const", "continue", "crate", "dyn", "else",
            "enum", "extern", "fn", "for", "if", "impl", "in", "let", "loop", "match",
            "mod", "move", "mut", "pub", "ref", "return", "self", "Self", "static",
            "struct", "super", "trait", "type", "unsafe", "use", "where", "while",
            "yield", "macro_rules"
        };
        rules.types = {
            "bool", "char", "f32", "f64", "i8", "i16", "i32", "i64", "i128", "isize",
            "str", "u8", "u16", "u32", "u64", "u128", "usize",
            "String", "Vec", "Box", "Rc", "Arc", "Option", "Result", "HashMap", "HashSet",
            "BTreeMap", "BTreeSet", "Cow", "Cell", "RefCell", "Mutex", "RwLock", "Pin",
            "Fn", "FnMut", "FnOnce",
        };
        rules.builtins = {
            "println", "print", "eprintln", "eprint", "format", "vec", "todo", "unimplemented",
            "unreachable", "panic", "assert", "assert_eq", "assert_ne", "dbg",
            "cfg", "include", "include_str", "include_bytes", "env", "concat", "stringify",
        };
        rules.operators = {
            "..=", "..", "=>", "->", "::", "+=", "-=", "*=", "/=", "%=", "&=", "|=",
            "^=", "<<=", ">>=", "==", "!=", "<=", ">=", "&&", "||", "<<", ">>",
            "=", "<", ">", "+", "-", "*", "/", "%", "&", "|", "^", "!", "~",
            "?", ".", ",", ";", ":", "@", "#", "[", "]", "(", ")", "{", "}"
        };
        rules.line_comment_prefix = "//";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_ruby_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "alias", "and", "begin", "break", "case", "class", "def", "do", "else",
            "elsif", "end", "ensure", "for", "if", "in", "module", "next", "nil",
            "not", "or", "redo", "rescue", "retry", "return", "self", "super", "then",
            "undef", "unless", "until", "when", "while", "yield",
            "require", "require_relative", "include", "extend",
            "attr_reader", "attr_writer", "attr_accessor", "raise", "puts", "print"
        };
        rules.types = {
            "Array", "Hash", "String", "Integer", "Float", "Symbol", "Regexp", "Range",
            "NilClass", "TrueClass", "FalseClass", "Proc", "IO", "File", "Dir", "Time",
            "Thread", "Mutex", "Fiber", "Numeric", "Comparable", "Enumerable",
        };
        rules.operators = {
            "**", "<=>", "===", "=~", "!~", "<<", ">>", "<=", ">=", "==", "!=",
            "&&", "||", "..", "...", "+=", "-=", "*=", "/=", "%=", "**=", "&=",
            "|=", "^=", "<<=", ">>=",
            "=", "<", ">", "+", "-", "*", "/", "%", "&", "|", "^", "~", "!",
            ".", ",", ";", ":", "::", "(", ")", "[", "]", "{", "}", "@", "@@"
        };
        rules.line_comment_prefix = "#";
        rules.block_comment_delimiters = {"=begin", "=end"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_php_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "abstract", "and", "array", "as", "break", "callable", "case", "catch",
            "class", "clone", "const", "continue", "declare", "default", "do", "echo",
            "else", "elseif", "empty", "enddeclare", "endfor", "endforeach", "endif",
            "endswitch", "endwhile", "extends", "final", "finally", "fn", "for",
            "foreach", "function", "global", "goto", "if", "implements", "include",
            "include_once", "instanceof", "insteadof", "interface", "isset", "list",
            "match", "namespace", "new", "or", "print", "private", "protected", "public",
            "readonly", "require", "require_once", "return", "static", "switch", "throw",
            "trait", "try", "unset", "use", "var", "while", "xor", "yield"
        };
        rules.types = {
            "int", "float", "string", "bool", "array", "object", "null", "void",
            "mixed", "never", "iterable", "callable", "self", "parent",
        };
        rules.operators = {
            "=>", "->", "::", "\?\?=", "\?\?", "<=>", "===", "!==", "++", "--", "**",
            "<<=", ">>=", "<<", ">>", "<=", ">=", "==", "!=", "&&", "||",
            "+=", "-=", "*=", "/=", "%=", ".=", "&=", "|=", "^=",
            "...", "=", "<", ">", "!", "~", "+", "-", "*", "/", "%", ".", "&", "|",
            "^", "@", "?", ":", ";", ",", "[", "]", "(", ")", "{", "}"
        };
        rules.line_comment_prefix = "//";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_csharp_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "abstract", "as", "base", "break", "case", "catch", "checked", "class",
            "const", "continue", "default", "delegate", "do", "else", "enum", "event",
            "explicit", "extern", "finally", "fixed", "for", "foreach", "goto", "if",
            "implicit", "in", "interface", "internal", "is", "lock", "namespace", "new",
            "null", "operator", "out", "override", "params", "private", "protected",
            "public", "readonly", "ref", "return", "sealed", "sizeof", "stackalloc",
            "static", "struct", "switch", "this", "throw", "try", "typeof", "unchecked",
            "unsafe", "using", "virtual", "volatile", "while", "async", "await", "var",
            "dynamic", "yield", "record", "init", "required", "when", "with", "global"
        };
        rules.types = {
            "bool", "byte", "char", "decimal", "double", "float", "int", "long", "object",
            "sbyte", "short", "string", "uint", "ulong", "ushort", "void",
            "List", "Dictionary", "HashSet", "Queue", "Stack", "Array", "Tuple", "Task",
            "Action", "Func", "IEnumerable", "IList", "IDictionary", "ICollection",
            "Nullable", "Span", "Memory", "ReadOnlySpan", "ValueTask",
        };
        rules.operators = {
            "=>", "\?\?=", "\?\?", "?.", "++", "--", "<<=", ">>=", "<<", ">>",
            "<=", ">=", "==", "!=", "&&", "||",
            "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=",
            "=", "<", ">", "!", "~", "+", "-", "*", "/", "%", "&", "|", "^",
            ".", ",", ";", ":", "?", "[", "]", "(", ")", "{", "}"
        };
        rules.line_comment_prefix = "//";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_swift_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "associatedtype", "break", "case", "catch", "class", "continue", "default",
            "defer", "deinit", "do", "else", "enum", "extension", "fallthrough",
            "fileprivate", "for", "func", "guard", "if", "import", "in", "init", "inout",
            "internal", "is", "let", "nil", "open", "operator", "private", "protocol",
            "public", "repeat", "rethrows", "return", "self", "Self", "static", "struct",
            "subscript", "super", "switch", "throw", "throws", "try", "typealias", "var",
            "where", "while", "as", "any", "some", "async", "await", "actor",
            "nonisolated", "isolated"
        };
        rules.types = {
            "Int", "Int8", "Int16", "Int32", "Int64", "UInt", "UInt8", "UInt16", "UInt32",
            "UInt64", "Float", "Double", "Bool", "String", "Character", "Array",
            "Dictionary", "Set", "Optional", "Result", "Void", "Never", "AnyObject", "Any",
            "Codable", "Hashable", "Equatable", "Comparable", "Error", "Sequence",
            "Collection", "Data", "URL", "Date",
        };
        rules.builtins = {
            "print", "debugPrint", "dump", "fatalError", "precondition", "preconditionFailure",
            "assert", "assertionFailure", "min", "max", "abs", "zip", "stride",
        };
        rules.operators = {
            "...", "..<", "->", "\?\?", "?.","++", "--", "<<=", ">>=", "<<", ">>",
            "<=", ">=", "==", "!=", "===", "!==", "&&", "||",
            "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=",
            "=", "<", ">", "!", "~", "+", "-", "*", "/", "%", "&", "|", "^",
            ".", ",", ";", ":", "?", "[", "]", "(", ")", "{", "}"
        };
        rules.line_comment_prefix = "//";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_kotlin_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "as", "break", "class", "continue", "do", "else", "for", "fun", "if", "in",
            "interface", "is", "null", "object", "package", "return", "super", "this",
            "throw", "try", "typealias", "typeof", "val", "var", "when", "while",
            "by", "catch", "constructor", "delegate", "dynamic", "field", "file",
            "finally", "get", "import", "init", "param", "property", "receiver", "set",
            "setparam", "where", "actual", "abstract", "annotation", "companion", "const",
            "crossinline", "data", "enum", "expect", "external", "final", "infix",
            "inline", "inner", "internal", "lateinit", "noinline", "open", "operator",
            "out", "override", "private", "protected", "public", "reified", "sealed",
            "suspend", "tailrec", "vararg"
        };
        rules.types = {
            "Int", "Long", "Short", "Byte", "Float", "Double", "Boolean", "Char", "String",
            "Any", "Unit", "Nothing", "Array", "List", "MutableList", "Map", "MutableMap",
            "Set", "MutableSet", "Pair", "Triple", "Sequence", "Comparable",
        };
        rules.builtins = {
            "println", "print", "readLine", "require", "check", "error", "TODO",
            "listOf", "mutableListOf", "mapOf", "mutableMapOf", "setOf", "mutableSetOf",
            "arrayOf", "intArrayOf", "longArrayOf", "doubleArrayOf", "booleanArrayOf",
            "lazy", "also", "apply", "let", "run", "with", "takeIf", "takeUnless",
        };
        rules.operators = {
            "?.", "?:", "::", "->", "..","++", "--", "<<=", ">>=", "<<", ">>",
            "<=", ">=", "==", "!=", "===", "!==", "&&", "||",
            "+=", "-=", "*=", "/=", "%=",
            "=", "<", ">", "!", "+", "-", "*", "/", "%", "&", "|",
            ".", ",", ";", ":", "?", "[", "]", "(", ")", "{", "}", "@"
        };
        rules.line_comment_prefix = "//";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_bash_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "if", "then", "else", "elif", "fi", "for", "while", "until", "do", "done",
            "case", "esac", "in", "function", "select", "time", "coproc", "break",
            "continue", "return", "exit", "export", "readonly", "declare", "local",
            "typeset", "unset", "shift", "source", "alias", "unalias", "set", "eval",
            "exec", "trap", "wait", "read", "echo", "printf", "test"
        };
        rules.types = {};
        rules.builtins = {
            "cd", "pwd", "pushd", "popd", "dirs", "true", "false", "bg", "fg", "jobs",
            "kill", "let", "getopts", "umask", "ulimit", "type", "hash", "help",
            "logout", "times", "builtin", "command", "enable", "shopt",
        };
        rules.operators = {
            "||", "&&", ";;", "&>", ">>", "<<", "<<<", "|&", ">=", "<=", "==", "!=",
            "=~", "|", "&", ";", ">", "<", "=",
            "(", ")", "[", "]", "{", "}", "!", "$"
        };
        rules.line_comment_prefix = "#";
        rules.block_comment_delimiters = {};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_sql_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "SELECT", "FROM", "WHERE", "INSERT", "INTO", "VALUES", "UPDATE", "SET",
            "DELETE", "CREATE", "DROP", "ALTER", "TABLE", "INDEX", "VIEW", "DATABASE",
            "SCHEMA", "GRANT", "REVOKE", "JOIN", "INNER", "LEFT", "RIGHT", "FULL",
            "OUTER", "CROSS", "ON", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS",
            "NULL", "AS", "ORDER", "BY", "GROUP", "HAVING", "DISTINCT", "UNION", "ALL",
            "EXISTS", "ANY", "SOME", "CASE", "WHEN", "THEN", "ELSE", "END", "LIMIT",
            "OFFSET", "FETCH", "WITH", "RECURSIVE", "RETURNING", "TRIGGER", "PROCEDURE",
            "FUNCTION", "BEGIN", "COMMIT", "ROLLBACK", "SAVEPOINT", "PRIMARY", "KEY",
            "FOREIGN", "REFERENCES", "UNIQUE", "CHECK", "DEFAULT", "CONSTRAINT", "ASC",
            "DESC", "TOP", "DECLARE", "CURSOR", "IF", "WHILE", "EXEC", "EXECUTE",
            "ADD", "COLUMN", "CASCADE", "RESTRICT", "TRUNCATE", "REPLACE", "TEMPORARY",
            "TEMP", "EXPLAIN", "ANALYZE", "VACUUM", "REINDEX", "RENAME", "TO"
        };
        rules.types = {
            "INT", "INTEGER", "BIGINT", "SMALLINT", "TINYINT", "FLOAT", "DOUBLE",
            "DECIMAL", "NUMERIC", "REAL", "CHAR", "VARCHAR", "TEXT", "NCHAR", "NVARCHAR",
            "NTEXT", "BLOB", "CLOB", "DATE", "TIME", "TIMESTAMP", "DATETIME", "BOOLEAN",
            "SERIAL", "UUID", "JSON", "JSONB", "XML", "BINARY", "VARBINARY", "BIT", "MONEY",
            "BIGSERIAL", "SMALLSERIAL", "INTERVAL",
        };
        rules.operators = {
            "<>", "!=", "<=", ">=", "||", "::", "==",
            "=", "<", ">", "+", "-", "*", "/", "%",
            ".", ",", ";", "(", ")", "[", "]"
        };
        rules.line_comment_prefix = "--";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        rules.case_insensitive_keywords = true;
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_html_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "DOCTYPE", "html", "head", "body", "div", "span", "p", "a", "img", "ul",
            "ol", "li", "table", "tr", "td", "th", "form", "input", "button", "select",
            "option", "textarea", "script", "style", "link", "meta", "title", "header",
            "footer", "nav", "main", "section", "article", "aside", "h1", "h2", "h3",
            "h4", "h5", "h6", "br", "hr", "pre", "code", "strong", "em", "b", "i",
            "u", "sub", "sup", "blockquote", "iframe", "video", "audio", "source",
            "canvas", "svg", "path", "label", "fieldset", "legend", "details", "summary"
        };
        rules.types = {
            "class", "id", "href", "src", "alt", "type", "name", "value", "placeholder",
            "action", "method", "target", "rel", "media", "charset", "content", "width",
            "height", "style", "onclick", "onload", "data", "role", "aria",
        };
        rules.operators = {
            "=", "<", ">", "/", ".", ",", ";", ":", "(", ")", "[", "]", "{", "}"
        };
        rules.line_comment_prefix = "";
        rules.block_comment_delimiters = {"<!--", "-->"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_css_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "import", "media", "keyframes", "font-face", "charset", "supports", "page",
            "layer", "important", "inherit", "initial", "unset", "revert", "auto", "none",
            "block", "inline", "flex", "grid", "relative", "absolute", "fixed", "sticky",
            "static", "hidden", "visible", "solid", "dashed", "dotted", "transparent",
            "currentColor", "normal", "bold", "italic", "underline", "nowrap", "wrap",
            "center", "left", "right", "top", "bottom", "both", "all",
        };
        rules.types = {
            "px", "em", "rem", "vh", "vw", "vmin", "vmax", "deg", "rad", "s", "ms",
            "fr", "ch", "ex", "calc", "var", "rgb", "rgba", "hsl", "hsla",
            "linear-gradient", "radial-gradient", "url", "attr", "min", "max", "clamp",
            "repeat", "minmax", "fit-content",
        };
        rules.operators = {
            ":", ";", ",", ".", "#", ">", "+", "~", "*", "=", "(", ")", "[", "]", "{", "}"
        };
        rules.line_comment_prefix = "";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_json_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {"true", "false", "null"};
        rules.types = {};
        rules.operators = {":", ",", "[", "]", "{", "}"};
        rules.line_comment_prefix = "";
        rules.block_comment_delimiters = {};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_yaml_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "true", "false", "null", "yes", "no", "on", "off",
            "True", "False", "Null", "Yes", "No", "On", "Off",
            "TRUE", "FALSE", "NULL", "YES", "NO", "ON", "OFF",
        };
        rules.types = {};
        rules.operators = {
            ":", "-", "|", ">", "*", "&", "!", ",", "[", "]", "{", "}"
        };
        rules.line_comment_prefix = "#";
        rules.block_comment_delimiters = {};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_lua_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
            "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
            "true", "until", "while"
        };
        rules.types = {};
        rules.builtins = {
            "print", "type", "tostring", "tonumber", "pairs", "ipairs", "next", "select",
            "unpack", "require", "error", "pcall", "xpcall", "setmetatable", "getmetatable",
            "rawget", "rawset", "rawlen", "assert", "collectgarbage", "dofile", "load",
            "loadfile", "rawequal",
        };
        rules.operators = {
            "//", "..", "...", "~=", "<=", ">=", "==", "<<", ">>",
            "+", "-", "*", "/", "%", "^", "#", "&", "|", "~",
            "<", ">", "=", ".", ",", ";", ":", "(", ")", "[", "]", "{", "}"
        };
        rules.line_comment_prefix = "--";
        rules.block_comment_delimiters = {"--[[", "]]"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_perl_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "my", "our", "local", "use", "no", "require", "package", "sub", "return",
            "if", "elsif", "else", "unless", "while", "until", "for", "foreach", "do",
            "last", "next", "redo", "goto", "die", "warn", "print", "say", "chomp",
            "chop", "push", "pop", "shift", "unshift", "splice", "sort", "reverse",
            "map", "grep", "join", "split", "keys", "values", "exists", "delete",
            "defined", "undef", "eval", "BEGIN", "END", "given", "when", "default"
        };
        rules.types = {};
        rules.builtins = {
            "open", "close", "read", "write", "seek", "tell", "eof", "binmode",
            "stat", "lstat", "rename", "unlink", "mkdir", "rmdir", "chdir", "chmod",
            "chown", "glob", "opendir", "readdir", "closedir", "length", "substr",
            "index", "rindex", "sprintf", "printf", "chomp", "chop", "lc", "uc",
            "lcfirst", "ucfirst", "hex", "oct", "int", "abs", "sqrt", "log", "exp",
            "sin", "cos", "atan2", "rand", "srand", "time", "localtime", "gmtime",
        };
        rules.operators = {
            "=>", "->", "::", "=~", "!~", "<=>", "++", "--", "**",
            "+=", "-=", "*=", "/=", "%=", "**=", ".=", "x=", "&&=", "||=", "//=",
            "==", "!=", "<=", ">=", "&&", "||", "//", "<<", ">>",
            "=", "<", ">", "+", "-", "*", "/", "%", ".", "x", "&", "|", "^", "~", "!",
            ",", ";", ":", "?", "(", ")", "[", "]", "{", "}", "@", "$"
        };
        rules.line_comment_prefix = "#";
        rules.block_comment_delimiters = {"=pod", "=cut"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_systemverilog_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "module", "endmodule", "interface", "endinterface", "program", "endprogram",
            "package", "endpackage", "class", "endclass", "function", "endfunction",
            "task", "endtask", "begin", "end", "if", "else", "case", "endcase",
            "for", "foreach", "while", "repeat", "do", "forever", "return", "break",
            "continue", "generate", "endgenerate", "assign", "always", "always_ff",
            "always_comb", "always_latch", "initial", "final", "posedge", "negedge",
            "clocking", "endclocking", "property", "endproperty", "assert", "assume",
            "cover", "sequence", "endsequence", "rand", "randc", "constraint", "solve",
            "inside", "dist", "with", "new", "this", "super", "virtual", "typedef",
            "enum", "struct", "union", "packed", "signed", "unsigned", "const", "static",
            "automatic", "import", "export", "local", "protected", "pure", "extern",
        };
        rules.types = {
            "logic", "reg", "wire", "bit", "byte", "shortint", "int", "longint",
            "integer", "time", "shortreal", "real", "realtime", "string", "event",
            "chandle", "semaphore", "mailbox", "process",
        };
        rules.builtins = {
            "$display", "$write", "$monitor", "$strobe", "$time", "$realtime",
            "$finish", "$stop", "$fatal", "$error", "$warning", "$info", "$random",
            "$urandom", "$urandom_range", "$clog2", "$bits", "$isunknown", "$signed",
            "$unsigned", "$cast", "$test$plusargs", "$value$plusargs", "$readmemh",
            "$readmemb", "$fopen", "$fclose", "$fdisplay", "$fwrite",
        };
        rules.operators = {
            "<<<", ">>>", "<<", ">>", "<=", ">=", "===", "!==", "==", "!=", "&&", "||",
            "->", "<->", "=>", "::", "++", "--", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=",
            "=", "<", ">", "+", "-", "*", "/", "%", "&", "|", "^", "~", "!", "?",
            ".", ",", ";", ":", "@", "#", "$", "(", ")", "[", "]", "{", "}"
        };
        rules.line_comment_prefix = "//";
        rules.block_comment_delimiters = {"/*", "*/"};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_toml_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {"true", "false"};
        rules.types = {"nan", "inf"};
        rules.operators = {"=", ".", ",", "[", "]", "{", "}", ":"};
        rules.line_comment_prefix = "#";
        rules.block_comment_delimiters = {};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_dockerfile_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "FROM", "RUN", "CMD", "LABEL", "EXPOSE", "ENV", "ADD", "COPY", "ENTRYPOINT",
            "VOLUME", "USER", "WORKDIR", "ARG", "ONBUILD", "STOPSIGNAL", "HEALTHCHECK",
            "SHELL", "MAINTAINER",
        };
        rules.types = {"AS"};
        rules.operators = {"=", "\\", ":", ",", "[", "]"};
        rules.line_comment_prefix = "#";
        rules.block_comment_delimiters = {};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        rules.case_insensitive_keywords = true;
        initialized = true;
    }
    return rules;
}

static const LanguageRules& get_makefile_rules() {
    static LanguageRules rules;
    static bool initialized = false;
    if (!initialized) {
        rules.keywords = {
            "include", "ifdef", "ifndef", "ifeq", "ifneq", "else", "endif",
            "define", "endef", "override", "export", "unexport", "private", "vpath",
        };
        rules.types = {
            ".PHONY", ".DEFAULT", ".SUFFIXES", ".PRECIOUS", ".INTERMEDIATE",
            ".SECONDARY", ".SECONDEXPANSION", ".DELETE_ON_ERROR", ".IGNORE", ".SILENT",
        };
        rules.operators = {":", "::", "=", ":=", "+=", "?=", "!=", "$", "(", ")", "{", "}", ","};
        rules.line_comment_prefix = "#";
        rules.block_comment_delimiters = {};
        rules.string_delimiters = {"\"", "\""};
        rules.single_quote_string_delimiters = {"'", "'"};
        initialized = true;
    }
    return rules;
}

// ============================================================================
// Lexer Factory
// ============================================================================

std::unique_ptr<Lexer> create_lexer(std::string_view language_name) {
    // Normalize to lowercase
    std::string lang(language_name);
    std::transform(lang.begin(), lang.end(), lang.begin(), ::tolower);

    if (lang == "cpp" || lang == "c++" || lang == "c" || lang == "cc" || lang == "cxx" || lang == "h" || lang == "hpp")
        return std::make_unique<SimpleLexer>(get_cpp_rules());
    if (lang == "python" || lang == "py")
        return std::make_unique<SimpleLexer>(get_python_rules());
    if (lang == "javascript" || lang == "js")
        return std::make_unique<SimpleLexer>(get_javascript_rules());
    if (lang == "typescript" || lang == "ts")
        return std::make_unique<SimpleLexer>(get_typescript_rules());
    if (lang == "java")
        return std::make_unique<SimpleLexer>(get_java_rules());
    if (lang == "go" || lang == "golang")
        return std::make_unique<SimpleLexer>(get_go_rules());
    if (lang == "rust" || lang == "rs")
        return std::make_unique<SimpleLexer>(get_rust_rules());
    if (lang == "ruby" || lang == "rb")
        return std::make_unique<SimpleLexer>(get_ruby_rules());
    if (lang == "php")
        return std::make_unique<SimpleLexer>(get_php_rules());
    if (lang == "csharp" || lang == "cs" || lang == "c#")
        return std::make_unique<SimpleLexer>(get_csharp_rules());
    if (lang == "swift")
        return std::make_unique<SimpleLexer>(get_swift_rules());
    if (lang == "kotlin" || lang == "kt")
        return std::make_unique<SimpleLexer>(get_kotlin_rules());
    if (lang == "bash" || lang == "sh" || lang == "shell" || lang == "zsh")
        return std::make_unique<SimpleLexer>(get_bash_rules());
    if (lang == "sql")
        return std::make_unique<SimpleLexer>(get_sql_rules());
    if (lang == "html" || lang == "htm")
        return std::make_unique<SimpleLexer>(get_html_rules());
    if (lang == "css")
        return std::make_unique<SimpleLexer>(get_css_rules());
    if (lang == "json")
        return std::make_unique<SimpleLexer>(get_json_rules());
    if (lang == "yaml" || lang == "yml")
        return std::make_unique<SimpleLexer>(get_yaml_rules());
    if (lang == "lua")
        return std::make_unique<SimpleLexer>(get_lua_rules());
    if (lang == "perl" || lang == "pl")
        return std::make_unique<SimpleLexer>(get_perl_rules());
    if (lang == "systemverilog" || lang == "sv" || lang == "svh" || lang == "verilog" || lang == "v")
        return std::make_unique<SimpleLexer>(get_systemverilog_rules());
    if (lang == "toml")
        return std::make_unique<SimpleLexer>(get_toml_rules());
    if (lang == "dockerfile" || lang == "docker")
        return std::make_unique<SimpleLexer>(get_dockerfile_rules());
    if (lang == "makefile" || lang == "make" || lang == "mk")
        return std::make_unique<SimpleLexer>(get_makefile_rules());

    // Default: no highlighting
    static const LanguageRules default_rules = {};
    return std::make_unique<SimpleLexer>(default_rules);
}

} // namespace highlighter
} // namespace cich
