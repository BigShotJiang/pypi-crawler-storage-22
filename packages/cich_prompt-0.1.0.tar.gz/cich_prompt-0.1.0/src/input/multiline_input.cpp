// multiline_input.cpp
#include "cich/input/multiline_input.hpp"
#include "cich/system/clipboard.hpp"

#include <termios.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <poll.h>
#include <errno.h>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <csignal>
#include <cstring>
#include <future>
#include <locale.h>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <unordered_set>
#include <vector>
#include <wchar.h>

namespace input {
namespace {

[[noreturn]] void throw_errno(const char* what) {
    throw std::runtime_error(std::string(what) + ": " + std::strerror(errno));
}

bool write_all(int fd, const char* p, size_t n) {
    while (n > 0) {
        const ssize_t w = ::write(fd, p, n);
        if (w < 0) {
            if (errno == EINTR) continue;
            return false;
        }
        p += static_cast<size_t>(w);
        n -= static_cast<size_t>(w);
    }
    return true;
}

void out(std::string_view s) {
    if (!write_all(STDOUT_FILENO, s.data(), s.size())) {
        throw_errno("write");
    }
}

char read_byte_blocking() {
    char c = 0;
    while (true) {
        const ssize_t r = ::read(STDIN_FILENO, &c, 1);
        if (r == 1) return c;
        if (r < 0 && errno == EINTR) continue;
        throw_errno("read");
    }
}

// Read a single byte with poll-based timeout; returns nullopt on timeout.
std::optional<char> read_byte_timeout_ms(int timeout_ms) {
    pollfd pfd{};
    pfd.fd = STDIN_FILENO;
    pfd.events = POLLIN;

    while (true) {
        const int pr = ::poll(&pfd, 1, timeout_ms);
        if (pr == 0) return std::nullopt;
        if (pr < 0) {
            if (errno == EINTR) continue;
            throw_errno("poll");
        }

        if ((pfd.revents & POLLIN) != 0) {
            char c = 0;
            while (true) {
                const ssize_t r = ::read(STDIN_FILENO, &c, 1);
                if (r == 1) return c;
                if (r < 0 && errno == EINTR) continue;
                throw_errno("read");
            }
        }

        if ((pfd.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0) {
            return std::nullopt;
        }
    }
}

std::pair<int, int> term_size() {
    winsize ws{};
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) != 0) {
        return {80, 24};
    }
    const int cols = ws.ws_col > 0 ? static_cast<int>(ws.ws_col) : 80;
    const int rows = ws.ws_row > 0 ? static_cast<int>(ws.ws_row) : 24;
    return {cols, rows};
}

struct RawTerm {
    termios old{};
    bool active = false;

    RawTerm() {
        if (!isatty(STDIN_FILENO)) {
            errno = ENOTTY;
            throw_errno("stdin is not a TTY");
        }
        if (tcgetattr(STDIN_FILENO, &old) != 0) throw_errno("tcgetattr");

        termios raw = old;
        raw.c_lflag &= ~(ECHO | ICANON | IEXTEN | ISIG);
        raw.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
        raw.c_oflag &= ~(OPOST);
        raw.c_cflag |= (CS8);
        raw.c_cc[VMIN] = 1;
        raw.c_cc[VTIME] = 0;

        if (tcsetattr(STDIN_FILENO, TCSADRAIN, &raw) != 0) throw_errno("tcsetattr(raw)");
        active = true;
    }

    ~RawTerm() {
        if (active) {
            tcsetattr(STDIN_FILENO, TCSADRAIN, &old);
        }
    }
};


enum class KeyKind {
    Char,
    Enter,
    Backspace,
    CtrlC,
    CtrlN,
    CtrlD,
    CtrlV,
    CtrlShiftV,
    CtrlW,
    Left,
    Right,
    Up,
    Down,
    CtrlLeft,
    CtrlRight,
    CtrlUp,
    CtrlDown,
    UpLine,
    DownLine,
    Home,
    End,
    CtrlA,
    CtrlE,
    CtrlU,
    CtrlK,
    CtrlDelete,
    Delete,
    Unknown
};

struct KeyEvent {
    KeyKind kind = KeyKind::Unknown;
    std::string text;
};

std::string read_esc_suffix() {
    std::string s;
    auto read_byte_timeout = [](int timeout_ms) -> std::optional<char> {
        pollfd pfd{};
        pfd.fd = STDIN_FILENO;
        pfd.events = POLLIN;

        while (true) {
            const int pr = ::poll(&pfd, 1, timeout_ms);
            if (pr == 0) return std::nullopt;
            if (pr < 0) {
                if (errno == EINTR) continue;
                throw_errno("poll");
            }

            if ((pfd.revents & POLLIN) != 0) {
                char c = 0;
                while (true) {
                    const ssize_t r = ::read(STDIN_FILENO, &c, 1);
                    if (r == 1) return c;
                    if (r < 0 && errno == EINTR) continue;
                    throw_errno("read");
                }
            }

            if ((pfd.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0) {
                return std::nullopt;
            }
        }
    };

    const std::optional<char> first = read_byte_timeout(20);
    if (!first.has_value()) return s;
    s.push_back(*first);
    if (s[0] != '[' && s[0] != 'O') return s;

    for (int i = 0; i < 24; ++i) {
        const std::optional<char> next = read_byte_timeout(10);
        if (!next.has_value()) break;
        const char c = *next;
        s.push_back(c);
        if (c == 'A' || c == 'B' || c == 'C' || c == 'D' || c == '~' || c == 'u') {
            break;
        }
    }
    return s;
}

KeyEvent read_key() {
    const char c = read_byte_blocking();
    if (c == '\x01') return {KeyKind::CtrlA, {}};
    if (c == '\x03') return {KeyKind::CtrlC, {}};
    if (c == '\x0e') return {KeyKind::CtrlN, {}};
    if (c == '\x04') return {KeyKind::CtrlD, {}};
    if (c == '\x05') return {KeyKind::CtrlE, {}};
    if (c == '\x0b') return {KeyKind::CtrlK, {}};
    if (c == '\x15') return {KeyKind::CtrlU, {}};
    if (c == '\x16') return {KeyKind::CtrlV, {}};
    if (c == '\r' || c == '\n') return {KeyKind::Enter, {}};
    if (c == '\x7f') return {KeyKind::Backspace, {}};
    if (c == '\x08') return {KeyKind::CtrlW, {}};
    if (c == '\x17') return {KeyKind::CtrlW, {}};

    if (c == '\x1b') {
        const std::string suf = read_esc_suffix();
        auto ends = [&](char last) { return !suf.empty() && suf.back() == last; };
        auto has_ctrl = [&]() {
            return suf.find(";5") != std::string::npos || suf.find("[5") != std::string::npos;
        };

        if (suf == "\x7f" || suf == "\x08") return {KeyKind::CtrlW, {}};
        if (ends('u') && (suf.find("127;5") != std::string::npos ||
                          suf.find("8;5") != std::string::npos)) {
            return {KeyKind::CtrlW, {}};
        }

        if (ends('A')) return {has_ctrl() ? KeyKind::CtrlUp : KeyKind::UpLine, {}};
        if (ends('B')) return {has_ctrl() ? KeyKind::CtrlDown : KeyKind::DownLine, {}};
        if (ends('C')) return {has_ctrl() ? KeyKind::CtrlRight : KeyKind::Right, {}};
        if (ends('D')) return {has_ctrl() ? KeyKind::CtrlLeft : KeyKind::Left, {}};
        if (ends('u') && (suf.find("86;") != std::string::npos || suf.find("118;") != std::string::npos)) {
            // Check for Ctrl+Shift+V (modifier 6 = Shift+Ctrl)
            if (suf.find(";6u") != std::string::npos) {
                return {KeyKind::CtrlShiftV, {}};
            }
            return {KeyKind::CtrlV, {}};
        }
        if (ends('H') || suf.find("[1~") == 0 || suf.find("[7~") == 0) return {KeyKind::Home, {}};
        if (ends('F') || suf.find("[4~") == 0 || suf.find("[8~") == 0) return {KeyKind::End, {}};
        if (!suf.empty() && suf[0] == '[' && suf.back() == '~') {
            if (suf.find("[3;5~") == 0) return {KeyKind::CtrlDelete, {}};
            if (suf.find("[3") == 0) return {KeyKind::Delete, {}};
        }
        if (!suf.empty() && suf[0] != '[' && suf[0] != 'O') {
            return {KeyKind::Char, suf};
        }
        return {KeyKind::Unknown, {}};
    }

    const unsigned char uc = static_cast<unsigned char>(c);
    if (uc >= 0x20 && uc != 0x7f) {
        const auto utf8_len = [](unsigned char lead) -> int {
            if (lead < 0x80) return 1;
            if ((lead & 0xE0) == 0xC0) return 2;
            if ((lead & 0xF0) == 0xE0) return 3;
            if ((lead & 0xF8) == 0xF0) return 4;
            return 1;
        };
        const int need = utf8_len(uc);
        std::string out;
        out.reserve(static_cast<size_t>(need));
        out.push_back(c);
        for (int i = 1; i < need; ++i) {
            out.push_back(read_byte_blocking());
        }
        return {KeyKind::Char, out};
    }
    return {KeyKind::Unknown, {}};
}

inline bool is_space(char c) {
    return c == ' ' || c == '\t' || c == '\n';
}

inline bool is_utf8_cont(unsigned char c) {
    return (c & 0xC0) == 0x80;
}

size_t utf8_prev(std::string_view s, size_t i) {
    if (i == 0) return 0;
    size_t p = i - 1;
    while (p > 0 && is_utf8_cont(static_cast<unsigned char>(s[p]))) p--;
    return p;
}

size_t utf8_next(std::string_view s, size_t i) {
    if (i >= s.size()) return s.size();
    size_t n = i + 1;
    while (n < s.size() && is_utf8_cont(static_cast<unsigned char>(s[n]))) n++;
    return n;
}

inline bool is_space_at(std::string_view s, size_t pos) {
    const unsigned char c = static_cast<unsigned char>(s[pos]);
    if (c < 0x80) return is_space(static_cast<char>(c));
    return false;
}

struct DecodedCp {
    uint32_t cp = 0;
    size_t len = 1;
    bool ok = false;
};

DecodedCp decode_utf8(std::string_view s, size_t i) {
    DecodedCp d{};
    if (i >= s.size()) return d;
    const unsigned char lead = static_cast<unsigned char>(s[i]);
    if (lead < 0x80) {
        d.cp = lead;
        d.len = 1;
        d.ok = true;
        return d;
    }
    int need = 0;
    if ((lead & 0xE0) == 0xC0) need = 2;
    else if ((lead & 0xF0) == 0xE0) need = 3;
    else if ((lead & 0xF8) == 0xF0) need = 4;
    else { d.len = 1; return d; }
    if (i + static_cast<size_t>(need) > s.size()) { d.len = 1; return d; }
    uint32_t cp = lead & ((1u << (8 - need - 1)) - 1);
    for (int j = 1; j < need; ++j) {
        const unsigned char c = static_cast<unsigned char>(s[i + j]);
        if (!is_utf8_cont(c)) { d.len = 1; return d; }
        cp = (cp << 6) | (c & 0x3F);
    }
    d.cp = cp;
    d.len = static_cast<size_t>(need);
    d.ok = true;
    return d;
}

inline bool is_variation_selector(uint32_t cp) {
    return (cp >= 0xFE00 && cp <= 0xFE0F) || (cp >= 0xE0100 && cp <= 0xE01EF);
}

inline bool is_zwj(uint32_t cp) {
    return cp == 0x200D;
}

inline bool is_emoji_modifier(uint32_t cp) {
    return cp >= 0x1F3FB && cp <= 0x1F3FF;
}

inline bool is_regional_indicator(uint32_t cp) {
    return cp >= 0x1F1E6 && cp <= 0x1F1FF;
}

inline bool is_combining(uint32_t cp) {
    // (unchanged: your original combining ranges)
    return (cp >= 0x0300 && cp <= 0x036F) ||
           (cp >= 0x1AB0 && cp <= 0x1AFF) ||
           (cp >= 0x1DC0 && cp <= 0x1DFF) ||
           (cp >= 0x20D0 && cp <= 0x20FF) ||
           (cp >= 0xFE20 && cp <= 0xFE2F) ||
           (cp >= 0x0483 && cp <= 0x0489) ||
           (cp >= 0x0591 && cp <= 0x05BD) ||
           cp == 0x05BF ||
           (cp >= 0x05C1 && cp <= 0x05C2) ||
           (cp >= 0x05C4 && cp <= 0x05C5) ||
           cp == 0x05C7 ||
           (cp >= 0x0610 && cp <= 0x061A) ||
           (cp >= 0x064B && cp <= 0x065F) ||
           cp == 0x0670 ||
           (cp >= 0x06D6 && cp <= 0x06DC) ||
           (cp >= 0x06DF && cp <= 0x06E4) ||
           (cp >= 0x06E7 && cp <= 0x06E8) ||
           (cp >= 0x06EA && cp <= 0x06ED) ||
           cp == 0x0711 ||
           (cp >= 0x0730 && cp <= 0x074A) ||
           (cp >= 0x07A6 && cp <= 0x07B0) ||
           (cp >= 0x07EB && cp <= 0x07F3) ||
           (cp >= 0x0816 && cp <= 0x0819) ||
           (cp >= 0x081B && cp <= 0x0823) ||
           (cp >= 0x0825 && cp <= 0x0827) ||
           (cp >= 0x0829 && cp <= 0x082D) ||
           (cp >= 0x08D3 && cp <= 0x08E1) ||
           (cp >= 0x08E3 && cp <= 0x0902) ||
           cp == 0x093A || cp == 0x093C ||
           (cp >= 0x0941 && cp <= 0x0948) ||
           cp == 0x094D ||
           (cp >= 0x0951 && cp <= 0x0957) ||
           (cp >= 0x0962 && cp <= 0x0963) ||
           cp == 0x0981 || cp == 0x09BC ||
           (cp >= 0x09C1 && cp <= 0x09C4) ||
           cp == 0x09CD ||
           (cp >= 0x09E2 && cp <= 0x09E3) ||
           (cp >= 0x0A01 && cp <= 0x0A02) ||
           cp == 0x0A3C ||
           (cp >= 0x0A41 && cp <= 0x0A42) ||
           (cp >= 0x0A47 && cp <= 0x0A48) ||
           (cp >= 0x0A4B && cp <= 0x0A4D) ||
           cp == 0x0A51 ||
           (cp >= 0x0A70 && cp <= 0x0A71) ||
           cp == 0x0A75 ||
           (cp >= 0x0A81 && cp <= 0x0A82) ||
           cp == 0x0ABC ||
           (cp >= 0x0AC1 && cp <= 0x0AC5) ||
           (cp >= 0x0AC7 && cp <= 0x0AC8) ||
           cp == 0x0ACD ||
           (cp >= 0x0AE2 && cp <= 0x0AE3) ||
           cp == 0x0B01 || cp == 0x0B3C ||
           cp == 0x0B3F ||
           (cp >= 0x0B41 && cp <= 0x0B44) ||
           cp == 0x0B4D || cp == 0x0B56 ||
           (cp >= 0x0B62 && cp <= 0x0B63) ||
           cp == 0x0B82 || cp == 0x0BC0 || cp == 0x0BCD ||
           cp == 0x0C00 || cp == 0x0C04 ||
           (cp >= 0x0C3E && cp <= 0x0C40) ||
           (cp >= 0x0C46 && cp <= 0x0C48) ||
           (cp >= 0x0C4A && cp <= 0x0C4D) ||
           (cp >= 0x0C55 && cp <= 0x0C56) ||
           (cp >= 0x0C62 && cp <= 0x0C63) ||
           cp == 0x0C81 || cp == 0x0CBC || cp == 0x0CBF ||
           cp == 0x0CC6 ||
           (cp >= 0x0CCC && cp <= 0x0CCD) ||
           (cp >= 0x0CE2 && cp <= 0x0CE3) ||
           (cp >= 0x0D00 && cp <= 0x0D01) ||
           (cp >= 0x0D3B && cp <= 0x0D3C) ||
           (cp >= 0x0D41 && cp <= 0x0D44) ||
           cp == 0x0D4D ||
           (cp >= 0x0D62 && cp <= 0x0D63) ||
           cp == 0x0D81 || cp == 0x0DCA ||
           (cp >= 0x0DD2 && cp <= 0x0DD4) ||
           cp == 0x0DD6 ||
           cp == 0x0E31 ||
           (cp >= 0x0E34 && cp <= 0x0E3A) ||
           (cp >= 0x0E47 && cp <= 0x0E4E) ||
           cp == 0x0EB1 ||
           (cp >= 0x0EB4 && cp <= 0x0EB9) ||
           (cp >= 0x0EBB && cp <= 0x0EBC) ||
           (cp >= 0x0EC8 && cp <= 0x0ECD) ||
           (cp >= 0x0F18 && cp <= 0x0F19) ||
           cp == 0x0F35 || cp == 0x0F37 || cp == 0x0F39 ||
           (cp >= 0x0F71 && cp <= 0x0F7E) ||
           (cp >= 0x0F80 && cp <= 0x0F84) ||
           (cp >= 0x0F86 && cp <= 0x0F87) ||
           (cp >= 0x0F8D && cp <= 0x0F97) ||
           (cp >= 0x0F99 && cp <= 0x0FBC) ||
           cp == 0x0FC6;
}

// "Emoji-ish" base ranges. This is intentionally conservative: it will NOT match
// Latin letters or umlauts (ae oe ue ss are far below these ranges).
inline bool is_emoji_base(uint32_t cp) {
    return
        (cp >= 0x1F300 && cp <= 0x1FAFF) || // pictographs + most emoji blocks
        (cp >= 0x1F600 && cp <= 0x1F64F) || // emoticons
        (cp >= 0x1F680 && cp <= 0x1F6FF) || // transport/map
        (cp >= 0x1F900 && cp <= 0x1F9FF) || // supplemental pictographs
        (cp >= 0x2600  && cp <= 0x26FF)  || // misc symbols
        (cp >= 0x2700  && cp <= 0x27BF);    // dingbats
}

// Returns true if any codepoint in [i, j) indicates emoji presentation/sequence.
// We treat flags (regional indicators), ZWJ sequences, VS, and skin-tone modifiers as emoji-ish
// only if anchored by an emoji base or RI (flags).
bool is_emoji_grapheme(std::string_view s, size_t i, size_t j) {
    bool has_base = false;
    bool has_ri = false;

    size_t k = i;
    while (k < j) {
        const DecodedCp d = decode_utf8(s, k);
        if (!d.ok) { k += 1; continue; }

        if (is_regional_indicator(d.cp)) has_ri = true;
        if (is_emoji_base(d.cp)) has_base = true;

        // If it's clearly emoji already, we can accept early.
        if (has_base || has_ri) return true;

        // These are "emoji mechanics"; alone they shouldn't cause masking.
        // We keep scanning until we see a base/RI.
        (void)is_variation_selector(d.cp);
        (void)is_zwj(d.cp);
        (void)is_emoji_modifier(d.cp);

        k += d.len;
    }
    return false;
}

void append_emoji_placeholder(std::string& out, int cell_width) {
    // Deterministic ASCII placeholders (never emoji).
    // Width 1: "?"
    // Width 2: "??"  (two cells)
    // Width <=0: nothing (should not happen for emoji graphemes)
    if (cell_width <= 0) return;
    if (cell_width == 1) { out.push_back('?'); return; }
    // Clamp everything >=2 to 2 to avoid messing with column math
    out.push_back('?');
    out.push_back('?');
}

size_t grapheme_next(std::string_view s, size_t i) {
    if (i >= s.size()) return s.size();
    const DecodedCp first = decode_utf8(s, i);
    if (!first.ok) return i + 1;
    size_t j = i + first.len;
    if (first.cp == 0x0D && j < s.size()) {
        const DecodedCp next = decode_utf8(s, j);
        if (next.ok && next.cp == 0x0A) return j + next.len;
    }
    if (is_regional_indicator(first.cp) && j < s.size()) {
        const DecodedCp next = decode_utf8(s, j);
        if (next.ok && is_regional_indicator(next.cp)) return j + next.len;
    }
    while (j < s.size()) {
        const DecodedCp next = decode_utf8(s, j);
        if (!next.ok) break;
        if (is_combining(next.cp) || is_variation_selector(next.cp) || is_emoji_modifier(next.cp)) {
            j += next.len;
            continue;
        }
        if (is_zwj(next.cp)) {
            size_t k = j + next.len;
            if (k >= s.size()) { j = k; break; }
            const DecodedCp after = decode_utf8(s, k);
            if (!after.ok) { j = k; break; }
            k += after.len;
            while (k < s.size()) {
                const DecodedCp more = decode_utf8(s, k);
                if (!more.ok) break;
                if (is_combining(more.cp) || is_variation_selector(more.cp) || is_emoji_modifier(more.cp)) {
                    k += more.len;
                    continue;
                }
                break;
            }
            j = k;
            continue;
        }
        break;
    }
    return j;
}

size_t grapheme_prev(std::string_view s, size_t pos) {
    if (pos == 0) return 0;
    size_t i = 0;
    size_t last = 0;
    while (i < pos) {
        last = i;
        const size_t next = grapheme_next(s, i);
        if (next <= i) { i = i + 1; }
        else i = next;
    }
    return last;
}

int codepoint_width(uint32_t cp) {
    if (cp == 0) return 0;
    if (cp < 0x20 || cp == 0x7F) return 0;

    const int w = ::wcwidth(static_cast<wchar_t>(cp));
    return (w < 0) ? 1 : w;
}

int grapheme_width(std::string_view s, size_t i, size_t j) {
    int w = 0;
    size_t k = i;
    while (k < j) {
        const DecodedCp d = decode_utf8(s, k);
        if (!d.ok) { k += 1; w = std::max(w, 1); continue; }
        w = std::max(w, codepoint_width(d.cp));
        k += d.len;
    }
    return w;
}

void ensure_locale() {
    static std::once_flag flag;
    std::call_once(flag, []() {
        setlocale(LC_CTYPE, "");
    });
}

size_t line_display_col(std::string_view s, size_t line_start, size_t pos) {
    if (pos <= line_start) return 0;
    size_t col = 0;
    size_t i = line_start;
    while (i < pos && i < s.size()) {
        if (s[i] == '\n') break;
        const size_t next = grapheme_next(s, i);
        const int w = grapheme_width(s, i, next);
        if (pos <= next) break;
        if (w > 0) col += static_cast<size_t>(w);
        i = next;
    }
    return col;
}

size_t line_pos_for_col(std::string_view s, size_t line_start, size_t line_end, size_t target_col) {
    size_t col = 0;
    size_t i = line_start;
    while (i < line_end && i < s.size()) {
        if (s[i] == '\n') break;
        const size_t next = grapheme_next(s, i);
        const int w = grapheme_width(s, i, next);
        if (w > 0 && col + static_cast<size_t>(w) > target_col) break;
        if (w > 0) col += static_cast<size_t>(w);
        i = next;
    }
    return (i > line_end) ? line_end : i;
}

struct EditorState {
    std::string buf;
    size_t cur = 0;
};

void backspace(EditorState& st) {
    if (st.cur == 0) return;
    const size_t prev = grapheme_prev(st.buf, st.cur);
    st.buf.erase(prev, st.cur - prev);
    st.cur = prev;
}

void del_forward(EditorState& st) {
    if (st.cur >= st.buf.size()) return;
    const size_t next = grapheme_next(st.buf, st.cur);
    st.buf.erase(st.cur, next - st.cur);
}

void insert_char(EditorState& st, std::string_view s) {
    st.buf.insert(st.cur, s);
    st.cur += s.size();
}

void insert_newline(EditorState& st) {
    st.buf.insert(st.cur, 1, '\n');
    st.cur++;
}

struct Render {
    std::vector<std::string> rows;
    size_t cursor_row = 0;
    size_t cursor_col = 1;
};

Render render_prompt_buffer(std::string_view prompt,
                            std::string_view buf,
                            size_t cur_idx,
                            int cols) {
    if (cols < 10) cols = 10;
    Render r;
    r.rows.emplace_back();

    int col = 1;
    auto newline = [&]() {
        r.rows.emplace_back();
        col = 1;
    };
    auto put_invisible = [&](char c) {
        r.rows.back().push_back(c);
    };

    auto emit_text = [&](std::string_view text, bool track_cursor, size_t cur_target) {
        struct SgrState {
            bool bold = false;
            bool dim = false;
            int fg = -1;

            bool any() const { return bold || dim || fg >= 0; }
            void reset() {
                bold = false;
                dim = false;
                fg = -1;
            }
        };

        auto sgr_sequence = [](const SgrState& s) -> std::string {
            if (!s.any()) return {};
            std::string seq = "\x1b[";
            bool first = true;
            auto add = [&](int v) {
                if (!first) seq.push_back(';');
                first = false;
                seq += std::to_string(v);
            };
            if (s.bold) add(1);
            if (s.dim) add(2);
            if (s.fg >= 0) add(s.fg);
            seq.push_back('m');
            return seq;
        };

        auto apply_sgr_params = [](SgrState& s, std::string_view params) {
            if (params.empty()) {
                s.reset();
                return;
            }
            size_t p = 0;
            while (p < params.size()) {
                int val = 0;
                bool has = false;
                while (p < params.size() && params[p] >= '0' && params[p] <= '9') {
                    has = true;
                    val = val * 10 + (params[p] - '0');
                    p++;
                }
                if (has) {
                    if (val == 0) {
                        s.reset();
                    } else if (val == 1) {
                        s.bold = true;
                    } else if (val == 2) {
                        s.dim = true;
                    } else if (val == 22) {
                        s.bold = false;
                        s.dim = false;
                    } else if (val == 39) {
                        s.fg = -1;
                    } else if ((val >= 30 && val <= 37) || (val >= 90 && val <= 97)) {
                        s.fg = val;
                    }
                }
                while (p < params.size() && params[p] != ';') p++;
                if (p < params.size() && params[p] == ';') p++;
            }
        };

        size_t cursor_set_at = std::string::npos;
        SgrState active_sgr;
        SgrState last_break_sgr;
        size_t last_break_text = std::string::npos;
        size_t last_break_next = std::string::npos;
        size_t last_break_row_size = 0;
        int last_break_col = 1;
        const std::string sgr_reset = "\x1b[0m";
        auto clear_break = [&]() {
            last_break_text = std::string::npos;
            last_break_next = std::string::npos;
        };

        size_t i = 0;
        while (i < text.size()) {
            if (track_cursor && i == cur_target) {
                r.cursor_row = r.rows.size() - 1;
                r.cursor_col = static_cast<size_t>(col);
                cursor_set_at = cur_target;
            }
            if (text[i] == '\x1b' && i + 1 < text.size() && text[i + 1] == '[') {
                const size_t seq_start = i;
                put_invisible(text[i]);
                put_invisible(text[i + 1]);
                i += 2;
                while (i < text.size()) {
                    const unsigned char uc = static_cast<unsigned char>(text[i]);
                    put_invisible(text[i]);
                    i++;
                    if (uc >= 0x40 && uc <= 0x7E) break;
                }
                if (i > seq_start) {
                    const char final = text[i - 1];
                    if (final == 'm') {
                        const size_t seq_len = i - seq_start;
                        const size_t params_start = seq_start + 2;
                        const size_t params_len = (seq_len >= 3) ? (seq_len - 3) : 0;
                        const std::string_view params = text.substr(params_start, params_len);
                        apply_sgr_params(active_sgr, params);
                    }
                }
                continue;
            }
            const char c = text[i];


            if (c == '\r') {
                // Collapse CRLF into a single newline
                if (i + 1 < text.size() && text[i + 1] == '\n') {
                    i++;  // skip the LF
                }
                if (active_sgr.any()) r.rows.back().append(sgr_reset);
                newline();
                clear_break();
                if (active_sgr.any()) r.rows.back().append(sgr_sequence(active_sgr));
                i++;
                continue;
            }


            if (c == '\t') {
                int tabstop = 4;
                int spaces = tabstop - ((col - 1) % tabstop);

                for (int k = 0; k < spaces; ++k) {
                    if (col > cols) {   // wrap before printing
                        if (active_sgr.any()) r.rows.back().append(sgr_reset);
                        newline();
                        clear_break();
                        if (active_sgr.any()) r.rows.back().append(sgr_sequence(active_sgr));
                    }
                    r.rows.back().push_back(' ');
                    col++;
                }
                i++;
                continue;
            }


            if ((unsigned char)c < 0x20 && c != '\n') {
                // Never allow raw ESC to pass (safety)
                if (c == '\x1b') {
                    r.rows.back().push_back('?');
                    col += 1;
                    i++;
                    continue;
                }
                r.rows.back().push_back('?');
                col += 1;
                i++;
                continue;
            }



            if (c == '\n') {
                if (active_sgr.any()) {
                    r.rows.back().append(sgr_reset);
                }
                newline();
                clear_break();
                if (active_sgr.any()) {
                    r.rows.back().append(sgr_sequence(active_sgr));
                }
                i++;
                continue;
            }
            const size_t next = grapheme_next(text, i);
            if (track_cursor && cur_target > i && cur_target < next) {
                r.cursor_row = r.rows.size() - 1;
                r.cursor_col = static_cast<size_t>(col);
                cursor_set_at = cur_target;
            }
            int w = grapheme_width(text, i, next);
            if (w > 0 && col + w - 1 > cols) {
                if (last_break_text != std::string::npos) {
                    r.rows.back().resize(last_break_row_size);
                    col = last_break_col;
                    active_sgr = last_break_sgr;
                    if (track_cursor && cursor_set_at != std::string::npos && cursor_set_at >= last_break_next) {
                        cursor_set_at = std::string::npos;
                    }
                    if (active_sgr.any()) {
                        r.rows.back().append(sgr_reset);
                    }
                    newline();
                    if (active_sgr.any()) {
                        r.rows.back().append(sgr_sequence(active_sgr));
                    }
                    i = last_break_next;
                    clear_break();
                    continue;
                }
                if (active_sgr.any()) {
                    r.rows.back().append(sgr_reset);
                }
                newline();
                clear_break();
                if (active_sgr.any()) {
                    r.rows.back().append(sgr_sequence(active_sgr));
                }
            }

            if (text[i] == ' ') {
                last_break_text = i;
                last_break_next = next;
                last_break_row_size = r.rows.back().size();
                last_break_col = col;
                last_break_sgr = active_sgr;
            }

            // Render-time emoji masking (buffer stays intact)
            if (is_emoji_grapheme(text, i, next)) {
                append_emoji_placeholder(r.rows.back(), w);
            } else {
                r.rows.back().append(text.substr(i, next - i));
            }

            if (w > 0) col += w;
            i = next;
        }
    };

    emit_text(prompt, false, 0);
    if (cur_idx == 0) {
        r.cursor_row = r.rows.size() - 1;
        r.cursor_col = static_cast<size_t>(col);
    }
    emit_text(buf, true, cur_idx);
    if (cur_idx >= buf.size()) {
        r.cursor_row = r.rows.size() - 1;
        r.cursor_col = static_cast<size_t>(col);
    }
    if (r.rows.empty()) r.rows.emplace_back();
    return r;
}

struct RegionRenderer {
    std::vector<std::string> prev_rows;
    size_t prev_row_count = 0;
    size_t prev_cursor_row = 0;

    void refresh(const Render& r) {
        const size_t old_cursor_row = prev_cursor_row;
        out("\r");
        if (old_cursor_row > 0) {
            out("\x1b[" + std::to_string(old_cursor_row) + "A");
        }
        const size_t new_n = r.rows.size();
        const size_t max_n = std::max(prev_row_count, new_n);
        for (size_t i = 0; i < max_n; ++i) {
            if (i > 0) out("\n\r");
            const std::string new_line = i < new_n ? r.rows[i] : "";
            const std::string old_line = i < prev_rows.size() ? prev_rows[i] : "";
            if (new_line != old_line) {
                out(new_line);
                out("\x1b[K");
            }
        }
        out("\r");
        if (max_n > 1) {
            out("\x1b[" + std::to_string(max_n - 1) + "A");
        }
        if (r.cursor_row > 0) {
            out("\x1b[" + std::to_string(r.cursor_row) + "B");
        }
        out("\x1b[" + std::to_string(r.cursor_col) + "G");
        prev_rows = r.rows;
        prev_row_count = new_n;
        prev_cursor_row = r.cursor_row;
    }

    void finish_newline() {
        // Move cursor to end of rendered region before outputting newline
        // to prevent overlapping with subsequent output
        if (prev_row_count > 0) {
            const size_t last_row = prev_row_count - 1;

            // Move to last row if not already there
            if (prev_cursor_row < last_row) {
                out("\x1b[" + std::to_string(last_row - prev_cursor_row) + "B");
            } else if (prev_cursor_row > last_row) {
                out("\x1b[" + std::to_string(prev_cursor_row - last_row) + "A");
            }

            // Move to far right (end of content on last row)
            out("\x1b[999G");
        }

        out("\r\n");
        prev_rows.clear();
        prev_row_count = 0;
        prev_cursor_row = 0;
    }
};

enum class EditorMode { NormalInput, EditExisting, AutoReturnMatch };

struct RunResult {
    std::optional<std::string> value;
    bool cancelled = false;
    bool timed_out = false;
};

constexpr size_t kShortPasteThreshold = 120;
constexpr size_t kLongHeadPreview = 24;
constexpr size_t kLongTailPreview = 36;

std::string sanitize_preview_text(std::string_view text, size_t max_chars) {
    std::string out;
    out.reserve(std::min(text.size(), max_chars));
    const auto utf8_len = [](unsigned char lead) -> int {
        if (lead < 0x80) return 1;
        if ((lead & 0xE0) == 0xC0) return 2;
        if ((lead & 0xF0) == 0xE0) return 3;
        if ((lead & 0xF8) == 0xF0) return 4;
        return 1;
    };
    size_t i = 0;
    size_t count = 0;
    while (i < text.size() && count < max_chars) {
        const unsigned char uc = static_cast<unsigned char>(text[i]);
        if (uc < 0x80) {
            const char c = static_cast<char>(uc);
            if (c == '\n' || c == '\r' || c == '\t') out.push_back(' ');
            else if (uc < 0x20 || uc == 0x7f) out.push_back('?');
            else out.push_back(c);
            i += 1;
            count += 1;
            continue;
        }
        const int need = utf8_len(uc);
        if (need <= 1 || i + static_cast<size_t>(need) > text.size()) {
            out.push_back('?');
            i += 1;
            count += 1;
            continue;
        }
        bool ok = true;
        for (int j = 1; j < need; ++j) {
            if (!is_utf8_cont(static_cast<unsigned char>(text[i + j]))) {
                ok = false;
                break;
            }
        }
        if (!ok) {
            out.push_back('?');
            i += 1;
            count += 1;
            continue;
        }
        out.append(text.substr(i, static_cast<size_t>(need)));
        i += static_cast<size_t>(need);
        count += 1;
    }
    return out;
}

std::string paste_status_line(std::string_view pasted) {
    const auto word_estimate = [](size_t bytes) -> size_t {
        return static_cast<size_t>(std::llround(static_cast<double>(bytes) / 5.1));
    };
    const std::string bold_green = "\x1b[1;32m";
    const std::string dim = "\x1b[2m";
    const std::string reset = "\x1b[0m";
    const std::string normal = "\x1b[0m";

    if (pasted.size() <= kShortPasteThreshold) {
        return bold_green + "[" + reset +
               dim + sanitize_preview_text(pasted, kShortPasteThreshold) + reset +
               bold_green + "]" + reset;
    }
    const std::string head = sanitize_preview_text(pasted.substr(0, kLongHeadPreview), kLongHeadPreview);
    const size_t tail_start = pasted.size() > kLongTailPreview ? pasted.size() - kLongTailPreview : 0;
    const std::string tail = sanitize_preview_text(pasted.substr(tail_start), kLongTailPreview);
    const size_t words = word_estimate(pasted.size());
    const std::string count_colored = "\x1b[1;33m" + std::to_string(words) + "\x1b[0m";
    return bold_green + "[" + reset +
           dim + head + reset +
           normal + " ...... " +
           dim + tail + reset +
           normal + ": " + count_colored + " words" +
           bold_green + "]" + reset;
}


static inline void normalize_newlines(std::string& s) {
    // Convert CRLF and bare CR into LF
    size_t w = 0;
    for (size_t r = 0; r < s.size(); ++r) {
        char c = s[r];
        if (c == '\r') {
            // if CRLF, skip the next LF
            if (r + 1 < s.size() && s[r + 1] == '\n') r++;
            s[w++] = '\n';
        } else {
            s[w++] = c;
        }
    }
    s.resize(w);
}


// =========================================================================
// Multi-region concealment.
// =========================================================================

struct ConcealRegion {
    size_t start = 0;
    size_t len = 0;
    std::string replacement;
    size_t end() const { return start + len; }
};

struct ConcealList {
    std::vector<ConcealRegion> regions;

    bool empty() const { return regions.empty(); }
    void clear() { regions.clear(); }

    void add(size_t start, size_t len, std::string replacement) {
        ConcealRegion cr;
        cr.start = start;
        cr.len = len;
        cr.replacement = std::move(replacement);
        auto it = std::lower_bound(
            regions.begin(), regions.end(), start,
            [](const ConcealRegion& r, size_t s) { return r.start < s; });
        regions.insert(it, std::move(cr));
    }

    void adjust_for_insert(size_t pos, size_t count) {
        for (auto& r : regions) {
            if (pos <= r.start) r.start += count;
            else if (pos < r.end()) r.len += count;
        }
    }

    void adjust_for_safe_erase(size_t pos, size_t count) {
        const size_t erase_end = pos + count;
        for (auto& r : regions) {
            if (erase_end <= r.start) r.start -= count;
        }
    }

    bool would_overlap(size_t pos, size_t count) const {
        if (count == 0) return false;
        const size_t erase_end = pos + count;
        for (const auto& r : regions) {
            if (pos < r.end() && erase_end > r.start) return true;
            if (r.start >= erase_end) break;
        }
        return false;
    }

    std::optional<size_t> find_adjacent(size_t pos) const {
        for (size_t i = 0; i < regions.size(); ++i) {
            if (regions[i].start == pos || regions[i].end() == pos) return i;
        }
        return std::nullopt;
    }

    void remove_region(size_t idx) {
        if (idx < regions.size()) {
            regions.erase(regions.begin() + static_cast<ptrdiff_t>(idx));
        }
    }

    const ConcealRegion* find_containing(size_t pos) const {
        for (const auto& r : regions) {
            if (pos >= r.start && pos < r.end()) return &r;
            if (r.start > pos) break;
        }
        return nullptr;
    }

    size_t step_left(std::string_view s, size_t pos) const {
        if (pos == 0) return 0;
        if (const ConcealRegion* cr = find_containing(pos)) {
            if (pos > cr->start) return cr->start;
        }
        size_t np = grapheme_prev(s, pos);
        const ConcealRegion* cr = find_containing(np);
        return cr ? cr->start : np;
    }

    size_t step_right(std::string_view s, size_t pos, size_t buf_size) const {
        if (pos >= buf_size) return buf_size;
        if (const ConcealRegion* cr = find_containing(pos)) {
            if (pos < cr->end()) return cr->end();
        }
        size_t np = grapheme_next(s, pos);
        const ConcealRegion* cr = find_containing(np);
        return cr ? cr->end() : np;
    }

    size_t line_start(std::string_view s, size_t idx) const {
        if (idx > s.size()) idx = s.size();
        while (idx > 0) {
            const ConcealRegion* cr = find_containing(idx - 1);
            if (cr) { idx = cr->start; continue; }
            if (s[idx - 1] == '\n') break;
            idx--;
        }
        return idx;
    }

    size_t line_end(std::string_view s, size_t idx) const {
        if (idx > s.size()) idx = s.size();
        while (idx < s.size()) {
            const ConcealRegion* cr = find_containing(idx);
            if (cr) { idx = cr->end(); continue; }
            if (s[idx] == '\n') break;
            idx++;
        }
        return idx;
    }

    size_t clamp(size_t cur) const {
        const ConcealRegion* cr = find_containing(cur);
        if (!cr) return cur;
        const size_t d_start = cur - cr->start;
        const size_t d_end = cr->end() - cur;
        return (d_start <= d_end) ? cr->start : cr->end();
    }

    void set_loading(size_t start, size_t len) {
        for (auto& r : regions) {
            if (r.start == start && r.len == len) {
                r.replacement = "[loading clipboard...]";
                return;
            }
        }
        add(start, len, "[loading clipboard...]");
    }
};

// =========================================================================
// Conceal-aware movement.
// =========================================================================

void move_left(EditorState& st, const ConcealList& conceals) {
    st.cur = conceals.step_left(st.buf, st.cur);
}

void move_right(EditorState& st, const ConcealList& conceals) {
    st.cur = conceals.step_right(st.buf, st.cur, st.buf.size());
}

void move_home(EditorState& st, const ConcealList& conceals) {
    st.cur = conceals.line_start(st.buf, st.cur);
}

void move_end(EditorState& st, const ConcealList& conceals) {
    st.cur = conceals.line_end(st.buf, st.cur);
}

void move_up_line(EditorState& st, const ConcealList& conceals) {
    const size_t cur_start = conceals.line_start(st.buf, st.cur);
    if (cur_start == 0) {
        // Already on first line, go to start of that line
        st.cur = 0;
        return;
    }
    const size_t target_col = line_display_col(st.buf, cur_start, st.cur);
    const size_t prev_end = cur_start - 1;
    const size_t prev_start = conceals.line_start(st.buf, prev_end);
    const size_t prev_line_end = conceals.line_end(st.buf, prev_start);
    st.cur = line_pos_for_col(st.buf, prev_start, prev_line_end, target_col);
    st.cur = conceals.clamp(st.cur);
}

void move_down_line(EditorState& st, const ConcealList& conceals) {
    const size_t cur_start = conceals.line_start(st.buf, st.cur);
    const size_t cur_end = conceals.line_end(st.buf, st.cur);
    if (cur_end >= st.buf.size()) {
        // Already on last line, go to end of that line
        st.cur = cur_end;
        return;
    }
    const size_t target_col = line_display_col(st.buf, cur_start, st.cur);
    const size_t next_start = cur_end + 1;
    const size_t next_end = conceals.line_end(st.buf, next_start);
    st.cur = line_pos_for_col(st.buf, next_start, next_end, target_col);
    st.cur = conceals.clamp(st.cur);
}

void ctrl_left(EditorState& st, const ConcealList& conceals) {
    while (st.cur > 0) {
        size_t prev = conceals.step_left(st.buf, st.cur);
        if (prev == st.cur) break;
        if (st.cur - prev > 1) { st.cur = prev; return; }
        if (!is_space_at(st.buf, prev)) { st.cur = prev; break; }
        st.cur = prev;
    }
    while (st.cur > 0) {
        size_t prev = conceals.step_left(st.buf, st.cur);
        if (prev == st.cur) break;
        if (st.cur - prev > 1) { st.cur = prev; return; }
        if (is_space_at(st.buf, prev)) break;
        st.cur = prev;
    }
}

void ctrl_right(EditorState& st, const ConcealList& conceals) {
    while (st.cur < st.buf.size()) {
        size_t next = conceals.step_right(st.buf, st.cur, st.buf.size());
        if (next == st.cur) break;
        if (next - st.cur > 1) { st.cur = next; return; }
        if (!is_space_at(st.buf, st.cur)) { st.cur = next; break; }
        st.cur = next;
    }
    while (st.cur < st.buf.size()) {
        size_t next = conceals.step_right(st.buf, st.cur, st.buf.size());
        if (next == st.cur) break;
        if (next - st.cur > 1) { st.cur = next; return; }
        if (is_space_at(st.buf, st.cur)) break;
        st.cur = next;
    }
}

// =========================================================================
// Render buffer with conceal replacements.
// =========================================================================

std::string render_buffer_with_conceal(const EditorState& st,
                                       const ConcealList& conceals,
                                       size_t& render_cur) {
    if (conceals.empty()) {
        render_cur = st.cur;
        return st.buf;
    }

    std::string shown;
    {
        size_t est = st.buf.size();
        for (const auto& r : conceals.regions) {
            if (r.start <= st.buf.size() && r.start + r.len <= st.buf.size())
                est = est - r.len + r.replacement.size();
        }
        shown.reserve(est);
    }

    size_t buf_pos = 0;
    size_t shown_pos = 0;
    bool cursor_mapped = false;

    auto maybe_map_cursor = [&](size_t buf_end) {
        if (!cursor_mapped && st.cur >= buf_pos && st.cur < buf_end) {
            render_cur = shown_pos + (st.cur - buf_pos);
            cursor_mapped = true;
        }
    };

    for (const auto& r : conceals.regions) {
        if (r.start > st.buf.size() || r.start + r.len > st.buf.size()) continue;
        if (r.start < buf_pos) continue;

        if (r.start > buf_pos) {
            const size_t chunk_len = r.start - buf_pos;
            maybe_map_cursor(r.start);
            shown.append(st.buf, buf_pos, chunk_len);
            shown_pos += chunk_len;
            buf_pos = r.start;
        }

        if (!cursor_mapped && st.cur >= r.start && st.cur <= r.end()) {
            if (st.cur == r.start) {
                render_cur = shown_pos;
            } else {
                render_cur = shown_pos + r.replacement.size();
            }
            cursor_mapped = true;
        }

        shown.append(r.replacement);
        shown_pos += r.replacement.size();
        buf_pos = r.end();
    }

    if (buf_pos < st.buf.size()) {
        const size_t remaining = st.buf.size() - buf_pos;
        maybe_map_cursor(st.buf.size());
        shown.append(st.buf, buf_pos, remaining);
        shown_pos += remaining;
    }

    if (!cursor_mapped) render_cur = shown_pos;
    return shown;
}

// =========================================================================
// Pending clipboard paste.
// =========================================================================

struct PendingPaste {
    bool active = false;
    size_t replace_pos = 0;
    size_t replace_len = 0;
    std::future<std::string> future;
    void clear() { active = false; replace_pos = 0; replace_len = 0; }
};

std::optional<size_t> find_loading_region_index(const ConcealList& conceals) {
    for (size_t i = 0; i < conceals.regions.size(); ++i) {
        if (conceals.regions[i].replacement == "[loading clipboard...]") {
            return i;
        }
    }
    return std::nullopt;
}

void start_clipboard_fetch(PendingPaste& pending, size_t replace_pos, size_t replace_len) {
    pending.active = true;
    pending.replace_pos = replace_pos;
    pending.replace_len = replace_len;
    pending.future = std::async(std::launch::async, []() {
        return clipboard::get_text(false, false);
    });
}

std::optional<size_t> clip_token_start_before_cursor(const EditorState& st) {
    constexpr std::string_view token = "/clip";
    if (st.cur < token.size()) return std::nullopt;
    const size_t start = st.cur - token.size();
    if (st.buf.compare(start, token.size(), token) == 0) return start;
    return std::nullopt;
}

std::optional<KeyEvent> read_key_timeout(int timeout_ms) {
    pollfd pfd{};
    pfd.fd = STDIN_FILENO;
    pfd.events = POLLIN;
    while (true) {
        const int pr = ::poll(&pfd, 1, timeout_ms);
        if (pr == 0) return std::nullopt;
        if (pr < 0) { if (errno == EINTR) continue; throw_errno("poll"); }
        if ((pfd.revents & POLLIN) != 0) return read_key();
        if ((pfd.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0) return std::nullopt;
    }
}

// =========================================================================
// Conceal-aware edit helpers.
// =========================================================================

void insert_char_concealed(EditorState& st, std::string_view s, ConcealList& conceals) {
    const size_t pos = st.cur;
    insert_char(st, s);
    conceals.adjust_for_insert(pos, s.size());
}

void insert_newline_concealed(EditorState& st, ConcealList& conceals) {
    const size_t pos = st.cur;
    insert_newline(st);
    conceals.adjust_for_insert(pos, 1);
}

void backspace_concealed(EditorState& st, ConcealList& conceals) {
    if (st.cur == 0) return;
    const size_t prev = grapheme_prev(st.buf, st.cur);
    const size_t count = st.cur - prev;
    if (conceals.would_overlap(prev, count)) return;
    backspace(st);
    conceals.adjust_for_safe_erase(prev, count);
}

void del_forward_concealed(EditorState& st, ConcealList& conceals) {
    if (st.cur >= st.buf.size()) return;
    const size_t next = grapheme_next(st.buf, st.cur);
    const size_t count = next - st.cur;
    if (conceals.would_overlap(st.cur, count)) return;
    del_forward(st);
    conceals.adjust_for_safe_erase(st.cur, count);
}

void erase_safe_range(EditorState& st, ConcealList& conceals, size_t pos, size_t count) {
    if (count == 0) return;
    st.buf.erase(pos, count);
    if (st.cur > pos) st.cur = (st.cur >= pos + count) ? st.cur - count : pos;
    conceals.adjust_for_safe_erase(pos, count);
}

std::pair<size_t, size_t> safe_word_left_range(const EditorState& st, const ConcealList& conceals) {
    size_t target = st.cur;
    while (target > 0) {
        const size_t prev = grapheme_prev(st.buf, target);
        if (prev == target) break;
        if (!is_space_at(st.buf, prev)) break;
        if (conceals.would_overlap(prev, target - prev)) break;
        target = prev;
    }
    while (target > 0) {
        const size_t prev = grapheme_prev(st.buf, target);
        if (prev == target) break;
        if (is_space_at(st.buf, prev)) break;
        if (conceals.would_overlap(prev, target - prev)) break;
        target = prev;
    }
    return {target, st.cur - target};
}

std::pair<size_t, size_t> safe_word_right_range(const EditorState& st, const ConcealList& conceals) {
    size_t target = st.cur;
    while (target < st.buf.size()) {
        if (!is_space_at(st.buf, target)) break;
        const size_t next = grapheme_next(st.buf, target);
        if (conceals.would_overlap(target, next - target)) break;
        target = next;
    }
    while (target < st.buf.size()) {
        if (is_space_at(st.buf, target)) break;
        const size_t next = grapheme_next(st.buf, target);
        if (conceals.would_overlap(target, next - target)) break;
        target = next;
    }
    return {st.cur, target - st.cur};
}

void delete_word_left_concealed(EditorState& st, ConcealList& conceals) {
    const std::optional<size_t> adj = conceals.find_adjacent(st.cur);
    if (adj.has_value() && conceals.regions[*adj].end() == st.cur) {
        const size_t rstart = conceals.regions[*adj].start;
        const size_t rlen = conceals.regions[*adj].len;
        conceals.remove_region(*adj);
        st.buf.erase(rstart, rlen);
        st.cur = rstart;
        conceals.adjust_for_safe_erase(rstart, rlen);
        return;
    }
    const auto [erase_start, erase_count] = safe_word_left_range(st, conceals);
    erase_safe_range(st, conceals, erase_start, erase_count);
}

void delete_word_right_concealed(EditorState& st, ConcealList& conceals) {
    const std::optional<size_t> adj = conceals.find_adjacent(st.cur);
    if (adj.has_value() && conceals.regions[*adj].start == st.cur) {
        const size_t rstart = conceals.regions[*adj].start;
        const size_t rlen = conceals.regions[*adj].len;
        conceals.remove_region(*adj);
        st.buf.erase(rstart, rlen);
        conceals.adjust_for_safe_erase(rstart, rlen);
        return;
    }
    const auto [erase_start, erase_count] = safe_word_right_range(st, conceals);
    erase_safe_range(st, conceals, erase_start, erase_count);
}

void delete_to_line_start_concealed(EditorState& st, ConcealList& conceals) {
    size_t start = conceals.line_start(st.buf, st.cur);
    if (start >= st.cur) return;
    while (start < st.cur && conceals.would_overlap(start, st.cur - start)) {
        bool found = false;
        for (const auto& r : conceals.regions) {
            if (r.start >= st.cur) break;
            if (start < r.end() && st.cur > r.start) {
                start = r.end();
                found = true;
                break;
            }
        }
        if (!found) break;
    }
    if (start >= st.cur) return;
    const size_t count = st.cur - start;
    if (conceals.would_overlap(start, count)) return;
    st.buf.erase(start, count);
    st.cur = start;
    conceals.adjust_for_safe_erase(start, count);
}

void delete_to_line_end_concealed(EditorState& st, ConcealList& conceals) {
    size_t end_pos = conceals.line_end(st.buf, st.cur);
    if (end_pos <= st.cur) return;
    while (end_pos > st.cur && conceals.would_overlap(st.cur, end_pos - st.cur)) {
        bool found = false;
        for (const auto& r : conceals.regions) {
            if (r.start >= end_pos) break;
            if (st.cur < r.end() && end_pos > r.start) {
                end_pos = r.start;
                found = true;
                break;
            }
        }
        if (!found) break;
    }
    if (end_pos <= st.cur) return;
    const size_t count = end_pos - st.cur;
    if (conceals.would_overlap(st.cur, count)) return;
    st.buf.erase(st.cur, count);
    conceals.adjust_for_safe_erase(st.cur, count);
}




// =========================================================================
// Main editor loop.
// =========================================================================

RunResult run_editor(const std::string& prompt,
                     EditorState st,
                     EditorMode mode,
                     const std::unordered_set<std::string>& auto_options,
                     bool edit_enter_newline,
                     int timeout_ms) {
    ensure_locale();
    RawTerm rt;

    RegionRenderer rr;
    PendingPaste pending{};
    ConcealList conceals;

    using clock = std::chrono::steady_clock;
    auto last_activity = clock::now();

    for (;;) {
        // --- Phase 1: Clipboard fetch completion ---
        if (pending.active) {
            if (const auto loading_idx = find_loading_region_index(conceals); loading_idx.has_value()) {
                pending.replace_pos = conceals.regions[*loading_idx].start;
                pending.replace_len = conceals.regions[*loading_idx].len;
            }
            if (pending.future.wait_for(std::chrono::milliseconds(0)) == std::future_status::ready) {
                std::string clip;
                try {
                    clip = pending.future.get();
                    normalize_newlines(clip);
                } catch (...) {
                    if (const auto loading_idx = find_loading_region_index(conceals); loading_idx.has_value()) {
                        conceals.remove_region(*loading_idx);
                    }
                    pending.clear();
                    continue;
                }

                if (pending.replace_pos > st.buf.size()) {
                    pending.replace_pos = st.buf.size();
                    pending.replace_len = 0;
                }
                if (pending.replace_pos + pending.replace_len > st.buf.size()) {
                    pending.replace_len = st.buf.size() - pending.replace_pos;
                }

                if (const auto loading_idx = find_loading_region_index(conceals); loading_idx.has_value()) {
                    conceals.remove_region(*loading_idx);
                }
                if (pending.replace_len > 0) {
                    conceals.adjust_for_safe_erase(pending.replace_pos, pending.replace_len);
                }

                const size_t old_cur = st.cur;
                const size_t replace_start = pending.replace_pos;
                const size_t replace_end = pending.replace_pos + pending.replace_len;
                st.buf.replace(replace_start, pending.replace_len, clip);
                if (old_cur < replace_start) {
                    st.cur = old_cur;
                } else if (old_cur > replace_end) {
                    if (clip.size() >= pending.replace_len) {
                        st.cur = old_cur + (clip.size() - pending.replace_len);
                    } else {
                        const size_t shrink = pending.replace_len - clip.size();
                        st.cur = (old_cur >= shrink) ? (old_cur - shrink) : 0;
                    }
                } else {
                    // Cursor was inside (or exactly at end of) replaced range.
                    st.cur = replace_start + clip.size();
                }
                conceals.adjust_for_insert(pending.replace_pos, clip.size());

                if (clip.size() > kShortPasteThreshold) {
                    conceals.add(pending.replace_pos, clip.size(), paste_status_line(clip));
                }
                pending.clear();
                last_activity = clock::now();
            } else {
                if (pending.replace_len > 0) {
                    conceals.set_loading(pending.replace_pos, pending.replace_len);
                }
            }
        }

        // --- Phase 2: Render ---
        size_t render_cur = st.cur;
        const std::string render_buf = render_buffer_with_conceal(st, conceals, render_cur);
        const auto [cols, term_rows] = term_size();
        Render full = render_prompt_buffer(prompt, render_buf, render_cur, cols);

        // --- Viewport: clamp to terminal height to prevent scrolling ---
        Render vis = full;
        if (term_rows > 0 && vis.rows.size() > static_cast<size_t>(term_rows)) {
            const size_t H = static_cast<size_t>(term_rows);
            size_t start = 0;

            // Keep cursor visible, prefer showing the bottom
            if (full.cursor_row + 1 >= H) {
                start = full.cursor_row + 1 - H;
            }
            const size_t max_start = full.rows.size() - H;
            if (start > max_start) start = max_start;

            vis.rows.assign(full.rows.begin() + static_cast<ptrdiff_t>(start),
                           full.rows.begin() + static_cast<ptrdiff_t>(start + H));
            vis.cursor_row = full.cursor_row - start;
            // cursor_col unchanged
        }

        rr.refresh(vis);

        // --- Phase 3: Auto-return match ---
        if (mode == EditorMode::AutoReturnMatch) {
            if (auto_options.find(st.buf) != auto_options.end()) {
                rr.finish_newline();
                return {st.buf, false, false};
            }
        }

        // --- Phase 4: Input (poll-based) ---
        int poll_ms;
        if (pending.active) {
            poll_ms = 60;
        } else if (timeout_ms > 0) {
            const auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                clock::now() - last_activity).count();
            const int remaining = timeout_ms - static_cast<int>(elapsed_ms);
            if (remaining <= 0) {
                rr.finish_newline();
                return {std::nullopt, false, true};
            }
            poll_ms = remaining;
        } else {
            poll_ms = 60000;
        }

        const std::optional<KeyEvent> maybe_key = read_key_timeout(poll_ms);

        if (!maybe_key.has_value()) {
            if (pending.active) continue;
            if (timeout_ms > 0) {
                const auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                    clock::now() - last_activity).count();
                if (elapsed_ms >= timeout_ms) {
                    rr.finish_newline();
                    return {std::nullopt, false, true};
                }
            }
            continue;
        }

        const KeyEvent& k = *maybe_key;
        last_activity = clock::now();

        switch (k.kind) {
            case KeyKind::CtrlC:
                rr.finish_newline();
                return {std::nullopt, true, false};

            case KeyKind::CtrlD:
                rr.finish_newline();
                return {st.buf, false, false};

            case KeyKind::CtrlV:
            case KeyKind::CtrlShiftV:
                if (!pending.active) {
                    // Insert placeholder that will be replaced with clipboard content
                    constexpr std::string_view placeholder = "[...]";
                    const size_t insert_pos = st.cur;
                    insert_char_concealed(st, placeholder, conceals);
                    start_clipboard_fetch(pending, insert_pos, placeholder.size());
                }
                break;

            case KeyKind::Enter:
                if (mode == EditorMode::EditExisting && edit_enter_newline) {
                    insert_newline_concealed(st, conceals);
                } else {
                    rr.finish_newline();
                    return {st.buf, false, false};
                }
                break;

            case KeyKind::CtrlN:
                insert_newline_concealed(st, conceals);
                break;

            case KeyKind::Backspace:
                backspace_concealed(st, conceals);
                break;

            case KeyKind::Delete:
                del_forward_concealed(st, conceals);
                break;

            case KeyKind::CtrlDelete:
                delete_word_right_concealed(st, conceals);
                break;

            case KeyKind::CtrlW:
                delete_word_left_concealed(st, conceals);
                break;

            case KeyKind::CtrlU:
                delete_to_line_start_concealed(st, conceals);
                break;

            case KeyKind::CtrlK:
                delete_to_line_end_concealed(st, conceals);
                break;

            case KeyKind::Left:
                move_left(st, conceals);
                break;

            case KeyKind::Right:
                move_right(st, conceals);
                break;

            case KeyKind::CtrlA:
                if (mode == EditorMode::EditExisting) {
                    rr.finish_newline();
                    return {kEditingAbortedSentinel, false, false};
                }
                move_home(st, conceals);
                break;

            case KeyKind::Home:
                move_home(st, conceals);
                break;

            case KeyKind::End:
            case KeyKind::CtrlE:
                move_end(st, conceals);
                break;

            case KeyKind::UpLine:
                move_up_line(st, conceals);
                break;

            case KeyKind::DownLine:
                move_down_line(st, conceals);
                break;

            case KeyKind::CtrlUp:
                // Jump to absolute start of buffer
                st.cur = 0;
                break;

            case KeyKind::CtrlDown:
                // Jump to absolute end of buffer
                st.cur = st.buf.size();
                break;

            case KeyKind::CtrlLeft:
                ctrl_left(st, conceals);
                break;

            case KeyKind::CtrlRight:
                ctrl_right(st, conceals);
                break;

            case KeyKind::Char:
                if (!k.text.empty()) {
                    insert_char_concealed(st, k.text, conceals);
                }
                if (!pending.active) {
                    const std::optional<size_t> token_start = clip_token_start_before_cursor(st);
                    if (token_start.has_value()) {
                        start_clipboard_fetch(pending, *token_start, 5);
                    }
                }
                break;

            default:
                break;
        }
    }
}

} // namespace

std::string multiline_input(const std::string& prompt, int timeout_ms) {
    EditorState st;
    st.buf.reserve(256);
    const RunResult r = run_editor(prompt, std::move(st), EditorMode::NormalInput, {},
                                   true, timeout_ms);
    if (r.timed_out) return kTimeoutSentinel;
    if (r.cancelled) {
        std::raise(SIGINT);
        return std::string();
    }
    return r.value.value_or(std::string());
}

std::optional<std::string> multiline_edit(const std::string& prompt,
                                          const std::string& initial,
                                          bool enter_newline,
                                          int timeout_ms) {
    EditorState st;
    st.buf = initial;
    st.cur = st.buf.size();
    const RunResult r = run_editor(prompt, std::move(st), EditorMode::EditExisting, {},
                                   enter_newline, timeout_ms);
    if (r.timed_out) return kTimeoutSentinel;
    if (r.cancelled) {
        std::raise(SIGINT);
        return std::nullopt;
    }
    if (r.value.has_value() && r.value.value() == kEditingAbortedSentinel) {
        return kEditingAbortedSentinel;
    }
    return r.value;
}

std::string multiline_input_autoreturn(const std::string& prompt,
                                       const std::vector<std::string>& options,
                                       int timeout_ms) {
    std::unordered_set<std::string> opt;
    opt.reserve(options.size() * 2 + 1);
    for (const auto& s : options) opt.insert(s);
    EditorState st;
    st.buf.reserve(256);
    const RunResult r = run_editor(prompt, std::move(st), EditorMode::AutoReturnMatch, opt,
                                   true, timeout_ms);
    if (r.timed_out) return kTimeoutSentinel;
    if (r.cancelled) {
        std::raise(SIGINT);
        return std::string();
    }
    return r.value.value_or(std::string());
}

} // namespace input
