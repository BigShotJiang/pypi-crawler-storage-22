#include "cich/parser.h"
#include <vector>
#include <algorithm> // For std::min
#include <optional>  // For std::optional
#include <cctype>    // For std::isdigit

namespace cich {

Parser::Parser(std::string_view input) : m_input(input) {
    // Reserve based on estimated line count
    size_t newline_count = std::count(m_input.begin(), m_input.end(), '\n');
    m_lines.reserve(newline_count + 1);

    size_t current_pos = 0;
    while (current_pos < m_input.size()) {
        size_t line_end = m_input.find('\n', current_pos);
        if (line_end == std::string_view::npos) {
            m_lines.push_back(m_input.substr(current_pos));
            break;
        }
        m_lines.push_back(m_input.substr(current_pos, line_end - current_pos));
        current_pos = line_end + 1;
    }
}

std::string_view Parser::peek_line(size_t offset) const {
    if (m_current_line_idx + offset < m_lines.size()) {
        return m_lines[m_current_line_idx + offset];
    }
    return ""; // Return empty view if out of bounds
}

void Parser::consume_line() {
    if (!is_eof()) {
        m_current_line_idx++;
    }
}

bool Parser::is_eof() const {
    return m_current_line_idx >= m_lines.size();
}

void Parser::skip_empty_lines() {
    while (!is_eof() && peek_line().empty()) {
        consume_line();
    }
}

ast::Document Parser::parse() {
    ast::Document doc;
    while (!is_eof()) {
        skip_empty_lines(); // Skip any empty lines between blocks
        if (is_eof()) break; // If only empty lines left, stop.
        doc.push_back(parse_block());
    }
    return doc;
}

ast::BlockNode Parser::parse_block() {
    // Order matters here: try more specific blocks first
    if (auto code_block = parse_code_block()) {
        return *code_block;
    }
    if (auto hr = parse_horizontal_rule()) {
        return *hr;
    }
    if (auto table = parse_table()) {
        return *table;
    }
    if (auto header = parse_header()) {
        return *header;
    }
    if (auto blockquote = parse_blockquote()) {
        return *blockquote;
    }
    if (auto list = parse_list()) {
        return *list;
    }

    // If no specific block type matches, it's a paragraph
    return parse_paragraph();
}

static std::vector<std::string_view> split_table_row(std::string_view line) {
    std::vector<std::string_view> cells;
    if (line.empty()) return cells;
    // Trim leading/trailing pipe
    if (!line.empty() && line.front() == '|') line.remove_prefix(1);
    if (!line.empty() && line.back() == '|') line.remove_suffix(1);

    size_t start = 0;
    while (start <= line.size()) {
        size_t pos = line.find('|', start);
        if (pos == std::string_view::npos) pos = line.size();
        std::string_view cell = line.substr(start, pos - start);
        size_t left = cell.find_first_not_of(" \t");
        size_t right = cell.find_last_not_of(" \t");
        if (left == std::string_view::npos) {
            cells.push_back("");
        } else {
            cells.push_back(cell.substr(left, right - left + 1));
        }
        if (pos == line.size()) break;
        start = pos + 1;
    }
    return cells;
}

static bool is_table_separator_cell(std::string_view cell) {
    if (cell.empty()) return false;
    size_t i = 0;
    if (cell[i] == ':') i++;
    bool has_dash = false;
    while (i < cell.size()) {
        if (cell[i] == '-') {
            has_dash = true;
        } else if (cell[i] == ':') {
            // allow trailing colon
        } else {
            return false;
        }
        i++;
    }
    return has_dash;
}

static ast::TableAlign parse_align(std::string_view cell) {
    bool left = !cell.empty() && cell.front() == ':';
    bool right = !cell.empty() && cell.back() == ':';
    if (left && right) return ast::TableAlign::Center;
    if (right) return ast::TableAlign::Right;
    return ast::TableAlign::Left;
}

std::optional<ast::Table> Parser::parse_table() {
    std::string_view line = peek_line();
    std::string_view next = peek_line(1);
    if (line.find('|') == std::string_view::npos || next.find('|') == std::string_view::npos) {
        return std::nullopt;
    }

    auto header_cells = split_table_row(line);
    auto sep_cells = split_table_row(next);
    if (header_cells.empty() || sep_cells.empty() || header_cells.size() != sep_cells.size()) {
        return std::nullopt;
    }
    for (auto cell : sep_cells) {
        if (!is_table_separator_cell(cell)) {
            return std::nullopt;
        }
    }

    ast::Table table;
    table.align.reserve(sep_cells.size());
    for (auto cell : sep_cells) {
        table.align.push_back(parse_align(cell));
    }

    for (auto cell : header_cells) {
        table.header.cells.push_back(ast::TableCell{std::string(cell)});
    }

    consume_line();
    consume_line();

    while (!is_eof()) {
        std::string_view row = peek_line();
        if (row.empty() || row.find('|') == std::string_view::npos) {
            break;
        }
        auto row_cells = split_table_row(row);
        if (row_cells.size() != table.align.size()) {
            break;
        }
        ast::TableRow r;
        for (auto cell : row_cells) {
            r.cells.push_back(ast::TableCell{std::string(cell)});
        }
        table.rows.push_back(std::move(r));
        consume_line();
    }

    return table;
}

std::optional<ast::HorizontalRule> Parser::parse_horizontal_rule() {
    std::string_view line = peek_line();
    if (line.empty()) {
        return std::nullopt;
    }

    // Trim whitespace
    size_t start = line.find_first_not_of(" \t");
    if (start == std::string_view::npos) {
        return std::nullopt;
    }
    size_t end = line.find_last_not_of(" \t");
    std::string_view trimmed = line.substr(start, end - start + 1);

    if (trimmed.size() < 3) {
        return std::nullopt;
    }

    char ch = trimmed[0];
    if (ch != '-' && ch != '*' && ch != '_') {
        return std::nullopt;
    }
    for (char c : trimmed) {
        if (c != ch) {
            return std::nullopt;
        }
    }

    consume_line();
    return ast::HorizontalRule{};
}

std::optional<ast::Header> Parser::parse_header() {
    std::string_view line = peek_line();
    if (line.empty() || line[0] != '#') {
        return std::nullopt;
    }

    int level = 0;
    while (level < line.size() && line[level] == '#') {
        level++;
    }

    // Must be followed by a space or be the only characters on the line
    if (level > 0 && level <= 6 && (level == line.size() || line[level] == ' ')) {
        size_t text_start = line.find_first_not_of(" \t", level);
        std::string_view header_text = (text_start != std::string_view::npos) ? line.substr(text_start) : "";
        
        consume_line();
        ast::Header header;
        header.level = level;
        header.children = parse_inline_elements(header_text); // Changed to use parse_inline_elements
        return header;
    }
    return std::nullopt;
}

std::optional<ast::CodeBlock> Parser::parse_code_block() {
    std::string_view line = peek_line();
    // Check for leading spaces before the fence
    size_t first_non_space = line.find_first_not_of(" \t");
    if (first_non_space != std::string_view::npos && line.substr(first_non_space).rfind("```", 0) == 0) { 
        std::string_view fence_line = line.substr(first_non_space);
        std::string_view language_info = fence_line.substr(3);
        
        // Remove trailing whitespace from language_info
        size_t lang_trim_end = language_info.find_last_not_of(" \t");
        if (lang_trim_end != std::string_view::npos) {
            language_info = language_info.substr(0, lang_trim_end + 1);
        } else {
            language_info = "";
        }
        
        ast::CodeBlock code_block;
        code_block.language = std::string(language_info);
        
        consume_line(); // Consume opening fence

        std::string content_buffer;
        while (!is_eof()) {
            std::string_view current_code_line = peek_line();
            size_t current_first_non_space = current_code_line.find_first_not_of(" \t");
            if (current_first_non_space != std::string_view::npos && current_code_line.substr(current_first_non_space).rfind("```", 0) == 0) { // Closing fence
                consume_line();
                code_block.content = content_buffer;
                return code_block;
            }
            content_buffer += std::string(current_code_line) + "\n";
            consume_line();
        }
        // If EOF reached without closing fence, it's an unclosed code block
        code_block.content = content_buffer; 
        return code_block; 
    }
    return std::nullopt;
}

std::optional<ast::Blockquote> Parser::parse_blockquote() {
    std::string_view line = peek_line();
    if (line.empty() || (line[0] != '>' && line.find_first_not_of(" \t") != 0)) { // Must start with '>' or be indented
        return std::nullopt;
    }

    ast::Blockquote blockquote;
    // We will parse nested blocks within the blockquote
    // Temporarily store lines that belong to the blockquote
    std::vector<std::string_view> blockquote_lines;
    size_t initial_line_idx = m_current_line_idx;

    while (!is_eof()) {
        std::string_view current_line = peek_line();
        size_t first_char_pos = current_line.find_first_not_of(" \t");

        if (first_char_pos != std::string_view::npos && current_line[first_char_pos] == '>') {
            std::string_view content = current_line.substr(first_char_pos + 1);
            if (!content.empty() && content[0] == ' ') { // Skip leading space after '>'
                content = content.substr(1);
            }
            blockquote_lines.push_back(content);
            consume_line();
        } else if (!current_line.empty() && first_char_pos != std::string_view::npos && first_char_pos >= 4 && initial_line_idx != m_current_line_idx) { 
             // Continuation paragraph (indented by 4+ spaces)
             // Only if we've already consumed at least one blockquote line
             blockquote_lines.push_back(current_line);
             consume_line();
        }
        else {
            break; // End of blockquote
        }
    }

    if (blockquote_lines.empty()) {
        return std::nullopt;
    }

    // Join the collected lines into a single string for the sub-parser
    std::string blockquote_content_str;
    for (const auto& line : blockquote_lines) {
        blockquote_content_str += std::string(line) + "\n";
    }

    // Create a sub-parser for the collected lines
    Parser sub_parser(blockquote_content_str);
    while (!sub_parser.is_eof()) {
        sub_parser.skip_empty_lines();
        if (sub_parser.is_eof()) break;
        blockquote.children.push_back(sub_parser.parse_block());
    }

    if (!blockquote.children.empty()) {
        return blockquote;
    }
    return std::nullopt;
}

std::optional<ast::List> Parser::parse_list(size_t parent_indent_level) {
    ast::List list;
    size_t current_list_indent = 0; // Indentation of the current list level, dynamically determined by the first item

    // Find the first list item to determine the list's base indentation and type
    std::string_view initial_line = peek_line();
    size_t initial_line_non_space = initial_line.find_first_not_of(" \t");

    if (initial_line_non_space == std::string_view::npos || initial_line_non_space < parent_indent_level) {
        return std::nullopt; // Not a list item or indented less than parent
    }

    // Determine initial list type and marker length
    size_t initial_marker_len = 0; 
    ast::ListType initial_type;

    // Unordered
    if (initial_line[initial_line_non_space] == '-' || initial_line[initial_line_non_space] == '*' || initial_line[initial_line_non_space] == '+') {
        if (initial_line.size() > initial_line_non_space + 1 && initial_line[initial_line_non_space + 1] == ' ') {
            initial_type = ast::ListType::Unordered;
            initial_marker_len = initial_line_non_space + 2;
        }
    }
    // Ordered
    if (initial_marker_len == 0 && std::isdigit(static_cast<unsigned char>(initial_line[initial_line_non_space]))) {
        size_t dot_pos = initial_line.find('.', initial_line_non_space);
        if (dot_pos != std::string_view::npos && dot_pos > initial_line_non_space && (dot_pos + 1 < initial_line.size() && initial_line[dot_pos + 1] == ' ')) {
            initial_type = ast::ListType::Ordered;
            initial_marker_len = dot_pos + 2;
        }
    }

    if (initial_marker_len == 0) {
        return std::nullopt; // Not a valid list item
    }

    list.type = initial_type;
    current_list_indent = initial_line_non_space; // Base indentation for this list level

    // Main loop for parsing list items
    while (!is_eof()) {
        std::string_view current_line = peek_line();
        size_t current_line_non_space = current_line.find_first_not_of(" \t");
        size_t current_line_indent = current_line_non_space == std::string_view::npos ? current_line.size() : current_line_non_space;

        if (current_line.empty()) { // Empty line
            // If two empty lines in a row, or empty line is less indented than parent, terminate
            if (peek_line(1).empty() || current_line_indent < parent_indent_level) {
                break;
            }
            // A single empty line within a list item: consume and continue
            consume_line();
            continue;
        }

        if (current_line_indent < current_list_indent) {
            // Less indented: this list ends
            break;
        }
        
        // This line is part of the current list, process it as a list item
        ast::ListItem item;
        size_t item_start_indent = current_line_indent;
        size_t item_actual_marker_len = 0; // Actual marker length for this specific item

        // Determine type and marker for the current item
        if (current_line[item_start_indent] == '-' || current_line[item_start_indent] == '*' || current_line[item_start_indent] == '+') {
            if (current_line.size() > item_start_indent + 1 && current_line[item_start_indent + 1] == ' ') {
                item_actual_marker_len = item_start_indent + 2;
            }
        } else if (std::isdigit(static_cast<unsigned char>(current_line[item_start_indent]))) {
            size_t dot_pos = current_line.find('.', item_start_indent);
            if (dot_pos != std::string_view::npos && dot_pos > item_start_indent && (dot_pos + 1 < current_line.size() && current_line[dot_pos + 1] == ' ')) {
                item_actual_marker_len = dot_pos + 2;
            }
        }

        // If it's not a valid list item at this point, something is wrong, break
        if (item_actual_marker_len == 0) {
            break;
        }

        // Extract content after the marker for the first line of the item
        std::string_view item_first_line_content = current_line.substr(item_actual_marker_len);
        
        consume_line(); // Consume the initial list item line

        // Collect all lines belonging to this list item's content block
        std::string item_raw_content;
        item_raw_content += std::string(item_first_line_content) + "\n";
        
        size_t effective_content_indent = item_actual_marker_len;

        auto flush_item_content = [&](ast::ListItem& target_item, std::string& content) {
            if (content.empty()) {
                return;
            }
            Parser sub_parser(content);
            while (!sub_parser.is_eof()) {
                sub_parser.skip_empty_lines();
                if (sub_parser.is_eof()) break;
                target_item.children.push_back(sub_parser.parse_block());
            }
            content.clear();
        };

        while (!is_eof()) {
            std::string_view next_line = peek_line();
            size_t next_line_non_space = next_line.find_first_not_of(" \t");
            size_t next_line_indent = next_line_non_space == std::string_view::npos ? next_line.size() : next_line_non_space;
            
            if (next_line.empty()) {
                item_raw_content += "\n"; // Keep empty lines as part of content
                consume_line();
                continue;
            }

            // If the next line is a list item at the same or lesser indentation, it's a new item or end of list
            if (looks_like_list_item(next_line, next_line_indent) && next_line_indent <= current_list_indent) {
                break;
            }
            
            // If the next line is less indented than current list, break
            if (next_line_indent < current_list_indent) {
                break;
            }

            // If it's a nested list
            if (looks_like_list_item(next_line, next_line_indent) && next_line_indent > current_list_indent) {
                flush_item_content(item, item_raw_content);
                auto nested_list = parse_list(next_line_indent); // Recursive call
                if (nested_list) {
                    item.children.push_back(*nested_list);
                    // parse_list already consumed lines, so continue outer loop
                    continue; 
                }
            }

            // Otherwise, it's a continuation of the current list item's block content
            // Need to strip the item's content indentation
            if (next_line_indent >= effective_content_indent) {
                item_raw_content += std::string(next_line.substr(effective_content_indent)) + "\n";
            } else {
                // Malformed indentation, treat as new block or end of list
                break;
            }
            consume_line();
        }

        // Flush remaining content for this item
        flush_item_content(item, item_raw_content);
        list.children.push_back(item);
    }
    
    if (!list.children.empty()) {
        return list;
    }
    return std::nullopt;
}


ast::Paragraph Parser::parse_paragraph() {
    ast::Paragraph p;
    std::string content_buffer;

    while (!is_eof()) {
        std::string_view current_line = peek_line();
        if (current_line.empty()) {
            break; // Empty line terminates a paragraph
        }

        // Determine whether we should stop AFTER consuming this line
        bool stop_after_this_line = false;

        size_t next_line_idx = m_current_line_idx + 1;
        if (next_line_idx < m_lines.size()) {
            std::string_view next_line = m_lines[next_line_idx];
            size_t next_first_non_space = next_line.find_first_not_of(" \t");
            if (next_first_non_space != std::string_view::npos) {
                char indicator = next_line[next_first_non_space];
                if (indicator == '#' || indicator == '>' || indicator == '-' || indicator == '*' ||
                    indicator == '+' || std::isdigit(static_cast<unsigned char>(indicator)) ||
                    next_line.substr(next_first_non_space).rfind("```", 0) == 0) {
                    stop_after_this_line = true;
                }
            }
        }

        if (!content_buffer.empty()) {
            content_buffer += " ";
        }
        content_buffer += std::string(current_line);
        consume_line();

        if (stop_after_this_line) {
            break;
        }
    }

    p.children = parse_inline_elements(content_buffer);
    return p;
}

// Parses a string_view into a vector of inline nodes
std::vector<ast::InlineNode> Parser::parse_inline_elements(std::string_view text) {
    std::vector<ast::InlineNode> inline_nodes;
    size_t current_pos = 0;
    while (current_pos < text.size()) {
        if (auto inline_element = parse_inline(text, current_pos)) {
            inline_nodes.push_back(inline_element->first);
            current_pos += inline_element->second;
        } else {
            // Should not happen if parse_inline always returns something (even plain text)
            // But as a safeguard, advance by one character if parsing fails unexpectedly
            ast::Text text_node;
            text_node.value = std::string(text.substr(current_pos, 1));
            inline_nodes.push_back(text_node);
            current_pos += 1;
        }
    }
    return inline_nodes;
}

// Helper to parse a single inline element
std::optional<std::pair<ast::InlineNode, size_t>> Parser::parse_inline(std::string_view text, size_t start_pos) {
    if (start_pos >= text.size()) {
        return std::nullopt;
    }

    // Bold (**)
    if (text.size() - start_pos >= 2 && text.substr(start_pos, 2) == "**") {
        size_t end_pos = text.find("**", start_pos + 2);
        if (end_pos != std::string_view::npos) {
            ast::Bold bold_node;
            std::string_view inner_text = text.substr(start_pos + 2, end_pos - (start_pos + 2));
            bold_node.children = parse_inline_elements(inner_text); // Recursively parse inner content
            return std::make_pair(bold_node, end_pos + 2 - start_pos);
        }
    }
    // Italic (*)
    if (text.size() - start_pos >= 1 && text.substr(start_pos, 1) == "*") {
        size_t end_pos = text.find("*", start_pos + 1);
        if (end_pos != std::string_view::npos) {
            ast::Italic italic_node;
            std::string_view inner_text = text.substr(start_pos + 1, end_pos - (start_pos + 1));
            italic_node.children = parse_inline_elements(inner_text); // Recursively parse inner content
            return std::make_pair(italic_node, end_pos + 1 - start_pos);
        }
    }
    // Code Span (`)
    if (text.size() - start_pos >= 1 && text.substr(start_pos, 1) == "`") {
        size_t end_pos = text.find("`", start_pos + 1);
        if (end_pos != std::string_view::npos) {
            ast::CodeSpan code_span_node;
            code_span_node.content = std::string(text.substr(start_pos + 1, end_pos - (start_pos + 1)));
            return std::make_pair(code_span_node, end_pos + 1 - start_pos);
        }
    }

    // If no special inline element is found, parse as plain text
    size_t next_special_char = std::string_view::npos;
    size_t bold_start = text.find("**", start_pos);
    size_t italic_start = text.find("*", start_pos);
    size_t code_start = text.find("`", start_pos);

    if (bold_start != std::string_view::npos) next_special_char = std::min(next_special_char, bold_start);
    if (italic_start != std::string_view::npos) next_special_char = std::min(next_special_char, italic_start);
    if (code_start != std::string_view::npos) next_special_char = std::min(next_special_char, code_start);
    
    // If no special char found, or if the special char is the one we started with (meaning it wasn't a valid opening)
    if (next_special_char == std::string_view::npos || next_special_char == start_pos) {
        ast::Text text_node;
        text_node.value = std::string(text.substr(start_pos));
        return std::make_pair(text_node, text.size() - start_pos);
    } else {
        ast::Text text_node;
        text_node.value = std::string(text.substr(start_pos, next_special_char - start_pos));
        return std::make_pair(text_node, next_special_char - start_pos);
    }
}

} // namespace cich

// Add a helper function to check if a line looks like a list item
bool cich::Parser::looks_like_list_item(std::string_view line, size_t indentation) {
    if (line.empty() || indentation >= line.size()) return false;

    // Unordered
    if (line[indentation] == '-' || line[indentation] == '*' || line[indentation] == '+') {
        if (line.size() > indentation + 1 && line[indentation + 1] == ' ') {
            return true;
        }
    }

    // Ordered
    if (std::isdigit(static_cast<unsigned char>(line[indentation]))) {
        size_t dot_pos = line.find('.', indentation);
        if (dot_pos != std::string_view::npos && dot_pos > indentation && (dot_pos + 1 < line.size() && line[dot_pos + 1] == ' ')) {
            return true;
        }
    }
    return false;
}
