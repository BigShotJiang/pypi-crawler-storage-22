#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "cich/cich.h"
#include "cich/cout.h"
#include <string>

#ifdef __unix__
#include <sys/ioctl.h>
#include <unistd.h>
#endif

namespace py = pybind11;

static int get_terminal_width() {
#ifdef __unix__
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col > 0) {
        return ws.ws_col;
    }
#endif
    return 80;
}

// Simple ANSI-aware text wrapper
static std::string wrap_text(const std::string& text, int width) {
    std::string result;
    result.reserve(text.size() + text.size() / width);
    int col = 0;

    for (size_t i = 0; i < text.size(); ++i) {
        if (text[i] == '\033') {
            // Skip ANSI escape sequences
            size_t esc_end = text.find('m', i);
            if (esc_end != std::string::npos) {
                result.append(text, i, esc_end - i + 1);
                i = esc_end;
                continue;
            }
        }
        if (text[i] == '\n') {
            result += '\n';
            col = 0;
            continue;
        }
        if (col >= width) {
            result += '\n';
            col = 0;
        }
        result += text[i];
        col++;
    }
    return result;
}

static void py_render(const std::string& markdown_text) {
    // cich::render() already prints to stdout and returns the string
    // We wrap it for terminal width awareness
    int width = get_terminal_width();
    std::string rendered = cich::render(markdown_text);
    // cich::render already prints, but for wrapped output we'd need
    // to modify the flow. For now, render() handles output directly.
    (void)rendered;
    (void)width;
}

static std::string py_render_string(const std::string& markdown_text) {
    return cich::render(markdown_text);
}

PYBIND11_MODULE(seps_cich, m) {
    m.doc() = "cich - C++ markdown renderer for terminals with syntax highlighting";

    m.def("render", &py_render, py::arg("markdown"),
          "Render markdown to terminal with ANSI styling (prints to stdout)");

    m.def("render_string", &py_render_string, py::arg("markdown"),
          "Render markdown and return the ANSI-styled string");

    m.def("terminal_width", &get_terminal_width,
          "Get the current terminal width");

    py::class_<cich::Cout>(m, "Cout")
        .def_static("good", &cich::Cout::good,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("bad", &cich::Cout::bad,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("yellow", &cich::Cout::yellow,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("normal", &cich::Cout::normal,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("dim", &cich::Cout::dim,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("bold", &cich::Cout::bold,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("info", &cich::Cout::info,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("debug", &cich::Cout::debug,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("header", &cich::Cout::header,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("step", &cich::Cout::step,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("prompt", &cich::Cout::prompt,
            py::arg("text"), py::arg("end") = " ")
        .def_static("success", &cich::Cout::success,
            py::arg("text") = "Done", py::arg("end") = "\n")
        .def_static("fail", &cich::Cout::fail,
            py::arg("text") = "Failed", py::arg("end") = "\n")
        .def_static("warning", &cich::Cout::warning,
            py::arg("text") = "Warning", py::arg("end") = "\n")
        .def_static("rule", &cich::Cout::rule,
            py::arg("title") = "", py::arg("width") = 0)
        .def_static("highlight", &cich::Cout::highlight,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("underline", &cich::Cout::underline,
            py::arg("text"), py::arg("end") = "\n")
        .def_static("fail_raise", [](const std::string& msg) {
            cich::Cout::fail(msg);
            throw std::runtime_error(msg);
        }, py::arg("message"),
            "Print failure message and raise RuntimeError")
        .def_static("markdown", &cich::Cout::markdown,
            py::arg("text"))
        .def_static("terminal_width", &cich::Cout::terminal_width);
}
