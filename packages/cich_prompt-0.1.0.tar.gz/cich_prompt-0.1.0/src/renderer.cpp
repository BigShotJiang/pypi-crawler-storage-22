#include "cich/renderer.h"
#include "cich/terminal.h"
#include <algorithm>
#include <cctype>
#include <cstdint>
#include <sstream>
#include <type_traits>

namespace cich {

namespace {


struct RGB { int r; int g; int b; };

struct TruecolorStyle {
    RGB fg;
    bool bold;
    bool italic;
    bool underline;
};

RGB monokai_bg() { return {39, 40, 34}; }
RGB monokai_fg() { return {248, 248, 242}; }

TruecolorStyle monokai_style(cich::highlighter::TokenType type) {
    using TT = cich::highlighter::TokenType;
    switch (type) {
        case TT::Keyword: return {{102, 217, 239}, false, false, false};
        case TT::KeywordNamespace: return {{255, 70, 137}, false, false, false};
        case TT::Type: return {{102, 217, 239}, false, false, false};
        case TT::Function: return {{166, 226, 46}, false, false, false};
        case TT::String: return {{230, 219, 116}, false, false, false};
        case TT::Comment: return {{149, 144, 119}, false, false, false};
        case TT::Number: return {{174, 129, 255}, false, false, false};
        case TT::Boolean: return {{174, 129, 255}, false, false, false};
        case TT::Preprocessor: return {{166, 226, 46}, false, false, false};
        case TT::Operator: return {{255, 70, 137}, false, false, false};
        case TT::Punctuation: return {{248, 248, 242}, false, false, false};
        case TT::Identifier: return {{248, 248, 242}, false, false, false};
        case TT::Default: return {monokai_fg(), false, false, false};
        default: return {monokai_fg(), false, false, false};
    }
}

std::string to_lower_copy(std::string_view value) {
    std::string out(value);
    std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return out;
}

std::string normalize_language(std::string_view language) {
    if (language.empty()) {
        return "";
    }
    std::string trimmed = to_lower_copy(language);
    // Trim whitespace
    while (!trimmed.empty() && std::isspace(static_cast<unsigned char>(trimmed.front()))) {
        trimmed.erase(trimmed.begin());
    }
    while (!trimmed.empty() && std::isspace(static_cast<unsigned char>(trimmed.back()))) {
        trimmed.pop_back();
    }

    if (!trimmed.empty() && trimmed[0] == '.') {
        trimmed.erase(trimmed.begin());
    }

    return trimmed;
}

std::vector<std::string> split_lines(const std::string& text) {
    std::vector<std::string> lines;
    std::string current;
    for (char ch : text) {
        if (ch == '\n') {
            lines.push_back(current);
            current.clear();
        } else {
            current.push_back(ch);
        }
    }
    lines.push_back(current);
    return lines;
}

bool is_combining_mark(uint32_t cp) {
    return
        (cp >= 0x0300 && cp <= 0x036F) ||
        (cp >= 0x1AB0 && cp <= 0x1AFF) ||
        (cp >= 0x1DC0 && cp <= 0x1DFF) ||
        (cp >= 0x20D0 && cp <= 0x20FF) ||
        (cp >= 0xFE20 && cp <= 0xFE2F);
}

bool is_wide_codepoint(uint32_t cp) {
    return
        (cp >= 0x1100 && cp <= 0x115F) ||
        cp == 0x2329 || cp == 0x232A ||
        (cp >= 0x2E80 && cp <= 0xA4CF) ||
        (cp >= 0xAC00 && cp <= 0xD7A3) ||
        (cp >= 0xF900 && cp <= 0xFAFF) ||
        (cp >= 0xFE10 && cp <= 0xFE19) ||
        (cp >= 0xFE30 && cp <= 0xFE6F) ||
        (cp >= 0xFF00 && cp <= 0xFF60) ||
        (cp >= 0xFFE0 && cp <= 0xFFE6) ||
        (cp >= 0x1F300 && cp <= 0x1FAFF) ||
        (cp >= 0x20000 && cp <= 0x3FFFD);
}

int codepoint_width(uint32_t cp) {
    if (cp == 0 || is_combining_mark(cp)) {
        return 0;
    }
    if (cp < 0x20 || (cp >= 0x7F && cp < 0xA0)) {
        return 0;
    }
    if (is_wide_codepoint(cp)) {
        return 2;
    }
    return 1;
}

size_t decode_utf8_char(std::string_view text, size_t i, uint32_t& cp) {
    unsigned char c0 = static_cast<unsigned char>(text[i]);
    if (c0 < 0x80) {
        cp = c0;
        return i + 1;
    }

    if ((c0 & 0xE0) == 0xC0 && i + 1 < text.size()) {
        unsigned char c1 = static_cast<unsigned char>(text[i + 1]);
        if ((c1 & 0xC0) == 0x80) {
            cp = ((c0 & 0x1F) << 6) | (c1 & 0x3F);
            return i + 2;
        }
    } else if ((c0 & 0xF0) == 0xE0 && i + 2 < text.size()) {
        unsigned char c1 = static_cast<unsigned char>(text[i + 1]);
        unsigned char c2 = static_cast<unsigned char>(text[i + 2]);
        if ((c1 & 0xC0) == 0x80 && (c2 & 0xC0) == 0x80) {
            cp = ((c0 & 0x0F) << 12) | ((c1 & 0x3F) << 6) | (c2 & 0x3F);
            return i + 3;
        }
    } else if ((c0 & 0xF8) == 0xF0 && i + 3 < text.size()) {
        unsigned char c1 = static_cast<unsigned char>(text[i + 1]);
        unsigned char c2 = static_cast<unsigned char>(text[i + 2]);
        unsigned char c3 = static_cast<unsigned char>(text[i + 3]);
        if ((c1 & 0xC0) == 0x80 && (c2 & 0xC0) == 0x80 && (c3 & 0xC0) == 0x80) {
            cp = ((c0 & 0x07) << 18) | ((c1 & 0x3F) << 12) | ((c2 & 0x3F) << 6) | (c3 & 0x3F);
            return i + 4;
        }
    }

    cp = c0;
    return i + 1;
}

size_t display_width(std::string_view text, bool ansi_aware = true) {
    size_t width = 0;
    size_t i = 0;
    while (i < text.size()) {
        if (ansi_aware && text[i] == '\033' && i + 1 < text.size() && text[i + 1] == '[') {
            i += 2;
            while (i < text.size() && text[i] != 'm') {
                i++;
            }
            if (i < text.size()) {
                i++;
            }
            continue;
        }

        uint32_t cp = 0;
        size_t next = decode_utf8_char(text, i, cp);
        width += static_cast<size_t>(codepoint_width(cp));
        i = next;
    }
    return width;
}

std::vector<std::string> wrap_text_cell(const std::string& text, size_t width) {
    if (width == 0) {
        return {""};
    }

    std::vector<std::string> wrapped_lines;
    auto raw_lines = split_lines(text);
    if (raw_lines.empty()) {
        return {""};
    }

    for (const auto& raw : raw_lines) {
        if (display_width(raw, false) <= width) {
            wrapped_lines.push_back(raw);
            continue;
        }

        std::string current;
        size_t current_width = 0;
        size_t i = 0;

        while (i < raw.size()) {
            size_t token_start = i;
            bool is_space = false;

            uint32_t cp = 0;
            size_t next = decode_utf8_char(raw, i, cp);
            if (cp == ' ' || cp == '\t') {
                is_space = true;
            }
            i = next;

            while (i < raw.size()) {
                uint32_t inner_cp = 0;
                size_t inner_next = decode_utf8_char(raw, i, inner_cp);
                bool inner_space = (inner_cp == ' ' || inner_cp == '\t');
                if (inner_space != is_space) {
                    break;
                }
                i = inner_next;
            }

            std::string token = raw.substr(token_start, i - token_start);
            size_t token_width = display_width(token, false);

            if (is_space) {
                if (current_width == 0) {
                    continue;
                }
                if (current_width + token_width > width) {
                    wrapped_lines.push_back(current);
                    current.clear();
                    current_width = 0;
                    continue;
                }
                current += token;
                current_width += token_width;
                continue;
            }

            if (token_width <= width) {
                if (current_width > 0 && current_width + token_width > width) {
                    wrapped_lines.push_back(current);
                    current.clear();
                    current_width = 0;
                }
                current += token;
                current_width += token_width;
                continue;
            }

            size_t k = 0;
            while (k < token.size()) {
                if (current_width == width) {
                    wrapped_lines.push_back(current);
                    current.clear();
                    current_width = 0;
                }
                uint32_t ch = 0;
                size_t k_next = decode_utf8_char(token, k, ch);
                size_t ch_width = static_cast<size_t>(codepoint_width(ch));
                if (ch_width > width) {
                    k = k_next;
                    continue;
                }
                if (current_width > 0 && current_width + ch_width > width) {
                    wrapped_lines.push_back(current);
                    current.clear();
                    current_width = 0;
                }
                current.append(token, k, k_next - k);
                current_width += ch_width;
                k = k_next;
            }
        }

        wrapped_lines.push_back(current);
    }

    if (wrapped_lines.empty()) {
        wrapped_lines.push_back("");
    }
    return wrapped_lines;
}

std::string repeat_utf8(const char* glyph, size_t count) {
    std::string out;
    size_t glyph_len = std::char_traits<char>::length(glyph);
    out.reserve(glyph_len * count);
    for (size_t i = 0; i < count; ++i) {
        out.append(glyph, glyph_len);
    }
    return out;
}

} // namespace

Renderer::Renderer(RenderOptions options)
    : options_(std::move(options)) {}

size_t Renderer::effective_width() const {
    if (options_.width > 0) {
        return options_.width;
    }
    return detect_terminal_width();
}

std::string Renderer::render(const ast::Document& doc) {
    output_lines_.clear();

    for (const auto& block_node : doc) {
        std::visit([this](const auto& node) {
            using T = std::decay_t<decltype(node)>;
            if constexpr (std::is_same_v<T, ast::CodeBlock>) {
                append_blank_line();
            }

            auto lines = this->visit_block(node, 0, "");
            bool add_blank = true;
            if constexpr (std::is_same_v<T, ast::List>) {
                add_blank = true; // blank after list, but items remain compact
            }
            this->append_lines(lines, add_blank);
        }, block_node);
    }

    // Trim trailing blank lines
    while (!output_lines_.empty() && output_lines_.back().empty()) {
        output_lines_.pop_back();
    }

    std::ostringstream out;
    for (size_t i = 0; i < output_lines_.size(); ++i) {
        out << output_lines_[i];
        if (i + 1 < output_lines_.size()) {
            out << "\n";
        }
    }
    return out.str();
}

void Renderer::append_lines(const std::vector<std::string>& lines, bool add_blank_after) {
    for (const auto& line : lines) {
        output_lines_.push_back(line);
    }
    if (add_blank_after) {
        append_blank_line();
    }
}

void Renderer::append_blank_line() {
    if (output_lines_.empty() || output_lines_.back().empty()) {
        return;
    }
    output_lines_.push_back("");
}

std::vector<std::string> Renderer::visit_block(const ast::Header& node, size_t indent, std::string_view prefix) {
    InlineStyle style;
    style.bold = true;
    if (node.level <= 2) {
        style.fg = ansi::Color::BrightBlue;
    } else if (node.level == 3) {
        style.fg = ansi::Color::Blue;
    } else {
        style.fg = ansi::Color::BrightWhite;
    }

    auto runs = render_inline_runs(node.children, style);
    size_t width = effective_width();
    std::string full_prefix(indent, ' ');
    full_prefix += std::string(prefix);

    size_t prefix_width = display_width(full_prefix, true);
    size_t content_width = width > prefix_width ? width - prefix_width : 1;
    auto lines = wrap_runs(runs, content_width, "", "");

    for (auto& line : lines) {
        size_t line_width = display_width(line, true);
        size_t left_pad = line_width < content_width ? (content_width - line_width) / 2 : 0;
        line = full_prefix + std::string(left_pad, ' ') + line;
    }

    return lines;
}

std::vector<std::string> Renderer::visit_block(const ast::Paragraph& node, size_t indent, std::string_view prefix) {
    InlineStyle style;
    auto runs = render_inline_runs(node.children, style);
    size_t width = effective_width();
    std::string full_prefix(indent, ' ');
    full_prefix += std::string(prefix);

    if (!options_.wrap) {
        std::string combined;
        InlineStyle current_style;
        bool initialized = false;
        for (const auto& run : runs) {
            combined += apply_style_change(current_style, run.style, !initialized);
            combined += run.text;
            current_style = run.style;
            initialized = true;
        }
        combined += ansi::RESET_ALL;
        return {full_prefix + combined};
    }

    return wrap_runs(runs, width, full_prefix, full_prefix);
}

std::vector<std::string> Renderer::visit_block(const ast::Blockquote& node, size_t indent, std::string_view prefix) {
    std::vector<std::string> lines;
    std::string quote_prefix = "│ ";
    std::string full_prefix = std::string(prefix) + quote_prefix;

    for (const auto& block_node : node.children) {
        auto child_lines = std::visit([this, indent, &full_prefix](const auto& n) {
            return this->visit_block(n, indent, full_prefix);
        }, block_node);

        lines.insert(lines.end(), child_lines.begin(), child_lines.end());
    }

    return lines;
}

std::vector<std::string> Renderer::visit_block(const ast::List& node, size_t indent, std::string_view prefix) {
    std::vector<std::string> lines;
    size_t number_width = std::to_string(node.children.size()).length();
    for (size_t i = 0; i < node.children.size(); ++i) {
        std::string marker;
        size_t marker_width = 0;
        if (node.type == ast::ListType::Ordered) {
            std::string num = std::to_string(i + 1);
            if (num.length() < number_width) {
                num = std::string(number_width - num.length(), ' ') + num;
            }
            marker = num + ". ";
            marker_width = marker.size();
        } else {
            marker = ansi::apply_style("•", ansi::Color::Yellow, ansi::Style::Bold) + ansi::RESET_ALL + std::string(" ");
            marker_width = 2; // visual width of "• "
        }

        std::string first_prefix = std::string(prefix) + std::string(indent, ' ') + marker;
        std::string rest_prefix = std::string(prefix) + std::string(indent + marker_width, ' ');

        const auto& item = node.children[i];
        bool first_block = true;
        for (const auto& block_node : item.children) {
            auto item_lines = std::visit([this, &first_prefix, &rest_prefix, &first_block, indent, &prefix, marker_width](const auto& n) {
                using T = std::decay_t<decltype(n)>;
                if constexpr (std::is_same_v<T, ast::List>) {
                    // Nested list: indent under the list item content.
                    size_t nested_indent = indent + marker_width;
                    return this->visit_block(n, nested_indent, prefix);
                } else {
                    if (first_block) {
                        return this->visit_block(n, 0, first_prefix);
                    }
                    return this->visit_block(n, 0, rest_prefix);
                }
            }, block_node);

            if (!item_lines.empty()) {
                lines.insert(lines.end(), item_lines.begin(), item_lines.end());
                first_block = false;
            }
        }
    }
    return lines;
}

std::vector<std::string> Renderer::visit_block(const ast::CodeBlock& node, size_t indent, std::string_view prefix) {
    std::string code = node.content;
    if (!code.empty() && code.back() == '\n') {
        code.pop_back();
    }

    const std::string language = normalize_language(node.language);
    const bool shell_language = (language == "bash" || language == "sh" || language == "shell" || language == "zsh");
    const RGB code_bg = shell_language ? RGB{33, 34, 36} : monokai_bg();
    const size_t horizontal_pad = shell_language ? 1 : 0;

    auto lexer = highlighter::create_lexer(language);
    std::vector<highlighter::Token> tokens = lexer->tokenize(code);

    std::ostringstream oss;
    size_t line_visible = 0;
    size_t width = effective_width();

    auto start_line = [&]() {
        line_visible = 0;
        if (options_.code_background) {
            oss << "[48;2;" << code_bg.r << ";" << code_bg.g << ";" << code_bg.b << "m";
        }
        if (horizontal_pad > 0) {
            oss << std::string(horizontal_pad, ' ');
            line_visible += horizontal_pad;
        }
    };

    auto reset_line = [&]() {
        if (options_.code_background && line_visible < width) {
            oss << std::string(width - line_visible, ' ');
        }
        oss << "[0m";
    };

    auto emit_truecolor = [&](const TruecolorStyle& style, bool force) {
        static TruecolorStyle current = {monokai_fg(), false, false, false};
        if (!force && style.fg.r == current.fg.r && style.fg.g == current.fg.g && style.fg.b == current.fg.b &&
            style.bold == current.bold && style.italic == current.italic && style.underline == current.underline) {
            return;
        }
        oss << "[39m[22m[23m[24m";
        oss << "[38;2;" << style.fg.r << ";" << style.fg.g << ";" << style.fg.b << "m";
        if (style.bold) oss << "[1m";
        if (style.italic) oss << "[3m";
        if (style.underline) oss << "[4m";
        current = style;
    };

    auto emit_ansi = [&](ansi::Color fg, ansi::Style style) {
        if (fg == ansi::Color::Default) {
            oss << "[39m";
        } else {
            oss << ansi::color_code(fg);
        }
        if (style == ansi::Style::Default) {
            oss << "[22m[23m[24m";
        } else {
            oss << ansi::style_code(style);
        }
    };

    auto style_for_token = [&](highlighter::TokenType type) {
        if (shell_language) {
            if (type == highlighter::TokenType::Comment) {
                return TruecolorStyle{{149, 144, 119}, false, false, false};
            }
            return TruecolorStyle{{230, 230, 230}, false, false, false};
        }
        TruecolorStyle style = monokai_style(type);
        return style;
    };

    bool line_started = false;
    bool line_needs_style = true;
    for (const auto& token : tokens) {
        std::string_view value = token.value;
        size_t start = 0;
        while (start < value.size()) {
            size_t nl = value.find('\n', start);
            std::string_view chunk = (nl == std::string_view::npos)
                ? value.substr(start)
                : value.substr(start, nl - start);

            if (!line_started) {
                start_line();
                line_started = true;
                line_needs_style = true;
            }

            if (!chunk.empty()) {
                if (options_.truecolor) {
                    emit_truecolor(style_for_token(token.type), line_needs_style);
                } else {
                    auto [fg, style] = shell_language
                        ? (token.type == highlighter::TokenType::Comment
                            ? std::make_pair(ansi::Color::BrightBlack, ansi::Style::Default)
                            : std::make_pair(ansi::Color::White, ansi::Style::Default))
                        : theme_.get_style(token.type);
                    emit_ansi(fg, style);
                }
                oss << chunk;
                line_visible += chunk.size();
                line_needs_style = false;
            }

            if (nl != std::string_view::npos) {
                reset_line();
                oss << "\n";
                line_started = false;
                start = nl + 1;
            } else {
                break;
            }
        }
    }

    if (line_started) {
        reset_line();
    }

    std::string rendered = oss.str();

    auto lines = split_lines(rendered);
    if (!lines.empty() && lines.back().empty()) {
        lines.pop_back();
    }
    std::vector<std::string> indented;
    std::string indent_prefix(indent, ' ');
    std::string pref = indent_prefix + std::string(prefix);

    // width already computed earlier for line padding
    auto make_padding_line = [&](size_t target_width) {
        std::string out;
        out.reserve(target_width + 32);
        if (options_.truecolor) {
            out += "\033[48;2;" + std::to_string(code_bg.r) + ";" + std::to_string(code_bg.g) + ";" + std::to_string(code_bg.b) + "m";
        } else {
            out += ansi::apply_style("", ansi::Color::Default, ansi::Color::BrightBlack, ansi::Style::Default);
        }
        out += std::string(target_width, ' ');
        out += ansi::RESET_ALL;
        return out;
    };

    if (options_.code_background && options_.code_padding) {
        indented.push_back(make_padding_line(width));
    }
    for (auto& line : lines) {
        std::string out = pref + line;
        out += ansi::RESET_ALL;
        indented.push_back(out);
    }
    if (options_.code_background && options_.code_padding) {
        indented.push_back(make_padding_line(width));
    }
    return indented;
}

std::vector<std::string> Renderer::visit_block(const ast::HorizontalRule& node, size_t indent, std::string_view prefix) {
    (void)node;
    size_t width = effective_width();
    std::string line = std::string(indent, ' ') + std::string(prefix) + repeat_utf8("━", width);
    return {line};
}

std::vector<std::string> Renderer::visit_block(const ast::Table& node, size_t indent, std::string_view prefix) {
    const size_t cols = node.align.size();
    if (cols == 0) {
        return {};
    }

    std::vector<size_t> widths(cols, 1);
    auto measure_row = [&](const ast::TableRow& row) {
        for (size_t i = 0; i < std::min(cols, row.cells.size()); ++i) {
            widths[i] = std::max(widths[i], display_width(row.cells[i].text, false));
        }
    };
    measure_row(node.header);
    for (const auto& row : node.rows) {
        measure_row(row);
    }

    size_t available = effective_width();
    size_t prefix_width = indent + display_width(prefix, true);
    if (available > prefix_width) {
        available -= prefix_width;
    } else {
        available = 1;
    }

    // Border geometry with one-cell padding on each side: sum(widths) + (3 * cols + 1)
    const size_t frame_overhead = 3 * cols + 1;
    size_t max_content_width = (available > frame_overhead) ? (available - frame_overhead) : cols;

    size_t content_width_sum = 0;
    for (size_t w : widths) {
        content_width_sum += w;
    }

    if (options_.wrap && content_width_sum > max_content_width) {
        std::vector<size_t> min_width(cols, 1);
        size_t over = content_width_sum - max_content_width;
        while (over > 0) {
            size_t best = cols;
            size_t best_width = 0;
            for (size_t i = 0; i < cols; ++i) {
                if (widths[i] > min_width[i] && widths[i] > best_width) {
                    best = i;
                    best_width = widths[i];
                }
            }
            if (best == cols) {
                break;
            }
            widths[best]--;
            over--;
        }
    }

    std::string line_prefix(indent, ' ');
    line_prefix += std::string(prefix);

    auto build_rule = [&](const char* left, const char* fill, const char* cross, const char* right) {
        std::string line = line_prefix + left;
        for (size_t i = 0; i < cols; ++i) {
            line += repeat_utf8(fill, widths[i] + 2);
            line += (i + 1 == cols) ? right : cross;
        }
        return line;
    };

    auto align_cell = [&](const std::string& text, size_t col) {
        size_t w = display_width(text, false);
        size_t pad = widths[col] > w ? widths[col] - w : 0;
        if (node.align[col] == ast::TableAlign::Right) {
            return std::string(pad, ' ') + text;
        }
        if (node.align[col] == ast::TableAlign::Center) {
            size_t left = pad / 2;
            size_t right = pad - left;
            return std::string(left, ' ') + text + std::string(right, ' ');
        }
        return text + std::string(pad, ' ');
    };

    auto render_wrapped_row = [&](const ast::TableRow& row, bool header) {
        std::vector<std::vector<std::string>> cells(cols);
        size_t row_height = 1;
        for (size_t i = 0; i < cols; ++i) {
            std::string raw = (i < row.cells.size()) ? row.cells[i].text : "";
            cells[i] = options_.wrap ? wrap_text_cell(raw, widths[i]) : std::vector<std::string>{raw};
            row_height = std::max(row_height, cells[i].size());
        }

        std::vector<std::string> out;
        out.reserve(row_height);

        const char* side = header ? "┃" : "│";
        for (size_t line_idx = 0; line_idx < row_height; ++line_idx) {
            std::string line = line_prefix + side;
            for (size_t col = 0; col < cols; ++col) {
                std::string segment = (line_idx < cells[col].size()) ? cells[col][line_idx] : "";
                std::string content = align_cell(segment, col);

                line += " ";
                if (header) {
                    line += ansi::apply_style(content, ansi::Color::White, ansi::Style::Bold);
                    line += ansi::RESET_ALL;
                } else {
                    line += content;
                }
                line += " ";
                line += side;
            }
            out.push_back(std::move(line));
        }
        return out;
    };

    std::vector<std::string> lines;
    lines.push_back(build_rule("┏", "━", "┳", "┓"));

    auto header_lines = render_wrapped_row(node.header, true);
    lines.insert(lines.end(), header_lines.begin(), header_lines.end());

    lines.push_back(build_rule("┡", "━", "╇", "┩"));
    for (const auto& row : node.rows) {
        auto row_lines = render_wrapped_row(row, false);
        lines.insert(lines.end(), row_lines.begin(), row_lines.end());
    }
    lines.push_back(build_rule("└", "─", "┴", "┘"));
    return lines;
}

std::vector<Renderer::StyledRun> Renderer::render_inline_runs(const std::vector<ast::InlineNode>& nodes, InlineStyle base_style) {
    std::vector<StyledRun> runs;
    for (const auto& node : nodes) {
        auto node_runs = render_inline_run(node, base_style);
        runs.insert(runs.end(), node_runs.begin(), node_runs.end());
    }
    return runs;
}

std::vector<Renderer::StyledRun> Renderer::render_inline_run(const ast::InlineNode& node, InlineStyle base_style) {
    return std::visit([this, base_style](const auto& n) -> std::vector<StyledRun> {
        using T = std::decay_t<decltype(n)>;
        if constexpr (std::is_same_v<T, ast::Text>) {
            return {{n.value, base_style}};
        } else if constexpr (std::is_same_v<T, ast::Bold>) {
            InlineStyle style = base_style;
            style.bold = true;
            return render_inline_runs(n.children, style);
        } else if constexpr (std::is_same_v<T, ast::Italic>) {
            InlineStyle style = base_style;
            style.italic = true;
            return render_inline_runs(n.children, style);
        } else if constexpr (std::is_same_v<T, ast::CodeSpan>) {
            InlineStyle style = base_style;
            style.fg = ansi::Color::Cyan;
            style.bg = ansi::Color::Black;
            style.bold = true;
            return {{n.content, style}};
        }
        return {};
    }, node);
}

std::string Renderer::apply_style_change(const InlineStyle& from, const InlineStyle& to, bool force) {
    bool from_default = from.fg == ansi::Color::Default && from.bg == ansi::Color::Default &&
                        !from.bold && !from.italic && !from.underline;
    bool to_default = to.fg == ansi::Color::Default && to.bg == ansi::Color::Default &&
                      !to.bold && !to.italic && !to.underline;

    if (!force && from.fg == to.fg && from.bg == to.bg &&
        from.bold == to.bold && from.italic == to.italic && from.underline == to.underline) {
        return "";
    }

    std::string result;
    result.reserve(24);
    if (to_default) {
        if (!from_default) {
            result += ansi::RESET_ALL;
        }
        return result;
    }
    if (!from_default) {
        result += ansi::RESET_ALL;
    }
    if (to.fg != ansi::Color::Default) {
        result += ansi::color_code(to.fg);
    }
    if (to.bg != ansi::Color::Default) {
        int idx = static_cast<int>(to.bg);
        int bg_code = 0;
        if (idx >= 1 && idx <= 8) {
            bg_code = 39 + idx;   // 40-47
        } else if (idx >= 9 && idx <= 16) {
            bg_code = 91 + idx;   // 100-107
        }
        if (bg_code != 0) {
            result += "\033[" + std::to_string(bg_code) + "m";
        }
    }
    if (to.bold) {
        result += ansi::style_code(ansi::Style::Bold);
    }
    if (to.italic) {
        result += ansi::style_code(ansi::Style::Italic);
    }
    if (to.underline) {
        result += ansi::style_code(ansi::Style::Underline);
    }
    return result;
}

std::vector<std::string> Renderer::wrap_runs(const std::vector<StyledRun>& runs, size_t width, std::string_view first_prefix, std::string_view rest_prefix) {
    std::vector<std::string> lines;
    if (width == 0) {
        width = 80;
    }
    size_t first_prefix_width = display_width(first_prefix, true);
    size_t rest_prefix_width = display_width(rest_prefix, true);
    size_t min_width = std::max(first_prefix_width, rest_prefix_width) + 1;
    if (width < min_width) {
        width = min_width;
    }

    std::string current;
    size_t current_width = 0;
    bool first_line = true;
    InlineStyle current_style;
    bool style_initialized = false;

    auto start_new_line = [&]() {
        if (!current.empty()) {
            current += ansi::RESET_ALL;
            lines.push_back(current);
        }
        current.clear();
        current_width = 0;
        first_line = false;
        style_initialized = false;
    };

    auto append_prefix = [&]() {
        const std::string_view prefix = first_line ? first_prefix : rest_prefix;
        if (!prefix.empty()) {
            current += std::string(prefix);
            current_width += display_width(prefix, true);
        }
    };

    auto line_prefix_width = [&]() {
        return first_line ? first_prefix_width : rest_prefix_width;
    };

    append_prefix();

    for (const auto& run : runs) {
        std::string text = run.text;
        if (options_.tab_size > 0) {
            std::string expanded;
            for (char ch : text) {
                if (ch == '\t') {
                    expanded.append(options_.tab_size, ' ');
                } else {
                    expanded.push_back(ch);
                }
            }
            text.swap(expanded);
        }

        size_t pos = 0;
        while (pos < text.size()) {
            bool is_space = std::isspace(static_cast<unsigned char>(text[pos])) != 0;
            size_t start = pos;
            while (pos < text.size() && (std::isspace(static_cast<unsigned char>(text[pos])) != 0) == is_space) {
                pos++;
            }

            std::string chunk = text.substr(start, pos - start);
            size_t chunk_width = display_width(chunk, false);
            if (is_space) {
                if (current_width == line_prefix_width()) {
                    continue;
                }
                if (current_width + chunk_width > width) {
                    start_new_line();
                    append_prefix();
                    continue;
                }
                current += chunk;
                current_width += chunk_width;
                continue;
            }

            if (current_width + chunk_width > width) {
                if (chunk_width > width) {
                    size_t chunk_pos = 0;
                    while (chunk_pos < chunk.size()) {
                        size_t remaining = width - current_width;
                        if (remaining == 0) {
                            start_new_line();
                            append_prefix();
                            remaining = width - current_width;
                        }
                        size_t slice = std::min(remaining, chunk.size() - chunk_pos);
                        std::string piece = chunk.substr(chunk_pos, slice);
                        current += apply_style_change(current_style, run.style, !style_initialized);
                        current += piece;
                        current_style = run.style;
                        style_initialized = true;
                        current_width += display_width(piece, false);
                        chunk_pos += slice;
                        if (chunk_pos < chunk.size()) {
                            start_new_line();
                            append_prefix();
                        }
                    }
                    continue;
                }
                start_new_line();
                append_prefix();
            }

            current += apply_style_change(current_style, run.style, !style_initialized);
            current += chunk;
            current_style = run.style;
            style_initialized = true;
            current_width += chunk_width;
        }
    }

    if (!current.empty()) {
        current += ansi::RESET_ALL;
        lines.push_back(current);
    }

    return lines;
}

} // namespace cich
