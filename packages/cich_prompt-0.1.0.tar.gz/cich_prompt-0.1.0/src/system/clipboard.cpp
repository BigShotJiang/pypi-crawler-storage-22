#include "cich/system/clipboard.hpp"

#include "cich/system/platform.hpp"

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <mutex>
#include <string>
#include <string_view>
#include <vector>

#if defined(_WIN32)
#include <cstdio>
#else
#include <fcntl.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

namespace clipboard {
namespace {

bool env_exists(const char* name) {
    const char* v = std::getenv(name);
    return v != nullptr && *v != '\0';
}

#if defined(_WIN32)

bool run_set_command(const std::string& cmd, std::string_view text) {
    FILE* fp = _popen(cmd.c_str(), "wb");
    if (!fp) {
        return false;
    }
    const size_t n = std::fwrite(text.data(), 1, text.size(), fp);
    const int rc = _pclose(fp);
    return n == text.size() && rc == 0;
}

std::string run_get_command(const std::string& cmd) {
    FILE* fp = _popen(cmd.c_str(), "rb");
    if (!fp) {
        return {};
    }
    std::string out;
    char buf[4096];
    while (true) {
        const size_t n = std::fread(buf, 1, sizeof(buf), fp);
        if (n == 0) {
            break;
        }
        out.append(buf, n);
    }
    const int rc = _pclose(fp);
    if (rc != 0) {
        return {};
    }
    return out;
}

#else

bool command_exists(const char* command) {
    const char* path = std::getenv("PATH");
    if (!path || !*path || !command || !*command) {
        return false;
    }

    std::string p(path);
    std::size_t start = 0;
    while (start <= p.size()) {
        const std::size_t end = p.find(':', start);
        const std::string dir = (end == std::string::npos) ? p.substr(start) : p.substr(start, end - start);

        std::string full;
        if (dir.empty()) {
            full = command;
        } else {
            full.reserve(dir.size() + 1 + std::strlen(command));
            full.append(dir);
            full.push_back('/');
            full.append(command);
        }

        if (access(full.c_str(), X_OK) == 0) {
            return true;
        }
        if (end == std::string::npos) {
            break;
        }
        start = end + 1;
    }
    return false;
}

struct ProcResult {
    int exit_code = -1;
    std::string out;
};

ProcResult run_capture(const std::vector<const char*>& argv) {
    ProcResult result{};
    if (argv.empty() || argv[0] == nullptr) {
        return result;
    }

    int pipe_out[2];
    if (pipe(pipe_out) != 0) {
        return result;
    }

    const pid_t pid = fork();
    if (pid == 0) {
        dup2(pipe_out[1], STDOUT_FILENO);
        const int devnull = open("/dev/null", O_WRONLY);
        if (devnull >= 0) {
            dup2(devnull, STDERR_FILENO);
            close(devnull);
        }
        close(pipe_out[0]);
        close(pipe_out[1]);
        execvp(argv[0], const_cast<char* const*>(argv.data()));
        _exit(127);
    }

    close(pipe_out[1]);

    char buf[4096];
    while (true) {
        const ssize_t n = read(pipe_out[0], buf, sizeof(buf));
        if (n <= 0) {
            break;
        }
        result.out.append(buf, static_cast<std::size_t>(n));
    }
    close(pipe_out[0]);

    int status = 0;
    if (waitpid(pid, &status, 0) >= 0 && WIFEXITED(status)) {
        result.exit_code = WEXITSTATUS(status);
    }
    return result;
}

int run_stdin(const std::vector<const char*>& argv, std::string_view input) {
    if (argv.empty() || argv[0] == nullptr) {
        return -1;
    }

    int pipe_in[2];
    if (pipe(pipe_in) != 0) {
        return -1;
    }

    const pid_t pid = fork();
    if (pid == 0) {
        dup2(pipe_in[0], STDIN_FILENO);
        const int devnull = open("/dev/null", O_WRONLY);
        if (devnull >= 0) {
            dup2(devnull, STDOUT_FILENO);
            dup2(devnull, STDERR_FILENO);
            close(devnull);
        }
        close(pipe_in[0]);
        close(pipe_in[1]);
        execvp(argv[0], const_cast<char* const*>(argv.data()));
        _exit(127);
    }

    close(pipe_in[0]);
    std::size_t written = 0;
    while (written < input.size()) {
        const ssize_t n = write(pipe_in[1], input.data() + written, input.size() - written);
        if (n <= 0) {
            break;
        }
        written += static_cast<std::size_t>(n);
    }
    close(pipe_in[1]);

    int status = 0;
    if (waitpid(pid, &status, 0) >= 0 && WIFEXITED(status)) {
        return WEXITSTATUS(status);
    }
    return -1;
}

bool run_set(const std::vector<const char*>& argv, std::string_view text) {
    return run_stdin(argv, text) == 0;
}

std::string run_get(const std::vector<const char*>& argv) {
    ProcResult r = run_capture(argv);
    if (r.exit_code == 0) {
        return r.out;
    }
    return {};
}

#endif

enum class SetBackend {
    None,
    PowerShell,
    Termux,
    WlCopy,
    Xclip,
    Xsel,
    Pbcopy,
    Tmux
};

enum class GetBackend {
    None,
    PowerShell,
    Termux,
    WlPaste,
    Xclip,
    Xsel,
    Pbpaste,
    Tmux
};

struct BackendSelection {
    SetBackend set = SetBackend::None;
    GetBackend get = GetBackend::None;
};

void debug_log(bool debug, const char* msg) {
    if (debug) {
        std::cerr << msg << '\n';
    }
}

BackendSelection detect_backends() {
    BackendSelection sel{};
    const auto& pf = platform::detect_once();

#if defined(_WIN32)
    sel.set = SetBackend::PowerShell;
    sel.get = GetBackend::PowerShell;
    return sel;
#else
    const bool has_tmux = env_exists("TMUX") && command_exists("tmux");

    if (pf.is_termux && command_exists("termux-clipboard-set")) {
        sel.set = SetBackend::Termux;
    } else if (command_exists("wl-copy")) {
        sel.set = SetBackend::WlCopy;
    } else if (command_exists("xclip")) {
        sel.set = SetBackend::Xclip;
    } else if (command_exists("xsel")) {
        sel.set = SetBackend::Xsel;
    } else if (pf.os == platform::OSType::MacOS && command_exists("pbcopy")) {
        sel.set = SetBackend::Pbcopy;
    } else if (has_tmux) {
        sel.set = SetBackend::Tmux;
    }

    if (pf.is_termux && command_exists("termux-clipboard-get")) {
        sel.get = GetBackend::Termux;
    } else if (command_exists("wl-paste")) {
        sel.get = GetBackend::WlPaste;
    } else if (command_exists("xclip")) {
        sel.get = GetBackend::Xclip;
    } else if (command_exists("xsel")) {
        sel.get = GetBackend::Xsel;
    } else if (pf.os == platform::OSType::MacOS && command_exists("pbpaste")) {
        sel.get = GetBackend::Pbpaste;
    } else if (has_tmux) {
        sel.get = GetBackend::Tmux;
    }

    return sel;
#endif
}

const BackendSelection& backends_once() {
    static std::once_flag once;
    static BackendSelection cached{};
    std::call_once(once, []() {
        cached = detect_backends();
    });
    return cached;
}

std::string strip_trailing_newline(std::string s) {
    if (!s.empty() && s.back() == '\n') {
        s.pop_back();
    }
    return s;
}

} // namespace

bool set_text(std::string_view text, bool warn_tty, bool debug) {
    const BackendSelection& sel = backends_once();

    switch (sel.set) {
        case SetBackend::PowerShell:
#if defined(_WIN32)
            if (run_set_command("powershell -NoProfile -Command Set-Clipboard", text)) {
                debug_log(debug, "clipboard: powershell set");
                return true;
            }
#endif
            break;
        case SetBackend::Termux:
#if !defined(_WIN32)
            if (run_set({"termux-clipboard-set", nullptr}, text)) {
                debug_log(debug, "clipboard: termux-clipboard-set");
                return true;
            }
#endif
            break;
        case SetBackend::WlCopy:
#if !defined(_WIN32)
            if (run_set({"wl-copy", nullptr}, text)) {
                debug_log(debug, "clipboard: wl-copy");
                return true;
            }
#endif
            break;
        case SetBackend::Xclip:
#if !defined(_WIN32)
            if (run_set({"xclip", "-selection", "clipboard", nullptr}, text)) {
                debug_log(debug, "clipboard: xclip");
                return true;
            }
#endif
            break;
        case SetBackend::Xsel:
#if !defined(_WIN32)
            if (run_set({"xsel", "--clipboard", "--input", nullptr}, text)) {
                debug_log(debug, "clipboard: xsel");
                return true;
            }
#endif
            break;
        case SetBackend::Pbcopy:
#if !defined(_WIN32)
            if (run_set({"pbcopy", nullptr}, text)) {
                debug_log(debug, "clipboard: pbcopy");
                return true;
            }
#endif
            break;
        case SetBackend::Tmux:
#if !defined(_WIN32)
            if (run_set({"tmux", "load-buffer", "-", nullptr}, text)) {
                debug_log(debug, "clipboard: tmux load-buffer");
                if (warn_tty) {
                    std::cerr << "clipboard: set via tmux buffer\n";
                }
                return true;
            }
#endif
            break;
        case SetBackend::None:
            break;
    }

    debug_log(debug, "clipboard: set failed");
    return false;
}

std::string get_text(bool warn_tty, bool debug) {
    const BackendSelection& sel = backends_once();

    switch (sel.get) {
        case GetBackend::PowerShell:
#if defined(_WIN32)
            return strip_trailing_newline(run_get_command("powershell -NoProfile -Command Get-Clipboard"));
#else
            break;
#endif
        case GetBackend::Termux:
#if !defined(_WIN32)
            {
                std::string out = run_get({"termux-clipboard-get", nullptr});
                if (!out.empty()) {
                    debug_log(debug, "clipboard: termux-clipboard-get");
                    return strip_trailing_newline(out);
                }
            }
#endif
            break;
        case GetBackend::WlPaste:
#if !defined(_WIN32)
            {
                std::string out = run_get({"wl-paste", nullptr});
                if (!out.empty()) {
                    debug_log(debug, "clipboard: wl-paste");
                    return strip_trailing_newline(out);
                }
            }
#endif
            break;
        case GetBackend::Xclip:
#if !defined(_WIN32)
            {
                std::string out = run_get({"xclip", "-selection", "clipboard", "-o", nullptr});
                if (!out.empty()) {
                    debug_log(debug, "clipboard: xclip");
                    return strip_trailing_newline(out);
                }
            }
#endif
            break;
        case GetBackend::Xsel:
#if !defined(_WIN32)
            {
                std::string out = run_get({"xsel", "--clipboard", "--output", nullptr});
                if (!out.empty()) {
                    debug_log(debug, "clipboard: xsel");
                    return strip_trailing_newline(out);
                }
            }
#endif
            break;
        case GetBackend::Pbpaste:
#if !defined(_WIN32)
            {
                std::string out = run_get({"pbpaste", nullptr});
                if (!out.empty()) {
                    debug_log(debug, "clipboard: pbpaste");
                    return strip_trailing_newline(out);
                }
            }
#endif
            break;
        case GetBackend::Tmux:
#if !defined(_WIN32)
            {
                std::string out = run_get({"tmux", "show-buffer", nullptr});
                if (!out.empty()) {
                    debug_log(debug, "clipboard: tmux show-buffer");
                    if (warn_tty) {
                        std::cerr << "clipboard: read via tmux buffer\n";
                    }
                    return strip_trailing_newline(out);
                }
            }
#endif
            break;
        case GetBackend::None:
            break;
    }

    debug_log(debug, "clipboard: get failed");
    return {};
}

} // namespace clipboard
