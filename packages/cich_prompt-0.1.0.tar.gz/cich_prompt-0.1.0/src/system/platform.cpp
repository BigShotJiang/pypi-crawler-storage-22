#include "cich/system/platform.hpp"

#include <cstdlib>
#include <fstream>
#include <mutex>
#include <string_view>
#include <unordered_map>

#if defined(__unix__) || defined(__APPLE__) || defined(__linux__) || defined(__ANDROID__)
#include <sys/utsname.h>
#endif

namespace platform {
namespace {

std::string trim(std::string_view s) {
    std::size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r' || s[start] == '\n')) {
        ++start;
    }
    std::size_t end = s.size();
    while (end > start && (s[end - 1] == ' ' || s[end - 1] == '\t' || s[end - 1] == '\r' || s[end - 1] == '\n')) {
        --end;
    }
    return std::string(s.substr(start, end - start));
}

std::string unquote(std::string s) {
    if (s.size() >= 2 && s.front() == '"' && s.back() == '"') {
        s = s.substr(1, s.size() - 2);
    }
    return s;
}

bool file_exists(const char* path) {
    std::ifstream in(path);
    return in.good();
}

std::unordered_map<std::string, std::string> read_os_release() {
    std::unordered_map<std::string, std::string> out;
    const char* candidates[] = {
        "/etc/os-release",
        "/usr/lib/os-release",
    };

    for (const char* p : candidates) {
        std::ifstream in(p);
        if (!in.is_open()) {
            continue;
        }

        std::string line;
        while (std::getline(in, line)) {
            const std::string cleaned = trim(line);
            if (cleaned.empty() || cleaned[0] == '#') {
                continue;
            }
            const std::size_t eq = cleaned.find('=');
            if (eq == std::string::npos || eq == 0) {
                continue;
            }
            std::string key = trim(std::string_view(cleaned).substr(0, eq));
            std::string val = trim(std::string_view(cleaned).substr(eq + 1));
            out[std::move(key)] = unquote(std::move(val));
        }
        if (!out.empty()) {
            return out;
        }
    }
    return out;
}

bool env_exists(const char* name) {
    const char* v = std::getenv(name);
    return v != nullptr && *v != '\0';
}

bool env_contains(const char* name, std::string_view needle) {
    const char* v = std::getenv(name);
    if (!v || *v == '\0') {
        return false;
    }
    return std::string_view(v).find(needle) != std::string_view::npos;
}

} // namespace

const char* to_string(OSType os) noexcept {
    switch (os) {
        case OSType::Linux:
            return "linux";
        case OSType::MacOS:
            return "macos";
        case OSType::Windows:
            return "windows";
        case OSType::Android:
            return "android";
        default:
            return "unknown";
    }
}

PlatformInfo detect() {
    PlatformInfo info;

#if defined(_WIN32)
    info.os = OSType::Windows;
    return info;
#elif defined(__APPLE__) && defined(__MACH__)
    info.os = OSType::MacOS;
#elif defined(__ANDROID__)
    info.os = OSType::Android;
    info.is_android = true;
#elif defined(__linux__)
    info.os = OSType::Linux;
    info.is_linux = true;
#else
    info.os = OSType::Unknown;
#endif

#if defined(__unix__) || defined(__APPLE__) || defined(__linux__) || defined(__ANDROID__)
    utsname u{};
    if (uname(&u) == 0) {
        info.kernel_name = u.sysname;
        info.kernel_release = u.release;
        info.architecture = u.machine;
    }
#endif

    const auto osr = read_os_release();
    auto get_or_empty = [&](const char* key) -> std::string {
        auto it = osr.find(key);
        return (it == osr.end()) ? std::string() : it->second;
    };

    info.distro.id = get_or_empty("ID");
    info.distro.name = get_or_empty("NAME");
    info.distro.version_id = get_or_empty("VERSION_ID");
    info.distro.version_codename = get_or_empty("VERSION_CODENAME");
    info.distro.id_like = get_or_empty("ID_LIKE");

    // Termux/phone signal set:
    // - TERMUX_VERSION is set on modern Termux
    // - PREFIX includes /com.termux/files/usr
    // - /data/data/com.termux exists on Android installs
    const bool termux_env = env_exists("TERMUX_VERSION") || env_contains("PREFIX", "com.termux");
    const bool termux_path = file_exists("/data/data/com.termux") || file_exists("/data/data/com.termux/files/usr");
    info.is_termux = termux_env || termux_path;

    // Android signal set:
    // - compile-time __ANDROID__
    // - ANDROID_ROOT/ANDROID_DATA env present
    // - Termux implies Android userland
    if (!info.is_android) {
        info.is_android = env_exists("ANDROID_ROOT") || env_exists("ANDROID_DATA") || info.is_termux;
    }

    // Normalize OS label for Linux+Android userland.
    if (info.os == OSType::Linux && info.is_android) {
        info.os = OSType::Android;
    }

    return info;
}

const PlatformInfo& detect_once() {
    static std::once_flag once;
    static PlatformInfo cached;
    std::call_once(once, []() {
        cached = detect();
    });
    return cached;
}

} // namespace platform
