"""
cich_prompt - Fast multiline input and clipboard library

High-performance terminal input library with:
- Multiline terminal input with advanced editing
- Cross-platform clipboard operations
- Vim-like editing features
- Async clipboard support
"""

__version__ = "0.1.0"

try:
    from . import _cich_prompt as _backend
except ImportError as e:
    raise ImportError(
        f"Failed to import cich_prompt native extension: {e}\n"
        "Make sure the package is properly installed."
    ) from e

# Re-export native submodules
clipboard = _backend.clipboard
input = _backend.input

# Typed Python wrappers
from .wrappers import (
    get_editing_aborted_sentinel,
    get_help_multiline_edit,
    get_help_multiline_input,
    get_help_multiline_input_autoreturn,
    get_text,
    get_timeout_sentinel,
    help,
    multiline_edit,
    multiline_input,
    multiline_input_autoreturn,
    set_text,
)

__all__ = [
    "__version__",
    "clipboard",
    "input",
    "multiline_input",
    "multiline_edit",
    "multiline_input_autoreturn",
    "get_timeout_sentinel",
    "get_editing_aborted_sentinel",
    "get_help_multiline_input",
    "get_help_multiline_edit",
    "get_help_multiline_input_autoreturn",
    "help",
    "set_text",
    "get_text",
]
