"""Typed Python wrappers around the native cich_prompt bindings."""

from __future__ import annotations

from typing import Optional, Sequence

from . import _cich_prompt as _backend


def set_text(text: str, warn_tty: bool = True, debug: bool = False) -> None:
    """Set text to the system clipboard.

    Args:
        text: Text to place on the clipboard.
        warn_tty: If True, emit warnings when running without a TTY.
        debug: If True, enable debug logging in the native layer.
    """

    _backend.clipboard.set_text(text, warn_tty=warn_tty, debug=debug)


def get_text(warn_tty: bool = True, debug: bool = False) -> str:
    """Get text from the system clipboard.

    Args:
        warn_tty: If True, emit warnings when running without a TTY.
        debug: If True, enable debug logging in the native layer.
    """

    return _backend.clipboard.get_text(warn_tty=warn_tty, debug=debug)


def multiline_input(prompt: str, timeout_ms: int = 0) -> str:
    """Read multiline input from the user.

    Args:
        prompt: Prompt text shown to the user.
        timeout_ms: If > 0, return get_timeout_sentinel() after this many ms of idle.

    Raises:
        KeyboardInterrupt: On Ctrl+C.
    """

    return _backend.input.multiline_input(prompt, timeout_ms=timeout_ms)


def multiline_edit(
    prompt: str,
    initial: str,
    enter_newline: bool = True,
    timeout_ms: int = 0,
) -> Optional[str]:
    """Edit existing text with multiline input.

    Args:
        prompt: Prompt text shown to the user.
        initial: Initial text to edit.
        enter_newline: If True, enter inserts newline; otherwise commit.
        timeout_ms: If > 0, return get_timeout_sentinel() after this many ms of idle.

    Returns:
        The edited text, or the editing-aborted sentinel string.

    Raises:
        KeyboardInterrupt: On Ctrl+C.
    """

    return _backend.input.multiline_edit(
        prompt,
        initial,
        enter_newline=enter_newline,
        timeout_ms=timeout_ms,
    )


def multiline_input_autoreturn(
    prompt: str,
    options: Sequence[str],
    timeout_ms: int = 0,
) -> str:
    """Read multiline input with auto-return on matching options.

    Args:
        prompt: Prompt text shown to the user.
        options: Options that trigger auto-return when matched.
        timeout_ms: If > 0, return get_timeout_sentinel() after this many ms of idle.

    Raises:
        KeyboardInterrupt: On Ctrl+C.
    """

    return _backend.input.multiline_input_autoreturn(
        prompt,
        list(options),
        timeout_ms=timeout_ms,
    )


def get_timeout_sentinel() -> str:
    """Return the sentinel string used to indicate an input timeout."""

    return _backend.input.get_timeout_sentinel()


def get_editing_aborted_sentinel() -> str:
    """Return the sentinel string used to indicate editing was aborted."""

    return _backend.input.get_editing_aborted_sentinel()


def get_help_multiline_input() -> str:
    """Return help text for multiline_input mode."""

    return _backend.input.get_help_multiline_input()


def get_help_multiline_edit() -> str:
    """Return help text for multiline_edit mode."""

    return _backend.input.get_help_multiline_edit()


def get_help_multiline_input_autoreturn() -> str:
    """Return help text for multiline_input_autoreturn mode."""

    return _backend.input.get_help_multiline_input_autoreturn()


def help() -> str:
    """Return a combined help string for all input modes."""

    sections = [
        "=== multiline_input ===",
        get_help_multiline_input(),
        "",
        "=== multiline_edit ===",
        get_help_multiline_edit(),
        "",
        "=== multiline_input_autoreturn ===",
        get_help_multiline_input_autoreturn(),
    ]
    return "\n".join(sections)
