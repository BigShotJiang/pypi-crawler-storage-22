# This plugin implements Core dashboards
