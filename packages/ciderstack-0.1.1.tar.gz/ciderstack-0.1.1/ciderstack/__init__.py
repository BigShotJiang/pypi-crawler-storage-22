"""
CiderStack Fleet SDK for Python

A Python client for managing macOS VMs across CiderStack Fleet nodes.

Example:
    from ciderstack import FleetClient
    
    # Using an API token (recommended)
    client = FleetClient("192.168.1.100", api_token="csk_...")
    
    # Or using a trusted node ID (from pairing)
    client = FleetClient("192.168.1.100", node_id="your-trusted-node-id")
    
    # List VMs
    vms = client.list_vms()
    for vm in vms:
        print(f"{vm.name}: {vm.state}")
"""

from .client import FleetClient, FleetError
from .types import (
    VMState, TaskStatus, NodeRole,
    Template, APIToken, APITokenSummary, APITokenPermissions,
)

__version__ = "0.1.0"
__all__ = [
    "FleetClient", "FleetError",
    "VMState", "TaskStatus", "NodeRole",
    "Template", "APIToken", "APITokenSummary", "APITokenPermissions",
]
