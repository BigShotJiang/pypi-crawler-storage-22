"""
CiderStack Fleet Client

HTTP client for the CiderStack Fleet JSON-RPC API.
"""

import uuid

import requests
from typing import List, Optional, Dict, Any
from .types import (
    NodeInfo, NodeStats, VM, Snapshot, Task, ExecResult,
    VMState, TaskStatus, Template, APIToken, APITokenSummary
)


class FleetError(Exception):
    """Exception raised when a Fleet API call fails."""
    def __init__(self, message: str, response: Optional[Dict] = None):
        super().__init__(message)
        self.response = response


class FleetClient:
    """
    Client for the CiderStack Fleet API.
    
    Authenticate with either an API token (recommended) or a trusted node ID.
    
    Examples:
        # Using an API token (recommended)
        client = FleetClient("192.168.1.100", api_token="csk_...")
        
        # Using a trusted node ID (from pairing)
        client = FleetClient("192.168.1.100", node_id="your-trusted-node-id")
    """
    
    DEFAULT_PORT = 9473
    DEFAULT_TIMEOUT = 30
    
    def __init__(
        self,
        host: str,
        node_id: Optional[str] = None,
        api_token: Optional[str] = None,
        port: int = DEFAULT_PORT,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        """
        Initialize the Fleet client.
        
        Provide exactly one of node_id or api_token for authentication.
        
        Args:
            host: IP address or hostname of the Fleet node
            node_id: Trusted node ID (obtained via pairing)
            api_token: API token string (generated via CiderStack CLI/UI)
            port: Port number (default: 9473)
            timeout: Request timeout in seconds (default: 30)
        """
        if not node_id and not api_token:
            raise FleetError("Either node_id or api_token is required for authentication")
        if node_id and api_token:
            raise FleetError("Provide either node_id or api_token, not both")
        self.host = host
        self.port = port
        self.timeout = timeout
        self.node_id = node_id
        self.api_token = api_token
        self.base_url = f"http://{host}:{port}"
    
    def _rpc(
        self,
        method: str,
        payload: Optional[Dict] = None,
        request_timeout: Optional[int] = None,
    ) -> Dict:
        """Make an RPC call to the Fleet server."""
        url = f"{self.base_url}/rpc/{method}"
        timeout_sec = request_timeout if request_timeout is not None else self.timeout

        # Inject authentication into every request
        if self.api_token:
            authenticated_payload: Dict[str, Any] = {"apiToken": self.api_token}
        else:
            authenticated_payload = {"callerNodeID": self.node_id}
        if payload:
            authenticated_payload.update(payload)

        try:
            response = requests.post(
                url,
                json=authenticated_payload,
                timeout=timeout_sec,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 403:
                try:
                    body = response.json()
                    error_msg = body.get("error", "Authentication failed")
                except Exception:
                    error_msg = "Authentication failed"
                raise FleetError(error_msg)
            
            response.raise_for_status()
            return response.json()
        except FleetError:
            raise
        except requests.exceptions.RequestException as e:
            raise FleetError(f"Request failed: {e}")
    
    def _check_response(self, response: Dict, operation: str) -> Dict:
        """Check if response indicates success."""
        if not response.get("success", True):
            error = response.get("error") or response.get("message") or "Unknown error"
            raise FleetError(f"{operation} failed: {error}", response)
        return response
    
    # =========================================================================
    # Node Information
    # =========================================================================
    
    def get_node_info(self) -> NodeInfo:
        """Get information about the connected node."""
        data = self._rpc("GetNodeInfo")
        return NodeInfo.from_dict(data)
    
    def get_node_stats(self) -> NodeStats:
        """Get real-time statistics for the node."""
        data = self._rpc("GetNodeStats")
        return NodeStats.from_dict(data)
    
    # =========================================================================
    # VM Management
    # =========================================================================
    
    def list_vms(self) -> List[VM]:
        """List all VMs on the node."""
        data = self._rpc("ListVMs")
        vms = data.get("vms", [])
        return [VM.from_dict(vm) for vm in vms]
    
    def get_vm(self, vm_id: str) -> Optional[VM]:
        """Get a specific VM by ID."""
        vms = self.list_vms()
        for vm in vms:
            if vm.id == vm_id:
                return vm
        return None
    
    def start_vm(self, vm_id: str) -> bool:
        """Start a VM."""
        response = self._rpc("StartVM", {"vmID": vm_id})
        self._check_response(response, "Start VM")
        return True
    
    def stop_vm(self, vm_id: str) -> bool:
        """Stop a VM."""
        response = self._rpc("StopVM", {"vmID": vm_id})
        self._check_response(response, "Stop VM")
        return True
    
    def suspend_vm(self, vm_id: str) -> bool:
        """Suspend (pause) a running VM."""
        response = self._rpc("SuspendVM", {"vmID": vm_id})
        self._check_response(response, "Suspend VM")
        return True

    def start_vm_recovery(self, vm_id: str) -> bool:
        """Start a VM in recovery mode."""
        response = self._rpc("StartVMRecovery", {"vmID": vm_id})
        self._check_response(response, "Start VM recovery")
        return True
    
    def clone_vm(self, vm_id: str, new_name: str) -> VM:
        """Clone a VM."""
        response = self._rpc("CloneVM", {"vmID": vm_id, "newName": new_name})
        self._check_response(response, "Clone VM")
        return VM.from_dict(response.get("newVM", {}))
    
    def rename_vm(self, vm_id: str, new_name: str) -> bool:
        """Rename a VM."""
        response = self._rpc("RenameVM", {"vmID": vm_id, "newName": new_name})
        self._check_response(response, "Rename VM")
        return True
    
    def delete_vm(self, vm_id: str) -> bool:
        """Delete a VM."""
        response = self._rpc("DeleteVM", {"vmID": vm_id})
        self._check_response(response, "Delete VM")
        return True
    
    def get_vm_settings(self, vm_id: str) -> Dict:
        """Get VM settings/configuration."""
        response = self._rpc("GetVMSettings", {"vmID": vm_id})
        self._check_response(response, "Get VM settings")
        return response.get("configuration", {})
    
    def update_vm_settings(
        self,
        vm_id: str,
        cpu_count: Optional[int] = None,
        memory_size: Optional[int] = None,
        display_width: Optional[int] = None,
        display_height: Optional[int] = None,
        intent: Optional[str] = None,
        ttl_seconds: Optional[int] = None,
    ) -> bool:
        """Update VM settings.

        Args:
            vm_id: VM identifier.
            cpu_count: Number of virtual CPUs.
            memory_size: Memory in MB.
            display_width: Display width in pixels.
            display_height: Display height in pixels.
            intent: VM intent ("disposable", "persistent", "interactive", "ci").
            ttl_seconds: TTL in seconds from now. Pass -1 to clear the TTL.
        """
        payload: Dict[str, Any] = {"vmID": vm_id}
        if cpu_count is not None:
            payload["cpuCount"] = cpu_count
        if memory_size is not None:
            payload["memorySize"] = memory_size
        if display_width is not None:
            payload["displayWidth"] = display_width
        if display_height is not None:
            payload["displayHeight"] = display_height
        if intent is not None:
            payload["intent"] = intent
        if ttl_seconds is not None:
            payload["ttlSeconds"] = ttl_seconds

        response = self._rpc("UpdateVMSettings", payload)
        self._check_response(response, "Update VM settings")
        return True
    
    # =========================================================================
    # Snapshot Management
    # =========================================================================
    
    def list_snapshots(self, vm_id: str) -> List[Snapshot]:
        """List snapshots for a VM."""
        data = self._rpc("ListSnapshots", {"vmID": vm_id})
        snapshots = data.get("snapshots", [])
        return [Snapshot.from_dict(s) for s in snapshots]
    
    def create_snapshot(
        self,
        vm_id: str,
        name: str,
        description: Optional[str] = None
    ) -> Snapshot:
        """Create a snapshot."""
        payload = {"vmID": vm_id, "name": name}
        if description:
            payload["snapshotDescription"] = description
        
        response = self._rpc("CreateSnapshot", payload)
        self._check_response(response, "Create snapshot")
        return Snapshot.from_dict(response.get("snapshot", {}))
    
    def restore_snapshot(self, vm_id: str, snapshot_id: str) -> bool:
        """Restore a VM to a snapshot."""
        response = self._rpc("RestoreSnapshot", {"vmID": vm_id, "snapshotID": snapshot_id})
        self._check_response(response, "Restore snapshot")
        return True
    
    def delete_snapshot(self, vm_id: str, snapshot_id: str) -> bool:
        """Delete a snapshot."""
        response = self._rpc("DeleteSnapshot", {"vmID": vm_id, "snapshotID": snapshot_id})
        self._check_response(response, "Delete snapshot")
        return True
    
    # =========================================================================
    # Command Execution
    # =========================================================================
    
    DEFAULT_EXEC_TIMEOUT = 300  # seconds (5 min); increase for large downloads

    def exec_command(
        self,
        vm_id: str,
        command: str,
        ssh_user: Optional[str] = None,
        ssh_password: Optional[str] = None,
        timeout: int = DEFAULT_EXEC_TIMEOUT,
    ) -> ExecResult:
        """Execute a command on a VM via SSH. Use a longer timeout for long-running steps (e.g. curl + unzip)."""
        payload = {
            "vmID": vm_id,
            "command": command,
            "timeout": timeout,
        }
        if ssh_user:
            payload["sshUser"] = ssh_user
        if ssh_password:
            payload["sshPassword"] = ssh_password

        # HTTP request must stay open at least as long as the command (+ buffer) to avoid broken pipe
        request_timeout = max(self.timeout, timeout + 60)
        response = self._rpc("ExecCommand", payload, request_timeout=request_timeout)
        return ExecResult.from_dict(response)
    
    # =========================================================================
    # Task Management
    # =========================================================================
    
    def get_tasks(self, include_completed: bool = False) -> List[Task]:
        """Get tasks running on the node."""
        data = self._rpc("GetTasks", {"includeCompleted": include_completed})
        tasks = data.get("tasks", [])
        return [Task.from_dict(t) for t in tasks]
    
    # =========================================================================
    # Image Management
    # =========================================================================
    
    def push_image(self, vm_id: str, image_name: str, insecure: bool = False) -> str:
        """Push a VM as an OCI image."""
        response = self._rpc("PushImage", {
            "vmID": vm_id,
            "imageName": image_name,
            "insecure": insecure,
        })
        self._check_response(response, "Push image")
        return response.get("taskID", "")
    
    def list_ipsws(self) -> List[Dict]:
        """List available IPSW files on the node."""
        data = self._rpc("ListRemoteIPSWs")
        return data.get("ipsws", [])
    
    def list_oci_images(self) -> List[Dict]:
        """List OCI images on the node."""
        data = self._rpc("ListRemoteOCIImages")
        return data.get("images", [])
    
    def download_ipsw(self, url: str, name: str, version: str) -> bool:
        """Download an IPSW on the remote node."""
        response = self._rpc("DownloadIPSWOnNode", {
            "requestID": str(uuid.uuid4()),
            "downloadURL": url,
            "expectedName": name,
            "expectedVersion": version,
        })
        self._check_response(response, "Download IPSW")
        return True
    
    def pull_oci_image(
        self,
        image_reference: str,
        username: Optional[str] = None,
        password: Optional[str] = None,
    ) -> bool:
        """Pull an OCI image on the remote node."""
        payload = {
            "requestID": str(uuid.uuid4()),
            "imageReference": image_reference,
        }
        if username and password:
            payload["credentials"] = {"username": username, "password": password}
        
        response = self._rpc("PullOCIImageOnNode", payload)
        self._check_response(response, "Pull OCI image")
        return True
    
    def create_vm(
        self,
        name: str,
        cpu_count: int = 4,
        memory_mb: int = 8192,
        disk_gb: int = 64,
        ipsw_path: Optional[str] = None,
        oci_image: Optional[str] = None,
    ) -> str:
        """Create a VM on the remote node."""
        payload = {
            "requestID": str(uuid.uuid4()),
            "name": name,
            "cpuCount": cpu_count,
            "memorySizeMB": memory_mb,
            "diskSizeGB": disk_gb,
        }
        if ipsw_path:
            payload["ipswPath"] = ipsw_path
        if oci_image:
            payload["ociImageReference"] = oci_image
        
        response = self._rpc("CreateVMOnNode", payload)
        self._check_response(response, "Create VM")
        return response.get("vmID", "")
    
    # =========================================================================
    # Fleet Overview
    # =========================================================================
    
    def get_fleet_overview(self) -> Dict:
        """Get aggregated fleet status."""
        return self._rpc("GetFleetOverview")
    
    def get_fleet_events(self, limit: int = 100, event_type: Optional[str] = None) -> List[Dict]:
        """Get fleet activity events."""
        payload = {"limit": limit}
        if event_type:
            payload["eventType"] = event_type
        
        data = self._rpc("GetFleetEvents", payload)
        return data.get("events", [])
    
    def get_remote_resources(self) -> Dict:
        """Get available resources for VM creation."""
        return self._rpc("GetRemoteResources")
    
    # =========================================================================
    # Pairing
    # =========================================================================
    
    @staticmethod
    def pair(
        host: str,
        code: str,
        name: Optional[str] = None,
        port: int = 9473,
    ) -> Dict:
        """
        Pair this SDK client with a Fleet node using a 6-digit pairing code.
        
        The pairing code is displayed in the CiderStack app UI.
        On success, returns credentials that can be used to create a FleetClient.
        
        Args:
            host: IP address or hostname of the Fleet node
            code: 6-digit pairing code from the CiderStack UI
            name: Display name for this SDK client (auto-generated if omitted)
            port: Port number (default: 9473)
        
        Returns:
            Dict with keys: node_id, private_key_hex, public_key_hex,
            responder_node_id, responder_name
        
        Example:
            creds = FleetClient.pair("192.168.1.100", "123456", "my-ci-script")
            # Store creds["node_id"] securely for future use
            client = FleetClient("192.168.1.100", node_id=creds["node_id"])
        """
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
        import base64
        
        # Generate a new node identity
        node_id = str(uuid.uuid4()).upper()
        client_name = name or f"sdk-{node_id[:8].lower()}"
        
        # Generate P-256 keypair
        private_key = ec.generate_private_key(ec.SECP256R1())
        public_key_bytes = private_key.public_key().public_bytes(
            Encoding.X962, PublicFormat.UncompressedPoint
        )
        private_key_bytes = private_key.private_numbers().private_value.to_bytes(32, "big")
        
        public_key_hex = public_key_bytes.hex()
        private_key_hex = private_key_bytes.hex()
        public_key_b64 = base64.b64encode(public_key_bytes).decode()
        
        # Send pairing request — ensure code is always a string
        url = f"http://{host}:{port}/rpc/RequestPairing"
        payload = {
            "requestID": str(uuid.uuid4()).upper(),
            "requesterNodeID": {"value": node_id},
            "requesterName": client_name,
            "requesterIP": "0.0.0.0",
            "publicKey": public_key_b64,
            "code": str(code),
        }
        
        try:
            response = requests.post(
                url,
                json=payload,
                timeout=30,
                headers={"Content-Type": "application/json"},
            )
            response.raise_for_status()
            result = response.json()
        except requests.exceptions.RequestException as e:
            raise FleetError(f"Pairing request failed: {e}")
        
        if not result.get("accepted"):
            error_msg = result.get("errorMessage", "Pairing rejected")
            raise FleetError(f"Pairing failed: {error_msg}")
        
        responder_node_id = result.get("responderNodeID", {})
        
        return {
            "node_id": node_id,
            "private_key_hex": private_key_hex,
            "public_key_hex": public_key_hex,
            "responder_node_id": responder_node_id.get("value", ""),
            "responder_name": result.get("responderName", ""),
        }

    # =========================================================================
    # Template Management
    # =========================================================================

    def list_templates(self) -> List[Template]:
        """List all VM templates."""
        data = self._rpc("ListTemplates")
        templates = data.get("templates", [])
        return [Template.from_dict(t) for t in templates]

    def get_template(self, template_id: str) -> Optional[Template]:
        """Get a template by ID."""
        response = self._rpc("GetTemplate", {"templateID": template_id})
        if not response.get("success") or not response.get("template"):
            return None
        return Template.from_dict(response["template"])

    def get_template_by_name(self, name: str) -> Optional[Template]:
        """Get a template by name."""
        response = self._rpc("GetTemplate", {"templateName": name})
        if not response.get("success") or not response.get("template"):
            return None
        return Template.from_dict(response["template"])

    def create_template_from_vm(
        self,
        vm_id: str,
        name: str,
        description: Optional[str] = None,
        category: Optional[str] = None,
        keep_original_vm: bool = True,
    ) -> Template:
        """Create a template from an existing VM."""
        payload: Dict[str, Any] = {"vmID": vm_id, "name": name}
        if description is not None:
            payload["description"] = description
        if category is not None:
            payload["category"] = category
        payload["keepOriginalVM"] = keep_original_vm

        response = self._rpc("CreateTemplateFromVM", payload)
        self._check_response(response, "Create template from VM")
        return Template.from_dict(response.get("template", {}))

    def delete_template(self, template_id: str) -> bool:
        """Delete a template."""
        response = self._rpc("DeleteTemplate", {"templateID": template_id})
        self._check_response(response, "Delete template")
        return True

    # =========================================================================
    # API Token Management
    # =========================================================================

    def generate_api_token(
        self,
        name: str,
        permissions: str = "fullAccess",
    ) -> APIToken:
        """Generate a new API token for SDK/script access."""
        response = self._rpc("GenerateAPIToken", {
            "name": name,
            "permissions": permissions,
        })
        if not response.get("success"):
            raise FleetError(response.get("error", "Failed to generate API token"), response)
        return APIToken.from_dict(response.get("token", {}))

    def revoke_api_token(self, token_id: str) -> bool:
        """Revoke an API token by its ID."""
        response = self._rpc("RevokeAPIToken", {"tokenID": token_id})
        return response.get("revoked", False)

    def list_api_tokens(self) -> List[APITokenSummary]:
        """List all API tokens (token strings are redacted)."""
        response = self._rpc("ListAPITokens")
        tokens = response.get("tokens", [])
        return [APITokenSummary.from_dict(t) for t in tokens]

    # =========================================================================
    # Shared Folder Management
    # =========================================================================

    def list_shared_folders(self, vm_id: str) -> List[Dict]:
        """List shared folders for a VM."""
        response = self._rpc("ListSharedFolders", {"vmID": vm_id})
        self._check_response(response, "List shared folders")
        return response.get("folders", [])

    def add_shared_folder(
        self,
        vm_id: str,
        name: str,
        host_path: str,
        read_only: bool = False,
        mount_tag: Optional[str] = None,
    ) -> bool:
        """Add a shared folder to a VM."""
        payload: Dict[str, Any] = {
            "vmID": vm_id,
            "name": name,
            "hostPath": host_path,
            "readOnly": read_only,
        }
        if mount_tag is not None:
            payload["mountTag"] = mount_tag

        response = self._rpc("AddSharedFolder", payload)
        self._check_response(response, "Add shared folder")
        return True

    def remove_shared_folder(self, vm_id: str, name: str) -> bool:
        """Remove a shared folder from a VM."""
        response = self._rpc("RemoveSharedFolder", {"vmID": vm_id, "name": name})
        self._check_response(response, "Remove shared folder")
        return True

    def set_shared_folder_enabled(self, vm_id: str, name: str, enabled: bool) -> bool:
        """Enable or disable a shared folder."""
        response = self._rpc("SetSharedFolderEnabled", {
            "vmID": vm_id,
            "name": name,
            "enabled": enabled,
        })
        self._check_response(response, "Set shared folder enabled")
        return True

    # =========================================================================
    # Fleet Utilities
    # =========================================================================

    def unpair(self, node_id: str) -> bool:
        """Unpair a node from the fleet."""
        response = self._rpc("Unpair", {"nodeID": node_id})
        self._check_response(response, "Unpair")
        return True

    def cleanup_vms(self, force: bool = False) -> int:
        """Clean up retired VMs whose TTL has passed."""
        response = self._rpc("CleanupVMs", {"force": force})
        self._check_response(response, "Cleanup VMs")
        return response.get("cleanedCount", 0)

    def get_ipsw_info(self, path: str) -> Dict:
        """Get metadata about an IPSW file on the node."""
        return self._rpc("GetIPSWInfo", {"path": path})
