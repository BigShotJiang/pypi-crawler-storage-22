"""
CiderStack Fleet SDK Types
"""

from enum import Enum
from dataclasses import dataclass
from typing import Optional, List
from datetime import datetime


class VMState(str, Enum):
    """VM state enumeration."""
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPING = "stopping"
    ERROR = "error"


class TaskStatus(str, Enum):
    """Task status enumeration."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class NodeRole(str, Enum):
    """Node role enumeration."""
    WORKER = "worker"
    MANAGER = "manager"
    OPERATOR = "operator"


@dataclass
class NodeInfo:
    """Information about a Fleet node."""
    node_id: str
    name: str
    hostname: str
    ip_address: str
    port: int
    machine_model: str
    os_version: str
    cpu_cores: int
    total_memory_gb: int
    fleet_version: str

    @classmethod
    def from_dict(cls, data: dict) -> "NodeInfo":
        return cls(
            node_id=data.get("nodeID", ""),
            name=data.get("name", ""),
            hostname=data.get("hostname", ""),
            ip_address=data.get("ipAddress", ""),
            port=data.get("port", 9473),
            machine_model=data.get("machineModel", ""),
            os_version=data.get("osVersion", ""),
            cpu_cores=data.get("cpuCores", 0),
            total_memory_gb=data.get("totalMemoryGB", 0),
            fleet_version=data.get("fleetVersion", ""),
        )


@dataclass
class NodeStats:
    """Real-time statistics for a node."""
    node_id: str
    timestamp: datetime
    cpu_usage_percent: float
    memory_used_gb: float
    memory_total_gb: float
    disk_used_gb: float
    disk_total_gb: float
    running_vm_count: int
    total_vm_count: int

    @classmethod
    def from_dict(cls, data: dict) -> "NodeStats":
        return cls(
            node_id=data.get("nodeID", ""),
            timestamp=datetime.fromisoformat(data.get("timestamp", "").replace("Z", "+00:00")) if data.get("timestamp") else datetime.now(),
            cpu_usage_percent=data.get("cpuUsagePercent", 0.0),
            memory_used_gb=data.get("memoryUsedGB", 0.0),
            memory_total_gb=data.get("memoryTotalGB", 0.0),
            disk_used_gb=data.get("diskUsedGB", 0.0),
            disk_total_gb=data.get("diskTotalGB", 0.0),
            running_vm_count=data.get("runningVMCount", 0),
            total_vm_count=data.get("totalVMCount", 0),
        )


@dataclass
class VM:
    """A virtual machine."""
    id: str
    name: str
    state: VMState
    cpu_count: int
    memory_mb: int
    disk_size_gb: Optional[int]
    os_version: Optional[str]
    ip_address: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> "VM":
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            state=VMState(data.get("state", "stopped")),
            cpu_count=data.get("cpuCount", 0),
            memory_mb=data.get("memoryMB", 0),
            disk_size_gb=data.get("diskSizeGB"),
            os_version=data.get("osVersion"),
            ip_address=data.get("ipAddress"),
        )


@dataclass
class Snapshot:
    """A VM snapshot."""
    id: str
    name: str
    description: Optional[str]
    created_at: datetime
    size_bytes: int

    @classmethod
    def from_dict(cls, data: dict) -> "Snapshot":
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            description=data.get("description"),
            created_at=datetime.fromisoformat(data.get("createdAt", "").replace("Z", "+00:00")) if data.get("createdAt") else datetime.now(),
            size_bytes=data.get("sizeBytes", 0),
        )


@dataclass
class Task:
    """A background task."""
    id: str
    type: str
    title: str
    status: TaskStatus
    progress: float
    progress_text: Optional[str]
    started_at: datetime
    completed_at: Optional[datetime]
    vm_id: Optional[str]
    vm_name: Optional[str]
    error_message: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> "Task":
        completed_at = None
        if data.get("completedAt"):
            completed_at = datetime.fromisoformat(data["completedAt"].replace("Z", "+00:00"))
        
        return cls(
            id=data.get("id", ""),
            type=data.get("type", ""),
            title=data.get("title", ""),
            status=TaskStatus(data.get("status", "pending")),
            progress=data.get("progress", 0.0),
            progress_text=data.get("progressText"),
            started_at=datetime.fromisoformat(data.get("startedAt", "").replace("Z", "+00:00")) if data.get("startedAt") else datetime.now(),
            completed_at=completed_at,
            vm_id=data.get("vmID"),
            vm_name=data.get("vmName"),
            error_message=data.get("errorMessage"),
        )


@dataclass
class Template:
    """A VM template."""
    id: str
    name: str
    description: Optional[str]
    macos_version: Optional[str]
    icon_name: str
    category: str
    source_type: str
    created_at: datetime
    modified_at: datetime
    disk_size_bytes: Optional[int]
    default_cpu: int
    default_memory_mb: int
    default_disk_gb: int

    @classmethod
    def from_dict(cls, data: dict) -> "Template":
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            description=data.get("description"),
            macos_version=data.get("macOSVersion"),
            icon_name=data.get("iconName", ""),
            category=data.get("category", ""),
            source_type=data.get("sourceType", ""),
            created_at=datetime.fromisoformat(data.get("createdAt", "").replace("Z", "+00:00")) if data.get("createdAt") else datetime.now(),
            modified_at=datetime.fromisoformat(data.get("modifiedAt", "").replace("Z", "+00:00")) if data.get("modifiedAt") else datetime.now(),
            disk_size_bytes=data.get("diskSizeBytes"),
            default_cpu=data.get("defaultCPU", 0),
            default_memory_mb=data.get("defaultMemoryMB", 0),
            default_disk_gb=data.get("defaultDiskGB", 0),
        )


class APITokenPermissions(str, Enum):
    """API token permission level."""
    READ_ONLY = "readOnly"
    FULL_ACCESS = "fullAccess"


@dataclass
class APIToken:
    """An API token for SDK/script access."""
    id: str
    name: str
    token: str
    permissions: APITokenPermissions
    created_at: datetime
    last_used_at: Optional[datetime]

    @classmethod
    def from_dict(cls, data: dict) -> "APIToken":
        last_used = None
        if data.get("lastUsedAt"):
            last_used = datetime.fromisoformat(str(data["lastUsedAt"]).replace("Z", "+00:00"))
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            token=data.get("token", ""),
            permissions=APITokenPermissions(data.get("permissions", "fullAccess")),
            created_at=datetime.fromisoformat(str(data.get("createdAt", "")).replace("Z", "+00:00")) if data.get("createdAt") else datetime.now(),
            last_used_at=last_used,
        )


@dataclass
class APITokenSummary:
    """Summary of an API token (token string redacted)."""
    id: str
    name: str
    token_prefix: str
    permissions: APITokenPermissions
    created_at: datetime
    last_used_at: Optional[datetime]

    @classmethod
    def from_dict(cls, data: dict) -> "APITokenSummary":
        last_used = None
        if data.get("lastUsedAt"):
            last_used = datetime.fromisoformat(str(data["lastUsedAt"]).replace("Z", "+00:00"))
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            token_prefix=data.get("tokenPrefix", ""),
            permissions=APITokenPermissions(data.get("permissions", "fullAccess")),
            created_at=datetime.fromisoformat(str(data.get("createdAt", "")).replace("Z", "+00:00")) if data.get("createdAt") else datetime.now(),
            last_used_at=last_used,
        )


@dataclass
class ExecResult:
    """Result of executing a command on a VM."""
    success: bool
    exit_code: int
    stdout: str
    stderr: str
    duration: float

    @classmethod
    def from_dict(cls, data: dict) -> "ExecResult":
        return cls(
            success=data.get("success", False),
            exit_code=data.get("exitCode", -1),
            stdout=data.get("stdout", ""),
            stderr=data.get("stderr", ""),
            duration=data.get("duration", 0.0),
        )
