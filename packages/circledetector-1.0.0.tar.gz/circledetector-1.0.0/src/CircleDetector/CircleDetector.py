#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""\
CircleDetector.py: Contains classes of circle palate detetor.

The detector was developed within the framework of the DeKrys project to estimate
the position of the destination plate. The plate is a circle made of metal (copper or aluminium).
There are three small holes in the plate. The small holes are evenly spaced on a circle.
The plate is usually provided by an ArUco marker. The ArUco marker is placed outside
the main circle of the plate on the attached small square plate. The ArUco marker identifies
the plate and defines a unique coordinate system.

This Python module provides a simple class-based interface to detect circles and
ArUco markers in an image using OpenCV. It returns information such as the center,
perimeter, and marker ID (if available).
"""

__author__ = "Julia Skovierova"
__maintainer__ = "Julia Skovierova"
__email__ = "Julia.Skovierova@cvut.cz"
__copyright__ = "Copyright \xa9 2025 RMP, \
    CIIRC CVUT in Prague\nAll Rights Reserved."
__license__ = "Project internal use"
__version__ = "1.0"
__status__ = "Prototype"
__date__ = "2025/07/28"
__credits__ = []
__all__ = []

# ==========================================================================
import cv2
import cv2.aruco as aruco
import numpy as np
import matplotlib.pyplot as plt


# ==========================================================================
class CircleDetector:
    INNER_CIRCLE_RADIUS_MIN = 10
    INNER_CIRCLE_RADIUS_MAX = 14
    INNER_CIRCLE_MIN_DISTANCE = 20
    OUTER_CIRCLE_RADIUS_MIN = 129
    OUTER_CIRCLE_RADIUS_MAX = 160
    OUTER_CIRCLE_MIN_DISTANCE = 250
    MARKER_RADIUS = 70
    SCALE_FACTOR = 3

    def __init__(self, optional_config=None):
        if optional_config is not None:
            for key, value in optional_config.items():
                setattr(self, key, value)

    def _resize_image_by_scale(self, scale):
        resized = cv2.resize(self.original_image, (self.original_image.shape[1] // scale,
                                                   self.original_image.shape[0] // scale))
        return resized

    def _is_grayscale(self, img):

        return len(img.shape) == 2 or img.shape[2] == 1

    def _grayscale_image(self, image, show_image=False):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        if show_image is True:
            cv2.imshow('Grayscale Image', gray)
            
        return gray

    def _blur_image(self, image, kernel_size, show_image=False):
        blurred = cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)
        if show_image is True:
            cv2.imshow('Blurred Image', blurred)
            
        return blurred

    def _draw_circles(self, img, small_circles, large_circle):
        if small_circles is not None:
            small_circles = np.uint16(np.around(small_circles))
            for small_circle in small_circles:  # [0,:]:
                x, y, r = small_circle
                cv2.circle(img, (x, y), r, (0, 0, 255), 2)
                # cv2.circle(img, (x, y), 1, (0, 0, 255), 2) #circle center
        if large_circle is not None:
            large_circle = np.uint16(np.around(large_circle))
            for best_circle in large_circle:
                x, y, r = best_circle
                cv2.circle(img, (x, y), r, (255, 0, 0), 2)
                
        return img

    def _circle_distance_in_range(self, circle1, circle2, a, b):
        x1, y1, r1 = circle1
        x2, y2, r2 = circle2
        distance = np.sqrt((x2 - x1)**2 + (y2 - y1)**2) - r1 - r2

        if distance >= a and distance <= b:
            return True
        else:
            return False

    def _find_large_circles(self, large_circles_data, small_circles_data):
        large_circles = []  # array to store large circles with small circles inside
        small_circles_inside = []  # array to store small circles inside current large circle
        filtered_circles = []
        all_small = []
        # loop through all large circles
        if large_circles_data is not None and small_circles_data is not None:
            for large_circle in large_circles_data[0, :]:
                lx, ly, lr = large_circle
                num_circles_inside = 0
                # loop through all small circles
                for small_circle in small_circles_data[0, :]:
                    # check if small circle is inside large circle
                    sx, sy, sr = small_circle
                    all_small.append(small_circle)
                    centre_distance = np.sqrt((lx - sx)**2 + (ly - sy)**2)
                    if centre_distance <= (lr-sr):
                        small_circles_inside.append(small_circle)
                        num_circles_inside = num_circles_inside+1

                # if there are small circles inside, add large circle to array
                # check distance of each small circle
                for i in range(len(small_circles_inside)):
                    for j in range(i+1, len(small_circles_inside)):
                        if self._circle_distance_in_range(small_circles_inside[i],
                                                          small_circles_inside[j], 168, 176):
                            if small_circles_inside[i] not in filtered_circles:
                                filtered_circles.append(small_circles_inside[i])
                            if small_circles_inside[j] not in filtered_circles:
                                filtered_circles.append(small_circles_inside[j])

                if num_circles_inside <= 3 and num_circles_inside >= 2:
                    large_circles.append([lx, ly, lr])
                    
        return large_circles, small_circles_inside

    def _resize_and_move_circles(self, large_circles, small_circles, scale_factor):
        # Move and resize the circles according to scale factor
        for circle in large_circles:
            x, y, r = circle
            new_x = x * scale_factor
            new_y = y * scale_factor
            new_r = r * scale_factor
            cv2.circle(self.original_image, (int(new_x), int(new_y)), int(new_r), (0, 0, 255), 2)
            circle[0] = new_x
            circle[1] = new_y
            circle[2] = new_r

        for circle in small_circles:
            x, y, r = circle
            new_x = x * scale_factor
            new_y = y * scale_factor
            new_r = r * scale_factor
            cv2.circle(self.original_image, (int(new_x), int(new_y)), int(new_r), (0, 255, 0), 2)
            circle[0] = new_x
            circle[1] = new_y
            circle[2] = new_r

        return large_circles, small_circles

    def _detect_aruco_markers(self):
        """
        Detects small ArUco markers.
        Returns:
            - image with drawn boxes
            - list of marker data: [{'id': int, 'corners': np.ndarray}, ...]
        """
        # Create a list to store the detected markers
        detected_markers = []

        # Convert the image to grayscale
        gray_full = cv2.cvtColor(self.original_image, cv2.COLOR_BGR2GRAY)

        # Load dictionary
        aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_50)

        # Set parameters for small marker in small image
        parameters = aruco.DetectorParameters()

        # Detector object
        detector = aruco.ArucoDetector(aruco_dict, parameters)

        # Detect markers
        corners, ids, _ = detector.detectMarkers(gray_full)

        marker_data = []
        image = self.original_image
        if ids is not None:
            image = aruco.drawDetectedMarkers(self.original_image, corners, ids)
            for i in range(len(ids)):
                marker_data.append({
                    "id": int(ids[i][0]),
                    "corners": corners[i][0].squeeze(),
                    "center": corners[i].mean(axis=1).squeeze()
                })
                detected_markers.append((marker_data))
                
        return image, marker_data

    def _compute_angle(self, large_circle, marker):
        large_circle_center = np.array(large_circle[:2])
        marker_center = np.array(marker["center"])
        vector = marker_center - large_circle_center
        angle = np.arctan2(-vector[1], vector[0])
        
        return angle

    def _pair_circles_w_markers(self, circles, markers):
        marker_centers = np.array([marker["center"] for marker in markers])
        large_circle_centers = np.array([circle[:2] for circle in circles["large"]])
        small_circle_centers = np.array([circle[:2] for circle in circles["small"]])

        # compute distance matrix between large circles and markers
        if large_circle_centers.shape[0] == 0:
            return []    # no large circles
        else:
            marker_distance_matrix = np.linalg.norm(
            marker_centers[:, np.newaxis] - large_circle_centers, axis=2)

            marker_data = [None] * len(large_circle_centers)
            for i, marker in enumerate(markers):
                closest_large_circle_index = np.argmin(marker_distance_matrix[i])
                closest_large_circle_distance = marker_distance_matrix[i][closest_large_circle_index]

                if closest_large_circle_distance < (self.OUTER_CIRCLE_RADIUS_MAX * 3 + self.MARKER_RADIUS * 1.2):
                    angle = self._compute_angle(circles["large"][closest_large_circle_index], marker)
                    marker_data[closest_large_circle_index] = {
                        "marker_center": marker["center"],
                        "marker_id": marker["id"],
                        "marker_corners": marker["corners"],
                        "marker_angle": angle
                    }

            small_circle_distance_matrix = np.linalg.norm(
                small_circle_centers[:, np.newaxis] - large_circle_centers, axis=2)
            small_circle_data = [[] for _ in range(len(large_circle_centers))]

            for i, small_circle in enumerate(circles["small"]):
                closest_large_circle_index = np.argmin(small_circle_distance_matrix[i])
                closest_large_circle_distance = small_circle_distance_matrix[i][closest_large_circle_index]

                if closest_large_circle_distance < self.OUTER_CIRCLE_RADIUS_MAX * 2:
                    small_circle_data[closest_large_circle_index].append(small_circle)

            large_circle_data = []

            for i, large_circle in enumerate(large_circle_centers):
                data = {
                    "center": large_circle,
                    "radius": circles["large"][i][2],
                    "small_circles": np.array(small_circle_data[i])
                }
                if marker_data[i] is not None:
                    data.update(marker_data[i])
                large_circle_data.append(data)

            return large_circle_data

    def _fit_circle_least_squares(self, xs, ys):
        """
        Algebraic least-squares circle fit.
        Solves for (a,b,c) in: 2a x + 2b y + c = x^2 + y^2
        Then R = sqrt(a^2 + b^2 + c)
        Returns (a, b, R).
        """
        xs = xs.astype(np.float64)
        ys = ys.astype(np.float64)
        A = np.column_stack([2*xs, 2*ys, np.ones_like(xs)])
        b = xs**2 + ys**2
        # Solve in least squares sense
        params, *_ = np.linalg.lstsq(A, b, rcond=None)
        a, b_param, c = params
        R = np.sqrt(a*a + b_param*b_param + c)
        
        return float(a), float(b_param), float(R)
    def _circle_pixels_by_band(self, img_shape, cx, cy, r, tol=2):
        """
        Return boolean mask of pixels whose center lies within [r - tol, r + tol]
        of (cx, cy). Coordinates: x = column, y = row.
        """
        H, W = img_shape[:2]
        # grid of (x, y) with x in [0..W-1], y in [0..H-1]
        y = np.arange(H, dtype=np.float32)[:, None]   # shape (H, 1)
        x = np.arange(W, dtype=np.float32)[None, :]   # shape (1, W)   # X: cols, Y: rows

        dist = np.linalg.norm([x - cx, y - cy])#np.hypot(x - cx, y - cy)
        mask = (dist >= (r - tol)) & (dist <= (r + tol))
        return mask
    
    def _circle_mask(self, img_shape, cx, cy, r, tol):
        H, W = img_shape
        xs = np.arange(W, dtype=np.float32)
        ys = np.arange(H, dtype=np.float32)
        [X, Y] = np.meshgrid(xs, ys)
        dist = np.hypot(X - cx, Y - cy)
        mask = (dist >= (r - tol)) & (dist <= (r + tol))
        
        return mask

    def _circle_pixels_band_and_edges(self, image_gray, cx, cy, r, tol=2.0,
                                    canny1=50, canny2=150):
        """
        Use a narrow distance band AND edges to get cleaner circle pixels.
        """
        # Ensure 8-bit grayscale
        if image_gray.dtype != np.uint8:
            g = cv2.normalize(image_gray, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        else:
            g = image_gray

        edges = cv2.Canny(g, canny1, canny2, L2gradient=True)
        #band = self._circle_pixels_by_band(g.shape, cx, cy, r, tol)
        band = self._circle_mask(g.shape, cx, cy, r, tol)
        
        #plt.imsave('band.png', band, cmap='gray')
        return band & (edges > 0)
        
    def _refine_circle_from_hough(self, image_gray, cx, cy, r, tol=2.0, min_points=20):
        """
        1) Get boundary pixels using a ring band (optionally ∩ edges)
        2) Fit a new circle to those pixels
        """
        mask = self._circle_pixels_band_and_edges(image_gray, cx, cy, r, tol=tol)
        
        ys, xs = np.nonzero(mask)
        
        if xs.size < min_points:
            # Fallback: widen band and try again
            widen = max(1.0, tol*1.5)
            mask = self._circle_pixels_band_and_edges(image_gray, cx, cy, r, tol=widen)
            ys, xs = np.nonzero(mask)

        if xs.size < 3:
            print("Not enough points to fit a circle to refine, old values will remain")
            #raise ValueError("Not enough points to fit a circle.")
            a = cx
            b = cy
            R = r
        else: 
            a, b, R = self._fit_circle_least_squares(xs, ys)
        
        return {
            "mask": mask,               # boolean mask of selected pixels
            "points_xy": np.column_stack([xs, ys]),  # Nx2 array (x,y)
            "fitted_center": (a, b),    # (cx_refined, cy_refined)
            "fitted_radius": R
        }
    
    def detect(self, original_image, refine_circles=True):
        self.original_image = original_image
        if self.original_image is None:
            raise ValueError("original_image is None")

        image = self._resize_image_by_scale(self.SCALE_FACTOR)
        if not self._is_grayscale(image):
            gray = self._grayscale_image(image)
        else:
            gray = image
        blurred = self._blur_image(gray, 7)

        small_circles = cv2.HoughCircles(
            blurred, cv2.HOUGH_GRADIENT, dp=1.2, minDist=self.INNER_CIRCLE_MIN_DISTANCE,
            param1=50, param2=30,
            minRadius=self.INNER_CIRCLE_RADIUS_MIN, maxRadius=self.INNER_CIRCLE_RADIUS_MAX)
        large_circles = cv2.HoughCircles(
            blurred, cv2.HOUGH_GRADIENT, dp=1.2, minDist=self.OUTER_CIRCLE_MIN_DISTANCE,
            param1=50, param2=30,
            minRadius=self.OUTER_CIRCLE_RADIUS_MIN, maxRadius=self.OUTER_CIRCLE_RADIUS_MAX)
        selected_large, selected_small = self._find_large_circles(
            large_circles, small_circles)

        # go through all large circles and refine them
        if refine_circles:  
            #refine large circles
            if selected_large is not None:
                for i, circle in enumerate(selected_large):
                    x,y,r = circle
                    #print('large circle ',i," : ", x, y, r)
                    new_circle = self._refine_circle_from_hough(gray, x, y, r)
                    selected_large[i][0] = new_circle["fitted_center"][0]
                    selected_large[i][1] = new_circle["fitted_center"][1]
                    selected_large[i][2] = new_circle["fitted_radius"]
                    #print('re la circle ',i," : ", new_circle["fitted_center"][0], new_circle["fitted_center"][1], new_circle["fitted_radius"])
                #refine small circles
                for i, circle in enumerate(selected_small):
                    x,y,r = circle
                    #print('small circle ',i," : ", x, y, r)
                    new_circle = self._refine_circle_from_hough(gray, x, y, r)
                    selected_small[i][0] = new_circle["fitted_center"][0]
                    selected_small[i][1] = new_circle["fitted_center"][1]
                    selected_small[i][2] = new_circle["fitted_radius"]
                    #print('re sm circle ',i," : ", new_circle["fitted_center"][0], new_circle["fitted_center"][1], new_circle["fitted_radius"])

        # Move and resize the circles
        large_circles, small_circles = self._resize_and_move_circles(
            selected_large, selected_small, self.SCALE_FACTOR)
        circles = {}
        circles["large"] = large_circles
        circles["small"] = small_circles
        #print(circles)
        # detect aruco markers
        image_markers, detected_markers = self._detect_aruco_markers()

        large_circle_data = self._pair_circles_w_markers(circles, detected_markers)
        
        return large_circle_data
