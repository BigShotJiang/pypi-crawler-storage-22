import json
import numpy as np
import cv2
import matplotlib.pyplot as plt
import math
from pathlib import Path
import sys

import pytest

sys.path.insert(1, f'{Path(__file__).parent.parent}/src')
from CircleDetector.CircleDetector import CircleDetector


REQUIRED_KEYS = {
    "center",
    "radius",
    "small_circles",
    "marker_center",
    "marker_id",
    "marker_corners",
    "marker_angle",
}

TOL_CENTER = 3.0          # pixels
TOL_RADIUS = 3.0          # pixels
TOL_CIRCLE_RADIUS = 3.0
TOL_ANGLE = 0.02          # radians
TOL_CORNER = 3.0          # pixels

ASSETS = Path(__file__).parent / "assets"
EXPECTED = ASSETS / "expected"


def load_expected(name: str):
    return json.loads((EXPECTED / f"{name}.json").read_text())


def assert_close_tuple(a, b, tol):
    assert len(a) == len(b)
    for x, y in zip(a, b):
        assert math.isfinite(x)
        assert abs(x - y) <= tol

@pytest.mark.parametrize("img_name", ["img1", "img2"])
def test_detector_outputs_are_stable(img_name):
    img_path = ASSETS / f"{img_name}.png"

    expected = load_expected(EXPECTED / f"{img_name}")
    with open(f"{Path(__file__).parent.parent}/input_parameters.json", "r") as j:
        cfg = json.load(j)
    detector = CircleDetector(optional_config=cfg)
    result = detector.detect(cv2.imread(img_path), refine_circles=True)
    result = result[0]

    # ---- 1. Key presence ----
    assert REQUIRED_KEYS.issubset(result.keys())

    # ---- 2. Types & shapes ----
    assert isinstance(result["center"], np.ndarray) and len(result["center"]) == 2
    assert isinstance(result["radius"], (int, float))

    assert isinstance(result["small_circles"], np.ndarray)
    for c in result["small_circles"]:
        assert len(c) == 3

    assert isinstance(result["marker_center"], np.ndarray) and len(result["marker_center"]) == 2
    assert isinstance(result["marker_id"], int)

    assert isinstance(result["marker_corners"], np.ndarray)
    assert len(result["marker_corners"]) == 4
    for c in result["marker_corners"]:
        assert len(c) == 2

    assert isinstance(result["marker_angle"], (int, float))

    # ---- 3. Numerical checks ----
    assert_close_tuple(result["center"], expected["center"], TOL_CENTER)
    assert abs(result["radius"] - expected["radius"]) <= TOL_RADIUS

    assert len(result["small_circles"]) == len(expected["small_circles"])
    for r, e in zip(result["small_circles"], expected["small_circles"]):
        assert_close_tuple(r[:2], e[:2], TOL_CENTER)
        assert abs(r[2] - e[2]) <= TOL_CIRCLE_RADIUS

    assert_close_tuple(result["marker_center"], expected["marker_center"], TOL_CENTER)

    for r, e in zip(result["marker_corners"], expected["marker_corners"]):
        assert_close_tuple(r, e, TOL_CORNER)

    assert abs(result["marker_angle"] - expected["marker_angle"]) <= TOL_ANGLE
    assert result["marker_id"] == expected["marker_id"]