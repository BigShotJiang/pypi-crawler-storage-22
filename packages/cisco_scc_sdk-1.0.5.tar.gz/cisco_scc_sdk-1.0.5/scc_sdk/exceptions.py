# Copyright (c) 2026 Cisco Systems, Inc. and its affiliates
# SPDX-License-Identifier: Apache-2.0

"""
Custom exceptions for the Cisco Security Cloud Control SDK
"""

from typing import Optional, Dict, Any


class SCCError(Exception):
    """Base exception for all SCC API errors.
    
    Attributes:
        message: Error message
        status_code: HTTP status code
        response: Full response data from the API
        tracking_id: API tracking ID for the request (if available)
        timestamp: Error timestamp (if available)
        path: API path that generated the error (if available)
    """
    
    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response: Optional[Dict[str, Any]] = None
    ):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response or {}
        
        # Extract common error fields from response
        self.tracking_id = self.response.get('trackingId')
        self.timestamp = self.response.get('timestamp')
        self.path = self.response.get('path')
    
    def __str__(self):
        """String representation of the error."""
        if self.tracking_id:
            return f"{self.message} (Tracking ID: {self.tracking_id})"
        return self.message
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert error to dictionary format."""
        return {
            'message': self.message,
            'status_code': self.status_code,
            'tracking_id': self.tracking_id,
            'timestamp': self.timestamp,
            'path': self.path,
            'response': self.response
        }

class AuthenticationError(SCCError):
    """Raised when authentication fails (401)."""
    pass


class ForbiddenError(SCCError):
    """Raised when access is forbidden (403)."""
    pass


class NotFoundError(SCCError):
    """Raised when a resource is not found (404)."""
    pass


class ValidationError(SCCError):
    """Raised when request validation fails (400)."""
    pass


class ServerError(SCCError):
    """Raised when server error occurs (500)."""
    pass
