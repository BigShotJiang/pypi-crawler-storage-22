# Copyright (c) 2026 Cisco Systems, Inc. and its affiliates
# SPDX-License-Identifier: Apache-2.0

"""
Roles resource handler
"""

from typing import List, Dict, Any, Optional
from enum import Enum
from .base import BaseResource


class ProductName(Enum):
    """Enumeration of supported product names for role filtering."""
    SECURITY_CLOUD_CONTROL = "Security Cloud Control"
    CISCO_SECURE_ACCESS = "Cisco Secure Access"


class RolesResource(BaseResource):
    """
    Handler for role-related API endpoints.
    
    Example:
        >>> client = Client(access_token="token")
        >>> roles = client.roles.list(org_id="org-uuid")
        >>> role = client.roles.get(org_id="org-uuid", role_id="role-uuid")
        >>> result = client.roles.patch(org_id="org-uuid", role_id="role-uuid", users=[...])
    """
    
    def list(
        self,
        org_id: str,
        type: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List all roles for an organization.
        
        Args:
            org_id: The organization UUID
            type: Optional filter by role type (CUSTOM, BUNDLED, STATIC)
        
        Returns:
            Dictionary containing list of roles
        """
        params = {}
        
        if type:
            params["type"] = type
        
        return self.client.get(f"organizations/{org_id}/roles", params=params)
    
    def get(self, org_id: str, role_id: str) -> Dict[str, Any]:
        """
        Get a specific role by ID.
        
        Args:
            org_id: The organization UUID
            role_id: The role UUID
        
        Returns:
            Role dictionary
        """
        return self.client.get(f"organizations/{org_id}/roles/{role_id}")
    
    def patch(
        self,
        org_id: str,
        role_id: str,
        users: Optional[List[Dict[str, str]]] = None,
        groups: Optional[List[Dict[str, str]]] = None
    ) -> Dict[str, Any]:
        """
        Update role assignments by adding or removing users and groups.
        
        Args:
            org_id: The organization UUID
            role_id: The role UUID
            users: List of user operations with 'operation' (add/remove) and 'id' (user UUID)
            groups: List of group operations with 'operation' (add/remove) and 'id' (group UUID)
        
        Returns:
            Dictionary with 'results' array and 'summary' containing success/failure counts
            Example: {
                "results": [...],
                "summary": {
                    "total": 3,
                    "success": 2,
                    "failed": 1,
                    "all_successful": False
                }
            }
        
        Example:
            >>> result = client.roles.patch(
            ...     org_id="org-uuid",
            ...     role_id="role-uuid",
            ...     users=[{"operation": "add", "id": "user-uuid"}],
            ...     groups=[{"operation": "remove", "id": "group-uuid"}]
            ... )
            >>> if result["summary"]["all_successful"]:
            ...     print("All operations successful")
        """
        data = {}
        
        if users:
            data["users"] = users
        if groups:
            data["groups"] = groups
        
        response = self.client.patch(f"organizations/{org_id}/roles/{role_id}", json=data)
        
        # Parse the response - API returns {"results": [...]}
        if isinstance(response, dict) and "results" in response:
            results = response.get("results", [])
        elif isinstance(response, list):
            results = response
        else:
            results = []
        
        # Calculate summary
        total = len(results)
        success_count = sum(1 for r in results if r.get("status") == "success")
        failed_count = sum(1 for r in results if r.get("status") == "failed")
        
        return {
            "results": results,
            "summary": {
                "total": total,
                "success": success_count,
                "failed": failed_count,
                "all_successful": failed_count == 0 and total > 0
            }
        }
    
    def find_role_id(
        self,
        org_id: str,
        product_name: str,
        role_display_name: str
    ) -> Optional[str]:
        """
        Find a role ID by product name and role display name.
        Fetches and searches through STATIC type roles only.
        
        Args:
            org_id: The organization UUID
            product_name: The product name to search for (e.g., "Security Cloud Control")
            role_display_name: The role display name (e.g., "Organization Administrator")
        
        Returns:
            Role ID if found, None otherwise
        
        Example:
            >>> role_id = client.roles.find_role_id(
            ...     org_id="org-uuid",
            ...     product_name="Security Cloud Control",
            ...     role_display_name="Organization Administrator"
            ... )
        """
        # Fetch only STATIC roles
        roles_result = self.list(org_id=org_id, type="STATIC")
        roles = roles_result.get("roles", [])
        
        for role in roles:
            # Check if displayName matches
            if role.get("displayName") != role_display_name:
                continue
            
            # Check if any product name matches
            products = role.get("products", [])
            for product in products:
                if product.get("name") == product_name:
                    return role.get("id")
        
        return None
