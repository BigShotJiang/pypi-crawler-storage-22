# Copyright (c) 2026 Cisco Systems, Inc. and its affiliates
# SPDX-License-Identifier: Apache-2.0

"""
Subscriptions resource handler
"""

from typing import List, Dict, Any, Optional
from .base import BaseResource


class SubscriptionsResource(BaseResource):
    """
    Handler for subscription-related API endpoints.
    
    Example:
        >>> client = Client(access_token="token")
        >>> subs = client.subscriptions.list(org_id="org-uuid")
        >>> sub = client.subscriptions.get(org_id="org-uuid", subscription_id="sub-uuid")
        >>> new_sub = client.subscriptions.create(org_id="org-uuid", claim_code="XXXX-XXXX")
    """
    
    def list(
        self,
        org_id: str,
        name: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        List all subscriptions for an organization.
        
        Args:
            org_id: The organization UUID
            name: Optional subscription name filter
        
        Returns:
            List of subscription dictionaries
        """
        params = {}
        if name:
            params["name"] = name
        
        response = self.client.get(f"organizations/{org_id}/subscriptions", params=params)
        return response.get("subscriptions", [])
    
    def get(self, org_id: str, subscription_id: str) -> Dict[str, Any]:
        """
        Get a specific subscription by ID.
        
        Args:
            org_id: The organization UUID
            subscription_id: The subscription UUID
        
        Returns:
            Subscription dictionary
        """
        return self.client.get(f"organizations/{org_id}/subscriptions/{subscription_id}")
    
    def create(
        self,
        org_id: str,
        claim_code: str,
        products: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Create a new subscription using a claim code.
        
        Args:
            org_id: The organization UUID
            claim_code: Claim code for subscription creation
            products: Optional list of products to provision with configuration
        
        Returns:
            Dictionary with success status
        """
        data = {
            "claimCode": claim_code
        }
        
        if products:
            data["products"] = products
        
        return self.client.post(f"organizations/{org_id}/subscriptions", json=data)
    
    def update(
        self,
        org_id: str,
        subscription_id: str,
        product_id: str,
        status: bool,
        source_instance_id: Optional[str] = None,
        region_code: Optional[str] = None,
        initial_admin: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update a subscription (activate/deactivate product).
        
        Args:
            org_id: The organization UUID
            subscription_id: The subscription UUID
            product_id: The product UUID
            status: True to activate, False to deactivate
            source_instance_id: Source instance ID for using existing tenant
            region_code: Product region code (NAM, EMEA, APAC, US, GLOBAL)
            initial_admin: Initial admin email for new tenant provisioning
        
        Returns:
            Updated subscription dictionary
        """
        data = {
            "productId": product_id,
            "status": status
        }
        
        if source_instance_id:
            data["sourceInstanceId"] = source_instance_id
        if region_code:
            data["regionCode"] = region_code
        if initial_admin:
            data["initialAdmin"] = initial_admin
        
        return self.client.put(
            f"organizations/{org_id}/subscriptions/{subscription_id}",
            json=data
        )
    
    def patch(
        self,
        org_id: str,
        subscription_id: str,
        entitlements: List[Dict[str, Any]],
        use_existing_tenants: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Patch a subscription (update entitlement quantities for managed orgs).
        
        Args:
            org_id: The managed organization UUID
            subscription_id: The subscription UUID
            entitlements: List of entitlements with id and quantity
            use_existing_tenants: Optional list of existing tenant UUIDs
        
        Returns:
            Updated subscription dictionary
        
        Example:
            >>> client.subscriptions.patch(
            ...     org_id="org-uuid",
            ...     subscription_id="sub-uuid",
            ...     entitlements=[{"id": "E3S-AIDEF-ADV", "quantity": 10}],
            ...     use_existing_tenants=["8a9f43fa-f8f5-4aac-8d0b-380cf6656255"]
            ... )
        """
        data = {"entitlements": entitlements}
        
        if use_existing_tenants:
            data["useExistingTenants"] = use_existing_tenants
        
        return self.client.patch(
            f"organizations/{org_id}/subscriptions/{subscription_id}",
            json=data
        )
    
    def read_claim_code(self, org_id: str, claim_code: str) -> Dict[str, Any]:
        """
        Read and validate claim code details.
        
        Args:
            org_id: The organization UUID
            claim_code: Claim code to validate
        
        Returns:
            Claim code information dictionary
        """
        data = {"claimCode": claim_code}
        return self.client.post(
            f"organizations/{org_id}/subscriptions/claimInfo",
            json=data
        )
    
    def print_subscription_details(self, subscription: Dict[str, Any], max_products: int = 5) -> None:
        """
        Print subscription details in a formatted way.
        
        Args:
            subscription: Subscription dictionary (from get() or list())
            max_products: Maximum number of products to display (default: 5)
        
        Example:
            >>> sub = client.subscriptions.get(org_id="...", subscription_id="...")
            >>> client.subscriptions.print_subscription_details(sub)
        """
        print("\n✓ Subscription Details:")
        print(f"  - Name: {subscription.get('name')}")
        print(f"  - ID: {subscription.get('id')}")
        print(f"  - Created: {subscription.get('created')}")
        
        products = subscription.get("products", [])
        if products:
            print(f"  - Products ({len(products)}):")
            for product in products[:max_products]:
                print(f"      • {product.get('name')} - {product.get('status')}")
            if len(products) > max_products:
                print(f"      ... and {len(products) - max_products} more")
    
    def build_products_from_claim_info(
        self,
        claim_info: Dict[str, Any],
        preferred_region: str = "NAM"
    ) -> List[Dict[str, Any]]:
        """
        Build products list from claim info with region selection.
        
        Args:
            claim_info: Claim code information dictionary (from read_claim_code())
            preferred_region: Preferred region code (default: "NAM")
        
        Returns:
            List of products ready for subscription creation
        
        Example:
            >>> claim_info = client.subscriptions.read_claim_code(org_id="...", claim_code="...")
            >>> products = client.subscriptions.build_products_from_claim_info(claim_info)
            >>> client.subscriptions.create(org_id="...", claim_code="...", products=products)
        """
        products = []
        
        for product in claim_info.get("products", []):
            allowed_regions = product.get("allowedRegions", [])
            
            # Select region: prefer specified region, otherwise first available
            selected_region = None
            for region in allowed_regions:
                if region.get("regionCode") == preferred_region:
                    selected_region = region
                    break
            
            if not selected_region and allowed_regions:
                selected_region = allowed_regions[0]
            
            if selected_region:
                products.append({
                    "id": product.get("id"),
                    "useExistingTenant": False,
                    "regionCode": selected_region.get("regionCode"),
                    "regionDescription": selected_region.get("regionDescription")
                })
        
        return products
    
    def print_claim_info(self, claim_info: Dict[str, Any]) -> None:
        """
        Print claim code information in a formatted way.
        
        Args:
            claim_info: Claim code information dictionary (from read_claim_code())
        
        Example:
            >>> claim_info = client.subscriptions.read_claim_code(org_id="...", claim_code="...")
            >>> client.subscriptions.print_claim_info(claim_info)
        """
        print("\n✓ Claim Code Details:")
        print(f"  - Name: {claim_info.get('name')}")
        print(f"  - Created: {claim_info.get('created')}")
        
        products = claim_info.get("products", [])
        if products:
            print(f"  - Products ({len(products)}):")
            for product in products:
                print(f"      • {product.get('name')}")
                print(f"        ID: {product.get('id')}")
                print(f"        Status: {product.get('status')}")
                
                entitlements = product.get("entitlements", [])
                if entitlements:
                    print(f"        Entitlements:")
                    for ent in entitlements:
                        print(f"          - {ent.get('name')} (ID: {ent.get('id')}): Qty {ent.get('quantity')}")
                
                allowed_regions = product.get("allowedRegions", [])
                if allowed_regions:
                    print(f"        Allowed Regions:")
                    for region in allowed_regions:
                        print(f"          - {region.get('regionDescription')} ({region.get('regionCode')})")
