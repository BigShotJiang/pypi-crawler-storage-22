# Copyright (c) 2026 Cisco Systems, Inc. and its affiliates
# SPDX-License-Identifier: Apache-2.0

"""
Users resource handler
"""

from typing import Dict, Any, Optional, List
from .base import BaseResource


class UsersResource(BaseResource):
    """
    Handler for user-related API endpoints.
    
    Example:
        >>> client = Client(access_token="token")
        >>> users = client.users.list(org_id="org-uuid")
        >>> user = client.users.get(org_id="org-uuid", user_id="user-uuid")
        >>> updated_user = client.users.update(org_id="org-uuid", user_id="user-uuid", first_name="John")
    """
    
    def list(
        self,
        org_id: str,
        group_id: Optional[str] = None,
        status: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List all users for an organization.
        
        Args:
            org_id: The organization UUID
            group_id: Optional group ID to filter users by group membership
            status: Optional status filter (ACTIVE, DISABLE, PENDING, SHARED)
        
        Returns:
            Dictionary containing list of users
        """
        params = {}
        
        if group_id:
            params["groupId"] = group_id
        if status:
            params["status"] = status
        
        return self.client.get(f"organizations/{org_id}/users", params=params)
    
    def get(self, org_id: str, user_id: str) -> Dict[str, Any]:
        """
        Get a specific user by ID.
        
        Args:
            org_id: The organization UUID
            user_id: The user UUID
        
        Returns:
            User dictionary
        """
        return self.client.get(f"organizations/{org_id}/users/{user_id}")
    
    def invite(
        self,
        org_id: str,
        email: str,
        first_name: str,
        last_name: str
    ) -> Dict[str, Any]:
        """
        Invite a new user to the organization.
        
        Args:
            org_id: The organization UUID
            email: User's email address
            first_name: User's first name
            last_name: User's last name
        
        Returns:
            User operation response dictionary
        
        Example:
            >>> client.users.invite(
            ...     org_id="org-uuid",
            ...     email="user@example.com",
            ...     first_name="John",
            ...     last_name="Doe"
            ... )
        """
        return self.patch(
            org_id=org_id,
            users=[{
                "email": email,
                "operation": "invite",
                "firstName": first_name,
                "lastName": last_name
            }]
        )
    
    def disable(
        self,
        org_id: str,
        email: str
    ) -> Dict[str, Any]:
        """
        Disable a user account.
        
        Args:
            org_id: The organization UUID
            email: User's email address
        
        Returns:
            User operation response dictionary
        
        Example:
            >>> client.users.disable(
            ...     org_id="org-uuid",
            ...     email="user@example.com"
            ... )
        """
        return self.patch(
            org_id=org_id,
            users=[{
                "email": email,
                "operation": "disable"
            }]
        )
    
    def enable(
        self,
        org_id: str,
        email: str
    ) -> Dict[str, Any]:
        """
        Enable a user account.
        
        Args:
            org_id: The organization UUID
            email: User's email address
        
        Returns:
            User operation response dictionary
        
        Example:
            >>> client.users.enable(
            ...     org_id="org-uuid",
            ...     email="user@example.com"
            ... )
        """
        return self.patch(
            org_id=org_id,
            users=[{
                "email": email,
                "operation": "enable"
            }]
        )
    
    def remove(
        self,
        org_id: str,
        email: str
    ) -> Dict[str, Any]:
        """
        Remove a user from the organization.
        
        Args:
            org_id: The organization UUID
            email: User's email address
        
        Returns:
            User operation response dictionary
        
        Example:
            >>> client.users.remove(
            ...     org_id="org-uuid",
            ...     email="user@example.com"
            ... )
        """
        return self.patch(
            org_id=org_id,
            users=[{
                "email": email,
                "operation": "remove"
            }]
        )
    
    def resend_email_invite(
        self,
        org_id: str,
        email: str
    ) -> Dict[str, Any]:
        """
        Resend email invitation to a user.
        
        Args:
            org_id: The organization UUID
            email: User's email address
        
        Returns:
            User operation response dictionary
        
        Example:
            >>> client.users.resend_email_invite(
            ...     org_id="org-uuid",
            ...     email="user@example.com"
            ... )
        """
        return self.patch(
            org_id=org_id,
            users=[{
                "email": email,
                "operation": "resend_email_invite"
            }]
        )
    
    def update(
        self,
        org_id: str,
        user_id: str,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update a user's first and last name.
        
        Args:
            org_id: The organization UUID
            user_id: The user UUID
            first_name: User's first name
            last_name: User's last name
        
        Returns:
            Updated user dictionary
        """
        data = {}
        
        if first_name:
            data["firstName"] = first_name
        if last_name:
            data["lastName"] = last_name
        
        return self.client.put(f"organizations/{org_id}/users/{user_id}", json=data)
    
    def patch(
        self,
        org_id: str,
        users: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Perform operations on users (invite, disable, enable, remove, resend_email_invite).
        
        Args:
            org_id: The organization UUID
            users: List of user operation requests, each containing:
                   - email: User's email address
                   - operation: Operation to perform (invite, disable, enable, remove, resend_email_invite)
                   - firstName: User's first name (required for 'invite' operation)
                   - lastName: User's last name (required for 'invite' operation)
        
        Returns:
            Operation result dictionary with results array
        
        Example:
            >>> # Invite users
            >>> client.users.patch(
            ...     org_id="org-uuid",
            ...     users=[
            ...         {
            ...             "email": "user1@example.com",
            ...             "operation": "invite",
            ...             "firstName": "John",
            ...             "lastName": "Doe"
            ...         },
            ...         {
            ...             "email": "user2@example.com",
            ...             "operation": "invite",
            ...             "firstName": "Jane",
            ...             "lastName": "Smith"
            ...         }
            ...     ]
            ... )
            >>> # Disable a user
            >>> client.users.patch(
            ...     org_id="org-uuid",
            ...     users=[{"email": "user@example.com", "operation": "disable"}]
            ... )
        """
        # Validate users
        for user in users:
            if "email" not in user or "operation" not in user:
                raise ValueError("Each user must have email and operation fields")
            
            # Validate operation type
            valid_operations = ["invite", "disable", "enable", "remove", "resend_email_invite"]
            if user["operation"] not in valid_operations:
                raise ValueError(f"Invalid operation: {user['operation']}. Must be one of: {', '.join(valid_operations)}")
            
            # For invite operation, firstName and lastName are required
            if user["operation"] == "invite":
                if "firstName" not in user or "lastName" not in user:
                    raise ValueError("firstName and lastName are required for invite operation")
        
        data = {"users": users}
        
        return self.client.patch(f"organizations/{org_id}/users", json=data)
    
    def get_groups(self, org_id: str, user_id: str) -> Dict[str, Any]:
        """
        List all groups to which a user is assigned.
        
        Args:
            org_id: The organization UUID
            user_id: The user UUID
        
        Returns:
            Dictionary containing list of groups
        """
        return self.client.get(f"organizations/{org_id}/users/{user_id}/groups")
    
    def print_patch_results(self, result: Dict[str, Any]) -> None:
        """
        Print user patch operation results in a formatted way.
        
        Args:
            result: Result dictionary from patch operations (invite, disable, enable, etc.)
        
        Example:
            >>> result = client.users.invite(org_id="...", email="...", first_name="...", last_name="...")
            >>> client.users.print_patch_results(result)
        """
        if 'results' in result:
            for user_result in result.get('results', []):
                email = user_result.get('email', 'Unknown')
                status = user_result.get('status')
                
                if status == 'success':
                    print(f"    ✓ {email}: Success")
                else:
                    print(f"    ✗ {email}: {status}")
                    if user_result.get('errorDescription'):
                        print(f"      Error: {user_result.get('errorDescription')}")
