"""Tests for citations-collector."""
