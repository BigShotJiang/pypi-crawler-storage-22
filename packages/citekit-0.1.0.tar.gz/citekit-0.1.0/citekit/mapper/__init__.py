"""Mapper providers for CiteKit."""
