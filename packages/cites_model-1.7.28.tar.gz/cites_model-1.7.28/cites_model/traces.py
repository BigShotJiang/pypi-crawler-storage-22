from datetime import datetime

from pydantic import Field
from sysnet_pyutils.models.general import LogItemType


class TracesLogType(LogItemType):
    date_created: datetime | None = Field(default=None, description='Datum vytvoření')
    operation: str | None = Field(default=None, description='Operace')
    status: int | None = Field(default=None, description='Stav operace')
    request: dict | None = Field(default=None, description='Požadavek')
    response: dict | None = Field(default=None, description='Odpověď')
    error: str | None = Field(default=None, description='Chyba operace')
    fault: dict | None = Field(default=None, description='Chyba zdroje')
