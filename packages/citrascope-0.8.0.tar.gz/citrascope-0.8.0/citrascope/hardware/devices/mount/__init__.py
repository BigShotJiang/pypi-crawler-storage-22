"""Mount device adapters."""

from citrascope.hardware.devices.mount.abstract_mount import AbstractMount

__all__ = [
    "AbstractMount",
]
