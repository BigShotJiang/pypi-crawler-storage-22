
# Allows for exporting meetings for use in other modules
# Global variables used throughout the application. 
meetings = []
bills = []
meetingDetailsHTML = []
legislationDetailsHTML = []
fileLocaters = []
categories = {
    "Immigration": [],
    "Economy": [],
    "Civil": []
}
