#!python3
# -*- coding: utf-8 -*-
"""
Alias to most complete BuilderPackage implementation
"""

from ckanapi_harvesters.builder.builder_package_1_basic import example_package_xls
from ckanapi_harvesters.builder.builder_package_2_harvesters import BuilderPackageWithHarvesters as BuilderPackage  # alias

