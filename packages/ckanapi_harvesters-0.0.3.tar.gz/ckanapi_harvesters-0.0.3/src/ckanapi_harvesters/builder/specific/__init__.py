#!python3
# -*- coding: utf-8 -*-
"""
Default package builders
"""

from . import configuration_builder

# alias
from .configuration_builder import ConfigurationBuilder

