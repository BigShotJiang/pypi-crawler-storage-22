#!python3
# -*- coding: utf-8 -*-
"""
Deprecated code
"""

from . import ckan_api_deprecated
from . import ckan_api_deprecated_vocabularies

