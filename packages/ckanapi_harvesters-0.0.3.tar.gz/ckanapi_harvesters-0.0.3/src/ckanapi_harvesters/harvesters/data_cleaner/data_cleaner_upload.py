#!python3
# -*- coding: utf-8 -*-
"""
Alias
"""

from ckanapi_harvesters.harvesters.data_cleaner.data_cleaner_upload_1_basic import _pd_series_type_detect
from ckanapi_harvesters.harvesters.data_cleaner.data_cleaner_upload_2_geom import CkanDataCleanerUploadGeom as CkanDataCleanerUpload  # alias

