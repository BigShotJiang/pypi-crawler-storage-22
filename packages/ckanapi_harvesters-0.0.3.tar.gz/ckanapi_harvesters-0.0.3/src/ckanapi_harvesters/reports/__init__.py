#!python3
# -*- coding: utf-8 -*-
"""
Package to make reports on the CKAN database.
"""

from . import admin_report

# usage shortcuts


