# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-02-06

### Added
- Initial release of cl-preset package
- Preset installation with support for global, user, and project scopes
- CLI commands: init, install, list, info, uninstall
- Preset metadata validation using Pydantic
- Rich terminal output with formatted tables
- JSON output support for listing presets
- Example web development strategy preset
- Comprehensive test suite with pytest
- Support for preset types: agent, skill, command, strategy

### Features
- Create preset scaffolds with directory structure
- Install presets from local directories
- List installed presets with optional scope filtering
- Display detailed preset information
- Uninstall presets by name
- Registry-based installation tracking
