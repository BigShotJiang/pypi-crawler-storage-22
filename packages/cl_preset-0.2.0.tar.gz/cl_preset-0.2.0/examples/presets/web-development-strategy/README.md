# Web Development Strategy

A comprehensive preset for web development projects using Claude Code.

## Description

This preset provides optimized agents, skills, and commands for web development workflows including:

- FastAPI backend development
- React frontend development
- Docker containerization
- CI/CD pipeline setup

## Installation

```bash
cl-preset install . --name web-development-strategy --description "Web development preset with FastAPI and React"
```

## Structure

- `agents/` - Web development specialized agents
- `skills/` - Framework-specific skills
- `commands/` - Custom commands for web workflows
- `examples/` - Example projects and templates

## Author

William Jung

## License

MIT
