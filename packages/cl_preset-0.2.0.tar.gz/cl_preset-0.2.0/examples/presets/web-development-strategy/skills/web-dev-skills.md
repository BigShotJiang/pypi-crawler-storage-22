---
name: moai-skill-web-development
description: >
  Web development skills for FastAPI, React, and modern web frameworks.
  Provides scaffolding, patterns, and best practices.
---

# Web Development Skills

Skills for rapid web development with modern frameworks.

## Features

- FastAPI project templates
- React component generators
- API integration patterns
- Testing setup
- Docker configuration

## Quick Start

Use these skills when starting new web projects or adding features to existing web applications.
