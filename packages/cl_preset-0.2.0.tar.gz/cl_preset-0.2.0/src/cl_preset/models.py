"""
Data models for cl-preset package.
"""

from enum import Enum
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field


class PresetScope(str, Enum):
    """Scope levels for preset installation."""
    GLOBAL = "global"
    USER = "user"
    PROJECT = "project"


class PresetType(str, Enum):
    """Types of presets."""
    AGENT = "agent"
    SKILL = "skill"
    COMMAND = "command"
    STRATEGY = "strategy"


class PresetMetadata(BaseModel):
    """Metadata for a preset package."""
    name: str = Field(..., description="Unique identifier for the preset")
    version: str = Field(..., description="Semantic version (e.g., 1.0.0)")
    description: str = Field(..., description="Brief description of the preset")
    author: str = Field(default="", description="Author name or handle")
    license: str = Field(default="MIT", description="License identifier")
    preset_type: PresetType = Field(default=PresetType.STRATEGY, description="Type of preset")
    tags: list[str] = Field(default_factory=list, description="Tags for discovery")


class PresetConfig(BaseModel):
    """Configuration for a preset."""
    metadata: PresetMetadata
    source_path: Path = Field(..., description="Path to preset source files")
    target_path: Path | None = Field(None, description="Installation target path")
    scope: PresetScope = Field(default=PresetScope.USER, description="Installation scope")
    dependencies: list[str] = Field(default_factory=list, description="Required dependencies")

    def get_install_path(self, base_path: Path) -> Path:
        """Get the installation path based on scope."""
        if self.scope == PresetScope.GLOBAL:
            return base_path / "share" / "cl-preset" / self.metadata.name
        elif self.scope == PresetScope.USER:
            return Path.home() / ".claude" / "presets" / self.metadata.name
        else:  # PROJECT
            return Path.cwd() / ".claude" / "presets" / self.metadata.name


class Preset(BaseModel):
    """A preset package containing Claude Code configuration."""
    model_config = ConfigDict(arbitrary_types_allowed=True)

    config: PresetConfig
    files: dict[str, str] = Field(default_factory=dict, description="File contents mapping")
