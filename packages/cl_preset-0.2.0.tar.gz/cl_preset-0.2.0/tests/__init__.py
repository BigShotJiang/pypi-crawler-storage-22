"""Tests for cl_preset package."""
