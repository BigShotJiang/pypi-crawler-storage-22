"""Tests for cl_preset.cli module."""

from pathlib import Path
from unittest.mock import Mock, patch

import pytest
from click.testing import CliRunner

from cl_preset.cli import main


@pytest.fixture
def runner() -> CliRunner:
    """Create a Click CLI test runner."""
    return CliRunner()


def test_cli_main_help(runner: CliRunner) -> None:
    """Test CLI main command help."""
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "Manage Claude Code configuration presets" in result.output


def test_cli_version(runner: CliRunner) -> None:
    """Test CLI version command."""
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.output


def test_cli_list_empty(runner: CliRunner, tmp_path: Path) -> None:
    """Test CLI list command with no presets."""
    with patch("cl_preset.cli.PresetManager") as mock_manager_class:
        mock_manager = Mock()
        mock_manager.list.return_value = []
        mock_manager_class.return_value = mock_manager

        result = runner.invoke(main, ["list"])
        assert result.exit_code == 0


def test_cli_init_command(runner: CliRunner) -> None:
    """Test CLI init command creates scaffold."""
    with runner.isolated_filesystem() as temp_dir:
        result = runner.invoke(main, ["init", "test-preset"])
        assert result.exit_code == 0

        # The isolated_filesystem changes to a temp directory
        preset_dir = Path(temp_dir) / "test-preset"
        assert preset_dir.exists()
        assert (preset_dir / "agents").exists()
        assert (preset_dir / "skills").exists()
        assert (preset_dir / "commands").exists()
        assert (preset_dir / "examples").exists()
        assert (preset_dir / "README.md").exists()
        assert (Path(temp_dir) / "preset.json").exists()


def test_cli_info_command_not_found(runner: CliRunner) -> None:
    """Test CLI info command with non-existent preset."""
    with patch("cl_preset.cli.PresetManager") as mock_manager_class:
        mock_manager = Mock()
        mock_manager._load_registry.return_value = {"installed": []}
        mock_manager_class.return_value = mock_manager

        result = runner.invoke(main, ["info", "nonexistent"])
        assert result.exit_code == 0
        assert "not found" in result.output
