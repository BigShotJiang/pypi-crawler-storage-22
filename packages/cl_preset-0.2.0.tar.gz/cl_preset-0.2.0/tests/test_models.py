"""Tests for cl_preset.models module."""

import pytest
from pydantic import ValidationError

from cl_preset.models import Preset, PresetConfig, PresetMetadata, PresetScope, PresetType


def test_preset_scope_enum() -> None:
    """Test PresetScope enum values."""
    assert PresetScope.GLOBAL.value == "global"
    assert PresetScope.USER.value == "user"
    assert PresetScope.PROJECT.value == "project"


def test_preset_type_enum() -> None:
    """Test PresetType enum values."""
    assert PresetType.AGENT.value == "agent"
    assert PresetType.SKILL.value == "skill"
    assert PresetType.COMMAND.value == "command"
    assert PresetType.STRATEGY.value == "strategy"


def test_preset_metadata_creation() -> None:
    """Test creating PresetMetadata with valid data."""
    metadata = PresetMetadata(
        name="test-preset",
        version="1.0.0",
        description="A test preset",
        author="Test Author",
        license="MIT",
        preset_type=PresetType.STRATEGY,
        tags=["test", "example"]
    )

    assert metadata.name == "test-preset"
    assert metadata.version == "1.0.0"
    assert metadata.description == "A test preset"
    assert metadata.author == "Test Author"
    assert metadata.license == "MIT"
    assert metadata.preset_type == PresetType.STRATEGY
    assert metadata.tags == ["test", "example"]


def test_preset_metadata_defaults() -> None:
    """Test PresetMetadata default values."""
    metadata = PresetMetadata(
        name="test-preset",
        version="1.0.0",
        description="A test preset"
    )

    assert metadata.author == ""
    assert metadata.license == "MIT"
    assert metadata.preset_type == PresetType.STRATEGY
    assert metadata.tags == []


def test_preset_metadata_validation() -> None:
    """Test PresetMetadata validation."""
    with pytest.raises(ValidationError):
        PresetMetadata(
            version="1.0.0",
            description="A test preset"
            # Missing required 'name' field
        )


def test_preset_config_install_path() -> None:
    """Test PresetConfig.get_install_path method."""
    from pathlib import Path

    metadata = PresetMetadata(
        name="test-preset",
        version="1.0.0",
        description="A test preset"
    )

    # Test global scope
    config_global = PresetConfig(
        metadata=metadata,
        source_path=Path("/tmp/source"),
        scope=PresetScope.GLOBAL
    )
    path_global = config_global.get_install_path(Path("/base"))
    assert "test-preset" in str(path_global)

    # Test user scope
    config_user = PresetConfig(
        metadata=metadata,
        source_path=Path("/tmp/source"),
        scope=PresetScope.USER
    )
    path_user = config_user.get_install_path(Path("/base"))
    assert ".claude" in str(path_user)
    assert "test-preset" in str(path_user)


def test_preset_creation() -> None:
    """Test creating a Preset object."""
    from pathlib import Path

    metadata = PresetMetadata(
        name="test-preset",
        version="1.0.0",
        description="A test preset"
    )

    config = PresetConfig(
        metadata=metadata,
        source_path=Path("/tmp/source"),
        scope=PresetScope.USER
    )

    preset = Preset(config=config)

    assert preset.config.metadata.name == "test-preset"
    assert preset.config.metadata.version == "1.0.0"
    assert preset.files == {}
