"""
cl-preset: A package for managing Claude Code configuration presets and strategies.

This package allows users to package their Claude Code strategies and install them
with different scopes (global, project, etc.).
"""

__version__ = "0.1.0"

from cl_preset.manager import PresetManager
from cl_preset.models import Preset, PresetConfig, PresetScope
from cl_preset.tui import StrategyTUI

__all__ = [
    "__version__",
    "Preset",
    "PresetScope",
    "PresetConfig",
    "PresetManager",
    "StrategyTUI",
]
