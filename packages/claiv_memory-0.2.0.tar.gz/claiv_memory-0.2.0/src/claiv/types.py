"""TypedDict types matching the Claiv Memory API contracts exactly."""

from __future__ import annotations

from typing import Any, Literal, TypedDict

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

EventType = Literal["message", "tool_call", "app_event"]

EventRole = Literal["user", "assistant", "system", "tool"]

MemoryBlockType = Literal["open_loop", "fact", "claim", "episode", "chunk", "contradiction"]

UsageRange = Literal["7d", "30d", "month", "today"]

# ---------------------------------------------------------------------------
# Ingest
# ---------------------------------------------------------------------------


class IngestRequest(TypedDict, total=False):
    user_id: str  # required – enforced at runtime
    type: EventType  # required
    content: str  # required
    thread_id: str
    role: EventRole
    metadata: dict[str, Any]
    event_time: str
    idempotency_key: str


class IngestResponse(TypedDict):
    event_id: str
    deduped: bool


# ---------------------------------------------------------------------------
# Recall
# ---------------------------------------------------------------------------


class RecallRequest(TypedDict, total=False):
    user_id: str  # required
    task: str  # required
    token_budget: int  # required
    thread_id: str
    min_confidence: float
    scope: dict[str, Any]


class MemoryBlock(TypedDict):
    type: MemoryBlockType
    content: str
    source_ids: list[str]
    score: float


class RecallResponse(TypedDict):
    system_context: str
    memory_blocks: list[MemoryBlock]
    citations: list[str]
    token_estimate: int


ContextPack = RecallResponse

# ---------------------------------------------------------------------------
# Forget
# ---------------------------------------------------------------------------


class ForgetRequest(TypedDict, total=False):
    user_id: str  # required
    thread_id: str
    from_time: str
    to_time: str


class DeletedCounts(TypedDict):
    events: int
    chunks: int
    episodes: int
    facts: int
    claims: int
    open_loops: int


class ForgetResponse(TypedDict):
    receipt_id: str
    deleted_counts: DeletedCounts


# ---------------------------------------------------------------------------
# Deletion Receipts
# ---------------------------------------------------------------------------


class DeletionScope(TypedDict, total=False):
    user_id: str  # required
    thread_id: str | None
    from_time: str | None
    to_time: str | None


class DeletionReceipt(TypedDict):
    receipt_id: str
    scope: DeletionScope
    requested_at: str
    completed_at: str | None
    deleted_counts: DeletedCounts


class ListDeletionReceiptsResponse(TypedDict):
    receipts: list[DeletionReceipt]
    total: int
    limit: int
    offset: int


# ---------------------------------------------------------------------------
# Usage
# ---------------------------------------------------------------------------


class UsageTotals(TypedDict):
    requests: int
    ingest_requests: int
    recall_requests: int
    forget_requests: int
    ingest_events: int
    tokens: int
    work_units: int
    errors: int
    request_bytes: int
    response_bytes: int


class UsageDailyEntry(TypedDict):
    date: str
    requests: int
    ingest_events: int
    tokens: int
    work_units: int
    errors: int


class UsageSummaryResponse(TypedDict):
    range: str
    start_date: str
    end_date: str
    totals: UsageTotals
    daily: list[UsageDailyEntry]


class EndpointBreakdownEntry(TypedDict):
    endpoint: str
    requests: int
    errors: int
    error_rate: float
    avg_latency_ms: float


class UsageBreakdownResponse(TypedDict):
    range: str
    start_date: str
    end_date: str
    endpoints: list[EndpointBreakdownEntry]


class UsageLimitMetric(TypedDict):
    used: int
    limit: int | None
    remaining: int | None
    percentage_used: float


class _UsageLimits(TypedDict):
    requests: UsageLimitMetric
    tokens: UsageLimitMetric
    work_units: UsageLimitMetric
    ingest_events: UsageLimitMetric


class UsageLimitsResponse(TypedDict):
    plan: str
    billing_cycle_day: int
    reset_date: str
    is_within_quota: bool
    limits: _UsageLimits


# ---------------------------------------------------------------------------
# V2 Types (assertion-based memory)
# ---------------------------------------------------------------------------

V2MemoryBlockType = Literal["assertion", "episode", "conflict"]


class V2EvidenceRef(TypedDict):
    event_id: str
    quote: str


class V2MemoryBlock(TypedDict, total=False):
    type: V2MemoryBlockType  # required
    content: str  # required
    source_ids: list[str]  # required
    evidence: list[V2EvidenceRef]
    score: float  # required


class V2RecallRequest(TypedDict, total=False):
    user_id: str  # required
    task: str  # required
    token_budget: int  # required
    thread_id: str
    min_confidence: float


class V2RecallResponse(TypedDict):
    system_context: str
    memory_blocks: list[V2MemoryBlock]
    citations: list[str]
    token_estimate: int


class V2ForgetRequest(TypedDict, total=False):
    user_id: str  # required
    thread_id: str
    from_time: str
    to_time: str


class V2DeletedCounts(TypedDict):
    events: int
    assertions: int
    episodes: int
    entities: int
    conflicts: int
    extraction_failures: int


class V2ForgetResponse(TypedDict, total=False):
    receipt_id: str  # required
    deleted_counts: V2DeletedCounts  # required
    warnings: list[str]


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class _ApiErrorDetail(TypedDict, total=False):
    code: str  # required
    message: str  # required
    request_id: str  # required
    details: Any


class ApiErrorBody(TypedDict):
    error: _ApiErrorDetail
