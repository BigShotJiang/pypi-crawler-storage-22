"""Version information for clang-tool-chain."""

__version__ = "1.0.40"
