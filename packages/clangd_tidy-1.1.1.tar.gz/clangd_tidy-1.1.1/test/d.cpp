auto
f() -> int;
