## SET UP INSTRUCTIONS

A Model Context Protocol (MCP) for analyzing user feedback and querying Clarity. This guide explains how to install and use the Clarity MCP server with MCP-compatible clients like Cursor and Claude Code. 

---

## 1. Prerequisites

- **Python version**: Python 3.10 or higher.
- **Clarity account**:  
  - **Email** and **password** for your Clarity account.  
- **MCP-compatible client**:
  - Cursor (with `mcp.json` support).
  - Claude Code (or another client that can load MCP servers via config).

---

## 2. Install the Clarity MCP server

```bash
python -m pip install clarity-mcp-server
```

After install, the `clarity-mcp` entrypoint should be available on your `PATH`. You can verify this by running:

```bash
clarity-mcp --help
```

If this command is not found, make sure your Python scripts directory is on your `PATH`, or install with a tool like `pipx`:

```bash
pipx install clarity-mcp-server
```

---

## 3. Required environment variables

The Clarity MCP server needs the following environment variables when it is started by your MCP client (Cursor, Claude Code, etc.):

- `CLARITY_EMAIL` (required) – Your Clarity account email.
- `CLARITY_PASSWORD` (required) – Your Clarity account password.

---

## 4. Set up with Cursor (`mcp.json`)

1. **Locate your Cursor MCP config file**:
   - Open Cursor.
   - Go to **Settings → MCP** (or the MCP configuration section).
   - Open or edit your `mcp.json` file.

2. **Add a new `clarity` server entry** using the installed `clarity-mcp` command.

   Recommended configuration:

   ```json
   {
     "mcpServers": {
       "clarity": {
          "command": "uvx",
          "args": [
            "clarity-mcp"
          ],
          "env": {
            "CLARITY_EMAIL": "your_email@example.com",
            "CLARITY_PASSWORD": "your_password"
          }
        }
     }
   }
   ```

   - **Replace** `your_email@example.com` and `your_password` with your real Clarity credentials.

3. **Restart Cursor** so it reloads your MCP configuration.

4. **Verify in Cursor**:
   - Open the MCP tools list or ask the assistant something that should trigger Clarity tools (e.g., an insight query).
   - You should see tools such as `clarity_ping`, `chat`, and `get_company_info` available from the Clarity MCP server.

---
## 5. Set up with Claude Code

Claude Code now supports configuring MCP servers via the `claude` CLI. To add the Clarity MCP server:

1. **Ensure the `claude` CLI is installed and logged in**.

2. **Run this command to add the `clarity` MCP server**:

   ```bash
   claude mcp add clarity \
     -e CLARITY_EMAIL=your_email@example.com \
     -e CLARITY_PASSWORD=your_password \
     -- uvx clarity-mcp
   ```

   - Replace the `CLARITY_EMAIL` and `CLARITY_PASSWORD` values with the Clarity account you want Claude to use (unless you have been explicitly provided with shared test credentials).

3. **Verify in Claude Code**:
   - Ask Claude to use the Clarity MCP tools (for example: request company info or user feedback insights).
   - Confirm that tools like `clarity_ping`, `get_company_info`, and `chat` appear and run without authentication errors.

---

## 6. Basic usage and troubleshooting

- **Check that the command is available**:
  - Run `clarity-mcp --help` from a terminal.
  - If it fails, ensure:
    - `clarity-mcp-server` is installed (`pip show clarity-mcp-server` or `pipx list`).
    - Your terminal’s `PATH` matches what Cursor/Claude Code use.

- **Authentication errors**:
  - If you see login/auth errors in the MCP logs:
    - Verify `CLARITY_EMAIL` and `CLARITY_PASSWORD` are correct.
    - Make sure they are set in the **MCP config’s** `env` block, not only in your shell.

Once configured, your MCP client should seamlessly call Clarity tools to fetch company info, insights, and chat-based analytics using your Clarity account.

