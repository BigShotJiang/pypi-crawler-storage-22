"""Clarity MCP Server - A Model Context Protocol server for Clarity API."""

__version__ = "0.2.0"
