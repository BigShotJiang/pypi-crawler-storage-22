"""Authentication module for Clarity API using Supabase Auth."""

import httpx


# Default Supabase configuration for Clarity
DEFAULT_SUPABASE_URL = "https://fntlvswjjuoowwvgpeqx.supabase.co"
DEFAULT_SUPABASE_ANON_KEY = (
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
    ".eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZudGx2c3dqanVvb3d3dmdwZXF4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk4ODQ0NjAsImV4cCI6MjA3NTQ2MDQ2MH0"
    ".pTrhjO4S98IyguH_bPnakG_h5AmAkZRjOEQ5YXbEaXc"
)


class AuthenticationError(Exception):
    """Raised when authentication fails."""

    pass


def authenticate(
    email: str,
    password: str,
    supabase_url: str = DEFAULT_SUPABASE_URL,
    supabase_anon_key: str = DEFAULT_SUPABASE_ANON_KEY,
) -> dict:
    """
    Authenticate with Supabase Auth using email and password.

    Args:
        email: User email address
        password: User password
        supabase_url: Supabase project URL
        supabase_anon_key: Supabase anonymous API key

    Returns:
        Dictionary with 'access_token' and 'user_id'

    Raises:
        AuthenticationError: If authentication fails
    """
    token_url = f"{supabase_url.rstrip('/')}/auth/v1/token?grant_type=password"

    try:
        with httpx.Client() as client:
            response = client.post(
                token_url,
                json={"email": email, "password": password},
                headers={
                    "apikey": supabase_anon_key,
                    "Content-Type": "application/json",
                },
                timeout=15.0,
            )

            if response.status_code == 200:
                data = response.json()
                access_token = data.get("access_token")
                user = data.get("user", {})
                user_id = user.get("id")

                if not access_token:
                    raise AuthenticationError(
                        "Authentication response missing access_token"
                    )
                if not user_id:
                    raise AuthenticationError(
                        "Authentication response missing user ID"
                    )

                return {
                    "access_token": access_token,
                    "user_id": user_id,
                    "email": user.get("email", email),
                }
            else:
                try:
                    error_data = response.json()
                    error_detail = error_data.get("error_description") or error_data.get("msg") or "Unknown error"
                except Exception:
                    error_detail = response.text or "Unknown error"
                raise AuthenticationError(f"Authentication failed: {error_detail}")

    except AuthenticationError:
        raise
    except httpx.RequestError as e:
        raise AuthenticationError(f"Request error during authentication: {str(e)}") from e
