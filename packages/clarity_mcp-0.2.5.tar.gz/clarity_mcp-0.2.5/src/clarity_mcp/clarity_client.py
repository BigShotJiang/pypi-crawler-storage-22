"""HTTP client for Clarity API."""

import json
import httpx
from typing import Dict, Any, Optional


class ClarityAPIError(Exception):
    """Raised when Clarity API returns an error."""

    pass


class ClarityClient:
    """Client for making authenticated requests to Clarity API."""

    def __init__(
        self,
        base_url: str,
        auth_token: str,
        user_id: str,
        frontend_url: str,
    ):
        """
        Initialize Clarity API client.

        Args:
            base_url: Base URL of the Clarity API (e.g. https://api.withclarity.dev)
            auth_token: Supabase JWT access token
            user_id: Supabase user ID
        Args:
            base_url: Base URL of the Clarity API (e.g. https://api.withclarity.dev)
            auth_token: Supabase JWT access token
            user_id: Supabase user ID
            frontend_url: Base URL of the Clarity frontend (e.g. https://www.withclarity.dev)
        """
        self.base_url = base_url.rstrip("/")
        self.auth_token = auth_token
        self.user_id = user_id
        self.frontend_url = frontend_url.rstrip("/")
        self._company_id: Optional[str] = None

        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.auth_token}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    def _make_request(
        self, method: str, endpoint: str, **kwargs
    ) -> Dict[str, Any]:
        """
        Make an authenticated HTTP request to the Clarity API.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint (relative to base_url)
            **kwargs: Additional arguments to pass to httpx request

        Returns:
            JSON response as dictionary

        Raises:
            ClarityAPIError: If the API returns an error
        """
        url = endpoint.lstrip("/")

        try:
            response = self._client.request(method, url, **kwargs)

            if response.status_code in (401, 403):
                raise ClarityAPIError(
                    f"Authentication error: {response.status_code} - {response.text}"
                )

            if response.status_code >= 500:
                raise ClarityAPIError(
                    f"Server error: {response.status_code} - {response.text}"
                )

            response.raise_for_status()
            return response.json()

        except httpx.HTTPStatusError as e:
            raise ClarityAPIError(
                f"HTTP error: {e.response.status_code} - {e.response.text}"
            ) from e
        except httpx.RequestError as e:
            raise ClarityAPIError(f"Request error: {str(e)}") from e

    def get_user_data(self) -> Dict[str, Any]:
        """
        Get user and company information.

        Returns:
            Dictionary with user_id, company_id, company_name, etc.
        """
        return self._make_request("GET", f"/auth/user/{self.user_id}")

    def get_company_id(self) -> str:
        """
        Get the company ID for the authenticated user (cached after first call).

        Returns:
            Company ID string

        Raises:
            ClarityAPIError: If company ID cannot be retrieved
        """
        if self._company_id is None:
            user_data = self.get_user_data()
            self._company_id = user_data.get("company_id")
            if not self._company_id:
                raise ClarityAPIError("Could not retrieve company ID from user data")
        return self._company_id

    def get_insights(self, status: Optional[str] = None) -> Dict[str, Any]:
        """
        Get insights for the user's company.

        Args:
            status: Optional status filter (e.g. "new", "new,ticket_created")

        Returns:
            Dictionary containing insights data
        """
        company_id = self.get_company_id()
        params = {}
        if status:
            params["status"] = status
        return self._make_request("GET", f"/insights/{company_id}", params=params)

    def chat(self, query: str) -> str:
        """
        Send a chat query to the Clarity Chat API.

        Args:
            query: The user's question about their users/feedback

        Returns:
            The chat response string

        Raises:
            ClarityAPIError: If the API request fails
        """
        company_id = self.get_company_id()
        chat_url = f"{self.frontend_url}/api/chat"

        try:
            response = httpx.post(
                chat_url,
                headers={
                    "Authorization": f"Bearer {self.auth_token}",
                    "Content-Type": "application/json",
                },
                json={
                    "messages": [{"role": "user", "content": query}],
                    "company_id": company_id,
                    "user_id": self.user_id,
                    "source": "mcp",
                },
                timeout=120.0,
            )

            if response.status_code in (401, 403):
                raise ClarityAPIError(
                    f"Authentication error: {response.status_code} - {response.text}"
                )

            if response.status_code >= 500:
                raise ClarityAPIError(
                    f"Server error: {response.status_code} - {response.text}"
                )

            response.raise_for_status()
            raw = response.text
            if not raw or not raw.strip():
                raise ClarityAPIError(
                    "Chat API returned empty body. "
                    "Ensure JSON is returned for MCP (source='mcp')."
                )
            try:
                data = json.loads(raw)
            except json.JSONDecodeError as e:
                raise ClarityAPIError(
                    f"Chat API returned non-JSON (status={response.status_code}). "
                    f"First 200 chars: {raw[:200]!r}. "
                    "MCP requests require JSON when source is 'mcp'."
                ) from e
            return data.get("answer", data.get("response", str(data)))

        except httpx.HTTPStatusError as e:
            raise ClarityAPIError(
                f"HTTP error: {e.response.status_code} - {e.response.text}"
            ) from e
        except httpx.RequestError as e:
            raise ClarityAPIError(f"Request error: {str(e)}") from e

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
