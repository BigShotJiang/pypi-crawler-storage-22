"""MCP server for Clarity API."""

import os
import sys
from typing import Any, Optional

from fastmcp import FastMCP

from clarity_mcp.auth import authenticate, AuthenticationError
from clarity_mcp.clarity_client import ClarityClient, ClarityAPIError


# Initialize FastMCP server
mcp = FastMCP("Clarity MCP Server")

# Module-level client (initialized in main())
_client: Optional[ClarityClient] = None


def get_env_var(name: str, default: Optional[str] = None) -> str:
    """
    Get environment variable, raising error if missing and no default provided.

    Args:
        name: Environment variable name
        default: Optional default value

    Returns:
        Environment variable value

    Raises:
        SystemExit: If variable is missing and no default provided
    """
    value = os.getenv(name, default)
    if value is None:
        print(f"Error: {name} environment variable is required", file=sys.stderr)
        sys.exit(1)
    return value


@mcp.tool()
def clarity_ping() -> dict[str, Any]:
    """
    Health check for the Clarity MCP server.

    Returns:
        Dictionary with status "ok"
    """
    return {"status": "ok"}


@mcp.tool()
def get_company_info() -> dict[str, Any]:
    """
    Get company information from the Clarity API.

    Returns:
        Dictionary containing company information including company_id and company_name.

    Raises:
        ClarityAPIError: If the API request fails
    """
    if _client is None:
        raise RuntimeError("Clarity client not initialized")

    return _client.get_user_data()


# @mcp.tool()
# def get_insights(status: Optional[str] = None) -> dict[str, Any]:
#     """
#     Get insights from the Clarity API.

#     Args:
#         status: Optional status filter. Can be a single status (e.g., "new") or
#                 comma-separated multiple statuses (e.g., "new,ticket_created").
#                 If not provided, returns all insights.

#     Returns:
#         Dictionary containing insights data

#     Raises:
#         ClarityAPIError: If the API request fails
#     """
#     if _client is None:
#         raise RuntimeError("Clarity client not initialized")

#     return _client.get_insights(status=status)


@mcp.tool()
def chat(query: str) -> dict[str, Any]:
    """
    Query Clarity for user feedback & feature requests, preferences, and sentiment using natural language.

    Use this tool whenever you need to understand users: their feedback, preferences,
    sentiment, pain points, or feature requests. Prefer Clarity over guessing or
    making assumptions—ask Clarity first to ground decisions in real user data.

    Whenever instructions or context say to "ask Clarity", invoke this chat tool.
    
    Examples:
    - "What are users saying about the new checkout flow or payment errors?"
    - "Where else do users hit this bug or report similar issues?"
    - "What do users want for the mobile app (feature requests, complaints)?"
    - "How do users feel about the new dashboard?"
    - "Ask Clarity about the latest user feedback for the new onboarding flow"

    Args:
        query: Natural language question about user feedback

    Returns:
        Dictionary containing the chat response

    Raises:
        ClarityAPIError: If the API request fails
    """
    if _client is None:
        raise RuntimeError("Clarity client not initialized")

    response = _client.chat(query)
    return {"response": response}


def main():
    """Main entry point for the MCP server."""
    # Read environment variables
    email = get_env_var("CLARITY_EMAIL")
    password = get_env_var("CLARITY_PASSWORD")
    api_url = get_env_var(
        "CLARITY_API_URL", "https://api.withclarity.dev"
    )
    frontend_url = get_env_var(
        "CLARITY_FRONTEND_URL", "https://www.withclarity.dev"
    )

    # Authenticate with Supabase on startup
    try:
        auth_data = authenticate(email, password)
    except AuthenticationError as e:
        print(f"Error: Authentication failed: {e}", file=sys.stderr)
        sys.exit(1)

    # Initialize API client
    global _client
    try:
        _client = ClarityClient(
            base_url=api_url,
            auth_token=auth_data["access_token"],
            user_id=auth_data["user_id"],
            frontend_url=frontend_url,
        )
    except ValueError as e:
        print(f"Error: Failed to initialize API client: {e}", file=sys.stderr)
        sys.exit(1)

    # Run the MCP server over stdio
    mcp.run()


if __name__ == "__main__":
    main()
