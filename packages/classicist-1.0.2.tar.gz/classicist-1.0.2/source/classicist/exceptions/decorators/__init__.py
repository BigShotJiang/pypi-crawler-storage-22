from classicist.exceptions.decorators.aliased import AliasError
from classicist.exceptions.decorators.annotation import AnnotationError

__all__ = [
    "AliasError",
    "AnnotationError",
]
