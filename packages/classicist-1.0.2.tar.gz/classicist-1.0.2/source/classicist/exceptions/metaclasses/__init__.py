from classicist.exceptions.metaclasses.shadowproof import AttributeShadowingError

__all__ = [
    "AttributeShadowingError",
]
