import logging

logger = logging.getLogger("classicist")
