from classicist.metaclasses.aliased import aliased
from classicist.metaclasses.shadowproof import shadowproof

__all__ = [
    "aliased",
    "shadowproof",
]
