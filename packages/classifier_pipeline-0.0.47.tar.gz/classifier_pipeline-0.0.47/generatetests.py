from tests.generatetests import main

main()
