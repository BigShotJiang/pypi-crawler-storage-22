#!/usr/bin/env python

"""
Script to classify animals within a CPTV video file.
"""

from classify.main import main

main()
