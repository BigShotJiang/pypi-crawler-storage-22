from tests.trackingtest import main

main()
