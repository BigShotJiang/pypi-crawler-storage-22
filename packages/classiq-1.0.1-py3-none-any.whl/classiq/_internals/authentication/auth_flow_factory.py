import logging

from classiq._internals.authentication import password_manager as pm
from classiq._internals.authentication.authorization_flow import AuthorizationFlow
from classiq._internals.authentication.hybrid_flow import HybridFlow
from classiq._internals.authentication.machine_credentials_flow import (
    M2MClientCredentialsFlow,
)
from classiq._internals.config import Configuration

_logger = logging.getLogger(__name__)


class AuthFlowFactory:
    """Factory for creating appropriate authorization and authentication flows based on context."""

    @staticmethod
    def create_flow(
        password_manager: pm.PasswordManager, config: Configuration
    ) -> AuthorizationFlow:
        """
        Create an authentication with or without authentication flow based on the password manager type.

        Args:
            password_manager: The password manager instance.
            config: Configuration for authentication.

        Returns:
            Appropriate AuthorizationFlow instance (M2MClientCredentialsFlow or HybridFlow).

        Raises:
            ClassiqAuthenticationError: If M2M token generation failed.
        """
        # M2M authentication flow using client credentials to authenticate with Auth0 and get access token
        if isinstance(password_manager, pm.M2MPasswordManager):
            return M2MClientCredentialsFlow(
                client_id=password_manager.client_id,
                client_secret=password_manager.client_secret,
                organization=password_manager.org_id,
            )

        # Interactive user authentication flow
        return HybridFlow(require_refresh_token=True, text_only=config.text_only)
