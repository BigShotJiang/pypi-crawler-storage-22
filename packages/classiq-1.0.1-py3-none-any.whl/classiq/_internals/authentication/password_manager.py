import abc
import json
import logging
import os
import pathlib
import platform
import stat
from typing import Any

import keyring
from keyring.backends import fail
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

_logger = logging.getLogger(__name__)


class PasswordManagerSettings(BaseSettings):
    ACCESS_TOKEN_KEY: str = Field(
        default="classiqTokenAccount", validation_alias="CLASSIQ_ACCESS_TOKEN_ACCOUNT"
    )
    REFRESH_TOKEN_KEY: str = Field(
        default="classiqRefershTokenAccount",
        validation_alias="CLASSIQ_REFRESH_TOKEN_ACCOUNT",
    )

    model_config = SettingsConfigDict(extra="allow")

    def __init__(self, **data: Any) -> None:
        initial_data = {
            field: data[field] for field in data if field in self.model_fields
        }
        super().__init__(**data)
        for field, value in initial_data.items():
            setattr(self, field, value)


class PasswordManager(abc.ABC):
    _SERVICE_NAME: str = "classiqTokenService"
    text_only_supported: bool = True
    has_refresh_token: bool = True

    def __init__(self) -> None:
        self._settings = PasswordManagerSettings()

    @property
    def access_token(self) -> str | None:
        return self._get(key=self._settings.ACCESS_TOKEN_KEY)

    @access_token.setter
    def access_token(self, access_token: str | None) -> None:
        self._set(key=self._settings.ACCESS_TOKEN_KEY, value=access_token)

    @property
    def refresh_token(self) -> str | None:
        return self._get(key=self._settings.REFRESH_TOKEN_KEY)

    @refresh_token.setter
    def refresh_token(self, refresh_token: str | None) -> None:
        self._set(key=self._settings.REFRESH_TOKEN_KEY, value=refresh_token)

    @abc.abstractmethod
    def _get(self, key: str) -> str | None:
        pass

    @abc.abstractmethod
    def _set(self, key: str, value: str | None) -> None:
        pass

    @abc.abstractmethod
    def _clear(self, key: str) -> None:
        pass

    @staticmethod
    @abc.abstractmethod
    def is_supported() -> bool:
        pass


class KeyringPasswordManager(PasswordManager):
    text_only_supported: bool = False

    def _get(self, key: str) -> str | None:
        return keyring.get_password(service_name=self._SERVICE_NAME, username=key)

    def _set(self, key: str, value: str | None) -> None:
        if value is None:
            self._clear(key)
            return
        keyring.set_password(
            service_name=self._SERVICE_NAME,
            username=key,
            password=value,
        )

    def _clear(self, key: str) -> None:
        keyring.delete_password(
            service_name=self._SERVICE_NAME,
            username=key,
        )

    @staticmethod
    def is_supported() -> bool:
        return not isinstance(keyring.get_keyring(), fail.Keyring)


class DummyPasswordManager(PasswordManager):
    def _get(self, key: str) -> str | None:
        return None

    def _set(self, key: str, value: str | None) -> None:
        return

    def _clear(self, key: str) -> None:
        return

    @staticmethod
    def is_supported() -> bool:
        return True


class FilePasswordManager(PasswordManager):
    _CLASSIQ_CREDENTIALS_FILE_PATH: str = "{}/.classiq-credentials".format(
        os.getenv("CLASSIQ_DIR", os.getenv("HOME"))
    )

    def __init__(self) -> None:
        super().__init__()
        self.credentials_file = pathlib.Path(self._CLASSIQ_CREDENTIALS_FILE_PATH)

    def _update_file(self, token_dict: dict) -> None:
        self.credentials_file.touch()
        self.credentials_file.chmod(stat.S_IRUSR | stat.S_IWUSR)
        self.credentials_file.write_text(json.dumps(token_dict))

    def _get_token_dict(self) -> dict:
        if self.credentials_file.exists():
            return json.loads(self.credentials_file.read_text())
        return {}

    def _get(self, key: str) -> str | None:
        token_dict = self._get_token_dict()
        if key in token_dict:
            return token_dict[key]
        return None

    def _set(self, key: str, value: str | None) -> None:
        token_dict = self._get_token_dict()
        token_dict[key] = value
        self._update_file(token_dict)

    def _clear(self, key: str) -> None:
        token_dict = self._get_token_dict()
        if key in token_dict:
            token_dict.pop(key)
            self._update_file(token_dict)

    @staticmethod
    def is_supported() -> bool:
        return "windows" not in platform.platform().lower()


class M2MPasswordManager(PasswordManager):
    """Password manager for M2M authentication using environment variables.

    Supports machine-to-machine authentication by reading credentials from:
    - CLASSIQ_CLIENT_ID (required)
    - CLASSIQ_CLIENT_SECRET (required)
    - CLASSIQ_ORG_ID (optional)

    This manager stores tokens in memory after M2M authentication.
    """

    has_refresh_token: bool = False

    M2M_CREDS_ENV_KEYS = {
        "client_id": "CLASSIQ_CLIENT_ID",
        "client_secret": "CLASSIQ_CLIENT_SECRET",
        "org_id": "CLASSIQ_ORG_ID",
    }

    M2M_REQUIRED_CREDS = {"client_id", "client_secret"}

    def __init__(self) -> None:
        super().__init__()
        self._token_storage: dict[str, str | None] = {}
        # Initialize all environment variable values
        self._m2m_creds: dict[str, str | None] = {
            key: os.getenv(env_key) for key, env_key in self.M2M_CREDS_ENV_KEYS.items()
        }

    def _get(self, key: str) -> str | None:
        """Get token from in-memory storage."""
        return self._token_storage.get(key)

    def _set(self, key: str, value: str | None) -> None:
        """Store token in memory."""
        if value is None:
            self._clear(key)
            return
        self._token_storage[key] = value

    def _clear(self, key: str) -> None:
        """Clear token from memory storage."""
        self._token_storage.pop(key, None)

    @staticmethod
    def is_supported() -> bool:
        """Check if required M2M environment variables are present."""
        manager = M2MPasswordManager()
        return all(
            manager._m2m_creds.get(key) for key in M2MPasswordManager.M2M_REQUIRED_CREDS
        )

    def _get_required_cred(self, key: str) -> str:
        value = self._m2m_creds.get(key)
        if value is None:
            raise ValueError(
                f"M2M authentication requires {self.M2M_CREDS_ENV_KEYS[key]} environment variable"
            )
        return value

    # to prevent mypy from complaining about the return type
    def _get_optional_cred(self, key: str) -> str | None:
        return self._m2m_creds.get(key)

    @property
    def client_id(self) -> str:
        """Get client ID from initialized credentials."""
        return self._get_required_cred("client_id")

    @property
    def client_secret(self) -> str:
        """Get client secret from initialized credentials."""
        return self._get_required_cred("client_secret")

    @property
    def org_id(self) -> str | None:
        """Get organization ID from initialized credentials (optional)."""
        return self._get_optional_cred("org_id")
