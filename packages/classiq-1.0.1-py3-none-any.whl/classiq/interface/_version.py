from packaging.version import Version

# This file was generated automatically
# Please don't track in version control (DONTTRACK)

SEMVER_VERSION = '1.0.1'
VERSION = str(Version(SEMVER_VERSION))
