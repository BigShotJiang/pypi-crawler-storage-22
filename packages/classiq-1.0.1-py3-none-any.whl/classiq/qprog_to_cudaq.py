import importlib.util
from typing import TYPE_CHECKING, Any

from classiq.interface.exceptions import ClassiqError
from classiq.interface.generator.quantum_program import QuantumProgram
from classiq.interface.helpers.text_utils import readable_list

if TYPE_CHECKING:
    import cudaq
    import openqasm3

_CONVERSION_ERROR_PREFIX = "Cannot convert quantum program to cudaq: "


def _require_cudaq() -> None:
    missing = [m for m in ("cudaq", "openqasm3") if importlib.util.find_spec(m) is None]
    if missing:
        raise ClassiqError(
            "This feature needs the 'cudaq' extra. "
            "Install with: pip install classiq[cudaq] "
            f"(missing: {', '.join(missing)}).\n"
            f"Note: cudaq is only supported on Linux operating systems "
            f"https://nvidia.github.io/cuda-quantum/latest/using/quick_start.html\n"
            f"If you are using a different operating system, consider running on the "
            f"Classiq Studio https://docs.classiq.io/latest/user-guide/studio/Studio-Guide/ "
            f"or a Linux Docker container"
        )


def _get_qasm_ast(quantum_program: QuantumProgram) -> "openqasm3.ast.Program":
    import openqasm3

    if quantum_program.qasm is None:
        raise ClassiqError(_CONVERSION_ERROR_PREFIX + "missing QASM output format")
    try:
        return openqasm3.parser.parse(quantum_program.qasm)
    except Exception as e:
        raise ClassiqError(
            _CONVERSION_ERROR_PREFIX + "the provided QASM is not supported"
        ) from e


def _get_main_kernel(
    qasm_ast: "openqasm3.ast.Program",
) -> tuple["cudaq.PyKernel", dict[str, "cudaq.QuakeValue"]]:
    import cudaq
    import openqasm3

    classical_inputs: list[str] = []
    for statement in qasm_ast.statements:
        if isinstance(statement, openqasm3.ast.IODeclaration):
            if statement.io_identifier != openqasm3.ast.IOKeyword.input:
                raise ClassiqError(
                    _CONVERSION_ERROR_PREFIX + "classical outputs are not supported"
                )
            if not isinstance(statement.type, openqasm3.ast.FloatType):
                raise ClassiqError(
                    _CONVERSION_ERROR_PREFIX
                    + "only float classical inputs are supported"
                )
            classical_inputs.append(statement.identifier.name)

    if len(classical_inputs) == 0:
        return cudaq.make_kernel(), {}
    kernel_and_params = cudaq.make_kernel(*((float,) * len(classical_inputs)))
    kernel = kernel_and_params[0]
    params = dict(zip(classical_inputs, kernel_and_params[1:], strict=True))
    return kernel, params


def qprog_to_cudaq_kernel(quantum_program: QuantumProgram) -> "cudaq.PyKernel":
    _require_cudaq()

    qasm_ast = _get_qasm_ast(quantum_program)
    kernel, params = _get_main_kernel(qasm_ast)
    gates: dict[str, "cudaq.PyKernel"] = {}
    qubits: dict[str, "cudaq.QuakeValue"] = {}

    for statement in qasm_ast.statements:
        _process_main_statement(kernel, gates, qubits, params, statement)
    return kernel


def _process_main_statement(
    kernel: "cudaq.PyKernel",
    gates: dict[str, "cudaq.PyKernel"],
    qubits: dict[str, "cudaq.QuakeValue"],
    params: dict[str, "cudaq.QuakeValue"],
    statement: "openqasm3.ast.Statement | openqasm3.ast.Pragma",
) -> None:
    import cudaq
    import openqasm3

    if isinstance(statement, (openqasm3.ast.Include, openqasm3.ast.IODeclaration)):
        pass
    elif isinstance(
        statement,
        (
            openqasm3.ast.ClassicalDeclaration,
            openqasm3.ast.BranchingStatement,
            openqasm3.ast.QuantumMeasurementStatement,
        ),
    ):
        raise ClassiqError(
            _CONVERSION_ERROR_PREFIX + "mid-circuit measurements are not supported"
        )
    elif isinstance(statement, openqasm3.ast.QuantumReset):
        raise ClassiqError(
            _CONVERSION_ERROR_PREFIX + "reset instructions are not supported"
        )
    elif isinstance(statement, openqasm3.ast.QubitDeclaration):
        if statement.size is None:
            raise ClassiqError(
                _CONVERSION_ERROR_PREFIX
                + f"qubit declaration {statement.qubit.name!r} has no size"
            )
        if not isinstance(statement.size, openqasm3.ast.IntegerLiteral):
            raise ClassiqError(
                _CONVERSION_ERROR_PREFIX
                + f"the size of qubit declaration {statement.qubit.name!r} must be an integer literal"
            )
        qubits[statement.qubit.name] = kernel.qalloc(statement.size.value)
    elif isinstance(statement, openqasm3.ast.QuantumGateDefinition):
        angle_names = [param.name for param in statement.arguments]
        qubit_names = [param.name for param in statement.qubits]
        kernel_and_params = cudaq.make_kernel(
            *((float,) * len(angle_names)), *((cudaq.qubit,) * len(qubit_names))
        )
        func_kernel = kernel_and_params[0]
        func_params = dict(
            zip(angle_names, kernel_and_params[1 : len(angle_names) + 1], strict=True)
        )
        func_qubits = dict(
            zip(qubit_names, kernel_and_params[len(angle_names) + 1 :], strict=True)
        )
        for gate_statement in statement.body:
            _process_statement(
                func_kernel, gates, func_qubits, func_params, gate_statement
            )
        gates[statement.name.name] = func_kernel
    else:
        _process_statement(kernel, gates, qubits, params, statement)


def _eval_expr(
    params: dict[str, "cudaq.QuakeValue"], expr: "openqasm3.ast.Expression"
) -> Any:
    import openqasm3

    if isinstance(expr, openqasm3.ast.Identifier):
        if expr.name not in params:
            raise ClassiqError(
                _CONVERSION_ERROR_PREFIX + f"name {expr.name!r} is not defined"
            )
        return params[expr.name]
    if isinstance(expr, openqasm3.ast.UnaryExpression):
        target = _eval_expr(params, expr.expression)
        if expr.op == openqasm3.ast.UnaryOperator["~"]:
            return ~target
        if expr.op == openqasm3.ast.UnaryOperator["-"]:
            return -target
        raise ClassiqError(
            _CONVERSION_ERROR_PREFIX + f"operation {str(expr.op)!r} is not supported"
        )
    if isinstance(expr, openqasm3.ast.BinaryExpression):
        left = _eval_expr(params, expr.lhs)
        right = _eval_expr(params, expr.rhs)
        if expr.op == openqasm3.ast.BinaryOperator["|"]:
            return left | right
        if expr.op == openqasm3.ast.BinaryOperator["&"]:
            return left & right
        if expr.op == openqasm3.ast.BinaryOperator["<<"]:
            return left << right
        if expr.op == openqasm3.ast.BinaryOperator[">>"]:
            return left >> right
        if expr.op == openqasm3.ast.BinaryOperator["+"]:
            return left + right
        if expr.op == openqasm3.ast.BinaryOperator["-"]:
            return left - right
        if expr.op == openqasm3.ast.BinaryOperator["*"]:
            return left * right
        if expr.op == openqasm3.ast.BinaryOperator["/"]:
            return left / right
        raise ClassiqError(
            _CONVERSION_ERROR_PREFIX + f"operation {str(expr.op)!r} is not supported"
        )
    if isinstance(
        expr,
        (
            openqasm3.ast.IntegerLiteral,
            openqasm3.ast.FloatLiteral,
            openqasm3.ast.ImaginaryLiteral,
            openqasm3.ast.BooleanLiteral,
        ),
    ):
        return expr.value
    raise ClassiqError(
        _CONVERSION_ERROR_PREFIX
        + f"expression type {type(expr).__name__!r} is not supported"
    )


def _eval_var(
    qubits: dict[str, "cudaq.QuakeValue"],
    expr: "openqasm3.ast.IndexedIdentifier | openqasm3.ast.Identifier",
) -> "cudaq.QuakeValue":
    import openqasm3

    if isinstance(expr, openqasm3.ast.Identifier):
        if expr.name not in qubits:
            raise ClassiqError(
                _CONVERSION_ERROR_PREFIX + f"name {expr.name!r} is not defined"
            )
        return qubits[expr.name]
    if isinstance(expr, openqasm3.ast.IndexedIdentifier):
        if expr.name.name not in qubits:
            raise ClassiqError(
                _CONVERSION_ERROR_PREFIX + f"name {expr.name.name!r} is not defined"
            )
        if (
            len(expr.indices) != 1
            or not isinstance(accessor := expr.indices[0], list)
            or len(accessor) != 1
            or not isinstance(index := accessor[0], openqasm3.ast.IntegerLiteral)
        ):
            raise ClassiqError(
                _CONVERSION_ERROR_PREFIX
                + "only simple subscript expressions are supported (for example, q[0])"
            )
        return qubits[expr.name.name][index.value]
    raise ClassiqError(
        _CONVERSION_ERROR_PREFIX
        + f"expression type {type(expr).__name__!r} is not supported"
    )


def _get_expr_vars(
    params: dict[str, "cudaq.QuakeValue"], expr: "openqasm3.ast.Expression"
) -> set[str]:
    import openqasm3

    if isinstance(expr, openqasm3.ast.Identifier):
        if expr.name not in params:
            raise ClassiqError(
                _CONVERSION_ERROR_PREFIX + f"name {expr.name!r} is not defined"
            )
        return {expr.name}
    if isinstance(expr, openqasm3.ast.UnaryExpression):
        return _get_expr_vars(params, expr.expression)
    if isinstance(expr, openqasm3.ast.BinaryExpression):
        return _get_expr_vars(params, expr.lhs) | _get_expr_vars(params, expr.rhs)
    if isinstance(
        expr,
        (
            openqasm3.ast.IntegerLiteral,
            openqasm3.ast.FloatLiteral,
            openqasm3.ast.ImaginaryLiteral,
            openqasm3.ast.BooleanLiteral,
        ),
    ):
        return set()
    raise ClassiqError(
        _CONVERSION_ERROR_PREFIX
        + f"expression type {type(expr).__name__!r} is not supported"
    )


def _eval_single_var(
    params: dict[str, "cudaq.QuakeValue"], expr: "openqasm3.ast.Expression"
) -> "cudaq.QuakeValue":
    expr_vars = _get_expr_vars(params, expr)
    if len(expr_vars) != 1:
        if len(expr_vars) == 0:
            suffix = "got none"
        else:
            suffix = f"got {readable_list(list(expr_vars), quote=True)}"
        raise ClassiqError(
            _CONVERSION_ERROR_PREFIX
            + f"gate argument must contain exactly one angle variable, {suffix}"
        )
    return params[list(expr_vars)[0]]


def _process_statement(
    kernel: "cudaq.PyKernel",
    gates: dict[str, "cudaq.PyKernel"],
    qubits: dict[str, "cudaq.QuakeValue"],
    params: dict[str, "cudaq.QuakeValue"],
    statement: "openqasm3.ast.Statement | openqasm3.ast.Pragma",
) -> None:
    import openqasm3

    if isinstance(statement, openqasm3.ast.QuantumGate):
        if len(statement.modifiers) != 0:
            raise ClassiqError(
                _CONVERSION_ERROR_PREFIX + "gate modifiers are not supported"
            )
        if statement.duration:
            raise ClassiqError(
                _CONVERSION_ERROR_PREFIX + "gate duration is not supported"
            )
        qubit_args = [_eval_var(qubits, var) for var in statement.qubits]
        gate_name = statement.name.name
        if gate_name in gates:
            angle_args = [
                _eval_single_var(params, angle_expr)
                for angle_expr in statement.arguments
            ]
            kernel.apply_call(gates[gate_name], *angle_args, *qubit_args)
        elif gate_name in {"i", "id"}:
            pass
        elif gate_name in {
            "x",
            "y",
            "z",
            "h",
            "s",
            "t",
            "sdg",
            "tdg",
            "rx",
            "ry",
            "rz",
            "u3",
            "cx",
            "cy",
            "cz",
            "ch",
            "cs",
            "ct",
            "crx",
            "cry",
            "crz",
        }:
            angle_args = [
                _eval_expr(params, angle_expr) for angle_expr in statement.arguments
            ]
            getattr(kernel, gate_name)(*angle_args, *qubit_args)
        else:
            raise ClassiqError(
                _CONVERSION_ERROR_PREFIX + f"gate {gate_name!r} is not defined"
            )
    else:
        raise ClassiqError(
            _CONVERSION_ERROR_PREFIX
            + f"QASM statement {type(statement).__name__} is not supported"
        )
