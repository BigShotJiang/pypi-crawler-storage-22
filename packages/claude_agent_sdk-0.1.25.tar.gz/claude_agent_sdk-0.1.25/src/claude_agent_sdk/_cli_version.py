"""Bundled Claude Code CLI version."""

__cli_version__ = "2.1.23"
