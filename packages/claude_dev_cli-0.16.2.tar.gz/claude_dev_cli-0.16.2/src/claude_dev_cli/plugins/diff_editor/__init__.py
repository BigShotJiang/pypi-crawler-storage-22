"""Interactive diff editor plugin for reviewing AI-generated code changes."""

__version__ = "0.1.0"
