# Claude Launcher

Fast project switching for Claude Code. Select from your projects with fuzzy search and jump right in.

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PyPI](https://img.shields.io/pypi/v/claude-launcher)](https://pypi.org/project/claude-launcher/)

> **Community Project** - Independent tool, not affiliated with Anthropic.

## Install

**One command:**
```bash
curl -sSL https://raw.githubusercontent.com/solentlabs/claude-launcher/master/install.sh | bash
```

**Or with pipx:**
```bash
pipx install claude-launcher
```

## Use

```bash
claude-launcher ~/projects
```

That's it. Pick a project, Claude Code opens.

## Features

- 🔍 **Fuzzy search** - Type to filter projects instantly
- 📁 **Tree navigation** - See your project structure at a glance
- 📋 **Preview pane** - Git status, CLAUDE.md, directory contents
- ⚡ **Last opened** - Cursor starts on your most recent project
- ➕ **Manual projects** - Add non-git directories
- 🔗 **Symlink support** - Works with linked directories

## Requirements

- Python 3.8+
- fzf (install script handles this)
- Claude Code CLI

## Configuration

First run creates `~/.config/claude-launcher/config.toml`:

```toml
[scan]
paths = ["~/projects", "~/work"]
max_depth = 5
```

[Full configuration docs →](docs/configuration.md)

## Documentation

- [Installation Guide](docs/installation.md)
- [Configuration](docs/configuration.md)
- [Windows Terminal Setup](docs/windows-terminal.md)
- [Troubleshooting](docs/troubleshooting.md)

## License

MIT - see [LICENSE](LICENSE)
