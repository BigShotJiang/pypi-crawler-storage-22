"""Entry point for python -m claude_launcher."""

from claude_launcher.cli import app

if __name__ == "__main__":
    app()
