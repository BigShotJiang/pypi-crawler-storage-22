"""Claude Memory Kit (CMK). Persistent memory for Claude. Embedded, zero-server."""

__version__ = "0.1.3"
