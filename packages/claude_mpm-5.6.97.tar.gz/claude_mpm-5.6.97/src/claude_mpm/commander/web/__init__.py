"""Web UI module for MPM Commander."""
