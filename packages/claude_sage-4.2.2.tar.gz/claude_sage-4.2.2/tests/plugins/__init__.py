"""Plugin system tests."""
