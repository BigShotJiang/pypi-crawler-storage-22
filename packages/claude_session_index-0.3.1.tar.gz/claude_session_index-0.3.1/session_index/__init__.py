"""Claude session index — search, analyze, and synthesize across Claude Code sessions."""

__version__ = "0.3.0"
