"""Claudemon TUI widgets."""
