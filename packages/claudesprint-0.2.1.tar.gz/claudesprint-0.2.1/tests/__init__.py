"""Tests for ClaudeSprint."""
