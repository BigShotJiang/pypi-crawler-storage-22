"""Allow running as `python -m claudette`."""

from .assistant import main

if __name__ == "__main__":
    main()
