"""Claude Code process management."""

import asyncio
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional


class ExecutionError(Exception):
    """Raised when Claude Code execution fails."""

    pass


@dataclass
class ExecutionResult:
    """Result of a command execution."""

    output: str
    exit_code: int
    duration_seconds: float = 0.0
    error_output: str = ""
    timed_out: bool = False


class Executor:
    """Manages Claude Code process execution."""

    def __init__(
        self,
        claude_flags: str = "",
        passthrough: bool = False,
        timeout_seconds: int = 0,
    ) -> None:
        """Initialize executor.

        Args:
            claude_flags: Extra flags to pass to claude (e.g., "--resume abc123").
            passthrough: If True, stream output directly instead of capturing.
            timeout_seconds: Max seconds before killing the process (0 = no timeout).
        """
        self.claude_flags = claude_flags
        self.passthrough = passthrough
        self.timeout_seconds = timeout_seconds

    async def run(
        self,
        prompt: str,
        log_file: Optional[Path] = None,
        on_output: Optional[Callable[[str], None]] = None,
    ) -> ExecutionResult:
        """Execute a prompt in Claude Code.

        Args:
            prompt: The prompt to send to Claude Code.
            log_file: Optional path to write output to.
            on_output: Optional callback for each line of output (for passthrough).

        Returns:
            ExecutionResult with output and exit code.
        """
        import time

        start_time = time.time()

        # Build command arguments
        args = self._build_args(prompt)

        try:
            process = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
        except FileNotFoundError:
            raise ExecutionError(
                "Claude Code not found. Please ensure 'claude' is installed and in PATH."
            )
        except PermissionError:
            raise ExecutionError("Permission denied when running Claude Code.")

        # Collect output
        output_lines: list[str] = []
        error_lines: list[str] = []

        # Open log file if specified
        log_handle = None
        if log_file:
            log_handle = open(log_file, "w")

        timed_out = False
        try:
            coro = self._read_output(process, output_lines, error_lines, log_handle, on_output)
            if self.timeout_seconds > 0:
                try:
                    await asyncio.wait_for(coro, timeout=self.timeout_seconds)
                except asyncio.TimeoutError:
                    timed_out = True
                    process.kill()
                    await process.wait()
            else:
                await coro

        finally:
            if log_handle:
                if timed_out:
                    log_handle.write("[claun] Job timed out and was killed\n")
                log_handle.close()

        duration = time.time() - start_time
        output = "".join(output_lines)
        error_output = "".join(error_lines)

        return ExecutionResult(
            output=output,
            exit_code=process.returncode or 0,
            duration_seconds=duration,
            error_output=error_output,
            timed_out=timed_out,
        )

    async def _read_output(
        self,
        process: asyncio.subprocess.Process,
        output_lines: list[str],
        error_lines: list[str],
        log_handle: Optional[object],
        on_output: Optional[Callable[[str], None]],
    ) -> None:
        """Read stdout and stderr from the process until it exits."""
        # Read stdout
        while True:
            assert process.stdout is not None
            line_bytes = await process.stdout.readline()
            if not line_bytes:
                break
            line = line_bytes.decode("utf-8", errors="replace")
            output_lines.append(line)

            if self.passthrough and on_output:
                on_output(line.rstrip("\n"))

            if log_handle:
                log_handle.write(line)  # type: ignore[union-attr]
                log_handle.flush()  # type: ignore[union-attr]

        # Read stderr
        while True:
            assert process.stderr is not None
            line_bytes = await process.stderr.readline()
            if not line_bytes:
                break
            line = line_bytes.decode("utf-8", errors="replace")
            error_lines.append(line)

            if log_handle:
                log_handle.write(f"[stderr] {line}")  # type: ignore[union-attr]
                log_handle.flush()  # type: ignore[union-attr]

        await process.wait()

    def _build_args(self, prompt: str) -> list[str]:
        """Build command line arguments for claude."""
        args = ["claude"]

        # Add any extra flags the user specified first
        if self.claude_flags:
            extra_flags = shlex.split(self.claude_flags)
            args.extend(extra_flags)

        # Always put --print and the prompt last (prevents variadic flags
        # like --allowedTools from consuming the prompt)
        args.append("--print")
        args.append(prompt)

        return args
