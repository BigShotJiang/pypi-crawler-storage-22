"""Tests for claun."""
