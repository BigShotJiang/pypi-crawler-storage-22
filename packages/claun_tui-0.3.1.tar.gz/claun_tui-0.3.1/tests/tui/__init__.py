"""TUI tests for claun."""
