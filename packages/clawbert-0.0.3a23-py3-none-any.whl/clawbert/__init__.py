"""ClawbertCLI - CLI Package for Clawbert AI Assistant.

This package contains the command-line interface components of Clawbert,
including core functionality, tools, memory, skills, and services.
"""

__version__ = "0.0.3-alpha-23"
__author__ = "Clawbert Team"

from .core import config
from .tools import tool_registry
from .skills import skill_registry
from .memory import MemorySystem
from .session import session_manager

__all__ = [
    "config",
    "tool_registry",
    "skill_registry",
    "MemorySystem",
    "session_manager",
]
