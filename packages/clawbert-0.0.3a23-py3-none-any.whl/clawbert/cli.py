"""Command-line interface for Clawbert.

This module provides the CLI entry point with subcommands for:
- config: Configure API key, tools, and view settings
- session: Manage chat sessions (create, list, switch, delete)
- memory: Store and retrieve persistent memories
- skill: Manage AI skills and auto-selection
- chat: Interactive chat or single-prompt mode

The chat loop supports:
- Natural language input
- Tool calling (read, write, web_search, etc.)
- Skill auto-selection based on context
- Session persistence across commands
- Special commands (quit, exit, help, skills, memory, session, clear)

Example:
    # Set API key
    clawbert config --api-key YOUR_KEY

    # Interactive chat
    clawbert chat

    # Single prompt
    clawbert chat "list files in current directory"

    # Manage sessions
    clawbert session --list
    clawbert session --create "My Project"

    # Manage memory
    clawbert memory --store api_key=12345
    clawbert memory --search api

    # Manage skills
    clawbert skill --list
    clawbert skill --set weather
"""

import argparse
import json
import time
from pathlib import Path
from prompt_toolkit import prompt
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.styles import Style
from .core.config import config, VALID_PROVIDERS, DEFAULT_MODELS
from .core.llm import LLMClient
from .tools import tool_registry
from .skills import skill_registry
from .memory import MemorySystem
from .session import session_manager
from .ui.console import (
    console,
    print_banner,
    print_welcome,
    print_skills_table,
    print_tools_table,
    print_session_info,
    print_thinking,
    print_tool_call,
    print_tool_result,
    print_response,
    print_response_streaming,
    print_error,
    print_success,
    print_info,
    print_help,
    print_memory_results,
    print_goodbye,
    print_created_session,
    print_memory_entry,
    Text,
)

from .utils.completions import get_completion_script
from .utils.wizard import add_wizard_parser
from .services.plugins import plugin_manager
from .services.telemetry import usage_tracker, telemetry_sender, init_telemetry


def cmd_completions(args):
    """Handle completions subcommand - output shell completion script."""
    try:
        script = get_completion_script(args.shell)
        print(script)
        print()
        print("# To install, add to your shell config:")
        print(
            "# "
            + f"clawbert completions --shell {args.shell} >> ~/.shellrc".replace(
                "~/.shellrc", "~/.bashrc" if args.shell == "bash" else "~/.zshrc"
            )
        )
    except ValueError as e:
        print_error(str(e))


def cmd_api(args):
    """Handle api subcommand - start REST API server."""
    from .services.api import run_server

    print_info(f"Starting API server on {args.host}:{args.port}")
    if args.api_key:
        print_info("API key authentication enabled")

    run_server(
        host=args.host,
        port=args.port,
        api_key=args.api_key,
        cors_origins=args.cors.split(",") if args.cors else None,
    )


def cmd_mcp(args):
    """Handle mcp subcommand - start MCP server mode."""
    from .services.mcp import MCPServer

    print_info(f"Starting MCP server on {args.host}:{args.port}")
    print_info("Exposing Clawbert tools via MCP protocol")

    server = MCPServer(name="clawbert", version="0.0.3-alpha-23")

    for tool in tool_registry.tools.values():
        server.add_tool(tool.name, tool.description, tool.parameters)
        print_info(f"  - Exposed tool: {tool.name}")

    if args.transport == "stdio":
        print_info("Running in stdio mode...")
        server.run_stdio()
    else:
        print_info(f"Running in HTTP mode on {args.host}:{args.port}")
        server.run_http(host=args.host, port=args.port)


def cmd_config(args):
    """Handle config subcommand.

    Args:
        args: Parsed command-line arguments.
    """
    if args.provider:
        if args.provider not in VALID_PROVIDERS:
            print_error(
                f"Invalid provider. Valid options: {', '.join(VALID_PROVIDERS)}"
            )
            return
        config.model_provider = args.provider
        config.default_model = DEFAULT_MODELS.get(args.provider, "")
        config.save()
        console.print()
        console.print(
            Text("  ◆ ", style="bold cyan")
            + Text(f"Provider set to: {args.provider}", style="bold white")
        )
        console.print(
            Text("    Default model: ", style="cyan")
            + Text(config.default_model, style="white")
        )
        console.print()

    if args.api_key:
        if config.model_provider == "openrouter":
            config.openrouter_api_key = args.api_key
        elif config.model_provider == "openai":
            config.openai_api_key = args.api_key
        elif config.model_provider == "anthropic":
            config.anthropic_api_key = args.api_key
        elif config.model_provider == "groq":
            config.groq_api_key = args.api_key
        elif config.model_provider == "mistral":
            config.mistral_api_key = args.api_key
        elif config.model_provider == "gemini":
            config.gemini_api_key = args.api_key
        elif config.model_provider == "zai":
            config.zai_api_key = args.api_key
        config.save()
        console.print()
        console.print(
            Text("  ◆ ", style="bold cyan") + Text("API key saved", style="bold white")
        )
        console.print(
            Text("    Provider: ", style="cyan")
            + Text(config.model_provider, style="white")
        )
        console.print(
            Text("    Model: ", style="cyan")
            + Text(config.default_model, style="white")
        )
        console.print(
            Text("    Tools: ", style="cyan")
            + Text(", ".join(config.enabled_tools), style="yellow")
        )
        console.print()

    if args.model:
        config.default_model = args.model
        config.save()
        console.print()
        console.print(
            Text("  ◆ ", style="bold cyan") + Text("Model updated", style="bold white")
        )
        console.print(
            Text("    Model: ", style="cyan")
            + Text(config.default_model, style="white")
        )
        console.print()

    if args.base_url:
        if config.model_provider == "openrouter":
            config.openrouter_base_url = args.base_url
        elif config.model_provider == "openai":
            config.openai_base_url = args.base_url
        elif config.model_provider == "anthropic":
            config.anthropic_base_url = args.base_url
        elif config.model_provider == "ollama":
            config.ollama_base_url = args.base_url
        elif config.model_provider == "groq":
            config.groq_base_url = args.base_url
        elif config.model_provider == "mistral":
            config.mistral_base_url = args.base_url
        elif config.model_provider == "gemini":
            config.gemini_base_url = args.base_url
        elif config.model_provider == "zai":
            config.zai_base_url = args.base_url
        elif config.model_provider == "lmstudio":
            config.lmstudio_base_url = args.base_url
        config.save()
        console.print()
        console.print(
            Text("  ◆ ", style="bold cyan")
            + Text("Base URL updated", style="bold white")
        )
        console.print(
            Text("    URL: ", style="cyan") + Text(args.base_url, style="white")
        )
        console.print()

    if args.list_providers:
        console.print()
        console.print(Text("  Available Providers:", style="bold cyan"))
        for p in VALID_PROVIDERS:
            current = " (current)" if p == config.model_provider else ""
            console.print(f"    {p}{current}")
        console.print()
        console.print(Text("  Default Models:", style="bold cyan"))
        for p, m in DEFAULT_MODELS.items():
            console.print(f"    {p}: {m}")
        console.print()

    if args.list_models:
        from .core.providers import get_provider

        console.print()
        provider = get_provider(config.model_provider, config)
        models = provider.get_available_models()

        if models:
            console.print(
                Text(
                    f"  Available Models for {config.model_provider}:",
                    style="bold cyan",
                )
            )
            for m in models[:20]:
                marker = " ◆" if m == config.default_model else ""
                console.print(f"    {m}{marker}")
            if len(models) > 20:
                console.print(f"    ... and {len(models) - 20} more")
        else:
            console.print(
                Text(
                    f"  Could not fetch models for {config.model_provider}.",
                    style="yellow",
                )
            )
            console.print(
                Text("  Make sure API key is set: ", style="cyan")
                + Text(
                    f"clawbert config --provider {config.model_provider} --api-key YOUR_KEY",
                    style="white",
                )
            )
        console.print()

    if args.list_tools:
        if args.quiet:
            for tool in tool_registry.tools.values():
                print(tool.name)
        else:
            print_tools_table(tool_registry.tools, config.enabled_tools)

    if args.list_skills:
        print_skills_table(skill_registry.skills)


def cmd_session(args):
    """Handle session subcommand.

    Args:
        args: Parsed command-line arguments.
    """
    if args.list:
        sessions = session_manager.list_sessions()
        if not sessions:
            print_info("No sessions found")
            return
        for s in sessions:
            console.print(f"  {s['id']}: {s['name']} ({s['message_count']} messages)")

    elif args.create:
        session = session_manager.create(args.create or None)
        print_created_session(session.id)

    elif args.switch:
        if session_manager.set_current(args.switch):
            print_success(f"Switched to session: {args.switch}")
        else:
            print_error(f"Session not found: {args.switch}")

    elif args.delete:
        if session_manager.delete(args.delete):
            print_success(f"Deleted session: {args.delete}")
        else:
            print_error(f"Session not found: {args.delete}")

    else:
        current = session_manager.get_current()
        if current:
            print_session_info(current)
        else:
            print_info(
                "No active session. Use 'clawbert session --create' to start one."
            )


def cmd_memory(args):
    """Handle memory subcommand.

    Args:
        args: Parsed command-line arguments.
    """
    mem = MemorySystem()

    if args.search:
        results = mem.search(args.search)
        print_memory_results(results)

    elif args.list:
        all_mem = mem.list_all()
        if not all_mem:
            print_info("No memories stored")
        for m in all_mem:
            console.print(f"  {m['key']}: {m['content'][:50]}...")

    elif args.get:
        content = mem.get(args.get)
        if content:
            print_memory_entry(args.get, content)
        else:
            print_error(f"Memory not found: {args.get}")

    elif args.store:
        key, _, value = args.store.partition("=")
        if key and value:
            mem.store(key, value)
            print_success(f"Stored: {key}")
        else:
            print_info("Usage: --store key=value")

    elif args.delete:
        if mem.delete(args.delete):
            print_success(f"Deleted: {args.delete}")
        else:
            print_error(f"Memory not found: {args.delete}")

    elif args.clear:
        mem.clear()
        print_success("All memories cleared")


def cmd_chat(args):
    """Handle chat subcommand - interactive chat loop.

    Args:
        args: Parsed command-line arguments.
    """
    api_key = config.get_provider_api_key()
    if not api_key and config.model_provider != "ollama":
        print_error("API key not configured.")
        console.print(
            Text("  Run: ", style="cyan")
            + Text(
                f"clawbert config --provider {config.model_provider} --api-key YOUR_KEY",
                style="bold white",
            )
        )
        console.print()
        if config.model_provider == "openrouter":
            print_info("Get a free key at https://openrouter.ai")
        elif config.model_provider == "openai":
            print_info("Get a key at https://platform.openai.com")
        elif config.model_provider == "anthropic":
            print_info("Get a key at https://www.anthropic.com")
        return

    session = session_manager.get_current()
    if not session:
        session = session_manager.create("CLI Chat")
        print_created_session(session.id)

    skill_context = skill_registry.get_skill_descriptions()

    llm = LLMClient()
    memory = MemorySystem()
    memory_context = memory.get_memory_for_prompt()

    def build_system_prompt():
        """Build system prompt based on current active skill."""
        active_skill = skill_registry.get(session.active_skill)
        skill_instructions = active_skill.instructions if active_skill else ""

        return f"""You are Clawbert, a CLI AI assistant.

## CURRENT DATE: February 2026
Always search for the MOST UP-TO-DATE information. When using web_search, include "2026" in your search query to get the latest results.

{memory_context}

## ACTIVE SKILL: {session.active_skill.upper()}
{skill_instructions}

## AVAILABLE SKILLS
Use any of these skills automatically when the task matches their description:

{skill_context}

## AVAILABLE TOOLS
{", ".join(config.enabled_tools)}

Tool descriptions:
- read: Read file contents (only for files, not directories)
- write: Write content to file  
- web_search: Search the web (ALWAYS include "2026" in query for latest info)
- web_fetch: Fetch URL content (BEST for APIs like OpenMeteo - use this for weather data)
- memory_search: Search memory
- memory_store: Store in memory
- list_skills: List all available skills
- create_skill: Create a new skill (params: name, description, instructions, tools_required)
- reload_skills: Hot-reload skills after creating new ones
- list_directory: List contents of a directory (use this for dirs, NOT read)

## HOW SKILLS WORK
Skills are specialized capabilities that activate based on the user's request. When a task matches a skill's description, use that skill's specific tools and instructions.

Remember to use tools when appropriate. Be concise and helpful."""

    def build_messages():
        """Build message list with system prompt and history.

        Returns:
            List of message dicts for LLM API.
        """
        msgs = [{"role": "system", "content": build_system_prompt()}]
        msgs.extend(session_manager.get_messages(session.id))
        return msgs

    def handle_tool_calls(msg, messages, current_tools, depth=0):
        """Handle tool calls from LLM response.

        Args:
            msg: The message object from LLM.
            messages: Current message list.
            current_tools: Available tools for follow-up calls.
            depth: Recursion depth counter.

        Returns:
            Tuple of (final response, updated messages).
        """
        if depth > 20:
            return "Too many tool calls (max 100).", messages

        if not msg.get("tool_calls"):
            return msg.get("content", ""), messages

        # Execute tool calls and get results
        for tool_call in msg["tool_calls"]:
            func_name = tool_call["function"]["name"]
            func_args = tool_call["function"]["arguments"]

            if isinstance(func_args, str):
                import json

                func_args = json.loads(func_args)

            tool = tool_registry.get_tool(func_name)
            if tool:
                print_tool_call(func_name, func_args)
                start_time = time.time()
                success = True
                try:
                    result = tool.func(**func_args)
                except Exception as e:
                    result = f"Error: {str(e)}"
                    success = False
                    if config.usage_tracking_enabled:
                        usage_tracker.track_error("tool_error", str(e), func_name)
                duration = time.time() - start_time
                if config.usage_tracking_enabled:
                    usage_tracker.track_tool(func_name, duration, success)
                print_tool_result(result)

                messages.append(
                    {"role": "assistant", "content": None, "tool_calls": [tool_call]}
                )
                messages.append(
                    {"role": "tool", "tool_call_id": tool_call["id"], "content": result}
                )

        # Continue with tools available for any follow-up calls
        result = llm.chat_with_tools(messages, current_tools)
        if "error" in result:
            return result["error"], messages
        msg = result.get("choices", [{}])[0].get("message", {})

        # Handle any follow-up tool calls recursively
        if msg.get("tool_calls"):
            return handle_tool_calls(msg, messages, current_tools, depth + 1)

        return msg.get("content", ""), messages

    if args.prompt:
        messages = build_messages()
        messages.append({"role": "user", "content": args.prompt})

        # Build available tools based on current skill
        active_skill = skill_registry.get(session.active_skill)
        skill_tools = active_skill.allowed_tools if active_skill else []
        prompt_tools = [
            t
            for t in tool_registry.get_available_tools()
            if t["function"]["name"] in config.enabled_tools
            and (not skill_tools or t["function"]["name"] in skill_tools)
        ]

        if prompt_tools:
            result = llm.chat_with_tools(messages, prompt_tools)
            if "error" in result:
                print_error(result["error"])
                return
            msg = result.get("choices", [{}])[0].get("message", {})
            response, messages = handle_tool_calls(msg, messages, prompt_tools)
        else:
            response = llm.chat(messages)

        print_response(response)
        session_manager.add_message(session.id, "user", args.prompt)
        session_manager.add_message(session.id, "assistant", response)
        return

    console.clear()
    print_banner()
    print_welcome()

    def get_completer():
        """Create completer with nested / commands that updates dynamically."""

        class DynamicCompleter(Completer):
            def get_completions(self, document, complete_event):
                text = document.text_before_cursor

                if not text.startswith("/"):
                    return

                parts = text[1:].split()

                if len(parts) == 0:
                    commands = [
                        "/help",
                        "/skills",
                        "/skill",
                        "/memory",
                        "/session",
                        "/clear",
                        "/quit",
                        "/exit",
                    ]
                    for cmd in commands:
                        yield Completion(cmd, start_position=0)
                elif len(parts) == 1:
                    prefix = parts[0].lower()
                    commands = [
                        "help",
                        "skills",
                        "skill",
                        "memory",
                        "session",
                        "clear",
                        "quit",
                        "exit",
                    ]
                    for cmd in commands:
                        if cmd.startswith(prefix):
                            yield Completion("/" + cmd, start_position=0)
                elif len(parts) == 2 and parts[0].lower() == "skill":
                    prefix = parts[1].lower()
                    for skill_name in skill_registry.skills.keys():
                        if skill_name.startswith(prefix):
                            yield Completion(
                                f"/skill {skill_name}", start_position=-len(parts[1])
                            )

        return DynamicCompleter()

    prompt_style = Style.from_dict(
        {
            "prompt": "cyan bold",
        }
    )

    while True:
        try:
            user_input = prompt(
                "\n❯ ",
                completer=get_completer(),
                complete_while_typing=True,
                style=prompt_style,
            ).strip()
        except KeyboardInterrupt:
            print_goodbye()
            break
        except EOFError:
            print_goodbye()
            break

        if not user_input:
            continue

        if user_input.startswith("/"):
            cmd = user_input[1:].split()
            if cmd and cmd[0] == "help":
                print_help()
                continue
            elif cmd and cmd[0] == "skills":
                print_skills_table(skill_registry.skills)
                continue
            elif cmd and cmd[0] == "skill" and len(cmd) > 1:
                session.active_skill = cmd[1]
                print_success(f"Switched to skill: {cmd[1]}")
                continue
            elif cmd and cmd[0] == "memory" and len(cmd) > 1:
                mem = MemorySystem()
                results = mem.search(" ".join(cmd[1:]))
                print_memory_results(results)
                continue
            elif cmd and cmd[0] == "session":
                print_session_info(session)
                continue
            elif cmd and cmd[0] == "clear":
                session.messages = []
                print_success("Conversation cleared")
                continue
            elif cmd and cmd[0] == "quit" or (cmd and cmd[0] == "exit"):
                print_goodbye()
                break

        # Auto-select skill based on keywords
        user_lower = user_input.lower()
        prev_skill = session.active_skill
        if "weather" in user_lower or "temperature" in user_lower:
            if "weather" in skill_registry.skills:
                session.active_skill = "weather"
        elif any(
            x in user_lower for x in ["build", "create app", "flask", "pyside", "react"]
        ):
            for skill_name in skill_registry.skills:
                if any(x in skill_name for x in ["flask", "pyside6", "react", "app"]):
                    session.active_skill = skill_name
                    break

        if session.active_skill != prev_skill:
            print_info(f"Auto-selected skill: {session.active_skill}")

        messages = build_messages()
        messages.append({"role": "user", "content": user_input})

        # Use animated thinking spinner
        thinking = print_thinking()
        thinking.start()

        # Rebuild available_tools based on current skill (after auto-selection)
        active_skill = skill_registry.get(session.active_skill)
        skill_tools = active_skill.allowed_tools if active_skill else []
        current_tools = [
            t
            for t in tool_registry.get_available_tools()
            if t["function"]["name"] in config.enabled_tools
            and (not skill_tools or t["function"]["name"] in skill_tools)
        ]

        if current_tools:
            result = llm.chat_with_tools(messages, current_tools)
            if "error" in result:
                thinking.stop()
                print_error(result["error"])
                continue
            msg = result.get("choices", [{}])[0].get("message", {})

            # Only print response if there are NO tool calls
            # If there ARE tool calls, handle_tool_calls will print the final response
            if not msg.get("tool_calls"):
                thinking.stop()
                response = msg.get("content", "")
                print()
                print_response(response)
            else:
                thinking.stop()
                response, messages = handle_tool_calls(msg, messages, current_tools)
                print()
                print_response(response)
        else:
            thinking.stop()
            print()
            response = print_response_streaming(llm.chat_stream(messages))

        session_manager.add_message(session.id, "user", user_input)
        session_manager.add_message(session.id, "assistant", response)


def cmd_skill(args):
    """Handle skill subcommand.

    Args:
        args: Parsed command-line arguments.
    """
    if args.list:
        if args.quiet:
            for skill in skill_registry.skills.values():
                print(skill.name)
        else:
            print_skills_table(skill_registry.skills)

    elif args.enable:
        skill_registry.enable(args.enable)
        print_success(f"Enabled skill: {args.enable}")

    elif args.disable:
        skill_registry.disable(args.disable)
        print_success(f"Disabled skill: {args.disable}")

    elif args.set:
        session = session_manager.get_current()
        if session:
            session.active_skill = args.set
            print_success(f"Active skill set to: {args.set}")
        else:
            print_error("No active session")


def cmd_plugin(args):
    """Handle plugin subcommand.

    Args:
        args: Parsed command-line arguments.
    """
    if args.list:
        console.print()
        console.print(Text("  Loaded Plugins:", style="bold cyan"))
        plugins = plugin_manager.list_plugins()
        if not plugins:
            print_info("No plugins loaded")
        for p in plugins:
            status = "[green]enabled[/green]" if p["enabled"] else "[dim]disabled[/dim]"
            console.print(f"    {p['name']} v{p['version']} ({status})")
            if p["description"]:
                console.print(f"      {p['description']}")
            if p["tools"]:
                console.print(f"      Tools: {', '.join(p['tools'])}")

        available = plugin_manager.list_available()
        if available:
            console.print()
            console.print(Text("  Available Plugins:", style="bold cyan"))
            for name in available:
                console.print(f"    {name}")
        console.print()
        console.print(f"  Plugin directory: {Path.home() / '.clawbert' / 'plugins'}")
        console.print()

    elif args.install:
        path = args.install
        name = Path(path).name if Path(path).is_dir() else Path(path).stem
        if plugin_manager.install(path):
            print_success(f"Installed plugin: {name}")
        else:
            print_error(f"Failed to install plugin from: {path}")

    elif args.uninstall:
        name = args.uninstall
        if plugin_manager.uninstall(name):
            print_success(f"Uninstalled plugin: {name}")
        else:
            print_error(f"Failed to uninstall plugin: {name}")

    elif args.create:
        name = args.create
        if not name.replace("-", "").replace("_", "").isalnum():
            print_error(
                "Invalid plugin name. Use only letters, numbers, hyphens, and underscores."
            )
            return
        plugin_dir = plugin_manager.create(name, args.description or "")
        print_success(f"Created plugin scaffold: {name}")
        console.print(f"  Location: {plugin_dir}")
        console.print()
        console.print("  Edit the plugin files to add your functionality:")
        console.print(f"    {plugin_dir / '__init__.py'}")

    elif args.enable:
        name = args.enable
        if plugin_manager.enable(name):
            print_success(f"Enabled plugin: {name}")
        else:
            print_error(f"Failed to enable plugin: {name}")

    elif args.disable:
        name = args.disable
        if plugin_manager.disable(name):
            print_success(f"Disabled plugin: {name}")
        else:
            print_error(f"Failed to disable plugin: {name}")

    elif args.reload:
        name = args.reload
        if name:
            if plugin_manager.reload(name):
                print_success(f"Reloaded plugin: {name}")
            else:
                print_error(f"Failed to reload plugin: {name}")
        else:
            plugin_manager.reload()
            print_success("Reloaded all plugins")


def cmd_usage(args):
    """Handle usage subcommand - show usage statistics."""
    if args.clear:
        usage_tracker.clear_data()
        print_success("Usage data cleared")
        return

    if args.export:
        data = usage_tracker.export_data()
        print(json.dumps(data, indent=2))
        return

    stats = usage_tracker.get_stats(args.days)
    console.print()
    console.print(Text("  Usage Statistics", style="bold cyan"))
    console.print(f"  Period: last {stats['period_days']} days")
    console.print()

    api = stats["api_calls"]
    console.print(Text("  API Calls:", style="bold"))
    console.print(f"    Total: {api['total']}")
    console.print(f"    Total cost: ${api['total_cost']:.6f}")
    console.print(
        f"    Tokens: {api['total_tokens']:,} (prompt: {api['total_prompt_tokens']:,}, completion: {api['total_completion_tokens']:,})"
    )
    if api["by_provider"]:
        console.print(f"    By provider: {api['by_provider']}")
    console.print()

    tools = stats["tool_usage"]
    console.print(Text("  Tool Usage:", style="bold"))
    console.print(f"    Total: {tools['total']}")
    console.print(f"    Success rate: {tools['success_rate']}%")
    if tools["by_tool"]:
        console.print(f"    By tool: {tools['by_tool']}")
    console.print()

    sessions = stats["sessions"]
    console.print(Text("  Sessions:", style="bold"))
    console.print(f"    Started: {sessions['started']}")
    console.print(f"    Ended: {sessions['ended']}")
    console.print(f"    Total messages: {sessions['total_messages']}")
    console.print()

    errors = stats["errors"]
    console.print(Text("  Errors:", style="bold"))
    console.print(f"    Total: {errors['total']}")
    if errors["by_type"]:
        console.print(f"    By type: {errors['by_type']}")
    console.print()


def cmd_telemetry(args):
    """Handle telemetry subcommand - toggle anonymous telemetry."""
    if args.enable:
        config.telemetry_enabled = True
        config.save()
        telemetry_sender.enabled = True
        print_success("Anonymous telemetry enabled")
        console.print()
        console.print(
            "  Thank you! Telemetry helps improve Clawbert. "
            "Only anonymized, aggregated data is sent."
        )
        console.print("  No personal data or conversation content is ever transmitted.")
        console.print()

    elif args.disable:
        config.telemetry_enabled = False
        config.save()
        telemetry_sender.enabled = False
        print_success("Anonymous telemetry disabled")
        console.print()

    else:
        status = "enabled" if config.telemetry_enabled else "disabled"
        console.print(f"  Telemetry is currently: {status}")
        console.print()
        console.print("  Use --enable to opt-in or --disable to opt-out.")
        console.print()


def cmd_schedule(args):
    """Handle schedule subcommand - manage scheduled tasks."""
    from .services.scheduler import scheduler

    if args.list:
        tasks = scheduler.list_tasks()
        if not tasks:
            print_info("No scheduled tasks")
            return
        console.print()
        console.print(Text("  Scheduled Tasks:", style="bold cyan"))
        for task in tasks:
            status = (
                "[green]enabled[/green]" if task["enabled"] else "[dim]disabled[/dim]"
            )
            console.print(f"  {task['name']} ({status})")
            console.print(f"    Type: {task['task_type']}")
            console.print(f"    Schedule: {task['schedule']}")
            console.print(f"    Next run: {task['next_run'] or 'N/A'}")
            console.print(f"    Last run: {task['last_run'] or 'N/A'}")
            console.print()

    elif args.start:
        print_info("Starting scheduler daemon...")
        scheduler.run(daemon=True)
        console.print("  Scheduler running in background. Press Ctrl+C to stop.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            scheduler.running = False
            print_info("Scheduler stopped")

    elif args.run_once:
        print_info("Running all enabled tasks once...")
        scheduler.run(daemon=False)
        print_success("All tasks executed")

    else:
        console.print("  Usage:")
        console.print("    clawbert schedule --list          List scheduled tasks")
        console.print("    clawbert schedule --start        Start scheduler daemon")
        console.print("    clawbert schedule --run-once     Run all tasks once")
        console.print()


def cmd_expose(args):
    """Handle expose subcommand for Headscale/Tailscale."""
    from .services.exposure import create_exposure_manager

    mgr = create_exposure_manager()

    if args.status:
        status = mgr.get_status()
        console.print("[bold]Exposure Status:[/bold]")
        console.print(f"  Mode: {status['mode']}")
        console.print(f"  Tailscale installed: {status['tailscale_installed']}")
        console.print(f"  Connected: {status['connected']}")
        if status["tailnet_ip"]:
            console.print(f"  Tailnet IP: {status['tailnet_ip']}")
        return

    if args.disable:
        result = mgr.disable_exposure()
        console.print(f"[green]✓[/green] {result}")
        return

    if args.local:
        result = mgr.expose_local(port=args.port)
        console.print(f"[green]✓[/green] Exposed locally at: {result}")
        return

    if args.headscale:
        result = mgr.expose_headscale(port=args.port, headscale_url=args.headscale_url)
        console.print(f"[green]✓[/green] {result}")
        return

    console.print("[bold]Usage:[/bold]")
    console.print("  clawbert expose --local --port 8080     Expose locally")
    console.print("  clawbert expose --headscale             Expose via Headscale")
    console.print("  clawbert expose --status                Show status")
    console.print("  clawbert expose --disable                Disable exposure")


def cmd_todo(args):
    """Handle todo subcommand for task management."""
    from .core.todo import todo_manager

    if args.list:
        console.print("[bold]Task List:[/bold]")
        console.print(todo_manager.get_formatted_list())
        return

    if args.add:
        priority = args.priority or "medium"
        task_id = todo_manager.add(args.add, priority=priority)
        console.print(f"[green]✓[/green] Added task #{task_id}: {args.add}")
        console.print(todo_manager.get_summary())
        return

    if args.task_id and args.status:
        success = todo_manager.update(args.task_id, status=args.status)
        if success:
            console.print(
                f"[green]✓[/green] Updated task #{args.task_id} to {args.status}"
            )
            console.print(todo_manager.get_summary())
        else:
            console.print(f"[red]✗[/red] Task #{args.task_id} not found")
        return

    if args.clear:
        count = todo_manager.clear(status="completed")
        console.print(f"[green]✓[/green] Cleared {count} completed tasks")
        return

    console.print("[bold]Usage:[/bold]")
    console.print("  clawbert todo --list                    List all tasks")
    console.print("  clawbert todo --add 'task description'  Add new task")
    console.print("  clawbert todo <id> --status completed   Update task status")
    console.print("  clawbert todo --clear                   Clear completed tasks")
    console.print()
    console.print(todo_manager.get_summary())


def main():
    """Main entry point for the CLI."""
    init_telemetry(config.telemetry_enabled)

    parser = argparse.ArgumentParser(
        prog="clawbert",
        description="Clawbert - AI CLI Assistant with Memory & Skills",
    )
    subparsers = parser.add_subparsers()

    p_config = subparsers.add_parser("config", help="Configure Clawbert")
    p_config.add_argument(
        "--provider",
        help="Set LLM provider (openrouter, openai, anthropic, ollama, groq, mistral, gemini, zai, lmstudio)",
    )
    p_config.add_argument("--api-key", help="Set API key for current provider")
    p_config.add_argument("--model", help="Set default model")
    p_config.add_argument(
        "--base-url", help="Set base URL for provider (for proxies/custom endpoints)"
    )
    p_config.add_argument(
        "--list-providers", action="store_true", help="List available providers"
    )
    p_config.add_argument(
        "--list-models",
        action="store_true",
        help="List available models for current provider",
    )
    p_config.add_argument(
        "--list-tools", action="store_true", help="List available tools"
    )
    p_config.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Quiet output (just names, for completions)",
    )
    p_config.add_argument(
        "--list-skills", action="store_true", help="List available skills"
    )
    p_config.add_argument("--enable-tool", help="Enable a tool")
    p_config.add_argument("--disable-tool", help="Disable a tool")
    p_config.set_defaults(func=cmd_config)

    p_session = subparsers.add_parser("session", help="Manage sessions")
    p_session.add_argument("--list", action="store_true", help="List sessions")
    p_session.add_argument("--create", nargs="?", help="Create new session")
    p_session.add_argument("--switch", help="Switch to session")
    p_session.add_argument("--delete", help="Delete session")
    p_session.set_defaults(func=cmd_session)

    p_memory = subparsers.add_parser("memory", help="Manage memory")
    p_memory.add_argument("--search", help="Search memory")
    p_memory.add_argument("--list", action="store_true", help="List all memories")
    p_memory.add_argument("--get", help="Get memory by key")
    p_memory.add_argument("--store", help="Store memory (key=value)")
    p_memory.add_argument("--delete", help="Delete memory")
    p_memory.add_argument("--clear", action="store_true", help="Clear all memories")
    p_memory.set_defaults(func=cmd_memory)

    p_skill = subparsers.add_parser("skill", help="Manage skills")
    p_skill.add_argument("--list", action="store_true", help="List skills")
    p_skill.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Quiet output (just names, for completions)",
    )
    p_skill.add_argument("--enable", help="Enable skill")
    p_skill.add_argument("--disable", help="Disable skill")
    p_skill.add_argument("--set", help="Set active skill for current session")
    p_skill.set_defaults(func=cmd_skill)

    p_plugin = subparsers.add_parser("plugin", help="Manage plugins")
    p_plugin.add_argument(
        "--list", action="store_true", help="List loaded and available plugins"
    )
    p_plugin.add_argument("--install", metavar="PATH", help="Install plugin from path")
    p_plugin.add_argument(
        "--uninstall", metavar="NAME", help="Uninstall plugin by name"
    )
    p_plugin.add_argument("--create", metavar="NAME", help="Create new plugin scaffold")
    p_plugin.add_argument(
        "--description", "-d", default="", help="Plugin description (for --create)"
    )
    p_plugin.add_argument("--enable", metavar="NAME", help="Enable plugin")
    p_plugin.add_argument("--disable", metavar="NAME", help="Disable plugin")
    p_plugin.add_argument(
        "--reload", nargs="?", const="all", metavar="NAME", help="Reload plugin(s)"
    )
    p_plugin.set_defaults(func=cmd_plugin)

    p_chat = subparsers.add_parser("chat", help="Chat with Clawbert")
    p_chat.add_argument("prompt", nargs="?", help="Prompt to send")
    p_chat.set_defaults(func=cmd_chat)

    p_api = subparsers.add_parser("api", help="Start REST API server")
    p_api.add_argument(
        "--host", default="0.0.0.0", help="Host to bind to (default: 0.0.0.0)"
    )
    p_api.add_argument(
        "--port", type=int, default=8000, help="Port to bind to (default: 8000)"
    )
    p_api.add_argument("--api-key", help="Optional API key for authentication")
    p_api.add_argument(
        "--cors", help="CORS origins (comma-separated, default: allow all)"
    )
    p_api.set_defaults(func=cmd_api)

    p_mcp = subparsers.add_parser("mcp", help="Start MCP server mode")
    p_mcp.add_argument(
        "--transport",
        choices=["stdio", "http"],
        default="http",
        help="Transport type (default: http)",
    )
    p_mcp.add_argument(
        "--host", default="0.0.0.0", help="Host to bind to for HTTP (default: 0.0.0.0)"
    )
    p_mcp.add_argument(
        "--port",
        type=int,
        default=8080,
        help="Port to bind to for HTTP (default: 8080)",
    )
    p_mcp.set_defaults(func=cmd_mcp)

    p_completions = subparsers.add_parser(
        "completions", help="Generate shell completions"
    )
    p_completions.add_argument(
        "--shell",
        choices=["bash", "fish", "zsh"],
        required=True,
        help="Shell type (bash, fish, or zsh)",
    )
    p_completions.set_defaults(func=cmd_completions)

    p_usage = subparsers.add_parser("usage", help="Show usage statistics")
    p_usage.add_argument(
        "--export", action="store_true", help="Export usage data as JSON"
    )
    p_usage.add_argument("--clear", action="store_true", help="Clear all usage data")
    p_usage.add_argument(
        "--days", type=int, default=30, help="Number of days to include (default: 30)"
    )
    p_usage.set_defaults(func=cmd_usage)

    p_telemetry = subparsers.add_parser("telemetry", help="Manage anonymous telemetry")
    p_telemetry.add_argument(
        "--enable", action="store_true", help="Enable anonymous telemetry"
    )
    p_telemetry.add_argument(
        "--disable", action="store_true", help="Disable anonymous telemetry"
    )
    p_telemetry.set_defaults(func=cmd_telemetry)

    p_schedule = subparsers.add_parser("schedule", help="Manage scheduled tasks")
    p_schedule.add_argument(
        "--list", action="store_true", help="List all scheduled tasks"
    )
    p_schedule.add_argument(
        "--start", action="store_true", help="Start the scheduler daemon"
    )
    p_schedule.add_argument(
        "--run-once", action="store_true", help="Run all enabled tasks once"
    )
    p_schedule.set_defaults(func=cmd_schedule)

    p_expose = subparsers.add_parser(
        "expose", help="Manage remote exposure (Headscale/Tailscale)"
    )
    p_expose.add_argument("--local", action="store_true", help="Expose locally only")
    p_expose.add_argument(
        "--headscale", action="store_true", help="Expose via Headscale"
    )
    p_expose.add_argument("--headscale-url", help="Headscale server URL")
    p_expose.add_argument("--port", type=int, default=8080, help="Port to expose")
    p_expose.add_argument("--status", action="store_true", help="Show exposure status")
    p_expose.add_argument("--disable", action="store_true", help="Disable all exposure")
    p_expose.set_defaults(func=cmd_expose)

    p_todo = subparsers.add_parser("todo", help="Manage task list")
    p_todo.add_argument("--list", "-l", action="store_true", help="List all tasks")
    p_todo.add_argument("--add", "-a", help="Add a new task")
    p_todo.add_argument(
        "--status", help="Update task status (pending/in_progress/completed/cancelled)"
    )
    p_todo.add_argument("--priority", help="Set priority (high/medium/low)")
    p_todo.add_argument(
        "--clear", action="store_true", help="Clear all completed tasks"
    )
    p_todo.add_argument("task_id", nargs="?", help="Task ID for status update")
    p_todo.set_defaults(func=cmd_todo)

    add_wizard_parser(subparsers)

    args = parser.parse_args()

    # Ensure args has required attributes
    if not hasattr(args, "prompt"):
        args.prompt = None

    if hasattr(args, "func"):
        args.func(args)
    else:
        cmd_chat(args)


if __name__ == "__main__":
    main()
