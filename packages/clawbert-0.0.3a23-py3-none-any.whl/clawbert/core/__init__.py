"""Core module exports."""

from .config import Config, config

__all__ = ["Config", "config"]
