"""Configuration management for Clawbert.

This module provides a centralized configuration system using dataclasses.
Settings are persisted to JSON and loaded automatically on startup.

Configuration Options:
    - model_provider: LLM provider (openrouter, openai, anthropic, ollama)
    - openrouter_api_key: Authentication key for OpenRouter API
    - openai_api_key: Authentication key for OpenAI API
    - anthropic_api_key: Authentication key for Anthropic API
    - ollama_base_url: Base URL for local Ollama instance
    - default_model: Default LLM model
    - temperature: Sampling temperature for responses (0.0-2.0, default: 0.7)
    - max_tokens: Maximum tokens per response (default: 4096)
    - enabled_tools: List of active tool names
    - enabled_skills: List of active skill names
    - memory_dir: Directory for memory storage
    - sessions_dir: Directory for session storage
    - skills_dir: Directory for skills definitions

The config is stored at ~/.clawbert/config.json and automatically
created with sensible defaults on first run.

Example:
    from .config import Config, config

    # Update settings
    config.model_provider = "openai"
    config.openai_api_key = "sk-..."
    config.default_model = "gpt-4o"
    config.save()

    # Access settings
    print(config.enabled_tools)
"""

import json
from pathlib import Path
from dataclasses import dataclass, field


VALID_PROVIDERS = [
    "openrouter",
    "openai",
    "anthropic",
    "ollama",
    "groq",
    "mistral",
    "gemini",
    "zai",
    "lmstudio",
]

DEFAULT_MODELS = {
    "openrouter": "meta-llama/llama-3.3-70b-instruct:free",
    "openai": "gpt-4o-mini",
    "anthropic": "claude-3-5-haiku-20241022",
    "ollama": "llama3.2",
    "groq": "llama-3.3-70b-versatile",
    "mistral": "mistral-small-2503",
    "gemini": "gemini-2.0-flash-exp",
    "zai": "qwen2.5-72b-instruct",
    "lmstudio": "qwen2.5-7b-instruct-q4_0",
}


@dataclass
class Config:
    """Main configuration class for Clawbert.

    Attributes:
        model_provider: LLM provider to use (openrouter, openai, anthropic, ollama).
        openrouter_api_key: API key for OpenRouter service.
        openrouter_base_url: Base URL for OpenRouter API.
        openai_api_key: API key for OpenAI service.
        openai_base_url: Base URL for OpenAI API (optional, for proxies).
        anthropic_api_key: API key for Anthropic service.
        anthropic_base_url: Base URL for Anthropic API.
        ollama_base_url: Base URL for local Ollama instance.
        default_model: Default model to use for LLM calls.
        temperature: Default temperature for LLM responses.
        max_tokens: Default max tokens for LLM responses.
        memory_dir: Directory for storing memory data.
        sessions_dir: Directory for storing session data.
        skills_dir: Directory for storing skills.
        config_path: Path to the config JSON file.
        enabled_tools: List of tool names that are enabled.
        enabled_skills: List of skill names that are enabled.
        mcp_enabled: Enable MCP server mode.
        mcp_host: Host for MCP HTTP server.
        mcp_port: Port for MCP HTTP server.
    """

    model_provider: str = "openrouter"
    openrouter_api_key: str = ""
    openrouter_base_url: str = "https://openrouter.ai/api/v1"
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    anthropic_api_key: str = ""
    anthropic_base_url: str = "https://api.anthropic.com"
    ollama_base_url: str = "http://localhost:11434"
    groq_api_key: str = ""
    groq_base_url: str = "https://api.groq.com/openai/v1"
    mistral_api_key: str = ""
    mistral_base_url: str = "https://api.mistral.ai/v1"
    gemini_api_key: str = ""
    gemini_base_url: str = "https://generativelanguage.googleapis.com/v1beta"
    zai_api_key: str = ""
    zai_base_url: str = "https://api.z.ai/v1"
    lmstudio_base_url: str = "http://localhost:1234/v1"
    default_model: str = "stepfun/step-3.5-flash:free"
    temperature: float = 0.7
    max_tokens: int = 4096
    memory_dir: Path = Path.home() / ".clawbert" / "memory"
    sessions_dir: Path = Path.home() / ".clawbert" / "sessions"
    skills_dir: Path = Path.home() / ".clawbert" / "skills"
    config_path: Path = Path.home() / ".clawbert" / "config.json"

    enabled_tools: list = field(
        default_factory=lambda: [
            "read",
            "write",
            "edit",
            "grep",
            "glob",
            "list_directory",
            "git_status",
            "git_diff",
            "git_log",
            "git_commit",
            "git_push",
            "git_checkout",
            "web_search",
            "web_fetch",
            "exec",
            "sqlite_query",
            "http_request",
            "memory_search",
            "memory_store",
            "list_skills",
            "TodoWrite",
            "TodoRead",
        ]
    )
    enabled_skills: list = field(default_factory=list)
    enabled_plugins: list = field(default_factory=list)
    plugins_dir: Path = Path.home() / ".clawbert" / "plugins"
    vector_memory_enabled: bool = True
    vector_memory_model: str = "all-MiniLM-L6-v2"
    mcp_enabled: bool = False
    mcp_host: str = "0.0.0.0"
    mcp_port: int = 8080
    telemetry_enabled: bool = False
    usage_tracking_enabled: bool = True

    def __post_init__(self):
        """Initialize configuration and ensure directories exist.

        Creates necessary directories and loads existing config
        from file if present.
        """
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.skills_dir.mkdir(parents=True, exist_ok=True)
        self.plugins_dir.mkdir(parents=True, exist_ok=True)

        if self.config_path.exists():
            with open(self.config_path) as f:
                data = json.load(f)
                for key, value in data.items():
                    if hasattr(self, key):
                        setattr(self, key, value)

        if self.model_provider not in VALID_PROVIDERS:
            self.model_provider = "openrouter"

    def get_provider_api_key(self) -> str:
        """Get API key for the current provider."""
        if self.model_provider == "openrouter":
            return self.openrouter_api_key
        elif self.model_provider == "openai":
            return self.openai_api_key
        elif self.model_provider == "anthropic":
            return self.anthropic_api_key
        return ""

    def get_provider_base_url(self) -> str:
        """Get base URL for the current provider."""
        if self.model_provider == "openrouter":
            return self.openrouter_base_url
        elif self.model_provider == "openai":
            return self.openai_base_url
        elif self.model_provider == "anthropic":
            return self.anthropic_base_url
        elif self.model_provider == "ollama":
            return self.ollama_base_url
        return ""

    def get_default_model_for_provider(self, provider: str) -> str:
        """Get default model for a given provider."""
        return DEFAULT_MODELS.get(provider, "llama3.2")

    def get_current_model_default(self) -> str:
        """Get default model for the current provider."""
        return self.get_default_model_for_provider(self.model_provider)

    def save(self):
        """Save current configuration to JSON file.

        Writes all configuration settings to the config file
        for persistence across sessions.
        """
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "model_provider": self.model_provider,
            "openrouter_api_key": self.openrouter_api_key,
            "openrouter_base_url": self.openrouter_base_url,
            "openai_api_key": self.openai_api_key,
            "openai_base_url": self.openai_base_url,
            "anthropic_api_key": self.anthropic_api_key,
            "anthropic_base_url": self.anthropic_base_url,
            "ollama_base_url": self.ollama_base_url,
            "groq_api_key": self.groq_api_key,
            "groq_base_url": self.groq_base_url,
            "mistral_api_key": self.mistral_api_key,
            "mistral_base_url": self.mistral_base_url,
            "gemini_api_key": self.gemini_api_key,
            "gemini_base_url": self.gemini_base_url,
            "zai_api_key": self.zai_api_key,
            "zai_base_url": self.zai_base_url,
            "lmstudio_base_url": self.lmstudio_base_url,
            "default_model": self.default_model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "enabled_tools": self.enabled_tools,
            "enabled_skills": self.enabled_skills,
            "enabled_plugins": self.enabled_plugins,
            "plugins_dir": str(self.plugins_dir),
            "vector_memory_enabled": self.vector_memory_enabled,
            "vector_memory_model": self.vector_memory_model,
            "mcp_enabled": self.mcp_enabled,
            "mcp_host": self.mcp_host,
            "mcp_port": self.mcp_port,
            "telemetry_enabled": self.telemetry_enabled,
            "usage_tracking_enabled": self.usage_tracking_enabled,
        }
        with open(self.config_path, "w") as f:
            json.dump(data, f, indent=2)


config = Config()
