"""LLM client for interacting with various LLM providers.

This module provides a client that uses provider abstraction to support
multiple LLM services (OpenRouter, OpenAI, Anthropic, Ollama).

Features:
    - Multi-provider support via abstraction layer
    - Standard chat completions
    - Streaming responses (token-by-token)
    - Tool/function calling support
    - Automatic model listing
    - Backward compatibility with existing code

Example:
    from .core.llm import LLMClient

    # Initialize client (uses config provider)
    llm = LLMClient()

    # Simple chat
    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello!"}
    ]
    response = llm.chat(messages)

    # Streaming chat
    for chunk in llm.chat_stream(messages):
        print(chunk, end="", flush=True)

    # Tool calling
    tools = [{
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get weather for a location",
            "parameters": {"type": "object", "properties": {"city": {"type": "string"}}}
        }
    }]
    result = llm.chat_with_tools(messages, tools)
"""

from typing import Optional, Iterator
from .config import config
from .providers import Provider, get_provider
from ..services.telemetry import usage_tracker, telemetry_sender


class LLMClient:
    """Client for LLM provider interactions.

    Provides methods for sending chat requests with support for
    standard chat, streaming, and function calling. Uses provider
    abstraction to support multiple LLM services.

    Attributes:
        model: The model identifier to use.
        provider: The underlying provider instance.
    """

    def __init__(
        self,
        model: Optional[str] = None,
        provider_name: Optional[str] = None,
    ):
        """Initialize the LLM client.

        Args:
            model: Optional model name. Defaults to config default.
            provider_name: Optional provider name. Defaults to config provider.
        """
        self.model = model or config.default_model
        provider = provider_name or config.model_provider
        self.provider: Provider = get_provider(provider, config)

    def _get_error_message(self, error: str) -> str:
        """Get provider-specific error message.

        Args:
            error: The error message from the provider.

        Returns:
            Updated error message with provider context.
        """
        provider = config.model_provider
        if "API key not configured" in error:
            if provider == "openrouter":
                return "Error: OpenRouter API key not configured. Run: clawbert config --api-key YOUR_KEY"
            elif provider == "openai":
                return "Error: OpenAI API key not configured. Set with: clawbert config --provider openai --api-key YOUR_KEY"
            elif provider == "anthropic":
                return "Error: Anthropic API key not configured. Set with: clawbert config --provider anthropic --api-key YOUR_KEY"
            elif provider == "ollama":
                return "Error: Cannot connect to Ollama. Is it running? Run 'ollama serve' to start."
        return error

    def _estimate_cost(
        self, provider: str, model: str, prompt_tokens: int, completion_tokens: int
    ) -> float:
        """Estimate cost for API call based on provider and tokens."""
        rates = {
            "openrouter": {
                "prompt_per_1m": 0.05,
                "completion_per_1m": 0.10,
            },
            "openai": {
                "gpt-4o-mini": {"prompt_per_1m": 0.15, "completion_per_1m": 0.60},
                "gpt-4o": {"prompt_per_1m": 2.50, "completion_per_1m": 10.00},
            },
            "anthropic": {
                "prompt_per_1m": 0.80,
                "completion_per_1m": 4.00,
            },
            "ollama": {"prompt_per_1m": 0, "completion_per_1m": 0},
        }

        if provider == "openai" and model in rates["openai"]:
            rate = rates["openai"][model]
        elif provider in rates:
            rate = rates[provider]
        else:
            rate = rates["openrouter"]

        return (
            prompt_tokens / 1_000_000 * rate["prompt_per_1m"]
            + completion_tokens / 1_000_000 * rate["completion_per_1m"]
        )

    def _track_response_usage(
        self, provider: Provider, model: str, response: Optional[dict] = None
    ):
        """Track API usage from response data."""
        if response is None:
            return

        usage = response.get("usage", {})
        if not usage:
            return

        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)

        provider_name = config.model_provider
        cost = self._estimate_cost(
            provider_name, model, prompt_tokens, completion_tokens
        )

        usage_tracker.track_api_call(
            provider_name, model, prompt_tokens, completion_tokens, cost
        )

        if config.telemetry_enabled:
            stats = usage_tracker.get_stats(days=7)
            telemetry_sender.send_telemetry(stats)

    def chat(
        self, messages: list, temperature: float = 0.7, max_tokens: int = 4096
    ) -> str:
        """Send a chat completion request without tools.

        Args:
            messages: List of message dicts with 'role' and 'content'.
            temperature: Sampling temperature (0.0 to 2.0).
            max_tokens: Maximum tokens in response.

        Returns:
            The assistant's response content as a string,
            or an error message if the request fails.
        """
        result = self.provider.chat(messages, self.model, temperature, max_tokens)
        if result.startswith("Error:") and "API key not configured" in result:
            return self._get_error_message(result)

        if config.usage_tracking_enabled:
            self._track_response_usage(self.provider, self.model)

        return result

    def chat_stream(self, messages: list, temperature: float = 0.7) -> Iterator[str]:
        """Send a streaming chat completion request.

        Args:
            messages: List of message dicts with 'role' and 'content'.
            temperature: Sampling temperature (0.0 to 2.0).

        Yields:
            Chunks of the assistant's response as they arrive.
        """
        for chunk in self.provider.chat_stream(messages, self.model, temperature):
            if "API key not configured" in chunk:
                yield self._get_error_message(chunk)
                return
            yield chunk

    def chat_with_tools(
        self,
        messages: list,
        tools: list,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict:
        """Send a chat completion request with tool definitions.

        Args:
            messages: List of message dicts with 'role' and 'content'.
            tools: List of tool definitions for function calling.
            temperature: Sampling temperature (0.0 to 2.0).
            max_tokens: Maximum tokens in response.

        Returns:
            Full API response as a dict, or error dict if failed.
        """
        result = self.provider.chat_with_tools(
            messages, tools, self.model, temperature, max_tokens
        )
        if "error" in result and "API key not configured" in result.get("error", ""):
            result["error"] = self._get_error_message(result["error"])

        if config.usage_tracking_enabled:
            self._track_response_usage(self.provider, self.model, result)

        return result

    @staticmethod
    def extract_reasoning(response_data: dict) -> tuple[str, dict]:
        """Extract reasoning tokens and content from API response.

        Args:
            response_data: The API response dict

        Returns:
            Tuple of (reasoning_content, usage_info)
        """
        reasoning_content = ""
        usage_info = {}

        usage = response_data.get("usage", {})
        if usage:
            completion_details = usage.get("completion_tokens_details", {})
            reasoning_tokens = completion_details.get("reasoning_tokens", 0)
            if reasoning_tokens:
                usage_info["reasoning_tokens"] = reasoning_tokens

        choices = response_data.get("choices", [{}])
        if choices:
            message = choices[0].get("message", {})
            reasoning_content = message.get("reasoning_content", "")

            if not reasoning_content:
                message_content = message.get("content", "")
                if isinstance(message_content, dict):
                    reasoning_content = message_content.get("reasoning", "")

        return reasoning_content, usage_info

    def get_available_models(self) -> list[str]:
        """Get available models from the current provider.

        Returns:
            List of model identifiers sorted by name.
        """
        return self.provider.get_available_models()


def get_available_models() -> list[str]:
    """Standalone function to get available models from current provider.

    Returns:
        List of model identifiers sorted by name.
    """
    client = LLMClient()
    return client.get_available_models()
