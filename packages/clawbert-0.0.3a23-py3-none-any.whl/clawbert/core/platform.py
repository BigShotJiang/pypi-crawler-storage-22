"""Platform utilities for cross-platform compatibility."""

import sys
import os
from pathlib import Path
from typing import Optional


def get_platform() -> str:
    """Get current platform.

    Returns:
        'linux', 'windows', or 'darwin' (macOS)
    """
    return sys.platform


def is_linux() -> bool:
    """Check if running on Linux."""
    return sys.platform.startswith("linux")


def is_windows() -> bool:
    """Check if running on Windows."""
    return sys.platform == "win32" or os.name == "nt"


def is_macos() -> bool:
    """Check if running on macOS."""
    return sys.platform == "darwin"


def get_home_dir() -> Path:
    """Get user home directory cross-platform.

    Returns:
        Path to user home directory
    """
    return Path.home()


def get_config_dir() -> Path:
    """Get config directory cross-platform.

    Returns:
        Path to config directory (~/.clawbert)
    """
    return get_home_dir() / ".clawbert"


def get_temp_dir() -> Path:
    """Get temp directory cross-platform.

    Returns:
        Path to temp directory
    """
    import tempfile

    return Path(tempfile.gettempdir())


def which(command: str) -> Optional[str]:
    """Find command in PATH cross-platform.

    Args:
        command: Command name to find

    Returns:
        Full path to command or None
    """
    import shutil

    return shutil.which(command)


def get_path_separator() -> str:
    """Get PATH separator for current platform.

    Returns:
        ':' on Linux/macOS, ';' on Windows
    """
    return ";" if is_windows() else ":"


def line_ending() -> str:
    """Get line ending for current platform.

    Returns:
        '\\r\\n' on Windows, '\\n' on Linux/macOS
    """
    return "\r\n" if is_windows() else "\n"


def supports_ansi() -> bool:
    """Check if terminal supports ANSI colors.

    Returns:
        True if ANSI colors supported
    """
    if is_windows():
        import colorama

        try:
            colorama.init()
            return True
        except Exception:
            return False
    return True
