"""Multi-model provider support for Clawbert.

This module provides provider abstraction for different LLM services:
- OpenRouter: Aggregated API for multiple models
- OpenAI: Direct OpenAI API access
- Anthropic: Anthropic Claude API access
- Ollama: Local self-hosted models

Example:
    from .core.providers import get_provider, OpenRouterProvider

    provider = get_provider("openai")
    response = provider.chat([{"role": "user", "content": "Hello"}])
"""

import json
import requests
from abc import ABC, abstractmethod
from typing import Optional, Iterator, Any


class Provider(ABC):
    """Abstract base class for LLM providers."""

    @abstractmethod
    def chat(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        """Send a chat completion request.

        Args:
            messages: List of message dicts with 'role' and 'content'.
            model: Optional model name. Defaults to provider default.
            temperature: Sampling temperature (0.0 to 2.0).
            max_tokens: Maximum tokens in response.

        Returns:
            The assistant's response content as a string.
        """
        pass

    @abstractmethod
    def chat_stream(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        """Send a streaming chat completion request.

        Args:
            messages: List of message dicts with 'role' and 'content'.
            model: Optional model name. Defaults to provider default.
            temperature: Sampling temperature (0.0 to 2.0).

        Yields:
            Chunks of the assistant's response as they arrive.
        """
        pass

    @abstractmethod
    def chat_with_tools(
        self,
        messages: list,
        tools: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict:
        """Send a chat completion request with tool definitions.

        Args:
            messages: List of message dicts with 'role' and 'content'.
            tools: List of tool definitions for function calling.
            model: Optional model name. Defaults to provider default.
            temperature: Sampling temperature (0.0 to 2.0).
            max_tokens: Maximum tokens in response.

        Returns:
            Full API response as a dict.
        """
        pass

    @abstractmethod
    def get_available_models(self) -> list[str]:
        """Get available models from the provider.

        Returns:
            List of model identifiers.
        """
        pass


class OpenRouterProvider(Provider):
    """Provider for OpenRouter API (aggregated LLM access)."""

    DEFAULT_MODEL = "stepfun/step-3.5-flash:free"
    BASE_URL = "https://openrouter.ai/api/v1"

    def __init__(self, api_key: str = "", base_url: Optional[str] = None):
        self.api_key = api_key
        self.base_url = base_url or self.BASE_URL

    def _get_headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://github.com/ForgedInFiles/Clawbert",
            "X-Title": "Clawbert",
        }

    def chat(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        if not self.api_key:
            return "Error: OpenRouter API key not configured. Run: clawbert config --api-key YOUR_KEY"

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 503:
                return "Error: OpenRouter service is temporarily unavailable. Please try again in a moment."
            if response.status_code == 429:
                return "Error: Rate limited. Please wait a moment and try again."
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except requests.exceptions.RequestException as e:
            return f"Connection error: {str(e)}"

    def chat_stream(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        if not self.api_key:
            yield "Error: OpenRouter API key not configured."
            return

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                stream=True,
                timeout=120,
            )
            if response.status_code == 503:
                yield "Error: OpenRouter service is temporarily unavailable. Please try again in a moment."
                return
            if response.status_code == 429:
                yield "Error: Rate limited. Please wait a moment and try again."
                return
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    line = line.decode("utf-8")
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data)
                            content = (
                                chunk.get("choices", [{}])[0]
                                .get("delta", {})
                                .get("content", "")
                            )
                            if content:
                                yield content
                        except json.JSONDecodeError:
                            continue
        except requests.exceptions.RequestException as e:
            yield f"Error: {str(e)}"

    def chat_with_tools(
        self,
        messages: list,
        tools: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict:
        if not self.api_key:
            return {"error": "OpenRouter API key not configured"}

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "tools": tools,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 503:
                return {"error": "OpenRouter service is temporarily unavailable."}
            if response.status_code == 429:
                return {"error": "Rate limited. Please wait a moment and try again."}
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"error": f"Connection error: {str(e)}"}

    def get_available_models(self) -> list[str]:
        if not self.api_key:
            return []
        try:
            response = requests.get(
                f"{self.base_url}/models",
                headers=self._get_headers(),
                timeout=30,
            )
            if response.status_code == 200:
                data = response.json()
                models = data.get("data", [])
                return sorted(
                    [m["id"] for m in models if m.get("id")], key=lambda x: x.lower()
                )
        except requests.exceptions.RequestException:
            pass
        return []


class OpenAIProvider(Provider):
    """Provider for OpenAI API."""

    DEFAULT_MODEL = "gpt-4o-mini"
    BASE_URL = "https://api.openai.com/v1"

    def __init__(self, api_key: str = "", base_url: Optional[str] = None):
        self.api_key = api_key
        self.base_url = base_url or self.BASE_URL

    def _get_headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def chat(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        if not self.api_key:
            return "Error: OpenAI API key not configured. Set with: clawbert config --provider openai --api-key YOUR_KEY"

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 429:
                return "Error: Rate limited. Please wait a moment and try again."
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except requests.exceptions.RequestException as e:
            return f"Connection error: {str(e)}"

    def chat_stream(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        if not self.api_key:
            yield "Error: OpenAI API key not configured."
            return

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                stream=True,
                timeout=120,
            )
            if response.status_code == 429:
                yield "Error: Rate limited. Please wait a moment and try again."
                return
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    line = line.decode("utf-8")
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data)
                            content = (
                                chunk.get("choices", [{}])[0]
                                .get("delta", {})
                                .get("content", "")
                            )
                            if content:
                                yield content
                        except json.JSONDecodeError:
                            continue
        except requests.exceptions.RequestException as e:
            yield f"Error: {str(e)}"

    def chat_with_tools(
        self,
        messages: list,
        tools: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict:
        if not self.api_key:
            return {"error": "OpenAI API key not configured"}

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "tools": tools,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 429:
                return {"error": "Rate limited. Please wait a moment and try again."}
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"error": f"Connection error: {str(e)}"}

    def get_available_models(self) -> list[str]:
        if not self.api_key:
            return []
        try:
            response = requests.get(
                f"{self.base_url}/models",
                headers=self._get_headers(),
                timeout=30,
            )
            if response.status_code == 200:
                data = response.json()
                models = data.get("data", [])
                return sorted(
                    [m["id"] for m in models if m.get("id")], key=lambda x: x.lower()
                )
        except requests.exceptions.RequestException:
            pass
        return []


class AnthropicProvider(Provider):
    """Provider for Anthropic Claude API."""

    DEFAULT_MODEL = "claude-3-haiku-20240307"
    BASE_URL = "https://api.anthropic.com"

    def __init__(self, api_key: str = "", base_url: Optional[str] = None):
        self.api_key = api_key
        self.base_url = base_url or self.BASE_URL

    def _get_headers(self, anthropic_version: str = "2023-06-01") -> dict:
        return {
            "x-api-key": self.api_key,
            "anthropic-version": anthropic_version,
            "Content-Type": "application/json",
        }

    def _convert_messages(self, messages: list) -> tuple[str, list]:
        system_msg = ""
        converted = []
        for msg in messages:
            if msg.get("role") == "system":
                system_msg = msg.get("content", "")
            else:
                converted.append(
                    {"role": msg.get("role", "user"), "content": msg.get("content", "")}
                )
        return system_msg, converted

    def chat(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        if not self.api_key:
            return "Error: Anthropic API key not configured. Set with: clawbert config --provider anthropic --api-key YOUR_KEY"

        system, msgs = self._convert_messages(messages)

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": msgs,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if system:
            payload["system"] = system

        try:
            response = requests.post(
                f"{self.base_url}/v1/messages",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 429:
                return "Error: Rate limited. Please wait a moment and try again."
            response.raise_for_status()
            data = response.json()
            return data.get("content", [{}])[0].get("text", "")
        except requests.exceptions.RequestException as e:
            return f"Connection error: {str(e)}"

    def chat_stream(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        if not self.api_key:
            yield "Error: Anthropic API key not configured."
            return

        system, msgs = self._convert_messages(messages)

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": msgs,
            "max_tokens": 4096,
            "temperature": temperature,
            "stream": True,
        }
        if system:
            payload["system"] = system

        try:
            response = requests.post(
                f"{self.base_url}/v1/messages",
                headers=self._get_headers(),
                json=payload,
                stream=True,
                timeout=120,
            )
            if response.status_code == 429:
                yield "Error: Rate limited. Please wait a moment and try again."
                return
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    line = line.decode("utf-8")
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data)
                            if chunk.get("type") == "content_block_delta":
                                delta = chunk.get("delta", {})
                                if delta.get("type") == "text_delta":
                                    yield delta.get("text", "")
                        except json.JSONDecodeError:
                            continue
        except requests.exceptions.RequestException as e:
            yield f"Error: {str(e)}"

    def chat_with_tools(
        self,
        messages: list,
        tools: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict:
        if not self.api_key:
            return {"error": "Anthropic API key not configured"}

        system, msgs = self._convert_messages(messages)

        anthropic_tools = []
        for tool in tools:
            func = tool.get("function", {})
            anthropic_tools.append(
                {
                    "name": func.get("name"),
                    "description": func.get("description"),
                    "input_schema": func.get(
                        "parameters", {"type": "object", "properties": {}}
                    ),
                }
            )

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": msgs,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "tools": anthropic_tools,
        }
        if system:
            payload["system"] = system

        try:
            response = requests.post(
                f"{self.base_url}/v1/messages",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 429:
                return {"error": "Rate limited. Please wait a moment and try again."}
            response.raise_for_status()
            data = response.json()

            result = {"choices": [{"message": {"role": "assistant", "content": ""}}]}

            if data.get("content"):
                content_parts = []
                for block in data["content"]:
                    if block.get("type") == "text":
                        content_parts.append(block.get("text", ""))
                    elif block.get("type") == "tool_use":
                        content_parts.append("")
                        result["choices"][0]["message"]["tool_calls"] = [
                            {
                                "id": block.get("id"),
                                "type": "function",
                                "function": {
                                    "name": block.get("name"),
                                    "arguments": json.dumps(block.get("input", {})),
                                },
                            }
                        ]
                result["choices"][0]["message"]["content"] = "".join(content_parts)

            return result
        except requests.exceptions.RequestException as e:
            return {"error": f"Connection error: {str(e)}"}

    def get_available_models(self) -> list[str]:
        return [
            "claude-sonnet-4-20250514",
            "claude-sonnet-4-20250514",
            "claude-3-5-sonnet-20241022",
            "claude-3-5-haiku-20241022",
            "claude-3-opus-20240229",
        ]


class OllamaProvider(Provider):
    """Provider for local Ollama instances."""

    DEFAULT_MODEL = "llama3.2"
    BASE_URL = "http://localhost:11434"

    def __init__(self, base_url: Optional[str] = None):
        self.base_url = base_url or self.BASE_URL

    def _get_headers(self) -> dict:
        return {"Content-Type": "application/json"}

    def chat(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "stream": False,
            "options": {"num_predict": max_tokens},
        }

        try:
            response = requests.post(
                f"{self.base_url}/api/chat",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            response.raise_for_status()
            data = response.json()
            return data.get("message", {}).get("content", "")
        except requests.exceptions.RequestException as e:
            return f"Connection error: {str(e)}. Is Ollama running?"

    def chat_stream(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
        }

        try:
            response = requests.post(
                f"{self.base_url}/api/chat",
                headers=self._get_headers(),
                json=payload,
                stream=True,
                timeout=120,
            )
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line)
                        content = chunk.get("message", {}).get("content", "")
                        if content:
                            yield content
                        if chunk.get("done"):
                            break
                    except json.JSONDecodeError:
                        continue
        except requests.exceptions.RequestException as e:
            yield f"Error: {str(e)}. Is Ollama running?"

    def chat_with_tools(
        self,
        messages: list,
        tools: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict:
        ollama_tools = []
        for tool in tools:
            func = tool.get("function", {})
            ollama_tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": func.get("name"),
                        "description": func.get("description"),
                        "parameters": func.get("parameters", {}),
                    },
                }
            )

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "tools": ollama_tools,
            "temperature": temperature,
            "stream": False,
            "options": {"num_predict": max_tokens},
        }

        try:
            response = requests.post(
                f"{self.base_url}/api/chat",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            response.raise_for_status()
            data = response.json()

            msg = data.get("message", {})
            result = {
                "choices": [
                    {
                        "message": {
                            "role": msg.get("role", "assistant"),
                            "content": msg.get("content", ""),
                        }
                    }
                ]
            }

            if msg.get("tool_calls"):
                result["choices"][0]["message"]["tool_calls"] = msg["tool_calls"]

            return result
        except requests.exceptions.RequestException as e:
            return {"error": f"Connection error: {str(e)}. Is Ollama running?"}

    def get_available_models(self) -> list[str]:
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=30)
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                return sorted([m["name"] for m in models], key=lambda x: x.lower())
        except requests.exceptions.RequestException:
            pass
        return []


class GroqProvider(Provider):
    """Provider for Groq API (fast inference)."""

    DEFAULT_MODEL = "llama-3.3-70b-versatile"
    BASE_URL = "https://api.groq.com/openai/v1"

    def __init__(self, api_key: str = "", base_url: Optional[str] = None):
        self.api_key = api_key
        self.base_url = base_url or self.BASE_URL

    def _get_headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def chat(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        if not self.api_key:
            return "Error: Groq API key not configured. Set with: clawbert config --provider groq --api-key YOUR_KEY"

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 429:
                return "Error: Rate limited. Please wait a moment and try again."
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except requests.exceptions.RequestException as e:
            return f"Connection error: {str(e)}"

    def chat_stream(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        if not self.api_key:
            yield "Error: Groq API key not configured."
            return

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                stream=True,
                timeout=120,
            )
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line)
                        content = (
                            chunk.get("choices", [{}])[0]
                            .get("delta", {})
                            .get("content", "")
                        )
                        if content:
                            yield content
                        if chunk.get("choices", [{}])[0].get("finish_reason"):
                            break
                    except json.JSONDecodeError:
                        continue
        except requests.exceptions.RequestException as e:
            yield f"Error: {str(e)}"

    def chat_with_tools(
        self,
        messages: list,
        tools: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict:
        if not self.api_key:
            return {"error": "Groq API key not configured."}

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "tools": tools,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 429:
                return {"error": "Rate limited."}
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"error": f"Connection error: {str(e)}"}

    def get_available_models(self) -> list[str]:
        return [
            "llama-3.3-70b-versatile",
            "llama-3.1-70b-versatile",
            "llama-3.1-8b-instant",
            "mixtral-8x7b-32768",
            "whisper-large-v3",
        ]


class MistralProvider(Provider):
    """Provider for Mistral AI API."""

    DEFAULT_MODEL = "mistral-small-latest"
    BASE_URL = "https://api.mistral.ai/v1"

    def __init__(self, api_key: str = "", base_url: Optional[str] = None):
        self.api_key = api_key
        self.base_url = base_url or self.BASE_URL

    def _get_headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def chat(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        if not self.api_key:
            return "Error: Mistral API key not configured. Set with: clawbert config --provider mistral --api-key YOUR_KEY"

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 429:
                return "Error: Rate limited. Please wait a moment and try again."
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except requests.exceptions.RequestException as e:
            return f"Connection error: {str(e)}"

    def chat_stream(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        if not self.api_key:
            yield "Error: Mistral API key not configured."
            return

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                stream=True,
                timeout=120,
            )
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line)
                        content = (
                            chunk.get("choices", [{}])[0]
                            .get("delta", {})
                            .get("content", "")
                        )
                        if content:
                            yield content
                    except json.JSONDecodeError:
                        continue
        except requests.exceptions.RequestException as e:
            yield f"Error: {str(e)}"

    def chat_with_tools(
        self,
        messages: list,
        tools: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict:
        if not self.api_key:
            return {"error": "Mistral API key not configured."}

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "tools": tools,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 429:
                return {"error": "Rate limited."}
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"error": f"Connection error: {str(e)}"}

    def get_available_models(self) -> list[str]:
        return [
            "mistral-large-latest",
            "mistral-small-latest",
            "mistral-tiny",
            "codestral-latest",
            "mistral-embed",
        ]


class GeminiProvider(Provider):
    """Provider for Google Gemini API."""

    DEFAULT_MODEL = "gemini-2.0-flash-exp"
    BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

    def __init__(self, api_key: str = "", base_url: Optional[str] = None):
        self.api_key = api_key
        self.base_url = base_url or self.BASE_URL

    def _get_headers(self) -> dict:
        return {"Content-Type": "application/json"}

    def chat(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        if not self.api_key:
            return "Error: Gemini API key not configured. Set with: clawbert config --provider gemini --api-key YOUR_KEY"

        model = model or self.DEFAULT_MODEL
        contents = self._messages_to_contents(messages)

        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            },
        }

        try:
            response = requests.post(
                f"{self.base_url}/models/{model}:generateContent",
                headers=self._get_headers(),
                json=payload,
                params={"key": self.api_key},
                timeout=120,
            )
            if response.status_code == 429:
                return "Error: Rate limited. Please wait a moment and try again."
            response.raise_for_status()
            data = response.json()
            return (
                data.get("candidates", [{}])[0]
                .get("content", {})
                .get("parts", [{}])[0]
                .get("text", "")
            )
        except requests.exceptions.RequestException as e:
            return f"Connection error: {str(e)}"

    def chat_stream(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        if not self.api_key:
            yield "Error: Gemini API key not configured."
            return

        model = model or self.DEFAULT_MODEL
        contents = self._messages_to_contents(messages)

        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": temperature,
                "stream": True,
            },
        }

        try:
            response = requests.post(
                f"{self.base_url}/models/{model}:streamGenerateContent",
                headers=self._get_headers(),
                json=payload,
                params={"key": self.api_key},
                stream=True,
                timeout=120,
            )
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line)
                        content = (
                            chunk.get("candidates", [{}])[0]
                            .get("content", {})
                            .get("parts", [{}])[0]
                            .get("text", "")
                        )
                        if content:
                            yield content
                    except json.JSONDecodeError:
                        continue
        except requests.exceptions.RequestException as e:
            yield f"Error: {str(e)}"

    def chat_with_tools(
        self,
        messages: list,
        tools: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict:
        if not self.api_key:
            return {"error": "Gemini API key not configured."}

        model = model or self.DEFAULT_MODEL
        contents = self._messages_to_contents(messages)

        payload = {
            "contents": contents,
            "tools": tools,
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            },
        }

        try:
            response = requests.post(
                f"{self.base_url}/models/{model}:generateContent",
                headers=self._get_headers(),
                json=payload,
                params={"key": self.api_key},
                timeout=120,
            )
            if response.status_code == 429:
                return {"error": "Rate limited."}
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"error": f"Connection error: {str(e)}"}

    def _messages_to_contents(self, messages: list) -> list:
        contents = []
        for msg in messages:
            role = "user" if msg.get("role") == "user" else "model"
            contents.append({"role": role, "parts": [{"text": msg.get("content", "")}]})
        return contents

    def get_available_models(self) -> list[str]:
        return [
            "gemini-2.0-flash-exp",
            "gemini-2.0-flash",
            "gemini-1.5-pro",
            "gemini-1.5-flash",
            "gemini-1.5-flash-8b",
        ]


class ZAIProvider(Provider):
    """Provider for Z.ai API."""

    DEFAULT_MODEL = "qwen2.5-72b-instruct"
    BASE_URL = "https://api.z.ai/v1"

    def __init__(self, api_key: str = "", base_url: Optional[str] = None):
        self.api_key = api_key
        self.base_url = base_url or self.BASE_URL

    def _get_headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def chat(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        if not self.api_key:
            return "Error: Z.ai API key not configured. Set with: clawbert config --provider zai --api-key YOUR_KEY"

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 429:
                return "Error: Rate limited. Please wait a moment and try again."
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except requests.exceptions.RequestException as e:
            return f"Connection error: {str(e)}"

    def chat_stream(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        if not self.api_key:
            yield "Error: Z.ai API key not configured."
            return

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                stream=True,
                timeout=120,
            )
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line)
                        content = (
                            chunk.get("choices", [{}])[0]
                            .get("delta", {})
                            .get("content", "")
                        )
                        if content:
                            yield content
                    except json.JSONDecodeError:
                        continue
        except requests.exceptions.RequestException as e:
            yield f"Error: {str(e)}"

    def chat_with_tools(
        self,
        messages: list,
        tools: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict:
        if not self.api_key:
            return {"error": "Z.ai API key not configured."}

        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "tools": tools,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if response.status_code == 429:
                return {"error": "Rate limited."}
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"error": f"Connection error: {str(e)}"}

    def get_available_models(self) -> list[str]:
        return [
            "qwen2.5-72b-instruct",
            "qwen2.5-32b-instruct",
            "qwen2.5-14b-instruct",
            "qwen2.5-7b-instruct",
            "qwq-32b-preview",
        ]


class LMStudioProvider(Provider):
    """Provider for local LM Studio instances (OpenAI-compatible)."""

    DEFAULT_MODEL = "lmstudio-community/Qwen2.5-7B-Instruct-GGUF"
    BASE_URL = "http://localhost:1234/v1"

    def __init__(self, base_url: Optional[str] = None):
        self.base_url = base_url or self.BASE_URL
        self.api_key = "not-needed"

    def _get_headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def chat(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except requests.exceptions.RequestException as e:
            return f"Connection error: {str(e)}. Is LM Studio running?"

    def chat_stream(
        self,
        messages: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
    ) -> Iterator[str]:
        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "stream": True,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                stream=True,
                timeout=120,
            )
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line)
                        content = (
                            chunk.get("choices", [{}])[0]
                            .get("delta", {})
                            .get("content", "")
                        )
                        if content:
                            yield content
                    except json.JSONDecodeError:
                        continue
        except requests.exceptions.RequestException as e:
            yield f"Error: {str(e)}. Is LM Studio running?"

    def chat_with_tools(
        self,
        messages: list,
        tools: list,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> dict:
        payload = {
            "model": model or self.DEFAULT_MODEL,
            "messages": messages,
            "tools": tools,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"error": f"Connection error: {str(e)}. Is LM Studio running?"}

    def get_available_models(self) -> list[str]:
        try:
            response = requests.get(f"{self.base_url}/models", timeout=30)
            if response.status_code == 200:
                data = response.json()
                models = data.get("data", [])
                return sorted([m["id"] for m in models], key=lambda x: x.lower())
        except requests.exceptions.RequestException:
            pass
        return []


def get_provider(name: str, config: Optional[Any] = None) -> Provider:
    """Factory function to get a provider by name.

    Args:
        name: Provider name (openrouter, openai, anthropic, ollama, groq, mistral, gemini, zai, lmstudio).
        config: Optional config object with API keys and settings.

    Returns:
        Provider instance for the specified name.

    Raises:
        ValueError: If provider name is unknown.
    """
    name = name.lower()

    if name == "openrouter":
        return OpenRouterProvider(
            api_key=config.openrouter_api_key if config else "",
            base_url=config.openrouter_base_url if config else None,
        )
    elif name == "openai":
        return OpenAIProvider(
            api_key=config.openai_api_key if config else "",
            base_url=config.openai_base_url if config else None,
        )
    elif name == "anthropic":
        return AnthropicProvider(
            api_key=config.anthropic_api_key if config else "",
            base_url=config.anthropic_base_url if config else None,
        )
    elif name == "ollama":
        return OllamaProvider(
            base_url=config.ollama_base_url if config else None,
        )
    elif name == "groq":
        return GroqProvider(
            api_key=config.groq_api_key if config else "",
            base_url=config.groq_base_url if config else None,
        )
    elif name == "mistral":
        return MistralProvider(
            api_key=config.mistral_api_key if config else "",
            base_url=config.mistral_base_url if config else None,
        )
    elif name == "gemini":
        return GeminiProvider(
            api_key=config.gemini_api_key if config else "",
            base_url=config.gemini_base_url if config else None,
        )
    elif name == "zai":
        return ZAIProvider(
            api_key=config.zai_api_key if config else "",
            base_url=config.zai_base_url if config else None,
        )
    elif name == "lmstudio":
        return LMStudioProvider(
            base_url=config.lmstudio_base_url if config else None,
        )
    else:
        raise ValueError(f"Unknown provider: {name}")
