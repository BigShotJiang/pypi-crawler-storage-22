"""Todo/Task list system for Clawbert.

This module provides a todo/task management system that helps track
progress during complex multi-step tasks. It follows the pattern from
OpenCode and Claude Code for proactive task management.

Features:
    - Create and manage task lists
    - Track task states: pending, in_progress, completed, cancelled
    - File-based persistence across sessions
    - Proactive use for complex multi-step tasks

Task States:
    - pending: Task not yet started
    - in_progress: Currently working on (one at a time)
    - completed: Task finished successfully
    - cancelled: Task was cancelled

Example:
    from .core.todo import todo_manager

    # Add tasks
    todo_manager.add("Implement user authentication")
    todo_manager.add("Add database schema")

    # Update status
    todo_manager.update_status("1", "in_progress")

    # List tasks
    tasks = todo_manager.list_tasks()

    # Get formatted output
    output = todo_manager.get_formatted_list()
"""

import json
from pathlib import Path
from typing import Optional
from datetime import datetime
from dataclasses import dataclass, asdict


TODO_DIR = Path.home() / ".clawbert" / "todos"
TODO_FILE = TODO_DIR / "tasks.json"


@dataclass
class TodoTask:
    """Represents a single task in the todo list.

    Attributes:
        id: Unique identifier for the task.
        content: Description of what needs to be done.
        status: Current state (pending, in_progress, completed, cancelled).
        priority: Priority level (high, medium, low).
        created_at: ISO timestamp when task was created.
        updated_at: ISO timestamp when task was last updated.
    """

    id: str
    content: str
    status: str = "pending"
    priority: str = "medium"
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        if not self.updated_at:
            self.updated_at = self.created_at


class TodoManager:
    """Manages todo/task lists with file-based persistence.

        Provides methods to create, update, list, and delete tasks.
        Automatically persists to ~/./tasks.json
    clawbert/todos"""

    def __init__(self):
        self.tasks: list[TodoTask] = []
        self._load()

    def _load(self) -> None:
        """Load tasks from disk."""
        try:
            TODO_DIR.mkdir(parents=True, exist_ok=True)
            if TODO_FILE.exists():
                with open(TODO_FILE, "r") as f:
                    data = json.load(f)
                    self.tasks = [TodoTask(**t) for t in data.get("tasks", [])]
        except Exception:
            self.tasks = []

    def _save(self) -> None:
        """Save tasks to disk."""
        try:
            TODO_DIR.mkdir(parents=True, exist_ok=True)
            with open(TODO_FILE, "w") as f:
                json.dump({"tasks": [asdict(t) for t in self.tasks]}, f, indent=2)
        except Exception:
            pass

    def add(
        self, content: str, priority: str = "medium", status: str = "pending"
    ) -> str:
        """Add a new task.

        Args:
            content: Description of the task.
            priority: Priority level (high, medium, low).
            status: Initial status.

        Returns:
            The ID of the newly created task.
        """
        task_id = str(len(self.tasks) + 1)
        task = TodoTask(id=task_id, content=content, priority=priority, status=status)
        self.tasks.append(task)
        self._save()
        return task_id

    def update(
        self,
        task_id: str,
        content: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
    ) -> bool:
        """Update an existing task.

        Args:
            task_id: ID of the task to update.
            content: New description (optional).
            status: New status (optional).
            priority: New priority (optional).

        Returns:
            True if updated, False if not found.
        """
        for task in self.tasks:
            if task.id == task_id:
                if content is not None:
                    task.content = content
                if status is not None:
                    task.status = status
                if priority is not None:
                    task.priority = priority
                task.updated_at = datetime.now().isoformat()
                self._save()
                return True
        return False

    def delete(self, task_id: str) -> bool:
        """Delete a task.

        Args:
            task_id: ID of the task to delete.

        Returns:
            True if deleted, False if not found.
        """
        initial_len = len(self.tasks)
        self.tasks = [t for t in self.tasks if t.id != task_id]
        if len(self.tasks) != initial_len:
            self._save()
            return True
        return False

    def get(self, task_id: str) -> Optional[TodoTask]:
        """Get a specific task.

        Args:
            task_id: ID of the task.

        Returns:
            The task if found, None otherwise.
        """
        for task in self.tasks:
            if task.id == task_id:
                return task
        return None

    def list_tasks(
        self, status: Optional[str] = None, priority: Optional[str] = None
    ) -> list[TodoTask]:
        """List tasks with optional filters.

        Args:
            status: Filter by status (optional).
            priority: Filter by priority (optional).

        Returns:
            List of matching tasks.
        """
        result = self.tasks
        if status:
            result = [t for t in result if t.status == status]
        if priority:
            result = [t for t in result if t.priority == priority]
        return result

    def clear(self, status: Optional[str] = None) -> int:
        """Clear tasks, optionally by status.

        Args:
            status: If provided, only clear tasks with this status.

        Returns:
            Number of tasks cleared.
        """
        if status:
            initial_len = len(self.tasks)
            self.tasks = [t for t in self.tasks if t.status != status]
            cleared = initial_len - len(self.tasks)
        else:
            cleared = len(self.tasks)
            self.tasks = []
        self._save()
        return cleared

    def get_formatted_list(
        self, status: Optional[str] = None, show_completed: bool = True
    ) -> str:
        """Get formatted task list for display.

        Args:
            status: Filter by status (optional).
            show_completed: Whether to include completed tasks.

        Returns:
            Formatted string representation of task list.
        """
        tasks = self.list_tasks(status=status if status else None)

        if not show_completed:
            tasks = [t for t in tasks if t.status != "completed"]

        if not tasks:
            return "No tasks found."

        lines = []
        for task in tasks:
            status_emoji = {
                "pending": "○",
                "in_progress": "◐",
                "completed": "●",
                "cancelled": "✗",
            }.get(task.status, "○")

            priority_indicator = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(
                task.priority, "🟡"
            )

            lines.append(
                f"{status_emoji} [{task.id}] {priority_indicator} {task.content} "
                f"({task.status})"
            )

        return "\n".join(lines)

    def get_summary(self) -> str:
        """Get a summary of task counts by status.

        Returns:
            Formatted summary string.
        """
        pending = len([t for t in self.tasks if t.status == "pending"])
        in_progress = len([t for t in self.tasks if t.status == "in_progress"])
        completed = len([t for t in self.tasks if t.status == "completed"])
        cancelled = len([t for t in self.tasks if t.status == "cancelled"])

        return (
            f"Tasks: {len(self.tasks)} total | "
            f"Pending: {pending} | "
            f"In Progress: {in_progress} | "
            f"Completed: {completed} | "
            f"Cancelled: {cancelled}"
        )

    def set_from_json(self, json_str: str) -> bool:
        """Set tasks from JSON string (for TodoWrite tool).

        Args:
            json_str: JSON string containing tasks array.

        Returns:
            True if successful, False otherwise.
        """
        try:
            data = json.loads(json_str)
            if isinstance(data, list):
                tasks = []
                for i, item in enumerate(data):
                    if isinstance(item, dict):
                        tasks.append(
                            TodoTask(
                                id=str(i + 1),
                                content=item.get("content", ""),
                                status=item.get("status", "pending"),
                                priority=item.get("priority", "medium"),
                            )
                        )
                self.tasks = tasks
                self._save()
                return True
            elif isinstance(data, dict) and "tasks" in data:
                self.tasks = [TodoTask(**t) for t in data["tasks"]]
                self._save()
                return True
        except Exception:
            pass
        return False

    def to_json(self) -> str:
        """Export tasks as JSON string (for TodoRead tool).

        Returns:
            JSON string of all tasks.
        """
        return json.dumps({"tasks": [asdict(t) for t in self.tasks]}, indent=2)


todo_manager = TodoManager()
