"""Persistent memory system for Clawbert.

This module provides a simple key-value memory system that stores information
across sessions with keyword-based search capabilities.

Memories are stored as JSON index with metadata. Each memory entry contains:
    - key: Unique identifier for retrieval
    - content: The actual information to remember
    - timestamp: When the memory was stored
    - tags: Optional categories for organization

The memory system supports:
    - Storing key-value pairs
    - Keyword-based search
    - Listing all memories
    - Deleting specific memories
    - Clearing all memories

Example:
    from .memory.keyvalue import MemorySystem

    # Initialize (uses config memory_dir)
    mem = MemorySystem()

    # Store information
    mem.store("api_key", "sk-12345", tags=["credentials"])
    mem.store("project_notes", "Use Flask for this project")

    # Search memories
    results = mem.search("api")
    for r in results:
        print(f"{r['key']}: {r['content']}")

    # Retrieve specific memory
    content = mem.get("api_key")
"""

import json
from pathlib import Path
from typing import Optional
from datetime import datetime
from dataclasses import dataclass


@dataclass
class MemoryEntry:
    """Represents a single memory entry.

    Attributes:
        key: Unique identifier for the memory.
        content: The actual content to remember.
        timestamp: ISO timestamp of when the memory was created.
        tags: Optional list of tags for categorization.
    """

    key: str
    content: str
    timestamp: str
    tags: list[str]


class MemorySystem:
    """Persistent memory storage with keyword search.

    Provides functionality to store, retrieve, search, and
    manage memories that persist across sessions. Memories
    are stored both in JSON index and as individual markdown
    files for human readability.

    Attributes:
        memory_dir: Directory where memory files are stored.
        index_file: Path to the memory index JSON file.
        memories: In-memory dictionary of MemoryEntry objects.
    """

    def __init__(self, memory_dir: Optional[Path] = None):
        """Initialize the memory system.

        Args:
            memory_dir: Optional custom directory for memory storage.
                        Defaults to config memory_dir.
        """
        if memory_dir is None:
            from ..core.config import config

            memory_dir = config.memory_dir

        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.index_file = self.memory_dir / "index.json"
        self.memories: dict[str, MemoryEntry] = {}
        self._load_index()

    def _load_index(self):
        """Load memory index from JSON file.

        Reads the index file and populates the in-memory
        memories dictionary.
        """
        if self.index_file.exists():
            try:
                with open(self.index_file) as f:
                    data = json.load(f)
                    self.memories = {k: MemoryEntry(**v) for k, v in data.items()}
            except json.JSONDecodeError:
                self.memories = {}

    def _save_index(self):
        """Save memory index to JSON file.

        Writes the current state of memories to the index file
        for persistence.
        """
        data = {
            k: {
                "key": v.key,
                "content": v.content,
                "timestamp": v.timestamp,
                "tags": v.tags,
            }
            for k, v in self.memories.items()
        }
        with open(self.index_file, "w") as f:
            json.dump(data, f, indent=2)

    def store(self, key: str, content: str, tags: Optional[list[str]] = None):
        """Store a new memory entry.

        Args:
            key: Unique identifier for the memory.
            content: The content to remember.
            tags: Optional list of tags for categorization.
        """
        entry = MemoryEntry(
            key=key,
            content=content,
            timestamp=datetime.now().isoformat(),
            tags=tags or [],
        )
        self.memories[key] = entry
        self._save_index()

        md_file = self.memory_dir / f"{key}.md"
        md_file.write_text(f"""# {key}
Created: {entry.timestamp}

{content}

Tags: {", ".join(entry.tags) if entry.tags else "none"}
""")

    def get(self, key: str) -> Optional[str]:
        """Retrieve memory content by key.

        Args:
            key: The memory key to look up.

        Returns:
            The memory content, or None if not found.
        """
        entry = self.memories.get(key)
        return entry.content if entry else None

    def search(self, query: str, limit: int = 5) -> list[dict]:
        """Search memories using keyword matching.

        Performs a simple keyword-based search across memory
        keys, content, and tags. Results are ranked by relevance.

        Args:
            query: The search query string.
            limit: Maximum number of results to return.

        Returns:
            List of dicts with key, content, timestamp, and score.
        """
        query_lower = query.lower()
        results = []

        for key, entry in self.memories.items():
            score = 0
            key_lower = key.lower()
            content_lower = entry.content.lower()

            if query_lower in key_lower:
                score += 10
            if query_lower in content_lower:
                score += 5
            for tag in entry.tags:
                if query_lower in tag.lower():
                    score += 3

            if score > 0:
                results.append(
                    {
                        "key": key,
                        "content": entry.content,
                        "timestamp": entry.timestamp,
                        "score": score,
                    }
                )

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:limit]

    def delete(self, key: str) -> bool:
        """Delete a memory entry.

        Args:
            key: The memory key to delete.

        Returns:
            True if deleted, False if not found.
        """
        if key in self.memories:
            del self.memories[key]
            self._save_index()

            md_file = self.memory_dir / f"{key}.md"
            if md_file.exists():
                md_file.unlink()
            return True
        return False

    def list_all(self) -> list[dict]:
        """List all stored memories.

        Returns:
            List of dicts with key, content preview, timestamp, and tags.
        """
        return [
            {
                "key": k,
                "content": v.content[:100] + "..."
                if len(v.content) > 100
                else v.content,
                "timestamp": v.timestamp,
                "tags": v.tags,
            }
            for k, v in self.memories.items()
        ]

    def clear(self):
        """Clear all stored memories.

        Removes all memories from the index and deletes
        associated markdown files.
        """
        self.memories.clear()
        self._save_index()

        for md_file in self.memory_dir.glob("*.md"):
            if md_file.name != "index.json":
                md_file.unlink()

    MEMORY_FILES = [
        "AGENTS.md",
        "SOUL.md",
        "IDENTITY.md",
        "USER.md",
        "MEMORY.md",
        "HEARTBEAT.md",
        "BOOT.md",
    ]

    def load_memory_file(self, filename: str) -> str:
        """Load a memory file by name.

        Args:
            filename: Name of the memory file (e.g., 'AGENTS.md')

        Returns:
            File contents, or empty string if not found.
        """
        package_mem_dir = Path(__file__).parent / "files"
        package_file = package_mem_dir / filename

        if package_file.exists():
            return package_file.read_text()

        user_file = self.memory_dir / filename
        if user_file.exists():
            return user_file.read_text()

        return ""

    def load_all_memory_files(self) -> dict[str, str]:
        """Load all memory files.

        Returns:
            Dictionary mapping filename to contents.
        """
        memory_files = {}
        for filename in self.MEMORY_FILES:
            content = self.load_memory_file(filename)
            if content:
                memory_files[filename] = content
        return memory_files

    def get_memory_for_prompt(self) -> str:
        """Get all memory files formatted for system prompt.

        Returns:
            Formatted string with all memory file contents.
        """
        memory_files = self.load_all_memory_files()

        if not memory_files:
            return ""

        sections = ["## MEMORY FILES"]

        for filename, content in memory_files.items():
            section_name = filename.replace(".md", "")
            sections.append(f"\n=== {section_name} ===\n{content}")

        return "\n".join(sections)

    def save_memory_file(self, filename: str, content: str):
        """Save content to a memory file.

        Args:
            filename: Name of the memory file
            content: Content to save
        """
        user_file = self.memory_dir / filename
        user_file.parent.mkdir(parents=True, exist_ok=True)
        user_file.write_text(content)

    def list_memory_files(self) -> list[str]:
        """List available memory files.

        Returns:
            List of memory file names.
        """
        files = []

        package_mem_dir = Path(__file__).parent / "files"
        if package_mem_dir.exists():
            files.extend([f.name for f in package_mem_dir.glob("*.md")])

        if self.memory_dir.exists():
            files.extend([f.name for f in self.memory_dir.glob("*.md")])

        return sorted(set(files))
