"""Vector memory system for Clawbert.

This module provides semantic search capabilities using embeddings.
It stores memory entries with their embeddings in a SQLite database
and enables similarity-based search.

The system gracefully degrades if dependencies are not available.

Example:
    from .memory.vector import VectorMemory

    vm = VectorMemory()
    if vm.is_available():
        vm.add("api_config", "API key is sk-12345")
        results = vm.search("credentials")
        for r in results:
            print(f"{r['key']}: {r['content']} (score: {r['score']:.3f})")
"""

import sqlite3
import json
from pathlib import Path
from typing import Optional
from datetime import datetime


class EmbeddingError(Exception):
    """Raised when embedding generation fails."""

    pass


def _get_embedding_model():
    """Get the embedding model, trying multiple backends.

    Tries sentence-transformers first, falls back to a simple hash-based
    embedding if unavailable.

    Returns:
        Tuple of (model, embedding_dim, is_simple)
    """
    try:
        from sentence_transformers import SentenceTransformer

        model = SentenceTransformer("all-MiniLM-L6-v2")
        return model, 384, False
    except ImportError:
        pass

    return None, 0, True


def _compute_simple_embedding(text: str, dim: int = 384) -> list[float]:
    """Compute a simple hash-based embedding as fallback.

    This is a deterministic but not semantically meaningful embedding.
    It can be used when sentence-transformers is not available.

    Args:
        text: Text to embed.
        dim: Embedding dimension (default: 384 to match MiniLM)

    Returns:
        List of floats representing the embedding.
    """
    import hashlib

    embedding = [0.0] * dim
    text_lower = text.lower()

    for i, char in enumerate(text_lower):
        hash_input = f"{char}_{i}"
        hash_val = int(hashlib.md5(hash_input.encode()).hexdigest(), 16)
        embedding[i % dim] += (hash_val % 1000) / 1000.0

    norm = sum(x * x for x in embedding) ** 0.5
    if norm > 0:
        embedding = [x / norm for x in embedding]

    return embedding


class VectorMemory:
    """Vector-based memory storage with semantic search.

    Uses embeddings to enable similarity-based search across memory
    entries. Stores embeddings in SQLite for persistence.

    Attributes:
        db_path: Path to the SQLite database file.
        embedding_dim: Dimension of embedding vectors.
        is_available: Whether vector memory is available (dependencies installed).
        is_simple: Whether using simple hash-based embeddings.
    """

    def __init__(self, data_dir: Optional[Path] = None):
        """Initialize the vector memory system.

        Args:
            data_dir: Optional custom directory for storage.
                      Defaults to ~/.clawbert/memory/
        """
        if data_dir is None:
            from ..core.config import config

            data_dir = config.memory_dir

        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.data_dir / "vector_memory.db"

        self.model = None
        self.embedding_dim = 384
        self.is_available = False
        self.is_simple = False

        self._init_db()
        self._init_model()

    def _init_db(self):
        """Initialize the SQLite database."""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vectors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE NOT NULL,
                content TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                tags TEXT,
                embedding BLOB NOT NULL
            )
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_key ON vectors(key)
        """)
        conn.commit()
        conn.close()

    def _init_model(self):
        """Initialize the embedding model."""
        model, dim, is_simple = _get_embedding_model()

        if model is not None:
            self.model = model
            self.embedding_dim = dim
            self.is_available = True
            self.is_simple = False
        else:
            self.embedding_dim = dim
            self.is_available = True
            self.is_simple = True

    def _get_embedding(self, text: str) -> list[float]:
        """Get embedding for text.

        Args:
            text: Text to embed.

        Returns:
            Embedding vector as list of floats.
        """
        if self.model is not None:
            return self.model.encode(text).tolist()
        return _compute_simple_embedding(text, self.embedding_dim)

    def _blob_to_list(self, blob: bytes) -> list[float]:
        """Convert blob to list of floats."""
        import struct

        count = len(blob) // 4
        return list(struct.unpack(f"{count}f", blob))

    def _list_to_blob(self, emb: list[float]) -> bytes:
        """Convert list of floats to blob."""
        import struct

        return struct.pack(f"{len(emb)}f", *emb)

    def _cosine_similarity(self, a: list[float], b: list[float]) -> float:
        """Compute cosine similarity between two vectors."""
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x * x for x in a) ** 0.5
        norm_b = sum(x * x for x in b) ** 0.5
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)

    def add(self, key: str, content: str, tags: Optional[list[str]] = None):
        """Add a memory entry with its embedding.

        Args:
            key: Unique identifier for the memory.
            content: Content to remember.
            tags: Optional list of tags.
        """
        if not self.is_available:
            return

        embedding = self._get_embedding(content)
        blob = self._list_to_blob(embedding)

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT OR REPLACE INTO vectors (key, content, timestamp, tags, embedding)
            VALUES (?, ?, ?, ?, ?)
        """,
            (key, content, datetime.now().isoformat(), json.dumps(tags or []), blob),
        )

        conn.commit()
        conn.close()

    def search(self, query: str, limit: int = 5) -> list[dict]:
        """Search memories using semantic similarity.

        Args:
            query: Search query.
            limit: Maximum number of results.

        Returns:
            List of dicts with key, content, timestamp, score.
        """
        if not self.is_available:
            return []

        query_embedding = self._get_embedding(query)

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute("SELECT key, content, timestamp, tags, embedding FROM vectors")
        rows = cursor.fetchall()
        conn.close()

        results = []
        for key, content, timestamp, tags, blob in rows:
            emb = self._blob_to_list(blob)
            score = self._cosine_similarity(query_embedding, emb)

            if score > 0.01:
                results.append(
                    {
                        "key": key,
                        "content": content,
                        "timestamp": timestamp,
                        "tags": json.loads(tags) if tags else [],
                        "score": score,
                    }
                )

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:limit]

    def get(self, key: str) -> Optional[str]:
        """Get memory content by key.

        Args:
            key: Memory key to look up.

        Returns:
            Content or None if not found.
        """
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute("SELECT content FROM vectors WHERE key = ?", (key,))
        row = cursor.fetchone()
        conn.close()

        return row[0] if row else None

    def delete(self, key: str) -> bool:
        """Delete a memory entry.

        Args:
            key: Memory key to delete.

        Returns:
            True if deleted, False if not found.
        """
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute("DELETE FROM vectors WHERE key = ?", (key,))
        deleted = cursor.rowcount > 0

        conn.commit()
        conn.close()

        return deleted

    def list_all(self) -> list[dict]:
        """List all stored memories.

        Returns:
            List of dicts with key, content preview, timestamp, tags.
        """
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute("SELECT key, content, timestamp, tags FROM vectors")
        rows = cursor.fetchall()
        conn.close()

        return [
            {
                "key": key,
                "content": content[:100] + "..." if len(content) > 100 else content,
                "timestamp": timestamp,
                "tags": json.loads(tags) if tags else [],
            }
            for key, content, timestamp, tags in rows
        ]

    def clear(self):
        """Clear all vector memories."""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute("DELETE FROM vectors")
        conn.commit()
        conn.close()

    def reindex_all(self, memory_system=None):
        """Reindex all memories from the main memory system.

        Args:
            memory_system: Optional MemorySystem instance to index from.
                          If not provided, creates one.
        """
        if not self.is_available:
            return

        if memory_system is None:
            from .keyvalue import MemorySystem

            memory_system = MemorySystem()

        self.clear()

        for key, entry in memory_system.memories.items():
            self.add(key, entry.content, entry.tags)


vector_memory = VectorMemory()
