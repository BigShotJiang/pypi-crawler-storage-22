"""FastAPI-based REST API server for Clawbert.

This module provides a REST API server that exposes Clawbert's functionality
over HTTP with optional authentication and WebSocket support for streaming.

Endpoints:
    - POST /chat - Send a message and get response
    - GET /sessions - List sessions
    - GET /sessions/{id} - Get session history
    - POST /sessions - Create new session
    - DELETE /sessions/{id} - Delete session
    - GET /memory - Search memory
    - POST /memory - Store memory
    - GET /skills - List skills
    - GET /config - Get config
    - WS /ws/chat - WebSocket streaming chat

Example:
    # Start server
    clawbert api --port 8000 --api-key secret123

    # API calls
    curl -X POST http://localhost:8000/chat \
        -H "Content-Type: application/json" \
        -H "X-API-Key: secret123" \
        -d '{"message": "Hello!", "session_id": "optional_session_id"}'
"""

import json
from typing import Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from ..core.config import config
from ..core.llm import LLMClient
from ..tools.registry import tool_registry
from ..skills.registry import skill_registry
from ..memory.keyvalue import MemorySystem
from ..session.manager import session_manager
from .telemetry import usage_tracker

_api_key_setting: Optional[str] = None


async def verify_api_key(api_key: Optional[str] = None) -> bool:
    """Verify API key if authentication is enabled."""
    if not _api_key_setting:
        return True
    return api_key == _api_key_setting


class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    stream: bool = False
    temperature: float = 0.7
    max_tokens: int = 4096


class ChatResponse(BaseModel):
    response: str
    session_id: str
    message_count: int


class SessionCreateRequest(BaseModel):
    name: Optional[str] = None


class MemoryStoreRequest(BaseModel):
    key: str
    content: str
    tags: Optional[list[str]] = None


class ChatWebSocketManager:
    """Manages WebSocket connections for streaming chat."""

    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def send_message(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)


ws_manager = ChatWebSocketManager()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup/shutdown."""
    yield


def create_app(
    api_key: Optional[str] = None,
    cors_origins: Optional[list[str]] = None,
) -> FastAPI:
    """Create and configure FastAPI application."""
    global _api_key_setting
    if api_key:
        _api_key_setting = api_key

    if cors_origins is None:
        cors_origins = ["*"]

    app = FastAPI(
        title="Clawbert API",
        description="REST API for Clawbert AI Assistant",
        version="0.0.3-alpha-23",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    def build_system_prompt(active_skill: str = "general") -> str:
        """Build system prompt based on current active skill."""
        skill = skill_registry.get(active_skill)
        skill_instructions = skill.instructions if skill else ""
        skill_context = skill_registry.get_skill_descriptions()
        memory = MemorySystem()
        memory_context = memory.get_memory_for_prompt()

        return f"""You are Clawbert, a CLI AI assistant.

## CURRENT DATE: February 2026
Always search for the MOST UP-TO-DATE information.

{memory_context}

## ACTIVE SKILL: {active_skill.upper()}
{skill_instructions}

## AVAILABLE SKILLS
Use any of these skills automatically when the task matches their description:

{skill_context}

## AVAILABLE TOOLS
{", ".join(config.enabled_tools)}

Remember to use tools when appropriate. Be concise and helpful."""

    def build_messages(
        user_message: str,
        session_id: Optional[str] = None,
        active_skill: str = "general",
    ):
        """Build message list with system prompt and history."""
        messages = [{"role": "system", "content": build_system_prompt(active_skill)}]

        if session_id:
            msgs = session_manager.get_messages(session_id)
            messages.extend(msgs)

        messages.append({"role": "user", "content": user_message})
        return messages

    def handle_tool_calls(msg, messages, current_tools, depth=0):
        """Handle tool calls from LLM response."""
        if depth > 20:
            return "Too many tool calls (max 100).", messages

        if not msg.get("tool_calls"):
            return msg.get("content", ""), messages

        for tool_call in msg["tool_calls"]:
            func_name = tool_call["function"]["name"]
            func_args = tool_call["function"]["arguments"]

            if isinstance(func_args, str):
                func_args = json.loads(func_args)

            tool = tool_registry.get_tool(func_name)
            if tool:
                result = tool.func(**func_args)

                messages.append(
                    {"role": "assistant", "content": None, "tool_calls": [tool_call]}
                )
                messages.append(
                    {"role": "tool", "tool_call_id": tool_call["id"], "content": result}
                )

        llm = LLMClient()
        result = llm.chat_with_tools(messages, current_tools)
        if "error" in result:
            return result["error"], messages
        msg = result.get("choices", [{}])[0].get("message", {})

        if msg.get("tool_calls"):
            return handle_tool_calls(msg, messages, current_tools, depth + 1)

        return msg.get("content", ""), messages

    @app.get("/")
    async def root():
        """Root endpoint."""
        return {"message": "Clawbert API", "version": "0.0.2-alpha-13"}

    @app.get("/health")
    async def health():
        """Health check endpoint."""
        return {"status": "healthy"}

    @app.post("/chat", response_model=ChatResponse)
    async def chat(request: ChatRequest, api_key: Optional[str] = None):
        """Send a message and get response."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        api_key_check = config.get_provider_api_key()
        if not api_key_check and config.model_provider != "ollama":
            raise HTTPException(status_code=400, detail="API key not configured")

        session = None
        if request.session_id:
            session = session_manager.get(request.session_id)
            if not session:
                raise HTTPException(status_code=404, detail="Session not found")
        else:
            session = session_manager.create("API Chat")

        messages = build_messages(request.message, session.id, session.active_skill)

        active_skill = skill_registry.get(session.active_skill)
        skill_tools = active_skill.allowed_tools if active_skill else []
        prompt_tools = [
            t
            for t in tool_registry.get_available_tools()
            if t["function"]["name"] in config.enabled_tools
            and (not skill_tools or t["function"]["name"] in skill_tools)
        ]

        llm = LLMClient()

        if prompt_tools:
            result = llm.chat_with_tools(
                messages,
                prompt_tools,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
            )
            if "error" in result:
                raise HTTPException(status_code=500, detail=result["error"])
            msg = result.get("choices", [{}])[0].get("message", {})
            response, messages = handle_tool_calls(msg, messages, prompt_tools)
        else:
            response = llm.chat(
                messages, temperature=request.temperature, max_tokens=request.max_tokens
            )

        session_manager.add_message(session.id, "user", request.message)
        session_manager.add_message(session.id, "assistant", response)

        return ChatResponse(
            response=response,
            session_id=session.id,
            message_count=len(session.messages),
        )

    @app.get("/sessions")
    async def list_sessions(api_key: Optional[str] = None):
        """List all sessions."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")
        return session_manager.list_sessions()

    @app.get("/sessions/{session_id}")
    async def get_session(session_id: str, api_key: Optional[str] = None):
        """Get session history."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        session = session_manager.get(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        return {
            "id": session.id,
            "name": session.name,
            "created_at": session.created_at,
            "active_skill": session.active_skill,
            "messages": [
                {"role": m.role, "content": m.content} for m in session.messages
            ],
        }

    @app.post("/sessions")
    async def create_session(
        request: SessionCreateRequest, api_key: Optional[str] = None
    ):
        """Create a new session."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        session = session_manager.create(request.name or None)
        return {
            "id": session.id,
            "name": session.name,
            "created_at": session.created_at,
        }

    @app.delete("/sessions/{session_id}")
    async def delete_session(session_id: str, api_key: Optional[str] = None):
        """Delete a session."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        if session_manager.delete(session_id):
            return {"message": "Session deleted"}
        raise HTTPException(status_code=404, detail="Session not found")

    @app.get("/memory")
    async def search_memory(q: str, limit: int = 5, api_key: Optional[str] = None):
        """Search memory."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        mem = MemorySystem()
        results = mem.search(q, limit=limit)
        return {"results": results}

    @app.post("/memory")
    async def store_memory(request: MemoryStoreRequest, api_key: Optional[str] = None):
        """Store memory."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        mem = MemorySystem()
        mem.store(request.key, request.content, request.tags)
        return {"message": "Memory stored", "key": request.key}

    @app.get("/skills")
    async def list_skills(api_key: Optional[str] = None):
        """List all skills."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        return [
            {
                "name": name,
                "version": skill.version,
                "description": skill.description,
                "allowed_tools": skill.allowed_tools,
                "enabled": skill.enabled,
            }
            for name, skill in skill_registry.skills.items()
        ]

    @app.get("/config")
    async def get_config(api_key: Optional[str] = None):
        """Get current configuration (without API keys)."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        return {
            "model_provider": config.model_provider,
            "default_model": config.default_model,
            "temperature": config.temperature,
            "max_tokens": config.max_tokens,
            "enabled_tools": config.enabled_tools,
            "enabled_skills": config.enabled_skills,
        }

    @app.put("/config")
    async def update_config(request: dict, api_key: Optional[str] = None):
        """Update configuration."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        if "model_provider" in request:
            config.model_provider = request["model_provider"]
        if "default_model" in request:
            config.default_model = request["default_model"]
        if "temperature" in request:
            config.temperature = request["temperature"]
        if "max_tokens" in request:
            config.max_tokens = request["max_tokens"]
        if "enabled_tools" in request:
            config.enabled_tools = request["enabled_tools"]
        if "enabled_skills" in request:
            config.enabled_skills = request["enabled_skills"]
        config.save()
        return {"message": "Configuration updated"}

    @app.get("/tools")
    async def list_tools(api_key: Optional[str] = None):
        """List all available tools."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        return [
            {
                "name": name,
                "description": tool.description,
                "parameters": tool.parameters,
            }
            for name, tool in tool_registry.tools.items()
        ]

    @app.get("/usage")
    async def get_usage(days: int = 30, api_key: Optional[str] = None):
        """Get usage statistics."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        return usage_tracker.get_stats(days)

    @app.delete("/memory/{key}")
    async def delete_memory(key: str, api_key: Optional[str] = None):
        """Delete a memory entry."""
        if not await verify_api_key(api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")

        mem = MemorySystem()
        if mem.delete(key):
            return {"message": "Memory deleted"}
        raise HTTPException(status_code=404, detail="Memory not found")

    @app.websocket("/ws/chat")
    async def websocket_chat(websocket: WebSocket):
        """WebSocket endpoint for streaming chat."""
        await ws_manager.connect(websocket)
        try:
            await websocket.send_json(
                {"type": "connected", "message": "WebSocket connected"}
            )

            session = session_manager.create("WebSocket Chat")
            await websocket.send_json({"type": "session", "session_id": session.id})

            active_skill = session.active_skill

            while True:
                data = await websocket.receive_text()
                request_data = json.loads(data)

                message = request_data.get("message", "")
                if not message:
                    continue

                await websocket.send_json({"type": "message_start", "role": "user"})
                await websocket.send_json(
                    {"type": "message_content", "content": message}
                )
                await websocket.send_json({"type": "message_end"})

                messages = build_messages(message, session.id, active_skill)

                active_skill_obj = skill_registry.get(active_skill)
                skill_tools = active_skill_obj.allowed_tools if active_skill_obj else []
                prompt_tools = [
                    t
                    for t in tool_registry.get_available_tools()
                    if t["function"]["name"] in config.enabled_tools
                    and (not skill_tools or t["function"]["name"] in skill_tools)
                ]

                llm = LLMClient()

                if prompt_tools:
                    result = llm.chat_with_tools(messages, prompt_tools)
                    if "error" in result:
                        await websocket.send_json(
                            {"type": "error", "message": result["error"]}
                        )
                        continue
                    msg = result.get("choices", [{}])[0].get("message", {})
                    response, messages = handle_tool_calls(msg, messages, prompt_tools)
                else:
                    response = ""
                    for chunk in llm.chat_stream(messages):
                        await websocket.send_json({"type": "content", "chunk": chunk})
                        response += chunk

                await websocket.send_json({"type": "message_end"})

                session_manager.add_message(session.id, "user", message)
                session_manager.add_message(session.id, "assistant", response)

        except WebSocketDisconnect:
            ws_manager.disconnect(websocket)
        except Exception as e:
            await websocket.send_json({"type": "error", "message": str(e)})
            ws_manager.disconnect(websocket)

    return app


def run_server(
    host: str = "0.0.0.0",
    port: int = 8000,
    api_key: Optional[str] = None,
    cors_origins: Optional[list[str]] = None,
    no_api: bool = False,
):
    """Run the API server."""
    import uvicorn

    app = create_app(api_key=api_key, cors_origins=cors_origins)

    uvicorn.run(
        app,
        host=host,
        port=port,
        log_level="info",
    )
