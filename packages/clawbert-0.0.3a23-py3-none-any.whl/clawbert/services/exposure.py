"""Headscale/Tailscale integration for Clawbert.

This module provides integration with Headscale/Tailscale for remote access.
"""

import subprocess
import os
from typing import Optional
from dataclasses import dataclass


@dataclass
class ExposureConfig:
    mode: str  # "local", "tailscale", "headscale"
    host: str = "0.0.0.0"
    port: int = 8080
    api_key: Optional[str] = None
    headscale_url: Optional[str] = None
    headscale_api_key: Optional[str] = None


class ExposureManager:
    """Manages remote exposure options for Clawbert."""

    def __init__(self, config: Optional[ExposureConfig] = None):
        self.config = config or ExposureConfig(mode="local")

    def is_tailscale_installed(self) -> bool:
        """Check if Tailscale is installed."""
        try:
            subprocess.run(
                ["tailscale", "--version"],
                capture_output=True,
                check=True,
            )
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def is_headscale_installed(self) -> bool:
        """Check if headscale client is installed."""
        try:
            subprocess.run(
                ["tailscale", "--version"],
                capture_output=True,
                check=True,
            )
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def get_tailscale_status(self) -> dict:
        """Get Tailscale connection status."""
        try:
            result = subprocess.run(
                ["tailscale", "status", "--json"],
                capture_output=True,
                text=True,
                check=True,
            )
            import json

            return json.loads(result.stdout)
        except Exception as e:
            return {"error": str(e), "connected": False}

    def get_tailnet_ip(self) -> Optional[str]:
        """Get the tailnet IP address."""
        try:
            result = subprocess.run(
                ["tailscale", "ip", "-4"],
                capture_output=True,
                text=True,
                check=True,
            )
            return result.stdout.strip()
        except Exception:
            return None

    def expose_local(self, host: str = "0.0.0.0", port: int = 8080) -> str:
        """Start local exposure (no VPN).

        Args:
            host: Host to bind to
            port: Port to listen on

        Returns:
            URL to access the service
        """
        return f"http://{host}:{port}"

    def expose_tailscale_serve(self, port: int = 8080, https: bool = False) -> str:
        """Expose service via Tailscale Serve.

        Args:
            port: Local port to expose
            https: Use HTTPS

        Returns:
            Tailscale URL or error message
        """
        if not self.is_tailscale_installed():
            return "Error: Tailscale not installed"

        try:
            cmd = ["tailscale", "serve", str(port)]
            if https:
                cmd.append("--https=443")

            subprocess.run(cmd, check=True)

            tailnet_ip = self.get_tailnet_ip()
            if tailnet_ip:
                scheme = "https" if https else "http"
                return f"{scheme}://{tailnet_ip}"
            return "Tailscale serve enabled"
        except subprocess.CalledProcessError as e:
            return f"Error: {e.stderr}"

    def expose_tailscale_funnel(self, port: int = 8080) -> str:
        """Expose service via Tailscale Funnel (public).

        Args:
            port: Local port to expose

        Returns:
            Funnel URL or error message
        """
        if not self.is_tailscale_installed():
            return "Error: Tailscale not installed"

        try:
            subprocess.run(
                ["tailscale", "funnel", str(port)],
                check=True,
            )

            result = subprocess.run(
                ["tailscale", "funnel", "status", "--json"],
                capture_output=True,
                text=True,
            )

            import json

            data = json.loads(result.stdout)
            if data.get("enabled"):
                return f"Funnel enabled: {data.get('url', 'Check status')}"
            return "Funnel enabled"
        except Exception as e:
            return f"Error: {e}"

    def expose_headscale(self, port: int = 8080, headscale_url: str = "") -> str:
        """Expose service via Headscale.

        Note: Headscale doesn't have native serve/funnel like Tailscale.
        This uses the Tailscale client connected to a Headscale server.

        Args:
            port: Local port to expose
            headscale_url: Headscale server URL

        Returns:
            Status message
        """
        if not self.is_headscale_installed():
            return "Error: Tailscale client not installed"

        if headscale_url:
            os.environ["HEADSCALE_URL"] = headscale_url

        tailnet_ip = self.get_tailnet_ip()
        if tailnet_ip:
            return f"Connected to Headscale. Access at: http://{tailnet_ip}:{port}"
        return "Headscale: Not connected to tailnet"

    def disable_exposure(self) -> str:
        """Disable all exposure options."""
        try:
            subprocess.run(["tailscale", "serve", "reset"], capture_output=True)
        except Exception:
            pass

        try:
            subprocess.run(["tailscale", "funnel", "reset"], capture_output=True)
        except Exception:
            pass

        return "Exposure disabled"

    def get_status(self) -> dict:
        """Get current exposure status."""
        status = {
            "mode": self.config.mode,
            "tailscale_installed": self.is_tailscale_installed(),
            "connected": False,
            "tailnet_ip": None,
            "urls": [],
        }

        if status["tailscale_installed"]:
            ts_status = self.get_tailscale_status()
            status["connected"] = ts_status.get("BackendState") == "Running"
            status["tailnet_ip"] = self.get_tailnet_ip()

        return status


def create_exposure_manager(
    mode: str = "local",
    headscale_url: Optional[str] = None,
    headscale_api_key: Optional[str] = None,
) -> ExposureManager:
    """Create an ExposureManager instance.

    Args:
        mode: Exposure mode (local, tailscale, headscale)
        headscale_url: Headscale server URL
        headscale_api_key: Headscale API key

    Returns:
        Configured ExposureManager
    """
    config = ExposureConfig(
        mode=mode,
        headscale_url=headscale_url,
        headscale_api_key=headscale_api_key,
    )
    return ExposureManager(config)
