"""MCP (Model Context Protocol) support for Clawbert.

This module provides MCP client and server functionality:
- MCPClient: Connect to MCP servers via stdio or HTTP
- MCPServer: Expose Clawbert tools as an MCP server

MCP is a protocol from Anthropic for AI-tool integration using JSON-RPC 2.0.
"""

import json
import subprocess
from typing import Any, Optional
from dataclasses import dataclass


PROTOCOL_VERSION = "2024-11-05"


@dataclass
class MCPTool:
    """Represents an MCP tool definition."""

    name: str
    description: str
    input_schema: dict


class MCPConnection:
    """Base class for MCP connections."""

    def __init__(self):
        self._request_id = 0

    def _next_id(self) -> int:
        self._request_id += 1
        return self._request_id

    def _create_request(self, method: str, params: Optional[dict] = None) -> dict:
        request = {
            "jsonrpc": "2.0",
            "id": self._next_id(),
            "method": method,
        }
        if params:
            request["params"] = params
        return request

    def _create_notification(self, method: str, params: Optional[dict] = None) -> dict:
        notification = {
            "jsonrpc": "2.0",
            "method": method,
        }
        if params:
            notification["params"] = params
        return notification


class StdioMCPConnection(MCPConnection):
    """MCP connection over stdio (local subprocess)."""

    def __init__(
        self, command: str, args: Optional[list[str]] = None, env: Optional[dict] = None
    ):
        super().__init__()
        self.command = command
        self.args = args or []
        self.env = env or {}
        self.process: Optional[subprocess.Popen] = None

    async def connect(self) -> dict:
        """Connect to the MCP server via stdio."""
        merged_env = {**dict(__import__("os").environ), **self.env}

        self.process = subprocess.Popen(
            [self.command] + self.args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=merged_env,
            text=True,
            bufsize=1,
        )

        init_result = await self._initialize()
        return init_result

    async def _initialize(self) -> dict:
        """Perform MCP initialization handshake."""
        request = self._create_request(
            "initialize",
            {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "clawbert", "version": "0.0.2-alpha-13"},
            },
        )

        self._send(request)
        response = self._receive()

        notify = self._create_notification("notifications/initialized")
        self._send(notify)

        return response

    def _send(self, message: dict):
        """Send a JSON-RPC message."""
        if self.process and self.process.stdin:
            self.process.stdin.write(json.dumps(message) + "\n")
            self.process.stdin.flush()

    def _receive(self) -> dict:
        """Receive a JSON-RPC message."""
        if self.process and self.process.stdout:
            line = self.process.stdout.readline()
            if line:
                return json.loads(line)
        return {
            "jsonrpc": "2.0",
            "id": 0,
            "error": {"code": -1, "message": "No response"},
        }

    async def call_method(self, method: str, params: Optional[dict] = None) -> dict:
        """Call an MCP method."""
        request = self._create_request(method, params)
        self._send(request)
        return self._receive()

    def close(self):
        """Close the stdio connection."""
        if self.process:
            self.process.terminate()
            self.process.wait(timeout=5)


class HTTPMCPConnection(MCPConnection):
    """MCP connection over HTTP with SSE."""

    def __init__(self, base_url: str, headers: Optional[dict] = None):
        super().__init__()
        self.base_url = base_url.rstrip("/")
        self.headers = headers or {}
        self._session = None

    async def connect(self) -> dict:
        """Connect to the MCP server via HTTP."""
        import aiohttp

        self._session = aiohttp.ClientSession(headers=self.headers)

        init_result = await self._initialize()
        return init_result

    async def _initialize(self) -> dict:
        """Perform MCP initialization handshake."""
        request = self._create_request(
            "initialize",
            {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "clawbert", "version": "0.0.2-alpha-13"},
            },
        )

        response = await self._post(request)

        await self._send_notification("notifications/initialized", {})

        return response

    async def _post(self, message: dict) -> dict:
        """Send POST request to MCP server."""
        if not self._session:
            return {
                "jsonrpc": "2.0",
                "id": 0,
                "error": {"code": -1, "message": "Not connected"},
            }

        try:
            async with self._session.post(
                f"{self.base_url}/messages", json=message
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data
                return {
                    "jsonrpc": "2.0",
                    "id": message.get("id", 0),
                    "error": {"code": resp.status, "message": f"HTTP {resp.status}"},
                }
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": message.get("id", 0),
                "error": {"code": -1, "message": str(e)},
            }

    async def _send_notification(self, method: str, params: dict):
        """Send a notification (no response expected)."""
        notification = self._create_notification(method, params)
        await self._post(notification)

    async def call_method(self, method: str, params: Optional[dict] = None) -> dict:
        """Call an MCP method."""
        request = self._create_request(method, params)
        return await self._post(request)

    async def close(self):
        """Close the HTTP connection."""
        if self._session:
            await self._session.close()


class MCPClient:
    """MCP Client for connecting to MCP servers.

    Supports both stdio and HTTP transports.

    Example:
        # Connect via stdio
        client = MCPClient()
        await client.connect_stdio("python", ["server.py"])

        # Or connect via HTTP
        client = MCPClient()
        await client.connect_http("http://localhost:8080")

        # List tools
        tools = await client.list_tools()

        # Call a tool
        result = await client.call_tool("tool_name", {"arg": "value"})

        # Disconnect
        await client.disconnect()
    """

    def __init__(self):
        self.connection: Optional[MCPConnection] = None
        self.server_info: Optional[dict] = None
        self.tools: list[MCPTool] = []

    async def connect_stdio(
        self, command: str, args: Optional[list[str]] = None, env: Optional[dict] = None
    ) -> str:
        """Connect to an MCP server via stdio.

        Args:
            command: The command to run (e.g., "python", "node")
            args: Command-line arguments (e.g., ["server.py"])
            env: Optional environment variables

        Returns:
            Success message with server info
        """
        self.connection = StdioMCPConnection(command, args, env)
        result = await self.connection.connect()
        self.server_info = result.get("result", {}).get("serverInfo", {})
        await self.list_tools()
        return f"Connected to {self.server_info.get('name', 'MCP server')}"

    async def connect_http(self, url: str, headers: Optional[dict] = None) -> str:
        """Connect to an MCP server via HTTP/SSE.

        Args:
            url: Base URL of the MCP server
            headers: Optional HTTP headers

        Returns:
            Success message with server info
        """
        self.connection = HTTPMCPConnection(url, headers)
        result = await self.connection.connect()
        self.server_info = result.get("result", {}).get("serverInfo", {})
        await self.list_tools()
        return f"Connected to {self.server_info.get('name', 'MCP server')}"

    async def list_tools(self) -> list[dict]:
        """List available tools from the MCP server.

        Returns:
            List of tool definitions
        """
        if not self.connection:
            return []

        response = await self.connection.call_method("tools/list", {})
        tools_data = response.get("result", {}).get("tools", [])

        self.tools = [
            MCPTool(
                name=t.get("name", ""),
                description=t.get("description", ""),
                input_schema=t.get("inputSchema", {}),
            )
            for t in tools_data
        ]

        return [
            {"name": t.name, "description": t.description, "parameters": t.input_schema}
            for t in self.tools
        ]

    async def call_tool(self, name: str, arguments: Optional[dict] = None) -> Any:
        """Call a tool on the MCP server.

        Args:
            name: Name of the tool to call
            arguments: Tool arguments

        Returns:
            Tool execution result
        """
        if not self.connection:
            return {"error": "Not connected to MCP server"}

        response = await self.connection.call_method(
            "tools/call", {"name": name, "arguments": arguments or {}}
        )

        result = response.get("result", {})
        if "content" in result:
            contents = result["content"]
            if contents and isinstance(contents, list):
                return contents[0].get("text", str(contents))
        return result

    async def disconnect(self):
        """Disconnect from the MCP server."""
        if self.connection:
            await self.connection.close()
            self.connection = None
            self.tools = []
            self.server_info = None


class MCPServer:
    """MCP Server that exposes Clawbert tools.

    Supports stdio and HTTP transports.

    Example:
        # Create server
        server = MCPServer()

        # Add tools from tool registry
        from .tools import tool_registry
        for tool in tool_registry.tools.values():
            server.add_tool(tool.name, tool.description, tool.parameters)

        # Run as stdio server
        server.run_stdio()

        # Or run as HTTP server
        server.run_http(host="0.0.0.0", port=8080)
    """

    def __init__(self, name: str = "clawbert", version: str = "0.0.3-alpha-23"):
        self.name = name
        self.version = version
        self.tools: dict[str, dict] = {}
        self._initialized = False

    def add_tool(self, name: str, description: str, input_schema: dict):
        """Add a tool to the server.

        Args:
            name: Tool name
            description: Tool description
            input_schema: JSON schema for tool parameters
        """
        self.tools[name] = {
            "name": name,
            "description": description,
            "inputSchema": input_schema,
        }

    def _handle_initialize(self, params: dict) -> dict:
        """Handle initialize request."""
        self._initialized = True
        return {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": self.name, "version": self.version},
        }

    def _handle_tools_list(self, params: dict) -> dict:
        """Handle tools/list request."""
        return {"tools": list(self.tools.values())}

    def _handle_tools_call(self, params: dict) -> dict:
        """Handle tools/call request."""
        from ..tools.registry import tool_registry

        name = params.get("name")
        arguments = params.get("arguments", {})

        if name not in self.tools:
            return {"error": {"code": -32601, "message": f"Tool not found: {name}"}}

        tool = tool_registry.get_tool(name)
        if not tool:
            return {
                "error": {
                    "code": -32601,
                    "message": f"Tool implementation not found: {name}",
                }
            }

        try:
            result = tool.func(**arguments)
            return {"content": [{"type": "text", "text": str(result)}]}
        except Exception as e:
            return {"content": [{"type": "text", "text": f"Error: {str(e)}"}]}

    def _handle_request(self, request: dict) -> dict:
        """Handle a JSON-RPC request."""
        method = request.get("method")
        params = request.get("params", {})
        msg_id = request.get("id")

        handlers = {
            "initialize": self._handle_initialize,
            "tools/list": self._handle_tools_list,
            "tools/call": self._handle_tools_call,
        }

        if method not in handlers:
            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "error": {"code": -32601, "message": f"Method not found: {method}"},
            }

        try:
            result = handlers[method](params)
            return {"jsonrpc": "2.0", "id": msg_id, "result": result}
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "error": {"code": -32603, "message": f"Internal error: {str(e)}"},
            }

    def run_stdio(self):
        """Run the MCP server over stdio."""
        import sys

        while True:
            try:
                line = sys.stdin.readline()
                if not line:
                    break

                request = json.loads(line)
                method = request.get("method")

                if method == "notifications/initialized":
                    continue

                response = self._handle_request(request)

                if response:
                    print(json.dumps(response), flush=True)

            except EOFError:
                break
            except Exception as e:
                error_response = {
                    "jsonrpc": "2.0",
                    "id": 0,
                    "error": {"code": -32603, "message": str(e)},
                }
                print(json.dumps(error_response), flush=True)

    def run_http(self, host: str = "0.0.0.0", port: int = 8080):
        """Run the MCP server over HTTP with SSE.

        Args:
            host: Host to bind to
            port: Port to listen on
        """
        try:
            from fastapi import FastAPI, Request
            from fastapi.responses import JSONResponse
            import uvicorn
            from sse_starlette.sse import EventSourceResponse
            import asyncio
        except ImportError:
            print("Error: fastapi and sse-starlette required for HTTP server")
            print("Install with: pip install fastapi uvicorn sse-starlette")
            return

        app = FastAPI()
        clients = set()

        @app.get("/sse")
        async def sse_endpoint(request: Request):
            async def event_generator():
                client_id = id(request)
                clients.add(client_id)
                try:
                    while True:
                        await asyncio.sleep(1)
                        yield {"event": "ping", "data": "alive"}
                finally:
                    clients.discard(client_id)

            return EventSourceResponse(event_generator())

        @app.post("/messages")
        async def messages_endpoint(request: Request):
            body = await request.json()
            method = body.get("method")

            if method == "initialize":
                response = self._handle_initialize(body.get("params", {}))
                return JSONResponse(
                    {"jsonrpc": "2.0", "id": body.get("id"), "result": response}
                )

            elif method == "notifications/initialized":
                return JSONResponse({"jsonrpc": "2.0"})

            elif method == "tools/list":
                response = self._handle_tools_list(body.get("params", {}))
                return JSONResponse(
                    {"jsonrpc": "2.0", "id": body.get("id"), "result": response}
                )

            elif method == "tools/call":
                response = self._handle_tools_call(body.get("params", {}))
                return JSONResponse(
                    {"jsonrpc": "2.0", "id": body.get("id"), "result": response}
                )

            return JSONResponse(
                {
                    "jsonrpc": "2.0",
                    "id": body.get("id"),
                    "error": {"code": -32601, "message": f"Method not found: {method}"},
                }
            )

        print(f"Starting MCP server on http://{host}:{port}")
        print("Endpoints:")
        print(f"  - SSE: http://{host}:{port}/sse")
        print(f"  - Messages: http://{host}:{port}/messages")

        uvicorn.run(app, host=host, port=port)


mcp_client = MCPClient()
