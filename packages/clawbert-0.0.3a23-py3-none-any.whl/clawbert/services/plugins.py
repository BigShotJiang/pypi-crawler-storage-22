"""Plugin system for Clawbert.

This module provides a flexible plugin architecture that allows extending
Clawbert's capabilities through custom tools and functionality.

Plugin System:
    - Plugin base class for creating plugins
    - PluginManager for loading/discovering plugins
    - Automatic discovery from ~/.clawbert/plugins/
    - Decorator-based registration

Example:
    from .services.plugins import plugin_manager

    # List loaded plugins
    plugins = plugin_manager.list_plugins()

    # Get plugin by name
    plugin = plugin_manager.get_plugin("my-plugin")

    # Reload all plugins
    plugin_manager.reload()
"""

import importlib.util
import sys
import shutil
from pathlib import Path
from typing import Callable, Optional, Any
from dataclasses import dataclass, field


PLUGIN_DIR = Path.home() / ".clawbert" / "plugins"


@dataclass
class PluginMetadata:
    """Metadata for a plugin.

    Attributes:
        name: Unique identifier for the plugin.
        version: Plugin version string.
        description: Human-readable description.
        author: Plugin author.
        tools: List of tool names provided by the plugin.
        dependencies: List of required dependencies.
    """

    name: str
    version: str = "1.0.0"
    description: str = ""
    author: str = ""
    tools: list = field(default_factory=list)
    dependencies: list = field(default_factory=list)


class Plugin:
    """Base class for Clawbert plugins.

    All plugins should inherit from this class and implement the required methods.

    Attributes:
        metadata: Plugin metadata.
        tools: Dictionary of tools provided by this plugin.
        config: Plugin-specific configuration.

    Example:
        class MyPlugin(Plugin):
            def __init__(self):
                super().__init__()
                self.metadata.name = "my-plugin"
                self.metadata.description = "My custom plugin"
                self.register_tool(...)

            def on_load(self):
                print("Plugin loaded!")

            def on_unload(self):
                print("Plugin unloaded!")
    """

    def __init__(self):
        """Initialize the plugin with empty metadata and tools."""
        self.metadata = PluginMetadata(name=self.__class__.__name__)
        self.tools: dict[str, Any] = {}
        self.config: dict[str, Any] = {}

    def on_load(self) -> None:
        """Called when the plugin is loaded.

        Override this method to perform initialization logic.
        """
        pass

    def on_unload(self) -> None:
        """Called when the plugin is unloaded.

        Override this method to perform cleanup logic.
        """
        pass

    def on_enable(self) -> None:
        """Called when the plugin is enabled.

        Override this method to handle enable events.
        """
        pass

    def on_disable(self) -> None:
        """Called when the plugin is disabled.

        Override this method to handle disable events.
        """
        pass

    def register_tool(
        self,
        name: str,
        description: str,
        func: Callable,
        parameters: dict,
        risk_level: str = "medium",
    ) -> None:
        """Register a tool with the plugin.

        Args:
            name: Unique name for the tool.
            description: Human-readable description.
            func: Callable function to execute.
            parameters: JSON schema for parameters.
            risk_level: Risk assessment (low, medium, high, very_high).
        """
        from ..tools.registry import Tool

        tool = Tool(
            name=f"{self.metadata.name}_{name}" if "_" not in name else name,
            description=description,
            func=func,
            parameters=parameters,
            risk_level=risk_level,
        )
        self.tools[name] = tool
        self.metadata.tools.append(name)


class PluginManager:
    """Manager for loading, discovering, and managing plugins.

    Handles plugin lifecycle, discovery from filesystem, and integration
    with the tool registry.

    Attributes:
        plugins: Dictionary of loaded plugins.
        enabled: Set of enabled plugin names.
    """

    def __init__(self):
        """Initialize the plugin manager."""
        self.plugins: dict[str, Plugin] = {}
        self.enabled: set[str] = set()
        self._plugin_modules: dict[str, Any] = {}
        PLUGIN_DIR.mkdir(parents=True, exist_ok=True)

    def discover(self) -> list[str]:
        """Discover plugins from the plugin directory.

        Returns:
            List of discovered plugin names.
        """
        discovered = []
        if not PLUGIN_DIR.exists():
            return discovered

        for item in PLUGIN_DIR.iterdir():
            if item.is_dir() and (item / "__init__.py").exists():
                discovered.append(item.name)
            elif item.is_file() and item.suffix == ".py" and item.stem != "__init__":
                discovered.append(item.stem)

        return discovered

    def load(self, name: str) -> bool:
        """Load a plugin by name.

        Args:
            name: Plugin name to load.

        Returns:
            True if successfully loaded, False otherwise.
        """
        if name in self.plugins:
            return True

        plugin_path = PLUGIN_DIR / name
        module = None

        if plugin_path.is_dir() and (plugin_path / "__init__.py").exists():
            module = self._import_plugin_from_path(plugin_path, name)
        elif (PLUGIN_DIR / f"{name}.py").exists():
            module = self._import_plugin_from_path(PLUGIN_DIR / f"{name}.py", name)

        if module is None:
            return False

        try:
            plugin = module.load() if hasattr(module, "load") else module.Plugin()
        except Exception as e:
            print(f"Error loading plugin {name}: {e}")
            return False

        self.plugins[name] = plugin
        self._plugin_modules[name] = module

        plugin.on_load()

        for tool in plugin.tools.values():
            from ..tools.registry import tool_registry

            tool_registry.register(tool)

        if name not in self.enabled:
            self.enabled.add(name)

        return True

    def _import_plugin_from_path(self, path: Path, name: str) -> Optional[Any]:
        """Import a plugin module from a file path.

        Args:
            path: Path to the plugin file or directory.
            name: Plugin name.

        Returns:
            Imported module or None on failure.
        """
        try:
            if path.is_file():
                spec = importlib.util.spec_from_file_location(name, path)
            else:
                spec = importlib.util.spec_from_file_location(
                    name, path / "__init__.py"
                )

            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                sys.modules[name] = module
                spec.loader.exec_module(module)
                return module
        except Exception as e:
            print(f"Error importing plugin {name}: {e}")

        return None

    def unload(self, name: str) -> bool:
        """Unload a plugin by name.

        Args:
            name: Plugin name to unload.

        Returns:
            True if successfully unloaded, False otherwise.
        """
        if name not in self.plugins:
            return False

        plugin = self.plugins[name]

        plugin.on_unload()

        for tool_name in list(plugin.tools.keys()):
            tool = plugin.tools[tool_name]
            from ..tools.registry import tool_registry

            if tool.name in tool_registry.tools:
                del tool_registry.tools[tool.name]

        del self.plugins[name]
        self.enabled.discard(name)

        if name in self._plugin_modules:
            del self._plugin_modules[name]

        if name in sys.modules:
            del sys.modules[name]

        return True

    def enable(self, name: str) -> bool:
        """Enable a plugin.

        Args:
            name: Plugin name to enable.

        Returns:
            True if successfully enabled.
        """
        if name not in self.plugins:
            if not self.load(name):
                return False

        if name in self.enabled:
            return True

        plugin = self.plugins[name]
        plugin.on_enable()
        self.enabled.add(name)

        for tool in plugin.tools.values():
            from ..tools.registry import tool_registry

            if tool.name not in tool_registry.tools:
                tool_registry.register(tool)

        return True

    def disable(self, name: str) -> bool:
        """Disable a plugin.

        Args:
            name: Plugin name to disable.

        Returns:
            True if successfully disabled.
        """
        if name not in self.plugins:
            return False

        plugin = self.plugins[name]
        plugin.on_disable()
        self.enabled.discard(name)

        for tool in plugin.tools.values():
            from ..tools.registry import tool_registry

            if tool.name in tool_registry.tools:
                del tool_registry.tools[tool.name]

        return True

    def reload(self, name: Optional[str] = None) -> bool:
        """Reload plugins.

        Args:
            name: Optional plugin name to reload. If None, reloads all.

        Returns:
            True if successful.
        """
        if name:
            was_enabled = name in self.enabled
            self.unload(name)
            success = self.load(name)
            if success and was_enabled:
                self.enable(name)
            return success

        enabled = list(self.enabled)
        for name in list(self.plugins.keys()):
            self.unload(name)

        for name in enabled:
            self.load(name)

        return True

    def get_plugin(self, name: str) -> Optional[Plugin]:
        """Get a loaded plugin by name.

        Args:
            name: Plugin name.

        Returns:
            Plugin instance or None if not found.
        """
        return self.plugins.get(name)

    def list_plugins(self) -> list[dict]:
        """List all loaded plugins with their metadata.

        Returns:
            List of plugin info dictionaries.
        """
        result = []
        for name, plugin in self.plugins.items():
            result.append(
                {
                    "name": name,
                    "version": plugin.metadata.version,
                    "description": plugin.metadata.description,
                    "author": plugin.metadata.author,
                    "tools": list(plugin.tools.keys()),
                    "enabled": name in self.enabled,
                }
            )
        return result

    def list_available(self) -> list[str]:
        """List all available plugins (discovered but not loaded).

        Returns:
            List of plugin names.
        """
        discovered = self.discover()
        return [d for d in discovered if d not in self.plugins]

    def install(self, path: str) -> bool:
        """Install a plugin from a path.

        Args:
            path: Path to the plugin directory or file.

        Returns:
            True if successfully installed.
        """
        src = Path(path).expanduser()
        if not src.exists():
            return False

        name = src.name
        if src.is_file():
            name = src.stem

        dst = PLUGIN_DIR / name
        if dst.exists():
            return False

        try:
            if src.is_dir():
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
            return self.load(name)
        except Exception as e:
            print(f"Error installing plugin: {e}")
            return False

    def uninstall(self, name: str) -> bool:
        """Uninstall a plugin.

        Args:
            name: Plugin name to uninstall.

        Returns:
            True if successfully uninstalled.
        """
        if name in self.plugins:
            self.unload(name)

        plugin_path = PLUGIN_DIR / name
        if plugin_path.is_dir():
            shutil.rmtree(plugin_path)
        elif (PLUGIN_DIR / f"{name}.py").exists():
            (PLUGIN_DIR / f"{name}.py").unlink()
        else:
            return False

        return True

    def create(self, name: str, description: str = "") -> Path:
        """Create a new plugin scaffold.

        Args:
            name: Plugin name.
            description: Plugin description.

        Returns:
            Path to the created plugin directory.
        """
        plugin_dir = PLUGIN_DIR / name
        plugin_dir.mkdir(parents=True, exist_ok=True)

        init_content = f'''"""Plugin: {name}

{description or "A custom plugin for Clawbert."}
"""

from .services.plugins import Plugin


class {name.replace("-", "_").title().replace("_", "")}Plugin(Plugin):
    """Plugin class for {name}."""

    def __init__(self):
        super().__init__()
        self.metadata.name = "{name}"
        self.metadata.version = "1.0.0"
        self.metadata.description = "{description or "Custom plugin"}"
        self.metadata.author = ""

    def on_load(self):
        """Called when the plugin is loaded."""
        # Register your tools here
        pass


def load():
    """Required function to load the plugin."""
    return {name.replace("-", "_").title().replace("_", "")}Plugin()
'''

        (plugin_dir / "__init__.py").write_text(init_content)

        readme_content = f"""# {name}

{description or "A custom plugin for Clawbert."}

## Installation

This plugin is automatically installed to `~/.clawbert/plugins/{name}/`

## Usage

Once loaded, the plugin will register its tools with Clawbert.

## Tools

List the tools provided by this plugin here.

## Configuration

Add any configuration options here.
"""

        (plugin_dir / "README.md").write_text(readme_content)

        return plugin_dir


def plugin(name: str, description: str = "", version: str = "1.0.0"):
    """Decorator for creating plugins.

    Args:
        name: Plugin name.
        description: Plugin description.
        version: Plugin version.

    Returns:
        Decorator function.

    Example:
        @plugin("my-plugin", "My custom plugin", "1.0.0")
        class MyPlugin(Plugin):
            pass
    """

    def decorator(cls):
        cls._plugin_name = name
        cls._plugin_description = description
        cls._plugin_version = version
        return cls

    return decorator


plugin_manager = PluginManager()
