"""Scheduler for cron-like scheduled tasks.

This module provides a task scheduler with:
- Multiple task types: command, workflow, webhook, reminder
- Cron-like scheduling (interval or cron expression)
- Task storage in ~/.clawbert/schedules/
- Background daemon mode

Task Types:
    - command: Run a CLI command
    - workflow: Run a workflow
    - webhook: Call a webhook
    - reminder: Send a reminder

Example:
    from .services.scheduler import Scheduler, Task

    scheduler = Scheduler()
    task = Task(
        name="daily-backup",
        task_type="command",
        schedule="0 2 * * *",  # 2 AM daily
        config={"command": "tar -czf backup.tar.gz data/"}
    )
    scheduler.add_task(task)
    scheduler.run()
"""

import json
import subprocess
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
from dataclasses import dataclass
import requests


SCHEDULES_DIR = Path.home() / ".clawbert" / "schedules"


@dataclass
class Task:
    """Represents a scheduled task.

    Attributes:
        name: Unique identifier for the task.
        task_type: Type of task (command, workflow, webhook, reminder).
        schedule: Cron expression or interval (e.g., "5m", "1h", "0 2 * * *").
        config: Task-specific configuration.
        enabled: Whether the task is currently enabled.
        last_run: Last execution timestamp.
        next_run: Next scheduled execution timestamp.
    """

    name: str
    task_type: str
    schedule: str
    config: dict
    enabled: bool = True
    last_run: Optional[str] = None
    next_run: Optional[str] = None


class CronParser:
    """Parse cron expressions and calculate next run times."""

    @staticmethod
    def parse(schedule: str) -> tuple[Optional[list[int]], Optional[timedelta]]:
        """Parse a schedule string.

        Args:
            schedule: Cron expression (e.g., "0 2 * * *") or interval (e.g., "5m", "1h").

        Returns:
            Tuple of (cron fields or None, interval or None).
        """
        schedule = schedule.strip()

        if schedule.endswith("m") or schedule.endswith("h") or schedule.endswith("d"):
            try:
                num = int(schedule[:-1])
                unit = schedule[-1]
                if unit == "m":
                    return None, timedelta(minutes=num)
                elif unit == "h":
                    return None, timedelta(hours=num)
                elif unit == "d":
                    return None, timedelta(days=num)
            except ValueError:
                pass

        parts = schedule.split()
        if len(parts) == 5:
            try:
                return [int(p) if p != "*" else None for p in parts], None
            except ValueError:
                pass

        return None, None

    @staticmethod
    def get_next_run(schedule: str) -> datetime:
        """Calculate the next run time for a schedule.

        Args:
            schedule: Cron expression or interval.

        Returns:
            Next scheduled run time.
        """
        cron_fields, interval = CronParser.parse(schedule)

        if interval:
            return datetime.now() + interval

        if cron_fields:
            now = datetime.now()
            minute, hour, day, month, weekday = cron_fields

            next_run = now.replace(second=0, microsecond=0)
            next_run += timedelta(minutes=1)

            if minute is not None:
                next_run = next_run.replace(minute=minute)
            if hour is not None:
                next_run = next_run.replace(hour=hour)

            if next_run <= now:
                next_run += timedelta(days=1)

            return next_run

        return datetime.now() + timedelta(hours=1)


class Scheduler:
    """Manages scheduled tasks.

    Attributes:
        tasks: Dictionary of task name to Task objects.
        running: Whether the scheduler daemon is running.
    """

    def __init__(self):
        """Initialize the scheduler."""
        self.tasks: dict[str, Task] = {}
        self.running = False
        self._load_tasks()

    def _get_schedules_dir(self) -> Path:
        """Get the schedules directory, creating it if needed."""
        SCHEDULES_DIR.mkdir(parents=True, exist_ok=True)
        return SCHEDULES_DIR

    def _task_file(self, name: str) -> Path:
        """Get the file path for a task."""
        return self._get_schedules_dir() / f"{name}.json"

    def _load_tasks(self):
        """Load all tasks from disk."""
        for f in self._get_schedules_dir().glob("*.json"):
            try:
                data = json.loads(f.read_text())
                task = Task(
                    name=data["name"],
                    task_type=data["task_type"],
                    schedule=data["schedule"],
                    config=data.get("config", {}),
                    enabled=data.get("enabled", True),
                    last_run=data.get("last_run"),
                    next_run=data.get("next_run"),
                )
                self.tasks[task.name] = task
            except Exception:
                pass

    def _save_task(self, task: Task):
        """Save a task to disk."""
        data = {
            "name": task.name,
            "task_type": task.task_type,
            "schedule": task.schedule,
            "config": task.config,
            "enabled": task.enabled,
            "last_run": task.last_run,
            "next_run": task.next_run,
        }
        self._task_file(task.name).write_text(json.dumps(data, indent=2))

    def add_task(self, task: Task) -> bool:
        """Add a new scheduled task.

        Args:
            task: Task to add.

        Returns:
            True if added successfully, False if task already exists.
        """
        if task.name in self.tasks:
            return False

        task.next_run = CronParser.get_next_run(task.schedule).isoformat()
        self.tasks[task.name] = task
        self._save_task(task)
        return True

    def remove_task(self, name: str) -> bool:
        """Remove a scheduled task.

        Args:
            name: Task name to remove.

        Returns:
            True if removed, False if not found.
        """
        if name not in self.tasks:
            return False

        del self.tasks[name]
        self._task_file(name).unlink(missing_ok=True)
        return True

    def enable_task(self, name: str) -> bool:
        """Enable a task.

        Args:
            name: Task name to enable.

        Returns:
            True if enabled, False if not found.
        """
        if name not in self.tasks:
            return False

        self.tasks[name].enabled = True
        self._save_task(self.tasks[name])
        return True

    def disable_task(self, name: str) -> bool:
        """Disable a task.

        Args:
            name: Task name to disable.

        Returns:
            True if disabled, False if not found.
        """
        if name not in self.tasks:
            return False

        self.tasks[name].enabled = False
        self._save_task(self.tasks[name])
        return True

    def list_tasks(self) -> list[dict]:
        """List all tasks.

        Returns:
            List of task dictionaries.
        """
        result = []
        for task in self.tasks.values():
            result.append(
                {
                    "name": task.name,
                    "task_type": task.task_type,
                    "schedule": task.schedule,
                    "enabled": task.enabled,
                    "last_run": task.last_run,
                    "next_run": task.next_run,
                }
            )
        return result

    def _execute_task(self, task: Task):
        """Execute a task based on its type.

        Args:
            task: Task to execute.
        """
        task.last_run = datetime.now().isoformat()
        task.next_run = CronParser.get_next_run(task.schedule).isoformat()
        self._save_task(task)

        try:
            if task.task_type == "command":
                self._execute_command(task)
            elif task.task_type == "workflow":
                self._execute_workflow(task)
            elif task.task_type == "webhook":
                self._execute_webhook(task)
            elif task.task_type == "reminder":
                self._execute_reminder(task)
        except Exception as e:
            print(f"Error executing task {task.name}: {e}")

    def _execute_command(self, task: Task):
        """Execute a command task."""
        cmd = task.config.get("command", "")
        if cmd:
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                cwd=task.config.get("cwd"),
            )
            print(f"[{task.name}] Command output: {result.stdout[:500]}")

    def _execute_workflow(self, task: Task):
        """Execute a workflow task."""
        workflow_name = task.config.get("workflow")
        if workflow_name:
            print(f"[{task.name}] Running workflow: {workflow_name}")

    def _execute_webhook(self, task: Task):
        """Execute a webhook task."""
        url = task.config.get("url")
        method = task.config.get("method", "GET")
        headers = task.config.get("headers", {})
        body = task.config.get("body")

        if url:
            if method == "GET":
                resp = requests.get(url, headers=headers, timeout=30)
            elif method == "POST":
                resp = requests.post(url, headers=headers, json=body, timeout=30)
            elif method == "PUT":
                resp = requests.put(url, headers=headers, json=body, timeout=30)
            elif method == "DELETE":
                resp = requests.delete(url, headers=headers, timeout=30)
            else:
                resp = requests.request(
                    method, url, headers=headers, json=body, timeout=30
                )
            print(f"[{task.name}] Webhook response: {resp.status_code}")

    def _execute_reminder(self, task: Task):
        """Execute a reminder task."""
        message = task.config.get("message", "")
        print(f"[{task.name}] Reminder: {message}")

    def _run_loop(self):
        """Main scheduler loop."""
        while self.running:
            now = datetime.now()

            for task in self.tasks.values():
                if not task.enabled:
                    continue

                if task.next_run:
                    next_run = datetime.fromisoformat(task.next_run)
                    if now >= next_run:
                        thread = threading.Thread(
                            target=self._execute_task, args=(task,)
                        )
                        thread.start()

            time.sleep(10)

    def run(self, daemon: bool = True):
        """Start the scheduler daemon.

        Args:
            daemon: If True, run in background thread. If False, run once.
        """
        if daemon:
            self.running = True
            thread = threading.Thread(target=self._run_loop, daemon=True)
            thread.start()
        else:
            for task in self.tasks.values():
                if task.enabled:
                    self._execute_task(task)


scheduler = Scheduler()
