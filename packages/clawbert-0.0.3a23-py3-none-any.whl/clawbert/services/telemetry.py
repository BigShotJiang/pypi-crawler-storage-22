"""Usage tracking and telemetry for Clawbert.

This module provides local usage tracking with optional anonymous telemetry.
Privacy-first: no external upload by default.

Features:
    - Track API calls (provider, model, tokens, cost)
    - Track tool usage (which tools, how often, duration)
    - Track session stats (messages, duration)
    - Track errors
    - Local storage in ~/.clawbert/usage/
    - Optional anonymous telemetry to help improve Clawbert

Example:
    from .services.telemetry import usage_tracker

    # Track an API call
    usage_tracker.track_api_call("openrouter", "gpt-4", 1000, 2000, 0.002)

    # Track tool usage
    usage_tracker.track_tool("read", 0.5)

    # Get stats
    stats = usage_tracker.get_stats()
"""

import json
import uuid
from pathlib import Path
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional
from threading import Lock


@dataclass
class APICall:
    timestamp: str
    provider: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    cost: float


@dataclass
class ToolUsage:
    timestamp: str
    tool_name: str
    duration_seconds: float
    success: bool


@dataclass
class SessionStats:
    session_id: str
    start_time: str
    end_time: Optional[str] = None
    message_count: int = 0


@dataclass
class ErrorRecord:
    timestamp: str
    error_type: str
    message: str
    context: str


class UsageData:
    """Container for all usage data."""

    def __init__(self):
        self.api_calls: list[dict] = []
        self.tool_usage: list[dict] = []
        self.sessions: list[dict] = []
        self.errors: list[dict] = []


class UsageTracker:
    """Track usage statistics for Clawbert.

    Stores data locally in ~/.clawbert/usage/ with privacy-first approach.
    Optional anonymous telemetry can be enabled to help improve Clawbert.

    Attributes:
        usage_dir: Directory for storing usage data.
        current_session: Current session being tracked.
    """

    def __init__(self, usage_dir: Optional[Path] = None):
        """Initialize the usage tracker.

        Args:
            usage_dir: Optional custom directory for usage data.
        """
        self.usage_dir = usage_dir or Path.home() / ".clawbert" / "usage"
        self.usage_dir.mkdir(parents=True, exist_ok=True)

        self._api_calls_file = self.usage_dir / "api_calls.jsonl"
        self._tool_usage_file = self.usage_dir / "tool_usage.jsonl"
        self._sessions_file = self.usage_dir / "sessions.jsonl"
        self._errors_file = self.usage_dir / "errors.jsonl"

        self._lock = Lock()
        self.current_session: Optional[str] = None

    def _append_to_file(self, filepath: Path, data: dict):
        """Append a JSON record to a file."""
        with self._lock:
            with open(filepath, "a") as f:
                f.write(json.dumps(data) + "\n")

    def track_api_call(
        self,
        provider: str,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
        cost: float,
    ):
        """Track an API call to the LLM.

        Args:
            provider: The LLM provider (openrouter, openai, anthropic, ollama).
            model: The model identifier.
            prompt_tokens: Number of tokens in the prompt.
            completion_tokens: Number of tokens in the completion.
            cost: Estimated cost in USD.
        """
        record = {
            "timestamp": datetime.now().isoformat(),
            "provider": provider,
            "model": model,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
            "cost": cost,
        }
        self._append_to_file(self._api_calls_file, record)

    def track_tool(self, tool_name: str, duration_seconds: float, success: bool = True):
        """Track a tool execution.

        Args:
            tool_name: Name of the tool that was executed.
            duration_seconds: How long the tool took to execute.
            success: Whether the tool executed successfully.
        """
        record = {
            "timestamp": datetime.now().isoformat(),
            "tool_name": tool_name,
            "duration_seconds": duration_seconds,
            "success": success,
        }
        self._append_to_file(self._tool_usage_file, record)

    def start_session(self, session_id: str):
        """Start tracking a new session.

        Args:
            session_id: Unique identifier for the session.
        """
        self.current_session = session_id
        record = {
            "session_id": session_id,
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "message_count": 0,
        }
        self._append_to_file(self._sessions_file, record)

    def end_session(self, session_id: str, message_count: int):
        """End tracking a session.

        Args:
            session_id: Unique identifier for the session.
            message_count: Number of messages in the session.
        """
        record = {
            "session_id": session_id,
            "start_time": None,
            "end_time": datetime.now().isoformat(),
            "message_count": message_count,
        }
        self._append_to_file(self._sessions_file, record)
        self.current_session = None

    def track_error(self, error_type: str, message: str, context: str = ""):
        """Track an error occurrence.

        Args:
            error_type: Type/category of the error.
            message: Error message.
            context: Additional context about where the error occurred.
        """
        record = {
            "timestamp": datetime.now().isoformat(),
            "error_type": error_type,
            "message": message[:500],
            "context": context[:500],
        }
        self._append_to_file(self._errors_file, record)

    def _read_jsonl(self, filepath: Path) -> list[dict]:
        """Read all records from a JSONL file."""
        if not filepath.exists():
            return []
        records = []
        with open(filepath, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        records.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
        return records

    def get_stats(self, days: int = 30) -> dict:
        """Get usage statistics.

        Args:
            days: Number of days to include in stats (default: 30).

        Returns:
            Dictionary with usage statistics.
        """
        cutoff = datetime.now() - timedelta(days=days)

        api_calls = self._read_jsonl(self._api_calls_file)
        tool_usage = self._read_jsonl(self._tool_usage_file)
        sessions = self._read_jsonl(self._sessions_file)
        errors = self._read_jsonl(self._errors_file)

        recent_api = [
            c for c in api_calls if datetime.fromisoformat(c["timestamp"]) > cutoff
        ]
        recent_tools = [
            t for t in tool_usage if datetime.fromisoformat(t["timestamp"]) > cutoff
        ]
        recent_errors = [
            e for e in errors if datetime.fromisoformat(e["timestamp"]) > cutoff
        ]

        total_cost = sum(c.get("cost", 0) for c in recent_api)
        total_prompt_tokens = sum(c.get("prompt_tokens", 0) for c in recent_api)
        total_completion_tokens = sum(c.get("completion_tokens", 0) for c in recent_api)

        tool_counts: dict[str, int] = {}
        for t in recent_tools:
            name = t.get("tool_name", "unknown")
            tool_counts[name] = tool_counts.get(name, 0) + 1

        started_sessions = [
            s
            for s in sessions
            if s.get("start_time") and datetime.fromisoformat(s["start_time"]) > cutoff
        ]
        ended_sessions = [
            s
            for s in sessions
            if s.get("end_time") and datetime.fromisoformat(s["end_time"]) > cutoff
        ]

        return {
            "period_days": days,
            "api_calls": {
                "total": len(recent_api),
                "total_cost": round(total_cost, 6),
                "total_prompt_tokens": total_prompt_tokens,
                "total_completion_tokens": total_completion_tokens,
                "total_tokens": total_prompt_tokens + total_completion_tokens,
                "by_provider": self._count_by_field(recent_api, "provider"),
                "by_model": self._count_by_field(recent_api, "model"),
            },
            "tool_usage": {
                "total": len(recent_tools),
                "by_tool": tool_counts,
                "success_rate": round(
                    len([t for t in recent_tools if t.get("success")])
                    / max(len(recent_tools), 1)
                    * 100,
                    1,
                ),
            },
            "sessions": {
                "started": len(started_sessions),
                "ended": len(ended_sessions),
                "total_messages": sum(
                    s.get("message_count", 0) for s in ended_sessions
                ),
            },
            "errors": {
                "total": len(recent_errors),
                "by_type": self._count_by_field(recent_errors, "error_type"),
            },
        }

    def _count_by_field(self, records: list[dict], field_name: str) -> dict[str, int]:
        """Count records by a specific field."""
        counts: dict[str, int] = {}
        for r in records:
            value = r.get(field_name, "unknown")
            counts[value] = counts.get(value, 0) + 1
        return counts

    def export_data(self) -> dict:
        """Export all usage data as a dictionary.

        Returns:
            Dictionary containing all usage data.
        """
        return {
            "api_calls": self._read_jsonl(self._api_calls_file),
            "tool_usage": self._read_jsonl(self._tool_usage_file),
            "sessions": self._read_jsonl(self._sessions_file),
            "errors": self._read_jsonl(self._errors_file),
            "exported_at": datetime.now().isoformat(),
        }

    def clear_data(self):
        """Clear all usage data."""
        with self._lock:
            for filepath in [
                self._api_calls_file,
                self._tool_usage_file,
                self._sessions_file,
                self._errors_file,
            ]:
                if filepath.exists():
                    filepath.unlink()


class TelemetrySender:
    """Send anonymous telemetry data to help improve Clawbert.

    Privacy-first: Only sends anonymized, aggregated data.
    User must explicitly opt-in to enable telemetry.
    """

    TELEMETRY_ENDPOINT = "https://telemetry.opencode.ai/clawbert"

    def __init__(self, enabled: bool = False):
        """Initialize telemetry sender.

        Args:
            enabled: Whether telemetry is enabled by the user.
        """
        self.enabled = enabled

    def _get_anonymous_id(self) -> str:
        """Get or create an anonymous identifier for this installation."""
        id_file = Path.home() / ".clawbert" / ".telemetry_id"
        if id_file.exists():
            return id_file.read_text().strip()
        anon_id = str(uuid.uuid4())
        id_file.write_text(anon_id)
        return anon_id

    def send_telemetry(self, stats: dict):
        """Send anonymous telemetry data.

        Args:
            stats: Statistics to send (anonymized).
        """
        if not self.enabled:
            return

        try:
            import requests

            payload = {
                "installation_id": self._get_anonymous_id(),
                "version": "1.0.0",
                "stats": stats,
                "timestamp": datetime.now().isoformat(),
            }
            requests.post(
                self.TELEMETRY_ENDPOINT,
                json=payload,
                timeout=5,
            )
        except Exception:
            pass


usage_tracker = UsageTracker()
telemetry_sender = TelemetrySender()


def init_telemetry(enabled: bool):
    """Initialize telemetry based on config."""
    telemetry_sender.enabled = enabled
