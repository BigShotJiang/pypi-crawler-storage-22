"""Workflow automation for Clawbert.

This module provides multi-step task automation with support for:
- Workflow definitions in YAML or JSON
- Step dependencies and conditional execution
- Rollback on failure
- Persistent workflow storage in ~/.clawbert/workflows/

Built-in Workflows:
    - code_review: Review code changes
    - deploy: Deploy application
    - test_suite: Run tests
    - refactor: Refactor code

Example:
    from .services.workflows import workflow_manager

    # List available workflows
    workflows = workflow_manager.list_workflows()

    # Run a workflow
    result = workflow_manager.run_workflow("test_suite", {"path": "."})

    # Create a custom workflow
    workflow_manager.create_workflow("my_workflow", {...})
"""

import json
import subprocess
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Optional

import yaml


class WorkflowStatus(Enum):
    """Workflow execution status."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


class StepStatus(Enum):
    """Step execution status."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class WorkflowStep:
    """Represents a single step in a workflow.

    Attributes:
        id: Unique identifier for the step.
        name: Human-readable step name.
        description: Description of what the step does.
        command: Shell command to execute.
        condition: Optional condition for conditional execution.
        rollback: Optional rollback command on failure.
        depends_on: List of step IDs this step depends on.
        retry: Number of retries on failure (default: 0).
        timeout: Timeout in seconds (default: 30).
    """

    id: str
    name: str
    description: str
    command: str
    condition: Optional[str] = None
    rollback: Optional[str] = None
    depends_on: list[str] = field(default_factory=list)
    retry: int = 0
    timeout: int = 30


@dataclass
class Workflow:
    """Represents a multi-step workflow.

    Attributes:
        id: Unique identifier for the workflow.
        name: Human-readable workflow name.
        description: Description of what the workflow does.
        version: Version string.
        steps: List of workflow steps.
        allow_rollback: Whether to enable rollback on failure.
        required_tools: List of required tool names.
        metadata: Additional workflow metadata.
    """

    id: str
    name: str
    description: str
    version: str = "1.0.0"
    steps: list[WorkflowStep] = field(default_factory=list)
    allow_rollback: bool = True
    required_tools: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Workflow":
        """Create a Workflow from a dictionary.

        Args:
            data: Dictionary containing workflow definition.

        Returns:
            Workflow instance.
        """
        steps = []
        for step_data in data.get("steps", []):
            step = WorkflowStep(
                id=step_data.get("id", str(uuid.uuid4())),
                name=step_data.get("name", ""),
                description=step_data.get("description", ""),
                command=step_data.get("command", ""),
                condition=step_data.get("condition"),
                rollback=step_data.get("rollback"),
                depends_on=step_data.get("depends_on", []),
                retry=step_data.get("retry", 0),
                timeout=step_data.get("timeout", 30),
            )
            steps.append(step)

        return cls(
            id=data.get("id", str(uuid.uuid4())),
            name=data.get("name", ""),
            description=data.get("description", ""),
            version=data.get("version", "1.0.0"),
            steps=steps,
            allow_rollback=data.get("allow_rollback", True),
            required_tools=data.get("required_tools", []),
            metadata=data.get("metadata", {}),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert workflow to dictionary.

        Returns:
            Dictionary representation of the workflow.
        """
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "steps": [
                {
                    "id": step.id,
                    "name": step.name,
                    "description": step.description,
                    "command": step.command,
                    "condition": step.condition,
                    "rollback": step.rollback,
                    "depends_on": step.depends_on,
                    "retry": step.retry,
                    "timeout": step.timeout,
                }
                for step in self.steps
            ],
            "allow_rollback": self.allow_rollback,
            "required_tools": self.required_tools,
            "metadata": self.metadata,
        }


@dataclass
class WorkflowExecution:
    """Represents a workflow execution instance.

    Attributes:
        id: Unique execution ID.
        workflow_id: ID of the workflow being executed.
        workflow_name: Name of the workflow.
        status: Current execution status.
        step_results: Dictionary mapping step IDs to their results.
        started_at: Execution start timestamp.
        completed_at: Execution completion timestamp.
        error: Error message if execution failed.
    """

    id: str
    workflow_id: str
    workflow_name: str
    status: WorkflowStatus = WorkflowStatus.PENDING
    step_results: dict[str, dict[str, Any]] = field(default_factory=dict)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None


class WorkflowRunner:
    """Executes workflows with support for dependencies, conditions, and rollback.

    This class manages the execution of workflow steps, handling dependencies
    between steps, conditional execution, and rollback on failure.

    Attributes:
        workflow: The workflow to execute.
        context: Execution context (variables for interpolation).
    """

    def __init__(self, workflow: Workflow, context: Optional[dict[str, Any]] = None):
        """Initialize the workflow runner.

        Args:
            workflow: The workflow to execute.
            context: Execution context with variables.
        """
        self.workflow = workflow
        self.context = context or {}
        self.execution = WorkflowExecution(
            id=str(uuid.uuid4()),
            workflow_id=workflow.id,
            workflow_name=workflow.name,
        )
        self.step_status: dict[str, StepStatus] = {}

    def _interpolate(self, text: str) -> str:
        """Interpolate variables in text.

        Args:
            text: Text with {variable} placeholders.

        Returns:
            Text with interpolated variables.
        """
        result = text
        for key, value in self.context.items():
            result = result.replace(f"{{{key}}}", str(value))
        return result

    def _check_condition(self, condition: str) -> bool:
        """Check if a condition is satisfied.

        Args:
            condition: Condition expression to evaluate.

        Returns:
            True if condition passes, False otherwise.
        """
        try:
            interpolated = self._interpolate(condition)
            return eval(interpolated, {"__builtins__": {}}, {})
        except Exception:
            return False

    def _execute_step(self, step: WorkflowStep) -> dict[str, Any]:
        """Execute a single workflow step.

        Args:
            step: The step to execute.

        Returns:
            Dictionary with execution results.
        """
        self.step_status[step.id] = StepStatus.RUNNING

        if step.condition and not self._check_condition(step.condition):
            self.step_status[step.id] = StepStatus.SKIPPED
            return {
                "status": "skipped",
                "output": "Condition not met",
                "return_code": -1,
            }

        command = self._interpolate(step.command)
        retry_count = 0
        max_retries = step.retry

        while retry_count <= max_retries:
            try:
                result = subprocess.run(
                    command,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=step.timeout,
                )
                output = result.stdout or result.stderr

                if result.returncode != 0:
                    if retry_count < max_retries:
                        retry_count += 1
                        continue
                    self.step_status[step.id] = StepStatus.FAILED
                    return {
                        "status": "failed",
                        "output": output,
                        "return_code": result.returncode,
                    }

                self.step_status[step.id] = StepStatus.COMPLETED
                return {
                    "status": "completed",
                    "output": output,
                    "return_code": result.returncode,
                }
            except subprocess.TimeoutExpired:
                if retry_count < max_retries:
                    retry_count += 1
                    continue
                self.step_status[step.id] = StepStatus.FAILED
                return {
                    "status": "failed",
                    "output": f"Step timed out after {step.timeout} seconds",
                    "return_code": -1,
                }
            except Exception as e:
                if retry_count < max_retries:
                    retry_count += 1
                    continue
                self.step_status[step.id] = StepStatus.FAILED
                return {"status": "failed", "output": str(e), "return_code": -1}

        self.step_status[step.id] = StepStatus.FAILED
        return {"status": "failed", "output": "Max retries exceeded", "return_code": -1}

    def _execute_rollback(self, step: WorkflowStep, result: dict[str, Any]) -> bool:
        """Execute rollback for a failed step.

        Args:
            step: The step that failed.
            result: The failed step result.

        Returns:
            True if rollback succeeded, False otherwise.
        """
        if not step.rollback or not self.workflow.allow_rollback:
            return False

        try:
            rollback_cmd = self._interpolate(step.rollback)
            subprocess.run(
                rollback_cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=step.timeout,
            )
            return True
        except Exception:
            return False

    def _get_ready_steps(self) -> list[WorkflowStep]:
        """Get steps that are ready to execute (dependencies met).

        Returns:
            List of steps that can be executed.
        """
        ready = []
        for step in self.workflow.steps:
            if self.step_status.get(step.id) not in [
                None,
                StepStatus.PENDING,
            ]:
                continue

            deps_met = all(
                self.step_status.get(dep_id) == StepStatus.COMPLETED
                for dep_id in step.depends_on
            )
            if deps_met:
                ready.append(step)
        return ready

    def run(self) -> WorkflowExecution:
        """Execute the workflow.

        Returns:
            WorkflowExecution with results.
        """
        self.execution.started_at = datetime.now()
        self.execution.status = WorkflowStatus.RUNNING

        for step in self.workflow.steps:
            self.step_status[step.id] = StepStatus.PENDING

        completed_steps = 0
        total_steps = len(self.workflow.steps)

        while completed_steps < total_steps:
            ready_steps = self._get_ready_steps()
            if not ready_steps:
                pending = [
                    s.id
                    for s in self.workflow.steps
                    if self.step_status.get(s.id) in [None, StepStatus.PENDING]
                ]
                if pending:
                    self.execution.status = WorkflowStatus.FAILED
                    self.execution.error = (
                        f"Deadlock: steps {pending} have unmet dependencies"
                    )
                    break
                continue

            for step in ready_steps:
                result = self._execute_step(step)
                self.execution.step_results[step.id] = {
                    "step": step.name,
                    "command": step.command,
                    **result,
                }

                if result["status"] == "failed":
                    if step.rollback and self.workflow.allow_rollback:
                        self._execute_rollback(step, result)
                    self.execution.status = WorkflowStatus.FAILED
                    self.execution.error = (
                        f"Step '{step.name}' failed: {result['output']}"
                    )
                    break

                completed_steps += 1

            if self.execution.status == WorkflowStatus.FAILED:
                self.execution.status = WorkflowStatus.ROLLED_BACK
                break

        if self.execution.status == WorkflowStatus.RUNNING:
            self.execution.status = WorkflowStatus.COMPLETED

        self.execution.completed_at = datetime.now()
        return self.execution


class WorkflowManager:
    """Manages workflow storage, loading, and execution.

    This class provides the main interface for managing workflows,
    including listing, creating, running, and deleting workflows.

    Attributes:
        workflows_dir: Directory for storing workflows.
        workflows: Dictionary of loaded workflows.
    """

    def __init__(self, workflows_dir: Optional[Path] = None):
        """Initialize the workflow manager.

        Args:
            workflows_dir: Directory for workflow storage. Defaults to ~/.clawbert/workflows/.
        """
        self.workflows_dir = workflows_dir or Path.home() / ".clawbert" / "workflows"
        self.workflows_dir.mkdir(parents=True, exist_ok=True)
        self.workflows: dict[str, Workflow] = {}
        self.executions: dict[str, WorkflowExecution] = {}
        self._load_builtin_workflows()
        self._load_custom_workflows()

    def _load_builtin_workflows(self):
        """Load built-in workflows."""
        self.workflows["code_review"] = self._builtin_code_review()
        self.workflows["deploy"] = self._builtin_deploy()
        self.workflows["test_suite"] = self._builtin_test_suite()
        self.workflows["refactor"] = self._builtin_refactor()

    def _load_custom_workflows(self):
        """Load custom workflows from disk."""
        for file_path in self.workflows_dir.glob("*.yaml"):
            try:
                data = yaml.safe_load(file_path.read_text())
                if data:
                    wf = Workflow.from_dict(data)
                    self.workflows[wf.name.lower().replace(" ", "_")] = wf
            except Exception:
                pass

        for file_path in self.workflows_dir.glob("*.json"):
            try:
                data = json.loads(file_path.read_text())
                if data:
                    wf = Workflow.from_dict(data)
                    self.workflows[wf.name.lower().replace(" ", "_")] = wf
            except Exception:
                pass

    def _builtin_code_review(self) -> Workflow:
        """Create the built-in code review workflow.

        Returns:
            Workflow for code review.
        """
        return Workflow(
            id="builtin-code-review",
            name="code_review",
            description="Review code changes using git diff",
            steps=[
                WorkflowStep(
                    id="check-git",
                    name="Check git status",
                    description="Verify this is a git repository",
                    command="git status",
                    depends_on=[],
                ),
                WorkflowStep(
                    id="get-diff",
                    name="Get unstaged changes",
                    description="Get diff of unstaged changes",
                    command="git diff",
                    depends_on=["check-git"],
                ),
                WorkflowStep(
                    id="get-staged",
                    name="Get staged changes",
                    description="Get diff of staged changes",
                    command="git diff --cached",
                    depends_on=["check-git"],
                ),
                WorkflowStep(
                    id="get-log",
                    name="Get recent commits",
                    description="Get recent commit history",
                    command="git log --oneline -10",
                    depends_on=["check-git"],
                ),
            ],
            required_tools=["git_status", "git_diff", "git_log"],
        )

    def _builtin_deploy(self) -> Workflow:
        """Create the built-in deploy workflow.

        Returns:
            Workflow for deployment.
        """
        return Workflow(
            id="builtin-deploy",
            name="deploy",
            description="Deploy application (install deps, build, deploy)",
            steps=[
                WorkflowStep(
                    id="install-deps",
                    name="Install dependencies",
                    description="Install project dependencies",
                    command="pip install -r requirements.txt 2>/dev/null || npm install 2>/dev/null || true",
                    depends_on=[],
                    rollback="pip uninstall -r requirements.txt 2>/dev/null || true",
                ),
                WorkflowStep(
                    id="run-tests",
                    name="Run tests",
                    description="Run project tests before deployment",
                    command="python -m pytest 2>/dev/null || npm test 2>/dev/null || true",
                    depends_on=["install-deps"],
                ),
                WorkflowStep(
                    id="build",
                    name="Build project",
                    description="Build the project",
                    command="python -m py_compile *.py 2>/dev/null || npm run build 2>/dev/null || true",
                    depends_on=["run-tests"],
                ),
                WorkflowStep(
                    id="deploy-cmd",
                    name="Deploy application",
                    description="Execute deployment command",
                    command='echo "Deployment would run here. Set DEPLOY_COMMAND env var."',
                    depends_on=["build"],
                    condition="'${DEPLOY_COMMAND}' != ''",
                ),
            ],
            allow_rollback=True,
            required_tools=["exec"],
        )

    def _builtin_test_suite(self) -> Workflow:
        """Create the built-in test suite workflow.

        Returns:
            Workflow for running test suite.
        """
        return Workflow(
            id="builtin-test-suite",
            name="test_suite",
            description="Run comprehensive test suite",
            steps=[
                WorkflowStep(
                    id="detect-test-framework",
                    name="Detect test framework",
                    description="Detect available test framework",
                    command="if [ -f pytest.ini ] || [ -f pyproject.toml ]; then echo 'pytest'; elif [ -f package.json ]; then echo 'jest'; else echo 'none'; fi",
                    depends_on=[],
                ),
                WorkflowStep(
                    id="run-unit-tests",
                    name="Run unit tests",
                    description="Run unit tests",
                    command="python -m pytest tests/ -v 2>/dev/null || npm test 2>/dev/null || echo 'No tests found'",
                    depends_on=["detect-test-framework"],
                ),
                WorkflowStep(
                    id="run-coverage",
                    name="Run coverage",
                    description="Run tests with coverage",
                    command="python -m pytest --cov 2>/dev/null || echo 'Coverage not available'",
                    depends_on=["run-unit-tests"],
                ),
                WorkflowStep(
                    id="lint-checks",
                    name="Run linting",
                    description="Run code quality checks",
                    command="ruff check . 2>/dev/null || pylint *.py 2>/dev/null || echo 'Linting not configured'",
                    depends_on=["run-unit-tests"],
                ),
            ],
            required_tools=["exec"],
        )

    def _builtin_refactor(self) -> Workflow:
        """Create the built-in refactor workflow.

        Returns:
            Workflow for code refactoring.
        """
        return Workflow(
            id="builtin-refactor",
            name="refactor",
            description="Refactor code (analyze, plan, execute)",
            steps=[
                WorkflowStep(
                    id="analyze-code",
                    name="Analyze code structure",
                    description="Analyze code for refactoring opportunities",
                    command="find . -name '*.py' -type f | head -20",
                    depends_on=[],
                ),
                WorkflowStep(
                    id="check-complexity",
                    name="Check code complexity",
                    description="Check for complex functions",
                    command="radon cc . -a 2>/dev/null || echo 'Complexity analysis not available'",
                    depends_on=["analyze-code"],
                ),
                WorkflowStep(
                    id="find-duplicates",
                    name="Find duplicate code",
                    description="Search for duplicate code patterns",
                    command="echo 'Duplicate detection requires jscpd or similar tool'",
                    depends_on=["analyze-code"],
                ),
                WorkflowStep(
                    id="format-code",
                    name="Format code",
                    description="Format code with ruff/black",
                    command="ruff format . 2>/dev/null || black . 2>/dev/null || echo 'Formatter not available'",
                    depends_on=["check-complexity", "find-duplicates"],
                ),
            ],
            required_tools=["glob", "exec"],
        )

    def list_workflows(self) -> list[dict[str, Any]]:
        """List all available workflows.

        Returns:
            List of workflow summaries.
        """
        result = []
        for key, wf in self.workflows.items():
            result.append(
                {
                    "id": wf.id,
                    "name": wf.name,
                    "description": wf.description,
                    "version": wf.version,
                    "steps": len(wf.steps),
                    "builtin": key
                    in ["code_review", "deploy", "test_suite", "refactor"],
                }
            )
        return result

    def get_workflow(self, name: str) -> Optional[Workflow]:
        """Get a workflow by name.

        Args:
            name: Workflow name.

        Returns:
            Workflow instance or None if not found.
        """
        return self.workflows.get(name.lower().replace(" ", "_"))

    def run_workflow(
        self, name: str, context: Optional[dict[str, Any]] = None
    ) -> dict[str, Any]:
        """Run a workflow by name.

        Args:
            name: Workflow name.
            context: Execution context with variables.

        Returns:
            Dictionary with execution results.
        """
        workflow = self.get_workflow(name)
        if not workflow:
            return {
                "success": False,
                "error": f"Workflow '{name}' not found",
            }

        runner = WorkflowRunner(workflow, context or {})
        execution = runner.run()

        self.executions[execution.id] = execution

        return {
            "success": execution.status == WorkflowStatus.COMPLETED,
            "execution_id": execution.id,
            "workflow_name": execution.workflow_name,
            "status": execution.status.value,
            "step_results": execution.step_results,
            "error": execution.error,
            "started_at": execution.started_at.isoformat()
            if execution.started_at
            else None,
            "completed_at": execution.completed_at.isoformat()
            if execution.completed_at
            else None,
        }

    def create_workflow(
        self,
        name: str,
        description: str,
        steps: list[dict[str, Any]],
        version: str = "1.0.0",
        allow_rollback: bool = True,
    ) -> dict[str, Any]:
        """Create a new custom workflow.

        Args:
            name: Workflow name.
            description: Workflow description.
            steps: List of step definitions.
            version: Version string.
            allow_rollback: Whether to enable rollback.

        Returns:
            Dictionary with creation result.
        """
        workflow = Workflow(
            id=str(uuid.uuid4()),
            name=name,
            description=description,
            version=version,
            steps=[WorkflowStep(id=str(uuid.uuid4()), **s) for s in steps],
            allow_rollback=allow_rollback,
        )

        key = name.lower().replace(" ", "_")
        self.workflows[key] = workflow

        file_path = self.workflows_dir / f"{key}.yaml"
        with open(file_path, "w") as f:
            yaml.dump(workflow.to_dict(), f, default_flow_style=False)

        return {
            "success": True,
            "workflow": {
                "id": workflow.id,
                "name": workflow.name,
                "description": workflow.description,
                "steps": len(workflow.steps),
            },
            "path": str(file_path),
        }

    def get_status(self, execution_id: str) -> Optional[dict[str, Any]]:
        """Get the status of a workflow execution.

        Args:
            execution_id: The execution ID.

        Returns:
            Execution status dictionary or None if not found.
        """
        execution = self.executions.get(execution_id)
        if not execution:
            return None

        return {
            "execution_id": execution.id,
            "workflow_name": execution.workflow_name,
            "status": execution.status.value,
            "step_results": execution.step_results,
            "error": execution.error,
            "started_at": execution.started_at.isoformat()
            if execution.started_at
            else None,
            "completed_at": execution.completed_at.isoformat()
            if execution.completed_at
            else None,
        }

    def delete_workflow(self, name: str) -> dict[str, Any]:
        """Delete a custom workflow.

        Args:
            name: Workflow name.

        Returns:
            Deletion result.
        """
        key = name.lower().replace(" ", "_")
        if key in ["code_review", "deploy", "test_suite", "refactor"]:
            return {
                "success": False,
                "error": "Cannot delete built-in workflows",
            }

        workflow = self.workflows.pop(key, None)
        if not workflow:
            return {"success": False, "error": f"Workflow '{name}' not found"}

        for file_path in self.workflows_dir.glob(f"{key}.*"):
            file_path.unlink()

        return {"success": True, "deleted": workflow.name}


workflow_manager = WorkflowManager()
