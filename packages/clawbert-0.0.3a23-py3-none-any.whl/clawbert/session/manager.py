"""Session management for Clawbert.

This module handles conversation sessions, providing persistent chat history
that is stored locally in each project's .clawbert/sessions directory.

Sessions allow multiple independent conversations with full history preservation.
Each session tracks:
    - Unique ID and human-readable name
    - Complete message history (user/assistant messages)
    - Active skill for context-aware responses
    - Creation timestamp

Sessions are stored as JSON files in .clawbert/sessions/ within the
current working directory, making them project-specific.

Example:
    from .session.manager import session_manager

    # Create new session
    session = session_manager.create("Project Discussion")

    # Add messages
    session_manager.add_message(session.id, "user", "Hello!")
    session_manager.add_message(session.id, "assistant", "Hi there!")

    # Get conversation history
    messages = session_manager.get_messages(session.id)

    # List all sessions
    for s in session_manager.list_sessions():
        print(f"{s['name']}: {s['message_count']} messages")
"""

import json
from pathlib import Path
from typing import Optional
from datetime import datetime
from dataclasses import dataclass, field


def get_local_clawbert_dir() -> Path:
    """Get the local .clawbert directory in current working directory.

    Returns:
        Path to .clawbert directory in CWD
    """
    cwd = Path.cwd()
    local_dir = cwd / ".clawbert"
    local_dir.mkdir(parents=True, exist_ok=True)
    return local_dir


def get_local_sessions_dir() -> Path:
    """Get the sessions directory in .clawbert.

    Returns:
        Path to sessions directory
    """
    sessions_dir = get_local_clawbert_dir() / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    return sessions_dir


@dataclass
class Message:
    """Represents a single message in a session.

    Attributes:
        role: The role (user/assistant/system).
        content: The message content.
        timestamp: ISO timestamp of the message.
    """

    role: str
    content: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Session:
    """Represents a conversation session.

    Attributes:
        id: Unique session identifier.
        name: Human-readable session name.
        messages: List of messages in the session.
        created_at: ISO timestamp of session creation.
        active_skill: Currently active skill for this session.
    """

    id: str
    name: str
    messages: list[Message] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    active_skill: str = "general"


class SessionManager:
    """Manages conversation sessions with persistence.

    Handles creating, loading, saving, and managing multiple
    conversation sessions that persist across CLI invocations.

    Uses .clawbert/sessions in current working directory.
    """

    def __init__(self, sessions_dir: Optional[Path] = None):
        """Initialize the session manager.

        Args:
            sessions_dir: Optional custom directory for sessions.
                         Defaults to local .clawbert/sessions directory.
        """
        if sessions_dir is None:
            sessions_dir = get_local_sessions_dir()

        self.sessions_dir = Path(sessions_dir)
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.sessions: dict[str, Session] = {}
        self.current_session_id: Optional[str] = None
        self._load_sessions()

    def _load_sessions(self):
        """Load all sessions from the sessions directory."""
        for session_file in self.sessions_dir.glob("*.json"):
            try:
                with open(session_file) as f:
                    data = json.load(f)
                    session = Session(
                        id=data["id"],
                        name=data["name"],
                        messages=[Message(**m) for m in data.get("messages", [])],
                        created_at=data.get("created_at", datetime.now().isoformat()),
                        active_skill=data.get("active_skill", "general"),
                    )
                    self.sessions[session.id] = session
            except (json.JSONDecodeError, KeyError):
                pass

    def _save_session(self, session: Session):
        """Save a session to disk."""
        session_file = self.sessions_dir / f"{session.id}.json"
        data = {
            "id": session.id,
            "name": session.name,
            "messages": [
                {"role": m.role, "content": m.content, "timestamp": m.timestamp}
                for m in session.messages
            ],
            "created_at": session.created_at,
            "active_skill": session.active_skill,
        }
        with open(session_file, "w") as f:
            json.dump(data, f, indent=2)

    def create(self, name: Optional[str] = None) -> Session:
        """Create a new session."""
        session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        session = Session(id=session_id, name=name or f"Chat {session_id}")
        self.sessions[session_id] = session
        self.current_session_id = session_id
        self._save_session(session)
        return session

    def get(self, session_id: str) -> Optional[Session]:
        """Get a session by ID."""
        return self.sessions.get(session_id)

    def get_current(self) -> Optional[Session]:
        """Get the current active session."""
        if self.current_session_id:
            return self.sessions.get(self.current_session_id)
        return None

    def set_current(self, session_id: str) -> bool:
        """Set the current active session."""
        if session_id in self.sessions:
            self.current_session_id = session_id
            return True
        return False

    def add_message(self, session_id: str, role: str, content: str):
        """Add a message to a session."""
        session = self.sessions.get(session_id)
        if session:
            session.messages.append(Message(role=role, content=content))
            self._save_session(session)

    def get_messages(self, session_id: str) -> list[dict]:
        """Get all messages from a session."""
        session = self.sessions.get(session_id)
        if session:
            return [{"role": m.role, "content": m.content} for m in session.messages]
        return []

    def list_sessions(self) -> list[dict]:
        """List all available sessions."""
        return [
            {
                "id": s.id,
                "name": s.name,
                "message_count": len(s.messages),
                "created_at": s.created_at,
                "active_skill": s.active_skill,
            }
            for s in self.sessions.values()
        ]

    def delete(self, session_id: str) -> bool:
        """Delete a session."""
        if session_id in self.sessions:
            del self.sessions[session_id]
            session_file = self.sessions_dir / f"{session_id}.json"
            if session_file.exists():
                session_file.unlink()
            if self.current_session_id == session_id:
                self.current_session_id = None
            return True
        return False


session_manager = SessionManager()
