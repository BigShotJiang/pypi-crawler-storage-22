"""Skills system for Clawbert following Agent Skills specification.

This module provides skill management following the Agent Skills specification
from agentskills.io. Skills are specialized capabilities that the LLM can
automatically activate based on the user's request.

Skills follow a directory structure:
    skills/
    ├── skill-name/
    │   └── SKILL.md    # YAML frontmatter + markdown content

SKILL.md Format:
    ---
    name: skill-name
    description: What this skill does
    allowed_tools:
      - web_search
      - web_fetch
    ---

    # Detailed instructions
    You are an expert at...

Features:
    - YAML frontmatter for skill metadata
    - Hot-reloading of skills at runtime
    - Tool restrictions per skill
    - Auto-selection based on context

Example:
    from .skills.registry import skill_registry

    # List all skills
    for name, skill in skill_registry.skills.items():
        print(f"{name}: {skill.description}")

    # Get specific skill
    skill = skill_registry.get("web-research")

    # Reload skills from disk
    skill_registry.reload()
"""

import re
import yaml
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field, asdict


@dataclass
class Skill:
    """Represents a skill following Agent Skills specification.

    Attributes:
        name: Unique skill identifier (lowercase with hyphens).
        description: Human-readable description of what the skill does.
        version: Skill version (e.g., "1.0.0").
        instructions: Detailed instructions for the skill.
        license: Optional license for the skill.
        compatibility: Optional compatibility requirements.
        metadata: Optional arbitrary metadata.
        allowed_tools: List of tools this skill can use.
        env: Environment variables required for this skill.
        apiKey: API key required for this skill.
        enabled: Whether the skill is currently enabled.
        skill_dir: Directory path where skill files are stored.
    """

    name: str
    description: str
    version: str = "1.0.0"
    instructions: str = ""
    license: Optional[str] = None
    compatibility: Optional[str] = None
    metadata: dict = field(default_factory=dict)
    allowed_tools: list[str] = field(default_factory=list)
    env: dict = field(default_factory=dict)
    apiKey: str = ""
    enabled: bool = True
    skill_dir: Optional[Path] = None

    def to_dict(self):
        """Convert skill to dictionary.

        Returns:
            Dictionary representation of the skill.
        """
        return asdict(self)

    @classmethod
    def from_dir(cls, skill_dir: Path) -> Optional["Skill"]:
        """Load skill from a directory following Agent Skills spec.

        Reads SKILL.md from the directory and parses YAML frontmatter.

        Args:
            skill_dir: Path to the skill directory.

        Returns:
            Skill object, or None if SKILL.md doesn't exist.
        """
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            return None

        content = skill_md.read_text(encoding="utf-8")

        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                try:
                    frontmatter = yaml.safe_load(parts[1])
                except yaml.YAMLError:
                    return None

                instructions = parts[2].strip() if len(parts) > 2 else ""

                allowed_tools = frontmatter.get("allowed_tools", [])
                if isinstance(allowed_tools, str):
                    if "," in allowed_tools:
                        allowed_tools = [
                            t.strip() for t in allowed_tools.split(",") if t.strip()
                        ]
                    else:
                        allowed_tools = [
                            t.strip() for t in allowed_tools.split() if t.strip()
                        ]

                return cls(
                    name=frontmatter.get("name", skill_dir.name),
                    description=frontmatter.get("description", ""),
                    version=frontmatter.get("version", "1.0.0"),
                    instructions=instructions,
                    license=frontmatter.get("license"),
                    compatibility=frontmatter.get("compatibility"),
                    metadata=frontmatter.get("metadata", {}),
                    allowed_tools=allowed_tools,
                    env=frontmatter.get("env", {}),
                    apiKey=frontmatter.get("apiKey", ""),
                    skill_dir=skill_dir,
                )
        return None

    def get_scripts(self) -> list[Path]:
        """Get list of scripts in the skill's scripts/ directory.

        Returns:
            List of Path objects for script files.
        """
        if not self.skill_dir:
            return []
        scripts_dir = self.skill_dir / "scripts"
        if scripts_dir.exists():
            return list(scripts_dir.iterdir())
        return []

    def get_references(self) -> list[Path]:
        """Get list of reference files in the references/ directory.

        Returns:
            List of Path objects for reference files.
        """
        if not self.skill_dir:
            return []
        refs_dir = self.skill_dir / "references"
        if refs_dir.exists():
            return list(refs_dir.iterdir())
        return []


class SkillRegistry:
    """Registry for managing skills.

    Handles loading, creating, and managing skills following
    the Agent Skills specification. Supports both built-in
    and custom skills loaded from disk.

    Attributes:
        skills_dir: Directory where custom skills are stored.
        skills: Dictionary of skill name to Skill objects.
    """

    def __init__(self, skills_dir: Optional[Path] = None):
        """Initialize the skill registry.

        Args:
            skills_dir: Optional custom directory for skills.
                       Defaults to config skills_dir.
        """
        if skills_dir is None:
            from ..core.config import config

            skills_dir = config.skills_dir

        self.skills_dir = Path(skills_dir)
        self.skills_dir.mkdir(parents=True, exist_ok=True)
        self.skills: dict[str, Skill] = {}
        self._register_builtin_skills()
        self._load_default_skills()
        self._load_custom_skills()

    def _load_default_skills(self):
        """Load default bundled skills from the package.

        Loads skills from the default/ directory
        that are shipped with the package.
        """
        package_skills_dir = Path(__file__).parent / "default"

        if not package_skills_dir.exists():
            return

        for item in package_skills_dir.iterdir():
            if item.is_dir():
                skill = Skill.from_dir(item)
                if skill and skill.name not in self.skills:
                    self.skills[skill.name] = skill

    def _register_builtin_skills(self):
        """Register built-in skills.

        Creates the core skills that are always available:
        general, developer, researcher, file_manager.
        """
        builtin_dir = self.skills_dir / "_builtin"
        builtin_dir.mkdir(parents=True, exist_ok=True)

        self._create_builtin_skill(
            "general",
            "General assistant capabilities",
            """You are Clawbert, a helpful AI assistant. Use the available tools to assist the user.

# Available Tools
- read: Read file contents
- write: Write content to files
- exec: Execute shell commands
- web_search: Search the web
- web_fetch: Fetch URL content
- memory_search: Search memory
- memory_store: Store in memory
- list_directory: List directory contents

# Guidelines
- Use tools when appropriate - don't just describe what you would do
- Be concise and helpful
- Remember important information in memory for future recall""",
            [
                "read",
                "write",
                "exec",
                "web_search",
                "web_fetch",
                "memory_store",
                "memory_search",
                "list_directory",
            ],
        )

        self._create_builtin_skill(
            "developer",
            "Software development assistant",
            """You are a software development assistant. Help with coding tasks.

# Workflow
1. Use list_directory to explore project structure
2. Use read to examine existing code
3. Use write to create or modify code files
4. Use exec to run builds, tests, linters

# Best Practices
- Follow existing project patterns
- Write clean, maintainable code
- Use appropriate error handling
- Test your changes""",
            ["read", "write", "exec", "list_directory", "web_search"],
        )

        self._create_builtin_skill(
            "researcher",
            "Research and information gathering",
            """You are a research assistant. Help gather and organize information.

# Workflow
1. Use web_search to find relevant sources
2. Use web_fetch to read specific pages in detail
3. Use memory_store to save important findings with keys
4. Use memory_search to recall previous research

# Guidelines
- Always cite sources
- Organize findings clearly
- Be thorough but concise""",
            ["web_search", "web_fetch", "memory_store", "memory_search"],
        )

        self._create_builtin_skill(
            "file_manager",
            "File and directory management",
            """You are a file management assistant.

# Operations
- Use list_directory to explore directories
- Use read to view file contents
- Use write to create or modify files
- Use exec for advanced operations (mv, cp, rm, mkdir)

# Guidelines
- Always confirm before destructive operations
- Show what was done
- Be careful with rm and rm -rf""",
            ["read", "write", "list_directory", "exec"],
        )

    def _create_builtin_skill(
        self, name: str, description: str, instructions: str, allowed_tools: list[str]
    ):
        """Create and register a built-in skill.

        Args:
            name: Skill identifier.
            description: Human-readable description.
            instructions: Detailed instructions.
            allowed_tools: List of tool names this skill can use.
        """
        skill = Skill(
            name=name,
            description=description,
            instructions=instructions,
            allowed_tools=allowed_tools,
            enabled=True,
        )
        self.skills[name] = skill

    def _load_custom_skills(self):
        """Hot-load custom skills from the skills directory.

        Scans the skills directory for subdirectories containing
        SKILL.md files and loads them as skills.
        """
        if not self.skills_dir.exists():
            return

        for item in self.skills_dir.iterdir():
            if item.is_dir() and not item.name.startswith("_"):
                skill = Skill.from_dir(item)
                if skill:
                    self.skills[skill.name] = skill

    def reload(self):
        """Hot-reload skills from disk.

        Cleads and re-loads all custom skills from the
        skills directory.
        """
        self._load_custom_skills()

    def register(self, skill: Skill):
        """Register a skill in the registry.

        Args:
            skill: The Skill object to register.
        """
        self.skills[skill.name] = skill

    def create(
        self,
        name: str,
        description: str,
        instructions: str,
        allowed_tools: Optional[list[str]] = None,
    ) -> Skill:
        """Create a new skill following Agent Skills spec.

        Validates the name, creates the skill directory,
        writes SKILL.md with YAML frontmatter, and registers
        the skill.

        Args:
            name: Skill identifier (lowercase with hyphens).
            description: Human-readable description.
            instructions: Detailed instructions.
            allowed_tools: Optional list of allowed tools.

        Returns:
            The newly created Skill object.

        Raises:
            ValueError: If skill name is invalid.
        """
        if not re.match(r"^[a-z0-9]+[-_a-z0-9]*$", name):
            raise ValueError(
                f"Invalid skill name: {name}. Use lowercase letters, numbers, hyphens, and underscores only."
            )

        skill_dir = self.skills_dir / name
        skill_dir.mkdir(parents=True, exist_ok=True)

        skill_md = skill_dir / "SKILL.md"
        frontmatter = {
            "name": name,
            "description": description,
            "allowed_tools": " ".join(allowed_tools) if allowed_tools else "",
        }

        yaml_content = yaml.dump(frontmatter, default_flow_style=False)
        skill_md.write_text(
            f"---\n{yaml_content}---\n\n{instructions}", encoding="utf-8"
        )

        skill = Skill(
            name=name,
            description=description,
            instructions=instructions,
            allowed_tools=allowed_tools or [],
            skill_dir=skill_dir,
        )
        self.skills[name] = skill
        return skill

    def save_skill(self, skill: Skill):
        """Save skill to file for persistence.

        Args:
            skill: The Skill object to save.
        """
        if not skill.skill_dir:
            skill.skill_dir = self.skills_dir / skill.name

        skill.skill_dir.mkdir(parents=True, exist_ok=True)
        skill_md = skill.skill_dir / "SKILL.md"

        frontmatter = {
            "name": skill.name,
            "description": skill.description,
        }
        if skill.license:
            frontmatter["license"] = skill.license
        if skill.compatibility:
            frontmatter["compatibility"] = skill.compatibility
        if skill.metadata:
            frontmatter["metadata"] = str(skill.metadata)
        if skill.allowed_tools:
            frontmatter["allowed_tools"] = " ".join(skill.allowed_tools)

        yaml_content = yaml.dump(frontmatter, default_flow_style=False)
        skill_md.write_text(
            f"---\n{yaml_content}---\n\n{skill.instructions}", encoding="utf-8"
        )

        self.skills[skill.name] = skill

    def get(self, name: str) -> Optional[Skill]:
        """Get a skill by name.

        Args:
            name: The skill name to look up.

        Returns:
            The Skill object, or None if not found.
        """
        return self.skills.get(name)

    def get_enabled(self) -> list[Skill]:
        """Get all enabled skills.

        Returns:
            List of enabled Skill objects.
        """
        return [s for s in self.skills.values() if s.enabled]

    def enable(self, name: str):
        """Enable a skill.

        Args:
            name: The skill name to enable.
        """
        if name in self.skills:
            self.skills[name].enabled = True

    def disable(self, name: str):
        """Disable a skill.

        Args:
            name: The skill name to disable.
        """
        if name in self.skills:
            self.skills[name].enabled = False

    def delete(self, name: str) -> bool:
        """Delete a skill.

        Args:
            name: The skill name to delete.

        Returns:
            True if deleted, False if not found.
        """
        if name in self.skills:
            skill = self.skills[name]
            if skill.skill_dir and skill.skill_dir.exists():
                import shutil

                shutil.rmtree(skill.skill_dir)
            del self.skills[name]
            return True
        return False

    def get_instructions(self) -> str:
        """Get combined instructions from all enabled skills.

        Returns:
            Concatenated instructions from enabled skills.
        """
        instructions = []
        for skill in self.get_enabled():
            instructions.append(f"## {skill.name.upper()}\n{skill.instructions}")
        return "\n\n".join(instructions)

    def list_all(self) -> str:
        """Get a formatted list of all skills.

        Returns:
            Formatted string listing all skills with status.
        """
        lines = ["Available Skills:"]
        for name, skill in self.skills.items():
            status = "✓" if skill.enabled else "✗"
            lines.append(f"  {status} {name}: {skill.description}")
        return "\n".join(lines)

    def get_skill_descriptions(self) -> str:
        """Get brief descriptions for all skills.

        Returns:
            Formatted string with skill names, versions, and descriptions.
        """
        lines = []
        for name, skill in self.skills.items():
            if skill.enabled:
                tools_info = (
                    f" (tools: {', '.join(skill.allowed_tools)})"
                    if skill.allowed_tools
                    else ""
                )
                lines.append(
                    f"- {name} v{skill.version}: {skill.description}{tools_info}"
                )
        return "\n".join(lines)

    def get_skill_info(self, name: str) -> dict:
        """Get detailed info for a specific skill.

        Args:
            name: Skill name.

        Returns:
            Dict with skill details including version, tools, env requirements.
        """
        skill = self.skills.get(name)
        if not skill:
            return {}

        return {
            "name": skill.name,
            "version": skill.version,
            "description": skill.description,
            "allowed_tools": skill.allowed_tools,
            "env": skill.env,
            "apiKey_required": bool(skill.apiKey),
            "instructions": skill.instructions[:500] if skill.instructions else "",
        }


skill_registry = SkillRegistry()
