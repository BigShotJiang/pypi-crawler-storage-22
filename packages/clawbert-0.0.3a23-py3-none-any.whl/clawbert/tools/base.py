"""Base tool classes and definitions."""

from dataclasses import dataclass
from typing import Callable


@dataclass
class Tool:
    """Represents a callable tool for the LLM.

    Attributes:
        name: Unique identifier for the tool.
        description: Human-readable description of what the tool does.
        func: The callable function to execute.
        parameters: JSON schema for the tool's parameters.
        risk_level: Risk assessment (low, medium, high, very_high).
    """

    name: str
    description: str
    func: Callable
    parameters: dict
    risk_level: str = "medium"
