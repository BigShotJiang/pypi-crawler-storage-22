"""Database operation tools."""

import sqlite3
from pathlib import Path
from typing import Optional

import requests


class DatabaseTools:
    """Database operation tools for SQLite, PostgreSQL, MySQL, and HTTP requests."""

    def _sqlite_query(self, database_path: str, query: str) -> str:
        """Execute a SELECT SQL query on a SQLite database.

        Args:
            database_path: Path to the SQLite database file.
            query: SQL query to execute (SELECT only).

        Returns:
            Query results in formatted table.
        """
        query = query.strip()
        if not query.lower().startswith("select"):
            return "Error: Only SELECT queries are allowed for safety"

        p = Path(database_path).expanduser()
        if not p.exists():
            return f"Error: Database file not found: {database_path}"

        try:
            conn = sqlite3.connect(str(p))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(query)
            rows = cursor.fetchall()

            if not rows:
                conn.close()
                return "Query executed successfully. No rows returned."

            columns = [desc[0] for desc in cursor.description]
            col_widths = {col: len(col) for col in columns}

            formatted_rows = []
            for row in rows:
                row_data = dict(row)
                formatted_rows.append(row_data)
                for col in columns:
                    val_len = len(str(row_data.get(col, "")))
                    col_widths[col] = max(col_widths[col], val_len)

            header = " | ".join(col.ljust(col_widths[col]) for col in columns)
            separator = "-+-".join("-" * col_widths[col] for col in columns)

            lines = [header, separator]
            for row in formatted_rows:
                line = " | ".join(
                    str(row.get(col, "")).ljust(col_widths[col]) for col in columns
                )
                lines.append(line)

            conn.close()
            result_count = len(rows)
            return (
                "\n".join(lines)
                + f"\n\n({result_count} row{'s' if result_count != 1 else ''})"
            )
        except sqlite3.Error as e:
            return f"SQLite error: {e}"
        except Exception as e:
            return f"Error: {e}"

    def _sqlite_list(self, database_path: str) -> str:
        """List all tables in a SQLite database with row counts.

        Args:
            database_path: Path to the SQLite database file.

        Returns:
            List of tables with row counts.
        """
        p = Path(database_path).expanduser()
        if not p.exists():
            return f"Error: Database file not found: {database_path}"

        try:
            conn = sqlite3.connect(str(p))
            cursor = conn.cursor()

            cursor.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
            )
            tables = [row[0] for row in cursor.fetchall()]

            if not tables:
                conn.close()
                return "No tables found in database"

            result = ["Tables in database:"]
            for table in tables:
                cursor.execute(f'SELECT COUNT(*) FROM "{table}"')
                count = cursor.fetchone()[0]
                result.append(f"  - {table}: {count} rows")

            conn.close()
            return "\n".join(result)
        except sqlite3.Error as e:
            return f"SQLite error: {e}"
        except Exception as e:
            return f"Error: {e}"

    def _postgres_query(self, connection_string: str, query: str) -> str:
        """Execute a SQL query on a PostgreSQL database.

        Args:
            connection_string: PostgreSQL connection string.
            query: SQL query to execute.

        Returns:
            Formatted query results.
        """
        import importlib.util

        psycopg2_spec = importlib.util.find_spec("psycopg2")
        psycopg_spec = importlib.util.find_spec("psycopg")
        if psycopg2_spec is None and psycopg_spec is None:
            return "Error: PostgreSQL driver not installed. Install psycopg2 or psycopg (pip install psycopg2 or pip install psycopg)"

        try:
            import psycopg2
        except ImportError:
            try:
                import psycopg as psycopg
            except ImportError:
                return "Error: PostgreSQL driver not installed. Install psycopg2 or psycopg (pip install psycopg2 or pip install psycopg)"

        try:
            import psycopg2

            conn = psycopg2.connect(connection_string)
            cursor = conn.cursor()
            cursor.execute(query)

            if query.strip().lower().startswith("select"):
                rows = cursor.fetchall()
                if not cursor.description:
                    conn.close()
                    return "Query executed successfully. No results."

                columns = [desc[0] for desc in cursor.description]
                if not rows:
                    conn.close()
                    return "Query executed successfully. No rows returned."

                col_widths = {col: len(col) for col in columns}
                for row in rows:
                    for i, col in enumerate(columns):
                        val_len = len(str(row[i]))
                        col_widths[col] = max(col_widths[col], val_len)

                header = " | ".join(col.ljust(col_widths[col]) for col in columns)
                separator = "-+-".join("-" * col_widths[col] for col in columns)

                lines = [header, separator]
                for row in rows:
                    line = " | ".join(
                        str(row[i]).ljust(col_widths[columns[i]])
                        for i in range(len(columns))
                    )
                    lines.append(line)

                conn.close()
                result_count = len(rows)
                return (
                    "\n".join(lines)
                    + f"\n\n({result_count} row{'s' if result_count != 1 else ''})"
                )
            else:
                conn.commit()
                affected = cursor.rowcount
                conn.close()
                return f"Query executed successfully. {affected} row(s) affected."
        except Exception as e:
            return f"PostgreSQL error: {e}"

    def _mysql_query(self, connection_string: str, query: str) -> str:
        """Execute a SQL query on a MySQL database.

        Args:
            connection_string: MySQL connection string.
            query: SQL query to execute.

        Returns:
            Formatted query results.
        """
        try:
            import mysql.connector
        except ImportError:
            try:
                import pymysql

                class FakeCursor:
                    def __init__(self, conn):
                        self.conn = conn
                        self._results = None
                        self.description = None

                    def execute(self, q):
                        self._results = self.conn.query(q)
                        if self._results is None:
                            self.description = ()
                        else:
                            self.description = tuple(
                                (k,)
                                for k in (self._results[0] if self._results else [])
                            )

                    def fetchall(self):
                        return self._results[1] if self._results else []

                    def close(self):
                        pass

                class FakeConnection:
                    def __init__(self, **kwargs):
                        self._conn = pymysql.connect(**kwargs)

                    def cursor(self):
                        return FakeCursor(self._conn)

                    def close(self):
                        self._conn.close()

                    def commit(self):
                        pass

                MysqlConnection = FakeConnection
            except ImportError:
                return "Error: MySQL driver not installed. Install mysql-connector-python or pymysql (pip install mysql-connector-python or pip install pymysql)"
        else:
            MysqlConnection = mysql.connector.connect

        try:
            from urllib.parse import urlparse

            parsed = urlparse(connection_string)
            kwargs = {
                "host": parsed.hostname or "localhost",
                "port": parsed.port or 3306,
                "user": parsed.username,
                "password": parsed.password,
                "database": parsed.path.lstrip("/") if parsed.path else "",
            }
            conn = MysqlConnection(**kwargs)
            cursor = conn.cursor()
            cursor.execute(query)

            if query.strip().lower().startswith("select"):
                rows = cursor.fetchall()
                if not cursor.description:
                    conn.close()
                    return "Query executed successfully. No results."

                columns = [desc[0] for desc in cursor.description]
                if not rows:
                    conn.close()
                    return "Query executed successfully. No rows returned."

                col_widths = {col: len(col) for col in columns}
                for row in rows:
                    for i, col in enumerate(columns):
                        val_len = len(str(row[i])) if i < len(row) else 0
                        col_widths[col] = max(col_widths[col], val_len)

                header = " | ".join(col.ljust(col_widths[col]) for col in columns)
                separator = "-+-".join("-" * col_widths[col] for col in columns)

                lines = [header, separator]
                for row in rows:
                    line = " | ".join(
                        str(row[i]).ljust(col_widths[columns[i]])
                        for i in range(len(columns))
                    )
                    lines.append(line)

                conn.close()
                result_count = len(rows)
                return (
                    "\n".join(lines)
                    + f"\n\n({result_count} row{'s' if result_count != 1 else ''})"
                )
            else:
                conn.commit()
                affected = cursor.rowcount
                conn.close()
                return f"Query executed successfully. {affected} row(s) affected."
        except Exception as e:
            return f"MySQL error: {e}"

    def _http_request(
        self,
        url: str,
        method: str = "GET",
        headers: Optional[dict] = None,
        body: Optional[str] = None,
        params: Optional[dict] = None,
    ) -> str:
        """Make HTTP requests with full control over parameters.

        Args:
            url: The URL to request.
            method: HTTP method (GET, POST, PUT, DELETE, PATCH).
            headers: Optional HTTP headers.
            body: Request body for POST/PUT/PATCH.
            params: Optional query parameters.

        Returns:
            Formatted HTTP response details.
        """
        method = method.upper()
        valid_methods = ["GET", "POST", "PUT", "DELETE", "PATCH"]
        if method not in valid_methods:
            return f"Error: Invalid method '{method}'. Use: {', '.join(valid_methods)}"

        if not url.startswith(("http://", "https://")):
            return "Error: URL must start with http:// or https://"

        req_headers = headers or {}
        if "User-Agent" not in req_headers:
            req_headers["User-Agent"] = "Clawbert/1.0"

        try:
            request_kwargs = {
                "url": url,
                "headers": req_headers,
                "timeout": 30,
            }

            if params:
                request_kwargs["params"] = params

            if body and method in ["POST", "PUT", "PATCH"]:
                try:
                    import json as json_module

                    parsed = json_module.loads(body)
                    request_kwargs["json"] = parsed
                    if "Content-Type" not in req_headers:
                        req_headers["Content-Type"] = "application/json"
                except json_module.JSONDecodeError:
                    request_kwargs["data"] = body
                    if "Content-Type" not in req_headers:
                        req_headers["Content-Type"] = "text/plain"

            response = requests.request(method, **request_kwargs)

            result = [
                f"Status: {response.status_code} {response.reason}",
                f"URL: {response.url}",
                "",
                "Response Headers:",
            ]
            for key, value in response.headers.items():
                result.append(f"  {key}: {value}")

            result.append("")
            result.append("Response Body:")

            try:
                body_text = response.json()
                import json as json_module

                body_formatted = json_module.dumps(body_text, indent=2)
                result.append(body_formatted[:10000])
            except Exception:
                body_text = response.text
                result.append(body_text[:10000])

            if len(response.text) > 10000:
                result.append(f"\n... (truncated, total {len(response.text)} bytes)")

            return "\n".join(result)

        except requests.exceptions.Timeout:
            return "Error: Request timed out after 30 seconds"
        except requests.exceptions.ConnectionError as e:
            return f"Error: Connection failed - {e}"
        except requests.exceptions.InvalidURL as e:
            return f"Error: Invalid URL - {e}"
        except Exception as e:
            return f"Error: Request failed - {e}"

    def _http_test(
        self,
        url: str,
        expected_status: int = 200,
        contains: Optional[str] = None,
        method: str = "GET",
        body: Optional[str] = None,
    ) -> str:
        """Simple API testing - verify status code and optional content.

        Args:
            url: URL to test.
            expected_status: Expected HTTP status code.
            contains: Text that should be in the response.
            method: HTTP method.
            body: Request body for POST/PUT/PATCH.

        Returns:
            Pass/fail test results with details.
        """
        method = method.upper()

        if not url.startswith(("http://", "https://")):
            return "FAIL\nError: URL must start with http:// or https://"

        req_headers = {"User-Agent": "Clawbert/1.0"}

        try:
            request_kwargs = {
                "url": url,
                "headers": req_headers,
                "timeout": 30,
            }

            if body and method in ["POST", "PUT", "PATCH"]:
                try:
                    import json as json_module

                    parsed = json_module.loads(body)
                    request_kwargs["json"] = parsed
                    req_headers["Content-Type"] = "application/json"
                except json_module.JSONDecodeError:
                    request_kwargs["data"] = body
                    req_headers["Content-Type"] = "text/plain"

            response = requests.request(method, **request_kwargs)

            tests_passed = []
            tests_failed = []

            if response.status_code == expected_status:
                tests_passed.append(
                    f"Status code: {response.status_code} == {expected_status}"
                )
            else:
                tests_failed.append(
                    f"Status code: {response.status_code} != {expected_status}"
                )

            if contains:
                if contains.lower() in response.text.lower():
                    tests_passed.append(f"Contains: '{contains}' found in response")
                else:
                    tests_failed.append(f"Contains: '{contains}' NOT found in response")

            result = []
            if not tests_failed:
                result.append("PASS")
            else:
                result.append("FAIL")

            result.append("")
            result.append("Tests:")
            for t in tests_passed:
                result.append(f"  [PASS] {t}")
            for t in tests_failed:
                result.append(f"  [FAIL] {t}")

            result.append("")
            result.append(f"Response: {response.status_code} {response.reason}")

            return "\n".join(result)

        except requests.exceptions.Timeout:
            return "FAIL\n\nTests:\n  [FAIL] Request timed out after 30 seconds"
        except requests.exceptions.ConnectionError as e:
            return f"FAIL\n\nTests:\n  [FAIL] Connection failed - {e}"
        except Exception as e:
            return f"FAIL\n\nTests:\n  [FAIL] Request failed - {e}"
