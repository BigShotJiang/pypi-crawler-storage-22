"""File operation tools."""

from pathlib import Path


class FileTools:
    """File operation tools for reading, writing, editing, and searching files."""

    def _read(self, path: str) -> str:
        """Read file contents or list directory.

        If the path is a directory, lists its contents.
        If it's a file, returns the file content.

        Args:
            path: Path to file or directory.

        Returns:
            File content or directory listing.
        """
        p = Path(path).expanduser()
        if not p.exists():
            return f"Error: Path does not exist: {path}"
        if p.is_dir():
            return self._list_directory(path)
        if p.is_file():
            try:
                return p.read_text(encoding="utf-8")
            except Exception as e:
                return f"Error reading file: {e}"
        return f"Error: {path} is not a file or directory"

    def _write(self, path: str, content: str) -> str:
        """Write content to a file.

        Creates parent directories if they don't exist.

        Args:
            path: Path to the file to write.
            content: Content to write to the file.

        Returns:
            Success or error message.
        """
        p = Path(path).expanduser()
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
            return f"Successfully wrote to {path}"
        except Exception as e:
            return f"Error writing file: {e}"

    def _edit(self, path: str, find: str, replace: str) -> str:
        """Edit a file by replacing specific text.

        Finds the first occurrence of 'find' string and replaces it with 'replace'.
        For more complex edits, use read to see content, then write with full replacement.

        Args:
            path: Path to the file to edit.
            find: Text to find in the file.
            replace: Text to replace it with.

        Returns:
            Success or error message.
        """
        p = Path(path).expanduser()
        if not p.exists():
            return f"Error: File does not exist: {path}"

        try:
            content = p.read_text(encoding="utf-8")
            if find not in content:
                return f"Error: Text '{find[:50]}...' not found in file. Use read tool first to see exact content."

            new_content = content.replace(find, replace, 1)
            p.write_text(new_content, encoding="utf-8")
            return f"Successfully edited {path}"
        except Exception as e:
            return f"Error editing file: {e}"

    def _grep(self, pattern: str, path: str = ".") -> str:
        """Search for text patterns in files.

        Recursively searches for the pattern in files within the given directory.

        Args:
            pattern: Text pattern to search for.
            path: Directory path to search in (default: current directory).

        Returns:
            Matching lines with file paths.
        """
        p = Path(path).expanduser()
        if not p.exists():
            return f"Error: Path does not exist: {path}"

        matches = []
        try:
            for file_path in p.rglob("*"):
                if file_path.is_file() and not any(
                    part.startswith(".") for part in file_path.parts
                ):
                    try:
                        content = file_path.read_text(encoding="utf-8")
                        for line_num, line in enumerate(content.split("\n"), 1):
                            if pattern.lower() in line.lower():
                                matches.append(
                                    f"{file_path}:{line_num}: {line.strip()}"
                                )
                    except (UnicodeDecodeError, PermissionError):
                        continue

            if not matches:
                return f"No matches found for '{pattern}' in {path}"

            return "\n".join(matches[:100])
        except Exception as e:
            return f"Error searching: {e}"

    def _glob(self, pattern: str, path: str = ".") -> str:
        """Find files matching a glob pattern.

        Recursively searches for files matching the pattern.

        Args:
            pattern: Glob pattern (e.g., "*.py", "**/*.js").
            path: Directory path to search in (default: current directory).

        Returns:
            List of matching file paths.
        """
        p = Path(path).expanduser()
        if not p.exists():
            return f"Error: Path does not exist: {path}"

        matches = list(p.rglob(pattern))
        if not matches:
            return f"No files matching '{pattern}' found in {path}"

        return "\n".join([str(m) for m in matches[:50]])

    def _list_directory(self, path: str) -> str:
        """List contents of a directory.

        Args:
            path: Directory path.

        Returns:
            Formatted directory listing.
        """
        p = Path(path).expanduser()
        if not p.exists():
            return f"Error: Path does not exist: {path}"
        if not p.is_dir():
            return f"Error: {path} is not a directory"
        try:
            items = []
            for item in p.iterdir():
                items.append(f"{'📁 ' if item.is_dir() else '📄 '}{item.name}")
            return "\n".join(items) or "Empty directory"
        except Exception as e:
            return f"Error listing directory: {e}"
