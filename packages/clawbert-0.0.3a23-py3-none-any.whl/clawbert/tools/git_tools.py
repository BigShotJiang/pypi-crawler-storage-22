"""Git operation tools."""

import subprocess
from pathlib import Path


class GitTools:
    """Git operation tools for version control."""

    def _run_git(self, args: list, path: str = ".") -> tuple[int, str]:
        """Run a git command in the specified directory.

        Args:
            args: Git command arguments.
            path: Path to the git repository.

        Returns:
            Tuple of (return_code, output).
        """
        p = Path(path).expanduser()
        if not p.exists():
            return 1, f"Error: Path does not exist: {path}"
        if not (p / ".git").exists():
            return 1, f"Error: Not a git repository: {path}"

        try:
            result = subprocess.run(
                ["git", "-C", str(p)] + args,
                capture_output=True,
                text=True,
                timeout=30,
            )
            output = result.stdout or result.stderr
            return result.returncode, output
        except subprocess.TimeoutExpired:
            return 1, "Error: Git command timed out after 30 seconds"
        except FileNotFoundError:
            return 1, "Error: git command not found. Is git installed?"
        except Exception as e:
            return 1, f"Error running git: {e}"

    def _git_status(self, path: str = ".") -> str:
        """Show git status.

        Args:
            path: Path to the git repository.

        Returns:
            Formatted git status output.
        """
        code, output = self._run_git(["status", "--porcelain"], path)
        if code != 0:
            return output

        if not output.strip():
            return "Working tree is clean"

        lines = output.strip().split("\n")
        staged = []
        modified = []
        untracked = []
        deleted = []
        renamed = []

        for line in lines:
            if len(line) < 2:
                continue
            index_status = line[0]
            worktree_status = line[1]
            filepath = line[3:] if line[2:] else line[2:]

            if index_status == "?":
                untracked.append(filepath)
            elif index_status == "R":
                renamed.append(filepath)
            elif index_status == "D" or worktree_status == "D":
                deleted.append(filepath)
            elif index_status != " " and index_status != "?":
                staged.append(filepath)
            elif worktree_status == "M" or worktree_status == "A":
                modified.append(filepath)
            else:
                modified.append(filepath)

        result = []
        if staged:
            result.append(f"Staged ({len(staged)}):")
            for f in staged:
                result.append(f"  + {f}")
        if modified:
            result.append(f"Modified ({len(modified)}):")
            for f in modified:
                result.append(f"  M {f}")
        if deleted:
            result.append(f"Deleted ({len(deleted)}):")
            for f in deleted:
                result.append(f"  D {f}")
        if renamed:
            result.append(f"Renamed ({len(renamed)}):")
            for f in renamed:
                result.append(f"  R {f}")
        if untracked:
            result.append(f"Untracked ({len(untracked)}):")
            for f in untracked:
                result.append(f"  ? {f}")

        return "\n".join(result)

    def _git_diff(self, staged: bool = False, path: str = ".") -> str:
        """Show diff of changes.

        Args:
            staged: Show staged changes only.
            path: Path to the git repository.

        Returns:
            Git diff output.
        """
        args = ["diff"]
        if staged:
            args.append("--cached")
        args.append("--no-color")

        code, output = self._run_git(args, path)
        if code != 0:
            return output
        if not output.strip():
            return "No changes to show"
        return output

    def _git_log(self, max_count: int = 10, path: str = ".") -> str:
        """Show commit history.

        Args:
            max_count: Maximum number of commits to show.
            path: Path to the git repository.

        Returns:
            Formatted commit history.
        """
        args = [
            "log",
            f"--max-count={max_count}",
            "--format=%h | %s | %an, %ar",
            "--no-color",
        ]

        code, output = self._run_git(args, path)
        if code != 0:
            return output
        if not output.strip():
            return "No commits found"
        return output

    def _git_branch(
        self,
        action: str = "list",
        branch_name: str = "",
        new_name: str = "",
        path: str = ".",
    ) -> str:
        """List, create, or delete branches.

        Args:
            action: Action to perform (list, create, delete, rename).
            branch_name: Branch name for create/delete/rename.
            new_name: New name for rename.
            path: Path to the git repository.

        Returns:
            Branch operation result.
        """
        action = action.lower()

        if action == "list":
            args = ["branch", "-a", "--format=%(refname:short)"]
            code, output = self._run_git(args, path)
            if code != 0:
                return output

            code_curr, current = self._run_git(["branch", "--show-current"], path)
            current = current.strip() if current.strip() else "(detached)"

            branches = output.strip().split("\n") if output.strip() else []
            result = [f"Current branch: {current}", ""]
            for b in branches:
                if b.strip():
                    prefix = "*" if b.strip() == current else " "
                    result.append(f"{prefix} {b.strip()}")
            return "\n".join(result)

        if action == "create":
            if not branch_name:
                return "Error: branch_name is required for create action"
            code, output = self._run_git(["branch", branch_name], path)
            if code != 0:
                return output
            return f"Created branch: {branch_name}"

        if action == "delete":
            if not branch_name:
                return "Error: branch_name is required for delete action"
            code, output = self._run_git(["branch", "-d", branch_name], path)
            if code != 0:
                return f"Error: {output}\n(Use -D to force delete)"
            return f"Deleted branch: {branch_name}"

        if action == "rename":
            if not branch_name or not new_name:
                return "Error: branch_name and new_name are required for rename action"
            code, output = self._run_git(["branch", "-m", branch_name, new_name], path)
            if code != 0:
                return output
            return f"Renamed branch: {branch_name} -> {new_name}"

        return f"Unknown action: {action}. Use: list, create, delete, rename"

    def _git_commit(self, message: str, amend: bool = False, path: str = ".") -> str:
        """Create a git commit.

        Args:
            message: Commit message.
            amend: Amend the previous commit.
            path: Path to the git repository.

        Returns:
            Commit result.
        """
        if amend:
            code, output = self._run_git(["commit", "--amend", "-m", message], path)
        else:
            code, output = self._run_git(["commit", "-m", message], path)

        if code != 0:
            return output
        return output.strip() if output.strip() else "Commit created successfully"

    def _git_push(
        self,
        remote: str = "origin",
        branch: str = "",
        set_upstream: bool = False,
        path: str = ".",
    ) -> str:
        """Push commits to remote.

        Args:
            remote: Remote name.
            branch: Branch to push.
            set_upstream: Set upstream for branch.
            path: Path to the git repository.

        Returns:
            Push result.
        """
        args = ["push"]
        if set_upstream:
            args.append("-u")
        args.append(remote)
        if branch:
            args.append(branch)

        code, output = self._run_git(args, path)
        if code != 0:
            return output
        return (
            output.strip()
            if output.strip()
            else f"Pushed to {remote}/{branch or 'current branch'}"
        )

    def _git_pull(
        self, remote: str = "origin", branch: str = "", path: str = "."
    ) -> str:
        """Pull commits from remote.

        Args:
            remote: Remote name.
            branch: Branch to pull.
            path: Path to the git repository.

        Returns:
            Pull result.
        """
        args = ["pull", remote]
        if branch:
            args.append(branch)

        code, output = self._run_git(args, path)
        if code != 0:
            return output
        return (
            output.strip()
            if output.strip()
            else f"Pulled from {remote}/{branch or 'current branch'}"
        )

    def _git_checkout(
        self,
        branch: str = "",
        file: str = "",
        create_branch: bool = False,
        path: str = ".",
    ) -> str:
        """Checkout a branch or file.

        Args:
            branch: Branch name to checkout.
            file: File to checkout (restore).
            create_branch: Create and switch to new branch.
            path: Path to the git repository.

        Returns:
            Checkout result.
        """
        if not branch and not file:
            return "Error: Either branch or file must be specified"

        if branch and file:
            return "Error: Specify either branch or file, not both"

        if file:
            code, output = self._run_git(["checkout", "--", file], path)
            if code != 0:
                return output
            return f"Restored file: {file}"

        args = ["checkout"]
        if create_branch:
            args.append("-b")
        args.append(branch)

        code, output = self._run_git(args, path)
        if code != 0:
            return output
        action = "Created and switched to" if create_branch else "Switched to"
        return f"{action} branch: {branch}"
