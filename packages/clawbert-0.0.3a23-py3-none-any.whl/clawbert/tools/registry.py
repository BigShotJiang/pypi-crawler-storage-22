"""Tool registry for managing available tools."""

from typing import Optional

from .base import Tool
from .file_tools import FileTools
from .git_tools import GitTools
from .web_tools import WebTools
from .system_tools import SystemTools
from .database_tools import DatabaseTools
from .scheduler_tools import SchedulerTools


class ToolRegistry(
    FileTools, GitTools, WebTools, SystemTools, DatabaseTools, SchedulerTools
):
    """Registry for managing available tools.

    Maintains a collection of tools that can be called by the
    LLM. Includes file operations, web access, memory, and
    skill management tools.

    Attributes:
        tools: Dictionary mapping tool name to Tool objects.
    """

    def __init__(self):
        """Initialize the tool registry and register built-in tools."""
        self.tools: dict[str, Tool] = {}
        self._register_builtin_tools()

    def _register_builtin_tools(self):
        """Register all built-in tools."""
        self._register_file_tools()
        self._register_git_tools()
        self._register_web_tools()
        self._register_system_tools()
        self._register_database_tools()
        self._register_memory_tools()
        self._register_skill_tools()
        self._register_todo_tools()

    def register(self, tool: Tool):
        """Register a tool in the registry.

        Args:
            tool: The Tool object to register.
        """
        self.tools[tool.name] = tool

    def get_tool(self, name: str) -> Optional[Tool]:
        """Get a tool by name.

        Args:
            name: The tool name to look up.

        Returns:
            The Tool object, or None if not found.
        """
        return self.tools.get(name)

    def get_available_tools(self) -> list[dict]:
        """Get all tools formatted for LLM function calling.

        Returns:
            List of tool definitions in OpenAI function calling format.
        """
        return [
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters,
                },
            }
            for tool in self.tools.values()
        ]

    def _register_file_tools(self):
        """Register file operation tools."""
        self.register(
            Tool(
                name="read",
                description="Read contents of a file or directory",
                func=self._read,
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path to file or directory",
                        }
                    },
                    "required": ["path"],
                },
                risk_level="low",
            )
        )

        self.register(
            Tool(
                name="write",
                description="Write content to a file",
                func=self._write,
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "Path to file"},
                        "content": {
                            "type": "string",
                            "description": "Content to write",
                        },
                    },
                    "required": ["path", "content"],
                },
                risk_level="medium",
            )
        )

        self.register(
            Tool(
                name="edit",
                description="Edit a file by replacing specific text (use read first to see content)",
                func=self._edit,
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path to file to edit",
                        },
                        "find": {
                            "type": "string",
                            "description": "Text to find in the file",
                        },
                        "replace": {
                            "type": "string",
                            "description": "Text to replace it with",
                        },
                    },
                    "required": ["path", "find", "replace"],
                },
                risk_level="medium",
            )
        )

        self.register(
            Tool(
                name="grep",
                description="Search for text patterns in files recursively",
                func=self._grep,
                parameters={
                    "type": "object",
                    "properties": {
                        "pattern": {
                            "type": "string",
                            "description": "Text pattern to search for",
                        },
                        "path": {
                            "type": "string",
                            "description": "Directory to search in (default: current directory)",
                        },
                    },
                    "required": ["pattern"],
                },
                risk_level="low",
            )
        )

        self.register(
            Tool(
                name="glob",
                description="Find files matching a glob pattern (e.g., *.py, **/*.js)",
                func=self._glob,
                parameters={
                    "type": "object",
                    "properties": {
                        "pattern": {
                            "type": "string",
                            "description": "Glob pattern to match",
                        },
                        "path": {
                            "type": "string",
                            "description": "Directory to search in (default: current directory)",
                        },
                    },
                    "required": ["pattern"],
                },
                risk_level="low",
            )
        )

        self.register(
            Tool(
                name="list_directory",
                description="List files in a directory",
                func=self._list_directory,
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "Directory path"}
                    },
                    "required": ["path"],
                },
                risk_level="low",
            )
        )

    def _register_git_tools(self):
        """Register git operation tools."""
        self.register(
            Tool(
                name="git_status",
                description="Show git status (modified, staged, untracked files)",
                func=self._git_status,
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path to the git repository (default: current directory)",
                        }
                    },
                },
                risk_level="low",
            )
        )

        self.register(
            Tool(
                name="git_diff",
                description="Show diff of changes (staged and unstaged)",
                func=self._git_diff,
                parameters={
                    "type": "object",
                    "properties": {
                        "staged": {
                            "type": "boolean",
                            "description": "Show staged changes only (--cached)",
                        },
                        "path": {
                            "type": "string",
                            "description": "Path to the git repository (default: current directory)",
                        },
                    },
                },
                risk_level="low",
            )
        )

        self.register(
            Tool(
                name="git_log",
                description="Show commit history",
                func=self._git_log,
                parameters={
                    "type": "object",
                    "properties": {
                        "max_count": {
                            "type": "integer",
                            "description": "Maximum number of commits to show (default: 10)",
                        },
                        "path": {
                            "type": "string",
                            "description": "Path to the git repository (default: current directory)",
                        },
                    },
                },
                risk_level="low",
            )
        )

        self.register(
            Tool(
                name="git_commit",
                description="Create a git commit with a message",
                func=self._git_commit,
                parameters={
                    "type": "object",
                    "properties": {
                        "message": {
                            "type": "string",
                            "description": "Commit message",
                        },
                        "amend": {
                            "type": "boolean",
                            "description": "Amend the previous commit (--amend)",
                        },
                        "path": {
                            "type": "string",
                            "description": "Path to the git repository (default: current directory)",
                        },
                    },
                    "required": ["message"],
                },
                risk_level="medium",
            )
        )

        self.register(
            Tool(
                name="git_push",
                description="Push commits to remote repository",
                func=self._git_push,
                parameters={
                    "type": "object",
                    "properties": {
                        "remote": {
                            "type": "string",
                            "description": "Remote name (default: origin)",
                        },
                        "branch": {
                            "type": "string",
                            "description": "Branch to push (default: current branch)",
                        },
                        "set_upstream": {
                            "type": "boolean",
                            "description": "Set upstream for branch (-u flag)",
                        },
                        "path": {
                            "type": "string",
                            "description": "Path to the git repository (default: current directory)",
                        },
                    },
                },
                risk_level="medium",
            )
        )

        self.register(
            Tool(
                name="git_checkout",
                description="Checkout a branch or file",
                func=self._git_checkout,
                parameters={
                    "type": "object",
                    "properties": {
                        "branch": {
                            "type": "string",
                            "description": "Branch name to checkout",
                        },
                        "file": {
                            "type": "string",
                            "description": "File to checkout (restore working tree)",
                        },
                        "create_branch": {
                            "type": "boolean",
                            "description": "Create and switch to new branch (-b flag)",
                        },
                        "path": {
                            "type": "string",
                            "description": "Path to the git repository (default: current directory)",
                        },
                    },
                },
                risk_level="medium",
            )
        )

    def _register_web_tools(self):
        """Register web operation tools."""
        self.register(
            Tool(
                name="web_search",
                description="Search the web for information",
                func=self._web_search,
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"}
                    },
                    "required": ["query"],
                },
                risk_level="low",
            )
        )

        self.register(
            Tool(
                name="web_fetch",
                description="Fetch content from a URL",
                func=self._web_fetch,
                parameters={
                    "type": "object",
                    "properties": {
                        "url": {"type": "string", "description": "URL to fetch"}
                    },
                    "required": ["url"],
                },
                risk_level="medium",
            )
        )

    def _register_system_tools(self):
        """Register system operation tools."""
        self.register(
            Tool(
                name="exec",
                description="Execute a shell command",
                func=self._exec,
                parameters={
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": "Shell command to execute",
                        }
                    },
                    "required": ["command"],
                },
                risk_level="high",
            )
        )

    def _register_database_tools(self):
        """Register database operation tools."""
        self.register(
            Tool(
                name="sqlite_query",
                description="Execute a SELECT SQL query on a SQLite database and return results in a formatted table",
                func=self._sqlite_query,
                parameters={
                    "type": "object",
                    "properties": {
                        "database_path": {
                            "type": "string",
                            "description": "Path to the SQLite database file",
                        },
                        "query": {
                            "type": "string",
                            "description": "SQL query to execute (SELECT only)",
                        },
                    },
                    "required": ["database_path", "query"],
                },
                risk_level="low",
            )
        )

        self.register(
            Tool(
                name="http_request",
                description="Make HTTP requests (GET, POST, PUT, DELETE, PATCH) with full control over headers, body, and params",
                func=self._http_request,
                parameters={
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "The URL to request",
                        },
                        "method": {
                            "type": "string",
                            "enum": ["GET", "POST", "PUT", "DELETE", "PATCH"],
                            "description": "HTTP method (GET, POST, PUT, DELETE, PATCH)",
                            "default": "GET",
                        },
                        "headers": {
                            "type": "object",
                            "description": "Optional HTTP headers as key-value pairs",
                        },
                        "body": {
                            "type": "string",
                            "description": "Request body for POST/PUT/PATCH (JSON string or plain text)",
                        },
                        "params": {
                            "type": "object",
                            "description": "Optional query parameters as key-value pairs",
                        },
                    },
                    "required": ["url"],
                },
                risk_level="medium",
            )
        )

    def _register_memory_tools(self):
        """Register memory operation tools."""
        self.register(
            Tool(
                name="memory_search",
                description="Search memory for relevant information",
                func=self._memory_search,
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"}
                    },
                    "required": ["query"],
                },
                risk_level="low",
            )
        )

        self.register(
            Tool(
                name="memory_store",
                description="Store information in memory",
                func=self._memory_store,
                parameters={
                    "type": "object",
                    "properties": {
                        "key": {"type": "string", "description": "Memory key"},
                        "value": {
                            "type": "string",
                            "description": "Information to store",
                        },
                    },
                    "required": ["key", "value"],
                },
                risk_level="low",
            )
        )

    def _register_skill_tools(self):
        """Register skill operation tools."""
        self.register(
            Tool(
                name="list_skills",
                description="List all available skills",
                func=self._list_skills,
                parameters={
                    "type": "object",
                    "properties": {},
                },
                risk_level="low",
            )
        )

    def _register_todo_tools(self):
        """Register todo operation tools."""
        self.register(
            Tool(
                name="TodoWrite",
                description="Create and manage a structured task list for your current coding session. Use this to track progress on complex multi-step tasks. Update tasks in real-time as you work.",
                func=self._todo_write,
                parameters={
                    "type": "object",
                    "properties": {
                        "content": {
                            "type": "string",
                            "description": "JSON array of tasks or single task object. Each task should have 'content' (required), 'status' (optional: pending/in_progress/completed/cancelled), and 'priority' (optional: high/medium/low). Example: [{'content': 'Implement auth', 'status': 'pending', 'priority': 'high'}]",
                        }
                    },
                    "required": ["content"],
                },
                risk_level="medium",
            )
        )

        self.register(
            Tool(
                name="TodoRead",
                description="Read the current task list. Shows all tasks with their status, priority, and IDs. Use this to see what tasks remain and track progress.",
                func=self._todo_read,
                parameters={
                    "type": "object",
                    "properties": {
                        "status": {
                            "type": "string",
                            "description": "Optional filter by status: pending, in_progress, completed, or cancelled",
                        },
                        "show_completed": {
                            "type": "boolean",
                            "description": "Whether to show completed tasks (default: true)",
                        },
                    },
                },
                risk_level="low",
            )
        )


tool_registry = ToolRegistry()
