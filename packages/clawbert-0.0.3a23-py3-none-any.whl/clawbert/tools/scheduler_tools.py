"""Memory, skill, and todo operation tools."""

from typing import Optional


class SchedulerTools:
    """Memory, skill, and todo operation tools."""

    def _memory_search(self, query: str) -> str:
        """Search memory for relevant entries.

        Args:
            query: Search query.

        Returns:
            Formatted memory search results.
        """
        from ..memory import MemorySystem

        mem = MemorySystem()
        results = mem.search(query)
        if not results:
            return "No relevant memories found"
        return "\n".join([f"- {r['key']}: {r['content']}" for r in results])

    def _memory_store(self, key: str, value: str) -> str:
        """Store information in memory.

        Args:
            key: Memory key.
            value: Content to store.

        Returns:
            Success message.
        """
        from ..memory import MemorySystem

        mem = MemorySystem()
        mem.store(key, value)
        return f"Stored in memory: {key}"

    def _list_skills(self) -> str:
        """List all available skills.

        Returns:
            Formatted list of skills.
        """
        from ..skills import skill_registry

        return skill_registry.list_all()

    def _todo_write(self, content: str) -> str:
        """Create or update the task list.

        Args:
            content: JSON string containing tasks array or single task.

        Returns:
            Success message with task count or error.
        """
        from ..core.todo import todo_manager

        if todo_manager.set_from_json(content):
            return f"Task list updated. {todo_manager.get_summary()}"
        return "Error: Invalid JSON format for tasks"

    def _todo_read(
        self, status: Optional[str] = None, show_completed: bool = True
    ) -> str:
        """Read the current task list.

        Args:
            status: Optional filter by status.
            show_completed: Whether to show completed tasks.

        Returns:
            Formatted task list with summary.
        """
        from ..core.todo import todo_manager

        summary = todo_manager.get_summary()
        tasks = todo_manager.get_formatted_list(
            status=status, show_completed=show_completed
        )

        return f"{summary}\n\n{tasks}"
