"""System operation tools."""

import subprocess


class SystemTools:
    """System operation tools for executing shell commands."""

    def _exec(self, command: str) -> str:
        """Execute a shell command.

        Runs the command with a 30-second timeout.

        Args:
            command: Shell command to execute.

        Returns:
            Command output or error message.
        """
        try:
            result = subprocess.run(
                command, shell=True, capture_output=True, text=True, timeout=30
            )
            output = result.stdout or result.stderr
            if result.returncode != 0:
                output = f"Command failed (exit {result.returncode}):\n{output}"
            return output or "Command executed successfully (no output)"
        except subprocess.TimeoutExpired:
            return "Error: Command timed out after 30 seconds"
        except Exception as e:
            return f"Error executing command: {e}"
