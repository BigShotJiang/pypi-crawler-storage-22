"""Web operation tools."""

import requests
from urllib.parse import quote


class WebTools:
    """Web operation tools for searching and fetching web content."""

    def _web_search(self, query: str) -> str:
        """Search the web for information.

        Args:
            query: Search query string.

        Returns:
            Formatted search results.
        """
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }

        try:
            url = f"https://duckduckgo.com/?q={quote(query)}&format=json"
            resp = requests.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                results = []
                for topic in data.get("RelatedTopics", []):
                    if "FirstURL" in topic:
                        text = topic.get("Text", "")
                        if " - " in text:
                            text = text.split(" - ")[0]
                        results.append(f"- {text}: {topic['FirstURL']}")
                    elif "Topics" in topic:
                        for sub in topic.get("Topics", []):
                            if "FirstURL" in sub:
                                text = sub.get("Text", "")
                                if " - " in text:
                                    text = text.split(" - ")[0]
                                results.append(f"- {text}: {sub['FirstURL']}")
                if results:
                    return "\n".join(results[:8])
        except Exception:
            pass

        try:
            url = f"https://lite.duckduckgo.com/lite/?q={quote(query)}"
            resp = requests.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                from bs4 import BeautifulSoup

                soup = BeautifulSoup(resp.text, "html.parser")
                results = []
                for link in soup.select("a.result-link")[:8]:
                    title = link.get_text(strip=True)
                    if title:
                        results.append(
                            f"- {title}: https://duckduckgo.com{link.get('href', '')}"
                        )
                if results:
                    return "\n".join(results)
        except Exception:
            pass

        try:
            from ddgs import DDGS

            ddgs = DDGS()
            results = list(ddgs.text(query, max_results=5))
            if results:
                return "\n".join([f"- {r['title']}: {r['href']}" for r in results])
        except Exception:
            pass

        return "Search unavailable. Please try again later."

    def _web_fetch(self, url: str) -> str:
        """Fetch content from a URL.

        Args:
            url: URL to fetch.

        Returns:
            First 5000 characters of the page.
        """
        try:
            resp = requests.get(url, timeout=10)
            resp.raise_for_status()
            text = resp.text[:5000]
            return f"Fetched from {url}:\n\n{text}"
        except Exception as e:
            return f"Fetch error: {e}"
