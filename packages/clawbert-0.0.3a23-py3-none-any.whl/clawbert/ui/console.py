"""Terminal UI for Clawbert using Rich library.

This module provides beautiful terminal output using the Rich library,
with consistent styling, colors, and formatting for a professional CLI experience.

Features:
    - Modern dark theme with vibrant accents
    - Animated spinners and progress indicators
    - Formatted tables for skills and tools
    - Markdown and syntax highlighting support
    - Color-coded status messages

Color Scheme:
    - Primary: Cyan (#00D4FF) - Main accent
    - Secondary: Purple (#A855F7) - Highlights
    - Success: Emerald (#10B981) - Success states
    - Warning: Amber (#F59E0B) - Warnings
    - Error: Rose (#F43F5E) - Errors
    - Info: Sky (#0EA5E9) - Information

Example:
    from .ui.console import console, print_success, print_error

    console.print("Hello in bold white!", style="bold white")
    print_success("Operation completed!")
    print_error("Something went wrong")
"""

from typing import Optional

from rich.console import Console
from rich.theme import Theme
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich import box
from rich.rule import Rule
from rich.columns import Columns
from rich.status import Status
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
)
from rich.live import Live

console = Console(
    theme=Theme(
        {
            "info": "cyan",
            "warning": "yellow",
            "error": "red bold",
            "success": "green bold",
            "accent": "magenta",
            "muted": "dim",
            "bright": "bold white",
            "skill": "green",
            "tool": "blue",
            "memory": "yellow",
            "primary": "cyan",
            "secondary": "purple",
        }
    ),
    force_terminal=True,
    width=120,
)


def _gradient_text(text: str, style: str = "cyan") -> Text:
    """Create gradient-like effect text."""
    t = Text()
    colors = ["cyan", "blue", "purple", "magenta"]
    for i, char in enumerate(text):
        if char.strip():
            color = colors[i % len(colors)]
            t.append(char, style=color)
        else:
            t.append(char)
    return t


def print_banner():
    """Print the Clawbert ASCII art banner with modern glow effect."""
    banner = Text(
        r"""
 ░░      ░░░  ░░░░░░░░░      ░░░  ░░░░  ░░       ░░░        ░░       ░░░        ░
▒  ▒▒▒▒  ▒▒  ▒▒▒▒▒▒▒▒  ▒▒▒▒  ▒▒  ▒  ▒  ▒▒  ▒▒▒▒  ▒▒  ▒▒▒▒▒▒▒▒  ▒▒▒▒  ▒▒▒▒▒  ▒▒▒▒
▓  ▓▓▓▓▓▓▓▓  ▓▓▓▓▓▓▓▓  ▓▓▓▓  ▓▓        ▓▓       ▓▓▓      ▓▓▓▓       ▓▓▓▓▓▓  ▓▓▓▓
█  ████  ██  ████████        ██   ██   ██  ████  ██  ████████  ███  ██████  ████
██      ███        ██  ████  ██  ████  ██       ███        ██  ████  █████  ████
""",
        style="bold cyan",
    )
    console.print(banner)
    console.print()
    console.print(Text("  Your AI CLI Companion", style="dim cyan"))
    console.print()


def print_welcome():
    """Print the welcome panel with feature highlights."""
    console.print()

    features = Table(show_header=False, box=None, padding=(0, 1))
    features.add_column(style="cyan", width=4)
    features.add_column(style="bold white")
    features.add_column(style="dim")

    features.add_row("◆", "22 Built-in Tools", "File ops, git, web, databases")
    features.add_row("◆", "10 Bundled Skills", "Development, DevOps, security")
    features.add_row("◆", "Persistent Memory", "Remember across sessions")
    features.add_row("◆", "Multi-Provider AI", "OpenRouter, OpenAI, Anthropic")
    features.add_row("◆", "REST API", "Programmatic access")
    features.add_row("◆", "Plugin System", "Extend with custom tools")

    welcome = Panel(
        features,
        title="[bold cyan]Welcome to Clawbert[/bold cyan] [dim](v0.0.3a21)[/dim]",
        border_style="cyan",
        box=box.ROUNDED,
        padding=(1, 2),
    )
    console.print(welcome)
    console.print()
    console.print(
        Text("  ◆ ", style="bold cyan")
        + Text("Type ", style="muted")
        + Text("/help", style="bold cyan")
        + Text(" for commands, ", style="muted")
        + Text("/quit", style="bold cyan")
        + Text(" to exit", style="muted")
    )
    console.print()


def print_skills_table(skills_dict):
    """Print skills as compact cards in a grid layout.

    Args:
        skills_dict: Dictionary of skill name to Skill objects.
    """
    console.print()
    console.print(Rule(title="◆ Skills", style="bold cyan", align="left"))

    cards = []
    for name, skill in skills_dict.items():
        status = "●" if skill.enabled else "○"
        status_style = "green" if skill.enabled else "dim"
        tools_short = ", ".join(skill.allowed_tools[:3]) + (
            "..." if len(skill.allowed_tools) > 3 else ""
        )

        card = Panel(
            Text(f"{status} ", style=status_style, end="")
            + Text(name, style="bold cyan")
            + "\n"
            + Text(
                skill.description[:42] + "..."
                if len(skill.description or "") > 42
                else (skill.description or "No description"),
                style="dim white",
            )
            + "\n"
            + Text(f"◆ {tools_short}", style="yellow"),
            border_style=status_style,
            box=box.SIMPLE,
            padding=(0, 1),
            width=36,
        )
        cards.append(card)

    console.print(Columns(cards, padding=(0, 1)))
    console.print()


def print_tools_table(tools_dict, enabled_tools):
    """Print tools as compact cards in a grid layout.

    Args:
        tools_dict: Dictionary of tool name to Tool objects.
        enabled_tools: List of enabled tool names.
    """
    console.print()
    console.print(Rule(title="◆ Tools", style="bold cyan", align="left"))

    cards = []
    for name, tool in tools_dict.items():
        status = "●" if name in enabled_tools else "○"
        status_style = "green" if name in enabled_tools else "dim"
        risk_color = {
            "low": "green",
            "medium": "yellow",
            "high": "red",
            "very_high": "bold red",
        }.get(tool.risk_level, "white")
        risk = f"⚠ {tool.risk_level}" if tool.risk_level != "low" else ""

        card = Panel(
            Text(f"{status} ", style=status_style, end="")
            + Text(name, style="bold cyan")
            + "\n"
            + Text(
                tool.description[:38] + "..."
                if len(tool.description) > 38
                else tool.description,
                style="dim white",
            )
            + "\n"
            + Text(risk, style=risk_color),
            border_style=status_style,
            box=box.SIMPLE,
            padding=(0, 1),
            width=36,
        )
        cards.append(card)

    console.print(Columns(cards, padding=(0, 1)))
    console.print()


def print_session_info(session):
    """Print current session information in a beautiful panel."""
    info = Panel(
        Text("Session: ", style="bold cyan")
        + Text(session.id, style="bold white")
        + "\n\n"
        + Text("Name: ", style="bold cyan")
        + Text(session.name, style="white")
        + "\n\n"
        + Text("Messages: ", style="bold cyan")
        + Text(str(len(session.messages)), style="bold yellow")
        + "\n\n"
        + Text("Active Skill: ", style="bold cyan")
        + Text(session.active_skill or "None", style="bold green")
        + "\n\n"
        + Text("Model: ", style="bold cyan")
        + Text("arcee-ai/trinity-large-preview:free", style="dim"),
        title="◆ Session Info",
        border_style="cyan",
        box=box.ROUNDED,
        padding=(1, 2),
    )
    console.print(info)


def print_memory_entry(key, content, score=None):
    """Print a memory entry in a beautiful panel."""
    title = f"◆ {key}"
    if score:
        title += f" (relevance: {score:.2f})"

    panel = Panel(
        Text(content, style="white"),
        title=title,
        border_style="cyan",
        box=box.ROUNDED,
        padding=(1, 2),
    )
    console.print(panel)


def print_thinking():
    """Return a Status object for animated thinking."""
    return Status("[bold cyan]◆ Thinking...", console=console, spinner="dots")


def print_tool_call(tool_name, args):
    """Print tool call indicator with arguments."""
    args_str = str(args) if args else "No arguments"
    console.print()
    console.print(
        Text("  ◆ ", style="bold cyan")
        + Text("Calling: ", style="cyan")
        + Text(tool_name, style="bold cyan")
    )
    if args:
        console.print(
            Text("     Args: ", style="dim") + Text(args_str, style="dim white")
        )


def print_tool_result(result, max_len=500):
    """Print tool execution result with truncation."""
    if len(result) > max_len:
        result = result[:max_len] + "\n... [truncated]"
    console.print(Text("  └─ ", style="dim green") + Text(result, style="white"))
    console.print()


def print_response_streaming(content_generator):
    """Stream and print assistant response incrementally.

    Args:
        content_generator: Iterator yielding response chunks.

    Returns:
        The complete response text.
    """
    buffer = ""

    def make_panel(text):
        try:
            md = Markdown(text)
            return Panel(
                md,
                title="◆ Clawbert",
                border_style="cyan",
                box=box.ROUNDED,
                padding=(1, 2),
            )
        except Exception:
            return Panel(
                Text(text, style="white"),
                title="◆ Clawbert",
                border_style="cyan",
                box=box.ROUNDED,
                padding=(1, 2),
            )

    try:
        with Live(
            make_panel(""), console=console, refresh_per_second=15, transient=False
        ) as live:
            for chunk in content_generator:
                buffer += chunk
                live.update(make_panel(buffer))
    except Exception:
        console.print(buffer)

    return buffer


def print_response(text):
    """Print assistant response in a beautiful panel with markdown rendering."""
    try:
        md = Markdown(text)
        panel = Panel(
            md,
            title="◆ Clawbert",
            border_style="cyan",
            box=box.ROUNDED,
            padding=(1, 2),
        )
        console.print(panel)
    except Exception:
        panel = Panel(
            Text(text, style="white"),
            title="◆ Clawbert",
            border_style="cyan",
            box=box.ROUNDED,
            padding=(1, 2),
        )
        console.print(panel)


def print_error(text):
    """Print error message with styling."""
    console.print()
    panel = Panel(
        Text(text, style="red"),
        title="◆ Error",
        border_style="red",
        box=box.ROUNDED,
        padding=(1, 2),
        width=min(len(text) + 20, console.width - 4),
    )
    console.print(panel)


def print_success(text):
    """Print success message with styling."""
    console.print()
    panel = Panel(
        Text(text, style="bold green"),
        title="◆ Success",
        border_style="green",
        box=box.ROUNDED,
        padding=(1, 2),
        width=min(len(text) + 20, console.width - 4),
    )
    console.print(panel)


def print_info(text):
    """Print informational message."""
    console.print()
    console.print(Text("  ◆ ", style="bold cyan") + Text(text, style="cyan"))


def print_help():
    """Print help table with available commands."""
    console.print()
    console.print(Rule(title="◆ Help", style="bold cyan", align="left"))

    commands = [
        ("/help", "Show this help message"),
        ("/skills", "List all available skills with details"),
        ("/skill <name>", "Switch to a specific skill"),
        ("/memory <query>", "Search your memory"),
        ("/session", "Show current session info"),
        ("/clear", "Clear conversation history"),
        ("/quit or /exit", "Exit the chat"),
    ]

    for cmd, desc in commands:
        console.print(
            Text(f"  {cmd:<20}", style="bold cyan") + Text(desc, style="white")
        )

    console.print()


def print_skill_created(skill_name, description, tools):
    """Print confirmation of skill creation with celebration."""
    console.print()
    desc = description[:22] + "..." if len(description) > 22 else description
    tools_str = ", ".join(tools[:3])

    content = (
        Text("◆ Skill Created Successfully!", style="bold green")
        + "\n\n"
        + Text("┌" + "─" * 40 + "┐", style="dim")
        + "\n"
        + Text("│ Name:        ", style="cyan")
        + Text(skill_name, style="bold white")
        + " " * max(0, 25 - len(skill_name))
        + Text("│", style="dim")
        + "\n"
        + Text("│ Description: ", style="cyan")
        + Text(desc, style="white")
        + " " * max(0, 25 - len(desc))
        + Text("│", style="dim")
        + "\n"
        + Text("│ Tools:       ", style="cyan")
        + Text(tools_str, style="bold yellow")
        + " " * max(0, 25 - len(tools_str))
        + Text("│", style="dim")
        + "\n"
        + Text("└" + "─" * 40 + "┘", style="dim")
    )

    panel = Panel(
        content,
        title="◆ New Skill",
        border_style="green",
        box=box.ROUNDED,
        padding=(1, 2),
    )
    console.print(panel)


def print_memory_results(results):
    """Print memory search results with styling."""
    if not results:
        console.print(Text("  No memories found", style="dim yellow"))
        return

    console.print()
    console.print(
        Rule(
            title=f"◆ Memory Results ({len(results)} found)",
            style="bold cyan",
            align="left",
        )
    )
    console.print()
    for r in results:
        print_memory_entry(r["key"], r["content"], r.get("score"))
    console.print()


def print_goodbye():
    """Print goodbye message with style."""
    console.print()
    console.print(Text("═" * 50, style="dim cyan"))
    console.print()
    console.print(Text("  Thanks for using Clawbert!", style="bold cyan"))
    console.print()
    console.print(Text("  See you next time!", style="dim"))
    console.print()
    console.print(Text("  ◆ Made with ◆ in the CLI", style="dim cyan"))
    console.print()
    console.print(Text("═" * 50, style="dim cyan"))


def print_created_session(session_id):
    """Print session creation confirmation."""
    console.print()
    panel = Panel(
        Text("Session created: ", style="cyan") + Text(session_id, style="bold white"),
        title="◆ New Session",
        border_style="green",
        box=box.ROUNDED,
        padding=(1, 2),
    )
    console.print(panel)


def print_syntax_highlight(code, language="python"):
    """Print code with syntax highlighting."""
    syntax = Syntax(code, language, theme="monokai", line_numbers=True)
    console.print(syntax)


def print_progress_bar(description: str = "Loading..."):
    """Create and return a progress context manager."""
    progress = Progress(
        SpinnerColumn(style="cyan"),
        TextColumn("[progress.description]{task.description}", style="cyan"),
        BarColumn(bar_width=None, style="cyan"),
        TaskProgressColumn(),
        console=console,
    )
    return progress


def print_header(text: str, style: str = "bold cyan"):
    """Print a section header with decoration."""
    console.print()
    console.print(Text("◆ " + text, style=style))
    console.print(Text("─" * (len(text) + 3), style="dim cyan"))


def print_config_value(label: str, value: str, status: Optional[str] = None):
    """Print a configuration value in a formatted way."""
    if status:
        status_icons = {"enabled": "●", "disabled": "○"}
        icon = status_icons.get(status, "◆")
        status_style = "green" if status == "enabled" else "dim"
        console.print(
            Text("  ◆ ", style="cyan")
            + Text(f"{label}: ", style="bold white")
            + Text(value, style="cyan")
            + Text(f" [{icon}]", style=status_style)
        )
    else:
        console.print(
            Text("  ◆ ", style="cyan")
            + Text(f"{label}: ", style="bold white")
            + Text(value, style="cyan")
        )
