"""Shell completion scripts for Clawbert CLI."""

from ..tools import tool_registry


def get_tool_names() -> list[str]:
    """Get list of available tool names."""
    return [t["function"]["name"] for t in tool_registry.get_available_tools()]


BASH_COMPLETION = """#!/bin/bash

_clawbert_completions() {
    local cur prev opts
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"

    opts="chat config session memory skill api completions help"
    config_opts="--provider --api-key --model --base-url --list-providers --list-tools --list-skills --enable-tool --disable-tool"
    session_opts="--list --create --switch --delete"
    memory_opts="--search --list --get --store --delete --clear"
    skill_opts="--list --enable --disable --set"
    api_opts="--host --port --api-key --cors"
    providers="openrouter openai anthropic ollama"

    case ${COMP_CWORD} in
        1)
            COMPREPLY=( $(compgen -W "${opts}" -- ${cur}) )
            return 0
            ;;
        2)
            case ${prev} in
                chat)
                    return 0
                    ;;
                config)
                    COMPREPLY=( $(compgen -W "${config_opts}" -- ${cur}) )
                    return 0
                    ;;
                session)
                    COMPREPLY=( $(compgen -W "${session_opts}" -- ${cur}) )
                    return 0
                    ;;
                memory)
                    COMPREPLY=( $(compgen -W "${memory_opts}" -- ${cur}) )
                    return 0
                    ;;
                skill)
                    COMPREPLY=( $(compgen -W "${skill_opts}" -- ${cur}) )
                    return 0
                    ;;
                api)
                    COMPREPLY=( $(compgen -W "${api_opts}" -- ${cur}) )
                    return 0
                    ;;
                completions)
                    COMPREPLY=( $(compgen -W "bash fish zsh" -- ${cur}) )
                    return 0
                    ;;
            esac
            ;;
        3)
            case ${prev} in
                --provider)
                    COMPREPLY=( $(compgen -W "${providers}" -- ${cur}) )
                    return 0
                    ;;
                --enable-tool|--disable-tool)
                    COMPREPLY=( $(compgen -W "$(clawbert config --list-tools --quiet 2>/dev/null | head -40)" -- ${cur}) )
                    return 0
                    ;;
                --set|--enable|--disable)
                    COMPREPLY=( $(compgen -W "$(clawbert skill --list --quiet 2>/dev/null | head -50)" -- ${cur}) )
                    return 0
                    ;;
            esac
            ;;
    esac
}

complete -F _clawbert_completions clawbert
"""

FISH_COMPLETION = """# Fish shell completion for clawbert

complete -c clawbert -f

# Main subcommands
complete -c clawbert -n '__fish_use_subcommand' -a 'chat' -d 'Chat with Clawbert'
complete -c clawbert -n '__fish_use_subcommand' -a 'config' -d 'Configure Clawbert'
complete -c clawbert -n '__fish_use_subcommand' -a 'session' -d 'Manage sessions'
complete -c clawbert -n '__fish_use_subcommand' -a 'memory' -d 'Manage memory'
complete -c clawbert -n '__fish_use_subcommand' -a 'skill' -d 'Manage skills'
complete -c clawbert -n '__fish_use_subcommand' -a 'api' -d 'Start REST API server'
complete -c clawbert -n '__fish_use_subcommand' -a 'completions' -d 'Generate shell completions'

# config subcommand options
complete -c clawbert -n '__fish_seen_subcommand_from config' -l provider -s p -a 'openrouter openai anthropic ollama' -d 'Set LLM provider'
complete -c clawbert -n '__fish_seen_subcommand_from config' -sl api-key - k -d 'Set API key for current provider'
complete -c clawbert -n '__fish_seen_subcommand_from config' -l model -s m -d 'Set default model'
complete -c clawbert -n '__fish_seen_subcommand_from config' -l base-url -d 'Set base URL for provider'
complete -c clawbert -n '__fish_seen_subcommand_from config' -l list-providers -d 'List available providers'
complete -c clawbert -n '__fish_seen_subcommand_from config' -l list-tools -d 'List available tools'
complete -c clawbert -n '__fish_seen_subcommand_from config' -l list-skills -d 'List available skills'
complete -c clawbert -n '__fish_seen_subcommand_from config' -l enable-tool -d 'Enable a tool'
complete -c clawbert -n '__fish_seen_subcommand_from config' -l disable-tool -d 'Disable a tool'

# session subcommand options
complete -c clawbert -n '__fish_seen_subcommand_from session' -l list -d 'List sessions'
complete -c clawbert -n '__fish_seen_subcommand_from session' -l create -d 'Create new session'
complete -c clawbert -n '__fish_seen_subcommand_from session' -l switch -d 'Switch to session'
complete -c clawbert -n '__fish_seen_subcommand_from session' -l delete -d 'Delete session'

# memory subcommand options
complete -c clawbert -n '__fish_seen_subcommand_from memory' -l search -d 'Search memory'
complete -c clawbert -n '__fish_seen_subcommand_from memory' -l list -d 'List all memories'
complete -c clawbert -n '__fish_seen_subcommand_from memory' -l get -d 'Get memory by key'
complete -c clawbert -n '__fish_seen_subcommand_from memory' -l store -d 'Store memory (key=value)'
complete -c clawbert -n '__fish_seen_subcommand_from memory' -l delete -d 'Delete memory'
complete -c clawbert -n '__fish_seen_subcommand_from memory' -l clear -d 'Clear all memories'

# skill subcommand options
complete -c clawbert -n '__fish_seen_subcommand_from skill' -l list -d 'List skills'
complete -c clawbert -n '__fish_seen_subcommand_from skill' -l enable -d 'Enable skill'
complete -c clawbert -n '__fish_seen_subcommand_from skill' -l disable -d 'Disable skill'
complete -c clawbert -n '__fish_seen_subcommand_from skill' -l set -d 'Set active skill'

# api subcommand options
complete -c clawbert -n '__fish_seen_subcommand_from api' -l host -d 'Host to bind to'
complete -c clawbert -n '__fish_seen_subcommand_from api' -l port -d 'Port to bind to'
complete -c clawbert -n '__fish_seen_subcommand_from api' -l api-key -d 'Optional API key for authentication'
complete -c clawbert -n '__fish_seen_subcommand_from api' -l cors -d 'CORS origins (comma-separated)'

# completions subcommand
complete -c clawbert -n '__fish_seen_subcommand_from completions' -a 'bash' -d 'Bash completions'
complete -c clawbert -n '__fish_seen_subcommand_from completions' -a 'fish' -d 'Fish shell completions'
complete -c clawbert -n '__fish_seen_subcommand_from completions' -a 'zsh' -d 'Zsh completions'
"""

ZSH_COMPLETION = """#compdef clawbert

local -a main_subcommands
main_subcommands=(
    'chat:Chat with Clawbert'
    'config:Configure Clawbert'
    'session:Manage sessions'
    'memory:Manage memory'
    'skill:Manage skills'
    'api:Start REST API server'
    'completions:Generate shell completions'
)

local -a config_opts
config_opts=(
    '--provider:LLM provider(openrouter openai anthropic ollama)'
    '--api-key:API key for current provider'
    '--model:Default model'
    '--base-url:Base URL for provider'
    '--list-providers:List available providers'
    '--list-tools:List available tools'
    '--list-skills:List available skills'
    '--enable-tool:Enable a tool'
    '--disable-tool:Disable a tool'
)

local -a session_opts
session_opts=(
    '--list:List sessions'
    '--create:Create new session'
    '--switch:Switch to session'
    '--delete:Delete session'
)

local -a memory_opts
memory_opts=(
    '--search:Search memory'
    '--list:List all memories'
    '--get:Get memory by key'
    '--store:Store memory (key=value)'
    '--delete:Delete memory'
    '--clear:Clear all memories'
)

local -a skill_opts
skill_opts=(
    '--list:List skills'
    '--enable:Enable skill'
    '--disable:Disable skill'
    '--set:Set active skill'
)

local -a api_opts
api_opts=(
    '--host:Host to bind to'
    '--port:Port to bind to'
    '--api-key:Optional API key for authentication'
    '--cors:CORS origins (comma-separated)'
)

local -a shell_opts
shell_opts=(
    'bash:Bash completions'
    'fish:Fish shell completions'
    'zsh:Zsh completions'
)

_clawbert() {
    local -a cmd
    if (( CURRENT > 2 )); then
        cmd=( "${words[2]}" )
        (( CURRENT-- ))
        shift words
        (( CURRENT-- ))
    fi

    case "$cmd[1]" in
        chat)
            _message 'prompt to send'
            ;;
        config)
            _describe 'option' config_opts
            ;;
        session)
            _describe 'option' session_opts
            ;;
        memory)
            _describe 'option' memory_opts
            ;;
        skill)
            _describe 'option' skill_opts
            ;;
        api)
            _describe 'option' api_opts
            ;;
        completions)
            _describe 'shell' shell_opts
            ;;
        *)
            _describe 'subcommand' main_subcommands
            ;;
    esac
}

_clawbert "$@"
"""


def get_completion_script(shell: str) -> str:
    """Get the completion script for the specified shell.

    Args:
        shell: One of 'bash', 'fish', or 'zsh'

    Returns:
        The completion script string.
    """
    scripts = {
        "bash": BASH_COMPLETION,
        "fish": FISH_COMPLETION,
        "zsh": ZSH_COMPLETION,
    }

    if shell not in scripts:
        raise ValueError(f"Unsupported shell: {shell}. Choose from: bash, fish, zsh")

    return scripts[shell]


def print_install_instructions(shell: str) -> None:
    """Print installation instructions for the given shell."""
    instructions = {
        "bash": """# Bash installation:
# Add to your ~/.bashrc or ~/.bash_profile:
source <(clawbert completions --shell bash)

# Or install system-wide:
sudo cp /path/to/clawbert.bash /etc/bash_completion.d/""",
        "fish": """# Fish shell installation:
# Add to your ~/.config/fish/config.fish:
clawbert completions --shell fish > ~/.config/fish/completions/clawbert.fish""",
        "zsh": """# Zsh installation:
# Add to your ~/.zshrc:
source <(clawbert completions --shell zsh)

# Or copy to completions directory:
clawbert completions --shell zsh > ~/.zfunc/_clawbert""",
    }
    print(instructions.get(shell, ""))
