"""Interactive setup wizard for Clawbert.

This module provides an interactive wizard to guide users through
initial setup and configuration of Clawbert. Supports both interactive
and non-interactive (automated) modes.

Features:
- Interactive prompts using Rich
- API key setup for multiple providers
- Model selection
- Tool enable/disable
- Skill selection
- Memory preferences
- API server setup (optional)
- Non-interactive mode for automation

Example:
    # Interactive mode
    clawbert wizard

    # Automated mode
    clawbert wizard --non-interactive --provider openrouter --api-key KEY
"""

from typing import Optional

from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box

from ..core.config import config, DEFAULT_MODELS
from ..tools import tool_registry
from ..skills import skill_registry


console = Console()


class Wizard:
    """Interactive setup wizard for Clawbert.

    Provides a guided setup experience with steps for:
    - Welcome and introduction
    - API provider selection
    - API key configuration
    - Model selection
    - Tool enable/disable
    - Skill selection
    - Memory preferences
    - API server setup
    """

    def __init__(self, non_interactive: bool = False):
        """Initialize the wizard.

        Args:
            non_interactive: If True, skip prompts and use defaults/flags.
        """
        self.non_interactive = non_interactive
        self.step = 0
        self.total_steps = 7

    def _print_step(self, step_num: int, title: str):
        """Print step header.

        Args:
            step_num: Current step number.
            title: Step title.
        """
        if not self.non_interactive:
            console.print()
            console.print(
                f"[bold cyan]Step {step_num}/{self.total_steps}:[/bold cyan] {title}"
            )
            console.print("─" * 50)

    def _banner(self):
        """Print welcome banner."""
        banner = Text()
        banner.append(
            "═══════════════════════════════════════════════════\n", style="bold cyan"
        )
        banner.append("           ◆ Clawbert Setup Wizard ◆\n", style="bold cyan")
        banner.append(
            "═══════════════════════════════════════════════════", style="bold cyan"
        )
        console.print(Panel(banner, border_style="cyan", box=box.ROUNDED))

    def step_welcome(self):
        """Step 1: Welcome message and introduction."""
        self._print_step(1, "Welcome")

        console.print("[bold]Welcome to Clawbert![/bold]")
        console.print(
            "This wizard will guide you through setting up your AI assistant."
        )
        console.print()
        console.print("[dim]What we'll configure:[/dim]")
        console.print("  • LLM Provider (OpenRouter, OpenAI, Anthropic, Ollama)")
        console.print("  • API Key")
        console.print("  • Model selection")
        console.print("  • Tools to enable")
        console.print("  • Skills to enable")
        console.print("  • Memory settings")
        console.print("  • API server (optional)")
        console.print()

        if not self.non_interactive:
            Confirm.ask("[cyan]Continue with setup?[/cyan]", default=True)

    def step_provider(self) -> str:
        """Step 2: Select API provider.

        Returns:
            Selected provider name.
        """
        self._print_step(2, "LLM Provider")

        console.print("[bold]Select your LLM provider:[/bold]")
        console.print()

        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Option", style="cyan", width=12)
        table.add_column("Provider", style="white")
        table.add_column("Description", style="dim")

        table.add_row("1", "openrouter", "Access 100+ models (recommended)")
        table.add_row("2", "openai", "OpenAI GPT models")
        table.add_row("3", "anthropic", "Anthropic Claude models")
        table.add_row("4", "ollama", "Local models (Ollama)")

        console.print(table)
        console.print()

        if self.non_interactive and config.model_provider:
            provider = config.model_provider
            console.print(f"[green]Using configured provider:[/green] {provider}")
            return provider

        choice = Prompt.ask(
            "[cyan]Choose provider (1-4)[/cyan]",
            default="1",
            choices=["1", "2", "3", "4"],
        )

        providers = ["openrouter", "openai", "anthropic", "ollama"]
        provider = providers[int(choice) - 1]

        console.print(f"[green]Selected:[/green] {provider}")
        return provider

    def step_api_key(self, provider: str) -> str:
        """Step 3: Configure API key.

        Args:
            provider: Selected provider name.

        Returns:
            Entered API key.
        """
        self._print_step(3, "API Key")

        if provider == "openrouter":
            console.print("[bold]OpenRouter[/bold] - Get a free API key at:")
            console.print("  [link]https://openrouter.ai/settings[/link]")
        elif provider == "openai":
            console.print("[bold]OpenAI[/bold] - Get an API key at:")
            console.print("  [link]https://platform.openai.com/api-keys[/link]")
        elif provider == "anthropic":
            console.print("[bold]Anthropic[/bold] - Get an API key at:")
            console.print("  [link]https://www.anthropic.com/api[/link]")
        elif provider == "ollama":
            console.print("[bold]Ollama[/bold] - Make sure Ollama is running locally.")
            console.print(f"  Default URL: {config.ollama_base_url}")
            console.print("  Install from: [link]https://ollama.com[/link]")

        console.print()

        if self.non_interactive and config.get_provider_api_key():
            key = config.get_provider_api_key()
            console.print("[green]API key already configured[/green]")
            return key

        if provider == "ollama":
            base_url = Prompt.ask(
                "[cyan]Ollama base URL[/cyan]",
                default=config.ollama_base_url,
            )
            config.ollama_base_url = base_url
            return ""

        if self.non_interactive:
            console.print("[red]API key required in non-interactive mode[/red]")
            return ""

        api_key = Prompt.ask(
            f"[cyan]Enter {provider} API key[/cyan]",
            password=True,
        )

        if api_key:
            console.print("[green]API key saved[/green]")
        return api_key

    def step_model(self, provider: str) -> str:
        """Step 4: Select model.

        Args:
            provider: Selected provider name.

        Returns:
            Selected model name.
        """
        self._print_step(4, "Model Selection")

        models_info = {
            "openrouter": [
                ("stepfun/step-3.5-flash:free", "Free - Fast & capable (recommended)"),
                ("openai/gpt-4o-mini", "OpenAI GPT-4o Mini"),
                ("openai/gpt-4o", "OpenAI GPT-4o"),
                ("anthropic/claude-3.5-haiku", "Anthropic Claude 3.5 Haiku"),
                ("google/gemini-2.0-flash-exp", "Google Gemini 2.0 Flash"),
                ("meta-llama/llama-3.3-70b-instruct", "Meta Llama 3.3 70B"),
            ],
            "openai": [
                ("gpt-4o-mini", "GPT-4o Mini - Fast & cheap (recommended)"),
                ("gpt-4o", "GPT-4o - Most capable"),
                ("gpt-4o-2024-08-06", "GPT-4o with structured outputs"),
                ("gpt-4-turbo", "GPT-4 Turbo"),
                ("gpt-3.5-turbo", "GPT-3.5 Turbo"),
            ],
            "anthropic": [
                ("claude-3-5-haiku-20240307", "Claude 3.5 Haiku - Fast (recommended)"),
                ("claude-3-5-sonnet-20241022", "Claude 3.5 Sonnet"),
                ("claude-3-opus-20240229", "Claude 3 Opus"),
            ],
            "ollama": [
                ("llama3.2", "Llama 3.2 (recommended)"),
                ("llama3.1", "Llama 3.1"),
                ("mistral", "Mistral"),
                ("codellama", "Code Llama"),
                ("phi3", "Phi-3"),
            ],
        }

        models = models_info.get(provider, [])

        console.print("[bold]Available models:[/bold]")
        console.print()

        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("#", style="cyan", width=4)
        table.add_column("Model", style="white")
        table.add_column("Description", style="dim")

        for i, (model, desc) in enumerate(models, 1):
            table.add_row(str(i), model, desc)

        console.print(table)
        console.print()

        if self.non_interactive and config.default_model:
            model = config.default_model
            console.print(f"[green]Using configured model:[/green] {model}")
            return model

        choice = Prompt.ask(
            "[cyan]Choose model (number)[/cyan]",
            default="1",
            choices=[str(i) for i in range(1, len(models) + 1)],
        )

        model = models[int(choice) - 1][0]
        console.print(f"[green]Selected:[/green] {model}")
        return model

    def step_tools(self) -> list:
        """Step 5: Tool selection.

        Returns:
            List of enabled tool names.
        """
        self._print_step(5, "Tool Selection")

        console.print("[bold]Select tools to enable:[/bold]")
        console.print()

        tool_groups = {
            "File Operations": [
                ("read", "Read file contents"),
                ("write", "Write content to files"),
                ("edit", "Edit files (find/replace)"),
                ("grep", "Search patterns in files"),
                ("glob", "Find files by pattern"),
                ("list_directory", "List directory contents"),
            ],
            "Shell Commands": [
                ("exec", "Execute shell commands"),
            ],
            "Web Access": [
                ("web_search", "Search the web"),
                ("web_fetch", "Fetch URL content"),
            ],
            "Memory": [
                ("memory_search", "Search stored memories"),
                ("memory_store", "Store in memory"),
                ("read_memory_file", "Read memory files"),
                ("write_memory_file", "Write memory files"),
                ("list_memory_files", "List memory files"),
                ("vector_search", "Semantic search"),
            ],
            "Skills": [
                ("list_skills", "List available skills"),
                ("create_skill", "Create new skills"),
                ("reload_skills", "Reload skills"),
            ],
            "Sessions": [
                ("sessions_list", "List sessions"),
                ("sessions_history", "Get session history"),
                ("sessions_send", "Send to another session"),
            ],
            "Git": [
                ("git_status", "Show git status"),
                ("git_diff", "Show git diff"),
                ("git_log", "Show commit history"),
                ("git_branch", "Manage branches"),
                ("git_commit", "Create commits"),
                ("git_push", "Push to remote"),
                ("git_pull", "Pull from remote"),
                ("git_checkout", "Checkout branches/files"),
            ],
            "MCP": [
                ("mcp_connect", "Connect to MCP server"),
                ("mcp_disconnect", "Disconnect from MCP"),
                ("mcp_list", "List MCP tools"),
                ("mcp_call", "Call MCP tool"),
            ],
        }

        enabled_tools = []
        all_tools = tool_registry.tools

        if self.non_interactive:
            enabled_tools = config.enabled_tools.copy()
            console.print(
                f"[green]Using configured tools:[/green] {len(enabled_tools)} enabled"
            )
            return enabled_tools

        for group_name, tools in tool_groups.items():
            console.print(f"[bold]{group_name}:[/bold]")
            for tool_name, description in tools:
                if tool_name in all_tools:
                    default = "y" if tool_name in config.enabled_tools else "n"
                    enabled = Confirm.ask(
                        f"  [cyan]{tool_name}[/cyan] - {description}",
                        default=(default == "y"),
                    )
                    if enabled:
                        enabled_tools.append(tool_name)
            console.print()

        console.print(f"[green]Enabled {len(enabled_tools)} tools[/green]")
        return enabled_tools

    def step_skills(self) -> list:
        """Step 6: Skill selection.

        Returns:
            List of enabled skill names.
        """
        self._print_step(6, "Skill Selection")

        console.print("[bold]Select skills to enable:[/bold]")
        console.print()

        skill_registry.reload()
        skills = skill_registry.skills

        if not skills:
            console.print(
                "[dim]No custom skills found. You can add skills later.[/dim]"
            )
            console.print(f"Skills directory: {config.skills_dir}")
            console.print()
            if self.non_interactive:
                return []
            Confirm.ask("[cyan]Continue?[/cyan]", default=True)
            return []

        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Skill", style="cyan")
        table.add_column("Description", style="white")
        table.add_column("Tools", style="dim")

        for name, skill in skills.items():
            tools = ", ".join(skill.allowed_tools) if skill.allowed_tools else "all"
            table.add_row(name, skill.description, tools)

        console.print(table)
        console.print()

        if self.non_interactive:
            enabled_skills = config.enabled_skills.copy()
            console.print(
                f"[green]Using configured skills:[/green] {len(enabled_skills)} enabled"
            )
            return enabled_skills

        console.print("[cyan]Enter skill names to enable (comma-separated)[/cyan]")
        console.print("[dim]Leave empty to enable all, 'none' for none[/dim]")

        choice = Prompt.ask(
            "[cyan]Skills[/cyan]",
            default=",".join(config.enabled_skills) if config.enabled_skills else "",
        )

        if choice.lower() == "none":
            enabled_skills = []
        elif choice.strip():
            enabled_skills = [s.strip() for s in choice.split(",") if s.strip()]
        else:
            enabled_skills = list(skills.keys())

        console.print(f"[green]Enabled {len(enabled_skills)} skills[/green]")
        return enabled_skills

    def step_memory(self) -> dict:
        """Step 7: Memory preferences.

        Returns:
            Dictionary of memory settings.
        """
        self._print_step(7, "Memory Settings")

        console.print("[bold]Configure memory:[/bold]")
        console.print()

        if self.non_interactive:
            settings = {
                "vector_memory_enabled": config.vector_memory_enabled,
            }
            console.print("[green]Using configured settings[/green]")
            return settings

        vector_enabled = Confirm.ask(
            "[cyan]Enable semantic memory search?[/cyan]",
            default=config.vector_memory_enabled,
        )

        console.print()
        console.print(f"[dim]Memory directory: {config.memory_dir}[/dim]")
        console.print(f"[dim]Sessions directory: {config.sessions_dir}[/dim]")

        return {
            "vector_memory_enabled": vector_enabled,
        }

    def step_api_server(self) -> dict:
        """Step 8: API server setup (optional).

        Returns:
            Dictionary of API server settings.
        """
        self._print_step(8, "API Server (Optional)")

        console.print("[bold]Configure REST API server:[/bold]")
        console.print()

        if self.non_interactive:
            settings = {
                "mcp_enabled": config.mcp_enabled,
            }
            console.print("[green]Using configured settings[/green]")
            return settings

        enable_api = Confirm.ask(
            "[cyan]Enable REST API server?[/cyan]",
            default=config.mcp_enabled,
        )

        if not enable_api:
            return {"mcp_enabled": False}

        host = Prompt.ask(
            "[cyan]API host[/cyan]",
            default=config.mcp_host,
        )

        port = Prompt.ask(
            "[cyan]API port[/cyan]",
            default=str(config.mcp_port),
        )

        require_auth = Confirm.ask(
            "[cyan]Require API key for authentication?[/cyan]",
            default=False,
        )

        return {
            "mcp_enabled": True,
            "mcp_host": host,
            "mcp_port": int(port),
            "api_require_auth": require_auth,
        }

    def run(
        self,
        provider: Optional[str] = None,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
    ):
        """Run the wizard.

        Args:
            provider: Provider (for non-interactive mode).
            api_key: API key (for non-interactive mode).
            model: Model (for non-interactive mode).
        """
        self._banner()

        if not self.non_interactive:
            self.step_welcome()

        if provider:
            config.model_provider = provider

        if model:
            config.default_model = model

        provider = provider or self.step_provider()
        config.model_provider = provider
        config.default_model = DEFAULT_MODELS.get(provider, "")

        api_key = api_key or self.step_api_key(provider)
        if provider == "openrouter":
            config.openrouter_api_key = api_key
        elif provider == "openai":
            config.openai_api_key = api_key
        elif provider == "anthropic":
            config.anthropic_api_key = api_key

        model = model or self.step_model(provider)
        config.default_model = model

        enabled_tools = self.step_tools()
        config.enabled_tools = enabled_tools

        enabled_skills = self.step_skills()
        config.enabled_skills = enabled_skills

        memory_settings = self.step_memory()
        config.vector_memory_enabled = memory_settings.get(
            "vector_memory_enabled", True
        )

        config.save()

        console.print()
        console.print(
            Panel(
                "[bold green]Setup complete![/bold green]\n\n"
                "Run [cyan]clawbert chat[/cyan] to start chatting!\n"
                "Run [cyan]clawbert doctor[/cyan] to validate your setup.",
                title="✓ Success",
                border_style="green",
            )
        )


def cmd_wizard(args):
    """Handle wizard subcommand.

    Args:
        args: Parsed command-line arguments.
    """
    wizard = Wizard(non_interactive=args.non_interactive)
    wizard.run(
        provider=args.provider,
        api_key=args.api_key,
        model=args.model,
    )


def cmd_doctor(args):
    """Handle doctor subcommand - validate setup.

    Args:
        args: Parsed command-line arguments.
    """
    from ..core.llm import LLMClient

    console.print()
    console.print(
        Panel(
            "[bold cyan]Clawbert Doctor[/bold cyan]\n\nChecking your setup...",
            title="🩺",
            border_style="cyan",
        )
    )
    console.print()

    issues = []
    fixes = []

    console.print("[bold]Checking configuration...[/bold]")

    if not config.model_provider:
        issues.append("No provider configured")
        fixes.append("Run: clawbert wizard")

    if config.model_provider != "ollama":
        api_key = config.get_provider_api_key()
        if not api_key:
            issues.append("No API key configured")
            fixes.append("Run: clawbert config --api-key YOUR_KEY")
        else:
            console.print(
                f"  [green]✓[/green] API key configured ({config.model_provider})"
            )

    console.print(f"  [green]✓[/green] Provider: {config.model_provider}")
    console.print(f"  [green]✓[/green] Model: {config.default_model}")
    console.print(f"  [green]✓[/green] Tools: {len(config.enabled_tools)} enabled")
    console.print(f"  [green]✓[/green] Skills: {len(config.enabled_skills)} enabled")
    console.print()

    console.print("[bold]Checking dependencies...[/bold]")

    try:
        import requests

        console.print("  [green]✓[/green] requests")
    except ImportError:
        issues.append("Missing dependency: requests")
        fixes.append("Run: pip install requests")

    try:
        from importlib.util import find_spec as find_rich_spec

        rich_spec = find_rich_spec("rich")
        if rich_spec:
            console.print("  [green]✓[/green] rich")
        else:
            raise ImportError("rich")
    except ImportError:
        issues.append("Missing dependency: rich")
        fixes.append("Run: pip install rich")

    try:
        from importlib.util import find_spec as find_yaml_spec

        yaml_spec = find_yaml_spec("yaml")
        if yaml_spec:
            console.print("  [green]✓[/green] pyyaml")
        else:
            raise ImportError("yaml")
    except ImportError:
        issues.append("Missing dependency: pyyaml")
        fixes.append("Run: pip install pyyaml")
    console.print()

    console.print("[bold]Checking directories...[/bold]")

    for dir_path, name in [
        (config.memory_dir, "Memory"),
        (config.sessions_dir, "Sessions"),
        (config.skills_dir, "Skills"),
        (config.config_path.parent, "Config"),
    ]:
        if dir_path.exists():
            console.print(f"  [green]✓[/green] {name}: {dir_path}")
        else:
            issues.append(f"Missing directory: {name}")
            fixes.append("Directories will be created on first run")
            console.print(f"  [yellow]![/yellow] {name}: {dir_path} (will create)")
    console.print()

    console.print("[bold]Checking API connection...[/bold]")

    if config.model_provider == "ollama":
        try:
            import requests

            r = requests.get(f"{config.ollama_base_url}/api/tags", timeout=5)
            if r.ok:
                console.print("  [green]✓[/green] Ollama connected")
                models = r.json().get("models", [])
                console.print(f"    Available models: {len(models)}")
            else:
                issues.append("Ollama not responding")
                fixes.append("Ensure Ollama is running: ollama serve")
        except Exception as e:
            issues.append(f"Ollama connection failed: {e}")
            fixes.append("Ensure Ollama is installed and running")
    else:
        api_key = config.get_provider_api_key()
        if api_key:
            try:
                llm = LLMClient()
                console.print("  [yellow]...[/yellow] Testing API key...")
                test_result = llm.chat(
                    [{"role": "user", "content": "Say 'OK' if you can hear me."}]
                )
                if (
                    "error" not in test_result.lower()
                    if isinstance(test_result, str)
                    else True
                ):
                    console.print("  [green]✓[/green] API key works!")
                else:
                    issues.append(f"API error: {test_result}")
                    fixes.append("Check your API key and try again")
            except Exception as e:
                issues.append(f"API connection failed: {e}")
                fixes.append("Check your internet connection and API key")
    console.print()

    console.print("[bold]Checking memory files...[/bold]")
    memory_files = ["AGENTS.md", "SOUL.md", "USER.md", "MEMORY.md"]
    for mf in memory_files:
        fp = config.memory_dir / mf
        if fp.exists():
            console.print(f"  [green]✓[/green] {mf}")
        else:
            console.print(f"  [yellow]![/yellow] {mf} (optional)")
    console.print()

    if issues:
        console.print(
            Panel(
                "[bold red]Issues found:[/bold red]\n\n"
                + "\n".join(f"  • {issue}" for issue in issues),
                title="⚠ Problems",
                border_style="yellow",
            )
        )
        console.print()
        console.print("[bold]Suggested fixes:[/bold]")
        for fix in fixes:
            console.print(f"  • {fix}")
    else:
        console.print(
            Panel(
                "[bold green]All checks passed![/bold green]\n\n"
                "Your setup is ready. Run [cyan]clawbert chat[/cyan] to start!",
                title="✓ Success",
                border_style="green",
            )
        )

    console.print()


def add_wizard_parser(subparsers):
    """Add wizard subcommand to parser.

    Args:
        subparsers: ArgumentParser subparsers object.
    """
    p_wizard = subparsers.add_parser("wizard", help="Run interactive setup wizard")
    p_wizard.add_argument(
        "--non-interactive",
        action="store_true",
        help="Run in non-interactive/automated mode",
    )
    p_wizard.add_argument(
        "--provider",
        help="LLM provider (openrouter, openai, anthropic, ollama)",
    )
    p_wizard.add_argument(
        "--api-key",
        help="API key for the provider",
    )
    p_wizard.add_argument(
        "--model",
        help="Model to use",
    )
    p_wizard.set_defaults(func=cmd_wizard)

    p_doctor = subparsers.add_parser(
        "doctor", help="Validate setup and diagnose issues"
    )
    p_doctor.set_defaults(func=cmd_doctor)
