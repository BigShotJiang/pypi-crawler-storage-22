# ClawCut 🦞✂️

> AI-powered short video generator using Google's latest models

Turn a topic into a polished short video — automatically. ClawCut generates a 9-scene script, creates character-consistent imagery, produces video clips with Veo 3.1, trims silence, and concatenates everything into a final video.

## ✨ Features

- **Script Generation** — Gemini 3 Pro writes a 9-scene narrative from your topic
- **Nine-Grid Character Consistency** — generates a 3×3 reference grid to keep characters consistent across scenes
- **Veo 3.1 Video Generation** — each scene becomes a cinematic video clip with Chinese narration
- **Silence Trimming** — automatically removes leading/trailing silence from clips
- **Video Imitation** — upload a reference video to match its style and pacing
- **Multi-Image Reference** — upload up to 14 images for character appearance guidance

## 🛠 Tech Stack

| Component | Technology |
|-----------|-----------|
| Script & Image | [Gemini 3 Pro](https://cloud.google.com/vertex-ai) |
| Video | [Veo 3.1](https://cloud.google.com/vertex-ai) |
| Frontend | [Gradio](https://gradio.app/) |
| Audio/Video | FFmpeg |
| Runtime | Python 3.11+ |

## 🚀 Quick Start

```bash
# Clone
git clone https://github.com/YOUR_USERNAME/clawcut.git
cd clawcut

# Virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Configure
cp .env.example .env
# Edit .env with your values (see below)

# Run
python app.py
# Opens at http://localhost:7860
```

## ⚙️ Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `GOOGLE_APPLICATION_CREDENTIALS` | Path to your GCP service account JSON | ✅ |
| `VERTEX_PROJECT` | Your GCP project ID | ✅ |
| `VERTEX_LOCATION` | GCP region (default: `us-central1`) | ❌ |
| `FFMPEG_PATH` | Path to ffmpeg binary | ❌ |

## 🤖 Models Used

| Model | Purpose |
|-------|---------|
| `gemini-3-pro-preview` | Script generation |
| `gemini-3-pro-image-preview` | Character consistency grid image |
| `veo-3.1-generate-001` | Video clip generation |
| `veo-3.1-fast-generate-001` | Fast video generation (optional) |

## 📁 Project Structure

```
clawcut/
├── app.py          # Gradio UI
├── pipeline.py     # Core pipeline (script → grid → video → trim → concat)
├── config.py       # Configuration from environment variables
├── .env.example    # Environment variable template
└── requirements.txt
```

## 📄 License

[MIT](LICENSE) © 2026 ClawCut Contributors
