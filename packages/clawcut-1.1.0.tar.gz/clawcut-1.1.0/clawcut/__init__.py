"""ClawCut — AI short video generator using Gemini 3 Pro + Veo 3.1 on Vertex AI."""

__version__ = "1.1.0"
