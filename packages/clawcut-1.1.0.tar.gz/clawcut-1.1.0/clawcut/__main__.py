"""Allow running with `python -m clawcut`."""
from clawcut.app import main

if __name__ == "__main__":
    main()
