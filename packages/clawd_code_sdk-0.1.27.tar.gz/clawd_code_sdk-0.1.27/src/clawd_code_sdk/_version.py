"""Version information for clawd-code-sdk."""

from importlib.metadata import version

__version__ = version("clawd-code-sdk")
