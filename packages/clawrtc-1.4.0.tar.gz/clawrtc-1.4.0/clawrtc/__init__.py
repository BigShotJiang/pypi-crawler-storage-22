"""ClawRTC — Mine RTC tokens with your AI agent on any modern hardware."""

__version__ = "1.4.0"
