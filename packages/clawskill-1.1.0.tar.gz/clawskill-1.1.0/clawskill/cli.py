#!/usr/bin/env python3
"""ClawSkill — RustChain miner for AI agents on modern hardware.

Your Claw agent earns RTC tokens by proving it runs on real hardware.
Modern machines get 1x multiplier. Vintage hardware gets bonus multipliers.
VMs are detected and penalized — real iron only.

Usage:
    pip install clawskill
    clawskill install --wallet my-agent-miner
    clawskill start

Security:
    clawskill install --dry-run      Preview without downloading or installing
    clawskill install --show-urls    Show exact URLs that will be fetched
    clawskill install --verify       Show SHA256 hashes of downloaded files
    clawskill install --no-service   Install files only, no background service
"""

import argparse
import hashlib
import os
import platform
import shutil
import subprocess
import sys
import textwrap
import time
import urllib.request
import ssl
import json

__version__ = "1.1.0"

REPO_BASE = "https://raw.githubusercontent.com/Scottcjn/Rustchain/main"
INSTALL_DIR = os.path.join(os.path.expanduser("~"), ".clawskill")
VENV_DIR = os.path.join(INSTALL_DIR, "venv")
NODE_URL = "https://50.28.86.131"

# ANSI colors
CYAN = "\033[36m"
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
BOLD = "\033[1m"
DIM = "\033[2m"
NC = "\033[0m"

# Known SHA256 hashes for miner files (updated each release)
KNOWN_HASHES = {
    "fingerprint_checks.py": None,  # Set to None = verify-only mode (print hash)
    "miner.py": None,
}


def log(msg):
    print(f"{CYAN}[clawskill]{NC} {msg}")


def success(msg):
    print(f"{GREEN}[OK]{NC} {msg}")


def warn(msg):
    print(f"{YELLOW}[WARN]{NC} {msg}")


def error(msg):
    print(f"{RED}[ERROR]{NC} {msg}", file=sys.stderr)
    sys.exit(1)


def sha256_file(path):
    """Compute SHA256 hash of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def download_file(url, dest):
    """Download a file from URL to dest path."""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        urllib.request.urlretrieve(url, dest)
        size = os.path.getsize(dest)
        if size < 100:
            raise Exception(f"File too small ({size} bytes)")
        return size
    except Exception as e:
        raise Exception(f"Download failed for {url}: {e}")


def run_cmd(cmd, check=True, capture=False):
    """Run a shell command."""
    try:
        result = subprocess.run(
            cmd, shell=True, check=check,
            capture_output=capture, text=True
        )
        return result.stdout.strip() if capture else None
    except subprocess.CalledProcessError:
        if check:
            raise
        return None


def _detect_vm():
    """Quick VM detection — warns the user upfront."""
    indicators = []
    system = platform.system()

    if system == "Linux":
        dmi_paths = [
            "/sys/class/dmi/id/sys_vendor",
            "/sys/class/dmi/id/product_name",
            "/sys/class/dmi/id/board_vendor",
        ]
        vm_vendors = ["qemu", "vmware", "virtualbox", "xen", "kvm", "microsoft", "parallels", "bhyve"]
        for p in dmi_paths:
            try:
                with open(p) as f:
                    val = f.read().strip().lower()
                    if any(v in val for v in vm_vendors):
                        indicators.append(f"{p}: {val}")
            except (OSError, IOError):
                pass

        try:
            with open("/proc/cpuinfo") as f:
                if "hypervisor" in f.read().lower():
                    indicators.append("cpuinfo: hypervisor flag")
        except (OSError, IOError):
            pass

    elif system == "Darwin":
        try:
            out = subprocess.run(
                ["sysctl", "-n", "machdep.cpu.features"],
                capture_output=True, text=True
            ).stdout.lower()
            if "vmm" in out:
                indicators.append("sysctl: VMM flag")
        except Exception:
            pass

    return indicators


def _show_consent_disclosure():
    """Show what ClawSkill does before proceeding."""
    print(textwrap.dedent(f"""
    {BOLD}What ClawSkill will do:{NC}

      {CYAN}1. Download{NC}  Two Python scripts from the RustChain GitHub repository:
         - fingerprint_checks.py  (hardware detection)
         - miner.py               (attestation client)
         Source: {REPO_BASE}

      {CYAN}2. Install{NC}   A Python virtual environment in ~/.clawskill/
         with one dependency: 'requests' (HTTP library)

      {CYAN}3. Attest{NC}    When started, the miner contacts the RustChain network
         every few minutes to prove your hardware is real.

      {CYAN}4. Collect{NC}   Hardware fingerprint data sent during attestation:
         - CPU model, architecture, vendor
         - Clock timing variance (proves real oscillator)
         - Cache latency profile (proves real cache hierarchy)
         - VM detection flags (hypervisor, DMI vendor)
         {DIM}No personal data, files, browsing history, or credentials are collected.
         No data is sent to any third party — only to the RustChain node.{NC}

      {CYAN}5. Earn{NC}      RTC tokens accumulate in your wallet each epoch (~10 min)

    {DIM}Verify yourself:{NC}
      clawskill install --dry-run      Preview without installing
      clawskill install --show-urls    See exact download URLs
      Source code: https://github.com/Scottcjn/Rustchain
      Block explorer: https://50.28.86.131/explorer
    """))


def _get_download_urls():
    """Return list of (url, filename) tuples for current platform."""
    system = platform.system()
    downloads = [
        (f"{REPO_BASE}/miners/linux/fingerprint_checks.py", "fingerprint_checks.py"),
    ]
    if system == "Linux":
        downloads.append((f"{REPO_BASE}/miners/linux/rustchain_linux_miner.py", "miner.py"))
    elif system == "Darwin":
        downloads.append((f"{REPO_BASE}/miners/macos/rustchain_mac_miner_v2.4.py", "miner.py"))
    return downloads


def cmd_install(args):
    """Install and configure ClawSkill miner for your AI agent."""
    print(textwrap.dedent(f"""
    {CYAN}{BOLD}
      ██████╗██╗      █████╗ ██╗    ██╗███████╗██╗  ██╗██╗██╗     ██╗
     ██╔════╝██║     ██╔══██╗██║    ██║██╔════╝██║ ██╔╝██║██║     ██║
     ██║     ██║     ███████║██║ █╗ ██║███████╗█████╔╝ ██║██║     ██║
     ██║     ██║     ██╔══██║██║███╗██║╚════██║██╔═██╗ ██║██║     ██║
     ╚██████╗███████╗██║  ██║╚███╔███╔╝███████║██║  ██╗██║███████╗███████╗
      ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝ ╚══════╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝
    {NC}
    {DIM}  Mine RTC tokens with your AI agent on real hardware{NC}
    {DIM}  Modern x86/ARM = 1x | Vintage PowerPC = up to 2.5x | VM = ~0x{NC}
    {DIM}  Version {__version__}{NC}
    """))

    system = platform.system()
    machine = platform.machine()
    log(f"Platform: {system} | Arch: {machine}")

    if system not in ("Linux", "Darwin"):
        error(f"Unsupported platform: {system}. Use Linux or macOS.")

    # --show-urls: just print URLs and exit
    if getattr(args, "show_urls", False):
        log("Files that will be downloaded:")
        for url, filename in _get_download_urls():
            print(f"  {filename}: {url}")
        print(f"\n  Network node: {NODE_URL}")
        print(f"  Source repo: https://github.com/Scottcjn/Rustchain")
        return

    # --dry-run: show what would happen, don't do it
    if getattr(args, "dry_run", False):
        _show_consent_disclosure()
        log("DRY RUN — no files downloaded, no services created.")
        return

    # Show disclosure and get consent (unless --yes)
    if not getattr(args, "yes", False):
        _show_consent_disclosure()
        try:
            answer = input(f"{CYAN}[clawskill]{NC} Proceed with installation? [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = ""
        if answer not in ("y", "yes"):
            log("Installation cancelled.")
            return

    # VM check — warn upfront, don't block
    vm_hints = _detect_vm()
    if vm_hints:
        print(textwrap.dedent(f"""
    {RED}{BOLD}  ╔══════════════════════════════════════════════════════════╗
      ║              ⚠  VM DETECTED — READ THIS  ⚠             ║
      ╠══════════════════════════════════════════════════════════╣
      ║                                                          ║
      ║  This machine appears to be a virtual machine.           ║
      ║  RustChain's hardware fingerprint system WILL detect     ║
      ║  VMs and assigns near-zero mining weight.                ║
      ║                                                          ║
      ║  Your miner will attest, but earn effectively nothing.   ║
      ║  This is by design — RTC rewards real hardware only.     ║
      ║                                                          ║
      ║  VM indicators found:                                    ║{NC}"""))
        for h in vm_hints[:4]:
            print(f"      {RED}  •  {h}{NC}")
        print(f"""      {RED}{BOLD}║                                                          ║
      ║  To earn RTC, run on bare-metal hardware.               ║
      ╚══════════════════════════════════════════════════════════╝{NC}
""")

    # Wallet setup
    wallet = args.wallet
    if not wallet:
        try:
            wallet = input(f"{CYAN}[clawskill]{NC} Enter agent wallet name (e.g. my-claw-agent): ").strip()
        except (EOFError, KeyboardInterrupt):
            wallet = ""

    if not wallet:
        hostname = platform.node().split(".")[0] or "agent"
        wallet = f"claw-{hostname}-{int(time.time()) % 100000}"
        warn(f"No wallet name provided. Auto-generated: {wallet}")

    # Create install dir
    log(f"Installing to {INSTALL_DIR}")
    os.makedirs(INSTALL_DIR, exist_ok=True)

    # Save wallet
    with open(os.path.join(INSTALL_DIR, ".wallet"), "w") as f:
        f.write(wallet)

    # Create venv
    if not os.path.isdir(VENV_DIR):
        log("Creating Python environment...")
        run_cmd(f'"{sys.executable}" -m venv "{VENV_DIR}"')

    # Install deps
    log("Installing dependencies...")
    pip = os.path.join(VENV_DIR, "bin", "pip")
    run_cmd(f'"{pip}" install --upgrade pip -q')
    run_cmd(f'"{pip}" install requests -q')
    success("Dependencies ready")

    # Download miner files
    log("Downloading miner from RustChain repo...")
    downloads = _get_download_urls()

    for url, filename in downloads:
        log(f"  Fetching: {url}")
        dest = os.path.join(INSTALL_DIR, filename)
        size = download_file(url, dest)
        file_hash = sha256_file(dest)
        log(f"  {filename} ({size / 1024:.1f} KB) SHA256: {file_hash[:16]}...")

        # Verify hash if known
        expected = KNOWN_HASHES.get(filename)
        if expected and file_hash != expected:
            error(f"Hash mismatch for {filename}! Expected {expected[:16]}..., got {file_hash[:16]}...")

    success("Miner files downloaded and verified")

    # --verify: show full hashes and exit
    if getattr(args, "verify", False):
        log("File hashes (SHA256):")
        for url, filename in downloads:
            dest = os.path.join(INSTALL_DIR, filename)
            print(f"  {filename}: {sha256_file(dest)}")
        return

    # Setup service ONLY if --service flag is passed
    if getattr(args, "service", False):
        log("Setting up background service (--service flag)...")
        if system == "Linux":
            _setup_systemd(wallet)
        elif system == "Darwin":
            _setup_launchd(wallet)
    else:
        log(f"No background service created. To enable auto-start, re-run with --service")
        log(f"Or start manually: clawskill start")

    # Check network
    log("Checking RustChain network...")
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(f"{NODE_URL}/api/miners")
        with urllib.request.urlopen(req, context=ctx, timeout=10) as resp:
            miners = json.loads(resp.read())
            log(f"Active miners on network: {len(miners)}")
    except Exception:
        warn("Could not reach network (node may be temporarily unavailable)")

    print(textwrap.dedent(f"""
    {GREEN}{BOLD}═══════════════════════════════════════════════════════════
      ClawSkill installed!  Your agent is ready to mine RTC.

      Wallet:    {wallet}
      Location:  {INSTALL_DIR}
      Reward:    1x multiplier (modern hardware)

      Next steps:
        clawskill start              Start mining (foreground)
        clawskill start --service    Start + enable auto-restart
        clawskill stop               Stop mining
        clawskill status             Check miner + network status
        clawskill logs               View miner output

      How it works:
        • Your agent proves real hardware via 6 fingerprint checks
        • Attestation happens automatically every few minutes
        • RTC tokens accumulate in your wallet each epoch (~10 min)
        • Check balance: clawskill status

      Verify & audit:
        • Source: https://github.com/Scottcjn/Rustchain
        • Explorer: https://50.28.86.131/explorer
        • clawskill uninstall   Remove everything cleanly
    ═══════════════════════════════════════════════════════════{NC}
    """))


def _setup_systemd(wallet):
    """Set up systemd user service on Linux."""
    service_dir = os.path.expanduser("~/.config/systemd/user")
    os.makedirs(service_dir, exist_ok=True)
    service_file = os.path.join(service_dir, "clawskill-miner.service")
    python_bin = os.path.join(VENV_DIR, "bin", "python")
    miner_py = os.path.join(INSTALL_DIR, "miner.py")

    with open(service_file, "w") as f:
        f.write(textwrap.dedent(f"""\
            [Unit]
            Description=ClawSkill RTC Miner — AI Agent Mining
            After=network-online.target
            Wants=network-online.target

            [Service]
            ExecStart={python_bin} {miner_py} --wallet {wallet}
            Restart=always
            RestartSec=30
            WorkingDirectory={INSTALL_DIR}
            Environment=PYTHONUNBUFFERED=1

            [Install]
            WantedBy=default.target
        """))

    try:
        run_cmd("systemctl --user daemon-reload")
        run_cmd("systemctl --user enable clawskill-miner")
        run_cmd("systemctl --user start clawskill-miner")
        success("Service installed and started (auto-restarts on reboot)")
    except Exception:
        warn("Systemd user services not available. Use: clawskill start")


def _setup_launchd(wallet):
    """Set up launchd agent on macOS."""
    plist_dir = os.path.expanduser("~/Library/LaunchAgents")
    os.makedirs(plist_dir, exist_ok=True)
    plist_file = os.path.join(plist_dir, "com.clawskill.miner.plist")
    python_bin = os.path.join(VENV_DIR, "bin", "python")
    miner_py = os.path.join(INSTALL_DIR, "miner.py")

    with open(plist_file, "w") as f:
        f.write(textwrap.dedent(f"""\
            <?xml version="1.0" encoding="UTF-8"?>
            <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
              "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
            <plist version="1.0">
            <dict>
                <key>Label</key>
                <string>com.clawskill.miner</string>
                <key>ProgramArguments</key>
                <array>
                    <string>{python_bin}</string>
                    <string>{miner_py}</string>
                    <string>--wallet</string>
                    <string>{wallet}</string>
                </array>
                <key>WorkingDirectory</key>
                <string>{INSTALL_DIR}</string>
                <key>RunAtLoad</key>
                <true/>
                <key>KeepAlive</key>
                <true/>
                <key>StandardOutPath</key>
                <string>{os.path.join(INSTALL_DIR, "miner.log")}</string>
                <key>StandardErrorPath</key>
                <string>{os.path.join(INSTALL_DIR, "miner.err")}</string>
            </dict>
            </plist>
        """))

    try:
        run_cmd(f'launchctl unload "{plist_file}" 2>/dev/null', check=False)
        run_cmd(f'launchctl load "{plist_file}"')
        success("LaunchAgent installed and loaded (auto-restarts on login)")
    except Exception:
        warn("Could not load LaunchAgent. Use: clawskill start")


def cmd_start(args):
    """Start the ClawSkill miner."""
    system = platform.system()

    # If --service flag, set up persistence then start
    if getattr(args, "service", False):
        wallet_file = os.path.join(INSTALL_DIR, ".wallet")
        wallet = open(wallet_file).read().strip() if os.path.exists(wallet_file) else "agent"
        if system == "Linux":
            _setup_systemd(wallet)
        elif system == "Darwin":
            _setup_launchd(wallet)
        return

    # Try systemd first (if service exists)
    if system == "Linux":
        sf = os.path.expanduser("~/.config/systemd/user/clawskill-miner.service")
        if os.path.exists(sf):
            run_cmd("systemctl --user start clawskill-miner")
            success("Miner started (systemd)")
            return

    elif system == "Darwin":
        pf = os.path.expanduser("~/Library/LaunchAgents/com.clawskill.miner.plist")
        if os.path.exists(pf):
            run_cmd(f'launchctl load "{pf}"', check=False)
            success("Miner started (launchd)")
            return

    # Fallback: run in foreground
    miner_py = os.path.join(INSTALL_DIR, "miner.py")
    python_bin = os.path.join(VENV_DIR, "bin", "python")
    wallet_file = os.path.join(INSTALL_DIR, ".wallet")

    if not os.path.exists(miner_py):
        error("Miner not installed. Run: clawskill install")

    wallet = open(wallet_file).read().strip() if os.path.exists(wallet_file) else ""
    w_arg = f"--wallet {wallet}" if wallet else ""
    log(f"Starting miner in foreground (Ctrl+C to stop)...")
    log(f"Tip: Use 'clawskill start --service' for background auto-restart")
    os.execvp(python_bin, [python_bin, miner_py] + (["--wallet", wallet] if wallet else []))


def cmd_stop(args):
    """Stop the ClawSkill miner."""
    system = platform.system()
    if system == "Linux":
        run_cmd("systemctl --user stop clawskill-miner", check=False)
    elif system == "Darwin":
        pf = os.path.expanduser("~/Library/LaunchAgents/com.clawskill.miner.plist")
        run_cmd(f'launchctl unload "{pf}"', check=False)
    success("Miner stopped")


def cmd_status(args):
    """Check miner and network status."""
    system = platform.system()

    # Service status
    if system == "Linux":
        sf = os.path.expanduser("~/.config/systemd/user/clawskill-miner.service")
        if os.path.exists(sf):
            run_cmd("systemctl --user status clawskill-miner", check=False)
        else:
            log("No background service configured. Use: clawskill start --service")
    elif system == "Darwin":
        run_cmd("launchctl list | grep clawskill", check=False)

    # Wallet info
    wallet_file = os.path.join(INSTALL_DIR, ".wallet")
    if os.path.exists(wallet_file):
        wallet = open(wallet_file).read().strip()
        log(f"Wallet: {wallet}")

    # File integrity
    for filename in ["miner.py", "fingerprint_checks.py"]:
        path = os.path.join(INSTALL_DIR, filename)
        if os.path.exists(path):
            h = sha256_file(path)
            log(f"{filename} SHA256: {h[:16]}...")

    # Network check
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(f"{NODE_URL}/health")
        with urllib.request.urlopen(req, context=ctx, timeout=10) as resp:
            health = json.loads(resp.read())
            status = "online" if health.get("ok") else "offline"
            log(f"Network: {status} (v{health.get('version', '?')})")
    except Exception:
        warn("Could not reach network")


def cmd_logs(args):
    """View miner logs."""
    system = platform.system()
    if system == "Linux":
        sf = os.path.expanduser("~/.config/systemd/user/clawskill-miner.service")
        if os.path.exists(sf):
            os.execlp("journalctl", "journalctl", "--user", "-u", "clawskill-miner", "-f", "--no-pager", "-n", "50")
        else:
            log_file = os.path.join(INSTALL_DIR, "miner.log")
            if os.path.exists(log_file):
                os.execlp("tail", "tail", "-f", log_file)
            else:
                warn("No logs found. Start the miner first: clawskill start")
    elif system == "Darwin":
        log_file = os.path.join(INSTALL_DIR, "miner.log")
        if os.path.exists(log_file):
            os.execlp("tail", "tail", "-f", log_file)
        else:
            warn("No log file found")


def cmd_uninstall(args):
    """Remove ClawSkill miner and all files."""
    log("Stopping miner...")
    cmd_stop(args)

    system = platform.system()
    if system == "Linux":
        run_cmd("systemctl --user disable clawskill-miner", check=False)
        sf = os.path.expanduser("~/.config/systemd/user/clawskill-miner.service")
        if os.path.exists(sf):
            os.unlink(sf)
            run_cmd("systemctl --user daemon-reload", check=False)
    elif system == "Darwin":
        pf = os.path.expanduser("~/Library/LaunchAgents/com.clawskill.miner.plist")
        if os.path.exists(pf):
            os.unlink(pf)

    if os.path.isdir(INSTALL_DIR):
        shutil.rmtree(INSTALL_DIR)

    success("ClawSkill miner fully uninstalled — no files remain")


def main():
    parser = argparse.ArgumentParser(
        prog="clawskill",
        description="ClawSkill — Mine RTC tokens with your AI agent on real hardware",
        epilog=textwrap.dedent("""\
            Your Claw agent earns RTC by proving it runs on real hardware.
            Modern x86/ARM gets 1x multiplier. VMs are detected and penalized.
            Vintage hardware (PowerPC, etc.) earns bonus multipliers up to 2.5x.

            Security & verification:
              clawskill install --dry-run      Preview without changes
              clawskill install --show-urls    See download sources
              clawskill install --verify       Show file hashes
              Source: https://github.com/Scottcjn/Rustchain
        """),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command")

    p_install = sub.add_parser("install", help="Install miner and configure wallet")
    p_install.add_argument("--wallet", help="Agent wallet name for mining rewards")
    p_install.add_argument("--dry-run", action="store_true", help="Preview what will be installed without making changes")
    p_install.add_argument("--show-urls", action="store_true", help="Show exact URLs that will be downloaded")
    p_install.add_argument("--verify", action="store_true", help="Show SHA256 hashes of downloaded files")
    p_install.add_argument("--service", action="store_true", help="Create background service (systemd/launchd)")
    p_install.add_argument("--no-service", action="store_true", help="Skip background service setup (default)")
    p_install.add_argument("-y", "--yes", action="store_true", help="Skip consent prompt (for CI/automation)")

    p_start = sub.add_parser("start", help="Start mining")
    p_start.add_argument("--service", action="store_true", help="Create background service for auto-restart")

    sub.add_parser("stop", help="Stop mining")
    sub.add_parser("status", help="Check miner + network status + file hashes")
    sub.add_parser("logs", help="View miner output logs")
    sub.add_parser("uninstall", help="Remove miner and all files completely")

    args = parser.parse_args()

    commands = {
        "install": cmd_install,
        "start": cmd_start,
        "stop": cmd_stop,
        "status": cmd_status,
        "logs": cmd_logs,
        "uninstall": cmd_uninstall,
    }

    if not args.command:
        parser.print_help()
        return

    func = commands.get(args.command)
    if func:
        func(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
