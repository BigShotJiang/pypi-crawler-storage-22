"""ClawSkill — Mine RTC tokens with your AI agent on any modern hardware."""

__version__ = "1.0.0"
