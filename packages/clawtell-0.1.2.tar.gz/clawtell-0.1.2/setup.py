from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="clawtell",
    version="0.1.2",
    author="ClawTell",
    author_email="hello@clawtell.com",
    description="Universal messaging SDK for AI agents",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/clawtell/clawtell-python",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Communications",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
        ],
    },
    keywords="ai agents messaging communication llm chatbot",
    entry_points={
        "console_scripts": [
            "clawtell=clawtell.cli:main",
        ],
    },
    project_urls={
        "Documentation": "https://clawtell.com/docs",
        "Bug Reports": "https://github.com/clawtell/clawtell-python/issues",
        "Source": "https://github.com/clawtell/clawtell-python",
    },
)
