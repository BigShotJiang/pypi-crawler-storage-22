## [2.0.44] - 2026-02-04

### Fixed
- More columns with documentation problem for the schema

