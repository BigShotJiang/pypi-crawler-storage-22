class PermissionsError(Exception):
    pass
