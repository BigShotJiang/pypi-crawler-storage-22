## [2.0.5] - 2026-02-04

### Changed
- Extend catalog entity

