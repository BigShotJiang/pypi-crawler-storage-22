## [2.0.8] - 2026-02-04

### Added
- Add flags for delete, create, update, query

### Fixed
- Cortex backend pagination

