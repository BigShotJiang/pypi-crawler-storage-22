## [2.0.12] - 2026-02-04

### Added
- Add flags for delete, create, update, query

