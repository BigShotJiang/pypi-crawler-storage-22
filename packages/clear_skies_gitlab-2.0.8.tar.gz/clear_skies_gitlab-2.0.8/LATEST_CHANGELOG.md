## [2.0.8] - 2026-02-02

### Changed
- Update to latest dependencies

### Fixed
- Limits

