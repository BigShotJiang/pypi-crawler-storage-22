## [2.0.4] - 2026-02-17

### Added
- Add backend for the import jobs to handle the location header

