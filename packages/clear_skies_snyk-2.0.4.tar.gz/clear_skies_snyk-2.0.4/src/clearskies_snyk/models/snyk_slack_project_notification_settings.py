"""Snyk Slack Project Notification Settings model."""

from typing import Self

from clearskies import Model
from clearskies.columns import Boolean, String

from clearskies_snyk.backends import SnykBackend


class SnykSlackProjectNotificationSettings(Model):
    """
    Model for Snyk Slack Project Notification Settings.

    This model represents project-specific Slack notification settings that override
    the default settings for an organization.
    Uses the Snyk v2 REST API endpoint: /orgs/{org_id}/slack_app/{bot_id}/projects/{project_id}

    ```python
    import clearskies
    from clearskies_snyk.models import SnykSlackProjectNotificationSettings


    def my_handler(snyk_slack_project_notification_settings: SnykSlackProjectNotificationSettings):
        # Get project-specific Slack notification settings
        settings = snyk_slack_project_notification_settings.where("org_id=org-123").where(
            "bot_id=bot-456"
        )
        for setting in settings:
            print(f"Project: {setting.target_project_name}, Active: {setting.is_active}")
    ```
    """

    id_column_name: str = "id"

    backend = SnykBackend(api_to_model_map={"type": "settings_type"})

    @classmethod
    def destination_name(cls: type[Self]) -> str:
        """Return the slug of the api endpoint for this model."""
        return "orgs/{org_id}/slack_app/{bot_id}/projects"

    # Columns based on ProjectSettingsData schema
    id = String()
    org_id = String(is_searchable=True)
    bot_id = String(is_searchable=True)
    project_id = String(is_searchable=True)
    settings_type = String()  # Mapped from 'type', e.g., "slack"

    # Attributes
    target_channel_id = String()  # URI format, e.g., "slack://channel?team=team-id&id=channel-id"
    target_channel_name = String()  # Name of the Slack channel
    severity_threshold = String()  # low, medium, high, critical
    target_project_name = String()  # The target file name for the project
    is_active = Boolean()  # Current status of the project settings
