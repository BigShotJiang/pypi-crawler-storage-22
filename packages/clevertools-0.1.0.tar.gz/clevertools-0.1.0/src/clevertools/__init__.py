from __future__ import annotations

from .tools.test_tool import TestFunction

__all__ = ["TestFunction", "test_one", "test_two"]


def test_one() -> None:
    TestFunction.test_one()


def test_two() -> None:
    TestFunction.test_two()
