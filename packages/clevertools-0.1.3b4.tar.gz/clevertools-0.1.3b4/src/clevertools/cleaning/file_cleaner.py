from __future__ import annotations

from pathlib import Path

from ..error_handling.validation import ValidateFile
from ..error_handling.status import Result

class FileCleaner:
    def __init__(self) -> None:
        pass
    
    def _start_removing(self, file_path: Path) -> Result[None]:
        try:
            file_path.unlink()
            return Result.success(None)
        except Exception as exc:
            return Result.failure(str(exc))
        
    def _start_emptying(self, file_path: Path) -> Result[None]:
        try:
            with file_path.open("w"):
                pass
            return Result.success(None)
        except Exception as exc:
            return Result.failure(str(exc))

def clean_file(file_path: Path | str) -> Result[None]:
    path: Path = Path(file_path)
    ValidateFile(path)
    
    try:
        if path is None:
            return Result.success(None)

        if path.resolve() == Path("/"):
            return Result.failure("Refusing to clean root directory")

        cleaner = FileCleaner()
        cleaner._start_removing(path)
        
        return Result.success(None)
    except Exception as exc:
        return Result.failure(str(exc))
