from __future__ import annotations

from typing import Iterable, Optional
from pathlib import Path
import shutil

from ..error_handling.validation import ValidateFolder
from ..error_handling.status import Result

class FolderCleaner:
    def __init__(self, skipped_dirs: Optional[Iterable[str]]) -> None:
        self.skip_set: set[str] = set(skipped_dirs or [])

    def _remove_item(self, item: Path) -> Result[None]:
        try:
            if item.is_symlink() or item.is_file():
                item.unlink()
            elif item.is_dir():
                shutil.rmtree(item)
            return Result.success(None)
        except Exception as exc:
            return Result.failure(str(exc))

    def _start_removing(self, folder_path: Path) -> Result[None]:
        try:
            for item in folder_path.iterdir():
                if item.name in self.skip_set:
                    continue

                result = self._remove_item(item)
                if not result.ok:
                    return result
            return Result.success(None)
        except Exception as exc:
            return Result.failure(str(exc))

def clean_folder(folder_path: Path | str, skipped_dirs: Optional[Iterable[str]] = None) -> Result[None]:
    path: Path = Path(folder_path)
    ValidateFolder(path)
    
    try:
        if path is None:
            return Result.success(None)

        if path.resolve() == Path("/"):
            return Result.failure("Refusing to clean root directory")

        cleaner = FolderCleaner(skipped_dirs)
        cleaner._start_removing(path)
        
        return Result.success(None)
    except Exception as exc:
        return Result.failure(str(exc))