from __future__ import annotations

from typing import Optional, Iterable
from pathlib import Path
import shutil
import os

from ..error_handling.validation import ValidateFolder
from ..error_handling.status import Result

class PycacheCleaner:
    def __init__(self, skipped_dirs: Optional[Iterable[str]]) -> None:
        self.skip_set: set[str] = set(skipped_dirs or [])
        self.cache_dir_name: str = "__pycache__"
        self.bytecode_suffixes: set[str] = {".pyc", ".pyo"}

    def _remove_path(self, path: Path) -> Result[None]:
        try:
            if path.is_symlink() or path.is_file():
                path.unlink(missing_ok=True)
                return Result.success(None)

            if path.is_dir():
                shutil.rmtree(path)
                return Result.success(None)

            return Result.success(None)
        except Exception as exc:
            return Result.failure(str(exc))

    def _start_removing(self, folder_path: Path) -> Result[None]:
        try:
            for current_dir, dir_names, file_names in os.walk(folder_path, topdown=True):
                current_path = Path(current_dir)
                
                dir_names[:] = [d for d in dir_names if d not in self.skip_set]
            
                if self.cache_dir_name in dir_names:
                    pycache_path = current_path / self.cache_dir_name
                    result = self._remove_path(pycache_path)
                    if not result.ok:
                        return result
                    dir_names.remove(self.cache_dir_name)

                for fn in file_names:
                    p = current_path / fn
                    if p.suffix in self.bytecode_suffixes:
                        result = self._remove_path(p)
                        if not result.ok:
                            return result
                            
            return Result.success(None)
        except Exception as exc:
            return Result.failure(str(exc))

def clean_pycaches(folder_path: Path | str, skipped_dirs: Optional[Iterable[str]] = None) -> Result[None]:
    path: Path = Path(folder_path)
    ValidateFolder(path)

    try: 
        if path is None:
            return Result.success(None)

        if path.resolve() == Path("/"):
            return Result.failure("Refusing to clean root directory")

        cleaner = PycacheCleaner(skipped_dirs)
        result = cleaner._start_removing(path)
        
        if not result.ok:
            return result
        return Result.success(None)
    except Exception as exc:
        return Result.failure(str(exc))