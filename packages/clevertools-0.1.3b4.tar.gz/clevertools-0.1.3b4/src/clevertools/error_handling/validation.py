from __future__ import annotations

from .status import Result
from pathlib import Path
from typing import Dict


class ValidateFile:
    def __init__(self, FILE_PATH: Path) -> None:
        self.FILE_PATH: Path = FILE_PATH

        self.does_file_exist()
        self.is_file()

    def does_file_exist(self) -> Result[Dict]:
        try:
            if not self.FILE_PATH.exists():
                raise FileExistsError(f"{self.FILE_PATH} does not exist!")
            return Result.success()
        except Exception as exc:
            return Result.failure(str(exc))

    def is_file(self) -> Result[Dict]:
        try:
            if not self.FILE_PATH.is_file():
                raise FileExistsError(f"{self.FILE_PATH} is not a file!")
            return Result.success()
        except Exception as exc:
            return Result.failure(str(exc))

class ValidateFolder:
    def __init__(self, FOLDER_PATH: Path) -> None:
        self.FOLDER_PATH: Path = FOLDER_PATH

        self.does_folder_exist()
        self.is_folder()

    def does_folder_exist(self) -> Result[Dict]:
        try:
            if not self.FOLDER_PATH.exists():
                raise FileExistsError(f"{self.FOLDER_PATH} does not exist!")
            return Result.success()
        except Exception as exc:
            return Result.failure(str(exc))

    def is_folder(self) -> Result[Dict]:
        try:
            if not self.FOLDER_PATH.is_dir():
                raise FileExistsError(f"{self.FOLDER_PATH} is not a directory!")
            return Result.success()
        except Exception as exc:
            return Result.failure(str(exc))
