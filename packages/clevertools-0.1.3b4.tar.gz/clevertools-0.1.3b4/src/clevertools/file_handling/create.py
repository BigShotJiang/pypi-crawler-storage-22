from __future__ import annotations

from pathlib import Path
from typing import Any

from ..error_handling.validation import ValidateFile, ValidateFolder
from ..error_handling.status import Result

def create_file(file_path: Path | str, data: Any) -> Result[None]:
    path: Path = Path(file_path)
    ValidateFile(path)

    try:
        if not path.exists():
            path.touch(exist_ok=True)
            print(f"created: {path}")
        else:
            print(f"{path} already exists!")
        
        return Result.success(None)
    except Exception as exc:
        return Result.failure(str(exc))

def create_folder(folder_path: Path | str) -> Result[None]:
    path: Path = Path(folder_path)
    
    try:
        if not path.exists():
            path.mkdir(parents=True, exist_ok=True)
            print(f"created: {path}")
        else:
            print(f"{path} already exists!")
        
        ValidateFolder(path)
        return Result.success(None)
    except Exception as exc:
        return Result.failure(str(exc))