from __future__ import annotations

from typing import Dict, Any
from pathlib import Path
import tomli_w
import tomllib

from ..error_handling.validation import ValidateFile
from ..error_handling.status import Result

class TomlResult(Result[Dict[Any, Any]]):
    def get(self, key: Any, default: Any = None) -> Any:
        if not self.ok or not isinstance(self.value, dict):
            return default

        if not isinstance(key, str) or "." not in key:
            return self.value.get(key, default)

        if key in self.value:
            return self.value.get(key, default)

        current: Any = self.value
        for part in key.split("."):
            if not isinstance(current, dict) or part not in current:
                return default
            current = current[part]

        return current

def read_toml(file_path: Path | str) -> TomlResult:
    path: Path = Path(file_path)
    ValidateFile(path)

    try:
        with path.open("rb") as f:
            return TomlResult.success(tomllib.load(f))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        return TomlResult.failure(str(exc))

def write_toml(file_path: Path | str, data: Any) -> Result[None]:
    path = Path(file_path)
    ValidateFile(path)
    
    try:
        with path.open("wb") as f:
            tomli_w.dump(data, f)
        return Result.success(None)
    except (OSError, TypeError, ValueError) as exc:
        return Result.failure(str(exc))