from __future__ import annotations

from typing import Dict, Any
from pathlib import Path
import yaml

from ..error_handling.validation import ValidateFile
from ..error_handling.status import Result

def read_yaml(file_path: Path | str) -> Result[Dict[Any, Any]]:
    path: Path = Path(file_path)
    ValidateFile(path)

    try:
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            return Result.success(data if data is not None else {})
    except (OSError, yaml.YAMLError) as exc:
        return Result.failure(str(exc))

def write_yaml(file_path: Path | str, data: Any) -> Result[None]:
    path = Path(file_path)
    ValidateFile(path)

    try:
        with path.open("w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)
        return Result.success(None)
    except (OSError, yaml.YAMLError, TypeError, ValueError) as exc:
        return Result.failure(str(exc))
