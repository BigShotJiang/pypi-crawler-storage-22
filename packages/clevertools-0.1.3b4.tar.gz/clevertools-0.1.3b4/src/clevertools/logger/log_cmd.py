from __future__ import annotations

from ..error_handling.status import Result

def log(process: str, level: str, message: str) -> Result[None]:
    try:
        level = (level or "INFO").upper()
        print(f"{process} | [ {level} ] = {message}")
        return Result.success(None)
    except Exception as exc:
        return Result.failure(str(exc))