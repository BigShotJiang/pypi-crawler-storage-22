from __future__ import annotations

from typing import Any, Generic, TypeVar, Union
from dataclasses import dataclass
from enum import IntEnum


class ExitCode(IntEnum):
    OK = 0
    ERROR = 1
    INVALID_INPUT = 2
    NOT_FOUND = 3
    IO_ERROR = 4
    PERMISSION_DENIED = 5


T = TypeVar("T")

@dataclass(frozen=True, slots=True)
class Result(Generic[T]):
    exit_code: int
    value: T | None = None
    error: str | None = None
    details: Any | None = None

    @property
    def ok(self) -> bool:
        return int(self.exit_code) == int(ExitCode.OK)

    @property
    def is_error(self) -> bool:
        return not self.ok

    @classmethod
    def success(cls, value: T | None = None) -> "Result[T]":
        return cls(exit_code=int(ExitCode.OK), value=value)

    @classmethod
    def failure(cls, error: str | None = None, exit_code: int | ExitCode = ExitCode.ERROR, details: Any | None = None) -> "Result[T]":
        return cls(exit_code=int(exit_code), value=None, error=error, details=details)

    def with_code(self, exit_code: int | ExitCode) -> "Result[T]":
        return Result(exit_code=int(exit_code), value=self.value, error=self.error, details=self.details)


def is_ok(code: Union[int, "ExitCode"]) -> bool:
    try:
        return int(code) == int(ExitCode.OK)
    except (TypeError, ValueError):
        return False
