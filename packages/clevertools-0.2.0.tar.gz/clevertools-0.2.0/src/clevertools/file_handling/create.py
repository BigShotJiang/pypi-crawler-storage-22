from __future__ import annotations

from pathlib import Path

from ..error_handling.status import Result, ExitCode


def file_create(path: str, content: str = "") -> Result[None]:
    p = Path(path)
    if p.exists():
        if p.is_file():
            return Result.failure(
                exit_code=ExitCode.INVALID_INPUT,
                error="File already exists",
                details={"path": path},
            )
        return Result.failure(
            exit_code=ExitCode.INVALID_INPUT,
            error="Path is not a file",
            details={"path": path},
        )

    if not p.parent.exists():
        return Result.failure(
            exit_code=ExitCode.NOT_FOUND,
            error="Parent directory not found",
            details={"path": path},
        )

    try:
        with p.open("x", encoding="utf-8") as f:
            if content:
                f.write(content)
    except FileExistsError:
        return Result.failure(
            exit_code=ExitCode.INVALID_INPUT,
            error="File already exists",
            details={"path": path},
        )
    except OSError as e:
        return Result.failure(
            exit_code=ExitCode.IO_ERROR,
            error=str(e),
            details={"path": path},
        )

    return Result.success(None)
