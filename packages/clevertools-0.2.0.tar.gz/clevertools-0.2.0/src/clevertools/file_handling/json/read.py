from __future__ import annotations

from pathlib import Path
import json

from ...error_handling.status import Result, ExitCode


def json_read(path: str) -> Result[dict]:
    p = Path(path)
    if not p.exists():
        return Result.failure(exit_code=ExitCode.NOT_FOUND, error="File not found", details={"path": path})
    try:
        with p.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        return Result.failure(exit_code=ExitCode.INVALID_INPUT, error="Invalid JSON", details={"path": path, "error": str(e)})
    except OSError as e:
        return Result.failure(exit_code=ExitCode.IO_ERROR, error=str(e), details={"path": path})
    return Result.success(data)