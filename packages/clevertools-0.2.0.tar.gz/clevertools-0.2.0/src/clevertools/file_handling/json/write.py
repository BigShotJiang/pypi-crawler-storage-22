from __future__ import annotations

import json
from pathlib import Path

from ...error_handling.status import Result, ExitCode


def json_write(path: str, data: dict) -> Result[None]:
    p = Path(path)
    if p.exists() and not p.is_file():
        return Result.failure(exit_code=ExitCode.INVALID_INPUT, error="Path is not a file", details={"path": path})

    try:
        with p.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except TypeError as e:
        return Result.failure(exit_code=ExitCode.INVALID_INPUT, error="Data is not JSON-serializable", details={"path": path, "error": str(e)})
    except OSError as e:
        return Result.failure(exit_code=ExitCode.IO_ERROR, error=str(e), details={"path": path})

    return Result.success(None)
