# clevertools

`clevertools` is a Python utility library focused on practical workflow helpers.
It provides reusable modules for file handling, cleaning operations, logging, and centralized error handling.

This repository contains the local source code, local integration test runner, and documentation.

## Project Goals
- Reduce repeated utility boilerplate in application code.
- Provide consistent validation and error handling behavior.
- Keep module usage simple while allowing global customization.
- Support realistic local verification through a config-driven test mini-program.

## Main Modules
- `error_handling`
  - structured results
  - action and policy handling
  - validation helpers
  - custom exception support
- `file_handling`
  - create file/folder
  - read/write JSON
  - read/write TOML
  - read/write YAML
- `cleaning`
  - clean file
  - clean folder content
  - clean pycache artifacts
- `logger`
  - simple process/level/message logging
- `messages`
  - centralized message templates for all modules

## Quick Start
Install dependencies:

```bash
python -m pip install -r requirements.txt
```

Run local test mini-program:

```bash
python tests/start.py
```

## Documentation
Detailed documentation is in `docs/`:
- `docs/README.md`
- `docs/error_handling_overview.md`
- `docs/error_handling_validation.md`
- `docs/error_handling_status.md`
- `docs/file_handling.md`
- `docs/cleaning.md`
- `docs/logger.md`
- `docs/messages.md`
- `docs/test_program.md`

## Repository Structure
- `src/clevertools/`: library source code
- `tests/`: config-driven local test mini-program
- `docs/`: detailed module and testing documentation

## Legal Notices
Please read:
- `LICENSE`
- `NOTICE`
- `CONTRIBUTORS`

By using, copying, or redistributing this project, you agree to their terms.
