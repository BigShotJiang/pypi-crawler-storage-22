from __future__ import annotations

from pathlib import Path

from ..error_handling.validation import ValidateFile
from ..error_handling.status import Result, enforce_result, stop
from ..messages import MESSAGES

class FileCleaner:
    def __init__(self) -> None:
        pass
    
    def _start_removing(self, file_path: Path) -> Result[None]:
        try:
            file_path.unlink()
            return Result.success(None)
        except Exception as exc:
            return enforce_result(Result.failure(MESSAGES["cleaning.file.remove_failed"].format(path=file_path, reason=exc)))
        
    def _start_emptying(self, file_path: Path) -> Result[None]:
        try:
            with file_path.open("w"):
                pass
            return Result.success(None)
        except Exception as exc:
            return enforce_result(Result.failure(MESSAGES["cleaning.file.remove_failed"].format(path=file_path, reason=exc)))

def clean_file(file_path: Path | str) -> Result[None]:
    path: Path = Path(file_path)
    ValidateFile(path, required=True)
    
    try:
        if path is None:
            return Result.success(None)

        if path.resolve() == Path("/"):
            return enforce_result(Result.failure(MESSAGES["cleaning.root_refused"], action=stop))

        cleaner = FileCleaner()
        result = cleaner._start_removing(path)
        if not result.ok:
            return result
        return Result.success(None)
    except Exception as exc:
        return enforce_result(Result.failure(MESSAGES["cleaning.file.remove_failed"].format(path=path, reason=exc)))