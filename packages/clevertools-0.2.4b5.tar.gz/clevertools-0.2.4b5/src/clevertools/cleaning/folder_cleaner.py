from __future__ import annotations

from typing import Iterable, Optional
from pathlib import Path
import shutil

from ..error_handling.validation import ValidateFolder
from ..error_handling.status import Result, enforce_result, stop
from ..messages import MESSAGES

class FolderCleaner:
    def __init__(self, skipped_dirs: Optional[Iterable[str]]) -> None:
        self.skip_set: set[str] = set(skipped_dirs or [])

    def _remove_item(self, item: Path) -> Result[None]:
        try:
            if item.is_symlink() or item.is_file():
                item.unlink()
            elif item.is_dir():
                shutil.rmtree(item)
            return Result.success(None)
        except Exception as exc:
            return enforce_result(Result.failure(MESSAGES["cleaning.folder.remove_item_failed"].format(path=item, reason=exc)))

    def _start_removing(self, folder_path: Path) -> Result[None]:
        try:
            for item in folder_path.iterdir():
                if item.name in self.skip_set:
                    continue

                result = self._remove_item(item)
                if not result.ok:
                    return result
            return Result.success(None)
        except Exception as exc:
            return enforce_result(Result.failure(MESSAGES["cleaning.folder.scan_failed"].format(path=folder_path, reason=exc)))

def clean_folder(folder_path: Path | str, skipped_dirs: Optional[Iterable[str]] = None) -> Result[None]:
    path: Path = Path(folder_path)
    ValidateFolder(path, required=True)
    
    try:
        if path is None:
            return Result.success(None)

        if path.resolve() == Path("/"):
            return enforce_result(Result.failure(MESSAGES["cleaning.root_refused"], action=stop))

        cleaner = FolderCleaner(skipped_dirs)
        result = cleaner._start_removing(path)
        if not result.ok:
            return result
        return Result.success(None)
    except Exception as exc:
        return enforce_result(Result.failure(MESSAGES["cleaning.folder.scan_failed"].format(path=path, reason=exc)))