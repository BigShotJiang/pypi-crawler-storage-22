from __future__ import annotations


class AppError(Exception):
    """Base error type for clevertools."""


class RecoverableError(AppError):
    """Error where the caller can continue or skip."""


class FatalError(AppError):
    """Error where the caller should stop execution."""


class ValidationError(RecoverableError):
    """Validation failed for user input or optional resources."""


class DependencyError(FatalError):
    """Required dependency or core file is missing."""


class ExecutionHaltedError(FatalError):
    """Execution was halted by error handling policy."""