from __future__ import annotations

from ..messages import MESSAGES

__all__ = ["MESSAGES"]