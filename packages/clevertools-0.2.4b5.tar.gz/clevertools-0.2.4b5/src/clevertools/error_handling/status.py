from __future__ import annotations

from typing import Generic, Optional, TypeVar
from dataclasses import dataclass
from enum import Enum, auto

from .exceptions import ExecutionHaltedError

T = TypeVar("T")


class Action(Enum):
    SKIP = auto()
    STOP = auto()


class FailurePolicy(Enum):
    CONTINUE = auto()
    STOP = auto()


_failure_policy: FailurePolicy = FailurePolicy.CONTINUE
_fatal_exception_type: type[Exception] = ExecutionHaltedError


def _normalize_action(action: Action | str) -> Action:
    if isinstance(action, Action):
        return action

    normalized = action.strip().lower()
    mapping = {
        "continue": Action.SKIP,
        "cont": Action.SKIP,
        "skip": Action.SKIP,
        "stop": Action.STOP,
    }
    if normalized in mapping:
        return mapping[normalized]
    raise ValueError(f"Unknown action: {action}")


def _normalize_on_failure(on_failure: FailurePolicy | bool | None) -> FailurePolicy | None:
    if on_failure is None or isinstance(on_failure, FailurePolicy):
        return on_failure
    if isinstance(on_failure, bool):
        return FailurePolicy.CONTINUE if on_failure else FailurePolicy.STOP
    raise ValueError(f"Unknown on_failure value: {on_failure}")


skip: Action = Action.SKIP
stop: Action = Action.STOP


def set_failure_policy(policy: FailurePolicy) -> None:
    global _failure_policy
    _failure_policy = policy


def set_default_fatal_exception(exception_type: type[Exception]) -> None:
    global _fatal_exception_type
    _fatal_exception_type = exception_type


def set_continue_on_failure(should_continue: bool) -> None:
    if should_continue:
        set_failure_policy(FailurePolicy.CONTINUE)
        return
    set_failure_policy(FailurePolicy.STOP)


@dataclass
class Result(Generic[T]):
    ok: bool
    value: Optional[T] = None
    error: Optional[Exception | str] = None
    action: Action = Action.SKIP
    on_failure: Optional[FailurePolicy] = None
    error_type: Optional[type[Exception]] = None

    @classmethod
    def success(cls, value: Optional[T] = None) -> "Result[T]":
        return cls(ok=True, value=value)

    @classmethod
    def failure(cls, error: Exception | str, action: Action | str = Action.SKIP, on_failure: FailurePolicy | bool | None = None, error_type: type[Exception] | None = None) -> "Result[T]":
        return cls(
            ok=False,
            error=error,
            action=_normalize_action(action),
            on_failure=_normalize_on_failure(on_failure),
            error_type=error_type,
        )

    @property
    def message(self) -> str:
        if self.error is None:
            return ""
        return str(self.error)

    @property
    def should_stop(self) -> bool:
        return not self.ok and self.action == Action.STOP

    @property
    def should_skip(self) -> bool:
        return not self.ok and self.action == Action.SKIP


def handle_result(result: Result[T]) -> bool:
    if result.ok:
        return True
    if result.action == Action.STOP:
        return False
    if result.on_failure is not None:
        return result.on_failure == FailurePolicy.CONTINUE
    return _failure_policy == FailurePolicy.CONTINUE


def enforce_result(result: Result[T]) -> Result[T]:
    if handle_result(result):
        return result
    exception_type: type[Exception] = result.error_type or _fatal_exception_type
    if isinstance(result.error, Exception):
        if isinstance(result.error, exception_type):
            raise result.error
        raise exception_type(result.message or "Execution stopped due to failure") from result.error
    raise exception_type(result.message or "Execution stopped due to failure")