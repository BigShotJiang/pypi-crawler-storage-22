from __future__ import annotations

from pathlib import Path
from typing import Dict

from .exceptions import DependencyError, ValidationError
from ..messages import MESSAGES
from .status import Action, FailurePolicy, Result, enforce_result


def _resolve_on_failure(continue_on_failure: bool | None) -> FailurePolicy | None:
    if continue_on_failure is None:
        return None
    return FailurePolicy.CONTINUE if continue_on_failure else FailurePolicy.STOP

class ValidateFile:
    def __init__(
        self,
        FILE_PATH: Path,
        required: bool = False,
        continue_on_failure: bool | None = None,
        missing_message: str | None = None,
        not_file_message: str | None = None,
        error_type: type[Exception] | None = None,
    ) -> None:
        self.FILE_PATH: Path = FILE_PATH
        self.required: bool = required
        self.on_failure: FailurePolicy | None = _resolve_on_failure(continue_on_failure)
        self.missing_message: str | None = missing_message
        self.not_file_message: str | None = not_file_message
        self.error_type: type[Exception] | None = error_type
        self.result: Result[Dict] = self.validate()
        enforce_result(self.result)

    def validate(self) -> Result[Dict]:
        exists_result: Result[Dict] = self.does_file_exist()
        if not exists_result.ok:
            return exists_result

        file_result: Result[Dict] = self.is_file()
        if not file_result.ok:
            return file_result

        return Result.success()

    def does_file_exist(self) -> Result[Dict]:
        if not self.FILE_PATH.exists():
            message: str = self.missing_message or MESSAGES["validation.file_missing"].format(path=self.FILE_PATH)
            if self.required:
                return Result.failure(DependencyError(message), action=Action.STOP, error_type=self.error_type)
            return Result.failure(ValidationError(message), action=Action.SKIP, on_failure=self.on_failure, error_type=self.error_type)
        return Result.success()

    def is_file(self) -> Result[Dict]:
        if not self.FILE_PATH.is_file():
            message: str = self.not_file_message or MESSAGES["validation.file_not_file"].format(path=self.FILE_PATH)
            if self.required:
                return Result.failure(DependencyError(message), action=Action.STOP, error_type=self.error_type)
            return Result.failure(ValidationError(message), action=Action.SKIP, on_failure=self.on_failure, error_type=self.error_type)
        return Result.success()

class ValidateFolder:
    def __init__(
        self,
        FOLDER_PATH: Path,
        required: bool = False,
        continue_on_failure: bool | None = None,
        missing_message: str | None = None,
        not_dir_message: str | None = None,
        error_type: type[Exception] | None = None,
    ) -> None:
        self.FOLDER_PATH: Path = FOLDER_PATH
        self.required: bool = required
        self.on_failure: FailurePolicy | None = _resolve_on_failure(continue_on_failure)
        self.missing_message: str | None = missing_message
        self.not_dir_message: str | None = not_dir_message
        self.error_type: type[Exception] | None = error_type
        self.result: Result[Dict] = self.validate()
        enforce_result(self.result)

    def validate(self) -> Result[Dict]:
        exists_result: Result[Dict] = self.does_folder_exist()
        if not exists_result.ok:
            return exists_result

        folder_result: Result[Dict] = self.is_folder()
        if not folder_result.ok:
            return folder_result

        return Result.success()

    def does_folder_exist(self) -> Result[Dict]:
        if not self.FOLDER_PATH.exists():
            message: str = self.missing_message or MESSAGES["validation.folder_missing"].format(path=self.FOLDER_PATH)
            if self.required:
                return Result.failure(DependencyError(message), action=Action.STOP, error_type=self.error_type)
            return Result.failure(ValidationError(message), action=Action.SKIP, on_failure=self.on_failure, error_type=self.error_type)
        return Result.success()

    def is_folder(self) -> Result[Dict]:
        if not self.FOLDER_PATH.is_dir():
            message: str = self.not_dir_message or MESSAGES["validation.folder_not_dir"].format(path=self.FOLDER_PATH)
            if self.required:
                return Result.failure(DependencyError(message), action=Action.STOP, error_type=self.error_type)
            return Result.failure(ValidationError(message), action=Action.SKIP, on_failure=self.on_failure, error_type=self.error_type)
        return Result.success()