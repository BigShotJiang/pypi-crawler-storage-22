from __future__ import annotations

from pathlib import Path
from ..error_handling.validation import ValidateFile, ValidateFolder
from ..error_handling.status import Result, enforce_result
from ..messages import MESSAGES

def create_file(file_path: Path | str) -> Result[None]:
    path: Path = Path(file_path)

    try:
        if path.exists():
            ValidateFile(path, required=True)
            print(MESSAGES["file_handling.create.exists"].format(path=path))
        else:
            if not path.parent.exists():
                return enforce_result(Result.failure(MESSAGES["file_handling.create.parent_missing"].format(path=path.parent)))
            path.touch(exist_ok=True)
            print(MESSAGES["file_handling.create.created"].format(path=path))

        return Result.success(None)
    except Exception as exc:
        return enforce_result(Result.failure(MESSAGES["file_handling.create.failed"].format(path=path, reason=exc)))

def create_folder(folder_path: Path | str) -> Result[None]:
    path: Path = Path(folder_path)
    
    try:
        if not path.exists():
            path.mkdir(parents=True, exist_ok=True)
            print(MESSAGES["file_handling.create.created"].format(path=path))
        else:
            print(MESSAGES["file_handling.create.exists"].format(path=path))
        
        ValidateFolder(path, required=True)
        return Result.success(None)
    except Exception as exc:
        return enforce_result(Result.failure(MESSAGES["file_handling.create_folder.failed"].format(path=path, reason=exc)))
