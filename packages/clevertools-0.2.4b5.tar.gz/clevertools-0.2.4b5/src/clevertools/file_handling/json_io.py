from __future__ import annotations

from typing import Dict, Any
from pathlib import Path
import json

from ..error_handling.validation import ValidateFile
from ..error_handling.status import Result, enforce_result, skip
from ..messages import MESSAGES

def read_json(file_path: Path | str) -> Result[Dict[Any, Any]]:
    path: Path = Path(file_path)
    ValidateFile(path, required=True)

    try:
        with path.open("r", encoding="utf-8") as f:
            return Result.success(json.load(f))
    except (OSError, json.JSONDecodeError) as exc:
        return enforce_result(Result.failure(MESSAGES["io.json.read_failed"].format(path=path, reason=exc), action=skip))

def write_json(file_path: Path | str, data: Any) -> Result[None]:
    path = Path(file_path)

    try:
        with path.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        return Result.success(None)
    except (OSError, TypeError, ValueError) as exc:
        return enforce_result(Result.failure(MESSAGES["io.json.write_failed"].format(path=path, reason=exc), action=skip))