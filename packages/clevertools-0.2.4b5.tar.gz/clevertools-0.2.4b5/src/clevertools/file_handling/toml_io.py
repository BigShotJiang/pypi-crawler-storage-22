from __future__ import annotations

from typing import Dict, Any
from pathlib import Path
import tomli_w
import tomllib

from ..error_handling.validation import ValidateFile
from ..error_handling.status import Action, FailurePolicy, Result, enforce_result, skip
from ..messages import MESSAGES

class TomlResult(Result[Dict[Any, Any]]):
    @classmethod
    def success(cls, value: Dict[Any, Any] | None = None) -> "TomlResult":
        return cls(ok=True, value=value)

    @classmethod
    def failure(cls, error: Exception | str, action: Action | str = "skip", on_failure: FailurePolicy | bool | None = None, error_type: type[Exception] | None = None) -> "TomlResult":
        base = Result.failure(error=error, action=action, on_failure=on_failure, error_type=error_type)
        return cls(ok=base.ok, value=base.value, error=base.error, action=base.action, on_failure=base.on_failure, error_type=base.error_type)

    def get(self, key: Any, default: Any = None) -> Any:
        if not self.ok or not isinstance(self.value, dict):
            return default

        if not isinstance(key, str) or "." not in key:
            return self.value.get(key, default)

        if key in self.value:
            return self.value.get(key, default)

        current: Any = self.value
        for part in key.split("."):
            if not isinstance(current, dict) or part not in current:
                return default
            current = current[part]

        return current

def read_toml(file_path: Path | str) -> TomlResult:
    path: Path = Path(file_path)
    ValidateFile(path, required=True)

    try:
        with path.open("rb") as f:
            return TomlResult.success(tomllib.load(f))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        result = TomlResult.failure(MESSAGES["io.toml.read_failed"].format(path=path, reason=exc), action=skip)
        enforce_result(result)
        return result

def write_toml(file_path: Path | str, data: Any) -> Result[None]:
    path = Path(file_path)
    
    try:

        with path.open("wb") as f:
            tomli_w.dump(data, f)
        return Result.success(None)
    except (ModuleNotFoundError, OSError, TypeError, ValueError) as exc:
        return enforce_result(Result.failure(MESSAGES["io.toml.write_failed"].format(path=path, reason=exc), action=skip))