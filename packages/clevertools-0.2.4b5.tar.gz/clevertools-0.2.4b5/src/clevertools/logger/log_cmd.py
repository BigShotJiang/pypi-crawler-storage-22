from __future__ import annotations

from ..error_handling.status import Result, enforce_result
from ..messages import MESSAGES

def log(process: str, level: str, message: str) -> Result[None]:
    try:
        level = (level or "INFO").upper()
        print(MESSAGES["logger.line"].format(process=process, level=level, message=message))
        return Result.success(None)
    except Exception as exc:
        return enforce_result(Result.failure(MESSAGES["logger.failed"].format(process=process, reason=exc)))