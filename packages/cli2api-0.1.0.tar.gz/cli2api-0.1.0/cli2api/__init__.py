"""CLI2API - OpenAI-compatible API over CLI tools."""

__version__ = "0.1.0"
