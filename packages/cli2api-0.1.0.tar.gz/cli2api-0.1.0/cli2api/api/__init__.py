"""API module with FastAPI routers."""

from cli2api.api.router import api_router

__all__ = ["api_router"]
