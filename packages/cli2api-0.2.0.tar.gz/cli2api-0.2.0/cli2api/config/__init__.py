"""Configuration module."""

from cli2api.config.settings import Settings

__all__ = ["Settings"]
