"""Service layer for business logic."""

from cli2api.services.completion import CompletionService

__all__ = ["CompletionService"]
