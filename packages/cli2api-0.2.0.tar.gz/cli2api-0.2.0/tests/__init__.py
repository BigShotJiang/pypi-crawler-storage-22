"""Tests for CLI2API."""
