# Add Get Scores Command

## Prompt
Take a look at this file. I have laid out a concept that we need implemented into this project. Please implement the concept as described in the file. If you have any questions about the concept, please ask me for clarification before implementing.
Use this file to takes notes for the entire process of implementing the concept. This file should be used to keep track of the implementation process, and to document any decisions that were made along the way. This file should also be used to document any challenges that were encountered, and how they were overcome. This file should be used to document the final implementation of the concept, including any code that was written, and any tests that were created. This file should be used to document any future work that could be done on this concept, and any potential improvements that could be made.
The only sections I don't want updated are the "Prompt" and "Original Concept".
Don't create a new file for notes. Add sections at the bottom of this file.

## Original Concept
- Add a `scores` command to the CLI that prints the current highscores games.
  - without a tag will return all highscores in a pretty print
  - optional game tag using index or game name (like the run command)
  - optional `raw` tag that will return a raw json as string.

## Implementation Notes

### Process Overview
- Reviewed the concept and requirements for the `scores` command.
- Located CLI entrypoint and subcommand structure in cli.py.
- Located highscores logic in game_classes/highscores.py.
- Designed the command to support:
  - No tag: pretty print all games' highscores.
  - Game tag (index or name): pretty print specific game's highscores.
  - --raw: output JSON for all or specific game.

### Decisions
- Used argparse for command parsing, consistent with other CLI commands.
- Used existing game discovery logic for game name/index resolution.
- Used HighScores class for loading scores.
- Pretty print format matches other CLI output styles.
- Raw output uses json.dumps for easy integration.

### Challenges
- Ensured robust handling of game name/index resolution (exact, substring, index).
- Maintained backward compatibility with existing CLI structure.
- Avoided code duplication by reusing game discovery and HighScores logic.

### Final Implementation
- Added 'scores' subcommand to CLI parser.
- Implemented logic in main() to handle all required options.
- Used pretty_print_scores() for formatted output.
- Used json.dumps for raw output.

#### Key Code (cli.py)
```
# Add scores command
scoresp = sub.add_parser(
    'scores',
    help='Show highscores for games',
    description='Print highscores for all games or a specific game. Optionally output raw JSON.',
    epilog='Examples:\n  %(prog)s scores\n  %(prog)s scores 0\n  %(prog)s scores "Byte Bouncer"\n  %(prog)s scores --raw\n',
    formatter_class=argparse.RawDescriptionHelpFormatter,
)
scoresp.add_argument('game', nargs='?', help='Optional game name or zero-based index')
scoresp.add_argument('--raw', action='store_true', help='Output raw JSON string')

if args.cmd == 'scores':
    import json
    from game_classes.highscores import HighScores
    ... # see full implementation in cli.py
```

### Testing
- Manual testing via CLI:
  - `python cli.py scores` (all games, pretty print)
  - `python cli.py scores 0` (first game, pretty print)
  - `python cli.py scores "Byte Bouncer"` (named game, pretty print)
  - `python cli.py scores --raw` (all games, raw JSON)
  - `python cli.py scores 0 --raw` (first game, raw JSON)

### Future Work & Improvements
- Add unit tests for scores command logic.
- Support filtering or sorting highscores.
- Add option to export scores to file.
- Improve pretty print formatting for more details.
- Handle empty or missing highscores gracefully.

### Summary
The scores command is now implemented as described, supporting all required options and output formats. The CLI is consistent and robust, and future improvements can be easily integrated.

---

## Prompt (2026-02-05)
Take notes. every prompt

### Action Taken
- Updated the pretty print logic in the CLI to iterate through all keys in each game's highscore JSON, displaying every entry (not just 'score').
- Now, for each key (e.g., 'score', 'level', or any custom key), the CLI prints the player and value if present, or the raw value otherwise.
- This ensures all highscore data types are shown for each game, matching the flexible JSON structure.

### Next Steps
- Continue to document each prompt and implementation change in this section.

### Update (2026-02-05)
- The CLI `scores` handler was updated to use `get_saved_highscores()` from `game_classes/highscores.py` so output reflects actual saved files (no injected defaults). Notes updated to reflect this.
