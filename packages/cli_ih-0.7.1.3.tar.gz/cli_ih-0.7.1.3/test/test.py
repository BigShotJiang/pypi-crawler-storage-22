import time
import cli_ih, cli_ih.exceptions, asyncio
from cli_ih import safe_print as print
import logging

print("CLI-IH Version:", cli_ih.__version__)

handler = cli_ih.AsyncInputHandler()

@handler.command(name="log", description="Logs a message")
async def log_cmd(msg):
    print(f"User logged: {msg}")

handler.start()

# Simulate background logs
def background_logger():
    count = 0
    while handler.is_running:
        print(f"Background log #{count}")
        count += 1
        time.sleep(2)

print("Starting handler. Type something. Background logs will appear every 2s.")
print("The cursor and your current input should be preserved at the bottom.")

background_logger()