from . import main  # Change from absolute to relative import

if __name__ == "__main__":
    main()
