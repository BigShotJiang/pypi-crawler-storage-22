# GBP

La libreria permite realizar operaciones en Global Blue Point (GBP)mediante HTTP. Sin utilizar interfaz gráfica (Scraping). Usando las credenciales de una cuenta, se obtiene las cookies de sesión y se pueden realizar operaciones. Se realiza todo de manera sincrona.

