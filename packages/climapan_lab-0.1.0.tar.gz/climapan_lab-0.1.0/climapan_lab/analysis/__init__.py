"""
CliMaPan-Lab Analysis Module

This package contains tools for model validation, sensitivity analysis, and results inspection.
"""

__version__ = "1.0.0"
