"""
CliMaPan-Lab Documentation

This package contains documentation files and UML diagrams.
"""
