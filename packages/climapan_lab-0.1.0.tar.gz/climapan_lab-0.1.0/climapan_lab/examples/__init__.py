"""
CliMaPan-Lab Examples

This package contains example scripts and notebooks demonstrating
how to use the CliMaPan-Lab modeling framework.
"""
