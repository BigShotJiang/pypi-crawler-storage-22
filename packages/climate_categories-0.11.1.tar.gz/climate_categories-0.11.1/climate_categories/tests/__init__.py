"""Unit test package for climate_categories."""
