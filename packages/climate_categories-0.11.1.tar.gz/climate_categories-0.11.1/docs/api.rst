===
API
===
Module contents
===============

.. automodule:: climate_categories
   :members:
   :show-inheritance:


climate\_categories.search module
---------------------------------

.. automodule:: climate_categories.search
   :members:
