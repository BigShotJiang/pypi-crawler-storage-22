Welcome to climate_category's documentation!
============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   usage
   api
   data
   contributing
   credits
   changelog

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
