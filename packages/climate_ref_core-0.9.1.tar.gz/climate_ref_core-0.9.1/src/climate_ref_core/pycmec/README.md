CMEC python implementation (pycmec)
