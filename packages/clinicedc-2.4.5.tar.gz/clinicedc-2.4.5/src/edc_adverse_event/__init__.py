# from importlib.metadata import version
#
# __version__ = version("edc_adverse_event")
#
# from .utils import get_ae_model
