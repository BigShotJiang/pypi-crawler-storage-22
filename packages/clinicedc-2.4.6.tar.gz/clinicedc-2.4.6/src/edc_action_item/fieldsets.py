action_fields = (
    "action_identifier",
    "action_item",
    "parent_action_item",
    "related_action_item",
)

action_fieldset_tuple = ("Action", {"classes": ("collapse",), "fields": action_fields})
