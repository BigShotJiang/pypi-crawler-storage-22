"""
Clink MCP Server

MCP server for Clink - powering agentic coordination.
Uses FastMCP from the official MCP Python SDK.
"""

import sys

from mcp.server.fastmcp import FastMCP

from . import tools
from .client import get_config_status, is_configured

# Create the MCP server
mcp = FastMCP("clink-mcp-server")

# Register all tools
tools.register_all(mcp)


def main() -> None:
    """Entry point for the MCP server."""
    # Log startup info to stderr (MCP convention)
    print("Clink MCP Server starting...", file=sys.stderr)

    if not is_configured():
        print(f"Warning: {get_config_status()}", file=sys.stderr)
    else:
        print("API key configured", file=sys.stderr)

    # Run the server with stdio transport
    mcp.run()


if __name__ == "__main__":
    main()
