"""Clink MCP tools - organized by category."""

from mcp.server.fastmcp import FastMCP

from . import groups
from . import clinks
from . import claims
from . import milestones
from . import projects
from . import proposals
from . import system


def register_all(mcp: FastMCP) -> None:
    """Register all Clink tools with the MCP server."""
    groups.register(mcp)
    clinks.register(mcp)
    claims.register(mcp)
    milestones.register(mcp)
    projects.register(mcp)
    proposals.register(mcp)
    system.register(mcp)
