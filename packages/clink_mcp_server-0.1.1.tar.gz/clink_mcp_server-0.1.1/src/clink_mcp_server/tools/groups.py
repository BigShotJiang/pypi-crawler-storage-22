"""Group-related tools: list_groups, list_members."""

from mcp.server.fastmcp import FastMCP

from .. import client
from ..types import ClinkApiError


def register(mcp: FastMCP) -> None:
    """Register group tools with the MCP server."""

    @mcp.tool()
    async def list_groups() -> str:
        """List all Clink groups you belong to. Returns group slugs, names, descriptions, and your role in each."""
        try:
            groups = await client.list_groups()

            if not groups:
                return "You are not a member of any groups yet. Create a group at https://app.clink.voxos.ai or ask someone to invite you."

            lines = []
            for g in groups:
                role = f" ({g.role})" if g.role else ""
                desc = f" - {g.description}" if g.description else ""
                lines.append(f'* {g.slug}{role}{desc}\n  Name: "{g.name}"')

            return f"Your groups ({len(groups)}):\n\n" + "\n\n".join(lines)
        except ClinkApiError as e:
            return f"Error: {e}"

    @mcp.tool()
    async def list_members(group: str) -> str:
        """List all members of a Clink group. Shows member names, roles, and when they joined.

        Args:
            group: The group slug (e.g., "backend-team") or group ID
        """
        try:
            if not group:
                groups = await client.list_groups()
                if groups:
                    group_list = "\n".join(f'* {g.slug} - "{g.name}"' for g in groups)
                    return f"Please provide a group slug. Your groups:\n\n{group_list}"
                return "Please provide a group slug. You are not a member of any groups."

            # Resolve slug or ID to group ID
            group_id = await client.resolve_group(group)
            members = await client.list_members(group_id)

            if not members:
                return "This group has no members."

            lines = []
            for m in members:
                role = " (admin)" if m.role == "admin" else ""
                name = m.name or m.email or m.user_id
                joined = m.joined_at[:10] if m.joined_at else "unknown"
                lines.append(f"* {name}{role}\n  Joined: {joined}")

            return f"Group members ({len(members)}):\n\n" + "\n\n".join(lines)
        except ClinkApiError as e:
            return f"Error: {e}"
