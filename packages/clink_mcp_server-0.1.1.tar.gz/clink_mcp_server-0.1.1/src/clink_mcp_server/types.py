"""Clink API type definitions as Pydantic models."""

from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, Field


# Status types
ClinkStatus = Literal["pending", "claimed", "completed"]
MilestoneStatus = Literal["active", "closed"]
CheckpointStatus = Literal["pending", "completed"]
ProjectStatus = Literal["active", "completed", "archived"]
VotingType = Literal["single", "yes_no", "ranked"]
ThresholdType = Literal["majority", "two_thirds", "unanimous", "quorum"]
ProposalStatus = Literal["open", "finalized"]
FeedbackCategory = Literal["bug", "feature", "improvement", "other"]
VerificationTargetType = Literal["checkpoint", "vote"]
VerificationStatus = Literal["pending", "expired", "verified"]


# Group types
class Group(BaseModel):
    """A Clink group."""

    group_id: str
    name: str
    slug: str
    description: str
    owner_id: str
    role: Optional[str] = None
    created_at: str
    updated_at: Optional[str] = None


# Member types
class Member(BaseModel):
    """A group member."""

    user_id: str
    name: str
    email: Optional[str] = None
    role: str
    member_type: Optional[str] = None
    joined_at: str


# Clink types
class Clink(BaseModel):
    """A clink message."""

    clink_id: str
    group_id: str
    group_name: Optional[str] = None
    group_slug: Optional[str] = None
    sender_id: str
    sender_name: str
    content: str
    created_at: str
    status: ClinkStatus
    claimed_by: Optional[str] = None
    claimed_at: Optional[str] = None
    claim_expires_at: Optional[str] = None
    completed_by: Optional[str] = None
    completed_at: Optional[str] = None
    for_: Optional[str] = Field(default=None, alias="for")

    model_config = {"populate_by_name": True}


class ClaimResponse(BaseModel):
    """Response from claiming a clink."""

    clink_id: str
    status: ClinkStatus
    claimed_by: str
    claimed_at: str
    claim_expires_at: str


class ReleaseResponse(BaseModel):
    """Response from releasing a clink."""

    clink_id: str
    status: ClinkStatus


class CompleteResponse(BaseModel):
    """Response from completing a clink."""

    clink: Clink
    response_clink_id: Optional[str] = None


# User types
class User(BaseModel):
    """A Clink user."""

    user_id: str
    email: str
    name: str
    picture: Optional[str] = None
    subscription_tier: Optional[str] = None
    has_api_key: Optional[bool] = None
    created_at: str


# Checkpoint types
class Checkpoint(BaseModel):
    """A milestone checkpoint."""

    order: int
    title: str
    description: str
    status: CheckpointStatus
    completed_by: Optional[str] = None
    completed_at: Optional[str] = None
    requires_proposal_id: Optional[str] = None
    proposal_status: Optional[str] = None
    depends_on: Optional[list[int | str]] = None
    git_branch_url: Optional[str] = None
    git_pr_url: Optional[str] = None
    git_commit_url: Optional[str] = None


# Milestone types
class Milestone(BaseModel):
    """A milestone with checkpoints."""

    milestone_id: str
    group_id: str
    project_id: Optional[str] = None
    title: str
    description: str
    status: MilestoneStatus
    created_by: str
    created_at: str
    updated_at: Optional[str] = None
    closed_at: Optional[str] = None
    total_checkpoints: int
    completed_checkpoints: int
    progress: str
    checkpoints: Optional[list[Checkpoint]] = None


# Project types
class Project(BaseModel):
    """A project that organizes milestones."""

    project_id: str
    group_id: str
    title: str
    description: str
    slug: str
    color: str
    status: ProjectStatus
    is_default: bool
    created_by: Optional[str] = None
    created_at: str
    updated_at: Optional[str] = None
    completed_at: Optional[str] = None
    completed_by: Optional[str] = None
    archived_at: Optional[str] = None
    archived_by: Optional[str] = None
    reopened_at: Optional[str] = None
    reopened_by: Optional[str] = None


# Vote types
class Vote(BaseModel):
    """A vote on a proposal."""

    voter_id: str
    vote: str
    comment: str
    voted_at: str


# Proposal types
class Proposal(BaseModel):
    """A voting proposal."""

    proposal_id: str
    group_id: str
    title: str
    description: str
    proposer_id: str
    voting_type: VotingType
    threshold_type: ThresholdType
    options: list[str]
    status: ProposalStatus
    created_at: str
    deadline: Optional[str] = None
    finalized_at: Optional[str] = None
    result: Optional[str] = None
    threshold_met: Optional[bool] = None
    votes: Optional[list[Vote]] = None
    vote_count: Optional[int] = None
    tally: Optional[dict[str, int]] = None
    linked_milestone_id: Optional[str] = None
    linked_checkpoint_order: Optional[int] = None


# Feedback types
class FeedbackResponse(BaseModel):
    """Response from submitting feedback."""

    feedback_id: str
    category: FeedbackCategory
    submitted_at: str


# Permission types
class PermissionInfo(BaseModel):
    """Information about a permission."""

    granted: bool
    description: str


class PermissionsResponse(BaseModel):
    """Response from getting permissions."""

    permissions: dict[str, bool]
    permissions_info: dict[str, PermissionInfo]
    scope_type: Literal["user", "group"]
    scope_id: str
    owner_type: Literal["user", "agent_profile"]


# HIL (Human-in-the-Loop) types
class HILRequiredResponse(BaseModel):
    """Response indicating HIL verification is required."""

    verification_required: Literal[True]
    verification_id: str
    verification_status: Optional[Literal["new", "pending"]] = None
    expires_in_seconds: Optional[int] = None
    expires_at: Optional[str] = None
    sent_to: Optional[list[str]] = None
    message: str
    previous_verification_expired: Optional[bool] = None


# Pending Verification types
class PendingVerification(BaseModel):
    """A pending HIL verification."""

    verification_id: str
    target_type: VerificationTargetType
    status: VerificationStatus
    expires_at: str
    requested_by: str
    requester_name: Optional[str] = None
    requested_at: str
    group_id: str
    group_name: Optional[str] = None
    milestone_id: Optional[str] = None
    checkpoint_order: Optional[int] = None
    milestone_title: Optional[str] = None
    checkpoint_title: Optional[str] = None
    proposal_id: Optional[str] = None
    proposal_title: Optional[str] = None
    voting_type: Optional[VotingType] = None
    proposal_options: Optional[list[str]] = None


# Error types
class ClinkApiError(Exception):
    """Error from the Clink API."""

    def __init__(self, message: str, status_code: int, details: Optional[str] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details

    def __str__(self) -> str:
        if self.details:
            return f"{self.message}: {self.details}"
        return self.message


def is_hil_required(response: dict) -> bool:
    """Check if a response indicates HIL verification is required."""
    return (
        isinstance(response, dict)
        and response.get("verification_required") is True
    )
