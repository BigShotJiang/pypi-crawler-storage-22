# about.py

__version__ = "0.1.2"
__package__ = "clipboard_tts_client"
__program_name__ = "clipboard-tts-indicator"
__author__ = "Fernando Pujaico Rivera" 
__email__  = "fernando.pujaico.rivera@gmail.com"
__description__ = "Program that collects text from clipboard and converts it to speech using tts-program-server"
__url_source__  = "https://github.com/trucomanx/ClipboardTTSClient"
__url_doc__     = "https://github.com/trucomanx/ClipboardTTSClient/doc"
__url_funding__ = "https://trucomanx.github.io/en/funding.html"
__url_bugs__    = "https://github.com/trucomanx/ClipboardTTSClient/issues"
