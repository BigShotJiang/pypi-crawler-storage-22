import argparse
import sys

from clipkly.core import limpiar_video, procesar_clips
from clipkly.version import __version__


def cmd_clips(args):
    """Subcomando para generar clips desde un video."""
    procesar_clips(
        archivo_json=args.json,
        video_h=args.horizontal,
        video_v=args.vertical,
        offset=args.offset,
        offset_h=args.offset_h,
        categoria=args.filter,
        duracion=args.duracion,
        dry_run=args.dry_run,
        export_zip=args.zip,
        out_dir=args.out_dir,
    )


def cmd_clean(args):
    """Subcomando para limpiar un video removiendo segmentos no deseados."""
    limpiar_video(
        archivo_json=args.json,
        video=args.video,
        out_file=args.output,
        margin=args.margin,
        fade=args.fade,
        dry_run=args.dry_run,
        preview=args.preview,
    )


def main():
    parser = argparse.ArgumentParser(
        prog="clipkly",
        description="Clipkly — Automatiza clips y limpieza de videos desde JSON.",
    )
    parser.add_argument(
        "--version", "-v", action="version",
        version=f"clipkly {__version__}"
    )

    subparsers = parser.add_subparsers(
        dest="command", help="Comandos disponibles")

    # --- Subcomando: clips ---
    clips_parser = subparsers.add_parser(
        "clips", help="Generar clips desde un video usando un JSON de timecodes"
    )
    clips_parser.add_argument(
        "--horizontal", type=str, help="Video horizontal")
    clips_parser.add_argument("--vertical", type=str, help="Video vertical")
    clips_parser.add_argument("--json", type=str,
                              default="clips.json", help="Archivo JSON de clips")
    clips_parser.add_argument("--offset", type=float, default=0.0,
                              help="Offset en segundos para video vertical")
    clips_parser.add_argument("--offset-h", type=float, default=0.0,
                              help="Offset en segundos para video horizontal")
    clips_parser.add_argument("--filter", type=str,
                              help="Filtrar por categoría")
    clips_parser.add_argument("--duracion", type=str, choices=[
                              "muy_corto", "ideal", "largo", "muy_largo"],
                              help="Filtrar por duración")
    clips_parser.add_argument(
        "--dry-run", action="store_true", help="Solo simular")
    clips_parser.add_argument("--zip", action="store_true",
                              help="Exportar .zip con clips")
    clips_parser.add_argument("--out-dir", type=str,
                              default="clips", help="Directorio de salida")
    clips_parser.set_defaults(func=cmd_clips)

    # --- Subcomando: clean ---
    clean_parser = subparsers.add_parser(
        "clean", help="Limpiar un video removiendo segmentos no deseados"
    )
    clean_parser.add_argument("--video", type=str, required=True,
                              help="Ruta al video fuente")
    clean_parser.add_argument("--json", type=str, required=True,
                              help="Archivo JSON con cortes_sugeridos")
    clean_parser.add_argument("--output", "-o", type=str, default=None,
                              help="Ruta del video de salida (default: <nombre>_limpio.mp4)")
    clean_parser.add_argument("--margin", type=float, default=0.0,
                              help="Segundos de margen extra en cada corte")
    clean_parser.add_argument("--fade", type=float, default=0.0,
                              help="Segundos de crossfade entre segmentos (0 = sin fade)")
    clean_parser.add_argument("--dry-run", action="store_true",
                              help="Solo mostrar comandos sin ejecutar")
    clean_parser.add_argument("--preview", action="store_true",
                              help="Solo generar reporte sin procesar video")
    clean_parser.set_defaults(func=cmd_clean)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
