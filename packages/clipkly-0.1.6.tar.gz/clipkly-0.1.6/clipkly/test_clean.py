# test_clean.py — Tests para la funcionalidad de limpieza de video

import json
import os
import tempfile

from clipkly.core import (hhmmss_to_sec, invertir_rangos, limpiar_video,
                          sec_to_hhmmss)


def test_invertir_rangos_basico():
    """Cortes al inicio y en medio → conserva el resto."""
    cortes = [
        {"inicio": "00:00:00", "final": "00:11:30"},
        {"inicio": "00:36:45", "final": "00:38:20"},
    ]
    duracion_total = 7200.0  # 2 horas

    rangos = [(hhmmss_to_sec(c["inicio"]), hhmmss_to_sec(c["final"]))
              for c in cortes]
    resultado = invertir_rangos(cortes, duracion_total)

    # Esperado: (11:30 → 36:45), (38:20 → 2:00:00)
    assert len(resultado) == 2
    assert resultado[0] == (hhmmss_to_sec("00:11:30"),
                            hhmmss_to_sec("00:36:45"))
    assert resultado[1] == (hhmmss_to_sec("00:38:20"), 7200.0)
    print("✅ test_invertir_rangos_basico OK")


def test_invertir_rangos_sin_corte_inicial():
    """Corte solo en medio → conserva inicio y final."""
    cortes = [
        {"inicio": "00:10:00", "final": "00:20:00"},
    ]
    duracion_total = 3600.0

    resultado = invertir_rangos(cortes, duracion_total)

    assert len(resultado) == 2
    assert resultado[0] == (0.0, 600.0)
    assert resultado[1] == (1200.0, 3600.0)
    print("✅ test_invertir_rangos_sin_corte_inicial OK")


def test_invertir_rangos_corte_total():
    """Si se corta todo el video, no queda nada."""
    cortes = [
        {"inicio": "00:00:00", "final": "01:00:00"},
    ]
    duracion_total = 3600.0

    resultado = invertir_rangos(cortes, duracion_total)

    assert len(resultado) == 0
    print("✅ test_invertir_rangos_corte_total OK")


def test_invertir_rangos_solapados():
    """Cortes solapados se fusionan."""
    cortes = [
        {"inicio": "00:05:00", "final": "00:15:00"},
        {"inicio": "00:10:00", "final": "00:20:00"},
    ]
    duracion_total = 3600.0

    resultado = invertir_rangos(cortes, duracion_total)

    # Fusionado: (5:00 → 20:00) → conserva (0→5:00) y (20:00→final)
    assert len(resultado) == 2
    assert resultado[0] == (0.0, 300.0)
    assert resultado[1] == (1200.0, 3600.0)
    print("✅ test_invertir_rangos_solapados OK")


def test_invertir_rangos_sin_cortes():
    """Sin cortes → se conserva todo."""
    cortes = []
    duracion_total = 3600.0

    resultado = invertir_rangos(cortes, duracion_total)

    assert len(resultado) == 1
    assert resultado[0] == (0.0, 3600.0)
    print("✅ test_invertir_rangos_sin_cortes OK")


def test_invertir_rangos_corte_al_final():
    """Corte al final del video."""
    cortes = [
        {"inicio": "00:50:00", "final": "01:00:00"},
    ]
    duracion_total = 3600.0

    resultado = invertir_rangos(cortes, duracion_total)

    assert len(resultado) == 1
    assert resultado[0] == (0.0, 3000.0)
    print("✅ test_invertir_rangos_corte_al_final OK")


def test_limpiar_video_preview():
    """Preview mode: genera reporte sin procesar video."""
    # Crear JSON temporal
    data = {
        "cortes_sugeridos": [
            {"inicio": "00:00:00", "final": "00:11:30", "razon": "Intro"},
            {"inicio": "00:36:45", "final": "00:38:20", "razon": "Off-topic"},
        ]
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, encoding="utf-8") as f:
        json.dump(data, f)
        json_path = f.name

    try:
        result = limpiar_video(
            archivo_json=json_path,
            video="fake_video.mp4",
            preview=True,
        )
        assert result["video"] is None
        assert len(result["segmentos_conservados"]) == 2
        assert len(result["segmentos_removidos"]) == 2
        assert result["duracion_removida"] > 0
        print("✅ test_limpiar_video_preview OK")
    finally:
        os.remove(json_path)


if __name__ == "__main__":
    test_invertir_rangos_basico()
    test_invertir_rangos_sin_corte_inicial()
    test_invertir_rangos_corte_total()
    test_invertir_rangos_solapados()
    test_invertir_rangos_sin_cortes()
    test_invertir_rangos_corte_al_final()
    test_limpiar_video_preview()
    print("\n🎉 Todos los tests pasaron correctamente!")
    print("\n🎉 Todos los tests pasaron correctamente!")
    print("\n🎉 Todos los tests pasaron correctamente!")
    print("\n🎉 Todos los tests pasaron correctamente!")
