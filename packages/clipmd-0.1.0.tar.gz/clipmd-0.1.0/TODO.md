# TODO

- commit and push all changes to clipmd feat/phase-1-project-setup branch

- merge clipmd pr and publish it on pypi

- add dependabot and default gh config to new gh repos @github @opensource-projects @englog @spotfm
