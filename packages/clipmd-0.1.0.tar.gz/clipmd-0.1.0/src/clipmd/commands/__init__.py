"""CLI commands for clipmd."""
