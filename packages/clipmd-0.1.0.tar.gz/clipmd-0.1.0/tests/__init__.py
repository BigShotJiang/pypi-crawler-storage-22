"""Tests for clipmd."""
