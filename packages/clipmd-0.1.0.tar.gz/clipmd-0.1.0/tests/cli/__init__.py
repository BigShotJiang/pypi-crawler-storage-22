"""CLI tests for clipmd."""
