"""Integration tests for clipmd."""
