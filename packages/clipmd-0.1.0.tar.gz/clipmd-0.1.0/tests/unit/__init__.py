"""Unit tests for clipmd."""
