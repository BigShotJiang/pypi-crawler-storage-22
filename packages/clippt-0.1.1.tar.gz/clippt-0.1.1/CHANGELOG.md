# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.1] - 2026-02-15

### Added
- Click-based CLI application (`clippt` command)
- Shell integration and support
- Example presentations
- `--continue` flag for resuming presentations
- Path support in slide definitions

### Changed
- Initial release with core slideshow functionality
