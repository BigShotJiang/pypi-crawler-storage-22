-- Drop common functions
DROP FUNCTION IF EXISTS update_timestamp();
DROP FUNCTION IF EXISTS soft_delete();
