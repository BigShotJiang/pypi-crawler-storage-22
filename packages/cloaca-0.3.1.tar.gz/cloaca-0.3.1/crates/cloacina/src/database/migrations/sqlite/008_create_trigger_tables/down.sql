-- SQLite migration: Drop trigger tables

DROP TABLE IF EXISTS trigger_executions;
DROP TABLE IF EXISTS trigger_schedules;
