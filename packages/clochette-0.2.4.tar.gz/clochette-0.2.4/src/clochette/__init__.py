import logging
from logging import Logger

log: Logger = logging.getLogger("Clochette")
