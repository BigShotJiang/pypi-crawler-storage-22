from reactivex.scheduler import ThreadPoolScheduler

scheduler = ThreadPoolScheduler(16)
