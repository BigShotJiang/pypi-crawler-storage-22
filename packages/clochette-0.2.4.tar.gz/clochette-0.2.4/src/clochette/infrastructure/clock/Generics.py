from datetime import date, datetime
from typing import TypeVar

DateOrDatetimeType = TypeVar("DateOrDatetimeType", date, datetime)
