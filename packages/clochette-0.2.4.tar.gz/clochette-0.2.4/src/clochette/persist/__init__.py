from peewee import SqliteDatabase

db = SqliteDatabase(None)  # Un-initialized database.
