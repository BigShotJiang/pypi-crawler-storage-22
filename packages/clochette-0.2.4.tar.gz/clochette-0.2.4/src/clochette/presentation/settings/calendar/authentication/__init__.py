# Authentication configuration components
