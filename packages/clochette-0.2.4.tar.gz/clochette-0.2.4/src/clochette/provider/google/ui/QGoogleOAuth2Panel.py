from clochette.provider.google.dto.GoogleCalendar import GoogleCalendar
from clochette.provider.shared.ui.QOAuth2Panel import QOAuth2Panel


class QGoogleOAuth2Panel(QOAuth2Panel[GoogleCalendar]):
    pass
