from clochette.provider.microsoft.dto.MicrosoftCalendar import MicrosoftCalendar
from clochette.provider.shared.ui.QOAuth2Panel import QOAuth2Panel


class QMicrosoftOAuth2Panel(QOAuth2Panel[MicrosoftCalendar]):
    pass
