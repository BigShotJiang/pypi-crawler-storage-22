import sys
from .ct import O, I, E
from .err import CE

try:
    from ._cld_nat import ffi, lib
except ImportError:
    ffi = lib = None

class C:
    def __init__(self):
        if lib is None:
            raise CE("Native library not found. Install libcurl.")
        
        self._handle = lib.cld_init()
        if self._handle == ffi.NULL:
            raise CE("Failed to initialize curl")
        
        self._callbacks = {}
        self._headers = None
        self._closed = False
        
    def __enter__(self):
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        
    def __del__(self):
        if not self._closed and hasattr(self, '_handle'):
            self.close()
    
    def setopt(self, option, value):
        if self._closed:
            raise CE("Handle is closed")
            
        code = lib.cld_setopt(self._handle, option, value)
        if code != E.OK:
            raise CE(f"Failed to set option {option}: {E.to_str(code)}")
        
        return self
    
    def getinfo(self, option):
        if self._closed:
            raise CE("Handle is closed")
            
        if option & 0xF00000 == 0x100000:
            result = ffi.new("char**")
            lib.cld_getinfo(self._handle, option, result)
            return ffi.string(result[0]).decode() if result[0] else ""
        elif option & 0xF00000 == 0x200000:
            result = ffi.new("long*")
            lib.cld_getinfo(self._handle, option, result)
            return int(result[0])
        elif option & 0xF00000 == 0x300000:
            result = ffi.new("double*")
            lib.cld_getinfo(self._handle, option, result)
            return float(result[0])
        return None
    
    def perform(self):
        if self._closed:
            raise CE("Handle is closed")
            
        code = lib.cld_perform(self._handle)
        if code != E.OK:
            raise CE(f"Perform failed: {E.to_str(code)}")
    
    def reset(self):
        if not self._closed:
            lib.cld_reset(self._handle)
        return self
    
    def close(self):
        if not self._closed and hasattr(self, '_handle'):
            if self._handle != ffi.NULL:
                lib.cld_cleanup(self._handle)
            self._handle = ffi.NULL
            self._closed = True
            self._callbacks.clear()
            self._headers = None