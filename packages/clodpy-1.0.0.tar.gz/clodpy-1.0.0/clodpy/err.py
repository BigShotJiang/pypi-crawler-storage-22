class CE(Exception):
    pass