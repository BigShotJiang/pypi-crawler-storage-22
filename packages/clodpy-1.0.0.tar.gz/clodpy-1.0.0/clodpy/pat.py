import sys

def fix():
    from . import cl
    sys.modules["curl"] = sys.modules["pycurl"] = sys.modules["clodpy.pat"]
    return True