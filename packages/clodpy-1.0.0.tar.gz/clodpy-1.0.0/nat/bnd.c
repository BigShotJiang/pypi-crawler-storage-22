#include "cld.h"
#include <cffi.h>

void* cld_init_wrap(void) {
    return cld_init();
}

void cld_cleanup_wrap(void* handle) {
    cld_cleanup(handle);
}

int cld_setopt_wrap(void* handle, int option, void* parameter) {
    return cld_setopt(handle, option, parameter);
}

int cld_perform_wrap(void* handle) {
    return cld_perform(handle);
}

int cld_getinfo_wrap(void* handle, int info, void* data) {
    return cld_getinfo(handle, info, data);
}

void cld_reset_wrap(void* handle) {
    cld_reset(handle);
}