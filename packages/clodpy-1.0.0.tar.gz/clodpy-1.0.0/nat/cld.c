#include "cld.h"
#include <stdlib.h>
#include <string.h>

static size_t write_callback(char* ptr, size_t size, size_t nmemb, void* userdata) {
    size_t realsize = size * nmemb;
    clod_buffer_t* mem = (clod_buffer_t*)userdata;
    
    if (!mem->data) {
        mem->data = (char*)malloc(1);
        mem->size = 0;
    }
    
    char* new_data = (char*)realloc(mem->data, mem->size + realsize + 1);
    if (!new_data) {
        return 0;
    }
    
    mem->data = new_data;
    memcpy(&(mem->data[mem->size]), ptr, realsize);
    mem->size += realsize;
    mem->data[mem->size] = 0;
    
    return realsize;
}

void* cld_init(void) {
    return curl_easy_init();
}

void cld_cleanup(void* handle) {
    if (handle) {
        curl_easy_cleanup((CURL*)handle);
    }
}

int cld_setopt(void* handle, int option, void* parameter) {
    if (!handle) return CURLE_FAILED_INIT;
    
    CURLoption opt = (CURLoption)option;
    CURL* curl = (CURL*)handle;
    
    if (opt == CURLOPT_WRITEDATA) {
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    } else if (opt == CURLOPT_WRITEHEADER) {
        curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, write_callback);
    }
    
    return curl_easy_setopt(curl, opt, parameter);
}

int cld_perform(void* handle) {
    if (!handle) return CURLE_FAILED_INIT;
    return curl_easy_perform((CURL*)handle);
}

int cld_getinfo(void* handle, int info, void* data) {
    if (!handle) return CURLE_FAILED_INIT;
    return curl_easy_getinfo((CURL*)handle, (CURLINFO)info, data);
}

void cld_reset(void* handle) {
    if (handle) {
        curl_easy_reset((CURL*)handle);
    }
}