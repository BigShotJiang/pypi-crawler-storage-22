from setuptools import setup, Extension
import os
import sys

# Determine libraries based on platform
libraries = ["curl"]
if sys.platform == "win32":
    libraries = ["libcurl", "ws2_32", "crypt32", "wldap32"]
elif sys.platform == "darwin":
    libraries = ["curl"]
else:
    libraries = ["curl"]

setup(
    name="clodpy",
    version="1.0.0",
    author="JA3FR",
    author_email="",
    description="Python CFFI bindings for libcurl",
    long_description="Fast and reliable HTTP client for Python using libcurl",
    url="https://github.com/hhvvm1",
    license="MIT",
    
    packages=["clodpy"],
    package_dir={"clodpy": "clodpy"},
    
    ext_modules=[
        Extension(
            "clodpy._cld_nat",
            sources=[
                "nat/cld.c",
                "nat/bnd.c"
            ],
            include_dirs=["nat"],
            libraries=libraries,
            library_dirs=[],
        )
    ],
    
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    
    python_requires=">=3.6",
    install_requires=["cffi>=1.15.0"],
    setup_requires=["cffi>=1.15.0"],
    
    keywords="http https curl networking web requests",
    project_urls={
        "Bug Reports": "https://github.com/hhvvm1",
        "Source": "https://github.com/hhvvm1",
    },
)