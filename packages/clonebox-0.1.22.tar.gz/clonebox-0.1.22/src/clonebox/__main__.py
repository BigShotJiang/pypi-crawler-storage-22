#!/usr/bin/env python3
"""Entry point for python -m clonebox."""

from clonebox.cli import main

if __name__ == "__main__":
    main()
