#!/usr/bin/env python3
"""
CloneBox CLI package.
"""

from .parsers import main
from .utils import (
    CLONEBOX_CONFIG_FILE,
    console,
    custom_style,
    deduplicate_list,
    generate_clonebox_yaml,
    load_clonebox_config,
)

# Re-export for tests
import questionary
from clonebox.cloner import SelectiveVMCloner
from clonebox.detector import SystemDetector
from clonebox.cli.vm_commands import cmd_detect
from clonebox.cli.misc_commands import cmd_clone
from clonebox.cli.utils import create_vm_from_config
from clonebox.audit import AuditQuery
from clonebox.cli.compose_commands import (
    cmd_compose_up,
    cmd_compose_down,
    cmd_compose_status,
    cmd_compose_logs,
)
from clonebox.orchestrator import Orchestrator
from clonebox.plugins.manager import get_plugin_manager
from clonebox.remote import RemoteCloner
from clonebox.cli.monitoring_commands import cmd_logs
from clonebox.cli.misc_commands import cmd_set_password
from clonebox.cli.policy_audit_commands import (
    cmd_audit_list,
    cmd_audit_show,
    cmd_audit_failures,
    cmd_audit_search,
    cmd_audit_export,
    cmd_policy_validate,
    cmd_policy_apply,
)
from clonebox.cli.plugin_commands import (
    cmd_plugin_list,
    cmd_plugin_enable,
    cmd_plugin_disable,
    cmd_plugin_discover,
    cmd_plugin_install,
    cmd_plugin_uninstall,
    cmd_plugin_info,
    cmd_plugin_run,
)
from clonebox.cli.remote_commands import (
    cmd_remote_list,
    cmd_remote_status,
    cmd_remote_start,
    cmd_remote_stop,
    cmd_remote_delete,
    cmd_remote_exec,
    cmd_remote_health,
    cmd_list_remote,
)
from rich.progress import Progress

__all__ = [
    "main",
    "CLONEBOX_CONFIG_FILE",
    "console",
    "custom_style",
    "deduplicate_list",
    "generate_clonebox_yaml",
    "load_clonebox_config",
    "SelectiveVMCloner",
    "SystemDetector",
    "cmd_detect",
    "cmd_clone",
    "create_vm_from_config",
    "Progress",
    "questionary",
    "AuditQuery",
    "cmd_compose_up",
    "cmd_compose_down",
    "cmd_compose_status",
    "cmd_compose_logs",
    "Orchestrator",
    "get_plugin_manager",
    "RemoteCloner",
    "cmd_logs",
    "cmd_set_password",
    "cmd_audit_list",
    "cmd_audit_show",
    "cmd_audit_failures",
    "cmd_audit_search",
    "cmd_audit_export",
    "cmd_policy_validate",
    "cmd_policy_apply",
    "cmd_plugin_list",
    "cmd_plugin_enable",
    "cmd_plugin_disable",
    "cmd_plugin_discover",
    "cmd_plugin_install",
    "cmd_plugin_uninstall",
    "cmd_plugin_info",
    "cmd_plugin_run",
    "cmd_remote_list",
    "cmd_remote_status",
    "cmd_remote_start",
    "cmd_remote_stop",
    "cmd_remote_delete",
    "cmd_remote_exec",
    "cmd_remote_health",
    "cmd_list_remote",
]
