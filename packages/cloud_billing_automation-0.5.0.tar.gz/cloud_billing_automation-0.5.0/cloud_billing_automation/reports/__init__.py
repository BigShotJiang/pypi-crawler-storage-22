"""
Reports module initialization.
"""
