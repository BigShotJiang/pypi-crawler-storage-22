# AG-UI ↔ Dify API 接口映射表

本文档详细说明了 AG-UI 协议与 Dify API 之间的参数和事件映射关系，用于实现 Dify adapter。

## 快速参考表

### 请求参数映射（AG-UI → Dify）

| AG-UI | Dify | 必需 | 说明 |
|-------|------|------|------|
| `thread_id` | `conversation_id` | 否 | 会话ID，为空时创建新会话 |
| `messages[-1].content` (user) | `query` | 是 | **仅提取 user 角色的消息**；严格模式：本次请求若包含任意非 user role 直接报错 |
| `forwarded_props.user` | `user` | 是 | 用户标识符 |
| `forwarded_props.inputs` | `inputs` | 否 | 应用变量，默认 {} |
| `run_id` | `trace_id`（body）+ `X-Trace-Id`（header） | 否 | 链路追踪：Dify 支持三种方式，优先级 Header > Query > Body；我们同时写 header 与 body |
| `forwarded_props.response_mode` | `response_mode` | 否 | streaming/blocking，默认 streaming |
| `forwarded_props.files` | `files` | 否 | 图片文件列表，需转换为 Dify 格式（见 1.2 文件格式） |
| `forwarded_props.auto_generate_name` | `auto_generate_name` | 否 | 自动生成会话标题，默认 `true` |
| `DIFY_API_KEY` (环境变量) | `Authorization: Bearer {key}` | 是 | API Key，从环境变量获取，不在请求中传递 |

**⚠️ 重要说明：**
- Dify API 只接受 `user` 角色的消息。**严格模式：本次请求若包含 `assistant`/`system`/`tool`/`developer` 等非 user role，adapter 直接返回 `RUN_ERROR`**
- API Key 从环境变量 `DIFY_API_KEY` 获取，不在请求中传递
- 应用通过 API Key 识别，不需要额外的 `app_id` 或 `agent_id` 参数
- `run_id` 如果用户未传入，需要生成 UUID 兜底
- `response_mode=blocking` 时返回完整 JSON，需要转换为事件序列；Agent 模式不支持 blocking

### 响应事件映射（Dify → AG-UI）

| Dify 事件 | AG-UI 事件 | 说明 |
|----------|-----------|------|
| `message` (首次) | `TEXT_MESSAGE_START` | 文本消息开始 |
| `message` | `TEXT_MESSAGE_CONTENT` | 文本内容增量（`answer` 为增量 delta） |
| `message_end` | `TEXT_MESSAGE_END` | 文本消息结束 |
| `agent_thought` (有 tool 且 thought 非重复) | `THINKING_TEXT_MESSAGE_CONTENT` | Agent 思考过程（见 2.3.3 去重规则） |
| `agent_thought` (tool + tool_input，无 observation) | `TOOL_CALL_START` / `TOOL_CALL_ARGS` / `TOOL_CALL_END` | 工具调用开始 |
| `agent_thought` (tool + observation) | `TOOL_CALL_RESULT` | 工具调用结果（observation） |
| `agent_thought` (仅 observation，无 tool) | `TOOL_CALL_RESULT` | 边缘情况：observation 仍作为 TOOL_CALL_RESULT |
| `message_file` (belongs_to=assistant) | `TOOL_CALL_RESULT` | 工具执行结果（文件 URL），tool_call_id 由 agent_thought 关联 |
| `agent_message` | `TEXT_MESSAGE_START`（若未发）+ `TEXT_MESSAGE_CONTENT` | Agent 消息增量 |
| `error` | `RUN_ERROR` | 流式错误 |
| `message_replace` | `TEXT_MESSAGE_START` + `TEXT_MESSAGE_CONTENT` | 内容审核替换 |
| `ping` | — | 忽略（保活） |
| `tts_message` / `tts_message_end` | — | 不映射（无 AG-UI 标准事件） |
| - | `RUN_STARTED` | 运行开始（adapter 生成） |
| - | `RUN_FINISHED` | 运行结束（adapter 生成） |
| - | `STEP_STARTED` / `STEP_FINISHED` | 步骤事件（adapter 生成） |

---

## 详细映射说明

## 1. 请求参数映射（AG-UI → Dify）

### 1.1 基础参数映射

| AG-UI 参数 | Dify API 参数 | 映射规则 | 说明 |
|-----------|--------------|---------|------|
| `run_input.thread_id` | `conversation_id` | 直接映射 | 会话ID，用于继续对话。如果为空，Dify 会创建新会话 |
| `run_input.run_id` | - | 不映射到 Dify，但在 AG-UI 事件中原样使用 | AG-UI 内部运行ID，Dify 不关心。如果用户传入则使用，否则生成 UUID |
| `run_input.messages` (最新 user 消息) | `query` | **只提取最后一条 `role="user"` 消息的 content** | 用户输入/问题内容。⚠️ **严格模式：本次请求 delta messages 中出现任何非 user role 直接报错** |
| `run_input.messages` (非 user 消息) | - | **报错（严格模式）** | `assistant`、`system`、`tool`、`developer` 等消息在本次请求中不被支持（避免语义悄然变化） |
| `run_input.messages` (历史消息) | - | 不映射 | Dify 通过 conversation_id 自动管理历史，不需要显式传递历史消息 |
| `run_input.forwarded_props.user` | `user` | 直接映射 | 用户标识符，必需字段 |
| `run_input.forwarded_props.inputs` | `inputs` | 直接映射 | 应用变量值（key/value 对），默认 {} |
| `run_input.run_id` | `trace_id`（body）、`X-Trace-Id`（header） | 同时写入 body 与 header | Dify 文档：trace_id 三种方式优先级为 Header > Query > Body；我们使用 Header + Body |
| `run_input.forwarded_props.response_mode` | `response_mode` | 直接映射 | 响应模式：`streaming`（推荐）或 `blocking`，默认 `streaming` |
| `run_input.forwarded_props.auto_generate_name` | `auto_generate_name` | 直接映射 | 自动生成会话标题，默认 `true` |
| `run_input.forwarded_props.files` | `files` | `_convert_files_format()` | 图片文件列表；AG-UI 支持 `type`+`url` 或 `type`+`upload_file_id`，Dify 需 `transfer_method`（`remote_url`/`local_file`）+ `url` 或 `upload_file_id` |
| - | `app_id` / `agent_id` | **不映射** | Dify 通过 API Key 识别应用，每个应用有独立的 API Key |

### 1.2 消息处理规则

**⚠️ 重要限制：Dify API 只接受用户消息**

Dify API 的 `query` 参数明确限定为 **"User Input/Question content"**，这意味着：
- **只能发送 `role="user"` 的消息**到 Dify API
- 其他 role 的消息（`assistant`, `system`, `tool`, `developer`）**不能直接映射**到 Dify API

**用户消息提取策略（参考 Coze adapter）：**
```python
# 只提取最后一条 user 角色的消息
user_message = None
for msg in reversed(run_input.messages):
    if getattr(msg, "role", None) == "user" and getattr(msg, "content", None):
        user_message = msg.content
        break

# 如果找到 user 消息，映射到 Dify 的 query 字段
if user_message:
    dify_request["query"] = user_message
```

**严格模式（A）：非 user 消息直接报错**

为了避免“悄悄丢上下文导致语义不一致”，Dify adapter 采用**严格模式**：
- 本次请求的 delta messages **必须只包含 user 角色消息**（通常只关心最后一条 user）
- 只要本次请求 messages 中出现任意 `assistant` / `system` / `tool` / `developer` 角色消息，**直接报错并终止**（不发送到 Dify）

**实现建议：**
1. **校验 role**：扫描本次 `run_input.messages`，如果存在任何非 `user` 的 role，抛出 `ValueError`
2. **提取 query**：通过最后一条 `role="user"` 的消息生成 Dify `query`
3. **无 user 消息**：如果没有 user 消息，抛出明确的错误

**示例代码：**
```python
def dify_prepare_inputs(run_input: RunAgentInput) -> Dict[str, Any]:
    """准备 Dify API 请求参数（严格模式）"""
    # 1) 严格校验：本次 messages 不允许出现非 user role
    for msg in run_input.messages:
        role = getattr(msg, "role", None)
        if role and role != "user":
            raise ValueError(
                "Dify adapter (strict mode) only supports role='user' messages in a single request. "
                f"Found unsupported role={role!r}. "
                "Please do not include assistant/system/tool/developer messages in the request."
            )

    # 2) 提取最后一条 user 消息作为 query
    user_message = None
    for msg in reversed(run_input.messages):
        if getattr(msg, "role", None) == "user" and getattr(msg, "content", None):
            user_message = msg.content
            break

    if not user_message:
        raise ValueError(
            "No user message found in messages. "
            "Dify API requires at least one message with role='user'."
        )
    
    # 构建 Dify 请求
    dify_request = {
        "query": user_message,
        "user": run_input.forwarded_props.get("user", ""),
        "conversation_id": run_input.thread_id or "",
        "response_mode": run_input.forwarded_props.get("response_mode", "streaming"),
        # ... 其他参数
    }
    
    return dify_request
```

**文件格式转换（`_convert_files_format`）：**

- 输入：AG-UI 格式列表，每项 `type`（默认 `"image"`）、`url` 或 `upload_file_id`。
- 输出：Dify 格式列表；有 `url` 时输出 `type`、`transfer_method: "remote_url"`、`url`；有 `upload_file_id` 时输出 `type`、`transfer_method: "local_file"`、`upload_file_id`。

```python
# AG-UI 格式（forwarded_props.files）
files = [
    {"type": "image", "url": "https://example.com/image.png"},
    {"type": "image", "upload_file_id": "file_id_from_upload"}
]

# Dify 格式（converters 输出）
files = [
    {"type": "image", "transfer_method": "remote_url", "url": "https://example.com/image.png"},
    {"type": "image", "transfer_method": "local_file", "upload_file_id": "file_id_from_upload"}
]
```

### 1.3 工具（Tools）处理

| AG-UI | Dify | 说明 |
|-------|------|------|
| `run_input.tools` | - | **不映射**。Dify 的工具是在平台配置的，不通过 API 传递 |

**注意：** Dify 的工具调用是通过平台配置的，API 调用时不需要传递工具定义。工具调用结果会通过 SSE 事件返回。

### 1.4 状态和上下文

| AG-UI | Dify | 说明 |
|-------|------|------|
| `run_input.state` | - | 不映射，Dify 不管理外部状态 |
| `run_input.context` | - | 不映射，Dify 通过 conversation_id 管理上下文 |

## 2. 响应事件映射（Dify → AG-UI）

### 2.1 SSE 事件流格式

Dify 使用 Server-Sent Events (SSE) 格式返回流式响应，每个事件以 `data: ` 开头，JSON 格式。

### 2.2 事件类型映射表

| Dify 事件类型 | Dify 事件字段 | AG-UI 事件类型 | AG-UI 事件字段映射 | 说明 |
|--------------|--------------|---------------|-------------------|------|
| `message` | `event: "message"`, `answer`, `conversation_id` | `TEXT_MESSAGE_START`（首次）+ `TEXT_MESSAGE_CONTENT` | `message_id` = `{conversation_id}:{run_id}`（优先用事件内 `conversation_id`）, `delta` = `answer` | 文本流式增量；内部累积 `_message_content_buffer` 供 agent_thought 去重 |
| `message_end` | `event: "message_end"` | `TEXT_MESSAGE_END` | `message_id` | 文本消息结束；清理 `_message_started`、`_content_buffer`、`_message_content_buffer` |
| `agent_thought` | `thought`, `observation`, `tool`, `tool_input`, `id`, `message_files`, `conversation_id` | 见 2.3.3 | 见 2.3.3 | 思考/工具调用/结果；去重与两阶段工具调用见下文 |
| `message_file` | `id`, `url`, `type`, `belongs_to` | `TOOL_CALL_RESULT` | `tool_call_id`（由 `_pending_file_ids` 或 `_tool_call_mapping` 解析）, `content` = `url` | 仅当 `belongs_to == "assistant"` 且 `url` 存在时发送 |
| `agent_message` | `answer`, `conversation_id` | `TEXT_MESSAGE_START`（若未发）+ `TEXT_MESSAGE_CONTENT` | `message_id`, `delta` = `answer`；累积到 `_message_content_buffer` | Agent 模式文本增量 |
| `error` | `event: "error"`, `status`, `code`, `message` | `RUN_ERROR` | `thread_id`, `run_id`, `message`, `code` | 流式错误 |
| `message_replace` | `answer` | `TEXT_MESSAGE_START` + `TEXT_MESSAGE_CONTENT` | 重置消息状态后发送新内容 | 内容审核替换 |
| `ping` | `event: "ping"` | — | 忽略 | 保活 |
| `tts_message` / `tts_message_end` | — | 不映射 | — | 无 AG-UI 标准 TTS 事件 |
| - | - | `RUN_STARTED` | `thread_id`, `run_id` | 运行开始（adapter 生成） |
| - | - | `RUN_FINISHED` | `thread_id`, `run_id` | 运行结束（adapter 生成） |
| - | - | `STEP_STARTED` / `STEP_FINISHED` | `step_name` | 步骤事件（adapter 生成） |

### 2.3 详细事件映射规则

#### 2.3.1 message 事件（文本消息）

**Dify SSE 格式：**
```
data: {"event": "message", "task_id":"mock_task_id", "message_id": "5ad4cb98-f0c7-4085-b384-88c403be6290", "conversation_id": "45701982-8118-4bc5-8e9b-64562b4555f2", "answer": " I", "created_at": 1679586595}

data: {"event": "message", "task_id":"mock_task_id", "message_id": "5ad4cb98-f0c7-4085-b384-88c403be6290", "conversation_id": "45701982-8118-4bc5-8e9b-64562b4555f2", "answer": " am", "created_at": 1679586596}
```

**Dify JSON 格式（每个 data: 行）：**
```json
{
  "event": "message",
  "task_id": "c3800678-a077-43df-a102-53f23ed20b88",
  "id": "9da23599-e713-473b-982c-4328d4f5c78a",
  "message_id": "9da23599-e713-473b-982c-4328d4f5c78a",
  "conversation_id": "45701982-8118-4bc5-8e9b-64562b4555f2",
  "mode": "chat",
  "answer": " I",  // 增量内容片段
  "created_at": 1705407629
}
```

**AG-UI 转换：**
1. 首次收到 `message` 事件时，发送 `TEXT_MESSAGE_START`：
   ```python
   TextMessageStartEvent(
       type=EventType.TEXT_MESSAGE_START,
       message_id=f"{conversation_id}:{run_id}",
       role="assistant"
   )
   ```

2. 每次收到 `message` 事件时，发送 `TEXT_MESSAGE_CONTENT`（增量）：
   ```python
   TextMessageContentEvent(
       type=EventType.TEXT_MESSAGE_CONTENT,
       message_id=f"{conversation_id}:{run_id}",
       delta=answer  # 增量内容片段（如 " I", " am", " a"）
   )
   ```

**重要说明：** 
- Dify 的 `answer` 字段在 streaming 模式下是**增量内容**（delta），每个事件只包含新增的文本片段；直接作为 `delta` 传递。
- `message_id` 与 `buffer_key` 使用事件内 `conversation_id`（若有），否则用入参 `thread_id`；格式为 `{conversation_id}:{run_id}`。
- 实现中会将每次 `answer` 累积到 `_message_content_buffer[buffer_key]`，供后续 `agent_thought` 去重（避免 thought 与已流式消息重复）。
- SSE 格式：每个事件以 `data: ` 开头，JSON 数据，以 `\n\n` 结尾。

#### 2.3.2 message_end 事件（消息结束）

**Dify 格式：**
```json
{
  "event": "message_end",
  "task_id": "c3800678-a077-43df-a102-53f23ed20b88",
  "message_id": "9da23599-e713-473b-982c-4328d4f5c78a",
  "conversation_id": "45701982-8118-4bc5-8e9b-64562b4555f2",
  "metadata": {
    "usage": {...},
    "retriever_resources": [...]
  }
}
```

**AG-UI 转换：** 若该 `buffer_key` 已发送过 `TEXT_MESSAGE_START`（`_message_started[buffer_key]` 为 True），则发送 `TextMessageEndEvent(message_id=msg_id)`，并将 `_message_started[buffer_key]` 置为 False；同时清理该 buffer_key 下的 `_content_buffer` 与 `_message_content_buffer` 条目。

#### 2.3.3 agent_thought 事件（Agent 思考与工具调用）

**Dify 格式：**
```json
{
  "event": "agent_thought",
  "id": "agent_thought_id_1",
  "task_id": "task123",
  "message_id": "msg123",
  "conversation_id": "conv123",
  "position": 1,
  "thought": "Thinking about calling a tool...",
  "observation": "",
  "tool": "dalle3",
  "tool_input": "{\"dalle3\": {\"prompt\": \"a cute cat\"}}",
  "message_files": [],
  "created_at": 1705395332
}
```

**ID 与 message_id：** 使用事件内 `conversation_id`（若有）更新 `actual_conversation_id`、`msg_id`、`buffer_key`；`thought_id` = `event.id` 或生成 UUID。

**1. 仅文本摘要（无 tool）时丢弃 thought**

- 当 `agent_thought` 没有 `tool` 或 `tool` 为空时，视为“纯文本摘要”，与已流式输出的 agent 消息重复，**不发送** `THINKING_TEXT_MESSAGE_CONTENT`，只处理下方的工具与 observation。

**2. thought 与 observation 去重**

- 若 `thought` 与 `observation` 相同或 thought 包含 observation 内容，则不把 thought 作为思考内容发送；observation 单独作为 `TOOL_CALL_RESULT` 处理（见下）。

**3. thought 与已累积消息内容去重**

- 使用 `_message_content_buffer[buffer_key]` 累积的文本与 `thought` 做规范化比较（去空白）。
- 若 thought 与消息内容高度相似（如消息内容完全包含在 thought 中且占比 ≥ 80%，或字符相似度 ≥ 90%），**不发送** `THINKING_TEXT_MESSAGE_CONTENT`，避免与已流式输出的 `TEXT_MESSAGE_CONTENT` 重复。
- 若无累积消息或明显不同，则发送 `ThinkingTextMessageContentEvent(delta=thought)`。

**4. 工具调用的两阶段事件（Dify 每个工具调用发两个 agent_thought）**

- **阶段一（仅有 tool + tool_input，无 observation）：** 发送 `TOOL_CALL_START`（`tool_call_id` = `event.id`，`tool_call_name` = 第一个工具名）、`TOOL_CALL_ARGS`（`delta` = `tool_input` 的 JSON 字符串）、`TOOL_CALL_END`；并将该 `thought_id` 写入 `_tool_call_mapping`，供后续 result 与 message_file 关联。
- **阶段二（同一 tool + tool_input + observation）：** 仅发送 `TOOL_CALL_RESULT`（`tool_call_id` = `event.id`，`content` = `observation`，`role="tool"`），**不再**发送 START/ARGS/END。

**5. tool 字段**

- 可能为分号分隔的多个工具名；取第一个非空为 `primary_tool`，用于 `TOOL_CALL_START.tool_call_name`。

**6. observation 无 tool 的边角情况**

- 若仅有 `observation` 无 `tool`/`tool_input`，仍发送 `TOOL_CALL_RESULT`（`tool_call_id` = `event.id`，`content` = `observation`）。若存在 `message_files`，将 file_id 写入 `_pending_file_ids[file_id] = thought_id`，供后续 `message_file` 解析 `tool_call_id`。

**7. message_files**

- `agent_thought.message_files` 中的 file_id 会写入 `_pending_file_ids`，在收到 `message_file` 时用其解析出对应的 `tool_call_id`。

#### 2.3.4 message_file 事件（工具执行结果文件）

**Dify 格式：**
```json
{
  "event": "message_file",
  "id": "file_id_1",
  "type": "image",
  "belongs_to": "assistant",
  "url": "https://example.com/cat.png",
  "conversation_id": "conv123"
}
```

**tool_call_id 解析顺序：**
1. 若 `event.id` 在 `_pending_file_ids` 中（来自 `agent_thought.message_files`），则 `tool_call_id` = `_pending_file_ids[file_id]`，使用后从 `_pending_file_ids` 移除。
2. 否则若存在 `_tool_call_mapping`，先查 `event.id` 是否在 mapping 中；若不在，则用**最近一次**工具调用的 id 作为 `tool_call_id`。

**AG-UI 转换：** 仅当 `url` 非空且 `belongs_to == "assistant"` 时发送：
```python
ToolCallResultEvent(
    type=EventType.TOOL_CALL_RESULT,
    message_id=msg_id,
    tool_call_id=tool_call_id,  # 由上一步解析得到
    content=url,
    role="tool"
)
```
若 `belongs_to != "assistant"` 或无 `url`，则不发送事件（debug 模式下记录日志）。

#### 2.3.5 agent_message 事件（Agent 模式文本增量）

**Dify 格式：**
```json
{
  "event": "agent_message",
  "task_id": "task123",
  "message_id": "msg123",
  "conversation_id": "conv123",
  "answer": "Here is the image: ",
  "created_at": 1705395333
}
```

**AG-UI 转换：**
- 使用事件内 `conversation_id`（若有）更新 `actual_conversation_id`、`msg_id`、`buffer_key`。
- 若该 `buffer_key` 尚未发送过 `TEXT_MESSAGE_START`（`_message_started[buffer_key]` 为 False），先发送 `TextMessageStartEvent`，再置 `_message_started[buffer_key] = True`。
- 若 `answer` 非空：累积到 `_message_content_buffer[buffer_key]`（供后续 agent_thought 去重），并发送 `TextMessageContentEvent(message_id=msg_id, delta=answer)`。

这样在 Agent 模式下，先到的 `agent_message` 增量会进入 `_message_content_buffer`，后续若 `agent_thought` 携带相同或高度相似内容会被去重，避免重复展示。

#### 2.3.6 error 事件（流式错误）

**Dify 格式：** `event: "error"`，字段 `status`、`code`、`message`。

**AG-UI 转换：** 发送 `RunErrorEvent`（`RUN_ERROR`），`thread_id`、`run_id` 使用当前运行上下文，`message` 为拼接的完整错误信息（含 status/code/message），`code` 为 `event.code` 或 `str(status)`。由 adapter 层据此发出 `RUN_ERROR`。

#### 2.3.7 message_replace 事件（内容审核替换）

**Dify 格式：** `event: "message_replace"`，字段 `answer` 为替换后的完整内容。

**AG-UI 转换：** 重置该 `buffer_key` 下的 `_message_started` 与 `_message_content_buffer`，然后发送新的 `TextMessageStartEvent` 与 `TextMessageContentEvent(message_id=msg_id, delta=answer)`，再置 `_message_started[buffer_key] = True`。用于内容审核触发时的整条消息替换。

#### 2.3.8 ping 事件（保活）

**Dify 格式：** `event: "ping"`（约每 10 秒一次）。

**AG-UI 转换：** 不映射，直接忽略（`dify_events_to_ag_ui_events` 返回 `None`）。debug 模式下可打日志。

#### 2.3.9 tts_message / tts_message_end 事件（TTS 音频）

**Dify 格式：** `event: "tts_message"`（含 Base64 音频块）、`event: "tts_message_end"`。

**AG-UI 转换：** 不映射。AG-UI 协议无标准 TTS 事件类型，converters 返回 `None`。debug 模式下可记录 `tts_message` 的 `message_id`、`audio` 长度等。

### 2.4 Agent 模式特殊事件处理

**Dify Agent Assistant 模式事件序列：**

1. **agent_thought** - Agent 思考过程（可选）
   ```json
   {
     "event": "agent_thought",
     "id": "agent_thought_id_1",
     "task_id": "task123",
     "message_id": "msg123",
     "conversation_id": "conv123",
     "position": 1,
     "thought": "Thinking about calling a tool...",
     "tool": "dalle3",
     "tool_input": "{\"dalle3\": {\"prompt\": \"a cute cat\"}}",
     "created_at": 1705395332
   }
   ```

2. **message_file** - 工具执行结果（文件）
   ```json
   {
     "event": "message_file",
     "id": "file_id_1",
     "type": "image",
     "belongs_to": "assistant",
     "url": "https://example.com/cat.png",
     "conversation_id": "conv123"
   }
   ```

3. **agent_message** - Agent 最终消息
   ```json
   {
     "event": "agent_message",
     "task_id": "task123",
     "message_id": "msg123",
     "conversation_id": "conv123",
     "answer": "Here is the image: ",
     "created_at": 1705395333
   }
   ```

4. **message_end** - 消息结束
   ```json
   {
     "event": "message_end",
     "task_id": "task123",
     "message_id": "msg123",
     "conversation_id": "conv123",
     "metadata": {...}
   }
   ```

### 2.5 工具调用处理

**Dify 工具调用流程：**
1. Dify 平台配置工具（不通过 API 传递）
2. Agent 调用工具时，通过 `agent_thought` 事件显示工具调用信息（包含 `tool` 和 `tool_input`）
3. 工具执行结果通过 `message_file` 事件返回（如果是文件类型）
4. Agent 最终响应通过 `agent_message` 事件返回

**AG-UI 工具调用事件映射（与 2.3.3、2.3.4 一致）：**
- **agent_thought 且含 tool + tool_input、无 observation：** 发送 `TOOL_CALL_START`（`tool_call_id` = `event.id`，`tool_call_name` = 第一个工具名）、`TOOL_CALL_ARGS`（`delta` = `tool_input` 的 JSON 字符串）、`TOOL_CALL_END`；并写入 `_tool_call_mapping[thought_id]`。
- **agent_thought 且含 tool + observation：** 仅发送 `TOOL_CALL_RESULT`（`tool_call_id` = `event.id`，`content` = `observation`），不重复发 START/ARGS/END。
- **message_file：** 先通过 `_pending_file_ids` 或 `_tool_call_mapping` 解析 `tool_call_id`，再在 `belongs_to == "assistant"` 且存在 `url` 时发送 `TOOL_CALL_RESULT`（`content` = `url`）。

**注意：** 实现中维护 `_tool_call_mapping`（agent_thought.id → 工具信息）和 `_pending_file_ids`（agent_thought.message_files 的 file_id → thought_id），以便 `message_file` 正确关联到工具调用。

### 2.6 元数据（Metadata）处理

**Dify metadata 字段：**
```json
{
  "metadata": {
    "usage": {
      "prompt_tokens": 1033,
      "completion_tokens": 128,
      "total_tokens": 1161,
      "total_price": "0.0012890",
      "currency": "USD",
      "latency": 0.7682376249867957
    },
    "retriever_resources": [
      {
        "position": 1,
        "dataset_id": "101b4c97-fc2e-463c-90b1-5261a4cdcafb",
        "dataset_name": "iPhone",
        "document_id": "8dd1ad74-0b5f-4175-b735-7d98bbbb4e00",
        "document_name": "iPhone List",
        "segment_id": "ed599c7f-2766-4294-9d1d-e5235a61270a",
        "score": 0.98457545,
        "content": "..."
      }
    ]
  }
}
```

**AG-UI 处理：**
- `usage` 信息可以通过 `forwarded_props` 传递或记录到日志
- `retriever_resources` 可以作为上下文信息处理，但不映射到标准 AG-UI 事件

## 3. 错误处理映射

**流式 SSE `error` 事件：** Dify 在 SSE 流中可能发送 `event: "error"`，字段 `status`、`code`、`message`。converters 将其转换为 `RunErrorEvent`（`RUN_ERROR`），`message` 为拼接的 `"Dify API error ({status}), code={code}: {message}"`，`code` 为 `event.code` 或 `str(status)`。其他 HTTP 或业务错误由 adapter 层统一转换为 `RUN_ERROR`。

| Dify 错误码 / 来源 | Dify 错误消息 | AG-UI 事件 | 说明 |
|------------------|--------------|-----------|------|
| SSE `error` 事件 | `status`, `code`, `message` | `RUN_ERROR` | 流式错误，由 converters 直接发出 RunErrorEvent |
| `invalid_param` | "Abnormal parameter input" | `RUN_ERROR` | 参数错误 |
| `app_unavailable` | "App configuration unavailable" | `RUN_ERROR` | 应用配置不可用 |
| `provider_not_initialize` | "No available model credential configuration" | `RUN_ERROR` | 模型凭证未配置 |
| `provider_quota_exceeded` | "Model invocation quota insufficient" | `RUN_ERROR` | 配额不足 |
| `model_currently_not_support` | "Current model unavailable" | `RUN_ERROR` | 模型不可用 |
| `completion_request_error` | "Text generation failed" | `RUN_ERROR` | 文本生成失败 |
| 404 | "Conversation does not exist" | `RUN_ERROR` | 会话不存在 |
| 500 | "Internal server error" | `RUN_ERROR` | 服务器错误 |

## 4. 认证和应用识别

### 4.1 API Key 认证

| AG-UI | Dify | 说明 |
|-------|------|------|
| `DIFY_API_KEY` (环境变量) | `Authorization: Bearer {API_KEY}` | API Key 从环境变量获取，在初始化时配置，不在请求中传递 |

**实现方式（参考 Coze adapter）：**
```python
import os

class DifyAgent(BaseAgent):
    def __init__(
        self,
        name: str,
        description: str,
        api_key: Optional[str] = None,  # 可选，优先使用参数
        base_url: Optional[str] = None,
        # ...
    ):
        # 从环境变量或参数获取 API Key
        final_api_key = api_key or os.environ.get("DIFY_API_KEY")
        if not final_api_key:
            raise ValueError(
                "DIFY_API_KEY is required. "
                "Set it via environment variable DIFY_API_KEY or pass api_key parameter."
            )
        
        # 创建 Dify 客户端，API Key 在初始化时设置
        self._dify_client = DifyClient(
            api_key=final_api_key,
            base_url=base_url or "https://api.dify.ai/v1"
        )
```

**⚠️ 重要：**
- API Key **不应该**从 `forwarded_props.api_key` 获取（安全风险）
- API Key 应该在**服务启动时**从环境变量读取
- 每个 Dify 应用有独立的 API Key，通过 API Key 识别应用

### 4.2 应用/Agent 识别

**Dify 的应用识别机制：**
- Dify **不通过请求参数**指定应用/agent ID
- 应用通过 **API Key 识别**：每个应用在 Dify Studio 中生成独立的 API Key
- 使用不同的 API Key 就相当于使用不同的应用

**实现方式：**
```python
# 方式1：单一应用（推荐）
# 在环境变量中设置对应应用的 API Key
DIFY_API_KEY=app-xxxxx  # 对应某个特定应用的 API Key

# 方式2：多应用支持（如果需要）
# 可以通过不同的 agent 实例使用不同的 API Key
agent1 = DifyAgent(api_key="app-1-key", ...)  # 应用1
agent2 = DifyAgent(api_key="app-2-key", ...)  # 应用2
```

**与 Coze 的区别：**
- Coze 需要 `bot_id` 参数来指定 Bot
- Dify 通过 API Key 自动识别应用，**不需要额外的 app_id 或 agent_id 参数**

## 5. 特殊处理说明

### 5.1 conversation_id 处理

- **首次请求：** `thread_id` 为空或不存在时，Dify 会创建新会话，返回的 `conversation_id` 需要保存
- **继续对话：** 使用之前返回的 `conversation_id` 作为 `thread_id` 传入

### 5.1.1 conversation_id 非法的兜底重试（建议）

当 `thread_id` 被映射到 Dify 的 `conversation_id` 时，如果该值**格式非法**，Dify 可能返回 `400 invalid_param`。

为避免因为“格式问题”阻断对话，可以像 Coze 一样做**一次性兜底重试**，但必须**有条件**：

- ✅ **只在 400 且错误码为 `invalid_param`（且错误信息指向 conversation_id 格式问题）时**：重试一次，将 `conversation_id` 置空（或不传）创建新会话
- ❌ **404 Conversation does not exist**：不重试（这是业务语义错误，应暴露给调用方）
- ❌ 401/403/配额/模型不可用等：不重试

**实现思路：**
1. 第一次按原样发送（携带 conversation_id）
2. 若捕获到满足条件的 400 invalid_param，则第二次发送不带 conversation_id
3. 最多重试 1 次

### 5.2 run_id 处理

| 场景 | 处理方式 | 说明 |
|------|---------|------|
| 用户传入 `run_id` | 原样使用 | 使用 `run_input.run_id` |
| 用户未传入 `run_id` | 生成 UUID | 使用 `uuid.uuid4()` 生成，确保每个运行有唯一ID |

**实现方式：**
```python
import uuid

def get_run_id(run_input: RunAgentInput) -> str:
    """获取或生成 run_id"""
    if run_input.run_id:
        return run_input.run_id
    return str(uuid.uuid4())
```

**注意：**
- `run_id` 不映射到 Dify API（Dify 不关心）
- `run_id` 用于 AG-UI 事件中的 `message_id` 生成：`f"{conversation_id}:{run_id}"`
- 确保每个运行都有唯一的 `run_id`，用于事件追踪

### 5.3 非 user role 消息处理

**严格模式（A）：本次请求 messages 只允许包含 `user` 角色**

| AG-UI Message Role | 处理方式 | 原因 |
|-------------------|---------|------|
| `user` | ✅ **提取并映射到 `query`** | Dify API 唯一支持的消息类型 |
| `assistant` / `system` / `tool` / `developer` | ❌ **直接报错（RUN_ERROR）** | Dify API 无法接收这些 role；忽略会导致语义悄然变化 |

**实现代码：**
```python
def dify_prepare_inputs(run_input: RunAgentInput) -> Dict[str, Any]:
    """准备 Dify API 请求参数（严格模式）"""
    # 1) 严格校验：不允许出现非 user role
    for msg in run_input.messages:
        role = getattr(msg, "role", None)
        if role and role != "user":
            raise ValueError(
                "Dify adapter (strict mode) only supports role='user' messages in a single request. "
                f"Found unsupported role={role!r}."
            )

    # 2) 提取最后一条 user 消息作为 query
    user_message = None
    for msg in reversed(run_input.messages):
        if getattr(msg, "role", None) == "user" and getattr(msg, "content", None):
            user_message = msg.content
            break

    if not user_message:
        raise ValueError(
            "No user message found in messages. "
            "Dify API requires at least one message with role='user'."
        )

    return {"query": user_message, ...}
```

### 5.4 response_mode: blocking vs streaming

**Dify 支持两种响应模式：**

| 模式 | 响应格式 | 适用场景 | AG-UI 事件处理 |
|------|---------|---------|---------------|
| `streaming` (默认) | `text/event-stream` (SSE) | 实时流式响应，推荐 | 逐事件转换并流式发送 |
| `blocking` | `application/json` | 等待完整响应后返回 | 需要等待完整响应，然后转换为事件序列 |

**streaming 模式（推荐）：**
```python
# Dify 返回 SSE 流
response_mode = "streaming"

# 处理方式：逐事件转换
async for dify_event in dify_stream:
    agui_events = dify_events_to_ag_ui_events(dify_event, ...)
    for event in agui_events:
        yield event
```

**blocking 模式：**
```python
# Dify 返回完整 JSON 响应
response_mode = "blocking"

# 响应格式（一次性返回）：
{
    "event": "message",
    "task_id": "...",
    "message_id": "...",
    "conversation_id": "...",
    "mode": "chat",
    "answer": "完整响应内容",  # 注意：这里是完整内容，不是增量
    "metadata": {...},
    "created_at": 1705407629
}

# 处理方式：转换为事件序列
def blocking_response_to_events(dify_response: dict, ...) -> List[BaseEvent]:
    """将 blocking 模式的完整响应转换为事件序列"""
    events = []
    
    # 1. RUN_STARTED
    events.append(RunStartedEvent(...))
    events.append(StepStartedEvent(...))
    
    # 2. TEXT_MESSAGE_START
    events.append(TextMessageStartEvent(
        message_id=f"{conversation_id}:{run_id}",
        role="assistant"
    ))
    
    # 3. TEXT_MESSAGE_CONTENT（完整内容作为单个 delta）
    events.append(TextMessageContentEvent(
        message_id=f"{conversation_id}:{run_id}",
        delta=dify_response["answer"]  # 完整内容
    ))
    
    # 4. TEXT_MESSAGE_END
    events.append(TextMessageEndEvent(
        message_id=f"{conversation_id}:{run_id}"
    ))
    
    # 5. RUN_FINISHED
    events.append(StepFinishedEvent(...))
    events.append(RunFinishedEvent(...))
    
    return events
```

**关键区别：**

| 特性 | streaming | blocking |
|------|-----------|----------|
| 响应格式 | SSE (`text/event-stream`) | JSON (`application/json`) |
| `answer` 字段 | 增量内容（delta） | 完整内容 |
| 事件发送时机 | 实时流式发送 | 等待完整响应后一次性发送 |
| 适用场景 | 实时对话（推荐） | 简单请求，不需要流式体验 |
| Agent 模式支持 | ✅ 支持 | ❌ 不支持（文档明确说明） |

**⚠️ 重要限制：**
- **Agent Assistant 模式不支持 blocking**：Dify 文档明确说明 "not supported in Agent Assistant mode"
- **Cloudflare 超时**：blocking 模式有 100s 超时限制
- **推荐使用 streaming**：更好的用户体验，支持 Agent 模式

**实现建议：**
```python
# 默认使用 streaming
response_mode = run_input.forwarded_props.get("response_mode", "streaming")

if response_mode == "blocking":
    # 检查是否是 Agent 模式（如果可检测）
    # 如果是 Agent 模式，强制使用 streaming
    logger.warning("Blocking mode not supported for Agent Assistant mode, using streaming")
    response_mode = "streaming"

# 根据模式选择处理方式
if response_mode == "streaming":
    async for event in handle_streaming_response(...):
        yield event
else:
    # blocking 模式
    response = await dify_client.chat_messages.create(..., response_mode="blocking")
    for event in blocking_response_to_events(response, ...):
        yield event
```

### 5.5 流式响应处理

- Dify 使用 SSE 格式，每个事件以 `data: ` 开头
- 需要解析 JSON 并转换为 AG-UI 事件（`dify_events_to_ag_ui_events`）
- 流式响应以 `[DONE]` 结束（若使用标准 SSE 格式）

### 5.6 消息 ID 生成

- AG-UI 使用 `message_id` = `{conversation_id}:{run_id}`；优先使用事件内返回的 `conversation_id`（如 `message`、`agent_thought`、`agent_message` 等），以与 Dify 实际会话一致
- Dify 返回的 `message_id` 可作内部关联，对外统一使用 `{conversation_id}:{run_id}`

### 5.7 工具调用关联

- Dify 的工具调用通过两个 `agent_thought`（无 observation → START/ARGS/END，有 observation → TOOL_CALL_RESULT）及可选的 `message_file` 返回
- 实现中通过 `_tool_call_mapping`（thought_id → 工具信息）与 `_pending_file_ids`（file_id → thought_id）维护关联，以便 `message_file` 正确解析 `tool_call_id`

## 6. 实现方式说明

**当前实现：** 本包（converters + agent）使用 **httpx** 直接调用 Dify HTTP API 与解析 SSE 流，不依赖 `dify-client` SDK。这样可完全控制请求/响应与事件解析，便于与 AG-UI 事件一一对应，并避免第三方 SDK 版本滞后问题。

**HTTP 与事件：** 流式模式下请求 `POST /v1/chat-messages`，响应为 `text/event-stream`；每行 `data: {...}` 解析为 JSON 后传入 `dify_events_to_ag_ui_events()` 得到 AG-UI 事件列表。blocking 模式返回完整 JSON，需在 adapter 层转换为事件序列（若支持）。

**可选参考：** 官方 Python SDK 见 https://github.com/langgenius/dify-python-sdk；若采用 SDK，需保证流式事件格式与本文档 2.x 节一致，以便复用同一套 `dify_events_to_ag_ui_events` 逻辑。

## 7. 关键限制和注意事项

### 7.1 ⚠️ 消息 Role 限制（重要）

**问题：** AG-UI 协议支持多种消息角色（`user`, `assistant`, `system`, `tool`, `developer`），但 Dify API 的 `query` 参数明确限定为 **"User Input/Question content"**，只接受用户消息。

**影响：**
- ❌ **不能**将 `assistant` 消息强制映射为 `user` 消息发送给 Dify
- ❌ **不能**将 `system` 消息直接发送给 Dify API
- ❌ **不能**将 `tool` 消息发送给 Dify（工具调用由 Dify 平台管理）

**解决方案：**
1. **只提取 user 消息**：从消息列表中提取最后一条 `role="user"` 的消息（参考 Coze adapter 实现）
2. **严格报错**：对于非 user 消息，直接抛出错误（避免语义不一致）
3. **验证消息存在**：如果没有 user 消息，应该抛出明确的错误

**为什么不能强制映射？**
- **语义错误**：assistant 消息被当作 user 消息会导致 Dify 误解对话上下文
- **对话逻辑混乱**：可能导致 Dify 的对话历史管理出现问题
- **功能限制**：无法正确传递系统指令或工具结果

**参考实现（Coze adapter 模式）：**
```python
# ✅ 正确做法：只提取 user 消息
user_message = None
for msg in reversed(run_input.messages):
    if getattr(msg, "role", None) == "user" and getattr(msg, "content", None):
        user_message = msg.content
        break

# ❌ 错误做法：强制映射所有消息
# 不要这样做！
# for msg in run_input.messages:
#     if msg.role == "assistant":
#         dify_request["query"] = msg.content  # 错误！
```

### 7.2 其他实现注意事项

1. **增量内容处理：** Dify 的 `answer` 字段在 streaming 模式下是增量内容，需要直接作为 `delta` 传递，不需要累积
2. **事件顺序：** 确保 `TEXT_MESSAGE_START` 在 `TEXT_MESSAGE_CONTENT` 之前发送
3. **conversation_id 同步：** 首次请求后，需要将返回的 `conversation_id` 更新到 `thread_id`，用于后续对话
4. **错误处理：** 所有错误都需要转换为 `RUN_ERROR` 事件
5. **生命周期事件：** `RUN_STARTED`, `RUN_FINISHED`, `STEP_STARTED`, `STEP_FINISHED` 由 adapter 生成，不在 Dify 响应中
6. **实现方式：** 当前实现使用 httpx 直接调用 HTTP API 与解析 SSE，不依赖 `dify-client` SDK；工具调用关联通过 `_tool_call_mapping` 与 `_pending_file_ids` 维护 `agent_thought.id` 与 `message_file` 的对应关系
7. **线程安全：** 若使用同步 HTTP 客户端，需在 worker 线程中调用（参考 Coze adapter 的实现模式）
