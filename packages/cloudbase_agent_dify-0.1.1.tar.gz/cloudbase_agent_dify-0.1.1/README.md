# cloudbase-agent-dify

Cloudbase Agent Python SDK - Dify framework integration

This package provides Dify-specific agent implementations for Cloudbase Agent, enabling seamless integration with Dify platform's chat API.

## Installation

```bash
pip install -e .
```

## Usage

See examples in `python-sdk/examples/dify/` for usage examples.

## Configuration

Set the following environment variables:

- `DIFY_API_KEY`: Dify API key (required)
- `DIFY_API_BASE`: Dify API base URL (optional, defaults to `https://api.dify.ai/v1`)

## Implementation Details

This adapter uses **direct HTTP requests** via `httpx` instead of relying on third-party SDKs:

- **Why direct HTTP?** The official `dify-client` package on PyPI hasn't been updated since 2023 and may be outdated
- **Benefits**: Full control over API calls, easier to maintain, no dependency on potentially outdated SDKs
- **API Reference**: Implementation follows the official Dify API documentation: https://docs.dify.ai/api-reference/chat/send-chat-message

## Features

- **Strict mode**: Only `user` role messages are accepted in a single request (prevents semantic inconsistencies)
- **Automatic conversation management**: Uses `conversation_id` from Dify responses as `thread_id`
- **Intelligent retry**: Automatically retries once without `conversation_id` if format error occurs
- **Streaming & Blocking**: Support for both `streaming` (SSE) and `blocking` response modes
- **Tool call mapping**: Complete support for Dify Agent mode tool calls via `agent_thought` events
