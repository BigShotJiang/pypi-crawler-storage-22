# Cloudbase Agent N8n Adapter

N8n agent integration for Cloudbase Agent Python SDK.

## Installation

```bash
pip install cloudbase-agent-n8n
```

## Usage

```python
from cloudbase_agent.n8n import N8nAgent
from ag_ui.core import RunAgentInput, Message

agent = N8nAgent(
    name="MyN8nAgent",
    description="An agent powered by N8n",
    webhook_url="https://n8n.example.com/webhook/chat",
)

run_input = RunAgentInput(
    thread_id="thread-001",
    run_id="run-001",
    messages=[Message(role="user", content="Hello!")],
)
async for event in agent.run(run_input):
    print(event)
```

## License

MIT
