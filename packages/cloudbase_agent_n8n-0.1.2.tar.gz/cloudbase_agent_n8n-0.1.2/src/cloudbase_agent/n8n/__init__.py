"""N8n Agent Implementation Package.

This package provides N8n-specific agent implementations for Cloudbase Agent,
including webhook calling, event streaming, and response parsing utilities.

Available Classes:
    - N8nAgent: N8n agent implementation extending BaseAgent

Available Modules:
    - converters: Message and event conversion utilities
    - agent: N8n agent implementation
"""

from .agent import N8nAgent
from .converters import (
    n8n_prepare_inputs,
    n8n_events_to_ag_ui_events,
)

__all__ = [
    "N8nAgent",
    "n8n_prepare_inputs",
    "n8n_events_to_ag_ui_events",
]
