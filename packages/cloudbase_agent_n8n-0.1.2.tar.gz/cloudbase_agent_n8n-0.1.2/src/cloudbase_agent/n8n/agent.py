"""N8n Agent Implementation.

This module provides the N8nAgent class for integrating with N8n workflows
via webhook calls. Supports streaming responses via Server-Sent Events (SSE).
"""

import json
import logging
import os
from collections.abc import AsyncGenerator
from typing import Any, Dict, Optional

import httpx

from cloudbase_agent.base_agent import BaseAgent
from ag_ui.core import RunAgentInput
from ag_ui.core.events import (
    EventType,
    RunErrorEvent,
    RunFinishedEvent,
    RunStartedEvent,
    StepFinishedEvent,
    StepStartedEvent,
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
    ThinkingEndEvent,
    ThinkingStartEvent,
    ThinkingTextMessageContentEvent,
    ThinkingTextMessageEndEvent,
    ThinkingTextMessageStartEvent,
)

from .converters import n8n_events_to_ag_ui_events, n8n_prepare_inputs

# Optional observability imports
try:
    from cloudbase_agent.observability import start_observation
    from opentelemetry.trace import SpanContext, Status, StatusCode
    HAS_OBSERVABILITY = True
except ImportError:
    HAS_OBSERVABILITY = False
    SpanContext = Any
    Status = None
    StatusCode = None

# Logger for this module
logger = logging.getLogger(__name__)


class N8nAgent(BaseAgent):
    """N8n agent implementation using webhook calls.

    This agent sends messages to an N8n workflow via webhook and processes
    the streaming response. N8n handles tool execution internally and returns
    plain text responses.

    Attributes:
        name: The agent name.
        description: A brief description of the agent.
        webhook_url: The N8n webhook URL to call. Falls back to N8N_WEBHOOK_URL env var.
        timeout: Request timeout in seconds (default: 120).
        headers: Optional custom HTTP headers for webhook authentication.

    Example:
        >>> import base64
        >>> agent = N8nAgent(
        ...     name="MyN8nAgent",
        ...     description="An agent powered by N8n",
        ...     webhook_url="https://n8n.example.com/webhook/chat",
        ...     headers={"Authorization": f"Basic {base64.b64encode(b'user:pass').decode()}"},
        ... )
        >>> async for event in agent.run(run_input):
        ...     print(event)
    """

    def __init__(
        self,
        name: str,
        description: str,
        webhook_url: Optional[str] = None,
        timeout: int = 120,
        headers: Optional[Dict[str, str]] = None,
    ):
        """Initialize the N8n agent.

        Args:
            name: The agent name.
            description: A brief description of the agent.
            webhook_url: The N8n webhook URL to call.
                Falls back to N8N_WEBHOOK_URL environment variable if not provided.
            timeout: Request timeout in seconds (default: 120).
            headers: Optional custom HTTP headers to send with webhook requests.
                Useful for n8n webhook authentication (Basic Auth, Header Auth, JWT).
        """
        super().__init__(name=name, description=description, agent=None)

        # Resolve webhook URL from parameter or environment variable
        final_webhook_url = webhook_url or os.environ.get("N8N_WEBHOOK_URL")

        # Validate webhook URL
        if not final_webhook_url or not isinstance(final_webhook_url, str) or not final_webhook_url.strip():
            raise ValueError(
                "webhook_url is required. Provide it as a parameter or set N8N_WEBHOOK_URL environment variable."
            )
        from urllib.parse import urlparse
        parsed = urlparse(final_webhook_url.strip())
        if parsed.scheme not in ("http", "https"):
            raise ValueError("webhook_url must use http or https scheme")

        self.webhook_url = final_webhook_url.strip()
        self.timeout = timeout
        self.headers = headers

    def _extract_parent_context(
        self, run_input: RunAgentInput
    ) -> Optional[SpanContext]:
        """Extract parent span context from forwarded_props.

        Args:
            run_input: The run input containing forwarded_props.

        Returns:
            The parent SpanContext if available, None otherwise.
        """
        if not HAS_OBSERVABILITY:
            return None

        try:
            forwarded_props = run_input.forwarded_props
            if not forwarded_props or not isinstance(forwarded_props, dict):
                return None
            server_context = forwarded_props.get("__agui_server_context")
            if server_context:
                from opentelemetry.trace import SpanContext, TraceFlags

                trace_id = int(server_context["trace_id"], 16)
                span_id = int(server_context["span_id"], 16)
                trace_flags = TraceFlags(server_context["trace_flags"])

                return SpanContext(
                    trace_id=trace_id,
                    span_id=span_id,
                    is_remote=True,
                    trace_flags=trace_flags,
                )
        except Exception:
            pass

        return None

    async def run(
        self,
        run_input: RunAgentInput,
    ) -> AsyncGenerator[Any, None]:
        """Run the agent with the given input.

        Sends messages to the N8n webhook and yields AG-UI events from
        the streaming response.

        Creates observability spans:
        - Adapter.N8n [CHAIN]: Container for the N8n adapter execution
        - N8n.Webhook [AGENT]: The actual webhook HTTP call

        Args:
            run_input: Input data for the agent execution.

        Yields:
            AG-UI events from the agent execution.

        Raises:
            httpx.HTTPError: If the HTTP request fails.
            TimeoutError: If the request times out.
        """
        with self.as_current():
            # Extract parent context from server if available
            parent_context = self._extract_parent_context(run_input)

            if HAS_OBSERVABILITY:
                # Create Adapter.n8n CHAIN span (matches TypeScript naming)
                try:
                    adapter_attributes = {
                        "input": {"messages": run_input.messages},
                        "metadata": {
                            "webhook_url": self.webhook_url,
                            "thread_id": run_input.thread_id,
                            "run_id": run_input.run_id,
                        },
                    }
                    adapter_obs = start_observation(
                        "Adapter.n8n",
                        adapter_attributes,
                        as_type="chain",
                        parent_span_context=parent_context,
                    )

                    try:
                        async for event in self._run_with_observability(
                            run_input, adapter_obs
                        ):
                            yield event
                    finally:
                        adapter_obs.end()
                except Exception:
                    # Observability failure should not block business flow - fallback
                    async for event in self._run_internal(run_input):
                        yield event
            else:
                async for event in self._run_internal(run_input):
                    yield event

    async def _run_with_observability(
        self,
        run_input: RunAgentInput,
        adapter_obs: Any,
    ) -> AsyncGenerator[Any, None]:
        """Run with observability spans wrapping the core business logic.

        Args:
            run_input: Input data for the agent execution.
            adapter_obs: The adapter observation for parent context.

        Yields:
            AG-UI events from the webhook execution.
        """
        # Get adapter span context as parent for webhook span
        adapter_span_context = adapter_obs.otel_span.get_span_context()

        # Create n8n Webhook AGENT span (matches TypeScript naming)
        inputs = n8n_prepare_inputs(run_input)
        webhook_attributes = {
            "input": inputs,
            "metadata": {
                "webhook_url": self.webhook_url,
                "timeout": self.timeout,
            },
        }
        webhook_obs = start_observation(
            "n8n Webhook",
            webhook_attributes,
            as_type="agent",
            parent_span_context=adapter_span_context,
        )

        full_response = []
        has_error = False

        try:
            async for event in self._run_internal(run_input):
                # Collect text content for observability output
                if (
                    hasattr(event, "type")
                    and event.type == EventType.TEXT_MESSAGE_CONTENT
                    and hasattr(event, "delta")
                ):
                    full_response.append(event.delta)

                # Track errors for span status
                if hasattr(event, "type") and event.type == EventType.RUN_ERROR:
                    has_error = True
                    error_msg = getattr(event, "message", "Unknown error")
                    webhook_obs.otel_span.set_status(Status(StatusCode.ERROR, error_msg))
                    webhook_obs.update(
                        {"output": {"error": error_msg}, "status_message": error_msg}
                    )

                yield event

            if not has_error:
                webhook_obs.update({"output": {"content": "".join(full_response)}})
        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            webhook_obs.otel_span.set_status(Status(StatusCode.ERROR, error_msg))
            webhook_obs.update(
                {"output": {"error": error_msg}, "status_message": error_msg}
            )
            raise
        finally:
            webhook_obs.end()

    async def _run_internal(
        self,
        run_input: RunAgentInput,
    ) -> AsyncGenerator[Any, None]:
        """Internal run logic without observability.

        Args:
            run_input: Input data for the agent execution.

        Yields:
            AG-UI events from the webhook execution.
        """
        # Prepare input data for N8n
        inputs = n8n_prepare_inputs(run_input)

        # Generate message_id for text events
        thread_id = run_input.thread_id or ""
        run_id = run_input.run_id
        message_id = f"{thread_id}:{run_id}"

        # Emit RUN_STARTED
        yield RunStartedEvent(
            type=EventType.RUN_STARTED,
            thread_id=thread_id,
            run_id=run_id,
        )

        # Emit STEP_STARTED
        yield StepStartedEvent(
            type=EventType.STEP_STARTED,
            step_name="webhook",
        )

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                request_headers = {"Accept": "text/event-stream"}
                if self.headers:
                    request_headers.update(self.headers)
                async with client.stream(
                    "POST",
                    self.webhook_url,
                    json=inputs,
                    headers=request_headers,
                ) as response:
                    response.raise_for_status()

                    # Process SSE stream
                    async for event in self._process_stream(
                        response, thread_id, run_id, message_id
                    ):
                        yield event

        except httpx.HTTPStatusError as e:
            yield RunErrorEvent(
                type=EventType.RUN_ERROR,
                thread_id=thread_id,
                run_id=run_id,
                message=f"HTTP error {e.response.status_code}: {str(e)}",
            )
            return
        except httpx.RequestError as e:
            yield RunErrorEvent(
                type=EventType.RUN_ERROR,
                thread_id=thread_id,
                run_id=run_id,
                message=f"Request error: {str(e)}",
            )
            return
        except Exception as e:
            yield RunErrorEvent(
                type=EventType.RUN_ERROR,
                thread_id=thread_id,
                run_id=run_id,
                message=f"Unexpected error: {str(e)}",
            )
            return

        # Emit STEP_FINISHED
        yield StepFinishedEvent(
            type=EventType.STEP_FINISHED,
            step_name="webhook",
        )

        # Emit RUN_FINISHED
        yield RunFinishedEvent(
            type=EventType.RUN_FINISHED,
            thread_id=thread_id,
            run_id=run_id,
        )

    async def _process_stream(
        self,
        response: httpx.Response,
        thread_id: str,
        run_id: str,
        message_id: str,
    ) -> AsyncGenerator[Any, None]:
        """Process the streaming response from N8n.

        N8n returns JSON Lines format where each line is a JSON object:
        - {"type": "begin", "metadata": {...}}
        - {"type": "item", "content": "...", "metadata": {...}}
        - {"type": "end", "metadata": {...}}

        We parse each line, extract content from "item" types, and convert to AG-UI events.
        Supports <think>...</think> tags for reasoning content (like DeepSeek-R1).

        Args:
            response: The HTTP streaming response.
            thread_id: The thread ID.
            run_id: The run ID.
            message_id: The message ID for text events.

        Yields:
            AG-UI events from the response stream.
        """
        # State tracking for think tag parsing
        in_thinking = False
        text_started = False
        thinking_started = False
        thinking_message_started = False
        buffer = ""  # Buffer for incomplete tags across items

        think_id = f"{message_id}-think"

        async for line in response.aiter_lines():
            # Skip empty lines
            if not line or not line.strip():
                continue

            try:
                # Parse JSON line
                event = json.loads(line.strip())
                event_type = event.get("type")

                # Only process "item" type events with content
                if event_type == "item":
                    content = event.get("content", "")
                    if not content:
                        continue

                    # Prepend any buffered incomplete tag from previous item
                    if buffer:
                        content = buffer + content
                        buffer = ""

                    # Process content with think tag parsing
                    remaining = content

                    while remaining:
                        if not in_thinking:
                            # Look for <think> tag start
                            think_start = remaining.find("<think>")
                            if think_start == -1:
                                # No think tag, treat as regular text
                                # But check if this might be an incomplete <think> tag at the end
                                if remaining.rfind("<") > remaining.rfind(">"):
                                    # Only buffer if it looks like a <think> prefix
                                    last_lt = remaining.rfind("<")
                                    potential = remaining[last_lt:]
                                    if potential in ("<", "<t", "<th", "<thi", "<thin", "<think"):
                                        buffer = potential
                                        remaining = remaining[:last_lt]
                                    if remaining:
                                        if not text_started:
                                            yield TextMessageStartEvent(
                                                type=EventType.TEXT_MESSAGE_START,
                                                message_id=message_id,
                                                role="assistant",
                                            )
                                            text_started = True
                                        yield TextMessageContentEvent(
                                            type=EventType.TEXT_MESSAGE_CONTENT,
                                            message_id=message_id,
                                            delta=remaining,
                                        )
                                else:
                                    if remaining:
                                        if not text_started:
                                            yield TextMessageStartEvent(
                                                type=EventType.TEXT_MESSAGE_START,
                                                message_id=message_id,
                                                role="assistant",
                                            )
                                            text_started = True
                                        yield TextMessageContentEvent(
                                            type=EventType.TEXT_MESSAGE_CONTENT,
                                            message_id=message_id,
                                            delta=remaining,
                                        )
                                remaining = ""
                            else:
                                # Found <think> tag
                                # First, emit any text before the tag
                                before_think = remaining[:think_start]
                                if before_think:
                                    if before_think.isspace():
                                        # Whitespace before think is just formatting,
                                        # but we need to close any open text message
                                        if text_started:
                                            yield TextMessageEndEvent(
                                                type=EventType.TEXT_MESSAGE_END,
                                                message_id=message_id,
                                            )
                                            text_started = False
                                    else:
                                        # Non-whitespace content before think
                                        if not text_started:
                                            yield TextMessageStartEvent(
                                                type=EventType.TEXT_MESSAGE_START,
                                                message_id=message_id,
                                                role="assistant",
                                            )
                                            text_started = True
                                        yield TextMessageContentEvent(
                                            type=EventType.TEXT_MESSAGE_CONTENT,
                                            message_id=message_id,
                                            delta=before_think,
                                        )

                                # End any open text message before starting thinking
                                if text_started:
                                    yield TextMessageEndEvent(
                                        type=EventType.TEXT_MESSAGE_END,
                                        message_id=message_id,
                                    )
                                    text_started = False

                                # Start thinking section
                                in_thinking = True
                                remaining = remaining[think_start + 7:]  # Skip "<think>"

                                if not thinking_started:
                                    yield ThinkingStartEvent(
                                        type=EventType.THINKING_START,
                                        message_id=think_id,
                                    )
                                    thinking_started = True

                                if not thinking_message_started:
                                    yield ThinkingTextMessageStartEvent(
                                        type=EventType.THINKING_TEXT_MESSAGE_START,
                                        message_id=think_id,
                                        role="assistant",
                                    )
                                    thinking_message_started = True
                        else:
                            # Inside thinking section, look for </think> end
                            think_end = remaining.find("</think>")
                            if think_end == -1:
                                # Still in thinking, emit all as thinking content
                                # Check for incomplete </think> tag at the end
                                if remaining.rfind("<") > remaining.rfind(">"):
                                    last_lt = remaining.rfind("<")
                                    potential = remaining[last_lt:]
                                    if potential in ("<", "</", "</t", "</th", "</thi", "</thin", "</think"):
                                        buffer = potential
                                        remaining = remaining[:last_lt]
                                    if remaining:
                                        if not thinking_message_started:
                                            yield ThinkingTextMessageStartEvent(
                                                type=EventType.THINKING_TEXT_MESSAGE_START,
                                                message_id=think_id,
                                                role="assistant",
                                            )
                                            thinking_message_started = True
                                        yield ThinkingTextMessageContentEvent(
                                            type=EventType.THINKING_TEXT_MESSAGE_CONTENT,
                                            message_id=think_id,
                                            delta=remaining,
                                        )
                                else:
                                    if remaining:
                                        if not thinking_message_started:
                                            yield ThinkingTextMessageStartEvent(
                                                type=EventType.THINKING_TEXT_MESSAGE_START,
                                                message_id=think_id,
                                                role="assistant",
                                            )
                                            thinking_message_started = True
                                        yield ThinkingTextMessageContentEvent(
                                            type=EventType.THINKING_TEXT_MESSAGE_CONTENT,
                                            message_id=think_id,
                                            delta=remaining,
                                        )
                                remaining = ""
                            else:
                                # Found </think> tag end
                                think_content = remaining[:think_end]
                                if think_content:
                                    if not thinking_message_started:
                                        yield ThinkingTextMessageStartEvent(
                                            type=EventType.THINKING_TEXT_MESSAGE_START,
                                            message_id=think_id,
                                            role="assistant",
                                        )
                                        thinking_message_started = True
                                    yield ThinkingTextMessageContentEvent(
                                        type=EventType.THINKING_TEXT_MESSAGE_CONTENT,
                                        message_id=think_id,
                                        delta=think_content,
                                    )

                                # End thinking message and thinking section
                                yield ThinkingTextMessageEndEvent(
                                    type=EventType.THINKING_TEXT_MESSAGE_END,
                                    message_id=think_id,
                                )
                                thinking_message_started = False

                                yield ThinkingEndEvent(
                                    type=EventType.THINKING_END,
                                    message_id=think_id,
                                )
                                in_thinking = False
                                thinking_started = False

                                # Close current text message before starting new one
                                if text_started:
                                    yield TextMessageEndEvent(
                                        type=EventType.TEXT_MESSAGE_END,
                                        message_id=message_id,
                                    )
                                    text_started = False

                                remaining = remaining[think_end + 8:]  # Skip "</think>"

                                # Skip leading whitespace/newlines after </think> - they are just formatting, not content
                                remaining = remaining.lstrip("\n\r\t ")

                # Ignore "begin" and "end" types (metadata only)
                elif event_type in ("begin", "end"):
                    continue

            except json.JSONDecodeError:
                logger.warning("Failed to parse n8n response line: %s", line)
                continue

        # Stream ended - clean up any remaining state
        if buffer:
            # Handle any remaining buffered content
            if in_thinking:
                if not thinking_message_started:
                    yield ThinkingTextMessageStartEvent(
                        type=EventType.THINKING_TEXT_MESSAGE_START,
                        message_id=think_id,
                        role="assistant",
                    )
                    thinking_message_started = True
                yield ThinkingTextMessageContentEvent(
                    type=EventType.THINKING_TEXT_MESSAGE_CONTENT,
                    message_id=think_id,
                    delta=buffer,
                )
            else:
                if not text_started:
                    yield TextMessageStartEvent(
                        type=EventType.TEXT_MESSAGE_START,
                        message_id=message_id,
                        role="assistant",
                    )
                    text_started = True
                yield TextMessageContentEvent(
                    type=EventType.TEXT_MESSAGE_CONTENT,
                    message_id=message_id,
                    delta=buffer,
                )

        # Close any unclosed thinking section (boundary condition: incomplete think tag)
        if thinking_message_started:
            yield ThinkingTextMessageEndEvent(
                type=EventType.THINKING_TEXT_MESSAGE_END,
                message_id=think_id,
            )
        if thinking_started:
            yield ThinkingEndEvent(
                type=EventType.THINKING_END,
                message_id=think_id,
            )

        # Close text message if started
        if text_started:
            yield TextMessageEndEvent(
                type=EventType.TEXT_MESSAGE_END,
                message_id=message_id,
            )
        elif not thinking_started:
            # Handle empty response (no content at all)
            yield TextMessageStartEvent(
                type=EventType.TEXT_MESSAGE_START,
                message_id=message_id,
                role="assistant",
            )
            yield TextMessageContentEvent(
                type=EventType.TEXT_MESSAGE_CONTENT,
                message_id=message_id,
                delta="No response from N8n workflow.",
            )
            yield TextMessageEndEvent(
                type=EventType.TEXT_MESSAGE_END,
                message_id=message_id,
            )
