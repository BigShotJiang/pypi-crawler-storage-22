"""N8n Event Converters.

This module provides utility functions for converting between N8n webhook
request/response formats and AG-UI event formats.
"""

from typing import Any, Generator

from ag_ui.core import RunAgentInput
from ag_ui.core.events import (
    EventType,
    TextMessageContentEvent,
    TextMessageEndEvent,
    TextMessageStartEvent,
    ThinkingEndEvent,
    ThinkingStartEvent,
    ThinkingTextMessageContentEvent,
    ThinkingTextMessageEndEvent,
    ThinkingTextMessageStartEvent,
)


def n8n_prepare_inputs(run_input: RunAgentInput) -> dict[str, Any]:
    """Prepare input data for N8n webhook request.

    Converts RunAgentInput into the format expected by N8n AI Agent webhooks.
    N8n Chat Trigger expects 'chatInput' and 'sessionId' fields.

    Args:
        run_input: Input data for the agent execution.

    Returns:
        Dictionary containing the prepared input data for N8n.

    Example:
        >>> run_input = RunAgentInput(
        ...     messages=[{"role": "user", "content": "Hello!"}],
        ...     thread_id="thread-123",
        ...     run_id="run-456",
        ... )
        >>> inputs = n8n_prepare_inputs(run_input)
        >>> print(inputs)
        {
            'chatInput': 'Hello!',
            'sessionId': 'thread-123',
        }
    """
    # Extract the last user message as chatInput
    chat_input = ""
    for msg in reversed(run_input.messages):
        msg_dict = None
        if hasattr(msg, "model_dump"):
            msg_dict = msg.model_dump(exclude_none=True)
        elif hasattr(msg, "__dict__"):
            msg_dict = msg.__dict__
        elif isinstance(msg, dict):
            msg_dict = msg
        else:
            msg_dict = dict(msg)

        if msg_dict.get("role") == "user":
            content = msg_dict.get("content", "")
            chat_input = content if isinstance(content, str) else str(content)
            break

    inputs: dict[str, Any] = {
        "chatInput": chat_input,
    }

    # Use thread_id as sessionId for maintaining conversation context
    if run_input.thread_id:
        inputs["sessionId"] = run_input.thread_id

    return inputs


def parse_think_tags(
    content: str,
    message_id: str,
) -> Generator[Any, None, None]:
    """Parse content with <think>...</think> tags and yield AG-UI events.

    Handles both thinking content (inside <think> tags) and regular text content.
    Supports incomplete/malformed tags at boundaries.

    Args:
        content: The content string potentially containing <think> tags.
        message_id: The message ID for text events.

    Yields:
        AG-UI events for text and thinking content.

    Example:
        >>> content = "<think>Let me think...</think>Hello!"
        >>> events = list(parse_think_tags(content, "msg-123"))
        >>> # Yields: ThinkingStartEvent, ThinkingTextMessageStartEvent,
        >>> #         ThinkingTextMessageContentEvent ("Let me think..."),
        >>> #         ThinkingTextMessageEndEvent, ThinkingEndEvent,
        >>> #         TextMessageStartEvent, TextMessageContentEvent ("Hello!"),
        >>> #         TextMessageEndEvent
    """
    think_id = f"{message_id}-think"
    in_thinking = False
    text_started = False
    thinking_started = False
    thinking_message_started = False
    remaining = content

    while remaining:
        if not in_thinking:
            # Look for <think> tag start
            think_start = remaining.find("<think>")
            if think_start == -1:
                # No think tag, treat as regular text
                if remaining:
                    if not text_started:
                        yield TextMessageStartEvent(
                            type=EventType.TEXT_MESSAGE_START,
                            message_id=message_id,
                            role="assistant",
                        )
                        text_started = True
                    yield TextMessageContentEvent(
                        type=EventType.TEXT_MESSAGE_CONTENT,
                        message_id=message_id,
                        delta=remaining,
                    )
                remaining = ""
            else:
                # Found <think> tag
                # First, emit any text before the tag
                before_think = remaining[:think_start]
                if before_think:
                    if not text_started:
                        yield TextMessageStartEvent(
                            type=EventType.TEXT_MESSAGE_START,
                            message_id=message_id,
                            role="assistant",
                        )
                        text_started = True
                    yield TextMessageContentEvent(
                        type=EventType.TEXT_MESSAGE_CONTENT,
                        message_id=message_id,
                        delta=before_think,
                    )
                    # End the text message before starting thinking
                    yield TextMessageEndEvent(
                        type=EventType.TEXT_MESSAGE_END,
                        message_id=message_id,
                    )
                    text_started = False

                # Start thinking section
                in_thinking = True
                remaining = remaining[think_start + 7:]  # Skip "<think>"

                if not thinking_started:
                    yield ThinkingStartEvent(
                        type=EventType.THINKING_START,
                        message_id=think_id,
                    )
                    thinking_started = True

                if not thinking_message_started:
                    yield ThinkingTextMessageStartEvent(
                        type=EventType.THINKING_TEXT_MESSAGE_START,
                        message_id=think_id,
                        role="assistant",
                    )
                    thinking_message_started = True
        else:
            # Inside thinking section, look for </think> end
            think_end = remaining.find("</think>")
            if think_end == -1:
                # Still in thinking, emit all as thinking content
                if remaining:
                    yield ThinkingTextMessageContentEvent(
                        type=EventType.THINKING_TEXT_MESSAGE_CONTENT,
                        message_id=think_id,
                        delta=remaining,
                    )
                remaining = ""
            else:
                # Found </think> tag end
                think_content = remaining[:think_end]
                if think_content:
                    yield ThinkingTextMessageContentEvent(
                        type=EventType.THINKING_TEXT_MESSAGE_CONTENT,
                        message_id=think_id,
                        delta=think_content,
                    )

                # End thinking message and thinking section
                yield ThinkingTextMessageEndEvent(
                    type=EventType.THINKING_TEXT_MESSAGE_END,
                    message_id=think_id,
                )
                thinking_message_started = False

                yield ThinkingEndEvent(
                    type=EventType.THINKING_END,
                    message_id=think_id,
                )
                in_thinking = False
                thinking_started = False

                remaining = remaining[think_end + 8:]  # Skip "</think>"

                # Skip leading whitespace/newlines after </think> - they are just formatting, not content
                remaining = remaining.lstrip("\n\r\t ")

    # Close any unclosed sections (boundary condition handling)
    if thinking_message_started:
        yield ThinkingTextMessageEndEvent(
            type=EventType.THINKING_TEXT_MESSAGE_END,
            message_id=think_id,
        )
    if thinking_started:
        yield ThinkingEndEvent(
            type=EventType.THINKING_END,
            message_id=think_id,
        )
    if text_started:
        yield TextMessageEndEvent(
            type=EventType.TEXT_MESSAGE_END,
            message_id=message_id,
        )


def n8n_events_to_ag_ui_events(
    n8n_response: str,
    thread_id: str,
    run_id: str,
    message_id: str,
) -> list[dict[str, Any]]:
    """Convert N8n response text to AG-UI events.

    Parses a raw N8n response (typically from a non-streaming call)
    and converts it into a list of AG-UI format events.
    Supports <think>...</think> tags for reasoning content.

    Args:
        n8n_response: The raw text response from N8n.
        thread_id: The thread ID.
        run_id: The run ID.
        message_id: The message ID for text events.

    Returns:
        List of AG-UI event dictionaries.

    Example:
        >>> events = n8n_events_to_ag_ui_events(
        ...     "Hello, how can I help?",
        ...     "thread-123",
        ...     "run-456",
        ...     "thread-123:run-456",
        ... )
        >>> print(events)
        [
            {'type': 'run_started', 'thread_id': 'thread-123', 'run_id': 'run-456'},
            {'type': 'step_started', 'step_name': 'webhook'},
            {'type': 'text_message_start', 'message_id': 'thread-123:run-456', 'role': 'assistant'},
            {'type': 'text_message_content', 'message_id': 'thread-123:run-456', 'delta': 'Hello, how can I help?'},
            {'type': 'text_message_end', 'message_id': 'thread-123:run-456'},
            {'type': 'step_finished', 'step_name': 'webhook'},
            {'type': 'run_finished', 'thread_id': 'thread-123', 'run_id': 'run-456'},
        ]
    """
    events: list[dict[str, Any]] = []

    # Run started
    events.append({
        "type": "run_started",
        "thread_id": thread_id,
        "run_id": run_id,
    })

    # Step started
    events.append({
        "type": "step_started",
        "step_name": "webhook",
    })

    # Parse content with think tag support
    if n8n_response.strip():
        for event in parse_think_tags(n8n_response, message_id):
            # Convert event objects to dictionaries
            event_dict = {"type": event.type.value}
            if hasattr(event, "thread_id"):
                event_dict["thread_id"] = event.thread_id
            if hasattr(event, "run_id"):
                event_dict["run_id"] = event.run_id
            if hasattr(event, "message_id"):
                event_dict["message_id"] = event.message_id
            if hasattr(event, "role"):
                event_dict["role"] = event.role
            if hasattr(event, "delta"):
                event_dict["delta"] = event.delta
            events.append(event_dict)
    else:
        # Empty response handling
        events.append({
            "type": "text_message_start",
            "message_id": message_id,
            "role": "assistant",
        })
        events.append({
            "type": "text_message_content",
            "message_id": message_id,
            "delta": "No response from N8n workflow.",
        })
        events.append({
            "type": "text_message_end",
            "message_id": message_id,
        })

    # Step finished
    events.append({
        "type": "step_finished",
        "step_name": "webhook",
    })

    # Run finished
    events.append({
        "type": "run_finished",
        "thread_id": thread_id,
        "run_id": run_id,
    })

    return events
