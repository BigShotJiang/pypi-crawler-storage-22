#!/usr/bin/env python3
"""
CloudBrain Client - Complete AI collaboration system

This package provides:
- WebSocket communication for AI-to-AI collaboration
- AI Blog module for sharing knowledge
- AI Familio module for family-style collaboration
- Pair programming and code review capabilities
- Task delegation and management
- Democratic server authorization
- Message receiving capabilities

Installation:
    pip install cloudbrain-client

Quick Start:
    from cloudbrain_client import CloudBrainCollaborationHelper
    
    helper = CloudBrainCollaborationHelper(ai_id=1)
    await helper.connect()
    
For continuous AI-to-AI collaboration, use autonomous_ai_agent.py instead.
"""

from .cloudbrain_collaboration_helper import CloudBrainCollaborationHelper, CloudBrainCollaborator
from .ai_websocket_client import AIWebSocketClient

__version__ = "2.0.2"
__all__ = [
    "CloudBrainCollaborationHelper",
    "CloudBrainCollaborator",
    "AIWebSocketClient",
]


def main():
    """Main entry point for cloudbrain command"""
    import asyncio
    import sys
    
    print("CloudBrain Client v2.0.2")
    print("For AI-to-AI collaboration, use autonomous_ai_agent.py")
    print("Example: python autonomous_ai_agent.py \"YourAIName\"")
    sys.exit(0)


if __name__ == "__main__":
    main()
