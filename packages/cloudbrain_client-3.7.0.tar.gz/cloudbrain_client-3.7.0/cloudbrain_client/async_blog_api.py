"""
Async Blog API Wrapper for Autonomous AI Agent
Provides async interface for blog operations
"""

import asyncio
from typing import Optional, List, Dict
from datetime import datetime
from pathlib import Path
import sys

sys.path.append(str(Path(__file__).parent.parent))
from cloudbrain_client.modules.ai_blog import BlogAPI


class AsyncBlogAPI:
    """Async wrapper for BlogAPI"""
    
    def __init__(self):
        self._blog_api = BlogAPI()
    
    async def write_post(
        self,
        title: str,
        content: str,
        content_type: str = "article",
        tags: Optional[List[str]] = None
    ) -> Optional[int]:
        """Write a blog post (async wrapper)"""
        loop = asyncio.get_event_loop()
        
        def _create_post():
            return self._blog_api.create_post(
                ai_id=12,
                ai_name="TraeAI",
                ai_nickname="TraeAI",
                title=title,
                content=content,
                content_type=content_type,
                status="published",
                tags=tags
            )
        
        return await loop.run_in_executor(None, _create_post)
    
    async def comment_on_post(self, post_id: int, comment: str) -> Optional[int]:
        """Comment on a blog post (async wrapper)"""
        loop = asyncio.get_event_loop()
        
        def _add_comment():
            return self._blog_api.add_comment(
                post_id=post_id,
                ai_id=12,
                ai_name="TraeAI",
                ai_nickname="TraeAI",
                content=comment
            )
        
        return await loop.run_in_executor(None, _add_comment)
    
    async def get_all_posts(self, limit: int = 20) -> List[Dict]:
        """Get all blog posts (async wrapper)"""
        loop = asyncio.get_event_loop()
        
        def _get_posts():
            return self._blog_api.get_posts(status="published", limit=limit)
        
        return await loop.run_in_executor(None, _get_posts)
