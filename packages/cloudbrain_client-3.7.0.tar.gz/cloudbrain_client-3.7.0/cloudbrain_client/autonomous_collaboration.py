"""
🤝 Autonomous Collaboration Helper Module

This module provides functions for autonomous AI agents to collaborate
through the database without human intervention.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Boolean, ARRAY, or_
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.dialects.postgresql import array
from datetime import datetime
import json

Base = declarative_base()


class AutonomousTasks(Base):
    """Model for autonomous_tasks table"""
    __tablename__ = 'autonomous_tasks'

    id = Column(Integer, primary_key=True, autoincrement=True)
    from_ai_id = Column(Integer, nullable=False)
    to_ai_id = Column(Integer, nullable=False)
    task_type = Column(String(50), nullable=False)
    task_data = Column(Text, nullable=False)
    priority = Column(Integer, default=5)
    status = Column(String(20), default='pending')
    created_at = Column(DateTime, nullable=False)
    assigned_at = Column(DateTime, nullable=True)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    result = Column(Text, nullable=True)

    def __repr__(self):
        return f"<AutonomousTasks(id={self.id}, from={self.from_ai_id}, to={self.to_ai_id}, type={self.task_type}, status={self.status})>"


class AICodeStorage(Base):
    """Model for ai_code_storage table"""
    __tablename__ = 'ai_code_storage'

    id = Column(Integer, primary_key=True, autoincrement=True)
    ai_id = Column(Integer, nullable=False)
    file_path = Column(String(255), nullable=False)
    file_content = Column(Text, nullable=False)
    version = Column(Integer, default=1)
    status = Column(String(20), default='draft')
    created_at = Column(DateTime, nullable=False)
    updated_at = Column(DateTime, nullable=False)
    approved_by = Column(Integer, nullable=True)
    approved_at = Column(DateTime, nullable=True)

    def __repr__(self):
        return f"<AICodeStorage(id={self.id}, ai_id={self.ai_id}, path={self.file_path}, version={self.version}, status={self.status})>"


class CodeReviews(Base):
    """Model for code_reviews table"""
    __tablename__ = 'code_reviews'

    id = Column(Integer, primary_key=True, autoincrement=True)
    code_id = Column(Integer, nullable=False)
    reviewer_ai_id = Column(Integer, nullable=False)
    review_type = Column(String(50), nullable=False)
    feedback = Column(Text, nullable=False)
    rating = Column(Integer, nullable=True)
    approved = Column(Boolean, nullable=True)
    created_at = Column(DateTime, nullable=False)

    def __repr__(self):
        return f"<CodeReviews(id={self.id}, code_id={self.code_id}, reviewer={self.reviewer_ai_id}, approved={self.approved})>"


class CollaborationSessions(Base):
    """Model for collaboration_sessions table"""
    __tablename__ = 'collaboration_sessions'

    id = Column(Integer, primary_key=True, autoincrement=True)
    session_name = Column(String(100), nullable=True)
    participants = Column(ARRAY(Integer), nullable=True)
    started_at = Column(DateTime, nullable=False)
    ended_at = Column(DateTime, nullable=True)
    status = Column(String(20), default='active')
    total_tasks = Column(Integer, default=0)
    completed_tasks = Column(Integer, default=0)

    def __repr__(self):
        return f"<CollaborationSessions(id={self.id}, name={self.session_name}, status={self.status}, tasks={self.completed_tasks}/{self.total_tasks})>"


def get_session():
    """Get database session"""
    POSTGRES_HOST = os.getenv('POSTGRES_HOST', 'localhost')
    POSTGRES_PORT = os.getenv('POSTGRES_PORT', '5432')
    POSTGRES_DB = os.getenv('POSTGRES_DB', 'cloudbrain')
    POSTGRES_USER = os.getenv('POSTGRES_USER', 'jk')
    POSTGRES_PASSWORD = os.getenv('POSTGRES_PASSWORD', '')

    database_url = f"postgresql+psycopg2://{POSTGRES_USER}:{POSTGRES_PASSWORD}@{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}"
    engine = create_engine(database_url)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    return Session()


def create_task(from_ai_id, to_ai_id, task_type, task_data, priority=5):
    """Create a new task for another AI"""
    
    session = get_session()
    
    task = AutonomousTasks(
        from_ai_id=from_ai_id,
        to_ai_id=to_ai_id,
        task_type=task_type,
        task_data=json.dumps(task_data),
        priority=priority,
        status='pending',
        created_at=datetime.now()
    )
    
    session.add(task)
    session.commit()
    
    task_id = task.id
    session.close()
    
    return task_id


def get_pending_tasks(ai_id):
    """Get all pending tasks for an AI"""
    
    session = get_session()
    
    tasks = session.query(AutonomousTasks).filter_by(
        to_ai_id=ai_id,
        status='pending'
    ).order_by(AutonomousTasks.priority.desc(), AutonomousTasks.created_at).all()
    
    task_list = []
    for task in tasks:
        task_list.append({
            'id': task.id,
            'from_ai_id': task.from_ai_id,
            'task_type': task.task_type,
            'task_data': json.loads(task.task_data),
            'priority': task.priority,
            'created_at': task.created_at
        })
    
    session.close()
    
    return task_list


def start_task(task_id):
    """Mark a task as started"""
    
    session = get_session()
    
    task = session.query(AutonomousTasks).filter_by(id=task_id).first()
    
    if task:
        task.status = 'in_progress'
        task.started_at = datetime.now()
        session.commit()
        
    session.close()


def complete_task(task_id, result):
    """Mark a task as completed with result"""
    
    session = get_session()
    
    task = session.query(AutonomousTasks).filter_by(id=task_id).first()
    
    if task:
        task.status = 'completed'
        task.completed_at = datetime.now()
        task.result = json.dumps(result)
        session.commit()
        
    session.close()


def store_code(ai_id, file_path, file_content, status='draft'):
    """Store code in the database"""
    
    session = get_session()
    
    code = AICodeStorage(
        ai_id=ai_id,
        file_path=file_path,
        file_content=file_content,
        status=status,
        created_at=datetime.now(),
        updated_at=datetime.now()
    )
    
    session.add(code)
    session.commit()
    
    code_id = code.id
    session.close()
    
    return code_id


def get_code(code_id):
    """Get code from database"""
    
    session = get_session()
    
    code = session.query(AICodeStorage).filter_by(id=code_id).first()
    
    if code:
        result = {
            'id': code.id,
            'ai_id': code.ai_id,
            'file_path': code.file_path,
            'file_content': code.file_content,
            'version': code.version,
            'status': code.status,
            'created_at': code.created_at,
            'updated_at': code.updated_at
        }
        session.close()
        return result
    
    session.close()
    return None


def review_code(code_id, reviewer_ai_id, review_type, feedback, rating=None, approved=None):
    """Add a code review"""
    
    session = get_session()
    
    review = CodeReviews(
        code_id=code_id,
        reviewer_ai_id=reviewer_ai_id,
        review_type=review_type,
        feedback=feedback,
        rating=rating,
        approved=approved,
        created_at=datetime.now()
    )
    
    session.add(review)
    session.commit()
    
    review_id = review.id
    session.close()
    
    return review_id


def get_code_reviews(code_id):
    """Get all reviews for a code"""
    
    session = get_session()
    
    reviews = session.query(CodeReviews).filter_by(code_id=code_id).all()
    
    review_list = []
    for review in reviews:
        review_list.append({
            'id': review.id,
            'code_id': review.code_id,
            'reviewer_ai_id': review.reviewer_ai_id,
            'review_type': review.review_type,
            'feedback': review.feedback,
            'rating': review.rating,
            'approved': review.approved,
            'created_at': review.created_at
        })
    
    session.close()
    
    return review_list


def create_collaboration_session(session_name, participants):
    """Create a new collaboration session"""
    
    session = get_session()
    
    collab_session = CollaborationSessions(
        session_name=session_name,
        participants=participants,
        started_at=datetime.now(),
        status='active'
    )
    
    session.add(collab_session)
    session.commit()
    
    session_id = collab_session.id
    session.close()
    
    return session_id


def update_collaboration_session(session_id, total_tasks=None, completed_tasks=None, status=None):
    """Update collaboration session"""
    
    session = get_session()
    
    collab_session = session.query(CollaborationSessions).filter_by(id=session_id).first()
    
    if collab_session:
        if total_tasks is not None:
            collab_session.total_tasks = total_tasks
        if completed_tasks is not None:
            collab_session.completed_tasks = completed_tasks
        if status is not None:
            collab_session.status = status
            if status == 'completed':
                collab_session.ended_at = datetime.now()
        
        session.commit()
        
    session.close()


def get_active_collaboration_sessions(ai_id):
    """Get active collaboration sessions for an AI"""
    
    session = get_session()
    
    sessions = session.query(CollaborationSessions).filter(
        CollaborationSessions.status == 'active'
    ).all()
    
    session_list = []
    for collab_session in sessions:
        if collab_session.participants and ai_id in collab_session.participants:
            session_list.append({
                'id': collab_session.id,
                'session_name': collab_session.session_name,
                'participants': collab_session.participants,
                'started_at': collab_session.started_at,
                'status': collab_session.status,
                'total_tasks': collab_session.total_tasks,
                'completed_tasks': collab_session.completed_tasks
            })
    
    session.close()
    
    return session_list


def get_ai_name(ai_id):
    """Get AI name by ID (placeholder - should be implemented with proper AI registry)"""
    
    ai_names = {
        12: 'TraeAI',
        13: 'CodeRider'
    }
    
    return ai_names.get(ai_id, f'AI {ai_id}')
