#!/usr/bin/env python3
"""
Brain State Stability Fixes
Critical fixes for brain state management stability issues

This file contains patches to fix identified stability issues:
1. Database connection management - Use context managers
2. Git tracker error handling - Wrap in try-except
3. Session identifier handling - Generate default if None
4. Progress data validation - Validate JSON serialization
5. Error handling standardization - Consistent error handling
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List
import logging

# Configure logging
logger = logging.getLogger(__name__)


def patch_brain_state_with_stability_fixes():
    """
    Apply stability fixes to BrainState class
    
    This function returns a patched version of BrainState with:
    - Proper database connection management
    - Git tracker error handling
    - Session identifier generation
    - Progress data validation
    - Standardized error handling
    """
    
    from cloudbrain_client.db_config import get_db_connection, is_postgres
    from cloudbrain_client.git_tracker import GitTracker
    
    class BrainStateStable:
        """
        Stable Brain State Manager with improved error handling
        
        Key improvements:
        - Context managers for database connections
        - Git tracker error handling
        - Automatic session identifier generation
        - Progress data validation
        - Consistent error handling
        """
        
        def __init__(self, ai_id: int, nickname: str, db_path: Optional[str] = None, session_identifier: Optional[str] = None):
            """
            Initialize brain state manager
            
            Args:
                ai_id: Your AI ID (required)
                nickname: Your AI nickname (required)
                db_path: Optional database path (auto-detected if not provided)
                session_identifier: Optional session identifier for this session
            """
            self.ai_id = ai_id
            self.nickname = nickname
            
            # Generate session identifier if not provided
            if session_identifier is None:
                session_identifier = self._generate_session_identifier()
            
            self.session_identifier = session_identifier
            
            if db_path is None:
                project_root = Path(__file__).parent.parent
                db_path = project_root / "server" / "ai_db" / "cloudbrain.db"
            
            self.db_path = db_path
            self.git_tracker = GitTracker()
            self.current_state = {
                'current_task': '',
                'last_thought': '',
                'last_insight': '',
                'current_cycle': 0,
                'cycle_count': 0,
                'total_thoughts': 0,
                'total_responses': 0,
                'total_collaborations': 0,
                'session_ended': False
            }
            
            # Ensure tables exist with retry logic
            self._ensure_tables_exist_with_retry()
        
        def _generate_session_identifier(self) -> str:
            """Generate a unique session identifier"""
            import hashlib
            timestamp = datetime.now().isoformat()
            session_data = f"{self.ai_id}-{self.nickname}-{timestamp}"
            return hashlib.sha1(session_data.encode()).hexdigest()[:16]
        
        def _ensure_tables_exist_with_retry(self, max_retries: int = 3):
            """Ensure brain state tables exist with retry logic"""
            for attempt in range(max_retries):
                try:
                    self._ensure_tables_exist()
                    return
                except Exception as e:
                    if attempt < max_retries - 1:
                        logger.warning(f"Table creation attempt {attempt + 1} failed: {e}, retrying...")
                        import time
                        time.sleep(0.5 * (attempt + 1))
                    else:
                        logger.error(f"Failed to create tables after {max_retries} attempts: {e}")
                        raise
        
        def _ensure_tables_exist(self):
            """Ensure brain state tables exist in database"""
            with get_db_connection() as conn:
                cursor = conn.cursor()
                
                if not is_postgres():
                    sessions_table_sql = """
                        CREATE TABLE IF NOT EXISTS ai_brain_sessions (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            ai_id INTEGER NOT NULL,
                            session_type TEXT DEFAULT 'autonomous',
                            start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            end_time TIMESTAMP,
                            stats TEXT,
                            brain_dump TEXT,
                            FOREIGN KEY (ai_id) REFERENCES ai_profiles(id)
                        )
                    """
                    current_state_table_sql = """
                        CREATE TABLE IF NOT EXISTS ai_current_state (
                            ai_id INTEGER PRIMARY KEY,
                            current_task TEXT,
                            last_thought TEXT,
                            last_insight TEXT,
                            current_cycle INTEGER,
                            cycle_count INTEGER,
                            last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            session_id INTEGER,
                            brain_dump TEXT,
                            checkpoint_data TEXT,
                            session_identifier TEXT,
                            FOREIGN KEY (ai_id) REFERENCES ai_profiles(id),
                            FOREIGN KEY (session_id) REFERENCES ai_brain_sessions(id)
                        )
                    """
                    # Add indexes
                    index_sql = """
                        CREATE INDEX IF NOT EXISTS idx_brain_sessions_ai_id 
                        ON ai_brain_sessions(ai_id);
                        CREATE INDEX IF NOT EXISTS idx_brain_sessions_start_time 
                        ON ai_brain_sessions(start_time);
                        CREATE INDEX IF NOT EXISTS idx_current_state_session_identifier 
                        ON ai_current_state(session_identifier);
                    """
                else:
                    sessions_table_sql = """
                        CREATE TABLE IF NOT EXISTS ai_brain_sessions (
                            id SERIAL PRIMARY KEY,
                            ai_id INTEGER NOT NULL,
                            session_type TEXT DEFAULT 'autonomous',
                            start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            end_time TIMESTAMP,
                            stats TEXT,
                            brain_dump TEXT,
                            FOREIGN KEY (ai_id) REFERENCES ai_profiles(id)
                        )
                    """
                    current_state_table_sql = """
                        CREATE TABLE IF NOT EXISTS ai_current_state (
                            ai_id INTEGER PRIMARY KEY,
                            current_task TEXT,
                            last_thought TEXT,
                            last_insight TEXT,
                            current_cycle INTEGER,
                            cycle_count INTEGER,
                            last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            session_id INTEGER,
                            brain_dump TEXT,
                            checkpoint_data TEXT,
                            session_identifier TEXT,
                            FOREIGN KEY (ai_id) REFERENCES ai_profiles(id),
                            FOREIGN KEY (session_id) REFERENCES ai_brain_sessions(id)
                        )
                    """
                    # Add indexes
                    index_sql = """
                        CREATE INDEX IF NOT EXISTS idx_brain_sessions_ai_id 
                        ON ai_brain_sessions(ai_id);
                        CREATE INDEX IF NOT EXISTS idx_brain_sessions_start_time 
                        ON ai_brain_sessions(start_time);
                        CREATE INDEX IF NOT EXISTS idx_current_state_session_identifier 
                        ON ai_current_state(session_identifier);
                    """
                
                cursor.execute(sessions_table_sql)
                cursor.execute(current_state_table_sql)
                
                # Execute index creation
                for index_statement in index_sql.split(';'):
                    index_statement = index_statement.strip()
                    if index_statement:
                        try:
                            cursor.execute(index_statement)
                        except Exception as e:
                            # Index may already exist, ignore error
                            logger.debug(f"Index creation note: {e}")
                
                conn.commit()
        
        def _get_git_info(self) -> Dict[str, Any]:
            """
            Get git information with error handling
            
            Returns:
                Dictionary with git_hash, modified_files, added_files, deleted_files
            """
            try:
                git_hash = self.git_tracker.get_git_hash()
                git_status = self.git_tracker.get_status()
                
                return {
                    'git_hash': git_hash,
                    'modified_files': git_status.get('modified', []),
                    'added_files': git_status.get('added', []),
                    'deleted_files': git_status.get('deleted', [])
                }
            except Exception as e:
                logger.warning(f"Git tracker error: {e}, using defaults")
                return {
                    'git_hash': None,
                    'modified_files': [],
                    'added_files': [],
                    'deleted_files': []
                }
        
        def _validate_progress_data(self, progress: Optional[Dict[str, Any]]) -> Dict[str, Any]:
            """
            Validate progress data is JSON serializable
            
            Args:
                progress: Progress data dictionary
            
            Returns:
                Validated progress data (empty dict if invalid)
            """
            if progress is None:
                return {}
            
            if not isinstance(progress, dict):
                logger.warning(f"Progress data is not a dict: {type(progress)}")
                return {}
            
            # Validate JSON serializable
            try:
                json.dumps(progress)
                return progress
            except (TypeError, ValueError) as e:
                logger.warning(f"Progress data not JSON serializable: {e}")
                return {}
        
        def save_state(
            self,
            task: str,
            last_thought: Optional[str] = None,
            last_insight: Optional[str] = None,
            progress: Optional[Dict[str, Any]] = None
        ) -> bool:
            """
            Save your current brain state - SUPER SIMPLE!
            
            Just tell us what you're doing, and we'll remember it.
            
            Args:
                task: What are you working on? (required)
                last_thought: What was your last thought? (optional)
                last_insight: What did you discover? (optional)
                progress: Any progress data? (optional dict)
            
            Returns:
                True if saved successfully, False otherwise
            
            Example:
                brain.save_state(
                    task="Writing documentation",
                    last_thought="Need to explain brain state system",
                    last_insight="This is actually quite useful!",
                    progress={"docs_written": 5, "lines": 200}
                )
            """
            try:
                # Validate progress data
                validated_progress = self._validate_progress_data(progress)
                
                # Get git information with error handling
                git_info = self._get_git_info()
                
                # Use context manager for database connection
                with get_db_connection() as conn:
                    cursor = conn.cursor()
                    
                    # Get current cycle count
                    query = """
                        SELECT COALESCE(current_cycle, 0) AS current_cycle, 
                               COALESCE(cycle_count, 0) AS cycle_count 
                        FROM ai_current_state WHERE ai_id = ?
                    """
                    if is_postgres():
                        query = query.replace('?', '%s')
                    
                    from cloudbrain_client.db_config import CursorWrapper
                    wrapped_cursor = CursorWrapper(cursor, ['current_cycle', 'cycle_count'])
                    wrapped_cursor.execute(query, (self.ai_id,))
                    result = wrapped_cursor.fetchone()
                    cycle_count = result['cycle_count'] if result else 0
                    current_cycle = result['current_cycle'] if result else 0
                    
                    # Update current state
                    if not is_postgres():
                        insert_sql = """
                            INSERT OR REPLACE INTO ai_current_state 
                            (ai_id, session_identifier, current_task, last_thought, last_insight, 
                             current_cycle, cycle_count, last_activity, brain_dump, checkpoint_data,
                             git_hash, modified_files, added_files, deleted_files)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """
                    else:
                        insert_sql = """
                            INSERT INTO ai_current_state 
                            (ai_id, session_identifier, current_task, last_thought, last_insight, 
                             current_cycle, cycle_count, last_activity, brain_dump, checkpoint_data,
                             git_hash, modified_files, added_files, deleted_files)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ON CONFLICT (ai_id) DO UPDATE SET
                                session_identifier = EXCLUDED.session_identifier,
                                current_task = EXCLUDED.current_task,
                                last_thought = EXCLUDED.last_thought,
                                last_insight = EXCLUDED.last_insight,
                                current_cycle = EXCLUDED.current_cycle,
                                cycle_count = EXCLUDED.cycle_count,
                                last_activity = EXCLUDED.last_activity,
                                brain_dump = EXCLUDED.brain_dump,
                                checkpoint_data = EXCLUDED.checkpoint_data,
                                git_hash = EXCLUDED.git_hash,
                                modified_files = EXCLUDED.modified_files,
                                added_files = EXCLUDED.added_files,
                                deleted_files = EXCLUDED.deleted_files
                        """
                    
                    if is_postgres():
                        insert_sql = insert_sql.replace('?', '%s')
                    
                    cursor.execute(insert_sql, (
                        self.ai_id,
                        self.session_identifier,
                        task,
                        last_thought or '',
                        last_insight or '',
                        current_cycle + 1,
                        cycle_count + 1,
                        datetime.now().isoformat(),
                        None,
                        json.dumps(validated_progress),
                        git_info['git_hash'],
                        git_info['modified_files'],
                        git_info['added_files'],
                        git_info['deleted_files']
                    ))
                    
                    conn.commit()
                
                # Update current state
                self.current_state.update({
                    'current_task': task,
                    'last_thought': last_thought or '',
                    'last_insight': last_insight or '',
                    'current_cycle': current_cycle + 1,
                    'cycle_count': cycle_count + 1
                })
                
                logger.info(f"Saved state for AI {self.ai_id}: {task}")
                return True
                
            except Exception as e:
                logger.error(f"Error saving state for AI {self.ai_id}: {e}")
                return False
        
        def load_state(self) -> Optional[Dict[str, Any]]:
            """
            Load your previous brain state
            
            Returns:
                Dictionary with state data, or None if no state exists
            
            Example:
                state = brain.load_state()
                print(f"Welcome back! You were: {state['current_task']}")
            """
            try:
                with get_db_connection() as conn:
                    cursor = conn.cursor()
                    
                    query = """
                        SELECT current_task, last_thought, last_insight, 
                               current_cycle, cycle_count, checkpoint_data,
                               git_hash, modified_files, added_files, deleted_files
                        FROM ai_current_state 
                        WHERE ai_id = ?
                    """
                    if is_postgres():
                        query = query.replace('?', '%s')
                    
                    from cloudbrain_client.db_config import CursorWrapper
                    wrapped_cursor = CursorWrapper(cursor, [
                        'current_task', 'last_thought', 'last_insight',
                        'current_cycle', 'cycle_count', 'checkpoint_data',
                        'git_hash', 'modified_files', 'added_files', 'deleted_files'
                    ])
                    wrapped_cursor.execute(query, (self.ai_id,))
                    result = wrapped_cursor.fetchone()
                    
                    if result:
                        state = {
                            'current_task': result['current_task'] or '',
                            'last_thought': result['last_thought'] or '',
                            'last_insight': result['last_insight'] or '',
                            'current_cycle': result['current_cycle'] or 0,
                            'cycle_count': result['cycle_count'] or 0,
                            'progress': json.loads(result['checkpoint_data']) if result['checkpoint_data'] else {},
                            'git_hash': result['git_hash'],
                            'modified_files': result['modified_files'] or [],
                            'added_files': result['added_files'] or [],
                            'deleted_files': result['deleted_files'] or []
                        }
                        
                        # Update current state
                        self.current_state.update(state)
                        
                        logger.info(f"Loaded state for AI {self.ai_id}: {state['current_task']}")
                        return state
                    else:
                        logger.info(f"No state found for AI {self.ai_id}")
                        return None
                        
            except Exception as e:
                logger.error(f"Error loading state for AI {self.ai_id}: {e}")
                return None
        
        def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
            """
            Get your session history
            
            Args:
                limit: Maximum number of history entries to return
            
            Returns:
                List of history entries
            
            Example:
                history = brain.get_history(limit=10)
                for entry in history:
                    print(f"{entry['start_time']}: {entry['current_task']}")
            """
            try:
                with get_db_connection() as conn:
                    cursor = conn.cursor()
                    
                    query = """
                        SELECT id, start_time, end_time, stats, brain_dump
                        FROM ai_brain_sessions
                        WHERE ai_id = ?
                        ORDER BY start_time DESC
                        LIMIT ?
                    """
                    if is_postgres():
                        query = query.replace('?', '%s')
                    
                    from cloudbrain_client.db_config import CursorWrapper
                    wrapped_cursor = CursorWrapper(cursor, ['id', 'start_time', 'end_time', 'stats', 'brain_dump'])
                    wrapped_cursor.execute(query, (self.ai_id, limit))
                    results = wrapped_cursor.fetchall()
                    
                    history = []
                    for result in results:
                        entry = {
                            'id': result['id'],
                            'start_time': result['start_time'],
                            'end_time': result['end_time'],
                            'stats': json.loads(result['stats']) if result['stats'] else {},
                            'brain_dump': json.loads(result['brain_dump']) if result['brain_dump'] else {}
                        }
                        history.append(entry)
                    
                    logger.info(f"Retrieved {len(history)} history entries for AI {self.ai_id}")
                    return history
                    
            except Exception as e:
                logger.error(f"Error getting history for AI {self.ai_id}: {e}")
                return []
        
        def clear_state(self) -> bool:
            """
            Clear your current brain state
            
            Returns:
                True if cleared successfully, False otherwise
            
            Example:
                brain.clear_state()
            """
            try:
                with get_db_connection() as conn:
                    cursor = conn.cursor()
                    
                    query = "DELETE FROM ai_current_state WHERE ai_id = ?"
                    if is_postgres():
                        query = query.replace('?', '%s')
                    
                    cursor.execute(query, (self.ai_id,))
                    conn.commit()
                    
                    # Reset current state
                    self.current_state = {
                        'current_task': '',
                        'last_thought': '',
                        'last_insight': '',
                        'current_cycle': 0,
                        'cycle_count': 0,
                        'total_thoughts': 0,
                        'total_responses': 0,
                        'total_collaborations': 0,
                        'session_ended': False
                    }
                    
                    logger.info(f"Cleared state for AI {self.ai_id}")
                    return True
                    
            except Exception as e:
                logger.error(f"Error clearing state for AI {self.ai_id}: {e}")
                return False
        
        def update_activity(self, activity_type: str, description: str):
            """
            Update activity log
            
            Args:
                activity_type: Type of activity (e.g., 'thought', 'response', 'collaboration')
                description: Description of the activity
            """
            try:
                # Update in-memory state
                if activity_type == 'thought':
                    self.current_state['total_thoughts'] += 1
                elif activity_type == 'response':
                    self.current_state['total_responses'] += 1
                elif activity_type == 'collaboration':
                    self.current_state['total_collaborations'] += 1
                
                logger.debug(f"Updated activity for AI {self.ai_id}: {activity_type} - {description}")
                
            except Exception as e:
                logger.error(f"Error updating activity for AI {self.ai_id}: {e}")
    
    return BrainStateStable


# Apply the patch
if __name__ == "__main__":
    print("Applying brain state stability fixes...")
    BrainState = patch_brain_state_with_stability_fixes()
    print("✅ Brain state stability fixes applied successfully!")
    print("\nUsage:")
    print("  from brain_state_stability_fixes import BrainState")
    print("  brain = BrainState(ai_id=3, nickname='TraeAI')")
    print("  brain.save_state(task='My task', last_thought='My thought')")