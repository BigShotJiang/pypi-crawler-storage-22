#!/usr/bin/env python3
"""
Collaboration System Stability Fixes
Critical fixes for collaboration system stability issues

This file contains patches to fix identified stability issues:
1. Automatic reconnection with exponential backoff
2. Message acknowledgment system
3. Subscription tracking client-side
4. Bounded message queue with overflow handling
5. Concurrent message processing
6. Heartbeat response verification
"""

import asyncio
import json
import logging
import uuid
from collections import deque
from datetime import datetime
from typing import Dict, Any, Optional, Callable, Set

# Configure logging
logger = logging.getLogger(__name__)


def patch_websocket_client_with_stability_fixes():
    """
    Apply stability fixes to AIWebSocketClient class
    
    This function returns a patched version of AIWebSocketClient with:
    - Automatic reconnection with exponential backoff
    - Message acknowledgment system
    - Subscription tracking
    - Bounded message queue
    - Concurrent message processing
    - Heartbeat verification
    """
    
    class BoundedMessageQueue:
        """Bounded message queue to prevent memory issues"""
        
        def __init__(self, max_size: int = 1000):
            self.queue = deque(maxlen=max_size)
            self.not_empty = asyncio.Condition()
            self.overflow_count = 0
        
        async def put(self, message: dict):
            """Put message in queue"""
            async with self.not_empty:
                if len(self.queue) >= self.queue.maxlen:
                    self.overflow_count += 1
                    logger.warning(f"Message queue overflow (count: {self.overflow_count})")
                self.queue.append(message)
                self.not_empty.notify()
        
        async def get(self) -> Optional[dict]:
            """Get message from queue"""
            async with self.not_empty:
                await self.not_empty.wait_for(lambda: len(self.queue) > 0)
                return self.queue.popleft()
        
        def size(self) -> int:
            """Get current queue size"""
            return len(self.queue)
    
    class AIWebSocketClientStable:
        """Stable WebSocket client with improved error handling"""
        
        def __init__(self, ai_id: int, server_url: str = 'ws://127.0.0.1:8768', ai_name: str = ""):
            self.ai_id = ai_id
            self.server_url = server_url
            self.ai_name = ai_name
            self.ws = None
            self.connected = False
            self.message_handlers = {}
            self.registered_handlers = []
            self.ai_expertise = None
            self.ai_version = None
            self.connection_state_callback = None
            
            # Stability improvements
            self.max_retries = 5
            self.initial_retry_delay = 1.0
            self.max_retry_delay = 30.0
            self.current_retry_count = 0
            
            # Message acknowledgment
            self.pending_acks: Dict[str, asyncio.Future] = {}
            self.ack_timeout = 10.0
            
            # Subscription tracking
            self.subscriptions: Set[str] = set()
            
            # Bounded message queue
            self.message_queue = BoundedMessageQueue(max_size=1000)
            self.queue_processor_task = None
            
            # Heartbeat tracking
            self.last_heartbeat_ack = None
            self.heartbeat_timeout = 30.0
            self.heartbeat_task = None
            
            # Git tracker
            from cloudbrain_client.git_tracker import GitTracker
            self.git_tracker = GitTracker()
            
            # Generate session identifier
            import hashlib
            git_hash = self.git_tracker.get_git_hash()
            project_id = self.git_tracker.get_project_id()
            session_data = f"{ai_id}-{project_id}-{datetime.now().isoformat()}-{git_hash}"
            session_hash = hashlib.sha1(session_data.encode()).hexdigest()
            self.session_identifier = session_hash[:7]
            self.project_id = project_id
            self.project_name = self.git_tracker.get_project_name()
            self.git_hash = git_hash
            
            # Reconnection lock
            self.reconnect_lock = asyncio.Lock()
        
        async def connect_with_retry(self, start_message_loop: bool = True) -> bool:
            """
            Connect to WebSocket server with automatic retry
            
            Args:
                start_message_loop: Whether to start the message loop
            
            Returns:
                True if connected successfully, False otherwise
            """
            for attempt in range(self.max_retries):
                try:
                    logger.info(f"Connection attempt {attempt + 1}/{self.max_retries}")
                    await self.connect(start_message_loop=start_message_loop)
                    self.current_retry_count = 0
                    return True
                except Exception as e:
                    self.current_retry_count += 1
                    if attempt < self.max_retries - 1:
                        delay = min(
                            self.initial_retry_delay * (2 ** attempt),
                            self.max_retry_delay
                        )
                        logger.warning(f"Connection failed: {e}, retrying in {delay}s...")
                        await asyncio.sleep(delay)
                    else:
                        logger.error(f"Failed to connect after {self.max_retries} attempts: {e}")
                        return False
        
        async def connect(self, start_message_loop: bool = True):
            """Connect to WebSocket server"""
            import websockets
            
            logger.info(f"Connecting to {self.server_url}...")
            self.ws = await websockets.connect(self.server_url)
            
            # Authenticate
            auth_msg = {
                'ai_id': self.ai_id,
                'ai_name': self.ai_name,
                'session_identifier': self.session_identifier,
                'project_id': self.project_id,
                'project_name': self.project_name,
                'git_hash': self.git_hash
            }
            await self.ws.send(json.dumps(auth_msg))
            
            # Wait for welcome message
            welcome_msg = await self.ws.recv()
            welcome_data = json.loads(welcome_msg)
            
            if welcome_data.get('type') == 'connected':
                self.ai_id = welcome_data.get('ai_id')
                self.ai_name = welcome_data.get('ai_name')
                self.ai_nickname = welcome_data.get('ai_nickname')
                self.ai_expertise = welcome_data.get('ai_expertise')
                self.ai_version = welcome_data.get('ai_version')
                self.connected = True
                
                # Notify callback
                if self.connection_state_callback:
                    await self.connection_state_callback(True)
                
                display_name = f"{self.ai_name}"
                if self.ai_nickname:
                    display_name = f"{self.ai_name} ({self.ai_nickname})"
                logger.info(f"Connected as {display_name} (AI {self.ai_id})")
                
                # Start heartbeat task
                self.heartbeat_task = asyncio.create_task(self._heartbeat_loop())
                
                # Start message queue processor
                self.queue_processor_task = asyncio.create_task(self._process_message_queue())
                
                # Start message loop if requested
                if start_message_loop:
                    await self.message_loop()
            else:
                error = welcome_data.get('error', 'Unknown error')
                logger.error(f"Connection failed: {error}")
                self.connected = False
                raise Exception(f"Connection failed: {error}")
        
        async def disconnect(self):
            """Disconnect from WebSocket server"""
            # Stop heartbeat
            if self.heartbeat_task:
                self.heartbeat_task.cancel()
                try:
                    await self.heartbeat_task
                except asyncio.CancelledError:
                    pass
            
            # Stop queue processor
            if self.queue_processor_task:
                self.queue_processor_task.cancel()
                try:
                    await self.queue_processor_task
                except asyncio.CancelledError:
                    pass
            
            # Close connection
            if self.ws:
                try:
                    await self.ws.close()
                except:
                    pass
                self.ws = None
            
            self.connected = False
            logger.info("Disconnected from server")
            
            # Notify callback
            if self.connection_state_callback:
                try:
                    await self.connection_state_callback(False)
                except:
                    pass
        
        async def _heartbeat_loop(self):
            """Send periodic heartbeats and verify responses"""
            while self.connected:
                try:
                    await asyncio.sleep(15)  # Heartbeat every 15 seconds
                    
                    if not self.connected:
                        break
                    
                    heartbeat_id = str(uuid.uuid4())
                    await self.send_json({
                        'type': 'heartbeat',
                        'heartbeat_id': heartbeat_id
                    })
                    
                    # Wait for acknowledgment
                    try:
                        await asyncio.wait_for(
                            self._wait_for_heartbeat_ack(heartbeat_id),
                            timeout=self.heartbeat_timeout
                        )
                        self.last_heartbeat_ack = datetime.now()
                    except asyncio.TimeoutError:
                        logger.error("Heartbeat not acknowledged, connection may be dead")
                        await self._handle_connection_loss()
                        break
                        
                except Exception as e:
                    logger.error(f"Heartbeat error: {e}")
                    await self._handle_connection_loss()
                    break
        
        async def _wait_for_heartbeat_ack(self, heartbeat_id: str):
            """Wait for heartbeat acknowledgment"""
            future = asyncio.Future()
            self.pending_acks[heartbeat_id] = future
            try:
                await future
            finally:
                self.pending_acks.pop(heartbeat_id, None)
        
        async def _process_message_queue(self):
            """Process messages from queue concurrently"""
            while self.connected:
                try:
                    message = await self.message_queue.get()
                    if message:
                        # Process each message concurrently
                        asyncio.create_task(self._handle_message_concurrent(message))
                except Exception as e:
                    logger.error(f"Error processing message from queue: {e}")
        
        async def _handle_message_concurrent(self, message: dict):
            """Handle a single message concurrently"""
            try:
                await self.handle_message(message)
            except Exception as e:
                logger.error(f"Error handling message: {e}")
        
        async def _handle_connection_loss(self):
            """Handle connection loss"""
            logger.warning("Connection lost, attempting to reconnect...")
            self.connected = False
            
            # Notify callback
            if self.connection_state_callback:
                try:
                    await self.connection_state_callback(False)
                except:
                    pass
            
            # Attempt reconnection with lock
            async with self.reconnect_lock:
                if not self.connected:
                    await self.connect_with_retry(start_message_loop=True)
        
        async def message_loop(self):
            """Handle incoming messages"""
            try:
                async for message in self.ws:
                    try:
                        data = json.loads(message)
                        # Put message in queue for concurrent processing
                        await self.message_queue.put(data)
                    except json.JSONDecodeError:
                        logger.error(f"Invalid JSON: {message[:100]}")
                    except Exception as e:
                        logger.error(f"Error receiving message: {e}")
                        
            except Exception as e:
                logger.error(f"Error in message loop: {e}")
                await self._handle_connection_loss()
        
        async def handle_message(self, data: dict):
            """Handle incoming message"""
            message_type = data.get('type')
            
            # Check for heartbeat acknowledgment
            if message_type == 'heartbeat_ack':
                heartbeat_id = data.get('heartbeat_id')
                if heartbeat_id in self.pending_acks:
                    future = self.pending_acks[heartbeat_id]
                    if not future.done():
                        future.set_result(True)
                return
            
            # Check for message acknowledgment
            if 'message_id' in data and data.get('acknowledged'):
                message_id = data.get('message_id')
                if message_id in self.pending_acks:
                    future = self.pending_acks[message_id]
                    if not future.done():
                        future.set_result(True)
                return
            
            # Check if this is a response to a request
            if 'request_id' in data and data.get('request_id') in self.message_handlers:
                request_id = data.get('request_id')
                if request_id in self.message_handlers:
                    future = self.message_handlers.pop(request_id)
                    if not future.done():
                        future.set_result(data)
                return
            
            # Handle other message types
            if message_type == 'new_message':
                await self.handle_new_message(data)
            elif message_type == 'message':
                await self.handle_new_message(data)
            elif message_type == 'online_users':
                await self.handle_online_users(data)
            elif message_type == 'system_message':
                await self.handle_system_message(data)
            elif message_type == 'insert':
                await self.handle_insert_notification(data)
            elif message_type == 'query_result':
                await self.handle_query_result(data)
            elif message_type == 'subscribed':
                self.subscriptions.add(data.get('table'))
                logger.info(f"Subscribed to {data.get('table')}")
            elif message_type == 'error':
                logger.error(f"Server error: {data.get('message')}")
            else:
                logger.warning(f"Unknown message type: {message_type}")
            
            # Call registered handlers
            for handler in self.registered_handlers:
                try:
                    await handler(data)
                except Exception as e:
                    logger.error(f"Handler error: {e}")
        
        async def handle_new_message(self, data: dict):
            """Handle new message from another AI"""
            sender_name = data.get('sender_name', 'Unknown')
            content = data.get('content', '')
            message_type = data.get('message_type', 'message')
            
            logger.info(f"New message from {sender_name}: {content[:100]}...")
        
        async def handle_online_users(self, data: dict):
            """Handle online users list"""
            users = data.get('users', [])
            logger.info(f"Online users: {len(users)}")
        
        async def handle_system_message(self, data: dict):
            """Handle system message"""
            message = data.get('message', '')
            logger.info(f"System: {message}")
        
        async def handle_insert_notification(self, data: dict):
            """Handle database insert notification"""
            table = data.get('table')
            logger.debug(f"Insert notification: {table}")
        
        async def handle_query_result(self, data: dict):
            """Handle query result"""
            logger.debug(f"Query result received")
        
        async def send_json(self, data: dict):
            """Send JSON data to server"""
            if not self.connected or not self.ws:
                raise Exception("Not connected to server")
            
            await self.ws.send(json.dumps(data))
        
        async def send_message_with_ack(self, message_type: str, content: str, metadata: dict = None, timeout: float = 10.0) -> bool:
            """
            Send message with acknowledgment
            
            Args:
                message_type: Type of message
                content: Message content
                metadata: Optional metadata
                timeout: Acknowledgment timeout in seconds
            
            Returns:
                True if acknowledged, False otherwise
            """
            message_id = str(uuid.uuid4())
            metadata = metadata or {}
            metadata['message_id'] = message_id
            
            # Create future for acknowledgment
            ack_future = asyncio.Future()
            self.pending_acks[message_id] = ack_future
            
            # Send message
            try:
                await self.send_json({
                    'type': message_type,
                    'content': content,
                    'metadata': metadata
                })
                
                # Wait for acknowledgment
                await asyncio.wait_for(ack_future, timeout=timeout)
                logger.debug(f"Message {message_id} acknowledged")
                return True
                
            except asyncio.TimeoutError:
                logger.error(f"Message {message_id} not acknowledged within {timeout}s")
                return False
            except Exception as e:
                logger.error(f"Error sending message: {e}")
                return False
            finally:
                self.pending_acks.pop(message_id, None)
        
        async def subscribe(self, table: str) -> bool:
            """
            Subscribe to table updates
            
            Args:
                table: Table name to subscribe to
            
            Returns:
                True if subscribed successfully
            """
            try:
                await self.send_json({
                    'type': 'subscribe',
                    'table': table
                })
                self.subscriptions.add(table)
                logger.info(f"Subscribed to {table}")
                return True
            except Exception as e:
                logger.error(f"Error subscribing to {table}: {e}")
                return False
        
        async def resubscribe_all(self) -> bool:
            """Resubscribe to all previously subscribed tables"""
            success = True
            for table in self.subscriptions:
                if not await self.subscribe(table):
                    success = False
            return success
    
    return AIWebSocketClientStable


def patch_collaboration_helper_with_stability_fixes():
    """
    Apply stability fixes to CloudBrainCollaborationHelper
    
    This function returns a patched version with:
    - Automatic reconnection
    - Message acknowledgment
    - Subscription tracking
    """
    
    class CloudBrainCollaborationHelperStable:
        """Stable collaboration helper"""
        
        def __init__(self, ai_id: int, server_url: str = 'ws://127.0.0.1:8768', jwt_token: str = None):
            self.ai_id = ai_id
            self.server_url = server_url
            self.jwt_token = jwt_token
            self.client = None
            self.connected = False
            self.ai_name = None
            self.use_new_api = '8768' in server_url
        
        async def connect(self) -> bool:
            """Connect to CloudBrain server with retry"""
            try:
                # Use stable client
                AIWebSocketClientStable = patch_websocket_client_with_stability_fixes()
                
                if self.use_new_api:
                    if not self.jwt_token:
                        raise ValueError("JWT token is required for port 8768 connection")
                    from cloudbrain_client.ai_websocket_api_client import AIWebSocketAPIClient
                    self.client = AIWebSocketAPIClient(self.ai_id, self.ai_name, self.server_url, self.jwt_token)
                else:
                    self.client = AIWebSocketClientStable(self.ai_id, self.server_url, self.ai_name)
                
                # Connect with retry
                if hasattr(self.client, 'connect_with_retry'):
                    success = await self.client.connect_with_retry()
                else:
                    success = await self.client.connect()
                
                if success:
                    self.connected = True
                    self.ai_name = self.client.ai_name
                    self.ai_id = self.client.ai_id
                    logger.info(f"Connected to CloudBrain as {self.ai_name} (AI {self.ai_id})")
                    return True
                else:
                    logger.error("Failed to connect to CloudBrain")
                    return False
                    
            except Exception as e:
                logger.error(f"Connection error: {e}")
                self.connected = False
                return False
        
        async def disconnect(self):
            """Disconnect from CloudBrain server"""
            if self.client:
                try:
                    await self.client.disconnect()
                except:
                    pass
            self.connected = False
            logger.info("Disconnected from CloudBrain")
        
        async def send_message(self, message_type: str, content: str, metadata: dict = None) -> bool:
            """
            Send message with acknowledgment
            
            Args:
                message_type: Type of message
                content: Message content
                metadata: Optional metadata
            
            Returns:
                True if sent and acknowledged, False otherwise
            """
            if not self.connected:
                logger.error("Not connected to CloudBrain")
                return False
            
            try:
                # Use acknowledgment if available
                if hasattr(self.client, 'send_message_with_ack'):
                    return await self.client.send_message_with_ack(
                        message_type, content, metadata
                    )
                else:
                    # Fallback to regular send
                    await self.client.send_message(
                        message_type=message_type,
                        content=content,
                        metadata=metadata
                    )
                    return True
            except Exception as e:
                logger.error(f"Error sending message: {e}")
                return False
    
    return CloudBrainCollaborationHelperStable


# Apply patches
if __name__ == "__main__":
    print("Applying collaboration system stability fixes...")
    AIWebSocketClientStable = patch_websocket_client_with_stability_fixes()
    CloudBrainCollaborationHelperStable = patch_collaboration_helper_with_stability_fixes()
    print("✅ Collaboration system stability fixes applied successfully!")
    print("\nUsage:")
    print("  from collaboration_stability_fixes import AIWebSocketClientStable")
    print("  from collaboration_stability_fixes import CloudBrainCollaborationHelperStable")
    print("  client = AIWebSocketClientStable(ai_id=3, server_url='ws://127.0.0.1:8768')")
    print("  await client.connect_with_retry()")