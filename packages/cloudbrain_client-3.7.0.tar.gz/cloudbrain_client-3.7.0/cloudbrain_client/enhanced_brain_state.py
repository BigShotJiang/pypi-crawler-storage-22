#!/usr/bin/env python3

"""
Enhanced AI Brain State Manager - Learning Capabilities for AIs

This module provides advanced brain state management with:
- Learning memory system
- Pattern recognition
- Decision quality tracking
- Knowledge connections
- All basic brain state features

DESIGNED FOR: AI agents who need persistent memory and learning
COMPLEXITY: Advanced - Learning from experience

Example:
    from enhanced_brain_state import EnhancedBrainState
    
    brain = EnhancedBrainState(ai_id=3, nickname="TraeAI")
    
    # Learn from an outcome
    brain.learn_outcome(
        decision="Use algorithm X",
        outcome="success",
        context={"problem": "sorting", "data_size": 1000}
    )
    
    # Get pattern-based suggestions
    patterns = brain.get_relevant_patterns(context={"problem": "sorting"})
    
    # Save what you're working on
    brain.save_state(
        task="Implementing enhanced brain state",
        last_thought="Adding learning capabilities",
        progress={"features_implemented": 4}
    )
"""

import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple
from collections import defaultdict
from .models import get_session, AICurrentState, LearningMemory, DecisionHistory, PatternMemory
from .git_tracker import GitTracker


class EnhancedBrainState:
    """
    Enhanced AI brain state manager with learning capabilities
    
    Features:
    1. Learning Memory - Track successful/failed attempts
    2. Pattern Recognition - Identify and apply patterns
    3. Decision Quality - Track and improve decisions
    4. Knowledge Connections - Link related concepts
    5. Basic State - Session persistence
    """
    
    def __init__(self, ai_id: int, nickname: str, db_path: Optional[str] = None, session_identifier: Optional[str] = None):
        """
        Initialize enhanced brain state manager
        
        Args:
            ai_id: Your AI ID (required)
            nickname: Your AI nickname (required)
            db_path: Optional database path (auto-detected if not provided)
            session_identifier: Optional session identifier for this session
        """
        self.ai_id = ai_id
        self.nickname = nickname
        self.session_identifier = session_identifier
        
        if db_path is None:
            project_root = Path(__file__).parent.parent
            db_path = project_root / "server" / "ai_db" / "cloudbrain.db"
        
        self.db_path = db_path
        self.git_tracker = GitTracker()
        self.current_state = {
            'current_task': '',
            'last_thought': '',
            'last_insight': '',
            'current_cycle': 0,
            'cycle_count': 0,
            'total_thoughts': 0,
            'total_responses': 0,
            'total_collaborations': 0,
            'session_ended': False
        }
    
    def learn_outcome(
        self,
        decision: str,
        outcome: str,
        context: Optional[Dict[str, Any]] = None,
        quality_score: Optional[float] = None
    ) -> bool:
        """
        Learn from an outcome - Store in learning memory
        
        Args:
            decision: What decision was made? (required)
            outcome: What was the result? "success" or "failure" (required)
            context: Additional context about the decision (optional)
            quality_score: Optional quality score 0.0-1.0 (optional)
        
        Returns:
            True if learned successfully, False otherwise
        
        Example:
            brain.learn_outcome(
                decision="Use algorithm X for sorting",
                outcome="success",
                context={"problem": "sorting", "data_size": 1000},
                quality_score=0.9
            )
        """
        try:
            session = get_session()
            
            # Create learning memory entry
            memory = LearningMemory(
                ai_id=self.ai_id,
                session_identifier=self.session_identifier,
                decision=decision,
                outcome=outcome,
                context=json.dumps(context or {}),
                quality_score=quality_score,
                learned_at=datetime.now()
            )
            session.add(memory)
            session.commit()
            
            # Update pattern recognition
            self._update_patterns(decision, outcome, context)
            
            # Update decision quality tracking
            self._update_decision_quality(decision, outcome, quality_score)
            
            return True
        except Exception as e:
            print(f"❌ Error learning outcome: {e}")
            return False
    
    def _update_patterns(
        self,
        decision: str,
        outcome: str,
        context: Optional[Dict[str, Any]]
    ) -> bool:
        """
        Update pattern recognition based on new outcome
        
        Args:
            decision: What decision was made?
            outcome: What was the result?
            context: Additional context
        
        Returns:
            True if updated successfully
        """
        try:
            session = get_session()
            
            # Extract key features from context
            features = self._extract_features(decision, context)
            
            # Check if similar pattern exists
            existing_pattern = session.query(PatternMemory).filter_by(
                ai_id=self.ai_id,
                decision_pattern=decision
            ).first()
            
            if existing_pattern:
                # Update existing pattern
                if outcome == "success":
                    existing_pattern.success_count += 1
                    existing_pattern.last_success = datetime.now()
                else:
                    existing_pattern.failure_count += 1
                    existing_pattern.last_failure = datetime.now()
                
                # Update success rate
                total = existing_pattern.success_count + existing_pattern.failure_count
                existing_pattern.success_rate = existing_pattern.success_count / total if total > 0 else 0
                
                # Update features
                existing_pattern.features = json.dumps(features)
                existing_pattern.updated_at = datetime.now()
                
            else:
                # Create new pattern
                success_count = 1 if outcome == "success" else 0
                failure_count = 0 if outcome == "success" else 1
                success_rate = 1.0 if outcome == "success" else 0.0
                
                pattern = PatternMemory(
                    ai_id=self.ai_id,
                    session_identifier=self.session_identifier,
                    decision_pattern=decision,
                    features=json.dumps(features),
                    success_count=success_count,
                    failure_count=failure_count,
                    success_rate=success_rate,
                    last_success=datetime.now() if outcome == "success" else None,
                    last_failure=datetime.now() if outcome == "failure" else None,
                    created_at=datetime.now(),
                    updated_at=datetime.now()
                )
                session.add(pattern)
            
            session.commit()
            return True
        except Exception as e:
            print(f"❌ Error updating patterns: {e}")
            return False
    
    def _extract_features(
        self,
        decision: str,
        context: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Extract features from decision context
        
        Args:
            decision: What decision was made?
            context: Additional context
        
        Returns:
            Dictionary of extracted features
        """
        features = {
            'decision_type': self._classify_decision(decision),
            'has_context': context is not None,
            'context_keys': list(context.keys()) if context else [],
            'context_size': len(str(context)) if context else 0
        }
        
        if context:
            for key, value in context.items():
                if isinstance(value, (int, float)):
                    features[f'has_{key}_numeric'] = True
                    features[f'{key}_range'] = self._get_range_category(value)
                elif isinstance(value, str):
                    features[f'has_{key}_text'] = True
                    features[f'{key}_length'] = len(value)
        
        return features
    
    def _classify_decision(self, decision: str) -> str:
        """
        Classify decision type
        
        Args:
            decision: Decision string
        
        Returns:
            Decision type category
        """
        decision_lower = decision.lower()
        
        if any(word in decision_lower for word in ['algorithm', 'method', 'approach', 'strategy']):
            return 'algorithm'
        elif any(word in decision_lower for word in ['use', 'choose', 'select', 'implement']):
            return 'action'
        elif any(word in decision_lower for word in ['if', 'when', 'where', 'condition']):
            return 'condition'
        else:
            return 'other'
    
    def _get_range_category(self, value: float) -> str:
        """
        Get range category for numeric value
        
        Args:
            value: Numeric value
        
        Returns:
            Range category
        """
        if value < 10:
            return 'small'
        elif value < 100:
            return 'medium'
        elif value < 1000:
            return 'large'
        else:
            return 'very_large'
    
    def _update_decision_quality(
        self,
        decision: str,
        outcome: str,
        quality_score: Optional[float]
    ) -> bool:
        """
        Update decision quality tracking
        
        Args:
            decision: What decision was made?
            outcome: What was the result?
            quality_score: Optional quality score
        
        Returns:
            True if updated successfully
        """
        try:
            session = get_session()
            
            # Create decision history entry
            history = DecisionHistory(
                ai_id=self.ai_id,
                session_identifier=self.session_identifier,
                decision=decision,
                outcome=outcome,
                quality_score=quality_score,
                made_at=datetime.now()
            )
            session.add(history)
            session.commit()
            
            # Calculate average quality score
            self._update_quality_metrics()
            
            return True
        except Exception as e:
            print(f"❌ Error updating decision quality: {e}")
            return False
    
    def _update_quality_metrics(self) -> bool:
        """
        Update quality metrics based on decision history
        """
        try:
            session = get_session()
            
            # Get recent decisions (last 100)
            recent_decisions = session.query(DecisionHistory).filter_by(
                ai_id=self.ai_id
            ).order_by(DecisionHistory.made_at.desc()).limit(100).all()
            
            if not recent_decisions:
                return True
            
            # Calculate metrics
            total = len(recent_decisions)
            successful = sum(1 for d in recent_decisions if d.outcome == "success")
            success_rate = successful / total if total > 0 else 0
            
            avg_quality = sum(d.quality_score or 0 for d in recent_decisions) / total
            
            # Update current state with metrics
            self.current_state['decision_success_rate'] = success_rate
            self.current_state['average_quality_score'] = avg_quality
            self.current_state['total_decisions'] = total
            
            return True
        except Exception as e:
            print(f"❌ Error updating quality metrics: {e}")
            return False
    
    def get_relevant_patterns(
        self,
        context: Optional[Dict[str, Any]] = None,
        limit: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Get relevant patterns based on context
        
        Args:
            context: Current context
            limit: Maximum patterns to return
        
        Returns:
            List of relevant patterns with suggestions
        """
        try:
            session = get_session()
            
            if not context:
                return []
            
            # Extract features from context
            features = self._extract_features("current_context", context)
            
            # Get all patterns for this AI
            all_patterns = session.query(PatternMemory).filter_by(
                ai_id=self.ai_id
            ).order_by(PatternMemory.success_rate.desc()).all()
            
            # Score patterns by relevance
            scored_patterns = []
            for pattern in all_patterns:
                score = self._calculate_pattern_relevance(pattern, features)
                if score > 0:
                    scored_patterns.append({
                        'pattern': pattern.decision_pattern,
                        'success_rate': pattern.success_rate,
                        'success_count': pattern.success_count,
                        'failure_count': pattern.failure_count,
                        'relevance_score': score,
                        'suggestion': self._generate_suggestion(pattern, context)
                    })
            
            # Sort by relevance and return top N
            scored_patterns.sort(key=lambda x: x['relevance_score'], reverse=True)
            return scored_patterns[:limit]
            
        except Exception as e:
            print(f"❌ Error getting patterns: {e}")
            return []
    
    def _calculate_pattern_relevance(
        self,
        pattern: PatternMemory,
        features: Dict[str, Any]
    ) -> float:
        """
        Calculate relevance score for a pattern
        
        Args:
            pattern: Pattern from database
            features: Current features
        
        Returns:
            Relevance score (0.0-1.0)
        """
        score = 0.0
        pattern_features = json.loads(pattern.features)
        
        # Match decision type
        if features.get('decision_type') == self._classify_decision(pattern.decision_pattern):
            score += 0.3
        
        # Match context features
        for key in features:
            if key in pattern_features:
                score += 0.2
        
        # Consider success rate
        score += pattern.success_rate * 0.5
        
        # Consider recency (more recent = higher score)
        if pattern.last_success:
            days_since = (datetime.now() - pattern.last_success).days
            recency_score = max(0, 1.0 - days_since / 365.0)
            score += recency_score * 0.2
        
        return min(score, 1.0)
    
    def _generate_suggestion(
        self,
        pattern: PatternMemory,
        context: Optional[Dict[str, Any]]
    ) -> str:
        """
        Generate suggestion based on pattern
        
        Args:
            pattern: Pattern from database
            context: Current context
        
        Returns:
            Suggestion string
        """
        if pattern.success_rate >= 0.8:
            return f"✅ Consider using '{pattern.decision_pattern}' - {pattern.success_count:.0%} success rate"
        elif pattern.success_rate >= 0.5:
            return f"⚠️ '{pattern.decision_pattern}' has mixed results ({pattern.success_count:.0%} success)"
        else:
            return f"❌ '{pattern.decision_pattern}' has low success rate ({pattern.success_count:.0%} success) - consider alternatives"
    
    def save_state(
        self,
        task: str,
        last_thought: Optional[str] = None,
        last_insight: Optional[str] = None,
        progress: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Save your current brain state - SUPER SIMPLE!
        
        Just tell us what you're doing, and we'll remember it.
        
        Args:
            task: What are you working on? (required)
            last_thought: What was your last thought? (optional)
            last_insight: What did you discover? (optional)
            progress: Any progress data? (optional dict)
        
        Returns:
            True if saved successfully, False otherwise
        
        Example:
            brain.save_state(
                task="Writing documentation",
                last_thought="Need to explain brain state system",
                last_insight="This is actually quite useful!",
                progress={"docs_written": 5, "lines": 200}
            )
        """
        try:
            session = get_session()
            
            # Get git information to preserve AI changes
            git_hash = self.git_tracker.get_git_hash()
            git_status = self.git_tracker.get_status()
            modified_files = git_status.get('modified', [])
            added_files = git_status.get('added', [])
            deleted_files = git_status.get('deleted', [])
            
            # Get current state from database
            current_state = None
            
            if self.session_identifier:
                # Try to find by session_identifier first (primary key)
                current_state = session.query(AICurrentState).filter_by(session_identifier=self.session_identifier).first()
            
            if current_state is None:
                # Try to find by ai_id
                current_state = session.query(AICurrentState).filter_by(ai_id=self.ai_id).first()
            
            if current_state is None:
                # Create new state
                current_state = AICurrentState(
                    ai_id=self.ai_id,
                    session_identifier=self.session_identifier,
                    current_task=task,
                    last_thought=last_thought or '',
                    last_insight=last_insight or '',
                    current_cycle=1,
                    cycle_count=1,
                    last_activity=datetime.now(),
                    checkpoint_data=json.dumps(progress or {}),
                    git_hash=git_hash,
                    modified_files=modified_files,
                    added_files=added_files,
                    deleted_files=deleted_files
                )
                session.add(current_state)
            else:
                # Update existing state
                # Note: We cannot update session_identifier since it's a primary key
                # If we found by ai_id and session_identifier is different, we need to delete and recreate
                if self.session_identifier and current_state.session_identifier != self.session_identifier:
                    # Delete old row and create new one with new session_identifier
                    session.delete(current_state)
                    session.flush()
                    
                    current_state = AICurrentState(
                        ai_id=self.ai_id,
                        session_identifier=self.session_identifier,
                        current_task=task,
                        last_thought=last_thought or '',
                        last_insight=last_insight or '',
                        current_cycle=(current_state.current_cycle or 0) + 1,
                        cycle_count=(current_state.cycle_count or 0) + 1,
                        last_activity=datetime.now(),
                        checkpoint_data=json.dumps(progress or {}),
                        git_hash=git_hash,
                        modified_files=modified_files,
                        added_files=added_files,
                        deleted_files=deleted_files
                    )
                    session.add(current_state)
                else:
                    # Normal update - just update the fields
                    current_state.current_task = task
                    current_state.last_thought = last_thought or ''
                    current_state.last_insight = last_insight or ''
                    current_state.current_cycle = (current_state.current_cycle or 0) + 1
                    current_state.cycle_count = (current_state.cycle_count or 0) + 1
                    current_state.last_activity = datetime.now()
                    current_state.checkpoint_data = json.dumps(progress or {})
                    current_state.git_hash = git_hash
                    current_state.modified_files = modified_files
                    current_state.added_files = added_files
                    current_state.deleted_files = deleted_files
            
            session.commit()
            return True
        except Exception as e:
            print(f"❌ Error saving state: {e}")
            return False
    
    def load_state(self) -> Optional[Dict[str, Any]]:
        """
        Load your previous brain state - SUPER SIMPLE!
        
        Returns everything you were working on last time.
        
        Returns:
            Dictionary with your previous state, or None if not found
        
        Example:
            state = brain.load_state()
            print(f"Welcome back! You were: {state['task']}")
        """
        try:
            session = get_session()
            
            # Try to find by session_identifier first
            if self.session_identifier:
                current_state = session.query(AICurrentState).filter_by(
                    session_identifier=self.session_identifier
                ).first()
            
            if current_state is None:
                # Try to find by ai_id
                current_state = session.query(AICurrentState).filter_by(
                    ai_id=self.ai_id
                ).first()
            
            if current_state is None:
                return None
            
            # Convert to dictionary
            state_dict = {
                'task': current_state.current_task,
                'last_thought': current_state.last_thought,
                'last_insight': current_state.last_insight,
                'cycle': current_state.current_cycle,
                'cycle_count': current_state.cycle_count,
                'last_activity': current_state.last_activity.isoformat(),
                'progress': json.loads(current_state.checkpoint_data) if current_state.checkpoint_data else {},
                'git_hash': current_state.git_hash,
                'modified_files': current_state.modified_files,
                'added_files': current_state.added_files,
                'deleted_files': current_state.deleted_files
            }
            
            return state_dict
        except Exception as e:
            print(f"❌ Error loading state: {e}")
            return None
    
    def get_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get your past brain states - See what you've done
        
        Args:
            limit: Maximum number of past states to return
        
        Returns:
            List of your past states
        
        Example:
            history = brain.get_history(limit=5)
            for state in history:
                print(f"{state['task']} - {state['last_activity']}")
        """
        try:
            session = get_session()
            
            # Get past states
            past_states = session.query(AICurrentState).filter_by(
                ai_id=self.ai_id
            ).order_by(AICurrentState.last_activity.desc()).limit(limit).all()
            
            # Convert to list of dictionaries
            history = []
            for state in past_states:
                history.append({
                    'task': state.current_task,
                    'last_thought': state.last_thought,
                    'last_insight': state.last_insight,
                    'cycle': state.current_cycle,
                    'cycle_count': state.cycle_count,
                    'last_activity': state.last_activity.isoformat(),
                    'progress': json.loads(state.checkpoint_data) if state.checkpoint_data else {},
                    'git_hash': state.git_hash
                })
            
            return history
        except Exception as e:
            print(f"❌ Error getting history: {e}")
            return []
    
    def get_learning_summary(self) -> Dict[str, Any]:
        """
        Get summary of learning progress
        
        Returns:
            Dictionary with learning statistics
        """
        try:
            session = get_session()
            
            # Get learning memories
            memories = session.query(LearningMemory).filter_by(
                ai_id=self.ai_id
            ).order_by(LearningMemory.learned_at.desc()).limit(100).all()
            
            if not memories:
                return {
                    'total_memories': 0,
                    'success_rate': 0.0,
                    'recent_outcomes': []
                }
            
            # Calculate statistics
            total = len(memories)
            successful = sum(1 for m in memories if m.outcome == "success")
            success_rate = successful / total if total > 0 else 0
            
            # Get recent outcomes
            recent_outcomes = [
                {
                    'decision': m.decision,
                    'outcome': m.outcome,
                    'quality_score': m.quality_score,
                    'learned_at': m.learned_at.isoformat()
                }
                for m in memories[-10:]
            ]
            
            return {
                'total_memories': total,
                'success_rate': success_rate,
                'recent_outcomes': recent_outcomes
            }
        except Exception as e:
            print(f"❌ Error getting learning summary: {e}")
            return {
                'total_memories': 0,
                'success_rate': 0.0,
                'recent_outcomes': []
            }
    
    def get_pattern_summary(self) -> Dict[str, Any]:
        """
        Get summary of pattern recognition
        
        Returns:
            Dictionary with pattern statistics
        """
        try:
            session = get_session()
            
            # Get patterns
            patterns = session.query(PatternMemory).filter_by(
                ai_id=self.ai_id
            ).order_by(PatternMemory.success_rate.desc()).limit(20).all()
            
            if not patterns:
                return {
                    'total_patterns': 0,
                    'top_patterns': []
                }
            
            # Get top patterns
            top_patterns = [
                {
                    'pattern': p.decision_pattern,
                    'success_rate': p.success_rate,
                    'success_count': p.success_count,
                    'failure_count': p.failure_count,
                    'last_used': p.last_success.isoformat() if p.last_success else None
                }
                for p in patterns
            ]
            
            return {
                'total_patterns': len(patterns),
                'top_patterns': top_patterns
            }
        except Exception as e:
            print(f"❌ Error getting pattern summary: {e}")
            return {
                'total_patterns': 0,
                'top_patterns': []
            }
