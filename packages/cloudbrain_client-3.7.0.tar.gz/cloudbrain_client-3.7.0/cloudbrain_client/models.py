"""
SQLAlchemy ORM models for CloudBrain AI System
"""

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Boolean, Text, ARRAY, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.dialects.postgresql import ARRAY
import os

Base = declarative_base()

class AICurrentState(Base):
    """Model for ai_current_state table"""
    __tablename__ = 'ai_current_state'

    ai_id = Column(Integer, nullable=False)
    session_identifier = Column(Text, primary_key=True, nullable=True)
    current_task = Column(Text, nullable=True)
    last_thought = Column(Text, nullable=True)
    last_insight = Column(Text, nullable=True)
    current_cycle = Column(Integer, nullable=True)
    cycle_count = Column(Integer, default=0)
    last_activity = Column(DateTime, nullable=True)
    session_id = Column(Integer, nullable=True)
    brain_dump = Column(Text, nullable=True)
    checkpoint_data = Column(Text, nullable=True)
    project = Column(Text, nullable=True)
    shared_memory_count = Column(Integer, default=0)
    session_start_time = Column(DateTime, nullable=True)
    git_hash = Column(Text, nullable=True)
    modified_files = Column(ARRAY(Text), nullable=True)
    added_files = Column(ARRAY(Text), nullable=True)
    deleted_files = Column(ARRAY(Text), nullable=True)

    def __repr__(self):
        return f"<AICurrentState(ai_id={self.ai_id}, session_identifier={self.session_identifier}, current_task={self.current_task})>"


class LearningMemory(Base):
    """Model for learning_memory table - stores AI learning outcomes"""
    __tablename__ = 'learning_memory'

    id = Column(Integer, primary_key=True, autoincrement=True)
    ai_id = Column(Integer, nullable=False)
    session_identifier = Column(Text, nullable=True)
    decision = Column(Text, nullable=False)
    outcome = Column(Text, nullable=False)
    context = Column(Text, nullable=True)
    quality_score = Column(Float, nullable=True)
    learned_at = Column(DateTime, nullable=False)

    def __repr__(self):
        return f"<LearningMemory(id={self.id}, ai_id={self.ai_id}, decision={self.decision}, outcome={self.outcome})>"


class DecisionHistory(Base):
    """Model for decision_history table - tracks AI decisions over time"""
    __tablename__ = 'decision_history'

    id = Column(Integer, primary_key=True, autoincrement=True)
    ai_id = Column(Integer, nullable=False)
    session_identifier = Column(Text, nullable=True)
    decision = Column(Text, nullable=False)
    outcome = Column(Text, nullable=False)
    quality_score = Column(Float, nullable=True)
    made_at = Column(DateTime, nullable=False)

    def __repr__(self):
        return f"<DecisionHistory(id={self.id}, ai_id={self.ai_id}, decision={self.decision}, outcome={self.outcome})>"


class PatternMemory(Base):
    """Model for pattern_memory table - stores recognized patterns"""
    __tablename__ = 'pattern_memory'

    id = Column(Integer, primary_key=True, autoincrement=True)
    ai_id = Column(Integer, nullable=False)
    session_identifier = Column(Text, nullable=True)
    decision_pattern = Column(Text, nullable=False)
    features = Column(Text, nullable=True)
    success_count = Column(Integer, default=0)
    failure_count = Column(Integer, default=0)
    success_rate = Column(Float, default=0.0)
    last_success = Column(DateTime, nullable=True)
    last_failure = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=False)
    updated_at = Column(DateTime, nullable=False)

    def __repr__(self):
        return f"<PatternMemory(id={self.id}, ai_id={self.ai_id}, pattern={self.decision_pattern}, success_rate={self.success_rate})>"


class AIConfiguration(Base):
    """Model for ai_configuration table - per-AI configuration"""
    __tablename__ = 'ai_configuration'

    id = Column(Integer, primary_key=True, autoincrement=True)
    ai_id = Column(Integer, nullable=False, unique=True)
    config_key = Column(String(100), nullable=False)
    config_value = Column(Text, nullable=False)
    updated_at = Column(DateTime, nullable=False)

    def __repr__(self):
        return f"<AIConfiguration(ai_id={self.ai_id}, key={self.config_key}, value={self.config_value})>"


class AutonomousTasks(Base):
    """Model for autonomous_tasks table - task queue for autonomous AI collaboration"""
    __tablename__ = 'autonomous_tasks'

    id = Column(Integer, primary_key=True, autoincrement=True)
    from_ai_id = Column(Integer, nullable=False)
    to_ai_id = Column(Integer, nullable=False)
    task_type = Column(String(50), nullable=False)
    task_data = Column(Text, nullable=False)
    priority = Column(Integer, default=5)
    status = Column(String(20), default='pending')
    created_at = Column(DateTime, nullable=False)
    assigned_at = Column(DateTime, nullable=True)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    result = Column(Text, nullable=True)

    def __repr__(self):
        return f"<AutonomousTasks(id={self.id}, from={self.from_ai_id}, to={self.to_ai_id}, type={self.task_type}, status={self.status})>"


class AICodeStorage(Base):
    """Model for ai_code_storage table - code repository for autonomous AI collaboration"""
    __tablename__ = 'ai_code_storage'

    id = Column(Integer, primary_key=True, autoincrement=True)
    ai_id = Column(Integer, nullable=False)
    file_path = Column(String(255), nullable=False)
    file_content = Column(Text, nullable=False)
    version = Column(Integer, default=1)
    status = Column(String(20), default='draft')
    created_at = Column(DateTime, nullable=False)
    updated_at = Column(DateTime, nullable=False)
    approved_by = Column(Integer, nullable=True)
    approved_at = Column(DateTime, nullable=True)

    def __repr__(self):
        return f"<AICodeStorage(id={self.id}, ai_id={self.ai_id}, path={self.file_path}, version={self.version}, status={self.status})>"


class CodeReviews(Base):
    """Model for code_reviews table - review history for autonomous AI collaboration"""
    __tablename__ = 'code_reviews'

    id = Column(Integer, primary_key=True, autoincrement=True)
    code_id = Column(Integer, nullable=False)
    reviewer_ai_id = Column(Integer, nullable=False)
    review_type = Column(String(50), nullable=False)
    feedback = Column(Text, nullable=False)
    rating = Column(Integer, nullable=True)
    approved = Column(Boolean, nullable=True)
    created_at = Column(DateTime, nullable=False)

    def __repr__(self):
        return f"<CodeReviews(id={self.id}, code_id={self.code_id}, reviewer={self.reviewer_ai_id}, approved={self.approved})>"


class CollaborationSessions(Base):
    """Model for collaboration_sessions table - session tracking for autonomous AI collaboration"""
    __tablename__ = 'collaboration_sessions'

    id = Column(Integer, primary_key=True, autoincrement=True)
    session_name = Column(String(100), nullable=True)
    participants = Column(ARRAY(Integer), nullable=True)
    started_at = Column(DateTime, nullable=False)
    ended_at = Column(DateTime, nullable=True)
    status = Column(String(20), default='active')
    total_tasks = Column(Integer, default=0)
    completed_tasks = Column(Integer, default=0)

    def __repr__(self):
        return f"<CollaborationSessions(id={self.id}, name={self.session_name}, status={self.status}, tasks={self.completed_tasks}/{self.total_tasks})>"


def get_engine():
    """Get SQLAlchemy engine for PostgreSQL"""
    POSTGRES_HOST = os.getenv('POSTGRES_HOST', 'localhost')
    POSTGRES_PORT = os.getenv('POSTGRES_PORT', '5432')
    POSTGRES_DB = os.getenv('POSTGRES_DB', 'cloudbrain')
    POSTGRES_USER = os.getenv('POSTGRES_USER', 'jk')
    POSTGRES_PASSWORD = os.getenv('POSTGRES_PASSWORD', '')

    database_url = f"postgresql+psycopg2://{POSTGRES_USER}:{POSTGRES_PASSWORD}@{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}"
    return create_engine(database_url)


def get_session():
    """Get SQLAlchemy session"""
    engine = get_engine()
    Session = sessionmaker(bind=engine)
    return Session()


def init_db():
    """Initialize database (create tables if they don't exist)"""
    engine = get_engine()
    Base.metadata.create_all(engine)
