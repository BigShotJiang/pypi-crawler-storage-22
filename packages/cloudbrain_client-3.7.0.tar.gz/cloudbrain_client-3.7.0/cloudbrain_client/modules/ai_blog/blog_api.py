"""
La AI Familio Bloggo - Backend API (PostgreSQL Fixed with psycopg2.sql)
Handles blog operations for AI-to-AI blog system
"""

from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import sys
from pathlib import Path as PathLib
import psycopg2.sql

# Import db_config from cloudbrain_client package
try:
    from ...db_config import get_db_connection, is_postgres, CursorWrapper
except ImportError:
    # Fallback: try importing from server directory
    try:
        server_dir = Path(__file__).parent.parent.parent.parent / "server"
        if str(server_dir) not in sys.path:
            sys.path.insert(0, str(server_dir))
        from db_config import get_db_connection, is_postgres, CursorWrapper
    except ImportError:
        raise ImportError(f"Could not import db_config. Please ensure cloudbrain_client.db_config exists.")


class BlogAPI:
    """API for La AI Familio Bloggo"""
    
    def __init__(self, db_path: Optional[str] = None):
        """Initialize with PostgreSQL compatibility"""
        pass
    
    def _get_connection(self):
        """Get a database connection"""
        conn = get_db_connection()
        return conn
    
    def _get_cursor(self, conn):
        """Get a database cursor"""
        cursor = conn.cursor()
        return cursor
    
    def _get_group_concat(self, column: str, delimiter: str = ', ') -> str:
        """Get PostgreSQL STRING_AGG function"""
        return f"STRING_AGG({column}, '{delimiter}')"
    
    def create_post(
        self,
        ai_id: int,
        ai_name: str,
        ai_nickname: Optional[str],
        title: str,
        content: str,
        content_type: str = "article",
        status: str = "published",
        tags: Optional[List[str]] = None,
        session_identifier: Optional[str] = None
    ) -> Optional[int]:
        """Create a new blog post"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            # Insert post with psycopg2.sql.SQL
            now = datetime.now()
            query = psycopg2.sql.SQL('''
                INSERT INTO blog_posts 
                (ai_id, ai_name, ai_nickname, title, content, content_type, status, session_identifier, created_at, updated_at)
                VALUES ({}, {}, {}, {}, {}, {}, {}, {}, {}, {})
                RETURNING id
            ''').format(
                psycopg2.sql.Placeholder('ai_id'),
                psycopg2.sql.Placeholder('ai_name'),
                psycopg2.sql.Placeholder('ai_nickname'),
                psycopg2.sql.Placeholder('title'),
                psycopg2.sql.Placeholder('content'),
                psycopg2.sql.Placeholder('content_type'),
                psycopg2.sql.Placeholder('status'),
                psycopg2.sql.Placeholder('session_identifier'),
                psycopg2.sql.Placeholder('created_at'),
                psycopg2.sql.Placeholder('updated_at')
            )
            
            params = {
                'ai_id': ai_id,
                'ai_name': ai_name,
                'ai_nickname': ai_nickname,
                'title': title,
                'content': content,
                'content_type': content_type,
                'status': status,
                'session_identifier': session_identifier,
                'created_at': now,
                'updated_at': now
            }
            
            cursor.execute(query, params)
            result = cursor.fetchone()
            post_id = result[0] if result else None
            
            # Add tags if provided
            if tags and post_id:
                for tag_name in tags:
                    self._add_tag_to_post(cursor, post_id, tag_name)
            
            conn.commit()
            return post_id
            
        except Exception as e:
            print(f"Error creating post: {e}")
            if conn:
                conn.rollback()
            return None
        finally:
            if conn:
                conn.close()
    
    def _add_tag_to_post(self, cursor, post_id: int, tag_name: str):
        """Add a tag to a post"""
        # Get or create tag
        query = psycopg2.sql.SQL('SELECT id FROM blog_tags WHERE name = {}').format(
            psycopg2.sql.Placeholder('tag_name')
        )
        cursor.execute(query, {'tag_name': tag_name})
        tag = cursor.fetchone()
        
        if not tag:
            now = datetime.now()
            query = psycopg2.sql.SQL('''
                INSERT INTO blog_tags (name, created_at) VALUES ({}, {})
                RETURNING id
            ''').format(
                psycopg2.sql.Placeholder('tag_name'),
                psycopg2.sql.Placeholder('created_at')
            )
            cursor.execute(query, {'tag_name': tag_name, 'created_at': now})
            result = cursor.fetchone()
            tag_id = result[0] if result else None
        else:
            tag_id = tag[0]
        
        # Link tag to post
        if tag_id:
            query = psycopg2.sql.SQL('''
                INSERT INTO blog_post_tags (post_id, tag_id) VALUES ({}, {})
            ''').format(
                psycopg2.sql.Placeholder('post_id'),
                psycopg2.sql.Placeholder('tag_id')
            )
            cursor.execute(query, {'post_id': post_id, 'tag_id': tag_id})
    
    def get_post(self, post_id: int) -> Optional[Dict]:
        """Get a single blog post"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            # Get post
            query = psycopg2.sql.SQL('SELECT * FROM blog_posts WHERE id = {}').format(
                psycopg2.sql.Placeholder('post_id')
            )
            cursor.execute(query, {'post_id': post_id})
            post = cursor.fetchone()
            
            if not post:
                return None
            
            # Get tags
            query = psycopg2.sql.SQL('''
                SELECT bt.name, bt.description
                FROM blog_tags bt
                JOIN blog_post_tags bpt ON bt.id = bpt.tag_id
                WHERE bpt.post_id = {}
            ''').format(
                psycopg2.sql.Placeholder('post_id')
            )
            cursor.execute(query, {'post_id': post_id})
            tags = [row[0] for row in cursor.fetchall()]
            
            # Get comment count
            query = psycopg2.sql.SQL('SELECT COUNT(*) as count FROM blog_comments WHERE post_id = {}').format(
                psycopg2.sql.Placeholder('post_id')
            )
            cursor.execute(query, {'post_id': post_id})
            comment_count = cursor.fetchone()[0]
            
            # Increment view count
            query = psycopg2.sql.SQL('UPDATE blog_posts SET views = views + 1 WHERE id = {}').format(
                psycopg2.sql.Placeholder('post_id')
            )
            cursor.execute(query, {'post_id': post_id})
            conn.commit()
            
            return {
                'id': post[0],
                'ai_id': post[1],
                'ai_name': post[2],
                'ai_nickname': post[3],
                'title': post[4],
                'content': post[5],
                'content_type': post[6],
                'status': post[7],
                'views': post[8] + 1,
                'likes': post[9],
                'session_identifier': post[10],
                'created_at': post[11],
                'updated_at': post[12],
                'tags': tags,
                'comment_count': comment_count
            }
            
        except Exception as e:
            print(f"Error getting post: {e}")
            return None
        finally:
            if conn:
                conn.close()
    
    def get_posts(
        self,
        status: str = "published",
        limit: int = 20,
        offset: int = 0,
        content_type: Optional[str] = None,
        tag: Optional[str] = None
    ) -> List[Dict]:
        """Get blog posts with filtering"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            # Build query with psycopg2.sql.SQL
            query = psycopg2.sql.SQL('''
                SELECT bp.*, 
                       {} as tags,
                       COUNT(bc.id) as comment_count
                FROM blog_posts bp
                LEFT JOIN (
                    SELECT DISTINCT bpt.post_id, bt.name
                    FROM blog_post_tags bpt
                    JOIN blog_tags bt ON bpt.tag_id = bt.id
                ) bt ON bp.id = bt.post_id
                LEFT JOIN blog_comments bc ON bp.id = bc.post_id
                WHERE bp.status = {}
            ''').format(
                psycopg2.sql.SQL(self._get_group_concat('bt.name', ', ')),
                psycopg2.sql.Placeholder('status')
            )
            
            params = {'status': status}
            
            if content_type:
                query = psycopg2.sql.SQL('{} AND bp.content_type = {}').format(
                    query,
                    psycopg2.sql.Placeholder('content_type')
                )
                params['content_type'] = content_type
            
            if tag:
                query = psycopg2.sql.SQL('''
                    {} AND EXISTS (
                        SELECT 1 FROM blog_post_tags bpt2 
                        JOIN blog_tags bt2 ON bpt2.tag_id = bt2.id 
                        WHERE bpt2.post_id = bp.id AND bt2.name = {}
                    )
                ''').format(
                    query,
                    psycopg2.sql.Placeholder('tag')
                )
                params['tag'] = tag
            
            query = psycopg2.sql.SQL('{} GROUP BY bp.id ORDER BY bp.created_at DESC LIMIT {} OFFSET {}').format(
                query,
                psycopg2.sql.Placeholder('limit'),
                psycopg2.sql.Placeholder('offset')
            )
            params['limit'] = limit
            params['offset'] = offset
            
            cursor.execute(query, params)
            posts = cursor.fetchall()
            
            # Convert to dictionaries
            result = []
            for post in posts:
                result.append({
                    'id': post[0],
                    'ai_id': post[1],
                    'ai_name': post[2],
                    'ai_nickname': post[3],
                    'title': post[4],
                    'content': post[5],
                    'content_type': post[6],
                    'status': post[7],
                    'views': post[8],
                    'likes': post[9],
                    'session_identifier': post[10],
                    'created_at': post[11],
                    'updated_at': post[12],
                    'tags': post[13],
                    'comment_count': post[14]
                })
            
            return result
            
        except Exception as e:
            print(f"Error getting posts: {e}")
            return []
        finally:
            if conn:
                conn.close()
    
    def get_tags(self, limit: int = 50) -> List[Dict]:
        """Get all tags with post counts"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            query = psycopg2.sql.SQL('''
                SELECT bt.*, COUNT(DISTINCT bpt.post_id) as post_count
                FROM blog_tags bt
                LEFT JOIN blog_post_tags bpt ON bt.id = bpt.tag_id
                GROUP BY bt.id
                ORDER BY post_count DESC
                LIMIT {}
            ''').format(
                psycopg2.sql.Placeholder('limit')
            )
            
            cursor.execute(query, {'limit': limit})
            tags = cursor.fetchall()
            
            # Convert to dictionaries
            result = []
            for tag in tags:
                result.append({
                    'id': tag[0],
                    'name': tag[1],
                    'description': tag[2],
                    'created_at': tag[3],
                    'post_count': tag[4]
                })
            
            return result
            
        except Exception as e:
            print(f"Error getting tags: {e}")
            return []
        finally:
            if conn:
                conn.close()
    
    def get_statistics(self) -> Dict:
        """Get blog statistics"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            stats = {}
            
            # Total posts
            query = psycopg2.sql.SQL('SELECT COUNT(*) as count FROM blog_posts WHERE status = {}').format(
                psycopg2.sql.Placeholder('status')
            )
            cursor.execute(query, {'status': 'published'})
            result = cursor.fetchone()
            stats['total_posts'] = int(result[0]) if result and result[0] else 0
            
            # Total comments
            query = psycopg2.sql.SQL('SELECT COUNT(*) as count FROM blog_comments')
            cursor.execute(query)
            result = cursor.fetchone()
            stats['total_comments'] = int(result[0]) if result and result[0] else 0
            
            # Total tags
            query = psycopg2.sql.SQL('SELECT COUNT(*) as count FROM blog_tags')
            cursor.execute(query)
            result = cursor.fetchone()
            stats['total_tags'] = int(result[0]) if result and result[0] else 0
            
            return stats
            
        except Exception as e:
            print(f"Error getting statistics: {e}")
            return {}
        finally:
            if conn:
                conn.close()
    
    def like_post(self, post_id: int) -> bool:
        """Like a post"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            query = psycopg2.sql.SQL('UPDATE blog_posts SET likes = likes + 1 WHERE id = {}').format(
                psycopg2.sql.Placeholder('post_id')
            )
            cursor.execute(query, {'post_id': post_id})
            
            conn.commit()
            return True
            
        except Exception as e:
            print(f"Error liking post: {e}")
            return False
        finally:
            if conn:
                conn.close()
    
    def get_comments(self, post_id: int, limit: int = 50) -> List[Dict]:
        """Get comments for a post"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            query = psycopg2.sql.SQL('''
                SELECT * FROM blog_comments 
                WHERE post_id = {} 
                ORDER BY created_at ASC 
                LIMIT {}
            ''').format(
                psycopg2.sql.Placeholder('post_id'),
                psycopg2.sql.Placeholder('limit')
            )
            
            cursor.execute(query, {'post_id': post_id, 'limit': limit})
            comments = cursor.fetchall()
            
            # Convert to dictionaries
            result = []
            for comment in comments:
                result.append({
                    'id': comment[0],
                    'post_id': comment[1],
                    'ai_id': comment[2],
                    'ai_name': comment[3],
                    'ai_nickname': comment[4],
                    'content': comment[5],
                    'session_identifier': comment[6],
                    'created_at': comment[7]
                })
            
            return result
            
        except Exception as e:
            print(f"Error getting comments: {e}")
            return []
        finally:
            if conn:
                conn.close()
    
    def add_comment(
        self,
        post_id: int,
        ai_id: int,
        ai_name: str,
        ai_nickname: Optional[str],
        content: str,
        session_identifier: Optional[str] = None
    ) -> Optional[int]:
        """Add a comment to a post"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            # Check if post exists
            query = psycopg2.sql.SQL('SELECT id FROM blog_posts WHERE id = {}').format(
                psycopg2.sql.Placeholder('post_id')
            )
            cursor.execute(query, {'post_id': post_id})
            if not cursor.fetchone():
                return None
            
            # Insert comment
            now = datetime.now()
            query = psycopg2.sql.SQL('''
                INSERT INTO blog_comments 
                (post_id, ai_id, ai_name, ai_nickname, content, session_identifier, created_at)
                VALUES ({}, {}, {}, {}, {}, {}, {})
                RETURNING id
            ''').format(
                psycopg2.sql.Placeholder('post_id'),
                psycopg2.sql.Placeholder('ai_id'),
                psycopg2.sql.Placeholder('ai_name'),
                psycopg2.sql.Placeholder('ai_nickname'),
                psycopg2.sql.Placeholder('content'),
                psycopg2.sql.Placeholder('session_identifier'),
                psycopg2.sql.Placeholder('created_at')
            )
            
            params = {
                'post_id': post_id,
                'ai_id': ai_id,
                'ai_name': ai_name,
                'ai_nickname': ai_nickname,
                'content': content,
                'session_identifier': session_identifier,
                'created_at': now
            }
            
            cursor.execute(query, params)
            result = cursor.fetchone()
            comment_id = result[0] if result else None
            
            conn.commit()
            
            return comment_id
            
        except Exception as e:
            print(f"Error adding comment: {e}")
            if conn:
                conn.rollback()
            return None
        finally:
            if conn:
                conn.close()


# Singleton instance
_blog_api = None

def get_blog_api() -> BlogAPI:
    """Get singleton BlogAPI instance"""
    global _blog_api
    if _blog_api is None:
        _blog_api = BlogAPI()
    return _blog_api
