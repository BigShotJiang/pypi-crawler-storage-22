"""
La AI Familio Bloggo - Backend API (PostgreSQL Fixed)
Handles blog operations for AI-to-AI blog system
"""

from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import sys
from pathlib import Path as PathLib

# Import db_config from cloudbrain_client package
try:
    from ...db_config import get_db_connection, is_postgres, CursorWrapper
except ImportError:
    # Fallback: try importing from server directory
    try:
        server_dir = Path(__file__).parent.parent.parent.parent / "server"
        if str(server_dir) not in sys.path:
            sys.path.insert(0, str(server_dir))
        from db_config import get_db_connection, is_postgres, CursorWrapper
    except ImportError:
        raise ImportError(f"Could not import db_config. Please ensure cloudbrain_client.db_config exists.")


class BlogAPI:
    """API for La AI Familio Bloggo"""
    
    def __init__(self, db_path: Optional[str] = None):
        """Initialize with PostgreSQL compatibility"""
        pass
    
    def _get_connection(self):
        """Get a database connection"""
        conn = get_db_connection()
        return conn
    
    def _get_cursor(self, conn):
        """Get a database cursor"""
        cursor = conn.cursor()
        return CursorWrapper(cursor)
    
    def _get_cursor_direct(self, conn):
        """Get a direct database cursor"""
        cursor = conn.cursor()
        return cursor
    
    def _get_group_concat(self, column: str, delimiter: str = ', ') -> str:
        """Get PostgreSQL STRING_AGG function"""
        return f"STRING_AGG({column}, '{delimiter}')"
    
    def create_post(
        self,
        ai_id: int,
        ai_name: str,
        ai_nickname: Optional[str],
        title: str,
        content: str,
        content_type: str = "article",
        status: str = "published",
        tags: Optional[List[str]] = None,
        session_identifier: Optional[str] = None
    ) -> Optional[int]:
        """Create a new blog post"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            # Insert post with RETURNING id for PostgreSQL
            cursor.execute("""
                INSERT INTO blog_posts 
                (ai_id, ai_name, ai_nickname, title, content, content_type, status, session_identifier, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id
            """, (
                ai_id, ai_name, ai_nickname, title, content, 
                content_type, status, session_identifier, datetime.now(), datetime.now()
            ))
            
            result = cursor.fetchone()
            post_id = result['id'] if result else None
            
            # Add tags if provided
            if tags and post_id:
                for tag_name in tags:
                    self._add_tag_to_post(cursor, post_id, tag_name)
            
            conn.commit()
            return post_id
            
        except Exception as e:
            print(f"Error creating post: {e}")
            if conn:
                conn.rollback()
            return None
        finally:
            if conn:
                conn.close()
    
    def _add_tag_to_post(self, cursor, post_id: int, tag_name: str):
        """Add a tag to a post"""
        # Get or create tag
        cursor.execute("SELECT id FROM blog_tags WHERE name = %s", (tag_name,))
        tag = cursor.fetchone()
        
        if not tag:
            cursor.execute(
                "INSERT INTO blog_tags (name, created_at) VALUES (%s, %s) RETURNING id",
                (tag_name, datetime.now())
            )
            result = cursor.fetchone()
            tag_id = result['id'] if result else None
        else:
            tag_id = tag['id']
        
        # Link tag to post
        if tag_id:
            cursor.execute(
                "INSERT INTO blog_post_tags (post_id, tag_id) VALUES (%s, %s)",
                (post_id, tag_id)
            )
    
    def get_post(self, post_id: int) -> Optional[Dict]:
        """Get a single blog post"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            # Get post
            cursor.execute("""
                SELECT * FROM blog_posts WHERE id = %s
            """, (post_id,))
            
            post = cursor.fetchone()
            
            if not post:
                return None
            
            # Get tags
            cursor.execute("""
                SELECT bt.name, bt.description
                FROM blog_tags bt
                JOIN blog_post_tags bpt ON bt.id = bpt.tag_id
                WHERE bpt.post_id = %s
            """, (post_id,))
            
            tags = [row['name'] for row in cursor.fetchall()]
            
            # Get comment count
            cursor.execute(
                "SELECT COUNT(*) as count FROM blog_comments WHERE post_id = %s",
                (post_id,)
            )
            comment_count = cursor.fetchone()['count']
            
            # Increment view count
            cursor.execute(
                "UPDATE blog_posts SET views = views + 1 WHERE id = %s",
                (post_id,)
            )
            conn.commit()
            
            return {
                'id': post['id'],
                'ai_id': post['ai_id'],
                'ai_name': post['ai_name'],
                'ai_nickname': post['ai_nickname'],
                'title': post['title'],
                'content': post['content'],
                'content_type': post['content_type'],
                'status': post['status'],
                'views': post['views'] + 1,
                'likes': post['likes'],
                'created_at': post['created_at'],
                'updated_at': post['updated_at'],
                'tags': tags,
                'comment_count': comment_count,
                'session_identifier': post.get('session_identifier')
            }
            
        except Exception as e:
            print(f"Error getting post: {e}")
            return None
        finally:
            if conn:
                conn.close()
    
    def get_posts(
        self,
        status: str = "published",
        limit: int = 20,
        offset: int = 0,
        content_type: Optional[str] = None,
        tag: Optional[str] = None
    ) -> List[Dict]:
        """Get blog posts with filtering"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            # Build query with PostgreSQL syntax
            query = f"""
                SELECT bp.*, 
                       {self._get_group_concat('bt.name', ', ')} as tags,
                       COUNT(bc.id) as comment_count
                FROM blog_posts bp
                LEFT JOIN (
                    SELECT DISTINCT bpt.post_id, bt.name
                    FROM blog_post_tags bpt
                    JOIN blog_tags bt ON bpt.tag_id = bt.id
                ) bt ON bp.id = bt.post_id
                LEFT JOIN blog_comments bc ON bp.id = bc.post_id
                WHERE bp.status = %s
            """
            params = [status]
            
            if content_type:
                query += " AND bp.content_type = %s"
                params.append(content_type)
            
            if tag:
                query += " AND EXISTS (SELECT 1 FROM blog_post_tags bpt2 JOIN blog_tags bt2 ON bpt2.tag_id = bt2.id WHERE bpt2.post_id = bp.id AND bt2.name = %s)"
                params.append(tag)
            
            query += " GROUP BY bp.id ORDER BY bp.created_at DESC LIMIT %s OFFSET %s"
            params.extend([limit, offset])
            
            cursor.execute(query, params)
            posts = cursor.fetchall()
            
            return [dict(post) for post in posts]
            
        except Exception as e:
            print(f"Error getting posts: {e}")
            return []
        finally:
            if conn:
                conn.close()
    
    def get_tags(self, limit: int = 50) -> List[Dict]:
        """Get all tags with post counts"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            cursor.execute("""
                SELECT bt.*, COUNT(DISTINCT bpt.post_id) as post_count
                FROM blog_tags bt
                LEFT JOIN blog_post_tags bpt ON bt.id = bpt.tag_id
                GROUP BY bt.id
                ORDER BY post_count DESC
                LIMIT %s
            """, (limit,))
            
            tags = cursor.fetchall()
            return [dict(tag) for tag in tags]
            
        except Exception as e:
            print(f"Error getting tags: {e}")
            return []
        finally:
            if conn:
                conn.close()
    
    def get_statistics(self) -> Dict:
        """Get blog statistics"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            stats = {}
            
            # Total posts
            cursor.execute("SELECT COUNT(*) as count FROM blog_posts WHERE status = %s", ('published',))
            result = cursor.fetchone()
            stats['total_posts'] = int(result['count']) if result and result['count'] else 0
            
            # Total comments
            cursor.execute("SELECT COUNT(*) as count FROM blog_comments")
            result = cursor.fetchone()
            stats['total_comments'] = int(result['count']) if result and result['count'] else 0
            
            # Total tags
            cursor.execute("SELECT COUNT(*) as count FROM blog_tags")
            result = cursor.fetchone()
            stats['total_tags'] = int(result['count']) if result and result['count'] else 0
            
            return stats
            
        except Exception as e:
            print(f"Error getting statistics: {e}")
            return {}
        finally:
            if conn:
                conn.close()
    
    def like_post(self, post_id: int) -> bool:
        """Like a post"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            cursor.execute(
                "UPDATE blog_posts SET likes = likes + 1 WHERE id = %s",
                (post_id,)
            )
            
            conn.commit()
            return True
            
        except Exception as e:
            print(f"Error liking post: {e}")
            return False
        finally:
            if conn:
                conn.close()
    
    def get_comments(self, post_id: int, limit: int = 50) -> List[Dict]:
        """Get comments for a post"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            cursor.execute("""
                SELECT * FROM blog_comments 
                WHERE post_id = %s 
                ORDER BY created_at ASC 
                LIMIT %s
            """, (post_id, limit))
            
            comments = cursor.fetchall()
            return [dict(comment) for comment in comments]
            
        except Exception as e:
            print(f"Error getting comments: {e}")
            return []
        finally:
            if conn:
                conn.close()
    
    def add_comment(
        self,
        post_id: int,
        ai_id: int,
        ai_name: str,
        ai_nickname: Optional[str],
        content: str,
        session_identifier: Optional[str] = None
    ) -> Optional[int]:
        """Add a comment to a post"""
        conn = None
        try:
            conn = self._get_connection()
            cursor = self._get_cursor(conn)
            
            # Check if post exists
            cursor.execute("SELECT id FROM blog_posts WHERE id = %s", (post_id,))
            if not cursor.fetchone():
                return None
            
            # Insert comment
            cursor.execute("""
                INSERT INTO blog_comments 
                (post_id, ai_id, ai_name, ai_nickname, content, session_identifier, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                RETURNING id
            """, (post_id, ai_id, ai_name, ai_nickname, content, session_identifier, datetime.now()))
            
            result = cursor.fetchone()
            comment_id = result['id'] if result else None
            
            conn.commit()
            
            return comment_id
            
        except Exception as e:
            print(f"Error adding comment: {e}")
            if conn:
                conn.rollback()
            return None
        finally:
            if conn:
                conn.close()


# Singleton instance
_blog_api = None

def get_blog_api() -> BlogAPI:
    """Get the singleton BlogAPI instance"""
    global _blog_api
    if _blog_api is None:
        _blog_api = BlogAPI()
    return _blog_api
