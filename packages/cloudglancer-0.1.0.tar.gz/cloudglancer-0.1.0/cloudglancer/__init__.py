"""cloudglancer: Simple interactive visualization of 3D point clouds"""

from cloudglancer.scatter import plot, combine_plots

__version__ = "0.1.0"
__all__ = ["plot", "combine_plots"]
