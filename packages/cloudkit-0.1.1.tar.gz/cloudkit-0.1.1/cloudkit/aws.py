import json
from typing import Any, Dict, List, Optional, Union
import asyncio
from datetime import datetime, timedelta

import boto3
import aioboto3

from .interfaces import (
    StorageService,
    DBService, 
    MessagingService,
    TextAnalysisService,
    ChatService,
    EmbeddingService,
    SearchService,
)


class S3StorageService(StorageService):
    def __init__(self, config: Dict[str, Any]):
        self.bucket_name = config.get("aws_s3_bucket_name")
        self.region = config.get("aws_region", "us-east-1")
        
        # Initialize sync and async clients
        self.s3_client = boto3.client(
            's3',
            region_name=self.region,
            aws_access_key_id=config.get("aws_access_key_id"),
            aws_secret_access_key=config.get("aws_secret_access_key")
        )
        
        self.session = aioboto3.Session(
            aws_access_key_id=config.get("aws_access_key_id"),
            aws_secret_access_key=config.get("aws_secret_access_key"),
            region_name=self.region
        )

    async def upload_file(self, file_path: str, data: bytes) -> str:
        async with self.session.client('s3') as s3:
            await s3.put_object(
                Bucket=self.bucket_name,
                Key=file_path,
                Body=data
            )
        return f"s3://{self.bucket_name}/{file_path}"

    async def download_file(self, path: str) -> bytes:
        async with self.session.client('s3') as s3:
            response = await s3.get_object(Bucket=self.bucket_name, Key=path)
            return await response['Body'].read()

    async def get_file_url(self, path: str, expiry_hours: int = 24) -> str:
        # Generate presigned URL
        url = self.s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': self.bucket_name, 'Key': path},
            ExpiresIn=expiry_hours * 3600
        )
        return url

    async def list_files(self, prefix: str) -> List[str]:
        async with self.session.client('s3') as s3:
            response = await s3.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=prefix
            )
            return [obj['Key'] for obj in response.get('Contents', [])]

    async def delete_file(self, path: str) -> bool:
        async with self.session.client('s3') as s3:
            await s3.delete_object(Bucket=self.bucket_name, Key=path)
        return True


class DynamoDBService(DBService):
    def __init__(self, config: Dict[str, Any]):
        self.region = config.get("aws_region", "us-east-1")
        
        self.session = aioboto3.Session(
            aws_access_key_id=config.get("aws_access_key_id"),
            aws_secret_access_key=config.get("aws_secret_access_key"),
            region_name=self.region
        )

    async def get_item(self, table: str, key: Dict[str, Any]) -> Dict[str, Any]:
        async with self.session.resource('dynamodb') as dynamodb:
            table_resource = await dynamodb.Table(table)
            response = await table_resource.get_item(Key=key)
            return response.get('Item')

    async def put_item(self, table: str, item: Dict[str, Any]) -> Dict[str, Any]:
        async with self.session.resource('dynamodb') as dynamodb:
            table_resource = await dynamodb.Table(table)
            await table_resource.put_item(Item=item)
            return item

    async def query(
        self, table: str, query_params: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        async with self.session.resource('dynamodb') as dynamodb:
            table_resource = await dynamodb.Table(table)
            
            # Support different query types
            if 'KeyConditionExpression' in query_params:
                response = await table_resource.query(**query_params)
            else:
                response = await table_resource.scan(**query_params)
            
            return response.get('Items', [])

    async def delete_item(self, table: str, key: Dict[str, Any]) -> bool:
        async with self.session.resource('dynamodb') as dynamodb:
            table_resource = await dynamodb.Table(table)
            await table_resource.delete_item(Key=key)
        return True


class SQSMessagingService(MessagingService):
    def __init__(self, config: Dict[str, Any]):
        self.region = config.get("aws_region", "us-east-1")
        
        self.session = aioboto3.Session(
            aws_access_key_id=config.get("aws_access_key_id"),
            aws_secret_access_key=config.get("aws_secret_access_key"),
            region_name=self.region
        )

    async def send_message(
        self, queue: str, message: str, attributes: Dict[str, Any] = None
    ) -> str:
        async with self.session.client('sqs') as sqs:
            params = {
                'QueueUrl': queue,
                'MessageBody': message
            }
            
            if attributes:
                params['MessageAttributes'] = {
                    k: {'StringValue': str(v), 'DataType': 'String'}
                    for k, v in attributes.items()
                }
            
            response = await sqs.send_message(**params)
            return response['MessageId']

    async def receive_messages(
        self, queue: str, max_messages: int = 10
    ) -> List[Dict[str, Any]]:
        async with self.session.client('sqs') as sqs:
            response = await sqs.receive_message(
                QueueUrl=queue,
                MaxNumberOfMessages=min(max_messages, 10),
                WaitTimeSeconds=20,
                MessageAttributeNames=['All']
            )
            return response.get('Messages', [])

    async def delete_message(self, queue: str, receipt_handle: str) -> bool:
        async with self.session.client('sqs') as sqs:
            await sqs.delete_message(
                QueueUrl=queue,
                ReceiptHandle=receipt_handle
            )
        return True


# AI Services
class ComprehendTextAnalysisService(TextAnalysisService):
    def __init__(self, config: Dict[str, Any]):
        self.region = config.get("aws_region", "us-east-1")
        
        self.session = aioboto3.Session(
            aws_access_key_id=config.get("aws_access_key_id"),
            aws_secret_access_key=config.get("aws_secret_access_key"),
            region_name=self.region
        )

    async def analyze_sentiment(self, text: str, language: str = "en") -> Dict[str, Any]:
        async with self.session.client('comprehend') as comprehend:
            response = await comprehend.detect_sentiment(
                Text=text,
                LanguageCode=language
            )
            return {
                'sentiment': response['Sentiment'],
                'confidence': response['SentimentScore'][response['Sentiment']]
            }

    async def extract_key_phrases(self, text: str, language: str = "en") -> List[str]:
        async with self.session.client('comprehend') as comprehend:
            response = await comprehend.detect_key_phrases(
                Text=text,
                LanguageCode=language
            )
            return [phrase['Text'] for phrase in response['KeyPhrases']]

    async def recognize_entities(self, text: str, language: str = "en") -> List[Dict[str, Any]]:
        async with self.session.client('comprehend') as comprehend:
            response = await comprehend.detect_entities(
                Text=text,
                LanguageCode=language
            )
            return [
                {
                    'text': entity['Text'],
                    'type': entity['Type'],
                    'confidence': entity['Score']
                }
                for entity in response['Entities']
            ]

    async def detect_language(self, text: str) -> Dict[str, Any]:
        async with self.session.client('comprehend') as comprehend:
            response = await comprehend.detect_dominant_language(Text=text)
            
            if response['Languages']:
                lang = response['Languages'][0]
                return {
                    'language': lang['LanguageCode'],
                    'confidence': lang['Score']
                }
            return {'language': 'unknown', 'confidence': 0.0}


class BedrockChatService(ChatService):
    def __init__(self, config: Dict[str, Any]):
        self.region = config.get("aws_region", "us-east-1")
        
        self.session = aioboto3.Session(
            aws_access_key_id=config.get("aws_access_key_id"),
            aws_secret_access_key=config.get("aws_secret_access_key"),
            region_name=self.region
        )

    async def chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str = "anthropic.claude-3-sonnet-20240229-v1:0",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> Dict[str, Any]:
        async with self.session.client('bedrock-runtime') as bedrock:
            # Format messages for Claude
            system_message = ""
            human_messages = []
            
            for msg in messages:
                if msg['role'] == 'system':
                    system_message = msg['content']
                elif msg['role'] == 'user':
                    human_messages.append(f"Human: {msg['content']}")
                elif msg['role'] == 'assistant':
                    human_messages.append(f"Assistant: {msg['content']}")
            
            prompt = f"{system_message}\n\n" + "\n\n".join(human_messages) + "\n\nAssistant:"
            
            body = {
                "prompt": prompt,
                "temperature": temperature,
                "top_p": 0.9,
                "max_tokens_to_sample": max_tokens or 2048,
                "stop_sequences": ["\n\nHuman:"]
            }
            
            response = await bedrock.invoke_model(
                modelId=model,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(body)
            )
            
            response_body = json.loads(await response['body'].read())
            
            return {
                'choices': [{
                    'message': {
                        'role': 'assistant',
                        'content': response_body['completion']
                    }
                }],
                'usage': {
                    'total_tokens': len(prompt.split()) + len(response_body['completion'].split())
                }
            }

    async def stream_chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str = "anthropic.claude-3-sonnet-20240229-v1:0",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ):
        # For streaming, we'll use the regular completion and yield chunks
        response = await self.chat_completion(messages, model, temperature, max_tokens, **kwargs)
        content = response['choices'][0]['message']['content']
        
        # Simulate streaming by yielding words
        words = content.split()
        for i, word in enumerate(words):
            yield {
                'choices': [{
                    'delta': {
                        'content': word + (' ' if i < len(words) - 1 else '')
                    }
                }]
            }
            await asyncio.sleep(0.05)  # Small delay to simulate streaming


class BedrockEmbeddingService(EmbeddingService):
    def __init__(self, config: Dict[str, Any]):
        self.region = config.get("aws_region", "us-east-1")
        
        self.session = aioboto3.Session(
            aws_access_key_id=config.get("aws_access_key_id"),
            aws_secret_access_key=config.get("aws_secret_access_key"),
            region_name=self.region
        )

    async def create_embeddings(
        self,
        texts: Union[str, List[str]],
        model: str = "amazon.titan-embed-text-v1"
    ) -> List[List[float]]:
        if isinstance(texts, str):
            texts = [texts]
        
        embeddings = []
        async with self.session.client('bedrock-runtime') as bedrock:
            for text in texts:
                body = {"inputText": text}
                
                response = await bedrock.invoke_model(
                    modelId=model,
                    contentType="application/json",
                    accept="application/json", 
                    body=json.dumps(body)
                )
                
                response_body = json.loads(await response['body'].read())
                embeddings.append(response_body['embedding'])
        
        return embeddings

    async def similarity_search(
        self,
        query_embedding: List[float],
        embeddings: List[List[float]],
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        import numpy as np
        
        # Calculate cosine similarity
        query_vec = np.array(query_embedding)
        similarities = []
        
        for i, emb in enumerate(embeddings):
            emb_vec = np.array(emb)
            similarity = np.dot(query_vec, emb_vec) / (np.linalg.norm(query_vec) * np.linalg.norm(emb_vec))
            similarities.append({'index': i, 'similarity': float(similarity)})
        
        # Sort by similarity and return top_k
        similarities.sort(key=lambda x: x['similarity'], reverse=True)
        return similarities[:top_k]


class OpenSearchService(SearchService):
    def __init__(self, config: Dict[str, Any]):
        self.endpoint = config.get("aws_opensearch_endpoint")
        self.region = config.get("aws_region", "us-east-1")
        
        # You would need to install opensearch-py for full functionality
        # For now, we'll use basic HTTP requests
        import httpx
        self.http_client = httpx.AsyncClient()

    async def index_document(
        self,
        index_name: str,
        document_id: str,
        document: Dict[str, Any]
    ) -> bool:
        url = f"{self.endpoint}/{index_name}/_doc/{document_id}"
        response = await self.http_client.put(url, json=document)
        return response.status_code in [200, 201]

    async def search_documents(
        self,
        index_name: str,
        query: str,
        filters: Optional[Dict[str, Any]] = None,
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        url = f"{self.endpoint}/{index_name}/_search"
        
        search_body = {
            "query": {
                "multi_match": {
                    "query": query,
                    "fields": ["*"]
                }
            },
            "size": top_k
        }
        
        if filters:
            search_body["query"] = {
                "bool": {
                    "must": [search_body["query"]],
                    "filter": [{"term": {k: v}} for k, v in filters.items()]
                }
            }
        
        response = await self.http_client.post(url, json=search_body)
        if response.status_code == 200:
            results = response.json()
            return [hit['_source'] for hit in results['hits']['hits']]
        return []

    async def vector_search(
        self,
        index_name: str,
        vector: List[float],
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        url = f"{self.endpoint}/{index_name}/_search"
        
        search_body = {
            "query": {
                "knn": {
                    "vector_field": {
                        "vector": vector,
                        "k": top_k
                    }
                }
            }
        }
        
        response = await self.http_client.post(url, json=search_body)
        if response.status_code == 200:
            results = response.json()
            return [hit['_source'] for hit in results['hits']['hits']]
        return []

    async def delete_document(self, index_name: str, document_id: str) -> bool:
        url = f"{self.endpoint}/{index_name}/_doc/{document_id}"
        response = await self.http_client.delete(url)
        return response.status_code == 200
