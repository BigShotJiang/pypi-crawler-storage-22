import datetime
from typing import Any, Dict, List, Optional, Union
import json

from .interfaces import (
    DBService, 
    MessagingService, 
    StorageService,
    TextAnalysisService,
    ChatService,
    EmbeddingService,
    SearchService,
)


class AzureBlobStorageService(StorageService):
    def __init__(self, config: Dict[str, Any]):
        from azure.storage.blob import BlobServiceClient

        connection_string = config.get("azure_storage_connection_string")
        self.container_name = config.get("azure_storage_container_name")
        self.blob_service = BlobServiceClient.from_connection_string(connection_string)
        self.container_client = self.blob_service.get_container_client(
            self.container_name
        )

    async def upload_file(self, file_path: str, data: bytes) -> str:
        blob_client = self.container_client.get_blob_client(file_path)
        blob_client.upload_blob(data, overwrite=True)
        return f"azure://{self.container_name}/{file_path}"

    async def download_file(self, path: str) -> bytes:
        blob_client = self.container_client.get_blob_client(path)
        download = blob_client.download_blob()
        return download.readall()

    async def get_file_url(self, path: str) -> str:
        from azure.storage.blob import BlobSasPermissions, generate_blob_sas

        # fetch sas token for file for 24h
        blob_client = self.container_client.get_blob_client(path)
        sas_token = generate_blob_sas(
            account_name=blob_client.account_name,
            container_name=blob_client.container_name,
            blob_name=blob_client.blob_name,
            account_key=blob_client.credential.account_key,
            permission=BlobSasPermissions(read=True),
            expiry=datetime.datetime.now(datetime.timezone.utc)
            + datetime.timedelta(hours=24),
            start=datetime.datetime.now(datetime.timezone.utc),
        )
        return f"{blob_client.url}?{sas_token}"

    async def list_files(self, prefix: str) -> List[str]:
        blobs = self.container_client.list_blobs(name_starts_with=prefix)
        return [blob.name for blob in blobs]

    async def delete_file(self, path: str) -> bool:
        blob_client = self.container_client.get_blob_client(path)
        blob_client.delete_blob()
        return True


class CosmosDBService(DBService):
    """Base class for Cosmos DB services"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config

    @classmethod
    def create(cls, config: Dict[str, Any], api_type: str = "nosql"):
        """Factory method to create appropriate Cosmos DB client

        Args:
            config: Configuration dictionary
            api_type: Either "nosql" or "tables"

        Returns:
            The appropriate Cosmos DB service implementation
        """
        if api_type.lower() == "nosql":
            return CosmosDBNoSQLService(config)
        elif api_type.lower() == "table":
            return CosmosDBTableService(config)
        else:
            raise ValueError(
                f"Unsupported API type: {api_type}. Use 'nosql' or 'table'"
            )

    async def get_item(self, table: str, key: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError("Use a concrete implementation")

    async def put_item(self, table: str, item: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError("Use a concrete implementation")

    async def query(
        self, table: str, query_params: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        raise NotImplementedError("Use a concrete implementation")

    async def delete_item(self, table: str, key: Dict[str, Any]) -> bool:
        raise NotImplementedError("Use a concrete implementation")


class CosmosDBNoSQLService(CosmosDBService):
    """Implementation for Cosmos DB NoSQL API"""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        from azure.cosmos import CosmosClient

        # Support both direct endpoint/key and connection string authentication
        connection_string = config.get("azure_cosmos_nosql_connection_string")

        if connection_string:
            self.client = CosmosClient.from_connection_string(connection_string)
        else:
            endpoint = config.get("endpoint")
            key = config.get("key")
            self.client = CosmosClient(endpoint, key)

        self.db_name = config.get("azure_cosmos_nosql_db_name")
        self.db = self.client.get_database_client(self.db_name)
        self.containers = {}  # Cache for container clients

    def _get_container(self, container_name: str):
        if container_name not in self.containers:
            self.containers[container_name] = self.db.get_container_client(
                container_name
            )
        return self.containers[container_name]

    async def get_item(self, table: str, key: Dict[str, Any]) -> Dict[str, Any]:
        container = self._get_container(table)
        id_value = key.get("id")
        partition_key = key.get("PartitionKey", id_value)

        try:
            item = container.read_item(item=id_value, partition_key=partition_key)
            return item
        except Exception:
            return None

    async def put_item(self, table: str, item: Dict[str, Any]) -> Dict[str, Any]:
        container = self._get_container(table)
        response = container.upsert_item(body=item)
        return response

    async def query(
        self, table: str, query_params: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        container = self._get_container(table)
        query = query_params.get("query", "SELECT * FROM c")
        parameters = query_params.get("parameters", [])

        items = container.query_items(
            query=query,
            parameters=parameters,
            enable_cross_partition_query=query_params.get(
                "enable_cross_partition_query", True
            ),
        )

        return list(items)

    async def delete_item(self, table: str, key: Dict[str, Any]) -> bool:
        container = self._get_container(table)
        id_value = key.get("id")
        partition_key = key.get("PartitionKey", id_value)

        container.delete_item(item=id_value, partition_key=partition_key)
        return True


class CosmosDBTableService(CosmosDBService):
    """Implementation for Cosmos DB Table API"""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        from azure.data.tables import TableServiceClient

        connection_string = config.get("azure_cosmos_table_connection_string")
        print(f"Connection string: {connection_string}")

        if not connection_string:
            # Build connection string from account name and key
            account_name = config.get("account_name")
            account_key = config.get("account_key")
            connection_string = f"DefaultEndpointsProtocol=https;AccountName={account_name};AccountKey={account_key};EndpointSuffix=core.windows.net"

        self.table_service = TableServiceClient.from_connection_string(
            connection_string
        )
        for table in self.table_service.list_tables():
            print(table)
        self.tables = {}  # Cache for table clients

    def _get_table(self, table_name: str):
        if table_name not in self.tables:
            self.tables[table_name] = self.table_service.get_table_client(table_name)
        return self.tables[table_name]

    async def get_item(self, table: str, key: Dict[str, Any]) -> Dict[str, Any]:
        table_client = self._get_table(table)
        partition_key = key.get("PartitionKey")
        row_key = key.get("RowKey")

        try:
            item = table_client.get_entity(partition_key=partition_key, row_key=row_key)
            return dict(item)
        except Exception:
            return None

    async def put_item(self, table: str, item: Dict[str, Any]) -> Dict[str, Any]:
        table_client = self._get_table(table)
        # Ensure the item has partition key and row key
        if "PartitionKey" not in item or "RowKey" not in item:
            raise ValueError(
                "Items for Table API must contain 'PartitionKey' and 'RowKey'"
            )

        response = table_client.upsert_entity(entity=item)
        return item  # Table API doesn't return the entity in response

    async def query(
        self, table: str, query_params: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        table_client = self._get_table(table)
        query_filter = query_params.get("filter", None)
        select = query_params.get("select", None)

        params = {}
        if select:
            params["select"] = select

        if query_filter:
            entities = table_client.query_entities(query_filter=query_filter, **params)
        else:
            entities = table_client.list_entities(**params)

        return [dict(entity) for entity in entities]

    async def delete_item(self, table: str, key: Dict[str, Any]) -> bool:
        table_client = self._get_table(table)
        partition_key = key.get("PartitionKey")
        row_key = key.get("RowKey")

        try:
            table_client.delete_entity(partition_key=partition_key, row_key=row_key)
            return True
        except Exception:
            return False


class ServiceBusMessagingService(MessagingService):
    def __init__(self, config: Dict[str, Any]):
        from azure.servicebus import ServiceBusClient

        connection_string = config.get("connection_string")
        self.sb_client = ServiceBusClient.from_connection_string(connection_string)
        self.senders = {}
        self.receivers = {}

    async def send_message(
        self, queue: str, message: str, attributes: Dict[str, Any] = None
    ) -> str:
        if queue not in self.senders:
            self.senders[queue] = self.sb_client.get_queue_sender(queue_name=queue)

        sender = self.senders[queue]

        from azure.servicebus import ServiceBusMessage

        message_obj = ServiceBusMessage(message)

        if attributes:
            for key, value in attributes.items():
                message_obj.application_properties[key] = value

        await sender.send_messages(message_obj)
        return "message-sent"  # Azure doesn't return a message ID in the same way

    async def receive_messages(
        self, queue: str, max_messages: int = 10
    ) -> List[Dict[str, Any]]:
        if queue not in self.receivers:
            self.receivers[queue] = self.sb_client.get_queue_receiver(queue_name=queue)

        receiver = self.receivers[queue]
        received_msgs = await receiver.receive_messages(
            max_message_count=max_messages, max_wait_time=5
        )

        messages = []
        for msg in received_msgs:
            message_dict = {
                "body": str(msg),
                "message_id": msg.message_id,
                "receipt_handle": msg,  # Store the actual message object for deletion
                "properties": dict(msg.application_properties)
                if msg.application_properties
                else {},
            }
            messages.append(message_dict)

        return messages

    async def delete_message(self, queue: str, receipt_handle: str) -> bool:
        # In this implementation, receipt_handle is actually the message object
        if isinstance(receipt_handle, str):
            # This is a simplified implementation - in a real scenario
            # you'd need a way to map receipt handles back to message objects
            return False

        if queue in self.receivers:
            receiver = self.receivers[queue]
            await receiver.complete_message(receipt_handle)
            return True

        return False


# Azure AI Services
class AzureTextAnalysisService(TextAnalysisService):
    def __init__(self, config: Dict[str, Any]):
        from azure.ai.textanalytics import TextAnalyticsClient
        from azure.core.credentials import AzureKeyCredential
        
        endpoint = config.get("azure_cognitive_services_endpoint")
        key = config.get("azure_cognitive_services_key")
        
        self.client = TextAnalyticsClient(
            endpoint=endpoint,
            credential=AzureKeyCredential(key)
        )

    async def analyze_sentiment(self, text: str, language: str = "en") -> Dict[str, Any]:
        documents = [{"id": "1", "text": text, "language": language}]
        response = self.client.analyze_sentiment(documents=documents)
        
        result = response[0]
        return {
            'sentiment': result.sentiment,
            'confidence': result.sentiment_scores.positive if result.sentiment == 'positive' else 
                        result.sentiment_scores.negative if result.sentiment == 'negative' else
                        result.sentiment_scores.neutral
        }

    async def extract_key_phrases(self, text: str, language: str = "en") -> List[str]:
        documents = [{"id": "1", "text": text, "language": language}]
        response = self.client.extract_key_phrases(documents=documents)
        
        result = response[0]
        return result.key_phrases

    async def recognize_entities(self, text: str, language: str = "en") -> List[Dict[str, Any]]:
        documents = [{"id": "1", "text": text, "language": language}]
        response = self.client.recognize_entities(documents=documents)
        
        result = response[0]
        return [
            {
                'text': entity.text,
                'type': entity.category,
                'confidence': entity.confidence_score
            }
            for entity in result.entities
        ]

    async def detect_language(self, text: str) -> Dict[str, Any]:
        documents = [{"id": "1", "text": text}]
        response = self.client.detect_language(documents=documents)
        
        result = response[0]
        primary_language = result.primary_language
        return {
            'language': primary_language.iso6391_name,
            'confidence': primary_language.confidence_score
        }


class AzureOpenAIChatService(ChatService):
    def __init__(self, config: Dict[str, Any]):
        from openai import AsyncAzureOpenAI
        
        self.client = AsyncAzureOpenAI(
            api_key=config.get("azure_openai_api_key"),
            api_version=config.get("azure_openai_api_version", "2023-12-01-preview"),
            azure_endpoint=config.get("azure_openai_endpoint")
        )

    async def chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str = "gpt-35-turbo",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> Dict[str, Any]:
        response = await self.client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs
        )
        
        return {
            'choices': [
                {
                    'message': {
                        'role': choice.message.role,
                        'content': choice.message.content
                    }
                }
                for choice in response.choices
            ],
            'usage': {
                'total_tokens': response.usage.total_tokens,
                'prompt_tokens': response.usage.prompt_tokens,
                'completion_tokens': response.usage.completion_tokens
            }
        }

    async def stream_chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str = "gpt-35-turbo",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ):
        stream = await self.client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True,
            **kwargs
        )
        
        async for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content:
                yield {
                    'choices': [{
                        'delta': {
                            'content': chunk.choices[0].delta.content
                        }
                    }]
                }


class AzureOpenAIEmbeddingService(EmbeddingService):
    def __init__(self, config: Dict[str, Any]):
        from openai import AsyncAzureOpenAI
        
        self.client = AsyncAzureOpenAI(
            api_key=config.get("azure_openai_api_key"),
            api_version=config.get("azure_openai_api_version", "2023-12-01-preview"),
            azure_endpoint=config.get("azure_openai_endpoint")
        )

    async def create_embeddings(
        self,
        texts: Union[str, List[str]],
        model: str = "text-embedding-ada-002"
    ) -> List[List[float]]:
        if isinstance(texts, str):
            texts = [texts]
        
        response = await self.client.embeddings.create(
            model=model,
            input=texts
        )
        
        return [data.embedding for data in response.data]

    async def similarity_search(
        self,
        query_embedding: List[float],
        embeddings: List[List[float]],
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        import numpy as np
        
        # Calculate cosine similarity
        query_vec = np.array(query_embedding)
        similarities = []
        
        for i, emb in enumerate(embeddings):
            emb_vec = np.array(emb)
            similarity = np.dot(query_vec, emb_vec) / (np.linalg.norm(query_vec) * np.linalg.norm(emb_vec))
            similarities.append({'index': i, 'similarity': float(similarity)})
        
        # Sort by similarity and return top_k
        similarities.sort(key=lambda x: x['similarity'], reverse=True)
        return similarities[:top_k]


class AzureSearchService(SearchService):
    def __init__(self, config: Dict[str, Any]):
        from azure.search.documents import SearchClient
        from azure.core.credentials import AzureKeyCredential
        
        self.service_name = config.get("azure_search_service_name")
        self.admin_key = config.get("azure_search_admin_key")
        self.endpoint = f"https://{self.service_name}.search.windows.net"
        
        self.credential = AzureKeyCredential(self.admin_key)
        self.search_clients = {}  # Cache for search clients per index

    def _get_search_client(self, index_name: str):
        if index_name not in self.search_clients:
            from azure.search.documents import SearchClient
            self.search_clients[index_name] = SearchClient(
                endpoint=self.endpoint,
                index_name=index_name,
                credential=self.credential
            )
        return self.search_clients[index_name]

    async def index_document(
        self,
        index_name: str,
        document_id: str,
        document: Dict[str, Any]
    ) -> bool:
        search_client = self._get_search_client(index_name)
        
        # Ensure document has a key field
        if '@search.action' not in document:
            document['@search.action'] = 'upload'
        
        # Ensure document has an id field
        if 'id' not in document:
            document['id'] = document_id
        
        try:
            result = search_client.upload_documents([document])
            return len(result) > 0 and result[0].succeeded
        except Exception:
            return False

    async def search_documents(
        self,
        index_name: str,
        query: str,
        filters: Optional[Dict[str, Any]] = None,
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        search_client = self._get_search_client(index_name)
        
        search_params = {
            'search_text': query,
            'top': top_k
        }
        
        if filters:
            # Convert filters to OData filter string
            filter_parts = []
            for key, value in filters.items():
                if isinstance(value, str):
                    filter_parts.append(f"{key} eq '{value}'")
                else:
                    filter_parts.append(f"{key} eq {value}")
            
            if filter_parts:
                search_params['filter'] = ' and '.join(filter_parts)
        
        results = search_client.search(**search_params)
        return [dict(result) for result in results]

    async def vector_search(
        self,
        index_name: str,
        vector: List[float],
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        search_client = self._get_search_client(index_name)
        
        # Azure Cognitive Search vector search
        from azure.search.documents.models import VectorizedQuery
        
        vector_query = VectorizedQuery(
            vector=vector,
            k_nearest_neighbors=top_k,
            fields="vector_field"  # This should match your vector field name
        )
        
        results = search_client.search(
            search_text=None,
            vector_queries=[vector_query]
        )
        
        return [dict(result) for result in results]

    async def delete_document(self, index_name: str, document_id: str) -> bool:
        search_client = self._get_search_client(index_name)
        
        try:
            result = search_client.delete_documents([{"id": document_id}])
            return len(result) > 0 and result[0].succeeded
        except Exception:
            return False
