from typing import Optional, Dict, Any
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings


class AzureConfig(BaseModel):
    """Azure-specific configuration"""
    # Storage
    azure_storage_connection_string: Optional[str] = None
    azure_storage_container_name: Optional[str] = None
    
    # Cosmos DB
    azure_cosmos_nosql_connection_string: Optional[str] = None
    azure_cosmos_nosql_db_name: Optional[str] = None
    azure_cosmos_table_connection_string: Optional[str] = None
    
    # Service Bus
    azure_servicebus_connection_string: Optional[str] = None
    
    # Cognitive Services
    azure_cognitive_services_endpoint: Optional[str] = None
    azure_cognitive_services_key: Optional[str] = None
    
    # OpenAI
    azure_openai_api_key: Optional[str] = None
    azure_openai_endpoint: Optional[str] = None
    azure_openai_api_version: str = "2023-12-01-preview"
    
    # Search
    azure_search_service_name: Optional[str] = None
    azure_search_admin_key: Optional[str] = None


class AWSConfig(BaseModel):
    """AWS-specific configuration"""
    # General
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_region: str = "us-east-1"
    
    # S3
    aws_s3_bucket_name: Optional[str] = None
    
    # OpenSearch
    aws_opensearch_endpoint: Optional[str] = None


class CloudSDKSettings(BaseSettings):
    """Main SDK configuration"""
    cloud_provider: str = Field(default="azure", description="Cloud provider: 'azure' or 'aws'")
    
    # Azure settings
    azure: AzureConfig = Field(default_factory=AzureConfig)
    
    # AWS settings 
    aws: AWSConfig = Field(default_factory=AWSConfig)
    
    class Config:
        env_prefix = "CLOUD_SDK_"
        env_nested_delimiter = "__"
        case_sensitive = False


def get_provider_config(provider_type: str = "azure", custom_config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Get configuration for a specific cloud provider
    
    Args:
        provider_type: Either 'azure' or 'aws'
        custom_config: Optional dictionary to override default config
        
    Returns:
        Configuration dictionary for the specified provider
    """
    settings = CloudSDKSettings()
    
    if provider_type == "azure":
        config = settings.azure.model_dump()
    elif provider_type == "aws":
        config = settings.aws.model_dump()
    else:
        raise ValueError(f"Unsupported provider type: {provider_type}")
    
    # Add general cloud provider setting
    config["cloud_provider"] = provider_type
    
    # Override with custom config if provided
    if custom_config:
        config.update(custom_config)
    
    return config 