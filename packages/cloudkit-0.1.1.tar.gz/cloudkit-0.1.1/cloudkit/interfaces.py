from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union


class StorageService(ABC):
    @abstractmethod
    async def upload_file(self, file_path: str, data: bytes) -> str:
        pass

    @abstractmethod
    async def download_file(self, path: str) -> bytes:
        pass

    @abstractmethod
    async def get_file_url(self, path: str) -> str:
        pass

    @abstractmethod
    async def list_files(self, prefix: str) -> List[str]:
        pass

    @abstractmethod
    async def delete_file(self, path: str) -> bool:
        pass


class DBService(ABC):
    @abstractmethod
    async def get_item(self, table: str, key: Dict[str, Any]) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def put_item(self, table: str, item: Dict[str, Any]) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def query(
        self, table: str, query_params: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    async def delete_item(self, table: str, key: Dict[str, Any]) -> bool:
        pass


class MessagingService(ABC):
    @abstractmethod
    async def send_message(
        self, queue: str, message: str, attributes: Dict[str, Any] = None
    ) -> str:
        pass

    @abstractmethod
    async def receive_messages(
        self, queue: str, max_messages: int = 10
    ) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    async def delete_message(self, queue: str, receipt_handle: str) -> bool:
        pass


# AI Service Interfaces
class AIService(ABC):
    """Base class for AI services"""
    pass


class TextAnalysisService(AIService):
    @abstractmethod
    async def analyze_sentiment(self, text: str, language: str = "en") -> Dict[str, Any]:
        """Analyze sentiment of text"""
        pass

    @abstractmethod
    async def extract_key_phrases(self, text: str, language: str = "en") -> List[str]:
        """Extract key phrases from text"""
        pass

    @abstractmethod
    async def recognize_entities(self, text: str, language: str = "en") -> List[Dict[str, Any]]:
        """Recognize named entities in text"""
        pass

    @abstractmethod
    async def detect_language(self, text: str) -> Dict[str, Any]:
        """Detect language of text"""
        pass


class ChatService(AIService):
    @abstractmethod
    async def chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str = "gpt-3.5-turbo",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Generate chat completion"""
        pass

    @abstractmethod
    async def stream_chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str = "gpt-3.5-turbo", 
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ):
        """Generate streaming chat completion"""
        pass


class EmbeddingService(AIService):
    @abstractmethod
    async def create_embeddings(
        self,
        texts: Union[str, List[str]],
        model: str = "text-embedding-ada-002"
    ) -> List[List[float]]:
        """Create embeddings for text(s)"""
        pass

    @abstractmethod
    async def similarity_search(
        self,
        query_embedding: List[float],
        embeddings: List[List[float]],
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        """Find most similar embeddings"""
        pass


class SearchService(AIService):
    @abstractmethod
    async def index_document(
        self,
        index_name: str,
        document_id: str,
        document: Dict[str, Any]
    ) -> bool:
        """Index a document"""
        pass

    @abstractmethod
    async def search_documents(
        self,
        index_name: str,
        query: str,
        filters: Optional[Dict[str, Any]] = None,
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        """Search documents"""
        pass

    @abstractmethod
    async def vector_search(
        self,
        index_name: str,
        vector: List[float],
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        """Vector-based search"""
        pass

    @abstractmethod
    async def delete_document(self, index_name: str, document_id: str) -> bool:
        """Delete a document from index"""
        pass
