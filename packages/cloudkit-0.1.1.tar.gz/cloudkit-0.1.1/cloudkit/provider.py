from typing import Any, Dict, Optional, List

from .azure import (
    AzureBlobStorageService, 
    CosmosDBService, 
    ServiceBusMessagingService,
    AzureTextAnalysisService,
    AzureOpenAIChatService,
    AzureOpenAIEmbeddingService,
    AzureSearchService,
)
from .aws import (
    S3StorageService,
    DynamoDBService,
    SQSMessagingService,
    ComprehendTextAnalysisService,
    BedrockChatService,
    BedrockEmbeddingService,
    OpenSearchService,
)
from .interfaces import (
    DBService, 
    MessagingService, 
    StorageService,
    TextAnalysisService,
    ChatService,
    EmbeddingService,
    SearchService,
)


class CloudProvider:
    def __init__(
        self,
        provider_type: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
    ):
        # Determine the cloud provider type
        self.provider_type = provider_type or config.get("cloud_provider", "azure")

        # Load configuration
        self.config = config or {}

        # Initialize service instances
        self._storage_service = None
        self._db_nosql_service = None
        self._db_table_service = None
        self._messaging_service = None
        self._text_analysis_service = None
        self._chat_service = None
        self._embedding_service = None
        self._search_service = None

    def get_storage_service(self) -> StorageService:
        """Returns the appropriate storage service for the configured cloud provider."""
        if not self._storage_service:
            if self.provider_type == "aws":
                self._storage_service = S3StorageService(self.config)
            else:  # azure
                self._storage_service = AzureBlobStorageService(self.config)

        return self._storage_service

    def get_db_nosql_service(self) -> DBService:
        """Returns the appropriate NoSQL database service for the configured cloud provider."""
        if not self._db_nosql_service:
            if self.provider_type == "aws":
                self._db_nosql_service = DynamoDBService(self.config)
            else:  # azure
                self._db_nosql_service = CosmosDBService.create(
                    self.config, api_type="nosql"
                )

        return self._db_nosql_service

    def get_db_table_service(self) -> DBService:
        """Returns the appropriate table database service for the configured cloud provider."""
        if not self._db_table_service:
            if self.provider_type == "aws":
                # AWS uses DynamoDB for both NoSQL and table-like operations
                self._db_table_service = DynamoDBService(self.config)
            else:  # azure
                self._db_table_service = CosmosDBService.create(
                    self.config, api_type="table"
                )

        return self._db_table_service

    def get_messaging_service(self) -> MessagingService:
        """Returns the appropriate messaging service for the configured cloud provider."""
        if not self._messaging_service:
            if self.provider_type == "aws":
                self._messaging_service = SQSMessagingService(self.config)
            else:  # azure
                self._messaging_service = ServiceBusMessagingService(self.config)

        return self._messaging_service

    def get_text_analysis_service(self) -> TextAnalysisService:
        """Returns the appropriate text analysis service for the configured cloud provider."""
        if not self._text_analysis_service:
            if self.provider_type == "aws":
                self._text_analysis_service = ComprehendTextAnalysisService(self.config)
            else:  # azure
                self._text_analysis_service = AzureTextAnalysisService(self.config)

        return self._text_analysis_service

    def get_chat_service(self) -> ChatService:
        """Returns the appropriate chat completion service for the configured cloud provider."""
        if not self._chat_service:
            if self.provider_type == "aws":
                self._chat_service = BedrockChatService(self.config)
            else:  # azure
                self._chat_service = AzureOpenAIChatService(self.config)

        return self._chat_service

    def get_embedding_service(self) -> EmbeddingService:
        """Returns the appropriate embedding service for the configured cloud provider."""
        if not self._embedding_service:
            if self.provider_type == "aws":
                self._embedding_service = BedrockEmbeddingService(self.config)
            else:  # azure
                self._embedding_service = AzureOpenAIEmbeddingService(self.config)

        return self._embedding_service

    def get_search_service(self) -> SearchService:
        """Returns the appropriate search service for the configured cloud provider."""
        if not self._search_service:
            if self.provider_type == "aws":
                self._search_service = OpenSearchService(self.config)
            else:  # azure
                self._search_service = AzureSearchService(self.config)

        return self._search_service

    # Convenience methods for common operations
    async def store_file(self, file_path: str, data: bytes) -> str:
        """Convenience method to upload a file"""
        storage = self.get_storage_service()
        return await storage.upload_file(file_path, data)

    async def retrieve_file(self, file_path: str) -> bytes:
        """Convenience method to download a file"""
        storage = self.get_storage_service()
        return await storage.download_file(file_path)

    async def analyze_text_sentiment(self, text: str, language: str = "en") -> Dict[str, Any]:
        """Convenience method to analyze text sentiment"""
        text_analysis = self.get_text_analysis_service()
        return await text_analysis.analyze_sentiment(text, language)

    async def chat_with_ai(self, messages: List[Dict[str, str]], **kwargs) -> Dict[str, Any]:
        """Convenience method for AI chat completion"""
        chat = self.get_chat_service()
        return await chat.chat_completion(messages, **kwargs)

    async def create_text_embeddings(self, texts, **kwargs) -> List[List[float]]:
        """Convenience method to create text embeddings"""
        embedding = self.get_embedding_service()
        return await embedding.create_embeddings(texts, **kwargs)

    async def search_documents(self, index_name: str, query: str, **kwargs) -> List[Dict[str, Any]]:
        """Convenience method to search documents"""
        search = self.get_search_service()
        return await search.search_documents(index_name, query, **kwargs)
