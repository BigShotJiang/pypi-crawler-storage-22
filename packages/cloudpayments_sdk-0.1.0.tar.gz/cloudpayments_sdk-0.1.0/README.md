# CloudPayments SDK

Python SDK for CloudPayments API with sync/async clients, typed response models, retry middleware, and webhook utilities.

## Features

- Sync and async clients (`CloudPayments`, `AsyncCloudPayments`)
- Resource-oriented API (`payments`, `orders`, `subscriptions`, `notifications`, `claims`, `payouts`)
- Pydantic v2 models with tolerant parsing (`extra="allow"`)
- Retry middleware for transient network/rate-limit errors
- Webhook signature verification and event parsing
- Optional framework adapters: FastAPI, Flask, Django

## Installation

```bash
uv venv
source .venv/bin/activate
uv pip install -e ".[dev]"
```

With webhook framework adapters:

```bash
uv pip install -e ".[webhooks]"
```

## Quick Start

```python
from cloudpayments_sdk import CloudPayments

with CloudPayments(public_id="pk_...", api_secret="...") as client:
    assert client.test() is True
```

## Live API Tests

```bash
export CLOUDPAYMENTS_RUN_LIVE=1
export CLOUDPAYMENTS_PUBLIC_ID="pk_..."
export CLOUDPAYMENTS_API_SECRET="..."
export CLOUDPAYMENTS_IP_ADDRESS="$(curl -4 https://api.ipify.org)"

uv run --extra dev pytest -q -m live -s
```

## Local Checks

```bash
uv run --extra dev ruff check cloudpayments_sdk tests examples
uv run --extra dev mypy cloudpayments_sdk
uv run --extra dev pytest -q
```

## Examples

- `python -m examples.sync_basic`
- `python -m examples.async_basic`
- `python -m examples.e2e_token_subscription`
- `python -m examples.webhook_fastapi`

Detailed usage: `docs/examples.md`  
API method list: `docs/reference.md`

## Build

```bash
uv build
```

## License

MIT (`LICENSE`).
