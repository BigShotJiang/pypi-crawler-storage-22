"""Package metadata for CloudPayments SDK."""

__version__ = "0.1.0"
__author__ = "CloudPayments SDK Maintainers"
__url__ = "https://developers.cloudpayments.ru/"
