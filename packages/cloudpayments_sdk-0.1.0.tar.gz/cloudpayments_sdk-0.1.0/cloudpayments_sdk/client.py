"""Entry points for users of the CloudPayments SDK."""

from __future__ import annotations

from typing import Any

from .config import Config
from .transport.base import BaseTransport, AsyncBaseTransport
from .transport import (
    HttpxSyncTransport,
    HttpxAsyncTransport,
    RetryMiddleware,
    AsyncRetryMiddleware,
)
from .resources import (
    PaymentsResource,
    AsyncPaymentsResource,
    PayoutsResource,
    AsyncPayoutsResource,
    SubscriptionsResource,
    AsyncSubscriptionsResource,
    OrdersResource,
    AsyncOrdersResource,
    NotificationsResource,
    AsyncNotificationsResource,
    ClaimsResource,
    AsyncClaimsResource,
)


class CloudPayments:
    """Synchronous client for the CloudPayments API.

    The client exposes grouped resources such as ``payments``, ``payouts``,
    ``subscriptions`` etc.  Each resource provides methods mapped to API
    endpoints.  The underlying transport is configurable via the
    ``Config`` dataclass; by default it uses ``httpx.Client``.
    """

    def __init__(self, public_id: str, api_secret: str, **kwargs: Any) -> None:
        self.config = Config(public_id=public_id, api_secret=api_secret, **kwargs)
        self.transport: BaseTransport
        raw_transport = HttpxSyncTransport(self.config)
        # Wrap the transport in a retry middleware according to configured retries
        if self.config.retries > 0:
            self.transport = RetryMiddleware(raw_transport, retries=self.config.retries)
        else:
            self.transport = raw_transport
        self._raw_transport: HttpxSyncTransport
        self._raw_transport = raw_transport
        self.payments = PaymentsResource(self.transport)
        self.payouts = PayoutsResource(self.transport)
        self.subscriptions = SubscriptionsResource(self.transport)
        self.orders = OrdersResource(self.transport)
        self.notifications = NotificationsResource(self.transport)
        self.claims = ClaimsResource(self.transport)

    def test(self) -> Any:
        """Convenience method to call the test endpoint on the payments resource."""
        return self.payments.test()

    def close(self) -> None:
        """Close underlying HTTP client."""
        self._raw_transport.close()

    def __enter__(self) -> "CloudPayments":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()


class AsyncCloudPayments:
    """Asynchronous client for the CloudPayments API."""

    def __init__(self, public_id: str, api_secret: str, **kwargs: Any) -> None:
        self.config = Config(public_id=public_id, api_secret=api_secret, **kwargs)
        self.transport: AsyncBaseTransport
        raw_transport = HttpxAsyncTransport(self.config)
        if self.config.retries > 0:
            self.transport = AsyncRetryMiddleware(raw_transport, retries=self.config.retries)
        else:
            self.transport = raw_transport
        self._raw_transport: HttpxAsyncTransport
        self._raw_transport = raw_transport
        self.payments = AsyncPaymentsResource(self.transport)
        self.payouts = AsyncPayoutsResource(self.transport)
        self.subscriptions = AsyncSubscriptionsResource(self.transport)
        self.orders = AsyncOrdersResource(self.transport)
        self.notifications = AsyncNotificationsResource(self.transport)
        self.claims = AsyncClaimsResource(self.transport)

    async def test(self) -> Any:
        return await self.payments.test()

    async def aclose(self) -> None:
        """Close underlying async HTTP client."""
        await self._raw_transport.aclose()

    async def __aenter__(self) -> "AsyncCloudPayments":
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        await self.aclose()
