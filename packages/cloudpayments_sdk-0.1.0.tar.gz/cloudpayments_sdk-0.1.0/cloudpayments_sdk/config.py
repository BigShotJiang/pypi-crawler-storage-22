"""Configuration for the CloudPayments SDK.

This module defines a simple data container used to
configure the SDK clients.  The configuration is passed
to the transport layer to specify credentials, base URL
and behaviour such as timeouts and TLS verification.
"""

from dataclasses import dataclass


@dataclass
class Config:
    """Simple configuration holder.

    Attributes:
        public_id: Merchant public identifier provided by CloudPayments.
        api_secret: Secret key used for Basic Authentication with the API.
        base_url: Base URL of the CloudPayments API.
        timeout: Timeout in seconds for HTTP requests.
        verify_tls: Whether to verify TLS certificates.
        retries: Number of times to retry a failed request.
    """

    public_id: str
    api_secret: str
    base_url: str = "https://api.cloudpayments.ru"
    timeout: float = 30.0
    verify_tls: bool = True
    retries: int = 3
