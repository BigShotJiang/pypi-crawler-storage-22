"""Error codes used by the CloudPayments SDK.

The CloudPayments API returns various codes and subcodes to
indicate the reason for failures.  This module defines a
small enumeration for generic categories; you can extend
this according to the official documentation to capture
all possible codes.
"""

from enum import Enum


class ErrorCode(str, Enum):
    """High‑level error categories for CloudPayments responses."""

    UNKNOWN = "unknown"
    AUTHENTICATION_FAILED = "authentication_failed"
    RATE_LIMIT = "rate_limit"
    NETWORK_ERROR = "network_error"
    API_ERROR = "api_error"
