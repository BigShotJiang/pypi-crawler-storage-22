"""Core exception types for the CloudPayments SDK.

All custom exceptions raised by the SDK inherit from
``CloudPaymentsError``.  Specific subclasses identify
common categories of errors such as authentication failures,
rate limiting or network issues.
"""


class CloudPaymentsError(Exception):
    """Base exception for all errors originating from this SDK."""


class AuthenticationError(CloudPaymentsError):
    """Authentication failed due to invalid credentials."""


class ApiError(CloudPaymentsError):
    """Generic API error returned by CloudPayments."""


class ApiResponseError(ApiError):
    """Raised when CloudPayments returns ``Success=false`` with HTTP 200."""

    def __init__(self, message: str, *, error_code: str | None = None, response: dict | None = None) -> None:
        self.error_code = error_code
        self.response = response or {}
        super().__init__(message)


class RateLimitError(CloudPaymentsError):
    """Raised when the API signals rate limiting or throttling."""


class NetworkError(CloudPaymentsError):
    """Raised when a network error occurs while performing a request."""
