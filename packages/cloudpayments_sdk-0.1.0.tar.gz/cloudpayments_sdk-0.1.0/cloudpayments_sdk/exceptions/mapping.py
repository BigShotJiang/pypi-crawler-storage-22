"""Map HTTP status codes and other signals to SDK exceptions."""

from http import HTTPStatus
from typing import Type
from .core import (
    AuthenticationError,
    RateLimitError,
    ApiError,
    CloudPaymentsError,
)


# A simple mapping from HTTP status codes to our exception classes.  You can
# extend this mapping with more specific handling based on CloudPayments
# documentation.  When a response's status code is present in this map
# the corresponding exception class will be raised.
STATUS_EXCEPTION_MAP: dict[int, Type[CloudPaymentsError]] = {
    HTTPStatus.UNAUTHORIZED: AuthenticationError,
    HTTPStatus.FORBIDDEN: AuthenticationError,
    HTTPStatus.TOO_MANY_REQUESTS: RateLimitError,
}


def get_exception_for_status(status: int) -> Type[CloudPaymentsError]:
    """Return an exception class appropriate for the given HTTP status.

    Args:
        status: Integer HTTP status code returned by the API.

    Returns:
        A subclass of ``CloudPaymentsError``.  Defaults to ``ApiError``.
    """
    return STATUS_EXCEPTION_MAP.get(status, ApiError)
