"""Structured logging utilities for CloudPayments SDK.

This module exposes a simple logger configured to output
informative messages about API calls.  It also defines
a convenience function to record event durations, status
codes and optional trace identifiers.  Developers can
configure logging globally by adjusting the root logger.
"""

import logging
from typing import Optional


# Configure a module-level logger.  If no handlers exist on
# instantiation, attach a default StreamHandler.  This makes
# the logger emit to stderr by default when used stand‑alone.
logger = logging.getLogger("cloudpayments_sdk")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s: %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
logger.setLevel(logging.INFO)


def log_event(
    event: str,
    status: str,
    duration: float,
    trace_id: Optional[str] = None,
    retries: int = 0,
) -> None:
    """Emit a structured log line describing an API call.

    Args:
        event: Human‑readable name of the operation.
        status: Result status (e.g. ``"ok"`` or ``"error"``).
        duration: Execution time in seconds.
        trace_id: Optional trace identifier for correlation across systems.
        retries: Number of retry attempts performed.
    """
    prefix = f"[{trace_id}] " if trace_id else ""
    logger.info(
        "%sevent=%s status=%s duration=%.3f retries=%s",
        prefix,
        event,
        status,
        duration,
        retries,
    )
