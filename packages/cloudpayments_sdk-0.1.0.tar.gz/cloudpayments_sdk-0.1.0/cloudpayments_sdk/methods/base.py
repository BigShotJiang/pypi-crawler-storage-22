"""Low‑level API method definitions.

The SDK defines each REST endpoint as a subclass of ``APIMethod`` that
describes the HTTP method, path and how to build the request payload.
Instances of ``RequestSpec`` encapsulate the information needed by
the transport layer to perform the call.
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class RequestSpec:
    """Specification of an HTTP request.

    Attributes:
        http_method: HTTP verb (GET, POST, etc.).
        path: Relative URL path, without the base URL.
        params: Query parameters.
        json: JSON body to send in the request.
        headers: Additional HTTP headers.
    """

    http_method: str
    path: str
    params: Optional[Dict[str, Any]] = None
    json: Optional[Dict[str, Any]] = None
    headers: Optional[Dict[str, str]] = None


class APIMethod:
    """Base class for declarative API method definitions."""

    http_method: str
    path: str
