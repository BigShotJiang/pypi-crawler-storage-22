"""Definitions of claim‑related API endpoints."""

from __future__ import annotations

from typing import Any, Dict

from .base import APIMethod, RequestSpec


class GetClaims(APIMethod):
    """Retrieve a list of claims for a given date range."""

    http_method = "GET"
    path = "/claims"

    @classmethod
    def build(
        cls,
        *,
        date_from: str,
        date_to: str,
    ) -> RequestSpec:
        params: Dict[str, Any] = {
            "DateFrom": date_from,
            "DateTo": date_to,
        }
        return RequestSpec(http_method=cls.http_method, path=cls.path, params=params)
