"""Definitions of notification-related API endpoints."""

from __future__ import annotations

from typing import Any

from .base import APIMethod, RequestSpec


NOTIFICATION_TYPES = ("Fail", "Confirm", "Recurrent", "Pay", "Refund", "Check")


def normalize_notification_type(notification_type: str) -> str:
    normalized = notification_type.strip().capitalize()
    if normalized not in NOTIFICATION_TYPES:
        raise ValueError(
            f"Unknown notification type '{notification_type}'. "
            f"Supported values: {', '.join(NOTIFICATION_TYPES)}"
        )
    return normalized


class GetNotificationSettings(APIMethod):
    """Retrieve current notification settings by type."""

    http_method = "POST"
    path = "/site/notifications/{notification_type}/get"

    @classmethod
    def build(cls, *, notification_type: str) -> RequestSpec:
        normalized = normalize_notification_type(notification_type)
        return RequestSpec(http_method=cls.http_method, path=cls.path.format(notification_type=normalized))


class UpdateNotificationSettings(APIMethod):
    """Update notification settings by type."""

    http_method = "POST"
    path = "/site/notifications/{notification_type}/update"

    @classmethod
    def build(
        cls,
        *,
        notification_type: str,
        enabled: bool,
        address: str | None = None,
        http_method: str | None = None,
        format: str | None = None,
    ) -> RequestSpec:
        normalized = normalize_notification_type(notification_type)
        payload: dict[str, Any] = {"IsEnabled": enabled}
        if address is not None:
            payload["Address"] = address
        if http_method is not None:
            payload["HttpMethod"] = http_method
        if format is not None:
            payload["Format"] = format
        return RequestSpec(
            http_method=cls.http_method,
            path=cls.path.format(notification_type=normalized),
            json=payload,
        )
