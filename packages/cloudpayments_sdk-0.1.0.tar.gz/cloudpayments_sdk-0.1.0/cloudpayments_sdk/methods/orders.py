"""Definitions of order‑related API endpoints."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .base import APIMethod, RequestSpec


def _drop_none(payload: Dict[str, Any]) -> Dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None}


class CreateOrder(APIMethod):
    """Create an invoice (order) for a customer to pay later."""

    http_method = "POST"
    path = "/orders/create"

    @classmethod
    def build(
        cls,
        *,
        amount: float,
        currency: str,
        description: str,
        invoice_id: Optional[str] = None,
        account_id: Optional[str] = None,
        email: Optional[str] = None,
        json_data: Optional[Dict[str, Any]] = None,
        require_confirmation: Optional[bool] = None,
        send_email: Optional[bool] = None,
    ) -> RequestSpec:
        payload = _drop_none(
            {
                "Amount": amount,
                "Currency": currency,
                "Description": description,
                "InvoiceId": invoice_id,
                "AccountId": account_id,
                "Email": email,
                "JsonData": json_data,
                "RequireConfirmation": require_confirmation,
                "SendEmail": send_email,
            }
        )
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)


class CancelOrder(APIMethod):
    """Cancel an invoice (order) before it is paid."""

    http_method = "POST"
    path = "/orders/cancel"

    @classmethod
    def build(
        cls,
        *,
        order_id: str,
    ) -> RequestSpec:
        payload = {"Id": order_id}
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)
