"""Definitions of payment-related API endpoints."""

from __future__ import annotations

from typing import Any

from .base import APIMethod, RequestSpec


def _drop_none(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None}


class Test(APIMethod):
    """Test method to verify credentials and connectivity."""

    http_method = "GET"
    path = "/test"

    @classmethod
    def build(cls) -> RequestSpec:
        return RequestSpec(http_method=cls.http_method, path=cls.path)


class ChargeCard(APIMethod):
    """One-step charge with card cryptogram."""

    http_method = "POST"
    path = "/payments/cards/charge"

    @classmethod
    def build(
        cls,
        *,
        amount: float,
        card_cryptogram_packet: str,
        ip_address: str,
        currency: str | None = None,
        account_id: str | None = None,
        invoice_id: str | None = None,
        email: str | None = None,
        description: str | None = None,
        json_data: dict[str, Any] | None = None,
        name: str | None = None,
        payment_url: str | None = None,
        culture_name: str | None = None,
        payer: dict[str, Any] | None = None,
        save_card: bool | None = None,
        require_confirmation: bool | None = None,
        headers: dict[str, str] | None = None,
    ) -> RequestSpec:
        payload = _drop_none(
            {
                "Amount": amount,
                "CardCryptogramPacket": card_cryptogram_packet,
                "IpAddress": ip_address,
                "Currency": currency,
                "AccountId": account_id,
                "InvoiceId": invoice_id,
                "Email": email,
                "Description": description,
                "JsonData": json_data,
                "Name": name,
                "PaymentUrl": payment_url,
                "CultureName": culture_name,
                "Payer": payer,
                "SaveCard": save_card,
                "RequireConfirmation": require_confirmation,
            }
        )
        return RequestSpec(cls.http_method, cls.path, json=payload, headers=headers)


class AuthCard(APIMethod):
    """Two-step auth (hold) with card cryptogram."""

    http_method = "POST"
    path = "/payments/cards/auth"

    @classmethod
    def build(cls, **kwargs: Any) -> RequestSpec:
        spec = ChargeCard.build(**kwargs)
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=spec.json, headers=spec.headers)


class ChargeToken(APIMethod):
    """One-step charge with a previously saved token."""

    http_method = "POST"
    path = "/payments/tokens/charge"

    @classmethod
    def build(
        cls,
        *,
        amount: float,
        token: str,
        ip_address: str,
        currency: str | None = None,
        account_id: str | None = None,
        invoice_id: str | None = None,
        email: str | None = None,
        description: str | None = None,
        json_data: dict[str, Any] | None = None,
        payment_url: str | None = None,
        culture_name: str | None = None,
        payer: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> RequestSpec:
        payload = _drop_none(
            {
                "Amount": amount,
                "Token": token,
                "IpAddress": ip_address,
                "Currency": currency,
                "AccountId": account_id,
                "InvoiceId": invoice_id,
                "Email": email,
                "Description": description,
                "JsonData": json_data,
                "PaymentUrl": payment_url,
                "CultureName": culture_name,
                "Payer": payer,
            }
        )
        return RequestSpec(cls.http_method, cls.path, json=payload, headers=headers)


class AuthToken(APIMethod):
    """Two-step auth (hold) with a previously saved token."""

    http_method = "POST"
    path = "/payments/tokens/auth"

    @classmethod
    def build(cls, **kwargs: Any) -> RequestSpec:
        spec = ChargeToken.build(**kwargs)
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=spec.json, headers=spec.headers)


class Confirm(APIMethod):
    """Confirm (capture) a previously authorized payment."""

    http_method = "POST"
    path = "/payments/confirm"

    @classmethod
    def build(
        cls,
        *,
        transaction_id: int,
        amount: float | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> RequestSpec:
        payload = _drop_none(
            {
                "TransactionId": transaction_id,
                "Amount": amount,
                "JsonData": json_data,
            }
        )
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)


class Cancel(APIMethod):
    """Cancel (void) a previously authorized payment."""

    http_method = "POST"
    path = "/payments/void"

    @classmethod
    def build(
        cls,
        *,
        transaction_id: int,
    ) -> RequestSpec:
        payload = {"TransactionId": transaction_id}
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)


class Refund(APIMethod):
    """Refund a previously captured payment."""

    http_method = "POST"
    path = "/payments/refund"

    @classmethod
    def build(
        cls,
        *,
        transaction_id: int,
        amount: float,
        json_data: dict[str, Any] | None = None,
    ) -> RequestSpec:
        payload = _drop_none(
            {
                "TransactionId": transaction_id,
                "Amount": amount,
                "JsonData": json_data,
            }
        )
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)


class GetTransaction(APIMethod):
    """Retrieve information about a single transaction."""

    http_method = "POST"
    path = "/payments/get"

    @classmethod
    def build(cls, *, transaction_id: int) -> RequestSpec:
        return RequestSpec(
            http_method=cls.http_method,
            path=cls.path,
            json={"TransactionId": transaction_id},
        )


class ListTransactionsDay(APIMethod):
    """List transactions for a specific day via `/payments/list`."""

    http_method = "POST"
    path = "/payments/list"

    @classmethod
    def build(
        cls,
        *,
        date: str,
        time_zone: str | None = None,
    ) -> RequestSpec:
        payload = _drop_none(
            {
                "Date": date,
                "TimeZone": time_zone,
            }
        )
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)


class ListTransactionsRange(APIMethod):
    """List transactions for a date range via `/v2/payments/list`."""

    http_method = "POST"
    path = "/v2/payments/list"

    @classmethod
    def build(
        cls,
        *,
        created_date_gte: str | None = None,
        created_date_lte: str | None = None,
        time_zone: str | None = None,
        pay_status: str | None = None,
        page_number: int | None = None,
        statuses: list[str] | None = None,
    ) -> RequestSpec:
        payload = _drop_none(
            {
                "CreatedDateGte": created_date_gte,
                "CreatedDateLte": created_date_lte,
                "TimeZone": time_zone,
                "PayStatus": pay_status,
                "PageNumber": page_number,
                "Statuses": statuses,
            }
        )
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)


class ListTransactions(APIMethod):
    """Compatibility wrapper that dispatches day/range requests."""

    @classmethod
    def build(
        cls,
        *,
        date: str | None = None,
        time_zone: str | None = None,
        pay_status: str | None = None,
        page_number: int | None = None,
        created_date_gte: str | None = None,
        created_date_lte: str | None = None,
        statuses: list[str] | None = None,
    ) -> RequestSpec:
        if date is not None and created_date_gte is None and created_date_lte is None:
            return ListTransactionsDay.build(date=date, time_zone=time_zone)
        return ListTransactionsRange.build(
            created_date_gte=created_date_gte,
            created_date_lte=created_date_lte,
            time_zone=time_zone,
            pay_status=pay_status,
            page_number=page_number,
            statuses=statuses,
        )


class FindPayment(APIMethod):
    """Find payment by external identifiers."""

    http_method = "POST"
    path = "/v2/payments/find"

    @classmethod
    def build(
        cls,
        *,
        invoice_id: str | None = None,
        account_id: str | None = None,
    ) -> RequestSpec:
        payload = _drop_none({"InvoiceId": invoice_id, "AccountId": account_id})
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)


class ListTokens(APIMethod):
    """List card tokens for the account."""

    http_method = "POST"
    path = "/payments/tokens/list"

    @classmethod
    def build(cls, *, account_id: str) -> RequestSpec:
        payload = {"AccountId": account_id}
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)
