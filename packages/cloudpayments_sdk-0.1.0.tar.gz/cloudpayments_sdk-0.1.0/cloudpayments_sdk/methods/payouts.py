"""Definitions of payout‑related API endpoints."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .base import APIMethod, RequestSpec


def _drop_none(payload: Dict[str, Any]) -> Dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None}


class PayoutCryptogram(APIMethod):
    """Initiate a payout using a card cryptogram packet."""

    http_method = "POST"
    path = "/payments/cards/topup"

    @classmethod
    def build(
        cls,
        *,
        amount: float,
        currency: str | None,
        card_cryptogram_packet: str,
        account_id: str | None = None,
        invoice_id: str | None = None,
        description: Optional[str] = None,
        ip_address: str | None = None,
        json_data: Dict[str, Any] | None = None,
    ) -> RequestSpec:
        payload = _drop_none(
            {
                "Amount": amount,
                "Currency": currency,
                "CardCryptogramPacket": card_cryptogram_packet,
                "AccountId": account_id,
                "InvoiceId": invoice_id,
                "Description": description,
                "IpAddress": ip_address,
                "JsonData": json_data,
            }
        )
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)


class PayoutToken(APIMethod):
    """Initiate a payout using a stored card token."""

    http_method = "POST"
    path = "/payments/token/topup"

    @classmethod
    def build(
        cls,
        *,
        amount: float,
        currency: str | None,
        token: str,
        account_id: str | None = None,
        invoice_id: str | None = None,
        description: Optional[str] = None,
        ip_address: str | None = None,
        json_data: Dict[str, Any] | None = None,
    ) -> RequestSpec:
        payload = _drop_none(
            {
                "Amount": amount,
                "Currency": currency,
                "Token": token,
                "AccountId": account_id,
                "InvoiceId": invoice_id,
                "Description": description,
                "IpAddress": ip_address,
                "JsonData": json_data,
            }
        )
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)


class PayoutSBP(APIMethod):
    """Initiate a payout using the Faster Payments System (SBP)."""

    http_method = "POST"
    path = "/payments/alt/topup"

    @classmethod
    def build(
        cls,
        *,
        amount: float,
        currency: str | None,
        sbp_beneficiary_id: str,
        account_id: str | None = None,
        invoice_id: str | None = None,
        description: Optional[str] = None,
        ip_address: str | None = None,
        json_data: Dict[str, Any] | None = None,
    ) -> RequestSpec:
        payload = _drop_none(
            {
                "Amount": amount,
                "Currency": currency,
                "SBPBeneficiaryId": sbp_beneficiary_id,
                "AccountId": account_id,
                "InvoiceId": invoice_id,
                "Description": description,
                "IpAddress": ip_address,
                "JsonData": json_data,
            }
        )
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)
