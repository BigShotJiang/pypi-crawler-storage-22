"""Definitions of subscription-related API endpoints."""

from __future__ import annotations

from typing import Any

from .base import APIMethod, RequestSpec


def _drop_none(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None}


def _normalize_interval_period(interval: str | int | None, period: int | str | None) -> tuple[str | None, int | None]:
    """Normalize subscription schedule fields.

    Official API contract:
      - Interval: Day | Week | Month
      - Period: int
    """
    if isinstance(interval, int) and isinstance(period, str):
        # Backward-compatible swap for legacy SDK calls.
        interval, period = period, interval

    normalized_interval = interval if isinstance(interval, str) else None
    normalized_period = period if isinstance(period, int) else None
    return normalized_interval, normalized_period


class CreateSubscription(APIMethod):
    """Create a recurring subscription."""

    http_method = "POST"
    path = "/subscriptions/create"

    @classmethod
    def build(
        cls,
        *,
        token: str,
        account_id: str,
        description: str,
        amount: float,
        currency: str,
        email: str | None = None,
        require_confirmation: bool | None = None,
        start_date: str | None = None,
        interval: str | int | None = None,
        period: int | str | None = None,
        max_periods: int | None = None,
        customer_receipt: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> RequestSpec:
        normalized_interval, normalized_period = _normalize_interval_period(interval, period)
        payload = _drop_none(
            {
                "Token": token,
                "AccountId": account_id,
                "Description": description,
                "Amount": amount,
                "Currency": currency,
                "Email": email,
                "RequireConfirmation": require_confirmation,
                "StartDate": start_date,
                "Interval": normalized_interval,
                "Period": normalized_period,
                "MaxPeriods": max_periods,
                "CustomerReceipt": customer_receipt,
                "JsonData": json_data,
            }
        )
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)


class GetSubscription(APIMethod):
    """Retrieve information about a subscription by id."""

    http_method = "POST"
    path = "/subscriptions/get"

    @classmethod
    def build(cls, *, subscription_id: str) -> RequestSpec:
        return RequestSpec(http_method=cls.http_method, path=cls.path, json={"Id": subscription_id})


class FindSubscriptions(APIMethod):
    """List subscriptions for account id."""

    http_method = "POST"
    path = "/subscriptions/find"

    @classmethod
    def build(cls, *, account_id: str) -> RequestSpec:
        return RequestSpec(http_method=cls.http_method, path=cls.path, json={"AccountId": account_id})


class UpdateSubscription(APIMethod):
    """Change the parameters of a subscription."""

    http_method = "POST"
    path = "/subscriptions/update"

    @classmethod
    def build(
        cls,
        *,
        subscription_id: str,
        amount: float | None = None,
        currency: str | None = None,
        start_date: str | None = None,
        interval: str | int | None = None,
        period: int | str | None = None,
        max_periods: int | None = None,
    ) -> RequestSpec:
        normalized_interval, normalized_period = _normalize_interval_period(interval, period)
        payload = _drop_none(
            {
                "Id": subscription_id,
                "Amount": amount,
                "Currency": currency,
                "StartDate": start_date,
                "Interval": normalized_interval,
                "Period": normalized_period,
                "MaxPeriods": max_periods,
            }
        )
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)


class CancelSubscription(APIMethod):
    """Cancel a subscription by id."""

    http_method = "POST"
    path = "/subscriptions/cancel"

    @classmethod
    def build(cls, *, subscription_id: str) -> RequestSpec:
        payload = {"Id": subscription_id}
        return RequestSpec(http_method=cls.http_method, path=cls.path, json=payload)
