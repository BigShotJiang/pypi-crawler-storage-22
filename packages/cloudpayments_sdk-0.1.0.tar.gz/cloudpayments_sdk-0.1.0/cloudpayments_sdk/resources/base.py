"""Base resource classes providing request dispatch and model validation."""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional, Type, TypeVar, overload, cast

from pydantic import BaseModel

from ..transport.base import BaseTransport, AsyncBaseTransport


ModelT = TypeVar("ModelT", bound=BaseModel)


def _unwrap_body(data: Any) -> Any:
    """Return business payload from the CloudPayments response envelope."""
    if isinstance(data, dict) and "Model" in data and data["Model"] is not None:
        return data["Model"]
    return data


class BaseResource:
    """Base class for synchronous resource groups."""

    def __init__(self, transport: BaseTransport) -> None:
        self._transport = transport

    @overload
    def _request(
        self,
        model: Type[ModelT],
        http_method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> ModelT: ...

    @overload
    def _request(
        self,
        model: type[dict],
        http_method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> dict: ...

    @overload
    def _request(
        self,
        model: Callable[[Any], ModelT],
        http_method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> ModelT: ...

    def _request(
        self,
        model: Type[ModelT] | Callable[[Any], ModelT] | type[dict],
        http_method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> ModelT | dict:
        raw = self._transport.request(
            method=http_method,
            path=path,
            params=params,
            json=json,
            headers=headers,
        )
        payload = _unwrap_body(raw)

        if model is dict:
            return cast(dict, payload)

        if isinstance(model, type) and issubclass(model, BaseModel):
            return cast(ModelT, model.model_validate(payload))

        parser = cast(Callable[[Any], ModelT], model)
        return parser(payload)


class AsyncBaseResource:
    """Base class for asynchronous resource groups."""

    def __init__(self, transport: AsyncBaseTransport) -> None:
        self._transport = transport

    @overload
    async def _request(
        self,
        model: Type[ModelT],
        http_method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> ModelT: ...

    @overload
    async def _request(
        self,
        model: type[dict],
        http_method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> dict: ...

    @overload
    async def _request(
        self,
        model: Callable[[Any], ModelT],
        http_method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> ModelT: ...

    async def _request(
        self,
        model: Type[ModelT] | Callable[[Any], ModelT] | type[dict],
        http_method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> ModelT | dict:
        raw = await self._transport.request(
            method=http_method,
            path=path,
            params=params,
            json=json,
            headers=headers,
        )
        payload = _unwrap_body(raw)

        if model is dict:
            return cast(dict, payload)

        if isinstance(model, type) and issubclass(model, BaseModel):
            return cast(ModelT, model.model_validate(payload))

        parser = cast(Callable[[Any], ModelT], model)
        return parser(payload)
