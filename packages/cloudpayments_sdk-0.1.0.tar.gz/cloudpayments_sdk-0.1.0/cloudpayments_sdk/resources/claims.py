"""Resource group for claims operations."""

from __future__ import annotations

from .base import BaseResource, AsyncBaseResource
from ..methods import GetClaims
from ..schemas.claim import ClaimList


class ClaimsResource(BaseResource):
    """Expose claim endpoints for synchronous clients."""

    def list(self, *, date_from: str, date_to: str) -> ClaimList:
        spec = GetClaims.build(date_from=date_from, date_to=date_to)
        return self._request(ClaimList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)


class AsyncClaimsResource(AsyncBaseResource):
    """Expose claim endpoints for asynchronous clients."""

    async def list(self, *, date_from: str, date_to: str) -> ClaimList:
        spec = GetClaims.build(date_from=date_from, date_to=date_to)
        return await self._request(ClaimList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)
