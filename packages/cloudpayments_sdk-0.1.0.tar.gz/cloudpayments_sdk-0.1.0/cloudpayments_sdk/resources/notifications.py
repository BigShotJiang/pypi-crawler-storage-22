"""Resource group for notification settings."""

from __future__ import annotations

from .base import BaseResource, AsyncBaseResource
from ..methods import GetNotificationSettings, UpdateNotificationSettings
from ..schemas.notification import NotificationSettings


class NotificationsResource(BaseResource):
    """Expose notification settings endpoints for synchronous clients."""

    def get(self, *, notification_type: str) -> NotificationSettings:
        spec = GetNotificationSettings.build(notification_type=notification_type)
        return self._request(NotificationSettings, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def update(
        self,
        *,
        notification_type: str,
        enabled: bool,
        address: str | None = None,
        http_method: str | None = None,
        format: str | None = None,
    ) -> NotificationSettings:
        spec = UpdateNotificationSettings.build(
            notification_type=notification_type,
            enabled=enabled,
            address=address,
            http_method=http_method,
            format=format,
        )
        return self._request(NotificationSettings, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)


class AsyncNotificationsResource(AsyncBaseResource):
    """Expose notification settings endpoints for asynchronous clients."""

    async def get(self, *, notification_type: str) -> NotificationSettings:
        spec = GetNotificationSettings.build(notification_type=notification_type)
        return await self._request(NotificationSettings, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def update(
        self,
        *,
        notification_type: str,
        enabled: bool,
        address: str | None = None,
        http_method: str | None = None,
        format: str | None = None,
    ) -> NotificationSettings:
        spec = UpdateNotificationSettings.build(
            notification_type=notification_type,
            enabled=enabled,
            address=address,
            http_method=http_method,
            format=format,
        )
        return await self._request(NotificationSettings, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)
