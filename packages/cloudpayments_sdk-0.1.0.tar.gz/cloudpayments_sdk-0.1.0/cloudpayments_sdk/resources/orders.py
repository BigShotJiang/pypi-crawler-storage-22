"""Resource group for order (invoice) operations."""

from __future__ import annotations

from typing import Any, Optional

from .base import BaseResource, AsyncBaseResource
from ..methods import CreateOrder, CancelOrder
from ..schemas.orders import Order


class OrdersResource(BaseResource):
    """Expose invoice endpoints for synchronous clients."""

    def create(
        self,
        *,
        amount: float,
        currency: str,
        description: str,
        invoice_id: Optional[str] = None,
        account_id: Optional[str] = None,
        email: Optional[str] = None,
        json_data: Optional[dict[str, Any]] = None,
        require_confirmation: Optional[bool] = None,
        send_email: Optional[bool] = None,
    ) -> Order:
        spec = CreateOrder.build(
            amount=amount,
            currency=currency,
            description=description,
            invoice_id=invoice_id,
            account_id=account_id,
            email=email,
            json_data=json_data,
            require_confirmation=require_confirmation,
            send_email=send_email,
        )
        return self._request(Order, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def cancel(self, *, order_id: str | None = None, invoice_id: str | None = None) -> Order:
        resolved_order_id = order_id or invoice_id
        if resolved_order_id is None:
            raise ValueError("Either 'order_id' or deprecated 'invoice_id' must be provided.")
        spec = CancelOrder.build(order_id=resolved_order_id)
        return self._request(Order, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)


class AsyncOrdersResource(AsyncBaseResource):
    """Expose invoice endpoints for asynchronous clients."""

    async def create(
        self,
        *,
        amount: float,
        currency: str,
        description: str,
        invoice_id: Optional[str] = None,
        account_id: Optional[str] = None,
        email: Optional[str] = None,
        json_data: Optional[dict[str, Any]] = None,
        require_confirmation: Optional[bool] = None,
        send_email: Optional[bool] = None,
    ) -> Order:
        spec = CreateOrder.build(
            amount=amount,
            currency=currency,
            description=description,
            invoice_id=invoice_id,
            account_id=account_id,
            email=email,
            json_data=json_data,
            require_confirmation=require_confirmation,
            send_email=send_email,
        )
        return await self._request(Order, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def cancel(self, *, order_id: str | None = None, invoice_id: str | None = None) -> Order:
        resolved_order_id = order_id or invoice_id
        if resolved_order_id is None:
            raise ValueError("Either 'order_id' or deprecated 'invoice_id' must be provided.")
        spec = CancelOrder.build(order_id=resolved_order_id)
        return await self._request(Order, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)
