"""Resource group for payment operations."""

from __future__ import annotations

from typing import Any

from .base import BaseResource, AsyncBaseResource
from ..methods import (
    Test,
    ChargeCard,
    AuthCard,
    ChargeToken,
    AuthToken,
    Confirm,
    Cancel,
    Refund,
    GetTransaction,
    ListTransactionsDay,
    ListTransactionsRange,
    ListTransactions,
    FindPayment,
    ListTokens,
)
from ..schemas.payment import Payment, PaymentList, CardTokenList


class PaymentsResource(BaseResource):
    """Expose payment-related endpoints for synchronous clients."""

    def test(self) -> bool:
        spec = Test.build()
        return bool(
            self._request(
                lambda payload: payload,
                spec.http_method,
                spec.path,
                params=spec.params,
                json=spec.json,
                headers=spec.headers,
            )
        )

    def charge_card(
        self,
        *,
        amount: float,
        card_cryptogram_packet: str,
        ip_address: str,
        currency: str | None = None,
        account_id: str | None = None,
        two_step: bool = False,
        invoice_id: str | None = None,
        email: str | None = None,
        description: str | None = None,
        json_data: dict[str, Any] | None = None,
        name: str | None = None,
        payment_url: str | None = None,
        culture_name: str | None = None,
        payer: dict[str, Any] | None = None,
        save_card: bool | None = None,
        require_confirmation: bool | None = None,
        headers: dict[str, str] | None = None,
    ) -> Payment:
        method = AuthCard if two_step else ChargeCard
        spec = method.build(
            amount=amount,
            currency=currency,
            card_cryptogram_packet=card_cryptogram_packet,
            account_id=account_id,
            invoice_id=invoice_id,
            email=email,
            description=description,
            json_data=json_data,
            name=name,
            ip_address=ip_address,
            payment_url=payment_url,
            culture_name=culture_name,
            payer=payer,
            save_card=save_card,
            require_confirmation=require_confirmation,
            headers=headers,
        )
        return self._request(
            Payment,
            spec.http_method,
            spec.path,
            params=spec.params,
            json=spec.json,
            headers=spec.headers,
        )

    def charge_token(
        self,
        *,
        amount: float,
        token: str,
        ip_address: str,
        currency: str | None = None,
        account_id: str | None = None,
        two_step: bool = False,
        invoice_id: str | None = None,
        email: str | None = None,
        description: str | None = None,
        json_data: dict[str, Any] | None = None,
        payment_url: str | None = None,
        culture_name: str | None = None,
        payer: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Payment:
        method = AuthToken if two_step else ChargeToken
        spec = method.build(
            amount=amount,
            token=token,
            ip_address=ip_address,
            currency=currency,
            account_id=account_id,
            invoice_id=invoice_id,
            email=email,
            description=description,
            json_data=json_data,
            payment_url=payment_url,
            culture_name=culture_name,
            payer=payer,
            headers=headers,
        )
        return self._request(
            Payment,
            spec.http_method,
            spec.path,
            params=spec.params,
            json=spec.json,
            headers=spec.headers,
        )

    def confirm(
        self,
        *,
        transaction_id: int,
        amount: float | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Payment:
        spec = Confirm.build(transaction_id=transaction_id, amount=amount, json_data=json_data)
        return self._request(Payment, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def cancel(self, *, transaction_id: int) -> Payment:
        spec = Cancel.build(transaction_id=transaction_id)
        return self._request(Payment, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def refund(
        self,
        *,
        transaction_id: int,
        amount: float,
        json_data: dict[str, Any] | None = None,
    ) -> Payment:
        spec = Refund.build(transaction_id=transaction_id, amount=amount, json_data=json_data)
        return self._request(Payment, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def get_transaction(self, *, transaction_id: int) -> Payment:
        spec = GetTransaction.build(transaction_id=transaction_id)
        return self._request(Payment, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def list_transactions(
        self,
        *,
        date: str | None = None,
        time_zone: str | None = None,
        pay_status: str | None = None,
        page_number: int | None = None,
        created_date_gte: str | None = None,
        created_date_lte: str | None = None,
        statuses: list[str] | None = None,
    ) -> PaymentList:
        if date is None and created_date_gte is None and created_date_lte is None:
            raise ValueError("Provide either 'date' or both 'created_date_gte' and 'created_date_lte'.")

        if date is not None and created_date_gte is None and created_date_lte is None:
            spec = ListTransactionsDay.build(date=date, time_zone=time_zone)
            return self._request(PaymentList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

        if created_date_gte is None or created_date_lte is None:
            raise ValueError("'created_date_gte' and 'created_date_lte' must be provided together for range listing.")

        spec = ListTransactionsRange.build(
            created_date_gte=created_date_gte,
            created_date_lte=created_date_lte,
            time_zone=time_zone,
            pay_status=pay_status,
            page_number=page_number,
            statuses=statuses,
        )
        return self._request(PaymentList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def list_transactions_compat(
        self,
        *,
        date: str | None = None,
        time_zone: str | None = None,
        pay_status: str | None = None,
        page_number: int | None = None,
        created_date_gte: str | None = None,
        created_date_lte: str | None = None,
        statuses: list[str] | None = None,
    ) -> PaymentList:
        """Compatibility wrapper around `methods.ListTransactions`."""
        spec = ListTransactions.build(
            date=date,
            time_zone=time_zone,
            pay_status=pay_status,
            page_number=page_number,
            created_date_gte=created_date_gte,
            created_date_lte=created_date_lte,
            statuses=statuses,
        )
        return self._request(PaymentList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def list_transactions_for_day(self, *, date: str, time_zone: str | None = None) -> PaymentList:
        return self.list_transactions(date=date, time_zone=time_zone)

    def list_transactions_for_range(
        self,
        *,
        created_date_gte: str,
        created_date_lte: str,
        page_number: int | None = None,
        time_zone: str | None = None,
        statuses: list[str] | None = None,
    ) -> PaymentList:
        return self.list_transactions(
            created_date_gte=created_date_gte,
            created_date_lte=created_date_lte,
            page_number=page_number,
            time_zone=time_zone,
            statuses=statuses,
        )

    def find(self, *, invoice_id: str | None = None, account_id: str | None = None) -> Payment:
        if invoice_id is None and account_id is None:
            raise ValueError("Either 'invoice_id' or 'account_id' must be provided.")
        spec = FindPayment.build(invoice_id=invoice_id, account_id=account_id)
        return self._request(Payment, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def list_tokens(self, *, account_id: str) -> CardTokenList:
        spec = ListTokens.build(account_id=account_id)
        return self._request(CardTokenList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)


class AsyncPaymentsResource(AsyncBaseResource):
    """Expose payment-related endpoints for asynchronous clients."""

    async def test(self) -> bool:
        spec = Test.build()
        return bool(
            await self._request(
                lambda payload: payload,
                spec.http_method,
                spec.path,
                params=spec.params,
                json=spec.json,
                headers=spec.headers,
            )
        )

    async def charge_card(
        self,
        *,
        amount: float,
        card_cryptogram_packet: str,
        ip_address: str,
        currency: str | None = None,
        account_id: str | None = None,
        two_step: bool = False,
        invoice_id: str | None = None,
        email: str | None = None,
        description: str | None = None,
        json_data: dict[str, Any] | None = None,
        name: str | None = None,
        payment_url: str | None = None,
        culture_name: str | None = None,
        payer: dict[str, Any] | None = None,
        save_card: bool | None = None,
        require_confirmation: bool | None = None,
        headers: dict[str, str] | None = None,
    ) -> Payment:
        method = AuthCard if two_step else ChargeCard
        spec = method.build(
            amount=amount,
            currency=currency,
            card_cryptogram_packet=card_cryptogram_packet,
            account_id=account_id,
            invoice_id=invoice_id,
            email=email,
            description=description,
            json_data=json_data,
            name=name,
            ip_address=ip_address,
            payment_url=payment_url,
            culture_name=culture_name,
            payer=payer,
            save_card=save_card,
            require_confirmation=require_confirmation,
            headers=headers,
        )
        return await self._request(
            Payment,
            spec.http_method,
            spec.path,
            params=spec.params,
            json=spec.json,
            headers=spec.headers,
        )

    async def charge_token(
        self,
        *,
        amount: float,
        token: str,
        ip_address: str,
        currency: str | None = None,
        account_id: str | None = None,
        two_step: bool = False,
        invoice_id: str | None = None,
        email: str | None = None,
        description: str | None = None,
        json_data: dict[str, Any] | None = None,
        payment_url: str | None = None,
        culture_name: str | None = None,
        payer: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Payment:
        method = AuthToken if two_step else ChargeToken
        spec = method.build(
            amount=amount,
            token=token,
            ip_address=ip_address,
            currency=currency,
            account_id=account_id,
            invoice_id=invoice_id,
            email=email,
            description=description,
            json_data=json_data,
            payment_url=payment_url,
            culture_name=culture_name,
            payer=payer,
            headers=headers,
        )
        return await self._request(
            Payment,
            spec.http_method,
            spec.path,
            params=spec.params,
            json=spec.json,
            headers=spec.headers,
        )

    async def confirm(
        self,
        *,
        transaction_id: int,
        amount: float | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Payment:
        spec = Confirm.build(transaction_id=transaction_id, amount=amount, json_data=json_data)
        return await self._request(Payment, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def cancel(self, *, transaction_id: int) -> Payment:
        spec = Cancel.build(transaction_id=transaction_id)
        return await self._request(Payment, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def refund(
        self,
        *,
        transaction_id: int,
        amount: float,
        json_data: dict[str, Any] | None = None,
    ) -> Payment:
        spec = Refund.build(transaction_id=transaction_id, amount=amount, json_data=json_data)
        return await self._request(Payment, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def get_transaction(self, *, transaction_id: int) -> Payment:
        spec = GetTransaction.build(transaction_id=transaction_id)
        return await self._request(Payment, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def list_transactions(
        self,
        *,
        date: str | None = None,
        time_zone: str | None = None,
        pay_status: str | None = None,
        page_number: int | None = None,
        created_date_gte: str | None = None,
        created_date_lte: str | None = None,
        statuses: list[str] | None = None,
    ) -> PaymentList:
        if date is None and created_date_gte is None and created_date_lte is None:
            raise ValueError("Provide either 'date' or both 'created_date_gte' and 'created_date_lte'.")

        if date is not None and created_date_gte is None and created_date_lte is None:
            spec = ListTransactionsDay.build(date=date, time_zone=time_zone)
            return await self._request(PaymentList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

        if created_date_gte is None or created_date_lte is None:
            raise ValueError("'created_date_gte' and 'created_date_lte' must be provided together for range listing.")

        spec = ListTransactionsRange.build(
            created_date_gte=created_date_gte,
            created_date_lte=created_date_lte,
            time_zone=time_zone,
            pay_status=pay_status,
            page_number=page_number,
            statuses=statuses,
        )
        return await self._request(PaymentList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def list_transactions_compat(
        self,
        *,
        date: str | None = None,
        time_zone: str | None = None,
        pay_status: str | None = None,
        page_number: int | None = None,
        created_date_gte: str | None = None,
        created_date_lte: str | None = None,
        statuses: list[str] | None = None,
    ) -> PaymentList:
        """Compatibility wrapper around `methods.ListTransactions`."""
        spec = ListTransactions.build(
            date=date,
            time_zone=time_zone,
            pay_status=pay_status,
            page_number=page_number,
            created_date_gte=created_date_gte,
            created_date_lte=created_date_lte,
            statuses=statuses,
        )
        return await self._request(PaymentList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def list_transactions_for_day(self, *, date: str, time_zone: str | None = None) -> PaymentList:
        return await self.list_transactions(date=date, time_zone=time_zone)

    async def list_transactions_for_range(
        self,
        *,
        created_date_gte: str,
        created_date_lte: str,
        page_number: int | None = None,
        time_zone: str | None = None,
        statuses: list[str] | None = None,
    ) -> PaymentList:
        return await self.list_transactions(
            created_date_gte=created_date_gte,
            created_date_lte=created_date_lte,
            page_number=page_number,
            time_zone=time_zone,
            statuses=statuses,
        )

    async def find(self, *, invoice_id: str | None = None, account_id: str | None = None) -> Payment:
        if invoice_id is None and account_id is None:
            raise ValueError("Either 'invoice_id' or 'account_id' must be provided.")
        spec = FindPayment.build(invoice_id=invoice_id, account_id=account_id)
        return await self._request(Payment, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def list_tokens(self, *, account_id: str) -> CardTokenList:
        spec = ListTokens.build(account_id=account_id)
        return await self._request(CardTokenList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)
