"""Resource group for payout operations."""

from __future__ import annotations

from typing import Any, Optional

from .base import BaseResource, AsyncBaseResource
from ..methods import PayoutCryptogram, PayoutToken, PayoutSBP
from ..schemas.payout import Payout


class PayoutsResource(BaseResource):
    """Expose payout endpoints for synchronous clients."""

    def cryptogram(
        self,
        *,
        amount: float,
        currency: str | None,
        card_cryptogram_packet: str,
        account_id: str | None = None,
        invoice_id: str | None = None,
        description: Optional[str] = None,
        ip_address: str | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Payout:
        spec = PayoutCryptogram.build(
            amount=amount,
            currency=currency,
            card_cryptogram_packet=card_cryptogram_packet,
            account_id=account_id,
            invoice_id=invoice_id,
            description=description,
            ip_address=ip_address,
            json_data=json_data,
        )
        return self._request(Payout, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def token(
        self,
        *,
        amount: float,
        currency: str | None,
        token: str,
        account_id: str | None = None,
        invoice_id: str | None = None,
        description: Optional[str] = None,
        ip_address: str | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Payout:
        spec = PayoutToken.build(
            amount=amount,
            currency=currency,
            token=token,
            account_id=account_id,
            invoice_id=invoice_id,
            description=description,
            ip_address=ip_address,
            json_data=json_data,
        )
        return self._request(Payout, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def sbp(
        self,
        *,
        amount: float,
        currency: str | None,
        sbp_beneficiary_id: str,
        account_id: str | None = None,
        invoice_id: str | None = None,
        description: Optional[str] = None,
        ip_address: str | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Payout:
        spec = PayoutSBP.build(
            amount=amount,
            currency=currency,
            sbp_beneficiary_id=sbp_beneficiary_id,
            account_id=account_id,
            invoice_id=invoice_id,
            description=description,
            ip_address=ip_address,
            json_data=json_data,
        )
        return self._request(Payout, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)


class AsyncPayoutsResource(AsyncBaseResource):
    """Expose payout endpoints for asynchronous clients."""

    async def cryptogram(
        self,
        *,
        amount: float,
        currency: str | None,
        card_cryptogram_packet: str,
        account_id: str | None = None,
        invoice_id: str | None = None,
        description: Optional[str] = None,
        ip_address: str | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Payout:
        spec = PayoutCryptogram.build(
            amount=amount,
            currency=currency,
            card_cryptogram_packet=card_cryptogram_packet,
            account_id=account_id,
            invoice_id=invoice_id,
            description=description,
            ip_address=ip_address,
            json_data=json_data,
        )
        return await self._request(Payout, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def token(
        self,
        *,
        amount: float,
        currency: str | None,
        token: str,
        account_id: str | None = None,
        invoice_id: str | None = None,
        description: Optional[str] = None,
        ip_address: str | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Payout:
        spec = PayoutToken.build(
            amount=amount,
            currency=currency,
            token=token,
            account_id=account_id,
            invoice_id=invoice_id,
            description=description,
            ip_address=ip_address,
            json_data=json_data,
        )
        return await self._request(Payout, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def sbp(
        self,
        *,
        amount: float,
        currency: str | None,
        sbp_beneficiary_id: str,
        account_id: str | None = None,
        invoice_id: str | None = None,
        description: Optional[str] = None,
        ip_address: str | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Payout:
        spec = PayoutSBP.build(
            amount=amount,
            currency=currency,
            sbp_beneficiary_id=sbp_beneficiary_id,
            account_id=account_id,
            invoice_id=invoice_id,
            description=description,
            ip_address=ip_address,
            json_data=json_data,
        )
        return await self._request(Payout, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)
