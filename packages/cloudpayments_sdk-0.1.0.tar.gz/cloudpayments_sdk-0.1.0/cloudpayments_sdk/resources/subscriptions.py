"""Resource group for subscription operations."""

from __future__ import annotations

from typing import Any

from .base import BaseResource, AsyncBaseResource
from ..methods import (
    CreateSubscription,
    GetSubscription,
    FindSubscriptions,
    UpdateSubscription,
    CancelSubscription,
)
from ..schemas.subscription import Subscription, SubscriptionList


class SubscriptionsResource(BaseResource):
    """Expose subscription endpoints for synchronous clients."""

    def create(
        self,
        *,
        token: str,
        account_id: str,
        description: str,
        amount: float,
        currency: str,
        email: str | None = None,
        require_confirmation: bool | None = None,
        start_date: str | None = None,
        interval: str | int | None = None,
        period: int | str | None = None,
        max_periods: int | None = None,
        customer_receipt: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Subscription:
        spec = CreateSubscription.build(
            token=token,
            account_id=account_id,
            description=description,
            amount=amount,
            currency=currency,
            email=email,
            require_confirmation=require_confirmation,
            start_date=start_date,
            interval=interval,
            period=period,
            max_periods=max_periods,
            customer_receipt=customer_receipt,
            json_data=json_data,
        )
        return self._request(Subscription, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def get(self, *, subscription_id: str) -> Subscription:
        spec = GetSubscription.build(subscription_id=subscription_id)
        return self._request(Subscription, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def find(self, *, account_id: str) -> SubscriptionList:
        spec = FindSubscriptions.build(account_id=account_id)
        return self._request(SubscriptionList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def list(self, *, account_id: str) -> SubscriptionList:
        return self.find(account_id=account_id)

    def update(
        self,
        *,
        subscription_id: str,
        amount: float | None = None,
        currency: str | None = None,
        start_date: str | None = None,
        interval: str | int | None = None,
        period: int | str | None = None,
        max_periods: int | None = None,
    ) -> Subscription:
        spec = UpdateSubscription.build(
            subscription_id=subscription_id,
            amount=amount,
            currency=currency,
            start_date=start_date,
            interval=interval,
            period=period,
            max_periods=max_periods,
        )
        return self._request(Subscription, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    def cancel(self, *, subscription_id: str) -> Subscription:
        spec = CancelSubscription.build(subscription_id=subscription_id)
        return self._request(Subscription, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)


class AsyncSubscriptionsResource(AsyncBaseResource):
    """Expose subscription endpoints for asynchronous clients."""

    async def create(
        self,
        *,
        token: str,
        account_id: str,
        description: str,
        amount: float,
        currency: str,
        email: str | None = None,
        require_confirmation: bool | None = None,
        start_date: str | None = None,
        interval: str | int | None = None,
        period: int | str | None = None,
        max_periods: int | None = None,
        customer_receipt: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Subscription:
        spec = CreateSubscription.build(
            token=token,
            account_id=account_id,
            description=description,
            amount=amount,
            currency=currency,
            email=email,
            require_confirmation=require_confirmation,
            start_date=start_date,
            interval=interval,
            period=period,
            max_periods=max_periods,
            customer_receipt=customer_receipt,
            json_data=json_data,
        )
        return await self._request(Subscription, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def get(self, *, subscription_id: str) -> Subscription:
        spec = GetSubscription.build(subscription_id=subscription_id)
        return await self._request(Subscription, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def find(self, *, account_id: str) -> SubscriptionList:
        spec = FindSubscriptions.build(account_id=account_id)
        return await self._request(SubscriptionList, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def list(self, *, account_id: str) -> SubscriptionList:
        return await self.find(account_id=account_id)

    async def update(
        self,
        *,
        subscription_id: str,
        amount: float | None = None,
        currency: str | None = None,
        start_date: str | None = None,
        interval: str | int | None = None,
        period: int | str | None = None,
        max_periods: int | None = None,
    ) -> Subscription:
        spec = UpdateSubscription.build(
            subscription_id=subscription_id,
            amount=amount,
            currency=currency,
            start_date=start_date,
            interval=interval,
            period=period,
            max_periods=max_periods,
        )
        return await self._request(Subscription, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)

    async def cancel(self, *, subscription_id: str) -> Subscription:
        spec = CancelSubscription.build(subscription_id=subscription_id)
        return await self._request(Subscription, spec.http_method, spec.path, params=spec.params, json=spec.json, headers=spec.headers)
