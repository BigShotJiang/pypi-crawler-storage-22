"""Common Pydantic schemas used throughout the SDK."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field, ConfigDict


class Money(BaseModel):
    """Simple money representation."""

    amount: float = Field(..., alias="Amount")
    currency: str = Field(..., alias="Currency")

    model_config = ConfigDict(populate_by_name=True, extra="allow")


class Metadata(BaseModel):
    """Arbitrary metadata container."""

    data: dict[str, str] = Field(default_factory=dict)
    model_config = ConfigDict(populate_by_name=True, extra="allow")


class Pagination(BaseModel):
    """Pagination information for listing endpoints."""

    page: Optional[int] = Field(None, alias="Page")
    per_page: Optional[int] = Field(None, alias="PerPage")
    total: Optional[int] = Field(None, alias="Total")
    model_config = ConfigDict(populate_by_name=True, extra="allow")


class SuccessResponse(BaseModel):
    """Generic success response wrapper."""

    success: bool = Field(..., alias="Success")
    model: Optional[dict] = Field(None, alias="Model")
    message: Optional[str] = Field(None, alias="Message")
    model_config = ConfigDict(populate_by_name=True, extra="allow")


class ErrorResponse(BaseModel):
    """Generic error response wrapper."""

    success: bool = Field(..., alias="Success")
    message: Optional[str] = Field(None, alias="Message")
    model_config = ConfigDict(populate_by_name=True, extra="allow")
