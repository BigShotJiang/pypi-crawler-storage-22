"""Pydantic models for claim endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field, ConfigDict, model_validator


class ClaimItem(BaseModel):
    """Individual claim record."""

    id: Optional[int] = Field(None, alias="Id")
    transaction_id: Optional[int] = Field(None, alias="TransactionId")
    reason: Optional[str] = Field(None, alias="Reason")
    amount: Optional[float] = Field(None, alias="Amount")
    created_at: Optional[datetime] = Field(None, alias="CreateDateIso")

    model_config = ConfigDict(populate_by_name=True, extra="allow")


class ClaimList(BaseModel):
    """Wrapper for listing claims."""

    claims: list[ClaimItem] = Field(default_factory=list)
    count: Optional[int] = None
    model_config = ConfigDict(populate_by_name=True, extra="allow")

    @model_validator(mode="before")
    @classmethod
    def _normalize_input(cls, value: Any) -> Any:
        if isinstance(value, list):
            return {"claims": value}
        if isinstance(value, dict):
            if "claims" in value:
                return value
            if isinstance(value.get("Model"), list):
                return {"claims": value["Model"], "count": value.get("Count")}
            if isinstance(value.get("Items"), list):
                return {"claims": value["Items"], "count": value.get("Count")}
        return value
