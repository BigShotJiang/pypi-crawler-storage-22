"""Pydantic models for notification settings."""

from __future__ import annotations

from pydantic import BaseModel, Field, ConfigDict


class NotificationSettings(BaseModel):
    """Notification settings for one callback type."""

    is_enabled: bool | None = Field(None, alias="IsEnabled")
    address: str | None = Field(None, alias="Address")
    http_method: str | None = Field(None, alias="HttpMethod")
    format: str | None = Field(None, alias="Format")
    type: str | None = Field(None, alias="Type")

    model_config = ConfigDict(populate_by_name=True, extra="allow")
