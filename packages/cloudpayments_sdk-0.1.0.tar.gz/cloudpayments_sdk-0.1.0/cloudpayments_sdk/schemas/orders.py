"""Pydantic models for order (invoice) endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field, ConfigDict


class Order(BaseModel):
    """Representation of an invoice or order."""

    id: Optional[str] = Field(None, alias="Id")
    invoice_id: Optional[str] = Field(None, alias="InvoiceId")
    amount: Optional[float] = Field(None, alias="Amount")
    currency: Optional[str] = Field(None, alias="Currency")
    description: Optional[str] = Field(None, alias="Description")
    account_id: Optional[str] = Field(None, alias="AccountId")
    status: Optional[str] = Field(None, alias="Status")
    created_at: Optional[datetime] = Field(None, alias="CreateDateIso")
    model_config = ConfigDict(populate_by_name=True, extra="allow")
