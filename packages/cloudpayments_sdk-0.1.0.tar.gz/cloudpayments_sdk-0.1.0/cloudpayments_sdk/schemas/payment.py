"""Pydantic models for payment endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, ConfigDict, model_validator


class Payment(BaseModel):
    """Representation of a payment (transaction) returned by the API."""

    id: int | None = Field(None, alias="TransactionId")
    amount: float | None = Field(None, alias="Amount")
    currency: str | None = Field(None, alias="Currency")
    status: str | None = Field(None, alias="Status")
    status_code: int | str | None = Field(None, alias="StatusCode")
    reason: str | None = Field(None, alias="Reason")
    card_first_six: str | None = Field(None, alias="CardFirstSix")
    card_last_four: str | None = Field(None, alias="CardLastFour")
    card_exp_first_six: str | None = Field(None, alias="CardExpFirstSix")
    invoice_id: str | None = Field(None, alias="InvoiceId")
    account_id: str | None = Field(None, alias="AccountId")
    token: str | None = Field(None, alias="Token")
    created_at: datetime | None = Field(None, alias="CreatedDateIso")

    model_config = ConfigDict(populate_by_name=True, extra="allow")


class PaymentList(BaseModel):
    """Container for payment list responses."""

    payments: list[Payment] = Field(default_factory=list)
    count: int | None = None

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    @model_validator(mode="before")
    @classmethod
    def _normalize_input(cls, value: Any) -> Any:
        if isinstance(value, list):
            return {"payments": value}
        if isinstance(value, dict):
            if "payments" in value:
                return value
            if isinstance(value.get("Transactions"), list):
                return {
                    "payments": value["Transactions"],
                    "count": value.get("Count") or value.get("Total") or value.get("TotalCount"),
                }
            if isinstance(value.get("Items"), list):
                return {
                    "payments": value["Items"],
                    "count": value.get("Count") or value.get("Total") or value.get("TotalCount"),
                }
            if isinstance(value.get("Model"), list):
                return {"payments": value["Model"], "count": value.get("Count")}
        return value


class CardToken(BaseModel):
    """Saved card token details."""

    token: str | None = Field(None, alias="Token")
    account_id: str | None = Field(None, alias="AccountId")
    card_first_six: str | None = Field(None, alias="CardFirstSix")
    card_last_four: str | None = Field(None, alias="CardLastFour")
    card_type: str | None = Field(None, alias="CardType")
    issuer: str | None = Field(None, alias="Issuer")
    expiration: str | None = Field(None, alias="ExpDate")

    model_config = ConfigDict(populate_by_name=True, extra="allow")


class CardTokenList(BaseModel):
    """Container for token list responses."""

    tokens: list[CardToken] = Field(default_factory=list)

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    @model_validator(mode="before")
    @classmethod
    def _normalize_input(cls, value: Any) -> Any:
        if isinstance(value, list):
            return {"tokens": value}
        if isinstance(value, dict):
            if "tokens" in value:
                return value
            if isinstance(value.get("Model"), list):
                return {"tokens": value["Model"]}
            if isinstance(value.get("Items"), list):
                return {"tokens": value["Items"]}
        return value
