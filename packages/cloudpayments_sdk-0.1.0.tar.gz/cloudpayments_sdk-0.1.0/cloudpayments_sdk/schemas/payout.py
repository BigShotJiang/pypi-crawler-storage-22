"""Pydantic models for payout endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field, ConfigDict


class Payout(BaseModel):
    """Representation of a payout transaction."""

    id: Optional[int] = Field(None, alias="Id")
    amount: Optional[float] = Field(None, alias="Amount")
    currency: Optional[str] = Field(None, alias="Currency")
    account_id: Optional[str] = Field(None, alias="AccountId")
    status: Optional[str] = Field(None, alias="Status")
    created_at: Optional[datetime] = Field(None, alias="CreateDateIso")

    model_config = ConfigDict(populate_by_name=True, extra="allow")
