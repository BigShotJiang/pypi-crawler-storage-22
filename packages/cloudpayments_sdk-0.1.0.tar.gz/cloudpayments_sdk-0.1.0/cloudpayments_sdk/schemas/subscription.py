"""Pydantic models for subscription endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, ConfigDict, model_validator


class Subscription(BaseModel):
    """Representation of a recurring subscription."""

    id: str | None = Field(None, alias="Id")
    account_id: str | None = Field(None, alias="AccountId")
    description: str | None = Field(None, alias="Description")
    amount: float | None = Field(None, alias="Amount")
    currency: str | None = Field(None, alias="Currency")
    status: str | None = Field(None, alias="Status")
    start_date_iso: datetime | None = Field(None, alias="StartDateIso")
    created_at: datetime | None = Field(None, alias="CreatedDateIso")
    interval: str | None = Field(None, alias="Interval")
    period: int | None = Field(None, alias="Period")
    max_periods: int | None = Field(None, alias="MaxPeriods")

    model_config = ConfigDict(populate_by_name=True, extra="allow")


class SubscriptionList(BaseModel):
    """Container for subscription list responses."""

    subscriptions: list[Subscription] = Field(default_factory=list)

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    @model_validator(mode="before")
    @classmethod
    def _normalize_input(cls, value: Any) -> Any:
        if isinstance(value, list):
            return {"subscriptions": value}
        if isinstance(value, dict):
            if "subscriptions" in value:
                return value
            if isinstance(value.get("Model"), list):
                return {"subscriptions": value["Model"]}
            if isinstance(value.get("Items"), list):
                return {"subscriptions": value["Items"]}
        return value
