"""Pydantic models for CloudPayments webhooks."""

from __future__ import annotations

from typing import Any, Dict

from pydantic import BaseModel, Field, ConfigDict


class WebhookEvent(BaseModel):
    """Generic webhook event wrapper.

    The API sends various event types with different payloads.  At a minimum
    they include a type (e.g. ``PaymentSucceeded``) and a payload under
    ``Data``.  Additional fields may be present in the future, so
    ``extra='allow'`` is enabled.
    """

    type: str = Field(..., alias="Type")
    data: Dict[str, Any] = Field(default_factory=dict, alias="Data")
    model_config = ConfigDict(populate_by_name=True, extra="allow")
