"""Cryptographic utilities for signatures and idempotency keys."""

import base64
import hashlib
import hmac
import secrets


def sign_message(secret: str, message: bytes) -> str:
    """Compute an HMAC SHA256 signature for the message.

    Args:
        secret: Shared secret key used for signing (webhook secret).
        message: Raw request body.

    Returns:
        Base64‑encoded HMAC digest.
    """
    digest = hmac.new(secret.encode(), message, hashlib.sha256).digest()
    return base64.b64encode(digest).decode()


def generate_idempotency_key() -> str:
    """Generate a random idempotency key for safely retrying requests."""
    return secrets.token_hex(16)
