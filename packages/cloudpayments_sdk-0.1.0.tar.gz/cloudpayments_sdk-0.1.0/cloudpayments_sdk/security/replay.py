"""Simple anti‑replay helpers."""

import time
from collections import deque
from typing import Deque, Tuple


class ReplayProtector:
    """Protect against replay attacks by tracking nonces and timestamps."""

    def __init__(self, window_seconds: int = 300, max_entries: int = 1000) -> None:
        self.window_seconds = window_seconds
        self.max_entries = max_entries
        self.seen: Deque[Tuple[str, float]] = deque()

    def is_replay(self, nonce: str, timestamp: float) -> bool:
        """Check whether the given nonce/timestamp pair has already been seen."""
        current_time = time.time()
        # Remove expired entries
        while self.seen and current_time - self.seen[0][1] > self.window_seconds:
            self.seen.popleft()
        # Check if nonce is in deque
        for existing_nonce, _ in self.seen:
            if existing_nonce == nonce:
                return True
        # Record the new nonce
        self.seen.append((nonce, timestamp))
        # Enforce maximum entries
        if len(self.seen) > self.max_entries:
            self.seen.popleft()
        return False
