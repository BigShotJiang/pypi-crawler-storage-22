"""Abstract base classes for transport implementations.

Transports are responsible for performing HTTP requests to the CloudPayments
API.  Two concrete implementations are provided: synchronous and
asynchronous transports using ``httpx``.  Middleware such as retries and
logging can wrap a transport to augment its behaviour.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class BaseTransport(ABC):
    """A base class for synchronous HTTP transports."""

    @abstractmethod
    def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        """Perform an HTTP request.

        Concrete implementations should send the request to ``self.base_url``
        plus ``path`` and return the deserialized JSON body (or raise an
        appropriate exception on error).
        """
        raise NotImplementedError


class AsyncBaseTransport(ABC):
    """A base class for asynchronous HTTP transports."""

    @abstractmethod
    async def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        """Perform an HTTP request asynchronously.

        Concrete implementations should send the request to ``self.base_url``
        plus ``path`` and return the deserialized JSON body (or raise an
        appropriate exception on error).
        """
        raise NotImplementedError
