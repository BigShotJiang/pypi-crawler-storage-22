"""Synchronous transport implementation using httpx.Client."""

from __future__ import annotations

import time
from typing import Any, Dict, Optional

import httpx

from .base import BaseTransport
from ..config import Config
from ..exceptions import get_exception_for_status, NetworkError, ApiResponseError
from ..logger import log_event


class HttpxSyncTransport(BaseTransport):
    """A simple synchronous transport built on httpx.Client.

    The client is configured with Basic Authentication using the merchant's
    public ID and API secret.  Requests are made relative to the base URL
    defined in the configuration.  Responses are parsed as JSON and
    returned as Python dictionaries.  Errors result in exceptions.
    """

    def __init__(self, config: Config) -> None:
        self.config = config
        self.client = httpx.Client(
            base_url=config.base_url,
            timeout=config.timeout,
            verify=config.verify_tls,
            auth=(config.public_id, config.api_secret),
        )

    def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        start = time.perf_counter()
        try:
            response = self.client.request(
                method=method,
                url=path,
                params=params,
                json=json,
                headers=headers,
            )
        except httpx.RequestError as exc:
            # Wrap network errors in our custom exception
            raise NetworkError(str(exc)) from exc
        duration = time.perf_counter() - start
        if response.status_code >= 400:
            exc_cls = get_exception_for_status(response.status_code)
            log_event(path, "error", duration)
            raise exc_cls(response.text)
        log_event(path, "ok", duration)
        try:
            payload = response.json()
        except ValueError:
            return response.text
        if isinstance(payload, dict) and payload.get("Success") is False:
            raise _make_api_response_error(payload)
        return payload

    def __del__(self) -> None:
        # Ensure the client is closed when the transport is GC'd
        try:
            self.client.close()
        except Exception:
            pass

    def close(self) -> None:
        """Close underlying httpx client."""
        self.client.close()


def _make_api_response_error(payload: dict[str, Any]) -> ApiResponseError:
    message = payload.get("Message")
    model = payload.get("Model")
    if not message and isinstance(model, dict):
        message = (
            model.get("CardHolderMessage")
            or model.get("Description")
            or model.get("Reason")
            or model.get("Message")
        )
        if not message and model.get("ReasonCode") is not None:
            message = f"Payment rejected (ReasonCode={model.get('ReasonCode')})"
    if not message:
        message = "CloudPayments API returned Success=false"

    error_code = payload.get("ErrorCode")
    if error_code is not None and "ErrorCode" not in message:
        message = f"{message} (ErrorCode={error_code})"

    return ApiResponseError(message, error_code=error_code, response=payload)
