"""Middleware for retrying requests and adding metadata to logs.

This module defines a simple retry middleware that wraps a transport and
retries requests on transient errors such as network failures or rate
limiting.  Developers can extend this middleware to implement
backoff with jitter, circuit breaking, tracing, etc.
"""

import asyncio
import time
import random
from typing import Any, Dict, Optional

from ..exceptions import RateLimitError, NetworkError
from .base import BaseTransport, AsyncBaseTransport


class RetryMiddleware(BaseTransport):
    """Wrap a synchronous transport with retry logic."""

    def __init__(
        self,
        transport: BaseTransport,
        retries: int = 3,
        backoff_factor: float = 0.5,
        jitter: float = 0.1,
    ) -> None:
        self.transport = transport
        self.retries = retries
        self.backoff_factor = backoff_factor
        self.jitter = jitter

    def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        last_exc: Exception | None = None
        for attempt in range(self.retries + 1):
            try:
                return self.transport.request(
                    method=method,
                    path=path,
                    params=params,
                    json=json,
                    headers=headers,
                )
            except (RateLimitError, NetworkError) as exc:
                last_exc = exc
                sleep_time = self.backoff_factor * (2 ** attempt)
                sleep_time += random.uniform(0, self.jitter)
                time.sleep(sleep_time)
                continue
        # If we exhausted all retries, raise the last exception
        if last_exc is not None:
            raise last_exc
        # Should never reach here
        raise RuntimeError("RetryMiddleware: Unexpected state")


class AsyncRetryMiddleware(AsyncBaseTransport):
    """Wrap an async transport with retry logic."""

    def __init__(
        self,
        transport: AsyncBaseTransport,
        retries: int = 3,
        backoff_factor: float = 0.5,
        jitter: float = 0.1,
    ) -> None:
        self.transport = transport
        self.retries = retries
        self.backoff_factor = backoff_factor
        self.jitter = jitter

    async def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        last_exc: Exception | None = None
        for attempt in range(self.retries + 1):
            try:
                return await self.transport.request(
                    method=method,
                    path=path,
                    params=params,
                    json=json,
                    headers=headers,
                )
            except (RateLimitError, NetworkError) as exc:
                last_exc = exc
                sleep_time = self.backoff_factor * (2 ** attempt)
                sleep_time += random.uniform(0, self.jitter)
                await asyncio.sleep(sleep_time)
                continue
        if last_exc is not None:
            raise last_exc
        raise RuntimeError("AsyncRetryMiddleware: Unexpected state")
