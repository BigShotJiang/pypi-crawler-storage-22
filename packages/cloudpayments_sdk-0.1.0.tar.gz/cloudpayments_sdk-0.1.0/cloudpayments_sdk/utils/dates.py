"""Date and time utilities."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional


ISO_FMT = "%Y-%m-%dT%H:%M:%S%z"


def to_iso8601(dt: datetime) -> str:
    """Convert a datetime to an ISO8601 string with timezone.

    Args:
        dt: A timezone‑aware datetime.

    Returns:
        A formatted ISO8601 string.
    """
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.strftime(ISO_FMT)


def parse_iso8601(value: str) -> Optional[datetime]:
    """Parse an ISO8601 string into a datetime object.

    Args:
        value: ISO8601 formatted string.

    Returns:
        A timezone‑aware datetime or ``None`` if parsing fails.
    """
    try:
        return datetime.strptime(value, ISO_FMT)
    except Exception:
        return None
