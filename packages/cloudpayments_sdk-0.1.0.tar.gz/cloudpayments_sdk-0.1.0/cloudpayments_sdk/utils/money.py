"""Money utilities for rounding and formatting."""

from decimal import Decimal, ROUND_HALF_UP, getcontext


getcontext().prec = 28  # Set a reasonable precision for money calculations


def round_money(amount: float, precision: int = 2) -> float:
    """Round a floating point amount to the given precision using bankers rounding."""
    quant = Decimal('1.{}'.format('0' * precision))
    return float(Decimal(str(amount)).quantize(quant, rounding=ROUND_HALF_UP))


def format_money(amount: float, currency: str) -> str:
    """Format a money amount for display."""
    rounded = round_money(amount, 2)
    return f"{rounded:.2f} {currency}"
