"""Helper functions for paginated responses."""

from typing import Any, Callable, Iterable, List


def paginate(
    list_func: Callable[..., List[Any]],
    *,
    page_size: int = 50,
    **kwargs: Any,
) -> Iterable[Any]:
    """Iterate over paginated API results.

    ``list_func`` should accept ``page`` and ``per_page`` keyword arguments and
    return a list of items.  Additional keyword arguments are passed
    through to ``list_func`` on each call.
    """
    page = 1
    while True:
        items = list_func(page=page, per_page=page_size, **kwargs)
        for item in items:
            yield item
        if len(items) < page_size:
            break
        page += 1
