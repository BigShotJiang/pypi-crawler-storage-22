"""Narrow type aliases used throughout the SDK."""

from typing import TypedDict, Literal, Dict, Any


class JsonData(TypedDict, total=False):
    """Generic JSON data passed with some API calls."""

    # Add your own keys here as needed
    pass


Currency = Literal["RUB", "USD", "EUR"]


MoneyDict = Dict[str, Any]
