"""Expose framework adapters for webhooks."""

from .fastapi import get_router as get_fastapi_router
from .flask import get_blueprint as get_flask_blueprint
from .django import webhook_view as get_django_view

__all__ = [
    "get_fastapi_router",
    "get_flask_blueprint",
    "get_django_view",
]
