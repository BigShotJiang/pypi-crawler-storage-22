"""Django adapter for CloudPayments webhooks."""

from __future__ import annotations

from typing import Any, Callable

from ..verify import verify_signature
from ..handlers import handle_event


def webhook_view(secret: str) -> Callable[[Any], Any]:
    """Factory that returns a Django view function for CloudPayments webhooks."""
    try:
        from django.http import HttpResponse, HttpResponseForbidden, JsonResponse  # type: ignore[import-not-found]
        from django.views.decorators.csrf import csrf_exempt  # type: ignore[import-not-found]
    except ImportError as exc:
        raise ImportError("Django is not installed. Install optional dependency: pip install cloudpayments-sdk[webhooks]") from exc

    @csrf_exempt
    def _view(request: Any) -> Any:
        if request.method != "POST":
            return HttpResponse(status=405)
        raw = request.body
        headers = {k: v for k, v in request.headers.items()}
        if not verify_signature(headers, raw, secret=secret):
            return HttpResponseForbidden("Invalid signature")
        event = handle_event(raw, headers)
        return JsonResponse({"ok": True, "type": event.type})

    return _view
