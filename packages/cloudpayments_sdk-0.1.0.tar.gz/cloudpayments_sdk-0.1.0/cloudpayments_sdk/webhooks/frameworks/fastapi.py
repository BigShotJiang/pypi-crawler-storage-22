"""FastAPI adapter for CloudPayments webhooks."""

from __future__ import annotations

from typing import Any

from ..verify import verify_signature
from ..handlers import handle_event


def get_router(secret: str) -> Any:
    """Create a FastAPI router that verifies and parses CloudPayments webhooks."""
    try:
        from fastapi import APIRouter, HTTPException, Request  # type: ignore[import-not-found]
    except ImportError as exc:
        raise ImportError("FastAPI is not installed. Install optional dependency: pip install cloudpayments-sdk[webhooks]") from exc

    router = APIRouter()

    @router.post("/cloudpayments/webhook")
    async def webhook(request: Request) -> dict[str, Any]:
        raw = await request.body()
        headers = {k: v for k, v in request.headers.items()}
        if not verify_signature(headers, raw, secret=secret):
            raise HTTPException(status_code=401, detail="Invalid signature")
        event = handle_event(raw, headers)
        return {"ok": True, "type": event.type}

    return router
