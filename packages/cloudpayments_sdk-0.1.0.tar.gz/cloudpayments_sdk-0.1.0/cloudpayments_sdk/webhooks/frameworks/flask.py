"""Flask adapter for CloudPayments webhooks."""

from __future__ import annotations

from typing import Any

from ..verify import verify_signature
from ..handlers import handle_event


def get_blueprint(secret: str) -> Any:
    """Create a Flask blueprint that verifies and parses CloudPayments webhooks."""
    try:
        from flask import Blueprint, abort, jsonify, request  # type: ignore[import-not-found]
    except ImportError as exc:
        raise ImportError("Flask is not installed. Install optional dependency: pip install cloudpayments-sdk[webhooks]") from exc

    bp = Blueprint("cloudpayments_webhook", __name__)

    @bp.route("/cloudpayments/webhook", methods=["POST"])
    def webhook() -> Any:
        raw: bytes = request.get_data()
        headers = {k: v for k, v in request.headers.items()}
        if not verify_signature(headers, raw, secret=secret):
            abort(401)
        event = handle_event(raw, headers)
        return jsonify({"ok": True, "type": event.type})

    return bp
