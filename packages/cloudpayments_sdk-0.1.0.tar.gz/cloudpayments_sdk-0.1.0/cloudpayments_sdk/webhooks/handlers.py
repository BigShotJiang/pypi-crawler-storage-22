"""Framework‑agnostic webhook parsing helpers."""

from __future__ import annotations

import json
from typing import Dict

from ..schemas.webhook import WebhookEvent


def handle_event(raw_body: bytes, headers: Dict[str, str]) -> WebhookEvent:
    """Parse a webhook payload into a structured WebhookEvent.

    Args:
        raw_body: Raw HTTP request body.
        headers: Request headers (unused but kept for extensibility).

    Returns:
        An instance of ``WebhookEvent`` with the event type and data.
    """
    try:
        payload = json.loads(raw_body.decode())
    except Exception as exc:
        raise ValueError(f"Invalid JSON payload: {exc}") from exc
    return WebhookEvent.model_validate(payload)
