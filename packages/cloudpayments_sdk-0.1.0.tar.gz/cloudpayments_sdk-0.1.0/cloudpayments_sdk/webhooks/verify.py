"""Verify CloudPayments webhook signatures."""

from __future__ import annotations

import hmac
from typing import Dict

from ..security.crypto import sign_message


def verify_signature(headers: Dict[str, str], body: bytes, secret: str) -> bool:
    """Verify the HMAC signature of a webhook request.

    Args:
        headers: Request headers (case insensitive keys).
        body: Raw request body as bytes.
        secret: Webhook secret key configured in CloudPayments dashboard.

    Returns:
        ``True`` if the signature matches; otherwise ``False``.
    """
    # The signature header name may vary; CloudPayments typically uses 'Content-HMAC'
    signature = headers.get("Content-Hmac") or headers.get("Content-HMAC") or headers.get("X-Content-Hmac")
    if not signature:
        return False
    expected = sign_message(secret, body)
    return hmac.compare_digest(signature, expected)
