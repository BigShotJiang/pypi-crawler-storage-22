"""Setup script for backwards compatibility.

This file exists primarily for developers who still rely on ``setup.py`` to
build or install the project.  It simply delegates to setuptools, which
reads the metadata from ``pyproject.toml``.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
