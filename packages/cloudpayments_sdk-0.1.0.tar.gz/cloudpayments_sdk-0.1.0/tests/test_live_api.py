"""Live integration tests against CloudPayments API.

These tests run only when all required env vars are present and
`CLOUDPAYMENTS_RUN_LIVE=1`.
"""

from __future__ import annotations

import asyncio
import os
import time
from datetime import date, timedelta
from typing import Any, Callable, TypeVar

import pytest

from cloudpayments_sdk import CloudPayments, AsyncCloudPayments
from cloudpayments_sdk.exceptions import ApiResponseError, ApiError, AuthenticationError


T = TypeVar("T")
NOTIFICATION_TYPES = ("Fail", "Confirm", "Recurrent", "Pay", "Refund", "Check")


def _live_enabled() -> bool:
    return os.getenv("CLOUDPAYMENTS_RUN_LIVE") == "1"


def _require_live_enabled() -> None:
    if not _live_enabled():
        pytest.skip("Set CLOUDPAYMENTS_RUN_LIVE=1 to execute live tests.")


def _run_or_business_error(fn: Callable[[], T]) -> T | Exception:
    try:
        return fn()
    except (ApiResponseError, ApiError, AuthenticationError) as exc:
        if isinstance(exc, ApiResponseError):
            assert isinstance(exc.response, dict)
            assert exc.response.get("Success") is False
        else:
            assert str(exc)
        return exc


def _extract_transaction_id(value: Any) -> int | None:
    if value is None:
        return None
    tx_id = getattr(value, "id", None)
    if isinstance(tx_id, int):
        return tx_id
    if isinstance(value, ApiResponseError):
        model = value.response.get("Model")
        if isinstance(model, dict) and isinstance(model.get("TransactionId"), int):
            return model["TransactionId"]
    return None


def _extract_subscription_id(value: Any) -> str | None:
    if value is None:
        return None
    sub_id = getattr(value, "id", None)
    if isinstance(sub_id, str) and sub_id:
        return sub_id
    if isinstance(value, ApiResponseError):
        model = value.response.get("Model")
        if isinstance(model, dict):
            candidate = model.get("Id") or model.get("SubscriptionId")
            if isinstance(candidate, str) and candidate:
                return candidate
    return None


@pytest.fixture(scope="session")
def live_credentials() -> tuple[str, str]:
    _require_live_enabled()
    public_id = os.getenv("CLOUDPAYMENTS_PUBLIC_ID")
    api_secret = os.getenv("CLOUDPAYMENTS_API_SECRET")
    if not public_id or not api_secret:
        pytest.skip("Set CLOUDPAYMENTS_PUBLIC_ID and CLOUDPAYMENTS_API_SECRET for live tests.")
    return public_id, api_secret


@pytest.fixture(scope="session")
def live_client(live_credentials: tuple[str, str]) -> CloudPayments:
    public_id, api_secret = live_credentials
    with CloudPayments(public_id=public_id, api_secret=api_secret, retries=0) as client:
        yield client


@pytest.mark.live
def test_live_sync_test_endpoint(live_client: CloudPayments) -> None:
    result = live_client.test()
    assert result is True


@pytest.mark.live
def test_live_sync_payments_methods(live_client: CloudPayments) -> None:
    ip_address = os.getenv("CLOUDPAYMENTS_IP_ADDRESS", "127.0.0.1")
    cryptogram = os.getenv("CLOUDPAYMENTS_CRYPTOGRAM", "invalid_packet")
    token = os.getenv("CLOUDPAYMENTS_TOKEN", "invalid_token")
    account_id = os.getenv("CLOUDPAYMENTS_ACCOUNT_ID", "sdk_live_account")
    invoice_id = f"sdk-live-{int(time.time())}"
    today = date.today().isoformat()
    week_ago = (date.today() - timedelta(days=7)).isoformat()

    charge = _run_or_business_error(
        lambda: live_client.payments.charge_card(
            amount=1.0,
            currency="RUB",
            card_cryptogram_packet=cryptogram,
            ip_address=ip_address,
            account_id=account_id,
            invoice_id=invoice_id,
            description="SDK live charge test",
        )
    )
    auth = _run_or_business_error(
        lambda: live_client.payments.charge_card(
            amount=1.0,
            currency="RUB",
            card_cryptogram_packet=cryptogram,
            ip_address=ip_address,
            account_id=account_id,
            invoice_id=f"{invoice_id}-auth",
            description="SDK live auth test",
            two_step=True,
        )
    )
    charge_token = _run_or_business_error(
        lambda: live_client.payments.charge_token(
            amount=1.0,
            token=token,
            ip_address=ip_address,
            currency="RUB",
            account_id=account_id,
            invoice_id=f"{invoice_id}-token",
        )
    )
    auth_token = _run_or_business_error(
        lambda: live_client.payments.charge_token(
            amount=1.0,
            token=token,
            ip_address=ip_address,
            currency="RUB",
            account_id=account_id,
            invoice_id=f"{invoice_id}-token-auth",
            two_step=True,
        )
    )

    assert charge is not None
    assert auth is not None
    assert charge_token is not None
    assert auth_token is not None

    tx_id = (
        _extract_transaction_id(charge)
        or _extract_transaction_id(auth)
        or _extract_transaction_id(charge_token)
        or _extract_transaction_id(auth_token)
    )
    if tx_id is None:
        tx_from_env = os.getenv("CLOUDPAYMENTS_TRANSACTION_ID")
        tx_id = int(tx_from_env) if tx_from_env else None

    if tx_id is not None:
        assert _run_or_business_error(lambda: live_client.payments.get_transaction(transaction_id=tx_id)) is not None
        assert _run_or_business_error(lambda: live_client.payments.confirm(transaction_id=tx_id, amount=1.0)) is not None
        assert _run_or_business_error(lambda: live_client.payments.cancel(transaction_id=tx_id)) is not None
        assert _run_or_business_error(lambda: live_client.payments.refund(transaction_id=tx_id, amount=1.0)) is not None

    list_day = _run_or_business_error(lambda: live_client.payments.list_transactions_for_day(date=today))
    assert list_day is not None

    list_range = _run_or_business_error(
        lambda: live_client.payments.list_transactions_for_range(
            created_date_gte=week_ago,
            created_date_lte=today,
            page_number=1,
        )
    )
    assert list_range is not None

    find_result = _run_or_business_error(lambda: live_client.payments.find(invoice_id=invoice_id))
    assert find_result is not None

    tokens = _run_or_business_error(lambda: live_client.payments.list_tokens(account_id=account_id))
    assert tokens is not None


@pytest.mark.live
def test_live_sync_orders_methods(live_client: CloudPayments) -> None:
    order_tag = f"sdk-order-{int(time.time())}"
    created = _run_or_business_error(
        lambda: live_client.orders.create(
            amount=1.0,
            currency="RUB",
            description="SDK live order test",
            invoice_id=order_tag,
            account_id=os.getenv("CLOUDPAYMENTS_ACCOUNT_ID", "sdk_live_account"),
        )
    )
    assert created is not None

    cancel = _run_or_business_error(lambda: live_client.orders.cancel(invoice_id=order_tag))
    assert cancel is not None


@pytest.mark.live
def test_live_sync_subscriptions_methods(live_client: CloudPayments) -> None:
    account_id = os.getenv("CLOUDPAYMENTS_ACCOUNT_ID", "sdk_live_account")
    token = os.getenv("CLOUDPAYMENTS_TOKEN", "invalid_token")

    found = _run_or_business_error(lambda: live_client.subscriptions.find(account_id=account_id))
    assert found is not None

    created = _run_or_business_error(
        lambda: live_client.subscriptions.create(
            token=token,
            account_id=account_id,
            description="SDK live subscription test",
            amount=1.0,
            currency="RUB",
            email=os.getenv("CLOUDPAYMENTS_EMAIL", "sdk-live@example.com"),
            interval="Week",
            period=1,
        )
    )
    assert created is not None

    subscription_id = _extract_subscription_id(created) or os.getenv("CLOUDPAYMENTS_SUBSCRIPTION_ID")
    if subscription_id:
        assert _run_or_business_error(lambda: live_client.subscriptions.get(subscription_id=subscription_id)) is not None
        assert _run_or_business_error(
            lambda: live_client.subscriptions.update(subscription_id=subscription_id, amount=1.0)
        ) is not None
        assert _run_or_business_error(lambda: live_client.subscriptions.cancel(subscription_id=subscription_id)) is not None


@pytest.mark.live
def test_live_sync_notifications_methods(live_client: CloudPayments) -> None:
    for notification_type in NOTIFICATION_TYPES:
        settings = _run_or_business_error(lambda n=notification_type: live_client.notifications.get(notification_type=n))
        assert settings is not None
        if isinstance(settings, ApiResponseError):
            continue
        update = _run_or_business_error(
            lambda n=notification_type, s=settings: live_client.notifications.update(
                notification_type=n,
                enabled=bool(s.is_enabled),
                address=s.address,
                http_method=s.http_method,
                format=s.format,
            )
        )
        assert update is not None


@pytest.mark.live
def test_live_sync_claims_and_payouts_methods(live_client: CloudPayments) -> None:
    date_to = date.today().isoformat()
    date_from = (date.today() - timedelta(days=7)).isoformat()
    claims = _run_or_business_error(lambda: live_client.claims.list(date_from=date_from, date_to=date_to))
    assert claims is not None

    cryptogram = os.getenv("CLOUDPAYMENTS_CRYPTOGRAM", "invalid_packet")
    token = os.getenv("CLOUDPAYMENTS_TOKEN", "invalid_token")
    account_id = os.getenv("CLOUDPAYMENTS_ACCOUNT_ID", "sdk_live_account")

    payout_cryptogram = _run_or_business_error(
        lambda: live_client.payouts.cryptogram(
            amount=1.0,
            currency="RUB",
            card_cryptogram_packet=cryptogram,
            account_id=account_id,
            ip_address=os.getenv("CLOUDPAYMENTS_IP_ADDRESS", "127.0.0.1"),
        )
    )
    assert payout_cryptogram is not None

    payout_token = _run_or_business_error(
        lambda: live_client.payouts.token(
            amount=1.0,
            currency="RUB",
            token=token,
            account_id=account_id,
            ip_address=os.getenv("CLOUDPAYMENTS_IP_ADDRESS", "127.0.0.1"),
        )
    )
    assert payout_token is not None

    payout_sbp = _run_or_business_error(
        lambda: live_client.payouts.sbp(
            amount=1.0,
            currency="RUB",
            sbp_beneficiary_id=os.getenv("CLOUDPAYMENTS_SBP_BENEFICIARY_ID", "invalid_sbp_id"),
            account_id=account_id,
            ip_address=os.getenv("CLOUDPAYMENTS_IP_ADDRESS", "127.0.0.1"),
        )
    )
    assert payout_sbp is not None


@pytest.mark.live
def test_live_async_smoke(live_credentials: tuple[str, str]) -> None:
    public_id, api_secret = live_credentials
    account_id = os.getenv("CLOUDPAYMENTS_ACCOUNT_ID", "sdk_live_account")

    async def _run() -> None:
        async with AsyncCloudPayments(public_id=public_id, api_secret=api_secret, retries=0) as client:
            assert await client.test() is True

            date_to = date.today().isoformat()
            try:
                list_result: Any = await client.payments.list_transactions(date=date_to, page_number=1)
            except (ApiResponseError, ApiError, AuthenticationError) as exc:
                if isinstance(exc, ApiResponseError):
                    assert isinstance(exc.response, dict)
                else:
                    assert str(exc)
                list_result = exc
            assert list_result is not None

            try:
                notif: Any = await client.notifications.get(notification_type="Pay")
            except (ApiResponseError, ApiError, AuthenticationError) as exc:
                if isinstance(exc, ApiResponseError):
                    assert isinstance(exc.response, dict)
                else:
                    assert str(exc)
                notif = exc
            assert notif is not None

            try:
                tokens: Any = await client.payments.list_tokens(account_id=account_id)
            except (ApiResponseError, ApiError, AuthenticationError) as exc:
                if isinstance(exc, ApiResponseError):
                    assert isinstance(exc.response, dict)
                else:
                    assert str(exc)
                tokens = exc
            assert tokens is not None

    asyncio.run(_run())
