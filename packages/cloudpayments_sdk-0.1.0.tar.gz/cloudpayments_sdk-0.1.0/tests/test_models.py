"""Basic tests for Pydantic models."""

from cloudpayments_sdk.schemas.payment import PaymentList, CardTokenList
from cloudpayments_sdk.schemas.payment import Payment
from cloudpayments_sdk.schemas.subscription import SubscriptionList


def test_payment_model_extra_fields() -> None:
    # Payload with extra fields not explicitly defined
    payload = {
        "TransactionId": 1,
        "Amount": 10.0,
        "Currency": "RUB",
        "Unexpected": "value",
    }
    payment = Payment.model_validate(payload)
    assert payment.id == 1
    assert payment.amount == 10.0
    assert payment.currency == "RUB"
    # Extra fields should be accessible via dict() or model_dump()
    dumped = payment.model_dump(by_alias=True)
    assert dumped.get("Unexpected") == "value"


def test_payment_list_normalizes_items_shape() -> None:
    payload = {
        "Items": [
            {"TransactionId": 11, "Amount": 5.0, "Currency": "RUB", "StatusCode": 5},
            {"TransactionId": 12, "Amount": 6.0, "Currency": "RUB", "StatusCode": "3"},
        ],
        "Count": 2,
    }
    model = PaymentList.model_validate(payload)

    assert model.count == 2
    assert [p.id for p in model.payments] == [11, 12]
    assert model.payments[0].status_code == 5
    assert model.payments[1].status_code == "3"


def test_card_token_list_normalizes_model_shape() -> None:
    payload = {
        "Model": [
            {"Token": "tok_1", "AccountId": "acc_1"},
            {"Token": "tok_2", "AccountId": "acc_1"},
        ]
    }
    model = CardTokenList.model_validate(payload)

    assert [t.token for t in model.tokens] == ["tok_1", "tok_2"]


def test_subscription_list_normalizes_model_shape() -> None:
    payload = {"Model": [{"Id": "sub_1"}, {"Id": "sub_2"}]}
    model = SubscriptionList.model_validate(payload)

    assert [s.id for s in model.subscriptions] == ["sub_1", "sub_2"]
