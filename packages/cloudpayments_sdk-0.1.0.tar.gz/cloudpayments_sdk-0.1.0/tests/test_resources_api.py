"""Resource and method behavior tests."""

from __future__ import annotations

import asyncio
from typing import Any

from cloudpayments_sdk.resources import (
    PaymentsResource,
    AsyncPaymentsResource,
    SubscriptionsResource,
    AsyncSubscriptionsResource,
    NotificationsResource,
    OrdersResource,
    ClaimsResource,
    PayoutsResource,
)


class DummyTransport:
    def __init__(self, response: Any) -> None:
        self.response = response
        self.last_request: dict[str, Any] = {}

    def request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        self.last_request = {
            "method": method,
            "path": path,
            "params": params,
            "json": json,
            "headers": headers,
        }
        return self.response


class DummyAsyncTransport:
    def __init__(self, response: Any) -> None:
        self.response = response
        self.last_request: dict[str, Any] = {}

    async def request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        self.last_request = {
            "method": method,
            "path": path,
            "params": params,
            "json": json,
            "headers": headers,
        }
        return self.response


def test_payments_charge_token_two_step_and_model_parsing() -> None:
    transport = DummyTransport(
        {
            "Success": True,
            "Model": {
                "TransactionId": 101,
                "Amount": 99.5,
                "Currency": "RUB",
                "Status": "Authorized",
            },
        }
    )
    resource = PaymentsResource(transport)  # type: ignore[arg-type]

    payment = resource.charge_token(
        amount=99.5,
        token="tok_123",
        ip_address="127.0.0.1",
        two_step=True,
        account_id="acc_1",
    )

    assert transport.last_request["path"] == "/payments/tokens/auth"
    assert transport.last_request["json"]["Token"] == "tok_123"
    assert payment.id == 101
    assert payment.status == "Authorized"


def test_payments_list_transactions_parses_model_list() -> None:
    transport = DummyTransport(
        {
            "Success": True,
            "Model": [
                {"TransactionId": 1, "Amount": 10.0, "Currency": "RUB"},
                {"TransactionId": 2, "Amount": 20.0, "Currency": "RUB"},
            ],
        }
    )
    resource = PaymentsResource(transport)  # type: ignore[arg-type]

    result = resource.list_transactions(date="2026-02-14", page_number=1)

    assert transport.last_request["method"] == "POST"
    assert transport.last_request["path"] == "/payments/list"
    assert transport.last_request["json"]["Date"] == "2026-02-14"
    assert len(result.payments) == 2
    assert result.payments[0].id == 1


def test_payments_list_transactions_range_uses_v2_endpoint() -> None:
    transport = DummyTransport({"Success": True, "Model": []})
    resource = PaymentsResource(transport)  # type: ignore[arg-type]

    resource.list_transactions(
        created_date_gte="2026-02-13",
        created_date_lte="2026-02-14",
        page_number=1,
    )

    assert transport.last_request["method"] == "POST"
    assert transport.last_request["path"] == "/v2/payments/list"
    assert transport.last_request["json"]["CreatedDateGte"] == "2026-02-13"
    assert transport.last_request["json"]["CreatedDateLte"] == "2026-02-14"


def test_payments_list_transactions_requires_day_or_range() -> None:
    transport = DummyTransport({"Success": True, "Model": []})
    resource = PaymentsResource(transport)  # type: ignore[arg-type]

    try:
        resource.list_transactions()
    except ValueError as exc:
        assert "Provide either 'date'" in str(exc)
    else:
        raise AssertionError("Expected ValueError when list filters are missing")


def test_payments_list_transactions_requires_full_range_pair() -> None:
    transport = DummyTransport({"Success": True, "Model": []})
    resource = PaymentsResource(transport)  # type: ignore[arg-type]

    try:
        resource.list_transactions(created_date_gte="2026-02-13")
    except ValueError as exc:
        assert "'created_date_gte' and 'created_date_lte'" in str(exc)
    else:
        raise AssertionError("Expected ValueError when range is partial")


def test_payments_find_requires_identifier() -> None:
    transport = DummyTransport({"Success": True, "Model": {}})
    resource = PaymentsResource(transport)  # type: ignore[arg-type]

    try:
        resource.find()
    except ValueError as exc:
        assert "Either 'invoice_id' or 'account_id'" in str(exc)
    else:
        raise AssertionError("Expected ValueError when find identifiers are missing")


def test_subscriptions_find_uses_find_endpoint() -> None:
    transport = DummyTransport(
        {
            "Success": True,
            "Model": [
                {
                    "Id": "sub_1",
                    "AccountId": "acc_42",
                    "Amount": 100.0,
                    "Currency": "RUB",
                }
            ],
        }
    )
    resource = SubscriptionsResource(transport)  # type: ignore[arg-type]

    subscriptions = resource.find(account_id="acc_42")

    assert transport.last_request["path"] == "/subscriptions/find"
    assert transport.last_request["json"] == {"AccountId": "acc_42"}
    assert len(subscriptions.subscriptions) == 1
    assert subscriptions.subscriptions[0].id == "sub_1"


def test_subscriptions_create_normalizes_legacy_interval_period_order() -> None:
    transport = DummyTransport({"Success": True, "Model": {"Id": "sub_2"}})
    resource = SubscriptionsResource(transport)  # type: ignore[arg-type]

    resource.create(
        token="tok_1",
        account_id="acc_1",
        description="sub test",
        amount=10.0,
        currency="RUB",
        interval=1,  # legacy order in old SDK versions
        period="Week",
    )

    assert transport.last_request["path"] == "/subscriptions/create"
    assert transport.last_request["json"]["Interval"] == "Week"
    assert transport.last_request["json"]["Period"] == 1


def test_claims_list_uses_get_with_query_params() -> None:
    transport = DummyTransport({"Success": True, "Model": []})
    resource = ClaimsResource(transport)  # type: ignore[arg-type]

    resource.list(date_from="2026-02-01", date_to="2026-02-14")

    assert transport.last_request["method"] == "GET"
    assert transport.last_request["path"] == "/claims"
    assert transport.last_request["params"] == {"DateFrom": "2026-02-01", "DateTo": "2026-02-14"}


def test_payouts_token_and_sbp_paths() -> None:
    token_transport = DummyTransport({"Success": True, "Model": {"Id": 1}})
    token_resource = PayoutsResource(token_transport)  # type: ignore[arg-type]
    token_resource.token(amount=1.0, currency="RUB", token="tok_1", account_id="acc_1")
    assert token_transport.last_request["path"] == "/payments/token/topup"
    assert token_transport.last_request["json"]["Token"] == "tok_1"

    sbp_transport = DummyTransport({"Success": True, "Model": {"Id": 2}})
    sbp_resource = PayoutsResource(sbp_transport)  # type: ignore[arg-type]
    sbp_resource.sbp(amount=1.0, currency="RUB", sbp_beneficiary_id="sbp_1", account_id="acc_1")
    assert sbp_transport.last_request["path"] == "/payments/alt/topup"
    assert sbp_transport.last_request["json"]["SBPBeneficiaryId"] == "sbp_1"


def test_notifications_get_and_update_paths() -> None:
    get_transport = DummyTransport({"Success": True, "Model": {"IsEnabled": True, "Address": "https://cb"}})
    resource = NotificationsResource(get_transport)  # type: ignore[arg-type]
    settings = resource.get(notification_type="pay")
    assert get_transport.last_request["path"] == "/site/notifications/Pay/get"
    assert settings.is_enabled is True

    update_transport = DummyTransport({"Success": True, "Model": {"IsEnabled": True}})
    update_resource = NotificationsResource(update_transport)  # type: ignore[arg-type]
    update_resource.update(
        notification_type="refund",
        enabled=True,
        address="https://cb/refund",
        http_method="POST",
        format="JSON",
    )
    assert update_transport.last_request["path"] == "/site/notifications/Refund/update"
    assert update_transport.last_request["json"]["IsEnabled"] is True


def test_orders_cancel_accepts_deprecated_invoice_id() -> None:
    transport = DummyTransport({"Success": True, "Model": {"Id": "order_1"}})
    resource = OrdersResource(transport)  # type: ignore[arg-type]
    resource.cancel(invoice_id="order_1")
    assert transport.last_request["json"] == {"Id": "order_1"}


def test_async_payments_cancel_builds_valid_payload() -> None:
    async def _run() -> None:
        transport = DummyAsyncTransport(
            {
                "Success": True,
                "Model": {"TransactionId": 77, "Amount": 50.0, "Currency": "RUB"},
            }
        )
        resource = AsyncPaymentsResource(transport)  # type: ignore[arg-type]

        payment = await resource.cancel(transaction_id=77)

        assert transport.last_request["path"] == "/payments/void"
        assert transport.last_request["json"] == {"TransactionId": 77}
        assert payment.id == 77

    asyncio.run(_run())


def test_async_subscriptions_list_alias_calls_find_endpoint() -> None:
    async def _run() -> None:
        transport = DummyAsyncTransport({"Success": True, "Model": []})
        resource = AsyncSubscriptionsResource(transport)  # type: ignore[arg-type]

        result = await resource.list(account_id="acc_55")

        assert transport.last_request["path"] == "/subscriptions/find"
        assert transport.last_request["json"] == {"AccountId": "acc_55"}
        assert result.subscriptions == []

    asyncio.run(_run())
