"""Transport-level behavior tests."""

from __future__ import annotations

import pytest

from cloudpayments_sdk.config import Config
from cloudpayments_sdk.exceptions import ApiResponseError
from cloudpayments_sdk.transport.httpx_sync import HttpxSyncTransport


class _FakeResponse:
    def __init__(self, payload: dict) -> None:
        self.status_code = 200
        self.text = ""
        self._payload = payload

    def json(self) -> dict:
        return self._payload


class _FakeClient:
    def __init__(self, payload: dict) -> None:
        self.payload = payload

    def request(self, **kwargs):  # type: ignore[no-untyped-def]
        return _FakeResponse(self.payload)

    def close(self) -> None:
        return None


def test_sync_transport_raises_on_success_false() -> None:
    transport = HttpxSyncTransport(Config(public_id="pk", api_secret="sk", retries=0))
    transport.client = _FakeClient({"Success": False, "Message": "Declined", "ErrorCode": "13"})

    with pytest.raises(ApiResponseError) as exc:
        transport.request(method="POST", path="/payments/cards/charge")

    assert "Declined" in str(exc.value)
    assert exc.value.error_code == "13"
