"""Tests for webhook and security helper utilities."""

from __future__ import annotations

import builtins
import json
import time
from typing import Any

import pytest

from cloudpayments_sdk.security.crypto import generate_idempotency_key, sign_message
from cloudpayments_sdk.security.replay import ReplayProtector
from cloudpayments_sdk.webhooks.handlers import handle_event
from cloudpayments_sdk.webhooks.verify import verify_signature
from cloudpayments_sdk.webhooks.frameworks.fastapi import get_router as get_fastapi_router
from cloudpayments_sdk import webhooks


def test_verify_signature_accepts_valid_hmac() -> None:
    secret = "test_secret"
    body = b'{"Type":"PaymentSucceeded","Data":{"TransactionId":1}}'
    signature = sign_message(secret, body)

    assert verify_signature({"Content-HMAC": signature}, body, secret=secret) is True
    assert verify_signature({"Content-Hmac": signature}, body, secret=secret) is True


def test_webhooks_package_import_is_safe_without_framework_extras() -> None:
    assert callable(webhooks.verify_signature)
    assert callable(webhooks.handle_event)


def test_verify_signature_rejects_missing_or_invalid_signature() -> None:
    secret = "test_secret"
    body = b'{"Type":"PaymentSucceeded","Data":{"TransactionId":1}}'

    assert verify_signature({}, body, secret=secret) is False
    assert verify_signature({"Content-HMAC": "invalid"}, body, secret=secret) is False


def test_handle_event_parses_valid_payload() -> None:
    payload = {"Type": "PaymentSucceeded", "Data": {"TransactionId": 123, "Amount": 10.0}}
    event = handle_event(json.dumps(payload).encode("utf-8"), headers={})

    assert event.type == "PaymentSucceeded"
    assert event.data["TransactionId"] == 123


def test_handle_event_raises_on_invalid_json() -> None:
    with pytest.raises(ValueError):
        handle_event(b"{not_json", headers={})


def test_generate_idempotency_key_returns_hex_value() -> None:
    first = generate_idempotency_key()
    second = generate_idempotency_key()

    assert len(first) == 32
    assert len(second) == 32
    assert first != second
    int(first, 16)
    int(second, 16)


def test_replay_protector_detects_duplicate_nonce() -> None:
    protector = ReplayProtector(window_seconds=300, max_entries=10)
    now = time.time()

    assert protector.is_replay("nonce-1", timestamp=now) is False
    assert protector.is_replay("nonce-1", timestamp=now + 1) is True
    assert protector.is_replay("nonce-2", timestamp=now + 2) is False


def test_fastapi_adapter_reports_missing_dependency(monkeypatch: pytest.MonkeyPatch) -> None:
    original_import = builtins.__import__

    def _fake_import(name: str, *args: Any, **kwargs: Any) -> Any:
        if name == "fastapi":
            raise ImportError("fastapi not installed")
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", _fake_import)

    with pytest.raises(ImportError) as exc:
        get_fastapi_router("secret")
    assert "cloudpayments-sdk[webhooks]" in str(exc.value)
