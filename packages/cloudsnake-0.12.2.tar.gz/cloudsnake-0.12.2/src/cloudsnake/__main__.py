from cloudsnake.cli.cli import app


def main() -> None:
    """
    Entry point of the application.
    Starts the CLI.
    """
    app()


if __name__ == "__main__":
    main()
