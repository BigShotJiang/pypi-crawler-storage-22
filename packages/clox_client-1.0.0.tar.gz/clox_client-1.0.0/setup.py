#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Clox Client SDK - Python client for Clox Document Processing API
"""

from setuptools import setup
from pathlib import Path

# Read the contents of README file
this_directory = Path(__file__).parent
long_description = ""
readme_path = this_directory / "README.md"
if readme_path.exists():
    long_description = readme_path.read_text(encoding="utf-8")

setup(
    name="clox-client",
    version="1.0.0",
    author="Clox Team",
    author_email="support@clox.ai",
    description="Python client SDK for Clox Document Processing API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/clox/client-sdk",
    py_modules=["clox_client"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries",
        "Topic :: Internet :: WWW/HTTP",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.10",
    install_requires=[
        "requests>=2.28.0",
        "urllib3>=1.26.0",
    ],
    keywords=[
        "clox",
        "document-processing",
        "ocr",
        "api-client",
        "sdk",
        "rest-api",
    ],
    project_urls={
        "Bug Reports": "https://github.com/clox/client-sdk/issues",
        "Source": "https://github.com/clox/client-sdk",
        "Documentation": "https://docs.clox.ai/client",
    },
)
