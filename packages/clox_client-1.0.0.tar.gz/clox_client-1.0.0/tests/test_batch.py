import logging
from clox_client import Clox
logging.basicConfig(level=logging.INFO)
# logger = logging.get# logger(__name__)

class TestBatchWorkflow:

    def test_batch_workflow(self, clox_client: Clox):
        batch_requests = clox_client.get_batch_requests()
        batch_id = batch_requests.get("batches")[0]['_id']
        batch_details = clox_client.get_batch_details(batch_id)
        assert batch_details.get("documents")[0]['batch_id'] == batch_id