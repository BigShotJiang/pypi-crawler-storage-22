import logging
from clox_client import Clox
logging.basicConfig(level=logging.INFO)
# logger = logging.get# logger(__name__)


class TestPDFDocumentWorkflow:
    """Test suite for PDF document processing workflow."""

    def test_process_pdf_document(self, clox_client: Clox, pdf_file, shared_context):
        """Process a PDF document and store document_id for subsequent tests."""
        result = clox_client.process_document(pdf_file)
        # logger.info(f"Process PDF result: {result}")
        assert result is not None
        assert result['document_id'] is not None
        assert result['is_fraud'] is True

        # Store document_id for dependent tests
        shared_context['document_id'] = result['document_id']

    def test_get_pdf_document(self, clox_client: Clox, shared_context):
        """Get the processed PDF document using document_id from test_process_pdf_document."""
        document_id = shared_context['document_id']
        assert document_id is not None, "document_id not set - run test_process_pdf_document first"

        result = clox_client.get_document(document_id)
        assert result is not None
        assert len(result) > 0

    def test_get_annotated_pdf_document(self, clox_client: Clox, shared_context):
        """Get the annotated PDF document using document_id from test_process_pdf_document."""
        document_id = shared_context['document_id']
        assert document_id is not None, "document_id not set - run test_process_pdf_document first"

        result = clox_client.get_annotated_document(document_id)
        assert result is not None
        assert len(result) > 0


class TestImageDocumentWorkflow:
    """Test suite for image document processing workflow."""

    def test_process_image_document(self, clox_client: Clox, image_file, shared_context):
        """Process an image document and store document_id for subsequent tests."""
        result = clox_client.process_document(image_file)
        # logger.info(f"Process image result: {result}")
        assert result is not None
        assert result['document_id'] is not None
        assert result['is_fraud'] is True

        # Store document_id for dependent tests (overwrite previous PDF document_id)
        shared_context['document_id'] = result['document_id']

    def test_get_image_document(self, clox_client: Clox, shared_context):
        """Get the processed image document using document_id from test_process_image_document."""
        document_id = shared_context['document_id']
        assert document_id is not None, "document_id not set - run test_process_image_document first"

        result = clox_client.get_document(document_id)
        assert result is not None
        assert len(result) > 0

    def test_get_annotated_image_document(self, clox_client: Clox, shared_context):
        """Get the annotated image document using document_id from test_process_image_document."""
        document_id = shared_context['document_id']
        assert document_id is not None, "document_id not set - run test_process_image_document first"

        result = clox_client.get_annotated_document(document_id)
        assert result is not None
        assert len(result) > 0


class TestBatchDocumentWorkflow:
    """Test suite for batch/multiple document processing workflow."""

    def test_process_multiple_documents(self, clox_client: Clox, pdf_file, image_file, shared_context):
        """Process multiple documents and store document_ids for subsequent tests."""
        result = clox_client.process_documents(files=[pdf_file, image_file])
        # logger.info(f"Process multiple documents result: {result}")
        assert result is not None
        assert result['batch_id'] is not None
        shared_context['batch_id'] = result['batch_id']

    def test_get_batch_details(self, clox_client: Clox, shared_context):
        """Get the batch details using batch_id from test_process_multiple_documents."""
        batch_id = shared_context['batch_id']
        assert batch_id is not None, "batch_id not set - run test_process_multiple_documents first"

        result = clox_client.get_batch_details(batch_id)
        assert result is not None
        # logger.info(f"Get batch details result: {result}")