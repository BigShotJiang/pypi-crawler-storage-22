import logging
from clox_client import Clox

logging.basicConfig(level=logging.INFO)
# logger = logging.get# logger(__name__)


class TestUsersWorkflow:

    def test_create_user(self, clox_client: Clox, shared_context):
        user = clox_client.create_user(
            {
                "first_name": "Sample",
                "last_name": "User 2",
                "email": "sample_user2@clox.ai",
                "phone": "9191919191",
                "invitation_code": "ITBIJLNV",
                "password": "Clox@123456",
            }
        )
        # logger.info(f"User: {user}")
        assert user.get("email") == "sample_user2@clox.ai"

    def test_users_workflow(self, clox_client: Clox, shared_context):
        result = clox_client.list_users()
        # logger.info(f"Users: {result.get('users')}")
        assert result.get('users') is not None
        assert len(result.get('users')) > 0
        for user in result.get('users'):
            if user.get('email') == 'sample_user2@clox.ai':
                shared_context['user_id'] = user.get('_id')
                break
        assert shared_context['user_id'] is not None

    def test_update_user(self, clox_client: Clox, shared_context):
        user_id = shared_context["user_id"]
        result = clox_client.update_user(
            user_id,
            {
                "first_name": "Sample 2",
            },
        )
        # logger.info(f"Result: {result}")
        assert result.get("message") == "User updated successfully"

    def test_get_user(self, clox_client: Clox):
        result = clox_client.list_users()
        # logger.info(f"Users: {result.get('users')}")
        assert result.get('users') is not None
        assert len(result.get('users')) > 0
        for user in result.get('users'):
            if user.get('email') == 'sample_user2@clox.ai':
                assert user.get('first_name') == "Sample 2"

    def test_delete_user(self, clox_client: Clox, shared_context):
        user_id = shared_context["user_id"]
        result = clox_client.delete_user(user_id)
        # logger.info(f"Result: {result}")
        assert result.get("message") == "User deleted successfully"
