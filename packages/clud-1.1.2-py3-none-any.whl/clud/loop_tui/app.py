"""Main TUI application for clud --loop mode."""

import os
import subprocess
from collections.abc import AsyncIterator, Callable
from pathlib import Path

from textual import events, work
from textual.app import App, ComposeResult
from textual.containers import Container, VerticalScroll
from textual.widgets import Label, RichLog, Static


class CludLoopTUI(App[None]):
    """Terminal UI for clud --loop mode with streaming output and menu."""

    CSS = """
    Screen {
        background: $background;
        min-width: 80;
        min-height: 20;
    }

    #header {
        dock: top;
        height: 3;
        background: $accent;
        content-align: center middle;
        text-style: bold;
        color: $text;
    }

    #output {
        height: 1fr;
        border: heavy $accent;
        background: $surface;
        scrollbar-gutter: stable;
    }

    #menu_container {
        dock: bottom;
        height: auto;
        min-height: 5;
        background: $panel;
        border-top: heavy $accent;
        padding: 0 1;
    }

    #menu_items {
        text-align: center;
        padding: 1 0;
        text-style: bold;
    }

    #menu_help {
        text-align: center;
        color: $text-muted;
        padding: 0 0 1 0;
    }
    """

    MAIN_MENU = ["Options", "Exit"]
    OPTIONS_MENU = ["← Back", "Edit UPDATE.md", "Halt", "Help"]

    def __init__(
        self,
        on_exit: Callable[[], None] | None = None,
        on_halt: Callable[[], None] | None = None,
        on_edit: Callable[[], None] | None = None,
        update_file: Path | None = None,
    ) -> None:
        """Initialize TUI.

        Args:
            on_exit: Callback when user exits
            on_halt: Callback when user halts loop
            on_edit: Callback when user edits UPDATE.md
            update_file: Path to UPDATE.md file for editing
        """
        super().__init__()

        self.selected_index = 0
        self.current_menu = self.MAIN_MENU
        self.on_exit_callback = on_exit
        self.on_halt_callback = on_halt
        self.on_edit_callback = on_edit
        self.update_file = update_file

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield Static("clud --loop", id="header")

        with VerticalScroll(id="output"):
            yield RichLog(auto_scroll=True, highlight=True, markup=True)

        with Container(id="menu_container"):
            yield Label(id="menu_items")
            yield Label(id="menu_help")

    def on_mount(self) -> None:
        """Called when app is mounted."""
        self.update_menu()
        self.log_message("TUI initialized. Press 'q' to quit.")

    def log_message(self, message: str) -> None:
        """Add message to output log."""
        log = self.query_one(RichLog)
        log.write(message)

    def show_loading(self, message: str) -> None:
        """Show loading indicator with message.

        Args:
            message: Loading message to display
        """
        self.log_message(f"⏳ {message}")

    def hide_loading(self, message: str = "Done") -> None:
        """Hide loading indicator and show completion message.

        Args:
            message: Completion message to display
        """
        self.log_message(f"✓ {message}")

    def update_menu(self) -> None:
        """Update menu display based on current selection."""
        items: list[str] = []
        for i, item in enumerate(self.current_menu):
            if i == self.selected_index:
                items.append(f"[{item}]")
            else:
                items.append(f" {item} ")

        menu_label = self.query_one("#menu_items", Label)
        menu_label.update("  ".join(items))

        help_text = "↑↓/←→: Navigate  Enter: Select  Q/Esc: Exit"
        help_label = self.query_one("#menu_help", Label)
        help_label.update(help_text)

    def on_key(self, event: events.Key) -> None:
        """Handle keyboard events."""
        if event.key in ("left", "up"):
            self.selected_index = (self.selected_index - 1) % len(self.current_menu)
            self.update_menu()
        elif event.key in ("right", "down", "tab"):
            self.selected_index = (self.selected_index + 1) % len(self.current_menu)
            self.update_menu()
        elif event.key == "enter":
            self.handle_selection()
        elif event.key in ("escape", "q"):
            # If in submenu, go back to main menu
            if self.current_menu == self.OPTIONS_MENU:
                self.show_main_menu()
            else:
                # Exit the application
                if self.on_exit_callback:
                    self.on_exit_callback()
                self.exit()

    def handle_selection(self) -> None:
        """Handle menu item selection."""
        selected = self.current_menu[self.selected_index]

        if selected == "Exit":
            if self.on_exit_callback:
                self.on_exit_callback()
            self.exit()
        elif selected == "Options":
            self.show_options_menu()
        elif selected == "← Back":
            self.show_main_menu()
        elif selected == "Edit UPDATE.md":
            self.open_update_file()
        elif selected == "Halt":
            self.halt_loop()
        elif selected == "Help":
            self.show_help()

    def show_main_menu(self) -> None:
        """Switch to main menu."""
        self.current_menu = self.MAIN_MENU
        self.selected_index = 0
        self.update_menu()

    def show_options_menu(self) -> None:
        """Switch to options submenu."""
        self.current_menu = self.OPTIONS_MENU
        self.selected_index = 0
        self.update_menu()
        self.log_message("> Options menu opened")

    def open_update_file(self) -> None:
        """Open UPDATE.md in default editor."""
        if self.update_file is None:
            self.log_message("> Error: No UPDATE.md file specified")
            return

        if not self.update_file.exists():
            self.show_loading(f"Creating {self.update_file}...")
            self.update_file.parent.mkdir(parents=True, exist_ok=True)
            self.update_file.touch()
            self.hide_loading("File created")

        editor = os.environ.get("EDITOR", "notepad" if os.name == "nt" else "vi")
        self.show_loading(f"Opening {self.update_file} in {editor}...")

        try:
            # Suspend the app to allow the editor to take over the terminal
            with self.suspend():
                subprocess.run([editor, str(self.update_file)])
            self.hide_loading(f"Closed {editor}")

            # Call the on_edit callback if provided
            if self.on_edit_callback:
                self.on_edit_callback()
        except Exception as e:
            self.log_message(f"> Error opening editor: {e}")

    def halt_loop(self) -> None:
        """Halt the loop gracefully."""
        self.log_message("> Halting loop...")
        if self.on_halt_callback:
            self.on_halt_callback()
        self.exit()

    def show_help(self) -> None:
        """Display help information."""
        help_text = """
╔═══════════════════════════════════════════════════════════════╗
║                    CLUD LOOP TUI - HELP                        ║
╠═══════════════════════════════════════════════════════════════╣
║                                                                ║
║  KEYBOARD SHORTCUTS:                                           ║
║    ↑ / ↓ / ← / →    Navigate menu items                       ║
║    Tab              Next menu item                             ║
║    Enter            Select highlighted menu item               ║
║    Esc              Back to previous menu / Exit app           ║
║    Q                Quit application                           ║
║                                                                ║
║  MENU OPTIONS:                                                 ║
║    Options          Open options submenu                       ║
║    Exit             Quit clud --loop                           ║
║                                                                ║
║  OPTIONS SUBMENU:                                              ║
║    ← Back           Return to main menu                        ║
║    Edit UPDATE.md   Open UPDATE.md in default editor           ║
║    Halt             Stop loop gracefully                       ║
║    Help             Show this help screen                      ║
║                                                                ║
║  REQUIREMENTS:                                                 ║
║    Minimum terminal size: 80x20                                ║
║    UTF-8 encoding support recommended                          ║
║    ANSI color support (optional)                               ║
║                                                                ║
║  Press any key to close this help screen                       ║
╚═══════════════════════════════════════════════════════════════╝
"""
        self.log_message(help_text)

    @work(exclusive=False)
    async def stream_output(self, stream: AsyncIterator[str]) -> None:
        """Stream output from async iterator to log.

        Args:
            stream: Async iterator yielding output lines
        """
        log = self.query_one(RichLog)

        try:
            async for line in stream:
                log.write(line.rstrip())
        except Exception as e:
            log.write(f"> Error streaming output: {e}")

    def on_resize(self, event: events.Resize) -> None:
        """Handle terminal resize events.

        Args:
            event: Resize event
        """
        # Warn if terminal too small
        if event.size.width < 80 or event.size.height < 20:
            self.notify(
                "Terminal too small! Minimum 80x20 recommended.",
                severity="warning",
            )
