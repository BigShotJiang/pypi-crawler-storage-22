"""Integration between loop logic and TUI."""

from pathlib import Path
from typing import TYPE_CHECKING

from .loop_worker import LoopWorkerApp

if TYPE_CHECKING:
    from ..agent_args import Args


def run_loop_with_tui(args: "Args", claude_path: str, loop_count: int) -> int:
    """Run loop mode with TUI.

    This function wraps the standard loop execution with a TUI that displays
    streaming output and provides interactive menu options.

    Args:
        args: Command-line arguments
        claude_path: Path to Claude executable
        loop_count: Number of iterations to run

    Returns:
        Exit code (0 for success)
    """
    # Set up UPDATE.md file path (.loop/UPDATE.md)
    loop_dir = Path(".loop")
    update_file = loop_dir / "UPDATE.md"

    # Create and run the TUI app with loop worker
    app = LoopWorkerApp(
        args=args,
        claude_path=claude_path,
        loop_count=loop_count,
        update_file=update_file,
    )

    # Run the TUI app (blocking)
    app.run()

    # Return the exit code from the loop execution
    return app._exit_code
