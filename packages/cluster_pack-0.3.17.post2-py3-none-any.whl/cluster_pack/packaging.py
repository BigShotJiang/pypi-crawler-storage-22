import getpass
import importlib.util
import json
import logging
import os
import glob
import shutil
import subprocess
from subprocess import CalledProcessError
import sys
import tempfile
from typing import Tuple, Dict, Collection, List, Any, Optional, NamedTuple, Union
import uuid
import zipfile
import setuptools
from packaging.version import Version
from importlib.metadata import version as pkg_version

CRITEO_PYPI_URL = (
    "https://filer-build-pypi.prod.crto.in/repository/criteo.moab.pypi-read/simple"
)

EDITABLE_PACKAGES_INDEX = "editable_packages_index"

_logger = logging.getLogger(__name__)

JsonDictType = Dict[str, Any]


class PexTooLargeError(RuntimeError):
    pass


class PexCreationError(RuntimeError):
    pass


class PythonEnvDescription(NamedTuple):
    path_to_archive: str
    interpreter_cmd: str
    dest_path: str
    must_unpack: bool


UNPACKED_ENV_NAME = "pyenv"
LARGE_PEX_CMD = f"{UNPACKED_ENV_NAME}/__main__.py"


def _get_tmp_dir() -> str:
    tmp_dir = f"/tmp/{uuid.uuid1()}"
    _logger.debug(f"local tmp_dir {tmp_dir}")
    os.makedirs(tmp_dir, exist_ok=True)
    return tmp_dir


def _get_current_user() -> str:
    """
    Get the current user name.

    First checks the C_PACK_USER environment variable.
    If not set or empty, falls back to getpass.getuser().

    :return: username string
    """
    user = os.environ.get("C_PACK_USER", "").strip()
    if user:
        return user
    return getpass.getuser()


def zip_path(
    py_dir: str, include_base_name: bool = True, tmp_dir: str = _get_tmp_dir()
) -> str:
    """
    Zip current directory

    :param py_dir: directory to zip
    :param include_base_name: include the basename of py_dir into the archive (
        for skein zip files it should be False,
        for pyspark zip files it should be True)
    :return: destination of the archive
    """
    py_archive = os.path.join(tmp_dir, os.path.basename(py_dir) + ".zip")

    with zipfile.ZipFile(py_archive, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(py_dir):
            for file in files:
                # do not include .pyc files, it makes the import
                # fail for no obvious reason
                if not file.endswith(".pyc"):
                    zipf.write(
                        os.path.join(root, file),
                        os.path.join(
                            os.path.basename(py_dir) if include_base_name else "",
                            os.path.relpath(root, py_dir),
                            file,
                        )
                        if root != py_dir
                        else os.path.join(
                            os.path.basename(root) if include_base_name else "", file
                        ),
                    )
    return py_archive


def format_requirements(requirements: Dict[str, str]) -> List[str]:
    if requirements is None:
        return list()
    else:
        return [
            name + "==" + version if version else name
            for name, version in requirements.items()
        ]


def check_large_pex(allow_large_pex: bool, pex_file: str) -> None:
    if allow_large_pex:
        return

    max_pex_size_gb = 2 if Version(pkg_version('pex')) < Version("2.41.1") else 4
    if os.path.getsize(pex_file) > max_pex_size_gb * 1024 * 1024 * 1024:
        raise PexTooLargeError(
            f"The generate pex is larger than {max_pex_size_gb}Gb and won't be executable"
            " by python; Please set the 'allow_large_pex' flag in upload_env"
        )


def pack_spec_in_pex(
    spec_file: str,
    output: str,
    pex_inherit_path: str = "fallback",
    allow_large_pex: bool = False,
    include_pex_tools: bool = False,
    additional_repo: Optional[Union[List[str], str]] = None,
    additional_indexes: Optional[List[str]] = None,
) -> str:
    with open(spec_file, "r") as f:
        lines = [
            line for line in f.read().splitlines() if line and not line.startswith("#")
        ]
        _logger.debug(f"used requirements: {lines}")
        return pack_in_pex(
            lines,
            output,
            pex_inherit_path=pex_inherit_path,
            allow_large_pex=allow_large_pex,
            include_pex_tools=include_pex_tools,
            additional_repo=additional_repo,
            additional_indexes=additional_indexes,
        )


def pack_in_pex(
    requirements: List[str],
    output: str,
    ignored_packages: Collection[str] = [],
    pex_inherit_path: str = "fallback",
    editable_requirements: Dict[str, str] = {},
    allow_large_pex: bool = False,
    include_pex_tools: bool = False,
    additional_repo: Optional[Union[str, List[str]]] = None,
    additional_indexes: Optional[List[str]] = None,
) -> str:
    """Pack current environment using a pex.

    :param additional_repo: an additional pypi repo if one was used env creation
    :param requirements: list of requirements (ex {'tensorflow': '1.15.0'})
    :param output: location of the pex
    :param ignored_packages: packages to be exluded from pex
    :param pex_inherit_path: see https://github.com/pantsbuild/pex/blob/master/pex/bin/pex.py#L264,
                             possible values ['false', 'fallback', 'prefer']
    :param allow_large_pex: Creates a non-executable pex that will need to be unzipped to circumvent
                            python's limitation with zips > 2Gb. The file will need to be unzipped
                            and the entry point will be <output>/__main__.py
    :return: destination of the archive, name of the pex
    """

    with tempfile.TemporaryDirectory() as tempdir:
        cmd = ["pex", f"--inherit-path={pex_inherit_path}"]

        if allow_large_pex:
            cmd.extend(["--layout", "packed"])
            tmp_ext = ".tmp"
        else:
            tmp_ext = ""
        if include_pex_tools:
            cmd.extend(["--include-tools"])

        if editable_requirements and len(editable_requirements) > 0:
            for current_package in editable_requirements.values():
                _logger.debug("Add current path as source", current_package)
                shutil.copytree(
                    current_package,
                    os.path.join(tempdir, os.path.basename(current_package)),
                )
            cmd.append(f"--sources-directory={tempdir}")

        for req in requirements:
            pkg_name = req.split("=")[0]
            if pkg_name in ignored_packages:
                _logger.debug(f"Ignore requirement {req}")
            else:
                _logger.debug(f"Add requirement {req}")
                cmd.append(req)
        if _is_criteo():
            cmd.append(f"--index-url={CRITEO_PYPI_URL}")

        if additional_repo is not None:
            additional_repo = (
                additional_repo
                if isinstance(additional_repo, list)
                else [additional_repo]
            )
            for repo in additional_repo:
                cmd.append(f"--index-url={repo}")

        if additional_indexes:
            for index in additional_indexes:
                cmd.extend(["-f", index])

        cmd.extend(["-o", output + tmp_ext])

        try:
            print(f"Running command: {' '.join(cmd)}")
            call = subprocess.run(cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
            call.check_returncode()

        except CalledProcessError as err:
            _logger.exception("Cannot create pex")
            _logger.exception(err.stderr.decode("ascii"))
            raise PexCreationError(err.stderr.decode("ascii"))

        check_large_pex(allow_large_pex, output + tmp_ext)

        if allow_large_pex:
            shutil.make_archive(output, "zip", output + tmp_ext)

    return output + ".zip" if allow_large_pex else output


def _get_packages(
    editable: bool, executable: str = sys.executable
) -> List[JsonDictType]:
    editable_mode = "-e" if editable else "--exclude-editable"
    # We only keep the first line because pip warnings on subsequent lines can cause
    # JSONDecodeError below
    results = (
        subprocess.check_output(
            [
                f"{executable}",
                "-m",
                "pip",
                "list",
                "-l",
                f"{editable_mode}",
                "--format",
                "json",
                "-v",
            ]
        )
        .decode()
        .split("\n")[0]
    )

    _logger.debug(f"'pip list' with editable={editable} results:" + results)

    try:
        return json.loads(results)
    except json.JSONDecodeError as e:
        _logger.error(
            f"Caught below exception while parsing output of pip list: {results}"
        )
        raise e


class Packer(object):
    def env_name(self) -> str:
        raise NotImplementedError

    def extension(self) -> str:
        raise NotImplementedError

    def pack(
        self,
        output: str,
        reqs: List[str],
        additional_packages: Dict[str, str],
        ignored_packages: Collection[str],
        editable_requirements: Dict[str, str],
        allow_large_pex: bool = False,
        include_pex_tools: bool = False,
        additional_repo: Optional[Union[str, List[str]]] = None,
        additional_indexes: Optional[List[str]] = None,
    ) -> str:
        raise NotImplementedError

    def pack_from_spec(
        self,
        spec_file: str,
        output: str,
        allow_large_pex: bool = False,
        include_pex_tools: bool = False,
    ) -> str:
        raise NotImplementedError


def get_env_name(env_var_name: str) -> str:
    """
    Return default virtual env
    """
    virtual_env_path = os.environ.get(env_var_name)
    if not virtual_env_path:
        return "default"
    else:
        return os.path.basename(virtual_env_path)


class PexPacker(Packer):
    def env_name(self) -> str:
        return get_env_name("VIRTUAL_ENV")

    def extension(self) -> str:
        return "pex"

    def pack(
        self,
        output: str,
        reqs: List[str],
        additional_packages: Dict[str, str],
        ignored_packages: Collection[str],
        editable_requirements: Dict[str, str],
        allow_large_pex: bool = False,
        include_pex_tools: bool = False,
        additional_repo: Optional[Union[str, List[str]]] = None,
        additional_indexes: Optional[List[str]] = None,
    ) -> str:
        return pack_in_pex(
            reqs,
            output,
            ignored_packages,
            editable_requirements=editable_requirements,
            allow_large_pex=allow_large_pex,
            include_pex_tools=include_pex_tools,
            additional_repo=additional_repo,
            additional_indexes=additional_indexes,
        )

    def pack_from_spec(
        self,
        spec_file: str,
        output: str,
        allow_large_pex: bool = False,
        include_pex_tools: bool = False,
    ) -> str:
        return pack_spec_in_pex(
            spec_file=spec_file,
            output=output,
            allow_large_pex=allow_large_pex,
            include_pex_tools=include_pex_tools,
        )


PEX_PACKER = PexPacker()


def _get_editable_requirements(executable: str = sys.executable) -> List[str]:
    top_level_pkgs = []
    for pkg in _get_packages(True, executable):
        location = pkg.get("editable_project_location", pkg.get("location", ""))
        packages_found = set(
            setuptools.find_packages(location)
            + setuptools.find_packages(f"{location}/src")
        )
        for _pkg in packages_found:
            if "." in _pkg:
                continue
            imported = __import__(_pkg)
            if imported.__file__:
                top_level_pkgs.append(os.path.dirname(imported.__file__))
    return top_level_pkgs


def get_non_editable_requirements(executable: str = sys.executable) -> Dict[str, str]:
    return {
        package["name"]: package["version"]
        for package in _get_packages(False, executable)
    }


def _build_package_path(name: str, extension: Optional[str]) -> str:
    path = f"{get_default_fs()}/user/{_get_current_user()}/envs/{name}"
    if extension is None:
        return path
    return f"{path}.{extension}"


def detect_archive_names(
    packer: Packer, package_path: str = None, allow_large_pex: bool = None
) -> Tuple[str, str, str]:
    if _running_from_pex():
        pex_file = get_current_pex_filepath()
        env_name = os.path.splitext(os.path.basename(pex_file))[0]
    else:
        pex_file = ""
        env_name = packer.env_name()
    extension = packer.extension()

    if not package_path:
        package_path = _build_package_path(env_name, extension)
    else:
        if "".join(os.path.splitext(package_path)[1]) != f".{extension}":
            raise ValueError(
                f"{package_path} has the wrong extension"
                f", .{packer.extension()} is expected"
            )

    # we are actually building or reusing a large pex and we have the information from the
    # allow_large_pex flag
    if (
        extension == PEX_PACKER.extension()
        and allow_large_pex
        and not package_path.endswith(".zip")
    ):
        package_path += ".zip"

    # We are running from an unzipped large pex and we have the information because `pex_file` is
    # not empty, and it is a directory instead of a zipapp
    if pex_file != "" and os.path.isdir(pex_file) and not package_path.endswith(".zip"):
        zip_pex_file = resolve_zip_from_pex_dir(pex_file)
        package_path = _build_package_path(os.path.basename(zip_pex_file), None)

    return package_path, env_name, pex_file


def resolve_zip_from_pex_dir(pex_dir: str) -> str:
    parent_dir = os.path.dirname(pex_dir)
    pex_files = glob.glob(f"{parent_dir}/*.pex.zip")
    if len(pex_files) == 1:
        return pex_files[0]

    pex_file = next((x for x in pex_files if pex_dir == x.split(".zip")[0]), None)
    if pex_file is None:
        raise ValueError(f"{pex_dir}.zip not found, found {pex_files}")

    return pex_file


def detect_packer_from_spec(spec_file: str) -> Packer:
    if os.path.basename(spec_file) == "requirements.txt":
        return PEX_PACKER
    else:
        raise ValueError(
            f"Archive format {spec_file} unsupported. Must be requirements.txt"
        )


def detect_packer_from_env() -> Packer:
    return PEX_PACKER


def detect_packer_from_file(zip_file: str) -> Packer:
    if zip_file.endswith(".pex") or zip_file.endswith(".pex.zip"):
        return PEX_PACKER
    else:
        raise ValueError(f"Archive format {zip_file} unsupported. Must be .pex")


def get_current_pex_filepath() -> str:
    """
    If we run from a pex, returns the path
    """
    # Env variable PEX has been introduced in pex==2.1.54 and is now the
    # preferred way to detect whether we run from within a pex
    if "PEX" in os.environ:
        return os.environ["PEX"]

    # We still temporarilly support the previous way
    try:
        import _pex

        return os.path.abspath(
            os.path.dirname(os.path.dirname(os.path.dirname(_pex.__file__)))
        )
    except ModuleNotFoundError:
        raise RuntimeError(
            "Trying to get current pex file path while not running from PEX"
        )


def get_editable_requirements(
    executable: str = sys.executable,
    editable_packages_dir: str = os.getcwd(),  # only overridden for tests
) -> Dict[str, str]:
    editable_requirements: Dict[str, str] = {}
    if _running_from_pex():
        try:
            package_names = (
                open(f"{editable_packages_dir}/{EDITABLE_PACKAGES_INDEX}")
                .read()
                .splitlines()
            )
        except FileNotFoundError:
            editable_requirements = {}
        else:
            for package_name in package_names:
                try:
                    spec = importlib.util.find_spec(package_name)
                    if spec is None or spec.origin is None:
                        raise ModuleNotFoundError(f"No module named '{package_name}'")
                    path = os.path.dirname(spec.origin)
                    editable_requirements[os.path.basename(path)] = path
                except ModuleNotFoundError:
                    _logger.error(
                        f"Could not import package {package_name}"
                        f" repo exists={os.path.exists(package_name)}"
                    )
    else:
        editable_requirements = {
            os.path.basename(requirement_dir): requirement_dir
            for requirement_dir in _get_editable_requirements(executable)
        }

    _logger.info(f"found editable requirements {editable_requirements}")
    return editable_requirements


def get_pyenv_usage_from_archive(path_to_archive: str) -> PythonEnvDescription:
    archive_filename = os.path.basename(path_to_archive)

    if archive_filename.endswith(".pex.zip"):
        return PythonEnvDescription(
            path_to_archive, LARGE_PEX_CMD, UNPACKED_ENV_NAME, True
        )
    elif archive_filename.endswith(".pex"):
        return PythonEnvDescription(
            path_to_archive, f"./{archive_filename}", archive_filename, False
        )
    else:
        raise ValueError(
            f"Archive format {archive_filename} unsupported. Must be .pex/pex.zip"
        )


def get_default_fs() -> str:
    return (
        subprocess.check_output("hdfs getconf -confKey fs.defaultFS".split())
        .strip()
        .decode()
    )


def _running_from_pex() -> bool:
    # Env variable PEX has been introduced in pex==2.1.54 and is now the
    # preferred way to detect whether we run from within a pex
    if "PEX" in os.environ:
        return True

    # We still temporarilly support the previous way
    try:
        import _pex

        return True
    except ModuleNotFoundError:
        return False


def _is_criteo() -> bool:
    return "CRITEO_ENV" in os.environ
