# Clusterra CLI

Command Line Interface for interacting with the Clusterra API.

## Installation

```bash
pip install -e .
```

## Usage

```bash
clusterra configure
clusterra clusters list
```
