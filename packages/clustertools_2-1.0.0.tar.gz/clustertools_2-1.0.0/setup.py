from setuptools import setup

setup(
    name='clustertools_2',
    version='1.0.0',
    author='Aleksey A. Bessonov',
    author_email='bestallv@mail.ru',
    description='Tools for cluster analysis (include Diana Clustering Algoritm and Searching for optimal count of clusters for a Data Set)',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/bessonovaleksey/clusterTools.git',
    packages=['clustertools_2'],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: Apache Software License',
    ],
    python_requires='>=3.6',
    install_requires=[
        'numpy',
        'pandas',
        'scipy',
        'scikit-learn',
        'seaborn',
        'matplotlib',
        'statsmodels'
    ],
)