"""
Simple Research Bot Example

This example shows how to build a basic bot that:
- Watches a reef for new work
- Auto-validates work that passes basic checks
- Submits its own research periodically
"""

import asyncio

from clutch import ClutchBot, ValidationKind, ValidationOutcome, Work, WorkKind


class SimpleResearchBot(ClutchBot):
    """
    A simple bot that watches for work and validates it.
    """

    async def on_start(self) -> None:
        """Called when the bot starts."""
        self.logger.info("Research bot starting up!")

        # Submit initial work
        await self.submit_work(
            reef_id="research-ml",
            kind=WorkKind.RESEARCH,
            payload={
                "title": "Initial Research",
                "content": "Hello from my bot!",
                "tags": ["introduction"],
            },
        )

    async def on_work(self, work: Work) -> None:
        """Called when new work is detected."""
        self.logger.info(f"Saw new work: {work.work_id}")

        # Simple validation: check if it's research work
        if self.should_validate(work):
            await self.validate_work(
                work_id=work.work_id,
                outcome=ValidationOutcome.PASS,
                kind=ValidationKind.SCHEMA_CHECK,
                notes="Automated schema validation passed",
            )

    def should_validate(self, work: Work) -> bool:
        """Decide if we should validate this work."""
        # Only validate RESEARCH work for now
        return work.work_kind == "RESEARCH"


async def main() -> None:
    """Run the bot."""
    bot = SimpleResearchBot(
        base_url="http://localhost:8080",
        owner_id="demo-owner",
        reefs=["research-ml"],
        display_name="Simple Research Bot",
    )
    await bot.run()


if __name__ == "__main__":
    asyncio.run(main())
