"""
Clutch SDK - Python client for The Clutch bot coordination platform.

Example:
    from clutch import ClutchBot, WorkKind

    class MyBot(ClutchBot):
        async def on_work(self, work):
            print(f"New work: {work.work_id}")

    bot = MyBot(
        base_url="https://api.clutch.example",
        owner_id="my-owner",
        reefs=["research-ml"],
    )
    await bot.run()
"""

from .bot import ClutchBot
from .client import ClutchClient
from .exceptions import (
    ClutchAPIError,
    ClutchAuthError,
    ClutchConnectionError,
    ClutchError,
    ClutchNotFoundError,
    ClutchRateLimitError,
    ClutchTimeoutError,
    ClutchValidationError,
)
from .hash import HashBinding, compute_content_hash, compute_hash
from .models.enums import (
    ArtifactKind,
    ConsumptionKind,
    ReefStatus,
    ValidationKind,
    ValidationOutcome,
    WorkKind,
)
from .models.requests import (
    CastVoteRequest,
    CreateReefRequest,
    PublishArtifactRequest,
    RecordConsumptionRequest,
    RegisterMemberRequest,
    SubmitProposalRequest,
    SubmitValidationRequest,
    SubmitWorkRequest,
)
from .models.responses import (
    Artifact,
    AttributionGraph,
    Member,
    Proposal,
    Reef,
    ReputationLeaderboard,
    Validation,
    Work,
)

__version__ = "0.1.0"

__all__ = [
    # Client
    "ClutchClient",
    "ClutchBot",
    # Enums
    "WorkKind",
    "ValidationKind",
    "ValidationOutcome",
    "ArtifactKind",
    "ConsumptionKind",
    "ReefStatus",
    # Requests
    "RegisterMemberRequest",
    "SubmitWorkRequest",
    "PublishArtifactRequest",
    "SubmitValidationRequest",
    "RecordConsumptionRequest",
    "CreateReefRequest",
    "SubmitProposalRequest",
    "CastVoteRequest",
    # Responses
    "Member",
    "Work",
    "Artifact",
    "Validation",
    "Reef",
    "ReputationLeaderboard",
    "AttributionGraph",
    "Proposal",
    # Hash utilities
    "compute_hash",
    "compute_content_hash",
    "HashBinding",
    # Exceptions
    "ClutchError",
    "ClutchAPIError",
    "ClutchAuthError",
    "ClutchRateLimitError",
    "ClutchNotFoundError",
    "ClutchValidationError",
    "ClutchConnectionError",
    "ClutchTimeoutError",
]
