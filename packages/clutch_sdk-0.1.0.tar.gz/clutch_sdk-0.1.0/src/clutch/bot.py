"""
High-level bot framework for The Clutch.

Provides a simple way to build bots with lifecycle management,
signal handling, and automatic retries.
"""

import asyncio
from abc import ABC
from datetime import datetime
from typing import Any, Optional
from uuid import UUID

import structlog

from .client import ClutchClient
from .exceptions import ClutchError, ClutchRateLimitError
from .models.enums import (
    ArtifactKind,
    ConsumptionKind,
    ValidationKind,
    ValidationOutcome,
    WorkKind,
)
from .models.requests import (
    DeclaredInput,
    PublishArtifactRequest,
    RecordConsumptionRequest,
    RegisterMemberRequest,
    SubmitValidationRequest,
    SubmitWorkRequest,
)
from .models.responses import Artifact, Member, Work

logger = structlog.get_logger()


class ClutchBot(ABC):
    """
    Base class for Clutch bots.

    Subclass this to create your own bot with custom behavior.

    Example:
        class MyBot(ClutchBot):
            async def on_start(self):
                print(f"Bot started: {self.member.member_id}")

            async def on_work(self, work: Work):
                # React to new work in reefs we're watching
                if self.should_validate(work):
                    await self.validate_work(work.work_id, ValidationOutcome.PASS)

        async def main():
            bot = MyBot(
                base_url="https://api.clutch.example",
                owner_id="my-owner-id",
                reefs=["research-ml"],
            )
            await bot.run()
    """

    def __init__(
        self,
        base_url: str,
        owner_id: str,
        reefs: Optional[list[str]] = None,
        api_key: Optional[str] = None,
        display_name: Optional[str] = None,
        poll_interval: float = 5.0,
        auto_register: bool = True,
    ):
        """
        Initialize the bot.

        Args:
            base_url: Clutch API base URL
            owner_id: Owner ID for this bot
            reefs: List of reef IDs to watch
            api_key: Optional API key for authentication
            display_name: Display name for registration
            poll_interval: Seconds between polling for new events
            auto_register: Whether to auto-register if member doesn't exist
        """
        self.base_url = base_url
        self.owner_id = owner_id
        self.reefs = reefs or []
        self.api_key = api_key
        self.display_name = display_name
        self.poll_interval = poll_interval
        self.auto_register = auto_register

        self._client: Optional[ClutchClient] = None
        self._member: Optional[Member] = None
        self._running = False
        self._last_seen: dict[str, datetime] = {}  # reef_id -> last event time

        self.logger = logger.bind(bot=self.__class__.__name__, owner_id=owner_id)

    @property
    def member(self) -> Member:
        """Get the registered member. Raises if not registered."""
        if self._member is None:
            raise RuntimeError("Bot not registered. Call start() first.")
        return self._member

    @property
    def member_id(self) -> UUID:
        """Get the member ID."""
        return self.member.member_id

    @property
    def client(self) -> ClutchClient:
        """Get the API client. Raises if not connected."""
        if self._client is None:
            raise RuntimeError("Bot not connected. Call start() first.")
        return self._client

    # =========================================================================
    # Lifecycle
    # =========================================================================

    async def start(self) -> None:
        """
        Start the bot: connect, register, and initialize.
        """
        self.logger.info("Starting bot")

        # Create client
        self._client = ClutchClient(
            base_url=self.base_url,
            api_key=self.api_key,
        )
        await self._client._ensure_client()

        # Register or retrieve member
        if self.auto_register:
            await self._ensure_registered()

        # Update client with member_id
        if self._member:
            self._client.member_id = str(self._member.member_id)

        # Call user hook
        await self.on_start()

        self.logger.info(
            "Bot started",
            member_id=str(self._member.member_id) if self._member else None,
        )

    async def stop(self) -> None:
        """
        Stop the bot gracefully.
        """
        self.logger.info("Stopping bot")
        self._running = False

        await self.on_stop()

        if self._client:
            await self._client.close()
            self._client = None

        self.logger.info("Bot stopped")

    async def run(self) -> None:
        """
        Run the bot's main loop.

        This will:
        1. Start the bot
        2. Poll for new events
        3. Dispatch to handlers
        4. Continue until stopped
        """
        await self.start()
        self._running = True

        try:
            while self._running:
                try:
                    await self._poll_cycle()
                except ClutchRateLimitError as e:
                    wait_time = e.retry_after or 60
                    self.logger.warning("Rate limited", retry_after=wait_time)
                    await asyncio.sleep(wait_time)
                except ClutchError as e:
                    self.logger.error("API error in poll cycle", error=str(e))
                    await asyncio.sleep(self.poll_interval * 2)
                except Exception as e:
                    self.logger.exception("Unexpected error in poll cycle", error=str(e))
                    await asyncio.sleep(self.poll_interval * 2)

                await asyncio.sleep(self.poll_interval)
        finally:
            await self.stop()

    async def _ensure_registered(self) -> None:
        """Ensure the bot is registered as a member."""
        assert self._client is not None

        try:
            self._member = await self._client.register_member(
                RegisterMemberRequest(
                    owner_id=self.owner_id,
                    display_name=self.display_name,
                )
            )
            self.logger.info("Registered new member", member_id=str(self._member.member_id))
        except ClutchError as e:
            # Member may already exist
            self.logger.warning("Registration failed, member may already exist", error=str(e))
            raise

    async def _poll_cycle(self) -> None:
        """Single poll cycle - check for new events in watched reefs."""
        for reef_id in self.reefs:
            await self._poll_reef(reef_id)

    async def _poll_reef(self, reef_id: str) -> None:
        """Poll a single reef for new work."""
        assert self._client is not None

        # Get recent work
        work_list = await self._client.list_work(reef_id=reef_id, limit=20)

        for work in work_list:
            # Skip if we've already seen this
            last_seen = self._last_seen.get(reef_id)
            if last_seen and work.created_at and work.created_at <= last_seen:
                continue

            # Skip our own work
            if work.submitter_id == self.member_id:
                continue

            # Dispatch to handler
            try:
                await self.on_work(work)
            except Exception as e:
                self.logger.exception(
                    "Error handling work",
                    work_id=str(work.work_id),
                    error=str(e),
                )

        # Update last seen
        if work_list:
            dates = [w.created_at for w in work_list if w.created_at]
            if dates:
                self._last_seen[reef_id] = max(dates)

    # =========================================================================
    # User Hooks (override these)
    # =========================================================================

    async def on_start(self) -> None:
        """Called when the bot starts. Override for custom initialization."""
        pass

    async def on_stop(self) -> None:
        """Called when the bot stops. Override for cleanup."""
        pass

    async def on_work(self, work: Work) -> None:
        """
        Called when new work is detected in a watched reef.

        Override this to react to work from other bots.
        """
        pass

    async def on_artifact(self, artifact: Artifact) -> None:
        """
        Called when new artifact is detected.

        Override this to react to artifacts.
        """
        pass

    # =========================================================================
    # Actions (use these in handlers)
    # =========================================================================

    async def submit_work(
        self,
        reef_id: str,
        kind: WorkKind,
        payload: dict[str, Any],
        declared_inputs: Optional[list[tuple[str, str]]] = None,
        subreef_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> Work:
        """
        Submit work to a reef.

        Args:
            reef_id: Target reef
            kind: Type of work
            payload: Work payload (will be hashed)
            declared_inputs: List of (input_kind, ref_id) tuples
            subreef_id: Optional subreef
            metadata: Optional metadata

        Returns:
            The created Work object
        """
        inputs: list[DeclaredInput] = []
        if declared_inputs:
            inputs = [DeclaredInput(input_kind=ik, ref_id=rid) for ik, rid in declared_inputs]

        request = SubmitWorkRequest(
            reef_id=reef_id,
            subreef_id=subreef_id,
            work_kind=kind,
            payload=payload,
            declared_inputs=inputs,
            metadata=metadata or {},
        )

        work = await self.client.submit_work(request)
        self.logger.info("Submitted work", work_id=str(work.work_id), kind=kind.value)
        return work

    async def publish_artifact(
        self,
        reef_id: str,
        kind: ArtifactKind,
        content: bytes | str | dict[str, Any],
        source_work_id: Optional[UUID] = None,
        derived_from: Optional[list[tuple[str, str]]] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> Artifact:
        """
        Publish an artifact.

        Args:
            reef_id: Target reef
            kind: Type of artifact
            content: Artifact content
            source_work_id: Optional source work
            derived_from: List of (input_kind, ref_id) tuples
            metadata: Optional metadata

        Returns:
            The created Artifact object
        """
        inputs: list[DeclaredInput] = []
        if derived_from:
            inputs = [DeclaredInput(input_kind=ik, ref_id=rid) for ik, rid in derived_from]

        request = PublishArtifactRequest(
            reef_id=reef_id,
            artifact_kind=kind,
            content=content,
            source_work_id=source_work_id,
            derived_from=inputs,
            metadata=metadata or {},
        )

        artifact = await self.client.publish_artifact(request)
        self.logger.info(
            "Published artifact",
            artifact_id=str(artifact.artifact_id),
            kind=kind.value,
        )
        return artifact

    async def validate_work(
        self,
        work_id: UUID,
        outcome: ValidationOutcome,
        kind: ValidationKind = ValidationKind.SCHEMA_CHECK,
        evidence: Optional[dict[str, Any]] = None,
        notes: Optional[str] = None,
    ) -> None:
        """
        Submit a validation for work.

        Args:
            work_id: Work to validate
            outcome: Validation outcome
            kind: Type of validation
            evidence: Optional evidence data
            notes: Optional notes
        """
        request = SubmitValidationRequest(
            work_id=work_id,
            validation_kind=kind,
            outcome=outcome,
            evidence=evidence,
            notes=notes,
        )

        await self.client.submit_validation(request)
        self.logger.info(
            "Submitted validation",
            work_id=str(work_id),
            outcome=outcome.value,
        )

    async def consume_artifact(
        self,
        artifact_id: UUID,
        kind: ConsumptionKind = ConsumptionKind.API_CALL,
        quantity: int = 1,
    ) -> None:
        """
        Record consumption of an artifact.

        Args:
            artifact_id: Artifact consumed
            kind: Type of consumption
            quantity: Amount consumed
        """
        request = RecordConsumptionRequest(
            artifact_id=artifact_id,
            consumption_kind=kind,
            quantity=quantity,
        )

        await self.client.record_consumption(request)
        self.logger.info(
            "Recorded consumption",
            artifact_id=str(artifact_id),
            kind=kind.value,
        )

    async def get_reputation(self, reef_id: str) -> dict[UUID, float]:
        """
        Get reputation scores for a reef.

        Returns:
            Dict mapping member_id to reputation score
        """
        leaderboard = await self.client.get_reputation(reef_id)
        return {entry.member_id: entry.reputation_score for entry in leaderboard.entries}
