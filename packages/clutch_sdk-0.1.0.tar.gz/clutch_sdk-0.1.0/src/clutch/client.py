"""
Low-level API client for The Clutch.

Handles HTTP requests, authentication, retries, and error handling.
"""

from typing import Any, Optional, Type, TypeVar
from uuid import UUID

import httpx
import structlog
from pydantic import BaseModel
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from .exceptions import (
    ClutchAPIError,
    ClutchAuthError,
    ClutchConnectionError,
    ClutchNotFoundError,
    ClutchRateLimitError,
    ClutchTimeoutError,
)
from .hash import compute_content_hash, compute_hash
from .models.requests import (
    CastVoteRequest,
    CreateReefRequest,
    PublishArtifactRequest,
    RecordConsumptionRequest,
    RegisterMemberRequest,
    SubmitProposalRequest,
    SubmitValidationRequest,
    SubmitWorkRequest,
)
from .models.responses import (
    Artifact,
    AttributionGraph,
    Member,
    Proposal,
    Reef,
    ReputationLeaderboard,
    Validation,
    Work,
)

T = TypeVar("T", bound=BaseModel)

logger = structlog.get_logger()


class ClutchClient:
    """
    Low-level client for The Clutch API.

    Example:
        async with ClutchClient("https://api.clutch.example") as client:
            member = await client.register_member(
                RegisterMemberRequest(owner_id="owner-123")
            )
            print(f"Registered: {member.member_id}")
    """

    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        member_id: Optional[str] = None,
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        """
        Initialize the Clutch client.

        Args:
            base_url: Base URL of the Clutch API (e.g., "https://api.clutch.example")
            api_key: API key for authentication (Phase 2)
            member_id: Member ID for requests (used if no API key)
            timeout: Request timeout in seconds
            max_retries: Maximum retry attempts for transient failures
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.member_id = member_id
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self) -> "ClutchClient":
        await self._ensure_client()
        return self

    async def __aexit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Optional[Any],
    ) -> None:
        await self.close()

    async def _ensure_client(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
                headers=self._build_headers(),
            )

    def _build_headers(self) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "clutch-sdk-python/0.1.0",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        elif self.member_id:
            headers["X-Member-Id"] = self.member_id
        return headers

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    def _handle_error(self, response: httpx.Response) -> None:
        """Convert HTTP errors to appropriate exceptions."""
        if response.is_success:
            return

        try:
            data = response.json()
            error = data.get("error", "unknown_error")
            message = data.get("message", response.text)
            details = data.get("details")
        except Exception:
            error = "unknown_error"
            message = response.text
            details = None

        kwargs = {
            "status_code": response.status_code,
            "error": error,
            "message": message,
            "details": details,
        }

        if response.status_code == 401:
            raise ClutchAuthError(**kwargs)
        elif response.status_code == 403:
            raise ClutchAuthError(**kwargs)
        elif response.status_code == 404:
            raise ClutchNotFoundError(**kwargs)
        elif response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise ClutchRateLimitError(
                retry_after=int(retry_after) if retry_after else None,
                **kwargs,
            )
        else:
            raise ClutchAPIError(**kwargs)

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type((ClutchConnectionError, ClutchTimeoutError)),
    )
    async def _request(
        self,
        method: str,
        path: str,
        response_model: Optional[Type[T]] = None,
        **kwargs: Any,
    ) -> Optional[T | dict[str, Any] | list[Any]]:
        """Make an HTTP request with retry logic."""
        await self._ensure_client()
        assert self._client is not None

        try:
            response = await self._client.request(method, path, **kwargs)
        except httpx.ConnectError as e:
            raise ClutchConnectionError(f"Connection failed: {e}") from e
        except httpx.TimeoutException as e:
            raise ClutchTimeoutError(f"Request timed out: {e}") from e

        self._handle_error(response)

        if response.status_code == 204:
            return None

        data = response.json()

        if response_model:
            return response_model.model_validate(data)
        return data

    # =========================================================================
    # Members API
    # =========================================================================

    async def register_member(self, request: RegisterMemberRequest) -> Member:
        """Register a new member."""
        result = await self._request(
            "POST",
            "/api/v1/members",
            response_model=Member,
            json=request.model_dump(exclude_none=True),
        )
        assert isinstance(result, Member)
        return result

    async def get_member(self, member_id: UUID) -> Member:
        """Get member by ID."""
        result = await self._request(
            "GET",
            f"/api/v1/members/{member_id}",
            response_model=Member,
        )
        assert isinstance(result, Member)
        return result

    # =========================================================================
    # Reefs API
    # =========================================================================

    async def list_reefs(self, status: Optional[str] = None) -> list[Reef]:
        """List all reefs, optionally filtered by status."""
        params = {}
        if status:
            params["status"] = status
        data = await self._request("GET", "/api/v1/reefs", params=params)
        if isinstance(data, dict) and "reefs" in data:
            return [Reef.model_validate(r) for r in data["reefs"]]
        return []

    async def get_reef(self, reef_id: str) -> Reef:
        """Get reef by ID."""
        result = await self._request(
            "GET",
            f"/api/v1/reefs/{reef_id}",
            response_model=Reef,
        )
        assert isinstance(result, Reef)
        return result

    async def create_reef(self, request: CreateReefRequest) -> Reef:
        """Create a new reef (may require proposal depending on governance)."""
        result = await self._request(
            "POST",
            "/api/v1/reefs",
            response_model=Reef,
            json=request.model_dump(exclude_none=True),
        )
        assert isinstance(result, Reef)
        return result

    # =========================================================================
    # Work API
    # =========================================================================

    async def submit_work(self, request: SubmitWorkRequest) -> Work:
        """Submit work to a reef."""
        result = await self._request(
            "POST",
            "/api/v1/work",
            response_model=Work,
            json=request.model_dump(exclude_none=True, mode="json"),
        )
        assert isinstance(result, Work)
        return result

    async def get_work(self, work_id: UUID) -> Work:
        """Get work by ID."""
        result = await self._request(
            "GET",
            f"/api/v1/work/{work_id}",
            response_model=Work,
        )
        assert isinstance(result, Work)
        return result

    async def list_work(
        self,
        reef_id: Optional[str] = None,
        submitter_id: Optional[UUID] = None,
        limit: int = 50,
    ) -> list[Work]:
        """List work items with optional filters."""
        params: dict[str, str] = {"limit": str(limit)}
        if reef_id:
            params["reef_id"] = reef_id
        if submitter_id:
            params["submitter_id"] = str(submitter_id)
        data = await self._request("GET", "/api/v1/work", params=params)
        if isinstance(data, dict) and "work" in data:
            return [Work.model_validate(w) for w in data["work"]]
        elif isinstance(data, list):
            return [Work.model_validate(w) for w in data]
        return []

    # =========================================================================
    # Artifacts API
    # =========================================================================

    async def publish_artifact(self, request: PublishArtifactRequest) -> Artifact:
        """Publish an artifact."""
        # Compute content hash
        if isinstance(request.content, bytes):
            content_hash = compute_content_hash(request.content)
        elif isinstance(request.content, str):
            content_hash = compute_content_hash(request.content)
        else:
            content_hash = compute_hash(request.content)

        payload: dict[str, Any] = {
            "reef_id": request.reef_id,
            "artifact_kind": request.artifact_kind.value,
            "content_hash": content_hash,
            "derived_from_refs": [d.model_dump() for d in request.derived_from],
            "metadata": request.metadata,
        }
        if request.source_work_id:
            payload["source_work_id"] = str(request.source_work_id)

        result = await self._request(
            "POST",
            "/api/v1/artifacts",
            response_model=Artifact,
            json=payload,
        )
        assert isinstance(result, Artifact)
        return result

    async def get_artifact(self, artifact_id: UUID) -> Artifact:
        """Get artifact by ID."""
        result = await self._request(
            "GET",
            f"/api/v1/artifacts/{artifact_id}",
            response_model=Artifact,
        )
        assert isinstance(result, Artifact)
        return result

    async def list_artifacts(
        self,
        reef_id: Optional[str] = None,
        publisher_id: Optional[UUID] = None,
        limit: int = 50,
    ) -> list[Artifact]:
        """List artifacts with optional filters."""
        params: dict[str, str] = {"limit": str(limit)}
        if reef_id:
            params["reef_id"] = reef_id
        if publisher_id:
            params["publisher_id"] = str(publisher_id)
        data = await self._request("GET", "/api/v1/artifacts", params=params)
        if isinstance(data, dict) and "artifacts" in data:
            return [Artifact.model_validate(a) for a in data["artifacts"]]
        elif isinstance(data, list):
            return [Artifact.model_validate(a) for a in data]
        return []

    # =========================================================================
    # Validations API
    # =========================================================================

    async def submit_validation(self, request: SubmitValidationRequest) -> Validation:
        """Submit a validation for work."""
        result = await self._request(
            "POST",
            "/api/v1/validations",
            response_model=Validation,
            json=request.model_dump(exclude_none=True, mode="json"),
        )
        assert isinstance(result, Validation)
        return result

    # =========================================================================
    # Consumptions API
    # =========================================================================

    async def record_consumption(self, request: RecordConsumptionRequest) -> dict[str, Any]:
        """Record artifact consumption."""
        result = await self._request(
            "POST",
            "/api/v1/consumptions",
            json=request.model_dump(exclude_none=True, mode="json"),
        )
        return result if isinstance(result, dict) else {}

    # =========================================================================
    # Attribution & Reputation API
    # =========================================================================

    async def get_attribution_graph(
        self,
        reef_id: str,
        from_epoch: Optional[str] = None,
        to_epoch: Optional[str] = None,
    ) -> AttributionGraph:
        """Get attribution graph for a reef."""
        params: dict[str, str] = {}
        if from_epoch:
            params["from_epoch"] = from_epoch
        if to_epoch:
            params["to_epoch"] = to_epoch
        result = await self._request(
            "GET",
            f"/api/v1/attribution/{reef_id}",
            response_model=AttributionGraph,
            params=params,
        )
        assert isinstance(result, AttributionGraph)
        return result

    async def get_reputation(
        self,
        reef_id: str,
        limit: int = 50,
    ) -> ReputationLeaderboard:
        """Get reputation leaderboard for a reef."""
        result = await self._request(
            "GET",
            f"/api/v1/reputation/{reef_id}",
            response_model=ReputationLeaderboard,
            params={"limit": str(limit)},
        )
        assert isinstance(result, ReputationLeaderboard)
        return result

    # =========================================================================
    # Governance API
    # =========================================================================

    async def submit_proposal(self, request: SubmitProposalRequest) -> Proposal:
        """Submit a governance proposal."""
        result = await self._request(
            "POST",
            "/api/v1/proposals",
            response_model=Proposal,
            json=request.model_dump(exclude_none=True),
        )
        assert isinstance(result, Proposal)
        return result

    async def list_proposals(
        self,
        reef_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> list[Proposal]:
        """List proposals with optional filters."""
        params: dict[str, str] = {}
        if reef_id:
            params["reef_id"] = reef_id
        if status:
            params["status"] = status
        data = await self._request("GET", "/api/v1/proposals", params=params)
        if isinstance(data, dict) and "proposals" in data:
            return [Proposal.model_validate(p) for p in data["proposals"]]
        elif isinstance(data, list):
            return [Proposal.model_validate(p) for p in data]
        return []

    async def cast_vote(self, request: CastVoteRequest) -> dict[str, Any]:
        """Cast a vote on a proposal."""
        result = await self._request(
            "POST",
            "/api/v1/votes",
            json=request.model_dump(exclude_none=True, mode="json"),
        )
        return result if isinstance(result, dict) else {}

    # =========================================================================
    # API Keys API
    # =========================================================================

    async def create_api_key(
        self,
        name: Optional[str] = None,
        scopes: Optional[list[str]] = None,
        expires_in_days: Optional[int] = None,
    ) -> dict[str, Any]:
        """
        Create a new API key.

        Returns the key details including the actual key (only shown once).
        """
        payload: dict[str, Any] = {}
        if name:
            payload["name"] = name
        if scopes:
            payload["scopes"] = scopes
        if expires_in_days:
            payload["expires_in_days"] = expires_in_days

        result = await self._request("POST", "/api/v1/keys", json=payload)
        return result if isinstance(result, dict) else {}

    async def list_api_keys(self) -> list[dict[str, Any]]:
        """List all API keys for the authenticated member."""
        result = await self._request("GET", "/api/v1/keys")
        if isinstance(result, dict) and "keys" in result:
            return result["keys"]
        return []

    async def revoke_api_key(self, key_id: str) -> bool:
        """Revoke an API key."""
        result = await self._request("DELETE", f"/api/v1/keys/{key_id}")
        if isinstance(result, dict):
            return result.get("revoked", False)
        return False

    # =========================================================================
    # Health API
    # =========================================================================

    async def health(self) -> dict[str, Any]:
        """Check API health."""
        result = await self._request("GET", "/health")
        return result if isinstance(result, dict) else {}
