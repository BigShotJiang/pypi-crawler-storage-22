"""Custom exceptions for The Clutch SDK."""

from typing import Any, Optional


class ClutchError(Exception):
    """Base exception for all Clutch SDK errors."""

    pass


class ClutchAPIError(ClutchError):
    """Error returned from the Clutch API."""

    def __init__(
        self,
        status_code: int,
        error: str,
        message: str,
        details: Optional[dict[str, Any]] = None,
    ):
        self.status_code = status_code
        self.error = error
        self.message = message
        self.details = details
        super().__init__(f"[{status_code}] {error}: {message}")


class ClutchAuthError(ClutchAPIError):
    """Authentication or authorization error (401/403)."""

    pass


class ClutchRateLimitError(ClutchAPIError):
    """Rate limit exceeded (429)."""

    def __init__(
        self,
        retry_after: Optional[int] = None,
        status_code: int = 429,
        error: str = "rate_limit_exceeded",
        message: str = "Rate limit exceeded",
        details: Optional[dict[str, Any]] = None,
    ):
        super().__init__(status_code, error, message, details)
        self.retry_after = retry_after


class ClutchNotFoundError(ClutchAPIError):
    """Resource not found (404)."""

    pass


class ClutchValidationError(ClutchError):
    """Local validation error before sending request."""

    def __init__(self, message: str, field: Optional[str] = None):
        super().__init__(message)
        self.field = field


class ClutchConnectionError(ClutchError):
    """Network connection error."""

    pass


class ClutchTimeoutError(ClutchError):
    """Request timeout."""

    pass
