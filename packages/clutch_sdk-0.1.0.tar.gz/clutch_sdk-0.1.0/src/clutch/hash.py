"""
Canonicalization and hashing utilities matching clutch-canonical-json-v1.

This module provides hash computation compatible with The Clutch backend,
ensuring consistent content addressing across Python and Rust implementations.
"""

import hashlib
import json
from typing import Any

CANONICALIZATION_ID = "clutch-canonical-json-v1"
HASH_ALGORITHM = "sha3-256"


def canonical_json(data: Any) -> str:
    """
    Produce canonical JSON string.

    Rules:
    - Keys sorted alphabetically (recursive)
    - No whitespace
    - Unicode escaped as \\uXXXX
    - Numbers without trailing zeros

    Args:
        data: Any JSON-serializable data

    Returns:
        Canonical JSON string
    """
    return json.dumps(
        data,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    )


def compute_hash(data: Any) -> str:
    """
    Compute SHA3-256 hash of canonicalized data.

    Args:
        data: Any JSON-serializable data

    Returns:
        Hash as hex string with algorithm prefix (e.g., "sha3-256:abc123...")
    """
    canonical = canonical_json(data)
    hash_bytes = hashlib.sha3_256(canonical.encode("utf-8")).digest()
    return f"sha3-256:{hash_bytes.hex()}"


def compute_content_hash(content: bytes | str) -> str:
    """
    Compute hash of raw content (bytes or string).

    Args:
        content: Raw bytes or string content

    Returns:
        Hash as hex string with algorithm prefix
    """
    if isinstance(content, str):
        content = content.encode("utf-8")
    hash_bytes = hashlib.sha3_256(content).digest()
    return f"sha3-256:{hash_bytes.hex()}"


def verify_hash(data: Any, expected_hash: str) -> bool:
    """
    Verify that data matches expected hash.

    Args:
        data: Data to verify
        expected_hash: Expected hash string

    Returns:
        True if hash matches
    """
    computed = compute_hash(data)
    return computed == expected_hash


def verify_content_hash(content: bytes | str, expected_hash: str) -> bool:
    """
    Verify that content matches expected hash.

    Args:
        content: Content to verify
        expected_hash: Expected hash string

    Returns:
        True if hash matches
    """
    computed = compute_content_hash(content)
    return computed == expected_hash


class HashBinding:
    """
    Represents a hash binding per clutch.hash_binding@0.1.0.

    A hash binding includes the algorithm and canonicalization method used,
    ensuring hashes are verifiable and reproducible.
    """

    def __init__(self, content_hash: str):
        """
        Create a hash binding.

        Args:
            content_hash: The computed hash string
        """
        self.hash_alg = HASH_ALGORITHM
        self.canonicalization_id = CANONICALIZATION_ID
        self.content_hash = content_hash

    def to_dict(self) -> dict[str, str]:
        """Convert to dictionary representation."""
        return {
            "hash_alg": self.hash_alg,
            "canonicalization_id": self.canonicalization_id,
            "content_hash": self.content_hash,
        }

    @classmethod
    def from_data(cls, data: Any) -> "HashBinding":
        """
        Create a hash binding from JSON-serializable data.

        Args:
            data: Data to hash

        Returns:
            HashBinding instance
        """
        return cls(compute_hash(data))

    @classmethod
    def from_content(cls, content: bytes | str) -> "HashBinding":
        """
        Create a hash binding from raw content.

        Args:
            content: Raw bytes or string

        Returns:
            HashBinding instance
        """
        return cls(compute_content_hash(content))

    def __repr__(self) -> str:
        return f"HashBinding({self.content_hash!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, HashBinding):
            return False
        return self.content_hash == other.content_hash
