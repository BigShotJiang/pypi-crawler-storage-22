"""Models for The Clutch SDK."""

from .enums import (
    ArtifactKind,
    ConsumptionKind,
    ReefStatus,
    ValidationKind,
    ValidationOutcome,
    WorkKind,
)
from .requests import (
    CastVoteRequest,
    CreateReefRequest,
    DeclaredInput,
    PublishArtifactRequest,
    RecordConsumptionRequest,
    RegisterMemberRequest,
    SubmitProposalRequest,
    SubmitValidationRequest,
    SubmitWorkRequest,
)
from .responses import (
    APIError,
    Artifact,
    AttributionEdge,
    AttributionGraph,
    AttributionNode,
    Member,
    Proposal,
    Reef,
    ReputationEntry,
    ReputationLeaderboard,
    Validation,
    Work,
)

__all__ = [
    # Enums
    "WorkKind",
    "ValidationKind",
    "ValidationOutcome",
    "ArtifactKind",
    "ConsumptionKind",
    "ReefStatus",
    # Requests
    "DeclaredInput",
    "RegisterMemberRequest",
    "SubmitWorkRequest",
    "PublishArtifactRequest",
    "SubmitValidationRequest",
    "RecordConsumptionRequest",
    "CreateReefRequest",
    "SubmitProposalRequest",
    "CastVoteRequest",
    # Responses
    "Member",
    "Work",
    "Artifact",
    "Validation",
    "Reef",
    "ReputationEntry",
    "ReputationLeaderboard",
    "AttributionNode",
    "AttributionEdge",
    "AttributionGraph",
    "Proposal",
    "APIError",
]
