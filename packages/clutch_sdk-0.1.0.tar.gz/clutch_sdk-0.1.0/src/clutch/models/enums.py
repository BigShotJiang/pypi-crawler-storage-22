"""Enums for The Clutch SDK."""

from enum import Enum


class WorkKind(str, Enum):
    """Types of work that can be submitted."""

    RESEARCH = "RESEARCH"
    CODE = "CODE"
    DATASET = "DATASET"
    EVALUATION = "EVALUATION"
    OPERATIONS = "OPERATIONS"
    GOVERNANCE = "GOVERNANCE"


class ValidationKind(str, Enum):
    """Types of validation that can be performed."""

    SCHEMA_CHECK = "SCHEMA_CHECK"
    REPRODUCIBILITY = "REPRODUCIBILITY"
    SECURITY_SCAN = "SECURITY_SCAN"
    PROVENANCE_CHECK = "PROVENANCE_CHECK"
    PERFORMANCE_BENCH = "PERFORMANCE_BENCH"
    HUMAN_REVIEW = "HUMAN_REVIEW"


class ValidationOutcome(str, Enum):
    """Possible outcomes of a validation."""

    PASS = "PASS"
    FAIL = "FAIL"
    INCONCLUSIVE = "INCONCLUSIVE"


class ArtifactKind(str, Enum):
    """Types of artifacts that can be published."""

    MODEL = "MODEL"
    DATASET = "DATASET"
    CODE_PACKAGE = "CODE_PACKAGE"
    DOCUMENT = "DOCUMENT"
    INDEX = "INDEX"
    OTHER = "OTHER"


class ConsumptionKind(str, Enum):
    """Types of artifact consumption."""

    API_CALL = "API_CALL"
    DOWNLOAD = "DOWNLOAD"
    EMBED = "EMBED"
    DERIVATION = "DERIVATION"
    OTHER = "OTHER"


class ReefStatus(str, Enum):
    """Possible statuses for a reef."""

    PROPOSED = "PROPOSED"
    VOTING = "VOTING"
    REJECTED = "REJECTED"
    APPROVED = "APPROVED"
    TRIAL_ACTIVE = "TRIAL_ACTIVE"
    TRIAL_EXPIRED = "TRIAL_EXPIRED"
    SUNSETTED = "SUNSETTED"
    PROMOTED = "PROMOTED"
