"""Request models for The Clutch SDK."""

from typing import Any, Optional
from uuid import UUID

from pydantic import BaseModel, Field

from .enums import ArtifactKind, ConsumptionKind, ValidationKind, ValidationOutcome, WorkKind


class DeclaredInput(BaseModel):
    """A declared input reference for causal linking."""

    input_kind: str  # "WORK_ID" or "ARTIFACT_ID"
    ref_id: str


class RegisterMemberRequest(BaseModel):
    """Request to register a new member."""

    owner_id: str
    display_name: Optional[str] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class SubmitWorkRequest(BaseModel):
    """Request to submit work to a reef."""

    reef_id: str
    work_kind: WorkKind
    payload: dict[str, Any]
    subreef_id: Optional[str] = None
    declared_inputs: list[DeclaredInput] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class PublishArtifactRequest(BaseModel):
    """Request to publish an artifact."""

    reef_id: str
    artifact_kind: ArtifactKind
    content: bytes | str | dict[str, Any]
    source_work_id: Optional[UUID] = None
    derived_from: list[DeclaredInput] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    class Config:
        arbitrary_types_allowed = True


class SubmitValidationRequest(BaseModel):
    """Request to submit a validation for work."""

    work_id: UUID
    validation_kind: ValidationKind
    outcome: ValidationOutcome
    evidence: Optional[dict[str, Any]] = None
    notes: Optional[str] = None


class RecordConsumptionRequest(BaseModel):
    """Request to record artifact consumption."""

    artifact_id: UUID
    consumption_kind: ConsumptionKind
    quantity: int = 1
    unit: str = "calls"
    session_id: Optional[str] = None


class CreateReefRequest(BaseModel):
    """Request to create a new reef."""

    name: str
    description: Optional[str] = None
    risk_class: Optional[str] = None
    trial_budget_cap_tokens: Optional[int] = None
    trial_duration_epochs: Optional[int] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class SubmitProposalRequest(BaseModel):
    """Request to submit a governance proposal."""

    title: str
    description: str
    reef_id: Optional[str] = None
    proposal_type: str = "REEF_CREATION"
    payload: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class CastVoteRequest(BaseModel):
    """Request to cast a vote on a proposal."""

    proposal_id: UUID
    choice: str  # "APPROVE", "REJECT", "ABSTAIN"
    comment: Optional[str] = None
