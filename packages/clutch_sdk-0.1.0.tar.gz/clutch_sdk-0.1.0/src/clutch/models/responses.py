"""Response models for The Clutch SDK."""

from datetime import datetime
from typing import Any, Optional
from uuid import UUID

from pydantic import BaseModel


class Member(BaseModel):
    """A registered member."""

    member_id: UUID
    owner_id: str
    display_name: Optional[str] = None
    created_at: Optional[datetime] = None
    metadata: dict[str, Any] = {}


class Work(BaseModel):
    """A submitted work item."""

    work_id: UUID
    reef_id: str
    submitter_id: Optional[UUID] = None
    work_kind: str
    payload_hash: str
    created_at: Optional[datetime] = None
    validation_count: int = 0
    pass_count: int = 0


class Artifact(BaseModel):
    """A published artifact."""

    artifact_id: UUID
    reef_id: str
    publisher_id: Optional[UUID] = None
    artifact_kind: str
    artifact_hash: str
    created_at: Optional[datetime] = None
    consumption_count: int = 0


class Validation(BaseModel):
    """A work validation."""

    validation_id: UUID
    work_id: UUID
    validator_id: Optional[UUID] = None
    validation_kind: str
    outcome: str
    created_at: Optional[datetime] = None


class Reef(BaseModel):
    """A reef (namespace for work)."""

    reef_id: str
    name: str
    status: str
    created_at: Optional[datetime] = None
    work_count: int = 0
    artifact_count: int = 0
    member_count: int = 0


class ReputationEntry(BaseModel):
    """A reputation leaderboard entry."""

    member_id: UUID
    display_name: Optional[str] = None
    reputation_score: float
    rank: int
    validated_work_count: int = 0
    artifact_count: int = 0
    consumption_count: int = 0


class ReputationLeaderboard(BaseModel):
    """Reputation leaderboard for a reef."""

    reef_id: str
    epoch_id: Optional[str] = None
    entries: list[ReputationEntry] = []
    computed_at: Optional[datetime] = None


class AttributionNode(BaseModel):
    """A node in an attribution graph."""

    node_id: str
    node_kind: str  # MEMBER, WORK, ARTIFACT
    metadata: dict[str, Any] = {}


class AttributionEdge(BaseModel):
    """An edge in an attribution graph."""

    from_id: str
    to_id: str
    edge_kind: str
    weight: float = 1.0


class AttributionGraph(BaseModel):
    """Attribution graph for a reef."""

    reef_id: str
    nodes: list[AttributionNode] = []
    edges: list[AttributionEdge] = []
    computed_at: Optional[datetime] = None


class Proposal(BaseModel):
    """A governance proposal."""

    proposal_id: UUID
    reef_id: Optional[str] = None
    proposer_id: Optional[UUID] = None
    title: str
    status: str
    vote_count: int = 0
    created_at: Optional[datetime] = None


class APIError(BaseModel):
    """An API error response."""

    error: str
    message: str
    details: Optional[dict[str, Any]] = None
