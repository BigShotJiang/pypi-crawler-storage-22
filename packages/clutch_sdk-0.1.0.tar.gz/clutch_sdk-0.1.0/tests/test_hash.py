"""Tests for hashing utilities."""

import pytest

from clutch.hash import (
    HashBinding,
    canonical_json,
    compute_content_hash,
    compute_hash,
    verify_content_hash,
    verify_hash,
)


class TestCanonicalJson:
    """Tests for canonical JSON serialization."""

    def test_sorts_keys(self):
        """Keys should be sorted alphabetically."""
        data = {"zebra": 1, "apple": 2, "mango": 3}
        result = canonical_json(data)
        assert result == '{"apple":2,"mango":3,"zebra":1}'

    def test_nested_sorting(self):
        """Nested object keys should also be sorted."""
        data = {"outer": {"z": 1, "a": 2}}
        result = canonical_json(data)
        assert result == '{"outer":{"a":2,"z":1}}'

    def test_no_whitespace(self):
        """Output should have no whitespace."""
        data = {"key": "value", "list": [1, 2, 3]}
        result = canonical_json(data)
        assert " " not in result
        assert "\n" not in result
        assert result == '{"key":"value","list":[1,2,3]}'

    def test_arrays_preserve_order(self):
        """Array elements should preserve their order."""
        data = {"items": [3, 1, 2]}
        result = canonical_json(data)
        assert result == '{"items":[3,1,2]}'


class TestComputeHash:
    """Tests for hash computation."""

    def test_returns_prefixed_hash(self):
        """Hash should have sha3-256 prefix."""
        result = compute_hash({"test": "data"})
        assert result.startswith("sha3-256:")

    def test_hash_length(self):
        """Hash should be 64 hex chars after prefix."""
        result = compute_hash({"test": "data"})
        hash_part = result.split(":")[1]
        assert len(hash_part) == 64  # SHA3-256 = 32 bytes = 64 hex chars

    def test_same_data_same_hash(self):
        """Same data should produce same hash."""
        data = {"key": "value"}
        hash1 = compute_hash(data)
        hash2 = compute_hash(data)
        assert hash1 == hash2

    def test_key_order_independent(self):
        """Key order should not affect hash due to canonicalization."""
        data1 = {"a": 1, "b": 2}
        data2 = {"b": 2, "a": 1}
        assert compute_hash(data1) == compute_hash(data2)

    def test_different_data_different_hash(self):
        """Different data should produce different hash."""
        hash1 = compute_hash({"key": "value1"})
        hash2 = compute_hash({"key": "value2"})
        assert hash1 != hash2


class TestComputeContentHash:
    """Tests for content hash computation."""

    def test_string_hash(self):
        """String content should be hashed correctly."""
        result = compute_content_hash("hello world")
        assert result.startswith("sha3-256:")
        assert len(result.split(":")[1]) == 64

    def test_bytes_hash(self):
        """Bytes content should be hashed correctly."""
        result = compute_content_hash(b"hello world")
        assert result.startswith("sha3-256:")

    def test_string_and_bytes_match(self):
        """String and equivalent bytes should produce same hash."""
        string_hash = compute_content_hash("hello world")
        bytes_hash = compute_content_hash(b"hello world")
        assert string_hash == bytes_hash


class TestVerifyHash:
    """Tests for hash verification."""

    def test_verify_correct_hash(self):
        """Verification should pass for correct hash."""
        data = {"test": "data"}
        hash_value = compute_hash(data)
        assert verify_hash(data, hash_value)

    def test_verify_incorrect_hash(self):
        """Verification should fail for incorrect hash."""
        data = {"test": "data"}
        assert not verify_hash(data, "sha3-256:0" * 64)


class TestVerifyContentHash:
    """Tests for content hash verification."""

    def test_verify_correct_content_hash(self):
        """Verification should pass for correct hash."""
        content = "hello world"
        hash_value = compute_content_hash(content)
        assert verify_content_hash(content, hash_value)

    def test_verify_incorrect_content_hash(self):
        """Verification should fail for incorrect hash."""
        assert not verify_content_hash("hello world", "sha3-256:0" * 64)


class TestHashBinding:
    """Tests for HashBinding class."""

    def test_from_data(self):
        """Should create binding from data."""
        data = {"test": "data"}
        binding = HashBinding.from_data(data)
        assert binding.hash_alg == "sha3-256"
        assert binding.canonicalization_id == "clutch-canonical-json-v1"
        assert binding.content_hash.startswith("sha3-256:")

    def test_from_content(self):
        """Should create binding from content."""
        binding = HashBinding.from_content("hello world")
        assert binding.hash_alg == "sha3-256"
        assert binding.content_hash.startswith("sha3-256:")

    def test_to_dict(self):
        """Should convert to dictionary."""
        binding = HashBinding.from_data({"test": "data"})
        result = binding.to_dict()
        assert "hash_alg" in result
        assert "canonicalization_id" in result
        assert "content_hash" in result

    def test_equality(self):
        """Bindings with same hash should be equal."""
        data = {"test": "data"}
        binding1 = HashBinding.from_data(data)
        binding2 = HashBinding.from_data(data)
        assert binding1 == binding2
