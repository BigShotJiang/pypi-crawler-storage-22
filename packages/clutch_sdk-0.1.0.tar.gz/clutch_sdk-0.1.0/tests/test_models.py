"""Tests for model validation."""

import pytest
from uuid import uuid4

from clutch.models.enums import (
    ArtifactKind,
    ConsumptionKind,
    ReefStatus,
    ValidationKind,
    ValidationOutcome,
    WorkKind,
)
from clutch.models.requests import (
    CastVoteRequest,
    CreateReefRequest,
    DeclaredInput,
    PublishArtifactRequest,
    RecordConsumptionRequest,
    RegisterMemberRequest,
    SubmitProposalRequest,
    SubmitValidationRequest,
    SubmitWorkRequest,
)
from clutch.models.responses import (
    Artifact,
    Member,
    Reef,
    ReputationEntry,
    Validation,
    Work,
)


class TestEnums:
    """Tests for enum values."""

    def test_work_kind_values(self):
        assert WorkKind.RESEARCH.value == "RESEARCH"
        assert WorkKind.CODE.value == "CODE"

    def test_validation_kind_values(self):
        assert ValidationKind.SCHEMA_CHECK.value == "SCHEMA_CHECK"
        assert ValidationKind.HUMAN_REVIEW.value == "HUMAN_REVIEW"

    def test_validation_outcome_values(self):
        assert ValidationOutcome.PASS.value == "PASS"
        assert ValidationOutcome.FAIL.value == "FAIL"

    def test_artifact_kind_values(self):
        assert ArtifactKind.DOCUMENT.value == "DOCUMENT"
        assert ArtifactKind.CODE_PACKAGE.value == "CODE_PACKAGE"

    def test_consumption_kind_values(self):
        assert ConsumptionKind.API_CALL.value == "API_CALL"
        assert ConsumptionKind.DOWNLOAD.value == "DOWNLOAD"

    def test_reef_status_values(self):
        assert ReefStatus.TRIAL_ACTIVE.value == "TRIAL_ACTIVE"
        assert ReefStatus.PROMOTED.value == "PROMOTED"


class TestRequestModels:
    """Tests for request model validation."""

    def test_register_member_request(self):
        request = RegisterMemberRequest(
            owner_id="owner-123",
            display_name="Test Bot",
        )
        assert request.owner_id == "owner-123"
        assert request.display_name == "Test Bot"
        assert request.metadata == {}

    def test_submit_work_request(self):
        request = SubmitWorkRequest(
            reef_id="test-reef",
            work_kind=WorkKind.RESEARCH,
            payload={"title": "Test", "content": "Hello"},
        )
        assert request.reef_id == "test-reef"
        assert request.work_kind == WorkKind.RESEARCH
        assert request.declared_inputs == []

    def test_submit_work_with_inputs(self):
        request = SubmitWorkRequest(
            reef_id="test-reef",
            work_kind=WorkKind.CODE,
            payload={"code": "print('hello')"},
            declared_inputs=[
                DeclaredInput(input_kind="WORK_ID", ref_id="uuid-123"),
            ],
        )
        assert len(request.declared_inputs) == 1

    def test_publish_artifact_request(self):
        request = PublishArtifactRequest(
            reef_id="test-reef",
            artifact_kind=ArtifactKind.DOCUMENT,
            content={"doc": "content"},
        )
        assert request.artifact_kind == ArtifactKind.DOCUMENT

    def test_submit_validation_request(self):
        work_id = uuid4()
        request = SubmitValidationRequest(
            work_id=work_id,
            validation_kind=ValidationKind.SCHEMA_CHECK,
            outcome=ValidationOutcome.PASS,
        )
        assert request.work_id == work_id
        assert request.outcome == ValidationOutcome.PASS

    def test_record_consumption_request(self):
        artifact_id = uuid4()
        request = RecordConsumptionRequest(
            artifact_id=artifact_id,
            consumption_kind=ConsumptionKind.API_CALL,
            quantity=5,
        )
        assert request.quantity == 5
        assert request.unit == "calls"

    def test_create_reef_request(self):
        request = CreateReefRequest(
            name="ML Research",
            description="Machine learning research reef",
        )
        assert request.name == "ML Research"

    def test_submit_proposal_request(self):
        request = SubmitProposalRequest(
            title="New Reef Proposal",
            description="Create a new reef for AI safety",
        )
        assert request.proposal_type == "REEF_CREATION"

    def test_cast_vote_request(self):
        proposal_id = uuid4()
        request = CastVoteRequest(
            proposal_id=proposal_id,
            choice="APPROVE",
            comment="Looks good!",
        )
        assert request.choice == "APPROVE"


class TestResponseModels:
    """Tests for response model parsing."""

    def test_member_model(self):
        member_id = uuid4()
        member = Member(
            member_id=member_id,
            owner_id="owner-123",
            display_name="Test Bot",
        )
        assert member.member_id == member_id

    def test_work_model(self):
        work_id = uuid4()
        work = Work(
            work_id=work_id,
            reef_id="test-reef",
            work_kind="RESEARCH",
            payload_hash="sha3-256:abc123",
        )
        assert work.validation_count == 0
        assert work.pass_count == 0

    def test_artifact_model(self):
        artifact_id = uuid4()
        artifact = Artifact(
            artifact_id=artifact_id,
            reef_id="test-reef",
            artifact_kind="DOCUMENT",
            artifact_hash="sha3-256:def456",
        )
        assert artifact.consumption_count == 0

    def test_validation_model(self):
        validation_id = uuid4()
        work_id = uuid4()
        validation = Validation(
            validation_id=validation_id,
            work_id=work_id,
            validation_kind="SCHEMA_CHECK",
            outcome="PASS",
        )
        assert validation.outcome == "PASS"

    def test_reef_model(self):
        reef = Reef(
            reef_id="test-reef",
            name="Test Reef",
            status="TRIAL_ACTIVE",
        )
        assert reef.work_count == 0
        assert reef.artifact_count == 0

    def test_reputation_entry_model(self):
        member_id = uuid4()
        entry = ReputationEntry(
            member_id=member_id,
            reputation_score=150.5,
            rank=1,
        )
        assert entry.reputation_score == 150.5
        assert entry.rank == 1
