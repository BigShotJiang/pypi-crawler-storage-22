"""
Asynchronous terminal service implementation.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from cmdop.models.terminal import (
    HistoryResponse,
    SessionInfo,
    SessionListItem,
    SessionListResponse,
    SessionMode,
    SessionState,
    SessionStatus,
    SignalType,
)
from cmdop.services.base import BaseService
from cmdop.services.terminal._helpers import get_signal_number

if TYPE_CHECKING:
    from cmdop.streaming.terminal import TerminalStream
    from cmdop.transport.base import BaseTransport


class AsyncTerminalService(BaseService):
    """
    Asynchronous terminal service.

    Provides async operations for terminal session management.
    Most methods support auto-detection of session_id when not provided.

    Example:
        >>> # Auto session detection - SDK handles session automatically
        >>> output, code = await client.terminal.execute("ls -la")
        >>> history = await client.terminal.get_history()
        >>>
        >>> # Or explicit session control
        >>> session = await client.terminal.get_active_session()
        >>> await client.terminal.send_input(b"ls\\n", session_id=session.session_id)
    """

    def __init__(self, transport: BaseTransport) -> None:
        super().__init__(transport)
        self._stub: Any = None
        self._cached_session_id: str | None = None
        self._cached_hostname: str | None = None
        self._cached_session_info: SessionListItem | None = None

    # -------------------------------------------------------------------------
    # Machine & Session Management
    # -------------------------------------------------------------------------

    async def set_machine(self, hostname: str) -> SessionListItem:
        """
        Set the target machine by hostname and cache its session.

        Finds the most recently active session on the specified machine
        and caches both hostname and session_id for all subsequent operations.

        Args:
            hostname: Machine hostname (partial match supported).

        Returns:
            SessionListItem for the found session.

        Raises:
            CMDOPError: If no active session found on the machine.

        Example:
            >>> await client.terminal.set_machine("my-server")
            >>> # Now all operations target this machine
            >>> output, code = await client.terminal.execute("ls")
            >>> await client.terminal.send_input("echo hello\\n")
        """
        session = await self.get_active_session(hostname=hostname)
        if session is None:
            from cmdop.exceptions import CMDOPError

            raise CMDOPError(f"No active session found for hostname: {hostname}")

        self._cached_hostname = hostname
        self._cached_session_id = session.session_id
        self._cached_session_info = session
        return session

    async def _resolve_session_id(self, session_id: str | None) -> str | None:
        """
        Resolve session_id, using cache or auto-detecting if None.

        Resolution order:
        1. Explicit session_id parameter
        2. Cached session_id (from set_machine or set_session_id)
        3. Auto-detect from cached hostname (requires set_machine() first)

        Returns None if no session found or hostname not set.
        """
        if session_id is not None:
            self._cached_session_id = session_id
            return session_id

        if self._cached_session_id is not None:
            return self._cached_session_id

        # Auto-detect requires hostname to be set
        if self._cached_hostname is None:
            return None

        session = await self.get_active_session(self._cached_hostname)
        if session:
            self._cached_session_id = session.session_id
            self._cached_session_info = session
            return session.session_id

        return None

    def set_session_id(self, session_id: str) -> None:
        """
        Set the default session_id for all operations.

        Use this to pre-set the session once. For targeting a specific
        machine, prefer set_machine() which also validates the session exists.

        Args:
            session_id: Session ID to use for all operations.

        Example:
            >>> session = await client.terminal.get_active_session("my-server")
            >>> client.terminal.set_session_id(session.session_id)
            >>> await client.terminal.send_input(b"ls\\n")
        """
        self._cached_session_id = session_id

    def clear_session(self) -> None:
        """Clear cached session and hostname, forcing auto-detection on next call."""
        self._cached_session_id = None
        self._cached_hostname = None
        self._cached_session_info = None

    def clear_session_id(self) -> None:
        """Clear cached session_id only. Alias for clear_session()."""
        self.clear_session()

    @property
    def current_session(self) -> SessionListItem | None:
        """Get the currently cached session info, if any."""
        return self._cached_session_info

    @property
    def current_hostname(self) -> str | None:
        """Get the currently cached hostname filter, if any."""
        return self._cached_hostname

    # -------------------------------------------------------------------------
    # gRPC Stub
    # -------------------------------------------------------------------------

    @property
    def _get_stub(self) -> Any:
        """Lazy-load async gRPC stub."""
        if self._stub is None:
            from cmdop._generated.service_pb2_grpc import (
                TerminalStreamingServiceStub,
            )

            self._stub = TerminalStreamingServiceStub(self._async_channel)
        return self._stub

    # -------------------------------------------------------------------------
    # Session Operations
    # -------------------------------------------------------------------------

    async def create(
        self,
        shell: str = "/bin/bash",
        cols: int = 80,
        rows: int = 24,
        env: dict[str, str] | None = None,
        working_dir: str | None = None,
        mode: SessionMode = SessionMode.EXCLUSIVE,
    ) -> SessionInfo:
        """Create a new terminal session."""
        from cmdop._generated.common_types_pb2 import SessionConfig, TerminalSize
        from cmdop._generated.rpc_messages.session_pb2 import (
            CreateSessionRequest as PbRequest,
        )

        config = SessionConfig(
            shell=shell,
            working_directory=working_dir or "",
            size=TerminalSize(cols=cols, rows=rows),
        )
        if env:
            for k, v in env.items():
                config.env[k] = v

        request = PbRequest(config=config)
        response = await self._call_async(self._get_stub.CreateSession, request)

        return SessionInfo(
            session_id=response.session_id,
            state=SessionState.ACTIVE,
            mode=mode,
            shell=shell,
            cols=cols,
            rows=rows,
            working_dir=working_dir,
            created_at=datetime.now(timezone.utc),
        )

    async def close(
        self,
        session_id: str | None = None,
        force: bool = False,  # noqa: ARG002
    ) -> None:
        """
        Close terminal session.

        Args:
            session_id: Session UUID to close. If None, closes cached/active session.
            force: Force kill if graceful close fails.

        Raises:
            CMDOPError: If no session found and session_id not provided.
        """
        from cmdop._generated.rpc_messages.session_pb2 import CloseSessionRequest

        resolved_id = await self._resolve_session_id(session_id)
        if resolved_id is None:
            from cmdop.exceptions import CMDOPError

            raise CMDOPError("No active session found")

        request = CloseSessionRequest(session_id=resolved_id)
        await self._call_async(self._get_stub.CloseSession, request)

        if self._cached_session_id == resolved_id:
            self._cached_session_id = None

    # -------------------------------------------------------------------------
    # Terminal I/O
    # -------------------------------------------------------------------------

    async def send_input(
        self,
        data: bytes | str,
        session_id: str | None = None,
    ) -> None:
        """
        Send input to terminal session.

        Args:
            data: Input bytes or string to send.
            session_id: Target session UUID. If None, auto-detects active session.

        Raises:
            CMDOPError: If no session found and session_id not provided.

        Example:
            >>> await client.terminal.send_input("ls\\n")
            >>> await client.terminal.send_input("ls\\n", session_id="...")
        """
        from cmdop._generated.rpc_messages.terminal_pb2 import SendInputRequest

        resolved_id = await self._resolve_session_id(session_id)
        if resolved_id is None:
            from cmdop.exceptions import CMDOPError

            raise CMDOPError("No active session found")

        if isinstance(data, str):
            data = data.encode("utf-8")

        request = SendInputRequest(session_id=resolved_id, data=data)
        await self._call_async(self._get_stub.SendInput, request)

    async def resize(
        self,
        cols: int,
        rows: int,
        session_id: str | None = None,
    ) -> None:
        """
        Resize terminal window.

        Args:
            cols: New width in columns.
            rows: New height in rows.
            session_id: Target session UUID. If None, auto-detects active session.

        Raises:
            CMDOPError: If no session found and session_id not provided.
        """
        from cmdop._generated.rpc_messages.terminal_pb2 import SendResizeRequest

        resolved_id = await self._resolve_session_id(session_id)
        if resolved_id is None:
            from cmdop.exceptions import CMDOPError

            raise CMDOPError("No active session found")

        request = SendResizeRequest(session_id=resolved_id, cols=cols, rows=rows)
        await self._call_async(self._get_stub.SendResize, request)

    async def send_signal(
        self,
        signal: SignalType,
        session_id: str | None = None,
    ) -> None:
        """
        Send signal to terminal session.

        Args:
            signal: Signal to send (SIGINT, SIGTERM, etc.).
            session_id: Target session UUID. If None, auto-detects active session.

        Raises:
            CMDOPError: If no session found and session_id not provided.
        """
        from cmdop._generated.rpc_messages.terminal_pb2 import SendSignalRequest

        resolved_id = await self._resolve_session_id(session_id)
        if resolved_id is None:
            from cmdop.exceptions import CMDOPError

            raise CMDOPError("No active session found")

        request = SendSignalRequest(
            session_id=resolved_id,
            signal=get_signal_number(signal),
        )
        await self._call_async(self._get_stub.SendSignal, request)

    async def get_history(
        self,
        session_id: str | None = None,
        lines: int = 1000,
        offset: int = 0,
    ) -> HistoryResponse:
        """
        Get terminal output history.

        Args:
            session_id: Target session UUID. If None, auto-detects active session.
            lines: Number of lines to retrieve.
            offset: Start offset for pagination.

        Returns:
            History response with output data.

        Raises:
            CMDOPError: If no session found and session_id not provided.
        """
        from cmdop._generated.rpc_messages.history_pb2 import GetHistoryRequest

        resolved_id = await self._resolve_session_id(session_id)
        if resolved_id is None:
            from cmdop.exceptions import CMDOPError

            raise CMDOPError("No active session found")

        request = GetHistoryRequest(
            session_id=resolved_id,
            limit=lines,
            offset=offset,
        )
        response = await self._call_async(self._get_stub.GetHistory, request)

        return HistoryResponse(
            session_id=resolved_id,
            data=response.data
            if hasattr(response, "data")
            else b"".join(c.encode() for c in response.commands),
            total_lines=response.total if hasattr(response, "total") else lines,
            has_more=False,
        )

    async def get_output(
        self,
        session_id: str | None = None,
        limit: int = 0,
        offset: int = 0,
    ) -> bytes:
        """
        Get terminal output buffer (raw PTY output).

        Retrieves terminal output from Django's Redis buffer.
        This is different from get_history() which returns command strings.

        Args:
            session_id: Target session UUID. If None, auto-detects active session.
            limit: Max bytes to return (0 = default 1MB).
            offset: Byte offset to start from.

        Returns:
            Raw terminal output bytes.

        Raises:
            CMDOPError: If no session found and session_id not provided.
        """
        from cmdop._generated.rpc_messages.history_pb2 import GetOutputRequest

        resolved_id = await self._resolve_session_id(session_id)
        if resolved_id is None:
            from cmdop.exceptions import CMDOPError

            raise CMDOPError("No active session found")

        request = GetOutputRequest(
            session_id=resolved_id,
            limit=limit,
            offset=offset,
        )
        response = await self._call_async(self._get_stub.GetOutput, request)

        return response.data if response.data else b""

    # -------------------------------------------------------------------------
    # Streaming
    # -------------------------------------------------------------------------

    def stream(self) -> TerminalStream:
        """
        Create a bidirectional terminal stream.

        Returns a TerminalStream that manages real-time terminal I/O
        via gRPC bidirectional streaming.

        **IMPORTANT: Remote mode only!**
        Streaming requires cloud relay connection (RemoteTransport).
        Local connections will raise RuntimeError on connect().
        For local mode, use send_input(), get_history() methods instead.

        Usage (remote mode):
            >>> async with AsyncCMDOPClient.remote(api_key="xxx") as client:
            ...     async with client.terminal.stream() as stream:
            ...         stream.on_output(lambda data: print(data.decode(), end=""))
            ...         await stream.send_input(b"ls\\n")

        Returns:
            TerminalStream instance (not yet connected).

        Raises:
            RuntimeError: On connect() if using local transport.

        Note:
            Call `await stream.connect()` or use as context manager
            to establish the connection.
        """
        from cmdop.streaming.terminal import TerminalStream

        return TerminalStream(self._transport)

    # -------------------------------------------------------------------------
    # Command Execution
    # -------------------------------------------------------------------------

    async def execute(
        self,
        command: str,
        timeout: float = 30.0,
        session_id: str | None = None,
    ) -> tuple[bytes, int]:
        """
        Execute a command and return output.

        Sends command to existing session and retrieves output via history.
        For real-time streaming output, use stream() instead.

        Requires either:
        - Explicit session_id parameter, OR
        - Prior call to set_machine() to set target hostname

        Args:
            command: Command to execute.
            timeout: Maximum time to wait for output.
            session_id: Session ID to use. If None, uses cached session.

        Returns:
            Tuple of (output_bytes, exit_code).
            Note: exit_code is 0 on success, -1 if unable to detect completion.

        Example:
            >>> await client.terminal.set_machine("my-server")
            >>> output, code = await client.terminal.execute("ls -la")
            >>> print(output.decode())
        """
        import asyncio

        from cmdop.exceptions import CMDOPError

        resolved_id = await self._resolve_session_id(session_id)
        if resolved_id is None:
            return b"No session. Call set_machine() first or provide session_id.", -1
        session_id = resolved_id

        # Use marker to detect command completion and get exit code
        marker = f"__CMDOP_DONE_{id(command)}__"
        full_cmd = f"{command}; echo '{marker}'$?\n"

        try:
            await self.send_input(full_cmd.encode(), session_id=session_id)
        except CMDOPError as e:
            return f"Failed to send command: {e.message}".encode(), -1

        # Poll output buffer until we see the marker or timeout
        start_time = asyncio.get_event_loop().time()
        last_output = b""
        exit_code = -1

        while True:
            await asyncio.sleep(0.3)

            try:
                # Use get_output() which reads from Redis buffer (real PTY output)
                # instead of get_history() which reads from CommandHistory DB
                output = await self.get_output(session_id)
            except CMDOPError as e:
                return f"Failed to get output: {e.message}".encode(), -1

            marker_bytes = marker.encode()
            if marker_bytes in output:
                try:
                    idx = output.index(marker_bytes)
                    after_marker = output[idx + len(marker_bytes) : idx + len(marker_bytes) + 10]
                    exit_str = after_marker.split(b"\n")[0].strip()
                    if exit_str.isdigit():
                        exit_code = int(exit_str)
                    else:
                        exit_code = 0
                except (ValueError, IndexError):
                    exit_code = 0

                # Clean up marker from output
                output = output.replace(f"echo '{marker}'$?\n".encode(), b"")
                output = output.replace(f"{marker}{exit_code}\n".encode(), b"")
                output = output.replace(marker_bytes, b"")
                return output, exit_code

            last_output = output

            elapsed = asyncio.get_event_loop().time() - start_time
            if elapsed >= timeout:
                return last_output, -1

    # -------------------------------------------------------------------------
    # Session Discovery
    # -------------------------------------------------------------------------

    async def list_sessions(
        self,
        hostname: str | None = None,
        status: str | None = None,
        limit: int = 20,
    ) -> SessionListResponse:
        """
        List terminal sessions in workspace (v2.14.0).

        Returns sessions visible to the authenticated API key's workspace.

        Args:
            hostname: Optional filter by machine hostname (partial match).
            status: Optional filter by status ("connected", "disconnected").
            limit: Maximum sessions to return (default: 20).

        Returns:
            SessionListResponse with list of sessions.

        Example:
            >>> response = await client.terminal.list_sessions(status="connected")
            >>> for s in response.sessions:
            ...     print(f"{s.machine_hostname}: {s.status}")
        """
        from cmdop._generated.rpc_messages.session_pb2 import ListSessionsRequest

        request = ListSessionsRequest(
            hostname_filter=hostname or "",
            status_filter=status or "",
            limit=limit,
        )

        response = await self._call_async(self._get_stub.ListSessions, request)

        if response.error:
            from cmdop.exceptions import CMDOPError

            raise CMDOPError(response.error)

        sessions = []
        for s in response.sessions:
            connected_at = None
            if s.connected_at and s.connected_at.seconds > 0:
                connected_at = datetime.fromtimestamp(
                    s.connected_at.seconds, tz=timezone.utc
                )

            sessions.append(
                SessionListItem(
                    session_id=s.session_id,
                    machine_hostname=s.machine_hostname,
                    machine_name=s.machine_name,
                    status=s.status,
                    os=s.os,
                    agent_version=s.agent_version,
                    heartbeat_age_seconds=s.heartbeat_age_seconds,
                    has_shell=s.has_shell,
                    shell=s.shell,
                    working_directory=s.working_directory,
                    connected_at=connected_at,
                )
            )

        return SessionListResponse(
            sessions=sessions,
            total=response.total,
            workspace_name=response.workspace_name,
        )

    async def list_active_sessions(
        self,
        hostname: str,
        limit: int = 100,
    ) -> list[SessionListItem]:
        """
        List active (connected) sessions for a specific machine.

        Filters for connected sessions and sorts by heartbeat_age_seconds
        (lower = more recently active).

        Args:
            hostname: Machine hostname filter (required, partial match).
            limit: Maximum sessions to return (default: 100).

        Returns:
            List of SessionListItem, sorted by most recent activity.

        Example:
            >>> sessions = await client.terminal.list_active_sessions("my-server")
            >>> for s in sessions:
            ...     print(f"{s.machine_hostname} ({s.heartbeat_age_seconds}s ago)")
        """
        response = await self.list_sessions(
            hostname=hostname,
            status=SessionStatus.CONNECTED.value,
            limit=limit,
        )

        return sorted(
            response.sessions,
            key=lambda s: s.heartbeat_age_seconds,
        )

    async def get_active_session(
        self,
        hostname: str,
    ) -> SessionListItem | None:
        """
        Get most recently active (connected) session for a specific machine.

        Returns the connected session with the lowest heartbeat_age_seconds,
        i.e., the one that was active most recently.

        Args:
            hostname: Machine hostname filter (required, partial match).

        Returns:
            SessionListItem if found, None otherwise.

        Example:
            >>> session = await client.terminal.get_active_session("my-server")
            >>> if session:
            ...     client.terminal.set_session_id(session.session_id)
        """
        sessions = await self.list_active_sessions(hostname, limit=1)
        return sessions[0] if sessions else None
