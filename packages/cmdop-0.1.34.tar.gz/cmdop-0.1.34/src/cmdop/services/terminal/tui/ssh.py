"""
SSH-like terminal connection.

Provides simple raw terminal passthrough for connecting to remote machines.
"""

from __future__ import annotations

import asyncio
import sys
from typing import TYPE_CHECKING

from cmdop.services.terminal.tui.modes import (
    enter_raw_mode,
    exit_raw_mode,
    get_terminal_size,
    is_tty,
    setup_resize_handler,
)

if TYPE_CHECKING:
    from cmdop import AsyncCMDOPClient
    from cmdop.streaming.terminal import TerminalStream


async def ssh_connect(
    hostname: str,
    api_key: str,
    session_id: str | None = None,
) -> int:
    """
    Connect to a remote machine with SSH-like terminal experience.

    Establishes a bidirectional terminal stream and provides
    raw terminal passthrough for interactive shell access.

    Args:
        hostname: Machine hostname to connect to (partial match).
        api_key: CMDOP API key for authentication.
        session_id: Optional specific session ID to connect to.

    Returns:
        Exit code (0 for success, 1 for error).

    Example:
        >>> import asyncio
        >>> asyncio.run(ssh_connect("my-server", "cmd_xxx"))

    Note:
        Requires a TTY for interactive operation.
        Press Ctrl+D to disconnect gracefully.
    """
    from cmdop import AsyncCMDOPClient

    # Check for TTY
    if not is_tty():
        print("Error: ssh_connect requires an interactive terminal (TTY)", file=sys.stderr)
        return 1

    try:
        async with AsyncCMDOPClient.remote(api_key=api_key) as client:
            # Find session if not provided
            if session_id is None:
                session = await client.terminal.get_active_session(hostname=hostname)
                if session is None:
                    print(f"Error: No active session found for '{hostname}'", file=sys.stderr)
                    return 1
                session_id = session.session_id
                print(f"Connecting to {session.machine_hostname}...")

            # Create stream
            stream = client.terminal.stream()

            # Setup output handler
            def on_output(data: bytes) -> None:
                """Write output to stdout."""
                sys.stdout.buffer.write(data)
                sys.stdout.buffer.flush()

            def on_error(code: str, message: str, is_fatal: bool) -> None:
                """Handle stream errors."""
                print(f"\nError: {code}: {message}", file=sys.stderr)
                if is_fatal:
                    stream._shutdown.set()

            def on_disconnect(reason: str) -> None:
                """Handle disconnection."""
                print(f"\nDisconnected: {reason}")

            stream.on_output(on_output)
            stream.on_error(on_error)
            stream.on_disconnect(on_disconnect)

            # Connect stream
            try:
                await stream.connect()
                await stream.wait_ready()
            except Exception as e:
                print(f"Connection failed: {e}", file=sys.stderr)
                return 1

            print("Connected. Press Ctrl+D to disconnect.\n")

            # Run terminal loop
            exit_code = await _run_terminal_loop(stream)

            # Close stream
            await stream.close("user_disconnect")

            return exit_code

    except KeyboardInterrupt:
        print("\nInterrupted.")
        return 130  # Standard exit code for SIGINT


async def _run_terminal_loop(stream: TerminalStream) -> int:
    """
    Run the main terminal I/O loop.

    Args:
        stream: Connected terminal stream.

    Returns:
        Exit code.
    """
    import select

    # Enter raw mode
    if not enter_raw_mode():
        print("Warning: Could not enter raw mode", file=sys.stderr)

    # Setup resize handler
    async def on_resize(cols: int, rows: int) -> None:
        """Forward resize to remote."""
        try:
            await stream.send_resize(cols, rows)
        except Exception:
            pass

    def resize_callback(cols: int, rows: int) -> None:
        """Sync wrapper for async resize handler."""
        asyncio.create_task(on_resize(cols, rows))

    setup_resize_handler(resize_callback)

    # Send initial size
    cols, rows = get_terminal_size()
    try:
        await stream.send_resize(cols, rows)
    except Exception:
        pass

    try:
        # Main input loop
        while stream.is_connected:
            # Check for input with timeout (non-blocking)
            try:
                readable, _, _ = select.select([sys.stdin], [], [], 0.05)
            except (ValueError, OSError):
                # stdin closed or invalid
                break

            if readable:
                try:
                    # Read raw input
                    data = sys.stdin.buffer.read1(1024)  # type: ignore
                except AttributeError:
                    # Fallback for stdin without read1
                    data = sys.stdin.buffer.read(1)

                if not data:
                    # EOF (Ctrl+D)
                    break

                # Check for Ctrl+D (ASCII 4)
                if b"\x04" in data:
                    break

                # Send input to remote
                try:
                    await stream.send_input(data)
                except Exception as e:
                    print(f"\nSend error: {e}", file=sys.stderr)
                    break

            # Small sleep to prevent busy loop
            await asyncio.sleep(0.01)

        return 0

    except asyncio.CancelledError:
        return 0
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        return 1
    finally:
        # Restore terminal
        exit_raw_mode()
        print()  # Newline after exit


async def ssh_execute(
    hostname: str,
    command: str,
    api_key: str,
    timeout: float = 30.0,
) -> tuple[bytes, int]:
    """
    Execute a command on remote machine via SSH-like connection.

    Non-interactive command execution that returns output.

    Args:
        hostname: Machine hostname to connect to.
        command: Command to execute.
        api_key: CMDOP API key.
        timeout: Maximum execution time in seconds.

    Returns:
        Tuple of (output_bytes, exit_code).

    Example:
        >>> output, code = await ssh_execute("my-server", "ls -la", "cmd_xxx")
        >>> print(output.decode())
    """
    from cmdop import AsyncCMDOPClient

    async with AsyncCMDOPClient.remote(api_key=api_key) as client:
        # Find session
        session = await client.terminal.get_active_session(hostname=hostname)
        if session is None:
            raise ValueError(f"No active session found for '{hostname}'")

        # Execute command
        return await client.terminal.execute(
            command,
            timeout=timeout,
            session_id=session.session_id,
        )
