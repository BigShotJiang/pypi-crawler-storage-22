from cmdz import __version__

def version_command():
    print(f"cliz version {__version__}")