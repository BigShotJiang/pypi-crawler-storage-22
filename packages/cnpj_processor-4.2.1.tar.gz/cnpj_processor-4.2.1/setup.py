from setuptools import setup

# Toda configuração está em pyproject.toml
# setup.py mantido apenas para compatibilidade
setup()
