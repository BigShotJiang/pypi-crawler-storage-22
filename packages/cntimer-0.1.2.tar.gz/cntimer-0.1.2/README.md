# cntimer ⏱

Automatic execution time and memory tracker for Python scripts.

No code changes. No config. Just install — every script shows timing and memory automatically.

---

## Install

```bash
pip install cntimer
```

Every script you run will show:

```
────────────────────────────────────────────────────────────
  🕐 Time      21.4 ms       (cpu: 20.9 ms)
  📦 Memory    96 KB         (peak: 19.0 MB)
────────────────────────────────────────────────────────────
```

---

## How it works

When you `pip install cntimer`, it places a `cntimer.pth` file into your Python's
`site-packages` directory. Python automatically reads all `.pth` files on every
startup — which is what makes tracking work without any code changes.

---

## Manual install (if auto-install failed)

If you see a warning during `pip install`, copy `cntimer.pth` manually.

**Step 1 — Find your site-packages path:**

```bash
# Mac / Linux
python3 -c "import site; print(site.getsitepackages())"

# Windows
python -c "import site; print(site.getsitepackages())"
```

**Step 2 — Copy the file:**

### Mac
```bash
cp cntimer.pth /Library/Frameworks/Python.framework/Versions/3.x/lib/python3.x/site-packages/cntimer.pth
```

### Linux
```bash
sudo cp cntimer.pth /usr/lib/python3/dist-packages/cntimer.pth
```

### Windows 64-bit (x64) — run Command Prompt as Administrator
```
copy cntimer.pth "C:\Program Files\Python3xx\Lib\site-packages\cntimer.pth"
```

### Windows 32-bit (x86) — run Command Prompt as Administrator
```
copy cntimer.pth "C:\Program Files (x86)\Python3xx\Lib\site-packages\cntimer.pth"
```

### Windows ARM64 — run Command Prompt as Administrator
```
copy cntimer.pth "C:\Program Files\Python3xx\Lib\site-packages\cntimer.pth"
```

> Replace `3xx` / `3.x` with your actual Python version number (e.g. `312` for Python 3.12).

> **Tip:** Not sure which Windows version you have?  
> Run `python -c "import platform; print(platform.architecture(), platform.machine())"` — it will tell you.

---

## Uninstall

```bash
pip uninstall cntimer
```

Then delete `cntimer.pth` from your site-packages folder (same path as above).

---

## License

MIT
