import os
import sys
import shutil
import platform
import site
from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.develop import develop


def get_site_packages():
    candidates = []
    if hasattr(site, "getsitepackages"):
        candidates += site.getsitepackages()
    if hasattr(site, "getusersitepackages"):
        candidates.append(site.getusersitepackages())

    writable = [p for p in candidates if os.path.isdir(p) and os.access(p, os.W_OK)]

    if writable:
        for p in writable:
            if any(f.endswith(".pth") for f in os.listdir(p)):
                return p
        return writable[0]
    return None


def install_pth():
    # Find cntimer.pth relative to this setup.py
    here = os.path.dirname(os.path.abspath(__file__))
    src  = os.path.join(here, "cntimer.pth")

    # Also check inside the installed package (for wheel installs)
    if not os.path.exists(src):
        import cntimer
        src = os.path.join(os.path.dirname(cntimer.__file__), "..", "cntimer.pth")
        src = os.path.normpath(src)

    sp = get_site_packages()
    system  = platform.system()
    arch    = platform.architecture()[0]
    machine = platform.machine().lower()

    if sp and os.path.exists(src):
        dest = os.path.join(sp, "cntimer.pth")
        shutil.copy2(src, dest)
        print(f"\n[cntimer] ✅ Auto-tracking installed!")
        print(f"[cntimer]    Platform : {system} {arch} ({machine})")
        print(f"[cntimer]    Location : {dest}")
        print(f"[cntimer]    Every Python script will now show time + memory automatically.\n")
    else:
        print("\n[cntimer] ⚠️  Could not auto-install the tracking hook.")
        print(f"[cntimer]    Platform : {system} {arch} ({machine})")
        print(f"[cntimer]    To fix this, copy cntimer.pth manually:")
        if os.path.exists(src):
            print(f"[cntimer]    Source   : {src}")

        if system == "Windows":
            if "arm" in machine:
                variant = "ARM64"
                example = r"C:\Program Files\Python3xx\Lib\site-packages\cntimer.pth"
            elif arch == "32bit":
                variant = "32-bit (x86)"
                example = r"C:\Program Files (x86)\Python3xx\Lib\site-packages\cntimer.pth"
            else:
                variant = "64-bit (x64)"
                example = r"C:\Program Files\Python3xx\Lib\site-packages\cntimer.pth"
            print(f"[cntimer]    Detected : Windows {variant}")
            print(f"[cntimer]    Destination (example): {example}")
            print(f"[cntimer]    Find your exact path:")
            print(f"[cntimer]      python -c \"import site; print(site.getsitepackages())\"")
            print(f"[cntimer]    Then run Command Prompt as Administrator:")
            print(f"[cntimer]      copy cntimer.pth <your-site-packages-path>\\cntimer.pth")
        elif system == "Darwin":
            print(f"[cntimer]    Detected : macOS ({machine})")
            print(f"[cntimer]    Find your exact path:")
            print(f"[cntimer]      python3 -c \"import site; print(site.getsitepackages())\"")
            print(f"[cntimer]    Then run:")
            print(f"[cntimer]      cp cntimer.pth <your-site-packages-path>/cntimer.pth")
        else:
            print(f"[cntimer]    Detected : Linux ({machine})")
            print(f"[cntimer]    Find your exact path:")
            print(f"[cntimer]      python3 -c \"import site; print(site.getsitepackages())\"")
            print(f"[cntimer]    Then run:")
            print(f"[cntimer]      sudo cp cntimer.pth <your-site-packages-path>/cntimer.pth")

        print(f"\n[cntimer]    📖 Full guide: https://github.com/cntimer/cntimer#manual-install\n")


class Install(install):
    def run(self):
        super().run()
        install_pth()


class Develop(develop):
    def run(self):
        super().run()
        install_pth()


setup(
    name="cntimer",
    version="0.1.2",
    description="Automatic execution time and memory tracker for Python scripts.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.7",
    packages=find_packages(),
    # Include cntimer.pth in the package data so it's present after wheel install
    package_data={"cntimer": ["../cntimer.pth"]},
    data_files=[("", ["cntimer.pth"])],
    entry_points={
        "console_scripts": [
            "cntimer=cntimer.cli:main",
        ],
    },
    cmdclass={
        "install": Install,
        "develop": Develop,
    },
)
