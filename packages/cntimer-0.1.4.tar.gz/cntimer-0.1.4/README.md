# cntimer ⏱

[![PyPI version](https://badge.fury.io/py/cntimer.svg)](https://pypi.org/project/cntimer/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.7+](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)
[![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey.svg)](https://pypi.org/project/cntimer/)

**Automatic execution time and memory tracker for Python scripts.**

No code changes. No config. Just `pip install cntimer` — every script you run will automatically show timing and memory at the end, whether you use VSCode, terminal, or any Python runner.

---

## Install

```bash
pip install cntimer
```

That's it. Every Python script you run will show this automatically:

```
────────────────────────────────────────────────────────────
  🕐 Time      1.52 s        (cpu: 1.44 s)
  📦 Memory    31.2 MB       (peak: 62.4 MB)
────────────────────────────────────────────────────────────
```

---

## How it works

When you `pip install cntimer`, it places a `cntimer.pth` file into your Python's `site-packages` directory. Python automatically reads all `.pth` files on **every startup** — which is what makes tracking work with zero code changes.

- ✅ Works with VSCode Run button
- ✅ Works in terminal
- ✅ Works on Windows (x86, x64, ARM64), macOS, Linux
- ✅ No imports needed in your code

---

## Output explained

| Field | Meaning |
|---|---|
| 🕐 Time | Total wall-clock time (how long you waited) |
| cpu | CPU time — excludes sleep, I/O, network wait |
| 📦 Memory | Memory still in use when script finished |
| peak | Highest memory used at any point during execution |

If **Time** is much bigger than **cpu**, your script spent time waiting (file I/O, network, sleep).  
If they're close, your script is CPU-bound (pure computation).

---

## Manual install (if auto-install failed)

Find your site-packages path:

```bash
# Mac / Linux
python3 -c "import site; print(site.getsitepackages()[0])"

# Windows
python -c "import site; print(site.getsitepackages()[0])"
```

Then copy the file:

### macOS
```bash
cp cntimer.pth $(python3 -c "import site; print(site.getsitepackages()[0])")/cntimer.pth
```

### Linux
```bash
sudo cp cntimer.pth $(python3 -c "import site; print(site.getsitepackages()[0])")/cntimer.pth
```

### Windows 64-bit / ARM64 — run Command Prompt as Administrator
```
copy cntimer.pth "C:\Program Files\Python3xx\Lib\site-packages\cntimer.pth"
```

### Windows 32-bit — run Command Prompt as Administrator
```
copy cntimer.pth "C:\Program Files (x86)\Python3xx\Lib\site-packages\cntimer.pth"
```

> Replace `3xx` with your Python version (e.g. `312` for Python 3.12).

---

## Uninstall

```bash
pip uninstall cntimer
```

Then remove the `.pth` file:
```bash
# Mac / Linux
rm $(python3 -c "import site; print(site.getsitepackages()[0])")/cntimer.pth

# Windows (run as Administrator)
del "C:\Program Files\Python3xx\Lib\site-packages\cntimer.pth"
```

---

## License

[MIT](LICENSE) © 2026 tokitahmidtoufa
