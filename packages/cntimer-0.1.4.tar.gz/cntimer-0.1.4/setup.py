import os
import shutil
import platform
import site
import sysconfig
from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.develop import develop


def get_site_packages():
    # sysconfig.get_path("purelib") returns the site-packages of the
    # CURRENTLY RUNNING Python — which is always correct:
    # • base Python  → global site-packages
    # • inside venv  → the venv's site-packages
    # • pipx / conda → their own isolated site-packages
    primary = sysconfig.get_path("purelib")
    if primary and os.path.isdir(primary) and os.access(primary, os.W_OK):
        return primary

    # Fallback 1: sysconfig platlib (some platforms split pure/platform libs)
    platlib = sysconfig.get_path("platlib")
    if platlib and os.path.isdir(platlib) and os.access(platlib, os.W_OK):
        return platlib

    # Fallback 2: site.getsitepackages() list (skip if in venv to avoid
    # accidentally writing to the base Python when a venv is active)
    if hasattr(site, "getsitepackages") and not hasattr(sys, "real_prefix") \
            and not (hasattr(sys, "base_prefix") and sys.base_prefix != sys.prefix):
        for p in site.getsitepackages():
            if os.path.isdir(p) and os.access(p, os.W_OK):
                return p

    # Fallback 3: user site-packages (always writable, no sudo needed)
    if hasattr(site, "getusersitepackages"):
        user = site.getusersitepackages()
        os.makedirs(user, exist_ok=True)
        return user

    return None


def install_pth():
    import sys  # needs to be imported here for the venv check in fallback 2

    here = os.path.dirname(os.path.abspath(__file__))
    src  = os.path.join(here, "cntimer.pth")
    sp   = get_site_packages()

    system  = platform.system()
    arch    = platform.architecture()[0]
    machine = platform.machine().lower()

    if sp and os.path.exists(src):
        dest = os.path.join(sp, "cntimer.pth")
        shutil.copy2(src, dest)
        print(f"\n[cntimer] ✅ Auto-tracking installed!")
        print(f"[cntimer]    Platform : {system} {arch} ({machine})")
        print(f"[cntimer]    Location : {dest}")
        print(f"[cntimer]    Every Python script will now show time + memory automatically.\n")
    else:
        print("\n[cntimer] ⚠️  Could not auto-install the tracking hook.")
        print(f"[cntimer]    Platform : {system} {arch} ({machine})")
        if system == "Windows":
            if "arm" in machine:
                variant, example = "ARM64", r"C:\Program Files\Python3xx\Lib\site-packages\cntimer.pth"
            elif arch == "32bit":
                variant, example = "32-bit (x86)", r"C:\Program Files (x86)\Python3xx\Lib\site-packages\cntimer.pth"
            else:
                variant, example = "64-bit (x64)", r"C:\Program Files\Python3xx\Lib\site-packages\cntimer.pth"
            print(f"[cntimer]    Detected : Windows {variant}")
            print(f"[cntimer]    Run as Administrator: copy cntimer.pth \"{example}\"")
        elif system == "Darwin":
            print(f"[cntimer]    Run: cp cntimer.pth $(python3 -c \"import site; print(site.getsitepackages()[0])\")/cntimer.pth")
        else:
            print(f"[cntimer]    Run: sudo cp cntimer.pth $(python3 -c \"import site; print(site.getsitepackages()[0])\")/cntimer.pth")
        print(f"\n[cntimer]    📖 Full guide: https://github.com/tokitahmidtoufa/cntimer#manual-install\n")


class Install(install):
    def run(self):
        super().run()
        install_pth()


class Develop(develop):
    def run(self):
        super().run()
        install_pth()


setup(
    name="cntimer",
    version="0.1.4",
    packages=find_packages(),
    data_files=[("", ["cntimer.pth"])],
    entry_points={"console_scripts": ["cntimer=cntimer.cli:main"]},
    cmdclass={"install": Install, "develop": Develop},
)