# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2025 - 2026 BMO Soluciones, S.A.
"""Helper functions for managing planilla associations."""

from sqlalchemy import select
from sqlalchemy.sql.functions import count
from coati_payroll.model import (
    db,
    Nomina,
    Planilla,
    PlanillaEmpleado,
    PlanillaIngreso,
    PlanillaDeduccion,
    PlanillaPrestacion,
    PlanillaReglaCalculo,
)


def get_planilla_component_counts(planilla_id: str) -> dict:
    """Get counts of all components associated with a planilla.

    Returns a dictionary with counts for empleados, percepciones, deducciones,
    prestaciones, and reglas.
    """
    return {
        "empleados_count": db.session.execute(
            select(count()).select_from(PlanillaEmpleado).filter_by(planilla_id=planilla_id)
        ).scalar(),
        "percepciones_count": db.session.execute(
            select(count()).select_from(PlanillaIngreso).filter_by(planilla_id=planilla_id)
        ).scalar(),
        "deducciones_count": db.session.execute(
            select(count()).select_from(PlanillaDeduccion).filter_by(planilla_id=planilla_id)
        ).scalar(),
        "prestaciones_count": db.session.execute(
            select(count()).select_from(PlanillaPrestacion).filter_by(planilla_id=planilla_id)
        ).scalar(),
        "reglas_count": db.session.execute(
            select(count()).select_from(PlanillaReglaCalculo).filter_by(planilla_id=planilla_id)
        ).scalar(),
    }


def get_nomina_counts_by_planilla(planilla_ids: list[str]) -> dict[str, int]:
    """Get nomina counts grouped by planilla id."""
    if not planilla_ids:
        return {}

    rows = db.session.execute(
        select(Nomina.planilla_id, count(Nomina.id))
        .where(Nomina.planilla_id.in_(planilla_ids))
        .group_by(Nomina.planilla_id)
    ).all()

    counts = {planilla_id: 0 for planilla_id in planilla_ids}
    counts.update({planilla_id: total for planilla_id, total in rows})
    return counts


def agregar_asociacion(
    planilla_id: str,
    tipo_componente: str,
    componente_id: str,
    datos_extra: dict | None = None,
    usuario: str | None = None,
) -> tuple[bool, str | None, str | None]:
    """Generic function to add any component association to a planilla.

    Args:
        planilla_id: ID of the planilla
        tipo_componente: Type of component ('percepcion', 'deduccion', 'prestacion', 'regla')
        componente_id: ID of the component to associate
        datos_extra: Additional data for the association (orden, prioridad, etc.)
        usuario: Username of the user creating the association

    Returns:
        Tuple of (success, error_message, association_id). If success is False, error_message is set.
    """
    datos_extra = datos_extra or {}
    usuario = usuario or "system"

    # Verify planilla exists
    planilla = db.session.get(Planilla, planilla_id)
    if not planilla:
        return False, "Planilla no encontrada", None

    if not componente_id:
        return False, f"Debe seleccionar una {tipo_componente}.", None

    tipo_componente = {
        "percepcion": "income",
        "deduccion": "deduction",
        "prestacion": "benefit",
    }.get(tipo_componente, tipo_componente)

    # Check for existing association based on type
    existing = None
    association_class = None
    filter_params = {"planilla_id": planilla_id}

    if tipo_componente == "income":
        association_class = PlanillaIngreso
        filter_params["percepcion_id"] = componente_id
    elif tipo_componente == "deduction":
        association_class = PlanillaDeduccion
        filter_params["deduccion_id"] = componente_id
    elif tipo_componente == "benefit":
        association_class = PlanillaPrestacion
        filter_params["prestacion_id"] = componente_id
    elif tipo_componente == "regla":
        association_class = PlanillaReglaCalculo
        filter_params["regla_calculo_id"] = componente_id
    else:
        return False, f"Tipo de componente desconocido: {tipo_componente}", None

    existing = db.session.execute(db.select(association_class).filter_by(**filter_params)).scalar_one_or_none()

    if existing:
        return False, f"La {tipo_componente} ya está asignada a esta planilla.", None

    # Create association based on type
    if tipo_componente == "income":
        orden = datos_extra.get("orden", 0)
        association = PlanillaIngreso(
            planilla_id=planilla_id,
            percepcion_id=componente_id,
            orden=orden,
            editable=True,
            activo=True,
            creado_por=usuario,
        )
    elif tipo_componente == "deduction":
        prioridad = datos_extra.get("prioridad", 100)
        es_obligatoria = datos_extra.get("es_obligatoria", False)
        association = PlanillaDeduccion(
            planilla_id=planilla_id,
            deduccion_id=componente_id,
            prioridad=prioridad,
            es_obligatoria=es_obligatoria,
            editable=True,
            activo=True,
            creado_por=usuario,
        )
    elif tipo_componente == "benefit":
        orden = datos_extra.get("orden", 0)
        association = PlanillaPrestacion(
            planilla_id=planilla_id,
            prestacion_id=componente_id,
            orden=orden,
            editable=True,
            activo=True,
            creado_por=usuario,
        )
    elif tipo_componente == "regla":
        orden = datos_extra.get("orden", 0)
        association = PlanillaReglaCalculo(
            planilla_id=planilla_id,
            regla_calculo_id=componente_id,
            orden=orden,
            activo=True,
            creado_por=usuario,
        )
    else:
        return False, f"Tipo de componente desconocido: {tipo_componente}", None

    db.session.add(association)
    db.session.commit()

    return True, None, association.id
