"""Setup script for the terminalai package."""
from setuptools import setup

# This setup.py is kept minimal and is used alongside pyproject.toml
# The actual package configuration is in pyproject.toml
setup(
    # All configuration is now in pyproject.toml
)
