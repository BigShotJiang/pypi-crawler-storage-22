__title__ = "tardis"
__package__ = "cobald-tardis"
__summary__ = "Transparent Adaptive Resource Dynamic Integration System"
__url__ = "https://github.com/matterminers/tardis"

__version__ = "0.9.0"
__author__ = "Manuel Giffels, Matthias Schnepf"
__email__ = "giffels@gmail.com"
__copyright__ = "2018 - 2026 %s and Contributors" % __author__
__keywords__ = "asyncio tardis cloud scheduler"
