# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

from enum import Enum

from cobalt.serialization import register_serializable_enum


class SelectionState(Enum):
    initial = "initial"
    selected = "selected"


@register_serializable_enum
class GroupType(Enum):
    user = "Saved Group"
    failure = "Failure Group"
    drift = "Drifted Group"
    cluster = "Cluster"
    node = "Node"
    any = "Group"


@register_serializable_enum
class RunType(Enum):
    """Type for GroupResultCollection."""

    MANUAL = "manual"
    AUTOMATIC = "automatic"


@register_serializable_enum
class ColumnDataType(Enum):
    numerical = "numerical"
    text = "text"
    datetime = "datetime"
    other = "other"
