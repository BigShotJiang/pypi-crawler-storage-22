# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.


import numpy as np
import pandas as pd
import pynndescent

from cobalt.schema.graph import HierarchicalCobaltGraph


class NNIndexGraph:
    def __init__(self, graph: HierarchicalCobaltGraph) -> None:
        if not isinstance(graph, HierarchicalCobaltGraph):
            raise TypeError("graph must be a HierarchicalCobaltGraph")
        if graph.embedding is None:
            raise ValueError("No embedding information available.")
        self.graph = graph
        self._index = None

    def _get_graph_source_data(self):
        subset = self.graph.subset
        embedding = self.graph.embedding
        if embedding is None:
            raise ValueError("No embedding information available.")
        source_data = embedding.get(subset)
        return source_data

    def _get_graph_metric(self) -> str:
        if hasattr(self.graph, "params") and "metric" in self.graph.params:
            metric = self.graph.params["metric"]
        elif hasattr(self.graph, "metric"):
            metric = self.graph.metric  # type: ignore
        elif self.graph.embedding is not None:
            metric = self.graph.embedding.default_distance_metric
        else:
            raise ValueError("No metric information available")

        if not isinstance(metric, str):
            if not getattr(metric, "nndescent_named_metric", None):
                if getattr(metric, "name", None):
                    raise ValueError(
                        f"Graph metric {metric.name} not supported for nearest neighbor index."
                    )
                else:
                    raise ValueError("graph.metric has unknown type")
            metric = metric.name
        return metric

    def compute_index(self):
        nhbrs = self.graph.raw_graph._neighbors
        source_data = self._get_graph_source_data()
        metric = self._get_graph_metric()
        self._index = pynndescent.NNDescent(
            source_data, metric=metric, init_graph=nhbrs
        )

    def get_index(self):
        return self._index

    def is_indexed(self):
        return self._index is not None

    def get_nearest_labels(
        self, X: np.ndarray, y: np.ndarray, n_neighbors: int = 5
    ) -> np.ndarray:
        """Returns labels of nearest neighbors for query X.

        Args:
            X (ndarray): array of query vectors of shape (n_queries, n_dimensions).
            y (ndarray): labels corresponding to the data in the underlying graph.
            n_neighbors (int): number of nearest neighbors to return.

        Returns:
            out (np.ndarray): nearest n_neighbors labels for each element in X.

        Notes:
        X must be a 2D array of shape (N, D), not a 1D vector of shape (D,).

        Finds the n_neighbors nearest neighbors in the index for each point in
        X, and returns the corresponding values in y.
        """
        # Consider conversion here.

        if len(X.shape) == 1:
            raise ValueError(
                "X should be 2-dimensional with shape (n_samples, n_dimensions)."
                f"X had shape {X.shape}."
            )

        if not isinstance(y, np.ndarray):
            y = np.array(y)

        source_data = self._get_graph_source_data()

        if len(y) != len(source_data):
            raise ValueError(
                f"len(y) ({len(y)}) should be equal to the number of "
                f"data points in the source graph ({len(source_data)})."
            )
        if not self.is_indexed():
            self.compute_index()
        descent = self.get_index()
        n, _ = descent.query(X, k=n_neighbors)
        return y[n]

    def make_prediction(
        self,
        X: np.ndarray,
        y: np.ndarray,
        is_classification: bool = True,
        n_neighbors: int = 5,
    ) -> np.ndarray:
        """Returns topological classification for input data X.

        Args:
            X (ndarray): Input array of shape (n_samples, n_dimensions).
            y (ndarray): Labels corresponding to training data (graph)
            is_classification (bool): Whether the task is classification or regression.
            n_neighbors (int): Number of neighbors to use when making predictions.

        Predictions are based on similarity to data points in the graph used to
        construct the NNIndexGraph object. Ground truth labels are provided in
        y, which must contain one entry for each data point in the original
        graph. X may have any number of data points but must have the same
        dimensionality as the data used to construct the original graph.

        If `is_classification`: return mode of nearest labels (i.e. a voting
        mechanism).  Otherwise, returns mean of nearest labels (regression
        problem).

        n_neighbors controls the number of nearest neighbors used to make the
        prediction.
        """
        nearest_labels = self.get_nearest_labels(X, y, n_neighbors)

        if is_classification:
            df = pd.DataFrame(nearest_labels)
            return df.mode(axis=1).to_numpy()[:, 0]
        else:
            return nearest_labels.mean(axis=1)
