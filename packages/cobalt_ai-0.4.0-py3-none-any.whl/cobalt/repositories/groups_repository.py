# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Dict, Optional, Sequence

from cobalt.schema.group import GroupMetadata
from cobalt.serialization import SerializableMixin

if TYPE_CHECKING:
    from cobalt.schema import CobaltDataSubset


class AbstractGroupRepository(ABC):
    @abstractmethod
    def __init__(self) -> None:
        """Initialize the repository."""
        raise NotImplementedError

    @abstractmethod
    def add_group(self, group: CobaltDataSubset, group_name: str):
        """Add a group with the given name."""
        raise NotImplementedError

    @abstractmethod
    def get_groups_info(self):
        """Return information about all groups."""
        raise NotImplementedError

    @abstractmethod
    def get_group(self, group_name: str):
        """Return a group by name, or all groups if no name is provided."""
        raise NotImplementedError

    def get_group_metadata(self, group_name: str):
        raise NotImplementedError

    @abstractmethod
    def get_groups(self):
        """Return a group by name, or all groups if no name is provided."""
        raise NotImplementedError

    def get_groups_metadata(self):
        raise NotImplementedError

    @abstractmethod
    def is_group_name_unique(self, group_name: str):
        """Check if a group name is unique."""
        raise NotImplementedError

    @abstractmethod
    def delete_group(self, group_name):
        """Delete a group by name."""
        raise NotImplementedError

    @abstractmethod
    def rename_group(self, old_name: str, new_name: str):
        """Rename group without changing order."""
        raise NotImplementedError


class GroupRepository(AbstractGroupRepository, SerializableMixin):
    _serialization_version = 1

    def __init__(self) -> None:
        self.saved_groups: Dict[str, CobaltDataSubset] = {}
        self.groups_info: Dict[str, int] = {}
        self.group_metadata: Dict[str, GroupMetadata] = {}

    def add_group(
        self,
        group: CobaltDataSubset,
        group_name: str,
        metadata: Optional[GroupMetadata] = None,
    ):
        self.groups_info[group_name] = len(group)
        self.saved_groups[group_name] = group
        if metadata:
            self.group_metadata[group_name] = metadata
        else:
            self.group_metadata[group_name] = GroupMetadata(group, group_name)

    def add_groups(self, groups_data: Sequence[Dict]):
        for group_data in groups_data:
            self.add_group(
                group_data["group"],
                group_data["group_name"],
                group_data.get("metadata"),
            )

    def get_groups_info(self):
        return self.groups_info

    def get_group(self, group_name: str):
        return self.saved_groups[group_name]

    def get_group_metadata(self, group_name: str):
        return self.group_metadata[group_name]

    def get_groups(self):
        return self.saved_groups

    def get_groups_metadata(self):
        return self.group_metadata

    def is_group_name_unique(self, group_name: str) -> bool:
        return group_name not in self.saved_groups

    def delete_group(self, group_name: str):
        if group_name in self.saved_groups:
            del self.saved_groups[group_name]
        if group_name in self.groups_info:
            del self.groups_info[group_name]
        if group_name in self.group_metadata:
            del self.group_metadata[group_name]

    def rename_group(self, old_name: str, new_name: str):
        if not old_name:
            # ToDo: add message about. ValueError ?
            return
        if not new_name:
            # ToDo: add message about. ValueError ?
            return
        if old_name == new_name:
            return

        if old_name not in self.saved_groups:
            return

        self.saved_groups = {
            new_name if k == old_name else k: v for k, v in self.saved_groups.items()
        }
        self.groups_info = {
            new_name if k == old_name else k: v for k, v in self.groups_info.items()
        }
        self.group_metadata = {
            new_name if k == old_name else k: v for k, v in self.group_metadata.items()
        }
        self.group_metadata[new_name].name = new_name

    def __data_dict__(self):
        return {
            "saved_groups": self.saved_groups,
            "groups_info": self.groups_info,
            "group_metadata": self.group_metadata,
        }

    @classmethod
    def __from_serializable_dict__(cls, d: dict) -> GroupRepository:
        inst = GroupRepository()
        d = d["__data__"]
        inst.saved_groups = d["saved_groups"]
        inst.groups_info = d["groups_info"]
        inst.group_metadata = d["group_metadata"]
        return inst
