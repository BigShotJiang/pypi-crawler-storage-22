from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import numpy as np
from mapper import CSRGraph, DataGraph, HierarchicalDataGraph, KNNGraph
from mapper.distances import Metric, NameOnlyMetric

from cobalt.schema.dataset import CobaltDataSubset
from cobalt.schema.embedding import Embedding
from cobalt.schema.group_collection import GroupCollection
from cobalt.schema.subset_collection import SubsetCollection
from cobalt.serialization import DictConstructibleMixin, SerializableMixin


class CobaltGraph(DictConstructibleMixin, SerializableMixin):
    """A single-resolution graph based on a dataset.

    Each node in the graph corresponds with a set of similar data points. Edges
    connect related groups of data points. ``CobaltGraph`` objects are
    usually obtained by selecting a particular resolution level from a
    ``HierarchicalCobaltGraph``.

    Attributes:
         subset: The ``CobaltDataSubset`` this graph was built from
         node_subsets: A ``SubsetCollection`` of the subsets for each node in the graph.
    """

    def __init__(self, graph: DataGraph, subset: CobaltDataSubset):
        self._graph = graph
        self.subset = subset
        self.node_subsets = SubsetCollection.from_indices(self.subset, graph.nodes)

    @property
    def N(self) -> int:
        """Total number of data points in the graph."""
        return self._graph.N

    @property
    def nodes(self) -> List[np.ndarray]:
        """List of node memberships. Each element is an array of indices into self.subset.

        Alias for self.node_sets.
        """
        return self.node_sets

    @property
    def node_sets(self) -> List[np.ndarray]:
        """List of node memberships. Each element is an array of indices into self.subset."""
        return self._graph.node_sets

    @property
    def node_membership(self) -> np.ndarray:
        """Array giving the node ID for each data point in self.subset."""
        return self._graph.node_membership

    @property
    def edge_list(self) -> List[tuple]:
        """List of edges as (source, target) tuples."""
        return self._graph.edge_list

    @property
    def edge_mtx(self) -> np.ndarray:
        """Edge matrix as (n_edges, 2) array where each row is [source, target]."""
        return self._graph.edge_mtx

    @property
    def edge_weights(self) -> np.ndarray:
        """Array of edge weights."""
        return self._graph.edge_weights

    @property
    def edges(self) -> List[Dict[str, int]]:
        """List of edges as dicts with 'source','target', and 'weight' keys."""
        return self._graph.edges

    @property
    def n_edges(self) -> int:
        """Number of edges in the graph."""
        return self._graph.n_edges

    @property
    def csr_graph(self) -> CSRGraph:
        """The underlying sparse graph structure without information about data points."""
        return self._graph.csr_graph

    def induced_subgraph(self, node_indices: np.ndarray) -> CobaltGraph:
        """Create the subgraph induced by a collection of nodes.

        Also creates the corresponding subset of self.subset.
        """
        subgraph = self._graph.induced_subgraph(node_indices)
        subset = self.subset.mask(subgraph.node_membership != -1)
        subset_membership = subgraph.node_membership[subgraph.node_membership != -1]
        subset_subgraph = DataGraph(
            subgraph.csr_graph,
            node_membership=subset_membership,
        )

        return CobaltGraph(subset_subgraph, subset)

    def partition_modularity(self, partition_vec: np.ndarray) -> float:
        """Compute the graph modularity score of a partition of the graph nodes.

        The partition is specified as an integer array of length
        len(self.nodes), assigning each node a partition ID.
        """
        return self._graph.partition_modularity(partition_vec)

    def get_group_collection(self, name: Optional[str] = None) -> GroupCollection:
        """Convert the nodes of this graph to a GroupCollection.

        This can be used to quickly analyze each node as an individual group.
        """
        group_collection = GroupCollection.from_subset_collection(
            self.node_subsets, name=name
        )
        return group_collection

    def __repr__(self) -> str:
        return (
            f"CobaltGraph(n_nodes={len(self.nodes)}, "
            f"n_edges={self.n_edges}, subset_size={len(self.subset)})"
        )

    def __getattr__(self, name: str) -> Any:
        """Pass unknown attribute access through to the underlying graph."""
        return getattr(self._graph, name)

    _serialization_version = 1

    def __data_dict__(self) -> Dict:
        return {"graph": self._graph, "subset": self.subset}

    def __eq__(self, other):
        return self.subset == other.subset and self._graph == other._graph


class HierarchicalCobaltGraph(DictConstructibleMixin, SerializableMixin):
    """A hierarchical collection of graphs built from a dataset.

    Each graph in the collection is a ``CobaltGraph`` whose nodes correspond
    with subsets of the source data. These are hierarchically arranged, so that
    if i < j, each node in self.levels[j] is a union of nodes from
    self.levels[i].

    Attributes:
        levels: List of ``CobaltGraph`` objects, one per resolution level
        name: The name of the graph
        subset: The CobaltDataSubset this graph was built from
        params: Dictionary of parameters used to build this graph
        embedding: The Embedding object used to build the graph
        source_columns: List of column names used to build the graph
        base_graph: A very high-resolution ``CobaltGraph``, where nodes are
            as small as possible. May be higher resolution than self.levels[0].
    """

    def __init__(
        self,
        name: str,
        graph: HierarchicalDataGraph,
        subset: CobaltDataSubset,
        params: Optional[Dict[str, Any]] = None,
        embedding: Optional[Embedding] = None,
        source_columns: Optional[List[str]] = None,
    ) -> None:
        self.name = name
        self._graph = graph
        self.base_graph = CobaltGraph(graph.base_graph, subset)
        self.levels = [CobaltGraph(g, subset) for g in graph.levels]
        if params is None:
            params = {}
        base_graph_params = getattr(graph.base_graph, "params", {})
        self.params = {**base_graph_params, **params}
        self.subset = subset
        self.source_columns = source_columns or []
        self.embedding = embedding

    @property
    def n_levels(self) -> int:
        """Number of resolution levels in the hierarchical graph."""
        return self._graph.n_levels

    @property
    def raw_graph(self) -> Optional[KNNGraph]:
        """A nearest-neighbor graph giving raw distances between points.

        May not be available.
        """
        try:
            return self._graph.base_graph.raw_graph
        except AttributeError:
            return None

    @property
    def neighbor_graph(self) -> CobaltGraph:
        """A normalized neighbor graph mapping relationships between points.

        This is an alias for self.base_graph provided for backwards compatibility.
        """
        return self.base_graph

    @property
    def metric(self) -> Union[Metric, NameOnlyMetric]:
        return self._graph.base_graph.metric

    def __repr__(self) -> str:
        details = [
            f"name='{self.name}'",
            f"n_levels={self.n_levels}",
            f"subset_size={len(self.subset)}",
        ]
        if self.embedding:
            details.append(f"embedding={self.embedding.name}")
        details_str = ", ".join(details)
        return f"HierarchicalCobaltGraph({details_str})"

    # serialization implementation
    _serialization_version = 1

    def __data_dict__(self) -> Dict:
        return {
            "name": self.name,
            "graph": self._graph,
            "subset": self.subset,
            "params": self.params,
            "embedding": self.embedding,
            "source_columns": self.source_columns,
        }

    def __eq__(self, other):
        return (
            self.name == other.name
            and self.subset == other.subset
            and self._graph == other._graph
        )
