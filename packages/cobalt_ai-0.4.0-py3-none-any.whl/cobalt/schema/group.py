# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.
from __future__ import annotations

import contextlib
import itertools
from dataclasses import dataclass, field
from typing import (
    Any,
    ClassVar,
    Dict,
    List,
    Literal,
    Optional,
    Protocol,
    Sequence,
    Tuple,
    Union,
)
from uuid import UUID

import numpy as np
import pandas as pd

from cobalt.array_utils import get_bottom_k_indices
from cobalt.cobalt_types import ColumnDataType, GroupType
from cobalt.feature_compare import (
    categorical_feature_compare,
    feature_compare,
    feature_descriptions_from_tables,
    get_categorical_columns,
    get_numerical_features,
    numerical_feature_compare,
)
from cobalt.problem_group.group_labeling import (
    CategoricalHistogram,
    collate_categorical_histograms,
    get_column_distribution_categorical,
    short_feature_description_string,
)
from cobalt.schema.dataset import CobaltDataSubset, DatasetBase
from cobalt.schema.model_metadata import ModelMetadata, ModelTask
from cobalt.serialization import (
    DataclassSerializableMixin,
    DictConstructibleMixin,
    SerializableMixin,
)
from cobalt.text.group_explain import compare_groups_prompted
from cobalt.text.score_description import score_descriptions as run_score_descriptions
from cobalt.warnings_handler import error_if_no_llm_api


@dataclass
class GroupKeywords(DataclassSerializableMixin):
    col: str
    terms: Tuple[str, ...]
    scores: Tuple[float, ...]
    match_rate: Tuple[float, ...]
    params: Dict = field(default_factory=dict)

    _serialization_version: ClassVar[int] = 1

    def get_keyword_string(
        self, n_keywords: int = 3, min_match_rate: float = 0, delimiter: str = ", "
    ) -> str:
        # TODO: filter keywords for redundancy to make better names
        return delimiter.join(
            itertools.islice(
                (
                    t
                    for t, mr in zip(self.terms, self.match_rate)
                    if t and mr >= min_match_rate
                ),
                n_keywords,
            )
        )

    def __len__(self) -> int:
        return len(self.terms)

    def __repr__(self) -> str:
        return self.get_keyword_string(n_keywords=len(self.terms))


@dataclass
class GroupAutoDescription(DataclassSerializableMixin):
    col: str
    description: str
    precision_score: float
    recall_score: float
    f1_score: float
    params: Dict = field(default_factory=dict)

    _serialization_version: ClassVar[int] = 1


# TODO: refactor schema for better modularity and compatibility


@dataclass
class GroupComparisonStats(DataclassSerializableMixin):
    comparison_group: Union[
        Literal["all", "rest"], GroupMetadata
    ]  # ugh, this is a circular reference...
    comparison_group_name: str
    numerical_stats: pd.DataFrame
    categorical_stats: pd.DataFrame
    test: str

    _serialization_version: ClassVar[int] = 1


@dataclass
class GroupFeatureBounds(DataclassSerializableMixin):
    features: List[str]
    lower_bounds: List[Union[int, float]]
    upper_bounds: List[Union[int, float]]
    dataset_frac: np.ndarray

    _serialization_version: ClassVar[int] = 1


@dataclass
class GroupDisplayInfo(DataclassSerializableMixin):
    histograms: Dict[str, CategoricalHistogram] = field(default_factory=dict)
    """A collection of named histograms to display."""

    feature_descriptions: Dict[str, str] = field(default_factory=dict)
    """A collection of feature name => statistical summary pairs."""

    # TODO: this is redundant with GroupMetadata.comparison_stats?
    feature_stat_tables: Dict[str, pd.DataFrame] = field(default_factory=dict)
    """A set of named tables containing feature statistics on this group."""

    # TODO: should these be more specific?
    keyword_lists: Dict[str, List[str]] = field(default_factory=dict)
    """Lists of keywords for this group for each of a set of selected columns."""

    textual_descriptions: Dict[str, List[str]] = field(default_factory=dict)
    """One or more natural language descriptions for the content of selected columns."""

    visible: bool = True

    _serialization_version: ClassVar[int] = 1


@dataclass
class GroupMetadata(SerializableMixin, DictConstructibleMixin):
    subset: CobaltDataSubset
    """The data points included in this group."""

    name: Optional[str] = None
    """The group's name. Should be unique within a SubsetCollection."""

    metrics: Dict[str, float] = field(default_factory=dict)
    """Relevant numeric metrics for this group."""

    description: Optional[str] = None
    """A short description of the contents of the group."""

    display_info: GroupDisplayInfo = field(default_factory=GroupDisplayInfo)
    """Information to be displayed in the group explorer in the UI."""

    keywords: Dict[str, GroupKeywords] = field(default_factory=dict)
    """Distinctive keywords found in text columns in the group."""

    auto_descriptions: Dict[str, List[GroupAutoDescription]] = field(
        default_factory=dict
    )

    comparison_stats: Dict[str, GroupComparisonStats] = field(default_factory=dict)
    """Results of statistical tests comparing this group with others."""

    feature_bounds: Optional[GroupFeatureBounds] = None
    """Upper and lower bounds for individual features on this group."""

    group_type: GroupType = GroupType.any
    """Describes the semantic meaning of the group in context."""

    # TODO: should metrics be grouped by model, or at least have the option?

    other_fields: Dict[str, Any] = field(default_factory=dict)

    _serialization_version: ClassVar = 1

    def compute_comparison_stats(
        self,
        comparison_group: Union[Literal["all", "rest"], GroupMetadata],
        omit_columns: Optional[Sequence[str]] = None,
        set_description_string: bool = True,
        set_display_info: bool = True,
        test: Literal["t-test", "perm"] = "t-test",
    ):
        if comparison_group == "all":
            comparison_group_name = "all"
            comparison_subset: DatasetBase = self.subset.source_dataset
        elif comparison_group == "rest":
            comparison_group_name = "rest"
            comparison_subset = self.subset.complement()
        else:
            comparison_group_name = comparison_group.name
            comparison_subset = comparison_group.subset

        if omit_columns is not None:
            numerical_features = get_numerical_features(self.subset.source_dataset.df)
            numerical_features = list(set(numerical_features).difference(omit_columns))
            num_stats = numerical_feature_compare(
                self.subset, comparison_subset, numerical_features, test=test
            )
            categorical_features = get_categorical_columns(self.subset.source_dataset)
            categorical_features = list(
                set(categorical_features).difference(omit_columns)
            )
            cat_stats = categorical_feature_compare(
                self.subset, comparison_subset, categorical_features
            )
        else:
            num_stats, cat_stats = feature_compare(self.subset, comparison_subset)
        self.comparison_stats[comparison_group_name] = GroupComparisonStats(
            comparison_group=comparison_group,
            comparison_group_name=comparison_group_name,
            numerical_stats=num_stats,
            categorical_stats=cat_stats,
            test=test,
        )

        if set_description_string:
            self.description = short_feature_description_string(
                num_stats.rename(
                    {"mean A": "mean", "mean B": "complement mean"}, axis=1
                ),
                cat_stats,
            )

        if set_display_info and comparison_group_name == "rest":
            num_stats = (
                num_stats[num_stats["p-value"] <= 0.001]
                .iloc[: min(3, len(num_stats)), :]
                .copy()
                .rename({"mean A": "mean", "mean B": "complement mean"}, axis=1)
            )
            cat_stats = (
                cat_stats[
                    (cat_stats["p-value"] <= 0.001) & (cat_stats["frequency (%)"] >= 50)
                ]
                .iloc[: min(3, len(cat_stats)), :]
                .copy()
            )
            cat_stats["complement frequency (%)"] = [
                (comparison_subset.select_col(row["feature"]) == row["mode"]).mean()
                * 100
                for _, row in cat_stats.iterrows()
            ]
            self.display_info.feature_descriptions = feature_descriptions_from_tables(
                num_stats, cat_stats
            )
        # TODO: should this return something?

    def compute_feature_bounds(
        self,
        omit_columns: Optional[Sequence[str]] = None,
    ):
        if omit_columns is None:
            omit_columns = set(self.subset.metadata.hidable_columns)
        else:
            omit_columns = set(omit_columns)

        columns = [
            c
            for c in self.subset.df.columns
            if c not in omit_columns
            and (
                self.subset.metadata.data_types[c].col_type == ColumnDataType.numerical
            )
            and not self.subset.metadata.data_types[c].explicit_categorical
        ]

        # No need to do anything if there are no numeric columns
        if not columns:
            return

        subset_df = self.subset.df[columns]
        col_max = subset_df.max(axis=0)
        col_min = subset_df.min(axis=0)
        source_df = self.subset.source_dataset.df[columns]
        # somehow this is like 100x faster than the vectorized version
        # at least for large numbers of columns
        ds_in_bounds = pd.concat(
            [source_df[c].between(col_min[c], col_max[c]) for c in columns], axis=1
        )
        dataset_frac = ds_in_bounds.mean(axis=0)

        self.feature_bounds = GroupFeatureBounds(
            features=list(columns),
            lower_bounds=col_min.tolist(),
            upper_bounds=col_max.tolist(),
            dataset_frac=dataset_frac.to_numpy(),
        )

        top_features = get_bottom_k_indices(-dataset_frac, 3)
        dataset_frac_threshold = min(
            50 * len(self.subset) / len(self.subset.source_dataset), 0.25
        )
        descriptions = {
            f"{columns[i]} ": (
                (
                    f">= {col_min.iloc[i]:.3g}, <= {col_max.iloc[i]:.3g} "
                    if col_min.iloc[i] < col_max.iloc[i]
                    else f"= {col_min.iloc[i]:.3g} "
                )
                + f"({dataset_frac.iloc[i] * 100:.1f}% of data)"
            )
            for i in top_features
            if dataset_frac.iloc[i] <= dataset_frac_threshold
        }
        self.display_info.feature_descriptions.update(descriptions)

        return self.feature_bounds

    # TODO: add color map for histogram.
    def add_categorical_histograms_for_columns(
        self,
        columns: Sequence[str],
        histogram_titles: Sequence[str],
        collate_categories: bool = False,
        max_n_cats: int = 6,
    ):
        histograms = [
            get_column_distribution_categorical(self.subset, c) for c in columns
        ]
        if collate_categories:
            collate_categorical_histograms(histograms, max_n_cats=max_n_cats)
        else:
            for h in histograms:
                collate_categorical_histograms([h], max_n_cats=max_n_cats)

        for title, hist in zip(histogram_titles, histograms):
            self.display_info.histograms[title] = hist

    def add_model_data_histograms(self, model: ModelMetadata, max_n_classes: int = 6):
        if model.task != ModelTask.classification:
            return
        columns = []
        titles = []
        if model.outcome_column:
            columns.append(model.outcome_column)
            titles.append(f"Label Distribution ({model.outcome_column})")
        if model.prediction_column:
            columns.append(model.prediction_column)
            titles.append(f"Prediction Distribution ({model.prediction_column})")
        if len(columns) == 0:
            return
        self.add_categorical_histograms_for_columns(
            columns, titles, collate_categories=True, max_n_cats=max_n_classes
        )

    def add_group_description_from_keywords(
        self, keyword_column: str, include_col_name_in_description: bool = False
    ):
        keyword_string = self.keywords[keyword_column].get_keyword_string(
            delimiter=" | "
        )
        prefix = (
            f"Keywords ({keyword_column})"
            if include_col_name_in_description
            else "Keywords"
        )
        self.description = f"{prefix}: {keyword_string}"

    def get_autodescriptions(
        self,
        column: str,
        n_descriptions: int = 1,
        descriptions_per_prompt: int = 1,
        n_samples: int = 10,
        max_sample_length: int = 250,
        set_description: bool = True,
        score_descriptions: bool = False,
        seed: int = 582,
        description_model: str = "gpt-4.1",
        scoring_model: str = "gpt-4.1-mini",
    ) -> List[GroupAutoDescription]:
        """Use an LLM to generate hypotheses for properties that distinguish this group from others.

        This works by sampling a number of documents from the group and
        prompting the LLM to describe a feature present in the documents in the
        sample but not present in a sample of documents not in the group.

        Models provided through the OpenAI API are currently supported. To use
        this functionality, you must first configure your API key, either by
        calling ``cobalt.setup_api_client()`` or setting the `OPENAI_API_KEY`
        environment variable.

        Args:
            column: The column of the dataset containing the documents to describe.
            n_descriptions: The number of descriptions to generate for the
                group. Each description will be generated with a fresh sample of
                documents, so generating multiple descriptions can increase the
                likelihood of finding useful hypotheses.
            descriptions_per_prompt: The number of descriptions to generate for
                each sample. This must be a divisor of n_descriptions.
            n_samples: The number of documents from the group to sample and use
                in the prompt for each description.
            max_sample_length: The maximum number of characters to include from
                each sampled document. This puts an upper bound on the cost of each
                API call.
            set_description: Whether to use the generated descriptions to set
                the group's primary description. If score_descriptions is True, the
                description with the highest F1-score will be used; otherwise the
                first description returned will be used.
            score_descriptions: Whether to evaluate the quality of the generated
                descriptions. Description scoring is done by selecting a set of
                samples from the group and a set of samples from the rest of the
                dataset, and prompting a model to evaluate whether the description
                accurately captures each sample. This is treated as a classifier
                distinguishing between documents in the group and documents not in
                the group, and the precision, recall, and F1-score are reported.
            seed: Used to control the samples from each group. Does not affect
                the LLM sampling.
            description_model: Which model to use to generate descriptions.
            scoring_model: Which model to use to score descriptions.
        """
        error_if_no_llm_api()
        descriptions = compare_groups_prompted(
            self,
            "rest",
            column=column,
            n_samples=n_samples,
            seed=seed,
            n_prompts=n_descriptions // descriptions_per_prompt,
            n_responses=descriptions_per_prompt,
            model=description_model,
        )

        if score_descriptions:
            scores = run_score_descriptions(
                self,
                "rest",
                descriptions=descriptions,
                column=column,
                n_samples=2 * n_samples,
                max_sample_length=max_sample_length,
                model=scoring_model,
            )
        else:
            scores = [(0, 0, 0) for description in descriptions]

        description_objects = [
            GroupAutoDescription(column, description, precision, recall, fscore)
            for description, (precision, recall, fscore) in zip(descriptions, scores)
        ]
        description_objects.sort(key=lambda x: x.f1_score, reverse=True)

        self.auto_descriptions[column] = description_objects

        if set_description:
            self.description = description_objects[0].description
            self.display_info.textual_descriptions[column] = [
                d.description for d in description_objects
            ]

        return description_objects

    def __getattr__(self, name):
        try:
            return self.other_fields[name]
        except KeyError:
            raise AttributeError(
                f"{self.__class__.__name__} object has no attribute {name!r}"
            ) from None

    def __repr__(self) -> str:
        return f"GroupMetadata(name={self.name!r}, keywords={self.keywords!r})"

    def __eq__(self, other):
        return self is other

    def __hash__(self):
        return id(self)

    def __data_dict__(self):
        d = {
            "subset": self.subset,
            "name": self.name,
            "metrics": self.metrics,
            "description": self.description,
            "display_info": self.display_info,
            "keywords": self.keywords,
            "auto_descriptions": self.auto_descriptions,
            "comparison_stats": self.comparison_stats,
            "group_type": self.group_type,
            "feature_bounds": self.feature_bounds,
            "other_fields": self.other_fields,  # TODO: this may not be serializable
        }
        return d

    @classmethod
    def __from_serializable_dict__(cls, d: dict):
        data = d["__data__"]
        return cls(**data)


class Group(Protocol):
    name: Optional[str]
    subset: CobaltDataSubset
    summary: str
    metrics: Dict[str, float]
    group_details: GroupDisplayInfo
    visible: bool = True
    run_id: Optional[UUID] = None


@dataclass
class ProblemGroup(GroupMetadata):
    """A group representing a problem with a model."""

    problem_description: str = ""
    """A brief description of the problem."""

    severity: float = 1.0
    """A score representing the degree of seriousness of the problem.

    Used to sort a collection of groups. Typically corresponds to the value of a
    performance metric on the group, and in general is only comparable within
    the result set of a single algorithm run.
    """

    primary_metric: Optional[str] = None
    """The main metric used to evaluate this group."""

    visible: bool = True
    run_id: Optional[UUID] = None

    _serialization_version: ClassVar[int] = 1

    @property
    def group_details(self) -> GroupDisplayInfo:
        return self.display_info

    @group_details.setter
    def group_details(self, val):
        self.display_info = val

    @property
    def summary(self) -> str:
        return self.description or ""

    @summary.setter
    def summary(self, val):
        self.description = val

    def __post_init__(self):
        if self.primary_metric is None:
            # assume the first metric in the dict is the main one to use
            with contextlib.suppress(StopIteration):
                self.primary_metric = next(iter(self.metrics.keys()))
        if self.problem_description == "" and self.primary_metric:
            self.problem_description = (
                f"{len(self.subset)} points | "
                f"{self.primary_metric}: {self.metrics[self.primary_metric]:.3g}"
            )

    # This is not a strict __repr__() method since it can't be used to reinstantiate the object
    # but that wouldn't be easily possible anyway
    # We use __repr__() instead of __str__() so that it controls the default
    # rendering when a ProblemGroup is in the output of a Jupyter cell.
    def __repr__(self):
        return (
            f"ProblemGroup(name={self.name!r}, "
            f"subset={self.subset.__class__.__name__}(n_points={len(self.subset)}), "
            f"problem_description={self.problem_description!r}, "
            f"metrics={self.metrics})"
        )

    def __eq__(self, other):
        return self is other

    def __hash__(self):
        return id(self)

    def __data_dict__(self):
        d = super().__data_dict__()
        d["problem_description"] = self.problem_description
        d["severity"] = self.severity
        d["primary_metric"] = self.primary_metric
        d["visible"] = self.visible
        d["run_id"] = self.run_id.hex if self.run_id else None
        return d

    @classmethod
    def __from_serializable_dict__(cls, d: dict):
        data = d["__data__"]
        run_id = data["run_id"]
        if run_id:
            data["run_id"] = UUID(run_id)
        return cls(**data)


@dataclass
class Cluster(GroupMetadata, SerializableMixin):
    problem_description: str = ""
    visible: bool = True
    run_id: Optional[UUID] = None

    _serialization_version: ClassVar[int] = 1

    @property
    def group_details(self) -> GroupDisplayInfo:
        return self.display_info

    @group_details.setter
    def group_details(self, val):
        self.display_info = val

    @property
    def summary(self) -> str:
        return self.description or ""

    @summary.setter
    def summary(self, val):
        self.description = val

    def __repr__(self):
        return f"Cluster(subset={self.subset.__class__.__name__}(n_points={len(self.subset)}))"

    def __eq__(self, other):
        return self is other

    def __hash__(self):
        return id(self)

    def __data_dict__(self):
        d = super().__data_dict__()
        d["problem_description"] = self.problem_description
        d["visible"] = self.visible
        d["run_id"] = self.run_id.hex if self.run_id else None
        return d

    @classmethod
    def __from_serializable_dict__(cls, d: dict):
        data = d["__data__"]
        run_id = data["run_id"]
        if run_id:
            data["run_id"] = UUID(run_id)
        return cls(**data)
