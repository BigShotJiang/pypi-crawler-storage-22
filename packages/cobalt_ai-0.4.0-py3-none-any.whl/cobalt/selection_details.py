# Copyright (C) 2023-2026 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

import ipyvuetify as v

from cobalt.config import handle_cb_exceptions
from cobalt.schema import CobaltDataSubset
from cobalt.selection_manager import SelectionState
from cobalt.state import State


class SelectionDetails(v.Flex):
    def __init__(self, selection_manager, state, on_source_change=None):
        super().__init__()
        self.state: State = state
        self.selection_manager = selection_manager
        self.bind_selection_manager()
        self.on_source_change = on_source_change
        self.initialize_ui()

    def initialize_ui(self):
        self.tag = "div"
        self.count_chip = v.Chip(
            children=["No selection"],
            color="grey lighten-3",
            small=True,
            class_="mr-2",
        )

        self.source_chip = v.Chip(
            children=[""],
            color="blue lighten-4",
            small=True,
            class_="mr-2",
        )
        self.source_chip.class_list.add("d-none")

        self.dataset_chip = v.Chip(
            children=[""],
            color="green lighten-4",
            small=True,
        )
        self.dataset_chip.class_list.add("d-none")

        self.class_ = "d-flex align-center flex-grow-0 mr-2"
        self.style_ = "font-size: 14px"
        body = [
            self.count_chip,
            self.source_chip,
            self.dataset_chip,
        ]

        self.children = body

    def bind_selection_manager(self):
        self.selection_manager.on_graph_select(self.update_details_from_graph)
        self.selection_manager.on_group_select(self.update_details_from_group)

    def get_selection_source_dataset(self):
        """Get the dataset name of the current selection source."""
        if self.selection_manager.selection_state == SelectionState.initial:
            return None

        # Graph selection takes precedence over group selection
        graph_selection = self.selection_manager.graph_selection
        if graph_selection and len(graph_selection) > 0:
            return graph_selection.source_dataset.name

        if self.selection_manager.group_selection:
            subset = self.selection_manager.group_selection.get("subset")
            if subset:
                return subset.source_dataset.name

        return None

    @handle_cb_exceptions
    def update_details_from_graph(self, selection: CobaltDataSubset):
        if self.selection_manager.selection_state == SelectionState.initial:
            # no selection
            num_points = 0
            self.source_chip.class_list.add("d-none")
            self.dataset_chip.class_list.add("d-none")
        else:
            num_points = len(selection)

            graph_name = "Graph"
            # First check if we have a tracked graph name from the selection
            if (
                hasattr(self.selection_manager, "graph_selection_source_graph_name")
                and self.selection_manager.graph_selection_source_graph_name
            ):
                graph_name = (
                    f"Graph: {self.selection_manager.graph_selection_source_graph_name}"
                )
            # Fallback to the first visualization's graph name
            elif (
                hasattr(self.selection_manager, "visualization")
                and self.selection_manager.visualization
                and hasattr(
                    self.selection_manager.visualization, "visualization_selector"
                )
            ):
                viz_name = (
                    self.selection_manager.visualization.visualization_selector.v_model
                )
                if viz_name:
                    graph_name = f"Graph: {viz_name}"

            self.source_chip.children = [graph_name]
            self.source_chip.class_list.remove("d-none")

            self._update_dataset_chip(selection)

        self.update_selected_number_of_points(num_points)

        if self.on_source_change:
            self.on_source_change("Graph")

    @handle_cb_exceptions
    def update_details_from_group(self, selected_item):
        if selected_item:
            group_id = selected_item.get("group_id")
            subset = selected_item.get("subset")

            number_of_points = len(subset) if subset else 0
            self.update_selected_number_of_points(number_of_points)

            self.source_chip.children = [f"Group: {group_id}"]
            self.source_chip.class_list.remove("d-none")

            self._update_dataset_chip(subset)

            if self.on_source_change:
                self.on_source_change(group_id)

    def _update_dataset_chip(self, subset: CobaltDataSubset):
        dataset_collection = self.state.dataset_collection
        if len(dataset_collection.datasets) > 1 and subset:
            dataset_name = subset.source_dataset.name
            self.dataset_chip.children = [f"Dataset: {dataset_name}"]
            self.dataset_chip.class_list.remove("d-none")
        else:
            self.dataset_chip.class_list.add("d-none")

    def update_selected_number_of_points(self, points: int):
        """Update the number of selected points. Called by UI components."""
        if points > 0:
            self.count_chip.children = [f"{points} points"]
            self.count_chip.color = "primary"
        else:
            self.count_chip.children = ["No selection"]
            self.count_chip.color = "grey lighten-3"

    def update_selection_source(self, source):
        """Update the selection source. Called by UI components."""
        if source:
            self.source_chip.children = [source]
            self.source_chip.class_list.remove("d-none")
        else:
            self.source_chip.class_list.add("d-none")
        if self.on_source_change:
            self.on_source_change(source)
