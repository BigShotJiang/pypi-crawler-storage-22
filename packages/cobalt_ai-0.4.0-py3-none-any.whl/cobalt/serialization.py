# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

from __future__ import annotations

import base64
import json
from abc import abstractmethod
from enum import Enum, EnumMeta
from io import BytesIO, StringIO
from typing import TYPE_CHECKING, Any, Dict, Optional, Protocol, Type, TypeVar

import mapper
import numpy as np
import pandas as pd
import pyarrow
import scipy.sparse as sp
from mapper.serialization import (
    NP_SERIALIZATION_VERSION,
    SP_SERIALIZATION_VERSION,
    np_from_dict,
    np_to_bytes,
    sp_from_dict,
    sp_to_bytes,
)

DATAFRAME_SERIALIZATION_VERSION = 1
NP_OBJ_SERIALIZATION_VERSION = 1

if TYPE_CHECKING:
    from cobalt.schema.dataset import CobaltDataset, CobaltDataSubset
    from cobalt.schema.group import GroupMetadata


def df_from_dict(d: dict) -> pd.DataFrame:
    version = d.get("__version__")
    if version == 1:
        data = d["__data__"]
        if "parquet" in data:
            buffer = BytesIO(data["parquet"])
            df = pd.read_parquet(buffer)
        else:
            buffer = StringIO(data["csv"])
            df = pd.read_csv(buffer, index_col=None)
        df.index = data["index"]
    else:
        raise ValueError("Unknown serialization version for DataFrame.")
    return df


def df_to_dict(df: pd.DataFrame) -> dict:
    index = df.index.tolist()
    buffer = BytesIO()
    parquet = True
    try:
        df.to_parquet(buffer, engine="pyarrow")
    except pyarrow.ArrowException:
        # some things can't be saved in Parquet files
        parquet = False
        buffer = StringIO()
        df.to_csv(buffer, index=False)
    buffer.seek(0)

    if parquet:
        data = {"parquet": buffer.read(), "index": index}
    else:
        data = {"csv": buffer.read(), "index": index}

    return {
        "__class__": "pd_dataframe",
        "__version__": DATAFRAME_SERIALIZATION_VERSION,
        "__data__": data,
    }


def hierarchical_graph_from_dict(d: dict) -> mapper.HierarchicalDataGraph:
    version = d.get("__version__")
    if version == 1:
        data = d["__data__"]
        g = mapper.HierarchicalDataGraph.from_msgpack(data["graph"])
    else:
        raise ValueError("Unknown serialization version for HierarchicalDataGraph")
    return g


def data_graph_from_dict(d: dict) -> mapper.DataGraph:
    version = d.get("__version__")
    if version == 1:
        data = d["__data__"]
        g = mapper.DataGraph.from_msgpack(data)
    else:
        raise ValueError("Unknown serialization version for HierarchicalDataGraph")
    return g


def np_obj_from_dict(d: dict) -> np.ndarray:
    return np.array(d["__data__"], dtype=object)


def timestamp_from_dict(d: dict) -> pd.Timestamp:
    version = d.get("__version__")
    if version == 1:
        return pd.Timestamp(d["__data__"])
    else:
        raise ValueError("Unknown serialization version for pd.Timestamp")


class_decoders = {
    "ndarray": np_from_dict,
    "obj_ndarray": np_obj_from_dict,
    "sparsearray": sp_from_dict,
    "pd_dataframe": df_from_dict,
    "pd_timestamp": timestamp_from_dict,
    "HierarchicalDataGraph": hierarchical_graph_from_dict,
    "DataGraph": data_graph_from_dict,
}

with_datasets_class_decoders = {}

enum_encoders = {}
serializable_enums = []

SerializableT = TypeVar("SerializableT", bound="Serializable")
SerializableWithDatasetsT = TypeVar(
    "SerializableWithDatasetsT", bound="SerializableWithDatasets"
)


class Serializable(Protocol):
    # Represent the internal state of this object as a dict to be serialized.
    def __serializable_dict__(self) -> dict: ...

    # Construct an instance from the output of __serializable_dict__().
    @classmethod
    def __from_serializable_dict__(
        cls: Type[SerializableT], d: dict
    ) -> SerializableT: ...


class SerializableWithDatasets(Protocol):
    # Represent the internal state of this object as a dict to be serialized.
    def __serializable_dict__(self) -> dict: ...

    # Construct an instance from the output of __serializable_dict__().
    @classmethod
    def __from_serializable_dict__(
        cls: Type[SerializableT], d: dict, datasets: Dict[str, CobaltDataset]
    ) -> SerializableT: ...


class SerializableMixin:
    _serialization_version: int

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        class_decoders[cls.__name__] = cls.__from_serializable_dict__

    @abstractmethod
    def __data_dict__(self) -> dict:
        """A dict containing all information necessary to reinstantiate this object."""

    def __serializable_dict__(self) -> dict:
        """Represent the internal state of this object as a dict to be serialized."""
        return {
            "__class__": self.__class__.__name__,
            "__version__": self._serialization_version,
            "__data__": self.__data_dict__(),
        }

    @classmethod
    @abstractmethod
    def __from_serializable_dict__(
        cls: Type[SerializableT],
        d: dict,
    ) -> SerializableT:
        """Construct an instance from the output of __serializable_dict__()."""


class SerializableWithDatasetsMixin:
    _serialization_version: int

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        with_datasets_class_decoders[cls.__name__] = cls.__from_serializable_dict__

    @abstractmethod
    def __data_dict__(self) -> dict:
        """A dict containing all information necessary to reinstantiate this object."""

    def __serializable_dict__(self) -> dict:
        """Represent the internal state of this object as a dict to be serialized."""
        return {
            "__class__": self.__class__.__name__,
            "__version__": self._serialization_version,
            "__data__": self.__data_dict__(),
        }

    @classmethod
    def __from_serializable_dict__(
        cls: Type[SerializableWithDatasetsT],
        d: dict,
        datasets: Dict[str, CobaltDataset],
    ) -> SerializableWithDatasetsT: ...


def make_enum_encoder(enum: EnumMeta, version=1):
    def enc(x: Enum):
        return {"__class__": enum.__name__, "__version__": version, "__data__": x.value}

    return enc


def make_enum_decoder(enum: EnumMeta, version=1):
    def dec(d: dict):
        if d["__version__"] != version:
            raise ValueError(
                f"Incorrect serialization version {d['__version__']}. "
                f"Expected {version}."
            )
        return enum(d["__data__"])

    return dec


EnumT = TypeVar("EnumT", bound=EnumMeta)


def register_serializable_enum(*args, version: int = 1, encoder=None, decoder=None):
    def decorator(enum: EnumT) -> EnumT:
        if encoder is not None and decoder is not None:
            enum_encoders[enum.__name__] = encoder
            class_decoders[enum.__name__] = decoder
        else:
            enum_encoders[enum.__name__] = make_enum_encoder(enum, version=version)
            class_decoders[enum.__name__] = make_enum_decoder(enum, version=version)
        serializable_enums.append(enum)
        return enum

    if len(args) == 1:
        return decorator(*args)
    else:
        return decorator


class JSONSerializableMixin:
    """Adds to_json() and from_json() methods.

    The class must implement the Serializable protocol.
    """

    def to_json(self: Serializable) -> str:
        return json.dumps(self.__serializable_dict__(), default=default_encode)

    @classmethod
    def from_json(cls: Type[SerializableT], data: str) -> SerializableT:
        obj = json.loads(data, object_hook=object_hook)
        if not isinstance(obj, cls):
            raise ValueError(
                f"Incorrect object type {type(obj)}, "
                f"expected instance of {cls.__name__}"
            )
        return obj


DedictableT = TypeVar("DedictableT", bound="DictConstructibleMixin")


## DUE TO MRO, THIS MUST COME BEFORE SerializableMixin
class DictConstructibleMixin:
    """Adds __from_serializable_dict__() method.

    Assumes that the serialized dict has a __class__ and __version__ key, and
    that the contents of the __data__ key can be splatted into the class constructor.
    """

    _serialization_version: int

    @classmethod
    def __from_serializable_dict__(cls: Type[DedictableT], d: dict) -> DedictableT:
        if (cls_name := d.pop("__class__", None)) != cls.__name__:
            raise ValueError(f"Incorrect serialized object type {cls_name}.")
        if (ser_version := d.pop("__version__", None)) != cls._serialization_version:
            raise ValueError(
                f"Incorrect serialization version {ser_version}. "
                f"Expected {cls._serialization_version}."
            )
        return cls(**d["__data__"])


class SerializableWithVersion(Serializable, Protocol):
    _serialization_version: int


VersionedSerializableT = TypeVar(
    "VersionedSerializableT", bound="SerializableWithVersion"
)


class DataclassSerializableMixin(SerializableMixin):
    # this may or may not work well in general???
    def __data_dict__(self):
        return self.__dict__.copy()

    @classmethod
    def __from_serializable_dict__(
        cls: Type[VersionedSerializableT], d: dict
    ) -> VersionedSerializableT:
        if (cls_name := d.pop("__class__", None)) != cls.__name__:
            raise ValueError(f"Incorrect serialized object type {cls_name}.")
        if (ser_version := d.pop("__version__", None)) != cls._serialization_version:
            raise ValueError(
                f"Incorrect serialization version {ser_version}. "
                f"Expected {cls._serialization_version}."
            )
        return cls(**d["__data__"])


class SubsetLibrary(SerializableMixin):
    _serialization_version = 2

    def __init__(self):
        self.subset_to_id: Dict[CobaltDataSubset, int] = {}
        self.id_to_subset: Dict[int, CobaltDataSubset] = {}
        # Track which dataset each subset belongs to (by dataset name)
        self.subset_dataset_names: Dict[int, str] = {}
        self.next_subset_id = 0

    def add_subset(
        self, subset: CobaltDataSubset, dataset_name: str = "primary"
    ) -> int:
        """Add a subset to the library.

        Args:
            subset: The subset to add
            dataset_name: Name of the dataset this subset belongs to

        Returns:
            ID assigned to this subset
        """
        if subset in self.subset_to_id:
            return self.subset_to_id[subset]
        else:
            subset_id = self.next_subset_id
            self.subset_to_id[subset] = subset_id
            self.id_to_subset[subset_id] = subset
            self.subset_dataset_names[subset_id] = dataset_name
            self.next_subset_id += 1
            return subset_id

    def get_subset(self, subset_id: int) -> CobaltDataSubset:
        return self.id_to_subset[subset_id]

    def get_dataset_name(self, subset_id: int) -> str:
        """Get the dataset name for a subset."""
        return self.subset_dataset_names.get(subset_id, "primary")

    def __data_dict__(self):
        id_to_subset_data = {
            i: {
                "indices": subset.indices.tolist(),
                "dataset_name": self.subset_dataset_names.get(i, "primary"),
            }
            for i, subset in self.id_to_subset.items()
        }
        return id_to_subset_data

    @classmethod
    def from_dict(cls, d, dataset: CobaltDataset) -> SubsetLibrary:
        """Load SubsetLibrary from dict (backward compatible).

        Supports both v1 (single dataset) and v2 (multi-dataset) formats.
        """
        data = d["__data__"]
        library = SubsetLibrary()

        # Check if this is v1 format (just indices) or v2 format (with dataset_name)
        if data and isinstance(next(iter(data.values())), list):
            # Version 1: just indices, single dataset
            library.id_to_subset = {
                int(i): dataset.subset(indices) for i, indices in data.items()
            }
            library.subset_dataset_names = {int(i): "primary" for i in data}
        else:
            # Version 2: dict with indices and dataset_name
            library.id_to_subset = {
                int(i): dataset.subset(subset_data["indices"])
                for i, subset_data in data.items()
            }
            library.subset_dataset_names = {
                int(i): subset_data.get("dataset_name", "primary")
                for i, subset_data in data.items()
            }

        library.next_subset_id = max(library.id_to_subset.keys(), default=-1) + 1
        library.subset_to_id = {subset: i for i, subset in library.id_to_subset.items()}

        return library

    @classmethod
    def from_dict_multi(cls, d, datasets: Dict[str, CobaltDataset]) -> SubsetLibrary:
        """Load SubsetLibrary with multiple datasets.

        Args:
            d: Serialized dict
            datasets: Dict mapping dataset names to CobaltDataset objects
        """
        data = d["__data__"]
        library = SubsetLibrary()

        for i, subset_data in data.items():
            dataset_name = subset_data.get("dataset_name", "primary")
            if dataset_name not in datasets:
                raise ValueError(f"Dataset '{dataset_name}' not found")

            dataset = datasets[dataset_name]
            subset = dataset.subset(subset_data["indices"])
            library.id_to_subset[int(i)] = subset
            library.subset_dataset_names[int(i)] = dataset_name

        library.next_subset_id = max(library.id_to_subset.keys(), default=-1) + 1
        library.subset_to_id = {subset: i for i, subset in library.id_to_subset.items()}

        return library


class GroupLibrary:
    _serialization_version = 1

    def __init__(self):
        self.group_to_id: Dict[GroupMetadata, int] = {}
        self.id_to_group: Dict[int, GroupMetadata] = {}
        self.next_group_id = 0

    def add_group(self, group: GroupMetadata) -> int:
        if group in self.group_to_id:
            return self.group_to_id[group]
        else:
            group_id = self.next_group_id
            self.group_to_id[group] = group_id
            self.id_to_group[group_id] = group
            self.next_group_id += 1
            return group_id

    def get_group(self, group_id: int) -> GroupMetadata:
        return self.id_to_group[group_id]

    def __data_dict__(self):
        return self.id_to_group

    def __serializable_dict__(self) -> dict:
        """Represent the internal state of this object as a dict to be serialized."""
        return {
            "__class__": self.__class__.__name__,
            "__version__": self._serialization_version,
            "__data__": self.__data_dict__(),
        }

    @classmethod
    def from_dict(cls, d) -> GroupLibrary:
        id_to_group = d["__data__"]
        library = GroupLibrary()
        library.id_to_group = {int(i): group for i, group in id_to_group.items()}
        library.group_to_id = {group: i for i, group in library.id_to_group.items()}
        library.next_group_id = max(library.id_to_group.keys(), default=-1) + 1

        return library


def default_encode(obj: Any):
    if isinstance(obj, np.ndarray):
        if obj.dtype.kind == "O":
            return {
                "__class__": "obj_ndarray",
                "__version__": NP_OBJ_SERIALIZATION_VERSION,
                "__data__": obj.tolist(),
            }
        else:
            return {
                "__class__": "ndarray",
                "__version__": NP_SERIALIZATION_VERSION,
                "__data__": np_to_bytes(obj),
            }
    elif sp.issparse(obj):
        return {
            "__class__": "sparsearray",
            "__version__": SP_SERIALIZATION_VERSION,
            "__data__": sp_to_bytes(obj),
        }
    elif isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.bool_):
        return bool(obj)
    elif isinstance(obj, np.str_):
        return str(obj)
    elif isinstance(obj, np.bytes_):
        return bytes(obj)
    elif isinstance(obj, pd.Timestamp):
        return {
            "__class__": "pd_timestamp",
            "__version__": 1,
            "__data__": obj.isoformat(),
        }
    elif isinstance(obj, pd.DataFrame):
        return df_to_dict(obj)
    elif isinstance(obj, bytes):
        return {
            "__class__": "bytes",
            "__version__": 1,
            "__data__": base64.b64encode(obj).decode(),
        }
    elif type(obj) in serializable_enums:
        return enum_encoders[type(obj).__name__](obj)
    elif isinstance(obj, mapper.HierarchicalDataGraph):
        return {
            "__class__": "HierarchicalDataGraph",
            "__version__": 1,
            "__data__": {
                "graph": obj.to_msgpack(),
            },
        }
    elif isinstance(obj, mapper.DataGraph):
        return {
            "__class__": "DataGraph",
            "__version__": 1,
            "__data__": obj.to_msgpack(),
        }
    elif hasattr(obj, "__serializable_dict__"):
        return obj.__serializable_dict__()
    raise TypeError(f"Cannot serialize object of type {type(obj)}")


def get_json_default_for_subsets(
    subset_library: SubsetLibrary, group_library: Optional[GroupLibrary]
):

    def subset_default_encode(obj):
        nonlocal subset_library
        nonlocal group_library
        from cobalt.schema.group import GroupMetadata

        if obj.__class__.__name__ == "CobaltDataSubset":
            # For backward compatibility, use "primary" as default dataset name
            dataset_name = getattr(obj.source_dataset, "name", "primary") or "primary"
            subset_id = subset_library.add_subset(obj, dataset_name)
            return {
                "__class__": "_CobaltDataSubset__Ref",
                "__version__": 1,
                "__data__": subset_id,
            }
        elif group_library and isinstance(obj, GroupMetadata):
            group_id = group_library.add_group(obj)
            return {
                "__class__": "_GroupMetadata__Ref",
                "__version__": 1,
                "__data__": group_id,
            }
        else:
            return default_encode(obj)

    return subset_default_encode


def object_hook(obj: dict):
    obj_class = obj.get("__class__")
    if obj_class is None:
        return obj
    elif obj_class == "bytes":
        return base64.b64decode(obj["__data__"])
    try:
        decoder = class_decoders[obj_class]
        return decoder(obj)
    # obj_class might not be in the dict or it might be unhashable
    except (KeyError, TypeError):
        pass
    return obj


def get_object_hook_for_subsets(
    datasets: Dict[str, CobaltDataset],
    subset_library: SubsetLibrary,
    group_library: Optional[GroupLibrary],
):
    """Create an object hook for deserializing subsets and groups.

    Args:
        datasets: A dict mapping dataset names to CobaltDataset objects
        subset_library: Library for reconstituting subsets
        group_library: Optional library for reconstituting groups
    """

    def subset_object_hook(obj: dict):
        obj_class = obj.get("__class__")

        if obj_class == "_CobaltDataSubset__Ref":
            try:
                subset_id = obj["__data__"]
                return subset_library.get_subset(subset_id)
            except (KeyError, TypeError):
                pass
        if obj_class == "_GroupMetadata__Ref" and group_library is not None:
            try:
                group_id = obj["__data__"]
                return group_library.get_group(group_id)
            except (KeyError, TypeError):
                pass
        if obj_class in with_datasets_class_decoders:
            decoder = with_datasets_class_decoders[obj_class]
            return decoder(obj, datasets)

        return object_hook(obj)

    return subset_object_hook


def recursive_encode_data(d, encoder=default_encode):
    if isinstance(d, dict):
        return {k: recursive_encode_data(v, encoder) for k, v in d.items()}
    elif isinstance(d, (list, tuple)):
        return [recursive_encode_data(x, encoder) for x in d]
    elif isinstance(d, (str, int, float, bool)) or d is None:
        return d
    else:
        encoded_d = encoder(d)
        if encoded_d is d:
            raise TypeError(f"Could not serialize object of type {type(d)}")
        return recursive_encode_data(encoded_d, encoder)


def recursive_decode_data(d, decoder=object_hook):
    if isinstance(d, dict):
        return decoder({k: recursive_decode_data(v) for k, v in d.items()})
    if isinstance(d, list):
        return [recursive_decode_data(v) for v in d]
    return d
