from __future__ import annotations

import html
import unicodedata
from dataclasses import dataclass
from typing import Any, Callable, ClassVar, Dict, List, cast

import pandas as pd

from cobalt.cobalt_types import ColumnDataType
from cobalt.schema.metadata import DatasetColumnMetadata

numerical_filter_predicates: Dict[str, Callable[[pd.Series, Any], pd.Series]] = {
    "eq": lambda col, val: col == val,
    "gt": lambda col, val: col > val,
    "lt": lambda col, val: col < val,
    "gte": lambda col, val: col >= val,
    "lte": lambda col, val: col <= val,
}
text_filter_predicates: Dict[str, Callable[[pd.Series, str], pd.Series]] = {
    "is_case_sensitive_on": lambda col, val: col == val,
    "is_case_sensitive_off": lambda col, val: col.str.lower() == val.lower(),
    "contains_sensitive_off": lambda col, val: col.str.contains(
        val, case=False, na=False, regex=False
    ),
    "contains_sensitive_on": lambda col, val: col.str.contains(
        val, case=True, na=False, regex=False
    ),
}


class DataExplorerFilters:
    """Collection of filters scoped to the table explorer widgets."""

    filter_ops_map: ClassVar[
        Dict[ColumnDataType, Dict[str, Callable[[pd.Series, Any], pd.Series]]]
    ] = {
        ColumnDataType.numerical: numerical_filter_predicates,
        ColumnDataType.text: text_filter_predicates,
    }

    def __init__(self):
        self.filters: List[DataFilter] = []

    def add_filter(self, data_filter: DataFilter):
        self.filters.append(data_filter)

    def remove_filter(self, data_filter: DataFilter):
        for dfilter in self.filters:
            if dfilter == data_filter:
                self.filters.remove(dfilter)

    def clear(self):
        self.filters = []


@dataclass
class DataFilter:
    """Individual filter for data explorer column."""

    column: DatasetColumnMetadata
    op: str
    value: str

    def __post_init__(self):
        legal_ops = DataExplorerFilters.filter_ops_map[self.column.col_type]
        if self.op not in legal_ops:
            raise ValueError(f"op must be one of {list(legal_ops)}")

    def __eq__(self, other):
        if not isinstance(other, DataFilter):
            return False
        return (
            (self.column == other.column)
            and (self.op == other.op)
            and (self.value == other.value)
        )


def apply_filters_df(df: pd.DataFrame, data_filters: DataExplorerFilters):
    def apply_filter(data: pd.DataFrame, col: DatasetColumnMetadata, op: str, val):
        filter_ops_map = data_filters.filter_ops_map.get(col.col_type)
        if not filter_ops_map:
            return data
        if val == "nan" and op in [
            "is_case_sensitive_on",
            "eq",
            "gt",
            "lt",
            "gte",
            "lte",
        ]:
            filter_mask = data[col.name].isna()
            return data.loc[filter_mask]
        filter_op = filter_ops_map[op]
        column = df[col.name]
        if op in text_filter_predicates:
            column = normalize_apostrophes(column)
            val = normalize_apostrophes(val)

        column_series = cast(pd.Series, column)
        filter_mask = filter_op(column_series, val)
        return data.loc[filter_mask]

    # applies pandas filters to df one by one
    for data_filter in data_filters.filters:
        df = apply_filter(df, data_filter.column, data_filter.op, data_filter.value)
    return df


def normalize_apostrophes_text(text):
    """Normalize apostrophes and decode HTML entities."""
    if isinstance(text, str):
        text = html.unescape(text)  # Convert HTML entities (e.g., &#x27; → ')
        text = unicodedata.normalize("NFKC", text)
        text = text.replace("ʼ", "'")  # noqa: RUF001
        text = text.replace("’", "'")  # noqa: RUF001
        text = text.replace("ʹ", "'")  # noqa: RUF001
    return text


def normalize_apostrophes_series(column: pd.Series):
    """Normalize apostrophes and decode HTML entities for pd.Series.

    It works 10x faster than normalize_apostrophes + apply.
    """
    if isinstance(column.dtype, pd.CategoricalDtype):
        column = column.cat.add_categories([""]).fillna("")
    else:
        column = column.fillna("")  # html.unescape fails if there are NaNs
    series = column.apply(lambda x: html.unescape(x) if isinstance(x, str) else x)
    apostrophe_variants = r"[’ʼ`´ʹ]"  # noqa: RUF001
    return series.str.normalize("NFKC").str.replace(
        apostrophe_variants, "'", regex=True
    )


def normalize_apostrophes(obj):
    if isinstance(obj, str):
        return normalize_apostrophes_text(obj)
    elif isinstance(obj, pd.Series):
        return normalize_apostrophes_series(obj)
    return obj
