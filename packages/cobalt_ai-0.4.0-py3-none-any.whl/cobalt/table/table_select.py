# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

from threading import Timer
from typing import Dict, List, Optional, Tuple, Union
from uuid import UUID

import ipyvuetify as v
import ipywidgets as w
import pandas as pd

from cobalt.config import debug_logger, handle_cb_exceptions
from cobalt.groups.groups_ui import GroupSaveModal
from cobalt.schema.dataset import CobaltDataset, CobaltDataSubset
from cobalt.state import State
from cobalt.table.data_filters import DataFilter
from cobalt.table.filter_manager import TableFilterManager
from cobalt.table.filters_list import FiltersList
from cobalt.table.table_filter import TableFilter
from cobalt.table.table_view import TableView
from cobalt.ui_utils import with_tooltip
from cobalt.widgets import Autocomplete, Button


class TableSelector(w.VBox):
    """High-level container for table display and filtering.

    - Renders a table of data (via TableView).
    - Manages which columns are visible.
    - Integrates with TableFilter to apply filters via a TableFilterManager.
    - Refreshes the UI (table display) whenever filters or columns change.
    """

    def __init__(
        self,
        source_data: Union[CobaltDataset, CobaltDataSubset],
        state: State,
        workspace_id: Optional[UUID] = None,
        columns: Optional[List[str]] = None,
        image_columns: Optional[List[dict]] = None,
        html_columns: Optional[List[str]] = None,
        columns_to_filter: Optional[List[str]] = None,
        filter_criteria: Optional[Dict] = None,
        filter_manager: Optional[TableFilterManager] = None,
        image_size: Tuple[int, int] = (80, 80),
        max_rows_to_display: Optional[int] = None,
        run_server: bool = True,
        selection_details=None,
        user_selected_dataset: Optional[str] = None,
    ):
        super().__init__()
        self.original_selection = source_data  # Always store the original selection
        self.state = state
        self.workspace_id = workspace_id
        self.columns = columns
        self.image_size = image_size
        self.columns_to_filter = columns_to_filter
        self.filter_criteria = filter_criteria or {}
        self.show_filters = False
        self.max_rows_to_display = max_rows_to_display
        self.run_server = run_server
        self._debounce_timer = None
        self.selection_details = selection_details

        if user_selected_dataset is not None:
            self.user_selected_dataset = True
            self.selected_dataset_name = user_selected_dataset
        else:
            self.user_selected_dataset = False
            if isinstance(source_data, CobaltDataset):
                self.selected_dataset_name = source_data.name
            else:
                self.selected_dataset_name = source_data.source_dataset.name

        if user_selected_dataset is not None:
            self.source_data = self._translate_to_dataset(
                self.original_selection, user_selected_dataset
            )
        else:
            self.source_data = self.original_selection

        if image_columns is None:
            media_columns = self.source_data.metadata.media_columns
            self.image_columns = [
                img_col.autoname_media_visualization_column()
                for img_col in media_columns
            ]
        else:
            self.image_columns = image_columns

        if html_columns is None:
            self.html_columns = self.source_data.metadata.long_text_columns
        else:
            self.html_columns = html_columns

        if filter_manager is None:
            self.filter_manager = TableFilterManager(self.source_data.metadata)
        else:
            self.filter_manager = filter_manager
            self.filter_manager.update_metadata(self.source_data.metadata)

        self.df = self._get_data_from_source()

        self._initialize_widgets()
        self._setup_widget_list()
        self._check_and_open_filters()

    def _translate_to_dataset(
        self,
        source_data: Union[CobaltDataset, CobaltDataSubset],
        target_dataset_name: str,
    ) -> Union[CobaltDataset, CobaltDataSubset]:
        """Translate source_data to target dataset using links."""
        dataset_collection = self.state.dataset_collection
        from_ds = (
            source_data.name
            if isinstance(source_data, CobaltDataset)
            else source_data.source_dataset.name
        )

        link = dataset_collection.get_link(from_ds, target_dataset_name)

        if link is None:
            # No link exists, just show the target dataset directly
            return dataset_collection.datasets[target_dataset_name].as_subset()
        else:
            # Translate the selection to the target dataset
            selection = (
                source_data
                if isinstance(source_data, CobaltDataSubset)
                else source_data.as_subset()
            )
            return link.push_subset_to_right(selection)

    def _get_data_from_source(self) -> pd.DataFrame:
        data = self.source_data
        table_df = data.create_rich_media_table(run_server=self.run_server)
        filtered_df = self._filter_df(table_df)
        return filtered_df

    def _initialize_widgets(self):
        self.table_view = self._generate_table(self.workspace_id)
        self.select_all_text = "Select All"

        self._init_column_selector()
        self._setup_filtering()
        self._init_save_group_modal()

        self.filter_view = self._get_filter_view()

    def _init_column_selector(self):
        self.column_selector = Autocomplete(
            items=[self.select_all_text, *self.df.columns],
            v_model=self.columns,
            multiple=True,
            clearable=True,
            placeholder="All columns displayed by default. Adjust as needed.",
        )
        self.column_selector.on_event("change", self._on_change_with_debounce)

        self._init_dataset_selector()

    def _init_dataset_selector(self):
        """Initialize dataset selector dropdown if there are linked datasets."""
        from cobalt.widgets import Select

        dataset_collection = self.state.dataset_collection
        dataset_names = list(dataset_collection.datasets.keys())

        if len(dataset_names) > 1:
            self.dataset_selector = Select(
                items=dataset_names,
                v_model=self.selected_dataset_name,
                label="Dataset",
                style_="max-width: 200px;",
                autofocus=False,
            )
            self.dataset_selector.on_event("change", self._on_dataset_change)

            self.dataset_mismatch_icon = v.Icon(
                children=["mdi-link-variant"],
                color="info",
                small=True,
                style_="visibility: hidden;",
            )
            self.dataset_mismatch_indicator = v.Html(
                tag="div",
                class_="mx-1 d-flex align-center",
                children=[self.dataset_mismatch_icon],
                style_="min-width: 24px; justify-content: center;",
            )
        else:
            self.dataset_selector = None
            self.dataset_mismatch_indicator = None

    def _setup_filtering(self):
        filter_icon_button = Button(
            icon=True,
            children=[v.Icon(children=["mdi mdi-filter-variant"], color="primary")],
        )
        filter_icon_button.on_event("click", self._switch_filters_layout)

        self.filters_counter = v.Flex(
            children="",
            style_="position: absolute; right: 2px; bottom: 0px;",
        )

        filter_button_container = v.Flex(
            style_="max-width: 36px; height: 36px; position: relative;",
            class_="mx-4",
            children=[filter_icon_button, v.Flex(children=[self.filters_counter])],
        )

        self.filter_button_container_with_tooltip = with_tooltip(
            filter_button_container, "Show/Hide Filters"
        )

    def _init_save_group_modal(self):
        filtered_indices = self.state.dataset.df.index.get_indexer(self.df.index)
        self.filtered_subset = self.state.dataset.subset(filtered_indices)
        self.group_save_modal = GroupSaveModal(
            state=self.state, data_points=self.filtered_subset
        )
        self.group_save_modal_with_tooltip = with_tooltip(
            self.group_save_modal, "Create Group from Table Data"
        )

    def _setup_widget_list(self):
        self.main_area = v.Flex(class_="d-flex flex-column", children=[self.table_view])

        selector_children = []
        if self.dataset_selector is not None:
            selector_children.append(self.dataset_selector)
            if self.dataset_mismatch_indicator is not None:
                selector_children.append(self.dataset_mismatch_indicator)
        selector_children.extend(
            [
                self.column_selector,
                self.filter_button_container_with_tooltip,
                self.group_save_modal_with_tooltip,
            ]
        )

        self.selector_controls = v.Html(
            tag="div",
            children=selector_children,
            class_="d-flex align-center justify-center px-6",
        )

        self.children = [
            self.selector_controls,
            self.main_area,
        ]

        self._update_dataset_mismatch_indicator()

    def _check_and_open_filters(self):
        if self.filter_manager.has_filters():
            self.filters_counter.children = str(self.filter_manager.active_count())
            self._switch_filters_layout()

    def _on_change_with_debounce(self, widget, event, data, delay=1):
        self.update_columns(widget, event, data)

        if self._debounce_timer:
            self._debounce_timer.cancel()

        def trigger_update_table():
            self.update_table(widget, event, data)

        self._debounce_timer = Timer(delay, trigger_update_table)
        self._debounce_timer.start()

    def _switch_filters_layout(self, *_):
        self.show_filters = not self.show_filters
        self._set_filter_visibility(self.show_filters)

    @handle_cb_exceptions
    def _apply_filter(self, column, operator, value):
        try:
            self.filter_manager.add_filter(column=column, op=operator, value=value)
            self.filters_counter.children = str(self.filter_manager.active_count())
            self.update_table()
        except Exception as e:
            debug_logger.error(f"Error updating table: {e}")
            self._update_table_view()

    def _handle_chip_click(self, data_filter: DataFilter):
        self.filter_manager.remove_filter(data_filter)
        remaining_filters = self.filter_manager.active_count()

        self.df = self._get_data_from_source()
        if remaining_filters == 0:
            self.filters_counter.children = ""
        else:
            self.filters_counter.children = str(remaining_filters)

        self.update_table()

    def _clear_all_filters(self, *_):
        self.filter_manager.clear()

        del self.df
        self.df = None
        self.df = self._get_data_from_source()

        self.update_table()
        self.filters_counter.children = ""

    def update_columns(self, widget, event, data):
        if not hasattr(self, "df") or self.df is None:
            return
        if self.select_all_text in self.column_selector.v_model:
            if self.select_all_text == "Select All":
                self.column_selector.v_model = list(self.df.columns)
                self.select_all_text = "Deselect All"
            else:
                self.column_selector.v_model = []
                self.select_all_text = "Select All"

            self.column_selector.items = [self.select_all_text, *self.df.columns]
        else:
            if (
                set(self.column_selector.v_model) != set(self.df.columns)
                and self.select_all_text == "Deselect All"
            ):
                self.select_all_text = "Select All"
                self.column_selector.items = [
                    self.select_all_text,
                    *self.df.columns,
                ]

    @handle_cb_exceptions
    def update_table(self, *args):
        self.columns = self.column_selector.v_model

        self.df = self._get_data_from_source()

        self._update_table_view()

        filtered_indices = self.state.dataset.df.index.get_indexer(self.df.index)
        self.filtered_subset = self.state.dataset.subset(filtered_indices)
        self.group_save_modal.update_data_points(self.filtered_subset)

    def _update_table_view(self):
        self.table_view = self._generate_table(self.workspace_id)
        self.filter_view = self._get_filter_view()
        self.main_area.children = [self.filter_view, self.table_view]

    def _set_filter_visibility(self, show: bool):
        if show:
            self.filter_view.children[1]._clear_fields()
            self.main_area.children = [self.filter_view, self.table_view]
        else:
            self.main_area.children = [self.table_view]

    def _update_dataset_mismatch_indicator(self):
        """Update the dataset mismatch indicator based on selection state.

        Three states:
        1. Hidden: Current dataset matches selection source
        2. Link icon: Viewing linked data from a different dataset
        3. Broken link icon: Current dataset is not linked to selection, showing full table
        """
        if self.dataset_mismatch_indicator is None:
            return

        if self.selection_details is None:
            # no selection, no indicator
            self.dataset_mismatch_icon.style_ = "visibility: hidden;"
            return

        selection_source_dataset = self.selection_details.get_selection_source_dataset()

        if (
            not selection_source_dataset
            or selection_source_dataset == self.selected_dataset_name
        ):
            # same dataset or no selection, hide indicator
            self.dataset_mismatch_icon.style_ = "visibility: hidden;"
            return

        dataset_collection = self.state.dataset_collection
        link = dataset_collection.get_link(
            selection_source_dataset, self.selected_dataset_name
        )

        if link is not None:
            # linked datasets - show link icon
            self.dataset_mismatch_icon.children = ["mdi-link-variant"]
            self.dataset_mismatch_icon.color = "info"
            self.dataset_mismatch_icon.style_ = "visibility: visible;"
            tooltip_widget = with_tooltip(
                self.dataset_mismatch_icon,
                f"Viewing linked data from dataset {selection_source_dataset}",
            )
            self.dataset_mismatch_indicator.children = [tooltip_widget]
        else:
            # unlinked, show broken link icon
            self.dataset_mismatch_icon.children = ["mdi-link-variant-off"]
            self.dataset_mismatch_icon.color = "warning"
            self.dataset_mismatch_icon.style_ = "visibility: visible;"
            tooltip_widget = with_tooltip(
                self.dataset_mismatch_icon,
                "Dataset not linked to selection; showing full table",
            )
            self.dataset_mismatch_indicator.children = [tooltip_widget]

    def on_selection_change(self):
        """Called when the selection changes to update the mismatch indicator."""
        self._update_dataset_mismatch_indicator()

    @handle_cb_exceptions
    def _on_dataset_change(self, widget, event, data):
        """Handle dataset selection change, translating the selection through links."""
        # may use "(via link)" to distinguish datasets that are linked to selection vs not?
        new_dataset_name = data.replace(" (via link)", "")

        if new_dataset_name == self.selected_dataset_name:
            return

        # Mark that user has manually selected a dataset
        self.user_selected_dataset = True

        dataset_collection = self.state.dataset_collection
        from_ds = (
            self.original_selection.name
            if isinstance(self.original_selection, CobaltDataset)
            else self.original_selection.source_dataset.name
        )

        link = dataset_collection.get_link(from_ds, new_dataset_name)

        if link is None:
            # no link exists, just show the new dataset directly
            new_dataset = dataset_collection.datasets[new_dataset_name]
            self.source_data = new_dataset.as_subset()
        else:
            # translate the original selection to the new dataset
            selection = (
                self.original_selection
                if isinstance(self.original_selection, CobaltDataSubset)
                else self.original_selection.as_subset()
            )
            self.source_data = link.push_subset_to_right(selection)

        # clear filters when switching datasets
        self.filter_manager.clear()
        self.filter_manager.update_metadata(self.source_data.metadata)
        self.filters_counter.children = ""

        self.selected_dataset_name = new_dataset_name

        # refresh the data table
        self.df = self._get_data_from_source()
        self.column_selector.items = [self.select_all_text, *self.df.columns]

        # reset column selection to default
        self.columns = None
        if self.source_data.metadata.default_columns is not None:
            self.columns = self.source_data.metadata.default_columns
            self.column_selector.v_model = self.columns
        else:
            self.column_selector.v_model = []

        # update image/html columns
        media_columns = self.source_data.metadata.media_columns
        self.image_columns = [
            img_col.autoname_media_visualization_column() for img_col in media_columns
        ]
        self.html_columns = self.source_data.metadata.long_text_columns

        # rebuild filter view with new metadata
        self.filter_view = self._get_filter_view()
        if self.show_filters:
            self._set_filter_visibility(True)

        # update group save modal with new data
        self._update_save_group_modal()

        # Update mismatch indicator
        self._update_dataset_mismatch_indicator()

        self.update_table()

    def _update_save_group_modal(self):
        """Update the group save modal with current filtered data."""
        filtered_indices = self.source_data.source_dataset.df.index.get_indexer(
            self.df.index
        )
        filtered_data_points = self.source_data.source_dataset.subset(filtered_indices)
        self.group_save_modal.data_points = filtered_data_points

    def _filter_df(self, df) -> pd.DataFrame:
        return self.filter_manager.apply(df)

    def _generate_table(self, workspace_id: Optional[UUID] = None):
        df = self.df[self.columns] if self.columns else self.df
        return TableView(
            df,
            table_uuid=workspace_id,
            num_rows=self.max_rows_to_display,
            image_columns=self.image_columns,
            html_columns=self.html_columns,
            image_size=self.image_size,
        )

    def _get_filter_view(self):
        filters_list = FiltersList(
            filter_manager=self.filter_manager,
            handle_chip_click=self._handle_chip_click,
            handle_clear_filters=self._clear_all_filters,
        )

        table_filter = TableFilter(
            df=self.df,
            columns_metadata=self.source_data.metadata,
            on_apply_filter_callback=self._apply_filter,
        )

        return v.Flex(
            children=[filters_list, table_filter],
            class_="px-6",
        )
