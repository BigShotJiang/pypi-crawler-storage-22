# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

import warnings

warnings.filterwarnings("always", category=DeprecationWarning, module="cobalt")


def load_tabular_dataset(*args, **kwargs):
    raise NotImplementedError(
        "load_tabular_dataset() is no longer supported. "
        "Construct a CobaltDataset directly from your DataFrame."
    )
