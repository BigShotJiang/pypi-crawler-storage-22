from __future__ import annotations

import concurrent.futures
from typing import TYPE_CHECKING, List, Literal, Union

import numpy as np

from cobalt.api_wrapper import get_api_client
from cobalt.schema.dataset import CobaltDataSubset

if TYPE_CHECKING:
    from cobalt.schema.group import GroupMetadata

# ruff: noqa: E501
prompt_template = """You will be given a passage of text and a description of an attribute that that passage may have. Respond with "yes" or "no", depending on whether the passage has the given attribute.

Attribute:
---------
{attribute}
---------

Passage:
--------
{passage}
--------

Now, does the attribute correctly describe the passage? Answer with "yes" or "no" only.
"""

task_rules = """
"""


def build_prompts_for_explanation_score(
    group: GroupMetadata,
    reference_subset: CobaltDataSubset,
    column: str,
    description: str,
    n_samples: int = 10,
    seed: int = 5,
    sample_length: int = 250,
    use_keywords: bool = True,
):
    positive_subset = group.subset.sample(n_samples, seed)
    negative_subset = reference_subset.sample(n_samples, seed)
    positive_texts = positive_subset.select_col(column)
    negative_texts = negative_subset.select_col(column)
    positive_samples = [sample[:sample_length] for sample in positive_texts]
    negative_samples = [sample[:sample_length] for sample in negative_texts]
    positive_prompts = [
        prompt_template.format(attribute=description, passage=sample)
        for sample in positive_samples
    ]
    negative_prompts = [
        prompt_template.format(attribute=description, passage=sample)
        for sample in negative_samples
    ]

    return positive_prompts, negative_prompts


def parse_response(response):
    description: str = response.choices[0].message.content.strip()
    return "yes" in description.lower()


def score_description(
    group: GroupMetadata,
    reference_subset: Union[CobaltDataSubset, Literal["rest"]],
    description: str,
    column: str,
    n_samples: int = 10,
    max_sample_length: int = 350,
    model: str = "gpt-4.1-mini",  # TODO: try 4.1-nano
    seed: int = 17,
    parallel: bool = True,
    return_prompts: bool = False,
):
    if reference_subset == "rest":
        reference_subset = group.subset.complement()

    positive_prompts, negative_prompts = build_prompts_for_explanation_score(
        group,
        reference_subset,
        column,
        description,
        n_samples,
        sample_length=max_sample_length,
        seed=seed,
    )

    client = get_api_client()
    # TODO: handle errors
    positive_messages = [
        [{"role": "user", "content": prompt}] for prompt in positive_prompts
    ]
    negative_messages = [
        [{"role": "user", "content": prompt}] for prompt in negative_prompts
    ]
    if parallel:
        positive_responses = client.parallel_prompt(
            messages=positive_messages, model=model, timeout=15, temperature=0.0
        )
        negative_responses = client.parallel_prompt(
            messages=negative_messages, model=model, timeout=15, temperature=0.0
        )
    else:
        positive_responses = [
            client.prompt(
                messages=msgs,
                model=model,
                timeout=15,
                temperature=0.0,
            )
            for msgs in positive_messages
        ]
        negative_responses = [
            client.prompt(
                messages=msgs,
                model=model,
                timeout=15,
                temperature=0.7,
            )
            for msgs in negative_messages
        ]
    positive_scores = np.array([parse_response(r) for r in positive_responses])
    negative_scores = np.array([parse_response(r) for r in negative_responses])

    # TODO: precision and recall may not be the best metrics given we have balanced subsets
    true_positive = np.sum(positive_scores)
    false_positive = np.sum(negative_scores)
    total_detected_positive = true_positive + false_positive
    recall = true_positive / len(positive_prompts)
    precision = true_positive / max(1, total_detected_positive)
    f1_score = (
        2 * precision * recall / (precision + recall) if precision + recall > 0 else 0.0
    )

    if return_prompts:
        return (
            precision,
            recall,
            f1_score,
            positive_prompts,
            negative_prompts,
            positive_scores,
            negative_scores,
        )
    else:
        return precision, recall, f1_score


def score_descriptions(
    group: GroupMetadata,
    reference_subset: Union[CobaltDataSubset, Literal["rest"]],
    descriptions: List[str],
    column: str,
    n_samples: int = 10,
    max_sample_length: int = 350,
    model: str = "gpt-4.1-mini",
    seed: int = 17,
    parallel: bool = True,
):
    if parallel:
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(
                    score_description,
                    group=group,
                    reference_subset=reference_subset,
                    description=description,
                    column=column,
                    n_samples=n_samples,
                    max_sample_length=max_sample_length,
                    model=model,
                    seed=seed,
                    parallel=parallel,
                    return_prompts=False,
                )
                for description in descriptions
            ]
            scores = [future.result() for future in futures]
    else:
        scores = [
            score_description(
                group=group,
                reference_subset=reference_subset,
                description=description,
                column=column,
                n_samples=n_samples,
                max_sample_length=max_sample_length,
                model=model,
                seed=seed,
                parallel=parallel,
                return_prompts=False,
            )
            for description in descriptions
        ]
    return scores
