# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.
from __future__ import annotations

import io
import json
import os
import warnings
import zipfile
from math import ceil, floor
from typing import Any, Dict, List, Literal, Optional, Tuple, Union, cast
from uuid import uuid4

import numpy as np
import numpy.typing as npt
import pandas as pd
import scipy.stats
from mapper import HierarchicalDataGraph, Metric

from cobalt import schema, serialization
from cobalt.build_graph import GraphBuilder
from cobalt.cobalt_types import GroupType
from cobalt.config import handle_cb_exceptions, is_colab_environment
from cobalt.event_bus import DatasetEvent, EventBusController
from cobalt.feature_compare import feature_compare
from cobalt.problem_group import failure_group
from cobalt.problem_group.autogroup import autogroup_modularity
from cobalt.repositories.run_repository import GroupResultsCollection, RunType
from cobalt.repositories.server_repository import SERVER_REGISTRY
from cobalt.schema import DatasetSplit, SplitDescriptor, evaluation_metric
from cobalt.schema.dataset import CobaltDataset, CobaltDataSubset
from cobalt.schema.graph import HierarchicalCobaltGraph
from cobalt.schema.group import Cluster, ProblemGroup
from cobalt.schema.group_collection import GroupCollection
from cobalt.schema.link import DatasetLink
from cobalt.schema.metadata import TextDataType
from cobalt.schema.model_metadata import ModelMetadata
from cobalt.serialization import (
    GroupLibrary,
    SubsetLibrary,
    get_json_default_for_subsets,
    get_object_hook_for_subsets,
)
from cobalt.state import State
from cobalt.table.table_select import TableSelector
from cobalt.ui import UI
from cobalt.visualization import GraphManager

# joblib (or maybe pynndescent/numba) uses attributes deprecated in Python 3.12
warnings.filterwarnings("ignore", category=DeprecationWarning, module="joblib")
# numba can use different threading backends but will warn if it can't use an old version of TBB
warnings.filterwarnings(
    "ignore", message="The TBB threading layer requires TBB version"
)


class Workspace:
    """Encapsulates analysis done with a dataset and models.

    Attributes:
        ui: A user interface that can be used to interact with the data, models,
            and other analysis.
        run_auto_group_analysis: Whether to automatically run a group analysis
            of the data and models when the UI is opened, if no analysis has yet
            been run.
    """

    def __init__(
        self,
        dataset: CobaltDataset,
        split: Optional[Union[schema.DatasetSplit, SplitDescriptor]] = None,
        auto_graph: bool = True,
        run_server: Optional[bool] = None,
    ):
        """Initialize a Workspace.

        Args:
            dataset: The CobaltDataset to use for the analysis.
            split: A division of the dataset into predetermined groups, e.g. test/train.
            auto_graph: Whether to automatically run the graph creation.
            run_server: Whether to run a web server to host images. If None
                (default), will run a server unless a Colab environment is detected.

        The dataset split can be provided in a number of different ways.
        """
        self.workspace_id = uuid4()
        if isinstance(split, DatasetSplit):
            self.state = State(dataset, split, workspace_id=self.workspace_id)
        else:
            self.state = State(
                dataset, DatasetSplit(dataset, split), workspace_id=self.workspace_id
            )
        if run_server is None:
            run_server = not is_colab_environment()
        self.run_server = run_server

        # Collect metrics for initial dataset
        self.state.collect_metrics(field="all", dataset=dataset)
        self.run_event_bus = EventBusController.get_run_event_bus(self.workspace_id)

        self.auto_graph = auto_graph

        media_columns = self.state.metadata.media_columns
        if media_columns:
            for mc in media_columns:
                if not mc.is_remote and self.run_server:
                    SERVER_REGISTRY.add_server(media_columns[0].host_directory)
        SERVER_REGISTRY.run_servers()

        self.graph_builder = GraphBuilder(self.state)
        self.run_auto_group_analysis = self.auto_graph
        self.ui = self._init_ui(dataset)

    @property
    def split(self) -> DatasetSplit:
        return self.state.split

    @property
    def dataset(self) -> schema.CobaltDataset:
        """The dataset being analyzed in this workspace."""
        return self.state.dataset

    @staticmethod
    def from_arrays(
        model_inputs: Union[List, np.ndarray, pd.DataFrame],
        model_predictions: np.ndarray,
        ground_truth: Optional[np.ndarray],
        task: str = "classification",
        embedding: Optional[np.ndarray] = None,
        embeddings: Optional[List[np.ndarray]] = None,
        embedding_metric: Optional[str] = None,
        embedding_metrics: Optional[List[str]] = None,
        split: Optional[Union[schema.DatasetSplit, SplitDescriptor]] = None,
    ):
        """Returns a Workspace object constructed from user-defined arrays.

        Args:
            model_inputs: the data evaluated by the model.
            model_predictions: the model's predictions corresponding to `model_inputs`.
            ground_truth: ground truths for `model_inputs`.
            task: model task, pass in "classification"
            embedding: embedding array to include.
            embeddings: list of embedding arrays to use.
            embedding_metric: embedding metric corresponding to embedding.
            embedding_metrics: list of metrics corresponding to embeddings.
            split: an optional dataset split.

        At most one of ``embedding`` or ``embeddings`` (and the corresponding
        ``embedding_metric`` or ``embedding_metrics``) should be provided.
        """
        warnings.warn(
            "Workspace.from_arrays() is deprecated. "
            "Construct a CobaltDataset from a DataFrame instead.",
            category=DeprecationWarning,
            stacklevel=2,
        )
        # TODO: Weighing whether it should be a secondary step to provide groups.
        # What we could do is create a different analysis with different splits.

        if isinstance(model_inputs, pd.DataFrame):
            df = model_inputs
            input_columns = list(model_inputs.columns)
        else:
            if isinstance(model_inputs, np.ndarray) and len(model_inputs.shape) > 1:
                raise ValueError(
                    "model_inputs should be One Dimensional if an np.ndarray."
                )

            df = pd.DataFrame({"inputs": model_inputs})
            input_columns = "inputs"

        df["predictions"] = model_predictions

        if ground_truth is not None:
            df["target"] = ground_truth

        dataset = schema.CobaltDataset(df)

        dataset.add_model(
            input_columns=input_columns,
            target_column="target",
            prediction_column="predictions",
            task=task,
            name="model_1",
        )

        if embedding is not None:
            dataset.add_embedding_array(embedding, embedding_metric)

        if embeddings is not None:
            for e, m in zip(embeddings, embedding_metrics):
                dataset.add_embedding_array(e, m)

        return Workspace(dataset, split)

    def view_table(
        self,
        subset: Optional[Union[List[int], CobaltDataSubset]] = None,
        display_columns: Optional[List[str]] = None,
        max_rows: Optional[int] = None,
    ):
        """Returns a visualization of the dataset table."""
        if not isinstance(subset, CobaltDataSubset):
            subset: CobaltDataSubset = (
                self.state.dataset.subset(subset)
                if subset is not None
                else self.state.dataset.as_subset()
            )

        media_columns = subset.metadata.media_columns
        image_columns = [
            img_col.autoname_media_visualization_column() for img_col in media_columns
        ]
        html_columns = subset.metadata.long_text_columns

        if display_columns is None and subset.metadata.default_columns is not None:
            display_columns = subset.metadata.default_columns

        return TableSelector(
            subset,
            self.state,
            columns=display_columns,
            image_columns=image_columns,
            html_columns=html_columns,
            max_rows_to_display=max_rows,
        )

    def _init_ui(self, dataset):
        ui = UI(workspace=self, dataset=dataset)
        ui.workspace_id = self.workspace_id
        return ui

    @staticmethod
    def analyze(
        subset: CobaltDataSubset,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Compute numerical and categorical statistics for the given subset.

        Returns:
            A tuple (numerical_statistics, categorical statistics) giving
            summary statistics for numerical and categorical features in the
            dataset.
        """
        return subset.get_summary_statistics()

    def feature_compare(
        self,
        group_1: Union[str, CobaltDataSubset],
        group_2: Union[str, CobaltDataSubset, Literal["all", "rest", "neighbors"]],
        numerical_features: Optional[List[str]] = None,
        categorical_features: Optional[List[str]] = None,
        numerical_test: Literal["t-test", "perm"] = "t-test",
        categorical_test: Literal["G-test"] = "G-test",
        include_nan: bool = False,
        neighbor_graph: Optional[Union[str, HierarchicalCobaltGraph]] = None,
    ):
        """Compare the distributions of features between two subsets."""
        group_1 = self._get_subset(group_1)
        if group_2 == "neighbors":
            if neighbor_graph is None:
                # TODO: choose a default graph?
                raise ValueError(
                    "neighbor_graph must be specified to use 'neighbors' comparison group."
                )
            group_2 = self.get_group_neighbors(group_1, neighbor_graph)
        elif group_2 == "all":
            group_2 = group_1.source_dataset.as_subset()
        elif group_2 == "rest":
            group_2 = group_1.complement()
        else:
            group_2 = self._get_subset(group_2)

        if group_1.source_dataset is not group_2.source_dataset:
            raise ValueError(
                "To compare subsets, they must have the same source dataset."
            )

        return feature_compare(
            group_1,
            group_2,
            numerical_features,
            categorical_features,
            numerical_test,
            categorical_test,
            include_nan=include_nan,
        )

    def get_group_neighbors(
        self,
        group: Union[CobaltDataSubset, str],
        graph: Union[HierarchicalCobaltGraph, str],
        size_ratio: float = 1.0,
    ) -> CobaltDataSubset:
        """Find a set of data points that are neighbors of a group.

        Returns a set of data points that is well connected to the given group
        in the graph, and which does not include any points from the original
        group.

        This method is experimental and its functionality may change in the future.

        Args:
            group: A CobaltDataSubset or name of a saved group to find the neighbors of.
            graph: A HierarchicalCobaltGraph or name of a graph in which to find the neighbors.
            size_ratio: Approximate relative size of the group of neighbors. The
                algorithm will attempt to return a group of neighbors that is
                approximately ``size_ratio`` times the size of the input group.
        """
        from cobalt.lab.neighborhood import get_group_neighborhood

        subset = self._get_subset(group)
        cobalt_graph = self._get_graph(graph)

        expanded_neighborhood = get_group_neighborhood(
            subset, cobalt_graph, nbhd_size_ratio=1 + size_ratio
        )
        return expanded_neighborhood.difference(subset)

    def get_groups(self) -> GroupCollection:
        """Get a GroupCollection object with the currently saved groups.

        Returns:
            GroupCollection read-only object with groups.
            A group consists of a subset of data points together with some metadata
            about the subset.
        """
        groups = self.state.get_groups_metadata().copy()
        if len(groups) == 0:
            return GroupCollection(
                self.state.dataset, [], "User Saved Groups", GroupType.user
            )
        g_collection = GroupCollection.from_groups(list(groups.values()))
        g_collection.group_type = GroupType.user
        return g_collection

    @property
    def saved_groups(self) -> GroupCollection:
        """An object that represents the currently saved groups.

        This does not include groups selected by algorithms like
        ``find_failure_groups()``, only groups saved manually in the UI or with
        ``Workspace.add_group()``.
        """
        # TODO: make this behave nicely with setters?
        return self.get_groups()

    def add_group(
        self,
        name: str,
        group: schema.CobaltDataSubset,
        compute_stats: bool = True,
        description: Optional[str] = None,
    ):
        """Add a group to the collection of saved groups.

        Args:
            name: The name to identify the group.
            group: A CobaltDataSubset object to be saved as a group.
            compute_stats: Whether to compute summary statistics for the group.
                For large datasets with many features this can be time consuming and
                setting this to False may help.
            description: An optional description to be displayed with the group.
        """
        self.state.add_group(
            group, name, compute_stats=compute_stats, description=description
        )
        self.state.collect_metrics(field="groups", group_id=name, dataset=group)

    @property
    def graphs(self) -> Dict[str, HierarchicalCobaltGraph]:
        """The graphs that have been created and saved."""
        return self.state.graph_repo.get_cobalt_graphs()

    def add_graph(
        self,
        name: str,
        graph: Union[HierarchicalDataGraph, HierarchicalCobaltGraph],
        subset: Optional[schema.CobaltDataSubset] = None,
        init_max_nodes: int = 500,
        init_max_degree: float = 15.0,
        params: Optional[dict] = None,
        source_columns: Optional[List[str]] = None,
        embedding: Optional[schema.Embedding] = None,
    ):
        """Add a graph to self.graphs.

        Args:
            name (str): A name for the graph.
            graph: The graph to add (HierarchicalDataGraph or HierarchicalCobaltGraph).
            subset: The subset of the self.dataset this graph is constructed from.
                If graph is a HierarchicalCobaltGraph and subset is None, uses graph.subset.
            init_max_nodes: The maximum number of nodes to show in the initial view
                of this graph.
            init_max_degree: The maximum average node degree for the initial view of this graph.
            params: Optional dict of parameters used to construct the graph
            source_columns: Optional list of column names used to build the graph
            embedding: Optional Embedding object used to build the graph
        """
        if isinstance(graph, HierarchicalCobaltGraph):
            # if a HierarchicalCobaltGraph is passed with a different name, update it
            if graph.name != name:
                cobalt_graph = HierarchicalCobaltGraph(
                    name=name,
                    graph=graph._graph,
                    subset=graph.subset,
                    params=graph.params,
                    source_columns=graph.source_columns,
                    embedding=graph.embedding,
                )
            else:
                cobalt_graph = graph
            if subset is not None and subset != cobalt_graph.subset:
                raise ValueError("subset and graph.subset do not match")
            if params is not None:
                cobalt_graph.params.update(params)
            if embedding is not None:
                cobalt_graph.embedding = embedding
        else:
            if subset is None:
                raise ValueError(
                    "subset must be provided when graph is a HierarchicalDataGraph"
                )
            cobalt_graph = HierarchicalCobaltGraph(
                name=name,
                graph=graph,
                subset=subset,
                params=params or {},
                source_columns=source_columns,
                embedding=embedding,
            )

        landscape_params = {
            "init_max_nodes": init_max_nodes,
            "init_max_degree": init_max_degree,
        }

        self.state.add_graph(
            graph={"cobalt_graph": cobalt_graph, "landscape_params": landscape_params},
            graph_name=name,
        )

    def new_graph(
        self,
        name: Optional[str] = None,
        subset: Optional[Union[str, CobaltDataSubset, CobaltDataset]] = None,
        embedding: Union[int, str, schema.Embedding] = 0,
        metric: Optional[Union[str, Metric]] = None,
        init_max_nodes: int = 500,
        init_max_degree: float = 15.0,
        **kwargs,
    ) -> HierarchicalCobaltGraph:
        """Create a new graph from a specified subset.

        The resulting graph will be returned and added to the Workspace.

        Args:
            name: The name to give the graph in self.graphs. If None: Autoname it.
            subset: The subset of the dataset to include in the graph. If a string,
                will try to use a subset with that name from the dataset split or the
                saved groups (in that order). Otherwise, should be a `CobaltDataSubset`.
            embedding: The embedding to use to generate the graph. May be specified
                as an index into self.dataset.embeddings, the name of the embedding, or
                an `Embedding` object.
            metric: The distance metric to use when constructing the graph. If none
                is provided, will use the metric specified by the embedding.
            init_max_nodes: The maximum number of nodes to show in the initial view
                of this graph.
            init_max_degree: The maximum average node degree for the initial view of this graph.
            **kwargs: Additional keyword parameters. These can include:

                - Parameters for `GraphSpec` (e.g., `M`, `K`, `min_nbrs`, `affinity`,
                  `L_coarseness`, `L_connectivity`, `filters`).

                - `grid_search` (bool): If True, perform a grid search over graph
                  parameters to select the best graph according to a scoring function.
                  Default is False. This has a performance cost but can yield
                  higher-quality graphs.

                - Grid search options (only used when `grid_search=True`):
                    - `param_grid`: List of parameter dicts to search over. If None,
                      uses a default grid.
                    - `scorer`: Scoring function key ("spectral_score" or
                      "modularity_score") or a callable. Default is "spectral_score".
                    - `subsample_max_size`: Max data size for scoring phase. Default 1000.
                    - `random_state`: RNG seed for subsampling. Default 42.
                    - `reverse`: If True, higher scores are better. Default True.
                    - `embedding_search_mode`: One of "given" (default, use passed
                      embedding only), "all" (search all embeddings in dataset), or
                      "given_plus_generated" (passed embedding plus auto-generated
                      scaled and random forest embeddings).

                When `grid_search=True`, the returned graph's `params` attribute will
                contain a "grid_search_details" key with the selected parameters,
                score, and other grid search metadata.

        Returns:
            HierarchicalCobaltGraph: The created graph.
        """
        if subset is None:
            subset = self.state.dataset.as_subset()
        subset_ = self._get_subset(subset)
        _, embedding_metadata = self._get_embedding(subset_, embedding)

        if name is None:
            name = GraphManager.generate_new_graph_name(self.state)

        cobalt_graph = self.graph_builder.new_graph(
            name=name,
            subset=subset_,
            embedding=embedding_metadata,
            metric=metric,
            **kwargs,
        )

        self.add_graph(
            name,
            cobalt_graph,
            init_max_nodes=init_max_nodes,
            init_max_degree=init_max_degree,
        )

        return self.graphs[name]

    def get_graph_level(
        self,
        graph: Union[str, HierarchicalCobaltGraph],
        level: int,
        name: Optional[str] = None,
    ) -> GroupCollection:
        """Create a GroupCollection from a specified level of a graph.

        This method is deprecated. Use CobaltGraph.get_group_collection() instead:

        >>> hierarchical_graph = workspace.graphs["graph_name"]
        >>> graph_level = hierarchical_graph.levels[level]
        >>> group_collection = graph_level.get_group_collection(name)

        Args:
            graph: Name of the graph to use, or the graph object itself.
            level: The level of the graph to use for the groups. One group will
                be created for each node in the graph.
            name: An optional name for the GroupCollection.
        """
        warnings.warn(
            "Workspace.get_graph_level() is deprecated. "
            "Use CobaltGraph.get_group_collection() instead",
            category=DeprecationWarning,
            stacklevel=2,
        )
        graph = self._get_graph(graph)

        source = graph.subset
        group_collection = GroupCollection.from_indices(
            source, graph.levels[level].nodes, name=name
        )
        return group_collection

    def get_graph_levels(
        self,
        graph: Union[str, HierarchicalCobaltGraph],
        min_level: int,
        max_level: int,
        name_prefix: Optional[str] = None,
    ) -> Dict[int, GroupCollection]:
        """Create GroupCollections for a range of levels of a graph.

        All levels between min_level and max_level will be used. The return
        value is a dict mapping levels to GroupCollections.

        This method is experimental and its interface may be changed in the
        future.

        Args:
            graph: Name of the graph to use, or the graph object itself.
            min_level: The lowest level of the graph to use for the groups.
            max_level: The highest level of the graph to use for the groups.
            name_prefix: If provided, the GroupCollection for level i will be
                named "{name_prefix}_{i}".
        """
        return {
            level: self.get_graph_level(
                graph, level, name=f"{name_prefix}_{level}" if name_prefix else None
            )
            for level in range(min_level, max_level + 1)
        }

    def add_evaluation_metric_values(
        self,
        name: str,
        metric_values: npt.ArrayLike,
        model: Union[int, str, ModelMetadata] = 0,
        lower_values_are_better: bool = True,
        dataset: Optional[Union[str, CobaltDataset]] = None,
    ):
        """Add values for a custom evaluation metric.

        Args:
            name: A name for this evaluation metric. This will be used to name a
                column in the dataset where these values will be stored, as well as
                to name the metric itself.
            metric_values: An arraylike with one value for each data point in the dataset.
            model: The name or index of the model in self.dataset that this metric evaluates.
            lower_values_are_better: If True, Cobalt will interpret lower values
                of this metric as positive; otherwise, it will interpret higher
                values as positive.
            dataset: The dataset the model belongs to. May be a dataset name or
                a CobaltDataset object.
        """
        if dataset is None:
            dataset = self.state.dataset
        elif isinstance(dataset, str):
            dataset = self.state.dataset_collection.datasets[dataset]
        if len(metric_values) != len(dataset):
            raise ValueError("Not enough metric values for this dataset.")
        model_metadata = self._get_model(model, dataset)
        if name in model_metadata.evaluation_metrics:
            raise ValueError(f"Evaluation metric with name '{name}' already exists.")
        column_name = self._find_available_column_name(dataset.df.columns, name)
        dataset.set_column(column_name, metric_values)
        metric_metadata = evaluation_metric.ColumnEvaluationMetric(
            name, column_name, lower_values_are_better
        )
        model_metadata.evaluation_metrics[name] = metric_metadata

    def find_drifted_groups(
        self,
        reference_group: Union[str, CobaltDataSubset],
        comparison_group: Union[str, CobaltDataSubset],
        embedding: Union[int, str, schema.Embedding] = 0,
        relative_prevalence_threshold: float = 2,
        p_value_threshold: float = 0.05,
        min_size: int = 5,
        run_name: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
        manual: bool = True,
        visible: bool = True,
        generate_group_descriptions: bool = True,
        model: Union[int, str, ModelMetadata] = 0,
        graph: Optional[Union[str, HierarchicalCobaltGraph]] = None,
    ) -> GroupResultsCollection:
        """Return groups in the comparison group that are underrepresented in the reference group.

        Args:
            reference_group: The reference subset of the data, e.g. the training set.
            comparison_group: The subset of the data that may have regions that
                are not well represented in the reference set. This may be a test
                dataset or production data.
            embedding: The embedding to use for the analysis. If none is provided,
                will use the default dataset embedding. (If one does not exist, will
                raise an error.)
            relative_prevalence_threshold: How much more common points from
                comparison_group need to be in a group relative to the overall
                average for it to be considered drifted. This is computed by
                comparing the ratio of comparison points to reference points in a
                group, compared with the ratio in the overall dataset. If the
                overall balance of points is 1:1 from each group and
                relative_prevalence_threshold = 2, a drifted group will have
                at least a 2:1 balance in favor of data points from the comparison
                set. If the overall ratio of points is 1:2 comparison : reference,
                then a drifted group will need to have at least a 1:1 ratio.

                Choose this value based on what amount of overrepresentation of
                the comparison group would be meaningful to you. Under the
                default parameter of 2, the interpretation is roughly that for
                any returned group, points from the comparison subset are at
                least twice as common as they would be in a random sample of
                data points.
            p_value_threshold: Used in a significance test that the prevalence
                of points from the comparison group is at least as high as required
                based on the value of relative_prevalence_threshold.
            min_size: The minimum number of data points that need to be in the drifted
                region else, the drifted region is dropped from the result
            run_name: A name under which to store the results. If one is not
                provided, it will be chosen automatically.
            config: A dictionary containing further configuration parameters
                that will be passed to the underlying algorithm.
            manual: Used internally to signal whether the failure group analysis
                was created by the user.
            visible: Whether to show the results of this analysis in the UI.
            generate_group_descriptions: Whether to generate statistical and
                textual descriptions of returned groups. True by default, but
                consider setting to False for large datasets with many columns, as
                this process can be very time consuming.
            model: Index or name of the model whose error metric will be shown
                with the returned groups.
            graph: The graph object to use when comparing groups. This graph
                must be built on the concatenation of reference_group with
                comparison_group.

        Returns:
            A GroupResultsCollection object containing the discovered drifted
            groups and the parameters used by the algorithm.
        """
        if config is None:
            config = {}
        subset1 = self._get_subset(reference_group)
        subset2 = self._get_subset(comparison_group)

        if subset1.source_dataset is not subset2.source_dataset:
            raise ValueError(
                "To compute drift, reference and comparison groups "
                "must be subsets of the same dataset."
            )

        if not subset1.embedding_metadata or not subset2.embedding_metadata:
            return None
        combined = subset1.concatenate(subset2)
        _, embedding = self._get_embedding(combined, embedding)
        drift_score = np.zeros(len(subset1) + len(subset2))
        drift_score[len(subset1) :] = 1

        comparison_prob = len(subset2) / len(combined)
        comparison_odds = len(subset2) / len(subset1)
        # we're looking at the odds ratio between the overall dataset and each individual group
        threshold_odds = comparison_odds * relative_prevalence_threshold
        threshold_prob = threshold_odds / (threshold_odds + 1)

        if graph is not None:
            graph = self._get_graph(graph)
            if graph.subset != combined:
                raise ValueError(
                    "If provided, graph must be built on the "
                    "concatenation of reference_group and comparison_group."
                )

            graph_config = failure_group.select_best_graph_level(graph, drift_score)
            config.update(graph_config)

        raw_groups, params = failure_group.find_failure_groups_superlevel_auto(
            combined,
            drift_score,
            embedding,
            # don't include nodes in a group if the ratio is _less_ than the overall ratio
            threshold=comparison_prob,
            use_merge_tree=True,
            **config,
        )

        params["prod"] = subset2

        # Remove drifted groups which have fewer data points than min_size.
        raw_groups = [group for group in raw_groups if len(group) >= min_size]

        # remove drifted groups which don't pass the hypothesis test for being above threshold_prob
        group_sizes = [len(g) for g in raw_groups]
        comparison_counts = [subset2.intersection_size(g) for g in raw_groups]
        p_vals = [
            scipy.stats.binomtest(
                count, size, p=threshold_prob, alternative="greater"
            ).pvalue
            for count, size in zip(comparison_counts, group_sizes)
        ]
        raw_groups = [
            group
            for group, p_val in zip(raw_groups, p_vals)
            if p_val < p_value_threshold
        ]

        if run_name:
            group_name_prefix = run_name
        else:
            run_name = self.state.run_repo.new_run_name()
            group_name_prefix = f"{run_name}_drift"

        if "full_graph" in params:
            self.add_graph(
                f"{group_name_prefix}_graph",
                params["full_graph"],
                combined,
            )

        error_metric = None
        if subset1.models:
            model_metadata = self._get_model(model, subset1.source_dataset)
            if "error" in model_metadata.performance_metric_keys:
                error_metric = model_metadata.performance_metrics["error"]

        problem_groups: List[ProblemGroup] = []
        for group in raw_groups:
            prod_fraction = group.intersection_size(subset2) / len(group)
            metrics = {"production fraction": prod_fraction}
            if error_metric is None:
                severity = prod_fraction
                problem_description = (
                    f"Drifted group | {len(group)} points "
                    f"| {100 * prod_fraction :.1f}% new"
                )
            else:
                error_rate = error_metric.overall_score(group)
                metrics.update(error_rate)
                severity = error_rate["error"]
                problem_description = (
                    f"Drifted group | {len(group)} points "
                    f"| {100 * prod_fraction :.1f}% new "
                    f"| {100 * error_rate['error'] :.1f}% error "
                )

            problem_group = ProblemGroup(
                name="",
                subset=group,
                severity=severity,
                problem_description=problem_description,
                metrics=metrics,
                group_type=GroupType.drift,
            )
            problem_groups.append(problem_group)

        problem_groups.sort(
            key=lambda g: (round(g.severity, 3), len(g.subset)),
            reverse=True,
        )
        for i, g in enumerate(problem_groups):
            g.name = f"{group_name_prefix}/{i + 1}"
        # TODO: model performance metrics? histograms?

        run: GroupResultsCollection = self.state.run_repo.build_run(
            run_type=RunType.MANUAL if manual else RunType.AUTOMATIC,
            groups=problem_groups,
            run_name=run_name,
            algorithm="drift",
            group_type=GroupType.drift,
            source_data=combined,
            params=params,
            visible=visible,
        )

        if self.state.dataset.model:
            for m in run.metadata:
                m.add_model_data_histograms(self.state.dataset.model)

        if generate_group_descriptions:
            for m in run.metadata:
                m.compute_comparison_stats(
                    comparison_group="rest",
                    omit_columns=subset1.metadata.hidable_columns,
                )
                m.compute_feature_bounds()
            run.compute_group_keywords(warn_if_no_data=False)

        if visible:
            self.run_event_bus.run_all()

        return run

    @property
    def drifted_groups(self) -> Dict[str, GroupResultsCollection]:
        """The collection of all drifted group analysis results."""
        return self.state.run_repo.get_runs(group_type=GroupType.drift)

    def find_failure_groups(
        self,
        method: Literal["superlevel"] = "superlevel",
        subset: Optional[Union[str, CobaltDataSubset, CobaltDataset]] = None,
        model: Union[int, str, ModelMetadata] = 0,
        embedding: Union[int, str, schema.Embedding] = 0,
        failure_metric: Optional[Union[str, pd.Series]] = None,
        min_size: int = 1,
        max_size: Union[int, float] = np.inf,
        min_failures: int = 3,
        config: Optional[Dict[str, Dict]] = None,
        run_name: Optional[str] = None,
        manual: bool = True,
        visible: bool = True,
        generate_group_descriptions: bool = True,
        graph: Optional[Union[HierarchicalCobaltGraph, str]] = None,
    ) -> GroupResultsCollection:
        """Run an analysis to find failure groups in the dataset.

        Saves the results in self.failure_groups under `run_name`.

        Args:
            method: Algorithm to use for finding failure groups. Currently only
                "superlevel" is supported.
            subset: The subset of the data on which to perform the analysis. If none
                is provided, will use the entire dataset.
            model: Index or name of the model for which failure groups should be found.
            embedding: The embedding to use for the analysis. If none is provided,
                will use the default dataset embedding. (If one does not exist, will
                raise an error.)
            failure_metric: The performance metric to use. If a string, will use the
                model performance metric with that name; otherwise, must be a Pandas
                Series, with length either equal to the length of the specified subset,
                or the whole dataset. If a Series is passed, it will be added to the
                dataset as a model evaluation metric.
            min_size: The minimum size for a returned failure group. Smaller groups
                will be discarded.
            max_size: The maximum size for a returned failure group. Larger groups
                will be split into smaller groups by applying a clustering algorithm.
            min_failures: The minimum number of failure for a returned failure groups.
                Smaller groups will be discarded. Default is set to 3 to allow DS to spot
                failure patterns. This is only for classification tasks.
            config: A dictionary containing further configuration parameters
                that will be passed to the underlying algorithm.
            run_name: A name under which to store the results. If one is not
                provided, it will be chosen automatically.
            manual: Used internally to signal whether the failure group analysis
                was created by the user.
            visible: Whether to show the results of this analysis in the UI.
            generate_group_descriptions: Whether to generate statistical and
                textual descriptions of returned groups. True by default, but
                consider setting to False for large datasets with many columns, as
                this process can be very time consuming.
            graph: A graph object or name of a graph to use in finding the
                failure groups. If provided, this graph must be built on the subset
                of data provided in the subset argument.

        Returns:
            A GroupResultsCollection object containing the discovered failure
            groups and the parameters used by the algorithm.
        """
        if method != "superlevel":
            raise NotImplementedError(f"method {method} is not implemented")

        if graph is not None:
            graph = self._get_graph(graph)
            graph_subset = graph.subset

            if subset is not None and graph_subset != subset:
                raise ValueError(
                    "If provided, graph must be built on the specified subset."
                )

        if subset is None:
            subset = (
                graph.subset if graph is not None else self.state.dataset.as_subset()
            )
        subset = self._get_subset(subset)
        if not subset.embedding_metadata and graph is None:
            raise ValueError(
                "If a graph is not provided, at least one embedding must exist."
            )
        _, embedding = self._get_embedding(subset, embedding)

        model_metadata = self._get_model(model, subset.source_dataset)

        if failure_metric is None:
            failure_metric = model_metadata.performance_metric_keys[0]
        if isinstance(failure_metric, str):
            failure_metric_name = failure_metric
        else:
            if len(failure_metric) < len(self.state.dataset):
                warnings.warn(
                    (
                        "Not enough failure values provided for dataset. "
                        "Attempting to assign to specified subset."
                        "Data points outside the subset will have missing "
                        "values for this metric."
                    ),
                    stacklevel=2,
                )
                failure_values = np.full(len(self.state.dataset), np.nan)
                failure_values[subset.indices] = failure_metric
            else:
                failure_values = failure_metric
            self.add_evaluation_metric_values(
                failure_metric.name, failure_values, model=model
            )
            failure_metric_name = str(failure_metric.name)

        failure_values = subset.get_model_performance_data(failure_metric_name, model)
        metric_metadata = model_metadata.performance_metrics[failure_metric_name]
        if not metric_metadata.lower_values_are_better:
            failure_values = -np.array(failure_values, dtype=float)

        if config is None:
            config = {}
        config = cast(Dict[str, Any], config.get(method, config))

        if graph is not None:
            metric_vals = metric_metadata.calculate(subset)[metric_metadata.get_key()]
            graph_config = failure_group.select_best_graph_level(
                graph, np.asarray(metric_vals)
            )
            config.update(graph_config)

        # TODO: remove dependency on embedding if the user provides a graph
        raw_failure_groups, params = failure_group.find_failure_groups_superlevel_auto(
            subset, failure_values, embedding, **config
        )

        params["model"] = model_metadata

        if "full_graph" in params:

            def split_group(gp):
                return failure_group.split_group(
                    gp,
                    params["full_graph"],
                    max_size,
                    params["graph_level"],
                )

        else:

            def split_group(gp):
                return failure_group.split_group_new_graph(gp, embedding, max_size)

        filtered_failure_groups = failure_group.split_groups_max_size(
            raw_failure_groups,
            max_size,
            split_group,
        )

        # if we've split some groups, there may be some that don't exceed the threshold now
        filtered_failure_groups = failure_group.filter_groups_metric_threshold(
            filtered_failure_groups, metric_metadata, params["threshold"]
        )

        filtered_failure_groups = failure_group.filter_groups_min_errors(
            filtered_failure_groups, model_metadata, min_failures
        )
        filtered_failure_groups = [
            gp for gp in filtered_failure_groups if len(gp) >= min_size
        ]

        failure_groups: List[ProblemGroup] = []
        metric = model_metadata.performance_metrics[failure_metric_name]
        sev_sign = 1 if metric_metadata.lower_values_are_better else -1
        for fg in filtered_failure_groups:
            metric_average = metric.calculate(fg)[failure_metric_name].mean()
            severity = sev_sign * metric_average
            failure_groups.append(
                ProblemGroup(
                    subset=fg,
                    metrics={failure_metric_name: metric_average},
                    severity=severity,
                    primary_metric=failure_metric_name,
                )
            )

        # sort by rounded metric value, then by size
        # most of the time the sort by size won't be meaningful
        failure_groups.sort(
            key=lambda g: (round(g.severity, 3), len(g.subset)),
            reverse=True,
        )

        if run_name:
            group_name_prefix = run_name
        else:
            run_name = self.state.run_repo.new_run_name()
            group_name_prefix = f"{run_name}_fg"

        for i, gp in enumerate(failure_groups):
            gp.name = f"{group_name_prefix}/{i + 1}"

        # BuildRun and automatically and it to the repos
        run: GroupResultsCollection = self.state.run_repo.build_run(
            run_type=RunType.MANUAL if manual else RunType.AUTOMATIC,
            groups=failure_groups,
            run_name=run_name,
            algorithm=method,
            group_type=GroupType.failure,
            source_data=subset,
            params=params,
            visible=visible,
        )

        for m in run.metadata:
            m.add_model_data_histograms(model_metadata)

        if generate_group_descriptions:
            omit_columns = [
                *subset.metadata.hidable_columns,
                *model_metadata.error_columns,
            ]
            for m in run.metadata:
                m.compute_comparison_stats(
                    comparison_group="rest",
                    omit_columns=omit_columns,
                )
                m.compute_feature_bounds(omit_columns=omit_columns)
            topic_column = subset.metadata.default_topic_column
            # override the default to be the model input column if it's text
            if (
                model_metadata.input_columns is not None
                and len(model_metadata.input_columns) == 1
            ):
                input_column = model_metadata.input_columns[0]
                if (
                    subset.metadata.data_types[input_column].text_type
                    == TextDataType.long_text
                ):
                    topic_column = input_column

            run.compute_group_keywords(set_descriptions=False, warn_if_no_data=False)
            if topic_column:
                run.set_descriptions_from_keywords(col=topic_column)

        self.state.collect_metrics_for_current_run(run)

        if "full_graph" in params:
            self.add_graph(
                f"{run_name}_graph",
                params["full_graph"],
            )

        if visible:
            self.run_event_bus.run_all()

        return run

    @handle_cb_exceptions
    def _get_or_create_displayed_groups(self) -> List[ProblemGroup]:
        runs = self.state.run_repo.get_runs(run_visible=True)

        if not runs and (
            not self.run_auto_group_analysis
            or not self.state.dataset.embedding_metadata
        ):
            return []

        if not runs and self.state.dataset._has_model_metadata():
            # can run failure group analysis
            run = self.find_failure_groups(
                run_name="auto_fg", manual=False, visible=True
            )
            runs["auto_fg"] = run

        # run autogrouping if we couldn't do failure groups
        if not runs:
            autogroup_run = self.find_clusters(
                run_name="auto_cluster", manual=False, visible=True
            )
            if autogroup_run:
                runs["auto_cluster"] = autogroup_run

        groups = []
        for run in runs.values():
            groups.extend(run.groups)

        return groups

    def _get_displayed_groups(self) -> List[ProblemGroup]:
        runs = self.state.run_repo.get_runs(run_visible=True)

        groups = []
        for run in runs.values():
            groups.extend(run.groups)

        return groups

    @property
    def failure_groups(self) -> Dict[str, GroupResultsCollection]:
        """The collection of all failure group analysis results."""
        return self.state.run_repo.get_runs(group_type=GroupType.failure)

    def find_clusters(
        self,
        method: Literal["modularity", "global_modularity"] = "modularity",
        subset: Optional[Union[str, CobaltDataSubset, CobaltDataset]] = None,
        graph: Optional[Union[str, HierarchicalCobaltGraph]] = None,
        embedding: Union[int, str, schema.Embedding] = 0,
        min_group_size: Union[int, float] = 1,
        max_group_size: Union[int, float] = np.inf,
        max_n_groups: int = 10000,
        min_n_groups: int = 1,
        config: Optional[Dict[str, Any]] = None,
        run_name: Optional[str] = None,
        manual: bool = True,
        visible: bool = True,
        generate_group_descriptions: bool = True,
    ) -> GroupResultsCollection:
        """Run an analysis to find natural clusters in the dataset.

        Saves the results in self.clustering_results under `run_name`.

        Args:
            method: Algorithm to use for finding clusters. Currently only
                "modularity" is supported.
            subset: The subset of the data on which to perform the analysis. If none
                is provided, will use the entire dataset.
            graph: A graph to use for the clustering. If none is provided, will
                create a new graph based on the specified embedding. Note that
                if a graph is provided, it must be built on the subset specified
                by the ``subset`` parameter.
            embedding: The embedding to use to create a graph if none is
                provided. If none is provided, will use the default dataset
                embedding. (If one does not exist, will raise an error.)
            min_group_size: The minimum size for a returned cluster. If a value
                between 0 and 1 is provided, it will be interpreted as a fraction of
                the size of the subset of data being clustered.
            max_group_size: The maximum size for a returned cluster. If a value
                between 0 and 1 is provided, it will be interpreted as a fraction of
                the size of the subset of data being clustered.
            max_n_groups: The maximum number of clusters to return.
            min_n_groups: The minimum number of clusters to return.
            config: A dictionary containing further configuration parameters
                that will be passed to the underlying algorithm.
            run_name: A name under which to store the results. If one is not
                provided, it will be chosen automatically.
            manual: Used internally to signal whether the clustering analysis
                was created by the user.
            visible: Whether to show the results of this analysis in the UI.
            generate_group_descriptions: Whether to generate statistical and
                textual descriptions of returned clusters. True by default, but
                consider setting to False for large datasets with many columns, or
                when a large number of clusters is desired, as this process can be
                very time consuming.


        Returns:
            A GroupResultsCollection object containing the discovered clusters
            and the parameters used by the algorithm.
        """
        if method not in ("modularity", "global_modularity"):
            raise NotImplementedError(f"method {method} is not implemented")

        if graph is not None:
            graph = self._get_graph(graph)
            if subset is None:
                subset = graph.subset

        if subset is None:
            subset = self.state.dataset.as_subset()
        subset = self._get_subset(subset)
        if not subset.embedding_metadata and not graph:
            return None

        if graph is None:
            graph = self.new_graph("autogroup_graph", subset, embedding)

        if config is None:
            config = {}

        if min_group_size < 1:
            min_group_size = ceil(len(subset) * min_group_size)
        if max_group_size < 1:
            max_group_size = floor(len(subset) * max_group_size)

        if min_group_size > max_group_size:
            raise ValueError("min_group_size must not be greater than max_group_size")
        if min_n_groups > max_n_groups:
            raise ValueError("min_n_groups must not be greater than max_n_groups")

        raw_groups, params = autogroup_modularity(
            graph,
            min_group_size=min_group_size,
            max_group_size=max_group_size,
            max_n_groups=max_n_groups,
            min_n_groups=min_n_groups,
            algorithm="greedy" if method == "modularity" else "global",
            **config,
        )

        if run_name:
            group_name_prefix = run_name
        else:
            run_name = self.state.run_repo.new_run_name()
            group_name_prefix = f"{run_name}_cluster"

        raw_groups.sort(key=lambda g: len(g), reverse=True)

        groups = [
            Cluster(
                name=f"{group_name_prefix}/{i + 1}",
                subset=subset,
                problem_description=f"{len(subset)} points",
            )
            for i, subset in enumerate(raw_groups)
        ]

        run: GroupResultsCollection = self.state.run_repo.build_run(
            run_type=RunType.MANUAL if manual else RunType.AUTOMATIC,
            groups=groups,
            run_name=run_name,
            algorithm=method,
            group_type=GroupType.cluster,
            source_data=subset,
            params=params,
            visible=visible,
        )

        if self.state.dataset.model:
            for m in run.metadata:
                m.add_model_data_histograms(self.state.dataset.model)

        if generate_group_descriptions:
            for m in run.metadata:
                m.compute_comparison_stats(
                    comparison_group="rest",
                    omit_columns=subset.metadata.hidable_columns,
                )
                m.compute_feature_bounds()
            run.compute_group_keywords(warn_if_no_data=False)

        if visible:
            self.run_event_bus.run_all()

        return run

    @property
    def clustering_results(self) -> Dict[str, GroupResultsCollection]:
        """Results from all previous runs of the clustering algorithm."""
        return self.state.run_repo.get_runs(group_type=GroupType.cluster)

    def _get_subset(
        self, subset: Union[str, CobaltDataSubset, CobaltDataset]
    ) -> CobaltDataSubset:
        return self.state.get_subset(subset)

    def _get_embedding(
        self, subset: CobaltDataSubset, embedding: Union[int, str, schema.Embedding] = 0
    ) -> Tuple[np.ndarray, schema.Embedding]:
        return self.graph_builder.get_embedding(subset, embedding)

    def _get_graph(
        self, graph: Union[str, HierarchicalCobaltGraph]
    ) -> HierarchicalCobaltGraph:
        """Get a HierarchicalCobaltGraph from a string name or HierarchicalCobaltGraph."""
        if isinstance(graph, str):
            return self.graphs[graph]
        if not isinstance(graph, HierarchicalCobaltGraph):
            raise TypeError(
                f"Expected 'graph' to be of type 'str' or 'HierarchicalCobaltGraph', "
                f"got {type(graph)}"
            )
        return graph

    def _get_model(
        self,
        model: Union[int, str, ModelMetadata],
        dataset: Optional[CobaltDataset] = None,
    ) -> ModelMetadata:
        if isinstance(model, ModelMetadata):
            return model
        if dataset is None:
            dataset = self.state.dataset
        return dataset.models[model]

    @staticmethod
    def _find_available_column_name(columns: List[str], desired_name: str) -> str:
        name = desired_name
        i = 0
        while name in columns:
            name = f"{desired_name}_{i}"
            i += 1
        return name

    def export_groups_as_dataframe(self) -> pd.DataFrame:
        """Exports saved groups as a DataFrame.

        The columns of the resulting DataFrame are named after the saved groups, and
        the column for each group contains a boolean mask indicating which data
        points in the dataset belong to that group.
        """
        groups = self.get_groups()
        d = {}
        for group in groups.metadata:
            indicator_function = group.subset.as_mask()
            g_name = group.name
            d[g_name] = indicator_function
        return pd.DataFrame(d)

    def import_groups_from_dataframe(self, df: pd.DataFrame):
        """Imports groups from a DataFrame with one column for each group.

        The name of each column will be used as the name for the group,
        and the entries in the column will be interpreted as boolean values
        indicating the membership of each data point in that group.
        """
        groups = [
            {"group_name": col, "group": self.state.dataset.mask(df[col])}
            for col in df.columns
        ]
        self.state.add_groups(groups)

    def _get_summary(self):
        summary_data = {"splits": {}, "models": []}

        for split_name, split_data in self.state.split.items():
            summary_data["splits"][split_name] = {
                "points_number": len(split_data.indices)
            }

        for model in self.state.dataset.models:
            summary_data["models"].append(
                {
                    "model_name": model.name,
                    "model_metadata": {
                        "task": model.task.name,
                        "input_columns": model.input_columns,
                        "outcome_columns": model.outcome_columns,
                        "prediction_columns": model.prediction_columns,
                    },
                }
            )

        return summary_data

    def auto_analysis(
        self,
        ref: Union[str, CobaltDataSubset],
        cmp: Union[str, CobaltDataSubset],
        model: Union[int, str, ModelMetadata] = 0,
        embedding: Union[int, str, schema.Embedding] = 0,
        failure_metric: Optional[Union[str, pd.Series]] = None,
        min_size: int = 3,
        min_failures: int = 3,
        config: Optional[Dict[str, Dict]] = None,
        run_name: Optional[str] = None,
        manual: bool = True,
        visible: bool = True,
    ):
        """Returns an analysis of errors and warnings with the data and model.

        Args:
            ref: The subset of the data on which to do the reference analysis.
                Users should typically pass in the training dataset.
            cmp: The subset of the data on which to do the comparison analysis.
                Users may pass in a test dataset, or a production dataset.
            model: The index or name of the model object you want to consider.
            embedding: The embedding to use to create a graph if none is
                provided. If none is provided, will use the default dataset
                embedding. (If one does not exist, will raise an error.)
            failure_metric: The failure metric to use to find error patterns based on.
            min_size: The minimum size of a returned group.
            min_failures: The minimum number of failures in a failure group, for a
                classification task.
            config: A dictionary containing further configuration parameters
                that will be passed to the underlying algorithm.
            run_name: A name under which to store the results. If one is not
                provided, it will be chosen automatically.
            manual: Used internally to signal whether the clustering analysis
                was created by the user.
            visible: Whether to show the results of this analysis in the UI.

        Returns:
            a dictionary with keys "summaries" and "groups"

            Under "summaries" is a tuple of two DataFrames. The first is a table
            summarizing the discovered error groups; the second is a table
            summarizing the discovered warning groups.

            Under "groups" is a tuple of two lists of CobaltDataSubsets, the
            first listing the error groups, and the second listing the warning
            groups.
        """
        warnings.warn(
            "Workspace.auto_analysis() is deprecated. "
            "Use Workspace.find_failure_groups() and "
            "Workspace.find_drifted_groups() instead.",
            category=DeprecationWarning,
            stacklevel=2,
        )
        # TODO: Add other features to "Explain" our failure modes and make them
        # actionable and prioritizable in a variety of use cases.

        # Examples will include
        # - TFIDF
        # - GPT
        # - External Feature Stores
        # - etc.

        baseline = self._get_subset(ref)
        prod = self._get_subset(cmp)
        combo = baseline.concatenate(prod)

        ### We create failure clusters, then we score them with drift amount.
        ### These are communicated to the data scientist as "Errors".

        fg_run: GroupResultsCollection = self.find_failure_groups(
            subset=combo,
            method="superlevel",
            model=model,
            embedding=embedding,
            min_size=min_size,
            min_failures=min_failures,
            failure_metric=failure_metric,
            config=config,
            run_name=run_name,
            manual=manual,
            visible=visible,
        )

        if fg_run:
            fgs = fg_run.groups
            error_groups_table = fg_run.summary(production_subset=prod)
        else:
            fgs = []
            error_groups_table = []

        ### Now we compute drifted groups, score each by error.
        ### And present these to the customer as "warnings".

        drift_run = self.find_drifted_groups(
            reference_group=baseline,
            comparison_group=prod,
            embedding=embedding,
            config=config,
            min_size=min_size,
        )
        if drift_run:
            drift_groups = drift_run.groups
            warning_groups_table = drift_run.summary(production_subset=prod)
        else:
            drift_groups = []
            warning_groups_table = []

        return {
            "summaries": (error_groups_table, warning_groups_table),
            "groups": (fgs, drift_groups),
        }

    def add_column(
        self,
        key: str,
        data,
        is_categorical: Union[bool, Literal["auto"]] = "auto",
        dataset: Optional[str] = None,
    ):
        """Add or replace a column in the dataset.

        Will update any already-opened UI with the new data, which will not
        happen just by calling CobaltDataset.set_column().

        Args:
            key: Name of the column to add.
            data: ArrayLike of values to store in the column. Must have length
                equal to the length of the dataset.
            is_categorical: Whether the column values should be treated as
                categorical. If "auto" (the default), will autodetect.
            dataset: The name of the dataset to add the column to. If None, will
                add the column to the primary dataset.
        """
        if dataset is None:
            ds = self.state.dataset
        else:
            ds = self.state.dataset_collection.datasets[dataset]
        ds.set_column(key, data, is_categorical)
        event = DatasetEvent("updated", str(self.workspace_id), dataset_name=ds.name)
        self.state.dataset_event_bus.run_all(event)

    def add_dataset(
        self,
        dataset: schema.CobaltDataset,
        name: Optional[str] = None,
        split: Optional[Union[schema.DatasetSplit, SplitDescriptor]] = None,
    ) -> None:
        """Add a dataset to this workspace.

        Args:
            dataset: CobaltDataset to add
            name: Optional name. If not provided, uses dataset.name
            split: Optional split for this dataset. Can be a DatasetSplit or descriptor
                   (dict, list of indices, etc). If not provided, creates default split.

        Example:
            >>> orders = cobalt.CobaltDataset(orders_df)
            >>> orders.name = "orders"
            >>> workspace.add_dataset(orders, split={"train": train_indices, "test": test_indices})
        """
        # Convert split descriptor to DatasetSplit if needed
        if split is not None and not isinstance(split, DatasetSplit):
            split = DatasetSplit(dataset, split)

        self.state.dataset_collection.add_dataset(dataset, name, split)

    def link_datasets(
        self,
        left: Union[str, CobaltDataset],
        right: Union[str, CobaltDataset],
        left_column: str,
        right_column: Optional[str] = None,
    ) -> None:
        """Create a link between two datasets in the workspace.

        There are two cases: if the values in both columns are scalar, rows will
        be linked together if they have the same value in both columns. If one
        column (say, the left) contains lists, then a row in the left dataset
        will be linked to all rows in the right dataset where the value of the
        right column is contained in the list in the left column.

        Args:
            left: Name or CobaltDataset instance of the first dataset.
            right: Name or CobaltDataset instance of the second dataset.
            left_column: Column name in left dataset for linking.
            right_column: Column name in right dataset for linking.
                If None, uses the same column name as left_column.

        Raises:
            ValueError: If a link already exists between these datasets

        Example:
            >>> # Using dataset names
            >>> workspace.link_datasets(
            >>>     "customers", "orders",
            >>>     "customer_id", "customer_id"
            >>> )

            >>> # Using dataset objects with same column name
            >>> workspace.link_datasets(
            >>>     customers, orders,
            >>>     "customer_id"
            >>> )
        """
        # Default right_column to left_column if not provided
        if right_column is None:
            right_column = left_column

        # Get dataset names
        left_name = left.name if isinstance(left, CobaltDataset) else left
        right_name = right.name if isinstance(right, CobaltDataset) else right

        left_ds = self.state.dataset_collection.datasets[left_name]
        right_ds = self.state.dataset_collection.datasets[right_name]

        link = DatasetLink.from_columns(left_ds, right_ds, (left_column, right_column))

        self.state.dataset_collection.add_link(link)

    def get_linked_datasets(self, dataset_name: Optional[str] = None) -> List[str]:
        """Get names of datasets linked to the specified dataset.

        Args:
            dataset_name: Dataset name, or None for primary dataset

        Returns:
            List of dataset names linked to the specified dataset
        """
        if dataset_name is None:
            # Use primary dataset name
            dataset_name = self.state.dataset_collection.primary.name

        links = self.state.dataset_collection.get_links_for_dataset(dataset_name)
        return [name for name, _ in links]

    def get_split(
        self, dataset: Optional[Union[str, CobaltDataset]] = None
    ) -> schema.DatasetSplit:
        """Get the split for a dataset.

        Args:
            dataset: CobaltDataset object, name of a dataset, or None for primary dataset

        Returns:
            DatasetSplit for the specified dataset
        """
        if dataset is None:
            dataset_name = self.state.dataset_collection.primary.name
        elif isinstance(dataset, CobaltDataset):
            dataset_name = dataset.name
        else:
            dataset_name = dataset

        split = self.state.dataset_collection.get_split(dataset_name)
        if split is None:
            raise ValueError(f"Dataset with name {dataset_name} not found.")

        return split

    def save(self, path: str) -> str:
        """Save this workspace to a file.

        The file can be loaded with `Workspace.load()`. It will include the
        dataset, embeddings, saved groups, autogroups, and graphs created in
        this Workspace. However, no UI state will be preserved.

        This method is experimental and forwards compatibility is not
        guaranteed. Future versions of Cobalt may not be able to load Workspaces
        saved with this version.
        """
        subset_library = SubsetLibrary()
        group_library = GroupLibrary()
        default_encode = serialization.get_json_default_for_subsets(
            subset_library, group_library
        )

        datasets_json = {
            name: dataset.to_json()
            for name, dataset in self.state.dataset_collection.datasets.items()
        }

        d = {
            "group_repo": self.state.group_repo,
            "run_repo": self.state.run_repo,
            "graph_repo": self.state.graph_repo,
            "dataset_collection": self.state.dataset_collection,
        }
        workspace_json = json.dumps(
            d, default=default_encode, check_circular=False
        ).encode("utf-8")

        default_encode = get_json_default_for_subsets(subset_library, None)
        json_group_library = json.dumps(
            group_library.__serializable_dict__(),
            default=default_encode,
            check_circular=False,
        ).encode("utf-8")

        json_subset_library = json.dumps(subset_library.__serializable_dict__()).encode(
            "utf-8"
        )

        if os.path.dirname(path):
            os.makedirs(os.path.dirname(path), exist_ok=True)
        if not path.endswith(".cobaltws"):
            path += ".cobaltws"

        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
            # Save datasets as separate files for each dataset
            for name, dataset_json in datasets_json.items():
                # Use safe filename
                safe_name = name.replace("/", "_").replace("\\", "_")
                zf.writestr(f"dataset_{safe_name}.json", dataset_json)

            zf.writestr("groups.json", json_group_library)
            zf.writestr("subsets.json", json_subset_library)
            zf.writestr("workspace_data.json", workspace_json)
        return path

    @staticmethod
    def load(path: str) -> Workspace:
        """Load a Workspace saved with Workspace.save().

        Compatibility with Workspaces saved by previous versions of Cobalt is
        not guaranteed.
        """
        with zipfile.ZipFile(path, "r") as zf:
            file_list = zf.namelist()

            # Check if this is saved in the new multi-dataset format
            is_multi_dataset = any(
                f.startswith("dataset_") and f.endswith(".json") for f in file_list
            )

            if is_multi_dataset:
                return Workspace._load_multi_dataset(zf)
            else:
                return Workspace._load_single_dataset(zf)

    @staticmethod
    def _load_single_dataset(zf: zipfile.ZipFile) -> Workspace:
        """Load a single-dataset workspace (backward compatibility)."""
        with zf.open("dataset.json") as f:
            ds = schema.CobaltDataset.from_json(
                io.TextIOWrapper(f, encoding="utf-8").read()
            )
        with zf.open("subsets.json") as f:
            subsets_dict = json.load(io.TextIOWrapper(f, encoding="utf-8"))

        subset_library = SubsetLibrary.from_dict(subsets_dict, ds)
        object_hook = get_object_hook_for_subsets({"primary": ds}, subset_library, None)
        with zf.open("groups.json") as f:
            group_library_dict = json.load(
                io.TextIOWrapper(f, encoding="utf-8"), object_hook=object_hook
            )

        group_library = GroupLibrary.from_dict(group_library_dict)
        object_hook = get_object_hook_for_subsets(
            {"primary": ds}, subset_library, group_library
        )
        with zf.open("workspace_data.json") as f:
            ws_data = json.load(
                io.TextIOWrapper(f, encoding="utf-8"), object_hook=object_hook
            )

        # Old format: extract split from ws_data
        split_data = ws_data.get("split")
        split = DatasetSplit(ds, split_data) if split_data else DatasetSplit(ds)

        w = Workspace(ds, split)

        w.state.group_repo = ws_data["group_repo"]
        w.state.run_repo = ws_data["run_repo"]
        w.state.graph_repo = ws_data["graph_repo"]

        return w

    @staticmethod
    def _load_multi_dataset(zf: zipfile.ZipFile) -> Workspace:
        """Load a multi-dataset workspace."""
        datasets = {}
        for file_info in zf.namelist():
            if file_info.startswith("dataset_") and file_info.endswith(".json"):
                # Remove "dataset_" prefix and ".json" suffix
                safe_name = file_info[8:-5]
                with zf.open(file_info) as f:
                    ds = schema.CobaltDataset.from_json(
                        io.TextIOWrapper(f, encoding="utf-8").read()
                    )
                actual_name = ds.name or safe_name
                datasets[actual_name] = ds

        if not datasets:
            raise ValueError("No datasets found in workspace file")

        with zf.open("subsets.json") as f:
            subsets_dict = json.load(io.TextIOWrapper(f, encoding="utf-8"))

        subset_library = SubsetLibrary.from_dict_multi(subsets_dict, datasets)

        # Use standard object hook for groups (subsets already reconstituted)
        # Pass dict of datasets so collections can find their source dataset
        object_hook = get_object_hook_for_subsets(datasets, subset_library, None)

        with zf.open("groups.json") as f:
            group_library_dict = json.load(
                io.TextIOWrapper(f, encoding="utf-8"), object_hook=object_hook
            )

        group_library = GroupLibrary.from_dict(group_library_dict)

        # Reload with group library - pass dict of datasets
        object_hook = get_object_hook_for_subsets(
            datasets, subset_library, group_library
        )

        with zf.open("workspace_data.json") as f:
            ws_data = json.load(
                io.TextIOWrapper(f, encoding="utf-8"), object_hook=object_hook
            )

        collection = ws_data.get("dataset_collection")

        primary_dataset = collection.primary
        primary_name = primary_dataset.name
        primary_split = collection.splits[primary_name]

        w = Workspace(primary_dataset, primary_split)

        w.state.dataset_collection = collection

        w.state.group_repo = ws_data["group_repo"]
        w.state.run_repo = ws_data["run_repo"]
        w.state.graph_repo = ws_data["graph_repo"]

        return w
