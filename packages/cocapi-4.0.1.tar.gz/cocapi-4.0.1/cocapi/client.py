"""
Main CocApi client - simplified and modular version
"""

import asyncio
import logging
import time
from collections.abc import Awaitable, Callable
from typing import Any
from warnings import warn

import httpx

from .api_methods import ApiMethods
from .async_client import AsyncCocApiCore
from .cache import CacheManager
from .config import ApiConfig
from .metrics import MetricsTracker
from .middleware import MiddlewareManager
from .models import create_dynamic_model
from .utils import (
    build_url,
    extract_after_cursor,
    extract_items,
    is_successful_response,
    should_retry_error,
    validate_params,
)


class CocApi(ApiMethods):
    """
    Clash of Clans API Wrapper with enhanced v3.0.0 features

    Provides both sync and async interfaces with caching, metrics, middleware,
    and dynamic model generation capabilities.
    """

    def __init__(
        self,
        token: str,
        timeout: int = 20,
        status_code: bool = False,
        config: ApiConfig | None = None,
        async_mode: bool = False,
    ):
        """
        Initialize CocApi with enhanced features

        Args:
            token: API token from developer.clashofclans.com
            timeout: Request timeout in seconds (backward compatibility)
            status_code: Include status code in responses (backward compatibility)
            config: Optional ApiConfig for advanced settings
            async_mode: Enable async mode (default: False for backward compatibility)
        """
        self.token = token
        self.timeout = timeout
        self.status_code = status_code
        self.config = config or ApiConfig(timeout=timeout)
        self.async_mode = async_mode

        # Use config timeout if provided, otherwise use parameter
        if config is None:
            self.config.timeout = timeout

        self.ENDPOINT = self.config.base_url  # Backward compatibility
        self.headers = {
            "authorization": f"Bearer {token}",
            "Accept": "application/json",
        }

        # Initialize components
        self.cache = CacheManager(default_ttl=self.config.cache_ttl)
        self.cache.enable() if self.config.enable_caching else self.cache.disable()

        self.metrics = MetricsTracker(max_metrics=self.config.metrics_window_size)
        self.metrics.enable() if self.config.enable_metrics else self.metrics.disable()

        self.middleware = MiddlewareManager()

        # Async core for async operations
        self._async_core: AsyncCocApiCore | None = None

        # Key manager state (set by from_credentials())
        self._km_email: str | None = None
        self._km_password: str | None = None
        self._km_tokens: list[str] = []

        self.DEFAULT_PARAMS = ("limit", "after", "before")
        self.ERROR_INVALID_PARAM = {
            "result": "error",
            "message": "Invalid params for method",
        }

        # Only test sync mode immediately (async mode tests in context manager)
        if not async_mode:
            test_response = self.test()
            if test_response.get("result") == "error":
                raise ValueError(
                    f"API initialization failed: {test_response.get('message')}"
                )

    @classmethod
    def from_credentials(
        cls,
        email: str,
        password: str,
        timeout: int = 20,
        status_code: bool = False,
        config: ApiConfig | None = None,
    ) -> "CocApi":
        """
        Create a CocApi instance using SuperCell developer portal credentials.

        Instead of providing a raw API token, provide your developer portal
        email and password. Keys are automatically created and managed
        based on your current public IP.

        Args:
            email: SuperCell developer portal email
            password: SuperCell developer portal password
            timeout: Request timeout in seconds
            status_code: Include status code in responses
            config: Optional ApiConfig for advanced settings

        Returns:
            Configured CocApi instance with a managed API token

        Example::

            api = CocApi.from_credentials("email@example.com", "password")
            clan = api.clan_tag("#CLAN_TAG")
        """
        from .key_manager import SyncKeyManager

        config = config or ApiConfig(timeout=timeout)

        with SyncKeyManager(
            email=email,
            password=password,
            key_name=config.key_name,
            key_count=config.key_count,
            key_description=config.key_description,
            persist_keys=config.persist_keys,
            key_storage_path=config.key_storage_path,
        ) as km:
            tokens = km.manage_keys()

        instance = cls(
            token=tokens[0],
            timeout=timeout,
            status_code=status_code,
            config=config,
        )
        instance._km_email = email
        instance._km_password = password
        instance._km_tokens = tokens
        return instance

    def _should_auto_refresh_keys(self) -> bool:
        """Check if auto key refresh is available and enabled."""
        return self._km_email is not None and self.config.auto_refresh_keys

    def _refresh_token(self) -> bool:
        """
        Refresh API token via KeyManager. Returns True if successful.

        Re-detects IP, revokes stale keys, creates new ones as needed.
        """
        from .key_manager import SyncKeyManager

        try:
            with SyncKeyManager(
                email=self._km_email,  # type: ignore[arg-type]
                password=self._km_password,  # type: ignore[arg-type]
                key_name=self.config.key_name,
                key_count=self.config.key_count,
                key_description=self.config.key_description,
                persist_keys=self.config.persist_keys,
                key_storage_path=self.config.key_storage_path,
            ) as km:
                tokens = km.refresh_keys()

            if tokens:
                self.token = tokens[0]
                self._km_tokens = tokens
                self.headers["authorization"] = f"Bearer {self.token}"
                self.cache.clear()
                logging.info("API token refreshed via KeyManager")
                return True
        except Exception as e:
            logging.warning("Token refresh failed: %s", e)

        return False

    # Async Context Manager Support
    async def __aenter__(self) -> "CocApi":
        """Async context manager entry - enables async mode automatically"""
        if not self.async_mode:
            self.async_mode = True  # Auto-enable async mode in context

        self._async_core = AsyncCocApiCore(self.token, self.config)
        await self._async_core.__aenter__()

        # Propagate key manager state for auto-refresh
        if self._km_email is not None:
            self._async_core.set_key_manager_state(
                email=self._km_email,
                password=self._km_password,  # type: ignore[arg-type]
                key_name=self.config.key_name,
                key_count=self.config.key_count,
                auto_refresh=self.config.auto_refresh_keys,
                persist_keys=self.config.persist_keys,
                key_storage_path=self.config.key_storage_path,
            )

        # Test API connection in async mode
        test_response = await self._async_core.test_connection()
        if test_response.get("result") == "error":
            await self.__aexit__(None, None, None)
            raise ValueError(
                f"Async API initialization failed: {test_response.get('message')}"
            )

        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit"""
        if self._async_core:
            await self._async_core.__aexit__(exc_type, exc_val, exc_tb)
            self._async_core = None

    # Core API method - handles both sync and async
    def _api_response(
        self,
        uri: str,
        params: dict[str, Any] | None = None,
        use_dynamic_model: bool = False,
    ) -> dict[str, Any] | Awaitable[dict[str, Any]]:
        """Core API method that routes to sync or async implementation"""
        # Auto-enable models when use_pydantic_models config is set
        if self.config.use_pydantic_models and not use_dynamic_model:
            from .models import validate_pydantic_available

            if validate_pydantic_available():
                use_dynamic_model = True

        if self.async_mode:
            if not self._async_core:
                raise RuntimeError(
                    "Async mode enabled but not in async context. Use 'async with' statement."
                )
            return self._async_core.make_request(uri, params, use_dynamic_model)
        else:
            return self._sync_api_response(uri, params, use_dynamic_model)

    def _sync_api_response(
        self,
        uri: str,
        params: dict[str, Any] | None = None,
        use_dynamic_model: bool = False,
        _refresh_attempted: bool = False,
    ) -> dict[str, Any]:
        """Synchronous API response handling"""
        start_time = time.time()
        cache_hit = False

        # Build URL
        url = build_url(self.config.base_url, uri, params)

        # Check cache first
        if self.config.enable_caching:
            cached_response = self.cache.get(url, params)
            if cached_response is not None:
                cache_hit = True

                # Record metrics for cache hit
                if self.config.enable_metrics:
                    self.metrics.record_request(
                        endpoint=uri,
                        method="GET",
                        status_code=200,
                        response_time=time.time() - start_time,
                        cache_hit=True,
                    )

                # Apply dynamic model if requested
                if use_dynamic_model:
                    cached_response = create_dynamic_model(cached_response, uri)

                # Add status code if requested (backward compatibility)
                if self.status_code:
                    cached_response["status_code"] = 200

                return cached_response

        # Apply request middleware
        headers = self.headers.copy()
        url, headers, request_params = self.middleware.apply_request_middleware(
            url, headers, params or {}
        )

        # Make the request with retries
        for attempt in range(self.config.max_retries):
            try:
                response = httpx.get(url, headers=headers, timeout=self.config.timeout)
                response_time = time.time() - start_time

                if is_successful_response(response.status_code):
                    # Parse JSON response
                    try:
                        json_response = response.json()
                    except Exception as e:
                        error_response = self._handle_json_error(e, attempt)
                        if self.config.enable_metrics:
                            self.metrics.record_request(
                                endpoint=uri,
                                method="GET",
                                status_code=response.status_code,
                                response_time=response_time,
                                cache_hit=False,
                                error_type="json",
                            )
                        return self._add_status_code(
                            error_response, response.status_code
                        )

                    # Apply response middleware
                    json_response = self.middleware.apply_response_middleware(
                        json_response
                    )

                    # Cache successful response
                    if self.config.enable_caching:
                        self.cache.set(url, params, json_response)

                    # Record metrics
                    if self.config.enable_metrics:
                        self.metrics.record_request(
                            endpoint=uri,
                            method="GET",
                            status_code=response.status_code,
                            response_time=response_time,
                            cache_hit=cache_hit,
                        )

                    # Apply dynamic model if requested
                    if use_dynamic_model:
                        json_response = create_dynamic_model(json_response, uri)

                    return self._add_status_code(json_response, response.status_code)

                else:
                    # Auto-refresh on accessDenied.invalidIp (once only)
                    if (
                        response.status_code == 403
                        and not _refresh_attempted
                        and self._should_auto_refresh_keys()
                    ):
                        try:
                            body = response.json()
                            if body.get("reason") == "accessDenied.invalidIp":
                                if self._refresh_token():
                                    return self._sync_api_response(
                                        uri,
                                        params,
                                        use_dynamic_model,
                                        _refresh_attempted=True,
                                    )
                        except Exception:
                            # Auto-refresh is best-effort; fall through to normal error handling
                            pass

                    # Handle HTTP errors
                    error_response = self._handle_http_error(
                        response.status_code, attempt
                    )

                    if self.config.enable_metrics:
                        self.metrics.record_request(
                            endpoint=uri,
                            method="GET",
                            status_code=response.status_code,
                            response_time=response_time,
                            cache_hit=False,
                            error_type="http",
                        )

                    if (
                        not should_retry_error(response.status_code)
                        or attempt >= self.config.max_retries - 1
                    ):
                        return self._add_status_code(
                            error_response, response.status_code
                        )

                    # Wait before retry
                    time.sleep(self.config.retry_delay * (2**attempt))

            except httpx.TimeoutException as e:
                error_response = self._handle_network_error(e, attempt)
                response_time = time.time() - start_time

                if self.config.enable_metrics:
                    self.metrics.record_request(
                        endpoint=uri,
                        method="GET",
                        status_code=0,
                        response_time=response_time,
                        cache_hit=False,
                        error_type="timeout",
                    )

                if attempt >= self.config.max_retries - 1:
                    return self._add_status_code(error_response, 0)

                time.sleep(self.config.retry_delay * (2**attempt))

            except Exception as e:
                error_response = self._handle_network_error(e, attempt)
                response_time = time.time() - start_time

                if self.config.enable_metrics:
                    self.metrics.record_request(
                        endpoint=uri,
                        method="GET",
                        status_code=0,
                        response_time=response_time,
                        cache_hit=False,
                        error_type="connection",
                    )

                if attempt >= self.config.max_retries - 1:
                    return self._add_status_code(error_response, 0)

                time.sleep(self.config.retry_delay * (2**attempt))

        # This should never be reached
        return self._add_status_code(
            {
                "result": "error",
                "message": "Max retries exceeded",
                "error_type": "retry_exhausted",
            },
            0,
        )

    def _add_status_code(
        self, response: dict[str, Any], status_code: int
    ) -> dict[str, Any]:
        """Add status code to response if requested (backward compatibility)"""
        if self.status_code and isinstance(response, dict):
            response["status_code"] = status_code
        return response

    def _handle_http_error(self, status: int, attempt: int) -> dict[str, Any]:
        """Handle HTTP error responses"""
        error_messages = {
            400: "Bad request - check your parameters",
            403: "Forbidden - invalid API token or access denied",
            404: "Not found - check clan/player tag",
            429: "Rate limited - too many requests",
        }

        if status >= 500:
            error_messages[status] = "Server error - try again later"

        error_response = {
            "result": "error",
            "message": error_messages.get(status, f"HTTP error {status}"),
            "error_type": "http",
            "http_status": status,
        }

        return error_response

    def _handle_network_error(self, error: Exception, attempt: int) -> dict[str, Any]:
        """Handle network-related errors"""
        error_type = (
            "timeout" if isinstance(error, httpx.TimeoutException) else "connection"
        )

        messages = {
            "timeout": f"Request timeout after {self.config.timeout} seconds",
            "connection": "Connection error - check your internet connection",
        }

        error_response: dict[str, Any] = {
            "result": "error",
            "message": messages[error_type],
            "error_type": error_type,
        }

        return error_response

    def _handle_json_error(self, error: Exception, attempt: int) -> dict[str, Any]:
        """Handle JSON parsing errors"""
        return {
            "result": "error",
            "message": "Invalid JSON response from API",
            "error_type": "json",
        }

    def _validate_params(self, params: dict[str, Any] | None) -> bool:
        """Validate request parameters"""
        return validate_params(params, self.DEFAULT_PARAMS)

    # Test method
    def test(self) -> dict[str, Any]:
        """Test API connection"""
        try:
            response = self._sync_api_response("/locations")
            if response.get("result") == "error":
                return response
            return {"result": "success", "message": "API connection successful"}
        except Exception as e:
            return {
                "result": "error",
                "message": f"Connection test failed: {str(e)}",
                "error_type": "connection",
            }

    # POST support for endpoints like verifytoken
    def _api_post_response(
        self,
        uri: str,
        json_body: dict[str, Any],
        params: dict[str, Any] | None = None,
        use_dynamic_model: bool = False,
    ) -> dict[str, Any] | Awaitable[dict[str, Any]]:
        """Core POST API method that routes to sync or async implementation"""
        # Auto-enable models when use_pydantic_models config is set
        if self.config.use_pydantic_models and not use_dynamic_model:
            from .models import validate_pydantic_available

            if validate_pydantic_available():
                use_dynamic_model = True

        if self.async_mode:
            if not self._async_core:
                raise RuntimeError(
                    "Async mode enabled but not in async context. Use 'async with' statement."
                )
            return self._async_core.make_post_request(
                uri, json_body, params, use_dynamic_model
            )
        else:
            return self._sync_api_post_response(
                uri, json_body, params, use_dynamic_model
            )

    def _sync_api_post_response(
        self,
        uri: str,
        json_body: dict[str, Any],
        params: dict[str, Any] | None = None,
        use_dynamic_model: bool = False,
        _refresh_attempted: bool = False,
    ) -> dict[str, Any]:
        """Synchronous POST API response handling"""
        start_time = time.time()

        # Apply request middleware before building URL so middleware can modify params
        headers = self.headers.copy()
        url_base = build_url(self.config.base_url, uri, None)
        url_base, headers, request_params = self.middleware.apply_request_middleware(
            url_base, headers, params or {}
        )
        # Rebuild URL with (potentially modified) params
        url = build_url(self.config.base_url, uri, request_params or None)

        # Make the request with retries
        for attempt in range(self.config.max_retries):
            try:
                response = httpx.post(
                    url, headers=headers, json=json_body, timeout=self.config.timeout
                )
                response_time = time.time() - start_time

                if is_successful_response(response.status_code):
                    try:
                        json_response = response.json()
                    except Exception as e:
                        error_response = self._handle_json_error(e, attempt)
                        if self.config.enable_metrics:
                            self.metrics.record_request(
                                endpoint=uri,
                                method="POST",
                                status_code=response.status_code,
                                response_time=response_time,
                                cache_hit=False,
                                error_type="json",
                            )
                        return self._add_status_code(
                            error_response, response.status_code
                        )

                    # Apply response middleware
                    json_response = self.middleware.apply_response_middleware(
                        json_response
                    )

                    # Record metrics
                    if self.config.enable_metrics:
                        self.metrics.record_request(
                            endpoint=uri,
                            method="POST",
                            status_code=response.status_code,
                            response_time=response_time,
                            cache_hit=False,
                        )

                    # Apply dynamic model if requested
                    if use_dynamic_model:
                        json_response = create_dynamic_model(json_response, uri)

                    return self._add_status_code(json_response, response.status_code)

                else:
                    # Auto-refresh on accessDenied.invalidIp (once only)
                    if (
                        response.status_code == 403
                        and not _refresh_attempted
                        and self._should_auto_refresh_keys()
                    ):
                        try:
                            body = response.json()
                            if body.get("reason") == "accessDenied.invalidIp":
                                if self._refresh_token():
                                    return self._sync_api_post_response(
                                        uri,
                                        json_body,
                                        params,
                                        use_dynamic_model,
                                        _refresh_attempted=True,
                                    )
                        except Exception:
                            # Auto-refresh is best-effort; fall through to normal error handling
                            pass

                    error_response = self._handle_http_error(
                        response.status_code, attempt
                    )

                    if self.config.enable_metrics:
                        self.metrics.record_request(
                            endpoint=uri,
                            method="POST",
                            status_code=response.status_code,
                            response_time=response_time,
                            cache_hit=False,
                            error_type="http",
                        )

                    if (
                        not should_retry_error(response.status_code)
                        or attempt >= self.config.max_retries - 1
                    ):
                        return self._add_status_code(
                            error_response, response.status_code
                        )

                    time.sleep(self.config.retry_delay * (2**attempt))

            except httpx.TimeoutException as e:
                error_response = self._handle_network_error(e, attempt)
                response_time = time.time() - start_time

                if self.config.enable_metrics:
                    self.metrics.record_request(
                        endpoint=uri,
                        method="POST",
                        status_code=0,
                        response_time=response_time,
                        cache_hit=False,
                        error_type="timeout",
                    )

                if attempt >= self.config.max_retries - 1:
                    return self._add_status_code(error_response, 0)

                time.sleep(self.config.retry_delay * (2**attempt))

            except Exception as e:
                error_response = self._handle_network_error(e, attempt)
                response_time = time.time() - start_time

                if self.config.enable_metrics:
                    self.metrics.record_request(
                        endpoint=uri,
                        method="POST",
                        status_code=0,
                        response_time=response_time,
                        cache_hit=False,
                        error_type="connection",
                    )

                if attempt >= self.config.max_retries - 1:
                    return self._add_status_code(error_response, 0)

                time.sleep(self.config.retry_delay * (2**attempt))

        return self._add_status_code(
            {
                "result": "error",
                "message": "Max retries exceeded",
                "error_type": "retry_exhausted",
            },
            0,
        )

    # Deprecated endpoint wrapper
    def _deprecated_api_response(
        self,
        uri: str,
        method_name: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | Awaitable[dict[str, Any]]:
        """Try an API call; return deprecation notice on failure"""
        if self.async_mode:
            if not self._async_core:
                raise RuntimeError(
                    "Async mode enabled but not in async context. Use 'async with' statement."
                )
            return self._async_deprecated_response(uri, method_name, params)
        return self._sync_deprecated_response(uri, method_name, params)

    def _sync_deprecated_response(
        self,
        uri: str,
        method_name: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Sync: try the API call, return deprecation notice only for 404/410"""
        response = self._sync_api_response(uri, params)
        if response.get("result") == "error":
            http_status = response.get("http_status", 0)
            if http_status in (404, 410):
                return {
                    "result": "error",
                    "message": (
                        f"This endpoint appears to be deprecated by SuperCell. "
                        f"Method '{method_name}' may no longer be available."
                    ),
                    "error_type": "deprecated",
                }
            return response
        return response

    async def _async_deprecated_response(
        self,
        uri: str,
        method_name: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Async: try the API call, return deprecation on failure"""
        if not self._async_core:
            raise RuntimeError(
                "Async mode enabled but not in async context. Use 'async with' statement."
            )
        response = await self._async_core.make_request(uri, params)
        if response.get("result") == "error":
            http_status = response.get("http_status", 0)
            if http_status in (404, 410):
                return {
                    "result": "error",
                    "message": (
                        f"This endpoint appears to be deprecated by SuperCell. "
                        f"Method '{method_name}' may no longer be available."
                    ),
                    "error_type": "deprecated",
                }
            return response
        return response

    # Pagination
    def paginate(
        self,
        method: Callable[..., Any],
        *args: Any,
        limit: int = 100,
    ) -> Any:
        """Auto-paginate through all results from a list endpoint.

        Yields individual items from each page, automatically following
        the ``after`` cursor until all pages are exhausted.

        Args:
            method: An API method that returns paginated results
                    (e.g. ``api.clan_members``).
            *args:  Positional arguments for the method **excluding** the
                    ``params`` dict (e.g. the clan tag).
            limit:  Items per page (default 100).

        Returns:
            Generator (sync) or async generator (async) of individual items.

        Example::

            for member in api.paginate(api.clan_members, "#TAG"):
                print(member["name"])
        """
        if self.async_mode:
            return self._apaginate(method, *args, limit=limit)
        return self._paginate(method, *args, limit=limit)

    def _paginate(
        self,
        method: Callable[..., Any],
        *args: Any,
        limit: int = 100,
    ) -> Any:
        """Synchronous pagination generator."""
        params: dict[str, Any] = {"limit": limit}
        while True:
            result = method(*args, params=params)
            items = extract_items(result)
            if not items:
                break
            yield from items
            after = extract_after_cursor(result)
            if not after:
                break
            params = {"limit": limit, "after": after}

    async def _apaginate(
        self,
        method: Callable[..., Any],
        *args: Any,
        limit: int = 100,
    ) -> Any:
        """Asynchronous pagination generator."""
        params: dict[str, Any] = {"limit": limit}
        while True:
            result = await method(*args, params=params)
            items = extract_items(result)
            if not items:
                break
            for item in items:
                yield item
            after = extract_after_cursor(result)
            if not after:
                break
            params = {"limit": limit, "after": after}

    # Batch fetch
    def batch(
        self,
        method: Callable[..., Any],
        args_list: list[Any],
        max_concurrent: int | None = None,
    ) -> list[dict[str, Any]] | Awaitable[list[dict[str, Any]]]:
        """Fetch multiple resources in one call.

        Args:
            method:         An API method (e.g. ``api.players``).
            args_list:      List of arguments — each element is passed to
                            *method*.  Use tuples for methods that take
                            multiple positional args.
            max_concurrent: Limit concurrent requests in async mode
                            (ignored in sync mode).

        Returns:
            List of response dicts (sync) or awaitable list (async).
            Failed calls return their error dict in-place.

        Example::

            results = api.batch(api.players, ["#TAG1", "#TAG2", "#TAG3"])
        """
        if self.async_mode:
            return self._abatch(method, args_list, max_concurrent)
        return self._batch(method, args_list)

    def _batch(
        self,
        method: Callable[..., Any],
        args_list: list[Any],
    ) -> list[dict[str, Any]]:
        """Synchronous batch — sequential calls."""
        results: list[dict[str, Any]] = []
        for args in args_list:
            if isinstance(args, (list, tuple)):
                results.append(method(*args))
            else:
                results.append(method(args))
        return results

    async def _abatch(
        self,
        method: Callable[..., Any],
        args_list: list[Any],
        max_concurrent: int | None = None,
    ) -> list[dict[str, Any]]:
        """Asynchronous batch — concurrent calls with optional semaphore."""

        async def _call(args: Any) -> dict[str, Any]:
            if isinstance(args, (list, tuple)):
                return await method(*args)
            return await method(args)

        if max_concurrent:
            sem = asyncio.Semaphore(max_concurrent)

            async def _limited(args: Any) -> dict[str, Any]:
                async with sem:
                    return await _call(args)

            return list(await asyncio.gather(*[_limited(a) for a in args_list]))

        return list(await asyncio.gather(*[_call(a) for a in args_list]))

    # V3.0.0 Enhanced Features
    def custom_endpoint(
        self,
        endpoint_path: str,
        params: dict[str, Any] | None = None,
        use_dynamic_model: bool = False,
    ) -> dict[str, Any] | Awaitable[dict[str, Any]]:
        """
        Call a custom API endpoint (future-proofing for new SuperCell endpoints)

        Args:
            endpoint_path: The endpoint path (e.g., "/clans/new-feature")
            params: Optional query parameters
            use_dynamic_model: Whether to generate dynamic Pydantic models

        Returns:
            API response as dict or Pydantic model
        """
        if not endpoint_path.startswith("/"):
            endpoint_path = "/" + endpoint_path

        return self._api_response(endpoint_path, params, use_dynamic_model)

    def set_base_url(self, new_base_url: str, force: bool = False) -> None:
        """
        Change the base API URL with safety warnings

        Args:
            new_base_url: New base URL to use
            force: Skip safety warnings (use with caution)
        """
        official_url = "https://api.clashofclans.com/v1"

        if new_base_url != official_url and not force:
            warn(
                f"⚠️  WARNING: Changing base URL from official endpoint!\n"
                f"   Official: {official_url}\n"
                f"   New URL:  {new_base_url}\n"
                f"   This may result in API failures or unexpected behavior.\n"
                f"   Use force=True to suppress this warning.",
                UserWarning,
                stacklevel=2,
            )

        original_url = self.config.base_url
        self.config.base_url = new_base_url
        self.ENDPOINT = new_base_url  # Update backward compatibility field

        logging.info(f"Base URL changed from {original_url} to {new_base_url}")

    def get_base_url(self) -> str:
        """Get current base URL"""
        return self.config.base_url

    def reset_base_url(self) -> None:
        """Reset to official SuperCell API URL"""
        official_url = "https://api.clashofclans.com/v1"
        original_url = self.config.base_url

        self.config.base_url = official_url
        self.ENDPOINT = official_url

        if original_url != official_url:
            warn(
                f"Base URL reset to official SuperCell endpoint: {official_url}",
                UserWarning,
                stacklevel=2,
            )
            logging.info(f"Base URL reset from {original_url} to {official_url}")
        else:
            logging.info("Base URL is already set to the official endpoint")

    # Middleware methods
    def add_request_middleware(
        self,
        middleware: Callable[
            [str, dict[str, str], dict[str, Any]],
            tuple[str, dict[str, str], dict[str, Any]],
        ],
    ) -> None:
        """Add request middleware - delegates to middleware manager"""
        self.middleware.add_request_middleware(middleware)

    def add_response_middleware(
        self, middleware: Callable[[dict[str, Any]], dict[str, Any]]
    ) -> None:
        """Add response middleware - delegates to middleware manager"""
        self.middleware.add_response_middleware(middleware)

    # Metrics methods
    def get_metrics(self) -> dict[str, Any]:
        """Get API metrics summary"""
        return self.metrics.get_metrics_summary()

    def clear_metrics(self) -> None:
        """Clear stored metrics"""
        self.metrics.clear_metrics()

    # Cache methods
    def clear_cache(self) -> int:
        """Clear API response cache"""
        return self.cache.clear()

    def get_cache_stats(self) -> dict[str, Any]:
        """Get cache statistics"""
        return self.cache.get_stats()

    # Continue with all the existing API methods...
    # For brevity, I'll include the key ones and the pattern

    # All API endpoint methods are inherited from ApiMethods mixin
