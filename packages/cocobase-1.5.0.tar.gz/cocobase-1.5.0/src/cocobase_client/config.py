BASEURL = "https://api.cocobase.buzz"
# BASEURL = "http://localhost:8000"
