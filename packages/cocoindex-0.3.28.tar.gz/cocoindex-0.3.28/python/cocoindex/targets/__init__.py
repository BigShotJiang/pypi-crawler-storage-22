"""
Targets supported by CocoIndex.
"""

from ._engine_builtin_specs import *
from . import doris
