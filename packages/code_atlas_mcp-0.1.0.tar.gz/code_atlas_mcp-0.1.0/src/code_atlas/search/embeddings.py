"""Embedding client and text builder for Code Atlas.

Uses litellm to route embedding requests to any OpenAI-compatible endpoint
(self-hosted TEI, OpenAI, Cohere, etc.) via a single code path.
"""

from __future__ import annotations

import hashlib
import struct
from collections import OrderedDict
from typing import TYPE_CHECKING, Any

import litellm
import redis.asyncio as aioredis
from loguru import logger

from code_atlas.telemetry import get_tracer

if TYPE_CHECKING:
    from code_atlas.settings import EmbeddingSettings, RedisSettings

_tracer = get_tracer(__name__)


class EmbeddingError(Exception):
    """Raised when an embedding operation fails."""


class EmbedClient:
    """Async embedding client backed by litellm.

    Routes to any OpenAI-compatible endpoint. When ``base_url`` is set
    (e.g. self-hosted TEI), the model is prefixed with ``openai/`` so
    litellm treats it as an OpenAI-compatible API.
    """

    def __init__(self, settings: EmbeddingSettings) -> None:
        self._settings = settings
        self._batch_size = settings.batch_size
        self._timeout = settings.timeout_s
        self._query_cache: OrderedDict[str, list[float]] = OrderedDict()
        self._query_cache_size = settings.query_cache_size

        # Compute the litellm model string based on provider
        if settings.provider == "tei":
            # Self-hosted TEI endpoint — prefix with openai/ for litellm compat
            model = settings.model
            if not model.startswith("openai/"):
                model = f"openai/{model}"
            self._model = model
            self._api_base = settings.base_url
            self._api_key = "unused"  # TEI ignores key, but OpenAI SDK requires one
        elif settings.provider == "ollama":
            # Local Ollama — use base_url but let litellm handle routing
            self._model = settings.model
            self._api_base = settings.base_url
            self._api_key = None
        else:
            # Cloud provider via litellm (openai/, gemini/, voyage/, cohere/, etc.)
            self._model = settings.model
            self._api_base = None
            self._api_key = None

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of texts, chunking by ``batch_size``.

        Returns a flat list of vectors in the same order as *texts*.
        Raises ``EmbeddingError`` on failure.
        """
        if not texts:
            return []

        with _tracer.start_as_current_span(
            "embed.embed_batch", attributes={"batch_size": len(texts), "model": self._model}
        ):
            all_vectors: list[list[float]] = []
            for i in range(0, len(texts), self._batch_size):
                chunk = texts[i : i + self._batch_size]
                try:
                    kwargs: dict[str, Any] = {
                        "model": self._model,
                        "input": chunk,
                        "timeout": self._timeout,
                    }
                    if self._api_base:
                        kwargs["api_base"] = self._api_base
                        # TEI rejects encoding_format=null; explicitly request floats
                        kwargs["encoding_format"] = "float"
                    if self._api_key:
                        kwargs["api_key"] = self._api_key

                    response = await litellm.aembedding(**kwargs)
                    vectors = [
                        item["embedding"] if isinstance(item, dict) else item.embedding for item in response.data
                    ]
                    all_vectors.extend(vectors)
                except Exception as exc:
                    msg = f"Embedding failed for batch [{i}:{i + len(chunk)}]: {exc}"
                    logger.error(msg)
                    raise EmbeddingError(msg) from exc

            return all_vectors

    async def embed_one(self, text: str) -> list[float]:
        """Embed a single text with LRU caching for repeated queries."""
        with _tracer.start_as_current_span("embed.embed_one") as span:
            if text in self._query_cache:
                self._query_cache.move_to_end(text)
                span.set_attribute("cache_hit", True)
                return self._query_cache[text]

            span.set_attribute("cache_hit", False)
            result = await self.embed_batch([text])
            vector = result[0]

            self._query_cache[text] = vector
            if len(self._query_cache) > self._query_cache_size:
                self._query_cache.popitem(last=False)

            return vector

    async def detect_dimension(self) -> int:
        """Probe the embedding service and return the vector dimension."""
        vectors = await self.embed_batch(["dimension probe"])
        return len(vectors[0])

    async def health_check(self) -> bool:
        """Check if the embedding service is reachable.

        For endpoints with ``base_url``, tries a small embedding call.
        Returns True if successful, False otherwise.
        """
        try:
            await self.embed_one("health check")
        except EmbeddingError:
            return False
        else:
            return True


# ---------------------------------------------------------------------------
# Embedding cache (Valkey-backed)
# ---------------------------------------------------------------------------


class EmbedCache:
    """Valkey-backed embedding vector cache.

    Three-tier key scheme: ``{prefix}:emb:{model_hash}:{text_hash}`` where
    *model_hash* is the first 8 hex chars of the SHA-256 of the model name
    (auto-invalidates on model change) and *text_hash* is the SHA-256 hex
    of the embed text.

    Vectors are stored as compact little-endian float32 binary via
    :mod:`struct` (e.g. 3072 bytes for 768-dim).
    """

    def __init__(self, redis_settings: RedisSettings, embed_settings: EmbeddingSettings) -> None:
        url = f"redis://{redis_settings.host}:{redis_settings.port}/{redis_settings.db}"
        if redis_settings.password:
            url = f"redis://:{redis_settings.password}@{redis_settings.host}:{redis_settings.port}/{redis_settings.db}"
        self._redis = aioredis.from_url(url, decode_responses=False)
        self._prefix = redis_settings.stream_prefix
        self._model_hash = hashlib.sha256(embed_settings.model.encode()).hexdigest()[:8]
        self._dimension = embed_settings.dimension
        self._ttl_s = embed_settings.cache_ttl_days * 86400
        self._hits = 0
        self._misses = 0

    @property
    def hits(self) -> int:
        return self._hits

    @property
    def misses(self) -> int:
        return self._misses

    def _key(self, text_hash: str) -> str:
        return f"{self._prefix}:emb:{self._model_hash}:{text_hash}"

    @staticmethod
    def hash_text(text: str) -> str:
        """Return the SHA-256 hex digest of *text*."""
        return hashlib.sha256(text.encode()).hexdigest()

    def _pack_vector(self, vector: list[float]) -> bytes:
        return struct.pack(f"<{len(vector)}f", *vector)

    def _unpack_vector(self, data: bytes) -> list[float]:
        count = len(data) // 4
        return list(struct.unpack(f"<{count}f", data))

    async def get_many(self, hashes: list[str]) -> dict[str, list[float]]:
        """Batch-get cached vectors by text hash. Returns {hash: vector} for hits."""
        if not hashes:
            return {}
        with _tracer.start_as_current_span("embed_cache.get_many", attributes={"count": len(hashes)}):
            try:
                keys = [self._key(h) for h in hashes]
                pipe = self._redis.pipeline(transaction=False)
                for k in keys:
                    pipe.get(k)
                values = await pipe.execute()
            except Exception:
                logger.warning("EmbedCache.get_many failed, treating as cache miss")
                self._misses += len(hashes)
                return {}

            result: dict[str, list[float]] = {}
            for h, val in zip(hashes, values, strict=True):
                if val is not None:
                    result[h] = self._unpack_vector(val)
                    self._hits += 1
                else:
                    self._misses += 1
            return result

    async def put_many(self, items: list[tuple[str, list[float]]]) -> None:
        """Batch-store vectors by text hash with TTL."""
        if not items or self._ttl_s <= 0:
            return
        with _tracer.start_as_current_span("embed_cache.put_many", attributes={"count": len(items)}):
            try:
                pipe = self._redis.pipeline(transaction=False)
                for text_hash, vector in items:
                    pipe.setex(self._key(text_hash), self._ttl_s, self._pack_vector(vector))
                await pipe.execute()
            except Exception:
                logger.warning("EmbedCache.put_many failed, vectors not cached")

    async def clear(self) -> None:
        """Delete all cached embeddings for the current model."""
        try:
            pattern = f"{self._prefix}:emb:{self._model_hash}:*"
            cursor: int | bytes = 0
            while True:
                cursor, keys = await self._redis.scan(cursor=cursor, match=pattern, count=500)
                if keys:
                    await self._redis.delete(*keys)
                if cursor == 0:
                    break
        except Exception:
            logger.warning("EmbedCache.clear failed")

    async def clear_all_models(self) -> None:
        """Delete ALL cached embeddings across all models."""
        try:
            pattern = f"{self._prefix}:emb:*"
            cursor: int | bytes = 0
            while True:
                cursor, keys = await self._redis.scan(cursor=cursor, match=pattern, count=500)
                if keys:
                    await self._redis.delete(*keys)
                if cursor == 0:
                    break
        except Exception:
            logger.warning("EmbedCache.clear_all_models failed")

    async def close(self) -> None:
        """Close the Redis connection."""
        await self._redis.aclose()


# ---------------------------------------------------------------------------
# Embed text builder
# ---------------------------------------------------------------------------

# Node labels that represent code entities (used for template selection)
_CODE_ENTITY_LABELS = frozenset({"Callable", "TypeDef", "Value", "Module"})


def build_embed_text(props: dict[str, Any]) -> str:
    """Build embeddable text from graph node properties.

    Enriches with hierarchical context derived from ``qualified_name``
    (e.g. ``myapp.parser.Parser.process`` → Module / Class / Method).

    Args:
        props: Node properties dict with keys like ``qualified_name``,
               ``signature``, ``docstring``, ``kind``, ``_label``.

    Returns:
        A text string suitable for embedding. Returns empty string if
        the node has insufficient data.
    """
    label = props.get("_label", "")
    qualified_name = props.get("qualified_name", "")
    kind = props.get("kind", "")
    signature = props.get("signature", "")
    docstring = props.get("docstring", "")
    source = props.get("source", "")

    if not qualified_name:
        return ""

    if label == "DocSection":
        return _build_doc_section_text(qualified_name, docstring)
    if label in _CODE_ENTITY_LABELS:
        return _build_code_entity_text(label, kind, qualified_name, signature, docstring, source)

    # Fallback for unknown labels: just use qualified_name + docstring
    parts = [qualified_name]
    if docstring:
        parts.append(docstring)
    return "\n".join(parts)


def _build_code_entity_text(
    label: str, kind: str, qualified_name: str, signature: str, docstring: str, source: str = ""
) -> str:
    """Build embed text for code entities (Callable, TypeDef, Value, Module)."""
    parts = qualified_name.split(".")
    lines: list[str] = []

    if label == "Module":
        lines.append(f"Module: {qualified_name}")
        if docstring:
            lines.append(f'"""{docstring}"""')
        return "\n".join(lines)

    # Reconstruct hierarchy from qualified_name parts
    # e.g. myapp.parser.Parser.process → Module: myapp.parser, Class: Parser, Method: process
    if len(parts) >= 2:
        # Module is everything up to the entity (or its class)
        _method_kinds = ("method", "constructor", "destructor", "static_method", "class_method", "property")
        if label == "Callable" and kind in _method_kinds:
            # Method — parent is a class, grandparent is the module
            if len(parts) >= 3:
                module_name = ".".join(parts[:-2])
                class_name = parts[-2]
                lines.append(f"Module: {module_name}")
                lines.append(f"Class: {class_name}")
            else:
                module_name = ".".join(parts[:-1])
                lines.append(f"Module: {module_name}")
        elif label == "TypeDef":
            module_name = ".".join(parts[:-1])
            lines.append(f"Module: {module_name}")
        else:
            # Top-level function, value, etc.
            module_name = ".".join(parts[:-1])
            lines.append(f"Module: {module_name}")

    # Entity line with kind label
    display_kind = _kind_display(label, kind)
    if signature:
        lines.append(f"{display_kind}: {signature}")
    else:
        lines.append(f"{display_kind}: {parts[-1] if parts else qualified_name}")

    if docstring:
        lines.append(f'"""{docstring}"""')

    if source:
        lines.append("")
        lines.append(source)

    return "\n".join(lines)


def _build_doc_section_text(qualified_name: str, docstring: str) -> str:
    """Build embed text for DocSection nodes.

    The ``qualified_name`` encodes the header breadcrumb
    (e.g. ``docs/architecture.md > Architecture > Event Pipeline > Tier 2``).
    """
    # Split on " > " to get file path and section headers
    breadcrumb_parts = qualified_name.split(" > ")
    lines: list[str] = []

    if breadcrumb_parts:
        lines.append(f"File: {breadcrumb_parts[0]}")
        if len(breadcrumb_parts) > 1:
            lines.append(f"Section: {' > '.join(breadcrumb_parts[1:])}")

    if docstring:
        lines.append(f'"""{docstring}"""')

    return "\n".join(lines)


def _kind_display(label: str, kind: str) -> str:
    """Map label+kind to a human-readable display name for the embed text."""
    if label == "Callable":
        return {
            "function": "Function",
            "method": "Method",
            "constructor": "Constructor",
            "destructor": "Destructor",
            "static_method": "StaticMethod",
            "class_method": "ClassMethod",
            "property": "Property",
            "closure": "Closure",
        }.get(kind, "Function")
    if label == "TypeDef":
        return {
            "class": "Class",
            "struct": "Struct",
            "interface": "Interface",
            "trait": "Trait",
            "enum": "Enum",
            "union": "Union",
            "type_alias": "TypeAlias",
            "protocol": "Protocol",
            "record": "Record",
            "data_type": "DataType",
            "typeclass": "Typeclass",
            "annotation": "Annotation",
        }.get(kind, "Class")
    if label == "Value":
        return {
            "variable": "Variable",
            "constant": "Constant",
            "field": "Field",
            "enum_member": "EnumMember",
        }.get(kind, "Value")
    return label
