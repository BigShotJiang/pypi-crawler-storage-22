# Architecture

## Project Structure

```
code-compass/
├── src/
│   ├── __init__.py           # Package initialization
│   ├── cli/
│   │   ├── __init__.py
│   │   └── main.py           # CLI entry point and command definitions
│   ├── scanner/
│   │   ├── __init__.py
│   │   └── repo_scanner.py   # Repository scanning and analysis
│   ├── query/
│   │   ├── __init__.py
│   │   └── copilot_query.py  # NLP query engine
│   ├── visualizer/
│   │   ├── __init__.py
│   │   └── flow_tracer.py    # Execution flow tracing
│   ├── quality/
│   │   ├── __init__.py
│   │   └── analyzer.py       # Code quality analysis
│   └── docs/
│       ├── __init__.py
│       └── doc_generator.py  # Documentation generation
├── requirements.txt          # Project dependencies
└── README.md
```

## Module Overview

### CLI Module (`src/cli/main.py`)

**Purpose**: Command-line interface for all CodeCompass features.

**Key Components**:
- `cli()`: Main entry point, creates click command group
- `scan()`: Repository structure scanning
- `query()`: Natural language code search
- `trace()`: Execution flow visualization
- `analyze()`: Code quality analysis
- `gendocs()`: Auto-documentation generation

**Dependencies**: click, rich

### Scanner Module (`src/scanner/repo_scanner.py`)

**Purpose**: Analyzes repository structure and file organization.

**Key Classes**:
- `RepoScanner`: Walks repository and collects file/directory information

**Key Methods**:
- `scan()`: Returns structure information
- `_collect_files()`: Gathers all project files
- `_collect_directories()`: Gathers all directories

### Query Module (`src/query/copilot_query.py`)

**Purpose**: Intelligent code querying with natural language understanding.

**Key Classes**:
- `CopilotQuery`: Executes queries against codebase

**Key Methods**:
- `execute()`: Routes queries to appropriate handler
- `_search_query()`: Keyword-based search
- `_definition_query()`: Find class/function definitions
- `_import_query()`: Find imports and dependencies
- `_general_query()`: Answer general project questions

**Capabilities**:
- Searches code for keywords with line numbers
- Finds function and class definitions
- Identifies import statements
- Answers questions about project purpose

### Visualizer Module (`src/visualizer/flow_tracer.py`)

**Purpose**: Traces and visualizes code execution flows.

**Key Classes**:
- `FlowTracer`: Analyzes call chains and execution paths
- `Node`: Represents a function/class in the execution graph

**Key Methods**:
- `trace()`: Analyzes execution flow from entry point
- `_scan_codebase()`: Finds all definitions and calls
- `_extract_definitions()`: Locates functions and classes
- `_extract_calls()`: Identifies function calls
- `_build_call_chain()`: Creates execution tree

**Capabilities**:
- Maps function calls and dependencies
- Shows execution paths with file/line references
- Prevents infinite recursion with depth limits
- Filters out built-in functions

### Quality Module (`src/quality/analyzer.py`)

**Purpose**: Detects code quality issues and security vulnerabilities.

**Key Classes**:
- `CodeAnalyzer`: Analyzes code for issues
- `Issue`: Represents a detected problem

**Issue Types**:
1. **Security** (Critical/Warning)
   - SQL injection patterns
   - Hardcoded secrets/API keys
   - XSS vulnerabilities

2. **Performance** (Warning/Info)
   - N+1 query patterns
   - Nested loops and inefficiency

3. **Code Smells** (Info)
   - Long functions (>30 lines)
   - Large classes (>50 lines)
   - Duplicate code

**Each Issue Includes**:
- File path and line number
- Severity level
- Category
- Description
- Fix suggestion

### Documentation Module (`src/docs/doc_generator.py`)

**Purpose**: Auto-generates project documentation.

**Key Classes**:
- `DocumentationGenerator`: Analyzes project and generates docs

**Generated Files**:
- `README.md`: Project overview and quick start
- `ARCHITECTURE.md`: Detailed architecture guide
- `SETUP.md`: Installation and setup instructions

**Key Methods**:
- `generate()`: Creates all documentation files
- `_analyze_project()`: Scans and analyzes project structure
- `_extract_module_info()`: Extracts info from modules
- `_extract_docstring()`: Gets module docstrings
- `_extract_functions()`: Lists functions
- `_extract_classes()`: Lists classes

## Data Flow

### Query Processing
```
User Input
    ↓
Query Command
    ↓
CopilotQuery.execute()
    ↓
Query Type Detection (search/definition/import/general)
    ↓
Appropriate Handler Method
    ↓
Codebase Analysis
    ↓
Rich Formatted Output
```

### Flow Tracing
```
User Input (function name)
    ↓
Trace Command
    ↓
FlowTracer.trace()
    ↓
Codebase Scanning
    ↓
Definition Extraction
    ↓
Call Analysis
    ↓
Call Chain Building
    ↓
Tree Visualization
    ↓
Rich Formatted Output
```

### Quality Analysis
```
User Input (repository path)
    ↓
Analyze Command
    ↓
CodeAnalyzer.analyze()
    ↓
File-by-File Analysis
    ↓
Security Checks
    ↓
Performance Checks
    ↓
Code Smell Detection
    ↓
Issue Categorization by Severity
    ↓
Rich Formatted Output
```

## Technology Stack

- **Language**: Python 3.7+
- **CLI Framework**: Click
- **Output Formatting**: Rich
- **Pattern Matching**: Regular Expressions
- **File I/O**: Standard Python libraries

## Design Principles

1. **Modularity**: Each feature in its own module with clear responsibilities
2. **Extensibility**: Easy to add new query types, checks, or commands
3. **User-Friendly**: Rich terminal output with colors, tables, and formatting
4. **Non-Invasive**: Reads files, doesn't modify them (except docs generation)
5. **Performance**: Efficient file scanning and pattern matching

---

Generated documentation - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
