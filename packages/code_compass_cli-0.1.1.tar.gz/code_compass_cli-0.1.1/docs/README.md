# 

A Python CLI tool for code analysis and navigation.

## Overview

 provides intelligent code analysis, navigation, and quality checking tools for Python projects.

### Features

- **Code Querying**: Search your codebase with natural language queries
- **Flow Tracing**: Trace execution paths through your code
- **Quality Analysis**: Detect security issues, performance problems, and code smells
- **Auto-Documentation**: Generate comprehensive project documentation

## Quick Start

### Installation

```bash
pip install -r requirements.txt
```

### Basic Usage

```bash
# Scan repository structure
python3 src/cli/main.py scan .

# Query codebase
python3 src/cli/main.py query "find FlowTracer" .

# Trace execution flow
python3 src/cli/main.py trace execute .

# Analyze code quality
python3 src/cli/main.py analyze .

# Generate documentation
python3 src/cli/main.py gendocs .
```

## Commands

### scan
Scan a repository for code structure.
```bash
python3 src/cli/main.py scan <path>
```

### query
Query code with natural language.
```bash
python3 src/cli/main.py query "<question>" <path>
```

### trace
Trace execution flow for a symbol.
```bash
python3 src/cli/main.py trace <function_name> <path>
```

### analyze
Analyze code quality (security, performance, code smells).
```bash
python3 src/cli/main.py analyze <path>
```

### gendocs
Generate documentation for the project.
```bash
python3 src/cli/main.py gendocs <path>
```

## Project Structure

See [ARCHITECTURE.md](ARCHITECTURE.md) for detailed project architecture and module descriptions.

## Setup & Installation

See [SETUP.md](SETUP.md) for detailed setup instructions.

## Requirements

- Python 3.7+
- click>=8.1.0
- rich>=13.0.0

## License

MIT License

---

Generated on 2026-02-03 17:49:14
