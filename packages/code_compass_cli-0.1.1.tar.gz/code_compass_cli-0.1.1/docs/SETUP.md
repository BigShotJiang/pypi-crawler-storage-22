# Setup & Installation Guide

## Requirements

- Python 3.7 or higher
- pip (Python package manager)

## Installation Steps

### 1. Clone or Download the Repository

```bash
cd code-compass
```

### 2. Create a Virtual Environment (Recommended)

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\\Scripts\\activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Verify Installation

```bash
python3 src/cli/main.py --help
```

You should see the help menu with all available commands.

## Project Dependencies

### Required Packages

- **click** (>=8.1.0): Command-line interface framework
  - Used for creating CLI commands
  - Handles argument and option parsing

- **rich** (>=13.0.0): Rich text and formatting library
  - Beautiful terminal output with colors
  - Tables, panels, trees for visualization

### Development (Optional)

For development and testing:
```bash
pip install pytest  # For running tests
pip install flake8  # For linting
pip install black   # For code formatting
```

## Quick Start

After installation, try these commands:

### 1. Scan the Repository

```bash
python3 src/cli/main.py scan .
```

Shows repository structure and files.

### 2. Query the Codebase

```bash
python3 src/cli/main.py query "find FlowTracer" .
```

Searches for code patterns using natural language.

### 3. Trace a Function

```bash
python3 src/cli/main.py trace execute .
```

Shows the execution flow of a function.

### 4. Analyze Code Quality

```bash
python3 src/cli/main.py analyze .
```

Detects security issues, performance problems, and code smells.

### 5. Generate Documentation

```bash
python3 src/cli/main.py gendocs .
```

Auto-generates README, ARCHITECTURE, and SETUP documentation.

## Using with Other Projects

To analyze another Python project:

```bash
python3 src/cli/main.py query "what does this project do" /path/to/project
python3 src/cli/main.py analyze /path/to/project
python3 src/cli/main.py trace main /path/to/project
```

## Troubleshooting

### ModuleNotFoundError: No module named 'click'

**Solution**: Install dependencies
```bash
pip install -r requirements.txt
```

### Virtual Environment Not Activated

**Solution**: Activate the virtual environment
```bash
source venv/bin/activate  # Linux/Mac
venv\\Scripts\\activate      # Windows
```

### Permission Denied on venv/bin/activate

**Solution**: Make it executable
```bash
chmod +x venv/bin/activate
```

### Python 3 Not Found

**Solution**: Use python3 explicitly or check your Python installation
```bash
python3 --version
which python3
```

## Environment Setup for Different Operating Systems

### Linux/macOS

```bash
# Create venv
python3 -m venv venv

# Activate venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run
python3 src/cli/main.py --help
```

### Windows (PowerShell)

```bash
# Create venv
python -m venv venv

# Activate venv
.\\venv\\Scripts\\Activate.ps1

# If you get execution policy error, run:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Install dependencies
pip install -r requirements.txt

# Run
python src\\cli\\main.py --help
```

### Windows (Command Prompt)

```bash
# Create venv
python -m venv venv

# Activate venv
venv\\Scripts\\activate.bat

# Install dependencies
pip install -r requirements.txt

# Run
python src\\cli\\main.py --help
```

## Next Steps

1. Read README.md for feature overview
2. Read ARCHITECTURE.md for technical details
3. Start using commands to analyze your code!

## Getting Help

- Use `--help` flag with any command for usage information
- Check command docstrings in `src/cli/main.py`
- Review module docstrings for implementation details

---

Setup guide generated - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
