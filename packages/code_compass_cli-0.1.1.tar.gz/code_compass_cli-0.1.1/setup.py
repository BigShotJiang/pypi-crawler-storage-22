"""Setup configuration for CodeCompass."""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="code-compass-cli",
    version="0.1.0",
    author="CodeCompass Team",
    author_email="support@codecompass.dev",
    description="A Python CLI tool for intelligent code analysis and navigation",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/techwhiz/code-compass",
    project_urls={
        "Bug Tracker": "https://github.com/techwhiz/code-compass/issues",
        "Documentation": "https://github.com/techwhiz/code-compass#readme",
        "Source Code": "https://github.com/techwhiz/code-compass",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Natural Language :: English",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Utilities",
    ],
    python_requires=">=3.7",
    install_requires=[
        "click>=8.1.0",
        "rich>=13.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=3.0",
            "flake8>=4.0",
            "black>=22.0",
            "mypy>=0.950",
        ],
    },
    entry_points={
        "console_scripts": [
            "codecompass=src.cli.main:cli",
        ],
    },
    include_package_data=True,
    keywords=[
        "code-analysis",
        "code-navigation",
        "code-quality",
        "static-analysis",
        "cli",
        "python",
        "security",
        "performance",
    ],
)
