"""CodeCompass - Python CLI tool for code analysis and navigation."""

__version__ = "0.1.0"
