"""CLI module for CodeCompass."""
