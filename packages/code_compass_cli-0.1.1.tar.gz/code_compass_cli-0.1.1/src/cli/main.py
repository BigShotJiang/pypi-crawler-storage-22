"""Main CLI entry point for CodeCompass."""

import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.tree import Tree

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.scanner.repo_scanner import RepoScanner
from src.query.copilot_query import CopilotQuery
from src.visualizer.flow_tracer import FlowTracer
from src.quality.analyzer import CodeAnalyzer
from src.docs.doc_generator import DocumentationGenerator


console = Console()


@click.group()
@click.version_option()
def cli():
    """CodeCompass - Navigate and analyze code with ease."""
    pass


def _tree_to_rich(tree_node, max_files: int = 100) -> Tree:
    """Convert TreeNode to rich Tree for display.
    
    Args:
        tree_node: The TreeNode to convert
        max_files: Maximum number of files to display
        
    Returns:
        Rich Tree object
    """
    rich_tree = Tree(f"📁 {tree_node.name}")
    _populate_rich_tree(tree_node, rich_tree, 0, max_files)
    return rich_tree


def _populate_rich_tree(tree_node, rich_parent: Tree, depth: int, max_files: int, file_count: list = None) -> None:
    """Recursively populate rich tree with nodes.
    
    Args:
        tree_node: Current TreeNode
        rich_parent: Parent Rich Tree node
        depth: Current recursion depth
        max_files: Maximum files to display
        file_count: List to track file count [current_count]
    """
    if file_count is None:
        file_count = [0]
    
    if depth > 10:
        return
    
    if file_count[0] >= max_files:
        rich_parent.label += " [dim]...[/dim]"
        return
    
    for child in sorted(tree_node.children, key=lambda x: (not x.is_dir, x.name)):
        if file_count[0] >= max_files:
            break
        
        file_count[0] += 1
        
        if child.is_dir:
            child_tree = rich_parent.add(f"📂 [bold]{child.name}[/bold]")
            _populate_rich_tree(child, child_tree, depth + 1, max_files, file_count)
        else:
            # Add file with icon based on extension
            icon = _get_file_icon(child.name)
            rich_parent.add(f"{icon} [cyan]{child.name}[/cyan]")


def _get_file_icon(filename: str) -> str:
    """Get appropriate icon for file type.
    
    Args:
        filename: The file name
        
    Returns:
        Icon string
    """
    ext = filename.split('.')[-1].lower() if '.' in filename else ''
    icons = {
        'py': '🐍',
        'js': '📜',
        'ts': '📘',
        'json': '📋',
        'md': '📝',
        'txt': '📄',
        'yaml': '⚙️',
        'yml': '⚙️',
        'toml': '⚙️',
        'lock': '🔒',
        'git': '🔗',
        'env': '🔑',
    }
    return icons.get(ext, '📄')


@cli.command()
@click.argument('path', default='.', required=False)
def scan(path):
    """Scan a repository for code structure."""
    try:
        scanner = RepoScanner(path)
        result = scanner.scan()
        
        console.print()
        console.print(Panel("[bold cyan]CodeCompass Repository Scan[/bold cyan]", expand=False))
        console.print(f"[bold]Path:[/bold] [yellow]{result['path']}[/yellow]")
        console.print(f"[bold]Files found:[/bold] {len(result['files'])}")
        console.print(f"[bold]Directories:[/bold] {len(result['directories'])}")
        console.print()
        
        # Display directory tree
        rich_tree = _tree_to_rich(result['tree'], max_files=500)
        console.print(rich_tree)
        console.print()
        
        console.print("[bold green]✓ Scan completed successfully[/bold green]")
    except FileNotFoundError as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        sys.exit(1)
    except Exception as e:
        console.print(f"[bold red]✗ Unexpected error:[/bold red] {e}")
        sys.exit(1)



@cli.command()
@click.argument('query_text')
@click.argument('path', default='.', required=False)
def query(query_text, path):
    """Query code with natural language."""
    try:
        copilot = CopilotQuery(path)
        
        console.print()
        console.print(Panel("[bold cyan]CodeCompass Query[/bold cyan]", expand=False))
        console.print(f"[bold]Query:[/bold] {query_text}")
        console.print(f"[dim]Path:[/dim] {path}")
        console.print()
        
        result = copilot.execute(query_text)
        
        if result.get("results"):
            console.print("[bold green]✓ Results found:[/bold green]")
            console.print()
            
            for idx, match in enumerate(result["results"], 1):
                # Display file header
                match_type = match.get("match_type", "Match")
                file_path = match.get("file", "unknown")
                console.print(f"[bold cyan][{idx}] {file_path}[/bold cyan] [dim]({match_type})[/dim]")
                
                # Display keyword
                if match.get("keyword"):
                    console.print(f"  [yellow]Keyword:[/yellow] {match['keyword']}")
                
                # Display content for filename/content matches
                if match.get("content"):
                    console.print("  [bold]Code:[/bold]")
                    code_lines = match["content"].split("\n")
                    for line in code_lines[:15]:  # Limit to 15 lines
                        console.print(f"    [dim]|[/dim] {line}")
                    if len(code_lines) > 15:
                        console.print(f"    [dim]... ({len(code_lines) - 15} more lines)[/dim]")
                
                # Display definitions
                if match.get("definitions"):
                    console.print("  [bold]Definitions:[/bold]")
                    for defn in match["definitions"][:3]:  # Max 3 definitions
                        console.print(f"    [green]{defn.get('type', 'definition')}[/green] at line {defn.get('line_num')}")
                        console.print(f"      [cyan]{defn.get('name', 'unknown')}[/cyan]")
                        if defn.get("code"):
                            console.print(f"      [dim]{defn['code'][:80]}[/dim]")
                        if defn.get("body"):
                            body_preview = defn['body'][:100].replace("\n", " ")
                            console.print(f"      [dim]Body: {body_preview}...[/dim]")
                
                # Display lines for keyword matches
                if match.get("lines"):
                    console.print("  [bold]Matches:[/bold]")
                    for line_info in match["lines"][:2]:  # Max 2 context blocks
                        console.print(f"    Line {line_info.get('line_num')}:")
                        console.print(f"      [yellow]{line_info.get('content', '')}[/yellow]")
                
                # Display import statements
                if match.get("content") and "import" in match.get("content", "").lower():
                    console.print(f"  [bold]Import:[/bold] [dim]{match['content'][:100]}[/dim]")
                
                console.print()
            
            console.print(f"[dim]{result['summary']}[/dim]")
        else:
            console.print("[bold yellow]⚠ No results found[/bold yellow]")
            console.print(f"[dim]Try searching with different keywords or longer file names[/dim]")
        
        console.print()
    except Exception as e:
        console.print(f"[bold red]✗ Error:[/bold red] {e}")
        sys.exit(1)



@cli.command()
@click.argument('symbol')
@click.argument('path', default='.', required=False)
def trace(symbol, path):
    """Trace execution flow for a symbol."""
    tracer = FlowTracer(path)

    console.print()
    console.print(Panel("[bold cyan]CodeCompass Flow Trace[/bold cyan]", expand=False))
    console.print(f"[bold]Entry Point:[/bold] {symbol}")
    console.print(f"[dim]Path:[/dim] {path}")
    console.print()

    result = tracer.trace(symbol)

    if result["flow"]:
        console.print("[bold green]✓ Execution flow traced:[/bold green]")
        console.print()

        # Build a rich tree for visualization
        tree = Tree(f"[bold]{result['entry_point']}[/bold]")
        _build_tree(tree, result["flow"])

        console.print(tree)
        console.print()
        console.print(f"[dim]Total function calls: {result['total_calls']}[/dim]")
    else:
        console.print("[yellow]No execution flow found. Function not located in codebase.[/yellow]")


@cli.command()
@click.argument('path', default='.', required=False)
def analyze(path):
    """Analyze code quality (security, performance, code smells)."""
    analyzer = CodeAnalyzer(path)

    console.print()
    console.print(Panel("[bold cyan]CodeCompass Quality Analysis[/bold cyan]", expand=False))
    console.print(f"[dim]Path:[/dim] {path}")
    console.print()

    result = analyzer.analyze()

    # Display summary
    total = result["total"]
    critical_count = len(result["critical"])
    warning_count = len(result["warning"])
    info_count = len(result["info"])

    console.print("[bold]Analysis Results:[/bold]")
    console.print(f"  [red]🔴 Critical:[/red] {critical_count}")
    console.print(f"  [yellow]🟡 Warnings:[/yellow] {warning_count}")
    console.print(f"  [blue]🔵 Info:[/blue] {info_count}")
    console.print(f"  [dim]Total Issues: {total}[/dim]")
    console.print()

    # Display critical issues
    if critical_count:
        console.print("[bold red]━ CRITICAL ISSUES ━[/bold red]")
        for i, issue in enumerate(result["critical"], 1):
            _display_issue(issue, i)

    # Display warning issues
    if warning_count:
        console.print("[bold yellow]━ WARNINGS ━[/bold yellow]")
        for i, issue in enumerate(result["warning"], 1):
            _display_issue(issue, i)

    # Display info issues
    if info_count:
        console.print("[bold blue]━ INFO ━[/bold blue]")
        for i, issue in enumerate(result["info"][:5], 1):  # Limit to first 5
            _display_issue(issue, i)
        if len(result["info"]) > 5:
            console.print(f"[dim]... and {len(result['info']) - 5} more info messages[/dim]")

    if total == 0:
        console.print("[bold green]✓ No issues found! Code looks clean.[/bold green]")


def _display_issue(issue, index):
    """Display a single issue.

    Args:
        issue: Issue object
        index: Issue number
    """
    severity_color = {
        "critical": "red",
        "warning": "yellow",
        "info": "blue",
    }.get(issue.severity, "white")

    console.print()
    console.print(f"  [{severity_color}]{index}. {issue.category.upper()}[/{severity_color}] "
                 f"[bold]{issue.message}[/bold]")
    console.print(f"     [dim]📄 {issue.file}:{issue.line}[/dim]")
    console.print(f"     [dim]{issue.code_snippet}[/dim]")
    console.print(f"     [cyan]💡 Suggestion:[/cyan] {issue.suggestion}")


def _build_tree(parent_tree, flow_node, depth=0):
    """Build a rich Tree from flow data.

    Args:
        parent_tree: Parent Tree node
        flow_node: Flow data dictionary
        depth: Current depth
    """
    if not flow_node or depth > 5:
        return

    # Add definition info
    if flow_node.get("file"):
        label = f"[cyan]{flow_node['name']}[/cyan] [dim]({flow_node['type']})[/dim]"
        label += f"\n[blue]📄 {flow_node['file']}:{flow_node['line']}[/blue]"
        child = parent_tree.add(label)
    else:
        label = f"[dim]{flow_node['name']}[/dim] [yellow](not found)[/yellow]"
        child = parent_tree.add(label)

    # Add called functions
    if flow_node.get("calls"):
        for call in flow_node["calls"]:
            call_label = f"[cyan]{call['name']}[/cyan]"
            if call.get("called_from"):
                call_label += f"\n[green]→ called from {call['called_from']['file']}:{call['called_from']['line']}[/green]"
            sub_child = child.add(call_label)

            # Recursively add children
            if call.get("calls"):
                for sub_call in call["calls"]:
                    _build_tree_node(sub_child, sub_call, depth + 1)


def _build_tree_node(parent_tree, flow_node, depth=0):
    """Helper to build tree nodes recursively.

    Args:
        parent_tree: Parent Tree node
        flow_node: Flow data dictionary
        depth: Current depth
    """
    if not flow_node or depth > 5:
        return

    label = f"[cyan]{flow_node['name']}[/cyan]"
    if flow_node.get("file"):
        label += f" [blue]({flow_node['file']}:{flow_node['line']})[/blue]"
    else:
        label += " [yellow](not found)[/yellow]"

    child = parent_tree.add(label)

    if flow_node.get("calls"):
        for call in flow_node["calls"]:
            _build_tree_node(child, call, depth + 1)


@cli.command()
@click.argument('path', default='.', required=False)
def gendocs(path):
    """Generate documentation for the project."""
    generator = DocumentationGenerator(path)

    console.print()
    console.print(Panel("[bold cyan]CodeCompass Documentation Generator[/bold cyan]", expand=False))
    console.print(f"[dim]Path:[/dim] {path}")
    console.print()

    console.print("[bold]Generating documentation...[/bold]")
    console.print()

    with console.status("[bold cyan]Analyzing project structure..."):
        docs = generator.generate()

    # Display results
    console.print("[bold green]✓ Documentation generated successfully![/bold green]")
    console.print()

    # Show generated files
    docs_path = Path(path) / "docs"
    console.print("[bold]Generated Files:[/bold]")
    for filename in sorted(docs.keys()):
        filepath = docs_path / filename
        if filepath.exists():
            file_size = filepath.stat().st_size
            console.print(f"  [green]✓[/green] [cyan]{filename}[/cyan] ({file_size:,} bytes)")

    console.print()
    console.print(f"[dim]📁 Location: {docs_path.absolute()}[/dim]")
    console.print()

    # Display file descriptions
    console.print("[bold]File Descriptions:[/bold]")
    console.print()

    descriptions = {
        "README.md": "Project overview, features, and quick start guide",
        "ARCHITECTURE.md": "Detailed architecture, module descriptions, and data flow diagrams",
        "SETUP.md": "Installation instructions for different operating systems",
    }

    for filename, description in descriptions.items():
        console.print(f"  [yellow]•[/yellow] [bold]{filename}[/bold]")
        console.print(f"    [dim]{description}[/dim]")

    console.print()
    console.print("[bold cyan]Next Steps:[/bold cyan]")
    console.print(f"  • Review the generated documentation in: [cyan]{docs_path}[/cyan]")
    console.print("  • Use the documentation for onboarding and reference")
    console.print("  • Share with team members for project understanding")


if __name__ == '__main__':
    cli()
