"""Documentation generation module."""
