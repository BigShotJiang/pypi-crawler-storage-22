"""Code quality analyzer for detecting security, performance, and code smell issues."""

import os
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass


@dataclass
class Issue:
    """Represents a detected code issue."""

    file: str
    line: int
    severity: str  # "critical", "warning", "info"
    category: str  # "security", "performance", "code_smell"
    message: str
    suggestion: str
    code_snippet: str


class CodeAnalyzer:
    """Analyzes code for security issues, performance problems, and code smells."""

    def __init__(self, repo_path: str = "."):
        """Initialize the code analyzer.

        Args:
            repo_path: Path to repository to analyze
        """
        self.repo_path = Path(repo_path)
        self.issues: List[Issue] = []

    def analyze(self) -> Dict[str, Any]:
        """Analyze the codebase for issues.

        Returns:
            Dictionary with analysis results organized by severity
        """
        self.issues = []

        # Scan all Python files
        for root, _, files in os.walk(self.repo_path):
            # Skip venv and hidden directories
            if "venv" in root or "/.git" in root:
                continue

            for file in files:
                if file.endswith(".py"):
                    filepath = Path(root) / file
                    rel_path = filepath.relative_to(self.repo_path)

                    try:
                        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                            content = f.read()
                            self._analyze_file(content, str(rel_path))
                    except (IOError, OSError):
                        continue

        # Organize by severity
        critical = [i for i in self.issues if i.severity == "critical"]
        warnings = [i for i in self.issues if i.severity == "warning"]
        info = [i for i in self.issues if i.severity == "info"]

        return {
            "total": len(self.issues),
            "critical": critical,
            "warning": warnings,
            "info": info,
            "by_category": self._group_by_category(),
        }

    def _analyze_file(self, content: str, filepath: str) -> None:
        """Analyze a single file for issues.

        Args:
            content: File content
            filepath: Path to the file
        """
        self._check_security(content, filepath)
        self._check_performance(content, filepath)
        self._check_code_smells(content, filepath)

    def _check_security(self, content: str, filepath: str) -> None:
        """Check for security issues.

        Args:
            content: File content
            filepath: Path to the file
        """
        lines = content.split("\n")

        # Check for SQL injection patterns
        sql_patterns = [
            (r'(?:query|execute|sql)\s*\(\s*["\'].*%s', "Potential SQL injection - use parameterized queries"),
            (r'(?:query|execute|sql)\s*\(\s*f["\'].*{', "Potential SQL injection - f-strings are vulnerable"),
            (r'\.format\s*\(.*\)\s*for\s+(?:query|execute)', "SQL string formatting detected"),
        ]

        for i, line in enumerate(lines, 1):
            for pattern, msg in sql_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.issues.append(Issue(
                        file=filepath,
                        line=i,
                        severity="critical",
                        category="security",
                        message=f"SQL Injection Risk: {msg}",
                        suggestion="Use parameterized queries/prepared statements",
                        code_snippet=line.strip()[:80],
                    ))

        # Check for exposed secrets/API keys
        secret_patterns = [
            (r'(?:api[_-]?key|secret|password|token|auth)\s*=\s*["\'][^"\']*["\']', "Hardcoded secret/API key"),
            (r'(?:sk_|pk_|Bearer\s+)[A-Za-z0-9\-_]+', "Exposed API key or token"),
            (r'https?://\w+:\w+@', "Credentials in URL"),
        ]

        for i, line in enumerate(lines, 1):
            # Skip if line is commented
            if line.strip().startswith("#"):
                continue

            for pattern, msg in secret_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.issues.append(Issue(
                        file=filepath,
                        line=i,
                        severity="critical",
                        category="security",
                        message=f"Exposed Secret: {msg}",
                        suggestion="Move secrets to environment variables or configuration files",
                        code_snippet=line.strip()[:80],
                    ))

        # Check for XSS vulnerabilities
        xss_patterns = [
            (r'\.innerHTML\s*=\s*(?!.*escape)', "Direct HTML assignment - XSS risk"),
            (r'(?:html|render)\s*\(.*\+.*(?:user_input|request\.args|request\.form)', "User input in HTML - XSS risk"),
        ]

        for i, line in enumerate(lines, 1):
            for pattern, msg in xss_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.issues.append(Issue(
                        file=filepath,
                        line=i,
                        severity="warning",
                        category="security",
                        message=f"XSS Vulnerability: {msg}",
                        suggestion="Escape/sanitize all user input before rendering",
                        code_snippet=line.strip()[:80],
                    ))

    def _check_performance(self, content: str, filepath: str) -> None:
        """Check for performance issues.

        Args:
            content: File content
            filepath: Path to the file
        """
        lines = content.split("\n")

        # Check for N+1 query patterns
        for i in range(len(lines) - 1):
            line = lines[i]

            # Look for loops with potential queries inside
            if re.match(r'^\s*for\s+\w+\s+in\s+', line):
                # Check next few lines for query patterns
                for j in range(i + 1, min(i + 5, len(lines))):
                    if re.search(r'(?:query|execute|filter|get|fetch)\s*\(', lines[j]):
                        self.issues.append(Issue(
                            file=filepath,
                            line=i + 1,
                            severity="warning",
                            category="performance",
                            message="Potential N+1 Query Problem",
                            suggestion="Consider using batch queries or joins instead of looping",
                            code_snippet=line.strip()[:80],
                        ))
                        break

        # Check for inefficient loop patterns
        for i, line in enumerate(lines, 1):
            # Nested loops
            if re.match(r'^\s{8,}for\s+', line):  # Deeply indented for loop
                for j in range(max(0, i - 5), i):
                    if re.match(r'^\s{4,8}for\s+', lines[j - 1]):
                        self.issues.append(Issue(
                            file=filepath,
                            line=i,
                            severity="info",
                            category="performance",
                            message="Nested Loop Detected",
                            suggestion="Consider using list comprehension or optimization",
                            code_snippet=line.strip()[:80],
                        ))
                        break

    def _check_code_smells(self, content: str, filepath: str) -> None:
        """Check for code smells.

        Args:
            content: File content
            filepath: Path to the file
        """
        lines = content.split("\n")

        # Check for long functions (more than 30 lines)
        current_func = None
        func_start = 0

        for i, line in enumerate(lines, 1):
            # Find function definitions
            func_match = re.match(r"^\s*def\s+(\w+)\s*\(", line)
            if func_match:
                if current_func and i - func_start > 30:
                    self.issues.append(Issue(
                        file=filepath,
                        line=func_start,
                        severity="info",
                        category="code_smell",
                        message=f"Function '{current_func}' is too long ({i - func_start} lines)",
                        suggestion="Consider breaking this function into smaller, more focused functions",
                        code_snippet=f"def {current_func}(...)",
                    ))

                current_func = func_match.group(1)
                func_start = i

        # Check final function
        if current_func and len(lines) - func_start > 30:
            self.issues.append(Issue(
                file=filepath,
                line=func_start,
                severity="info",
                category="code_smell",
                message=f"Function '{current_func}' is too long ({len(lines) - func_start} lines)",
                suggestion="Consider breaking this function into smaller, more focused functions",
                code_snippet=f"def {current_func}(...)",
            ))

        # Check for duplicate code patterns (simple heuristic)
        code_lines = [line.strip() for line in lines if line.strip() and not line.strip().startswith("#")]
        seen = {}

        for i, line in enumerate(code_lines):
            # Only check substantial lines
            if len(line) > 20:
                if line in seen:
                    # Found duplicate code
                    if i - seen[line] > 5:  # Not too close
                        self.issues.append(Issue(
                            file=filepath,
                            line=i + 1,
                            severity="info",
                            category="code_smell",
                            message="Duplicate Code Detected",
                            suggestion="Extract this logic into a reusable function",
                            code_snippet=line[:80],
                        ))
                else:
                    seen[line] = i

        # Check for large classes (more than 50 lines)
        current_class = None
        class_start = 0

        for i, line in enumerate(lines, 1):
            class_match = re.match(r"^\s*class\s+(\w+)\s*[\(:]", line)
            if class_match:
                if current_class and i - class_start > 50:
                    self.issues.append(Issue(
                        file=filepath,
                        line=class_start,
                        severity="info",
                        category="code_smell",
                        message=f"Class '{current_class}' is too large ({i - class_start} lines)",
                        suggestion="Consider breaking this class using composition or inheritance",
                        code_snippet=f"class {current_class}:",
                    ))

                current_class = class_match.group(1)
                class_start = i

    def _group_by_category(self) -> Dict[str, List[Issue]]:
        """Group issues by category.

        Returns:
            Dictionary of issues grouped by category
        """
        grouped = {}
        for issue in self.issues:
            if issue.category not in grouped:
                grouped[issue.category] = []
            grouped[issue.category].append(issue)
        return grouped
