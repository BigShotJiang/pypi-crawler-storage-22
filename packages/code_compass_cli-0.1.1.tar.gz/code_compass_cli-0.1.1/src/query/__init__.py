"""Query module for code analysis."""
