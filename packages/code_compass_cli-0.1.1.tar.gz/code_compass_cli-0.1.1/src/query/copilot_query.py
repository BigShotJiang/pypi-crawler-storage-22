"""Code query engine for analyzing source files."""

import os
import re
from pathlib import Path
from typing import Dict, List, Any, Optional


class CopilotQuery:
    """Query interface for code analysis."""

    def __init__(self, repo_path: str = "."):
        """Initialize the query engine.

        Args:
            repo_path: Path to the repository to analyze
        """
        self.repo_path = Path(repo_path)
        self.history: List[Dict[str, Any]] = []
        self._supported_extensions = (
            ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".cpp", ".c", ".h",
            ".php", ".rb", ".go", ".rs", ".sql", ".swift", ".kt"
        )

    def execute(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Execute a query against the codebase.

        Args:
            query: Natural language query string
            context: Optional context about the codebase

        Returns:
            Dictionary containing query results
        """
        query_lower = query.lower()
        results = []

        # Route to appropriate search method
        if any(word in query_lower for word in ["method", "function", "class", "attribute", "define"]):
            results = self._definition_query(query)
        elif any(word in query_lower for word in ["import", "depend", "require"]):
            results = self._import_query(query)
        elif any(word in query_lower for word in ["find", "search", "where", "locate"]):
            results = self._search_query(query)
        else:
            # General query - search source files for keywords
            results = self._general_query(query)

        result_entry = {
            "query": query,
            "context": context or {},
            "results": results,
            "summary": self._generate_summary(results),
        }
        self.history.append(result_entry)
        return result_entry

    def _general_query(self, query: str) -> List[Dict[str, Any]]:
        """Handle general questions by searching source code.

        Args:
            query: Query string

        Returns:
            List of relevant code files
        """
        keywords = self._extract_keywords(query)
        if not keywords:
            return []

        results = []
        # Search for matching files by name and content
        for keyword in keywords:
            file_matches = self._search_files_by_name(keyword)
            content_matches = self._search_files_by_content(keyword, limit_per_keyword=2)
            
            for match in file_matches:
                if match not in results:
                    results.append(match)
            
            for match in content_matches:
                if match not in results:
                    results.append(match)
        
        return results[:10]  # Limit total results

    def _search_files_by_name(self, keyword: str) -> List[Dict[str, Any]]:
        """Search for files matching keyword in filename.

        Args:
            keyword: Search keyword

        Returns:
            List of matching files with content
        """
        matches = []
        keyword_lower = keyword.lower()

        for root, _, files in os.walk(self.repo_path):
            if self._should_skip_dir(root):
                continue

            for filename in files:
                if filename.lower().endswith(self._supported_extensions):
                    # Check if keyword matches filename
                    if keyword_lower in filename.lower():
                        filepath = Path(root) / filename
                        rel_path = filepath.relative_to(self.repo_path)
                        
                        try:
                            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                                content = f.read()
                                matches.append({
                                    "file": str(rel_path),
                                    "keyword": keyword,
                                    "type": "filename_match",
                                    "content": self._extract_relevant_content(content, keyword, lines=30),
                                    "match_type": "File name contains keyword",
                                })
                        except (IOError, OSError):
                            continue

        return matches

    def _search_files_by_content(self, keyword: str, limit_per_keyword: int = 2) -> List[Dict[str, Any]]:
        """Search for content matching keyword in source files.

        Args:
            keyword: Search keyword
            limit_per_keyword: Max files to return per keyword

        Returns:
            List of matching files with relevant content
        """
        matches = []
        keyword_lower = keyword.lower()
        found_count = 0

        for root, _, files in os.walk(self.repo_path):
            if self._should_skip_dir(root):
                continue

            if found_count >= limit_per_keyword:
                break

            for filename in files:
                if found_count >= limit_per_keyword:
                    break

                if filename.lower().endswith(self._supported_extensions):
                    filepath = Path(root) / filename
                    rel_path = filepath.relative_to(self.repo_path)

                    try:
                        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                            content = f.read()
                            # Count matches
                            if keyword_lower in content.lower():
                                relevant_content = self._extract_relevant_content(content, keyword, lines=25)
                                if relevant_content:
                                    matches.append({
                                        "file": str(rel_path),
                                        "keyword": keyword,
                                        "type": "content_match",
                                        "content": relevant_content,
                                        "match_type": "Content contains keyword",
                                    })
                                    found_count += 1
                    except (IOError, OSError):
                        continue

        return matches

    def _search_query(self, query: str) -> List[Dict[str, Any]]:
        """Search for keywords in source code.

        Args:
            query: Search query string

        Returns:
            List of matching files and locations
        """
        keywords = self._extract_keywords(query)
        matches = []

        for keyword in keywords:
            for root, _, files in os.walk(self.repo_path):
                if self._should_skip_dir(root):
                    continue

                for filename in files:
                    if filename.lower().endswith(self._supported_extensions):
                        filepath = Path(root) / filename
                        rel_path = filepath.relative_to(self.repo_path)

                        try:
                            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                                content = f.read()
                                if keyword.lower() in content.lower():
                                    lines = self._find_keyword_lines(content, keyword)
                                    if lines:
                                        matches.append({
                                            "file": str(rel_path),
                                            "keyword": keyword,
                                            "lines": lines,
                                            "match_type": "Keyword found in code",
                                        })
                                    break
                        except (IOError, OSError):
                            continue

        return matches[:15]  # Limit results

    def _definition_query(self, query: str) -> List[Dict[str, Any]]:
        """Search for function/class definitions.

        Args:
            query: Definition query string

        Returns:
            List of definitions found
        """
        keywords = self._extract_keywords(query)
        definitions = []

        for keyword in keywords:
            for root, _, files in os.walk(self.repo_path):
                if self._should_skip_dir(root):
                    continue

                for filename in files:
                    if filename.lower().endswith(self._supported_extensions):
                        filepath = Path(root) / filename
                        rel_path = filepath.relative_to(self.repo_path)

                        try:
                            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                                content = f.read()
                                defs = self._find_definitions(content, keyword, filename)
                                if defs:
                                    definitions.append({
                                        "file": str(rel_path),
                                        "keyword": keyword,
                                        "definitions": defs,
                                        "match_type": "Function/Class definition",
                                    })
                        except (IOError, OSError):
                            continue

        return definitions[:10]

    def _import_query(self, query: str) -> List[Dict[str, Any]]:
        """Search for imports and dependencies.

        Args:
            query: Import query string

        Returns:
            List of imports found
        """
        keywords = self._extract_keywords(query)
        imports = []

        for root, _, files in os.walk(self.repo_path):
            if self._should_skip_dir(root):
                continue

            for filename in files:
                if filename.lower().endswith(self._supported_extensions):
                    filepath = Path(root) / filename
                    rel_path = filepath.relative_to(self.repo_path)

                    try:
                        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                            for line_num, line in enumerate(f, 1):
                                if "import" in line.lower() or "require" in line.lower():
                                    for keyword in keywords:
                                        if keyword.lower() in line.lower():
                                            imports.append({
                                                "file": str(rel_path),
                                                "line": line_num,
                                                "content": line.strip(),
                                                "match_type": "Import/Require statement",
                                            })
                                            break
                    except (IOError, OSError):
                        continue

        return imports[:20]

    def _should_skip_dir(self, path: str) -> bool:
        """Check if directory should be skipped.

        Args:
            path: Directory path

        Returns:
            True if should skip, False otherwise
        """
        skip_patterns = {"venv", ".git", "__pycache__", "node_modules", ".egg-info", "dist", "build", "vendor"}
        for pattern in skip_patterns:
            if pattern in path:
                return True
        return False

    def _extract_relevant_content(self, content: str, keyword: str, lines: int = 20) -> str:
        """Extract relevant content around keyword.

        Args:
            content: File content
            keyword: Search keyword
            lines: Number of lines to include

        Returns:
            Relevant content snippet
        """
        all_lines = content.split("\n")
        keyword_lower = keyword.lower()

        for i, line in enumerate(all_lines):
            if keyword_lower in line.lower():
                start = max(0, i - 2)
                end = min(len(all_lines), i + lines)
                snippet = "\n".join(all_lines[start:end])
                return snippet[:1000]  # Limit to 1000 chars

        return ""

    def _extract_keywords(self, query: str) -> List[str]:
        """Extract search keywords from query.

        Args:
            query: Query string

        Returns:
            List of keywords
        """
        stopwords = {
            "find", "search", "where", "locate", "the", "a", "an", "in", "for",
            "define", "what", "how", "why", "function", "class", "import", "depend",
            "all", "this", "does", "is", "are", "project", "code", "do", "can",
            "will", "should", "by", "and", "or", "not", "to", "of", "with", "from",
            "describe", "explain", "purpose", "method", "file", "files", "require",
            "attribute", "check", "show", "tell", "list", "get", "work", "work",
            "do", "does", "done", "doing", "on", "at", "it", "its", "have", "has"
        }
        words = query.split()
        keywords = [w.strip("'\".,!?;:") for w in words 
                   if w.lower() not in stopwords and len(w.strip("'\".,!?;:")) > 2]
        return keywords

    def _find_keyword_lines(self, content: str, keyword: str, context_lines: int = 3) -> List[Dict[str, Any]]:
        """Find lines containing keyword with context.

        Args:
            content: File content
            keyword: Keyword to search for
            context_lines: Number of context lines to include

        Returns:
            List of matching lines with context
        """
        lines = content.split("\n")
        matches = []
        keyword_lower = keyword.lower()

        for i, line in enumerate(lines):
            if keyword_lower in line.lower():
                start = max(0, i - context_lines)
                end = min(len(lines), i + context_lines + 1)
                matches.append({
                    "line_num": i + 1,
                    "content": line.strip(),
                    "context": "\n".join(lines[start:end]),
                })
                if len(matches) >= 3:
                    break

        return matches

    def _find_definitions(self, content: str, keyword: str, filename: str) -> List[Dict[str, Any]]:
        """Find function/class definitions matching keyword.

        Args:
            content: File content
            keyword: Keyword to search for
            filename: Name of the file

        Returns:
            List of definitions found
        """
        definitions = []
        lines = content.split("\n")
        keyword_esc = re.escape(keyword)

        # Build patterns based on file type
        if filename.endswith(".py"):
            patterns = [
                (r"^\s*def\s+(\w*" + keyword_esc + r"\w*)\s*\(", "function"),
                (r"^\s*class\s+(\w*" + keyword_esc + r"\w*)\s*[\(:]", "class"),
                (r"^\s*async\s+def\s+(\w*" + keyword_esc + r"\w*)\s*\(", "async_function"),
            ]
        elif filename.endswith((".php", ".java", ".cpp", ".c", ".swift", ".kt")):
            patterns = [
                (r"(?:public|private|protected|static)?\s+(?:function|void|int|string|bool|class|interface|struct)\s+(\w*" + keyword_esc + r"\w*)\s*[\({\(]", "function/class"),
            ]
        elif filename.endswith((".js", ".ts", ".jsx", ".tsx")):
            patterns = [
                (r"(?:function|const|let|var)\s+(\w*" + keyword_esc + r"\w*)\s*[=\(]", "function"),
                (r"class\s+(\w*" + keyword_esc + r"\w*)\s*[{]", "class"),
            ]
        else:
            patterns = [
                (r"(?:function|def|class)\s+(\w*" + keyword_esc + r"\w*)", "definition"),
            ]

        for i, line in enumerate(lines):
            for pattern, def_type in patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    # Get function/class body (next few lines)
                    body_start = i + 1
                    body_end = min(len(lines), i + 10)
                    body = "\n".join(lines[body_start:body_end])

                    definitions.append({
                        "line_num": i + 1,
                        "type": def_type,
                        "name": match.group(1),
                        "code": line.strip(),
                        "body": body[:500],  # First 500 chars of body
                    })

        return definitions

    def _generate_summary(self, results: List[Dict[str, Any]]) -> str:
        """Generate a summary of results.

        Args:
            results: List of search results

        Returns:
            Summary string
        """
        if not results:
            return "No matching code found."

        file_count = len(results)
        total_matches = sum(
            len(r.get("lines", [])) + len(r.get("definitions", [])) 
            for r in results if r.get("lines") or r.get("definitions")
        )

        if any(r.get("type") == "filename_match" for r in results):
            return f"Found {file_count} file(s) matching the query keywords."

        if any(r.get("type") == "content_match" for r in results):
            return f"Found {file_count} file(s) with relevant code content."

        if total_matches > 0:
            return f"Found {file_count} file(s) with {total_matches} match(es) in code."

        return f"Found {file_count} relevant file(s)."

    def get_history(self) -> List[Dict[str, Any]]:
        """Get query history.

        Returns:
            List of past queries and results
        """
        return self.history

    def clear_history(self) -> None:
        """Clear query history."""
        self.history = []
