"""Repository scanner for analyzing code structure."""

import os
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class TreeNode:
    """Represents a node in the directory tree."""
    name: str
    is_dir: bool
    children: List['TreeNode'] = None

    def __post_init__(self):
        if self.children is None:
            self.children = []


class RepoScanner:
    """Scans a repository to extract code structure and metadata."""

    # Files/dirs to exclude from scan
    EXCLUDE_PATTERNS = {
        'venv', '.git', '__pycache__', '.pytest_cache', '.egg-info',
        'node_modules', '.env', '.venv', 'dist', 'build', '.DS_Store',
        '*.pyc', '.coverage', '.mypy_cache', 'htmlcov'
    }

    def __init__(self, repo_path: str = '.'):
        """Initialize the repository scanner.

        Args:
            repo_path: Path to the repository to scan
        """
        self.repo_path = Path(repo_path)

    def scan(self) -> Dict[str, Any]:
        """Scan the repository and return structure information.

        Returns:
            Dictionary containing repository structure and metadata
        """
        if not self.repo_path.exists():
            raise FileNotFoundError(f"Repository path not found: {self.repo_path}")

        return {
            "path": str(self.repo_path),
            "tree": self._build_tree(),
            "files": self._collect_files(),
            "directories": self._collect_directories(),
        }

    def _should_exclude(self, path: str) -> bool:
        """Check if a path should be excluded from scan."""
        for pattern in self.EXCLUDE_PATTERNS:
            if pattern.replace('*', '') in path:
                return True
        return False

    def _build_tree(self, start_path: Optional[Path] = None) -> TreeNode:
        """Build a tree structure of the repository.

        Args:
            start_path: Starting path for tree building (defaults to repo_path)

        Returns:
            Root TreeNode of the directory tree
        """
        if start_path is None:
            start_path = self.repo_path

        root = TreeNode(name=start_path.name or str(start_path), is_dir=True)
        self._populate_tree(start_path, root)
        return root

    def _populate_tree(self, current_path: Path, node: TreeNode, depth: int = 0) -> None:
        """Recursively populate tree with directory/file entries.

        Args:
            current_path: Current directory path
            node: Current tree node
            depth: Current recursion depth (limit to 10 to prevent infinite loops)
        """
        if depth > 10:
            return

        try:
            entries = sorted(current_path.iterdir(), key=lambda x: (not x.is_dir(), x.name))
        except PermissionError:
            return

        for entry in entries:
            if self._should_exclude(entry.name):
                continue

            child = TreeNode(name=entry.name, is_dir=entry.is_dir())

            if entry.is_dir():
                self._populate_tree(entry, child, depth + 1)
            
            node.children.append(child)

    def _collect_files(self) -> List[str]:
        """Collect all files in the repository.

        Returns:
            List of file paths
        """
        files = []
        for root, _, filenames in os.walk(self.repo_path):
            if self._should_exclude(root):
                continue
            for filename in filenames:
                if self._should_exclude(filename):
                    continue
                file_path = os.path.join(root, filename)
                rel_path = os.path.relpath(file_path, self.repo_path)
                files.append(rel_path)
        return files

    def _collect_directories(self) -> List[str]:
        """Collect all directories in the repository.

        Returns:
            List of directory paths
        """
        directories = []
        for root, dirnames, _ in os.walk(self.repo_path):
            if self._should_exclude(root):
                continue
            for dirname in dirnames:
                if self._should_exclude(dirname):
                    continue
                dir_path = os.path.join(root, dirname)
                rel_path = os.path.relpath(dir_path, self.repo_path)
                directories.append(rel_path)
        return directories
