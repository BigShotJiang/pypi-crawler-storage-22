import uvicorn
from fastapi import FastAPI, Query
from pydantic import BaseModel
from typing import Optional

app = FastAPI(docs_url="/docs", redoc_url="/redoc")
app.openapi_version = "3.0.2"

class Item(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    tax: Optional[float] = None


@app.get("/items/{item_id}")
def get_item(item_id: int):
    return {"item_id": item_id}


@app.get("/")
def read_root(q: str = Query(default="fastapi")):
    return {"message": q}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
