# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

<!-- insertion marker -->
## [v0.0.20](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.20) - 2026-02-14

<small>[Compare with v0.0.19](https://github.com/sicksubroutine/codec-cub/compare/v0.0.19...v0.0.20)</small>

### Bug Fixes

- update TOML file handler docstring for clarity ([d080438](https://github.com/sicksubroutine/codec-cub/commit/d080438d110ad094f1b9c314ffc21429c5a94e95) by chaz).

## [v0.0.19](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.19) - 2026-01-12

<small>[Compare with v0.0.18](https://github.com/sicksubroutine/codec-cub/compare/v0.0.18...v0.0.19)</small>

### Bug Fixes

- Fix JSON and JSONL File Handlers (#21) ([ad107ef](https://github.com/sicksubroutine/codec-cub/commit/ad107ef52601d3f583f5a994d2116124aca9c591) by Chaz).

## [v0.0.18](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.18) - 2026-01-12

<small>[Compare with v0.0.17](https://github.com/sicksubroutine/codec-cub/compare/v0.0.17...v0.0.18)</small>

### Bug Fixes

- update funcy-bear and frozen-cub dependency versions in pyproject.toml and uv.lock ([f8223aa](https://github.com/sicksubroutine/codec-cub/commit/f8223aad985e00e67a6480a0ac8ecda455e9b338) by chaz).

## [v0.0.17](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.17) - 2026-01-02

<small>[Compare with v0.0.16](https://github.com/sicksubroutine/codec-cub/compare/v0.0.16...v0.0.17)</small>

### Bug Fixes

- update frozen-cub dependency version and correct import statement in quote_scanner.py ([8c00204](https://github.com/sicksubroutine/codec-cub/commit/8c00204554693b821f2547be6eefe8f91b4089c3) by chaz).

## [v0.0.16](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.16) - 2025-12-25

<small>[Compare with v0.0.15](https://github.com/sicksubroutine/codec-cub/compare/v0.0.15...v0.0.16)</small>

### Features

- Update dependencies and refactor minor details (#19) ([d940209](https://github.com/sicksubroutine/codec-cub/commit/d940209d6f9c760ee3e3b4949a4a2bb868e6dba1) by Chaz).
- Refactor codec handling and enhance packing functionality with new data classes ([81cf3dd](https://github.com/sicksubroutine/codec-cub/commit/81cf3dd00c941a5c1dbbc6c4b14a875102bbe874) by chaz).
- Enhance profiling functionality and add ByteAccumulator for MessagePack serialization ([9cf7a3f](https://github.com/sicksubroutine/codec-cub/commit/9cf7a3fd3b1e9d092092a06913aed57efc4dd39a) by chaz).

## [v0.0.15](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.15) - 2025-12-11

<small>[Compare with v0.0.14](https://github.com/sicksubroutine/codec-cub/compare/v0.0.14...v0.0.15)</small>

## [v0.0.14](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.14) - 2025-12-10

<small>[Compare with v0.0.13](https://github.com/sicksubroutine/codec-cub/compare/v0.0.13...v0.0.14)</small>

### Features

- Add Features Related to YAML (#17) ([500baf6](https://github.com/sicksubroutine/codec-cub/commit/500baf6623c4de399c51c8234c40b4b9322b60fa) by Chaz).

## [v0.0.13](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.13) - 2025-12-09

<small>[Compare with v0.0.12](https://github.com/sicksubroutine/codec-cub/compare/v0.0.12...v0.0.13)</small>

## [v0.0.12](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.12) - 2025-12-09

<small>[Compare with v0.0.11](https://github.com/sicksubroutine/codec-cub/compare/v0.0.11...v0.0.12)</small>

### Features

- implement TOON builder API with tabular encoding support and ad… (#16) ([2360ee3](https://github.com/sicksubroutine/codec-cub/commit/2360ee364cc7b4df0d232bf1b50bd7f55e6a9b39) by Chaz).
- update read method signatures to support None return type and enhance utility functions with final constants (#15) ([af4e217](https://github.com/sicksubroutine/codec-cub/commit/af4e217d0a9d46744f7db131862135fbfdaaf5e6) by Chaz).

### Bug Fixes

- update funcy-bear dependency to version 0.0.21 ([8cb2229](https://github.com/sicksubroutine/codec-cub/commit/8cb22290e4a3f6be7de28530dcd93f615ab132b9) by chaz).

## [v0.0.11](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.11) - 2025-12-08

<small>[Compare with v0.0.10](https://github.com/sicksubroutine/codec-cub/compare/v0.0.10...v0.0.11)</small>

## [v0.0.10](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.10) - 2025-12-08

<small>[Compare with v0.0.9](https://github.com/sicksubroutine/codec-cub/compare/v0.0.9...v0.0.10)</small>

### Features

- introduce Wrapper class and enhance NixCodecConfig options (#14) ([2314f5e](https://github.com/sicksubroutine/codec-cub/commit/2314f5e90bfd4e536207d12013539fa21325dad0) by Chaz).

## [v0.0.9](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.9) - 2025-12-05

<small>[Compare with v0.0.8](https://github.com/sicksubroutine/codec-cub/compare/v0.0.8...v0.0.9)</small>

## [v0.0.8](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.8) - 2025-11-24

<small>[Compare with v0.0.7](https://github.com/sicksubroutine/codec-cub/compare/v0.0.7...v0.0.8)</small>

## [v0.0.7](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.7) - 2025-11-19

<small>[Compare with v0.0.6](https://github.com/sicksubroutine/codec-cub/compare/v0.0.6...v0.0.7)</small>

## [v0.0.6](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.6) - 2025-11-17

<small>[Compare with v0.0.5](https://github.com/sicksubroutine/codec-cub/compare/v0.0.5...v0.0.6)</small>

## [v0.0.5](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.5) - 2025-11-16

<small>[Compare with v0.0.3](https://github.com/sicksubroutine/codec-cub/compare/v0.0.3...v0.0.5)</small>

## [v0.0.3](https://github.com/sicksubroutine/codec-cub/releases/tag/v0.0.3) - 2025-11-15

<small>[Compare with first commit](https://github.com/sicksubroutine/codec-cub/compare/5715b9f87846882afad66ef1a6b922831ae7bd0c...v0.0.3)</small>

### Features

- Implement PyDB codec (#6) ([59c0ec8](https://github.com/sicksubroutine/codec-cub/commit/59c0ec81f1f536bd590fb8e1741d6ea3921bbcc5) by Chaz). Co-authored-by: Claude
