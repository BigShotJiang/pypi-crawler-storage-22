import json
import statistics
import timeit
from typing import Any

from codec_cub.message_pack import pack, unpack

SAMPLE_DATA: dict[str, Any] = {
    "name": "Benchmark",
    "values": list(range(1000)),
    "nested": {"a": 1, "b": [1, 2, 3], "c": {"d": 4, "e": {"f": 5}}},
    "float": 3.14159,
    "bool": True,
    "none": None,
}


def benchmark_pack(data: object, iterations: int = 100_000, repeat: int = 5) -> dict:
    """Benchmark packing with statistical information.

    Returns:
        dict with 'mean', 'min', 'max', 'stdev' in microseconds
    """
    timer = timeit.Timer(lambda: pack(data))
    times: list[float] = timer.repeat(repeat=repeat, number=iterations)
    times_us: list[float] = [(t / iterations) * 1_000_000 for t in times]

    return {
        "mean": f"{statistics.mean(times_us):.2f} us",
        "min": f"{min(times_us):.2f} us",
        "max": f"{max(times_us):.2f} us",
        "stdev": f"{statistics.stdev(times_us) if len(times_us) > 1 else 0:.2f} us",
        "median": f"{statistics.median(times_us):.2f} us",
    }


def benchmark_unpack(packed_data: bytes, iterations: int = 10000, repeat: int = 5) -> dict:
    """Benchmark the unpacking of data using MessagePack.

    Args:
        packed_data: The packed data to be unpacked.
        iterations: Number of iterations to run the benchmark.

    Returns:
        Average time taken per unpacking operation in microseconds.
    """
    timer = timeit.Timer(lambda: unpack(packed_data))
    times: list[float] = timer.repeat(repeat=repeat, number=iterations)
    times_us: list[float] = [(t / iterations) * 1_000_000 for t in times]

    return {
        "mean": f"{statistics.mean(times_us):.2f} us",
        "min": f"{min(times_us):.2f} us",
        "max": f"{max(times_us):.2f} us",
        "stdev": f"{statistics.stdev(times_us) if len(times_us) > 1 else 0:.2f} us",
        "median": f"{statistics.median(times_us):.2f} us",
    }


if __name__ == "__main__":
    ITERATIONS = 100_000
    packed_sample = pack(SAMPLE_DATA)

    pack_time = benchmark_pack(SAMPLE_DATA, iterations=ITERATIONS)
    unpack_time = benchmark_unpack(packed_sample, iterations=ITERATIONS)
    print(f"Packing benchmark over {ITERATIONS} iterations: {json.dumps(pack_time, indent=2)}")
    print(f"Unpacking benchmark over {ITERATIONS} iterations: {json.dumps(unpack_time, indent=2)}")
