from __future__ import annotations

from importlib.util import find_spec
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

HAS_ORJSON: bool = find_spec("orjson") is not None

json_loads: Callable[[bytes], Any]
json_dumps: Callable[..., bytes]
DecodeError: type[Exception]


if HAS_ORJSON:
    import orjson

    def _kwargs_to_option(**kwargs: Any) -> int:
        option: int = orjson.OPT_NON_STR_KEYS

        if kwargs.get("indent"):
            option |= orjson.OPT_INDENT_2
        if kwargs.get("sort_keys"):
            option |= orjson.OPT_SORT_KEYS
        if kwargs.get("append_newline"):
            option |= orjson.OPT_APPEND_NEWLINE

        return option

    def _orjson_loads(data: bytes, **_: Any) -> Any:
        return orjson.loads(data)

    def _orjson_dumps(data: Any, **kwargs: Any) -> bytes:
        option: int = _kwargs_to_option(**kwargs)
        return orjson.dumps(data, option=option)

    json_dumps = _orjson_dumps
    json_loads = _orjson_loads
    DecodeError = orjson.JSONDecodeError
else:
    import json

    def _json_loads(data: bytes, **kwargs: Any) -> Any:
        return json.loads(data, **kwargs)

    def _json_dumps(data: Any, **kwargs: Any) -> bytes:
        return json.dumps(data, **kwargs).encode("utf-8")

    json_loads = _json_loads
    json_dumps = _json_dumps
    DecodeError = json.JSONDecodeError


__all__ = ["DecodeError", "json_dumps", "json_loads"]
