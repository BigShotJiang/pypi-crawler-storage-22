"""A dataclass to hold file metadata information."""

from __future__ import annotations

from enum import StrEnum
from functools import lru_cache
from pathlib import Path
import sys
from typing import TYPE_CHECKING, Final

from codec_cub.general.helpers import get_file_hash, touch as _touch
from funcy_bear.constants import GIGABYTES, KILOBYTES, MEGABYTES
from funcy_bear.constants.type_constants import StrPath  # noqa: TC001

if TYPE_CHECKING:
    from os import stat_result

    from funcy_bear.protocols.general import PathInfo


IS_BINARY = -1
ASCII_SPACE = 0x20
ASCII_PRINTABLE: set[int] = set(range(32, 127)) | {0x09, 0x0A, 0x0D}
BINARY_THRESHOLD = 0.3


def is_binary(path_to_file: Path) -> bool:
    """Check if a file is binary by reading a chunk of it."""
    if not path_to_file.is_file():
        return False
    with open(path_to_file, "rb") as f:
        chunk: bytes = f.read(8192)
    if len(chunk) == 0:
        return False
    non_text_chars: int = sum(1 for byte in chunk if byte < ASCII_SPACE and byte not in ASCII_PRINTABLE)
    return bool(b"\x00" in chunk and non_text_chars / len(chunk) > BINARY_THRESHOLD)


def size_str(size: int) -> str:
    """Convert a file size in bytes to a human-readable string."""
    if size >= GIGABYTES:
        return f"{size / GIGABYTES:.2f} GB"
    if size >= MEGABYTES:
        return f"{size / MEGABYTES:.2f} MB"
    if size >= KILOBYTES:
        return f"{size / KILOBYTES:.2f} KB"
    return f"{size} bytes"


ABOVE_3_14: Final = sys.version_info >= (3, 14)


class OS(StrEnum):
    """Enumeration of operating systems."""

    DARWIN = "Darwin"
    """MacOS platform also known as Darwin."""
    LINUX = "Linux"
    """Linux platform."""
    WINDOWS = "Windows"
    """Windows platform."""
    BSD = "BSD"
    """BSD platform."""
    OTHER = "Other"
    """Other or unsupported platform."""


@lru_cache(maxsize=1)
def get_platform(cached: bool = True) -> OS:
    """Return the current operating system as an :class:`OS` enum.

    Optional arg for cached mainly for testing purposes so we can turn it off
    and force re-evaluation.

    Args:
        cached (bool): Whether to cache the result for future calls. Defaults to `True`.

    Returns:
        OS: The current operating system as an enum member, or `OS.OTHER` if the platform is not recognized.
    """
    import platform

    system: str = platform.system()
    if not cached:
        get_platform.cache_clear()
    return OS(system) if system in OS.__members__.values() else OS.OTHER


def created(get_stat: stat_result | None) -> float | None:
    """Get the creation time from a stat result, handling OS differences."""
    platform: OS = get_platform()
    if get_stat is None:
        return None

    if platform is OS.DARWIN and hasattr(get_stat, "st_birthtime"):
        return getattr(get_stat, "st_birthtime", None)
    if platform is OS.WINDOWS:
        return get_stat.st_ctime
    return get_stat.st_mtime


class FileInfo(Path):
    """Dataclass to hold file metadata information."""

    def __init__(self, path: StrPath) -> None:
        """Initialize FileInfo with a Path object."""
        self.path: Path = Path(path)
        self._is_binary: bool | None = None
        self._get_stat: stat_result | None = None
        self._size: int | None = None
        self._length: int | None = None
        self._length_str: str | None = None
        self._size_str: str | None = None
        self._created: float | None = None
        self._modified: float | None = None
        self._does_exist: bool | None = None

    def touch(self, exist_ok: bool = True, **kwargs) -> None:  # pyright: ignore[reportIncompatibleMethodOverride]
        """Create the file if it does not exist."""
        _touch(self.path, exist_ok=exist_ok, **kwargs)

    def __fspath__(self) -> str:
        """Return the file system path representation."""
        return str(self.path)

    def exists(self, **kwargs) -> bool:
        """Check if the file exists."""
        return self.path.exists(**kwargs)

    def is_file(self, **kwargs) -> bool:
        """Check if the path is a file."""
        return self.path.is_file(**kwargs) if self.does_exist else False

    def is_dir(self, **kwargs) -> bool:
        """Check if the path is a directory."""
        return self.path.is_dir(**kwargs) if self.does_exist else False

    def is_symlink(self) -> bool:
        """Check if the path is a symbolic link."""
        return self.path.is_symlink() if self.does_exist else False

    def resolve(self, strict: bool = False) -> Path:
        """Resolve the path to its absolute form."""
        return self.path.resolve(strict=strict)

    def copy(self, dst: StrPath, **kwargs) -> Path:  # pyright: ignore[reportIncompatibleMethodOverride]
        """Copy file to destination.

        Args:
            dst: Destination path
            **kwargs: Additional arguments for Python 3.14+ Path.copy()

        Returns:
            The path to the copied file.
        """
        dest_path = Path(dst)
        if ABOVE_3_14:
            return self.path.copy(dest_path, **kwargs)
        import shutil

        shutil.copy2(self.path, dest_path)
        return dest_path

    def copy_into(self, dst: StrPath, **kwargs) -> Path:  # pyright: ignore[reportIncompatibleMethodOverride]
        """Copy the file into a new location.

        Args:
            dst: Destination path
            **kwargs: Additional arguments for Python 3.14+ Path.copy_into()

        Returns:
            The path to the copied file.
        """
        dest_path = Path(dst)
        if ABOVE_3_14:
            return self.path.copy_into(dest_path, **kwargs)
        import shutil

        shutil.copy2(self.path, dest_path)
        return dest_path

    def move(self, dst: StrPath, **kwargs) -> Path:  # pyright: ignore[reportIncompatibleMethodOverride]
        """Move the file to a new location.

        Args:
            dst: Destination path
            **kwargs: Additional arguments for Python 3.14+ Path.move()

        Returns:
            The path to the moved file.
        """
        dest_path = Path(dst)
        if ABOVE_3_14:
            return self.path.move(dest_path, **kwargs)
        import shutil

        shutil.move(self.path, dest_path)
        return dest_path

    def move_into(self, dst: StrPath, **kwargs) -> Path:  # pyright: ignore[reportIncompatibleMethodOverride]
        """Move the file into a new location.

        Args:
            dst: Destination path
            **kwargs: Additional arguments for Python 3.14+ Path.move_into()

        Returns:
            The path to the moved file.
        """
        dest_path = Path(dst)
        if ABOVE_3_14:
            return self.path.move_into(dest_path, **kwargs)
        import shutil

        shutil.move(self.path, dest_path)
        return dest_path

    def chmod(self, mode: int, **kwargs) -> None:
        """Change the file's mode."""
        self.path.chmod(mode, **kwargs)

    def rmdir(self, del_all: bool = False) -> None:
        """Remove the directory.

        Args:
            del_all: If True, remove all contents recursively.

        Raises:
            OSError: If the directory is not empty and del_all is False.
        """
        if del_all:
            import shutil

            shutil.rmtree(self.path)
        else:
            self.path.rmdir()

    @property
    def _raw_paths(self) -> tuple[str, ...]:
        """Get the raw paths from the underlying Path object."""
        return self.path._raw_paths  # type: ignore[attr-defined]

    @property
    def _str(self) -> str:
        """Get the string representation of the underlying Path object."""
        return str(self.path)

    @_str.setter
    def _str(self, value: str) -> None:
        """Set the string representation of the underlying Path object."""
        self.path = Path(value)

    @property
    def info(self) -> PathInfo:
        """Get the file info (available in Python 3.14+)."""
        if ABOVE_3_14:
            return self.path.info
        raise NotImplementedError("Path.info is not available in Python versions below 3.14.")

    @property
    def name(self) -> str:
        """Get the file name."""
        return self.path.name

    @property
    def ext(self) -> str:
        """Get the file extension."""
        return self.path.suffix.lstrip(".")

    @property
    def does_exist(self) -> bool:
        """Check if the file exists."""
        return self.exists()

    @property
    def file_hash(self) -> str:
        """Get the SHA256 hash of the file."""
        if not self.does_exist or not self.is_file():
            return ""
        return get_file_hash(self.path)

    @property
    def is_binary(self) -> bool:
        """Check if the file is binary by attempting to read it as text."""
        if self._is_binary is None:
            if not self.is_file():
                self._is_binary = False
            else:
                self._is_binary = is_binary(self.path)
        return self._is_binary

    @property
    def get_stat(self) -> stat_result | None:  # type: ignore[override]
        """Get the file's stat result."""
        if not self.does_exist:
            return None
        if self._get_stat is None:
            self._get_stat = self.path.stat()
        return self._get_stat

    @property
    def size(self) -> int:
        """Get the file size in bytes."""
        if self._size is None:
            if not self.does_exist or not self.is_file() or self.get_stat is None:
                return 0
            self._size = self.get_stat.st_size
        return self._size

    @property
    def length(self) -> int:
        """Get the number of lines in the file."""
        if self._length is None:
            if not self.does_exist or not self.is_file() or self.size == 0:
                return 0
            if self.is_binary:
                self._length = IS_BINARY
            else:
                self._length = len(self.path.read_text(encoding="utf-8").splitlines())
        return self._length

    @property
    def length_str(self) -> str:
        """Get a human-readable string for the number of lines in the file."""
        if self.length == IS_BINARY:
            return "binary"
        return f"{self.length} lines"

    @property
    def size_str(self) -> str:
        """Get a human-readable file size string."""
        if self._size_str is None:
            self._size_str = size_str(self.size)
        return self._size_str

    @property
    def created(self) -> float | None:
        """Get the file creation time as a timestamp."""
        if self._created is None:
            self._created = created(self.get_stat)
        return self._created

    @property
    def modified(self) -> float | None:
        """Get the file modification time as a timestamp."""
        if self._modified is None:
            self._modified = self.get_stat.st_mtime if self.get_stat is not None else None
        return self._modified

    def invalidate_cache(self) -> None:
        """Invalidate cached properties."""
        self._is_binary = None
        self._get_stat = None
        self._size = None
        self._length = None
        self._length_str = None
        self._size_str = None
        self._created = None
        self._modified = None
        self._does_exist = None


# ruff: noqa: PLC0415
