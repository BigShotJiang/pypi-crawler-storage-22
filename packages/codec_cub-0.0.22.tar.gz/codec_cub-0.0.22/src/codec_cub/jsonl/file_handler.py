"""A module for handling JSON Lines (JSONL) files with caching and file locking."""

from __future__ import annotations

from pathlib import Path
from typing import IO, TYPE_CHECKING, Any

from codec_cub.general._orjson_helper import json_dumps
from codec_cub.general.file_lock import LockExclusive
from codec_cub.text.bytes_handler import BytesFileHandler
from funcy_bear.constants.type_constants import StrPath  # noqa: TC001

from .utils import deserialize, deserialize_line, jsonl_serialize

if TYPE_CHECKING:
    from collections.abc import Generator


class JSONLFileHandler[File_T](BytesFileHandler):
    """A JSONL file handler for reading and writing JSON Lines files.

    JSONL format stores one JSON object per line, making it ideal for:
    - Append-only logging and data collection
    - Streaming large datasets without loading everything into memory
    - Simple line-by-line processing
    """

    def __init__(
        self,
        file: StrPath,
        mode: str = "a+b",
        touch: bool = False,
    ) -> None:
        """Initialize the handler with the path to the JSONL file.

        Args:
            file: Path to the JSONL file
            mode: File open mode (default: "a+b")
            touch: Whether to create the file if it doesn't exist (default: False)
        """
        super().__init__(file, mode=mode, touch=touch)

    def read(self, **kwargs: Any) -> list[File_T] | None:  # pyright: ignore[reportIncompatibleMethodOverride]
        """Read all records from the JSONL file.

        Returns:
            A list of records (typically dicts) read from the file, or None if empty.
        """
        handle: IO | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")
        data: list[File_T] = deserialize(handle, **kwargs)
        if not data:
            return None
        return data

    def write(self, data: list[File_T]) -> None:  # pyright: ignore[reportIncompatibleMethodOverride]
        """Write records to the JSONL file, replacing existing content.

        Args:
            data: A list of records to write (typically dicts, strings, or bytes).
        """
        handle: IO[Any] | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")
        with LockExclusive(handle):
            handle.seek(0)
            handle.truncate(0)
            handle.flush()
            lines: list[bytes] = jsonl_serialize(data)
            handle.writelines(line + b"\n" for line in lines)
            handle.flush()

    def append_records(self, records: list[File_T]) -> None:
        """Append records to the end of the JSONL file.

        Args:
            records: A list of records to append (typically dicts, strings, or bytes).
        """
        handle: IO[Any] | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")
        with LockExclusive(handle):
            handle.seek(0, 2)  # Seek to end of file
            lines: list[bytes] = jsonl_serialize(records)
            handle.writelines(line + b"\n" for line in lines)
            handle.flush()

    def iter_records(self) -> Generator[dict[str, Any], Any]:
        """Iterate over records in the JSONL file without loading all into memory.

        Yields:
            Records one at a time from the JSONL file.
        """
        handle: IO | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")
        with LockExclusive(handle):  # To prevent writes while reading
            handle.seek(0)
            size: int = Path(self.file).stat().st_size
            ln = 0
            while handle.tell() < size:
                line: bytes = handle.readline()
                if not line:
                    break
                yield deserialize_line(ln, line)
                ln += 1

    def to_lines(self) -> list[str]:
        """Convert all records to their JSON string representations.

        Returns:
            A list of JSON strings, one for each record in the file.
        """
        records: list[File_T] | None = self.read()
        if not records:
            return []
        return [json_dumps(record).decode("utf-8") for record in records]

    def write_raw_lines(self, lines: list[str]) -> None:
        """Write raw JSON strings directly to the file without serialization.

        Use this when you already have JSON-formatted strings and don't want
        them to be re-serialized (which would double-encode them).

        Args:
            lines: List of raw JSON strings, each representing one JSONL record.
        """
        handle: IO[Any] | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")
        with LockExclusive(handle):
            handle.seek(0)
            handle.truncate(0)
            handle.flush()
            for line in lines:
                handle.write(line.encode("utf-8") + b"\n")
            handle.flush()
