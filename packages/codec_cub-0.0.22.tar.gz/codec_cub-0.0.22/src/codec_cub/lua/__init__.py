"""Lua codec using tree-sitter for parsing Lua tables."""
