from typing import Final

AND: Final = "and"
BREAK: Final = "break"
DO: Final = "do"
ELSE: Final = "else"
ELSEIF: Final = "elseif"
END: Final = "end"
FOR: Final = "for"
FUNCTION: Final = "function"
GOTO: Final = "goto"
IF: Final = "if"
IN: Final = "in"
LOCAL: Final = "local"
NIL: Final = "nil"
NOT: Final = "not"
OR: Final = "or"
REPEAT: Final = "repeat"
RETURN: Final = "return"
THEN: Final = "then"
TRUE: Final = "true"
FALSE: Final = "false"
UNTIL: Final = "until"
WHILE: Final = "while"

LUA_KEYWORDS: Final = frozenset(
    {
        AND,
        BREAK,
        DO,
        ELSE,
        ELSEIF,
        END,
        FOR,
        FUNCTION,
        GOTO,
        IF,
        IN,
        LOCAL,
        NIL,
        NOT,
        OR,
        REPEAT,
        RETURN,
        THEN,
        TRUE,
        FALSE,
        UNTIL,
        WHILE,
    }
)


def is_keyword(s: str, keywords: frozenset[str] = LUA_KEYWORDS) -> bool:
    return s in keywords
