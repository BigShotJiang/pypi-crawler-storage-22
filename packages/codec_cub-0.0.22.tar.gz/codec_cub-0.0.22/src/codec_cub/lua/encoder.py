"""Fast Lua table encoder.

Designed for speed with simple isinstance chains.
Each encode_* function can be replaced with C++ bindings later.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Final

from ._keywords import FALSE, NIL, TRUE, is_keyword

if TYPE_CHECKING:
    from collections.abc import Mapping


RETURN: Final = "return "
HUGE: Final = "math.huge"
NEG_HUGE: Final = "-math.huge"
MATH_NAN: Final = "0/0"
UNDERSCORE: Final = "_"


def is_bare_key(s: str) -> bool:
    """Check if string can be used as a bare Lua table key."""
    if not s or is_keyword(s):
        return False
    first: str = s[0]
    if not (first.isalpha() or first == UNDERSCORE):
        return False
    return all(c.isalnum() or c == UNDERSCORE for c in s)


def encode_string(s: str) -> str:
    """Encode a string to Lua string literal.

    TODO: Replace with C++ binding.
    """
    return f'"{s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t")}"'


def encode_key(key: str) -> str:
    """Encode a dict key for Lua table.

    TODO: Replace with C++ binding.
    """
    if is_bare_key(key):
        return key
    return f"[{encode_string(key)}]"


def encode_value(obj: Any) -> str:
    """Encode any Python value to Lua.

    TODO: Replace with C++ binding that takes msgpack bytes.
    """

    def _encode_key(key: str) -> str:
        if is_bare_key(key):
            return key
        return f"[{encode_string(key)}]"

    if obj is None:
        return NIL

    if obj is True:
        return TRUE

    if obj is False:
        return FALSE

    if isinstance(obj, str):
        return f'"{obj.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t")}"'

    if isinstance(obj, int):
        return str(obj)

    if isinstance(obj, float):
        import math  # noqa: PLC0415

        if math.isnan(obj):
            return MATH_NAN
        if obj == float("inf"):
            return HUGE
        if obj == float("-inf"):
            return NEG_HUGE
        return str(obj)

    if isinstance(obj, (list, tuple)):
        if not obj:
            return "{}"

        parts: list[str] = [encode_value(item) for item in obj]
        return "{" + ", ".join(parts) + "}"

    if isinstance(obj, dict):
        if not obj:
            return "{}"

        parts: list[str] = []
        for k, value in obj.items():
            str_key: str = k if isinstance(k, str) else str(k)
            encoded_key: str = _encode_key(str_key)
            encoded_value: str = encode_value(value)
            parts.append(f"{encoded_key} = {encoded_value}")

        return "{" + ", ".join(parts) + "}"

    raise TypeError(f"Cannot encode {type(obj).__name__} to Lua")


def encode_array(obj: list | tuple) -> str:
    """Encode a list/tuple as Lua array table.

    TODO: Replace with C++ binding.
    """
    if not obj:
        return "{}"

    parts: list[str] = [encode_value(item) for item in obj]
    return "{" + ", ".join(parts) + "}"


def encode_table(obj: Mapping[str, Any]) -> str:
    """Encode a dict as Lua table.

    TODO: Replace with C++ binding.
    """
    if not obj:
        return "{}"

    parts: list[str] = []
    for k, value in obj.items():
        str_key: str = k if isinstance(k, str) else str(k)
        encoded_key: str = encode_key(str_key)
        encoded_value: str = encode_value(value)
        parts.append(f"{encoded_key} = {encoded_value}")

    return "{" + ", ".join(parts) + "}"


def encode(obj: Any) -> str:
    """Encode a Python object to Lua table syntax.

    Main entry point.

    TODO: Replace with C++ binding that:
    1. Takes obj, packs to msgpack bytes
    2. Transforms msgpack bytes to Lua string in C++
    3. Returns Lua string
    """
    return f"{RETURN}{encode_value(obj)}"


def encode_to_bytes(obj: Any) -> bytes:
    """Encode and return as UTF-8 bytes.

    TODO: C++ version would return bytes directly.
    """
    return encode(obj).encode("utf-8")


class LuaEncoder:
    """Encoder class for consistency with other codec patterns."""

    __slots__ = ()

    def encode(self, obj: Any) -> str:
        """Encode Python object to Lua string."""
        return encode(obj)

    def encode_bytes(self, obj: Any) -> bytes:
        """Encode Python object to Lua bytes."""
        return encode_to_bytes(obj)
