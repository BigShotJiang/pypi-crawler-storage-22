"""File handler for Lua table files."""

from __future__ import annotations

from typing import IO, TYPE_CHECKING, Any

from lazy_bear import lazy

from codec_cub.general.base_file_handler import BaseFileHandler
from codec_cub.lua.encoder import encode
from codec_cub.lua.tree_sitter_parser import TreeSitterLuaParser

if TYPE_CHECKING:
    from codec_cub.general.file_lock import LockExclusive, LockShared
    from funcy_bear.constants.type_constants import StrPath
else:
    LockExclusive, LockShared = lazy("codec_cub.general.file_lock").to("LockExclusive", "LockShared")


type AllObjs = str | int | float | bool | dict[str, Any] | list[Any]
type LuaData = AllObjs | None | list[AllObjs] | dict[str, AllObjs]


class LuaFileHandler(BaseFileHandler[LuaData]):
    """File handler for Lua table files with locking.

    Supports reading and writing Python objects to Lua table syntax.
    Uses shared locks for reads and exclusive locks for writes.
    """

    def __init__(
        self,
        file: StrPath,
        touch: bool = False,
    ) -> None:
        """Initialize LuaFileHandler.

        Args:
            file: Path to the Lua file
            touch: Whether to create the file if it doesn't exist
        """
        super().__init__(file, mode="r+", encoding="utf-8", touch=touch)
        self._parser = TreeSitterLuaParser()

    def read(self, **kwargs) -> LuaData | None:  # noqa: ARG002
        """Read and decode Lua file content.

        Returns:
            Decoded Python objects from the Lua file or None if empty
        """
        handle: IO | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")

        with LockShared(handle):
            handle.seek(0)
            content: str = handle.read()
            if not content.strip():
                return None
            return self._parser.parse_string(content)

    def write(self, data: LuaData, **kwargs) -> None:  # noqa: ARG002
        """Encode and write data to Lua file.

        Args:
            data: Python objects to encode and write
        """
        handle: IO | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")

        with LockExclusive(handle):
            handle.seek(0)
            handle.truncate(0)
            handle.write(encode(data))
            handle.flush()


__all__ = ["LuaData", "LuaFileHandler"]
