"""Tree-sitter based Lua table parser for high-performance parsing.

This parser handles Lua data files in the format:
    return { ... }

It converts Lua tables to Python dicts/lists, supporting:
- Tables as dicts: { key = value, ... }
- Tables as lists: { value1, value2, ... }
- Mixed tables: { "array_elem", key = "dict_elem" }
- Strings, numbers, booleans, nil
"""

from __future__ import annotations

from functools import cache
from typing import TYPE_CHECKING, Any, Final

from tree_sitter import Language, Node, Parser, Tree
import tree_sitter_lua as tslua

if TYPE_CHECKING:
    from collections.abc import Callable


LUA_LANGUAGE = Language(tslua.language())

MIN_CHILDREN_FOR_KEY_VALUE = 2

CHUNK_HASH: Final = hash("chunk")
RETURN_STATEMENT_HASH: Final = hash("return_statement")
EXPRESSION_LIST_HASH: Final = hash("expression_list")
TABLE_CONSTRUCTOR_HASH: Final = hash("table_constructor")
STRING_HASH: Final = hash("string")
NUMBER_HASH: Final = hash("number")
IDENTIFIER_HASH: Final = hash("identifier")
TRUE_HASH: Final = hash("true")
FALSE_HASH: Final = hash("false")
NIL_HASH: Final = hash("nil")


def _chunk_func(node: Node, text: bytes | None) -> Any:
    """Root node - find the return statement."""
    for child in node.named_children:
        if child.type == "return_statement":  # String compare inside handler
            return _convert_node(child)
    return None


def _return_func(node: Node, text: bytes | None) -> Any:
    """Handle return { ... } - get the expression list or table."""
    for child in node.named_children:
        child_type: str = child.type  # String compare inside handler
        if child_type == "expression_list":
            return _convert_node(child)
        if child_type == "table_constructor":
            return _convert_table(child)
    return None


def _expression_list_func(node: Node, text: bytes | None) -> Any:
    """Usually just one expression (the table)."""
    for child in node.named_children:
        return _convert_node(child)
    return None


def _number_func(node: Node, text: bytes | None) -> Any:
    if text:
        num_str: str = text.decode()
        if "." in num_str or "e" in num_str.lower():
            return float(num_str)
        return int(num_str)
    return 0


def default_func(node: Node, text: bytes | None) -> Any:
    return text.decode() if text else ""


HASH_TABLE: dict[str, Callable[[Node, bytes | None], Any]] = {
    "chunk": _chunk_func,
    "return_statement": _return_func,
    "expression_list": _expression_list_func,
    "number": _number_func,
    "table_constructor": lambda node, text: _convert_table(node),
    "string": lambda node, text: _convert_string(node),
    "string_content": lambda node, text: _convert_string(node),
    "true": lambda node, text: True,
    "false": lambda node, text: False,
    "nil": lambda node, text: None,
    "identifier": default_func,
}


STR_KEYS = HASH_TABLE.keys()


@cache
def get_cached(node_type: str) -> Callable[[Node, bytes | None], Any]:
    return HASH_TABLE.get(node_type, default_func)


for token in STR_KEYS:
    get_cached(token)  # Pre-cache functions


def _convert_node(node: Node) -> Any:
    text: bytes | None = node.text
    func: Callable[[Node, bytes | None], Any] = get_cached(node.type)
    return func(node, text)


def _convert_table(node: Node) -> dict[str, Any] | list[Any]:
    fields: list[Node] = [child for child in node.named_children if child.type == "field"]

    if not fields:
        return {}

    first_children = fields[0].named_children
    is_dict: bool = len(first_children) >= MIN_CHILDREN_FOR_KEY_VALUE and first_children[0].type == "identifier"

    if is_dict:
        return _convert_dict_table(fields)
    return _convert_array_table(fields)


def _convert_array_table(fields: list[Node]) -> list[Any]:
    result: list[Any] = []
    for field in fields:
        children: list[Node] = field.named_children
        if children:
            result.append(_convert_node(children[0]))
    return result


SMALL_TABLE = {
    "identifier": default_func,
    "string": lambda node, text: _convert_string(node),
}


def _convert_dict_table(fields: list[Node]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for field in fields:
        children: list[Node] = field.named_children
        if len(children) >= MIN_CHILDREN_FOR_KEY_VALUE:
            key_node: Node = children[0]
            value_node: Node = children[1]

            key_type: str = key_node.type
            text: bytes | None = key_node.text
            key = SMALL_TABLE.get(key_type, default_func)(key_node, text)

            result[key] = _convert_node(value_node)
    return result


def _convert_string(node: Node) -> str:
    for child in node.named_children:
        if child.type == "string_content":
            text = child.text
            return text.decode() if text else ""

    text: bytes | None = node.text
    if text:
        s: str = text.decode()
        if len(s) >= MIN_CHILDREN_FOR_KEY_VALUE and s[0] in ('"', "'") and s[-1] == s[0]:
            return s[1:-1]
        return s
    return ""


class TreeSitterLuaParser:
    """High-performance tree-sitter based Lua table parser."""

    __slots__ = ("_parser",)

    def __init__(self) -> None:
        """Initialize the tree-sitter Lua parser."""
        self._parser = Parser(LUA_LANGUAGE)

    def parse_string(self, text: str) -> Any:
        """Parse Lua table string into Python object."""
        tree: Tree = self._parser.parse(text.encode("utf-8"))

        if tree.root_node.has_error:
            raise ValueError("Lua parse error: invalid syntax")

        return _convert_node(tree.root_node)


__all__ = ["TreeSitterLuaParser"]

# ruff: noqa: ARG001
