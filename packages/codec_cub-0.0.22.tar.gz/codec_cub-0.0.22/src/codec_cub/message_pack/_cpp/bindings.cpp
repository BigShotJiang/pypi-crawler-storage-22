/*
 * Python C++ extension module for fast MessagePack packing and unpacking
 */

#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <filesystem>

#include "constants.hpp"
#include "unpacker.hpp"
#include "packer.hpp"

namespace fs = std::filesystem;

// ========== UNPACKING ==========

static PyObject* msgpack_unpack(PyObject* self, PyObject* args) {
    Py_buffer buffer;

    if (!PyArg_ParseTuple(args, "y*", &buffer)) {
        return nullptr;
    }

    PyObject* result = nullptr;

    try {
        msgpack::Unpacker unpacker(
            static_cast<const uint8_t*>(buffer.buf),
            buffer.len
        );
        result = unpacker.unpack();
    } catch (const std::exception& e) {
        PyBuffer_Release(&buffer);
        PyErr_SetString(PyExc_RuntimeError, e.what());
        return nullptr;
    }

    PyBuffer_Release(&buffer);
    return result;
}

static PyObject* msgpack_unpack_file(PyObject* self, PyObject* args) {
    const char* filepath;

    if (!PyArg_ParseTuple(args, "s", &filepath)) {
        return nullptr;
    }

    FILE* file = fopen(filepath, "rb");
    if (!file) {
        PyErr_SetFromErrnoWithFilename(PyExc_OSError, filepath);
        return nullptr;
    }

    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);

    std::vector<uint8_t> buffer(file_size);
    size_t bytes_read = fread(buffer.data(), 1, file_size, file);
    fclose(file);

    if (bytes_read != static_cast<size_t>(file_size)) {
        PyErr_SetString(PyExc_IOError, "Failed to read complete file");
        return nullptr;
    }

    PyObject* result = nullptr;
    try {
        msgpack::Unpacker unpacker(buffer.data(), buffer.size());
        result = unpacker.unpack();
    } catch (const std::exception& e) {
        PyErr_SetString(PyExc_RuntimeError, e.what());
        return nullptr;
    }

    return result;
}

// ========== PACKING ==========

/**
 * @brief Pack a Python object into MessagePack bytes.
 * @param self Module reference (unused)
 * @param args Tuple containing the Python object to pack
 * Arg: PyObject* obj - The Python object to pack
 * @return PyObject* Bytes object containing MessagePack data, or nullptr on failure with an exception set
 */
static PyObject* msgpack_pack(PyObject* self, PyObject* args) {
    PyObject* obj;

    if (!PyArg_ParseTuple(args, "O", &obj)) {
        return nullptr;
    }

    try {
        msgpack::Packer packer;
        packer.pack(obj);
        return packer.get_bytes();
    } catch (const std::exception& e) {
        PyErr_SetString(PyExc_RuntimeError, e.what());
        return nullptr;
    }
}

/**
 * @brief Pack a Python object and write the MessagePack bytes to a file.
 * @param self Module reference (unused)
 * @param args Tuple containing the Python object and the file path as a string
 * Arg: PyObject* obj - The Python object to pack
 * Arg: const char* filepath - The path to the output file
 * Arg: int - touch before writing
 * @return PyObject* Py_None on success, or nullptr on failure with an exception set
 */
static PyObject* msgpack_pack_file(PyObject* self, PyObject* args) {
    PyObject* obj;
    const char* filepath;
    int touch = 0;
    fs::path file_path;

    if (!PyArg_ParseTuple(args, "Os|i", &obj, &filepath, &touch)) {
        return nullptr;
    }

    try {
        if (touch) {
            file_path = fs::path(filepath);
            fs::create_directories(file_path.parent_path());

            FILE* touch_file = fopen(filepath, "ab");
            if (!touch_file) {
                PyErr_SetFromErrnoWithFilename(PyExc_OSError, filepath);
                return nullptr;
            }
            fclose(touch_file);
        }

        msgpack::Packer packer;
        packer.pack(obj);

        PyObject* bytes_obj = packer.get_bytes();
        if (!bytes_obj) {
            return nullptr;
        }

        char* data;
        Py_ssize_t size;
        if (PyBytes_AsStringAndSize(bytes_obj, &data, &size) < 0) {
            Py_DECREF(bytes_obj);
            return nullptr;
        }

        FILE* file = fopen(filepath, "wb");
        if (!file) {
            Py_DECREF(bytes_obj);
            PyErr_SetFromErrnoWithFilename(PyExc_OSError, filepath);
            return nullptr;
        }

        size_t bytes_written = fwrite(data, 1, size, file);
        fclose(file);
        Py_DECREF(bytes_obj);

        if (bytes_written != static_cast<size_t>(size)) {
            PyErr_SetString(PyExc_IOError, "Failed to write complete file");
            return nullptr;
        }

        Py_RETURN_NONE;
    } catch (const std::exception& e) {
        PyErr_SetString(PyExc_RuntimeError, e.what());
        return nullptr;
    }
}

// ========== MODULE DEFINITION ==========

static PyMethodDef MsgpackMethods[] = {
    {
        "unpack",
        msgpack_unpack,
        METH_VARARGS,
        "Unpack MessagePack data from bytes."
    },
    {
        "unpack_file",
        msgpack_unpack_file,
        METH_VARARGS,
        "Unpack MessagePack data from a file."
    },
    {
        "pack",
        msgpack_pack,
        METH_VARARGS,
        "Pack a Python object into MessagePack bytes."
    },
    {
        "pack_file",
        msgpack_pack_file,
        METH_VARARGS,
        "Pack a Python object and write to a file."
    },
    {nullptr, nullptr, 0, nullptr}
};

static struct PyModuleDef msgpack_module = {
    PyModuleDef_HEAD_INIT,
    "bindings",
    "Fast MessagePack packer and unpacker implemented in C++",
    -1,
    MsgpackMethods
};

PyMODINIT_FUNC PyInit_bindings(void) {
    return PyModule_Create(&msgpack_module);
}
