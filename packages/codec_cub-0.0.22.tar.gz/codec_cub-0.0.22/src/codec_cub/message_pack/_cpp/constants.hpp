#ifndef MSGPACK_CONSTANTS_HPP
#define MSGPACK_CONSTANTS_HPP

#include <cstdint>

namespace msgpack {
namespace tag {
    // Literals
    constexpr uint8_t NIL = 0xC0;
    constexpr uint8_t FALSE = 0xC2;
    constexpr uint8_t TRUE = 0xC3;

    // Unsigned integers
    constexpr uint8_t UINT8 = 0xCC;
    constexpr uint8_t UINT16 = 0xCD;
    constexpr uint8_t UINT32 = 0xCE;
    constexpr uint8_t UINT64 = 0xCF;

    // Signed integers
    constexpr uint8_t INT8 = 0xD0;
    constexpr uint8_t INT16 = 0xD1;
    constexpr uint8_t INT32 = 0xD2;
    constexpr uint8_t INT64 = 0xD3;

    // Float
    constexpr uint8_t FLOAT64 = 0xCB;

    // Strings
    constexpr uint8_t STR8 = 0xD9;
    constexpr uint8_t STR16 = 0xDA;
    constexpr uint8_t STR32 = 0xDB;

    // Binary
    constexpr uint8_t BIN8 = 0xC4;
    constexpr uint8_t BIN16 = 0xC5;
    constexpr uint8_t BIN32 = 0xC6;

    // Arrays
    constexpr uint8_t ARRAY16 = 0xDC;
    constexpr uint8_t ARRAY32 = 0xDD;

    // Maps
    constexpr uint8_t MAP16 = 0xDE;
    constexpr uint8_t MAP32 = 0xDF;

    // Fix family masks and bases
    constexpr uint8_t FIXMAP_MASK = 0xF0;
    constexpr uint8_t FIXMAP_BASE = 0x80;
    constexpr uint8_t FIXARRAY_MASK = 0xF0;
    constexpr uint8_t FIXARRAY_BASE = 0x90;
    constexpr uint8_t FIXSTR_MASK = 0xE0;
    constexpr uint8_t FIXSTR_BASE = 0xA0;
    constexpr uint8_t POS_FIXINT_MASK = 0x80;
    constexpr uint8_t NEG_FIXINT_MASK = 0xE0;
    constexpr uint8_t NEG_FIXINT_BASE = 0xE0;
}
} // namespace msgpack

#endif // MSGPACK_CONSTANTS_HPP