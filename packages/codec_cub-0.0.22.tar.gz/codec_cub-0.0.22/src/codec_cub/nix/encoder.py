"""Nix encoder implementation."""

from __future__ import annotations

from decimal import ROUND_HALF_EVEN, Decimal, DecimalTuple, InvalidOperation
from functools import lru_cache
import math
from typing import TYPE_CHECKING, Any, Final, cast

from codec_cub.common import Wrapper
from funcy_bear.constants import characters as ch
from funcy_bear.ops.math import neg
from funcy_bear.ops.math.infinity import is_infinite
from funcy_bear.type_stuffs.validate import is_mapping

if TYPE_CHECKING:
    from codec_cub.config import NixCodecConfig


ZERO_QUOTE: Final = "0"
NEGATIVE_ZERO_QUOTE: Final = f"{ch.DASH}{ZERO_QUOTE}"
UNDERSCORE: str = ch.UNDERSCORE
DASH: str = ch.DASH
N_LITERAL: Final = "n"
R_LITERAL: Final = "r"
T_LITERAL: Final = "t"
F_LITERAL: Final = "f"
ESCAPED_BACKSLASH: Final = f"{ch.BACKSLASH}{ch.BACKSLASH}"
"""Escaped backslash string."""
ESCAPED_DOUBLE_QUOTE: Final = f"{ch.BACKSLASH}{ch.DOUBLE_QUOTE}"
"""Escaped double quote string."""
ESCAPED_NEWLINE: Final = f"{ch.BACKSLASH}{N_LITERAL}"
"""Escaped newline string."""
ESCAPED_CARRIAGE: Final = f"{ch.BACKSLASH}{R_LITERAL}"
"""Escaped carriage return string."""
ESCAPED_TAB: Final = f"{ch.BACKSLASH}{T_LITERAL}"
"""Escaped tab string."""

ESCAPE_MEMBERS: set[str] = {ch.BACKSLASH, ch.DOUBLE_QUOTE, ch.NEWLINE, ch.CARRIAGE, ch.TAB}

TO_ESCAPE_MAP: dict[str, str] = {
    ch.BACKSLASH: ESCAPED_BACKSLASH,
    ch.DOUBLE_QUOTE: ESCAPED_DOUBLE_QUOTE,
    ch.NEWLINE: ESCAPED_NEWLINE,
    ch.CARRIAGE: ESCAPED_CARRIAGE,
    ch.TAB: ESCAPED_TAB,
}
"""Mapping of characters to their escape sequences."""


def return_escaped(c: str) -> str:
    """Return escaped character.

    Args:
        c: Character to escape
    Returns:
        Escaped character
    """
    if c not in ESCAPE_MEMBERS:
        return c
    return TO_ESCAPE_MAP[c]


@lru_cache(512)
def escape_string(s: str) -> str:
    """Escape a string.

    Args:
        s: String to escape
    Returns:
        Escaped string
    """
    return f"{ch.DOUBLE_QUOTE}{ch.EMPTY_STRING.join(return_escaped(c) for c in s)}{ch.DOUBLE_QUOTE}"


@lru_cache(512)
def is_nan(obj: Decimal) -> bool:
    """Check if Decimal is NaN."""
    return obj.is_nan()


@lru_cache(512)
def math_is_nan(obj: float) -> bool:
    """Check if float is NaN."""
    return math.isnan(obj)


@lru_cache(512)
def is_bare_identifier(s: str) -> bool:
    """Return True if s is a valid bare identifier in Nix.

    Args:
        s: The string to check.

    Returns:
        True if s is a valid bare identifier, False otherwise.
    """
    if not s:
        return False
    first: str = s[0]
    rest: str = s[1:]
    if not (first.isalpha() or first == ch.UNDERSCORE):
        return False
    return all(ch.isalnum() or ch in {UNDERSCORE, DASH} for ch in rest)


@lru_cache(512)
def to_decimal_no_exponent(obj: float, encoder: _NixEncoder) -> Decimal:
    """Convert float to Decimal without exponent, respecting max_scale."""
    max_scale: int = encoder._cfg.float_scale
    try:
        dec = Decimal(repr(obj))
    except InvalidOperation:
        return Decimal(0)

    if is_nan(dec):
        return Decimal(0)

    quant: Decimal = Decimal(1).scaleb(neg(max_scale))
    normalized: Decimal = dec.quantize(quant, rounding=ROUND_HALF_EVEN).normalize()
    if normalized == Decimal(NEGATIVE_ZERO_QUOTE):
        return Decimal(0)
    norm_tuple: DecimalTuple = normalized.as_tuple()
    if abs(cast("int", norm_tuple.exponent)) > max_scale:
        return normalized.quantize(quant, rounding=ROUND_HALF_EVEN)
    return normalized


class _NixEncoder:
    def __init__(self, cfg: NixCodecConfig) -> None:
        self._cfg: NixCodecConfig = cfg
        self._in_array: bool = False

    def encode(self, obj: Any) -> str:
        return self._emit_value(obj, 0)

    def _emit_value(self, obj: Any, depth: int) -> str:
        if obj is None or is_infinite(obj):
            return ch.NULL_LITERAL
        if isinstance(obj, bool):
            return ch.TRUE_LITERAL if obj else ch.FALSE_LITERAL
        if isinstance(obj, int):
            return str(obj)
        if isinstance(obj, float):
            if math_is_nan(obj):
                return ch.NULL_LITERAL
            if obj == 0.0:
                return ZERO_QUOTE

            if obj.is_integer():
                return str(int(obj))

            dec: Decimal = to_decimal_no_exponent(obj, self)
            text: str = format(dec, F_LITERAL)
            if ch.DOT in text:
                text: str = text.rstrip(ZERO_QUOTE).rstrip(ch.DOT)
            return text or ZERO_QUOTE
        if isinstance(obj, str):
            return escape_string(obj)
        if isinstance(obj, list):
            next_depth: int = depth + 1
            list_wrap = Wrapper(ch.LEFT_BRACKET, ch.RIGHT_BRACKET, sep=ch.SPACE)
            if self._is_inline_list(obj) or self._cfg.inline_lists:
                if not obj:
                    return list_wrap.render()
                rendered: str = ch.SPACE.join(self._emit_value(x, next_depth) for x in obj)
                return list_wrap.append(rendered, ch.SPACE, ch.SPACE).render(sep=ch.EMPTY_STRING)

            was_in_array: bool = self._in_array
            self._in_array = True
            try:
                for x in obj:
                    list_wrap.append(self._emit_value(x, next_depth), self._indent(next_depth))
                output: str = list_wrap.render(pre=self._indent(depth), sep=self._cfg.newline)
                return output
            finally:
                self._in_array = was_in_array
        if is_mapping(obj):
            keys: list[str] = list(obj.keys())
            if self._cfg.sort_keys:
                keys.sort()
            next_depth: int = depth + 1
            dict_wrap = Wrapper(ch.LEFT_BRACE, ch.RIGHT_BRACE, ch.SPACE)
            end: str = ch.SEMICOLON if self._cfg.trailing_semicolon else ch.EMPTY_STRING

            if not keys:
                return dict_wrap.render()

            if self._cfg.inline_arrays and self._in_array:
                pairs: list[str] = []
                for k in keys:
                    key_text: str = self._emit_key(k)
                    value_text: str = self._emit_value(obj[k], next_depth)
                    pairs.append(f"{key_text} {ch.EQUALS} {value_text}{end}")
                rendered: str = ch.SPACE.join(pairs)
                return dict_wrap.append(rendered, ch.SPACE, ch.SPACE).render(sep=ch.EMPTY_STRING)

            for k in keys:
                key_text: str = self._emit_key(k)
                value_text: str = self._emit_value(obj[k], next_depth)
                dict_wrap.append(f"{key_text} {ch.EQUALS} {value_text}{end}", pre=self._indent(next_depth))
            return dict_wrap.render(pre=self._indent(depth), sep=self._cfg.newline)
        raise TypeError(f"Unsupported type {type(obj).__name__} to Nix")

    def _emit_key(self, key: str) -> str:
        if is_bare_identifier(key):
            return key
        return escape_string(key)

    def _indent(self, depth: int) -> str:
        return ch.SPACE * (self._cfg.indent_spaces * depth)

    def _is_inline_list(self, x: Any) -> bool:
        def _is_atomic(x: Any) -> bool:
            return x is None or isinstance(x, (bool, int, float, str))

        if not isinstance(x, list):
            return False
        return len(x) <= self._cfg.max_inline_list and all(_is_atomic(item) for item in x)
