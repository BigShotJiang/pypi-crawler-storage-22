"""Tree-sitter based Nix parser implementation for high-performance parsing."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Final

from tree_sitter import Language, Node, Parser, Tree
import tree_sitter_nix as tsnix

if TYPE_CHECKING:
    from collections.abc import Callable

    from codec_cub.config import NixCodecConfig

NIX_LANGUAGE = Language(tsnix.language())

EMPTY_STRING: Final = ""

# Node Types
SOURCE_CODE: Final = "source_code"
ATTRSET: Final = "attrset_expression"
LIST: Final = "list_expression"
INTEGER: Final = "integer_expression"
FLOAT: Final = "float_expression"
STRING: Final = "string_expression"
VARIABLE: Final = "variable_expression"
UNARY: Final = "unary_expression"
COMMENT: Final = "comment"
STRING_FRAGMENT: Final = "string_fragment"
ESCAPE_SEQUENCE: Final = "escape_sequence"
IDENTIFIER: Final = "identifier"
BINDING_SET: Final = "binding_set"
BINDING: Final = "binding"
ATTRPATH: Final = "attrpath"


# Variable Values
TRUE_VALUE: Final = "true"
FALSE_VALUE: Final = "false"
NULL_VALUE: Final = "null"

_ESCAPE_MAP: dict[str, str] = {
    "\\n": "\n",
    "\\t": "\t",
    "\\r": "\r",
    "\\\\": "\\",
    '\\"': '"',
    r"\$": "$",
}

_STR_TO_NODE_ID: Final = {
    SOURCE_CODE: 1,
    ATTRSET: 2,
    LIST: 3,
    INTEGER: 4,
    FLOAT: 5,
    STRING: 6,
    VARIABLE: 7,
    UNARY: 8,
}


def list_func(node: Node) -> Any:
    return [_convert_node(child) for child in node.named_children]


def integer_func(node: Node) -> Any:
    return int(node.text.decode()) if node.text else 0


def float_func(node: Node) -> Any:
    return float(node.text.decode()) if node.text else 0.0


def variable_func(node: Node) -> Any:
    ident: str = node.text.decode() if node.text else ""
    return True if ident == TRUE_VALUE else False if ident == FALSE_VALUE else None if ident == NULL_VALUE else ident


def unary_func(node: Node) -> float:
    for child in node.named_children:
        child_text: bytes | None = child.text
        if child_text is not None:
            if child.type == INTEGER:
                return -int(child_text.decode())
            if child.type == FLOAT:
                return -float(child_text.decode())
    return 0


def _convert_attrset(node: Node) -> dict[str, Any]:
    """Convert an attrset_expression node to a Python dict."""
    result: dict[str, Any] = {}
    for child in node.named_children:
        if child.type == BINDING_SET:
            for binding in child.named_children:
                if binding.type == BINDING:
                    key, value = _convert_binding(binding)
                    result[key] = value
    return result


def _convert_binding(node: Node) -> tuple[str, Any]:
    """Convert a binding node to a (key, value) tuple."""
    key: str = ""
    value: Any = None

    for child in node.named_children:
        if child.type == ATTRPATH:
            for subchild in child.named_children:
                if subchild.type == IDENTIFIER:
                    key = (subchild.text or b"").decode()
                    break
                if subchild.type == STRING:
                    key = _convert_string(subchild)
                    break
        else:
            value = _convert_node(child)
    return key, value


def _convert_string(node: Node) -> str:
    """Convert a string_expression node to a Python string."""
    children: list[Node] = node.named_children
    if not children:
        return EMPTY_STRING
    if len(children) == 1:
        child: Node = children[0]
        if child.type == STRING_FRAGMENT:
            return child.text.decode() if child.text else EMPTY_STRING
    parts: list[str] = [EMPTY_STRING] * len(children)
    for i, child in enumerate(children):
        text: str = child.text.decode() if child.text else EMPTY_STRING
        if child.type == STRING_FRAGMENT:
            parts[i] = text
        if child.type == ESCAPE_SEQUENCE:
            parts[i] = _ESCAPE_MAP.get(text, text[1:] if len(text) > 1 else text)
    return EMPTY_STRING.join(parts)


# fmt: off
FUNC_TABLE: list[Callable[[Node], Any] | None] = [
      None,                # 0 - NIX_NODE_UNKNOWN  # Fast way to reject unknown nodes
      None,                # 1 - NIX_NODE_SOURCE_CODE
      _convert_attrset,    # 2 - NIX_NODE_ATTRSET
      list_func,           # 3 - NIX_NODE_LIST
      integer_func,        # 4 - NIX_NODE_INTEGER
      float_func,          # 5 - NIX_NODE_FLOAT
      _convert_string,     # 6 - NIX_NODE_STRING
      variable_func,       # 7 - NIX_NODE_VARIABLE
      unary_func,          # 8 - NIX_NODE_UNARY
      None,                # 9 - COMMENT # The types below this are not handled at the top level
      None,                # 10 - STRING_FRAGMENT
      None,                # 11 - ESCAPE_SEQUENCE
      None,                # 12 - IDENTIFIER
      None,                # 13 - BINDING_SET
      None,                # 14 - BINDING
      None,                # 15 - ATTRPATH
  ]
# fmt: on


def _convert_node(node: Node) -> Any:
    """Convert a tree-sitter node to a Python value."""
    node_type: str = node.type
    if (func := FUNC_TABLE[_STR_TO_NODE_ID.get(node_type, 0)]) is not None:
        return func(node)
    raise ValueError(f"Unsupported Nix node type: {node_type}")


class _TreeSitterNixParser:
    """High-performance tree-sitter based Nix parser.

    This parser uses the tree-sitter C library for parsing, which provides
    significant performance improvements over pure-Python parsing solutions.
    """

    __slots__ = ("_cfg", "_parser")

    def __init__(self, cfg: NixCodecConfig) -> None:
        """Initialize the tree-sitter Nix parser."""
        self._cfg: NixCodecConfig = cfg
        self._parser = Parser(NIX_LANGUAGE)

    def parse_string(self, text: str) -> Any:
        """Parse Nix syntax string into Python object.

        Raises:
            ValueError: If the input contains syntax errors or unsupported constructs.
        """
        tree: Tree = self._parser.parse(text.encode("utf-8"))
        if tree.root_node.has_error:
            raise ValueError("Syntax error in Nix input.")

        for child in tree.root_node.named_children:
            if child.type == COMMENT:
                continue
            return _convert_node(child)
        return None


__all__ = ["_TreeSitterNixParser"]
