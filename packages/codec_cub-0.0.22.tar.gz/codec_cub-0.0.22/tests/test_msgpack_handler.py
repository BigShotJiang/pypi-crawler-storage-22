"""Tests for MsgPackHandler class."""

from typing import Any

from codec_cub.message_pack import pack, unpack


class TestMsgPackHandler:
    """Test suite for MsgPackHandler."""

    def test_pack_unpack_dict(self) -> None:
        """Test packing and unpacking a dictionary."""
        data: dict[str, Any] = {"name": "Bear", "age": 42, "active": True}
        packed: bytes = pack(data)
        unpacked: Any = unpack(packed)
        assert unpacked == data

    def test_pack_unpack_list(self) -> None:
        """Test packing and unpacking a list."""
        data: list[int] = [1, 2, 3, 4, 5]
        packed: bytes = pack(data)
        unpacked: list[int] = unpack(packed)
        assert unpacked == data

    def test_pack_unpack_nested(self) -> None:
        """Test packing and unpacking nested structures."""
        data: dict[str, Any] = {
            "users": [
                {"id": 1, "name": "Bear"},
                {"id": 2, "name": "Claire"},
            ],
            "count": 2,
        }
        packed: bytes = pack(data)
        unpacked: dict[str, Any] = unpack(packed)
        assert unpacked == data

    def test_multiple_cycles(self) -> None:
        """Test multiple pack/unpack cycles with same handler."""
        # Cycle 1
        data1: dict[str, Any] = {"name": "Bear", "count": 42}
        packed1: bytes = pack(data1)
        unpacked1: dict[str, Any] = unpack(packed1)
        assert unpacked1 == data1

        # Cycle 2
        data2: list[int] = [1, 2, 3, 4, 5]
        packed2: bytes = pack(data2)
        unpacked2: list[int] = unpack(packed2)
        assert unpacked2 == data2

        # Cycle 3
        data3: dict[str, dict[str, dict[str, int]]] = {"nested": {"deep": {"value": 123}}}
        packed3: bytes = pack(data3)
        unpacked3: Any = unpack(packed3)
        assert unpacked3 == data3

    def test_pack_primitives(self) -> None:
        """Test packing various primitive types."""
        test_cases: list[Any] = [
            None,
            True,
            False,
            0,
            42,
            -1,
            3.14,
            "hello",
            b"bytes",
        ]
        for value in test_cases:
            packed: bytes = pack(value)
            unpacked: list[Any] = unpack(packed)
            assert unpacked == value, f"Failed for {value!r}"

    def test_init_with_bytes_data(self) -> None:
        """Test initializing handler with bytes data."""
        data: dict[str, Any] = {"name": "Bear", "age": 42}
        packed: bytes = pack(data)

        # Use unpack_one to unpack pre-packed bytes
        unpacked: dict[str, Any] = unpack(packed)
        assert unpacked == data
