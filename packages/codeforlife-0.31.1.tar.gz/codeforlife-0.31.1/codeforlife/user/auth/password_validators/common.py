# pylint: skip-file
# TODO: https://docs.djangoproject.com/en/5.1/topics/auth/passwords/#writing-your-own-validator
class CommonPasswordValidator:
    pass
