TEACH_BANNER = {
    "title": "Educate",
    "subtitle": "Get ready to teach the next generation of computer scientists",
    "text": "",
    "image_class": "banner--picture--educate",
    "alt": "Female teacher helping young female student on a laptop",
}
