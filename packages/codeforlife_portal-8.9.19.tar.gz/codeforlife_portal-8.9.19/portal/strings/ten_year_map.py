TEN_YEAR_MAP_BANNER = {
    "title": "Celebrate",
    "subtitle": "Join us in celebrating our 10 year anniversary",
    "text": "",
    "image_class": "banner--picture--educate",
    "alt": "Female teacher helping young female student on a laptop",
}

TEN_YEAR_MAP_HEADLINE = {
    "title": "Code for Life is turning 10!",
    "description": "For our 10th anniversary, we're going global! Click on the pins on the map "
    "to check out what events are being run by our amazing volunteers from around the world.",
}
