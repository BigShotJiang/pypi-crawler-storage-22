"""Notification providers package."""

from codegeass.notifications.providers.base import NotificationProvider

__all__ = ["NotificationProvider"]
