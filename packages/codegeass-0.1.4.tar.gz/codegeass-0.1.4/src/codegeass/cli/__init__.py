"""CLI layer - Click-based command line interface."""

from codegeass.cli.main import cli

__all__ = ["cli"]
