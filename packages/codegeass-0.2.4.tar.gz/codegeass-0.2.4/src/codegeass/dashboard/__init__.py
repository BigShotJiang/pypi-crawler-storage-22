"""CodeGeass Dashboard - Web UI for managing tasks and viewing logs."""

from pathlib import Path

DASHBOARD_DIR = Path(__file__).parent
STATIC_DIR = DASHBOARD_DIR / "static"
