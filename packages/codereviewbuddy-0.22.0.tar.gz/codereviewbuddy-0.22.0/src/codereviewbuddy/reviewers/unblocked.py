"""Unblocked reviewer adapter."""

from __future__ import annotations

from typing import override

from codereviewbuddy.reviewers.base import ReviewerAdapter


class UnblockedAdapter(ReviewerAdapter):
    """Adapter for the Unblocked AI reviewer.

    - Does NOT auto-resolve comments.
    - Comments are posted by 'unblocked[bot]' or 'unblocked-bot'.
    """

    @property
    def name(self) -> str:
        return "unblocked"

    @property
    def auto_resolves_comments(self) -> bool:
        return False

    @override
    def identify(self, author: str) -> bool:
        normalized = author.lower().strip()
        return normalized in {"unblocked[bot]", "unblocked-bot", "unblocked"}
