# CodeShield LeanMCP Server

This is the LeanMCP deployment of CodeShield - AI-powered code verification, style correction, and context management exposed as MCP tools.

## 🚀 Quick Start

### Prerequisites

- Node.js >= 18
- npm >= 9
- LeanMCP CLI (`npm i -g @leanmcp/cli`)
- CodeShield Python backend running

### Installation

```bash
# Install dependencies
cd leanmcp
npm install

# Login to LeanMCP
leanmcp login
```

### Local Development

```bash
# Start the Python backend first (in project root)
cd ..
python -m codeshield.api_server

# Then start the MCP server
cd leanmcp
npm run dev
```

### Deploy to LeanMCP Platform

```bash
# Deploy to production
leanmcp deploy .

# Your MCP will be live at: https://codeshield.leanmcp.link
```

## 📦 Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `CODESHIELD_API_URL` | Yes | URL of the CodeShield Python backend |
| `CODESHIELD_API_KEY` | No | API key for backend authentication |
| `PORT` | No | Server port (default: 3001) |

Set these in LeanMCP Platform:
1. Go to [ship.leanmcp.com](https://ship.leanmcp.com)
2. Select your project
3. Go to Settings → Environment Variables

## 🛠️ Available MCP Tools

### Verification (TrustGate)
| Tool | Description |
|------|-------------|
| `verify_code` | Verify Python code for syntax errors and issues |
| `full_verify` | Complete verification with sandbox execution |
| `quick_check` | Fast syntax validation |

### Style (StyleForge)
| Tool | Description |
|------|-------------|
| `check_style` | Check code against style guidelines |
| `fix_style` | Auto-fix style issues with LLM |
| `format_black` | Format code with Black formatter |

### Context (ContextVault)
| Tool | Description |
|------|-------------|
| `capture_context` | Save coding context to vault |
| `restore_context` | Restore saved context |
| `list_contexts` | List all saved contexts |

### System
| Tool | Description |
|------|-------------|
| `get_health` | Get system health status |
| `get_metrics` | Get usage metrics |

## 🔌 Connect MCP Clients

### Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "codeshield": {
      "url": "https://codeshield.leanmcp.link/mcp"
    }
  }
}
```

### Cursor

Add to Cursor settings:

```json
{
  "mcp.servers": {
    "codeshield": {
      "url": "https://codeshield.leanmcp.link/mcp"
    }
  }
}
```

### Local Development

```json
{
  "mcpServers": {
    "codeshield": {
      "url": "http://localhost:3001/mcp"
    }
  }
}
```

## 📊 Monitoring

LeanMCP Platform provides built-in observability:

- **Tool Analytics** - Which tools are called, success rates
- **Latency Metrics** - p50, p95, p99 response times
- **Error Tracking** - Errors with full stack traces
- **Real-time Logs** - Stream production logs

Access at [ship.leanmcp.com](https://ship.leanmcp.com) → Your Project → Monitoring

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    MCP Clients                               │
│         (Claude Desktop, Cursor, Windsurf, etc.)            │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│              LeanMCP Platform (Edge)                         │
│    ┌─────────────────────────────────────────────────┐      │
│    │         CodeShield MCP Server (TypeScript)       │      │
│    │  • CodeVerificationService                       │      │
│    │  • StyleForgeService                             │      │
│    │  • ContextVaultService                           │      │
│    │  • HealthService                                 │      │
│    └──────────────────────────┬──────────────────────┘      │
└───────────────────────────────┼─────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────┐
│              CodeShield Python Backend                       │
│    ┌─────────────────────────────────────────────────┐      │
│    │  FastAPI Server (api_server.py)                  │      │
│    │  • TrustGate (verification + sandbox)            │      │
│    │  • StyleForge (style checking/fixing)            │      │
│    │  • ContextVault (context management)             │      │
│    │  • Daytona (secure sandbox execution)            │      │
│    └─────────────────────────────────────────────────┘      │
└─────────────────────────────────────────────────────────────┘
```

## 📚 Resources

- [LeanMCP Documentation](https://docs.leanmcp.com/)
- [CodeShield Documentation](../docs/)
- [MCP Protocol Specification](https://modelcontextprotocol.io/)

## 📄 License

MIT License - see [LICENSE](../LICENSE)
