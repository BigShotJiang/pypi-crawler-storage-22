/**
 * LeanMCP Configuration for CodeShield
 * 
 * This configures the LeanMCP deployment settings.
 * Docs: https://docs.leanmcp.com/
 */

export default {
  name: "codeshield",
  version: "1.0.0",
  
  // Server configuration
  server: {
    port: 3001,
    host: "0.0.0.0",
  },
  
  // Environment variables required for deployment
  env: {
    // CodeShield backend URL (your deployed FastAPI server)
    CODESHIELD_API_URL: {
      required: true,
      description: "URL of the CodeShield Python backend API",
      default: "http://localhost:8000"
    },
    // Optional: API key for backend authentication
    CODESHIELD_API_KEY: {
      required: false,
      description: "API key for CodeShield backend (if enabled)"
    }
  },
  
  // MCP service discovery
  mcp: {
    // Auto-discover services in mcp/ directory
    servicesDir: "./mcp",
    
    // Server metadata
    info: {
      name: "CodeShield",
      description: "AI-powered code verification, style correction, and context management",
      version: "1.0.0"
    }
  },
  
  // Deployment settings
  deploy: {
    // Region preference (LeanMCP will deploy to nearest edge)
    preferredRegions: ["us-east-1", "eu-west-1"],
    
    // Scaling configuration
    scaling: {
      minInstances: 1,
      maxInstances: 10,
      targetConcurrency: 50
    }
  }
};
