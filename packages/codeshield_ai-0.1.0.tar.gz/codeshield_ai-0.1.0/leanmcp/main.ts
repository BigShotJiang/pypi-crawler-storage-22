/**
 * CodeShield MCP Server - Main Entry Point
 * 
 * This is the LeanMCP server that wraps the CodeShield Python backend
 * and exposes it as a proper MCP server for Claude, Cursor, and other MCP clients.
 * 
 * Deploy with: leanmcp deploy .
 * Docs: https://docs.leanmcp.com/
 */

import { MCPServer, createHTTPServer } from "@leanmcp/core";

// Configuration
const PORT = parseInt(process.env.PORT || "3001", 10);
const CODESHIELD_API_URL = process.env.CODESHIELD_API_URL || "http://localhost:8000";

// Store the API URL globally so services can access it
(globalThis as any).CODESHIELD_API_URL = CODESHIELD_API_URL;

console.log(`
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   ██████╗ ██████╗ ██████╗ ███████╗███████╗██╗  ██╗██╗███████╗██╗     ██████╗  ║
║  ██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔════╝██║  ██║██║██╔════╝██║     ██╔══██╗ ║
║  ██║     ██║   ██║██║  ██║█████╗  ███████╗███████║██║█████╗  ██║     ██║  ██║ ║
║  ██║     ██║   ██║██║  ██║██╔══╝  ╚════██║██╔══██║██║██╔══╝  ██║     ██║  ██║ ║
║  ╚██████╗╚██████╔╝██████╔╝███████╗███████║██║  ██║██║███████╗███████╗██████╔╝ ║
║   ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚═════╝  ║
║                                                               ║
║   MCP Server powered by LeanMCP                               ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
`);

console.log(`🔧 Configuration:`);
console.log(`   Backend API: ${CODESHIELD_API_URL}`);
console.log(`   Port: ${PORT}`);
console.log("");

// Validate backend connection on startup
async function validateBackend(): Promise<boolean> {
  try {
    const response = await fetch(`${CODESHIELD_API_URL}/health`);
    if (response.ok) {
      console.log(`✅ Backend connection verified`);
      return true;
    }
    console.warn(`⚠️  Backend returned status ${response.status}`);
    return false;
  } catch (error) {
    console.warn(`⚠️  Backend not reachable: ${error}`);
    console.warn(`   Tools will attempt to connect on each request`);
    return false;
  }
}

// Create and start the MCP server
async function main() {
  // Validate backend
  await validateBackend();
  
  // Create MCP server - services are auto-discovered from mcp/ folder
  const server = new MCPServer({
    name: "CodeShield",
    version: "1.0.0"
  });
  
  // Start HTTP server with MCP endpoint
  await createHTTPServer(() => server.getServer(), { 
    port: PORT,
    cors: true 
  });
  
  console.log(`🚀 CodeShield MCP Server running!`);
  console.log(`   MCP Endpoint: http://localhost:${PORT}/mcp`);
  console.log(`   Health Check: http://localhost:${PORT}/health`);
  console.log("");
  console.log(`📚 Available Tools:`);
  console.log(`   • verify_code     - Verify Python code for errors`);
  console.log(`   • full_verify     - Complete verification with sandbox execution`);
  console.log(`   • check_style     - Check code against style guidelines`);
  console.log(`   • fix_style       - Auto-fix style issues`);
  console.log(`   • capture_context - Save coding context to vault`);
  console.log(`   • restore_context - Restore saved context`);
  console.log(`   • get_health      - Get system health status`);
  console.log(`   • get_metrics     - Get token usage metrics`);
  console.log("");
  console.log(`🔗 Connect with Claude Desktop, Cursor, or any MCP client`);
}

main().catch((error) => {
  console.error("Failed to start CodeShield MCP Server:", error);
  process.exit(1);
});
