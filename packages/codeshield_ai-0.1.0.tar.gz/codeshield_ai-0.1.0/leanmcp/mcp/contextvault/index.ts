/**
 * ContextVault Service - Context Management MCP Tools
 * 
 * Exposes CodeShield's context capture and restore capabilities.
 */

import { Tool, Resource, SchemaConstraint, Optional } from "@leanmcp/core";

// Get API URL from global config
const getApiUrl = () => (globalThis as any).CODESHIELD_API_URL || "http://localhost:8000";

// Input schemas
class CaptureContextInput {
  @SchemaConstraint({
    description: "Current code being worked on",
    minLength: 1
  })
  code!: string;

  @Optional()
  @SchemaConstraint({
    description: "Name/label for this context snapshot",
    maxLength: 100
  })
  name?: string;

  @Optional()
  @SchemaConstraint({
    description: "Additional metadata to store with context"
  })
  metadata?: Record<string, unknown>;

  @Optional()
  @SchemaConstraint({
    description: "List of relevant file paths"
  })
  files?: string[];
}

class RestoreContextInput {
  @SchemaConstraint({
    description: "Context ID to restore"
  })
  context_id!: string;
}

class ListContextsInput {
  @Optional()
  @SchemaConstraint({
    description: "Maximum number of contexts to return",
    minimum: 1,
    maximum: 100,
    default: 10
  })
  limit?: number;
}

// Response types
interface ContextSnapshot {
  id: string;
  name: string;
  timestamp: string;
  code_preview: string;
  metadata: Record<string, unknown>;
  token_count: number;
}

interface CaptureResult {
  success: boolean;
  context_id: string;
  message: string;
  token_count: number;
}

interface RestoreResult {
  success: boolean;
  context: ContextSnapshot;
  code: string;
  files: string[];
}

export class ContextVaultService {
  @Tool({
    description: "Capture current coding context (code, files, metadata) to the vault for later restoration. Useful for saving work state before major changes.",
    inputClass: CaptureContextInput
  })
  async capture_context(input: CaptureContextInput): Promise<CaptureResult> {
    const response = await fetch(`${getApiUrl()}/context/capture`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: input.code,
        name: input.name,
        metadata: input.metadata,
        files: input.files
      })
    });

    if (!response.ok) {
      throw new Error(`Context capture failed: ${response.statusText}`);
    }

    return await response.json() as CaptureResult;
  }

  @Tool({
    description: "Restore a previously captured context from the vault. Returns the saved code and associated files.",
    inputClass: RestoreContextInput
  })
  async restore_context(input: RestoreContextInput): Promise<RestoreResult> {
    const response = await fetch(`${getApiUrl()}/context/restore/${input.context_id}`, {
      method: "GET",
      headers: { "Content-Type": "application/json" }
    });

    if (!response.ok) {
      throw new Error(`Context restore failed: ${response.statusText}`);
    }

    return await response.json() as RestoreResult;
  }

  @Tool({
    description: "List all saved context snapshots in the vault.",
    inputClass: ListContextsInput
  })
  async list_contexts(input: ListContextsInput): Promise<{ contexts: ContextSnapshot[] }> {
    const limit = input.limit ?? 10;
    const response = await fetch(`${getApiUrl()}/context/list?limit=${limit}`, {
      method: "GET",
      headers: { "Content-Type": "application/json" }
    });

    if (!response.ok) {
      throw new Error(`Context list failed: ${response.statusText}`);
    }

    return await response.json() as { contexts: ContextSnapshot[] };
  }

  @Resource({
    description: "Available context snapshots in the vault",
    mimeType: "application/json"
  })
  async getContextList(): Promise<{ contents: Array<{ uri: string; mimeType: string; text: string }> }> {
    try {
      const response = await fetch(`${getApiUrl()}/context/list?limit=20`, {
        method: "GET",
        headers: { "Content-Type": "application/json" }
      });

      if (!response.ok) {
        return {
          contents: [{
            uri: "codeshield://contexts",
            mimeType: "application/json",
            text: JSON.stringify({ error: "Failed to fetch contexts" })
          }]
        };
      }

      const data = await response.json() as { contexts: ContextSnapshot[] };
      return {
        contents: [{
          uri: "codeshield://contexts",
          mimeType: "application/json",
          text: JSON.stringify(data.contexts, null, 2)
        }]
      };
    } catch {
      return {
        contents: [{
          uri: "codeshield://contexts",
          mimeType: "application/json",
          text: JSON.stringify({ error: "Backend not available" })
        }]
      };
    }
  }
}
