/**
 * Health & Metrics Service - System Status MCP Tools
 * 
 * Exposes health checks and metrics endpoints.
 */

import { Tool, Resource } from "@leanmcp/core";

// Get API URL from global config
const getApiUrl = () => (globalThis as any).CODESHIELD_API_URL || "http://localhost:8000";

// Track server start time
const startTime = Date.now();

// Response types
interface HealthStatus {
  status: "healthy" | "degraded" | "unhealthy";
  version: string;
  timestamp: string;
  components: {
    backend: { status: string; latency_ms?: number };
    sandbox: { status: string; available?: boolean };
    llm: { status: string; provider?: string };
  };
}

interface Metrics {
  total_verifications: number;
  successful_verifications: number;
  failed_verifications: number;
  total_style_checks: number;
  total_fixes: number;
  average_response_time_ms: number;
  tokens_processed: number;
  tokens_saved: number;
  uptime_seconds: number;
}

interface BackendHealth {
  ok: boolean;
  latency: number;
  sandbox: boolean;
  llm: boolean;
  llmProvider?: string;
}

async function checkBackend(): Promise<BackendHealth> {
  const start = Date.now();
  try {
    const response = await fetch(`${getApiUrl()}/health`, {
      method: "GET",
      headers: { "Content-Type": "application/json" }
    });
    const latency = Date.now() - start;

    if (!response.ok) {
      return { ok: false, latency, sandbox: false, llm: false };
    }

    const data = await response.json() as { 
      sandbox_available?: boolean; 
      llm_configured?: boolean; 
      llm_provider?: string 
    };
    return {
      ok: true,
      latency,
      sandbox: data.sandbox_available ?? false,
      llm: data.llm_configured ?? false,
      llmProvider: data.llm_provider
    };
  } catch {
    return { ok: false, latency: Date.now() - start, sandbox: false, llm: false };
  }
}

export class HealthService {
  @Tool({
    description: "Get CodeShield system health status including backend, sandbox, and LLM provider status."
  })
  async get_health(): Promise<HealthStatus> {
    const backendStatus = await checkBackend();
    
    return {
      status: backendStatus.ok ? "healthy" : "degraded",
      version: "1.0.0",
      timestamp: new Date().toISOString(),
      components: {
        backend: {
          status: backendStatus.ok ? "healthy" : "unreachable",
          latency_ms: backendStatus.latency
        },
        sandbox: {
          status: backendStatus.sandbox ? "available" : "unavailable",
          available: backendStatus.sandbox
        },
        llm: {
          status: backendStatus.llm ? "configured" : "not configured",
          provider: backendStatus.llmProvider
        }
      }
    };
  }

  @Tool({
    description: "Get usage metrics including verification counts, token usage, and response times."
  })
  async get_metrics(): Promise<Metrics> {
    try {
      const response = await fetch(`${getApiUrl()}/metrics`, {
        method: "GET",
        headers: { "Content-Type": "application/json" }
      });

      if (!response.ok) {
        throw new Error("Failed to fetch metrics");
      }

      const data = await response.json() as Omit<Metrics, 'uptime_seconds'>;
      return {
        ...data,
        uptime_seconds: Math.floor((Date.now() - startTime) / 1000)
      };
    } catch {
      // Return local metrics if backend unavailable
      return {
        total_verifications: 0,
        successful_verifications: 0,
        failed_verifications: 0,
        total_style_checks: 0,
        total_fixes: 0,
        average_response_time_ms: 0,
        tokens_processed: 0,
        tokens_saved: 0,
        uptime_seconds: Math.floor((Date.now() - startTime) / 1000)
      };
    }
  }

  @Resource({
    description: "Current system health status",
    mimeType: "application/json"
  })
  async getHealthResource(): Promise<{ contents: Array<{ uri: string; mimeType: string; text: string }> }> {
    const health = await this.get_health();
    return {
      contents: [{
        uri: "codeshield://health",
        mimeType: "application/json",
        text: JSON.stringify(health, null, 2)
      }]
    };
  }

  @Resource({
    description: "Available CodeShield MCP tools",
    mimeType: "application/json"
  })
  getToolsList(): { contents: Array<{ uri: string; mimeType: string; text: string }> } {
    const tools = {
      verification: [
        { name: "verify_code", description: "Verify Python code for syntax errors and issues" },
        { name: "full_verify", description: "Complete verification with sandbox execution" },
        { name: "quick_check", description: "Fast syntax validation" }
      ],
      styleforge: [
        { name: "check_style", description: "Check code against style guidelines" },
        { name: "fix_style", description: "Auto-fix style issues with LLM" },
        { name: "format_black", description: "Format code with Black" }
      ],
      contextvault: [
        { name: "capture_context", description: "Save coding context to vault" },
        { name: "restore_context", description: "Restore saved context" },
        { name: "list_contexts", description: "List all saved contexts" }
      ],
      system: [
        { name: "get_health", description: "Get system health status" },
        { name: "get_metrics", description: "Get usage metrics" }
      ]
    };

    return {
      contents: [{
        uri: "codeshield://tools",
        mimeType: "application/json",
        text: JSON.stringify(tools, null, 2)
      }]
    };
  }
}
