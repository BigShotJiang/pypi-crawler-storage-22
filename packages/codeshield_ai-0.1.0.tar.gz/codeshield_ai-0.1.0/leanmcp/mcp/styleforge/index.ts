/**
 * StyleForge Service - Code Style MCP Tools
 * 
 * Exposes CodeShield's style checking and correction capabilities.
 */

import { Tool, SchemaConstraint, Optional } from "@leanmcp/core";

// Get API URL from global config
const getApiUrl = () => (globalThis as any).CODESHIELD_API_URL || "http://localhost:8000";

// Input schemas
class CheckStyleInput {
  @SchemaConstraint({
    description: "Python code to check for style issues",
    minLength: 1
  })
  code!: string;

  @Optional()
  @SchemaConstraint({
    description: "Style guide to check against (pep8, google, black)",
    enum: ["pep8", "google", "black"],
    default: "pep8"
  })
  style_guide?: "pep8" | "google" | "black";
}

class FixStyleInput {
  @SchemaConstraint({
    description: "Python code to auto-fix style issues",
    minLength: 1
  })
  code!: string;

  @Optional()
  @SchemaConstraint({
    description: "Style guide to apply (pep8, google, black)",
    enum: ["pep8", "google", "black"],
    default: "pep8"
  })
  style_guide?: "pep8" | "google" | "black";

  @Optional()
  @SchemaConstraint({
    description: "Whether to use LLM for intelligent fixes",
    default: true
  })
  use_llm?: boolean;
}

// Response types
interface StyleIssue {
  line: number;
  column: number;
  code: string;
  message: string;
  severity: "error" | "warning" | "convention";
}

interface StyleCheckResult {
  issues: StyleIssue[];
  score: number;
  summary: string;
}

interface StyleFixResult {
  original_code: string;
  fixed_code: string;
  changes_made: string[];
  issues_fixed: number;
}

export class StyleForgeService {
  @Tool({
    description: "Check Python code against style guidelines (PEP8, Google, Black). Returns list of style issues with line numbers and suggestions.",
    inputClass: CheckStyleInput
  })
  async check_style(input: CheckStyleInput): Promise<StyleCheckResult> {
    const response = await fetch(`${getApiUrl()}/style/check`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: input.code,
        style_guide: input.style_guide ?? "pep8"
      })
    });

    if (!response.ok) {
      throw new Error(`Style check failed: ${response.statusText}`);
    }

    return await response.json() as StyleCheckResult;
  }

  @Tool({
    description: "Automatically fix style issues in Python code. Uses LLM for intelligent fixes that preserve code semantics.",
    inputClass: FixStyleInput
  })
  async fix_style(input: FixStyleInput): Promise<StyleFixResult> {
    const response = await fetch(`${getApiUrl()}/style/fix`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: input.code,
        style_guide: input.style_guide ?? "pep8",
        use_llm: input.use_llm ?? true
      })
    });

    if (!response.ok) {
      throw new Error(`Style fix failed: ${response.statusText}`);
    }

    return await response.json() as StyleFixResult;
  }

  @Tool({
    description: "Format code using Black formatter for consistent styling.",
    inputClass: CheckStyleInput
  })
  async format_black(input: CheckStyleInput): Promise<{ formatted_code: string }> {
    const response = await fetch(`${getApiUrl()}/style/format`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: input.code,
        formatter: "black"
      })
    });

    if (!response.ok) {
      throw new Error(`Formatting failed: ${response.statusText}`);
    }

    return await response.json() as { formatted_code: string };
  }
}
