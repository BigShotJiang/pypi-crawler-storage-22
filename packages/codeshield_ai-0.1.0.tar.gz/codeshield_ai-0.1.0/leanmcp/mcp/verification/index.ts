/**
 * Code Verification Service - TrustGate MCP Tools
 * 
 * Exposes CodeShield's verification capabilities as MCP tools.
 */

import { Tool, SchemaConstraint, Optional } from "@leanmcp/core";

// Get API URL from global config
const getApiUrl = () => (globalThis as any).CODESHIELD_API_URL || "http://localhost:8000";

// Input schemas
class VerifyCodeInput {
  @SchemaConstraint({
    description: "Python code to verify for syntax errors, missing imports, and issues",
    minLength: 1
  })
  code!: string;

  @Optional()
  @SchemaConstraint({
    description: "Whether to automatically fix issues found",
    default: true
  })
  auto_fix?: boolean;
}

class FullVerifyInput {
  @SchemaConstraint({
    description: "Python code to verify with full sandbox execution",
    minLength: 1
  })
  code!: string;
}

// Response types
interface VerificationResult {
  success: boolean;
  syntax_valid: boolean;
  issues: Array<{
    type: string;
    message: string;
    line?: number;
    severity: "error" | "warning" | "info";
  }>;
  fixed_code?: string;
  confidence_score: number;
  execution_result?: {
    success: boolean;
    output?: string;
    error?: string;
  };
}

export class CodeVerificationService {
  @Tool({
    description: "Verify Python code for syntax errors, missing imports, and other issues. Returns a verification report with confidence score and optional auto-fixes.",
    inputClass: VerifyCodeInput
  })
  async verify_code(input: VerifyCodeInput): Promise<VerificationResult> {
    const response = await fetch(`${getApiUrl()}/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: input.code,
        auto_fix: input.auto_fix ?? true
      })
    });

    if (!response.ok) {
      throw new Error(`Verification failed: ${response.statusText}`);
    }

    return await response.json() as VerificationResult;
  }

  @Tool({
    description: "Complete verification: syntax + imports + sandbox execution. Runs code in secure sandbox (Daytona) to confirm it actually works.",
    inputClass: FullVerifyInput
  })
  async full_verify(input: FullVerifyInput): Promise<VerificationResult> {
    const response = await fetch(`${getApiUrl()}/full-verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: input.code
      })
    });

    if (!response.ok) {
      throw new Error(`Full verification failed: ${response.statusText}`);
    }

    return await response.json() as VerificationResult;
  }

  @Tool({
    description: "Quick syntax check without running full verification. Fast validation for immediate feedback.",
    inputClass: VerifyCodeInput
  })
  async quick_check(input: VerifyCodeInput): Promise<{ valid: boolean; errors: string[] }> {
    const response = await fetch(`${getApiUrl()}/quick-check`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: input.code
      })
    });

    if (!response.ok) {
      throw new Error(`Quick check failed: ${response.statusText}`);
    }

    return await response.json() as { valid: boolean; errors: string[] };
  }
}
