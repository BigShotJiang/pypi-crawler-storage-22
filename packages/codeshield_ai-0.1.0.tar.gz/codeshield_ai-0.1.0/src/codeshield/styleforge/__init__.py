"""StyleForge - Convention enforcement module"""
