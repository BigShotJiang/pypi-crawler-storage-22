"""CLI module for Codeshift."""

from codeshift.cli.main import cli

__all__ = ["cli"]
