# CodeTree MCP Server

MCP (Model Context Protocol) server for CodeTree. Query code repositories using natural language from Claude Desktop, Cline, Continue, and other MCP-compatible clients.

## Installation

```bash
pip install codetree-mcp
```

## Setup for Claude Desktop

Add to your Claude Desktop config:

**macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "codetree": {
      "command": "codetree-mcp",
      "env": {
        "OPENAI_API_KEY": "sk-your-key-here"
      }
    }
  }
}
```

Restart Claude Desktop after configuration.

## Available Tools

| Tool | Description |
|------|-------------|
| `codetree_index` | Index a repository (required before other operations) |
| `codetree_query` | Ask natural language questions about code |
| `codetree_tree` | Show the hierarchical code structure |
| `codetree_find` | Find all references to a symbol |
| `codetree_stats` | Get repository statistics |

## Usage in Claude

Once configured, ask Claude:

- "Use codetree to index /path/to/my/project"
- "Query the codebase: how does authentication work?"
- "Show me the code structure"
- "Find all references to UserService"

## Requirements

- Python 3.10+
- OpenAI or Anthropic API key (for LLM queries)

## Links

- [CodeTree Main Package](https://pypi.org/project/codetree-rag/)
- [GitHub Repository](https://github.com/toller892/Oh-Code-Rag)
