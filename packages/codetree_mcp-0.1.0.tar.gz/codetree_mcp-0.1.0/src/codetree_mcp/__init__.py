"""CodeTree MCP Server - Query code repositories from Claude Desktop and other MCP clients."""

from .server import MCPServer, main

__version__ = "0.1.0"
__all__ = ["MCPServer", "main"]
