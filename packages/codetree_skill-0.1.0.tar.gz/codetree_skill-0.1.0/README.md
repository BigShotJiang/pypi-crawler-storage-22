# CodeTree Skill for Clawdbot

Clawdbot skill for querying code repositories using natural language. Built on vectorless RAG technology.

## Installation

```bash
pip install codetree-skill
```

## Usage

### CLI Commands

```bash
# Index a repository
codetree-skill index /path/to/repo

# Query the codebase
codetree-skill query /path/to/repo "How does authentication work?"

# Show code structure
codetree-skill tree /path/to/repo

# Find symbol references
codetree-skill find /path/to/repo "UserService"

# Get statistics
codetree-skill stats /path/to/repo
```

### As Clawdbot Skill

Copy the skill files to your Clawdbot skills directory:

```bash
# Find where the skill is installed
python -c "import codetree_skill; print(codetree_skill.__file__)"

# Copy to Clawdbot skills (adjust path as needed)
cp -r /path/to/codetree_skill ~/.clawdbot/skills/codetree/
```

## Features

- 🚫 **No Vector Database** - Uses LLM reasoning instead of embeddings
- 🌳 **AST Parsing** - Understands actual code structure
- 🔗 **Cross-File References** - Tracks imports and dependencies
- 💬 **Natural Language** - Ask questions in plain English

## Supported Languages

- Python
- JavaScript / TypeScript
- Go
- Rust
- Java

## Requirements

- Python 3.10+
- OpenAI or Anthropic API key

## Links

- [CodeTree Main Package](https://pypi.org/project/codetree-rag/)
- [CodeTree MCP Server](https://pypi.org/project/codetree-mcp/)
- [GitHub Repository](https://github.com/toller892/Oh-Code-Rag)
