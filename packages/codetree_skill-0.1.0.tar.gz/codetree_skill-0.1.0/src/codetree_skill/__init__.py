"""CodeTree Skill for Clawdbot - Query code repositories using natural language."""

__version__ = "0.1.0"
