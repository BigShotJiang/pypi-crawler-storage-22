#!/usr/bin/env python3
"""CLI wrapper for CodeTree skill."""

import sys
import click
from pathlib import Path


@click.group()
@click.version_option(version="0.1.0")
def main():
    """CodeTree Skill - Query code repositories using natural language."""
    pass


@main.command()
@click.argument("repo_path", type=click.Path(exists=True))
def index(repo_path: str):
    """Index a code repository."""
    from codetree import CodeTree
    
    tree = CodeTree(repo_path)
    index = tree.build_index()
    
    click.echo(f"✅ Indexed repository: {repo_path}")
    click.echo(f"   Files: {index.total_files}")
    click.echo(f"   Lines: {index.total_lines:,}")
    click.echo(f"   Languages: {', '.join(index.languages.keys())}")


@main.command()
@click.argument("repo_path", type=click.Path(exists=True))
@click.argument("question")
def query(repo_path: str, question: str):
    """Ask a question about a code repository."""
    from codetree import CodeTree
    
    tree = CodeTree(repo_path)
    if tree.index is None:
        click.echo("Building index first...")
        tree.build_index()
    
    answer = tree.query(question)
    click.echo(answer)


@main.command()
@click.argument("repo_path", type=click.Path(exists=True))
@click.option("--depth", "-d", default=3, help="Maximum tree depth")
def tree(repo_path: str, depth: int):
    """Show the code structure of a repository."""
    from codetree import CodeTree
    
    ct = CodeTree(repo_path)
    if ct.index is None:
        click.echo("Building index first...")
        ct.build_index()
    
    click.echo(f"🌲 Code Tree: {Path(repo_path).name}\n")
    click.echo(ct.tree(max_depth=depth))


@main.command()
@click.argument("repo_path", type=click.Path(exists=True))
@click.argument("symbol")
def find(repo_path: str, symbol: str):
    """Find all references to a symbol."""
    from codetree import CodeTree
    
    ct = CodeTree(repo_path)
    if ct.index is None:
        click.echo("Building index first...")
        ct.build_index()
    
    refs = ct.find(symbol)
    
    if refs:
        click.echo(f"📍 Found {len(refs)} references to '{symbol}':\n")
        for ref in refs:
            if ref["type"] == "import":
                click.echo(f"  [import]   {ref['file']}: {ref['statement']}")
            else:
                line = f":{ref['line']}" if ref.get('line') else ""
                click.echo(f"  [{ref['type']:8}] {ref['file']}{line} → {ref['name']}")
    else:
        click.echo(f"No references found for '{symbol}'")


@main.command()
@click.argument("repo_path", type=click.Path(exists=True))
def stats(repo_path: str):
    """Show repository statistics."""
    from codetree import CodeTree
    
    ct = CodeTree(repo_path)
    if ct.index is None:
        click.echo("Building index first...")
        ct.build_index()
    
    s = ct.stats()
    
    click.echo(f"📊 Repository Statistics\n")
    click.echo(f"Path: {s['repo_path']}")
    click.echo(f"Files: {s['total_files']}")
    click.echo(f"Lines: {s['total_lines']:,}")
    click.echo(f"\nLanguages:")
    for lang, count in s['languages'].items():
        click.echo(f"  - {lang}: {count} files")


if __name__ == "__main__":
    main()
