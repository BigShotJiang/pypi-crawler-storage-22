# Changelog

All notable changes to CodeVault will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2024-01-XX

### Added
- 🎉 **AI-Powered Merge Conflict Resolution**
  - Automatic conflict detection when pushing code
  - Three merge strategies: `ai` (intelligent), `local`, `remote`
  - `check-conflicts` command to preview conflicts
  - `auto-merge` command with AI-powered resolution using Llama 70B
  - Automatic backups before merging
  - Fallback to traditional conflict markers if AI fails

- **New Commands**
  - `codevault check-conflicts <files>` - Check for merge conflicts
  - `codevault auto-merge <files> --strategy [ai|local|remote]` - Resolve conflicts

- **Enhanced Push Command**
  - Now detects conflicts before committing
  - `--force` flag to bypass conflict detection
  - Better error messages for conflict scenarios

### Changed
- Improved conflict detection using difflib for precise region identification
- Enhanced metadata structure to support merge state tracking
- Better error handling and user feedback
- Updated documentation with merge conflict examples

### Technical
- Added `MergeConflict` class for conflict representation
- New `_detect_merge_conflicts()` method
- New `_ai_resolve_conflict()` method using Groq Llama 70B
- New `_create_conflict_markers()` for manual fallback
- Repository structure now includes `/merge` directory for backups

## [1.0.0] - 2024-01-XX

### Added
- Initial release
- Basic version control operations (push, pull, delete, log)
- AI-powered commit message generation using Groq
- Semantic commit analysis (type, risk, impact)
- Automatic version bumping based on semantic type
- AI code change insights
- Changelog generation
- Commit insights command
- User configuration management
- Repository status tracking

### Features
- **Push**: Store code snapshots with change detection
- **Pull**: Restore code from commits
- **Delete**: Remove commits from history
- **Log**: View commit history with metadata
- **Status**: Repository information
- **Changelog**: Auto-generated from commits
- **Insight**: Detailed commit analysis
- **Auth**: API key management

### Technical
- SHA-1 based commit IDs
- JSON-based metadata storage
- File snapshot system
- Home directory user config
- Groq API integration
- Support for Python 3.8+

[1.1.0]: https://github.com/yourusername/codevault/compare/v1.0.0...v1.1.0
[1.0.0]: https://github.com/yourusername/codevault/releases/tag/v1.0.0