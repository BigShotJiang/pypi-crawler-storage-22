"""
CodeVault - AI-Powered Version Control System

A lightweight version control system with:
- Automatic conflict detection
- AI-powered merge resolution
- Semantic versioning
- AI-generated commit messages
"""

__version__ = "1.1.0"
__author__ = "Your Name"

from .vault import CodeVault, MergeConflict

__all__ = ['CodeVault', 'MergeConflict']