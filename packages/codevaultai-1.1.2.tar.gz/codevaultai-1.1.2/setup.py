from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="codevaultAI",
    version="1.1.2",  # Bumped for merge conflict feature
    author="kevil rana ",
    author_email="Kevilrana28@gmail.com",
    description="GitHub-like version control system with AI-powered auto-updates and merge conflict resolution",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Version Control",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "groq>=0.4.0",
    ],
    entry_points={
        "console_scripts": [
            "codevault=codevault.cli:main",
        ],
    },
    include_package_data=True,
    keywords="version-control git vcs ai merge-conflicts llm groq",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/codevault/issues",
        "Source": "https://github.com/yourusername/codevault",
        "Documentation": "https://github.com/yourusername/codevault#readme",
    },
)