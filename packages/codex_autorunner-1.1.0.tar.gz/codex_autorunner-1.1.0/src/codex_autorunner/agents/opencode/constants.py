DEFAULT_TICKET_MODEL = "zai-coding-plan/glm-4.7"

__all__ = ["DEFAULT_TICKET_MODEL"]
