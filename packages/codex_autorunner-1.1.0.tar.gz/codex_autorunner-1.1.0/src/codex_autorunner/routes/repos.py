"""Backward-compatible repo routes."""

from ..surfaces.web.routes.repos import *  # noqa: F401,F403
