"""Backward-compatible review routes."""

from ..surfaces.web.routes.review import *  # noqa: F401,F403
