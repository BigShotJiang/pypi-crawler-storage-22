"""Backward-compatible usage routes."""

from ..surfaces.web.routes.usage import *  # noqa: F401,F403
