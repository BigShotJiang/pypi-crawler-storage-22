"""Backward-compatible voice routes."""

from ..surfaces.web.routes.voice import *  # noqa: F401,F403
