"""Backward-compatible workspace routes."""

from ..surfaces.web.routes.workspace import *  # noqa: F401,F403
