"""Backward-compatible review service wrapper.

Review implementation lives under flows.review.service.
"""

from ...flows.review.service import *  # noqa: F401,F403
