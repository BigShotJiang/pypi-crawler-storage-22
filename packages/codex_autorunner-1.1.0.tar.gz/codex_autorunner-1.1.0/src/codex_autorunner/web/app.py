"""Backward-compatible app exports."""

from ..surfaces.web.app import *  # noqa: F401,F403
