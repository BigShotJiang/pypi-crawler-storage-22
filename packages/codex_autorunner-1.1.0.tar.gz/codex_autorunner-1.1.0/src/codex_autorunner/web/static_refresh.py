"""Backward-compatible static refresh exports."""

from ..surfaces.web.static_refresh import *  # noqa: F401,F403
