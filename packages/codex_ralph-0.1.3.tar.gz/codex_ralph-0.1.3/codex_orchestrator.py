import argparse
import json
import os
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path


SUBPROCESS_PROMPT_TEMPLATE = textwrap.dedent(
    """\
    You are an autonomous coding agent running in iteration {iteration}.

    Global goal:
    {goal}

    Current workspace:
    {workspace}

    Previous iteration notes:
    {history}

    Instructions for this iteration:
    1) Check the current state quickly (files, git status, test state when needed).
    2) Make or update a short plan for the remaining work.
    3) Execute the next smallest meaningful chunk of work.
    4) Validate only what is relevant for the executed chunk.
    5) Decide if the global goal is fully complete.

    Hard rules:
    - Keep momentum; do not stop at analysis if code changes are needed.
    - Do not ask the user for input unless absolutely blocked.
    - Return valid JSON only, matching the provided schema.
    - Be explicit about what changed and what remains.
    """
)


OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "done": {"type": "boolean"},
        "summary": {"type": "string"},
        "actions_taken": {"type": "array", "items": {"type": "string"}},
        "remaining_work": {"type": "array", "items": {"type": "string"}},
        "next_focus": {"type": "string"},
    },
    "required": ["done", "summary", "actions_taken", "remaining_work", "next_focus"],
    "additionalProperties": False,
}


def default_codex_bin() -> str:
    return "codex.cmd" if os.name == "nt" else "codex"


def build_prompt(goal: str, workspace: str, history: list[str], iteration: int) -> str:
    history_text = "\n".join(f"- {item}" for item in history[-12:]) if history else "- (none)"
    return SUBPROCESS_PROMPT_TEMPLATE.format(
        iteration=iteration,
        goal=goal.strip(),
        workspace=workspace,
        history=history_text,
    )


def run_codex_once(
    codex_bin: str,
    prompt: str,
    workspace: Path,
    schema_path: Path,
    output_path: Path,
    extra_args: list[str],
) -> dict:
    cmd = [
        codex_bin,
        "exec",
        "--dangerously-bypass-approvals-and-sandbox",
        "--skip-git-repo-check",
        "--cd",
        str(workspace),
        "--color",
        "never",
        "--output-schema",
        str(schema_path),
        "--output-last-message",
        str(output_path),
        *extra_args,
        prompt,
    ]
    result = subprocess.run(cmd, text=True, capture_output=True)
    if result.returncode != 0:
        raise RuntimeError(
            "Codex execution failed.\n"
            f"Command: {' '.join(cmd)}\n"
            f"Exit code: {result.returncode}\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )
    raw = output_path.read_text(encoding="utf-8").strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Codex returned non-JSON output:\n{raw}") from exc


def print_panel(title: str, lines: list[str]) -> None:
    width = 88
    print("\n" + "=" * width)
    print(title)
    print("-" * width)
    for line in lines:
        print(line)
    print("=" * width)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Iterative Codex orchestrator using subprocess + codex exec."
    )
    parser.add_argument("--goal", help="Global goal to complete.")
    parser.add_argument(
        "--workspace",
        default=".",
        help="Workspace directory passed to codex --cd. Default: current directory.",
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=20,
        help="Maximum iterations before stopping. Default: 20.",
    )
    parser.add_argument(
        "--auto-continue",
        action="store_true",
        help="Continue iterations automatically without confirmation.",
    )
    parser.add_argument(
        "--codex-bin",
        default=default_codex_bin(),
        help="Codex binary name/path. On Windows default is codex.cmd.",
    )
    parser.add_argument(
        "--extra-arg",
        action="append",
        default=[],
        help="Extra argument passed to codex exec (repeatable). Example: --extra-arg --search",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    goal = args.goal or input("Enter your global goal: ").strip()
    if not goal:
        print("Goal is required.")
        return 1

    workspace = Path(args.workspace).resolve()
    if not workspace.exists():
        print(f"Workspace does not exist: {workspace}")
        return 1

    print_panel(
        "Codex Iterative Orchestrator",
        [
            f"Workspace: {workspace}",
            f"Max iterations: {args.max_iterations}",
            f"Auto-continue: {args.auto_continue}",
            f"Codex bin: {args.codex_bin}",
            "Danger flag: --dangerously-bypass-approvals-and-sandbox",
        ],
    )

    history: list[str] = []
    with tempfile.TemporaryDirectory(prefix="codex-orch-") as td:
        schema_path = Path(td) / "schema.json"
        output_path = Path(td) / "last_message.json"
        schema_path.write_text(json.dumps(OUTPUT_SCHEMA, ensure_ascii=True), encoding="utf-8")

        for iteration in range(1, args.max_iterations + 1):
            prompt = build_prompt(
                goal=goal,
                workspace=str(workspace),
                history=history,
                iteration=iteration,
            )
            print_panel(
                f"Iteration {iteration}",
                [
                    "Running codex exec...",
                    "This may take a while depending on task complexity.",
                ],
            )

            payload = run_codex_once(
                codex_bin=args.codex_bin,
                prompt=prompt,
                workspace=workspace,
                schema_path=schema_path,
                output_path=output_path,
                extra_args=args.extra_arg,
            )

            done = bool(payload["done"])
            summary = payload["summary"].strip()
            actions = payload.get("actions_taken", [])
            remaining = payload.get("remaining_work", [])
            next_focus = payload["next_focus"].strip()

            history.append(f"[iter {iteration}] {summary}")
            print_panel(
                f"Result {iteration} | done={done}",
                [
                    f"Summary: {summary}",
                    f"Actions taken: {actions if actions else '[]'}",
                    f"Remaining: {remaining if remaining else '[]'}",
                    f"Next focus: {next_focus}",
                ],
            )

            if done:
                print("\nGlobal goal completed.")
                return 0

            if not args.auto_continue:
                choice = input("Continue to next iteration? [Y/n]: ").strip().lower()
                if choice in {"n", "no"}:
                    print("Stopped by user before completion.")
                    return 0

    print("\nReached max iterations before completion.")
    return 2


if __name__ == "__main__":
    sys.exit(main())
