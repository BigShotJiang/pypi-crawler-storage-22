from codex_orchestrator import main as orchestrator_main


if __name__ == "__main__":
    raise SystemExit(orchestrator_main())
