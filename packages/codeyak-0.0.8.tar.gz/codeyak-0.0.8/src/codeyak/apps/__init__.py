"""
CodeYak applications.
"""
