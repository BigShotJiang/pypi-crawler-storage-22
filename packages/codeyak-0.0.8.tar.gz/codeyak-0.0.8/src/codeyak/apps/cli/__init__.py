"""
CLI application for CodeYak.
"""

from .main import main

__all__ = ["main"]
