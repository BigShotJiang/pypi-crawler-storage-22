"""Coding platform crawler"""

__version__ = "2.0.0"
