"""Application layer for the crawler system."""
