"""Repository implementations for data persistence."""

from .filesystem import FileSystemRepository

__all__ = ["FileSystemRepository"]
