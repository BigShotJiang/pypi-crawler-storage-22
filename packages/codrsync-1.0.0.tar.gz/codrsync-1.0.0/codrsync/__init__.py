"""
codrsync - Turn any dev into jedi ninja codr

AI-powered development orchestrator with guided development,
interactive validation, and persistent context.
"""

__version__ = "1.0.0"
__author__ = "Ciro Arendt"
