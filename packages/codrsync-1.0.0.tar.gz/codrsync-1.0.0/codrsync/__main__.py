"""Entry point for python -m codrsync"""

from codrsync.cli import app

if __name__ == "__main__":
    app()
