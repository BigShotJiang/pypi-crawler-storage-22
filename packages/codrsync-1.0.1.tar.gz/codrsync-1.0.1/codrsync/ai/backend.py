"""
AI Backend abstraction - Multi-provider support

Supports:
- Claude Code CLI (recommended)
- Anthropic API (Claude)
- OpenAI API (GPT-4, GPT-4o, o1)
- Google AI (Gemini)
- xAI API (Grok)
- Ollama (local models)
"""

import os
import subprocess
import json
from abc import ABC, abstractmethod
from typing import Optional, Generator
from pathlib import Path

from rich.console import Console

from codrsync.auth import AIBackend, get_api_key
from codrsync.config import get_config


console = Console()


class AIBackendBase(ABC):
    """Abstract base for AI backends"""

    provider_name: str = "Unknown"

    @abstractmethod
    def run_prompt(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> str:
        """Run a prompt and return the response"""
        pass

    @abstractmethod
    def run_interactive(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> Generator[str, None, None]:
        """Run an interactive session, yielding responses"""
        pass

    def run_conversation(
        self,
        messages: list[dict],
        system: Optional[str] = None,
    ) -> str:
        """Run a multi-turn conversation. Default: use last user message as prompt."""
        last_user = ""
        for msg in reversed(messages):
            if msg.get("role") == "user":
                last_user = msg["content"]
                break
        return self.run_prompt(last_user, system=system)

    @staticmethod
    def _build_context_message(prompt: str, context: Optional[dict] = None) -> str:
        """Build a message with context included."""
        if context:
            context_str = json.dumps(context, indent=2, ensure_ascii=False)
            return f"Context:\n```json\n{context_str}\n```\n\n{prompt}"
        return prompt


class ClaudeCodeBackend(AIBackendBase):
    """Uses Claude Code CLI"""

    provider_name = "Claude Code CLI"

    def __init__(self):
        self.claude_path = "claude"

    def run_prompt(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> str:
        """Run prompt via Claude Code CLI"""
        full_prompt = self._build_prompt(prompt, context, system)
        cmd = [self.claude_path, "-p", full_prompt]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300  # 5 min timeout
            )
            return result.stdout
        except subprocess.TimeoutExpired:
            return "Error: Command timed out"
        except Exception as e:
            return f"Error: {str(e)}"

    def run_interactive(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> Generator[str, None, None]:
        """Run interactive Claude Code session"""
        yield self.run_prompt(prompt, context, system)

    def run_conversation(
        self,
        messages: list[dict],
        system: Optional[str] = None,
    ) -> str:
        """Run conversation via Claude Code CLI"""
        parts = []
        if system:
            parts.append(f"<system>\n{system}\n</system>\n")

        for msg in messages:
            role = msg["role"].upper()
            parts.append(f"[{role}]\n{msg['content']}\n")

        full_prompt = "\n".join(parts)
        cmd = [self.claude_path, "-p", full_prompt]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
            )
            return result.stdout
        except subprocess.TimeoutExpired:
            return "Error: Command timed out"
        except Exception as e:
            return f"Error: {str(e)}"

    @staticmethod
    def _build_prompt(
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> str:
        """Combine system, context, and prompt into a single string for CLI mode."""
        parts = []

        if system:
            parts.append(f"<system>\n{system}\n</system>\n")

        if context:
            context_str = json.dumps(context, indent=2, ensure_ascii=False)
            parts.append(f"<context>\n{context_str}\n</context>\n")

        parts.append(prompt)
        return "\n".join(parts)


class AnthropicAPIBackend(AIBackendBase):
    """Uses Anthropic API directly"""

    provider_name = "Anthropic API"

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or get_api_key(AIBackend.ANTHROPIC_API) or os.getenv("ANTHROPIC_API_KEY")
        self.model = model or self._get_preferred_model() or "claude-sonnet-4-20250514"

        if not self.api_key:
            raise ValueError("ANTHROPIC_API_KEY not set")

        try:
            from anthropic import Anthropic
            self.client = Anthropic(api_key=self.api_key)
        except ImportError:
            raise ImportError("anthropic package not installed. Run: pip install anthropic")

    def _get_preferred_model(self) -> Optional[str]:
        config = get_config()
        if config.model_preferences:
            return config.model_preferences.get("anthropic-api")
        return None

    def run_prompt(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> str:
        """Run prompt via Anthropic API"""
        messages = [{"role": "user", "content": self._build_context_message(prompt, context)}]

        kwargs = {
            "model": self.model,
            "max_tokens": 4096,
            "messages": messages,
        }
        if system:
            kwargs["system"] = system

        response = self.client.messages.create(**kwargs)
        return response.content[0].text

    def run_interactive(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> Generator[str, None, None]:
        """Run with streaming"""
        messages = [{"role": "user", "content": self._build_context_message(prompt, context)}]

        kwargs = {
            "model": self.model,
            "max_tokens": 4096,
            "messages": messages,
        }
        if system:
            kwargs["system"] = system

        with self.client.messages.stream(**kwargs) as stream:
            for text in stream.text_stream:
                yield text

    def run_conversation(
        self,
        messages: list[dict],
        system: Optional[str] = None,
    ) -> str:
        """Run a multi-turn conversation via API"""
        kwargs = {
            "model": self.model,
            "max_tokens": 4096,
            "messages": messages,
        }
        if system:
            kwargs["system"] = system

        response = self.client.messages.create(**kwargs)
        return response.content[0].text


class OpenAIAPIBackend(AIBackendBase):
    """Uses OpenAI API (GPT-4, GPT-4o, o1)"""

    provider_name = "OpenAI API"

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or get_api_key(AIBackend.OPENAI_API) or os.getenv("OPENAI_API_KEY")
        self.model = model or self._get_preferred_model() or "gpt-4o"

        if not self.api_key:
            raise ValueError("OPENAI_API_KEY not set")

        try:
            from openai import OpenAI
            self.client = OpenAI(api_key=self.api_key)
        except ImportError:
            raise ImportError("openai package not installed. Run: pip install openai")

    def _get_preferred_model(self) -> Optional[str]:
        config = get_config()
        if config.model_preferences:
            return config.model_preferences.get("openai-api")
        return None

    def run_prompt(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> str:
        """Run prompt via OpenAI API"""
        messages = []

        if system:
            messages.append({"role": "system", "content": system})

        messages.append({"role": "user", "content": self._build_context_message(prompt, context)})

        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=4096,
        )
        return response.choices[0].message.content

    def run_interactive(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> Generator[str, None, None]:
        """Run with streaming"""
        messages = []

        if system:
            messages.append({"role": "system", "content": system})

        messages.append({"role": "user", "content": self._build_context_message(prompt, context)})

        stream = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=4096,
            stream=True,
        )

        for chunk in stream:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content

    def run_conversation(
        self,
        messages: list[dict],
        system: Optional[str] = None,
    ) -> str:
        """Run a multi-turn conversation via API"""
        api_messages = []

        if system:
            api_messages.append({"role": "system", "content": system})

        api_messages.extend(messages)

        response = self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            max_tokens=4096,
        )
        return response.choices[0].message.content


class GoogleAIBackend(AIBackendBase):
    """Uses Google AI (Gemini) API"""

    provider_name = "Google AI (Gemini)"

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or get_api_key(AIBackend.GOOGLE_AI) or os.getenv("GOOGLE_AI_API_KEY")
        self.model = model or self._get_preferred_model() or "gemini-2.0-flash"

        if not self.api_key:
            raise ValueError("GOOGLE_AI_API_KEY not set")

        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            self.genai = genai
            self.client = genai.GenerativeModel(self.model)
        except ImportError:
            raise ImportError("google-generativeai package not installed. Run: pip install google-generativeai")

    def _get_preferred_model(self) -> Optional[str]:
        config = get_config()
        if config.model_preferences:
            return config.model_preferences.get("google-ai")
        return None

    def run_prompt(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> str:
        """Run prompt via Google AI API"""
        full_prompt = self._build_context_message(prompt, context)

        if system:
            full_prompt = f"{system}\n\n{full_prompt}"

        response = self.client.generate_content(full_prompt)
        return response.text

    def run_interactive(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> Generator[str, None, None]:
        """Run with streaming"""
        full_prompt = self._build_context_message(prompt, context)

        if system:
            full_prompt = f"{system}\n\n{full_prompt}"

        response = self.client.generate_content(full_prompt, stream=True)

        for chunk in response:
            if chunk.text:
                yield chunk.text

    def run_conversation(
        self,
        messages: list[dict],
        system: Optional[str] = None,
    ) -> str:
        """Run a multi-turn conversation via API"""
        # Convert to Gemini format
        chat = self.client.start_chat(history=[])

        for msg in messages:
            if msg["role"] == "user":
                response = chat.send_message(msg["content"])

        return response.text


class XAIAPIBackend(AIBackendBase):
    """Uses xAI (Grok) API"""

    provider_name = "xAI (Grok)"

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or get_api_key(AIBackend.XAI_API) or os.getenv("XAI_API_KEY")
        self.model = model or self._get_preferred_model() or "grok-2"

        if not self.api_key:
            raise ValueError("XAI_API_KEY not set")

        # xAI uses OpenAI-compatible API
        try:
            from openai import OpenAI
            self.client = OpenAI(
                api_key=self.api_key,
                base_url="https://api.x.ai/v1"
            )
        except ImportError:
            raise ImportError("openai package not installed. Run: pip install openai")

    def _get_preferred_model(self) -> Optional[str]:
        config = get_config()
        if config.model_preferences:
            return config.model_preferences.get("xai-api")
        return None

    def run_prompt(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> str:
        """Run prompt via xAI API"""
        messages = []

        if system:
            messages.append({"role": "system", "content": system})

        messages.append({"role": "user", "content": self._build_context_message(prompt, context)})

        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=4096,
        )
        return response.choices[0].message.content

    def run_interactive(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> Generator[str, None, None]:
        """Run with streaming"""
        messages = []

        if system:
            messages.append({"role": "system", "content": system})

        messages.append({"role": "user", "content": self._build_context_message(prompt, context)})

        stream = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=4096,
            stream=True,
        )

        for chunk in stream:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content

    def run_conversation(
        self,
        messages: list[dict],
        system: Optional[str] = None,
    ) -> str:
        """Run a multi-turn conversation via API"""
        api_messages = []

        if system:
            api_messages.append({"role": "system", "content": system})

        api_messages.extend(messages)

        response = self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            max_tokens=4096,
        )
        return response.choices[0].message.content


class OllamaBackend(AIBackendBase):
    """Uses Ollama for local models"""

    provider_name = "Ollama (Local)"

    def __init__(self, model: Optional[str] = None, host: Optional[str] = None):
        config = get_config()
        self.model = model or config.ollama_model or "llama3.2"
        self.host = host or config.ollama_host or "http://localhost:11434"

        try:
            import ollama
            self.client = ollama.Client(host=self.host)
        except ImportError:
            raise ImportError("ollama package not installed. Run: pip install ollama")

    def run_prompt(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> str:
        """Run prompt via Ollama"""
        messages = []

        if system:
            messages.append({"role": "system", "content": system})

        messages.append({"role": "user", "content": self._build_context_message(prompt, context)})

        response = self.client.chat(
            model=self.model,
            messages=messages,
        )
        return response["message"]["content"]

    def run_interactive(
        self,
        prompt: str,
        context: Optional[dict] = None,
        system: Optional[str] = None,
    ) -> Generator[str, None, None]:
        """Run with streaming"""
        messages = []

        if system:
            messages.append({"role": "system", "content": system})

        messages.append({"role": "user", "content": self._build_context_message(prompt, context)})

        stream = self.client.chat(
            model=self.model,
            messages=messages,
            stream=True,
        )

        for chunk in stream:
            if chunk["message"]["content"]:
                yield chunk["message"]["content"]

    def run_conversation(
        self,
        messages: list[dict],
        system: Optional[str] = None,
    ) -> str:
        """Run a multi-turn conversation via Ollama"""
        api_messages = []

        if system:
            api_messages.append({"role": "system", "content": system})

        api_messages.extend(messages)

        response = self.client.chat(
            model=self.model,
            messages=api_messages,
        )
        return response["message"]["content"]


def get_backend_instance(backend: AIBackend) -> AIBackendBase:
    """Get appropriate backend instance.

    Args:
        backend: The AI backend type to instantiate

    Returns:
        An instance of the appropriate backend class

    Raises:
        ValueError: If no suitable backend is available
    """
    backend_classes = {
        AIBackend.CLAUDE_CODE: ClaudeCodeBackend,
        AIBackend.ANTHROPIC_API: AnthropicAPIBackend,
        AIBackend.OPENAI_API: OpenAIAPIBackend,
        AIBackend.GOOGLE_AI: GoogleAIBackend,
        AIBackend.XAI_API: XAIAPIBackend,
        AIBackend.OLLAMA: OllamaBackend,
    }

    if backend not in backend_classes:
        raise ValueError(f"No AI backend available for {backend.value}")

    return backend_classes[backend]()


def get_available_backends() -> list[tuple[AIBackend, str]]:
    """Get list of available backends with their names.

    Returns:
        List of tuples (backend_enum, provider_name)
    """
    from codrsync.auth import detect_all_providers, PROVIDERS

    available = detect_all_providers()
    result = []

    for provider_id, is_available in available.items():
        if is_available:
            backend_enum = AIBackend(provider_id)
            provider_name = PROVIDERS.get(provider_id, {}).get("name", provider_id)
            result.append((backend_enum, provider_name))

    return result
