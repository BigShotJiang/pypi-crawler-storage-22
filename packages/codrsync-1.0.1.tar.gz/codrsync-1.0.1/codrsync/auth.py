"""
Authentication and AI backend detection - Multi-provider support

Supports:
- Claude Code CLI (recommended - full agentic capabilities)
- Anthropic API (Claude)
- OpenAI API (GPT-4, GPT-4o, o1)
- Google AI (Gemini)
- xAI API (Grok)
- Ollama (local models)
"""

import os
import shutil
from enum import Enum
from typing import Optional, Dict, Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
import questionary

from codrsync.config import get_config, Config


console = Console()


class AIBackend(Enum):
    """Supported AI backends for codrsync.

    Priority order (when auto-detecting):
    1. Claude Code CLI (preferred - full agentic capabilities)
    2. Anthropic API (Claude via API)
    3. OpenAI API (GPT-4, GPT-4o)
    4. Google AI (Gemini)
    5. xAI API (Grok)
    6. Ollama (local models)
    7. Offline mode
    """
    CLAUDE_CODE = "claude-code"
    ANTHROPIC_API = "anthropic-api"
    OPENAI_API = "openai-api"
    GOOGLE_AI = "google-ai"
    XAI_API = "xai-api"
    OLLAMA = "ollama"
    OFFLINE = "offline"


# =============================================================================
# PROVIDER CONFIGURATION
# =============================================================================

PROVIDERS = {
    "claude-code": {
        "name": "Claude Code CLI",
        "description": "Anthropic's official CLI with full agentic capabilities",
        "env_key": None,  # CLI-based, no API key
        "config_key": None,
        "detect_fn": "detect_claude_code",
        "recommended": True,
        "models": ["claude-sonnet-4", "claude-opus-4"],
        "install_hint": "npm install -g @anthropic-ai/claude-code",
    },
    "anthropic-api": {
        "name": "Anthropic API",
        "description": "Claude models via direct API",
        "env_key": "ANTHROPIC_API_KEY",
        "config_key": "anthropic_api_key",
        "detect_fn": "detect_anthropic_api",
        "recommended": True,
        "models": ["claude-sonnet-4-20250514", "claude-opus-4-20250514"],
        "url": "https://console.anthropic.com/",
    },
    "openai-api": {
        "name": "OpenAI API",
        "description": "GPT-4, GPT-4o, and o1 models",
        "env_key": "OPENAI_API_KEY",
        "config_key": "openai_api_key",
        "detect_fn": "detect_openai_api",
        "recommended": False,
        "models": ["gpt-4o", "gpt-4-turbo", "o1-preview", "o1-mini"],
        "url": "https://platform.openai.com/api-keys",
    },
    "google-ai": {
        "name": "Google AI (Gemini)",
        "description": "Gemini Pro and Ultra models",
        "env_key": "GOOGLE_AI_API_KEY",
        "config_key": "google_ai_api_key",
        "detect_fn": "detect_google_ai",
        "recommended": False,
        "models": ["gemini-2.0-flash", "gemini-1.5-pro", "gemini-1.5-flash"],
        "url": "https://aistudio.google.com/apikey",
    },
    "xai-api": {
        "name": "xAI (Grok)",
        "description": "Grok models from xAI",
        "env_key": "XAI_API_KEY",
        "config_key": "xai_api_key",
        "detect_fn": "detect_xai_api",
        "recommended": False,
        "models": ["grok-2", "grok-beta"],
        "url": "https://console.x.ai/",
    },
    "ollama": {
        "name": "Ollama (Local)",
        "description": "Run models locally via Ollama",
        "env_key": None,
        "config_key": None,
        "detect_fn": "detect_ollama",
        "recommended": False,
        "models": ["llama3.2", "codellama", "mistral", "mixtral"],
        "install_hint": "curl -fsSL https://ollama.com/install.sh | sh",
    },
    "offline": {
        "name": "Offline Mode",
        "description": "Local commands only, no AI features",
        "env_key": None,
        "config_key": None,
        "detect_fn": None,
        "recommended": False,
        "models": [],
    },
}


# =============================================================================
# DETECTION FUNCTIONS
# =============================================================================

def detect_claude_code() -> bool:
    """Check if Claude Code CLI is installed"""
    return shutil.which("claude") is not None


def detect_anthropic_api() -> bool:
    """Check if Anthropic API key is configured"""
    config = get_config()
    return bool(os.getenv("ANTHROPIC_API_KEY") or config.anthropic_api_key)


def detect_openai_api() -> bool:
    """Check if OpenAI API key is configured"""
    config = get_config()
    return bool(os.getenv("OPENAI_API_KEY") or config.openai_api_key)


def detect_google_ai() -> bool:
    """Check if Google AI API key is configured"""
    config = get_config()
    return bool(os.getenv("GOOGLE_AI_API_KEY") or config.google_ai_api_key)


def detect_xai_api() -> bool:
    """Check if xAI API key is configured"""
    config = get_config()
    return bool(os.getenv("XAI_API_KEY") or config.xai_api_key)


def detect_ollama() -> bool:
    """Check if Ollama is installed and running"""
    if not shutil.which("ollama"):
        return False

    # Try to connect to Ollama server
    try:
        import urllib.request
        req = urllib.request.urlopen("http://localhost:11434/api/tags", timeout=2)
        return req.status == 200
    except Exception:
        return False


def get_detection_fn(provider: str):
    """Get detection function for a provider"""
    fn_name = PROVIDERS.get(provider, {}).get("detect_fn")
    if not fn_name:
        return lambda: False

    return globals().get(fn_name, lambda: False)


def detect_all_providers() -> Dict[str, bool]:
    """Detect all available providers.

    Returns:
        Dictionary mapping provider names to availability status
    """
    return {
        provider: get_detection_fn(provider)()
        for provider in PROVIDERS
        if provider != "offline"
    }


# =============================================================================
# BACKEND SELECTION
# =============================================================================

def get_ai_backend() -> AIBackend:
    """
    Detect which AI backend to use.

    Priority:
    1. Explicit config setting (if available)
    2. Claude Code CLI (if installed) - recommended
    3. Anthropic API (if key present)
    4. OpenAI API (if key present)
    5. Google AI (if key present)
    6. xAI (if key present)
    7. Ollama (if running)
    8. Offline mode
    """
    from codrsync.i18n import t

    config = get_config()

    # Check explicit config
    backend_map = {
        "claude-code": (AIBackend.CLAUDE_CODE, detect_claude_code),
        "anthropic-api": (AIBackend.ANTHROPIC_API, detect_anthropic_api),
        "openai-api": (AIBackend.OPENAI_API, detect_openai_api),
        "google-ai": (AIBackend.GOOGLE_AI, detect_google_ai),
        "xai-api": (AIBackend.XAI_API, detect_xai_api),
        "ollama": (AIBackend.OLLAMA, detect_ollama),
        "offline": (AIBackend.OFFLINE, lambda: True),
    }

    # If explicitly configured, try that first
    if config.ai_backend in backend_map:
        backend_enum, detect_fn = backend_map[config.ai_backend]
        if detect_fn():
            return backend_enum
        # Warn but continue with auto-detection
        console.print(f"[yellow]⚠ Configured backend '{config.ai_backend}' not available, auto-detecting...[/yellow]")

    # Auto-detect in priority order
    priority_order = [
        "claude-code",
        "anthropic-api",
        "openai-api",
        "google-ai",
        "xai-api",
        "ollama",
    ]

    for provider in priority_order:
        if provider in backend_map:
            backend_enum, detect_fn = backend_map[provider]
            if detect_fn():
                return backend_enum

    return AIBackend.OFFLINE


def get_api_key(backend: AIBackend) -> Optional[str]:
    """Get API key for a backend from config or environment.

    Args:
        backend: The AI backend to get the key for

    Returns:
        API key string or None if not found
    """
    config = get_config()

    key_mapping = {
        AIBackend.ANTHROPIC_API: ("ANTHROPIC_API_KEY", config.anthropic_api_key),
        AIBackend.OPENAI_API: ("OPENAI_API_KEY", config.openai_api_key),
        AIBackend.GOOGLE_AI: ("GOOGLE_AI_API_KEY", config.google_ai_api_key),
        AIBackend.XAI_API: ("XAI_API_KEY", config.xai_api_key),
    }

    if backend not in key_mapping:
        return None

    env_key, config_key = key_mapping[backend]
    return os.getenv(env_key) or config_key


# =============================================================================
# STATUS AND CONFIGURATION UI
# =============================================================================

def show_auth_status():
    """Show current authentication status with all providers"""
    from codrsync.i18n import t

    backend = get_ai_backend()
    config = get_config()
    available = detect_all_providers()

    # Create table
    table = Table(title="AI Providers Status", show_header=True, header_style="bold cyan")
    table.add_column("Provider", style="cyan")
    table.add_column("Status")
    table.add_column("Models", style="dim")

    for provider_id, info in PROVIDERS.items():
        if provider_id == "offline":
            continue

        is_available = available.get(provider_id, False)
        is_active = backend.value == provider_id

        # Status indicator
        if is_active:
            status = "[bold green]● Active[/bold green]"
        elif is_available:
            status = "[green]✓ Available[/green]"
        else:
            status = "[dim]✗ Not configured[/dim]"

        # Models
        models = ", ".join(info.get("models", [])[:2])
        if len(info.get("models", [])) > 2:
            models += "..."

        # Recommended badge
        name = info["name"]
        if info.get("recommended"):
            name += " [yellow]★[/yellow]"

        table.add_row(name, status, models)

    console.print(table)

    # Current config
    console.print(f"\n[bold]Current Configuration:[/bold]")
    console.print(f"  Backend: [cyan]{backend.value}[/cyan]")
    console.print(f"  Config setting: [dim]{config.ai_backend}[/dim]")

    if backend == AIBackend.OFFLINE:
        console.print(f"\n[yellow]⚠ No AI backend available. Run 'codrsync auth' to configure.[/yellow]")


def configure_auth():
    """Interactive authentication configuration with multi-provider support"""
    from codrsync.i18n import t

    console.print("\n[bold cyan]codrsync AI Configuration[/bold cyan]\n")
    console.print("Configure which AI provider to use for development assistance.\n")

    # Detect available options
    available = detect_all_providers()

    # Build choices
    choices = []

    # Claude Code (recommended)
    if available.get("claude-code"):
        choices.append({
            "name": "★ Claude Code CLI (recommended - full agentic capabilities)",
            "value": "claude-code"
        })
    else:
        choices.append({
            "name": "Claude Code CLI (not installed)",
            "value": "claude-code",
            "disabled": "Install: npm install -g @anthropic-ai/claude-code"
        })

    # Anthropic API
    status = "✓ configured" if available.get("anthropic-api") else "enter key"
    choices.append({
        "name": f"Anthropic API (Claude) [{status}]",
        "value": "anthropic-api"
    })

    # OpenAI API
    status = "✓ configured" if available.get("openai-api") else "enter key"
    choices.append({
        "name": f"OpenAI API (GPT-4, o1) [{status}]",
        "value": "openai-api"
    })

    # Google AI
    status = "✓ configured" if available.get("google-ai") else "enter key"
    choices.append({
        "name": f"Google AI (Gemini) [{status}]",
        "value": "google-ai"
    })

    # xAI
    status = "✓ configured" if available.get("xai-api") else "enter key"
    choices.append({
        "name": f"xAI (Grok) [{status}]",
        "value": "xai-api"
    })

    # Ollama
    if available.get("ollama"):
        choices.append({
            "name": "Ollama (local models) [✓ running]",
            "value": "ollama"
        })
    else:
        choices.append({
            "name": "Ollama (local models) [not running]",
            "value": "ollama",
            "disabled": "Start Ollama server first"
        })

    # Offline
    choices.append({
        "name": "Offline mode (no AI features)",
        "value": "offline"
    })

    selected = questionary.select(
        "Select AI provider:",
        choices=choices,
    ).ask()

    if selected is None:
        raise SystemExit(0)

    config = get_config()
    config.ai_backend = selected

    # Handle API key entry for API-based providers
    api_providers = {
        "anthropic-api": ("anthropic_api_key", "ANTHROPIC_API_KEY", "https://console.anthropic.com/"),
        "openai-api": ("openai_api_key", "OPENAI_API_KEY", "https://platform.openai.com/api-keys"),
        "google-ai": ("google_ai_api_key", "GOOGLE_AI_API_KEY", "https://aistudio.google.com/apikey"),
        "xai-api": ("xai_api_key", "XAI_API_KEY", "https://console.x.ai/"),
    }

    if selected in api_providers:
        config_key, env_key, url = api_providers[selected]
        current_key = os.getenv(env_key) or getattr(config, config_key, None)

        if not current_key:
            console.print(f"\n[dim]Get your API key at: {url}[/dim]")
            api_key = questionary.password(
                f"Enter {PROVIDERS[selected]['name']} API key:"
            ).ask()

            if api_key:
                setattr(config, config_key, api_key)
                console.print(f"\n[green]✓[/green] API key saved securely")
                console.print(f"[dim]Tip: You can also set {env_key} environment variable[/dim]")
        else:
            console.print(f"\n[green]✓[/green] API key already configured")

            if questionary.confirm("Update API key?", default=False).ask():
                api_key = questionary.password(
                    f"Enter new {PROVIDERS[selected]['name']} API key:"
                ).ask()
                if api_key:
                    setattr(config, config_key, api_key)
                    console.print(f"[green]✓[/green] API key updated")

    # Model selection for API providers
    if selected in PROVIDERS and PROVIDERS[selected].get("models"):
        models = PROVIDERS[selected]["models"]
        if len(models) > 1:
            console.print(f"\n[dim]Available models: {', '.join(models)}[/dim]")

            model = questionary.select(
                "Select default model:",
                choices=models,
                default=models[0],
            ).ask()

            if model:
                # Store model preference per provider
                if not hasattr(config, 'model_preferences'):
                    config.model_preferences = {}
                config.model_preferences = config.model_preferences or {}
                config.model_preferences[selected] = model

    config.save()

    console.print(f"\n[green]✓[/green] Configuration saved!")
    console.print(f"  Backend: [bold]{selected}[/bold]")

    if selected == "claude-code":
        console.print("\n[dim]Start developing with: codrsync start[/dim]")
    elif selected == "offline":
        console.print("\n[yellow]Note:[/yellow] AI-powered commands (init, build, prp) won't be available.")
        console.print("Available offline: status, roadmap, export, sprint, scan")
    else:
        console.print("\n[dim]You're all set! AI features are now available.[/dim]")
