"""
codrsync Hooks - Claude Code integration hooks

This package contains hook handlers that are invoked by Claude Code
at various points during a session:

- context.py: SessionStart - Inject project context
- activity.py: PostToolUse - Log file editing activity
- progress.py: Stop - Update progress tracking
"""

from codrsync.hooks.context import inject_context
from codrsync.hooks.activity import log_activity
from codrsync.hooks.progress import update_progress

__all__ = ["inject_context", "log_activity", "update_progress"]
