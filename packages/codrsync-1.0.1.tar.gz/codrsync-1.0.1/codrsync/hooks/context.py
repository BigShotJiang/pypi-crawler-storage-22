"""
codrsync Hook: Context Injection

This hook is triggered at SessionStart to inject project context
into the Claude Code session.
"""

import json
from pathlib import Path
from typing import Dict, Any, Optional


def inject_context() -> None:
    """Hook: SessionStart - Inject project context.

    Displays project information and available commands at the
    start of a Claude Code session.
    """
    project_path = Path.cwd()
    codrsync_dir = project_path / ".codrsync"

    if not codrsync_dir.exists():
        print("⚠️  codrsync não inicializado. Execute: codrsync init")
        return

    # Load context
    manifest = load_manifest(codrsync_dir)
    progress = load_progress(codrsync_dir)
    context = load_context_md(codrsync_dir)

    # Get project info
    project_name = manifest.get("project", {}).get("name", project_path.name)
    phase = progress.get("phase", "não definida")
    sprint_info = format_sprint(progress)

    # Build context message
    message = f"""
╔══════════════════════════════════════════════════════════════════╗
║  [codrsync] Metodologia CE (Context Engineering) Ativa           ║
╠══════════════════════════════════════════════════════════════════╣
║  Projeto: {project_name:<53} ║
║  Fase: {phase:<56} ║
║  Sprint: {sprint_info:<54} ║
╠══════════════════════════════════════════════════════════════════╣
║  Comandos: /hitit /status /sprint /generate-prp /execute-prp     ║
╚══════════════════════════════════════════════════════════════════╝
"""
    print(message)

    # Print context summary if available
    if context:
        print(f"\n📋 Contexto atual:\n{context[:500]}{'...' if len(context) > 500 else ''}\n")


def load_manifest(codrsync_dir: Path) -> Dict[str, Any]:
    """Load manifest.json from .codrsync directory.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Manifest data or empty dict if not found
    """
    manifest_path = codrsync_dir / "manifest.json"

    if not manifest_path.exists():
        return {}

    try:
        return json.loads(manifest_path.read_text())
    except (json.JSONDecodeError, IOError):
        return {}


def load_progress(codrsync_dir: Path) -> Dict[str, Any]:
    """Load progress.json from .codrsync directory.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Progress data or empty dict if not found
    """
    progress_path = codrsync_dir / "progress.json"

    if not progress_path.exists():
        return {}

    try:
        return json.loads(progress_path.read_text())
    except (json.JSONDecodeError, IOError):
        return {}


def load_context_md(codrsync_dir: Path) -> Optional[str]:
    """Load context.md from .codrsync directory.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Context content or None if not found
    """
    context_path = codrsync_dir / "context.md"

    if not context_path.exists():
        return None

    try:
        return context_path.read_text()
    except IOError:
        return None


def format_sprint(progress: Dict[str, Any]) -> str:
    """Format sprint information for display.

    Args:
        progress: Progress data dictionary

    Returns:
        Formatted sprint string
    """
    sprint = progress.get("current_sprint", {})

    if not sprint:
        return "Nenhum sprint ativo"

    sprint_name = sprint.get("name", "Sprint")
    total_stories = len(sprint.get("stories", []))
    completed = sum(
        1 for s in sprint.get("stories", [])
        if s.get("status") == "done"
    )

    if total_stories > 0:
        return f"{sprint_name} ({completed}/{total_stories} stories)"
    else:
        return sprint_name
