"""
codrsync Hook: Progress Tracking

This hook is triggered at Stop to update progress.json
when Claude finishes a response.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any

from codrsync.hooks.activity import get_activity_stats


def update_progress() -> None:
    """Hook: Stop - Update progress.json when Claude stops.

    Updates last_activity timestamp and metrics from the
    activity log.
    """
    project_path = Path.cwd()
    codrsync_dir = project_path / ".codrsync"
    progress_file = codrsync_dir / "progress.json"

    if not progress_file.exists():
        return

    try:
        progress = json.loads(progress_file.read_text())
    except (json.JSONDecodeError, IOError):
        return

    # Update last_activity timestamp
    progress["last_activity"] = datetime.now().isoformat()

    # Update metrics from activity log
    stats = get_activity_stats(codrsync_dir)
    if stats:
        progress.setdefault("metrics", {})
        progress["metrics"]["edits_today"] = stats.get("today_edits", 0)
        progress["metrics"]["total_edits"] = stats.get("total_edits", 0)
        progress["metrics"]["unique_files_edited"] = stats.get("unique_files", 0)

    # Increment session count
    progress.setdefault("metrics", {})
    sessions = progress["metrics"].get("sessions", 0)
    progress["metrics"]["sessions"] = sessions + 1

    # Write updated progress
    try:
        progress_file.write_text(json.dumps(progress, indent=2))
    except IOError:
        pass  # Silently fail - don't interrupt Claude


def get_progress_summary(codrsync_dir: Path) -> Dict[str, Any]:
    """Get a summary of current progress.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Dictionary with progress summary
    """
    progress_file = codrsync_dir / "progress.json"

    if not progress_file.exists():
        return {}

    try:
        progress = json.loads(progress_file.read_text())
    except (json.JSONDecodeError, IOError):
        return {}

    # Extract key info
    summary = {
        "phase": progress.get("phase", "unknown"),
        "last_activity": progress.get("last_activity"),
    }

    # Sprint info
    sprint = progress.get("current_sprint", {})
    if sprint:
        stories = sprint.get("stories", [])
        summary["sprint"] = {
            "name": sprint.get("name"),
            "total_stories": len(stories),
            "completed": sum(1 for s in stories if s.get("status") == "done"),
            "in_progress": sum(1 for s in stories if s.get("status") == "in_progress"),
        }

    # Metrics
    metrics = progress.get("metrics", {})
    if metrics:
        summary["metrics"] = metrics

    return summary


def mark_story_done(codrsync_dir: Path, story_id: str) -> bool:
    """Mark a story as done in progress.json.

    Args:
        codrsync_dir: Path to .codrsync directory
        story_id: ID of the story to mark done

    Returns:
        True if story was found and marked, False otherwise
    """
    progress_file = codrsync_dir / "progress.json"

    if not progress_file.exists():
        return False

    try:
        progress = json.loads(progress_file.read_text())
    except (json.JSONDecodeError, IOError):
        return False

    sprint = progress.get("current_sprint", {})
    stories = sprint.get("stories", [])

    found = False
    for story in stories:
        if story.get("id") == story_id:
            story["status"] = "done"
            story["completed_at"] = datetime.now().isoformat()
            found = True
            break

    if found:
        try:
            progress_file.write_text(json.dumps(progress, indent=2))
        except IOError:
            return False

    return found
