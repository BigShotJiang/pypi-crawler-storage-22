"""
codrsync Setup - Claude Code environment configuration

This module handles:
- Claude Code detection and installation
- .claude/ directory setup with hooks
- Slash commands deployment
- CLAUDE.md methodology injection
"""

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional, Dict, Any

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from codrsync.i18n import t

console = Console()


# =============================================================================
# CLAUDE CODE DETECTION
# =============================================================================

def detect_claude_code() -> Optional[str]:
    """Detect if Claude Code CLI is installed.

    Returns:
        Path to claude executable if found and valid, None otherwise.
    """
    claude_path = shutil.which("claude")
    if claude_path:
        try:
            result = subprocess.run(
                ["claude", "--version"],
                capture_output=True,
                text=True,
                timeout=10
            )
            # Verify it's actually Claude Code
            if "claude" in result.stdout.lower() or result.returncode == 0:
                return claude_path
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

    return None


def get_claude_version(claude_path: str) -> str:
    """Get Claude Code version string.

    Args:
        claude_path: Path to claude executable

    Returns:
        Version string or "unknown" if detection fails
    """
    try:
        result = subprocess.run(
            [claude_path, "--version"],
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.stdout.strip() or "unknown"
    except Exception:
        return "unknown"


# =============================================================================
# CLAUDE CODE INSTALLATION
# =============================================================================

INSTALLERS = {
    "npm": {
        "check": ["npm", "--version"],
        "install": ["npm", "install", "-g", "@anthropic-ai/claude-code"],
        "name": "npm (Node.js)",
        "url": "https://nodejs.org"
    },
    "brew": {
        "check": ["brew", "--version"],
        "install": ["brew", "install", "claude-code"],
        "name": "Homebrew",
        "url": "https://brew.sh"
    },
    "pip": {
        "check": ["pip", "--version"],
        "install": ["pip", "install", "claude-code"],
        "name": "pip (Python)",
        "url": "https://pip.pypa.io"
    },
    "pipx": {
        "check": ["pipx", "--version"],
        "install": ["pipx", "install", "claude-code"],
        "name": "pipx",
        "url": "https://pipx.pypa.io"
    },
    "cargo": {
        "check": ["cargo", "--version"],
        "install": ["cargo", "install", "claude-code"],
        "name": "Cargo (Rust)",
        "url": "https://rustup.rs"
    },
    "scoop": {
        "check": ["scoop", "--version"],
        "install": ["scoop", "install", "claude-code"],
        "name": "Scoop (Windows)",
        "url": "https://scoop.sh"
    },
}


def detect_available_installers() -> list[str]:
    """Detect which package managers are available on the system.

    Returns:
        List of available package manager names
    """
    available = []
    for name, config in INSTALLERS.items():
        try:
            result = subprocess.run(
                config["check"],
                capture_output=True,
                timeout=5
            )
            if result.returncode == 0:
                available.append(name)
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass
    return available


def offer_claude_installation() -> bool:
    """Offer to install Claude Code if not found.

    Returns:
        True if installation succeeded, False otherwise
    """
    console.print(Panel(
        "[yellow]Claude Code não encontrado[/yellow]\n\n"
        "O codrsync precisa do Claude Code para funcionar como superego.\n\n"
        "Opções de instalação:\n"
        "  [cyan]npm install -g @anthropic-ai/claude-code[/cyan]\n"
        "  [cyan]brew install claude-code[/cyan]\n"
        "  [cyan]pip install claude-code[/cyan]\n\n"
        "Ou visite: [link=https://claude.ai/code]https://claude.ai/code[/link]",
        title="Claude Code Necessário",
        border_style="yellow"
    ))

    # Detect available installers
    available = detect_available_installers()

    if not available:
        console.print("[red]Nenhum gerenciador de pacotes detectado.[/red]")
        console.print("Instale o npm, brew, pip ou outro gerenciador primeiro.")
        return False

    # Build choices for installer selection
    choices = [INSTALLERS[name]["name"] for name in available]
    choices.append("Cancelar")

    console.print(f"\n[dim]Gerenciadores disponíveis: {', '.join(available)}[/dim]")

    if not typer.confirm("Deseja instalar Claude Code agora?"):
        return False

    # Use first available installer (npm preferred)
    preferred_order = ["npm", "brew", "pipx", "pip", "cargo", "scoop"]
    installer = None
    for pref in preferred_order:
        if pref in available:
            installer = pref
            break

    if not installer:
        installer = available[0]

    console.print(f"\n[dim]Instalando via {INSTALLERS[installer]['name']}...[/dim]")

    try:
        result = subprocess.run(
            INSTALLERS[installer]["install"],
            capture_output=True,
            text=True,
            timeout=300  # 5 minutes timeout for install
        )

        if result.returncode == 0:
            console.print("[green]✓ Claude Code instalado com sucesso![/green]")
            return True
        else:
            console.print(f"[red]Falha na instalação:[/red]\n{result.stderr}")
            return False

    except subprocess.TimeoutExpired:
        console.print("[red]Instalação expirou. Tente manualmente.[/red]")
        return False
    except Exception as e:
        console.print(f"[red]Erro: {e}[/red]")
        return False


# =============================================================================
# ENVIRONMENT SETUP
# =============================================================================

def setup_claude_environment(project_path: Path, reset: bool = False) -> bool:
    """Configure .claude/ directory with codrsync hooks and commands.

    Args:
        project_path: Path to the project root
        reset: If True, overwrite existing configuration

    Returns:
        True if setup succeeded
    """
    claude_dir = project_path / ".claude"
    claude_dir.mkdir(exist_ok=True)

    # 1. Configure hooks (settings.json)
    settings_path = claude_dir / "settings.json"
    if reset or not settings_path.exists():
        settings = generate_hooks_config()
        settings_path.write_text(json.dumps(settings, indent=2))
        console.print("[green]✓[/green] Hooks configurados")
    else:
        console.print("[dim]✓ Hooks já configurados[/dim]")

    # 2. Copy slash commands
    commands_dir = claude_dir / "commands"
    commands_dir.mkdir(exist_ok=True)
    copied = copy_slash_commands(commands_dir, reset=reset)
    if copied > 0:
        console.print(f"[green]✓[/green] {copied} slash commands instalados")
    else:
        console.print("[dim]✓ Slash commands já instalados[/dim]")

    # 3. Update CLAUDE.md
    claude_md = project_path / "CLAUDE.md"
    inject_ce_methodology(claude_md, project_path)
    console.print("[green]✓[/green] CLAUDE.md atualizado com metodologia CE")

    return True


def generate_hooks_config() -> Dict[str, Any]:
    """Generate .claude/settings.json with codrsync hooks.

    Returns:
        Dictionary with hooks configuration
    """
    return {
        "hooks": {
            "SessionStart": [
                {
                    "matcher": "",
                    "hooks": [
                        {
                            "type": "command",
                            "command": "codrsync _inject-context"
                        }
                    ]
                }
            ],
            "PostToolUse": [
                {
                    "matcher": "Edit|Write",
                    "hooks": [
                        {
                            "type": "command",
                            "command": "codrsync _log-activity"
                        }
                    ]
                }
            ],
            "Stop": [
                {
                    "matcher": "",
                    "hooks": [
                        {
                            "type": "command",
                            "command": "codrsync _update-progress"
                        }
                    ]
                }
            ]
        }
    }


def copy_slash_commands(commands_dir: Path, reset: bool = False) -> int:
    """Copy slash command templates to .claude/commands/.

    Args:
        commands_dir: Target directory for commands
        reset: If True, overwrite existing commands

    Returns:
        Number of commands copied
    """
    # Get templates directory
    templates_dir = Path(__file__).parent / "templates" / "commands"

    if not templates_dir.exists():
        # Fallback: create basic commands inline
        return _create_default_commands(commands_dir, reset)

    copied = 0
    for template_file in templates_dir.glob("*.md"):
        target = commands_dir / template_file.name
        if reset or not target.exists():
            shutil.copy(template_file, target)
            copied += 1

    return copied


def _create_default_commands(commands_dir: Path, reset: bool = False) -> int:
    """Create default slash commands if templates not found.

    Args:
        commands_dir: Target directory for commands
        reset: If True, overwrite existing commands

    Returns:
        Number of commands created
    """
    commands = {
        "hitit.md": """# /hitit - Iniciar Projeto ou Feature

Inicia o fluxo de desenvolvimento com codrsync.

## Uso
```
/hitit [descrição do que você quer construir]
```

## Comportamento
1. Entende sua intenção através de perguntas
2. Detecta stack e integrações do projeto
3. Gera PRPs (Product Requirements Plans)
4. Inicia implementação guiada

## Exemplos
- `/hitit quero um sistema de autenticação`
- `/hitit adicionar dark mode`
- `/hitit API de pagamentos com Stripe`
""",
        "status.md": """# /status - Status do Projeto

Mostra o status atual do projeto codrsync.

## Uso
```
/status [--mini] [--executive]
```

## Flags
- `--mini`: Versão compacta
- `--executive`: Resumo executivo

## Informações Mostradas
- Fase atual do projeto
- Sprint ativo e progresso
- PRPs pendentes
- Métricas de atividade
""",
        "sprint.md": """# /sprint - Gerenciar Sprints

Gerencia sprints e stories do projeto.

## Uso
```
/sprint [comando]
```

## Comandos
- `/sprint` - Mostra sprint atual
- `/sprint start` - Inicia novo sprint
- `/sprint plan` - Planeja stories
- `/sprint review` - Revisa entregas
- `/sprint close` - Fecha sprint

## Exemplos
- `/sprint start --duration 2 --goal "MVP do auth"`
- `/sprint plan`
""",
        "generate-prp.md": """# /generate-prp - Gerar PRP

Gera um Product Requirements Plan para uma feature.

## Uso
```
/generate-prp <descrição da feature>
```

## Processo
1. Analisa o contexto do projeto
2. Decompõe em componentes
3. Define critérios de validação
4. Estima complexidade

## Exemplo
```
/generate-prp sistema de notificações push
```
""",
        "execute-prp.md": """# /execute-prp - Executar PRP

Executa a implementação de um PRP existente.

## Uso
```
/execute-prp <número ou nome do PRP>
```

## Processo
1. Carrega PRP e contexto
2. Implementa componente por componente
3. Valida critérios automaticamente
4. Atualiza progresso

## Exemplos
- `/execute-prp PRP-01`
- `/execute-prp auth-system`
""",
    }

    created = 0
    for filename, content in commands.items():
        target = commands_dir / filename
        if reset or not target.exists():
            target.write_text(content)
            created += 1

    return created


# =============================================================================
# CLAUDE.MD INJECTION
# =============================================================================

CE_METHODOLOGY_HEADER = """# METODOLOGIA CE (Context Engineering) - codrsync

## Comandos Disponíveis

- `/hitit` - Iniciar novo projeto ou feature
- `/status` - Ver status atual do projeto
- `/sprint` - Gerenciar sprints e stories
- `/generate-prp` - Gerar PRP (Product Requirements Plan)
- `/execute-prp` - Executar implementação de um PRP

## Princípios de Context Engineering

1. **Contexto Persistente**: Sempre leia .codrsync/context.md no início
2. **PRPs**: Planeje antes de implementar usando PRPs
3. **Progresso Rastreado**: Atualize stories ao completar tarefas
4. **Erros Documentados**: Registre falhas para aprendizado

## Arquivos Importantes

- `.codrsync/manifest.json` - Configuração do projeto
- `.codrsync/progress.json` - Status e stories
- `.codrsync/context.md` - Contexto persistente
- `PRPs/*.md` - Product Requirements Plans

---

"""


def inject_ce_methodology(claude_md_path: Path, project_path: Path) -> None:
    """Inject CE methodology into CLAUDE.md.

    Args:
        claude_md_path: Path to CLAUDE.md file
        project_path: Path to project root (for context)
    """
    existing_content = ""

    if claude_md_path.exists():
        existing_content = claude_md_path.read_text()

        # Remove existing CE header if present
        if "# METODOLOGIA CE" in existing_content:
            existing_content = _remove_ce_header(existing_content)

    new_content = CE_METHODOLOGY_HEADER + existing_content
    claude_md_path.write_text(new_content)


def _remove_ce_header(content: str) -> str:
    """Remove existing CE methodology header from content.

    Args:
        content: Original CLAUDE.md content

    Returns:
        Content with CE header removed
    """
    lines = content.split("\n")
    result = []
    skip_until_separator = False
    found_header = False

    for line in lines:
        if line.startswith("# METODOLOGIA CE"):
            skip_until_separator = True
            found_header = True
            continue

        if skip_until_separator:
            if line.strip() == "---":
                skip_until_separator = False
            continue

        result.append(line)

    # Remove leading empty lines
    while result and not result[0].strip():
        result.pop(0)

    return "\n".join(result)


# =============================================================================
# PROJECT VERIFICATION
# =============================================================================

def verify_codrsync_project(project_path: Path) -> Dict[str, Any]:
    """Verify if project has codrsync initialized.

    Args:
        project_path: Path to check

    Returns:
        Dictionary with project info or empty if not initialized
    """
    codrsync_dir = project_path / ".codrsync"

    if not codrsync_dir.exists():
        return {}

    manifest_path = codrsync_dir / "manifest.json"
    progress_path = codrsync_dir / "progress.json"

    result = {
        "initialized": True,
        "path": str(codrsync_dir),
    }

    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text())
            result["project_name"] = manifest.get("project", {}).get("name", "Unknown")
            result["manifest"] = manifest
        except json.JSONDecodeError:
            result["project_name"] = "Unknown"

    if progress_path.exists():
        try:
            progress = json.loads(progress_path.read_text())
            result["phase"] = progress.get("phase", "unknown")
            result["progress"] = progress
        except json.JSONDecodeError:
            result["phase"] = "unknown"

    return result


def offer_codrsync_init(project_path: Path) -> bool:
    """Offer to initialize codrsync if not found.

    Args:
        project_path: Path to initialize

    Returns:
        True if user accepted and init succeeded
    """
    console.print(Panel(
        "[yellow]Projeto codrsync não detectado[/yellow]\n\n"
        "Este diretório não tem codrsync inicializado.\n\n"
        "Execute [cyan]codrsync init[/cyan] para configurar.",
        title="Inicialização Necessária",
        border_style="yellow"
    ))

    if typer.confirm("Deseja inicializar agora?"):
        # Import and run init
        from codrsync.ai import kickstart as kickstart_module
        from codrsync.auth import get_ai_backend, AIBackend

        backend = get_ai_backend()
        if backend == AIBackend.OFFLINE:
            console.print("[red]AI backend necessário para init.[/red]")
            return False

        kickstart_module.run(backend=backend)
        return True

    return False


# =============================================================================
# LAUNCH CLAUDE CODE
# =============================================================================

def launch_claude(claude_path: str, project_path: Path) -> None:
    """Launch Claude Code, replacing current process.

    Args:
        claude_path: Path to claude executable
        project_path: Directory to launch in
    """
    os.chdir(project_path)
    os.execvp(claude_path, [claude_path])


def show_start_summary(project_path: Path, claude_path: str) -> None:
    """Show summary before launching Claude Code.

    Args:
        project_path: Project root path
        claude_path: Path to Claude executable
    """
    from codrsync import __version__

    project_info = verify_codrsync_project(project_path)
    claude_version = get_claude_version(claude_path)

    # Count slash commands
    commands_dir = project_path / ".claude" / "commands"
    command_count = len(list(commands_dir.glob("*.md"))) if commands_dir.exists() else 0

    # Build summary panel
    lines = [
        f"[bold]Projeto:[/bold] {project_info.get('project_name', project_path.name)}",
        f"[bold]Fase:[/bold] {project_info.get('phase', 'não definida')}",
        "",
        f"[green]✓[/green] Claude Code {claude_version}",
        f"[green]✓[/green] Hooks configurados",
        f"[green]✓[/green] {command_count} slash commands disponíveis",
        "",
        "[dim]Iniciando Claude Code...[/dim]",
    ]

    console.print(Panel(
        "\n".join(lines),
        title=f"[bold cyan]codrsync v{__version__}[/bold cyan] - Superego Ativo",
        border_style="cyan"
    ))
