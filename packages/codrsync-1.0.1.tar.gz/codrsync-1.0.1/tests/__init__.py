# codrsync CLI tests
