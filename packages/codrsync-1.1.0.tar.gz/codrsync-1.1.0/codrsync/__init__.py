"""
codrsync - Your AI's AI

Context engineering that makes Claude, GPT & Gemini 10x smarter.
AI-powered development orchestrator with guided development,
interactive validation, and persistent context.
"""

__version__ = "1.1.0"
__author__ = "Ciro Arendt"
