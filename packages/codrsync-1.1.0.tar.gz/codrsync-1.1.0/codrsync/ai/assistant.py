"""
AI-powered onboarding assistant for CLI.

Provides interactive help for:
- Installation troubleshooting
- Anthropic account creation
- Environment configuration
- Basic codrsync commands
"""

import os
import sys
import platform
import uuid
import json
from typing import Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich import box

console = Console()

# API endpoint
API_URL = os.getenv("CODRSYNC_ONBOARDING_API", "https://codrsync.dev/api/onboarding/assist")

# Session limit
MAX_MESSAGES = 10


def get_system_info() -> dict:
    """Collect system information for context."""
    system = platform.system().lower()
    if system == "darwin":
        os_name = "macos"
    elif system == "linux":
        os_name = "linux"
    else:
        os_name = "windows"

    machine = platform.machine().lower()
    if machine in ("x86_64", "amd64"):
        arch = "x86_64"
    elif machine in ("arm64", "aarch64"):
        arch = "arm64"
    else:
        arch = machine

    # Detect installed tools
    installed = []
    tools_to_check = [
        ("python3", "python3 --version"),
        ("node", "node --version"),
        ("npm", "npm --version"),
        ("brew", "brew --version"),
        ("uv", "uv --version"),
        ("pipx", "pipx --version"),
        ("claude", "claude --version"),
        ("codrsync", "codrsync --version"),
    ]

    for tool, _ in tools_to_check:
        if os.popen(f"command -v {tool}").read().strip():
            installed.append(tool)

    return {
        "os": os_name,
        "arch": arch,
        "installed_tools": installed,
    }


def call_api(session_id: str, message: str, language: str) -> Optional[dict]:
    """Call the onboarding assist API."""
    context = get_system_info()
    context["language"] = language

    payload = json.dumps({
        "session_id": session_id,
        "message": message,
        "context": context,
    }).encode("utf-8")

    req = Request(
        API_URL,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "User-Agent": "codrsync-cli/1.0",
        },
        method="POST",
    )

    try:
        with urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as e:
        error_body = e.read().decode("utf-8")
        try:
            error_data = json.loads(error_body)
            return {"error": error_data.get("error", f"HTTP {e.code}")}
        except json.JSONDecodeError:
            return {"error": f"HTTP {e.code}"}
    except URLError as e:
        return {"error": f"Connection error: {e.reason}"}
    except Exception as e:
        return {"error": str(e)}


def display_response(response: dict, language: str) -> None:
    """Display the AI response in a formatted panel."""
    if "error" in response:
        if language == "pt":
            console.print(Panel(
                f"[red]Erro: {response['error']}[/red]",
                title="[red]Erro[/red]",
                border_style="red",
            ))
        else:
            console.print(Panel(
                f"[red]Error: {response['error']}[/red]",
                title="[red]Error[/red]",
                border_style="red",
            ))
        return

    message = response.get("message", "")
    commands = response.get("commands", [])
    remaining = response.get("remaining_messages", 0)
    provider = response.get("provider_used", "")

    # Display the message
    console.print()
    console.print(Panel(
        Markdown(message),
        title="[bold green]AI Assistant[/bold green]" if language != "pt" else "[bold green]Assistente IA[/bold green]",
        border_style="green",
        padding=(1, 2),
    ))

    # Display suggested commands
    if commands:
        if language == "pt":
            console.print("\n[bold yellow]Comandos sugeridos:[/bold yellow]")
        else:
            console.print("\n[bold yellow]Suggested commands:[/bold yellow]")

        for cmd in commands:
            console.print(f"  [cyan]$ {cmd}[/cyan]")

        # Offer to run first command
        console.print()
        if language == "pt":
            prompt = "Executar primeiro comando? [S/n]: "
        else:
            prompt = "Run first command? [Y/n]: "

        try:
            answer = input(prompt).strip().lower()
            if answer in ("", "y", "yes", "s", "sim"):
                console.print(f"\n[cyan]Running: {commands[0]}[/cyan]")
                os.system(commands[0])
        except (KeyboardInterrupt, EOFError):
            pass

    # Show remaining messages
    console.print()
    if language == "pt":
        console.print(f"[dim]Mensagens restantes: {remaining} | Provedor: {provider}[/dim]")
    else:
        console.print(f"[dim]Messages remaining: {remaining} | Provider: {provider}[/dim]")


def run_interactive(language: str = "en") -> None:
    """Run the interactive AI assistant chat."""
    session_id = str(uuid.uuid4())
    message_count = 0

    # Display header
    console.clear()

    if language == "pt":
        title = "Assistente de Instalação AI"
        subtitle = "Pergunte sobre instalação, configuração ou comandos do codrsync"
        limit_msg = f"Limite: {MAX_MESSAGES} mensagens por sessão"
        exit_hint = "Digite 'sair' ou Ctrl+C para sair"
        prompt_text = "Você"
        examples = [
            "Como criar uma conta na Anthropic?",
            "Python não encontrado",
            "Como configurar a API key?",
            "O que faz o codrsync start?",
        ]
    else:
        title = "AI Installation Assistant"
        subtitle = "Ask about installation, configuration, or codrsync commands"
        limit_msg = f"Limit: {MAX_MESSAGES} messages per session"
        exit_hint = "Type 'exit' or Ctrl+C to quit"
        prompt_text = "You"
        examples = [
            "How to create an Anthropic account?",
            "Python not found",
            "How to configure the API key?",
            "What does codrsync start do?",
        ]

    console.print(Panel(
        f"[bold]{subtitle}[/bold]\n\n"
        f"[dim]{limit_msg}[/dim]\n"
        f"[dim]{exit_hint}[/dim]\n\n"
        f"[bold]{'Exemplos' if language == 'pt' else 'Examples'}:[/bold]\n" +
        "\n".join(f"  • {ex}" for ex in examples),
        title=f"[bold cyan]{title}[/bold cyan]",
        border_style="cyan",
        padding=(1, 2),
    ))

    console.print()

    # Main chat loop
    while message_count < MAX_MESSAGES:
        try:
            # Get user input
            user_input = console.input(f"[bold blue]{prompt_text}:[/bold blue] ").strip()

            if not user_input:
                continue

            # Check for exit commands
            if user_input.lower() in ("exit", "quit", "sair", "q"):
                break

            message_count += 1

            # Show thinking indicator
            if language == "pt":
                console.print("[dim]Pensando...[/dim]")
            else:
                console.print("[dim]Thinking...[/dim]")

            # Call API
            response = call_api(session_id, user_input, language)

            if response:
                display_response(response, language)

                # Check if session limit reached
                if response.get("remaining_messages", 1) == 0:
                    if language == "pt":
                        console.print("\n[yellow]Limite de mensagens atingido. Inicie uma nova sessão se precisar de mais ajuda.[/yellow]")
                    else:
                        console.print("\n[yellow]Message limit reached. Start a new session if you need more help.[/yellow]")
                    break
            else:
                if language == "pt":
                    console.print("[red]Erro ao conectar com o assistente.[/red]")
                else:
                    console.print("[red]Error connecting to assistant.[/red]")

        except KeyboardInterrupt:
            console.print("\n")
            break
        except EOFError:
            break

    # Farewell message
    console.print()
    if language == "pt":
        console.print("[bold green]Até mais! Execute 'codrsync doctor' para verificar sua instalação.[/bold green]")
    else:
        console.print("[bold green]Goodbye! Run 'codrsync doctor' to check your installation.[/bold green]")
    console.print()


def ask_single_question(question: str, language: str = "en") -> Optional[str]:
    """Ask a single question and return the response message."""
    session_id = str(uuid.uuid4())
    response = call_api(session_id, question, language)

    if response and "message" in response:
        return response["message"]
    return None


def help_setup_api_key(language: str = "en") -> bool:
    """
    Help user set up an API key with AI assistance.

    Shows options:
    1. Get AI help to create Anthropic account
    2. Configure manually
    3. Cancel

    Returns:
        True if user configured the key, False otherwise
    """
    from codrsync.config import get_config
    import questionary

    # Translations
    if language == "pt":
        title = "Configuração Necessária"
        no_backend = "Nenhum backend de IA detectado."
        need_key = "O codrsync init precisa de uma API key para funcionar."
        options_title = "Como você gostaria de prosseguir?"
        choice_ai = "Preciso de ajuda para criar conta (AI Assistant)"
        choice_manual = "Já tenho a key, vou digitar"
        choice_skip = "Cancelar"
        requires_ai = "O comando init requer um backend de IA configurado."
        ai_question = "Como criar uma conta na Anthropic e obter uma API key?"
        enter_key_title = "Configurar API Key"
        enter_key_desc = "Para obter sua API key da Anthropic:"
        step_go = "Acesse"
        step_create = "Crie sua conta (ou faça login)"
        step_settings = "Vá em Settings → API Keys"
        step_key = "Clique em 'Create Key' e copie"
        step_paste = "Cole abaixo"
        enter_prompt = "Cole sua API key aqui"
        no_key = "Nenhuma key fornecida."
        invalid_format = "Formato inválido. A key deve começar com 'sk-ant-'."
        try_again = "Tentar novamente?"
        key_saved = "API key salva com sucesso!"
        key_tip = "Dica: Você também pode definir ANTHROPIC_API_KEY no seu ambiente"
    else:
        title = "Setup Required"
        no_backend = "No AI backend detected."
        need_key = "codrsync init requires an API key to function."
        options_title = "How would you like to proceed?"
        choice_ai = "I need help creating an account (AI Assistant)"
        choice_manual = "I already have a key, let me enter it"
        choice_skip = "Cancel"
        requires_ai = "The init command requires an AI backend configured."
        ai_question = "How to create an Anthropic account and get an API key?"
        enter_key_title = "Configure API Key"
        enter_key_desc = "To get your Anthropic API key:"
        step_go = "Go to"
        step_create = "Create your account (or log in)"
        step_settings = "Go to Settings → API Keys"
        step_key = "Click 'Create Key' and copy it"
        step_paste = "Paste below"
        enter_prompt = "Paste your API key here"
        no_key = "No key provided."
        invalid_format = "Invalid format. The key should start with 'sk-ant-'."
        try_again = "Try again?"
        key_saved = "API key saved successfully!"
        key_tip = "Tip: You can also set ANTHROPIC_API_KEY in your environment"

    # Show setup panel
    console.print()
    console.print(Panel(
        f"[yellow]{no_backend}[/yellow]\n\n"
        f"{need_key}",
        title=f"[yellow]{title}[/yellow]",
        border_style="yellow",
    ))

    # Ask how to proceed
    choice = questionary.select(
        options_title,
        choices=[
            {"name": f"🤖 {choice_ai}", "value": "ai"},
            {"name": f"⌨️  {choice_manual}", "value": "manual"},
            {"name": f"❌ {choice_skip}", "value": "skip"},
        ]
    ).ask()

    if choice == "skip" or choice is None:
        console.print(f"\n[yellow]{requires_ai}[/yellow]")
        return False

    if choice == "ai":
        # Start interactive AI help for creating Anthropic account
        console.print()
        console.print(f"[dim]{'Conectando ao assistente...' if language == 'pt' else 'Connecting to assistant...'}[/dim]")

        session_id = str(uuid.uuid4())
        response = call_api(session_id, ai_question, language)

        if response and "message" in response:
            display_response(response, language)

            # Mini interactive loop for follow-up questions
            while True:
                console.print()
                next_action = questionary.select(
                    "→" if language == "pt" else "→",
                    choices=[
                        {"name": "✅ " + ("Entendi, vou digitar a key" if language == "pt" else "Got it, let me enter the key"), "value": "done"},
                        {"name": "❓ " + ("Tenho outra dúvida" if language == "pt" else "I have another question"), "value": "question"},
                        {"name": "❌ " + ("Cancelar" if language == "pt" else "Cancel"), "value": "cancel"},
                    ]
                ).ask()

                if next_action == "done":
                    break
                elif next_action == "cancel" or next_action is None:
                    return False
                elif next_action == "question":
                    question = console.input(f"[bold blue]{'Você' if language == 'pt' else 'You'}:[/bold blue] ").strip()
                    if question:
                        console.print(f"[dim]{'Pensando...' if language == 'pt' else 'Thinking...'}[/dim]")
                        response = call_api(session_id, question, language)
                        if response:
                            display_response(response, language)
        else:
            console.print(f"[yellow]{'Não foi possível conectar ao assistente. Continuando manualmente...' if language == 'pt' else 'Could not connect to assistant. Continuing manually...'}[/yellow]")

    # Show manual entry panel
    console.print()
    console.print(Panel(
        f"[bold]{enter_key_desc}[/bold]\n\n"
        f"  1. {step_go} [link=https://console.anthropic.com/]console.anthropic.com[/link]\n"
        f"  2. {step_create}\n"
        f"  3. {step_settings}\n"
        f"  4. {step_key}\n"
        f"  5. {step_paste}",
        title=f"[cyan]{enter_key_title}[/cyan]",
        border_style="cyan",
    ))

    # Get API key
    api_key = questionary.password(enter_prompt).ask()

    if not api_key:
        console.print(f"\n[yellow]{no_key}[/yellow]")
        return False

    # Validate key format
    if not api_key.startswith("sk-ant-"):
        console.print(f"\n[yellow]{invalid_format}[/yellow]")
        retry = questionary.confirm(try_again, default=True).ask()
        if retry:
            return help_setup_api_key(language)
        return False

    # Save the key
    config = get_config()
    config.anthropic_api_key = api_key
    config.ai_backend = "anthropic-api"
    config.save()

    # Also set environment variable for current session
    os.environ["ANTHROPIC_API_KEY"] = api_key

    console.print(f"\n[green]✓[/green] {key_saved}")
    console.print(f"[dim]{key_tip}[/dim]")

    return True
