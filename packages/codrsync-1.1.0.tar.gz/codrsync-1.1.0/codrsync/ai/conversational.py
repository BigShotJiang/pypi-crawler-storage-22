"""
Conversational Onboarding - AI-driven project setup.

Provides a natural conversation experience for project initialization,
especially designed for beginners who don't know technical terms.
"""

import json
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple, List, Dict, Any

from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.prompt import Prompt
from rich import box

from codrsync.auth import AIBackend, get_ai_backend, detect_claude_code, detect_anthropic_api, detect_openai_api, detect_codrsync_credits
from codrsync.config import get_config

console = Console()


# =============================================================================
# SYSTEM PROMPTS
# =============================================================================

ONBOARDING_SYSTEM_PROMPT = """You are codrsync, a friendly AI development mentor helping someone create their first project.

YOUR PERSONALITY:
- Warm, encouraging, patient
- Use simple language (no jargon for beginners)
- Celebrate small wins
- Guide step by step

CURRENT PHASE: {phase}
USER LEVEL: {level}
LANGUAGE: {language}

CONVERSATION CONTEXT:
{context}

RESPONSE FORMAT:
You must respond in valid JSON with this structure:
{{
    "message": "Your friendly message to the user",
    "action": "continue|ask_name|ask_experience|ask_project|confirm_project|done",
    "data": {{
        // Any extracted data like name, project_name, description, etc.
    }},
    "suggestions": ["optional", "quick", "replies"]
}}

RULES:
1. Keep messages SHORT (2-3 sentences max)
2. Ask ONE question at a time
3. For beginners: NEVER mention tech terms like "stack", "framework", "API"
4. For beginners: YOU decide the tech stack based on their description
5. Always be encouraging
6. Use emojis sparingly but warmly
7. Respond in the same language the user writes in

PHASE GUIDELINES:

ask_name:
- Just ask their name warmly

ask_experience:
- Ask if they've programmed before
- Accept any answer: "yes", "no", "a little", "beginner", etc.
- Classify into: beginner, intermediate, advanced

ask_project:
- Ask what they want to build
- Let them describe in their own words
- Don't ask about tech - understand their GOAL

confirm_project:
- Summarize what you understood
- For beginners: explain in simple terms what you'll create
- For advanced: can mention tech choices
- Ask for confirmation

done:
- Project is ready to be created
- Include all extracted data in the "data" field
"""

BEGINNER_TECH_PROMPT = """Based on this project description, choose the best tech stack for a BEGINNER.
Prioritize: simplicity, good documentation, large community.

Project: {description}

Respond in JSON:
{{
    "project_name": "suggested-slug-name",
    "project_type": "webapp|api|mobile|bot|cli",
    "tech_stack": {{
        "frontend": "choice or None",
        "backend": "choice",
        "database": "choice",
        "extras": []
    }},
    "simple_explanation": "2 sentences explaining what this means for a beginner"
}}
"""


# =============================================================================
# AI BACKEND SELECTION
# =============================================================================

def detect_available_backends() -> Dict[str, bool]:
    """Detect all available AI backends."""
    return {
        "claude_code": detect_claude_code(),
        "anthropic_api": detect_anthropic_api(),
        "openai_api": detect_openai_api(),
        "codrsync_credits": detect_codrsync_credits(),
    }


def select_ai_backend(language: str = "pt") -> Tuple[Optional[str], Optional[str]]:
    """
    Let user select which AI backend to use.

    Returns:
        Tuple of (backend_type, api_key or None)
    """
    available = detect_available_backends()
    has_any = any(available.values())

    # Translations
    if language == "pt":
        title = "Assistente Inteligente"
        subtitle = "Para uma experiencia personalizada, escolha como usar a IA:"
        opt_claude = "Usar Claude Code (detectado!)"
        opt_anthropic = "Usar minha chave Anthropic"
        opt_openai = "Usar minha chave OpenAI"
        opt_credits = "Comprar creditos codrsync"
        opt_basic = "Continuar sem IA (experiencia basica)"
        detected = "detectado"
        not_detected = "configurar"
        coming_soon = "(em breve)"
    else:
        title = "Smart Assistant"
        subtitle = "For a personalized experience, choose how to use AI:"
        opt_claude = "Use Claude Code (detected!)"
        opt_anthropic = "Use my Anthropic key"
        opt_openai = "Use my OpenAI key"
        opt_credits = "Buy codrsync credits"
        opt_basic = "Continue without AI (basic experience)"
        detected = "detected"
        not_detected = "configure"
        coming_soon = "(coming soon)"

    # Build options
    options = []

    if available["claude_code"]:
        options.append(("claude_code", f"[green]1.[/green] {opt_claude}"))

    if available["anthropic_api"]:
        options.append(("anthropic_api", f"[green]2.[/green] {opt_anthropic} [{detected}]"))
    else:
        options.append(("anthropic_api_setup", f"[yellow]2.[/yellow] {opt_anthropic} [{not_detected}]"))

    if available["openai_api"]:
        options.append(("openai_api", f"[green]3.[/green] {opt_openai} [{detected}]"))
    else:
        options.append(("openai_api_setup", f"[yellow]3.[/yellow] {opt_openai} [{not_detected}]"))

    if available["codrsync_credits"]:
        options.append(("codrsync_credits", f"[green]4.[/green] {opt_credits} [✓ authenticated]"))
    else:
        options.append(("codrsync_credits_setup", f"[cyan]4.[/cyan] {opt_credits} [10 free!]"))
    options.append(("basic", f"[dim]5.[/dim] {opt_basic}"))

    # Show panel
    console.print()
    console.print(Panel(
        f"[bold]{subtitle}[/bold]\n\n" +
        "\n".join([opt[1] for opt in options]),
        title=f"[cyan]{title}[/cyan]",
        border_style="cyan",
    ))

    # Get choice
    while True:
        choice = Prompt.ask("\n[bold]Escolha[/bold]", default="1" if available["claude_code"] else "5")

        try:
            idx = int(choice) - 1
            if 0 <= idx < len(options):
                selected = options[idx][0]
                break
        except ValueError:
            pass

        console.print("[yellow]Opcao invalida[/yellow]")

    # Handle selection
    if selected == "claude_code":
        return ("claude_code", None)

    elif selected == "anthropic_api":
        return ("anthropic_api", os.getenv("ANTHROPIC_API_KEY") or get_config().anthropic_api_key)

    elif selected == "anthropic_api_setup":
        key = setup_api_key("anthropic", language)
        if key:
            return ("anthropic_api", key)
        return select_ai_backend(language)  # Retry

    elif selected == "openai_api":
        return ("openai_api", os.getenv("OPENAI_API_KEY") or get_config().openai_api_key)

    elif selected == "openai_api_setup":
        key = setup_api_key("openai", language)
        if key:
            return ("openai_api", key)
        return select_ai_backend(language)  # Retry

    elif selected == "codrsync_credits":
        return ("codrsync_credits", get_config().codrsync_device_token)

    elif selected == "codrsync_credits_setup":
        # Run device code auth flow
        from codrsync.device_auth import device_code_login
        config = get_config()
        if device_code_login(config):
            return ("codrsync_credits", config.codrsync_device_token)
        return select_ai_backend(language)  # Retry

    else:  # basic
        return ("basic", None)


def setup_api_key(provider: str, language: str) -> Optional[str]:
    """Guide user to set up an API key."""
    if language == "pt":
        if provider == "anthropic":
            console.print(Panel(
                "[bold]Para obter sua chave Anthropic:[/bold]\n\n"
                "1. Acesse [link=https://console.anthropic.com/]console.anthropic.com[/link]\n"
                "2. Crie uma conta ou faca login\n"
                "3. Va em Settings -> API Keys\n"
                "4. Clique em 'Create Key'\n"
                "5. Copie e cole abaixo",
                title="[cyan]Configurar Anthropic[/cyan]",
                border_style="cyan",
            ))
        else:
            console.print(Panel(
                "[bold]Para obter sua chave OpenAI:[/bold]\n\n"
                "1. Acesse [link=https://platform.openai.com/api-keys]platform.openai.com/api-keys[/link]\n"
                "2. Crie uma conta ou faca login\n"
                "3. Clique em 'Create new secret key'\n"
                "4. Copie e cole abaixo",
                title="[cyan]Configurar OpenAI[/cyan]",
                border_style="cyan",
            ))
        prompt = "Cole sua chave aqui (ou Enter para voltar)"
    else:
        if provider == "anthropic":
            console.print(Panel(
                "[bold]To get your Anthropic key:[/bold]\n\n"
                "1. Go to [link=https://console.anthropic.com/]console.anthropic.com[/link]\n"
                "2. Create account or log in\n"
                "3. Go to Settings -> API Keys\n"
                "4. Click 'Create Key'\n"
                "5. Copy and paste below",
                title="[cyan]Configure Anthropic[/cyan]",
                border_style="cyan",
            ))
        else:
            console.print(Panel(
                "[bold]To get your OpenAI key:[/bold]\n\n"
                "1. Go to [link=https://platform.openai.com/api-keys]platform.openai.com/api-keys[/link]\n"
                "2. Create account or log in\n"
                "3. Click 'Create new secret key'\n"
                "4. Copy and paste below",
                title="[cyan]Configure OpenAI[/cyan]",
                border_style="cyan",
            ))
        prompt = "Paste your key here (or Enter to go back)"

    key = Prompt.ask(f"\n{prompt}", password=True, default="")

    if not key:
        return None

    # Validate format
    if provider == "anthropic" and not key.startswith("sk-ant-"):
        console.print("[yellow]Chave invalida. Deve comecar com 'sk-ant-'[/yellow]")
        return None

    if provider == "openai" and not key.startswith("sk-"):
        console.print("[yellow]Chave invalida. Deve comecar com 'sk-'[/yellow]")
        return None

    # Save key
    config = get_config()
    if provider == "anthropic":
        config.anthropic_api_key = key
        os.environ["ANTHROPIC_API_KEY"] = key
    else:
        config.openai_api_key = key
        os.environ["OPENAI_API_KEY"] = key
    config.save()

    console.print("[green]Chave salva com sucesso![/green]")
    return key


# =============================================================================
# AI CONVERSATION ENGINE
# =============================================================================

class ConversationEngine:
    """Manages the AI-driven conversation flow."""

    def __init__(
        self,
        backend_type: str,
        api_key: Optional[str] = None,
        language: str = "pt",
        project_context: Optional[Dict[str, Any]] = None,
    ):
        self.backend_type = backend_type
        self.api_key = api_key
        self.language = language
        self.project_context = project_context
        self.context: List[Dict[str, str]] = []
        self.user_data = {
            "name": None,
            "level": None,
            "project_name": None,
            "project_description": None,
            "project_type": None,
            "tech_stack": None,
        }
        self.phase = "ask_name"

        # Pre-populate from project context if available
        if project_context:
            if project_context.get('project_name'):
                self.user_data['project_name'] = project_context['project_name']
            stack = project_context.get('stack', {})
            if stack.get('languages') or stack.get('frameworks'):
                self.user_data['tech_stack'] = stack

    def chat(self, user_message: str) -> Dict[str, Any]:
        """Send a message and get AI response."""
        self.context.append({"role": "user", "content": user_message})

        if self.backend_type == "basic":
            return self._basic_flow(user_message)

        try:
            response = self._call_ai(user_message)
            self.context.append({"role": "assistant", "content": response.get("message", "")})

            # Update user data from response
            if response.get("data"):
                for key, value in response["data"].items():
                    if key in self.user_data and value:
                        self.user_data[key] = value

            # Update phase
            if response.get("action"):
                self.phase = response["action"]

            return response

        except Exception as e:
            console.print(f"[dim]AI error: {e}[/dim]")
            return self._basic_flow(user_message)

    def _call_ai(self, user_message: str) -> Dict[str, Any]:
        """Call the AI backend."""
        system_prompt = ONBOARDING_SYSTEM_PROMPT.format(
            phase=self.phase,
            level=self.user_data.get("level", "unknown"),
            language=self.language,
            context=json.dumps(self.user_data, indent=2),
        )

        if self.backend_type == "claude_code":
            return self._call_claude_code(system_prompt, user_message)
        elif self.backend_type == "anthropic_api":
            return self._call_anthropic(system_prompt, user_message)
        elif self.backend_type == "openai_api":
            return self._call_openai(system_prompt, user_message)
        elif self.backend_type == "codrsync_credits":
            return self._call_codrsync_credits(system_prompt, user_message)
        else:
            return self._basic_flow(user_message)

    def _call_claude_code(self, system_prompt: str, user_message: str) -> Dict[str, Any]:
        """Call Claude Code CLI."""
        import subprocess
        import tempfile

        full_prompt = f"{system_prompt}\n\nUser: {user_message}\n\nRespond in JSON only:"

        try:
            result = subprocess.run(
                ["claude", "-p", full_prompt, "--output-format", "text"],
                capture_output=True,
                text=True,
                timeout=60,
            )

            output = result.stdout.strip()

            # Try to parse JSON from output
            # Claude might wrap it in markdown code blocks
            if "```json" in output:
                output = output.split("```json")[1].split("```")[0]
            elif "```" in output:
                output = output.split("```")[1].split("```")[0]

            return json.loads(output)

        except subprocess.TimeoutExpired:
            return {"message": "Timeout - tente novamente", "action": self.phase}
        except json.JSONDecodeError:
            # If we can't parse JSON, treat as plain message
            return {"message": result.stdout.strip() if result else "Erro", "action": self.phase}
        except Exception as e:
            return {"message": f"Erro: {e}", "action": self.phase}

    def _call_anthropic(self, system_prompt: str, user_message: str) -> Dict[str, Any]:
        """Call Anthropic API directly."""
        import urllib.request

        messages = [{"role": "user", "content": user_message}]

        payload = json.dumps({
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 1024,
            "system": system_prompt,
            "messages": messages,
        }).encode("utf-8")

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
            },
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=60) as response:
            result = json.loads(response.read().decode("utf-8"))
            content = result["content"][0]["text"]

            # Parse JSON from response
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]

            return json.loads(content)

    def _call_openai(self, system_prompt: str, user_message: str) -> Dict[str, Any]:
        """Call OpenAI API directly."""
        import urllib.request

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ]

        payload = json.dumps({
            "model": "gpt-4o-mini",
            "messages": messages,
            "max_tokens": 1024,
            "response_format": {"type": "json_object"},
        }).encode("utf-8")

        req = urllib.request.Request(
            "https://api.openai.com/v1/chat/completions",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=60) as response:
            result = json.loads(response.read().decode("utf-8"))
            content = result["choices"][0]["message"]["content"]
            return json.loads(content)

    def _call_codrsync_credits(self, system_prompt: str, user_message: str) -> Dict[str, Any]:
        """Call codrsync.dev AI API using credits."""
        from codrsync.device_auth import call_credits_ai
        from codrsync.config import get_config

        config = get_config()

        messages = [{"role": "user", "content": f"{system_prompt}\n\nUser: {user_message}\n\nRespond in JSON only:"}]

        result = call_credits_ai(
            config=config,
            feature="init",
            messages=messages,
            model="claude-sonnet",
        )

        if not result:
            # Fallback to basic flow if API call fails
            return self._basic_flow(user_message)

        content = result.get("response", "")

        # Parse JSON from response
        try:
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]

            return json.loads(content)
        except json.JSONDecodeError:
            return {"message": content, "action": self.phase}

    def _basic_flow(self, user_message: str) -> Dict[str, Any]:
        """Fallback basic flow without AI."""
        if self.language == "pt":
            if self.phase == "ask_name":
                self.user_data["name"] = user_message.strip()
                self.phase = "ask_experience"
                return {
                    "message": f"Prazer, {self.user_data['name']}! Voce ja programou antes?",
                    "action": "ask_experience",
                    "suggestions": ["Sim", "Nao", "Um pouco"],
                }

            elif self.phase == "ask_experience":
                msg_lower = user_message.lower()
                if any(x in msg_lower for x in ["nao", "nunca", "no", "iniciante", "comecando"]):
                    self.user_data["level"] = "beginner"
                elif any(x in msg_lower for x in ["sim", "yes", "muito", "avancado", "senior"]):
                    self.user_data["level"] = "advanced"
                else:
                    self.user_data["level"] = "intermediate"

                self.phase = "ask_project"
                return {
                    "message": "Legal! Me conta: o que voce quer construir? Descreva com suas palavras.",
                    "action": "ask_project",
                }

            elif self.phase == "ask_project":
                self.user_data["project_description"] = user_message
                self.user_data["project_name"] = self._generate_slug(user_message)
                self.user_data["project_type"] = "webapp"
                self.user_data["tech_stack"] = {
                    "frontend": "Next.js",
                    "backend": "Python + FastAPI",
                    "database": "SQLite",
                    "extras": [],
                }

                self.phase = "confirm_project"

                if self.user_data["level"] == "beginner":
                    return {
                        "message": f"Entendi! Vou criar um app web para: {user_message}\n\nIsso vai funcionar no navegador do celular e computador. Posso criar?",
                        "action": "confirm_project",
                        "suggestions": ["Sim!", "Quero mudar algo"],
                    }
                else:
                    return {
                        "message": f"Projeto: {user_message}\n\nTech: Next.js + FastAPI + SQLite\n\nConfirma?",
                        "action": "confirm_project",
                        "suggestions": ["Sim", "Mudar tech"],
                    }

            elif self.phase == "confirm_project":
                if any(x in user_message.lower() for x in ["sim", "yes", "ok", "confirma", "pode", "vai"]):
                    self.phase = "done"
                    return {
                        "message": "Perfeito! Criando seu projeto...",
                        "action": "done",
                        "data": self.user_data,
                    }
                else:
                    self.phase = "ask_project"
                    return {
                        "message": "Ok! Me conta de novo o que voce quer fazer:",
                        "action": "ask_project",
                    }
        else:
            # English fallback
            if self.phase == "ask_name":
                self.user_data["name"] = user_message.strip()
                self.phase = "ask_experience"
                return {
                    "message": f"Nice to meet you, {self.user_data['name']}! Have you programmed before?",
                    "action": "ask_experience",
                    "suggestions": ["Yes", "No", "A little"],
                }
            # ... similar flow in English

        return {"message": "...", "action": self.phase}

    def _generate_slug(self, description: str) -> str:
        """Generate a project slug from description."""
        import re
        # Take first few words
        words = description.lower().split()[:3]
        slug = "-".join(words)
        # Clean up
        slug = re.sub(r"[^a-z0-9-]", "", slug)
        return slug or "meu-projeto"


# =============================================================================
# MAIN CONVERSATIONAL FLOW
# =============================================================================

def run_conversational_init(
    project_path: Optional[Path] = None,
    scan_result: Optional[Any] = None,
    language: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """
    Run the conversational project initialization.

    This is the --local mode handler that uses local AI (BYOK) instead of
    the cloud concierge.

    Args:
        project_path: Path to the project directory
        scan_result: Quick scan result from envrsync
        language: Language preference ('pt' or 'en')

    Returns:
        Project data dict if successful, None if cancelled
    """
    # Detect language from system or config
    config = get_config()
    if language is None:
        language = "pt" if config.language == "pt" else "en"

    # Use project context from scan if available
    project_context = None
    if scan_result:
        project_context = scan_result.to_dict() if hasattr(scan_result, 'to_dict') else scan_result

    # Welcome message with project context if available
    if project_context and not project_context.get('is_empty', True):
        stack_summary = project_context.get('stack', {})
        languages = stack_summary.get('languages', [])
        frameworks = stack_summary.get('frameworks', [])
        stack_str = ' + '.join(languages[:2] + frameworks[:2]) if (languages or frameworks) else 'seu projeto'

        if language == "pt":
            welcome = (
                f"Oi! Eu sou o [bold cyan]codrsync[/bold cyan], seu assistente de desenvolvimento.\n\n"
                f"Vi que voce tem um projeto [cyan]{stack_str}[/cyan].\n"
                "Vou te ajudar a configurar com a metodologia Context Engineering."
            )
            first_question = "Qual e o seu nome?"
        else:
            welcome = (
                f"Hi! I'm [bold cyan]codrsync[/bold cyan], your development assistant.\n\n"
                f"I see you have a [cyan]{stack_str}[/cyan] project.\n"
                "I'll help you configure it with the Context Engineering methodology."
            )
            first_question = "What's your name?"
    else:
        if language == "pt":
            welcome = (
                "Oi! Eu sou o [bold cyan]codrsync[/bold cyan], seu assistente de desenvolvimento.\n\n"
                "Vou te ajudar a criar seu projeto do zero, passo a passo."
            )
            first_question = "Primeiro, qual e o seu nome?"
        else:
            welcome = (
                "Hi! I'm [bold cyan]codrsync[/bold cyan], your development assistant.\n\n"
                "I'll help you create your project from scratch, step by step."
            )
            first_question = "First, what's your name?"

    console.print()
    console.print(Panel(
        welcome,
        title="[bold green]Bem-vindo![/bold green]" if language == "pt" else "[bold green]Welcome![/bold green]",
        border_style="green",
    ))

    # Select AI backend
    backend_type, api_key = select_ai_backend(language)

    if backend_type == "basic":
        console.print(f"\n[dim]{'Modo basico - experiencia simplificada' if language == 'pt' else 'Basic mode - simplified experience'}[/dim]")
    else:
        console.print(f"\n[green]{'Assistente inteligente ativado!' if language == 'pt' else 'Smart assistant activated!'}[/green]")

    # Initialize conversation engine with project context
    engine = ConversationEngine(
        backend_type=backend_type,
        api_key=api_key,
        language=language,
        project_context=project_context,
    )

    # Start conversation
    console.print()
    console.print(f"[bold cyan]codrsync:[/bold cyan] {first_question}")

    # Conversation loop
    while engine.phase != "done":
        # Get user input
        console.print()
        user_input = Prompt.ask("[bold blue]Voce[/bold blue]" if language == "pt" else "[bold blue]You[/bold blue]")

        if not user_input or user_input.lower() in ["sair", "exit", "quit", "q"]:
            console.print(f"\n[yellow]{'Ate mais!' if language == 'pt' else 'Goodbye!'}[/yellow]")
            return None

        # Get AI response
        console.print(f"\n[dim]{'Pensando...' if language == 'pt' else 'Thinking...'}[/dim]")
        response = engine.chat(user_input)

        # Show response
        console.print()
        message = response.get("message", "...")
        console.print(f"[bold cyan]codrsync:[/bold cyan] {message}")

        # Show suggestions if available
        suggestions = response.get("suggestions", [])
        if suggestions:
            console.print(f"[dim]  Sugestoes: {' | '.join(suggestions)}[/dim]")

    # Create project structure from collected data
    if engine.user_data:
        if language == "pt":
            console.print("\n[dim]Criando estrutura do projeto...[/dim]")
        else:
            console.print("\n[dim]Creating project structure...[/dim]")

        success = create_project_from_conversation(engine.user_data)

        if success:
            if language == "pt":
                console.print(Panel(
                    "[bold green]Projeto configurado![/bold green]\n\n"
                    "Arquivos criados:\n"
                    "  [cyan]CLAUDE.md[/cyan] - Instrucoes para o assistente\n"
                    "  [cyan]doc/project/manifest.json[/cyan] - Metadados do projeto\n\n"
                    "Proximos passos:\n"
                    "  [cyan]codrsync start[/cyan] - Continuar desenvolvendo",
                    border_style="green",
                ))
            else:
                console.print(Panel(
                    "[bold green]Project configured![/bold green]\n\n"
                    "Files created:\n"
                    "  [cyan]CLAUDE.md[/cyan] - Instructions for the assistant\n"
                    "  [cyan]doc/project/manifest.json[/cyan] - Project metadata\n\n"
                    "Next steps:\n"
                    "  [cyan]codrsync start[/cyan] - Continue developing",
                    border_style="green",
                ))

    return engine.user_data


def create_project_from_conversation(data: Dict[str, Any]) -> bool:
    """Create the project structure from conversation data."""
    from codrsync.ai.kickstart import create_project_structure

    project_name = data.get("project_name", "meu-projeto")
    project_description = data.get("project_description", "")
    project_type = data.get("project_type", "webapp")
    tech_stack = data.get("tech_stack", {
        "frontend": "Next.js",
        "backend": "Python + FastAPI",
        "database": "SQLite",
        "extras": [],
    })
    dev_name = data.get("name", "Developer")
    dev_level = data.get("level", "beginner")

    try:
        create_project_structure(
            project_name=project_name,
            project_description=project_description,
            project_type=project_type,
            tech_stack=tech_stack,
            dev_name=dev_name,
            dev_level=dev_level,
        )
        return True
    except Exception as e:
        console.print(f"[red]Erro ao criar projeto: {e}[/red]")
        return False
