"""
codrsync CLI - Main entry point

Commands:
  Local (no AI needed):
    - status: Show project dashboard
    - roadmap: Show timeline and dependencies
    - export: Export to Excel/Jira/Trello/Notion
    - sprint: Manage sprints
    - scan: Detect project stack, docs, and GitHub info
    - connect: Check integration status for external services

  AI-powered (uses Claude Code or API):
    - init: Initialize new project (kickstart wizard)
    - build: Execute development with AI guidance
    - prp: Generate or execute PRPs
"""

import typer
from pathlib import Path
from rich.console import Console
from rich.panel import Panel

from codrsync import __version__
from codrsync.config import get_config, Config, is_first_run
from codrsync.auth import get_ai_backend, AIBackend
from codrsync.i18n import lazy_t, t

# Sub-modules
from codrsync.local import status as status_module
from codrsync.local import roadmap as roadmap_module
from codrsync.local import export as export_module
from codrsync.local import sprint as sprint_module
from codrsync.ai import kickstart as kickstart_module
from codrsync.scanner import scan as scan_module
from codrsync.connect import connect as connect_module

app = typer.Typer(
    name="codrsync",
    help=lazy_t("cli.app.help"),
    add_completion=False,
    rich_markup_mode="rich",
)

console = Console()


def version_callback(value: bool):
    if value:
        console.print(t("cli.version.show", version=__version__))
        raise typer.Exit()


def help_ai_callback(value: bool):
    """Launch interactive AI assistant for onboarding help."""
    if value:
        from codrsync.ai.assistant import run_interactive
        from codrsync.config import Config

        # Get language from config
        try:
            cfg = Config.load()
            lang = cfg.language or "en"
        except Exception:
            lang = "en"

        # Map to supported languages
        if lang.startswith("pt"):
            lang = "pt"
        else:
            lang = "en"

        run_interactive(language=lang)
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        None, "--version", "-v", callback=version_callback, is_eager=True,
        help=lazy_t("cli.version.help")
    ),
    help_ai: bool = typer.Option(
        None, "--help-ai", callback=help_ai_callback, is_eager=True,
        help="Launch interactive AI assistant for installation help"
    ),
):
    """
    [bold cyan]codrsync[/bold cyan] - Your AI's AI

    Context engineering that makes Claude, GPT & Gemini 10x smarter.
    AI-powered development orchestrator with guided development,
    interactive validation, and persistent context.
    """
    # If no command provided (just `codrsync`)
    if ctx.invoked_subcommand is None:
        if is_first_run():
            # First time: show full onboarding
            from codrsync.onboarding import run_onboarding
            run_onboarding()
        else:
            # Already configured: show welcome back message
            from codrsync.onboarding import show_welcome_back
            show_welcome_back()
        return

    # If a command is provided and it's first run, show onboarding first
    if is_first_run():
        from codrsync.onboarding import run_onboarding
        run_onboarding()


# =============================================================================
# LOCAL COMMANDS (No AI needed)
# =============================================================================

@app.command(help=lazy_t("cli.status.help"), rich_help_panel=lazy_t("cli.panel.local"))
def status(
    mini: bool = typer.Option(False, "--mini", "-m", help=lazy_t("cli.status.mini_help")),
    prp: str = typer.Option(None, "--prp", "-p", help=lazy_t("cli.status.prp_help")),
    executive: bool = typer.Option(False, "--executive", "-e", help=lazy_t("cli.status.executive_help")),
):
    status_module.run(mini=mini, prp=prp, executive=executive)


@app.command(help=lazy_t("cli.roadmap.help"), rich_help_panel=lazy_t("cli.panel.local"))
def roadmap(
    current: bool = typer.Option(False, "--current", "-c", help=lazy_t("cli.roadmap.current_help")),
    epics: bool = typer.Option(False, "--epics", "-e", help=lazy_t("cli.roadmap.epics_help")),
    mermaid: bool = typer.Option(False, "--mermaid", help=lazy_t("cli.roadmap.mermaid_help")),
    json_output: bool = typer.Option(False, "--json", "-j", help=lazy_t("cli.roadmap.json_help")),
):
    roadmap_module.run(current=current, epics=epics, mermaid=mermaid, json_output=json_output)


@app.command(help=lazy_t("cli.export.help"), rich_help_panel=lazy_t("cli.panel.local"))
def export(
    format: str = typer.Argument("excel", help=lazy_t("cli.export.format_help")),
    output: str = typer.Option("exports", "--output", "-o", help=lazy_t("cli.export.output_help")),
):
    export_module.run(format=format, output=output)


# Sprint subcommands
sprint_app = typer.Typer(help=lazy_t("cli.sprint.help"), rich_markup_mode="rich")
app.add_typer(sprint_app, name="sprint", rich_help_panel=lazy_t("cli.panel.local"))


@sprint_app.callback(invoke_without_command=True)
def sprint_status(ctx: typer.Context):
    """Show current sprint status (default when no subcommand)."""
    if ctx.invoked_subcommand is None:
        sprint_module.show_status()


@sprint_app.command("start")
def sprint_start(
    duration: int = typer.Option(2, "--duration", "-d", help=lazy_t("cli.sprint.duration_help")),
    goal: str = typer.Option(None, "--goal", "-g", help=lazy_t("cli.sprint.goal_help")),
):
    """Start a new sprint."""
    sprint_module.start(duration=duration, goal=goal)


@sprint_app.command("plan")
def sprint_plan():
    """Interactive sprint planning."""
    sprint_module.plan()


@sprint_app.command("review")
def sprint_review():
    """Sprint review - summarize deliveries."""
    sprint_module.review()


@sprint_app.command("retro")
def sprint_retro():
    """Sprint retrospective - capture learnings."""
    sprint_module.retro()


@sprint_app.command("close")
def sprint_close():
    """Close current sprint."""
    sprint_module.close()


@sprint_app.command("check", help=lazy_t("cli.sprint.check_help"))
def sprint_check():
    """Check stories ready for auto-completion."""
    sprint_module.check()


@sprint_app.command("time", help=lazy_t("cli.sprint.time_help"))
def sprint_time(
    story: str = typer.Argument(None, help=lazy_t("cli.sprint.time_story_help")),
):
    """Show time spent per story."""
    sprint_module.time_tracking(story_id=story)


@sprint_app.command("calibrate", help=lazy_t("cli.sprint.calibrate_help"))
def sprint_calibrate(
    export: str = typer.Option(None, "--export", "-e", help=lazy_t("cli.sprint.calibrate_export_help")),
    import_file: str = typer.Option(None, "--import", "-i", help=lazy_t("cli.sprint.calibrate_import_help")),
):
    """Show calibration RAG status and manage data."""
    sprint_module.calibrate(export_path=export, import_path=import_file)


@app.command(help=lazy_t("cli.scan.help"), rich_help_panel=lazy_t("cli.panel.local"))
def scan(
    path: str = typer.Argument(None, help=lazy_t("cli.scan.path_help")),
    github: bool = typer.Option(False, "--github", "-g", help=lazy_t("cli.scan.github_help")),
    docs: bool = typer.Option(False, "--docs", "-d", help=lazy_t("cli.scan.docs_help")),
    deep: bool = typer.Option(False, "--deep", help=lazy_t("cli.scan.deep_help")),
):
    backend = None
    if deep:
        from codrsync.ai.backend import get_backend_instance
        ai_backend = get_ai_backend()
        if ai_backend != AIBackend.OFFLINE:
            backend = get_backend_instance(ai_backend)
        else:
            console.print(f"{t('common.warning')} {t('common.ai_required_short')}")

    scan_module.run(
        path=Path(path) if path else None,
        github=github,
        docs=docs,
        deep=deep,
        backend=backend,
    )


@app.command(help=lazy_t("cli.connect.help"), rich_help_panel=lazy_t("cli.panel.local"))
def connect(
    service: str = typer.Argument(None, help=lazy_t("cli.connect.service_help")),
    path: str = typer.Argument(None, help=lazy_t("cli.connect.path_help")),
    link: bool = typer.Option(False, "--link", "-l", help="Link project to external database/project"),
    list_all: bool = typer.Option(False, "--list", help="List available integrations"),
):
    project_path = Path(path) if path else Path.cwd()

    # List available integrations
    if list_all:
        from codrsync.integrations.sync import get_sync_engine
        engine = get_sync_engine(project_path / ".codrsync")

        console.print("\n[bold]Available Integrations[/bold]\n")
        for info in engine.list_available_integrations():
            status_icon = "[green]Available[/green]" if info["status"] == "available" else "[yellow]Coming Soon[/yellow]"
            console.print(f"  {info['display_name']:15} {status_icon}")
            console.print(f"  [dim]{info['description']}[/dim]\n")

        connected = engine.list_connected_integrations()
        if connected:
            console.print("[bold]Connected Integrations[/bold]\n")
            for conn in connected:
                console.print(f"  {conn['provider']:15} {conn.get('workspace_name', '')} / {conn.get('project_name', 'Not linked')}")
        return

    # OAuth-based integrations (notion, jira, etc)
    if service in connect_module.OAUTH_PROVIDERS:
        if service == "notion":
            from codrsync.connect.notion import connect_notion, link_notion_database
            if link:
                link_notion_database(project_path)
            else:
                connect_notion(project_path)
        else:
            console.print(f"[yellow]{service.capitalize()} integration coming soon![/yellow]")
        return

    # Standard connector check
    connect_module.run(
        service=service,
        path=project_path,
    )


@app.command(help="Sync stories with external services", rich_help_panel=lazy_t("cli.panel.local"))
def sync(
    provider: str = typer.Argument(None, help="Provider to sync with (notion, jira)"),
    push: bool = typer.Option(False, "--push", "-p", help="Push local changes to external"),
    pull: bool = typer.Option(False, "--pull", help="Pull external changes to local"),
    status: bool = typer.Option(False, "--status", "-s", help="Show sync status"),
):
    """Sync stories with connected external services."""
    import asyncio
    from codrsync.integrations.sync import get_sync_engine, SyncDirection

    project_path = Path.cwd()
    codrsync_dir = project_path / ".codrsync"

    if not codrsync_dir.exists():
        console.print("[yellow]Not a codrsync project. Run 'codrsync init' first.[/yellow]")
        raise typer.Exit(1)

    engine = get_sync_engine(codrsync_dir)

    # Show status
    if status or (not provider and not push and not pull):
        connected = engine.list_connected_integrations()
        if not connected:
            console.print("[yellow]No integrations connected. Run 'codrsync connect notion' to connect.[/yellow]")
            return

        console.print("\n[bold]Sync Status[/bold]\n")
        for conn in connected:
            sync_status = engine.get_sync_status(conn["provider"])
            console.print(f"  [cyan]{conn['provider'].capitalize()}[/cyan]")
            console.print(f"    Workspace: {sync_status.get('workspace', 'N/A')}")
            console.print(f"    Project: {sync_status.get('project', 'Not linked')}")
            console.print(f"    Stories: {sync_status.get('synced_stories', 0)}/{sync_status.get('total_stories', 0)} synced")
            console.print()
        return

    # Sync with specific provider
    if not provider:
        # Sync with all connected providers
        connected = engine.list_connected_integrations()
        if not connected:
            console.print("[yellow]No integrations connected.[/yellow]")
            return

        for conn in connected:
            _run_sync(engine, conn["provider"], push, pull)
    else:
        _run_sync(engine, provider, push, pull)


def _run_sync(engine, provider: str, push: bool, pull: bool):
    """Run sync for a specific provider."""
    import asyncio
    from codrsync.integrations.sync import SyncDirection

    config = engine.get_integration_config(provider)
    if not config:
        console.print(f"[yellow]Not connected to {provider}. Run 'codrsync connect {provider}' first.[/yellow]")
        return

    console.print(f"\n[bold]Syncing with {provider.capitalize()}...[/bold]")

    # Determine direction
    if push and not pull:
        direction = SyncDirection.EXPORT
    elif pull and not push:
        direction = SyncDirection.IMPORT
    else:
        direction = config.sync_direction

    try:
        result = asyncio.run(engine.sync(provider, direction))

        if result.success:
            console.print(f"[green]Sync completed![/green]")
            if result.created:
                console.print(f"  Created: {result.created}")
            if result.updated:
                console.print(f"  Updated: {result.updated}")
            if result.skipped:
                console.print(f"  Skipped: {result.skipped}")
        else:
            console.print(f"[red]Sync failed[/red]")
            for error in result.errors:
                console.print(f"  - {error}")

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")


# =============================================================================
# AI-POWERED COMMANDS
# =============================================================================

@app.command(help=lazy_t("cli.init.help"), rich_help_panel=lazy_t("cli.panel.ai"))
def init(
    name: str = typer.Option(None, "--name", "-n", help=lazy_t("cli.init.name_help")),
    skip_research: bool = typer.Option(False, "--skip-research", help=lazy_t("cli.init.skip_research_help")),
    classic: bool = typer.Option(False, "--classic", help=lazy_t("cli.init.classic_help")),
    local: bool = typer.Option(False, "--local", "-l", help="Use local AI (BYOK) instead of cloud concierge"),
):
    """Initialize a new project with Context Engineering methodology.

    By default, uses the cloud concierge for a guided, conversational setup.
    The concierge analyzes your project and creates the configuration files.

    Modes:
      (default)   Cloud concierge - AI-guided setup with 60-min trial
      --local     Use your own API key (Anthropic/OpenAI) for local AI
      --classic   Old wizard-style setup with form questions
    """
    from codrsync.config import Config
    from codrsync.envrsync import quick_scan, format_scan_result, get_project_summary

    project_path = Path.cwd()
    cfg = Config.load()
    language = cfg.language or "pt"

    # PHASE 1: Local scan (always runs first - familiar and fast)
    if language == "pt":
        console.print("[dim]Analisando seu projeto...[/dim]")
    else:
        console.print("[dim]Analyzing your project...[/dim]")

    scan_result = quick_scan(project_path)

    # Show scan results
    console.print()
    console.print(format_scan_result(scan_result, language))
    console.print()

    # Classic mode: use old wizard
    if classic:
        backend = get_ai_backend()
        if backend == AIBackend.OFFLINE:
            console.print(Panel(
                t("common.ai_required"),
                title=t("common.ai_required_title"),
                border_style="yellow"
            ))
            raise typer.Exit(1)

        # Check for existing code → offer import
        from codrsync.scanner.detector import has_existing_code

        if has_existing_code(project_path) and not Path("doc/project/manifest.json").exists():
            console.print(Panel(
                f"{t('init.existing_detected')}\n\n{t('init.existing_description')}",
                border_style="yellow",
            ))

            import questionary
            choice = questionary.select(
                t("init.existing_detected"),
                choices=[
                    {"name": t("init.choice_import"), "value": "import"},
                    {"name": t("init.choice_fresh"), "value": "fresh"},
                ]
            ).ask()

            if choice == "import":
                console.print(f"\n  {t('init.import_scan_step')}")
                scan_result_classic = scan_module.run(
                    path=project_path, github=True, docs=True,
                )
                console.print(f"  {t('init.import_connect_step')}")
                connect_module.run(path=project_path)
                console.print(f"  {t('init.import_context_step')}")
                kickstart_module.run_from_scan(backend=backend, scan_result=scan_result_classic)
                return

        kickstart_module.run(backend=backend, name=name, skip_research=skip_research, classic=classic)
        return

    # Local mode: use conversational.py with local AI
    if local:
        backend = get_ai_backend()
        if backend == AIBackend.OFFLINE:
            console.print(Panel(
                t("common.ai_required"),
                title=t("common.ai_required_title"),
                border_style="yellow"
            ))
            raise typer.Exit(1)

        # Use conversational init with local AI
        from codrsync.ai.conversational import run_conversational_init
        run_conversational_init(
            project_path=project_path,
            scan_result=scan_result,
            language=language,
        )
        return

    # DEFAULT: Cloud concierge mode
    # Check if authenticated
    if not cfg.codrsync_device_token:
        if language == "pt":
            console.print("[dim]Conectando ao assistente AI...[/dim]")
            console.print()
            console.print("Para usar o assistente, voce precisa de uma conta.")
            console.print("E gratis e leva 30 segundos!")
            console.print()
        else:
            console.print("[dim]Connecting to AI assistant...[/dim]")
            console.print()
            console.print("To use the assistant, you need an account.")
            console.print("It's free and takes 30 seconds!")
            console.print()

        # Offer to authenticate
        import questionary
        if language == "pt":
            prompt = "Criar conta agora?"
        else:
            prompt = "Create account now?"

        if questionary.confirm(prompt, default=True).ask():
            from codrsync.device_auth import device_code_login
            if not device_code_login(cfg):
                # Auth failed, offer local fallback
                if language == "pt":
                    console.print()
                    console.print("[yellow]Autenticacao cancelada.[/yellow]")
                    console.print("Voce pode usar o modo local com sua propria API key:")
                    console.print("  [cyan]codrsync init --local[/cyan]")
                else:
                    console.print()
                    console.print("[yellow]Authentication cancelled.[/yellow]")
                    console.print("You can use local mode with your own API key:")
                    console.print("  [cyan]codrsync init --local[/cyan]")
                raise typer.Exit(1)
            # Reload config after auth
            cfg = Config.load()
        else:
            # Offer local fallback
            if language == "pt":
                console.print()
                console.print("Sem problemas! Use o modo local com sua propria API key:")
                console.print("  [cyan]codrsync init --local[/cyan]")
            else:
                console.print()
                console.print("No problem! Use local mode with your own API key:")
                console.print("  [cyan]codrsync init --local[/cyan]")
            raise typer.Exit(0)

    # PHASE 2: Connect to cloud concierge
    if language == "pt":
        console.print("[dim]Conectando ao assistente AI...[/dim]")
    else:
        console.print("[dim]Connecting to AI assistant...[/dim]")

    from codrsync.cloud.session import start_init_session

    # Start the init session with project context
    success = start_init_session(
        access_token=cfg.codrsync_device_token,
        local_path=project_path,
        project_context=scan_result.to_dict(),
        language=language,
    )

    if not success:
        # Cloud failed, offer local fallback
        if language == "pt":
            console.print()
            console.print("[yellow]Nao foi possivel conectar ao assistente.[/yellow]")
            console.print("Tente o modo local:")
            console.print("  [cyan]codrsync init --local[/cyan]")
        else:
            console.print()
            console.print("[yellow]Could not connect to assistant.[/yellow]")
            console.print("Try local mode:")
            console.print("  [cyan]codrsync init --local[/cyan]")
        raise typer.Exit(1)

    # Show next steps after successful init
    console.print()
    if language == "pt":
        console.print(Panel(
            "[bold green]Projeto configurado![/bold green]\n\n"
            "Proximos passos:\n"
            "  [cyan]codrsync start[/cyan]  - Continuar desenvolvendo com o assistente\n"
            "  [cyan]codrsync status[/cyan] - Ver status do projeto",
            border_style="green",
        ))
    else:
        console.print(Panel(
            "[bold green]Project configured![/bold green]\n\n"
            "Next steps:\n"
            "  [cyan]codrsync start[/cyan]  - Continue developing with the assistant\n"
            "  [cyan]codrsync status[/cyan] - View project status",
            border_style="green",
        ))


@app.command(help=lazy_t("cli.build.help"), rich_help_panel=lazy_t("cli.panel.ai"))
def build(
    prp: str = typer.Argument(None, help=lazy_t("cli.build.prp_help")),
    story: str = typer.Option(None, "--story", "-s", help=lazy_t("cli.build.story_help")),
):
    backend = get_ai_backend()

    if backend == AIBackend.OFFLINE:
        console.print(f"{t('common.error')} {t('common.ai_required_short')}")
        raise typer.Exit(1)

    from codrsync.ai import build as build_module
    build_module.run(backend=backend, prp=prp, story=story)


@app.command(help=lazy_t("cli.prp.help"), rich_help_panel=lazy_t("cli.panel.ai"))
def prp(
    action: str = typer.Argument("list", help=lazy_t("cli.prp.action_help")),
    file: str = typer.Argument(None, help=lazy_t("cli.prp.file_help")),
):
    from codrsync.ai import prp as prp_module
    prp_module.run(action=action, file=file)


@app.command(help=lazy_t("cli.auth.help"), rich_help_panel=lazy_t("cli.panel.config"))
def auth(
    show: bool = typer.Option(False, "--show", "-s", help=lazy_t("cli.auth.show_help")),
    cloud: bool = typer.Option(False, "--cloud", "-c", help=lazy_t("cli.auth.cloud_help")),
    logout: bool = typer.Option(False, "--logout", help=lazy_t("cli.auth.logout_help")),
):
    from codrsync.auth import configure_auth, show_auth_status

    if cloud:
        from codrsync.cloud_auth import cloud_login
        cloud_login()
    elif logout:
        from codrsync.cloud_auth import cloud_logout
        cloud_logout()
    elif show:
        show_auth_status()
    else:
        configure_auth()


@app.command(help=lazy_t("cli.billing.help"), rich_help_panel=lazy_t("cli.panel.config"))
def billing(
    status: bool = typer.Option(False, "--status", "-s", help=lazy_t("cli.billing.status_help")),
    upgrade: bool = typer.Option(False, "--upgrade", "-u", help=lazy_t("cli.billing.upgrade_help")),
    portal: bool = typer.Option(False, "--portal", "-p", help=lazy_t("cli.billing.portal_help")),
    credits: bool = typer.Option(False, "--credits", "-c", help=lazy_t("cli.billing.credits_help")),
):
    """Manage subscription and billing."""
    from codrsync.subscription import (
        get_subscription,
        show_subscription_status,
        show_upgrade_prompt,
        show_credits_prompt,
        CODRSYNC_API_URL,
    )
    import webbrowser

    if portal:
        # Open Stripe customer portal
        subscription = get_subscription()
        if subscription and subscription.stripe_subscription_id:
            webbrowser.open(f"{CODRSYNC_API_URL}/api/billing/portal")
            console.print(t("subscription.checkout_opened"))
        else:
            console.print("[yellow]No active subscription. Use --upgrade to subscribe.[/yellow]")
        return

    if upgrade:
        show_upgrade_prompt()
        return

    if credits:
        subscription = get_subscription()
        if subscription:
            balance = subscription.credits.balance
            show_credits_prompt("credits_100", 100, balance)
        else:
            console.print("[yellow]Not authenticated. Run 'codrsync auth --cloud' first.[/yellow]")
        return

    # Default: show status
    show_subscription_status()


# =============================================================================
# RSYNC SUITE COMMANDS (envrsync, docrsync, pptrsync)
# =============================================================================

@app.command(help=lazy_t("cli.envrsync.help"), rich_help_panel=lazy_t("cli.panel.local"))
def envrsync(
    path: str = typer.Argument(None, help=lazy_t("cli.envrsync.path_help")),
    deep: bool = typer.Option(False, "--deep", "-d", help=lazy_t("cli.envrsync.deep_help")),
    json_output: bool = typer.Option(False, "--json", "-j", help=lazy_t("cli.envrsync.json_help")),
    output: str = typer.Option(None, "--output", "-o", help=lazy_t("cli.envrsync.output_help")),
):
    """Scan and analyze project environment."""
    from pathlib import Path as P
    from codrsync.envrsync import quick_scan, format_scan_result
    import json as json_module

    scan_path = P(path) if path else P.cwd()

    if not scan_path.exists():
        console.print(f"[red]{t('common.error')} {t('envrsync.path_not_found', path=str(scan_path))}[/red]")
        raise typer.Exit(1)

    # Deep scan requires credits
    if deep:
        from codrsync.subscription import require_credits, require_feature, Feature

        # Check feature access
        if not require_feature(Feature.ENVRSYNC):
            raise typer.Exit(1)

        # Check credits (deep scan costs 5 credits)
        if not require_credits("scan_deep"):
            raise typer.Exit(1)

        console.print(t("envrsync.deep_scan_starting"))
        # TODO: Implement deep AI-powered analysis
        console.print("[yellow]Deep scan coming soon. Running basic scan...[/yellow]")

    # Run quick scan
    console.print(t("envrsync.scanning"))
    result = quick_scan(scan_path)

    # Output as JSON
    if json_output:
        output_data = json_module.dumps(result.to_dict(), indent=2, ensure_ascii=False)
        if output:
            P(output).write_text(output_data, encoding="utf-8")
            console.print(t("envrsync.saved_to", path=output))
        else:
            console.print(output_data)
        return

    # Format and display
    cfg = Config.load()
    lang = "pt" if cfg.language and cfg.language.startswith("pt") else "en"

    formatted = format_scan_result(result, lang)

    console.print(Panel(
        formatted,
        title=f"[bold cyan]envrsync[/bold cyan] - {result.project_name or scan_path.name}",
        border_style="cyan",
    ))

    # Save to file if requested
    if output:
        P(output).write_text(json_module.dumps(result.to_dict(), indent=2), encoding="utf-8")
        console.print(t("envrsync.saved_to", path=output))


@app.command(help=lazy_t("cli.docrsync.help"), rich_help_panel=lazy_t("cli.panel.ai"))
def docrsync(
    mode: str = typer.Argument("readme", help=lazy_t("cli.docrsync.mode_help")),
    path: str = typer.Option(None, "--path", "-p", help=lazy_t("cli.docrsync.path_help")),
    output: str = typer.Option(None, "--output", "-o", help=lazy_t("cli.docrsync.output_help")),
):
    """Generate documentation with AI."""
    from codrsync.subscription import require_feature, require_credits, Feature

    # Check feature access (requires Pro or higher)
    if not require_feature(Feature.DOCRSYNC):
        raise typer.Exit(1)

    # Map mode to credit cost
    credit_map = {
        "readme": "doc_readme",      # 5 credits
        "technical": "doc_technical", # 15 credits
        "full": "doc_full",          # 30 credits
    }

    if mode not in credit_map:
        console.print(f"[red]{t('docrsync.invalid_mode', mode=mode)}[/red]")
        console.print(t("docrsync.valid_modes"))
        raise typer.Exit(1)

    # Check credits
    if not require_credits(credit_map[mode]):
        raise typer.Exit(1)

    console.print(Panel(
        t("docrsync.coming_soon"),
        title="[bold cyan]docrsync[/bold cyan]",
        border_style="cyan",
    ))
    # TODO: Implement docrsync functionality
    # - Scan project structure
    # - Send to cloud AI for documentation generation
    # - Save generated docs


@app.command(help=lazy_t("cli.pptrsync.help"), rich_help_panel=lazy_t("cli.panel.ai"))
def pptrsync(
    mode: str = typer.Argument("standard", help=lazy_t("cli.pptrsync.mode_help")),
    topic: str = typer.Option(None, "--topic", "-t", help=lazy_t("cli.pptrsync.topic_help")),
    premium_images: bool = typer.Option(False, "--premium", help=lazy_t("cli.pptrsync.premium_help")),
    output: str = typer.Option(None, "--output", "-o", help=lazy_t("cli.pptrsync.output_help")),
    export_format: str = typer.Option("pptx", "--format", "-f", help=lazy_t("cli.pptrsync.format_help")),
):
    """Generate presentations with AI."""
    from codrsync.subscription import (
        require_feature, require_credits, get_subscription,
        Feature, CREDIT_COSTS,
    )

    # Check feature access (requires Pro or higher)
    if not require_feature(Feature.PPTRSYNC):
        raise typer.Exit(1)

    # Check premium images feature (requires Pro+)
    if premium_images:
        if not require_feature(Feature.PPTRSYNC_PREMIUM):
            raise typer.Exit(1)

    # Map mode to credit cost
    credit_map = {
        "quick": "ppt_quick",       # 10 credits, 5 slides
        "standard": "ppt_standard", # 20 credits, 10 slides
        "full": "ppt_full",         # 35 credits, 20 slides
    }

    if mode not in credit_map:
        console.print(f"[red]{t('pptrsync.invalid_mode', mode=mode)}[/red]")
        console.print(t("pptrsync.valid_modes"))
        raise typer.Exit(1)

    # Calculate total credits
    base_cost = CREDIT_COSTS.get(credit_map[mode], 20)
    total_cost = base_cost

    if premium_images:
        total_cost += CREDIT_COSTS.get("ppt_images_premium", 10)

    if export_format in ["pptx", "pdf"]:
        total_cost += CREDIT_COSTS.get("ppt_export", 5)

    # Check credits
    subscription = get_subscription()
    if subscription and subscription.credits.balance < total_cost:
        console.print(f"[yellow]{t('subscription.insufficient_credits')}[/yellow]")
        console.print(f"{t('subscription.cost')}: {total_cost} {t('subscription.credits_unit')}")
        console.print(f"{t('subscription.balance')}: {subscription.credits.balance} {t('subscription.credits_unit')}")
        raise typer.Exit(1)

    console.print(Panel(
        t("pptrsync.coming_soon"),
        title="[bold cyan]pptrsync[/bold cyan]",
        border_style="cyan",
    ))
    # TODO: Implement pptrsync functionality
    # - Parse topic or scan project
    # - Send to cloud AI for presentation generation
    # - Generate images (standard or premium)
    # - Export to requested format


# =============================================================================
# CLOUD WORKSPACE COMMANDS
# =============================================================================

cloud_app = typer.Typer(help="Manage cloud workspaces", rich_markup_mode="rich")
app.add_typer(cloud_app, name="cloud", rich_help_panel=lazy_t("cli.panel.ai"))


@cloud_app.command("status", help="Show active cloud workspace status")
def cloud_status():
    """Show status of active cloud workspace."""
    from codrsync.config import Config
    from codrsync.cloud.session import check_active_workspace

    cfg = Config.load()

    if not cfg.codrsync_device_token:
        console.print("[yellow]Not authenticated. Run 'codrsync auth --cloud' first.[/yellow]")
        raise typer.Exit(1)

    session = check_active_workspace(cfg.codrsync_device_token)

    if not session:
        console.print("[dim]No active cloud workspace.[/dim]")
        console.print()
        console.print("Start one with: [cyan]codrsync start --cloud[/cyan]")
        return

    from rich.table import Table

    table = Table(title="[bold cyan]Cloud Workspace[/bold cyan]", show_header=False)
    table.add_column("Key", style="bold")
    table.add_column("Value", style="cyan")

    table.add_row("Slug", session.workspace_slug)
    table.add_row("URL", session.workspace_url)
    table.add_row("Mode", session.mode)
    table.add_row("Duration", f"{session.duration_minutes} minutes")
    table.add_row("Started", session.started_at[:19] if session.started_at else "N/A")

    console.print(table)
    console.print()
    console.print("Connect with: [cyan]codrsync start --cloud[/cyan]")


@cloud_app.command("download", help="Download workspace files as ZIP")
def cloud_download(
    output: str = typer.Option("workspace.zip", "--output", "-o", help="Output file path"),
):
    """Download the current cloud workspace as a ZIP file."""
    from codrsync.config import Config
    from codrsync.cloud.session import check_active_workspace
    import urllib.request
    import urllib.error

    cfg = Config.load()

    if not cfg.codrsync_device_token:
        console.print("[yellow]Not authenticated. Run 'codrsync auth --cloud' first.[/yellow]")
        raise typer.Exit(1)

    session = check_active_workspace(cfg.codrsync_device_token)

    if not session:
        console.print("[yellow]No active cloud workspace to download.[/yellow]")
        raise typer.Exit(1)

    console.print(f"[dim]Downloading workspace {session.workspace_slug}...[/dim]")

    try:
        req = urllib.request.Request(
            f"https://codrsync.dev/api/concierge/download/{session.workspace_slug}",
            headers={
                "Authorization": f"Bearer {cfg.codrsync_device_token}",
            },
            method="GET",
        )

        with urllib.request.urlopen(req, timeout=120) as response:
            with open(output, "wb") as f:
                f.write(response.read())

        console.print(f"[green]Downloaded to: {output}[/green]")

    except urllib.error.HTTPError as e:
        if e.code == 400:
            console.print("[yellow]Workspace is not running. Cannot download.[/yellow]")
        else:
            console.print(f"[red]Download failed: HTTP {e.code}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@cloud_app.command("stop", help="Stop the active cloud workspace")
def cloud_stop():
    """Stop the current cloud workspace."""
    from codrsync.config import Config
    from codrsync.cloud.session import check_active_workspace

    cfg = Config.load()

    if not cfg.codrsync_device_token:
        console.print("[yellow]Not authenticated.[/yellow]")
        raise typer.Exit(1)

    session = check_active_workspace(cfg.codrsync_device_token)

    if not session:
        console.print("[dim]No active cloud workspace.[/dim]")
        return

    console.print(f"[yellow]Stopping workspace {session.workspace_slug}...[/yellow]")
    # TODO: Implement stop API call
    console.print("[dim]Stop functionality coming soon. Workspace will auto-stop after inactivity.[/dim]")


# =============================================================================
# CLOUD STORAGE COMMANDS
# =============================================================================

storage_app = typer.Typer(help=lazy_t("cli.storage.help"), rich_markup_mode="rich")
app.add_typer(storage_app, name="storage", rich_help_panel=lazy_t("cli.panel.config"))


@storage_app.command("upload", help=lazy_t("cli.storage.upload_help"))
def storage_upload(
    file: str = typer.Argument(..., help=lazy_t("cli.storage.file_help")),
    folder: str = typer.Option("uploads", "--folder", "-f", help=lazy_t("cli.storage.folder_help")),
    public: bool = typer.Option(False, "--public", "-p", help=lazy_t("cli.storage.public_help")),
):
    from codrsync.cloud.storage import upload_file, StorageError, StorageLimitExceeded

    try:
        result = upload_file(file, folder=folder, is_public=public)
        if result.get("usage"):
            usage = result["usage"]
            console.print(f"\n[dim]Storage: {usage.get('used', '?')} / {usage.get('limit', '?')} ({usage.get('percentUsed', 0)}%)[/dim]")
    except StorageLimitExceeded as e:
        console.print(Panel(
            f"{t('cloud_storage.limit_exceeded', used=e.usage.get('used', '?'), limit=e.usage.get('limit', '?'))}\n\n"
            f"{t('cloud_storage.upgrade_hint', plan='Pro')}",
            title=t("common.error"),
            border_style="red",
        ))
        raise typer.Exit(1)
    except StorageError as e:
        console.print(f"{t('common.error')} {str(e)}")
        raise typer.Exit(1)


@storage_app.command("download", help=lazy_t("cli.storage.download_help"))
def storage_download(
    key: str = typer.Argument(..., help=lazy_t("cli.storage.key_help")),
    output: str = typer.Option(None, "--output", "-o", help=lazy_t("cli.storage.output_help")),
):
    from codrsync.cloud.storage import download_file, StorageError

    try:
        download_file(key, output_path=output)
    except StorageError as e:
        console.print(f"{t('common.error')} {str(e)}")
        raise typer.Exit(1)


@storage_app.command("list", help=lazy_t("cli.storage.list_help"))
def storage_list(
    folder: str = typer.Option(None, "--folder", "-f", help=lazy_t("cli.storage.folder_help")),
):
    from codrsync.cloud.storage import list_files, StorageError
    from rich.table import Table

    try:
        files = list_files(folder=folder)

        if not files:
            console.print("[dim]No files found.[/dim]")
            return

        table = Table(title="Cloud Storage Files")
        table.add_column("Filename", style="cyan")
        table.add_column("Size", justify="right")
        table.add_column("Folder")
        table.add_column("Created")

        for f in files:
            size = f.get("size", 0)
            size_str = f"{size / 1024:.1f} KB" if size < 1024 * 1024 else f"{size / (1024 * 1024):.1f} MB"
            table.add_row(
                f.get("filename", "?"),
                size_str,
                f.get("folder", ""),
                f.get("created_at", "")[:10] if f.get("created_at") else "",
            )

        console.print(table)
    except StorageError as e:
        console.print(f"{t('common.error')} {str(e)}")
        raise typer.Exit(1)


@storage_app.command("delete", help=lazy_t("cli.storage.delete_help"))
def storage_delete(
    key: str = typer.Argument(..., help=lazy_t("cli.storage.key_help")),
):
    from codrsync.cloud.storage import delete_file, StorageError

    try:
        delete_file(key)
    except StorageError as e:
        console.print(f"{t('common.error')} {str(e)}")
        raise typer.Exit(1)


@storage_app.command("usage", help=lazy_t("cli.storage.usage_help"))
def storage_usage():
    from codrsync.cloud.storage import get_usage, StorageError
    from rich.table import Table
    from rich.progress import Progress, BarColumn, TextColumn

    try:
        data = get_usage()

        console.print(f"\n[bold]Storage Usage[/bold] ({data.get('tier', 'free').title()} plan)\n")

        used = data.get("usage", {}).get("formatted", "0 B")
        limit = data.get("limit", {}).get("formatted", "100 MB")
        percent = data.get("percentUsed", 0)
        file_count = data.get("usage", {}).get("fileCount", 0)

        # Progress bar
        with Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task(f"{used} / {limit}", total=100, completed=percent)
            progress.refresh()

        console.print(f"  Used: [cyan]{used}[/cyan] of [cyan]{limit}[/cyan]")
        console.print(f"  Files: [cyan]{file_count}[/cyan]")
        console.print(f"  Remaining: [green]{data.get('remaining', {}).get('formatted', '?')}[/green]")

        if percent > 80:
            console.print(f"\n[yellow]{t('cloud_storage.upgrade_hint', plan='Pro')}[/yellow]")

    except StorageError as e:
        console.print(f"{t('common.error')} {str(e)}")
        raise typer.Exit(1)


# =============================================================================
# UTILITY COMMANDS
# =============================================================================

@app.command(help=lazy_t("cli.doctor.help"), rich_help_panel=lazy_t("cli.panel.config"))
def doctor():
    from codrsync.utils.doctor import run_diagnostics
    run_diagnostics()


@app.command(help=lazy_t("cli.config.help"), rich_help_panel=lazy_t("cli.panel.config"))
def config(
    lang: str = typer.Option(None, "--lang", "-l", help=lazy_t("cli.config.lang_help")),
    show: bool = typer.Option(False, "--show", "-s", help=lazy_t("cli.config.show_help")),
):
    """View or update codrsync configuration."""
    import os
    from codrsync.config import Config, CODRSYNC_HOME
    from codrsync.i18n import setup_language, t
    from codrsync.i18n.strings import BUILTIN_LANGUAGES
    from codrsync.auth import get_ai_backend
    from rich.table import Table

    cfg = Config.load()

    if show or (lang is None):
        # Show current config
        if lang is None and not show:
            console.print(t("config.no_changes"))
            console.print()

        table = Table(title=t("config.current_title"), show_header=False)
        table.add_column("Key", style="bold")
        table.add_column("Value", style="cyan")

        table.add_row(t("config.language_label"), cfg.language or "en")
        table.add_row(t("config.backend_label"), get_ai_backend().value)

        # Check if in a project
        project_name = t("config.no_project")
        manifest_path = Path("doc/project/manifest.json")
        if manifest_path.exists():
            import json
            try:
                with open(manifest_path) as f:
                    manifest = json.load(f)
                    project_name = manifest.get("name", project_name)
            except Exception:
                pass
        table.add_row(t("config.project_label"), project_name)

        console.print(table)
        return

    if lang:
        lang = lang.strip().lower()

        # Check if it's a built-in language
        if lang in BUILTIN_LANGUAGES:
            cfg.language = lang
            cfg.save()
            setup_language(lang)
            console.print(t("config.language_changed", lang=lang))
            console.print(f"[dim]{t('config.language_restart_hint')}[/dim]")
            return

        # Not built-in, try API translation
        console.print(t("config.language_not_found", lang=lang))
        console.print(t("config.language_api_required", lang=lang))

        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            api_key = cfg.anthropic_api_key

        if not api_key:
            console.print(Panel(
                t("common.ai_required"),
                title=t("common.ai_required_title"),
                border_style="yellow"
            ))
            return

        console.print(t("config.language_translating", lang=lang))
        from codrsync.i18n.translator import translate_via_api
        result = translate_via_api(lang, api_key)

        if result is None:
            console.print(f"[yellow]{t('config.language_translation_failed')}[/yellow]")
            return

        cfg.language = lang
        cfg.save()
        setup_language(lang)
        console.print(t("config.language_changed", lang=lang))
        console.print(f"[dim]{t('config.language_restart_hint')}[/dim]")


# =============================================================================
# CREDITS MANAGEMENT
# =============================================================================

@app.command(help="Manage codrsync credits", rich_help_panel=lazy_t("cli.panel.config"))
def credits(
    buy: bool = typer.Option(False, "--buy", "-b", help="Open browser to purchase credits"),
    history: bool = typer.Option(False, "--history", "-h", help="Show transaction history"),
):
    """Manage your codrsync credits balance.

    View balance: codrsync credits
    Buy credits: codrsync credits --buy
    History: codrsync credits --history
    """
    from codrsync.config import Config
    from codrsync.device_auth import get_credits_balance
    from rich.table import Table
    import webbrowser

    cfg = Config.load()

    # Check if authenticated
    if not cfg.codrsync_device_token:
        console.print("[yellow]Not authenticated with codrsync.dev[/yellow]")
        console.print()
        console.print("To use codrsync credits:")
        console.print("  1. Run [cyan]codrsync auth[/cyan]")
        console.print("  2. Select [cyan]codrsync Credits[/cyan]")
        console.print()
        console.print("[green]🎁 New users get 10 FREE credits![/green]")
        return

    if buy:
        url = "https://codrsync.dev/dashboard/billing?buy_credits=true"
        console.print(f"[dim]Opening: {url}[/dim]")
        webbrowser.open(url)
        return

    # Get balance
    console.print("[dim]Fetching credits balance...[/dim]")
    balance = get_credits_balance(cfg)

    if balance is None:
        console.print("[red]Failed to get credits balance[/red]")
        console.print("[dim]Try re-authenticating with 'codrsync auth'[/dim]")
        return

    # Display balance
    console.print()
    table = Table(title="[bold cyan]codrsync Credits[/bold cyan]", show_header=False)
    table.add_column("Label", style="bold")
    table.add_column("Value", style="cyan", justify="right")

    table.add_row("Current Balance", f"[bold green]{balance.get('balance', 0)}[/bold green] credits")
    table.add_row("Lifetime Purchased", f"{balance.get('lifetime_purchased', 0)} credits")
    table.add_row("Lifetime Used", f"{balance.get('lifetime_used', 0)} credits")
    table.add_row("Bonus Credits", f"{balance.get('lifetime_bonus', 0)} credits")

    console.print(table)
    console.print()

    if balance.get('balance', 0) < 10:
        console.print("[yellow]Low balance![/yellow] Buy more with: [cyan]codrsync credits --buy[/cyan]")
    else:
        console.print("[dim]Buy more credits: codrsync credits --buy[/dim]")

    if cfg.codrsync_user_email:
        console.print(f"[dim]Logged in as: {cfg.codrsync_user_email}[/dim]")


# =============================================================================
# SUPEREGO / CLAUDE CODE INTEGRATION
# =============================================================================

@app.command(help="Start Claude Code with codrsync as superego", rich_help_panel=lazy_t("cli.panel.ai"))
def start(
    project: Path = typer.Option(Path("."), "--project", "-p", help="Project directory"),
    cloud: bool = typer.Option(False, "--cloud", "-c", help="Use cloud workspace instead of local"),
    no_hooks: bool = typer.Option(False, "--no-hooks", help="Launch without hooks (debug)"),
    reset: bool = typer.Option(False, "--reset", help="Reset environment configuration"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed logs"),
    sync_first: bool = typer.Option(False, "--sync", "-s", help="Sync local project to cloud before starting"),
):
    """Launch Claude Code with codrsync as the guiding superego.

    Local mode (default):
    1. Detects or installs Claude Code
    2. Configures hooks and slash commands
    3. Injects CE methodology into CLAUDE.md
    4. Launches Claude Code with full context

    Cloud mode (--cloud):
    1. Authenticates with codrsync.dev (if needed)
    2. Provisions a cloud workspace container
    3. Connects via WebSocket for real-time chat
    4. All execution happens in the cloud
    """
    # Cloud mode: use remote workspace
    if cloud:
        from codrsync.config import Config
        from codrsync.cloud.session import start_cloud_session

        cfg = Config.load()

        # Check authentication
        if not cfg.codrsync_device_token:
            console.print("[yellow]Not authenticated with codrsync.dev[/yellow]")
            console.print()
            console.print("To use cloud workspaces, first authenticate:")
            console.print("  [cyan]codrsync auth --cloud[/cyan]")
            console.print()

            # Offer to authenticate now
            import questionary
            if questionary.confirm("Authenticate now?", default=True).ask():
                from codrsync.device_auth import device_code_login
                if not device_code_login(cfg):
                    raise typer.Exit(1)
            else:
                raise typer.Exit(1)

        # Get project URL if syncing
        project_url = None
        if sync_first:
            # TODO: Implement git remote detection and sync
            project_path = project.resolve()
            try:
                import subprocess
                result = subprocess.run(
                    ["git", "remote", "get-url", "origin"],
                    cwd=project_path,
                    capture_output=True,
                    text=True,
                )
                if result.returncode == 0:
                    project_url = result.stdout.strip()
                    console.print(f"[dim]Will clone: {project_url}[/dim]")
            except Exception:
                pass

        # Start cloud session
        console.print()
        console.print(Panel(
            "[bold cyan]codrsync Cloud[/bold cyan]\n\n"
            "Starting cloud workspace with Claude Code.\n"
            "Your code runs in a secure container.",
            border_style="cyan",
        ))
        console.print()

        success = start_cloud_session(
            access_token=cfg.codrsync_device_token,
            project_url=project_url,
            language=cfg.language or "en",
        )

        if not success:
            raise typer.Exit(1)
        return

    # Local mode: launch Claude Code locally
    from codrsync.setup import (
        detect_claude_code,
        offer_claude_installation,
        verify_codrsync_project,
        offer_codrsync_init,
        setup_claude_environment,
        show_start_summary,
        launch_claude,
    )

    project_path = project.resolve()

    # 1. Detect Claude Code
    if verbose:
        console.print("[dim]Detectando Claude Code...[/dim]")

    claude_path = detect_claude_code()
    if not claude_path:
        if offer_claude_installation():
            claude_path = detect_claude_code()
        if not claude_path:
            console.print("[red]Claude Code é necessário. Instale e tente novamente.[/red]")
            raise typer.Exit(1)

    # 2. Verify codrsync project
    if verbose:
        console.print("[dim]Verificando projeto codrsync...[/dim]")

    project_info = verify_codrsync_project(project_path)
    if not project_info.get("initialized"):
        if not offer_codrsync_init(project_path):
            raise typer.Exit(1)

    # 3. Configure environment
    if not no_hooks:
        if verbose:
            console.print("[dim]Configurando ambiente...[/dim]")
        setup_claude_environment(project_path, reset=reset)

    # 4. Show summary
    show_start_summary(project_path, claude_path)

    # 5. Launch Claude Code
    launch_claude(claude_path, project_path)


# =============================================================================
# HIDDEN HOOK COMMANDS (used by Claude Code hooks)
# =============================================================================

@app.command(hidden=True)
def _inject_context():
    """[Hook] Inject context at session start."""
    from codrsync.hooks.context import inject_context
    inject_context()


@app.command(hidden=True)
def _log_activity():
    """[Hook] Log file editing activity."""
    from codrsync.hooks.activity import log_activity
    log_activity()


@app.command(hidden=True)
def _update_progress():
    """[Hook] Update progress when Claude stops."""
    from codrsync.hooks.progress import update_progress
    update_progress()


if __name__ == "__main__":
    app()
