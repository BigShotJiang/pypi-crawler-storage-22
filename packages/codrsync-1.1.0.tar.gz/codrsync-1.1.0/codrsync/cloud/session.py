"""
Cloud Session Module

Manages cloud workspace sessions from the CLI:
- Provision workspace via codrsync.dev API
- Connect via WebSocket to container
- Render TUI chat interface with streaming
- Handle tool activity display
- CloudInitSession for concierge-driven project initialization
"""

import json
import os
import time
import threading
import queue
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Callable

from rich.console import Console
from rich.panel import Panel
from rich.live import Live
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich.spinner import Spinner
from rich.text import Text
from rich.table import Table
from rich.layout import Layout
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeRemainingColumn

console = Console()

# API Configuration
API_BASE = "https://codrsync.dev"


@dataclass
class CloudSession:
    """Represents an active cloud workspace session."""
    workspace_id: str
    workspace_slug: str
    workspace_url: str
    auth_token: str
    conversation_id: str
    mode: str = "onboarding"
    duration_minutes: int = 60  # 60 min trial
    started_at: str = ""

    # Runtime state
    ws: Optional[object] = None
    connected: bool = False
    messages: list = field(default_factory=list)
    current_tool: Optional[str] = None

    @property
    def time_remaining_minutes(self) -> int:
        """Calculate remaining time in the session."""
        if not self.started_at:
            return self.duration_minutes
        try:
            # Parse ISO format timestamp
            started = datetime.fromisoformat(self.started_at.replace("Z", "+00:00"))
            now = datetime.now(started.tzinfo) if started.tzinfo else datetime.now()
            elapsed = now - started
            remaining = self.duration_minutes - int(elapsed.total_seconds() / 60)
            return max(0, remaining)
        except Exception:
            return self.duration_minutes

    @property
    def time_remaining_str(self) -> str:
        """Human-readable time remaining."""
        remaining = self.time_remaining_minutes
        if remaining <= 0:
            return "0:00"
        hours = remaining // 60
        mins = remaining % 60
        if hours > 0:
            return f"{hours}h {mins}min"
        return f"{mins} min"

    @property
    def is_trial_ending_soon(self) -> bool:
        """Check if trial is ending in < 5 minutes."""
        return self.time_remaining_minutes <= 5

    @property
    def is_trial_ended(self) -> bool:
        """Check if trial has ended."""
        return self.time_remaining_minutes <= 0


def provision_workspace(
    access_token: str,
    project_url: Optional[str] = None,
    language: str = "en",
) -> Optional[CloudSession]:
    """
    Provision a new cloud workspace.

    Args:
        access_token: Device token from codrsync auth
        project_url: Optional GitHub URL to clone
        language: Language preference

    Returns:
        CloudSession if successful, None otherwise
    """
    import urllib.request
    import urllib.error

    console.print("[dim]Provisioning cloud workspace...[/dim]")

    try:
        data = json.dumps({
            "projectUrl": project_url,
            "language": language,
            "source": "cli",
        }).encode("utf-8")

        req = urllib.request.Request(
            f"{API_BASE}/api/concierge/start",
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}",
            },
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=120) as response:
            result = json.loads(response.read().decode("utf-8"))

            if not result.get("success"):
                console.print(f"[red]Error: {result.get('error', 'Unknown error')}[/red]")
                return None

            ws = result["workspace"]
            return CloudSession(
                workspace_id=ws["id"],
                workspace_slug=ws["slug"],
                workspace_url=ws["url"],
                auth_token=ws["authToken"],
                conversation_id=ws["conversationId"],
                mode=ws.get("mode", "onboarding"),
                duration_minutes=ws.get("durationMinutes", 30),
                started_at=ws.get("startedAt", ""),
            )

    except urllib.error.HTTPError as e:
        error_body = json.loads(e.read().decode("utf-8")) if e.fp else {}
        error_msg = error_body.get("error", f"HTTP {e.code}")

        if e.code == 401:
            console.print("[yellow]Session expired. Run 'codrsync auth --cloud' to re-authenticate.[/yellow]")
        elif e.code == 429:
            console.print("[yellow]Trial limit reached. Subscribe to continue![/yellow]")
            console.print(f"[dim]{error_msg}[/dim]")
        else:
            console.print(f"[red]Error: {error_msg}[/red]")
        return None

    except urllib.error.URLError as e:
        console.print(f"[red]Connection error: {e.reason}[/red]")
        return None
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        return None


def check_active_workspace(access_token: str) -> Optional[CloudSession]:
    """
    Check if user has an active workspace.

    Returns:
        CloudSession if active workspace exists, None otherwise
    """
    import urllib.request
    import urllib.error

    try:
        req = urllib.request.Request(
            f"{API_BASE}/api/concierge/active",
            headers={
                "Authorization": f"Bearer {access_token}",
            },
            method="GET",
        )

        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode("utf-8"))

            ws = result.get("workspace")
            if not ws:
                return None

            return CloudSession(
                workspace_id=ws["id"],
                workspace_slug=ws["slug"],
                workspace_url=ws["url"],
                auth_token=ws["authToken"],
                conversation_id=ws["conversationId"],
                mode=ws.get("mode", "onboarding"),
                duration_minutes=ws.get("durationMinutes", 30),
                started_at=ws.get("startedAt", ""),
            )

    except Exception:
        return None


class CloudChatTUI:
    """
    Terminal UI for cloud chat sessions.

    Handles:
    - WebSocket connection and reconnection
    - Message streaming and display
    - Tool activity visualization
    - User input
    """

    def __init__(self, session: CloudSession):
        self.session = session
        self.ws = None
        self.connected = False
        self.running = False
        self.messages: list = []
        self.current_response = ""
        self.current_tool: Optional[dict] = None
        self.is_loading = False
        self.event_queue: queue.Queue = queue.Queue()

    def connect(self) -> bool:
        """Establish WebSocket connection to container."""
        try:
            import websocket
        except ImportError:
            console.print("[yellow]Installing websocket-client...[/yellow]")
            import subprocess
            subprocess.run(["pip", "install", "websocket-client"], capture_output=True)
            import websocket

        ws_url = self.session.workspace_url.replace("https://", "wss://").replace("http://", "ws://")
        ws_url = f"{ws_url}/ws?token={self.session.auth_token}"

        console.print(f"[dim]Connecting to {self.session.workspace_slug}...[/dim]")

        try:
            self.ws = websocket.create_connection(
                ws_url,
                timeout=30,
                header={"Origin": "https://codrsync.dev"},
            )
            self.connected = True
            console.print("[green]Connected![/green]")
            return True
        except Exception as e:
            console.print(f"[red]Connection failed: {e}[/red]")
            return False

    def disconnect(self):
        """Close WebSocket connection."""
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass
        self.connected = False
        self.ws = None

    def send_message(self, content: str):
        """Send a message to Claude."""
        if not self.ws or not self.connected:
            console.print("[red]Not connected[/red]")
            return

        self.is_loading = True
        self.current_response = ""
        self.current_tool = None

        # Add user message to history
        self.messages.append({
            "role": "user",
            "content": content,
        })

        # Send to WebSocket
        self.ws.send(json.dumps({
            "type": "message",
            "content": content,
            "conversationId": self.session.conversation_id,
        }))

    def receive_loop(self):
        """Background thread to receive WebSocket messages."""
        while self.running and self.ws:
            try:
                self.ws.settimeout(0.5)
                data = self.ws.recv()
                if data:
                    event = json.loads(data)
                    self.event_queue.put(event)
            except Exception:
                continue

    def handle_event(self, event: dict):
        """Process incoming WebSocket event."""
        event_type = event.get("type", "")

        if event_type == "connected":
            console.print(f"[dim]Workspace ready: {event.get('workspace', '')}[/dim]")

        elif event_type == "status":
            status = event.get("status", "")
            if status == "processing":
                self.is_loading = True
            elif status == "complete":
                self.is_loading = False
                if self.current_response:
                    self.messages.append({
                        "role": "assistant",
                        "content": self.current_response,
                    })
                self.current_response = ""

        elif event_type == "session_start":
            # Claude session started
            pass

        elif event_type == "text":
            # Streaming text
            content = event.get("content", "") or event.get("delta", "")
            self.current_response += content

        elif event_type == "tool_start":
            tool_name = event.get("tool", "unknown")
            tool_input = event.get("input", {})
            self.current_tool = {
                "name": tool_name,
                "input": tool_input,
                "status": "running",
            }

        elif event_type == "tool_result":
            if self.current_tool:
                self.current_tool["status"] = "done" if event.get("success", True) else "error"
                self.current_tool["output"] = event.get("output", "")
            self.current_tool = None

        elif event_type == "result":
            self.is_loading = False
            if self.current_response:
                self.messages.append({
                    "role": "assistant",
                    "content": self.current_response,
                })
            self.current_response = ""

        elif event_type == "error":
            error = event.get("error", "Unknown error")
            console.print(f"[red]Error: {error}[/red]")
            self.is_loading = False

    def render_messages(self) -> Panel:
        """Render message history for display."""
        if not self.messages and not self.current_response:
            return Panel(
                "[dim]Start by typing a message below...[/dim]\n\n"
                "Examples:\n"
                "  - Create a REST API with Express\n"
                "  - Help me debug this function\n"
                "  - Write tests for my code",
                title="[bold cyan]Claude Code[/bold cyan]",
                border_style="cyan",
            )

        content_parts = []

        # Render history
        for msg in self.messages[-10:]:  # Last 10 messages
            if msg["role"] == "user":
                content_parts.append(f"[bold green]You:[/bold green] {msg['content']}\n")
            else:
                content_parts.append(f"[bold cyan]Claude:[/bold cyan]\n{msg['content']}\n")

        # Render current streaming response
        if self.current_response:
            content_parts.append(f"[bold cyan]Claude:[/bold cyan]\n{self.current_response}")
            if self.is_loading:
                content_parts.append("[dim]...[/dim]")

        # Render current tool activity
        if self.current_tool:
            tool_name = self.current_tool["name"]
            tool_input = self.current_tool.get("input", {})

            tool_info = f"\n[yellow]Tool: {tool_name}[/yellow]"
            if "file_path" in tool_input:
                tool_info += f" [dim]{tool_input['file_path']}[/dim]"
            elif "command" in tool_input:
                cmd = tool_input["command"][:50]
                tool_info += f" [dim]$ {cmd}...[/dim]"
            content_parts.append(tool_info)

        # Loading indicator
        if self.is_loading and not self.current_response and not self.current_tool:
            content_parts.append("\n[dim]Thinking...[/dim]")

        return Panel(
            "\n".join(content_parts),
            title=f"[bold cyan]Cloud Session[/bold cyan] [dim]({self.session.workspace_slug})[/dim]",
            border_style="cyan",
        )

    def run(self):
        """Run the interactive chat TUI."""
        if not self.connect():
            return

        self.running = True

        # Start receive thread
        recv_thread = threading.Thread(target=self.receive_loop, daemon=True)
        recv_thread.start()

        console.print()
        console.print(Panel(
            f"[bold]Cloud Workspace Active[/bold]\n\n"
            f"  Slug: [cyan]{self.session.workspace_slug}[/cyan]\n"
            f"  Mode: {self.session.mode}\n"
            f"  Duration: {self.session.duration_minutes} minutes\n\n"
            f"[dim]Type your message and press Enter. Ctrl+C to exit.[/dim]",
            border_style="green",
        ))
        console.print()

        try:
            while self.running:
                # Process any pending events
                while not self.event_queue.empty():
                    try:
                        event = self.event_queue.get_nowait()
                        self.handle_event(event)
                    except queue.Empty:
                        break

                # Show current state
                if self.is_loading or self.current_response or self.current_tool:
                    console.print(self.render_messages())
                    time.sleep(0.2)
                    # Clear for next update
                    console.print("\033[F" * 10, end="")  # Move cursor up
                    continue

                # Get user input
                try:
                    user_input = console.input("[bold green]You>[/bold green] ")
                except EOFError:
                    break

                if not user_input.strip():
                    continue

                if user_input.strip().lower() in ["/exit", "/quit", "exit", "quit"]:
                    break

                if user_input.strip().lower() == "/download":
                    console.print("[dim]Downloading workspace...[/dim]")
                    # TODO: Implement download
                    continue

                if user_input.strip().lower() == "/status":
                    console.print(f"[cyan]Workspace:[/cyan] {self.session.workspace_slug}")
                    console.print(f"[cyan]Connected:[/cyan] {self.connected}")
                    console.print(f"[cyan]Messages:[/cyan] {len(self.messages)}")
                    continue

                # Send message
                self.send_message(user_input)

                # Wait for response with live update
                with Live(self.render_messages(), console=console, refresh_per_second=4) as live:
                    while self.is_loading:
                        # Process events
                        while not self.event_queue.empty():
                            try:
                                event = self.event_queue.get_nowait()
                                self.handle_event(event)
                            except queue.Empty:
                                break

                        live.update(self.render_messages())
                        time.sleep(0.1)

                    # Final update
                    live.update(self.render_messages())

                console.print()  # Newline after response

        except KeyboardInterrupt:
            console.print("\n[yellow]Session ended.[/yellow]")
        finally:
            self.running = False
            self.disconnect()


def start_cloud_session(
    access_token: str,
    project_url: Optional[str] = None,
    language: str = "en",
) -> bool:
    """
    Main entry point for cloud session.

    1. Check for existing workspace
    2. Provision new one if needed
    3. Connect and run TUI

    Returns True if session ran successfully.
    """
    # Check for existing workspace
    session = check_active_workspace(access_token)

    if session:
        console.print(f"[cyan]Resuming existing workspace: {session.workspace_slug}[/cyan]")
    else:
        # Provision new workspace
        session = provision_workspace(
            access_token=access_token,
            project_url=project_url,
            language=language,
        )

        if not session:
            return False

        console.print(f"[green]Workspace created: {session.workspace_slug}[/green]")

    # Run TUI
    tui = CloudChatTUI(session)
    tui.run()

    return True


def provision_workspace_init(
    access_token: str,
    project_context: dict,
    language: str = "en",
) -> Optional[CloudSession]:
    """
    Provision a cloud workspace specifically for init mode.

    Args:
        access_token: Device token from codrsync auth
        project_context: Quick scan result dictionary
        language: Language preference

    Returns:
        CloudSession if successful, None otherwise
    """
    import urllib.request
    import urllib.error

    try:
        data = json.dumps({
            "language": language,
            "source": "cli",
            "mode": "init",  # Important: init mode for concierge
            "projectContext": project_context,
        }).encode("utf-8")

        req = urllib.request.Request(
            f"{API_BASE}/api/concierge/start",
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}",
            },
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=120) as response:
            result = json.loads(response.read().decode("utf-8"))

            if not result.get("success"):
                console.print(f"[red]Error: {result.get('error', 'Unknown error')}[/red]")
                return None

            ws = result["workspace"]
            return CloudSession(
                workspace_id=ws["id"],
                workspace_slug=ws["slug"],
                workspace_url=ws["url"],
                auth_token=ws["authToken"],
                conversation_id=ws["conversationId"],
                mode=ws.get("mode", "init"),
                duration_minutes=ws.get("durationMinutes", 60),
                started_at=ws.get("startedAt", ""),
            )

    except urllib.error.HTTPError as e:
        error_body = json.loads(e.read().decode("utf-8")) if e.fp else {}
        error_msg = error_body.get("error", f"HTTP {e.code}")

        if e.code == 401:
            console.print("[yellow]Session expired. Run 'codrsync auth --cloud' to re-authenticate.[/yellow]")
        elif e.code == 429:
            console.print("[yellow]Trial limit reached. Subscribe to continue![/yellow]")
            console.print(f"[dim]{error_msg}[/dim]")
        else:
            console.print(f"[red]Error: {error_msg}[/red]")
        return None

    except urllib.error.URLError as e:
        console.print(f"[red]Connection error: {e.reason}[/red]")
        return None
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        return None


@dataclass
class SyncedFile:
    """A file synced from cloud to local."""
    path: str
    content: str
    timestamp: str


class CloudInitSession:
    """
    Specialized session for the `codrsync init` command.

    Differences from CloudChatTUI:
    - Shows trial timer prominently
    - Captures Write/Edit tool events and syncs files locally
    - User-friendly UX framing (no technical cloud terms)
    - Handles conversion flow at end of trial
    """

    def __init__(
        self,
        session: CloudSession,
        local_path: Path,
        language: str = "pt",
    ):
        self.session = session
        self.local_path = local_path
        self.language = language
        self.ws = None
        self.connected = False
        self.running = False
        self.messages: list = []
        self.current_response = ""
        self.current_tool: Optional[dict] = None
        self.is_loading = False
        self.event_queue: queue.Queue = queue.Queue()

        # File sync tracking
        self.synced_files: list[SyncedFile] = []
        self.pending_syncs: list[dict] = []

        # Trial tracking
        self.trial_warning_shown = False
        self.init_complete = False
        self.files_created: list[str] = []

    def connect(self) -> bool:
        """Establish WebSocket connection."""
        try:
            import websocket
        except ImportError:
            console.print("[dim]Installing websocket-client...[/dim]")
            import subprocess
            subprocess.run(["pip", "install", "websocket-client"], capture_output=True)
            import websocket

        ws_url = self.session.workspace_url.replace("https://", "wss://").replace("http://", "ws://")
        ws_url = f"{ws_url}/ws?token={self.session.auth_token}"

        try:
            self.ws = websocket.create_connection(
                ws_url,
                timeout=30,
                header={"Origin": "https://codrsync.dev"},
            )
            self.connected = True
            return True
        except Exception as e:
            console.print(f"[red]Connection failed: {e}[/red]")
            return False

    def disconnect(self):
        """Close WebSocket connection."""
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass
        self.connected = False
        self.ws = None

    def send_message(self, content: str):
        """Send a message to the concierge."""
        if not self.ws or not self.connected:
            return

        self.is_loading = True
        self.current_response = ""
        self.current_tool = None

        self.messages.append({
            "role": "user",
            "content": content,
        })

        self.ws.send(json.dumps({
            "type": "message",
            "content": content,
            "conversationId": self.session.conversation_id,
        }))

    def receive_loop(self):
        """Background thread to receive WebSocket messages."""
        while self.running and self.ws:
            try:
                self.ws.settimeout(0.5)
                data = self.ws.recv()
                if data:
                    event = json.loads(data)
                    self.event_queue.put(event)
            except Exception:
                continue

    def handle_event(self, event: dict):
        """Process incoming WebSocket event."""
        event_type = event.get("type", "")

        if event_type == "connected":
            pass  # Session connected

        elif event_type == "status":
            status = event.get("status", "")
            if status == "processing":
                self.is_loading = True
            elif status == "complete":
                self.is_loading = False
                if self.current_response:
                    self.messages.append({
                        "role": "assistant",
                        "content": self.current_response,
                    })
                self.current_response = ""
                # Sync any pending files after response complete
                self._sync_pending_files()

        elif event_type == "text":
            content = event.get("content", "") or event.get("delta", "")
            self.current_response += content

        elif event_type == "tool_start":
            tool_name = event.get("tool", "unknown")
            tool_input = event.get("input", {})
            self.current_tool = {
                "name": tool_name,
                "input": tool_input,
                "status": "running",
            }

            # Track Write/Edit operations for sync
            if tool_name in ["Write", "Edit"]:
                file_path = tool_input.get("file_path", "")
                if file_path:
                    self.pending_syncs.append({
                        "tool": tool_name,
                        "path": file_path,
                        "input": tool_input,
                    })

        elif event_type == "tool_result":
            if self.current_tool:
                self.current_tool["status"] = "done" if event.get("success", True) else "error"

                # Capture file content from Write tool result
                if self.current_tool["name"] == "Write" and event.get("success", True):
                    tool_input = self.current_tool.get("input", {})
                    file_path = tool_input.get("file_path", "")
                    content = tool_input.get("content", "")
                    if file_path and content:
                        self.synced_files.append(SyncedFile(
                            path=file_path,
                            content=content,
                            timestamp=datetime.now().isoformat(),
                        ))
                        self.files_created.append(file_path)

            self.current_tool = None

        elif event_type == "result":
            self.is_loading = False
            if self.current_response:
                self.messages.append({
                    "role": "assistant",
                    "content": self.current_response,
                })
            self.current_response = ""
            self._sync_pending_files()

        elif event_type == "error":
            error = event.get("error", "Unknown error")
            console.print(f"[red]Error: {error}[/red]")
            self.is_loading = False

    def _sync_pending_files(self):
        """Sync pending files to local filesystem."""
        for synced in self.synced_files:
            # Convert cloud path to local path
            cloud_path = synced.path
            # Remove leading /workspace/ or similar prefix
            if cloud_path.startswith("/workspace/"):
                local_rel = cloud_path[len("/workspace/"):]
            elif cloud_path.startswith("/"):
                local_rel = cloud_path[1:]
            else:
                local_rel = cloud_path

            local_full = self.local_path / local_rel

            try:
                # Create parent directories
                local_full.parent.mkdir(parents=True, exist_ok=True)
                # Write content
                local_full.write_text(synced.content)
            except Exception as e:
                console.print(f"[yellow]Warning: Could not sync {local_rel}: {e}[/yellow]")

        # Clear synced files
        self.synced_files.clear()
        self.pending_syncs.clear()

    def sync_file_to_local(self, cloud_path: str, content: str):
        """Sync a single file from cloud to local."""
        if cloud_path.startswith("/workspace/"):
            local_rel = cloud_path[len("/workspace/"):]
        elif cloud_path.startswith("/"):
            local_rel = cloud_path[1:]
        else:
            local_rel = cloud_path

        local_full = self.local_path / local_rel

        try:
            local_full.parent.mkdir(parents=True, exist_ok=True)
            local_full.write_text(content)
            return True
        except Exception:
            return False

    def download_workspace_files(self) -> list[str]:
        """
        Download all relevant files from the workspace at end of session.

        Returns list of downloaded file paths.
        """
        import urllib.request
        import urllib.error

        downloaded = []

        # Files to download
        important_files = [
            "CLAUDE.md",
            "doc/project/manifest.json",
            ".codrsync/manifest.json",
        ]

        # Also try to download any PRPs
        for pattern in ["doc/prps/*.md"]:
            # We'd need to list files - for now, try common names
            for i in range(1, 10):
                important_files.append(f"doc/prps/PRP-{i:03d}.md")

        for file_path in important_files:
            try:
                # Download from workspace container
                download_url = f"{self.session.workspace_url}/files/{file_path}"
                req = urllib.request.Request(
                    download_url,
                    headers={
                        "Authorization": f"Bearer {self.session.auth_token}",
                    },
                )

                with urllib.request.urlopen(req, timeout=10) as response:
                    content = response.read().decode("utf-8")
                    if self.sync_file_to_local(file_path, content):
                        downloaded.append(file_path)

            except Exception:
                continue  # File doesn't exist or not accessible

        return downloaded

    def _get_timer_display(self) -> str:
        """Get the timer display string."""
        remaining = self.session.time_remaining_str
        if self.session.is_trial_ended:
            return "[red bold]00:00 trial[/red bold]"
        elif self.session.is_trial_ending_soon:
            return f"[yellow bold]{remaining} trial[/yellow bold]"
        else:
            return f"[dim]{remaining} trial[/dim]"

    def render_header(self) -> Panel:
        """Render session header with timer."""
        if self.language == "pt":
            title = "codrsync init"
        else:
            title = "codrsync init"

        timer = self._get_timer_display()

        return Panel(
            f"[bold cyan]{title}[/bold cyan]                          {timer}",
            border_style="cyan",
            padding=(0, 1),
        )

    def render_messages(self) -> Panel:
        """Render message history for display."""
        # Format translations
        if self.language == "pt":
            ai_name = "Assistente"
            you_name = "Voce"
            thinking = "Pensando..."
            tool_label = "Ferramenta"
        else:
            ai_name = "Assistant"
            you_name = "You"
            thinking = "Thinking..."
            tool_label = "Tool"

        content_parts = []

        # Render history (last 5 messages to keep TUI clean)
        for msg in self.messages[-5:]:
            if msg["role"] == "user":
                content_parts.append(f"[bold green]{you_name}:[/bold green] {msg['content']}\n")
            else:
                content_parts.append(f"[bold cyan]{ai_name}:[/bold cyan]\n{msg['content']}\n")

        # Render current streaming response
        if self.current_response:
            content_parts.append(f"[bold cyan]{ai_name}:[/bold cyan]\n{self.current_response}")
            if self.is_loading:
                content_parts.append("[dim]...[/dim]")

        # Render current tool activity (user-friendly framing)
        if self.current_tool:
            tool_name = self.current_tool["name"]
            tool_input = self.current_tool.get("input", {})

            # User-friendly tool descriptions
            if tool_name == "Write":
                file_path = tool_input.get("file_path", "arquivo")
                if self.language == "pt":
                    tool_info = f"\n[yellow]Criando {file_path}...[/yellow]"
                else:
                    tool_info = f"\n[yellow]Creating {file_path}...[/yellow]"
            elif tool_name == "Edit":
                file_path = tool_input.get("file_path", "arquivo")
                if self.language == "pt":
                    tool_info = f"\n[yellow]Editando {file_path}...[/yellow]"
                else:
                    tool_info = f"\n[yellow]Editing {file_path}...[/yellow]"
            elif tool_name == "Read":
                file_path = tool_input.get("file_path", "arquivo")
                if self.language == "pt":
                    tool_info = f"\n[yellow]Lendo {file_path}...[/yellow]"
                else:
                    tool_info = f"\n[yellow]Reading {file_path}...[/yellow]"
            elif tool_name == "Bash":
                cmd = tool_input.get("command", "")[:40]
                if self.language == "pt":
                    tool_info = f"\n[yellow]Executando comando...[/yellow]"
                else:
                    tool_info = f"\n[yellow]Running command...[/yellow]"
            else:
                if self.language == "pt":
                    tool_info = f"\n[yellow]Analisando...[/yellow]"
                else:
                    tool_info = f"\n[yellow]Analyzing...[/yellow]"

            content_parts.append(tool_info)

        # Loading indicator
        if self.is_loading and not self.current_response and not self.current_tool:
            content_parts.append(f"\n[dim]{thinking}[/dim]")

        timer = self._get_timer_display()

        return Panel(
            "\n".join(content_parts) if content_parts else "[dim]...[/dim]",
            title=f"[bold cyan]codrsync init[/bold cyan]",
            subtitle=timer,
            border_style="cyan",
        )

    def show_trial_warning(self):
        """Show trial ending warning."""
        if self.trial_warning_shown:
            return

        self.trial_warning_shown = True

        if self.language == "pt":
            console.print(Panel(
                "[bold yellow]5 minutos restantes no trial![/bold yellow]\n\n"
                "Seus arquivos estao sendo salvos localmente.",
                border_style="yellow",
            ))
        else:
            console.print(Panel(
                "[bold yellow]5 minutes remaining in trial![/bold yellow]\n\n"
                "Your files are being saved locally.",
                border_style="yellow",
            ))

    def show_trial_ended(self) -> str:
        """
        Show trial ended dialog and get user choice.

        Returns: 'pro', 'free', or 'exit'
        """
        # First, sync any remaining files
        downloaded = self.download_workspace_files()

        # Show summary of work done
        if self.language == "pt":
            summary = "[bold]Nesta sessao voce:[/bold]\n"
            if self.files_created:
                for f in self.files_created[:5]:
                    summary += f"  [green]✓[/green] Criou {f}\n"
            summary += f"\n[green]✓[/green] Arquivos sincronizados para {self.local_path}"

            console.print(Panel(
                summary,
                title="[bold]Trial de 60 min encerrado![/bold]",
                border_style="yellow",
            ))

            console.print()
            console.print("[bold]Para continuar desenvolvendo:[/bold]")
            console.print()
            console.print("  [bold cyan][1][/bold cyan] Pro - R$47/mes [green](RECOMENDADO)[/green]")
            console.print("      Cloud + 500 creditos (AI + pptrsync)")
            console.print("      Continua de onde parou")
            console.print()
            console.print("  [bold cyan][2][/bold cyan] Free - R$0 (BYOK)")
            console.print("      Roda local + sua API key")
            console.print("      Metodologia CE completa")
            console.print()
            console.print("  [bold cyan][3][/bold cyan] Baixar projeto e sair")
            console.print("      Seus arquivos estao salvos em ./doc/")
            console.print()

            try:
                choice = console.input("[bold]Escolha [1/2/3]: [/bold]")
            except (EOFError, KeyboardInterrupt):
                choice = "3"

        else:
            summary = "[bold]In this session you:[/bold]\n"
            if self.files_created:
                for f in self.files_created[:5]:
                    summary += f"  [green]✓[/green] Created {f}\n"
            summary += f"\n[green]✓[/green] Files synced to {self.local_path}"

            console.print(Panel(
                summary,
                title="[bold]60-min trial ended![/bold]",
                border_style="yellow",
            ))

            console.print()
            console.print("[bold]To continue developing:[/bold]")
            console.print()
            console.print("  [bold cyan][1][/bold cyan] Pro - $29/month [green](RECOMMENDED)[/green]")
            console.print("      Cloud + 500 credits (AI + pptrsync)")
            console.print("      Continue where you left off")
            console.print()
            console.print("  [bold cyan][2][/bold cyan] Free - $0 (BYOK)")
            console.print("      Runs local + your API key")
            console.print("      Full CE methodology")
            console.print()
            console.print("  [bold cyan][3][/bold cyan] Download project and exit")
            console.print("      Your files are saved in ./doc/")
            console.print()

            try:
                choice = console.input("[bold]Choose [1/2/3]: [/bold]")
            except (EOFError, KeyboardInterrupt):
                choice = "3"

        choice = choice.strip()
        if choice == "1":
            return "pro"
        elif choice == "2":
            return "free"
        else:
            return "exit"

    def open_checkout(self, tier: str = "pro"):
        """Open Stripe checkout in browser."""
        import webbrowser
        checkout_url = f"{API_BASE}/api/billing/checkout?tier={tier}"
        webbrowser.open(checkout_url)

        if self.language == "pt":
            console.print("\n[green]Checkout aberto no navegador![/green]")
            console.print("[dim]Apos o pagamento, rode 'codrsync start' para continuar.[/dim]")
        else:
            console.print("\n[green]Checkout opened in browser![/green]")
            console.print("[dim]After payment, run 'codrsync start' to continue.[/dim]")

    def show_free_setup(self):
        """Show instructions for setting up free tier with BYOK."""
        if self.language == "pt":
            console.print("\n[bold]Configuracao do plano Free:[/bold]")
            console.print()
            console.print("1. Obtenha uma API key da Anthropic:")
            console.print("   [cyan]https://console.anthropic.com/api-keys[/cyan]")
            console.print()
            console.print("2. Configure a variavel de ambiente:")
            console.print("   [dim]export ANTHROPIC_API_KEY=sk-ant-...[/dim]")
            console.print()
            console.print("3. Continue desenvolvendo:")
            console.print("   [cyan]codrsync start --local[/cyan]")
        else:
            console.print("\n[bold]Free plan setup:[/bold]")
            console.print()
            console.print("1. Get an API key from Anthropic:")
            console.print("   [cyan]https://console.anthropic.com/api-keys[/cyan]")
            console.print()
            console.print("2. Set the environment variable:")
            console.print("   [dim]export ANTHROPIC_API_KEY=sk-ant-...[/dim]")
            console.print()
            console.print("3. Continue developing:")
            console.print("   [cyan]codrsync start --local[/cyan]")

    def show_exit_message(self):
        """Show exit message with saved files info."""
        if self.language == "pt":
            console.print("\n[green]Seus arquivos estao salvos![/green]")
            if self.files_created:
                console.print("[dim]Arquivos criados:[/dim]")
                for f in self.files_created[:10]:
                    # Convert to local path
                    if f.startswith("/workspace/"):
                        f = f[len("/workspace/"):]
                    console.print(f"  [dim]- {f}[/dim]")
            console.print()
            console.print("Volte quando quiser: [cyan]codrsync init[/cyan]")
        else:
            console.print("\n[green]Your files are saved![/green]")
            if self.files_created:
                console.print("[dim]Files created:[/dim]")
                for f in self.files_created[:10]:
                    if f.startswith("/workspace/"):
                        f = f[len("/workspace/"):]
                    console.print(f"  [dim]- {f}[/dim]")
            console.print()
            console.print("Come back anytime: [cyan]codrsync init[/cyan]")

    def run(self, initial_context: Optional[dict] = None):
        """
        Run the init session.

        Args:
            initial_context: Quick scan result to send as first message
        """
        if not self.connect():
            return False

        self.running = True

        # Start receive thread
        recv_thread = threading.Thread(target=self.receive_loop, daemon=True)
        recv_thread.start()

        # Wait for connection to establish
        time.sleep(1)

        # Send initial context if provided
        if initial_context:
            context_str = json.dumps(initial_context, indent=2)
            if self.language == "pt":
                initial_msg = f"Contexto do projeto local:\n```json\n{context_str}\n```\n\nAjude-me a configurar este projeto com a metodologia Context Engineering."
            else:
                initial_msg = f"Local project context:\n```json\n{context_str}\n```\n\nHelp me set up this project with the Context Engineering methodology."
            self.send_message(initial_msg)

        try:
            while self.running:
                # Check trial time
                if self.session.is_trial_ending_soon and not self.trial_warning_shown:
                    self.show_trial_warning()

                if self.session.is_trial_ended:
                    # Handle trial end
                    choice = self.show_trial_ended()
                    if choice == "pro":
                        self.open_checkout("pro")
                    elif choice == "free":
                        self.show_free_setup()
                    else:
                        self.show_exit_message()
                    break

                # Process pending events
                while not self.event_queue.empty():
                    try:
                        event = self.event_queue.get_nowait()
                        self.handle_event(event)
                    except queue.Empty:
                        break

                # If loading, show updates
                if self.is_loading or self.current_response or self.current_tool:
                    with Live(self.render_messages(), console=console, refresh_per_second=4) as live:
                        while self.is_loading or self.current_response or self.current_tool:
                            # Process events
                            while not self.event_queue.empty():
                                try:
                                    event = self.event_queue.get_nowait()
                                    self.handle_event(event)
                                except queue.Empty:
                                    break

                            live.update(self.render_messages())
                            time.sleep(0.1)

                            # Check trial during long operations
                            if self.session.is_trial_ended:
                                break

                        live.update(self.render_messages())
                    console.print()
                    continue

                # Get user input
                try:
                    if self.language == "pt":
                        user_input = console.input("[bold green]> [/bold green]")
                    else:
                        user_input = console.input("[bold green]> [/bold green]")
                except EOFError:
                    break

                if not user_input.strip():
                    continue

                if user_input.strip().lower() in ["/exit", "/quit", "/sair", "exit", "quit", "sair"]:
                    self.show_exit_message()
                    break

                if user_input.strip().lower() in ["/status", "/tempo"]:
                    if self.language == "pt":
                        console.print(f"[cyan]Tempo restante:[/cyan] {self.session.time_remaining_str}")
                    else:
                        console.print(f"[cyan]Time remaining:[/cyan] {self.session.time_remaining_str}")
                    continue

                # Send message
                self.send_message(user_input)

        except KeyboardInterrupt:
            console.print()
            self.show_exit_message()
        finally:
            self.running = False
            self.disconnect()

        return True


def start_init_session(
    access_token: str,
    local_path: Path,
    project_context: dict,
    language: str = "pt",
) -> bool:
    """
    Start a cloud init session for project initialization.

    This is the main entry point for `codrsync init` with cloud concierge.

    Args:
        access_token: Device token from codrsync auth
        local_path: Local project directory
        project_context: Quick scan result dictionary
        language: Language preference ('pt' or 'en')

    Returns:
        True if session completed successfully
    """
    # Check for existing workspace first
    session = check_active_workspace(access_token)

    if session:
        if language == "pt":
            console.print(f"[cyan]Retomando sessao existente...[/cyan]")
        else:
            console.print(f"[cyan]Resuming existing session...[/cyan]")
    else:
        # Provision new init workspace
        if language == "pt":
            console.print("[dim]Conectando ao assistente AI...[/dim]")
        else:
            console.print("[dim]Connecting to AI assistant...[/dim]")

        session = provision_workspace_init(
            access_token=access_token,
            project_context=project_context,
            language=language,
        )

        if not session:
            return False

    # Run init TUI
    tui = CloudInitSession(
        session=session,
        local_path=local_path,
        language=language,
    )

    return tui.run(initial_context=project_context)
