"""
Connect package - check and display integration status for external services.

Includes:
- Standard connectors (Supabase, Vercel, GitHub, etc.) - status checking
- OAuth integrations (Notion, Jira) - full connection and sync support
"""

from codrsync.connect.base import ConnectorBase, ConnectorResult
from codrsync.connect.connect import run, CONNECTORS, OAUTH_PROVIDERS
from codrsync.connect.notion import NotionConnector, connect_notion, link_notion_database

__all__ = [
    "ConnectorBase",
    "ConnectorResult",
    "run",
    "CONNECTORS",
    "OAUTH_PROVIDERS",
    "NotionConnector",
    "connect_notion",
    "link_notion_database",
]
