"""
Notion connector - Check Notion integration status and manage OAuth.
"""

import asyncio
import json
import time
from pathlib import Path
from typing import Optional, Dict, Any

from rich.console import Console
from rich.prompt import Prompt
import questionary

from codrsync.connect.base import ConnectorBase, ConnectorResult
from codrsync.i18n import t

console = Console()


class NotionConnector(ConnectorBase):
    """Connector for Notion integration."""

    AUTH_API_BASE = "https://auth.codrsync.dev"
    POLL_INTERVAL = 5  # seconds
    POLL_TIMEOUT = 300  # 5 minutes

    def service_name(self) -> str:
        return "notion"

    def required_cli(self) -> Optional[str]:
        return None  # No CLI required for Notion

    def check(self, project_path: Path) -> ConnectorResult:
        """Check Notion integration status."""
        codrsync_dir = project_path / ".codrsync"
        integrations_path = codrsync_dir / "integrations.json"

        if not integrations_path.exists():
            return ConnectorResult(
                service="notion",
                connected=False,
                status="not_configured",
                details={"reason": "No integrations configured"},
            )

        try:
            data = json.loads(integrations_path.read_text())
            for integration in data.get("integrations", []):
                if integration.get("provider") == "notion":
                    return ConnectorResult(
                        service="notion",
                        connected=True,
                        status="connected",
                        details={
                            "workspace": integration.get("workspace_name"),
                            "project": integration.get("project_name"),
                            "sync_direction": integration.get("sync_direction"),
                        },
                    )
        except (json.JSONDecodeError, IOError):
            pass

        return ConnectorResult(
            service="notion",
            connected=False,
            status="not_configured",
            details={"reason": "Notion not connected"},
        )

    async def start_auth(self) -> Dict[str, str]:
        """Start device authorization flow.

        Returns:
            Dictionary with device_code, user_code, verification_url
        """
        import httpx

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.AUTH_API_BASE}/api/integrations/notion/device-code",
                json={"provider": "notion"},
                timeout=30.0,
            )
            response.raise_for_status()
            return response.json()

    async def poll_auth(self, device_code: str) -> Optional[Dict[str, Any]]:
        """Poll for authorization completion.

        Args:
            device_code: Device code from start_auth

        Returns:
            Token data if authorized, None if still pending
        """
        import httpx

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.AUTH_API_BASE}/api/integrations/notion/device-token",
                json={"device_code": device_code},
                timeout=30.0,
            )

            if response.status_code == 202:
                return None  # Still pending

            if response.status_code == 200:
                return response.json()

            response.raise_for_status()
            return None

    async def list_databases(self, access_token: str) -> list[Dict[str, Any]]:
        """List available Notion databases.

        Args:
            access_token: Notion access token

        Returns:
            List of database info
        """
        import httpx

        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.notion.com/v1/search",
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "Content-Type": "application/json",
                    "Notion-Version": "2022-06-28",
                },
                json={
                    "filter": {"property": "object", "value": "database"},
                    "page_size": 100,
                },
                timeout=30.0,
            )
            response.raise_for_status()
            data = response.json()

            databases = []
            for db in data.get("results", []):
                title_parts = db.get("title", [])
                title = "".join(t.get("plain_text", "") for t in title_parts) or "Untitled"
                databases.append({
                    "id": db["id"],
                    "name": title,
                    "url": db.get("url"),
                })

            return databases


def connect_notion(project_path: Path) -> bool:
    """Interactive Notion connection flow.

    Args:
        project_path: Project directory path

    Returns:
        True if connected successfully
    """
    connector = NotionConnector()

    console.print("\n[bold cyan]Connecting to Notion[/bold cyan]\n")
    console.print("This will open a browser window to authorize codrsync with your Notion workspace.\n")

    try:
        # Start device auth
        console.print("[dim]Starting authorization...[/dim]")
        auth_data = asyncio.run(connector.start_auth())

        user_code = auth_data.get("user_code", "")
        verification_url = auth_data.get("verification_url", f"{connector.AUTH_API_BASE}/connect/notion")
        device_code = auth_data.get("device_code", "")

        console.print(f"\n[bold]1. Open this URL:[/bold] [link={verification_url}]{verification_url}[/link]")
        console.print(f"[bold]2. Enter this code:[/bold] [yellow]{user_code}[/yellow]")
        console.print("\n[dim]Waiting for authorization (Ctrl+C to cancel)...[/dim]\n")

        # Poll for completion
        start_time = time.time()
        token_data = None

        while time.time() - start_time < connector.POLL_TIMEOUT:
            token_data = asyncio.run(connector.poll_auth(device_code))
            if token_data:
                break
            time.sleep(connector.POLL_INTERVAL)

        if not token_data:
            console.print("[red]Authorization timed out. Please try again.[/red]")
            return False

        console.print("[green]Authorization successful![/green]\n")

        # Get access token
        access_token = token_data.get("access_token")
        workspace_name = token_data.get("workspace_name", "Notion Workspace")

        # List databases and let user select
        console.print("[dim]Fetching available databases...[/dim]")
        databases = asyncio.run(connector.list_databases(access_token))

        if not databases:
            console.print("[yellow]No databases found. Make sure you've shared at least one database with the integration.[/yellow]")
            console.print("[dim]You can add a database later with: codrsync connect notion --link[/dim]")

            # Save minimal config
            _save_integration_config(
                project_path,
                access_token=access_token,
                workspace_name=workspace_name,
            )
            return True

        # Let user select database
        choices = [{"name": f"{db['name']} ({db['id'][:8]}...)", "value": db} for db in databases]
        choices.append({"name": "Skip for now", "value": None})

        selected = questionary.select(
            "Select a database to link with this project:",
            choices=choices,
        ).ask()

        # Save config
        _save_integration_config(
            project_path,
            access_token=access_token,
            workspace_name=workspace_name,
            project_id=selected["id"] if selected else None,
            project_name=selected["name"] if selected else None,
        )

        console.print(f"\n[green]Connected to Notion workspace: {workspace_name}[/green]")
        if selected:
            console.print(f"[green]Linked to database: {selected['name']}[/green]")
        console.print("\n[dim]Use 'codrsync sync --to notion' to sync your stories.[/dim]")

        return True

    except KeyboardInterrupt:
        console.print("\n[yellow]Cancelled.[/yellow]")
        return False
    except Exception as e:
        console.print(f"\n[red]Error: {str(e)}[/red]")
        return False


def link_notion_database(project_path: Path) -> bool:
    """Link project to a Notion database (requires existing connection).

    Args:
        project_path: Project directory path

    Returns:
        True if linked successfully
    """
    codrsync_dir = project_path / ".codrsync"
    integrations_path = codrsync_dir / "integrations.json"

    if not integrations_path.exists():
        console.print("[yellow]Not connected to Notion. Run 'codrsync connect notion' first.[/yellow]")
        return False

    try:
        data = json.loads(integrations_path.read_text())
        notion_config = None

        for integration in data.get("integrations", []):
            if integration.get("provider") == "notion":
                notion_config = integration
                break

        if not notion_config:
            console.print("[yellow]Not connected to Notion. Run 'codrsync connect notion' first.[/yellow]")
            return False

        access_token = notion_config.get("access_token")
        if not access_token:
            console.print("[red]Invalid Notion configuration. Please reconnect.[/red]")
            return False

        # List databases
        connector = NotionConnector()
        console.print("[dim]Fetching available databases...[/dim]")
        databases = asyncio.run(connector.list_databases(access_token))

        if not databases:
            console.print("[yellow]No databases found.[/yellow]")
            return False

        # Let user select
        choices = [{"name": f"{db['name']} ({db['id'][:8]}...)", "value": db} for db in databases]

        selected = questionary.select(
            "Select a database to link:",
            choices=choices,
        ).ask()

        if not selected:
            return False

        # Update config
        notion_config["project_id"] = selected["id"]
        notion_config["project_name"] = selected["name"]

        integrations_path.write_text(json.dumps(data, indent=2))

        console.print(f"\n[green]Linked to database: {selected['name']}[/green]")
        return True

    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        return False


def _save_integration_config(
    project_path: Path,
    access_token: str,
    workspace_name: str,
    project_id: Optional[str] = None,
    project_name: Optional[str] = None,
) -> None:
    """Save Notion integration config to .codrsync/integrations.json."""
    codrsync_dir = project_path / ".codrsync"
    codrsync_dir.mkdir(parents=True, exist_ok=True)
    integrations_path = codrsync_dir / "integrations.json"

    # Load existing or create new
    if integrations_path.exists():
        try:
            data = json.loads(integrations_path.read_text())
        except (json.JSONDecodeError, IOError):
            data = {"integrations": [], "mappings": {}}
    else:
        data = {"integrations": [], "mappings": {}}

    # Remove existing Notion config
    data["integrations"] = [
        i for i in data.get("integrations", [])
        if i.get("provider") != "notion"
    ]

    # Add new config
    data["integrations"].append({
        "provider": "notion",
        "workspace_name": workspace_name,
        "workspace_id": "",  # Notion doesn't provide this easily
        "project_id": project_id,
        "project_name": project_name,
        "sync_direction": "export",
        "source_of_truth": "codrsync",
        "access_token": access_token,
        "field_mappings": {},
    })

    integrations_path.write_text(json.dumps(data, indent=2))
