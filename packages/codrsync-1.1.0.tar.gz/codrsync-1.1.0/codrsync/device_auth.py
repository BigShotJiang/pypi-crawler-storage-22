"""
Device Code OAuth Flow for codrsync CLI

Implements RFC 8628 Device Authorization Grant for CLI authentication
with codrsync.dev without requiring a browser redirect callback.

Flow:
1. CLI requests a device code from the server
2. Server returns device_code + user_code + verification_url
3. User opens URL in browser and enters the code
4. CLI polls for token until user authorizes
5. Token is stored locally for future API calls
"""

import time
import webbrowser
from typing import Optional
import urllib.request
import urllib.error
import json

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()

# API Configuration
API_BASE = "https://codrsync.dev/api/auth"


def device_code_login(config) -> bool:
    """
    Perform device code login flow.

    Args:
        config: Config object to store the token

    Returns:
        True if login successful, False otherwise
    """
    from codrsync.i18n import t

    try:
        # Step 1: Request device code
        console.print("[dim]Requesting authentication code...[/dim]")
        device_code_response = _request_device_code()

        if not device_code_response:
            console.print("[red]Failed to get device code from server[/red]")
            return False

        device_code = device_code_response["device_code"]
        user_code = device_code_response["user_code"]
        verification_uri = device_code_response["verification_uri"]
        expires_in = device_code_response.get("expires_in", 900)
        interval = device_code_response.get("interval", 5)

        # Step 2: Display code to user
        console.print()
        console.print(Panel(
            f"[bold cyan]Your verification code:[/bold cyan]\n\n"
            f"    [bold yellow]{user_code}[/bold yellow]\n\n"
            f"[dim]Open the following URL in your browser:[/dim]\n"
            f"    [link={verification_uri}]{verification_uri}[/link]",
            title="[bold]Device Authentication[/bold]",
            border_style="cyan",
        ))
        console.print()

        # Try to open browser automatically
        try:
            webbrowser.open(verification_uri)
            console.print("[dim]Browser opened automatically.[/dim]")
        except Exception:
            console.print("[dim]Please open the URL manually in your browser.[/dim]")

        # Step 3: Poll for token
        console.print()
        console.print("[dim]Waiting for you to authorize in the browser...[/dim]")
        console.print("[dim]Press Ctrl+C to cancel.[/dim]\n")

        token_response = _poll_for_token(
            device_code=device_code,
            interval=interval,
            expires_in=expires_in,
        )

        if not token_response:
            return False

        # Step 4: Store token
        config.codrsync_device_token = token_response["access_token"]
        config.codrsync_user_email = token_response.get("email")
        config.codrsync_token_expires_at = token_response.get("expires_at")
        config.save()

        return True

    except KeyboardInterrupt:
        console.print("\n[yellow]Authentication cancelled.[/yellow]")
        return False
    except Exception as e:
        console.print(f"[red]Authentication error: {e}[/red]")
        return False


def _request_device_code() -> Optional[dict]:
    """Request a device code from the server."""
    import platform
    import socket

    try:
        # Collect client info
        client_info = {
            "hostname": socket.gethostname(),
            "platform": platform.system(),
            "arch": platform.machine(),
            "python_version": platform.python_version(),
        }

        data = json.dumps({"client_info": client_info}).encode("utf-8")

        req = urllib.request.Request(
            f"{API_BASE}/device-code",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))

    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8") if e.fp else ""
        console.print(f"[red]Server error: {e.code} - {error_body}[/red]")
        return None
    except urllib.error.URLError as e:
        console.print(f"[red]Connection error: {e.reason}[/red]")
        console.print("[dim]Check your internet connection and try again.[/dim]")
        return None
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        return None


def _poll_for_token(device_code: str, interval: int, expires_in: int) -> Optional[dict]:
    """Poll for the access token."""
    start_time = time.time()
    poll_interval = interval

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Waiting for authorization...", total=None)

        while time.time() - start_time < expires_in:
            try:
                data = json.dumps({"device_code": device_code}).encode("utf-8")

                req = urllib.request.Request(
                    f"{API_BASE}/device-token",
                    data=data,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )

                with urllib.request.urlopen(req, timeout=30) as response:
                    result = json.loads(response.read().decode("utf-8"))

                    if result.get("access_token"):
                        return result

            except urllib.error.HTTPError as e:
                error_body = json.loads(e.read().decode("utf-8")) if e.fp else {}
                error_type = error_body.get("error")

                if error_type == "authorization_pending":
                    # User hasn't authorized yet, keep polling
                    pass
                elif error_type == "slow_down":
                    # Increase polling interval
                    poll_interval = min(poll_interval + 5, 30)
                elif error_type == "expired_token":
                    console.print("[yellow]Authentication code expired. Please try again.[/yellow]")
                    return None
                elif error_type == "access_denied":
                    console.print("[yellow]Authentication was denied.[/yellow]")
                    return None
                else:
                    console.print(f"[red]Error: {error_body.get('error_description', error_type)}[/red]")
                    return None

            except urllib.error.URLError:
                # Network error, retry
                pass

            # Wait before next poll
            time.sleep(poll_interval)

    console.print("[yellow]Authentication timed out. Please try again.[/yellow]")
    return None


def refresh_token(config) -> bool:
    """
    Refresh the device token if it's expired or about to expire.

    Args:
        config: Config object with the current token

    Returns:
        True if token is valid or refreshed, False if re-auth needed
    """
    if not config.codrsync_device_token:
        return False

    # Check expiration
    if config.codrsync_token_expires_at:
        from datetime import datetime, timedelta

        try:
            expires_at = datetime.fromisoformat(
                config.codrsync_token_expires_at.replace("Z", "+00:00")
            )
            now = datetime.now(expires_at.tzinfo)

            # If expired, need to re-auth
            if expires_at < now:
                console.print("[yellow]Session expired. Please re-authenticate.[/yellow]")
                return False

            # If expiring within 24h, could refresh (not implemented yet)
            # For now, just return True if not expired
        except Exception:
            pass

    return True


def logout(config) -> bool:
    """
    Clear stored authentication credentials.

    Args:
        config: Config object

    Returns:
        True if logout successful
    """
    config.codrsync_device_token = None
    config.codrsync_user_email = None
    config.codrsync_token_expires_at = None

    if config.ai_backend == "codrsync-credits":
        config.ai_backend = "auto"

    config.save()
    console.print("[green]✓[/green] Logged out successfully")
    return True


def get_credits_balance(config) -> Optional[dict]:
    """
    Get current credits balance from codrsync.dev.

    Args:
        config: Config object with device token

    Returns:
        Credits summary dict or None if error
    """
    if not config.codrsync_device_token:
        return None

    try:
        req = urllib.request.Request(
            "https://codrsync.dev/api/credits",
            headers={
                "Authorization": f"Bearer {config.codrsync_device_token}",
            },
            method="GET",
        )

        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))

    except urllib.error.HTTPError as e:
        if e.code == 401:
            console.print("[yellow]Session expired. Please re-authenticate with 'codrsync auth'[/yellow]")
        return None
    except Exception:
        return None


def call_credits_ai(config, feature: str, messages: list, model: str = "claude-sonnet") -> Optional[dict]:
    """
    Make an AI request using codrsync credits.

    Args:
        config: Config object with device token
        feature: Feature name ('chat', 'init', 'build', 'prp')
        messages: List of message dicts with 'role' and 'content'
        model: Model to use

    Returns:
        Response dict with 'response', 'credits_used', 'credits_remaining' or None if error
    """
    if not config.codrsync_device_token:
        console.print("[yellow]Not authenticated. Run 'codrsync auth' first.[/yellow]")
        return None

    try:
        data = json.dumps({
            "feature": feature,
            "messages": messages,
            "model": model,
        }).encode("utf-8")

        req = urllib.request.Request(
            "https://codrsync.dev/api/credits/ai",
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {config.codrsync_device_token}",
            },
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=120) as response:
            return json.loads(response.read().decode("utf-8"))

    except urllib.error.HTTPError as e:
        error_body = json.loads(e.read().decode("utf-8")) if e.fp else {}

        if e.code == 401:
            console.print("[yellow]Session expired. Please re-authenticate with 'codrsync auth'[/yellow]")
        elif e.code == 402:
            console.print("[yellow]Insufficient credits.[/yellow]")
            console.print(f"[dim]Current balance: {error_body.get('balance', 0)} credits[/dim]")
            console.print("[dim]Buy more at: codrsync credits buy[/dim]")
        else:
            console.print(f"[red]Error: {error_body.get('error', 'Unknown error')}[/red]")

        return None
    except Exception as e:
        console.print(f"[red]Connection error: {e}[/red]")
        return None
