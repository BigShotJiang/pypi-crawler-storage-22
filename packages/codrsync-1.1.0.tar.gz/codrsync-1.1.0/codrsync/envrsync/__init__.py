"""
envrsync - Environment scanning and analysis module.

Provides quick scanning of project environments for the init command
and detailed analysis for the standalone envrsync command.
"""

from .scan import (
    QuickScanResult,
    quick_scan,
    format_scan_result,
    get_project_summary,
)

__all__ = [
    "QuickScanResult",
    "quick_scan",
    "format_scan_result",
    "get_project_summary",
]
