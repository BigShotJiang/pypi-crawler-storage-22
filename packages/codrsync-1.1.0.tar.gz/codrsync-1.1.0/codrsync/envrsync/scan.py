"""
Quick environment scanning for codrsync init and envrsync standalone.

Provides fast project analysis that runs locally before cloud connection,
making the UX feel familiar and responsive.
"""

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from ..scanner.detector import detect, DetectionResult, has_existing_code

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]


@dataclass
class FileInfo:
    """Information about a detected file."""
    path: str
    size_bytes: int
    type: str  # 'config', 'source', 'doc', 'asset'


@dataclass
class DependencyInfo:
    """Information about a dependency."""
    name: str
    version: Optional[str]
    type: str  # 'runtime', 'dev', 'peer', 'optional'


@dataclass
class QuickScanResult:
    """Result of quick project scan for init command."""

    # Project detection
    has_code: bool = False
    is_empty: bool = True
    project_name: Optional[str] = None

    # Stack detection (from detector.py)
    detection: Optional[DetectionResult] = None

    # Key files found
    key_files: list[FileInfo] = field(default_factory=list)

    # Project size metrics
    total_files: int = 0
    source_files: int = 0
    config_files: int = 0

    # Dependencies
    dependencies: list[DependencyInfo] = field(default_factory=list)
    node_version: Optional[str] = None
    python_version: Optional[str] = None

    # Directories
    has_src: bool = False
    has_tests: bool = False
    has_docs: bool = False
    has_git: bool = False

    # Special files
    has_claude_md: bool = False
    has_env_file: bool = False
    has_dockerfile: bool = False
    has_manifest: bool = False

    def to_dict(self) -> dict:
        """Convert to dictionary for API transmission."""
        return {
            "has_code": self.has_code,
            "is_empty": self.is_empty,
            "project_name": self.project_name,
            "stack": self.detection.to_dict() if self.detection else {},
            "key_files": [
                {"path": f.path, "size": f.size_bytes, "type": f.type}
                for f in self.key_files
            ],
            "metrics": {
                "total_files": self.total_files,
                "source_files": self.source_files,
                "config_files": self.config_files,
            },
            "dependencies": [
                {"name": d.name, "version": d.version, "type": d.type}
                for d in self.dependencies[:20]  # Limit to top 20
            ],
            "versions": {
                "node": self.node_version,
                "python": self.python_version,
            },
            "directories": {
                "has_src": self.has_src,
                "has_tests": self.has_tests,
                "has_docs": self.has_docs,
                "has_git": self.has_git,
            },
            "special_files": {
                "has_claude_md": self.has_claude_md,
                "has_env_file": self.has_env_file,
                "has_dockerfile": self.has_dockerfile,
                "has_manifest": self.has_manifest,
            },
        }

    @property
    def primary_language(self) -> Optional[str]:
        """Get the primary detected language."""
        if self.detection and self.detection.languages:
            return self.detection.languages[0]
        return None

    @property
    def primary_framework(self) -> Optional[str]:
        """Get the primary detected framework."""
        if self.detection and self.detection.frameworks:
            return self.detection.frameworks[0]
        return None

    def get_stack_summary(self) -> str:
        """Get a human-readable stack summary."""
        parts = []
        if self.detection:
            if self.detection.languages:
                parts.append(self.detection.languages[0])
            if self.detection.frameworks:
                parts.append(self.detection.frameworks[0])
        return " + ".join(parts) if parts else "Unknown"


def _count_files(path: Path, extensions: set[str], max_depth: int = 3) -> int:
    """Count files with given extensions up to max depth."""
    count = 0
    try:
        for root, dirs, files in os.walk(path):
            # Calculate depth
            depth = str(root).replace(str(path), "").count(os.sep)
            if depth >= max_depth:
                dirs.clear()  # Don't go deeper
                continue

            # Skip common non-source directories
            dirs[:] = [d for d in dirs if d not in {
                "node_modules", ".git", "__pycache__", ".venv", "venv",
                "dist", "build", ".next", ".nuxt", "coverage", ".pytest_cache",
            }]

            for f in files:
                if any(f.endswith(ext) for ext in extensions):
                    count += 1
    except PermissionError:
        pass
    return count


def _get_file_info(path: Path, file_path: str, file_type: str) -> Optional[FileInfo]:
    """Get file info if file exists."""
    full_path = path / file_path
    if full_path.exists():
        try:
            size = full_path.stat().st_size
            return FileInfo(path=file_path, size_bytes=size, type=file_type)
        except (OSError, PermissionError):
            return FileInfo(path=file_path, size_bytes=0, type=file_type)
    return None


def _parse_npm_deps(pkg: dict) -> tuple[list[DependencyInfo], Optional[str]]:
    """Parse npm dependencies and node version from package.json."""
    deps = []

    # Runtime dependencies
    for name, version in pkg.get("dependencies", {}).items():
        deps.append(DependencyInfo(name=name, version=str(version), type="runtime"))

    # Dev dependencies
    for name, version in pkg.get("devDependencies", {}).items():
        deps.append(DependencyInfo(name=name, version=str(version), type="dev"))

    # Peer dependencies
    for name, version in pkg.get("peerDependencies", {}).items():
        deps.append(DependencyInfo(name=name, version=str(version), type="peer"))

    # Node version from engines
    node_version = pkg.get("engines", {}).get("node")

    return deps, node_version


def _parse_python_deps(pyproject: dict) -> tuple[list[DependencyInfo], Optional[str]]:
    """Parse Python dependencies and version from pyproject.toml."""
    deps = []
    python_version = None

    # Standard dependencies [project.dependencies]
    for dep_str in pyproject.get("project", {}).get("dependencies", []):
        name = dep_str.split(">=")[0].split("==")[0].split("<")[0].split("[")[0].strip()
        version = None
        if ">=" in dep_str:
            version = ">=" + dep_str.split(">=")[1].split(",")[0].strip()
        elif "==" in dep_str:
            version = dep_str.split("==")[1].split(",")[0].strip()
        deps.append(DependencyInfo(name=name, version=version, type="runtime"))

    # Poetry dependencies [tool.poetry.dependencies]
    poetry_deps = pyproject.get("tool", {}).get("poetry", {}).get("dependencies", {})
    for name, spec in poetry_deps.items():
        if name == "python":
            python_version = spec if isinstance(spec, str) else spec.get("version")
            continue
        version = spec if isinstance(spec, str) else spec.get("version")
        deps.append(DependencyInfo(name=name, version=version, type="runtime"))

    # Poetry dev dependencies
    poetry_dev = pyproject.get("tool", {}).get("poetry", {}).get("group", {}).get("dev", {}).get("dependencies", {})
    for name, spec in poetry_dev.items():
        version = spec if isinstance(spec, str) else spec.get("version")
        deps.append(DependencyInfo(name=name, version=version, type="dev"))

    # Python version from [project]
    if not python_version:
        python_version = pyproject.get("project", {}).get("requires-python")

    return deps, python_version


def quick_scan(path: Path) -> QuickScanResult:
    """
    Perform a quick scan of a project directory.

    This is designed to be fast (< 3 seconds) and run locally before
    connecting to the cloud concierge. It provides enough context for
    a meaningful initial conversation.

    Args:
        path: Directory to scan

    Returns:
        QuickScanResult with project information
    """
    result = QuickScanResult()

    # Check if directory exists
    if not path.exists() or not path.is_dir():
        return result

    # Check for existing code
    result.has_code = has_existing_code(path)
    result.is_empty = not result.has_code

    # Run stack detection
    result.detection = detect(path)

    # Get project name
    # Try package.json first
    pkg_path = path / "package.json"
    if pkg_path.exists():
        try:
            with open(pkg_path) as f:
                pkg = json.load(f)
                result.project_name = pkg.get("name")
                deps, node_ver = _parse_npm_deps(pkg)
                result.dependencies.extend(deps)
                result.node_version = node_ver
        except (json.JSONDecodeError, OSError):
            pass

    # Try pyproject.toml
    pyproject_path = path / "pyproject.toml"
    if pyproject_path.exists() and tomllib:
        try:
            with open(pyproject_path, "rb") as f:
                pyproject = tomllib.load(f)
                if not result.project_name:
                    result.project_name = (
                        pyproject.get("project", {}).get("name") or
                        pyproject.get("tool", {}).get("poetry", {}).get("name")
                    )
                deps, py_ver = _parse_python_deps(pyproject)
                result.dependencies.extend(deps)
                result.python_version = py_ver
        except Exception:
            pass

    # Fallback to directory name
    if not result.project_name:
        result.project_name = path.name

    # Check key files
    key_file_checks = [
        ("package.json", "config"),
        ("pyproject.toml", "config"),
        ("requirements.txt", "config"),
        ("go.mod", "config"),
        ("Cargo.toml", "config"),
        ("CLAUDE.md", "doc"),
        ("README.md", "doc"),
        (".env", "config"),
        (".env.example", "config"),
        ("Dockerfile", "config"),
        ("docker-compose.yml", "config"),
        ("docker-compose.yaml", "config"),
        ("tsconfig.json", "config"),
        ("next.config.js", "config"),
        ("next.config.ts", "config"),
        ("vite.config.ts", "config"),
        ("tailwind.config.js", "config"),
        ("tailwind.config.ts", "config"),
    ]

    for file_path, file_type in key_file_checks:
        info = _get_file_info(path, file_path, file_type)
        if info:
            result.key_files.append(info)

    # Check directories
    result.has_src = (path / "src").is_dir()
    result.has_tests = (
        (path / "tests").is_dir() or
        (path / "test").is_dir() or
        (path / "__tests__").is_dir()
    )
    result.has_docs = (
        (path / "docs").is_dir() or
        (path / "doc").is_dir()
    )
    result.has_git = (path / ".git").is_dir()

    # Check special files
    result.has_claude_md = (path / "CLAUDE.md").exists()
    result.has_env_file = (path / ".env").exists() or (path / ".env.example").exists()
    result.has_dockerfile = (path / "Dockerfile").exists()
    result.has_manifest = (
        (path / "doc" / "project" / "manifest.json").exists() or
        (path / ".codrsync" / "manifest.json").exists()
    )

    # Count files
    source_extensions = {".js", ".ts", ".jsx", ".tsx", ".py", ".go", ".rs", ".java", ".rb", ".php"}
    config_extensions = {".json", ".yaml", ".yml", ".toml", ".xml", ".env"}

    result.source_files = _count_files(path, source_extensions)
    result.config_files = _count_files(path, config_extensions)
    result.total_files = result.source_files + result.config_files

    return result


def format_scan_result(result: QuickScanResult, language: str = "pt") -> str:
    """
    Format scan result for terminal display.

    Args:
        result: QuickScanResult to format
        language: 'pt' or 'en'

    Returns:
        Formatted string for rich console
    """
    lines = []

    if language == "pt":
        if result.is_empty:
            lines.append("[dim]Nenhum arquivo de projeto encontrado[/dim]")
        else:
            # Stack
            stack = result.get_stack_summary()
            lines.append(f"[green]Stack:[/green] {stack}")

            # Key files
            if result.key_files:
                found = [f.path for f in result.key_files[:5]]
                lines.append(f"[green]Arquivos:[/green] {', '.join(found)}")

            # Metrics
            if result.source_files > 0:
                lines.append(f"[green]Tamanho:[/green] {result.source_files} arquivos de codigo")

            # Directories
            dirs = []
            if result.has_src:
                dirs.append("src/")
            if result.has_tests:
                dirs.append("tests/")
            if result.has_docs:
                dirs.append("docs/")
            if dirs:
                lines.append(f"[green]Pastas:[/green] {', '.join(dirs)}")

            # Special indicators
            indicators = []
            if result.has_git:
                indicators.append("Git")
            if result.has_claude_md:
                indicators.append("CLAUDE.md")
            if result.has_dockerfile:
                indicators.append("Docker")
            if indicators:
                lines.append(f"[dim]Detectado: {', '.join(indicators)}[/dim]")
    else:
        if result.is_empty:
            lines.append("[dim]No project files found[/dim]")
        else:
            # Stack
            stack = result.get_stack_summary()
            lines.append(f"[green]Stack:[/green] {stack}")

            # Key files
            if result.key_files:
                found = [f.path for f in result.key_files[:5]]
                lines.append(f"[green]Files:[/green] {', '.join(found)}")

            # Metrics
            if result.source_files > 0:
                lines.append(f"[green]Size:[/green] {result.source_files} source files")

            # Directories
            dirs = []
            if result.has_src:
                dirs.append("src/")
            if result.has_tests:
                dirs.append("tests/")
            if result.has_docs:
                dirs.append("docs/")
            if dirs:
                lines.append(f"[green]Folders:[/green] {', '.join(dirs)}")

            # Special indicators
            indicators = []
            if result.has_git:
                indicators.append("Git")
            if result.has_claude_md:
                indicators.append("CLAUDE.md")
            if result.has_dockerfile:
                indicators.append("Docker")
            if indicators:
                lines.append(f"[dim]Detected: {', '.join(indicators)}[/dim]")

    return "\n".join(lines)


def get_project_summary(result: QuickScanResult, language: str = "pt") -> str:
    """
    Get a short summary string for the project.

    Used in the concierge greeting message context.

    Args:
        result: QuickScanResult
        language: 'pt' or 'en'

    Returns:
        Short summary string
    """
    if result.is_empty:
        if language == "pt":
            return "projeto vazio"
        return "empty project"

    parts = []

    # Project name
    if result.project_name:
        parts.append(result.project_name)

    # Stack
    stack = result.get_stack_summary()
    if stack != "Unknown":
        parts.append(f"({stack})")

    # Size indicator
    if result.source_files > 100:
        if language == "pt":
            parts.append("- projeto grande")
        else:
            parts.append("- large project")
    elif result.source_files > 30:
        if language == "pt":
            parts.append("- projeto medio")
        else:
            parts.append("- medium project")

    return " ".join(parts)


# Quick test
if __name__ == "__main__":
    import sys

    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    result = quick_scan(path)

    print(f"Project: {result.project_name or 'Unknown'}")
    print(f"Has code: {result.has_code}")
    print(f"Stack: {result.get_stack_summary()}")
    print(f"Files: {result.source_files} source, {result.config_files} config")
    print()
    print("Key files:")
    for f in result.key_files[:10]:
        print(f"  - {f.path} ({f.size_bytes} bytes)")
    print()
    print("Dependencies:")
    for d in result.dependencies[:10]:
        print(f"  - {d.name}: {d.version or 'any'} ({d.type})")
    print()
    print("Formatted output:")
    print(format_scan_result(result, "pt"))
