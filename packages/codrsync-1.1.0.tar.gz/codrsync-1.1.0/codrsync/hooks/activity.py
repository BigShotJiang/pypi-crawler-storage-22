"""
codrsync Hook: Activity Logging

This hook is triggered PostToolUse (after Edit/Write) to log
file editing activity for metrics and tracking. Also maps files
to stories and tracks completion signals.
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional


def log_activity() -> None:
    """Hook: PostToolUse - Log file editing activity.

    Reads hook input from stdin and logs edit/write operations
    to .codrsync/activity.log for tracking. Also updates story
    file mappings and completion signals.
    """
    # Read hook input from stdin
    input_data = read_hook_input()
    if not input_data:
        return

    tool_name = input_data.get("tool_name", "")
    tool_input = input_data.get("tool_input", {})

    # Only log Edit and Write operations
    if tool_name not in ("Edit", "Write"):
        return

    file_path = tool_input.get("file_path", "")
    if file_path:
        log_file_activity(file_path, tool_name)
        update_story_mapping(file_path)
        increment_session_edits()


def read_hook_input() -> Optional[Dict[str, Any]]:
    """Read hook input data from stdin.

    Returns:
        Parsed JSON input or None if invalid
    """
    try:
        # Check if stdin has data
        if sys.stdin.isatty():
            return None

        input_text = sys.stdin.read()
        if not input_text.strip():
            return None

        return json.loads(input_text)
    except (json.JSONDecodeError, IOError):
        return None


def log_file_activity(file_path: str, tool_name: str) -> None:
    """Log activity to .codrsync/activity.log.

    Args:
        file_path: Path to the edited file
        tool_name: Name of the tool used (Edit/Write)
    """
    project_path = Path.cwd()
    codrsync_dir = project_path / ".codrsync"

    if not codrsync_dir.exists():
        return

    log_file = codrsync_dir / "activity.log"
    timestamp = datetime.now().isoformat()

    # Make file path relative to project
    try:
        rel_path = Path(file_path).relative_to(project_path)
    except ValueError:
        rel_path = file_path

    log_entry = f"{timestamp} | {tool_name:5} | {rel_path}\n"

    try:
        with open(log_file, "a") as f:
            f.write(log_entry)
    except IOError:
        pass  # Silently fail - don't interrupt Claude


def get_activity_stats(codrsync_dir: Path) -> Dict[str, Any]:
    """Get activity statistics from the log.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Dictionary with activity statistics
    """
    log_file = codrsync_dir / "activity.log"

    if not log_file.exists():
        return {"total_edits": 0, "today_edits": 0, "files_edited": set()}

    today = datetime.now().date().isoformat()
    total_edits = 0
    today_edits = 0
    files_edited = set()

    try:
        with open(log_file, "r") as f:
            for line in f:
                parts = line.strip().split(" | ")
                if len(parts) >= 3:
                    total_edits += 1
                    timestamp = parts[0]
                    file_path = parts[2]

                    files_edited.add(file_path)

                    if timestamp.startswith(today):
                        today_edits += 1

    except IOError:
        pass

    return {
        "total_edits": total_edits,
        "today_edits": today_edits,
        "files_edited": files_edited,
        "unique_files": len(files_edited),
    }


def update_story_mapping(file_path: str) -> None:
    """Update story-file mapping for the edited file.

    Args:
        file_path: Path to the edited file
    """
    project_path = Path.cwd()
    codrsync_dir = project_path / ".codrsync"

    if not codrsync_dir.exists():
        return

    try:
        # Get current story from session
        from codrsync.sprint_engine.tracker import TimeTracker

        tracker = TimeTracker(codrsync_dir)
        session = tracker.get_active_session()

        if session and session.active_story:
            # Map file to story
            from codrsync.sprint_engine.matcher import StoryMatcher

            # Make path relative
            try:
                rel_path = str(Path(file_path).relative_to(project_path))
            except ValueError:
                rel_path = file_path

            matcher = StoryMatcher(codrsync_dir)
            matcher.map_file_to_story(rel_path, session.active_story)

            # Update completion signals
            matcher.update_completion_signals(session.active_story)
    except Exception:
        # Don't interrupt Claude if mapping fails
        pass


def increment_session_edits() -> None:
    """Increment edit count for current session."""
    project_path = Path.cwd()
    codrsync_dir = project_path / ".codrsync"

    if not codrsync_dir.exists():
        return

    try:
        from codrsync.sprint_engine.tracker import TimeTracker

        tracker = TimeTracker(codrsync_dir)
        tracker.increment_edits()
    except Exception:
        # Don't interrupt Claude if tracking fails
        pass
