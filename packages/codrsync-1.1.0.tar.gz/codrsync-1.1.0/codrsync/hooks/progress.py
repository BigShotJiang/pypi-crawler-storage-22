"""
codrsync Hook: Progress Tracking

This hook is triggered at Stop to update progress.json
when Claude finishes a response. Also handles session end,
auto-completion detection, metrics updates, and documentation sync.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional

from codrsync.hooks.activity import get_activity_stats


def update_progress() -> None:
    """Hook: Stop - Update progress.json when Claude stops.

    Updates last_activity timestamp and metrics from the
    activity log. Also ends session tracking, checks for
    auto-completion, updates metrics, and syncs documentation.
    """
    project_path = Path.cwd()
    codrsync_dir = project_path / ".codrsync"
    progress_file = codrsync_dir / "progress.json"

    if not progress_file.exists():
        return

    try:
        progress = json.loads(progress_file.read_text())
    except (json.JSONDecodeError, IOError):
        return

    # Update last_activity timestamp
    progress["last_activity"] = datetime.now().isoformat()

    # Update metrics from activity log
    stats = get_activity_stats(codrsync_dir)
    if stats:
        progress.setdefault("metrics", {})
        progress["metrics"]["edits_today"] = stats.get("today_edits", 0)
        progress["metrics"]["total_edits"] = stats.get("total_edits", 0)
        progress["metrics"]["unique_files_edited"] = stats.get("unique_files", 0)

    # Increment session count
    progress.setdefault("metrics", {})
    sessions = progress["metrics"].get("sessions", 0)
    progress["metrics"]["sessions"] = sessions + 1

    # Write updated progress
    try:
        progress_file.write_text(json.dumps(progress, indent=2))
    except IOError:
        pass  # Silently fail - don't interrupt Claude

    # End session tracking and record time
    end_session_tracking(codrsync_dir)

    # Update sprint metrics
    update_sprint_metrics(codrsync_dir)

    # Check for auto-completion
    auto_completed = check_auto_completion(codrsync_dir)

    # Sync documentation
    sync_documentation(codrsync_dir)

    # Report auto-completed stories if any
    if auto_completed:
        print(f"\n✅ Stories auto-completed: {', '.join(auto_completed)}")


def end_session_tracking(codrsync_dir: Path) -> None:
    """End session tracking and record time.

    Args:
        codrsync_dir: Path to .codrsync directory
    """
    try:
        from codrsync.sprint_engine.tracker import TimeTracker

        tracker = TimeTracker(codrsync_dir)
        session = tracker.end_session()

        if session and session.duration_minutes:
            # Record for calibration if story was completed
            record_calibration_data(codrsync_dir, session)
    except Exception:
        pass  # Don't interrupt Claude


def record_calibration_data(codrsync_dir: Path, session: Any) -> None:
    """Record calibration data for completed stories.

    Args:
        codrsync_dir: Path to .codrsync directory
        session: Ended session object
    """
    if not session.active_story:
        return

    try:
        from codrsync.sprint_engine.tracker import TimeTracker
        from codrsync.sprint_engine.calibration import CalibrationRAG

        tracker = TimeTracker(codrsync_dir)
        progress_path = codrsync_dir / "progress.json"

        if not progress_path.exists():
            return

        progress = json.loads(progress_path.read_text())

        # Find story
        story = None
        sprint = progress.get("current_sprint", {})
        for s in sprint.get("stories", []):
            if s.get("id") == session.active_story:
                story = s
                break

        if not story or story.get("status") != "done":
            return

        # Get project name
        manifest_path = codrsync_dir / "manifest.json"
        project_name = "unknown"
        if manifest_path.exists():
            manifest = json.loads(manifest_path.read_text())
            project_name = manifest.get("project", {}).get("name", "unknown")

        # Get time tracking info
        time_tracking = story.get("time_tracking", {})
        estimated_hours = time_tracking.get("estimated_hours", 0)
        actual_minutes = time_tracking.get("actual_minutes", 0)
        sessions_count = len(time_tracking.get("sessions", []))

        if estimated_hours > 0:
            rag = CalibrationRAG()
            rag.record_story_completion(
                story_id=session.active_story,
                project=project_name,
                description=story.get("title", ""),
                tags=story.get("tags", []),
                estimated_points=story.get("points", 0),
                estimated_hours=estimated_hours,
                actual_hours=actual_minutes / 60,
                actual_sessions=sessions_count,
                files_touched=1,  # Simplified for now
            )
    except Exception:
        pass


def update_sprint_metrics(codrsync_dir: Path) -> None:
    """Update sprint metrics in progress.json.

    Args:
        codrsync_dir: Path to .codrsync directory
    """
    try:
        from codrsync.sprint_engine.metrics import MetricsEngine

        engine = MetricsEngine(codrsync_dir)
        engine.update_sprint_metrics()
    except Exception:
        pass  # Don't interrupt Claude


def check_auto_completion(codrsync_dir: Path) -> List[str]:
    """Check for stories ready for auto-completion.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        List of auto-completed story IDs
    """
    try:
        from codrsync.sprint_engine.sync import DocumentationSync

        sync = DocumentationSync(codrsync_dir)
        return sync.auto_close_stories()
    except Exception:
        return []


def sync_documentation(codrsync_dir: Path) -> None:
    """Sync documentation with current progress.

    Args:
        codrsync_dir: Path to .codrsync directory
    """
    try:
        from codrsync.sprint_engine.sync import DocumentationSync

        sync = DocumentationSync(codrsync_dir)
        sync.sync_progress_docs()
    except Exception:
        pass  # Don't interrupt Claude


def get_progress_summary(codrsync_dir: Path) -> Dict[str, Any]:
    """Get a summary of current progress.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Dictionary with progress summary
    """
    progress_file = codrsync_dir / "progress.json"

    if not progress_file.exists():
        return {}

    try:
        progress = json.loads(progress_file.read_text())
    except (json.JSONDecodeError, IOError):
        return {}

    # Extract key info
    summary = {
        "phase": progress.get("phase", "unknown"),
        "last_activity": progress.get("last_activity"),
    }

    # Sprint info
    sprint = progress.get("current_sprint", {})
    if sprint:
        stories = sprint.get("stories", [])
        summary["sprint"] = {
            "name": sprint.get("name"),
            "total_stories": len(stories),
            "completed": sum(1 for s in stories if s.get("status") == "done"),
            "in_progress": sum(1 for s in stories if s.get("status") == "in_progress"),
        }

    # Metrics
    metrics = progress.get("metrics", {})
    if metrics:
        summary["metrics"] = metrics

    return summary


def mark_story_done(codrsync_dir: Path, story_id: str) -> bool:
    """Mark a story as done in progress.json.

    Args:
        codrsync_dir: Path to .codrsync directory
        story_id: ID of the story to mark done

    Returns:
        True if story was found and marked, False otherwise
    """
    progress_file = codrsync_dir / "progress.json"

    if not progress_file.exists():
        return False

    try:
        progress = json.loads(progress_file.read_text())
    except (json.JSONDecodeError, IOError):
        return False

    sprint = progress.get("current_sprint", {})
    stories = sprint.get("stories", [])

    found = False
    for story in stories:
        if story.get("id") == story_id:
            story["status"] = "done"
            story["completed_at"] = datetime.now().isoformat()
            found = True
            break

    if found:
        try:
            progress_file.write_text(json.dumps(progress, indent=2))
        except IOError:
            return False

    return found
