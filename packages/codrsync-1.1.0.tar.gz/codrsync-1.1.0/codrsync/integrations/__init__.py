"""
Integration Hub - Connect to external project management tools

Supports:
- Notion (databases/pages)
- Jira (issues/sprints)
- Trello (boards/cards) [future]
- ClickUp (tasks/lists) [future]
"""

from codrsync.integrations.base import (
    IntegrationBase,
    Story,
    SyncResult,
    SyncDirection,
    IntegrationConfig,
)
from codrsync.integrations.notion import NotionIntegration
from codrsync.integrations.sync import SyncEngine

__all__ = [
    "IntegrationBase",
    "Story",
    "SyncResult",
    "SyncDirection",
    "IntegrationConfig",
    "NotionIntegration",
    "SyncEngine",
]
