"""
Base classes for external integrations

Defines the interface and data structures for all integration providers.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Dict, Any, List, Optional


class SyncDirection(Enum):
    """Sync direction for project integrations."""

    EXPORT = "export"  # codrsync -> external
    IMPORT = "import"  # external -> codrsync
    BIDIRECTIONAL = "bidirectional"  # both ways


class SourceOfTruth(Enum):
    """Which system is the source of truth."""

    CODRSYNC = "codrsync"
    EXTERNAL = "external"


@dataclass
class Story:
    """Represents a story/task for sync."""

    id: str
    title: str
    status: str
    points: Optional[int] = None
    sprint: Optional[str] = None
    priority: Optional[str] = None
    assignee: Optional[str] = None
    description: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    acceptance_criteria: List[str] = field(default_factory=list)
    due_date: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    external_id: Optional[str] = None
    external_url: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "title": self.title,
            "status": self.status,
            "points": self.points,
            "sprint": self.sprint,
            "priority": self.priority,
            "assignee": self.assignee,
            "description": self.description,
            "tags": self.tags,
            "acceptance_criteria": self.acceptance_criteria,
            "due_date": self.due_date,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "external_id": self.external_id,
            "external_url": self.external_url,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Story":
        """Create Story from dictionary."""
        return cls(
            id=data.get("id", ""),
            title=data.get("title", ""),
            status=data.get("status", "pending"),
            points=data.get("points"),
            sprint=data.get("sprint"),
            priority=data.get("priority"),
            assignee=data.get("assignee"),
            description=data.get("description"),
            tags=data.get("tags", []),
            acceptance_criteria=data.get("acceptance_criteria", []),
            due_date=data.get("due_date"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            external_id=data.get("external_id"),
            external_url=data.get("external_url"),
        )


@dataclass
class SyncResult:
    """Result of a sync operation."""

    success: bool
    created: int = 0
    updated: int = 0
    deleted: int = 0
    skipped: int = 0
    errors: List[str] = field(default_factory=list)
    mappings: Dict[str, str] = field(default_factory=dict)  # local_id -> external_id
    synced_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "success": self.success,
            "created": self.created,
            "updated": self.updated,
            "deleted": self.deleted,
            "skipped": self.skipped,
            "errors": self.errors,
            "mappings": self.mappings,
            "synced_at": self.synced_at,
        }


@dataclass
class IntegrationConfig:
    """Configuration for a project integration."""

    provider: str
    workspace_id: str
    workspace_name: str
    project_id: str
    project_name: str
    sync_direction: SyncDirection = SyncDirection.EXPORT
    source_of_truth: SourceOfTruth = SourceOfTruth.CODRSYNC
    field_mappings: Dict[str, str] = field(default_factory=dict)
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    token_expires_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary (without sensitive data)."""
        return {
            "provider": self.provider,
            "workspace_id": self.workspace_id,
            "workspace_name": self.workspace_name,
            "project_id": self.project_id,
            "project_name": self.project_name,
            "sync_direction": self.sync_direction.value,
            "source_of_truth": self.source_of_truth.value,
            "field_mappings": self.field_mappings,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "IntegrationConfig":
        """Create from dictionary."""
        return cls(
            provider=data.get("provider", ""),
            workspace_id=data.get("workspace_id", ""),
            workspace_name=data.get("workspace_name", ""),
            project_id=data.get("project_id", ""),
            project_name=data.get("project_name", ""),
            sync_direction=SyncDirection(data.get("sync_direction", "export")),
            source_of_truth=SourceOfTruth(data.get("source_of_truth", "codrsync")),
            field_mappings=data.get("field_mappings", {}),
            access_token=data.get("access_token"),
            refresh_token=data.get("refresh_token"),
            token_expires_at=data.get("token_expires_at"),
        )


@dataclass
class ExternalProject:
    """Represents an external project/database."""

    id: str
    name: str
    url: Optional[str] = None
    workspace_id: Optional[str] = None
    workspace_name: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class IntegrationBase(ABC):
    """Base class for external integrations."""

    # Status mappings (override in subclasses)
    STATUS_TO_EXTERNAL: Dict[str, str] = {
        "pending": "To Do",
        "todo": "To Do",
        "in_progress": "In Progress",
        "done": "Done",
        "blocked": "Blocked",
    }

    STATUS_FROM_EXTERNAL: Dict[str, str] = {
        "To Do": "todo",
        "In Progress": "in_progress",
        "Done": "done",
        "Blocked": "blocked",
        "Backlog": "pending",
    }

    def __init__(self, config: Optional[IntegrationConfig] = None):
        """Initialize integration.

        Args:
            config: Integration configuration
        """
        self.config = config

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Return provider name (notion, jira, etc)."""
        pass

    @property
    @abstractmethod
    def display_name(self) -> str:
        """Return display name for UI."""
        pass

    @abstractmethod
    async def start_device_auth(self, api_base_url: str) -> Dict[str, str]:
        """Start device authorization flow.

        Args:
            api_base_url: Base URL for the auth API (e.g., https://auth.codrsync.dev)

        Returns:
            Dictionary with:
            - device_code: Code for polling
            - user_code: Code to show user
            - verification_url: URL for user to visit
            - expires_in: Seconds until expiration
        """
        pass

    @abstractmethod
    async def poll_device_auth(
        self,
        api_base_url: str,
        device_code: str,
    ) -> Optional[Dict[str, Any]]:
        """Poll for device authorization completion.

        Args:
            api_base_url: Base URL for the auth API
            device_code: Device code from start_device_auth

        Returns:
            Token data if authorized, None if still pending
        """
        pass

    @abstractmethod
    async def list_workspaces(self) -> List[Dict[str, Any]]:
        """List available workspaces/sites.

        Returns:
            List of workspace info dictionaries
        """
        pass

    @abstractmethod
    async def list_projects(self, workspace_id: str) -> List[ExternalProject]:
        """List available projects/databases in workspace.

        Args:
            workspace_id: Workspace ID

        Returns:
            List of ExternalProject objects
        """
        pass

    @abstractmethod
    async def push_stories(
        self,
        stories: List[Story],
        mappings: Dict[str, str],
    ) -> SyncResult:
        """Push stories to external system.

        Args:
            stories: Stories to push
            mappings: Existing local_id -> external_id mappings

        Returns:
            SyncResult with created/updated counts and new mappings
        """
        pass

    @abstractmethod
    async def pull_stories(
        self,
        mappings: Dict[str, str],
    ) -> tuple[List[Story], SyncResult]:
        """Pull stories from external system.

        Args:
            mappings: Existing local_id -> external_id mappings

        Returns:
            Tuple of (stories, sync_result)
        """
        pass

    def map_status_to_external(self, status: str) -> str:
        """Map codrsync status to external status.

        Args:
            status: codrsync status

        Returns:
            External status string
        """
        return self.STATUS_TO_EXTERNAL.get(status, status)

    def map_status_from_external(self, status: str) -> str:
        """Map external status to codrsync status.

        Args:
            status: External status

        Returns:
            codrsync status string
        """
        return self.STATUS_FROM_EXTERNAL.get(status, status.lower().replace(" ", "_"))
