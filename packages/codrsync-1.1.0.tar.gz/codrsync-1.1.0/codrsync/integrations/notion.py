"""
Notion Integration - Sync with Notion databases

Handles OAuth, database operations, and story sync with Notion.
"""

import asyncio
import json
from datetime import datetime
from typing import Dict, Any, List, Optional

import httpx

from codrsync.integrations.base import (
    IntegrationBase,
    IntegrationConfig,
    Story,
    SyncResult,
    ExternalProject,
)


class NotionIntegration(IntegrationBase):
    """Integration with Notion databases."""

    NOTION_API_VERSION = "2022-06-28"
    NOTION_API_URL = "https://api.notion.com/v1"

    # Field mapping: codrsync field -> Notion property name
    DEFAULT_FIELD_MAPPING = {
        "id": "External ID",
        "title": "Name",
        "status": "Status",
        "points": "Story Points",
        "assignee": "Assignee",
        "sprint": "Sprint",
        "priority": "Priority",
        "due_date": "Due Date",
        "tags": "Tags",
    }

    # Status mapping for Notion status property
    STATUS_TO_EXTERNAL = {
        "pending": "Backlog",
        "todo": "To Do",
        "in_progress": "In Progress",
        "done": "Done",
        "blocked": "Blocked",
    }

    STATUS_FROM_EXTERNAL = {
        "Backlog": "pending",
        "To Do": "todo",
        "In Progress": "in_progress",
        "Done": "done",
        "Blocked": "blocked",
    }

    @property
    def provider_name(self) -> str:
        return "notion"

    @property
    def display_name(self) -> str:
        return "Notion"

    def _get_headers(self) -> Dict[str, str]:
        """Get headers for Notion API requests."""
        if not self.config or not self.config.access_token:
            raise ValueError("Access token not configured")

        return {
            "Authorization": f"Bearer {self.config.access_token}",
            "Content-Type": "application/json",
            "Notion-Version": self.NOTION_API_VERSION,
        }

    async def start_device_auth(self, api_base_url: str) -> Dict[str, str]:
        """Start device authorization flow via auth.codrsync.dev.

        Args:
            api_base_url: Base URL for the auth API

        Returns:
            Device auth info
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{api_base_url}/api/integrations/notion/device-code",
                json={"provider": "notion"},
            )
            response.raise_for_status()
            return response.json()

    async def poll_device_auth(
        self,
        api_base_url: str,
        device_code: str,
    ) -> Optional[Dict[str, Any]]:
        """Poll for device authorization completion.

        Args:
            api_base_url: Base URL for the auth API
            device_code: Device code from start_device_auth

        Returns:
            Token data if authorized, None if still pending
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{api_base_url}/api/integrations/notion/device-token",
                json={"device_code": device_code},
            )

            if response.status_code == 202:
                # Still pending
                return None

            if response.status_code == 200:
                return response.json()

            # Error
            response.raise_for_status()
            return None

    async def list_workspaces(self) -> List[Dict[str, Any]]:
        """List Notion workspaces (via bot info).

        Returns:
            List with single workspace info (Notion returns one per integration)
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.NOTION_API_URL}/users/me",
                headers=self._get_headers(),
            )
            response.raise_for_status()
            data = response.json()

            # Notion integrations are scoped to one workspace
            return [{
                "id": data.get("bot", {}).get("workspace_name", "Default"),
                "name": data.get("bot", {}).get("workspace_name", "Notion Workspace"),
                "owner": data.get("bot", {}).get("owner", {}),
            }]

    async def list_projects(self, workspace_id: str = "") -> List[ExternalProject]:
        """List available Notion databases.

        Args:
            workspace_id: Not used for Notion (scoped to integration)

        Returns:
            List of databases as ExternalProject objects
        """
        databases = []

        async with httpx.AsyncClient() as client:
            # Search for all databases the integration has access to
            response = await client.post(
                f"{self.NOTION_API_URL}/search",
                headers=self._get_headers(),
                json={
                    "filter": {"property": "object", "value": "database"},
                    "page_size": 100,
                },
            )
            response.raise_for_status()
            data = response.json()

            for db in data.get("results", []):
                title = self._extract_title(db.get("title", []))
                databases.append(ExternalProject(
                    id=db["id"],
                    name=title or "Untitled Database",
                    url=db.get("url"),
                    metadata={
                        "icon": db.get("icon"),
                        "properties": list(db.get("properties", {}).keys()),
                    },
                ))

        return databases

    async def push_stories(
        self,
        stories: List[Story],
        mappings: Dict[str, str],
    ) -> SyncResult:
        """Push stories to Notion database.

        Args:
            stories: Stories to push
            mappings: Existing local_id -> external_id (page_id) mappings

        Returns:
            SyncResult with counts and updated mappings
        """
        if not self.config or not self.config.project_id:
            return SyncResult(
                success=False,
                errors=["No Notion database configured"],
            )

        result = SyncResult(success=True, mappings=dict(mappings))
        field_map = self.config.field_mappings or self.DEFAULT_FIELD_MAPPING

        async with httpx.AsyncClient() as client:
            for story in stories:
                try:
                    external_id = mappings.get(story.id)

                    if external_id:
                        # Update existing page
                        await self._update_page(client, external_id, story, field_map)
                        result.updated += 1
                    else:
                        # Create new page
                        page_id = await self._create_page(client, story, field_map)
                        result.mappings[story.id] = page_id
                        result.created += 1

                except Exception as e:
                    result.errors.append(f"Error syncing {story.id}: {str(e)}")

        result.success = len(result.errors) == 0
        return result

    async def pull_stories(
        self,
        mappings: Dict[str, str],
    ) -> tuple[List[Story], SyncResult]:
        """Pull stories from Notion database.

        Args:
            mappings: Existing local_id -> external_id mappings

        Returns:
            Tuple of (stories, sync_result)
        """
        if not self.config or not self.config.project_id:
            return [], SyncResult(
                success=False,
                errors=["No Notion database configured"],
            )

        stories = []
        result = SyncResult(success=True, mappings=dict(mappings))
        field_map = self.config.field_mappings or self.DEFAULT_FIELD_MAPPING

        # Reverse mapping: external_id -> local_id
        reverse_map = {v: k for k, v in mappings.items()}

        async with httpx.AsyncClient() as client:
            try:
                # Query all pages in database
                response = await client.post(
                    f"{self.NOTION_API_URL}/databases/{self.config.project_id}/query",
                    headers=self._get_headers(),
                    json={"page_size": 100},
                )
                response.raise_for_status()
                data = response.json()

                for page in data.get("results", []):
                    try:
                        story = self._page_to_story(page, field_map, reverse_map)
                        stories.append(story)

                        if story.external_id and story.id:
                            result.mappings[story.id] = story.external_id

                    except Exception as e:
                        result.errors.append(f"Error parsing page {page.get('id')}: {str(e)}")

            except Exception as e:
                result.errors.append(f"Error querying database: {str(e)}")
                result.success = False

        return stories, result

    async def _create_page(
        self,
        client: httpx.AsyncClient,
        story: Story,
        field_map: Dict[str, str],
    ) -> str:
        """Create a new page in Notion database.

        Args:
            client: HTTP client
            story: Story to create
            field_map: Field mappings

        Returns:
            Created page ID
        """
        properties = self._story_to_properties(story, field_map)

        response = await client.post(
            f"{self.NOTION_API_URL}/pages",
            headers=self._get_headers(),
            json={
                "parent": {"database_id": self.config.project_id},
                "properties": properties,
            },
        )
        response.raise_for_status()
        data = response.json()
        return data["id"]

    async def _update_page(
        self,
        client: httpx.AsyncClient,
        page_id: str,
        story: Story,
        field_map: Dict[str, str],
    ) -> None:
        """Update an existing Notion page.

        Args:
            client: HTTP client
            page_id: Notion page ID
            story: Story with updated data
            field_map: Field mappings
        """
        properties = self._story_to_properties(story, field_map)

        response = await client.patch(
            f"{self.NOTION_API_URL}/pages/{page_id}",
            headers=self._get_headers(),
            json={"properties": properties},
        )
        response.raise_for_status()

    def _story_to_properties(
        self,
        story: Story,
        field_map: Dict[str, str],
    ) -> Dict[str, Any]:
        """Convert Story to Notion properties.

        Args:
            story: Story to convert
            field_map: Field mappings

        Returns:
            Notion properties dictionary
        """
        properties = {}

        # Title (required)
        title_field = field_map.get("title", "Name")
        properties[title_field] = {
            "title": [{"text": {"content": story.title}}]
        }

        # External ID
        id_field = field_map.get("id", "External ID")
        properties[id_field] = {
            "rich_text": [{"text": {"content": story.id}}]
        }

        # Status
        if story.status:
            status_field = field_map.get("status", "Status")
            external_status = self.map_status_to_external(story.status)
            properties[status_field] = {"status": {"name": external_status}}

        # Story Points
        if story.points is not None:
            points_field = field_map.get("points", "Story Points")
            properties[points_field] = {"number": story.points}

        # Priority
        if story.priority:
            priority_field = field_map.get("priority", "Priority")
            properties[priority_field] = {"select": {"name": story.priority.capitalize()}}

        # Sprint
        if story.sprint:
            sprint_field = field_map.get("sprint", "Sprint")
            properties[sprint_field] = {"select": {"name": story.sprint}}

        # Due Date
        if story.due_date:
            date_field = field_map.get("due_date", "Due Date")
            properties[date_field] = {"date": {"start": story.due_date}}

        # Tags
        if story.tags:
            tags_field = field_map.get("tags", "Tags")
            properties[tags_field] = {
                "multi_select": [{"name": tag} for tag in story.tags]
            }

        return properties

    def _page_to_story(
        self,
        page: Dict[str, Any],
        field_map: Dict[str, str],
        reverse_map: Dict[str, str],
    ) -> Story:
        """Convert Notion page to Story.

        Args:
            page: Notion page data
            field_map: Field mappings
            reverse_map: external_id -> local_id mapping

        Returns:
            Story object
        """
        properties = page.get("properties", {})
        page_id = page["id"]

        # Extract fields
        title = self._extract_title_property(properties.get(field_map.get("title", "Name"), {}))
        external_id_text = self._extract_rich_text(properties.get(field_map.get("id", "External ID"), {}))

        # Use external_id from property, or look up in reverse map, or generate new
        local_id = external_id_text or reverse_map.get(page_id) or f"EXT-{page_id[:8]}"

        status_prop = properties.get(field_map.get("status", "Status"), {})
        status_name = status_prop.get("status", {}).get("name", "To Do")
        status = self.map_status_from_external(status_name)

        points = self._extract_number(properties.get(field_map.get("points", "Story Points"), {}))
        priority = self._extract_select(properties.get(field_map.get("priority", "Priority"), {}))
        sprint = self._extract_select(properties.get(field_map.get("sprint", "Sprint"), {}))
        due_date = self._extract_date(properties.get(field_map.get("due_date", "Due Date"), {}))
        tags = self._extract_multi_select(properties.get(field_map.get("tags", "Tags"), {}))

        return Story(
            id=local_id,
            title=title,
            status=status,
            points=points,
            priority=priority.lower() if priority else None,
            sprint=sprint,
            due_date=due_date,
            tags=tags,
            external_id=page_id,
            external_url=page.get("url"),
            updated_at=page.get("last_edited_time"),
        )

    def _extract_title(self, title_array: List[Dict[str, Any]]) -> str:
        """Extract text from Notion title array."""
        if not title_array:
            return ""
        return "".join(t.get("plain_text", "") for t in title_array)

    def _extract_title_property(self, prop: Dict[str, Any]) -> str:
        """Extract text from Notion title property."""
        return self._extract_title(prop.get("title", []))

    def _extract_rich_text(self, prop: Dict[str, Any]) -> str:
        """Extract text from Notion rich_text property."""
        texts = prop.get("rich_text", [])
        return "".join(t.get("plain_text", "") for t in texts)

    def _extract_number(self, prop: Dict[str, Any]) -> Optional[int]:
        """Extract number from Notion number property."""
        num = prop.get("number")
        return int(num) if num is not None else None

    def _extract_select(self, prop: Dict[str, Any]) -> Optional[str]:
        """Extract value from Notion select property."""
        select = prop.get("select")
        return select.get("name") if select else None

    def _extract_multi_select(self, prop: Dict[str, Any]) -> List[str]:
        """Extract values from Notion multi_select property."""
        options = prop.get("multi_select", [])
        return [opt.get("name") for opt in options if opt.get("name")]

    def _extract_date(self, prop: Dict[str, Any]) -> Optional[str]:
        """Extract date from Notion date property."""
        date = prop.get("date")
        return date.get("start") if date else None


async def create_notion_database(
    access_token: str,
    parent_page_id: str,
    project_name: str,
) -> str:
    """Create a new Notion database for sprint tracking.

    Args:
        access_token: Notion access token
        parent_page_id: Parent page ID
        project_name: Project name for database title

    Returns:
        Created database ID
    """
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{NotionIntegration.NOTION_API_URL}/databases",
            headers={
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
                "Notion-Version": NotionIntegration.NOTION_API_VERSION,
            },
            json={
                "parent": {"page_id": parent_page_id},
                "title": [{"text": {"content": f"{project_name} - Sprint Board"}}],
                "properties": {
                    "Name": {"title": {}},
                    "Status": {
                        "status": {
                            "options": [
                                {"name": "Backlog", "color": "gray"},
                                {"name": "To Do", "color": "default"},
                                {"name": "In Progress", "color": "blue"},
                                {"name": "Done", "color": "green"},
                                {"name": "Blocked", "color": "red"},
                            ]
                        }
                    },
                    "Story Points": {"number": {}},
                    "Priority": {
                        "select": {
                            "options": [
                                {"name": "Critical", "color": "red"},
                                {"name": "High", "color": "orange"},
                                {"name": "Medium", "color": "yellow"},
                                {"name": "Low", "color": "green"},
                            ]
                        }
                    },
                    "Sprint": {"select": {}},
                    "Due Date": {"date": {}},
                    "External ID": {"rich_text": {}},
                    "Tags": {"multi_select": {}},
                    "Assignee": {"people": {}},
                },
            },
        )
        response.raise_for_status()
        data = response.json()
        return data["id"]
