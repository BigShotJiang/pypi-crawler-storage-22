"""
Sync Engine - Coordinates synchronization between codrsync and external services

Handles:
- Loading/saving integration configs
- Managing item mappings
- Coordinating push/pull operations
- Conflict detection
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional, Type

from codrsync.integrations.base import (
    IntegrationBase,
    IntegrationConfig,
    Story,
    SyncResult,
    SyncDirection,
    SourceOfTruth,
    ExternalProject,
)


class SyncEngine:
    """Coordinates synchronization with external services."""

    def __init__(self, codrsync_dir: Path):
        """Initialize sync engine.

        Args:
            codrsync_dir: Path to .codrsync directory
        """
        self.codrsync_dir = codrsync_dir
        self.integrations_path = codrsync_dir / "integrations.json"
        self.progress_path = codrsync_dir / "progress.json"
        self.manifest_path = codrsync_dir / "manifest.json"

        # Integration class registry
        self._integration_classes: Dict[str, Type[IntegrationBase]] = {}

    def register_integration(self, name: str, cls: Type[IntegrationBase]) -> None:
        """Register an integration class.

        Args:
            name: Provider name
            cls: Integration class
        """
        self._integration_classes[name] = cls

    def get_integration_class(self, name: str) -> Optional[Type[IntegrationBase]]:
        """Get integration class by name.

        Args:
            name: Provider name

        Returns:
            Integration class or None
        """
        return self._integration_classes.get(name)

    def load_integrations(self) -> Dict[str, Any]:
        """Load integrations configuration.

        Returns:
            Integrations data
        """
        if not self.integrations_path.exists():
            return {"integrations": [], "mappings": {}}

        try:
            return json.loads(self.integrations_path.read_text())
        except (json.JSONDecodeError, IOError):
            return {"integrations": [], "mappings": {}}

    def save_integrations(self, data: Dict[str, Any]) -> bool:
        """Save integrations configuration.

        Args:
            data: Integrations data

        Returns:
            Success status
        """
        try:
            self.integrations_path.write_text(json.dumps(data, indent=2))
            return True
        except IOError:
            return False

    def get_integration_config(self, provider: str) -> Optional[IntegrationConfig]:
        """Get integration config for a provider.

        Args:
            provider: Provider name

        Returns:
            IntegrationConfig or None
        """
        data = self.load_integrations()
        for integration in data.get("integrations", []):
            if integration.get("provider") == provider:
                return IntegrationConfig.from_dict(integration)
        return None

    def save_integration_config(self, config: IntegrationConfig) -> bool:
        """Save or update integration config.

        Args:
            config: Integration config

        Returns:
            Success status
        """
        data = self.load_integrations()
        integrations = data.get("integrations", [])

        # Find and update existing or add new
        found = False
        for i, integration in enumerate(integrations):
            if integration.get("provider") == config.provider:
                integrations[i] = {
                    **config.to_dict(),
                    "access_token": config.access_token,
                    "refresh_token": config.refresh_token,
                    "token_expires_at": config.token_expires_at,
                }
                found = True
                break

        if not found:
            integrations.append({
                **config.to_dict(),
                "access_token": config.access_token,
                "refresh_token": config.refresh_token,
                "token_expires_at": config.token_expires_at,
            })

        data["integrations"] = integrations
        return self.save_integrations(data)

    def remove_integration(self, provider: str) -> bool:
        """Remove an integration.

        Args:
            provider: Provider name

        Returns:
            Success status
        """
        data = self.load_integrations()
        integrations = [
            i for i in data.get("integrations", [])
            if i.get("provider") != provider
        ]
        data["integrations"] = integrations

        # Also remove mappings
        if provider in data.get("mappings", {}):
            del data["mappings"][provider]

        return self.save_integrations(data)

    def get_mappings(self, provider: str) -> Dict[str, str]:
        """Get item mappings for a provider.

        Args:
            provider: Provider name

        Returns:
            Dictionary of local_id -> external_id
        """
        data = self.load_integrations()
        return data.get("mappings", {}).get(provider, {})

    def save_mappings(self, provider: str, mappings: Dict[str, str]) -> bool:
        """Save item mappings for a provider.

        Args:
            provider: Provider name
            mappings: local_id -> external_id mappings

        Returns:
            Success status
        """
        data = self.load_integrations()
        if "mappings" not in data:
            data["mappings"] = {}
        data["mappings"][provider] = mappings
        return self.save_integrations(data)

    def load_local_stories(self) -> List[Story]:
        """Load stories from local progress.json.

        Returns:
            List of Story objects
        """
        stories = []

        # Load from progress.json
        if self.progress_path.exists():
            try:
                progress = json.loads(self.progress_path.read_text())

                # Stories from progress
                for s in progress.get("stories", []):
                    stories.append(Story.from_dict(s))

                # Stories from current sprint
                sprint = progress.get("current_sprint", {})
                for s in sprint.get("stories", []):
                    # Avoid duplicates
                    if not any(st.id == s.get("id") for st in stories):
                        stories.append(Story.from_dict(s))

            except (json.JSONDecodeError, IOError):
                pass

        return stories

    def save_local_stories(self, stories: List[Story]) -> bool:
        """Save stories to local progress.json.

        Args:
            stories: Stories to save

        Returns:
            Success status
        """
        if not self.progress_path.exists():
            return False

        try:
            progress = json.loads(self.progress_path.read_text())

            # Update existing stories or add new ones
            existing_ids = {s.get("id") for s in progress.get("stories", [])}

            for story in stories:
                story_dict = story.to_dict()

                if story.id in existing_ids:
                    # Update existing
                    for i, s in enumerate(progress.get("stories", [])):
                        if s.get("id") == story.id:
                            progress["stories"][i] = {
                                **s,
                                **story_dict,
                            }
                            break
                else:
                    # Add new
                    if "stories" not in progress:
                        progress["stories"] = []
                    progress["stories"].append(story_dict)

            self.progress_path.write_text(json.dumps(progress, indent=2))
            return True

        except (json.JSONDecodeError, IOError):
            return False

    async def sync(
        self,
        provider: str,
        direction: Optional[SyncDirection] = None,
        stories: Optional[List[Story]] = None,
    ) -> SyncResult:
        """Perform sync with a provider.

        Args:
            provider: Provider name
            direction: Sync direction (uses config default if None)
            stories: Stories to sync (loads from local if None)

        Returns:
            SyncResult
        """
        config = self.get_integration_config(provider)
        if not config:
            return SyncResult(
                success=False,
                errors=[f"No integration configured for {provider}"],
            )

        integration_class = self.get_integration_class(provider)
        if not integration_class:
            return SyncResult(
                success=False,
                errors=[f"Unknown provider: {provider}"],
            )

        integration = integration_class(config)
        mappings = self.get_mappings(provider)
        sync_direction = direction or config.sync_direction

        result = SyncResult(success=True, mappings=dict(mappings))

        try:
            if sync_direction in (SyncDirection.EXPORT, SyncDirection.BIDIRECTIONAL):
                # Push local → external
                local_stories = stories or self.load_local_stories()
                push_result = await integration.push_stories(local_stories, mappings)

                result.created += push_result.created
                result.updated += push_result.updated
                result.errors.extend(push_result.errors)
                result.mappings.update(push_result.mappings)

            if sync_direction in (SyncDirection.IMPORT, SyncDirection.BIDIRECTIONAL):
                # Pull external → local
                external_stories, pull_result = await integration.pull_stories(mappings)

                if external_stories:
                    self.save_local_stories(external_stories)

                result.errors.extend(pull_result.errors)
                result.mappings.update(pull_result.mappings)

            # Save updated mappings
            self.save_mappings(provider, result.mappings)

            result.success = len(result.errors) == 0

        except Exception as e:
            result.success = False
            result.errors.append(f"Sync error: {str(e)}")

        return result

    async def push(
        self,
        provider: str,
        stories: Optional[List[Story]] = None,
    ) -> SyncResult:
        """Push stories to external provider.

        Args:
            provider: Provider name
            stories: Stories to push (loads from local if None)

        Returns:
            SyncResult
        """
        return await self.sync(provider, SyncDirection.EXPORT, stories)

    async def pull(self, provider: str) -> SyncResult:
        """Pull stories from external provider.

        Args:
            provider: Provider name

        Returns:
            SyncResult
        """
        return await self.sync(provider, SyncDirection.IMPORT)

    def get_sync_status(self, provider: str) -> Dict[str, Any]:
        """Get current sync status for a provider.

        Args:
            provider: Provider name

        Returns:
            Status information
        """
        config = self.get_integration_config(provider)
        mappings = self.get_mappings(provider)
        local_stories = self.load_local_stories()

        synced_count = sum(1 for s in local_stories if s.id in mappings)
        unsynced_count = len(local_stories) - synced_count

        return {
            "provider": provider,
            "connected": config is not None,
            "workspace": config.workspace_name if config else None,
            "project": config.project_name if config else None,
            "sync_direction": config.sync_direction.value if config else None,
            "total_stories": len(local_stories),
            "synced_stories": synced_count,
            "unsynced_stories": unsynced_count,
            "mappings_count": len(mappings),
        }

    def list_available_integrations(self) -> List[Dict[str, str]]:
        """List all available integration providers.

        Returns:
            List of provider info
        """
        return [
            {
                "name": "notion",
                "display_name": "Notion",
                "description": "Sync with Notion databases",
                "status": "available",
            },
            {
                "name": "jira",
                "display_name": "Jira",
                "description": "Sync with Jira issues and sprints",
                "status": "coming_soon",
            },
            {
                "name": "trello",
                "display_name": "Trello",
                "description": "Sync with Trello boards and cards",
                "status": "coming_soon",
            },
            {
                "name": "clickup",
                "display_name": "ClickUp",
                "description": "Sync with ClickUp tasks and lists",
                "status": "coming_soon",
            },
        ]

    def list_connected_integrations(self) -> List[Dict[str, Any]]:
        """List all connected integrations.

        Returns:
            List of connected integration info
        """
        data = self.load_integrations()
        connected = []

        for integration in data.get("integrations", []):
            connected.append({
                "provider": integration.get("provider"),
                "workspace_name": integration.get("workspace_name"),
                "project_name": integration.get("project_name"),
                "sync_direction": integration.get("sync_direction"),
            })

        return connected


def get_sync_engine(codrsync_dir: Optional[Path] = None) -> SyncEngine:
    """Get a SyncEngine instance with registered integrations.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Configured SyncEngine
    """
    if codrsync_dir is None:
        codrsync_dir = Path.cwd() / ".codrsync"

    engine = SyncEngine(codrsync_dir)

    # Register available integrations
    from codrsync.integrations.notion import NotionIntegration
    engine.register_integration("notion", NotionIntegration)

    return engine
