"""
First-run onboarding experience for codrsync.

Detects first execution (no config.json), shows welcome panel,
language selection (with hybrid detection), tour, and next steps.
"""

import os
import sys
import locale

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.columns import Columns
from rich.table import Table
from rich import box
import questionary

from codrsync.config import Config, CODRSYNC_HOME, get_config
from codrsync.i18n import setup_language, t
from codrsync.i18n.strings import EN, BUILTIN_LANGUAGES


console = Console()

# ASCII Art logo - stylized text
LOGO_ASCII = """[bold cyan]
   ██████╗ ██████╗ ██████╗ ██████╗ ███████╗██╗   ██╗███╗   ██╗ ██████╗
  ██╔════╝██╔═══██╗██╔══██╗██╔══██╗██╔════╝╚██╗ ██╔╝████╗  ██║██╔════╝
  ██║     ██║   ██║██║  ██║██████╔╝███████╗ ╚████╔╝ ██╔██╗ ██║██║
  ██║     ██║   ██║██║  ██║██╔══██╗╚════██║  ╚██╔╝  ██║╚██╗██║██║
  ╚██████╗╚██████╔╝██████╔╝██║  ██║███████║   ██║   ██║ ╚████║╚██████╗
   ╚═════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═══╝ ╚═════╝
[/bold cyan]"""

LOGO_SIMPLE = """[bold cyan]codrsync[/bold cyan] - [bold yellow]Your AI's AI[/bold yellow]"""

# Taglines by language
TAGLINES = {
    "en": {
        "main": "Your AI's AI",
        "sub": "Context engineering made simple",
    },
    "pt-br": {
        "main": "A IA da sua IA",
        "sub": "Engenharia de contexto simplificada",
    },
}

# Mapping from system locale to codrsync language codes
LOCALE_MAP = {
    "pt": "pt-br",
    "pt_br": "pt-br",
    "pt_pt": "pt-br",
    "es": "es",
    "es_es": "es",
    "es_mx": "es",
    "fr": "fr",
    "fr_fr": "fr",
    "de": "de",
    "de_de": "de",
    "it": "it",
    "it_it": "it",
    "en": "en",
    "en_us": "en",
    "en_gb": "en",
}

# Language display names
LANGUAGE_NAMES = {
    "en": "English",
    "pt-br": "Português (Brasil)",
    "es": "Español",
    "fr": "Français",
    "de": "Deutsch",
    "it": "Italiano",
}

# Language choices for manual selection
LANGUAGE_CHOICES = [
    {"name": "English", "value": "en"},
    {"name": "Português (Brasil)", "value": "pt-br"},
    {"name": "Español", "value": "es"},
    {"name": "Français", "value": "fr"},
    {"name": "Deutsch", "value": "de"},
    {"name": "Italiano", "value": "it"},
    {"name": "Other (type language code)", "value": "__other__"},
]


def detect_system_language() -> str:
    """
    Detect language using hybrid approach:
    1. Check CODRSYNC_LANG environment variable
    2. Detect from system locale
    3. Fall back to English

    Returns codrsync language code (e.g., 'en', 'pt-br')
    """
    # 1. Check environment variable first (highest priority)
    env_lang = os.getenv("CODRSYNC_LANG", "").strip().lower()
    if env_lang:
        # Direct match
        if env_lang in BUILTIN_LANGUAGES:
            return env_lang
        # Try mapping
        if env_lang in LOCALE_MAP:
            return LOCALE_MAP[env_lang]

    # 2. Detect from system locale
    try:
        system_locale = locale.getdefaultlocale()[0]
        if system_locale:
            # Normalize: pt_BR -> pt_br
            normalized = system_locale.lower().replace("-", "_")

            # Try exact match first
            if normalized in LOCALE_MAP:
                return LOCALE_MAP[normalized]

            # Try language part only (pt_BR -> pt)
            lang_part = normalized.split("_")[0]
            if lang_part in LOCALE_MAP:
                return LOCALE_MAP[lang_part]
    except Exception:
        pass

    # 3. Fall back to English
    return "en"


def show_welcome_header(lang: str = "en") -> None:
    """Display the welcome header with logo."""
    tagline = TAGLINES.get(lang, TAGLINES["en"])

    console.print()
    # Print logo centered
    console.print(Align.center(Text.from_markup(LOGO_ASCII.strip())))
    console.print()
    # Print tagline centered
    console.print(Align.center(Text.from_markup(f"[bold yellow]{tagline['main']}[/bold yellow]")))
    console.print(Align.center(Text.from_markup(f"[dim]{tagline['sub']}[/dim]")))
    console.print()


def show_next_steps(lang: str = "en") -> None:
    """Display next steps in a beautiful format with codrsync start highlighted."""
    # Main action - codrsync start
    if lang == "pt-br":
        main_cmd = "[bold green]codrsync start[/bold green]"
        main_desc = "Iniciar Claude Code com superego"
        title = "Comece Agora"
        other_title = "Outros Comandos"
    else:
        main_cmd = "[bold green]codrsync start[/bold green]"
        main_desc = "Launch Claude Code with superego"
        title = "Get Started"
        other_title = "Other Commands"

    # Highlighted main command
    console.print()
    console.print(Panel(
        Align.center(f"[bold]→[/bold]  {main_cmd}  [dim]{main_desc}[/dim]"),
        title=f"[bold green]🚀 {title}[/bold green]",
        border_style="green",
        padding=(1, 2),
    ))

    # Other commands table
    table = Table(
        show_header=False,
        box=box.SIMPLE,
        padding=(0, 2),
        expand=True,
    )
    table.add_column("Command", style="cyan", width=20)
    table.add_column("Description", style="dim")

    if lang == "pt-br":
        table.add_row("codrsync init", "Criar novo projeto com wizard")
        table.add_row("codrsync scan", "Escanear projeto existente")
        table.add_row("codrsync auth", "Configurar backend de IA")
    else:
        table.add_row("codrsync init", "Create new project with wizard")
        table.add_row("codrsync scan", "Scan existing project")
        table.add_row("codrsync auth", "Configure AI backend")

    console.print(Panel(
        table,
        title=f"[dim]{other_title}[/dim]",
        border_style="dim",
        padding=(0, 1),
    ))


def show_quick_tips(lang: str = "en") -> None:
    """Display quick tips including how to change language."""
    if lang == "pt-br":
        tips = [
            "[cyan]codrsync --help[/cyan] para ver todos os comandos",
            "[cyan]codrsync doctor[/cyan] para verificar instalação",
            "[cyan]codrsync config --lang en[/cyan] para mudar idioma",
        ]
        title = "💡 Dicas Rápidas"
    else:
        tips = [
            "[cyan]codrsync --help[/cyan] to see all commands",
            "[cyan]codrsync doctor[/cyan] to check installation",
            "[cyan]codrsync config --lang pt-br[/cyan] to change language",
        ]
        title = "💡 Quick Tips"

    console.print()
    console.print(Panel(
        "\n".join(f"  • {tip}" for tip in tips),
        title=f"[bold blue]{title}[/bold blue]",
        border_style="blue",
        padding=(0, 1),
    ))


def show_providers_info(lang: str = "en") -> None:
    """Display supported AI providers."""
    if lang == "pt-br":
        title = "🤖 Provedores de IA Suportados"
    else:
        title = "🤖 Supported AI Providers"

    providers = Table(show_header=False, box=None, padding=(0, 2))
    providers.add_column("Provider")
    providers.add_column("Models", style="dim")

    providers.add_row("[bold]Claude[/bold]", "Opus 4.5, Sonnet 4.5")
    providers.add_row("[bold]GPT[/bold]", "GPT-5.2, o3, o4-mini")
    providers.add_row("[bold]Gemini[/bold]", "Gemini 3 Pro/Flash")
    providers.add_row("[bold]Ollama[/bold]", "Local models (free)")

    console.print()
    console.print(Panel(
        providers,
        title=f"[bold magenta]{title}[/bold magenta]",
        border_style="magenta",
        padding=(0, 1),
    ))


def show_success_message(lang: str = "en") -> None:
    """Display success message after onboarding."""
    console.print()

    if lang == "pt-br":
        msg = "[bold green]✓[/bold green] codrsync configurado com sucesso!"
        hint = "Execute [bold cyan]codrsync start[/bold cyan] para começar"
    else:
        msg = "[bold green]✓[/bold green] codrsync configured successfully!"
        hint = "Run [bold cyan]codrsync start[/bold cyan] to get started"

    console.print(Align.center(msg))
    console.print(Align.center(hint))
    console.print()


def offer_ai_setup(lang: str) -> None:
    """Offer AI backend setup during onboarding.

    Guides the user to configure an AI provider so they're ready
    to use codrsync init and other AI-powered commands.
    """
    from codrsync.auth import (
        detect_claude_code, detect_anthropic_api, detect_openai_api,
        detect_codrsync_credits
    )

    # Check what's already available
    has_claude_code = detect_claude_code()
    has_anthropic = detect_anthropic_api()
    has_openai = detect_openai_api()
    has_credits = detect_codrsync_credits()

    # If user already has something configured, skip
    if has_claude_code or has_anthropic or has_openai or has_credits:
        return

    # Translations
    if lang == "pt-br":
        title = "🤖 Configurar Assistente de IA"
        intro = (
            "O codrsync usa IA para te ajudar a criar projetos.\n"
            "Configure agora para começar com o pé direito!"
        )
        opt_credits = "🎁 codrsync Credits (10 créditos GRÁTIS!)"
        opt_credits_desc = "Mais fácil - não precisa criar conta em outro lugar"
        opt_anthropic = "🔑 Já tenho API key da Anthropic"
        opt_openai = "🔑 Já tenho API key da OpenAI"
        opt_later = "⏭️  Configurar depois"
        opt_later_desc = "Você pode usar 'codrsync auth' a qualquer momento"
        choice_prompt = "Escolha uma opção"
        success_msg = "Assistente de IA configurado!"
        skipped_msg = "Sem problema! Configure depois com: codrsync auth"
    else:
        title = "🤖 Configure AI Assistant"
        intro = (
            "codrsync uses AI to help you create projects.\n"
            "Configure now to get started on the right foot!"
        )
        opt_credits = "🎁 codrsync Credits (10 FREE credits!)"
        opt_credits_desc = "Easiest - no need to create account elsewhere"
        opt_anthropic = "🔑 I already have an Anthropic API key"
        opt_openai = "🔑 I already have an OpenAI API key"
        opt_later = "⏭️  Configure later"
        opt_later_desc = "You can use 'codrsync auth' anytime"
        choice_prompt = "Choose an option"
        success_msg = "AI assistant configured!"
        skipped_msg = "No problem! Configure later with: codrsync auth"

    console.print()
    console.print(Panel(
        f"[bold]{intro}[/bold]",
        title=f"[cyan]{title}[/cyan]",
        border_style="cyan",
    ))

    # Build choices
    choices = [
        {"name": f"{opt_credits}\n      [dim]{opt_credits_desc}[/dim]", "value": "credits"},
        {"name": opt_anthropic, "value": "anthropic"},
        {"name": opt_openai, "value": "openai"},
        {"name": f"{opt_later}\n      [dim]{opt_later_desc}[/dim]", "value": "skip"},
    ]

    choice = questionary.select(
        choice_prompt,
        choices=choices,
        style=questionary.Style([
            ('highlighted', 'fg:cyan bold'),
            ('selected', 'fg:green'),
            ('pointer', 'fg:cyan bold'),
        ])
    ).ask()

    if choice == "credits":
        # Device flow authentication for codrsync credits
        from codrsync.device_auth import device_code_login
        config = get_config()

        console.print()
        if device_code_login(config):
            console.print(f"\n[green]✓[/green] {success_msg}")
            if config.codrsync_user_email:
                if lang == "pt-br":
                    console.print(f"  Logado como: [cyan]{config.codrsync_user_email}[/cyan]")
                else:
                    console.print(f"  Logged in as: [cyan]{config.codrsync_user_email}[/cyan]")

    elif choice == "anthropic":
        _setup_api_key("anthropic", lang)

    elif choice == "openai":
        _setup_api_key("openai", lang)

    else:  # skip
        console.print(f"\n[dim]{skipped_msg}[/dim]")


def _setup_api_key(provider: str, lang: str) -> bool:
    """Helper to set up an API key during onboarding."""
    # Translations
    if lang == "pt-br":
        if provider == "anthropic":
            instructions = (
                "[bold]Para obter sua chave Anthropic:[/bold]\n\n"
                "1. Acesse [link=https://console.anthropic.com/]console.anthropic.com[/link]\n"
                "2. Crie uma conta ou faça login\n"
                "3. Vá em Settings → API Keys\n"
                "4. Clique em 'Create Key'\n"
                "5. Copie e cole abaixo"
            )
            title = "Configurar Anthropic"
        else:
            instructions = (
                "[bold]Para obter sua chave OpenAI:[/bold]\n\n"
                "1. Acesse [link=https://platform.openai.com/api-keys]platform.openai.com/api-keys[/link]\n"
                "2. Crie uma conta ou faça login\n"
                "3. Clique em 'Create new secret key'\n"
                "4. Copie e cole abaixo"
            )
            title = "Configurar OpenAI"
        prompt = "Cole sua chave aqui (ou Enter para pular)"
        invalid_anthropic = "Chave inválida. Deve começar com 'sk-ant-'"
        invalid_openai = "Chave inválida. Deve começar com 'sk-'"
        success = "Chave salva com sucesso!"
    else:
        if provider == "anthropic":
            instructions = (
                "[bold]To get your Anthropic key:[/bold]\n\n"
                "1. Go to [link=https://console.anthropic.com/]console.anthropic.com[/link]\n"
                "2. Create account or log in\n"
                "3. Go to Settings → API Keys\n"
                "4. Click 'Create Key'\n"
                "5. Copy and paste below"
            )
            title = "Configure Anthropic"
        else:
            instructions = (
                "[bold]To get your OpenAI key:[/bold]\n\n"
                "1. Go to [link=https://platform.openai.com/api-keys]platform.openai.com/api-keys[/link]\n"
                "2. Create account or log in\n"
                "3. Click 'Create new secret key'\n"
                "4. Copy and paste below"
            )
            title = "Configure OpenAI"
        prompt = "Paste your key here (or Enter to skip)"
        invalid_anthropic = "Invalid key. Should start with 'sk-ant-'"
        invalid_openai = "Invalid key. Should start with 'sk-'"
        success = "Key saved successfully!"

    console.print()
    console.print(Panel(
        instructions,
        title=f"[cyan]{title}[/cyan]",
        border_style="cyan",
    ))

    key = questionary.password(prompt).ask()

    if not key:
        return False

    # Validate format
    if provider == "anthropic" and not key.startswith("sk-ant-"):
        console.print(f"[yellow]{invalid_anthropic}[/yellow]")
        return False

    if provider == "openai" and not key.startswith("sk-"):
        console.print(f"[yellow]{invalid_openai}[/yellow]")
        return False

    # Save key
    config = get_config()
    if provider == "anthropic":
        config.anthropic_api_key = key
        config.ai_backend = "anthropic-api"
        os.environ["ANTHROPIC_API_KEY"] = key
    else:
        config.openai_api_key = key
        config.ai_backend = "openai-api"
        os.environ["OPENAI_API_KEY"] = key
    config.save()

    console.print(f"\n[green]✓[/green] {success}")
    return True


def run_onboarding() -> None:
    """Run the first-run onboarding experience with hybrid language detection."""
    # Clear screen for clean experience
    console.clear()

    # Detect language first for proper header display
    detected_lang = detect_system_language()

    # Show welcome header with logo (in detected language)
    show_welcome_header(detected_lang)

    # Non-interactive mode: use auto-detection only
    if not sys.stdin.isatty():
        lang = detected_lang
    else:
        # Hybrid detection: detect first, then confirm
        detected_name = LANGUAGE_NAMES.get(detected_lang, detected_lang)

        console.print("[dim]─" * 50 + "[/dim]")
        console.print()

        # Show detected language and ask for confirmation
        if detected_lang == "pt-br":
            confirm_msg = f"🌍 Idioma detectado: [bold cyan]{detected_name}[/bold cyan]"
            confirm_prompt = "Confirmar idioma?"
        else:
            confirm_msg = f"🌍 Detected language: [bold cyan]{detected_name}[/bold cyan]"
            confirm_prompt = "Confirm language?"

        console.print(confirm_msg)
        console.print()

        # Build choices with detected language first
        choices = [
            {"name": f"✓ {detected_name} (detected)", "value": detected_lang},
        ]
        # Add other languages
        for choice in LANGUAGE_CHOICES:
            if choice["value"] != detected_lang and choice["value"] != "__other__":
                choices.append(choice)
        choices.append({"name": "Other (type language code)", "value": "__other__"})

        lang = questionary.select(
            confirm_prompt,
            choices=choices,
            style=questionary.Style([
                ('highlighted', 'fg:cyan bold'),
                ('selected', 'fg:green'),
                ('pointer', 'fg:cyan bold'),
            ])
        ).ask()

        if lang is None:
            lang = detected_lang

        if lang == "__other__":
            lang = questionary.text(
                "Enter language code (e.g. ja, ko, zh):"
            ).ask()
            if not lang:
                lang = detected_lang
            lang = lang.strip().lower()

    # For non-built-in languages, try API translation
    if lang not in BUILTIN_LANGUAGES:
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            try:
                cfg = Config.load()
                api_key = cfg.anthropic_api_key
            except Exception:
                pass

        if not api_key:
            console.print()
            if detected_lang == "pt-br":
                console.print(Panel(
                    f"[yellow]Idioma '{lang}' requer tradução via API.[/yellow]\n"
                    "Nenhuma chave API configurada. Usando Português.\n\n"
                    "Execute [bold cyan]codrsync auth[/bold cyan] para configurar.",
                    border_style="yellow",
                ))
                lang = "pt-br"
            else:
                console.print(Panel(
                    f"[yellow]Language '{lang}' requires translation via API.[/yellow]\n"
                    "No API key configured. Using English.\n\n"
                    "Run [bold cyan]codrsync auth[/bold cyan] to configure.",
                    border_style="yellow",
                ))
                lang = "en"
        else:
            if lang == "pt-br":
                console.print(f"\n  [dim]Traduzindo para {lang}...[/dim]")
            else:
                console.print(f"\n  [dim]Translating to {lang}...[/dim]")
            from codrsync.i18n.translator import translate_via_api
            result = translate_via_api(lang, api_key)
            if result is None:
                if detected_lang == "pt-br":
                    console.print("  [yellow]Tradução falhou. Usando Português.[/yellow]")
                    lang = "pt-br"
                else:
                    console.print("  [yellow]Translation failed. Using English.[/yellow]")
                    lang = "en"

    # Activate language
    setup_language(lang)

    # Save config with language preference
    CODRSYNC_HOME.mkdir(parents=True, exist_ok=True)
    config = Config(language=lang)
    config.save()

    # NEW: Offer AI setup if no backend is configured
    if sys.stdin.isatty():
        offer_ai_setup(lang)

    # Show next steps
    show_next_steps(lang)

    # Show quick tips
    show_quick_tips(lang)

    # Show providers info
    show_providers_info(lang)

    # Show success message
    show_success_message(lang)


def show_welcome_back() -> None:
    """Show a brief welcome back message for returning users."""
    from codrsync.config import Config

    cfg = Config.load()
    lang = cfg.language or "en"

    # Get localized taglines
    tagline_data = TAGLINES.get(lang, TAGLINES["en"])

    console.print()
    # Print logo centered
    console.print(Align.center(Text.from_markup(LOGO_ASCII.strip())))
    console.print()
    # Print tagline centered
    console.print(Align.center(Text.from_markup(f"[bold yellow]{tagline_data['main']}[/bold yellow]")))
    console.print(Align.center(Text.from_markup(f"[dim]{tagline_data['sub']}[/dim]")))
    console.print()

    if lang == "pt-br":
        msg = "[bold cyan]Bem-vindo de volta![/bold cyan]"
        hint = "Execute [bold green]codrsync start[/bold green] para iniciar o modo superego"
        help_hint = "ou [dim]codrsync --help[/dim] para ver todos os comandos"
    else:
        msg = "[bold cyan]Welcome back![/bold cyan]"
        hint = "Run [bold green]codrsync start[/bold green] to launch superego mode"
        help_hint = "or [dim]codrsync --help[/dim] to see all commands"

    console.print(Align.center(msg))
    console.print()
    console.print(Align.center(hint))
    console.print(Align.center(help_hint))
    console.print()
