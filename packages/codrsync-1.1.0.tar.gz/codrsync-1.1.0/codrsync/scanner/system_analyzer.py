"""
System Analyzer - Detect user's system limitations for cloud upsell.

Analyzes:
- RAM (memory)
- CPU cores
- Disk space
- OS version
- Installed tools
"""

import os
import platform
import shutil
from dataclasses import dataclass
from typing import List, Optional, Dict, Any


@dataclass
class SystemInfo:
    """System information."""
    os_name: str
    os_version: str
    cpu_cores: int
    cpu_threads: int
    ram_gb: float
    disk_free_gb: float
    disk_total_gb: float
    machine: str  # arm64, x86_64
    hostname: str


@dataclass
class SystemLimitation:
    """A detected system limitation."""
    type: str  # 'low_ram', 'low_cpu', 'low_disk', 'old_os'
    severity: str  # 'warning', 'critical'
    current_value: str
    recommended_value: str
    impact: str  # User-friendly impact description
    cloud_benefit: str  # What cloud offers instead


def get_system_info() -> SystemInfo:
    """Collect system information."""
    # OS info
    system = platform.system()
    if system == "Darwin":
        os_name = "macOS"
        # Get macOS version name
        mac_ver = platform.mac_ver()[0]
        os_version = mac_ver
    elif system == "Linux":
        os_name = "Linux"
        try:
            import distro
            os_version = f"{distro.name()} {distro.version()}"
        except ImportError:
            os_version = platform.release()
    else:
        os_name = system
        os_version = platform.release()

    # CPU info
    cpu_cores = os.cpu_count() or 1
    # Logical vs physical cores
    try:
        import psutil
        cpu_physical = psutil.cpu_count(logical=False) or cpu_cores
        cpu_logical = psutil.cpu_count(logical=True) or cpu_cores
    except ImportError:
        cpu_physical = cpu_cores
        cpu_logical = cpu_cores

    # RAM info
    try:
        import psutil
        ram_bytes = psutil.virtual_memory().total
        ram_gb = round(ram_bytes / (1024**3), 1)
    except ImportError:
        # Fallback for systems without psutil
        ram_gb = _get_ram_fallback()

    # Disk info
    try:
        disk_usage = shutil.disk_usage(os.path.expanduser("~"))
        disk_free_gb = round(disk_usage.free / (1024**3), 1)
        disk_total_gb = round(disk_usage.total / (1024**3), 1)
    except Exception:
        disk_free_gb = 0
        disk_total_gb = 0

    return SystemInfo(
        os_name=os_name,
        os_version=os_version,
        cpu_cores=cpu_physical,
        cpu_threads=cpu_logical,
        ram_gb=ram_gb,
        disk_free_gb=disk_free_gb,
        disk_total_gb=disk_total_gb,
        machine=platform.machine(),
        hostname=platform.node(),
    )


def _get_ram_fallback() -> float:
    """Get RAM without psutil (macOS/Linux only)."""
    system = platform.system()

    if system == "Darwin":
        try:
            import subprocess
            result = subprocess.run(
                ["sysctl", "-n", "hw.memsize"],
                capture_output=True, text=True
            )
            if result.returncode == 0:
                return round(int(result.stdout.strip()) / (1024**3), 1)
        except Exception:
            pass

    elif system == "Linux":
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        kb = int(line.split()[1])
                        return round(kb / (1024**2), 1)
        except Exception:
            pass

    return 8.0  # Default assumption


def analyze_limitations(system_info: SystemInfo, language: str = "pt") -> List[SystemLimitation]:
    """
    Analyze system and identify limitations that could benefit from cloud.

    Args:
        system_info: System information
        language: 'pt' or 'en' for messages

    Returns:
        List of detected limitations
    """
    limitations = []

    # Translations
    if language == "pt":
        msgs = {
            "low_ram_impact": "Projetos grandes podem travar ou ficar lentos",
            "low_ram_cloud": "16GB RAM dedicados, sem impactar seu Mac",
            "very_low_ram_impact": "Muitos projetos modernos não vão rodar bem",
            "low_cpu_impact": "Builds e compilações vão demorar mais",
            "low_cpu_cloud": "8 vCPUs dedicados para builds rápidos",
            "low_disk_impact": "Pode faltar espaço para node_modules e Docker",
            "low_disk_cloud": "100GB SSD NVMe ultra-rápido",
            "very_low_disk_impact": "Instalação de dependências vai falhar",
        }
    else:
        msgs = {
            "low_ram_impact": "Large projects may freeze or slow down",
            "low_ram_cloud": "16GB dedicated RAM, no impact on your Mac",
            "very_low_ram_impact": "Many modern projects won't run well",
            "low_cpu_impact": "Builds and compilations will take longer",
            "low_cpu_cloud": "8 dedicated vCPUs for fast builds",
            "low_disk_impact": "May run out of space for node_modules and Docker",
            "low_disk_cloud": "100GB ultra-fast NVMe SSD",
            "very_low_disk_impact": "Dependency installation will fail",
        }

    # Check RAM
    if system_info.ram_gb < 4:
        limitations.append(SystemLimitation(
            type="low_ram",
            severity="critical",
            current_value=f"{system_info.ram_gb}GB",
            recommended_value="8GB+",
            impact=msgs["very_low_ram_impact"],
            cloud_benefit=msgs["low_ram_cloud"],
        ))
    elif system_info.ram_gb < 8:
        limitations.append(SystemLimitation(
            type="low_ram",
            severity="warning",
            current_value=f"{system_info.ram_gb}GB",
            recommended_value="8GB+",
            impact=msgs["low_ram_impact"],
            cloud_benefit=msgs["low_ram_cloud"],
        ))

    # Check CPU
    if system_info.cpu_cores < 4:
        limitations.append(SystemLimitation(
            type="low_cpu",
            severity="warning",
            current_value=f"{system_info.cpu_cores} cores",
            recommended_value="4+ cores",
            impact=msgs["low_cpu_impact"],
            cloud_benefit=msgs["low_cpu_cloud"],
        ))

    # Check disk space
    if system_info.disk_free_gb < 10:
        limitations.append(SystemLimitation(
            type="low_disk",
            severity="critical",
            current_value=f"{system_info.disk_free_gb}GB livre",
            recommended_value="20GB+",
            impact=msgs["very_low_disk_impact"],
            cloud_benefit=msgs["low_disk_cloud"],
        ))
    elif system_info.disk_free_gb < 20:
        limitations.append(SystemLimitation(
            type="low_disk",
            severity="warning",
            current_value=f"{system_info.disk_free_gb}GB livre",
            recommended_value="20GB+",
            impact=msgs["low_disk_impact"],
            cloud_benefit=msgs["low_disk_cloud"],
        ))

    return limitations


def get_cloud_recommendation(
    system_info: SystemInfo,
    limitations: List[SystemLimitation],
    language: str = "pt"
) -> Optional[Dict[str, Any]]:
    """
    Generate a cloud workspace recommendation based on limitations.

    Returns None if no recommendation (system is adequate).
    """
    if not limitations:
        return None

    # Count severity
    critical_count = sum(1 for l in limitations if l.severity == "critical")
    warning_count = sum(1 for l in limitations if l.severity == "warning")

    # Determine recommendation strength
    if critical_count > 0:
        strength = "strong"
    elif warning_count >= 2:
        strength = "moderate"
    else:
        strength = "light"

    # Translations
    if language == "pt":
        if strength == "strong":
            headline = "Seu sistema pode ter dificuldades com projetos modernos"
            cta = "Experimente o Cloud Workspace com 10 créditos GRÁTIS!"
        elif strength == "moderate":
            headline = "Detectamos algumas limitações no seu sistema"
            cta = "Um Cloud Workspace pode melhorar sua experiência"
        else:
            headline = "Dica: Cloud Workspace disponível"
            cta = "Desenvolva sem impactar a performance do seu Mac"

        benefits = [
            "16GB RAM dedicados",
            "8 vCPUs para builds rápidos",
            "100GB SSD NVMe",
            "Claude Code + codrsync pré-configurados",
            "Acesse de qualquer lugar",
        ]
    else:
        if strength == "strong":
            headline = "Your system may struggle with modern projects"
            cta = "Try Cloud Workspace with 10 FREE credits!"
        elif strength == "moderate":
            headline = "We detected some limitations on your system"
            cta = "A Cloud Workspace can improve your experience"
        else:
            headline = "Tip: Cloud Workspace available"
            cta = "Develop without impacting your Mac's performance"

        benefits = [
            "16GB dedicated RAM",
            "8 vCPUs for fast builds",
            "100GB NVMe SSD",
            "Claude Code + codrsync pre-configured",
            "Access from anywhere",
        ]

    return {
        "strength": strength,
        "headline": headline,
        "cta": cta,
        "benefits": benefits,
        "limitations": [
            {
                "type": l.type,
                "severity": l.severity,
                "current": l.current_value,
                "impact": l.impact,
                "cloud_benefit": l.cloud_benefit,
            }
            for l in limitations
        ],
        "free_credits": 10,
        "pricing": {
            "per_hour": 1,  # 1 credit per hour
            "currency": "BRL" if language == "pt" else "USD",
            "starter_price": 25 if language == "pt" else 5,
        },
    }


def format_upsell_panel(recommendation: Dict[str, Any], language: str = "pt") -> str:
    """Format the upsell recommendation as a rich panel string."""
    if not recommendation:
        return ""

    lines = []

    # Headline
    lines.append(f"[bold yellow]{recommendation['headline']}[/bold yellow]")
    lines.append("")

    # Limitations
    for lim in recommendation["limitations"]:
        icon = "🔴" if lim["severity"] == "critical" else "🟡"
        lines.append(f"  {icon} {lim['current']}: {lim['impact']}")

    lines.append("")
    lines.append("[bold cyan]Com Cloud Workspace você tem:[/bold cyan]" if language == "pt"
                 else "[bold cyan]With Cloud Workspace you get:[/bold cyan]")
    lines.append("")

    # Benefits
    for benefit in recommendation["benefits"]:
        lines.append(f"  [green]✓[/green] {benefit}")

    lines.append("")

    # Pricing
    currency = recommendation["pricing"]["currency"]
    price = recommendation["pricing"]["starter_price"]
    if language == "pt":
        lines.append(f"[dim]Custo: ~R${price}/mês para uso leve (Starter)[/dim]")
    else:
        lines.append(f"[dim]Cost: ~${price}/month for light usage (Starter)[/dim]")

    lines.append("")
    lines.append(f"[bold green]🎁 {recommendation['cta']}[/bold green]")

    return "\n".join(lines)


# Quick test
if __name__ == "__main__":
    info = get_system_info()
    print(f"System: {info.os_name} {info.os_version}")
    print(f"CPU: {info.cpu_cores} cores ({info.cpu_threads} threads)")
    print(f"RAM: {info.ram_gb}GB")
    print(f"Disk: {info.disk_free_gb}GB free / {info.disk_total_gb}GB total")
    print(f"Machine: {info.machine}")
    print()

    limitations = analyze_limitations(info)
    if limitations:
        print("Limitations found:")
        for l in limitations:
            print(f"  - {l.type} ({l.severity}): {l.current_value}")
    else:
        print("No limitations detected.")

    rec = get_cloud_recommendation(info, limitations)
    if rec:
        print()
        print("Recommendation:")
        print(format_upsell_panel(rec))
