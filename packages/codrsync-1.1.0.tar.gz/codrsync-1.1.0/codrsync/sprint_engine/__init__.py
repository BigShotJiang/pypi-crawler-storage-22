"""
Sprint Engine - Automatic Sprint Management for codrsync

This module provides:
- Session and time tracking (tracker.py)
- Story completion detection (matcher.py)
- Metrics calculation (metrics.py)
- Documentation synchronization (sync.py)
- Estimation calibration via RAG (calibration.py)
"""

from codrsync.sprint_engine.tracker import (
    TimeTracker,
    Session,
    start_session,
    end_session,
    get_active_session,
    get_story_time,
)

from codrsync.sprint_engine.matcher import (
    StoryMatcher,
    CompletionSignal,
    should_auto_complete,
    map_file_to_story,
    get_completion_signals,
)

from codrsync.sprint_engine.metrics import (
    MetricsEngine,
    calculate_velocity,
    calculate_burndown,
    calculate_points_per_hour,
)

from codrsync.sprint_engine.sync import (
    DocumentationSync,
    sync_progress_docs,
    update_story_status,
)

from codrsync.sprint_engine.calibration import (
    CalibrationRAG,
    suggest_story_points,
    record_story_completion,
    get_calibration_stats,
)

__all__ = [
    # Tracker
    "TimeTracker",
    "Session",
    "start_session",
    "end_session",
    "get_active_session",
    "get_story_time",
    # Matcher
    "StoryMatcher",
    "CompletionSignal",
    "should_auto_complete",
    "map_file_to_story",
    "get_completion_signals",
    # Metrics
    "MetricsEngine",
    "calculate_velocity",
    "calculate_burndown",
    "calculate_points_per_hour",
    # Sync
    "DocumentationSync",
    "sync_progress_docs",
    "update_story_status",
    # Calibration
    "CalibrationRAG",
    "suggest_story_points",
    "record_story_completion",
    "get_calibration_stats",
]
