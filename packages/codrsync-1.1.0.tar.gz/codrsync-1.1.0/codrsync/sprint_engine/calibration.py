"""
Calibration RAG - Estimation calibration through historical data

Learns from completed stories to improve future estimations.
Uses a RAG-like approach to find similar stories and suggest
calibrated story points based on actual performance data.
"""

import json
import re
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple


@dataclass
class StorySample:
    """A completed story sample for calibration."""

    id: str
    project: str
    story_type: str
    tags: List[str]
    complexity_signals: Dict[str, Any]
    estimation: Dict[str, Any]
    actual: Dict[str, Any]
    accuracy: float
    completed_at: str


@dataclass
class CalibrationSuggestion:
    """A calibrated estimation suggestion."""

    points: int
    confidence: float
    estimated_hours: float
    source: str  # "calibration_rag", "default", "insufficient_data"
    similar_stories: int
    message: str


class CalibrationRAG:
    """RAG engine for estimation calibration."""

    # Story type patterns
    STORY_TYPE_PATTERNS = {
        "api_endpoint": [
            r"endpoint", r"api", r"route", r"rest", r"graphql",
        ],
        "ui_component": [
            r"component", r"ui", r"interface", r"screen", r"page", r"modal",
        ],
        "bug_fix": [
            r"fix", r"bug", r"issue", r"error", r"broken", r"crash",
        ],
        "refactor": [
            r"refactor", r"cleanup", r"improve", r"optimize", r"reorganize",
        ],
        "feature": [
            r"feature", r"implement", r"add", r"create", r"build",
        ],
        "test": [
            r"test", r"testing", r"spec", r"coverage",
        ],
        "docs": [
            r"doc", r"documentation", r"readme", r"guide",
        ],
        "infrastructure": [
            r"deploy", r"ci", r"cd", r"pipeline", r"docker", r"kubernetes",
        ],
    }

    # Default hours per point by story type
    DEFAULT_HOURS_PER_POINT = {
        "api_endpoint": 1.0,
        "ui_component": 1.2,
        "bug_fix": 0.5,
        "refactor": 0.8,
        "feature": 1.0,
        "test": 0.6,
        "docs": 0.4,
        "infrastructure": 1.5,
        "unknown": 1.0,
    }

    # Tag multipliers
    TAG_MULTIPLIERS = {
        "auth": 1.3,
        "security": 1.4,
        "crud": 0.8,
        "migration": 1.4,
        "database": 1.2,
        "external_api": 1.3,
        "complex": 1.5,
        "simple": 0.7,
    }

    def __init__(self, config_dir: Optional[Path] = None):
        """Initialize calibration RAG.

        Args:
            config_dir: Directory for calibration data (default: ~/.codrsync/)
        """
        if config_dir is None:
            config_dir = Path.home() / ".codrsync"

        self.config_dir = config_dir
        self.history_path = config_dir / "calibration_history.json"
        self.config_dir.mkdir(parents=True, exist_ok=True)

    def load_history(self) -> Dict[str, Any]:
        """Load calibration history."""
        if not self.history_path.exists():
            return {
                "version": "1.0",
                "stories": [],
                "aggregates": {
                    "by_type": {},
                    "by_tag": {},
                    "global_velocity": {
                        "points_per_hour": 1.0,
                        "trend": "stable",
                    },
                },
            }

        try:
            return json.loads(self.history_path.read_text())
        except (json.JSONDecodeError, IOError):
            return {
                "version": "1.0",
                "stories": [],
                "aggregates": {
                    "by_type": {},
                    "by_tag": {},
                    "global_velocity": {
                        "points_per_hour": 1.0,
                        "trend": "stable",
                    },
                },
            }

    def save_history(self, history: Dict[str, Any]) -> bool:
        """Save calibration history."""
        try:
            self.history_path.write_text(json.dumps(history, indent=2))
            return True
        except IOError:
            return False

    def classify_story_type(self, description: str) -> str:
        """Classify story type from description.

        Args:
            description: Story description

        Returns:
            Story type string
        """
        description_lower = description.lower()

        for story_type, patterns in self.STORY_TYPE_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, description_lower):
                    return story_type

        return "unknown"

    def extract_complexity_signals(
        self,
        description: str,
        tags: List[str],
    ) -> Dict[str, Any]:
        """Extract complexity signals from story.

        Args:
            description: Story description
            tags: Story tags

        Returns:
            Complexity signals dictionary
        """
        description_lower = description.lower()

        return {
            "has_tests": any(t in tags for t in ["test", "tests", "testing"]),
            "has_db_migration": any(
                kw in description_lower
                for kw in ["migration", "schema", "database", "db"]
            ),
            "has_external_api": any(
                kw in description_lower
                for kw in ["external", "third-party", "api", "integration"]
            ),
            "has_auth": any(
                kw in description_lower
                for kw in ["auth", "login", "permission", "security"]
            ),
            "estimated_files": self._estimate_file_count(description),
        }

    def _estimate_file_count(self, description: str) -> int:
        """Estimate number of files from description."""
        # Simple heuristic based on description length and keywords
        word_count = len(description.split())

        if word_count < 10:
            return 1
        elif word_count < 30:
            return 2
        elif word_count < 50:
            return 4
        else:
            return 6

    def find_similar_stories(
        self,
        story_type: str,
        tags: List[str],
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """Find similar stories in history.

        Args:
            story_type: Story type
            tags: Story tags
            limit: Maximum number of results

        Returns:
            List of similar story samples
        """
        history = self.load_history()
        stories = history.get("stories", [])

        if not stories:
            return []

        # Score each story by similarity
        scored = []
        for story in stories:
            score = 0.0

            # Type match
            if story.get("story_type") == story_type:
                score += 2.0

            # Tag matches
            story_tags = set(story.get("tags", []))
            input_tags = set(tags)
            common_tags = story_tags & input_tags

            score += len(common_tags) * 0.5

            # Recency boost (more recent = higher score)
            try:
                completed = datetime.fromisoformat(story.get("completed_at", ""))
                days_ago = (datetime.now() - completed).days
                recency_boost = max(0, 1 - days_ago / 365)  # Linear decay over year
                score += recency_boost
            except ValueError:
                pass

            scored.append((score, story))

        # Sort by score descending
        scored.sort(key=lambda x: x[0], reverse=True)

        # Return top matches
        return [s[1] for s in scored[:limit] if s[0] > 0]

    def calculate_weighted_average(
        self,
        similar_stories: List[Dict[str, Any]],
    ) -> float:
        """Calculate weighted average hours from similar stories.

        Args:
            similar_stories: List of similar story samples

        Returns:
            Weighted average hours
        """
        if not similar_stories:
            return 0.0

        total_weight = 0.0
        weighted_hours = 0.0

        for i, story in enumerate(similar_stories):
            # More recent stories get higher weight
            weight = 1.0 / (i + 1)

            actual = story.get("actual", {})
            hours = actual.get("hours", 0)

            weighted_hours += hours * weight
            total_weight += weight

        return weighted_hours / total_weight if total_weight > 0 else 0.0

    def hours_to_points(self, hours: float) -> int:
        """Convert hours to story points.

        Args:
            hours: Estimated hours

        Returns:
            Story points (1, 2, 3, 5, 8, 13)
        """
        # Fibonacci-like point scale
        if hours <= 0.5:
            return 1
        elif hours <= 1:
            return 2
        elif hours <= 2:
            return 3
        elif hours <= 4:
            return 5
        elif hours <= 8:
            return 8
        else:
            return 13

    def suggest_story_points(
        self,
        description: str,
        tags: List[str],
    ) -> CalibrationSuggestion:
        """Suggest story points based on historical data.

        Args:
            description: Story description
            tags: Story tags

        Returns:
            CalibrationSuggestion with points and confidence
        """
        # Classify story type
        story_type = self.classify_story_type(description)

        # Find similar stories
        similar = self.find_similar_stories(story_type, tags)

        if len(similar) < 3:
            # Insufficient data - use defaults
            default_hours = self.DEFAULT_HOURS_PER_POINT.get(
                story_type, self.DEFAULT_HOURS_PER_POINT["unknown"]
            )

            # Apply tag multipliers
            for tag in tags:
                if tag in self.TAG_MULTIPLIERS:
                    default_hours *= self.TAG_MULTIPLIERS[tag]

            points = self.hours_to_points(default_hours)

            return CalibrationSuggestion(
                points=points,
                confidence=0.3,
                estimated_hours=default_hours,
                source="default",
                similar_stories=len(similar),
                message=f"Insufficient historical data ({len(similar)} samples). Using default estimate.",
            )

        # Calculate weighted average hours
        weighted_hours = self.calculate_weighted_average(similar)

        # Apply tag multipliers
        for tag in tags:
            if tag in self.TAG_MULTIPLIERS:
                weighted_hours *= self.TAG_MULTIPLIERS[tag]

        # Convert to points
        points = self.hours_to_points(weighted_hours)

        # Calculate confidence based on variance
        hours_list = [
            s.get("actual", {}).get("hours", 0)
            for s in similar
            if s.get("actual", {}).get("hours", 0) > 0
        ]

        if len(hours_list) >= 2:
            mean = sum(hours_list) / len(hours_list)
            variance = sum((h - mean) ** 2 for h in hours_list) / len(hours_list)
            std_dev = variance ** 0.5

            # Lower variance = higher confidence
            cv = std_dev / mean if mean > 0 else 1.0
            confidence = max(0.4, min(0.95, 1 - cv))
        else:
            confidence = 0.5

        return CalibrationSuggestion(
            points=points,
            confidence=confidence,
            estimated_hours=round(weighted_hours, 1),
            source="calibration_rag",
            similar_stories=len(similar),
            message=f"Based on {len(similar)} similar stories",
        )

    def record_story_completion(
        self,
        story_id: str,
        project: str,
        description: str,
        tags: List[str],
        estimated_points: int,
        estimated_hours: float,
        actual_hours: float,
        actual_sessions: int,
        files_touched: int,
    ) -> float:
        """Record completed story for future calibration.

        Args:
            story_id: Story ID
            project: Project name
            description: Story description
            tags: Story tags
            estimated_points: Original estimate in points
            estimated_hours: Original estimate in hours
            actual_hours: Actual hours spent
            actual_sessions: Number of sessions
            files_touched: Number of files touched

        Returns:
            Accuracy ratio (actual / estimated)
        """
        history = self.load_history()

        # Calculate accuracy
        accuracy = actual_hours / estimated_hours if estimated_hours > 0 else 1.0

        # Create story sample
        sample = {
            "id": f"{project}-{story_id}",
            "project": project,
            "story_type": self.classify_story_type(description),
            "tags": tags,
            "complexity_signals": self.extract_complexity_signals(description, tags),
            "estimation": {
                "points": estimated_points,
                "estimated_hours": estimated_hours,
            },
            "actual": {
                "hours": actual_hours,
                "sessions": actual_sessions,
                "files_touched": files_touched,
            },
            "accuracy": round(accuracy, 2),
            "completed_at": datetime.now().isoformat(),
        }

        # Add to history
        history["stories"].append(sample)

        # Update aggregates
        self._update_aggregates(history, sample)

        self.save_history(history)
        return accuracy

    def _update_aggregates(
        self,
        history: Dict[str, Any],
        sample: Dict[str, Any],
    ) -> None:
        """Update aggregate statistics.

        Args:
            history: History data
            sample: New story sample
        """
        aggregates = history.setdefault("aggregates", {})
        story_type = sample.get("story_type", "unknown")
        tags = sample.get("tags", [])
        actual_hours = sample.get("actual", {}).get("hours", 0)
        points = sample.get("estimation", {}).get("points", 0)

        # Update by_type
        by_type = aggregates.setdefault("by_type", {})
        type_stats = by_type.setdefault(story_type, {
            "count": 0,
            "total_hours": 0,
            "total_points": 0,
            "accuracy_sum": 0,
        })

        type_stats["count"] += 1
        type_stats["total_hours"] += actual_hours
        type_stats["total_points"] += points
        type_stats["accuracy_sum"] += sample.get("accuracy", 1.0)

        if type_stats["total_points"] > 0:
            type_stats["avg_hours_per_point"] = round(
                type_stats["total_hours"] / type_stats["total_points"], 2
            )
        type_stats["accuracy_trend"] = round(
            type_stats["accuracy_sum"] / type_stats["count"], 2
        )

        # Update by_tag
        by_tag = aggregates.setdefault("by_tag", {})
        for tag in tags:
            if tag not in by_tag:
                by_tag[tag] = {"count": 0, "total_accuracy": 0}

            by_tag[tag]["count"] += 1
            by_tag[tag]["total_accuracy"] += sample.get("accuracy", 1.0)
            by_tag[tag]["multiplier"] = round(
                by_tag[tag]["total_accuracy"] / by_tag[tag]["count"], 2
            )

        # Update global velocity
        all_samples = history.get("stories", [])
        if len(all_samples) >= 3:
            recent = all_samples[-10:]  # Last 10 samples
            total_points = sum(
                s.get("estimation", {}).get("points", 0) for s in recent
            )
            total_hours = sum(
                s.get("actual", {}).get("hours", 0) for s in recent
            )

            if total_hours > 0:
                current_velocity = total_points / total_hours
                prev_velocity = aggregates.get("global_velocity", {}).get(
                    "points_per_hour", 1.0
                )

                aggregates["global_velocity"] = {
                    "points_per_hour": round(current_velocity, 2),
                    "trend": "improving" if current_velocity > prev_velocity else (
                        "declining" if current_velocity < prev_velocity * 0.9 else "stable"
                    ),
                }

    def get_calibration_stats(self) -> Dict[str, Any]:
        """Get calibration statistics.

        Returns:
            Dictionary with calibration stats
        """
        history = self.load_history()
        stories = history.get("stories", [])
        aggregates = history.get("aggregates", {})

        return {
            "total_stories": len(stories),
            "by_type": aggregates.get("by_type", {}),
            "by_tag": aggregates.get("by_tag", {}),
            "global_velocity": aggregates.get("global_velocity", {}),
        }

    def export_calibration(self) -> str:
        """Export calibration data as JSON string.

        Returns:
            JSON string of calibration data
        """
        history = self.load_history()
        return json.dumps(history, indent=2)

    def import_calibration(self, data: str) -> int:
        """Import calibration data from JSON string.

        Args:
            data: JSON string of calibration data

        Returns:
            Number of stories imported
        """
        try:
            imported = json.loads(data)
        except json.JSONDecodeError:
            return 0

        history = self.load_history()

        # Merge stories (avoid duplicates by ID)
        existing_ids = {s.get("id") for s in history.get("stories", [])}
        new_stories = [
            s for s in imported.get("stories", [])
            if s.get("id") not in existing_ids
        ]

        history["stories"].extend(new_stories)

        # Recalculate aggregates
        history["aggregates"] = {
            "by_type": {},
            "by_tag": {},
            "global_velocity": {"points_per_hour": 1.0, "trend": "stable"},
        }

        for sample in history["stories"]:
            self._update_aggregates(history, sample)

        self.save_history(history)
        return len(new_stories)


# Module-level convenience functions
def suggest_story_points(
    description: str,
    tags: List[str],
    config_dir: Optional[Path] = None,
) -> CalibrationSuggestion:
    """Suggest story points based on historical data.

    Args:
        description: Story description
        tags: Story tags
        config_dir: Optional config directory

    Returns:
        CalibrationSuggestion
    """
    rag = CalibrationRAG(config_dir)
    return rag.suggest_story_points(description, tags)


def record_story_completion(
    story_id: str,
    project: str,
    description: str,
    tags: List[str],
    estimated_points: int,
    estimated_hours: float,
    actual_hours: float,
    actual_sessions: int = 1,
    files_touched: int = 1,
    config_dir: Optional[Path] = None,
) -> float:
    """Record completed story for calibration.

    Args:
        story_id: Story ID
        project: Project name
        description: Story description
        tags: Story tags
        estimated_points: Original estimate in points
        estimated_hours: Original estimate in hours
        actual_hours: Actual hours spent
        actual_sessions: Number of sessions
        files_touched: Number of files touched
        config_dir: Optional config directory

    Returns:
        Accuracy ratio
    """
    rag = CalibrationRAG(config_dir)
    return rag.record_story_completion(
        story_id, project, description, tags,
        estimated_points, estimated_hours,
        actual_hours, actual_sessions, files_touched,
    )


def get_calibration_stats(config_dir: Optional[Path] = None) -> Dict[str, Any]:
    """Get calibration statistics.

    Args:
        config_dir: Optional config directory

    Returns:
        Calibration stats
    """
    rag = CalibrationRAG(config_dir)
    return rag.get_calibration_stats()
