"""
Story Matcher - Completion detection and file-to-story mapping

Detects when stories are completed based on various signals:
- Explicit markers (user says "done")
- Acceptance criteria completion
- Test file creation/modification
- File touch patterns
- Keyword detection
"""

import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple, Set


@dataclass
class CompletionSignal:
    """Represents a completion signal for a story."""

    signal_type: str  # explicit, criteria, tests, files, keywords
    confidence: float  # 0.0 to 1.0
    reason: str
    detected_at: str


class StoryMatcher:
    """Matches files to stories and detects completion."""

    # Completion keywords in different languages
    COMPLETION_KEYWORDS = {
        "en": [
            "done", "complete", "completed", "finished", "implemented",
            "fixed", "resolved", "ready", "working",
        ],
        "pt-br": [
            "pronto", "completo", "concluido", "finalizado", "implementado",
            "corrigido", "resolvido", "funcionando",
        ],
    }

    # Test file patterns
    TEST_PATTERNS = [
        r"test_.*\.py$",
        r".*_test\.py$",
        r".*\.test\.(js|ts|tsx|jsx)$",
        r".*\.spec\.(js|ts|tsx|jsx)$",
        r"tests?/.*\.(py|js|ts)$",
        r"__tests__/.*\.(js|ts|tsx|jsx)$",
    ]

    # Default confidence threshold for auto-completion
    DEFAULT_THRESHOLD = 0.8

    def __init__(self, codrsync_dir: Path):
        """Initialize story matcher.

        Args:
            codrsync_dir: Path to .codrsync directory
        """
        self.codrsync_dir = codrsync_dir
        self.progress_path = codrsync_dir / "progress.json"
        self.story_files_path = codrsync_dir / "story-files.json"

    def load_progress(self) -> Dict[str, Any]:
        """Load progress.json data."""
        if not self.progress_path.exists():
            return {}

        try:
            return json.loads(self.progress_path.read_text())
        except (json.JSONDecodeError, IOError):
            return {}

    def save_progress(self, progress: Dict[str, Any]) -> bool:
        """Save progress.json data."""
        try:
            self.progress_path.write_text(json.dumps(progress, indent=2))
            return True
        except IOError:
            return False

    def load_story_files(self) -> Dict[str, Any]:
        """Load story-files.json mapping."""
        if not self.story_files_path.exists():
            return {"file_to_story": {}, "story_to_files": {}}

        try:
            return json.loads(self.story_files_path.read_text())
        except (json.JSONDecodeError, IOError):
            return {"file_to_story": {}, "story_to_files": {}}

    def save_story_files(self, mapping: Dict[str, Any]) -> bool:
        """Save story-files.json mapping."""
        try:
            self.story_files_path.write_text(json.dumps(mapping, indent=2))
            return True
        except IOError:
            return False

    def map_file_to_story(self, file_path: str, story_id: str) -> None:
        """Map a file to a story.

        Args:
            file_path: Relative path to the file
            story_id: Story ID
        """
        mapping = self.load_story_files()

        # Update file_to_story
        if file_path not in mapping["file_to_story"]:
            mapping["file_to_story"][file_path] = []
        if story_id not in mapping["file_to_story"][file_path]:
            mapping["file_to_story"][file_path].append(story_id)

        # Update story_to_files
        if story_id not in mapping["story_to_files"]:
            mapping["story_to_files"][story_id] = {"created": [], "tested": []}

        # Categorize file
        is_test = any(re.match(p, file_path) for p in self.TEST_PATTERNS)
        category = "tested" if is_test else "created"

        if file_path not in mapping["story_to_files"][story_id][category]:
            mapping["story_to_files"][story_id][category].append(file_path)

        self.save_story_files(mapping)

    def get_story_for_file(self, file_path: str) -> List[str]:
        """Get stories associated with a file.

        Args:
            file_path: Relative path to the file

        Returns:
            List of story IDs
        """
        mapping = self.load_story_files()
        return mapping.get("file_to_story", {}).get(file_path, [])

    def get_files_for_story(self, story_id: str) -> Dict[str, List[str]]:
        """Get files associated with a story.

        Args:
            story_id: Story ID

        Returns:
            Dictionary with 'created' and 'tested' file lists
        """
        mapping = self.load_story_files()
        return mapping.get("story_to_files", {}).get(
            story_id, {"created": [], "tested": []}
        )

    def detect_explicit_marker(self, text: str, story_id: str) -> Optional[CompletionSignal]:
        """Detect explicit completion markers in text.

        Args:
            text: Text to analyze
            story_id: Story ID to look for

        Returns:
            CompletionSignal if found, None otherwise
        """
        # Patterns like "mark S-001 done", "S-001 complete", etc.
        patterns = [
            rf"mark\s+{re.escape(story_id)}\s+(?:as\s+)?done",
            rf"{re.escape(story_id)}\s+(?:is\s+)?(?:done|complete|finished)",
            rf"(?:close|finish|complete)\s+{re.escape(story_id)}",
            rf"marcar\s+{re.escape(story_id)}\s+(?:como\s+)?(?:pronto|concluido)",
        ]

        text_lower = text.lower()
        for pattern in patterns:
            if re.search(pattern, text_lower):
                return CompletionSignal(
                    signal_type="explicit",
                    confidence=1.0,
                    reason=f"Explicit marker found: '{pattern}'",
                    detected_at=datetime.now().isoformat(),
                )

        return None

    def check_acceptance_criteria(self, story_id: str) -> Tuple[float, List[str]]:
        """Check acceptance criteria completion.

        Args:
            story_id: Story ID

        Returns:
            Tuple of (completion_ratio, list of incomplete criteria)
        """
        progress = self.load_progress()

        # Find story
        story = None
        for s in progress.get("stories", []):
            if s.get("id") == story_id:
                story = s
                break

        if not story:
            sprint = progress.get("current_sprint", {})
            for s in sprint.get("stories", []):
                if s.get("id") == story_id:
                    story = s
                    break

        if not story:
            return 0.0, []

        criteria = story.get("acceptance_criteria", [])
        if not criteria:
            return 0.5, []  # No criteria defined

        completed = [c for c in criteria if c.get("completed", False)]
        incomplete = [c.get("text", "") for c in criteria if not c.get("completed", False)]

        ratio = len(completed) / len(criteria) if criteria else 0.0
        return ratio, incomplete

    def check_test_coverage(self, story_id: str) -> Tuple[bool, List[str]]:
        """Check if tests exist for story files.

        Args:
            story_id: Story ID

        Returns:
            Tuple of (has_tests, list of files without tests)
        """
        files = self.get_files_for_story(story_id)
        created = files.get("created", [])
        tested = files.get("tested", [])

        if not created:
            return False, []

        # Simple heuristic: story has tests if test files exist
        has_tests = len(tested) > 0

        # Find source files that might need tests
        source_files = [
            f for f in created
            if not any(re.match(p, f) for p in self.TEST_PATTERNS)
        ]

        return has_tests, source_files if not has_tests else []

    def check_files_touched(self, story_id: str) -> Tuple[bool, List[str]]:
        """Check if all mapped files have been touched.

        Args:
            story_id: Story ID

        Returns:
            Tuple of (all_touched, list of untouched files)
        """
        progress = self.load_progress()
        story = None

        # Find story with file_mapping
        for s in progress.get("stories", []):
            if s.get("id") == story_id:
                story = s
                break

        if not story:
            sprint = progress.get("current_sprint", {})
            for s in sprint.get("stories", []):
                if s.get("id") == story_id:
                    story = s
                    break

        if not story:
            return False, []

        # Get expected files from story
        file_mapping = story.get("file_mapping", {})
        expected_files = set(
            file_mapping.get("primary_files", []) +
            file_mapping.get("test_files", [])
        )

        if not expected_files:
            return True, []  # No files expected

        # Get actually touched files
        files = self.get_files_for_story(story_id)
        touched = set(files.get("created", []) + files.get("tested", []))

        untouched = list(expected_files - touched)
        all_touched = len(untouched) == 0

        return all_touched, untouched

    def detect_keywords(self, text: str, story_id: str) -> float:
        """Detect completion keywords in text.

        Args:
            text: Text to analyze
            story_id: Story ID

        Returns:
            Confidence score based on keywords
        """
        text_lower = text.lower()

        # Check if story ID is mentioned
        if story_id.lower() not in text_lower:
            return 0.0

        # Count matching keywords
        all_keywords = []
        for lang_keywords in self.COMPLETION_KEYWORDS.values():
            all_keywords.extend(lang_keywords)

        matches = sum(1 for kw in all_keywords if kw in text_lower)

        if matches == 0:
            return 0.0
        elif matches == 1:
            return 0.4
        elif matches == 2:
            return 0.5
        else:
            return 0.6

    def get_completion_signals(self, story_id: str) -> List[CompletionSignal]:
        """Get all completion signals for a story.

        Args:
            story_id: Story ID

        Returns:
            List of CompletionSignal objects
        """
        signals = []
        now = datetime.now().isoformat()

        # Check acceptance criteria
        ac_ratio, incomplete = self.check_acceptance_criteria(story_id)
        if ac_ratio > 0:
            signals.append(CompletionSignal(
                signal_type="criteria",
                confidence=ac_ratio,
                reason=f"Acceptance criteria: {ac_ratio*100:.0f}% complete",
                detected_at=now,
            ))

        # Check tests
        has_tests, _ = self.check_test_coverage(story_id)
        if has_tests:
            signals.append(CompletionSignal(
                signal_type="tests",
                confidence=0.8,
                reason="Test files exist for this story",
                detected_at=now,
            ))

        # Check files touched
        all_touched, untouched = self.check_files_touched(story_id)
        if all_touched:
            signals.append(CompletionSignal(
                signal_type="files",
                confidence=0.7,
                reason="All expected files have been touched",
                detected_at=now,
            ))
        elif untouched:
            signals.append(CompletionSignal(
                signal_type="files",
                confidence=0.3,
                reason=f"Files not touched: {', '.join(untouched[:3])}",
                detected_at=now,
            ))

        return signals

    def should_auto_complete(
        self,
        story_id: str,
        threshold: float = DEFAULT_THRESHOLD,
    ) -> Tuple[bool, float, str]:
        """Determine if story should be auto-completed.

        Args:
            story_id: Story ID
            threshold: Confidence threshold (default 0.8)

        Returns:
            Tuple of (should_complete, confidence, reason)
        """
        signals = self.get_completion_signals(story_id)

        if not signals:
            return False, 0.0, "No completion signals detected"

        # Calculate weighted confidence
        weights = {
            "explicit": 1.0,
            "criteria": 0.9,
            "tests": 0.3,
            "files": 0.2,
            "keywords": 0.1,
        }

        total_weight = sum(weights.get(s.signal_type, 0.5) for s in signals)
        weighted_confidence = sum(
            s.confidence * weights.get(s.signal_type, 0.5)
            for s in signals
        ) / total_weight if total_weight > 0 else 0.0

        # Time boost: check if worked 80%+ of estimate
        progress = self.load_progress()
        story = None

        for s in progress.get("stories", []):
            if s.get("id") == story_id:
                story = s
                break

        if not story:
            sprint = progress.get("current_sprint", {})
            for s in sprint.get("stories", []):
                if s.get("id") == story_id:
                    story = s
                    break

        if story:
            time_tracking = story.get("time_tracking", {})
            estimated_hours = time_tracking.get("estimated_hours", 0)
            actual_minutes = time_tracking.get("actual_minutes", 0)

            if estimated_hours > 0:
                actual_hours = actual_minutes / 60
                ratio = actual_hours / estimated_hours

                if ratio >= 0.8:
                    weighted_confidence = min(1.0, weighted_confidence + 0.1)

        # Determine result
        should_complete = weighted_confidence >= threshold

        # Build reason
        if should_complete:
            reasons = [s.reason for s in signals if s.confidence >= 0.5]
            reason = "; ".join(reasons[:3])
        else:
            reason = f"Confidence {weighted_confidence:.0%} below threshold {threshold:.0%}"

        return should_complete, weighted_confidence, reason

    def update_completion_signals(self, story_id: str) -> None:
        """Update completion signals in progress.json.

        Args:
            story_id: Story ID
        """
        progress = self.load_progress()
        signals = self.get_completion_signals(story_id)

        # Calculate summary
        ac_ratio, _ = self.check_acceptance_criteria(story_id)
        all_touched, _ = self.check_files_touched(story_id)
        _, confidence, _ = self.should_auto_complete(story_id)

        completion_signals = {
            "all_files_touched": all_touched,
            "criteria_met": ac_ratio,
            "confidence_score": confidence,
            "signals": [
                {
                    "type": s.signal_type,
                    "confidence": s.confidence,
                    "reason": s.reason,
                }
                for s in signals
            ],
        }

        # Update story
        for story in progress.get("stories", []):
            if story.get("id") == story_id:
                story["completion_signals"] = completion_signals
                break

        sprint = progress.get("current_sprint", {})
        for story in sprint.get("stories", []):
            if story.get("id") == story_id:
                story["completion_signals"] = completion_signals
                break

        self.save_progress(progress)


# Module-level convenience functions
def should_auto_complete(
    codrsync_dir: Path,
    story_id: str,
    threshold: float = StoryMatcher.DEFAULT_THRESHOLD,
) -> Tuple[bool, float, str]:
    """Check if story should be auto-completed.

    Args:
        codrsync_dir: Path to .codrsync directory
        story_id: Story ID
        threshold: Confidence threshold

    Returns:
        Tuple of (should_complete, confidence, reason)
    """
    matcher = StoryMatcher(codrsync_dir)
    return matcher.should_auto_complete(story_id, threshold)


def map_file_to_story(codrsync_dir: Path, file_path: str, story_id: str) -> None:
    """Map a file to a story.

    Args:
        codrsync_dir: Path to .codrsync directory
        file_path: Relative file path
        story_id: Story ID
    """
    matcher = StoryMatcher(codrsync_dir)
    matcher.map_file_to_story(file_path, story_id)


def get_completion_signals(
    codrsync_dir: Path,
    story_id: str,
) -> List[CompletionSignal]:
    """Get completion signals for a story.

    Args:
        codrsync_dir: Path to .codrsync directory
        story_id: Story ID

    Returns:
        List of CompletionSignal objects
    """
    matcher = StoryMatcher(codrsync_dir)
    return matcher.get_completion_signals(story_id)
