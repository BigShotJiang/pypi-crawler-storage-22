"""
Metrics Engine - Calculate velocity, burndown, and points/hour

Provides sprint metrics for tracking team performance and
enabling better estimation through historical data.
"""

import json
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple


@dataclass
class SprintMetrics:
    """Metrics for a sprint."""

    velocity: int
    burndown_ideal: List[int]
    burndown_actual: List[int]
    points_per_hour: float
    completion_rate: float
    total_hours: float


class MetricsEngine:
    """Calculate and manage sprint metrics."""

    def __init__(self, codrsync_dir: Path):
        """Initialize metrics engine.

        Args:
            codrsync_dir: Path to .codrsync directory
        """
        self.codrsync_dir = codrsync_dir
        self.progress_path = codrsync_dir / "progress.json"

    def load_progress(self) -> Dict[str, Any]:
        """Load progress.json data."""
        if not self.progress_path.exists():
            return {}

        try:
            return json.loads(self.progress_path.read_text())
        except (json.JSONDecodeError, IOError):
            return {}

    def save_progress(self, progress: Dict[str, Any]) -> bool:
        """Save progress.json data."""
        try:
            self.progress_path.write_text(json.dumps(progress, indent=2))
            return True
        except IOError:
            return False

    def calculate_velocity(self, sprint: Optional[Dict[str, Any]] = None) -> int:
        """Calculate velocity for a sprint.

        Args:
            sprint: Sprint data (uses current sprint if None)

        Returns:
            Velocity in story points
        """
        if sprint is None:
            progress = self.load_progress()
            sprint = progress.get("current_sprint", {})

        stories = sprint.get("stories", [])
        done_points = sum(
            s.get("points", 0)
            for s in stories
            if s.get("status") == "done"
        )

        return done_points

    def calculate_burndown(
        self,
        sprint: Optional[Dict[str, Any]] = None,
    ) -> Tuple[List[int], List[int]]:
        """Calculate burndown data for a sprint.

        Args:
            sprint: Sprint data (uses current sprint if None)

        Returns:
            Tuple of (ideal_burndown, actual_burndown)
        """
        progress = self.load_progress()

        if sprint is None:
            sprint = progress.get("current_sprint", {})

        if not sprint:
            return [], []

        # Get sprint dates
        start_str = sprint.get("start")
        end_str = sprint.get("end")

        if not start_str or not end_str:
            return [], []

        start_date = datetime.strptime(start_str, "%Y-%m-%d")
        end_date = datetime.strptime(end_str, "%Y-%m-%d")
        today = datetime.now()

        # Calculate total days
        total_days = (end_date - start_date).days
        if total_days <= 0:
            return [], []

        # Calculate total points
        stories = sprint.get("stories", [])
        total_points = sum(s.get("points", 0) for s in stories)

        # Ideal burndown (linear)
        ideal = []
        for day in range(total_days + 1):
            remaining = total_points - (total_points * day / total_days)
            ideal.append(int(remaining))

        # Actual burndown
        actual = []
        elapsed_days = min((today - start_date).days, total_days)

        # Calculate remaining points for each day based on completed stories
        completed_points_by_date: Dict[str, int] = {}

        for story in stories:
            if story.get("status") == "done":
                completed_at = story.get("completed_at")
                if completed_at:
                    try:
                        completed_date = datetime.fromisoformat(completed_at).strftime("%Y-%m-%d")
                        completed_points_by_date[completed_date] = (
                            completed_points_by_date.get(completed_date, 0) +
                            story.get("points", 0)
                        )
                    except ValueError:
                        pass

        # Build actual burndown
        cumulative_completed = 0
        for day in range(elapsed_days + 1):
            current_date = (start_date + timedelta(days=day)).strftime("%Y-%m-%d")
            cumulative_completed += completed_points_by_date.get(current_date, 0)
            remaining = total_points - cumulative_completed
            actual.append(remaining)

        return ideal, actual

    def calculate_points_per_hour(
        self,
        sprint: Optional[Dict[str, Any]] = None,
    ) -> float:
        """Calculate points per hour for a sprint.

        Args:
            sprint: Sprint data (uses current sprint if None)

        Returns:
            Points per hour
        """
        progress = self.load_progress()

        if sprint is None:
            sprint = progress.get("current_sprint", {})

        stories = sprint.get("stories", [])

        total_points = 0
        total_minutes = 0

        for story in stories:
            if story.get("status") == "done":
                total_points += story.get("points", 0)

                time_tracking = story.get("time_tracking", {})
                actual_minutes = time_tracking.get("actual_minutes", 0)
                total_minutes += actual_minutes

        if total_minutes == 0:
            return 0.0

        total_hours = total_minutes / 60
        return total_points / total_hours

    def get_velocity_history(self) -> List[int]:
        """Get historical velocity data.

        Returns:
            List of velocities from past sprints
        """
        progress = self.load_progress()
        metrics = progress.get("metrics", {})
        return metrics.get("velocity_history", [])

    def get_average_velocity(self) -> float:
        """Get average velocity across sprints.

        Returns:
            Average velocity
        """
        history = self.get_velocity_history()
        if not history:
            return 0.0
        return sum(history) / len(history)

    def update_sprint_metrics(self) -> None:
        """Update metrics in progress.json for current sprint."""
        progress = self.load_progress()
        sprint = progress.get("current_sprint", {})

        if not sprint:
            return

        # Calculate current metrics
        velocity = self.calculate_velocity(sprint)
        ideal, actual = self.calculate_burndown(sprint)
        points_per_hour = self.calculate_points_per_hour(sprint)

        # Update metrics section
        metrics = progress.setdefault("metrics", {})

        metrics["burndown"] = {
            "ideal": ideal,
            "actual": actual,
        }

        metrics["time_tracking"] = {
            "points_per_hour": round(points_per_hour, 2),
        }

        # Current sprint velocity (not historical)
        metrics["current_velocity"] = velocity

        self.save_progress(progress)

    def record_sprint_completion(self) -> Dict[str, Any]:
        """Record metrics when sprint is closed.

        Returns:
            Final sprint metrics
        """
        progress = self.load_progress()
        sprint = progress.get("current_sprint", {})

        if not sprint:
            return {}

        # Calculate final metrics
        velocity = self.calculate_velocity(sprint)
        points_per_hour = self.calculate_points_per_hour(sprint)

        stories = sprint.get("stories", [])
        total_stories = len(stories)
        done_stories = sum(1 for s in stories if s.get("status") == "done")
        completion_rate = done_stories / total_stories if total_stories else 0.0

        total_minutes = sum(
            s.get("time_tracking", {}).get("actual_minutes", 0)
            for s in stories if s.get("status") == "done"
        )
        total_hours = total_minutes / 60

        # Update historical metrics
        metrics = progress.setdefault("metrics", {})

        velocity_history = metrics.get("velocity_history", [])
        velocity_history.append(velocity)
        metrics["velocity_history"] = velocity_history
        metrics["average_velocity"] = sum(velocity_history) / len(velocity_history)

        self.save_progress(progress)

        return {
            "velocity": velocity,
            "points_per_hour": round(points_per_hour, 2),
            "completion_rate": round(completion_rate, 2),
            "total_hours": round(total_hours, 1),
            "stories_completed": done_stories,
            "stories_total": total_stories,
        }

    def get_time_summary(self) -> Dict[str, Any]:
        """Get time tracking summary for all stories.

        Returns:
            Time summary data
        """
        progress = self.load_progress()
        sprint = progress.get("current_sprint", {})
        stories = sprint.get("stories", [])

        summary = {
            "stories": [],
            "total_minutes": 0,
            "total_sessions": 0,
        }

        for story in stories:
            time_tracking = story.get("time_tracking", {})
            minutes = time_tracking.get("actual_minutes", 0)
            sessions = len(time_tracking.get("sessions", []))

            summary["stories"].append({
                "id": story.get("id"),
                "title": story.get("title"),
                "status": story.get("status"),
                "points": story.get("points", 0),
                "minutes": minutes,
                "sessions": sessions,
            })

            summary["total_minutes"] += minutes
            summary["total_sessions"] += sessions

        summary["total_hours"] = round(summary["total_minutes"] / 60, 1)

        return summary

    def get_check_summary(self) -> List[Dict[str, Any]]:
        """Get completion readiness for all stories.

        Returns:
            List of stories with completion status
        """
        progress = self.load_progress()
        sprint = progress.get("current_sprint", {})
        stories = sprint.get("stories", [])

        from codrsync.sprint_engine.matcher import StoryMatcher
        matcher = StoryMatcher(self.codrsync_dir)

        result = []
        for story in stories:
            story_id = story.get("id")
            if not story_id:
                continue

            should_complete, confidence, reason = matcher.should_auto_complete(story_id)

            result.append({
                "id": story_id,
                "title": story.get("title"),
                "status": story.get("status"),
                "points": story.get("points", 0),
                "ready": should_complete,
                "confidence": round(confidence * 100),
                "reason": reason,
            })

        return result


# Module-level convenience functions
def calculate_velocity(codrsync_dir: Path) -> int:
    """Calculate velocity for current sprint.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Velocity in story points
    """
    engine = MetricsEngine(codrsync_dir)
    return engine.calculate_velocity()


def calculate_burndown(codrsync_dir: Path) -> Tuple[List[int], List[int]]:
    """Calculate burndown for current sprint.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Tuple of (ideal, actual) burndown lists
    """
    engine = MetricsEngine(codrsync_dir)
    return engine.calculate_burndown()


def calculate_points_per_hour(codrsync_dir: Path) -> float:
    """Calculate points per hour for current sprint.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Points per hour
    """
    engine = MetricsEngine(codrsync_dir)
    return engine.calculate_points_per_hour()
