"""
Documentation Sync - Automatic documentation updates

Keeps documentation synchronized with sprint progress,
updating story status and metrics automatically.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List


class DocumentationSync:
    """Synchronizes documentation with sprint progress."""

    def __init__(self, codrsync_dir: Path):
        """Initialize documentation sync.

        Args:
            codrsync_dir: Path to .codrsync directory
        """
        self.codrsync_dir = codrsync_dir
        self.progress_path = codrsync_dir / "progress.json"
        self.manifest_path = codrsync_dir / "manifest.json"
        self.context_path = codrsync_dir / "context.md"

    def load_progress(self) -> Dict[str, Any]:
        """Load progress.json data."""
        if not self.progress_path.exists():
            return {}

        try:
            return json.loads(self.progress_path.read_text())
        except (json.JSONDecodeError, IOError):
            return {}

    def save_progress(self, progress: Dict[str, Any]) -> bool:
        """Save progress.json data."""
        try:
            self.progress_path.write_text(json.dumps(progress, indent=2))
            return True
        except IOError:
            return False

    def load_manifest(self) -> Dict[str, Any]:
        """Load manifest.json data."""
        if not self.manifest_path.exists():
            return {}

        try:
            return json.loads(self.manifest_path.read_text())
        except (json.JSONDecodeError, IOError):
            return {}

    def save_manifest(self, manifest: Dict[str, Any]) -> bool:
        """Save manifest.json data."""
        try:
            self.manifest_path.write_text(json.dumps(manifest, indent=2))
            return True
        except IOError:
            return False

    def update_story_status(
        self,
        story_id: str,
        new_status: str,
        completed_at: Optional[str] = None,
    ) -> bool:
        """Update story status in both progress and manifest.

        Args:
            story_id: Story ID
            new_status: New status (done, in_progress, pending, etc.)
            completed_at: Optional completion timestamp

        Returns:
            True if updated successfully
        """
        progress = self.load_progress()
        manifest = self.load_manifest()

        updated = False

        # Update in progress.json stories
        for story in progress.get("stories", []):
            if story.get("id") == story_id:
                story["status"] = new_status
                if new_status == "done" and completed_at:
                    story["completed_at"] = completed_at
                updated = True
                break

        # Update in current_sprint stories (progress.json)
        sprint = progress.get("current_sprint", {})
        for story in sprint.get("stories", []):
            if story.get("id") == story_id:
                story["status"] = new_status
                if new_status == "done" and completed_at:
                    story["completed_at"] = completed_at
                updated = True
                break

        # Update in manifest.json current_sprint
        manifest_sprint = manifest.get("current_sprint", {})
        for story in manifest_sprint.get("stories", []):
            if story.get("id") == story_id:
                story["status"] = new_status
                if new_status == "done" and completed_at:
                    story["completed_at"] = completed_at
                updated = True
                break

        if updated:
            self.save_progress(progress)
            self.save_manifest(manifest)

        return updated

    def sync_sprint_between_files(self) -> None:
        """Synchronize sprint data between progress.json and manifest.json."""
        progress = self.load_progress()
        manifest = self.load_manifest()

        # Use progress.json as source of truth for current_sprint
        progress_sprint = progress.get("current_sprint", {})
        manifest_sprint = manifest.get("current_sprint", {})

        if not progress_sprint and not manifest_sprint:
            return

        # Merge: prefer progress.json for stories, manifest for metadata
        if progress_sprint:
            merged_sprint = {
                **manifest_sprint,
                **progress_sprint,
            }

            # Keep stories from progress (more up-to-date)
            merged_sprint["stories"] = progress_sprint.get(
                "stories",
                manifest_sprint.get("stories", [])
            )

            progress["current_sprint"] = merged_sprint
            manifest["current_sprint"] = merged_sprint

            self.save_progress(progress)
            self.save_manifest(manifest)

    def update_context_md(self) -> bool:
        """Update context.md with current sprint information.

        Returns:
            True if updated successfully
        """
        progress = self.load_progress()
        sprint = progress.get("current_sprint", {})

        if not sprint:
            return False

        # Build context content
        stories = sprint.get("stories", [])
        done = [s for s in stories if s.get("status") == "done"]
        in_progress = [s for s in stories if s.get("status") == "in_progress"]
        pending = [s for s in stories if s.get("status") in ["pending", "todo"]]

        total_points = sum(s.get("points", 0) for s in stories)
        done_points = sum(s.get("points", 0) for s in done)

        context = f"""# Sprint {sprint.get('number', '?')} Context

**Goal:** {sprint.get('goal', 'Not defined')}
**Period:** {sprint.get('start')} - {sprint.get('end')}
**Progress:** {done_points}/{total_points} points ({len(done)}/{len(stories)} stories)

## Current Focus

"""
        # Add in-progress stories
        if in_progress:
            context += "### In Progress\n"
            for s in in_progress:
                context += f"- **{s['id']}**: {s.get('title', 'Untitled')} ({s.get('points', 0)} pts)\n"
            context += "\n"

        # Add pending stories
        if pending:
            context += "### Up Next\n"
            for s in pending[:3]:  # Only show top 3
                context += f"- {s['id']}: {s.get('title', 'Untitled')} ({s.get('points', 0)} pts)\n"
            if len(pending) > 3:
                context += f"- ... and {len(pending) - 3} more\n"
            context += "\n"

        # Add completed stories
        if done:
            context += "### Completed\n"
            for s in done[-5:]:  # Only show last 5
                context += f"- ~~{s['id']}: {s.get('title', 'Untitled')}~~ ({s.get('points', 0)} pts)\n"
            context += "\n"

        # Add metrics
        metrics = progress.get("metrics", {})
        if metrics:
            context += "## Metrics\n\n"
            context += f"- **Velocity:** {metrics.get('current_velocity', 0)} points (current)\n"
            context += f"- **Average Velocity:** {metrics.get('average_velocity', 0):.1f} points\n"

            time_tracking = metrics.get("time_tracking", {})
            if time_tracking.get("points_per_hour"):
                context += f"- **Points/Hour:** {time_tracking['points_per_hour']:.1f}\n"

        context += f"\n---\n*Updated: {datetime.now().isoformat()}*\n"

        try:
            self.context_path.write_text(context)
            return True
        except IOError:
            return False

    def sync_progress_docs(self) -> Dict[str, bool]:
        """Perform full documentation synchronization.

        Returns:
            Dictionary with sync status for each operation
        """
        results = {
            "sprint_sync": False,
            "context_update": False,
        }

        try:
            self.sync_sprint_between_files()
            results["sprint_sync"] = True
        except Exception:
            pass

        try:
            results["context_update"] = self.update_context_md()
        except Exception:
            pass

        return results

    def auto_close_stories(self) -> List[str]:
        """Auto-close stories that meet completion criteria.

        Returns:
            List of story IDs that were closed
        """
        from codrsync.sprint_engine.matcher import StoryMatcher

        progress = self.load_progress()
        sprint = progress.get("current_sprint", {})
        stories = sprint.get("stories", [])

        matcher = StoryMatcher(self.codrsync_dir)
        closed_stories = []

        for story in stories:
            story_id = story.get("id")
            status = story.get("status")

            # Only check in_progress stories
            if status != "in_progress":
                continue

            should_complete, confidence, reason = matcher.should_auto_complete(story_id)

            if should_complete:
                completed_at = datetime.now().isoformat()
                self.update_story_status(story_id, "done", completed_at)
                closed_stories.append(story_id)

        return closed_stories

    def record_activity_for_story(self, story_id: str, file_path: str) -> None:
        """Record file activity for a story.

        Args:
            story_id: Story ID
            file_path: File that was edited
        """
        from codrsync.sprint_engine.matcher import StoryMatcher

        matcher = StoryMatcher(self.codrsync_dir)
        matcher.map_file_to_story(file_path, story_id)
        matcher.update_completion_signals(story_id)


# Module-level convenience functions
def sync_progress_docs(codrsync_dir: Path) -> Dict[str, bool]:
    """Perform full documentation synchronization.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Dictionary with sync status
    """
    sync = DocumentationSync(codrsync_dir)
    return sync.sync_progress_docs()


def update_story_status(
    codrsync_dir: Path,
    story_id: str,
    new_status: str,
    completed_at: Optional[str] = None,
) -> bool:
    """Update story status.

    Args:
        codrsync_dir: Path to .codrsync directory
        story_id: Story ID
        new_status: New status
        completed_at: Optional completion timestamp

    Returns:
        True if updated successfully
    """
    sync = DocumentationSync(codrsync_dir)
    return sync.update_story_status(story_id, new_status, completed_at)
