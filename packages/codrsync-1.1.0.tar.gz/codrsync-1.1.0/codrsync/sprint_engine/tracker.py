"""
Time Tracker - Session and story time tracking

Tracks time spent per session and per story, enabling
accurate velocity calculations and estimation calibration.
"""

import json
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List


@dataclass
class Session:
    """Represents a development session."""

    id: str
    started_at: str
    active_story: Optional[str] = None
    edits_count: int = 0
    ended_at: Optional[str] = None
    duration_minutes: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert session to dictionary."""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class StoryTimeEntry:
    """Time entry for a story."""

    session_id: str
    started_at: str
    minutes: int
    ended_at: Optional[str] = None


class TimeTracker:
    """Manages time tracking for sessions and stories."""

    def __init__(self, codrsync_dir: Path):
        """Initialize time tracker.

        Args:
            codrsync_dir: Path to .codrsync directory
        """
        self.codrsync_dir = codrsync_dir
        self.progress_path = codrsync_dir / "progress.json"
        self._current_session: Optional[Session] = None

    def load_progress(self) -> Dict[str, Any]:
        """Load progress.json data."""
        if not self.progress_path.exists():
            return {}

        try:
            return json.loads(self.progress_path.read_text())
        except (json.JSONDecodeError, IOError):
            return {}

    def save_progress(self, progress: Dict[str, Any]) -> bool:
        """Save progress.json data."""
        try:
            self.progress_path.write_text(json.dumps(progress, indent=2))
            return True
        except IOError:
            return False

    def start_session(self, story_id: Optional[str] = None) -> Session:
        """Start a new session.

        Args:
            story_id: Optional story ID to associate with session

        Returns:
            New Session object
        """
        session = Session(
            id=f"sess-{uuid.uuid4().hex[:8]}",
            started_at=datetime.now().isoformat(),
            active_story=story_id,
            edits_count=0,
        )

        progress = self.load_progress()
        progress["current_session"] = session.to_dict()
        self.save_progress(progress)

        self._current_session = session
        return session

    def end_session(self) -> Optional[Session]:
        """End the current session.

        Returns:
            Ended Session object or None if no active session
        """
        progress = self.load_progress()
        session_data = progress.get("current_session")

        if not session_data:
            return None

        # Calculate duration
        started_at = datetime.fromisoformat(session_data["started_at"])
        ended_at = datetime.now()
        duration_minutes = int((ended_at - started_at).total_seconds() / 60)

        session_data["ended_at"] = ended_at.isoformat()
        session_data["duration_minutes"] = duration_minutes

        # Record time for active story
        active_story = session_data.get("active_story")
        if active_story:
            self._record_story_time(progress, active_story, session_data["id"], duration_minutes)

        # Clear current session
        progress["current_session"] = None
        self.save_progress(progress)

        return Session(**session_data)

    def _record_story_time(
        self,
        progress: Dict[str, Any],
        story_id: str,
        session_id: str,
        minutes: int,
    ) -> None:
        """Record time spent on a story.

        Args:
            progress: Progress data dictionary
            story_id: Story ID
            session_id: Session ID
            minutes: Minutes spent
        """
        # Find story in progress
        stories = progress.get("stories", [])
        for story in stories:
            if story.get("id") == story_id:
                # Initialize time_tracking if needed
                if "time_tracking" not in story:
                    story["time_tracking"] = {
                        "estimated_hours": story.get("estimated_hours", 0),
                        "actual_minutes": 0,
                        "sessions": [],
                    }

                # Add session time
                story["time_tracking"]["actual_minutes"] += minutes
                story["time_tracking"]["sessions"].append({
                    "session_id": session_id,
                    "minutes": minutes,
                })
                break

        # Also check current sprint stories
        sprint = progress.get("current_sprint", {})
        sprint_stories = sprint.get("stories", [])
        for story in sprint_stories:
            if story.get("id") == story_id:
                if "time_tracking" not in story:
                    story["time_tracking"] = {
                        "estimated_hours": story.get("estimated_hours", 0),
                        "actual_minutes": 0,
                        "sessions": [],
                    }

                story["time_tracking"]["actual_minutes"] += minutes
                story["time_tracking"]["sessions"].append({
                    "session_id": session_id,
                    "minutes": minutes,
                })
                break

    def get_active_session(self) -> Optional[Session]:
        """Get the current active session.

        Returns:
            Active Session or None
        """
        progress = self.load_progress()
        session_data = progress.get("current_session")

        if not session_data:
            return None

        return Session(**session_data)

    def switch_story(self, new_story_id: str) -> Optional[str]:
        """Switch to a different story during session.

        Args:
            new_story_id: New story ID to work on

        Returns:
            Previous story ID or None
        """
        progress = self.load_progress()
        session_data = progress.get("current_session")

        if not session_data:
            return None

        previous_story = session_data.get("active_story")

        # Record time for previous story if any
        if previous_story and previous_story != new_story_id:
            started_at = datetime.fromisoformat(session_data["started_at"])
            minutes = int((datetime.now() - started_at).total_seconds() / 60)

            self._record_story_time(
                progress, previous_story, session_data["id"], minutes
            )

            # Reset start time for new story segment
            session_data["started_at"] = datetime.now().isoformat()

        session_data["active_story"] = new_story_id
        progress["current_session"] = session_data
        self.save_progress(progress)

        return previous_story

    def increment_edits(self) -> int:
        """Increment edit count for current session.

        Returns:
            New edit count
        """
        progress = self.load_progress()
        session_data = progress.get("current_session")

        if not session_data:
            return 0

        session_data["edits_count"] = session_data.get("edits_count", 0) + 1
        progress["current_session"] = session_data
        self.save_progress(progress)

        return session_data["edits_count"]

    def get_story_time(self, story_id: str) -> Dict[str, Any]:
        """Get time tracking info for a story.

        Args:
            story_id: Story ID

        Returns:
            Time tracking data
        """
        progress = self.load_progress()

        # Check stories list
        for story in progress.get("stories", []):
            if story.get("id") == story_id:
                return story.get("time_tracking", {})

        # Check sprint stories
        sprint = progress.get("current_sprint", {})
        for story in sprint.get("stories", []):
            if story.get("id") == story_id:
                return story.get("time_tracking", {})

        return {}

    def get_all_story_times(self) -> Dict[str, Dict[str, Any]]:
        """Get time tracking for all stories.

        Returns:
            Dictionary of story_id -> time_tracking
        """
        progress = self.load_progress()
        result = {}

        # From stories list
        for story in progress.get("stories", []):
            story_id = story.get("id")
            if story_id:
                result[story_id] = story.get("time_tracking", {})

        # From sprint stories
        sprint = progress.get("current_sprint", {})
        for story in sprint.get("stories", []):
            story_id = story.get("id")
            if story_id:
                result[story_id] = story.get("time_tracking", {})

        return result


# Module-level convenience functions
def start_session(codrsync_dir: Path, story_id: Optional[str] = None) -> Session:
    """Start a new session.

    Args:
        codrsync_dir: Path to .codrsync directory
        story_id: Optional story ID

    Returns:
        New Session
    """
    tracker = TimeTracker(codrsync_dir)
    return tracker.start_session(story_id)


def end_session(codrsync_dir: Path) -> Optional[Session]:
    """End the current session.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Ended Session or None
    """
    tracker = TimeTracker(codrsync_dir)
    return tracker.end_session()


def get_active_session(codrsync_dir: Path) -> Optional[Session]:
    """Get the active session.

    Args:
        codrsync_dir: Path to .codrsync directory

    Returns:
        Active Session or None
    """
    tracker = TimeTracker(codrsync_dir)
    return tracker.get_active_session()


def get_story_time(codrsync_dir: Path, story_id: str) -> Dict[str, Any]:
    """Get time tracking for a story.

    Args:
        codrsync_dir: Path to .codrsync directory
        story_id: Story ID

    Returns:
        Time tracking data
    """
    tracker = TimeTracker(codrsync_dir)
    return tracker.get_story_time(story_id)
