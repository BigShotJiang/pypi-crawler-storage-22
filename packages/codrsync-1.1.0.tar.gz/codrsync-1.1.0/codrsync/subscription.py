"""
codrsync subscription verification

Verifies active plan via API, checks feature access by tier,
displays subscription status, and handles upgrade prompts.

Usage:
    from codrsync.subscription import (
        get_subscription,
        has_feature,
        check_credits,
        show_upgrade_prompt,
    )
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional
import webbrowser

import requests
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from codrsync.cloud_auth import get_cloud_credentials, CODRSYNC_API_URL
from codrsync.i18n import t


console = Console()


class PlanTier(str, Enum):
    """Available plan tiers."""
    FREE = "free"
    PRO = "pro"
    PRO_PLUS = "pro_plus"
    TEAM = "team"
    ENTERPRISE = "enterprise"


class Feature(str, Enum):
    """Available features that can be checked."""
    CLOUD_WORKSPACE = "cloud_workspace"
    BYOK_SUPPORT = "byok_support"
    CODRSYNC = "codrsync"
    DOCRSYNC = "docrsync"
    PPTRSYNC = "pptrsync"
    PPTRSYNC_PREMIUM = "pptrsync_premium"
    ENVRSYNC = "envrsync"
    PRIORITY_SUPPORT = "priority_support"
    SSO = "sso"
    ADMIN_DASHBOARD = "admin_dashboard"
    SLA = "sla"
    ONGOING_DOCS = "ongoing_docs"


@dataclass
class PlanLimits:
    """Plan limits."""
    storage: int
    credits_per_month: int
    credits_rollover: int
    team_members: int
    api_keys: int


@dataclass
class Credits:
    """User credits status."""
    balance: int
    used_this_month: int
    last_refresh: Optional[str]
    next_refresh: Optional[str]


@dataclass
class Subscription:
    """User subscription details."""
    tier: PlanTier
    plan_name: str
    status: str
    limits: PlanLimits
    features: dict[str, bool]
    credits: Credits
    stripe_subscription_id: Optional[str]
    current_period_end: Optional[str]
    cancel_at_period_end: bool


# Feature requirements by tier
FEATURE_MIN_TIER: dict[Feature, PlanTier] = {
    Feature.CLOUD_WORKSPACE: PlanTier.PRO,
    Feature.BYOK_SUPPORT: PlanTier.FREE,
    Feature.CODRSYNC: PlanTier.FREE,
    Feature.DOCRSYNC: PlanTier.PRO,
    Feature.PPTRSYNC: PlanTier.PRO,
    Feature.PPTRSYNC_PREMIUM: PlanTier.PRO_PLUS,
    Feature.ENVRSYNC: PlanTier.FREE,
    Feature.PRIORITY_SUPPORT: PlanTier.PRO_PLUS,
    Feature.SSO: PlanTier.TEAM,
    Feature.ADMIN_DASHBOARD: PlanTier.TEAM,
    Feature.SLA: PlanTier.TEAM,
    Feature.ONGOING_DOCS: PlanTier.TEAM,
}

# Tier order for comparison
TIER_ORDER = [PlanTier.FREE, PlanTier.PRO, PlanTier.PRO_PLUS, PlanTier.TEAM, PlanTier.ENTERPRISE]


# Credit costs for operations
CREDIT_COSTS = {
    # codrsync (AI)
    "chat_short": 1,
    "chat_medium": 2,
    "chat_long": 5,
    # envrsync (Scan)
    "scan_basic": 0,
    "scan_deep": 5,
    # docrsync (Docs)
    "doc_readme": 5,
    "doc_technical": 15,
    "doc_full": 30,
    # pptrsync (Presentations)
    "ppt_quick": 10,
    "ppt_standard": 20,
    "ppt_full": 35,
    "ppt_images_premium": 10,
    "ppt_export": 5,
}


def get_subscription(api_url: Optional[str] = None) -> Optional[Subscription]:
    """Fetch current subscription status from API.

    Returns None if not authenticated or request fails.
    """
    credentials = get_cloud_credentials()
    if not credentials:
        return None

    base_url = api_url or CODRSYNC_API_URL
    token = credentials.get("access_token")

    try:
        resp = requests.get(
            f"{base_url}/api/billing/subscription",
            headers={"Authorization": f"Bearer {token}"},
            timeout=10,
        )

        if resp.status_code == 401:
            # Token expired or invalid
            return None

        resp.raise_for_status()
        data = resp.json()

        return Subscription(
            tier=PlanTier(data["tier"]),
            plan_name=data["plan_name"],
            status=data["status"],
            limits=PlanLimits(
                storage=data["limits"]["storage"],
                credits_per_month=data["limits"]["credits_per_month"],
                credits_rollover=data["limits"]["credits_rollover"],
                team_members=data["limits"]["team_members"],
                api_keys=data["limits"]["api_keys"],
            ),
            features=data["features"],
            credits=Credits(
                balance=data["credits"]["balance"],
                used_this_month=data["credits"]["used_this_month"],
                last_refresh=data["credits"].get("last_refresh"),
                next_refresh=data["credits"].get("next_refresh"),
            ),
            stripe_subscription_id=data.get("subscription", {}).get("stripe_subscription_id") if data.get("subscription") else None,
            current_period_end=data.get("subscription", {}).get("current_period_end") if data.get("subscription") else None,
            cancel_at_period_end=data.get("subscription", {}).get("cancel_at_period_end", False) if data.get("subscription") else False,
        )
    except requests.RequestException as e:
        console.print(f"[dim]{t('subscription.fetch_error', error=str(e))}[/dim]")
        return None
    except (KeyError, ValueError) as e:
        console.print(f"[dim]{t('subscription.parse_error', error=str(e))}[/dim]")
        return None


def get_cached_tier() -> PlanTier:
    """Get tier from cached credentials (without API call).

    Falls back to FREE if not authenticated.
    """
    credentials = get_cloud_credentials()
    if not credentials:
        return PlanTier.FREE

    tier_str = credentials.get("tier", "free")
    try:
        return PlanTier(tier_str)
    except ValueError:
        return PlanTier.FREE


def has_feature(feature: Feature, subscription: Optional[Subscription] = None) -> bool:
    """Check if user has access to a feature.

    Args:
        feature: The feature to check
        subscription: Optional subscription (fetched if not provided)

    Returns:
        True if feature is available
    """
    if subscription is None:
        # Check cached tier first (faster)
        tier = get_cached_tier()
    else:
        tier = subscription.tier

    # Check feature flags if we have full subscription data
    if subscription and feature.value in subscription.features:
        return subscription.features[feature.value]

    # Fall back to tier-based check
    min_tier = FEATURE_MIN_TIER.get(feature, PlanTier.FREE)
    return TIER_ORDER.index(tier) >= TIER_ORDER.index(min_tier)


def check_credits(operation: str, subscription: Optional[Subscription] = None) -> tuple[bool, int, int]:
    """Check if user has enough credits for an operation.

    Args:
        operation: The operation key (e.g., "chat_medium", "ppt_standard")
        subscription: Optional subscription (fetched if not provided)

    Returns:
        Tuple of (has_enough, cost, current_balance)
    """
    cost = CREDIT_COSTS.get(operation, 0)

    if cost == 0:
        return True, 0, 0

    if subscription is None:
        subscription = get_subscription()

    if subscription is None:
        # Not authenticated - can't use credits
        return False, cost, 0

    # Unlimited credits for enterprise
    if subscription.limits.credits_per_month == -1:
        return True, cost, -1

    balance = subscription.credits.balance
    return balance >= cost, cost, balance


def show_subscription_status(subscription: Optional[Subscription] = None) -> None:
    """Display current subscription status in a formatted panel."""
    if subscription is None:
        subscription = get_subscription()

    if subscription is None:
        console.print(Panel(
            t("subscription.not_authenticated"),
            title=t("subscription.status_title"),
            border_style="yellow",
        ))
        return

    # Build status table
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Label", style="dim")
    table.add_column("Value", style="bold")

    # Plan info
    tier_colors = {
        PlanTier.FREE: "white",
        PlanTier.PRO: "cyan",
        PlanTier.PRO_PLUS: "blue",
        PlanTier.TEAM: "magenta",
        PlanTier.ENTERPRISE: "gold1",
    }
    tier_color = tier_colors.get(subscription.tier, "white")

    table.add_row(t("subscription.plan"), f"[{tier_color}]{subscription.plan_name}[/]")
    table.add_row(t("subscription.status_label"), _format_status(subscription.status))

    # Credits
    if subscription.limits.credits_per_month == -1:
        credits_str = t("subscription.unlimited")
    else:
        credits_str = f"{subscription.credits.balance:,} / {subscription.limits.credits_per_month:,}"
    table.add_row(t("subscription.credits"), credits_str)

    # Storage
    storage_gb = subscription.limits.storage / (1024 * 1024 * 1024)
    table.add_row(t("subscription.storage"), f"{storage_gb:.0f} GB")

    # Period end
    if subscription.current_period_end:
        table.add_row(t("subscription.renews"), subscription.current_period_end[:10])

    if subscription.cancel_at_period_end:
        table.add_row("", f"[yellow]{t('subscription.cancels_at_end')}[/]")

    console.print(Panel(
        table,
        title=t("subscription.status_title"),
        border_style=tier_color,
    ))


def _format_status(status: str) -> str:
    """Format subscription status with color."""
    status_styles = {
        "active": "[green]Active[/]",
        "trialing": "[cyan]Trial[/]",
        "past_due": "[yellow]Past Due[/]",
        "canceled": "[red]Canceled[/]",
        "inactive": "[dim]Inactive[/]",
    }
    return status_styles.get(status, status)


def show_upgrade_prompt(
    feature: Optional[Feature] = None,
    required_tier: Optional[PlanTier] = None,
    reason: Optional[str] = None,
) -> bool:
    """Show upgrade prompt and optionally open checkout.

    Args:
        feature: The feature that requires upgrade
        required_tier: The minimum tier required
        reason: Custom reason message

    Returns:
        True if user chose to upgrade (opened browser)
    """
    # Determine required tier
    if required_tier is None and feature is not None:
        required_tier = FEATURE_MIN_TIER.get(feature, PlanTier.PRO)

    if required_tier is None:
        required_tier = PlanTier.PRO

    # Build upgrade message
    tier_names = {
        PlanTier.PRO: "Pro",
        PlanTier.PRO_PLUS: "Pro+",
        PlanTier.TEAM: "Teams",
        PlanTier.ENTERPRISE: "Enterprise",
    }
    tier_prices = {
        PlanTier.PRO: "R$47/mês",
        PlanTier.PRO_PLUS: "R$147/mês",
        PlanTier.TEAM: "R$397/seat/mês",
    }

    tier_name = tier_names.get(required_tier, "Pro")
    tier_price = tier_prices.get(required_tier, "")

    if reason:
        message = reason
    elif feature:
        message = t("subscription.feature_requires", feature=feature.value, tier=tier_name)
    else:
        message = t("subscription.upgrade_for_more")

    console.print(Panel(
        f"{message}\n\n"
        f"[bold]{tier_name}[/bold] - {tier_price}\n\n"
        f"{t('subscription.upgrade_question')}",
        title=t("subscription.upgrade_title"),
        border_style="cyan",
    ))

    # Ask user
    try:
        import questionary
        choice = questionary.confirm(
            t("subscription.open_checkout"),
            default=True,
        ).ask()

        if choice:
            checkout_url = f"{CODRSYNC_API_URL}/api/billing/checkout?tier={required_tier.value}"
            webbrowser.open(checkout_url)
            console.print(t("subscription.checkout_opened"))
            return True
    except (ImportError, KeyboardInterrupt):
        pass

    return False


def show_credits_prompt(operation: str, cost: int, balance: int) -> bool:
    """Show prompt when user doesn't have enough credits.

    Args:
        operation: The operation that requires credits
        cost: Credits required
        balance: Current balance

    Returns:
        True if user chose to buy credits (opened browser)
    """
    console.print(Panel(
        f"{t('subscription.insufficient_credits')}\n\n"
        f"{t('subscription.operation')}: {operation}\n"
        f"{t('subscription.cost')}: {cost} {t('subscription.credits_unit')}\n"
        f"{t('subscription.balance')}: {balance} {t('subscription.credits_unit')}\n\n"
        f"{t('subscription.buy_credits_question')}",
        title=t("subscription.credits_required"),
        border_style="yellow",
    ))

    try:
        import questionary
        choice = questionary.confirm(
            t("subscription.buy_credits"),
            default=True,
        ).ask()

        if choice:
            checkout_url = f"{CODRSYNC_API_URL}/api/billing/checkout?credits=100"
            webbrowser.open(checkout_url)
            console.print(t("subscription.checkout_opened"))
            return True
    except (ImportError, KeyboardInterrupt):
        pass

    return False


def require_feature(feature: Feature) -> bool:
    """Check feature and show upgrade prompt if needed.

    Convenience function that combines has_feature and show_upgrade_prompt.

    Args:
        feature: The feature to check

    Returns:
        True if feature is available or user chose to upgrade
    """
    subscription = get_subscription()

    if has_feature(feature, subscription):
        return True

    return show_upgrade_prompt(feature=feature)


def require_credits(operation: str) -> bool:
    """Check credits and show purchase prompt if needed.

    Convenience function that combines check_credits and show_credits_prompt.

    Args:
        operation: The operation key

    Returns:
        True if credits are sufficient or user chose to buy more
    """
    subscription = get_subscription()
    has_enough, cost, balance = check_credits(operation, subscription)

    if has_enough:
        return True

    return show_credits_prompt(operation, cost, balance)
