"""CLI login functionality for CoGames."""

from cogames.auth import BaseCLIAuthenticator

# Default CoGames server URL
DEFAULT_COGAMES_SERVER = "https://softmax.com/api"


class CoGamesAuthenticator(BaseCLIAuthenticator):
    """CLI Authenticator for CoGames, storing tokens in cogames.yaml under 'login_tokens' key."""

    def __init__(self):
        super().__init__(
            token_file_name="cogames.yaml",
            token_storage_key="login_tokens",  # Nested under 'login_tokens' key
        )


def perform_login(auth_server_url: str, force: bool = False, timeout: int = 300) -> bool:
    """Perform CoGames login authentication.

    Args:
        auth_server_url: URL of the CoGames authentication server
        force: If True, get a new token even if one already exists
        timeout: Authentication timeout in seconds

    Returns:
        True if authentication successful, False otherwise
    """
    authenticator = CoGamesAuthenticator()

    # Check if we already have a token
    if authenticator.has_saved_token(auth_server_url) and not force:
        return True

    # Perform authentication
    return authenticator.authenticate(auth_server_url=auth_server_url, token_key=auth_server_url, timeout=timeout)
