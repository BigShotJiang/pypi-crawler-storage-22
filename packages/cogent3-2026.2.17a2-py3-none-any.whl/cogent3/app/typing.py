"""defined type hints for app composability"""

# TODO write more extensive docstring explaining limited use of these types
from __future__ import annotations

import inspect
import re
from types import UnionType
from typing import (
    TYPE_CHECKING,
    Any,
    ForwardRef,
    Protocol,
    TypeVar,
    Union,
    get_args,
    get_origin,
    runtime_checkable,
)

if TYPE_CHECKING:  # pragma: no cover
    from cogent3.app.result import (
        bootstrap_result,
        generic_result,
        hypothesis_result,
        model_collection_result,
        model_result,
        tabular_result,
    )
    from cogent3.core.alignment import Alignment, SequenceCollection
    from cogent3.core.sequence import (
        ByteSequence,
        DnaSequence,
        ProteinSequence,
        ProteinWithStopSequence,
        RnaSequence,
        Sequence,
    )
    from cogent3.core.table import Table
    from cogent3.core.tree import PhyloNode
    from cogent3.evolve.fast_distance import DistanceMatrix
    from cogent3.util.dict_array import DictArray


NESTED_HINTS = (Union, UnionType, list, tuple, set)


@runtime_checkable
class HasSource(Protocol):
    @property
    def source(self) -> Any: ...


@runtime_checkable
class HasInfo(Protocol):
    @property
    def info(self) -> HasSource: ...


AlignedSeqsType = TypeVar("AlignedSeqsType", bound="Alignment")
UnalignedSeqsType = TypeVar("UnalignedSeqsType", bound="SequenceCollection")
SeqsCollectionType = Union[AlignedSeqsType, UnalignedSeqsType]
SeqType = TypeVar(
    "SeqType",
    "Sequence",
    "DnaSequence",
    "RnaSequence",
    "ByteSequence",
    "ProteinSequence",
    "ProteinWithStopSequence",
)
PairwiseDistanceType = TypeVar("PairwiseDistanceType", bound="DistanceMatrix")
TabularType = TypeVar("TabularType", "Table", "DictArray", "DistanceMatrix")
TreeType = TypeVar("TreeType", bound="PhyloNode")
BootstrapResultType = TypeVar("BootstrapResultType", bound="bootstrap_result")
HypothesisResultType = TypeVar("HypothesisResultType", bound="hypothesis_result")
ModelCollectionResultType = TypeVar(
    "ModelCollectionResultType",
    bound="model_collection_result",
)
ModelResultType = TypeVar("ModelResultType", bound="model_result")
TabularResultType = TypeVar("TabularResultType", bound="tabular_result")
GenericResultType = TypeVar("GenericResultType", bound="generic_result")
ResultType = Union[
    GenericResultType,
    BootstrapResultType,
    HypothesisResultType,
    ModelResultType,
    TabularResultType,
]
SerialisableType = TypeVar(
    "SerialisableType", SeqsCollectionType, TreeType, TabularType, ResultType, SeqType
)

IdentifierType = TypeVar("IdentifierType")


def _is_type(text):
    p = re.compile("[A-Z][a-z]+")
    matches = list(p.finditer(text))
    if len(matches) <= 1 or matches[0].start() != 0:
        return False

    return matches[-1].group() == "Type"


_all_types = {n: t for n, t in locals().items() if _is_type(n)}


def get_constraint_names(*hints) -> set[str | type]:
    """returns the set of named constraints of a type hint"""
    all_hints = set()
    for hint in hints:
        if hint == IdentifierType or (
            inspect.isclass(hint) and get_origin(hint) not in (list, tuple, set)
        ):
            all_hints.add(hint.__name__)
            continue

        if hint == SerialisableType or (
            inspect.isclass(hint) and get_origin(hint) not in (list, tuple, set)
        ):
            all_hints.add(hint.__name__)
            # we expand the nominated cogent3 compatible types
            for hnt in getattr(hint, "__constraints__", []):
                typ = get_constraint_names(hnt) | get_constraint_names(*get_args(hnt))
                all_hints |= typ
            continue

        if getattr(hint, "__bound__", None):
            all_hints.add(hint.__bound__)
            continue

        if getattr(hint, "__constraints__", None):
            all_hints.update(hint.__constraints__)
            continue

        if get_origin(hint) in NESTED_HINTS:
            all_hints.update(get_constraint_names(*get_args(hint)))

        if type(hint) == type:
            all_hints.add(hint.__name__)
        elif type(hint) == ForwardRef:
            all_hints.add(hint.__forward_arg__)
        elif type(hint) == str:
            all_hints.add(hint)

    return {h.__forward_arg__ if type(h) == ForwardRef else h for h in all_hints}


def type_tree(hint, depth=0) -> tuple:
    """compute the order of types"""
    level_type = get_origin(hint)
    if not level_type:
        return depth + 1, hint

    levels = []
    depths = []
    for arg in get_args(hint):
        d, t = type_tree(arg, depth=depth)
        levels.append(t)
        depths.append(d)
    depth = max(depths) + 1

    if len(levels) == 1:
        levels = levels[0]

    try:
        levels = tuple(levels)
    except TypeError:
        levels = (levels,)

    return depth, (level_type, levels)


def defined_types():
    """returns a table of the type hints and the cogent3 classes they represent

    Notes
    -----
    These (or standard Python) types are required to annotate argument and
    return values from cogent3 apps. They define the compatability of apps.
    """
    from cogent3.core.table import Table

    rows = [[n, ", ".join(get_constraint_names(t))] for n, t in _all_types.items()]
    title = "To use a type hint, from cogent3.app import typing"
    legend = (
        "An app which uses one of these hints is compatible with the indicated types."
    )
    table = Table(
        header=["type hint", "includes"],
        data=rows,
        title=title,
        legend=legend,
        index_name="type hint",
    )
    table.set_repr_policy(show_shape=False)
    return table
