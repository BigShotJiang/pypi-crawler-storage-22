# 🧠 Cognify AI

<p align="center">
  <strong>Code Cognition — Your AI-Powered Code Assistant</strong>
</p>

<p align="center">
  <a href="#features">Features</a> •
  <a href="#vscode-extension">VSCode Extension</a> •
  <a href="#installation">Installation</a> •
  <a href="#providers">Providers</a> •
  <a href="#usage">Usage</a> •
  <a href="#documentation">Docs</a>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/python-3.9+-blue.svg" alt="Python 3.9+">
  <img src="https://img.shields.io/badge/license-MIT-green.svg" alt="MIT License">
  <img src="https://img.shields.io/badge/tests-144%20passed-brightgreen.svg" alt="Tests">
  <img src="https://img.shields.io/badge/providers-6%20supported-purple.svg" alt="6 Providers">
  <img src="https://img.shields.io/badge/VSCode-Extension-blue.svg" alt="VSCode Extension">
</p>

---

A powerful CLI tool and **VSCode extension** that brings AI-powered code cognition to your development workflow. Review code, generate functions, search your codebase semantically, and refactor projects—with support for **multiple LLM providers** including local (Ollama) and cloud options with free tiers.

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🔍 **Code Review** | Analyze code for bugs, security issues, and style problems |
| ⚡ **Code Generation** | Generate functions, classes, and tests from natural language |
| 🔎 **Semantic Search** | Search your codebase using natural language queries |
| 📝 **AI File Editing** | Edit files with natural language instructions |
| 🔄 **Multi-File Refactor** | Refactor across multiple files at once |
| ✏️ **Symbol Renaming** | Rename functions, classes, variables across your project |
| 💬 **Interactive Chat** | Chat with AI about your code |
| 📊 **Codebase Indexing** | Create searchable semantic index with RAG |
| 🌐 **Multi-Provider** | Support for 6 LLM providers (local & cloud) |
| 🖥️ **VSCode Extension** | Full IDE integration with sidebar chat |

## 🖥️ VSCode Extension

<p align="center">
  <img src="vscode-extension/images/icon.png" width="64" alt="Cognify VSCode">
</p>

The Cognify AI VSCode extension brings all the power of Cognify directly into your IDE with a beautiful sidebar chat interface.

### Extension Features

- ⚛️ **Sidebar Chat Panel** - Chat with AI directly in VSCode sidebar
- 📎 **Add Context** - Include code from your editor in conversations
- 🔍 **Code Review** - Review files with inline diagnostics
- ✨ **Code Generation** - Generate code from descriptions
- 💡 **Code Explanation** - Get explanations for selected code
- ✏️ **AI Editing** - Edit code with natural language

### Quick Actions
- 📋 Review current file
- 💡 Explain selected code
- ✨ Suggest improvements
- 🧪 Generate tests

### Install VSCode Extension

```bash
# Build from source
cd vscode-extension
npm install
npm run package

# Install the extension
code --install-extension cognify-ai-0.2.0.vsix
```

Or install via VSCode:
1. Open VSCode
2. Go to Extensions sidebar
3. Click "..." → "Install from VSIX..."
4. Select `cognify-ai-0.2.0.vsix`

### Using the Extension

1. Click the ⚛️ Cognify icon in the Activity Bar (left sidebar)
2. Use quick actions or type your question
3. Click "📎 Add Context" to include code from your editor
4. Press Enter or click Send

**Keyboard Shortcuts:**
| Command | Mac | Windows/Linux |
|---------|-----|---------------|
| Review File | `Cmd+Shift+R` | `Ctrl+Shift+R` |
| Generate Code | `Cmd+Shift+G` | `Ctrl+Shift+G` |
| Explain Code | `Cmd+Shift+E` | `Ctrl+Shift+E` |
| Open Chat | `Cmd+Shift+C` | `Ctrl+Shift+C` |

## 🤖 Supported Providers

| Provider | Free Tier | API Key | Best For |
|----------|-----------|---------|----------|
| **Ollama** | ✅ Unlimited | ❌ None | Privacy, offline use |
| **Google AI** | ✅ Generous | ✅ Required | 1M+ token context |
| **Groq** | ✅ 1000 req/day | ✅ Required | Fastest inference |
| **Cerebras** | ✅ Available | ✅ Required | Fast inference |
| **OpenRouter** | ✅ Free models | ✅ Required | Model variety |
| **OpenAI** | ❌ Paid only | ✅ Required | GPT-4 quality |

## 🚀 Quick Start

### Option 1: Local with Ollama (No API Key)

```bash
# Install Ollama from https://ollama.ai
ollama pull deepseek-coder:6.7b
ollama serve
```

### Option 2: Cloud with Free Tier

```bash
# Google AI Studio (1M token context, free)
export GOOGLE_API_KEY="your-key"  # Get from https://aistudio.google.com/apikey

# OR Groq (fastest inference, free tier)
export GROQ_API_KEY="your-key"    # Get from https://console.groq.com/keys

# OR OpenRouter (free models available)
export OPENROUTER_API_KEY="your-key"  # Get from https://openrouter.ai/keys
```

### Installation

```bash
# Clone the repository
git clone https://github.com/akkssy/cognify-ai.git
cd cognify-ai

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install the package
pip install -e .
```

### Verify Installation

```bash
# Check status and available providers
cognify status
cognify providers
```

## 📖 CLI Usage

### Code Review
```bash
cognify review path/to/file.py
cognify review src/ --format json
```

### Code Generation
```bash
cognify generate "binary search function" --language python
cognify generate "REST API client class" --mode class
```

### Semantic Search
```bash
# First, index your codebase
cognify index .

# Then search
cognify search "error handling"
```

### File Editing
```bash
cognify edit config.py "add logging to all functions" --preview
```

### Interactive Chat
```bash
cognify chat
```

### All Commands
```bash
cognify --help
```

## ⚙️ Configuration

Configuration is managed via `config.yaml`:

```yaml
llm:
  provider: "ollama"
  model: "deepseek-coder:6.7b"
  base_url: "http://localhost:11434"
  temperature: 0.1
  max_tokens: 4096
```

Or use environment variables:
```bash
export AI_ASSISTANT_LLM_PROVIDER="groq"
export AI_ASSISTANT_LLM_MODEL="llama-3.3-70b-versatile"
export GROQ_API_KEY="your-key"
```

## 📁 Project Structure

```
cognify-ai/
├── src/ai_code_assistant/    # Core Python package
│   ├── cli.py                # Command-line interface
│   ├── providers/            # LLM providers
│   ├── reviewer/             # Code review
│   ├── generator/            # Code generation
│   ├── retrieval/            # Semantic search
│   ├── editor/               # AI file editing
│   └── chat/                 # Interactive chat
├── vscode-extension/         # VSCode Extension
│   ├── src/                  # Extension source
│   ├── images/               # Icons
│   └── package.json          # Extension manifest
├── tests/                    # Unit tests
├── docs/                     # Documentation
└── config.yaml               # Configuration
```

## 🧪 Testing

```bash
PYTHONPATH=src pytest tests/ -v
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

---

<p align="center">
  Made with ❤️ for developers who want flexible AI-powered coding assistance
</p>
