"""Base provider class for LLM integrations."""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Dict, Iterator, List, Optional
import logging

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage
from pydantic import BaseModel
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    before_sleep_log,
)

logger = logging.getLogger(__name__)


class ProviderType(str, Enum):
    """Supported LLM provider types."""
    OLLAMA = "ollama"
    GOOGLE = "google"
    GROQ = "groq"
    CEREBRAS = "cerebras"
    OPENROUTER = "openrouter"
    OPENAI = "openai"


class ProviderConfig(BaseModel):
    """Configuration for an LLM provider."""
    provider: ProviderType = ProviderType.OLLAMA
    model: str = "deepseek-coder:6.7b"
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    temperature: float = 0.1
    max_tokens: int = 4096
    timeout: int = 120


class ModelInfo(BaseModel):
    """Information about a model."""
    name: str
    provider: ProviderType
    description: str = ""
    context_window: int = 4096
    is_free: bool = True


def _is_retryable_error(exception: Exception) -> bool:
    """Check if an exception should trigger a retry."""
    error_msg = str(exception).lower()
    # Rate limits, temporary server issues, timeout errors
    retryable_keywords = [
        "rate limit", "rate_limit", "429",
        "503", "502", "504",
        "timeout", "timed out",
        "temporarily unavailable",
        "server error", "internal error",
        "connection", "network",
    ]
    return any(keyword in error_msg for keyword in retryable_keywords)


class BaseProvider(ABC):
    """Abstract base class for LLM providers."""

    # Provider metadata
    provider_type: ProviderType
    display_name: str
    requires_api_key: bool = True
    default_model: str
    free_tier: bool = True

    # Available models for this provider
    available_models: List[ModelInfo] = []

    # Retry settings for cloud providers
    _retry_attempts: int = 3
    _retry_min_wait: int = 2
    _retry_max_wait: int = 30

    def __init__(self, config: ProviderConfig):
        """Initialize the provider with configuration."""
        self.config = config
        self._llm: Optional[BaseChatModel] = None

    @property
    def llm(self) -> BaseChatModel:
        """Get or create the LLM instance."""
        if self._llm is None:
            self._llm = self._create_llm()
        return self._llm

    @abstractmethod
    def _create_llm(self) -> BaseChatModel:
        """Create the LangChain LLM instance. Must be implemented by subclasses."""
        pass

    @abstractmethod
    def validate_config(self) -> tuple[bool, str]:
        """Validate the provider configuration. Returns (is_valid, error_message)."""
        pass

    def _should_retry(self) -> bool:
        """Check if this provider should use retry logic (cloud providers only)."""
        return self.provider_type != ProviderType.OLLAMA

    def invoke(self, prompt: str, system_prompt: Optional[str] = None) -> str:
        """Invoke the LLM with a prompt and optional system message."""
        messages: List[BaseMessage] = []
        if system_prompt:
            messages.append(SystemMessage(content=system_prompt))
        messages.append(HumanMessage(content=prompt))

        if self._should_retry():
            return self._invoke_with_retry(messages)
        else:
            response = self.llm.invoke(messages)
            return str(response.content)

    def _invoke_with_retry(self, messages: List[BaseMessage]) -> str:
        """Invoke with exponential backoff retry for cloud providers."""
        @retry(
            stop=stop_after_attempt(self._retry_attempts),
            wait=wait_exponential(multiplier=1, min=self._retry_min_wait, max=self._retry_max_wait),
            retry=retry_if_exception_type(Exception),
            before_sleep=before_sleep_log(logger, logging.WARNING),
            reraise=True,
        )
        def _do_invoke():
            try:
                response = self.llm.invoke(messages)
                return str(response.content)
            except Exception as e:
                if _is_retryable_error(e):
                    logger.warning(f"Retryable error from {self.provider_type.value}: {e}")
                    raise  # Will be retried
                else:
                    raise  # Non-retryable, will not retry

        return _do_invoke()

    def stream(self, prompt: str, system_prompt: Optional[str] = None) -> Iterator[str]:
        """Stream LLM response for real-time output."""
        messages: List[BaseMessage] = []
        if system_prompt:
            messages.append(SystemMessage(content=system_prompt))
        messages.append(HumanMessage(content=prompt))

        if self._should_retry():
            yield from self._stream_with_retry(messages)
        else:
            for chunk in self.llm.stream(messages):
                yield str(chunk.content)

    def _stream_with_retry(self, messages: List[BaseMessage]) -> Iterator[str]:
        """Stream with retry logic for cloud providers."""
        last_exception = None

        for attempt in range(self._retry_attempts):
            try:
                for chunk in self.llm.stream(messages):
                    yield str(chunk.content)
                return  # Success, exit
            except Exception as e:
                last_exception = e
                if _is_retryable_error(e) and attempt < self._retry_attempts - 1:
                    import time
                    wait_time = min(
                        self._retry_max_wait,
                        self._retry_min_wait * (2 ** attempt)
                    )
                    logger.warning(
                        f"Retryable error from {self.provider_type.value}: {e}. "
                        f"Retrying in {wait_time}s (attempt {attempt + 1}/{self._retry_attempts})"
                    )
                    time.sleep(wait_time)
                else:
                    raise

        if last_exception:
            raise last_exception

    def check_connection(self) -> bool:
        """Check if the provider is accessible."""
        try:
            self.invoke("Say 'ok' and nothing else.")
            return True
        except Exception:
            return False

    def get_model_info(self) -> Dict[str, Any]:
        """Get information about the current model configuration."""
        return {
            "provider": self.provider_type.value,
            "model": self.config.model,
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
            "base_url": self.config.base_url,
            "free_tier": self.free_tier,
        }

    @classmethod
    def get_available_models(cls) -> List[ModelInfo]:
        """Get list of available models for this provider."""
        return cls.available_models

    @classmethod
    def get_setup_instructions(cls) -> str:
        """Get setup instructions for this provider."""
        return f"Configure {cls.display_name} in your config.yaml or set environment variables."
