"""
Codebase indexer using ChromaDB and sentence-transformers.

Indexes code files for semantic search.
"""

import os
import json
import hashlib
import time
from pathlib import Path
from typing import List, Optional, Set, Dict, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer

from .chunker import CodeChunker, CodeChunk


class SkipReason(Enum):
    """Reasons why a file might be skipped during indexing."""
    UNSUPPORTED_EXTENSION = "unsupported_extension"
    IGNORED_DIRECTORY = "ignored_directory"
    FILE_TOO_LARGE = "file_too_large"
    EMPTY_FILE = "empty_file"
    READ_ERROR = "read_error"
    NO_CHUNKS = "no_chunks"
    BINARY_FILE = "binary_file"


@dataclass
class SkippedFile:
    """Information about a skipped file."""
    path: str
    reason: SkipReason
    details: str = ""

    def to_dict(self) -> dict:
        return {
            "path": self.path,
            "reason": self.reason.value,
            "details": self.details,
        }


@dataclass
class IndexStats:
    """Comprehensive statistics about the indexing operation."""
    # Basic counts
    total_files_found: int = 0
    total_files_indexed: int = 0
    total_chunks: int = 0
    total_lines_indexed: int = 0

    # File lists
    indexed_files: List[str] = field(default_factory=list)
    skipped_files: List[SkippedFile] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    # Language breakdown
    files_by_language: Dict[str, int] = field(default_factory=dict)
    chunks_by_language: Dict[str, int] = field(default_factory=dict)
    lines_by_language: Dict[str, int] = field(default_factory=dict)

    # Directory breakdown
    files_by_directory: Dict[str, int] = field(default_factory=dict)

    # Skip reason breakdown
    skipped_by_reason: Dict[str, int] = field(default_factory=dict)

    # Timing metrics
    start_time: float = 0.0
    end_time: float = 0.0
    embedding_time: float = 0.0
    chunking_time: float = 0.0
    storage_time: float = 0.0

    # Storage metrics
    index_size_bytes: int = 0
    index_path: str = ""

    # Configuration used
    embedding_model: str = ""
    extensions_configured: Set[str] = field(default_factory=set)
    ignored_dirs_configured: Set[str] = field(default_factory=set)
    max_file_size: int = 0

    # Metadata
    indexed_at: str = ""
    root_path: str = ""

    # Project Intelligence (populated after indexing)
    project_intelligence: Optional[Any] = None

    @property
    def duration_seconds(self) -> float:
        """Total indexing duration in seconds."""
        return self.end_time - self.start_time if self.end_time > 0 else 0.0

    @property
    def files_per_second(self) -> float:
        """Indexing speed in files per second."""
        if self.duration_seconds > 0:
            return self.total_files_indexed / self.duration_seconds
        return 0.0

    @property
    def chunks_per_file(self) -> float:
        """Average chunks per indexed file."""
        if self.total_files_indexed > 0:
            return self.total_chunks / self.total_files_indexed
        return 0.0

    @property
    def index_size_mb(self) -> float:
        """Index size in megabytes."""
        return self.index_size_bytes / (1024 * 1024)

    def add_indexed_file(self, path: str, language: str, chunks: int, lines: int):
        """Record a successfully indexed file."""
        self.indexed_files.append(path)
        self.total_files_indexed += 1
        self.total_chunks += chunks
        self.total_lines_indexed += lines

        # Update language stats
        self.files_by_language[language] = self.files_by_language.get(language, 0) + 1
        self.chunks_by_language[language] = self.chunks_by_language.get(language, 0) + chunks
        self.lines_by_language[language] = self.lines_by_language.get(language, 0) + lines

        # Update directory stats
        directory = str(Path(path).parent) if "/" in path or "\\" in path else "."
        self.files_by_directory[directory] = self.files_by_directory.get(directory, 0) + 1

    def add_skipped_file(self, path: str, reason: SkipReason, details: str = ""):
        """Record a skipped file with reason."""
        self.skipped_files.append(SkippedFile(path=path, reason=reason, details=details))
        reason_key = reason.value
        self.skipped_by_reason[reason_key] = self.skipped_by_reason.get(reason_key, 0) + 1

    def add_error(self, error: str):
        """Record an error."""
        self.errors.append(error)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "summary": {
                "total_files_found": self.total_files_found,
                "total_files_indexed": self.total_files_indexed,
                "total_chunks": self.total_chunks,
                "total_lines_indexed": self.total_lines_indexed,
                "files_skipped": len(self.skipped_files),
                "errors_count": len(self.errors),
            },
            "timing": {
                "duration_seconds": round(self.duration_seconds, 2),
                "files_per_second": round(self.files_per_second, 2),
                "embedding_time_seconds": round(self.embedding_time, 2),
                "chunking_time_seconds": round(self.chunking_time, 2),
                "storage_time_seconds": round(self.storage_time, 2),
            },
            "storage": {
                "index_size_bytes": self.index_size_bytes,
                "index_size_mb": round(self.index_size_mb, 2),
                "index_path": self.index_path,
            },
            "breakdown": {
                "files_by_language": dict(sorted(self.files_by_language.items(), key=lambda x: -x[1])),
                "chunks_by_language": dict(sorted(self.chunks_by_language.items(), key=lambda x: -x[1])),
                "lines_by_language": dict(sorted(self.lines_by_language.items(), key=lambda x: -x[1])),
                "files_by_directory": dict(sorted(self.files_by_directory.items(), key=lambda x: -x[1])[:20]),
                "skipped_by_reason": self.skipped_by_reason,
            },
            "configuration": {
                "embedding_model": self.embedding_model,
                "extensions_configured": sorted(list(self.extensions_configured)),
                "ignored_dirs_configured": sorted(list(self.ignored_dirs_configured)),
                "max_file_size_bytes": self.max_file_size,
            },
            "metadata": {
                "indexed_at": self.indexed_at,
                "root_path": self.root_path,
                "chunks_per_file_avg": round(self.chunks_per_file, 2),
            },
            "files": {
                "indexed": self.indexed_files[:100],  # Limit for readability
                "indexed_count": len(self.indexed_files),
                "skipped": [sf.to_dict() for sf in self.skipped_files[:50]],
                "skipped_count": len(self.skipped_files),
                "errors": self.errors[:20],
                "errors_count": len(self.errors),
            },
            "project_intelligence": self.project_intelligence.to_dict() if self.project_intelligence else None,
        }

    def get_suggestions(self) -> List[str]:
        """Generate actionable suggestions based on indexing results."""
        suggestions = []

        # Check for common issues
        if self.skipped_by_reason.get("unsupported_extension", 0) > 10:
            suggestions.append(
                f"💡 {self.skipped_by_reason['unsupported_extension']} files skipped due to unsupported extensions. "
                "Consider adding common extensions to your config."
            )

        if self.skipped_by_reason.get("file_too_large", 0) > 0:
            suggestions.append(
                f"💡 {self.skipped_by_reason['file_too_large']} files skipped due to size limits. "
                "Increase max_file_size in config if needed."
            )

        if len(self.errors) > 0:
            suggestions.append(
                f"⚠️  {len(self.errors)} errors occurred during indexing. "
                "Check file permissions and encoding."
            )

        if self.total_files_indexed == 0:
            suggestions.append(
                "❌ No files were indexed! Check that your directory contains supported file types."
            )

        if self.chunks_per_file > 20:
            suggestions.append(
                f"💡 High chunk count per file ({self.chunks_per_file:.1f}). "
                "Consider increasing chunk_size for better performance."
            )

        # Language-specific suggestions
        if "python" not in self.files_by_language and self.total_files_indexed > 0:
            suggestions.append(
                "💡 No Python files indexed. If this is a Python project, check file extensions."
            )

        # Performance suggestions
        if self.duration_seconds > 60 and self.total_files_indexed > 100:
            suggestions.append(
                f"💡 Indexing took {self.duration_seconds:.0f}s. Consider using incremental indexing for faster updates."
            )

        if not suggestions and self.total_files_indexed > 0:
            suggestions.append("✅ Indexing completed successfully with no issues detected.")

        return suggestions

    def save_to_file(self, path: Path):
        """Save stats to a JSON file."""
        with open(path, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load_from_file(cls, path: Path) -> Optional['IndexStats']:
        """Load stats from a JSON file."""
        if not path.exists():
            return None
        try:
            with open(path, 'r') as f:
                data = json.load(f)

            stats = cls()
            # Restore basic fields from summary
            summary = data.get("summary", {})
            stats.total_files_found = summary.get("total_files_found", 0)
            stats.total_files_indexed = summary.get("total_files_indexed", 0)
            stats.total_chunks = summary.get("total_chunks", 0)
            stats.total_lines_indexed = summary.get("total_lines_indexed", 0)

            # Restore timing
            timing = data.get("timing", {})
            stats.start_time = 0
            stats.end_time = timing.get("duration_seconds", 0)
            stats.embedding_time = timing.get("embedding_time_seconds", 0)
            stats.chunking_time = timing.get("chunking_time_seconds", 0)
            stats.storage_time = timing.get("storage_time_seconds", 0)

            # Restore storage
            storage = data.get("storage", {})
            stats.index_size_bytes = storage.get("index_size_bytes", 0)
            stats.index_path = storage.get("index_path", "")

            # Restore breakdown
            breakdown = data.get("breakdown", {})
            stats.files_by_language = breakdown.get("files_by_language", {})
            stats.chunks_by_language = breakdown.get("chunks_by_language", {})
            stats.lines_by_language = breakdown.get("lines_by_language", {})
            stats.files_by_directory = breakdown.get("files_by_directory", {})
            stats.skipped_by_reason = breakdown.get("skipped_by_reason", {})

            # Restore configuration
            config = data.get("configuration", {})
            stats.embedding_model = config.get("embedding_model", "")
            stats.extensions_configured = set(config.get("extensions_configured", []))
            stats.ignored_dirs_configured = set(config.get("ignored_dirs_configured", []))
            stats.max_file_size = config.get("max_file_size_bytes", 0)

            # Restore metadata
            metadata = data.get("metadata", {})
            stats.indexed_at = metadata.get("indexed_at", "")
            stats.root_path = metadata.get("root_path", "")

            # Restore file lists (limited)
            files = data.get("files", {})
            stats.indexed_files = files.get("indexed", [])
            stats.errors = files.get("errors", [])

            # Restore project intelligence (as dict for now, can be reconstructed)
            intel_data = data.get("project_intelligence")
            if intel_data:
                # Store raw dict - can be used directly or reconstructed
                from .project_analyzer import ProjectIntelligence
                intel = ProjectIntelligence()
                pt = intel_data.get("project_type", {})
                intel.project_type = pt.get("type", "Unknown")
                intel.project_type_confidence = pt.get("confidence", 0.0)
                intel.project_type_indicators = pt.get("indicators", [])

                arch = intel_data.get("architecture", {})
                intel.architecture_style = arch.get("style", "Unknown")
                intel.frameworks = arch.get("frameworks", [])
                intel.design_patterns = arch.get("design_patterns", [])

                tech = intel_data.get("technology_stack", {})
                intel.primary_language = tech.get("primary_language", "")
                intel.language_percentages = tech.get("language_percentages", {})
                intel.frontend_technologies = tech.get("frontend", [])
                intel.backend_technologies = tech.get("backend", [])
                intel.databases = tech.get("databases", [])
                intel.build_tools = tech.get("build_tools", [])
                intel.package_managers = tech.get("package_managers", [])
                intel.testing_frameworks = tech.get("testing_frameworks", [])

                insights = intel_data.get("codebase_insights", {})
                intel.entry_points = insights.get("entry_points", [])
                intel.key_directories = insights.get("key_directories", {})
                intel.config_files = insights.get("config_files", [])

                features = intel_data.get("features", {})
                intel.has_tests = features.get("has_tests", False)
                intel.has_ci_cd = features.get("has_ci_cd", False)
                intel.has_docker = features.get("has_docker", False)
                intel.has_documentation = features.get("has_documentation", False)

                stats.project_intelligence = intel

            return stats
        except Exception:
            return None


@dataclass  
class IndexConfig:
    """Configuration for the indexer."""
    # Embedding model (runs locally)
    embedding_model: str = "all-MiniLM-L6-v2"
    # ChromaDB persistence directory
    persist_directory: str = ".ai-assistant-index"
    # Collection name
    collection_name: str = "codebase"
    # File extensions to index
    extensions: Set[str] = field(default_factory=lambda: {
        ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rs",
        ".rb", ".php", ".c", ".cpp", ".h", ".hpp", ".cs", ".swift",
        ".kt", ".scala", ".sh", ".yaml", ".yml", ".json", ".md", ".sql",
        ".html", ".css", ".scss", ".vue", ".svelte",
    })
    # Directories to ignore
    ignore_dirs: Set[str] = field(default_factory=lambda: {
        ".git", ".svn", ".hg", "node_modules", "__pycache__", ".pytest_cache",
        ".mypy_cache", ".tox", ".venv", "venv", "env", ".env", "dist", "build",
        "target", ".idea", ".vscode", "coverage", ".coverage", "htmlcov",
        ".eggs", "*.egg-info", ".ai-assistant-index",
    })
    # Max file size in bytes (skip large files)
    max_file_size: int = 1024 * 1024  # 1MB


class CodebaseIndexer:
    """Indexes codebase into ChromaDB for semantic search."""
    
    def __init__(self, config: Optional[IndexConfig] = None, root_path: Optional[str] = None):
        """Initialize the indexer.
        
        Args:
            config: Index configuration
            root_path: Root directory of the codebase
        """
        self.config = config or IndexConfig()
        self.root_path = Path(root_path) if root_path else Path.cwd()
        self.chunker = CodeChunker()
        
        # Initialize embedding model (lazy load)
        self._embedder: Optional[SentenceTransformer] = None
        
        # Initialize ChromaDB
        persist_path = self.root_path / self.config.persist_directory
        self._client = chromadb.PersistentClient(
            path=str(persist_path),
            settings=Settings(anonymized_telemetry=False),
        )
        self._collection = self._client.get_or_create_collection(
            name=self.config.collection_name,
            metadata={"description": "Codebase index for semantic search"},
        )
    
    @property
    def embedder(self) -> SentenceTransformer:
        """Lazy load the embedding model."""
        if self._embedder is None:
            self._embedder = SentenceTransformer(self.config.embedding_model)
        return self._embedder
    
    def _should_index_file(self, file_path: Path, stats: Optional[IndexStats] = None) -> bool:
        """Check if a file should be indexed.

        Args:
            file_path: Path to the file
            stats: Optional IndexStats to record skip reasons

        Returns:
            True if file should be indexed, False otherwise
        """
        rel_path = str(file_path)
        try:
            rel_path = str(file_path.relative_to(self.root_path))
        except ValueError:
            pass

        # Check extension
        if file_path.suffix.lower() not in self.config.extensions:
            if stats:
                stats.add_skipped_file(
                    rel_path,
                    SkipReason.UNSUPPORTED_EXTENSION,
                    f"Extension '{file_path.suffix}' not in configured extensions"
                )
            return False

        # Check if in ignored directory
        for part in file_path.parts:
            if part in self.config.ignore_dirs:
                if stats:
                    stats.add_skipped_file(
                        rel_path,
                        SkipReason.IGNORED_DIRECTORY,
                        f"In ignored directory '{part}'"
                    )
                return False
            # Handle glob patterns like *.egg-info
            for pattern in self.config.ignore_dirs:
                if "*" in pattern and file_path.match(pattern):
                    if stats:
                        stats.add_skipped_file(
                            rel_path,
                            SkipReason.IGNORED_DIRECTORY,
                            f"Matches ignore pattern '{pattern}'"
                        )
                    return False

        # Check file size
        try:
            file_size = file_path.stat().st_size
            if file_size > self.config.max_file_size:
                if stats:
                    stats.add_skipped_file(
                        rel_path,
                        SkipReason.FILE_TOO_LARGE,
                        f"File size {file_size / 1024:.1f}KB exceeds limit {self.config.max_file_size / 1024:.1f}KB"
                    )
                return False
            if file_size == 0:
                if stats:
                    stats.add_skipped_file(rel_path, SkipReason.EMPTY_FILE, "File is empty")
                return False
        except OSError as e:
            if stats:
                stats.add_skipped_file(rel_path, SkipReason.READ_ERROR, str(e))
            return False

        return True
    
    def _get_file_hash(self, content: str) -> str:
        """Get hash of file content for change detection."""
        return hashlib.md5(content.encode()).hexdigest()
    
    def _read_file(self, file_path: Path) -> Optional[str]:
        """Safely read a file."""
        try:
            return file_path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return None
    
    def index_file(self, file_path: Path, stats: IndexStats) -> bool:
        """Index a single file.

        Returns True if file was indexed, False if skipped.
        """
        content = self._read_file(file_path)

        # Get relative path for storage
        try:
            rel_path = str(file_path.relative_to(self.root_path))
        except ValueError:
            rel_path = str(file_path)

        if content is None:
            stats.add_skipped_file(rel_path, SkipReason.READ_ERROR, "Could not read file")
            stats.add_error(f"Could not read: {file_path}")
            return False

        # Check for binary content (null bytes)
        if '\x00' in content:
            stats.add_skipped_file(rel_path, SkipReason.BINARY_FILE, "File appears to be binary")
            return False

        # Chunk the file with timing
        chunk_start = time.time()
        chunks = self.chunker.chunk_file(rel_path, content)
        stats.chunking_time += time.time() - chunk_start

        if not chunks:
            stats.add_skipped_file(rel_path, SkipReason.NO_CHUNKS, "No chunks generated (file may be empty or too small)")
            return False

        # Get language from first chunk
        language = chunks[0].language or "unknown"
        lines_count = content.count('\n') + 1

        # Generate embeddings with timing
        embed_start = time.time()
        texts = [chunk.content for chunk in chunks]
        embeddings = self.embedder.encode(texts, show_progress_bar=False).tolist()
        stats.embedding_time += time.time() - embed_start

        # Prepare data for ChromaDB
        ids = [chunk.id for chunk in chunks]
        documents = texts
        metadatas = [chunk.to_dict() for chunk in chunks]

        # Store in ChromaDB with timing
        storage_start = time.time()

        # Delete old chunks for this file (if re-indexing)
        try:
            existing = self._collection.get(where={"file_path": rel_path})
            if existing["ids"]:
                self._collection.delete(ids=existing["ids"])
        except Exception:
            pass  # Collection might be empty

        # Add to collection
        self._collection.add(
            ids=ids,
            documents=documents,
            embeddings=embeddings,
            metadatas=metadatas,
        )
        stats.storage_time += time.time() - storage_start

        # Record success with detailed stats
        stats.add_indexed_file(rel_path, language, len(chunks), lines_count)
        return True

    def index_directory(
        self,
        directory: Optional[Path] = None,
        verbose: bool = True,
        progress_callback: Optional[callable] = None
    ) -> IndexStats:
        """Index all files in a directory recursively.

        Args:
            directory: Directory to index (defaults to root_path)
            verbose: Print progress
            progress_callback: Optional callback(current, total, file_path) for progress updates

        Returns:
            IndexStats with comprehensive results
        """
        directory = directory or self.root_path
        stats = IndexStats()

        # Record start time and configuration
        stats.start_time = time.time()
        stats.indexed_at = datetime.now().isoformat()
        stats.root_path = str(directory.absolute())
        stats.embedding_model = self.config.embedding_model
        stats.extensions_configured = self.config.extensions.copy()
        stats.ignored_dirs_configured = self.config.ignore_dirs.copy()
        stats.max_file_size = self.config.max_file_size
        stats.index_path = str(self.root_path / self.config.persist_directory)

        # Count all files first (for accurate total)
        all_files = list(directory.rglob("*"))
        all_files = [f for f in all_files if f.is_file()]
        stats.total_files_found = len(all_files)

        if verbose:
            print(f"Scanning {len(all_files)} files...")

        # Filter files and track skip reasons
        files_to_index = []
        for file_path in all_files:
            if self._should_index_file(file_path, stats):
                files_to_index.append(file_path)

        if verbose:
            print(f"Found {len(files_to_index)} indexable files (skipped {len(stats.skipped_files)})...")

        # Index each file
        for i, file_path in enumerate(files_to_index):
            if verbose and (i + 1) % 10 == 0:
                print(f"  Indexed {i + 1}/{len(files_to_index)} files...")

            if progress_callback:
                try:
                    rel_path = str(file_path.relative_to(self.root_path))
                except ValueError:
                    rel_path = str(file_path)
                progress_callback(i + 1, len(files_to_index), rel_path)

            try:
                self.index_file(file_path, stats)
            except Exception as e:
                stats.add_error(f"{file_path}: {str(e)}")

        # Record end time
        stats.end_time = time.time()

        # Calculate index size on disk
        index_path = self.root_path / self.config.persist_directory
        if index_path.exists():
            stats.index_size_bytes = sum(
                f.stat().st_size for f in index_path.rglob("*") if f.is_file()
            )

        # Run project intelligence analysis
        if verbose:
            print("\n🔍 Analyzing project structure...")
        try:
            from .project_analyzer import ProjectAnalyzer
            analyzer = ProjectAnalyzer(directory)
            stats.project_intelligence = analyzer.analyze(stats)
            if verbose:
                summary = stats.project_intelligence.get_summary()
                print(f"  {summary}")
        except Exception as e:
            if verbose:
                print(f"  Warning: Project analysis failed: {e}")

        # Save stats to file for later retrieval
        stats_file = index_path / "index_stats.json"
        try:
            stats.save_to_file(stats_file)
        except Exception as e:
            if verbose:
                print(f"Warning: Could not save stats file: {e}")

        if verbose:
            print(f"\n✓ Indexed {stats.total_files_indexed} files ({stats.total_chunks} chunks)")
            print(f"  Duration: {stats.duration_seconds:.1f}s ({stats.files_per_second:.1f} files/sec)")
            if stats.errors:
                print(f"⚠ {len(stats.errors)} errors occurred")

        return stats

    def clear_index(self) -> None:
        """Clear the entire index."""
        self._client.delete_collection(self.config.collection_name)
        self._collection = self._client.create_collection(
            name=self.config.collection_name,
            metadata={"description": "Codebase index for semantic search"},
        )
        # Also remove stats file
        stats_file = self.root_path / self.config.persist_directory / "index_stats.json"
        if stats_file.exists():
            stats_file.unlink()

    def get_stats(self) -> dict:
        """Get statistics about the current index."""
        count = self._collection.count()

        # Calculate current index size
        index_path = self.root_path / self.config.persist_directory
        index_size = 0
        if index_path.exists():
            index_size = sum(f.stat().st_size for f in index_path.rglob("*") if f.is_file())

        return {
            "total_chunks": count,
            "collection_name": self.config.collection_name,
            "embedding_model": self.config.embedding_model,
            "root_path": str(self.root_path),
            "index_path": str(index_path),
            "index_size_bytes": index_size,
            "index_size_mb": round(index_size / (1024 * 1024), 2),
        }

    def get_saved_stats(self) -> Optional[IndexStats]:
        """Load previously saved indexing statistics.

        Returns:
            IndexStats if stats file exists, None otherwise
        """
        stats_file = self.root_path / self.config.persist_directory / "index_stats.json"
        return IndexStats.load_from_file(stats_file)

    def has_index(self) -> bool:
        """Check if an index exists."""
        index_path = self.root_path / self.config.persist_directory
        return index_path.exists() and self._collection.count() > 0

