"""
Project Intelligence Analyzer.

Analyzes indexed codebase to detect project type, architecture,
technology stack, and provide codebase insights.
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, List, Optional, Set, Any, Tuple
from dataclasses import dataclass, field
from collections import defaultdict


@dataclass
class ProjectIntelligence:
    """Comprehensive project intelligence summary."""

    # Project Type Detection
    project_type: str = "Unknown"  # e.g., "Web Application", "REST API", "CLI Tool"
    project_type_confidence: float = 0.0
    project_type_indicators: List[str] = field(default_factory=list)

    # Architecture Analysis
    architecture_style: str = "Unknown"  # e.g., "MVC", "Microservices", "Monolith"
    frameworks: List[str] = field(default_factory=list)
    design_patterns: List[str] = field(default_factory=list)

    # Technology Stack
    primary_language: str = ""
    language_percentages: Dict[str, float] = field(default_factory=dict)
    frontend_technologies: List[str] = field(default_factory=list)
    backend_technologies: List[str] = field(default_factory=list)
    databases: List[str] = field(default_factory=list)
    build_tools: List[str] = field(default_factory=list)
    package_managers: List[str] = field(default_factory=list)
    testing_frameworks: List[str] = field(default_factory=list)

    # Codebase Insights
    entry_points: List[str] = field(default_factory=list)
    key_directories: Dict[str, str] = field(default_factory=dict)  # dir -> purpose
    config_files: List[str] = field(default_factory=list)
    api_endpoints: List[str] = field(default_factory=list)

    # Additional metadata
    has_tests: bool = False
    has_ci_cd: bool = False
    has_docker: bool = False
    has_documentation: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "project_type": {
                "type": self.project_type,
                "confidence": round(self.project_type_confidence, 2),
                "indicators": self.project_type_indicators[:5],
            },
            "architecture": {
                "style": self.architecture_style,
                "frameworks": self.frameworks,
                "design_patterns": self.design_patterns,
            },
            "technology_stack": {
                "primary_language": self.primary_language,
                "language_percentages": {k: round(v, 1) for k, v in self.language_percentages.items()},
                "frontend": self.frontend_technologies,
                "backend": self.backend_technologies,
                "databases": self.databases,
                "build_tools": self.build_tools,
                "package_managers": self.package_managers,
                "testing_frameworks": self.testing_frameworks,
            },
            "codebase_insights": {
                "entry_points": self.entry_points[:10],
                "key_directories": dict(list(self.key_directories.items())[:10]),
                "config_files": self.config_files[:10],
                "api_endpoints_count": len(self.api_endpoints),
                "api_endpoints_sample": self.api_endpoints[:5],
            },
            "features": {
                "has_tests": self.has_tests,
                "has_ci_cd": self.has_ci_cd,
                "has_docker": self.has_docker,
                "has_documentation": self.has_documentation,
            },
        }

    def get_summary(self) -> str:
        """Get a human-readable summary."""
        parts = []

        if self.project_type != "Unknown":
            parts.append(f"📦 {self.project_type}")

        if self.primary_language:
            parts.append(f"💻 {self.primary_language}")

        if self.frameworks:
            parts.append(f"🔧 {', '.join(self.frameworks[:3])}")

        if self.architecture_style != "Unknown":
            parts.append(f"🏗️ {self.architecture_style}")

        return " • ".join(parts) if parts else "Project analysis pending"


class ProjectAnalyzer:
    """Analyzes project structure and technology stack."""

    # Project type indicators
    PROJECT_TYPE_INDICATORS = {
        "Web Application": {
            "files": ["index.html", "app.tsx", "app.jsx", "App.vue", "pages/", "views/"],
            "packages": ["react", "vue", "angular", "svelte", "next", "nuxt"],
            "weight": 1.0,
        },
        "REST API": {
            "files": ["routes/", "api/", "endpoints/", "controllers/"],
            "packages": ["express", "fastapi", "flask", "django-rest-framework", "gin", "echo"],
            "patterns": [r"@app\.(get|post|put|delete)", r"router\.(get|post|put|delete)"],
            "weight": 1.0,
        },
        "CLI Tool": {
            "files": ["cli.py", "main.py", "__main__.py", "bin/", "cmd/"],
            "packages": ["click", "argparse", "typer", "commander", "cobra"],
            "patterns": [r"@click\.command", r"argparse\.ArgumentParser", r"if __name__"],
            "weight": 0.9,
        },
        "Library/Package": {
            "files": ["setup.py", "pyproject.toml", "package.json", "Cargo.toml"],
            "patterns": [r"from setuptools import", r'"main":\s*"'],
            "weight": 0.8,
        },
        "Mobile App": {
            "files": ["App.js", "android/", "ios/", "lib/main.dart"],
            "packages": ["react-native", "flutter", "expo", "ionic"],
            "weight": 1.0,
        },
        "Desktop Application": {
            "files": ["main.js", "electron.js", "preload.js"],
            "packages": ["electron", "tauri", "pyqt", "tkinter"],
            "weight": 1.0,
        },
        "Microservice": {
            "files": ["docker-compose.yml", "kubernetes/", "k8s/", "helm/"],
            "packages": ["grpc", "protobuf", "kafka", "rabbitmq"],
            "weight": 0.9,
        },
    }

    # Framework detection patterns
    FRAMEWORK_INDICATORS = {
        # Frontend
        "React": {"packages": ["react", "react-dom"], "files": ["jsx", "tsx"], "category": "frontend"},
        "Vue.js": {"packages": ["vue"], "files": [".vue"], "category": "frontend"},
        "Angular": {"packages": ["@angular/core"], "files": ["angular.json"], "category": "frontend"},
        "Svelte": {"packages": ["svelte"], "files": [".svelte"], "category": "frontend"},
        "Next.js": {"packages": ["next"], "files": ["next.config.js"], "category": "frontend"},
        "Nuxt": {"packages": ["nuxt"], "files": ["nuxt.config.js"], "category": "frontend"},
        # Backend Python
        "FastAPI": {"packages": ["fastapi"], "patterns": [r"from fastapi"], "category": "backend"},
        "Django": {"packages": ["django"], "files": ["manage.py", "settings.py"], "category": "backend"},
        "Flask": {"packages": ["flask"], "patterns": [r"from flask"], "category": "backend"},
        "Tornado": {"packages": ["tornado"], "category": "backend"},
        # Backend Node.js
        "Express": {"packages": ["express"], "patterns": [r"express\(\)"], "category": "backend"},
        "NestJS": {"packages": ["@nestjs/core"], "category": "backend"},
        "Koa": {"packages": ["koa"], "category": "backend"},
        "Hono": {"packages": ["hono"], "category": "backend"},
        # Backend Other
        "Spring Boot": {"files": ["pom.xml", "build.gradle"], "patterns": [r"@SpringBootApplication"], "category": "backend"},
        "Gin": {"packages": ["github.com/gin-gonic/gin"], "category": "backend"},
        "Echo": {"packages": ["github.com/labstack/echo"], "category": "backend"},
        "Actix": {"packages": ["actix-web"], "category": "backend"},
        "Rocket": {"packages": ["rocket"], "category": "backend"},
    }

    # Database indicators
    DATABASE_INDICATORS = {
        "PostgreSQL": {"packages": ["psycopg2", "pg", "postgres", "postgresql"], "patterns": [r"postgres://"]},
        "MySQL": {"packages": ["mysql", "mysql2", "pymysql"], "patterns": [r"mysql://"]},
        "MongoDB": {"packages": ["mongodb", "mongoose", "pymongo"], "patterns": [r"mongodb://"]},
        "Redis": {"packages": ["redis", "ioredis"], "patterns": [r"redis://"]},
        "SQLite": {"packages": ["sqlite3", "better-sqlite3"], "patterns": [r"sqlite://", r"\.sqlite"]},
        "Elasticsearch": {"packages": ["elasticsearch", "@elastic/elasticsearch"]},
        "Supabase": {"packages": ["@supabase/supabase-js", "supabase"]},
        "Firebase": {"packages": ["firebase", "firebase-admin"]},
        "Prisma": {"packages": ["@prisma/client", "prisma"]},
        "TypeORM": {"packages": ["typeorm"]},
        "SQLAlchemy": {"packages": ["sqlalchemy"], "patterns": [r"from sqlalchemy"]},
    }

    # Testing framework indicators
    TESTING_INDICATORS = {
        "pytest": {"packages": ["pytest"], "files": ["pytest.ini", "conftest.py"]},
        "Jest": {"packages": ["jest"], "files": ["jest.config.js"]},
        "Mocha": {"packages": ["mocha"], "files": [".mocharc"]},
        "Vitest": {"packages": ["vitest"], "files": ["vitest.config"]},
        "unittest": {"patterns": [r"import unittest", r"from unittest"]},
        "JUnit": {"patterns": [r"@Test", r"import org.junit"]},
        "Go testing": {"patterns": [r"func Test", r"testing.T"]},
        "RSpec": {"packages": ["rspec"], "files": [".rspec"]},
    }

    # Build tool indicators
    BUILD_TOOL_INDICATORS = {
        "Webpack": {"packages": ["webpack"], "files": ["webpack.config.js"]},
        "Vite": {"packages": ["vite"], "files": ["vite.config.js", "vite.config.ts"]},
        "esbuild": {"packages": ["esbuild"]},
        "Rollup": {"packages": ["rollup"], "files": ["rollup.config.js"]},
        "Parcel": {"packages": ["parcel"]},
        "Turbopack": {"packages": ["turbopack"]},
        "Maven": {"files": ["pom.xml"]},
        "Gradle": {"files": ["build.gradle", "build.gradle.kts"]},
        "Make": {"files": ["Makefile"]},
        "CMake": {"files": ["CMakeLists.txt"]},
        "Cargo": {"files": ["Cargo.toml"]},
    }

    # Entry point patterns
    ENTRY_POINT_PATTERNS = [
        ("main.py", "Python main entry"),
        ("__main__.py", "Python package entry"),
        ("cli.py", "CLI entry point"),
        ("app.py", "Application entry"),
        ("server.py", "Server entry"),
        ("index.ts", "TypeScript entry"),
        ("index.js", "JavaScript entry"),
        ("main.ts", "TypeScript main"),
        ("main.js", "JavaScript main"),
        ("main.go", "Go main"),
        ("main.rs", "Rust main"),
        ("Main.java", "Java main"),
        ("Program.cs", "C# main"),
    ]

    # Directory purpose mapping
    DIRECTORY_PURPOSES = {
        "src": "Source code",
        "lib": "Library code",
        "app": "Application code",
        "api": "API endpoints",
        "routes": "Route definitions",
        "controllers": "Controller logic",
        "models": "Data models",
        "views": "View templates",
        "components": "UI components",
        "pages": "Page components",
        "services": "Service layer",
        "utils": "Utility functions",
        "helpers": "Helper functions",
        "middleware": "Middleware",
        "tests": "Test files",
        "test": "Test files",
        "__tests__": "Test files",
        "spec": "Test specifications",
        "config": "Configuration",
        "configs": "Configuration",
        "static": "Static assets",
        "public": "Public assets",
        "assets": "Assets",
        "styles": "Stylesheets",
        "css": "CSS styles",
        "docs": "Documentation",
        "scripts": "Scripts",
        "bin": "Binary/executables",
        "cmd": "Commands",
        "pkg": "Go packages",
        "internal": "Internal packages",
    }

    def __init__(self, root_path: Path):
        """Initialize the analyzer with a root path."""
        self.root_path = Path(root_path)
        self._files_cache: Optional[List[str]] = None
        self._package_cache: Dict[str, Set[str]] = {}

    def analyze(self, stats: Any) -> ProjectIntelligence:
        """
        Analyze the project and return intelligence summary.

        Args:
            stats: IndexStats object with indexed file information

        Returns:
            ProjectIntelligence with comprehensive analysis
        """
        intelligence = ProjectIntelligence()

        # Get indexed files from stats
        indexed_files = getattr(stats, 'indexed_files', [])
        files_by_language = getattr(stats, 'files_by_language', {})
        files_by_directory = getattr(stats, 'files_by_directory', {})

        # Detect all aspects
        self._detect_project_type(intelligence, indexed_files)
        self._detect_frameworks(intelligence, indexed_files)
        self._detect_architecture(intelligence, indexed_files, files_by_directory)
        self._analyze_tech_stack(intelligence, files_by_language)
        self._detect_databases(intelligence, indexed_files)
        self._detect_testing(intelligence, indexed_files)
        self._detect_build_tools(intelligence, indexed_files)
        self._extract_insights(intelligence, indexed_files, files_by_directory)
        self._detect_features(intelligence, indexed_files)

        return intelligence

    def _get_all_files(self) -> List[str]:
        """Get all files in the project (cached)."""
        if self._files_cache is None:
            self._files_cache = []
            for item in self.root_path.rglob("*"):
                if item.is_file():
                    try:
                        rel_path = str(item.relative_to(self.root_path))
                        self._files_cache.append(rel_path)
                    except ValueError:
                        pass
        return self._files_cache

    def _read_package_file(self, filename: str) -> Dict[str, Any]:
        """Read and parse a package file (package.json, pyproject.toml, etc.)."""
        file_path = self.root_path / filename
        if not file_path.exists():
            return {}
        try:
            content = file_path.read_text(encoding='utf-8', errors='ignore')
            if filename.endswith('.json'):
                return json.loads(content)
            elif filename.endswith('.toml'):
                # Simple TOML parsing for dependencies
                deps = {}
                in_deps = False
                for line in content.split('\n'):
                    if '[' in line and 'dependencies' in line.lower():
                        in_deps = True
                    elif line.startswith('[') and in_deps:
                        in_deps = False
                    elif in_deps and '=' in line:
                        pkg = line.split('=')[0].strip().strip('"').strip("'")
                        if pkg:
                            deps[pkg] = True
                return {"dependencies": deps}
        except Exception:
            pass
        return {}

    def _get_packages(self) -> Set[str]:
        """Get all package dependencies."""
        if not self._package_cache:
            packages = set()

            # Check package.json
            pkg_json = self._read_package_file("package.json")
            if pkg_json:
                packages.update(pkg_json.get("dependencies", {}).keys())
                packages.update(pkg_json.get("devDependencies", {}).keys())

            # Check pyproject.toml
            pyproject = self._read_package_file("pyproject.toml")
            if pyproject:
                packages.update(pyproject.get("dependencies", {}).keys())

            # Check requirements.txt
            req_path = self.root_path / "requirements.txt"
            if req_path.exists():
                try:
                    content = req_path.read_text()
                    for line in content.split('\n'):
                        line = line.strip()
                        if line and not line.startswith('#'):
                            pkg = re.split(r'[<>=!~\[]', line)[0].strip()
                            if pkg:
                                packages.add(pkg.lower())
                except Exception:
                    pass

            # Check go.mod
            go_mod = self.root_path / "go.mod"
            if go_mod.exists():
                try:
                    content = go_mod.read_text()
                    for match in re.finditer(r'^\s*([a-zA-Z0-9./-]+)\s+v', content, re.MULTILINE):
                        packages.add(match.group(1))
                except Exception:
                    pass

            # Check Cargo.toml
            cargo = self._read_package_file("Cargo.toml")
            if cargo:
                packages.update(cargo.get("dependencies", {}).keys())

            self._package_cache = {"all": packages}

        return self._package_cache.get("all", set())


    def _detect_project_type(self, intelligence: ProjectIntelligence, indexed_files: List[str]):
        """Detect the project type based on files and packages."""
        packages = self._get_packages()
        all_files = self._get_all_files()
        scores: Dict[str, Tuple[float, List[str]]] = {}

        for project_type, indicators in self.PROJECT_TYPE_INDICATORS.items():
            score = 0.0
            found_indicators = []

            # Check for indicator files
            for file_pattern in indicators.get("files", []):
                for f in all_files:
                    if file_pattern.endswith('/'):
                        if file_pattern.rstrip('/') in f.split('/'):
                            score += 0.3
                            found_indicators.append(f"dir:{file_pattern}")
                            break
                    elif file_pattern in f:
                        score += 0.4
                        found_indicators.append(f"file:{file_pattern}")
                        break

            # Check for packages
            for pkg in indicators.get("packages", []):
                if pkg.lower() in packages or any(pkg.lower() in p.lower() for p in packages):
                    score += 0.5
                    found_indicators.append(f"pkg:{pkg}")

            # Check patterns in indexed files (sample)
            for pattern in indicators.get("patterns", []):
                for f in indexed_files[:50]:  # Sample first 50 files
                    try:
                        file_path = self.root_path / f
                        if file_path.exists():
                            content = file_path.read_text(errors='ignore')[:5000]
                            if re.search(pattern, content):
                                score += 0.3
                                found_indicators.append(f"pattern:{pattern[:20]}")
                                break
                    except Exception:
                        pass

            if score > 0:
                weight = indicators.get("weight", 1.0)
                scores[project_type] = (score * weight, found_indicators)

        # Select highest scoring type
        if scores:
            best_type = max(scores.items(), key=lambda x: x[1][0])
            intelligence.project_type = best_type[0]
            intelligence.project_type_confidence = min(best_type[1][0] / 2.0, 1.0)
            intelligence.project_type_indicators = best_type[1][1]

    def _detect_frameworks(self, intelligence: ProjectIntelligence, indexed_files: List[str]):
        """Detect frameworks used in the project."""
        packages = self._get_packages()
        all_files = self._get_all_files()

        for framework, indicators in self.FRAMEWORK_INDICATORS.items():
            detected = False

            # Check packages
            for pkg in indicators.get("packages", []):
                if pkg.lower() in packages or any(pkg.lower() in p.lower() for p in packages):
                    detected = True
                    break

            # Check files
            if not detected:
                for file_pattern in indicators.get("files", []):
                    for f in all_files:
                        if file_pattern in f:
                            detected = True
                            break
                    if detected:
                        break

            if detected:
                intelligence.frameworks.append(framework)
                category = indicators.get("category", "")
                if category == "frontend" and framework not in intelligence.frontend_technologies:
                    intelligence.frontend_technologies.append(framework)
                elif category == "backend" and framework not in intelligence.backend_technologies:
                    intelligence.backend_technologies.append(framework)

    def _detect_architecture(self, intelligence: ProjectIntelligence, indexed_files: List[str],
                            files_by_directory: Dict[str, int]):
        """Detect architecture style based on project structure."""
        dir_names = set()
        for f in indexed_files:
            parts = f.split('/')
            if len(parts) > 1:
                dir_names.add(parts[0])

        # Check for MVC pattern
        mvc_indicators = {'models', 'views', 'controllers', 'model', 'view', 'controller'}
        if len(mvc_indicators & dir_names) >= 2:
            intelligence.architecture_style = "MVC"
            intelligence.design_patterns.append("MVC Pattern")

        # Check for microservices
        service_count = sum(1 for d in dir_names if 'service' in d.lower())
        if service_count >= 3 or (self.root_path / "docker-compose.yml").exists():
            intelligence.architecture_style = "Microservices"

        # Check for serverless
        all_files = self._get_all_files()
        if any('serverless.yml' in f or 'sam.yaml' in f or 'lambda' in f.lower() for f in all_files):
            intelligence.architecture_style = "Serverless"

        # Check for monorepo
        if any('packages/' in f or 'apps/' in f for f in indexed_files[:100]):
            intelligence.design_patterns.append("Monorepo")

        # Default to Monolith if nothing detected
        if intelligence.architecture_style == "Unknown" and len(indexed_files) > 10:
            intelligence.architecture_style = "Monolith"


    def _analyze_tech_stack(self, intelligence: ProjectIntelligence, files_by_language: Dict[str, int]):
        """Analyze the technology stack from language breakdown."""
        total_files = sum(files_by_language.values()) if files_by_language else 1

        # Calculate percentages
        for lang, count in files_by_language.items():
            percentage = (count / total_files) * 100
            intelligence.language_percentages[lang] = percentage

        # Determine primary language
        if files_by_language:
            primary = max(files_by_language.items(), key=lambda x: x[1])
            intelligence.primary_language = primary[0].title()

        # Detect package managers from files
        all_files = self._get_all_files()
        pm_files = {
            "npm": "package.json",
            "yarn": "yarn.lock",
            "pnpm": "pnpm-lock.yaml",
            "pip": "requirements.txt",
            "poetry": "poetry.lock",
            "pipenv": "Pipfile",
            "cargo": "Cargo.lock",
            "go mod": "go.sum",
            "maven": "pom.xml",
            "gradle": "build.gradle",
            "composer": "composer.json",
            "bundler": "Gemfile.lock",
        }

        for pm, file in pm_files.items():
            if any(file in f for f in all_files):
                intelligence.package_managers.append(pm)

    def _detect_databases(self, intelligence: ProjectIntelligence, indexed_files: List[str]):
        """Detect database technologies used."""
        packages = self._get_packages()

        for db, indicators in self.DATABASE_INDICATORS.items():
            detected = False

            # Check packages
            for pkg in indicators.get("packages", []):
                if pkg.lower() in packages or any(pkg.lower() in p.lower() for p in packages):
                    detected = True
                    break

            if detected and db not in intelligence.databases:
                intelligence.databases.append(db)

    def _detect_testing(self, intelligence: ProjectIntelligence, indexed_files: List[str]):
        """Detect testing frameworks used."""
        packages = self._get_packages()
        all_files = self._get_all_files()

        for framework, indicators in self.TESTING_INDICATORS.items():
            detected = False

            # Check packages
            for pkg in indicators.get("packages", []):
                if pkg.lower() in packages or any(pkg.lower() in p.lower() for p in packages):
                    detected = True
                    break

            # Check files
            if not detected:
                for file_pattern in indicators.get("files", []):
                    if any(file_pattern in f for f in all_files):
                        detected = True
                        break

            if detected:
                intelligence.testing_frameworks.append(framework)
                intelligence.has_tests = True

    def _detect_build_tools(self, intelligence: ProjectIntelligence, indexed_files: List[str]):
        """Detect build tools used."""
        packages = self._get_packages()
        all_files = self._get_all_files()

        for tool, indicators in self.BUILD_TOOL_INDICATORS.items():
            detected = False

            # Check packages
            for pkg in indicators.get("packages", []):
                if pkg.lower() in packages or any(pkg.lower() in p.lower() for p in packages):
                    detected = True
                    break

            # Check files
            if not detected:
                for file_pattern in indicators.get("files", []):
                    if any(file_pattern in f for f in all_files):
                        detected = True
                        break

            if detected:
                intelligence.build_tools.append(tool)

    def _extract_insights(self, intelligence: ProjectIntelligence, indexed_files: List[str],
                         files_by_directory: Dict[str, int]):
        """Extract codebase insights like entry points and key directories."""
        all_files = self._get_all_files()

        # Find entry points
        for pattern, description in self.ENTRY_POINT_PATTERNS:
            for f in all_files:
                if f.endswith(pattern) or f == pattern:
                    intelligence.entry_points.append(f)
                    break

        # Identify key directories with purposes
        seen_dirs = set()
        for f in indexed_files:
            parts = f.split('/')
            if len(parts) > 1:
                top_dir = parts[0]
                if top_dir not in seen_dirs:
                    seen_dirs.add(top_dir)
                    purpose = self.DIRECTORY_PURPOSES.get(top_dir.lower(), "")
                    if purpose:
                        intelligence.key_directories[top_dir] = purpose

        # Also check second-level directories
        for f in indexed_files[:200]:
            parts = f.split('/')
            if len(parts) > 2:
                sub_dir = parts[1]
                if sub_dir not in intelligence.key_directories:
                    purpose = self.DIRECTORY_PURPOSES.get(sub_dir.lower(), "")
                    if purpose:
                        intelligence.key_directories[sub_dir] = purpose

        # Find config files
        config_patterns = [
            ".env", ".env.example", "config.json", "config.yaml", "config.yml",
            "settings.py", "settings.json", ".eslintrc", ".prettierrc",
            "tsconfig.json", "webpack.config.js", "vite.config.js",
            "docker-compose.yml", "Dockerfile", ".dockerignore",
            ".gitignore", ".editorconfig", "babel.config.js",
        ]
        for f in all_files:
            filename = f.split('/')[-1]
            if filename in config_patterns or filename.startswith('.'):
                if any(p in filename for p in ['config', 'rc', 'settings', '.env']):
                    if f not in intelligence.config_files:
                        intelligence.config_files.append(f)

    def _detect_features(self, intelligence: ProjectIntelligence, indexed_files: List[str]):
        """Detect additional project features."""
        all_files = self._get_all_files()

        # Has tests
        test_indicators = ['test', 'tests', 'spec', '__tests__', '_test.', '.test.', '.spec.']
        if any(any(t in f.lower() for t in test_indicators) for f in indexed_files):
            intelligence.has_tests = True

        # Has CI/CD
        ci_files = ['.github/workflows', '.gitlab-ci.yml', 'Jenkinsfile', '.circleci',
                   '.travis.yml', 'azure-pipelines.yml', 'bitbucket-pipelines.yml']
        if any(any(ci in f for ci in ci_files) for f in all_files):
            intelligence.has_ci_cd = True

        # Has Docker
        docker_indicators = ['Dockerfile', 'docker-compose', '.dockerignore']
        if any(any(d in f for d in docker_indicators) for f in all_files):
            intelligence.has_docker = True

        # Has documentation
        doc_indicators = ['README', 'docs/', 'documentation/', 'CHANGELOG', 'CONTRIBUTING']
        if any(any(d in f for d in doc_indicators) for f in all_files):
            intelligence.has_documentation = True