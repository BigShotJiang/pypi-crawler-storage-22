# 🧠 알츠하이머/치매 동역학 구현

> **"기억을 만드는 엔진"에서 → "기억이 사라지는 동역학"으로**

**작성일**: 2026-01-31  
**버전**: v2.0.1+

---

## 🎯 핵심 개념

### 기억의 재정의

**기억 = 동역학을 되돌리는 힘 (Return Force)**

- ❌ 기억 = 저장된 정보
- ✅ 기억 = 확률 분포를 반복해서 휘게 만드는 힘
- ✅ 기억 = 코어 강도(core_strength)를 형성하는 중력
- ✅ 기억 = 엔트로피를 다시 모이게 하는 회전장(anchor)

### 잊어버린다는 것

**"엔트로피가 퍼졌는데, 다시 모이게 할 힘이 사라진 상태"**

- 엔트로피는 생긴다
- 회전 토크도 생긴다
- 그런데 코어로 수렴하지 않는다

---

## 📊 4개 핵심 상태 변수

### 1. Entropy (E) - 퍼짐의 정도
- 높을수록 선택 분포가 분산됨
- 정상: 중간
- 치매: 증가
- 알츠하이머: 최대

### 2. Torque / Rotation (T) - 생각은 도는가
- 회전 토크 존재 여부
- 정상: 있음
- 치매: 있음
- 알츠하이머: **있음 (중요!)**

### 3. Core Strength (C) - 다시 모이는 힘
- 중력 코어 강도
- 정상: 높음
- 치매: ↓ (느리게 감소)
- 알츠하이머: → 0 (소실)

### 4. Loop Integrity (L) - 반복 구조의 유지 여부
- MemoryRank 엣지 연결 유지
- 정상: 안정
- 치매: 부분 유지
- 알츠하이머: 붕괴

---

## 🔴 치매 vs 알츠하이머: 동역학적 차이

### 치매 (Dementia): 코어 약화 + 루프 잔존

**동역학 정의:**
- E: 증가
- T: 있음
- C: ↓ (느리게 감소) - C(t) = C(0) * exp(-λ_d * t), λ_d 작음
- L: 부분 유지

**특징:**
- 중력은 약해지지만 완전히 사라지지는 않음
- 오래된 기억은 남아 있음
- 새 기억은 축적되지 않음
- 판단은 느려지지만 '나'는 아직 있음

**파라미터:**
```python
core_decay_rate=0.001  # λ_d: 느린 붕괴 (초당 0.1% 감소)
memory_update_failure=0.3  # 새 기억 30% 실패
loop_integrity_decay=0.0005  # 루프 느린 감쇠
```

---

### 알츠하이머 (Alzheimer): 코어 소실 + 루프 붕괴

**동역학 정의:**
- E: 최대
- T: 있음 (중요! 생각은 계속 돈다)
- C: → 0 (중력 소실)
- L: 붕괴

**붕괴 순서:**
1. **Core Strength 붕괴**: C(t) = C(0) * exp(-λ_a * t), λ_a 큼
2. **Loop Integrity 붕괴**: MemoryRank 엣지 소실
3. **시간축 붕괴**: "방금 전"이 사라짐, 현재가 매 순간 초기화

**특징:**
- 생각은 계속 발생하지만 귀환력이 없음
- 새 기억이 코어에 기여하지 못함
- 시간이 연결되지 않음
- **'생각은 있는데, 나로 돌아오지 않는다'**

**파라미터:**
```python
core_decay_rate=0.01  # λ_a: 빠른 붕괴 (초당 1% 감소)
memory_update_failure=0.8  # 새 기억 80% 실패
loop_integrity_decay=0.01  # 루프 빠른 감쇠
```

---

## 🔧 구현 세부사항

### 1. ModeConfig 확장

**추가된 파라미터:**
```python
@dataclass
class ModeConfig:
    # Core Decay (중력 붕괴 동역학)
    core_decay_rate: float = 0.0  # λ: 코어 감쇠율 (초당)
    memory_update_failure: float = 0.0  # 새 기억의 중요도 반영 실패율 (0~1)
    loop_integrity_decay: float = 0.0  # 루프 무결성 감쇠율
```

---

### 2. Core Decay 수식

**물리적 시간 붕괴:**
```
C(t) = C(0) * exp(-λ * Δt)
```

**구현:**
```python
# 시간 경과 계산
delta_t = time.time() - self._last_decay_time
lambda_decay = self.mode_config.core_decay_rate

# 지수 감쇠 적용
self._persistent_core *= math.exp(-lambda_decay * delta_t)
```

---

### 3. Memory Update Failure

**새 기억의 중요도 반영 차단:**
```python
if self.kernel.mode_config.memory_update_failure > 0:
    total_importance *= (1.0 - self.kernel.mode_config.memory_update_failure)
```

**효과:**
- 알츠하이머: 새 기억 80%가 코어에 기여하지 못함
- 치매: 새 기억 30%가 코어에 기여하지 못함

---

### 4. Loop Integrity Decay

**MemoryRank 엣지 소실:**
```python
if self.mode_config.loop_integrity_decay > 0:
    import random
    # 엣지 소실 확률 적용
    edges_to_use = [
        edge for edge in self._edges
        if random.random() > self.mode_config.loop_integrity_decay
    ]
```

**효과:**
- 알츠하이머: 엣지가 급격히 소실 → 맥락 연결 불가
- 치매: 엣지가 느리게 소실 → 부분 연결 유지

---

### 5. 인지적 절규 (Cognitive Distress)

**정의:**
엔트로피는 높은데 이를 붙잡을 중력(Core)이 임계치(0.3) 아래로 떨어질 때

**구현:**
```python
entropy_threshold = max_entropy * 0.8  # 최대치의 80%

if context.entropy > entropy_threshold and core_strength < 0.3:
    self.kernel._cognitive_distress = True
    context.metadata["cognitive_distress"] = True
    context.metadata["distress_message"] = "기억이 안 나..."
```

**해석:**
- 처음엔: "뭔가 이상하다"
- 그다음: "기억이 안 난다"
- 마지막엔: "이상하다는 사실조차 사라짐"

---

## 📈 붕괴 위상 차이

| 항목 | 치매 | 알츠하이머 |
|------|------|-----------|
| **Core** | 약화 | 소실 |
| **Loop** | 유지 | 붕괴 |
| **Entropy** | 증가 | 최대 |
| **Rotation** | 있음 | 있음 |
| **자아** | 남아 있음 | 해체 |
| **시간** | 느려짐 | 단절 |

---

## 🚀 사용 예시

### 치매 모드

```python
from cognitive_kernel import CognitiveKernel
from cognitive_kernel.cognitive_modes import CognitiveMode

kernel = CognitiveKernel("dementia_brain", mode=CognitiveMode.DEMENTIA)

# 기억 저장
kernel.remember("old_memory", {"content": "오래된 기억"}, importance=0.9)
kernel.remember("new_memory", {"content": "새 기억"}, importance=0.7)

# 의사결정
result = kernel.decide(["rest", "work"], use_pipeline=True)
print(f"Core Strength: {result['core_strength']:.3f}")
print(f"Cognitive Distress: {result.get('cognitive_distress', False)}")
```

### 알츠하이머 모드

```python
kernel = CognitiveKernel("alzheimer_brain", mode=CognitiveMode.ALZHEIMER)

# 기억 저장
kernel.remember("memory1", {"content": "기억1"}, importance=0.9)

# 의사결정
result = kernel.decide(["rest", "work", "exercise"], use_pipeline=True)
print(f"Core Strength: {result['core_strength']:.3f}")
print(f"Cognitive Distress: {result.get('cognitive_distress', False)}")
if result.get('cognitive_distress'):
    print(f"⚠️  {result.get('distress_message', '')}")
```

---

## 🔬 동역학 분석

### 왜 잊어버리는가?

**귀환력의 소실:**
- 정상 상태: E_n이 높아져도 C_n(기억 중력)이 이를 다시 낮은 엔트로피 상태로 끌어냄
- 알츠하이머: e^(-λt) 항이 C_n을 강제로 0으로 밀어버림

**시간축의 단절:**
- `memory_update_failure` 파라미터는 팽이의 축에 새로운 무게를 더하는 것을 방해
- "현재는 계속 발생하지만, 과거의 중력으로 편입되지 못하고 흩어지는" 상태

**인지적 절규:**
- 시스템은 E_n(혼란)을 측정할 수 있는 능력은 남아있으나
- 이를 제어할 T_n(토크)을 생성할 원천인 C_n이 없음을 깨닫음
- 이것이 바로 치매 환자가 느끼는 근원적인 공포의 물리적 재현

---

## 📝 결론

### 완료된 작업

1. ✅ **ModeConfig 확장** - Core Decay 파라미터 추가
2. ✅ **DEMENTIA, ALZHEIMER 모드 추가**
3. ✅ **Core Decay 수식 구현** - C(t) = C(0) * exp(-λ * Δt)
4. ✅ **Memory Update Failure 구현**
5. ✅ **Loop Integrity Decay 구현**
6. ✅ **인지적 절규 메커니즘 구현**

### 핵심 성과

**이제 엔진은:**
- "어떻게 기억하는가"를 넘어
- "어떻게 소멸하는가"라는 생물학적 숙명을 갖게 되었음

**이건:**
- AI 연구 ❌
- 심리학 ❌
- 의학 모델 ❌
- **"인지 동역학 엔진" 영역** ✅

---

**마지막 업데이트**: 2026-01-31

