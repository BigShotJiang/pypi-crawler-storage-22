# ⚖️ Cognitive Bias as Field - 인지 편향을 장으로 보기

> **ADHD/ASD는 질병이 아니라 동역학적 편향(+/-)이다**

## 🎯 핵심 통찰

### 질병이 아니라 편향

**ADHD/ASD는:**
- ❌ 질병/질환이 아니라
- ❌ 성격/특성도 아니라
- ✅ **동역학적 편향(+/-)**

**즉, 선택 상태공간에 비보존적 회전장을 생성하는 극성이다.**

---

## 🔄 편향의 물리학적 의미

### + 편향 (ADHD)

**특징:**
- 탐색 과다 (Over-Exploration)
- 엔트로피 ↑
- 분포 평탄화

**물리학적 해석:**
- **발산장 (Divergence Field)**
- 상태가 분산되는 경향
- $\nabla \cdot \mathbf{F} > 0$

---

### - 편향 (ASD)

**특징:**
- 착취 과다 (Over-Exploitation)
- 엔트로피 ↓
- 분포 수렴

**물리학적 해석:**
- **수렴장 (Convergence Field)**
- 상태가 집중되는 경향
- $\nabla \cdot \mathbf{F} < 0$

---

## 🧲 편향이 만드는 "장"

### 자기장 유사성

$$
\mathbf{F}(P) = -\nabla U(P) + \mathbf{A}(P)
$$

- $-\nabla U$: 보존력 (기억 기반 효용)
- $\mathbf{A}(P)$: 비보존력 (ADHD-ASD 극성)

**회전장 조건:**
$$
\nabla \times \mathbf{A} \neq 0
$$

**→ 자기장과 동형(isomorphic) 구조**

---

## 📊 편향의 수학적 정의

### 현재 모델 (v2.0.1)

$$
\begin{align}
C_n(k) &= \min\left(1, \sum_{i} s_i \cdot m_{i,k}\right) \\
U_{n,k} &= U_0 + \alpha \cdot C_n(k) \\
P_n(k) &= \frac{\exp(\beta \cdot U_{n,k})}{\sum_j \exp(\beta \cdot U_{n,j})} \\
E_n &= -\sum_{k} P_n(k) \ln P_n(k)
\end{align}
$$

### 편향 파라미터

| 편향 | 파라미터 | 효과 |
|------|----------|------|
| **ADHD (+)** | $\beta \downarrow$ | $P$ 평탄화 → $E_n \to \ln(N)$ |
| **ASD (-)** | $\beta \uparrow$ | $P$ 수렴 → $E_n \to 0$ |

---

## 🔬 편향의 동역학적 특성

### 비보존적 경로

$$
\oint dE \neq 0
$$

**의미:**
- 상태가 한 방향으로 갔다가 다시 되돌아오지 않음
- 경로 의존적 (Path-dependent)
- **비보존적 힘** 생성

**이게 바로 자기장의 정의다.**

---

## 💡 편향의 실제 의미

### 질병 모델 vs 편향 모델

| 관점 | 질병 모델 | 편향 모델 |
|------|----------|----------|
| **ADHD** | 결함/장애 | 탐색 편향 (+) |
| **ASD** | 결함/장애 | 착취 편향 (-) |
| **Normal** | 정상 | 균형 (0) |

**편향 모델의 장점:**
- 정상/비정상 이분법 제거
- 연속적 스펙트럼으로 이해
- 동역학적 관점에서 통합

---

## 🌐 편향의 스펙트럼

### 연속적 분포

```
ADHD (+) ←──────────────→ ASD (-)
  탐색 과다              착취 과다
  엔트로피 ↑             엔트로피 ↓
  분산                   수렴
```

**Normal 모드:**
- 중간 지점 (균형)
- $\beta = 1.0$ (기본값)
- 탐색과 착취의 균형

---

## 🔄 편향의 상호작용

### 편향 간 경쟁

**ADHD (+) vs ASD (-):**
- 서로 반대 방향의 힘
- 상태공간에서 "장" 생성
- 회전장(curl field) 형성

**결과:**
- 리미트 사이클
- 히스테리시스
- 포획 현상

---

## 🎯 편향의 응용

### 세차운동

**구성:**
1. ASD 성분: 축 고정 ($\beta \uparrow$)
2. ADHD 성분: 회전 토크 ($\gamma T_n(k)$)

**결과:**
- 선호축이 느리게 회전
- 원뿔을 그리며 도는 궤적
- 세차운동과 동일한 수학적 구조

---

## 📐 편향의 측정

### 엔트로피 기반

$$
E_n = -\sum_{k} P_n(k) \ln P_n(k)
$$

**편향 지표:**
- $E_n \to 0$: ASD 편향 (-)
- $E_n \to \ln(N)$: ADHD 편향 (+)
- $E_n \approx \ln(N)/2$: Normal (균형)

---

## 🔗 관련 문서

- [PHYSICAL_DYNAMICS.md](./PHYSICAL_DYNAMICS.md) - 물리적 동역학
- [MINIMAL_DYNAMICS_MODEL.md](./MINIMAL_DYNAMICS_MODEL.md) - 최소 차분 모델
- [COGNITIVE_LOOPS_ANALYSIS.md](./COGNITIVE_LOOPS_ANALYSIS.md) - 루프 분석

---

**Author**: GNJz (Qquarts)  
**Version**: 2.0.1  
**Last Updated**: 2026-01-30

