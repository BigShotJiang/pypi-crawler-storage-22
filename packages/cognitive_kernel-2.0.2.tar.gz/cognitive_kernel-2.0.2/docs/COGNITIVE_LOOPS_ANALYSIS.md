# 🔄 Cognitive Loops Analysis - 인지 루프 분석

> **ADHD(+) ↔ ASD(-) 축 안에서 발생할 수 있는 동역학적 루프와 질환 매핑**

## ⚠️ 중요 고지

```
⚠️ 연구 및 실험 도구입니다.
   실제 뇌의 완전한 모델이 아니며, 임상 진단 도구가 아닙니다.

📌 This is a computational psychiatry-style simulator.
   It explores state space (disorders/abilities/situations) through
   loop/parameter combinations, not disease engines.
```

---

## 🎯 핵심 개념

### ADHD/ASD는 "질환 엔진"이 아님

**현재 구조:**
- ADHD/ASD는 **같은 7개 엔진을 다른 파라미터로 돌리는 모드 프리셋**
- 인지 동역학의 극단(탐색↔착취)을 만들기 위한 설정

**ADHD 모드(+) = 탐색 과다 (Over-Exploration)**
- 시스템을 탐색 쪽으로 밀어냄

**ASD 모드(-) = 착취 과다 (Over-Exploitation)**
- 시스템을 착취 쪽으로 밀어냄

---

## 🔄 5가지 핵심 루프

### (A) 탐색-착취 루프 (PFC ↔ BasalGanglia)

**구조:**
```
PFC (의사결정) ↔ BasalGanglia (습관/강화학습)
```

**파라미터 레버:**
- PFC: `decision_temperature` (β)
- BG: `tau` (탐색 온도), `impulsivity`, `patience`

**동역학:**
- **탐색 과다 쪽 (ADHD)**: 
  - `decision_temperature↓` → 선택 확률 분산↑
  - `tau↑`, `impulsivity↑` → 새 행동 시도/전환↑
  - 같은 상황에서도 행동이 자주 바뀜

- **착취 과다 쪽 (ASD)**:
  - `decision_temperature↑` → 선택 확률 수렴↑
  - `tau↓`, `patience↑` → 루틴 고착/전환 비용 과대

**증상/현상 후보:**
- 탐색 과다: 산만/충동/전환 과다 (ADHD 성향)
- 착취 과다: 루틴 고착/전환 비용 과대 (ASD 성향)

---

### (B) 기억-행동 결합 루프 (Panorama → MemoryRank → PFC)

**구조:**
```
Panorama (시간축 기억) → MemoryRank (중요도 랭킹) → PFC (의사결정)
```

**v2.0.1 핵심 구현:**
```python
expected_reward = 0.5 + α * memory_relevance
# α = 0.5 (기억 영향 계수)
# memory_relevance = Σ(importance_i × match_score_i)
```

**동역학:**
- 특정 기억 패턴(예: "red")이 특정 행동(`choose_red`)의 효용을 올림
- **패턴 고착 = 기억-행동 결합** 발생

**증상/현상 후보:**
- 특정 키워드/단서에 행동이 고착 ("의미 기반 습관")
- 기억이 강하게 한 행동을 밀어주면, "새 옵션"이 들어와도 바꾸기 어려움
- **패턴 고착 (ASD)**

**주의:**
- 현재 `relevance`는 키워드 포함 여부 기반
- 실제 의미/정서/맥락 고착(임상적 의미의 fixation)과는 다름
- 하지만 "고착이 생길 수 있는 구조"는 만들어짐

---

### (C) 입력 게이팅-과부하 루프 (Thalamus → WorkingMemory/PFC)

**구조:**
```
Thalamus (입력 필터링) → WorkingMemory/PFC (처리)
```

**설계상 ASD에서 핵심이 될 수 있는 루프:**
- 감각 과부하/주의 과부하는 "게이팅 실패" 관점에서 설명됨
- 자폐를 베이지안/예측부호화로 설명하는 이론과 일치

**현재 코드 상태:**
- ❌ `thalamus` 엔진은 초기화되지만
- ❌ `remember()`가 thalamus를 통과하지 않음
- ❌ "입력 필터링으로 인한 과부하"는 아직 동역학으로 미구현

**향후 구현 가능:**
```python
def remember(self, ...):
    # Thalamus 게이팅
    filtered_input = self.thalamus.gate(input, threshold=self.mode_config.gate_threshold)
    
    # ASD: gate_threshold=0.0 → 모든 입력 통과 → 과부하
    # ADHD: gate_threshold=0.1 → 많은 입력 통과 → 산만
```

**증상/현상 후보:**
- 감각 과부하 (ASD)
- 주의 과부하
- 예측 오차 기반 스트레스 폭증

---

### (D) 습관 고착 루프 (BasalGanglia 중심)

**구조:**
```
BasalGanglia (습관 학습) → PFC (의사결정)
```

**동역학:**
- `context`가 주어지고 BG Q-table이 특정 행동을 계속 밀면
- PFC 결정보다 "습관 제안"이 강해지는 형태
- 충돌 flag로 관찰 가능

**질환/상태 후보:**
- **강박/강박행동 (OCD)**
  - "goal-directed ↔ habit" 불균형 (습관 쪽 편향)
  - BG habit 선택이 과도해지고 goal-directed가 약해지는 모델

**현재 구현:**
```python
# decide() 메서드
habit_action = self.basal_ganglia.select_action(context, options)
conflict = pfc_result.action.name != habit_action
```

**확장 가능:**
- 습관 강도가 임계값을 넘으면 PFC 결정을 덮어씀
- 강박 행동 시뮬레이션 가능

---

### (E) 보상 민감도/효용 평탄화 루프 (PFC utility landscape)

**구조:**
```
PFC (utility 계산) → 선택 확률
```

**동역학:**
- 모든 옵션의 `expected_reward`가 비슷해지면
- 선택은 "무작위"가 아니라 "무의미/저구동"처럼 보임
- 에너지/스트레스 엔진이 붙으면 더 명확해짐

**질환/상태 후보:**
- **우울/무쾌감 (Anhedonia)**
  - 보상 민감도↓ → 선택이 보상 구배에 덜 반응
  - 결정과학 관점에서 이런 프레임 존재

**현재 구현 가능:**
```python
# 모든 action의 expected_reward가 평탄화
expected_reward = 0.5 + α * memory_relevance
# relevance가 전반적으로 낮으면 → 모든 utility가 비슷
# 또는 risk/effort가 상대적으로 커지면 → 선택이 저구동
```

**확장 가능:**
- Hypothalamus (에너지/스트레스)가 PFC utility에 패널티로 들어가면
- 자연스럽게 우울/무쾌감 재현 가능

---

## 📊 질환 매핑 (루프 기반)

### ADHD 쪽 (+): 탐색 과다 / 전환 과다 / 입력 과다

**파라미터:**
- PFC: `decision_temperature↓` (랜덤성↑)
- BG: `tau↑`, `impulsivity↑`
- Thalamus: `gate_threshold↓`

**루프:**
- (A) 탐색-착취 루프: 탐색 과다
- (C) 입력 게이팅: 입력 과다 (설계상)

**연구 근거:**
- 실제 ADHD를 RL 관점으로 모델링한 연구 흐름 존재

---

### ASD 쪽 (-): 착취 과다 / 루틴 수렴 / 예측-오차 민감

**파라미터:**
- PFC: `decision_temperature↑` (결정론↑)
- BG: `tau↓`, `patience↑`
- Thalamus: `gate_threshold↓` (향후 게이팅 루프)

**루프:**
- (A) 탐색-착취 루프: 착취 과다
- (B) 기억-행동 결합 루프: 패턴 고착 ✅ (v2.0.1 구현)
- (C) 입력 게이팅: 감각 과부하 (향후 구현)

**연구 근거:**
- 자폐를 "예측부호화/베이지안 priors·precision"으로 설명하는 이론 존재

---

### OCD (강박): 습관 루프 과대 + 전환 비용 과대

**파라미터:**
- BG: `habit_threshold↓`, `habit_beta↑`
- PFC: `decision_temperature↑` (결정론↑)

**루프:**
- (D) 습관 고착 루프: BG habit 선택이 과도

**현재 구현 가능:**
```python
# BG habit이 PFC 결정을 덮어쓰는 경우
if habit_strength > habit_threshold:
    action = habit_action  # PFC 결정 무시
```

**연구 근거:**
- "goal-directed ↔ habit" 불균형 모델 계열 존재

---

### 정신증/조현 스펙트럼: 살리언스(의미/중요도) 부여 비정상

**파라미터:**
- MemoryRank: `damping↑`, `local_weight_boost↑`
- Amygdala: `novelty_sensitivity↑↑`

**루프:**
- (B) 기억-행동 결합 루프: 중요도 왜곡
- Amygdala → MemoryRank → PFC: 감정 가중 과도

**현재 구현 가능:**
```python
# MemoryRank 중요도가 비정상적으로 높아짐
# Amygdala 감정이 utility에 과도하게 반영
expected_reward = 0.5 + α * memory_relevance + β * emotion_intensity
```

**연구 근거:**
- 'aberrant salience' 가설 (도파민/동기 salience)

---

### 우울/무쾌감: 보상 민감도↓ → 선택이 보상 구배에 덜 반응

**파라미터:**
- PFC: 모든 `expected_reward` 평탄화
- Hypothalamus: `stress_baseline↑`, `energy↓`

**루프:**
- (E) 보상 민감도/효용 평탄화 루프

**현재 구현 가능:**
```python
# 모든 action의 utility가 비슷해짐
expected_reward = 0.5 + α * memory_relevance
# relevance가 전반적으로 낮으면 → 평탄화

# 또는 Hypothalamus 패널티
utility = expected_reward - stress_penalty - energy_cost
```

**연구 근거:**
- 결정과학 관점에서 우울 프레임 존재

---

## 🔬 루프 조합 시나리오

### 시나리오 1: ADHD + 기억 기반 산만함

**루프 조합:**
- (A) 탐색-착취 루프: 탐색 과다
- (B) 기억-행동 결합 루프: 기억 영향 있지만 분산

**결과:**
- 기억은 영향을 주지만, 낮은 온도로 인해 선택이 분산됨
- choose_red 30% (기억 영향 + 산만함)

---

### 시나리오 2: ASD + 패턴 고착

**루프 조합:**
- (A) 탐색-착취 루프: 착취 과다
- (B) 기억-행동 결합 루프: 기억 기반 패턴 고착 ✅

**결과:**
- 기억 영향 + 높은 온도로 인해 선택이 수렴됨
- choose_red 90% (패턴 고착)

---

### 시나리오 3: OCD (향후 구현)

**루프 조합:**
- (D) 습관 고착 루프: BG habit 과도
- (A) 탐색-착취 루프: 착취 과다

**예상 결과:**
- 습관이 PFC 결정을 덮어씀
- 같은 행동 반복 (강박)

---

### 시나리오 4: 우울/무쾌감 (향후 구현)

**루프 조합:**
- (E) 보상 민감도/효용 평탄화 루프
- Hypothalamus: 에너지↓, 스트레스↑

**예상 결과:**
- 모든 선택의 utility가 비슷
- 선택이 저구동/무의미

---

## 📐 수식 정리

### 루프 (A): 탐색-착취

$$
P(a) = \text{softmax}(Q(s,a) / \tau) \quad \text{(BasalGanglia)}
$$

$$
P(i) = \exp(\beta \times U_i) / \sum \exp(\beta \times U_j) \quad \text{(PFC)}
$$

- $\tau \uparrow$ → 탐색↑ (ADHD)
- $\tau \downarrow$ → 착취↑ (ASD)
- $\beta \uparrow$ → 결정론↑ (ASD)
- $\beta \downarrow$ → 무작위↑ (ADHD)

---

### 루프 (B): 기억-행동 결합

$$
U_i = U_{base} + \alpha \cdot \sum_{j} (r_j \times m_{ij})
$$

- $r_j$: MemoryRank 중요도
- $m_{ij}$: 옵션-기억 매칭 점수
- $\alpha = 0.5$: 기억 영향 계수

**v2.0.1 구현 완료** ✅

---

### 루프 (C): 입력 게이팅 (향후 구현)

$$
I_{filtered} = \begin{cases}
I & \text{if } I > \theta \\
0 & \text{otherwise}
\end{cases}
$$

- $\theta$: `gate_threshold`
- ASD: $\theta = 0.0$ → 모든 입력 통과 → 과부하
- ADHD: $\theta = 0.1$ → 많은 입력 통과 → 산만

**현재 미구현** ❌

---

### 루프 (D): 습관 고착

$$
H(s,a) = H(s,a) + \beta \cdot (\text{success} - H(s,a))
$$

$$
\text{action} = \begin{cases}
\text{habit\_action} & \text{if } H > H_{threshold} \\
\text{pfc\_action} & \text{otherwise}
\end{cases}
$$

**현재 부분 구현** (충돌 flag만)

---

### 루프 (E): 보상 민감도 평탄화

$$
U_i = \text{expected\_reward}_i - \text{stress\_penalty} - \text{energy\_cost}
$$

**모든 $U_i$가 비슷해지면** → 선택이 저구동

**현재 구현 가능** (Hypothalamus 통합 시)

---

## 🎯 현재 구현 상태

| 루프 | 구현 상태 | 비고 |
|------|----------|------|
| (A) 탐색-착취 | ✅ 완료 | PFC + BG 파라미터 |
| (B) 기억-행동 결합 | ✅ 완료 | v2.0.1 구현 |
| (C) 입력 게이팅 | ❌ 미구현 | Thalamus 게이팅 루프 없음 |
| (D) 습관 고착 | ⚠️ 부분 | 충돌 flag만, 덮어쓰기 미구현 |
| (E) 보상 민감도 | ⚠️ 가능 | Hypothalamus 통합 필요 |

---

## 🚀 향후 확장 가능성

### 1. Thalamus 게이팅 루프 구현

```python
def remember(self, ...):
    # Thalamus 게이팅
    filtered = self.thalamus.gate(input, self.mode_config.gate_threshold)
    if filtered:
        # Panorama에 저장
        ...
```

### 2. 습관 덮어쓰기 구현

```python
def decide(self, ...):
    habit_action = self.basal_ganglia.select_action(...)
    habit_strength = self.basal_ganglia.get_habit_strength(...)
    
    if habit_strength > self.config.habit_override_threshold:
        return habit_action  # PFC 결정 무시
```

### 3. Hypothalamus 통합

```python
def decide(self, ...):
    # 에너지/스트레스 패널티
    stress_penalty = self.hypothalamus.get_stress() * 0.3
    energy_cost = (1.0 - self.hypothalamus.get_energy()) * 0.2
    
    utility = expected_reward - stress_penalty - energy_cost
```

---

## 📚 참고 문헌

1. **Exploration vs Exploitation**: Reinforcement Learning
2. **Predictive Coding Theory**: ASD의 신경과학적 모델
3. **Aberrant Salience Hypothesis**: 정신증/조현 스펙트럼
4. **Goal-directed vs Habit**: OCD 모델
5. **Reward Sensitivity**: 우울/무쾌감 모델

---

## 🔗 관련 문서

- [COGNITIVE_STATES.md](./COGNITIVE_STATES.md) - 모드별 상세 설명
- [COGNITIVE_DYSFUNCTION.md](./COGNITIVE_DYSFUNCTION.md) - 시뮬레이션 문서
- [COGNITIVE_STATES_HONEST.md](./COGNITIVE_STATES_HONEST.md) - 정직한 기술 문서

---

**Author**: GNJz (Qquarts)  
**Version**: 2.0.1  
**Last Updated**: 2026-01-30

