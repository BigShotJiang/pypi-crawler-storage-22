# 치매/알츠하이머 구현 설명

> **시간축 분리 동역학을 통한 기억 붕괴 모델링**

**작성일**: 2026-01-31  
**버전**: v2.0.2

---

## 🧠 핵심 개념

### 기억의 정의

이 엔진에서 **기억은 단순한 데이터가 아니라 "엔트로피를 다시 모이게 하는 귀환력(Return Force)"**입니다.

```
기억 = 확률 분포를 반복해서 휘게 만드는 힘
기억 = 코어 강도(core_strength)를 형성하는 중력
기억 = 엔트로피를 다시 모이게 하는 회전장(anchor)
```

### 잊어버린다는 것

**알츠하이머/치매는 정보 삭제 문제가 아닙니다.**

엔진 언어로 정확히 말하면:

> "엔트로피가 퍼졌는데, 다시 모이게 할 힘이 사라진 상태"

즉,
- 엔트로피는 생긴다 ✅
- 회전 토크도 생긴다 ✅
- 그런데 코어로 수렴하지 않는다 ❌

---

## 🔬 동역학적 정의

### 치매 (Dementia)

**동역학 정의:**
- **E (엔트로피)**: 증가
- **T (회전)**: 있음
- **C (코어 강도)**: ↓ (느리게 감소)
- **L (루프 무결성)**: 부분 유지

**특징:**
- 중력은 약해지지만 완전히 사라지지는 않음
- 오래된 기억은 남아 있음
- 새 기억은 축적되지 않음
- 판단은 느려지지만 '나'는 아직 있음

**수식:**
```
C(t) = C(0) * exp(-λ_d * t),  λ_d 작음 (0.001)
```

### 알츠하이머 (Alzheimer)

**동역학 정의:**
- **E (엔트로피)**: 최대
- **T (회전)**: 있음 (중요! 생각은 계속 돈다)
- **C (코어 강도)**: → 0 (중력 소실)
- **L (루프 무결성)**: 붕괴

**붕괴 순서:**
1. Core Strength 붕괴: `C(t) = C(0) * exp(-λ_a * t)`, λ_a 큼 (0.01)
2. Loop Integrity 붕괴: MemoryRank 엣지 소실
3. 시간축 붕괴: "방금 전"이 사라짐, 현재가 매 순간 초기화

**특징:**
- 생각은 계속 발생하지만 귀환력이 없음
- 새 기억이 코어에 기여하지 못함
- 시간이 연결되지 않음
- **'생각은 있는데, 나로 돌아오지 않는다'**

---

## ⏰ 시간축 분리 (Time-axis Separation)

### 핵심 아이디어

**치매와 알츠하이머의 차이는 "어떤 기억이 먼저 지워지는가"입니다.**

- **치매**: 최근 기억부터 지워짐 (오래된 기억은 남음)
- **알츠하이머**: 새 기억이 전혀 저장되지 않음 (오래된 기억은 느리게 감쇠)

### 구현 파라미터

```python
# 시간축 분리 파라미터
old_memory_decay_rate: float = 0.0  # 오래된 기억 감쇠율 (초당)
new_memory_decay_rate: float = 0.0  # 새 기억 감쇠율 (초당)
memory_age_threshold: float = 3600.0  # 기억 나이 임계값 (초, 1시간)
```

### 수식

**오래된 기억 감쇠:**
```
importance *= exp(-λ_old * age)
```

**새 기억 감쇠:**
```
importance *= exp(-λ_new * age)
```

**기억 나이 계산:**
```
memory_age = current_time - memory_timestamp
if memory_age > memory_age_threshold:
    # 오래된 기억
    importance *= exp(-old_memory_decay_rate * memory_age)
else:
    # 새 기억
    importance *= exp(-new_memory_decay_rate * memory_age)
```

---

## 📊 구현 상세

### 1. ModeConfig 설정

**치매 모드:**
```python
config = ModeConfig(
    core_decay_rate=0.001,  # λ_d: 느린 붕괴
    memory_update_failure=0.3,  # 새 기억 30% 실패
    loop_integrity_decay=0.0005,  # 루프 느린 감쇠
)
# 시간축 분리
config.old_memory_decay_rate = 0.0001  # 오래된 기억 감쇠율 (느림)
config.new_memory_decay_rate = 0.0  # 새 기억은 정상
config.memory_age_threshold = 3600.0  # 1시간 이상 = 오래된 기억
```

**알츠하이머 모드:**
```python
config = ModeConfig(
    core_decay_rate=0.01,  # λ_a: 빠른 붕괴
    memory_update_failure=0.8,  # 새 기억 80% 실패
    loop_integrity_decay=0.01,  # 루프 빠른 감쇠
)
# 시간축 분리
config.old_memory_decay_rate = 0.0001  # 오래된 기억은 느리게 감쇠
config.new_memory_decay_rate = 0.1  # 새 기억은 매우 빠르게 감쇠 (거의 즉시 소실)
config.memory_age_threshold = 3600.0  # 1시간 이상 = 오래된 기억
```

### 2. Core Strength 계산 (calculate_core_strength)

**위치**: `src/cognitive_kernel/engines/dynamics/dynamics_engine.py`

**로직:**
```python
def calculate_core_strength(self, memories, ...):
    current_time = time.time()
    total_importance = 0.0
    
    for m in memories:
        importance = m.get("importance", 0.0)
        memory_timestamp = m.get("timestamp", current_time)
        memory_age = current_time - memory_timestamp
        
        # 오래된 기억 감쇠 (치매 특성)
        if self.config.old_memory_decay_rate > 0 and memory_age > self.config.memory_age_threshold:
            decay_factor = math.exp(-self.config.old_memory_decay_rate * memory_age)
            importance *= decay_factor
        
        # 새 기억 감쇠 (알츠하이머 특성)
        if self.config.new_memory_decay_rate > 0 and memory_age <= self.config.memory_age_threshold:
            decay_factor = math.exp(-self.config.new_memory_decay_rate * memory_age)
            importance *= decay_factor
        
        total_importance += importance
    
    # 새 기억의 중요도 반영 차단 (알츠하이머)
    if memory_update_failure > 0:
        total_importance *= (1.0 - memory_update_failure)
    
    # Core Decay 적용
    if self.config.core_decay_rate > 0:
        # C(t) = C(0) * exp(-λ * Δt)
        self.state.persistent_core *= math.exp(-lambda_decay * delta_t)
    
    return core_strength
```

---

## 🔄 동작 흐름

### 정상 상태
1. 기억 저장 → `importance` 계산
2. 시간 경과 → `importance` 유지
3. Core Strength 계산 → 높은 값 유지
4. 엔트로피 증가 → Core가 다시 수렴시킴

### 치매 상태
1. 기억 저장 → `importance` 계산
2. 시간 경과 → **오래된 기억 감쇠** (느림)
3. Core Strength 계산 → 점진적 감소
4. 엔트로피 증가 → Core가 약하게 수렴시킴

### 알츠하이머 상태
1. 기억 저장 → `importance` 계산
2. 시간 경과 → **새 기억 즉시 감쇠** (매우 빠름)
3. Core Strength 계산 → 급격한 감소
4. 엔트로피 증가 → Core가 수렴시키지 못함

---

## 📈 차이점 요약

| 항목 | 치매 | 알츠하이머 |
|------|------|------------|
| **Core 약화** | 약화 | 소실 |
| **Loop** | 유지 | 붕괴 |
| **Entropy** | 증가 | 최대 |
| **Rotation** | 있음 | 있음 |
| **자아** | 남아 있음 | 해체 |
| **시간** | 느려짐 | 단절 |
| **오래된 기억 감쇠** | 느림 (0.0001) | 느림 (0.0001) |
| **새 기억 감쇠** | 정상 (0.0) | 매우 빠름 (0.1) |
| **Core Decay Rate** | 느림 (0.001) | 빠름 (0.01) |
| **Memory Update Failure** | 30% | 80% |

---

## 🎯 핵심 인사이트

### "왜 모든 과정을 잊어버리게 되는가?"

**답**: 기억은 과정이 아니라 **귀환력(return force)**이기 때문입니다.

이 엔진에서 기억은:
- ❌ 과정
- ❌ 기록
- ❌ 데이터

**✅ "다시 그 상태로 돌아오게 하는 힘"**

그 힘이 사라지면:
- 생각은 발생함 ✅
- 판단도 발생함 ✅
- 말도 함 ✅
- 하지만 궤도가 남지 않음 ❌

### "자아는 언제까지 자신이 잊고 있음을 아는가?"

**답**: Core Strength가 임계값 아래로 떨어질 때까지

```python
if entropy > threshold and core_strength > ε:
    self._cognitive_distress = True
```

**해석:**
- 처음엔 → "뭔가 이상하다"
- 그다음 → "기억이 안 난다"
- 마지막엔 → "이상하다는 사실조차 사라짐"

**알츠하이머 말기 = distress조차 사라진 상태**

---

## 🔗 관련 파일

- `src/cognitive_kernel/cognitive_modes.py` - ModeConfig 및 프리셋
- `src/cognitive_kernel/engines/dynamics/dynamics_engine.py` - Core Strength 계산
- `src/cognitive_kernel/engines/dynamics/config.py` - 시간축 분리 파라미터
- `src/cognitive_kernel/core.py` - 통합 및 초기화

---

**작성자**: GNJz (Qquarts)  
**작성일**: 2026-01-31

