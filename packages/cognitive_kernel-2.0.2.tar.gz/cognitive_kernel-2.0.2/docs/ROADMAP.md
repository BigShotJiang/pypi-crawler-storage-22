# Cognitive Kernel - Implementation Roadmap

> **Version**: 2.0.0  
> **Date**: 2026-01-29  
> **Status**: ✅ Phase 1~3 완료, v2.0.0 공식 릴리즈

---

## 🎯 프로젝트 원칙

### 핵심 경고

> **"이 아키텍처는 너무 제대로라서, 한 번에 다 구현하려 들면 무너질 수 있다."**

### 실행 원칙

1. **Phase별 엄격한 분리** - 한 번에 하나씩
2. **최소 유효 모델 (Minimum Valid Model)** - 각 엔진의 핵심만 구현
3. **수식 ↔ 코드 일치 검증** - 이론과 구현의 정합성 확인
4. **테스트 우선** - 구현 전 검증 기준 정의

---

## 📊 Phase별 구현 계획

### Phase 1: Core Memory System ✅ 완료

| 모듈 | 핵심 기능 | 수식 | 상태 |
|------|----------|------|------|
| **Panorama** | 시간축 기록 | Exponential Decay | ✅ v1.0.0 |
| **MemoryRank** | 중요도 계산 | PageRank | ✅ v1.0.0 |
| **PFC** | 작업기억 + 결정 | Softmax Utility | ✅ v1.0.0 |

**검증 완료**:
- 수학적 모델 테스트 통과
- 3-엔진 통합 파이프라인 동작 확인

---

### Phase 2: Emotion & Homeostasis ⏳ 검증 중

| 모듈 | 핵심 기능 | 수식 | 상태 |
|------|----------|------|------|
| **Amygdala** | 공포 학습 | Rescorla-Wagner | ⚠️ 검증 필요 |
| **Hypothalamus** | 스트레스/에너지 | HPA ODE | ⚠️ 검증 필요 |
| **Thalamus** | 감각 게이팅 | Salience Filtering | ⚠️ 검증 필요 |

**필요 작업**:
1. 기존 코드 ↔ ARCHITECTURE.md 수식 일치 확인
2. 각 엔진별 단위 테스트 작성
3. Phase 1 엔진과의 인터페이스 검증

---

### Phase 3: Action & Learning 📋 계획됨

| 모듈 | 핵심 기능 | 수식 | 상태 |
|------|----------|------|------|
| **BasalGanglia** | 습관 학습 | TD Learning / Q-Learning | ⚠️ 검증 필요 |

**필요 작업**:
1. Dopamine RPE 수식 구현 확인
2. 습관 형성 임계값 검증
3. PFC → BasalGanglia 인터페이스 정의

---

## 🔬 수식 ↔ 코드 일치 체크리스트

### Amygdala (Rescorla-Wagner)

```
이론: ΔV = α × β × (λ - V)
```

- [ ] `alpha` (CS salience) 파라미터 존재 확인
- [ ] `beta` (US learning rate) 파라미터 존재 확인
- [ ] `lambda_max` (최대 연합 강도) 파라미터 존재 확인
- [ ] 학습 업데이트 함수가 수식과 일치하는지 확인
- [ ] 소거(extinction) 로직 존재 확인

### Hypothalamus (HPA Axis)

```
이론: dC/dt = -k₁ × C + k₂ × S × (1 - C/C_max)
```

- [ ] `k1` (decay rate) 파라미터 존재 확인
- [ ] `k2` (production rate) 파라미터 존재 확인
- [ ] `C_max` (최대 코르티솔) 파라미터 존재 확인
- [ ] 미분 방정식 이산화 구현 확인
- [ ] 스트레스 입력 → 코르티솔 반응 검증

### BasalGanglia (TD Learning)

```
이론: δ = r + γ × V(s') - V(s)
      Q ← Q + α × δ
```

- [ ] `alpha` (learning rate) 파라미터 존재 확인
- [ ] `gamma` (discount factor) 파라미터 존재 확인
- [ ] TD error 계산 함수 확인
- [ ] Q-value 업데이트 함수 확인
- [ ] 습관 강도(habit strength) 추적 확인

### Thalamus (Gating)

```
이론: pass = (salience > threshold) AND (channel_count < max)
```

- [ ] `gate_threshold` 파라미터 존재 확인
- [ ] `max_channels` 파라미터 존재 확인
- [ ] salience 계산 로직 확인
- [ ] 필터링 로직 검증

---

## 📁 v1.0.0 범위 정의

### 포함 (In Scope)

1. **Core Memory Pipeline**
   - Panorama: 이벤트 기록, 범위 쿼리, 에피소드 분할
   - MemoryRank: PageRank 계산, Top-N 추출
   - PFC: 작업기억 (7±2), Softmax 선택, 억제

2. **통합 시뮬레이션**
   - 7개 엔진 연결
   - Normal vs PTSD 시나리오
   - 상태 추적 및 알림

3. **문서**
   - ARCHITECTURE.md (이론적 기반)
   - 수학적 모델 검증 테스트

### 제외 (Out of Scope for v1.0)

1. **고급 기능**
   - 실시간 스트리밍 처리
   - 분산 시스템 지원
   - GPU 가속

2. **추가 엔진**
   - Hippocampus (공간 기억)
   - Cerebellum (운동 학습)
   - Striatum 세분화

3. **응용**
   - 실제 질환 진단 시스템
   - 임상 데이터 연동
   - 의료기기 인증

---

## 🚀 다음 단계 (권장)

### 즉시 (Now)

1. **Phase 2 엔진 검증**
   - Amygdala, Hypothalamus, Thalamus
   - 수식 ↔ 코드 일치 확인
   - 단위 테스트 작성

### 단기 (1-2주)

2. **인터페이스 표준화**
   - 모든 엔진의 입출력 형식 통일
   - Data Contracts 구현

3. **Phase 3 검증**
   - BasalGanglia 수식 확인
   - PFC → BasalGanglia 연동 테스트

### 중기 (1개월)

4. **v1.0.0 릴리즈**
   - 전체 테스트 통과
   - 문서 완성
   - GitHub Release 생성

---

## 📚 참고

- [ARCHITECTURE.md](./ARCHITECTURE.md) - 이론적 기반
- [test_mathematical_models.py](../tests/test_mathematical_models.py) - 수식 검증

---

**Author**: GNJz (Qquarts)  
**License**: MIT

