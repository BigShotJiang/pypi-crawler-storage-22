# Dynamics Engine v2.0.2 PHAM 해시

## 파일별 해시

### config.py
**해시**: b06dd0f38044cd5d9d4ad7cfa19d0fe5b5d8df993480fc48494ddcaff0bcde01
**변경**: 시간축 분리 파라미터 추가

### models.py
**해시**: 30cbd8d64dcd4d2d1731428223402ac1db407cc00a0d7307e1aa22c8baf4675b
**변경**: 변경 없음

### dynamics_engine.py
**해시**: f9a3591353b0768db4ba3d9830dd02835d796a7ec95e6245f13ea23c9fdf7da8
**변경**: CognitiveMode 의존성 제거, 시간축 분리 로직 추가

### __init__.py
**해시**: 2621e4279489ba9ab9cf5b8f518d4f2dfdea3906723d3789f7892cdefbd72d3b
**변경**: 변경 없음

## 전체 디렉토리 해시
**해시**: 0159b137e1ffd5cc26018545afc92f1b0125be894d8c85e9be9a5003f5d148be

**날짜**: 2026-01-31
**버전**: v2.0.2
