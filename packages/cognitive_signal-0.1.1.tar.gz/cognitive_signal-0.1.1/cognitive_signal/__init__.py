"""
cognitive_signal - Orthogonal cognitive signal extraction from journal entries.

Usage:
    from cognitive_signal import SignalDetectionPipeline, JournalEntry

    pipeline = SignalDetectionPipeline()
    entries = [JournalEntry(text="I felt empowered today...", timestamp=datetime.now(), entry_id="1")]
    result = pipeline.process_journal(entries)
"""

from cognitive_signal.models.types import (
    JournalEntry,
    SignalVector,
    TemporalSignal,
    SegmentationOutput,
    ChangePointOutput,
    SemanticChangePoint,
    Phase,
    SignalDetectionOutput,
)
from cognitive_signal.pipeline import SignalDetectionPipeline

__version__ = "0.1.1"

__all__ = [
    "SignalDetectionPipeline",
    "JournalEntry",
    "SignalVector",
    "TemporalSignal",
    "SegmentationOutput",
    "ChangePointOutput",
    "SemanticChangePoint",
    "Phase",
    "SignalDetectionOutput",
    "__version__",
]
