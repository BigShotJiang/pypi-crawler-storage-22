"""Core data types for the signal detection engine."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from cognitive_signal.dissonance.detector import DissonanceVector
    from cognitive_signal.semantic.motion import SemanticMotionOutput


@dataclass(slots=True)
class JournalEntry:
    text: str
    timestamp: datetime
    entry_id: str


@dataclass(slots=True)
class SignalVector:
    embedding: np.ndarray
    valence: float
    arousal: float
    agency: float
    self_focus: float
    social_orientation: float
    action_ratio: float


@dataclass(slots=True)
class TemporalSignal:
    delta: float
    trend: float
    volatility: float
    persistence: float


@dataclass(slots=True)
class SegmentationOutput:
    state_sequence: list[int]
    transition_matrix: np.ndarray
    state_means: np.ndarray
    state_covariances: np.ndarray
    log_likelihood: float


@dataclass(slots=True)
class SemanticChangePoint:
    timestep: int
    distance: float
    method: str


@dataclass(slots=True)
class ChangePointOutput:
    signal_changepoints: dict[str, list[int]]
    semantic_changepoints: list[SemanticChangePoint]
    merged_changepoints: list[int]


@dataclass(slots=True)
class Phase:
    start: int
    end: int
    phase_id: int


@dataclass(slots=True)
class SignalDetectionOutput:
    journal_entries: list[JournalEntry]
    signal_vectors: list[SignalVector]
    dissonance_vectors: list[DissonanceVector]
    temporal_signals: dict[str, list[TemporalSignal]]
    semantic_motion: SemanticMotionOutput
    segmentation: SegmentationOutput
    state_labels: dict[int, str]
    changepoints: ChangePointOutput
    phases: list[Phase]
    _raw_observations: np.ndarray | None = None
    _raw_feature_names: list[str] | None = None
    _raw_processing_seconds: float | None = None
