Functional Tests

    >>> portal = layer['portal']
    >>> from plone.testing.z2 import Browser
    >>> browser = Browser(layer['app'])
    >>> browser.handleErrors = False
    >>> portal_url = portal.absolute_url()
    >>> portal.error_log._ignored_exceptions = ()

Open the demo simple edit form. This form  has a number of lines

    >>> browser.open(portal_url+'/@@demo-collective.z3cform.datagrid')

Make sure that the first row of data is present

    >>> browser.getControl(name='form.widgets.address.0.widgets.address_type:list').value
    ['Work']
    >>> browser.getControl(name='form.widgets.address.0.widgets.line1').value
    'My Office'
    >>> browser.getControl(name='form.widgets.address.0.widgets.line2').value
    'Big Office Block'
    >>> browser.getControl(name='form.widgets.address.0.widgets.city').value
    'Mega City'
    >>> browser.getControl(name='form.widgets.address.0.widgets.country').value
    'The Old Sod'

Make sure that the auto-insert row is present

    >>> browser.getControl(name='form.widgets.address.AA.widgets.address_type:list').value
    ['--NOVALUE--']
    >>> browser.getControl(name='form.widgets.address.AA.widgets.line1').value
    ''
    >>> browser.getControl(name='form.widgets.address.AA.widgets.line2').value
    ''
    >>> browser.getControl(name='form.widgets.address.AA.widgets.city').value
    ''
    >>> browser.getControl(name='form.widgets.address.AA.widgets.country').value
    ''

Make sure that the template row is present

    >>> browser.getControl(name='form.widgets.address.TT.widgets.address_type:list').value
    ['--NOVALUE--']
    >>> browser.getControl(name='form.widgets.address.TT.widgets.line1').value
    ''
    >>> browser.getControl(name='form.widgets.address.TT.widgets.line2').value
    ''
    >>> browser.getControl(name='form.widgets.address.TT.widgets.city').value
    ''
    >>> browser.getControl(name='form.widgets.address.TT.widgets.country').value
    ''

Make sure the add row button is present (x4)

    >>> browser.contents.find('<button class="btn btn-outline-dark btn-sm dgf--row-add"') != -1
    True

Make sure the delete row button is present (x4)

    >>> browser.contents.find('<button class="btn btn-outline-dark btn-sm dgf--row-delete"') != -1
    True

Make sure the description is displayed in the 'personCount' column header

    >>> browser.contents.find('<span class="form-text">Enter number of persons (min 0 and max 15)</span>') != -1
    True


Make sure resources from our package are not using absolute URLs.  If absolute
URLs are present, then the resources won't load on anything except where
Plone/Zope are the root of the domain.

    >>> '"/++resource++collective.z3cform.datagridfield' not in browser.contents
    True
