"""Series[T] generic interface."""
