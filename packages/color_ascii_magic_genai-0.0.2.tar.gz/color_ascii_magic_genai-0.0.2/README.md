# Color ASCII Magic GenAI

This is a simple package to generate ASCII art with colors.

## Installation

```bash
pip install color_ascii_magic_genai
```

## Usage

```python
from color_ascii_magic_genai import colorize_text

print(colorize_text("Hello World", color="red"))
print(colorize_text("Random Color", color="random"))
print(colorize_text("Rainbow Text", color="rainbow"))

```
