from art import text2art
from termcolor import colored
import random

def colorize_text(text: str, color: str = 'white', font: str = 'block') -> str:
    """
    Generates ASCII art from text and colorizes it.
    
    Args:
        text (str): The text to convert to ASCII art.
        color (str): The color to apply. Supported colors: red, green, yellow, blue, magenta, cyan, white.
                     Also supports 'random' (random color for whole text) and 'rainbow' (random per character).
        font (str): The font style for ASCII art.
        
    Returns:
        str: Colored ASCII art string.
    """
    ascii_art = text2art(text, font=font)
    
    if color == 'random':
        color = random.choice(available_colors())
        return colored(ascii_art, color)
        
    if color == 'rainbow':
        colored_chars = []
        for char in ascii_art:
            # color only non-whitespace characters to avoid weird background issues depending on terminal
            # actually, termcolor colored() on space is fine usually, but let's be safe or just color everything?
            # random.choice on every char
            if char.strip(): 
                c = random.choice(available_colors())
                colored_chars.append(colored(char, c))
            else:
                colored_chars.append(char)
        return "".join(colored_chars)

    return colored(ascii_art, color)

def available_colors():
    """Returns a list of available colors."""
    return ['red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']

