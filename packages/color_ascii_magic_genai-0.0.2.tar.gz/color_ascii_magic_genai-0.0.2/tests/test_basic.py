import pytest
from color_ascii_magic_genai import colorize_text, available_colors

def test_available_colors():
    colors = available_colors()
    assert 'red' in colors
    assert 'blue' in colors

def test_colorize_text_basic():
    # Just checking it doesn't crash and returns a string
    res = colorize_text("test", color="red")
    assert isinstance(res, str)
    assert len(res) > 0
