# Color ASCII Magic GenAI 🎨✨

Welcome to **Color ASCII Magic GenAI**! I built this little tool because I love terminal art but found it tedious to manually colorize output or glue together different libraries just to get something cool on the screen.

This package basically takes the heavy lifting out of generating ASCII art and makes it **pop** with colors. Whether you want a specific color, a random surprise, or a full-on rainbow effect, I've got you covered.

## Why use this?

- **It's simple**: One function request does it all.
- **It's fun**: The `rainbow` mode is perfect for CLI tools that need a bit of personality.
- **It works**: Built on top of the solid `art` and `termcolor` libraries.

## Installation

You can grab it straight from PyPI:

```bash
pip install color_ascii_magic_genai
```

## How to Use

It's super tailored for ease of use. Here is how I typically use it in my projects:

### 1. The Basics
Just import `colorize_text` and pass your string.

```python
from color_ascii_magic_genai import colorize_text

# Classic red
print(colorize_text("Warning!", color="red"))
```

### 2. Feeling Lucky? 🎲
Use `random` mode if you can't decide. It picks one color for the whole block.

```python
print(colorize_text("Surprise Me", color="random"))
```

### 3. The "Rainbow" Mode 🌈
This is my favorite feature. It iterates through every character and assigns a random color. It looks chaotic and beautiful.

```python
print(colorize_text("UNICORN POWER", color="rainbow"))
```

## Arguments

| Argument | Type | Default | Description |
|----------|------|---------|-------------|
| `text` | `str` | (Required) | The text you want to convert. |
| `color` | `str` | `'white'` | Choose from standard colors or special modes like `'random'` / `'rainbow'`. |
| `font` | `str` | `'block'` | The ASCII font style. Passed directly to the `art` library. |

## Supported Colors

I support all the standard terminal colors:
* `red`, `green`, `yellow`, `blue`, `magenta`, `cyan`, `white`

Plus the special modes:
* `random` (Pick one random color)
* `rainbow` (Every character allows a different color)

## Contributing

If you have ideas for more cool modes (maybe a gradient or specific patterns?), feel free to open an issue or PR. I'm always open to making this more fun!

## License

MIT License. Do whatever you want with it! 🤘
