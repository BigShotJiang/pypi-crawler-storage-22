[FORMAT OF THE READ ME IS AI BC IDK HOW TO DO ALL OF THE COLOR THINGS]
# ColorKat

ColorKat is a Python package for creating colorful console applications with animations, gradients, and logging. It allows you to easily display text with colors, gradients, and animated effects in your terminal, while also supporting logging to files.

## Features

- **Text Animations:** Write text character by character, in columns, or in rows.
- **Colors:** Add colored text using RGB values.
- **Gradients:** Apply gradient colors to text with multiple built-in styles.
- **Logging:** Log messages with levels like INFO, SUCCESS, WARNING, ERROR, and DEBUG.

## Installation

pip install colorkat

## Usage

```python
from colorkat.animate import Animate
from colorkat.colors import Colors
from colorkat.gradients import Gradient, Gradients
from colorkat.loggers import Logs

logger = Logs(logging=True, filePath="file.log")

Animate.Write("Kitties", speed=0.05)
Animate.Wave("Kitties", speed=0.05)

print(Colors.Add("This is red text!", Colors.Red))
print(Gradients.Apply("Gradient Text Example", Gradient.Rainbow))
```

## Animations

- `Animate.Write(text, speed)` - Animates text character by character
- `Animate.Column(text, speed)` - Animates text column by column
- `Animate.Row(text, speed)` - Animates text row by row
- `Animate.LogWrite(logger, text, speed)` - Animate and log text

## Colors

Use predefined colors or add your own using RGB tuples:

```python
Colors.Red
Colors.Green
Colors.Blue
```

## Gradients

Built in gradients include Rainbow, Sunset, Mint, Fire, Ocean, and many more. Apply gradients like this:

```python
Gradients.Apply("Your gradient text", Gradient.Rainbow)
```

## Logging

Create a logger:

```python
logger = Logs(logging=True, filePath="example.log")
logger.Info("Information")
logger.Success("Success")
logger.Warning("Warning")
logger.Error("Error")
logger.Debug("Debug message")
```

## Example

Run the `examples.py` file to see animations, colors, gradients, and logging in action:

```bash
python examples.py
```

