from .utils import ColorUtils

class Colors:
    Black       = (0, 0, 0)
    Gray        = (128, 128, 128)

    Red         = (255, 0, 0)
    DarkRed     = (139, 0, 0)
    Orange      = (255, 165, 0)
    Yellow      = (255, 255, 0)

    Green       = (0, 255, 0)
    DarkGreen   = (0, 100, 0)

    Blue        = (0, 0, 255)
    LightBlue   = (173, 216, 230)
    Cyan        = (0, 255, 255)
    DarkBlue    = (0, 0, 139)

    Purple      = (128, 0, 128)
    Pink        = (255, 105, 180)

    @staticmethod
    def Add(text: str, rgb: tuple) -> str:
        r, g, b = rgb
        ansiCode = ColorUtils.RgbToAnsi(r, g, b)
        resetCode = "\033[0m"
        return f"{ansiCode}{text}{resetCode}"
