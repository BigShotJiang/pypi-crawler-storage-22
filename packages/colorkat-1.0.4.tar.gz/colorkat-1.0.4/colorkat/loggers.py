from .utils import isCmd, ColorUtils

class Logs:
    def __init__(self, logging: bool = False, filePath: str | None = None):
        self.Logging = logging
        self.FilePath = filePath if logging else None

    def _WriteFile(self, text: str):
        if not self.FilePath:
            return
        with open(self.FilePath, "a", encoding="utf-8") as f:
            f.write(text + "\n")

    def _Color(self, text: str, rgb: tuple):
        if not isCmd:
            return text
        r, g, b = rgb
        return f"{ColorUtils.RgbToAnsi(r, g, b)}{text}\033[0m"

    def _Build(self, name: str, text: str, rgb: tuple):
        message = f"[{name}] > {text}"
        self._WriteFile(message)
        return self._Color(message, rgb)

    def Error(self, text: str):
        return self._Build("ERROR", text, (255, 0, 0))

    def Warning(self, text: str):
        return self._Build("WARNING", text, (255, 165, 0))

    def Info(self, text: str):
        return self._Build("INFO", text, (0, 200, 255))

    def Success(self, text: str):
        return self._Build("SUCCESS", text, (0, 255, 0))

    def Debug(self, text: str):
        return self._Build("DEBUG", text, (180, 180, 180))
