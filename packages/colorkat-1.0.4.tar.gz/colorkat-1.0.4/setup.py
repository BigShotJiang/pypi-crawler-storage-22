from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="colorkat",
    version="1.0.4",
    description="Color library with multiple features including colors, gradients, logging, and animations",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="g4",
    author_email="glpezg@gmail.com",
    packages=find_packages(),
    include_package_data=True,
    python_requires='>=3.6',
    license="MIT",
)
