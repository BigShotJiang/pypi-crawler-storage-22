# CometChat LangGraph Agent

A LangChain-compatible agent and weather tool designed for seamless integration with [CometChat](https://www.cometchat.com) and other chat platforms. This package demonstrates how to build and expose agentic workflows using LangGraph, with real-time streaming and tool execution.

## Features

- Weather tool using OpenWeatherMap
- LangGraph agent workflow
- FastAPI server example for NDJSON streaming
- Designed for easy integration with CometChat’s Agentic Platform

## Installation

```sh
git clone <this-repo>
cd <this-repo>
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
pip install -r requirements.txt
```

## Environment Variables

Copy `.env.example` to `.env` and fill in your API keys:

```sh
cp .env.example .env
```

Edit `.env` and set:
- `OPENAI_API_KEY`
- `OPENWEATHER_API_KEY`
- (Optional) `MODEL`, `PORT`, `HOST`

## Usage Example

```python
from cometchat_langgraph_agent.agent import graph
from langchain_core.messages import HumanMessage

result = graph.invoke({
    "messages": [HumanMessage(content="What's the weather in London?")]
})
print(result["messages"][-1].content)
```

Or run the FastAPI server for CometChat integration:

```sh
python examples/server.py
```

## Project Structure

```
cometchat_langgraph_agent/
    __init__.py
    agent.py
    weather_tool.py
examples/
    server.py
tests/
    unit_tests/
    integration_tests/
.env.example
pyproject.toml
README.md
requirements.txt
```

## Running Tests

```sh
pytest
```

## CometChat Integration

This agent is designed to work out-of-the-box with CometChat’s Agentic Platform. The included FastAPI server streams NDJSON responses compatible with CometChat’s real-time chat interface. See `examples/server.py` for integration details.

### Getting Started with CometChat

1. **Create a CometChat account:** [https://app.cometchat.com/signup](https://app.cometchat.com/signup)
2. **Create a new app** in the CometChat dashboard.
3. **Navigate to the Agents section** and create a new agent (choose "Custom Agent").
4. **Set the deployment URL** to your running FastAPI server endpoint (e.g., `https://your-server.com/kickoff`).
5. **Test the integration** using CometChat’s dashboard or client SDKs.

## More Information

- [CometChat](https://www.cometchat.com)
- [LangGraph Documentation](https://python.langchain.com/docs/langgraph)
- [LangChain Documentation](https://python.langchain.com/docs/get_started/introduction)