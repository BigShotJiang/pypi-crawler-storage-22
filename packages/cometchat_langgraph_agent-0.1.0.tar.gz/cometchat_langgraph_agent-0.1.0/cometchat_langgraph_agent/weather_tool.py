import os
import json
from datetime import datetime, timezone
from typing import Annotated

import httpx
from langchain_core.tools import tool, InjectedToolCallId

@tool
def get_weather(location: str, unit: str = "fahrenheit", tool_call_id: Annotated[str, InjectedToolCallId] = None) -> str:
    """Get current weather for a city using OpenWeatherMap."""
    api_key = os.getenv("OPENWEATHER_API_KEY")
    if not api_key:
        raise Exception("OPENWEATHER_API_KEY not set")

    url = "https://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": location,
        "appid": api_key,
        "units": "imperial" if unit.lower() == "fahrenheit" else "metric",
    }

    response = httpx.get(url, params=params, timeout=10.0)
    response.raise_for_status()
    data = response.json()

    result = {
        "location": data["name"],
        "country": data["sys"]["country"],
        "temperature": round(data["main"]["temp"], 1),
        "feels_like": round(data["main"]["feels_like"], 1),
        "unit": unit,
        "conditions": data["weather"][0]["description"],
        "humidity": data["main"]["humidity"],
        "wind_speed": data["wind"]["speed"],
        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        "tool_call_id": tool_call_id
    }

    return json.dumps(result)
