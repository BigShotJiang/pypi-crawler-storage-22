"""Interactive CLI components."""
