"""Resolution strategy implementations for CLI."""
