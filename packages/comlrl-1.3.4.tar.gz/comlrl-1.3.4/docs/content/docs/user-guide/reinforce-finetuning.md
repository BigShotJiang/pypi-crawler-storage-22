---
title: Multi-Agent REINFORCE
weight: 2
math: true
---

REINFORCE optimizes the policy directly using sampled returns. An action-independent baseline can be included to reduce variance for REINFORCE methods. REINFORCE methods have been widely used to fine-tune LLMs because of their simplicity and effectiveness, e.g., [GRPO](https://arxiv.org/pdf/2402.03300), [Dr. GRPO](https://arxiv.org/abs/2503.20783), [RLOO](https://openreview.net/forum?id=r1lgTGL5DE), [ReMax](https://arxiv.org/abs/2310.1050), [TreeRPO](https://arxiv.org/abs/2506.05183), and [REINFORCE++](https://arxiv.org/abs/2501.03262).

## MAREINFORCE

In the LLM collaboration setting, REINFORCE can be extended to optimize each agent's policy with joint returns from multiple agents.

- **MAREINFORCE**: The naive Multi‑Agent REINFORCE without a baseline can be expressed by:

{{< katex display=true >}}
J(\theta_i) = \mathbb{E}_{\mathbf{o}_0 \sim \mathcal{D}, \mathbf{h}^\mathcal{G} \sim \mathbf{\pi}_{\mathbf{\theta}}}
\Bigg[\frac{1}{|\mathcal{G}|}\sum_{g \in \mathcal{G}} R^{(g)}_t \cdot \log \pi_{\theta_i}(a^{(g)}_{i,t}\mid h_{i,t})\Bigg].
{{< /katex >}}

{{% hint success %}}
These classes are derived from `comlrl.trainers.reinforce.MAGRPOTrainer`. Interfaces for the trainer and configuration classes are the same as `MAGRPOTrainer` and `MAGRPOConfig`.
{{% /hint %}}

## MAGRPO

Multi‑Agent Group‑Relative Policy Optimization optimizes each agent with a group‑relative baseline computed among sibling joint actions at the same node.

{{< katex display=true >}}
J(\theta_i) = \mathbb{E}_{\mathbf{o}_0 \sim \mathcal{D}, \mathbf{h}^\mathcal{G} \sim \mathbf{\pi}_{\mathbf{\theta}}}\left[ \frac{1}{|\mathcal{G}|}\sum_{g \in \mathcal{G}}
\Big(R^{(g)}_t - \operatorname{mean}(R^{\mathcal{G}}_t)\Big)
\cdot \log \pi_{\theta_i}\big(a^{(g)}_{i,t} \mid h_{i,t}\big) \right].
{{< /katex >}}

{{% hint info %}}
**MAGRPOConfig** provides parameters for both single-turn and multi-turn training:

- `num_agents`: Number of agents (default: 2)
- `num_turns`: Number of turns per episode; set >1 for multi-turn (default: 2)
- `num_train_epochs`: Number of training epochs (default: 20)
- `agent_learning_rate`: Learning rate (default: 5e-6)
- `logging_steps`: Log every N steps (default: 50)
- `num_generations`: Number of generations to sample per prompt for each agent (default: 4)
- `max_new_tokens`: Maximum number of new tokens to generate (default: 256)
- `temperature`: Temperature for sampling (default: 0.6)
- `top_p`: Top-p for sampling (default: 0.6)
- `top_k`: Top-k for sampling (default: 50)
- `discount`: Discount factor gamma over turns for returns (default: 0.9)
- `joint_mode`: Joint action composition - `'aligned'` (index-aligned, default) or `'cross'` (Cartesian product)
- `early_termination_threshold`: Early stop a branch if mean reward exceeds this threshold (default: -0.2)
- `rollout_buffer_size`: Number of node samples to buffer before update (default: 2)
- `train_batch_size`: Mini-batch size within each update (default: rollout_buffer_size)
- `advantage_normalization`: Whether to normalize advantages within each prompt (default: true)
- `eval_interval`: Run evaluation every N training batches (default: 16)
- `eval_num_samples`: Number of samples to evaluate per evaluation run (default: 4)
- `eval_batch_size`: Eval dataloader batch size (default: 1)
- `external_prompt_passthrough`: Use external prompts directly in multi-turn (default: false)
- `advantage_mode`: Baseline mode (`mean`, `max`, `rloo`, `raw`) (default: mean)
{{% /hint %}}

{{% hint info %}}
**MAGRPOTrainer** accepts either a model string for homogeneous agents or a list of `agents` for heterogeneous setups:

- `model` or `agents`: Model identifier string for homogeneous agents, or list of agent models (multi-agent `model` must be a string)
- `num_agents`: Number of agents (default: 2)
- `tokenizer`: The tokenizer (required)
- `train_dataset`: Training dataset (required)
- `reward_func`: Callable that returns a list of floats (required)
- `reward_processor`: Optional processor to apply to rewards (e.g., scaling)
- `formatters`: Single callable or list of callables for each agent to format dataset items into prompts
- `external_transition`: Function providing transitions between turns (required for multi-turn training)
- `eval_dataset`: Evaluation dataset (optional)
- `eval_logger`: Evaluation logger function (optional)
- `eval_aggregator`: Evaluation aggregator function (optional)
- `wandb_config`: Configuration for Weights & Biases logging (optional)
- `model_config`: Model configuration dict (optional)
- `args`: Instance of `MAGRPOConfig` (optional)
{{% /hint %}}

{{% hint warning %}}
For simplicity, MAGRPO computes the policy gradient using the current policy's samples without importance sampling or ratio clipping. And since it does not use a critic model, there is no `value_clip_range` applicable.
{{% /hint %}}

{{% hint warning %}}
The trainer uses a fixed training DataLoader batch size of 1 and requires at least `num_generations=2` generations for group baseline computation. The training use batch gradient descent by default, where `train_batch_size`=`rollout_buffer_size`.
{{% /hint %}}

## Other Variants

CoMLRL also implements other Multi-Agent REINFORCE variants with different baselines:

- **MARLOO**: Multi‑Agent REINFORCE Leave‑One‑Out. Baseline is the mean return of other agents (leave‑one‑out) at the same step.

{{< katex display=true >}}
J(\theta_i) = \mathbb{E}_{\mathbf{o}_0 \sim \mathcal{D}, \mathbf{h}^\mathcal{G} \sim \mathbf{\pi}_{\mathbf{\theta}}}
\Bigg[\frac{1}{|\mathcal{G}|}\sum_{g \in \mathcal{G}} \Big( R^{(g)}_t - \sum_{k\in \mathcal{G},\, k\neq g}\tfrac{R^{(k)}_t}{|\mathcal{G}|-1} \Big) \cdot \log \pi_{\theta_i}(a^{(g)}_{i,t}\mid h_{i,t}) \Bigg];
{{< /katex >}}

- **MAREMAX**: Multi‑Agent REINFORCE with Group Max. Baseline is the maximum group return at the step.

{{< katex display=true >}}
J(\theta_i) = \mathbb{E}_{\mathbf{o}_0 \sim \mathcal{D}, \mathbf{h}^\mathcal{G} \sim \mathbf{\pi}_{\mathbf{\theta}}}
\Bigg[\frac{1}{|\mathcal{G}|}\sum_{g \in \mathcal{G}} \Big( R^{(g)}_t - \max(R_t^{\mathcal{G}}) \Big) \cdot \log \pi_{\theta_i}(a^{(g)}_{i,t}\mid h_{i,t}) \Bigg].
{{< /katex >}}

{{% hint success %}}
These classes are derived from `comlrl.trainers.reinforce.MAGRPOTrainer`. Interfaces for the trainer and configuration classes are the same as `MAGRPOTrainer` and `MAGRPOConfig`.
{{% /hint %}}
