# Commit Pulse 💎
A premium, high-fidelity Git repository analytics engine and dashboard generator. Built for engineers who care about their legacy.

- **Author**: Samuel Olubukun
- **Repository**: [github.com/samolubukun/commitpulse](https://github.com/samolubukun/commitpulse)
- **License**: MIT
- **Tech Stack**: Python, Jinja2, Chart.js (Local); Next.js, Neon DB, Tailwind CSS (Cloud)

Commit Pulse is a powerful, locally-first CLI tool that generates high-fidelity engineering dashboards for your Git repositories. It analyzes your development ecosystem, visualizes commit intensity heatmaps, and identifies top contributors using real GitHub profiles.

## ✨ Key Features
- **Zero-PAT Analysis**: Analyzes local `.git` metadata directly. No Personal Access Tokens or cloud APIs required for core stats.
- **Accurate Project Timelines**: Dynamic contribution grids that span from the repository's inception to the **last official commit**.
- **GitHub Profile Integration**: Automatically fetches actual contributor avatars via the public GitHub Search API.
- **Master Scan**: A recursive drive scanner that aggregates stats from every project on your machine into a single interactive dashboard.
- **Premium Aesthetics**: Glassmorphic UI with dark mode, smooth animations, and official GitHub iconography.

## 📦 Installation

### 1. Local (Developer Mode)
If you have the source code locally:
```bash
pip install -e .
```

### 2. Direct from GitHub
Anyone can install your tool directly if the repo is public:
```bash
pip install git+https://github.com/YOUR_USERNAME/commitpulse.git
```

### 3. Global Command
Once installed, the `commitpulse` command is available everywhere in your terminal.

## 🚀 Usage

### Analyze the current repository
```bash
commitpulse
```

### Analyze all repositories on your computer (Master Scan)
```bash
commitpulse --scan
```

### Specify a target directory
```bash
commitpulse /path/to/projects
```

## 🛠️ Options
- `--scan`: Crawls subdirectories to find and aggregate all Git repositories.
- `--no-open`: Generates the dashboard without automatically opening it in the browser.

## 🚀 Deployment & Sharing

Commit Pulse offers two ways to view and share your results:

### 1. Local-First (Default)
Run the command to generate a self-contained, interactive HTML dashboard on your machine. Perfect for private analysis.
```bash
commitpulse --scan
```
*Output: `stats_dashboard.html`*

### 2. Commit Pulse Cloud (Global Sharing)
Ready to show the world? Use the `--publish` flag to host your dashboard on the cloud and get a unique, shareable URL.
```bash
commitpulse --publish
```
*Output: `https://commitpulse.app/v/your-unique-id`*

---

## 🛠️ Setting up your own Cloud Instance (Optional)

If you are hosting your own version of **Commit Pulse Cloud**:

1.  **Neon DB**:
    - Go to [Neon.tech](https://neon.tech) and create a free project.
    - Copy your **Connection String** (e.g., `postgresql://user:pass@ep-cool-beach-123.us-east-2.aws.neon.tech/neondb?sslmode=require`).
2.  **Environment Setup**:
    - In the `commitpulse-cloud` directory, rename `.env.example` to `.env`.
    - Paste your connection string into `DATABASE_URL`.
3.  **Vercel Deployment**:
    - Deploy the `commitpulse-cloud` folder to Vercel.
    - Add the `DATABASE_URL` to your Vercel Environment Variables.

## 🌍 Distribution & PyPI Hosting

To share **Commit Pulse** with the global developer community via PyPI:

### 1. Prepare your Account
- Register at [pypi.org](https://pypi.org/).
- Generate an API Token in your account settings.

### 2. Build the Distribution
Ensure you have the latest build tools:
```bash
python -m pip install --upgrade build twine
```
Then build the package:
```bash
python -m build
```
This creates a `dist/` folder with your `.whl` and `.tar.gz` files.

### 3. Upload to PyPI
Use `twine` to securely upload your package:
```bash
python -m twine upload dist/*
```
- **Username**: `__token__`
- **Password**: `[Your API Token]`

Once uploaded, anyone can install it via:
```bash
pip install commitpulse
```

---
*Built with ❤️ for the development ecosystem.*
