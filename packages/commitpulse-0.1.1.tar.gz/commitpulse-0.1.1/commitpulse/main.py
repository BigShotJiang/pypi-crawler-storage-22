import argparse
import os
import sys
import webbrowser
from .analyzer import GitAnalyzer
from .renderer import DashboardRenderer

def main():
    parser = argparse.ArgumentParser(
        description="Commit Pulse - Premium Git Repository Analytics Dashboard"
    )
    
    parser.add_argument(
        'path', 
        nargs='?', 
        default='.', 
        help="Path to the repository (default is current directory)"
    )
    
    parser.add_argument(
        '--scan', 
        action='store_true', 
        help="Scan the current directory (and subdirectories) for all git repositories"
    )
    
    parser.add_argument(
        '--no-open', 
        action='store_true', 
        help="Do not automatically open the dashboard in the browser"
    )
    
    parser.add_argument(
        '--publish', 
        action='store_true', 
        help="Publish your project's pulse to the cloud for sharing"
    )

    args = parser.parse_args()
    
    all_stats = []
    
    if args.scan:
        print(f"Scanning for git repositories in {os.path.abspath(args.path)}...")
        repo_paths = GitAnalyzer.scan_for_repos(args.path)
        print(f"Found {len(repo_paths)} repositories.")
        
        for p in repo_paths:
            analyzer = GitAnalyzer(p)
            stats = analyzer.get_stats()
            if stats:
                all_stats.append(stats)
    else:
        analyzer = GitAnalyzer(args.path)
        if not analyzer.is_git_repo():
            print(f"Error: {os.path.abspath(args.path)} is not a git repository.")
            sys.exit(1)
            
        stats = analyzer.get_stats()
        if stats:
            all_stats.append(stats)

    if not all_stats:
        print("Note: No statistics could be gathered.")
        sys.exit(0)

    # Render dashboard
    renderer = DashboardRenderer(all_stats)
    output_path = renderer.render()
    
    print(f"\nDashboard generated successfully!")
    print(f"Location: {output_path}")
    
    # Decide whether to open local HTML
    # If publishing, we might want to prioritize the cloud link instead of popping up the local file
    should_open_local = not args.no_open
    if args.publish and not args.no_open:
        # If they are publishing, maybe they only want the web link? 
        # Let's still open local unless it's a server environment, but clarify.
        pass

    if should_open_local:
        webbrowser.open(f"file://{output_path}")

    # Cloud Publishing
    if args.publish:
        import requests
        # Get username from git config
        username = GitAnalyzer.get_git_config_user() or os.getenv("USER") or "Anonymous"
        
        print(f"\n🚀 Publishing your Pulse to the cloud as '{username}'...")
        
        # In a real scenario, this would be your production URL
        # For now, we point to the local or configured cloud instance
        cloud_url = os.getenv("COMMITPULSE_CLOUD_URL", "http://localhost:3000") 
        api_endpoint = f"{cloud_url}/api/publish"
        
        try:
            # We publish the first repo in scanning mode or the target repo
            # For simplicity, we publish the main one if multiple found
            repo_to_publish = all_stats[0]
            
            payload = {
                "username": username,
                "repoName": repo_to_publish["name"],
                "stats": all_stats # Send all scanned repos
            }
            
            response = requests.post(api_endpoint, json=payload, timeout=10)
            if response.status_code == 200:
                result = response.json()
                print(f"✨ Successfully published! Share your Pulse at: {result['url']}")
            else:
                print(f"❌ Failed to publish: {response.text}")
        except Exception as e:
            print(f"⚠️ Cloud sync failed: {str(e)}")

if __name__ == "__main__":
    main()
