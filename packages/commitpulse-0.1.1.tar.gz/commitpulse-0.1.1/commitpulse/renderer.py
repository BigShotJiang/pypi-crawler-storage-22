import json
import os
from datetime import datetime, timedelta

class DashboardRenderer:
    def __init__(self, stats_data):
        self.stats_data = stats_data

    def render(self, output_path="stats_dashboard.html"):
        html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Commit Pulse | Repository Ecosystem</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #0d1117;
            --card-bg: rgba(22, 27, 34, 0.7);
            --border: rgba(48, 54, 61, 0.8);
            --text-main: #f0f6fc;
            --text-dim: #8b949e;
            --accent: #238636;
            --accent-glow: rgba(35, 134, 54, 0.3);
            --github-blue: #58a6ff;
            --glass-blur: blur(12px);
            
            /* Heatmap Colors */
            --h-0: #161b22;
            --h-1: #0e4429;
            --h-2: #006d32;
            --h-3: #26a641;
            --h-4: #39d353;
        }

        * {
            box-sizing: border-box;
            transition: all 0.2s ease-in-out;
        }

        body {
            font-family: 'Outfit', -apple-system, BlinkMacSystemFont, sans-serif;
            background-color: var(--bg-dark);
            background-image: radial-gradient(circle at 50% 10%, rgba(35, 134, 54, 0.05) 0%, transparent 50%);
            color: var(--text-main);
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        header {
            padding: 30px 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(13, 17, 23, 0.8);
            backdrop-filter: var(--glass-blur);
            border-bottom: 1px solid var(--border);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-icon {
            fill: var(--text-main);
            filter: drop-shadow(0 0 8px rgba(255,255,255,0.2));
        }

        h1 {
            font-size: 24px;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
            background: linear-gradient(90deg, #fff, var(--text-dim));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 60px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 40px;
        }

        .repo-card {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            backdrop-filter: var(--glass-blur);
            position: relative;
            overflow: hidden;
        }

        .repo-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 4px; height: 100%;
            background: var(--accent);
            opacity: 0;
            transition: 0.3s;
        }

        .repo-card:hover {
            border-color: var(--github-blue);
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(0,0,0,0.3);
        }

        .repo-card:hover::before {
            opacity: 1;
        }

        .repo-title-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 24px;
        }

        .repo-name-group {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .repo-name {
            font-size: 28px;
            font-weight: 700;
            color: var(--text-main);
            text-decoration: none;
        }

        .repo-meta-badges {
            display: flex;
            gap: 12px;
            margin-bottom: 32px;
        }

        .badge {
            background: rgba(48, 54, 61, 0.4);
            border: 1px solid var(--border);
            color: var(--text-dim);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .badge.highlight {
            border-color: var(--accent);
            color: var(--accent);
            background: rgba(35, 134, 54, 0.1);
        }

        .dashboard-row {
            display: grid;
            grid-template-columns: 1fr;
            gap: 32px;
        }

        /* HEATMAP STYLES */
        .heatmap-container {
            background: rgba(0,0,0,0.2);
            padding: 32px;
            border-radius: 12px;
            border: 1px solid var(--border);
            width: 100%;
            overflow: hidden;
        }

        .heatmap-wrapper {
            overflow-x: auto;
            display: flex;
            gap: 16px;
            padding-bottom: 12px;
            scrollbar-width: thin;
            scrollbar-color: var(--border) transparent;
        }

        .heatmap-wrapper::-webkit-scrollbar {
            height: 6px;
        }

        .heatmap-wrapper::-webkit-scrollbar-track {
            background: transparent;
        }

        .heatmap-wrapper::-webkit-scrollbar-thumb {
            background: var(--border);
            border-radius: 10px;
        }

        .heatmap-wrapper::-webkit-scrollbar-thumb:hover {
            background: var(--text-dim);
        }

        .section-label {
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-dim);
            letter-spacing: 1px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .heatmap-month-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
            flex-shrink: 0; /* Don't squish month groups */
        }

        .month-name {
            font-size: 11px;
            font-weight: 700;
            color: var(--github-blue); /* Subtle blue for headers */
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .heatmap-grid {
            display: flex;
            flex-flow: column wrap;
            height: 122px; /* (14px * 7) + (4px * 6) = 122px */
            gap: 4px;
            align-content: flex-start;
        }

        .heatmap-cell {
            width: 14px;
            height: 14px;
            border-radius: 2px;
            background-color: var(--h-0);
            cursor: pointer;
            flex-shrink: 0;
        }

        .heatmap-cell.empty {
            background-color: transparent;
            cursor: default;
            pointer-events: none;
        }

        .heatmap-cell:hover {
            outline: 2px solid var(--text-main);
            z-index: 10;
        }

        .intensity-1 { background-color: var(--h-1); }
        .intensity-2 { background-color: var(--h-2); }
        .intensity-3 { background-color: var(--h-3); }
        .intensity-4 { background-color: var(--h-4); }

        .legend {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            color: var(--text-dim);
        }

        .legend-box {
            width: 10px;
            height: 10px;
            border-radius: 2px;
        }

        /* CONTRIBUTOR STYLES */
        .contributor-panel {
            background: rgba(0,0,0,0.2);
            padding: 24px;
            border-radius: 12px;
            border: 1px solid var(--border);
            margin-top: 24px;
        }

        .contributor-list {
            display: flex;
            flex-wrap: wrap;
            gap: 24px;
        }

        .contributor-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px;
            border-radius: 8px;
            background: rgba(255,255,255,0.02);
            min-width: 200px;
        }

        .contributor-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid var(--border);
            padding: 2px;
            background: #0d1117;
            object-fit: cover;
        }

        .contributor-name {
            font-weight: 600;
            font-size: 15px;
            color: var(--text-main);
        }

        .commit-pill {
            background: var(--accent);
            color: #fff;
            padding: 4px 12px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 12px;
        }

        footer {
            text-align: center;
            padding: 60px;
            color: var(--text-dim);
            font-size: 14px;
            opacity: 0.6;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .repo-card {
            animation: fadeIn 0.8s ease-out forwards;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-left">
            <svg height="32" viewBox="0 0 16 16" width="32" class="logo-icon"><path d="M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27-.68 0-1.36.09-2 .27-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.27-.82 2.15 0 3.07 1.87 3.75 3.65 3.95-.29.25-.54.73-.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 1 0 8c0-4.42 3.58-8 8-8Z"></path></svg>
            <h1>Commit Pulse</h1>
        </div>
        <div class="badge highlight">
            <span>Repository Ecosystem</span>
        </div>
    </header>

        <div class="stats-grid" id="stats-grid"></div>

    <footer>
        &copy; 2026 Commit Pulse &bull; High-Fidelity Ecosystem Analytics
    </footer>

    <script>
        const data = __STATS_DATA__;
        
        function getIntensity(count) {
            if (count === 0) return '';
            if (count < 3) return 'intensity-1';
            if (count < 6) return 'intensity-2';
            if (count < 10) return 'intensity-3';
            return 'intensity-4';
        }

        function createHeatmap(repo) {
            const wrapper = document.createElement('div');
            wrapper.className = 'heatmap-wrapper';
            
            const start = new Date(repo.first_commit);
            const end = new Date(repo.last_commit);
            
            // Start from the first day of the first commit month
            const current = new Date(start.getFullYear(), start.getMonth(), 1);
            // End at the last day of the last commit month
            const lastDay = new Date(end.getFullYear(), end.getMonth() + 1, 0);
            
            const months = {};
            
            while (current <= lastDay) {
                const monthKey = `${current.getFullYear()}-${String(current.getMonth() + 1).padStart(2, '0')}`;
                if (!months[monthKey]) {
                    months[monthKey] = {
                        name: current.toLocaleString('default', { month: 'short' }),
                        year: current.getFullYear(),
                        days: []
                    };
                }
                
                const dateKey = current.toISOString().split('T')[0];
                const count = repo.heatmap[dateKey] || 0;
                
                months[monthKey].days.push({
                    date: dateKey,
                    readable: current.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                    count: count
                });
                
                current.setDate(current.getDate() + 1);
            }
            
            Object.values(months).forEach(m => {
                const monthGroup = document.createElement('div');
                monthGroup.className = 'heatmap-month-group';
                
                const monthLabel = document.createElement('div');
                monthLabel.className = 'month-name';
                monthLabel.innerText = `${m.name} ${m.year}`;
                monthGroup.appendChild(monthLabel);
                
                const grid = document.createElement('div');
                grid.className = 'heatmap-grid';
                
                m.days.forEach(day => {
                    const cell = document.createElement('div');
                    cell.className = `heatmap-cell ${getIntensity(day.count)}`;
                    cell.title = `${day.count} commits on ${day.readable}`;
                    grid.appendChild(cell);
                });

                // Pad the end of the month to complete the column (total cells must be multiple of 7)
                const totalCells = m.days.length;
                const remaining = (7 - (totalCells % 7)) % 7;
                for (let i = 0; i < remaining; i++) {
                    const empty = document.createElement('div');
                    empty.className = 'heatmap-cell empty';
                    grid.appendChild(empty);
                }
                
                monthGroup.appendChild(grid);
                wrapper.appendChild(monthGroup);
            });
            
            return wrapper;
        }

        function render() {
            const grid = document.getElementById('stats-grid');
            data.forEach((repo, index) => {
                const card = document.createElement('div');
                card.className = 'repo-card';
                card.style.animationDelay = `${index * 0.15}s`;
                
                card.innerHTML = `
                    <div class="repo-title-row">
                        <div class="repo-name-group">
                            <svg height="24" viewBox="0 0 16 16" width="24" fill="var(--text-dim)"><path d="M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27-.68 0-1.36.09-2 .27-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.27-.82 2.15 0 3.07 1.87 3.75 3.65 3.95-.29.25-.54.73-.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 1 0 8c0-4.42 3.58-8 8-8Z"></path></svg>
                            <span class="repo-name">${repo.name}</span>
                        </div>
                        <div class="commit-pill">${repo.total_commits} Total Commits</div>
                    </div>

                    <div class="repo-meta-badges">
                        <div class="badge">
                            <span style="opacity: 0.5">Timeline:</span>
                            ${repo.first_commit} to ${repo.last_commit}
                        </div>
                        <div class="badge highlight">
                            <span style="opacity: 0.5">Peak Hour:</span>
                            ${repo.peak_hour}
                        </div>
                    </div>

                    <div class="dashboard-row">
                        <div class="heatmap-container">
                            <div class="section-label">
                                <span>Commit Contributions (Full History)</span>
                                <div class="legend">
                                    <span>Less</span>
                                    <div class="legend-box" style="background: var(--h-0)"></div>
                                    <div class="legend-box intensity-1"></div>
                                    <div class="legend-box intensity-2"></div>
                                    <div class="legend-box intensity-3"></div>
                                    <div class="legend-box intensity-4"></div>
                                    <span>More</span>
                                </div>
                            </div>
                            <div class="heatmap-wrapper" id="heatmap-${index}"></div>
                        </div>
                    </div>

                    <div class="contributor-panel">
                        <span class="section-label">Top Engineering Impact</span>
                        <div class="contributor-list">
                            ${repo.contributors.map(c => `
                                <div class="contributor-item">
                                    <div class="contributor-info">
                                        <img src="${c.avatar}" class="avatar" onerror="this.src='https://www.gravatar.com/avatar/0?d=mp'">
                                        <span class="contributor-name">${c.name}</span>
                                    </div>
                                    <div class="commit-pill" style="background: rgba(255,255,255,0.05); color: var(--text-dim); border: 1px solid var(--border)">
                                        ${c.commits}
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `;
                grid.appendChild(card);
                document.getElementById(`heatmap-${index}`).appendChild(createHeatmap(repo));
            });
        }
        render();
    </script>
</body>
</html>
""".replace("__STATS_DATA__", json.dumps(self.stats_data))
        
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html_template)
        
        return os.path.abspath(output_path)
