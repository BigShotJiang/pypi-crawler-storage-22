from contracts_hj3415.nfs.constants import C104_BLOCK_KEYS, C103_BLOCK_KEYS


def make_empty_c103_blocks() -> dict[str, dict]:
    return {k: {} for k in C103_BLOCK_KEYS}

def make_empty_c104_blocks() -> dict[str, dict]:
    return {k: {} for k in C104_BLOCK_KEYS}

