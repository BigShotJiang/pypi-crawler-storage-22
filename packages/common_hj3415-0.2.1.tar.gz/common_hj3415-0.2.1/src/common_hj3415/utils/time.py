from __future__ import annotations

from datetime import datetime, timezone


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def to_utc(dt: datetime) -> datetime:
    """
    datetime을 UTC timezone-aware datetime으로 정규화한다.

    규칙:
    - tzinfo가 없는 naive datetime은 이미 UTC라고 가정한다.
    - tzinfo가 있는 aware datetime은 UTC로 변환한다.

    반환값:
    - 항상 tzinfo=timezone.utc 인 datetime
    """
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)
