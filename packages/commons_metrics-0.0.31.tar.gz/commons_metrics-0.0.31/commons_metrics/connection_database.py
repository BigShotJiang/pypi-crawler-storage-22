from lib.commons_metrics.commons_metrics import DatabaseConnection, Util, ComponentRepository

class ConnectionDatabase:
    """Manager for connection with database"""

    def __init__(self, secret_name: str, logger: str, aws_region: str):
        self.secret_name = secret_name
        self.logger = logger
        self.aws_region = aws_region

    def get_connection_database_from_secret(self) -> ComponentRepository:
        """
        Retrieve connection database from AWS secrets manager
        """
        secret_json = Util.get_secret_aws(self.secret_name, self.logger, self.aws_region)
        db_connection = DatabaseConnection()
        db_connection.connect({
            'host': secret_json["host"],
            'port': secret_json["port"],
            'dbname': secret_json["dbname"],
            'username': secret_json["username"],
            'password': secret_json["password"]
        })

        return ComponentRepository(db_connection)
