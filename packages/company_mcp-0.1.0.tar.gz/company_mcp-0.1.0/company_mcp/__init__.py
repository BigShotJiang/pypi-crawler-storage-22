"""Company MCP - Extract AI companies and funding information from articles."""

__version__ = "0.1.0"
