// Custom allocator configuration header
