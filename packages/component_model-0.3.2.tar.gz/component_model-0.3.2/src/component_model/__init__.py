"""component_model."""
