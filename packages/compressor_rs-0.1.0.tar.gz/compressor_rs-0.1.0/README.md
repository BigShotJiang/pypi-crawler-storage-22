# Compressor

Bibliothèque de compression de répertoires rapide pour Python, propulsée par Rust.

## Fonctionnalités

- Compression ultra-rapide grâce à Rust
- Formats multiples : tar.gz, tar.zlib, zip, 7z
- Compression récursive - gère automatiquement les sous-répertoires
- API Python simple - facile à utiliser
- Haute performance - implémentation Rust optimisée

## Installation

### Depuis les sources

```bash
# Installation
pip install compressor-rs

```

## Utilisation

```python
import compressor

# Compresser un répertoire en tar.gz
compressor.compress_gz("mon_dossier/", "archive.tar.gz")

# Compresser un répertoire en tar.zlib
compressor.compress_zlib("mon_dossier/", "archive.tar.zlib")

# Compresser un répertoire en ZIP
compressor.compress_zip("mon_dossier/", "archive.zip")

# Compresser un répertoire en 7z
compressor.compress_7z("mon_dossier/", "archive.7z")
```

## Exemple

```python
import compressor
import os

# Créer une structure de répertoires de test
os.makedirs("dossier_test/sous_dossier", exist_ok=True)
with open("dossier_test/fichier1.txt", "w") as f:
    f.write("Bonjour le monde")
with open("dossier_test/sous_dossier/fichier2.txt", "w") as f:
    f.write("Fichier imbriqué")

# Compresser le répertoire entier
compressor.compress_zip("dossier_test/", "sortie.zip")
print("✓ Répertoire compressé avec succès !")

# Fonctionne avec tous les sous-répertoires et fichiers
compressor.compress_gz("dossier_test/", "sortie.tar.gz")
compressor.compress_7z("dossier_test/", "sortie.7z")
```

## Comparaison des formats

| Format | Extension | Compression | Vitesse | Cas d'usage |
|--------|-----------|-------------|---------|-------------|
| tar.gz | .tar.gz | Bonne | Rapide | Standard Unix/Linux |
| tar.zlib | .tar.zlib | Bonne | Rapide | Alternative à gzip |
| ZIP | .zip | Bonne | Rapide | Universel, compatible Windows |
| 7z | .7z | Excellente | Plus lent | Compression maximale |

## Référence API

### compress_gz(repertoire_entree, fichier_sortie)

Compresse un répertoire au format tar.gz.

- **repertoire_entree** (str) : Chemin du répertoire à compresser
- **fichier_sortie** (str) : Chemin du fichier .tar.gz de sortie
- **Retourne** : None
- **Lève** : IOError en cas d'échec

### compress_zlib(repertoire_entree, fichier_sortie)

Compresse un répertoire au format tar.zlib.

- **repertoire_entree** (str) : Chemin du répertoire à compresser
- **fichier_sortie** (str) : Chemin du fichier .tar.zlib de sortie
- **Retourne** : None
- **Lève** : IOError en cas d'échec

### compress_zip(repertoire_entree, fichier_sortie)

Compresse un répertoire au format ZIP.

- **repertoire_entree** (str) : Chemin du répertoire à compresser
- **fichier_sortie** (str) : Chemin du fichier .zip de sortie
- **Retourne** : None
- **Lève** : IOError en cas d'échec

### compress_7z(repertoire_entree, fichier_sortie)

Compresse un répertoire au format 7z.

- **repertoire_entree** (str) : Chemin du répertoire à compresser
- **fichier_sortie** (str) : Chemin du fichier .7z de sortie
- **Retourne** : None
- **Lève** : IOError en cas d'échec

## Prérequis

- Python >= 3.8
## Performance

Compressor utilise Rust pour les opérations critiques en termes de performance, le rendant significativement plus rapide que les implémentations Python pures pour les grands répertoires.

Exemple de benchmark (1000 fichiers, ~100 Mo) :

- compressor (Rust) : ~0,8s
- zipfile (Python) : ~2,3s
- tarfile (Python) : ~1,9s

*Les résultats peuvent varier selon le matériel et les types de fichiers*

## Licence

Licence MIT

## Contribution

Les contributions sont les bienvenues ! C'est un projet simple axé sur la compression rapide de répertoires.

## Dépannage

### Erreurs de compilation

Assurez-vous d'avoir Rust installé :

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

### Erreurs d'import

Après l'installation, si `import compressor` échoue, essayez de réinstaller :

```bash
pip uninstall compressor
maturin develop --release
```

## Historique des versions

### Version 0.1.0

- Version initiale
- Support des formats tar.gz, tar.zlib, zip, 7z
- Compression récursive de répertoires
- Implémentation Rust rapide