use flate2::write::{GzEncoder, ZlibEncoder};
use flate2::Compression;
use pyo3::prelude::*;
use pyo3::exceptions::PyIOError;
use std::fs::File;
use std::path::Path;
use walkdir::WalkDir;
use zip::write::FileOptions;
use zip::CompressionMethod;
use tar::Builder;

macro_rules! py_try {
    ($expr:expr) => {
        $expr.map_err(|e| PyIOError::new_err(e.to_string()))?
    };
}

/// Compress a directory to .tar.gz format
#[pyfunction]
fn compress_gz(inputdir: &str, output: &str) -> PyResult<()> {
    let file = py_try!(File::create(output));
    let gz = GzEncoder::new(file, Compression::default());
    let mut tar = Builder::new(gz);

    py_try!(tar.append_dir_all(".", inputdir));
    py_try!(tar.finish());

    Ok(())
}

/// Compress a directory to .tar.zlib format
#[pyfunction]
fn compress_zlib(inputdir: &str, output: &str) -> PyResult<()> {
    let file = py_try!(File::create(output));
    let zlib = ZlibEncoder::new(file, Compression::default());
    let mut tar = Builder::new(zlib);

    py_try!(tar.append_dir_all(".", inputdir));
    py_try!(tar.finish());

    Ok(())
}

/// Compress a directory to ZIP format
#[pyfunction]
fn compress_zip(inputdir: &str, output: &str) -> PyResult<()> {
    let file = py_try!(File::create(output));
    let mut zip = zip::ZipWriter::new(file);
    let options = FileOptions::<()>::default()
        .compression_method(CompressionMethod::Deflated)
        .unix_permissions(0o755);

    for entry in WalkDir::new(inputdir).into_iter().filter_map(|e| e.ok()) {
        let path = entry.path();
        let name = py_try!(path.strip_prefix(inputdir)
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e)))
            .to_str()
            .unwrap();

        if name.is_empty() {
            continue;
        }

        if path.is_file() {
            py_try!(zip.start_file(name, options));
            let mut file = py_try!(File::open(path));
            py_try!(std::io::copy(&mut file, &mut zip));
        } else if path.is_dir() {
            py_try!(zip.add_directory(name, options));
        }
    }

    py_try!(zip.finish());
    Ok(())
}

/// Compress a directory to 7z format
#[pyfunction]
fn compress_7z(inputdir: &str, output: &str) -> PyResult<()> {
    py_try!(sevenz_rust::compress_to_path(
        Path::new(inputdir),
        Path::new(output)
    ));
    Ok(())
}

/// A Python module for fast compression using Rust
#[pymodule]
fn compressor(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(compress_gz, m)?)?;
    m.add_function(wrap_pyfunction!(compress_zlib, m)?)?;
    m.add_function(wrap_pyfunction!(compress_zip, m)?)?;
    m.add_function(wrap_pyfunction!(compress_7z, m)?)?;
    Ok(())
}