from tempfile import TemporaryDirectory
from argparse import Namespace, _SubParsersAction
from pathlib import Path

from conda.auxlib.ish import dals
from conda.base.context import context
from conda.exceptions import ArgumentError

from conda_pypi import build, paths


def configure_parser(parser: _SubParsersAction) -> None:
    """
    Configure all subcommand arguments and options via argparse
    """
    # convert subcommand
    summary = "Build and convert local Python sdists, wheels or projects to conda packages"
    description = summary
    epilog = dals(
        """
        Examples:

        Convert a PyPI package to conda format without installing::

            conda pypi convert ./requests-2.32.5-py3-none-any.whl

        Convert a local Python project to conda package::

            conda pypi convert ./my-python-project

        Convert a package and save to a specific output folder::

            conda pypi convert --output-folder ./conda-packages ./numpy-2.3.3-cp312-cp312-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl

        Convert a local Python project to an editable package::

            conda pypi convert -e . --output-folder ./conda-packages

        Convert a package from a Git repository::

            git clone https://github.com/user/repo.git
            conda pypi convert ./repo

        """
    )

    convert = parser.add_parser(
        "convert",
        help=summary,
        description=description,
        epilog=epilog,
    )

    convert.add_argument(
        "--output-folder",
        help="Folder to write output package(s)",
        type=Path,
        required=False,
        default=Path.cwd() / "conda-pypi-output",
    )
    convert.add_argument(
        "project_path",
        metavar="PROJECT",
        help="Convert named path as conda package.",
    )
    convert.add_argument(
        "-e",
        "--editable",
        action="store_true",
        help="Build PROJECT as an editable package.",
    )


def execute(args: Namespace) -> int:
    """
    Entry point for the `conda pypi convert` subcommand
    """
    prefix_path = Path(context.target_prefix)
    if not Path(args.project_path).exists():
        raise ArgumentError("PROJECT must be a local path to a sdist, wheel or directory.")
    project_path = Path(args.project_path).expanduser()
    output_folder = Path(args.output_folder).expanduser()
    output_folder.mkdir(parents=True, exist_ok=True)

    # Handle wheel files directly without building
    if project_path.suffix == ".whl":
        if args.editable:
            raise ArgumentError("Cannot create editable package from a wheel file.")

        python_executable = str(paths.get_python_executable(prefix_path))
        with TemporaryDirectory(prefix="conda") as build_path:
            package_path = build.build_conda(
                project_path,
                Path(build_path),
                output_folder,
                python_executable,
            )
    else:
        # Build from source (project directory or sdist)
        distribution = "editable" if args.editable else "wheel"
        package_path = build.pypa_to_conda(
            project_path,
            distribution=distribution,
            output_path=output_folder,
            prefix=prefix_path,
        )

    print(f"Conda package at {package_path} built successfully. Output folder: {output_folder}.")
    return 0
