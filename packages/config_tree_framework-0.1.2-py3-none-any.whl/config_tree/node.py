class Node:
    def __init__(self, value, max_children=2):
        self.value = value
        self.children = []
        self.max_children = max_children

    def add_child(self, node):
        if self.max_children is not None and len(self.children) >= self.max_children:
            raise ValueError("Maximum children limit reached")
        self.children.append(node)

    @property
    def left(self):
        return self.children[0] if len(self.children) > 0 else None

    @left.setter
    def left(self, node):
        if len(self.children) == 0:
            self.children.append(node)
        else:
            self.children[0] = node

    @property
    def right(self):
        return self.children[1] if len(self.children) > 1 else None

    @right.setter
    def right(self, node):
        if len(self.children) < 2:
            self.children.append(node)
        else:
            self.children[1] = node
