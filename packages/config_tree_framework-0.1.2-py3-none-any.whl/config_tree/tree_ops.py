from .node import Node

def create_tree(value, max_children=None):
    return Node(value, max_children)

def add_node_by_path(root, path, value):
    current = root

    for direction in path[:-1]:
        if direction == "L":
            if current.left is None:
                current.left = Node(None)
            current = current.left
        elif direction == "R":
            if current.right is None:
                current.right = Node(None)
            current = current.right

    if path[-1] == "L":
        current.left = Node(value)
    elif path[-1] == "R":
        current.right = Node(value)

def add_node(root, parent_value, new_value):
    if root.value == parent_value:
        root.add_child(Node(new_value, root.max_children))
        return True
    for child in root.children:
        if add_node(child, parent_value, new_value):
            return True
    return False

def edit_node(root, old_value, new_value):
    if root.value == old_value:
        root.value = new_value
        return True
    for child in root.children:
        if edit_node(child, old_value, new_value):
            return True
    return False

def delete_node(root, value):
    for i, child in enumerate(root.children):
        if child.value == value:
            del root.children[i]
            return True
    for child in root.children:
        if delete_node(child, value):
            return True
    return False

def delete_tree(root):
    root.children.clear()
    root.value = None

def print_binary_tree(root, level=0, label="Root"):
    if root is None:
        print("    " * level + f"{label}---None")
        return

    if level == 0:
        print(f"Root:{root.value}")
    else:
        print("    " * level + f"{label}---{root.value}")

    # Left child
    print_binary_tree(root.left, level + 1, "L")

    # Right child
    print_binary_tree(root.right, level + 1, "R")

def print_tree(root, level=0):
    print("  " * level + str(root.value))
    for child in root.children:
        print_tree(child, level + 1)
