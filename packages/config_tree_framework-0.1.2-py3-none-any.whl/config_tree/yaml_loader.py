import yaml
from .node import Node

def build_tree_from_yaml(path):
    with open(path, "r") as f:
        data = yaml.safe_load(f)
    return _build_binary_tree(data)

def _build_binary_tree(data):
    if data is None:
        return None

    node = Node(data["value"])
    node.left = _build_binary_tree(data.get("left"))
    node.right = _build_binary_tree(data.get("right"))
    return node

def load_tree_from_yaml(path):
    with open(path, "r") as f:
        config = yaml.safe_load(f)

    max_children = config.get("tree", {}).get("max_children")
    return _build_tree(config["root"], max_children)

def _build_tree(data, max_children):
    node = Node(data["value"], max_children)
    for child in data.get("children", []):
        node.add_child(_build_tree(child, max_children))
    return node

def save_tree_to_yaml(root, path):
    tree_dict = {
        "tree": {
            "max_children": root.max_children
        },
        "root": _serialize_tree(root)
    }

    with open(path, "w") as f:
        yaml.safe_dump(tree_dict, f, sort_keys=False)

def _serialize_tree(node):
    data = {"value": node.value}
    if node.children:
        data["children"] = [_serialize_tree(child) for child in node.children]
    return data
