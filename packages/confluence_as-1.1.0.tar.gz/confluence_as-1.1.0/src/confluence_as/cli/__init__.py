"""CLI module for Confluence Assistant Skills."""

from confluence_as.cli.main import cli as main

__all__ = ["main"]
