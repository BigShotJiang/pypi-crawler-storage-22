# congreso-ia

[![PyPI version](https://img.shields.io/pypi/v/congreso-ia.svg)](https://pypi.org/project/congreso-ia/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Libreria Python para acceder a datos publicos del **Congreso de los Diputados de Espana**. Extrae diputados, votaciones, iniciativas e intervenciones del portal de Open Data oficial.

## Instalacion

```bash
pip install congreso-ia
```

## Uso rapido

### API Python

```python
from congreso_ia import CongressClient

client = CongressClient()

# Obtener todos los diputados activos
deputies = client.get_deputies()
print(f"{len(deputies)} diputados")

# Filtrar por partido
pp_deputies = client.get_deputies(party="PP")

# Obtener votaciones recientes
votes = client.get_votes()

# Obtener iniciativas
initiatives = client.get_initiatives()

# Buscar intervenciones de un diputado
interventions = client.get_interventions(speaker="Pedro Sanchez")
print(f"{len(interventions)} intervenciones")

# Filtrar por organo y fecha
from datetime import date
pleno = client.get_interventions(
    speaker="Feijoo",
    organ="Pleno",
    start_date=date(2024, 1, 1)
)
```

### Ejecucion paralela con rate limiting

Para busquedas masivas, usa el modulo de concurrencia que controla la tasa de peticiones:

```python
from congreso_ia import CongressClient, parallel_fetch

client = CongressClient()

# Buscar intervenciones de multiples diputados en paralelo
speakers = ["Sanchez", "Feijoo", "Abascal", "Diaz"]

results = parallel_fetch(
    func=lambda s: client.get_interventions(speaker=s),
    items=speakers,
    max_workers=4,           # Threads concurrentes
    requests_per_second=2.0, # Rate limit
    on_progress=lambda done, total, r: print(f"{done}/{total}")
)

for r in results:
    if r.success:
        print(f"{r.item}: {len(r.result)} intervenciones")
```

### Exportar a DataFrame

```python
from congreso_ia import interventions

# Obtener como pandas DataFrame
df = interventions.fetch(speaker="Abascal", as_df=True)
print(df.head())

# Exportar a CSV
df.to_csv("intervenciones_abascal.csv", index=False)
```

### CLI

```bash
# Descargar votaciones recientes
congreso scrape votes --latest

# Descargar intervenciones de una legislatura
congreso scrape interventions --legislature 15

# Exportar a diferentes formatos
congreso scrape votes --format parquet
congreso scrape votes --format csv
```

## Datos disponibles

| Recurso | Metodo | Campos principales |
|---------|--------|-------------------|
| Diputados | `get_deputies()` | nombre, partido, circunscripcion, grupo, email, avatar_url |
| Votaciones | `get_votes()` | fecha, titulo, resultado, votos individuales |
| Iniciativas | `get_initiatives()` | titulo, tipo, autor, expediente |
| Intervenciones | `get_interventions()` | orador, fecha, organo, tema, video_url, pdf_url |

## Filtros disponibles

### Diputados
- `party`: Filtrar por partido (ej. "PP", "PSOE")
- `constituency`: Filtrar por circunscripcion (ej. "Madrid")

### Votaciones
- `deputy`: Filtrar por nombre de diputado
- `party`: Filtrar por partido

### Intervenciones
- `speaker`: Nombre del orador (busqueda parcial)
- `organ`: Tipo de organo ("Pleno", "Comision")
- `legislature`: Numero de legislatura
- `start_date` / `end_date`: Rango de fechas

## Rate Limiting

El modulo `concurrent` proporciona control de tasa para no sobrecargar el servidor:

```python
from congreso_ia import RateLimiter

# Crear rate limiter: max 2 req/s, rafaga de 5
limiter = RateLimiter(requests_per_second=2.0, burst=5)

# Usar como context manager
with limiter:
    response = make_request()

# O manualmente
limiter.acquire()
response = make_request()
```

## Fuentes de datos

Los datos provienen del portal de Open Data del Congreso:

- Diputados: `congreso.es/es/opendata/diputados`
- Votaciones: `congreso.es/es/opendata/votaciones`
- Iniciativas: `congreso.es/es/opendata/iniciativas`
- Intervenciones: `congreso.es/es/opendata/intervenciones`

## Ejemplos

Ver la carpeta `examples/` para mas ejemplos:

```bash
python examples/fetch_deputies.py
python examples/fetch_votes.py
python examples/fetch_interventions.py
python examples/parallel_interventions.py
```

## Desarrollo

```bash
# Clonar repositorio
git clone https://github.com/congreso-ia/congreso-ia-scraper.git
cd congreso-ia-scraper

# Instalar en modo desarrollo
pip install -e ".[dev]"

# Ejecutar tests
pytest

# Linter
ruff check .
```

## Disclaimer Legal

Este proyecto **no es una fuente oficial** del Congreso de los Diputados. Es una herramienta de codigo abierto que utiliza exclusivamente fuentes de datos publicos del portal de Open Data. El uso de esta herramienta debe cumplir con los terminos de servicio de la web oficial del Congreso.

## Licencia

Distribuido bajo la licencia MIT. Ver `LICENSE` para mas informacion.
