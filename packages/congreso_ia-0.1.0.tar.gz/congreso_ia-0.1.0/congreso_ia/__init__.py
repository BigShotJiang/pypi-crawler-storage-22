"""
congreso-ia: Librería para acceder a datos públicos del Congreso de los Diputados de España.

Uso básico:
    from congreso_ia import CongressClient

    client = CongressClient()
    deputies = client.get_deputies()
    votes = client.get_votes()
    initiatives = client.get_initiatives()
    interventions = client.get_interventions(speaker="Sánchez")

Ejecución paralela:
    from congreso_ia import parallel_fetch, parallel_map

    results = parallel_fetch(
        func=lambda s: client.get_interventions(speaker=s),
        items=["Sánchez", "Feijóo"],
        requests_per_second=2.0
    )
"""

__version__ = "0.1.0"

# Client API
from congreso_ia.client import CongressClient

# Models
from congreso_ia.models.deputy import Deputy
from congreso_ia.models.vote import Vote, DeputyVote
from congreso_ia.models.initiative import Initiative
from congreso_ia.models.intervention import Intervention

# Concurrency
from congreso_ia.concurrent import (
    RateLimiter,
    parallel_fetch,
    parallel_map,
    TaskResult,
)

# Module-level fetch functions
from congreso_ia import interventions

__all__ = [
    # Version
    "__version__",
    # Client
    "CongressClient",
    # Models
    "Deputy",
    "Vote",
    "DeputyVote",
    "Initiative",
    "Intervention",
    # Concurrency
    "RateLimiter",
    "parallel_fetch",
    "parallel_map",
    "TaskResult",
    # Modules
    "interventions",
]
