import typer
from rich.console import Console
from rich.table import Table
from typing import Optional
from datetime import datetime

app = typer.Typer(help="CLI para interactuar con datos del Congreso de los Diputados de España.")
scrape_app = typer.Typer(help="Comandos para scrapear datos.")
app.add_typer(scrape_app, name="scrape")

console = Console()

@scrape_app.command("interventions")
def scrape_interventions(
    legislature: int = typer.Option(15, help="Número de la legislatura."),
    since: Optional[str] = typer.Option(None, help="Fecha de inicio (YYYY-MM-DD)."),
    output: str = typer.Option("interventions.parquet", help="Archivo de salida.")
):
    """Scrapea intervenciones del Diario de Sesiones."""
    console.print(f"[bold blue]Scrapeando intervenciones...[/bold blue]")
    console.print(f"Legislatura: {legislature}, Desde: {since}")
    # Aquí iría la llamada a la lógica de scraping
    console.print(f"[bold green]Éxito![/bold green] Datos guardados en {output}")

@scrape_app.command("votes")
def scrape_votes(
    latest: bool = typer.Option(True, help="Obtener solo las votaciones más recientes."),
    output: str = typer.Option("votes.parquet", help="Archivo de salida.")
):
    """Scrapea resultados de votaciones."""
    console.print(f"[bold blue]Scrapeando votaciones...[/bold blue]")
    # Aquí iría la llamada a la lógica de scraping
    console.print(f"[bold green]Éxito![/bold green] Datos guardados en {output}")

@app.command("export")
def export_data(
    format: str = typer.Option("parquet", help="Formato de salida (parquet, csv, json)."),
    output_dir: str = typer.Option("data/", help="Directorio de salida.")
):
    """Exporta datos previamente locales a otros formatos."""
    console.print(f"Exportando datos a [bold]{format}[/bold] en {output_dir}")

if __name__ == "__main__":
    app()
