from typing import List, Optional
from datetime import date
from .sources.congress import CongressFetcher
from .models.deputy import Deputy
from .models.vote import Vote
from .models.initiative import Initiative
from .models.intervention import Intervention

def normalize_text(text: str) -> str:
    """Elimina acentos y convierte a minúsculas para comparaciones robustas."""
    if not text:
        return ""
    import unicodedata
    text = "".join(
        c for c in unicodedata.normalize('NFD', text)
        if unicodedata.category(c) != 'Mn'
    )
    return text.lower()

class CongressClient:
    """
    Cliente de alto nivel para interactuar con los datos del Congreso.
    Abstrae la complejidad de fetchers y proporciona métodos con filtrado integrado.
    """
    
    def __init__(self):
        self.fetcher = CongressFetcher()
        
    def get_deputies(self, party: Optional[str] = None, constituency: Optional[str] = None) -> List[Deputy]:
        """
        Obtiene diputados activos con filtros opcionales.
        """
        deputies = self.fetcher.fetch_active_deputies()
        
        if party:
            p_norm = normalize_text(party)
            deputies = [d for d in deputies if d.party and p_norm in normalize_text(d.party)]
        if constituency:
            c_norm = normalize_text(constituency)
            deputies = [d for d in deputies if d.constituency and c_norm in normalize_text(d.constituency)]
            
        return deputies

    def get_votes(self, deputy: Optional[str] = None, party: Optional[str] = None) -> List[Vote]:
        """
        Obtiene votaciones recientes. Si se especifica deputy o party, 
        se filtran los resultados para mostrar solo donde hubo participación relevante.
        """
        votes = self.fetcher.fetch_recent_votes()
        
        if deputy or party:
            filtered_votes = []
            dep_words = normalize_text(deputy).split() if deputy else []
            party_norm = normalize_text(party) if party else None
            
            for v in votes:
                # Filtrar la lista interna de votos del objeto Vote
                v.votes = [dv for dv in v.votes if 
                          (not deputy or all(word in normalize_text(dv.deputy_name) for word in dep_words)) and
                          (not party or (dv.group and party_norm in normalize_text(dv.group)))]
                
                # Solo incluimos la votación si tiene votos que coincidan con el filtro
                if v.votes:
                    filtered_votes.append(v)
            return filtered_votes
            
        return votes

    def get_initiatives(self, group: Optional[str] = None) -> List[Initiative]:
        """
        Obtiene iniciativas recientes con filtro por grupo parlamentario / autor.
        """
        initiatives = self.fetcher.fetch_initiatives()
        if group:
            initiatives = [i for i in initiatives if i.author and group.lower() in i.author.lower()]
        return initiatives

    def get_interventions(
        self,
        speaker: Optional[str] = None,
        organ: Optional[str] = None,
        legislature: Optional[int] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
    ) -> List[Intervention]:
        """
        Obtiene intervenciones del Congreso con filtros opcionales.

        Args:
            speaker: Nombre del orador (búsqueda parcial, ej. "Pedro Sánchez", "Sánchez").
            organ: Tipo de órgano (ej. "Pleno", "Comisión").
            legislature: Número de legislatura (por defecto la actual).
            start_date: Fecha de inicio.
            end_date: Fecha de fin.

        Returns:
            Lista de Intervention que coinciden con los filtros.
        """
        interventions = self.fetcher.fetch_interventions(legislature=legislature)

        if speaker:
            speaker_norm = normalize_text(speaker)
            # Buscar por cualquier palabra del nombre
            speaker_words = speaker_norm.split()
            interventions = [
                i for i in interventions
                if all(word in normalize_text(i.speaker) for word in speaker_words)
            ]

        if organ:
            organ_norm = normalize_text(organ)
            interventions = [
                i for i in interventions
                if i.organ and organ_norm in normalize_text(i.organ)
            ]

        if start_date:
            interventions = [i for i in interventions if i.session_date >= start_date]

        if end_date:
            interventions = [i for i in interventions if i.session_date <= end_date]

        return interventions
