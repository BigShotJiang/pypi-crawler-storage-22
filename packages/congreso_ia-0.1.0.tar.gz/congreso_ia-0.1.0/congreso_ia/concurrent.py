"""
Módulo de concurrencia para ejecutar operaciones en paralelo con rate limiting.

Uso como lambdas:
    from congreso_ia.concurrent import parallel_fetch, RateLimiter

    # Buscar intervenciones de múltiples diputados en paralelo
    speakers = ["Sánchez", "Feijóo", "Abascal", "Díaz"]
    results = parallel_fetch(
        func=lambda s: client.get_interventions(speaker=s),
        items=speakers,
        max_workers=4,
        requests_per_second=2.0
    )
"""
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TypeVar, Callable, List, Dict, Any, Optional, Tuple
from dataclasses import dataclass

T = TypeVar('T')
R = TypeVar('R')


class RateLimiter:
    """
    Rate limiter thread-safe usando token bucket algorithm.

    Args:
        requests_per_second: Número máximo de requests por segundo.
        burst: Número máximo de requests que se pueden hacer en ráfaga.
    """

    def __init__(self, requests_per_second: float = 2.0, burst: int = 5):
        self.requests_per_second = requests_per_second
        self.burst = burst
        self.tokens = burst
        self.last_update = time.monotonic()
        self._lock = threading.Lock()

    def acquire(self, timeout: Optional[float] = None) -> bool:
        """
        Adquiere un token para hacer una request.
        Bloquea hasta que haya un token disponible o se agote el timeout.

        Args:
            timeout: Tiempo máximo de espera en segundos. None = esperar indefinidamente.

        Returns:
            True si se adquirió el token, False si se agotó el timeout.
        """
        deadline = None if timeout is None else time.monotonic() + timeout

        while True:
            with self._lock:
                now = time.monotonic()
                # Añadir tokens según el tiempo transcurrido
                elapsed = now - self.last_update
                self.tokens = min(self.burst, self.tokens + elapsed * self.requests_per_second)
                self.last_update = now

                if self.tokens >= 1:
                    self.tokens -= 1
                    return True

                # Calcular tiempo de espera hasta el próximo token
                wait_time = (1 - self.tokens) / self.requests_per_second

            # Verificar timeout
            if deadline is not None:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                wait_time = min(wait_time, remaining)

            time.sleep(wait_time)

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *args):
        pass


@dataclass
class TaskResult:
    """Resultado de una tarea paralela."""
    item: Any
    result: Any = None
    error: Optional[Exception] = None
    success: bool = True


def parallel_fetch(
    func: Callable[[T], R],
    items: List[T],
    max_workers: int = 4,
    requests_per_second: float = 2.0,
    burst: int = 5,
    timeout_per_task: Optional[float] = 60.0,
    on_progress: Optional[Callable[[int, int, TaskResult], None]] = None,
) -> List[TaskResult]:
    """
    Ejecuta una función en paralelo sobre una lista de items con rate limiting.

    Args:
        func: Función a ejecutar para cada item (lambda style).
        items: Lista de items a procesar.
        max_workers: Número máximo de threads concurrentes.
        requests_per_second: Límite de requests por segundo.
        burst: Ráfaga máxima permitida.
        timeout_per_task: Timeout por tarea individual en segundos.
        on_progress: Callback opcional (completed, total, result) para reportar progreso.

    Returns:
        Lista de TaskResult con los resultados (en el mismo orden que items).

    Example:
        >>> speakers = ["Sánchez", "Feijóo", "Abascal"]
        >>> results = parallel_fetch(
        ...     func=lambda s: client.get_interventions(speaker=s),
        ...     items=speakers,
        ...     max_workers=3,
        ...     requests_per_second=2.0
        ... )
        >>> for r in results:
        ...     print(f"{r.item}: {len(r.result)} intervenciones")
    """
    rate_limiter = RateLimiter(requests_per_second, burst)
    results: Dict[int, TaskResult] = {}
    total = len(items)
    completed = 0

    def execute_task(idx: int, item: T) -> Tuple[int, TaskResult]:
        # Esperar por el rate limiter
        rate_limiter.acquire()

        try:
            result = func(item)
            return idx, TaskResult(item=item, result=result, success=True)
        except Exception as e:
            return idx, TaskResult(item=item, error=e, success=False)

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(execute_task, idx, item): idx
            for idx, item in enumerate(items)
        }

        for future in as_completed(futures, timeout=timeout_per_task * len(items) if timeout_per_task else None):
            try:
                idx, task_result = future.result(timeout=timeout_per_task)
                results[idx] = task_result
                completed += 1

                if on_progress:
                    on_progress(completed, total, task_result)

            except Exception as e:
                idx = futures[future]
                results[idx] = TaskResult(item=items[idx], error=e, success=False)
                completed += 1

    # Devolver en orden original
    return [results[i] for i in range(len(items))]


def parallel_map(
    func: Callable[[T], R],
    items: List[T],
    max_workers: int = 4,
    requests_per_second: float = 2.0,
) -> List[R]:
    """
    Versión simplificada de parallel_fetch que devuelve solo los resultados.
    Lanza excepción si alguna tarea falla.

    Args:
        func: Función a ejecutar para cada item.
        items: Lista de items a procesar.
        max_workers: Número máximo de threads concurrentes.
        requests_per_second: Límite de requests por segundo.

    Returns:
        Lista de resultados (en el mismo orden que items).

    Raises:
        Exception: Si alguna tarea falla.
    """
    results = parallel_fetch(func, items, max_workers, requests_per_second)

    for r in results:
        if not r.success:
            raise r.error

    return [r.result for r in results]
