import pandas as pd
from typing import Optional, List, Union
from congreso_ia.models.intervention import Intervention
from congreso_ia.sources.congress import CongressFetcher
from congreso_ia.storage.exporter import Exporter


def fetch(
    legislature: Optional[int] = None,
    speaker: Optional[str] = None,
    organ: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    as_df: bool = True
) -> Union[pd.DataFrame, List[Intervention]]:
    """
    Busca y retorna intervenciones del Congreso desde el Open Data.

    Args:
        legislature: Número de la legislatura (por defecto, la actual).
        speaker: Filtrar por nombre del orador (búsqueda parcial, sin acentos).
        organ: Filtrar por órgano (Pleno, Comisión, etc.).
        start_date: Fecha de inicio (YYYY-MM-DD).
        end_date: Fecha fin (YYYY-MM-DD).
        as_df: Si es True, retorna un pandas.DataFrame. Si es False, una lista de modelos Pydantic.

    Returns:
        DataFrame o lista de Intervention con las intervenciones encontradas.
    """
    fetcher = CongressFetcher()
    interventions = fetcher.fetch_interventions(legislature=legislature)

    # Filtrar por orador
    if speaker:
        speaker_norm = _normalize_text(speaker)
        interventions = [
            i for i in interventions
            if speaker_norm in _normalize_text(i.speaker)
        ]

    # Filtrar por órgano
    if organ:
        organ_norm = _normalize_text(organ)
        interventions = [
            i for i in interventions
            if i.organ and organ_norm in _normalize_text(i.organ)
        ]

    # Filtrar por rango de fechas
    if start_date:
        from datetime import date as date_type
        start = date_type.fromisoformat(start_date)
        interventions = [i for i in interventions if i.session_date >= start]

    if end_date:
        from datetime import date as date_type
        end = date_type.fromisoformat(end_date)
        interventions = [i for i in interventions if i.session_date <= end]

    if as_df:
        return Exporter.to_dataframe(interventions)
    return interventions


def _normalize_text(text: str) -> str:
    """Elimina acentos y convierte a minúsculas para comparaciones robustas."""
    if not text:
        return ""
    import unicodedata
    text = "".join(
        c for c in unicodedata.normalize('NFD', text)
        if unicodedata.category(c) != 'Mn'
    )
    return text.lower()
