from datetime import date
from typing import Optional, List
from pydantic import BaseModel, Field

class DeputyTerm(BaseModel):
    """
    Representa la participación de un diputado en una legislatura específica.
    """
    legislature: int
    circunscripcion: str = Field(..., description="Provincia o ciudad por la que fue electo")
    group: str = Field(..., description="Grupo parlamentario en esa legislatura")
    start_date: Optional[date] = None
    end_date: Optional[date] = None

class Deputy(BaseModel):
    """
    Representa a un Diputado del Congreso con su historial.
    Inspirado en seguimiento-politico/congreso-scrapper.
    """
    id: str = Field(..., description="ID interno/oficial del diputado")
    name: str = Field(..., description="Nombre de pila")
    surnames: str = Field(..., description="Apellidos")
    gender: Optional[str] = Field(None, description="Género (Hombre/Mujer)")
    birthday: Optional[date] = Field(None, description="Fecha de nacimiento")
    profession: Optional[str] = Field(None, description="Profesión declarada")
    twitter: Optional[str] = None
    email: Optional[str] = None
    avatar_url: Optional[str] = Field(None, description="URL de la foto del diputado")
    active: bool = True
    party: Optional[str] = Field(None, description="Formación electoral")
    constituency: Optional[str] = Field(None, description="Circunscripción actual")
    group: Optional[str] = Field(None, description="Grupo parlamentario actual")
    history: List[DeputyTerm] = Field(default_factory=list, description="Historial por legislatura")
    url: Optional[str] = Field(None, description="Enlace al perfil oficial")

    @property
    def full_name(self) -> str:
        return f"{self.name} {self.surnames}"

    class Config:
        from_attributes = True
