from datetime import date
from typing import Optional
from pydantic import BaseModel, Field

class Initiative(BaseModel):
    """
    Representa una iniciativa parlamentaria (Proposición de Ley, Proyecto de Ley, etc.).
    """
    id: Optional[str] = Field(None, description="ID único")
    title: str = Field(..., description="Título de la iniciativa")
    reference: Optional[str] = Field(None, description="Número de expediente")
    type: str = Field(..., description="Tipo de iniciativa (e.g. Proposición de Ley)")
    author: Optional[str] = Field(None, description="Autor o Grupo Parlamentario")
    entry_date: Optional[date] = Field(None, description="Fecha de presentación")
    url: Optional[str] = Field(None, description="URL a la ficha oficial")
    
    class Config:
        from_attributes = True
