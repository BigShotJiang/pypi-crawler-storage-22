from datetime import date, time
from typing import Optional
from pydantic import BaseModel, Field, ConfigDict


class Intervention(BaseModel):
    """
    Representa una intervención individual en el Congreso de los Diputados.
    Datos obtenidos del Open Data del Congreso (intervenciones).
    """
    model_config = ConfigDict(from_attributes=True)

    # Identificación de la sesión
    legislature: int = Field(..., description="Número de la legislatura (ej. 15)")
    session_date: date = Field(..., description="Fecha de la sesión")
    organ: str = Field(..., description="Órgano (Pleno, Comisión, etc.)")
    phase: Optional[str] = Field(None, description="Fase del procedimiento")

    # Orador
    speaker: str = Field(..., description="Nombre completo del orador (Apellidos, Nombre)")
    group: Optional[str] = Field(None, description="Grupo parlamentario del orador")
    role: Optional[str] = Field(None, description="Cargo del orador (Diputado/a, Presidente, Ministro/a)")

    # Intervención
    intervention_type: Optional[str] = Field(None, description="Tipo de intervención")
    start_time: Optional[time] = Field(None, description="Hora de inicio de la intervención")
    end_time: Optional[time] = Field(None, description="Hora de fin de la intervención")
    topic: Optional[str] = Field(None, description="Tema/objeto de la iniciativa en discusión")

    # Enlaces
    video_url: Optional[str] = Field(None, description="URL del vídeo de la intervención")
    video_download_url: Optional[str] = Field(None, description="URL de descarga directa del vídeo")
    text_url: Optional[str] = Field(None, description="URL al texto íntegro de la intervención")
    pdf_url: Optional[str] = Field(None, description="URL al PDF del Diario de Sesiones con página")
