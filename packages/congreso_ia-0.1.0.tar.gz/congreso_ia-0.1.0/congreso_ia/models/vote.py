from datetime import date
from typing import Dict, Optional, List
from pydantic import BaseModel, Field

class VoteDetail(BaseModel):
    """
    Detalle de un voto individual o por grupo.
    """
    group: str
    yes: int = 0
    no: int = 0
    abstain: int = 0
    no_vote: int = Field(0, alias="noVotan")

class DeputyVote(BaseModel):
    """
    Voto individual de un diputado.
    """
    seat: int = Field(..., description="Asiento del diputado")
    deputy_name: str = Field(..., description="Nombre del diputado")
    group: str = Field(..., description="Grupo parlamentario")
    vote: str = Field(..., description="Voto emitido (Sí/No/Abstención/No vota)")

class Vote(BaseModel):
    """
    Representa el resultado de una votación en el Congreso.
    Refinado con conceptos de proyecto-colibri (Sesión, detalles de recuento).
    """
    vote_id: str = Field(..., description="ID único de la votación")
    session_number: int = Field(..., description="Número de la sesión")
    vote_number: int = Field(..., description="Número de la votación dentro de la sesión")
    session_date: date = Field(..., description="Fecha de la votación", alias="fecha")
    
    initiative_title: str = Field(..., description="Título de la iniciativa votada")
    expediente: Optional[str] = Field(None, description="Número de expediente")
    
    result: str = Field(..., description="Resultado (Aprobado/Rechazado)")
    attendees: int = Field(0, description="Número de asistentes")
    total_yes: int
    total_no: int
    total_abstain: int
    total_no_vote: int
    
    assent: bool = Field(False, description="Votación por asentimiento")
    
    results_by_group: List[VoteDetail] = Field(default_factory=list)
    votes: List[DeputyVote] = Field(default_factory=list, description="Lista de votos individuales")

    class Config:
        from_attributes = True
        populate_by_name = True
