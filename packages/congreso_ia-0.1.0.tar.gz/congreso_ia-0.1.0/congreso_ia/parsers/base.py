from abc import ABC, abstractmethod
from typing import Any, List, TypeVar, Generic
from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)

class BaseParser(ABC, Generic[T]):
    """
    Clase base abstracta para todos los parsers.
    Cada parser debe transformar una fuente (HTML/PDF/XML) en un modelo Pydantic o lista de modelos.
    """
    @abstractmethod
    def parse(self, source: Any) -> List[T]:
        """
        Extrae datos de la fuente y los convierte en una lista de objetos del modelo.
        """
        pass
