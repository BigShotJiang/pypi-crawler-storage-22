import httpx
from typing import Optional, Dict, Any

class BaseFetcher:
    """
    Clase base para realizar peticiones HTTP a la web del Congreso.
    Maneja reintentos, timeouts y logs básicos.
    """
    def __init__(self, base_url: str = "https://www.congreso.es"):
        self.base_url = base_url
        self.client = httpx.Client(
            base_url=self.base_url,
            timeout=30.0,
            follow_redirects=True,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            }
        )

    def fetch_html(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> str:
        """Obtiene el HTML de un endpoint."""
        response = self.client.get(endpoint, params=params)
        response.raise_for_status()
        return response.text

    def fetch_xml(self, endpoint: str) -> Any:
        """Obtiene y parsea XML de un endpoint."""
        import xml.etree.ElementTree as ET
        response = self.client.get(endpoint)
        response.raise_for_status()
        return ET.fromstring(response.content)

    def fetch_json(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Obtiene y parsea JSON de un endpoint."""
        response = self.client.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()
