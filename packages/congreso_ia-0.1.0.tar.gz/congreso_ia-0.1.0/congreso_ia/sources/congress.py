from typing import List, Optional
from datetime import datetime, date, time
import re
from bs4 import BeautifulSoup
from .base import BaseFetcher
from ..models.deputy import Deputy
from ..models.vote import Vote
from ..models.intervention import Intervention

class CongressFetcher(BaseFetcher):
    """
    Fetcher especializado para el Congreso de los Diputados.
    Capaz de descubrir URLs dinámicas y parsear los formatos específicos (XML/JSON).
    """
    
    def fetch_active_deputies(self) -> List[Deputy]:
        """
        Obtiene la lista de diputados activos parseando la página de Open Data 
        para encontrar el enlace al archivo JSON más reciente.
        """
        landing_url = f"{self.base_url}/es/opendata/diputados"
        html = self.fetch_html(landing_url)
        soup = BeautifulSoup(html, 'html.parser')
        
        # Buscar enlace a JSON de DiputadosActivos
        json_url = None
        for a in soup.find_all('a', href=True):
            if "DiputadosActivos" in a['href'] and a['href'].endswith('.json'):
                json_url = a['href']
                break
        
        if not json_url:
            raise ValueError("No se encontró el archivo JSON de diputados activos")
            
        if not json_url.startswith('http'):
            json_url = f"{self.base_url}{json_url}"
            
        data = self.fetch_json(json_url)
        
        # El JSON suele tener una estructura envolvente.
        # En la implementación real revisada, suelen ser una lista directa o lista bajo clave.
        # Verificamos.
        deputies_data = data
        if isinstance(data, dict):
             # Posibles claves: 'diputados', 'sequi:diputados', etc.
             for key in ['diputados', 'active_deputies', 'data']:
                 if key in data:
                     deputies_data = data[key]
                     break
        
        if not isinstance(deputies_data, list):
            # Si sigue siendo dict, quizás es el item único o estructura desconocida
            # En caso real, suele ser una lista.
            pass

        deputies = []
        for item in deputies_data:
            # Keys observed: 'NOMBRE', 'CIRCUNSCRIPCION', 'FORMACIONELECTORAL', 'GRUPOPARLAMENTARIO'
            # 'NOMBRE' format: "Abades Martínez, Cristina"
            
            raw_name = item.get('NOMBRE') or item.get('nombre') or ''
            surnames = ""
            name = ""
            if ',' in raw_name:
                parts = raw_name.split(',', 1)
                surnames = parts[0].strip()
                name = parts[1].strip()
            else:
                name = raw_name
                
            # Generate ID from name if missing
            dep_id = item.get('id') or item.get('apellidosNombre')
            if not dep_id and raw_name:
                import hashlib
                dep_id = hashlib.md5(raw_name.encode('utf-8')).hexdigest()[:10]

            dep = Deputy(
                id=str(dep_id) if dep_id else "unknown",
                name=name,
                surnames=surnames,
                party=item.get('FORMACIONELECTORAL') or item.get('nombreFormacion', ''),
                constituency=item.get('CIRCUNSCRIPCION') or item.get('nombreCircunscripcion', ''),
                email=item.get('email'), # Not observed in sample
                avatar_url=item.get('urlFoto'), # Not observed
                group=item.get('GRUPOPARLAMENTARIO') or item.get('nombreGrupo', '')
            )
            deputies.append(dep)
            
        return deputies

    def fetch_recent_votes(self) -> List[Vote]:
        """
        Obtiene las votaciones de la sesión más reciente listada en el portal.
        """
        landing_url = f"{self.base_url}/es/opendata/votaciones"
        html = self.fetch_html(landing_url)
        soup = BeautifulSoup(html, 'html.parser')
        
        # 1. Buscar XMLs directamente en la landing
        vote_links = []
        for a in soup.find_all('a', href=True):
            href = a['href']
            if "VOT_" in href and href.lower().endswith('.xml'):
                if not href.startswith('http'):
                    href = f"https://www.congreso.es{href}" if href.startswith('/') else f"{self.base_url}{href}"
                if href not in vote_links:
                    vote_links.append(href)
        
        # 2. Si hay pocos, buscar páginas de sesiones para completar
        if len(vote_links) < 5:
            session_pages = []
            for a in soup.find_all('a', href=True):
                href = a['href']
                if "idSesion" in href or "p_p_id=votaciones" in href:
                    if not href.startswith('http'):
                        href = f"{self.base_url}{href}"
                    if href not in session_pages:
                        session_pages.append(href)
            
            for s_url in session_pages[:2]:
                try:
                    s_html = self.fetch_html(s_url)
                    s_soup = BeautifulSoup(s_html, 'html.parser')
                    for a in s_soup.find_all('a', href=True):
                        href = a['href']
                        if "VOT_" in href and href.lower().endswith('.xml'):
                            if not href.startswith('http'):
                                href = f"https://www.congreso.es{href}" if href.startswith('/') else href
                            if href not in vote_links:
                                vote_links.append(href)
                except:
                    continue

        # 3. Parsear
        votes = []
        for xml_url in vote_links[:15]:
            try:
                xml_root = self.fetch_xml(xml_url)
                vote = self._parse_vote_xml(xml_root, xml_url)
                if vote:
                    votes.append(vote)
            except Exception as e:
                print(f"DEBUG: Parse error on {xml_url}: {e}")
                
        return votes

    def _parse_vote_xml(self, root, url: str) -> Optional[Vote]:
        """Parsea el XML de una votación individual a un objeto Vote."""
        info = root.find('Informacion')
        totales = root.find('Totales')
        
        if info is None or totales is None:
            return None
            
        # Parse date DD/MM/YYYY
        date_str = info.find('Fecha').text
        session_date = datetime.strptime(date_str, "%d/%m/%Y").date()
        
        from ..models.vote import Vote, DeputyVote
        
        # Parse individual votes
        deputy_votes = []
        votaciones = root.find('Votaciones')
        if votaciones:
            for v in votaciones.findall('Votacion'):
                dep_vote = DeputyVote(
                    seat=int(v.find('Asiento').text),
                    deputy_name=v.find('Diputado').text,
                    group=v.find('Grupo').text,
                    vote=v.find('Voto').text
                )
                deputy_votes.append(dep_vote)

        vote = Vote(
            vote_id=url.split('/')[-1].replace('.xml', ''), # Derivar ID del nombre archivo
            session_number=int(info.find('Sesion').text),
            vote_number=int(info.find('NumeroVotacion').text),
            session_date=session_date,
            initiative_title=info.find('Titulo').text,
            expediente=info.find('TextoExpediente').text,
            result="Aprobado" if int(totales.find('AFavor').text) > int(totales.find('EnContra').text) else "Rechazado", # Lógica simplificada
            attendees=int(totales.find('Presentes').text),
            total_yes=int(totales.find('AFavor').text),
            total_no=int(totales.find('EnContra').text),
            total_abstain=int(totales.find('Abstenciones').text),
            total_no_vote=int(totales.find('NoVotan').text),
            assent=totales.find('Asentimiento').text.lower() == "si",
            votes=deputy_votes
        )
        return vote

    def fetch_initiatives(self) -> List["Initiative"]:
        """
        Obtiene las iniciativas legislativas recientes (Proposiciones de Ley, Proyectos de Ley).
        Combina múltiples fuentes (Proyectos, Proposiciones).
        """
        from ..models.initiative import Initiative
        
        # Fuentes principales identificadas
        sources = [
            ("Proyectos de Ley", "ProyectosDeLey"),
            ("Proposiciones de Ley", "ProposicionesDeLey")
        ]
        
        landing_url = f"{self.base_url}/es/opendata/iniciativas"
        html = self.fetch_html(landing_url)
        soup = BeautifulSoup(html, 'html.parser')
        
        initiatives = []
        
        for type_name, keyword in sources:
            # Buscar enlace JSON
            json_url = None
            for a in soup.find_all('a', href=True):
                if keyword in a['href'] and a['href'].endswith('.json'):
                    json_url = a['href']
                    break
            
            if json_url:
                if not json_url.startswith('http'):
                    json_url = f"{self.base_url}{json_url}"
                
                try:
                    data = self.fetch_json(json_url)
                    
                    # Extraer lista base
                    items = []
                    if isinstance(data, dict):
                        for k in data.keys():
                            if isinstance(data[k], list):
                                items = data[k]
                                break
                    elif isinstance(data, list):
                        items = data
                        
                    for item in items:
                        # Mapeo basado en campos reales observados
                        init = Initiative(
                           id=item.get('id') or item.get('NUMEXPEDIENTE'),
                           title=item.get('OBJETO') or item.get('titulo') or '',
                           reference=item.get('NUMEXPEDIENTE') or item.get('numeroExpediente'),
                           type=type_name,
                           author=item.get('AUTOR') or item.get('autor'),
                           url=item.get('url') or item.get('URL')
                        )
                        initiatives.append(init)
                        
                except Exception as e:
                    print(f"Error fetching {type_name}: {e}")

        return initiatives

    def fetch_interventions(self, legislature: Optional[int] = None) -> List[Intervention]:
        """
        Obtiene las intervenciones del Open Data del Congreso.

        Args:
            legislature: Filtrar por legislatura (por defecto usa la actual).

        Returns:
            Lista de objetos Intervention.
        """
        landing_url = f"{self.base_url}/es/opendata/intervenciones"
        html = self.fetch_html(landing_url)
        soup = BeautifulSoup(html, 'html.parser')

        # Buscar el JSON de intervenciones (preferir cronológico)
        json_url = None
        for a in soup.find_all('a', href=True):
            href = a['href']
            if 'IntervencionesCronologicamente' in href and href.endswith('.json'):
                json_url = href
                break

        # Fallback al otro formato si no se encuentra
        if not json_url:
            for a in soup.find_all('a', href=True):
                href = a['href']
                if 'Intervenciones' in href and href.endswith('.json'):
                    json_url = href
                    break

        if not json_url:
            raise ValueError("No se encontró el archivo JSON de intervenciones")

        if not json_url.startswith('http'):
            json_url = f"{self.base_url}{json_url}"

        data = self.fetch_json(json_url)

        interventions = []
        for item in data:
            intervention = self._parse_intervention(item)
            if intervention:
                # Filtrar por legislatura si se especifica
                if legislature is None or intervention.legislature == legislature:
                    interventions.append(intervention)

        return interventions

    def _parse_intervention(self, item: dict) -> Optional[Intervention]:
        """Parsea un elemento del JSON de intervenciones."""
        try:
            # Parsear legislatura: "Leg.15" -> 15
            leg_str = item.get('LEGISLATURA', '')
            legislature = int(re.search(r'\d+', leg_str).group()) if leg_str else 0

            # Parsear fecha: "29/02/2024" -> date
            session_str = item.get('SESION', '')
            session_date = datetime.strptime(session_str, "%d/%m/%Y").date() if session_str else date.today()

            # Parsear orador y grupo: "Requena Ruiz, Juan Diego (GP)" -> speaker, group
            orador = item.get('ORADOR', '')
            speaker = orador
            group = None
            if '(' in orador and orador.endswith(')'):
                match = re.match(r'^(.+?)\s*\(([^)]+)\)$', orador)
                if match:
                    speaker = match.group(1).strip()
                    group = match.group(2).strip()

            # Parsear horas: "10:40" -> time
            start_time = None
            end_time = None
            inicio = item.get('INICIOINTERVENCION', '')
            fin = item.get('FININTERVENCION', '')
            if inicio and ':' in inicio:
                parts = inicio.split(':')
                start_time = time(int(parts[0]), int(parts[1]))
            if fin and ':' in fin:
                parts = fin.split(':')
                end_time = time(int(parts[0]), int(parts[1]))

            return Intervention(
                legislature=legislature,
                session_date=session_date,
                organ=item.get('ORGANO', ''),
                phase=item.get('FASE'),
                speaker=speaker,
                group=group,
                role=item.get('CARGOORADOR'),
                intervention_type=item.get('TIPOINTERVENCION'),
                start_time=start_time,
                end_time=end_time,
                topic=item.get('OBJETOINICIATIVA'),
                video_url=item.get('ENLACEDIFERIDO'),
                video_download_url=item.get('ENLACEDESCARGADIRECTA'),
                text_url=item.get('ENLACETEXTOINTEGRO'),
                pdf_url=item.get('ENLACEPDF'),
            )
        except Exception as e:
            print(f"Error parsing intervention: {e}")
            return None
