import pandas as pd
from pathlib import Path
from typing import List, Union
from pydantic import BaseModel

class Exporter:
    """
    Exporta listas de modelos Pydantic o DataFrames a múltiples formatos.
    """
    @staticmethod
    def to_dataframe(data: List[BaseModel]) -> pd.DataFrame:
        """Convierte una lista de modelos Pydantic a pandas DataFrame."""
        return pd.DataFrame([item.dict() for item in data])

    @staticmethod
    def save(df: pd.DataFrame, path: Union[str, Path], format: str = "parquet"):
        """
        Guarda un DataFrame en el formato especificado.
        Formatos soportados: csv, json, parquet.
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        if format == "parquet":
            df.to_parquet(path, index=False)
        elif format == "csv":
            df.to_csv(path, index=False)
        elif format == "json":
            df.to_json(path, orient="records", indent=4, force_ascii=False)
        else:
            raise ValueError(f"Formato no soportado: {format}")
