import pandas as pd
from typing import Optional, List, Union
from datetime import date
from congreso_ia.models.vote import Vote
from congreso_ia.storage.exporter import Exporter

def fetch(
    latest: bool = True,
    start_date: Optional[str] = None,
    as_df: bool = True
) -> Union[pd.DataFrame, List[Vote]]:
    """
    Busca y retorna resultados de votaciones.
    
    Args:
        latest: Si es True, retorna solo la última votación disponible.
        start_date: Fecha de inicio (YYYY-MM-DD).
        as_df: Si es True, retorna un pandas.DataFrame.
    """
    # Mock de datos para demostración
    mock_data = [
        Vote(
            vote_id="V001",
            date=date.today(),
            initiative_title="Propuesta de Ley Orgánica de amnistía",
            result="Aprobada",
            total_yes=178,
            total_no=172,
            total_abstain=0,
            total_no_vote=0,
            results_by_group=[]
        )
    ]
    
    if as_df:
        return Exporter.to_dataframe(mock_data)
    return mock_data
