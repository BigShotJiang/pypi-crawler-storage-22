# Connection API for checkers


# Connection Api 
Connection Api  allows you to send HTTP/1.1 Connection  extremely easily.

Installing Connection Api  and Supported Versions
Connection Api  is available on PyPI:

$ python -m pip install connections-api-requests

# Supported Features & Best–Practices Like :

Keep-Alive & Connection Pooling
International Domains and URLs
Sessions with Cookie Persistence
Browser-style TLS/SSL Verification
Basic & Digest Authentication
Familiar dict–like Cookies
Automatic Content Decompression and Decoding
Multi-part File Uploads
SOCKS Proxy Support
Connection Timeouts
Streaming Downloads
Automatic honoring of .netrc
