"""co-ai: AI coding agent built with ConnectOnion framework."""

from connectonion.cli.co_ai.agent import create_coding_agent

__version__ = "0.1.0"
__all__ = ["create_coding_agent"]
