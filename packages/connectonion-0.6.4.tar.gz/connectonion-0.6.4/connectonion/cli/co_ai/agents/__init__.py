"""Sub-agents for OO."""

from connectonion.cli.co_ai.agents.registry import SUBAGENTS, get_subagent

__all__ = ["SUBAGENTS", "get_subagent"]
