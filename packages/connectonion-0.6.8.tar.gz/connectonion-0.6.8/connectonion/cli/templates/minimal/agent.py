"""Minimal ConnectOnion agent template."""

from connectonion import Agent


def calculator(expression: str) -> float:
    """Evaluate a math expression. Example: "5*5" returns 25."""
    return eval(expression)


agent = Agent(
    name="calculator-agent",
    system_prompt="prompt.md",
    tools=[calculator],
)

if __name__ == "__main__":
    result = agent.input("what is 5 * 5?")
    print(result)
