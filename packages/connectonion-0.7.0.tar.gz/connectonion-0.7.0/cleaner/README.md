# Minimal ConnectOnion Agent

The simplest way to get started with ConnectOnion.

## Quick Start

```bash
# Create new project
co create calculator

# Or initialize in existing folder
co init

# Run the agent
python agent.py
```

## Project Structure

```
calculator/
├── .co/           # ConnectOnion metadata
├── .env           # API keys (auto-copied from ~/.co/)
├── agent.py       # Your agent code
└── prompt.md      # System prompt
```

## Files

**`agent.py`** - Agent with tools:
```python
from connectonion import Agent

def calculator(expression: str) -> float:
    """Evaluate a math expression."""
    return eval(expression)

agent = Agent(
    name="calculator-agent",
    system_prompt="prompt.md",
    tools=[calculator],
)
```

**`prompt.md`** - System prompt (edit this to change agent behavior)

## Run

```bash
python agent.py
```

## Next Steps

- Edit `prompt.md` to change agent behavior
- Add more tools to `agent.py`
- Try other templates: `co create browser-bot --template playwright`

## Learn More

- [Documentation](https://docs.connectonion.com)
- [Discord Community](https://discord.gg/4xfD9k8AUF)
