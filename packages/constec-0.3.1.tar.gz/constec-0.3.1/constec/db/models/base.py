import uuid
from django.db import models


class UUIDModel(models.Model):
    """Base model with UUID as primary key.

    All Constec models inherit from this to ensure consistent
    UUID-based primary keys across the platform.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    class Meta:
        abstract = True
