# Generated manually on 2026-02-03 - Rename User to CompanyUser

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('constec_db', '0006_automation_trigger_action_executionlog_notificationtemplate'),
    ]

    operations = [
        migrations.RenameModel(
            old_name='User',
            new_name='CompanyUser',
        ),
        migrations.RenameModel(
            old_name='UserRole',
            new_name='CompanyUserRole',
        ),
        migrations.RenameModel(
            old_name='UserCompanyAccess',
            new_name='CompanyUserAccess',
        ),
    ]
