# Generated manually on 2026-02-03 - Django 6.0 compatibility (table and index renames)

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('constec_db', '0007_rename_user_to_companyuser'),
    ]

    operations = [
        # Just accept Django 6's automatic changes to table names and indexes
        # This migration intentionally empty - Django will handle the renames automatically
    ]
