# Fix Action model nullable fields

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('constec_db', '0008_django6_compatibility'),
    ]

    operations = [
        migrations.AlterField(
            model_name='action',
            name='on_error',
            field=models.CharField(
                blank=True,
                choices=[('stop', 'Stop'), ('continue', 'Continue'), ('retry', 'Retry')],
                help_text="Override del on_error de la automation",
                max_length=20,
                null=True
            ),
        ),
        migrations.AlterField(
            model_name='action',
            name='retry_count',
            field=models.IntegerField(
                blank=True,
                help_text="Override del retry_count de la automation",
                null=True
            ),
        ),
    ]
