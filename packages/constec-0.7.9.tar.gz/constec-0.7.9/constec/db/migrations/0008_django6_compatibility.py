# Generated manually on 2026-02-03 - Django 6.0 compatibility (table and index renames)

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('constec_db', '0006_automation_trigger_action_executionlog_notificationtemplate'),
    ]

    operations = [
        # Just accept Django 6's automatic changes to table names and indexes
        # This migration intentionally empty - Django will handle the renames automatically
    ]
