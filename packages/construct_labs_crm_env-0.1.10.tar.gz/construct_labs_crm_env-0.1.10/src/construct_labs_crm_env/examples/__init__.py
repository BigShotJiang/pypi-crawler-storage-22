"""Example scripts for construct-labs-crm-env."""
