#!/usr/bin/python
# coding: utf-8
from container_manager_mcp.container_manager_mcp import container_manager_mcp

if __name__ == "__main__":
    container_manager_mcp()
