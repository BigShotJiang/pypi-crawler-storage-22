Workflow: Scale app
1. `init_swarm` if needed.
2. `create_service`.
3. `list_nodes` / `list_services` to monitor.
