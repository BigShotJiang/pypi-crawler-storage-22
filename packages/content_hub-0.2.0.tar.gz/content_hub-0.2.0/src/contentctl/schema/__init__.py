"""Schema resources for contentctl."""
