# Content Understanding SDK

Python SDK for Azure Content Understanding API.

## Installation

```bash
pip install content-understanding-sdk
