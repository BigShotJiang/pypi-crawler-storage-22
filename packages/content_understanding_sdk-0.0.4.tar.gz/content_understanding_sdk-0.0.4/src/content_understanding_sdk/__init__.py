# src/content_understanding_client/__init__.py

from .client import ContentUnderstandingClient

__all__ = ["ContentUnderstandingClient"]
