"""ContentAPI Python SDK — extract content from any URL.

Usage::

    from contentapi import ContentAPI

    client = ContentAPI(api_key="sk_live_...")
    result = client.web.extract("https://example.com")
    print(result.title, result.content)
"""

from __future__ import annotations

from .client import ContentAPI
from ._async.client import AsyncContentAPI
from .exceptions import (
    AuthenticationError,
    ConnectionError,
    ContentAPIError,
    ExtractionError,
    NotFoundError,
    QuotaExceededError,
    RateLimitError,
    ServerError,
    TimeoutError,
)
from .models import (
    BatchResultItem,
    BatchResults,
    BatchSummary,
    RedditMetadata,
    RedditPost,
    SearchResultItem,
    SearchResults,
    StructureItem,
    Tweet,
    TwitterMetadata,
    TwitterThread,
    WebMetadata,
    WebResult,
    YouTubeMetadata,
    YouTubeSummary,
    YouTubeTranscript,
    TranscriptSegment,
    YouTubeComments,
    YouTubeCommentItem,
    YouTubeChapters,
    YouTubeChapterItem,
    AIExtractResult,
    SummarizeResult,
    CrawlStartResult,
    CrawlStatusResult,
    CrawlCancelResult,
    CrawlPage,
)

__version__ = "0.1.0"

__all__ = [
    # Clients
    "ContentAPI",
    "AsyncContentAPI",
    # Exceptions
    "ContentAPIError",
    "AuthenticationError",
    "RateLimitError",
    "QuotaExceededError",
    "ExtractionError",
    "NotFoundError",
    "ServerError",
    "TimeoutError",
    "ConnectionError",
    # Models — Web
    "WebResult",
    "WebMetadata",
    "StructureItem",
    # Models — YouTube
    "YouTubeTranscript",
    "TranscriptSegment",
    "YouTubeMetadata",
    "YouTubeSummary",
    "YouTubeComments",
    "YouTubeCommentItem",
    "YouTubeChapters",
    "YouTubeChapterItem",
    # Models — AI
    "AIExtractResult",
    "SummarizeResult",
    # Models — Crawl
    "CrawlStartResult",
    "CrawlStatusResult",
    "CrawlCancelResult",
    "CrawlPage",
    # Models — Twitter
    "TwitterThread",
    "Tweet",
    "TwitterMetadata",
    # Models — Reddit
    "RedditPost",
    "RedditMetadata",
    # Models — Search
    "SearchResults",
    "SearchResultItem",
    # Models — Batch
    "BatchResults",
    "BatchResultItem",
    "BatchSummary",
]
