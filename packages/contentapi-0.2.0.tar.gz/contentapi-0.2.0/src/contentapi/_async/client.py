"""Asynchronous ContentAPI client."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

import httpx

from ..exceptions import (
    AuthenticationError,
    ConnectionError,
    ContentAPIError,
    ExtractionError,
    NotFoundError,
    QuotaExceededError,
    RateLimitError,
    ServerError,
    TimeoutError,
)
from ..resources.web import WebResource
from ..resources.youtube import YouTubeResource
from ..resources.twitter import TwitterResource
from ..resources.reddit import RedditResource
from ..resources.search import SearchResource
from ..resources.batch import BatchResource
from ..resources.ai import AIResource
from ..resources.crawl import CrawlResource

logger = logging.getLogger("contentapi")

_DEFAULT_BASE_URL = "https://api.getcontentapi.com/api/v1"
_DEFAULT_TIMEOUT = 60.0
_DEFAULT_MAX_RETRIES = 3


class AsyncContentAPI:
    """Asynchronous client for the ContentAPI.

    Usage::

        async with ContentAPI(api_key="sk_live_...", async_mode=True) as client:
            result = await client.web.extract("https://example.com")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.max_retries = max_retries
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "X-API-Key": api_key,
                "User-Agent": "contentapi-python/0.1.0",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

        # Resource namespaces
        self.web = WebResource(self)  # type: ignore[arg-type]
        self.youtube = YouTubeResource(self)  # type: ignore[arg-type]
        self.twitter = TwitterResource(self)  # type: ignore[arg-type]
        self.reddit = RedditResource(self)  # type: ignore[arg-type]
        self._search = SearchResource(self)  # type: ignore[arg-type]
        self._batch = BatchResource(self)  # type: ignore[arg-type]
        self.ai = AIResource(self)  # type: ignore[arg-type]
        self.crawl = CrawlResource(self)  # type: ignore[arg-type]

    # ------------------------------------------------------------------
    # Convenience top-level methods
    # ------------------------------------------------------------------

    async def search(
        self,
        query: str,
        *,
        count: Optional[int] = None,
        **kwargs: Any,
    ) -> Any:
        return await self._search.aquery(query, count=count, **kwargs)

    async def batch(
        self,
        urls: list[str],
        **kwargs: Any,
    ) -> Any:
        return await self._batch.aextract(urls, **kwargs)

    # ------------------------------------------------------------------
    # HTTP layer
    # ------------------------------------------------------------------

    async def _arequest(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict[str, Any]] = None,
        json_body: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Execute an async HTTP request with retry logic."""
        if params:
            params = {k: v for k, v in params.items() if v is not None}

        last_exc: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                response = await self._client.request(
                    method,
                    path,
                    params=params,
                    json=json_body,
                )
                return self._handle_response(response)
            except (RateLimitError, ServerError) as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    wait = self._backoff_delay(attempt, exc)
                    logger.info(
                        "Retrying %s %s in %.1fs (attempt %d/%d): %s",
                        method, path, wait, attempt + 1, self.max_retries, exc.message,
                    )
                    await asyncio.sleep(wait)
                else:
                    raise
            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    wait = self._backoff_delay(attempt)
                    logger.info(
                        "Timeout on %s %s, retrying in %.1fs (attempt %d/%d)",
                        method, path, wait, attempt + 1, self.max_retries,
                    )
                    await asyncio.sleep(wait)
                else:
                    raise TimeoutError(
                        f"Request timed out after {self.max_retries + 1} attempts: {exc}",
                    )
            except httpx.ConnectError as exc:
                raise ConnectionError(f"Connection failed: {exc}")
            except httpx.HTTPError as exc:
                raise ContentAPIError(f"HTTP error: {exc}")

        raise last_exc or ContentAPIError("Request failed")  # type: ignore[arg-type]

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Parse response and raise appropriate exceptions (same logic as sync)."""
        status = response.status_code

        try:
            body: dict[str, Any] = response.json()
        except Exception:
            if status >= 400:
                raise ContentAPIError(
                    f"HTTP {status}: {response.text[:500]}",
                    status_code=status,
                )
            return {"success": True, "data": {"raw": response.text}}

        if status == 401 or status == 403:
            err = body.get("error", {})
            raise AuthenticationError(
                err.get("message", "Authentication failed"),
                status_code=status,
                error_code=err.get("code"),
                response_body=body,
            )

        if status == 429:
            err = body.get("error", {})
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                err.get("message", "Rate limit exceeded"),
                status_code=status,
                error_code=err.get("code"),
                response_body=body,
                retry_after=float(retry_after) if retry_after else None,
            )

        if status == 404:
            err = body.get("error", {})
            raise NotFoundError(
                err.get("message", "Not found"),
                status_code=status,
                error_code=err.get("code"),
                response_body=body,
            )

        if status >= 500:
            err = body.get("error", {})
            raise ServerError(
                err.get("message", f"Server error (HTTP {status})"),
                status_code=status,
                error_code=err.get("code"),
                response_body=body,
            )

        if status >= 400:
            err = body.get("error", {})
            code = err.get("code", "")
            message = err.get("message", f"API error (HTTP {status})")

            if code == "QUOTA_EXCEEDED" or "quota" in message.lower():
                raise QuotaExceededError(
                    message, status_code=status, error_code=code, response_body=body,
                )
            if code == "EXTRACTION_FAILED" or "extract" in message.lower():
                raise ExtractionError(
                    message, status_code=status, error_code=code, response_body=body,
                )

            raise ContentAPIError(
                message, status_code=status, error_code=code, response_body=body,
            )

        if not body.get("success", True):
            err = body.get("error", {})
            raise ExtractionError(
                err.get("message", "Extraction failed"),
                error_code=err.get("code"),
                response_body=body,
            )

        return body

    @staticmethod
    def _backoff_delay(attempt: int, exc: Optional[Exception] = None) -> float:
        base = 1.0
        if isinstance(exc, RateLimitError) and exc.retry_after:
            base = exc.retry_after
        return base * (2 ** attempt)

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    async def __aenter__(self) -> AsyncContentAPI:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        await self._client.aclose()

    def __repr__(self) -> str:
        return f"AsyncContentAPI(base_url={self.base_url!r})"
