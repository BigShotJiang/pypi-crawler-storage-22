"""Custom exceptions for the ContentAPI SDK."""

from __future__ import annotations

from typing import Any, Optional


class ContentAPIError(Exception):
    """Base exception for all ContentAPI errors.

    Attributes:
        message: Human-readable error description.
        status_code: HTTP status code, if from an API response.
        error_code: Machine-readable error code from the API (e.g. ``"NOT_FOUND"``).
        response_body: Raw response body dict, when available.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        error_code: Optional[str] = None,
        response_body: Optional[dict[str, Any]] = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.error_code = error_code
        self.response_body = response_body
        super().__init__(message)

    def __repr__(self) -> str:
        attrs = [f"message={self.message!r}"]
        if self.status_code is not None:
            attrs.append(f"status_code={self.status_code}")
        if self.error_code is not None:
            attrs.append(f"error_code={self.error_code!r}")
        return f"{self.__class__.__name__}({', '.join(attrs)})"


class AuthenticationError(ContentAPIError):
    """Raised when the API key is invalid or missing (HTTP 401/403)."""


class RateLimitError(ContentAPIError):
    """Raised when the rate limit is exceeded (HTTP 429).

    Attributes:
        retry_after: Seconds to wait before retrying, if provided by the API.
    """

    def __init__(
        self,
        message: str,
        *,
        retry_after: Optional[float] = None,
        **kwargs: Any,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(message, **kwargs)


class QuotaExceededError(ContentAPIError):
    """Raised when the account's credit quota is exhausted."""


class ExtractionError(ContentAPIError):
    """Raised when content extraction fails on the server side."""


class NotFoundError(ContentAPIError):
    """Raised when the requested resource or endpoint is not found (HTTP 404)."""


class ServerError(ContentAPIError):
    """Raised on server-side errors (HTTP 5xx)."""


class TimeoutError(ContentAPIError):
    """Raised when a request times out."""


class ConnectionError(ContentAPIError):
    """Raised when there is a network connectivity problem."""
