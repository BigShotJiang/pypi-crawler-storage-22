"""Pydantic v2 response models for the ContentAPI SDK."""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Shared / envelope
# ---------------------------------------------------------------------------

class APIResponse(BaseModel):
    """Raw API envelope. Consumers normally use typed wrappers instead."""

    success: bool
    data: Optional[dict[str, Any]] = None
    error: Optional[dict[str, Any]] = None
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None


# ---------------------------------------------------------------------------
# Web extraction
# ---------------------------------------------------------------------------

class StructureItem(BaseModel):
    tag: str
    text: str
    links: Optional[list[dict[str, Any]]] = None


class WebMetadata(BaseModel):
    description: Optional[str] = None
    language: Optional[str] = None
    og_title: Optional[str] = Field(None, alias="og:title")
    og_description: Optional[str] = Field(None, alias="og:description")
    og_image: Optional[str] = Field(None, alias="og:image")

    model_config = {"populate_by_name": True, "extra": "allow"}


class WebResult(BaseModel):
    """Result from ``client.web.extract(...)``."""

    source: str = "web"
    url: str
    title: Optional[str] = None
    content: Optional[str] = None
    content_type: Optional[str] = None
    word_count: Optional[int] = None
    structure: Optional[list[StructureItem]] = None
    metadata: Optional[WebMetadata] = None
    cache_hit: Optional[bool] = None

    # Credits info (promoted from envelope)
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


# ---------------------------------------------------------------------------
# YouTube
# ---------------------------------------------------------------------------

class TranscriptSegment(BaseModel):
    start: float
    duration: float
    text: str


class YouTubeTranscript(BaseModel):
    """Result from ``client.youtube.transcript(...)``."""

    video_id: str
    title: Optional[str] = None
    channel: Optional[str] = None
    channel_id: Optional[str] = None
    language: Optional[str] = None
    duration: Optional[int] = None
    published_at: Optional[str] = None
    view_count: Optional[int] = None
    thumbnail_url: Optional[str] = None
    tags: Optional[list[str]] = None
    word_count: Optional[int] = None
    transcript: Optional[list[TranscriptSegment]] = Field(None, alias="transcript")

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow", "populate_by_name": True}

    @property
    def segments(self) -> list[TranscriptSegment]:
        """Alias for ``transcript``."""
        return self.transcript or []

    @property
    def full_text(self) -> str:
        """Join all segment texts into a single string."""
        return " ".join(seg.text for seg in self.segments)


class YouTubeMetadata(BaseModel):
    """Result from ``client.youtube.metadata(...)``."""

    video_id: str
    title: Optional[str] = None
    channel: Optional[str] = None
    channel_id: Optional[str] = None
    description: Optional[str] = None
    duration: Optional[int] = None
    view_count: Optional[int] = None
    published_at: Optional[str] = None
    thumbnail_url: Optional[str] = None
    tags: Optional[list[str]] = None

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


class YouTubeSummary(BaseModel):
    """Result from ``client.youtube.summary(...)`` (if available)."""

    video_id: str
    title: Optional[str] = None
    summary: Optional[str] = None

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


# ---------------------------------------------------------------------------
# YouTube Comments & Chapters
# ---------------------------------------------------------------------------

class YouTubeCommentItem(BaseModel):
    author: str
    text: str
    likes: int = 0
    published_at: Optional[str] = None
    reply_count: Optional[int] = None

    model_config = {"extra": "allow"}


class YouTubeComments(BaseModel):
    """Result from ``client.youtube.comments(...)``."""

    video_id: str
    title: Optional[str] = None
    comment_count: Optional[int] = None
    comments: list[YouTubeCommentItem] = Field(default_factory=list)

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


class YouTubeChapterItem(BaseModel):
    title: str
    start: float
    duration: Optional[float] = None

    model_config = {"extra": "allow"}


class YouTubeChapters(BaseModel):
    """Result from ``client.youtube.chapters(...)``."""

    video_id: str
    title: Optional[str] = None
    chapters: list[YouTubeChapterItem] = Field(default_factory=list)

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


# ---------------------------------------------------------------------------
# AI Extract (Schema Extraction)
# ---------------------------------------------------------------------------

class AIExtractResult(BaseModel):
    """Result from ``client.ai.extract(...)``."""

    url: str
    data: dict[str, Any] = Field(default_factory=dict)
    tokens_used: Optional[int] = None

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


# ---------------------------------------------------------------------------
# Summarize
# ---------------------------------------------------------------------------

class SummarizeResult(BaseModel):
    """Result from ``client.ai.summarize(...)``."""

    summary: str = ""
    key_points: list[str] = Field(default_factory=list)
    topics: Optional[list[str]] = None
    title: Optional[str] = None
    word_count: Optional[int] = None

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


# ---------------------------------------------------------------------------
# Crawl
# ---------------------------------------------------------------------------

class CrawlStartResult(BaseModel):
    """Result from ``client.crawl.start(...)``."""

    crawl_id: str
    status: str = ""
    url: str = ""
    max_pages: Optional[int] = None
    max_depth: Optional[int] = None

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


class CrawlPage(BaseModel):
    url: str
    title: Optional[str] = None
    content: Optional[str] = None
    word_count: Optional[int] = None
    status: str = ""

    model_config = {"extra": "allow"}


class CrawlStatusResult(BaseModel):
    """Result from ``client.crawl.status(...)``."""

    crawl_id: str
    status: str = ""
    url: str = ""
    pages_crawled: int = 0
    pages_total: int = 0
    pages: Optional[list[CrawlPage]] = None
    created_at: Optional[str] = None
    completed_at: Optional[str] = None

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


class CrawlCancelResult(BaseModel):
    """Result from ``client.crawl.cancel(...)``."""

    crawl_id: str
    status: str = ""
    message: str = ""

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


# ---------------------------------------------------------------------------
# Twitter
# ---------------------------------------------------------------------------

class Tweet(BaseModel):
    id: str
    text: str
    created_at: Optional[str] = None
    likes: Optional[int] = None
    retweets: Optional[int] = None

    model_config = {"extra": "allow"}


class TwitterMetadata(BaseModel):
    tweet_count: Optional[int] = None
    total_engagement: Optional[int] = None

    model_config = {"extra": "allow"}


class TwitterThread(BaseModel):
    """Result from ``client.twitter.thread(...)``."""

    source: str = "twitter"
    url: str
    author: Optional[str] = None
    author_name: Optional[str] = None
    published_at: Optional[str] = None
    content: Optional[str] = None
    content_type: Optional[str] = None
    tweets: Optional[list[Tweet]] = None
    metadata: Optional[TwitterMetadata] = None
    cache_hit: Optional[bool] = None

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


# ---------------------------------------------------------------------------
# Reddit
# ---------------------------------------------------------------------------

class RedditMetadata(BaseModel):
    upvote_ratio: Optional[float] = None
    num_comments: Optional[int] = None
    is_self: Optional[bool] = None

    model_config = {"extra": "allow"}


class RedditPost(BaseModel):
    """Result from ``client.reddit.post(...)``."""

    source: str = "reddit"
    url: str
    subreddit: Optional[str] = None
    author: Optional[str] = None
    title: Optional[str] = None
    published_at: Optional[str] = None
    content: Optional[str] = None
    content_type: Optional[str] = None
    score: Optional[int] = None
    metadata: Optional[RedditMetadata] = None
    cache_hit: Optional[bool] = None

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

class SearchResultItem(BaseModel):
    title: str
    url: str
    snippet: Optional[str] = None

    model_config = {"extra": "allow"}


class SearchResults(BaseModel):
    """Result from ``client.search(...)``."""

    query: str
    results: list[SearchResultItem] = Field(default_factory=list)
    total_results: Optional[int] = None

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}


# ---------------------------------------------------------------------------
# Batch
# ---------------------------------------------------------------------------

class BatchResultItem(BaseModel):
    index: int
    url: str
    source: Optional[str] = None
    success: bool
    data: Optional[dict[str, Any]] = None
    error: Optional[dict[str, Any]] = None

    model_config = {"extra": "allow"}


class BatchSummary(BaseModel):
    total: int
    succeeded: int
    failed: int

    model_config = {"extra": "allow"}


class BatchResults(BaseModel):
    """Result from ``client.batch(...)``."""

    results: list[BatchResultItem] = Field(default_factory=list)
    summary: Optional[BatchSummary] = None

    # Credits info
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None

    model_config = {"extra": "allow"}
