"""Resource namespaces for ContentAPI."""

from .web import WebResource
from .youtube import YouTubeResource
from .twitter import TwitterResource
from .reddit import RedditResource
from .search import SearchResource
from .batch import BatchResource
from .ai import AIResource
from .crawl import CrawlResource

__all__ = [
    "WebResource",
    "YouTubeResource",
    "TwitterResource",
    "RedditResource",
    "SearchResource",
    "BatchResource",
    "AIResource",
    "CrawlResource",
]
