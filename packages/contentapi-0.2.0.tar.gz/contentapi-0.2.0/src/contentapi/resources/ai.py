"""AI extraction and summarization resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional, Union

from ..models import AIExtractResult, SummarizeResult

if TYPE_CHECKING:
    from ..client import ContentAPI
    from .._async.client import AsyncContentAPI


class AIResource:
    """AI-powered schema extraction and content summarization.

    Usage::

        # Schema extraction
        result = client.ai.extract(
            url="https://example.com/product",
            prompt="Extract the product name, price, and description",
        )
        print(result.data)

        # Summarization
        summary = client.ai.summarize("https://example.com/article")
        print(summary.summary, summary.key_points)
    """

    def __init__(self, client: Union[ContentAPI, AsyncContentAPI]) -> None:
        self._client = client

    def _is_async(self) -> bool:
        return hasattr(self._client, "_arequest")

    # ------------------------------------------------------------------
    # Extract (schema extraction)
    # ------------------------------------------------------------------

    def extract(
        self,
        url: str,
        *,
        schema: Optional[dict[str, Any]] = None,
        prompt: Optional[str] = None,
        **kwargs: Any,
    ) -> AIExtractResult:
        """Extract structured data from a URL using AI.

        Args:
            url: The URL to extract data from.
            schema: JSON schema describing the desired output shape.
            prompt: Natural-language prompt describing what to extract.
            **kwargs: Additional body parameters.

        Returns:
            An :class:`AIExtractResult` with the extracted data.
        """
        if self._is_async():
            return self.aextract(url, schema=schema, prompt=prompt, **kwargs)  # type: ignore[return-value]

        json_body: dict[str, Any] = {"url": url, **kwargs}
        if schema is not None:
            json_body["schema"] = schema
        if prompt is not None:
            json_body["prompt"] = prompt

        body = self._client._request("POST", "/extract", json_body=json_body)  # type: ignore[union-attr]
        return self._parse_extract(body)

    async def aextract(
        self,
        url: str,
        *,
        schema: Optional[dict[str, Any]] = None,
        prompt: Optional[str] = None,
        **kwargs: Any,
    ) -> AIExtractResult:
        """Async version of :meth:`extract`."""
        json_body: dict[str, Any] = {"url": url, **kwargs}
        if schema is not None:
            json_body["schema"] = schema
        if prompt is not None:
            json_body["prompt"] = prompt

        body = await self._client._arequest("POST", "/extract", json_body=json_body)  # type: ignore[union-attr]
        return self._parse_extract(body)

    @staticmethod
    def _parse_extract(body: dict[str, Any]) -> AIExtractResult:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return AIExtractResult.model_validate(data)

    # ------------------------------------------------------------------
    # Summarize
    # ------------------------------------------------------------------

    def summarize(
        self,
        url: str,
        *,
        content: Optional[str] = None,
        title: Optional[str] = None,
        **kwargs: Any,
    ) -> SummarizeResult:
        """Summarize content from a URL or raw text using AI.

        Args:
            url: URL to summarize.
            content: Raw content to summarize (instead of fetching from URL).
            title: Optional title for context.

        Returns:
            A :class:`SummarizeResult` with summary and key points.
        """
        if self._is_async():
            return self.asummarize(url, content=content, title=title, **kwargs)  # type: ignore[return-value]

        json_body: dict[str, Any] = {"url": url, **kwargs}
        if content is not None:
            json_body["content"] = content
        if title is not None:
            json_body["title"] = title

        body = self._client._request("POST", "/summarize", json_body=json_body)  # type: ignore[union-attr]
        return self._parse_summarize(body)

    async def asummarize(
        self,
        url: str,
        *,
        content: Optional[str] = None,
        title: Optional[str] = None,
        **kwargs: Any,
    ) -> SummarizeResult:
        """Async version of :meth:`summarize`."""
        json_body: dict[str, Any] = {"url": url, **kwargs}
        if content is not None:
            json_body["content"] = content
        if title is not None:
            json_body["title"] = title

        body = await self._client._arequest("POST", "/summarize", json_body=json_body)  # type: ignore[union-attr]
        return self._parse_summarize(body)

    @staticmethod
    def _parse_summarize(body: dict[str, Any]) -> SummarizeResult:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return SummarizeResult.model_validate(data)
