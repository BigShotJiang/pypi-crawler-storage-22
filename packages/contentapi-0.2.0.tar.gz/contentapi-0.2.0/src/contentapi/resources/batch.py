"""Batch extraction resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Union

from ..models import BatchResults

if TYPE_CHECKING:
    from ..client import ContentAPI
    from .._async.client import AsyncContentAPI


class BatchResource:
    """Batch content extraction.

    Usage::

        results = client.batch(["https://example.com", "https://youtube.com/watch?v=..."])
        for item in results.results:
            print(item.url, item.success)
    """

    def __init__(self, client: Union[ContentAPI, AsyncContentAPI]) -> None:
        self._client = client

    def _is_async(self) -> bool:
        return hasattr(self._client, "_arequest")

    def extract(self, urls: list[str], **kwargs: Any) -> BatchResults:
        """Extract content from multiple URLs in a single request.

        Args:
            urls: List of URLs to extract.
        """
        if self._is_async():
            return self.aextract(urls, **kwargs)  # type: ignore[return-value]

        body = self._client._request(  # type: ignore[union-attr]
            "POST",
            "/batch",
            json_body={"urls": urls, **kwargs},
        )
        return self._parse(body)

    async def aextract(self, urls: list[str], **kwargs: Any) -> BatchResults:
        """Async version of :meth:`extract`."""
        body = await self._client._arequest(  # type: ignore[union-attr]
            "POST",
            "/batch",
            json_body={"urls": urls, **kwargs},
        )
        return self._parse(body)

    @staticmethod
    def _parse(body: dict[str, Any]) -> BatchResults:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return BatchResults.model_validate(data)
