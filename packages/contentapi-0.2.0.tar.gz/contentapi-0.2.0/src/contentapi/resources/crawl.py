"""Crawl resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional, Union

from ..models import CrawlStartResult, CrawlStatusResult, CrawlCancelResult

if TYPE_CHECKING:
    from ..client import ContentAPI
    from .._async.client import AsyncContentAPI


class CrawlResource:
    """Website crawling operations.

    Usage::

        # Start a crawl
        job = client.crawl.start("https://docs.example.com", max_pages=50)
        print(job.crawl_id)

        # Check status
        result = client.crawl.status(job.crawl_id)
        print(result.status, result.pages_crawled)

        # Cancel
        client.crawl.cancel(job.crawl_id)
    """

    def __init__(self, client: Union[ContentAPI, AsyncContentAPI]) -> None:
        self._client = client

    def _is_async(self) -> bool:
        return hasattr(self._client, "_arequest")

    # ------------------------------------------------------------------
    # Start
    # ------------------------------------------------------------------

    def start(
        self,
        url: str,
        *,
        max_pages: Optional[int] = None,
        max_depth: Optional[int] = None,
        patterns: Optional[list[str]] = None,
        webhook_url: Optional[str] = None,
        **kwargs: Any,
    ) -> CrawlStartResult:
        """Start a new crawl job.

        Args:
            url: Starting URL for the crawl.
            max_pages: Maximum number of pages to crawl (default 10).
            max_depth: Maximum link depth (default 2).
            patterns: URL patterns to include (glob or regex).
            webhook_url: Webhook URL to POST results to on completion.

        Returns:
            A :class:`CrawlStartResult` with the crawl_id.
        """
        if self._is_async():
            return self.astart(url, max_pages=max_pages, max_depth=max_depth, patterns=patterns, webhook_url=webhook_url, **kwargs)  # type: ignore[return-value]

        json_body: dict[str, Any] = {"url": url, **kwargs}
        if max_pages is not None:
            json_body["max_pages"] = max_pages
        if max_depth is not None:
            json_body["max_depth"] = max_depth
        if patterns is not None:
            json_body["patterns"] = patterns
        if webhook_url is not None:
            json_body["webhook_url"] = webhook_url

        body = self._client._request("POST", "/crawl", json_body=json_body)  # type: ignore[union-attr]
        return self._parse_start(body)

    async def astart(
        self,
        url: str,
        *,
        max_pages: Optional[int] = None,
        max_depth: Optional[int] = None,
        patterns: Optional[list[str]] = None,
        webhook_url: Optional[str] = None,
        **kwargs: Any,
    ) -> CrawlStartResult:
        """Async version of :meth:`start`."""
        json_body: dict[str, Any] = {"url": url, **kwargs}
        if max_pages is not None:
            json_body["max_pages"] = max_pages
        if max_depth is not None:
            json_body["max_depth"] = max_depth
        if patterns is not None:
            json_body["patterns"] = patterns
        if webhook_url is not None:
            json_body["webhook_url"] = webhook_url

        body = await self._client._arequest("POST", "/crawl", json_body=json_body)  # type: ignore[union-attr]
        return self._parse_start(body)

    @staticmethod
    def _parse_start(body: dict[str, Any]) -> CrawlStartResult:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return CrawlStartResult.model_validate(data)

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def status(self, crawl_id: str, **kwargs: Any) -> CrawlStatusResult:
        """Get the status and results of a crawl job.

        Args:
            crawl_id: The crawl ID returned by :meth:`start`.

        Returns:
            A :class:`CrawlStatusResult` with status and pages.
        """
        if self._is_async():
            return self.astatus(crawl_id, **kwargs)  # type: ignore[return-value]

        body = self._client._request("GET", f"/crawl/{crawl_id}", **kwargs)  # type: ignore[union-attr]
        return self._parse_status(body)

    async def astatus(self, crawl_id: str, **kwargs: Any) -> CrawlStatusResult:
        """Async version of :meth:`status`."""
        body = await self._client._arequest("GET", f"/crawl/{crawl_id}", **kwargs)  # type: ignore[union-attr]
        return self._parse_status(body)

    @staticmethod
    def _parse_status(body: dict[str, Any]) -> CrawlStatusResult:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return CrawlStatusResult.model_validate(data)

    # ------------------------------------------------------------------
    # Cancel
    # ------------------------------------------------------------------

    def cancel(self, crawl_id: str, **kwargs: Any) -> CrawlCancelResult:
        """Cancel a running crawl job.

        Args:
            crawl_id: The crawl ID to cancel.

        Returns:
            A :class:`CrawlCancelResult` confirmation.
        """
        if self._is_async():
            return self.acancel(crawl_id, **kwargs)  # type: ignore[return-value]

        body = self._client._request("DELETE", f"/crawl/{crawl_id}", **kwargs)  # type: ignore[union-attr]
        return self._parse_cancel(body)

    async def acancel(self, crawl_id: str, **kwargs: Any) -> CrawlCancelResult:
        """Async version of :meth:`cancel`."""
        body = await self._client._arequest("DELETE", f"/crawl/{crawl_id}", **kwargs)  # type: ignore[union-attr]
        return self._parse_cancel(body)

    @staticmethod
    def _parse_cancel(body: dict[str, Any]) -> CrawlCancelResult:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return CrawlCancelResult.model_validate(data)
