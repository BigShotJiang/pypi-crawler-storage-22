"""Reddit resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Union

from ..models import RedditPost

if TYPE_CHECKING:
    from ..client import ContentAPI
    from .._async.client import AsyncContentAPI


class RedditResource:
    """Access Reddit content extraction.

    Usage::

        post = client.reddit.post("https://reddit.com/r/Python/comments/...")
        print(post.title, post.subreddit, post.score)
    """

    def __init__(self, client: Union[ContentAPI, AsyncContentAPI]) -> None:
        self._client = client

    def _is_async(self) -> bool:
        return hasattr(self._client, "_arequest")

    def post(self, url: str, **kwargs: Any) -> RedditPost:
        """Extract a Reddit post.

        Args:
            url: Reddit post URL.
        """
        if self._is_async():
            return self.apost(url, **kwargs)  # type: ignore[return-value]

        params: dict[str, Any] = {"url": url, **kwargs}
        body = self._client._request("GET", "/reddit/post", params=params)  # type: ignore[union-attr]
        return self._parse(body)

    async def apost(self, url: str, **kwargs: Any) -> RedditPost:
        """Async version of :meth:`post`."""
        params: dict[str, Any] = {"url": url, **kwargs}
        body = await self._client._arequest("GET", "/reddit/post", params=params)  # type: ignore[union-attr]
        return self._parse(body)

    @staticmethod
    def _parse(body: dict[str, Any]) -> RedditPost:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return RedditPost.model_validate(data)
