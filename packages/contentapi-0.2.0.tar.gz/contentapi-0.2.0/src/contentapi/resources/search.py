"""Web search resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional, Union

from ..models import SearchResults

if TYPE_CHECKING:
    from ..client import ContentAPI
    from .._async.client import AsyncContentAPI


class SearchResource:
    """Access web search.

    Usage::

        results = client.search("python RAG tutorial", count=5)
        for r in results.results:
            print(r.title, r.url)
    """

    def __init__(self, client: Union[ContentAPI, AsyncContentAPI]) -> None:
        self._client = client

    def _is_async(self) -> bool:
        return hasattr(self._client, "_arequest")

    def query(
        self,
        q: str,
        *,
        count: Optional[int] = None,
        **kwargs: Any,
    ) -> SearchResults:
        """Search the web.

        Args:
            q: Search query string.
            count: Maximum number of results to return.
        """
        if self._is_async():
            return self.aquery(q, count=count, **kwargs)  # type: ignore[return-value]

        params: dict[str, Any] = {"q": q, **kwargs}
        if count is not None:
            params["count"] = count

        body = self._client._request("GET", "/web/search", params=params)  # type: ignore[union-attr]
        return self._parse(body)

    async def aquery(
        self,
        q: str,
        *,
        count: Optional[int] = None,
        **kwargs: Any,
    ) -> SearchResults:
        """Async version of :meth:`query`."""
        params: dict[str, Any] = {"q": q, **kwargs}
        if count is not None:
            params["count"] = count

        body = await self._client._arequest("GET", "/web/search", params=params)  # type: ignore[union-attr]
        return self._parse(body)

    @staticmethod
    def _parse(body: dict[str, Any]) -> SearchResults:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return SearchResults.model_validate(data)
