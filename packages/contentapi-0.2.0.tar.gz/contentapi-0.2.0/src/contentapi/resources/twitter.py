"""Twitter / X resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Union

from ..models import TwitterThread

if TYPE_CHECKING:
    from ..client import ContentAPI
    from .._async.client import AsyncContentAPI


class TwitterResource:
    """Access Twitter/X content extraction.

    Usage::

        thread = client.twitter.thread("https://x.com/user/status/123")
        print(thread.author, thread.content)
        for tweet in thread.tweets:
            print(tweet.text)
    """

    def __init__(self, client: Union[ContentAPI, AsyncContentAPI]) -> None:
        self._client = client

    def _is_async(self) -> bool:
        return hasattr(self._client, "_arequest")

    def thread(self, url: str, **kwargs: Any) -> TwitterThread:
        """Extract a Twitter thread / tweet.

        Args:
            url: Tweet or thread URL (twitter.com or x.com).
        """
        if self._is_async():
            return self.athread(url, **kwargs)  # type: ignore[return-value]

        params: dict[str, Any] = {"url": url, **kwargs}
        body = self._client._request("GET", "/twitter/thread", params=params)  # type: ignore[union-attr]
        return self._parse(body)

    async def athread(self, url: str, **kwargs: Any) -> TwitterThread:
        """Async version of :meth:`thread`."""
        params: dict[str, Any] = {"url": url, **kwargs}
        body = await self._client._arequest("GET", "/twitter/thread", params=params)  # type: ignore[union-attr]
        return self._parse(body)

    @staticmethod
    def _parse(body: dict[str, Any]) -> TwitterThread:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return TwitterThread.model_validate(data)
