"""Web extraction resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional, Union

from ..models import WebResult

if TYPE_CHECKING:
    from ..client import ContentAPI
    from .._async.client import AsyncContentAPI


class WebResource:
    """Access web content extraction.

    Usage::

        result = client.web.extract("https://example.com", format="markdown")
        print(result.title, result.content)
    """

    def __init__(self, client: Union[ContentAPI, AsyncContentAPI]) -> None:
        self._client = client

    def _is_async(self) -> bool:
        return hasattr(self._client, "_arequest")

    def extract(
        self,
        url: str,
        *,
        format: Optional[str] = None,
        render_js: Optional[bool] = None,
        ignore_robots: Optional[bool] = None,
        **kwargs: Any,
    ) -> WebResult:
        """Extract content from a web URL.

        Args:
            url: The URL to extract content from.
            format: Output format (e.g. ``"markdown"``, ``"text"``).
            render_js: Set to ``True`` to render JavaScript before extraction.
            ignore_robots: Set to ``True`` to skip robots.txt restrictions.
            **kwargs: Additional query parameters.

        Returns:
            A :class:`WebResult` with extracted content.

        Note:
            In async mode, use ``await client.web.aextract(...)`` or
            ``await client.web.extract(...)`` (auto-detected).
        """
        if self._is_async():
            return self.aextract(url, format=format, render_js=render_js, ignore_robots=ignore_robots, **kwargs)  # type: ignore[return-value]

        params: dict[str, Any] = {"url": url, **kwargs}
        if format is not None:
            params["format"] = format
        if render_js is not None:
            params["render_js"] = render_js
        if ignore_robots is not None:
            params["ignore_robots"] = ignore_robots

        body = self._client._request("GET", "/web/extract", params=params)  # type: ignore[union-attr]
        return self._parse(body)

    async def aextract(
        self,
        url: str,
        *,
        format: Optional[str] = None,
        render_js: Optional[bool] = None,
        ignore_robots: Optional[bool] = None,
        **kwargs: Any,
    ) -> WebResult:
        """Async version of :meth:`extract`."""
        params: dict[str, Any] = {"url": url, **kwargs}
        if format is not None:
            params["format"] = format
        if render_js is not None:
            params["render_js"] = render_js
        if ignore_robots is not None:
            params["ignore_robots"] = ignore_robots

        body = await self._client._arequest("GET", "/web/extract", params=params)  # type: ignore[union-attr]
        return self._parse(body)

    @staticmethod
    def _parse(body: dict[str, Any]) -> WebResult:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return WebResult.model_validate(data)
