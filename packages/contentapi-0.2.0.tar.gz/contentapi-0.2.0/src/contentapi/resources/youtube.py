"""YouTube resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional, Union

from ..models import YouTubeMetadata, YouTubeTranscript, YouTubeComments, YouTubeChapters

if TYPE_CHECKING:
    from ..client import ContentAPI
    from .._async.client import AsyncContentAPI


class YouTubeResource:
    """Access YouTube content extraction.

    Usage::

        transcript = client.youtube.transcript("https://youtube.com/watch?v=...")
        print(transcript.title, transcript.full_text)

        metadata = client.youtube.metadata("https://youtube.com/watch?v=...")
        print(metadata.description)
    """

    def __init__(self, client: Union[ContentAPI, AsyncContentAPI]) -> None:
        self._client = client

    def _is_async(self) -> bool:
        return hasattr(self._client, "_arequest")

    # ------------------------------------------------------------------
    # Transcript
    # ------------------------------------------------------------------

    def transcript(
        self,
        url: str,
        *,
        language: Optional[str] = None,
        **kwargs: Any,
    ) -> YouTubeTranscript:
        """Get the transcript for a YouTube video.

        Args:
            url: YouTube video URL.
            language: Preferred transcript language code.
        """
        if self._is_async():
            return self.atranscript(url, language=language, **kwargs)  # type: ignore[return-value]

        params: dict[str, Any] = {"url": url, **kwargs}
        if language is not None:
            params["language"] = language

        body = self._client._request("GET", "/youtube/transcript", params=params)  # type: ignore[union-attr]
        return self._parse_transcript(body)

    async def atranscript(
        self,
        url: str,
        *,
        language: Optional[str] = None,
        **kwargs: Any,
    ) -> YouTubeTranscript:
        """Async version of :meth:`transcript`."""
        params: dict[str, Any] = {"url": url, **kwargs}
        if language is not None:
            params["language"] = language

        body = await self._client._arequest("GET", "/youtube/transcript", params=params)  # type: ignore[union-attr]
        return self._parse_transcript(body)

    @staticmethod
    def _parse_transcript(body: dict[str, Any]) -> YouTubeTranscript:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return YouTubeTranscript.model_validate(data)

    # ------------------------------------------------------------------
    # Metadata
    # ------------------------------------------------------------------

    def metadata(self, url: str, **kwargs: Any) -> YouTubeMetadata:
        """Get metadata for a YouTube video.

        Args:
            url: YouTube video URL.
        """
        if self._is_async():
            return self.ametadata(url, **kwargs)  # type: ignore[return-value]

        params: dict[str, Any] = {"url": url, **kwargs}
        body = self._client._request("GET", "/youtube/metadata", params=params)  # type: ignore[union-attr]
        return self._parse_metadata(body)

    async def ametadata(self, url: str, **kwargs: Any) -> YouTubeMetadata:
        """Async version of :meth:`metadata`."""
        params: dict[str, Any] = {"url": url, **kwargs}
        body = await self._client._arequest("GET", "/youtube/metadata", params=params)  # type: ignore[union-attr]
        return self._parse_metadata(body)

    @staticmethod
    def _parse_metadata(body: dict[str, Any]) -> YouTubeMetadata:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return YouTubeMetadata.model_validate(data)

    # ------------------------------------------------------------------
    # Comments
    # ------------------------------------------------------------------

    def comments(
        self,
        url: str,
        *,
        limit: Optional[int] = None,
        sort: Optional[str] = None,
        **kwargs: Any,
    ) -> YouTubeComments:
        """Get comments for a YouTube video.

        Args:
            url: YouTube video URL.
            limit: Maximum number of comments to return (default 20).
            sort: Sort order: ``'top'`` or ``'newest'`` (default ``'top'``).
        """
        if self._is_async():
            return self.acomments(url, limit=limit, sort=sort, **kwargs)  # type: ignore[return-value]

        params: dict[str, Any] = {"url": url, **kwargs}
        if limit is not None:
            params["limit"] = limit
        if sort is not None:
            params["sort"] = sort

        body = self._client._request("GET", "/youtube/comments", params=params)  # type: ignore[union-attr]
        return self._parse_comments(body)

    async def acomments(
        self,
        url: str,
        *,
        limit: Optional[int] = None,
        sort: Optional[str] = None,
        **kwargs: Any,
    ) -> YouTubeComments:
        """Async version of :meth:`comments`."""
        params: dict[str, Any] = {"url": url, **kwargs}
        if limit is not None:
            params["limit"] = limit
        if sort is not None:
            params["sort"] = sort

        body = await self._client._arequest("GET", "/youtube/comments", params=params)  # type: ignore[union-attr]
        return self._parse_comments(body)

    @staticmethod
    def _parse_comments(body: dict[str, Any]) -> YouTubeComments:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return YouTubeComments.model_validate(data)

    # ------------------------------------------------------------------
    # Chapters
    # ------------------------------------------------------------------

    def chapters(self, url: str, **kwargs: Any) -> YouTubeChapters:
        """Get chapters/timestamps for a YouTube video.

        Args:
            url: YouTube video URL.
        """
        if self._is_async():
            return self.achapters(url, **kwargs)  # type: ignore[return-value]

        params: dict[str, Any] = {"url": url, **kwargs}
        body = self._client._request("GET", "/youtube/chapters", params=params)  # type: ignore[union-attr]
        return self._parse_chapters(body)

    async def achapters(self, url: str, **kwargs: Any) -> YouTubeChapters:
        """Async version of :meth:`chapters`."""
        params: dict[str, Any] = {"url": url, **kwargs}
        body = await self._client._arequest("GET", "/youtube/chapters", params=params)  # type: ignore[union-attr]
        return self._parse_chapters(body)

    @staticmethod
    def _parse_chapters(body: dict[str, Any]) -> YouTubeChapters:
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return YouTubeChapters.model_validate(data)

    # ------------------------------------------------------------------
    # Summary (may not be available on all plans)
    # ------------------------------------------------------------------

    def summary(self, url: str, **kwargs: Any) -> Any:
        """Get an AI summary of a YouTube video (if available).

        Args:
            url: YouTube video URL.
        """
        if self._is_async():
            return self.asummary(url, **kwargs)

        from ..models import YouTubeSummary
        params: dict[str, Any] = {"url": url, **kwargs}
        body = self._client._request("GET", "/youtube/summary", params=params)  # type: ignore[union-attr]
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return YouTubeSummary.model_validate(data)

    async def asummary(self, url: str, **kwargs: Any) -> Any:
        """Async version of :meth:`summary`."""
        from ..models import YouTubeSummary
        params: dict[str, Any] = {"url": url, **kwargs}
        body = await self._client._arequest("GET", "/youtube/summary", params=params)  # type: ignore[union-attr]
        data = body.get("data", {})
        data["credits_used"] = body.get("credits_used")
        data["credits_remaining"] = body.get("credits_remaining")
        return YouTubeSummary.model_validate(data)
