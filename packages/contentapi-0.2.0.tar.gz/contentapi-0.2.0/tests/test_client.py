"""Unit tests for the ContentAPI Python SDK."""

from __future__ import annotations

import json
import pytest
import httpx
import respx

from contentapi import (
    ContentAPI,
    AsyncContentAPI,
    ContentAPIError,
    AuthenticationError,
    RateLimitError,
    NotFoundError,
    WebResult,
    YouTubeTranscript,
    TwitterThread,
    RedditPost,
    SearchResults,
    BatchResults,
)


BASE = "https://api.getcontentapi.com/api/v1"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def client() -> ContentAPI:
    c = ContentAPI("sk_test_123")
    yield c  # type: ignore[misc]
    c.close()


# ---------------------------------------------------------------------------
# Web extraction
# ---------------------------------------------------------------------------

class TestWebExtract:
    @respx.mock
    def test_extract_success(self, client: ContentAPI) -> None:
        respx.get(f"{BASE}/web/extract").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "source": "web",
                    "url": "https://example.com",
                    "title": "Example Domain",
                    "content": "Hello world",
                    "word_count": 2,
                },
                "credits_used": 1,
                "credits_remaining": 99,
            })
        )
        result = client.web.extract("https://example.com")
        assert isinstance(result, WebResult)
        assert result.title == "Example Domain"
        assert result.word_count == 2
        assert result.credits_used == 1

    @respx.mock
    def test_extract_with_format(self, client: ContentAPI) -> None:
        route = respx.get(f"{BASE}/web/extract").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "source": "web",
                    "url": "https://example.com",
                    "title": "Example",
                    "content": "# Hello",
                    "word_count": 1,
                },
                "credits_used": 1,
            })
        )
        client.web.extract("https://example.com", format="markdown")
        assert route.called
        request = route.calls[0].request
        assert "format=markdown" in str(request.url)


# ---------------------------------------------------------------------------
# YouTube
# ---------------------------------------------------------------------------

class TestYouTube:
    @respx.mock
    def test_transcript(self, client: ContentAPI) -> None:
        respx.get(f"{BASE}/youtube/transcript").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "video_id": "abc123",
                    "title": "Test Video",
                    "channel": "TestChannel",
                    "duration": 120,
                    "word_count": 50,
                    "transcript": [
                        {"start": 0.0, "duration": 2.0, "text": "Hello"},
                        {"start": 2.0, "duration": 2.0, "text": "World"},
                    ],
                },
                "credits_used": 1,
            })
        )
        result = client.youtube.transcript("https://youtube.com/watch?v=abc123")
        assert isinstance(result, YouTubeTranscript)
        assert result.title == "Test Video"
        assert len(result.segments) == 2
        assert result.full_text == "Hello World"

    @respx.mock
    def test_metadata(self, client: ContentAPI) -> None:
        respx.get(f"{BASE}/youtube/metadata").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "video_id": "abc123",
                    "title": "Test Video",
                    "channel": "TestChannel",
                    "description": "A test video",
                    "duration": 120,
                    "view_count": 1000,
                },
                "credits_used": 1,
            })
        )
        result = client.youtube.metadata("https://youtube.com/watch?v=abc123")
        assert result.title == "Test Video"
        assert result.view_count == 1000


# ---------------------------------------------------------------------------
# Twitter
# ---------------------------------------------------------------------------

class TestTwitter:
    @respx.mock
    def test_thread(self, client: ContentAPI) -> None:
        respx.get(f"{BASE}/twitter/thread").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "source": "twitter",
                    "url": "https://x.com/user/status/123",
                    "author": "@testuser",
                    "content": "Hello tweet",
                    "tweets": [
                        {"id": "123", "text": "Hello tweet", "likes": 42},
                    ],
                },
                "credits_used": 1,
            })
        )
        result = client.twitter.thread("https://x.com/user/status/123")
        assert isinstance(result, TwitterThread)
        assert result.author == "@testuser"
        assert len(result.tweets or []) == 1


# ---------------------------------------------------------------------------
# Reddit
# ---------------------------------------------------------------------------

class TestReddit:
    @respx.mock
    def test_post(self, client: ContentAPI) -> None:
        respx.get(f"{BASE}/reddit/post").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "source": "reddit",
                    "url": "https://reddit.com/r/test/comments/abc/test",
                    "subreddit": "r/test",
                    "title": "Test Post",
                    "score": 42,
                    "content": "Post content",
                },
                "credits_used": 1,
            })
        )
        result = client.reddit.post("https://reddit.com/r/test/comments/abc/test")
        assert isinstance(result, RedditPost)
        assert result.title == "Test Post"
        assert result.score == 42


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

class TestSearch:
    @respx.mock
    def test_search(self, client: ContentAPI) -> None:
        respx.get(f"{BASE}/web/search").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "query": "python tutorial",
                    "results": [
                        {"title": "Python Tutorial", "url": "https://example.com", "snippet": "Learn Python"},
                    ],
                    "total_results": 1,
                },
                "credits_used": 1,
            })
        )
        result = client.search("python tutorial", count=5)
        assert isinstance(result, SearchResults)
        assert result.query == "python tutorial"
        assert len(result.results) == 1


# ---------------------------------------------------------------------------
# Batch
# ---------------------------------------------------------------------------

class TestBatch:
    @respx.mock
    def test_batch(self, client: ContentAPI) -> None:
        respx.post(f"{BASE}/batch").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "results": [
                        {"index": 0, "url": "https://example.com", "source": "web", "success": True, "data": {}},
                    ],
                    "summary": {"total": 1, "succeeded": 1, "failed": 0},
                },
                "credits_used": 1,
            })
        )
        result = client.batch(["https://example.com"])
        assert isinstance(result, BatchResults)
        assert result.summary is not None
        assert result.summary.total == 1


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrors:
    @respx.mock
    def test_auth_error(self, client: ContentAPI) -> None:
        respx.get(f"{BASE}/web/extract").mock(
            return_value=httpx.Response(401, json={
                "success": False,
                "error": {"code": "UNAUTHORIZED", "message": "Invalid API key"},
            })
        )
        with pytest.raises(AuthenticationError) as exc_info:
            client.web.extract("https://example.com")
        assert exc_info.value.status_code == 401

    @respx.mock
    def test_rate_limit_error(self, client: ContentAPI) -> None:
        # Disable retries for this test
        client.max_retries = 0
        respx.get(f"{BASE}/web/extract").mock(
            return_value=httpx.Response(429, json={
                "success": False,
                "error": {"code": "RATE_LIMITED", "message": "Too many requests"},
            })
        )
        with pytest.raises(RateLimitError):
            client.web.extract("https://example.com")

    @respx.mock
    def test_not_found(self, client: ContentAPI) -> None:
        respx.get(f"{BASE}/web/extract").mock(
            return_value=httpx.Response(404, json={
                "success": False,
                "error": {"code": "NOT_FOUND", "message": "Not found"},
            })
        )
        with pytest.raises(NotFoundError):
            client.web.extract("https://example.com")


# ---------------------------------------------------------------------------
# Client basics
# ---------------------------------------------------------------------------

class TestClient:
    def test_import(self) -> None:
        from contentapi import ContentAPI
        c = ContentAPI("test_key")
        assert repr(c) == f"ContentAPI(base_url='{BASE}')"
        c.close()

    def test_async_mode_returns_async_client(self) -> None:
        c = ContentAPI("test_key", async_mode=True)
        assert isinstance(c, AsyncContentAPI)

    def test_context_manager(self) -> None:
        with ContentAPI("test_key") as c:
            assert c.api_key == "test_key"
