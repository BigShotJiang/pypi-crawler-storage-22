



from fastapi import APIRouter

from contentgrid_extension_helpers.responses.hal import FastAPIHALCollection

from server.types.bar import Bar, BarCreate

from contentgrid_extension_helpers.responses.hal import (
    FastAPIHALResponse,
    FastAPIHALCollection,
    HALLinkFor,
    HALTemplateFor,
)

def create_bar_router(tags=[]):
    bar_router = APIRouter(tags=tags)
    bars = []

    @bar_router.get('/bars', response_model=FastAPIHALCollection, response_model_exclude_none=True)
    def get_bars():
        return FastAPIHALCollection[Bar](
            _links={
                "self" : HALLinkFor(endpoint_function_name="get_bars", tags=tags)
            },
            _embedded={
                "bars" : bars
            },
            _templates={
                "create_bar" : HALTemplateFor(endpoint_function_name="create_bar", tags=tags)
            }
        )

    @bar_router.post('/bars', response_model=Bar,  response_model_exclude_none=True)
    def create_bar(bar : BarCreate) -> Bar:
        new_bar = Bar(**bar.model_dump(), tags=tags)
        bars.append(new_bar)
        return new_bar
    
    return bar_router