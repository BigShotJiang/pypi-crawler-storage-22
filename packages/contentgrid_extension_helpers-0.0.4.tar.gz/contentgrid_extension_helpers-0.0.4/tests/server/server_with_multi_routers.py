
from contentgrid_extension_helpers.responses.hal import FastAPIHALResponse
from server.base_server import app
FastAPIHALResponse.init_app(app)
from server.routers.bar_router import create_bar_router

app_with_multi_routers = app

bar1_tags = ["bar1"]
bar2_tags = ["bar2", "a random tag"]
app_with_multi_routers.include_router(create_bar_router(tags=bar1_tags), prefix="/bar1", tags=bar1_tags)
app_with_multi_routers.include_router(create_bar_router(tags=bar2_tags), prefix='/bar2', tags=bar2_tags)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app_with_multi_routers, host="0.0.0.0", port=5004, workers=1)