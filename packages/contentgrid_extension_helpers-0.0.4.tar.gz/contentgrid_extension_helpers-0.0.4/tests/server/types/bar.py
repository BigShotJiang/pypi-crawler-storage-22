from typing import Optional, List
from pydantic import BaseModel, Field as PydanticField
from sqlmodel import Field, SQLModel, Relationship

from contentgrid_extension_helpers.responses.hal import FastAPIHALResponse

from contentgrid_extension_helpers.responses.hal import HALLinkFor

class BarBase(BaseModel):
    name: str = Field(description="Name of the Bar")
    location : str = Field(default=None, description="Location of the bar")
    
class Bar(FastAPIHALResponse, BarBase):
    
    def __init__(self, tags, **kwargs):
        super().__init__(**kwargs)
        self.links = {
            "bars" : HALLinkFor(endpoint_function_name="get_bars", tags=tags)
        }

class BarCreate(BarBase):
    # Model for creating a new Bar
    secret_drink_recipe : str = Field(..., description="A secret recipe for a drink")