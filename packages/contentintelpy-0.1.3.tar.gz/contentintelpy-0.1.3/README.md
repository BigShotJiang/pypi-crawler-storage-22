# contentintelpy

**Production-grade NLP library for unified content intelligence.**

`contentintelpy` provides a unified, DAG-based engine for multilingual sentiment analysis, NER, translation, and summarization using real transformer models (RoBERTa, GLiNER, NLLB).

## Features

- **Real Models**: No heuristics. Uses State-of-the-Art Transformers.
    - Sentiment: RoBERTa
    - NER: GLiNER
    - Translation: NLLB (GPU) + ArgosTranslate (Offline CPU)
- **Hybrid Execution**: Models download on first run (lazy-loaded). Offline fallback available.
- **Deterministic Pipelines**: DAG-based execution guarantees order.
- **Dual API**: 
    - **Pipeline-first** for complex workflows.
    - **Service-first** for quick scripts.
- **Production Ready**: Thread-safe, standard error handling, sparse outputs.

## Installation

Install the base library:
```bash
pip install contentintelpy
```

### Optional Dependencies (Recommended)
Since the library uses heavy ML models, you should install the specific components you need:

```bash
# For all core features
pip install "contentintelpy[core,ner,translation,summarization]"

# For development
pip install "contentintelpy[dev]"
```

> [!IMPORTANT]
> **spaCy Model Requirement**
> If you use NER or language features, you must install a spaCy model manually:
> ```bash
> python -m spacy download en_core_web_sm
> ```

---

## Quick Start

Ideal for simple tasks in notebooks or scripts.

```python
from contentintelpy import SentimentService, TranslationService

# Sentiment
service = SentimentService()
result = service.analyze("This library is amazing!")
print(result) 
# {'value': 'positive', 'confidence': 0.99, ...}

# Translation
translator = TranslationService()
text = translator.translate("Hola mundo", target="en")
print(text)
# "Hello world"
```

## Production Usage (Pipeline-First)

Recommended for Backends, APIs, and Data Pipelines.

```python
import contentintelpy as ci

# 1. Create the canonical pipeline
pipeline = ci.create_default_pipeline()

# 2. Run it (Thread-safe)
result = pipeline.run({
    "text": "गूगल ने बेंगलुरु में नया कार्यालय खोला"
})

# 3. Access Sparse Output
print(result)
```

**Output Example:**
```json
{
  "text": "...",
  "text_translated": "Google opened a new office in Bengaluru",
  "language": "hi",
  "entities": [
    {"text": "Google", "label": "ORG"},
    {"text": "Bengaluru", "label": "LOC"}
  ],
  "sentiment": {
    "value": "neutral",
    "value_en": "neutral",
    "confidence": 0.95
  },
  "summary": "..."
}
```

## Error Handling

Nodes **never crash** the pipeline. Errors are collected in `errors` dict.

```python
{
    "text": "...",
    "errors": {
        "TranslationNode": "Model download failed: Connection error"
    }
}
```

## Architecture

This library is pure logic. It does **NOT** contain:
- Flask / FastAPI routes
- Database models
- Authentication

It is designed to be **consumed** by your backend application.
