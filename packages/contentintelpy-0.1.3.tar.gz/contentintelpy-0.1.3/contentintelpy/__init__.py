from .pipeline.pipeline import Pipeline
from .pipeline.context import PipelineContext
from .pipeline.base_node import Node
import importlib
import sys

def _show_welcome_hint():
    """Shows a one-time setup hint if core optional dependencies are missing."""
    try:
        importlib.import_module("transformers")
    except ImportError:
        # ANSI escape codes for color
        YELLOW = "\033[93m"
        RESET = "\033[0m"
        BOLD = "\033[1m"
        
        # Core [core] extra is missing
        print(f"\n{YELLOW}{'═'*60}")
        print(f"{BOLD}Welcome to ContentIntelPy!{RESET}{YELLOW}")
        print("═"*60)
        print("You've installed the base package. To unlock the full power of")
        print("the Content Intelligence Pipeline, install the extras below:")
        
        print(f"\n{BOLD}📦 FULL INSTALLATION (Recommended){RESET}{YELLOW}")
        print("   pip install \"contentintelpy[core,ner,translation,summarization]\"")
        
        print(f"\n{BOLD}🛠️ CAPABILITIES BY EXTRA:{RESET}{YELLOW}")
        print("   [core]         -> Sentiment, Classification, Keywords, Language Detection")
        print("   [ner]          -> Entity Recognition (Person, Org, Location)")
        print("   [translation]  -> Multi-language NLLB & Argos Support")
        print("   [summarization]-> Abstractive (BART) & Extractive (Sumy) Summary")
        
        print(f"\n{BOLD}💡 GETTING STARTED:{RESET}{YELLOW}")
        print("   import contentintelpy as ci")
        print("   pipeline = ci.create_default_pipeline()")
        print("   result = pipeline.run({'text': 'Your text here'})")
        print(f"{'═'*60}{RESET}\n")

# Run hint on first import if in an interactive session
if sys.stdout.isatty():
    _show_welcome_hint()

# Import Nodes for the default pipeline
from .nodes.language_node import LanguageDetectionNode
from .nodes.translation_node import TranslationNode
from .nodes.classification_node import CategoryClassificationNode
from .nodes.ner_node import NERNode
from .nodes.location_node import LocationExtractionNode
from .nodes.sentiment_node import SentimentNode
from .nodes.keyword_extract_node import KeywordExtractionNode
from .nodes.summarization_node import SummarizationNode

# Import Services for public use
from .services.sentiment_service import SentimentService
from .services.translation_service import TranslationService
from .services.ner_service import NERService
from .services.summarization_service import SummarizationService

def create_default_pipeline() -> Pipeline:
    """
    Creates the canonical ContentIntelPy pipeline.
    
    Execution Order:
    1. Language Detection (Detects source lang)
    2. Translation (Normalizes to English)
    3. Classification (Broad categorization)
    4. NER (Entity discovery)
    5. Location Extraction (Refines location entities)
    6. Sentiment (Analyzes tone)
    7. Keyword Extraction (Highlights)
    8. Summarization (Reduces content)
    
    Returns:
        A configured Pipeline instance ready to run.
    """
    nodes = [
        LanguageDetectionNode(),
        TranslationNode(target_lang="en"), # Normalize to English
        CategoryClassificationNode(),
        NERNode(),
        LocationExtractionNode(),
        SentimentNode(),
        KeywordExtractionNode(),
        SummarizationNode()
    ]
    
    return Pipeline(nodes)

__all__ = [
    "Pipeline",
    "create_default_pipeline",
    "PipelineContext",
    "Node",
    "SentimentService",
    "TranslationService",
    "NERService",
    "SummarizationService"
]
