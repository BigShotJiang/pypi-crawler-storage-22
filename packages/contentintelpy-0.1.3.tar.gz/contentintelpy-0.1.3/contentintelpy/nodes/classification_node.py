from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..utils.model_registry import registry
import logging

logger = logging.getLogger("contentintelpy.nodes.classification")

class CategoryClassificationNode(Node):
    """
    Classifies text into categories using Zero-Shot Classification (BART).
    Default labels: Business, Politics, Sports, Technology, Entertainment, Health, Science.
    """
    DEFAULT_LABELS = [
        "Business", "Politics", "Sports", "Technology", 
        "Entertainment", "Health", "Science", "World"
    ]

    def __init__(self, candidate_labels: list = None):
        super().__init__("CategoryClassificationNode")
        self.candidate_labels = candidate_labels or self.DEFAULT_LABELS

    def process(self, context: PipelineContext) -> PipelineContext:
        # Prefer translated text if available, else original
        text = context.get("text_translated") or context.get("text")
        
        if not text or not isinstance(text, str):
            logger.warning("No text available for category classification.")
            return context

        try:
            classifier = registry.get_classifier_pipeline()
            # Multi-label=False ensures scores sum to 1
            result = classifier(text, self.candidate_labels, multi_label=False)
            
            # Result format: {'labels': ['Sports', ...], 'scores': [0.99, ...]}
            if result and 'labels' in result and 'scores' in result:
                top_label = result['labels'][0]
                top_score = result['scores'][0]
                
                context["category"] = top_label
                context["category_score"] = top_score
                context["all_categories"] = dict(zip(result['labels'], result['scores']))
                logger.debug(f"Classified as: {top_label} ({top_score:.2f})")
            
        except Exception as e:
            logger.error(f"Classification failed: {e}")
            context.add_error("CategoryClassificationNode", str(e))

        return context
