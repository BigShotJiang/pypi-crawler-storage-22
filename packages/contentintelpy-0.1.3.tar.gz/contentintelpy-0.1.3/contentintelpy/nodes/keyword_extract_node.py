from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..utils.model_registry import registry
from ..utils.lazy_import import ensure_dependency
import numpy as np
import logging
import itertools

logger = logging.getLogger("contentintelpy.nodes.keywords")

class KeywordExtractionNode(Node):
    """
    Extracts keywords using semantic embeddings (KeyBERT-style logic).
    
    Algorithm:
    1. Generate candidate n-grams (1-2 words).
    2. Embed document and candidates using SentenceTransformer.
    3. Calculate cosine similarity.
    4. Return top N candidates.
    """
    def __init__(self, top_n: int = 5):
        super().__init__("KeywordExtractionNode")
        self.top_n = top_n

    def process(self, context: PipelineContext) -> PipelineContext:
        text = context.get("text_translated") or context.get("text")
        
        if not text or len(text.split()) < 3:
            return context

        try:
            ensure_dependency("sklearn", "core")
            from sklearn.metrics.pairwise import cosine_similarity
            from sklearn.feature_extraction.text import CountVectorizer

            model = registry.get_embedding_model()

            # 1. Candidate Generation (using simple CountVectorizer)
            # Remove stopwords usually handled by vectorizer, but we use 'english'
            n_gram_range = (1, 2)
            count = CountVectorizer(ngram_range=n_gram_range, stop_words="english").fit([text])
            candidates = count.get_feature_names_out()

            if len(candidates) == 0:
                return context

            # 2. Embeddings
            doc_embedding = model.encode([text])
            candidate_embeddings = model.encode(candidates)

            # 3. Similarity
            distances = cosine_similarity(doc_embedding, candidate_embeddings)
            
            # 4. Top N
            keywords = []
            # flatten distances
            distances = distances[0]
            
            # Get indices of top_n
            # partition works nicely to get top elements, then we sort them
            keywords_idx = np.argpartition(distances, -self.top_n)[-self.top_n:]
            # Sort by score descending
            keywords_idx = keywords_idx[np.argsort(distances[keywords_idx])][::-1]

            for idx in keywords_idx:
                keywords.append({
                    "text": candidates[idx],
                    "score": float(distances[idx])
                })

            context["keywords"] = keywords
            logger.debug(f"Extracted {len(keywords)} keywords.")

        except Exception as e:
            # Fallback? Maybe just log error. 
            # Ideally could fallback to rake-nltk but we banned it.
            # So we just fail softly.
            logger.error(f"Keyword extraction failed: {e}")
            context.add_error("KeywordExtractionNode", str(e))

        return context
