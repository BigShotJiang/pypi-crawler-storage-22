from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..utils.model_registry import registry
import logging

logger = logging.getLogger("contentintelpy.nodes.language")

class LanguageDetectionNode(Node):
    """
    Detects the language of the input text.
    Writes 'language' and 'language_score' to context.
    """
    def __init__(self):
        super().__init__("LanguageDetectionNode")

    def process(self, context: PipelineContext) -> PipelineContext:
        text = context.get("text")
        if not text or not isinstance(text, str):
            logger.warning("No text found in context for LanguageDetectionNode.")
            context["language"] = "en" # Default to English if no text
            context["language_score"] = 0.0
            return context

        try:
            detector = registry.get_language_detector()
            # Truncate text for detection speed/limit
            snippet = text[:512] 
            
            result = detector(snippet)
            # Result format: [{'label': 'en', 'score': 0.99}]
            
            if result and len(result) > 0:
                top_result = result[0]
                lang_code = top_result['label']
                score = top_result['score']
                
                context["language"] = lang_code
                context["language_score"] = score
                logger.info(f"Detected language: {lang_code} ({score:.2f})")
            else:
                context["language"] = "unknown"
                context["language_score"] = 0.0
                
        except Exception as e:
            # Fallback if model fails
            logger.error(f"Language detection model error: {e}")
            context["language"] = "en" # Fallback safe default
            context["language_score"] = 0.0
            raise e # Re-raise to trigger BaseNode error logging

        return context
