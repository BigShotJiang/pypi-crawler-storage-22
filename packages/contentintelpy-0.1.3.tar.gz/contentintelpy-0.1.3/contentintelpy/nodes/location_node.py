from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
import logging

logger = logging.getLogger("contentintelpy.nodes.location")

class LocationExtractionNode(Node):
    """
    Refines location data from NER results.
    Extracts 'Location', 'City', 'Country' entities into a dedicated 'locations' key.
    Future upgrade: Add actual Geocoding (Lat/Lon) here.
    """
    LOCATION_LABELS = {"Location", "City", "Country", "GPE"}

    def __init__(self):
        super().__init__("LocationExtractionNode")

    def process(self, context: PipelineContext) -> PipelineContext:
        entities = context.get("entities", [])
        
        if not entities:
            return context

        locations = []
        seen = set()

        for ent in entities:
            label = ent.get("label")
            text = ent.get("text")
            
            if label in self.LOCATION_LABELS and text:
                # Basic deduplication
                clean_text = text.lower().strip()
                if clean_text not in seen:
                    locations.append({
                        "name": text,
                        "type": label,
                        # Placeholder for future geocoding extension:
                        # "coordinates": None 
                    })
                    seen.add(clean_text)

        if locations:
            context["locations"] = locations
            logger.debug(f"Extracted {len(locations)} unique locations.")
        
        return context
