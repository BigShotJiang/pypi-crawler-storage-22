from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..utils.model_registry import registry
import logging

logger = logging.getLogger("contentintelpy.nodes.ner")

class NERNode(Node):
    """
    Named Entity Recognition using GLiNER.
    Extracts: Person, Organization, Location, Date, etc.
    """
    LABELS = ["Person", "Organization", "Location", "City", "Country", "Date"]

    def __init__(self, labels: list = None):
        super().__init__("NERNode")
        self.labels = labels or self.LABELS

    def process(self, context: PipelineContext) -> PipelineContext:
        text = context.get("text_translated") or context.get("text")
        
        if not text:
            return context

        try:
            gliner = registry.get_gliner_model()
            # GLiNER predict_entities returns list of dicts: {'text': '', 'label': '', 'score': float}
            entities = gliner.predict_entities(text, self.labels)
            
            # Normalize and serialize
            serialized_entities = []
            for ent in entities:
                serialized_entities.append({
                    "text": ent["text"],
                    "label": ent["label"],
                    "score": float(ent.get("score", 0.0))
                })
            
            context["entities"] = serialized_entities
            logger.debug(f"Found {len(serialized_entities)} entities.")

        except Exception as e:
            logger.error(f"NER failed: {e}")
            context.add_error("NERNode", str(e))

        return context
