from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..utils.model_registry import registry
import logging

logger = logging.getLogger("contentintelpy.nodes.sentiment")

class SentimentNode(Node):
    """
    Analyzes emotional tone (Positive / Negative / Neutral) using RoBERTa.
    Provides output in both English and Native language (if supported).
    """
    
    # Simple static mapping for target language labels (MVP approach)
    # In a full version, this could be dynamic or more extensive.
    LABEL_MAP = {
        "hi": {
            "positive": "सकारात्मक",
            "negative": "नकारात्मक",
            "neutral": "तटस्थ"
        },
        "es": {
            "positive": "positivo",
            "negative": "negativo",
            "neutral": "neutral"
        },
        "fr": {
            "positive": "positif",
            "negative": "négatif",
            "neutral": "neutre"
        },
        # Add more as needed
    }

    def __init__(self):
        super().__init__("SentimentNode")

    def process(self, context: PipelineContext) -> PipelineContext:
        # Sentiment should run on the TRANSLATED text (English) for model accuracy
        # But we return labels relevant to the original language context if possible.
        text_to_analyze = context.get("text_translated") or context.get("text")
        original_lang = context.get("language", "en")

        if not text_to_analyze:
            return context

        try:
            analyzer = registry.get_sentiment_pipeline()
            # Truncate to model max length (~512 tokens)
            result = analyzer(text_to_analyze[:512]) 
            # Result: [{'label': 'positive', 'score': 0.98}]
            
            if result and len(result) > 0:
                top = result[0]
                label_en = top['label'].lower() # positive, negative, neutral
                score = top['score']

                # Resolve Native Label
                label_native = label_en
                if original_lang in self.LABEL_MAP:
                    label_native = self.LABEL_MAP[original_lang].get(label_en, label_en)

                context["sentiment"] = {
                    "value": label_native,
                    "value_en": label_en,
                    "confidence": round(score, 4)
                }
                logger.debug(f"Sentiment: {label_en} ({score:.2f})")

        except Exception as e:
            logger.error(f"Sentiment analysis failed: {e}")
            context.add_error("SentimentNode", str(e))

        return context
