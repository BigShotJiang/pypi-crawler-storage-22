from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..utils.model_registry import registry
import logging

from ..utils.lazy_import import ensure_dependency

logger = logging.getLogger("contentintelpy.nodes.summarization")

class SummarizationNode(Node):
    """
    Summarizes text.
    Primary: BART (Generic Abstractive) via Transformers.
    Fallback: Sumy (LSA - Extractive).
    """
    def __init__(self, max_length: int = 150, min_length: int = 40):
        super().__init__("SummarizationNode")
        self.max_length = max_length
        self.min_length = min_length

    def process(self, context: PipelineContext) -> PipelineContext:
        text = context.get("text_translated") or context.get("text")
        
        if not text or len(text.split()) < 30:
            logger.debug("Text too short for summarization.")
            return context

        summary_text = None

        # 1. Try BART
        try:
            summarizer = registry.get_summarization_pipeline()
            # Limit input size to avoid model errors on very long text
            input_text = text[:1024 * 4] 
            
            result = summarizer(input_text, max_length=self.max_length, min_length=self.min_length, do_sample=False)
            if result and len(result) > 0:
                summary_text = result[0]['summary_text']
        except Exception as e:
            logger.warning(f"BART summarization failed: {e}. Falling back to Sumy.")
            context.add_error("SummarizationNode_BART", str(e))

        # 2. Fallback: Sumy (LSA)
        if not summary_text:
            try:
                ensure_dependency("sumy", "summarization")
                from sumy.parsers.plaintext import PlaintextParser
                from sumy.nlp.tokenizers import Tokenizer
                from sumy.summarizers.lsa import LsaSummarizer as Summarizer
                from sumy.nlp.stemmers import Stemmer
                from sumy.utils import get_stop_words

                parser = PlaintextParser.from_string(text, Tokenizer("english"))
                stemmer = Stemmer("english")
                summarizer = Summarizer(stemmer)
                summarizer.stop_words = get_stop_words("english")

                # Extract top 3 sentences
                sentences = summarizer(parser.document, 3)
                summary_text = " ".join([str(s) for s in sentences])
                context["summary_method"] = "sumy_lsa"
            except Exception as e:
                logger.error(f"Sumy fallback failed: {e}")
                context.add_error("SummarizationNode_Sumy", str(e))

        if summary_text:
            context["summary"] = summary_text
        
        return context
