from ..pipeline.base_node import Node
from ..pipeline.context import PipelineContext
from ..utils.model_registry import registry
from ..utils.lazy_import import ensure_dependency
import logging

logger = logging.getLogger("contentintelpy.nodes.translation")

class TranslationNode(Node):
    """
    Normalizes text to the target language (default 'en').
    Strategy:
    1. Check if translation needed (source != target).
    2. Try NLLB (High Quality, GPU/CPU).
    3. Fallback to ArgosTranslate (Offline, CPU).
    """
    def __init__(self, target_lang: str = "en", force: bool = False):
        super().__init__("TranslationNode")
        self.target_lang = target_lang
        self.force = force

    def process(self, context: PipelineContext) -> PipelineContext:
        original_text = context.get("text")
        source_lang = context.get("language", "unknown")

        # 1. Logic Check: Do we need to translate?
        if not original_text:
            return context
            
        if not self.force and source_lang == self.target_lang:
            logger.info(f"Skipping translation: Source is already {source_lang}.")
            context["text_translated"] = original_text
            context["translation_method"] = "skipped"
            return context

        # 2. Try NLLB (High Quality)
        translated_text = None
        try:
            logger.info("Attempting translation with NLLB...")
            translator = registry.get_translation_pipeline()
            # NLLB expects specific language codes (e.g., 'hin_Deva' for Hindi)
            # For simplicity in this v0.1, we assume the model handles standard ISO codes or auto-detect
            # In a real deep implementation, we'd map ISO->NLLB codes. 
            # Transformers pipeline handles source detection often, but target needs spec.
            # However, NLLB pipeline usage is slightly complex. 
            # For v0.1.0 reliability, we wrap this in try-except carefully.
            
            # Simple direct usage for standard pipeline
            output = translator(original_text, src_lang=source_lang, tgt_lang=self.target_lang, max_length=512)
            # Output format: [{'translation_text': '...'}]
            if output and len(output) > 0:
                translated_text = output[0]['translation_text']
                context["translation_method"] = "nllb"
        except Exception as e:
            logger.warning(f"NLLB translation failed: {e}. Falling back to Argos.")
            context.add_error("TranslationNode_NLLB", str(e))

        # 3. Fallback: ArgosTranslate (Offline)
        if not translated_text:
            try:
                argostranslate = ensure_dependency("argostranslate", "translation")
                import argostranslate.package
                import argostranslate.translate
                
                logger.info("Attempting translation with ArgosTranslate...")
                # Argos requires ensuring packages are installed
                # This is a blocking network call on first run if not present
                # Ideally, we should preload these in ModelRegistry, but Argos manages its own state
                argostranslate.package.update_package_index()
                available_packages = argostranslate.package.get_available_packages()
                package_to_install = next(
                    filter(
                        lambda x: x.from_code == source_lang and x.to_code == self.target_lang, available_packages
                    ), None
                )
                if package_to_install:
                    argostranslate.package.install_from_path(package_to_install.download())
                
                translated_text = argostranslate.translate.translate(original_text, source_lang, self.target_lang)
                context["translation_method"] = "argos"
            except Exception as e:
                logger.error(f"Argos translation failed: {e}")
                context.add_error("TranslationNode_Argos", str(e))

        # 4. Final Result
        if translated_text:
            context["text_translated"] = translated_text
        else:
            # Last resort: Keep original
            logger.warning("All translation methods failed. Keeping original text.")
            context["text_translated"] = original_text
            context["translation_method"] = "failed_copy"

        return context
