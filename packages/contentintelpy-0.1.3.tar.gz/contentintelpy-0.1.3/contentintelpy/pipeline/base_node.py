from abc import ABC, abstractmethod
from typing import Any
from .context import PipelineContext
import logging

# Configure reusable logger
logger = logging.getLogger("contentintelpy")

class Node(ABC):
    """
    Base class for all NLP processing nodes.
    Enforces the contract: read from context -> process -> write to context -> handle errors.
    """
    def __init__(self, name: str):
        self.name = name

    def run(self, context: PipelineContext) -> PipelineContext:
        """
        Public execution entry point. Handles error safety.
        DO NOT OVERRIDE THIS. Override `process` instead.
        """
        try:
            # Execute the core logic
            return self.process(context)
        except Exception as e:
            # Soft failure: Log error and continue
            error_msg = f"{type(e).__name__}: {str(e)}"
            logger.error(f"Node '{self.name}' failed: {error_msg}")
            context.add_error(self.name, error_msg)
            return context

    @abstractmethod
    def process(self, context: PipelineContext) -> PipelineContext:
        """
        Core logic implementation.
        Must mutate context in-place and return it.
        
        Args:
            context: The mutable pipeline state.
            
        Returns:
            The modified context.
        """
        pass
