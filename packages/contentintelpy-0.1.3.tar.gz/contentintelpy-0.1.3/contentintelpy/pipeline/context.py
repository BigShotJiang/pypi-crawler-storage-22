from typing import Any, Dict, Optional

class PipelineContext:
    """
    Mutable state container for the NLP pipeline.
    wraps a dictionary and provides helper methods for safe access and error logging.
    """
    def __init__(self, initial_data: Optional[Dict[str, Any]] = None):
        self._data: Dict[str, Any] = initial_data or {}
        if "errors" not in self._data:
            self._data["errors"] = {}

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self._data[key] = value

    def add_error(self, node_name: str, error_message: str) -> None:
        """Log a soft failure for a specific node."""
        if "errors" not in self._data:
            self._data["errors"] = {}
        self._data["errors"][node_name] = error_message

    def has_errors(self) -> bool:
        """Check if any errors have been logged in the current context."""
        return len(self._data.get("errors", {})) > 0

    def to_dict(self) -> Dict[str, Any]:
        """Return the raw dictionary state."""
        return self._data

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value

    def __contains__(self, key: str) -> bool:
        return key in self._data
