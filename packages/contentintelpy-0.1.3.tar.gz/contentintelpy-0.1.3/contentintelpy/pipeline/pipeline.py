from typing import List, Dict, Any
from .base_node import Node
from .context import PipelineContext

class Pipeline:
    """
    DAG execution engine.
    Runs a tailored sequence of Nodes in strict order.
    """
    def __init__(self, nodes: List[Node]):
        self.nodes = nodes

    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the pipeline on the input data.
        
        Args:
            input_data: Dictionary containing the input (e.g. {"text": "..."})
            
        Returns:
            The final dictionary with results and any errors (sparse output).
        """
        # Initialize context wrapper
        context = PipelineContext(input_data)

        # distinct linear execution
        for node in self.nodes:
            context = node.run(context)

        return context.to_dict()
