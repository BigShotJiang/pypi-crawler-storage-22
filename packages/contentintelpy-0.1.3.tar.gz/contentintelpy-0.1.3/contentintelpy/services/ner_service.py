from ..nodes.ner_node import NERNode
from ..pipeline.context import PipelineContext
from typing import List, Dict, Any

class NERService:
    """
    Service-first wrapper for Named Entity Recognition.
    """
    def __init__(self, labels: List[str] = None):
        self.node = NERNode(labels=labels)

    def extract(self, text: str) -> List[Dict[str, Any]]:
        """
        Extract entities from text.
        
        Returns:
            List of entities [{'text': '...', 'label': '...', 'score': ...}]
        """
        if not text:
            return []

        context = PipelineContext({"text": text})
        context = self.node.run(context)
        
        return context.get("entities", [])
